/********************************************************************************************************
*  File			: userservice.c
*  Created By	: Prachi Wade/Muktesh Girdhani
*  Created On	: 02-Jul-2012
*  Project		: TCUA 	 
*  Purpose		: Registering User Services
*  Arguments	:	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes
*
********************************************************************************************************/

#include "userservice.h"
#include "iman_headers.h"
#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
//PrintErrorStack();

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

/*
static int PrintErrorStack( void )

*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*

{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Checkout Error(s): \n");
	Write_To_Log("Checkout Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}
*/
extern DLLAPI int All_register_userservices(METHOD_message_t *msg,va_list args)
{

	/******Muktesh*******/
	int nargs=1;
    int *inputArgTypes;
	int retValueType;
    /********************/

    /********Prachi*******/
	int nargs1=19;
    int *inputArgTypes1;
    int retValueType1;    
    /*********************/

    
	/*********Muktesh**********************************************/ 
	inputArgTypes=(int *)MEM_alloc(nargs * sizeof(int));
	inputArgTypes[0]=USERARG_STRING_TYPE;	
	retValueType=USERARG_TAG_TYPE;
	printf("\n User Service Call...........");

    /**************************************************************/

    /**************************************************************/   
    inputArgTypes1=(int *)MEM_alloc(nargs1 * sizeof(int));
    inputArgTypes1[0]=USERARG_STRING_TYPE;
	inputArgTypes1[1]=USERARG_STRING_TYPE;

	inputArgTypes1[2]=USERARG_STRING_TYPE;
	inputArgTypes1[3]=USERARG_STRING_TYPE;
	inputArgTypes1[4]=USERARG_STRING_TYPE;

	inputArgTypes1[5]=USERARG_STRING_TYPE;
	inputArgTypes1[6]=USERARG_STRING_TYPE;
	inputArgTypes1[7]=USERARG_STRING_TYPE;

	inputArgTypes1[8]=USERARG_STRING_TYPE;
	inputArgTypes1[9]=USERARG_STRING_TYPE;
	inputArgTypes1[10]=USERARG_STRING_TYPE;

	inputArgTypes1[11]=USERARG_STRING_TYPE;
	inputArgTypes1[12]=USERARG_STRING_TYPE;
	inputArgTypes1[13]=USERARG_STRING_TYPE;

	inputArgTypes1[14]=USERARG_STRING_TYPE;
	inputArgTypes1[15]=USERARG_STRING_TYPE;
	inputArgTypes1[16]=USERARG_STRING_TYPE;

	inputArgTypes1[17]=USERARG_STRING_TYPE;
	inputArgTypes1[18]=USERARG_STRING_TYPE;


    retValueType1 = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;
	Write_To_Log("\n User Service Call ...........");
    /**************************************************************/    
	 

	USERSERVICE_register_method("assignCFT",(USER_function_t)proj_assign_cft,nargs1,inputArgTypes1,retValueType1);	 
	USERSERVICE_register_method("createBulkItems",(USER_function_t)TCDEV_create_bulk_items,nargs,inputArgTypes,retValueType);

    return ITK_ok;

}


extern DLLAPI int userservice_register_callbacks()
{
   CUSTOM_register_exit("userservice","USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t) All_register_userservices);
   Write_To_Log("\nRegistering Common User Service \n");
   return ITK_ok;
}

