/****************************************************************************************************
*  File            :   FolderCreatePost.c
*  Created By      :   Yogiraj
*  Created On      :   20-Feb-2012
*  Purpose         :   Post create of PIP Project
******************************************************************************************************/
#include <tc/tc.h>
#include <custom.h>
#include <dataset.h>
#include <epm/epm.h>
#include <ict_userservice.h>
#include <method.h>
#include <property/prop.h>
#include <property/prop_errors.h>
#include <property/prop_msg.h>
#include <reservation.h>
#include <stdarg.h>
#include <string.h>
#include <tc.h>
#include <tc/emh_const.h>
#include <tc/envelope.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/method.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcfile.h>
#include <tctype.h>
#include <item_errors.h>
#include <user_exits/user_exits.h>
#include <workspaceobject.h>
#include <project.h>
#include <tc_msg.h>
#include "iman_headers.h"
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_err 919002

char* subString (char* mainStringf ,int fromCharf,int toCharf);

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    printf(msg);
    va_end(args);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    int *pSevLst, *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
	
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

extern DLLAPI int createpost_method_PIP(METHOD_message_t *m, va_list args)
{
	const char	 reason; 
	const char	change_id;
	const char	dir_name;
	const char* type_name;
    tag_t       pipproj= NULLTAG;
	tag_t	objTypeTag= NULLTAG;
	tag_t	projobj= NULLTAG; 
	tag_t	projobj1 = NULLTAG;

	int		i=0,	notalpha =99, IDlen;

	char	*prj_name= NULL;
	char	*prj_desc = NULL;
	char   type_name1[TCTYPE_name_size_c+1];
	char	Ptype_name1[TCTYPE_name_size_c+1];
	char	person_name[SA_person_name_size_c+1];
	char	person_Org[SA_organization_size_c+1];
	char	*person_MailId;
	char	*Mgr_MailId;
	char	*username;
	char	*prj_manager;
	
	tag_t	user_tag, person_tag, user, Mgr_tag = NULLTAG;

	tag_t    tagItem=NULLTAG;
	tag_t    tagItemRev=NULLTAG;

	tag_t*      new_item_tag;
	tag_t*      new_rev_tag;

	char command[100];

	const char* item_id;
    const char* item_name;
    const char* rev_id;
	tag_t lov_tag=NULLTAG;
	tag_t *lov_tag1;
	
	lov_tag = m->object_tag;
	
	printf("\n ========================================== = \n");fflush(stdout);

	if (TCTYPE_ask_object_type(lov_tag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if (TCTYPE_ask_name(objTypeTag,type_name1)!=ITK_ok)PrintErrorStack();

	printf("\n type_name1 = %s\n", type_name1);fflush(stdout);
	if(strcmp(type_name1,"T8_Project")==0)
	{
		if( AOM_ask_value_string(lov_tag,"object_name",&prj_name))PrintErrorStack();
		if( AOM_ask_value_string(lov_tag,"object_desc",&prj_desc))PrintErrorStack();
		printf("\n Project name %s= object_desc = %s\n", prj_name,prj_desc);fflush(stdout);
		if (PROJ_create_project(prj_name,prj_name,prj_desc,&pipproj)!=ITK_ok)PrintErrorStack();
		printf("\n ----------- After Create Project---------- ");fflush(stdout);

		if(strcmp(prj_name,""))
		{
			if (PROJ_find(prj_name,&projobj) !=ITK_ok)PrintErrorStack();

			if(projobj !=NULLTAG)
			{
				if (TCTYPE_ask_object_type(projobj,&projobj1)!=ITK_ok)PrintErrorStack();
				if (TCTYPE_ask_name(projobj1,Ptype_name1)!=ITK_ok)PrintErrorStack();
				printf("\n Proj type_name = %s\n", Ptype_name1);
				if (PROJ_assign_objects(1 ,&projobj ,1 ,&lov_tag )!=ITK_ok)PrintErrorStack();
				printf("\nAssigned to Project\n");fflush(stdout);

			}
			else
			{
				printf("\nProject not found\n");fflush(stdout);
			}
		}
	}
	else
	{
	printf("\nProject Code attribute found NULL on object. Project will not be assigned\n");fflush(stdout);
	}
	printf("\nPost Creation.....done\n");fflush(stdout);
	return ITK_ok;
}

extern int PIPcreatepost_register_method_PIP(int *decision, va_list args)
{
    METHOD_id_t  method;
	METHOD_id_t	methodP;
  
	*decision = ALL_CUSTOMIZATIONS;
   
	if ( METHOD_find_method("Folder", ITEM_create_msg, &method) !=ITK_ok)
	PrintErrorStack();

	if (method.id != NULLTAG)
	{
		if( METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) createpost_method_PIP, NULL)!=ITK_ok)
		PrintErrorStack();
		printf(" \n 333333333********** Registered as Post-Action for PIP Proj Creation ***********3333333333\n");fflush(stdout);
	}
	else
		printf("\nMethod not found!\n");fflush(stdout);

    return ITK_ok;
}

extern DLLAPI int PIPcreatepost_register_callbacks ()
{
    printf("\n\n PIPcreatepost \n\n");fflush(stdout);
    if(CUSTOM_register_exit ( "PIPcreatepost", "USER_init_module", (CUSTOM_EXIT_ftn_t)  PIPcreatepost_register_method_PIP) !=ITK_ok)
    PrintErrorStack();
	return ( ITK_ok );
}
