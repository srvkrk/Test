#include <ict/ict_userservice.h>
#include <stdio.h>
#include <item.h>
#include <custom.h>
#include <stdarg.h>
#include <method.h>
#include <string.h>
#include <tc_string.h>
#include <stdlib.h>
#include <sa.h>
#include <folder.h>
#include <aom.h>


extern DLLAPI int userservice_register_callbacks();
extern DLLAPI int All_register_userservices(METHOD_message_t *msg,va_list args);
int proj_assign_cft(void* retValue);
int TCDEV_create_bulk_items(void* retValue);

