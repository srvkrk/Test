/********************************************************************************************************
*  File			: cft.c
*  Created By	: Prachi Wade
*  Created On	: 01-Jun-2012
*  Project		: TCUA 	 
*  Purpose		: Custom exit for - assign CFT
*  Arguments	:	 

*  Modification History : 
*  S.No    Date     CR      Modified By         Modification Notes
*
********************************************************************************************************/

#include "iman_headers.h"
#include <epm_task_template_itk.h>
#include <project.h>
#include <arch.h>
#include <cr.h>

#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	Write_To_Log("CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}
 
int find_user(char *username, tag_t *user_tag)
{
	int ifail =0;
	int k	  =0;
	tag_t person_tag = NULLTAG;

	int    n_instances		= 0;
	int    n_classes		= 0;
	tag_t  *ref_classes		= 0;
	tag_t  *ref_instances	= NULLTAG;	
	tag_t  user_class		= NULLTAG;	
	tag_t  classId			= NULLTAG;
	int	   *instance_levels;
	int	   *instance_where_found;
	int    *class_levels;
	int    *class_where_found;
	char  	userid[SA_user_size_c+1];
	tag_t   member_tag = NULLTAG;

	
	SA_find_person(username,&person_tag );
	if(person_tag != NULLTAG)
	{

	   CALLAPI(POM_referencers_of_instance(person_tag, 1,POM_in_ds_and_db,&n_instances,&ref_instances,&instance_levels,&instance_where_found,&n_classes,&ref_classes,&class_levels,&class_where_found));
 	   CALLAPI(POM_class_id_of_class("User", &user_class));
	   for(k=0;k<n_instances;k++)
       {
 
			CALLAPI(POM_class_of_instance(ref_instances[k],&classId));
		    if(user_class==classId)
	        {  
				
				CALLAPI(SA_ask_user_identifier(ref_instances[k],userid));
				Write_To_Log("User id is:%s\n",userid);
				CALLAPI(SA_find_user(userid,&member_tag));
				*user_tag = member_tag;

	        }
	   }
	}

	return ifail;

}


int find_proj_member(tag_t project_tag)
{
	int ifail =0;

	int k	  =0;  
	tag_t   team_tag = NULLTAG;
	tag_t   *project_members = NULLTAG;
	int num =0;
	tag_t *mem = NULLTAG;

	tag_t group_tag = NULLTAG;
	tag_t role_tag = NULLTAG;
	tag_t user_tag = NULLTAG;

	char group_name[SA_name_size_c+1];
	char role_name[SA_name_size_c+1];
	char *user_name=NULL;
 
	 
	if(project_tag != NULLTAG)
	{
	   Write_To_Log("\nInside Remove Memebers\n");

       AOM_ask_value_tag(project_tag,"project_team",&team_tag); 
	   if(team_tag != NULLTAG)
		{	
	       
			AOM_ask_value_tags(team_tag,"project_members",&num,&mem);
			Write_To_Log("num:%d\n",num);
			AOM_refresh(project_tag,1);
			for(k=0;k<num;k++)
			{
				 AOM_ask_value_tag(mem[k],"the_group",&group_tag); 				 
			 	 SA_ask_group_name(group_tag,group_name); 

				 AOM_ask_value_tag(mem[k],"the_role",&role_tag); 
			 	 SA_ask_role_name(role_tag,role_name); 

				 AOM_ask_value_tag(mem[k],"the_user",&user_tag); 
			 	 POM_ask_user_name(user_tag,&user_name); 
				 
				 Write_To_Log("group:%s role:%s user:%s\n",group_name,role_name,user_name);		 

				 if(strstr(role_name,"Primary")!=NULL || strstr(role_name,"Secondary")!=NULL || strstr(role_name,"Tertiary")!=NULL || strstr(role_name,"Head")!=NULL)
				 {
					Write_To_Log("\n%s removed\n",user_name);
					PROJ_remove_members( project_tag,1,&user_tag);				 
				 }
	  	
			}

            save_object(project_tag);
			AOM_refresh(project_tag,0);
		 
	   }	
	}

	return ifail;

} 


int save_object (tag_t     object_tag)
{
    int ReturnCode;

    /*  Save the object.  */
    ReturnCode = AOM_save (object_tag);
    if (ReturnCode != ITK_ok)
    {
        //output_error ("ERROR %d save object.\n", ReturnCode);
        return (ReturnCode);
    }

    /* Unlock the object. */
    ReturnCode = AOM_unlock (object_tag);
    if (ReturnCode != ITK_ok)
    {
        //output_error ("ERROR %d unlock object.\n", ReturnCode);
    }

    return (ReturnCode);
}


int add_user_in_project(tag_t user_tag,tag_t project,char *groupname,char * rolename,tag_t *final_tag)
{

	 int k =0;
	 tag_t role_tag = NULLTAG;
	 tag_t Mem_user_tag = NULLTAG;
	 int ifail =0;
	 tag_t classId = NULLTAG;
	 char *class_name = NULL; 
	 char role_name[SA_name_size_c+1];
	 tag_t *members_tag = NULLTAG;
	 int count =0,j=0;
	 tag_t member = NULLTAG;
	 tag_t    	group_tag  = NULLTAG;
	 char  	group_name[SA_name_size_c+1]; 

	 int is_user_present_in_role =0;
	 int is_user_present_in_grp  =0;

	// CALLAPI(SA_find_user(user,&user_tag)); 
	// CALLAPI(POM_referencers_of_instance(user_tag,1,POM_in_ds_and_db,&n_instances,&ref_instances,&instance_levels,&instance_where_found,&n_classes,&ref_classes,&class_levels,&class_where_found));
	 SA_find_groupmember_by_user(user_tag,&count,&members_tag);
	  Write_To_Log("\nCheck Group name:%s Role name:%s\n",groupname,rolename);
	 //Write_To_Log("\nGroupMember count is :%d\n",count);
	 for(j=0;j<count;j++ )
     {
			is_user_present_in_grp = 0;	
			is_user_present_in_role = 0;

		      CALLAPI(SA_ask_groupmember_group(members_tag[j],&group_tag)); 
			  CALLAPI(SA_ask_group_name(group_tag,group_name)); 
			  Write_To_Log("Group name is :%s\n",group_name);
			  if(strcmp(group_name,groupname)==0)
			  {
				  is_user_present_in_grp = 1;		 
			  }

              CALLAPI(SA_ask_groupmember_role(members_tag[j],&role_tag));
              CALLAPI(SA_ask_role_name(role_tag,role_name));

              Write_To_Log("Role name is :%s\n",role_name);
			  if(strcmp(role_name,rolename)==0)
			  {
			//	  Write_To_Log("\n%s found\n",rolename);
				  is_user_present_in_role = 1;
			  }
		

			//  Write_To_Log("\nis_user_present_in_grp:%d is_user_present_in_role:%d\n",is_user_present_in_grp,is_user_present_in_role);			
			  if(is_user_present_in_grp==1 && is_user_present_in_role ==1 )
		      {
				 Write_To_Log("\nUser present in group and role:%s :%s\n",group_name,role_name);
				// final_tag = &(members_tag[j]);
				 *final_tag = (members_tag[j]);
				 break;
			  }
     }

	 if(is_user_present_in_grp==0 || is_user_present_in_role==0)
	 {
	   //add user in group/role. 
	    Write_To_Log("\nAdd user in group and role:%s :%s\n",groupname,rolename);
	    CALLAPI(SA_find_group(groupname,&group_tag));
		CALLAPI(SA_find_role(rolename,&role_tag));
	    
		Write_To_Log("\nAdd user in group\n");
		SA_create_groupmember(group_tag,user_tag,0,&member);
       // AOM_save(member);
		//AOM_refresh(member,1);
		
		Write_To_Log("\nSet role of user in group\n");
		SA_set_groupmember_role(member,role_tag);
        AOM_save(member);
		AOM_refresh(member,1);
 

		//Search User Again...................
		Write_To_Log("\nSearch User\n");
		/**********/
		 SA_find_groupmember_by_user(user_tag,&count,&members_tag);
		//Write_To_Log("\nGroupMember count is :%d\n",count);
		Write_To_Log("\nSearch for :%s %s\n",groupname,rolename);
		 for(j=0;j<count;j++ )
		 {
				is_user_present_in_grp = 0;	
				is_user_present_in_role = 0;
				  CALLAPI(SA_ask_groupmember_group(members_tag[j],&group_tag)); 
				  CALLAPI(SA_ask_group_name(group_tag,group_name)); 
				   Write_To_Log("Group name is :%s\n",group_name);
 				  if(strcmp(group_name,groupname)==0)
				  {
					  is_user_present_in_grp = 1;		 
				  }

				  CALLAPI(SA_ask_groupmember_role(members_tag[j],&role_tag));
				  CALLAPI(SA_ask_role_name(role_tag,role_name));
				  Write_To_Log("Role name is :%s\n",role_name);
 				  if(strcmp(role_name,rolename)==0)
				  {
 					  is_user_present_in_role = 1;
				  }
				 
				  if(is_user_present_in_grp==1 & is_user_present_in_role ==1 )
				  {
					  Write_To_Log("\nUser found in Group name:%s Role name:%s\n",group_name,role_name);  
					// final_tag = &(members_tag[j]);
					 *final_tag = (members_tag[j]);
					 break;
				  }
		 }

		/*********/

		//*final_tag = member;
	  
	 } 

	 

/*
	 Write_To_Log("n_instances: %d\t n_classes %d\n",n_instances,n_classes);
	 for(k=0;k<n_instances;k++)
	 {                              
			   CALLAPI(POM_class_of_instance(ref_instances[k],&classId));
			   CALLAPI(POM_name_of_class(classId,&class_name));
			   Write_To_Log("Class name :%s\n",class_name);
			   if(strcmp(class_name,"GroupMember")==0)
			   {
					 CALLAPI(SA_ask_groupmember_role(ref_instances[k],&role_tag));
					 CALLAPI(SA_ask_role_name(role_tag,role_name));
					 Write_To_Log("Role name is :%s\n",role_name);
					 //PROJ_add_members(Project_tag,1,&ref_instances[k]);  // this is for assigning members to Project
					 if(strcmp(role_name,rolename)==0)                  // role_name which is passed from JAVA as a argument
					 {
							Write_To_Log("Role found \n");
							CALLAPI(SA_ask_groupmember_user(ref_instances[k],&Mem_user_tag));
							CALLAPI(PROJ_assign_team(project,1,&ref_instances[k],Mem_user_tag,1,&Mem_user_tag));
							Write_To_Log("\nProject user assigned ");
							AOM_save(project);
							AOM_refresh(project,0);
							break;
					 }
		   
			  }
	}        
*/
	return ifail;

} 

int proj_assign_cft(void* retValue)
{
     int status=ITK_ok;
	 char *projname = NULL;
	 char *action=NULL;
	 char *projmgr = NULL;

     char* mktprim=NULL;
     char* mktsec=NULL;
     char* mktter=NULL;

	 char* ercprim=NULL;
     char* ercsec=NULL;
     char* ercter=NULL;

	 char* vdprim=NULL; 
     char* vdsec=NULL;
     char* vdter=NULL;

	 char* tsprim=NULL;
     char* tssec=NULL;
     char* tster=NULL;

	 char* finprim=NULL;
     char* finsec=NULL;
     char* finter=NULL;

	 char* npipm=NULL;
     char* npihd=NULL;      
 
     int n_items =0;
	 tag_t *item_tags= NULLTAG;
	 tag_t project = NULLTAG;
	 tag_t user_tag = NULLTAG;
	 char *project_ids  =NULL;
	 tag_t *member_tags= NULLTAG;
	 tag_t *auth_tags= NULLTAG;
	 tag_t member	= NULLTAG;
	 tag_t admin_tag = NULLTAG;
	 tag_t    	person_tag	 = NULLTAG;
	 int ifail =0;
	 int count =0;
	 tag_t   	current_role_tag = NULLTAG;
	 tag_t   	dba_grp = NULLTAG;
	 tag_t   	dba_role = NULLTAG;
	 char rolename[SA_name_size_c+1];
	 WSO_search_criteria_t   criteria;
 

	 int k	  =0;  
	 tag_t   team_tag = NULLTAG;
	 tag_t   *project_members = NULLTAG;
	 int num =0;
	 tag_t *mem = NULLTAG;

	 tag_t group_tag = NULLTAG;
	 tag_t role_tag = NULLTAG;
	 tag_t usertag = NULLTAG;

	 char group_name[SA_name_size_c+1];
	 char role_name[SA_name_size_c+1];
	 char *user_name=NULL;


      USERSERVICE_array_t array_struct;
	  int array_size = 16; 
      char **string_array = NULL;
      string_array =  (char **) MEM_alloc(array_size * sizeof(char*));

     // user_name = (char *) MEM_alloc (sizeof (char) * 128);

 
	 SA_ask_current_role( &current_role_tag);
	 SA_ask_role_name (current_role_tag,rolename); 
	 Write_To_Log("\nSA_ask_role_name:%s\n",rolename);

	// CALLAPI(ITK_init_module("paw05169","paw05169","dba")); 
	SA_find_group("dba",&dba_grp);
	SA_find_role("DBA",&dba_role);
	if(dba_grp != NULLTAG && dba_role!= NULLTAG)
	{
		SA_change_group(dba_grp,dba_role);
	}

	 SA_ask_current_role(&current_role_tag);
	 SA_ask_role_name (current_role_tag,rolename); 
	 Write_To_Log("\nSA_ask_role_name:%s\n",rolename);
 
	
	 USERARG_get_string_argument(&projname);
	 if(projname!=NULL)
	 { 
		 Write_To_Log("\n Project Name : %s",projname);	 
	 }
	 else
	 {
		 Write_To_Log("\n NO Project Input\n");	 
		// EMH_store_error_s1(EMH_severity_error,ITK_err,"Project Not Found");	 					 	
		// return ITK_err;
	 }

 

	 //Assign CFT

	 /************************************************************************/

	 member_tags = (tag_t *) MEM_alloc (sizeof (tag_t) * 20);
	 auth_tags = (tag_t *) MEM_alloc (sizeof (tag_t) * 20);

	 //CALLAPI(WSOM_find(projname,&n_items,&item_tags));
	 CALLAPI(WSOM_clear_search_criteria(&criteria));
	 strcpy(criteria.name,projname);
	 strcpy(criteria.class_name,"T8_Project");
     CALLAPI(WSOM_search(criteria,&n_items,&item_tags)); 
	 Write_To_Log("\nNo of Projects found:%d\n",n_items);fflush(stdout);

     if(n_items > 0)
	 { 
		Write_To_Log("\nProject Found:%s\n",projname);
		CALLAPI(AOM_ask_value_string(item_tags[0],"project_ids",&project_ids));
	    Write_To_Log("Project ids:%s\n",project_ids);
	 	CALLAPI(PROJ_find(project_ids,&project)); 	
		if(project!=NULLTAG)
		{				
				USERARG_get_string_argument(&action);
                if(strcmp(action,"update")==0)            
			    { 
						/*
						AOM_refresh(project,1);
						CALLAPI(POM_set_owning_user(project,user_tag));
                        save_object(project);
						AOM_refresh(project,0);
						*/
						CALLAPI(find_proj_member(project));

						USERARG_get_string_argument(&projmgr);
						Write_To_Log("\n Project Manager : %s",projmgr);
						if(projmgr!=NULL && strlen(projmgr)>0)
						{ 					 
							CALLAPI(SA_find_user(projmgr,&user_tag));
							if(user_tag!=NULLTAG)
							{
								 add_user_in_project(user_tag,project,"Project Administration","Project Manager",&admin_tag);		
								 Write_To_Log("\nAdding Project Manager\n");
								 (auth_tags)[0] = admin_tag;
								 (member_tags)[count] = admin_tag;
								 count++;
							}
						}	 
						 
						/***********************************/
						USERARG_get_string_argument(&mktprim);
						Write_To_Log("\n Marketing Primary : %s",mktprim);		 
						if(mktprim!=NULL && strlen(mktprim)>0)
						{
							//CALLAPI(SA_find_user(mktprim,&user_tag)); 
							CALLAPI(find_user(mktprim,&user_tag));
							if(user_tag!=NULLTAG)
							{
								 add_user_in_project(user_tag,project,"Marketing","Primary",&member);		
								 Write_To_Log("\nAdding Marketing Primary\n");
								 (member_tags)[count] = member;
								 count++;
							}
						}	 
						 
						USERARG_get_string_argument(&mktsec);
						Write_To_Log("\n Marketing Secondary  : %s",mktsec);
						if(mktsec!=NULL && strlen(mktsec)>0)
						{
							//CALLAPI(SA_find_user(mktsec,&user_tag));
							CALLAPI(find_user(mktsec,&user_tag));
							if(user_tag!=NULLTAG)
							{								 
								 add_user_in_project(user_tag,project,"Marketing","Secondary",&member);	
								 Write_To_Log(" Adding Marketing Secondary\n");	
								 (member_tags)[count] = member;
								 count++;
							}
						}

						USERARG_get_string_argument(&mktter);
						Write_To_Log("\n Marketing Tertiary  : %s",mktter);
						if(mktter!=NULL && strlen(mktter)>0)
						{
							//CALLAPI(SA_find_user(mktter,&user_tag)); 
							CALLAPI(find_user(mktter,&user_tag)); 
							if(user_tag!=NULLTAG)
							{								 				 
								 add_user_in_project(user_tag,project,"Marketing","Tertiary",&member);	 
								 Write_To_Log(" Adding Marketing Tertiary\n");	
								 (member_tags)[count] = member;
								 count++;
							}
						}

						/***********************************/

						USERARG_get_string_argument(&ercprim);
						Write_To_Log("\n ERC Primary : %s",ercprim);
						if(ercprim!=NULL && strlen(ercprim)>0)
						{
							//CALLAPI(SA_find_user(ercprim,&user_tag)); 
							CALLAPI(find_user(ercprim,&user_tag)); 
							if(user_tag!=NULLTAG)
							{								  
								 add_user_in_project(user_tag,project,"ERC","Primary",&member);	 
								 Write_To_Log(" Adding ERC Primary\n");			
								 (member_tags)[count] = member;
								 count++;				 
							}
						}
			 
						USERARG_get_string_argument(&ercsec);
						Write_To_Log("\n ERC Secondary  : %s",ercsec);
						if(ercsec!=NULL && strlen(ercsec)>0)
						{
							//CALLAPI(SA_find_user(ercsec,&user_tag)); 
							CALLAPI(find_user(ercsec,&user_tag)); 
							if(user_tag!=NULLTAG)
							{									 
								add_user_in_project(user_tag,project,"ERC","Secondary",&member);	 
								Write_To_Log(" Adding ERC Secondary\n");				
								(member_tags)[count] = member;
								count++;	
							}
						}

						USERARG_get_string_argument(&ercter);
						Write_To_Log("\n ERC Tertiary  : %s",ercter);
						if(ercter!=NULL && strlen(ercter)>0)
						{
							//CALLAPI(SA_find_user(ercter,&user_tag)); 
							CALLAPI(find_user(ercter,&user_tag)); 
							if(user_tag!=NULLTAG)
							{								 
								add_user_in_project(user_tag,project,"ERC","Tertiary",&member);	 
								Write_To_Log(" Adding ERC Tertiary\n");			
								(member_tags)[count] = member;
								count++;				 
							}
						}

						/***********************************/


						USERARG_get_string_argument(&vdprim);
						Write_To_Log("\n VD Primary : %s",vdprim);
						if(vdprim!=NULL && strlen(vdprim)>0)
						{
							//CALLAPI(SA_find_user(ercprim,&user_tag)); 
							CALLAPI(find_user(vdprim,&user_tag)); 
							if(user_tag!=NULLTAG)
							{											 
								 add_user_in_project(user_tag,project,"VD","Primary",&member);	 
								  Write_To_Log(" Adding VD Primary\n");
								 (member_tags)[count] = member;
								 count++;				 
							}
						}

						USERARG_get_string_argument(&vdsec);
						Write_To_Log("\n VD Secondary : %s",vdsec);
						if(vdsec!=NULL && strlen(vdsec)>0)
						{
							//CALLAPI(SA_find_user(ercprim,&user_tag)); 
							CALLAPI(find_user(vdsec,&user_tag)); 
							if(user_tag!=NULLTAG)
							{										 
								 add_user_in_project(user_tag,project,"VD","Secondary",&member);	 
								  Write_To_Log(" Adding VD Secondary\n");	
								 (member_tags)[count] = member;
								 count++;				 
							}
						}

						USERARG_get_string_argument(&vdter);
						Write_To_Log("\n VD Tertiary  : %s",vdter);
						if(vdter!=NULL && strlen(vdter)>0)
						{
							//CALLAPI(SA_find_user(ercter,&user_tag)); 
							CALLAPI(find_user(vdter,&user_tag)); 
							if(user_tag!=NULLTAG)
							{									 
								add_user_in_project(user_tag,project,"VD","Tertiary",&member);	 
								Write_To_Log(" Adding VD Tertiary\n");		
								(member_tags)[count] = member;
								count++;				 
							}
						}

						/***********************************/
		  

						USERARG_get_string_argument(&tsprim);
						Write_To_Log("\n TS Primary : %s",tsprim);
						if(tsprim!=NULL && strlen(tsprim)>0)
						{
							//CALLAPI(SA_find_user(ercprim,&user_tag)); 
							CALLAPI(find_user(tsprim,&user_tag)); 
							if(user_tag!=NULLTAG)
							{									 
								 add_user_in_project(user_tag,project,"TS","Primary",&member);	 
								  Write_To_Log(" Adding TS Primary\n");		
								 (member_tags)[count] = member;
								 count++;				 
							}
						}

						
						USERARG_get_string_argument(&tssec);
						Write_To_Log("\n TS Secondary : %s",tssec);
						if(tssec!=NULL && strlen(tssec)>0)
						{
							//CALLAPI(SA_find_user(ercprim,&user_tag)); 
							CALLAPI(find_user(tssec,&user_tag)); 
							if(user_tag!=NULLTAG)
							{								 		 
								 add_user_in_project(user_tag,project,"TS","Secondary",&member);	 
								 Write_To_Log(" Adding TS Secondary\n");	
								 (member_tags)[count] = member;
								 count++;				 
							}
						}


						USERARG_get_string_argument(&tster);
						Write_To_Log("\n TS Tertiary  : %s",tster);
						if(tster!=NULL && strlen(tster)>0)
						{
							//CALLAPI(SA_find_user(ercter,&user_tag)); 
							CALLAPI(find_user(tster,&user_tag)); 
							if(user_tag!=NULLTAG)
							{									 
								add_user_in_project(user_tag,project,"TS","Tertiary",&member);	 
								Write_To_Log(" Adding TS Tertiary\n");		
								(member_tags)[count] = member;
								count++;				 
							}
						} 

						/***********************************/


						USERARG_get_string_argument(&finprim);
						Write_To_Log("\n Finance Primary : %s",finprim);
						if(finprim!=NULL && strlen(finprim)>0)
						{
							//CALLAPI(SA_find_user(ercprim,&user_tag)); 
							CALLAPI(find_user(finprim,&user_tag)); 
							if(user_tag!=NULLTAG)
							{									 
								 add_user_in_project(user_tag,project,"Finance","Primary",&member);	 
								  Write_To_Log(" Adding Finance Primary\n");		
								 (member_tags)[count] = member;
								 count++;				 
							}
						}

						USERARG_get_string_argument(&finsec);
						Write_To_Log("\n Finance Secondary : %s",finsec);
						if(finsec!=NULL && strlen(finsec)>0)
						{
							//CALLAPI(SA_find_user(ercprim,&user_tag)); 
							CALLAPI(find_user(finsec,&user_tag)); 
							if(user_tag!=NULLTAG)
							{										 
								 add_user_in_project(user_tag,project,"Finance","Secondary",&member);	 
								  Write_To_Log(" Adding Finance Secondary\n");	
								 (member_tags)[count] = member;
								 count++;				 
							}
						}

						USERARG_get_string_argument(&finter);
						Write_To_Log("\n Finance Tertiary : %s",finter);
						if(finter!=NULL && strlen(finter)>0)
						{
							//CALLAPI(SA_find_user(ercprim,&user_tag)); 
							CALLAPI(find_user(finter,&user_tag)); 
							if(user_tag!=NULLTAG)
							{								
								 add_user_in_project(user_tag,project,"Finance","Tertiary",&member);	 
								  Write_To_Log(" Adding Finance Tertiary\n");			 
								 (member_tags)[count] = member;
								 count++;				 
							}
						}

						/***********************************/

						//USERARG_get_string_argument(&npipm);
						/*
						Write_To_Log("\n NPI Project Manager : %s",projmgr);
						if(projmgr!=NULL && strlen(projmgr)>0)
						{
							//CALLAPI(SA_find_user(ercprim,&user_tag)); 
							CALLAPI(find_user(projmgr,&user_tag)); 
							if(user_tag!=NULLTAG)
							{								 	 
								 add_user_in_project(user_tag,project,"NPI","Project Manager",&member);	 
								 Write_To_Log(" Adding NPI Project Manager\n");		
								 (member_tags)[count] = member;
								 count++;				 
							}
						}
						*/

						USERARG_get_string_argument(&npihd);
						Write_To_Log("\n NPI Head : %s",npihd);
						if(npihd!=NULL && strlen(npihd)>0)
						{
							//CALLAPI(SA_find_user(ercprim,&user_tag)); 
							CALLAPI(find_user(npihd,&user_tag)); 
							if(user_tag!=NULLTAG)
							{								 
								 add_user_in_project(user_tag,project,"NPI","Head",&member);	 
								  Write_To_Log(" Adding NPI Head \n");		
								 (member_tags)[count] = member;
								 count++;				 
							}
						}

						/***********************************/ 

		 
						if(member_tags!=NULLTAG)
						{
						   Write_To_Log("\nAssigning Team\n");
						//   CALLAPI(PROJ_assign_team(project,count,member_tags,admin_tag,1,auth_tags));	 
						   CALLAPI(PROJ_add_members(project,count,member_tags));
						   AOM_refresh(project,1);
						   save_object(project);
						   AOM_refresh(project,0);

						} 
				}
				if(strcmp(action,"view")==0)
				{
	
						 //Display CFT
					     Write_To_Log("\nView Team\n"); 

						 AOM_refresh(project,0);

						string_array[0] = "";
						string_array[1] = "";
						string_array[2] = "";
						string_array[3] = "";
						string_array[4] = "";
						string_array[5] = "";
						string_array[6] = "";
						string_array[7] = "";
						string_array[8] = "";
						string_array[9] = "";
						string_array[10] = "";
						string_array[11] = "";
						string_array[12] = "";
						string_array[13] = "";
						string_array[14] = "";
						string_array[15] = "";

						if(project != NULLTAG)
						 {

								AOM_ask_value_tag(project,"project_team",&team_tag); 
								if(team_tag != NULLTAG)
							    {								   
									    AOM_refresh(team_tag,0);
										AOM_ask_value_tags(team_tag,"project_members",&num,&mem);
										Write_To_Log("num:%d\n",num);
										for(k=0;k<num;k++)
										{
											 user_name = "";
											 AOM_ask_value_tag(mem[k],"the_group",&group_tag); 				 
											 SA_ask_group_name(group_tag,group_name); 
											 AOM_ask_value_tag(mem[k],"the_role",&role_tag); 
											 SA_ask_role_name(role_tag,role_name); 
											 AOM_ask_value_tag(mem[k],"the_user",&usertag);  
											 //POM_ask_user_name(usertag,&user_name); 
											 AOM_ask_value_string(usertag,"user_name",&user_name); 					  
											 
											 Write_To_Log("\ngroup:%s role:%s user:%s\n",group_name,role_name,user_name);	

											 if(strcmp(group_name,"Marketing")==0)
											 {
											    if(strcmp(role_name,"Primary")==0)
												{
												  Write_To_Log("\nstring_array[0]:%s\n",user_name);	
												   string_array[0]=user_name;
												}
												if(strcmp(role_name,"Secondary")==0)
												{
													Write_To_Log("\nstring_array[1]:%s\n",user_name);
												   string_array[1]=user_name;
												}
												if(strcmp(role_name,"Tertiary")==0)
												{
													Write_To_Log("\nstring_array[2]:%s\n",user_name);
												   string_array[2]=user_name;
												}
											 
											 } 
											 

											 if(strcmp(group_name,"ERC")==0)
											 {
											    if(strcmp(role_name,"Primary")==0)
												{
													Write_To_Log("\nstring_array[3]:%s\n",user_name);	
												    string_array[3]=user_name;
												}
												if(strcmp(role_name,"Secondary")==0)
												{
													Write_To_Log("\nstring_array[4]:%s\n",user_name);	
												    string_array[4]=user_name;
												}
												if(strcmp(role_name,"Tertiary")==0)
												{
												   Write_To_Log("\nstring_array[5]:%s\n",user_name);			
												   string_array[5]=user_name;
												}
											 
											 }

											 if(strcmp(group_name,"VD")==0)
											 {
											    if(strcmp(role_name,"Primary")==0)
												{
													 Write_To_Log("\nstring_array[6]:%s\n",user_name);		
												  string_array[6]=user_name;
												}
												if(strcmp(role_name,"Secondary")==0)
												{
													 Write_To_Log("\nstring_array[7]:%s\n",user_name);		
												  string_array[7]=user_name;
												}
												if(strcmp(role_name,"Tertiary")==0)
												{
													 Write_To_Log("\nstring_array[8]:%s\n",user_name);		
												  string_array[8]=user_name;
												}
											 
											 }

											 if(strcmp(group_name,"TS")==0)
											 {
											    if(strcmp(role_name,"Primary")==0)
												{
													 Write_To_Log("\nstring_array[9]:%s\n",user_name);		
												  string_array[9]=user_name;
												}
												if(strcmp(role_name,"Secondary")==0)
												{
													 Write_To_Log("\nstring_array[10]:%s\n",user_name);		
												  string_array[10]=user_name;
												}
												if(strcmp(role_name,"Tertiary")==0)
												{
													 Write_To_Log("\nstring_array[11]:%s\n",user_name);		
												  string_array[11]=user_name;
												}
											 
											 }

											 if(strcmp(group_name,"Finance")==0)
											 {
											    if(strcmp(role_name,"Primary")==0)
												{
													 Write_To_Log("\nstring_array[12]:%s\n",user_name);		
												  string_array[12]=user_name;
												}
												if(strcmp(role_name,"Secondary")==0)
												{
													 Write_To_Log("\nstring_array[13]:%s\n",user_name);		
												  string_array[13]=user_name;
												}
												if(strcmp(role_name,"Tertiary")==0)
												{
													 Write_To_Log("\nstring_array[14]:%s\n",user_name);		
												  string_array[14]=user_name;
												}
											 
											 }

											 if(strcmp(group_name,"NPI")==0)
											 {
											    if(strcmp(role_name,"Head")==0)
												{
													 Write_To_Log("\nstring_array[15]:%s\n",user_name);		
												  string_array[15]=user_name;
												} 												 
											 
											 }		
											 if(strcmp(group_name,"Project Administration")==0)
											 {
											    
												if(strcmp(role_name,"Project Manager")==0)
												{
													 Write_To_Log("\nstring_array[16]:%s\n",user_name);		
												//  string_array[15]=user_name;
												} 
											 
											 }									 
 
 
											 
											 
											  
										} 
							    }	
						} 

						 
						  Write_To_Log("\nReturn Array\n");	
						  status = USERSERVICE_return_string_array((const char**)string_array, array_size, &array_struct);

						Write_To_Log("\narray_struct.length:%d\n",array_struct.length);	
						if (array_struct.length != 0)
							*((USERSERVICE_array_t*) retValue) = array_struct;

				}
		
		 }
		 else
		 {
			 EMH_store_error_s1(EMH_severity_error,ITK_err,"Project Not Found");	 					 	
			 return ITK_err;
		 
		 }
	 }

	 Write_To_Log("\ncount:%d\n",count);
   
	 
	
	 return status;

}

extern DLLAPI int cft_register_userservices(METHOD_message_t *msg,va_list args)
{

      int nargs=19;
      int *inputArgTypes;
      int retValueType;
      inputArgTypes=(int *)MEM_alloc(nargs * sizeof(int));
      inputArgTypes[0]=USERARG_STRING_TYPE;
	  inputArgTypes[1]=USERARG_STRING_TYPE;

	  inputArgTypes[2]=USERARG_STRING_TYPE;
	  inputArgTypes[3]=USERARG_STRING_TYPE;
	  inputArgTypes[4]=USERARG_STRING_TYPE;

	  inputArgTypes[5]=USERARG_STRING_TYPE;
	  inputArgTypes[6]=USERARG_STRING_TYPE;
	  inputArgTypes[7]=USERARG_STRING_TYPE;

	  inputArgTypes[8]=USERARG_STRING_TYPE;
	  inputArgTypes[9]=USERARG_STRING_TYPE;
	  inputArgTypes[10]=USERARG_STRING_TYPE;

	  inputArgTypes[11]=USERARG_STRING_TYPE;
	  inputArgTypes[12]=USERARG_STRING_TYPE;
	  inputArgTypes[13]=USERARG_STRING_TYPE;

	  inputArgTypes[14]=USERARG_STRING_TYPE;
	  inputArgTypes[15]=USERARG_STRING_TYPE;
	  inputArgTypes[16]=USERARG_STRING_TYPE;

	  inputArgTypes[17]=USERARG_STRING_TYPE;
	  inputArgTypes[18]=USERARG_STRING_TYPE;


      retValueType = USERARG_STRING_TYPE + USERARG_ARRAY_TYPE;

      //retValueType=USERARG_TAG_TYPE;
		
	  Write_To_Log("\n User Service Call assignCFT...........");
      USERSERVICE_register_method("assignCFT",(USER_function_t)proj_assign_cft,nargs,inputArgTypes,retValueType);
      Write_To_Log("\nitk Needs to be called for assignCFT........");

	  MEM_free(inputArgTypes); 

      return ITK_ok;
}




extern DLLAPI int cft_register_callbacks()

{

  CUSTOM_register_exit("cft","USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)cft_register_userservices);

  Write_To_Log("\ncalling cft.dll\n");

  return ITK_ok;

}

 

