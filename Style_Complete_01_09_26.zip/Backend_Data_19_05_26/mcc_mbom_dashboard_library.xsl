<?xml version="1.0" encoding="utf-8"?> 
<xsl:stylesheet version="1.0"  xmlns:xsl="http://www.w3.org/1999/XSL/Transform" > 
<xsl:output method="html"/> 
<xsl:template match="/"> 
<!-- 
*****************************************************************************************************************
Author : Ujjawal Kumar
Date   : August-2024 
Purpose : For MCC Dashboard AWC page.

Change History:
2024-08-01 : Initial Creation by Ujjawal Kumar.

2025-03-19
Modification in NPR section. Added Agreed, Dropped Percentage in Section 6.1
Added DEFENCE Columns in Section 6.3, 6.4

Pls do not copy this code. Copyright@2024.
*****************************************************************************************************************
-->
<html> 
  <head> 
		 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
		
		 <link rel = "stylesheet" href = "//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css"></link>
		 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
					
		<!-- <script type = "text/javascript"      src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>-->
				
		<script type = "text/javascript" src = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
	  
	<style>
	
	body {

    background-color: #F2F3F4;
	color: #636363;
	font-size: 11px;
	font-family: Tahoma, Geneva, sans-serif;
   
	}
	
	  h2   {color: blue;}
	  h6   {
		color: #004465;
		<!-- color: #006699; -->
		font-size: 12px;
		font-family: Tahoma, Geneva, sans-serif;
		font-weight: bold;
	  }
	  
	  h6_NPR   {
		color: #e67e22;
		<!-- color: #006699; -->
		font-size: 12px;
		font-family: Tahoma, Geneva, sans-serif;
		font-weight: bold;
	  }
	  
	  h4 {
	  font-family: Tahoma, Geneva, sans-serif;
	  }
	  
	  p {
		color: #006699;
		font-family: Tahoma, Geneva, sans-serif;
		text-align: center;
		}
	  
	  td {
		  border: 0.25px solid #dddfe1;
		  border-collapse: collapse;
		  color: #636363;
		  font-size: 12px;
		  font-family: Tahoma, Geneva, sans-serif;
		  padding: 3px;
		  text-align: center;
		  <!-- white-space: nowrap; -->	  
	  }
	  
	  th{
		  border: 0.25px solid #dddfe1;
		  background-color: #AED6F1;
		  white-space: nowrap;
		  <!-- color: #636363; -->
		  color: #006699;
		  padding: 3px;
		  text-align: center;
		  font-size: 11px;
		  font-family: Tahoma, Geneva, sans-serif;
		  
		  writing-mode: vertical-rl;
		  transform: scale(-1);
		  <!-- writing-mode: vertical-lr;
		  transform: scale(-1); -->
	  }
	  
	  th_awc{
		  border: 0.25px solid #dddfe1;
		  background-color: #006699;
		  white-space: nowrap;
		  color: white;
		  padding: 3px;
		  text-align: center;
		  font-size: 12px;
		  font-family: Tahoma, Geneva, sans-serif;
		  <!-- writing-mode: vertical-lr;
		  transform: scale(-1); -->
	  }
	  
	  tr:nth-child(even) {
		background-color: #f9fafb;
	  
	  }
	  
	  tr:hover {background-color: #ffff99;}

<!-- 	 .row > div {
		  
		  border: 1px solid grey;
		} -->
		
	.col-md-12 {
		font-size: 16px;
		<!-- font-weight: bold; -->
		background-color: #006699;
		white-space: nowrap;
		color: white;
		text-align: center;
		vertical-align: middle;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	.col-md-6 {
		font-size: 16px;
		font-weight: bold;
		background-color: #006699;
		white-space: nowrap;
		color: white;
		text-align: center;
		vertical-align: middle;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	
	.col-md-1 {
		font-size: 16px;
		font-weight: bold;
		background-color: #EBEDEF;
		white-space: nowrap;
		color: white;
		text-align: center;
		vertical-align: middle;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	
	div.wrap {
	  word-wrap: break-word;
	}
	  
	  
	.label {
	  color: white;
	  padding: 20px;
	}

	.success {background-color: #04AA6D;} /* Green */
	.info {background-color: #2196F3;} /* Blue */
	.warning {background-color: #ff9800;} /* Orange */
	.danger {background-color: #f44336;} /* Red */
	.other {background-color: #e7e7e7; color: black;} /* Gray */
	
.cardInAggGrpPage {
  /* Add shadows to create the "card" effect */
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  background-color: #04AA6D;
  transition: 0.3s;
  font-size: 12px;
  border-radius: 10px; /* 5px rounded corners */
}
		
.card {
  /* Add shadows to create the "card" effect */
<!--   height: 100px;
  width: 300px; -->
  <!-- box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); -->
  transition: 0.3s;
  border-radius: 10px; /* 5px rounded corners */
}

/* On mouse-over, add a deeper shadow */
.card:hover { 
  box-shadow: 0 2px 10px 0 #006699;
}
<!-- .card_container:hover {
  color : #ffff99; 
} -->

/* Add some padding inside the card container */
.card_container {
  padding: 4px 16px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  color: #626567;
  font-size: 11px;
}

/* Add some padding inside the card container */
.card_container_top {
  padding: 40px 16px;
  height: 250px;
  background-color: #154360;
  color: white;
  vertical-align: middle;
  font-size: 11px;
}
	  
	div.wrap {
	  word-wrap: break-word;
	}  	

.label_alert{
  <!-- display: flex;   -->
  <!-- background-color: #dddfe1; -->
  <!-- background-color: #ffff99; -->
  background-color: #f0fbff;
  <!-- background-color: #ffe2a9; -->
  <!-- background-color: white; ffffc5 ffd071-->
  <!-- color: #636363;  -->
  <!-- color: #004465; -->
  color: #641e16;
  <!-- font-weight: bold; -->
  <!-- text-shadow: 0 0 5px #00ff00, 0 0 5px #00ff00, 0 0 5px #00ff00; -->
  padding: 5px;
  margin-bottom: 5px;  
  <!-- font-size: 13px; -->
  border: 1.25px solid #dddfe1;
  <!-- font-weight: bold; -->
  <!-- box-shadow: 0 0 5px 0 #006699; -->
}

/* On mouse-over, add a deeper shadow */
.label_alert:hover { 
  background-color: #ffff99;
  <!-- font-weight: bold; -->
  box-shadow: 0 0 3px 0 #006699;
}

.label_NPR{
  display: flex;  
  <!-- background-color: #fffcbf; -->
  <!-- background-color: #dddfe1; -->
  <!-- background-color: #f5cba7; -->
  <!-- background-color: #1a5276; -->
    background-color: #fad7a0;
  <!-- background-color: #005078; -->
  <!-- background-color: #fcf3cf; -->
  
  <!-- color: #ffff99;   -->
  color: #7e5109;  
  <!-- color: #fffcbf;   -->
  font-size: 12px;
  font-weight: bold;
  padding: 2px;
  <!-- border: 0.25px solid #abb2b9; -->

  font-family: Tahoma, Geneva, sans-serif;
  
  <!-- font-weight: bold; -->
}

.label_MCC{
  display: flex;  
  <!-- background-color: #fffcbf; -->
  <!-- background-color: #dddfe1; -->
  background-color: #006699;
  <!-- background-color: white; -->
  <!-- background-color: #005078; -->
  <!-- background-color: #fcf3cf; -->
  
  <!-- color: #636363;  -->
  color: white;   
  <!-- color: #004465;   -->
  <!-- color: #fffcbf;   -->
  font-size: 12px;
  font-weight: bold;
  padding: 2px;
  <!-- border: 0.25px solid #abb2b9; -->

  font-family: Tahoma, Geneva, sans-serif;
  
  <!-- font-weight: bold; -->
}

.label1{
  display: flex;  
  <!-- background-color: #fffcbf; -->
  <!-- background-color: #dddfe1; -->
  background-color: #004465;
  <!-- background-color: white; -->
  <!-- background-color: #005078; -->
  <!-- background-color: #fcf3cf; -->
  
  color: #f0fbff;  
  <!-- color: #004465;   -->
  <!-- color: #fffcbf;   -->
  font-size: 13px;
  font-weight: bold;
  padding: 10px;
  border: 1.25px solid #abb2b9;
  <!-- font-weight: bold; -->
}

.label2{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: center;
  align-content: space-evenly;
  background-color: #006699;
  color: white;
  font-weight: bold;
  padding: 5px;
  margin-top: 2px;
  <!-- font-weight: bold; -->
}

.label_info{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: left;
  align-content: space-evenly;
  <!-- background-color: #f0fbff; -->
  <!-- background-color: #AED6F1;   -->
  <!-- background-color: #f0fbff;   -->
  background-color: #f0fbff;  
  <!-- color: #006699; -->
  color: #004465;  
  <!-- font-weight: bold; -->
  padding: 5px;
  margin-bottom: 5px;
  border: 1.25px solid #dddfe1;
  <!-- font-weight: bold; -->
}

.label_info:hover { 
  background-color: #ffff99;
  <!-- font-weight: bold; -->
  box-shadow: 0 0 3px 0 #006699;
}

.label_info_header{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: left;
  align-content: space-evenly;
  <!-- background-color: #f0fbff; -->
  background-color: #ffff99;  
  <!-- background-color: #ffff99;   -->
  <!-- color: #006699; -->
  color: #641e16;
  <!-- font-weight: bold; -->
  padding: 5px;
  margin-bottom: 5px;
  border: 1.25px solid #f9e79f;
  <!-- font-weight: bold; -->
}

.grid-container {
  display: grid;
  grid-template-columns: auto auto auto auto;
  gap: 10px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  padding: 5px;
  border: 1.25px solid #dddfe1;
  
}

.grid-container > div {
  <!-- background-color: rgba(255, 255, 255, 0.8); -->
  <!-- text-align: center; -->
  padding: 5px 5px;
  font-size: 11px;
  border: 1.25px solid #006699;
  border-radius: 5px;    

 }
 
 .grid-container > div:hover { 
  box-shadow: 0 2px 10px 0 #006699;
}

.grid-container-2 {
  display: grid;
  grid-template-columns: auto auto auto auto auto auto auto;
  gap: 5px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  padding: 5px;
   border: 1.25px solid #dddfe1;
  
}

.grid_sm_usage_freq {
  display: grid;
  grid-template-columns: 200px auto;
  gap: 5px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  padding: 5px;
   border: 1.25px solid #dddfe1;
  
}

.grid-container-2 > div {
  <!-- background-color: white; -->
  <!-- text-align: center; -->
  padding: 10px 10px;
  <!-- font-size: 11px; -->
  border: 2.25px solid #dddfe1;
  border-radius: 5px;
  <!-- border-radius: 10px;     -->

 }
 
 .grid-container-2 > div:hover { 
  box-shadow: 0 2px 10px 0 #006699;
}

.item1 {
  grid-row-start: 1;
  grid-row-end: 3;
  align-content: space-evenly; 
  background-color: #AED6F1;
  <!-- color: white;   -->
}

.item2 {
  grid-row-start: 1;
  grid-row-end: 3;
  align-content: space-evenly;
  background-color: #f9e79f;
  <!-- color: white;   -->
}
.itemg2cell {
  align-content: space-evenly;
  background-color: #fff8de;  
}

.itemg2cell_lb {
  align-content: space-evenly;
  background-color: #e0f3ff;  
}

.item21 { 
  text-align: center;
  align-content: space-evenly;
  background-color: #006699;
  color: white;
  font-size: 14px;  
}

.itemUF1 { 
  text-align: center;
  align-content: space-evenly;
  background-color: #006699;
  color: white; 
  vertical-align: middle;
  border-radius: 50px;  
}

.itemg1_1 { 
  text-align: left;
  background-color: #F2F3F4;
  <!-- color: white;   -->
}

.item27{
  text-align: center;
  background-color: #f0fbff;
  font-size: 12px;
  font-weight: bold;
  border: 0.25px solid #dddfe1;
  align-content: space-evenly;
}

</style>
	
	
	
<script>

	$(document).ready(function(){
	 <!--  $("#linebtn").click(function(){
		$("#myChart1").toggle();
	  });
	  $("#barbtn").click(function(){
		$("#myChart2").toggle();
	  }); -->


	$("#myInput1AT").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableALTROZTrend tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1HT").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableHARRIERTrend tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
		  
	$("#myInput1AR").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableAPPENGGReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1HR").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableCHASSISReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1PR").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableCABReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1SR").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableEEReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1AT").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTablePOWERTRAINReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1HT").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableVEHICLEReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });

	$("#tabs").tabs();	  
	  
	});
	
	
	


	
	</script>	
</head> 

<body> 
    <!--<canvas id="myChart" style="width:100%;max-width:600px"></canvas> -->

<div class="container">	
	
	<!-- <div id = "tabs"> -->
			<!-- <ul>
				<li><a href = "#tabs-1"><font size="2px">MCC<br></br><b>Main DASHBOARD</b></font></a></li>
				<li><a href = "#tabs-2"><font size="2px">MCC Dashboard<br></br>Vehicle Compliance Reports</font></a></li> -->
				<!-- <li><a href = "#tabs-8">Report<br></br>PUNCH</a></li> -->
				<!-- <li><a href = "#tabs-9">Report<br></br>SAFARI</a></li> -->
	<!--        <li><a href = "#tabs-3">NA Module Count(Bar Chart)</a></li>
				<li><a href = "#tabs-4">Trend Report</a></li> -->
			<!-- </ul> -->

		<!-- tabs-1 Dashboard. -->	
		
		

		<div id = "tabs-1">	

			<div class="row m-3"> 
				<div class="col-sm-12">
					<center><h5><b>MBOM - Modularity and Configuration Cell (MCC)</b><br></br>DASHBOARD</h5></center>
				</div>
			</div>
			
			
			
			<div class="label_info_header" style="font-size: 12px; text-align: center">
			<!-- As per data last updated on date : 10 Oct, 2024 (Thursday) @ 22:35 hrs. -->
			
				<xsl:for-each select="MCCMainDashboardRpt/DataRefreshDate">						
					Below Dashboard data is as per last updated on date : <xsl:value-of select="LastDate"/>							
				</xsl:for-each>		
			
			</div>
			
			
			<!-- <div class="label_alert" style="font-size: 12px; text-align: right">As per data last updated on date : 10 Oct, 2024 (Thursday) @ 22:35 hrs.</div> -->
			
			
			<!-- <div class="alert alert-warning p-1" style="font-size: 12px; text-align: right">As per data last updated on date : 10 Oct, 2024 (Thursday) @ 22:35 hrs.</div> -->
						
				
			<div class="label1">
			[Section 1] Vehicle and Submodules Count:
			</div>
			
			<div class="label_alert" style="font-size: 12px; text-align: right">
			<!-- As per data last updated on date : 10 Oct, 2024 (Thursday) @ 22:35 hrs. -->
			
				<xsl:for-each select="MCCMainDashboardRpt/DataRefreshDate">						
					As per data last updated on date : <xsl:value-of select="LastDate"/>							
				</xsl:for-each>	
				
			</div>
			
			<h6>Product-Line wise count of Released Vehicles and Submodules:</h6>
			<div class="grid-container-2">
			  <div class="item21">
			  <!-- <br></br><br></br><br></br><br></br>		 -->
				PRODUCT LINE:
			  
			  </div>
			  <div class="item21">
									<b>HCV</b>
									
			  </div>
			  <div class="item21">
									<b>ILMCV</b>
						
				
			  </div>  
			  <div class="item21">
					<b>SCV</b>
					
			  </div>
			  <div class="item21">
					<b>CV PASS<br></br>(BUS)</b>
					
			  </div>
			  <div class="item21">
					<b>DEFENCE</b>
					
			  </div>
			  <div class="item21">
					<b>TOTAL<br></br>CV</b>
						
			  </div>
			  
			  
				<div class="item21">Count of Released VEHICLES:</div>
				 
				<xsl:for-each select="MCCMainDashboardRpt/DataSheet1">
					
					<div class="item27"><xsl:value-of select="DS1HCVData"/><br></br>Vehicles</div>
					<div class="item27"><xsl:value-of select="DS1ILMCVData"/><br></br>Vehicles</div>
					<div class="item27"><xsl:value-of select="DS1SCVData"/><br></br>Vehicles</div>
					<div class="item27"><xsl:value-of select="DS1PASSData"/><br></br>Vehicles</div>
					<div class="item27"><xsl:value-of select="DS1DEFENCEData"/><br></br>Vehicles</div>
					<div class="item21"><xsl:value-of select="DS1CVData"/><br></br>Vehicles</div>		  
						
				</xsl:for-each>	

					  
				<div class="item21">Count of Released SUBMODULES:</div>
				
				<xsl:for-each select="MCCMainDashboardRpt/DataSheet2">
					
					<div class="item27"><xsl:value-of select="DS2HCVData"/><br></br>Submodules</div>
					<div class="item27"><xsl:value-of select="DS2ILMCVData"/><br></br>Submodules</div>
					<div class="item27"><xsl:value-of select="DS2SCVData"/><br></br>Submodules</div>
					<div class="item27"><xsl:value-of select="DS2PASSData"/><br></br>Submodules</div>
					<div class="item27"><xsl:value-of select="DS2DEFENCEData"/><br></br>Submodules</div>
					<div class="item21"><xsl:value-of select="DS2CVData"/><br></br>Submodules</div>		  
						
				</xsl:for-each>	
				
			</div>	
			
			<div class="label_info">
			1. Above section shows Product-Line wise, number of released Vehicles and Submodules attached to VCs in PLM.<br></br>
			2. VCs released in modular BOM in RDE, IB, EV, Defence and POC have been considered.<br></br>
			3. Submodule variety of Internal engine submodules, software calibration, IFD and CP modules have not been considered.<br></br>
			4. Count of Module Addresses excluded in MBOM MCC Library (As per TS11820): <b>12</b>
			</div>
			
			
			<br></br>
			<div class="label1">
			[Section 2] MBOM MCC Submodules Library Details (Aggregate-Group wise):
			</div>
			<div class="label_alert" style="font-size: 12px; text-align: right">
			<!-- As per data last updated on date : 10 Oct, 2024 (Thursday) @ 22:35 hrs. -->
				<xsl:for-each select="MCCMainDashboardRpt/DataRefreshDate">						
					As per data last updated on date : <xsl:value-of select="LastDate"/>							
				</xsl:for-each>	
			</div>
				

			 <br></br>
			 <div class="label_MCC">[Section 2.1] : VEHICLE-Linked only Submodules Details in MBOM MCC-Library:</div>
			 <div class="grid-container mt-2">
			  <div class="item2">
			  <!-- <br></br><br></br><br></br><br></br>		 -->
				<h6>Vehicle-Linked SubModules Only<br></br><br></br>CVBU ENGINEERING</h6>
				<br></br>	
				<xsl:for-each select="MCCMainDashboardRpt/LinkSubmoduleVariety">
					<xsl:if test="LinkAggregateGrpName = 'CVBU'">
		
						<!-- Aggregate Groups : <h8><b><xsl:value-of select="AggregateGrpVar"/></b></h8><br></br>	 -->
						<!-- | Aggregates : <h8><b><xsl:value-of select="AggregateVar"/></b></h8> -->
						Total Modules : <h8><b><xsl:value-of select="LinkModuleVar"/></b></h8><br></br>	
						Total Submodule Address(es) : <h8><b><xsl:value-of select="LinkSubModuleVar"/></b></h8><br></br>		
						Total Submodule Variety Count : <h8><b><xsl:value-of select="LinkDetailsVar"/></b></h8>
						<br></br>
					
					</xsl:if>
				</xsl:for-each>				  
			  </div>
			  <div class="itemg2cell">
													<h6>APP ENGINEERING</h6>
									
									<xsl:for-each select="MCCMainDashboardRpt/LinkSubmoduleVariety">
									<xsl:if test="LinkAggregateGrpName = 'APPLICATION ENGINEERING'">							
									
										<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
										Modules : <h8><b><xsl:value-of select="LinkModuleVar"/></b></h8><br></br>
										Submodule Address : <h8><b><xsl:value-of select="LinkSubModuleVar"/></b></h8><br></br>	
										Submodule Variety Count : <h8><b><xsl:value-of select="LinkDetailsVar"/></b></h8>																		
									 </xsl:if>
									</xsl:for-each>	
			  </div>
			  <div class="itemg2cell">
														<h6>CHASSIS</h6>
					
					<xsl:for-each select="MCCMainDashboardRpt/LinkSubmoduleVariety">
					<xsl:if test="LinkAggregateGrpName = 'CHASSIS'">
								
						<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
						Modules : <h8><b><xsl:value-of select="LinkModuleVar"/></b></h8><br></br>
						Submodule Address(es) : <h8><b><xsl:value-of select="LinkSubModuleVar"/></b></h8><br></br>	
						Submodule Variety Count : <h8><b><xsl:value-of select="LinkDetailsVar"/></b></h8>
											
					 </xsl:if>
					</xsl:for-each>	
				
			  </div>  
			  <div class="itemg2cell">
					<h6>CAB</h6>
					
					<xsl:for-each select="MCCMainDashboardRpt/LinkSubmoduleVariety">
					<xsl:if test="LinkAggregateGrpName = 'CAB'">
								
						<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
						Modules : <h8><b><xsl:value-of select="LinkModuleVar"/></b></h8><br></br>
						Submodule Address(es) : <h8><b><xsl:value-of select="LinkSubModuleVar"/></b></h8><br></br>	
						Submodule Variety Count : <h8><b><xsl:value-of select="LinkDetailsVar"/></b></h8>
											
					 </xsl:if>
					</xsl:for-each>	
			  </div>
			  <div class="itemg2cell">
					<h6>EE</h6>
					
					<xsl:for-each select="MCCMainDashboardRpt/LinkSubmoduleVariety">
					<xsl:if test="LinkAggregateGrpName = 'EandE'">
								
						<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
						Modules : <h8><b><xsl:value-of select="LinkModuleVar"/></b></h8><br></br>
						Submodule Address(es) : <h8><b><xsl:value-of select="LinkSubModuleVar"/></b></h8><br></br>	
						Submodule Variety Count : <h8><b><xsl:value-of select="LinkDetailsVar"/></b></h8>
										
					</xsl:if>
					</xsl:for-each>	
			  </div>
			  <div class="itemg2cell">
					<h6>POWERTRAIN</h6>
					
					<xsl:for-each select="MCCMainDashboardRpt/LinkSubmoduleVariety">
					<xsl:if test="LinkAggregateGrpName = 'POWERTRAIN'">
								
						<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
						Modules : <h8><b><xsl:value-of select="LinkModuleVar"/></b></h8><br></br>
						Submodule Address(es) : <h8><b><xsl:value-of select="LinkSubModuleVar"/></b></h8><br></br>	
						Submodule Variety Count : <h8><b><xsl:value-of select="LinkDetailsVar"/></b></h8>
											
					</xsl:if>
					</xsl:for-each>	
			  </div>
			  <div class="itemg2cell">
					<h6>VEHICLE</h6>
					
					<xsl:for-each select="MCCMainDashboardRpt/LinkSubmoduleVariety">
					<xsl:if test="LinkAggregateGrpName = 'VEHICLE'">
								
						<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
						Modules : <h8><b><xsl:value-of select="LinkModuleVar"/></b></h8><br></br>
						Submodule Address(es) : <h8><b><xsl:value-of select="LinkSubModuleVar"/></b></h8><br></br>	
						Submodule Variety Count : <h8><b><xsl:value-of select="LinkDetailsVar"/></b></h8>
										
					</xsl:if>
					</xsl:for-each>	
			  </div>
			</div>
			
			<div class="label_info">
			1. This section shows Aggregate-Group wise data of Submodules as maintained in MBOM MCC Submodule Library.<br></br>
			2. It also shows the Variety count of Submodules as per MBOM MCC Submodule Library.<br></br>
			3. Count of Module Addresses excluded in MBOM MCC Library (As per TS11820): <b>12</b>
			</div>
							
			<div class="label_MCC">[Section 2.2] : ALL Submodules Details in MBOM MCC-Library:</div>
			<div class="grid-container">
			  <div class="item1">
			  <!-- <br></br><br></br><br></br><br></br>		 -->
				<h6>ALL Submodules<br></br><br></br>CVBU ENGINEERING</h6>
				<br></br>	
				<xsl:for-each select="MCCMainDashboardRpt/SubmoduleVariety">
					<xsl:if test="AggregateGrpName = 'CVBU'">
		
						<!-- Aggregate Groups : <h8><b><xsl:value-of select="AggregateGrpVar"/></b></h8><br></br>	 -->
						<!-- | Aggregates : <h8><b><xsl:value-of select="AggregateVar"/></b></h8> -->
						Total Modules : <h8><b><xsl:value-of select="ModuleVar"/></b></h8><br></br>	
						Total Submodule Address(es) : <h8><b><xsl:value-of select="SubModuleVar"/></b></h8><br></br>		
						Total Submodule Variety Count : <h8><b><xsl:value-of select="DetailsVar"/></b></h8>
						<br></br>
					
					</xsl:if>
				</xsl:for-each>				  
			  </div>
			  <div class="itemg2cell_lb">
									<h6>APP ENGINEERING [A]</h6>
									
									<xsl:for-each select="MCCMainDashboardRpt/SubmoduleVariety">
									<xsl:if test="AggregateGrpName = 'APPLICATION ENGINEERING'">							
									
										<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
										Modules : <h8><b><xsl:value-of select="ModuleVar"/></b></h8><br></br>
										Submodule Address : <h8><b><xsl:value-of select="SubModuleVar"/></b></h8><br></br>	
										Submodule Variety Count : <h8><b><xsl:value-of select="DetailsVar"/></b></h8>																		
									 </xsl:if>
									</xsl:for-each>	
			  </div>
			  <div class="itemg2cell_lb">
									<h6>CHASSIS [F]</h6>
					
					<xsl:for-each select="MCCMainDashboardRpt/SubmoduleVariety">
					<xsl:if test="AggregateGrpName = 'CHASSIS'">
								
						<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
						Modules : <h8><b><xsl:value-of select="ModuleVar"/></b></h8><br></br>
						Submodule Address(es) : <h8><b><xsl:value-of select="SubModuleVar"/></b></h8><br></br>	
						Submodule Variety Count : <h8><b><xsl:value-of select="DetailsVar"/></b></h8>
											
					 </xsl:if>
					</xsl:for-each>	
				
			  </div>  
			  <div class="itemg2cell_lb">
					<h6>CAB [D]</h6>
					
					<xsl:for-each select="MCCMainDashboardRpt/SubmoduleVariety">
					<xsl:if test="AggregateGrpName = 'CAB'">
								
						<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
						Modules : <h8><b><xsl:value-of select="ModuleVar"/></b></h8><br></br>
						Submodule Address(es) : <h8><b><xsl:value-of select="SubModuleVar"/></b></h8><br></br>	
						Submodule Variety Count : <h8><b><xsl:value-of select="DetailsVar"/></b></h8>
											
					 </xsl:if>
					</xsl:for-each>	
			  </div>
			  <div class="itemg2cell_lb">
					<h6>EE [G]</h6>
					
					<xsl:for-each select="MCCMainDashboardRpt/SubmoduleVariety">
					<xsl:if test="AggregateGrpName = 'EandE'">
								
						<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
						Modules : <h8><b><xsl:value-of select="ModuleVar"/></b></h8><br></br>
						Submodule Address(es) : <h8><b><xsl:value-of select="SubModuleVar"/></b></h8><br></br>	
						Submodule Variety Count : <h8><b><xsl:value-of select="DetailsVar"/></b></h8>
										
					</xsl:if>
					</xsl:for-each>	
			  </div>
			  <div class="itemg2cell_lb">
					<h6>POWERTRAIN [H]</h6>
					
					<xsl:for-each select="MCCMainDashboardRpt/SubmoduleVariety">
					<xsl:if test="AggregateGrpName = 'POWERTRAIN'">
								
						<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
						Modules : <h8><b><xsl:value-of select="ModuleVar"/></b></h8><br></br>
						Submodule Address(es) : <h8><b><xsl:value-of select="SubModuleVar"/></b></h8><br></br>	
						Submodule Variety Count : <h8><b><xsl:value-of select="DetailsVar"/></b></h8>
											
					</xsl:if>
					</xsl:for-each>	
			  </div>
			  <div class="itemg2cell_lb">
					<h6>VEHICLE [K]</h6>
					
					<xsl:for-each select="MCCMainDashboardRpt/SubmoduleVariety">
					<xsl:if test="AggregateGrpName = 'VEHICLE'">
								
						<!-- Aggregate Variety : <h8><b><xsl:value-of select="AggregateVar"/></b></h8><br></br> -->
						Modules : <h8><b><xsl:value-of select="ModuleVar"/></b></h8><br></br>
						Submodule Address(es) : <h8><b><xsl:value-of select="SubModuleVar"/></b></h8><br></br>	
						Submodule Variety Count : <h8><b><xsl:value-of select="DetailsVar"/></b></h8>
										
					</xsl:if>
					</xsl:for-each>	
			  </div>
			</div>
			
			<div class="label_info">
			1. This section shows Aggregate-Group wise data of Submodules as maintained in MBOM MCC Submodule Library.<br></br>
			2. It also shows the Variety count of Submodules as per MBOM MCC Submodule Library.<br></br>
			3. Count of Module Addresses excluded in MBOM MCC Library (As per TS11820): <b>12</b>			
			</div>
			
			<br></br>
			
			<div class="label1">
			[Section 3] : Baseline of Vehicles, Submodules and Ratios (Week-Wise):
			</div>
			
			<div class="label_alert" style="font-size: 12px; text-align: right">
			<!-- As per data last updated on date : 10 Oct, 2024 (Thursday) @ 22:35 hrs. -->
			
				<xsl:for-each select="MCCMainDashboardRpt/DataRefreshDate">						
					As per data last updated on date : <xsl:value-of select="LastDate"/>							
				</xsl:for-each>	
				
			</div>
			
			
						<!-- <br></br> -->
						<table width="100%">
							
							<tr bgcolor="#006699">	
								<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
								<td bgcolor="#006699" style="width: 80px;">
								<font color="white">
									Time-Span
									</font>
								</td>
							  
								<td bgcolor="#006699" style="width: 80px;">	
								<font color="white">							  
									<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
										<b><xsl:value-of select="DS3Col1Det"/></b>
									</xsl:for-each>									
								</font>
								</td>			  
						
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
										<b><xsl:value-of select="DS3Col9Det"/></b>
									</xsl:for-each>	
									</font>
								</td>	
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
										<b><xsl:value-of select="DS3Col8Det"/></b>
									</xsl:for-each>	
									</font>
								</td>					
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
										<b><xsl:value-of select="DS3Col7Det"/></b>
									</xsl:for-each>	
									</font>
								</td>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
										<b><xsl:value-of select="DS3Col6Det"/></b>
									</xsl:for-each>	
									</font>
								</td>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
										<b><xsl:value-of select="DS3Col5Det"/></b>
									</xsl:for-each>	
									</font>
								</td>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
										<b><xsl:value-of select="DS3Col4Det"/></b>
									</xsl:for-each>	
									</font>
								</td>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
										<b><xsl:value-of select="DS3Col3Det"/></b>
									</xsl:for-each>	
									</font>
								</td>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
										<b><xsl:value-of select="DS3Col2Det"/></b>
									</xsl:for-each>	
									</font>
								</td>						  						  
							</tr>
							
						
																	
									<tr>								   								    
									   <th rowspan="6">VEHICLES<br></br>(VEHs)</th>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td>
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
												<xsl:value-of select="VDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
												<xsl:value-of select="VDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
												<xsl:value-of select="VDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
												<xsl:value-of select="VDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
												<xsl:value-of select="VDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
												<xsl:value-of select="VDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
												<xsl:value-of select="VDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
												<xsl:value-of select="VDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   			
									</tr>
									
									
									
									<tr>								   								    
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3ILMCV"/></b>
											</xsl:for-each>	
										</td>
										
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
												<xsl:value-of select="VDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
												<xsl:value-of select="VDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   								   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
												<xsl:value-of select="VDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
												<xsl:value-of select="VDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
												<xsl:value-of select="VDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
												<xsl:value-of select="VDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   							   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
												<xsl:value-of select="VDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
												<xsl:value-of select="VDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   									   
									</tr>
									
									
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3SCV"/></b>
											</xsl:for-each>	
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
												<xsl:value-of select="VDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
												<xsl:value-of select="VDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   								   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
												<xsl:value-of select="VDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
												<xsl:value-of select="VDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
												<xsl:value-of select="VDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
												<xsl:value-of select="VDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
												<xsl:value-of select="VDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
												<xsl:value-of select="VDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   									   
									</tr>
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3PASS"/></b>
											</xsl:for-each>	
										</td>
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="VDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="VDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   								   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="VDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="VDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="VDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="VDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   								   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="VDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="VDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   									   
									</tr>
									
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3DEFENCE"/></b>
											</xsl:for-each>	
										</td>
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="VDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="VDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   								   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="VDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="VDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="VDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="VDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   								   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="VDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="VDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   									   
									</tr>
									
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3CV"/></b>
											</xsl:for-each>	
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<font color="#006699"><b><xsl:value-of select="VDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<font color="#006699"><b><xsl:value-of select="VDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<b><xsl:value-of select="VDS3CVData"/></b>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<font color="#006699"><b><xsl:value-of select="VDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<font color="#006699"><b><xsl:value-of select="VDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<font color="#006699"><b><xsl:value-of select="VDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   								   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<font color="#006699"><b><xsl:value-of select="VDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<font color="#006699"><b><xsl:value-of select="VDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   								   
									</tr>

									<tr>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>									   
									</tr>


									
									<tr>	
									   <th rowspan="6">SUBMODULES<br></br>(SMs)</th>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="SDS3HCV"/></b>
											</xsl:for-each>	
										</td>
										
									   	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="SDS3HCVData"/>
											</xsl:for-each>	
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="SDS3HCVData"/>
											</xsl:for-each>	
										</td>
																				
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="SDS3HCVData"/>
											</xsl:for-each>	
										</td>
																				
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="SDS3HCVData"/>
											</xsl:for-each>	
										</td>
																				
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="SDS3HCVData"/>
											</xsl:for-each>	
										</td>
																				
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="SDS3HCVData"/>
											</xsl:for-each>	
										</td>
																				
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="SDS3HCVData"/>
											</xsl:for-each>	
										</td>
																				
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="SDS3HCVData"/>
											</xsl:for-each>	
										</td>						   
							
									</tr>
									
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="SDS3ILMCV"/></b>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="SDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="SDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="SDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="SDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="SDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="SDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="SDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="SDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   									   								   
									</tr>
									
									
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="SDS3SCV"/></b>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="SDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="SDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="SDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="SDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="SDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="SDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="SDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="SDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									</tr>
									<tr>								   								    
									   

										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="SDS3PASS"/></b>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="SDS3PASSData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="SDS3PASSData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="SDS3PASSData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="SDS3PASSData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="SDS3PASSData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="SDS3PASSData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="SDS3PASSData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="SDS3PASSData"/>
											</xsl:for-each>	
										</td>
																	   
									</tr>
									
									<!-- Added on 27-FEB-2025 -->
									
									<tr>								   								    
									   

										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="SDS3DEFENCE"/></b>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="SDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="SDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="SDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="SDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="SDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="SDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="SDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="SDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
																	   
									</tr>
									
									
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="SDS3CV"/></b>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<font color="#006699"><b><xsl:value-of select="SDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<font color="#006699"><b><xsl:value-of select="SDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<font color="#006699"><b><xsl:value-of select="SDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<font color="#006699"><b><xsl:value-of select="SDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<font color="#006699"><b><xsl:value-of select="SDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<font color="#006699"><b><xsl:value-of select="SDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<b><xsl:value-of select="SDS3CVData"/></b>
											</xsl:for-each>	
										</td>
										
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<font color="#006699"><b><xsl:value-of select="SDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									  								  									   
									</tr>

									<tr>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>										   
									</tr>

									
									
									
									<tr>								   								    
									   
									   <th rowspan="6">Ratio<br></br>(VEHs/SMs)</th>
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="RDS3HCV"/></b>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="RDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="RDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="RDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="RDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="RDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="RDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="RDS3HCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="RDS3HCVData"/>
											</xsl:for-each>	
										</td>
							
									</tr>
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="RDS3ILMCV"/></b>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="RDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="RDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="RDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="RDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="RDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="RDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="RDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="RDS3ILMCVData"/>
											</xsl:for-each>	
										</td>
																	   
									</tr>
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="RDS3SCV"/></b>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="RDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="RDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="RDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="RDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="RDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="RDS3SCVData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="RDS3SCVData"/>
											</xsl:for-each>	
										</td>										
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="RDS3SCVData"/>
											</xsl:for-each>	
										</td>									   
																	   
									</tr>
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="RDS3PASS"/></b>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="RDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="RDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="RDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="RDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="RDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="RDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="RDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="RDS3PASSData"/>
											</xsl:for-each>	
										</td>
									   								   
									</tr>
									
									<!-- Added on 27-FEB-2025 -->
									
									<tr>							   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="RDS3DEFENCE"/></b>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<xsl:value-of select="RDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<xsl:value-of select="RDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<xsl:value-of select="RDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<xsl:value-of select="RDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<xsl:value-of select="RDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<xsl:value-of select="RDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<xsl:value-of select="RDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<xsl:value-of select="RDS3DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   								   
									</tr>
									
									
									<tr>								   								    
									   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="RDS3CV"/></b>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col9">
											<font color="#006699"><b><xsl:value-of select="RDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col8">
											<font color="#006699"><b><xsl:value-of select="RDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col7">
											<font color="#006699"><b><xsl:value-of select="RDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col6">
											<font color="#006699"><b><xsl:value-of select="RDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col5">
											<font color="#006699"><b><xsl:value-of select="RDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col4">
											<font color="#006699"><b><xsl:value-of select="RDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col3">
											<font color="#006699"><b><xsl:value-of select="RDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
									   
									    <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col2">
											<font color="#006699"><b><xsl:value-of select="RDS3CVData"/></b></font>
											</xsl:for-each>	
										</td>
										
									</tr>									
									
									<tr>								   								    
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>										   							   
									</tr>

							
									
						</table>
						
						
			<div class="label_info">
			This section shows table with Product-Line wise data of released Vehicles and Submodules week-wise.
			</div>
						
	<br></br>				
						
			<div class="label1">
			[Section 4] Baseline of Vehicles, Submodules and Ratios (Month-Wise):
			</div>
			
			<div class="label_alert" style="font-size: 12px; text-align: right">
			<!-- As per data last updated on date : 10 Oct, 2024 (Thursday) @ 22:35 hrs. -->
			
				<xsl:for-each select="MCCMainDashboardRpt/DataRefreshDate">						
					As per data last updated on date : <xsl:value-of select="LastDate"/>							
				</xsl:for-each>	
				
			</div>
			
			
						<!-- <br></br> -->
						<table width="100%">
						
						 						
							<tr bgcolor="#006699">							 
								
								<td bgcolor="#006699" style="width: 80px;">
								<font color="white">
									Time-Span
								</font>
								</td>
							  
								<td bgcolor="#006699" style="width: 80px;">
								<font color="white">															
									<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
										<b><xsl:value-of select="DS4Col1Det"/></b>
									</xsl:for-each>									
								</font>
								</td>
			  
						
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
											<b><xsl:value-of select="DS4Col13Det"/></b>
										</xsl:for-each>	
									</font>
								</td>	
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
											<b><xsl:value-of select="DS4Col12Det"/></b>
										</xsl:for-each>	
									</font>
								</td>					
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
											<b><xsl:value-of select="DS4Col11Det"/></b>
										</xsl:for-each>	
									</font>
								</td> 
								<th>
									<b>FY 24-25<br></br></b>
									<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
											<b><xsl:value-of select="DS4Col11Det"/></b>
									</xsl:for-each>	
								</th>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
											<b><xsl:value-of select="DS4Col10Det"/></b>
										</xsl:for-each>	
									</font>
								</td>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
											<b><xsl:value-of select="DS4Col9Det"/></b>
										</xsl:for-each>	
									</font>
								</td>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
											<b><xsl:value-of select="DS4Col8Det"/></b>
										</xsl:for-each>	
									</font>
								</td>
								<th>
									<b>FY 24-25<br></br></b>
									<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
											<b><xsl:value-of select="DS4Col8Det"/></b>
									</xsl:for-each>	
								</th>								
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
											<b><xsl:value-of select="DS4Col7Det"/></b>
										</xsl:for-each>	
									</font>
								</td>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
											<b><xsl:value-of select="DS4Col6Det"/></b>
										</xsl:for-each>	
									</font>
								</td>	
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
											<b><xsl:value-of select="DS4Col5Det"/></b>
										</xsl:for-each>	
									</font>
								</td>
								<th>
									<b>FY 24-25<br></br></b>
									<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
											<b><xsl:value-of select="DS4Col5Det"/></b>
									</xsl:for-each>	
								</th>							
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
											<b><xsl:value-of select="DS4Col4Det"/></b>
										</xsl:for-each>	
									</font>
								</td>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
											<b><xsl:value-of select="DS4Col3Det"/></b>
										</xsl:for-each>	
									</font>
								</td>
								<td bgcolor="#006699" align="center">
									<font color="white">
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
											<b><xsl:value-of select="DS4Col2Det"/></b>
										</xsl:for-each>	
									</font>
								</td>
								<th>
									<b>FY 24-25<br></br></b>
									<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
											<b><xsl:value-of select="DS4Col2Det"/></b>
									</xsl:for-each>	
								</th>
								 
							</tr>
							
						
									<!-- VEHICLES (VEHs) HCV Row -->
									<tr>								   								    
									   <th rowspan="6">VEHICLES<br></br>(VEHs)</th>
									   
									   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4HCV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
									   			
									</tr>
																		
									<!-- VEHICLES (VEHs) ILMCV Row -->
									
									<tr>	
										
									<!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4ILMCV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
									   			
									</tr>
									
									<!-- VEHICLES (VEHs) SCV Row -->
									<tr>								   								    
									   
									   
									   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4SCV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4SCVData"/>
											</xsl:for-each>	
										</font></td>
									   									   									   
									</tr>
									
									<!-- VEHICLES (VEHs) CV PASS Row -->
									
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4PASS"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
									   
									   
									   									   									   
									</tr>
									
									
									<!-- Added on 27-FEB-2025 -->
									<!-- VEHICLES (VEHs) FOR DEFENCE PLATFORM. -->
									
									
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4DEFENCE"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>  
									   									   									   
									</tr>	
									
																		
									<!-- VEHICLES (VEHs) TOTAL CV Row -->
									<tr>								   								    
									   
									   	<!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4CV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="VDS4CVData"/>
											</xsl:for-each>	
										</font></td>

									   								   
									</tr>

									<!-- DIVIDER after VEHICLES (VEHs) -->
									<tr>
									
									
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>		
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
										<td bgcolor="#006699"></td>	
									   <!-- <th></th> -->									   
									</tr>

									<!-- SUBMODULES (SMs) HCV Row -->
									<tr>	
									   <th rowspan="6">SUBMODULES<br></br>(SMs)</th>
									   
									   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="SDS4HCV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
										
							
									</tr>
									
									<!-- SUBMODULES (SMs) ILMCV Row -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="SDS4ILMCV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>									
										
									   									   								   
									</tr>
									
									<!-- SUBMODULES (SMs) SCV Row -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="SDS4SCV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4SCVData"/>
											</xsl:for-each>	
										</font></td>						
																			   
									</tr>
																		
									<!-- SUBMODULES (SMs) CV PASS Row -->
									<tr>								   								    
									   
																			   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="SDS4PASS"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4PASSData"/>
											</xsl:for-each>	
										</font></td>

																	   
									</tr>
									
									
									<!-- Added on 27-FEB-2025 -->
									
									<!-- SUBMODULES (SMs) DEFENCE Row -->
									<tr>								   								    
									   
										<!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="SDS4DEFENCE"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>

																	   
									</tr>
									
									
									<!-- SUBMODULES (SMs) TOTAL CV Row -->									
									<tr>								   								    
									   
										<!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="SDS4CV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="SDS4CVData"/>
											</xsl:for-each>	
										</font></td>
									  								  									   
									</tr>

									<!-- DIVIDER after SUBMODULES (SMs) -->
									<tr>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>		
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
										<td bgcolor="#006699"></td>										   
									   <!-- <th></th> -->									   
									</tr>
									
									
									<!-- RATIOS (VEHs/SMs) HCV Row -->
									<tr>								   								    
									   
									   <th rowspan="6">Ratio<br></br>(VEHs/SMs)</th>
									   
									   									   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="RDS4HCV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4HCVData"/>
											</xsl:for-each>	
										</font></td>								   							   
							
									</tr>
									
									<!-- RATIOS (VEHs/SMs) ILMCV Row -->
									<tr>								   								    
									   
									   									   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="RDS4ILMCV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4ILMCVData"/>
											</xsl:for-each>	
										</font></td>
																	   
									</tr>
									
									<!-- RATIOS (VEHs/SMs) SCV Row -->
									<tr>								   								    
									   
																			   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="RDS4SCV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4SCVData"/>
											</xsl:for-each>	
										</font></td>									   
																	   
									</tr>
									
									<!-- RATIOS (VEHs/SMs) CV PASS Row -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="RDS4PASS"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4PASSData"/>
											</xsl:for-each>	
										</font></td>
									   								   
									</tr>
									
									<!-- Added on 27-FEB-2025 -->
									<!-- RATIOS (VEHs/SMs) TOTAL CV Row -->
									<tr>								   								    
									   
										<!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="RDS4DEFENCE"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4DEFENCEData"/>
											</xsl:for-each>	
										</font></td>
										
									</tr>	
									
									
									
									<!-- RATIOS (VEHs/SMs) TOTAL CV Row -->
									<tr>								   								    
									   
										<!-- PLATFORM Cell -->
									   <td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="RDS4CV"/></b>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col12">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col11">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col10">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col9">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col8">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</font></td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col7">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									    <!-- Column Left-To-Right Month-8 -->	
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col6">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-9 -->							   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	
										<!-- 13		 -->
										<!-- Column Left-To-Right FY-Q Cell-3 -->										
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col5">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</font></td>
									   	<!-- Column Left-To-Right Month-10 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col4">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-11 -->			
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col3">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- Column Left-To-Right Month-12 -->											   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</td>
									   	<!-- 17		 -->	
										<!-- Column Left-To-Right FY-Q Cell-4 -->	
										<td bgcolor="#f0fbff" align="center"><font color="#006699">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col2">
												<xsl:value-of select="RDS4CVData"/>
											</xsl:for-each>	
										</font></td>
										
									</tr>									
									
									<!-- DIVIDER after RATIOS (VEHs/SMs) -->
									<tr>								   								    
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>		
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
										<td bgcolor="#006699"></td>	
									  <!--  <th></th> -->									   
									</tr>

																
						</table>
						
						<div class="label_info">
						This section shows table with Product-Line wise data of released Vehicles and Submodules Month-wise.
						</div>
			
		
		
	<br></br>
	
			<div class="label1">
			[Section 5] Submodules Usage Frequency in Vehicles :
			</div>
			
			<div class="label_alert" style="font-size: 12px; text-align: right">
			<!-- As per data last updated on date : 10 Oct, 2024 (Thursday) @ 22:35 hrs. -->
			
				<xsl:for-each select="MCCMainDashboardRpt/DataRefreshDate">						
					As per data last updated on date : <xsl:value-of select="LastDate"/>							
				</xsl:for-each>	
				
			</div>
			
			
			
			<div class="row">
				<div class="col-sm-12">
					<div class="label2">
						<center>Submodules Usage Frequency in Vehicles</center>
					</div>
					<!-- 
					<div class="grid_sm_usage_freq mt-2">	

					
						   <div class="itemUF1">
							
							No of Vehicles
							
							</div>
						   <div class="item27">Count</div>
							
							<div class="itemUF1">
							
							Submodule in <font size="4px"><b>1</b></font> Vehicle
							
							</div>
						<div class="item27">3351</div>
						
						
							<div class="itemUF1">
							Submodule in <font size="4px"><b>2-5</b></font> Vehicles
							</div>
						<div class="item27">3351</div>
						
						
						<div class="itemUF1">
						Submodule in <font size="4px"><b>6-15</b></font> Vehicles
							</div>
						<div class="item27">3351</div>
						
						
						<div class="itemUF1">
						Submodule in <font size="4px"><b>16-99</b></font> Vehicles
							</div>
						<div class="item27">3351</div>
						
						
						<div class="itemUF1">
						Submodule in <font size="4px"><b>>100</b></font> Vehicles
							</div>
						<div class="item27">3333</div>
										
					</div>
					 -->
					 
								
					 
						 <table width="100%">
							<tr>
								<!-- <td>Module Desc</td> -->
								<td bgcolor="#AED6F1" align="center"><font color="#006699"><b>Srl</b></font></td>	
								<td bgcolor="#AED6F1" align="center"><font color="#006699"><b>Usage Frequency Category</b></font></td>	
								<!-- <td>Module Desc</td> -->
								<td bgcolor="#AED6F1" align="center"><font color="#006699"><b>Count of Submodules</b></font></td>
								<td bgcolor="#AED6F1" align="center"><font color="#006699"><b>Percentage (%)</b></font></td>									
							</tr>
							
							
							
								<tr>
									<td>1</td>
									<td style="font-size: 12px; text-align: left">No. of Submodules in <b>1</b> Vehicle</td>								
									<td>
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
										<xsl:value-of select="DS5Col1"/>							
										</xsl:for-each>	
									</td>
									<td>
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
										<xsl:value-of select="DS5Col1Per"/>	%						
										</xsl:for-each>	
									</td>
								</tr>
								<tr>
									<td>2</td>
									<td style="font-size: 12px; text-align: left">No. of Submodules in <b>2-5</b> Vehicles</td>
									<td>
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
										<xsl:value-of select="DS5Col2"/>							
										</xsl:for-each>	
									</td>
									<td>
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
										<xsl:value-of select="DS5Col2Per"/>	%						
										</xsl:for-each>	
									</td>
								</tr>
								<tr>
									<td>3</td>
									<td style="font-size: 12px; text-align: left">No. of Submodules in <b>6-15</b> Vehicles</td>
									<td>
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
										<xsl:value-of select="DS5Col3"/>							
										</xsl:for-each>	
									</td>
									<td>
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
										<xsl:value-of select="DS5Col3Per"/>	%						
										</xsl:for-each>	
									</td>
								</tr>
								<tr>
									<td>4</td>
									<td style="font-size: 12px; text-align: left">No. of Submodules in <b>16-99</b> Vehicles</td>
									<td>
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
										<xsl:value-of select="DS5Col4"/>							
										</xsl:for-each>	
									</td>
									<td>
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
										<xsl:value-of select="DS5Col4Per"/>	%						
										</xsl:for-each>	
									</td>
								</tr>
								<tr>
									<td>5</td>
									<td style="font-size: 12px; text-align: left">No. of Submodules in <b>>100</b> Vehicles</td>	
									<td>
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
										<xsl:value-of select="DS5Col5"/>							
										</xsl:for-each>	
									</td>
									<td>
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
										<xsl:value-of select="DS5Col5Per"/>	%						
										</xsl:for-each>	
									</td>
								</tr>
								
								<tr>
									<td bgcolor="#AED6F1" align="center"><font color="#006699"><b></b></font></td>
									<td bgcolor="#AED6F1" align="center"><font color="#006699"><b>TOTAL</b></font></td>	
									<td bgcolor="#AED6F1" align="center">
										<font color="#006699">
											<b>
												<xsl:for-each select="MCCMainDashboardRpt/DataSheet5">						
												<xsl:value-of select="DS5Col5Total"/>					
												</xsl:for-each>	
											</b>
										</font>
									</td>
									<td bgcolor="#AED6F1" align="center"><font color="#006699"><b></b></font></td>
								</tr>
							
							
						
						</table>
					
		
					<div class="label_info">
					Above table shows the number of VCs in which a submodule is used and count of submodules.
					Data includes all submodules that are attached to a VC (includes software releases).			

					</div>
					
				</div>	
	  
	  
				<div class="col-sm-4">
				
				<!-- 
					<div class="label2">
						Top Submodules with Usage Frequency = 1
					</div>
					
					<table width="100%">
						<tr>
							
							<td bgcolor="#AED6F1" align="center"><font color="#006699"><b>Module Desc</b></font></td>	
							
							<td bgcolor="#AED6F1" align="center"><font color="#006699"><b>Variety Count</b></font></td>	
						</tr>
						
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
					</table>
					<div class="label_info">
					This section shows variety of Submodules having usage frequency as 1.
					</div>
					 -->
				
				</div>
				
				<div class="col-sm-4">
					<!-- 
					<div class="label2">
						Top Submodules with Usage Frequency > 100
					</div>	
					
					<table width="100%">
						<tr>
							
							<td bgcolor="#AED6F1" align="center"><font color="#006699"><b>Module Desc</b></font></td>	
							
							<td bgcolor="#AED6F1" align="center"><font color="#006699"><b>Variety Count</b></font></td>	
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
						<tr>
							<td>TBD</td>
							<td>TBD</td>
						</tr>
					</table>
					<div class="label_info">
					This section shows variety of Submodules having usage frequency >100.
					</div>
					 -->
					
				</div>
				

				
			</div>
			
					<br></br>
				
			<div class="label1">
			[Section 6] Submodules sharing across Product-Line:
			</div>
			<div class="label_alert" style="font-size: 12px; text-align: right">			
				<xsl:for-each select="MCCMainDashboardRpt/DataRefreshDate">						
					As per data last updated on date : <xsl:value-of select="LastDate"/>							
				</xsl:for-each>	
			</div>
			
			
						<!-- <br></br> -->
						<table width="100%">
						
						 						
							<tr bgcolor="#006699">							 
								
								<td bgcolor="#006699" style="width: 200px;">
								</td>
							  
								<td bgcolor="#006699" style="width: 300px;">
								<font color="white">															
									<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
										<b><xsl:value-of select="DS7Row21"/></b>
									</xsl:for-each>									
								</font>
								</td>
			  
						
								<td bgcolor="#006699" align="center" style="width: 50px;"><font color="white"><b>HCV</b></font></td>	
								<td bgcolor="#006699" align="center" style="width: 50px;"><font color="white"><b>ILMCV</b></font></td>
								<td bgcolor="#006699" align="center" style="width: 50px;"><font color="white"><b>SCV</b></font></td> 								
								<td bgcolor="#006699" align="center" style="width: 50px;"><font color="white"><b>CVP</b></font></td> 								
								<td bgcolor="#006699" align="center" style="width: 100px;"><font color="white"><b>DEFENCE</b></font></td>
								<td bgcolor="#006699" align="center" style="width: 100px;"><font color="white"><b>POC</b></font></td>
								<td bgcolor="#006699" align="center" style="width: 100px;"><font color="white"><b>Count</b></font></td>
								<td bgcolor="#006699" align="center"><font color="white"><b>Total Submodules</b></font></td> 							
								<td bgcolor="#006699" align="center"><font color="white"><b>Percentage (%)</b></font></td>

								 
							</tr>
							
						
									<!-- Exclusive to PL - HCV Row -->
									<tr>							   								    
										<td rowspan="5" bgcolor="#a3e4d7" align="center">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col1">
												<b><xsl:value-of select="DS7Row11"/></b>
											</xsl:for-each>	
										</td>
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<!-- <xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4HCV"/></b>
											</xsl:for-each>	 -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row22"/>
											</xsl:for-each>
											
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#a3e4d7" align="center">
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td></td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td></td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>											
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row32"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<!-- <td rowspan="4" bgcolor="#a3e4d7" align="center"> -->
										<td rowspan="5" bgcolor="#a3e4d7" align="center">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col4">
												<b><xsl:value-of select="DS7Row42"/></b>
											</xsl:for-each>	
										</td>
									    
										<!-- Column Left-To-Right Month-7 -->	
										<td rowspan="5" bgcolor="#a3e4d7" align="center">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col5">
												<b><xsl:value-of select="DS7Row52"/> %</b>
											</xsl:for-each>	
										</td>
									    									  
									   			
									</tr>
																		
									
									<!-- Exclusive to PL - ILMCV Row -->
									<tr>								   								    
									   
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<!-- <xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4SCV"/></b>
											</xsl:for-each>	 -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row23"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td></td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#a3e4d7" align="center">
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   

										<td></td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row33"/>
											</xsl:for-each>	
										</td>	   
					    						    
									   									   									   
									</tr>
									
									<!-- Exclusive to PL - SCV Row -->
									
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<!-- <xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4PASS"/></b>
											</xsl:for-each>	 -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row24"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td></td>
									   <!-- Column Left-To-Right Month-2 -->
										<td></td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#a3e4d7" align="center">
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row34"/>
											</xsl:for-each>	
										</td>			   									   
									   									   									   
									</tr>
																		
									<!-- Exclusive to PL - CVP Row -->
									<tr>								   								    
									   
									   	<!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<!-- <xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4CV"/></b>
											</xsl:for-each>	 -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row25"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td></td>
									   <!-- Column Left-To-Right Month-2 -->
										<td></td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td></td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#a3e4d7" align="center">
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row35"/>
											</xsl:for-each>	
										</td>							   	


									   								   
									</tr>
									
									<!-- Exclusive to PL - DEFENCE Row -->
									<tr>								   								    
									   
									   	<!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<!-- <xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="VDS4CV"/></b>
											</xsl:for-each>	 -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row26"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td></td>
									   <!-- Column Left-To-Right Month-2 -->
										<td></td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td></td>
									   	<!-- 5		 -->
									   	<!-- Column Left-To-Right Month-4 -->		
										<td></td>
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#a3e4d7" align="center">
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row36"/>
											</xsl:for-each>	
										</td>									   								   
									</tr>

									<!-- DIVIDER after Exclusive to PL -->
									<tr>
									
									
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>		
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
	
									   <!-- <th></th> -->									   
									</tr>

									<!-- Shared between 2 PLs ROW-1 HCV/ILMCV-->
									<tr>
									   <td rowspan="6" bgcolor="#AED6F1" align="center">
										<!-- <b>Shared between 2 PLs</b>										 -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col1">
												<b><xsl:value-of select="DS7Row12"/></b>
											</xsl:for-each>	
									   </td>
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<!-- <xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col1">
											<b><xsl:value-of select="SDS4HCV"/></b>
											</xsl:for-each>	 -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row27"/>
											</xsl:for-each>	
									   </td>

									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#AED6F1" align="center">
											HCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#AED6F1" align="center">
											ILMCV
										</td>
										<!-- Column Left-To-Right Month-1 -->
										<td></td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row37"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
									   <td rowspan="6" bgcolor="#AED6F1" align="center">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col4">
												<b><xsl:value-of select="DS7Row43"/></b>
											</xsl:for-each>	
									   </td>
										
									<!-- 	<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet3/DS3Col1">
											<b><xsl:value-of select="VDS3HCV"/></b>
											</xsl:for-each>	
									   </td> -->
									    
										<!-- Column Left-To-Right Month-7 -->	
									   <td rowspan="6" bgcolor="#AED6F1" align="center">
									   		<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col5">
												<b><xsl:value-of select="DS7Row53"/> %</b>
											</xsl:for-each>	
									   </td>
									    
										
							
									</tr>
									
									<!-- Shared between 2 PLs ROW-2 HCV/SCV -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row28"/>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#AED6F1" align="center">
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td></td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#AED6F1" align="center">
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td>	
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
																			
										<td>
										</td>
										
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row38"/>
											</xsl:for-each>	
										</td>							    				
																			   									   								   
									</tr>
									
									<!-- Shared between 2 PLs ROW-3 HCV/CVP -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
											
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row29"/>
											</xsl:for-each>	
											
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#AED6F1" align="center">
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#AED6F1" align="center">
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>										
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row39"/>
											</xsl:for-each>	
										</td>							   	
									    				
																			   
									</tr>
																		
									<!-- Shared between 2 PLs ROW-4 ILMCV/SCV -->
									<tr>								   								    
									   
										<!-- PLATFORM Cell -->
									   <td style="text-align: left">											
												
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row210"/>
											</xsl:for-each>												
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#AED6F1" align="center">
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#AED6F1" align="center">
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row310"/>
											</xsl:for-each>	
										</td>
									   							    

																	   
									</tr>
									
									<!-- Shared between 2 PLs ROW-5 ILMCV/CVP -->								
									<tr>								   								    
									   
										<!-- PLATFORM Cell -->
									   <td style="text-align: left">											
												
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row211"/>
											</xsl:for-each>												
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>											
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#AED6F1" align="center">
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>											
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#AED6F1" align="center">
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>											
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row311"/>
											</xsl:for-each>	
										</td>
									   										    
									  								  									   
									</tr>

									<!-- Shared between 2 PLs ROW-6 CVP/SCV -->		
									<tr>								   								    
									   
										<!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row212"/>
											</xsl:for-each>												
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>											
										</td>
									   	
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#AED6F1" align="center">
											SCV
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#AED6F1" align="center">
											CVP
										</td>
										<!-- Column Left-To-Right Month-3 -->				   
										<td>											
										</td>
									   	<!-- 5		 -->
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row312"/>
											</xsl:for-each>	
										</td>   				    
									  								  									   
									</tr>

									<!-- DIVIDER after Shared between 2 PLs -->
									<tr>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>		
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   									   
									   <!-- <th></th> -->									   
									</tr>
									
									
									<!-- Shared between 3 PLs ROW-1 HCV/ILMCV/SCV -->
									<tr>								   								    
									   
									   <td rowspan="4" bgcolor="#f9e79f" align="center">
									    
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col1">
												<b><xsl:value-of select="DS7Row13"/></b>
											</xsl:for-each>											
									   </td>
									   
									   									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row213"/>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#f9e79f" align="center">
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#f9e79f" align="center">
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#f9e79f" align="center">
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row313"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
									   <td rowspan="4" bgcolor="#f9e79f" align="center">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col4">
												<b><xsl:value-of select="DS7Row44"/></b>
											</xsl:for-each>	
									   </td>
									   <td rowspan="4" bgcolor="#f9e79f" align="center">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col5">
												<b><xsl:value-of select="DS7Row54"/> %</b>
											</xsl:for-each>	
									   </td>
									
									    			   							   
							
									</tr>
									
									<!-- Shared between 3 PLs ROW-2 HCV/ILMCV/CVP -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row214"/>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#f9e79f" align="center">
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#f9e79f" align="center">
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f9e79f" align="center">
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row314"/>
											</xsl:for-each>
										</td>
									  
								
									    
																	   
									</tr>
									
									<!-- Shared between 3 PLs ROW-3 HCV/SCV/CVP -->
									<tr>								   								    
									   
									<!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row215"/>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#f9e79f" align="center">
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->									
										<td>
										</td>
										<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#f9e79f" align="center">
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f9e79f" align="center">
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row315"/>
											</xsl:for-each>
										</td>								    						   
																	   
									</tr>
									
									<!-- Shared between 3 PLs ROW-4 ILMCV/SCV/CVP -->
									<tr>								   								    
									   
									  <!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row216"/>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#f9e79f" align="center">
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#f9e79f" align="center">
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f9e79f" align="center">
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>	
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row316"/>
											</xsl:for-each>
										</td>								    						   
																	   
									</tr>
									
									<!-- DIVIDER after Shared between 3 PLs -->
									<tr>								   								    
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>		
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   
									  <!--  <th></th> -->									   
									</tr>
									
									<!-- Shared across all PLs HCV/ILMCV/CVP/SCV Row -->
									<tr>								   								    
									   
									   <td rowspan="1" bgcolor="#ccd1d1" align="center">
									   <xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col1">
												<b><xsl:value-of select="DS7Row14"/></b>
											</xsl:for-each>
									   </td>
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row217"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#ccd1d1" align="center">
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#ccd1d1" align="center">
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#ccd1d1" align="center">
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#ccd1d1" align="center">
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row317"/>
											</xsl:for-each>										
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td rowspan="1" bgcolor="#ccd1d1" align="center">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col4">
												<b><xsl:value-of select="DS7Row45"/></b>
											</xsl:for-each>
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
									   
									   <td rowspan="1" bgcolor="#ccd1d1" align="center">
									   		<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col5">
												<b><xsl:value-of select="DS7Row55"/> %</b>
											</xsl:for-each>
									   </td>
									    					   							   
							
									</tr>
									
									
									<!-- DIVIDER after Shared across all PLs -->
									<tr>								   								    
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>		
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									  <!--  <th></th> -->									   
									</tr>
									
									<!-- Shared with DEFENCE Row-1 HCV/ILMCV/SCV/CVP/DEFENCE -->
									<tr>
									   <td rowspan="12" bgcolor="#f5cba7" align="center">
									   		<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col1">
												<b><xsl:value-of select="DS7Row15"/></b>
											</xsl:for-each>
									   </td>
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
									   <!-- HCV/ILMCV/CVP/ILMCV-DEFENCE -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row218"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#f5cba7" align="center">
											<!-- <xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	 -->
											<!-- <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16">
											  <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/>
											</svg> -->
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#f5cba7" align="center">											
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#f5cba7" align="center">											
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f5cba7" align="center">											
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row318"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
									   <td rowspan="12" bgcolor="#f5cba7" align="center">
									   		<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col4">
												<b><xsl:value-of select="DS7Row46"/></b>
											</xsl:for-each>	
									   </td>
									   
									   <td rowspan="12" bgcolor="#f5cba7" align="center">
									   		<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col5">
												<b><xsl:value-of select="DS7Row56"/> %</b>
											</xsl:for-each>	
									   </td>								
																	
									</tr>
									
									<!-- Shared with DEFENCE Row-2 HCV/ILMCV/CVP/DEFENCE -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>HCV, ILMCV, CVP, ILMCV-DEFENCE</b> -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row219"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#f5cba7" align="center">
											<!-- <xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	 -->
											<!-- <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16">
											  <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/>
											</svg> -->
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#f5cba7" align="center">											
											ILMCV
										</td>
									   	<td></td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f5cba7" align="center">											
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row319"/>
											</xsl:for-each>	
										</td>									    
																   								   
									</tr>
									
									<!-- Shared with DEFENCE Row-3 HCV/ILMCV/DEFENCE -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>HCV, ILMCV, ILMCV-DEFENCE</b><br></br> -->
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row220"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#f5cba7" align="center">
											<!-- <xsl:for-each select="MCCMainDashboardRpt/DataSheet4/DS4Col13">
												<xsl:value-of select="VDS4HCVData"/>
											</xsl:for-each>	 -->
											<!-- <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check2" viewBox="0 0 16 16">
											  <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0"/>
											</svg> -->
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#f5cba7" align="center">											
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td></td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row320"/>
											</xsl:for-each>	
										</td>							   										    
																			    					
																			   
									</tr>
																		
									<!-- Shared with DEFENCE Row-4 HCV/SCV/DEFENCE -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>CVP, ILMCV-DEFENCE</b><br></br> -->
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row221"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#f5cba7" align="center">											
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#f5cba7" align="center">											
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row321"/>
											</xsl:for-each>	
										</td>							    
										
																	   
									</tr>
									
									<!-- Shared with DEFENCE Row-5 HCV/CVP/DEFENCE -->									
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>ILMCV, CVP, ILMCV-DEFENCE</b><br></br> -->
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row222"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#f5cba7" align="center">											
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td></td>
										<td></td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#f5cba7" align="center">											
											CVP
										</td>									   	
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row322"/>
											</xsl:for-each>		
										</td>							    
										
									  								  									   
									</tr>

									<!-- Shared with DEFENCE Row-6. HCV/DEFENCE -->	
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>ILMCV, CVP, HCV-DEFENCE</b><br></br> -->
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row223"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td bgcolor="#f5cba7" align="center">											
											HCV
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td></td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td></td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row323"/>
											</xsl:for-each>	
										</td>
									    									
									    
									  								  									   
									</tr>

									
									<!-- Shared with DEFENCE Row-7. ILMCV/SCV/DEFENCE -->	
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>ILMCV, ILMCV-DEFENCE</b><br></br> -->
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row224"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#f5cba7" align="center">											
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#f5cba7" align="center">											
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row324"/>
											</xsl:for-each>	
										</td>							    
										
									    																	   
									</tr>
									
									<!-- Shared with DEFENCE Row-8. ILMCV/CVP/DEFENCE -->								
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>HCV-DEFENCE</b><br></br> -->
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row225"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#f5cba7" align="center">											
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f5cba7" align="center">											
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row325"/>
											</xsl:for-each>	
										</td>								    
									    									  								  									   
									</tr>

									<!-- Shared with DEFENCE Row-9. ILMCV/DEFENCE -->	
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>ILMCV-DEFENCE</b><br></br> -->
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row226"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td bgcolor="#f5cba7" align="center">											
											ILMCV
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row326"/>
											</xsl:for-each>	
										</td>									    
									    
									  								  									   
									</tr>
									
									<!-- Shared with DEFENCE Row-10.SCV/DEFENCE -->	
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>ILMCV-DEFENCE</b><br></br> -->
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row227"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td></td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#f5cba7" align="center">											
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row327"/>
											</xsl:for-each>	
										</td>									    
									    
									  								  									   
									</tr>
									
									<!-- Shared with DEFENCE Row-11. SCV/CVP/DEFENCE -->	
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>ILMCV-DEFENCE</b><br></br> -->
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row228"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td bgcolor="#f5cba7" align="center">											
											SCV
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f5cba7" align="center">											
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row328"/>
											</xsl:for-each>	
										</td>									    
									    
									  								  									   
									</tr>
									
									<!-- Shared with DEFENCE Row-12. CVP/DEFENCE -->	
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>ILMCV-DEFENCE</b><br></br> -->
										<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row229"/>
											</xsl:for-each>
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td bgcolor="#f5cba7" align="center">											
											CVP
										</td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td bgcolor="#f5cba7" align="center">											
											DEFENCE
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td></td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row329"/>
											</xsl:for-each>	
										</td>									    
									    
									  								  									   
									</tr>

									
									<!-- DIVIDER after Shared with DEFENCE Row-12 -->
									<tr>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>		
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <!-- <th></th> -->									   
									</tr>
									
									<!-- POC Row-1. HCV-POC -->
									<tr>						   								    
									   <td rowspan="5" bgcolor="#d7bde2" align="center">
									   <!-- <b>POC</b><br></br> -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col1">
												<b><xsl:value-of select="DS7Row16"/></b>
											</xsl:for-each>	
									   </td>
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>HCV-POC</b><br></br> -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row230"/>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td bgcolor="#d7bde2" align="center">											
											HCV-POC
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row330"/>
											</xsl:for-each>	
										</td>
									   	<!-- 9		 -->
										<!-- Column Left-To-Right FY-Q Cell-2 -->										
									   
									   <td rowspan="5" bgcolor="#d7bde2" align="center">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col4">
												<b><xsl:value-of select="DS7Row47"/></b>
											</xsl:for-each>
									   </td>	
									   
										<!-- Column Left-To-Right Month-7 -->	
										<td rowspan="5" bgcolor="#d7bde2" align="center">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col5">
												<b><xsl:value-of select="DS7Row57"/> %</b>
											</xsl:for-each>
											
										</td>
									    
									   			
									</tr>
																		
									
									<!-- POC Row-2. ILMCV-POC -->
									<tr>								   								    
									   
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>ILMCV-POC</b><br></br> -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row231"/>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td bgcolor="#d7bde2" align="center">											
											ILMCV-POC
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row331"/>
											</xsl:for-each>
										</td>
									    
																			    
									   									   									   
									</tr>
									
									<!-- POC Row-3. SCV-POC -->									
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>CVP-POC</b><br></br> -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row232"/>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td bgcolor="#d7bde2" align="center">											
											SCV-POC
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row332"/>
											</xsl:for-each>
										</td>								   
									   									   									   
									</tr>
																		
									<!-- POC Row-4. CVP-POC -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>SCV-POC</b><br></br> -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row233"/>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td bgcolor="#d7bde2" align="center">											
											CVP-POC
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row333"/>
											</xsl:for-each>	
										</td>
										
									</tr>
									
									<!-- POC Row-5. DEFENCE-POC -->
									<tr>								   								    
									   
									   <!-- PLATFORM Cell -->
									   <td style="text-align: left">
										<!-- <b>SCV-POC</b><br></br> -->
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col2">
												<xsl:value-of select="DS7Row234"/>
											</xsl:for-each>	
									   </td>
									   <!-- Column Left-To-Right Month-1 -->
									   <!-- Column Left-To-Right Month-1 -->
										<td>
										</td>
									   <!-- Column Left-To-Right Month-2 -->
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-3 -->				   
										<td>
										</td>
									   	<!-- 5		 -->
										
										<!-- Column Left-To-Right FY-Q Cell-1 -->
										<!-- border: 0.25px solid #dddfe1; -->
										<td></td>
									   	<!-- Column Left-To-Right Month-4 -->		
										<td>
										</td>
									   	<!-- Column Left-To-Right Month-5 -->		
										<td bgcolor="#d7bde2" align="center">											
											DEFENCE-POC
										</td>
									   	<!-- Column Left-To-Right Month-6 -->										   
										<td>
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col3">
												<xsl:value-of select="DS7Row334"/>
											</xsl:for-each>	
										</td>
										
									</tr>

																
									<tr>
																		
									   <td bgcolor="#006699">
										<font color="white">
											<b>TOTAL</b>	
										</font>
									   </td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>								   
									   <td bgcolor="#006699">
										<font color="white">
											<xsl:for-each select="MCCMainDashboardRpt/DataSheet7/DS7Col4">
												<b><xsl:value-of select="DS7Row48"/></b>
											</xsl:for-each>	
										</font>
									   </td>		
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <!-- <th></th> -->									   
									</tr>

									
									
									

																
						</table>
						
						<div class="label_info">
						This section shows table for Submodules distribution count across Product-Line.
						<br></br>
						This data is based on MBOM MCC Library Submodules data in which Product-Line is updated based on its linked Vehicles' Platforms.
						</div>		

		
	
<br></br>
<hr style="height:5px;border-width:0;color:gray;background-color:gray"></hr>

		<center>
		<font size="2px">Copyright@2026 (PLM ERC Team)</font>
		</center>
					 

				

			
	</div> 	
			

	<!-- </div> -->
		
		 
</div>
	
	 <!--<canvas id="chartId" aria-label="chart" heigth="350" width="580"></canvas>-->
<!-- 	 <canvas id="myChart3" style="width:100%"></canvas>-->
	
	<script>
	
	
	<!-- function getRandomColor() {
	  var letters = '0123456789ABCDEF';
	  var color = '#';
	  for (var i = 0; i < 6; i++) {
		color += letters[Math.floor(Math.random() * 16)];
	  }
	  return color;
	}
	 -->
	
	</script>
	
  </body> 
</html> 

</xsl:template>
</xsl:stylesheet> 