<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40" >
    
    <xsl:output method="xml" version="1.0" indent="yes" />
    <xsl:strip-space elements="*"/>
    
    <xsl:template match="/">
        <xsl:call-template name="ReportHeader"></xsl:call-template>
    </xsl:template>
    
    <xsl:template name="ReportHeader">
        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">
            
            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="11" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <!--<Alignment ss:Horizontal="Right"/>-->
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="PropertyNameCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                </Style>                
            </Styles>
            
            <Worksheet ss:Name="Sheet1">
                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="50"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="300" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Row>  
                        <Cell ss:StyleID="s22" ss:MergeAcross='5'>
                            <Data ss:Type='String'>Vehicle Compliance Report</Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Vehicle No</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="VehCompliance/ComplianceStatus/VehNo"/>
                            </Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Vehicle Revision</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="VehCompliance/ComplianceStatus/VehRev"/>
                            </Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Vehicle Sequence</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/VehSeq"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Vehicle Description</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/VehDesc"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Vehicle AR/DR Status</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/VehDrAr"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Revision Rule</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/RevRule"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Closure Rule</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/ClosureRule"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Total Modules in Vehicle</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/TotalMod"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Present Modules in MCC Library</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/PresentMod"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Not-Present Modules in MCC Library</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/NotPresentMod"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>No of MAX DR4 and Above Submodules</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/AboveMod"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>No of Below DR4 Submodules</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/BelowMod"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>DR4 and Above Compliance Percentage</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/MaxPercent"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>All DR Status Compliance Percentage</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/AllPercent"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Report Generation Time</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehCompliance/ComplianceStatus/TimeStamp"/>
                            </Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row>
					    <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Serial No</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module No</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Revision</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Sequence</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Description</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module Address</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Product Line</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Platform</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Project Code</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Design Group</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>DR/AR Status</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Part Type</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Quantity</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>UOM</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Vehicle Linkage Frequency</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Status</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Library Rev</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Library Seq</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Library AR/DR</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Library Max AR/DR</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module Name</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Aggregate Family Name</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Aggregate Group</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Classification</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>NPR Object</Data>
                        </Cell>
                    </Row>
                    <xsl:call-template name="generateDesignRevPartsList"></xsl:call-template>
                    <Row></Row>
                    <Row></Row>
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    
    <xsl:template name="generateDesignRevPartsList">
        <xsl:for-each select="VehCompliance/Compliance">
			<Row>
			    <Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="SlNo"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="PartNo"/></Data>
				</Cell>
			    <Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="PartRev"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="PartSeq"/></Data>
				</Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="PartDesc"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="PartAddr"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="ProdLine"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="Platform"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="ProjCode"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="DesGrp"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="DrAr"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="PartType"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="Qty"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="UOM"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="VehFreq"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="Status"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LibRev"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LibSeq"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LibGate"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LibMax"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LibMod"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LibFamily"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LibAggGrp"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LibClass"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="NPRNo"/></Data>
                </Cell>
			</Row>
        </xsl:for-each>
    </xsl:template>
    
</xsl:stylesheet>