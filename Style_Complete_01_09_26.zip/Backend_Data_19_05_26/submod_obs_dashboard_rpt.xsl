<?xml version="1.0" encoding="utf-8"?> 
<xsl:stylesheet version="1.0"  xmlns:xsl="http://www.w3.org/1999/XSL/Transform" > 
<xsl:output method="html"/> 
<xsl:template match="/"> 
<!-- 
*****************************************************************************************************************
Author : Ujjawal Kumar
Date   : August-2024 
Purpose : For MCC Dashboard AWC page.

Change History:
2024-08-01 : Initial Creation by Ujjawal Kumar.

2025-03-19
Modification in NPR section. Added Agreed, Dropped Percentage in Section 6.1
Added DEFENCE Columns in Section 6.3, 6.4

Pls do not copy this code. Copyright@2024.
*****************************************************************************************************************
-->
<html> 
  <head> 
		 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
		
		 <link rel = "stylesheet" href = "//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css"></link>
		 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
		 					
		<!-- <script type = "text/javascript"      src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>-->
				
		<script type = "text/javascript" src = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
		
		
	  <style>
    /* Tab menu styles */
    .tab {
      overflow: hidden;
      border-bottom: 1px solid #ccc;
    }

    .tab button {
      background-color: inherit;
      float: left;
      border: none;
      outline: none;
      padding: 10px 20px;
      cursor: pointer;
      transition: 0.3s;
    }

    .tab button:hover {
      background-color: #ddd;
    }

    .tab button.active {
      background-color: #ccc;
    }

    /* Tab content styles */
    .tabcontent {
      display: none;
      padding: 15px;
      border: 1px solid #ccc;
      border-top: none;
    }
  </style>
	  
	<style>
	
	body {

  background-color: #F2F3F4;
	color: #636363;
	font-size: 11px;
	font-family: Tahoma, Geneva, sans-serif;
   
	}
	
	  h2   {color: blue;}
	  h6   {
		color: #004465;
		<!-- color: #006699; -->
		font-size: 12px;
		font-family: Tahoma, Geneva, sans-serif;
		font-weight: bold;
	  }
	  
	  h6_NPR   {
		color: #e67e22;
		<!-- color: #006699; -->
		font-size: 12px;
		font-family: Tahoma, Geneva, sans-serif;
		font-weight: bold;
	  }
	  
	  h4 {
	  font-family: Tahoma, Geneva, sans-serif;
	  }
	  
	  p {
		color: #006699;
		font-family: Tahoma, Geneva, sans-serif;
		text-align: center;
		}
	  
	  td {
		  border: 0.25px solid #dddfe1;
		  border-collapse: collapse;
		  color: #636363;
		  font-size: 10px;
		  font-family: Tahoma, Geneva, sans-serif;
		  padding: 3px;
		  text-align: center;
		  <!-- white-space: nowrap; -->	  
	  }
	  
	  th{
		  border: 0.25px solid #dddfe1;
		  background-color: #AED6F1;
		  white-space: nowrap;
		  <!-- color: #636363; -->
		  color: #006699;
		  padding: 3px;
		  text-align: center;
		  font-size: 11px;
		  font-family: Tahoma, Geneva, sans-serif;		  

		  <!-- writing-mode: vertical-lr;
		  transform: scale(-1); -->
	  }
	  
	  th_awc{
		  border: 0.25px solid #dddfe1;
		  background-color: #006699;
		  white-space: nowrap;
		  color: white;
		  padding: 3px;
		  text-align: center;
		  font-size: 12px;
		  font-family: Tahoma, Geneva, sans-serif;
		  <!-- writing-mode: vertical-lr;
		  transform: scale(-1); -->
	  }
	  
	  tr:nth-child(even) {
		background-color: #f9fafb;
	  
	  }
	  
	  <!-- tr:hover {background-color: #ffff99;} -->
	  
	  <!-- tr:hover td {background:#ffff99; color:#006699; font-weight:bold;} -->
	  tr:hover td {background:#ffff99; color:#006699;}

<!-- 	 .row > div {
		  
		  border: 1px solid grey;
		} -->
		
		
	.td_header {
		  border: 0.25px solid #dddfe1;
		  border-collapse: collapse;
		  color: white;
		  font-size: 12px;
		  font-family: Tahoma, Geneva, sans-serif;
		  padding: 3px;
		  text-align: center;
		  pointer-events: none;
		  <!-- white-space: nowrap; -->	  
	  }
	  
	.tr_nohover{
	  pointer-events: none;
	  }
	  
	.col-md-12 {
		font-size: 16px;
		<!-- font-weight: bold; -->
		background-color: #006699;
		white-space: nowrap;
		color: white;
		text-align: center;
		vertical-align: middle;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	.col-md-6 {
		font-size: 16px;
		font-weight: bold;
		background-color: #006699;
		white-space: nowrap;
		color: white;
		text-align: center;
		vertical-align: middle;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	
	.col-md-1 {
		font-size: 16px;
		font-weight: bold;
		background-color: #EBEDEF;
		white-space: nowrap;
		color: white;
		text-align: center;
		vertical-align: middle;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	
	div.wrap {
	  word-wrap: break-word;
	}
	  
	  
	.label {
	  color: white;
	  padding: 20px;
	}

	.success {background-color: #04AA6D;} /* Green */
	.info {background-color: #2196F3;} /* Blue */
	.warning {background-color: #ff9800;} /* Orange */
	.danger {background-color: #f44336;} /* Red */
	.other {background-color: #e7e7e7; color: black;} /* Gray */
	
.cardInAggGrpPage {
  /* Add shadows to create the "card" effect */
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  background-color: #04AA6D;
  transition: 0.3s;
  font-size: 12px;
  border-radius: 10px; /* 5px rounded corners */
}
		
.card {
  /* Add shadows to create the "card" effect */
<!--   height: 100px;
  width: 300px; -->
  <!-- box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); -->
  transition: 0.3s;
  border-radius: 10px; /* 5px rounded corners */
}

/* On mouse-over, add a deeper shadow */
.card:hover { 
  box-shadow: 0 2px 10px 0 #006699;
}
<!-- .card_container:hover {
  color : #ffff99; 
} -->

/* Add some padding inside the card container */
.card_container {
  padding: 4px 16px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  color: #626567;
  font-size: 11px;
}

/* Add some padding inside the card container */
.card_container_top {
  padding: 40px 16px;
  height: 250px;
  background-color: #154360;
  color: white;
  vertical-align: middle;
  font-size: 11px;
}
	  
	div.wrap {
	  word-wrap: break-word;
	}  	

.label_alert{
  <!-- display: flex;   -->
  <!-- background-color: #dddfe1; -->
  <!-- background-color: #ffff99; -->
  background-color: #f0fbff;
  <!-- background-color: #ffe2a9; -->
  <!-- background-color: white; ffffc5 ffd071-->
  <!-- color: #636363;  -->
  <!-- color: #004465; -->
  color: #641e16;
  <!-- font-weight: bold; -->
  <!-- text-shadow: 0 0 5px #00ff00, 0 0 5px #00ff00, 0 0 5px #00ff00; -->
  padding: 5px;
  margin-bottom: 5px;  
  <!-- font-size: 13px; -->
  border: 1.25px solid #dddfe1;
  <!-- font-weight: bold; -->
  <!-- box-shadow: 0 0 5px 0 #006699; -->
}

/* On mouse-over, add a deeper shadow */
.label_alert:hover { 
  <!-- background-color: #ffff99; -->
  <!-- font-weight: bold; -->
  box-shadow: 0 0 1px 0 #006699;
}

.label_NPR{
  display: flex;  
  <!-- background-color: #fffcbf; -->
  <!-- background-color: #dddfe1; -->
  <!-- background-color: #f5cba7; -->
  <!-- background-color: #1a5276; -->
    background-color: #fad7a0;
  <!-- background-color: #005078; -->
  <!-- background-color: #fcf3cf; -->
  
  <!-- color: #ffff99;   -->
  color: #7e5109;  
  <!-- color: #fffcbf;   -->
  font-size: 12px;
  font-weight: bold;
  padding: 2px;
  <!-- border: 0.25px solid #abb2b9; -->

  font-family: Tahoma, Geneva, sans-serif;
  
  <!-- font-weight: bold; -->
}

.label_MCC{
  display: flex;  
  <!-- background-color: #fffcbf; -->
  <!-- background-color: #dddfe1; -->
  background-color: #006699;
  <!-- background-color: white; -->
  <!-- background-color: #005078; -->
  <!-- background-color: #fcf3cf; -->
  
  <!-- color: #636363;  -->
  color: white;   
  <!-- color: #004465;   -->
  <!-- color: #fffcbf;   -->
  font-size: 12px;
  font-weight: bold;
  padding: 2px;
  <!-- border: 0.25px solid #abb2b9; -->

  font-family: Tahoma, Geneva, sans-serif;
  
  <!-- font-weight: bold; -->
}

.label1{
  display: flex;  
  <!-- background-color: #fffcbf; -->
  <!-- background-color: #dddfe1; -->
  <!-- background-color: #004465; -->
  background-color: #DBDBDB;
  <!-- background-color: white; -->
  <!-- background-color: #005078; -->
  <!-- background-color: #fcf3cf; -->
  
  <!-- color: #f0fbff;   -->
  color: #004465; 
  <!-- color: black;    -->
  <!-- color: #fffcbf;   -->
  font-size: 12px;
  font-weight: bold;
  padding: 7px;
  border: 1.25px solid #abb2b9;
  <!-- font-weight: bold; -->
}

.label2{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: center;
  align-content: space-evenly;
  background-color: #006699;
  color: white;
  font-weight: bold;
  padding: 5px;
  margin-top: 2px;
  <!-- font-weight: bold; -->
}

.label_green{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: center;
  align-content: space-evenly;
  background-color: #a3e4d7;
  color: #0e6251;
  font-weight: bold;
  padding: 5px;
  margin-top: 2px;
  font-size: 15px;
  <!-- border: 1px solid; -->
  <!-- font-weight: bold; -->
}

.label_blue{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: center;
  align-content: space-evenly;
  background-color: #AED6F1;
  color: #006699;
  font-weight: bold;
  padding: 5px;
  margin-top: 2px;
  font-size: 15px;
  <!-- border: 1px solid; -->
  <!-- font-weight: bold; -->
}

.label_blue_help{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: left;
  align-content: space-evenly;
  background-color: #AED6F1;
  color: #006699;
  font-weight: bold;
  padding: 5px;
  margin-top: 2px;
  font-size: 15px;
  <!-- border: 1px solid; -->
  <!-- font-weight: bold; -->
}

.label_white_help{
  <!-- display: flex;   -->
  <!-- background-color: #fffcbf; -->
  <!-- background-color: #dddfe1; -->
  background-color: white;
  <!-- background-color: white; -->
  <!-- background-color: #005078; -->
  <!-- background-color: #fcf3cf; -->
  
  color: #636363;
  text-align: left;  
  <!-- color: #004465;   -->
  <!-- color: #fffcbf;   -->
  font-size: 12px;
  <!-- font-weight: bold; -->
  padding: 20px;
  border: 1.25px solid #abb2b9;
  <!-- font-weight: bold; -->
}

.label_red{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: center;
  align-content: space-evenly;
  background-color: #f5b7b1;
  color: #78281f;
  font-weight: bold;
  padding: 5px;
  margin-top: 2px;
  font-size: 15px;
  <!-- font-weight: bold; -->
}

.label_info{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: left;
  align-content: space-evenly;
  <!-- background-color: #f0fbff; -->
  <!-- background-color: #AED6F1;   -->
  <!-- background-color: #f0fbff;   -->
  background-color: #f0fbff;  
  <!-- color: #006699; -->
  color: #004465;  
  <!-- font-weight: bold; -->
  padding: 5px;
  margin-bottom: 5px;
  border: 1.25px solid #dddfe1;
  <!-- font-weight: bold; -->
}

.label_info:hover { 
  background-color: #ffff99;
  <!-- font-weight: bold; -->
  box-shadow: 0 0 3px 0 #006699;
}

.label_info_header{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: left;
  align-content: space-evenly;
  <!-- background-color: #f0fbff; -->
  background-color: #ffff99;  
  <!-- background-color: #ffff99;   -->
  <!-- color: #006699; -->
  color: #641e16;
  <!-- font-weight: bold; -->
  padding: 2px;
  <!-- margin-bottom: 1px; -->
  border: 1.25px solid #f9e79f;
  <!-- font-weight: bold; -->
}

.grid-container {
  display: grid;
  grid-template-columns: auto auto auto auto;
  gap: 10px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  padding: 5px;
  border: 1.25px solid #dddfe1;
  
}

.grid-container > div {
  <!-- background-color: rgba(255, 255, 255, 0.8); -->
  <!-- text-align: center; -->
  padding: 5px 5px;
  font-size: 11px;
  border: 1.25px solid #006699;
  border-radius: 5px;    

 }
 
 .grid-container > div:hover { 
  box-shadow: 0 2px 10px 0 #006699;
}

.grid-container-2 {
  display: grid;
  grid-template-columns: auto auto auto auto auto auto auto;
  gap: 5px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  padding: 5px;
   border: 1.25px solid #dddfe1;
  
}

.grid_sm_usage_freq {
  display: grid;
  grid-template-columns: 200px auto;
  gap: 5px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  padding: 5px;
   border: 1.25px solid #dddfe1;
  
}

.grid-container-2 > div {
  <!-- background-color: white; -->
  <!-- text-align: center; -->
  padding: 10px 10px;
  <!-- font-size: 11px; -->
  border: 2.25px solid #dddfe1;
  border-radius: 5px;
  <!-- border-radius: 10px;     -->

 }
 
 .grid-container-2 > div:hover { 
  box-shadow: 0 2px 10px 0 #006699;
}

.item1 {
  grid-row-start: 1;
  grid-row-end: 3;
  align-content: space-evenly; 
  background-color: #AED6F1;
  <!-- color: white;   -->
}

.item2 {
  grid-row-start: 1;
  grid-row-end: 3;
  align-content: space-evenly;
  background-color: #f9e79f;
  <!-- color: white;   -->
}
.itemg2cell {
  align-content: space-evenly;
  background-color: #fff8de;  
}

.itemg2cell_lb {
  align-content: space-evenly;
  background-color: #e0f3ff;  
}

.item21 { 
  text-align: center;
  align-content: space-evenly;
  background-color: #006699;
  color: white;
  font-size: 14px;  
}

.itemUF1 { 
  text-align: center;
  align-content: space-evenly;
  background-color: #006699;
  color: white; 
  vertical-align: middle;
  border-radius: 50px;  
}

.itemg1_1 { 
  text-align: left;
  background-color: #F2F3F4;
  <!-- color: white;   -->
}

.item27{
  text-align: center;
  background-color: #f0fbff;
  font-size: 12px;
  font-weight: bold;
  border: 0.25px solid #dddfe1;
  align-content: space-evenly;
}

<!-- .scrollable_div {
	border: 0.5px solid #ccc;
	height: 300px; /* Fixed height */
	overflow-y: auto; /* Show scrollbar only when needed */
	padding: 1px;
} -->


    .scrollable_div {
      max-height: 0;
      overflow: auto;
      transition: max-height 0.4s ease;
      background-color: #f1f1f1;
      margin-top: 0px;
      padding: 0 10px;
      border: 1px solid #ccc;
    }

    /* When expanded */
    .scrollable_div.show {
      max-height: 500px; /* Adjust as needed */
      padding: 10px;
	  overflow-y: auto; /* Show scrollbar only when needed */
    }
	
	/* When Closed */
	 .scrollable_div.close{
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.4s ease;
      background-color: #f1f1f1;
      margin-top: 0px;
      padding: 0 10px;
      border: 1px solid #ccc;
    }


</style>
	
	
	
<script>
<![CDATA[
	$(document).ready(function(){
	//alert("Ujj 111..");
	$("#SOReportSearchID").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#TableBodySOReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });	

	$("#tabs").tabs();	  
	  
	});	
]]>	
</script>

<script type="text/javascript">
          <![CDATA[
            
  function openTab(evt, tabName) {
    // Hide all tab contents
    var tabcontent = document.getElementsByClassName("tabcontent");
    for (let i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }

    // Remove active class from all buttons
    var tablinks = document.getElementsByClassName("tablinks");
    for (let i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the clicked tab and add active class
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
  }

  // Optional: Open the first tab by default
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelector(".tablinks").click();
  });
		  
          ]]>
        </script>	
</head> 

<body> 
    <!--<canvas id="myChart" style="width:100%;max-width:600px"></canvas> -->

<!-- Tab headers -->
<div class="tab">
  <button class="tablinks" onclick="openTab(event, 'Tab1')">DASHBOARD</button>  
  <button class="tablinks" onclick="openTab(event, 'Tab2')">Submodules Obsolescence Report</button>
  <!-- <button class="tablinks" onclick="openTab(event, 'Tab3')">OBSOLETED Submodules</button> -->
  <button class="tablinks" onclick="openTab(event, 'Tab4')">Help</button>
</div>

<!-- Tab content -->
<div id="Tab1" class="tabcontent">
	
	<div class="container-fluid">				

			<div id = "tabs-1">	

				<!-- <div class="row m-2"> 
					<div class="col-sm-12">
						<center><h5><b>Modularity and Configuration Cell (MCC)</b></h5></center>					
					</div>
				</div> -->							
	
          
          <!-- Button to trigger modal -->
          <!-- <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#myModal">
            Pending Data
          </button> -->

          <!-- Modal HTML -->
          <div class="modal fade" id="myModal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="modalLabel">XSLT-Generated Modal</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <!-- Output from XML -->
                  <p>
                   
				   
						<center>	
											
						<!-- <center><font color="#006699"><h3><b>Vehicle Compliance Report Dashboard</b></h3></font></center> -->
						
						Search : <input id="myInputVCRDBSearch" type="text" placeholder="Search in below table.."></input>
						<br></br>

						<table>			

								<tr bgcolor="#006699">
								  <th><b>ERC_DML</b></th>
								  <th><b>STAT/REL_DATE</b></th>								  				   
								  <th><b>SRL#</b></th>							  
									<th><b>SUBMOD_NO</b></th>
									<th><b>REV_SEQ</b></th>
									<th><b>PRODUCT</b></th>	
									<th><b>TYPE</b></th>
									<th><b>MODULE_ADDR</b></th>
									<th><b>AGGR_GRP/AGGR/MOD_GRP/MOD</b></th>							  
									<th><b>DR/AR</b></th>															  
								  <th><b>RELEASE_STATUS</b></th>								  
								</tr>
								
								
								<tbody id="myTableVCRDashboard">
								<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">						
							
										<tr>
										   <td align="center"><xsl:value-of select="ERC_DML_NO"/></td>									   
										   <td style="width: 120px;">
												<xsl:value-of select="ERC_DML_REL_STATUS"/>
												<br></br>
												<xsl:value-of select="ERC_DML_REL_DATE"/>
										   </td>
										   
										   <td align="center"><xsl:value-of select="PART_SRL"/></td>									
											 <td bgcolor="#f5b7b1"><b><xsl:value-of select="PART_NO"/></b></td>
										   <td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
										   <td align="center"><xsl:value-of select="PART_PRODUCT"/></td>
										   <td align="center"><xsl:value-of select="PART_TYPE"/></td>
										   <td><xsl:value-of select="PART_MODULE_ADDR"/></td>													  						   
										 <td style="text-align: left;">
												<xsl:value-of select="PART_AGGREGATE_GROUP"/>
												<br></br>
												<xsl:value-of select="PART_AGGREGATE"/>
											  <br></br>
											  <xsl:value-of select="PART_MODULE_GROUP"/>
											  <br></br>
											  <xsl:value-of select="PART_MODULE"/>
											</td>									 										 
										 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
										 <td style="text-align: left;">
											<font color="red">
											<xsl:value-of select="PART_RELEASE_STATUS"/>
										 </font>
										 </td>											
										</tr>
									
								</xsl:for-each>
								</tbody>
						</table>
						</center>
				   
				   
                  </p>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>


				
				<!-- <br></br>
				<center><font color="#006699" size="3px"><b>[MCC] SUBMODULES OBSOLESCENCE STATUS DASHBOARD</b></font></center>			
				<br></br> -->
										
				<div class="row">	
				<div class="col-sm-1"></div>
				<div class="col-sm-10">
				
					<!-- <div class="label_NPR">[Section 2] : VC Obsolescence Approval Status</div> -->
						
						<!-- <div class="label2"></div> -->						
												
						<!-- <div class="label_blue">
							[MCC] Submodules Obsolescence Dashboard.
						</div>
						<br></br> -->
						
							<div class="label_info_header" style="font-size: 10px; text-align: center">					
								<xsl:for-each select="MCCMainDashboardRpt/DataRefreshDate">						
									Below Dashboard data is as per last updated on date : <xsl:value-of select="LastDate"/>						
								</xsl:for-each>				
							</div>	
							<br></br>
							
							
							
							
							
							<!-- DML Count for AGGREGATE_GROUP WISE APPROVAL TABLE -->
							
							<!-- <div class="label_NPR"> -->
							<div class="label1">							
							[Section 1] : DML Count Aggregate-Group-Wise Submodules Obsolescence Dashboard
							</div>
							
							<table width="100%">
							
												
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									
											  
							
									<td colspan="17" bgcolor="#006699" align="center">
											<font color="#C8F8D6">										   
													[MCC] DML Count Aggregate-Group Wise : Submodules Obsolescence <u>Approval</u> Dashboard
											</font>
									</td>
									
									
														  						  
								</tr>
								
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									<!-- <td bgcolor="#006699" style="width: 100px; white-space: nowrap;"> -->
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">
									<font color="white">
										AGGREGATE<br></br>GROUP
										</font>
									</td>
								  
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">	
									<font color="white">
										Type of Count								
									</font>
									</td>																							

									<td bgcolor="#006699" align="center">
										<font color="white">										
										Total Raised							
										</font>
									</td>								
							
									<td bgcolor="#006699" align="center">
										<font color="white">										
										ERC Released						
										</font>
									</td>												
									<td bgcolor="#006699" align="center">
										<font color="white">										
										MBOM Released
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLP (PUNE)	Released							
										</font>
									</td>			  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLJ (JSR) Released								
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLL (LKO) Released								
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLU (UTK) Released							
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLD (DWD) Released							
										</font>
									</td>		  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDP (PUNE)	Released							
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDJ (JSR)	Released							
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDL (LKO)	Released						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDU (UTK)	Released						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDD (DWD)	Released							
										</font>
									</td>	
									<!-- <td bgcolor="#006699" align="center">
										<font color="white">										
										OBSOLETED Count
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">										
										SAP ARCHIVED
										</font>
									</td> -->
									
									
									
														  						  
								</tr>	
																		
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;" >
											<font color="#006699">										   
													<b>D-CAB</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_RELEASED_D-CAB">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														DML Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>	
														<!-- <b><xsl:value-of select="@Name"/></b><b><xsl:value-of select="@ID"/></b>															 -->
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<!-- <td bgcolor="#F0F9FF" align="center"> -->

														<!-- <font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>												 -->
													<!-- </td>														 -->
													
													<!-- <td bgcolor="#F0F9FF" align="center">											 -->
														<!-- <font color="#024A70"><xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/></font>											 -->
													<!-- </td> -->
													
											</xsl:for-each>	
											
								</tr>
																						
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>F-CHASSIS</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_RELEASED_F-CHASSIS">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														DML Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<!-- <td bgcolor="#F0F9FF" align="center">

														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>																									
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>										
													</td> -->
													
											</xsl:for-each>		
											
								</tr>																					
								
							
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>G-E_AND_E</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_RELEASED_G-E_AND_E">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														DML Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<!-- <td bgcolor="#F0F9FF" align="center">

														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
																											
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>											
													</td> -->
													
											</xsl:for-each>		
											
								</tr>
																					
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>H-POWERTRAIN</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_RELEASED_H-POWERTRAIN">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														DML Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<!-- <td bgcolor="#F0F9FF" align="center">

														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
																											
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>											
													</td> -->
													
											</xsl:for-each>
											
								</tr>
								
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>A-APPLICATION_ENGINEERING</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_RELEASED_A-APPLICATION_ENGINEERING">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														DML Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<!-- <td bgcolor="#F0F9FF" align="center">
														
														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>													
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>											
													</td> -->
													
											</xsl:for-each>
											
								</tr>
																						
																
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								<tr class="tr_nohover">								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										   
										 
										<td colspan="2" bgcolor="#006699" style="text-align: right">
											<font color="white"><b>DML AGGREGATE-GROUP WISE RELEASED TOTAL</b></font>
										</td>			   


												<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_RELEASED_TOTAL">
											
																										
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b></font>										
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/></b></font>										
													</td>													
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/></b></font>									
													</td>																						   
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/></b></font>									
													</td><td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/></b></font>									
													</td>																						   
													<!-- <td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/></b></font>								
													</td> -->
													
											</xsl:for-each>	
											
								</tr>
								
								
								
								<!-- <tr>
									<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>									  
								</tr> -->
								
										
							</table>
							
							<table width="100%">
							
												
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									
											  
							
									<td colspan="17" bgcolor="#006699" align="center">
											<font color="#FAA18F" size="1px">										   
													[MCC] DML Count Aggregate-Group Wise : Submodules Obsolescence <u>Pending</u> Dashboard
											</font>
									</td>
									
									
														  						  
								</tr>
								
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">
									<font color="white">
										AGGREGATE<br></br>GROUP
										</font>
									</td>
								  
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">	
									<font color="white">
										Type of Count								
									</font>
									</td>

									<td bgcolor="#006699" align="center">
										<font color="white">										
										Total Raised							
										</font>
									</td>								
							
									<td bgcolor="#006699" align="center">
										<font color="white">										
										ERC Pending						
										</font>
									</td>												
									<td bgcolor="#006699" align="center">
										<font color="white">										
										MBOM Pending
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLP (PUNE)	Pending							
										</font>
									</td>			  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLJ (JSR)	Pending							
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLL (LKO)	Pending							
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLU (UTK)	Pending							
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLD (DWD)	Pending							
										</font>
									</td>		  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDP (PUNE)	Pending							
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDJ (JSR)	Pending							
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDL (LKO)	Pending						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDU (UTK)	Pending						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDD (DWD)	Pending							
										</font>
									</td>	
									<!-- <td bgcolor="#006699" align="center">
										<font color="white">										
										OBSOLETE Pending
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">										
										SAP Pending
										</font>
									</td> -->
									
									
									
														  						  
								</tr>	
																		
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;" >
											<font color="#006699">										   
													<b>D-CAB</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_PENDING_D-CAB">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														DML Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">												
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<!-- <td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_aggrgrp_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapseAggrGrpPending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td> -->
													
											</xsl:for-each>	
											
								</tr>
																						
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>F-CHASSIS</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_PENDING_F-CHASSIS">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														DML Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<!-- <td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_aggrgrp_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapseAggrGrpPending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>										
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>										
													</td> -->
													
											</xsl:for-each>		
											
								</tr>																					
								
							
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>G-E_AND_E</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_PENDING_G-E_AND_E">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														DML Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>										
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>									
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<!-- <td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_aggrgrp_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapseAggrGrpPending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>									
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td> -->
													
											</xsl:for-each>		
											
								</tr>
																					
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>H-POWERTRAIN</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_PENDING_H-POWERTRAIN">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														DML Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<!-- <td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_aggrgrp_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapseAggrGrpPending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>										
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td> -->
													
											</xsl:for-each>		
											
								</tr>
								
								
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>A-APPLICATION_ENGINEERING</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_PENDING_A-APPLICATION_ENGINEERING">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														DML Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<!-- <td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_aggrgrp_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapseAggrGrpPending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>										
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td> -->
													
											</xsl:for-each>		
											
								</tr>
																						
																
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								<tr class="tr_nohover">								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										   
										 
										<td colspan="2" bgcolor="#006699" style="text-align: right">
											<font color="white"><b>DML AGGREGATE-GROUP-WISE PENDING TOTAL</b></font>
										</td>			   


												<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/DML_AGGRGRP_PENDING_TOTAL">
											
																										
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b></font>										
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/></b></font>										
													</td>													
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/></b></font>									
													</td>																						   
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/></b></font>									
													</td><td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/></b></font>									
													</td>																						   
													<!-- <td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/></b></font>								
													</td> -->
													
											</xsl:for-each>	
											
								</tr>
								
								
								
								<!-- <tr>
									<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>									  
								</tr> -->
								
										
							</table>
							
							<br></br>
							<br></br>
							
							
							
							<!-- AGGREGATE_GROUP WISE APPROVAL TABLE -->
							
							<!-- <div class="label_NPR"> -->
							<div class="label1">							
							[Section 2] : Aggregate-Group-Wise Submodules Obsolescence Dashboard
							</div>
							
							<table width="100%">
							
												
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									
											  
							
									<td colspan="17" bgcolor="#006699" align="center">
											<font color="#C8F8D6">										   
													[MCC] Aggregate-Group Wise : Submodules Obsolescence <u>Approval</u> Dashboard
											</font>
									</td>
									
									
														  						  
								</tr>
								
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									<!-- <td bgcolor="#006699" style="width: 100px; white-space: nowrap;"> -->
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">
									<font color="white">
										AGGREGATE<br></br>GROUP
										</font>
									</td>
								  
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">	
									<font color="white">
										Type of Count								
									</font>
									</td>																							

									<td bgcolor="#006699" align="center">
										<font color="white">										
										Total Raised							
										</font>
									</td>								
							
									<td bgcolor="#006699" align="center">
										<font color="white">										
										ERC Released						
										</font>
									</td>												
									<td bgcolor="#006699" align="center">
										<font color="white">										
										MBOM Released
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLP (PUNE)	Released							
										</font>
									</td>			  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLJ (JSR) Released								
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLL (LKO) Released								
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLU (UTK) Released							
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLD (DWD) Released							
										</font>
									</td>		  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDP (PUNE)	Released							
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDJ (JSR)	Released							
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDL (LKO)	Released						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDU (UTK)	Released						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDD (DWD)	Released							
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">										
										OBSOLETED Count
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">										
										SAP ARCHIVED
										</font>
									</td>
									
									
									
														  						  
								</tr>	
																		
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;" >
											<font color="#006699">										   
													<b>D-CAB</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_RELEASED_D-CAB">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>	
														<!-- <b><xsl:value-of select="@Name"/></b><b><xsl:value-of select="@ID"/></b>															 -->
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">

														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
														<!-- <a href="#" style="color: green;" class="modal_link_section" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
																<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b>
														</a> -->													
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<font color="#024A70"><xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/></font>											
													</td>
													
											</xsl:for-each>	
											
								</tr>
																						
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>F-CHASSIS</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_RELEASED_F-CHASSIS">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">

														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
														<!-- <a href="#" style="color: green;" class="modal_link_section" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
																<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b>
														</a> -->												
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>										
													</td>
													
											</xsl:for-each>		
											
								</tr>																					
								
							
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>G-E_AND_E</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_RELEASED_G-E_AND_E">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">

														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
														<!-- <a href="#" style="color: green;" class="modal_link_section" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
																<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b>
														</a> -->													
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>		
											
								</tr>
																					
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>H-POWERTRAIN</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_RELEASED_H-POWERTRAIN">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">

														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
														<!-- <a href="#" style="color: green;" class="modal_link_section" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
																<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b>
														</a> -->													
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>
											
								</tr>
								
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>A-APPLICATION_ENGINEERING</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_RELEASED_A-APPLICATION_ENGINEERING">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">
														
														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
														<!-- <a href="#" style="color: green;" class="modal_link_section" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
																<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b>
														</a> -->													
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>
											
								</tr>
																						
																
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								<tr class="tr_nohover">								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										   
										 
										<td colspan="2" bgcolor="#006699" style="text-align: right">
											<font color="white"><b>TOTAL</b></font>
										</td>			   


												<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_RELEASED_TOTAL">
											
																										
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b></font>										
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/></b></font>										
													</td>													
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/></b></font>									
													</td>																						   
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/></b></font>									
													</td><td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/></b></font>									
													</td>																						   
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/></b></font>								
													</td>
													
											</xsl:for-each>	
											
								</tr>
								
								
								
								<!-- <tr>
									<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>									  
								</tr> -->
								
										
							</table>
							
							
							<!-- AGGREGATE-GRP WISE PENDING TABLE -->
							
							<table width="100%">
							
												
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									
											  
							
									<td colspan="17" bgcolor="#006699" align="center">
											<font color="#FAA18F" size="1px">										   
													[MCC] Aggregate-Group Wise : Submodules Obsolescence <u>Pending</u> Dashboard
											</font>
									</td>
									
									
														  						  
								</tr>
								
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">
									<font color="white">
										AGGREGATE<br></br>GROUP
										</font>
									</td>
								  
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">	
									<font color="white">
										Type of Count								
									</font>
									</td>

									<td bgcolor="#006699" align="center">
										<font color="white">										
										Total Raised							
										</font>
									</td>								
							
									<td bgcolor="#006699" align="center">
										<font color="white">										
										ERC Pending						
										</font>
									</td>												
									<td bgcolor="#006699" align="center">
										<font color="white">										
										MBOM Pending
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLP (PUNE)	Pending							
										</font>
									</td>			  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLJ (JSR)	Pending							
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLL (LKO)	Pending							
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLU (UTK)	Pending							
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLD (DWD)	Pending							
										</font>
									</td>		  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDP (PUNE)	Pending							
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDJ (JSR)	Pending							
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDL (LKO)	Pending						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDU (UTK)	Pending						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDD (DWD)	Pending							
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">										
										OBSOLETE Pending
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">										
										SAP Pending
										</font>
									</td>
									
									
									
														  						  
								</tr>	
																		
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;" >
											<font color="#006699">										   
													<b>D-CAB</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_PENDING_D-CAB">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">												
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_aggrgrp_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapseAggrGrpPending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>	
											
								</tr>
																						
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>F-CHASSIS</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_PENDING_F-CHASSIS">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_aggrgrp_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapseAggrGrpPending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>										
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>										
													</td>
													
											</xsl:for-each>		
											
								</tr>																					
								
							
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>G-E_AND_E</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_PENDING_G-E_AND_E">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>										
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>									
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_aggrgrp_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapseAggrGrpPending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>									
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>		
											
								</tr>
																					
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>H-POWERTRAIN</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_PENDING_H-POWERTRAIN">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_aggrgrp_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapseAggrGrpPending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>										
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>		
											
								</tr>
								
								
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: left; white-space: nowrap;">
											<font color="#006699">										   
													<b>A-APPLICATION_ENGINEERING</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_PENDING_A-APPLICATION_ENGINEERING">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_aggrgrp_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapseAggrGrpPending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>										
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>		
											
								</tr>
																						
																
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								<tr class="tr_nohover">								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										   
										 
										<td colspan="2" bgcolor="#006699" style="text-align: right">
											<font color="white"><b>TOTAL</b></font>
										</td>			   


												<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/AGGRGRP_PENDING_TOTAL">
											
																										
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b></font>										
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/></b></font>										
													</td>													
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/></b></font>									
													</td>																						   
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/></b></font>									
													</td><td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/></b></font>									
													</td>																						   
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/></b></font>								
													</td>
													
											</xsl:for-each>	
											
								</tr>
								
								
								
								<!-- <tr>
									<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>									  
								</tr> -->
								
										
							</table>
							
							<div class="scrollable_div" id="myCollapseAggrGrpPending">
							  <center>						  
								Section to show data based on above click link.
								<br></br>
								Pls click on links in 'Total Obsolescence Pending' Column.
							  </center>
							</div>
							
							
							<br></br>
							<br></br>
							
							<!-- PLATFORM-WISE APPROVAL TABLE -->
							
							<!-- <div class="label_NPR"> -->
							<div class="label1">
							[Section 3] : Platform-Wise Submodules Obsolescence Dashboard
							</div>
							
							<table width="100%">
							
												
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									
											  
							
									<td colspan="17" bgcolor="#006699" align="center">
											<font color="#C8F8D6">										   
													[MCC] Platform-Wise : Submodules Obsolescence <u>Approval</u> Dashboard
											</font>
									</td>
									
									
														  						  
								</tr>
								
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">
									<font color="white">
										PRODUCT<br></br>LINE
										</font>
									</td>
								  
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">	
									<font color="white">
										Type of Count								
									</font>
									</td>																							

									<td bgcolor="#006699" align="center">
										<font color="white">										
										Total Raised							
										</font>
									</td>								
							
									<td bgcolor="#006699" align="center">
										<font color="white">										
										ERC Released						
										</font>
									</td>												
									<td bgcolor="#006699" align="center">
										<font color="white">										
										MBOM Released
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLP (PUNE)	Released							
										</font>
									</td>			  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLJ (JSR) Released								
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLL (LKO) Released								
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLU (UTK) Released							
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLD (DWD) Released							
										</font>
									</td>		  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDP (PUNE)	Released							
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDJ (JSR)	Released							
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDL (LKO)	Released						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDU (UTK)	Released						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDD (DWD)	Released							
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">										
										OBSOLETED Count
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">										
										SAP ARCHIVED
										</font>
									</td>
									
									
									
														  						  
								</tr>	
																		
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: center; white-space: nowrap;" >
											<font color="#006699">										   
													<b>HCV</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/PL_RELEASED_HCV">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>	
														<!-- <b><xsl:value-of select="@Name"/></b><b><xsl:value-of select="@ID"/></b>															 -->
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">
														
														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
														<!-- <a href="#" style="color: green;" class="modal_link_section" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
																<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b>
														</a> -->													
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<font color="#024A70"><xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/></font>											
													</td>
													
											</xsl:for-each>	
											
								</tr>
																						
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: center; white-space: nowrap;">
											<font color="#006699">										   
													<b>ILMCV</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/PL_RELEASED_ILMCV">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">
														
														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
														<!-- <a href="#" style="color: green;" class="modal_link_section" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
																<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b>
														</a> -->												
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>										
													</td>
													
											</xsl:for-each>		
											
								</tr>																					
								
							
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: center; white-space: nowrap;">
											<font color="#006699">										   
													<b>SCV</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/PL_RELEASED_SCV">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">

														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
														<!-- <a href="#" style="color: green;" class="modal_link_section" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
																<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b>
														</a> -->													
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>		
											
								</tr>
																					
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: center; white-space: nowrap;">
											<font color="#006699">										   
													<b>BUS</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/PL_RELEASED_BUS">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#DCFCE7" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">

														<font color="green"><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></font>
														
														<!-- <a href="#" style="color: green;" class="modal_link_section" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
																<b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b>
														</a> -->													
																									
													</td>														
													
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>
											
								</tr>
																						
																
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								<tr class="tr_nohover">								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										   
										 
										<td colspan="2" bgcolor="#006699" style="text-align: right">
											<font color="white"><b>TOTAL</b></font>
										</td>			   


												<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/PL_RELEASED_TOTAL">
											
																										
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SM_TOTAL"/></b></font>										
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_ERC_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_DML_MBOM_STATUS"/></b></font>										
													</td>													
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_PUNE_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_JSR_STATUS"/></b></font>									
													</td>																						   
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_LKO_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_UTK_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_APL_DWD_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_PUNE_STATUS"/></b></font>									
													</td><td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_JSR_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_LKO_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_UTK_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_STD_DWD_STATUS"/></b></font>									
													</td>																						   
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_OBSOLETED_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_RELEASED_SUM_SAP_ARCHIVED_STATUS"/></b></font>								
													</td>
													
											</xsl:for-each>	
											
								</tr>
								
								
								
								<!-- <tr>
									<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>									  
								</tr> -->
								
										
							</table>
							
						<!-- <div class="scrollable_div" id="myCollapse">
						  <center>						  
							Section to show data based on above click link.
							<br></br>
							Pls click on links in 'Total Obsolescence Pending' Column.
						  </center>
						</div> -->
							
							<!-- PLATFORM-WISE PENDING TABLE -->
							<!-- <br></br> -->
													
							<table width="100%">
							
												
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									
											  
							
									<td colspan="17" bgcolor="#006699" align="center">
											<font color="#FAA18F">										   
													[MCC] Platform-Wise : Submodules Obsolescence <u>Pending</u> Dashboard
											</font>
									</td>
									
									
														  						  
								</tr>
								
								<tr class="tr_nohover">	
									<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">
									<font color="white">
										PRODUCT<br></br>LINE
										</font>
									</td>
								  
									<td bgcolor="#006699" style="width: 100px; white-space: nowrap;">	
									<font color="white">
										Type of Count								
									</font>
									</td>

									<td bgcolor="#006699" align="center">
										<font color="white">										
										Total Raised							
										</font>
									</td>								
							
									<td bgcolor="#006699" align="center">
										<font color="white">										
										ERC Pending						
										</font>
									</td>												
									<td bgcolor="#006699" align="center">
										<font color="white">										
										MBOM Pending
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLP (PUNE)	Pending							
										</font>
									</td>			  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLJ (JSR)	Pending							
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLL (LKO)	Pending							
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLU (UTK)	Pending							
										</font>
									</td>
									
									<td bgcolor="#006699" align="center">
										<font color="white">
											APLD (DWD)	Pending							
										</font>
									</td>		  
							
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDP (PUNE)	Pending							
										</font>
									</td>
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDJ (JSR)	Pending							
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDL (LKO)	Pending						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDU (UTK)	Pending						
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">
											STDD (DWD)	Pending							
										</font>
									</td>	
									<td bgcolor="#006699" align="center">
										<font color="white">										
										OBSOLETE Pending
										</font>
									</td>					
									<td bgcolor="#006699" align="center">
										<font color="white">										
										SAP Pending
										</font>
									</td>
									
									
									
														  						  
								</tr>	
																		
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: center; white-space: nowrap;" >
											<font color="#006699">										   
													<b>HCV</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/PL_PENDING_HCV">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">												
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapsePending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>	
											
								</tr>
																						
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: center; white-space: nowrap;">
											<font color="#006699">										   
													<b>ILMCV</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/PL_PENDING_ILMCV">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapsePending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>										
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>										
													</td>
													
											</xsl:for-each>		
											
								</tr>																					
								
							
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
									<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: center; white-space: nowrap;">
											<font color="#006699">										   
													<b>SCV</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/PL_PENDING_SCV">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>										
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>									
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>										
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapsePending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>									
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>		
											
								</tr>
																					
								
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								
								<tr>								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										 
										<td bgcolor="#AED6F1" style="width: 100px; text-align: center; white-space: nowrap;">
											<font color="#006699">										   
													<b>BUS</b>
											</font>
										</td>

											<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/PL_PENDING_BUS">
											
													<td style="width: 100px; text-align: right; white-space: nowrap;">									
														Submodules Count :													
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/>											
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/>											
													</td>												
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/>											
													</td>
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/>										
													</td>
													
													<td bgcolor="#FFE2E2" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/>											
													</td>
																																														   
													<td bgcolor="#F0F9FF" align="center">											
														<a href="#" style="color: red;" class="modal_link_section_pending" data-id="{@PLATFORM}" data-bs-toggle="scrollable_div" data-bs-target="#myCollapsePending">
																<xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/>
														</a>										
													</td>														
													<td bgcolor="#F0F9FF" align="center">											
														<xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/>											
													</td>
													
											</xsl:for-each>		
											
								</tr>
																						
																
								<!-- <tr>
								<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>
								</tr> -->
								
								<tr class="tr_nohover">								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
										   
										   
										 
										<td colspan="2" bgcolor="#006699" style="text-align: right">
											<font color="white"><b>TOTAL</b></font>
										</td>			   


												<xsl:for-each select="MCCMainDashboardRpt/SMObsDasboardData/PL_PENDING_TOTAL">
											
																										
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_SM_TOTAL"/></b></font>										
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_DML_ERC_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_DML_MBOM_STATUS"/></b></font>										
													</td>													
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_PUNE_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_JSR_STATUS"/></b></font>									
													</td>																						   
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_LKO_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_UTK_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_APL_DWD_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_PUNE_STATUS"/></b></font>									
													</td><td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_JSR_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_LKO_STATUS"/></b></font>									
													</td>
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_UTK_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_STD_DWD_STATUS"/></b></font>									
													</td>																						   
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_OBSOLETED_STATUS"/></b></font>									
													</td>														
													<td bgcolor="#006699">											
														<font color="white"><b><xsl:value-of select="SM_COUNT_PENDING_SUM_SAP_ARCHIVED_STATUS"/></b></font>								
													</td>
													
											</xsl:for-each>	
											
								</tr>
								
								
								
								<!-- <tr>
									<td class="tr_nohover" colspan="25" bgcolor="#006699"></td>									  
								</tr> -->
								
										
							</table>
							
							
						<div class="scrollable_div" id="myCollapsePending">
						  <center>						  
							Section to show data based on above click link.
							<br></br>
							Pls click on links in 'Total Obsolescence Pending' Column.
						  </center>
						</div>
							
						
							
						<!-- ############### -->			
						
				
						
											
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsReleasedData_HCV" style="display: none;">	
							 <div id="item-HCV">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Product-Line <u>RELEASED HCV</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_PRODUCT = 'HCV'">
														<xsl:if test="@OBSOLETED_STATUS = 'Obsolete'">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td align="center"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																<td align="center"><xsl:value-of select="@DML_ERC_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@DML_MBOM_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_PUNE_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_JSR_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_LKO_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_UTK_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>														
														</xsl:if>																											
													</xsl:if>	
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>


						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsReleasedData_ILMCV" style="display: none;">	
							 <div id="item-ILMCV">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Product-Line <u>RELEASED ILMCV</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_PRODUCT = 'ILMCV'">
														<xsl:if test="@OBSOLETED_STATUS = 'Obsolete'">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td align="center"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																<td align="center"><xsl:value-of select="@DML_ERC_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@DML_MBOM_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_PUNE_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_JSR_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_LKO_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_UTK_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>														
														</xsl:if>																											
													</xsl:if>	
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsReleasedData_SCV" style="display: none;">	
							 <div id="item-SCV">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Product-Line <u>RELEASED SCV</u></h6></center>															
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_PRODUCT = 'SCV'">
														<xsl:if test="@OBSOLETED_STATUS = 'Obsolete'">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td align="center"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																<td align="center"><xsl:value-of select="@DML_ERC_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@DML_MBOM_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_PUNE_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_JSR_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_LKO_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_UTK_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>														
														</xsl:if>																											
													</xsl:if>	
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsReleasedData_BUS" style="display: none;">	
							 <div id="item-BUS">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Product-Line <u>RELEASED BUS</u></h6></center>															
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_PRODUCT = 'BUS'">
														<xsl:if test="@OBSOLETED_STATUS = 'Obsolete'">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td align="center"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																<td align="center"><xsl:value-of select="@DML_ERC_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@DML_MBOM_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_PUNE_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_JSR_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_LKO_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_UTK_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@APL_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>														
														</xsl:if>																											
													</xsl:if>	
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_PENDING_HCV" style="display: none;">	
							 <div id="item-PENDING_HCV">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Product-Line <u>PENDING HCV</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_PRODUCT = 'HCV'">
														<xsl:if test="@OBSOLETED_STATUS = ''">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_ERC_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_ERC_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_ERC_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_MBOM_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_MBOM_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_MBOM_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_PUNE_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_PUNE_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_PUNE_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>													
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_JSR_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_JSR_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_JSR_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>																
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_LKO_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_LKO_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_LKO_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>												

																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_UTK_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_UTK_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_UTK_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_DWD_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_DWD_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_DWD_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>														
														</xsl:if>																											
													</xsl:if>														
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>																	
								</div>							  
							</div>
						</div>
						
						
												
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_PENDING_ILMCV" style="display: none;">	
							 <div id="item-PENDING_ILMCV">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Product-Line <u>PENDING ILMCV</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_PRODUCT = 'ILMCV'">
														<xsl:if test="@OBSOLETED_STATUS = ''">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_ERC_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_ERC_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_ERC_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_MBOM_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_MBOM_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_MBOM_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_PUNE_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_PUNE_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_PUNE_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>													
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_JSR_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_JSR_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_JSR_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>																
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_LKO_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_LKO_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_LKO_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>												

																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_UTK_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_UTK_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_UTK_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_DWD_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_DWD_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_DWD_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>
														</xsl:if>																											
													</xsl:if>																									
																									
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>																		
								</div>							  
							</div>
						</div>
						
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsData_PENDING_SCV" style="display: none;">	
							 <div id="item-PENDING_SCV">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Product-Line <u>PENDING SCV</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_PRODUCT = 'SCV'">
														<xsl:if test="@OBSOLETED_STATUS = ''">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_ERC_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_ERC_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_ERC_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_MBOM_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_MBOM_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_MBOM_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_PUNE_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_PUNE_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_PUNE_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>													
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_JSR_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_JSR_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_JSR_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>																
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_LKO_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_LKO_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_LKO_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>												

																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_UTK_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_UTK_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_UTK_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_DWD_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_DWD_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_DWD_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>
														</xsl:if>																											
													</xsl:if>																									
																									
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  																		
								</div>							  
							</div>
						</div>
						
					
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsData_PENDING_BUS" style="display: none;">	
							 <div id="item-PENDING_BUS">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Product-Line <u>PENDING BUS</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_PRODUCT = 'BUS'">
														<xsl:if test="@OBSOLETED_STATUS = ''">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_ERC_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_ERC_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_ERC_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_MBOM_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_MBOM_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_MBOM_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_PUNE_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_PUNE_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_PUNE_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>													
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_JSR_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_JSR_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_JSR_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>																
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_LKO_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_LKO_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_LKO_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>												

																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_UTK_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_UTK_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_UTK_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_DWD_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_DWD_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_DWD_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>
														</xsl:if>																											
													</xsl:if>																									
																									
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  																	
								</div>							  
							</div>
						</div>
						
						<!-- AGGREGATE-WISE DETAIL DATA -->
						
						
						
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsData_PENDING_D-CAB" style="display: none;">	
							 <div id="item-PENDING_D-CAB">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Aggregate-Group <u>D-CAB</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_AGGREGATE_GROUP = 'D-CAB'">
														<xsl:if test="@OBSOLETED_STATUS = ''">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_ERC_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_ERC_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_ERC_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_MBOM_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_MBOM_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_MBOM_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_PUNE_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_PUNE_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_PUNE_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>													
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_JSR_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_JSR_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_JSR_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>																
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_LKO_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_LKO_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_LKO_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>												

																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_UTK_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_UTK_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_UTK_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_DWD_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_DWD_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_DWD_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>
														</xsl:if>																											
													</xsl:if>																									
																									
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
																	
								</div>							  
							</div>
						</div>
						
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsData_PENDING_F-CHASSIS" style="display: none;">	
							 <div id="item-PENDING_F-CHASSIS">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Aggregate-Group <u>F-CHASSIS</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_AGGREGATE_GROUP = 'F-CHASSIS'">
														<xsl:if test="@OBSOLETED_STATUS = ''">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_ERC_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_ERC_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_ERC_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_MBOM_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_MBOM_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_MBOM_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_PUNE_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_PUNE_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_PUNE_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>													
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_JSR_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_JSR_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_JSR_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>																
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_LKO_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_LKO_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_LKO_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>												

																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_UTK_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_UTK_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_UTK_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_DWD_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_DWD_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_DWD_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>
														</xsl:if>																											
													</xsl:if>																									
																									
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
																	
								</div>							  
							</div>
						</div>
						
						
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsData_PENDING_G-E_AND_E" style="display: none;">	
							 <div id="item-PENDING_G-E_AND_E">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Aggregate-Group <u>G-E_AND_E</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_AGGREGATE_GROUP = 'G-E_AND_E'">
														<xsl:if test="@OBSOLETED_STATUS = ''">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_ERC_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_ERC_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_ERC_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_MBOM_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_MBOM_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_MBOM_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_PUNE_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_PUNE_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_PUNE_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>													
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_JSR_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_JSR_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_JSR_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>																
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_LKO_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_LKO_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_LKO_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>												

																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_UTK_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_UTK_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_UTK_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_DWD_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_DWD_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_DWD_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>
														</xsl:if>																											
													</xsl:if>																									
																									
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
																		
								</div>							  
							</div>
						</div>
						
						
						
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsData_PENDING_H-POWERTRAIN" style="display: none;">	
							 <div id="item-PENDING_H-POWERTRAIN">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Aggregate-Group <u>H-POWERTRAIN</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_AGGREGATE_GROUP = 'H-POWERTRAIN'">
														<xsl:if test="@OBSOLETED_STATUS = ''">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_ERC_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_ERC_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_ERC_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_MBOM_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_MBOM_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_MBOM_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_PUNE_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_PUNE_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_PUNE_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>													
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_JSR_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_JSR_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_JSR_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>																
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_LKO_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_LKO_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_LKO_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>												

																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_UTK_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_UTK_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_UTK_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_DWD_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_DWD_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_DWD_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>
														</xsl:if>																											
													</xsl:if>																									
																									
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
																		
								</div>							  
							</div>
						</div>
						
						
						
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsData_PENDING_A-APPLICATION_ENGINEERING" style="display: none;">	
							 <div id="item-PENDING_A-APPLICATION_ENGINEERING">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Showing results for clicked Aggregate-Group <u>A-APPLICATION_ENGINEERING</u></h6></center>											
																
																						
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<xsl:if test="@PART_AGGREGATE_GROUP = 'A-APPLICATION_ENGINEERING'">
														<xsl:if test="@OBSOLETED_STATUS = ''">
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_ERC_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_ERC_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_ERC_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_MBOM_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_MBOM_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_MBOM_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_PUNE_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_PUNE_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_PUNE_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>													
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_JSR_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_JSR_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_JSR_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>																
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_LKO_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_LKO_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_LKO_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>												

																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_UTK_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_UTK_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_UTK_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_DWD_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_DWD_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_DWD_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td>
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>
														</xsl:if>																											
													</xsl:if>																									
																									
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
																	
								</div>							  
							</div>
						</div>
						
											
						
						<!-- ############### -->

					
						<!-- Hidden divs for each item's modal content -->
						<div id="modal-data" style="display: none;">
						 
							 <div id="item-HCV-MODAL">
							<div class="container">							
								<div class="row">									
									<div class="col-sm-12">	
											<center>																
											<!-- <center><font color="#006699"><h3><b>Vehicle Compliance Report Dashboard</b></h3></font></center> -->
											
											Search : <input id="myInputVCRDBSearch" type="text" placeholder="Search in below table.."></input>
											<br></br>

											<table>			

													<tr bgcolor="#006699">
													  <th><b>ERC_DML</b></th>
													  <th><b>STAT/REL_DATE</b></th>								  				   
													  <th><b>SRL#</b></th>							  
														<th><b>SUBMOD_NO</b></th>
														<th><b>REV_SEQ</b></th>
														<th><b>PRODUCT</b></th>	
														<th><b>TYPE</b></th>
														<th><b>MODULE_ADDR</b></th>
														<th><b>AGGR_GRP/AGGR/MOD_GRP/MOD</b></th>							  
														<th><b>DR/AR</b></th>															  
													  <th><b>RELEASE_STATUS</b></th>								  
													</tr>
													
													
													<tbody id="myTableVCRDashboard">
													<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
														
														<xsl:if test="PART_PRODUCT = 'HCV'">

																<tr>
																   <td align="center"><xsl:value-of select="ERC_DML_NO"/></td>									   
																	<td style="width: 120px;">
																		<xsl:value-of select="ERC_DML_REL_STATUS"/>
																		<br></br>
																		<xsl:value-of select="ERC_DML_REL_DATE"/>
																   </td>
																   
																   <td align="center"><xsl:value-of select="PART_SRL"/></td>									
																	 <td bgcolor="#f5b7b1"><b><xsl:value-of select="PART_NO"/></b></td>
																   <td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
																   <td align="center"><xsl:value-of select="PART_PRODUCT"/></td>
																   <td align="center"><xsl:value-of select="PART_TYPE"/></td>
																   <td><xsl:value-of select="PART_MODULE_ADDR"/></td>													  						   
																 <td style="text-align: left;">
																		<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																		<br></br>
																		<xsl:value-of select="PART_AGGREGATE"/>
																	  <br></br>
																	  <xsl:value-of select="PART_MODULE_GROUP"/>
																	  <br></br>
																	  <xsl:value-of select="PART_MODULE"/>
																	</td>									 										 
																 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
																 <td style="text-align: left;">
																	<font color="red">
																	<xsl:value-of select="PART_RELEASE_STATUS"/>
																 </font>
																 </td>											
																</tr>
													
														</xsl:if>																										
														
													</xsl:for-each>
													</tbody>
											</table>
											</center>
									</div>
								</div>  

								
								<center>
								<font size="2px">Copyright@2025 PLM Team</font>
								</center>
								
							</div>


							  
							</div>
						  
						</div>


						<!-- Bootstrap Modal -->
						<div class="modal fade" id="itemModal" tabindex="-1" aria-hidden="true">
						  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
							<div class="modal-content">
							  <div class="modal-header">
								<h5 class="modal-title">Item Details</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
							  </div>
							  <div class="modal-body" id="modalContent">
								<!-- Filled dynamically by JS -->
								<p>Select an item to view details.</p>
							  </div>
							</div>
						  </div>
						</div>	

		<!-- JavaScript to copy content from hidden div into modal -->
						
        <script type="text/javascript">
          <![CDATA[
		  document.addEventListener('DOMContentLoaded', function () {
						document.querySelectorAll('.modal-link').forEach(function (link) {
						  link.addEventListener('click', function (e) {
							e.preventDefault();
							const itemId = this.getAttribute('data-id');
							alert('Pls proceed to show data for Product-line : ' + itemId);
							const content = document.getElementById('item-' + itemId);
							<!-- alert(111); -->
							alert(content.innerHTML);
							if (content) {
							  document.getElementById('modalContent').innerHTML = content.innerHTML;							  
							} else {
							  document.getElementById('modalContent').innerHTML = "<p>Item not found.</p>";
							}
						  });
						});
					  });		  
          ]]>
        </script>	
		
		 <script type="text/javascript">
          <![CDATA[
		  document.addEventListener('DOMContentLoaded', function () {
						document.querySelectorAll('.modal_link_section').forEach(function (link) {
						  link.addEventListener('click', function (e) {
							e.preventDefault();
							const itemId = this.getAttribute('data-id');
							//alert('Pls proceed to show data for Product-line : ' + itemId);
							const content = document.getElementById('item-' + itemId);
							<!-- alert(111); -->
							//alert(content.innerHTML);
							if (content) {
							  document.getElementById('myCollapse').innerHTML = content.innerHTML;							  
							} else {
							  document.getElementById('myCollapse').innerHTML = "<p>Item not found.</p>";
							}
						  });
						});
					  });

          ]]>
        </script>
													
							<!-- <div class="label_info">
							Above table shows stage-wise approval details for pFirst requests as approved for VC-Obsolescence and its VCs/DML release status in TCUA-CV PLM system.
							</div> -->
							
				</div>
				<div class="col-sm-1">
																	
						<!-- <div class="scrollable_div" id="myCollapse">
						  <center>						  
							Section to show data based on above click link.
							<br></br>
							Pls click on links in 'Total Obsolescence Pending' Column.
						  </center>
						</div> -->	
				
				</div>
				
		</div> <!-- row end -->		

<br></br>
<!--

AGGREGATE_WISE
AGGREGATE_WISE
AGGREGATE_WISE
AGGREGATE_WISE
AGGREGATE_WISE
AGGREGATE_WISE

-->

				<div class="row">	
				<div class="col-sm-1"></div>
				<div class="col-sm-10">
				
					<!-- <div class="label_NPR">[Section 2] : VC Obsolescence Approval Status</div> -->
						
						<!-- <div class="label2"></div> -->						
												
						<!-- <div class="label_blue">
							[MCC] Submodules Obsolescence Dashboard.
						</div>
						<br></br> -->
						
							
						<!-- ############### -->			
						
				
						
											
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_HCV" style="display: none;">	
							 <div id="item-HCV">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											<br></br>
											<center><h6>Showing results for clicked Product-Line <u>HCV</u></h6></center>
											
											<table>
												<tr bgcolor="#006699">													  					  
													<th><b>SUBMOD_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PRODUCT</b></th>																
													<th><b>MODULE_ADDR</b></th>
													<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
													<th><b>DR/AR</b></th>
													<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
												   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
													<th><b>PENDING WITH USER</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
													
													<xsl:if test="PART_PRODUCT = 'HCV'">
														<tr>															  
															<td bgcolor="#FFE2E2"><b><xsl:value-of select="PART_NO"/></b></td>
															<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
															<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
															<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
															<td style="text-align: left;">
																<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_AGGREGATE"/>
																<br></br>
																<xsl:value-of select="PART_MODULE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_MODULE"/>
															 </td>									 										 
															 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
															 <td style="text-align: left;">																		
																<xsl:value-of select="PART_RELEASE_STATUS"/>				 
															 </td>																		
															<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
															<td style="text-align: left;"> </td>																	 
														</tr>													
													</xsl:if>																									
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>					  
						
						
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_ILMCV" style="display: none;">	
							 <div id="item-ILMCV">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											<br></br>
											<center><h6>Showing results for clicked Product-Line <u>ILMCV</u></h6></center>
											
											<table>
												<tr bgcolor="#006699">													  					  
													<th><b>SUBMOD_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PRODUCT</b></th>																
													<th><b>MODULE_ADDR</b></th>
													<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
													<th><b>DR/AR</b></th>
													<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
												   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
													<th><b>PENDING WITH USER</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
													
													<xsl:if test="PART_PRODUCT = 'ILMCV'">
														<tr>															  
															<td bgcolor="#FFE2E2"><b><xsl:value-of select="PART_NO"/></b></td>
															<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
															<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
															<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
															<td style="text-align: left;">
																<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_AGGREGATE"/>
																<br></br>
																<xsl:value-of select="PART_MODULE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_MODULE"/>
															 </td>									 										 
															 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
															 <td style="text-align: left;">																		
																<xsl:value-of select="PART_RELEASE_STATUS"/>				 
															 </td>																		
															<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
															<td style="text-align: left;"> </td>																	 
														</tr>													
													</xsl:if>																									
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
												
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_BUS" style="display: none;">	
							 <div id="item-BUS">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											<br></br>
											<center><h6>Showing results for clicked Product-Line <u>BUS</u></h6></center>
											
											<table>
												<tr bgcolor="#006699">													  					  
													<th><b>SUBMOD_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PRODUCT</b></th>																
													<th><b>MODULE_ADDR</b></th>
													<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
													<th><b>DR/AR</b></th>
													<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
												   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
													<th><b>PENDING WITH USER</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
													
													<xsl:if test="PART_PRODUCT = 'BUS'">
														<tr>															  
															<td bgcolor="#FFE2E2"><b><xsl:value-of select="PART_NO"/></b></td>
															<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
															<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
															<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
															<td style="text-align: left;">
																<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_AGGREGATE"/>
																<br></br>
																<xsl:value-of select="PART_MODULE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_MODULE"/>
															 </td>									 										 
															 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
															 <td style="text-align: left;">																		
																<xsl:value-of select="PART_RELEASE_STATUS"/>				 
															 </td>																		
															<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
															<td style="text-align: left;"> </td>																	 
														</tr>													
													</xsl:if>																									
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_A-APPLICATION_ENGG" style="display: none;">	
							 <div id="item-A-APPLICATION_ENGG">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											<br></br>
											<center><h6>Showing results for clicked Product-Line <u>A-APPLICATION_ENGG</u></h6></center>
											
											<table>
												<tr bgcolor="#006699">													  					  
													<th><b>SUBMOD_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PRODUCT</b></th>																
													<th><b>MODULE_ADDR</b></th>
													<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
													<th><b>DR/AR</b></th>
													<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
												   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
													<th><b>PENDING WITH USER</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
													
													<xsl:if test="PART_AGGREGATE_GROUP = 'A-APPLICATION_ENGG'">
														<tr>															  
															<td bgcolor="#FFE2E2"><b><xsl:value-of select="PART_NO"/></b></td>
															<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
															<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
															<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
															<td style="text-align: left;">
																<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_AGGREGATE"/>
																<br></br>
																<xsl:value-of select="PART_MODULE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_MODULE"/>
															 </td>									 										 
															 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
															 <td style="text-align: left;">																		
																<xsl:value-of select="PART_RELEASE_STATUS"/>				 
															 </td>																		
															<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
															<td style="text-align: left;"> </td>																	 
														</tr>													
													</xsl:if>																									
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>

						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_D-CAB" style="display: none;">	
							 <div id="item-D-CAB">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											<br></br>
											<center><h6>Showing results for clicked Product-Line <u>D-CAB</u></h6></center>
											
											<table>
												<tr bgcolor="#006699">													  					  
													<th><b>SUBMOD_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PRODUCT</b></th>																
													<th><b>MODULE_ADDR</b></th>
													<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
													<th><b>DR/AR</b></th>
													<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
												   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
													<th><b>PENDING WITH USER</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
													
													<xsl:if test="PART_AGGREGATE_GROUP = 'D-CAB'">
														<tr>															  
															<td bgcolor="#FFE2E2"><b><xsl:value-of select="PART_NO"/></b></td>
															<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
															<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
															<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
															<td style="text-align: left;">
																<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_AGGREGATE"/>
																<br></br>
																<xsl:value-of select="PART_MODULE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_MODULE"/>
															 </td>									 										 
															 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
															 <td style="text-align: left;">																		
																<xsl:value-of select="PART_RELEASE_STATUS"/>				 
															 </td>																		
															<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
															<td style="text-align: left;"> </td>																	 
														</tr>													
													</xsl:if>																									
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_F-CHASSIS" style="display: none;">	
							 <div id="item-F-CHASSIS">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											<br></br>
											<center><h6>Showing results for clicked Product-Line <u>F-CHASSIS</u></h6></center>
											
											<table>
												<tr bgcolor="#006699">													  					  
													<th><b>SUBMOD_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PRODUCT</b></th>																
													<th><b>MODULE_ADDR</b></th>
													<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
													<th><b>DR/AR</b></th>
													<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
												   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
													<th><b>PENDING WITH USER</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
													
													<xsl:if test="PART_AGGREGATE_GROUP = 'F-CHASSIS'">
														<tr>															  
															<td bgcolor="#FFE2E2"><b><xsl:value-of select="PART_NO"/></b></td>
															<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
															<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
															<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
															<td style="text-align: left;">
																<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_AGGREGATE"/>
																<br></br>
																<xsl:value-of select="PART_MODULE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_MODULE"/>
															 </td>									 										 
															 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
															 <td style="text-align: left;">																		
																<xsl:value-of select="PART_RELEASE_STATUS"/>				 
															 </td>																		
															<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
															<td style="text-align: left;"> </td>																	 
														</tr>													
													</xsl:if>																									
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_G-E_AND_E" style="display: none;">	
							 <div id="item-G-E_AND_E">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											<br></br>
											<center><h6>Showing results for clicked Product-Line <u>G-E_AND_E</u></h6></center>
											
											<table>
												<tr bgcolor="#006699">													  					  
													<th><b>SUBMOD_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PRODUCT</b></th>																
													<th><b>MODULE_ADDR</b></th>
													<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
													<th><b>DR/AR</b></th>
													<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
												   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
													<th><b>PENDING WITH USER</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
													
													<xsl:if test="PART_AGGREGATE_GROUP = 'G-E_AND_E'">
														<tr>															  
															<td bgcolor="#FFE2E2"><b><xsl:value-of select="PART_NO"/></b></td>
															<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
															<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
															<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
															<td style="text-align: left;">
																<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_AGGREGATE"/>
																<br></br>
																<xsl:value-of select="PART_MODULE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_MODULE"/>
															 </td>									 										 
															 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
															 <td style="text-align: left;">																		
																<xsl:value-of select="PART_RELEASE_STATUS"/>				 
															 </td>																		
															<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
															<td style="text-align: left;"> </td>																	 
														</tr>													
													</xsl:if>																									
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_H-POWERTRAIN" style="display: none;">	
							 <div id="item-H-POWERTRAIN">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											<br></br>
											<center><h6>Showing results for clicked Product-Line <u>H-POWERTRAIN</u></h6></center>
											
											<table>
												<tr bgcolor="#006699">													  					  
													<th><b>SUBMOD_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PRODUCT</b></th>																
													<th><b>MODULE_ADDR</b></th>
													<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
													<th><b>DR/AR</b></th>
													<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
												   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
													<th><b>PENDING WITH USER</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
													
													<xsl:if test="PART_AGGREGATE_GROUP = 'H-POWERTRAIN'">
														<tr>															  
															<td bgcolor="#FFE2E2"><b><xsl:value-of select="PART_NO"/></b></td>
															<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
															<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
															<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
															<td style="text-align: left;">
																<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_AGGREGATE"/>
																<br></br>
																<xsl:value-of select="PART_MODULE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_MODULE"/>
															 </td>									 										 
															 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
															 <td style="text-align: left;">																		
																<xsl:value-of select="PART_RELEASE_STATUS"/>				 
															 </td>																		
															<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
															<td style="text-align: left;"> </td>																	 
														</tr>													
													</xsl:if>																									
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_K-VEHICLE" style="display: none;">	
							 <div id="item-K-VEHICLE">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											<br></br>
											<center><h6>Showing results for clicked Product-Line <u>K-VEHICLE</u></h6></center>
											
											<table>
												<tr bgcolor="#006699">													  					  
													<th><b>SUBMOD_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PRODUCT</b></th>																
													<th><b>MODULE_ADDR</b></th>
													<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
													<th><b>DR/AR</b></th>
													<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
												   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
													<th><b>PENDING WITH USER</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
													
													<xsl:if test="PART_AGGREGATE_GROUP = 'K-VEHICLE'">
														<tr>															  
															<td bgcolor="#FFE2E2"><b><xsl:value-of select="PART_NO"/></b></td>
															<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
															<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
															<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
															<td style="text-align: left;">
																<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_AGGREGATE"/>
																<br></br>
																<xsl:value-of select="PART_MODULE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_MODULE"/>
															 </td>									 										 
															 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
															 <td style="text-align: left;">																		
																<xsl:value-of select="PART_RELEASE_STATUS"/>				 
															 </td>																		
															<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
															<td style="text-align: left;"> </td>																	 
														</tr>													
													</xsl:if>																									
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
						<!-- Hidden divs for each item's modal content -->
						<div id="SectionSMObsPendingData_Z-DEV_MODULE" style="display: none;">	
							 <div id="item-Z-DEV_MODULE">
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											<br></br>
											<center><h6>Showing results for clicked Product-Line <u>Z-DEV_MODULE</u></h6></center>
											
											<table>
												<tr bgcolor="#006699">													  					  
													<th><b>SUBMOD_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PRODUCT</b></th>																
													<th><b>MODULE_ADDR</b></th>
													<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
													<th><b>DR/AR</b></th>
													<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
												   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
													<th><b>PENDING WITH USER</b></th>
												</tr>
																	
												<tbody id="myInputSearchBody">
												<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
													
													<xsl:if test="PART_AGGREGATE_GROUP = 'Z-DEV_MODULE'">
														<tr>															  
															<td bgcolor="#FFE2E2"><b><xsl:value-of select="PART_NO"/></b></td>
															<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
															<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
															<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
															<td style="text-align: left;">
																<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_AGGREGATE"/>
																<br></br>
																<xsl:value-of select="PART_MODULE_GROUP"/>
																<br></br>
																<xsl:value-of select="PART_MODULE"/>
															 </td>									 										 
															 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
															 <td style="text-align: left;">																		
																<xsl:value-of select="PART_RELEASE_STATUS"/>				 
															 </td>																		
															<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
															<td style="text-align: left;"> </td>																	 
														</tr>													
													</xsl:if>																									
													
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>  
									<center>
									<font size="2px">Copyright@2025 PLM Team</font>
									</center>									
								</div>							  
							</div>
						</div>
						
						<!-- ############### -->

					
						<!-- Hidden divs for each item's modal content -->
						<div id="modal-data" style="display: none;">
						 
							 <div id="item-HCV-MODAL">
							<div class="container">							
								<div class="row">									
									<div class="col-sm-12">	
											<center>																
											<!-- <center><font color="#006699"><h3><b>Vehicle Compliance Report Dashboard</b></h3></font></center> -->
											
											Search : <input id="myInputVCRDBSearch" type="text" placeholder="Search in below table.."></input>
											<br></br>

											<table>			

													<tr bgcolor="#006699">
													  <th><b>ERC_DML</b></th>
													  <th><b>STAT/REL_DATE</b></th>								  				   
													  <th><b>SRL#</b></th>							  
														<th><b>SUBMOD_NO</b></th>
														<th><b>REV_SEQ</b></th>
														<th><b>PRODUCT</b></th>	
														<th><b>TYPE</b></th>
														<th><b>MODULE_ADDR</b></th>
														<th><b>AGGR_GRP/AGGR/MOD_GRP/MOD</b></th>							  
														<th><b>DR/AR</b></th>															  
													  <th><b>RELEASE_STATUS</b></th>								  
													</tr>
													
													
													<tbody id="myTableVCRDashboard">
													<xsl:for-each select="MCCMainDashboardRpt/PendingSubModulesDetails/NotObsoletedSubModRow">
														
														<xsl:if test="PART_PRODUCT = 'HCV'">

																<tr>
																   <td align="center"><xsl:value-of select="ERC_DML_NO"/></td>									   
																	<td style="width: 120px;">
																		<xsl:value-of select="ERC_DML_REL_STATUS"/>
																		<br></br>
																		<xsl:value-of select="ERC_DML_REL_DATE"/>
																   </td>
																   
																   <td align="center"><xsl:value-of select="PART_SRL"/></td>									
																	 <td bgcolor="#f5b7b1"><b><xsl:value-of select="PART_NO"/></b></td>
																   <td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
																   <td align="center"><xsl:value-of select="PART_PRODUCT"/></td>
																   <td align="center"><xsl:value-of select="PART_TYPE"/></td>
																   <td><xsl:value-of select="PART_MODULE_ADDR"/></td>													  						   
																 <td style="text-align: left;">
																		<xsl:value-of select="PART_AGGREGATE_GROUP"/>
																		<br></br>
																		<xsl:value-of select="PART_AGGREGATE"/>
																	  <br></br>
																	  <xsl:value-of select="PART_MODULE_GROUP"/>
																	  <br></br>
																	  <xsl:value-of select="PART_MODULE"/>
																	</td>									 										 
																 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
																 <td style="text-align: left;">
																	<font color="red">
																	<xsl:value-of select="PART_RELEASE_STATUS"/>
																 </font>
																 </td>											
																</tr>
													
														</xsl:if>																										
														
													</xsl:for-each>
													</tbody>
											</table>
											</center>
									</div>
								</div>  

								
								<center>
								<font size="2px">Copyright@2025 PLM Team</font>
								</center>
								
							</div>


							  
							</div>
						  
						</div>


						<!-- Bootstrap Modal -->
						<div class="modal fade" id="itemModal" tabindex="-1" aria-hidden="true">
						  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
							<div class="modal-content">
							  <div class="modal-header">
								<h5 class="modal-title">Item Details</h5>
								<button type="button" class="btn-close" data-bs-dismiss="modal"></button>
							  </div>
							  <div class="modal-body" id="modalContent">
								<!-- Filled dynamically by JS -->
								<p>Select an item to view details.</p>
							  </div>
							</div>
						  </div>
						</div>	

		<!-- JavaScript to copy content from hidden div into modal -->
						
        <script type="text/javascript">
          <![CDATA[
		  document.addEventListener('DOMContentLoaded', function () {
						document.querySelectorAll('.modal-link').forEach(function (link) {
						  link.addEventListener('click', function (e) {
							e.preventDefault();
							const itemId = this.getAttribute('data-id');
							alert('Pls proceed to show data for Product-line : ' + itemId);
							const content = document.getElementById('item-' + itemId);
							<!-- alert(111); -->
							alert(content.innerHTML);
							if (content) {
							  document.getElementById('modalContent').innerHTML = content.innerHTML;							  
							} else {
							  document.getElementById('modalContent').innerHTML = "<p>Item not found.</p>";
							}
						  });
						});
					  });		  
          ]]>
        </script>	
		
		        <script type="text/javascript">
          <![CDATA[
		  document.addEventListener('DOMContentLoaded', function () {
						document.querySelectorAll('.modal_link_section').forEach(function (link) {
						  link.addEventListener('click', function (e) {
							e.preventDefault();
							const itemId = this.getAttribute('data-id');
							//alert('Pls proceed to show data for Product-line : ' + itemId);
							
							const content = document.getElementById('item-' + itemId);
							const show_content = document.getElementById('myCollapse');
							//alert("show_content :" + show_content);
							<!-- alert(111); -->
							//alert(content.innerHTML);
							if (content) {								
																		
								// Only add 'show' class if it's NOT already open
									//if (!show_content.classList.contains('show')) {
									//  show_content.classList.toggle('show');									  
									//}
								// If already open, do nothing (keeps it open)						 
							    
								show_content.classList.toggle('show');	
								document.getElementById('myCollapse').innerHTML = content.innerHTML;
							  
							} else {
							  document.getElementById('myCollapse').innerHTML = "<p>Item not found.</p>";
							}
						  });
						});
					  });

			
			document.addEventListener('DOMContentLoaded', function () {
						document.querySelectorAll('.modal_link_section_pending').forEach(function (link) {
						  link.addEventListener('click', function (e) {
							e.preventDefault();
							const itemId = this.getAttribute('data-id');
							//alert('Pls proceed to show data for Product-line : ' + itemId);
							
							const content = document.getElementById('item-' + itemId);
							const show_content = document.getElementById('myCollapsePending');
							//alert("show_content :" + show_content);
							<!-- alert(111); -->
							//alert(content.innerHTML);
							if (content) {								
																		
								// Only add 'show' class if it's NOT already open
									//if (!show_content.classList.contains('show')) {
									//  show_content.classList.toggle('show');									  
									//}
								// If already open, do nothing (keeps it open)						 
							    
								show_content.classList.toggle('show');	
								document.getElementById('myCollapsePending').innerHTML = content.innerHTML;
							  
							} else {
							  document.getElementById('myCollapsePending').innerHTML = "<p>Item not found.</p>";
							}
						  });
						});
					  });
					  
			
			document.addEventListener('DOMContentLoaded', function () {
						document.querySelectorAll('.modal_link_section_aggrgrp_pending').forEach(function (link) {
						  link.addEventListener('click', function (e) {
							e.preventDefault();
							const itemId = this.getAttribute('data-id');
							//alert('Pls proceed to show data for Product-line : ' + itemId);
							
							const content = document.getElementById('item-' + itemId);
							const show_content = document.getElementById('myCollapseAggrGrpPending');
							//alert("show_content :" + show_content);
							<!-- alert(111); -->
							//alert(content.innerHTML);
							if (content) {								
																		
								// Only add 'show' class if it's NOT already open
									//if (!show_content.classList.contains('show')) {
									//  show_content.classList.toggle('show');									  
									//}
								// If already open, do nothing (keeps it open)						 
							    
								show_content.classList.toggle('show');	
								document.getElementById('myCollapseAggrGrpPending').innerHTML = content.innerHTML;
							  
							} else {
							  document.getElementById('myCollapseAggrGrpPending').innerHTML = "<p>Item not found.</p>";
							}
						  });
						});
					  });
			
			
			
			function CloseSectionFunction() {
			
				const show_content = document.getElementById('myCollapse');				
				
				show_content.classList.toggle('close');
				location.reload();				
			}

					  
          ]]>
        </script>
													
							<!-- <div class="label_info">
							Above table shows stage-wise approval details for pFirst requests as approved for VC-Obsolescence and its VCs/DML release status in TCUA-CV PLM system.
							</div> -->
							
				</div>
				<div class="col-sm-1">
																	
						<!-- <div class="scrollable_div" id="myCollapse">
						  <center>						  
							Section to show data based on above click link.
							<br></br>
							Pls click on links in 'Total Obsolescence Pending' Column.
						  </center>
						</div>	 -->
				
				</div>
				
		</div> <!-- row end -->	



		
							
				
	<br></br>
	<hr style="height:1px;border-width:0;color:gray;background-color:gray"></hr>

			<center>
			<font size="1px">Copyright@2025 (PLM ERC Team)</font>
			</center>
						 

					

				
		</div> 	
				

		<!-- </div> -->
			
			 
	</div>


</div>

<div id="Tab2" class="tabcontent">
  
						<!-- Hidden divs for each item's modal content -->
						<!-- <div id="SO_Report" style="display: none;"> -->
						<div id="SO_Report">	
							 <!-- <div id="item-PENDING_ILMCV"> -->
								<div class="container-fluid">							
									<div class="row">									
										<div class="col-sm-12">	
											<center>																		
											<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
											
											<!-- <div class="label_alert" style="font-size: 10px; text-align: right">
												<a href="javascript:CloseSectionFunction()">Close_HCV_Section</a>				
											</div> -->
											
											<center><h6>Submodule Obsolescence Report</h6></center>											
																
																						
											Search : <input id="SOReportSearchID" type="text" placeholder="Search in below table.."></input>
											<br></br>
											
											<table width="100%">
												<tr bgcolor="#006699">													  					  
													<th><b>SR_NO</b></th>
													<th><b>ERC_DML_NO</b></th>
													<th><b>ERC_DML_CRE_DATE</b></th>
													<th><b>DML_PRODUCT</b></th>
													<th><b>PART_SRL</b></th>
													<th><b>PART_NO</b></th>
													<th><b>REV_SEQ</b></th>
													<th><b>PART_TYPE</b></th>
													<th><b>PART_PRODUCT</b></th>
													<th><b>PART_AGGREGATE_GROUP</b></th>
													<th><b>PART_AGGREGATE</b></th>
													<th><b>PART_MODULE_GROUP</b></th>
													<th><b>PART_MODULE</b></th>
													<th><b>PART_MODULE_ADDR</b></th>
													<th><b>PART_DR_STAT</b></th>
													<th><b>DML_ERC_STATUS</b></th>
													<th><b>DML_MBOM_STATUS</b></th>
													<th><b>APL_PUNE_STATUS</b></th>
													<th><b>APL_JSR_STATUS</b></th>
													<th><b>APL_LKO_STATUS</b></th>
													<th><b>APL_UTK_STATUS</b></th>
													<th><b>APL_DWD_STATUS</b></th>
													<th><b>STD_PUNE_STATUS</b></th>
													<th><b>STD_JSR_STATUS</b></th>
													<th><b>STD_LKO_STATUS</b></th>
													<th><b>STD_UTK_STATUS</b></th>
													<th><b>STD_DWD_STATUS</b></th>
													<th><b>OBSOLETED_STATUS</b></th>
													<th><b>SAP_ARCHIVED_STATUS</b></th>
												</tr>
																	
												<tbody id="TableBodySOReport">
												<xsl:for-each select="MCCMainDashboardRpt/AllSMDataAsPerTCUA/SM_DATA">
													
													<!-- <xsl:if test="@PART_PRODUCT = 'ILMCV'"> -->
														<!-- <xsl:if test="@OBSOLETED_STATUS = ''"> -->
															<tr>															  
																<td align="center"><xsl:value-of select="@SR_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_NO"/></td>	
																<td align="center"><xsl:value-of select="@ERC_DML_CRE_DATE"/></td>	
																<td align="center"><xsl:value-of select="@DML_PRODUCT"/></td>	
																<td align="center"><xsl:value-of select="@PART_SRL"/></td>	
																<td align="center"><xsl:value-of select="@PART_NO"/></td>	
																<td align="center"><xsl:value-of select="@REV_SEQ"/></td>	
																<td align="center"><xsl:value-of select="@PART_TYPE"/></td>	
																<td align="center"><xsl:value-of select="@PART_PRODUCT"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_AGGREGATE"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE_GROUP"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@PART_MODULE"/></td>	
																<td align="center"><xsl:value-of select="@PART_MODULE_ADDR"/></td>	
																<td align="center"><xsl:value-of select="@PART_DR_STAT"/></td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_ERC_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_ERC_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_ERC_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@DML_MBOM_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@DML_MBOM_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@DML_MBOM_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_PUNE_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_PUNE_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_PUNE_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>													
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_JSR_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_JSR_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_JSR_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>																
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_LKO_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_LKO_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_LKO_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>												

																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_UTK_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_UTK_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_UTK_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>
																
																<td style="width: 150px; text-align: center; white-space: nowrap;">
																	<xsl:choose>
																	  <xsl:when test="contains(@APL_DWD_STATUS,'Working')">
																		<font color="red"><xsl:value-of select="@APL_DWD_STATUS"/></font>
																	  </xsl:when>
																	  <xsl:otherwise>
																		<xsl:value-of select="@APL_DWD_STATUS"/>
																	  </xsl:otherwise>
																	</xsl:choose>
																</td>	
																
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_PUNE_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_JSR_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_LKO_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_UTK_STATUS"/></td>	
																<td style="width: 150px; text-align: center; white-space: nowrap;"><xsl:value-of select="@STD_DWD_STATUS"/></td>	
																<!-- <td align="center"><xsl:value-of select="@OBSOLETED_STATUS"/></td> -->
																
																<xsl:if test="@OBSOLETED_STATUS = 'Obsolete'">
																<td bgcolor="#DCFCE7" align="center"><font color="green"><xsl:value-of select="@OBSOLETED_STATUS"/></font></td>
																</xsl:if>
																
																<xsl:if test="@OBSOLETED_STATUS = ''">
																 <td bgcolor="#FFE2E2" align="center"><font color="red"><xsl:value-of select="@OBSOLETED_STATUS"/></font></td>
																</xsl:if>
																															
																
																<td align="center"><xsl:value-of select="@SAP_ARCHIVED_STATUS"/></td>										 
															</tr>
														<!-- </xsl:if>																											 -->
													<!-- </xsl:if>																									 -->
																									
												</xsl:for-each>
												</tbody>
											</table>
											</center>
										</div>
									</div>																		
								</div>							  
							<!-- </div> -->
						</div>

</div>

<div id="Tab3" class="tabcontent">

 	<div id="SectionSMObsApproved">	
		
		<div class="container">

			<div class="row">
				<div class="label_green">
				Absoleted Submodules.
				</div>	
			</div>
			<br></br>
			<div class="row">									
				<div class="col-sm-12">	
					<center>																		
					<!-- Search Data in below Table : <input id="myInputSearchID" style="width: 300px;" type="text" placeholder="Search in below table.."></input> -->
					
					<br></br>
					<table>
						<tr bgcolor="#006699">													  					  
							<th><b>SUBMOD_NO</b></th>
							<th><b>REV_SEQ</b></th>
							<th><b>PRODUCT</b></th>																
							<th><b>MODULE_ADDR</b></th>
							<th style="text-align: left;"><b>AGGR_GRP<br></br>AGGR<br></br>MOD_GRP<br></br>MOD</b></th>							  
							<th><b>DR/AR</b></th>
							<th><b>SUBMODULE<br></br>RELEASE STATUS</b></th>																
						   <th><b>DML STAGES<br></br>RELEASE STATUS/DETAILS</b></th>
							<!-- <th><b>PENDING WITH USER</b></th> -->
						</tr>
											
						<tbody id="myInputSearchBody">
						<xsl:for-each select="MCCMainDashboardRpt/ApprovedSubModuleDetails/ObsoletedSubModRow">
							
							
							<tr>															  
								<td bgcolor="#DCFCE7"><b><xsl:value-of select="PART_NO"/></b></td>
								<td align="center"><xsl:value-of select="PART_REV_SEQ"/></td>
								<td align="center"><xsl:value-of select="PART_PRODUCT"/></td>	   
								<td><xsl:value-of select="PART_MODULE_ADDR"/></td>										  						   
								<td style="width: 300px; text-align: left;">
									<xsl:value-of select="PART_AGGREGATE_GROUP"/>
									<br></br>
									<xsl:value-of select="PART_AGGREGATE"/>
									<br></br>
									<xsl:value-of select="PART_MODULE_GROUP"/>
									<br></br>
									<xsl:value-of select="PART_MODULE"/>
								 </td>									 										 
								 <td align="center"><xsl:value-of select="PART_DR_STAT"/></td>								     
								 <td style="text-align: left;">																		
									<xsl:value-of select="PART_RELEASE_STATUS"/>				 
								 </td>																		
								<td style="width: 600px; text-align: left;"><xsl:value-of select="DML_RELEASE_STATUS_STRING"/></td>
								<!-- <td style="text-align: left;"> </td>																	  -->
							</tr>													
																															
							
						</xsl:for-each>
						</tbody>
					</table>
					</center>
				</div>
			</div>  
			<center>
			<font size="2px">Copyright@2025 PLM Team</font>
			</center>									
		</div>						  
		
	</div>

</div>


<div id="Tab4" class="tabcontent">
  <div class="container">
  <center>
  <h4>Help Page</h4>
   
  <div class="label_blue_help">
  Columns of Submodule Obsolescence Dashboard.
  </div>
  <div class="label_white_help">	
	
  </div>
  <br></br>
  
  <div class="label_blue_help">
  Other/Remarks
  </div>
  <div class="label_white_help">
	For any further queries/support, please get in touch with :-
	<br></br>
	TML : Ravindra Patil, Machhindra Kamthe, Aditya Dole
	<br></br>
	TTL : Ujjawal Kumar, Poonam Sah, Sourav Karak, Manisha Joshi
  </div>
  <br></br>
    			
  </center>
  </div>
</div>


	
	 <!--<canvas id="chartId" aria-label="chart" heigth="350" width="580"></canvas>-->
<!-- 	 <canvas id="myChart3" style="width:100%"></canvas>-->
	
	<script>
	
	
	<!-- function getRandomColor() {
	  var letters = '0123456789ABCDEF';
	  var color = '#';
	  for (var i = 0; i < 6; i++) {
		color += letters[Math.floor(Math.random() * 16)];
	  }
	  return color;
	}
	 -->
	
	</script>
	
  </body> 
</html> 

</xsl:template>
</xsl:stylesheet> 