<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40" >
    
    <xsl:output method="xml" version="1.0" indent="yes" />
    <xsl:strip-space elements="*"/>
    
    <xsl:template match="/">
        <xsl:call-template name="ReportHeader"></xsl:call-template>
    </xsl:template>
    
    <xsl:template name="ReportHeader">
        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">
            
            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="11" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="PropertyNameCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                </Style>                
            </Styles>
            
            <Worksheet ss:Name="Sheet1">
                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="50"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="300" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Row>  
                        <Cell ss:StyleID="s22" ss:MergeAcross='5'>
                            <Data ss:Type='String'>MCC MBOM Complete Library Details Report</Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Library Refreshed TimeStamp</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="SubMooduleDashboard/DataRefreshDate/LastDate"/>
                            </Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>AGGREGATE_GROUP</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>AGGREGATE</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>MODULE</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>MODULE_ADDRESS</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>ADDRESS_DESCRIPTION</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>MODULE_VARIETY</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>MODULE_NO</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>REVISION</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>SEQUENCE</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>DESCRIPTION</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>PRODUCT_LINE</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>PLATFORM</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>PROJECT_CODE</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>AR/DR_STATUS</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>MAX_AR/DR_STATUS</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>VEHICLE_LINK_STATUS</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>VEHICLE_LINK_COUNT</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>AGEING(in Days)</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>VEHICLE_LINK_PLATFORMWISE</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>PUNE_CS</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>LKN_CS</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>JSR_CS</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>UTK_CS</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>DWD_CS</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>DESIGN_GROUP</Data>
                        </Cell>
                    </Row>
                    <xsl:call-template name="generateDesignRevPartsList"></xsl:call-template>
                    <Row></Row>
                    <Row></Row>
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    
    <xsl:template name="generateDesignRevPartsList">
        <xsl:for-each select="SubMooduleDashboard/SubmoduleDetail">
			<Row>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="AggregateGrpName"/></Data>
				</Cell>
			    <Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="AggregateName"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="ModuleName"/></Data>
				</Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="SubmoduleName"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="SubmoduleDesc"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="SubmoduleDetailsVariety"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleNo"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleRev"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleSeq"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleDesc"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleProd"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmodulePlat"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleProj"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleDrAr"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleMax"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleVehLinkedFlag"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleVehCount"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleAgeing"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_SubmoduleVehPlat"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_Puncs"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_Lkncs"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_Jsrcs"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_Utkcs"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_Dwdcs"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TBL_DesGr"/></Data>
                </Cell>
			</Row>
        </xsl:for-each>
    </xsl:template>
    
</xsl:stylesheet>