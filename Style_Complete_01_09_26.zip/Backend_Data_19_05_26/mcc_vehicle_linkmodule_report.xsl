<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40" >
    
    <xsl:output method="xml" version="1.0" indent="yes" />
    <xsl:strip-space elements="*"/>
    
    <xsl:template match="/">
        <xsl:call-template name="ReportHeader"></xsl:call-template>
    </xsl:template>
    
    <xsl:template name="ReportHeader">
        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">
            
            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="11" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <!--<Alignment ss:Horizontal="Right"/>-->
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="PropertyNameCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                </Style>                
            </Styles>
            
            <Worksheet ss:Name="Sheet1">
                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="50"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="300" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Row>  
                        <Cell ss:StyleID="s22" ss:MergeAcross='5'>
                            <Data ss:Type='String'>Vehicle Link Module Status Report</Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Vehicle</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="VehLinkStatRpt/PartDetails/Veh"/>
                            </Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Revision</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="VehLinkStatRpt/PartDetails/Rev"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Sequence</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="VehLinkStatRpt/PartDetails/Seq"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Description</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="VehLinkStatRpt/PartDetails/Desc"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>AR/DR Status</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                <xsl:value-of select="VehLinkStatRpt/PartDetails/DRAR"/>
                            </Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Report Generation Time</Data>
                        </Cell>
                        <Cell ss:StyleID="s24" ss:MergeAcross='2'>
                            <Data ss:Type='String'>
                                 <xsl:value-of select="VehLinkStatRpt/PartDetails/DT"/>
                            </Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module Address</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module No</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Revision</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Sequence</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module Release Date</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Total Linked Vehicle</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Modules Project Code Linked Vehicle</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Vehicle Linked Project Code</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Status (Same/Different)</Data>
                        </Cell>
                    </Row>
                    <xsl:call-template name="generateDesignRevPartsList"></xsl:call-template>
                    <Row></Row>
                    <Row></Row>
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    
    <xsl:template name="generateDesignRevPartsList">
        <xsl:for-each select="VehLinkStatRpt/LinkDetails">
			<Row>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="Add"/></Data>
				</Cell>
			    <Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="Mod"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="ModR"/></Data>
				</Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="ModS"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="ModRD"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="TCount"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LCount"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LProjCode"/></Data>
                </Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="LStatus"/></Data>
                </Cell>
			</Row>
        </xsl:for-each>
    </xsl:template>
    
</xsl:stylesheet>