############################################################
## To generate part applicability matrix report
##############################################################

StartTime=`date`
echo -e "\nIn Execution Shell Argument Print Started...."

echo "PartList: -----> "$1

echo "User: -----> "$2

echo "Email: -----> "$3

echo -e "\nIn Execution Shell Argument Print Ended...."

cd /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_ModuleAppMatrix

nohup ./generatePartAppMatReport_FINAL_STEPS_V1.sh $1 $2 $3 > $StartTime.log&
