############################################################
## To generate part applicability matrix report
##############################################################

StartTime=`date`
echo -e "\nIn Execution Shell Argument Print Started...."

echo "PartList: -----> "$1

echo "User: -----> "$2

echo "Email: -----> "$3

echo -e "\nIn Execution Shell Argument Print Ended...."

cd /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_ModuleAppMatrix

echo "Started executing Program for Part List: $1"

/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_ModuleAppMatrix/tm_PartApplicability_Rpt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -PartList=$1 -User=$2 -Email=$3

echo "Ended executing Program for Part List: $1"
