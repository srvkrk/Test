//==================================================
//
//  Copyright 2012 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
//
//==================================================
#include "soapH.h"
#include "PartDetails.nsmap"
#include "stdsoap2.h"
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <epm/signoff.h>
#include <ce/ce.h>
#include <tc/folder.h>
#include <tccore/project.h>
//#include <tc/tc.h>
#include <tc/tc_startup.h>
#include <ae/datasettype.h>
#include <tccore/grm_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <base_utils/Mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/item_msg.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <common/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#include <tc/envelope.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <Fnd0Participant/participant.h>
#include <unistd.h>
#include <epm/cr.h>
#include <bom/bom_msg.h>
#include <cfm/cfm.h>
#define MAX_LINE_LENGTH 1000

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 

    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   // ffprintf(fp, stderr, "CopyTemplates Error(s): \n");
	//fprintf(fp,"CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
//        ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
//        ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
//		fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}


/*
extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new());

}
*/

extern int ITK_user_main(int argc, char *argv[])
{
  struct soap *soap = soap_new();
  soap->accept_timeout = 24*60*60;
  soap->send_timeout = soap->recv_timeout = 5;
  soap->transfer_timeout = 10;
  soap_ssl_init();
  if (soap_ssl_server_context(
								soap,
								SOAP_SSL_NO_AUTHENTICATION,
								NULL,
								NULL,
								NULL,
								NULL,
								NULL,
								NULL,
								NULL
								)
	  )
  {
    soap_print_fault(soap, stderr);
    exit(EXIT_FAILURE);
  }
  soap_serve(soap) ;
  soap_print_fault(soap, stderr);
  soap_destroy(soap);
  soap_end(soap);
  soap_free(soap);
  return 0;
}
;

char *GetLifecycleStateDisplay(char *DmlReasonCode)
{
	char	*Dml_ReasonDisplay			= NULL;

	Dml_ReasonDisplay=(char *)MEM_alloc(200);

	printf("\n Print DmlReasonCode==> [%s]",DmlReasonCode);fflush(stdout);
	if(tc_strcmp(DmlReasonCode,"T5_APLFinalReleased")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DR");
		tc_strcpy(Dml_ReasonDisplay,"APL Final Released");
	}
	if(tc_strcmp(DmlReasonCode,"T5_APLPre-Released")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"AD");
		tc_strcpy(Dml_ReasonDisplay,"APL Pre- Released");
	}
	if(tc_strcmp(DmlReasonCode,"T5_LcsAPLWrkg")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"QU");
		tc_strcpy(Dml_ReasonDisplay,"APLC Working");
	}
	if(tc_strcmp(DmlReasonCode,"T5_LcsAPLaWrkg")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CM");
		tc_strcpy(Dml_ReasonDisplay,"APLA Working");
	}
	if(tc_strcmp(DmlReasonCode,"T5_LcsAPLdWrkg")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"RR");
		tc_strcpy(Dml_ReasonDisplay,"APLD Working");
	}
	if(tc_strcmp(DmlReasonCode,"T5_LcsAPLjWrkg")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CR");
		tc_strcpy(Dml_ReasonDisplay,"APLJ Working");
	}
	if(tc_strcmp(DmlReasonCode,"T5_LcsAPLlWrkg")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ATR");
		tc_strcpy(Dml_ReasonDisplay,"APLL Working");
	}
	if(tc_strcmp(DmlReasonCode,"T5_LcsAPLpWrkg")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"EM");
		tc_strcpy(Dml_ReasonDisplay,"APLP Working");
	}
	if(tc_strcmp(DmlReasonCode,"T5_LcsAPLsWrkg")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFAF");
		tc_strcpy(Dml_ReasonDisplay,"APLS Working");
	}
	if(tc_strcmp(DmlReasonCode,"T5_LcsAPLuWrkg")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFSF");
		tc_strcpy(Dml_ReasonDisplay,"APLU Working");
	}
	if(tc_strcmp(DmlReasonCode,"T5_LcsAPLvWrkg")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFCF");
		tc_strcpy(Dml_ReasonDisplay,"APLV Working");
	}
	if(tc_strcmp(DmlReasonCode,"T5_LcsAplRlzd")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CMR");
		tc_strcpy(Dml_ReasonDisplay,"APLC Released");
	}
	if(tc_strcmp(DmlReasonCode,"CSC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CSC");
		tc_strcpy(Dml_ReasonDisplay,"CONDITION OF SUPPLY CHANGE");
	}
	if(tc_strcmp(DmlReasonCode,"SC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SC");
		tc_strcpy(Dml_ReasonDisplay,"SCOPE CHANGES");
	}
	if(tc_strcmp(DmlReasonCode,"RSP")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"RSP");
		tc_strcpy(Dml_ReasonDisplay,"RELEASE OF SPARES/KITS (NO NEW PART DEVELOPMENT)");
	}
	if(tc_strcmp(DmlReasonCode,"WR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"WR");
		tc_strcpy(Dml_ReasonDisplay,"WEIGHT REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"IFD")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"IFD");
		tc_strcpy(Dml_ReasonDisplay,"INFO-FITMENT DRAWING (IFD)");
	}
	if(tc_strcmp(DmlReasonCode,"ECFR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ECFR");
		tc_strcpy(Dml_ReasonDisplay,"ECU CALIBRATION FILE RELEASE");
	}
	if(tc_strcmp(DmlReasonCode,"SA")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SA");
		tc_strcpy(Dml_ReasonDisplay,"SAMPLES TO BE APPROVED");
	}
	if(tc_strcmp(DmlReasonCode,"DFM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFM");
		tc_strcpy(Dml_ReasonDisplay,"DFM");
	}
	if(tc_strcmp(DmlReasonCode,"NR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"NR");
		tc_strcpy(Dml_ReasonDisplay,"NEW REQUIREMENTS (NEW VC, NEW AGGREGATE)");
	}
	if(tc_strcmp(DmlReasonCode,"CFL")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CFL");
		tc_strcpy(Dml_ReasonDisplay,"CHANGE IN FEATURE LIST");
	}
	if(tc_strcmp(DmlReasonCode,"RSR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"RSR");
		tc_strcpy(Dml_ReasonDisplay,"REGULATORY / SAFETY REQUIREMENTS");
	}
	if(tc_strcmp(DmlReasonCode,"DM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DM");
		tc_strcpy(Dml_ReasonDisplay,"DESIGN MATURATION");
	}
	if(tc_strcmp(DmlReasonCode,"SCAS")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SCAS");
		tc_strcpy(Dml_ReasonDisplay,"STYLING SURFACES (CAS)");
	}
	if(tc_strcmp(DmlReasonCode,"EVI")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"EVI");
		tc_strcpy(Dml_ReasonDisplay,"EVI REPLACEMENTS (BLACK BOX)");
	}
	if(tc_strcmp(DmlReasonCode,"FA")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"FA");
		tc_strcpy(Dml_ReasonDisplay,"FEATURE ADDITION");
	}
	if(tc_strcmp(DmlReasonCode,"BTSC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"BTSC");
		tc_strcpy(Dml_ReasonDisplay,"BTS SUPPLIER CHANGE (GREY BOX)");
	}
	if(tc_strcmp(DmlReasonCode,"DVLO")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DVLO");
		tc_strcpy(Dml_ReasonDisplay,"DVLO ISSUES");
	}
	if(tc_strcmp(DmlReasonCode,"4DCHANGE")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"4DCHANGE");
		tc_strcpy(Dml_ReasonDisplay,"4D CHANGES");
	}
	if(tc_strcmp(DmlReasonCode,"VCAE")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"VCAE");
		tc_strcpy(Dml_ReasonDisplay,"VALIDATION / CAE FEEDBACK");
	}
	if(tc_strcmp(DmlReasonCode,"FMPCQRI")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"FMPCQRI");
		tc_strcpy(Dml_ReasonDisplay,"TO FACILITATE MANUFACTURING/ PROCESS CHANGES FOR QUALITY RELIABILITY IMPROVEMENT");
	}
	if(tc_strcmp(DmlReasonCode,"ICWCR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ICWCR");
		tc_strcpy(Dml_ReasonDisplay,"INTEGRATED COST REDUCTION / WEIGHT REDUCTION / COMPLEXITY REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"MMDMR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"MMDMR");
		tc_strcpy(Dml_ReasonDisplay,"MODULE MASTER DATA MANAGEMENT REQUEST");
	}
	if(tc_strcmp(DmlReasonCode,"VAC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"VAC");
		tc_strcpy(Dml_ReasonDisplay,"VC Attribute Change");
	}
	if(tc_strcmp(DmlReasonCode,"WCR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"WCR");
		tc_strcpy(Dml_ReasonDisplay,"WARRANTY COST REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"PQ")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"PQ");
		tc_strcpy(Dml_ReasonDisplay,"IMPROVEMENT IN JD POWER INITIAL QUALITY SCORE");
	}
	if(tc_strcmp(DmlReasonCode,"QR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"QR");
		tc_strcpy(Dml_ReasonDisplay,"QUALITY & RELIABILITY IMPROVEMENT");
	}
	if(tc_strcmp(DmlReasonCode,"QRI")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"QR");
		tc_strcpy(Dml_ReasonDisplay,"QUALITY, WARRANTY & RELIABILITY IMPROVEMENT");
	}
	if(tc_strcmp(DmlReasonCode,"FM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"FM");
		tc_strcpy(Dml_ReasonDisplay,"TO FACILITATE MANUFACTURING");
	}
	if(tc_strcmp(DmlReasonCode,"SR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SR");
		tc_strcpy(Dml_ReasonDisplay,"SAFETY REQUIREMENT");
	}
	if(tc_strcmp(DmlReasonCode,"ICR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ICR");
		tc_strcpy(Dml_ReasonDisplay,"INTEGRATED COST REDUCTION");
	}
	printf("\n Print Dml_ReasonDisplay==> [%s]",Dml_ReasonDisplay);fflush(stdout);
	return Dml_ReasonDisplay;
}
int ns__getItemData(struct soap* soap,char *part_no,struct ns__CharArray1 *aString_test)
{
        //int ifail =0;
		int i,j = 0;
		int n_tags_found = 0;
		int num = 0;
		int d = 0;
		int row = 7;
		int pom_version = 0;

		tag_t *tags_found = NULLTAG;
		tag_t item_t = NULLTAG;
		tag_t itemRev_t = NULLTAG;
		tag_t ercmdlquery = NULLTAG;
		tag_t logUser = NULLTAG;
		tag_t topmost_class_id = NULLTAG;

		char*	partnum		= NULL;
		
		char*			responseString1			= NULL;
		char*			responseString2			= NULL;
		char*			responseString3			= NULL;
		char*			responseString4			= NULL;
		char*			responseString5			= NULL;
		

		char*          PartNumber         =NULL;
		char*          PartRevisionSeq         =NULL;
		char*          PartRevision         =NULL;
		char*          PartSeq         =NULL;
		char*          PartDesc         =NULL;
		char*          PartLC         =NULL;
		
		logical 	ignore_unsaved_stuff;
		FILE *fpPart_List = NULL;
		char Buffer[MAX_LINE_LENGTH];
		char* username_str = NULL;
		char* password_str = NULL;
		char* group_str = NULL;
		char* username_strDup = NULL;
		char* password_strDup = NULL;
		char* group_strDup = NULL;
		char* loggedInUser = NULL;

		char
        *qry_entries[2] = {"Item ID","Type"},
        *qry_values[2]	= {"*","*"};
		//const char* u = NULL;
		//const char* p = NULL;
		//const char* g = NULL;

		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/PartDetails.txt", "w", stdout);
		//CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		//u = ITK_ask_cli_argument( "-u=ercjsup");
		//p = ITK_ask_cli_argument( "-p=Tcua_tst@789");
		//g = ITK_ask_cli_argument( "-g=dba");
		//if (ITK_init_module(u,p,g) == ITK_ok )
		//{

		//POM_logout(ignore_unsaved_stuff);
		//POM_exit_module();
		//ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
		//POM_start("infodba","infodba","dba",&logUser,&topmost_class_id,&pom_version);
		
		//ITK_auto_login( );
		//ITK_set_journalling( TRUE );
		
		//fpPart_List = fopen("/user/uaprodtrl/Sourav/WebServicePwfFile.txt","r");  //UAPRODTRL Login
		fpPart_List = fopen("/user/cvprod/sourav/WebServicePwfFile.txt","r");  //CVPRODTRL Login
		if(fpPart_List != NULL)
		{
			printf(" Input_File Not Null..!!\n");fflush(stdout);
			while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
			{
				username_str=strtok(Buffer,"^");
				password_str=strtok(NULL,"^");
				group_str=strtok(NULL,"^");
				
				if(username_str!=NULL)tc_strdup(username_str,&username_strDup);
				if(password_str!=NULL)tc_strdup(password_str,&password_strDup);
				if(group_str!=NULL)tc_strdup(group_str,&group_strDup);
				
				if(username_strDup!=NULL)trimwhitespace(username_strDup);
				if(password_strDup!=NULL)trimwhitespace(password_strDup);
				if(group_strDup!=NULL)trimwhitespace(group_strDup);
			}
		}
		else 
		{
			printf("\n UserName & Password Input_File is NULL..!!\n");fflush(stdout);
		}
		fclose(fpPart_List);
		printf(" UserName & Password & Group Data read From File Done..!!\n");fflush(stdout);
		ITK_init_module(username_strDup, password_strDup, group_strDup);
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);


		printf("\n Input .. %s",part_no);fflush(stdout);
		if((part_no !=NULL) && (tc_strcmp(part_no,"")!=0))
		{
			const char *attrs[1];
			const char *values[1];
			attrs[0] ="item_id";
			//attrs[1] ="object_type";
			values[0] = (char *)part_no;
			//values[1] = "ERC DML";
			printf("\n values[0] <%s> \n",values[0] );fflush(stdout);

			qry_values[0]	= part_no;
			qry_values[1]	= "Design";
			QRY_find2("Item...", &ercmdlquery);
			QRY_execute(ercmdlquery, 2, qry_entries, qry_values, &n_tags_found, &tags_found);

			//ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);

			printf("\n Tag Found <%d> \n",n_tags_found );fflush(stdout);
			if(n_tags_found>0)
			{
				responseString1=(char *)MEM_alloc(200);
				responseString2=(char *)MEM_alloc(200);
				responseString3=(char *)MEM_alloc(200);
				responseString4=(char *)MEM_alloc(200);
				responseString5=(char *)MEM_alloc(200);

				item_t = tags_found[0];
				ITEM_ask_latest_rev(item_t,&itemRev_t);
				//itemRev_t = tags_found[0];
				AOM_ask_value_string(itemRev_t,"item_id",&PartNumber);
				printf("\n PartNumber <%s> \n",PartNumber);fflush(stdout);
				tc_strcpy(responseString1,"PARTNUMBER = '");
				tc_strcat(responseString1,PartNumber);
				tc_strcat(responseString1,"'");

				AOM_ask_value_string(itemRev_t,"object_name",&PartDesc);
				printf("\n PartDesc <%s> \n",PartDesc);fflush(stdout);
				tc_strcpy(responseString2,"NOMENCLATURE = '"); 
				tc_strcat(responseString2,PartDesc);
				tc_strcat(responseString2,"'");

				AOM_ask_value_string(itemRev_t,"item_revision_id",&PartRevisionSeq);
				printf("\n PartRevisionSeq <%s> \n",PartRevisionSeq);fflush(stdout);
				PartRevision = tc_strtok(PartRevisionSeq,";");
				PartSeq = tc_strtok(NULL,";");

				tc_strcpy(responseString3,"REVISION  = '"); 
				tc_strcat(responseString3,PartRevision);
				tc_strcat(responseString3,"'");

				
				tc_strcpy(responseString4,"SEQUENCE  ='"); 
				tc_strcat(responseString4,PartSeq);
				tc_strcat(responseString4,"'");

				int status_count,ii = 0;
				tag_t* status_list = NULLTAG;				
				PartLC =  (char *)MEM_alloc(200);
				char *ReleaseStatus=NULL;
				AOM_UIF_ask_value(itemRev_t, "release_status_list",&ReleaseStatus);
				printf("\t ReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
				tc_strcpy(PartLC,ReleaseStatus);
				
				/*
				WSOM_ask_release_status_list(itemRev_t,&status_count,&status_list);
				for (ii = 0; ii < status_count; ii++)
				{
					char *ReleaseStatus=NULL;
					char *GetLifecycleStateDisplayValue=NULL;
					//AOM_ask_name(status_list[ii], &ReleaseStatus);
					AOM_UIF_ask_value(itemRev_t, "release_status_list",&ReleaseStatus);
					printf("\t ReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
					//GetLifecycleStateDisplayValue = GetLifecycleStateDisplay(ReleaseStatus);
					if(ii == 0)
					{
						tc_strcpy(PartLC,ReleaseStatus);
					}
					else
					{
						tc_strcat(PartLC," ");
						tc_strcat(PartLC,ReleaseStatus);
					}
					
				}
				MEM_free(status_list);
				*/
				printf("\n PartLC <%s> \n",PartLC);fflush(stdout);
				tc_strcpy(responseString5,"LIFECYCLESTATE  = '"); 
				tc_strcat(responseString5,PartLC);
				tc_strcat(responseString5,"'");

				aString_test-> __size =1;
				aString_test->__ptrItem = malloc( (aString_test->__size + 1) * sizeof(*aString_test->__ptrItem) );
				for(i=0;i<1;i++)
				{
					aString_test->__ptrItem[i].PART_NO = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_NO,responseString1); // PART NO

					aString_test->__ptrItem[i].PART_REV = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_REV,responseString2); // PART REV

					aString_test->__ptrItem[i].PART_SEQ = malloc(200 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_SEQ,responseString3); // PART SEQ

					aString_test->__ptrItem[i].PART_DESC = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_DESC,responseString4); // PART DESC

					aString_test->__ptrItem[i].PART_LC = malloc(30 * sizeof(char *) );
					strcpy(aString_test->__ptrItem[i].PART_LC,responseString5); // PART LC
				}
			}
		}///
		//}
		MEM_free(responseString1);
		MEM_free(responseString2);
		MEM_free(responseString3);
		MEM_free(responseString4);
		MEM_free(responseString5);
		MEM_free(tags_found);
		MEM_free(PartNumber);
		MEM_free(PartDesc);
		MEM_free(PartRevisionSeq);
		
		MEM_free(PartLC);
		ITK_exit_module(true);
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

		return SOAP_OK;
}

