/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                :	Anant Hingankar
*  Module                :  JT/CAD BOM List
*  Code                  :  jt_cad_bom_list.c
*  Created on			 :	Aug 21st 2018
*  Modification History :
*  S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <fclasses/tc_date.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tcinit/tcinit.h>
#include <ps/ps.h>
#include <vector>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <cfm/cfm.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <ae/dataset.h>
#include <stdlib.h>
#include<iostream>
#include <tccore/libtccore_exports.h>
#define Debug TRUE

using namespace std;


#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

#define TCTYPE_name_size_c 100

int getFileDetails(tag_t rev_tag_c, const char* relation_name, char** value1, char** value2, FILE *fp1)
{
	int	iFail=ITK_ok;
	int	ii=ITK_ok;
	int	nm=ITK_ok;
	int refnum=0;
	int n_specs=0;
	int status1=0;
	int status2=0;
	char* nm_type = NULL;
	char* fullpath = NULL;
	char* OriginalName = NULL;
	char* type_name = NULL;
	tag_t *specs = NULL;
	tag_t relation_tag = NULL;
	tag_t *namedRef_tags = NULLTAG;
	tag_t *namedRef_tag = NULLTAG;
	
	iFail =(GRM_find_relation_type(relation_name,&relation_tag));
	iFail =(GRM_list_secondary_objects_only(rev_tag_c,relation_tag, &n_specs, &specs));
	printf("\nNo. Of Objects in relationship are :: %d",n_specs);
	
	for (ii = 0; ii < n_specs; ii++)
	{
		
		iFail =(AOM_ask_value_string(specs[ii],"object_type",&type_name));
		printf("\ntype_name is %s",type_name);

		iFail =(AE_ask_dataset_named_refs(specs[ii],&refnum,&namedRef_tags));
		printf("\nNamed References Found are %d",refnum);fflush(stdout);

		if(refnum>0)
		{
			for (nm=0;nm<refnum ;nm++ )
			{
				iFail =(AOM_ask_value_string(namedRef_tags[nm],"object_type",&nm_type));
				printf(" \n  named reference type is 33 :%s",nm_type);fflush(stdout);
				if (tc_strstr(nm_type,"Form")!=NULL)
				{
					printf("\n Metadata Form / JPEG is found attached to dataset");
					continue;
				}

				iFail =(IMF_ask_file_pathname2(namedRef_tags[nm],SS_UNIX_MACHINE,&fullpath));
				printf(" \n  full path is :%s",fullpath);fflush(stdout);
				iFail =(AOM_ask_value_string(namedRef_tags[nm],"original_file_name",&OriginalName));
				printf("\n  OriginalName here is %s",OriginalName);fflush(stdout);
				if (tc_strstr(OriginalName,".JPG")==NULL)
				{
					if(tc_strcmp(relation_name,"IMAN_specification") == 0 && (tc_strcmp(type_name,"CMI2Product")==0 || tc_strcmp(type_name,"CMI2Part") == 0))
					{
						printf("\n  111111111111111111111111111");fflush(stdout);
						tc_strdup(OriginalName, value1);
						if(fp1) fprintf(fp1,"%s,%s,\n",fullpath,OriginalName);fflush(fp1);
						status1++;
					}

					if(tc_strcmp(relation_name,"IMAN_specification") == 0 && (tc_strcmp(type_name,"CMI2Drawing")==0 || tc_strcmp(type_name,"Creo drawing") == 0))
					{
						printf("\n 22222222222222222222222222222222222");fflush(stdout);
						tc_strdup(OriginalName, value2);
						if(fp1) fprintf(fp1,"%s,%s,\n",fullpath,OriginalName);fflush(fp1);
						status2++;
					}

					if(tc_strcmp(relation_name,"IMAN_Rendering") == 0 && tc_strcmp(type_name,"DirectModel")==0)
					{
						printf("\n33333333333333333333333333333333333");fflush(stdout);
						tc_strdup((const char*)OriginalName, value1);
						if(fp1) fprintf(fp1,"%s,%s,\n",fullpath,OriginalName);fflush(fp1);
						status1++;
					}

					if(tc_strcmp(relation_name,"IMAN_Rendering") == 0 && tc_strcmp(type_name,"PDF")==0)
					{
						printf("\n44444444444444444444444444444444444");fflush(stdout);
						tc_strdup(OriginalName, value2);
						if(fp1) fprintf(fp1,"%s,%s,\n",fullpath,OriginalName);fflush(fp1);
						status2++;
					}
				}
			}
		}
	}
	if(status1 == 0) tc_strdup("NA", value1);
	if(status2 == 0) tc_strdup("NA", value2);
	fflush(stdout);
}



int Get_Bom_line_attr_list(tag_t rev_tag_br, const char* outputdir, const char* parentName, const char* DataFlag, const char* AttributeFlag, FILE *fp, FILE *fp1)
{
	int	iFail=ITK_ok;
	int	bl_level_starting_0=0;
	int	bl_value_int=ITK_ok;
	int	bl_status_count=0;
	int iChldPrts=0,i=0,inx=0,iblType=0,i_ChildCount=0,i_statusCount = 0;
	char *bl_value=NULL;
	logical bl_value11;
	char *State=NULL;
	char *item_id=NULL;
	char *item_rev_id=NULL;
	char *item_rev_id_rep=NULL;
	char line[500];
	char fileName[150];
	char attribute[300];
	char* bl_item_object_desc = NULL;
	char* bl_item_object_desc1 = NULL;
	char* bl_item_object_descDup = NULL;
	char* bl_revision_t5_DocRemarks = NULL;
	char* bl_revision_t5_ProjectCode = NULL;
	char* bl_rev_t5designgroup  = NULL;
	char* owning_organization  = NULL;
	char* bl_Design_revision_t5_Weight   = NULL;
	char* bl_Design_revision_t5_LeftRh_Comp   = NULL;
	char* bl_design_revision_t5_ColourInd = NULL;
	char* bl_design_revision_t5_ColourID = NULL;
	char* bl_desig_revision_t5_NcPartNo = NULL;
	char* bl_desig_revision_t5_PrtCatCode = NULL;
	char* bl_design_revision_t5_Coated  = NULL;
	char* bl_design_revision_t5_StdPartIndicator  = NULL;
	char* bl_DesignRevision_t5_DsgnDept = NULL;
	char* bl_DesignRevision_t5_SpareInd = NULL;
	char* bl_DesignRevision_t5_MatlClass = NULL;
	char* bl_DesignRevision_t5_Recoverable = NULL;
	char* bl_DesignRevision_t5_Reliability = NULL;
	char* bl_DesignRevision_t5_Dismantable = NULL;
	char* bl_DesignRevision_t5_Product = NULL;
	char* bl_DesignRevision_t5_PkgStd = NULL;
	char* bl_DesignRevision_t5_CMVRCertificationReqd = NULL;
	char* bl_DesignRevision_t5_HomologationReqd = NULL;
	char* bl_DesignRevision_t5_HazardousContents = NULL;
	char* bl_DesignRevision_t5_Recyclability = NULL;
	char* bl_DesignRevision_t5_EnvelopeDimensions = NULL;
	char* bl_DesignRevision_t5_ClassificationHazardous = NULL;
	char* bl_DesignRevision_t5_DsgnOwn = NULL;
	char* bl_DesignRevision_t5_PunIntialAgency = NULL;
	char* bl_DesignRevision_t5_PunMakeBuyIndicator = NULL;
	char* bl_DesignRevision_t5_JsrIntialAgency = NULL;
	char* bl_DesignRevision_t5_JsrMakeBuyIndicator = NULL;
	char* bl_DesignRevision_t5_LkoIntialAgency = NULL;
	char* bl_DesignRevision_t5_LkoMakeBuyIndicator = NULL;
	char* bl_DesignRevision_t5_SgrIntialAgency = NULL;
	char* bl_DesignRevision_t5_SgrMakeBuyIndicator = NULL;
	char* bl_DesignRevision_t5_PnrIntialAgency = NULL;
	char* bl_DesignRevision_t5_PnrMakeBuyIndicator = NULL;
	char* bl_DesignRevision_t5_MThickness = NULL;
	char* bl_DesignRevision_t5_CategoryName = NULL;	
	char* bl_DesignRevision_t5_PartType = NULL;
	char* bl_DesignRevision_t5_PartStatus = NULL;
	char* bl_rev_release_status_value = NULL;
	char* bl_occurrence_name  = NULL;
	char* bl_plmxml_occ_xform   = NULL;
	char* cad = NULL;
	char* drw = NULL;
	char* jt = NULL;
	char* pdf = NULL;
	char* awb0RevisionOwningUser = NULL;
	char* bl_rev_release_status_list = NULL;
	char* bl_rev_release_status_list1 = NULL;
	const char* dateFormat = "%Y-%m-%d %H:%M:%S";

	char **  bl_statusS = (char **) MEM_alloc(6 * sizeof(char *));

	
	char* emailId = NULL;
	char* user_name = NULL;
	char* dateTime = NULL;
	tag_t userTag = NULLTAG;
	tag_t personTag = NULLTAG;
	date_t awb0RevisionLastModifiedDate;

	logical bl_is_occ_suppressed_logical;

	tag_t rev_tag_c= NULLTAG;
	tag_t bl_status= NULLTAG;	
	tag_t  t_TopLine = NULLTAG;
	tag_t  t_Childobject = NULLTAG;
	tag_t  t_Rule = NULLTAG;
	tag_t *t_PartChildren;
	vector<tag_t> p_Vec;
	PROP_type_t *  	proptype;
	char *  	proptype_n;	

	FILE  *attributeFile = NULL;
	
	printf("\nInside Get_Bom_line_attr_list function BVR");fflush(stdout);
	
	AOM_ask_value_string(rev_tag_br, "awb0BomLineItemId", &item_id);
	printf("\nitem_id === %s\n", item_id);fflush(stdout);

	AOM_ask_value_string(rev_tag_br, "bl_rev_item_revision_id", &item_rev_id);
	printf("\nitem_rev_id === %s\n", item_rev_id);fflush(stdout);	

	AOM_ask_value_int(rev_tag_br, "bl_level_starting_0", &bl_level_starting_0);
	printf("\nbl_level_starting_0 == %d\n", bl_level_starting_0);fflush(stdout);

	AOM_ask_value_logical(rev_tag_br, "bl_is_occ_suppressed", &bl_is_occ_suppressed_logical);
	printf("\nSuppressed Value is -- %d\n", bl_is_occ_suppressed_logical);

	AOM_ask_value_string(rev_tag_br, "bl_occurrence_name", &bl_occurrence_name );
	if(tc_strlen(bl_occurrence_name ) == 0) tc_strcpy(bl_occurrence_name ,"--");
	printf("\nbl_occurrence_name  == %s\n", bl_occurrence_name );fflush(stdout);

	AOM_ask_value_string(rev_tag_br, "bl_plmxml_occ_xform", &bl_plmxml_occ_xform);
	if(tc_strlen(bl_plmxml_occ_xform) == 0) tc_strcpy(bl_plmxml_occ_xform,"--");
	printf("\nbl_plmxml_occ_xform == %s\n", bl_plmxml_occ_xform );fflush(stdout);
	
	AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_PartType", &bl_DesignRevision_t5_PartType);
	printf("\nbl_DesignRevision_t5_PartType == %s\n",bl_DesignRevision_t5_PartType);
	if(tc_strlen(bl_DesignRevision_t5_PartType) == 0) 
	{
		AOM_ask_value_string(rev_tag_br,"fnd0bl_line_object_type", &bl_DesignRevision_t5_PartStatus);
		if(tc_strstr(bl_DesignRevision_t5_PartType,"T5_PlatformRevision") != NULL || tc_strstr(bl_DesignRevision_t5_PartType,"Platform Revision") != NULL) 
		{
			tc_strcpy(bl_DesignRevision_t5_PartType,"Platform");
		}
		if(tc_strstr(bl_DesignRevision_t5_PartStatus,"T5_ArchModuleRevision") != NULL || tc_strstr(bl_DesignRevision_t5_PartStatus,"Architecture Module Revision") != NULL) 
		{
			tc_strcpy(bl_DesignRevision_t5_PartType,"ArchModule");
		}
		else
		{
			tc_strcpy(bl_DesignRevision_t5_PartType,"--");
		}
	}
	printf("\nbl_DesignRevision_t5_PartType == %s\n",bl_DesignRevision_t5_PartType);fflush(stdout);

	AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_PartStatus", &bl_DesignRevision_t5_PartStatus);
	printf("\nbl_DesignRevision_t5_PartStatus == %s\n",bl_DesignRevision_t5_PartStatus);fflush(stdout);	

	AOM_ask_value_string(rev_tag_br,"bl_rev_release_status_list", &bl_rev_release_status_list1);
	printf("\nbl_rev_release_status_list count  == %s\n", bl_rev_release_status_list1);fflush(stdout);
	if(tc_strlen == 0) tc_strcpy(bl_rev_release_status_list,"--");
	else
	{ 
		 bl_rev_release_status_value = strtok(bl_rev_release_status_list1, ","); 
  
		// Keep printing tokens while one of the 
		// delimiters present in str[]. 
		while (bl_rev_release_status_value != NULL) { 
			printf("\nbl_rev_release_status_value  == %s\n", bl_rev_release_status_value);fflush(stdout);
			if(tc_strstr(bl_rev_release_status_value,"Std") != NULL)
			{
				bl_rev_release_status_list = NULL;
				tc_strdup(bl_rev_release_status_value,&bl_rev_release_status_list);
				break;
			}

			if(tc_strstr(bl_rev_release_status_value,"Apl") != NULL)
			{
				bl_rev_release_status_list = NULL;
				tc_strdup(bl_rev_release_status_value,&bl_rev_release_status_list);
			}

			if(tc_strcmp(bl_rev_release_status_value,"T5_LcsErcRlzd") == 0 && !(bl_rev_release_status_list || tc_strstr(bl_rev_release_status_value,"Apl") != NULL))
			{
				bl_rev_release_status_list = NULL;
				tc_strdup(bl_rev_release_status_value,&bl_rev_release_status_list);
			}

			if(!(bl_rev_release_status_list || tc_strcmp(bl_rev_release_status_value,"T5_LcsErcRlzd") == 0 || tc_strstr(bl_rev_release_status_value,"Apl") != NULL) && tc_strcmp(bl_rev_release_status_value,"T5_LcsReview") == 0)
			{
				bl_rev_release_status_list = NULL;
				tc_strdup(bl_rev_release_status_value,&bl_rev_release_status_list);
			}

			if(!bl_rev_release_status_list  && tc_strcmp(bl_rev_release_status_value,"T5_LcsWorking") == 0)
			{
				bl_rev_release_status_list = NULL;
				tc_strdup(bl_rev_release_status_value,&bl_rev_release_status_list);
			}

			bl_rev_release_status_value = strtok(NULL, ","); 
		} 
		//ERC Review 23-May-2019 17:41 to 31-May-2019 08:49 (NONE). ERC Released 01-Jun-2019 00:00 to UP (NONE). APLC Released 02-Jul-2019 00:00 to UP (NONE). APLC Released 02-Jul-2019 00:00 to UP (NONE). APLC Released 02-Jul-2019 00:00 to UP (NONE)
	}
	printf("\nbl_rev_release_status_list value == %s\n",bl_rev_release_status_value);fflush(stdout);

	AOM_ask_value_string(rev_tag_br, "bl_Design Revision_t5_ApplicationOwner", &bl_value);
	if(!bl_value) 
	{
		tc_strcpy(bl_value,"--");
	}
	printf("\nbl_Design Revision_t5_ApplicationOwner == %s\n", bl_value);fflush(stdout);

	AOM_ask_value_string(rev_tag_br, "bl_rev_object_desc", &bl_item_object_desc);
	printf("\nbl_item_object_desc == %s\n", bl_item_object_desc);fflush(stdout);
	if(tc_strlen(bl_item_object_desc) == 0) tc_strcpy(bl_item_object_desc,"--");
	else
	{
		if(tc_strstr(bl_item_object_desc1,":") != NULL)
		{
			STRNG_replace_str(bl_item_object_desc,":", " ", &bl_item_object_descDup);	
			tc_strdup(bl_item_object_descDup, &bl_item_object_desc);
		}
		
	}
	printf("\nbl_item_object_desc == %s\n", bl_item_object_desc);fflush(stdout);
	 
	if(tc_strcmp(AttributeFlag,"Y") == 0)
	{
		STRNG_replace_str (item_rev_id,";","_", &item_rev_id_rep);

		tc_strcpy(fileName,"");
		tc_strcat(fileName,outputdir);
		tc_strcat(fileName,"//");
		tc_strcat(fileName,item_id);
		tc_strcat(fileName,"_");
		tc_strcat(fileName,item_rev_id_rep);
		tc_strcat(fileName,"_attr.txt");
		if(!attributeFile) attributeFile = fopen(fileName, "w");		

		AOM_ask_value_string(rev_tag_br, "bl_Design Revision_t5_DocRemarks", &bl_revision_t5_DocRemarks);
		if(tc_strlen(bl_revision_t5_DocRemarks) == 0) tc_strcpy(bl_revision_t5_DocRemarks,"--");
		printf("\nbl_value == %s\n", bl_revision_t5_DocRemarks);fflush(stdout);

		AOM_ask_value_string(rev_tag_br, "Revision_t5_ProjectCode", &bl_revision_t5_ProjectCode);
		if(tc_strlen(bl_revision_t5_ProjectCode) == 0) tc_strcpy(bl_revision_t5_ProjectCode,"--");
		printf("\nbl_value == %s\n", bl_revision_t5_ProjectCode);fflush(stdout);

		AOM_ask_value_string(rev_tag_br, "bl_rev_t5designgroup", &bl_rev_t5designgroup );
		if(tc_strlen(bl_rev_t5designgroup) == 0) tc_strcpy(bl_rev_t5designgroup,"--");
		printf("\nbl_value == %s\n", bl_rev_t5designgroup );fflush(stdout);
		
		//to be taken from item revision
		AOM_ask_value_string(rev_tag_br, "owning_organization", &owning_organization );
		if(tc_strlen(owning_organization) == 0) tc_strcpy(owning_organization,"--");
		printf("\nbl_value == %s\n", owning_organization );fflush(stdout);

		AOM_ask_value_string(rev_tag_br, "bl_Design Revision_t5_Weight", &bl_Design_revision_t5_Weight);
		if(tc_strlen(bl_Design_revision_t5_Weight) == 0) tc_strcpy(bl_Design_revision_t5_Weight,"--");
		printf("\nbl_value == %s\n", bl_Design_revision_t5_Weight);fflush(stdout);

		AOM_ask_value_string(rev_tag_br, "bl_Design Revision_t5_LeftRh_Comp", &bl_Design_revision_t5_LeftRh_Comp);
		if(tc_strlen(bl_Design_revision_t5_LeftRh_Comp) == 0) tc_strcpy(bl_Design_revision_t5_LeftRh_Comp,"--");
		printf("\nbl_value == %s\n", bl_Design_revision_t5_LeftRh_Comp  );fflush(stdout);

		AOM_ask_value_string(rev_tag_br, "bl_Design Revision_t5_ColourInd", &bl_design_revision_t5_ColourInd);
		if(tc_strlen(bl_design_revision_t5_ColourInd) == 0) tc_strcpy(bl_design_revision_t5_ColourInd,"--");
		printf("\nbl_value == %s\n", bl_design_revision_t5_ColourInd);fflush(stdout);

		AOM_ask_value_string(rev_tag_br, "bl_Design Revision_t5_ColourID", &bl_design_revision_t5_ColourID);
		if(tc_strlen(bl_design_revision_t5_ColourID) == 0) tc_strcpy(bl_design_revision_t5_ColourID,"--");
		printf("\nbl_value == %s\n", bl_design_revision_t5_ColourID);fflush(stdout);

		AOM_ask_value_string(rev_tag_br, "bl_Design Revision_t5_NcPartNo", &bl_desig_revision_t5_NcPartNo);
		if(tc_strlen(bl_desig_revision_t5_NcPartNo) == 0) tc_strcpy(bl_desig_revision_t5_NcPartNo,"--");
		printf("\nbl_value == %s\n", bl_desig_revision_t5_NcPartNo);fflush(stdout);

		AOM_ask_value_string(rev_tag_br, "bl_Design Revision_t5_PrtCatCode", &bl_desig_revision_t5_PrtCatCode);
		if(tc_strlen(bl_desig_revision_t5_PrtCatCode) == 0) tc_strcpy(bl_desig_revision_t5_PrtCatCode,"--");
		printf("\nbl_value == %s\n", bl_desig_revision_t5_PrtCatCode);fflush(stdout);

		AOM_ask_value_string(rev_tag_br, "bl_Design Revision_t5_Coated", &bl_design_revision_t5_Coated );
		if(tc_strlen(bl_design_revision_t5_Coated) == 0) tc_strcpy(bl_design_revision_t5_Coated,"--");
		printf("\nbl_value == %s\n", bl_design_revision_t5_Coated );fflush(stdout);

		AOM_ask_value_string(rev_tag_br, "bl_Design Revision_t5_StdPartIndicator", &bl_design_revision_t5_StdPartIndicator );
		if(tc_strlen(bl_design_revision_t5_StdPartIndicator) == 0) tc_strcpy(bl_design_revision_t5_StdPartIndicator,"--");
		printf("\nbl_value == %s\n", bl_design_revision_t5_StdPartIndicator );fflush(stdout);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_DsgnDept", &bl_DesignRevision_t5_DsgnDept);
		if(tc_strlen(bl_DesignRevision_t5_DsgnDept) == 0) tc_strcpy(bl_DesignRevision_t5_DsgnDept,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_DsgnDept);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_SpareInd", &bl_DesignRevision_t5_SpareInd);
		if(tc_strlen(bl_DesignRevision_t5_SpareInd) == 0) tc_strcpy(bl_DesignRevision_t5_SpareInd,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_SpareInd);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_MatlClass", &bl_DesignRevision_t5_MatlClass);
		if(tc_strlen(bl_DesignRevision_t5_MatlClass) == 0) tc_strcpy(bl_DesignRevision_t5_MatlClass,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_MatlClass);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_Recoverable", &bl_DesignRevision_t5_Recoverable);
		if(tc_strlen(bl_DesignRevision_t5_Recoverable) == 0) tc_strcpy(bl_DesignRevision_t5_Recoverable,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_Recoverable);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_Reliability", &bl_DesignRevision_t5_Reliability);
		if(tc_strlen(bl_DesignRevision_t5_Reliability) == 0) tc_strcpy(bl_DesignRevision_t5_Reliability,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_Reliability);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_Dismantable", &bl_DesignRevision_t5_Dismantable);
		if(tc_strlen(bl_DesignRevision_t5_Dismantable) == 0) tc_strcpy(bl_DesignRevision_t5_Dismantable,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_Dismantable);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_Product", &bl_DesignRevision_t5_Product);
		if(tc_strlen(bl_DesignRevision_t5_Product) == 0) tc_strcpy(bl_DesignRevision_t5_Product,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_Product);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_PkgStd", &bl_DesignRevision_t5_PkgStd);
		if(tc_strlen(bl_DesignRevision_t5_PkgStd) == 0) tc_strcpy(bl_DesignRevision_t5_PkgStd,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_PkgStd);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_CMVRCertificationReqd", &bl_DesignRevision_t5_CMVRCertificationReqd);
		if(tc_strlen(bl_DesignRevision_t5_CMVRCertificationReqd) == 0) tc_strcpy(bl_DesignRevision_t5_CMVRCertificationReqd,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_CMVRCertificationReqd);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_HomologationReqd", &bl_DesignRevision_t5_HomologationReqd);
		if(tc_strlen(bl_DesignRevision_t5_HomologationReqd) == 0) tc_strcpy(bl_DesignRevision_t5_HomologationReqd,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_HomologationReqd);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_HazardousContents", &bl_DesignRevision_t5_HazardousContents);
		if(tc_strlen(bl_DesignRevision_t5_HazardousContents) == 0) tc_strcpy(bl_DesignRevision_t5_HazardousContents,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_HazardousContents);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_Recyclability", &bl_DesignRevision_t5_Recyclability);
		if(tc_strlen(bl_DesignRevision_t5_Recyclability) == 0) tc_strcpy(bl_DesignRevision_t5_Recyclability,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_Recyclability);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_ClassificationHazardous", &bl_DesignRevision_t5_ClassificationHazardous);
		if(tc_strlen(bl_DesignRevision_t5_ClassificationHazardous) == 0) tc_strcpy(bl_DesignRevision_t5_ClassificationHazardous,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_ClassificationHazardous);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_EnvelopeDimensions", &bl_DesignRevision_t5_EnvelopeDimensions);
		if(tc_strlen(bl_DesignRevision_t5_EnvelopeDimensions) == 0) tc_strcpy(bl_DesignRevision_t5_EnvelopeDimensions,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_EnvelopeDimensions);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_DsgnOwn", &bl_DesignRevision_t5_DsgnOwn);
		if(tc_strlen(bl_DesignRevision_t5_DsgnOwn) == 0) tc_strcpy(bl_DesignRevision_t5_DsgnOwn,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_DsgnOwn);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_PunIntialAgency", &bl_DesignRevision_t5_PunIntialAgency);
		if(tc_strlen(bl_DesignRevision_t5_PunIntialAgency) == 0) tc_strcpy(bl_DesignRevision_t5_PunIntialAgency,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_PunIntialAgency);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_PunMakeBuyIndicator", &bl_DesignRevision_t5_PunMakeBuyIndicator);
		if(tc_strlen(bl_DesignRevision_t5_PunMakeBuyIndicator) == 0) tc_strcpy(bl_DesignRevision_t5_PunMakeBuyIndicator,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_PunMakeBuyIndicator);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_JsrIntialAgency", &bl_DesignRevision_t5_JsrIntialAgency);
		if(tc_strlen(bl_DesignRevision_t5_JsrIntialAgency) == 0) tc_strcpy(bl_DesignRevision_t5_JsrIntialAgency,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_JsrIntialAgency);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_JsrMakeBuyIndicator", &bl_DesignRevision_t5_JsrMakeBuyIndicator);
		if(tc_strlen(bl_DesignRevision_t5_JsrMakeBuyIndicator) == 0) tc_strcpy(bl_DesignRevision_t5_JsrMakeBuyIndicator,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_JsrMakeBuyIndicator);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_LkoIntialAgency", &bl_DesignRevision_t5_LkoIntialAgency);
		if(tc_strlen(bl_DesignRevision_t5_LkoIntialAgency) == 0) tc_strcpy(bl_DesignRevision_t5_LkoIntialAgency,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_LkoIntialAgency);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_LkoMakeBuyIndicator", &bl_DesignRevision_t5_LkoMakeBuyIndicator);
		if(tc_strlen(bl_DesignRevision_t5_LkoMakeBuyIndicator) == 0) tc_strcpy(bl_DesignRevision_t5_LkoMakeBuyIndicator,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_LkoMakeBuyIndicator);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_SgrIntialAgency", &bl_DesignRevision_t5_SgrIntialAgency);
		if(tc_strlen(bl_DesignRevision_t5_SgrIntialAgency) == 0) tc_strcpy(bl_DesignRevision_t5_SgrIntialAgency,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_SgrIntialAgency);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_SgrMakeBuyIndicator", &bl_DesignRevision_t5_SgrMakeBuyIndicator);
		if(tc_strlen(bl_DesignRevision_t5_SgrMakeBuyIndicator) == 0) tc_strcpy(bl_DesignRevision_t5_SgrMakeBuyIndicator,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_SgrMakeBuyIndicator);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_PnrIntialAgency", &bl_DesignRevision_t5_PnrIntialAgency);
		if(tc_strlen(bl_DesignRevision_t5_PnrIntialAgency) == 0) tc_strcpy(bl_DesignRevision_t5_PnrIntialAgency,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_PnrIntialAgency);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_PnrMakeBuyIndicator", &bl_DesignRevision_t5_PnrMakeBuyIndicator);
		if(tc_strlen(bl_DesignRevision_t5_PnrMakeBuyIndicator) == 0) tc_strcpy(bl_DesignRevision_t5_PnrMakeBuyIndicator,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_PnrMakeBuyIndicator);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_MThickness", &bl_DesignRevision_t5_MThickness);
		if(tc_strlen(bl_DesignRevision_t5_MThickness) == 0) tc_strcpy(bl_DesignRevision_t5_MThickness,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_MThickness);

		AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_CategoryName", &bl_DesignRevision_t5_CategoryName);
		if(tc_strlen(bl_DesignRevision_t5_CategoryName) == 0) tc_strcpy(bl_DesignRevision_t5_CategoryName,"--");
		printf("\nbl_value == %s\n",bl_DesignRevision_t5_CategoryName);

		//AOM_ask_value_string(rev_tag_br,"bl_Design Revision_t5_PartStatus", &bl_DesignRevision_t5_PartStatus);
		//if(tc_strlen(bl_DesignRevision_t5_PartStatus) == 0) tc_strcpy(bl_DesignRevision_t5_PartStatus,"--");
		//printf("\nbl_DesignRevision_t5_PartStatus value == %s\n",bl_DesignRevision_t5_PartStatus);fflush(stdout);

		printf("\nbl_DesignRevision_t5_PartStatus value == %s\n",bl_DesignRevision_t5_PartStatus);fflush(stdout);

		sprintf(line,"%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::",bl_value, item_id, item_rev_id, bl_item_object_desc, bl_revision_t5_DocRemarks, bl_revision_t5_ProjectCode, bl_rev_t5designgroup, owning_organization, bl_Design_revision_t5_Weight, bl_Design_revision_t5_LeftRh_Comp, bl_design_revision_t5_ColourInd, bl_design_revision_t5_ColourID, bl_desig_revision_t5_NcPartNo, bl_desig_revision_t5_PrtCatCode, bl_design_revision_t5_Coated, bl_design_revision_t5_StdPartIndicator, bl_DesignRevision_t5_DsgnDept, bl_DesignRevision_t5_SpareInd, bl_DesignRevision_t5_MatlClass, bl_DesignRevision_t5_Recoverable, bl_DesignRevision_t5_Reliability, bl_DesignRevision_t5_Dismantable, bl_DesignRevision_t5_Product, bl_DesignRevision_t5_PkgStd, bl_DesignRevision_t5_CMVRCertificationReqd, bl_DesignRevision_t5_HomologationReqd, bl_DesignRevision_t5_HazardousContents, bl_DesignRevision_t5_Recyclability, bl_DesignRevision_t5_ClassificationHazardous, bl_DesignRevision_t5_EnvelopeDimensions, bl_DesignRevision_t5_DsgnOwn, bl_DesignRevision_t5_PunIntialAgency, bl_DesignRevision_t5_PunMakeBuyIndicator, bl_DesignRevision_t5_JsrIntialAgency, bl_DesignRevision_t5_JsrMakeBuyIndicator, bl_DesignRevision_t5_LkoIntialAgency, bl_DesignRevision_t5_LkoMakeBuyIndicator, bl_DesignRevision_t5_SgrIntialAgency, bl_DesignRevision_t5_SgrMakeBuyIndicator, bl_DesignRevision_t5_PnrIntialAgency, bl_DesignRevision_t5_PnrMakeBuyIndicator, bl_DesignRevision_t5_MThickness, bl_DesignRevision_t5_CategoryName, bl_DesignRevision_t5_PartType, bl_DesignRevision_t5_PartStatus);

		printf("\n\n%s", line);
		
		if(attributeFile) fprintf(attributeFile,"%s\n",line);fflush(attributeFile);
		if(attributeFile) fclose(attributeFile);
	}
	
	AOM_ask_value_tag(rev_tag_br, "bl_line_object",&rev_tag_c);
	if(rev_tag_c != NULLTAG)
	{
		AOM_ask_value_date(rev_tag_br,"awb0RevisionLastModifiedDate", &awb0RevisionLastModifiedDate);
		DATE_date_to_string(awb0RevisionLastModifiedDate,dateFormat,&dateTime);

		AOM_ask_value_tag(rev_tag_br,"awb0RevisionOwningUser", &userTag);
		if(userTag != NULLTAG)
		{
			AOM_ask_value_string(userTag,"user_name", &user_name);
			if(tc_strlen(user_name) == 0) tc_strcpy(user_name,"--");
			printf("\n user_name == %s\n",user_name);
			AOM_ask_value_tag(userTag,"person",&personTag);
			if(personTag != NULLTAG)
			{
				AOM_ask_value_string(personTag,"PA9", &emailId);
				if(tc_strlen(emailId) == 0) tc_strcpy(emailId,"--");
				printf("\n emailId == %s\n",emailId);
			}
		}
	}	
	
	if(tc_strlen(dateTime) == 0) tc_strcpy(dateTime,"--");
	printf("\n dateTime == %s\n",dateTime);

	if(tc_strcmp(DataFlag,"N") == 0)
	{
		tc_strcpy(cad,"NA");
		tc_strcpy(drw,"NA");
		tc_strcpy(jt,"NA");
		tc_strcpy(pdf,"NA");
	}
	else
	{
		if(rev_tag_c != NULLTAG)
		{	
			if(tc_strcmp(DataFlag,"B") == 0 || tc_strcmp(DataFlag,"C") == 0) getFileDetails(rev_tag_c, "IMAN_specification", &cad, &drw, fp1);
			if(tc_strcmp(DataFlag,"B") == 0 || tc_strcmp(DataFlag,"J") == 0) getFileDetails(rev_tag_c, "IMAN_Rendering", &jt, &pdf,fp1);

			if(tc_strcmp(DataFlag,"J") == 0)
			{
				printf("\nIN J Condition\n");
				tc_strcpy(cad,"NA");
				tc_strcpy(drw,"NA");
			}

			if(tc_strcmp(DataFlag,"C") == 0)
			{
				printf("\nIN C Condition\n");
				tc_strcpy(jt,"NA");
				tc_strcpy(pdf,"NA");
			}
		}
		else
		{
			printf("\n**** Item Revision Tag Not Found ****");
			tc_strcpy(cad,"ITEMTAGNOTFOUND");
			tc_strcpy(drw,"ITEMTAGNOTFOUND");
			tc_strcpy(jt,"ITEMTAGNOTFOUND");
			tc_strcpy(pdf,"ITEMTAGNOTFOUND");
		}
	}
	sprintf(attribute,"%d::%s::%s::%s::%d::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s::%s", bl_level_starting_0,item_id,item_rev_id, bl_DesignRevision_t5_PartType,  bl_is_occ_suppressed_logical, parentName, bl_occurrence_name,jt,cad,pdf,drw,bl_plmxml_occ_xform, user_name, emailId, dateTime, stripBlanks(bl_rev_release_status_value), bl_value, bl_item_object_desc, bl_DesignRevision_t5_PartStatus);		
	printf("\n\n%s", attribute); fflush(stdout);
	if(fp) fprintf(fp,"%s\n",attribute);fflush(fp);
	printf("\nExiting Get_Bom_line_attr_list function BVR");fflush(stdout);
}

int getChildren(tag_t bomLine, const char* AttrFile_File, const char* DataFlag, const char* AttributeFlag, FILE *bom_fptr, FILE *cadJTFptr)
{
	int iFail = 0;
	int i_ChildCount = 0;
	int iChldPrts = 0;
	char* item_id = NULL;
	tag_t* t_PartChildren;
	
	AOM_ask_value_string(bomLine, "awb0BomLineItemId", &item_id);
	printf("\nitem_id === %s\n", item_id);fflush(stdout);
	iFail = BOM_line_ask_child_lines (bomLine, &i_ChildCount, &t_PartChildren);

	if (i_ChildCount>0)
	{
		for (iChldPrts = 0; iChldPrts < i_ChildCount; iChldPrts++)
		{
			iFail = Get_Bom_line_attr_list(t_PartChildren[iChldPrts], AttrFile_File, item_id, DataFlag, AttributeFlag, bom_fptr, cadJTFptr);
			iFail = getChildren(t_PartChildren[iChldPrts], AttrFile_File, DataFlag, AttributeFlag, bom_fptr, cadJTFptr);
		}
	}
}

int ITK_user_main(int argc, char* argv[])
{

	int status ;
	int expansionLevel = 0 ;

	char* user=NULL;
	char* passwd=NULL;
	char* group=NULL;
	char* inputpart=NULL;
	char* partRev=NULL;
	char* RevRule=NULL;
	char* DataFlag=NULL;
	char* ExplLevel=NULL;
	char* AttributeFlag=NULL;
	char* Bom_File=NULL;
	char* CadJT_File=NULL;
	char* AttrFile_File=NULL;
	char* PartNumber=NULL;
	char *inputFile=NULL;
	char *value=NULL;
	char *attrval=NULL;
	char *item_id=NULL;
	char fileLine[300];
	char line[100];
	
	/* testing*/
	char *bl_value=NULL;
	tag_t t_BomLineWindow= NULLTAG;
	tag_t  t_TopLine = NULLTAG;
	tag_t  t_Childobject = NULLTAG;
	tag_t  t_Rule = NULLTAG;
	tag_t  view_tag = NULLTAG;
	int iblType=0;
	char *State=NULL;
	char *ChilNum=NULL;
	char *ChilRev=NULL;
	int	i_ChildCount=0,iChldPrts=0;
	tag_t *t_PartChildren;
	/* testing ends*/

	tag_t rev_tag = NULLTAG;
	FILE *bom_fptr = NULL;
	FILE *inFptr = NULL;
	FILE *cadJTFptr = NULL;
	int ii,i=0;
	int iFail = ITK_ok;
	vector<tag_t> pVec;	
	

	(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	user=ITK_ask_cli_argument("-u=");
	passwd=ITK_ask_cli_argument("-p=");
	if(!passwd) passwd=ITK_ask_cli_argument("-pf=");
	group=ITK_ask_cli_argument("-g=");
	inputFile = ITK_ask_cli_argument("-k=");	
		
	//if( ITK_init_module(user,passwd,group)!=ITK_ok) ;
	(ITK_auto_login( ));
	(ITK_set_journalling( TRUE ));
	printf("\n Inside GetBOMJTandCADDetails %s  %s ",inputpart,partRev);

	inFptr=fopen(inputFile,"r");
	while(fgets(fileLine,sizeof fileLine,inFptr)!=NULL && !feof( inFptr ))
	{

		inputpart=strtok(fileLine,",");
		partRev= strtok(NULL,",");
		RevRule= strtok(NULL,",");
		DataFlag= strtok(NULL,",");
		ExplLevel= strtok(NULL,",");
		AttributeFlag= strtok(NULL,",");
		Bom_File= strtok(NULL,",");
		CadJT_File= strtok(NULL,",");
		AttrFile_File= strtok(NULL,",");

		printf("\n PartNumner is %s:%s, \t RevRule is %s , \t DataRequired %s \tLevel %s , \tAttribute Required%s",inputpart,partRev,RevRule,DataFlag,ExplLevel,AttributeFlag);fflush(stdout);
		printf("\n BOM File %s \n CAD/JT data download file is %s \n Attribute File is %s",Bom_File,CadJT_File,AttrFile_File);fflush(stdout);
		
		ITK_CALL(ITEM_find_rev(inputpart,partRev,&rev_tag));
		
		//tc_strcpy(State, RevRule);
		iFail = BOM_create_window (&t_BomLineWindow);
		iFail = CFM_find(State, &t_Rule );
		iFail = BOM_set_window_config_rule( t_BomLineWindow, t_Rule );
		iFail = BOM_set_window_pack_all (t_BomLineWindow, false);
		iFail = BOM_set_window_top_line (t_BomLineWindow,NULLTAG,rev_tag, null_tag, &t_TopLine);
		if(t_TopLine != NULLTAG)
		{
			
			AOM_ask_value_string(t_PartChildren[iChldPrts], "awb0BomLineItemId", &item_id);
			printf("\nitem_id === %s\n", item_id);fflush(stdout);

			if(!bom_fptr) bom_fptr = fopen(Bom_File,"w"); 
			if(!cadJTFptr) cadJTFptr = fopen(CadJT_File,"w"); 
			iFail=Get_Bom_line_attr_list(t_TopLine, AttrFile_File, "NA", DataFlag, AttributeFlag, bom_fptr, cadJTFptr);
			if(tc_strcmp(ExplLevel,"S")==0)
			{
				printf("\nInside Single Level Expansion.");fflush(stdout);
				iFail = BOM_line_ask_child_lines (t_TopLine, &i_ChildCount, &t_PartChildren);

				printf("\nNumber of Child Found are :: %d\n",i_ChildCount );
				if (i_ChildCount>0)
				{
					for (iChldPrts = 0; iChldPrts < i_ChildCount; iChldPrts++)
					{
						iFail=Get_Bom_line_attr_list(t_PartChildren[iChldPrts], AttrFile_File, item_id, DataFlag, AttributeFlag, bom_fptr, cadJTFptr);
					}
				}
			}
			if(tc_strcmp(ExplLevel,"M")==0)
			{
				printf("\nInside Multiple Level Expansion.");fflush(stdout);
				iFail = getChildren(t_TopLine,AttrFile_File, DataFlag, AttributeFlag, bom_fptr, cadJTFptr);
			}		
		}
		
		printf("\n Exiting GetBOMJTandCADDetails %s  %s ",inputpart,partRev);	
		if(bom_fptr) fclose(bom_fptr); 
	}
}