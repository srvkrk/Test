/*
./compile MIS_VC_DateWise_Rep.c
./linkitk -o MIS_VC_DateWise_Rep MIS_VC_DateWise_Rep.o
scp MIS_VC_DateWise_Rep tkr06466@172.22.97.12:/user/plmsap/PLMSAP/tkr/clientcode/MIS_VC_DateWise_Rep
nohup ./MIS_VC_DateWise_Rep -u=tkr06466 -p=XYT1ESA -fromdate="01-Mar-2022" -todate="20-Mar-2022" -type='M' >1.log &
*/
#define TE_MAXLINELEN  128

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include <unidefs.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <stdarg.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
//#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <time.h>
#include <sa/am.h>
#include <fclasses/tc_date.h>
#define Debug TRUE
#define ITK_err 910001

int DFQApplCntflag=0;
int falseflagg=0;
int DFQpdfCount=0;
int DFQexcelsCount=0;
int MeetexpectationCnt=0;

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))



static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		//printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			//printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %s",len,text,str);fflush(stdout);
  return;
}




void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}



char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

char* DVACalulate()
{
	char* ptr = NULL;
	float percentage;

	ptr = (char *) MEM_alloc(sizeof(char)* 30);



	printf("\n\n DVACalulate--DFQApplcbltyCnt: [%d]  PDFAttachedCnt: [%d]  DFQMeetExpNoCnt: [%d] \n", DFQApplCntflag,DFQpdfCount,MeetexpectationCnt);fflush(stdout);


	if ((DFQApplCntflag != 0)&&(DFQpdfCount != 0))
	{

		percentage = (float)(MeetexpectationCnt) / DFQApplCntflag * 100.0;

		printf("\n  after calculation: Percentage = %.2f%%", percentage); fflush(stdout);
		sprintf(ptr,"%10lf",percentage);
		printf("\n  after conversion  to str: %s \n",ptr);fflush(stdout);

		return ptr;
	}
	else
	{
		return "0";
	}
}

char* GetDemeritScoreRating(char* DvloName , int DemeritScore)
{
	char* ptr = NULL;
	int dvr=0;


	ptr = (char *) MEM_alloc(sizeof(char)* 30);

      if (DvloName!=NULL)
	 {
		printf("\n  DvloName: %s   DemeritScore: %d",DvloName,DemeritScore);fflush(stdout);

		if (DemeritScore<=100)
		{
			dvr=100;
			printf("\n dvr value is 100*:%d",dvr);fflush(stdout);
		}
		else if( (DemeritScore<=130) && (DemeritScore>100))
		{
			dvr=80;
			printf("\n dvr value is 80*:%d",dvr);fflush(stdout);
		}
		else if (DemeritScore>130)
		{
			dvr=50;
			printf("\n dvr value is 50*:%d",dvr);fflush(stdout);
		}
		else
		{
			dvr=0;
			printf("\n dvr value is 0*:%d",dvr);fflush(stdout);
		}

		printf("\n dvr value is----:%d",dvr);fflush(stdout);
		sprintf(ptr,"%d",dvr);
		printf(" after conversion dvr: %s \n",ptr);fflush(stdout);

		return ptr;
	}
	else
	{
		return "0";
	}
}

int GetDVAUseCaseFromLibraryt(tag_t PartTag, char* t5_business_unit_type_mod, int* resultCount, tag_t **dfq_use_case_tags)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char* documentName;
	char* s;
	char* moduleAddressS;
	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	tag_t queryTag = NULLTAG;
	tag_t *dfq_use_case_tags1 = NULLTAG;


	/*--------------------------------------------------------
		Get Applicable DFQ USE CASE
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"bl_Design Revision_t5_ModuleAddress",&moduleAddressS);
	printf("Module Address  :: %s\n",moduleAddressS);fflush(stdout);

	queryTag = NULLTAG;
	status =   QRY_find2("DFQ Use Case", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}
	else
	{
      printf("Tag found query\n");fflush(stdout);
	}

	if(tc_strcmp(t5_business_unit_type_mod,"CVBU") == 0) t5_business_unit_type_mod = "CV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU") == 0) t5_business_unit_type_mod = "PV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU and CVBU Both") == 0) t5_business_unit_type_mod = "PSE";
	else
	{
			EMH_ask_error_text( status, &s);
			MEM_free(s);
			return status;
	}

	//Query DFQ Use Case
	documentName = NULL;
	documentName = (char *)MEM_alloc(50);
	tc_strcpy(documentName, "DVA_");
	tc_strcat(documentName, t5_business_unit_type_mod);
	tc_strcat(documentName, "_");
	tc_strcat(documentName, moduleAddressS);
	tc_strcat(documentName, "*");

	qry_values1[0] = (char *)MEM_alloc(strlen(documentName ) + 1);
	tc_strcpy(qry_values1[0], documentName);

	//qry_values1[1] = (char *)MEM_alloc(10);
	//tc_strcpy(qry_values1[1], "DFQ Use Case");

    qry_entries[0] = (char *)MEM_alloc(10);
	strcpy(qry_entries[0], "Name");

	//qry_entries[1] = (char *)MEM_alloc(10);
	//strcpy(qry_entries[1], "Type");
	//strcpy(qry_entries[1], "object_type");



   printf("Name is  :: %s\n",qry_values1[0]);fflush(stdout);
  // printf("Type is  :: %s\n",qry_values1[1]);fflush(stdout);


	ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values1, &resultCount1, &dfq_use_case_tags1));
	printf("\nNo. of DFQ Use Case Document found are %d -- %s\n",resultCount1,documentName);fflush(stdout);

	if(resultCount1 > 0)
	{
		*dfq_use_case_tags = dfq_use_case_tags1;
		*resultCount = resultCount1;
	}

	return 0;
}

int getBusinessUnitFun(tag_t PartTag, char** ProjdescDup,char** Projname)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char *t5_business_unit_type_mod1;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"t5_ProjectCode",&t5_projectc_code_string);

	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status =   QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"object_desc",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjdescDup = t5_business_unit_type_mod;

	AOM_ask_value_string(proj_tags[0],"t5_VehicleClass",&t5_business_unit_type_mod1);
	printf("Vechile class -- %s\n",t5_business_unit_type_mod1);fflush(stdout);

	*Projname = t5_business_unit_type_mod1;

	return 0;
}

int getBusinessUnitFunct(tag_t PartTag, char** ProjbussDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"bl_Design Revision_t5_ProjectCode",&t5_projectc_code_string);

	printf("bl_Design Revision_t5_ProjectCode  %s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status =   QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  111111111111-- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit1111 -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}
int getBusinessUnitFunct22(tag_t PartTag, char** ProjbussDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"t5_ProjectCode",&t5_projectc_code_string);

	printf("\n ProjectCode  %s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status =   QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  111111111111-- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit1111 -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}




extern int ITK_user_main(int argc, char ** argv )
{
	int status				= ITK_ok;
     char*DvloNameStr=NULL;
     char*gcinam=NULL;
     char*VehicleNo=NULL;
	 char*VehicleRev=NULL;
     char*VehicleSeq=NULL;
     char*VehicleDR=NULL;
	 DvloNameStr	=(char *) MEM_alloc(sizeof(char)* 50);
	 VehicleNo	=(char *) MEM_alloc(sizeof(char)* 50);
	 VehicleSeq	=(char *) MEM_alloc(sizeof(char)* 50);
	 VehicleRev	=(char *) MEM_alloc(sizeof(char)* 50);
	 VehicleDR	=(char *) MEM_alloc(sizeof(char)* 50);
	 gcinam	=(char *) MEM_alloc(sizeof(char)* 50);
	  char*rev_id=NULL;
	 //rev_id	=(char *) MEM_alloc(sizeof(char)* 50);
	 char*DvloName=NULL;
	 DvloName	=(char *) MEM_alloc(sizeof(char)* 50);


	 tag_t DitemTAG			 = NULLTAG;
	 tag_t VechRevTag		 = NULLTAG;
	 tag_t VCDMLRevTag		 = NULLTAG;
	 tag_t cmSolTag		 = NULLTAG;
	 tag_t*GciObj=NULLTAG;
	 tag_t*VCtaskObjSO=NULLTAG;
	 tag_t GCI_relation=NULLTAG;
	 tag_t VCDMLobjTypTag=NULLTAG;
	 tag_t VCDML_tag=NULLTAG;
	 tag_t Vechtag=NULLTAG;
	 tag_t GCItag=NULLTAG;
	 int gcicnt=0;
	 int gci=0;

	 
	char*	strDVA		=NULL;
	char*	strDSR		=NULL;
	char*	DVLODsetID	=NULL;
	char*	GCIStr		=NULL;

	int DemeritScore=0;
	int VCtaskcnt=0;
	int dsr=0;
	FILE* file=NULL;
	FILE* file1=NULL;
	char*	fsuccess_nam		=NULL;
	fsuccess_nam = (char *)MEM_alloc(200);

	double GCI;
	double dVA;
	double dSR;
	double Strdsr;
	char *Csvpath=NULL;
	char *VCtaskName=NULL;
	char *VCDMLRlstype=NULL;
	char *VCDMLtype=NULL;
	char *VPrtModNum=NULL;
	char *ProjbussDup=NULL;
	char *ProjdescDup=NULL;
	char *Projname=NULL;
	char *VPrtdesc=NULL;
	char *Owner=NULL;
	char *partsts=NULL;
	char *partstsDup=NULL;
	char *prjcode=NULL;
	char *Vcno=NULL;
	//char *Creationdate=NULL;
	char *prjcodeDup=NULL;
	char *VPrtModNumType=NULL;
	 char *CurRe=NULL;
	 char *GCIDocPath=NULL;
	 char *PartRelStat=NULL;
	 //char VCDMLobjType[WSO_name_size_c+1];
	 char *VCDML=NULL;
	 char *VCDMLobjType=NULL;
	 char *CurSe=NULL;
	 char	Data[100]= "";
	 struct 	tm when;
	 // char fsuccess_nam[200];
	 time_t 	now;

	 int k = 0;

	 Csvpath = (char *)MEM_alloc(200);
	Owner = (char *)MEM_alloc(200);
	CurRe = (char *)MEM_alloc(100);
	CurSe = (char *)MEM_alloc(100);
	char*VCdmlTaskNo=(char *) MEM_alloc(sizeof(char)* 100);

	 time(&now);
	 when = *localtime(&now);
     strftime(Data,100,"%Y_%b_%d_%H_%M_%S",&when);

	 date_t Creationdateout;
	 char* Creationdate		= NULL;

	//cal
	//char*DvloName=NULL;
	//char*DScore=NULL;

	GCIStr= (char *) MEM_alloc(sizeof(char)* 10);

    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login());
	ITK_CALL(ITK_set_journalling( TRUE ));
	VehicleNo = ITK_ask_cli_argument("-Gci=");
	rev_id = ITK_ask_cli_argument("-rev_id=");
	VCDML = ITK_ask_cli_argument("-VCDML=");

     printf("\n VehicleNo [%s] ,rev_id [%s],VCDML [%s]  ",VehicleNo,rev_id,VCDML);fflush(stdout);

	 if(DvloNameStr)
     {

//        gcinam = tc_strtok(DvloNameStr,"_");  
//		VehicleNo = tc_strtok(NULL,"_");
//		VehicleRev = tc_strtok(NULL,"_");
//		VehicleSeq = tc_strtok(NULL,"_");

		printf("vech,VCDML,%s,%s",VehicleNo,VCDML);fflush(stdout);

//        tc_strcpy(rev_id,"");
//		tc_strcat(rev_id,VehicleRev);
//		tc_strcat(rev_id,";");
//		tc_strcat(rev_id,VehicleSeq);
		printf("\n Rev Input: [%s]  ",rev_id);fflush(stdout);

	 }

	   ITEM_find_item(VehicleNo,&Vechtag);

	  

	   if(Vechtag!=NULLTAG)
	   {
		 
		 printf("\nTag found\n");

	    ITEM_find_revision(Vechtag,rev_id,&VechRevTag);
	   }
	   else
	   {
	     printf("\nTag Not found\n");
	   
	   }

	 if (VechRevTag!=NULLTAG)
	{
	   ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

		   ITK_CALL(GRM_list_secondary_objects_only(VechRevTag,GCI_relation,&gcicnt,&GciObj));

		   for(gci=0;gci<gcicnt;gci++)
		  {
			printf("\n inside for loop\n");fflush(stdout);

			GCItag=GciObj[gci];

		  }
		  //dsr=atoi(strDSR);
		//ITK_CALL(AOM_lock(DVLONewDataset));
		ITK_CALL(AOM_refresh(GCItag,1));
			
//		printf("\n before setting value GCI, strDSR, strDVA= %s,%s,%s\n",GCIStr,strDSR,strDVA);fflush(stdout);
//			
//		ITK_CALL(AOM_UIF_set_value(GCItag,"t5_DVA_value_d1",strDVA));						//double not supported		DVA value(D)
//		ITK_CALL(AOM_set_value_int(GCItag,"t5_demerit_score_rating_S1",dsr));			//int not supported			DMU Demerit Score Rating(S)
//		ITK_CALL(AOM_set_value_double(GCItag,"t5_geometry_conf_index_a1",GCI));		//double not supported		Geometry conformance Index(A)
//		ITK_CALL(AOM_set_value_int(GCItag,"t5_demerit_score_v1",DemeritScore));			//int						DMU Demerit score(V)

		if(VCDML!=NULL)
		{
		ITK_CALL(AOM_set_value_string(GCItag,"t5_DVLODmlNo1",VCDML));
		}
			
		ITK_CALL(AOM_save_with_extensions(GCItag));
		printf("\n after saving GCI\n");fflush(stdout);
		ITK_CALL(AOM_refresh(GCItag,0));
	}


	 

//if(DvloNameStr)
//{
//
//        gcinam = tc_strtok(DvloNameStr,"_");  
//		VehicleNo = tc_strtok(NULL,"_");
//		VehicleRev = tc_strtok(NULL,"_");
//		VehicleSeq = tc_strtok(NULL,"_");
//		//VehicleDR = tc_strtok(NULL,"_");
//
//		//printf("vech,rev,seq,DR: %s,%s,%s,%s",VehicleNo,VehicleRev,VehicleSeq,VehicleDR);fflush(stdout);
//		printf("vech,rev,seq: %s,%s,%s",VehicleNo,VehicleRev,VehicleSeq);fflush(stdout);
//
//        tc_strcpy(rev_id,"");
//		tc_strcat(rev_id,VehicleRev);
//		tc_strcat(rev_id,";");
//		tc_strcat(rev_id,VehicleSeq);
//
//        printf("\n Rev Input: [%s]  ",rev_id);fflush(stdout);
//
//
//      
//		 ITK_CALL(AOM_ask_value_date(Vechtag,"creation_date",&Creationdateout));
//	  ITK_CALL(DATE_date_to_string(Creationdateout,"%d/%m/%Y",&Creationdate));
//	   printf("\n Design Revision Creation Date [%s]\n",Creationdate);   fflush(stdout);
//
//		if(Vechtag != NULLTAG)
//	    {
//         
//
//         if(VechRevTag != NULLTAG)
//		   {
//
//           
//
//
//		  ITK_CALL(AOM_ask_value_string(VechRevTag,"item_id",&VPrtModNum));
//     printf("\nV number is [%s]\n",VPrtModNum); fflush(stdout);
//
//	
//     ITK_CALL(AOM_ask_value_string(VechRevTag,"object_desc",&VPrtdesc));
//     ITK_CALL(AOM_ask_value_string(VechRevTag,"t5_PartStatus",&partsts));
//	  ITK_CALL(AOM_ask_value_string(VechRevTag,"item_revision_id",&VPrtModNumType));
//	 // ITK_CALL(AOM_ask_value_string(VechRevTag,"creation_date",&Creationdate));
//	 /* ITK_CALL(AOM_ask_value_date(VechRevTag,"creation_date",&Creationdateout));
//	  ITK_CALL(DATE_date_to_string(Creationdateout,"%d/%m/%Y",&Creationdate));
//	   printf("\n Design Revision Creation Date [%s]\n",Creationdate);   fflush(stdout);*/
//
//	   ITK_CALL(AOM_UIF_ask_value(VechRevTag,"release_status_list",&PartRelStat));
//	   printf("\n Design Revision release status is [%s]\n",PartRelStat);   fflush(stdout);
//
//	   if(tc_strstr(PartRelStat,"ERC Released")==NULL)
//	   {
//
//	   	printf("\n Inside the WIP vault condition\n"); fflush(stdout);
//	   	tc_strcpy(Owner,"WIP Vault");
//
//		ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &cmSolTag));
//		if(GRM_list_primary_objects_only(VechRevTag,cmSolTag,&VCtaskcnt,&VCtaskObjSO));
//	        printf("\n solution task count****** is 1 %d.\n",VCtaskcnt); fflush(stdout);
//
//			if(VCtaskcnt>0)
//		    {
//
//				for(k=0;k<VCtaskcnt;k++)
//				{
//					 if(AOM_ask_value_string(VCtaskObjSO[k],"item_id",&VCtaskName));
//						printf("\n VC task name : 1 [%s] \n", VCtaskName);fflush(stdout);
//
//						   if(tc_strcmp(VCtaskName,"")!=0)
//						  {
//							  VCdmlTaskNo = tc_strtok(VCtaskName,"_");
//							  printf("\n VC DML name : 1 [%s] \n", VCdmlTaskNo);fflush(stdout);
//						  }
//
//						  if(ITEM_find_item(VCdmlTaskNo, &VCDML_tag)!=ITK_ok);
//
//						  if (VCDML_tag != NULLTAG)
//						  {
//								printf("\n DML No is for vechile :1 [%s] \n", VCdmlTaskNo);fflush(stdout);
//
//								if(ITEM_ask_latest_rev(VCDML_tag, &VCDMLRevTag)!=ITK_ok);
//
//								/*ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"item_id",&VCDML));
//								printf("\n  item_id is %s\n", VCDML);fflush(stdout);*/
//
//								ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"t5_rlstype",&VCDMLtype));
//								printf("\n  VC DML type is1 : [%s]\n", VCDMLtype); fflush(stdout);
//
//								ITK_CALL(TCTYPE_ask_object_type(VCDMLRevTag,&VCDMLobjTypTag));
//								printf("\n  after object taggggggg21222 \n");fflush(stdout);
//
//								ITK_CALL(TCTYPE_ask_name2(VCDMLobjTypTag,&VCDMLobjType));
//								printf("\n  object_type is1 %s\n", VCDMLobjType);fflush(stdout);
//
//								if(tc_strcmp(VCDMLobjType,"ChangeRequestRevision")==0)
//								{
//
//
//								ITK_CALL(AOM_UIF_ask_value(VCDMLRevTag,"release_status_list",&VCDMLRlstype));
//								printf("\n  VC DML rls is 1 : [%s]\n", VCDMLRlstype); fflush(stdout);
//
//								
//
//								if((tc_strcmp(VCDMLtype,"Veh")==0) && (tc_strstr(VCDMLRlstype,"ERC Released")==NULL))
//								{
//									printf("\n inside the if condition before break..1..\n"); fflush(stdout);
//
//									ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"item_id",&VCDML));
//								    printf("\n  item_id is1 %s\n", VCDML);fflush(stdout);
//									//break;
//								}
//								
//								}
//						  }
//						  else
//						  {
//							printf("\n DML not found****8 \n");fflush(stdout);
//
//
//
//
//						  }
//				
//				
//				
//				}
//
//			}
//
//
//
//
//	   }
//	   else
//	   {
//
//	   	printf("\n Inside the Release vault condition\n"); fflush(stdout);
//	   	tc_strcpy(Owner,"Release Vault");
//
//		//ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &cmSolTag));       //solution relation tag
//		ITK_CALL(GRM_find_relation_type("CMReferences", &cmSolTag));       //CMReferences relation tag
//
//		if(GRM_list_primary_objects_only(VechRevTag,cmSolTag,&VCtaskcnt,&VCtaskObjSO));
//		  printf("\n DML count is %d\n",VCtaskcnt); fflush(stdout);
//
//			 if(VCtaskcnt>0)
//					 {
//
//						for(k=0;k<VCtaskcnt;k++)
//						{
//
//						  if(AOM_ask_value_string(VCtaskObjSO[k],"item_id",&VCtaskName));
//						  printf("\n VC task name : [%s] \n", VCtaskName);fflush(stdout);
//
//
//						  if(tc_strcmp(VCtaskName,"")!=0)
//						  {
//							  VCdmlTaskNo = tc_strtok(VCtaskName,"_");
//							  printf("\n VC DML name : [%s] \n", VCdmlTaskNo);fflush(stdout);
//						  }
//
//						  if(ITEM_find_item(VCdmlTaskNo, &VCDML_tag)!=ITK_ok);
//
//						  if (VCDML_tag != NULLTAG)
//						  {
//								printf("\n DML No is for vechile : [%s] \n", VCdmlTaskNo);fflush(stdout);
//
//								if(ITEM_ask_latest_rev(VCDML_tag, &VCDMLRevTag)!=ITK_ok);
//
//								/*ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"item_id",&VCDML));
//								printf("\n  item_id is %s\n", VCDML);fflush(stdout);*/
//
//								ITK_CALL(TCTYPE_ask_object_type(VCDMLRevTag,&VCDMLobjTypTag));
//								printf("\n  after object taggggggg2222 \n");fflush(stdout);
//
//								ITK_CALL(TCTYPE_ask_name2(VCDMLobjTypTag,&VCDMLobjType));
//								printf("\n  object_type is %s\n", VCDMLobjType);fflush(stdout);
//
//								if(tc_strcmp(VCDMLobjType,"ChangeRequestRevision")==0)
//								{
//
//
//								ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"t5_rlstype",&VCDMLtype));
//								printf("\n  VC DML type is : [%s]\n", VCDMLtype); fflush(stdout);
//
//								ITK_CALL(AOM_UIF_ask_value(VCDMLRevTag,"release_status_list",&VCDMLRlstype));
//								printf("\n  VC DML rls is :111111111 [%s]\n", VCDMLRlstype); fflush(stdout);
//
//								
//
//
//								if(tc_strstr(VCDMLRlstype,"ERC Released")==NULL)
//								{
//									ITK_CALL(AOM_ask_value_string(VCDMLRevTag,"item_id",&VCDML));
//								    printf("\n  item_id is22222 %s\n", VCDML);fflush(stdout);
//								}
//								else
//								{
//									printf("\n inside the else condition after break222222....\n"); fflush(stdout);
//									
//								}
//
//								}
//						  }
//						  else
//						  {
//							printf("\n DML not found****8 \n");fflush(stdout);
//						  }
//
//						}
//
//					 }
//
//	   }
//	 tc_strdup(partsts,&partstsDup);
//	  CurRe = strtok(VPrtModNumType,";");
//	 CurSe = strtok(NULL,";");
//
//
//     ITK_CALL(AOM_ask_value_string(VechRevTag,"t5_ProjectCode",&prjcode));
//	 tc_strdup(prjcode,&prjcodeDup);
//	 ITK_CALL(PREF_ask_char_value("T5_GCICSV_Destination_path_uaprodtrl",0,&GCIDocPath));
//	 printf("\n GCIDocPath :[%s]\n",GCIDocPath);   fflush(stdout);
//	 ITK_CALL(getBusinessUnitFunct22(VechRevTag, &ProjbussDup));
//	 printf("Value of project code is %s",ProjbussDup);fflush(stdout);
//	 ITK_CALL(getBusinessUnitFun(VechRevTag, &ProjdescDup,&Projname));
//
//	 tc_strcpy(Csvpath,"");
//     tc_strcpy(Csvpath,GCIDocPath);
//	 sprintf(fsuccess_nam,"MIS_DVA_VC_%s_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname,Data);
//	/* sprintf(fsuccess_nam,"MIS_DVA_VC_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname);
//	 sprintf(fsuccess_nam,"MIS_DVA_VC_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup);*/
//     //sprintf(fsuccess_nam,"%s_%s_%s_DVA_Matrix_%s.csv",VPrtModNum,CurRe,CurSe,Data);
//     tc_strcat(Csvpath,fsuccess_nam);
//     printf("\n file path is*** :[%s]\n",Csvpath);   fflush(stdout);
//
//
//	 /***************/
//
//	 file = fopen(Csvpath,"w");
//	 //file = NULL;
//
//     //fseek(file, 2, SEEK_SET);
//
//	 fprintf(file,",,,,DVA MIS Report VC Wise,,date-%s,,,,,,\n",Data);
//	 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
//	 fprintf(file,",,,Description,%s,,,,,,,\n",VPrtdesc);
//	 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
//	fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
//	 fprintf(file,",,,Last Updated,,,,,,,\n");
//	 fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
//	// fprintf(file1,",,,Project Description,%s,,,,,,\n",ProjdescDup);
//	fprintf(file,",,,Demerit Score(V),%d,,,,\n",DemeritScore);
//	 fprintf(file,",,,Demerit Score Rating(S),%d,,,\n",dsr);
//	 fprintf(file,",,,Geometry conformance Index(A),%lf,,\n\n\n",GCI);
//
//	 /************************/
//		   
//		     printf("\n calling function SendVCdetailsForGCI\n");fflush(stdout);
//		     SendVCdetailsForGCI(VechRevTag,GCItag,&file,&Csvpath);
//			 printf("\n calling function SendVCdetailsForGCI end\n");fflush(stdout);
//
//
//			 printf("\n\n DFQApplCntflag: [%d]  DFQpdfCount: [%d]  MeetexpectationCnt: [%d] \n", DFQApplCntflag,DFQpdfCount,MeetexpectationCnt);fflush(stdout);
//	//tc_strdup(DVACalulate(),&strDVA);
//	strDVA=DVACalulate();
//	printf("\n strDVA= [%s] \n", strDVA);fflush(stdout);
//
//	if(GCItag != NULLTAG)
//	{
//
//			//DemeritScore=((100*atoi(Pointer_100_Val)) + (40*atoi(Pointer_40_Val)) + (10*atoi(Pointer_10_Val)) + (20*atoi(Pointer_20_Val)) + (1*atoi(Pointer_1_Val)));
//			ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&DemeritScore));
//			printf("\n Total DemeritScore: %d \n",DemeritScore);fflush(stdout);
//
//			ITK_CALL(AOM_ask_value_string(GCItag,"t5_DVLO_Name1",&DvloName));
//			printf("\n GCIName :[%s]\n",DvloName);fflush(stdout);
//
//		  //tc_strdup(GetDemeritScoreRating(DvloName,DemeritScore),&strDSR);
//			printf("calling GetDemeritScoreRating fun");fflush(stdout);
//			strDSR=GetDemeritScoreRating(DvloName,DemeritScore);
//			printf("  strDSR= [%s] ", strDSR);fflush(stdout);
//
//		    if (strDVA!=NULL && strDSR!=NULL)
//		    {
//			 dVA=strtod(strDVA,NULL);
//			 dSR=strtod(strDSR,NULL);
//		    
//			 printf("\n dVA: %lf   dSR: %lf ",dVA,dSR);fflush(stdout);
//			 printf("\n Inside the 2023 condition\n");fflush(stdout);
//
//			 GCI=((0.5*dSR) + (0.5*dVA));
//			 printf("\n After Multiplication dVA: %lf   dSR: %lf ",dVA,dSR);fflush(stdout);
//		    
//			 printf("\n  GCI-after calculation: %lf",GCI);fflush(stdout);
//		    
//			 sprintf(GCIStr,"%10lf",GCI);
//			 printf("\n  after conversion  to GCIStr: %s \n",GCIStr);fflush(stdout);
//		   /*  if(tc_strstr(Creationdate,"2024")==NULL)
//			{
//			 printf("\n Inside the 2023 condition\n");fflush(stdout);
//
//			 GCI=((0.5*dSR) + (0.5*dVA));
//			 printf("\n After Multiplication dVA: %lf   dSR: %lf ",dVA,dSR);fflush(stdout);
//		    
//			 printf("\n  GCI-after calculation: %lf",GCI);fflush(stdout);
//		    
//			 sprintf(GCIStr,"%10lf",GCI);
//			 printf("\n  after conversion  to GCIStr: %s \n",GCIStr);fflush(stdout);
//			}
//			else if(tc_strstr(Creationdate,"2024")!=NULL)
//			{
//			  printf("\n Inside the 2024 condition\n");fflush(stdout);
//			 GCI=((0.25*dSR) + (0.75*dVA));
//			 printf("\n After Multiplication dVA: %lf   dSR: %lf ",dVA,dSR);fflush(stdout);
//		    
//			 printf("\n  GCI-after calculation: %lf",GCI);fflush(stdout);
//		    
//			 sprintf(GCIStr,"%10lf",GCI);
//			 printf("\n  after conversion  to GCIStr: %s \n",GCIStr);fflush(stdout);
//			
//			
//			}*/
//		    
//		    }
//
//			if(DFQApplCntflag!=0)
//			{
//				
//			
//			}
//			else
//			{
//				dsr=atoi(strDSR);
//				//ITK_CALL(AOM_lock(DVLONewDataset));  //check out dataset ---> ITK_CALL(AOM_refresh(DVLONewDataset,1));
//				ITK_CALL(AOM_refresh(GCItag,1));
//					
//				printf("\n before setting value GCI, strDSR, strDVA1= %s,%s,%s\n",GCIStr,strDSR,strDVA);fflush(stdout);
//					
//				ITK_CALL(AOM_UIF_set_value(GCItag,"t5_DVA_value_d1",strDVA));					//double not supported		DVA value(D)
//				ITK_CALL(AOM_set_value_int(GCItag,"t5_demerit_score_rating_S1",dsr));			//int not supported			DMU Demerit Score Rating(S)
//					
//				Strdsr=(double)dsr;
//					
//				printf("\n  GCI setting after type cast: %lf",Strdsr);fflush(stdout);
//				ITK_CALL(AOM_set_value_double(GCItag,"t5_geometry_conf_index_a1",Strdsr));	//double not supported		Geometry conformance Index(A)
//				ITK_CALL(AOM_set_value_int(GCItag,"t5_demerit_score_v1",DemeritScore));		//int						DMU Demerit score(V)
//				if(VCDML!=NULL)
//				{
//				ITK_CALL(AOM_set_value_string(GCItag,"t5_DVLODmlNo1",VCDML));
//				}
//					
//				ITK_CALL(AOM_save_with_extensions(GCItag));
//				printf("\n after saving GCI*****\n");fflush(stdout);
//				ITK_CALL(AOM_refresh(GCItag,0));												//checkin dataset
//			
//			}
//
//	}
//      
//    file = fopen(Csvpath,"r+");
//	 //file = NULL;
//
//     //fseek(file, 2, SEEK_SET);
//
//	 fprintf(file,",,,,DVA MIS Report VC Wise,,date-%s,,,,,,\n",Data);
//	 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
//	 fprintf(file,",,,Description,%s,,,,,,,\n",VPrtdesc);
//	 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
//	 fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
//	 fprintf(file,",,,Last Updated,,,,,,,\n");
//	 fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
//	// fprintf(file1,",,,Project Description,%s,,,,,,\n",ProjdescDup);
//	 fprintf(file,",,,Demerit Score(V),%d,\n",DemeritScore);
//	 fprintf(file,",,,Demerit Score Rating(S),%d\n",dsr);
//	 fprintf(file,",,,Geometry conformance Index(A),%lf\n",GCI);
//	// fprintf(file1,"\n,\n,\n",GCI,DemeritScore,dsr);
//
//	// fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DVA UID,Applicability,DVA Justification Comment,DVA Documents Number,PDF,Xlsx,DVA Meet the Expectations (Yes/No),DVA Use case Description\n");
//
//	 fclose(file);
//
//	      if(Csvpath)
//	      {
//           
//		   char*reference_nameGCI=NULL;
//		   tag_t file_tag = NULLTAG;
//	       IMF_file_t file_descriptor;
//	       AE_reference_type_t tagRefTypeText = 1;
//
//		     reference_nameGCI = (char *) MEM_alloc(10);
//
//             printf("\n before named reference GCI %s",Csvpath); fflush(stdout);
//		     tc_strcpy(reference_nameGCI,"T5_GCIDocRef");
//			 printf("\n named reference GCI %s",reference_nameGCI); fflush(stdout);
//
//
//            ITK_CALL(AOM_refresh(GCItag,TRUE));
//
//            ITK_CALL(IMF_import_file(Csvpath,NULL, SS_BINARY, &file_tag, &file_descriptor));
//			ITK_CALL(AOM_save_with_extensions(file_tag));
//			
//	        ITK_CALL(AE_add_dataset_named_ref2(GCItag,reference_nameGCI,tagRefTypeText,file_tag));
//	        printf("\n after named reference GCI \n"); fflush(stdout);
//			 
//            ITK_CALL(AOM_save_with_extensions(GCItag));
//			ITK_CALL(AOM_load(GCItag));	
//	         //ITK_CALL(AOM_unload(file_tag));
//			 ITK_CALL(AOM_refresh(GCItag,0));
//
//             printf("\n Done named reference GCI \n"); fflush(stdout);
//			
//		  }
//
//
//
//
//               
//
//
//		  }
//		 if(DFQApplCntflag>0)   
//		{
//			DFQApplCntflag=0; 
//		}
//
//		if(falseflagg>0)
//		{
//			falseflagg =0; 
//		}
//
//		if(DFQpdfCount>0)
//		{
//			DFQpdfCount=0;
//		}
//
//		if(DFQexcelsCount>0)
//		{
//			DFQexcelsCount=0; 
//		}
//
//		if(MeetexpectationCnt>0)
//		{
//			MeetexpectationCnt=0;
//		}
//	
//
//
//	   }





//}
       

	
	
	//printf("\nCLEANUP...\n"); fflush(stdout);
	return 0;
}
