// /user/cvprod/TC_ROOT14/tcldPatch/tcPatchExecutable IV_PO_Delete
// ./IV_PO_Delete -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
// CMITEST  -u=loader -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba
//  ./IV_PO_Delete -u="infodba" -pf="/home/cmitest/shells/Admin/infodbapawwdfile.pwf" -g="dba"
// $TC_ROOT/tcldPatch/tcPatchExecutable

//./IV_PO_Delete -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf
//./IV_PO_Delete -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf

#include <stdio.h>
#include <time.h>

#include <tc/emh.h>
#include <pom/pom/pom.h>

#include <qry/qry.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>

#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define PROP_UIF_set_value_msg		"PROP_UIF_set_value"
#define PROP_set_value_tag_msg		"PROP_set_value_tag"
#define PROP_ask_value_date_msg		"PROP_ask_value_date"
#define PROP_set_value_date_msg		"PROP_set_value_date"
#define PROP_set_value_string_msg   "PROP_set_value_string"
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

int query_object();


int			ifail 				= ITK_ok;
char		*sep				= "^";
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs,&pSevLst,&pErrCdeLst,&pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		fprintf( stderr, "Error(PrintErrorStack): \n");
		fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
	}
	return ITK_ok;
}
int ITK_APICALL(int x,FILE *Flogfile)
{      
	int status=x;
    if(status!=ITK_ok)
    {
        int index = 0;                      
        int n_ifails = 0;           
        const int*  severities = 0;         
        const int*  ifails = 0;                 
        const char** texts = NULL;           
        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               
        for( index=0; index<n_ifails; index++)                                     
        {                                                                          
            fprintf(Flogfile,"Error code - [%d]. Error message - %s\n",ifails[index],texts[index]);	
        } 
        EMH_clear_errors();
    }
    return status;
}
int ITK_user_main(int argc, char *argv[])
{
	
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* ipFile						= NULL;
	char			* group						= NULL;
	int              ifail =ITK_ok;

	//userid			= ITK_ask_cli_argument("-u=");
	//password 		= ITK_ask_cli_argument("-pf=");
	//group 			= ITK_ask_cli_argument("-g=");
	//ipFile 			= ITK_ask_cli_argument("-f=");
	

	//ifail = ITK_auto_login();
	ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE);
	printf("\n Auto login ");fflush(stdout);
	ifail = ITK_auto_login();
    ifail = ITK_set_journalling(TRUE);
	printf("\n Auto login .......\n");fflush(stdout);

	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");fflush(stdout);
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");fflush(stdout);
			printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
		}
	///ifail = ITK_set_bypass(true);
   // if (ifail != ITK_ok)
	//{
	//	printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
	//	return -1;
	//}

	//ifail = query_object(ipFile);
	ifail = query_object();

	//fclose(output);
	printf("\n*********************\n");fflush(stdout);
	printf("\nIV_PO_Delete_End of program.....!!\n");fflush(stdout);
	printf("\n*********************\n");fflush(stdout);
	ifail = ITK_exit_module(true);
	return ifail;
}
//int query_object(char *ipFile)
int query_object()
{
	int				ifail 						= ITK_ok;
	int				i	 						= 0;
	int				j	 						= 0;
	int				x	 						= 0;
	int				z	 						= 0;
	int				iter	 					= 0;
	int				pro							= 0;
	int				results						= 0;
	int				sec_count					= 0;
	int				rlsStsCount					= 0; 
	int				revisionlist_count					= 0; 
	int itkApiCallStatus = 0;

	
	char			*sec_obj_type				= NULL;
	char			*rev_last_mod_user			= NULL;
	char			*object_rev_id				= NULL;
	char			*form_last_mod_user			= NULL;
	char			*cp_last_md_dt				= NULL;
	char			*cp_last_md_dt_form			= NULL;
	char			*str_dt						= NULL;
	char			*DateS						= NULL;
	char			*DateTempS					= NULL;
	char			*propertyfound					= NULL;
	char			str[5];

    char			*Year						= NULL;
    char			*Month						= NULL;
    char			*Day						= NULL;
    char			*Hours						= NULL;
    char			*Min						= NULL;
    char			*Sec						= NULL;
    char			*MicroSec					= NULL;
    char			**propName					= NULL;
    char			*obj_type					= NULL;
  	char			*obj_name					= NULL;
  	char			*CVPUNplant					= NULL;
    char			*obj_id						= NULL;
	char *error_msg_string= NULL;

	tag_t			query_tag					= NULLTAG;
	tag_t			*object_tag					= NULLTAG;
	char *tempId = NULL;
	char *tempItemRevId = NULL;
	char *projectcode = NULL;

	
	if(QRY_find2("Part PO Details", &query_tag)); //for PV &CV
	char *GMsc_entry1[2] = {"Name","Bulk Material11"};
	char **GMsc_RelVal = (char **) MEM_alloc(5000 * sizeof(char *));
	GMsc_RelVal[0] = "573607140129";
	GMsc_RelVal[1] = "InValidPO";
	if(QRY_execute(query_tag, 2, GMsc_entry1, GMsc_RelVal, &results, &object_tag));

	
	printf("\n Total InValidPO found: %d\n",results);fflush(stdout);
	ifail = QRY_ignore_case_on_search(TRUE);

		if(query_tag == NULLTAG)
		{
			printf("\nQuery Part PO details Not Found in TC....!!\n");fflush(stdout);
			return 0;
		}
		else
		{  
	        if(results == 0)
		    {
			    printf("\n  No InValidPO Found in General Query"); fflush(stdout);
			
		    	printf("\n C.InValidPO--Count=%d object found ",results); fflush(stdout);
		    }
		
		    if(results > 0)
		    {

				for(i =0 ; i < results; i++)
				{
					
					  AOM_ask_value_string(object_tag[i],"object_name",&obj_name);
					 
					  printf("\n - obj_name = %s",obj_name);
					  AOM_ask_value_string(object_tag[i],"t5_Plant2",&CVPUNplant);

					  if(tc_strcmp(CVPUNplant,"CV PUN ERC Direct Mat")==0)
					  {
						  printf("\n - Skip for CV PUN Plant = %s &  obj_name = %s",CVPUNplant,obj_name);
					  }		
					  else
					  {
						     itkApiCallStatus=AOM_lock_for_delete(object_tag[i]);

							printf("\n ITK Status for AOM_lock_for_delete = %d = ",itkApiCallStatus);

							itkApiCallStatus=AOM_delete(object_tag[i]);

							EMH_ask_error_text (itkApiCallStatus, &error_msg_string);
							printf("ERROR: %d ERROR MSG: %s.\n", itkApiCallStatus, error_msg_string);

							printf("\n ITK Status for AOM_delete = %d = ",itkApiCallStatus);
							printf("\n Part PO details deleted from TCUA \n");
					  }
					  if (obj_name) MEM_free(obj_name);
					  if (CVPUNplant) MEM_free(CVPUNplant);
				}
		    }
	    }
    return ifail;  
}

				
				
