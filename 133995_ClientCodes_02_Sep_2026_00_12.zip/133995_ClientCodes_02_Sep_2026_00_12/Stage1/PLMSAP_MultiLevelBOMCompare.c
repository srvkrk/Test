/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : PlmSapMultiLevelBomCompareUA.c
* Created By                   : 
* Created On                   : 28.06.2023
* Project                      : Tata Motors PLM-SAP Interface
* Methods Defined              :
* Description                  : TCUA - SAP First level BOM compare report
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>


#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>

#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)

char cpydml_no[50]={0};
char *PlmDmlSuff 		= NULL;
char *PlmDmlSuffOrig 		= NULL;
char *meas_unit		= NULL;
char fsuccess_name[200]={0};
char fsuccess_BomCmpRpt[200]={0};
struct node_mis *start_sap = NULL;
struct node_mis *p_sap = NULL;
struct node_mis *q_sap = NULL;
char *output					= NULL;
char *SAPpstat=NULL;
char *MRPpstat=NULL;
char *sap_proc_type=NULL;
char *sap_proc_typeVal=NULL;
char *sap_spproc_type=NULL;
char *sap_spproc_typeVal=NULL;
char *bl_mkbuy_string		= NULL;
char *LCStateChk			= NULL;
FILE *Report = NULL;
int ctr=0;

char *PrintPrtDec			= NULL;
char *PrintPrtNum			= NULL;
char *PrintPrtPrjCode			= NULL;
char *archNode			= NULL;
char *ModelName			= NULL;

struct node *start = NULL;
struct node *p = NULL;
struct node *q = NULL;

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int report_error(char *file, int line, char *call, int status,
    logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int
            n_errors = 0;
        const int
            *severities = NULL,
            *statuses = NULL;
        const char
            **messages;

        EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
        if (n_errors > 0)
        {
            ECHO("\n%s\n", messages[n_errors-1]);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            EMH_get_error_string (NULLTAG, status, &error_message_string);
            ECHO("\n%s\n", error_message_string);
        }

        ECHO("error %d at line %d in %s\n", status, line, file);
        ECHO("%s\n", call);
        if (exit_on_error)
        {
            ECHO("%s", "Exiting program!\n");
            exit (status);
        }
    }
    return status;
}

struct node
{
	char sr_no[5];
	char *part;
	char *desc;
	float qty;
	char uq[4];
	char tempcsrel[2];
	char mat_prov_ind[2];
	char * make_buy_indDup;
	float usgProb;
	struct node *next;
};
struct node_mis
{
	char sr_no[5];
	char *part;
	char *qty;
	char *BomNo;
	char *Spmkby;
	char *SUOM;
	struct node_mis *next;
};

char recstring_sap[25000];
char crecstring_sap[25000];

struct usgProbnode
{
	char sr_no[5];
	char *part;
	float *usgProb;
	struct usgProbnode *next;
};
struct DmlEpaNode
{
	char DmlEpa[50];
	char ClosureTimeStamp[11];
	char DmlLifeCycleState[30];
	struct DmlEpaNode *next;
};

int isPrintable(char ch) {
    return ch >= 32 && ch <= 126;
}

// Function to remove non-ASCII, non-printable, and special characters from string
void removeNonAsciiChars(char *str) {
    int i = 0;
    char ch;
    while ((ch = str[i]) != '\0') {
        if (!isPrintable(ch))
        {
            str[i] = ' ';
        }
        i++;
    }
}

static char CMakeBuy1[45]={0};
static char CTmpMakeBuy1[45]={0};

char *plantcode			= NULL;

char *iSapServer		= NULL;
char *nomenclatureDup	= NULL;
char *apl_release_date 	= NULL;
char *Current_date_time = NULL;
tag_t MypartObjs		= NULLTAG;

char fsuccess_BomCmpRpt[200];
char DMLDescription[100];
FILE *fsuccess;
FILE *fsuccessRpt;
FILE *fsuccessRptSumm;

char *dml_numAP			= NULL;
char *dml_numAP1 		= NULL;
static char projectcode[5]={0};

int MC_DML = 0;

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);
void F_OUTK(const char *text,const unsigned pos,const unsigned len,char*str);
void my_free(struct node* start);
void display1(struct node *head,char *assy_noDup);
struct node* createnode(char sr_no[5],char *part,char *desc,float* qty,char uq[4],char tempcsrel[2],char mat_prov_ind[2],char *make_buy_indDup);
int search(struct node* start,char *part,float* qty);
int searchSAPExp(struct node* start,char *part);
//int searchSAP(struct node* start_sap,char *part,char* qty);
void  rfc_error(char *operation);
RFC_HANDLE BapiLogon(void);
struct node_mis * cll_cad_display_bom_with_sub_items(struct node *head,char * assy_noDup,char * plantcode);
RFC_RC cad_display_bom_with_sub_items(RFC_HANDLE hRfc,RC29L_STLAL *eIBomAlternative,RC29L_STLAN *eIBomType,RC29L_AENNR *eIChangeNumber,DRAW_LOEDK *eIDisplayFlag,RC29L_MATNR *eIMaterial,RC29L_WERKS *eIPlant,RC29L_REVLV *eIRevisionLevel,BICSK_DATUV *eIValidFrom,CAD_BICSK *iEBomHeader,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_RETURN_VALUE *iEReturn,ITAB_H thBomItem,ITAB_H thBomSubItem,ITAB_H thDmsClassData,ITAB_H thSapFieldData,char *xException);
//void compare(struct node *p1,struct node *p2,char *AssyNo);
void compare(struct node *p1,struct node_mis *p2,char *AssyNo,char* plantcode);
struct usgProbnode* createnode2(char sr_no[5],char *part,float* usgProb);
struct usgProbnode* GetUsageProb(char *assy_noDup);
void my_free2(struct usgProbnode* start);
//void compareUsage(struct usgProbnode *pUP,struct node *start);
void display2(struct usgProbnode *head,char *assy_noDup);
void trimString(char * str);
int tm_fnd_DML_PART(char	*PLT_CODE,tag_t t_currentRevision, tag_t* t_DMLRevision);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);
struct node_mis* createnode_mis(char sr_no[5],char *part,char* qty,char *BomNo,char *Spmkby,char * SUOM);
void display_bom(struct node_mis *head);
RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException);
int GetCSPstat(char cMaterial[15],RFC_RC RfcRc);

char *ltrim(char *s)
{
    while(isspace(*s)) s++;
    return s;
}

char *rtrim(char *s)
{
    char* back;
    int len = strlen(s);

    if(len == 0)
        return(s);

    back = s + len;
    while(isspace(*--back));
    *(back+1) = '\0';
    return s;
}

char *trim(char *s)
{
    return rtrim(ltrim(s));
}
void trimString(char * str)
{
	int i = 0;
    for (i = 0; i < tc_strlen(str); i++)
	{
		//printf("\n%d %c",i,str[i]);
		if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
		{
			str[i] = '\0';
		}     
	}
}
;

struct usgProbnode* createnode2(char sr_no[5],char *part,float* usgProb)
{
	struct usgProbnode* q		= NULL;

	//printf("In createnode2 Function....\n");

	q=(struct usgProbnode*)malloc(sizeof(struct usgProbnode));
	q->part=part;
	strcpy(q->sr_no,sr_no);
	q->usgProb = usgProb;
	q->next		= NULL;
	return q;
}


void my_free2(struct usgProbnode* start)
{
	struct usgProbnode* prev;
	struct usgProbnode* ptr;
	printf("\nErazing Linklist Started...\n");
	fprintf(fsuccess,"\nErazing Linklist Started...\n");
	for(prev = start, ptr = start; ptr != NULLTAG, prev = ptr;ptr = ptr->next)
	{
		printf("#");
		fprintf(fsuccess,"#");
		free(prev);
	}
	start = NULLTAG;
	printf("\nErazing Linklist Completed.\n");
	fprintf(fsuccess,"\nErazing Linklist Completed.\n");

}

void my_free(struct node* start)
{
	struct node* prev;
	struct node* ptr;
	printf("\nErazing Linklist Started...\n");
	fprintf(fsuccess,"\nErazing Linklist Started...\n");fflush(fsuccess);
	//for(prev = start, ptr = start; ptr != NULL, prev = ptr;ptr = ptr->next)
	for(prev = start, ptr = start; ptr != NULL, prev = ptr;ptr = ptr->next)
	{
		printf("#");
		fprintf(fsuccess,"#");fflush(fsuccess);
		free(prev);
	}
	start 		= NULL;
	printf("\nErazing Linklist Completed.\n");
	fprintf(fsuccess,"\nErazing Linklist Completed.\n");fflush(fsuccess);
}
void my_free_mis(struct node_mis** start)
{
	struct node_mis* current = *start;
	struct node_mis* ptr;
	printf("\n");
	while (current != NULL)
	{
		printf("#");
		ptr = current->next;
		free(current);
		current = ptr;
	}
	*start = NULL;
	printf("SUCCESSFULLY DELETED ALL NODES OF LINKED LIST\n");
}

void display1(struct node *head,char *assy_noDup)
{
	struct node *p=NULL;
	//fprintf(fp,"\n%15s", assy_noDup);
	for(p = head; p != NULL; p = p -> next)
	{
		printf("\n\t %s %-15s %7.3f %3s %3s %3s %s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> mat_prov_ind ,p -> tempcsrel,p -> make_buy_indDup);
		fprintf(fsuccess,"\n PLM BOM");fflush(fsuccess);
		fprintf(fsuccess,"\n\t %s %15s %7.3f %3s %3s %3s %s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> tempcsrel,p -> mat_prov_ind,p -> make_buy_indDup);fflush(fsuccess);
		//fprintf(fp,"\n%15s", p -> part);
		//fprintf(fsuccessRpt,"\n PLM BOM");fflush(fsuccessRpt);
		//fprintf(fsuccessRpt,"\n SAP BOM");fflush(fsuccessRpt);
		//fprintf(fsuccessRpt,"\n\t %s %15s %7.3f %3s %3s %3s %s",p -> sr_no, p -> part, p -> qty,p -> uq ,p -> tempcsrel,p -> mat_prov_ind,p -> make_buy_indDup);fflush(fsuccessRpt);
	}

}

struct node* createnode(char sr_no[5],char *part,char *desc,float* qty,char uq[4],char tempcsrel[2],char mat_prov_ind[2],char *make_buy_indDup)
{
	struct node* p = NULL;

	p = (struct node*)malloc(sizeof(struct node));
	//strcpy(p->part,part);
	p->part = part;
	p->desc = desc;
	tc_strcpy(p->sr_no,sr_no);
	tc_strcpy(p->uq,uq);
	tc_strcpy(p->mat_prov_ind,mat_prov_ind);
	tc_strcpy(p->tempcsrel,tempcsrel);
	p->make_buy_indDup = make_buy_indDup;
	p->qty = *qty;
	p->usgProb = 0.000f;
	p->next = NULL;
	return p;
}
void display_bom(struct node_mis *head)
{
	struct node_mis *p2=NULL;
	for(p2=head; p2!=NULL; p2 = p2->next)
	{
		printf("\n[%s][%s][%s][%s][%s][%s]",p2->sr_no,p2->part,p2->qty,p2->BomNo,p2->Spmkby,p2->SUOM);fflush(stdout);
		fprintf(fsuccess,"\n SAP BOM");fflush(fsuccess);
		fprintf(fsuccess,"\n[%s][%s][%s][%s][%s][%s]",p2->sr_no,p2->part,p2->qty,p2->BomNo,p2->Spmkby,p2->SUOM);fflush(fsuccess);
		//fprintf(fsuccessRpt,"\n SAP BOM");fflush(fsuccessRpt);
		//fprintf(fsuccessRpt,"\n[%s][%s][%s][%s][%s][%s]",p2->sr_no,p2->part,p2->qty,p2->BomNo,p2->Spmkby,p2->SUOM);fflush(fsuccessRpt);
	}
}
struct node_mis* createnode_mis(char sr_no[5],char *part,char *qty,char *BomNo,char *Spmkby,char *SUOM)
{
	printf("\n creating node forsr_no[%s]part[%s]qty[%s]BomNo[%s]Spmkby[%s]SUOM[%s]",sr_no,part,qty,BomNo,Spmkby,SUOM);fflush(stdout);
	struct node_mis* p = NULL;

	p = (struct node_mis*)malloc(sizeof(struct node_mis));
	tc_strcpy(p->sr_no,sr_no);

	p->part = (char *) MEM_alloc(19 * sizeof(char ));
	tc_strcpy(p->part,part);

	p->qty = (char *) MEM_alloc(19 * sizeof(char ));
	if ( strcmp(qty,"") != 0 )
	{
		tc_strcpy(p->qty,qty);
	}
	else
	{
		//tc_strcpy(p->qty,"0.000");
		tc_strcpy(p->qty,"");
	}

	p->BomNo = (char *) MEM_alloc(41 * sizeof(char ));
	if ( strcmp(BomNo,"") != 0 )
	{
		tc_strcpy(p->BomNo,BomNo);
	}
	else
	{
		tc_strcpy(p->BomNo,"NAA");
	}
	
	p->Spmkby = (char *) MEM_alloc(41 * sizeof(char ));
	if ( strcmp(Spmkby,"") != 0 )
	{
		tc_strcpy(p->Spmkby,Spmkby);
	}
	else
	{
		tc_strcpy(p->Spmkby,"");
	}
	
	p->SUOM = (char *) MEM_alloc(41 * sizeof(char ));
	if ( strcmp(SUOM,"") != 0 )
	{
		tc_strcpy(p->SUOM,SUOM);
	}
	else
	{
		tc_strcpy(p->SUOM,"");
	}
	printf("\n after creating node forsr_no[%s]part[%s]qty[%s]BomNo[%s]Spmkby[%s]SUOM[%s]",p->sr_no,p->part,p->qty,p->BomNo,p->Spmkby,p->SUOM);fflush(stdout);
	p->next = NULL;
	return p;
}

int search(struct node* start,char *part,float* qty)
{
	struct node* p;
	int found = 1 ;

	p=start;
	/*while(p->next!=NULL)*/
	while(p!=NULL)
	{
			if(strcmp(p->part,part)==0)
			{
					//found;
					p->qty = p->qty + *qty;
					found = 0;
					break;
			}
			else
			{
				p=p->next;
				found = 1 ;
			}

		}
	return found;
}

int searchSAP(struct node_mis* start_sap,char *part,char *qty)
{
	struct node_mis* p1;
	int found = 1 ;

	p1=start_sap;
	
	float floatQty= 0.000;
	float floatQtyadd= 0.000;
	float floatQtySerch= 0.000;
	floatQty = atof(qty);
	
	char *SapQtyAdd		= NULL;
	SapQtyAdd	= (char *) malloc(500 * sizeof(char));
	tc_strcpy(SapQtyAdd,"");
	
	char *SapQtyAdd1		= NULL;
	SapQtyAdd1	= (char *) malloc(500 * sizeof(char));
	tc_strcpy(SapQtyAdd1,"");
						
	/*while(p->next!=NULL)*/
	while(p1!=NULL)
	{
			if(strcmp(p1->part,part)==0)
			{
					//found;
					floatQtySerch = atof(p1->qty);
					
					floatQtyadd=floatQtySerch + floatQty;
					sprintf(SapQtyAdd,"%7.3f", floatQtyadd);
					SapQtyAdd1 =  (char *)stripBlanks(SapQtyAdd);
					p1->qty = SapQtyAdd1;
					found = 0;
					break;
			}
			else
			{
				p1=p1->next;
				found = 1 ;
			}

		}
	return found;
}
int searchSAPExp(struct node* start,char *part)
{
	printf("\n i am in searchSAPExp");fflush(stdout);
	struct node* ppp;
	int found = 1 ;

	ppp=start;
	printf("\n 111");fflush(stdout);
	/*while(p->next!=NULL)*/
	while(ppp!=NULL)
	{
			printf("\n 222");fflush(stdout);
			
			if(strcmp(ppp->part,part)==0)
			{
					printf("\ncomparing PLM link list of part [%s] with SAP[%s] and it is found",ppp->part,part);fflush(stdout);
					printf("\ncomparing PLM link list of part [%s] CS [%s] ",ppp->part,ppp->make_buy_indDup);fflush(stdout);
					
					if((strcmp(ppp->make_buy_indDup,"F")==0) || (strcmp(ppp->make_buy_indDup,"F18")==0))
					{
						printf("\n Found part in  PLM  [%s] CS is [%s] No need to expand in SAP ",ppp->part,ppp->make_buy_indDup);fflush(stdout);
						found = 0;
						break;
					}
					else
					{
						ppp=ppp->next;
						found = 1 ;
					}
			}
			else
			{
				ppp=ppp->next;
				//printf("\n comparing PLM link list of part [%s] with SAP[%s] and it is NOOOT found",ppp->part,part);fflush(stdout);
				found = 1 ;
			}

		}
	return found;
}


// char *slNo=(char *) MEM_alloc(200);
// sprintf(slNo,"%d",(i+1));

// write2xml(Report,"<DesignRevision>\n");
// write2xml(Report,"<field key =\"slNo\">");
// write2xml(Report,slNo);
// write2xml(Report,"</field>\n");
// write2xml(Report,"<field key =\"item_id\">");
// write2xml(Report,item_id);
// write2xml(Report,"</field>\n");
int RptFileline=0;
int SummFileline=0;
void compare(struct node *p1,struct node_mis *p2,char *AssyNo,char* plantcode)
{
	int	found = 1;
	char *PLMPartNum		= NULL;
	char *PLMPartNumDesc		= NULL;
	char *PLMmkby		= NULL;
	char *SAPmkby		= NULL;
	char *PLMUQ		= NULL;
	char *SAPUOM		= NULL;
	char *PLMQty		= NULL;
	char *SAPQty		= NULL;
	char *plm_qty		= NULL;
	char *plm_qty1		= NULL;
	char *SAPPartNum		= NULL;
	PLMPartNum	= (char *) malloc(500 * sizeof(char));
	PLMPartNumDesc	= (char *) malloc(500 * sizeof(char));
	SAPPartNum	= (char *) malloc(500 * sizeof(char));
	PLMmkby	= (char *) malloc(500 * sizeof(char));
	SAPmkby	= (char *) malloc(500 * sizeof(char));
	PLMUQ	= (char *) malloc(500 * sizeof(char));
	SAPUOM	= (char *) malloc(500 * sizeof(char));
	PLMQty	= (char *) malloc(500 * sizeof(char));
	SAPQty	= (char *) malloc(500 * sizeof(char));
	plm_qty	= (char *) malloc(500 * sizeof(char));
	plm_qty1	= (char *) malloc(500 * sizeof(char));
	struct node *s1 = NULL;
	struct node_mis *s2 = NULL;
	printf("\nIn compare");fflush(stdout);
	s1 = p1;//plm bom
	s2 = p2;//sap bom
	int ModuleMismatch=0;

	//fprintf(fsuccessRpt,"\n\t\t\t\t,,,,PLM-SAP Mismatch Report details,,");fflush(fsuccessRpt);

	if(RptFileline==0)
				{
					fprintf(fsuccessRpt,",,,,,,,,,,");fflush(fsuccessRpt);
					fprintf(fsuccessRpt,"\n,,,,,,,,,,");fflush(fsuccessRpt);
					RptFileline++;
				}
				else
				{
				fprintf(fsuccessRpt,"\n,,,,,,,,,,");fflush(fsuccessRpt);
				fprintf(fsuccessRpt,"\n,,,,,,,,,,");fflush(fsuccessRpt);
				}
	//fprintf(fsuccessRpt,"\nPLM Part Number~PLM Part Desc~SAP Part number~Part Comparison~PLM CS~SAP CS~CS Comparison~PLM UOM~SAP UOM~UOM Comparison~PLM Qty~SAP Qty~Qty Comparison~");fflush(fsuccessRpt);
	//fprintf(fsuccessRpt,"\nProject Code,Model,Arch Node,Module,Description, Part No.,Part Description,TCUA Qty,SAP Qty,Status,");fflush(fsuccessRpt);
	while(s1!=NULL)
	{
		s2=p2;

		while(s2!=NULL)
		{
	
			if((strcmp(s2->part,s1->part)==0))
			{
				found = 0;
				if (s1->qty!= 0)
					{
						tc_strcpy(plm_qty,"");
						tc_strcpy(plm_qty1,"");
						sprintf(plm_qty1,"%7.3f", s1->qty);
						//trimString(plm_qty);
						plm_qty =  (char *)stripBlanks(plm_qty1);
					}
					else
					{
						tc_strcpy(plm_qty,"");
					}
				
				fprintf(fsuccessRpt,"\n%s,%s,%s,%s,%s,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRpt);
				fprintf(fsuccessRpt,"%s,",s1->part);fflush(fsuccessRpt);
				fprintf(fsuccessRpt,"%s,",s1->desc);fflush(fsuccessRpt);
				
				if ( strcmp(s2->Spmkby,"") != 0 )
					{
						if ( strcmp(s1->make_buy_indDup,"") != 0 )
						{
							if((strcmp(s2->Spmkby,s1->make_buy_indDup)==0))
							{
								fprintf(fsuccessRpt,"%s,%s,OK,",s1->make_buy_indDup,s2->Spmkby);fflush(fsuccessRpt);
							}
							else
							{
								fprintf(fsuccessRpt,"%s,%s,CS Mismatch,",s1->make_buy_indDup,s2->Spmkby);fflush(fsuccessRpt);
							}
						}
						else
						{
							fprintf(fsuccessRpt,",%s,CS Mismatch,",s2->Spmkby);fflush(fsuccessRpt);
						}
					}
					else
					{
						if ( strcmp(s1->make_buy_indDup,"") != 0 )
						{
							
						  fprintf(fsuccessRpt,"%s,,CS Mismatch,",s1->make_buy_indDup);fflush(fsuccessRpt);
							
						}
						else
						{
							fprintf(fsuccessRpt,",,OK,");fflush(fsuccessRpt);
						}
					}
					if ( strcmp(s2->qty,"") != 0 )
					{
						if ( strcmp(plm_qty,"") != 0 )
						{
							if((strcmp(s2->qty,plm_qty)==0))
							{
								fprintf(fsuccessRpt,"%s,%s,OK,",plm_qty,s2->qty);fflush(fsuccessRpt);
							}
							else
							{
								fprintf(fsuccessRpt,"%s,%s,Qty Mismatch,",plm_qty,s2->qty);fflush(fsuccessRpt);
								ModuleMismatch = ModuleMismatch + 1;
							}
						}
						else
						{
							fprintf(fsuccessRpt,",%s,Qty Mismatch,",s2->qty);fflush(fsuccessRpt);
							ModuleMismatch = ModuleMismatch + 1;
						}
					}
					else
					{
						if ( strcmp(plm_qty,"") != 0 )
						{
							
						  //fprintf(fsuccessRpt,"%s~Blank~NOT OK~",plm_qty,s2->qty);fflush(fsuccessRpt);
						  fprintf(fsuccessRpt,"%s,,Qty Mismatch,",plm_qty);fflush(fsuccessRpt);
						  ModuleMismatch = ModuleMismatch + 1;
								
						}
						else
						{
							fprintf(fsuccessRpt,",,OK,");fflush(fsuccessRpt);
						}
					}
					
					
					// if((strcmp(s2->qty,s1->uq)==0))
					// {
						// fprintf(fsuccessRpt,"[%s]~[%s]~OK~",s1->qty,s2->qty);fflush(fsuccessRpt);
					// }
					// else
					// {
						// fprintf(fsuccessRpt,"[%s]~[%s]~NOT OK~",s1->qty,s2->qty);fflush(fsuccessRpt);
					// }
				
				break;
			}
			else
			{
				found = 1;
			}
			s2=s2->next;
		}
		if(found == 1)
		{
			tc_strcpy(SAPPartNum,"NA");
			
			if ( strcmp(s1->make_buy_indDup,"") == 0 )
			{
				tc_strcpy(PLMmkby,"");
			}
			else
			{
				tc_strcpy(PLMmkby,s1->make_buy_indDup);
			}
			printf("\n PLMmkby %s \n",PLMmkby);fflush(stdout);
			
			
			//if ( strcmp(s2->Spmkby,"") == 0 )
			//{
				//tc_strcpy(SAPmkby,"BLANK");
			//}
			//else
			//{
				///tc_strcpy(SAPmkby,s2->Spmkby);
			//}
			//printf("\n SAPmkby %s ",SAPmkby);fflush(stdout);
			if ( strcmp(s1->uq,"") == 0 )
			{
				tc_strcpy(PLMUQ,"BLANK");
			}
			else
			{
				tc_strcpy(PLMUQ,s1->uq);
			}
			printf("\n PLMUQ %s ",PLMUQ);fflush(stdout);
			// if ( strcmp(s2->SUOM,"") == 0 )
			// {
				// tc_strcpy(SAPUOM,"BLANK");
			// }
			// else
			// {
				// tc_strcpy(SAPUOM,s2->SUOM);
			// }
			// printf("\n SAPUOM %s ",SAPUOM);fflush(stdout);
			if (s1->qty!= 0)
			{
				tc_strcpy(plm_qty,"");
				tc_strcpy(plm_qty1,"");
				sprintf(plm_qty1,"%7.3f", s1->qty);
				//trimString(plm_qty);
				plm_qty =  (char *)stripBlanks(plm_qty1);
			}
			else
			{
				tc_strcpy(plm_qty,"");
			}
			printf("\n plm_qty %s ",plm_qty);fflush(stdout);
			tc_strcpy(SAPmkby,"");
			tc_strcpy(SAPUOM,"NA");
			tc_strcpy(SAPQty,"");
			//tc_strcpy(plm_qty,"BLANK");
			// if ( strcmp(s2->qty,"") == 0 )
			// {
				// tc_strcpy(SAPQty,"BLANK");
			// }
			// else
			// {
				// tc_strcpy(SAPQty,s2->qty);
			// }
			// printf("\n SAPQty %s ",SAPQty);fflush(stdout);
			//printf("\n%s Part present in PLM not in SAP %s BomNo[%s] for plant [%s]",AssyNo,s1->part,s1->BomNo,plantcode);fflush(stdout);
			printf("\n%s Part present in PLM not in SAP %s for plant [%s]",AssyNo,s1->part,plantcode);fflush(stdout);
			//fprintf(fsuccess,"\n%s Part present in PLM not in SAP %s BomNo[%s] for plant [%s]",AssyNo,s1->part,s1->BomNo,plantcode);fflush(stdout);
			fprintf(fsuccess,"\n%s Part present in PLM not in SAP %s for plant [%s]",AssyNo,s1->part,plantcode);fflush(fsuccess);
			//fprintf(fsuccessRpt,"\n[%s] Part present in PLM not in SAP [%s] for plant [%s]",s1->part,SAPPartNum,plantcode);fflush(fsuccessRpt);
			//fprintf(fsuccessRpt,"\n \t [%s] \t\t[%s] ",s1->part,SAPPartNum);fflush(fsuccessRpt);
			//fprintf(fsuccessRpt,"\n%s~%s~NA~%s~%s~NA~%s~%s~NA~%s~%s~NA~",s1->part,s1->desc,SAPPartNum,PLMmkby,SAPmkby,PLMUQ,SAPUOM,plm_qty,SAPQty);fflush(fsuccessRpt);
			//Part present in PLM not in SAP
			
			fprintf(fsuccessRpt,"\n%s,%s,%s,%s,%s,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRpt);	
			fprintf(fsuccessRpt,"%s,%s,%s,%s,Missing,%s,%s,Missing,",s1->part,s1->desc,PLMmkby,SAPmkby,plm_qty,SAPQty);fflush(fsuccessRpt);
			ModuleMismatch = ModuleMismatch + 1;

		}

		s1=s1->next;
	}


	s1 = p1;
	s2 = p2;
	while(s2!=NULL)
	{
		s1=p1;

		while(s1!=NULL)
		{
			found = 0;
//tc_strcpy(SAPPartNum,"");
			//tc_strcpy(s1->part,PLMPartNum);
			//tc_strcpy(s2->part,SAPPartNum);
			//printf("\n PLMPart Number [%s]",PLMPartNum);fflush(stdout);
			//printf("\n SAPPart Number [%s]",SAPPartNum);fflush(stdout);
			//if ( (strcmp(s1->part,s2->part)==0) && (strcmp(s1->BomNo,s2->BomNo)==0))
			if ( (strcmp(s1->part,s2->part)==0))
			{
				fprintf(fsuccess,"\n PLM Part[%s] SAP Part [%s] alredy processd",s1->part,s2->part);fflush(fsuccess);
				break;
				//found = 0;
				if (s1->qty!= 0)
					{
						tc_strcpy(plm_qty,"");
						tc_strcpy(plm_qty1,"");
						sprintf(plm_qty1,"%7.3f", s1->qty);
						plm_qty =  (char *)stripBlanks(plm_qty1);
						//trimString(plm_qty);
					}
					else
					{
						tc_strcpy(plm_qty,"");
					}
				//fprintf(fsuccessRpt,"\n[%s] Part present in PLM as well present in SAP [%s] for plant [%s]",s1->part,s2->part,plantcode);fflush(fsuccessRpt);
				//fprintf(fsuccessRpt,"\n \t [%s] \t\t[%s] ",s1->part,s2->part);fflush(fsuccessRpt);
				
				
				fprintf(fsuccessRpt,"\n%s,%s,%s,%s,%s,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRpt);
				fprintf(fsuccessRpt,"%s,%s,",s1->part,s1->desc);fflush(fsuccessRpt);

					
					if ( strcmp(s2->Spmkby,"") != 0 )
					{
						if ( strcmp(s1->make_buy_indDup,"") != 0 )
						{
							if((strcmp(s2->Spmkby,s1->make_buy_indDup)==0))
							{
								fprintf(fsuccessRpt,"%s,%s,OK,",s1->make_buy_indDup,s2->Spmkby);fflush(fsuccessRpt);
							}
							else
							{
								fprintf(fsuccessRpt,"%s,%s,CS Mismatch,",s1->make_buy_indDup,s2->Spmkby);fflush(fsuccessRpt);
							}
						}
						else
						{
							fprintf(fsuccessRpt,",%s,CS Mismatch~,",s2->Spmkby);fflush(fsuccessRpt);
						}
					}
					else
					{
						if ( strcmp(s1->make_buy_indDup,"") != 0 )
						{
							
						  fprintf(fsuccessRpt,"%s,,CS Mismatch,",s1->make_buy_indDup,s2->Spmkby);fflush(fsuccessRpt);
						}
						else
						{
							fprintf(fsuccessRpt,",,OK,");fflush(fsuccessRpt);
						}
					}
					if ( strcmp(s2->qty,"") != 0 )
					{
						if ( strcmp(plm_qty,"") != 0 )
						{
							if((strcmp(s2->qty,plm_qty)==0))
							{
								fprintf(fsuccessRpt,"%s,%s,OK,",plm_qty,s2->qty);fflush(fsuccessRpt);
							}
							else
							{
								fprintf(fsuccessRpt,"%s,%s,Qty Mismatch,",plm_qty,s2->qty);fflush(fsuccessRpt);
								ModuleMismatch = ModuleMismatch + 1;
							}
						}
						else
						{
							fprintf(fsuccessRpt,",%s,Qty Mismatch,",s2->qty);fflush(fsuccessRpt);
							ModuleMismatch = ModuleMismatch + 1;
						}
					}
					else
					{
						if ( strcmp(plm_qty,"") != 0 )
						{
							
						  fprintf(fsuccessRpt,"%s,,Qty Mismatch,",plm_qty);fflush(fsuccessRpt);
						  ModuleMismatch = ModuleMismatch + 1;
						}
						else
						{
							fprintf(fsuccessRpt,",,OK,");fflush(fsuccessRpt);
						}
					}
				break;
			}
			else
			{
				found = 1;
			}
			s1=s1->next;
		}
		if(found == 1)
		{
			tc_strcpy(PLMPartNum,"NA");
			tc_strcpy(PLMPartNumDesc,"NA");
			tc_strcpy(PLMmkby,"");
			tc_strcpy(plm_qty,"");
			tc_strcpy(PLMUQ,"NA");
			// if ( strcmp(s1->make_buy_indDup,"") == 0 )
			// {
				// tc_strcpy(PLMmkby,"BLANK");
			// }
			if ( strcmp(s2->Spmkby,"") == 0 )
			{
				tc_strcpy(SAPmkby,"");
			}
			else
			{
				tc_strcpy(SAPmkby,s2->Spmkby);
			}
			printf("\n SAPmkby %s \n",SAPmkby);fflush(stdout);
			// if ( strcmp(s1->uq,"") == 0 )
			// {
				// tc_strcpy(PLMUQ,"BLANK");
			// }
			if ( strcmp(s2->SUOM,"") == 0 )
			{
				tc_strcpy(SAPUOM,"BLANK");
			}
			else
			{
				tc_strcpy(SAPUOM,s2->SUOM);
			}
			printf("\n SAPUOM %s \n",SAPUOM);fflush(stdout); 
			
			// if (s1->qty!= 0)
			// {
				// sprintf(plm_qty,"%7.3f", s1->qty);
			// }
			// else
			// {
				// tc_strcpy(plm_qty,"BLANK");
			// }
			if ( strcmp(s2->qty,"") == 0 )
			{
				tc_strcpy(SAPQty,"");
			}
			else
			{
				tc_strcpy(SAPQty,s2->qty);
			}
			printf("\n SAPQty %s \n",SAPQty);fflush(stdout);
			//printf("\n%s Part present in SAP not in PLM %s BomNo[%s] for plant [%s] Item No [%s]",AssyNo,s2->part,s2->BomNo,plantcode,s2->sr_no);fflush(stdout);
			printf("\n%s Part present in SAP not in PLM %s for plant [%s] Item No [%s]",AssyNo,s2->part,plantcode,s2->sr_no);fflush(stdout);
			//fprintf(fsuccess,"\n%s Part present in SAP not in PLM %s BomNo[%s] for plant [%s] Item No [%s]",AssyNo,s2->part,s2->BomNo,plantcode,s2->sr_no);fflush(stdout);
			fprintf(fsuccess,"\n%s Part present in SAP not in PLM %s for plant [%s] Item No [%s]",AssyNo,s2->part,plantcode,s2->sr_no);fflush(fsuccess);
			//fprintf(fsuccessRpt,"\n[%s] Part present in SAP not in PLM [%s] for plant [%s]",s2->part,PLMPartNum,plantcode);fflush(fsuccessRpt);
			//fprintf(fsuccessRpt,"\n[%s] Part present in SAP not in PLM [%s] for plant [%s]",s2->part,PLMPartNum,plantcode);fflush(fsuccessRpt);
			//fprintf(fsuccessRpt,"\n \t [%s] \t\t[%s] ",PLMPartNum,s2->part);fflush(fsuccessRpt);
			// when PLM part is not peresnt in PLM
			
			
			fprintf(fsuccessRpt,"\n%s,%s,%s,%s,%s,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRpt);	
			fprintf(fsuccessRpt,"%s,,%s,%s,Missing,%s,%s,Missing,",s2->part,PLMmkby,SAPmkby,plm_qty,SAPQty);fflush(fsuccessRpt);
			ModuleMismatch = ModuleMismatch + 1;
			
		}

		s2=s2->next;
	}
	if(ModuleMismatch>0)
	{
		if(SummFileline==0)
		{
			SummFileline++;
			fprintf(fsuccess,"No new line for summry");fflush(fsuccess);
			fprintf(fsuccess,"It will print Once for summry");fflush(fsuccess);
			fprintf(fsuccessRptSumm,"%s,%s,%s,%s,%s,Mismatch,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRptSumm);
		}
		else{
			
		fprintf(fsuccessRptSumm,"\n%s,%s,%s,%s,%s,Mismatch,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRptSumm);
		}
	}
	else
	{
		if(SummFileline==0)
		{
			SummFileline++;
			fprintf(fsuccess,"No new line for summry");fflush(fsuccess);
			fprintf(fsuccess,"It will pront Once for summry");fflush(fsuccess);
			fprintf(fsuccessRptSumm,"%s,%s,%s,%s,%s,OK,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRptSumm);
		}
		else{
			
		fprintf(fsuccessRptSumm,"\n%s,%s,%s,%s,%s,OK,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRptSumm);
		}
	}

}

/*
int tm_fnd_DML_PART(char *PLT_CODE,tag_t t_currentRevision,tag_t* t_DMLRevision)
{
	int     status;
	int     ifail;
	int		count_tsk				=	0;
	int		count_DML				=	0;
	int		iPPPM					=	0;
	int		itsk					=	0;
	int		idml					=	0;
	int		iDMLFnd					=	0;

	char	*c_PartNumber			=	NULL;
	char	*Part_Rev				=	NULL;
	char	*object_type			=	NULL;
	char	*type_name				=	NULL;
	char	*type_dml_name			=	NULL;
	char	*task_name				=	NULL;
	char	*DML_name				=	NULL;
	char	*DML_Owner				= NULL;
	char	*DMLRelStatus			= NULL;
	char	*DateStr				= NULL;
	char	*STDRelDateStr			= NULL;
	char	*DMLEcnType				= NULL;

	date_t STDRelDate;

	tag_t	tsk_part_sol_rel_type	=	NULLTAG;
	tag_t	dml_task_rel_type		=	NULLTAG;
	tag_t	*TaskRevision			=	NULLTAG;
	tag_t	*DMLRevision			=	NULLTAG;
	tag_t	TaskRevTag				=	NULLTAG;
	tag_t	DMLRevTag				=	NULLTAG;
	tag_t	objTaskTypeTag			=	NULLTAG;
	tag_t	objDMLTypeTag			=	NULLTAG;

	printf("\nInside tm_fnd_DML_PART %s",PLT_CODE);fflush(stdout);

	AOM_ask_value_string(t_currentRevision,"current_id",&c_PartNumber);
	printf("\nPart_Number: %s\n",c_PartNumber);fflush(stdout);

	AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev);
	printf("\nPart_Rev: %s\n",Part_Rev);fflush(stdout);

	AOM_ask_value_string(t_currentRevision,"object_type",&object_type);
	printf("\nobject_type : %s",object_type);fflush(stdout);

	GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);

	if(tsk_part_sol_rel_type!=NULLTAG)
	{
		GRM_list_primary_objects_only(t_currentRevision,tsk_part_sol_rel_type,&count_tsk,&TaskRevision);
		printf("\nTask Count  : %d",count_tsk);fflush(stdout);

		if(count_tsk>0)
		{
			for(itsk=0;itsk<count_tsk;itsk++)
			{
				iDMLFnd		=	0;
				TaskRevTag	=	NULLTAG;
				TaskRevTag	=	TaskRevision[itsk];

				if(TCTYPE_ask_object_type(TaskRevTag,&objTaskTypeTag));
				if(TCTYPE_ask_name2(objTaskTypeTag,&type_name));
				printf("\nTask Object Type : %s\n", type_name);fflush(stdout);

				if(tc_strcmp(type_name,"T5_APLTaskRevision")==0)
				{
					//item_id
					AOM_ask_value_string(TaskRevTag,"item_id",&task_name);
					printf("\nTask Id : %s",task_name);fflush(stdout);

					if(tc_strstr(task_name,"PU")!=NULL ||tc_strstr(task_name,"PP")!=NULL || tc_strstr(task_name,"PM")!=NULL || tc_strstr(task_name,"AM")!=NULL || tc_strstr(task_name,"MC")!=NULL)
					{
						//printf("\nPP Task found for DML.");fflush(stdout);
						iPPPM	=	1;
						if(strstr(task_name,PLT_CODE))
						{
							//printf("\nMatch found...!!!");fflush(stdout);

							//if (tc_strstr(task_name,"PR")!=NULL)
							{
								AOM_ask_value_string(TaskRevTag,"item_id",&DML_name);
								AOM_UIF_ask_value(TaskRevTag,"owning_user",&DML_Owner);
								AOM_UIF_ask_value(TaskRevTag,"release_status_list",&DMLRelStatus);
								AOM_ask_value_date(TaskRevTag,"date_released",&STDRelDate);
								DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr);
								
								ITK_date_to_string(STDRelDate,&DateStr);
								
								if(tc_strstr(DMLRelStatus,"STDSIC Released")==NULL)
								{
									printf("\nAssy [%s/%s] PR Task Number [%s] Release Status [%s] PR Task Not STDSIC Released...\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
									//fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] Not STDSIC Released...\n",DMLNum,DMLRelStatus);fflush(stdout);
									continue;
								}
								else
								{
									printf("\nAssy [%s/%s] PR Task Number [%s] Task Release Status [%s] Found Released Task\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
									fprintf(fsuccess,"\nAssy [%s/%s] PR Task Number [%s] Task Release Status [%s] Found Released Task\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
								}

								if(tc_strstr(DML_Owner,"APLloader")!=NULL || tc_strstr(DML_Owner,"aplloader")!=NULL)
								{
									printf("\nAssy [%s/%s] DML [%s] as DML Owner [%s]",c_PartNumber,Part_Rev,DML_name,DML_Owner);
									//fprintf(fsuccess,"\nSkiping DML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
									//continue;
								}

								if (tc_strlen(DateStr)==0)
								{
									printf("\nAssy [%s/%s] DML Number [%s] STD Release Date is NULL..Exiting!\n",c_PartNumber,Part_Rev,DML_name,tc_strlen(DateStr));
									//fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DML_name,tc_strlen(DateStr));
									continue;
								}

								if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL && tc_strlen(DateStr)!=0)
								{
									iDMLFnd	=	1;
									printf("\nAssy [%s/%s] Found DML Number [%s] Release Status [%s] STD Released Date [%s]\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus,STDRelDateStr);fflush(stdout);

									if(tc_strstr(DML_name,"MC")!=NULL)
									{
										MC_DML=1;
										printf("\nDML [%s] is MC DML\n",DML_name);
										fprintf(fsuccess,"\nDML [%s] is MC DML\n",DML_name);
									}

									break;
								}

							}
							/*else
							{
								GRM_find_relation_type("T5_DMLTaskRelation",&dml_task_rel_type);
								if(dml_task_rel_type!=NULLTAG)
								{
									GRM_list_primary_objects_only(TaskRevTag,dml_task_rel_type,&count_DML,&DMLRevision);
									//printf("\nDML Count : %d",count_DML);fflush(stdout);
									if(count_DML>0)
									{
										for(idml=0;idml<count_DML;idml++)
										{
											DMLRevTag	=	NULLTAG;
											DMLRevTag	=	DMLRevision[idml];
											
											if(TCTYPE_ask_object_type(DMLRevTag,&objDMLTypeTag));
											if(TCTYPE_ask_name2(objDMLTypeTag,&type_dml_name));
											//printf("\ntype_dml_name : %s",type_dml_name);fflush(stdout);

											if (tc_strcmp(type_dml_name,"T5_APLDMLRevision")==0)
											{
												
												AOM_ask_value_string(DMLRevTag,"item_id",&DML_name);
												printf("\nDML Id : %s",DML_name);fflush(stdout);
												AOM_UIF_ask_value(DMLRevTag,"owning_user",&DML_Owner);
												AOM_UIF_ask_value(DMLRevTag,"release_status_list",&DMLRelStatus);
												AOM_UIF_ask_value(DMLRevTag,"t5_EcnType",&DMLEcnType);

												AOM_ask_value_date(DMLRevTag,"date_released",&STDRelDate);
												DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr);
												
												ITK_date_to_string(STDRelDate,&DateStr);

												if (tc_strcmp(DMLEcnType,"AMDML")==0)
												{
													printf("\nAssy [%s/%s] DML Number [%s] ECN Type [%s] Checking Next DML...\n",c_PartNumber,Part_Rev,DML_name,DMLEcnType);fflush(stdout);
													continue;
												}

												if(tc_strstr(DMLRelStatus,"STDSIC Released")==NULL)
												{
													printf("\nAssy [%s/%s] DML Number [%s] Release Status [%s] DML Not STDSIC Released...\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
													//fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] Not STDSIC Released...\n",DMLNum,DMLRelStatus);fflush(stdout);
													continue;
												}
												else
												{
													printf("\nAssy [%s/%s] DML Number [%s] DML Release Status [%s] Found Released DML\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
													fprintf(fsuccess,"\nAssy [%s/%s] DML Number [%s] DML Release Status [%s] Found Released DML\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus);fflush(stdout);
												}

												if(tc_strstr(DML_Owner,"APLloader")!=NULL || tc_strstr(DML_Owner,"aplloader")!=NULL)
												{
													printf("\nAssy [%s/%s] DML [%s] as DML Owner [%s]",c_PartNumber,Part_Rev,DML_name,DML_Owner);
													//fprintf(fsuccess,"\nSkiping DML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
													//continue;
												}

												if (tc_strlen(DateStr)==0)
												{
													printf("\nAssy [%s/%s] DML Number [%s] STD Release Date is NULL..Exiting!\n",c_PartNumber,Part_Rev,DML_name,tc_strlen(DateStr));
													//fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DML_name,tc_strlen(DateStr));
													continue;
												}

												if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL && tc_strlen(DateStr)!=0)
												{
													iDMLFnd	=	1;
													*t_DMLRevision	=	DMLRevTag;
													printf("\nAssy [%s/%s] Found DML Number [%s] Release Status [%s] STD Released Date [%s]\n",c_PartNumber,Part_Rev,DML_name,DMLRelStatus,STDRelDateStr);fflush(stdout);
													break;
												}
											}
										}
									}
									else
									{
										printf("\nNo DML found...!!!");fflush(stdout);
									}
								}
							}
						}
					}
				}
				if(iDMLFnd==1)
				{
					printf("\nTask Loop break...!!!");fflush(stdout);
					break;
				}
				else
				{
					//printf("\nChecking Next Task...!!!");fflush(stdout);
					continue;
				}
			}

		}
		else
		{
			printf("\nNo task found");fflush(stdout);
		}
	}

	return iDMLFnd;

}
*/

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child)
{
	    printf("\n i am in function bom_sub_child" );fflush(stdout);
		
		char* cItem_Level = NULL;
		char* cItem_Id = NULL;
		char* cItem_RevSeq = NULL;
		char* cItem_Rev = NULL;
		char* cItem_Seq = NULL;
		char* cArDrStatus = NULL;
		char* cArDrStatusDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		char* cItem_LCDetails = NULL;
		char* cParentName = NULL;
		char* cParentNameDup = NULL;
		int j =0;
		int i =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		tag_t* tSubRwPartItemMst = NULLTAG;
		char* cItem_Desc = NULL;
		char* cQuantity = NULL;
		char* cQuantityDup = NULL;
		
		tag_t ChildOPtr		= NULLTAG;
		int Item_ID=0,Item_UoM=0,Item_Owner=0;
		static int sr_no1 		= 0;
		int ret;
		
		char *LatRevName			= NULL;
	char *Plant_MakeBuy			= NULL;
	//char *bl_mkbuy_string		= NULL;
	char *POwnerName			= NULL;
	char *POwnerNameDup			= NULL;
	char *InpRevSeq				= NULL;
	char *ChildRevName			= NULL;
	char *ChildOwnName			= NULL;
	char *ChildPrtType			= NULL;
	char *ChildPrtQty			= NULL;
	char *ChildQtyDup			= NULL;
	char *ChildPrtUoM			= NULL;
	char *PartRelStatus			= NULL;
	char *ChildRelStatus		= NULL;
	char *PartRevSeq			= NULL;
	
	char *ChildPartType		= NULL;
	char *ChildPartDesc		= NULL;
	int ChildPartDesc1		= 0;
	float floatQty= 0.000;
	char *mat_prov_ind	= NULL;
	char *make_buy_ind 		= NULL;
	char *unitDup 			= NULL;
	char *part_noDup 		= NULL;
	char *part_noDup1	= NULL;
	char *tempcsrel		= NULL;
	
	
	char *make_buy_indDup 	= NULL;
	char *sr_no			= NULL;
	
	meas_unit	= (char *) malloc(500 * sizeof(char));
	sr_no		= (char *) malloc(500 * sizeof(char));
	
	
	//char *LCStateChk			= NULL;
			//Child part loop
			for(i=0;i<iSubSubNumber_Child;i++)
			{
							printf("\n for loop of child part" );fflush(stdout);
							
							ChildOPtr=tBOM_Sub_Children[i];

							//BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID);
							//BOM_line_ask_attribute_string(ChildOPtr, Item_ID, &ChildRevName);
							AOM_ask_value_string(ChildOPtr,"bl_item_item_id",&ChildRevName);
							
							printf("\n ChildRevName[%s]",ChildRevName );fflush(stdout);
							
							//BOM_line_look_up_attribute ("bl_item_uom_tag",&Item_UoM);
							//BOM_line_ask_attribute_string(ChildOPtr,Item_UoM,&ChildPrtUoM);
							AOM_ask_value_string(ChildOPtr,"bl_item_uom_tag",&ChildPrtUoM);
							
							printf("\n ChildPrtUoM[%s]",ChildPrtUoM );fflush(stdout);

							//BOM_line_look_up_attribute ("awb0RevisionOwningUser",&Item_Owner);
							//BOM_line_ask_attribute_string(ChildOPtr,Item_Owner,&ChildOwnName);
							AOM_ask_value_string(ChildOPtr,"awb0RevisionOwningUser",&ChildOwnName);
							
							printf("\n ChildOwnName[%s]",ChildOwnName );fflush(stdout);
							printf("\n bl_mkbuy_string[%s]",bl_mkbuy_string );fflush(stdout);

							ITK_CALL(AOM_UIF_ask_value(ChildOPtr,"bl_rev_release_status_list",&ChildRelStatus));
							printf("\n ChildRelStatus[%s]",ChildRelStatus );fflush(stdout);
							AOM_ask_value_string(ChildOPtr,"bl_quantity",&ChildPrtQty);
							printf("\n ChildPrtQty[%s]",ChildPrtQty );fflush(stdout);
							AOM_ask_value_string(ChildOPtr,"bl_Design Revision_t5_PartType",&ChildPartType);
							printf("\n ChildPartType[%s]",ChildPartType );fflush(stdout);
							AOM_ask_value_string(ChildOPtr,bl_mkbuy_string,&make_buy_ind);
							printf("\n make_buy_ind[%s]",make_buy_ind );fflush(stdout);
							
							//BOM_line_look_up_attribute ("bl_item_object_desc",&ChildPartDesc1);
							//BOM_line_ask_attribute_string(ChildOPtr,ChildPartDesc1,&ChildPartDesc);
							
							AOM_ask_value_string(ChildOPtr,"bl_item_object_desc",&ChildPartDesc);
							
							if (ChildPartDesc==NULL)
							{
								tc_strdup("NA",&ChildPartDesc);
							}
							
							printf("\nChild ChildPrtUoM is : %s",ChildPrtUoM);fflush(stdout);
							fprintf(fsuccess,"\nChild ChildPrtUoM is : %s",ChildPrtUoM);fflush(fsuccess);
							
							printf("\nChild ChildPartDesc is : %s",ChildPartDesc);fflush(stdout);
							fprintf(fsuccess,"\nChild ChildPartDesc is : %s",ChildPartDesc);fflush(fsuccess);
							
							int is=0;
							while(ChildPartDesc[is]!='\0')
							{
								if(ChildPartDesc[is]==',' || ChildPartDesc[is]=='\n')
								{
									ChildPartDesc[is]=' ';
								}
								is++;
							}

						printf("\nPlant wise LCstate[%s]",LCStateChk);fflush(stdout);
						if(tc_strstr(ChildRelStatus,LCStateChk)==NULL)
						{
							printf("\nChild Part %s ChildRelStatus: %s Part not STDSIC Released...Skipping\n",ChildRevName,ChildRelStatus);fflush(stdout);
							fprintf(fsuccess,"\nChild Part %s ChildRelStatus: %s Part not STDSIC Released...Skipping\n",ChildRevName,ChildRelStatus);fflush(fsuccess);
							continue;
						}

						tc_strdup(ChildPrtQty,&ChildQtyDup);
						//printf("\nChild Part Number [%s] Part Qty [%s]	UoM [%s]	Owner [%s]",ChildRevName,ChildPrtQty,ChildPrtUoM,ChildOwnName);
						
						if(tc_strcmp(ChildPrtQty, "") == 0 || tc_strcmp(ChildPrtQty,"0") == 0 || tc_strcmp(ChildPrtQty,"0.00000") == 0)
						{
							printf("\nChild Part Number [%s] Part Qty [%s] hence skipping",ChildRevName,ChildPrtQty);fflush(stdout);
							continue;
						}

						if (
							tc_strcmp(ChildPartType,"D")==0 ||
							tc_strcmp(ChildPartType,"DA")==0 ||
							tc_strcmp(ChildPartType,"DC")==0 ||
							tc_strcmp(ChildPartType,"CM")==0 ||//added 24.03.2023 Hrishikesh
							tc_strcmp(ChildPartType,"IFD")==0 ||
							tc_strcmp(ChildPartType,"IM")==0 ||
							tc_strcmp(ChildPartType,"CP")==0 ||
							tc_strstr(ChildRevName,"_") !=NULL
							)
						{
							printf("\nSkipping Child Part [%s] as Part Type [%s]",ChildRevName,ChildPartType);fflush(stdout);
							continue;
						}

						tc_strdup(make_buy_ind,&make_buy_indDup);

						//if(tc_strlen(make_buy_ind)==0 || tc_strcmp(make_buy_ind,"NA")==0 || tc_strcmp(make_buy_ind,"F")==0)
						if(tc_strlen(make_buy_ind)==0 || tc_strcmp(make_buy_ind,"NA")==0)
						{
							printf("\nSkipping Child Part [%s] as Plant Make/Buy is NULL or NA",ChildRevName);fflush(stdout);
							continue;
						}

						if(tc_strlen(make_buy_ind)>0)
						{
							tc_strdup(make_buy_ind,&make_buy_indDup);

							if(tc_strcmp(make_buy_indDup,"F18") == 0)
							{
								tc_strdup("L",&mat_prov_ind);
								tc_strdup("1",&tempcsrel);
							}
							else
							{
								tc_strdup("",&mat_prov_ind);
								tc_strdup("X",&tempcsrel);
							}
						}
					
						if(tc_strlen(ChildPrtUoM)>0)
						{
							tc_strdup(ChildPrtUoM,&unitDup);
							if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
							else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
							else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
							else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
							else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
							else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
							else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
							else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
							else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
							else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
							else
							{
								tc_strdup("EA",&unitDup);
								tc_strcpy(meas_unit,"EA");
							}
						}
						else tc_strcpy(meas_unit,"EA");
							
						tc_strdup(ChildRevName,&part_noDup);
						floatQty = atof(ChildQtyDup);

						printf("\nFinal Node [%s]desc[%s][%7.3f][%s][%s][%s][%s]",part_noDup,ChildPartDesc,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);fflush(stdout);

						if(p==NULL)
						{
							printf("\n if search");fflush(stdout);
							printf("\nFinal Node1 added [%s][%7.3f][%s][%s][%s][%s]",part_noDup,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);fflush(stdout);
							sr_no1 = 1 ;
							sprintf(sr_no,"%04d",sr_no1);
							tc_strdup(part_noDup,&part_noDup1);
							p = createnode(sr_no,part_noDup1,ChildPartDesc,&floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);
							start = p;
						}
						else
						{
							printf("\n search");fflush(stdout);
							ret = search(start,part_noDup,&floatQty);
							printf("\n search1");fflush(stdout);
							if(ret==1)
							{
								 q=start;
								 while(q->next!=NULL)
								 {
									 q=q->next;
								 }
								 printf("\nFinal Node2 added [%s][%7.3f][%s][%s][%s][%s]",part_noDup,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);fflush(stdout);
								 sr_no1 = sr_no1 + 1 ;
								 sprintf(sr_no,"%04d",sr_no1);
								//strcpy(part_noDup1,part_noDup);
								tc_strdup(part_noDup,&part_noDup1);
								q->next=createnode(sr_no,part_noDup1,ChildPartDesc,&floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);
							}
						}
				if((tc_strcmp(make_buy_ind,"F")==0) || (tc_strcmp(make_buy_ind,"F18")==0))
				{
					printf("\n Stop at F [%s]",make_buy_ind);fflush(stdout);
				}
				else
				{
					ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[i], &iNumber_SubChild, &tSubChild));
					printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
					if(iNumber_SubChild > 0)
					{
						bom_sub_child(tSubChild,iNumber_SubChild);
					}
					else if(iNumber_SubChild == 0)
					{
						if((tc_strcmp(ChildPartType,"SA")==0) ||(tc_strcmp(ChildPartType,"R")==0)||(tc_strcmp(ChildPartType,"SP")==0))
						{
							if(tc_strlen(ChildRevName)>=14)
							{
							tag_t MCPartTag = NULLTAG;
							tag_t		RwPartRel			= NULLTAG;
							tag_t		RawPartRelTag		= NULLTAG;
							ITK_CALL(GRM_find_relation_type("T5_RPtRel",&RwPartRel));
							
							ITK_CALL(AOM_ask_value_tag(ChildOPtr, "bl_revision", &MCPartTag));
							
							printf("\n tc_strlen(ChildRevName): [%d]\n",tc_strlen(ChildRevName));fflush(stdout);
							ITK_CALL(AOM_ask_value_tags(MCPartTag,"T5_RPtRel",&iNumber_SubChild,&tSubRwPartItemMst));
							printf("\n*******1111111 : %d ",iNumber_SubChild);fflush(stdout);
							int rawpCnt;
							tag_t		RwPartMstTag		= NULLTAG;
							if(iNumber_SubChild>0)
							{
								for(rawpCnt=0;rawpCnt<iNumber_SubChild;rawpCnt++)
								{
									printf("\n 11111");fflush(stdout);
									RwPartMstTag=tSubRwPartItemMst[rawpCnt];
									ITK_CALL(ITEM_ask_latest_rev(RwPartMstTag,&ChildOPtr));
									printf("\n 222222");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(ChildOPtr,"item_id",&ChildRevName));
									printf("\n 333333333");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(ChildOPtr,"t5_uom",&ChildPrtUoM));
									printf("\n 44444");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(ChildOPtr,"t5_PartType",&ChildPartType));
									printf("\n 55555555");fflush(stdout);
									ITK_CALL(AOM_UIF_ask_value(ChildOPtr,"release_status_list",&ChildRelStatus));
									printf("\n 66666666");fflush(stdout);
									ITK_CALL(AOM_UIF_ask_value(ChildOPtr,"current_desc",&ChildPartDesc));
									printf("\n 777777");fflush(stdout);
									if (ChildPartDesc==NULL)
									{
										tc_strdup("NA",&ChildPartDesc);
									}
									printf("\n 88888888");fflush(stdout);
									int is=0;
									while(ChildPartDesc[is]!='\0')
									{
										if(ChildPartDesc[is]==',' || ChildPartDesc[is]=='\n')
										{
											ChildPartDesc[is]=' ';
										}
										is++;
									}
									printf("\n 999999999");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(ChildOPtr,"t5_CarMakeBuyIndicator",&make_buy_ind));
									printf("\n 111111111111111");fflush(stdout);

									ITK_CALL(GRM_find_relation(MCPartTag,RwPartMstTag,RwPartRel,&RawPartRelTag));
									ITK_CALL(AOM_UIF_ask_value(RawPartRelTag,"t5_UsageRT",&ChildPrtQty));
									tc_strdup(ChildPrtQty,&ChildQtyDup);
									printf("\nChild Raw Part :%s,%s,%s,%s",ChildRevName,ChildPrtUoM,ChildPartType,ChildPrtQty);
									
									printf("\nPlant wise LCstate[%s]",LCStateChk);fflush(stdout);
									if(tc_strstr(ChildRelStatus,LCStateChk)==NULL)
									{
										printf("\nChild Part %s ChildRelStatus: %s Part not STDSIC Released...Skipping\n",ChildRevName,ChildRelStatus);fflush(stdout);
										fprintf(fsuccess,"\nChild Part %s ChildRelStatus: %s Part not STDSIC Released...Skipping\n",ChildRevName,ChildRelStatus);fflush(fsuccess);
										continue;
									}
									
									tc_strdup(ChildPrtQty,&ChildQtyDup);
						//printf("\nChild Part Number [%s] Part Qty [%s]	UoM [%s]	Owner [%s]",ChildRevName,ChildPrtQty,ChildPrtUoM,ChildOwnName);
						
						if(tc_strcmp(ChildPrtQty, "") == 0 || tc_strcmp(ChildPrtQty,"0") == 0 || tc_strcmp(ChildPrtQty,"0.00000") == 0)
						{
							printf("\nChild Part Number [%s] Part Qty [%s] hence skipping",ChildRevName,ChildPrtQty);fflush(stdout);
							continue;
						}

						if (
							tc_strcmp(ChildPartType,"D")==0 ||
							tc_strcmp(ChildPartType,"DA")==0 ||
							tc_strcmp(ChildPartType,"DC")==0 ||
							tc_strcmp(ChildPartType,"CM")==0 ||//added 24.03.2023 Hrishikesh
							tc_strcmp(ChildPartType,"IFD")==0 ||
							tc_strcmp(ChildPartType,"IM")==0 ||
							tc_strcmp(ChildPartType,"CP")==0 ||
							tc_strstr(ChildRevName,"_") !=NULL
							)
						{
							printf("\nSkipping Child Part [%s] as Part Type [%s]",ChildRevName,ChildPartType);fflush(stdout);
							continue;
						}

						tc_strdup(make_buy_ind,&make_buy_indDup);

						//if(tc_strlen(make_buy_ind)==0 || tc_strcmp(make_buy_ind,"NA")==0 || tc_strcmp(make_buy_ind,"F")==0)
						if(tc_strlen(make_buy_ind)==0 || tc_strcmp(make_buy_ind,"NA")==0)
						{
							printf("\nSkipping Child Part [%s] as Plant Make/Buy is NULL or NA",ChildRevName);fflush(stdout);
							continue;
						}

						if(tc_strlen(make_buy_ind)>0)
						{
							tc_strdup(make_buy_ind,&make_buy_indDup);

							if(tc_strcmp(make_buy_indDup,"F18") == 0)
							{
								tc_strdup("L",&mat_prov_ind);
								tc_strdup("1",&tempcsrel);
							}
							else
							{
								tc_strdup("",&mat_prov_ind);
								tc_strdup("X",&tempcsrel);
							}
						}
					
						if(tc_strlen(ChildPrtUoM)>0)
						{
							tc_strdup(ChildPrtUoM,&unitDup);
							if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
							else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
							else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
							else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
							else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
							else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
							else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
							else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
							else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
							else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
							else
							{
								tc_strdup("EA",&unitDup);
								tc_strcpy(meas_unit,"EA");
							}
						}
						else tc_strcpy(meas_unit,"EA");
							
						tc_strdup(ChildRevName,&part_noDup);
						floatQty = atof(ChildQtyDup);

						printf("\nFinal Node [%s]desc[%s][%7.3f][%s][%s][%s][%s]",part_noDup,ChildPartDesc,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);fflush(stdout);

						if(p==NULL)
						{
							printf("\n if search");fflush(stdout);
							printf("\nFinal Node1 added [%s][%7.3f][%s][%s][%s][%s]",part_noDup,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);fflush(stdout);
							sr_no1 = 1 ;
							sprintf(sr_no,"%04d",sr_no1);
							tc_strdup(part_noDup,&part_noDup1);
							p = createnode(sr_no,part_noDup1,ChildPartDesc,&floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);
							start = p;
						}
						else
						{
							printf("\n search");fflush(stdout);
							ret = search(start,part_noDup,&floatQty);
							printf("\n search1");fflush(stdout);
							if(ret==1)
							{
								 q=start;
								 while(q->next!=NULL)
								 {
									 q=q->next;
								 }
								 printf("\nFinal Node2 added [%s][%7.3f][%s][%s][%s][%s]",part_noDup,floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);fflush(stdout);
								 sr_no1 = sr_no1 + 1 ;
								 sprintf(sr_no,"%04d",sr_no1);
								//strcpy(part_noDup1,part_noDup);
								tc_strdup(part_noDup,&part_noDup1);
								q->next=createnode(sr_no,part_noDup1,ChildPartDesc,&floatQty,meas_unit,tempcsrel,mat_prov_ind,make_buy_indDup);
							}
						}
								}
							}
						
							
							//bom_sub_child(tSubRwPartItemMst,iNumber_SubChild);
						}
					}
					}
				}
			}//for loop child parts


	return iFail;
}
int ITK_user_main(int argc, char* argv[])
{
	char* cError = NULL;
	int ifail = ITK_ok;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	int status;
	if(ITK_auto_login() == ITK_ok)	
	//ITK_CALL(ITK_init_module ("akumar1.ttl","XYT1ESA","PLM_Support_Group"));
	//ITK_CALL(ITK_init_module ("aplplanner","XYT1ESA","APLCAR"));
	{
	
	int status;
	struct usgProbnode *pUP = NULLTAG;

	char *part_noDup1	= NULL;
	char my_denis[14] = {0};

	tag_t ChildOPtr		= NULLTAG;
	tag_t ChildOPtrCpy	= NULLTAG;
	tag_t PartOPtr		= NULLTAG;
	tag_t *partObjs		= NULLTAG;

	char *sUserName		= NULL;
	char *sPassword 	= NULL;
	char *AssyNo		= NULL;
	char *plantname		= NULL;
	char *sRevision		= NULL;
	char *sSequence		= NULL;
	//char *mat_prov_ind	= NULL;
	//char *meas_unit		= NULL;
	//char *sr_no			= NULL;
	//char *tempcsrel		= NULL;
	int ci			= 0;
	int ei			= 0;
	int grind		= 0;
	int iPartIndex;
	int ret;
	int failflag		= 0;
	int i				= 0;
	int noOfChilds		= 0;
	int stat			= 0;
	int taskCount		= 0;
	static int sr_no1 		= 0;
	int ia=0;
	int ja=0;
	int ka=0;
	int la=0;
	int ret1=0;

	char *AssyPrttype 		= NULL;
	char *AssyPrttypeDup 	= NULL;
	char *Revision 			= NULL;
	char *RevisionDup 		= NULL;
	char *assy_no 			= NULL;
	char *assy_noDup 		= NULL;
	char *date_updated 		= NULL;
	char *date_updatedDup 	= NULL;
	char *epaowner 			= NULL;
	char *epaownerDup 		= NULL;
	char *eparelzstate 		= NULL;
	char *eparelzstateDup 	= NULL;
	char *epataskId 		= NULL;
	char *epataskIdDup 		= NULL;
	char *make_buy_ind 		= NULL;
	char *make_buy_indDup 	= NULL;
	char *part_no 			= NULL;
	char *part_noDup 		= NULL;
	char *taskId 			= NULL;
	char *taskIdDup 		= NULL;
	char *unit 				= NULL;
	char *unitDup 			= NULL;
	char *DispName 			= NULL;
	char *DispNameDup 		= NULL;
	char *PrtCls 			= NULL;
	char *PrtClsDup 		= NULL;
	char *cPrtCls			= NULL;
	char *owner				= NULL;
	char *ownerDup			= NULL;
	char *prjcode			= NULL;
	char *prjcodeDup 		= NULL;
	char *prtType 			= NULL;
	char *prtTypeDup 		= NULL;
	char *qty 				= NULL;
	char *qtyDup 			= NULL;
	char *qty_req_info 		= NULL;
	char *qty_req_infoDup 	= NULL;
	char *relzstate 		= NULL;
	char *relzstateDup 		= NULL;
	
	//struct node *start = NULL;
	//struct node *p = NULL;
	//struct node *q = NULL;

	//float floatQty= 0.000;
	char *iOrganizationID	= NULL;
	char *StdDate			= NULL;
	char *MonYear			= NULL;
	char *inputDmlNumber	= NULL;
	char *inputPlantCode	= NULL;
	char *ChildPartType		= NULL;
	char *ChildPartDesc		= NULL;
	char *my_comp_part_sap	= NULL;

	int cnt = 0 ;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};


	char *AssemblyRevision 		= NULL;
	char *AssemblyRevisionDup 	= NULL;
	char *SequenceRevision 		= NULL;
	char *SequenceRevisionDup 	= NULL;
	
	int n_entries			= 0;
	int resultCount 		= 0;
	int CntChildP 			= 0;
	int ChildItemTag 		= 0;
	int n_closure_tags 		= 0;
	int Item_ID=0,Item_UoM=0,Item_Owner=0;
	//ITK_CALL(ITK_init_module ("dkk04042","1234","APLLKO"));
	char *LatRevName			= NULL;
	char *Plant_MakeBuy			= NULL;
	//char *bl_mkbuy_string		= NULL;
	char *POwnerName			= NULL;
	char *POwnerNameDup			= NULL;
	char *InpRevSeq				= NULL;
	char *ChildRevName			= NULL;
	char *ChildOwnName			= NULL;
	char *ChildPrtType			= NULL;
	char *ChildPrtQty			= NULL;
	char *ChildQtyDup			= NULL;
	char *ChildPrtUoM			= NULL;
	char *PartRelStatus			= NULL;
	char *ChildRelStatus		= NULL;
	char *PartRevSeq			= NULL;
	char *PlantSuffix			= NULL;
	//char *LCStateChk			= NULL;
	char *plantcode1			= NULL;
	plantcode1	= (char *) malloc(500 * sizeof(char));

	tag_t		queryTag		= NULLTAG;
	tag_t		LatestPRev		= NULLTAG;
	tag_t		window			= NULLTAG;
	tag_t		rule			= NULLTAG;
	char		*ClosureRule	= NULL;
	char		*rule1			= NULL;
	tag_t		*closure_tags	= NULLTAG;
	tag_t		closure_tag		= NULLTAG;
	tag_t		t_DMLRevision	= NULLTAG;
	
	tag_t		*outTag = NULLTAG;
	tag_t		PerentLine = NULLTAG;
	tag_t		*ChildPartLine = NULLTAG;
	tag_t		ChildItemRevTag = NULLTAG;
	tag_t		*RwPartItemMst		= NULLTAG;
	tag_t		RwPartMstTag		= NULLTAG;
	tag_t		RwPartRel			= NULLTAG;
	tag_t		RawPartRelTag		= NULLTAG;
	
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	char Data[100] = "";
	char fsuccess_name[200];
	char outputFile[200] = "";
	char outputFile1[200] = "";
	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	
	//sUserName		= ITK_ask_cli_argument("-u=dkk04042");
	//sPassword		= ITK_ask_cli_argument("-p=1234");
	char* ModuleList			= ITK_ask_cli_argument("-modlf=");
	char* RptFileName			= ITK_ask_cli_argument("-df=");
	char* SumFileName			= ITK_ask_cli_argument("-sf=");
	char* LogFileName			= ITK_ask_cli_argument("-lf=");
//AssyNo			= ITK_ask_cli_argument("-a=");
	//sRevision		= ITK_ask_cli_argument("-r=");
	//sSequence		= ITK_ask_cli_argument("-s=");
	plantcode		= ITK_ask_cli_argument("-t=");
	iSapServer		= ITK_ask_cli_argument("-c=");
	
	 RptFileline=0;
	 SummFileline=0;
	
	//iSapServer = (char *) MEM_alloc( 1000 * sizeof(char) );
	//tc_strcpy(iSapServer,"");
	//tc_strcpy(iSapServer,"CVP");
	
	printf("\n iSapServer [%s]\n", iSapServer);fflush(stdout);


	printf("\nInput Assay %s	plantcode [%s]\n", AssyNo,plantcode);fflush(stdout);
	
	//sprintf(outputFile,"/tmp/AkkiLogBOM_%s.log",Data);
	//sprintf(outputFile,"/tmp/AkkiLogBOM_%s.log",Data);
	//sprintf(outputFile,"/user/testcmi/Dev/devgroups/Akhilesh/PLMSAPBOMCompare/AkkiLogBOM_%s.log",Data);
	
	//sprintf(fsuccess_name,"/user/uaprodtrl/Poonam/PLMSAP_MultiLevelBOMCompareNEXON/NEXON_TCUA_SAP_BOM_Mismatch_%s.log",Data);
	fsuccess=fopen(LogFileName,"w");
	
	if(fsuccess == NULL)
	printf("\nUnable To open Or Create Log  file");fflush(stdout);
	
	
	//sprintf(outputFile,"/user/uaprodtrl/Poonam/PLMSAP_MultiLevelBOMCompareNEXON/NEXON_TCUA_SAP_BOM_Mismatch_%s.csv",Data);
	//sprintf(outputFile1,"/user/uaprodtrl/Poonam/PLMSAP_MultiLevelBOMCompareNEXON/NEXON_TCUA_SAP_BOM_Mismatch_Summry_%s.csv",Data);
	fsuccessRpt=fopen(RptFileName,"w");
	fsuccessRptSumm=fopen(SumFileName,"w");
	
	if(fsuccessRpt == NULL)
	printf("\nUnable To open Or Create Log  file");fflush(stdout);
	
	if(fsuccessRptSumm == NULL)
	printf("\nUnable To open Or Create Log  file");fflush(stdout);
	
	strftime(Data,100,"%d-%m-%Y %H:%M:%S",&when);
	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	//ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	

	
	if (tc_strcmp(plantcode,"2200") == 0) tc_strcpy(plantcode1,"UTK");
	else if (tc_strcmp(plantcode,"1100") == 0) tc_strcpy(plantcode1,"PuneCar");
	else if (tc_strcmp(plantcode,"1500") == 0) tc_strcpy(plantcode1,"Dharwad");
	else if (tc_strcmp(plantcode,"1001") == 0) tc_strcpy(plantcode1,"Pune");
	else if (tc_strcmp(plantcode,"3001") == 0) tc_strcpy(plantcode1,"Lko");
	else if (tc_strcmp(plantcode,"2001") == 0) tc_strcpy(plantcode1,"JSR");
	else if (tc_strcmp(plantcode,"E201") == 0) tc_strcpy(plantcode1,"SMALLCAR AHD");
	else tc_strcpy(plantcode1,"MyPlant");


	tc_strdup(sRevision,&AssemblyRevisionDup);
	tc_strdup(sSequence,&SequenceRevisionDup);
	
	//sprintf(fsuccess_name,"TCUA_SAP_BOM_Mismatch_%s.log",AssyNo);
	//sprintf(fsuccess_BomCmpRpt,"TCUA_SAP_BOM_Mismatch.txt");
	//fsuccess = fopen(fsuccess_name,"a");
	//fsuccessRpt=fopen("/tmp/TCUA_SAP_BOM_Mismatch.csv","w");
	
	//fsuccessRpt = fopen(fsuccess_BomCmpRpt,"w");
	

	//char *qry_entries[1] = {"ID"};
	n_entries=1;
	//char *qry_entries[2] = {"Item ID","Revision"};
	//char *qry_entries[2] = {"Item ID","Release Status"};
	char *qry_entries[1] = {"Item ID"};

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	
	//char *output					= NULL;
			
	output = (char *) MEM_alloc( 1000 * sizeof(char) );
	tc_strcpy(output,"");

	/*InpRevSeq 		= NULL;
	InpRevSeq=(char *) MEM_alloc(50);
	strcpy(InpRevSeq,sRevision);
	strcat(InpRevSeq,"*");
	strcat(InpRevSeq,sSequence);

	qry_values[0] = AssyNo;
	qry_values[1] = InpRevSeq;*/
	//fprintf(fsuccessRpt,"\n\t\t\t\t,,,,PLM-SAP Mismatch Report details,,");fflush(fsuccessRpt);
	//fprintf(fsuccessRpt,"\n\n");fflush(fsuccessRpt);
	//fprintf(fsuccessRpt,"\nPLM Part Number~PLM Part Desc~SAP Part number~Part Comparison~PLM CS~SAP CS~CS Comparison~PLM UOM~SAP UOM~UOM Comparison~PLM Qty~SAP Qty~Qty Comparison~");fflush(fsuccessRpt);
	//fprintf(fsuccessRpt,"\nProject Code,Model,Arch Node,Module,Description, Part No.,Part Description,TCUA Qty,SAP Qty,Status,");fflush(fsuccessRpt);
	
	//fprintf(fsuccessRptSumm,"\n\t\t\t\t,,,,PLM-SAP Mismatch Summary,,");fflush(fsuccessRptSumm);
	//fprintf(fsuccessRptSumm,"\n\n");fflush(fsuccessRptSumm);
	//fprintf(fsuccessRpt,"\nPLM Part Number~PLM Part Desc~SAP Part number~Part Comparison~PLM CS~SAP CS~CS Comparison~PLM UOM~SAP UOM~UOM Comparison~PLM Qty~SAP Qty~Qty Comparison~");fflush(fsuccessRpt);
	//fprintf(fsuccessRptSumm,"\nProject Code,Model,Arch Node,Module,Description,Status,");fflush(fsuccessRptSumm);
	
	char* inputline=(char *) MEM_alloc(5000);
	FILE *InpFilePtr = fopen(ModuleList,"r");
	while(fgets(inputline,5000,InpFilePtr)!=NULL)
	{
		start = NULL;
		p = NULL;
		q = NULL;
		
		
		p_sap = NULL;
		q_sap = NULL;

		printf("\n Input line is : [%s]",inputline);fflush(stdout);
		AssyNo=strtok(inputline,"~"); trim(AssyNo);  //1
        printf(AssyNo);fflush(stdout);


	qry_values[0] = AssyNo;
    //qry_values[1] = "T5_LcsAplRlzd";
    //qry_values[1] = "T5_LcsStddRlzd;T5_LcsStdlRlzd;T5_LcsStdjRlzd;T5_LcsStduRlzd;T5_LcsStdpRlzd;T5_LcsStdaRlzd;T5_LcsStdRlzd";

	//if(QRY_find("PartMatQ", &queryTag));
	//if(QRY_find("Unique RevSeq", &queryTag));
	//if(QRY_find("Driver VC Query", &queryTag));
	if(QRY_find2("Item Revision...", &queryTag));
	if(queryTag)
	{
		printf("\nFound Query PartMatQuery\n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query PartMatQuery\n");fflush(stdout);
	}
	
	//Executing query
	//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &partObjs));
	ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &partObjs));

	printf("\nresultCount :%d:\n",resultCount);fflush(stdout);
	int prtRlz=0;
	if(resultCount>0)
	{
		for (cnt=0;cnt< resultCount;cnt++ )
		{
			PartOPtr=partObjs[cnt];

			//ITK_CALL(ITEM_ask_latest_rev(PartOPtr,&LatestPRev));	
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"object_string",&LatRevName));
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"owning_user",&POwnerName));
			tc_strdup(POwnerName,&POwnerNameDup);
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"release_status_list",&PartRelStatus));
			printf("\nPartRelStatus [:%s]",PartRelStatus);fflush(stdout);
			
			ITK_CALL(AOM_ask_value_string(PartOPtr,"item_revision_id",&PartRevSeq));
			
			//if(tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)
			
			if (tc_strcmp(plantcode,"1100")==0)
			{
				if(tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)
				{
					prtRlz=1;
					break;
				}
			}
			else if (tc_strcmp(plantcode,"1500")==0)
			{
				if(tc_strstr(PartRelStatus,"STDSID Released")!=NULL)
				{
					prtRlz=1;
					break;
				}
			}
			else if (tc_strcmp(plantcode,"1001")==0)
			{
				if(tc_strstr(PartRelStatus,"STDSIP Released")!=NULL)
				{
					prtRlz=1;
					break;
				}
			}
			else if (tc_strcmp(plantcode,"3001")==0)
			{
				if(tc_strstr(PartRelStatus,"STDSIL Released")!=NULL)
				{
					prtRlz=1;
					break;
				}
			}
			else if (tc_strcmp(plantcode,"2001")==0)
			{
				if(tc_strstr(PartRelStatus,"STDSIJ Released")!=NULL)
				{
					prtRlz=1;
					break;
				}
			}
			else if (tc_strcmp(plantcode,"2200")==0)
			{
				if(tc_strstr(PartRelStatus,"STDSIU Released")!=NULL)
				{
					prtRlz=1;
					break;
				}
			}
			//Added Shubham
			else if (tc_strcmp(plantcode,"E201")==0)
			{
				if(tc_strstr(PartRelStatus,"STDSIA Released")!=NULL)
				{
					prtRlz=1;
					break;
				}
			}
			//Ended
			else
			{
				printf("\n Plant is invalid [%s]",plantcode);fflush(stdout);
			}
			
		}
	}
	
	if (tc_strcmp(plantcode,"1100")==0)
	{
		tc_strdup("t5_CarMakeBuyIndicator",&Plant_MakeBuy);
		tc_strdup("bl_Design Revision_t5_CarMakeBuyIndicator",&bl_mkbuy_string);
		//tc_strdup("BOMViewClosureRuleSTDC",&ClosureRule);
		tc_strdup("GenTPLBOMViewClosureRuleSTDC",&ClosureRule);
		tc_strdup("APLC",&PlantSuffix);
		tc_strdup("STDC Released and Above",&rule1);
		tc_strdup("STDSIC Released",&LCStateChk);
	}
	else if (tc_strcmp(plantcode,"1500")==0)
	{
		tc_strdup("t5_DwdMakeBuyIndicator",&Plant_MakeBuy);
		tc_strdup("bl_Design Revision_t5_DwdMakeBuyIndicator",&bl_mkbuy_string);
		//tc_strdup("BOMViewClosureRuleSTDD",&ClosureRule);
		tc_strdup("GenTPLBOMViewClosureRuleSTDD",&ClosureRule);
		tc_strdup("APLD",&PlantSuffix);
		tc_strdup("STDD Released and Above",&rule1);
		tc_strdup("STDSID Released",&LCStateChk);
	}
	else if (tc_strcmp(plantcode,"1001")==0)
	{
		tc_strdup("t5_PunMakeBuyIndicator",&Plant_MakeBuy);
		tc_strdup("bl_Design Revision_t5_PunMakeBuyIndicator",&bl_mkbuy_string);
		//tc_strdup("BOMViewClosureRuleSTDP",&ClosureRule);
		tc_strdup("GenTPLBOMViewClosureRuleSTDP",&ClosureRule);
		tc_strdup("APLP",&PlantSuffix);
		tc_strdup("STDP Released and Above",&rule1);
		tc_strdup("STDSIP Released",&LCStateChk);
	}
	else if (tc_strcmp(plantcode,"3001")==0)
	{
		tc_strdup("t5_LkoMakeBuyIndicator",&Plant_MakeBuy);
		tc_strdup("bl_Design Revision_t5_LkoMakeBuyIndicator",&bl_mkbuy_string);
		//tc_strdup("BOMViewClosureRuleSTDL",&ClosureRule);
		tc_strdup("GenTPLBOMViewClosureRuleSTDL",&ClosureRule);
		tc_strdup("APLL",&PlantSuffix);
		tc_strdup("STDL Released and Above",&rule1);
		tc_strdup("STDSIL Released",&LCStateChk);
	}
	else if (tc_strcmp(plantcode,"2001")==0)
	{
		tc_strdup("t5_JsrMakeBuyIndicator",&Plant_MakeBuy);
		tc_strdup("bl_Design Revision_t5_JsrMakeBuyIndicator",&bl_mkbuy_string);
		//tc_strdup("BOMViewClosureRuleSTDJ",&ClosureRule);
		tc_strdup("GenTPLBOMViewClosureRuleSTDJ",&ClosureRule);
		tc_strdup("APLJ",&PlantSuffix);
		tc_strdup("STDJ Released and Above",&rule1);
		tc_strdup("STDSIJ Released",&LCStateChk);
	}
	else if (tc_strcmp(plantcode,"2200")==0)
	{
		tc_strdup("t5_PnrMakeBuyIndicator",&Plant_MakeBuy);
		tc_strdup("bl_Design Revision_t5_PnrMakeBuyIndicator",&bl_mkbuy_string);
		//tc_strdup("BOMViewClosureRuleSTDU",&ClosureRule);
		tc_strdup("GenTPLBOMViewClosureRuleSTDU",&ClosureRule);
		tc_strdup("APLU",&PlantSuffix);
		tc_strdup("STDU Released and Above",&rule1);
		tc_strdup("STDSIU Released",&LCStateChk);
	}
	//Added Shubham
	else if (tc_strcmp(plantcode,"E201")==0)
	{
		tc_strdup("t5_AhdMakeBuyIndicator",&Plant_MakeBuy);
		tc_strdup("bl_Design Revision_t5_AhdMakeBuyIndicator",&bl_mkbuy_string);
		//tc_strdup("BOMViewClosureRuleSTDD",&ClosureRule);
		tc_strdup("GenTPLBOMViewClosureRuleSTDA",&ClosureRule);
		tc_strdup("APLA",&PlantSuffix);
		tc_strdup("STDA Released and Above",&rule1);
		tc_strdup("STDSIA Released",&LCStateChk);
	}
	//Ended
	else
	{
		printf("\nInvalid Plnat code [%s]",plantcode);fflush(stdout);
		//goto CLEANUP;
	}

	if(prtRlz>0)
	{
		printf("\nPart Found : %s Query Executed Succesfully",AssyNo);fflush(stdout);

		//for (cnt=0;cnt< 1;cnt++ )
		//{
			//PartOPtr=partObjs[cnt];

			//ITK_CALL(ITEM_ask_latest_rev(PartOPtr,&LatestPRev));	
			
			
			
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"object_string",&LatRevName));
			printf("\nLatRevName: %s",LatRevName);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"owning_user",&POwnerName));
			tc_strdup(POwnerName,&POwnerNameDup);
			printf("\nPOwnerName: %s",POwnerName);fflush(stdout);
			printf("\nPOwnerNameDup: %s",POwnerNameDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"release_status_list",&PartRelStatus));
			printf("\nPartRelStatus: %s",PartRelStatus);fflush(stdout);
			ITK_CALL(AOM_ask_value_string(PartOPtr,"t5_PartType",&prtType));
			printf("\nprtType: %s",prtType);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"item_id",&assy_no));
			printf("\nassy_no: %s",assy_no);fflush(stdout);
			ITK_CALL(AOM_ask_value_string(PartOPtr,"item_revision_id",&PartRevSeq));
			printf("\nPartRevSeq: %s",PartRevSeq);fflush(stdout);
			tc_strdup(prtType,&prtTypeDup);
			tc_strdup(assy_no,&assy_noDup);
			
			printf("\nassy_noDup: %s",prtTypeDup);fflush(stdout);
			printf("\nassy_noDup: %s",assy_noDup);fflush(stdout);

			
			PrintPrtDec			= NULL;
			PrintPrtNum			= NULL;
			PrintPrtPrjCode			= NULL;
			archNode			= NULL;
			ModelName			= NULL;
			ModelName	= (char *) malloc(500 * sizeof(char));
			archNode	= (char *) malloc(500 * sizeof(char));
			tc_strcpy(ModelName,"");
			tc_strcpy(archNode,"");
			
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"object_desc",&PrintPrtDec));
			
			int is=0;
			while(PrintPrtDec[is]!='\0')
			{
				if(PrintPrtDec[is]==',' || PrintPrtDec[is]=='\n')
				{
					PrintPrtDec[is]=' ';
				}
				is++;
			}
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"item_id",&PrintPrtNum));
			ITK_CALL(AOM_UIF_ask_value(PartOPtr,"t5_ProjectCode",&PrintPrtPrjCode));
			
			if (tc_strcmp(prtType,"M")==0)
			{
				archNode = subString(PrintPrtNum,4,7);
				
				if (tc_strcmp(PrintPrtPrjCode,"5445")==0)
				{
					tc_strcpy(ModelName,"Punch");
				}
				else if (tc_strcmp(PrintPrtPrjCode,"5466")==0)
				{
					tc_strcpy(ModelName,"Safarai");
				}
				else if (tc_strcmp(PrintPrtPrjCode,"5465")==0)
				{
					tc_strcpy(ModelName,"HARRIER");
				}
				else
				{
					tc_strcpy(ModelName,"Other");
				}
			}
			else
			{
				tc_strcpy(ModelName,"NA");
				tc_strcpy(archNode,"NA");
			}
			
			printf("\nPrintPrtPrjCode: %s",PrintPrtPrjCode);fflush(stdout);
			printf("\nPrintPrtNum: %s",PrintPrtNum);fflush(stdout);
			printf("\nModelName: %s",ModelName);fflush(stdout);
			printf("\narchNode: %s",archNode);fflush(stdout);
			printf("\nprtTypeDup: %s",prtTypeDup);fflush(stdout);
			
			if (tc_strcmp(archNode,"T3Z0168")==0)
			{
				//fprintf(fsuccessRptSumm,"\n%s,%s,%s,%s,%s,OK,\n",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRptSumm);
				//fprintf(fsuccessRpt,"\n%s,%s,%s,%s,%s,MASOP BOM,,,OK,,,OK,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRpt);
				if(SummFileline==0)
				{
					SummFileline++;
					fprintf(fsuccess,"No new line for summry");fflush(fsuccess);
					fprintf(fsuccess,"It will pront Once for summry");fflush(fsuccess);
					fprintf(fsuccessRptSumm,"%s,%s,%s,%s,%s,OK,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRptSumm);
				}
				else{
					
				fprintf(fsuccessRptSumm,"\n%s,%s,%s,%s,%s,OK,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRptSumm);
				}
				
				if(RptFileline==0)
				{
					fprintf(fsuccessRpt,",,,,,,,,,,");fflush(fsuccessRpt);
					fprintf(fsuccessRpt,"\n,,,,,,,,,,");fflush(fsuccessRpt);
					RptFileline++;
				}
				else
				{
				fprintf(fsuccessRpt,"\n,,,,,,,,,,");fflush(fsuccessRpt);
				fprintf(fsuccessRpt,"\n,,,,,,,,,,");fflush(fsuccessRpt);
				}
				fprintf(fsuccessRpt,"\n%s,%s,%s,%s,%s,MASOP BOM,,,,OK,,,,OK,",PrintPrtPrjCode,ModelName,archNode,PrintPrtNum,PrintPrtDec);fflush(fsuccessRpt);
				
				
				continue;
			}
			if (
				tc_strcmp(prtTypeDup,"D")==0 ||
				tc_strcmp(prtTypeDup,"DA")==0 ||
				tc_strcmp(prtTypeDup,"DC")==0 ||
				tc_strcmp(prtTypeDup,"CM")==0 ||//added 24.03.2023 Hrishikesh
				tc_strcmp(prtTypeDup,"IFD")==0 ||
				tc_strcmp(prtTypeDup,"IM")==0 ||
				tc_strcmp(prtTypeDup,"CP")==0
				)
			{
				printf("\nDesign Revision [%s] has Type %s Exiting...",assy_no,prtType);fflush(stdout);
			}

			if( tc_strcmp(prtTypeDup, "M") == 0 ||
				tc_strcmp(prtTypeDup, "SA") == 0 ||
				tc_strcmp(prtTypeDup, "SP")==0 ||
				tc_strcmp(prtTypeDup, "EM")==0 ||
				tc_strcmp(prtTypeDup, "A") == 0 ||
				tc_strcmp(prtTypeDup, "V") == 0 ||
				tc_strcmp(prtTypeDup, "T") == 0 ||
				tc_strcmp(prtTypeDup, "VC") == 0 ||
				tc_strcmp(prtTypeDup, "G") == 0 ||
				tc_strcmp(prtTypeDup, "C") == 0 ||
				tc_strcmp(prtTypeDup, "R") == 0)
			{
				printf("\nExpanding %s %s BOM...",assy_no,PartRevSeq);fflush(stdout);

				BOM_create_window (&window);		
				//CFM_find( "STDC Release and above", &rule );
				CFM_find( rule1, &rule );
				printf("\nSetting Rule1 : %s",rule1);fflush(stdout);
				//CFM_find( "STDC Released and Above", &rule );
				BOM_set_window_config_rule( window, rule );	
				
				//Setting Closure Rule Start
				printf("\nSetting ClosureRule : %s",ClosureRule);fflush(stdout);
				ITK_CALL(PIE_find_closure_rules( ClosureRule,PIE_TEAMCENTER, &n_closure_tags, &closure_tags ));
				printf("\nn_closure_tags found %d",n_closure_tags);fflush(stdout);
				if(n_closure_tags > 0)
				{
					closure_tag=closure_tags[0];
					ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
				}
				else
				{
					//goto CLEANUP;
				}
				//Setting Closure Rule End

				BOM_set_window_pack_all (window, true);
				BOM_set_window_top_line (window, null_tag, PartOPtr, null_tag, &PerentLine);
				BOM_line_ask_child_lines(PerentLine, &CntChildP, &ChildPartLine);
				printf("\nNo of Child Parts are %d\n",CntChildP);fflush(stdout);
				
				if(CntChildP>0)
				{
					printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
					bom_sub_child(ChildPartLine, CntChildP);
				}
				else if (CntChildP==0)//if (MC_DML==1)
				{
					if((tc_strcmp(prtTypeDup,"SA")==0) && (tc_strlen(PrintPrtNum)>=12))
					{
						ITK_CALL(GRM_find_relation_type("T5_RPtRel",&RwPartRel));
						ITK_CALL(AOM_ask_value_tags(PartOPtr,"T5_RPtRel",&CntChildP,&RwPartItemMst));
						printf("\nChild Raw Part Count : %d",CntChildP);fflush(stdout);
						fprintf(fsuccess,"\nChild Raw Part Count : %d",CntChildP);fflush(fsuccess);
						
						bom_sub_child(ChildPartLine, CntChildP);
					}
				}
				 ITK_CALL(BOM_close_window(window));
				printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
			
				if(start!=NULL)
				{
						start_sap = NULL;
						start_sap = cll_cad_display_bom_with_sub_items(start,assy_noDup, plantcode);

						printf("\n\nSAP DATA..............\n");fflush(stdout);
						fprintf(fsuccess,"\n\nSAP DATA..............\n");fflush(fsuccess);
						tc_strcat(output , "\n\nSAP DATA..............\n");
						display_bom(start_sap);
						printf("\n\nPLM DATA..............\n");fflush(stdout);
						fprintf(fsuccess,"\n\nPLM DATA..............\n");fflush(fsuccess);
				
						tc_strcat(output , "\n\nPLM DATA..............\n");
						display1(start,assy_noDup);
						printf("\nMismatch Report.........\n");fflush(stdout);
						fprintf(fsuccess,"\nMismatch Report.........\n");fflush(fsuccess);
						tc_strcat(output , "\nMismatch Report.........\n");
						//compare(start,start1,AssyNo);
						compare(start,start_sap,AssyNo,plantcode);
						printf("\nBOM Mismatch competeled for %s/%s BOM...",assy_no,PartRevSeq);fflush(stdout);
						printf("\n.....................................\n");fflush(stdout);
						fprintf(fsuccess,"\n.....................................\n");fflush(fsuccess);
						tc_strcat(output , "\n.....................................\n");
						
						my_free(start);
						my_free_mis(&start_sap);
						//goto CLEANUP;
					//}
				}
				else
				{
				 printf("\nNO BOM found for %s assembly in PLM",assy_noDup);fflush(stdout);
				 fprintf(fsuccess,"\nMSG RCVD:NO BOM found for %s assembly in PLM",assy_noDup);fflush(fsuccess);
				 //fprintf(fsuccessRpt,"\nMSG RCVD:NO BOM found for %s assembly in PLM",assy_noDup);fflush(fsuccessRpt);
				 //goto CLEANUP;
				}
				
			}//If Module
			else
			{
				printf("\nDesign Revision [%s] has PartType %s Exiting...",assy_no,prtType);fflush(stdout);
				//goto CLEANUP;
			}

		//}//part objects for loop
		printf("\n\n");fflush(stdout);
		printf("MY output");fflush(stdout);
		printf("output:%s",output);fflush(stdout);

	}
	else
	{
				printf("\nDesign Revision [%s] ",AssyNo);fflush(stdout);
				//goto CLEANUP;
	}
}

	ifail = ITK_exit_module(TRUE);
	if (ifail == ITK_ok)
	{
		//printf("\nTeamcenter Logout Success...");fflush(stdout);
	}
	else
	{
		EMH_ask_error_text(ifail, &cError);
		//printf("\nError is : %s", cError);fflush(stdout);
	}
}

	// CLEANUP:
		// printf("\nCLEANUP..."); fflush(stdout);
		// ITK_CALL(POM_logout(false));
		// return status;

	// EXIT:
		// printf("\nExiting...\n");
		// ITK_CALL(POM_logout(false));
		// return status;
		
		return ITK_ok;
}


RFC_HANDLE BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;
	
	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find2("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");fflush(stdout);
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");fflush(stdout);
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

struct node_mis* cll_cad_display_bom_with_sub_items(struct node *start,char *assy_noDup,char *plantcode)
{
static RFC_RC RfcRc;
RFC_HANDLE hRfc;
char s[1024];
/*char comp_part_sap[15];*/
char comp_part_sap[15];

char recstring_sap[25000];
char crecstring_sap[25000];


RC29L_STLAL eIBomAlternative;
RC29L_STLAN eIBomType;
RC29L_AENNR eIChangeNumber;
DRAW_LOEDK eIDisplayFlag;
RC29L_MATNR eIMaterial;
RC29L_WERKS eIPlant;
RC29L_REVLV eIRevisionLevel;
BICSK_DATUV eIValidFrom;
CAD_BICSK iEBomHeader;
MESSAGE_MSGTX iEMessage;
CAD_RETURN_MESSAGE_LEN iEMessageLen;
CAD_RETURN_VALUE iEReturn;
ITAB_H thBomItem = ITAB_NULL;
ITAB_H thBomSubItem = ITAB_NULL;
ITAB_H thDmsClassData = ITAB_NULL;
ITAB_H thSapFieldData = ITAB_NULL;
char xException[256];

int i_sap=0;
int j_sap=0;
int k_sap=0;
int m_sap=0;

/* table row variables */
CAD_BOM_ITEM *tBomItem;
unsigned crow;
char t;
/*char plant_code[5]={0};*/
//struct node_mis *start_sap = NULL;
//struct node_mis *p_sap = NULL;
//struct node_mis *q_sap = NULL;

char sr_no[5] = { 0 };
//char ChildPart[19] = { 0 };
char *ChildPart = NULL;
char *ChildPartVal = NULL;
char *Quantity = NULL;
char *QuantityVal = NULL;
char *BomNo = NULL;
char *BomNoVal = NULL;
//char *SAPMkby = NULL;
char *SAPMkbyVal = NULL;
char *SAPUOM = NULL;
char *SAPUOMVal = NULL;


//p_sap = NULL;
//q_sap = NULL;


    printf("\nBOM data received for :%s: ",plantcode);fflush(stdout);
    printf("\n Query BOM  for :%s: ",assy_noDup);fflush(stdout);

    SETCHAR(eIBomAlternative,"01");
    SETCHAR(eIBomType,"1");
    SETCHAR(eIChangeNumber,"");
    SETCHAR(eIDisplayFlag,"X");
    SETCHAR(eIMaterial,assy_noDup);
    SETCHAR(eIPlant,plantcode);
    SETCHAR(eIRevisionLevel,"");
    SETCHAR(eIValidFrom,"");

	//BapiLogon();

	hRfc = BapiLogon( );

    if (thBomItem==ITAB_NULL)
	{
      thBomItem = ItCreate("BOM_ITEM",sizeof(CAD_BOM_ITEM),0,0);
      if (thBomItem==ITAB_NULL)
		  rfc_error("ItCreateBOM_ITEM");
	}
    else
	{
      if (ItFree(thBomItem) != 0)
		  rfc_error("ItFreeBOM_ITEM");
	}
    if (thBomSubItem==ITAB_NULL)
	{
      thBomSubItem = ItCreate("BOM_SUB_ITEM",sizeof(CSSUBITEM),0,0);
      if (thBomSubItem==ITAB_NULL)
		  rfc_error("ItCreateBOM_SUB_ITEM");
	}
    else
	{
      if (ItFree(thBomSubItem) != 0)
		  rfc_error("ItFreeBOM_SUB_ITEM");
	}
    if (thDmsClassData==ITAB_NULL)
	{
      thDmsClassData = ItCreate("DMS_CLASS_DATA",sizeof(CLS_CHARAC),0,0);
      if (thDmsClassData==ITAB_NULL)
		  rfc_error("ItCreateDMS_CLASS_DATA");
	}
    else
	{
      if (ItFree(thDmsClassData) != 0)
		  rfc_error("ItFreeDMS_CLASS_DATA");
	}
    if (thSapFieldData==ITAB_NULL)
	{
      thSapFieldData = ItCreate("SAP_FIELD_DATA",sizeof(RFCDMSDATA),0,0);
      if (thSapFieldData==ITAB_NULL)
		  rfc_error("ItCreateSAP_FIELD_DATA");
	}
    else
	{
      if (ItFree(thSapFieldData) != 0)
		  rfc_error("ItFreeSAP_FIELD_DATA");
	}



      /* call RFC function */
	RfcRc = cad_display_bom_with_sub_items(hRfc,&eIBomAlternative,&eIBomType,&eIChangeNumber,&eIDisplayFlag,&eIMaterial,&eIPlant,&eIRevisionLevel,&eIValidFrom,&iEBomHeader,&iEMessage,&iEMessageLen,&iEReturn,thBomItem,thBomSubItem,thDmsClassData,thSapFieldData,xException);
	switch (RfcRc)
	{

	case RFC_OK :
				  //memset(crecstring_sap,0,sizeof(crecstring_sap));
				  //memset(recstring_sap,0,sizeof(recstring_sap));
				  //strcpy(recstring_sap,"");
				  sprintf(s,"%d lines",ItFill(thBomItem));
				 // printf("\nNo of row fetched :%s:",s); fflush(stdout);
				  printf("\nNo of row fetched :[%s] for partnumber[%s]",s,assy_noDup); fflush(stdout);
				  //t=0;

				  for (crow = 1;crow <= ItFill(thBomItem); crow++)
				  {
					tBomItem = ItGetLine(thBomItem,crow);
					if (tBomItem == NULL)
						rfc_error("ItGetLineBOM_ITEM");
					
					tc_strcpy(sr_no,"");
					
					ChildPart = (char *) MEM_alloc(19 * sizeof(char));
					ChildPartVal = (char *) MEM_alloc(19 * sizeof(char));
					tc_strcpy(ChildPart,"");
					tc_strcpy(ChildPartVal,"");

					Quantity = (char *) MEM_alloc(19 * sizeof(char));
					QuantityVal = (char *) MEM_alloc(19 * sizeof(char));
					tc_strcpy(Quantity,"");
					tc_strcpy(QuantityVal,"");

					BomNo = (char *) MEM_alloc(41 * sizeof(char));
					BomNoVal = (char *) MEM_alloc(41 * sizeof(char));
					
					tc_strcpy(BomNo,"");
					tc_strcpy(BomNoVal,"");
					
					//SAPMkby = (char *) MEM_alloc(41 * sizeof(char));
					SAPMkbyVal = (char *) MEM_alloc(41 * sizeof(char));
					
					//tc_strcpy(SAPMkby,"");
					//tc_strcpy(SAPMkbyVal,"");
					
					SAPUOM = (char *) MEM_alloc(41 * sizeof(char));
					SAPUOMVal = (char *) MEM_alloc(41 * sizeof(char));
					
					tc_strcpy(SAPUOM,"");
					tc_strcpy(SAPUOMVal,"");

					GETCHAR(tBomItem->Posnr,sr_no);

					GETCHAR(tBomItem->Idnrk,ChildPart);
					//tc_strcpy(ChildPartVal , (char *)stripTrailingBlanks(ChildPart));
					//tc_strcpy(ChildPartVal , (char *)stripBlanks(ChildPart));
					ChildPartVal =  (char *)stripBlanks(ChildPart);
					//printf("\nChildPartVal:[%s]",ChildPartVal);
					
					GETCHAR(tBomItem->Menge,Quantity);
					QuantityVal =  (char *)stripBlanks(Quantity);
					//printf("\tQuantityVal:[%s]",QuantityVal);

					GETCHAR(tBomItem->Potx1,BomNo);
					BomNoVal =  (char *)stripBlanks(BomNo);
					//printf("\tBomNoVal:[%s]",BomNoVal);
					
					//GETCHAR(tBomItem->Potx1,SAPMkby);
					//SAPMkbyVal =  (char *)stripBlanks(SAPMkby);
					
					GETCHAR(tBomItem->Meins,SAPUOM);
					SAPUOMVal =  (char *)stripBlanks(SAPUOM);
					//SAPpstat = (char *)malloc(500 * sizeof(char));
					//MRPpstat = (char *)malloc(500 * sizeof(char));
					sap_proc_type = (char *)malloc(20 * sizeof(char));
					sap_proc_typeVal = (char *)malloc(20 * sizeof(char));
					sap_spproc_type = (char *)malloc(20 * sizeof(char));
					sap_spproc_typeVal = (char *)malloc(20 * sizeof(char));
					SAPMkbyVal = (char *)malloc(20 * sizeof(char));
					tc_strcpy(sap_proc_type,"");
					tc_strcpy(sap_proc_typeVal,"");
					tc_strcpy(sap_spproc_type,"");
					tc_strcpy(sap_spproc_typeVal,"");
					
					GetCSPstat(ChildPartVal,RfcRc);
					trimString(sap_proc_type);
					trimString(sap_spproc_type);
					tc_strcpy(SAPMkbyVal,"");
					tc_strcpy(SAPMkbyVal,sap_proc_typeVal);
					tc_strcat(SAPMkbyVal,sap_spproc_typeVal);
					printf("\n SAPpstat:[%s][%s][%s]SAPMkbyVal[%s]",ChildPartVal,sap_proc_typeVal,sap_spproc_typeVal,SAPMkbyVal) ; fflush(stdout);
					int ret=0;
					if(p_sap == NULL)
					{
						printf("\n calling for create SAP node 11[%s]",ChildPartVal) ; fflush(stdout);
						p_sap = createnode_mis(sr_no,ChildPartVal,QuantityVal,BomNoVal,SAPMkbyVal,SAPUOMVal);
						start_sap = p_sap;
					}
					else
					{
						
						printf("\n search");fflush(stdout);
						ret = searchSAP(start_sap,ChildPartVal,QuantityVal);
						printf("\n search1");fflush(stdout);
						if(ret==1)
							{
								printf("\n else of p_sap") ; fflush(stdout);
								q_sap = start_sap;
								while(q_sap->next != NULL)
								{
									 q_sap = q_sap->next;
								}
								printf("\n calling for create SAP node 22[%s]",ChildPartVal) ; fflush(stdout);
								q_sap->next = createnode_mis(sr_no,ChildPartVal,QuantityVal,BomNoVal,SAPMkbyVal,SAPUOMVal);
							}

					}
					//if((tc_strcmp(SAPMkbyVal,"F")==0) ||(tc_strcmp(SAPMkbyVal,"F18")==0))
					//{
						printf("\n Stop at F [%s]",SAPMkbyVal) ; fflush(stdout);
					//}//
					//else
					//{
					//cll_cad_display_bom_with_sub_items(ChildPartVal,plantcode);
					//}
					int retPlm=0;
					printf("\n start calling funsearchSAPExp " ) ; fflush(stdout);
					//struct node *pp=NULL;
					//for(pp = start; pp != NULL; pp = pp -> next)
					//{
					//printf("\n\t %s %-15s %7.3f %3s %3s %3s %s",pp -> sr_no, pp -> part, pp -> qty,pp -> uq ,pp -> mat_prov_ind ,pp -> tempcsrel,pp -> make_buy_indDup);
					//}
					retPlm = searchSAPExp(start,ChildPartVal);
					printf("\n end calling funsearchSAPExp") ; fflush(stdout);
					if(retPlm==0)
					{
						printf("\n found in PLM Link List with CS F/F18") ; fflush(stdout);
						
					}
					else
					{
						
						printf("\n [%s]Not found in PLM Link List with CS F/F18",ChildPartVal) ; fflush(stdout);
						cll_cad_display_bom_with_sub_items(start,ChildPartVal,plantcode);
					}

				  }
				  //free(ChildPart);
				  //free(ChildPartVal);

				  /*for(i_sap=0;i_sap<strlen(recstring_sap);i_sap=i_sap+18)
				  {
					m_sap=i_sap;

					for(j_sap=0;j_sap<14;j_sap++)
					{
						crecstring_sap[k_sap]=recstring_sap[m_sap];
						k_sap++;
						m_sap++;
					}
				 }*/

				//display_bom(start_sap);

				  sprintf(s,"\nchild parts fetched from sap : %d ",ItFill(thBomItem ));

			         break;

        case RFC_EXCEPTION :
			         /* exception raised */
					 printf("exception"); fflush(stdout);
			         break;
        case RFC_SYS_EXCEPTION :
			         rfc_error("system exception raised");

        case RFC_FAILURE :
					 rfc_error("failure");

        default :
					 rfc_error("other failure");

      }
    /* delete tables */
    if (ItDelete(thBomItem) != 0)
      rfc_error("ItDelete BOM_ITEM");
    if (ItDelete(thBomSubItem) != 0)
      rfc_error("ItDelete BOM_SUB_ITEM");
    if (ItDelete(thDmsClassData) != 0)
      rfc_error("ItDelete DMS_CLASS_DATA");
    if (ItDelete(thSapFieldData) != 0)
      rfc_error("ItDelete SAP_FIELD_DATA");

	RfcClose (hRfc);
	return start_sap;
}

RFC_RC cad_display_bom_with_sub_items(RFC_HANDLE hRfc,RC29L_STLAL *eIBomAlternative,RC29L_STLAN *eIBomType,RC29L_AENNR *eIChangeNumber,DRAW_LOEDK *eIDisplayFlag,RC29L_MATNR *eIMaterial,RC29L_WERKS *eIPlant,RC29L_REVLV *eIRevisionLevel,BICSK_DATUV *eIValidFrom,CAD_BICSK *iEBomHeader,MESSAGE_MSGTX *iEMessage,CAD_RETURN_MESSAGE_LEN *iEMessageLen,CAD_RETURN_VALUE *iEReturn,ITAB_H thBomItem,ITAB_H thBomSubItem,ITAB_H thDmsClassData,ITAB_H thSapFieldData,char *xException)
{

  RFC_PARAMETER Exporting[9];
  RFC_PARAMETER Importing[5];
  RFC_TABLE Tables[5];
  RFC_RC RfcRc;
  char *RfcException = NULL;

  Exporting[0].name = "I_BOM_ALTERNATIVE";
  Exporting[0].nlen = 17;
  Exporting[0].type = TYPC;
  Exporting[0].leng = sizeof(RC29L_STLAL);
  Exporting[0].addr = eIBomAlternative;

  Exporting[1].name = "I_BOM_TYPE";
  Exporting[1].nlen = 10;
  Exporting[1].type = TYPC;
  Exporting[1].leng = sizeof(RC29L_STLAN);
  Exporting[1].addr = eIBomType;

  Exporting[2].name = "I_CHANGE_NUMBER";
  Exporting[2].nlen = 15;
  Exporting[2].type = TYPC;
  Exporting[2].leng = sizeof(RC29L_AENNR);
  Exporting[2].addr = eIChangeNumber;

  Exporting[3].name = "I_DISPLAY_FLAG";
  Exporting[3].nlen = 14;
  Exporting[3].type = TYPC;
  Exporting[3].leng = sizeof(DRAW_LOEDK);
  Exporting[3].addr = eIDisplayFlag;

  Exporting[4].name = "I_MATERIAL";
  Exporting[4].nlen = 10;
  Exporting[4].type = TYPC;
  Exporting[4].leng = sizeof(RC29L_MATNR);
  Exporting[4].addr = eIMaterial;

  Exporting[5].name = "I_PLANT";
  Exporting[5].nlen = 7;
  Exporting[5].type = TYPC;
  Exporting[5].leng = sizeof(RC29L_WERKS);
  Exporting[5].addr = eIPlant;

  Exporting[6].name = "I_REVISION_LEVEL";
  Exporting[6].nlen = 16;
  Exporting[6].type = TYPC;
  Exporting[6].leng = sizeof(RC29L_REVLV);
  Exporting[6].addr = eIRevisionLevel;

  Exporting[7].name = "I_VALID_FROM";
  Exporting[7].nlen = 12;
  Exporting[7].type = TYPC;
  Exporting[7].leng = sizeof(BICSK_DATUV);
  Exporting[7].addr = eIValidFrom;

  Exporting[8].name = NULL;

  Tables[0].name     = "BOM_ITEM";
  Tables[0].nlen     = 8;
  Tables[0].type     = handleOfCAD_BOM_ITEM;
  Tables[0].ithandle = thBomItem;

  Tables[1].name     = "BOM_SUB_ITEM";
  Tables[1].nlen     = 12;
  Tables[1].type     = handleOfCSSUBITEM;
  Tables[1].ithandle = thBomSubItem;

  Tables[2].name     = "DMS_CLASS_DATA";
  Tables[2].nlen     = 14;
  Tables[2].type     = handleOfCLS_CHARAC;
  Tables[2].ithandle = thDmsClassData;

  Tables[3].name     = "SAP_FIELD_DATA";
  Tables[3].nlen     = 14;
  Tables[3].type     = handleOfRFCDMSDATA;
  Tables[3].ithandle = thSapFieldData;

  Tables[4].name = NULL;

  RfcRc = RfcCall(hRfc,"CAD_DISPLAY_BOM_WITH_SUB_ITEMS",Exporting,Tables);

  switch (RfcRc)
  {
    case RFC_OK :

      Importing[0].name = "E_BOM_HEADER";
      Importing[0].nlen = 12;
      Importing[0].type = handleOfCAD_BICSK;
      Importing[0].leng = sizeof(CAD_BICSK);
      Importing[0].addr = iEBomHeader;

      Importing[1].name = "E_MESSAGE";
      Importing[1].nlen = 9;
      Importing[1].type = TYPC;
      Importing[1].leng = sizeof(MESSAGE_MSGTX);
      Importing[1].addr = iEMessage;

      Importing[2].name = "E_MESSAGE_LEN";
      Importing[2].nlen = 13;
      Importing[2].type = TYPC;
      Importing[2].leng = sizeof(CAD_RETURN_MESSAGE_LEN);
      Importing[2].addr = iEMessageLen;

      Importing[3].name = "E_RETURN";

      Importing[3].nlen = 8;
      Importing[3].type = TYPC;
      Importing[3].leng = sizeof(CAD_RETURN_VALUE);
      Importing[3].addr = iEReturn;

      Importing[4].name = NULL;

      RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
      switch (RfcRc)
      {
        case RFC_SYS_EXCEPTION :
				strcpy(xException,RfcException);
				break;
        case RFC_EXCEPTION :
				strcpy(xException,RfcException);
				break;
		default:;
       }

		break;
	default :
		printf("Error occured");fflush(stdout);
  }

  return RfcRc;
}
RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException)
{
	RFC_RC RfcRc;
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[1];
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfMATNR;
	Exporting[0].leng = sizeof(MATNR);
	Exporting[0].addr = eMatnr;

	Exporting[1].name = "PLANT";
	Exporting[1].nlen = 5;
	Exporting[1].type = handleOfWERKS_D;
	Exporting[1].leng = sizeof(WERKS_D);
	Exporting[1].addr = eWerks;

	Exporting[2].name = NULL;

	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_MATERIAL_GETALL",Exporting,Tables);

	switch (RfcRc)
	{
	  	case RFC_OK :

			Importing[0].name = "CLIENTDATA";
			Importing[0].nlen = 10;
			Importing[0].type = handleOfCLIENTDATA;
			Importing[0].leng = sizeof(CLIENTDATA);
			Importing[0].addr = iView;

			Importing[1].name = "PLANTDATA";
			Importing[1].nlen = 9;
			Importing[1].type = handleOfPLANTDATA;
			Importing[1].leng = sizeof(PLANTDATA);
			Importing[1].addr = iMrpView;

			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
	  			case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
				break;
				default:;
			}
		default:;
	}
	return RfcRc;
}
int GetCSPstat(char cMaterial[15],RFC_RC RfcRc)
{
	char xException[256];
	RFC_HANDLE hRfc;
	//RFC_RC RfcRc;
	MATNR eMatnr;
	WERKS_D eWerks;
	PLANTDATA iMrpView;
	CLIENTDATA iView;

	//char *plantcode=NULL;
	tc_strdup(plantcode,&plantcode);

	printf("\nProcessing GetCSPstat:[%s,%s]",cMaterial,plantcode);

	hRfc = BapiLogon();

	//tc_strcpy(SAPpstat,"");
	//tc_strcpy(MRPpstat,"");

	SETCHAR(eMatnr.Matnr,cMaterial);
	//SETCHAR(eMatnr.Matnr,part_noDup);
	SETCHAR(eWerks.WerksD,plantcode);

	RfcRc = export_CSpastat(hRfc
							,&eMatnr
							,&eWerks
							,&iMrpView
							,&iView
							,xException);

	switch (RfcRc)
	{
		case RFC_OK:
		
			GETCHAR(iMrpView.PROC_TYPE, sap_proc_type);		//OUTS("PROC_TYPE",10,30,sap_proc_type);
			sap_proc_typeVal =  (char *)stripBlanks(sap_proc_type);
			GETCHAR(iMrpView.SPPROCTYPE, sap_spproc_type);	//OUTS("SPPROCTYPE",10,30,sap_spproc_type);
			sap_spproc_typeVal =  (char *)stripBlanks(sap_spproc_type);
			//printf("\n In RFC_OK case...\n");	fflush(stdout);
			//GETCHAR(iView.MAINT_STAT, SAPpstat);
			//nlsStrTrimTrailWhiteSpace(SAPpstat);
			//nlsStrTrimLeadWhiteSpace(SAPpstat);
			//SAPpstat[tc_strlen(SAPpstat)] = '\0';

			//GETCHAR(iMrpView.MAINT_STAT, MRPpstat);
			//nlsStrTrimTrailWhiteSpace(MRPpstat);
			//nlsStrTrimLeadWhiteSpace(MRPpstat);
			//MRPpstat[tc_strlen(MRPpstat)] = '\0';

		break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception : %s",xException);
			exit(0);
		break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			exit(0);
		break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			exit(0);
		break;
		default:
			printf("\nOther Failure!");
			exit(0);
	}

	RfcClose(hRfc);
	return 0;
}