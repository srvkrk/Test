/**************************************************************************
* Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*	Client code	: GSA_Parameter_Check.c
*	Modification History :
*	S.No    Date        CR No       Modified By                Modification Notes
************************************************************************/
#define _CLMAIN_DEFNS
#define _CLMAIN_DEFNS
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
;

main(int argc, char *argv[])
{
	int stat=0;
	int j=0;
	int jiik=0;
	int jii=0;
	int ji=0;
	int jj=0;
	int conflag=0;
	int DocumentCounter=0;
	int AttachmentCounter=0;
	int OUTsideContainerFlag=0;
	int OUTsideParameterFlag=0;
	int GrpConFlag=0;
	FILE  *fp  =  NULL; 
	FILE  *fp1  =  NULL; 
	char fileRead[500];		
	string			LoginS          =  "super user" ;
    string			PasswordS       =  "abc123" ;
	string			InpFile			= NULL;
	string			sECUType			= NULL;
	string			tprojectcodeDup			= NULL;
	string			tprojectcode			= NULL;
	string			sECUChildpartDup			= NULL;
	string			sECUChildpart			= NULL;
	string			sECUSWTypeDup			= NULL;
	string			thisRelPatDup			= NULL;
	string			thisRelPatDupS			= NULL;
	string			sECUSWType			= NULL;
	string			VehPartnumSDup			= NULL;
	string			VehPartnumS			= NULL;
	string			sECUTypeDup			= NULL;
	string			sGECUTypeDup			= NULL;
	string			sGECUType			= NULL;
	string			sGECUPrtTypDup			= NULL;
	string			sGECUPrtTyp			= NULL;
	string			sGECUChildpartDup			= NULL;
	string			sGECUChildpart			= NULL;
	string			PartNo			= NULL;
	string			lineReadDup		= NULL;
	string			lineRead		= NULL;
	string			lineRead1		= NULL;
	string			PartnumSDup		= NULL;
	string			PartnumS		= NULL;
	string			fpname			= NULL;
	string			sPartSeqDup		= NULL;
	string			sPartSeq		= NULL;
	string			sPartRevDup		= NULL;
	string			sPartRev		= NULL;
	string			VehChildDesgDup		= NULL;
	string			VehChildDesg		= NULL;
	string			VehChldPartnumSDup		= NULL;
	string			VehChldPartnumS		= NULL;
	string			TrgWeight		= NULL;
	string			TempCatS		= NULL;
	string			sECUPrtTypDup		= NULL;
	string			sECUPrtTyp		= NULL;
	string			sGGECUChildpartDup		= NULL;
	string			sGGECUChildpart		= NULL;
	string			sGECUSWTypeDup		= NULL;
	string			sGECUSWType		= NULL;
	string			docobjst		= NULL;
	string			ParaString		= NULL;
	string			sGGECUPrtTypDup		= NULL;
	string			sGGECUPrtTyp		= NULL;
	string			ContString		= NULL;
	string			sGGECUSWTypeDup		= NULL;
	string			sGGECUSWType		= NULL;
	string			sGGECUTypeDup		= NULL;
	string			sGGECUType		= NULL;
	SqlPtr			sql				= NULL;
    ObjectPtr		GrppECUChildPartP			= NULL;
    ObjectPtr		GrpECUChildPartP			= NULL;
    ObjectPtr		DI_Ptr			= NULL;
    ObjectPtr		BI_Ptr			= NULL;
    ObjectPtr		VehChildPartP			= NULL;
    ObjectPtr		context1			= NULL;
    ObjectPtr		VehPartNoP			= NULL;
    ObjectPtr		genCntXO1			= NULL;
    ObjectPtr		ECUChildPartP			= NULL;
    ObjectPtr		PartNoP			= NULL;
	SetOfObjects    PrtObjs			= NULL;
		SetOfObjects	PrtDocSO1				= NULL;
		SetOfObjects	PrtDocRelSO1				= NULL;
	SetOfObjects	LatestDocSO1				= NULL;
	SetOfObjects	LatestDocRelSO1				= NULL;
	SetOfObjects	AttachedDI				= NULL;
	SetOfObjects    ECUChldPrtObjsRel			= NULL;
	SetOfObjects    ECUChldPrtObjs			= NULL;
	SetOfObjects    VehChldPrtObjs			= NULL;
	SetOfObjects    GrpECUChldPrtObjsRel			= NULL;
	SetOfObjects    ChldPrtObjs			= NULL;
	SetOfObjects    GrppECUChldPrtObjs			= NULL;
	SetOfObjects    GrppECUChldPrtObjsRel			= NULL;
	SetOfObjects    VehChldPrtRelObjs			= NULL;
	SetOfObjects    GrpECUChldPrtObjs			= NULL;
	SetOfObjects    ChldPrtRelObjs			= NULL;
	SetOfStrings	dbScp			= NULL;
	SetOfStrings    ReportSS		= NULL;
	SetOfStrings    ssTitle			= NULL;
	ReportSS		= setCreate(2000);
	ssTitle			= setCreate(300);
	int Rflag=0;
	int jjk=0;
	t5MethodInitWMD("DML_to_Attaches.c");

	//INPUT ARGU ITEM.........
  	LoginS		=nlsStrAlloc(20);
	fpname		=nlsStrAlloc(100); 
	TempCatS	=nlsStrAlloc(2000);  
	PasswordS	=nlsStrAlloc(20);
	InpFile		=nlsStrAlloc(20);
	InpFile=argv[1];
	printf("\n Arg1:[%s]",InpFile);
	
	printf("\n !!!!!!!!!!!!Starting here!!!!!!!! \n");
	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2(argc,&argv,NULL));	
	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());
	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));
	t5CheckDstat(clLogin2(LoginS,PasswordS,&stat));
	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s, %s \n", LoginS,PasswordS);
		goto EXIT;
	}
	//SET DATABASE
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (ji=0;ji<setSize(dbScp) ; ji++)
	{
		docobjst=low_set_get(dbScp,ji);
		printf("\nDB pref check before... :%s\n",docobjst);fflush(stdout);
	}

	set_add_str_unique(dbScp, "supprod");
	set_add_str_unique(dbScp, "suhprod");
	set_add_str_unique(dbScp, "sulprod");
	set_add_str_unique(dbScp, "sujprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (jj=0;jj<low_set_size(dbScp) ; jj++)
	{
		docobjst=low_set_get(dbScp,jj);
		printf("\nDB pref check after... :%s\n",docobjst);fflush(stdout);
	}

	//For reading Partnumber from CSV file			
	printf("Inside loop for read Input file........\n");fflush(stdout);
	fp=fopen(InpFile,"r");
	if(fp==NULL)
	{
		printf("unable  open  File.\n ");fflush(stdout);
		goto  CLEANUP;
	}
	//file creation start
	nlsStrCpy(fpname,"GSA_Parameter_Check.csv");
	fp1 = fopen(fpname,"w");
	if(fp1) fprintf(fp1,"Vehicle No, Revision, Sequence,Veh Project Code, 16R TPL number, GSA Container Availability, ECU Type,GSA Container Numbers, Hex File Name,");
	if(fp1) fprintf(fp1," \n");

	//File creation end
	while(fgets(fileRead,500,fp)!=NULL)
	{  		
		if(!nlsIsStrNull(fileRead))
		{
			if(PartNo)	PartNo	=NULL;
			if(TrgWeight)	TrgWeight	=NULL;
			//if(Seq)	Seq	=NULL;
			lineReadDup = nlsStrAlloc(500);
			nlsStrCpy(lineReadDup,fileRead);
			lineRead1 =low_strssra(lineReadDup,",,",", ,");		
			lineRead  =low_strssra(lineRead1,",,",", ,");
			PartNo =strtok(lineRead,",");
			//TrgWeight   =strtok(NULL,",");
			//Seq   =strtok(NULL,",");
			if(PartNo)nlsStrTrimTrailWhiteSpace(PartNo);

			printf("Part number..:: %s\n",PartNo);fflush(stdout);
			//printf("TrgWeight ...:: %s\n",TrgWeight);fflush(stdout);
			//printf("Seq number...:: %s\n",Seq);fflush(stdout);
		}					
		//Querying part number
		PrtObjs = NULL;
		if (dstat = oiSqlCreateSelect(&sql)) goto EXIT;
		if(dstat  = oiSqlWhereEQ(sql,PartNumberAttr,PartNo)) goto EXIT;
		/*if(dstat  = oiSqlWhereAND(sql)) goto CLEANUP;
		if(dstat  = oiSqlWhereBegParen(sql)) goto CLEANUP;
		if(dstat  = oiSqlWhereNE(sql,t5PartStatusAttr,"NA")) goto EXIT;
		if(dstat  = oiSqlWhereAND(sql)) goto CLEANUP;
		if(dstat  = oiSqlWhereNE(sql,t5PartStatusAttr,"DVPT")) goto EXIT;
		if(dstat  = oiSqlWhereEndParen(sql)) goto CLEANUP;*/
		if(dstat  = oiSqlWhereAND(sql)) goto CLEANUP;
		if(dstat  = oiSqlWhereLike(sql,OwnerNameAttr,"%Release Vault%")) goto EXIT;
		if(dstat = oiSqlDescOrder(sql,CreationDateAttr))goto EXIT;
		//if(dstat = oiSqlAscOrder(sql,CreationDateAttr))goto EXIT;
		if(dstat  = QueryDbObject("Part",sql,0,TRUE,SC_SCOPE_OF_SESSION,&PrtObjs,mfail)) goto EXIT;
		printf ("\n GM: Rel PrtObjs :[%d]\n", setSize(PrtObjs));fflush(stdout);
		if(setSize(PrtObjs)>0)
		{
			if(ParaString)			ParaString		=NULL;
			if(ContString)			ContString		=NULL;
			ContString = nlsStrAlloc(5000);
			ParaString = nlsStrAlloc(5000);
			nlsStrCpy(ContString,"");
			//nlsStrCpy(ContString,"Container:");
			nlsStrCpy(ParaString,"");
			//nlsStrCpy(ParaString,"Parameter:");
			for (jjk=0;jjk<low_set_size(PrtObjs) ; jjk++)
			{
				if(PartnumS)			PartnumS		=NULL;
				if(PartnumSDup)			PartnumSDup		=NULL;
				VehPartNoP=setGet(PrtObjs,jjk);
				//printf("\n...to get vehicle number... \n ");fflush(stdout);
				if(VehPartnumSDup)	VehPartnumSDup		=NULL;
				if(VehPartnumS)		VehPartnumS		=NULL;
				if(sPartRev)		sPartRev	=NULL;
				if(sPartRevDup)		sPartRevDup	=NULL;
				if(sPartSeqDup)		sPartSeqDup	=NULL;
				if(sPartSeq)		sPartSeq	=NULL;
				if(tprojectcodeDup)		tprojectcodeDup	=NULL;
				if(tprojectcode)		tprojectcode	=NULL;
				if (dstat = objGetAttribute(VehPartNoP,PartNumberAttr,&VehPartnumSDup)) goto CLEANUP;
				if(!nlsIsStrNull(VehPartnumSDup)) VehPartnumS = nlsStrDup(VehPartnumSDup);

				if(dstat = objGetAttribute(VehPartNoP,RevisionAttr,&sPartRevDup))   goto EXIT;
				if(!nlsIsStrNull(sPartRevDup))    sPartRev = nlsStrDup (sPartRevDup);

				if(dstat = objGetAttribute(VehPartNoP,SequenceAttr,&sPartSeqDup))   goto EXIT;
				if(!nlsIsStrNull(sPartSeqDup))   sPartSeq = nlsStrDup (sPartSeqDup);

				if(dstat = objGetAttribute(VehPartNoP, ProjectNameAttr, &tprojectcode)) goto EXIT;
				if(tprojectcode) tprojectcodeDup = nlsStrDup(tprojectcode);
				printf("\n VehPart: [%s] PartRev [%s] sPartSeq[%s] tprojectcodeDup:[%s]\n",VehPartnumS,sPartRev,sPartSeq,tprojectcodeDup);fflush(stdout);
				//context to get part revision
				t5CheckMfail(IntSetUpContext(objClass(VehPartNoP),VehPartNoP,&genCntXO1,mfail)) ;
				t5CheckMfail(GetCfgCtxtObjFromCtxt(DSesGnCClass,genCntXO1,&context1,mfail));
				t5CheckDstat(objSetAttribute(context1,CfgItemIdAttr,"GlobalCtxt"));
				t5CheckDstat(objSetAttribute(context1,PsmExpIncludeZeroQtyAttr,"+"));
				t5CheckDstat(SetNavigateViewPref(context1,TRUE,"EAS","ERC",mfail));
				t5CheckDstat(objNameValueSet(context1,LCStateListAttr,"LcsSTDRlzd","+"));
				t5CheckDstat(objNameValueSet(context1,LCStateListAttr,"LcsSTDWrkg","+"));
				t5CheckDstat(objNameValueSet(context1,LCStateListAttr,"LcsAplRlzd","+"));
				t5CheckDstat(objNameValueSet(context1,LCStateListAttr,"LcsAPLWrkg","+"));
				t5CheckDstat(objNameValueSet(context1,LCStateListAttr,"LcsErcRlzd","+"));
				t5CheckDstat(objNameValueSet(context1,LCStateListAttr,"LcsReview","-"));
				t5CheckDstat(objNameValueSet(context1,LCStateListAttr,"LcsWorking","-"));
				t5CheckDstat(objSetObject(genCntXO1,ConfigCtxtBlobAttr,context1));
				t5CheckMfail(SetExpOnRevInCtxt(DSesGnCClass,genCntXO1,"PscLastRev",mfail));
				printf("\n PO03:XO:Context genCntXO1.");fflush(stdout);
				//Exppand veh to BOM to get 16R TPL.
				if(VehChldPrtObjs) VehChldPrtObjs=NULL;
				if (dstat = ExpandRelationWithCtxt("AsRevRev",VehPartNoP,"PartsInAssembly",genCntXO1,SC_SCOPE_OF_SESSION,NULL,&VehChldPrtObjs,&VehChldPrtRelObjs,mfail))	goto EXIT;
				printf("\n PO03:XO: child count:[%d].",setSize(VehChldPrtObjs));fflush(stdout);
				if(setSize(VehChldPrtObjs)>0)
				{
					Rflag=0;
					for (j=0;j<low_set_size(VehChldPrtObjs) ; j++)
					{
						printf("\n...to get vehicle number... \n ");fflush(stdout);
						if(VehChldPartnumSDup)	VehChldPartnumSDup		=NULL;
						if(VehChldPartnumS)		VehChldPartnumS		=NULL;
						if(VehChildDesgDup)		VehChildDesgDup		=NULL;
						if(VehChildDesg)		VehChildDesg		=NULL;
						VehChildPartP=setGet(VehChldPrtObjs,j);
						if (dstat = objGetAttribute(VehChildPartP,PartNumberAttr,&VehChldPartnumSDup)) goto CLEANUP;
						if(!nlsIsStrNull(VehChldPartnumSDup)) VehChldPartnumS = nlsStrDup(VehChldPartnumSDup);

						if (dstat = objGetAttribute(VehChildPartP,t5DesignGroupAttr,&VehChildDesgDup)) goto CLEANUP;
						if(!nlsIsStrNull(VehChildDesgDup)) VehChildDesg = nlsStrDup(VehChildDesgDup);
						printf("\n Veh child Part: [%s]  VehChildDesg :[%s]\n",VehChldPartnumS,VehChildDesg);fflush(stdout);
						if (nlsStrCmp(VehChildDesg,"16")==0)
						{
							Rflag=1;
							//Expand till first level BOM and 2nd level if group id.
							if(ECUChldPrtObjs) ECUChldPrtObjs=NULL;
							if (dstat = ExpandRelationWithCtxt("AsRevRev",VehChildPartP,"PartsInAssembly",genCntXO1,SC_SCOPE_OF_SESSION,NULL,&ECUChldPrtObjs,&ECUChldPrtObjsRel,mfail))	goto EXIT;
							printf("\n PO03:child count:[%d].",setSize(ECUChldPrtObjs));fflush(stdout);
							if(setSize(ECUChldPrtObjs)>0)
							{
								GrpConFlag =0;
								OUTsideParameterFlag=0;
								OUTsideContainerFlag=0;
								conflag =0;
								for (ji=0;ji<low_set_size(ECUChldPrtObjs) ; ji++)
								{
									printf("\n...to get vehicle number... \n ");fflush(stdout);
									if(sECUChildpartDup)	sECUChildpartDup		=NULL;
									if(sECUChildpart)		sECUChildpart		=NULL;
									if(sECUSWTypeDup)		sECUSWTypeDup		=NULL;
									if(sECUSWType)		sECUSWType		=NULL;
									if(sECUTypeDup)		sECUTypeDup		=NULL;
									if(sECUType)		sECUType		=NULL;
									if(sECUPrtTypDup)		sECUPrtTypDup		=NULL;
									if(sECUPrtTyp)		sECUPrtTyp		=NULL;
									ECUChildPartP=setGet(ECUChldPrtObjs,ji);
									if (dstat = objGetAttribute(ECUChildPartP,PartNumberAttr,&sECUChildpartDup)) goto CLEANUP;
									if(!nlsIsStrNull(sECUChildpartDup)) sECUChildpart = nlsStrDup(sECUChildpartDup);

									if (dstat = objGetAttribute(ECUChildPartP,PartTypeAttr,&sECUPrtTyp)) goto EXIT;
									if(!nlsIsStrNull(sECUPrtTyp)) sECUPrtTypDup = nlsStrDup(sECUPrtTyp);

									if (dstat = objGetAttribute(ECUChildPartP,t5ECUTypeAttr,&sECUTypeDup)) goto CLEANUP;
									if(!nlsIsStrNull(sECUTypeDup)) sECUType = nlsStrDup(sECUTypeDup);
									printf("\n sECUChildpart: [%s]  sECUType :[%s]  Part Type:[%s]\n",sECUChildpart,sECUType,sECUPrtTypDup);fflush(stdout);
									if ((nlsStrCmp(sECUType,"Gear Shift Advisor")==0) ||(nlsStrCmp(sECUType,"GSA")==0))
									{
										if(nlsStrCmp(sECUPrtTypDup,"G")==0)
										{
											//Expand till first level BOM and 2nd level if group id.
											if(GrpECUChldPrtObjs) GrpECUChldPrtObjs=NULL;
											if (dstat = ExpandRelationWithCtxt("AsRevRev",ECUChildPartP,"PartsInAssembly",genCntXO1,SC_SCOPE_OF_SESSION,NULL,&GrpECUChldPrtObjs,&GrpECUChldPrtObjsRel,mfail))	goto EXIT;
											printf("\n Gchild count:[%d].",setSize(GrpECUChldPrtObjs));fflush(stdout);
											if(setSize(GrpECUChldPrtObjs)>0)
											{
												for (jii=0;jii<low_set_size(GrpECUChldPrtObjs) ; jii++)
												{
													printf("\n...to get vehicle number... \n ");fflush(stdout);
													if(sGECUChildpartDup)	sGECUChildpartDup		=NULL;
													if(sGECUChildpart)		sGECUChildpart		=NULL;
													if(sGECUPrtTypDup)		sGECUPrtTypDup		=NULL;
													if(sGECUPrtTyp)		sGECUPrtTyp		=NULL;
													if(sGECUTypeDup)		sGECUTypeDup		=NULL;
													if(sGECUType)		sGECUType		=NULL;
													if(sGECUSWTypeDup)		sGECUSWTypeDup		=NULL;
													if(sGECUSWType)		sGECUSWType		=NULL;
													GrpECUChildPartP=setGet(GrpECUChldPrtObjs,jii);
													if (dstat = objGetAttribute(GrpECUChildPartP,PartNumberAttr,&sGECUChildpartDup)) goto CLEANUP;
													if(!nlsIsStrNull(sGECUChildpartDup)) sGECUChildpart = nlsStrDup(sGECUChildpartDup);

													if (dstat = objGetAttribute(GrpECUChildPartP,PartTypeAttr,&sGECUPrtTyp)) goto EXIT;
													if(!nlsIsStrNull(sGECUPrtTyp)) sGECUPrtTypDup = nlsStrDup(sGECUPrtTyp);

													if (dstat = objGetAttribute(GrpECUChildPartP,t5ECUTypeAttr,&sGECUTypeDup)) goto CLEANUP;
													if(!nlsIsStrNull(sGECUTypeDup)) sGECUType = nlsStrDup(sGECUTypeDup);
													printf("\n sGECUChildpart: [%s]  sGECUType :[%s]  Part Type:[%s]\n",sGECUChildpart,sGECUType,sGECUPrtTypDup);fflush(stdout);
													if ((nlsStrCmp(sGECUType,"Gear Shift Advisor")==0) ||(nlsStrCmp(sGECUType,"GSA")==0))
													{
														if (dstat = objGetAttribute(GrpECUChildPartP,t5EESwPartTypeAttr,&sGECUSWTypeDup)) goto CLEANUP;
														if(!nlsIsStrNull(sGECUSWTypeDup)) sGECUSWType = nlsStrDup(sGECUSWTypeDup);
														printf("\n ECU SW Type: [%s] \n",sGECUSWType);fflush(stdout);
														if ((nlsStrCmp(sGECUSWType,"Container")==0) ||(nlsStrCmp(sGECUSWType,"CON")==0))
														{
															//Container Available.
															GrpConFlag =1;
															//conflag ++;
															printf("\n GRP:Container Available.. \n ");fflush(stdout);
															if (conflag ==0)
															{
																nlsStrCat(ContString,"");
																nlsStrCat(ContString,"Container");
																nlsStrCat(ContString,",`");
																nlsStrCat(ContString,sGECUChildpart);
																nlsStrCat(ContString,",");
																printf("\n GRP::::::ContString.:%s",ContString);fflush(stdout);
																conflag ++;
															}
															else
															{
																nlsStrCat(ContString,"\n,,,,,,");
																nlsStrCat(ContString,"Container");
																nlsStrCat(ContString,",`");
																nlsStrCat(ContString,sGECUChildpart);
																nlsStrCat(ContString,",");
																printf("\n GRP:::ContString.:%s",ContString);fflush(stdout);
																conflag ++;
															}

															if(GrppECUChldPrtObjs) GrppECUChldPrtObjs=NULL;
															if (dstat = ExpandRelationWithCtxt("AsRevRev",GrpECUChildPartP,"PartsInAssembly",genCntXO1,SC_SCOPE_OF_SESSION,NULL,&GrppECUChldPrtObjs,&GrppECUChldPrtObjsRel,mfail))	goto EXIT;
															printf("\n Gchild count:[%d].",setSize(GrppECUChldPrtObjs));fflush(stdout);
															if(setSize(GrppECUChldPrtObjs)>0)
															{
																for (jiik=0;jiik<low_set_size(GrppECUChldPrtObjs) ; jiik++)
																{
																	printf("\n...to get vehicle number... \n ");fflush(stdout);
																	if(sGGECUChildpartDup)	sGGECUChildpartDup		=NULL;
																	if(sGGECUChildpart)		sGGECUChildpart		=NULL;
																	if(sGGECUPrtTypDup)		sGGECUPrtTypDup		=NULL;
																	if(sGGECUPrtTyp)		sGGECUPrtTyp		=NULL;
																	if(sGGECUTypeDup)		sGGECUTypeDup		=NULL;
																	if(sGGECUType)		sGGECUType		=NULL;
																	if(sGGECUSWTypeDup)		sGGECUSWTypeDup		=NULL;
																	if(sGGECUSWType)		sGGECUSWType		=NULL;
																	GrppECUChildPartP=setGet(GrppECUChldPrtObjs,jiik);
																	if (dstat = objGetAttribute(GrppECUChildPartP,PartNumberAttr,&sGGECUChildpartDup)) goto CLEANUP;
																	if(!nlsIsStrNull(sGGECUChildpartDup)) sGGECUChildpart = nlsStrDup(sGGECUChildpartDup);

																	if (dstat = objGetAttribute(GrppECUChildPartP,PartTypeAttr,&sGGECUPrtTyp)) goto EXIT;
																	if(!nlsIsStrNull(sGGECUPrtTyp)) sGGECUPrtTypDup = nlsStrDup(sGGECUPrtTyp);

																	if (dstat = objGetAttribute(GrppECUChildPartP,t5ECUTypeAttr,&sGGECUTypeDup)) goto CLEANUP;
																	if(!nlsIsStrNull(sGGECUTypeDup)) sGGECUType = nlsStrDup(sGGECUTypeDup);
																	printf("\n sGGECUChildpart: [%s]  sGGECUType :[%s]  sGGECUPrtTypDup Type:[%s]\n",sGGECUChildpart,sGGECUType,sGGECUPrtTypDup);fflush(stdout);
																	if ((nlsStrCmp(sGGECUType,"Gear Shift Advisor")==0) ||(nlsStrCmp(sGGECUType,"GSA")==0))
																	{
																		if (dstat = objGetAttribute(GrppECUChildPartP,t5EESwPartTypeAttr,&sGGECUSWTypeDup)) goto CLEANUP;
																		if(!nlsIsStrNull(sGGECUSWTypeDup)) sGGECUSWType = nlsStrDup(sGGECUSWTypeDup);
																		printf("\n ECU SW Type: [%s] \n",sGGECUSWType);fflush(stdout);
																		if ((nlsStrCmp(sGGECUSWType,"Calibration Software")==0) ||(nlsStrCmp(sGGECUSWType,"CAL")==0))
																		{
																			t5CheckMfail(ExpandObject2(PartDocClass,GrppECUChildPartP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&PrtDocSO1,&PrtDocRelSO1,mfail));
																			if (setSize(PrtDocSO1)>0)
																			{

																				/*To get latest document wich are attached to TC Part*/
																				if (dstat = t5GetLatestDocumnets(PrtDocSO1,PrtDocRelSO1,&LatestDocSO1,&LatestDocRelSO1,mfail));
																				if(*mfail) goto CLEANUP;
																				printf("\n Number Of LatestDocument = [%d]\n",setSize(LatestDocSO1));fflush(stdout);
																				for(DocumentCounter=0;DocumentCounter<setSize(LatestDocSO1);DocumentCounter++)
																				{
																					/*Intialize NULL to string and object pointer*/
																					BI_Ptr = NULL;
																					/*Take Object pointer of latest Document*/
																					BI_Ptr=setGet(LatestDocSO1,DocumentCounter);
																					if(dstat = ExpandObject5(AttachClass, BI_Ptr,"DataItemsAttachedToBusItem", SC_SCOPE_OF_SESSION, &AttachedDI, mfail)) goto CLEANUP;
																					printf("\n Total  Doc Attchment is [%d]\n",setSize(AttachedDI));fflush(stdout);
																					if(*mfail) goto CLEANUP;

																				  //Start Transfer of DataItem to Vault
																					if(setSize(AttachedDI)>0)
																					{
																						/*Start processing of transfer datat item to WIP/CE vault*/
																						for (AttachmentCounter=0;AttachmentCounter<setSize(AttachedDI);AttachmentCounter++)
																						{
																							DI_Ptr=setGet(AttachedDI,AttachmentCounter);
																							t5CheckDstat(objGetAttribute(DI_Ptr,RelativePathAttr,&thisRelPatDup));
																							if(thisRelPatDup) thisRelPatDupS = nlsStrDup(thisRelPatDup);
																							printf("\n GRP:thisRelPatDupS.:%s",thisRelPatDupS);fflush(stdout);
																							//Expand till Hex file
																							//nlsStrCat(ContString,"- ");
																							nlsStrCat(ContString,thisRelPatDupS);
																							nlsStrCat(ContString,",");
																							printf("\n GRP:FIle name :ContString.:%s",ContString);fflush(stdout);
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
															//break;
														}
														/*else if ((nlsStrCmp(sGECUSWType,"Parameter")==0) ||(nlsStrCmp(sGECUSWType,"PRM")==0))
														{
															//Parameter Available.
															printf("\n GRP:Parameter Available.. \n ");fflush(stdout);
														}*/
														else
														{
															GrpConFlag =0;
															//GRP:Parameter/Container NOT Available.
															printf("\n Container NOT Available.. \n ");fflush(stdout);
														}
													}
												}
											}
										}
										printf("\n GRP:Group id having Container Available..:[%d] \n",GrpConFlag);fflush(stdout);

										if(nlsStrCmp(sECUPrtTypDup,"G")!=0)
										{
											if (dstat = objGetAttribute(ECUChildPartP,t5EESwPartTypeAttr,&sECUSWTypeDup)) goto CLEANUP;
											if(!nlsIsStrNull(sECUSWTypeDup)) sECUSWType = nlsStrDup(sECUSWTypeDup);
											printf("\n ECU SW Type: [%s] \n",sECUSWType);fflush(stdout);
											if ((nlsStrCmp(sECUSWType,"Container")==0) ||(nlsStrCmp(sECUSWType,"CON")==0))
											{
												//Container Available.
												printf("\n Container Available.. \n ");fflush(stdout);
												OUTsideContainerFlag ++;
												/*nlsStrCat(ContString,";");
												nlsStrCat(ContString,sECUChildpart);
												nlsStrCat(ContString,";");
												printf("\n :ContString.:%s",ContString);fflush(stdout);*/

												if (conflag ==0)
												{
													nlsStrCat(ContString,"");
													nlsStrCat(ContString,"Container");
													nlsStrCat(ContString,",`");
													nlsStrCat(ContString,sECUChildpart);
													nlsStrCat(ContString,",");
													printf("\n GRP::::::ContString.:%s",ContString);fflush(stdout);
													conflag ++;
												}
												else
												{
													nlsStrCat(ContString,"\n,,,,,,");
													nlsStrCat(ContString,"Container");
													nlsStrCat(ContString,",`");
													nlsStrCat(ContString,sECUChildpart);
													nlsStrCat(ContString,",");
													printf("\n GRP:::ContString.:%s",ContString);fflush(stdout);
													conflag ++;
												}
												if(GrppECUChldPrtObjs) GrppECUChldPrtObjs=NULL;
												if (dstat = ExpandRelationWithCtxt("AsRevRev",ECUChildPartP,"PartsInAssembly",genCntXO1,SC_SCOPE_OF_SESSION,NULL,&GrppECUChldPrtObjs,&GrppECUChldPrtObjsRel,mfail))	goto EXIT;
												printf("\n Gchild count:[%d].",setSize(GrppECUChldPrtObjs));fflush(stdout);
												if(setSize(GrppECUChldPrtObjs)>0)
												{
													for (jiik=0;jiik<low_set_size(GrppECUChldPrtObjs) ; jiik++)
													{
														printf("\n...to get vehicle number... \n ");fflush(stdout);
														if(sGGECUChildpartDup)	sGGECUChildpartDup		=NULL;
														if(sGGECUChildpart)		sGGECUChildpart		=NULL;
														if(sGGECUPrtTypDup)		sGGECUPrtTypDup		=NULL;
														if(sGGECUPrtTyp)		sGGECUPrtTyp		=NULL;
														if(sGGECUTypeDup)		sGGECUTypeDup		=NULL;
														if(sGGECUType)		sGGECUType		=NULL;
														if(sGGECUSWTypeDup)		sGGECUSWTypeDup		=NULL;
														if(sGGECUSWType)		sGGECUSWType		=NULL;
														GrppECUChildPartP=setGet(GrppECUChldPrtObjs,jiik);
														if (dstat = objGetAttribute(GrppECUChildPartP,PartNumberAttr,&sGGECUChildpartDup)) goto CLEANUP;
														if(!nlsIsStrNull(sGGECUChildpartDup)) sGGECUChildpart = nlsStrDup(sGGECUChildpartDup);

														if (dstat = objGetAttribute(GrppECUChildPartP,PartTypeAttr,&sGGECUPrtTyp)) goto EXIT;
														if(!nlsIsStrNull(sGGECUPrtTyp)) sGGECUPrtTypDup = nlsStrDup(sGGECUPrtTyp);

														if (dstat = objGetAttribute(GrppECUChildPartP,t5ECUTypeAttr,&sGGECUTypeDup)) goto CLEANUP;
														if(!nlsIsStrNull(sGGECUTypeDup)) sGGECUType = nlsStrDup(sGGECUTypeDup);
														printf("\n sGGECUChildpart: [%s]  sGGECUType :[%s]  sGGECUPrtTypDup Type:[%s]\n",sGGECUChildpart,sGGECUType,sGGECUPrtTypDup);fflush(stdout);
														if ((nlsStrCmp(sGGECUType,"Gear Shift Advisor")==0) ||(nlsStrCmp(sGGECUType,"GSA")==0))
														{
															if (dstat = objGetAttribute(GrppECUChildPartP,t5EESwPartTypeAttr,&sGGECUSWTypeDup)) goto CLEANUP;
															if(!nlsIsStrNull(sGGECUSWTypeDup)) sGGECUSWType = nlsStrDup(sGGECUSWTypeDup);
															printf("\n ECU SW Type: [%s] \n",sGGECUSWType);fflush(stdout);
															if ((nlsStrCmp(sGGECUSWType,"Calibration Software")==0) ||(nlsStrCmp(sGGECUSWType,"CAL")==0))
															{
																t5CheckMfail(ExpandObject2(PartDocClass,GrppECUChildPartP,"DocumentsDescribingPart",SC_SCOPE_OF_SESSION,&PrtDocSO1,&PrtDocRelSO1,mfail));
																if (setSize(PrtDocSO1)>0)
																{

																	/*To get latest document wich are attached to TC Part*/
																	if (dstat = t5GetLatestDocumnets(PrtDocSO1,PrtDocRelSO1,&LatestDocSO1,&LatestDocRelSO1,mfail));
																	if(*mfail) goto CLEANUP;
																	printf("\n Number Of LatestDocument = [%d]\n",setSize(LatestDocSO1));fflush(stdout);
																	for(DocumentCounter=0;DocumentCounter<setSize(LatestDocSO1);DocumentCounter++)
																	{
																		/*Intialize NULL to string and object pointer*/
																		BI_Ptr = NULL;
																		/*Take Object pointer of latest Document*/
																		BI_Ptr=setGet(LatestDocSO1,DocumentCounter);
																		if(dstat = ExpandObject5(AttachClass, BI_Ptr,"DataItemsAttachedToBusItem", SC_SCOPE_OF_SESSION, &AttachedDI, mfail)) goto CLEANUP;
																		printf("\n Total  Doc Attchment is [%d]\n",setSize(AttachedDI));fflush(stdout);
																		if(*mfail) goto CLEANUP;

																	  //Start Transfer of DataItem to Vault
																		if(setSize(AttachedDI)>0)
																		{
																			/*Start processing of transfer datat item to WIP/CE vault*/
																			for (AttachmentCounter=0;AttachmentCounter<setSize(AttachedDI);AttachmentCounter++)
																			{
																				DI_Ptr=setGet(AttachedDI,AttachmentCounter);
																				t5CheckDstat(objGetAttribute(DI_Ptr,RelativePathAttr,&thisRelPatDup));
																				if(thisRelPatDup) thisRelPatDupS = nlsStrDup(thisRelPatDup);
																				printf("\n GRP:thisRelPatDupS.:%s",thisRelPatDupS);fflush(stdout);
																				//Expand till Hex file
																				//nlsStrCat(ContString,"- ");
																				nlsStrCat(ContString,thisRelPatDupS);
																				nlsStrCat(ContString,",");
																				printf("\n GRP:FIle name :ContString.:%s",ContString);fflush(stdout);
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
											//if ((nlsStrCmp(sECUSWType,"Parameter")==0) ||(nlsStrCmp(sECUSWType,"PRM")==0))
											if ((nlsStrCmp(sECUSWType,"XXXXX")==0) ||(nlsStrCmp(sECUSWType,"YYYY")==0))
											{
												//Parameter Available.
												printf("\n Parameter Available.. \n ");fflush(stdout);
												OUTsideParameterFlag ++;
												
												/*nlsStrCat(ParaString,";");
												nlsStrCat(ParaString,sECUChildpart);
												nlsStrCat(ParaString,";");
												printf("\n :ParaString.:%s",ParaString);fflush(stdout);*/
												if (conflag ==0)
												{
													nlsStrCat(ParaString,"");
													nlsStrCat(ParaString,"ParaString");
													nlsStrCat(ParaString,",`");
													nlsStrCat(ParaString,sECUChildpart);
													nlsStrCat(ParaString,",");
													printf("\n GRP::::::ParaString.:%s",ParaString);fflush(stdout);
													conflag ++;
												}
												else
												{
													nlsStrCat(ParaString,"\n,,,,,,");
													nlsStrCat(ParaString,"ParaString");
													nlsStrCat(ParaString,",`");
													nlsStrCat(ParaString,sECUChildpart);
													nlsStrCat(ParaString,",");
													printf("\n GRP:::ParaString.:%s",ParaString);fflush(stdout);
													conflag ++;
												}
											}
										}
									}
								}
								//
								printf("\n GRP FINAL::Group id having Container Available..:[%d] \n",GrpConFlag);fflush(stdout);
								printf("\n FINAL:OUTsideParameterFlag:[%d] OUTsideContainerFlag:[%d]\n",OUTsideParameterFlag,OUTsideContainerFlag);fflush(stdout);
								if (GrpConFlag >0)
								{
									printf("\n Container Available in group id now chek for Parameter.. \n ");fflush(stdout);
									/*if(OUTsideParameterFlag > 0)
									{
										printf("\n Parameter and Container Available in group id.. \n ");fflush(stdout);
										fprintf(fp1,"\n%s,%s,%s,%s,%s,Parameter/Container both Available,%s and %s,",PartnumS,VehPartnumS,sPartRev,sPartSeq,VehChldPartnumS,ParaString,ContString);fflush(fp1);
									}
									else
									{
										printf("\n Container not available.. \n ");fflush(stdout);
										fprintf(fp1,"\n%s,%s,%s,%s,%s,Container Available and Parameter NOT,%s,",PartnumS,VehPartnumS,sPartRev,sPartSeq,VehChldPartnumS,ContString);fflush(fp1);
									}*/

									printf("\n Container available.. \n ");fflush(stdout);
									fprintf(fp1,"\n%s,%s,%s,%s,%s,Container Available,%s,",VehPartnumS,sPartRev,sPartSeq,tprojectcodeDup,VehChldPartnumS,ContString);fflush(fp1);
								}
								else
								{
									/*if((OUTsideParameterFlag ==0)&& (OUTsideContainerFlag >0))
									{
										printf("\n Parameter NOT  and Container Available.. \n ");fflush(stdout);
										fprintf(fp1,"\n%s,%s,%s,%s,%s,Container Available and Parameter NOT,%s,",PartnumS,VehPartnumS,sPartRev,sPartSeq,VehChldPartnumS,ContString);fflush(fp1);
									}
									if((OUTsideParameterFlag >0)&& (OUTsideContainerFlag ==0))
									{
										printf("\n Parameter Available and Container NOT.. \n ");fflush(stdout);
										fprintf(fp1,"\n%s,%s,%s,%s,%s,Parameter Available and Container NOT,%s,",PartnumS,VehPartnumS,sPartRev,sPartSeq,VehChldPartnumS,ParaString);fflush(fp1);
									}
									if((OUTsideParameterFlag >0)&& (OUTsideContainerFlag >0))
									{
										printf("\n Parameter/Container both Available.. \n ");fflush(stdout);
										fprintf(fp1,"\n%s,%s,%s,%s,%s,Parameter/Container both Available,%s and %s,",PartnumS,VehPartnumS,sPartRev,sPartSeq,VehChldPartnumS,ParaString,ContString);fflush(fp1);
									}
									if((OUTsideParameterFlag ==0)&& (OUTsideContainerFlag ==0))
									{
										//Parameter/Container NOT Available.
										printf("\n Parameter/Container both NOT Available.. \n ");fflush(stdout);
										fprintf(fp1,"\n%s,%s,%s,%s,%s,Parameter/Container both NOT Available",PartnumS,VehPartnumS,sPartRev,sPartSeq,VehChldPartnumS);fflush(fp1);
									}*/
									if(OUTsideContainerFlag >0)
									{
										printf("\n Container Available.. \n ");fflush(stdout);
										fprintf(fp1,"\n%s,%s,%s,%s,%s,Container Available,%s,",VehPartnumS,sPartRev,sPartSeq,tprojectcodeDup,VehChldPartnumS,ContString);fflush(fp1);
									}
									if (OUTsideContainerFlag ==0)
									{
										printf("\n Container NOT Available.. \n ");fflush(stdout);
										fprintf(fp1,"\n%s,%s,%s,%s,%s,Container NOT Available,,",VehPartnumS,sPartRev,sPartSeq,tprojectcodeDup,VehChldPartnumS);fflush(fp1);
									}
								}
							}
							else
							{
								fprintf(fp1,"\n%s,%s,%s,%s,%s,NO BOM to 16R,,,,,,",VehPartnumS,sPartRev,sPartSeq,tprojectcodeDup,VehChldPartnumS);fflush(fp1);
							}
							break;
						}
					}
					if (Rflag ==0)
					{
						fprintf(fp1,"\n%s,%s,%s,%s,16R TPL not avaialble under VC Vehicle,,,,,,",VehPartnumS,sPartRev,sPartSeq,tprojectcodeDup);fflush(fp1);
					}
				}
				else
				{
					fprintf(fp1,"\n%s,%s,%s,%s,NO BOM to Vehicle,,,,,,",VehPartnumS,sPartRev,sPartSeq,tprojectcodeDup);fflush(fp1);
				}
				break;
			}
		}
		else
		{
			fprintf(fp1,"\n%s,Vehicle not available,,,,,,",PartNo);fflush(fp1);
		}
	}
	printf("\n		~~~~~~~~~~~~~~~  REPORT GENERATION COMPLETE !!!   ~~~~~~~~~~~~~~~~~~~~ \n ");fflush(stdout);
	printf("\n		~~~~~~~~  L I V E   L O N G   &   P R O S P E R    ~~~~~~~~~~~~~~ \n\n ");fflush(stdout);
fclose(fp1);fp1=NULL;
CLEANUP :

       // t5FreeSetOfObjects(AllTmlStdSetObjs);
	   if (TempCatS) t5FreeString(TempCatS);

EXIT:
        if (dstat != OKAY) dlow_return_trace(mod_name, dstat);
         return (dstat);
}

