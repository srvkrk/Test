#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <tccore/aom_prop.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <time.h>
#define ITK_err (EMH_USER_error_base + 2)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

extern int ITK_user_main(int argc, char *argv[] )
{

	int	iStatus= 0;
	iStatus = ITK_auto_login();

//			char	*values[3];
			char	*values[1];
//			char	*qry_Input[3]			= {"License Level","Status","Id"};
		    char	*qry_Input[1]			= {"Id"};
//			int		n_Input					= 3;
			int		n_Input					= 1;
			int		Count					= 0;
			tag_t	*Usertag		   = NULLTAG;
			tag_t	Quser			   = NULLTAG;
			tag_t	persontag		   = NULLTAG;
			tag_t	RelationType	   = NULLTAG;
			tag_t	valueTag		   = NULLTAG;
			tag_t	UserTag1		   = NULLTAG;
			int lov1;
			char* emailid=NULL;
			char* usernameTag                   = NULL;
            char* useridTag  = NULL;
            char*    lov= NULL;
            char* class_name                    = NULL;
            char* deparmentTag                  = NULL;
            char* useragencyTag                 = NULL;
            char* userlocationTag               = NULL;
			char* license_level                 =NULL;
			char *lincese_level1                =NULL;
			char *fnd0LicenseServer              =NULL;
			char *last_login_time              =NULL;
			char *status              =NULL;
			char *status1              =NULL;
			char *UserId1                =NULL;
			char *UserId2                =NULL;
			int i=0;
			int usercount=0;
			int count2=0;
			int	n_values =0; 
            char* FirstName=NULL;
            char* MiddleName=NULL;
            char* LastName=NULL;
           


            
			char buffer[50];
//			values[0] = "0";
//			values[1] = "0";
//			values[2] = "*";
			
			FILE* fp = NULL;
			FILE *ftr=NULL;
			char* filename   = NULL;
            char  temp[500];
//			if(QRY_find2("UserFndACtive", &Quser));
			//ftr=fopen("InputUserId.txt","r");
			// if(ftr==NULL)
       // {
           //     printf("Read File\n");
          //      printf("unable  open  File\n ");fflush(stdout);
          //      return 1;
       // }
		// else
        //{
                // while(fgets(temp,500,ftr)!=NULL)
              //  {

                        // if(temp != NULL)
                       //  {

                          //   fputs(temp,stdout);
                           //      UserId1 = strtok(temp,",");
                           //      UserId2=strtok(NULL,",");



			values[0] = "*";
			if(QRY_find2("UserFind", &Quser));
			if(Quser)
		{
			 if(QRY_execute(Quser, n_Input, qry_Input, values, &Count, &Usertag));
			 printf("\n QUERY count== %d...................\n", Count);fflush(stdout);
		}
		if(Count==0)
			{

		    values[0] = UserId2;
			if(QRY_find2("UserFind", &Quser));
			if(Quser)
		    {
			 if(QRY_execute(Quser, n_Input, qry_Input, values, &Count, &Usertag));
			 printf("\n QUERY count another User== %d...................\n", Count);fflush(stdout);
		    }
		
		    }
			 fp = fopen("UserInformation.csv","w");

			 fprintf(fp,"User ID,Email ID,First Name,Middle Name,Last Name,Authorization,status,LicenseServer,Last System Access Time\n");
			  if(fp != NULL)
			{
					
			   printf("\n File is opened \n");fflush(stdout);
		      
			
			}
			else
		   {
				
				printf("\n File is  NOT opened \n");fflush(stdout);
				
			}
		 lincese_level1=(char *)MEM_alloc(200);
         status1=(char *)MEM_alloc(200);
		 MiddleName=(char *)MEM_alloc(200);
		 LastName=(char *)MEM_alloc(200);
			for(i=0; i<Count; i++)
	     {


			UserTag1 = Usertag[i];

			ITK_CALL(AOM_ask_value_string(UserTag1,"user_name",&usernameTag));

			printf("\n Name of user: %s \n",usernameTag);fflush(stdout);
			
			ITK_CALL(AOM_ask_value_string(UserTag1,"user_id",&useridTag));
			
			printf("\n User ID of user: %s \n",useridTag);fflush(stdout);

            ITK_CALL(AOM_UIF_ask_value(UserTag1,"status",&status));
			
			printf("\n User ID of user: %s \n",status);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(UserTag1,"last_login_time",&last_login_time));
			
			printf("\n User ID of user: %s \n",last_login_time);fflush(stdout);	

 

			if(tc_strcmp(status,"1"))
			 {
			     tc_strcpy(status1,"Active");
			 }
			 else if(tc_strcmp(status,"0"))
             {
			     tc_strcpy(status1,"Inactive");
			 }


            //ITK_CALL(AOM_ask_value_string(UserTag1,"status",&status));
			
			//printf("\n User ID of user: %s \n",status);fflush(stdout); 
			ITK_CALL(AOM_UIF_ask_value(UserTag1,"fnd0LicenseServer",&fnd0LicenseServer));
			
			printf("\n User ID of user: %s \n",fnd0LicenseServer);fflush(stdout);

			FirstName=tc_strtok(usernameTag," ");
			MiddleName=tc_strtok(NULL," ");
            LastName=tc_strtok(NULL," ");
	        if (tc_strcmp(LastName,NULL)==0)
	        {
                 printf("Ihside Condition 123.........................");fflush(stdout);
                 LastName=MiddleName;
				 MiddleName="";
	        }
			if((tc_strcmp(LastName,NULL)==0) && (tc_strcmp(MiddleName,"")==0) )
			 {
				 
			     LastName="";
			 }
            printf("\n User ID of user: %s \n",FirstName);fflush(stdout);
            printf("\n User ID of user: %s \n",MiddleName);fflush(stdout);
            printf("\n User ID of user: %s \n",LastName);fflush(stdout);
		    //ITKCALL(AOM_ask_value_tags(UserTag,"license_level",&license_level,&lov));
            ITKCALL(AOM_UIF_ask_value(UserTag1,"license_level",&lov));	
            printf("\n license_level : %s \n",lov);fflush(stdout);
			lov1=atoi(lov);
			strcpy(lincese_level1,"");
			if (lov1==0)
			{
                tc_strcpy(lincese_level1,"Author");

			}
			else if (lov1==1)
			{
                tc_strcpy(lincese_level1,"Consummer");
			}
            else if (lov1==2)
			{
			    tc_strcpy(lincese_level1,"Occsaional User");
			}
			else if (lov1==3)
			{
                 tc_strcpy(lincese_level1,"Viewer");
			}
           else if (lov1==4)
			{
		          tc_strcpy(lincese_level1,"Viewer");
		    }
            else if (lov1==5)
			{
			    tc_strcpy(lincese_level1,"Admin");  
			}
            printf("\n license_level1 : %s \n",lincese_level1);fflush(stdout);

			//ITK_CALL(AOM_ask_value_tag(UserTag1,"fnd0custom_user_profile",&valueTag));
            ITK_CALL(SA_ask_user_person(UserTag1,&persontag));

			ITK_CALL(SA_ask_person_email_address(persontag,&emailid));

			printf("\n Mail ID of user: %s \n",emailid);fflush(stdout);

//			ITK_CALL(GRM_find_relation_type("IMAN_based_on", &RelationType));

       

//		   ITK_CALL(ITEM_list_all_attachments(valueTag,RelationType,&count2,&Attachment));




			//if(valueTag !=NULLTAG)

			// {

			//printf("\n Value Tag Found Sucessfully ..!!!!!!\n");fflush(stdout);
			//
			//ITK_CALL(AOM_ask_value_string(valueTag,"t5_department",&deparmentTag));
			//
			//printf("\n Value of department : %s \n",deparmentTag);fflush(stdout);
			//
			//ITK_CALL(AOM_ask_value_string(valueTag,"t5_useragency",&useragencyTag));
			//
			//printf("\n Value of useragency: %s \n",useragencyTag);fflush(stdout);
			//
			//ITK_CALL(AOM_ask_value_string(valueTag,"t5_userlocation",&userlocationTag));
			//
			//printf("\n Value of userlocation: %s \n",userlocationTag);fflush(stdout);
			//
			 //}       
			
			fprintf(fp,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s",useridTag,emailid,FirstName,MiddleName,LastName,lincese_level1,status1,fnd0LicenseServer,last_login_time);fflush(stdout);
					
           
		 }
						// }
		//}
		//}
		//if(ftr)
	  //  {
		//   fclose(ftr);
		//	ftr=NULL;
	//	}
		if(fp)
		{
			fclose(fp);
			fp=NULL;
		}

		


  return 0;
}
