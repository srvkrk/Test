//  ./Test4dObj -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=DFM_282960000102_NR_1
//  ./Test4dObj -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=DFM_282960001452_NR_1
//  ./Test4dObj -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=InputFile.txt

//   ./PDF_DFMEA4D_Attachment -u=ercpsup -p=ERCpsup2019 -g=dba -i=Input_test.txt
//   ./PDF_DFMEA4D_Attachment -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=Input_test.txt
//  ./PDF_DFMEA4D_Attachment -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=InputFile2.txt

// ./PDF_DFMEA4D_Attachment -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=InputFile3.txt

//./PDF_DFMEA4D_Attachment -u=infodba -pf=/home/uaprod/shells/Admin/infodbapassfile.pwf -g=dba -i=shellInputfile.txt


//./PDF_DFMEA4D_Attachment -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=shellInputfile.txt
//./PDF_DFMEA4D_Attachment -u=bsd05818 -p=XYT1ESA -g=dba -i=shellInputfile.txt
//./PDF_DFMEA4D_Attachment -u=bsd05818 -p=XYT1ESA -g=dba -i=ShellPdfFiles.txt

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include <epm/cr_effectivity.h>
#include<ics/ics.h>
#include<ics/iman_ics.h>
//#include <tcfile_cache.h>

#define Debug TRUE
//#define ITK_CALL(X)														\
//	if(Debug)															\
//	{																	\
//		printf(#X);														\
//	}																	\
//	fflush(NULL);														\
//	status=X;															\
//	if (status != ITK_ok )												\
//	{																	\
//		int				index = 0;										\
//		int				n_ifails = 0;									\
//		const int*		severities = 0;									\
//		const int*		ifails = 0;										\
//		const char**	texts = NULL;									\
//																		\
//		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
//		printf("\t%3d error(s)\n", n_ifails);							\
//		for( index=0; index<n_ifails; index++)							\
//		{																\
//			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
//		}																\
//		return status;													\
//	}																	\
//	else																\
//	{																	\
//		if(Debug)														\
//		printf("\tSUCCESS\n");											\
//	}																	\



	#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error ( char *file, int line, char *function, int return_code)
{
if (return_code != ITK_ok)
{
int index = 0;
int n_ifails = 0;
const int* severities = 0;
const int* ifails = 0;
const char** texts = NULL;



EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
printf("%3d error(s)\n", n_ifails);
for( index=0; index<n_ifails; index++)
{
printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
}
EMH_clear_errors();

}
return return_code;
}



#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

void removeNewLineChar(char *ptr)
{
    while((ptr != NULL) && (*ptr != '\n'))
    {
        ++ptr;
    }
    *ptr = '\0';
}

extern int ITK_user_main(int argc, char ** argv )
{

    int status;

	tag_t PartObj		 = NULLTAG;
	tag_t queryTagK		 = NULLTAG;
	tag_t *children		 = NULLTAG;
	char *itemname		 = NULL;
	char *itemnameParent = NULL;
	int		nAttributes  = 0;


	char		*PartNumberS		= NULL;
	char		*PartNumberSxls		= NULL;
	char		*curentname			= NULL;
	char		*DADname			= NULL;
	char		*curentnameid			= NULL;
	char		*curentnamexls		= NULL;
	char		*ProjctCdeS			= NULL;
	tag_t  ProjctCdeS1 = NULLTAG;
	char		*ProjctCdeSxls		= NULL;
	char		*tok				= NULL;
	char		*tokxls				= NULL;
	char		*Parttok			= NULL;
	char		*Parttokxls			= NULL;
	char		*PartRevtok			= NULL;
	char		*PartRevtokxls		= NULL;
	char		*PartSeqtok			= NULL;
	char		*PartSeqtokxls		= NULL;
	char		*ObjTok				= NULL;
	char		*ObjTokxls			= NULL;
	tag_t		Part_tag			= NULLTAG;
	tag_t		Part_tagxls			= NULLTAG;
	tag_t		latestrev			= NULLTAG;
	tag_t		Latestrev_Tag		= NULLTAG;
	tag_t		latestrevxls		= NULLTAG;
	int			ifail				= 0;
	tag_t		relationSpeci_type;
	tag_t		relationSpeci_typexls;
	tag_t		FndSpeciRelation;
	tag_t		FndSpeciRelationxls;
	tag_t		DatasetType			= NULLTAG;
	tag_t		DatasetTypexls		= NULLTAG;
	tag_t		PdfDataset			= NULLTAG;
	tag_t		XlsDataset			= NULLTAG;
	tag_t		specificationRel_t	= NULLTAG;
	tag_t		specificationRel_txls	= NULLTAG;
	tag_t		PdfLatestDat_t		= NULLTAG;
	int			iStatus				= 0;
	FILE		*fptr;
	char		* inputfile			= NULL;
	char		*nwRev				= NULL;
	char		*nwRev1				= NULL;
	char		*nwRevxls			= NULL;
	tag_t		 ReqRev				= NULLTAG;
	int			n_tags_found4		= 0;
	tag_t		*tags_found4		= NULLTAG;

	nwRev		=(char *) MEM_alloc(10);
	//char		 pdfpath1[300];
	char		 *pdfpath1			=	NULL;
	char		 *xlspath1			=	NULL;
	//char		 pdfpath[300];
	char		 *pdfpath			=	NULL;
	char		 *xlspath			=	NULL;
	char		*inputline			=	NULL;
	char		*inputlinenew		=	NULL;
	char		*inputlinenew1		=	NULL;
	char		*TypeNmetok			=	NULL;
	char		*TypeNmetokxls		=	NULL;
	char		*SerialNumtok		=	NULL;
	char		*SerialNumtokxls	=	NULL;

	int         number_of_types1	= 0;
	int         number_of_types1xls	= 0;
	tag_t		type_tag3=NULLTAG;
	tag_t*		type_tag3xls;
	tag_t		object_create_input_tag3 =NULLTAG;
	tag_t		object_create_input_tag3xls =NULLTAG ;
	tag_t		dad_tag =NULLTAG;
	tag_t		dadrev_tag =NULLTAG;
	//tag_t		dad_tag1 =NULLTAG;
	tag_t		dad_tagxls =NULLTAG;
	tag_t		DADRel_t		= NULLTAG;
	tag_t		DADRel_txls		= NULLTAG;
	tag_t		tRelationFind	= NULLTAG;
	tag_t		tRelationFindxls	= NULLTAG;
	tag_t		tRelationExistxls	= NULLTAG;
	tag_t		tRelationExist	= NULLTAG;
	char *		Typetok			= NULL;
	char *		Typetokxls			= NULL;
	char *		inputfilenew	= NULL;

	tag_t	ProQry4dObj		= NULLTAG;
	tag_t	*Obj4D			= NULLTAG;
	tag_t	DAD4DCountObj	=NULL;
	int		DAD4DCount		= 0;
	int		n_Input			= 3;
//	char	*qry_Input[3]	= {"ItemID", "Type", "Revision"};
//	char	*valuesx[3];
	tag_t	DAD4D_rev_tag	= NULLTAG;
	tag_t	DADrevTag		= NULLTAG;
	tag_t	DADrevTagxls		= NULLTAG;
	char * PartTypeS		= NULL;
	char * PartTypeSxls		= NULL;
	char * DADNumber		= NULL;

	logical			checkout			= 0;
	logical			checkoutxls			= 0;
	logical			checkout2			= 0;
	logical			checkout2xls			= 0;
	char*			ReleaseStatus		= NULL;
	char*			ReleaseStatusxls		= NULL;
	char*			ReleaseStatuspdf	= NULL;
	tag_t			status_rel			= NULLTAG;
	tag_t			status_relxls			= NULLTAG;
	tag_t			status_relpdf		= NULLTAG;
	logical			retain				= 0;
	logical			retainpdf			= 0;
	tag_t*			relStatus_list;
	tag_t*			relStatus_listxls;
	int				status_count		= 0;
	int				status_countxls		= 0;
	int				ss					= 0;
	int				ss1					= 0;
	char			*latest_rev_Rel_Stus= NULL;
	char			*latest_rev_Rel_Stusxls= NULL;
	char		*T5_DAD_Document_item_id			= NULL;
	char		*PartRevSeq			= NULL;
	char		*s= NULL;
	int line_count = 0;



	(void)argc;
	(void)argv;


	inputfile  = ITK_ask_cli_argument("-i=");//DFA_1234567_NR_1_01.pdf

	iStatus = ITK_auto_login();
	//ifail = ITK_init_module("loader","loader@2022","dba");


	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));

	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\n After Auto login .......\n");fflush(stdout);



	fptr=fopen(inputfile,"r");
	if(fptr!=NULL)
	{
	  printf("\n Input File is %s",inputfile);

	  printf("\n inputfile-------->  : [%s]\n",inputfile);fflush(stdout);//abcd.txt

	  inputline=(char *) MEM_alloc(2000);
	  inputlinenew =(char *)MEM_alloc(2000);
	  //inputlinenew1 =(char *)MEM_alloc(1500);

	  while(fgets(inputline,2000,fptr)!=NULL)
	  {

		printf("inputline[%03d]: %s", ++line_count, inputline);
//		 if (inputline[strlen(inputline) - 1] != '\n')
//         printf("\n");

		printf("\n inputline -------->  : [%s]\n",inputline);fflush(stdout);
//		printf("\n inputlinenew------>  : [%s]\n",inputlinenew);fflush(stdout);

		removeNewLineChar(inputline);

		tc_strcpy(inputlinenew,inputline);
		printf("\n inputlinenew------>  : [%s]\n",inputlinenew);fflush(stdout);
		ObjTok = MEM_alloc(35);
		ObjTok = tc_strtok(inputlinenew, ".");

		printf("\n ObjTok  : [%s]\n",ObjTok);fflush(stdout);
		DADNumber	=	(char	*)MEM_alloc(90);
		tc_strcpy(DADNumber,ObjTok);
		printf("\n DADNumber------>  : [%s]\n",DADNumber);fflush(stdout);


	   if (tc_strstr(inputline,".pdf")!=NULL)
	   {
			//pdfpath1	=	NULL;
			pdfpath1	=	(char	*)MEM_alloc(500);
			//pdfpath1    =(char	*)MEM_alloc(tc_strlen(inputline)+2);
			tc_strcpy(pdfpath1,inputline);
			printf("\n PDF Name pdfpath1 ------------------->{%s}\n",pdfpath1); fflush(stdout);

			//pdfpath	=	NULL;
			pdfpath	=	(char	*)MEM_alloc(300);

			tc_strcpy(pdfpath,"");
			tc_strcat(pdfpath,"/home/cvprod/CVPROD_4D_Shell");
			//printf("\n pdfpath 111111 ----------------->	[%s]\n ",pdfpath);fflush(stdout);
			////tc_strcat(pdfpath,"/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/MovedFiles_TCUA");
			//tc_strcat(pdfpath,"/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/PDFFiles");
			//tc_strcat(pdfpath,"/user/uaprod/shells/4D");
			/*tc_strcat(pdfpath,"/user/uaprodtrl/4D_updation_shell");///user/bsd05818/Adi*/
			//tc_strcat(pdfpath,"/tmp");
			//tc_strcat(pdfpath,"/user/testcmi/devgroups/Adi/Test4dObj");
			//tc_strcat(pdfpath,"/user/plmsap/PLMSAP/dbk/sap_prod/Jan2022/05012022");
			tc_strcat(pdfpath,"/");
			tc_strcat(pdfpath,pdfpath1);

			printf("\n pdfpath ----------------->	[%s]\n ",pdfpath);fflush(stdout);
			//removeNewLineChar(pdfpath);
			printf("\n after removal pdfpath ----------------->	[%s]\n ",pdfpath);fflush(stdout);


			Typetok =NULL;
			Parttok =NULL;
			PartRevtok =NULL;
			PartSeqtok =NULL;
			SerialNumtok =NULL;

			Typetok = MEM_alloc(15);
			Parttok = MEM_alloc(15);
			PartRevtok = MEM_alloc(15);
			PartSeqtok = MEM_alloc(15);
			SerialNumtok = MEM_alloc(15);

			Typetok = tc_strtok(inputlinenew, "_");// DFA
			Parttok = tc_strtok(NULL, "_");		// 1234567
			PartRevtok = tc_strtok(NULL, "_");	//NR
			PartSeqtok = tc_strtok(NULL, "_");	//1
			SerialNumtok = tc_strtok(NULL, "_");//01

			PartRevSeq = MEM_alloc(5);
//			T5_DAD_Document_item_id = MEM_alloc(50);

			tc_strcpy(PartRevSeq,PartRevtok);

			printf("\n Typetok to find----------> = %s\n", Typetok);fflush(stdout);
			printf("\n Parttok to find----------> = %s\n", Parttok);fflush(stdout);
			printf("\n PartRevtok to find----------> = %s\n", PartRevtok);fflush(stdout);
			printf("\n PartSeqtok to find----------> = %s\n", PartSeqtok);fflush(stdout);
			printf("\n SerialNumtok to find----------> = %s\n", SerialNumtok);fflush(stdout);
			printf("\n PartRevSeq to find----------> = %s\n", PartRevSeq);fflush(stdout);
			//printf("\n T5_DAD_Document_item_id to find----------> = %s\n", T5_DAD_Document_item_id);fflush(stdout);
			tc_strcat(PartRevSeq,";");
			tc_strcat(PartRevSeq,PartSeqtok);
			printf("\n PartRevSeq to find----------> = %s\n", PartRevSeq);fflush(stdout);

			PartTypeS = (char	*)MEM_alloc(10);
			tc_strcpy(PartTypeS,Typetok);
			printf("\n PartTypeS= [%s]\n",PartTypeS);fflush(stdout);

			PartNumberS = (char	*)MEM_alloc(50);
			tc_strcpy(PartNumberS,Parttok);
			printf("\n Part Number to find = [%s]\n",PartNumberS);fflush(stdout);

			ITK_CALL(ITEM_find_item (PartNumberS,&Part_tag));

			const char **attrs3  = ( const char **) MEM_alloc(1 * sizeof(char *));
			const char **values3 = ( const char **) MEM_alloc(1 * sizeof(char *));
			attrs3[0]	   ="item_id";
			values3[0]     = (char *)PartNumberS;

			ITK_CALL(ITEM_find_item_revs_by_key_attributes(1,attrs3, values3,PartRevSeq, &n_tags_found4, &tags_found4));
			MEM_free(attrs3);
			MEM_free(values3);
			printf("\n revcount......%d\n",n_tags_found4);

			if (n_tags_found4>0)
			{
			   latestrev= tags_found4[0];

			}
			else
		    {
				continue;
		    }

			ITK_CALL(ITEM_ask_latest_rev(Part_tag,&Latestrev_Tag));	 ///trial Latestrev_Tag in replace of latestrev

			ITK_CALL(AOM_ask_value_string(Latestrev_Tag,"item_id",&curentname));
			printf("\ncurentname:%s\n",curentname);

			ITK_CALL(AOM_ask_value_string(Latestrev_Tag,"item_revision_id",&curentnameid));
			printf("\n curentnameid:%s \n",curentnameid);

			ITK_CALL(AOM_ask_value_string(Latestrev_Tag,"t5_ProjectCode",&ProjctCdeS));
			printf("\n Required revision---------------> [%s]and project code ---------->[%s]\n",curentnameid,ProjctCdeS);fflush(stdout);

			//return 0;
			if(access(pdfpath,F_OK)!=-1)
			{
				printf("\n FILE PRESENT qqqqqqqqqqqqqqqqqqqqqqqqqqqqQ  \n ");fflush(stdout);
			}
			else
			{
				printf("\n FILE NOT PRESENT qqqqqqqqqqqqqqqqqqqqqqqqqqqqQ  \n ");fflush(stdout);
			}
			system("pwd");

		   if(tc_strcmp(ProjctCdeS,"5195")==0||tc_strcmp(ProjctCdeS,"2999")==0||tc_strcmp(ProjctCdeS,"5550")==0||tc_strcmp(ProjctCdeS,"5550")==0||tc_strcmp(ProjctCdeS,"2073")==0||tc_strcmp(ProjctCdeS,"2075")==0||tc_strcmp(ProjctCdeS,"2084")==0||tc_strcmp(ProjctCdeS,"2099")==0||tc_strcmp(ProjctCdeS,"2152")==0
			||tc_strcmp(ProjctCdeS,"2165")==0||tc_strcmp(ProjctCdeS,"2171")==0||tc_strcmp(ProjctCdeS,"2196")==0||tc_strcmp(ProjctCdeS,"2202")==0||tc_strcmp(ProjctCdeS,"2240")==0||tc_strcmp(ProjctCdeS,"2574")==0||tc_strcmp(ProjctCdeS,"2591")==0||tc_strcmp(ProjctCdeS,"2592")==0 
			||tc_strcmp(ProjctCdeS,"2600")==0||tc_strcmp(ProjctCdeS,"2610")==0||tc_strcmp(ProjctCdeS,"2641")==0||tc_strcmp(ProjctCdeS,"2642")==0||tc_strcmp(ProjctCdeS,"2647")==0||tc_strcmp(ProjctCdeS,"2651")==0||tc_strcmp(ProjctCdeS,"2652")==0||tc_strcmp(ProjctCdeS,"2654")==0
			||tc_strcmp(ProjctCdeS,"2673")==0||tc_strcmp(ProjctCdeS,"2674")==0||tc_strcmp(ProjctCdeS,"2679")==0||tc_strcmp(ProjctCdeS,"2680")==0||tc_strcmp(ProjctCdeS,"2705")==0||tc_strcmp(ProjctCdeS,"2742")==0||tc_strcmp(ProjctCdeS,"2745")==0||tc_strcmp(ProjctCdeS,"2751")==0
			||tc_strcmp(ProjctCdeS,"2753")==0||tc_strcmp(ProjctCdeS,"2754")==0||tc_strcmp(ProjctCdeS,"2770")==0||tc_strcmp(ProjctCdeS,"2776")==0||tc_strcmp(ProjctCdeS,"2815")==0||tc_strcmp(ProjctCdeS,"2816")==0||tc_strcmp(ProjctCdeS,"2818")==0||tc_strcmp(ProjctCdeS,"2821")==0
			||tc_strcmp(ProjctCdeS,"2829")==0||tc_strcmp(ProjctCdeS,"2832")==0||tc_strcmp(ProjctCdeS,"2841")==0||tc_strcmp(ProjctCdeS,"2885")==0||tc_strcmp(ProjctCdeS,"2894")==0||tc_strcmp(ProjctCdeS,"2896")==0||tc_strcmp(ProjctCdeS,"2897")==0||tc_strcmp(ProjctCdeS,"2898")==0
			||tc_strcmp(ProjctCdeS,"2900")==0||tc_strcmp(ProjctCdeS,"2910")==0||tc_strcmp(ProjctCdeS,"3505")==0||tc_strcmp(ProjctCdeS,"4103")==0||tc_strcmp(ProjctCdeS,"5506")==0||tc_strcmp(ProjctCdeS,"5507")==0||tc_strcmp(ProjctCdeS,"5508")==0||tc_strcmp(ProjctCdeS,"5858")==0
			||tc_strcmp(ProjctCdeS,"5017")==0||tc_strcmp(ProjctCdeS,"5020")==0||tc_strcmp(ProjctCdeS,"5021")==0||tc_strcmp(ProjctCdeS,"5023")==0||tc_strcmp(ProjctCdeS,"5024")==0||tc_strcmp(ProjctCdeS,"5027")==0||tc_strcmp(ProjctCdeS,"5032")==0||tc_strcmp(ProjctCdeS,"5034")==0
			||tc_strcmp(ProjctCdeS,"5039")==0||tc_strcmp(ProjctCdeS,"5040")==0||tc_strcmp(ProjctCdeS,"5062")==0||tc_strcmp(ProjctCdeS,"5084")==0||tc_strcmp(ProjctCdeS,"5089")==0||tc_strcmp(ProjctCdeS,"5117")==0||tc_strcmp(ProjctCdeS,"5118")==0||tc_strcmp(ProjctCdeS,"5119")==0
			||tc_strcmp(ProjctCdeS,"5120")==0||tc_strcmp(ProjctCdeS,"5126")==0||tc_strcmp(ProjctCdeS,"5127")==0||tc_strcmp(ProjctCdeS,"5137")==0||tc_strcmp(ProjctCdeS,"5147")==0||tc_strcmp(ProjctCdeS,"5148")==0||tc_strcmp(ProjctCdeS,"5150")==0||tc_strcmp(ProjctCdeS,"5152")==0
			||tc_strcmp(ProjctCdeS,"5153")==0||tc_strcmp(ProjctCdeS,"5154")==0||tc_strcmp(ProjctCdeS,"5155")==0||tc_strcmp(ProjctCdeS,"5156")==0||tc_strcmp(ProjctCdeS,"5157")==0||tc_strcmp(ProjctCdeS,"5158")==0||tc_strcmp(ProjctCdeS,"5159")==0||tc_strcmp(ProjctCdeS,"5160")==0
			||tc_strcmp(ProjctCdeS,"5161")==0||tc_strcmp(ProjctCdeS,"5162")==0||tc_strcmp(ProjctCdeS,"5163")==0||tc_strcmp(ProjctCdeS,"5164")==0||tc_strcmp(ProjctCdeS,"5165")==0||tc_strcmp(ProjctCdeS,"5166")==0||tc_strcmp(ProjctCdeS,"5167")==0||tc_strcmp(ProjctCdeS,"5168")==0
			||tc_strcmp(ProjctCdeS,"5169")==0||tc_strcmp(ProjctCdeS,"5170")==0||tc_strcmp(ProjctCdeS,"5171")==0||tc_strcmp(ProjctCdeS,"5172")==0||tc_strcmp(ProjctCdeS,"5174")==0||tc_strcmp(ProjctCdeS,"5175")==0||tc_strcmp(ProjctCdeS,"5176")==0||tc_strcmp(ProjctCdeS,"5177")==0
			||tc_strcmp(ProjctCdeS,"5178")==0||tc_strcmp(ProjctCdeS,"5179")==0||tc_strcmp(ProjctCdeS,"5180")==0||tc_strcmp(ProjctCdeS,"5181")==0||tc_strcmp(ProjctCdeS,"5182")==0||tc_strcmp(ProjctCdeS,"5183")==0||tc_strcmp(ProjctCdeS,"5184")==0||tc_strcmp(ProjctCdeS,"5185")==0
			||tc_strcmp(ProjctCdeS,"5187")==0||tc_strcmp(ProjctCdeS,"5192")==0||tc_strcmp(ProjctCdeS,"5193")==0||tc_strcmp(ProjctCdeS,"5201")==0||tc_strcmp(ProjctCdeS,"5202")==0||tc_strcmp(ProjctCdeS,"5203")==0||tc_strcmp(ProjctCdeS,"5204")==0||tc_strcmp(ProjctCdeS,"5206")==0
			||tc_strcmp(ProjctCdeS,"5207")==0||tc_strcmp(ProjctCdeS,"5208")==0||tc_strcmp(ProjctCdeS,"5209")==0||tc_strcmp(ProjctCdeS,"5210")==0||tc_strcmp(ProjctCdeS,"5211")==0||tc_strcmp(ProjctCdeS,"5501")==0||tc_strcmp(ProjctCdeS,"5502")==0||tc_strcmp(ProjctCdeS,"5503")==0
			||tc_strcmp(ProjctCdeS,"5512")==0||tc_strcmp(ProjctCdeS,"5513")==0||tc_strcmp(ProjctCdeS,"5515")==0||tc_strcmp(ProjctCdeS,"5523")==0||tc_strcmp(ProjctCdeS,"5527")==0||tc_strcmp(ProjctCdeS,"5528")==0||tc_strcmp(ProjctCdeS,"5529")==0||tc_strcmp(ProjctCdeS,"5530")==0
			||tc_strcmp(ProjctCdeS,"5532")==0||tc_strcmp(ProjctCdeS,"5533")==0||tc_strcmp(ProjctCdeS,"5537")==0||tc_strcmp(ProjctCdeS,"5541")==0||tc_strcmp(ProjctCdeS,"5545")==0||tc_strcmp(ProjctCdeS,"5546")==0||tc_strcmp(ProjctCdeS,"5547")==0||tc_strcmp(ProjctCdeS,"5549")==0
			||tc_strcmp(ProjctCdeS,"5553")==0||tc_strcmp(ProjctCdeS,"5554")==0||tc_strcmp(ProjctCdeS,"5555")==0||tc_strcmp(ProjctCdeS,"5556")==0||tc_strcmp(ProjctCdeS,"5557")==0||tc_strcmp(ProjctCdeS,"5558")==0||tc_strcmp(ProjctCdeS,"5559")==0||tc_strcmp(ProjctCdeS,"5560")==0
			||tc_strcmp(ProjctCdeS,"5562")==0||tc_strcmp(ProjctCdeS,"5564")==0||tc_strcmp(ProjctCdeS,"5567")==0||tc_strcmp(ProjctCdeS,"5568")==0||tc_strcmp(ProjctCdeS,"5569")==0||tc_strcmp(ProjctCdeS,"5855")==0||tc_strcmp(ProjctCdeS,"5710")==0||tc_strcmp(ProjctCdeS,"5709")==0
			||tc_strcmp(ProjctCdeS,"2534")==0||tc_strcmp(ProjctCdeS,"2527")==0||tc_strcmp(ProjctCdeS,"5706")==0||tc_strcmp(ProjctCdeS,"5701")==0||tc_strcmp(ProjctCdeS,"5020")==0||tc_strcmp(ProjctCdeS,"2789")==0||tc_strcmp(ProjctCdeS,"5735")==0||tc_strcmp(ProjctCdeS,"2724")==0
			||tc_strcmp(ProjctCdeS,"5737")==0||tc_strcmp(ProjctCdeS,"2525")==0||tc_strcmp(ProjctCdeS,"2726")==0||tc_strcmp(ProjctCdeS,"2851")==0||tc_strcmp(ProjctCdeS,"5736")==0||tc_strcmp(ProjctCdeS,"5810")==0||tc_strcmp(ProjctCdeS,"5803")==0||tc_strcmp(ProjctCdeS,"2661")==0
			||tc_strcmp(ProjctCdeS,"5830")==0||tc_strcmp(ProjctCdeS,"2715")==0||tc_strcmp(ProjctCdeS,"5841")==0||tc_strcmp(ProjctCdeS,"2850")==0||tc_strcmp(ProjctCdeS,"2855")==0||tc_strcmp(ProjctCdeS,"2732")==0||tc_strcmp(ProjctCdeS,"2691")==0||tc_strcmp(ProjctCdeS,"5817")==0
			||tc_strcmp(ProjctCdeS,"5805")==0||tc_strcmp(ProjctCdeS,"5857")==0||tc_strcmp(ProjctCdeS,"2663")==0||tc_strcmp(ProjctCdeS,"5829")==0||tc_strcmp(ProjctCdeS,"2665")==0||tc_strcmp(ProjctCdeS,"2736")==0||tc_strcmp(ProjctCdeS,"5836")==0||tc_strcmp(ProjctCdeS,"2668")==0
			||tc_strcmp(ProjctCdeS,"2684")==0||tc_strcmp(ProjctCdeS,"2730")==0||tc_strcmp(ProjctCdeS,"2739")==0||tc_strcmp(ProjctCdeS,"5845")==0||tc_strcmp(ProjctCdeS,"2687")==0||tc_strcmp(ProjctCdeS,"2854")==0||tc_strcmp(ProjctCdeS,"5843")==0||tc_strcmp(ProjctCdeS,"2727")==0
			||tc_strcmp(ProjctCdeS,"2069")==0||tc_strcmp(ProjctCdeS,"2076")==0||tc_strcmp(ProjctCdeS,"2786")==0||tc_strcmp(ProjctCdeS,"2863")==0||tc_strcmp(ProjctCdeS,"5716")==0||tc_strcmp(ProjctCdeS,"5719")==0||tc_strcmp(ProjctCdeS,"5821")==0||tc_strcmp(ProjctCdeS,"5723")==0
			||tc_strcmp(ProjctCdeS,"5826")==0||tc_strcmp(ProjctCdeS,"5827")==0||tc_strcmp(ProjctCdeS,"5846")==0||tc_strcmp(ProjctCdeS,"2865")==0||tc_strcmp(ProjctCdeS,"2520")==0||tc_strcmp(ProjctCdeS,"2521")==0||tc_strcmp(ProjctCdeS,"2523")==0||tc_strcmp(ProjctCdeS,"2524")==0
			||tc_strcmp(ProjctCdeS,"2533")==0||tc_strcmp(ProjctCdeS,"2667")==0||tc_strcmp(ProjctCdeS,"2845")==0||tc_strcmp(ProjctCdeS,"2163")==0||tc_strcmp(ProjctCdeS,"5218")==0||tc_strcmp(ProjctCdeS,"5724")==0||tc_strcmp(ProjctCdeS,"2747")==0||tc_strcmp(ProjctCdeS,"5080")==0
			||tc_strcmp(ProjctCdeS,"5197")==0||tc_strcmp(ProjctCdeS,"5088")==0||tc_strcmp(ProjctCdeS,"2060")==0||tc_strcmp(ProjctCdeS,"2157")==0||tc_strcmp(ProjctCdeS,"2217")==0||tc_strcmp(ProjctCdeS,"2540")==0||tc_strcmp(ProjctCdeS,"2632")==0||tc_strcmp(ProjctCdeS,"2706")==0
			||tc_strcmp(ProjctCdeS,"5741")==0||tc_strcmp(ProjctCdeS,"5565")==0||tc_strcmp(ProjctCdeS,"2063")==0||tc_strcmp(ProjctCdeS,"2158")==0||tc_strcmp(ProjctCdeS,"2219")==0||tc_strcmp(ProjctCdeS,"2541")==0||tc_strcmp(ProjctCdeS,"2636")==0||tc_strcmp(ProjctCdeS,"2707")==0
			||tc_strcmp(ProjctCdeS,"5724")==0||tc_strcmp(ProjctCdeS,"5043")==0||tc_strcmp(ProjctCdeS,"2064")==0||tc_strcmp(ProjctCdeS,"2159")==0||tc_strcmp(ProjctCdeS,"2220")==0||tc_strcmp(ProjctCdeS,"2543")==0||tc_strcmp(ProjctCdeS,"2640")==0||tc_strcmp(ProjctCdeS,"2708")==0
			||tc_strcmp(ProjctCdeS,"5008")==0||tc_strcmp(ProjctCdeS,"2167")==0||tc_strcmp(ProjctCdeS,"2066")==0||tc_strcmp(ProjctCdeS,"2160")==0||tc_strcmp(ProjctCdeS,"2221")==0||tc_strcmp(ProjctCdeS,"2547")==0||tc_strcmp(ProjctCdeS,"2643")==0||tc_strcmp(ProjctCdeS,"2711")==0
			||tc_strcmp(ProjctCdeS,"2750")==0||tc_strcmp(ProjctCdeS,"2809")==0||tc_strcmp(ProjctCdeS,"2067")==0||tc_strcmp(ProjctCdeS,"2161")==0||tc_strcmp(ProjctCdeS,"2222")==0||tc_strcmp(ProjctCdeS,"2548")==0||tc_strcmp(ProjctCdeS,"2644")==0||tc_strcmp(ProjctCdeS,"2719")==0
			||tc_strcmp(ProjctCdeS,"5714")==0||tc_strcmp(ProjctCdeS,"2227")==0||tc_strcmp(ProjctCdeS,"2068")==0||tc_strcmp(ProjctCdeS,"2162")==0||tc_strcmp(ProjctCdeS,"2225")==0||tc_strcmp(ProjctCdeS,"2549")==0||tc_strcmp(ProjctCdeS,"2645")==0||tc_strcmp(ProjctCdeS,"2721")==0
			||tc_strcmp(ProjctCdeS,"5081")==0||tc_strcmp(ProjctCdeS,"5085")==0||tc_strcmp(ProjctCdeS,"2070")==0||tc_strcmp(ProjctCdeS,"2177")==0||tc_strcmp(ProjctCdeS,"2226")==0||tc_strcmp(ProjctCdeS,"2571")==0||tc_strcmp(ProjctCdeS,"2653")==0||tc_strcmp(ProjctCdeS,"2722")==0
			||tc_strcmp(ProjctCdeS,"5069")==0||tc_strcmp(ProjctCdeS,"2834")==0||tc_strcmp(ProjctCdeS,"2071")==0||tc_strcmp(ProjctCdeS,"2178")==0||tc_strcmp(ProjctCdeS,"2228")==0||tc_strcmp(ProjctCdeS,"2572")==0||tc_strcmp(ProjctCdeS,"2657")==0||tc_strcmp(ProjctCdeS,"2729")==0
			||tc_strcmp(ProjctCdeS,"4106")==0||tc_strcmp(ProjctCdeS,"2921")==0||tc_strcmp(ProjctCdeS,"2074")==0||tc_strcmp(ProjctCdeS,"2179")==0||tc_strcmp(ProjctCdeS,"2229")==0||tc_strcmp(ProjctCdeS,"2573")==0||tc_strcmp(ProjctCdeS,"2658")==0||tc_strcmp(ProjctCdeS,"2731")==0
			||tc_strcmp(ProjctCdeS,"5087")==0||tc_strcmp(ProjctCdeS,"5216")==0||tc_strcmp(ProjctCdeS,"2077")==0||tc_strcmp(ProjctCdeS,"2182")==0||tc_strcmp(ProjctCdeS,"2231")==0||tc_strcmp(ProjctCdeS,"2575")==0||tc_strcmp(ProjctCdeS,"2659")==0||tc_strcmp(ProjctCdeS,"2733")==0
			||tc_strcmp(ProjctCdeS,"5872")==0||tc_strcmp(ProjctCdeS,"2846")==0||tc_strcmp(ProjctCdeS,"2078")==0||tc_strcmp(ProjctCdeS,"2185")==0||tc_strcmp(ProjctCdeS,"2233")==0||tc_strcmp(ProjctCdeS,"2576")==0||tc_strcmp(ProjctCdeS,"2660")==0||tc_strcmp(ProjctCdeS,"2737")==0
			||tc_strcmp(ProjctCdeS,"2880")==0||tc_strcmp(ProjctCdeS,"5535")==0||tc_strcmp(ProjctCdeS,"2080")==0||tc_strcmp(ProjctCdeS,"2186")==0||tc_strcmp(ProjctCdeS,"2234")==0||tc_strcmp(ProjctCdeS,"2587")==0||tc_strcmp(ProjctCdeS,"2662")==0||tc_strcmp(ProjctCdeS,"2741")==0
			||tc_strcmp(ProjctCdeS,"5007")==0||tc_strcmp(ProjctCdeS,"4105")==0||tc_strcmp(ProjctCdeS,"2081")==0||tc_strcmp(ProjctCdeS,"2187")==0||tc_strcmp(ProjctCdeS,"2235")==0||tc_strcmp(ProjctCdeS,"2588")==0||tc_strcmp(ProjctCdeS,"2664")==0||tc_strcmp(ProjctCdeS,"2752")==0
			||tc_strcmp(ProjctCdeS,"5740")==0||tc_strcmp(ProjctCdeS,"2756")==0||tc_strcmp(ProjctCdeS,"2082")==0||tc_strcmp(ProjctCdeS,"2189")==0||tc_strcmp(ProjctCdeS,"2239")==0||tc_strcmp(ProjctCdeS,"2594")==0||tc_strcmp(ProjctCdeS,"2669")==0||tc_strcmp(ProjctCdeS,"2755")==0
			||tc_strcmp(ProjctCdeS,"5873")==0||tc_strcmp(ProjctCdeS,"5199")==0||tc_strcmp(ProjctCdeS,"2085")==0||tc_strcmp(ProjctCdeS,"2190")==0||tc_strcmp(ProjctCdeS,"2241")==0||tc_strcmp(ProjctCdeS,"2596")==0||tc_strcmp(ProjctCdeS,"2678")==0||tc_strcmp(ProjctCdeS,"2757")==0
			||tc_strcmp(ProjctCdeS,"5006")==0||tc_strcmp(ProjctCdeS,"2747")==0||tc_strcmp(ProjctCdeS,"2087")==0||tc_strcmp(ProjctCdeS,"2191")==0||tc_strcmp(ProjctCdeS,"2242")==0||tc_strcmp(ProjctCdeS,"2599")==0||tc_strcmp(ProjctCdeS,"2682")==0||tc_strcmp(ProjctCdeS,"2760")==0
			||tc_strcmp(ProjctCdeS,"2505")==0||tc_strcmp(ProjctCdeS,"5876")==0||tc_strcmp(ProjctCdeS,"2088")==0||tc_strcmp(ProjctCdeS,"2192")==0||tc_strcmp(ProjctCdeS,"2506")==0||tc_strcmp(ProjctCdeS,"2601")==0||tc_strcmp(ProjctCdeS,"2688")==0||tc_strcmp(ProjctCdeS,"2763")==0
			||tc_strcmp(ProjctCdeS,"5004")==0||tc_strcmp(ProjctCdeS,"5217")==0||tc_strcmp(ProjctCdeS,"2089")==0||tc_strcmp(ProjctCdeS,"2193")==0||tc_strcmp(ProjctCdeS,"2507")==0||tc_strcmp(ProjctCdeS,"2604")==0||tc_strcmp(ProjctCdeS,"2689")==0||tc_strcmp(ProjctCdeS,"2767")==0
			||tc_strcmp(ProjctCdeS,"5151")==0||tc_strcmp(ProjctCdeS,"5416")==0||tc_strcmp(ProjctCdeS,"2091")==0||tc_strcmp(ProjctCdeS,"2194")==0||tc_strcmp(ProjctCdeS,"2508")==0||tc_strcmp(ProjctCdeS,"2608")==0||tc_strcmp(ProjctCdeS,"2690")==0||tc_strcmp(ProjctCdeS,"2768")==0
			||tc_strcmp(ProjctCdeS,"5875")==0||tc_strcmp(ProjctCdeS,"5799")==0||tc_strcmp(ProjctCdeS,"2093")==0||tc_strcmp(ProjctCdeS,"2195")==0||tc_strcmp(ProjctCdeS,"2510")==0||tc_strcmp(ProjctCdeS,"2612")==0||tc_strcmp(ProjctCdeS,"2692")==0||tc_strcmp(ProjctCdeS,"2771")==0
			||tc_strcmp(ProjctCdeS,"5063")==0||tc_strcmp(ProjctCdeS,"5214")==0||tc_strcmp(ProjctCdeS,"2096")==0||tc_strcmp(ProjctCdeS,"2197")==0||tc_strcmp(ProjctCdeS,"2515")==0||tc_strcmp(ProjctCdeS,"2614")==0||tc_strcmp(ProjctCdeS,"2695")==0||tc_strcmp(ProjctCdeS,"2774")==0
			||tc_strcmp(ProjctCdeS,"5215")==0||tc_strcmp(ProjctCdeS,"5572")==0||tc_strcmp(ProjctCdeS,"2097")==0||tc_strcmp(ProjctCdeS,"2198")==0||tc_strcmp(ProjctCdeS,"2516")==0||tc_strcmp(ProjctCdeS,"2617")==0||tc_strcmp(ProjctCdeS,"2696")==0||tc_strcmp(ProjctCdeS,"2775")==0
			||tc_strcmp(ProjctCdeS,"5218")==0||tc_strcmp(ProjctCdeS,"5571")==0||tc_strcmp(ProjctCdeS,"2101")==0||tc_strcmp(ProjctCdeS,"2206")==0||tc_strcmp(ProjctCdeS,"2518")==0||tc_strcmp(ProjctCdeS,"2618")==0||tc_strcmp(ProjctCdeS,"2698")==0||tc_strcmp(ProjctCdeS,"2777")==0
			||tc_strcmp(ProjctCdeS,"5742")==0||tc_strcmp(ProjctCdeS,"5220")==0||tc_strcmp(ProjctCdeS,"2103")==0||tc_strcmp(ProjctCdeS,"2207")==0||tc_strcmp(ProjctCdeS,"2519")==0||tc_strcmp(ProjctCdeS,"2621")==0||tc_strcmp(ProjctCdeS,"2699")==0||tc_strcmp(ProjctCdeS,"2778")==0
			||tc_strcmp(ProjctCdeS,"5743")==0||tc_strcmp(ProjctCdeS,"2928")==0||tc_strcmp(ProjctCdeS,"2109")==0||tc_strcmp(ProjctCdeS,"2212")==0||tc_strcmp(ProjctCdeS,"2522")==0||tc_strcmp(ProjctCdeS,"2625")==0||tc_strcmp(ProjctCdeS,"2700")==0||tc_strcmp(ProjctCdeS,"2779")==0
			||tc_strcmp(ProjctCdeS,"5570")==0||tc_strcmp(ProjctCdeS,"1111")==0||tc_strcmp(ProjctCdeS,"2150")==0||tc_strcmp(ProjctCdeS,"2213")==0||tc_strcmp(ProjctCdeS,"2529")==0||tc_strcmp(ProjctCdeS,"2628")==0||tc_strcmp(ProjctCdeS,"2701")==0||tc_strcmp(ProjctCdeS,"2780")==0
			||tc_strcmp(ProjctCdeS,"5070")==0||tc_strcmp(ProjctCdeS,"2001")==0||tc_strcmp(ProjctCdeS,"2153")==0||tc_strcmp(ProjctCdeS,"2214")==0||tc_strcmp(ProjctCdeS,"2530")==0||tc_strcmp(ProjctCdeS,"2630")==0||tc_strcmp(ProjctCdeS,"2702")==0||tc_strcmp(ProjctCdeS,"2781")==0
			||tc_strcmp(ProjctCdeS,"5080")==0||tc_strcmp(ProjctCdeS,"2050")==0||tc_strcmp(ProjctCdeS,"2154")==0||tc_strcmp(ProjctCdeS,"2215")==0||tc_strcmp(ProjctCdeS,"2536")==0||tc_strcmp(ProjctCdeS,"2631")==0||tc_strcmp(ProjctCdeS,"2704")==0||tc_strcmp(ProjctCdeS,"2782")==0
			||tc_strcmp(ProjctCdeS,"2783")==0||tc_strcmp(ProjctCdeS,"2826")==0||tc_strcmp(ProjctCdeS,"2870")==0||tc_strcmp(ProjctCdeS,"3502")==0||tc_strcmp(ProjctCdeS,"5036")==0||tc_strcmp(ProjctCdeS,"5074")==0||tc_strcmp(ProjctCdeS,"5131")==0||tc_strcmp(ProjctCdeS,"5708")==0 
		   	||tc_strcmp(ProjctCdeS,"2784")==0||tc_strcmp(ProjctCdeS,"2827")==0||tc_strcmp(ProjctCdeS,"2871")==0||tc_strcmp(ProjctCdeS,"4101")==0||tc_strcmp(ProjctCdeS,"5037")==0||tc_strcmp(ProjctCdeS,"5075")==0||tc_strcmp(ProjctCdeS,"5132")==0||tc_strcmp(ProjctCdeS,"5715")==0
		   	||tc_strcmp(ProjctCdeS,"2785")==0||tc_strcmp(ProjctCdeS,"2828")==0||tc_strcmp(ProjctCdeS,"2872")==0||tc_strcmp(ProjctCdeS,"4102")==0||tc_strcmp(ProjctCdeS,"5041")==0||tc_strcmp(ProjctCdeS,"5076")==0||tc_strcmp(ProjctCdeS,"5135")==0||tc_strcmp(ProjctCdeS,"5717")==0
		   	||tc_strcmp(ProjctCdeS,"2787")==0||tc_strcmp(ProjctCdeS,"2830")==0||tc_strcmp(ProjctCdeS,"2873")==0||tc_strcmp(ProjctCdeS,"4104")==0||tc_strcmp(ProjctCdeS,"5042")==0||tc_strcmp(ProjctCdeS,"5077")==0||tc_strcmp(ProjctCdeS,"5136")==0||tc_strcmp(ProjctCdeS,"5718")==0
		   	||tc_strcmp(ProjctCdeS,"2788")==0||tc_strcmp(ProjctCdeS,"2833")==0||tc_strcmp(ProjctCdeS,"2874")==0||tc_strcmp(ProjctCdeS,"4181")==0||tc_strcmp(ProjctCdeS,"5044")==0||tc_strcmp(ProjctCdeS,"5079")==0||tc_strcmp(ProjctCdeS,"5141")==0||tc_strcmp(ProjctCdeS,"5734")==0
		   	||tc_strcmp(ProjctCdeS,"2790")==0||tc_strcmp(ProjctCdeS,"2838")==0||tc_strcmp(ProjctCdeS,"2876")==0||tc_strcmp(ProjctCdeS,"4183")==0||tc_strcmp(ProjctCdeS,"5045")==0||tc_strcmp(ProjctCdeS,"5086")==0||tc_strcmp(ProjctCdeS,"5143")==0||tc_strcmp(ProjctCdeS,"5739")==0
		   	||tc_strcmp(ProjctCdeS,"2791")==0||tc_strcmp(ProjctCdeS,"2839")==0||tc_strcmp(ProjctCdeS,"2879")==0||tc_strcmp(ProjctCdeS,"5003")==0||tc_strcmp(ProjctCdeS,"5046")==0||tc_strcmp(ProjctCdeS,"5090")==0||tc_strcmp(ProjctCdeS,"5149")==0||tc_strcmp(ProjctCdeS,"5801")==0
		   	||tc_strcmp(ProjctCdeS,"2792")==0||tc_strcmp(ProjctCdeS,"2840")==0||tc_strcmp(ProjctCdeS,"2881")==0||tc_strcmp(ProjctCdeS,"5005")==0||tc_strcmp(ProjctCdeS,"5048")==0||tc_strcmp(ProjctCdeS,"5091")==0||tc_strcmp(ProjctCdeS,"5194")==0||tc_strcmp(ProjctCdeS,"5802")==0
		   	||tc_strcmp(ProjctCdeS,"2797")==0||tc_strcmp(ProjctCdeS,"2842")==0||tc_strcmp(ProjctCdeS,"2882")==0||tc_strcmp(ProjctCdeS,"5009")==0||tc_strcmp(ProjctCdeS,"5049")==0||tc_strcmp(ProjctCdeS,"5096")==0||tc_strcmp(ProjctCdeS,"5505")==0||tc_strcmp(ProjctCdeS,"5806")==0
		   	||tc_strcmp(ProjctCdeS,"2798")==0||tc_strcmp(ProjctCdeS,"2843")==0||tc_strcmp(ProjctCdeS,"2883")==0||tc_strcmp(ProjctCdeS,"5010")==0||tc_strcmp(ProjctCdeS,"5050")==0||tc_strcmp(ProjctCdeS,"5101")==0||tc_strcmp(ProjctCdeS,"5511")==0||tc_strcmp(ProjctCdeS,"5807")==0
		   	||tc_strcmp(ProjctCdeS,"2799")==0||tc_strcmp(ProjctCdeS,"2849")==0||tc_strcmp(ProjctCdeS,"2884")==0||tc_strcmp(ProjctCdeS,"5011")==0||tc_strcmp(ProjctCdeS,"5053")==0||tc_strcmp(ProjctCdeS,"5102")==0||tc_strcmp(ProjctCdeS,"5516")==0||tc_strcmp(ProjctCdeS,"5809")==0
		   	||tc_strcmp(ProjctCdeS,"2801")==0||tc_strcmp(ProjctCdeS,"2852")==0||tc_strcmp(ProjctCdeS,"2886")==0||tc_strcmp(ProjctCdeS,"5012")==0||tc_strcmp(ProjctCdeS,"5055")==0||tc_strcmp(ProjctCdeS,"5103")==0||tc_strcmp(ProjctCdeS,"5517")==0||tc_strcmp(ProjctCdeS,"5811")==0
		   	||tc_strcmp(ProjctCdeS,"2802")==0||tc_strcmp(ProjctCdeS,"2853")==0||tc_strcmp(ProjctCdeS,"2887")==0||tc_strcmp(ProjctCdeS,"5013")==0||tc_strcmp(ProjctCdeS,"5056")==0||tc_strcmp(ProjctCdeS,"5105")==0||tc_strcmp(ProjctCdeS,"5519")==0||tc_strcmp(ProjctCdeS,"5812")==0
		   	||tc_strcmp(ProjctCdeS,"2803")==0||tc_strcmp(ProjctCdeS,"2856")==0||tc_strcmp(ProjctCdeS,"2888")==0||tc_strcmp(ProjctCdeS,"5014")==0||tc_strcmp(ProjctCdeS,"5057")==0||tc_strcmp(ProjctCdeS,"5106")==0||tc_strcmp(ProjctCdeS,"5520")==0||tc_strcmp(ProjctCdeS,"5813")==0
		   	||tc_strcmp(ProjctCdeS,"2805")==0||tc_strcmp(ProjctCdeS,"2857")==0||tc_strcmp(ProjctCdeS,"2889")==0||tc_strcmp(ProjctCdeS,"5016")==0||tc_strcmp(ProjctCdeS,"5058")==0||tc_strcmp(ProjctCdeS,"5107")==0||tc_strcmp(ProjctCdeS,"5524")==0||tc_strcmp(ProjctCdeS,"5814")==0
		   	||tc_strcmp(ProjctCdeS,"2806")==0||tc_strcmp(ProjctCdeS,"2858")==0||tc_strcmp(ProjctCdeS,"2892")==0||tc_strcmp(ProjctCdeS,"5018")==0||tc_strcmp(ProjctCdeS,"5059")==0||tc_strcmp(ProjctCdeS,"5109")==0||tc_strcmp(ProjctCdeS,"5526")==0||tc_strcmp(ProjctCdeS,"5816")==0
		   	||tc_strcmp(ProjctCdeS,"2807")==0||tc_strcmp(ProjctCdeS,"2859")==0||tc_strcmp(ProjctCdeS,"2895")==0||tc_strcmp(ProjctCdeS,"5019")==0||tc_strcmp(ProjctCdeS,"5060")==0||tc_strcmp(ProjctCdeS,"5121")==0||tc_strcmp(ProjctCdeS,"5538")==0||tc_strcmp(ProjctCdeS,"5819")==0
		   	||tc_strcmp(ProjctCdeS,"2808")==0||tc_strcmp(ProjctCdeS,"2862")==0||tc_strcmp(ProjctCdeS,"2912")==0||tc_strcmp(ProjctCdeS,"5022")==0||tc_strcmp(ProjctCdeS,"5064")==0||tc_strcmp(ProjctCdeS,"5122")==0||tc_strcmp(ProjctCdeS,"5539")==0||tc_strcmp(ProjctCdeS,"5820")==0
		   	||tc_strcmp(ProjctCdeS,"2819")==0||tc_strcmp(ProjctCdeS,"2864")==0||tc_strcmp(ProjctCdeS,"2913")==0||tc_strcmp(ProjctCdeS,"5026")==0||tc_strcmp(ProjctCdeS,"5066")==0||tc_strcmp(ProjctCdeS,"5123")==0||tc_strcmp(ProjctCdeS,"5552")==0||tc_strcmp(ProjctCdeS,"5823")==0
		   	||tc_strcmp(ProjctCdeS,"2820")==0||tc_strcmp(ProjctCdeS,"2866")==0||tc_strcmp(ProjctCdeS,"2916")==0||tc_strcmp(ProjctCdeS,"5028")==0||tc_strcmp(ProjctCdeS,"5068")==0||tc_strcmp(ProjctCdeS,"5124")==0||tc_strcmp(ProjctCdeS,"5702")==0||tc_strcmp(ProjctCdeS,"5825")==0
		   	||tc_strcmp(ProjctCdeS,"2822")==0||tc_strcmp(ProjctCdeS,"2867")==0||tc_strcmp(ProjctCdeS,"2917")==0||tc_strcmp(ProjctCdeS,"5030")==0||tc_strcmp(ProjctCdeS,"5071")==0||tc_strcmp(ProjctCdeS,"5125")==0||tc_strcmp(ProjctCdeS,"5703")==0||tc_strcmp(ProjctCdeS,"5828")==0
		   	||tc_strcmp(ProjctCdeS,"2823")==0||tc_strcmp(ProjctCdeS,"2868")==0||tc_strcmp(ProjctCdeS,"2999")==0||tc_strcmp(ProjctCdeS,"5031")==0||tc_strcmp(ProjctCdeS,"5072")==0||tc_strcmp(ProjctCdeS,"5128")==0||tc_strcmp(ProjctCdeS,"5705")==0||tc_strcmp(ProjctCdeS,"5832")==0
		   	||tc_strcmp(ProjctCdeS,"2825")==0||tc_strcmp(ProjctCdeS,"2869")==0||tc_strcmp(ProjctCdeS,"3501")==0||tc_strcmp(ProjctCdeS,"5033")==0||tc_strcmp(ProjctCdeS,"5073")==0||tc_strcmp(ProjctCdeS,"5129")==0||tc_strcmp(ProjctCdeS,"5707")==0||tc_strcmp(ProjctCdeS,"5842")==0
		    ||tc_strcmp(ProjctCdeS,"7700")==0||tc_strcmp(ProjctCdeS,"7703")==0||tc_strcmp(ProjctCdeS,"7704")==0||tc_strcmp(ProjctCdeS,"5713")==0||tc_strcmp(ProjctCdeS,"5219")==0||tc_strcmp(ProjctCdeS,"5221")==0||tc_strcmp(ProjctCdeS,"5222")==0||tc_strcmp(ProjctCdeS,"5572")==0
			||tc_strcmp(ProjctCdeS,"5573")==0||tc_strcmp(ProjctCdeS,"5575")==0||tc_strcmp(ProjctCdeS,"5576")==0||tc_strcmp(ProjctCdeS,"5577")==0||tc_strcmp(ProjctCdeS,"5880")==0||tc_strcmp(ProjctCdeS,"5881")==0||tc_strcmp(ProjctCdeS,"5882")==0||tc_strcmp(ProjctCdeS,"5220")==0
			||tc_strcmp(ProjctCdeS,"5223")==0||tc_strcmp(ProjctCdeS,"5878")==0)
			{
				printf("\n PROJECT CODE FOUND [%s] \n", ProjctCdeS);fflush(stdout);

				if (tc_strstr(pdfpath,".pdf")!=NULL)
				{
					printf("\n PDF FOUND \n");fflush(stdout);
					ITK_CALL(AE_find_datasettype2("PDF",&DatasetType));

					if((tc_strcmp(PartTypeS,"DFA")==0)||(tc_strcmp(PartTypeS,"DFS")==0)||(tc_strcmp(PartTypeS,"DFM")==0))
					{
						ITK_CALL(ITEM_find_item (DADNumber,&dad_tag));
						//ITK_CALL(ITEM_find_item (T5_DAD_Document_item_id,&dad_tag));//changed
						if (dad_tag!=NULLTAG)
						{
							printf("\n  T5_DADDoc already exists \n");fflush(stdout);
						}
						else
						{
							printf("\n  T5_DADDoc does not exist hence creating \n");fflush(stdout);
							//ITK_CALL(TCTYPE_find_types_for_class("T5_DADDoc",&number_of_types1,&type_tag3));
							ITK_CALL( TCTYPE_find_type( "T5_DADDoc", NULL, &type_tag3) );
							//ITK_CALL ( TCTYPE_ask_object_type ( wsobj_tag [ wsobj_index ], &wsob_type ) ) ;
							printf("\n number_of_types T5_DADDoc-------->  : %d\n",number_of_types1);fflush(stdout);
							ITK_CALL(TCTYPE_construct_create_input(type_tag3, &object_create_input_tag3));

							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"item_id",DADNumber));
							ITK_CALL(AOM_ask_value_string(object_create_input_tag3,"item_id",&DADname));
							printf("\n DADname:%s",DADname);fflush(stdout);

							//ITK_CALL(AOM_set_value_string(object_create_input_tag3,"item_id",T5_DAD_Document_item_id));
							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc","PFIRST DATA"));

							printf("\n test 123 \n");fflush(stdout);
							printf("\nDADNumber:%s\n",DADNumber);fflush(stdout);
							printf("\n test 123 \n");fflush(stdout);
							printf("\n curentnameid:%s \n",curentnameid);fflush(stdout);

							//ITK_CALL(ITEM_create_item(DADNumber,DADNumber,"T5_DADDoc",curentnameid,&dad_tag,&dadrev_tag));

							ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));			//DFA Item Master
							//CALLAPI( TCTYPE_create_object(object_create_input_tag3, &dad_tag) );
							printf("\n 4d obj dad_tag created......\n");fflush(stdout);


							if(dad_tag)
								{
									ITK_CALL(AOM_save(dad_tag));
									ITK_CALL(AOM_refresh(dad_tag,0));
									ITK_CALL(AOM_unlock(dad_tag));
									printf("\n  object created.\n"); fflush(stdout);
								}

							printf("\n afterrrrrrr 4d obj dad_tag created finding revision  now......\n");fflush(stdout);
						//}

							//ITK_CALL(ITEM_find_revision(dad_tag,nwRev,&rev));
							if(ITEM_ask_latest_rev(dad_tag,&DADrevTag));					//DFA Item Revision

							printf("\n AFTER 4D_REV_TAG\n");fflush(stdout);
							if(AOM_lock(DADrevTag));
							ITK_CALL(AOM_set_value_string(DADrevTag,"t5_DsgnNum",DADNumber));
							ITK_CALL(AOM_set_value_string(DADrevTag,"item_revision_id","A;1"));//NEW CHANGE
							ITK_CALL(AOM_set_value_string(DADrevTag,"t5_DsgnAnlysisDocType",PartTypeS));//NEW CHANGE

							if(AOM_save(DADrevTag));
							if(AOM_unlock(DADrevTag));
							printf("\n AFTER setting value on dad revision \n");fflush(stdout);


							printf("\n CREATING RELATION BETWEEN PART AND DAD DOC\n");

							if(GRM_find_relation_type("T5_PartHas4D",&tRelationFind));

							if (tRelationFind!=NULLTAG && DADrevTag !=NULLTAG && DADrevTag!=NULLTAG)
							  {
								printf("\n TESTING HERE \n");fflush(stdout);
								ITK_CALL( GRM_find_relation(Latestrev_Tag,DADrevTag,tRelationFind,&tRelationExist));

								printf("\n AFTER TESTING HERE tRelationExist \n");fflush(stdout);
								if(tRelationExist)
								  {
									 printf("\n tRelationExist tRelationExist tRelationExist \n");fflush(stdout);
								  }
								  else
								  {
									  printf("\n tRelationExist DOES NOT EXIST HENCE CREATING \n");fflush(stdout);
									 ITK_CALL(GRM_create_relation(Latestrev_Tag,DADrevTag,tRelationFind,NULLTAG,&DADRel_t));//latest part revision and dad doc revision
									 //ITK_CALL(GRM_create_relation(Latestrev_Tag,dad_tag,tRelationFind,NULLTAG,&DADRel_t));
									 ITK_CALL(GRM_save_relation(DADRel_t));
									 ITK_CALL(AOM_refresh(Latestrev_Tag,0));
								  }
							  }

							ITK_CALL(GRM_find_relation_type("IMAN_specification", &relationSpeci_type));
							//ITK_CALL(GRM_find_relation_type("TC_Attaches", &relationSpeci_type));
							if(relationSpeci_type != NULLTAG)
							{
								printf("\n pdfpath  ---------------[%s] \n",pdfpath);fflush(stdout);
								printf("\n pdfpath1  ----------------- [%s] \n",pdfpath1);fflush(stdout);
								//ITK_CALL(AE_find_datasettype2("PDF",&DatasetType));
								ITK_CALL(AE_create_dataset_with_id(DatasetType,pdfpath1,"Dataset Creation Tool","","",&PdfDataset));

								ITK_CALL(AE_save_myself(PdfDataset));

								printf("\n PDF created \n");fflush(stdout);

								if(PdfDataset != NULLTAG)
								{

									printf("\n PdfDataset tag found as dataset registered \n");fflush(stdout);
									ITK_CALL(GRM_create_relation(DADrevTag,PdfDataset,relationSpeci_type,NULLTAG,&specificationRel_t));//dad doc revision and pdf
									//ITK_CALL(GRM_create_relation(Latestrev_Tag,PdfDataset,relationSpeci_type,NULLTAG,&specificationRel_t));
									ITK_CALL(AOM_load(specificationRel_t));
									ITK_CALL(GRM_save_relation(specificationRel_t));
									if(specificationRel_t != NULLTAG)
									{
										tag_t PdfLatestDat_t=NULLTAG;

										printf("\n Spec rel found  \n");fflush(stdout);

										ITK_CALL(AOM_refresh(PdfDataset,TRUE));
										printf("\n Spec rel found  222222 [%s]\n",pdfpath );fflush(stdout);

										ITK_CALL(AE_ask_dataset_latest_rev(PdfDataset,&PdfLatestDat_t));
										ITK_CALL(AOM_refresh(PdfLatestDat_t,TRUE));

										//ITK_CALL(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference","/tmp/DFM_544249201659_B_3_30.pdf",NULL,SS_BINARY));
										ITK_CALL(AE_import_named_ref(PdfDataset,"PDF_Reference",pdfpath,NULL,SS_BINARY));


										printf("\n Spec rel found  333333333 \n");fflush(stdout);
										//CALLAPI(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference",docFile,NULL,SS_BINARY));
										//ITK_CALL(AE_add_dataset_named_ref(tDataset,list[0],SS_BINARY,imannewFileTag));

										AOM_save(PdfLatestDat_t);
										AOM_refresh(PdfLatestDat_t, FALSE);
										AOM_unload(PdfLatestDat_t);
										ITK_CALL(AE_save_myself(PdfLatestDat_t));
										printf("\n AFTER IMPORTING NAMED REFERENCE \n");fflush(stdout);

										//return 0;

										printf("\n check in the 4D Doc \n");fflush(stdout);

										ITK_CALL(RES_is_checked_out(DADrevTag,&checkout));
										printf("\nValue of checkout Attribute in Checkin DADrevTag : [%d]\n",checkout);fflush(stdout);
										  if (checkout==1)
										  {
												ITK_CALL(RES_checkin(DADrevTag));
												printf("\n %d DADrevTag Checked In \n");
										  }

										ITK_CALL(RES_is_checked_out(PdfDataset,&checkout2));
										printf("\nValue of checkout Attribute in Checkin PdfDataset : [%d]\n",checkout2);fflush(stdout);
										  if (checkout2==1)
										  {
												ITK_CALL(RES_checkin(PdfDataset));
												printf("\n %d PdfDataset Checked In \n");
										  }


										ITK_CALL(WSOM_ask_release_status_list(Latestrev_Tag, &status_count, &relStatus_list));
										if(status_count>0)
										{
											for(ss=0; ss<status_count ; ss++)
											{
												ITK_CALL(AOM_ask_value_string(relStatus_list[ss],"object_name",&latest_rev_Rel_Stus));
												printf("\n latest_rev_Rel_Stus: %s \n",latest_rev_Rel_Stus);fflush(stdout);

												if((strcmp(latest_rev_Rel_Stus,"ERC Review")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsReview")==0))
												{
													if (CR_create_release_status("T5_LcsReview",&status_rel));
													ITK_CALL( AOM_ask_name(status_rel, &ReleaseStatus));
													if(EPM_add_release_status(status_rel,1,&DADrevTag,retain));
													printf("\n after setting review status to the 4D Doc \n");fflush(stdout);

													//if (CR_create_release_status("T5_LcsReview",&status_relpdf));
													//ITK_CALL( AOM_ask_name(status_relpdf, &ReleaseStatuspdf));
													//if(EPM_add_release_status(status_relpdf,1,&PdfDataset,retainpdf));
													//printf("\n after setting review status to the 4D PDF \n");fflush(stdout);

												}

												else if((strcmp(latest_rev_Rel_Stus,"ERC Released")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsErcRlzd")==0))
												{
													if (CR_create_release_status("T5_LcsErcRlzd",&status_rel));
													ITK_CALL( AOM_ask_name(status_rel, &ReleaseStatus));
													if(EPM_add_release_status(status_rel,1,&DADrevTag,retain));
													printf("\n after setting release status to the 4D Doc \n");fflush(stdout);

													//if (CR_create_release_status("T5_LcsErcRlzd",&status_relpdf));
													//ITK_CALL( AOM_ask_name(status_relpdf, &ReleaseStatuspdf));
													//if(EPM_add_release_status(status_relpdf,1,&PdfDataset,retainpdf));
													//printf("\n after setting release status to the 4D PDF \n");fflush(stdout);
												}
											}
										}
//
//
//										//ITK_CALL(RES_checkin(DADrevTag));
//										//printf("\n after check in the 4D Doc check in the pdf \n");fflush(stdout);
//										//ITK_CALL(RES_checkin(PdfDataset));
//										//printf("\n after pdf check in \n");fflush(stdout);
									}
								}
							}
						}
					}
				}
			}
			if(pdfpath!=NULL)
			{
				MEM_free(pdfpath);
			}
		}
//		else if (tc_strstr(inputline,".xls")!=NULL) //FOR D01
//		{
//			printf("\n  XLS hence creating DFMEA doc ------------------->\n"); fflush(stdout);
//			xlspath1 = NULL;
//			xlspath1 = (char *) MEM_alloc(tc_strlen(inputline)+2);
//			tc_strcpy(xlspath1,inputline);
//
//			xlspath = NULL;
//			xlspath = MEM_alloc(150);
//			tc_strcpy(xlspath,"");
//			//tc_strcat(xlspath,"/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/PDFFiles");
//			tc_strcat(xlspath,"/user/uaprod/shells/4D");
//			tc_strcat(xlspath,"/");
//			tc_strcat(xlspath,xlspath1);
//
//			removeNewLineChar(xlspath);
//			printf("\n after removal xlspath ----------------->	[%s]\n ",xlspath);fflush(stdout);
//
//			Typetokxls =NULL;
//			Parttokxls =NULL;
//			PartRevtokxls =NULL;
//			PartSeqtokxls =NULL;
//			SerialNumtokxls =NULL;
//
//			Typetokxls = tc_strtok(inputlinenew, "_");// DFA
//			Parttokxls = tc_strtok(NULL, "_");		// 1234567
//			PartRevtokxls = tc_strtok(NULL, "_");	//NR
//			PartSeqtokxls = tc_strtok(NULL, "_");	//1
//			SerialNumtokxls = tc_strtok(NULL, "_");//01
//
//			printf("\n Typetok D01to find----------> = %s\n", Typetokxls);fflush(stdout);
//			printf("\n Parttok  D01to find----------> = %s\n", Parttokxls);fflush(stdout);
//			printf("\n PartRevtok D01 to find----------> = %s\n", PartRevtokxls);fflush(stdout);
//			printf("\n PartSeqtok D01 to find----------> = %s\n", PartSeqtokxls);fflush(stdout);
//			printf("\n SerialNumtok D01 to find----------> = %s\n", SerialNumtokxls);fflush(stdout);
//
//			//return 0;
//
//			nwRevxls		=	NULL;
//			nwRevxls		=(char *) MEM_alloc(10);
//			tc_strcpy(nwRevxls,"");
//			tc_strcat(nwRevxls,PartRevtokxls);
//			tc_strcat(nwRevxls,"*");
//			tc_strcat(nwRevxls,PartSeqtokxls);
//			printf("\n  nwRevxls to find----------> = %s\n", nwRevxls);fflush(stdout);
//
//			PartTypeSxls = (char	*)MEM_alloc(10);
//			tc_strcpy(PartTypeSxls,Typetokxls);
//			printf("\n PartTypeSxls= [%s]\n",PartTypeSxls);fflush(stdout);
//
//			PartNumberSxls = (char	*)MEM_alloc(50);
//			tc_strcpy(PartNumberSxls,Parttokxls);
//			printf("\n Part Number to find = [%s]\n",PartNumberSxls);fflush(stdout);
//
//			ITK_CALL(ITEM_find_item (PartNumberSxls,&Part_tagxls));
//
//			if (Part_tagxls!=NULLTAG)
//			{
//				printf("\nPart_tag is not tag\n");fflush(stdout);
//			}
//			else
//			{
//				printf("\nPart_tag is null tag\n");fflush(stdout);
//			}
//
//			ITK_CALL(ITEM_ask_latest_rev(Part_tagxls,&latestrevxls));//latest rev of part
//
//			if( AOM_ask_value_string(latestrevxls,"object_string",&curentnamexls)==ITK_ok)
//
//			if( AOM_ask_value_string(latestrevxls,"t5_ProjectCode",&ProjctCdeSxls)==ITK_ok)
//
//			printf("\n Required revision---------------> [%s]and project code ---------->[%s]\n",curentnamexls,ProjctCdeSxls);fflush(stdout);
//
//			//return 0;
//			if(access(xlspath,F_OK)!=-1)
//			{
//				printf("\n FILE PRESENT qqqqqqqqqqqqqqqqqqqqqqqqqqqqQ  \n ");
//			}
//			else
//			{
//				printf("\n FILE NOT PRESENT qqqqqqqqqqqqqqqqqqqqqqqqqqqqQ  \n ");
//			}
//			system("pwd");
//
//		  if(tc_strcmp(ProjctCdeSxls,"2829")==0 || tc_strcmp(ProjctCdeSxls,"5442")==0 || tc_strcmp(ProjctCdeSxls,"5445")==0 || tc_strcmp(ProjctCdeSxls,"5447")==0 || tc_strcmp(ProjctCdeSxls,"5438")==0 || tc_strcmp(ProjctCdeSxls,"5457")==0)
//			{
//				printf("\n PROJECT CODE FOUND [%s] \n", ProjctCdeSxls);fflush(stdout);
//
//				if (tc_strstr(xlspath,".xlsx")!=NULL)
//				{
//					printf("\n XLSxxxxxx FOUND \n");fflush(stdout);
//					ITK_CALL(AE_find_datasettype2("MSExcelX",&DatasetTypexls));//CHECK THIS
//				}
//
//				else if (tc_strstr(xlspath,".xls")!=NULL)
//				{
//					printf("\n XLS FOUND \n");fflush(stdout);
//					ITK_CALL(AE_find_datasettype2("MSExcel",&DatasetTypexls));//CHECK THIS
//
//				}
//
//					if(tc_strcmp(PartTypeSxls,"D01")==0)
//					{
//						ITK_CALL(ITEM_find_item (DADNumber,&dad_tagxls));
//						if (dad_tagxls!=NULLTAG)
//						{
//							printf("\n  T5_DADDoc already exists \n");fflush(stdout);
//						}
//						else
//						{
//							printf("\n  T5_DADDoc does not exist hence creating \n");fflush(stdout);
//
//							//ITK_CALL( TCTYPE_find_type( "T5_Dfmea", NULL, &type_tag3xls) );
//							ITK_CALL(TCTYPE_find_types_for_class("T5_Dfmea",&number_of_types1xls,&type_tag3xls));//change this
//							printf("\n number_of_types T5_DADDoc-------->  : %d\n",number_of_types1xls);fflush(stdout);
//
//							ITK_CALL(TCTYPE_construct_create_input(type_tag3xls[0], &object_create_input_tag3xls));
//
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3xls,"item_id",DADNumber));
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3xls,"object_desc","PFIRST DATA"));
//							ITK_CALL(TCTYPE_create_object(object_create_input_tag3xls, &dad_tagxls));//DFA Item Master
//							printf("\n DFMEA obj dad_tag created......\n");
//							ITK_CALL(AOM_save(dad_tagxls));
//							printf("\n afterrrrrrr 4d obj dad_tag created finding revision  now......\n");
//						}
//
//						//ITK_CALL(ITEM_find_revision(dad_tagxls,nwRev,&rev));
//						if(ITEM_ask_latest_rev(dad_tagxls,&DADrevTagxls))					//D01 Item Revision
//
//						printf("\n AFTER 4D_REV_TAG\n");fflush(stdout);
//						if(AOM_lock(DADrevTagxls));
//						ITK_CALL(AOM_set_value_string(DADrevTagxls,"t5_DsgnNum",DADNumber));
//						ITK_CALL(AOM_set_value_string(DADrevTagxls,"item_revision_id","A;1"));//NEW CHANGE
//						ITK_CALL(AOM_set_value_string(DADrevTagxls,"t5_DsgnAnlysisDocType",PartTypeSxls));//NEW CHANGE
//						if(AOM_save(DADrevTagxls));
//						if(AOM_unlock(DADrevTagxls));
//						printf("\n AFTER setting value on dad revision \n");fflush(stdout);
//
//
//						printf("\n CREATING RELATION BETWEEN PART AND DAD DOC\n");
//
//						if(GRM_find_relation_type("T5_PartHasDfmea",&tRelationFindxls));
//
//						if (tRelationFindxls!=NULLTAG && DADrevTagxls !=NULLTAG )
//						  {
//							printf("\n TESTING HERE \n");fflush(stdout);
//							ITK_CALL( GRM_find_relation(latestrevxls,DADrevTagxls,tRelationFindxls,&tRelationExistxls));
//
//							printf("\n AFTER TESTING HERE tRelationExistxls \n");fflush(stdout);
//							if(tRelationExistxls)
//							  {
//								 printf("\n tRelationExistxls tRelationExist tRelationExist \n");fflush(stdout);
//							  }
//							  else
//							  {
//								  printf("\n tRelationExistxls DOES NOT EXIST HENCE CREATING \n");fflush(stdout);
//								 ITK_CALL(GRM_create_relation(latestrevxls,DADrevTagxls,tRelationFindxls,NULLTAG,&DADRel_txls));//latest part revision and dad doc revision
//								 //ITK_CALL(GRM_create_relation(Latestrev_Tag,dad_tag,tRelationFind,NULLTAG,&DADRel_t));
//								 ITK_CALL(GRM_save_relation(DADRel_txls));
//								 ITK_CALL(AOM_refresh(latestrevxls,0));
//							  }
//						  }
//
//					ITK_CALL(GRM_find_relation_type("IMAN_specification", &relationSpeci_typexls));
//				    //ITK_CALL(GRM_find_relation_type("TC_Attaches", &relationSpeci_type));
//					if(relationSpeci_typexls != NULLTAG)
//						{
//							printf("\n Attaches/IMAN SPECIFICATION Relationship tag found \n");fflush(stdout);
//							//ITK_CALL(AE_find_datasettype2("PDF",&DatasetType));
//							ITK_CALL(AE_create_dataset_with_id(DatasetTypexls,xlspath1,"Dataset Creation Tool","","",&XlsDataset));
//							ITK_CALL(AE_save_myself(XlsDataset));
//
//							printf("\n PDF created \n");fflush(stdout);
//
//							if(XlsDataset != NULLTAG)
//							{
//								printf("\n XlsDataset tag found as dataset registered \n");fflush(stdout);
//								ITK_CALL(GRM_create_relation(DADrevTagxls,XlsDataset,relationSpeci_typexls,NULLTAG,&specificationRel_txls));//dad doc revision and pdf
//								//ITK_CALL(GRM_create_relation(Latestrev_Tag,XlsDataset,relationSpeci_type,NULLTAG,&specificationRel_t));
//								//ITK_CALL(AOM_load(specificationRel_t));
//								ITK_CALL(GRM_save_relation(specificationRel_txls));
//								if(specificationRel_txls != NULLTAG)
//								{
//									printf("\n Spec rel found  \n");fflush(stdout);
//
//									ITK_CALL(AOM_refresh(XlsDataset,TRUE));
//									ITK_CALL(AE_import_named_ref(XlsDataset,"excel",xlspath,NULL,SS_BINARY));//check this
//									//ITK_CALL(AE_add_dataset_named_ref(tDataset,list[0],SS_BINARY,imannewFileTag));
//
//									AOM_save(XlsDataset);
//									AOM_refresh(XlsDataset, FALSE);
//									AOM_unload(XlsDataset);
//									ITK_CALL(AE_save_myself(XlsDataset));
//									printf("\n AFTER IMPORTING NAMED REFERENCE \n");fflush(stdout);
//
//									printf("\n check in the 4D Doc \n");fflush(stdout);
//
//									ITK_CALL(RES_is_checked_out(DADrevTagxls,&checkoutxls));
//								    printf("\nValue of checkoutxls Attribute in Checkin DADrevTagxls : [%d]\n",checkoutxls);fflush(stdout);
//									  if (checkoutxls==1)
//									  {
//											ITK_CALL(RES_checkin(DADrevTagxls));
//											printf("\n %d DADrevTagxls Checked In \n");
//									  }
//
//									ITK_CALL(RES_is_checked_out(XlsDataset,&checkout2xls));
//								    printf("\nValue of checkoutxls Attribute in Checkin PdfDataset : [%d]\n",checkout2xls);fflush(stdout);
//									  if (checkout2xls==1)
//									  {
//											ITK_CALL(RES_checkin(XlsDataset));
//											printf("\n %d XlsDataset Checked In \n");
//									  }
//
//
//									ITK_CALL(WSOM_ask_release_status_list(latestrevxls, &status_countxls, &relStatus_listxls));
//									if(status_countxls>0)
//									{
//										for(ss1=0; ss1<status_countxls ; ss1++)
//										{
//											ITK_CALL(AOM_ask_value_string(relStatus_listxls[ss1],"object_name",&latest_rev_Rel_Stusxls));
//											printf("\n latest_rev_Rel_Stusxls: %s \n",latest_rev_Rel_Stusxls);fflush(stdout);
//
//											if((tc_strcmp(latest_rev_Rel_Stusxls,"ERC Review")==0) || (tc_strcmp(latest_rev_Rel_Stusxls,"T5_LcsReview")==0))
//											{
//												if (CR_create_release_status("T5_LcsReview",&status_relxls));
//												ITK_CALL( AOM_ask_name(status_relxls, &ReleaseStatusxls));
//												if(EPM_add_release_status(status_relxls,1,&DADrevTagxls,retain));
//												printf("\n after setting review status to the 4D Doc \n");fflush(stdout);
//
//												//if (CR_create_release_status("T5_LcsReview",&status_relpdf));
//												//ITK_CALL( AOM_ask_name(status_relpdf, &ReleaseStatuspdf));
//												//if(EPM_add_release_status(status_relpdf,1,&PdfDataset,retainpdf));
//												//printf("\n after setting review status to the 4D PDF \n");fflush(stdout);
//
//											}
//
//											else if((tc_strcmp(latest_rev_Rel_Stusxls,"ERC Released")==0) || (tc_strcmp(latest_rev_Rel_Stusxls,"T5_LcsErcRlzd")==0))
//											{
//											   	if (CR_create_release_status("T5_LcsErcRlzd",&status_relxls));
//												ITK_CALL( AOM_ask_name(status_relxls, &ReleaseStatusxls));
//												if(EPM_add_release_status(status_relxls,1,&DADrevTagxls,retain));
//												printf("\n after setting release status to the 4D Doc \n");fflush(stdout);
//
//												//if (CR_create_release_status("T5_LcsErcRlzd",&status_relpdf));
//												//ITK_CALL( AOM_ask_name(status_relpdf, &ReleaseStatuspdf));
//												//if(EPM_add_release_status(status_relpdf,1,&PdfDataset,retainpdf));
//												//printf("\n after setting release status to the 4D PDF \n");fflush(stdout);
//											}
//										}
//									}
//
//
//									//ITK_CALL(RES_checkin(DADrevTag));
//									//printf("\n after check in the 4D Doc check in the pdf \n");fflush(stdout);
//									//ITK_CALL(RES_checkin(PdfDataset));
//									//printf("\n after pdf check in \n");fflush(stdout);
//								}
//							}
//						}
//					}
//				//}
//			}
//
//		}
//		++line_count;
	 }

  }
  else
  {
	printf("\n Error while opening input file \n");
	exit(1);
  }


  if(fptr)
	  {
	   fclose(fptr);fptr=NULL;
	  }
  return status;
}
;