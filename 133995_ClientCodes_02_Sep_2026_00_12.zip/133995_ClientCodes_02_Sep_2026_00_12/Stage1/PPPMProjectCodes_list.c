#include <stdio.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <ae/dataset.h>
#include <tc/tc.h>
#include <tccore/tctype.h>
#include <tccore/item.h>
#include <sa/user.h>
#include <sa/person.h>
#define NO_OF_PPPM_PROJECT 100
#define PPPM_PROJECT_NAME_DESC 2

struct PPPM_ProjectInfo
{
        char PPPM_PROJECT_CODE[80];
        char PROJECT_DESCSCRIPTION[80];
}
sProjectInfo;

struct ProjectVariant
{
        char TOTAL_VOLUME[80];
        char VARIANT_ID[80];
        char LOCATION[20];
        char VARIANT_NAME[20];
}
sProjectVariant;

struct ProjectBase
{
        char PPPM_PROJECT_CODE[80];
        char PROJECT_DESCSCRIPTION[80];
        char MANUF_LOC[20];
        char PRONEXT_PROJ_SRL[20];
        char BUSINESS_UNIT[20];
        char PROJ_CODE[20];
        struct ProjectVariant PrjVariant[50];
}
sProjectBase;



#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
//char **DMLList = (char **) MEM_alloc(200 * sizeof(char *));
char **DMLList = NULL;
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
char *replaceWord(const char *s, const char *oldW,
                                 const char *newW)
{
    char *result;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);

    for (i = 0; s[i] != '\0'; i++)
    {
        if (strstr(&s[i], oldW) == &s[i])
        {
            cnt++;

            i += oldWlen - 1;
        }
    }

    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;
    while (*s)
    {
		 if (strstr(s, oldW) == s)
        {
			 tc_strcpy(&result[i], newW);
            i += newWlen;
            s += oldWlen;
        }
        else
            result[i++] = *s++;
    }

    result[i] = '\0';
    return result;
}

int MyTokenize ( char *src , char *Delimiter , char **AllProjectDetails, int *iLen_Delimiter, int *iProjectCounter )
{
		const char *next = src;
		char *CompleteStr = NULL;
		int i = 0 ;
		int j = 0;
		int iProjCount = 0;
		printf ( "\nMyTokenize : MyTokenize started" ) ; fflush ( stdout ) ;
		//struct AllProjectDetails_node *start = NULL ;

        while ( ( next = strstr(src, Delimiter ) ) != NULL )
        {
                i = 0 ;
                CompleteStr = (char *)MEM_alloc ( 5000 ) ;
                tc_strcpy ( CompleteStr, "" ) ;
                while ( src != next )
                {
                        CompleteStr [ i ] = *src++ ;
                        i = i + 1 ;
                }
                CompleteStr [ i ] = '\0' ;
				tc_strcpy ( AllProjectDetails[iProjCount], CompleteStr ) ;
				iProjCount = iProjCount + 1;
                src += *iLen_Delimiter ;//increment string with delimeter length
                printf ( "\n\nMyTokenize : j : %d CompleteStr1 : %s", j , CompleteStr ) ; fflush ( stdout ) ;
                j = j + 1;

        }
        printf ( "\n\nMyTokenize : MyTokenize src2 : %s", src ) ; fflush ( stdout ) ;

        i = 0 ;
        j = j + 1 ;
        if (  strstr ( src, Delimiter ) == NULL  )
        {
                CompleteStr = ( char * ) MEM_alloc ( 5000 ) ;
        }
        tc_strcpy ( CompleteStr, "" ) ;
        while ( *src != '\0' )
        {
                CompleteStr [ i ] = *src++ ;
                //printf("\nCompleteStr [ %d ]:%c",i,CompleteStr [ i ]); fflush(stdout);
                i = i + 1 ;
        }
        CompleteStr [ i ] = '\0' ;
        printf ( "\nMyTokenize : CompleteStr [ %d ] : %c", i , CompleteStr [ i ] ) ; fflush ( stdout ) ;
        printf ( "\n\nMyTokenize : j : %d CompleteStr2 : %s", j , CompleteStr ) ; fflush ( stdout ) ;
		
		tc_strcpy ( AllProjectDetails[iProjCount], CompleteStr ) ;
		iProjCount = iProjCount + 1;
		*iProjectCounter = iProjCount;	//no of project added
        printf ( "\nMyTokenize : MyTokenize end" ) ; fflush ( stdout ) ;

		return 0 ;
}

int getProjectNameDesc ( char* AllProjectStr, struct PPPM_ProjectInfo mysProjectInfo[100], int *iPrjCounter )
{
	char **AllProjectInfo = NULL;
	int iProjCount = 0;
	int iLen_Delimiter_PrjInfo = -1 ;
    char *Delimiter_PrjInfo = "!@@!" ;
	int iProjectCounter = 0 ;
	int iProjectNameDescCounter = 0 ;
	int iLen_Delimiter_PrjNameDesc = -1;
    char *Delimiter_PrjNameDesc = "!-!" ;
	iLen_Delimiter_PrjInfo = strlen ( Delimiter_PrjInfo ) ;
	
	char **AllProjectNameDesc = NULL ;

	AllProjectInfo = ( char ** ) MEM_alloc ( NO_OF_PPPM_PROJECT * sizeof ( char * ) ) ;	//no of pppm project shown 100 
	for ( iProjCount = 0 ; iProjCount < NO_OF_PPPM_PROJECT  ; iProjCount++ )
	{
		AllProjectInfo[iProjCount] = ( char * ) MEM_alloc ( 150 * sizeof ( char ) ) ;	//project name and description string length 
	}

    printf ( "\ngetProjectNameDesc : iLen_Delimiter_PrjInfo : [%d]", iLen_Delimiter_PrjInfo ) ; fflush ( stdout ) ;
	printf ( "\ngetProjectNameDesc : AllProjectStr : [%s]", AllProjectStr ) ;

	AllProjectNameDesc = ( char ** ) MEM_alloc ( PPPM_PROJECT_NAME_DESC * sizeof ( char * ) ) ;	//Project Name and description count = 2 size array 
	for ( iProjCount = 0 ; iProjCount < PPPM_PROJECT_NAME_DESC  ; iProjCount++ )
	{
		AllProjectNameDesc[iProjCount] = ( char * ) MEM_alloc ( 150 * sizeof ( char ) ) ;	//project name and description string length 
	}
	
	printf ( "\ngetProjectNameDesc : before calling MyTokenize" ) ;
	MyTokenize ( AllProjectStr, Delimiter_PrjInfo , AllProjectInfo, &iLen_Delimiter_PrjInfo, &iProjectCounter ) ;
	printf ( "\ngetProjectNameDesc : after calling MyTokenize" ) ;
	
	printf ( "\ngetProjectNameDesc : No of Project Found : [%d]", iProjectCounter ) ;
	*iPrjCounter = 0 ;
	for ( iProjCount = 0 ; iProjCount < iProjectCounter  ; iProjCount++ )
	{
		printf ( "\ngetProjectNameDesc : AllProjectInfo[iProjCount] : [%s]", AllProjectInfo[iProjCount] );

		//Process project and description from list for each project
		iLen_Delimiter_PrjNameDesc = strlen ( Delimiter_PrjNameDesc ) ;
		MyTokenize ( AllProjectInfo[iProjCount], Delimiter_PrjNameDesc, AllProjectNameDesc, &iLen_Delimiter_PrjNameDesc, &iProjectNameDescCounter ) ;
		
		printf ( "\ngetProjectNameDesc : iProjectNameDescCounter : [%d]", iProjectNameDescCounter ) ;
		tc_strcpy(mysProjectInfo[*iPrjCounter].PPPM_PROJECT_CODE, AllProjectNameDesc [ 0 ] );
		tc_strcpy(mysProjectInfo[*iPrjCounter].PROJECT_DESCSCRIPTION, AllProjectNameDesc [ 1 ] );

		printf( "\n\t\t\t%-30s:%s", "PPPM_PROJECT_CODE" , mysProjectInfo[*iPrjCounter].PPPM_PROJECT_CODE );fflush(stdout);
		printf( "\n\t\t\t%-30s:%s\n", "PROJECT_DESCSCRIPTION" , mysProjectInfo[*iPrjCounter].PROJECT_DESCSCRIPTION );fflush(stdout);

		*iPrjCounter = *iPrjCounter + 1;
		

		
	}
	if ( AllProjectNameDesc [ 0 ] != NULL )
	{
		MEM_free ( AllProjectNameDesc [ 0 ] ) ;//name
	}
	if ( AllProjectNameDesc [ 1 ] != NULL )
	{
		MEM_free ( AllProjectNameDesc [ 1 ] ) ;//desc
	}
	if ( AllProjectNameDesc != NULL )
	{
		MEM_free ( AllProjectNameDesc ) ;	//array of name desc
	}
	
	for ( iProjCount = 0 ; iProjCount < NO_OF_PPPM_PROJECT  ; iProjCount++ )//memory was allocated for NO_OF_PPPM_PROJECT = 100 as per macro value
	{
		if ( AllProjectInfo [iProjCount] != NULL )
		{
			MEM_free ( AllProjectInfo [iProjCount] ) ;	//each project name and desc string
		}
	}
	if ( AllProjectInfo != NULL )
	{
		MEM_free ( AllProjectInfo ) ;	//array of projects
	}
	
	
	return 0;
}

int getPrjVarDetails (char* AllProjectDetailsStr,struct ProjectBase mysProjectBase_1[2],int *VarCounter,struct ProjectBase* pvar)
{
        char *Delimiter_PrjDet = "!@xxx@!" ;
        char *Delimiter_PrjBaseBarrelVar = "!@:@!" ;
        char *Delimiter_PrjBase = "!@!" ;
        char *Delimiter_PrjBarrel = "!-!" ;
        char *Delimiter_PrjVariant =  "!@@@!";
        char *Delimiter_PrjVariantDet =  "!--!";

		//Response1: M-L156.4-MHCV_PI-MHCV_IB_TIPPER!@!MHCV_IB_TIPPER!@!JAMSHEDPUR!@!L156.4!@!CVBU!@!MHCV_PI!@:@!5067!-!5112!-!2067!-!5043!-!2167!-!5004!-!2641!-!2821!-!5007!-!2863!-!5008!-!2816!-!5006!@:@!1500!--!V2025!--!JSR!--!SK1616

        char **AllProjectDetails = NULL;
        char **AllProjectBaseBarrelVar = NULL;
        char **AllProjectBase = NULL;
        char **AllProjectBarrel = NULL;
        char **AllProjectVariant = NULL;
        char **AllProjectVariantDet = NULL;

        char* sProjectDetails = NULL;
        int iProdDetCounter = 0 ;
        int iLen_Delimiter_PrjDet = -1;
        int iLen_Delimiter_PrjBase = -1;
        int iLen_Delimiter_PrjBaseBarrelVar = -1;
        int iLen_Delimiter_PrjBarrel = -1;
        int iLen_Delimiter_PrjVariant = -1;
        int iLen_Delimiter_PrjVariantDet = -1;
        int iPrjCounter1 = 0;
        int iPrjBarrCntr = 0;
        int iPrjVarInfoCntr = 0;
		char* ProjectBaseInfo = NULL;
        char* ProjectBarrelInfo = NULL;
        char* ProjectVariantInfo = NULL;
        char* sProjectVariant_str = NULL;
		int iCntAllProjectDetails = 0;
		int iProjCount = 0;
		int iVarCount = 0 ;
		int iProjectBaseCnt = 0 ;
		int iProjBarrelCnt = 0;
		int ProjVarCnt = 0;
		int iPrjVariantDetCnt = 0;

        //Split all projects
        //AllProjectDetails = set_create_str( 20 ) ;

        iLen_Delimiter_PrjDet = strlen ( Delimiter_PrjDet ) ;
		AllProjectDetails = ( char ** ) MEM_alloc ( 20 * sizeof ( char * ) ) ;	
		for ( iProjCount = 0 ; iProjCount < 20  ; iProjCount++ )
		{
			AllProjectDetails[iProjCount] = ( char * ) MEM_alloc ( 500 * sizeof ( char ) ) ;	//project name and description string length 
		}
		printf( "\n\n\ngetPrjVarDetails : started :" );
		printf( "\ngetPrjVarDetails : AllProjectDetailsStr : [%s]", AllProjectDetailsStr );

        MyTokenize ( AllProjectDetailsStr, Delimiter_PrjDet, AllProjectDetails, &iLen_Delimiter_PrjDet, &iCntAllProjectDetails ) ;

		
		printf( "\ngetPrjVarDetails : iLen_Delimiter_PrjDet : [%d]", iLen_Delimiter_PrjDet );
		printf( "\ngetPrjVarDetails : iCntAllProjectDetails : [%d]", iCntAllProjectDetails );

        //printf ( "\n\n\nsetSize(AllProjectDetails):%d",setSize(AllProjectDetails) ) ;fflush(stdout);

        iPrjCounter1 = 0;
		
		if ( iCntAllProjectDetails > 0 )
		{
			AllProjectBaseBarrelVar = ( char ** ) MEM_alloc ( 3 * sizeof ( char * ) ) ;	
			for ( iProjCount = 0 ; iProjCount < 3  ; iProjCount++ )
			{
				AllProjectBaseBarrelVar[iProjCount] = ( char * ) MEM_alloc ( 2000 * sizeof ( char ) ) ;	//ProjectBaseInfo and ProjectBarrelInfo ProjectVariantInfo 
			}

			ProjectBaseInfo = ( char * ) MEM_alloc ( 200 * sizeof ( char ) ) ;	
			ProjectBarrelInfo = ( char * ) MEM_alloc ( 500 * sizeof ( char ) ) ;	
			ProjectVariantInfo = ( char * ) MEM_alloc ( 2000 * sizeof ( char ) ) ;	
				

			
			AllProjectBase = ( char ** ) MEM_alloc ( 10 * sizeof ( char * ) ) ;	//M-L156.4-MHCV_PI-MHCV_IB_TIPPER!@!MHCV_IB_TIPPER!@!JAMSHEDPUR!@!L156.4!@!CVBU!@!MHCV_PI
			for ( iProjCount = 0 ; iProjCount < 10  ; iProjCount++ )
			{
				AllProjectBase[iProjCount] = ( char * ) MEM_alloc ( 100 * sizeof ( char ) ) ;	//project name and description string length 
			}

			AllProjectBarrel = ( char ** ) MEM_alloc ( 50 * sizeof ( char * ) ) ; //4 digit barrel codes list	[5067!-!5112!-!2067!-!5043!-!2167!-!5004!-!2641!-!2821!-!5007!-!2863!-!5008!-!2816!-!5006]
			for ( iProjCount = 0 ; iProjCount < 50  ; iProjCount++ )
			{
				AllProjectBarrel[iProjCount] = ( char * ) MEM_alloc ( 10 * sizeof ( char ) ) ;	//4 digit barrel codes 
			}
			
			
			AllProjectVariant = ( char ** ) MEM_alloc ( 10 * sizeof ( char * ) ) ;	//[1500!--!V2025!--!JSR!--!SK1616]
			for ( iProjCount = 0 ; iProjCount < 10  ; iProjCount++ )
			{
				AllProjectVariant[iProjCount] = ( char * ) MEM_alloc ( 50 * sizeof ( char ) ) ;	//test
			}
			
			sProjectVariant_str = ( char * ) MEM_alloc ( 500 * sizeof ( char ) ) ;
			
			AllProjectVariantDet = ( char ** ) MEM_alloc ( 10 * sizeof ( char * ) ) ;	//test
			for ( iProjCount = 0 ; iProjCount < 10  ; iProjCount++ )
			{
				AllProjectVariantDet[iProjCount] = ( char * ) MEM_alloc ( 50 * sizeof ( char ) ) ;	//test
				//|1|2150|V268|PUN|1415 LPT|
				//|2|2710|V267|PUN|1215 LPT|
			}

			
		}

        for ( iProdDetCounter = 0 ; iProdDetCounter < iCntAllProjectDetails ; iProdDetCounter ++ )
        {
                //sProjectDetails = low_set_get_str ( AllProjectDetails, iProdDetCounter ) ;
				printf ( "\ngetPrjVarDetails : AllProjectDetails : [%s]", AllProjectDetails [ iProdDetCounter ] );

                iLen_Delimiter_PrjBaseBarrelVar = strlen ( Delimiter_PrjBaseBarrelVar ) ;
                //AllProjectBaseBarrelVar = set_create_str( 3 ) ;
				printf ( "\ngetPrjVarDetails : iLen_Delimiter_PrjBaseBarrelVar : [%d]", iLen_Delimiter_PrjBaseBarrelVar );
				printf ( "\ngetPrjVarDetails : Delimiter_PrjBaseBarrelVar : [%s]", Delimiter_PrjBaseBarrelVar );
				
				//AllProjectDetails [ iProdDetCounter ] value as below
				//[M-L156.4-MHCV_PI-MHCV_IB_TIPPER!@!MHCV_IB_TIPPER!@!JAMSHEDPUR!@!L156.4!@!CVBU!@!MHCV_PI!@:@!5067!-!5112!-!2067!-!5043!-!2167!-!5004!-!2641!-!2821!-!5007!-!2863!-!5008!-!2816!-!5006!@:@!1500!--!V2025!--!JSR!--!SK1616]
				
                MyTokenize ( AllProjectDetails [ iProdDetCounter ], Delimiter_PrjBaseBarrelVar, AllProjectBaseBarrelVar, &iLen_Delimiter_PrjBaseBarrelVar, &iVarCount );
				tc_strcpy ( ProjectBaseInfo, AllProjectBaseBarrelVar [ 0 ] );
				tc_strcpy ( ProjectBarrelInfo, AllProjectBaseBarrelVar [ 1 ] );
				tc_strcpy ( ProjectVariantInfo, AllProjectBaseBarrelVar [ 2 ] );
				//returned after AllProjectBaseBarrelVar
				//getPrjVarDetails : ProjectBaseInfo : [M-L156.4-MHCV_PI-MHCV_IB_TIPPER!@!MHCV_IB_TIPPER!@!JAMSHEDPUR!@!L156.4!@!CVBU!@!MHCV_PI]
				//getPrjVarDetails : ProjectBarrelInfo : [5067!-!5112!-!2067!-!5043!-!2167!-!5004!-!2641!-!2821!-!5007!-!2863!-!5008!-!2816!-!5006]
				//getPrjVarDetails : ProjectVariantInfo : [1500!--!V2025!--!JSR!--!SK1616]

				printf ( "\ngetPrjVarDetails : ProjectBaseInfo : [%s]", ProjectBaseInfo );
				printf ( "\ngetPrjVarDetails : ProjectBarrelInfo : [%s]", ProjectBarrelInfo );
				printf ( "\ngetPrjVarDetails : ProjectVariantInfo : [%s]", ProjectVariantInfo );


//
//                //----ProjectBase
                iLen_Delimiter_PrjBase = tc_strlen ( Delimiter_PrjBase ) ;
				printf ( "\ngetPrjVarDetails : iLen_Delimiter_PrjBase : [%d]", iLen_Delimiter_PrjBase );
                //AllProjectBase = set_create_str( 10 ) ;
                MyTokenize ( ProjectBaseInfo, Delimiter_PrjBase, AllProjectBase, &iLen_Delimiter_PrjBase, &iProjectBaseCnt ) ;
                printf ( "\n\n\ngetPrjVarDetails : iProjectBaseCnt : [%d]", iProjectBaseCnt ) ; fflush ( stdout ) ;

                printf ( "\n****************************************************" ) ; fflush ( stdout ) ;
                printf ( "\nProjectCounter:%d", iProdDetCounter ) ; fflush ( stdout ) ;
//				printf ( "\nSingleProjectString:%s", sProjectDetails );fflush(stdout);
//                //printf ( "\n\nProjectBaseInfo Table" ) ;
//
                tc_strcpy ( mysProjectBase_1 [ iPrjCounter1 ]. PPPM_PROJECT_CODE, AllProjectBase [ 0 ] );
                tc_strcpy ( mysProjectBase_1 [ iPrjCounter1 ]. PROJECT_DESCSCRIPTION, AllProjectBase [ 1 ]  );
                tc_strcpy ( mysProjectBase_1 [ iPrjCounter1 ]. MANUF_LOC, AllProjectBase [ 2 ]  );
                tc_strcpy ( mysProjectBase_1 [ iPrjCounter1 ]. PRONEXT_PROJ_SRL, AllProjectBase [ 3 ]  );
                tc_strcpy ( mysProjectBase_1 [ iPrjCounter1 ]. BUSINESS_UNIT, AllProjectBase [ 4 ]  );
                tc_strcpy ( mysProjectBase_1 [ iPrjCounter1 ]. PROJ_CODE, AllProjectBase [ 5 ] );

//				PPPM_PROJECT_CODE             :M-L156.4-MHCV_PI-MHCV_IB_TIPPER
//				PROJECT_DESCSCRIPTION         :MHCV_IB_TIPPER
//				MANUF_LOC                     :JAMSHEDPUR
//				PRONEXT_PROJ_SRL              :L156.4
//				BUSINESS_UNIT                 :CVBU
//				PROJ_CODE                     :MHCV_PI

//
//                //----ProjectBarrel
//
                iLen_Delimiter_PrjBarrel = tc_strlen ( Delimiter_PrjBarrel ) ;
				printf ( "\ngetPrjVarDetails : iLen_Delimiter_PrjBarrel : [%d]", iLen_Delimiter_PrjBarrel ) ;
				
                MyTokenize ( ProjectBarrelInfo, Delimiter_PrjBarrel, AllProjectBarrel, &iLen_Delimiter_PrjBarrel, &iProjBarrelCnt ) ;
                printf ( "\n\nProjectBarrelTable" ) ;fflush(stdout);
				printf ( "\ngetPrjVarDetails : iProjBarrelCnt : [%d]", iProjBarrelCnt ) ;
                for ( iPrjBarrCntr = 0 ; iPrjBarrCntr < iProjBarrelCnt ; iPrjBarrCntr++ )
                {
                        printf ( "\n\t\t\t|%d|%s|", iPrjBarrCntr, AllProjectBarrel [ iPrjBarrCntr ] );fflush(stdout);
                }
//				|0|5067|
//				|1|5112|
//				|2|2067|
//				|3|5043|
//				|4|2167|
//				|5|5004|
//				|6|2641|
//				|7|2821|
//				|8|5007|
//				|9|2863|
//				|10|5008|
//				|11|2816|
//				|12|5006|

//
                //----ProjectVariant

                iLen_Delimiter_PrjVariant = tc_strlen ( Delimiter_PrjVariant ) ;
				printf ( "\ngetPrjVarDetails : iLen_Delimiter_PrjVariant : [%d]", iLen_Delimiter_PrjVariant ) ;
                MyTokenize ( ProjectVariantInfo, Delimiter_PrjVariant, AllProjectVariant, &iLen_Delimiter_PrjVariant, &ProjVarCnt ) ;
				printf ( "\ngetPrjVarDetails : ProjVarCnt : [%d]", ProjVarCnt ) ;
                printf ( "\n\nVariantTable" ) ;fflush(stdout);

                *VarCounter = 0;

                for ( iPrjVarInfoCntr = 0 ; iPrjVarInfoCntr < ProjVarCnt ; iPrjVarInfoCntr++ )
                {
                        tc_strcpy (sProjectVariant_str, AllProjectVariant [ iPrjVarInfoCntr ] ) ;
                        iLen_Delimiter_PrjVariantDet = tc_strlen ( Delimiter_PrjVariantDet ) ;
						printf ( "\ngetPrjVarDetails : iLen_Delimiter_PrjVariantDet : [%d]", iLen_Delimiter_PrjVariantDet ) ;
                        //printf ( "\n\nsProjectVariant_str:%s", sProjectVariant_str ) ;fflush(stdout);
                        //AllProjectVariantDet = set_create_str( 10 ) ;
                        MyTokenize ( sProjectVariant_str, Delimiter_PrjVariantDet, AllProjectVariantDet, &iLen_Delimiter_PrjVariantDet, &iPrjVariantDetCnt);
						printf ( "\ngetPrjVarDetails : iPrjVariantDetCnt : [%d]", iPrjVariantDetCnt ) ;
                       
						tc_strcpy ( pvar->PrjVariant[iPrjVarInfoCntr].TOTAL_VOLUME, AllProjectVariantDet [ 0 ] );
                        tc_strcpy ( pvar->PrjVariant[iPrjVarInfoCntr].VARIANT_ID, AllProjectVariantDet [ 1 ] );
                        tc_strcpy ( pvar->PrjVariant[iPrjVarInfoCntr].LOCATION, AllProjectVariantDet [ 2 ] );
                        tc_strcpy ( pvar->PrjVariant[iPrjVarInfoCntr].VARIANT_NAME, AllProjectVariantDet [ 3 ] );

                        
						
						

                        *VarCounter = *VarCounter + 1;
                }
				printf( "\n\t\t\t|SrNo|TOTAL_VOLUME|VARIANT_ID|LOCATION|VARIANT_NAME|" );fflush(stdout);
				for ( iPrjVarInfoCntr = 0 ; iPrjVarInfoCntr < ProjVarCnt ; iPrjVarInfoCntr++ )
                {
						
                        printf( "\n\t\t\t|%d" , iPrjVarInfoCntr );fflush(stdout);
                        printf( "|%s" , pvar->PrjVariant[iPrjVarInfoCntr].TOTAL_VOLUME );fflush(stdout);
                        printf( "|%s" , pvar->PrjVariant[iPrjVarInfoCntr].VARIANT_ID );fflush(stdout);
                        printf( "|%s" , pvar->PrjVariant[iPrjVarInfoCntr].LOCATION );fflush(stdout);
                        printf( "|%s|" , pvar->PrjVariant[iPrjVarInfoCntr].VARIANT_NAME );fflush(stdout);
						//|1|2150|V268|PUN|1415 LPT|
						//|2|2710|V267|PUN|1215 LPT|
						//|3|830|V266|PUN|1112 LPT|
						//|4|2480|V265|PUN|1012 LPT|
						//|5|2220|V264|PUN|712 LPI-L25.13-CCD.871-LPT 7T-9T-12T-15T 3.3L -RDE|
				}
                iPrjCounter1 = iPrjCounter1 + 1;


				
        }
		//free memory
		if ( iCntAllProjectDetails > 0 )
		{
			for ( iProjCount = 0 ; iProjCount < 3  ; iProjCount++ )
			{
				if ( AllProjectBaseBarrelVar[iProjCount] != NULL )	//ProjectBaseInfo and ProjectBarrelInfo ProjectVariantInfo 
				{
					MEM_free ( AllProjectBaseBarrelVar[iProjCount] );
				}	
			}
			if ( AllProjectBaseBarrelVar != NULL )	//ProjectBaseInfo and ProjectBarrelInfo ProjectVariantInfo 
			{
				MEM_free ( AllProjectBaseBarrelVar );
			}
			
			
			if ( ProjectBaseInfo != NULL )	
			{
				MEM_free ( ProjectBaseInfo );
			}
			if ( ProjectBarrelInfo != NULL )	
			{
				MEM_free ( ProjectBarrelInfo );
			}
//			if ( ProjectVariantInfo != NULL )	
//			{
//				MEM_free ( ProjectVariantInfo );
//			}
//
//			for ( iProjCount = 0 ; iProjCount < 10  ; iProjCount++ )
//			{
//				if ( AllProjectBase[iProjCount] != NULL )	
//				{
//					MEM_free ( AllProjectBase[iProjCount] );
//				}	
//			}
//			if ( AllProjectBase != NULL )	//M-L156.4-MHCV_PI-MHCV_IB_TIPPER!@!MHCV_IB_TIPPER!@!JAMSHEDPUR!@!L156.4!@!CVBU!@!MHCV_PI
//			{
//				MEM_free ( AllProjectBase );
//			}	
//
//			
			for ( iProjCount = 0 ; iProjCount < 50  ; iProjCount++ )
			{
				if ( AllProjectBarrel[iProjCount] != NULL )	
				{
					MEM_free ( AllProjectBarrel[iProjCount] );
				}	
			}
			if ( AllProjectBarrel != NULL )	//4 digit barrel codes list	[5067!-!5112!-!2067!-!5043!-!2167!-!5004!-!2641!-!2821!-!5007!-!2863!-!5008!-!2816!-!5006]
			{
				MEM_free ( AllProjectBarrel );
			}	
//			
//			
//			for ( iProjCount = 0 ; iProjCount < 10  ; iProjCount++ )
//			{
//				if ( AllProjectVariant[iProjCount] != NULL )	
//				{
//					MEM_free ( AllProjectVariant[iProjCount] );
//				}	
//			}
//			if ( AllProjectVariant != NULL )	//[1500!--!V2025!--!JSR!--!SK1616]
//			{
//				MEM_free ( AllProjectVariant );
//			}	
//			
//			
			if ( sProjectVariant_str != NULL )	//[1500!--!V2025!--!JSR!--!SK1616]
			{
				MEM_free ( sProjectVariant_str );
			}	
			
//			for ( iProjCount = 0 ; iProjCount < 10  ; iProjCount++ )
//			{
//				if ( AllProjectVariantDet[iProjCount] != NULL )	
//				{
//					MEM_free ( AllProjectVariantDet[iProjCount] );
//					//|1|2150|V268|PUN|1415 LPT|
//					//|2|2710|V267|PUN|1215 LPT|
//				}	
//			}
			if ( AllProjectVariantDet != NULL )	
			{
				MEM_free ( AllProjectVariantDet );
			}	
			
		}

        printf ( "\n****************************************************\n" );fflush(stdout);

        return 0;
}

extern int ITK_user_main ( int argc, char ** argv )
{
	char* UserName = NULL ;
	char* Password = NULL ;
	char* ProjectCode = NULL ;
	char* fnamepath = NULL ;
	char *val1 = NULL ;
	char *AllProjectStr = NULL ;
	char *pppmcode3 = NULL ;
	int iPrjCounter = 0 ;
	int jc = 0 ;
	FILE *fp = NULL;

	struct PPPM_ProjectInfo mysProjectInfo [100] ;
	
	ITK_CALL ( ITK_initialize_text_services ( ITK_BATCH_TEXT_MODE ) ) ;
	ITK_CALL ( ITK_auto_login ( ) ) ;
    ITK_CALL ( ITK_set_journalling ( TRUE ) ) ;

	//UserName = ITK_ask_cli_argument("-u=");
	//Password = ITK_ask_cli_argument("-p=");
	ProjectCode = ITK_ask_cli_argument ( "-d=" ) ;
	fnamepath = ITK_ask_cli_argument ( "-f=" ) ;
	//char* Get_Variant_Frm_WS(char *barrelno1,char *pppmprojcode1,char *val1);
	//char* Get_PPPMProjCode_Frm_WS(char *barrelno,char *val1);
	
	val1 = ( char * ) MEM_alloc ( 5000 ) ;
	//Get_PPPMProjCode_Frm_WS("5150",val1);
	Get_PPPMProjCode_Frm_WS ( ProjectCode, val1 ) ;


	


	AllProjectStr = ( char *) MEM_alloc ( strlen ( val1 ) ) ;
    tc_strcpy ( AllProjectStr, val1 ) ;

	printf ( "\nITK_user_main : ProjectCompleteString Length : %d", strlen ( AllProjectStr ) ) ; fflush ( stdout ) ;
	printf ( "\nITK_user_main : ProjectCompleteString : %s", AllProjectStr ) ; fflush ( stdout ) ;
	iPrjCounter =0;
	
	getProjectNameDesc ( AllProjectStr, mysProjectInfo, &iPrjCounter ) ;
	printf ( "\nITK_user_main : iPrjCounter : %d", iPrjCounter ); fflush ( stdout ) ;
	pppmcode3 = ( char * ) MEM_alloc ( 500 ) ;
	if ( iPrjCounter > 0 )
	{
		
		fp = fopen ( fnamepath, "w");
		for (jc= 0;jc<iPrjCounter ; jc++)
		{
				
				tc_strcpy ( pppmcode3, "" ) ;

				printf("\nITK_user_main : mysProjectInfo[%d].PPPM_PROJECT_CODE:%s", jc , mysProjectInfo[jc].PPPM_PROJECT_CODE); fflush(stdout);
				printf("\nITK_user_main : mysProjectInfo[%d].PROJECT_DESCSCRIPTION:%s", jc , mysProjectInfo[jc].PROJECT_DESCSCRIPTION); fflush(stdout);

				tc_strcpy ( pppmcode3, mysProjectInfo[jc].PPPM_PROJECT_CODE ) ;
				tc_strcat ( pppmcode3, "$$" ) ;
				tc_strcat ( pppmcode3, mysProjectInfo[jc].PROJECT_DESCSCRIPTION ) ;

				printf ( "\nITK_user_main : pppmcode3 : %s \n",pppmcode3 ) ; fflush ( stdout ) ;
				fprintf ( fp, "%sv\n",pppmcode3 ) ; fflush ( stdout ) ;
				//low_set_add_str_unique(*values,pppmcode3);
				//printf("\nd5SORCre:t5GetPPPMPrjCodeMSG Tushar:pppmcode3: %d \n",setSize(*values));fflush(stdout);
		}
		fclose ( fp ) ;
	}
	
	printf("\nITK_user_main : Project Name Desc details END code\n\n\n" ) ;




	printf("\nITK_user_main : Code to get variant details of first project" ) ;
	char *AllProjectDetailsStr = NULL ;
	struct ProjectBase mysProjectBase_1[2] ;
	struct ProjectBase pvar ;
	int VarCounter = 0 ;
	char *PPPMPrjCodeDetailval = NULL ;
	char *PPPMPrjCodeDup = NULL;
	PPPMPrjCodeDup = ( char * ) MEM_alloc ( 150 * sizeof ( char ) ) ;	//project code name
	PPPMPrjCodeDetailval = ( char * ) MEM_alloc ( 25000 * sizeof ( char ) ) ;	//project details for input pppm project
	
	printf( "\nITK_user_main : mysProjectInfo[0].PPPM_PROJECT_CODE : [%s]", mysProjectInfo[0].PPPM_PROJECT_CODE );
	tc_strcpy ( PPPMPrjCodeDup, mysProjectInfo[0].PPPM_PROJECT_CODE ) ;

	//for project 2228
	//printf( "\nITK_user_main : mysProjectInfo[0].PPPM_PROJECT_CODE : [%s]", mysProjectInfo[8].PPPM_PROJECT_CODE );
	//tc_strcpy ( PPPMPrjCodeDup, mysProjectInfo[8].PPPM_PROJECT_CODE ) ;

	printf( "\nITK_user_main : copied to PPPMPrjCodeDup : [%s]", PPPMPrjCodeDup );

	Get_Variant_Frm_WS ( ProjectCode, PPPMPrjCodeDup, PPPMPrjCodeDetailval ) ;

	printf( "\nITK_user_main : retried string from Get_Variant_Frm_WS PPPMPrjCodeDetailval : [%s]", PPPMPrjCodeDetailval );

	AllProjectDetailsStr = ( char * ) MEM_alloc ( tc_strlen ( PPPMPrjCodeDetailval ) * sizeof ( char ) ) ;
	tc_strcpy ( AllProjectDetailsStr, PPPMPrjCodeDetailval );
	printf("\nITK_user_main : AllProjectDetailsStr : [%s] to get all variant input str", AllProjectDetailsStr ) ;
	getPrjVarDetails( AllProjectDetailsStr, mysProjectBase_1, &VarCounter, &pvar );
//
	printf ( "\n\nITK_user_main  t5GetPurchaseGroupLead ProjectBaseInfo Table" ) ;
	printf( "\n\t\t\t%-30s:%s", "PPPM_PROJECT_CODE" , mysProjectBase_1[0].PPPM_PROJECT_CODE );
	printf( "\n\t\t\t%-30s:%s", "PROJECT_DESCSCRIPTION" , mysProjectBase_1[0].PROJECT_DESCSCRIPTION );
	printf( "\n\t\t\t%-30s:%s", "MANUF_LOC" , mysProjectBase_1[0].MANUF_LOC );
	printf( "\n\t\t\t%-30s:%s", "PRONEXT_PROJ_SRL" , mysProjectBase_1[0].PRONEXT_PROJ_SRL );
	printf( "\n\t\t\t%-30s:%s", "BUSINESS_UNIT" , mysProjectBase_1[0].BUSINESS_UNIT );
	printf( "\n\t\t\t%-30s:%s", "PROJ_CODE" , mysProjectBase_1[0].PROJ_CODE );


	
	MEM_free ( pppmcode3 ) ;

	ITK_CALL ( POM_logout ( false ) ) ;
	printf ( "\nITK_user_main return\n" ) ; fflush ( stdout ) ;
	return ITK_ok ;
}	
