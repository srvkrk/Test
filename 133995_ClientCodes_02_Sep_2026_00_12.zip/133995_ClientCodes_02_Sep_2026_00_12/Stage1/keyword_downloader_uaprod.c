#include <stdio.h>
#include <tc/tc.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <string.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

int			ifail 				= ITK_ok;


int Get_Qry_Execute(char*, char*);


int ITK_user_main(int argc, char *argv[])
{

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Date_1					= NULL;
	char			* Date_2					= NULL;

	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Date_1		= ITK_ask_cli_argument("-f=");
	Date_2       = ITK_ask_cli_argument("-f1=");
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	ifail = Get_Qry_Execute(Date_1,Date_2);



	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

int Get_Qry_Execute(char* Date_1, char* Date_2)
{
		int ifail           = ITK_ok;
		tag_t KWDescQry     = NULLTAG;
	    tag_t *moduleTags   = NULL;
		char *Design_group	= NULL;
		char *Keyword_descp	= NULL;
		char *ext_2=NULL;
		int modCount=0;
		int Entry_count=2;
		FILE* fp = NULL;
		FILE* fp1 = NULL;
		char*Filename=NULL;
		Filename=(char*) MEM_alloc(100000000);
		char*Filename2=NULL;
		Filename2=(char*) MEM_alloc(10000000);
		int i =0;
		
		


char *Entries[2] = {"Creation after","Creation before"};
char **Values = (char **) MEM_alloc(500 * sizeof(char *));
Design_group=(char *) MEM_alloc(1000);
Keyword_descp=(char *) MEM_alloc(1000);
Values[0] = Date_1;
Values[1] = Date_2;

printf("\nvalue_0:%s",Date_1);
printf("\nvalue_1:%s",Date_2);
ifail=QRY_find("Qry_for_Keyword", &KWDescQry);
    
if (KWDescQry)
{ 
	QRY_execute(KWDescQry, Entry_count, Entries, Values, &modCount, &moduleTags);

	printf("\nModule Object Found : %d", modCount);fflush(stdout);
				
        for(i=0;i<modCount;i++)
        {
		
				
				ifail=AOM_ask_value_string(moduleTags[i],"ext_1",&Design_group);
				printf("\nDesign group : %s", Design_group);fflush(stdout);
			    ifail=AOM_ask_value_string(moduleTags[i],"name",&Keyword_descp);
				printf("\nkeyword description : %s", Keyword_descp);fflush(stdout);
				ifail=AOM_ask_value_string(moduleTags[i],"ext_2",&ext_2);
				printf("\nEXT_2 : %s", ext_2);fflush(stdout);
				Filename2=strcpy(Filename2,"partlist.txt");
				Filename=strcpy(Filename,"keyword_descp.txt");
		        fp1 = fopen(Filename,"a+");
				
                fp = fopen(Filename2,"a+");
			   
			   
			     fprintf(fp,"%s%s%s\n",Design_group,"^",Keyword_descp);
				 fprintf(fp1,"%s%s%s%s%s\n",Design_group,"^",Keyword_descp,"^",ext_2);
			     fclose(fp);
			   if(Design_group)
		 { MEM_free(Design_group); }
	       if(Keyword_descp)
		 { MEM_free(Keyword_descp); }
        }
		
		printf("\nAll keywords completed");fflush(stdout);
		
		 
}     

	    
else
	{
               
		 printf("\nModule not found with given input\n");fflush(stdout);
		 
	}


      
            return ifail;
	  
}

