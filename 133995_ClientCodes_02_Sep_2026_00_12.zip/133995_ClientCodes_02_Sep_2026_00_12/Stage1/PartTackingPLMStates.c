/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Abineshwar Bisoi
*  Module		 :   Cost Release Workflow Tacking-PLM States
*  Code			 :   PartTackingPLMStates.c
*  Created on	 :   18 June 2024
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
*  1.     18/06/2024              Sandeep/Abineshwar     Initial code for Cost Release Workflow Tacking-PLM States.
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <pom/enq/enq.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/pom/pom.h>
#include <epm/epm.h>
#include <user_exits/libuser_exits_exports.h>
#include <user_exits/libuser_exits_undef.h>
#include <time.h>
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#define MAX_LINE_LEN 1024



#define Debug TRUE

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text (stat, &err_string);                \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}


char* RptTimestamp = NULL;
char* APLRlzStatus = NULL;
char* STDRlzStatus = NULL;
char* ESTPlant = NULL;


signed long daysInSecond(signed int day)
{
    return day*24*60*60;
}

 long timeInSec(time_t time1) 
 {
	return (long)time1;
 }

time_t longTotime_t(long timeInSec)
{
    return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day)
{
    return longTotime_t(timeInSec(idate)+daysInSecond(day));
}


void GetReportTimeStamp()
{
	char        *timestamp            =   NULL;
	time_t t;
	time(&t);
    timestamp = ctime(&t);
    printf("\n Start Time..Of Report Generation..%s",timestamp);fflush(stdout);
	
	char 	*tempTimestamp1 = NULL;
	char 	*tempTimestamp2 = NULL;
	
	tempTimestamp1 = (char *) MEM_alloc(100 * sizeof(char *));
	tempTimestamp2 = (char *) MEM_alloc(100 * sizeof(char *));
	RptTimestamp = (char *) MEM_alloc(100 * sizeof(char *));

	STRNG_replace_str(timestamp," ","_",&tempTimestamp1);
	STRNG_replace_str(tempTimestamp1,":","_",&tempTimestamp2);
	STRNG_replace_str(tempTimestamp2,"\n","",&RptTimestamp);
}

/*******MAIN FUNCTION************/


tag_t t5GetItemFindLatestSequence(char* inputPart,char* InputRev)
{
    int ifail = ITK_ok;
	tag_t  itemRev = NULLTAG;
    int n_tags_found=0;
    tag_t* tags_found = NULL;
    const char *attrs[1];
    const char *values[1];
    
    
    attrs[0] ="item_id";
	values[0] = (char *)inputPart;
    ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
    printf("\n n_tags_found= %d",n_tags_found);fflush(stdout);
    
    if (n_tags_found >0)
    {
        tag_t  item = NULLTAG;
        
		int    Item_count = 0;
		tag_t* rev_list = NULLTAG;
		
        item = tags_found[0];
		ITK_CALL(ITEM_list_all_revs (item, &Item_count, &rev_list));
		
		int counterRevList = 0;
        printf("\n Item_count = %d",Item_count);fflush(stdout);
        for(counterRevList = Item_count-1; counterRevList<Item_count && counterRevList >= 0;counterRevList--)
        {
			char* RevSeq = NULL;
			char* PrtNme = NULL;
			
			ITK_CALL(AOM_ask_value_string(rev_list[counterRevList],"item_id",&PrtNme));
			ITK_CALL(AOM_ask_value_string(rev_list[counterRevList],"item_revision_id",&RevSeq));
			
			printf("\n PrtNme = %s",PrtNme);fflush(stdout);
			printf("\n RevSeq = %s",RevSeq);fflush(stdout);
			
			if(tc_strstr(RevSeq,InputRev) != NULL)
			{
				itemRev = rev_list[counterRevList];
				break;
			}
		}

        
	}
    return itemRev;
}

void SetESTPlant(char* InputPlant)
{
	ESTPlant = (char *) MEM_alloc(100 * sizeof(char *));
	if (tc_strcmp(InputPlant,"JSR") == 0)
	{
		tc_strcpy(ESTPlant,"CVBU JSR");
	}
	else if (tc_strcmp(InputPlant,"PUNECVBU") == 0)
	{
		tc_strcpy(ESTPlant,"CVBU PUNE");
	}
	else if (tc_strcmp(InputPlant,"LKO") == 0)
	{
		tc_strcpy(ESTPlant,"CVBU LKO");
	}
	else if (tc_strcmp(InputPlant,"DWD") == 0)
	{
		tc_strcpy(ESTPlant,"DHARWAD");
	}
	else if (tc_strcmp(InputPlant,"PNR") == 0)
	{
		tc_strcpy(ESTPlant,"CVBU PNR");
	}
}

void SetPlantRlzStatus(char* InputPlant)
{
	
	APLRlzStatus = (char *) MEM_alloc(100 * sizeof(char *));
	STDRlzStatus = (char *) MEM_alloc(100 * sizeof(char *));
	if (tc_strcmp(InputPlant,"JSR") == 0)
	{
		tc_strcpy(APLRlzStatus,"APLJ Released");
		tc_strcpy(STDRlzStatus,"STDSIJ Released");
	}
	else if (tc_strcmp(InputPlant,"PUNECVBU") == 0)
	{
		tc_strcpy(APLRlzStatus,"APLP Released");
		tc_strcpy(STDRlzStatus,"STDSIP Released");
	}
	else if (tc_strcmp(InputPlant,"LKO") == 0)
	{
		tc_strcpy(APLRlzStatus,"APLL Released");
		tc_strcpy(STDRlzStatus,"STDSIL Released");
	}
	else if (tc_strcmp(InputPlant,"DWD") == 0)
	{
		tc_strcpy(APLRlzStatus,"APLD Released");
		tc_strcpy(STDRlzStatus,"STDSID Released");
	}
	else if (tc_strcmp(InputPlant,"PNR") == 0)
	{
		tc_strcpy(APLRlzStatus,"APLU Released");
		tc_strcpy(STDRlzStatus,"STDSIU Released");
	}
}

char* GetUPLRlzStatus(char* InputPrt,char* PlantName,char* InputRev,char* InputSeq,char* UPLCreationDate)
{
	char* UPLObjectStr = NULL;
	char* UPLReportType = NULL;
	UPLObjectStr = (char *) MEM_alloc(50 * sizeof(char *));
	UPLReportType = (char *) MEM_alloc(2 * sizeof(char *));
	//UPLCreationDate = (char *) MEM_alloc(50 * sizeof(char *));
	
	strcpy(UPLObjectStr,"");
	strcat(UPLObjectStr,InputPrt);
	strcat(UPLObjectStr,",");
	strcat(UPLObjectStr,PlantName);
	strcat(UPLObjectStr,",");
	strcat(UPLObjectStr,"APL");
	strcat(UPLObjectStr,",");
	strcat(UPLObjectStr,"*");

	
	
	char    *qry_entry[2]            =    {"Name","Type"};
    char    *qry_values[2]           =    {UPLObjectStr,"uplmbom"};

    int     CountObject              =    0;
    tag_t   *Objects_Tag             =    NULLTAG;
    tag_t   UPLItemTag               =    NULLTAG;
	tag_t   UPLQryTag                =    NULLTAG;

    if(QRY_find2("General...", &UPLQryTag));
    if (UPLQryTag)
    {
        printf("\n Query General Found \n");fflush(stdout);
    }
    else
    {
        printf("\n Query Tag General Not Found \n");fflush(stdout);
    }
	printf("\n UPLObjectStr = %s",UPLObjectStr);fflush(stdout);
    
	int  num_to_sort = 1;
	char *keys[1] = {"creation_date"};
	int  	 orders[1]  ={1};
	
	if(QRY_execute_with_sort(UPLQryTag, 2, qry_entry, qry_values, num_to_sort, keys, orders, &CountObject, &Objects_Tag));
    printf("No of Object Found = %d",CountObject);fflush(stdout);
	
	
	int ItrUplObj = 0;
	for(ItrUplObj = 0;ItrUplObj<CountObject;ItrUplObj++)
	{
		UPLItemTag = Objects_Tag[ItrUplObj];
		tag_t ObjRevTag = NULLTAG;
		ITK_CALL(ITEM_ask_latest_rev(UPLItemTag,&ObjRevTag));
		
		char* UPLObjectNameStr = NULL;
        char* UPLObjectPartName = NULL;
        char* UPLObjectPartRev = NULL;
        char* UPLObjectPartSeq = NULL;
        char* UPLObjectPlantName = NULL;
        char* UPLObjectAgency = NULL;
		char* UPLObjectCreationDate = NULL;
            

        AOM_ask_value_string(ObjRevTag,"item_id",&UPLObjectNameStr);
        AOM_ask_value_string(ObjRevTag,"t5_UplPrtNum",&UPLObjectPartName);
        AOM_ask_value_string(ObjRevTag,"t5_UplPrtRev",&UPLObjectPartRev);
        AOM_ask_value_string(ObjRevTag,"t5_UplPrtSeq",&UPLObjectPartSeq);
        AOM_ask_value_string(ObjRevTag,"t5_UplPlnt",&UPLObjectPlantName);
		AOM_UIF_ask_value(ObjRevTag,"creation_date",&UPLObjectCreationDate);
        AOM_ask_value_string(ObjRevTag,"t5_UplAgency",&UPLObjectAgency);
		
		printf("\n UPLObjectNameStr = %s",UPLObjectNameStr);
		printf("\n UPLObjectPartName = %s",UPLObjectPartName);
		printf("\n UPLObjectPartRev = %s",UPLObjectPartRev);
		printf("\n UPLObjectPartSeq = %s",UPLObjectPartSeq);
		printf("\n UPLObjectCreationDate = %s",UPLObjectCreationDate);fflush(stdout);
		
		if ((tc_strcmp(InputRev,UPLObjectPartRev) == 0) && (tc_strcmp(InputSeq,UPLObjectPartSeq) == 0))
		{
	        tag_t  relation_type = NULLTAG;
            GRM_find_relation_type("IMAN_specification",&relation_type);
			if(relation_type != NULLTAG)
            {
                char* relation_name;
				char* UPLObjectNameStr = NULL;
                tag_t*  attachments = NULLTAG;
                int Tcnt = 0;
                TCTYPE_ask_name2( relation_type, &relation_name);
                GRM_list_secondary_objects_only(ObjRevTag,relation_type,&Tcnt,&attachments);
                tag_t  dataset = NULLTAG;
                tag_t  objTypeTag = NULLTAG;
                char*   ObjectClassType;
				AOM_ask_value_string(ObjRevTag,"item_id",&UPLObjectNameStr);
	        	printf("\n Tcnt = %d",Tcnt);fflush(stdout);
	        	printf("\n UPLObjectNameStr = %s",UPLObjectNameStr);fflush(stdout);
                if (Tcnt > 0)
                {
                    int Index = 0;
                    for (Index = 0;Index<Tcnt;Index++)
                    {
                        dataset = attachments[Index];
                        TCTYPE_ask_object_type(dataset,&objTypeTag);
                        TCTYPE_ask_name2(objTypeTag,&ObjectClassType);
                        printf("\n ObjectClassType :: %s\n", ObjectClassType);
	        			
                        if(tc_strcmp(ObjectClassType,"Text") == 0)
                        {
                            int NoOfFile = 0;
                            tag_t* NmdRefObjects = NULLTAG;
                            char   **ref_list = NULL;
                            //AE_ask_dataset_named_refs(dataset,&NoOfFile,&NmdRefObjects);
                            AOM_ask_displayable_values(dataset, "ref_list",&NoOfFile, &ref_list);
                            int FileCnt;
                            char* GenStatus = NULL;
                            char* RptTypeStr = NULL;
                            int RptType = 0;
                            GenStatus=(char*) MEM_alloc(20);
                            RptTypeStr=(char*) MEM_alloc(20);
                            for (FileCnt = 0; FileCnt < NoOfFile; FileCnt++)
                            {
                                printf ("\n Named Reference %d is <%s> ", FileCnt + 1, ref_list[FileCnt]);
								if(tc_strstr(ref_list[FileCnt],"Exception") !=NULL)
								{
									strcpy(UPLReportType,"Y");
									strcpy(UPLCreationDate,UPLObjectCreationDate);
									break;
								}
								else if(tc_strstr(ref_list[FileCnt],"MBOM") !=NULL)
								{
									strcpy(UPLReportType,"G");
									strcpy(UPLCreationDate,UPLObjectCreationDate);
									break;
								}
                            }
                            
                            MEM_free (ref_list);
                        }
						if((tc_strcmp(UPLReportType,"Y") == 0) || (tc_strcmp(UPLReportType,"G") == 0))
						{
							break;
						}
                    }
                }
	        
            }
			
		}
		if((tc_strcmp(UPLReportType,"Y") == 0) || (tc_strcmp(UPLReportType,"G") == 0))
		{
			break;
		}
	}
	
	if((tc_strcmp(UPLReportType,"Y") == 0) || (tc_strcmp(UPLReportType,"G") == 0))
	{
		//Do Nothing
	}
	else
	{
		strcpy(UPLReportType,"R");
	}
	return UPLReportType;
}


void EstimateSheetInformation(char* PrtNum,char* APLStatus,char* APLRlzDate,char* PSDStatus,char* PSDRlzDate)
{
	tag_t PrtMaster = NULLTAG;
	ITEM_find_item(PrtNum,&PrtMaster);
	tc_strcpy(APLStatus,"");
	tc_strcpy(APLRlzDate,"");
	tc_strcpy(PSDStatus,"");
	tc_strcpy(PSDRlzDate,"");
	if(PrtMaster !=NULLTAG)
	{
		tag_t PartESRel = NULLTAG;
		int RelCnt = 0;
		tag_t* ESObjectS = NULLTAG;
		
		GRM_find_relation_type("T5_Design_Estimate_Relation", &PartESRel);
		GRM_list_secondary_objects_only(PrtMaster,PartESRel,&RelCnt,&ESObjectS);
		
		int ESItr = 0;
		for(ESItr=0;ESItr<RelCnt;ESItr++)
		{
			char* ESObjectType = NULL;
			AOM_UIF_ask_value(ESObjectS[ESItr],"object_type",&ESObjectType);
			if(tc_strcmp(ESObjectType,"Estimate Sheet Revision")==0)
			{
				char* ESTName = NULL;
				char* ESTPlantName = NULL;
				AOM_UIF_ask_value(ESObjectS[ESItr],"item_id",&ESTName);
				AOM_UIF_ask_value(ESObjectS[ESItr],"t5_PEPlantName",&ESTPlantName);
				printf("\n ESTName = %s",ESTName);fflush(stdout);
				printf("\n ESTPlantName = %s",ESTPlantName);fflush(stdout);
				
				if (tc_strcmp(ESTPlant,ESTPlantName) == 0)
				{
					int statusCount = 0;
					tag_t* statusList = NULLTAG;
					ITK_CALL( WSOM_ask_release_status_list(ESObjectS[ESItr],&statusCount,&statusList));
					
					int ss = 0;
					for(ss=0;ss<statusCount;ss++)
					{
						char* StatusName    =  NULL;
						
						ITK_CALL(AOM_ask_value_string(statusList[ss],"object_name",&StatusName));						
						printf("\n Attached Status Name is : %s\n",StatusName);fflush(stdout);
						if (tc_strcmp(StatusName,"T5_APLPre-Released") == 0) 
						{   
							tc_strcpy(APLStatus,"Y");
							tc_strcpy(PSDStatus,"Y");
							tc_strcpy(APLRlzDate,"");
							tc_strcpy(PSDRlzDate,"");
							//printf("DateReleased = %s",DateReleased);fflush(stdout);
						}
						else if (tc_strcmp(StatusName,"T5_APLFinalReleased") == 0)
						{   
							char* DateReleased = NULL;
							ITK_CALL(AOM_UIF_ask_value(statusList[ss],"date_released",&DateReleased));
							printf("DateReleased = %s",DateReleased);fflush(stdout);
							tc_strcpy(APLStatus,"G");
							tc_strcpy(PSDStatus,"Y");
							tc_strcpy(APLRlzDate,DateReleased);
							tc_strcpy(PSDRlzDate,"");
							printf("DateReleased = %s",DateReleased);fflush(stdout);
						}
						else if (tc_strcmp(StatusName,"T5_PSDWorking") == 0)
						{ 
							char* DateReleased = NULL;
							tc_strcpy(APLStatus,"G");
							tc_strcpy(PSDStatus,"Y");
							ITK_CALL(AOM_UIF_ask_value(statusList[ss],"date_released",&DateReleased));
							tc_strcpy(APLRlzDate,DateReleased);
							tc_strcpy(PSDRlzDate,"");
							printf("DateReleased = %s",DateReleased);fflush(stdout);
						}
						else if (tc_strcmp(StatusName,"T5_PSDFinalReleased") == 0)
						{   
							char* DateReleased = NULL;
							ITK_CALL(AOM_UIF_ask_value(statusList[ss],"date_released",&DateReleased));
							printf("DateReleased = %s",DateReleased);fflush(stdout);
							tc_strcpy(APLStatus,"G");
							tc_strcpy(PSDStatus,"G");
							tc_strcpy(PSDRlzDate,DateReleased);
							tc_strcpy(APLRlzDate,DateReleased);
						}
					}
					break;
				}
			}
		}
	}
	if ((tc_strcmp(APLStatus,"") == 0) )
	{
		tc_strcpy(APLStatus,"R");
		tc_strcpy(PSDStatus,"R");
	}
}

extern int ITK_user_main (int argc, char* argv[])
{
	int		    status;
    char        *InputList      = NULL;
	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	InputList = ITK_ask_cli_argument("-i=");
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login ());
	
	GetReportTimeStamp();
	
	char* PartTackingPLMStatesRpt = NULL;
	PartTackingPLMStatesRpt = (char *) MEM_alloc(100 * sizeof(char *));
	
	tc_strcpy(PartTackingPLMStatesRpt,"Cost_Release_Workflow_Tacking_PLM_States_");
	tc_strcat(PartTackingPLMStatesRpt,RptTimestamp);
	tc_strcat(PartTackingPLMStatesRpt,".csv");
	
	FILE* fPrtTrckPLMSTReport   = NULL;
	fPrtTrckPLMSTReport=fopen(PartTackingPLMStatesRpt,"w");
	fprintf(fPrtTrckPLMSTReport,"PLANT_CODE,VC_NO,REVISION,SEQUENCE,VC_DESCRIPTION,DR_AR_Status,ERC_VC_Release_LifeCycleState,ERC_VC_Release_Date,MBOM_VC_Release_LifeCycleState,MBOM_VC_Release_Date,APL_VC_Release_LifeCycleState,APL_VC_Release_Date,STD_VC_Release_LifeCycleState,STD_VC_Release_Date,UPL_RELEASED_FROM_APL,UPL_RELEASED_Date,Estimate_Sheet_Release_FROM_APL,Estimate_Sheet_Release_Date_FROM_APL,Estimate_Sheet_Release_FROM_PSD,Estimate_Sheet_Release_Date_FROM_PSD");fflush(fPrtTrckPLMSTReport);
	char buffer1[MAX_LINE_LEN] ="";
	FILE*      fReport                = NULL;
	fReport=fopen(InputList,"r");
	
	//
	if (NULL == fReport)
	{
		printf("file can't be opened \n");
	}
	else
	{
		char buffer1[MAX_LINE_LEN] ="";
		while(fgets(buffer1, MAX_LINE_LEN,fReport)!= NULL)
		{
			char    *InputPlant                  =   NULL;
            char    *inputPartNum                =   NULL;
            char    *InputPartRev                =   NULL;

            InputPlant = (char *) MEM_alloc(100 * sizeof(char *));
            inputPartNum = (char *) MEM_alloc(100 * sizeof(char *));
            InputPartRev = (char *) MEM_alloc(100 * sizeof(char *));
			
			InputPlant = strtok(buffer1,"~");
            inputPartNum = strtok(NULL,"~");
            InputPartRev = strtok(NULL,"~");
           
            printf("\n InputPlant = %s",InputPlant);
            printf("\n inputPartNum = %s",inputPartNum);
            printf("\n InputPartRev = %s",InputPartRev);
			
			SetPlantRlzStatus(InputPlant);
			SetESTPlant(InputPlant);
			tag_t InputPrtRevTag = t5GetItemFindLatestSequence(inputPartNum,InputPartRev);
			
			if (InputPrtRevTag !=NULLTAG)
			{
				char* RevSeq       = NULL;
				char* PartDRStatus = NULL;
				char* PartDesc     = NULL;
				ITK_CALL(AOM_ask_value_string(InputPrtRevTag,"item_revision_id",&RevSeq));
				ITK_CALL(AOM_ask_value_string(InputPrtRevTag,"t5_PartStatus",&PartDRStatus));
				ITK_CALL(AOM_ask_value_string(InputPrtRevTag,"object_desc",&PartDesc));
				
				char* RevDup = NULL;
				char* SeqDup = NULL;
				char* SeqDupDup = NULL;
				SeqDupDup = (char *) MEM_alloc(10 * sizeof(char *));
				RevDup = strtok(RevSeq,";");
				SeqDup = strtok(NULL,";");
				STRNG_replace_str(SeqDup,"\n"," ",&SeqDupDup);
				
				char* TempPrtDesc1 = NULL;
				char* PrtDescDup = NULL;
				TempPrtDesc1 = (char *) MEM_alloc(100 * sizeof(char *));
				PrtDescDup = (char *) MEM_alloc(100 * sizeof(char *));
				STRNG_replace_str(PartDesc,"\n"," ",&TempPrtDesc1);
				STRNG_replace_str(TempPrtDesc1,","," ",&PrtDescDup);
				
				printf("\n InputPrtRevTag Latest RevSeq =%s",RevSeq);fflush(stdout);
				printf("\n InputPrtRevTag Latest PartDRStatus =%s",PartDRStatus);fflush(stdout);
				printf("\n InputPrtRevTag Latest PartDesc =%s",PrtDescDup);fflush(stdout);
				printf("\n InputPrtRevTag Latest RevDup =%s",RevDup);fflush(stdout);
				printf("\n InputPrtRevTag Latest SeqDupDup =%s",SeqDupDup);fflush(stdout);
				
				
				//GetUPLRlzStatus(inputPartNum,InputPlant,RevDup,SeqDupDup);
				
				int      Status_count = 0;
                tag_t*   Status_list = NULLTAG;
                char*    StatusName=NULL;
				ITK_CALL( WSOM_ask_release_status_list(InputPrtRevTag,&Status_count,&Status_list));
				
				char* ERCDateReleased   = NULL;
				char* MBOMDateReleased  = NULL;
				char* APLDateReleased   = NULL;
				char* STDDateReleased   = NULL;
				char* ERCReleasedLC     = NULL;
				char* MBOMReleasedLC    = NULL;
				char* APLReleasedLC     = NULL;
				char* STDReleasedLC     = NULL;
				ERCReleasedLC = (char *) MEM_alloc(10 * sizeof(char *));
				MBOMReleasedLC = (char *) MEM_alloc(10 * sizeof(char *));
				APLReleasedLC = (char *) MEM_alloc(10 * sizeof(char *));
				STDReleasedLC = (char *) MEM_alloc(10 * sizeof(char *));
				
				int ss = 0;
				for(ss=0;ss<Status_count;ss++)
                {
                    ITK_CALL(AOM_ask_value_string(Status_list[ss],"object_string",&StatusName));
                    if((tc_strcmp(StatusName,"ERC Released")==0))
                    {
						AOM_UIF_ask_value(Status_list[ss],"date_released",&ERCDateReleased);
						tc_strcpy(ERCReleasedLC,"ERC Released");
                    }
					if((tc_strcmp(StatusName,"MBOM Released")==0))
					{
						tc_strcpy(MBOMReleasedLC,"MBOM Released");
						AOM_UIF_ask_value(Status_list[ss],"date_released",&MBOMDateReleased);
					}
					if((tc_strcmp(StatusName,APLRlzStatus)==0))
					{
						tc_strcpy(APLReleasedLC,"APL Released");
						AOM_UIF_ask_value(Status_list[ss],"date_released",&APLDateReleased);
					}
					if((tc_strcmp(StatusName,STDRlzStatus)==0))
					{
						tc_strcpy(STDReleasedLC,"STD Released");
						AOM_UIF_ask_value(Status_list[ss],"date_released",&STDDateReleased);
					}
                }
				if((tc_strcmp(ERCReleasedLC,"ERC Released")!=0))
				{
					tc_strcpy(ERCReleasedLC,"Not Released");
					ERCDateReleased = (char *) MEM_alloc(10 * sizeof(char *));
					tc_strcpy(ERCDateReleased,"-");
				}
				if((tc_strcmp(MBOMReleasedLC,"MBOM Released")!=0))
				{
					tc_strcpy(MBOMReleasedLC,"Not Released");
					MBOMDateReleased = (char *) MEM_alloc(10 * sizeof(char *));
					tc_strcpy(MBOMDateReleased,"-");
				}
				if((tc_strcmp(APLReleasedLC,"APL Released")!=0))
				{
					tc_strcpy(APLReleasedLC,"Not Released");
					APLDateReleased = (char *) MEM_alloc(10 * sizeof(char *));
					tc_strcpy(APLDateReleased,"-");
				}
				if((tc_strcmp(STDReleasedLC,"STD Released")!=0))
				{
					tc_strcpy(STDReleasedLC,"Not Released");
					STDDateReleased = (char *) MEM_alloc(10 * sizeof(char *));
					tc_strcpy(STDDateReleased,"-");
				}
				
				printf("\n ERCDateReleased =%s",ERCDateReleased);fflush(stdout);
				printf("\n MBOMDateReleased =%s",MBOMDateReleased);fflush(stdout);
				printf("\n APLDateReleased =%s",APLDateReleased);fflush(stdout);
				printf("\n STDDateReleased =%s",STDDateReleased);fflush(stdout);
				
				char* UPLRptType  = NULL;
				char* UPLCreationDate  = NULL;
				UPLRptType = (char *) MEM_alloc(2 * sizeof(char *));
				UPLCreationDate = (char *) MEM_alloc(50 * sizeof(char *));
				UPLRptType = GetUPLRlzStatus(inputPartNum,InputPlant,RevDup,SeqDupDup,UPLCreationDate);
				printf("\n UPLRptType =%s",UPLRptType);fflush(stdout);
				printf("\n UPLCreationDate =%s",UPLCreationDate);fflush(stdout);
				char* APLStatus = NULL;
				char* APLRlzDate = NULL;
				char* PSDStatus = NULL;
				char* PSDRlzDate = NULL;
				APLStatus = (char *) MEM_alloc(50 * sizeof(char *));
				APLRlzDate = (char *) MEM_alloc(50 * sizeof(char *));
				PSDStatus = (char *) MEM_alloc(50 * sizeof(char *));
				PSDRlzDate = (char *) MEM_alloc(50 * sizeof(char *));
				EstimateSheetInformation(inputPartNum,APLStatus,APLRlzDate,PSDStatus,PSDRlzDate);
			    printf("\n APLStatus =%s",APLStatus);fflush(stdout);
			    printf("\n APLRlzDate =%s",APLRlzDate);fflush(stdout);
			    printf("\n PSDStatus =%s",PSDStatus);fflush(stdout);
			    printf("\n PSDRlzDate =%s",PSDRlzDate);fflush(stdout);
				
				fprintf(fPrtTrckPLMSTReport,"\n%s,",InputPlant);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",inputPartNum);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",RevDup);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",SeqDupDup);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",PrtDescDup);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",PartDRStatus);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",ERCReleasedLC);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",ERCDateReleased);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",MBOMReleasedLC);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",MBOMDateReleased);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",APLReleasedLC);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",APLDateReleased);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",STDReleasedLC);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",STDDateReleased);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",UPLRptType);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",UPLCreationDate);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",APLStatus);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",APLRlzDate);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",PSDStatus);fflush(fPrtTrckPLMSTReport);
				fprintf(fPrtTrckPLMSTReport,"%s,",PSDRlzDate);fflush(fPrtTrckPLMSTReport);
			}
		}
	}
	return status;
}