#!/bin/bash

# Example executable (replace with your executable

# Run the executable
echo "Run the executable"
echo $*
/user/cvprod/shells/tm_CancelRevisionITK -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -item_id=$1 -rev=$2 -seq=$3

# Check the exit status
echo "Check the exit status"

echo $*
if [ $? -eq 0 ]; then
    echo "Success: The command executed correctly."
    exit 0

else
    echo "Error: The command failed with exit status"
    exit 1

fi
