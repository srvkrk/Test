/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: get_revision.c
**
** Functions:- This utility takes item_id as input from file and queries it into teamcenter and writes it's latest revision's ID into output file.
** 
**
**	Date							Author								Modification
**	24-November-2017				Kalpesh Gondhali					Code creation
**
** command to run:
** get_revision -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


FILE		*output 			= NULL;

char		*sep				= ",";

int read_value_from_file(char*);
int get_revision(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter Usr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<filename> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper Usr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;
	char			Data[50]					= "";
	char			outputFile[100]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.csv",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(Filename);
		
	printf("\nEnd of program.....!!\n\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int			ifail 					= ITK_ok;
	
	char 		*itemid					= NULL;
	char 		temp[200];
	//char 		TEMP_str[200];
	
	FILE		* fp 					= NULL;
	
	fp = fopen(Filename, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));
		
			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				//tc_strcpy(TEMP_str,temp);
				itemid = strtok(temp, ",");
				printf("\nInput Item_id:%s\n",itemid);
				
				ifail = get_revision(itemid);
			}			
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       get_revision
    Description:    This function takes the item_id as input and get the revision id of it's
					latest revision.
********************************************************************************************/
int get_revision(char* item_id)
{
	int				ifail 						= ITK_ok;
	int				r_count 					= 0;
	
	tag_t			item_tag 					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	tag_t			*rev_list					= NULLTAG;
	
	char 			*rev_id						= NULL;
	char 			*prev_rev_id				= NULL;
	char 			*rev_rel_status				= NULL;
	char			*status						= "ERC Working";
	
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	ifail = ITEM_ask_latest_rev (item_tag, &rev_tag);
	if(rev_tag == NULLTAG)
		{
			printf("Object not found in TC...!!\n");
			printf("***************************\n");
			
			//fprintf(output,"%s",TEMP_str);
			//fprintf(output,"%s",sep);
			fprintf(output,"Not found\n");
			return 0;
		}
		else
		{
			printf("\nObject Found...!!\n");
		
			ifail = AOM_UIF_ask_value (rev_tag, "release_status_list", &rev_rel_status);
			printf("\nLatest Rev. Release Status:%s\n",rev_rel_status);
			
			if(strcmp(status,rev_rel_status) == 0 )
			{
				ifail = ITEM_list_all_revs (item_tag, &r_count, &rev_list);
				CHECK_FAIL;
				if(r_count < 2)
				{
					printf("\nOnly one rev. present:%s\n",rev_rel_status);
					printf("\n***********************************\n");
					//fprintf(output,"%s",TEMP_str);
					//fprintf(output,"%s",sep);
					fprintf(output,"%s\n",rev_rel_status);
					return 0;
				}
				printf("\nTotal Rev.:%d\n",r_count);
				ifail = AOM_UIF_ask_value (rev_list[r_count-2], "item_revision_id", &prev_rev_id);
				CHECK_FAIL;
				printf("\nPrevious Revision found is:%s\n",prev_rev_id);
				printf("\n***********************************\n");
				
				//fprintf(output,"%s",TEMP_str);
				//(output,"%s",sep);
				fprintf(output,"%s\n",prev_rev_id);	
			}
			else
			{	
				ifail = AOM_UIF_ask_value (rev_tag, "item_revision_id", &rev_id);
				CHECK_FAIL;
				printf("\nRevision found is:%s\n",rev_id);
				printf("\n***********************************\n");
				
				//fprintf(output,"%s",TEMP_str);
				//fprintf(output,"%s",sep);
				fprintf(output,"%s\n",rev_id);
			}
		}
		
	MEM_free(rev_rel_status);
	MEM_free(rev_list);
	MEM_free(prev_rev_id);
	MEM_free(rev_id);
	
	return ifail;
}
