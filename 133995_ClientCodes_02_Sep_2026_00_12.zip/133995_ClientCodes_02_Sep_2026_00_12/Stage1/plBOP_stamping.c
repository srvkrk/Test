#include <tcinit/tcinit.h>
//#include <base_utils/IFail.hxx>
//#include <base_utils/TcResultStatus.hxx>
//#include <base_utils/ScopedSmPtr.hxx>
//#include <Error_Exception.hxx>
#include <tccore/aom.h>
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <ae/dataset.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <tc/folder.h>
#include <tccore/aom_prop.h>
#include <epm/epm_task_template_itk.h>
#include <stddef.h>

#include <unistd.h>
//#include "functionCallForMPP.c"


char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
};
int RemoveRlzStat(tag_t Obj_tag, char* LCSToRemove)//function to remove release status of passed object
{
	tag_t class_id = NULLTAG;
	tag_t RlzStatLst_AttrID = NULLTAG;
	tag_t *RlzStatLst_Attr_tag;
	char *class_name = NULL;
	char *Release_Status = NULL;
	char *Obj_ID =NULL;
	logical	log1;
	logical	*is_it_null = NULL;
	logical	*is_it_empty = NULL;
	//int RlzStatLst_AttrID = 0;
	int RlzStatLst_Length = 0;
	int count=0;
	int	ifail=0;

	tag_t*    status_list1=NULLTAG;
	int              st_count1 = 0;

	(POM_class_of_instance(Obj_tag,&class_id)); 
	(POM_name_of_class(class_id,&class_name));
	printf("\n Class Name is :%s\n",class_name);

	(POM_attr_id_of_attr("release_status_list",class_name,&RlzStatLst_AttrID));
	(WSOM_ask_release_status_list(Obj_tag,&st_count1,&status_list1));
	printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);
    if(st_count1>0)
    {
        /*(POM_unload_instances(1,&Obj_tag));
        (POM_load_instances(1,&Obj_tag,class_id,1));
        (POM_is_loaded(Obj_tag,&log1));
        if(log1 == 1)
        {
            printf(" Load Success\n " );
        }
        else
        printf("Load Faillure\n"  );*/


        ( POM_length_of_attr(Obj_tag, RlzStatLst_AttrID, &RlzStatLst_Length) );
        ( POM_ask_attr_tags(Obj_tag, RlzStatLst_AttrID, 0, RlzStatLst_Length, &RlzStatLst_Attr_tag, &is_it_null, &is_it_empty ));
        int flag = 0;
        for(count=0; count<RlzStatLst_Length;count++)
        {
            AOM_ask_value_string(Obj_tag,"item_id",&Obj_ID);		//to get object id
            printf("\n Object ID is :%s\n",Obj_ID);
            AOM_ask_name(RlzStatLst_Attr_tag[count], &Release_Status);
            printf("\n Release status is1 :%s:%s\n",Release_Status,LCSToRemove);

            //if( (tc_strcmp(Release_Status,LCSToRemove)==0)|| (tc_strcmp(LCSToRemove,"T5_LcsApluReview")==0) )	
            //{
                printf("\n Release status is2 :%s\n",Release_Status);
                
                (AOM_lock(Obj_tag));
                printf("\n lock\n");
                (POM_remove_from_attr(1,&Obj_tag,RlzStatLst_AttrID,flag,1));  //Removes status from object
                printf("\n 1\n");
                (POM_save_instances(1,&Obj_tag,1));
                printf("\n 2\n");

                (POM_refresh_instances(1,&Obj_tag,class_id,2));
                printf("\n 3\n");
                
                
                (AOM_save_without_extensions(Obj_tag));
                printf("\n 4\n");

                (AOM_refresh(Obj_tag,1));
                printf("\n 4\n");
                (AOM_unlock(Obj_tag));
                printf("\n Release Status Removed Successfully :%s\n");

            //}
            flag++;
        }
        MEM_free(RlzStatLst_Attr_tag);

    }

	
	return ITK_ok;
}

void GetGroup(char *plant,char *Input,char *PlantCode,char *PlantName,char *GroupName)
{
    printf("\n ************************************ \n");fflush(stdout);
    printf("\n inside function \n");fflush(stdout);
    char UserInfo1[100];
    tc_strcpy(UserInfo1,Input);
    //tc_strcat(UserInfo1,"1001-PNE;3100-UTK;1500-DWD;2001-JSR;3001-LKO;");
    printf("%s", UserInfo1);
    char PlantNameStored[100];
    tc_strcpy(PlantNameStored,"");
    char *token = strtok(UserInfo1, ";"); //1001-PNE
    while (token != NULL) 
    {
        printf("\n token : %s ", token);
        if(tc_strstr(token,plant)!=NULL)
        {
            tc_strcat(PlantNameStored,token);
        }
        token = strtok(NULL, ";");
    }
    printf("\n PlantNameStored = [%s] \n", PlantNameStored);
    char *PlantCode1 = NULL;
    char *PlantName1 = NULL;
    char *GroupName1 = NULL;
    PlantCode1 = tc_strtok(PlantNameStored,"-");
    PlantName1 = tc_strtok(NULL,"-");
    GroupName1 = tc_strtok(NULL,"-");
    printf("\n PlantCode = [%s] \n", PlantCode1);
    printf("\n PlantName = [%s] \n", PlantName1);
    printf("\n GroupName = [%s] \n", GroupName1);

    tc_strcpy(PlantCode,PlantCode1); // 1001
    tc_strcpy(PlantName,PlantName1); // PNE
    tc_strcpy(GroupName,GroupName1); // pBOP_APLPUNE

    //PNE-CHA-

    printf("\n ************************************ \n");fflush(stdout);
}
void  get_CtrlVal_APLStateInf( char * Plt_Code ,char  APlRevwLC[40],char  AplWrkngLC[40],char  AplRlzdLC[40],char  StdWrkngLC[40],char  StdRlzdLC[40], char PlantLCFlag[40], char StdPlant[40], char StdRevRule[40], char StdCLosRule[40],char StdView[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *APlRevw 			= NULL;
	 char *AplWrkng			= NULL;
	 char *AplRlzd			= NULL;
	 char *StdWrkng			= NULL;
	 char *StdRlzd			= NULL;
	 char *Plant			= NULL;
	 char *stdCode			= NULL;
	 char *RevRule		= NULL;
	 char *stdClsRule		= NULL;
	 char *stdBvr			= NULL;
	 char *PlantOneChar		= NULL;

	 char* viewtocpy		= NULL;
	 int max_char_size = 80;
	 viewtocpy = (char *)MEM_alloc(max_char_size * sizeof(char));

	printf("\n Plt_Code:%s",Plt_Code);fflush(stdout);
	PlantOneChar=subString(Plt_Code,3,1);
	printf("\n PlantOneChar:%s",PlantOneChar);fflush(stdout);
	tc_strcpy(viewtocpy,"");
	tc_strcat(viewtocpy,"STD");
	tc_strcat(viewtocpy,PlantOneChar);
	tc_strcat(viewtocpy," View");
	printf("\n View to copy:%s",viewtocpy);fflush(stdout);
	 

	 if( QRY_find2("Control Objects...", &qryTagCntrl1));
    if (qryTagCntrl1)
    {
        printf("\n Control Object Query Found \n");fflush(stdout);
        qry_valuesCntrl1[0]="APLStateInf";
        qry_valuesCntrl1[1]=Plt_Code;
        qry_valuesCntrl1[2]="0";
        
        if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
    }
    else
    {
        printf("\n Control Object Query not Found \n");fflush(stdout);
    }	
    
    printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

    if(control_number_found1>0)
    {
        
        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &APlRevw);
        printf("\n APlRevw: %s\n",APlRevw);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &AplWrkng);
        printf("\n AplWrkng: %s\n",AplWrkng);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &AplRlzd);
        printf("\n AplRlzd: %s\n",AplRlzd);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &StdWrkng);
        printf("\n StdWrkng: %s\n",StdWrkng);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &StdRlzd);
        printf("\n StdRlzd: %s\n",StdRlzd);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &Plant);
        printf("\n Plant: %s\n",Plant);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &stdCode);
        printf("\n stdCode: %s\n",stdCode);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &RevRule);
        printf("\n RevRule: %s\n",RevRule);fflush(stdout);

        AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo9", &stdClsRule);
        printf("\n stdClsRule: %s\n",stdClsRule);fflush(stdout);

        //AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo10", &stdBvr);
        //printf("\n stdBvr: %s\n",stdBvr);fflush(stdout);

                    
        if(tc_strlen(APlRevw)>0) 
        { 
            tc_strcpy(APlRevwLC,APlRevw);
        }
        if(tc_strlen(AplWrkng)>0) 
        { 
            tc_strcpy(AplWrkngLC,AplWrkng);
        }
        if(tc_strlen(AplRlzd)>0) 				
        {
            tc_strcpy(AplRlzdLC,AplRlzd);
        }
        if(tc_strlen(StdWrkng)>0) 
        {
            tc_strcpy(StdWrkngLC,StdWrkng);
        }
        if(tc_strlen(StdRlzd)>0) 
        {
            tc_strcpy(StdRlzdLC,StdRlzd);
        }
        if(tc_strlen(Plant)>0) 
        {
            tc_strcpy(PlantLCFlag,Plant);
        }
        if(tc_strlen(stdCode)>0) 
        {
            tc_strcpy(StdPlant,stdCode);
        }
        if(tc_strlen(RevRule)>0) 
        {
            tc_strcpy(StdRevRule,RevRule);
        }
        if(tc_strlen(stdClsRule)>0) 
        {
            tc_strcpy(StdCLosRule,stdClsRule);
        }
        if(tc_strlen(viewtocpy)>0) 
        {
            tc_strcpy(StdView,viewtocpy);
        }
    }
    else
    {
        tc_strcpy(APlRevwLC,"T5_LcsAplReview");
        tc_strcpy(AplWrkngLC,"T5_LcsAPLWrkg");
        tc_strcpy(AplRlzdLC,"T5_LcsAplRlzd");
        tc_strcpy(StdWrkngLC,"T5_LcsSTDWrkg");
        tc_strcpy(StdRlzdLC,"T5_LcsStdRlzd");		
        tc_strcpy(PlantLCFlag,"CAR");
        tc_strcpy(StdPlant,"STDC");
        tc_strcpy(StdRevRule,"APLC Release and above");
        tc_strcpy(StdCLosRule,"BOMViewClosureRuleSTDC");
        tc_strcpy(StdView,viewtocpy);
    }
}
int plbopstamping(char *taskname, char * partID, char * revid)
{

    printf("\ncurrrent task :- %s",taskname );
    printf("\nPart ID :- %s",partID );
    printf("\nPart Rev ID :- %s",revid );
    size_t len = strlen(revid);

    
    char *newrevID = malloc(len + 2);
    if (!newrevID) {
        perror("malloc failed");
        return 1;
    }

    //strcpy(newrevID, "");
    strcpy(newrevID, revid);   
    strcat(newrevID, "*");
    printf("\nNew Rev ID:- %s",newrevID);fflush(stdout);

    char plantCode[5];

    strcpy(plantCode, "");
    strncat(plantCode, partID, 4);
    plantCode[4] = '\0'; 

    char *PlantCode  = NULL;
    char *PlantName = NULL;
    char *GroupName = NULL;
    tag_t qryTagCntrl = NULLTAG;

    PlantCode  = (char *) MEM_alloc(50 * sizeof(char *));
    PlantName = (char *) MEM_alloc(50 * sizeof(char *));
    GroupName = (char *) MEM_alloc(50 * sizeof(char *));

    QRY_find2("Control Objects...", &qryTagCntrl);
    if (qryTagCntrl)
    {
        int n_entryCntrl =3;
        char	**qry_valuesCntrl = (char **) MEM_alloc(5 * sizeof(char *));
        char    *qry_entryCntrl[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
        qry_valuesCntrl[0]="plBOPAssignment";
        qry_valuesCntrl[1]="plBOPAssignment";
        qry_valuesCntrl[2]="0";
        int  	control_number_found		= 0;
        tag_t 	*cntr_objects				= NULLTAG;
        char *UserInfo5 = NULL;
        logical retain = 0;
        tag_t PartVCqryTag = NULLTAG;
        int n_entryCnt = 2;
        char *qry_RentryCntrl1[2] = {"Item ID","Revision"};
        char **qry_RvaluesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
        int Partcontrol_num_found = 0;
        tag_t *Partlist_tags = NULLTAG;
        tag_t itemrevqry =NULLTAG;
        tag_t bvrtag=NULLTAG;

        printf("\n Control Object Query Found \n");fflush(stdout);
        QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntr_objects);
        if(control_number_found>0)
        {

            AOM_ask_value_string(cntr_objects[0],"t5_Userinfo5",&UserInfo5); // 1001-APLP;2001-APLJ
            printf("UserInfo4 : %s\n",UserInfo5);fflush(stdout);


            QRY_find2("Item Revision...", &itemrevqry);
            if(itemrevqry)
            {
                qry_RvaluesCntrl1[0] = partID;
                qry_RvaluesCntrl1[1] = newrevID;
                QRY_execute(itemrevqry, n_entryCnt, qry_RentryCntrl1, qry_RvaluesCntrl1, &Partcontrol_num_found, &Partlist_tags);
                if (Partcontrol_num_found>0)
                {
                    for(int statusiterator=0;statusiterator<Partcontrol_num_found;statusiterator++)
                    {

                        tag_t object =NULLTAG;
                        object =Partlist_tags[statusiterator];
                        int 	n_values_bvr=0;
                        tag_t			*bvr_assy_part= NULLTAG;
                        char *view_name=NULL;
                        ITEM_rev_list_bom_view_revs(object, &n_values_bvr, &bvr_assy_part);
                        printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
                        if(n_values_bvr>0)
                        {
                            printf("\n BVR found");fflush(stdout);
                        }
                        for(int assbvr=0;assbvr<n_values_bvr;assbvr++)
                        {
                            ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
                            printf("\n view_name %s",view_name);fflush(stdout);
                            if(strstr(view_name,"view")||strstr(view_name,"View"))
                            {
                                
                                bvrtag =bvr_assy_part[assbvr];

                            }
                        }
                        GetGroup(plantCode,UserInfo5,PlantCode,PlantName,GroupName);
                        printf("PlantCode : %s\n",PlantCode);fflush(stdout);
                        printf("PlantName : %s\n",PlantName);fflush(stdout);

                        char AplRvwLC[40]; // TZ3.46
                        char AplWrkngLC[40];
                        char AplRlzdLc[40];
                        char Stdwrknglc[40];
                        char Stdrlzdlc[40];
                        char PltLcs[40];
                        char StdPlant[40];
                        char StdRevRule[40];
                        char StdCLosRule[40];
                        char StdView[40];
                        get_CtrlVal_APLStateInf(PlantName, AplRvwLC, AplWrkngLC, AplRlzdLc, Stdwrknglc, Stdrlzdlc, PltLcs, StdPlant, StdRevRule, StdCLosRule, StdView); 
                        printf("AplWrkngLC : %s\n",AplWrkngLC);fflush(stdout);
                        printf("AplRlzdLc  : %s\n",AplRlzdLc);fflush(stdout);
                                            
                        if(tc_strcmp(taskname,"APL Working")==0)
                        {
                            printf("Inside APL working\n");fflush(stdout);
                            RemoveRlzStat(object,AplWrkngLC); 
                            RemoveRlzStat(bvrtag,AplWrkngLC);
                            printf("after function call\n");fflush(stdout);                  
                            tag_t APLWorkingTag = NULLTAG;
                            printf("1\n");fflush(stdout); 
                            RELSTAT_create_release_status(AplWrkngLC, &APLWorkingTag);
                            printf("2\n");fflush(stdout); 
                            RELSTAT_add_release_status(APLWorkingTag, 1, &object, retain);
                            RELSTAT_add_release_status(APLWorkingTag, 1, &bvrtag, retain);
                            printf("3\n");fflush(stdout); 
                        }
                        else if(tc_strcmp(taskname,"APL Released")==0)
                        {
                            printf("Inside APL Released\n");fflush(stdout);
                            
                            RemoveRlzStat(object,AplWrkngLC);
                            RemoveRlzStat(bvrtag,AplWrkngLC);
                            tag_t APLReleasedTag = NULLTAG;
                            RELSTAT_create_release_status(AplRlzdLc, &APLReleasedTag);
                            RELSTAT_add_release_status(APLReleasedTag, 1, &object, retain);
                            RELSTAT_add_release_status(APLReleasedTag, 1, &bvrtag, retain);
                        }
                        else
                        {
                            printf("Not compared any task.\n");fflush(stdout);

                        } 

                    }

                }
                else
                {
                    printf("No object found\n");fflush(stdout);

                }
            }

        }
    }

}


extern int ITK_user_main (int argc, char ** argv )
{
    
    char *u = NULL;
	char *p = NULL;
	char *g = NULL;
    char *t = NULL;
    char *r = NULL;
    char *s = NULL;
    
    u =  ITK_ask_cli_argument("-u=");
	p =  ITK_ask_cli_argument("-p=");
	g =  ITK_ask_cli_argument("-g=");
    t =  ITK_ask_cli_argument("-t=");
    r =  ITK_ask_cli_argument("-r=");
    s =  ITK_ask_cli_argument("-s=");
   
    ITK_auto_login();
    plbopstamping(t,r,s);

    printf("\n plBOP Stamping .exe is called......");
    return 0;
}