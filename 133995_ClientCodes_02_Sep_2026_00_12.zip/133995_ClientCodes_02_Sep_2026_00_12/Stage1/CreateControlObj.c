#include <string.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <string.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

int			ifail 				= ITK_ok;

int read_part_item_id(char*);
int Create_object(char*,char*,char*,char*,char*,char*,char*,char*,char*);


int ITK_user_main(int argc, char *argv[])
{

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;
	
	
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-f=");
	
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
		
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	
	ifail = read_part_item_id(Filename);



	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
int read_part_item_id(char* Filename)
{
	
	char *Name = NULL;
	char *SYSCD=NULL;
	char *SUBSYSCD=NULL;
    char *User_info1= NULL;
	char *User_info2= NULL;
	char *User_info3=NULL;
	char *User_info4= NULL;
	char *User_info5= NULL;
	char *User_info6= NULL;
	char temp[500];
	int row =0;

    Name=(char *) MEM_alloc(100);
	SYSCD=(char *) MEM_alloc(100);
    SUBSYSCD=(char *) MEM_alloc(100);
    User_info1=(char *) MEM_alloc(100);
    User_info2=(char *) MEM_alloc(100);
    User_info3=(char *) MEM_alloc(100);
    User_info4=(char *) MEM_alloc(100);
	User_info5=(char *) MEM_alloc(100);
	User_info6=(char *) MEM_alloc(100);
    
    
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{ 

		while (fgets(temp, 500, fp)!= NULL)
	    {
	        //row ++;
			//if(row==1)
			
			//continue;
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
		        
		        Name = strtok(temp,"~");
				printf("\nName of control object:%s",Name);
				
				SYSCD = strtok(NULL,"~");
				printf("\nSYSCD of control object:%s",SYSCD);
				
				SUBSYSCD = strtok(NULL,"~");
				printf("\nSUBSYSCD of control object:%s",SUBSYSCD);
				
				User_info1 = strtok(NULL,"~");
				printf("\nUser_info1 is:%s",User_info1);
				
				User_info2 = strtok(NULL,"~");
				printf("\nUser_info2 is:%s",User_info2);
				
				User_info3 = strtok(NULL,"~");
				
		        printf("\nUser_info3 is:%s",User_info3);
				
				User_info4 = strtok(NULL,"~");
				
				printf("\nUser_info4 is:%s",User_info4);
				
				User_info5 = strtok(NULL,"~");
				printf("\nUser_info5 is:%s",User_info5);
				
				User_info6 = strtok(NULL,"~");
				printf("\nUser_info6 is:%s",User_info6);
				
				
				ifail= Create_object(Name,SYSCD,SUBSYSCD,User_info1,User_info2,User_info3,User_info4,User_info5,User_info6);
			}
			tc_strcpy(temp, "");
	    
			}	  
	}
	else 
		
	{
		printf("File Unable to Open...!!");
	}       
	        
			 fclose(fp);
	return ifail;
}


int Create_object(char* Name,char* SYSCD,char *SUBSYSCD,char *User_info1,char *User_info2,char *User_info3,char *User_info4,char *User_info5,char *User_info6)
{
	tag_t ControlObject_type				= NULLTAG;
	tag_t object_create_input_tag		= NULLTAG;
	tag_t new_object						= NULLTAG;
	

            ifail=TCTYPE_find_type("T5_ControlObject", NULL, &ControlObject_type);   
			ifail=TCTYPE_construct_create_input(ControlObject_type, &object_create_input_tag);
			
			ifail=AOM_set_value_string(object_create_input_tag,"object_name",Name);
            ifail=AOM_set_value_string(object_create_input_tag,"t5_Syscd",SYSCD);
            ifail=AOM_set_value_string(object_create_input_tag,"t5_SubSyscd",SUBSYSCD);
			if(strcmp(User_info1,"NA")!=0)
			{ifail=AOM_set_value_string(object_create_input_tag,"t5_Userinfo1",User_info1);}
			if(strcmp(User_info2,"NA")!=0)
			{ifail=AOM_set_value_string(object_create_input_tag,"t5_Userinfo2",User_info2);}
		    if(strcmp(User_info3,"NA")!=0)
			{ifail=AOM_set_value_string(object_create_input_tag,"t5_Userinfo3",User_info3);}
		    if(strcmp(User_info4,"NA")!=0)
			{ifail=AOM_set_value_string(object_create_input_tag,"t5_Userinfo4",User_info4);}
		    if(strcmp(User_info5,"NA")!=0)
			{ifail=AOM_set_value_string(object_create_input_tag,"t5_Userinfo5",User_info5);}
		    if(strcmp(User_info6,"NA")!=0)
			{ifail=AOM_set_value_string(object_create_input_tag,"t5_Userinfo6",User_info6);}
			ifail=TCTYPE_create_object(object_create_input_tag, &new_object);
            ifail=AOM_save (new_object);
			
			return ifail;

}