/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Deepti Meshram
*  Module		 :   TCUA Desing Rev Data Stamping (CS,STORELOC,LCS,APL-STD EFF DATE) as per TCE
*  Code			 :   t5StampERCPart.c
*  Created on	 :   August 25, 2018
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

static int validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day ,
                                    &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

    return retcode;
}




int convertDate(char* date,char* rDate)
{
	int status;

}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		Monthas;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char*	strDay;
	char*	newCurrentDate;
	char*	strMon;
	char*	strYear;
	char	DateS[20];
	char* cMonth ;
	char CCMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	

	newCurrentDate=NULL;
	newCurrentDate=(char *) MEM_alloc(100);
	tc_strcpy(newCurrentDate,DatetoConvert);

    strYear =  strtok(newCurrentDate,"/"); //1
    cMonth  =  strtok(NULL,"'/'"); //2
    strDay  =  strtok(NULL,"'/'"); //3
    Monthas =  atoi(cMonth);
	getMonth(Monthas,CCMonth);

	printf("\n strYear:%s\n",strYear);fflush(stdout);
	printf("\n CCMonth:%s\n",CCMonth);fflush(stdout);
	printf("\n strDay:%s\n",strDay);fflush(stdout);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,CCMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);fflush(stdout);
}


static date_t TML_token_to_date(char *str )
{
	date_t   date		  = NULLDATE;

	int      month      = 0;          /* Month */
	int      day        = 0;          /* Day */
	int      year       = 0;          /* Year */
	int      hour       = 0;          /* Hour */
	int      minute     = 0;          /* Minutes */
	int      second     = 0;          /* Seconds */

	int ifail=0;

	//printf("\n tc_strlen(str) :%d %s",tc_strlen(str),str);fflush(stdout);

	printf("\n Debugging ==> %s \n",str);fflush(stdout);

	if(tc_strlen(str)>0)
	{
		//printf("\n Debugging ==> 0008999 \n");fflush(stdout);
		//sscanf_s( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		//scanf("%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		sscanf( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		month--;

		date.month = month;
		date.day   = day;
		date.year  = year;
		date.hour  = hour;
		date.minute= minute;
		date.second= second;
		printf("\n month ==>[%d]",month);fflush(stdout);
		printf("\n day ==>[%d]",day);fflush(stdout);
		printf("\n year ==>[%d]",year);fflush(stdout);
		printf("\n hour ==>[%d]",hour);fflush(stdout);
		printf("\n minute ==>[%d]",minute);fflush(stdout);

	}
	return date;
}

int MM_Change_Creation_Date(tag_t revTag,char* creation_date, char* mod_date)
{
	printf("\n Inside MM_Change_Creation_Date \n");fflush(stdout);

	int		status;
	int		ifail		= 0;

	date_t   crtndate	= NULLDATE;
	date_t   mdfcndate	= NULLDATE;

	tag_t	mod_datetag	= NULLTAG;

	char* objTyp		 = NULL;

	date_t dcreation_date;
	date_t dLast_mod_date;
	date_t *apl_last_md_dt_cpy = NULL;

	char* cCreation_date = NULL;
	char* cLast_mod_date = NULL;
	
	ITK_CALL(AOM_ask_value_string(revTag,"object_type",&objTyp));
	printf("\n objTyp is ==> %s\n",objTyp); fflush(stdout);

	printf("\n creation_date [%s]\n",creation_date);fflush(stdout);
	printf("\n mod_date [%s] \n",mod_date);fflush(stdout);

	crtndate = TML_token_to_date(creation_date);
	mdfcndate = TML_token_to_date(mod_date);

	//printf("\n creation_date [%s]\n",crtndate);fflush(stdout);
	//printf("\n mod_date [%s] \n",mdfcndate);fflush(stdout);

	//ITK_CALL(AOM_ask_value_string(revTag,"object_type",&objTyp));
	//printf("\n objTyp is -->%s\n",objTyp); fflush(stdout);

	if(DATE_IS_NULL(crtndate) == 0)
	{
		printf("\n Ketan 1 \n");fflush(stdout);
		ITK_CALL(AOM_refresh(revTag,true));
		ITK_CALL(POM_set_creation_date(revTag,crtndate));
		ITK_CALL(AOM_save_without_extensions(revTag));
		ITK_CALL(AOM_refresh(revTag,true));
	}
	if(DATE_IS_NULL(mdfcndate) == 0)
	{
		printf("\n Ketan 2 \n");fflush(stdout);
		ITK_CALL(AOM_refresh(revTag,true));
		ITK_CALL(POM_set_modification_date(revTag,mdfcndate));
		ITK_CALL(AOM_save_without_extensions(revTag));
		if(tc_strcmp(objTyp,"Design Revision")==0)
		{
			ITK_CALL(AOM_refresh(revTag,true));
			ITK_CALL(POM_attr_id_of_attr("date_released", "WorkspaceObject", &mod_datetag));
			ITK_CALL(POM_set_attr_date(1,&revTag,mod_datetag,mdfcndate));
			ITK_CALL(AOM_save_without_extensions(revTag));
		}
		ITK_CALL(AOM_refresh(revTag,true));
	}
	
	printf("\n After Change on object [%s] \n",objTyp);fflush(stdout);
	ITK_CALL(AOM_ask_value_date(revTag,"creation_date",&dcreation_date));
	ITK_date_to_string(dcreation_date, &cCreation_date);
	printf("\n cCreation_date ==> %s \n",cCreation_date);fflush(stdout);
	
	//ITK_CALL(AOM_lock(revTag));
	//apl_last_md_dt_cpy = (date_t *)MEM_alloc(sizeof(date_t)*2);
	//apl_last_md_dt_cpy[0] = mdfcndate;
	//
	//ITK_CALL(AOM_set_value_date(revTag,"last_mod_date",apl_last_md_dt_cpy));
	//ITK_CALL(AOM_save_without_extensions(revTag));
	//ITK_CALL(AOM_unlock(revTag));

	ITK_CALL(AOM_ask_value_date(revTag,"last_mod_date",&dLast_mod_date));
	ITK_date_to_string(dLast_mod_date, &cLast_mod_date);
	printf("\n cLast_mod_date ==> %s \n",cLast_mod_date);fflush(stdout);


	return ITK_ok;
}




int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}



int setAttributesOnDesign(tag_t* item,char* Uom)
{
	printf("\n Inside setAttributesOnDesign \n");fflush(stdout);
	
	int		status;
	int		ifail	=0;

	char* ent_uom=NULL;
	tag_t unit_of_measure=NULLTAG;

	ent_uom=(char *) MEM_alloc(10 * sizeof(char *));

	ITK_CALL(AOM_lock(*item));

	if(strcmp(Uom,"1")==0)
	{
		strcpy(ent_uom,ONE);
	}
	else if(strcmp(Uom,"2")==0)
	{
		strcpy(ent_uom,TWO);
	}
	else if(strcmp(Uom,"3")==0)
	{
		strcpy(ent_uom,THREE);
	}
	else if(strcmp(Uom,"4")==0)
	{
		strcpy(ent_uom,FOUR);
	}
	else if(strcmp(Uom,"5")==0)
	{
		strcpy(ent_uom,FIVE);
	}
	else if(strcmp(Uom,"6")==0)
	{
		strcpy(ent_uom,SIX);
	}
	else if(strcmp(Uom,"7")==0)
	{
		strcpy(ent_uom,SEVEN);
	}
	else if(strcmp(Uom,"8")==0)
	{
		strcpy(ent_uom,EIGHT);
	}
	else
	{
		strcpy(ent_uom,"-");
	}

	ITK_CALL(UOM_find_by_symbol(ent_uom,&unit_of_measure));
	if(ITK_ok != (ifail =ITEM_set_unit_of_measure(*item, unit_of_measure)))
	{
		return ifail;
	}

	ITK_CALL ( AOM_set_value_string(*item,"t5_uom",ent_uom));

	ITK_CALL(AOM_save_without_extensions(*item));
	ITK_CALL(AOM_unlock(*item));
}

int setAttributesOnDesignRevision(tag_t* rev,char* Part_MakeBuy,char* Part_SLOC,char* GenPlantCS,char* getPlantStore,char* Part_Type,char* Drawing_Indicator,char* Material_In_drawing,char* EnvelopeDimensions,
char* Weight,char* MThickness,char* StdPartIndicator,char* SpareInd,char* CMVRCertificationReqd,char* ModelIndS,char* ColourIndS,char* DeignOwnUnitS,char* t5HomologationReqdS,char* mod_desc,char* DrawingNoS)
{
	printf("\n Inside setAttributesOnDesignRevision \n");fflush(stdout);

	int status;

	double dweight=0;

	int     ifail               = ITK_ok;

	ITK_CALL(AOM_lock(*rev));

	printf("\n Part_MakeBuy ==> %s\n",Part_MakeBuy);fflush(stdout);
	printf("\n Part_SLOC ==> %s\n",Part_SLOC);fflush(stdout);

	if(Part_MakeBuy !=NULL)
	{
		printf("\n Setting the value for CS... \n");fflush(stdout);
		//ITK_CALL ( AOM_set_value_string(*rev,GenPlantCS,Part_MakeBuy));
	}
	
	if(Part_SLOC !=NULL)
	{
		printf("\n Setting the value for Store Location... \n");fflush(stdout);
		//ITK_CALL ( AOM_set_value_string(*rev,getPlantStore,Part_SLOC));
	}
	ITK_CALL(AOM_save_without_extensions(*rev));
	ITK_CALL(AOM_unlock(*rev));
	ITK_CALL(AOM_lock(*rev));

	printf("\n Part_Type ==> %s\n",Part_Type);fflush(stdout);
	if(Part_Type!=NULL)
	{
		if (tc_strcmp(Part_Type,"D")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","D"));
		}
		if (tc_strcmp(Part_Type,"A")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","A"));
		}
		if (tc_strcmp(Part_Type,"C")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","C"));
		}
		if (tc_strcmp(Part_Type,"VC")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","VC"));
		}
		if (tc_strcmp(Part_Type,"V")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","V"));
		}
		if (tc_strcmp(Part_Type,"T")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","T"));
		}
		if (tc_strcmp(Part_Type,"VCCR")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","VCCR"));
		}
		if (tc_strcmp(Part_Type,"G")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","G"));
		}
		if (tc_strcmp(Part_Type,"R")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","R"));
		}
		if (tc_strcmp(Part_Type,"SA")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","SA"));
		}
		if (tc_strcmp(Part_Type,"SP")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","SP"));
		}
		if (tc_strcmp(Part_Type,"PE")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","PE"));
		}
		if (tc_strcmp(Part_Type,"P")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","P"));
		}
		if (tc_strcmp(Part_Type,"M")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","M"));
		}
		if (tc_strcmp(Part_Type,"CM")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","CM"));
		}
		if (tc_strcmp(Part_Type,"DC")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","DC"));
		}
		if (tc_strcmp(Part_Type,"DA")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","DA"));
		}
		if (tc_strcmp(Part_Type,"IFD")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","IFD"));
		}
		if (tc_strcmp(Part_Type,"CR TPL")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","CR TPL"));
		}
	}
	ITK_CALL(AOM_save_without_extensions(*rev));
	ITK_CALL(AOM_refresh(*rev,true));
	ITK_CALL(AOM_unlock(*rev));

	printf("\n Drawing_Indicator ==> %s\n",Drawing_Indicator);fflush(stdout);
	printf("\n Material_In_drawing ==> %s\n",Material_In_drawing);fflush(stdout);

	ITK_CALL(AOM_lock(*rev));
	if(Drawing_Indicator!=NULL) 
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingInd",Drawing_Indicator));
	}
	if((Material_In_drawing!=NULL)||(strcmp(Material_In_drawing," ")!=0)) 
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_Material",Material_In_drawing));
	}

	printf("\n EnvelopeDimensions ==> %s\n",EnvelopeDimensions);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_EnvelopeDimensions",EnvelopeDimensions));

	printf("\n Weight ==> %s\n",Weight);fflush(stdout);
	dweight=atof(Weight);
	ITK_CALL ( AOM_set_value_double(*rev,"t5_Weight",dweight));

	printf("\n MThickness ==> %s\n",MThickness);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_MThickness",MThickness));

	printf("\n StdPartIndicator ==> %s\n",StdPartIndicator);fflush(stdout);
	if(strcmp(StdPartIndicator,"-")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_StdPartIndicator",false));
	}
	else if(strcmp(StdPartIndicator,"+")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_SpareInd",true));
	}

	printf("\n SpareInd ==> %s\n",SpareInd);fflush(stdout);
	if(strcmp(SpareInd,"-")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_SpareInd",false));
	}
	else if(strcmp(SpareInd,"+")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_SpareInd",true));
	}

	printf("\n CMVRCertificationReqd ==> %s\n",CMVRCertificationReqd);fflush(stdout);
	if(strcmp(CMVRCertificationReqd,"-")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_CMVRCertificationReqd",false));
	}
	else if(strcmp(CMVRCertificationReqd,"+")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_CMVRCertificationReqd",true));
	}

	printf("\n ModelIndS ==> %s\n",ModelIndS);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ModelIndicator",ModelIndS));

	printf("\n ColourIndS ==> %s\n",ColourIndS);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ColourInd",ColourIndS));

	printf("\n DeignOwnUnitS ==> %s\n",DeignOwnUnitS);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DsgnOwn",DeignOwnUnitS));

	printf("\n t5HomologationReqdS ==> %s\n",t5HomologationReqdS);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_HomologationReqd",t5HomologationReqdS));

	printf("\n mod_desc ==>%s\n",mod_desc);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc));

	printf("\n DrawingNoS ==>%s\n",DrawingNoS);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingNo",DrawingNoS));
	
	ITK_CALL(AOM_save_without_extensions(*rev));
	ITK_CALL(AOM_unlock(*rev));

	
		
	

}

int QueryPart(char* Part_Number,tag_t* PartTag)
{
	printf("\n Inside QueryPart Function \n");fflush(stdout);

	int ifail  = 0;
	int status = 0;

	const char *qry_entries[1];
	const char *qry_values[1];
	
	tag_t		*itemclass	=	NULLTAG;
	tag_t		item		=	NULLTAG;

	int			n_tags_found=0;

	qry_entries[0] ="item_id";
	qry_values[0] = Part_Number;

	//Find Item by its ID.
	ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
	printf("\n Number of Tags found : %d \n",n_tags_found);fflush(stdout);

	if(n_tags_found>0)
	{
		*PartTag= itemclass[0];
	}

	return ifail;
}

/*******MAIN FUNCTION************/

extern int ITK_user_main (int argc, char ** argv )
{   
	logical isCheckOut=false;
	FILE* fp						= NULL;
	FILE* fperror					= NULL;
	FILE* fp_partStampingList		= NULL;
	FILE* fp_Efferror				= NULL;

	char*	inputline				= NULL;
	char*	inputpartline			= NULL;
	char*	Part_List_File			= NULL;

	char*	ES_Num				= NULL;
	char*	ES_ReleaseStatus	= NULL;
	char*	ES_ReleaseStatusDup	= NULL;
	char*	ES_Desc				= NULL;
	char*	ES_Country			= NULL;
	char*	ES_CKD_Ind			= NULL;
	char*	ES_CKD_VC			= NULL;
	char*	ES_CKD_VCDup		= NULL;
	char*	PlantName				= NULL;
	char*	inputuser				= NULL;
	char*	inputpwd				= NULL;
	char*	inputgrp				= NULL;
	char*	PartListName			= NULL;
	char**	display_value;
	char*	tempStringt				= NULL;
	
	int     ifail               = ITK_ok;
	int		n_strings			= 1;
	int		l_strings			= 500;
	int		index				= 0;
	int		status;

	tag_t	t_dsgtyp			= NULLTAG;
	tag_t	t_dsgrevtyp			= NULLTAG;
	tag_t	t_dsgcre			= NULLTAG;
	tag_t	t_dsgrevcre			= NULLTAG;
	tag_t	t_dsgtag			= NULLTAG;
	tag_t 	DesignRevTag	    = NULLTAG;

	printf("\n ~~~~~~~~~ Ketan Inside Program ES_Loading_CKD ~~~~~~~~~~~\n");fflush(stdout);

	inputuser	   = ITK_ask_cli_argument("-u=");
	inputpwd	   = ITK_ask_cli_argument("-pf=");
	inputgrp	   = ITK_ask_cli_argument("-g=");
	Part_List_File = ITK_ask_cli_argument("-i=");

	ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	ITK_CALL(ITK_auto_login());
	ITK_set_bypass(true);

	fp=fopen("Part_List_File.txt","r");
	FILE*	fp_Output  = NULL;
	FILE*	fp_Output1 = NULL;
	fp_Output  = fopen("Base_VC_Not_Found.txt","w");
	fp_Output1 = fopen("ES_DS_Found.txt","w");

	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			fputs(inputline,stdout);	
			
			ES_Num				= NULL;
			ES_ReleaseStatusDup	= NULL;
			ES_Desc				= NULL;
			ES_Country			= NULL;
			ES_CKD_Ind			= NULL;
			ES_CKD_VCDup		= NULL;
			
			ES_Num				=strtok(inputline,"~");  
			ES_ReleaseStatusDup	=strtok(NULL,"~"); 
			ES_Desc				=strtok(NULL,"~"); 
			ES_Country			=strtok(NULL,"~"); 
			ES_CKD_Ind			=strtok(NULL,"~");
			ES_CKD_VCDup		=strtok(NULL,"~");
			
			printf("\n ES_Num => [%s]\n",ES_Num);fflush(stdout);
			printf("\n ES_ReleaseStatusDup => [%s]\n",ES_ReleaseStatusDup);fflush(stdout);
			printf("\n ES_Desc =>[%s]\n",ES_Desc);fflush(stdout);
			printf("\n ES_Country => [%s]\n",ES_Country);fflush(stdout);
			printf("\n ES_CKD_Ind => [%s]\n",ES_CKD_Ind);fflush(stdout);
			printf("\n ES_CKD_VCDup => [%s]\n",ES_CKD_VCDup);fflush(stdout);
			
			//
			tag_t	BaseVC_numberTag		= NULLTAG;
			
			QueryPart(ES_CKD_VCDup,&BaseVC_numberTag);

			if(BaseVC_numberTag == NULLTAG )
			{	
				printf("\n Base VC [%s] not found so taking Next ESDS \n",ES_CKD_VCDup);fflush(stdout);
				fprintf(fp_Output,"%s\n",ES_CKD_VCDup);fflush(fp_Output);
				continue;
			}	
			
			////////////////////////////////
			printf("\n Checking ES_DS => [%s] is already created or not .....\n",ES_Num);

			const char *qry_entries[2];
			const char *qry_values[2];
			
			tag_t		*itemclass	=	NULLTAG;
			tag_t		item		=	NULLTAG;

			int			n_tags_found=0;

			qry_entries[0] ="item_id";
			qry_values[0] = ES_Num;
			qry_entries[1] ="object_type";
			qry_values[1] = "T5_EPSExp";

			//Find Item by its ID.
			ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclass);
			printf("\n Number of Tags found => %d \n",n_tags_found);fflush(stdout);

			if(n_tags_found==0)
			{			
				printf("\n Inside ES-DS Creation \n",n_tags_found);fflush(stdout);

				ES_CKD_VC		 = strdup(ES_CKD_VCDup); 
				ES_ReleaseStatus = strdup(ES_ReleaseStatusDup);

				if(tc_strcmp(ES_ReleaseStatus,"LcsMktRel")==0)
				{
					tc_strcpy(ES_ReleaseStatus,"T5_LcsMktRel");				
				}
				else
				{
					tc_strcpy(ES_ReleaseStatus,"T5_LcsMktWor");				
				}

				char*	EsSpecTyp	= NULL;	
				if(tc_strstr(ES_Num,"ES")!=NULL)
				{
					EsSpecTyp = "E";
				}
				else
				{
					EsSpecTyp = "D";
				}		

				char    *qry_entryCntrl1[3]  = {"SYSCD","Information-2","Delete Indicator"};	
				char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

				int cntrlcnt=0;
				int  control_number_found1=0;

				tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

				tag_t   qryTagCntrl1     = NULLTAG;
				int     n_entryCntrl1    = 3;

				char*	ES_Country_Final	= NULL;

				if( QRY_find2("Control Objects...", &qryTagCntrl1));

				if (qryTagCntrl1)
				{
					printf("\n Control Object Query Found \n");fflush(stdout);
					qry_valuesCntrl1[0]="CKDCUPCD";
					qry_valuesCntrl1[1]=ES_Country;
					qry_valuesCntrl1[2]="0";
					
					if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
				}
				else
				{
					printf("\n Control Object Query not Found \n");fflush(stdout);
				}	
				
				printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

				if(control_number_found1>0)
				{
					AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &ES_Country_Final);							
				}
				else
				{
					printf("\n Inside Else \n");fflush(stdout);
					ES_Country_Final = "IND";
					//tc_strcpy(ES_Country_Final,"IND");
				}
				

				if(tc_strcmp(ES_CKD_Ind,"+")==0)
				{
					tc_strcpy(ES_CKD_Ind,"True");				
				}
				else
				{
					tc_strcpy(ES_CKD_Ind,"False");				
				}

				printf("\n Final ES_Country_Final => %s\n",ES_Country_Final);fflush(stdout);	
				printf("\n Final ES_CKD_Ind --> %s \n",ES_CKD_Ind);fflush(stdout);
				printf("\n Final EsSpecTyp => [%s]\n",EsSpecTyp);fflush(stdout);
				printf("\n Final ES_ReleaseStatus => [%s] \n",ES_ReleaseStatus);fflush(stdout);

				display_value = (char**)malloc( n_strings * sizeof *display_value );
				for( index=0; index<n_strings; index++ )
				{
					display_value[index] = (char*)malloc( l_strings + 1 );
				}
				
				// Design // 
				ITK_CALL(TCTYPE_find_type("T5_EPSExp",NULL,&t_dsgtyp));
				if (t_dsgtyp!=NULLTAG)
				{
					printf("\n t_dsgtyp is not null tag \n");fflush(stdout);
				}
				ITK_CALL(TCTYPE_construct_create_input(t_dsgtyp,&t_dsgcre));
							
				// Design Revision //
				ITK_CALL(TCTYPE_find_type("T5_EPSExpRevision",NULL,&t_dsgrevtyp));
				ITK_CALL(TCTYPE_construct_create_input(t_dsgrevtyp,&t_dsgrevcre));
				
				printf("\n Setting Value in Design \n");fflush(stdout);
				tc_strcpy(display_value[0],ES_Num);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"item_id",1,(const char**)display_value));

				tc_strcpy(display_value[0],ES_Desc);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"object_name",1,(const char**)display_value));

				tc_strcpy(display_value[0],ES_Desc);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"object_desc",1,(const char**)display_value));

				tc_strcpy(display_value[0],EsSpecTyp);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"t5_EsSpecTyp",1,(const char**)display_value));	

				ITK_CALL( AOM_tag_to_string(t_dsgrevcre, &tempStringt) );
				tc_strcpy(display_value[0],tempStringt);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"revision",1,(const char**)display_value));
				
				printf("\n Setting Value in Design Revision\n");fflush(stdout);
				tc_strcpy( display_value[0], "NR");
				ITK_CALL( TCTYPE_set_create_display_value( t_dsgrevcre, "item_revision_id", 1,(const char**)display_value));

				tc_strcpy(display_value[0],ES_Desc);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgrevcre,"object_name",1,(const char**)display_value));

				tc_strcpy(display_value[0],ES_Desc);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgrevcre,"object_desc",1,(const char**)display_value));
				
				tc_strcpy(display_value[0],ES_Country_Final);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgrevcre,"t5_EsCountry",1,(const char**)display_value));

				tc_strcpy(display_value[0],ES_CKD_Ind);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgrevcre,"t5_CKDInd",1,(const char**)display_value));
				
				tc_strcpy(display_value[0],ES_CKD_VC);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgrevcre,"t5_ESRelVcNo",1,(const char**)display_value));

				ITK_CALL( TCTYPE_create_object( t_dsgcre,&t_dsgtag) );
				ITK_CALL( AOM_save_without_extensions(t_dsgtag));
				
				ITEM_ask_latest_rev(t_dsgtag,&DesignRevTag);
				ITK_CALL( AOM_save_without_extensions(DesignRevTag));

				// Creating Relation between VC and ES/DS

				if (ES_CKD_VC!=NULL)
				{
					printf("\n Test 7 \n");fflush(stdout);
					char *newid;
					//char *item_idval=NULL;

					newid=(char *) MEM_alloc (20);

					ITK_CALL(POM_enquiry_create("vc_query"));
					tc_strcpy(newid,ES_CKD_VC);

					const char *new_id_val1={newid};
					const char *attr="item_id";

					const char *sel_attrs[1] = {"puid"};
					
					ITK_CALL(POM_enquiry_add_select_attrs("vc_query", "Design", 1, sel_attrs));
					ITK_CALL(POM_enquiry_set_string_value("vc_query", "value", 1, &new_id_val1,POM_enquiry_bind_value));
					ITK_CALL(POM_enquiry_set_attr_expr ("vc_query", "expression", "Design", attr, POM_enquiry_equal, "value"));
					ITK_CALL(POM_enquiry_set_where_expr ( "vc_query", "expression" ));
					ITK_CALL(POM_enquiry_add_order_attr ( "vc_query","Design","creation_date",POM_enquiry_desc_order));
					
					int  rows1 = 0, columns1 = 0;
					void ***report1;

					POM_enquiry_execute("vc_query", &rows1, &columns1, &report1);
					POM_enquiry_delete("vc_query");
					tag_t objtag1 = NULLTAG;
					char *item_Vc=NULL;
				
					if (rows1 != 0)
					{
						printf("\n Test 8 \n");fflush(stdout);
						objtag1  = *(tag_t*)(report1[0][0]);

						printf("\n \n Ketan number of row : %d cols : %d \n",rows1,columns1);fflush(stdout);
						
						ITK_CALL(AOM_ask_value_string(objtag1,"item_id",&item_Vc));
						printf("\n VC no => %s ",item_Vc);fflush(stdout);
      
						tag_t vcrevtag=NULLTAG;
						char *item_NewVc=NULL;
						char *item_NewEsVc=NULL;
      
						ITK_CALL(ITEM_ask_latest_rev (objtag1, &vcrevtag));
						
						tag_t relation_type,relation = NULLTAG;
						
						ITK_CALL(AOM_ask_value_string(vcrevtag,"item_id",&item_NewVc));
						printf("\n new VC no is %s ",item_NewVc);fflush(stdout);
						
						ITK_CALL(AOM_ask_value_string(DesignRevTag,"item_id",&item_NewEsVc));
						printf("\n new esvc VC no is %s ",item_NewEsVc);fflush(stdout);

						ITK_CALL(GRM_find_relation_type("T5_EpsVhR",&relation_type));
						ITK_CALL(GRM_create_relation(DesignRevTag,vcrevtag, relation_type,NULLTAG,&relation));
						ITK_CALL(GRM_save_relation(relation));						
					}
				}
				
				tag_t   status2				= NULLTAG;
				char*	Task_ReleaseStatus	= NULL;
				logical retain	=	false;

				ITK_CALL(RELSTAT_create_release_status(ES_ReleaseStatus,&status2));
				ITK_CALL(AOM_ask_name(status2, &Task_ReleaseStatus));
				printf("\n  Task_ReleaseStatus => %s\n",Task_ReleaseStatus);fflush(stdout);
				ITK_CALL(RELSTAT_add_release_status(status2,1,&DesignRevTag,retain));
			}
			else
			{
				printf("\n ES-DS => [%s] already exists...\n" ,ES_Num);fflush(stdout);
				fprintf(fp_Output1,"%s\n",ES_Num);fflush(fp_Output);
			}			
		}
		printf("\n----------------END OF PART-----------------------------------\n");fflush(stdout);
	}
	else
	{
		printf("\n Can't open file \n");fflush(stdout);
	}

	printf("\n CVprod - Ketan ES-DS_Loading_CKD SUCCESS \n");fflush(stdout);

	////////////
	

	
	
	return status;

   
}
 
