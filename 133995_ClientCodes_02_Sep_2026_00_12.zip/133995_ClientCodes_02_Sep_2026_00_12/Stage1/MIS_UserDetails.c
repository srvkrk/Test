#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <tccore/item.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/tctype.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <res/res_itk.h>
#include <pom/pom/pom.h>
#include <tccore/uom.h>
#include <tccore/aom_prop.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <sa/user.h>
#include <tc/folder.h>
#include <ae/datasettype.h>
#include <ae/dataset.h>
#define ITK_err (EMH_USER_error_base + 2)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
void remove_encoding_chars(char *str) {
    int i = 0, j = 0;
    while (str[i] != '\0') {
        // Check if the character is printable or if it's one of the allowed ones
        // Printable characters are those with ASCII value >= 32 (excluding control chars like \n, \r)
        if (isprint(str[i]) || str[i] == ' ') {  // Allow spaces and printable characters
            str[j++] = str[i];  // Copy valid character
        }
        i++;
    }
    str[j] = '\0';  // Null-terminate the string
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


extern int ITK_user_main(int argc, char *argv[] )
{

	


//			char	*values[3];
			char	*values[1];
//			char	*qry_Input[3]			= {"License Level","Status","Id"};
		    char	*qry_Input[1]			= {"Id"};
//			int		n_Input					= 3;
			int		n_Input					= 1;
			int		Count					= 0;
			int itr=0;
			int noOfReferences=0;
			int fldFound=0;
			tag_t	*Usertag		   = NULLTAG;
			tag_t	Quser			   = NULLTAG;
			tag_t	persontag		   = NULLTAG;
			tag_t	RelationType	   = NULLTAG;
			tag_t	valueTag		   = NULLTAG;
			tag_t	UserTag1		   = NULLTAG;
			tag_t sysUserTag           = NULLTAG;
			char *fldObjType         =   NULL;
			char *fldObjName         =   NULL;
			tag_t sysHomeTag           = NULLTAG;
	        tag_t newFolderTag         = NULLTAG;
	        tag_t datasetType          = NULLTAG; 
	        tag_t datasetTag           = NULLTAG;
	        tag_t rdatasetTag          = NULLTAG;
			char *datasetIdValue     =   (char*) MEM_alloc(200*sizeof(char));
	
	
	tag_t *cfg0ModelsTags             =  NULLTAG;
	tag_t *cfg0AvailabilityRulesTags  =  NULLTAG;
	tag_t *cfg0OptionValuesTags       =  NULLTAG;
	tag_t *folderReference            = NULLTAG;
			char *sSysUser           =   NULL;
			int lov1;
			char* emailid=NULL;
			char* usernameTag                   = NULL;
            char* useridTag  = NULL;
            char*    lov= NULL;
            
            char* class_name                    = NULL;
            char* deparmentTag                  = NULL;
			char* bu                  = NULL;
			char *sysUserId          =   (char*) MEM_alloc(200*sizeof(char));
			char* division                  = NULL;
			char *csvLog             =   (char*) MEM_alloc(200*sizeof(char));
            char* useragencyTag                 = NULL;
            char* userlocationTag               = NULL;
			char* license_level                 =NULL;
			char *lincese_level1                =NULL;
			char *fnd0LicenseServer              =NULL;
			char *last_login_time              =NULL;
			char *status              =NULL;
			char *status1              =NULL;
			char *UserId1                =NULL;
			char *UserId2                =NULL;
			int i=0;
			int usercount=0;
			int count2=0;
			int	n_values =0; 
			char *UserName=NULL;
			char *timeStrUpdated     =   NULL;
            char *timeStrUpdatedNew  =   NULL;
			char *timeStr            =   NULL;
			char *sUserName            =   NULL;
			char *sPasswordFile            =   NULL;
			char *sGroup            =   NULL;
			FILE* fp = NULL;
			FILE *ftr=NULL;
			char* filename   = NULL;
            char  temp[500];
			char buffer[50];
            //char* FirstName=NULL;
            //char* MiddleName=NULL;
           // char* LastName=NULL;
		   sUserName      = ITK_ask_cli_argument("-u=");
           sPasswordFile  = ITK_ask_cli_argument("-pf=");
           sGroup         = ITK_ask_cli_argument("-g=");
	       sSysUser       = ITK_ask_cli_argument("-j="); 
		  
           
           time_t mytime = time(NULL);
	       timeStr = ctime(&mytime);
	       timeStr[strlen(timeStr)-1] = '\0';
	       STRNG_replace_str(timeStr," ","_",&timeStrUpdated);
		    STRNG_replace_str(timeStrUpdated,":","_",&timeStrUpdatedNew);
		   tc_strcpy(csvLog,"/tmp/");  //  /tmp/ - to be added if required
	       tc_strcat(csvLog,"MIS_UserDetails_Report_");
	       tc_strcat(csvLog,"_");
	       tc_strcat(csvLog,timeStrUpdatedNew);
	       tc_strcat(csvLog,".csv");
		   tc_strcpy(datasetIdValue,"");
	       tc_strcat(datasetIdValue,"MIS_UserDetails_Report_");
	       tc_strcat(datasetIdValue,timeStrUpdatedNew);
		   fp = fopen(csvLog,"w");
		   printf("- sUserName         = %s\n",sUserName      );
	       printf("- sPasswordFile     = %s\n",sPasswordFile  );
	       printf("- sGroup            = %s\n",sGroup         );
	       printf("- sSysUser          = %s\n",sSysUser       );
	       printf("- csvLog            = %s\n",csvLog         );
	       printf("- timeStrUpdated    = %s\n",timeStrUpdated );
	       printf("- timeStrUpdatedNew = %s\n",timeStrUpdatedNew ); 
		   int	iStatus= 0;
		   ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	       iStatus = ITK_auto_login();
		   ITK_set_journalling(TRUE); 


            
			
//			values[0] = "0";
//			values[1] = "0";
//			values[2] = "*";
			
			
//			if(QRY_find2("UserFndACtive", &Quser));
			//ftr=fopen("InputUserId.txt","r");
			// if(ftr==NULL)
       // {
           //     printf("Read File\n");
          //      printf("unable  open  File\n ");fflush(stdout);
          //      return 1;
       // }
		// else
        //{
                // while(fgets(temp,500,ftr)!=NULL)
              //  {

                        // if(temp != NULL)
                       //  {

                          //   fputs(temp,stdout);
                           //      UserId1 = strtok(temp,",");
                           //      UserId2=strtok(NULL,",");



			values[0] = "*";
			if(QRY_find2("UserFind", &Quser));
			if(Quser)
		{
			 if(QRY_execute(Quser, n_Input, qry_Input, values, &Count, &Usertag));
			 printf("\n QUERY count== %d...................\n", Count);fflush(stdout);
		}
		if(Count==0)
			{

		    values[0] = UserId2;
			if(QRY_find2("UserFind", &Quser));
			if(Quser)
		    {
			 if(QRY_execute(Quser, n_Input, qry_Input, values, &Count, &Usertag));
			 printf("\n QUERY count another User== %d...................\n", Count);fflush(stdout);
		    }
		
		    }
			


			 //fprintf(fp,"User ID,Email ID,First Name,Middle Name,Last Name,Authorization,status,LicenseServer,Last System Access Time\n");
			 fprintf(fp,"User Name,Login ID,Mail ID,Status(Active/Inactive),License Authorization(Author/Consumer),License Server,Organization,Cost Center Name,Cost Center No,Engagement Type,BU,Department,Division,User Agency,User Location\n");
			  if(fp != NULL)
			{
					
			   printf("\n File is opened \n");fflush(stdout);
		      
			
			}
			else
		   {
				
				printf("\n File is  NOT opened \n");fflush(stdout);
				
			}
		 lincese_level1=(char *)MEM_alloc(200);
         status1=(char *)MEM_alloc(200);
		// MiddleName=(char *)MEM_alloc(200);
		 //LastName=(char *)MEM_alloc(200);
			for(i=0; i<Count; i++)
	     {


			UserTag1 = Usertag[i];

			ITK_CALL(AOM_ask_value_string(UserTag1,"user_name",&usernameTag));

			
			ITK_CALL(STRNG_replace_str(usernameTag,",","",&UserName));
			printf("\n Name of user: %s \n",UserName);fflush(stdout);
			
			ITK_CALL(AOM_ask_value_string(UserTag1,"user_id",&useridTag));
			
			printf("\n User ID of user: %s \n",useridTag);fflush(stdout);

            ITK_CALL(AOM_UIF_ask_value(UserTag1,"status",&status));
			
			printf("\n User ID of user: %s \n",status);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(UserTag1,"last_login_time",&last_login_time));
			
			printf("\n User ID of user: %s \n",last_login_time);fflush(stdout);	

 

			if(tc_strcmp(status,"1"))
			 {
			     tc_strcpy(status1,"Active");
			 }
			 else if(tc_strcmp(status,"0"))
             {
			     tc_strcpy(status1,"Inactive");
			 }


            //ITK_CALL(AOM_ask_value_string(UserTag1,"status",&status));
			
			//printf("\n User ID of user: %s \n",status);fflush(stdout); 
			ITK_CALL(AOM_UIF_ask_value(UserTag1,"fnd0LicenseServer",&fnd0LicenseServer));
			
			printf("\n User ID of user: %s \n",fnd0LicenseServer);fflush(stdout);

			//FirstName=tc_strtok(usernameTag," ");
			//MiddleName=tc_strtok(NULL," ");
           // LastName=tc_strtok(NULL," ");
	       // if (tc_strcmp(LastName,NULL)==0)
	       // {
            //     printf("Ihside Condition 123.........................");fflush(stdout);
             //    LastName=MiddleName;
			//	 MiddleName="";
	       // }
			//if((tc_strcmp(LastName,NULL)==0) && (tc_strcmp(MiddleName,"")==0) )
			// {
				 
			 //    LastName="";
			// }
          //  printf("\n User ID of user: %s \n",FirstName);fflush(stdout);
           // printf("\n User ID of user: %s \n",MiddleName);fflush(stdout);
          //  printf("\n User ID of user: %s \n",LastName);fflush(stdout);
		    //ITKCALL(AOM_ask_value_tags(UserTag,"license_level",&license_level,&lov));
            ITKCALL(AOM_UIF_ask_value(UserTag1,"license_level",&lov));	
            printf("\n license_level : %s \n",lov);fflush(stdout);
			lov1=atoi(lov);
			strcpy(lincese_level1,"");
			if (lov1==0)
			{
                tc_strcpy(lincese_level1,"Author");

			}
			else if (lov1==1)
			{
                tc_strcpy(lincese_level1,"Consumer");
			}
            else if (lov1==2)
			{
			    tc_strcpy(lincese_level1,"Occsaional User");
			}
			else if (lov1==3)
			{
                 tc_strcpy(lincese_level1,"Viewer");
			}
           else if (lov1==4)
			{
		          tc_strcpy(lincese_level1,"Viewer");
		    }
            else if (lov1==5)
			{
			    tc_strcpy(lincese_level1,"Admin");  
			}
            printf("\n license_level1 : %s \n",lincese_level1);fflush(stdout);

			ITK_CALL(AOM_ask_value_tag(UserTag1,"fnd0custom_user_profile",&valueTag));
            ITK_CALL(SA_ask_user_person(UserTag1,&persontag));

			ITK_CALL(SA_ask_person_email_address(persontag,&emailid));

			printf("\n Mail ID of user: %s \n",emailid);fflush(stdout);

//			ITK_CALL(GRM_find_relation_type("IMAN_based_on", &RelationType));

       

//		   ITK_CALL(ITEM_list_all_attachments(valueTag,RelationType,&count2,&Attachment));
           char *organization=NULL;
		   char *costcentername=NULL;
		   char *dupcostcentername=NULL;
		   char *costcenterno=NULL;
		   char *dupcostcenterno=NULL;
		   char *engagmenttype=NULL;
		   char *dupengagmenttype=NULL;


			if(valueTag !=NULLTAG)

			 {

			 printf("\n Value Tag Found Sucessfully ..!!!!!!\n");fflush(stdout);
			
			ITK_CALL(AOM_ask_value_string(valueTag,"t5_department",&deparmentTag));	
			printf("\n Value of department : %s \n",deparmentTag);fflush(stdout);
			remove_encoding_chars(deparmentTag);
			ITK_CALL(AOM_ask_value_string(valueTag,"t5_bu",&bu));			
			printf("\n Value of BU : %s \n",bu);fflush(stdout);
			remove_encoding_chars(bu);
			ITK_CALL(AOM_ask_value_string(valueTag,"t5_division",&division));			
			printf("\n Value of Division : %s \n",division);fflush(stdout);	
			remove_encoding_chars(division);
			ITK_CALL(AOM_ask_value_string(valueTag,"t5_useragency",&useragencyTag));			
			printf("\n Value of useragency: %s \n",useragencyTag);fflush(stdout);
			remove_encoding_chars(useragencyTag);
			ITK_CALL(AOM_ask_value_string(valueTag,"t5_userlocation",&userlocationTag));
		    printf("\n Value of userlocation: %s \n",userlocationTag);fflush(stdout);	
			remove_encoding_chars(userlocationTag);
			ITK_CALL(AOM_ask_value_string(valueTag,"t5_Organization",&organization)); 
			printf("\n Value of Organization : %s \n",organization);fflush(stdout); 
			remove_encoding_chars(organization);
			ITK_CALL(AOM_ask_value_string(valueTag,"t5_costcentername",&costcentername));
            ITK_CALL(STRNG_replace_str(costcentername,",","",&dupcostcentername));
			printf("\n Value of Cost Center Name : %s \n",dupcostcentername);fflush(stdout);
			remove_encoding_chars(dupcostcentername);
			ITK_CALL(AOM_ask_value_string(valueTag,"t5_costcenter1",&costcenterno));
            ITK_CALL(STRNG_replace_str(costcenterno,",","",&dupcostcenterno));
			printf("\n Value of Cost Center No : %s \n",dupcostcenterno);fflush(stdout);
			remove_encoding_chars(dupcostcenterno);
			ITK_CALL(AOM_ask_value_string(valueTag,"t5_UserType",&engagmenttype));
            ITK_CALL(STRNG_replace_str(engagmenttype,",","",&dupengagmenttype));
			printf("\n Value of Engagment type : %s \n",dupengagmenttype);fflush(stdout);
			remove_encoding_chars(dupengagmenttype);
			}
			else
			 {
                  organization="";
				  dupcostcentername="";
				  dupcostcenterno="";
				  dupengagmenttype="";
				  deparmentTag="";
				  bu="";
				  division="";
				  useragencyTag="";
				  userlocationTag="";




                  
			 } 
			
			//fprintf(fp,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s",useridTag,emailid,FirstName,MiddleName,LastName,lincese_level1,status1,fnd0LicenseServer,last_login_time);fflush(stdout);
			fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",UserName,useridTag,emailid,status1,lincese_level1,fnd0LicenseServer,organization,dupcostcentername,dupcostcenterno,dupengagmenttype,bu,deparmentTag,division,useragencyTag,userlocationTag);fflush(stdout); 
					
           
		 }
						// }
		//}
		//}
		//if(ftr)
	  //  {
		//   fclose(ftr);
		//	ftr=NULL;
	//	}
		if(fp)
		{
			fclose(fp);
			fp=NULL;
		}
		//sysUserId=subString(sSysUser,4,tc_strlen(sSysUser));
		printf("\n -sysUserId = %s ",sSysUser);
		ITK_CALL(SA_find_user2(sSysUser,&sysUserTag));
		if(sysUserTag!=NULLTAG)
		{
		   ITK_CALL(SA_ask_user_home_folder(sysUserTag,&sysHomeTag));
		   if(sysHomeTag!=NULLTAG)
						{
			   ITK_CALL(FL_ask_references(sysHomeTag,FL_fsc_as_ordered,&noOfReferences,&folderReference));
			   printf("\n -noOfReferences = %d",noOfReferences);
			   for(itr=0;itr<noOfReferences;itr++)
							{
								ITK_CALL(AOM_ask_value_string(folderReference[itr],"object_name",&fldObjName));
								ITK_CALL(AOM_ask_value_string(folderReference[itr],"object_type",&fldObjType));
								
								printf("\n -fldObjName = %s",fldObjName);
								printf("\n -fldObjType = %s",fldObjType);
								
								
								if(tc_strcmp(fldObjType,"Folder")==0 && tc_strcmp(fldObjName,"MIS User Details Reports") == 0)
								{
									fldFound=1;
									newFolderTag=folderReference[itr];
									break;
								}
				
							}
						
						printf("\n -fldFound = %d",fldFound);
						printf("\n- datasetIdValue     = %s\n",datasetIdValue );
						if(fldFound==1)
			            {
							printf("\n ************** Dataset Attachment started Folder available **************** ");
							ITK_CALL(AE_find_datasettype2("MSExcel",&datasetType));
							if(datasetType!=NULLTAG)
							{
                               ITK_CALL(AE_create_dataset_with_id(datasetType,datasetIdValue,datasetIdValue,datasetIdValue,"A",&datasetTag));
							   if(datasetTag!=NULLTAG)
									{
								     ITK_CALL(AE_import_named_ref(datasetTag,"excel",csvLog,datasetIdValue,SS_TEXT));
									 ITK_CALL(AOM_refresh(datasetTag,TRUE));
									 ITK_CALL(AOM_save_without_extensions(datasetTag));
									 ITK_CALL(FL_insert(newFolderTag,datasetTag,999));
									 ITK_CALL(AOM_save_without_extensions(newFolderTag));
								    }
									else
									{
										printf("\n Error : datasetTag == NULLTAG. Dataset not created.");
									}


							
							}
								else
								{
									printf("\n Error : datasetType not found.");
								}
						}
						else
			            {
                               printf("\n Folder Creation Started...........");
							   ITK_CALL(FL_create2("MIS User Details Reports","MIS User Details Reports",&newFolderTag));
							   if(newFolderTag!=NULLTAG);
							{
								ITK_CALL(AOM_save_without_extensions(newFolderTag));
								ITK_CALL(FL_insert(sysHomeTag,newFolderTag,000));
								ITK_CALL(AOM_save_without_extensions(sysHomeTag));
								ITK_CALL(AE_find_datasettype2("MSExcel",&datasetType));
								if(datasetType!=NULLTAG)
								    {
									  ITK_CALL(AE_create_dataset_with_id(datasetType,datasetIdValue,datasetIdValue,datasetIdValue,"A",&datasetTag));
									 if(datasetTag!=NULLTAG)
								    	{
                                         ITK_CALL(AE_import_named_ref(datasetTag,"excel",csvLog,datasetIdValue,SS_TEXT));
										 ITK_CALL(AOM_refresh(datasetTag,TRUE));
										 ITK_CALL(AOM_save_without_extensions(datasetTag));
										 ITK_CALL(FL_insert(newFolderTag,datasetTag,999));
										 ITK_CALL(AOM_save_without_extensions(newFolderTag));
										}
										else
										{
                                           printf("\n Error : datasetTag == NULLTAG. Dataset not created.");
										}

									}
									else
								{
									printf("\n Error : datasetType not found.");
								}
							}
						}
		        }

		}

		


  return 0;
}
