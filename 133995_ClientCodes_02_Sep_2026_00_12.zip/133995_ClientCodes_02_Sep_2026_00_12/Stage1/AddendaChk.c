#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define STRSIZE 200
#define NUMWORDS 11

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	
	//if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	//{
		//print_requirement();
		//return -1;
	//}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	//ifail = read_value_from_file(file);
	ifail = Addenda_Cre(file);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

/********************************************************************************************
    Function:       Addenda_Cre
    Description:    
********************************************************************************************/
int Addenda_Cre(char* Filename)
{
	int		count			=0;
	int		FlagA			=0;
    int		i, j,z			= 0;
    int		n_entriesObs	= 2;
    int		countDesign	= 0;
    int		resultCountObs	= 0;
    int		flag	= 0;
	tag_t item_type_tag				= NULLTAG;
	tag_t item_create_input_tag		= NULLTAG;
	tag_t cfg_item_create_input_tag = NULLTAG;
	tag_t object					= NULLTAG;
	tag_t cfg_object				= NULLTAG;
	tag_t cfg_item_type_tag			= NULLTAG;
	tag_t relation_type				= NULLTAG;
	tag_t new_relation				= NULLTAG;
	tag_t cc_item_tag				= NULLTAG;
	tag_t GeneralQryTag				= NULLTAG;
	tag_t	item_tag				= NULLTAG;
	tag_t	*Addenda				= NULLTAG;
	char* error_str					= NULL;
	char* Addenda_ID					= NULL;
	char* s = "^";
	char** design_grp = NULL;

	char *object_name = (char *) MEM_alloc( 100 * sizeof(char) );
	char *obj_item_id = (char *) MEM_alloc( 100 * sizeof(char) );
	char *project = (char *) MEM_alloc( 100 * sizeof(char) );
	char *projectcode = (char *) MEM_alloc( 100 * sizeof(char) );
	char *Addenda_desc = (char *) MEM_alloc( 100 * sizeof(char) );
	char *addPlant = (char *) MEM_alloc( 100 * sizeof(char) );	
	char *temp	=  (char *) MEM_alloc( 200 * sizeof(char) );;
	char *qry_entriesObs[2] = {"Description","Type"};
	char **qry_valuesObs = (char **) MEM_alloc(10 * sizeof(char *));

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));
			tc_strcpy(project,"");
			tc_strcpy(project,temp);

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				//project = strtok(temp, "^");
				//tc_strcpy(object_name,obj_item_id);
				printf("\nproject Checking:%s",project); fflush(stdout);
				if(QRY_find("General...", &GeneralQryTag));
				if (GeneralQryTag)
				{
					printf("\nGeneral... Found Query");	fflush(stdout);
					qry_valuesObs[0] =  project;
					qry_valuesObs[1] = "T5_DmlAddenda";
				
					if(QRY_execute(GeneralQryTag,n_entriesObs,qry_entriesObs,qry_valuesObs,&resultCountObs,&Addenda));
					printf("\n Found addenda resultCount :%d:\n", resultCountObs); fflush(stdout);
				
					if (resultCountObs > 0)
					{
						for (i=0;i<resultCountObs ;i++)
						{
							printf("\nChecking Addenda no [%d]",i+1);fflush(stdout);

							if(AOM_ask_value_strings(Addenda[i],"t5_crdesigngroup",&z, &design_grp));
							if(AOM_ask_value_string(Addenda[i],"current_name", &Addenda_ID));
							printf("\nAddednda Found is [%s]   and design group in addednda are [%d] \n",Addenda_ID ,resultCountObs); fflush(stdout);

							for(j=0;j<z; j++)
							{
								printf("\nFor addenda [%s] found design group is :%s:\n", design_grp[z]); fflush(stdout);
								if(tc_strcmp(design_grp[z], "02") == 0)
								{
									flag=1;
									printf("\nGiven Project Code [%s] is found in addenda [%s] of project code [%s]",design_grp[z],Addenda_ID,project);fflush(stdout);
								}	
							}
						}
					}
				}
			}
			if(flag ==0)
			{
				printf("Given design group is not available in any of addenda of project [%s]",project);
				return 1;
			}
		}
	}

	if(object_name != NULL)
		MEM_free(object_name);

	if(obj_item_id != NULL)
		MEM_free(obj_item_id);

	if(projectcode != NULL)
		MEM_free(projectcode);

	if(Addenda_desc != NULL)
		MEM_free(Addenda_desc);

	if(addPlant != NULL)
		MEM_free(addPlant);

	return ifail;
}
