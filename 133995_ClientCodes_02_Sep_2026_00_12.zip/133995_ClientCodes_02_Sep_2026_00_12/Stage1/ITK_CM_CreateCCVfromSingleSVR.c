#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ae/datasettype.h>
#include <ai/sample_err.h>
#include <cfm/cfm.h>
#include <bom/bom.h>
//#include <pom/pom/enq.h>

#include <epm/epm.h>

#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>

#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <property/prop.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>

#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <tccore/project.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/epm_toolkit_utils.h>

#define ITK_err 919002
///#define PLM_error 919018
#define ITK_errErr1 (EMH_USER_error_base + 4)
#define ITK_errErr (EMH_USER_error_base + 99)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define ERROR_CHECK(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define VOO_HASH_SIZE 4099
#define MAX_INT_LENGTH 10      //maximum no of characters required to hold an integer000
#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

char NoModuleStr[1900];

static int VOO_debug = FALSE;
static char *VOO_prog = (char *)"UnitBOM";

int ChkFrstLvlModuleDRstus(char* p_child_item_id, int DMLSTVALUT);

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
	}
	return return_code;
}
char *substring(char *string, int position, int length)
{
   char *pointer;
   int c;

   pointer = malloc(length+1);

   if (pointer == NULL)
   {
      printf("Unable to allocate memory.\n"); fflush(stdout);
      exit(1);
   }

   for (c = 0 ; c < length ; c++)
   {
      *(pointer+c) = *(string+position-1);
      string++;
   }

   *(pointer+c) = '\0';

   return pointer;
}
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2));
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2));
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3));
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3));
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;
}
int printObject(tag_t objtag)
{
	int prop_count=0;
	int num_values=0;
	int j=0,k=0;
	int ifail=ITK_ok;

	char *class_name=NULL;

	char** prop_names=NULL;
	char** values =NULL;

	tag_t class_tag=NULLTAG;

	logical propConstReqBool=false;

	printf("\n printObject()->");fflush(stdout);

	if(objtag==NULLTAG)
	{
		printf("\nNULLTAG");fflush(stdout);
		return ifail;
	}
	/* ITK_CALL(POM_class_of_instance( objtag, &class_tag ));
	ITK_CALL(POM_name_of_class(class_tag, &class_name) );
	*/
	char *type_name=NULL;
	tag_t type_tag = NULLTAG;
	ITK_CALL(TCTYPE_ask_object_type(objtag,&type_tag));

	ITK_CALL(TCTYPE_ask_name2(type_tag, &type_name));

	ITK_CALL(AOM_ask_sorted_prop_names(objtag,&prop_count,&prop_names))      ;
	printf("\nClass-Name:%s(Attr Count->%d)\n[",type_name,prop_count);fflush(stdout);
	// printf("\n printObject2 %d",prop_count);fflush(stdout);

	for (k=0;k<prop_count;k++)
	{
		ITK_CALL(AOM_ask_displayable_values(objtag,prop_names[k],&num_values,&values));

		tag_t prop_tag = NULLTAG;
		ITK_CALL(TCTYPE_ask_property_by_name(type_tag,prop_names[k],&prop_tag));
		printf("\n %s:{,[",prop_names[k]);fflush(stdout);

		propConstReqBool=false;
		char *prop_dispay_name=NULL;
		PROP_value_type_t valtype;
		char *valtypeName=NULL;

		ITK_CALL(PROPDESC_is_required(  prop_tag,  &propConstReqBool  ));
		printf("\n->REQ:  %d,",  propConstReqBool);fflush(stdout);

		ITK_CALL(PROPDESC_ask_display_name(prop_tag,&prop_dispay_name));
		printf("\n->Display Name:  %s,",  prop_dispay_name);fflush(stdout);

		ITK_CALL(PROPDESC_ask_value_type(  prop_tag,  &valtype,  &valtypeName));
		printf("\n->ValTypeName  %s,",  valtypeName);fflush(stdout);

		printf("\n]\n");fflush(stdout);

		for(j=0;j<num_values;j++)
		{
			printf("\n\t%s,",values[j]);fflush(stdout);
		}

		printf("\n },");fflush(stdout);
	}
	printf("\n]");fflush(stdout);

	printf("\n End of function printObject()......");fflush(stdout);

	return ifail;
}

int ChkVCfrmSVR(char *CVObjName)		//VC/TechSpec availability from SVR
{
	int tscount = 0;
	char *VCnm = NULL;
	char *seq = NULL;
	char *VRRev = NULL;
	char *VCname = NULL;
	VCnm =  (char *) MEM_alloc(10 * sizeof(char));
	seq =  (char *) MEM_alloc(10 * sizeof(char));
	VRRev =  (char *) MEM_alloc(10 * sizeof(char));
	char *VCRevG = NULL;
	int Child_Rev_count=0;
	tag_t VCtag = NULLTAG;
	tag_t VCTagLt = NULLTAG;
	tag_t relation_type_tag = NULLTAG;
	tag_t *Child_rev_list = NULLTAG;
	tag_t *techspec_objects = NULLTAG;

	tc_strtok(CVObjName, "_");
	VRRev = tc_strtok(NULL, "_");
	strncpy(VCnm,CVObjName,8);
	//VRRev=tc_strtok(NULL, ";");
	tc_strcat(VCnm,"R");
	printf( "\n ChkVCfrmSVR:VC Name created from SVR is %s & rev is %s",VCnm,VRRev); fflush(stdout);
	///////
	tag_t rev_tag = NULLTAG;
	tag_t Child_All_Rev = NULLTAG;
	tag_t objTypTag = NULLTAG;
	char*   ObjTyp= NULL;
	if(tc_strcmp(VRRev,"NR")!=0)
	{
		Child_All_Rev= t5GetItemRevison(VCnm);
		if(Child_All_Rev==NULLTAG)
		{
			printf("\n ChkVCfrmSVR:Child_All_Rev is NULL.\n");fflush(stdout);
		}
		else
		{
			if(ITEM_ask_latest_rev(Child_All_Rev, &rev_tag));

			if(TCTYPE_ask_object_type(rev_tag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n ChkVCfrmSVR: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
			
			if (rev_tag != NULLTAG)
			{
				if(AOM_UIF_ask_value(rev_tag,"item_revision_id",&VCRevG));
				printf( "\n ChkVCfrmSVR: VCRevG [%s]",VCRevG); fflush(stdout);
				seq=tc_strtok(VCRevG, ";");
				printf( "\n ChkVCfrmSVR:VCRevG Found and which is [%s] & seq is[%s]",VCRevG,seq); fflush(stdout);
			}
			else
			{	
				printf( "\n ChkVCfrmSVR:Latest VC Re Tag not found.[%s]",VCnm); fflush(stdout);
				EMH_clear_errors();
				//EMH_store_error_s1(EMH_severity_error,PLM_error,"Latest VC Revision not found for Creation, Kindly raise ticket in TMS");
				printf("\n Latest VC Revision not found for Creation, Kindly raise ticket in TMS\n");fflush(stdout);
				return 0;
			}
		}
		printf( "\n ChkVCfrmSVR:VC seq is [%s] & VRRev is [%s]",seq,VRRev); fflush(stdout);
		if (tc_strcmp(seq,VRRev)==0)
		{
			printf( "\n ChkVCfrmSVR:VC Revision is already present is system."); fflush(stdout);
			EMH_clear_errors();
			//EMH_store_error_s1(EMH_severity_error,PLM_error,"Run BOM process running multiple times, VC Revision is already present is system. Kindly raise ticket in TMS ");
			printf("\n ChkVCfrmSVR:Run BOM process running multiple times, VC Revision is already present is system\n");fflush(stdout);
			return 0;
		}
		else
		{
			printf("\n ChkVCfrmSVR: Sequese of [%s] is not found",VRRev);fflush(stdout);
			GRM_find_relation_type("T5_VCSpec", &relation_type_tag);
			GRM_list_secondary_objects_only(rev_tag,relation_type_tag,&tscount,&techspec_objects);
			if (tscount == 0)
			{
				printf( "\n ChkVCfrmSVR:Previous VC Revision is not having Tech Spec attached to it."); fflush(stdout);
				EMH_clear_errors();
				//EMH_store_error_s1(EMH_severity_error,PLM_error,"Latest Released VC Revision is not having Tech Spec attached to it. Kindly raise ticket in TMS ");
				printf("\n ChkVCfrmSVR::Latest Released VC Revision is not having Tech Spec attached to it.\n");fflush(stdout);
				return 0;
			}
		}
	}
	else
	{
		printf("\n SVR Rev is NR======> [%s]",VRRev);fflush(stdout);
		Child_All_Rev= t5GetItemRevison(VCnm);
		if(Child_All_Rev !=NULLTAG)
		{
			printf("\n ChkVCfrmSVR:Child_All_Rev is Not NULL of NR SVR. VC Revision is already present is system.\n");fflush(stdout);
			EMH_clear_errors();
			//EMH_store_error_s1(EMH_severity_error,PLM_error,"Run BOM process running multiple times, VC Revision is already present is system. Kindly raise ticket in TMS ");
			printf("\n ChkVCfrmSVR:Run BOM process running multiple times, VC Revision is already present is system\n");fflush(stdout);
			return 0;
		}
		else
		{
			printf("\nNeed not to check present VC in system, SVR Rev is NR======> [%s]",VRRev);fflush(stdout);
		}
	}
	return 0;
}

int TechSpecCreFun(char *projcode ,char *OwnerDesDept,char *OwnerDesUnit,char *VcClass,char *Desc,char *ProjClass,tag_t *RetTSItem)
{
	int ifail = ITK_ok;
	tag_t createInputTag = NULLTAG;
	tag_t createRevInputTag = NULLTAG;
	tag_t type = NULLTAG;
	tag_t revtype = NULLTAG;
	tag_t item = NULLTAG;
	const char *select_attrs[]={"item_id"};
	int n_rows;
	int n_cols;
	int row;
	int column;
	void ***report;
	char vals[30];
	char FinalItemId[15];

	printf("\nInside TechSpecCreFun*******"); fflush(stdout);

	char *basepart=(char *) MEM_alloc(10 * sizeof(char *));

	printf("\n Input Parameters projcode=%s OwnerDesDept=%s OwnerDesUnit=%s VcClass=%s Desc=%s ProjClass=%s",projcode,OwnerDesDept,OwnerDesUnit,VcClass,Desc,ProjClass);
	fflush(stdout);

	tc_strcpy(FinalItemId,"2590");
	tc_strcat(FinalItemId,projcode);
	tc_strcpy(basepart,"2590");
	tc_strcat(basepart,projcode);
	tc_strcat(FinalItemId,"*");
	printf("\n FinalItemId=%s",FinalItemId); fflush(stdout);


	const char *str_list[15]={FinalItemId};
	printf("\nstr_list[0]=%s",str_list[0]); fflush(stdout);
	//Create Start

	printf("\nB4 query Build FinalItemId=%s",FinalItemId); fflush(stdout);
	ERROR_CHECK(POM_enquiry_create ("find_TechSpec_by_type"));
	ERROR_CHECK(POM_enquiry_add_select_attrs ("find_TechSpec_by_type","T5_TSComp", 1, select_attrs));
	ERROR_CHECK(POM_enquiry_set_string_value ("find_TechSpec_by_type","attrval",1,str_list,POM_enquiry_bind_value));
	ERROR_CHECK(POM_enquiry_set_attr_expr ("find_TechSpec_by_type","expr1", "T5_TSComp","item_id",POM_enquiry_like, "attrval"));
	ERROR_CHECK(POM_enquiry_set_where_expr ("find_TechSpec_by_type","expr1"));
	ERROR_CHECK(POM_enquiry_add_order_attr( "find_TechSpec_by_type", "T5_TSComp", "item_id", POM_enquiry_desc_order ));
	ERROR_CHECK(POM_enquiry_execute("find_TechSpec_by_type", &n_rows, &n_cols, &report));
	ERROR_CHECK(POM_enquiry_delete("find_TechSpec_by_type"));

	printf("\nB4 cal FinalItemId=%s row=%d col=%d report=%s",FinalItemId,n_rows,n_cols,report); fflush(stdout);
	for (row = 0; row < n_rows; row++)
	{
		for (column = 0; column < n_cols; column++)
			printf("\n Query return=%s\t", report[row][column]); fflush(stdout);
	}
	printf("\n Row =%d Column =%d\t", n_rows,n_cols); fflush(stdout);
	if(n_rows==0 )
	{
		printf("\nInside start Base part=%s",basepart); fflush(stdout);
		strcat(basepart,"0001");
	}
	else
	{
		printf("\nInside Base part increment condition=%s ",basepart); fflush(stdout);
		char *tmpStr=report[0][0];
		printf("\ntmpStr=%s",tmpStr); fflush(stdout);
		//char *str=substring(tmpStr,9,tc_strlen(tmpStr));
		int last4dig=atoi(substring(tmpStr,9,tc_strlen(tmpStr)));
		last4dig=last4dig+1;
		printf("\n str=%d",last4dig); fflush(stdout);
		sprintf(vals,"%.4d",last4dig);
		printf("\nInside vals=%s",vals); fflush(stdout);
		strcat(basepart,vals);
	}

	printf("\nto be create part=%s",basepart); fflush(stdout);
	//create End

	ERROR_CHECK(TCTYPE_find_type ("T5_TSComp", NULL, &type ));
	ERROR_CHECK(TCTYPE_find_type ("T5_TSCompRevision", NULL, &revtype ));
	ERROR_CHECK(TCTYPE_construct_create_input ( type , &createInputTag));
	ERROR_CHECK(TCTYPE_construct_create_input ( revtype , &createRevInputTag));
	printf("\n TechSpecCreFun1*******"); fflush(stdout);
	// ERROR_CHECK( AOM_set_value_string(createRevInputTag, "t5projectname", projcode));

	ERROR_CHECK( AOM_set_value_string(createRevInputTag, "object_desc", Desc));
	ERROR_CHECK( AOM_set_value_string(createRevInputTag, "t5_DsgnDeptCpy", OwnerDesDept));
	ERROR_CHECK( AOM_set_value_string(createRevInputTag, "t5_DsgnOwnCpy", OwnerDesUnit));
	ERROR_CHECK( AOM_set_value_string(createRevInputTag, "item_revision_id", "A"));
	ERROR_CHECK( AOM_set_value_string(createRevInputTag, "t5_VCSubClass", VcClass));
	ERROR_CHECK( AOM_set_value_string(createRevInputTag, "t5_VCClassName", ProjClass));

	printf("\n TechSpecCreFun2*******"); fflush(stdout);

	ERROR_CHECK( AOM_set_value_string(createInputTag, "item_id", basepart));
	ERROR_CHECK( AOM_set_value_string(createInputTag, "object_name", Desc));
	ERROR_CHECK(AOM_set_value_tag(createInputTag, "revision",createRevInputTag));
	ERROR_CHECK(TCTYPE_create_object(createInputTag, &item));
	printf("\n TechSpecCreFun5*******"); fflush(stdout);
	ERROR_CHECK( AOM_save_with_extensions(item));
	printf("\n Tech Spec [%s] Created Successfully*******",basepart); fflush(stdout);

	if(item!=NULLTAG)
	{
		*RetTSItem=item;
	}

	printf("\n End of TechSpecCreFun ........\n");fflush(stdout);

	return 	ifail;
}

static int PrintErrorStack2( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );

    fprintf(stderr, "Reivse Error(s): \n"); fflush(stderr);
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]); fflush(stderr);
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]); fflush(stderr);
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

typedef struct
{
    int     size;
    int     capacity;
    int     increment;
    void  **content;
} vector_t;

struct modstruct
 {
	   //part details

		char parent_part[100];
		int child;

 } childstr[10000];

typedef vector_t *variant_rule_option_data_t[VOO_HASH_SIZE];

static int VOO_show_wso
    ( tag_t       wso                         /* <I> */
    );

	static char *VOO_time_stamp
    ();

static int VOO_list_saved_variant_rules
    ( tag_t       itemRev,                    /* <I> */
      int *       nVRules,                    /* <O> */
      tag_t **    vRules                      /* <OF> */
    );
static logical VOO_option_value_hash
    ( int         hash_size,                  /* <I> */
      vector_t *  hash[],                     /* <I> */
      tag_t       option_rev,                 /* <I> */
      int         option_rev_value_index,     /* <I> */
      int         add_if_new                  /* <I> */
    );
static int VOO_variant_expression
    ( tag_t        v1,                        /* <I> */
      int          op,                        /* <I> */
      tag_t        v2,                        /* <I> */
      const char * text,                      /* <I> */
      tag_t      * ve,                        /* <O> */
      logical    * was_new                    /* <O> */
    );
static int VOO_expression_hash
    ( int          hash_size,                 /* <I> */
      vector_t   * hash[],                    /* <I> */
      tag_t        val1,                      /* <I> */
      int          oper,                      /* <I> */
      tag_t        val2,                      /* <I> */
      const char * text,                      /* <I> */
      logical      add_if_new,                /* <I> */
      tag_t      * var_exp,                   /* <O> */
      logical    * was_new                    /* <O> */
    );

static char *VOO_time_stamp()
{
    time_t now;
    static char time_stamp[512];

    time( &now );
    sprintf( time_stamp, "%s", ctime( &now ) );
    time_stamp[tc_strlen(time_stamp)-1] = '\0'; /* strip off new line */
    return time_stamp;
}
static void handle_itk_error
    ( int stat,                           /* <I> */
      int source_code_line,               /* <I> */
      const char *source_code_file_name   /* <I> */
    )
{
    if ( VOO_debug )
    {
        int          n_ifails=0;
        const int   *severities=NULL;
        const int   *ifails=NULL;
        const char **texts=NULL;
        char        *errstring=NULL;

        fprintf( stderr, "Error detected\n" );
        fflush( stderr);
        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
        if ( n_ifails && texts != NULL )
        {
            if ( ifails[n_ifails-1] == stat )
            {
                fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (texts[n_ifails-1]==NULL?"null":texts[n_ifails-1]) );
            }
            else
            {
                EMH_ask_error_text( stat, &errstring );
                fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (errstring==NULL?"null":errstring) );
                MEM_free( errstring );
            }
        }
        else
        {
            EMH_ask_error_text( stat, &errstring );
            fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (errstring==NULL?"null":errstring) );
            MEM_free( errstring );
        }
        fprintf( stderr, "%s %s: Error: Line %d in %s\n", VOO_prog, VOO_time_stamp(), source_code_line, source_code_file_name );
    }
}
int UpdateAllowForm(tag_t  itemRev,char* Toupd)
{
	tag_t  *attachments = NULLTAG;
	tag_t  relation_type   = NULLTAG;
	tag_t  user_tag = NULLTAG;
	tag_t  dataset		= NULLTAG;
	char   *ObjectClassType		= NULL;
	char   *gov_class = NULL;
	char   *itemId = NULL;
	int    stat     = ITK_ok;
	int    n_found     = 0;
		  tag_t boTag= NULLTAG;
   	  tag_t creInputTag_r= NULLTAG;
 	  tag_t boTypeTag= NULLTAG;
 	  tag_t  relation_type1   = NULLTAG;
 	  tag_t  tRelationExist  = NULLTAG;
 	  tag_t  Rel_task        = NULLTAG;
	  int status;
 	 char *s;
	int    cnt      = 0;
	int    ij       = 0;
	int    ifail	= 0;

			TCTYPE_find_type("T5_UpdForm", NULL, &boTypeTag);

			if (AOM_ask_value_string(itemRev,"object_name",&itemId)!=ITK_ok);

			TCTYPE_construct_create_input (boTypeTag, &creInputTag_r);
			if(creInputTag_r != NULLTAG)
					printf("\nInput Tag Created for item id. \n", n_found);fflush(stdout);
			boTypeTag = NULLTAG;

			if(AOM_set_value_string(creInputTag_r, "object_name", itemId));
			if(AOM_set_value_string(creInputTag_r, "t5_IsUpdAllowed", "N"));

			 status = TCTYPE_create_object (creInputTag_r, &boTag) ;
			if(status != ITK_ok)
			{
					EMH_ask_error_text( status, &s);
					printf("\n*** Error with ITK_init_module: %s ***\n",s);fflush(stdout);
					MEM_free(s);
					return status;
			}

			creInputTag_r = NULLTAG;
			if(boTag != NULLTAG) printf("\n Update form created. \n");fflush(stdout);
			if(AOM_save_without_extensions(boTag));
			if(AOM_unlock(boTag));




				if(GRM_find_relation_type("T5_PartHasUpdForm",&relation_type1));
				if(GRM_find_relation(itemRev,boTag,relation_type1,&tRelationExist));
					if (tRelationExist==NULLTAG)
					   {
							   //###  Creating Relation between DML and Task  ###

							   printf("\n Now Creating Relation Between Design Revision and Update Form \n");fflush(stdout);
							   if(GRM_create_relation(itemRev,boTag,relation_type1,NULLTAG,&Rel_task));
							   if(GRM_save_relation  (Rel_task));
							   printf("\nRelation Created Successfully\n");fflush(stdout);
					   }



	if(GRM_list_secondary_objects_only(itemRev,relation_type,&cnt,&attachments));
				printf("\n Attached Datasets2: %d\n",cnt);fflush(stdout);
				printf("Update form value  [%s]\n",Toupd); fflush(stdout);

				for(ij=0;ij<cnt;ij++)
				{
						dataset = attachments[ij];
						if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok)
						printf("\n\n Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

						if (strcmp(ObjectClassType,"T5_UpdForm")==0)
						{
							if( AOM_set_value_string(dataset,"t5_IsUpdAllowed",Toupd));
							if(AOM_save_without_extensions(dataset));
							if(AOM_unlock(dataset));

							if( AOM_ask_value_string(dataset,"t5_IsUpdAllowed",&gov_class));
							printf("\n\n Update for value updated to:%s\n",gov_class);fflush(stdout);

						}
				}
	return ITK_ok;
}
static int VOO_show_wso ( tag_t wso ) {
    int                  stat=ITK_ok;
    tag_t                instance_class=NULLTAG;
    static tag_t         wso_class=NULLTAG;
    static tag_t         ve_class=NULLTAG;
    static int           not_initialized=TRUE;
    logical              is_wso=FALSE;

    // fprintf( stderr, "inside function VOO_show_wso");

	if ( not_initialized ) {
        ITK ( POM_class_id_of_class ( "WorkspaceObject", &wso_class ) );
        ITK ( POM_class_id_of_class ( "VariantExpression", &ve_class ) );
        not_initialized = FALSE;
    }

    if ( NULLTAG == wso ) {
        fprintf( stderr, "VOO_show_wso: Can't show info for a NULLTAG\n" );
        return stat;
    }

    ITK ( POM_class_of_instance ( wso, &instance_class ) );
    ITK ( POM_is_descendant ( wso_class, instance_class, &is_wso ) );
    if ( ! is_wso ) {
        logical is_ve=FALSE;

        ITK ( POM_is_descendant ( ve_class, instance_class, &is_ve ) );
        if ( is_wso ) {
            char *t=NULL;

            ITK ( BOM_variant_expression_as_text( wso, &t ) );
            fprintf( stderr, "%s %s: VariantExpression: %s: ", VOO_prog, VOO_time_stamp(), (NULL==t?"null":t) );
            MEM_free( t );
        }
        else
        {
            char    *class_name=NULL;

            ITK ( POM_name_of_class ( instance_class, &class_name ) );
            fprintf( stderr, "%s", (NULL==class_name?"null":class_name) );
        }
    }
    else
    {
        char              *obj_id=NULL;
        WSO_description_t  wso_desc;

        ITK ( WSOM_describe ( wso, &wso_desc ) );
        ITK ( WSOM_ask_object_id_string ( wso, &obj_id ) );
        if ( stat == ITK_ok ) {
            fprintf( stderr, "obj_id=%s", (NULL==obj_id?"null":obj_id) );
            MEM_free( obj_id );
/*            fprintf( stderr, ", name=%s", wso_desc.object_name );                             */
/*            fprintf( stderr, ", description=%s", wso_desc.description );                      */
            fprintf( stderr, ", type=%s", wso_desc.object_type );

        }
    }
    fprintf( stderr, "\n" );
    return stat;
}




int ChkFrstLvlModuleDRstus(char* p_child_item_id, int DMLSTVALUT)
{
	int cr =0;
	int crr =0;
	int DROKFlag =0;
	int n_tags_found2 =0;
	int PRTSTVALU =0;
	int Child_Rev_count =0;
	int Chld_Rel_Stus_Cunt =0;
	tag_t	Child_All_Rev		= NULLTAG;
	tag_t*	Child_rev_list		= NULLTAG;
	tag_t*	Child_status_lst	= NULLTAG;
	tag_t*	tags_found2	= NULLTAG;
	char* Chld_Rel_Stus = NULL;
	char* Child_Prt_DR = NULL;
	char* Child_rev_idd = NULL;
	char* PRTDRStr = NULL;

	//GETTING RELEASED REVISION

	//char **attrs2 = (char **) MEM_alloc(2 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(2 * sizeof(char *));
	const char *attrs2[2];
	const char *values2[2];

	printf("\n DR:p_child_item_id: %s   DMLSTVALUT: %d  ", p_child_item_id,DMLSTVALUT);fflush(stdout);

	/*
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)p_child_item_id;
	values2[1] = "Design";
	if ( ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2));
	MEM_free(attrs2);
	MEM_free(values2);
	*/

	if(ITEM_find_item (p_child_item_id, &Child_All_Rev));

	printf("\n DR-check Module: [%s]  n_tags_found2: %d", p_child_item_id,n_tags_found2);fflush(stdout);

	//if (n_tags_found2 == 1)
	//{
		// Child_All_Rev=tags_found2[0];

	if (Child_All_Rev != NULLTAG)
	{
		if(ITEM_list_all_revs (Child_All_Rev, &Child_Rev_count, &Child_rev_list));
		printf("\n DR:Total Child rev found: %d, DMLSTVALUT:%d ", Child_Rev_count,DMLSTVALUT);fflush(stdout);

		if(Child_Rev_count > 0)
		{
			cr=0;
			DROKFlag=0;
			for(cr=Child_Rev_count-1;cr>=0;cr--)
			{
				Chld_Rel_Stus_Cunt=0;
				DROKFlag=0;
				Child_rev_idd=NULL;
				if(AOM_UIF_ask_value (Child_rev_list[cr], "item_revision_id", &Child_rev_idd));
				printf("\n DR:Latest released rev is:%s.", Child_rev_idd);fflush(stdout);

				if(WSOM_ask_release_status_list (Child_rev_list[cr], &Chld_Rel_Stus_Cunt, &Child_status_lst));
				printf("\n DR:Chld_Rel_Stus_Cunt is:%d.", Chld_Rel_Stus_Cunt);fflush(stdout);
				if(Chld_Rel_Stus_Cunt > 0)
				{
					crr=0;
					for(crr=0;crr<Chld_Rel_Stus_Cunt;crr++)
					{
						DROKFlag=0;
						if(AOM_ask_value_string (Child_status_lst[crr], "object_name", &Chld_Rel_Stus));
						printf("\n DR: Chld_Rel_Stus:%s", Chld_Rel_Stus);fflush(stdout);
						if((tc_strstr(Chld_Rel_Stus,"Released")!=NULL)||(tc_strstr(Chld_Rel_Stus,"Rlzd")!=NULL)||(tc_strstr(Chld_Rel_Stus,"ERC Released")!=NULL) ||(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL))
						{
							DROKFlag=0;
							Child_Prt_DR=NULL;
							if(AOM_ask_value_string(Child_rev_list[cr],"t5_PartStatus",&Child_Prt_DR));
							printf("\n DR:RelStatus:%s  Child_rev_idd:%s DR Status:%s\n", Chld_Rel_Stus, Child_rev_idd,Child_Prt_DR);fflush(stdout);
							PRTDRStr=NULL;
							PRTSTVALU=0;
							PRTDRStr=subString(Child_Prt_DR, 2, 1);
							printf("\n DR:A:PRTDRStr: %s and ",PRTDRStr);fflush(stdout);
							PRTSTVALU=atoi(PRTDRStr);
							printf(":PRTSTVALU: %d",PRTSTVALU);fflush(stdout);
							if (PRTSTVALU >= DMLSTVALUT)
							{
								DROKFlag=1;
								break;
							}
						}
					}
					if (DROKFlag >0)
					{
						break;
					}
				}
			}
			printf("\n DR:DROKFlag: %d",DROKFlag);fflush(stdout);
			if (DROKFlag >0)
			{
				printf("\n DR:Released revison having valid DR-status.:%s ", p_child_item_id);fflush(stdout);
				return 1;
			}
			else
			{
				return 0;
			}
		}
	}

	return 0;
}
void getCurrentDateTimee(char cCurrentAccessDate[20])
{
	int ch=0;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];

	printf("\n getCurrentDateTime calling..........\n");

	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);

	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%b_%Y_%H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
void autoresizestrAdd(char **src,char* dest)
{
	char * desc = dest ? dest : "NA";
	//printf("\n autoresizestrAdd desc len==%d",strlen(desc));
	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
	tc_strcat(*src , desc);
}
void trimTrailing(char * str)
{
    int index=0, i=0;

    /* Set default index */
    index = -1;

    /* Find last index of non-white space character */
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }

        i++;
    }

    /* Mark next character to last non-white space character as NULL */
    str[index + 1] = '\0';
}
void trimLeading(char * str)
{
    int index=0, i=0, j=0;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }
    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}

int AssignProject_VC(tag_t  itemRev,char* projectcode)
{
	tag_t projobj=NULLTAG;
	char* username=NULL;
	tag_t user_tag=NULLTAG;
	int stat = ITK_ok;
	int ifail = 0;

	ITK_CALL(AOM_lock(itemRev));
	printf("\n P0:Projectcode==>[%s] ",projectcode); fflush(stdout);
	CALLAPI(PROJ_find(projectcode,&projobj));
	printf("\n P1: Assigned to Project\n");fflush(stdout);

	if(projobj !=NULLTAG)
	{
		//POM_get_user(&username,&user_tag);
		//ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		printf("\n P2:Before Project Assigning... \n");fflush(stdout);
		CALLAPI(PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
		printf("\n P3:After Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n Project not found\n");fflush(stdout);
	}
	
	ITK_CALL(AOM_save_without_extensions(itemRev));
	ITK_CALL(AOM_unlock(itemRev));
	printf("\n P4:save to Project...\n");fflush(stdout);
	return ITK_ok;
}

int AssignProject_vc_rel(tag_t  itemRev,char* projectcode)
{
	tag_t  projobj=NULLTAG;
	tag_t user_tag=NULLTAG;
	char* username=NULL;
	int stat = ITK_ok;
	int ifail = 0;

	//ITK_CALL(AOM_lock(itemRev));
	printf("\n AssignProject_vc_rel--Projectcode [%s]\n",projectcode); fflush(stdout);
	CALLAPI(PROJ_find(projectcode,&projobj));
	printf("\n AssignProject_vc_rel : Assigned to Project\n");fflush(stdout);

	if(projobj !=NULLTAG)
	{
		//POM_get_user(&username,&user_tag);
		//ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		printf("\n AssignProject_vc_rel : In not NULL tag\n");fflush(stdout);
		CALLAPI(PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
		printf("\n AssignProject_vc_rel--Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n AssignProject_vc_rel--Project not found\n");fflush(stdout);
	}
	//ITK_CALL(AOM_save_without_extensions(itemRev));
	//ITK_CALL(AOM_unlock(itemRev));

	return ITK_ok;
}
/*This will attach/replace the report to the reference items*/
int FindOrCreateDatasetAndAttachInWF(tag_t ERCDmlName,char *datasetName, char *datasetLocation)
{
	//int	status = ITK_ok;
	//int ifail=0;
	tag_t msWordType=NULLTAG;
	tag_t wordDataset=NULLTAG;
	tag_t wordLatestDat_t=NULLTAG;
	tag_t dml_Ref_Rel = NULLTAG;
	tag_t dml_Ref_Rel_t = NULLTAG;

	printf("\n\n Inside FindOrCreateDatasetAndAttachInWF  got datasetName:[%s], datasetLocation[%s] ",datasetName,datasetLocation);fflush(stdout);

	//if(access(datasetLocation,F_OK)!=-1)
	//{
		printf("\n [%s] access ok\n",datasetLocation);fflush(stdout);
		ITK_CALL(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel));
		printf("\n IMAN_reference found\n");fflush(stdout);
		TC_write_syslog("datasetfile accessed\n");
		ITK_CALL(AE_find_datasettype2("MSExcelX",&msWordType));//MSExcelx
		printf("\n datasetType Fetched\n");fflush(stdout);
		if(msWordType == NULLTAG)
		{
				printf("\n datasetType refrences not found\n");fflush(stdout);
				TC_write_syslog("Could not find Dataset Type Text. Please check data model\n");
				//continue;
		}
		else
		{
			printf("\n datasetType refrences found\n");fflush(stdout);
			int datasetExistsFlag = 0;
			tag_t * DatasetObj = NULL;
			int datasetCount = 0;
			char *ERCDmlDatasetName = NULL;
			//Expand the task to check if dataset is already present
			ITK_CALL(GRM_list_secondary_objects_only(ERCDmlName,dml_Ref_Rel,&datasetCount,&DatasetObj));
			if(datasetCount>0)
			{
				int k = 0;
				for(k=0;k<datasetCount;k++)
				{
					/*Check if Dataset already present or not*/
					ITK_CALL(AOM_ask_value_string(DatasetObj[k],"object_name",&ERCDmlDatasetName));
					printf("\n ERCDmlDatasetName[%s] \n",ERCDmlDatasetName);fflush(stdout);
					if(strcmp(ERCDmlDatasetName,datasetName)==0)
					{
						datasetExistsFlag=1;
						wordDataset = DatasetObj[k];
						printf("\n ERCDmlDatasetName[%s] already exists\n",ERCDmlDatasetName);fflush(stdout);
						break;
					}
				}
			}
			//End Expand the task to check if dataset is already present
			if(wordDataset==NULLTAG)
			{
				ITK_CALL(AE_create_dataset_with_id(msWordType,datasetName,"","","",&wordDataset));
				printf("\n Dataset[%s] Created\n",datasetName);fflush(stdout);
				ITK_CALL(AE_save_myself(wordDataset));
				printf("\n DataSet Saved\n");fflush(stdout);
				ITK_CALL(GRM_create_relation(ERCDmlName,wordDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t));
				printf("\n Relation Between DML and dataset created\n");fflush(stdout);
				ITK_CALL(AOM_load(dml_Ref_Rel_t));
				printf("\n Relation loaded\n");fflush(stdout);
				ITK_CALL(GRM_save_relation(dml_Ref_Rel_t));
				printf("\n Relation of DML and dataset saved\n");fflush(stdout);
			}
			//	ITK_CALL(AE_find_dataset2(datasetName,&wordLatestDat_t));
			ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
			printf("\n Fetched already existing dataset\n");fflush(stdout);
			ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
			printf("\n Refreshing Dataset\n");fflush(stdout);
			ITK_CALL(AOM_lock(wordDataset));
			if(datasetExistsFlag==1)
			{
				ITK_CALL(AE_remove_dataset_named_ref2(wordLatestDat_t,"excel"));
				printf("\n Refrence Removed\n");fflush(stdout);
			}

			/*
			//only refreshing of the object
			ITK_CALL(AE_import_named_ref(wordLatestDat_t,"excel",datasetLocation,NULL,SS_BINARY));
			//if(AE_import_named_ref(wordLatestDat_t,"Text",FileDown,NULL,SS_TEXT)!=ITK_ok);
			printf("\n File Updated\n");fflush(stdout);
			ITK_CALL(AE_save_myself(wordLatestDat_t));
			printf("\n Saved all things\n");fflush(stdout);
			ITK_CALL(AOM_unlock(wordDataset));
			remove(datasetLocation);
			printf("\n File removed\n");fflush(stdout);*/
			//Modification for TC12 Upgradation
			int ref_count;
			char **ref_list;
			tag_t filetag   = NULLTAG;
			IMF_file_t fileDescriptor;

			ITK_CALL(AE_ask_datasettype_refs(msWordType, &ref_count, &ref_list));
			ITK_CALL(IMF_import_file(datasetLocation,NULL, SS_BINARY, &filetag, &fileDescriptor));

			printf("\nFile Imported--->");fflush(stdout);
			ITK_CALL(AOM_save_without_extensions(filetag));
			printf("\nFile saved--->");fflush(stdout);

			ITK_CALL(AE_add_dataset_named_ref2(wordLatestDat_t,ref_list[0],AE_PART_OF ,filetag));
			printf("\n DatesetName44\n");fflush(stdout);
			ITK_CALL(AOM_save_without_extensions(wordLatestDat_t));
			printf("\n DatesetName55 \n");fflush(stdout);
			//END Modification for TC12 Upgradation
			// if(docFile) MEM_free(docFile);
		}
	//}
	//else
	//{
		//printf("\n Dataset location not presewnt[%s]" , datasetLocation);fflush(stdout);
	//}

	return ITK_ok;
}
int AttachSVRCompReportInWF(tag_t *ErcObj)
{
	char *DMLID = NULL;
	char *DMLRelType = NULL;
	char *DMLTaskID = NULL;
	char *object_type = NULL;
	char *partNumber = NULL;
	char *partType = NULL;
	char *inputForReport = NULL;

	tag_t relation_type = NULLTAG;
	tag_t Reference_relation_type = NULLTAG;
	tag_t *brkDwnObj = NULLTAG;
	tag_t *ReferenceObj = NULLTAG;

	int relCount= 0;
	int relCountRef= 0;
	int i=0;

	inputForReport = (char *) MEM_alloc( 1000 * sizeof(char) );
    tc_strcpy(inputForReport,"");
	printf("\n\n\n Inside AttachSVRCompReportInWF \n");fflush(stdout);
	ITK_CALL(AOM_ask_value_string(ErcObj[0],"item_id",&DMLID));
	printf("\n\nDML Number found [%s] \n",DMLID);fflush(stdout);
	ITK_CALL(AOM_ask_value_string(ErcObj[0],"t5_rlstype",&DMLRelType));
	printf("\n DML Release type[%s] \n",DMLRelType);fflush(stdout);
	ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
	ITK_CALL(GRM_list_secondary_objects_only(ErcObj[0],relation_type,&relCount,&brkDwnObj));
	printf("\n\n Total Number Of ERC TASKS Found ==[%d] \n",relCount);fflush(stdout);

	for(i=0;i<relCount;i++)
	{
		ITK_CALL(AOM_ask_value_string(brkDwnObj[i],"item_id",&DMLTaskID));
		printf("\n\n DML Task found [%s] \n",DMLTaskID);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(brkDwnObj[i],"object_type",&object_type));
		printf("\n\n object_type found [%s] \n",object_type);fflush(stdout);
		if(tc_strcmp(object_type,"T5_ChangeTaskRevision") == 0)
		{
			ITK_CALL(GRM_find_relation_type("CMReferences",&Reference_relation_type));
			ITK_CALL(GRM_list_secondary_objects_only(brkDwnObj[i],Reference_relation_type,&relCountRef,&ReferenceObj));
			printf("\n\n Total Number Of References Found ==[%d] \n",relCountRef);fflush(stdout);
			if(relCountRef>0)
			{
				int j=0;
				tag_t query = NULLTAG;
				int noOfCoObjects = 0;
				tag_t *Coobjects = NULLTAG;
				char *information1=NULL;
				char *tempbom = NULL;
				char *tempSVR = NULL;
				char temp[500] ;
				char *fileName = NULL;
				tempSVR = (char *) MEM_alloc( 1 * sizeof(char) );
				fileName = (char *) MEM_alloc( 1 * sizeof(char) );
				tempbom = (char *) MEM_alloc( 1 * sizeof(char) );
				tc_strcpy(tempSVR,"");
				tc_strcpy(fileName,"");
				tc_strcpy(tempbom,"");
				FILE* dmlFile =NULL;
				logical deleteIndicator = true;
				printf("\n\n\n Inside relCountRef>0 \n");fflush(stdout);
				char *qry_entries[]	 = { "SYSCD","SUBSYSCD"},*qry_values[]  = {"WFSVR","SVR-SVRCOMPARE"};

				ITK_CALL(QRY_find2("Control Objects...", &query));
				printf("\n query found");fflush(stdout);
				ITK_CALL(QRY_execute(query,2, qry_entries, qry_values, &noOfCoObjects, &Coobjects));
				printf("\n query executed");fflush(stdout);
				printf("\n\n Total Number Of Coobjects Found ==[%d] \n",noOfCoObjects);fflush(stdout);

				if(noOfCoObjects>0)
				{
					ITK_CALL(AOM_ask_value_logical(Coobjects[0],"t5_DelInd",&deleteIndicator));
					printf("\n deleteIndicator :[%d]\n",deleteIndicator);fflush(stdout);
				}

				if(deleteIndicator==false)
				{
					char OneRowData[500];
					ITK_CALL(AOM_ask_value_string(Coobjects[0],"t5_Userinfo1",&information1));
					printf("\n\n information1 : [%s] \n",information1);fflush(stdout);
					 tc_strcat(inputForReport,information1);
					 tc_strcat(inputForReport," ");
					 int isFirst=0;
					 for(j=0;j<relCountRef;j++)
					{
						ITK_CALL(AOM_ask_value_string(ReferenceObj[j],"object_type",&partType));
						if(strcmp(partType,"T5_PlatformRevision")==0)
						{
							ITK_CALL(AOM_ask_value_string(ReferenceObj[j],"item_id",&partNumber));
							autoresizestrAdd(&tempbom,partNumber);
							autoresizestrAdd(&tempbom," ");
						}
						if(strcmp(partType,"VariantRule")==0)
						{
							if(isFirst==0)
								isFirst=1;
							else
							autoresizestrAdd(&tempSVR,",");

							ITK_CALL(AOM_ask_value_string(ReferenceObj[j],"object_name",&partNumber));
							autoresizestrAdd(&tempSVR,partNumber);

						}
						printf("\n\n Part Number :[%s], Part Type :[%s] \n",partNumber,partType);fflush(stdout);
					}

					tc_strcat(inputForReport,tempbom);
					//strncpy(temp,tempSVR,strlen(tempSVR)-1);
					//temp[strlen(tempSVR)]='\0';
					//printf("\n temp = [%s]",temp);fflush(stdout);
					tc_strcat(inputForReport,tempSVR);
					tc_strcat(inputForReport," ");
					autoresizestrAdd(&fileName,"/tmp/");
					autoresizestrAdd(&fileName,DMLTaskID);
					autoresizestrAdd(&fileName,".txt");
					tc_strcat(inputForReport,fileName);
					printf("\n inputForReport=[%s]\n",inputForReport);fflush(stdout);
					//Place a system call
					system(inputForReport);

					//after system call is completed
					//Attach Report TO task
					//open dml.txt file from tmp folder
					dmlFile=fopen(fileName,"r");
					printf("\n fileName=[%s] opened\n",fileName);fflush(stdout);
					if(dmlFile == NULL) {
						printf("\n Error opening file");fflush(stdout);
						return(-1);
				    }
					while(fgets(OneRowData,500,dmlFile)!=NULL)
					{
						printf("\n OneRowData:[%s]",OneRowData);fflush(stdout);
						char * datasetName = NULL;
						char * datasetLocation = NULL;
						datasetName = strtok(OneRowData,":");
						datasetLocation = strtok(NULL,":");
						trimTrailing(datasetLocation);
						trimTrailing(datasetName);

						printf("\n datasetName:[%s], datasetLocation[%s] ",datasetName,datasetLocation);fflush(stdout);
						ITK_CALL(FindOrCreateDatasetAndAttachInWF(ErcObj[0],datasetName,datasetLocation));
						printf("\n FindOrCreateDatasetAndAttachInWF called successfully \n");fflush(stdout);
					}
				}
				else
				{
					printf("\n control object is not live \n");fflush(stdout);
				}
			}
			else
			{
				printf("\n\n No Reference Object Found \n");fflush(stdout);
			}
		}
		else
		{
			printf("\n\n not ERC TASK REVISION \n");fflush(stdout);
		}
	}
	return 0;
}
int tm_validateModuleAddress( tag_t DMLRevTag , tag_t top_line, int AltrozFlag)
{
	int ifail=0;
	int n_lines1=0 , p3=0, n_lines3=0;
	int ArchNodeQryC = 0 , ModuleAvailFlag=0, errorflag1=0 ;

	char *DMLNo=NULL;
	char *DMLDRstatus=NULL;
	char *DMLDRstatusStr=NULL;
	char *sModuleAdrr=NULL;
	char *Arch_item_id=NULL;
	char *Arch_item_idStr=NULL;
	char *strinfo1 =NULL;
	char *strinfo2 =NULL;
	char *strinfo3 =NULL;
	char *strinfo4 =NULL;
	char *strinfo6 =NULL;

	char *ArchQryEntry[2]  = {"SYSCD","SUBSYSCD"};
	char **ArchrNodeyEntryValue = (char **) MEM_alloc(50 * sizeof(char *));

	tag_t *ArchNodeLines = NULL;
	tag_t *moduleslines = NULL;
	tag_t *ArchNodeCtrObj = NULLTAG;

	tag_t Childobject1 = NULLTAG;
	tag_t CtrObjArchQryTag = NULLTAG;
	tag_t ArchTag = NULLTAG;
	tag_t ArchTagRev = NULLTAG;

	
	DMLDRstatusStr=(char *) MEM_alloc(10);
	Arch_item_idStr=(char *) MEM_alloc(10);


	printf("\n In function tm_validateModuleAddress------------");fflush(stdout);

	if (DMLRevTag != NULLTAG)
	{
		CALLAPI(AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo));
		CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRstatus));
		printf("\t DMLNo------>:%s: DMLDRstatus: %s ",DMLNo,DMLDRstatus);fflush(stdout);

		tc_strcpy(DMLDRstatusStr,",");
		tc_strcat(DMLDRstatusStr,DMLDRstatus);
		tc_strcat(DMLDRstatusStr,",");

		printf(" DMLDRstatusStr: [%s] ",DMLDRstatusStr);fflush(stdout);

		if (top_line != NULLTAG)
		{
			CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &ArchNodeLines));
			printf("\n tm_validateModuleAddress--ArchNodeLines::n_lines1: [%d] ",n_lines1);fflush(stdout);

			if (n_lines1 >0)
			{
				tc_strcpy(NoModuleStr,"");

				CALLAPI(QRY_find2("Control Objects...", &CtrObjArchQryTag));
				if (CtrObjArchQryTag != NULLTAG)
				{
					if (AltrozFlag>0)
					{
						printf("\n tm_validateModuleAddress--In AltrozArchNode condition...."); fflush(stdout);
						ArchrNodeyEntryValue[0] = "AltrozArchNode"; //SYSCD
						ArchrNodeyEntryValue[1] = "AltrozArchNode"; //SUBSYSCD
					}
					else
					{
						printf("\n tm_validateModuleAddress--In HornbillArchNode condition...."); fflush(stdout);
						ArchrNodeyEntryValue[0] = "HornbillArchNode"; //SYSCD
						ArchrNodeyEntryValue[1] = "HornbillArchNode"; //SUBSYSCD
					}

					CALLAPI(QRY_execute(CtrObjArchQryTag, 2, ArchQryEntry, ArchrNodeyEntryValue, &ArchNodeQryC, &ArchNodeCtrObj));
				}
				printf("\t Control-count: [%d] ",ArchNodeQryC); fflush(stdout);

				if(ArchNodeQryC>0)	
				{
					CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo1",&strinfo1));
					CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo2",&strinfo2));
					CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo3",&strinfo3));
					CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo4",&strinfo4));
					CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo6",&strinfo6));

					printf("\n tm_validateModuleAddress--DR-Info6=> [%s] ",strinfo6); fflush(stdout);
					printf("\n tm_validateModuleAddress--Address-Info1=> [%s] ",strinfo1); fflush(stdout);
					printf("\n tm_validateModuleAddress--Address-Info2=> [%s] ",strinfo2); fflush(stdout);
					printf("\n tm_validateModuleAddress--Address-Info3=> [%s] ",strinfo3); fflush(stdout);
					printf("\n tm_validateModuleAddress--Address-Info4=> [%s] \n",strinfo4); fflush(stdout);
				}

				for (p3=0;p3<n_lines1 ;p3++ )
				{
					if(Childobject1) Childobject1=NULLTAG;

					Childobject1=ArchNodeLines[p3];

					CALLAPI(AOM_ask_value_string(Childobject1,"bl_item_item_id",&Arch_item_id));

					CALLAPI(BOM_line_ask_child_lines(Childobject1, &n_lines3, &moduleslines));

					printf("\n tm_validate--p3:[%d] Arch:[%s]-->childCnt: [%d] ",p3,Arch_item_id,n_lines3);fflush(stdout);

					if (n_lines3 == 0)
					{
						ModuleAvailFlag=0;

						printf(" DMLDR:[%s] info6:[%s] [%s] ArchLen:[%d] ",DMLDRstatusStr,strinfo6,Arch_item_id,tc_strlen(Arch_item_id));fflush(stdout);

						if (Arch_item_id!=NULL)
						{
							CALLAPI(ITEM_find_item(Arch_item_id,&ArchTag));
							CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));
							CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));

							tc_strcpy(Arch_item_idStr,subString(Arch_item_id , tc_strlen(Arch_item_id)-6 , tc_strlen(Arch_item_id)-1 ) ); //6=length of module address
							
							printf(" Arch_item_idStr:[%s] sModuleAdrr:[%s] ",Arch_item_idStr,sModuleAdrr);fflush(stdout);

							if(((strinfo1 != NULL)&&(tc_strstr(strinfo1,Arch_item_idStr) != NULL)) ||
							   ((strinfo2 != NULL)&&(tc_strstr(strinfo2,Arch_item_idStr) != NULL)) ||
							   ((strinfo3 != NULL)&&(tc_strstr(strinfo3,Arch_item_idStr) != NULL)) ||
							   ((strinfo4 != NULL)&&(tc_strstr(strinfo4,Arch_item_idStr) != NULL)) )
							{
								printf("\t --Found in control-Object ");fflush(stdout);
								ModuleAvailFlag=ModuleAvailFlag+1;
							}
						}

						printf("  ModuleAvailFlag: [%d] ",ModuleAvailFlag);fflush(stdout);

						if ((tc_strstr(strinfo6,DMLDRstatusStr)!=NULL)&&(ModuleAvailFlag>0)&&(DMLDRstatusStr != NULL)&&(strinfo6 != NULL))
						{
							tc_strcat(NoModuleStr,"[");
							tc_strcat(NoModuleStr,Arch_item_id);
							tc_strcat(NoModuleStr,"]");
							tc_strcat(NoModuleStr,",");
							
							errorflag1=errorflag1+1;
							
							printf("\n tm_validateModuleAddress--D......show error....for no module under architecture [%s] %d  [%s] \n",Arch_item_id,n_lines3,DMLDRstatusStr);fflush(stdout);
						}
					}
				}

				if (errorflag1 > 0)
				{
					printf("\n tm_validateModuleAddress--2.....show error..no module under architecture..");fflush(stdout);
					return 0;
				}
			}
		}
		else
		{
			EMH_clear_errors();
			//EMH_store_error_s1(EMH_severity_error,PLM_error,"Error2:Structure is not present under Platform. Please raise ticket in TMS TCUA-DML.");
			printf("\n tm_validateModuleAddress--Error2:Structure is not present under Platform in TCUA ?? \n\n");fflush(stdout);
			return 0;
		}
	}
	else
	{
		printf("\n tm_validateModuleAddress--DMLRevTag is not found ??? \n");fflush(stdout);
	}

	printf("\n ------------Completed function tm_validateModuleAddress------------\n");fflush(stdout);

	return 0;
}
//int CM_CreateCCVfromSingleSVR(EPM_action_message_t msg)
int CM_CreateCCVfromSingleSVR(tag_t DMLTaskTag)
{
	int i=0,j=0,k=0;
	//int status=ITK_ok;
	int found,Dcrcnt = 0;
	int ifail=0;
	int jy=0;
	int Itemscnt=0;
	int dcrItemCnt=0,  dmlItemCnt=0, ItmCnt = 0,taskcnt = 0;
	int DcrItemscnt=0 , rulefound= 0 , status=0 ;
	int attachmentCount=0,qryRetCnt=0;
	int n_bom_views=0;
	int bom_view_index=0;
	int noAttachment=0;
	int IntAtr5=0;
	int n_strings = 1;
	int cnt12 = 0;
	int status_count =0;
	int ii =0;
	int index=0;
	int l_strings=80;
	int tempStrLength = 80;

	char *obj_type=NULL;
	char *dmlNumber=NULL;
	char *revId=NULL;
	char **qryEntries=NULL;
	char **qryValues=NULL;
	char *DMLDRstatus=NULL;
	char *usrInfo1=NULL;
	char *usrInfo2=NULL;
	char *ItemNumber=NULL;
	char *VCname=NULL;
	char *VCrevee=NULL;
	char *masid=NULL;
	char *ItemNumberwithDml=NULL;
	char *ItemId = NULL;
	char *RevId = NULL;
	char *VCItemId = NULL;
	char *SVRType = NULL;
	char *itemId12 = NULL;
	char *itemId123 = NULL;
	char *itemId1234 = NULL;
	char *itemId12345 = NULL;
	char *child_item_id=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	char *child_bl_formula=NULL;
	char *child_bl_formula23=NULL;
	char *VehName =NULL;
	char *objecttype=NULL;
	char *TempVal =NULL;
	char *platformName=NULL;
	char *objectname=NULL;
	char *ObjectName1=NULL;
	char *childsvrname=NULL;
	char *SVRNameStr=NULL;
	char *childsvrdesc=NULL;
	char *tempString = NULL;
	char *rel_status = NULL;
	char *rel_status1 = NULL;
	char *ProjDesc = NULL;
	char *ReleaseStatus=NULL;

	char **stringArray = NULL;
	char **rulename = NULL;
	char **rulevalue = NULL;

	char relation_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	char RelStat[200] = { 0 };

	tag_t bom_window = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t msWordType=NULLTAG;
	tag_t wordDataset=NULLTAG;
	tag_t wordLatestDat_t=NULLTAG;
	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t svrRev=NULLTAG;
	tag_t view_type= NULLTAG;
	tag_t rootTask_t=NULLTAG;
	tag_t primary1=NULLTAG;
	tag_t DcrItemObj=NULLTAG;
	tag_t implemRelationType_t=NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t VcSpecRel_t=NULLTAG;
	tag_t DMLRevTag=NULLTAG;
	tag_t bom_view_type=NULLTAG;
	tag_t item=NULLTAG;
	//tag_t DMLTaskTag=NULLTAG;
	tag_t bom_view= NULLTAG;
	tag_t VCrev= NULLTAG;
	tag_t Rel_task = NULLTAG;
	tag_t Rel_taska = NULLTAG;
	tag_t Rel_taskab = NULLTAG;
	tag_t Rel_taskab11 = NULLTAG;
	tag_t Rel_taskab112 = NULLTAG;
	tag_t rev_type_tag = NULLTAG;
	tag_t parent_master1 = NULLTAG;
	tag_t rev_create_input_tag = NULLTAG;
	tag_t item_type_tag = NULLTAG;
	tag_t tsk_dml_rel_type = NULLTAG;
	tag_t tRelationExist  = NULLTAG;
	tag_t tRelationExista  = NULLTAG;
	tag_t tRelationExistab  = NULLTAG;
	tag_t tRelationExistab11  = NULLTAG;
	tag_t SVRDerRel_t  = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;
	tag_t tRelationExistab11ss = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t relation_type1 = NULLTAG;
	tag_t status3=NULLTAG;
	tag_t objTypeTag=NULLTAG;
 	tag_t close_tag = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t parent_revision = NULLTAG;
	tag_t objTypeTag1=NULLTAG;
	tag_t NewRevTag = NULLTAG;
	tag_t PlatformRevTag = NULLTAG;

	tag_t *taskAttachments=NULLTAG;
	tag_t *closurerule = NULLTAG;
	tag_t *qryResults=NULLTAG;
	tag_t *DcrList=NULLTAG;
	tag_t *taskList=NULLTAG;
	tag_t *ItemsList=NULLTAG;
	tag_t *DcrItemsList=NULLTAG;
	tag_t *bom_views=NULL;
	tag_t *DMLRevision= NULLTAG;
	tag_t *attachments12 =NULLTAG;
	tag_t* status_list = NULLTAG;

	logical retain=false;
	logical is_latest;

	//	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	//	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	printf("\n\n\t\t ----Start of function CM_CreateCCVfromSingleSVR---attachmentCount: %d ----------",attachmentCount);fflush(stdout);

	ITK_CALL(GRM_find_relation_type("T5_VCSpec",&VcSpecRel_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	ITK_CALL(GRM_find_relation_type("T5_DerivedFromSVR",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("T5_SVRDerivesCCV",&SVRDerRel_t));

	// for getting DR status of DML from DML task
	//	if(attachmentCount > 0)
	//	{
	//		DMLTaskTag = taskAttachments[0];
	
	if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	if (tsk_dml_rel_type!=NULLTAG)
	{
		if(GRM_list_primary_objects_only(DMLTaskTag,tsk_dml_rel_type,&taskcnt,&DMLRevision));
		printf("\n\t CM_CreateCCVfromSingleSVR---DML Revision from Task for MR : %d",taskcnt);fflush(stdout);

		for (jy=0;jy<taskcnt ;jy++ )
		{
			if(ITEM_rev_sequence_is_latest(DMLRevision[jy],&is_latest));
			printf("\n\t CM_CreateCCVfromSingleSVR---is_latest MR is : %d\n",is_latest);fflush(stdout);

			if(is_latest != true)
			{
				printf("\n\t CM_CreateCCVfromSingleSVR---is_latest is not true .....\n");fflush(stdout);
			}
			else
			{
				DMLRevTag = DMLRevision[jy];

				if(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRstatus));
			}
		}
	}

	// for getting DR status of DML from DML task end
	//	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	//	{
	//		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));

		ITK_CALL(WSOM_ask_object_type2(DMLTaskTag,&obj_type));
		printf(" CM_CreateCCVfromSingleSVR---Object Type = %s ",obj_type);fflush(stdout);

		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{
			if(DcrProblmItemsRelType != NULLTAG)
			{
	//				ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&Dcrcnt,&DcrList));
				ITK_CALL(GRM_list_secondary_objects_only(DMLTaskTag,DcrProblmItemsRelType,&Dcrcnt,&DcrList));

				printf(" CM_CreateCCVfromSingleSVR---Dcrcnt= %d ",Dcrcnt);fflush(stdout);

				for(i=0;i<Dcrcnt;i++)
				{
					rev1 = DcrList[i];

					if(AOM_ask_value_string(rev1,"object_type",&objecttype));
					if(AOM_ask_value_string(rev1,"object_name",&platformName));

					printf("\n CM_CreateCCVfromSingleSVR--Object Type in loop = [%s] ",objecttype);fflush(stdout);

					if (tc_strcmp(objecttype,"T5_PlatformRevision")==0)
					{
						printf("\t Platform: [%s] --> Platform Found",platformName);fflush(stdout);

						PlatformRevTag=rev1;
						break;
					}
				}

				if (PlatformRevTag == NULLTAG)
				{
					EMH_clear_errors();
					//EMH_store_error_s1(EMH_severity_error,PLM_error1,"Error1::Platform is not attached under DML Task Relation. Please raise ticket in TMS for support.");
					printf("\n CM_CreateCCVfromSingleSVR--Platform is not attached under DML Task Relation ?? \n\n");fflush(stdout);
					return 0;
				}

				for(i=0;i<Dcrcnt;i++)
				{
					printf("\n CM_CreateCCVfromSingleSVR---to find impacted items\n");fflush(stdout);

					svrRev = DcrList[i];

					if(AOM_ask_value_string(svrRev,"object_type",&objecttype));
					if(AOM_ask_value_string(svrRev,"object_name",&objectname));
					printf(" CM_CreateCCVfromSingleSVR---Object Type in loop = %s [%s] ",objecttype,objectname);fflush(stdout);

					if (tc_strcmp(objecttype,"VariantRule")==0)
					{
						primary1=svrRev;

						if(AOM_ask_value_string(primary1,"object_name",&childsvrname));
						if(AOM_ask_value_string(primary1,"object_name",&SVRNameStr));
						if(AOM_ask_value_string(primary1,"object_desc",&childsvrdesc));
						ITK_CALL(AOM_UIF_ask_value (primary1,"release_status_list", &rel_status1));

						printf("\n CM_CreateCCVfromSingleSVR---release_status_list rel_status11111111 :[%s] \n",rel_status1);   fflush(stdout);

						if(strstr(rel_status1,"ERC Released")!=NULL)
						{
							printf("\n CM_CreateCCVfromSingleSVR---SVR is released hence ignoring ?? \n");fflush(stdout);

							//EMH_clear_errors();
							//EMH_store_error_s3(EMH_severity_error,PLM_error1,"Error3::",childsvrname," SVR attached under DML is released hence cannot proceed. Please raise ticket in TMS for support.");
							//printf("\n CM_CreateCCVfromSingleSVR--Error3::%s SVR is released attached under DML Task hence cannot proceed ?? \n\n",childsvrname);fflush(stdout);
							return 0;
						}
						else
						{
							printf("\n CM_CreateCCVfromSingleSVR---VCItemId := %s \n", childsvrname); fflush(stdout);

							VehName=(char *) MEM_alloc(20);
							itemId12 = tc_strtok(childsvrname,"_");
							RevId=tc_strtok(NULL,"_");
							itemId123=subString(itemId12,0,8);
							itemId1234=subString(itemId12,0,4);
							itemId12345=subString(itemId12,11,1);
							tc_strcpy(VehName,"");
							tc_strcpy(VehName,itemId123);
							tc_strcat(VehName,itemId12345);

							printf("\n CM_CreateCCVfromSingleSVR---itemId12 ==> [%s] ",itemId12); fflush(stdout);
							printf("\t itemId1234-project==> [%s] \n",itemId1234); fflush(stdout);

							// Start-Module Address Validation UA1.68
							if (PlatformRevTag != NULLTAG)
							{
								if(BOM_create_window( &bom_window ));
								if(CFM_find( "ERC release and above", &rule ));
								if(BOM_set_window_config_rule( bom_window, rule ));
								if(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
								printf ("\n CM_CreateSnapShotfromSingleSVR--rule count %d \n",rulefound);fflush(stdout);
								if (rulefound > 0)
								{
									close_tag = closurerule[0];
									printf ("\n CM_CreateSnapShotfromSingleSVR--closure rule found \n");fflush(stdout);
								}
								if(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));

								if(BOM_set_window_pack_all(bom_window, TRUE));
								if(BOM_set_window_top_line( bom_window, NULLTAG, PlatformRevTag, NULLTAG, &top_line ));
								printf("\n CM_CreateSnapShotfromSingleSVR--After BOM_set_window_top_line..\n");fflush(stdout);

								if(BOM_window_apply_variant_configuration(bom_window,1,&svrRev));
								if(BOM_window_hide_unconfigured(bom_window));
								if(BOM_window_show_variants(bom_window));

								if(top_line!=NULLTAG)
								{
									status = tm_validateModuleAddress(DMLRevTag , top_line, 0 ); //AltrozFlag=0 for hornbill/Punch
									printf("\n CM_CreateCCVfromSingleSVR--tm_validateModuleAddress--status: [%d] \n",status); fflush(stdout);
									if (status != 0)
									{
										printf("\n CM_CreateCCVfromSingleSVR--2.....show error....");fflush(stdout);

										tc_strcat(NoModuleStr,"-->");
										tc_strcat(NoModuleStr,SVRNameStr);

										printf("\n CM_CreateCCVfromSingleSVR--1.No module is present under ** [%s]  please verify the SVR.\n ",NoModuleStr);fflush(stdout);
										printf("\n -------A.CM_CreateCCVfromSingleSVR function ended with above data error---------------------\n\n");fflush(stdout);

										//EMH_clear_errors();
										//EMH_store_error_s3(EMH_severity_information,PLM_error,"No module is present under **",NoModuleStr," please verify the SVR.");
										return 0;
									}
								}
							}
							// End-Module Address Validation UA1.68

							ITK_CALL(ITEM_find_item(itemId12, &parent_master1));

							if (parent_master1!=NULLTAG)
							{
								ITK_CALL(ITEM_ask_latest_rev(parent_master1, &parent_revision));
								if (parent_revision!=NULLTAG)
								{
									printf("\n CM_CreateCCVfromSingleSVR---parent_revision latest revision found [%s] \n",itemId12);fflush(stdout);
									// ITK_CALL(AOM_UIF_ask_value (parent_revision,"release_status_list", &rel_status));
									ITK_CALL(AOM_ask_value_string(parent_revision,"t5_PartType",&ProjDesc));

									printf("\n CM_CreateCCVfromSingleSVR---release_status_list :[%s] ProjDesc : [%s]\n",rel_status,ProjDesc);   fflush(stdout);
									printf("\n CM_CreateCCVfromSingleSVR---get release status from WSOM ask release status API\n");   fflush(stdout);

									if (WSOM_ask_release_status_list(parent_revision,&status_count,&status_list));
									tc_strcpy(RelStat,"");
									printf("\n CM_CreateCCVfromSingleSVR---number of statuses: %d \n",  status_count);fflush(stdout);

									for (ii = 0; ii < status_count; ii++)
									{
										if(AOM_ask_name(status_list[ii], &ReleaseStatus));
										printf("\t ReleaseStatus: %s\n", ReleaseStatus);fflush(stdout);
										tc_strcat(RelStat,"[");
										tc_strcat(RelStat,ReleaseStatus);
										tc_strcat(RelStat,"]");
										tc_strcat(RelStat,",");
									}

									if(tc_strstr(RelStat,"T5_LcsErcRlzd")!=NULL)
									{
										if(tc_strcmp(ProjDesc,"CCVC")==0) //Part type check
										{
											printf("\n\t <<<<<<<<<<<<<<<<child SVR is ERC Released>>>>>>>\n");fflush(stdout);

											if (TCTYPE_ask_object_type(parent_revision,&objTypeTag1));
											if (TCTYPE_ask_name2(objTypeTag1,&type_name));
											printf("\n <<<<<<<<<<type_name>>>>>>>>>> %s\n", type_name);fflush(stdout);
											// for VC spec delete

											if(GRM_list_secondary_objects_only(parent_revision,VcSpecRel_t,&cnt12,&attachments12));
											if (cnt12==1)
											{
												if (AOM_ask_value_string(attachments12[0],"object_name",&ObjectName1));
												printf("\n\n CM_CreateCCVfromSingleSVR---TechSpec Name  :%s\n",ObjectName1);fflush(stdout);

												GRM_find_relation(parent_revision,attachments12[0],VcSpecRel_t,&tRelationExistab11);
												if(tRelationExistab11 != NULLTAG)
												{
													printf("\n CM_CreateCCVfromSingleSVR---Relation found Between VC and TechSpec ......\n");fflush(stdout);

													//printf("\n Now deleting Relation Between VC and TechSpec \n");fflush(stdout);
													//ITK_CALL(GRM_delete_relation(tRelationExistab11));
													//printf("\nRelation deleted Successfully\n");fflush(stdout);
												}
											}

											// for VC spec delete ends

											if(tc_strcmp(type_name,"Design Revision")==0 )
											{
												printf("\n CM_CreateCCVfromSingleSVR---In type_name=Design Revision if condition--Non-NR Revision.... \n");fflush(stdout);

												ITK_CALL(ITEM_copy_rev(parent_revision,NULL,&NewRevTag));
												ITK_CALL(AOM_refresh(parent_revision,0));
												ITK_CALL(AOM_refresh(NewRevTag,0));
												ITK_CALL(AssignProject_VC(NewRevTag,itemId1234));

												ITK_CALL(AOM_lock( NewRevTag ));
												ITK_CALL(AOM_set_value_string(NewRevTag,"t5_PartStatus",DMLDRstatus));
												ITK_CALL(AOM_set_value_string(NewRevTag, "object_desc", childsvrdesc));

												if(AOM_save_without_extensions(NewRevTag));
												if(AOM_refresh(NewRevTag,0));
												if(AOM_unlock(NewRevTag));

												printf("\n CM_CreateCCVfromSingleSVR-------------object----------------- \n");fflush(stdout);

												//printf("\n Now creating Relation Between VC and TechSpec \n");fflush(stdout);
												//if(GRM_create_relation(NewRevTag,attachments12[0],VcSpecRel_t,NULLTAG,&Rel_taskab11));
												//if(GRM_save_relation  (Rel_taskab11));
												//
												//if(GRM_create_relation(parent_revision,attachments12[0],VcSpecRel_t,NULLTAG,&Rel_taskab112));
												//if(GRM_save_relation  (Rel_taskab112));
												//printf("\nRelation Created Successfully\n");fflush(stdout);

												if(DmlItemsRelation_t != NULLTAG)
												{
													GRM_find_relation(DMLTaskTag,NewRevTag,DmlItemsRelation_t,&tRelationExist);
													if (tRelationExist==NULLTAG)
													{
														//###  Creating Relation between DML and Task  ###
														printf("\n CM_CreateCCVfromSingleSVR---Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
														if(GRM_create_relation(DMLTaskTag,NewRevTag,DmlItemsRelation_t,NULLTAG,&Rel_task));
														if(GRM_save_relation  (Rel_task));
														printf("\n CM_CreateCCVfromSingleSVR---Relation Created Successfully\n");fflush(stdout);

														// for adding newly created CCV in solution  item end
													}
												}

												// to delete existing svr relation
												int snapcnt=0;
												int iy=0;
												tag_t *extsnap = NULLTAG;

												if(GRM_list_secondary_objects_only(NewRevTag,implemRelationType_t,&snapcnt,&extsnap));
												for(iy=0; iy<snapcnt; iy++)
												{
													printf("\n CM_CreateCCVfromSingleSVR---to find impacted items\n");fflush(stdout);
													GRM_find_relation(NewRevTag,extsnap[iy],implemRelationType_t,&tRelationExistab11ss);

													if(tRelationExistab11ss != NULLTAG)
													{
														printf("\n CM_CreateCCVfromSingleSVR---Now deleting Relation Between CCVVC and SVR \n");fflush(stdout);
														if(GRM_delete_relation(tRelationExistab11ss));
														printf("\n CM_CreateCCVfromSingleSVR---Relation deleted Successfully\n");fflush(stdout);
													}
												}
												// end to delete existing svr relation

												if(implemRelationType_t != NULLTAG)
												{
														GRM_find_relation(NewRevTag,primary1,implemRelationType_t,&tRelationExista);
														if (tRelationExista==NULLTAG)
														{
															printf("\n CM_CreateCCVfromSingleSVR---1.Now Creating Relation Between CCV and SVR \n");fflush(stdout);
															if(GRM_create_relation(NewRevTag,primary1,implemRelationType_t,NULLTAG,&Rel_taska));
															if(GRM_save_relation  (Rel_taska));
															printf("\n CM_CreateCCVfromSingleSVR---1.Relation Created Successfully\n");fflush(stdout);
														}
												}

												ITK_CALL(AOM_refresh(NewRevTag,0));
												ITK_CALL(AOM_unlock(NewRevTag));
												ITK_CALL(AOM_unlock(parent_master1));

												printf("\n CM_CreateCCVfromSingleSVR---1.Before Relation Create....\n");fflush(stdout);
												if(SVRDerRel_t != NULLTAG)
												{
													if(GRM_find_relation(primary1,NewRevTag,SVRDerRel_t,&tRelationExistab));
													if (tRelationExistab==NULLTAG)
													{
														printf("\n CM_CreateCCVfromSingleSVR---2.Now Creating Relation Between SVR and CCV \n");fflush(stdout);
														if(GRM_create_relation(primary1,NewRevTag,SVRDerRel_t,NULLTAG,&Rel_taskab));
														if(GRM_save_relation  (Rel_taskab));
														printf("\n CM_CreateCCVfromSingleSVR---2.Relation Created Successfully\n");fflush(stdout);
													}
												}
											}
										}
										else
										{
											//EMH_store_error_s1(EMH_severity_error,PLM_error1,"Please Get Vehicle released with unit BOM ");
											printf("\n CM_CreateCCVfromSingleSVR---2.<<<<< release_status_list :[%s] >>>>>\n",rel_status);fflush(stdout);
											//return(PLM_error1);
										}
									}
									else
									{
										//if(strstr(rel_status,"ERC Released")==NULL)
										//{
										printf("\n CM_CreateCCVfromSingleSVR---3.release_status_list :[%s] >>>>>\n",rel_status);fflush(stdout);
										if (tc_strcmp(ProjDesc,"CCVC")==0)
										{
											printf("\n  CM_CreateCCVfromSingleSVR---3.ProjDesc>>> : [%s]\n",ProjDesc);   fflush(stdout);
											//EMH_store_error_s1(EMH_severity_error,PLM_error,"Please Get CCVC Released First ");
											printf("\n CM_CreateCCVfromSingleSVR---3.<<<<< release_status_list :[%s] >>>>>\n",rel_status);fflush(stdout);
											return 0;
										}
										//}
									}
								}
							}
							else
							{
								if(parent_master1 == NULLTAG)
								{
									stringArray = malloc( n_strings * sizeof *stringArray );
									for( index=0; index<n_strings; index++ )
									{
									stringArray[index] = malloc( l_strings + 1 );
									}
									tempString = malloc( tempStrLength + 1 );

									ITK_CALL( TCTYPE_find_type( "Design", NULL, &item_type_tag) );
									ITK_CALL( TCTYPE_find_type( "Design Revision", NULL, &rev_type_tag) );
									ITK_CALL( TCTYPE_construct_create_input( item_type_tag, &item_create_input_tag) );
									ITK_CALL( TCTYPE_construct_create_input( rev_type_tag, &rev_create_input_tag) );

									ITK_CALL( AOM_tag_to_string(rev_create_input_tag, &tempString) );
									strncpy( stringArray[0], tempString, l_strings );
									ITK_CALL( TCTYPE_set_create_display_value( item_create_input_tag, "revision", 1, stringArray) );

									strncpy( stringArray[0], itemId12, l_strings );
									ITK_CALL( TCTYPE_set_create_display_value( item_create_input_tag, "item_id", 1, stringArray) );

									strncpy( stringArray[0],itemId12,l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( item_create_input_tag, "object_name", 1, stringArray) );

									//strncpy( stringArray[0],RevId,l_strings);
									//ITK_CALL( TCTYPE_set_create_display_value( itemRevCreInTag, "item_revision_id", 1, stringArray) );

									strncpy( stringArray[0],"NR;1",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "item_revision_id", 1, stringArray) );

									strncpy( stringArray[0],itemId1234,l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_ProjectCode", 1, stringArray) );

									strncpy( stringArray[0],"CCVC",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_PartType", 1, stringArray) );

									strncpy( stringArray[0],childsvrdesc,l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "object_desc", 1, stringArray) );

									strncpy( stringArray[0],"00",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DesignGrp", 1, stringArray) );

									/*	strncpy( stringArray[0],"NA",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DocRemarks", 1, stringArray) );

									strncpy( stringArray[0],"PROPUN",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DsgnOwn", 1, stringArray) ); */

									strncpy( stringArray[0],"Y",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_ColourInd", 1, stringArray) );

									strncpy( stringArray[0],"VC",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_PrtCatCode", 1, stringArray) );

									strncpy( stringArray[0],DMLDRstatus,l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_PartStatus", 1, stringArray) );

									/*	strncpy( stringArray[0],"Pune-Design",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_DsgnDept", 1, stringArray) );

									strncpy( stringArray[0],"NA",l_strings);
									ITK_CALL( TCTYPE_set_create_display_value( rev_create_input_tag, "t5_MThickness", 1, stringArray) ); */

									TCTYPE_create_object(item_create_input_tag, &parent_master1);
									ITK_CALL(AOM_save_without_extensions(parent_master1));
									AOM_refresh(parent_master1,0);
									ITEM_ask_latest_rev(parent_master1, &VCrev);
									//ITEM_find_revision(parent_master1,"NR;1", &VCrev);

									if (VCrev!=NULLTAG)
									{
										ITK_CALL(AOM_lock(parent_master1));
										ITK_CALL(AOM_lock(VCrev));

										ITK_CALL(AOM_save_without_extensions(VCrev));
										printf("\n CM_CreateCCVfromSingleSVR---5.rev tag found.\n");fflush(stdout);
										ITK_CALL (RELSTAT_create_release_status("T5_LcsReview",&status3));
										printf("\n CM_CreateCCVfromSingleSVR---5.release status find 3.");fflush(stdout);
										ITK_CALL(RELSTAT_add_release_status(status3,1,&VCrev,retain));

										ITK_CALL(AssignProject_VC(VCrev,itemId1234));
										ITK_CALL(AssignProject_VC(parent_master1,itemId1234));

										if(implemRelationType_t != NULLTAG)
										{
											GRM_find_relation(VCrev,primary1,implemRelationType_t,&tRelationExista);
											if (tRelationExista==NULLTAG)
											{
												printf("\n CM_CreateCCVfromSingleSVR---5.Now Creating Relation Between CCV and SVR \n");fflush(stdout);
												if(GRM_create_relation(VCrev,primary1,implemRelationType_t,NULLTAG,&Rel_taska));
												if(GRM_save_relation  (Rel_taska));
												printf("\n CM_CreateCCVfromSingleSVR---5.Relation Created Successfully\n");fflush(stdout);
											}
										}

										AOM_refresh(VCrev,0);
										ITK_CALL(AOM_unlock(VCrev));
										AOM_unlock(parent_master1);
									}

									if(SVRDerRel_t != NULLTAG)
									{
										GRM_find_relation(primary1,VCrev,SVRDerRel_t,&tRelationExistab);
										if (tRelationExistab==NULLTAG)
										{
											printf("\n CM_CreateCCVfromSingleSVR---6.Now Creating Relation Between SVR and CCV \n");fflush(stdout);
											if(GRM_create_relation(primary1,VCrev,SVRDerRel_t,NULLTAG,&Rel_taskab));
											if(GRM_save_relation  (Rel_taskab));
											printf("\n CM_CreateCCVfromSingleSVR---6.Relation Created Successfully\n");fflush(stdout);
										}
									}

									if(AOM_ask_value_string(VCrev,"item_id",&VCname));
									if(AOM_ask_value_string(VCrev,"item_revision_id",&VCrevee));

									printf("\n CM_CreateCCVfromSingleSVR---VC name and revision is .%s %s",VCname,VCrevee); fflush(stdout);

									// for adding newly created CCV in solution  item
									if(DmlItemsRelation_t != NULLTAG)
									{
										GRM_find_relation(DMLTaskTag,VCrev,DmlItemsRelation_t,&tRelationExist);
										if (tRelationExist==NULLTAG)
										{
											//###  Creating Relation between DML and Task  ###

											printf("\n CM_CreateCCVfromSingleSVR---7.Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
											if(GRM_create_relation(DMLTaskTag,VCrev,DmlItemsRelation_t,NULLTAG,&Rel_task));
											if(GRM_save_relation  (Rel_task));
											printf("\n CM_CreateCCVfromSingleSVR---7.Relation Created Successfully\n");fflush(stdout);

											// for adding newly created CCV in solution  item end
										}
									}
								}
							}
						}
					}
				}
			}
		}
	//	}

	printf("\n -----Completed CM_CreateCCVfromSingleSVR function -------------------------\n");fflush(stdout);

	return ITK_ok;
}



int vc_release( tag_t DMLTag )
{
	int ifail = 0;
	int stat = ITK_ok;
	int n_bom_views	= 0;
	int j = 0;
	int bom_view_index = 0;
	int noAttachment = 0;
	int n_saved_variant_rules=0;
	int n_options =0;
	int errorflag =0;
	int errorflag4 =0;
	int errorflag1 =0;
	int ernew	   =0;
	int errorflag2 =0;
	int errorflag34	=0;
	int inx=0, jnx=0, knx=0;
	int n_option_data=0, p1=0;
	int n_ves_2_save=0;
	int n_lines2=0;
	int n_lines3=0;
	int n_lines4=0;
	int p2=0;
	int ss=0 , ss2 = 0;
	int p36=0;
	int p4=0;
	int n_lines,n_lines1,Item_ID = 0;
	int option_value_index = -1;
	int cnt = 0;
	int cnt12 = 0;
	int cnt33 = 0;
	int ko = 0;
	int p3 = 0;
	int i = 0;
	int status_count = 0 , NewRevstatus_count = 0;
	int ix=0;
	int imat=0;
	int jmat=0;
	int IntAtr5=0;
	int n_occs=0;
	int iy=0;
	int p34=0;
	int countConfigCtx = 0;
	int n_entries = 1;
	int resultCount=0;
	int opcode=-1;
	int toggle_value_index = -1;
	int int_qunt=0;
	int n_ves,n_opts,k=0,k1=0,Opt1=0,n_values1=0,n_secondaries=0,countDep,countDep1=0;
	int xform_matrix1 = 0;
	int blqu = 0;
	int Childstrcnt= 0;
	int p=0;
	int ju=0;
	int DMLSTVALUT=0;
	int jy=0;
	int v_entr=0;
	int bv_count=0, bvr_count=0;
	int rulefound= 0;
	int structcount=0;
	int n_tags_found = 0;
	int n_tags_found1 = 0;
	int n_tags_found3 = 0;
	int count = 0;
	int PRTSTVALU=0;
	int DRstusFlag=0;
	int add=0;
	int n_instances = 0;
	int n_classes = 0;
	int strcnt2 = 0;
	int rsltCount2 = 0;
	int n_entry2 = 2;
	//int rsltCount2 = 0;
	//int BU_n_entry = 1;
	//int BU_rsltCount = 0;

	int *option1_value_index=NULL;
	int *option2_value_index=NULL;
	int *ind;
	int *ind1;
	int *class_levels;
	int *class_where_found;
	int *instance_where_found;
	int *instance_levels;

	char *v2_text	= NULL;
	char *ItemId	= NULL;
	char *RevId		= NULL;
	char *VCItemId	= NULL;
	char *SVRType	= NULL;
	char *Item_ID_str= NULL;
	char *child_item_id=NULL;
	char *Arch_item_id=NULL;
	char *Arch_item_idStr=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	char *child_bl_formula=NULL;
	char **child_bl_formula23=NULL;
	char *objecttype=NULL;
	char *platformName=NULL;
	char *objectname=NULL;
	char *objectdesc=NULL;
	char *tempmat=NULL;
	char *option_item_s     =NULL;
	char *option_s          =NULL;
	char *option_eq_s       =NULL;
	char *option_val_s      =NULL;
	char *tempmat1=NULL;
	char *SmVCContext = NULL;
	char *SmCrIDContext = NULL;
	char *itemId12 = NULL;
	char *itemId123 = NULL;
	char *itemId1234 = NULL;
	char *itemId12345 = NULL;
	char *ContextobjName = NULL;
	char *str=NULL;
	char *object_type=NULL;
	char *find_option_name_p=NULL;
	char *find_option_desc_p=NULL;
	char *Context_Str=NULL;
	char *toggle_value=NULL;
	char *qry_entries[1] = {"ID"};
	char *name = NULL;
	char *username =NULL;
	char *TempVal =NULL;
	char *VehName =NULL;
	char *InpDMLTask =NULL;
	char *DMLNo =NULL;
	char *DMLDRstatus =NULL;
	char *DMLDRstatusStr =NULL;
	char *CurrentRelStatus = NULL;
	char *NewRevRelStatus = NULL;
	char *spcPrefName = NULL;
	char *class_name1 = NULL;
	char *DMLtype = NULL;
	char *DMLDRStrT = NULL;
	char *PRTDRStr = NULL;
	char *PrtDRstus = NULL;
	char *PrtProjj = NULL;
	char *Obj_PrtTyp = NULL;
	char *class_name = NULL;
	char *sModuleAdrr = NULL;
	char *sModuleName = NULL;
	char *sArchModule = NULL;
	char *latest_rev_Rel_Stus = NULL;

	char PartNum[300];
	char ERCRelErrStrng[1500];
	char command[512];

	char **rulename = NULL;
	char **rulevalue = NULL;
	char *desc = NULL;
	char *varrul = NULL;
	char **blqu_str = NULL;
	char **xform_matrix_str = NULL;
	char ***ite = NULL;
	char ***opt = NULL;
	char ***descr = NULL;
	char ***value = NULL;

	char* Config_CtxType= NULL;
	char* relation_name= NULL;
	char MulModule[1900] = { 0 };
	char MulChild[1900] = { 0 };
	char Fresh[1900];
	char NoModule[1900];
	char T3Z01NoModule[2000];
	char NoAlternateModule[2000];
	char RevMisMatch[900];
	char* type_name2= NULL;
	char* type_name= NULL;
	char* type_name1= NULL;
	char* CVVCPltform= NULL;

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t *bom_views = NULLTAG;
	tag_t *Obj_Tag = NULLTAG;
	tag_t *attachments = NULLTAG;
	tag_t *attachments12 = NULLTAG;
	tag_t *saved_variant_rules=NULLTAG;
	tag_t *options = NULLTAG;
	tag_t *option1_rev = NULLTAG;
	tag_t *option2_rev = NULLTAG;
	tag_t topline = NULLTAG;
	tag_t *ves_2_save = NULLTAG;
	tag_t *lines = NULL;
	tag_t *lines2 = NULL;
	tag_t *lines3 = NULL;
	tag_t *lines4 = NULL;
	tag_t *Newlines = NULL;
	tag_t *opts=NULLTAG;
	tag_t *rootLine=NULLTAG;
	tag_t *bom_variant_config=NULLTAG;
	tag_t *opt_revs=NULLTAG;
	tag_t *secondaries=NULLTAG;
	tag_t *occs = NULLTAG;
	tag_t *occsal = NULLTAG;
	tag_t *secondary_objects = NULLTAG;
	tag_t *secondary_objects1 = NULLTAG;
	tag_t *status_list = NULLTAG;
	tag_t *NewRevstatus_list = NULLTAG;
	tag_t *ConfigCtxSecObject = NULLTAG;
	tag_t *toggle_option_rev=NULLTAG;
	tag_t *ves=NULLTAG;
	tag_t *attachments1 = NULLTAG;
	tag_t *OptionValue=NULLTAG;
	tag_t *option_revs=NULLTAG;
	tag_t *closurerule = NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *bvs = NULLTAG, *bvrs = NULLTAG;
	tag_t *tags_found = NULLTAG;
	tag_t *tags_found1 = NULLTAG;
	tag_t *tags_found3 = NULLTAG;
	tag_t *ref_instancesTemp = NULLTAG;
	tag_t *ref_instances = NULLTAG;
	tag_t *ref_classes = NULLTAG;
	tag_t *VCReviseCtrObj = NULLTAG;
	//tag_t *BUntrlObjectTag = NULLTAG;

	tag_t **variant_rule_list= NULLTAG;

	tag_t rev = NULLTAG;
	tag_t rev1 = NULLTAG;
	tag_t view_type = NULLTAG;
	tag_t item = NULLTAG;
	tag_t bom_view	= NULLTAG;
	tag_t bom_view_type	=NULLTAG;
	tag_t e_block = NULLTAG;
	//tag_t DMLTag = NULLTAG;
	tag_t bom_window = NULLTAG;
	tag_t window2 = NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t top_line1 = NULLTAG;
	tag_t rule = NULLTAG;
	tag_t Childobject = NULLTAG;
	tag_t Childobject1 = NULLTAG;
	tag_t Childobject3 = NULLTAG;
	tag_t Childobject4 = NULLTAG;
	tag_t Childobject33 = NULLTAG;
	tag_t dataset = NULLTAG;
	tag_t *bom_variant_rule = NULLTAG;
	tag_t option1 = NULLTAG;
	tag_t option2 = NULLTAG;
	tag_t toggle_ve = NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t relation_type1 = NULLTAG;
	tag_t v1 = NULLTAG;
	tag_t primary = NULLTAG;
	//tag_t Obj_Tag = NULLTAG;
	//const tag_t *primary1 = NULLTAG;
	tag_t primary1 = NULLTAG;
	tag_t tRelationExist = NULLTAG;
	tag_t tRelationExist1 = NULLTAG;
	tag_t tRelationExist2 = NULLTAG;
	tag_t tRelationExist3 = NULLTAG;
	tag_t tRelationExist4 = NULLTAG;
	tag_t item1 = NULLTAG;
	tag_t rootTask = NULLTAG;
	tag_t option = NULLTAG;
	tag_t option_rev = NULLTAG;
	tag_t objTypeTagDi=NULLTAG;
	tag_t objTypeTagDi1=NULLTAG;
	tag_t opt_tag=NULLTAG;
	tag_t master_tag=NULLTAG;
	tag_t Itemmaster_tag=NULLTAG;
	tag_t relation_dep = NULLTAG;
	tag_t ConfigCtx = NULLTAG;
	tag_t ConfigCtxObjTypeTag = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t Optfmly_tag = NULLTAG;
	tag_t v2 = NULLTAG;
	tag_t toggle_option=NULLTAG;
	tag_t owning_item = NULLTAG;
	tag_t VCrev = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	tag_t Itemrev = NULLTAG;
	tag_t ItemRev = NULLTAG;
	tag_t ItemRev1 = NULLTAG;
	tag_t Rel_task = NULLTAG;
	tag_t RevNewSeqTag = NULLTAG;
	tag_t parent_master = NULLTAG;
	tag_t parent_master1 = NULLTAG;
	tag_t rev_create_input_tag = NULLTAG;
	tag_t item_type_tag = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;
	tag_t status2=NULLTAG;
	tag_t status3=NULLTAG;
	tag_t status4=NULLTAG;
	tag_t rev_type_tag = NULLTAG;
	tag_t tsk_dml_rel_type;
	tag_t DMLRevTag = NULLTAG;
	tag_t class_id1=NULLTAG;
	tag_t bv = NULLTAG, bvr = NULLTAG, parentBvr = NULLTAG, bv1 = NULLTAG, bvr1 = NULLTAG;
	tag_t Childrev = NULLTAG;
	tag_t user_tag =NULLTAG;
	tag_t cond_ve  = NULLTAG;
	tag_t loadif_ve = NULLTAG;
	tag_t veb = NULLTAG;
	tag_t attr_idDR = NULLTAG;
	tag_t class_id = NULLTAG;
	tag_t class_idr = NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t top_bomline = NULLTAG;
	tag_t clause_list = NULLTAG;
	tag_t CtrObjVCReviseQryTag = NULLTAG;
	tag_t ArchTag = NULLTAG;
	tag_t ArchTagRev = NULLTAG;
	//tag_t BUqryTag = NULLTAG;

	logical list_changed=FALSE;
	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;
	logical modB=FALSE;

	void **option_data=NULL;

	variant_rule_option_data_t *variant_rule_option_data=NULL;
	variant_rule_option_data_t option_value_dictionary={NULL};

	GRM_relation_t *primary_list_Dep = NULLTAG;

	double mat[4][4];
	double divInt=1000;

	logical retain=false;
	logical is_latest ;
	logical lNull = false, lEmpty = false;
	logical log1 ;
	
	//char *BU_qry_entry[1] = {"SYSCD"};
	//char **BU_qry_values2 =  (char **) MEM_alloc(50 * sizeof(char *));
	//char *VCReviseQryEntry[2]  = {"SYSCD","SUBSYSCD"};
	//char **VCReviseEntryValue = (char **) MEM_alloc(50 * sizeof(char *));

	char *VCReviseinfo1 =NULL;
	int VCReviseQryC=0;

	TempVal=(char *) MEM_alloc(1000);
	DMLDRstatusStr=(char *) MEM_alloc(10);
	Arch_item_idStr=(char *) MEM_alloc(10);
	//July2023
	int jk = 0;
	int jkk = 0;
	int iArcMdl = 0;
	int iManMOErrFlag = 0;
	int iManSODupFlag = 0;
	int iManSOFlag = 0;
	int MDL_n_entry2 = 2;
	int iNManSODupFlag = 0;
	int MDL_n_entry3 = 2;
	int MDL_rsltCount2 = 0;
	int MDL_rsltCount3 = 0;
	int BU_n_entry = 1;
	int sManSQErrorFlag = 0;
	int sManSQFlag = 0;
	int sNManSQErrorFlag = 0;
	int sNManSQFlag = 0;
	int sManMQErrorFlag = 0;
	int sManMQFlag = 0;
	int BU_rsltCount = 0;
	int strcnt1=0;
	int strcnt3=0;
	int BOmvarcnt1=0;
	
	char   *DMLBUnit=NULL;
	char   *BUInfo1 = NULL;
	char   *BUInfo2 = NULL;
	char   *BUInfo3 = NULL;
	char   *VCPltform = NULL;
	char   *sMDLinofA1=NULL;
	char   *sMDLinofA2=NULL;
	char   *sMDLinofA3=NULL;
	char   *sMDLinofA4=NULL;
	char   *sMDLinofA5=NULL;
	char   *sMDLinofA6=NULL;
	char   *sMDLinofA7=NULL;
	char   *sMDLinofA8=NULL;
	char   *sMDLinofA9=NULL;
	char   *sMDLinofA10=NULL;
	char **	AStringList =NULL;
	char **	BStringList =NULL;
	char **	CStringList =NULL;
	char **	DStringList =NULL;
	char    *DR_qry_entry[1]  = {"SYSCD"};
	char    *MDL_qry_entry2[2]  = {"SYSCD","SUBSYSCD"};
	char    *MDL_qry_entry3[2]  = {"SYSCD","SUBSYSCD"};
	char    *MDL_qry_entry4[2]  = {"SYSCD","SUBSYSCD"};
	char    **DR_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values3     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    **MDL_qry_values4     =  (char **) MEM_alloc(50 * sizeof(char *));
	char *CVObjtyp=NULL;
	char *CVObjDesc=NULL;
	char *CVObjName=NULL;
	char *MDLAddress =NULL;
	tag_t CVrev = NULLTAG;
	tag_t BUqryTag = NULLTAG;
	tag_t CVview_type = NULLTAG;
	tag_t CVitem = NULLTAG;
	tag_t *CVbom_views = NULLTAG;
	tag_t CVbom_view	= NULLTAG;
	tag_t CVbom_window = NULLTAG;
	tag_t CVclose_tag = NULLTAG;
	tag_t CVrule = NULLTAG;
	tag_t Qry_Tag = NULLTAG;
	tag_t *CVclosurerule = NULLTAG;
	tag_t *CVbom_variant_rule = NULLTAG;
	tag_t MdlObj=NULLTAG;
	tag_t CVobjTypeTag=NULLTAG;
	tag_t CVtop_line = NULLTAG;
	tag_t MdlQry_Tag = NULLTAG;
	tag_t MdlQry_Tag3 = NULLTAG;
	tag_t *CVoptions = NULLTAG;
	tag_t *CVoption_revs=NULLTAG;
	tag_t *CVlines = NULLTAG;
	tag_t *MDL_Obj_Tag = NULLTAG;
	tag_t *MDL_Obj_Tag3 = NULLTAG;
	tag_t *BUntrlObjectTag = NULLTAG;
	int CVn_lines	= 0;
	int n_CVbom_views	= 0;
	int CVn_lines3= 0;
	int	piStringCount	= 0;
	int CVn_lines1= 0;
	int mdlcunt= 0;
	int Cv_entr= 0;
	int SVRFlag= 0;
	int CVrulefound= 0;
	int BOmvarcnt2= 0;
	char **CVrulename = NULL;
	char **CVrulevalue = NULL;
	char* CVtype_name= NULL;

	char* sManMQMOSet = NULL ;
	char* sManSQMOSet = NULL ;
	char* sNManSQMOSet = NULL ;
	char* sNManMQMOSet = NULL ;
	char* sCPModuleAvailErr = NULL ;
	char* OtherZeroQtySet = NULL ;
	char* inValidQtySet = NULL ;
	char* sNManSODupErr = NULL ;
	char* sManSODupErr = NULL ;
	char* sManSOErr = NULL ;
	char* sManMOErr = NULL ;
	char* sFinalErr = NULL ;
	char *BU_qry_entry[1] = {"SYSCD"};
	char **BU_qry_values2 =  (char **) MEM_alloc(50 * sizeof(char *));
	char *VCReviseQryEntry[2]  = {"SYSCD","SUBSYSCD"};
	char **VCReviseEntryValue = (char **) MEM_alloc(50 * sizeof(char *));
	sManMQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
	sManSQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
	sNManSQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
	sNManMQMOSet     =  (char *) MEM_alloc(100000 * sizeof(char));
	sCPModuleAvailErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	OtherZeroQtySet     =  (char *) MEM_alloc(100000 * sizeof(char));
	inValidQtySet     =  (char *) MEM_alloc(100000 * sizeof(char));
	sNManSODupErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	sManSODupErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	sManSOErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	sManMOErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	sFinalErr     =  (char *) MEM_alloc(100000 * sizeof(char));
	tc_strcpy (sManMOErr,"" );
	tc_strcpy (sManMQMOSet,"" );
	tc_strcpy (sManSQMOSet,"" );
	tc_strcpy (sNManSQMOSet,"" );
	tc_strcpy (sNManMQMOSet,"" );
	//Error list
	tc_strcpy (sCPModuleAvailErr,"" );
	tc_strcpy (OtherZeroQtySet,"" );
	tc_strcpy (inValidQtySet,"" );
	tc_strcpy (sNManSODupErr,"" );
	tc_strcpy (sManSODupErr,"" );
	tc_strcpy (sManSOErr,"" );
	tc_strcpy (sFinalErr,"" );
	//July2023
	tc_strcpy(ERCRelErrStrng,"");
	tc_strcpy(DMLDRstatusStr,"");
	tc_strcpy(Arch_item_idStr,"");
	char    **qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	char    *qry_entry2[2]  = {"SYSCD","Information-1"};

	char *VCPltform1 =NULL;

	VCPltform1=(char *) MEM_alloc(100);

	POM_get_user(&username,&user_tag);
	printf("\n---Starting for vc_release :[%s]------------------------------------\n",username);fflush(stdout);

	//CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	//CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	//printf(" vc_release--Target Attachment:%d\n",noAttachment);fflush(stdout);

	//if(noAttachment > 0)
	//{
	    //DMLTag = attachments[0];

		//CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&InpDMLTask));
		//printf("\n\t vc_release--InpDMLTask: %s ",InpDMLTask);fflush(stdout);
	//}

	CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&InpDMLTask));
	printf("\n\t vc_release--InpDMLTask: %s ",InpDMLTask);fflush(stdout);

	CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	CALLAPI(GRM_find_relation_type("CMReferences",&relation_type));
	CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&relation_type1));

	//	CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
	//	CALLAPI(GRM_find_relation_type("CMReferences",&relation_type));
	//	CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&relation_type1));

	if (tsk_dml_rel_type!=NULLTAG)
	{
		CALLAPI(GRM_list_primary_objects_only(DMLTag,tsk_dml_rel_type,&count,&DMLRevision));
		printf("\n\t vc_release--DML Revision from Task for MR : %d",count);fflush(stdout);

		for( jy=0; jy<count; jy++ )
		{
			CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[jy],&is_latest));
			printf("\n\t vc_release--is_latest MR is : %d\n",is_latest);fflush(stdout);

			if(is_latest != true)
			{
				printf("\n\t vc_release--is_latest is not true .....\n");fflush(stdout);
			}
			else
			{
				DMLRevTag = DMLRevision[jy];

				CALLAPI(POM_class_of_instance(DMLRevTag,&class_id1));
				CALLAPI(POM_name_of_class(class_id1,&class_name1));
				printf("\n\t vc_release--class_name: %s",class_name1);fflush(stdout);

				CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_cDRstatus",&DMLDRstatus));
				CALLAPI(AOM_ask_value_string(DMLRevTag,"item_id",&DMLNo));
				CALLAPI(AOM_ask_value_string(DMLRevTag,"t5_ERCBusiUt",&DMLBUnit));
				printf("\t DMLNo------>:%s:DMLDRstatus------>:%s: DMLBUnit------>:%s: ",DMLNo,DMLDRstatus,DMLBUnit);fflush(stdout);

				tc_strcpy(DMLDRstatusStr,",");
				tc_strcat(DMLDRstatusStr,DMLDRstatus);
				tc_strcat(DMLDRstatusStr,",");

				DMLDRStrT=NULL;
				DMLSTVALUT=0;

				DMLDRStrT=subString(DMLDRstatus, 2, 1);
				printf("\n vc_release--DML DR status: DMLDRStrT: %s and ",DMLDRStrT);fflush(stdout);

				DMLSTVALUT=atoi(DMLDRStrT);
				printf(" DMLSTVALUT: %d  DMLDRstatusStr: [%s] \n",DMLSTVALUT,DMLDRstatusStr);fflush(stdout);
			}
		}
	}
	else
	{
		EMH_clear_errors();
		//EMH_store_error_s1(EMH_severity_error,PLM_error,"DML Task Relation not found. Please raise ticket in TMS.");
		printf("\n vc_release--DML-Task Relation T5_DMLTaskRelation not found in TCUA ?? \n\n");fflush(stdout);
		return 0;
	}

	if(relation_type != NULLTAG)
	{
		//AAA:Control Table
		//AAA: BU compair
		//Find validation which are not applicable to CV.
		if(QRY_find2("ControlObjects", &BUqryTag));
		if (BUqryTag)
		{
			printf("\n A0001:Found Query ControlObjects \n");fflush(stdout);
		}
		else
		{
			printf("\n A0002:Not Found Query ControlObjects \n");fflush(stdout);
		}

		BU_qry_values2[0] = "VCDmlBU";
		if(QRY_execute(BUqryTag, BU_n_entry, BU_qry_entry, BU_qry_values2, &BU_rsltCount, &BUntrlObjectTag));
		printf(" \nA0003:BU_rsltCount :%d:", BU_rsltCount); fflush(stdout);
		if(BU_rsltCount > 0)
		{
			//ON/OFF
			if (AOM_ask_value_string(BUntrlObjectTag[0],"t5_Userinfo1",&BUInfo1));
			if (AOM_ask_value_string(BUntrlObjectTag[0],"t5_Userinfo2",&BUInfo2));
			if (AOM_ask_value_string(BUntrlObjectTag[0],"t5_Userinfo3",&BUInfo3));  // Multi 
			printf("\n A0004:BUInfo1 is  = [%s]; BUInfo2 is  = [%s]",BUInfo1,BUInfo2);fflush(stdout);
		}
		CALLAPI(TCTYPE_ask_name2( relation_type,&relation_name));
		printf("\n vc_release--Relation-TypeName: [%s] ",relation_name);fflush(stdout);

		CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type,&cnt,&attachments1));
		printf("\t ChangeReferences-atatched-object-counts: [%d] \n",cnt);fflush(stdout);

		for(i=0;i<cnt;i++)
		{
			printf("\n vc_release--A.i: [%d] to find impacted items ",i);fflush(stdout);

			rev1 = attachments1[i];

			if(AOM_ask_value_string(rev1,"object_type",&objecttype));
			if(AOM_ask_value_string(rev1,"object_name",&platformName));

			printf("\t objecttype: [%s]   platformName: [%s] ",objecttype,platformName);fflush(stdout);

			if (strcmp(objecttype,"T5_PlatformRevision")==0)
			{
				primary1=rev1;
				//if(AOM_ask_value_string(rev1,"object_name",&VCPltform));

				//printf("\t --> Platform Found :VCPltform:%s",VCPltform);fflush(stdout);

				printf("\t CV:DMLBUnit:%s",DMLBUnit);fflush(stdout);
				if (strcmp(DMLBUnit,"CVBU")==0)
				{
					if(AOM_ask_value_string(rev1,"object_name",&VCPltform));
					printf("\t CV:Platform Found :VCPltform:%s  DMLBUnit:%s",VCPltform,DMLBUnit);fflush(stdout);
					//Quesy control object 

					if(QRY_find2("Control Objects...", &Qry_Tag));
					if (Qry_Tag)
					{
						printf("\n CV_VC:P3:Found Query Qry_Tag \n");fflush(stdout);
					}
					else
					{
						printf("\n CV_VC:P4:Not Found Query Qry_Tag \n");fflush(stdout);
					}


					tc_strcpy (VCPltform1,"");
					tc_strcpy (VCPltform1,"*");
					
					tc_strcat (VCPltform1,VCPltform);
					printf ("\n CV_VC:72:VCPltform1 to check:[%s]. ",VCPltform1);fflush(stdout);

					qry_values2[0] = "PartPlatform";
					qry_values2[1] = VCPltform1;
					//MDL_qry_values2[1] = "MHCV";//hardcoded fro testing
					if(QRY_execute(Qry_Tag, n_entry2, qry_entry2, qry_values2, &rsltCount2, &Obj_Tag));
					printf(" \n CV_VC:P5:rsltCount2 :%d:", rsltCount2); fflush(stdout);
					if(rsltCount2 > 0)
					{
						if (AOM_ask_value_string(Obj_Tag[0],"t5_Userinfo1",&CVVCPltform));
						printf(" \n CV_VC:P5:CVVCPltform :%d:", CVVCPltform); fflush(stdout);
					}
				}
				else
				{
					if(AOM_ask_value_string(rev1,"object_name",&VCPltform));
					printf("\t PV: Platform Found :VCPltform:%s  DMLBUnit:%s",VCPltform,DMLBUnit);fflush(stdout);
				}

				break;
			}
		}

		if (primary1 == NULLTAG)
		{
			EMH_clear_errors();
			//EMH_store_error_s1(EMH_severity_error,PLM_error,"Platform is not attached under DML Task Relation. Please raise ticket in TMS for support.");
			printf("\n vc_release--Platform is not attached under DML Task Relation ?? \n\n");fflush(stdout);
			return 0;
		}
		/////////////////////
		//Put Logic here for (platform based modular BOM validation.
		if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
		{
			printf("\n CV_VC:P1:Function call for platform based moduler BOM validation.."); fflush(stdout);
			if(tc_strstr(BUInfo1,"A008")==NULL)
			{
				printf("\n CV_VC:P2:If moduler BOM then check mandatory module address, Duplication allowed in BOM. \n");fflush(stdout);													
				//Quering control tables for mandatory module address: Duplication allowed in BOM.
				if(QRY_find2("Control Objects...", &MdlQry_Tag));
				if (MdlQry_Tag)
				{
					printf("\n CV_VC:P3:Found Query MdlQry_Tag \n");fflush(stdout);
				}
				else
				{
					printf("\n CV_VC:P4:Not Found Query MdlQry_Tag \n");fflush(stdout);
				}

				MDL_qry_values2[0] = "MANDTE";
				MDL_qry_values2[1] = VCPltform;
				//MDL_qry_values2[1] = "MHCV";//hardcoded fro testing
				if(QRY_execute(MdlQry_Tag, MDL_n_entry2, MDL_qry_entry2, MDL_qry_values2, &MDL_rsltCount2, &MDL_Obj_Tag));
				printf(" \n CV_VC:P5:MDL_rsltCount2 :%d:", MDL_rsltCount2); fflush(stdout);
				if(MDL_rsltCount2 > 0)
				{
					for(jk=0;jk<MDL_rsltCount2;jk++)
					{
						sMDLinofA1=NULL;
						sMDLinofA2=NULL;
						sMDLinofA3=NULL;
						sMDLinofA4=NULL;
						sMDLinofA5=NULL;
						sMDLinofA6=NULL;
						sMDLinofA7=NULL;
						sMDLinofA8=NULL;
						sMDLinofA9=NULL;
						sMDLinofA10=NULL;
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo1",&sMDLinofA1));
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo2",&sMDLinofA2));
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo3",&sMDLinofA3));
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo4",&sMDLinofA4));
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo5",&sMDLinofA5));
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo6",&sMDLinofA6));
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo7",&sMDLinofA7));
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo8",&sMDLinofA8));
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_Userinfo9",&sMDLinofA9));
						if (AOM_ask_value_string(MDL_Obj_Tag[jk],"t5_userinfo10",&sMDLinofA10));
						printf("\n CV_VC:P7:sMDLinofA1: [%s]", sMDLinofA1);fflush(stdout);
						printf("\n CV_VC:P8:sMDLinofA2: [%s]",sMDLinofA2);fflush(stdout);
						printf("\n CV_VC:P9:sMDLinofA3: [%s]",sMDLinofA3);fflush(stdout);
						printf("\n CV_VC:P10:sMDLinofA4: [%s]",sMDLinofA4);fflush(stdout);
						printf("\n CV_VC:P11:sMDLinofA5: [%s]",sMDLinofA5);fflush(stdout);
						printf("\n CV_VC:P12:sMDLinofA6: [%s]",sMDLinofA6);fflush(stdout);
						printf("\n CV_VC:P13:sMDLinofA7: [%s]",sMDLinofA7);fflush(stdout);
						printf("\n CV_VC:P14:sMDLinofA8: [%s]",sMDLinofA8);fflush(stdout);
						printf("\n CV_VC:P15:sMDLinofA9: [%s]",sMDLinofA9);fflush(stdout);
						printf("\n CV_VC:P16:sMDLinofA10: [%s]",sMDLinofA10);fflush(stdout);
						if(tc_strcmp(sMDLinofA1,"Multi")==0)
						{
							if (tc_strlen(sMDLinofA2) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA2);
								printf("\n CV_VC:P17:M2..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA3) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA3);
								printf(" M3..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA4) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA4);
								printf(" M4..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA5) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA5);
								printf(" M5..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA6) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA6);
								printf(" M6..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA7) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA7);
								printf(" M7..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA8) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA8);
								printf(" M8..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA9) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA9);
								printf(" M9..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA10) > 1)
							{
								tc_strcat (sManMQMOSet,sMDLinofA10);
								printf(" M10.");fflush(stdout);
							}
							printf("\n CV_VC:P18:sManMQMOSet: %s",sManMQMOSet); fflush(stdout);
						}
						else if(tc_strcmp(sMDLinofA1,"Single")==0)
						{
							if (tc_strlen(sMDLinofA2) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA2);
								printf("\n CV_VC:P19:M2..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA3) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA3);
								printf(" M3..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA4) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA4);
								printf(" M4..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA5) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA5);
								printf(" M5..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA6) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA6);
								printf(" M6..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA7) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA7);
								printf(" M7..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA8) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA8);
								printf(" M8..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA9) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA9);
								printf(" M9..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA10) > 1)
							{
								tc_strcat (sManSQMOSet,sMDLinofA10);
								printf(" M10.");fflush(stdout);
							}
							printf("\n CV_VC:P20:sManSQMOSet: %s",sManSQMOSet); fflush(stdout);
						}
						else
						{
							printf("\n CV_VC:P21:Other case....");fflush(stdout);
						}
					}
					printf("\n CV_VC:P22:Final sManMQMOSet: %s",sManMQMOSet); fflush(stdout);
					printf("\n CV_VC:P23:Final sManSQMOSet: %s",sManSQMOSet); fflush(stdout);
				}
				// checking for non mandatory module addresses.
				printf("\n CV_VC:P24:If moduler BOM then check mandatory module address.. \n");fflush(stdout);
				//Quering control tables for mandatory module address: Duplication allowed in BOM.
				if(QRY_find2("Control Objects...", &MdlQry_Tag3));
				if (MdlQry_Tag3)
				{
					printf("\n CV_VC:P25:Found Query MdlQry_Tag3 \n");fflush(stdout);
				}
				else
				{
					printf("\n CV_VC:P26:Not Found Query MdlQry_Tag3 \n");fflush(stdout);
				}

				MDL_qry_values3[0] = "NMANDTE";
				MDL_qry_values3[1] = VCPltform;
				//MDL_qry_values3[1] = "MHCV";//hardcoded for testing
				if(QRY_execute(MdlQry_Tag3, MDL_n_entry3, MDL_qry_entry3, MDL_qry_values3, &MDL_rsltCount3, &MDL_Obj_Tag3));
				printf("\n CV_VC:P27:MDL_rsltCount3 :%d:", MDL_rsltCount3); fflush(stdout);
				if(MDL_rsltCount3 > 0)
				{
					jk=0;
					for(jk=0;jk<MDL_rsltCount3;jk++)
					{
						sMDLinofA1=NULL;
						sMDLinofA2=NULL;
						sMDLinofA3=NULL;
						sMDLinofA4=NULL;
						sMDLinofA5=NULL;
						sMDLinofA6=NULL;
						sMDLinofA7=NULL;
						sMDLinofA8=NULL;
						sMDLinofA9=NULL;
						sMDLinofA10=NULL;
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo1",&sMDLinofA1));
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo2",&sMDLinofA2));
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo3",&sMDLinofA3));
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo4",&sMDLinofA4));
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo5",&sMDLinofA5));
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo6",&sMDLinofA6));
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo7",&sMDLinofA7));
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo8",&sMDLinofA8));
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_Userinfo9",&sMDLinofA9));
						if (AOM_ask_value_string(MDL_Obj_Tag3[jk],"t5_userinfo10",&sMDLinofA10));
						printf("\n CV_VC:P28:sMDLinofA1: [%s]", sMDLinofA1);fflush(stdout);
						printf("\n CV_VC:P29:sMDLinofA2: [%s]",sMDLinofA2);fflush(stdout);
						printf("\n CV_VC:P30:sMDLinofA3: [%s]",sMDLinofA3);fflush(stdout);
						printf("\n CV_VC:P31:sMDLinofA4: [%s]",sMDLinofA4);fflush(stdout);
						printf("\n CV_VC:P32:sMDLinofA5: [%s]",sMDLinofA5);fflush(stdout);
						printf("\n CV_VC:P33:sMDLinofA6: [%s]",sMDLinofA6);fflush(stdout);
						printf("\n CV_VC:P34:sMDLinofA7: [%s]",sMDLinofA7);fflush(stdout);
						printf("\n CV_VC:P35:sMDLinofA8: [%s]",sMDLinofA8);fflush(stdout);
						printf("\n CV_VC:P36:sMDLinofA9: [%s]",sMDLinofA9);fflush(stdout);
						printf("\n CV_VC:P37:sMDLinofA10: [%s]",sMDLinofA10);fflush(stdout);
						if(tc_strcmp(sMDLinofA1,"Multi")==0)
						{
							if (tc_strlen(sMDLinofA2) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA2);
								printf("\n CV_VC:P38:S2..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA3) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA3);
								printf(" S3..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA4) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA4);
								printf(" S4..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA5) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA5);
								printf(" S5..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA6) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA6);
								printf(" S6..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA7) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA7);
								printf(" S7..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA8) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA8);
								printf(" S8..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA9) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA9);
								printf(" S9..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA10) > 1)
							{
								tc_strcat (sNManMQMOSet,sMDLinofA10);
								printf(" S10.");fflush(stdout);
							}
							printf("\n CV_VC:P39:sNManMQMOSet: %s",sNManMQMOSet); fflush(stdout);
						}
						else if(tc_strcmp(sMDLinofA1,"Single")==0)
						{
							if (tc_strlen(sMDLinofA2) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA2);
								printf("\n CV_VC::S2..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA3) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA3);
								printf(" S3..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA4) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA4);
								printf(" S4..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA5) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA5);
								printf(" S5..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA6) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA6);
								printf(" S6..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA7) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA7);
								printf(" S7..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA8) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA8);
								printf(" S8..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA9) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA9);
								printf(" S9..");fflush(stdout);
							}
							if (tc_strlen(sMDLinofA10) > 1)
							{
								tc_strcat (sNManSQMOSet,sMDLinofA10);
								printf(" S10.");fflush(stdout);
							}
							printf("\n CV_VC:40:sNManSQMOSet: %s",sNManSQMOSet); fflush(stdout);
						}
						else
						{
							printf("\n CV_VC:41:Other case....");fflush(stdout);
						}
					}
					printf("\n CV_VC:42:Final sNManMQMOSet: %s",sNManMQMOSet); fflush(stdout);
					printf("\n CV_VC:43:Final sNManSQMOSet: %s",sNManSQMOSet); fflush(stdout);
				}
			}
			if(tc_strstr(BUInfo1,"A005")==NULL)
			{
				for(jk=0;jk<cnt;jk++)
				{
					printf("\n CV_VC:44:jk: attachment no:[%d]",jk);fflush(stdout);
					CVrev = attachments1[jk];

					if(AOM_ask_value_string(CVrev,"object_type",&CVObjtyp));
					if(AOM_ask_value_string(CVrev,"object_name",&CVObjName));
					printf("\n CV_VC:46:CVObjtyp: [%s]  CVObjName: [%s] ",CVObjtyp,CVObjName);fflush(stdout);

					if (strcmp(CVObjtyp,"VariantRule")==0)
					{
						
						if(AOM_ask_value_string(CVrev,"object_desc",&CVObjDesc));
						printf( "\n CV_VC:47:CVObjDesc ",CVObjDesc); fflush(stdout);


						if ( primary1 !=NULLTAG )
						{
							CALLAPI ( PS_find_view_type( "view", &CVview_type ));
							if ( CVview_type != NULLTAG )
							{
								CALLAPI ( ITEM_ask_item_of_rev( primary1, &CVitem ));
								CALLAPI ( ITEM_list_bom_views( CVitem, &n_CVbom_views, &CVbom_views ));
								CVbom_view = CVbom_views[0];
							}
							else
							{
								printf("\n CV_VC:48:View not found check.......\n"); fflush(stdout);
							}
						}

						if ( CVbom_view != NULLTAG )
						{
							printf("\n CV_VC:49:before BOM_create_window..\n");	fflush(stdout);

							CALLAPI ( BOM_create_window( &CVbom_window ));
							CALLAPI(CFM_find( "Latest Working", &CVrule ))
							CALLAPI(BOM_set_window_config_rule( CVbom_window, CVrule ));
							CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &CVrulefound, &CVclosurerule ));
							printf ("\n CV_VC:50:CVrule count %d \n",CVrulefound);fflush(stdout);
							if (CVrulefound > 0)
							{
								CVclose_tag = CVclosurerule[0];
								printf ("\n CV_VC:51:.closure CVrule found \n");fflush(stdout);
							}
							CALLAPI(BOM_window_set_closure_rule( CVbom_window,CVclose_tag, 0, CVrulename,CVrulevalue ));
							CALLAPI(BOM_set_window_pack_all(CVbom_window, FALSE));
							CALLAPI(BOM_set_window_top_line( CVbom_window, NULLTAG, primary1, NULLTAG, &CVtop_line ));
							printf("\n CV_VC:52:After BOM_set_window_top_line..\n");fflush(stdout);
							//CALLAPI(BOM_window_ask_variant_rule( CVbom_window, &CVbom_variant_rule ));
							if ( BOM_window_ask_variant_rules( CVbom_window,&BOmvarcnt1,&CVbom_variant_rule ));
							printf("\n CV_VC:53:BOM_window_ask_variant_rule..\n");fflush(stdout);
							if(BOmvarcnt1>0)
                            {
							CALLAPI(TCTYPE_ask_object_type(CVbom_variant_rule[0],&CVobjTypeTag));
							CALLAPI(TCTYPE_ask_name2(CVobjTypeTag,&CVtype_name));
							CALLAPI ( ITEM_ask_rev_variants ( primary1, &e_block ));
							}
							printf("\n CV_VC:54:ITEM_ask_rev_variants..\n");fflush(stdout);

							if(CVtop_line!=NULLTAG)
							{
								if(tc_strstr(BUInfo1,"A006")!=NULL)
								{
									CALLAPI(BOM_line_ask_child_lines(CVtop_line, &CVn_lines, &CVlines));
									printf("\n CV_VC:55.Before setting option CVn_lines: %d and Item_ID_str :%s\n", CVn_lines,Item_ID_str);

									CALLAPI(BOM_window_hide_unconfigured(CVbom_window));
									CALLAPI(BOM_window_show_variants(CVbom_window));
									printf("\n CV_VC:56:After inside CVbom_window-----\n"); fflush(stdout);
									CALLAPI(BOM_window_apply_variant_configuration(CVbom_window,1,&CVrev))   ;
									printf("\n CV_VC:57:After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
									//if(BOM_window_apply_overlay_variant_rules(CVbom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
									CALLAPI(BOM_window_hide_variants(CVbom_window))   ;
									CALLAPI(BOM_line_ask_child_lines(CVtop_line, &CVn_lines, &CVlines));
									printf("\n CV_VC:58:CVn_lines: [%d]  ",CVn_lines); fflush(stdout);
									//AAA:Need to check need for below loop
									if (CVn_lines >0)
									{
										structcount=0;
										for (jkk=0;jkk<CVn_lines ;jkk++ )
										{
											if(Childobject) Childobject=NULLTAG;

											Childobject=CVlines[jkk];

											CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
											printf("\n CV_VC:59:-jkk: [%d]  child_item_id: %s",jkk,child_item_id); fflush(stdout);
											//printf("\n vc_release--jkk: [%d]  ",jkk); fflush(stdout);

											CALLAPI(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));
											structcount++;
											tc_strcpy(childstr[jkk].parent_part,child_item_id);
											childstr[jkk].child=n_lines2;
											printf("\n CV_VC:60:Part no IS: %s  n_lines2: %d ",childstr[jkk].parent_part,childstr[jkk].child);fflush(stdout);
										}
									}
								}
							}
							else
							{
								EMH_clear_errors();
								//EMH_store_error_s1(EMH_severity_error,PLM_error,"Structure is not present under Platform. Please check and for any query, please raise ticket in TMS TCUA-DML.");
								printf("\n CV_VC:61:-Structure is not present under Platform in TCUA [%s] ?? \n\n",platformName);fflush(stdout);
								return 0;
							}

							CALLAPI(CFM_find( "ERC release and above", &CVrule ))
							CALLAPI(BOM_set_window_config_rule( CVbom_window, CVrule ));
							memset( &option_value_dictionary, 0, sizeof ( option_value_dictionary ) );

							if(BOmvarcnt1>0)
							{
							CALLAPI ( BOM_variant_rule_ask_options( CVbom_variant_rule[0], &Cv_entr, &CVoptions, &CVoption_revs ) )
							printf("\n CV_VC:62:No of Option values in the CVrule:%d\n",Cv_entr);fflush(stdout);
							}

							if ( CVtop_line!=NULLTAG )
							{
								printf("\n CV_VC:63:inside CVbom_window-----\n"); fflush(stdout);
								if(tc_strstr(BUInfo1,"V001")!=NULL)
								{
									printf("\n CV_VC:63: %s %s: inside topline Revision is \n", VOO_prog, VOO_time_stamp() ); fflush(stdout);
									//AAA check??
									CALLAPI ( VOO_show_wso( primary1 )) ;
								}

								CALLAPI(BOM_line_ask_child_lines(CVtop_line, &CVn_lines1, &CVlines));
								printf("\n CV_VC:64:1.LLlast Before setting option CVn_lines1: %d \n", CVn_lines1);

								if(CVbom_window != NULLTAG)
								{
									printf("\n CV_VC:65:before inside CVbom_window-----\n"); fflush(stdout);
									CALLAPI(BOM_window_hide_unconfigured(CVbom_window))   ;
									CALLAPI(BOM_window_show_variants(CVbom_window))   ;
									printf("\n CV_VC:66:After inside CVbom_window-----\n"); fflush(stdout);
									CALLAPI(BOM_window_apply_variant_configuration(CVbom_window,1,&CVrev))   ;
									printf("\n CV_VC:67:After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

									//if(BOM_window_apply_overlay_variant_rules(CVbom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
									CALLAPI(BOM_window_hide_variants(CVbom_window))   ;
									CALLAPI(BOM_window_ask_is_modified(CVbom_window,&modB))   ;
									if(modB)
									{
										printf("\n CV_VC:68:modified bom window\n"); fflush(stdout);
									}
									else
									{
										printf("\n CV_VC:69:not modified bom window\n"); fflush(stdout);
									}

									CALLAPI(BOM_line_ask_child_lines(CVtop_line, &CVn_lines1, &CVlines));

									CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
									if(relation_dep != NULLTAG)
									{
										printf("\n\t CV_VC:70:Variant ConfigContext relation found......");	fflush(stdout);
									}
									//kept off
									if(tc_strstr(BUInfo1,"A007")!=NULL)
									{
										CALLAPI(GRM_list_secondary_objects_only(CVitem,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
										printf("\n\t Configuration Context count is : %d",countConfigCtx);

										if(countConfigCtx>0)
										{
											ConfigCtx=ConfigCtxSecObject[0];

											CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
											CALLAPI(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType));
											printf( "\n\t vc_release--Config relation Config_CtxType :%s ..",Config_CtxType);

											CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
											printf("\n\t vc_release--SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

											CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
											printf("\n\t vc_release--SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

											if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag));
											printf("\n\t vc_release--After Cfg0OptionFamiliesFromIDs : QRY_find2");fflush(stdout);

											if (queryTag != NULLTAG)
											{
												printf("\t vc_release--Found Query");fflush(stdout);
											}else
											{
												printf("\t vc_release--Not Found Query");fflush(stdout);
											}

											qry_values[0] = SmCrIDContext;

											if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &OptionValue));
											printf("\n\t vc_release--resultCount : %d\n", resultCount); fflush(stdout);
										}
									}

									printf("\n CV_VC:68:2.LLlast Before setting option CVn_lines1: [%d] \n", CVn_lines1); fflush(stdout);

									EMH_clear_errors();

									if (CVn_lines1 >0)
									{
										if(tc_strstr(BUInfo1,"A009")==NULL)
										{
											//We got Arc module here, get the module address from it. and check in table w.r.t platform.
											//if single mandatory, then count CVn_lines3 should be 1.
											//if Multi mandatory, then count CVn_lines3 should >= 1.
											//if Single not mandatory, then count CVn_lines3 should be 1 or 0.
											//if Multi not mandatory, then count CVn_lines3 should be 1 or 0 or multi...no need check
											/////////////////////////////////////////////////////
											printf("\n CV_VC:P69:Final sManMQMOSet: %s",sManMQMOSet); fflush(stdout);
											if(tc_strstr(BUInfo1,"A010")==NULL)
											{
												if((sManMQMOSet==NULL)|| (tc_strcmp(sManMQMOSet,"")==0))
												{
													printf("\n CV_VC:70:sManMQMOSet is NULL.\n");fflush(stdout);
												}
												else
												{
													mdlcunt=0;
													piStringCount=0;
													if(EPM__parse_string(sManMQMOSet,",",&piStringCount,&AStringList));
													for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
													{
														MDLAddress=NULL;
														MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
														tc_strcpy (MDLAddress,"" );
														printf("\n CV_VC:71:sManMQMOSet Part:%s ",AStringList[mdlcunt]);fflush(stdout);
														tc_strcat (MDLAddress,AStringList[mdlcunt]);
														printf ("\n CV_VC:72:MDLAddress to check:[%s]. ",MDLAddress);fflush(stdout);
														if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
														{
															printf("\n CV_VC:73:MDLAddress is NULL.\n");fflush(stdout);
														}
														else
														{
															sManMQFlag=0;
															sManMQErrorFlag=0;
															for (iArcMdl=0;iArcMdl<CVn_lines1 ;iArcMdl++ )
															{
																if(Childobject1) Childobject1=NULLTAG;

																Childobject1=CVlines[iArcMdl];

																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &Arch_item_id ));
																printf("\n CV_VC:74:Arc Modlue no:[%s]\n",child_item_id1);fflush(stdout);

																CALLAPI(ITEM_find_item(Arch_item_id,&ArchTag));
																if (ArchTag != NULLTAG)
																{
																	CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleName",&sModuleName));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModule",&sArchModule));
																	printf("\n CV_VC:75:sModuleAdrr:[%s] sModuleName:[%s] sArchModule:[%s] ",sModuleAdrr,sModuleName,sArchModule);fflush(stdout);
																	if(tc_strlen(sModuleAdrr) == 0)
																	{
																		EMH_clear_errors();
																		//EMH_store_error_s1(EMH_severity_error,PLM_error,"Module address not available on Architecture Module Revision. Please update it.");
																		printf("\n CV_VC:76:Module address not available on Architecture Module Revision. Please update it\n",platformName);fflush(stdout);
																		return 0;
																	}
																}
																//if(tc_strcmp(MDLAddress,sModuleAdrr)==0)
																if(tc_strstr(sModuleAdrr,MDLAddress)!=NULL)
																{
																	sManMQFlag=1;
																	CVn_lines3=0;
																	CALLAPI(BOM_line_ask_child_lines(Childobject1, &CVn_lines3, &lines3));
																	printf(" and Module count:[%d]\n",CVn_lines3);fflush(stdout);
																	if(CVn_lines3 >0)
																	{
																		printf("\n CV_VC:78:MDLAddress:[%s] is Multi Mandatory available. \n",MDLAddress);fflush(stdout);
																	}
																	else
																	{
																		sManMQErrorFlag=1;
																		printf("\n CV_VC:79:ERROR:MDLAddress:[%s] is Multi Mandatory not available:[%d] \n",MDLAddress,sManMQErrorFlag);fflush(stdout);																		
																	}
																	break;
																}
															}
															if ((sManMQFlag==0) ||(sManMQErrorFlag==1))
															{
																printf("\n CV_VC:80:sManMQ error.  \n");fflush(stdout);
																if((tc_strcmp(sManMOErr,"")==0) || (tc_strstr(sManMOErr,CVObjName)==NULL))
																{
																	if(tc_strcmp(sManMOErr,"")!=0)
																	{
																		tc_strcat(sManMOErr,"\n");
																	}
																	//tc_strcat(sManMOErr,"\n");
																	tc_strcat(sManMOErr,CVObjName);
																	tc_strcat(sManMOErr,": ");
																}

																if(tc_strstr(sManMOErr,MDLAddress)==NULL)
																{
																	iManMOErrFlag ++;
																	if ((iManMOErrFlag ==20)|| (iManMOErrFlag ==40)||(iManMOErrFlag ==60)||(iManMOErrFlag ==80))
																	{
																		tc_strcat(sManMOErr,"\n");
																	}
																	tc_strcat(sManMOErr,MDLAddress);
																	tc_strcat(sManMOErr,",");
																	printf("\n CV_VC:81:ManMO_module address [%s] added to error set.:[%s]",MDLAddress,sManMOErr);fflush(stdout);
																}
																else
																{
																	printf("\n CV_VC:82::Module address already added... [%s]",MDLAddress);fflush(stdout);
																}
															}
														}
													}
												}
											}
											printf("\n CV_VC:83:Final sManSQMOSet: %s",sManSQMOSet); fflush(stdout);
											if(tc_strstr(BUInfo1,"A011")==NULL)
											{
												if((sManSQMOSet==NULL)|| (tc_strcmp(sManSQMOSet,"")==0))
												{
													printf("\n CV_VC:84:sManSQMOSet is NULL.\n");fflush(stdout);
												}
												else
												{
													mdlcunt=0;
													piStringCount=0;
													if(EPM__parse_string(sManSQMOSet,",",&piStringCount,&BStringList));
													for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
													{
														MDLAddress=NULL;
														MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
														tc_strcpy (MDLAddress,"" );
														printf("\n CV_VC:85:sManSQMOSet Part:[%s]",BStringList[mdlcunt]);fflush(stdout);
														tc_strcat (MDLAddress,BStringList[mdlcunt]);
														printf ("\n CV_VC:86:MDLAddress to check:[%s].. ",MDLAddress);fflush(stdout);
														if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
														{
															printf("\n CV_VC:87:MDLAddress is NULL..\n");fflush(stdout);
														}
														else
														{
															sManSQFlag=0;
															sManSQErrorFlag=0;
															for (iArcMdl=0;iArcMdl<CVn_lines1 ;iArcMdl++ )
															{
																if(Childobject1) Childobject1=NULLTAG;

																Childobject1=CVlines[iArcMdl];

																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &Arch_item_id ));
																printf("\n CV_VC:88:Arc Modlue no:[%s]\n",child_item_id1);fflush(stdout);

																CALLAPI(ITEM_find_item(Arch_item_id,&ArchTag));
																if (ArchTag != NULLTAG)
																{
																	CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleName",&sModuleName));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModule",&sArchModule));
																	printf("\n CV_VC:89:sModuleAdrr:[%s] sModuleName:[%s] sArchModule:[%s] ",sModuleAdrr,sModuleName,sArchModule);fflush(stdout);
																	if(tc_strlen(sModuleAdrr) == 0)
																	{
																		EMH_clear_errors();
																		//EMH_store_error_s1(EMH_severity_error,PLM_error,"Module address not available on Architecture Module Revision. Please update it.");
																		printf("\n CV_VC:90:Module address not available on Architecture Module Revision. Please update it\n",platformName);fflush(stdout);
																		return 0;
																	}
																}
																//if(tc_strcmp(MDLAddress,sModuleAdrr)==0)
																if(tc_strstr(sModuleAdrr,MDLAddress)!=NULL)
																{
																	sManSQFlag=1;
																	CVn_lines3=0;
																	CALLAPI(BOM_line_ask_child_lines(Childobject1, &CVn_lines3, &lines3));
																	printf(" and Module count:[%d]\n",CVn_lines3);fflush(stdout);
																	if(CVn_lines3 ==1)
																	{
																		printf("\n CV_VC:90:MDLAddress:[%s] is Single Mandatory available. \n",MDLAddress);fflush(stdout);
																	}
																	else if (CVn_lines3 >1)
																	{
																		//sManSQErrorFlag=1;
																		printf("\n CV_VC:91:ERROR:MDLAddress:[%s] is Single Mandatory not available, but Duplicated. \n",MDLAddress);fflush(stdout);
																		if((tc_strcmp(sManSODupErr,"")==0) || (tc_strstr(sManSODupErr,CVObjName)==NULL))
																		{
																			tc_strcat(sManSODupErr,CVObjName);
																			tc_strcat(sManSODupErr,": ");
																		}

																		if(tc_strstr(sManSODupErr,MDLAddress)==NULL)
																		{
																			iManSODupFlag ++;
																			if ((iManSODupFlag ==20)|| (iManSODupFlag ==40)||(iManSODupFlag ==60)||(iManSODupFlag ==80))
																			{
																				tc_strcat(sManSODupErr,"\n");
																			}
																			tc_strcat(sManSODupErr,MDLAddress);
																			tc_strcat(sManSODupErr,",");
																			printf("\n CV_VC:92:Dup ManMO_module address %s added to error set.:[%s]",MDLAddress,sManSODupErr);fflush(stdout);
																		}
																		else
																		{
																			printf("\n CV_VC:93:MOdule address already added..: [%s]",MDLAddress);fflush(stdout);
																		}
																	}
																	else if(CVn_lines3 ==0)
																	{
																		sManSQErrorFlag=1;
																		printf("\n CV_VC:94:ERROR:MDLAddress:[%s] is Single Mandatory not available:[%d] \n",MDLAddress,sManSQErrorFlag);fflush(stdout);
																	}
																	break;
																}
															}
															if ((sManSQFlag==0)||(sManSQErrorFlag ==1))
															{
																printf("\n CV_VC:95:Arc Module address not avaialble..- [%s]",MDLAddress);fflush(stdout);
																//Add to mandatory error set.
																if((tc_strcmp(sManSOErr,"")==0) || (tc_strstr(sManSOErr,CVObjName)==NULL))
																{
																	tc_strcat(sManSOErr,CVObjName);
																	tc_strcat(sManSOErr,": ");
																}

																if(tc_strstr(sManSOErr,MDLAddress)==NULL)
																{
																	iManSOFlag ++;
																	if ((iManSOFlag ==20)|| (iManSOFlag ==40)||(iManSOFlag ==60)||(iManSOFlag ==80))
																	{
																		tc_strcat(sManSOErr,"\n");
																	}
																	tc_strcat(sManSOErr,MDLAddress);
																	tc_strcat(sManSOErr,",");
																	printf("\n CV_VC:96:ManMO_module address %s added to error set.:[%s]",MDLAddress,sManSOErr);fflush(stdout);
																}
																else
																{
																	printf("\n CV_VC:97:Module address already added..- [%s]",MDLAddress);fflush(stdout);
																}
															}
														}
													}
												}
											}
											printf("\n CV_VC:98::Final sNManSQMOSet: %s",sNManSQMOSet); fflush(stdout);
											if(tc_strstr(BUInfo1,"A012")==NULL)
											{
												if((sNManSQMOSet==NULL)|| (tc_strcmp(sNManSQMOSet,"")==0))
												{
													printf("\n CV_VC:99:sNManSQMOSet is NULL.\n");fflush(stdout);
												}
												else
												{
													mdlcunt=0;
													piStringCount=0;
													if(EPM__parse_string(sNManSQMOSet,",",&piStringCount,&DStringList));
													for (mdlcunt=0;mdlcunt<piStringCount ;mdlcunt++ )
													{
														MDLAddress=NULL;
														MDLAddress     =  (char *) MEM_alloc(10 * sizeof(char));
														tc_strcpy (MDLAddress,"" );
														printf("\n CV_VC:A1:sNManSQMOSet Part:[%s]",DStringList[mdlcunt]);fflush(stdout);
														tc_strcat (MDLAddress,DStringList[mdlcunt]);
														printf ("\n CV_VC:A2:MDLAddress to check:[%s].. ",MDLAddress);fflush(stdout);
														if((MDLAddress==NULL)|| (tc_strcmp(MDLAddress,"")==0))
														{
															printf("\n CV_VC:A3:MDLAddress is NULL..\n");fflush(stdout);
														}
														else
														{
															sNManSQFlag=0;
															sNManSQErrorFlag=0;
															for (iArcMdl=0;iArcMdl<CVn_lines1 ;iArcMdl++ )
															{
																if(Childobject1) Childobject1=NULLTAG;

																Childobject1=CVlines[iArcMdl];

																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
																CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &Arch_item_id ));
																printf("\n CV_VC:A4:Arc Modlue no:[%s]\n",child_item_id1);fflush(stdout);

																CALLAPI(ITEM_find_item(Arch_item_id,&ArchTag));
																if (ArchTag != NULLTAG)
																{
																	CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleName",&sModuleName));
																	CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModule",&sArchModule));
																	printf("\n CV_VC:A5:sModuleAdrr:[%s] sModuleName:[%s] sArchModule:[%s] ",sModuleAdrr,sModuleName,sArchModule);fflush(stdout);
																	if(tc_strlen(sModuleAdrr) == 0)
																	{
																		EMH_clear_errors();
																		//EMH_store_error_s1(EMH_severity_error,PLM_error,"Module address not available on Architecture Module Revision. Please update it.");
																		printf("\n CV_VC:A6:Module address not available on Architecture Module Revision. Please update it\n",platformName);fflush(stdout);
																		return 0;
																	}
																}
																//if(tc_strcmp(MDLAddress,sModuleAdrr)==0)
																if(tc_strstr(sModuleAdrr,MDLAddress)!=NULL)
																{
																	sNManSQFlag=1;
																	CVn_lines3=0;
																	CALLAPI(BOM_line_ask_child_lines(Childobject1, &CVn_lines3, &lines3));
																	printf(" and Module count:[%d]\n",CVn_lines3);fflush(stdout);
																	if((CVn_lines3 ==1)||(CVn_lines3 ==0))
																	{
																		printf("\n CV_VC:A7:MDLAddress:[%s] no need to check non mandatory single. \n",MDLAddress);fflush(stdout);
																	}
																	else
																	{
																		sNManSQErrorFlag=1;
																		printf("\n CV_VC:A8:ERROR:MDLAddress:[%s] non mandatory single only allowed:[%d] \n",MDLAddress,sNManSQErrorFlag);fflush(stdout);
																		if((tc_strcmp(sNManSODupErr,"")==0) || (tc_strstr(sNManSODupErr,CVObjName)==NULL))
																		{
																			//tc_strcat(sNManSODupErr,"\n");
																			tc_strcat(sNManSODupErr,CVObjName);
																			tc_strcat(sNManSODupErr,": ");
																		}
																		if(tc_strstr(sNManSODupErr,MDLAddress)==NULL)
																		{
																			iNManSODupFlag ++;
																			if ((iNManSODupFlag ==20)|| (iNManSODupFlag ==40)||(iNManSODupFlag ==60)||(iNManSODupFlag ==80))
																			{
																				tc_strcat(sNManSODupErr,"\n");
																			}
																			tc_strcat(sNManSODupErr,MDLAddress);
																			tc_strcat(sNManSODupErr,",");
																			printf("\n CV_VC:A10:Non Mandatory single occurance, but duplicated.%s added to error set.:[%s]",MDLAddress,sNManSODupErr);fflush(stdout);
																		}
																	}
																	break;
																}
															}
															if ((sNManSQFlag==0)||(sNManSQErrorFlag==1))
															{
																printf("\n CV_VC:A9:Arc Module address not avaialble..- [%s]",MDLAddress);fflush(stdout);
															}
														}
													}
												}
											}
											printf("\n CV_VC:A11::Final:SKIP sNManMQMOSet: %s",sNManMQMOSet); fflush(stdout);
										}
									}
								}
								else
								{
									EMH_clear_errors();
									//EMH_store_error_s1(EMH_severity_error,PLM_error,"Structure not found for VC. Please raise ticket in TMS TCUA-DML.");
									printf("\n CV_VC:A12:Structure not found for VC in TCUA [%s] ?? \n\n",platformName);fflush(stdout);
									return 0;
								}
							}
						}
						if(tc_strstr(BUInfo1,"A019") == NULL)
						{
							printf("\n CV_VC:A13: closing BOM window..\n");fflush(stdout);
							CALLAPI(BOM_save_window(CVbom_window))
							CALLAPI(BOM_close_window(CVbom_window))
						}
					}
				}
				printf("\n CV_VC:A14:Final:sManMOErr:[%s] \n",sManMOErr);fflush(stdout);
				printf("\n CV_VC:A15:Final:sManSOErr:[%s] \n",sManSOErr);fflush(stdout);
				printf("\n CV_VC:A16:Final:sManSODupErr:[%s] \n",sManSODupErr);fflush(stdout);
				printf("\n CV_VC:A17:Final:sNManSODupErr:[%s] \n",sNManSODupErr);fflush(stdout);
				if(tc_strstr(BUInfo1,"A014") == NULL)
				{
					if(tc_strcmp(sManMOErr,"")!=0)
					{
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,"Below are mandatory module addresses, please check SVR. (ManMQ)");
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,sManMOErr);
					}
				}
				if(tc_strstr(BUInfo1,"A015") == NULL)
				{
					if(tc_strcmp(sManSOErr,"")!=0)
					{
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,"Below are mandatory module addresses, please check SVR. (ManSQ)");
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,sManSOErr);
					}
				}
				if(tc_strstr(BUInfo1,"A016") == NULL)
				{
					if(tc_strcmp(sManSODupErr,"")!=0)
					{
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,"Modules are duplicated for below module addresses, please check SVR. (NManSQDup)");
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,sManSODupErr);
					}
				}
				if(tc_strstr(BUInfo1,"A017") == NULL)
				{
					if(tc_strcmp(sNManSODupErr,"")!=0)
					{
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,"Modules for below module addresses are duplicated, please remove duplication. (NManSQ)");
						tc_strcat(sFinalErr,"\n");
						tc_strcat(sFinalErr,sNManSODupErr);
					}
				}
				if(tc_strstr(BUInfo1,"A018") == NULL)
				{
					if (tc_strlen(sFinalErr) > 0)
					{
						printf("\n CV_VC:A18:Final Error:::[%s] \n",sFinalErr);fflush(stdout);
						//EMH_clear_errors();
						//EMH_store_error_s2(EMH_severity_error,PLM_error,"Please find the below BOM error.\nPlease correct it and process. ",sFinalErr);
						return 0;
					}
					else
					{
						printf("\n CV_VC:A19:Final:NO Error...........\n");fflush(stdout);
					}
				}
			}
		}
		printf("\n CV_VC:A20:GOING TO MAIN CODE NOW...\n");fflush(stdout);
		int vcissue = 0;
		for(j=0;j<cnt;j++)
		{
			printf("\n\n vc_release--B.j: [%d] to find impacted items ",j);fflush(stdout);

			rev = attachments1[j];

			if(AOM_ask_value_string(rev,"object_type",&objecttype));
			if(AOM_ask_value_string(rev,"object_name",&objectname));

			printf("\t objecttype: [%s]  objectname: [%s] ",objecttype,objectname);fflush(stdout);

			if (strcmp(objecttype,"VariantRule")==0)
			{
				SVRFlag=0;
				if(tc_strstr(BUInfo1,"A020")==NULL)
				{
					if(tc_strstr(BUInfo1,"B001")==NULL)
					{
						printf("\n Checking VC availability Starting");fflush(stdout);
						int nTskCnt = 0;
						int tscount = 0;
						char *VCnm = NULL;
						char *seq = NULL;
						char *VRRev = NULL;
						char *VCname = NULL;
						VCnm =  (char *) MEM_alloc(10 * sizeof(char));
						seq =  (char *) MEM_alloc(10 * sizeof(char));
						VRRev =  (char *) MEM_alloc(10 * sizeof(char));
						char *VCRevG = NULL;
						int Child_Rev_count=0;
						tag_t VCtag = NULLTAG;
						tag_t VCTagLt = NULLTAG;
						tag_t part2tsk_rel_typ = NULLTAG;
						tag_t relation_type_tag = NULLTAG;
						tag_t *Child_rev_list = NULLTAG;
						tag_t *techspec_objects = NULLTAG;
						tag_t *VCTask = NULLTAG;

						tc_strtok(objectname, "_");
						VRRev = tc_strtok(NULL, "_");
						strncpy(VCnm,objectname,8);
						//VRRev=tc_strtok(NULL, ";");
						tc_strcat(VCnm,"R");
						printf( "\n ChkVCfrmSVRAvail:VC Name created from SVR is [%s] & rev is [%s] BUInfo1:[%s]",VCnm,VRRev,BUInfo1); fflush(stdout);
						///////
						tag_t rev_tag = NULLTAG;
						tag_t Child_All_Rev = NULLTAG;
						tag_t objTypTag = NULLTAG;
						char*   ObjTyp= NULL;
						if(tc_strcmp(VRRev,"NR")!=0)
						{
							Child_All_Rev= t5GetItemRevison(VCnm);
							if(Child_All_Rev==NULLTAG)
							{
								printf("\n ChkVCfrmSVRAvail:Child_All_Rev is NULL.\n");fflush(stdout);
							}
							else
							{
								if(ITEM_ask_latest_rev(Child_All_Rev, &rev_tag));

								if(TCTYPE_ask_object_type(rev_tag,&objTypTag));
								if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
								printf("\n ChkVCfrmSVRAvail: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);
								
								if (rev_tag != NULLTAG)
								{
									if(AOM_UIF_ask_value(rev_tag,"item_revision_id",&VCRevG));
									printf( "\n ChkVCfrmSVRAvail: VCRevG [%s]",VCRevG); fflush(stdout);
									seq=tc_strtok(VCRevG, ";");
									printf( "\n ChkVCfrmSVRAvail:VCRevG Found and which is [%s] & seq is[%s]",VCRevG,seq); fflush(stdout);
									printf( "\n ChkVCfrmSVRAvail:VC seq is [%s] & VRRev is [%s]",seq,VRRev); fflush(stdout);
									if (tc_strcmp(seq,VRRev)==0)
									{
										printf( "\n ChkVCfrmSVRAvail:VC Revision is already present is system."); fflush(stdout);
										//Check VC is attached to task or not. if not give error.
										if(tc_strstr(BUInfo1,"B003")==NULL)
										{
											if(GRM_find_relation_type("CMHasSolutionItem", &part2tsk_rel_typ));
											if (part2tsk_rel_typ!=NULLTAG)
											{
												printf("\n ChkVCfrmSVRAvail--> for part2tsk_rel_typ.");fflush(stdout);
												if(GRM_list_primary_objects_only(rev_tag,part2tsk_rel_typ,&nTskCnt,&VCTask));
												printf("\n ChkVCfrmSVRAvail: for nTskCnt:%d.",nTskCnt);fflush(stdout);
												if (nTskCnt == 0)
												{
													//VC not attached to task
													printf("\n ChkVCfrmSVRAvail-->ERROR: VC not attached to task.");fflush(stdout);
													EMH_clear_errors();
													//EMH_store_error_s1(EMH_severity_error,PLM_error,"Run BOM process running multiple times, VC Revision is already present is system.\nPlease query Vehicle in system, ensure BOM and attach vehicle to task in 'Solution' folder.\n If any validation issue, system will give pop-up message to user.\nIf still any query, Kindly raise ticket in TMS under DML workflow category. ");
													printf("\n ChkVCfrmSVRAvail:Run BOM process running multiple times, VC Revision is already present is system\n");fflush(stdout);
													return 0;
												}
												else
												{
													SVRFlag=1;
													printf("\n ChkVCfrmSVRAvail-->PASS: VC is attached to task.:SVRFlag:%d",SVRFlag);fflush(stdout);
													//return 1;
												}
											}
										}
										else
										{
											EMH_clear_errors();
											//EMH_store_error_s1(EMH_severity_error,PLM_error,"Run BOM process running multiple times, VC Revision is already present is system.\nPlease query Vehicle in system, ensure BOM and attach vehicle to task in 'Solution' folder.\n If any validation issue, system will give pop-up message to user.\nIf still any query, Kindly raise ticket in TMS under DML workflow category. ");
											printf("\n ChkVCfrmSVRAvail:Run BOM process running multiple times, VC Revision is already present is system\n");fflush(stdout);
											return 0;
										}
									}
									else
									{
										printf("\n ChkVCfrmSVRAvail: Sequese of [%s] is not found",VRRev);fflush(stdout);
										if(tc_strstr(BUInfo1,"B002")==NULL)
										{
											GRM_find_relation_type("T5_VCSpec", &relation_type_tag);
											GRM_list_secondary_objects_only(rev_tag,relation_type_tag,&tscount,&techspec_objects);
											if (tscount == 0)
											{
												printf( "\n ChkVCfrmSVRAvail:Previous VC Revision is not having Tech Spec attached to it."); fflush(stdout);
												EMH_clear_errors();
												//EMH_store_error_s1(EMH_severity_error,PLM_error,"Latest Released VC Revision is not having Tech Spec attached to it. Kindly raise ticket in TMS ");
												printf("\n ChkVCfrmSVRAvail::Latest Released VC Revision is not having Tech Spec attached to it.\n");fflush(stdout);
												return 0;
											}
										}
									}
								}
								else
								{	
									printf( "\n ChkVCfrmSVRAvail:Latest VC Re Tag not found.[%s]",VCnm); fflush(stdout);
									EMH_clear_errors();
									//EMH_store_error_s1(EMH_severity_error,PLM_error,"Latest VC revision not found created, Kindly raise ticket in TMS");
									printf("\n Latest VC Revision not found for Creation, Kindly raise ticket in TMS\n");fflush(stdout);
									return 0;
								}
							}
						}
						else
						{
							printf("\n SVR Rev is NR======> [%s]",VRRev);fflush(stdout);
							Child_All_Rev= t5GetItemRevison(VCnm);
							if(Child_All_Rev !=NULLTAG)
							{
								printf("\n ChkVCfrmSVRAvail:Child_All_Rev is Not NULL of NR SVR. VC Revision is already present is system.\n");fflush(stdout);
								if(tc_strstr(BUInfo1,"B004")==NULL)
								{
									if(GRM_find_relation_type("CMHasSolutionItem", &part2tsk_rel_typ));
									if (part2tsk_rel_typ!=NULLTAG)
									{
										printf("\n ChkVCfrmSVRAvail--> for part2tsk_rel_typ.");fflush(stdout);
										if(GRM_list_primary_objects_only(Child_All_Rev,part2tsk_rel_typ,&nTskCnt,&VCTask));
										printf("\n ChkVCfrmSVRAvail--> for nTskCnt:%d.",nTskCnt);fflush(stdout);
										if (nTskCnt == 0)
										{
											EMH_clear_errors();
											//EMH_store_error_s1(EMH_severity_error,PLM_error,"Run BOM process running multiple times, VC Revision is already present is system.\nPlease query Vehicle in system, ensure BOM and attach vehicle to task in 'Solution' folder.\n If any validation issue, system will give pop-up message to user.\nIf still any query, Kindly raise ticket in TMS under DML workflow category. ");
											printf("\n ChkVCfrmSVRAvail:Run BOM process running multiple times, VC Revision is already present is system\n");fflush(stdout);
											return 0;	
										}
										else
										{
											SVRFlag =1;
											printf("\n ChkVCfrmSVRAvail: NR VC is attached to task.SVRFlag:%d\n",SVRFlag);fflush(stdout);
											//return 1;
										}
									}
								}
							}
							else
							{
								printf("\nNeed not to check present VC in system, SVR Rev is NR: [%s]",VRRev);fflush(stdout);
							}
						}
						printf("\ncalling ChkVCfrmSVRAvail fun Completed vcissue [%d]",vcissue);fflush(stdout);
					}
					else
					{
						printf("\ncalling ChkVCfrmSVR fun Starting");fflush(stdout);
						vcissue = ChkVCfrmSVR(objectname);
						printf("\ncalling ChkVCfrmSVR fun Completed vcissue [%d]",vcissue);fflush(stdout);
						if (vcissue != 0)
						{
							SVRFlag=1;
							printf("\ncheck vcissue [%d]",vcissue);fflush(stdout);
							return 0;
						}
					}
				}
				printf("\nCheck SVRFlag [%d]",SVRFlag);fflush(stdout);
				if(SVRFlag ==0)
				{
					printf("\nVcpresentcheck Sucessfull...continue to next check");fflush(stdout);
					if(AOM_ask_value_string(rev,"object_desc",&objectdesc));
					strcpy(TempVal,objectname);

					printf( " ----INside platform "); fflush(stdout);

					if ( primary1 !=NULLTAG )
					{
						CALLAPI ( PS_find_view_type( "view", &view_type ));
						//printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

						if ( view_type != NULLTAG )
						{
							CALLAPI ( ITEM_ask_item_of_rev( primary1, &item ));
							CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

							bom_view = bom_views[0];
						}
						else
							printf("\n vc_release--1.View not found check.......\n"); fflush(stdout);
					}

					if ( bom_view != NULLTAG )
					{
						printf(" vc_release--1.before BOM_create_window..\n");	fflush(stdout);

						CALLAPI ( BOM_create_window( &bom_window ));
						//CALLAPI(CFM_find( "ERC release and above", &rule ))
						CALLAPI(CFM_find( "Latest Working", &rule ))
						CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
						CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));

						printf ("- vc_release--1.rule count %d \n",rulefound);fflush(stdout);

						if (rulefound > 0)
						{
							close_tag = closurerule[0];
							printf (" vc_release--1.closure rule found \n");fflush(stdout);
							// MEM_free(tags_found);
						}

						CALLAPI(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));

						CALLAPI(BOM_set_window_pack_all(bom_window, FALSE));
						CALLAPI(BOM_set_window_top_line( bom_window, NULLTAG, primary1, NULLTAG, &top_line ));
						printf(" vc_release--1.After BOM_set_window_top_line..\n");fflush(stdout);

						//CALLAPI(BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
						if ( BOM_window_ask_variant_rules( bom_window,&BOmvarcnt2,&bom_variant_rule ));
						printf(" vc_release--1.BOM_window_ask_variant_rule..\n");fflush(stdout);

                        if(BOmvarcnt2>0)
						{
						CALLAPI(TCTYPE_ask_object_type(bom_variant_rule[0],&objTypeTag));
						CALLAPI(TCTYPE_ask_name2(objTypeTag,&type_name));
						}

						CALLAPI ( ITEM_ask_rev_variants ( primary1, &e_block ));
						printf(" vc_release--1.ITEM_ask_rev_variants..\n");fflush(stdout);

						if(top_line!=NULLTAG)
						{
							CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
							printf("\n vc_release--1.Before setting option n_lines: %d and Item_ID_str :%s\n", n_lines,Item_ID_str);

							CALLAPI(BOM_window_hide_unconfigured(bom_window));
							CALLAPI(BOM_window_show_variants(bom_window));

							//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config))   ;
							//if(BOM_variant_config_apply (bom_variant_config))   ;

							//if(BOM_variant_rule_apply(primary1))   ;
							printf("\n vc_release--1.After inside bom_window-----\n"); fflush(stdout);
							CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&rev))   ;
							printf("\n vc_release--1.After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

							//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
							CALLAPI(BOM_window_hide_variants(bom_window))   ;

							CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
							printf("\n vc_release--n_lines: [%d]  ",n_lines); fflush(stdout);

							if (n_lines >0)
							{
								structcount=0;
								for (p1=0;p1<n_lines ;p1++ )
								{
									if(Childobject) Childobject=NULLTAG;

									Childobject=lines[p1];

									CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
									//printf("\n vc_release--p1: [%d]  child_item_id: %s",p1,child_item_id); fflush(stdout);
									printf("\n vc_release--p1: [%d]  ",p1); fflush(stdout);

									CALLAPI(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));

									//printf("\tBOM-n_lines2 : %d",n_lines2);fflush(stdout);

									structcount++;

									tc_strcpy(childstr[p1].parent_part,child_item_id);
									childstr[p1].child=n_lines2;
									printf("\t Part no IS: %s  n_lines2: %d ",childstr[p1].parent_part,childstr[p1].child);fflush(stdout);

									//ITK ( VOO_show_wso( Childobject ));
								}
							}
						}
						else
						{
							EMH_clear_errors();
							//EMH_store_error_s1(EMH_severity_error,PLM_error,"Structure is not present under Platform. Please raise ticket in TMS TCUA-DML.");
							printf("\n vc_release--Structure is not present under Platform in TCUA [%s] ?? \n\n",platformName);fflush(stdout);
							return 0;
						}

						//start
						CALLAPI(CFM_find( "ERC release and above", &rule ))
						//CALLAPI(CFM_find( "Latest Working", &rule ))
						CALLAPI(BOM_set_window_config_rule( bom_window, rule ));

						memset( &option_value_dictionary, 0, sizeof ( option_value_dictionary ) );

						CALLAPI ( BOM_variant_rule_ask_options( bom_variant_rule[0], &v_entr, &options, &option_revs ) )
						printf("\n vc_release--No of Option values in the rule:%d\n",v_entr);fflush(stdout);

						if ( top_line!=NULLTAG )
						{
							printf("\n vc_release--%s %s: inside topline Revision is \n", VOO_prog, VOO_time_stamp() ); fflush(stdout);

							fprintf( stderr, "\n print rev first .\n");
							CALLAPI ( VOO_show_wso( primary1 )) ;

							// CALLAPI ( ITEM_find_item( ItemId, &master_tag ));
							fprintf(stderr, "\n print Master second .\n");

							CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
							printf("\n vc_release--1.LLlast Before setting option n_lines1: %d \n", n_lines1);

							if(bom_window != NULLTAG)
							{
								printf("\n vc_release--before inside bom_window-----\n"); fflush(stdout);
								CALLAPI(BOM_window_hide_unconfigured(bom_window))   ;
								CALLAPI(BOM_window_show_variants(bom_window))   ;
								//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config))   ;
								//if(BOM_variant_config_apply (bom_variant_config))   ;

								//if(BOM_variant_rule_apply(primary1))   ;
								printf("\n vc_release--After inside bom_window-----\n"); fflush(stdout);
								CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&rev))   ;
								printf("\n vc_release--After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

								//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
								CALLAPI(BOM_window_hide_variants(bom_window))   ;
								CALLAPI(BOM_window_ask_is_modified(bom_window,&modB))   ;
								if(modB)
								{
									fprintf( stderr, "\n vc_release--modified bom window:..\n");fflush(stdout);
								}
								else
								{
									fprintf( stderr, "\n vc_release--not modfiifed ..\n");fflush(stdout);
								}

								CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));

								CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
								if(relation_dep != NULLTAG)
								{
									printf("\n\t vc_release--Variant ConfigContext relation found......");	fflush(stdout);
								}

								CALLAPI(GRM_list_secondary_objects_only(item,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
								printf("\n\t vc_release--Configuration Context count is : %d",countConfigCtx);

								if(countConfigCtx>0)
								{
									ConfigCtx=ConfigCtxSecObject[0];

									CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
									CALLAPI(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType));
									printf( "\n\t vc_release--Config relation Config_CtxType :%s ..",Config_CtxType);

									CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
									printf("\n\t vc_release--SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

									CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
									printf("\n\t vc_release--SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

									if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag));
									printf("\n\t vc_release--After Cfg0OptionFamiliesFromIDs : QRY_find2");fflush(stdout);

									if (queryTag != NULLTAG)
									{
										printf("\t vc_release--Found Query");fflush(stdout);
									}else
									{
										printf("\t vc_release--Not Found Query");fflush(stdout);
									}

									qry_values[0] = SmCrIDContext;

									if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &OptionValue));
									printf("\n\t vc_release--resultCount : %d\n", resultCount); fflush(stdout);
								}

								printf("\n vc_release--2.LLlast Before setting option n_lines1: [%d] mulmodule is start..[%s] \n", n_lines1,MulModule); fflush(stdout);

								EMH_clear_errors();

								tag_t CtrObjArchQryTag = NULLTAG;
								tag_t CtrObjT3Z01Tag = NULLTAG;
								tag_t CtrObjBypassTag = NULLTAG;

								tag_t *ArchNodeCtrObj = NULLTAG;
								tag_t *T3Z01CtrObj = NULLTAG;
								tag_t *BypassCtrObj = NULLTAG;

								char *QryEntry[2] = {"SYSCD","SUBSYSCD"};
								char *QryEntry3[3] = {"SYSCD","SUBSYSCD","Information-1"};

								char **ArchrNodeyEntryValue = (char **) MEM_alloc(50 * sizeof(char *));
								char **BypassEntryValue = (char **) MEM_alloc(50 * sizeof(char *));
								char **T3Z01EntryValue = (char **) MEM_alloc(50 * sizeof(char *));

								char *CtrlInfo11 =NULL;
								char *CtrlInfo22 =NULL;
								char *CtrlInfo33 =NULL;
								char *strinfo1 =NULL;
								char *strinfo2 =NULL;
								char *strinfo3 =NULL;
								char *strinfo4 =NULL;
								char *strinfo6 =NULL;
								char *BypassInfo1 =NULL;
								char *BypassInfo2 =NULL;

								int ArchNodeQryC = 0, BypassCtrlCnt=0, ModuleAvailFlag=0, info7T3Z01Found=0, ReplacemntModT3Z01Cnt=0;
								int CtrlQryCnt=0,  BypassFlag=0;

								CALLAPI(QRY_find2("Control Objects...", &CtrObjArchQryTag));

								if (CtrObjArchQryTag != NULLTAG)
								{
									printf("\n vc_release--CtrObjArchQryTag Found... "); fflush(stdout);

									ArchrNodeyEntryValue[0] = "AltrozArchNode"; //SYSCD
									ArchrNodeyEntryValue[1] = "AltrozArchNode"; //SUBSYSCD
									CALLAPI(QRY_execute(CtrObjArchQryTag, 2, QryEntry, ArchrNodeyEntryValue, &ArchNodeQryC, &ArchNodeCtrObj));
									printf("\n vc_release--CtrObjArchQryTag Found--Executed Qry-1... "); fflush(stdout);

									T3Z01EntryValue[0] = "BaseT3Z01Alternate"; //SYSCD
									T3Z01EntryValue[1] = "AlternateModInVeh";  //SUBSYSCD
									CALLAPI(QRY_execute(CtrObjArchQryTag, 2, QryEntry, T3Z01EntryValue, &CtrlQryCnt, &T3Z01CtrObj));
									printf("\n vc_release--CtrObjArchQryTag Found--Executed Qry-2... "); fflush(stdout);

									BypassEntryValue[0] = "ercbypass";	//SYSCD=ercbypass
									BypassEntryValue[1] = DMLNo;		//SUBSYSCD=dmlno
									BypassEntryValue[2] = objectname;	//Information-1=SVR_number
									CALLAPI(QRY_execute(CtrObjArchQryTag, 3, QryEntry3, BypassEntryValue, &BypassCtrlCnt, &BypassCtrObj));
									printf("\n vc_release--CtrObjArchQryTag Found--Executed Qry-3... "); fflush(stdout);
								}

								printf("\n vc_release--Control Object CtrlQryCnt:--> [%d] ",CtrlQryCnt); fflush(stdout);

								if(CtrlQryCnt>0)
								{
									CALLAPI(AOM_ask_value_string(T3Z01CtrObj[0],"t5_Userinfo1",&CtrlInfo11));
									CALLAPI(AOM_ask_value_string(T3Z01CtrObj[0],"t5_Userinfo2",&CtrlInfo22));
									CALLAPI(AOM_ask_value_string(T3Z01CtrObj[0],"t5_Userinfo3",&CtrlInfo33));

									printf("\n vc_release--BaseT3Z01Alternate, T3Z01-Info1=> [%s] ",CtrlInfo11); fflush(stdout);
									printf("\n vc_release--BaseT3Z01Alternate, Alternate-Addresses-Info2=> [%s] ",CtrlInfo22); fflush(stdout);
									printf("\n vc_release--BaseT3Z01Alternate, CtrlInfo33=> [%s] ",CtrlInfo33); fflush(stdout);

								}

								printf("\n vc_release--Control Object AltrozArchNode count:--> [%d] ",ArchNodeQryC); fflush(stdout);

								if(ArchNodeQryC>0)
								{
									CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo1",&strinfo1));
									CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo2",&strinfo2));
									CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo3",&strinfo3));
									CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo4",&strinfo4));
									CALLAPI(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo6",&strinfo6));

									printf("\n vc_release--AltrozArchNode, DR-Info6=> [%s] ",strinfo6); fflush(stdout);
									printf("\n vc_release--AltrozArchNode, Address-Info1=> [%s] ",strinfo1); fflush(stdout);
									printf("\n vc_release--AltrozArchNode, Address-Info2=> [%s] ",strinfo2); fflush(stdout);
									printf("\n vc_release--AltrozArchNode, Address-Info3=> [%s] ",strinfo3); fflush(stdout);
									printf("\n vc_release--AltrozArchNode, Address-Info4=> [%s] ",strinfo4); fflush(stdout);
								}

								printf("\n vc_release--Control Object BypassCtrlCnt:--> [%d] ",BypassCtrlCnt); fflush(stdout);
								if(BypassCtrlCnt>0)
								{
									CALLAPI(AOM_ask_value_string(BypassCtrObj[0],"t5_Userinfo1",&BypassInfo1)); //VC or SVR_no
									CALLAPI(AOM_ask_value_string(BypassCtrObj[0],"t5_Userinfo2",&BypassInfo2)); //Module addresses

									printf("\n vc_release--ercbypass, BypassInfo1=> [%s] ",BypassInfo1); fflush(stdout);
									printf("\n vc_release--ercbypass, BypassInfo2=> [%s] ",BypassInfo2); fflush(stdout);
								}

								if (n_lines1 >0)
								{
									//MulModule = (char *)MEM_alloc (1024 * sizeof(char));
									tc_strcpy(MulModule,"");
									tc_strcpy(NoModule,"");
									tc_strcpy(T3Z01NoModule,"");
									tc_strcpy(NoAlternateModule,"");
									tc_strcpy(RevMisMatch,"");

									info7T3Z01Found=0;
									ReplacemntModT3Z01Cnt=0;

									for (p3=0;p3<n_lines1 ;p3++ )
									{
										if(Childobject1) Childobject1=NULLTAG;

										Childobject1=lines[p3];

										CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id1 ));
										CALLAPI(AOM_ask_value_string(Childobject1, "bl_item_item_id", &Arch_item_id ));
										//fprintf( stderr, " child_item_id ..:%s\n",child_item_id);

										CALLAPI(ITEM_find_item(Arch_item_id,&ArchTag));
										if (ArchTag != NULLTAG)
										{
											CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));
											CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));
											CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleName",&sModuleName));
											CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModule",&sArchModule));
										}

										CALLAPI(BOM_line_ask_child_lines(Childobject1, &n_lines3, &lines3));

										printf("\n\n vc_release--p3: [%d] Arch: [%s]-->ModuleCnt:[%d] ArchName:[%s] ArchModule:[%s]",p3,child_item_id1,n_lines3,sModuleName,sArchModule);fflush(stdout);
										printf(" child_item_no=[%d]\n",n_lines3);fflush(stdout);

										if (n_lines3 >0)
										{
											for (p34=0;p34<n_lines3 ;p34++ )
											{
												if(Childobject33) Childobject33=NULLTAG;

												Childobject33=lines3[p34];

												CALLAPI(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
												//CALLAPI(BOM_line_look_up_attribute ("bl_rev_last_release_status",&IntAtr5));
												//CALLAPI(BOM_line_ask_attribute_string(Childobject33, IntAtr5, &child_bl_formula23));
												
												if( AOM_ask_displayable_values(Childobject33,"bl_rev_last_release_status",&strcnt1,&child_bl_formula23));

												if((tc_strstr(child_bl_formula23[0],"ERC Released")==NULL) || (tc_strstr(child_bl_formula23[0],"T5_LcsErcRlzd")==NULL) )
												{
													fprintf( stderr, "\n 1.Valid release status \n");
													//Function call for platform based moduler BOM validation.
												}
												else
												{
													EMH_clear_errors();
													EMH_store_error_s3(EMH_severity_error,ITK_errErr1,"These ",child_item_id15," does not have ERC Released status");

													printf("\n  vc_release--These [%s] does not have ERC Released status.... hence skipping..\n",child_item_id15);fflush(stdout);
													printf("\n ---------------------A.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

													return ITK_errErr1;
												}

												if (p34>0)
												{
													if (tc_strcmp(MulChild,child_item_id15)==0)
													{
														tc_strcpy(MulChild,"");
														tc_strcat(MulChild,child_item_id15);
														continue;
													}
													else
													{
														errorflag2=errorflag2+1;
														break;
													}
												}

												tc_strcpy(MulChild,"");
												tc_strcat(MulChild,child_item_id15);

												printf("\n  vc_release--p34: [%d]---inside diff child: [%s] \n",p34,MulChild);fflush(stdout);

												//CALLAPI ( ITEM_ask_latest_rev( parent_master, &VCrev ));
												//CALLAPI (WSOM_ask_release_status_list(VCrev,&status_count,&status_list));

												//Checking DR-validation for Modules:start.
												CALLAPI(AOM_ask_value_string(Childobject33, "bl_Design_t5_RevPartType", &Obj_PrtTyp));
												CALLAPI(AOM_ask_value_string(Childobject33, "bl_Design Revision_t5_ProjectCode", &PrtProjj));
												CALLAPI(AOM_ask_value_string(Childobject33, "bl_Design Revision_t5_PartStatus", &PrtDRstus));
												printf("\n Part: %s type: %s project: %s PrtDRstus: %s DML DR: %s Relstatus: %s",child_item_id15,Obj_PrtTyp,PrtProjj,PrtDRstus,DMLDRstatus,child_bl_formula23[0]);fflush(stdout);

												PRTDRStr=NULL;
												PRTSTVALU=0;

												PRTDRStr=subString(PrtDRstus, 2, 1);
												printf("\n vc_release--B.Part DR status: PRTDRStr: %s",PRTDRStr);fflush(stdout);

												PRTSTVALU=atoi(PRTDRStr);
												printf(" \t PRTSTVALU: %d ",PRTSTVALU);fflush(stdout);

												if((tc_strcmp(PrtProjj,"1111")==0)||(tc_strcmp(Obj_PrtTyp,"D")==0)||(tc_strcmp(Obj_PrtTyp,"DC")==0)||(tc_strcmp(Obj_PrtTyp,"DA")==0)||(tc_strcmp(Obj_PrtTyp,"IFD")==0)||(tc_strcmp(Obj_PrtTyp,"IM")==0))
												{
													printf("\t vc_release--B.Skipping dummy part: %s ",child_item_id15);fflush(stdout);
												}
												else
												{
													printf("\n In else---vc_release--B.GMD---");fflush(stdout);

													DRstusFlag=0;
													DRstusFlag = ChkFrstLvlModuleDRstus(child_item_id15,DMLSTVALUT);

													printf("\n vc_release--B.GMD::DRstusFlag: %d",DRstusFlag);fflush(stdout);

													if (DRstusFlag >0)
													{
														printf("\n vc_release--B.GMD::Released module part is OKKK.:%s ", child_item_id15);fflush(stdout);
													}
													else
													{
														//ADD PART NUMBER3.
														if ((add==10)||(add==20)||(add==30)||(add==40)||(add==50)||(add==60)||(add==70)||(add==80)||(add==90)||(add==100))
														{
															tc_strcat(ERCRelErrStrng,"\n");
														}
														tc_strcat(ERCRelErrStrng,child_item_id15);
														tc_strcat(ERCRelErrStrng,",");

														add++;

														printf("\n vc_release--B.Rel module part added to ERCRelErrStrng:%d:%s ",add, child_item_id15);fflush(stdout);
													}
												}
												//Checking DR-validation for Modules:start.
											}

											if(tc_strcmp(ERCRelErrStrng,"")!=0)
											{
												printf("\n vc_release--B.DR:ERRORRR.:%s", ERCRelErrStrng);fflush(stdout);
												if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
												{
													printf("\n CVBU_VC:P1:Function call for DR-status validation"); fflush(stdout);
													if(tc_strstr(BUInfo3,"P001")==NULL)
													{
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,ITK_err,"CVBU:Below mentioned modules should have DR-status equal or above than DML DR-status for any of the released revision.\n",ERCRelErrStrng);

														printf("\n vc_release--B.Mentioned modules should have DR-status equal or above than DML DR-status for any of the released revision==[%s] \n ",ERCRelErrStrng);fflush(stdout);
														printf("\n ---------------------C.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

														return ITK_err;
													}
												}
												else
												{
													if(tc_strstr(BUInfo3,"P001")==NULL)
													{
														printf("\n PVBU_VC:P2:Function call for DR-status validation."); fflush(stdout);
														EMH_clear_errors();
														EMH_store_error_s2(EMH_severity_error,ITK_err,"PVBU:Below mentioned modules should have DR-status equal or above than DML DR-status for any of the released revision.\n",ERCRelErrStrng);

														printf("\n vc_release--B.Mentioned modules should have DR-status equal or above than DML DR-status for any of the released revision==[%s] \n ",ERCRelErrStrng);fflush(stdout);
														printf("\n ---------------------C.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

														return ITK_err;
													}
												}
											}
										}

										//if (n_lines3 > 1)
										if ( (n_lines3>1) &&
											 ((tc_strstr(sModuleName,"TYRE RIM")==NULL) &&(tc_strstr(sArchModule,"TYRE RIM")==NULL))
										   )
										{
											printf("\n vc_release--B.mulmodule is before: %s child_item_id1: %s  ",MulModule,child_item_id1);fflush(stdout);

											tc_strcat(MulModule,"[");
											tc_strcat(MulModule,child_item_id1);
											tc_strcat(MulModule,"]");
											tc_strcat(MulModule,",");
											errorflag=errorflag+1;
											printf("\n vc_release--C......show error for mul....%d   mulmodule: %s  ",n_lines3,MulModule);fflush(stdout);
											//tc_strcpy(Fresh,MulModule);
											//printf("\n.....Fresh is after..%s\n",Fresh);fflush(stdout);
										}

										if((CtrlInfo11!=NULL)&&(sModuleAdrr!=NULL)&&(tc_strstr(CtrlInfo11,sModuleAdrr) != NULL)&&(n_lines3>0))
										{
											info7T3Z01Found=info7T3Z01Found+1;

											printf("\n\n\t sModuleAdrr:[%s]--info7T3Z01 module Found in BOM..[%d]",sModuleAdrr,n_lines3);fflush(stdout);
										}

										if (n_lines3 == 0)
										{
											ModuleAvailFlag=0;

											printf(" DMLDR: [%s] Arch-len: [%d] ",DMLDRstatusStr,tc_strlen(Arch_item_id));fflush(stdout);

											if (Arch_item_id!=NULL)
											{
												Arch_item_idStr=malloc(20);
												tc_strcpy(Arch_item_idStr,subString(Arch_item_id, tc_strlen(Arch_item_id)-6, tc_strlen(Arch_item_id)-1 ) ); //6=length of module address

												printf(" Arch_item_idStr: [%s]  sModuleAdrr:[%s] ",Arch_item_idStr,sModuleAdrr);fflush(stdout);

												///Module not from CtrlInfo11 and available in strinfo1 to strinfo4 only
												if((tc_strstr(CtrlInfo11,Arch_item_idStr) == NULL) && (
												   ((strinfo1 != NULL)&&(tc_strstr(strinfo1,Arch_item_idStr) != NULL)) ||
												   ((strinfo2 != NULL)&&(tc_strstr(strinfo2,Arch_item_idStr) != NULL)) ||
												   ((strinfo3 != NULL)&&(tc_strstr(strinfo3,Arch_item_idStr) != NULL)) ||
												   ((strinfo4 != NULL)&&(tc_strstr(strinfo4,Arch_item_idStr) != NULL))
												  ))
												{
													printf("\t--Found in control-Object ");fflush(stdout);
													ModuleAvailFlag=ModuleAvailFlag+1;
												}

												if ((info7T3Z01Found==0) && (tc_strstr(strinfo6,DMLDRstatusStr)!=NULL))
												{
													if ((CtrlInfo22 != NULL)&&(tc_strstr(CtrlInfo22,Arch_item_idStr) != NULL))
													{
														ReplacemntModT3Z01Cnt=ReplacemntModT3Z01Cnt+1;

														tc_strcat(T3Z01NoModule,Arch_item_idStr);
														tc_strcat(T3Z01NoModule,",");
													}
												}
												else if (info7T3Z01Found>0)
												{
													printf("\n\t vc_release--R......T3Z01 Found Found--- ");fflush(stdout);

													tc_strcpy(T3Z01NoModule,"");
													ReplacemntModT3Z01Cnt=0;
												}
											}

											printf("  ModuleAvailFlag: [%d]  info7T3Z01Found: [%d]  ReplacemntModT3Z01Cnt: [%d] ",ModuleAvailFlag,info7T3Z01Found,ReplacemntModT3Z01Cnt);fflush(stdout);

											if ((tc_strstr(strinfo6,DMLDRstatusStr)!=NULL)&&(ModuleAvailFlag>0)&&(DMLDRstatusStr != NULL)&&(strinfo6 != NULL))
											{
												BypassFlag=0;

												printf("\n vc_release-->1.BypassCtrlCnt: [%d] [%s]=[%s] [%s]==>",BypassCtrlCnt,objectname,BypassInfo1,BypassInfo2); fflush(stdout);

												if( (BypassCtrlCnt>0) &&
													((BypassInfo1 != NULL)&&(tc_strstr(objectname,BypassInfo1) != NULL))&&
													((BypassInfo2 != NULL)&&(tc_strstr(BypassInfo2,Arch_item_idStr) != NULL))
												)
												{
													BypassFlag=BypassFlag+1;
												}

												printf(" BypassFlag: [%d] ",BypassFlag);fflush(stdout);

												if (BypassFlag==0)
												{
													tc_strcat(NoModule,"[");
													tc_strcat(NoModule,Arch_item_id);
													tc_strcat(NoModule,"]");
													tc_strcat(NoModule,",");

													errorflag1=errorflag1+1;
													printf("\nvc_release--D......show error....for no mul....%d",n_lines3);fflush(stdout);
												}
											}
										}
										//ITK ( VOO_show_wso( Childobject ));
									}

									printf("\nvc_release--errorflag1:[%d]  errorflag:[%d]  errorflag2:[%d]  errorflag34:[%d]  info7T3Z01Found: [%d]",errorflag1,errorflag,errorflag2,errorflag34,info7T3Z01Found);fflush(stdout);

									if (errorflag1>0)
									{
										printf("\nvc_release--2.....show error....");fflush(stdout);

										tc_strcat(NoModule,"-->");
										tc_strcat(NoModule,objectname); //objectname=SVRName

										printf("\n vc_release--1.No module is present under ** [%s]  please verify the SVR.\n ",NoModule);fflush(stdout);
										printf("\n ---------------------F.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

										if ((CtrlInfo33 != NULL) && (tc_strstr(CtrlInfo33,"ON")!=NULL))
										{
											if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
											{
												printf("\n PV_VC:P2:Function call for platform based moduler BOM validation.."); fflush(stdout);
												if(tc_strstr(BUInfo3,"P002")==NULL)
												{
													EMH_clear_errors();
													EMH_store_error_s3(EMH_severity_information,ITK_errErr,"CVBU: No module is present under **",NoModule," please verify the SVR.");
													return ITK_Prjerr;
												}
											}
											else
											{
												printf("\n PV_VC:P2:Function call for platform based moduler BOM validation.."); fflush(stdout);
												if(tc_strstr(BUInfo3,"P002")==NULL)
												{
													EMH_clear_errors();
													EMH_store_error_s3(EMH_severity_information,ITK_errErr,"PVBU: No module is present under **",NoModule," please verify the SVR.");
													return ITK_Prjerr;
												}
											}
										}
										else
										{
											printf("\n vc_release--1.No mandatory module present under ---Skipping valiadtion....???? \n\n");fflush(stdout);
										}
									}
									if ((info7T3Z01Found==0)&&(tc_strstr(strinfo6,DMLDRstatusStr)!=NULL))
									{
										printf("\nvc_release--3--T3Z01.....show error....tc_strlen(T3Z01NoModule): [%d] ReplacemntModT3Z01Cnt: [%d]  T3Z01NoModule: [%s]",tc_strlen(T3Z01NoModule),ReplacemntModT3Z01Cnt,T3Z01NoModule);fflush(stdout);

										if ((tc_strlen(T3Z01NoModule)>0)&&(ReplacemntModT3Z01Cnt>0))
										{
											if (BypassCtrlCnt>0)
											{
												printf("\n vc_release-->2.BypassCtrlCnt: [%d] [%s]=[%s] BypassInfo2:[%s]==>",BypassCtrlCnt,objectname,BypassInfo1,BypassInfo2); fflush(stdout);

												tc_strcpy(NoAlternateModule,"");

												char *tokenStr = strtok(T3Z01NoModule, ",");

												while (tokenStr != NULL)
												{
													BypassFlag=0;

													printf("\n   Tokenized--info8==tokenStr: [%s] ",tokenStr); fflush(stdout);

													if( ((BypassInfo1 != NULL)&&(tc_strstr(objectname,BypassInfo1) != NULL))&&
														((BypassInfo2 != NULL)&&(tc_strstr(BypassInfo2,tokenStr) != NULL))
													  )
													{
														BypassFlag=BypassFlag+1;
													}

													printf(" BypassFlag= [%d] ",BypassFlag);fflush(stdout);

													if (BypassFlag==0)
													{
														//if(tc_strstr(CtrlInfo22,tokenStr)==NULL)
														//{
															tc_strcat(NoAlternateModule,tokenStr);
															tc_strcat(NoAlternateModule,"; ");
														//}
													}

													tokenStr = strtok(NULL, ",");
												}
											}
											else
											{
												tc_strcpy(NoAlternateModule,T3Z01NoModule);
											}

											printf("\n vc_release--R......show error....for [%d] CtrlInfo33: [%s] NoAlternateModule: [%s] ",tc_strlen(NoAlternateModule),CtrlInfo33,NoAlternateModule); fflush(stdout);

											if (tc_strlen(NoAlternateModule)>0)
											{
												tc_strcat(NoAlternateModule,"-->");
												tc_strcat(NoAlternateModule,objectname); //objectname=SVRName

												printf("\n vc_release--1.No Alternate Modules of T3Z01 present under ** [%s], please verify the SVR.\n ",NoAlternateModule);fflush(stdout);
												printf("\n ---------------------R.vc_release function ended with above data error---------------------\n");fflush(stdout);

												if ((CtrlInfo33 != NULL) && (tc_strstr(CtrlInfo33,"ON")!=NULL))
												{
													if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
													{
														printf("\n CV_VC:P1:Function call for platform based moduler BOM validation.."); fflush(stdout);
														if(tc_strstr(BUInfo3,"P003")==NULL)
														{
															EMH_clear_errors();
															EMH_store_error_s3(EMH_severity_information,ITK_errErr,"CVBU:No Replacevment Modules of T3Z01 is present under **",NoAlternateModule," please verify the SVR.");
															return ITK_Prjerr;
														}
													}
													else
													{
														printf("\n PV_VC:P1:Function call for platform based moduler BOM validation.."); fflush(stdout);
														if(tc_strstr(BUInfo3,"P003")==NULL)
														{
															EMH_clear_errors();
															EMH_store_error_s3(EMH_severity_information,ITK_errErr,"PVBU: No Replacevment Modules of T3Z01 is present under **",NoAlternateModule," please verify the SVR.");
															return ITK_Prjerr;
														}
													}
												}
												else
												{
													printf("\n vc_release--1.No Replacevment Modules of T3Z01 ---Skipping valiadtion....???? \n\n");fflush(stdout);
												}
											}
										}
									}
									//if ((errorflag>0) && (errorflag1>0) && (errorflag2>0))
									else if ((errorflag>0) && (errorflag2>0))
									{
										printf("\n vc_release--B.....child_item_id1 show error....length :%d and value : %s ",tc_strlen(child_item_id1),child_item_id1);fflush(stdout);
										printf("\n vc_release--B.....show error....length :%d and value : %s ",tc_strlen(MulModule),MulModule);fflush(stdout);
										MulModule[1899] = '\0';
										//printf("\n.....show error....length :%d and value fresh : %s",tc_strlen(Fresh),Fresh);fflush(stdout);
										if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
										{
											printf("\n CV_VC:P4:Function call for More than One module is present under validation.."); fflush(stdout);
											if(tc_strstr(BUInfo3,"P004")==NULL)
											{
												EMH_clear_errors();
												EMH_store_initial_error_s3(EMH_severity_error,ITK_Prjerr,"CVBU:More than One module is present under ",MulModule," please correct the SVR");
												return ITK_Prjerr;
											}
										}
										else
										{
											printf("\n PV_VC:P1:Function call for More than One module is present under validation.."); fflush(stdout);
											if(tc_strstr(BUInfo3,"P004")==NULL)
											{
												EMH_clear_errors();
												EMH_store_initial_error_s3(EMH_severity_error,ITK_Prjerr,"PVBU:More than One module is present under ",MulModule," please correct the SVR");
												return ITK_Prjerr;
											}
										}
		
									}
									if ((errorflag>0) && (errorflag1==0))
									{
										printf("\nvc_release--1.....show error....");fflush(stdout);
										if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
										{
											printf("\n CV_VC:P5:Function call for More than One module is present under validation.."); fflush(stdout);
											if(tc_strstr(BUInfo3,"P005")==NULL)
											{
												EMH_clear_errors();
												EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"CVBU:More than One module is present under ",MulModule," please correct the SVR");
												return ITK_Prjerr;
											}
										}
										else
										{
											printf("\n PV_VC:P5:Function call for More than One module is present under validation.."); fflush(stdout);
											if(tc_strstr(BUInfo3,"P005")==NULL)
											{
												EMH_clear_errors();
												EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"PVBU: More than One module is present under ",MulModule," please correct the SVR");
												return ITK_Prjerr;
											}
										}

										printf("\n vc_release--1.More than One module is present under [%s]  please correct the SVR.\n ",MulModule);fflush(stdout);
										printf("\n ---------------------E.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

										//EMH_store_error_s3(EMH_severity_error,ITK_errErr,"No module is present under ",NoModule," please verify the SVR");
										//return ITK_errErr;

									}
									//if ((errorflag==0) && (errorflag1>0))
									//{
									//	printf("\nvc_release--2.....show error....");fflush(stdout);
									//	EMH_clear_errors();
									//	//EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"More than One module is present under ",MulModule," please correct the SVR");
									//	EMH_store_error_s3(EMH_severity_information,ITK_errErr,"No module is present under **",NoModule," please verify the SVR");
									//
									//	printf("\n vc_release--1.No module is present under ** [%s]  please verify the SVR.\n ",NoModule);fflush(stdout);
									//	printf("\n ---------------------F.vc_release function ended with above data error---------------------\n\n");fflush(stdout);
									//	//return ITK_errErr;
									//	//return ITK_Prjerr;
									//}
									if ((errorflag34>0) && ((tc_strcmp(DMLDRstatus,"DR3")==0) || (tc_strcmp(DMLDRstatus,"DR4")==0) || (tc_strcmp(DMLDRstatus,"DR5")==0)))
									{
										printf("\nvc_release--3.....show error....");fflush(stdout);
										EMH_clear_errors();
										//EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"More than One module is present under ",MulModule," please correct the SVR");
										//EMH_store_error_s3(EMH_severity_information,ITK_errErr,"No released module is present under ",RevMisMatch," please verify the SVR");

										printf("\n ---------------------G.vc_release function ended with above data error---------------------\n\n");fflush(stdout);

										//return ITK_errErr;
										//return ITK_Prjerr;
									}
								}
							}
							else
							{
								fprintf( stderr, "\n vc_release--B.no bom window found here \n");
								if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
								{
									printf("\n PV_VC:P1:Function call for Structure not found validation.."); fflush(stdout);
									if(tc_strstr(BUInfo3,"P006")==NULL)
									{
										EMH_clear_errors();
										//EMH_store_error_s1(EMH_severity_error,PLM_error,"Structure not found for VC. Please raise ticket in TMS TCUA-DML.");
										printf("\n vc_release--Structure not found for VC in TCUA [%s] ?? \n\n",platformName);fflush(stdout);
										return 0;
									}
								}
								else
								{
									printf("\n PV_VC:P1:Function call for Structure not found validation.."); fflush(stdout);
									if(tc_strstr(BUInfo3,"P006")==NULL)
									{
										EMH_clear_errors();
										//EMH_store_error_s1(EMH_severity_error,PLM_error,"Structure not found for VC. Please raise ticket in TMS TCUA-DML.");
										printf("\n vc_release--Structure not found for VC in TCUA [%s] ?? \n\n",platformName);fflush(stdout);
										return 0;
									}
								}
							}

							//break;
						} //end of condn if(top_line!=NULLTAG)
					} //end of condn if ( bom_view != NULLTAG )

					errorflag4=0;

					printf("\n\n vc_release--VCItemId := %s ---------------------------->", TempVal); fflush(stdout);

					VehName=(char *) MEM_alloc(20);

					itemId12 = tc_strtok(TempVal,"_");
					RevId=tc_strtok(NULL,"_");

					itemId123=subString(itemId12,0,8);
					itemId1234=subString(itemId12,0,4);
					itemId12345=subString(itemId12,11,1);

					tc_strcpy(VehName,"");
					tc_strcpy(VehName,itemId123);
					tc_strcat(VehName,itemId12345);

					printf("\n vc_release--itemId12: [%s]  ritemId1234: [%s] ",itemId12,itemId1234); fflush(stdout);
					//printf("\n rev_type_tag Tag Found.");

					const char **attrs = (const char **) MEM_alloc(2 * sizeof(char *));
					const char **values = (const char **) MEM_alloc(2 * sizeof(char *));

					attrs[0] ="item_id";
					attrs[1] ="object_type";

					values[0] = (char *)itemId12;
					values[1] = "Design";

					CALLAPI(ITEM_find_items_by_key_attributes(2,attrs, values, &n_tags_found, &tags_found));

					MEM_free(attrs);
					MEM_free(values);

					printf( "\n vc_release--VC found count: %d ",n_tags_found); fflush(stdout);

					//CALLAPI(ITEM_find_item(itemId12, &parent_master1))

					if (n_tags_found == 0)
					{
						errorflag4=errorflag4+1;
					}
					printf( "\t errorflag4: %d ",errorflag4); fflush(stdout);

					if (errorflag4>0)
					{
						TCTYPE_find_type("Design Revision", NULL, &rev_type_tag);
						if(rev_type_tag!= NULLTAG)
						{
							printf("\n vc_release--1.rev_type_tag Tag Found."); fflush(stdout);
						}
						TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
						AOM_set_value_string(rev_create_input_tag, "object_name", itemId12);
						AOM_set_value_string(rev_create_input_tag, "object_desc", objectdesc);
						AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR;1");
						CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_ProjectCode", itemId1234));
						CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_DesignGrp", "00"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartType","VC"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DocRemarks","NA"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_MThickness","NA"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnDept","Pune-Design"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnOwn","PROPUN"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_ColourInd","Y"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PrtCatCode","VC"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartStatus",DMLDRstatus));
						//AAA:t5_PartPlatform onlly for CV
						if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
						{
							printf("\n Setting platform for CVBU VC..."); fflush(stdout);
							if(tc_strstr(BUInfo1,"A001")==NULL)
							{
								//Get Platform... AAA: need to work
								//Set platform
								//CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_Platform",VCPltform));
								if (strcmp(DMLBUnit,"CVBU")==0)
								{
									//CVVCPltform
									CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_Platform",CVVCPltform));
									printf("\n Setting platform for CVBU VC... done"); fflush(stdout);
								}
								else
								{
								
									CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_Platform",VCPltform));
									printf("\n Setting platform for PVBU VC... done"); fflush(stdout);
								}
							}
						}

						// Construct a CreateInput object for Item
						TCTYPE_find_type("Design", NULL, &item_type_tag);
						if(item_type_tag!= NULLTAG)
						{
							printf("\n vc_release--1.item_type_tag Tag Found."); fflush(stdout);
						}
						TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

						AOM_set_value_string(item_create_input_tag, "item_id", itemId12);
						AOM_set_value_string(item_create_input_tag, "object_name", itemId12);
						AOM_set_value_string(item_create_input_tag, "object_desc", objectdesc);
						AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

						//Create Design Object and Design Revision
						TCTYPE_create_object(item_create_input_tag, &parent_master1);
						if(parent_master1 != NULLTAG)
						{
							printf("\n vc_release--1.Design Revision created."); fflush(stdout);

							AOM_save_without_extensions(parent_master1);
						}

						CALLAPI ( ITEM_ask_latest_rev( parent_master1, &ItemRev ));
						CALLAPI(AOM_lock(parent_master1));
						CALLAPI(AOM_lock(ItemRev));

						CALLAPI(AOM_save_without_extensions(ItemRev));
						CALLAPI(AOM_unlock(ItemRev));
						AOM_unlock(parent_master1);

						//CALLAPI (CR_create_release_status2("T5_LcsWorking",&status2));
						//printf("\n release status find.");fflush(stdout);
						//CALLAPI(RELSTAT_add_release_status(status2,1,&ItemRev,retain));

						printf("\n vc_release--1.Before UpdateAllowForm call "); fflush(stdout);
						CALLAPI(UpdateAllowForm(ItemRev,"Y"));

						printf("\n vc_release--1.before project assign.");fflush(stdout);
						CALLAPI(AssignProject_vc_rel(ItemRev,itemId1234));//change Shubham
						printf("\n vc_release--1.after project assign.");fflush(stdout);

						CALLAPI(ITEM_list_bom_views(parent_master1,&bv_count, &bvs))

						CALLAPI( PS_create_bom_view( NULLTAG, "", "", parent_master1,&bv1 ));
						CALLAPI(AOM_save_without_extensions( bv1 ))
						CALLAPI( AOM_save_without_extensions( parent_master1 ))
						CALLAPI( AOM_unlock( parent_master1 ))
						fprintf( stderr, "\n inside PS_create_bom_view..\n");

						CALLAPI(PS_create_bvr( bv1, "", "", false, ItemRev,&bvr1) )
						if(bvr !=NULLTAG)
						{
							CALLAPI( AOM_save_without_extensions( bvr1) )
							CALLAPI (AOM_save_without_extensions( ItemRev ))
							CALLAPI( AOM_unlock( ItemRev ))
							fprintf( stderr, "\n inside  PS_create_bvr..\n");
						}

						printf("\n\t vc_release--1.VC not found loop..........");fflush(stdout); fflush(stdout);
					}

					const char **attrs1 = (const char **) MEM_alloc(2 * sizeof(char *));
					const char **values1 = (const char **) MEM_alloc(2 * sizeof(char *));

					attrs1[0] ="item_id";
					attrs1[1] ="object_type";

					values1[0] = (char *)VehName;
					values1[1] = "Design";

					CALLAPI(ITEM_find_items_by_key_attributes(2,attrs1, values1, &n_tags_found1, &tags_found1));

					MEM_free(attrs1);
					MEM_free(values1);

					//CALLAPI(ITEM_find_item(VehName, &parent_master))
					printf( "\n vc_release--1.parent_master found..........."); fflush(stdout);
					printf( "\n vc_release--1.parent master count  [%d] \n",n_tags_found1); fflush(stdout);

					//if(parent_master !=NULLTAG)
					if (n_tags_found1 == 1)
					{
						parent_master = tags_found1[0];

						CALLAPI(ITEM_list_bom_views(parent_master,&bv_count, &bvs))

						printf( "\n vc_release--1.bv_count :%d:.. ",bv_count); fflush(stdout);

						CALLAPI ( ITEM_ask_latest_rev( parent_master, &VCrev ));
						CALLAPI (WSOM_ask_release_status_list(VCrev,&status_count,&status_list));

						if (status_count > 0)  // No Status, so the Item is not yet Released
						{
							for(ss=0; ss<status_count ; ss++)
							{
								CALLAPI(AOM_ask_value_string(status_list[0],"object_name",&CurrentRelStatus));
								printf("\n vc_release--CurrentRelStatus: %s ",CurrentRelStatus);fflush(stdout);

								if((tc_strstr(CurrentRelStatus,"ERC Released")==NULL) || (tc_strstr(CurrentRelStatus,"T5_LcsErcRlzd")==NULL) )
								{
									CALLAPI(QRY_find2("Control Objects...", &CtrObjVCReviseQryTag));

									VCReviseEntryValue[0] = "DmlVCRevise";	//SYSCD
									VCReviseEntryValue[1] = "ON";			//SUBSYSCD

									CALLAPI(QRY_execute(CtrObjVCReviseQryTag, 2, VCReviseQryEntry, VCReviseEntryValue, &VCReviseQryC, &VCReviseCtrObj));
									printf("\n vc_release--Control Object AltrozVCRevise count:--> [%d] ",VCReviseQryC); fflush(stdout);

									if(VCReviseQryC>0)
									{
										CALLAPI(AOM_ask_value_string(VCReviseCtrObj[0],"t5_Userinfo1",&VCReviseinfo1));

										tc_strcpy(command,"");
										tc_strcpy(command,"/user/cvprod/Program_Shells/DML_Support/Shubham_CV/rudresh/vcReviseFrmDml_cvprodtrl.sh");
										tc_strcat(command," ");
										tc_strcat(command,DMLNo);
										tc_strcat(command," ");
										tc_strcat(command,VehName);

										printf("\n vc_release--:command: %s",command);fflush(stdout);

										TC_write_syslog("vc_release--Command = %s\n",command);
										system(command);

										CALLAPI(ITEM_ask_latest_rev(parent_master, &RevNewSeqTag ));
										if (RevNewSeqTag!=NULLTAG)
										{
											printf("\n vc_release--:RevNewSeqTag Found.. ");fflush(stdout);

											CALLAPI(AOM_UIF_ask_value(RevNewSeqTag, "release_status_list", &latest_rev_Rel_Stus));
											printf("\n vc_release--:latest_rev_Rel_Stus: [%s] ",latest_rev_Rel_Stus);fflush(stdout);

											CALLAPI(WSOM_ask_release_status_list(RevNewSeqTag,&NewRevstatus_count,&NewRevstatus_list));

											printf("\n vc_release--:NewRevstatus_count: [%d] ",NewRevstatus_count);fflush(stdout);
											if (NewRevstatus_count > 0)  // No Status, so the Item is not yet Released
											{
												for(ss2=0; ss2<NewRevstatus_count ; ss2++)
												{
													CALLAPI(AOM_ask_value_string(NewRevstatus_list[ss2],"object_name",&NewRevRelStatus));
													printf("\n vc_release--NewRevRelStatus: %s ",NewRevRelStatus);fflush(stdout);

													if((tc_strstr(NewRevRelStatus,"ERC Released")!=NULL) || (tc_strstr(NewRevRelStatus,"T5_LcsErcRlzd")!=NULL) )
													{
														EMH_clear_errors();
														//EMH_store_error_s1(EMH_severity_error,PLM_error,"Unable to Revise Vehicle for SVR attached under DML. Please raise ticket in TMS.");
														printf("\n vc_release--Unable to Revise Vehicle for SVR attached under DML ?? \n\n");fflush(stdout);
														return 0;
													}
												}
											}
										}
									}
									else
									{
										CALLAPI(ITEM_copy_rev(VCrev,NULL,&RevNewSeqTag));
									}
									//t5removeAllReleaseStatus (RevNewSeqTag);

									printf("\n vc_release--2.Before UpdateAllowForm call "); fflush(stdout);
									CALLAPI(UpdateAllowForm(RevNewSeqTag,"Y"));
									CALLAPI(AssignProject_vc_rel(RevNewSeqTag,itemId1234));

									CALLAPI(AOM_lock( RevNewSeqTag ));
									CALLAPI ( AOM_set_value_string(RevNewSeqTag,"t5_PartStatus",DMLDRstatus));
									CALLAPI ( AOM_set_value_string(RevNewSeqTag, "object_desc", objectdesc));
									CALLAPI(AOM_save_without_extensions( RevNewSeqTag) )
									CALLAPI(AOM_refresh(RevNewSeqTag,1));
									CALLAPI(AOM_unlock(RevNewSeqTag));

									//CALLAPI (CR_create_release_status2("T5_LcsWorking",&status2));
									//printf("\n release status find.");fflush(stdout);
									//CALLAPI(RELSTAT_add_release_status(status2,1,&RevNewSeqTag,retain));

									if (bv_count)
									{
										bv = bvs[0];
										MEM_free(bvs);
									}else
									{
										CALLAPI( PS_create_bom_view( NULLTAG, "", "", parent_master,&bv ));
										CALLAPI(AOM_save_without_extensions( bv ))
										CALLAPI( AOM_save_without_extensions( parent_master ))
										CALLAPI( AOM_unlock( parent_master ))
										printf(  "\n vc_release--1.inside PS_create_bom_view..\n"); fflush(stdout);
									}

									fprintf( stderr, "\n ITEM_ask_latest_rev.........\n");

									CALLAPI ( VOO_show_wso( RevNewSeqTag ) )
									CALLAPI(ITEM_rev_list_bom_view_revs(RevNewSeqTag,&bvr_count, &bvrs))
									printf("\n vc_release--1.bvr_count of Rev :%d..\n",bvr_count); fflush(stdout);

									if (bvr_count > 0)
									{
										bvr = bvrs[0];

										CALLAPI(AOM_lock( bvr ));

										CALLAPI(PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal ));
										printf("\n vc_release--A.Found....n_occs: [%d] \n",n_occs); fflush(stdout);

										for (iy = 0; iy<n_occs; iy++)
										{
											CALLAPI(PS_delete_occurrence( bvr, occsal[iy] ));
										}

										/*
										CALLAPI(POM_class_of_instance (bvr,&class_idr));
										CALLAPI(POM_unload_instances (1,&bvr));
										CALLAPI(POM_load_instances(1,&bvr,class_idr,1));
										CALLAPI(POM_is_loaded(bvr,&log1));

										if(log1 == 1)
										{
											printf(" vc_release--A.Load Success \n"); fflush(stdout);
										}
										else
										{
											printf(" vc_release--A.Load Failure \n"); fflush(stdout);
										}

										CALLAPI(POM_referencers_of_instance(bvr, 1,POM_in_db_only,&n_instances,&ref_instances,&instance_levels,&instance_where_found,&n_classes,&ref_classes,&class_levels,&class_where_found));
										printf("\n vc_release--A.Found....n_instances. FOR ITEM REVISION : [%d] \n",n_instances); fflush(stdout);

										for(iy=0;iy<n_instances;iy++)
										{
											CALLAPI(POM_class_of_instance (ref_instances[iy],&class_id));
											CALLAPI(POM_name_of_class (class_id,&class_name));

											if(strcmp(class_name,"PSOccurrence")==0 )
											{
												CALLAPI (POM_attr_id_of_attr("t5_CurrentViewMaskC", "PSOccurrence", &attr_idDR));
												CALLAPI (POM_ask_attr_string(ref_instances[iy] , attr_idDR, &spcPrefName, &lNull, &lEmpty));

												printf("\n vc_release--A.CarViewMask [%s] [%d] \n",spcPrefName,lNull); fflush(stdout);

												if (lNull == 0)
												{
													printf("\n vc_release--A.=> If 1 \n"); fflush(stdout);

													if(strcmp(spcPrefName,"-12")==0 )
													{
														printf("\n vc_release--A.skiping for car mask indexx:: [%s] \n ",spcPrefName); fflush(stdout);
														//CALLAPI(POM_delete_instances(1,ref_instances)); fflush(stdout);
													}
													else
													{
														//printf("\n vc_release--A.=> Else 1 \n"); fflush(stdout);
														ref_instancesTemp = malloc( sizeof(1) );
														ref_instancesTemp[0]=ref_instances[iy];
														CALLAPI(POM_delete_instances(1,ref_instancesTemp));
														ref_instancesTemp = NULL;
													}
												}
												else
												{
													//printf("\n vc_release--A.=> Else 2 \n"); fflush(stdout);
													ref_instancesTemp = malloc( sizeof(1) );
													ref_instancesTemp[0]=ref_instances[iy];
													CALLAPI(POM_delete_instances(1,ref_instancesTemp));
													ref_instancesTemp = NULL;
												}
											}
										}
										//CALLAPI(PS_create_bvr( bv, "", "", false, RevNewSeqTag,&bvr) )
										//if(bvr !=NULLTAG)
										//{
										//	CALLAPI( AOM_save_without_extensions( bvr) )
										//	CALLAPI (AOM_save_without_extensions( RevNewSeqTag ))
										//	CALLAPI( AOM_unlock( RevNewSeqTag ))
										//	fprintf( stderr, "\n inside  PS_create_bvr..\n");
										//}

										CALLAPI(POM_save_instances(1,&bvr,FALSE));
										*/

										CALLAPI( AOM_save_without_extensions( bvr) )
										CALLAPI(AOM_unlock(bvr));

										MEM_free(bvrs);
									}
									else
									{
										CALLAPI(PS_create_bvr( bv, "", "", false, RevNewSeqTag,&bvr) )
										if(bvr !=NULLTAG)
										{
											CALLAPI(AOM_save_without_extensions( bvr) )
											CALLAPI(AOM_save_without_extensions( RevNewSeqTag ))
											CALLAPI(AOM_unlock( RevNewSeqTag ))
											printf("\n inside  PS_create_bvr.."); fflush(stdout);
										}
									}
									printf( "\n vc_release--1.After PS_create_bvr.."); fflush(stdout);

									break;
								}
								else
								{
									printf("\n CV-PV: Setting error.."); fflush(stdout);
									if(tc_strstr(BUInfo1,"A002")==NULL)
									{
										//AAA: conform error statement
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_Prjerr, "Found VC revision is not ERC Released. in \n Please raise ticket in TMS." );
										return ITK_Prjerr;
									}
									else
									{
										//Code will be OFFF, we will remove in next deplyment
										printf("\n vc_release--3.In Else Condn "); fflush(stdout);

										CALLAPI(ITEM_rev_list_bom_view_revs(VCrev,&bvr_count, &bvrs))
										//t5removeAllReleaseStatus (VCrev);

										printf("\n vc_release--3.Before UpdateAllowForm call "); fflush(stdout);
										CALLAPI(UpdateAllowForm(VCrev,"Y"));
										CALLAPI(AssignProject_vc_rel(VCrev,itemId1234));

										//CALLAPI (CR_create_release_status2("T5_LcsWorking",&status2));
										//printf("\n release status find.");fflush(stdout);
										//CALLAPI(RELSTAT_add_release_status(status2,1,&VCrev,retain));

										printf( "\n vc_release--3.bvr_count of Rev :%d..\n",bvr_count); fflush(stdout);

										if (bvr_count > 0)
										{
											bvr = bvrs[0];

											CALLAPI(AOM_lock( bvr ));

											CALLAPI(PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal ));
											printf("\n vc_release--3.Found....n_occs: [%d] \n",n_occs); fflush(stdout);

											for (iy = 0; iy<n_occs; iy++)
											{
												CALLAPI(PS_delete_occurrence( bvr, occsal[iy] ));
											}

											/*
											CALLAPI(POM_class_of_instance (bvr,&class_idr));
											CALLAPI(POM_unload_instances (1,&bvr));
											CALLAPI(POM_load_instances(1,&bvr,class_idr,1));
											CALLAPI(POM_is_loaded(bvr,&log1));

											if(log1 == 1)
											{
												printf(" vc_release--B.Load Success \n"); fflush(stdout);
											}
											else
											{
												printf(" vc_release--B.Load Failure \n"); fflush(stdout);
											}

											CALLAPI(POM_referencers_of_instance(bvr, 1,POM_in_db_only,&n_instances,&ref_instances,&instance_levels,&instance_where_found,&n_classes,&ref_classes,&class_levels,&class_where_found));
											printf("\n vc_release--B.Found....n_instances. FOR ITEM REVISION: [%d] \n",n_instances); fflush(stdout);

											for(iy=0;iy<n_instances;iy++)
											{
												CALLAPI(POM_class_of_instance (ref_instances[iy],&class_id));
												CALLAPI(POM_name_of_class (class_id,&class_name));

												if(strcmp(class_name,"PSOccurrence")==0 )
												{
													CALLAPI (POM_attr_id_of_attr("t5_CurrentViewMaskC", "PSOccurrence", &attr_idDR));
													CALLAPI (POM_ask_attr_string(ref_instances[iy] , attr_idDR, &spcPrefName, &lNull, &lEmpty));

													printf("\n vc_release--B.CarViewMask [%s] [%d] \n",spcPrefName,lNull); fflush(stdout);

													if (lNull == 0)
													{
														printf("\n vc_release--B.=> If 1 \n"); fflush(stdout);

														if(strcmp(spcPrefName,"-12")==0 )
														{
															printf("\n vc_release--B.skiping for car mask indexx %s \n ",spcPrefName); fflush(stdout);
															//CALLAPI(POM_delete_instances(1,ref_instances)); fflush(stdout);
														}
														else
														{
															//printf("\n vc_release--B.=> Else 1 \n"); fflush(stdout);
															ref_instancesTemp = malloc( sizeof(1) );
															ref_instancesTemp[0]=ref_instances[iy];
															CALLAPI(POM_delete_instances(1,ref_instancesTemp));
															ref_instancesTemp = NULL;
														}
													}
													else
													{
														//printf("\n vc_release--B.=> Else 2 \n"); fflush(stdout);
														ref_instancesTemp = malloc( sizeof(1) );
														ref_instancesTemp[0]=ref_instances[iy];
														CALLAPI(POM_delete_instances(1,ref_instancesTemp));
														ref_instancesTemp = NULL;
													}
												}
											}
											*/

											MEM_free(bvrs);

											CALLAPI(POM_save_instances(1,&bvr,FALSE));
											CALLAPI( AOM_save_without_extensions( bvr) )
											CALLAPI(AOM_unlock(bvr));
										}
										else
										{
											CALLAPI(PS_create_bvr( bv, "", "", false, VCrev,&bvr) )
											if(bvr !=NULLTAG)
											{
												CALLAPI( AOM_save_without_extensions( bvr) )
												CALLAPI (AOM_save_without_extensions( VCrev ))
												CALLAPI( AOM_unlock( VCrev ))
												printf(  "\n vc_release--3.inside  PS_create_bvr..\n"); fflush(stdout);
											}
										}

										//printf("\n\t Released VC not found loop..........");fflush(stdout);
										//EMH_store_error_s1(EMH_severity_warning,ITK_errStore1,"Released VC with same name as that of SVR not present in TCUA. please get released VC loaded from TCE");
										//return ITK_errStore1;

										break;
									}
								}
							}
						}
					}
					else
					{
						TCTYPE_find_type("Design Revision", NULL, &rev_type_tag);
						if(rev_type_tag!=NULLTAG)
						{
							printf("\n vc_release--2.Else--rev_type_tag Tag Found."); fflush(stdout);
						}
						TCTYPE_construct_create_input(rev_type_tag, &rev_create_input_tag);
						AOM_set_value_string(rev_create_input_tag, "object_name", VehName);
						AOM_set_value_string(rev_create_input_tag, "object_desc", objectdesc);
						AOM_set_value_string(rev_create_input_tag, "item_revision_id", "NR;1");
						CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_ProjectCode", itemId1234));
						CALLAPI(AOM_set_value_string(rev_create_input_tag, "t5_DesignGrp", "00"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartType","V"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DocRemarks","NA"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_MThickness","NA"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnDept","Pune-Design"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_DsgnOwn","PROPUN"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_ColourInd","Y"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PrtCatCode","VEHICLE"));
						CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_PartStatus",DMLDRstatus));
						//AAA:t5_PartPlatform onlly for CV
						if(tc_strstr(BUInfo2,DMLBUnit)!=NULL)
						{
							printf("\n Setting platform for CVBU VC..."); fflush(stdout);
							if(tc_strstr(BUInfo1,"A003")==NULL)
							{
								//Get Platform... AAA: need to work
								//Set platform
								//CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_Platform",VCPltform));
								if (strcmp(DMLBUnit,"CVBU")==0)
								{
									//CVVCPltform
									CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_Platform",CVVCPltform));
									printf("\n Setting platform for CVBU VC... done"); fflush(stdout);
								}
								else
								{
								
									CALLAPI ( AOM_set_value_string(rev_create_input_tag,"t5_Platform",VCPltform));
									printf("\n Setting platform for PVBU VC... done"); fflush(stdout);
								}
							}
						}

						// Construct a CreateInput object for Item
						TCTYPE_find_type("Design", NULL, &item_type_tag);
						if(item_type_tag!=NULLTAG)
						{
							printf("\n vc_release--2.item_type_tag Tag Found."); fflush(stdout);
						}
						TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag);

						AOM_set_value_string(item_create_input_tag, "item_id", VehName);
						AOM_set_value_string(item_create_input_tag, "object_name", VehName);
						AOM_set_value_string(item_create_input_tag, "object_desc", objectdesc);
						AOM_set_value_tag(item_create_input_tag, "revision",rev_create_input_tag);

						//Create Design Object and Design Revision
						TCTYPE_create_object(item_create_input_tag, &parent_master);
						if(parent_master!=NULLTAG)
						{
							printf("\n vc_release--2.Design Revision created."); fflush(stdout);

							AOM_save_without_extensions(parent_master);
						}

						CALLAPI ( ITEM_ask_latest_rev( parent_master, &ItemRev1 ));
						CALLAPI(AOM_lock(parent_master));
						CALLAPI(AOM_lock(ItemRev1));

						CALLAPI(AOM_save_without_extensions(ItemRev1));
						CALLAPI(AOM_unlock(ItemRev1));
						AOM_unlock(parent_master);

						//t5removeAllReleaseStatus (ItemRev1);

						printf("\n vc_release--4.Before UpdateAllowForm call "); fflush(stdout);
						CALLAPI(UpdateAllowForm(ItemRev1,"Y"));
						CALLAPI(AssignProject_vc_rel(ItemRev1,itemId1234));

						//CALLAPI (CR_create_release_status2("T5_LcsWorking",&status2));
						//printf("\n release status find.");fflush(stdout);
						//CALLAPI(RELSTAT_add_release_status(status2,1,&ItemRev1,retain));

						CALLAPI(ITEM_list_bom_views(parent_master,&bv_count, &bvs))

						CALLAPI( PS_create_bom_view( NULLTAG, "", "", parent_master,&bv ));
						CALLAPI(AOM_save_without_extensions( bv ))
						CALLAPI( AOM_save_without_extensions( parent_master ))
						CALLAPI( AOM_unlock( parent_master ))
						printf( "\n vc_release--2.inside PS_create_bom_view..\n");	 fflush(stdout);

						CALLAPI(PS_create_bvr( bv, "", "", false, ItemRev1,&bvr) )
						if(bvr != NULLTAG)
						{
							CALLAPI(AOM_save_without_extensions( bvr) )
							CALLAPI(AOM_save_without_extensions( ItemRev1 ))
							CALLAPI(AOM_unlock( ItemRev1 ))
							printf("\n vc_release--2.inside  PS_create_bvr..\n"); fflush(stdout);
						}
						if (bvr1 != NULLTAG)
						{
							CALLAPI(AOM_lock( bvr1 ));
							CALLAPI(PS_create_occurrences( bvr1, ItemRev1, NULLTAG,1, &occs ))
							//CALLAPI(PS_set_occurrence_qty(bvr1, occs[0], int_qunt));
							CALLAPI(AOM_save_without_extensions( bvr1) )
							CALLAPI(AOM_refresh(bvr1,1));
							CALLAPI(AOM_unlock(bvr1));
						}

						printf("\n\t vc_release--2.VC not found loop..........");fflush(stdout);
						//	 EMH_store_error_s1(EMH_severity_error,ITK_errStore1,"VC with same name as that of SVR not present in TCUA. please get it loaded from TCE or create in TCUA and check-In");
						//		return ITK_errStore1;
					}

					/*
					if(top_line!=NULLTAG)
					{
						// CALLAPI(BOM_line_unpack(top_line));

						CALLAPI( BOM_line_look_up_attribute ("bl_quantity",&blqu));
						xform_matrix1=0;

						// CALLAPI( BOM_line_look_up_attribute ("bl_abs_xform_matrix",&xform_matrix1));
						CALLAPI( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrix1));
						CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
						printf("\n vc_release--21.LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);

						//if(n_lines1 == n_lines)
						//{
						if (n_lines1 >0)
						{
							const char **attrs3 = (const char **) MEM_alloc(2 * sizeof(char *));
							const char **values3 = (const char **) MEM_alloc(2 * sizeof(char *));

							attrs3[0] ="item_id";
							attrs3[1] ="object_type";

							printf("\n vc_release--2.before lock BVR-11  ");fflush(stdout);
							CALLAPI(AOM_lock( bvr ));

							for (p1=0;p1<n_lines1 ;p1++ )
							{
								if(Childobject4) Childobject4=NULLTAG;
								Childobject4=lines[p1];
								//CALLAPI(BOM_line_unpack(Childobject4));

								CALLAPI(BOM_line_ask_child_lines(Childobject4, &n_lines4, &lines4));

								if (n_lines4 >0)
								{
									for (p4=0;p4<n_lines4 ;p4++ )
									{
										if(Childobject3) Childobject3=NULLTAG;
										if(child_item_id) child_item_id=NULL;

										Childobject3=lines4[p4];

										CALLAPI(TCTYPE_ask_object_type(Childobject3,&objTypeTagDi));
										CALLAPI(TCTYPE_ask_name2(objTypeTagDi,&type_name2));

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_item_item_id", &child_item_id ));
										printf("\n\n p4:[%d]  Last child_item_id:: %s and type_name2 :%s \n",p4,child_item_id,type_name2);

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &child_item_revision_id ));
										printf("  revision: %s  ",child_item_revision_id);

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_formula", &child_bl_formula ));
										printf("\n child_bl_formula: %s",child_bl_formula);

										printf("\n ***********xform_matrix1: %d  ",xform_matrix1);
										CALLAPI(BOM_line_ask_attribute_string(Childobject3, xform_matrix1, &xform_matrix_str));
										printf( "\n child xform matrix 11--> %s",xform_matrix_str);fflush(stdout);

										tempmat1=tc_strtok(xform_matrix_str," ");

										for(imat=0;imat<4;imat++)
										{
											for(jmat=0;jmat<4;jmat++)
											{
												if(imat==0 && jmat==0)
												{
													//printf("\n inside if"); fflush(stdout);
													mat[imat][jmat]=strtod(tempmat1,NULL);
												}
												else
												{
													//printf("\n inside else"); fflush(stdout);
													tempmat=tc_strtok(NULL," ");
													mat[imat][jmat]=strtod(tempmat,NULL);
												}
											}
										}

										CALLAPI(BOM_line_ask_attribute_string(Childobject3, blqu, &blqu_str));

										printf("\n child quantity matrix--> %s  ",blqu_str);

										int_qunt=atoi(blqu_str);

										printf("\n child quantity int--> %d  ",int_qunt);

										if (child_item_id != NULL)
										{
											values3[0] = (char *)child_item_id;
											values3[1] = "Design";

											//ifail = ITEM_find_items_by_key_attributes(2,attrs, values, &n_tags_found, &tags_found);
											CALLAPI(ITEM_find_item_revs_by_key_attributes(2,attrs3, values3,child_item_revision_id, &n_tags_found3, &tags_found3))

											if (n_tags_found3>0)
											{
												Childrev= tags_found3[0];

												//CALLAPI ( ITEM_find_rev( child_item_id, child_item_revision_id, &Childrev ) )
												if(Childrev!=NULLTAG)
												{
													//////CALLAPI ( VOO_show_wso( Childrev ) )

													//CALLAPI(AOM_lock( bvr ));
													CALLAPI(PS_create_occurrences( bvr, Childrev, NULLTAG,1, &occs ))
													CALLAPI(PS_set_occurrence_qty(bvr, occs[0], int_qunt));

													int_qunt = 0;

													//for(imat=0;imat<3;imat++)
													//{
													//	mat[3][imat]=(double)(mat[3][imat]/divInt);
													//}

													for(imat=0;imat<4;imat++)
													{
														for(jmat=0;jmat<4;jmat++)
														{
															printf("%10lf,",mat[imat][jmat]);
														}
														printf("\n");
													}

													CALLAPI(PS_set_plmxml_transform(bvr, occs[0], *mat));

													//	CALLAPI(AOM_lock(bvr));

													CALLAPI(AOM_save_without_extensions( bvr) )
													//CALLAPI(AOM_refresh(bvr,1));
													//CALLAPI(AOM_unlock(bvr));
												}
											}
										} //End of if (child_item_id != NULL)
									}
								}
							} //End of for (p1=0;p1<n_lines1 ;p1++ )

							printf("\n vc_release--2.before saving BVR-11  ");fflush(stdout);
							CALLAPI(AOM_save_without_extensions( bvr) )
							CALLAPI(AOM_refresh(bvr,1));
							CALLAPI(AOM_unlock(bvr));

							printf("\n vc_release--2.before memory-Free-1  ");fflush(stdout);
							MEM_free(attrs3);
							MEM_free(values3);
							printf("\n vc_release--2.After memory-Free-1  ");fflush(stdout);

						} //End of if (n_lines1 >0)
						//else
						//{
						//	printf(  " Rules not applied successfully check again:\n"); fflush(stdout);
						//
						//}
					}*/


					if(top_line!=NULLTAG)
					{
						printf("\n vc_release--[--11--]"); fflush(stdout);

						//CALLAPI(AOM_save_without_extensions( bvr));
						//CALLAPI(AOM_refresh(bvr,1));
						//CALLAPI(AOM_lock( bvr ));

						//CALLAPI(BOM_line_unpack(top_line));

						//CALLAPI( BOM_line_look_up_attribute ("bl_quantity",&blqu));
						xform_matrix1=0;
						// CALLAPI( BOM_line_look_up_attribute ("bl_abs_xform_matrix",&xform_matrix1));
						//CALLAPI( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrix1));
						CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
						printf("\n vc_release--3.LLlast Before setting option n_lines1: %d", n_lines1); fflush(stdout);

						//if(n_lines1 == n_lines)
						//{
						if (n_lines1 >0)
						{
							for (p1=0;p1<n_lines1 ;p1++ )
							{
								if(Childobject4) Childobject4=NULLTAG;
								Childobject4=lines[p1];
								//CALLAPI(BOM_line_unpack(Childobject4));

								CALLAPI(BOM_line_ask_child_lines(Childobject4, &n_lines4, &lines4));

								if (n_lines4 >0)
								{
									for (p4=0;p4<n_lines4 ;p4++ )
									{
										if(Childobject3) Childobject3=NULLTAG;

										Childobject3=lines4[p4];

										CALLAPI(TCTYPE_ask_object_type(Childobject3,&objTypeTagDi));
										CALLAPI(TCTYPE_ask_name2(objTypeTagDi,&type_name2));

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_item_item_id", &child_item_id ));
										fprintf( stderr, " Last child_item_id ..:%s and type_name2 :%s\n",child_item_id,type_name2);

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &child_item_revision_id ));
										fprintf( stderr, " bl_rev_item_revision_id--------------> %s\n",child_item_revision_id);

										CALLAPI(AOM_ask_value_string(Childobject3, "bl_formula", &child_bl_formula ));
										fprintf( stderr, " child_bl_formula 2--------------> %s\n",child_bl_formula);

										//printf("\n***********xform_matrix1:%d\n",xform_matrix1);
										//CALLAPI(BOM_line_ask_attribute_string(Childobject3, xform_matrix1, &xform_matrix_str));
										
										if( AOM_ask_displayable_values(Childobject3,"bl_plmxml_abs_xform",&strcnt3,&xform_matrix_str));
										printf("\n vc_release--child xform matrix 11-----------> [%s]\n",xform_matrix_str[0]);fflush(stdout);

										tempmat1=tc_strtok(xform_matrix_str[0]," ");

										for(imat=0;imat<4;imat++)
										{
											for(jmat=0;jmat<4;jmat++)
											{
												if(imat==0 && jmat==0)
												{
													//printf("\n inside if"); fflush(stdout);
													mat[imat][jmat]=strtod(tempmat1,NULL);
												}
												else
												{
													//printf("\n inside else"); fflush(stdout);
													tempmat=tc_strtok(NULL," ");
													mat[imat][jmat]=strtod(tempmat,NULL);
												}
											}
										}

										//CALLAPI(BOM_line_ask_attribute_string(Childobject3, blqu, &blqu_str));
										if( AOM_ask_displayable_values(Childobject3,"bl_quantity",&strcnt2,&blqu_str));
										printf("\n vc_release--child quantity matrix--------------> %s\n",blqu_str[0]); fflush(stdout);
										fprintf(stderr,"child quantity matrix--------------> %s\n",blqu_str[0]); fflush(stderr);

										int_qunt=atoi(blqu_str[0]);

										fprintf( stderr, " child quantity int-------------> %d\n",int_qunt);

										const char **attrs3 = (const char **) MEM_alloc(2 * sizeof(char *));
										const char **values3 = (const char **) MEM_alloc(2 * sizeof(char *));

										attrs3[0] ="item_id";
										attrs3[1] ="object_type";

										values3[0] = (char *)child_item_id;
										values3[1] = "Design";

										CALLAPI(ITEM_find_item_revs_by_key_attributes(2,attrs3, values3,child_item_revision_id, &n_tags_found3, &tags_found3))

										MEM_free(attrs3);
										MEM_free(values3);

										if (n_tags_found3>0)
										{
											Childrev= tags_found3[0];

											if(Childrev!=NULLTAG)
											{
												CALLAPI(AOM_lock( bvr ));
												CALLAPI(PS_create_occurrences( bvr, Childrev, NULLTAG,1, &occs ))
												CALLAPI(PS_set_occurrence_qty(bvr, occs[0], int_qunt));

												int_qunt = 0;

												//for(imat=0;imat<3;imat++)
												//{
												//	mat[3][imat]=(double)(mat[3][imat]/divInt);
												//}

												for(imat=0;imat<4;imat++)
												{
													for(jmat=0;jmat<4;jmat++)
													{
														printf("%10lf,",mat[imat][jmat]);
													}
													printf("\n");
												}

												CALLAPI(PS_set_plmxml_transform(bvr, occs[0], *mat));

												//	CALLAPI(AOM_lock(bvr));

												printf("\n [--1--]"); fflush(stdout);
												CALLAPI(AOM_save_without_extensions( bvr));
												//printf("\t[--2--]"); fflush(stdout);
												CALLAPI(AOM_refresh(bvr,1));
												//printf("\t[--3--]"); fflush(stdout);
												CALLAPI(AOM_unlock(bvr));
												printf("\t[--4--]"); fflush(stdout);
											}
										}
									}
								}
							}
						}

						//printf("\n [--12--]"); fflush(stdout);
						//CALLAPI(AOM_save_without_extensions( bvr));
						//printf("\t[--2--]"); fflush(stdout);
						//CALLAPI(AOM_refresh(bvr,1));
						//printf("\t[--3--]"); fflush(stdout);
						//CALLAPI(AOM_unlock(bvr));
						//printf("\t[--4--]"); fflush(stdout);
						//else
						//{
						//	printf(  " Rules not applied successfully check again:\n"); fflush(stdout);
						//
						//}
					}

					if (ItemRev1 != NULLTAG)
					{
						CALLAPI ( RELSTAT_create_release_status("T5_LcsReview",&status3));
						printf("\n vc_release--2.release status find 1.");fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status3,1,&ItemRev1,retain));
						printf("\n vc_release--5.Before UpdateAllowForm call "); fflush(stdout);
						CALLAPI(UpdateAllowForm(ItemRev1,"N"));
					}
					if (ItemRev != NULLTAG)
					{
						CALLAPI ( RELSTAT_create_release_status("T5_LcsReview",&status4));
						printf("\n release status find 2 .");fflush(stdout);
						CALLAPI(RELSTAT_add_release_status(status4,1,&ItemRev,retain));
						printf("\n vc_release--6.Before UpdateAllowForm call "); fflush(stdout);
						CALLAPI(UpdateAllowForm(ItemRev,"N"));
					}
					if (RevNewSeqTag != NULLTAG)
					{
						ernew=ernew+1;
						CALLAPI ( RELSTAT_create_release_status("T5_LcsReview",&status3));
						printf("\n release status find 4.");fflush(stdout);
						//CALLAPI(RELSTAT_add_release_status(status3,1,&RevNewSeqTag,retain));
						printf("\n vc_release--7.Before UpdateAllowForm call "); fflush(stdout);
						CALLAPI(UpdateAllowForm(RevNewSeqTag,"N"));
					}
					if (ernew == 0)
					{
						if (VCrev != NULLTAG)
						{
							CALLAPI ( RELSTAT_create_release_status("T5_LcsReview",&status3));
							printf("\n vc_release--2.release status find 3.");fflush(stdout);
							//CALLAPI(RELSTAT_add_release_status(status3,1,&VCrev,retain));
							printf("\n vc_release--8.Before UpdateAllowForm call "); fflush(stdout);
							CALLAPI(UpdateAllowForm(VCrev,"N"));
						}
					}

					CALLAPI(BOM_save_window(bom_window))
					CALLAPI(BOM_close_window(bom_window))

					if(relation_type1 != NULLTAG)
					{
						CALLAPI(GRM_list_secondary_objects_only(DMLTag,relation_type1,&cnt12,&attachments12));
						printf("\n vc_release--impacted items:%d\n",cnt12);fflush(stdout);

						if (RevNewSeqTag != NULLTAG)
						{
							printf("\n vc_release--Relation Creation ----1 ");fflush(stdout);

							GRM_find_relation(DMLTag,RevNewSeqTag,relation_type1,&tRelationExist);
							if (tRelationExist==NULLTAG)
							{
								//###  Creating Relation between DML and RevNewSeqTag  ###

								printf("\n vc_release--Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,RevNewSeqTag,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task));
								printf("\n vc_release--Relation Created Successfully\n");fflush(stdout);
							}
						}
						if (ernew == 0)
						{
							printf("\n vc_release--Relation Creation ----2 ");fflush(stdout);
							if(VCrev != NULLTAG)
							{
								GRM_find_relation(DMLTag,VCrev,relation_type1,&tRelationExist1);
								if (tRelationExist1==NULLTAG)
								{
									//###  Creating Relation between DML and VCrev  ###

									printf("\n vc_release--3.Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
									CALLAPI(GRM_create_relation(DMLTag,VCrev,relation_type1,NULLTAG,&Rel_task));
									CALLAPI(GRM_save_relation  (Rel_task));
									printf("\n vc_release--3.Relation Created Successfully\n");fflush(stdout);
								}
							}
						}
						if(ItemRev1 != NULLTAG)
						{
							printf("\n vc_release--Relation Creation ----3 ");fflush(stdout);

							GRM_find_relation(DMLTag,ItemRev1,relation_type1,&tRelationExist2);
							if (tRelationExist2==NULLTAG)
							{
								//###  Creating Relation between DML and ItemRev1  ###

								printf("\n vc_release--4.Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,ItemRev1,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task));
								printf("\n vc_release--4.Relation Created Successfully\n");fflush(stdout);
							}
						}

						if(ItemRev != NULLTAG)
						{
							printf("\n vc_release--Relation Creation ----4 ");fflush(stdout);

							GRM_find_relation(DMLTag,ItemRev,relation_type1,&tRelationExist3);
							if (tRelationExist3==NULLTAG)
							{
								//###  Creating Relation between DML and ItemRev  ###

								printf("\n vc_release--5.Now Creating Relation Between DML Task and VC Object \n");fflush(stdout);
								CALLAPI(GRM_create_relation(DMLTag,ItemRev,relation_type1,NULLTAG,&Rel_task));
								CALLAPI(GRM_save_relation  (Rel_task));
								printf("\n vc_release--5.Relation Created Successfully\n");fflush(stdout);
							}
						}

						if (RevNewSeqTag!=NULLTAG)
						{
							logical checkout = 0;

							CALLAPI(RES_is_checked_out(RevNewSeqTag,&checkout));
							printf("\n vc_release--1.checkout:[%d] ",checkout); fflush(stdout);

							if (checkout > 0)
							{
								if(RES_checkin(RevNewSeqTag)!=ITK_ok)
								{
									printf("\n vc_release--1..RES_checkin failed.\n"); fflush(stdout);
								}
								else
								{
									printf("\n vc_release--1..RES_checkin is successful\n"); fflush(stdout);
								}
							}
						}

						//GRM_find_relation(DMLTag,parent_master1,relation_type1,&tRelationExist4);
						//if (tRelationExist4==NULLTAG)
						//{
						//	//###  Creating Relation between DML and Task  ###
						//
						//	printf("\n vc_release--6.Now Creating Relation Between DML Task and VC Object 11\n");fflush(stdout);
						//	CALLAPI(GRM_create_relation(DMLTag,parent_master1,relation_type1,NULLTAG,&Rel_task));
						//	CALLAPI(GRM_save_relation  (Rel_task));
						//	printf("\n vc_release--6.Relation Created Successfully\n");fflush(stdout);
						//}
						//}
						//else
						//{
						//	 EMH_store_error_s1(EMH_severity_error,ITK_errStore2,"Solution Items of DML Task already contains the object. please get it cleared first");
						//	 return ITK_errStore2;
						//}
						// end

					} //End of if(relation_type1 != NULLTAG)
				}
			} //End of condn if (strcmp(objecttype,"VariantRule")==0)
		} //End of for(j=0;j<cnt;j++)
	} //End of if(relation_type != NULLTAG)
	else
	{
		EMH_clear_errors();
		//EMH_store_error_s1(EMH_severity_error,PLM_error,"DML Task References relation not found. Please raise ticket in TMS.");
		printf("\n vc_release--DML-Task Relation CMReferences not found in TCUA ?? \n\n");fflush(stdout);
		return 0;
	}

	printf("\n End of vc_release ........\n");fflush(stdout);

	return ITK_ok;
}



//int CM_CreateSnapShotfromSingleSVR(EPM_action_message_t msg)
int CM_CreateSnapShotfromSingleSVR(tag_t DMLTaskTag)
{
	int i=0,j=0,k=0,kl=0;
	int found,Dcrcnt = 0;
	int ifail=0;
	int iy=0;
	int Itemscnt=0;
	int dcrItemCnt=0, taskCnt = 0, dmlItemCnt=0, taskcnt = 0;
	int DcrItemscnt=0;
	int attachmentCount=0,qryRetCnt=0;
	int n_bom_views=0;
	int bom_view_index=0;
	int noAttachment=0;

	char *obj_type=NULL;
	char* FileDown =NULL;
	char* filename =NULL;
	char *dmlNumber=NULL;
	char *revId=NULL;
	char **qryEntries=NULL;
	char **qryValues=NULL;
	char *usrInfo1=NULL;
	char *usrInfo2=NULL;
	char *ItemNumber=NULL;
	char *ItemNumberwithDml=NULL;
	tag_t msWordType=NULLTAG;
	tag_t wordDataset=NULLTAG;
	tag_t wordLatestDat_t=NULLTAG;
	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t view_type= NULLTAG;
	tag_t rootTask_t=NULLTAG;
	tag_t primary1=NULLTAG;
	//tag_t ItemObj = NULLTAG;
	tag_t DcrItemObj=NULLTAG;
	tag_t implemRelationType_t=NULLTAG;
	tag_t derivedFromSVRRelType_ta=NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t Rel_task = NULLTAG;
	tag_t *qryResults=NULLTAG;
	tag_t *DcrList=NULLTAG;
	//tag_t *taskList=NULLTAG;
	tag_t *ItemsList=NULLTAG;
	tag_t *DcrItemsList=NULLTAG;
	tag_t *bom_views=NULL;
	tag_t bom_view_type=NULLTAG;
	tag_t item=NULLTAG;
	tag_t bom_view= NULLTAG;
	tag_t VCrev= NULLTAG;
	char *ItemId = NULL;
	char *RevId = NULL;
	char *VCItemId = NULL;
	char *SVRType = NULL;
	FILE *fd = NULL;

	tag_t tRelationExistab11 = NULLTAG;
	tag_t e_block=NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t bom_window=NULLTAG;
	tag_t snapshot=NULLTAG;
	tag_t window2=NULLTAG;
	tag_t top_line=NULLTAG;
	tag_t top_line1=NULLTAG;
	tag_t rule =NULLTAG;
	tag_t Childobject=NULLTAG;
	tag_t Childobject1=NULLTAG;
	tag_t Childobject3=NULLTAG;
	tag_t Childobject4=NULLTAG;
	tag_t Childobject33=NULLTAG;
	tag_t dataset = NULLTAG;
	int n_saved_variant_rules=0;
	tag_t *saved_variant_rules=NULLTAG;
	tag_t *bom_variant_rule=NULLTAG;
	logical list_changed=FALSE;
	int n_options=0;
	int errorflag=0;
	int errorflag4=0;
	int errorflag1=0;
	int errorflag2=0;
	int errorflag34=0;
	tag_t *options=NULL;
	char *v2_text=NULL;
	//tag_t *option_revs=NULL;
	int option_value_index=-1;
	tag_t option1=NULLTAG;
	tag_t *option1_rev=NULL;
	int *option1_value_index=NULL;
	tag_t option2=NULLTAG;
	tag_t *option2_rev=NULL;
	int *option2_value_index=NULL;
	int inx, jnx, knx;
	int n_option_data=0,p1=0;
	tag_t topline = NULLTAG;
	void **option_data=NULL;
	int BOmvarcnt2= 0;

	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;
	int n_ves_2_save=0;
	int n_lines2=0;
	int n_lines3=0;
	int n_lines4=0;
	int rulefound= 0;
	int p2=0;
	int ss=0;
	int p36=0;
	char **rulename = NULL;
	char **rulevalue = NULL;
	char *desc = NULL;
	char *varrul = NULL;
	tag_t *option_revs=NULL;
	char *CurrentRelStatus = NULL;
	tag_t dml_Ref_Rel = NULLTAG;
	tag_t dml_Ref_Rel_t = NULLTAG;
	char* itemId12 = NULL;
	char cCurrentAccessDate[20]={0};
	int p4=0;
	int snapcnt=0;
	tag_t *ves_2_save=NULL;
	tag_t toggle_ve=NULLTAG;
	int n_lines,n_lines1,Item_ID = 0;
	tag_t *lines = NULL;
	tag_t *extsnap = NULLTAG;
	tag_t *lines2 = NULL;
	tag_t *lines3 = NULL;
	tag_t *lines4 = NULL;
	tag_t *Newlines = NULL;
	char *Item_ID_str=NULL;
	char* itemId1234 = NULL;
	char* itemId123 = NULL;
	char* itemId12345 = NULL;
	char *VehName =NULL;
	tag_t relation_type = NULLTAG;
	tag_t relation_type1 = NULLTAG;
	char relation_name[TCTYPE_name_size_c+1];
	char *child_item_id=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	tag_t *closurerule = NULL;
	char *child_bl_formula=NULL;
	tag_t objTypeTag=NULLTAG;
	char *child_bl_formula23=NULL;
	char* username=NULL;
	tag_t user_tag=NULLTAG;
	tag_t SVRDerRel_t=NULLTAG;
	tag_t parent_master1 = NULLTAG;
	int IntAtr5=0;
	char *objecttype=NULL;
	char *TempVal =NULL;
	tag_t close_tag;
	char *objectname=NULL;
	char *childsvrname=NULL;
	char docFile[100];
	logical modB=FALSE;
	int structcount=0;
	char type_name2[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	char type_name1[TCTYPE_name_size_c+1];
	char *tempmat=NULL;
	tag_t Rel_taska = NULLTAG;
	tag_t Rel_taskab = NULLTAG;
	tag_t tRelationExista = NULLTAG;
	tag_t tRelationExistab = NULLTAG;

	TempVal = (char *) MEM_alloc (sizeof (char) * 128);

	//	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	//	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	//ITK_CALL(GRM_find_relation_type("CMImplements",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
	ITK_CALL(GRM_find_relation_type("T5_PartHasSnapShot",&implemRelationType_t));
	ITK_CALL(GRM_find_relation_type("T5_DerivedFromSVR",&derivedFromSVRRelType_ta));
	ITK_CALL(GRM_find_relation_type("T5_SVRDerivesCCV",&SVRDerRel_t));

	//POM_get_user(&username,&user_tag);
	POM_get_user_id(&username);

	printf("\n\n CM_CreateSnapShotfromSingleSVR--Starting for taskbreskdownnn: [%s]....",username);fflush(stdout);

	getCurrentDateTimee(cCurrentAccessDate);
	printf("\t cCurrentAccessDate:[%s]",cCurrentAccessDate);fflush(stdout);

	//	for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
	//	{
	//		ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));

		ITK_CALL(WSOM_ask_object_type2(DMLTaskTag,&obj_type));
		printf(" CM_CreateSnapShotfromSingleSVR--Object Type = %s \n",obj_type);fflush(stdout);

		if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
		{
			char *qry_entriesR[] = { "SYSCD","SUBSYSCD"}, *qry_valuesR[] = {"Project","AltrozWay"};
			int noOfCoObjectsR = 0;
			tag_t queryR = NULLTAG;
			tag_t *CoobjectsR = NULLTAG;
			char *usrInfo1R = NULL;
			char *projStr = NULL;

			usrInfo1R = (char *) MEM_alloc(250);
			projStr=(char *) MEM_alloc(10);
			
			tc_strcpy(usrInfo1R,"");
			tc_strcpy(projStr,"");
			
			ITK_CALL(QRY_find2("Control Objects...", &queryR));
			if (queryR !=NULLTAG)
			{
				printf("\n CM_CreateSnapShotfromSingleSVR--queryR found");fflush(stdout);
				ITK_CALL(QRY_execute(queryR,2, qry_entriesR, qry_valuesR, &noOfCoObjectsR, &CoobjectsR));
				printf("\n\n CM_CreateSnapShotfromSingleSVR--Total Number Of CoobjectsR Found ==[%d] \n",noOfCoObjectsR);fflush(stdout);

				if(noOfCoObjectsR>0)
				{
					ITK_CALL(AOM_ask_value_string(CoobjectsR[0],"t5_Userinfo1",&usrInfo1R));
					printf("\n CM_CreateSnapShotfromSingleSVR--usrInfo1R :[%s]\n",usrInfo1R);fflush(stdout);
				}
			}

			if(DcrProblmItemsRelType != NULLTAG)
			{
	//				ITK_CALL(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DcrProblmItemsRelType,&Dcrcnt,&DcrList));
				ITK_CALL(GRM_list_secondary_objects_only(DMLTaskTag,DcrProblmItemsRelType,&Dcrcnt,&DcrList));

				printf("\n CM_CreateSnapShotfromSingleSVR--to find impacted items  Dcrcnt: [%d] \n",Dcrcnt);fflush(stdout);

				for(i=0;i<Dcrcnt;i++)
				{
					rev1 = DcrList[i];

					if(AOM_ask_value_string(rev1,"object_type",&objecttype));
					if(AOM_ask_value_string(rev1,"object_name",&objectname));

					printf(" CM_CreateSnapShotfromSingleSVR--Object Type in loop = %s\n",objecttype);fflush(stdout);

					if (tc_strcmp(objecttype,"T5_PlatformRevision")==0)
					{
						primary1=rev1;
						break;
					}
				}

				for(j=0;j<Dcrcnt;j++)
				{
					printf("\n CM_CreateSnapShotfromSingleSVR--to find impacted items\n");fflush(stdout);
					rev = DcrList[j];
					if(AOM_ask_value_string(rev,"object_type",&objecttype));
					if(AOM_ask_value_string(rev,"object_name",&objectname));

					if (strcmp(objecttype,"VariantRule")==0)
					{
						printf( "\n CM_CreateSnapShotfromSingleSVR--INside platform\n"); fflush(stdout);
						if ( primary1 !=NULLTAG )
						{
							if ( PS_find_view_type( "view", &view_type ));
							printf("\n CM_CreateSnapShotfromSingleSVR--PS_find_view_type is found......\n" ); fflush(stdout);

							if ( view_type != NULLTAG )
							{
								if ( ITEM_ask_item_of_rev( primary1, &item ));
								if ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

								bom_view = bom_views[0];
							}
							else
								printf("\n CM_CreateSnapShotfromSingleSVR--View not found check.......\n"); fflush(stdout);
						}

						if ( bom_view != NULLTAG )
						{
							printf(" CM_CreateSnapShotfromSingleSVR--before BOM_create_window..\n");        fflush(stdout);
							if ( BOM_create_window( &bom_window ));
							//if(CFM_find( "ERC release and above", &rule ))
							if(CFM_find( "ERC release and above", &rule ));
							if(BOM_set_window_config_rule( bom_window, rule ));

							//if(PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
							if(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));

							printf (" CM_CreateSnapShotfromSingleSVR--rule count %d \n",rulefound);fflush(stdout);
							if (rulefound > 0)
							{
								close_tag = closurerule[0];
								printf (" CM_CreateSnapShotfromSingleSVR--closure rule found \n");fflush(stdout);
							}
							if(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));

							if(BOM_set_window_pack_all(bom_window, TRUE));
							if (BOM_set_window_top_line( bom_window, NULLTAG, primary1, NULLTAG, &top_line ));
							printf( " CM_CreateSnapShotfromSingleSVR--After BOM_set_window_top_line..\n");fflush(stdout);

							if (BOM_window_ask_variant_rules( bom_window,&BOmvarcnt2, &bom_variant_rule ));
							printf( " CM_CreateSnapShotfromSingleSVR--BOM_window_ask_variant_rule..\n");fflush(stdout);

							if(BOmvarcnt2>0)

							if(TCTYPE_ask_object_type(bom_variant_rule[0],&objTypeTag));
							if(TCTYPE_ask_name2(objTypeTag,&type_name));

							if ( top_line!=NULLTAG )
							{
								fprintf(stderr, "\n CM_CreateSnapShotfromSingleSVR--print Master second .\n"); fflush(stderr);

								if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines))   ;
								printf("\n CM_CreateSnapShotfromSingleSVR--before hiide LLlast Before setting option n_lines1: %d \n", n_lines1);

								if(bom_window != NULLTAG)
								{
									//printf("\n CM_CreateSnapShotfromSingleSVR--before inside bom_window-----\n"); fflush(stdout);
									if(BOM_window_hide_unconfigured(bom_window))   ;
									if(BOM_window_show_variants(bom_window))   ;
									VehName=(char *) MEM_alloc(20);

									printf("\n CM_CreateSnapShotfromSingleSVR--Found-->");fflush(stdout);

									if(AOM_ask_value_string(rev,"object_name",&childsvrname));

									itemId1234=subString(childsvrname,0,4);
									itemId123=subString(childsvrname,0,8);
									itemId12345=subString(childsvrname,11,1);

									tc_strcpy(VehName,"");
									tc_strcpy(VehName,itemId123);
									tc_strcat(VehName,itemId12345);

									tc_strcpy(projStr,"");
									tc_strcpy(projStr,",");
									tc_strcat(projStr,itemId1234);
									tc_strcat(projStr,",");

									printf("\t itemId1234: [%s]  VehName: [%s]  projStr: [%s] usrInfo1R: [%s]",itemId1234,VehName,projStr,usrInfo1R);fflush(stdout);

									if ((tc_strstr(usrInfo1R,projStr)!=NULL)&&(usrInfo1R!=NULL)) //allowing Altroz-way for project made live in control-object
									{
										printf("\t itemId12==> [%s] \n",itemId12);fflush(stdout);

										ITK_CALL(ITEM_find_item(VehName, &parent_master1));
										ITEM_ask_latest_rev(parent_master1, &VCrev);
									}
									else
									{
										itemId12 = tc_strtok(childsvrname,"_");

										printf("\t itemId12: [%s] \n",itemId12);fflush(stdout);

										ITK_CALL(ITEM_find_item(itemId12, &parent_master1));
										ITEM_ask_latest_rev(parent_master1, &VCrev);
									}

									tc_strcpy(TempVal,objectname); //Copying SVR Name first
									tc_strcat(TempVal,"_");
									tc_strcat(TempVal,username);
									tc_strcat(TempVal,"_");
									tc_strcat(TempVal,cCurrentAccessDate);
									tc_strcat(TempVal,"_Snapshot");

									printf("\n CM_CreateSnapShotfromSingleSVR--After inside bom_window----->  TempVal: [%s] \n",TempVal); fflush(stdout);

									if(BOM_window_apply_variant_configuration(bom_window,1,&rev));
									printf("\n CM_CreateSnapShotfromSingleSVR--After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

									//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
									if(BOM_window_hide_variants(bom_window))   ;
									if(BOM_create_snapshot(bom_window,TempVal,"Snapshot for SVR",&snapshot));
									if(snapshot!=NULLTAG)
									{
										printf("\n CM_CreateSnapShotfromSingleSVR--SnapShot is created for [%s] \n",TempVal); fflush(stdout);
										if(AOM_save_without_extensions( snapshot));
										if(AOM_refresh(snapshot,1));
										if(AOM_unlock(snapshot));
									}
									else
									{
										printf("\n CM_CreateSnapShotfromSingleSVR--snapshot Tag not found ?? \n\n");fflush(stdout);
									}

									if (VCrev != NULLTAG)
									{
										// to delete existing snapshot relation
										ITK_CALL(GRM_list_secondary_objects_only(VCrev,implemRelationType_t,&snapcnt,&extsnap));

										printf("\n CM_CreateSnapShotfromSingleSVR--snapcnt-----> [%d] \n",snapcnt); fflush(stdout);
										for(iy=0;iy<snapcnt;iy++)
										{
											printf("\n CM_CreateSnapShotfromSingleSVR--to find impacted items\n");fflush(stdout);

											ITK_CALL(GRM_find_relation(VCrev,extsnap[iy],implemRelationType_t,&tRelationExistab11));

											if(tRelationExistab11 != NULLTAG)
											{
												printf("\n CM_CreateSnapShotfromSingleSVR--Now deleting Relation Between VC and old Snap-shot \n");fflush(stdout);
												ITK_CALL(GRM_delete_relation(tRelationExistab11));
												printf("\n CM_CreateSnapShotfromSingleSVR--Relation deleted Successfully\n");fflush(stdout);
											}
										}
										// end to delete existing snapshot relation

										if(implemRelationType_t != NULLTAG)
										{
											if(GRM_create_relation(VCrev,snapshot,implemRelationType_t,NULLTAG,&Rel_task));
											if(GRM_save_relation  (Rel_task));
										}


										if(derivedFromSVRRelType_ta != NULLTAG)
										{
											int iz = 0 , DerSvrcnt = 0;
											tag_t *DerSvrSet = NULLTAG;
											tag_t tRelationExistab11ss = NULLTAG;

											if(GRM_list_secondary_objects_only(VCrev,derivedFromSVRRelType_ta,&DerSvrcnt,&DerSvrSet));
											for(iz=0; iz<DerSvrcnt; iz++)
											{
												if(GRM_find_relation(VCrev,DerSvrSet[iz],derivedFromSVRRelType_ta,&tRelationExistab11ss));
												if(tRelationExistab11ss != NULLTAG)
												{
													printf("\n iz:[%d] CM_CreateCCVfromSingleSVR---Now deleting older Relation Between CCVVC/VC/Veh and SVR. \n",iz);fflush(stdout);
													if(GRM_delete_relation(tRelationExistab11ss));
													printf("\n iz:[%d] CM_CreateCCVfromSingleSVR---older SVR Relation deleted Successfully from CCVVC/VC/Veh. \n",iz);fflush(stdout);
												}
											}
											// end to delete existing svr relation

											ITK_CALL(GRM_find_relation(VCrev,rev,derivedFromSVRRelType_ta,&tRelationExista));
											if (tRelationExista==NULLTAG)
											{
												printf("\n CM_CreateSnapShotfromSingleSVR--3.Now Creating Relation Between CCV and SVR \n");fflush(stdout);
												if(GRM_create_relation(VCrev,rev,derivedFromSVRRelType_ta,NULLTAG,&Rel_taska));
												if(GRM_save_relation  (Rel_taska));
												printf("\n CM_CreateSnapShotfromSingleSVR--Relation Created Successfully\n");fflush(stdout);
											}
										}
										else
										{
											printf("\n CM_CreateSnapShotfromSingleSVR--T5_DerivedFromSVR relation Tag not found ?? \n\n");fflush(stdout);
										}

										ITK_CALL(AOM_refresh(VCrev,0));
										ITK_CALL(AOM_unlock(VCrev));

										if(SVRDerRel_t != NULLTAG)
										{
											ITK_CALL(GRM_find_relation(rev,VCrev,SVRDerRel_t,&tRelationExistab));
											if (tRelationExistab==NULLTAG)
											{
												printf("\n CM_CreateSnapShotfromSingleSVR--Now Creating Relation Between SVR and CCV \n");fflush(stdout);
												if(GRM_create_relation(rev,VCrev,SVRDerRel_t,NULLTAG,&Rel_taskab));
												if(GRM_save_relation  (Rel_taskab));
												printf("\n CM_CreateSnapShotfromSingleSVR--Relation Created Successfully\n");fflush(stdout);
											}
										}
										else
										{
											printf("\n CM_CreateSnapShotfromSingleSVR--T5_SVRDerivesCCV relation Tag not found ?? \n\n");fflush(stdout);
										}
									} //End of condn if (VCrev != NULLTAG)
									else
									{
										printf("\n CM_CreateSnapShotfromSingleSVR--VCrev Tag not found ?? \n\n");fflush(stdout);
									}
								} // End of condn if(bom_window != NULLTAG)
							}
						}
					}
				}
			}
		}
	//	}

	printf("\n End of CM_CreateSnapShotfromSingleSVR ........\n");fflush(stdout);

	return ITK_ok;
}

//int SVRComp_RptAttach( EPM_action_message_t msg )
int SVRComp_RptAttach( tag_t DMLLcmTag )
{
	int	ifail	= 0;
	tag_t	root_task                       =NULLTAG;
	tag_t  	DMLRevTag                       =NULLTAG;
	//	tag_t   DMLLcmTag                       =NULLTAG;
	tag_t   objTypTag                       =NULLTAG;
	tag_t   *attachments            =NULL;
	tag_t   *DMLRevision            =NULL;
	int i=0,j=0,count=0,count_rev=0;
	logical is_latest;
	char *dmlNumber=NULL;
	char *dmlrelease_type=NULL;
	char   *ObjTyp=NULL;
	tag_t tsk_dml_rel_type;

//	CALLAPI(EPM_ask_root_task(msg.task,&root_task));
//	CALLAPI(EPM_ask_attachments (root_task,EPM_target_attachment,&count,&attachments));
//
//	printf("\nSVRComp_RptAttach::SVR Release No of attachments: %d",count);
//
//	if(count>0)
//	{
//		for(i=0;i<count;i++)
//		{
//			DMLLcmTag=attachments[i];

			if(TCTYPE_ask_object_type(DMLLcmTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));

			printf("\n RPT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
			{
				CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));

				if (tsk_dml_rel_type!=NULLTAG)
					CALLAPI(GRM_list_primary_objects_only(DMLLcmTag,tsk_dml_rel_type,&count_rev,&DMLRevision));
				printf("\n SVRComp_RptAttach number of ERC DML : %d",count);fflush(stdout);

				for (j=0;j<count_rev ;j++ )
				{
					CALLAPI(ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest));
					printf("\nSVR Release is_latest : %d\n",is_latest);fflush(stdout);

					if(is_latest != true)
					{
							printf("\nERC DML - Not latest\n");fflush(stdout);
					}else
					{
						DMLRevTag = DMLRevision[j];

						CALLAPI(AOM_ask_value_string(DMLRevTag,"item_id",&dmlNumber));
						CALLAPI( AOM_ask_value_string(DMLRevTag,"t5_rlstype",&dmlrelease_type));

						printf("\n DML Number - [%s] \n Release Type-[%s]\n",dmlNumber,dmlrelease_type);fflush(stdout);

						/*Only to be called it the ERC release type is vehicle*/
						if(strcmp(dmlrelease_type,"Veh")==0)
						{
							printf("\n Calling AttachSVRCompReportInWF\n");fflush(stdout);
							tag_t dmlObjs[] = {DMLRevTag};
							ITK_CALL(AttachSVRCompReportInWF(dmlObjs));
							printf("\n AttachSVRCompReportInWF Completed\n");fflush(stdout);
						}
						else
						{
							printf("\nRelease Type is not Vehicle.\n");fflush(stdout);
						}

						break;
					}
				}
			}
//		}
//	}

	printf("\n End of SVRComp_RptAttach ........\n");fflush(stdout);

	return ITK_ok;
}

int CM_Check_CCVForTechSpec(tag_t  DMLTaskTag)
{
	int i=0,j=0,k=0;
	//int status=ITK_ok;
	int ifail=0;
	int Itemscnt=0;
	int attachmentCount=0;
	int n_option_data=0,p1=0;
	int n_ves_2_save=0;
	int n_lines2=0;
	int n_lines3=0;
	int n_lines4=0;
	int rulefound= 0;
	int p2=0;
	int ss=0;
	int p4=0;
	int n_lines,n_lines1,Item_ID = 0;
	int IntAtr5=0;
	int rule_count=0;
	int count=0;
	int resultCount = 0;
	int n_entries = 1;
	int tscount = 0;

	char *obj_type=NULL;
	char *dmlNumber=NULL;
	char *revId=NULL;
	char **qryEntries=NULL;
	char **qryValues=NULL;
	char *usrInfo1=NULL;
	char *usrInfo2=NULL;
	char *ItemNumber=NULL;
	char *ItemNumberwithDml=NULL;
	char *ItemId = NULL;
	char *RevId = NULL;
	char *VCItemId = NULL;
	char *SVRType = NULL;
	char *v2_text=NULL;
	char **rulename = NULL;
	char **rulevalue = NULL;
	char *desc = NULL;
	char *varrul = NULL;
	char *CurrentRelStatus = NULL;
	char *Item_ID_str=NULL;
	char relation_name[TCTYPE_name_size_c+1];
	char *child_item_id=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_id156=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	char *ChildSVRname=NULL;
	char *child_bl_formula=NULL;
	char *child_bl_formula23=NULL;
	char *objecttype=NULL;
	char *TempVal =NULL;
	char *objectname=NULL;
	char *ProjDesc = NULL;
	char *Proj_PltFrm = NULL;
	char *Proj_BU = NULL;
	char *Proj_DesgOwnUnit = NULL;
	char *Proj_ProtoUnit = NULL;
	char *Proj_VCSubClass = NULL;
	char *val = NULL;
	char *parttype = NULL;
	char *ProjectID = NULL;
	char *group_name = NULL;
	char *ProjectClass = NULL;
	char *user_name_string = NULL;
	char *SesLoc = NULL;
	char *ccvRevId = NULL;
	char *CCVDesc = NULL;
	char *CCVDescDup = NULL;
	char *tsitem = NULL;

	char *qry_entries[1] = {"Name"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char *Proj_DesgOwnDept = (char *) MEM_alloc(10 * sizeof(char *));

	tag_t *taskAttachments=NULLTAG;
	tag_t *qryResults=NULLTAG;
	tag_t *DcrList=NULLTAG;
	tag_t *taskList=NULLTAG;
	tag_t *ItemsList=NULLTAG;
	tag_t *DcrItemsList=NULLTAG;
	tag_t *bom_views=NULLTAG;
	tag_t *saved_variant_rules=NULLTAG;
	tag_t *options=NULLTAG;
	tag_t *option1_rev=NULLTAG;
	tag_t *option2_rev=NULLTAG;
	tag_t *option_revs=NULLTAG;
	tag_t *ves_2_save=NULLTAG;
	tag_t *lines = NULLTAG;
	tag_t *lines2 = NULLTAG;
	tag_t *lines3 = NULLTAG;
	tag_t *lines4 = NULLTAG;
	tag_t *Newlines = NULLTAG;
	tag_t *status_list = NULLTAG;
	tag_t *closurerule = NULLTAG;
	tag_t *secondary_objects = NULLTAG;
	tag_t *techspec_objects = NULLTAG;
	tag_t *t5_Project = NULLTAG;

	tag_t rev=NULLTAG;
	tag_t rev1=NULLTAG;
	tag_t view_type= NULLTAG;
	tag_t rootTask_t=NULLTAG;
	tag_t primary1=NULLTAG;
	//tag_t ItemObj = NULLTAG;
	tag_t DcrItemObj=NULLTAG;
	tag_t DcrProblmItemsRelType=NULLTAG;
	tag_t DmlTaskRelationType_t=NULLTAG;
	tag_t DmlItemsRelation_t=NULLTAG;
	tag_t bom_view_type=NULLTAG;
	tag_t item=NULLTAG;
	tag_t bom_view= NULLTAG;
	tag_t e_block=NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t bom_window=NULLTAG;
	tag_t window2=NULLTAG;
	tag_t top_line=NULLTAG;
	tag_t top_line1=NULLTAG;
	tag_t rule =NULLTAG;
	tag_t Childobject=NULLTAG;
	tag_t Childobject1=NULLTAG;
	tag_t Childobject3=NULLTAG;
	tag_t Childobject4=NULLTAG;
	tag_t Childobject33=NULLTAG;
	tag_t dataset = NULLTAG;
	tag_t bom_variant_rule=NULLTAG;
	tag_t option1=NULLTAG;
	tag_t option2=NULLTAG;
	tag_t topline = NULLTAG;
	tag_t toggle_ve=NULLTAG;
	tag_t relation_type = NULLTAG;
	tag_t relation_type1 = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t Project_t = NULLTAG;
	tag_t GroupMem = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t user = NULLTAG;
	tag_t relation_type_tag = NULLTAG;
	tag_t user_tag = NULLTAG;

	void **option_data=NULL;

	logical list_changed=FALSE;
	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;


	printf("\n inside CM_Check_CCVForTechSpec Action Handler -----------\n");fflush(stdout);

//	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
//	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	ITK_CALL(GRM_find_relation_type("CMReferences",&DcrProblmItemsRelType));
	ITK_CALL(GRM_find_relation_type("T5_HasChildSVR",&DmlTaskRelationType_t));
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));

//	printf("\n CM_Check_CCVForTechSpec attachmentCount = %d\n",attachmentCount);fflush(stdout);
//	if(attachmentCount>0)
//	{
//		for(Itemscnt=0;Itemscnt<attachmentCount;Itemscnt++)
//		{
//			ITK_CALL(WSOM_ask_object_type2(taskAttachments[Itemscnt],&obj_type));

			ITK_CALL(WSOM_ask_object_type2(DMLTaskTag,&obj_type));
			printf("\n CM_Check_CCVForTechSpec Object Type = %s\n",obj_type);fflush(stdout);

			if(tc_strcasecmp(obj_type,"T5_ChangeTaskRevision")==0)
			{
				printf("\n inside query \n");fflush(stdout);

				char *id;
				char *Solid;
				char *TaskAnlyst =NULL;
				char *TaskAnlystDup =NULL;

//				ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"item_id" , &id));
				ERROR_CHECK(AOM_ask_value_string(DMLTaskTag,"item_id" , &id));

				printf("\n Task_id= %s",id);fflush(stdout);

//				ERROR_CHECK(AOM_ask_value_string(taskAttachments[Itemscnt],"analyst_user_id",&TaskAnlyst));
				ERROR_CHECK(AOM_ask_value_string(DMLTaskTag,"analyst_user_id",&TaskAnlyst));
				printf("\n Analyst for Task= %s",TaskAnlyst);fflush(stdout);

				if(TaskAnlyst)
				{
					tc_strdup(TaskAnlyst,&TaskAnlystDup);
				}
				printf( "TaskAnlystDup:%s\n", TaskAnlystDup);fflush(stdout);

				//ERROR_CHECK(GRM_find_relation_type("CMHasSolutionItem",&DmlItemsRelation_t));
//				ERROR_CHECK(GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects ));
				ERROR_CHECK(GRM_list_secondary_objects_only(DMLTaskTag,DmlItemsRelation_t,&count,&secondary_objects ));
				//GRM_list_secondary_objects_only(taskAttachments[Itemscnt],DmlItemsRelation_t,&count,&secondary_objects );

				if(count>0)
				{
					for(i=0;i<count;i++)
					{
						char *VCClass;
						ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_string" , &Solid));
						ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartType" , &parttype));
						ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_type" , &VCClass));
						ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"item_revision_id" , &ccvRevId));
						ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"object_desc" , &CCVDesc));

						if(CCVDesc)
						{
							tc_strdup(CCVDesc,&CCVDescDup);
						}
						printf("\n Solution Item= %s parttype=%s VCClass=%s ccvRevId=%s CCVDescDup=%s",Solid,parttype,VCClass,ccvRevId,CCVDescDup);fflush(stdout);
						//return;

						if(tc_strcmp(parttype,"VC")!=0)	//to skip part Type VC
						{
							if(tc_strstr(parttype,"V")!=NULL)	//allowing CCV/V
							{
								if(tc_strstr(ccvRevId,"NR")!=NULL)
								{
									char *projcode;
									char *DRStatus;
									tag_t  CurrentRoleTag = NULLTAG;
									char *roleName=NULL;
									printf("\n going to create Tech Spec"); fflush(stdout);

									ERROR_CHECK(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
									ERROR_CHECK(GRM_list_secondary_objects_only(secondary_objects[i],relation_type_tag,&tscount,&techspec_objects ));

									if(tscount==0)
									{
										//Query to custom project class
										ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_ProjectCode",&ProjectID));
										printf("\n MT:PP: ProjectID : %s",ProjectID);   fflush(stdout);
										if(ProjectID)
										{
											if(QRY_find2("Qury_Project", &queryTag));
											printf("\n MT:After Prd_Project: QRY_find");fflush(stdout);
											if (queryTag)
											{
												printf("\n MT:Found Query");fflush(stdout);
											}
											else
											{
												printf("\n MT:Not Found Query");fflush(stdout);
											}
											qry_values[0] = ProjectID;
											if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
											printf("\n MT: resultCount : %d\n", resultCount); fflush(stdout);

											if(resultCount > 0)
											{
												printf("\n MT:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
												Project_t = t5_Project[0];
												if (Project_t!=NULLTAG)
												{
													ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass));
													ERROR_CHECK(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc));
													ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm));
													ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU));
													ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_DsgnOwn",&Proj_DesgOwnUnit));
													ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_ProtoUnit",&Proj_ProtoUnit));
													ERROR_CHECK(AOM_ask_value_string(Project_t,"t5_ProjSubVehClass",&Proj_VCSubClass));

													printf("\n MT: ProjectClass:[%s] \n ProjDesc : %s \n Proj_PltFrm :[%s] \n Proj_BU:[%s] \n Proj_DesgOwnUnit[%s] \n Proj_ProtoUnit[%s]\n Proj_VCSubClass=[%s] \n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU,Proj_DesgOwnUnit,Proj_ProtoUnit,Proj_VCSubClass);   fflush(stdout);
													if(tc_strstr(Proj_DesgOwnUnit,"PUN")!=NULL)
													{
														Proj_DesgOwnDept="Pune-Design";
													}
													else if(tc_strstr(Proj_DesgOwnUnit,"JSR")!=NULL)
													{
														Proj_DesgOwnDept="JSR-Design";
													}
													else if(tc_strstr(Proj_DesgOwnUnit,"LKO")!=NULL)
													{
														Proj_DesgOwnDept="JSR-Design";
													}
													else if(tc_strstr(Proj_DesgOwnUnit,"AHD")!=NULL)
													{
														Proj_DesgOwnDept="AHD-Design";
													}
													else
													{
														printf("\n Proj_DesgOwnUnit is not matching with condition value");fflush(stdout);
													}

													printf("\n Proj_DesgOwnDept =%s",Proj_DesgOwnDept);fflush(stdout);
												}
											}
											//End Query custom project

											ERROR_CHECK(POM_get_user(&user_name_string, &user));
											ERROR_CHECK(SA_ask_current_location_code(&SesLoc));
											SA_ask_current_groupmember(&GroupMem);
											printf("\nGroupMem: %u SesLoc=%s\n",GroupMem,SesLoc);fflush(stdout);
											if(GroupMem !=NULLTAG)
											{
												//printObject(GroupMem);
												ERROR_CHECK(AOM_ask_value_string(GroupMem,"object_name",&group_name));
												printf("\ngroup_name session is pare  : %s\n",group_name);fflush(stdout);
											}
											ERROR_CHECK(SA_ask_current_role(&CurrentRoleTag));
											ERROR_CHECK(SA_ask_role_name2(CurrentRoleTag,&roleName));
											printf("\n\n  roleName : %s\n",roleName); fflush(stdout);

											ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_ProjectCode" , &projcode));
											ERROR_CHECK(AOM_ask_value_string(secondary_objects[i],"t5_PartStatus" , &DRStatus));
											//ERROR_CHECK(AOM_ask_value_string(user,"t5_ProjectCode" , &projcode));
											printf("\n projcode=%s DRStatus=%s ",projcode,DRStatus); fflush(stdout);
											printf("\n before func call  TechSpecCreFun: ProjectClass:[%s] \n CCVDescDup : %s \n Proj_PltFrm :[%s] \n Proj_BU:[%s] \n Proj_DesgOwnUnit[%s] \n Proj_ProtoUnit[%s]\n Proj_VCSubClass=[%s] \n Proj_DesgOwnDept=[%s] \n",ProjectClass,CCVDescDup,Proj_PltFrm,Proj_BU,Proj_DesgOwnUnit,Proj_ProtoUnit,Proj_VCSubClass,Proj_DesgOwnDept);   fflush(stdout);
											printf("\n\n  before func call  TechSpecCreFun: "); fflush(stdout);
											tag_t retTStag= NULLTAG;
											ERROR_CHECK(TechSpecCreFun(projcode,Proj_DesgOwnDept,Proj_DesgOwnUnit,Proj_VCSubClass,CCVDescDup,ProjectClass,&retTStag));
											printf("\n\n  After func call  TechSpecCreFun: "); fflush(stdout);
											if(retTStag!=NULLTAG)
											{
												//printObject(retTStag);
												printf("\n\n  inside create relation between CCV & Tech Spec: "); fflush(stdout);
												tag_t *techspecRevTag=NULLTAG;
												int num;
												ERROR_CHECK(AOM_ask_value_tags(retTStag, "revision_list",&num,&techspecRevTag));

												if(techspecRevTag!=NULL)
												{
													printf( "TaskAnlystDup:%s\n", TaskAnlystDup);fflush(stdout);
													if(TaskAnlystDup)
													{
														CALLAPI(SA_find_user2(TaskAnlystDup,&user_tag));
														if(user_tag!=NULLTAG)
														{
															//AOM_ask_value_tag(taskAttachments[Itemscnt] ,"owning_group", &GroupMem);
															AOM_ask_value_tag(DMLTaskTag ,"owning_group", &GroupMem);
															CALLAPI(AOM_set_ownership(retTStag,user_tag,GroupMem));
															CALLAPI(AOM_set_ownership(*techspecRevTag,user_tag,GroupMem));
														}
													}
													//ERROR_CHECK(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
													ERROR_CHECK(GRM_find_relation_type("T5_VCSpec", &relation_type_tag));
													tag_t relation_tag  = NULLTAG;
													ERROR_CHECK(GRM_create_relation(secondary_objects[i],techspecRevTag[0],relation_type_tag, NULLTAG, &relation_tag));
													ERROR_CHECK(GRM_save_relation(relation_tag));
													printf("\n\n  After create relation between CCV & Tech Spec: "); fflush(stdout);
													if(relation_tag)
													{
														printObject(relation_tag);
													}
												}
											}
											printf("\n\n  After printObject: "); fflush(stdout);

											////if(tc_strcmp(DRStatus,"DR4")==0 || tc_strcmp(DRStatus,"DR5")==0 || tc_strcmp(DRStatus,"AR4")==0 || tc_strcmp(DRStatus,"AR5")==0)
											////{
											////	//ERROR_CHECK(TechSpecCreFun(char *projcode ,char *OwnerDesDept,char *OwnerDesUnit,char *VcClass,char *Desc,char *FilePath));
											////	printf("\n eligible to create Tech Spec"); fflush(stdout);
											////}
											////else
											////{
											////	printf("\n not eligible to create Tech Spec"); fflush(stdout);
											////}
										}
									}
									else
									{
										ERROR_CHECK(AOM_ask_value_string(techspec_objects[0],"item_id" , &tsitem));
										printf("\n Tech Spec object[%s] is already available for this CCV [%s]",tsitem,Solid); fflush(stdout);
									}
								}
								else
								{
									printf("\n NON-NR revision is not eligible to create Tech Spec for Cluster SVR release process, it will auto-revise with VC.. \n"); fflush(stdout);
								}
							}
						}
						else
						{
							printf("\n Part Type VC[Vehicle Composition for unit BOM] is not applicable for TechSpec w.r.t Altroz case \n"); fflush(stdout);
						}
					}
					printf("\nTech Spec object creation for CCV w.r.t SVR WF has completed");fflush(stdout);
				}
			}
//		}
//	}

	printf("\n End of CM_Check_CCVForTechSpec ........\n");fflush(stdout);

	return ifail;
}




extern int ITK_user_main (int argc, char ** argv )
{
    int status = 0;
	int tskcnt=0, i=0;

	char *dml_no=NULL;
	char *DML_rlstype = NULL;
	char *DML_proj = NULL;
	char *RevTyp = NULL;
	char *tsk_object_type = NULL;
	char *tsk_object_name = NULL;

	tag_t *Dml_tasks = NULLTAG;

	tag_t dml_tag = NULLTAG;
	tag_t DMLRevTag = NULLTAG;
	tag_t RevTypTag = NULLTAG;

	dml_no=ITK_ask_cli_argument("-i=");

	if(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");
	if(ITK_auto_login( ));
    if(ITK_set_journalling( TRUE ));

	printf("\n dml_no: %s ",dml_no );

	if(ITEM_find_item(dml_no, &dml_tag));
	if (dml_tag != NULLTAG)
	{
		if(ITEM_ask_latest_rev(dml_tag, &DMLRevTag));
		if(TCTYPE_ask_object_type(DMLRevTag, &RevTypTag));
		if(TCTYPE_ask_name2(RevTypTag,&RevTyp));

		if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DML_rlstype));
		printf(" and DML_rlstype: [%s] ", DML_rlstype);fflush(stdout);

		if(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DML_proj));
		printf(" and DML_proj: [%s] ", DML_proj);fflush(stdout);

		if(TCTYPE_ask_object_type(DMLRevTag, &RevTypTag));
		if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
		printf("\n RevTyp type: [%s]\n", RevTyp);fflush(stdout);

		if(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&tskcnt,&Dml_tasks));
		printf("\n No. of tskcnt: %d ",tskcnt);fflush(stdout);

		if (tskcnt>0)
		{
			char *qry_entriesR[] = { "SYSCD","SUBSYSCD"}, *qry_valuesR[] = {"Project","AltrozWay"};
			int noOfCoObjectsR = 0;
			tag_t queryR = NULLTAG;
			tag_t *CoobjectsR = NULLTAG;
			char *usrInfo1R = NULL;
			char *projStr = NULL;

			usrInfo1R = (char *) MEM_alloc(250);
			projStr=(char *) MEM_alloc(10);
			
			tc_strcpy(usrInfo1R,"");
			tc_strcpy(projStr,"");
			
			ITK_CALL(QRY_find2("Control Objects...", &queryR));
			if (queryR !=NULLTAG)
			{
				printf("\n main:CM_CreateSnapShotfromSingleSVR--queryR found");fflush(stdout);
				ITK_CALL(QRY_execute(queryR,2, qry_entriesR, qry_valuesR, &noOfCoObjectsR, &CoobjectsR));
				printf("\n\n main:CM_CreateSnapShotfromSingleSVR--Total Number Of CoobjectsR Found ==[%d] \n",noOfCoObjectsR);fflush(stdout);

				if(noOfCoObjectsR>0)
				{
					ITK_CALL(AOM_ask_value_string(CoobjectsR[0],"t5_Userinfo1",&usrInfo1R));
					printf("\n main:CM_CreateSnapShotfromSingleSVR--usrInfo1R :[%s]\n",usrInfo1R);fflush(stdout);
				}
			}

			for (i=0;i<tskcnt ;i++ )
			{
				if(AOM_ask_value_string(Dml_tasks[i],"object_type",&tsk_object_type));
				if(AOM_ask_value_string(Dml_tasks[i],"object_name",&tsk_object_name));

				printf("\n VC=tsk_object_type: [%s]   tsk_object_name: [%s]  DML_proj: [%s]  usrInfo1R: [%s]",tsk_object_type,tsk_object_name,DML_proj,usrInfo1R);fflush(stdout);

				//16PP251B01 and 13PP253M87  13PP253N06

				tc_strcpy(projStr,"");
				tc_strcpy(projStr,",");
				tc_strcat(projStr,DML_proj);
				tc_strcat(projStr,",");

				if ((tc_strstr(usrInfo1R,projStr)!=NULL)&&(usrInfo1R!=NULL)) //allowing if project made live in control-object
				{
					printf("\n main:In if condition--Altroz BOM Root...."); fflush(stdout);
					status = vc_release(Dml_tasks[i]);
					printf("\n vc_release--status: [%d] \n",status); fflush(stdout);
				}
				else
				{
					printf("\n In if condition--Hornbill SVR Root...."); fflush(stdout);
					status = CM_CreateCCVfromSingleSVR(Dml_tasks[i]);
					printf("\n CM_CreateCCVfromSingleSVR--status: [%d] \n",status); fflush(stdout);
				}
		
				if (status ==0 )
				{
					status = CM_CreateSnapShotfromSingleSVR(Dml_tasks[i]);
					printf("\n CM_CreateSnapShotfromSingleSVR--status: [%d] \n",status); fflush(stdout);
				
					status = CM_Check_CCVForTechSpec(Dml_tasks[i]);
					printf("\n CM_Check_CCVForTechSpec--status: [%d] \n",status); fflush(stdout);
				
					status = SVRComp_RptAttach(Dml_tasks[i]);
					printf("\n SVRComp_RptAttach--status: [%d] \n",status); fflush(stdout);
				}
			}
		}
	}
	printf("\n End of the ITK_CM_CreateCCVFromSingleSVR Function\n"); fflush(stdout);
	ITK_CALL(POM_logout(false));

	return status;
}