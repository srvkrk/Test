/***************************************************************************
* Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File				:	GetBaseRevAsReleasedSingleLvlBOMExp.c
*  Created By		:	Neha Salunkhe
*  Created On		:	02/07/2024
*  Project			:	Tata Motors
*  Purpose			:	Get the non-color part rev with the option "As released structure" of uses colour coated with single level Colour BOM expansion
*
*  Usage: /plmpv16/bulkdata/omf9dev/devgroups/Neha/GetBaseRevAsReleasedColorStructureWithSingleLvlBOMExpansion/GetBaseRevAsReleasedSingleLvlBOMExp inp.txt
*****************************************************************************/

#define _CLMAIN_DEFNS
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#include <string.h>
#include <stdlib.h>
#include <malloc.h>

FILE*			fp				= NULL;
FILE*			fpO				= NULL;
FILE*			fpR				= NULL;
char*			colorPartNo		= NULL;
char*			rev				= NULL;
char*			seq				= NULL;
SetOfStrings	dbScopeBkp		= NULL;
ObjectPtr		genContextObj2	= NULL;
int				levl			= 0;
SetOfObjects	myPrefSet		= NULL;


char* subString(char* mainStringf ,int fromCharf,int toCharf);

SetOfObjects getColorSchemePartObj(string clrscm)
{
	status	dstat = OKAY ;
	int  mfail;
	SetOfObjects sColScheme	= NULL;
	SqlPtr sqlPtr = NULL ;

	if(sqlPtr)
		oiSqlDispose(sqlPtr);

	if ((dstat = oiSqlCreateSelect(&sqlPtr))) goto EXIT;
	if ((dstat = oiSqlWhereEQ(sqlPtr, "Nomenclature",clrscm))) goto EXIT;
	if ((dstat = oiSqlWhereAND(sqlPtr))) goto EXIT;
	if ((dstat = oiSqlWhereEQ(sqlPtr,"Superseded","-"))) goto EXIT;
	if ((dstat = oiSqlWhereAND(sqlPtr))) goto EXIT;
	if ((dstat = oiSqlWhereLike(sqlPtr, "OwnerName","%Release Vault"))) goto EXIT;
	if ((dstat = QueryWhere("t5ClSchm",sqlPtr,&sColScheme,&mfail)))goto EXIT;

EXIT:
	return sColScheme;
}

status GetRevAttachedToNonColor(ObjectPtr ColorPart,SetOfObjects *hasnonclrmstrObjects,int mfail)
{
	char *mod_name = "GetRevAttachedToNonColor";
	string AssyNo = NULL;
	string AssyNoDup = NULL;
	SqlPtr sql = NULL;
	ObjectPtr ColorPartNext = NULL;
	SetOfObjects partObjs = NULL;
	SetOfObjects nonclrmstrObjects = NULL;
	SetOfObjects anonclrmstrObjects = NULL;
	status dstat = OKAY ;
	int foundmatch = 0;
	int iPartIndex = 0;
	ObjectPtr genContextObj = NULL;
	ObjectPtr CtxtObj = NULL;
	string viewName = NULL;
	string confg_class = NULL;

	if(dstat = IntSetUpContext(objClass(ColorPart),ColorPart,&genContextObj,&mfail)) goto CLEANUP;
	if(genContextObj)
	{
		if(dstat = GetCfgCtxtObjFromCtxt(DSesGnCClass,genContextObj,&CtxtObj,&mfail))goto CLEANUP;
		if(dstat = objGetAttribute(CtxtObj, NavigateViewNameAttr, &viewName))goto CLEANUP;
		if(dstat = objGetClass(CtxtObj, &confg_class)) goto CLEANUP;
		if(CtxtObj)
		{
			if(dstat = objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"))goto CLEANUP;
			if(dstat = objSetAttribute(CtxtObj,PsmExpIncludeZeroQtyAttr,"+"))goto CLEANUP;
			if(dstat = SetNavigateViewPref(CtxtObj,TRUE,"EAS","STD",&mfail)) goto CLEANUP;
			if(dstat = objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","-")) goto CLEANUP;
			if(dstat = objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","-")) goto CLEANUP;
			if(dstat = objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","-")) goto CLEANUP;
			if(dstat = objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","-")) goto CLEANUP;
			if(dstat = objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","-")) goto CLEANUP;
			if(dstat = objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+")) goto CLEANUP;
			if(dstat = objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","-")) goto CLEANUP;
			if(dstat = objSetObject(genContextObj,ConfigCtxtBlobAttr,CtxtObj));
			if(dstat = SetExpOnRevInCtxt(DSesGnCClass,genContextObj,"PscLastRev",&mfail));
		}
	}
	
	if(dstat = objGetAttribute(ColorPart, "PartNumber", &AssyNo)) goto CLEANUP;
	if(!nlsIsStrNull(AssyNo))
	{
		AssyNoDup = nlsStrDup(AssyNo);
	}

	if(	(dstat = oiSqlCreateSelect(&sql)) ||
		(dstat = oiSqlWhereBegParen(sql)) ||
		(dstat = oiSqlWhereEQ(sql,"PartNumber",AssyNoDup)) ||
		(dstat = oiSqlAscOrder(sql,"CreationDate")) ||
		(dstat = oiSqlWhereEndParen(sql)) ||
		(dstat = QueryWhere("Part",sql,&partObjs,&mfail)) ) goto CLEANUP;

	if(dstat = ulyFindObjectInSet(ColorPart,partObjs,"Revision",0,&foundmatch)) goto CLEANUP;
	printf(" In GetRevAttachedToNonColor");fflush(stdout);
	printf(" foundmatch in GetRevAttachedToNonColor:%d",foundmatch);fflush(stdout);
	if(foundmatch<0)
	{
		printf("No Match Found");fflush(stdout);
	}
	for(iPartIndex = foundmatch+1; iPartIndex <setSize(partObjs); iPartIndex++)
	{
		ColorPartNext = NULL;
		ColorPartNext = setGet(partObjs, iPartIndex);/*gettging last but prevoius reset to 0*/
		if(ColorPartNext!=NULL)
		{
			if (dstat = ExpandRelationWithCtxt("t5ClInfo",ColorPartNext,"t5ColPrtforAsm",genContextObj,SC_SCOPE_OF_SESSION,NULL,&nonclrmstrObjects,&anonclrmstrObjects,&mfail)) ;
			if(setSize(nonclrmstrObjects)>0)
			{
				printf(" Got the Next Revision Attached to Non Color");fflush(stdout);
				*hasnonclrmstrObjects = nonclrmstrObjects;
				printf(" SetSize:%d",setSize(*hasnonclrmstrObjects));fflush(stdout);
				break;
			}
		}
	}

CLEANUP:
	if (AssyNoDup) if(!nlsStrFree ( AssyNoDup )) goto EXIT ;
	if(sql) oiSqlDispose(sql); sql = NULL;
	if(ColorPartNext) objDispose(ColorPartNext);  ColorPartNext = NULL;
	if(partObjs)objDisposeAll(partObjs); partObjs = NULL;
	if(nonclrmstrObjects)objDisposeAll(nonclrmstrObjects); nonclrmstrObjects = NULL;
 	if (dstat != OKAY)
		dlow_return_trace (mod_name, dstat);
EXIT:
 return  dstat;
}

int GetInformation(ObjectPtr colourPart,ObjectPtr UsesPartObj,ObjectPtr UsesPartRel,int levl,integer mfail)
{
	status  dstat  = OKAY;

	string PartNumber		= NULL;
	string PartNumberDup	= NULL;
	string Revision			= NULL;
	string RevisionDup		= NULL;
	string Sequence			= NULL;
	string SequenceDup		= NULL;
	string partQuantity		= NULL;
	string partQuantityDup	= NULL;
	string relStatus		= NULL; 
	string relStatusDup		= NULL; 
	
	printf(" Inside GetInformation....!\n");

	PartNumber=NULL;                                                                 
	PartNumberDup=NULL; 
	if(dstat = objGetAttribute(UsesPartObj,"PartNumber", &PartNumber))goto EXIT;       
	if(!nlsIsStrNull(PartNumber))                                                    
	{                                                                              
		PartNumberDup = nlsStrDup(PartNumber);                                           
	}
	
	Revision=NULL;                                                                 
	RevisionDup=NULL; 
	if(dstat = objGetAttribute(UsesPartObj,"Revision", &Revision))goto EXIT;       
	if(!nlsIsStrNull(Revision))                                                    
	{                                                                              
		RevisionDup = nlsStrDup(Revision);                                           
	}  

	Sequence=NULL;                                                                 
	SequenceDup=NULL; 
	if(dstat = objGetAttribute(UsesPartObj,"Sequence", &Sequence))goto EXIT;       
	if(!nlsIsStrNull(Sequence))                                                    
	{                                                                              
		SequenceDup = nlsStrDup(Sequence);                                           
	}

	partQuantity=NULL;
	partQuantityDup=NULL;
	if(dstat = objGetAttribute(UsesPartRel,"Quantity",&partQuantity)) goto EXIT;
	if(!nlsIsStrNull(partQuantity))
	{
		partQuantityDup =  nlsStrDup(partQuantity);
	}

	relStatus=NULL;
	relStatusDup=NULL;
	if(dstat = objGetAttribute(UsesPartObj,"OwnerName",&relStatus)) goto EXIT;
	if(!nlsIsStrNull(relStatus))
	{
		relStatusDup =  nlsStrDup(relStatus);
	}

	printf(" Printing in single level BOM Report\n %d,%s,%s,%s,%s,%s\n",levl,PartNumberDup,RevisionDup,SequenceDup,partQuantityDup,relStatusDup); fflush(stdout);
	fprintf(fpO, "\n%d,%s,%s,%s,%s,%s,-,",levl,PartNumberDup,RevisionDup,SequenceDup,partQuantityDup,relStatusDup); fflush(fpO);

	CLEANUP:
		printf(" In cleanup GetInformation\n");fflush(stdout);
	
	EXIT:
		return dstat;
}

status ExtractColorBOM(ObjectPtr colourPart,ObjectPtr objColScheme, SetOfObjects myPrefSet,int levl)
{
	status	dstat = OKAY ;
	integer mfail;

	string			StrPartType					= NULL;
	string			ColPartNum					= NULL;
	string			ColPartNumDup				= NULL;
	string			ColPartDisplayName			= NULL;
	string			ColPartDisplayNameDup		= NULL;
	string			CoatedIdAssembly			= NULL;
	string			CoatedIdAssemblyDup			= NULL;
	string			ColourIndAssembly			= NULL;
	string			ColourIndAssemblyDup		= NULL;
	string			CoatedIdScheme				= NULL;
	string			CoatedIdSchemeDup			= NULL;
	string			ColurSchemeDisplayedName	= NULL;
	string			ColurSchemeDisplayedNameDup = NULL;
	string			viewName					= NULL;
	string			confg_class					= NULL;
	string			StrDesGrp					= NULL;
	string			assyCompCode				= NULL;
	string			colorid						= NULL;
	string			coatedid					= NULL;
	string			DisplayName					= NULL;
	string			DisplayNameDup				= NULL;
	string			cColorid					= NULL;
	string			cColoridDup					= NULL;
	string			temp1						= NULL;
	string			temp1Dup					= NULL;
	string			partnum						= NULL;
	string			partnumDup					= NULL;
	string			ClrIndUsesPart				= NULL;
	string			ClrIndUsesPartDup			= NULL;
	string			CoatedIdUsesPart			= NULL;
	string			CoatedIdUsesPartDup			= NULL;
	string			UsesPartCompCode			= NULL;
	string			UsesPartCompCodeDup			= NULL;
	string			compcode					= NULL;
	string			compcodeDup					= NULL;
	string			tmpStr						= NULL;
	string			strColSrl					= NULL;
	string			clridColorPart				= NULL;
	string			strColIDinSch				= NULL;
	string			ScmCategory					= NULL;
	string			ScmCategoryDup				= NULL;
	string			usesColourCoated			= NULL;
	string			usesColourCoatedDup			= NULL;
	string			usesColourColourid			= NULL;
	string			usesColourColouridDup		= NULL;
	string			clridColorInd				= NULL;
	string			clridColorIndDup			= NULL;
	string			clridCoatedInd				= NULL;
	string			clridCoatedIndDup			= NULL;
	string			clridClrPart				= NULL;
	string			clridClrPartDup				= NULL;
	string			clridClrPartOwnNm			= NULL;
	string			clridClrPartOwnNmDup		= NULL;
	string			nonColPartNum				= NULL;
	string			nonColPartNumDup			= NULL;
	string			rev							= NULL;
	string			revDup						= NULL;
	string			seq							= NULL;
	string			seqDup						= NULL;

	SetOfObjects	UsesPartVObjs				= NULL;
	SetOfObjects	UsesPartVRels				= NULL;
	SetOfObjects	hasnonclrmstrObjects		= NULL;
	SetOfObjects	ahasnonclrmstrObjects		= NULL;
	SetOfObjects	t5BasicItmRevs				= NULL;
	SetOfObjects	at5BasicItmRevs				= NULL;
	SetOfObjects	UsesPartObjs				= NULL;
	SetOfObjects	UsesPartRels				= NULL;
	SetOfObjects	t5ItmMstr					= NULL;
	SetOfObjects	t5ItmMstrRel				= NULL;
	SetOfObjects	clrParts					= NULL;
	SetOfObjects	clrRels						= NULL;
	SetOfObjects	t5CoatItmMstr				= NULL;
	SetOfObjects	t5CoatItmMstrRel			= NULL;
	SetOfObjects	clrCoatParts				= NULL;
	SetOfObjects	clrCoatRels					= NULL;

	ObjectPtr		CtxtObj						= NULL;
	ObjectPtr		UsesPartVObj				= NULL;
	ObjectPtr		UsesPartVRel				= NULL;
	ObjectPtr		hasnonclrmstrptr			= NULL;
	ObjectPtr		prtObj						= NULL;
	ObjectPtr		UsesPartObj					= NULL;
	ObjectPtr		UsesPartRel					= NULL;
	ObjectPtr		clrPart						= NULL;
	ObjectPtr		clrRel						= NULL;

	boolean			isSchemeMatch				= FALSE;
	boolean			CmpCodefound				= FALSE;

	SetOfStrings	setFromString				= NULL;
	char			*StrGet						= NULL;

	int	xv,j,compColIndYExist,returnflag,m,SchemeFlag,cci,ClrIdMacth3,ClrPrtOwnerNm,x = 0;

	printf("\n I am inside of ExtractColorBOM function \n");
	
	if (dstat = SetUpContext(objClass(colourPart), colourPart, &genContextObj2,&mfail))goto CLEANUP;
	if(genContextObj2)
	{
		if(dstat = GetCfgCtxtObjFromCtxt(DSesGnCClass,genContextObj2,&CtxtObj,&mfail))goto CLEANUP;
		if(dstat = objGetAttribute(CtxtObj, NavigateViewNameAttr, &viewName))goto CLEANUP;
		if(dstat = objGetClass(CtxtObj, &confg_class)) goto CLEANUP;
		if(CtxtObj)
		{
			if(dstat = objSetAttribute(CtxtObj,CfgItemIdAttr,"GlobalCtxt"))goto CLEANUP;  
			if(dstat=SetNavigateViewPref(CtxtObj,TRUE,"EAS","ERC",&mfail)) goto CLEANUP;
			if (dstat =objNameValueSet(CtxtObj,LCStateListAttr,"LcsErcRlzd","+"))goto CLEANUP;
			if (dstat =objNameValueSet(CtxtObj,LCStateListAttr,"LcsAPLWrkg","+"))goto CLEANUP;
			if (dstat =objNameValueSet(CtxtObj,LCStateListAttr,"LcsAplRlzd","+"))goto CLEANUP;
			if (dstat =objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDRlzd","+"))goto CLEANUP;
			if (dstat =objNameValueSet(CtxtObj,LCStateListAttr,"LcsSTDWrkg","+"))goto CLEANUP;
			if (dstat =objNameValueSet(CtxtObj,LCStateListAttr,"LcsReview","-"))goto CLEANUP;
			if (dstat =objNameValueSet(CtxtObj,LCStateListAttr,"LcsWorking","-"))goto CLEANUP;
			if (dstat = objSetObject(genContextObj2, ConfigCtxtBlobAttr, CtxtObj)) goto CLEANUP;
			if (dstat = SetExpOnRevInCtxt(DSesGnCClass,genContextObj2,"PscLastRev",&mfail))goto CLEANUP;
		}
	}

	if(dstat = objGetAttribute(colourPart,"PartType",&StrPartType)) goto EXIT;
	if(dstat = objGetAttribute(colourPart,"PartNumber",&ColPartNum)) goto EXIT;
	if(!nlsIsStrNull(ColPartNum))
	{
		ColPartNumDup = nlsStrDup(ColPartNum);
	}
	if(dstat = objGetAttribute(colourPart,"DisplayedName",&ColPartDisplayName)) goto EXIT;
	if(!nlsIsStrNull(ColPartDisplayName))
	{
		ColPartDisplayNameDup = nlsStrDup(ColPartDisplayName);
	}
	if(dstat = objGetAttribute(colourPart,"t5Coated",&CoatedIdAssembly)) goto EXIT;
	if (!nlsIsStrNull(CoatedIdAssembly))
	{
		CoatedIdAssemblyDup = nlsStrDup(CoatedIdAssembly);
	}

	if(dstat = objGetAttribute(colourPart,"t5ColourInd",&ColourIndAssembly)) goto EXIT;
	if (!nlsIsStrNull(ColourIndAssembly))
	{
		ColourIndAssemblyDup = nlsStrDup(ColourIndAssembly);
	}

	if((nlsStrCmp(CoatedIdAssemblyDup,"C") != 0) || nlsStrCmp(ColourIndAssemblyDup,"N") != 0)
	{
		if(dstat = objGetAttribute(objColScheme,"t5Coated",&CoatedIdScheme)) goto EXIT;
		if (!nlsIsStrNull(CoatedIdScheme))
		{
			CoatedIdSchemeDup = nlsStrDup(CoatedIdScheme);
		}
	}

	if(dstat = objGetAttribute(objColScheme,"Nomenclature",&ColurSchemeDisplayedName)) goto EXIT;
	if(!nlsIsStrNull(ColurSchemeDisplayedName))
	{
		ColurSchemeDisplayedNameDup = nlsStrDup(ColurSchemeDisplayedName);
	}

	printf(" [%s] Part Type: [%s]\n",ColPartDisplayNameDup,StrPartType); fflush(stdout);
	
	if(nlsStrCmp(StrPartType,"V")==0)
	{

		printf(" This is Vehicle..expand for Uses Parts");  fflush(stdout);
		if(dstat = ExpandRelationWithCtxt("AsRevRev",colourPart,"PartsInAssembly",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&UsesPartVObjs,&UsesPartVRels,&mfail)) goto CLEANUP;
		printf(" SetSize:[%d]",setSize(UsesPartVObjs));
		if(setSize(UsesPartVObjs)>0)
		{
			for( xv = 0 ; xv < setSize(UsesPartVObjs) ; xv++)
			{
				UsesPartVObj = setGet(UsesPartVObjs,xv);
				UsesPartVRel = setGet(UsesPartVRels,xv);

				GetInformation(colourPart,UsesPartVObj,UsesPartVRel,levl,mfail);
			}
		}
	}
	else
	{
		if(dstat = objGetAttribute(colourPart,"t5DesignGroup",&StrDesGrp)) goto EXIT;
		if((nlsStrCmp(StrPartType,"T")==0)&& (nlsStrCmp(StrDesGrp,"98")==0))
		{
			printf(" This is TPL 98..expand for Uses Parts");
			if(dstat = ExpandRelationWithCtxt("AsRevRev",colourPart,"PartsInAssembly",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&UsesPartVObjs,&UsesPartVRels,&mfail)) goto CLEANUP;
			if(setSize(UsesPartVObjs)>0)
			{
				for( xv = 0 ; xv < setSize(UsesPartVObjs) ; xv++)
				{
					UsesPartVObj = setGet(UsesPartVObjs,xv);
					UsesPartVRel = setGet(UsesPartVRels,xv);

					GetInformation(colourPart,UsesPartVObj,UsesPartVRel,levl,mfail);
				}
			}
			goto CLEANUP;
		}
		else if(nlsStrCmp(StrPartType,"VC")==0)
		{
			printf(" Part Type is :%s",StrPartType);  fflush(stdout);
		}
		else if(nlsStrCmp(StrPartType,"A")==0)
		{
			if(dstat = objGetAttribute(colourPart,"t5PrtCatCode",&assyCompCode)) goto EXIT;
			printf(" bComcode:[%s]",assyCompCode);

			if(nlsStrCmp(assyCompCode,"BODY_SHELL")==0)
			{
				if(dstat = ExpandRelationWithCtxt("AsRevRev",colourPart,"PartsInAssembly",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&UsesPartVObjs,&UsesPartVRels,&mfail)) goto CLEANUP;
				printf(" Uses Parts under Body Shell :%d",setSize(UsesPartVObjs));
				if(UsesPartVObjs)
				{
					for( xv = 0 ; xv < setSize(UsesPartVObjs) ; xv++)
					{
						UsesPartVObj = setGet(UsesPartVObjs,xv);
						UsesPartVRel = setGet(UsesPartVRels,xv);

						GetInformation(colourPart,UsesPartVObj,UsesPartVRel,levl,mfail);
					}
				}
			 }
		}
	}

	if (dstat = ExpandRelationWithCtxt("t5ClInfo",colourPart,"t5ColPrtforAsm",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&hasnonclrmstrObjects,&ahasnonclrmstrObjects,&mfail)) goto CLEANUP;
	if(setSize(hasnonclrmstrObjects)<1)
	{
		if(dstat = GetRevAttachedToNonColor(colourPart,&hasnonclrmstrObjects,mfail)) goto CLEANUP;
		printf(" 2.After calling GetRevAttachedToNonColor setSize:%d",setSize(hasnonclrmstrObjects));
	}

	if(setSize(hasnonclrmstrObjects)>0)
	{
		hasnonclrmstrptr = setGet(hasnonclrmstrObjects,0);

		if(dstat = ExpandRelationWithCtxt("ItemRev",hasnonclrmstrptr,"StrucBIRevsOfItemMstr",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&t5BasicItmRevs,&at5BasicItmRevs,&mfail))  goto CLEANUP;
		if(setSize(t5BasicItmRevs)>0)
		{
			prtObj = setGet(t5BasicItmRevs,0);
		}
	}

	if(dstat = objGetAttribute(prtObj,"t5ColourInd",&colorid)) goto EXIT;
	if(dstat = objGetAttribute(prtObj,"t5Coated",&coatedid)) goto EXIT;

	if((nlsStrCmp(colorid,"Y")==0) || (nlsStrCmp(coatedid,"Y")==0))
	{
		printf(" =========================For new color part %s\n",colorid);
		
		t5FreeSetOfObjects(UsesPartObjs);
		t5FreeSetOfObjects(UsesPartRels);

		if(dstat = objGetAttribute(prtObj, "DisplayedName", &DisplayName))goto EXIT;
		if(!nlsIsStrNull(DisplayName))
		{
			DisplayNameDup = nlsStrDup(DisplayName);
		}
		if(dstat = objGetAttribute(prtObj, "PartNumber", &nonColPartNum))goto EXIT;
		if(!nlsIsStrNull(nonColPartNum))
		{
			nonColPartNumDup = nlsStrDup(nonColPartNum);
		}
		if(dstat = objGetAttribute(prtObj, "Revision", &rev))goto EXIT;
		if(!nlsIsStrNull(rev))
		{
			revDup = nlsStrDup(rev);
		}
		if(dstat = objGetAttribute(prtObj, "Sequence", &seq))goto EXIT;
		if(!nlsIsStrNull(seq))
		{
			seqDup = nlsStrDup(seq);
		}
		printf(" ****************************************************************************\n");
		printf(" Colour [%s] NonColour Partnumber:[%s]\n",ColPartDisplayNameDup,DisplayNameDup);
		printf(" ****************************************************************************\n");
		
		//print in file of Part_Rev_Seq_Scheme.txt
		fprintf(fp, "%s#%s#%s,\n",nonColPartNumDup,revDup,seqDup); fflush(fp);

		if(dstat = ExpandRelationWithCtxt("AsRevRev",prtObj,"PartsInAssembly",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&UsesPartObjs,&UsesPartRels,&mfail)) goto CLEANUP;
		if(dstat = objGetAttribute(prtObj,"PartNumber",&temp1)) goto EXIT;
		
		for(j=0;j<setSize(UsesPartObjs);j++)
		{
			if(dstat = objGetAttribute(setGet(UsesPartObjs,j),"t5ColourInd",&cColorid)) goto EXIT;
			if(!nlsIsStrNull(cColorid))
			{
				cColoridDup = nlsStrDup(cColorid);
			}
		
			if((nlsStrCmp(cColoridDup,"Y") ==0))
			{
				compColIndYExist = 1;
				break;
			}
		}
		
		if(!nlsIsStrNull(temp1))
		{
			temp1Dup = nlsStrDup(temp1);
		}

		printf(" [%s] Uses parts count [%d]\n",DisplayNameDup,setSize(UsesPartObjs));

		if(setSize(UsesPartObjs)>0)
		{
			for(j=0;j<setSize(UsesPartObjs);j++)
			{
				if(dstat = objGetAttribute(setGet(UsesPartObjs,j),"PartNumber",&partnum)) goto EXIT;
				if(!nlsIsStrNull(partnum))
				{
					partnumDup = nlsStrDup(partnum);
				}
				if(dstat = objGetAttribute(setGet(UsesPartObjs,j),"t5ColourInd",&ClrIndUsesPart)) goto EXIT;
				if(!nlsIsStrNull(ClrIndUsesPart))
				{
					ClrIndUsesPartDup = nlsStrDup(ClrIndUsesPart);
				}
				if(dstat = objGetAttribute(setGet(UsesPartObjs,j),"t5Coated",&CoatedIdUsesPart)) goto EXIT;
				if(!nlsIsStrNull(CoatedIdUsesPart))
				{
					CoatedIdUsesPartDup = nlsStrDup(CoatedIdUsesPart);
				}
			
				if(dstat = objGetAttribute(setGet(UsesPartObjs,j),"t5PrtCatCode",&UsesPartCompCode)) goto EXIT;
				if(!nlsIsStrNull(UsesPartCompCode))
				{
					UsesPartCompCodeDup = nlsStrDup(UsesPartCompCode);
				}
				else
				{
					UsesPartCompCodeDup = nlsStrDup("");
				}
			
				printf(" %s UsesPart:[%s] ColInd:[%s]\n",temp1Dup,partnumDup,ClrIndUsesPart);
				UsesPartObj = setGet(UsesPartObjs,j);
				UsesPartRel = setGet(UsesPartRels,j);
			
				if(!nlsStrCmp(ClrIndUsesPart,"Y") && (!nlsIsStrNull(UsesPartCompCodeDup)))
				{
					if (dstat = ExpandRelationWithCtxt(ItemRevClass,UsesPartObj,"ItemMstrForStrucBIRev",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&t5ItmMstr,&t5ItmMstrRel,&mfail))  goto EXIT;
					if(setSize(t5ItmMstr)>0)
					{
					if (dstat = ExpandRelationWithCtxt("t5ClInfo",setGet(t5ItmMstr,0),"t5AsmhasColPrt",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&clrParts,&clrRels,&mfail)) goto EXIT ;
					returnflag = 0;
			
					isSchemeMatch = FALSE;
					if(setSize(clrParts)>0)
					{
						if(dstat = objGetAttribute(UsesPartObj,"t5PrtCatCode",&compcode)) goto EXIT;
						if(!nlsIsStrNull(compcode))
						{
							compcodeDup = nlsStrDup(compcode);
						}
						printf("\taComcode:[%s]",compcodeDup);
			
						t5ObjGetTableAttribute(objColScheme,"t5SchFullTab","t5PrtCatCode",compcodeDup,"t5ClSrl",&tmpStr,&mfail);
						if(tmpStr)
						{
							nlsStrTrimTrailWhiteSpace(tmpStr);
							strColSrl=nlsStrDup(tmpStr);
			
							printf("\tSchColourSrl:[%s]",strColSrl);
							if(nlsStrCmp(strColSrl,"NOMATCH")==0)
							{
								printf("\tcolor srl in the scheme is NOMATCH hence copying noncolour partno");  fflush(stdout);
			
								isSchemeMatch = FALSE;
								CmpCodefound = FALSE;
								returnflag = 1;
							}
							else
							{
								CmpCodefound = TRUE;
								setFromString = low_set_create(200);
								StrGet=strtok(strColSrl, ",");
								while (StrGet!=NULL)
								{
									low_set_add_str(setFromString,StrGet);
									StrGet=strtok(NULL, ",");
								}
								printf("\tSchColourSrlTKN:");  fflush(stdout);
			
								for (m=0;m< 2;m++)
								{
									tmpStr = low_set_get_str(setFromString,m);
									printf(",[%d:%s]",m,tmpStr); fflush(stdout);
								}
								if(!nlsIsStrNull(tmpStr))
								{
									nlsStrTrimTrailWhiteSpace(tmpStr);
									strColIDinSch=nlsStrDup(tmpStr);
								}
								printf("\tSchmColorId:[%s]",strColIDinSch); fflush(stdout);
								isSchemeMatch = FALSE;
								/*printf("\nColourUsesPartCount:%d",setSize(clrParts));*/
								ClrIdMacth3=0;
								ClrPrtOwnerNm=0;
								for( x = 0 ; x < setSize(clrParts) ; x++)
								{
									clrPart = setGet(clrParts,x);
									clrRel =  setGet(clrRels,x);
			
									if(dstat = objGetAttribute(clrPart,"t5ColourID",&clridColorPart)) goto EXIT;
									if(dstat = objGetAttribute(clrPart,"t5ColourInd",&clridColorInd)) goto EXIT;
									if(!nlsIsStrNull(clridColorInd))
									{
										clridColorIndDup = nlsStrDup(clridColorInd);
									}
									if(dstat = objGetAttribute(clrPart,"t5Coated",&clridCoatedInd)) goto EXIT;
									if(!nlsIsStrNull(clridCoatedInd))
									{
										clridCoatedIndDup = nlsStrDup(clridCoatedInd);
									}
									if(dstat = objGetAttribute(clrPart,"PartNumber",&clridClrPart)) goto EXIT;
									if(!nlsIsStrNull(clridClrPart))
									{
										clridClrPartDup = nlsStrDup(clridClrPart);
									}
									if(dstat = objGetAttribute(clrPart,"OwnerName",&clridClrPartOwnNm)) goto EXIT;
									if(!nlsIsStrNull(clridClrPartOwnNm))
									{
										clridClrPartOwnNmDup = nlsStrDup(clridClrPartOwnNm);
									}
									printf(" ColorUserPart:%s:%s:%s:%s\n",clridClrPartDup,clridCoatedIndDup,clridColorIndDup,clridClrPartOwnNmDup); fflush(stdout);
									printf(" nonColorPart:%s:%s:%s:\n",partnumDup,ClrIndUsesPartDup,CoatedIdUsesPartDup); fflush(stdout);
			
									if((nlsStrCmp(CoatedIdAssemblyDup,"C")==0) && (nlsStrCmp(ClrIndUsesPartDup,"Y")==0) && (nlsStrCmp(CoatedIdUsesPartDup,"Y")==0))
									{
										if(!nlsStrCmp(clridCoatedIndDup,"N") && !nlsStrCmp(clridColorIndDup,"C"))
										{
											printf("\tUses Color Part Loop");
											continue;
										}
									}
			
									if (nlsStrCmp(strColIDinSch,clridColorPart)==0)
									{
										ClrIdMacth3=0;
										if((nlsStrCmp(CoatedIdSchemeDup,"N")==0) && (nlsStrCmp(CoatedIdAssemblyDup,"N")==0)&& (nlsStrCmp(CoatedIdUsesPartDup,"Y")==0)&&(nlsStrCmp(clridCoatedIndDup,"C")==0))
										{
											continue;
										}
										
										printf("\tColor ID match found:%s %s",strColIDinSch,clridColorPart); fflush(stdout);
			
										printf(" 1.Child part:[%s] OwnerName:[%s]\n",clridClrPartDup,clridClrPartOwnNmDup);fflush(stdout);
												
										isSchemeMatch = TRUE;
										returnflag = 1;
										GetInformation(colourPart,clrPart,UsesPartRel,levl,mfail);
										break;
									}
									else
									{
										printf("\tColor ID match not found SchmCLRID:[%s] PtrCLRID:[%s] compcode:[%s]",strColIDinSch,clridColorPart,compcodeDup);  fflush(stdout);
										ClrIdMacth3=1;
									}
								}
								if((compColIndYExist = 1) && (ClrIdMacth3 == 1))
								{
									printf(" For assy [%s], comp part [%s] with ColorID [%s] match not found in PLM , hence Post Colour release is Required.\n",ColPartDisplayNameDup,partnumDup,strColIDinSch);  fflush(stdout);
									//goto CLEANUP;
									fprintf(fpO, "\n-,-,-,-,-,-,For assy [%s], comp part [%s] with ColorID [%s] match not found in PLM , hence Post Colour release is Required,",ColPartDisplayNameDup,partnumDup,strColIDinSch); fflush(fpO);
									break;
								}
								
							  }
						}
			
						if(!isSchemeMatch)
						{
							if(dstat = objGetAttribute(objColScheme,"t5SchmCompPlatForm",&ScmCategory)) goto EXIT;
							if(!nlsIsStrNull(ScmCategory))
							{
								ScmCategoryDup = nlsStrDup(ScmCategory);
							}
			
							if((CmpCodefound == FALSE)/*&&(nlsStrCmp(ScmCategoryDup,"Exterior")==0)*/)
							{
								printf("\tScheme Category:%s CompCodeFlag:%d CompCode not found in colour scheme hence Adding non colour part in BOM\n",ScmCategoryDup,CmpCodefound); fflush(stdout);
								UsesPartObj = setGet(UsesPartObjs,j);
								UsesPartRel = setGet(UsesPartRels,j);
								GetInformation(colourPart,UsesPartObj,UsesPartRel,levl,mfail);
								//fprintf(fpO, "\n-,-,-,-,-,-,%s Comp Code not found in the scheme %s,",partnumDup,ColurSchemeDisplayedName); fflush(fpO);
							}
							else
							{
								printf(" 1.Assembly do not found colour component %s:%s ,please check colour component's released Status\n",ColPartDisplayNameDup,partnumDup); fflush(stdout);
								printf(" ScmCat:[%s] CompCodematchFlag:[%d]\n",ScmCategoryDup,CmpCodefound); fflush(stdout);
								printf("\tMatched not found, Can not update BOM:[%s:%s]**  \n",ColPartNumDup,partnumDup); fflush(stdout);
								printf(" ColourScheme:[%s]\n",ColurSchemeDisplayedNameDup); fflush(stdout);
								SchemeFlag = 1;
								//goto CLEANUP;
								fprintf(fpO, "\n-,-,-,-,-,-,Assembly do not found colour component %s:%s ,please check colour component's released Status,",ColPartDisplayNameDup,partnumDup); fflush(fpO);
								break;
							}
						}
					}
					else
					{
						if(dstat = objGetAttribute(UsesPartObj,"t5PrtCatCode",&compcode)) goto EXIT;
						if(!nlsIsStrNull(compcode))
						{
							compcodeDup = nlsStrDup(compcode);
						}
						t5ObjGetTableAttribute(objColScheme,"t5SchFullTab","t5PrtCatCode",compcodeDup,"t5ClSrl",&tmpStr,&mfail);
						if(tmpStr)
						{
							nlsStrTrimTrailWhiteSpace(tmpStr);
							strColSrl=nlsStrDup(tmpStr);
							printf("\t! SchColourSrl:[%s]",strColSrl);
							if(nlsStrCmp(strColSrl,"NOMATCH")==0)
							{
								printf("\tcolor srl in the scheme is NOMATCH hence copying noncolour partno");
								isSchemeMatch = FALSE;
								CmpCodefound = FALSE;
								returnflag = 1;
							}
						}
						printf("\taComcode:[%s]",compcodeDup);
			
						if(CmpCodefound == FALSE)
						{
							printf("\taScheme Category:%s CompCodeFlag:%d CompCode not found in colour scheme hence Adding non colour part in BOM",ScmCategoryDup,CmpCodefound);

							UsesPartObj = setGet(UsesPartObjs,j);
							UsesPartRel = setGet(UsesPartRels,j);
							GetInformation(colourPart,UsesPartObj,UsesPartRel,levl,mfail);						
						}
						else
						{
							printf(" 2.Assembly do not found colour component %s:%s ,please check colour component's released Status\n",ColPartDisplayNameDup,partnumDup);
							SchemeFlag = 1;
							//goto CLEANUP;
							fprintf(fpO, "\n-,-,-,-,-,-,Assembly do not found colour component %s:%s ,please check colour component's released Status,",ColPartDisplayNameDup,partnumDup); fflush(fpO);
							break;
						}
					}
					}
				}
				else	
				{ 
					printf("\tColorInd:[N] CoatedInd:[Y]");
			
					if((nlsStrCmp(CoatedIdAssemblyDup,"C") != 0) && nlsStrCmp(ColourIndAssemblyDup,"N") != 0)
					{
						if((!nlsStrCmp(CoatedIdAssemblyDup,"C")) && (!nlsStrCmp(CoatedIdSchemeDup,"Y")) && (!nlsStrCmp(CoatedIdUsesPart,"Y")) && (!nlsStrCmp(ClrIndUsesPart,"N")))
						{
							if (dstat = ExpandRelationWithCtxt("ItemRev",UsesPartObj,"ItemMstrForStrucBIRev",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&t5CoatItmMstr,&t5CoatItmMstrRel,&mfail)) goto EXIT;
							if(setSize(t5CoatItmMstrRel)>0)
							{
								if (dstat = ExpandRelationWithCtxt("t5ClInfo",setGet(t5CoatItmMstr,0),"t5AsmhasColPrt",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&clrCoatParts,&clrCoatRels,&mfail)) goto EXIT ;
			
								if(setSize(clrCoatParts)>0)
								{
									UsesPartObj = setGet(clrCoatParts,0);
								
								}
								else
								{
									printf("\tColorInd:[N]10");
									UsesPartObj = setGet(UsesPartObjs,j);
									UsesPartRel = setGet(UsesPartRels,j);
			
									GetInformation(colourPart,UsesPartObj,UsesPartRel,levl,mfail);
								}
							}
						}
						else
						{
							printf("\tColorInd:[N]11");
							UsesPartObj = setGet(UsesPartObjs,j);
							UsesPartRel = setGet(UsesPartRels,j);
			
							GetInformation(colourPart,UsesPartObj,UsesPartRel,levl,mfail);
						}
					}
					else
					{
						printf(" Else2 is here\n");
						if((nlsStrCmp(CoatedIdAssemblyDup,"C")==0) /*&& (!nlsStrCmp(CoatedIdSchemeDup,"Y"))*/ && (nlsStrCmp(CoatedIdUsesPart,"Y")==0) && (nlsStrCmp(ClrIndUsesPart,"N")==0))
						{
							if (dstat = ExpandRelationWithCtxt("ItemRev",UsesPartObj,"ItemMstrForStrucBIRev",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&t5CoatItmMstr,&t5CoatItmMstrRel,&mfail)) goto EXIT;
							if(setSize(t5CoatItmMstr)>0)
							if (dstat = ExpandRelationWithCtxt("t5ClInfo",setGet(t5CoatItmMstr,0),"t5AsmhasColPrt",genContextObj2,SC_SCOPE_OF_SESSION,NULL,&clrCoatParts,&clrCoatRels,&mfail)) goto EXIT ;
							if(setSize(clrCoatParts)>0)
							{
								if(nlsStrCmp(CoatedIdSchemeDup,"Y")==0)
								{
									for(cci=0;cci<setSize(clrCoatParts);cci++)
									{
										UsesPartObj = setGet(clrCoatParts,cci);
										if(dstat = objGetAttribute(UsesPartObj, "t5Coated", &usesColourCoated)) goto CLEANUP;
										if(!nlsIsStrNull(usesColourCoated))
										{
											usesColourCoatedDup = nlsStrDup(usesColourCoated);
										}
			
										if(dstat = objGetAttribute(UsesPartObj, "t5ColourInd", &usesColourColourid)) goto CLEANUP;
										if(!nlsIsStrNull(usesColourColourid))
										{
											usesColourColouridDup = nlsStrDup(usesColourColourid);
										}
										if((nlsStrCmp(usesColourCoatedDup,"C")==0)&&(nlsStrCmp(usesColourColouridDup,"N")==0))
										{
											break;
										}
			
									}
								}
								else
								{
									UsesPartObj = setGet(clrCoatParts,0);
								}
			
								GetInformation(colourPart,UsesPartObj,UsesPartRel,levl,mfail);
							}
							else
							{
								printf("\tColorInd:[N]13");
								UsesPartObj = setGet(UsesPartObjs,j);
								UsesPartRel = setGet(UsesPartRels,j);
			
								GetInformation(colourPart,UsesPartObj,UsesPartRel,levl,mfail);
							}
						}
						else
						{
							//Non color Part
							printf("\tColorInd:[N]14");
							UsesPartObj = setGet(UsesPartObjs,j);
							UsesPartRel = setGet(UsesPartRels,j);
			
							GetInformation(colourPart,UsesPartObj,UsesPartRel,levl,mfail);
						}
					}
				}
			}
		}
		else
		{
			fprintf(fpO, "\n-,-,-,-,-,-,Uses parts not found [%s],\n",DisplayNameDup); fflush(fpO);
		}
	}

	CLEANUP:
		fprintf(fpO, "\n"); fflush(fpO);
		if(fpO)  fclose(fpO) ;
		fpO=NULL;
		printf(" I am in CLEAN UP of ExtractColorBOM....\n");
	EXIT:
		return(dstat);
}
;
int main(int argc,char * argv[])
{
	status	dstat = OKAY ;
	integer mfail;

	SqlPtr			a_sql					= NULL;
	SqlPtr			sql						= NULL;
	SqlPtr			sql1					= NULL;

	string			ercTaskId				= NULL;
	string			ercTaskIdDup			= NULL;
	string			VCObid					= NULL;
	string			cPartType				= NULL;
	string			cPartTypeDup			= NULL;
	string			LeftSchm				= NULL;
	string			SchmName				= NULL;
	string			colInd					= NULL;
	string			colIndDup				= NULL;
	string			partNum					= NULL;
	string			partNumDup				= NULL;
	string			rev						= NULL;
	string			revDup					= NULL;
	string			seq						= NULL;
	string			seqDup					= NULL;
	string			kitDml					= NULL;
	string			dmlNoDup				= NULL;
	string			dmlTp					= NULL;
	string			dmlTpDup				= NULL;
	string			schmNomenDup			= NULL;
	string			schmNomen				= NULL;
	string			schmColID				= NULL;
	string			schmColIDDup			= NULL;
	string			prtColID				= NULL;
	string			prtColIDDup				= NULL;
	string			revS					= NULL;
	string			revSDup					= NULL;
	string			scheme1					= NULL;
	string			scheme2					= NULL;
	string			scheme3					= NULL;
	string			scheme4					= NULL;
	string			scheme5					= NULL;
	string			assyCompCode			= NULL;
	string			assyColSrl				= NULL;
	string			nonColor				= NULL;
	string			subColSrl				= NULL;
	string			SchemeName				= NULL;
	string			SchemeRev				= NULL;
	string			PartCatCode				= NULL;
	string			ColSrl					= NULL;
	string			SchmPrtNo				= NULL;
	string			IntSchmInd				= NULL;
	string			IntSchmIndDup			= NULL;
	string			ColourSchDup			= NULL;
	string			ColourSch				= NULL;
	string			DisplayDescDup			= NULL;
	string			DisplayDesc				= NULL;
	string			clrscm					= NULL;
	string			InpFile					= NULL;
	string			lineRead				= NULL;
	string			lineRead1				= NULL;
	string			lineReadDup				= NULL;
	string			FileNameS				= NULL;
	string			FileColorBOM			= NULL;
	string			relStatus				= NULL;   
	string			relStatusDup			= NULL;

	SetOfObjects	ipPartObj				= NULL;
	SetOfObjects	ipTaskObj				= NULL;
	SetOfObjects	ipTaskRelObj			= NULL;
	SetOfObjects	ercDmlObj				= NULL;
	SetOfObjects	ercDmlRelObj			= NULL;
	SetOfObjects	hasnonclrmstrObjects	= NULL;
	SetOfObjects	ahasnonclrmstrObjects	= NULL;
	SetOfObjects	appSchmSet				= NULL;
	SetOfObjects	appSchmRelSet			= NULL;
	SetOfObjects	soControls				= NULL;
	SetOfObjects	tmpColSchmSet			= NULL;
	SetOfObjects	soSchmObj				= NULL;
	SetOfObjects	soClMas					= NULL;
	SetOfObjects  	HasControlSet			= NULL;
	SetOfObjects	AssyHasDmlSet			= NULL;
	SetOfObjects	AssyHasDmlRelSet		= NULL;
	SetOfObjects	setColScheme			= NULL;

	ObjectPtr		ercTask					= NULL;
	ObjectPtr		SchmRelObj				= NULL;
	ObjectPtr		SchmObjE				= NULL;
	ObjectPtr		genContextObj			= NULL;
	ObjectPtr		ipPartObjPtr			= NULL;
	ObjectPtr		ctxtObj					= NULL;
	ObjectPtr		hasnonclrmstrptr		= NULL;
	ObjectPtr		hasRevPtr				= NULL;
	ObjectPtr		schmObjPtr				= NULL;
	ObjectPtr		ClMasObj				= NULL;
	ObjectPtr		HasControlObj			= NULL;
	ObjectPtr		objColScheme			= NULL;
	
	SetOfStrings	dbScopeStr				= NULL;
	SetOfStrings	t5BasicItmRevs			= NULL;
	SetOfStrings	at5BasicItmRevs			= NULL;
	SetOfStrings	SchmRelSet				= NULL;
	SetOfStrings	ColSchmSet				= NULL;
	SetOfStrings	SetOfVC					= NULL;
	SetOfStrings	uniqueClrScm			= NULL;

	char			fileReadd[500];
	FileNameS	= nlsStrAlloc(200);
	PartCatCode	= low_getspace(100);
	char	*dmlNo = NULL;

	int	 uu=0,tt,i=0,cnt=0,t=0,TabSize=0,strLen=0,p=0,jj=0,ii=0,TabSize2=0,kk=0,sch=0,schemeFlg=0;

	FileNameS		= nlsStrAlloc(200);
	FileColorBOM 	= nlsStrAlloc(200);

	dbScopeStr		= low_set_create_str(2);
	dbScopeBkp		= low_set_create_str(2);


	/*********************************************Neha code started**************************************************/

	/* enable multibyte features of Metaphase */
	if (dstat = clInitMB2 (argc, &argv, NULL)) goto CLEANUP;
	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	if (dstat = clTestNetwork ()) goto CLEANUP;
	/*  Initialize the command line session.   */
	if (dstat = clInitialize2 (FALSE)) goto CLEANUP;

	printf("\n **Login Done** \n");fflush(stdout);

	InpFile = nlsStrAlloc(20);
	InpFile = argv[1];
	printf("\nArg1:[%s]", InpFile);

	printf("\nP5:Inside loop for read Input file........\n"); fflush(stdout);
	fpR = fopen(InpFile, "r");
	if (fpR == NULL)
	{
		printf("Unable  open  File.\n "); fflush(stdout);
		goto  CLEANUP;
	}

	

	while (fgets(fileReadd, 500, fpR) != NULL)
	{
		if (!nlsIsStrNull(fileReadd))
		{
			if(colorPartNo)		colorPartNo = NULL;
			if(rev)				rev			= NULL;
			if(seq)				seq			= NULL;

			lineReadDup = nlsStrAlloc(500);
			nlsStrCpy(lineReadDup, fileReadd);
			lineRead1	= low_strssra(lineReadDup, ",,", ", ,");
			lineRead	= low_strssra(lineRead1, ",,", ", ,");
			colorPartNo = strtok(lineRead, ",");
			rev			= strtok(NULL,",");
			seq			= strtok(NULL,",");

			if (colorPartNo)nlsStrTrimTrailWhiteSpace(colorPartNo);

			nlsStrCpy(FileColorBOM, "/user/omfprod/Neha/GetBaseRevAsRelWithSingleLvlBOMExpansion/");
			nlsStrCat(FileColorBOM, colorPartNo);
			nlsStrCat(FileColorBOM, "_");
			nlsStrCat(FileColorBOM, rev);
			nlsStrCat(FileColorBOM, "_");
			nlsStrCat(FileColorBOM, seq);
			nlsStrCat(FileColorBOM, "_ColorBom.txt");
			printf("\n FileColorBOM :: [%s]\n", FileColorBOM); fflush(stdout);

			fpO = fopen(FileColorBOM, "w");
			if (fpO == NULL)
			{
				printf("\n Cannot open fpO File for replication information logging ..."); fflush(stdout);
				goto EXIT;
			}

			fprintf(fpO,"Level,Part,Rev,Seq,Qty,Release Status,Error,");fflush(fpO);
			printf(" ############ Input Color Part number : [%s][%s][%s] ############\n", colorPartNo,rev,seq); fflush(stdout);

			
			nlsStrCpy(FileNameS, "/user/omfprod/Neha/GetBaseRevAsRelWithSingleLvlBOMExpansion/");
			nlsStrCat(FileNameS, colorPartNo);
			nlsStrCat(FileNameS, "_");
			nlsStrCat(FileNameS, rev);
			nlsStrCat(FileNameS, "_");
			nlsStrCat(FileNameS, seq);
			nlsStrCat(FileNameS, "_Scheme.txt");
			printf("FileNameS :: [%s]\n", FileNameS); fflush(stdout);
	
			fp = fopen(FileNameS, "w");
			if (fp == NULL)
			{
				printf("\n Cannot open fp File for replication information logging ..."); fflush(stdout);
				goto EXIT;
			}
		}
		
		//Get color scheme code 
		if ((dstat = oiSqlCreateSelect(&a_sql)) ||
			(dstat = oiSqlWhereBegParen(a_sql)) ||
			(dstat = oiSqlWhereEQ(a_sql, "PartNumber", colorPartNo)) ||
			(dstat = oiSqlWhereAND(a_sql)) ||
			(dstat = oiSqlWhereEQ(a_sql, "Superseded", "-")) ||
			(dstat = oiSqlWhereEndParen(a_sql)) ||
			(dstat = QueryWhere("Part", a_sql, &ipPartObj, &mfail))) goto CLEANUP;
		printf(" Part found %s with size %d\n", colorPartNo, setSize(ipPartObj)); fflush(stdout);

		if (setSize(ipPartObj) > 0)
		{
			for (tt = 0; tt < setSize(ipPartObj); tt++)
			{
				ipPartObjPtr = setGet(ipPartObj, tt);

				schemeFlg	= 0;
				partNum		= NULL;
				partNumDup	= NULL;
				rev			= NULL;
				revDup = NULL;
				seq = NULL;
				seqDup = NULL;
				cPartType = NULL;
				cPartTypeDup = NULL;
				colInd = NULL;
				colIndDup = NULL;
				ipTaskObj = NULL;
				ipTaskRelObj = NULL;
				ercTaskIdDup = NULL;
				ercTaskId = NULL;
				kitDml = NULL;
				ercDmlObj = NULL;
				ercDmlRelObj = NULL;
				dmlNo = NULL;
				dmlNoDup = NULL;
				dmlTp = NULL;
				dmlTpDup = NULL;
				hasnonclrmstrptr = NULL;
				hasnonclrmstrObjects = NULL;
				ahasnonclrmstrObjects = NULL;
				t5BasicItmRevs = NULL;
				at5BasicItmRevs = NULL;
				hasRevPtr = NULL;
				appSchmSet = NULL;
				appSchmRelSet = NULL;
				schmObjPtr = NULL;
				schmNomenDup = NULL;
				schmNomen = NULL;
				schmColID = NULL;
				schmColIDDup = NULL;
				prtColID = NULL;
				prtColIDDup = NULL;
				revS = NULL;
				revSDup = NULL;
				relStatus = NULL;
				relStatusDup = NULL;

				if (dstat = objGetAttribute(ipPartObjPtr, "PartNumber", &partNum)) goto CLEANUP;
				if (!nlsIsStrNull(partNum))
				{
					partNumDup = nlsStrDup(partNum);
				}

				if (dstat = objGetAttribute(ipPartObjPtr, "Revision", &rev)) goto CLEANUP;
				if (!nlsIsStrNull(rev))
				{
					revDup = nlsStrDup(rev);
				}

				if (dstat = objGetAttribute(ipPartObjPtr, "Sequence", &seq)) goto CLEANUP;
				if (!nlsIsStrNull(seq))
				{
					seqDup = nlsStrDup(seq);
				}

				if (dstat = objGetAttribute(ipPartObjPtr, "PartType", &cPartType)) goto CLEANUP;
				if (!nlsIsStrNull(cPartType))
				{
					cPartTypeDup = nlsStrDup(cPartType);
				}

				if (dstat = objGetAttribute(ipPartObjPtr, "t5ColourInd", &colInd)) goto CLEANUP;
				if (!nlsIsStrNull(colInd))
				{
					colIndDup = nlsStrDup(colInd);
				}

				if (dstat = objGetAttribute(ipPartObjPtr, "OwnerName", &relStatus)) goto CLEANUP;
				if (!nlsIsStrNull(relStatus))
				{
					relStatusDup = nlsStrDup(relStatus);
				}

				fprintf(fpO, "\n0,%s,%s,%s,%s,%s,%s,",partNumDup,revDup,seqDup,"-",relStatusDup,"-"); fflush(fpO);


				printf(" Part[%s] Rev[%s] Seq[%s] Part Type[%s] ColorInd[%s]\n", partNumDup, revDup, seqDup, cPartTypeDup, colIndDup); fflush(stdout);

				if (dstat = IntSetUpContext(objClass(ipPartObjPtr), ipPartObjPtr, &genContextObj, &mfail))goto CLEANUP;
				if (dstat = GetCfgCtxtObjFromCtxt(DSesGnCClass, genContextObj, &ctxtObj, &mfail));
				if (dstat = objSetAttribute(ctxtObj, CfgItemIdAttr, "GlobalCtxt"))goto CLEANUP;
				if (dstat = objNameValueSet(ctxtObj, LCStateListAttr, "LcsAplRlzd", "+"))goto CLEANUP;
				if (dstat = objNameValueSet(ctxtObj, LCStateListAttr, "LcsErcRlzd", "+"))goto CLEANUP;
				if (dstat = objNameValueSet(ctxtObj, LCStateListAttr, "LcsReview", "-"))goto CLEANUP;
				if (dstat = objNameValueSet(ctxtObj, LCStateListAttr, "LcsWorking", "-"))goto CLEANUP;
				if (dstat = objNameValueSet(ctxtObj, LCStateListAttr, "LcsAPLWrkg", "+"))goto CLEANUP;
				if (dstat = objNameValueSet(ctxtObj, LCStateListAttr, "LcsSTDRlzd", "+"))goto CLEANUP;
				if (dstat = objNameValueSet(ctxtObj, LCStateListAttr, "LcsSTDWrkg", "+"))goto CLEANUP;

				if (dstat = objSetObject(genContextObj, ConfigCtxtBlobAttr, ctxtObj))goto CLEANUP;
				if (dstat = SetExpOnRevInCtxt(DSesGnCClass, genContextObj, "PscLastRev", &mfail))goto CLEANUP;

				if (dstat = ExpandRelationWithCtxt("t5ClInfo", ipPartObjPtr, "t5ColPrtforAsm", genContextObj, SC_SCOPE_OF_SESSION, NULL, &hasnonclrmstrObjects, &ahasnonclrmstrObjects, &mfail)) goto CLEANUP;
				//printf(" Non-color master:[%d]\n", setSize(hasnonclrmstrObjects)); fflush(stdout);
				if (setSize(hasnonclrmstrObjects) > 0)
				{
					hasnonclrmstrptr = setGet(hasnonclrmstrObjects, 0);
					if (dstat = ExpandRelationWithCtxt("ItemRev", hasnonclrmstrptr, "StrucBIRevsOfItemMstr", genContextObj, SC_SCOPE_OF_SESSION, NULL, &t5BasicItmRevs, &at5BasicItmRevs, &mfail))  goto CLEANUP;
					hasRevPtr = setGet(t5BasicItmRevs, 0);
					if (dstat = objGetAttribute(hasRevPtr,"PartNumber",&nonColor)) goto EXIT;
				}
				else
				{
					printf(" **Non-color part not found\n"); fflush(stdout);
				}

				if (nlsStrCmp(colIndDup, "C") == 0)
				{
					if (nlsStrCmp(cPartTypeDup, "VC") == 0)  /* For VC part type */
					{
						printf(" Inside uses colour part being used for VC\n");fflush(stdout);
						if (dstat = objGetAttribute(hasRevPtr,OBIDAttr,&VCObid)) goto EXIT;
						printf(" VC has OBID :[%s] \n",VCObid);fflush(stdout);
						if(sql)	oiSqlDispose(sql);	sql = NULL;
						if(SchmRelSet)
						{
							objDisposeAll(SchmRelSet);
							SchmRelSet = NULL;
						}
						
						if(	(dstat = oiSqlCreateSelect(&sql)) ||
							(dstat = oiSqlWhereBegParen(sql)) ||
						    (dstat = oiSqlWhereEQ(sql,RightAttr,VCObid)) ||
							(dstat = oiSqlWhereAND(sql)) ||
							(dstat = oiSqlWhereEQ(sql,t5ColVCAttr,partNumDup))||
							(dstat = oiSqlWhereEndParen(sql)) ||
						    (dstat = QueryDbObject(t5ClCfgIClass,sql,1,TRUE,SC_SCOPE_OF_SESSION,&SchmRelSet,&mfail)))goto CLEANUP;

						printf(" No of Colour Scheme found setSize[SchmRelSet] :[%d]\n",setSize(SchmRelSet));fflush(stdout);
						
						SchmRelObj = setGet(SchmRelSet,0);
						if (dstat = objGetAttribute(SchmRelObj ,LeftAttr,&LeftSchm)) goto EXIT;
						printf(" LeftSchm :%s \n",LeftSchm);fflush(stdout);

						if( (dstat = oiSqlCreateSelect(&sql)) ||
							(dstat = oiSqlWhereBegParen(sql)) ||
							(dstat = oiSqlWhereEQ(sql,OBIDAttr,LeftSchm)) ||
							(dstat = oiSqlWhereEndParen(sql)) ||
							(dstat = QueryDbObject(t5ClSchmClass,sql,1,TRUE,SC_SCOPE_OF_SESSION,&ColSchmSet,&mfail)))goto CLEANUP;

						SchmObjE = setGet(ColSchmSet,0);
						if(dstat = objGetAttribute(SchmObjE,NomenclatureAttr,&SchmName)) goto EXIT;

						if(ColSchmSet) ColSchmSet=NULL;

						if( (dstat = oiSqlCreateSelect(&sql)) ||
							(dstat = oiSqlWhereBegParen(sql)) ||
							(dstat = oiSqlWhereEQ(sql,NomenclatureAttr,SchmName)) ||
							(dstat = oiSqlWhereAND(sql)) ||
							(dstat = oiSqlWhereLike(sql, OwnerNameAttr,"%Release Vault")) ||
							(dstat = oiSqlWhereEndParen(sql)) ||
							(dstat = QueryDbObject(t5ClSchmClass,sql,0,TRUE,SC_SCOPE_OF_SESSION,&ColSchmSet,&mfail)))goto CLEANUP;
						
					}
					else /* For non VC part type */
					{
						if (dstat = ExpandObject2("CmRslts", ipPartObjPtr, "BusItemIsResultOfCMPrdPln", SC_SCOPE_OF_SESSION, &ipTaskObj, &ipTaskRelObj, &mfail)) goto CLEANUP;
						//printf("ipTaskObj:%d\n", setSize(ipTaskObj)); fflush(stdout);

						if (setSize(ipTaskObj) > 0)
						{
							for (uu = 0; uu < setSize(ipTaskObj); uu++)
							{
								if (dstat = objGetAttribute(setGet(ipTaskObj, uu), "WbsID", &ercTaskIdDup)) goto EXIT;
								if (!nlsIsStrNull(ercTaskIdDup))
								{
									ercTaskId = nlsStrDup(ercTaskIdDup);
								}
								kitDml = subString(ercTaskId, 0, 10);
								//printf("DML:[%s][%s]\n", kitDml, ercTaskId); fflush(stdout);

								if ((nlsIsStrNull(nlsStrStr(ercTaskId, "APL"))) && (nlsIsStrNull(nlsStrStr(ercTaskId, "STD"))))
								{
									//printf("ERC dml object found %s\n", ercTaskId); fflush(stdout);
									ercTask = setGet(ipTaskObj, uu);
									break;
								}
							}
						}

						if (ercTask)
						{
							if (dstat = ExpandObject2("CmPlRvRv", ercTask, "CMPlanRollsUpInTo", SC_SCOPE_OF_SESSION, &ercDmlObj, &ercDmlRelObj, &mfail))goto CLEANUP;
							if (dstat = objGetAttribute(setGet(ercDmlObj, 0), "WbsID", &dmlNo)) goto EXIT; \
							if (!nlsIsStrNull(dmlNo))
							{
								dmlNoDup = nlsStrDup(dmlNo);
							}
							if (dstat = objGetAttribute(setGet(ercDmlObj, 0), "t5DmlType", &dmlTp)) goto EXIT;
							if (!nlsIsStrNull(dmlTp))
							{
								dmlTpDup = nlsStrDup(dmlTp);
							}
							printf(" DML No[%s] DML Type [%s]\n", dmlNoDup,dmlTpDup); fflush(stdout);

							if (!nlsIsStrNull(nlsStrStr(dmlTpDup, "CP")))
							{
								printf(" ***********Inside CP type DML***********\n");fflush(stdout);

								if(a_sql) a_sql=NULL;
								if(soControls) soControls=NULL;
								if((dstat = oiSqlCreateSelect(&a_sql)) ||
								(dstat = oiSqlWhereBegParen(a_sql)) ||
								(dstat = oiSqlWhereEQ(a_sql,t5VCDmlNoAttr,dmlNoDup)) ||
								(dstat = oiSqlWhereEndParen(a_sql)) ||
								(dstat = QueryDbObject(t5ColCtlClass, a_sql, 0, TRUE, SC_SCOPE_OF_SESSION, &soControls,&mfail))) goto CLEANUP;


								printf(" Control Object Found by Query:[%d]\n",setSize(soControls));fflush(stdout);
								SetOfVC  = setCreate(5);
								if (setSize(soControls)>0)
								{

									if (dstat = objGetAttribute(setGet(soControls,0),t5SchmNomenclature1Attr,&scheme1)) goto EXIT;

									if(!nlsIsStrNull(scheme1)) low_set_add_str(SetOfVC,scheme1);

									if (dstat = objGetAttribute(setGet(soControls,0),t5SchmNomenclature2Attr,&scheme2)) goto EXIT;

									if(!nlsIsStrNull(scheme2)) low_set_add_str(SetOfVC,scheme2);

									if (dstat = objGetAttribute(setGet(soControls,0),t5SchmNomenclature3Attr,&scheme3)) goto EXIT;

									if(!nlsIsStrNull(scheme3)) low_set_add_str(SetOfVC,scheme3);

									if (dstat = objGetAttribute(setGet(soControls,0),t5SchmNomenclature4Attr,&scheme4)) goto EXIT;

									if(!nlsIsStrNull(scheme4))  low_set_add_str(SetOfVC,scheme4);

									if (dstat = objGetAttribute(setGet(soControls,0),t5SchmNomenclature5Attr,&scheme5)) goto EXIT;
									if(!nlsIsStrNull(scheme5)) low_set_add_str(SetOfVC,scheme5);
								}

								printf(" No of Colour Schemes found for DML %s:[%d]\n",dmlNoDup,setSize(SetOfVC));fflush(stdout);

								if (setSize(SetOfVC)>0)
								{
									for(cnt=0;cnt<setSize(SetOfVC);cnt++)
									{

										printf(" %d.going to Query scheme for :%s  \n",cnt,setGetStr(SetOfVC,cnt));fflush(stdout);

										if(ColSchmSet) ColSchmSet=NULL;
										if((dstat = oiSqlCreateSelect(&sql)) ||
										(dstat = oiSqlWhereBegParen(sql)) ||
										(dstat = oiSqlWhereEQ(sql,NomenclatureAttr,setGet(SetOfVC,cnt))) ||
										(dstat = oiSqlWhereAND(sql)) ||
										(dstat = oiSqlWhereLike(sql, OwnerNameAttr,"%Release Vault")) ||
										(dstat = oiSqlWhereEndParen(sql)) ||
										(dstat = QueryDbObject(t5ClSchmClass,sql,0,TRUE,SC_SCOPE_OF_SESSION,&tmpColSchmSet,&mfail)))goto CLEANUP;
										
										printf(" %d: Scheme found through Control Object for scheme ===%s:%d  \n",cnt,setGetStr(SetOfVC,cnt),setSize(tmpColSchmSet));fflush(stdout);
										
										if(setSize(tmpColSchmSet)>0)
										{
										
											for(t=0;t<setSize(tmpColSchmSet);t++)
											{
												if (dstat = (ulyAddObjectToSet(low_set_get(tmpColSchmSet,t),&soSchmObj))) goto EXIT;
											}
											low_set_empty(tmpColSchmSet);
											printf(" %d:Scheme Added====:%d  \n",i,setSize(soSchmObj));fflush(stdout);
										}

									}
								}

							}
							else /*Other than CP DML*/
							{
								printf(" ***********Inside CM or CL type DML***********\n");fflush(stdout);
								printf(" Non-Color Part no: %s\n",nonColor);

								if(sql1) sql1=NULL;
								if(HasControlSet) HasControlSet=NULL;

								if((dstat = oiSqlCreateSelect(&sql1)) ||
								(dstat = oiSqlWhereBegParen(sql1)) ||
								(dstat = oiSqlWhereEQ(sql1,t5VCDmlNoAttr,dmlNoDup)) ||
								(dstat = oiSqlWhereAND(sql1))||
								(dstat = oiSqlWhereEQ(sql1,t5NonColorAssyAttr,nonColor))||
								(dstat = oiSqlWhereEndParen(sql1)) ||
								(dstat = QueryDbObject(t5ClCtTClass, sql1, 0, TRUE, SC_SCOPE_OF_SESSION, &HasControlSet, &mfail))) goto CLEANUP;
								printf(" Control Object Found by Query for  post mod dml :%d\n",setSize(HasControlSet));fflush(stdout);

								if(setSize(HasControlSet)==0)
								{
									printf(" Partno and DML combination not found in control object\n");fflush(stdout);
								}
								else
								{
									HasControlObj = setGet(HasControlSet,0);
									if(dstat = ExpandObject2("t5CtColR",HasControlObj,"t5AssyHasClDml",SC_SCOPE_OF_SESSION,&AssyHasDmlSet,&AssyHasDmlRelSet,&mfail)) goto CLEANUP ;
									if(setSize(AssyHasDmlSet)==0)
									{
										printf(" AssyHasDmlSet has size 0\n");fflush(stdout);
										goto CLEANUP;
									}
									else
									{
										printf(" AssyHasDmlSet ObjectSize: %d\n",setSize(AssyHasDmlSet));fflush(stdout);
									}
									if(setSize(AssyHasDmlRelSet)==0)
									{
										printf(" AssyHasDmlRelSet has size 0\n");fflush(stdout);
										goto CLEANUP;
									}
									else
									{
										printf(" AssyHasDmlRelSet ObjectSize: %d",setSize(AssyHasDmlRelSet));fflush(stdout);
									}
									for(jj=0 ;jj<setSize(AssyHasDmlRelSet);jj++)
									{
										t5FreeSetOfStrings(uniqueClrScm);
										uniqueClrScm =	set_create_str(100);
										if(dstat =objGetTableSize(setGet(AssyHasDmlRelSet,jj),"t5ColSchemesFt",&TabSize2)) goto EXIT;
										for(ii = 0; ii<TabSize2; ii++)
										{
											if(dstat=objGetTableAttribute (setGet(AssyHasDmlRelSet,jj),"t5ColSchemesFt", ii,"t5ColSchmRlsTAttr",&ColourSch)) goto EXIT;
											if(!nlsIsStrNull(ColourSch))
											{
												nlsStrTrimTrailWhiteSpace(ColourSch);
												ColourSchDup = nlsStrDup(ColourSch);
												low_set_add_str_unique(uniqueClrScm,ColourSchDup);
											}
										}
										printf(" Number of Schemes:%d for Clr of NCPartno:%s\n",setSize(uniqueClrScm),nonColor);fflush(stdout);
										if( dstat = objGetAttribute(setGet(AssyHasDmlSet,jj),"DisplayedDesc",&DisplayDesc)) goto CLEANUP;
										if(!nlsIsStrNull(DisplayDesc))
										{
											DisplayDescDup = nlsStrDup(DisplayDesc);
											printf(" DmlNo:%s\n",DisplayDescDup);fflush(stdout);
										}
								    	for(ii=0;ii<setSize(uniqueClrScm);ii++)
										{
											clrscm = low_set_get_str(uniqueClrScm,ii);
											printf(" %d %s\n",ii,clrscm);fflush(stdout);
											setColScheme = getColorSchemePartObj(clrscm);
											for(kk=0;kk<setSize(setColScheme);kk++)
											{									
												if(dstat=(ulyAddObjectToSet(low_set_get(setColScheme,kk),&soSchmObj)));   
											}
										}
										printf(" After for loop setSize(soSchmObj) :%d\n",setSize(soSchmObj));
									}
								}
			
							}
						}
						else
						{
							printf(" **ERC Task not Found\n"); fflush(stdout);
						}
					}
				}
				else
				{
					printf(" Part is not colorable \n"); fflush(stdout);
				}
			}

			if (setSize(soSchmObj)>0)
			{
				printf(" Total Scheme found through Control Object :%d  \n",setSize(soSchmObj));fflush(stdout);

				if (dstat = objGetAttribute(ipPartObjPtr,t5PrtCatCodeAttr,&assyCompCode)) goto EXIT;
				if (dstat = objGetAttribute(ipPartObjPtr,t5ColourIDAttr,&assyColSrl)) goto EXIT;

				/****************Query for Master *************************/
				if(sql1)	oiSqlDispose(sql1);	sql1 = NULL;
				if(soClMas)
				{
					soClMas = NULL;
				}
				if((dstat = oiSqlCreateSelect(&sql1)) ||
				(dstat = oiSqlWhereBegParen(sql1)) ||
				(dstat = oiSqlWhereEQ(sql1,t5Category_CodeAttr,assyCompCode)) ||
				(dstat = oiSqlWhereEndParen(sql1)) ||
				(dstat = QueryDbObject(t5CatCdClass, sql1, 0, TRUE, SC_SCOPE_OF_SESSION, &soClMas,&mfail))) goto CLEANUP;
				printf(" Colour Master Query Set Size:%d\n",setSize(soClMas));fflush(stdout);
				
				if(setSize(soClMas)>0)
				{
					ClMasObj=setGet(soClMas,0);
					if (dstat = objGetAttribute(ClMasObj,t5InternalSchmAttr,&IntSchmInd)) goto EXIT;
					if(!nlsIsStrNull(IntSchmInd)) IntSchmIndDup = nlsStrDup(IntSchmInd);
					printf(" Internal Scheme Indicator[%s]\n",IntSchmIndDup);fflush(stdout);
				}
				else
				{
					printf(" **Color Master not found \n"); fflush(stdout);
				}

				if(soSchmObj>0)
				{
					for(t=0;t<setSize(soSchmObj);t++)
					{
						if(dstat = objGetTableSize(low_set_get(soSchmObj,t),t5SchFullTabAttr,&TabSize)) goto EXIT;
						if (dstat = objGetAttribute(low_set_get(soSchmObj,t),NomenclatureAttr,&SchemeName)) goto EXIT;
						if (dstat = objGetAttribute(low_set_get(soSchmObj,t),"Revision",&SchemeRev)) goto EXIT;

						printf(" %d. Filtering the Schemes [%s#%s] for [%s] and [%s]  : and [%s] TabSize [%d]\n",t,SchemeName,SchemeRev,assyCompCode,assyColSrl,nonColor,TabSize);fflush(stdout);
						if(TabSize>0)
						{
							for (p=0;p<TabSize;p++)
							{
								//printf(" inside Tabsize \n",PartCatCode,subColSrl,SchmPrtNo);fflush(stdout);
								if(dstat = objGetTableAttribute(low_set_get(soSchmObj,t),t5SchFullTabAttr,p,t5PrtCatCodeAttr,&PartCatCode)) goto EXIT;
								if(dstat = objGetTableAttribute(low_set_get(soSchmObj,t),t5SchFullTabAttr,p,t5ClSrlAttr,&ColSrl)) goto EXIT;
								if(dstat = objGetTableAttribute(low_set_get(soSchmObj,t),t5SchFullTabAttr,p,t5SchmPrtCAttr,&SchmPrtNo)) goto EXIT;
							
								if((!nlsIsStrNull(PartCatCode))&&(!nlsIsStrNull(ColSrl)))
								{
									strLen=strlen(ColSrl);
									subColSrl=subString(ColSrl,3,strLen);
									nlsStrTrimTrailWhiteSpace(subColSrl);
									//printf(" Checking in Full table: PartCatCode  ColSrl & Scheme Part No: %s ,%s ,%s \n",PartCatCode,subColSrl,SchmPrtNo);fflush(stdout);
								}
							
								if (nlsStrCmp(IntSchmIndDup,"T")==0)
								{
									if(!nlsIsStrNull(SchmPrtNo))
									{
										nlsStrTrimTrailWhiteSpace(SchmPrtNo);
								
										if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 && nlsStrStr(SchmPrtNo,nonColor)!=NULL)
										{
											schemeFlg = 1;
											printf(" A. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
											//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
											//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
											//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
											if (dstat =(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet))) goto EXIT;
											break;
										}
									}
									else
									{
										if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 )
										{
											schemeFlg = 1;
											printf(" B. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
											//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
											//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
											//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
											if (dstat =(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet))) goto EXIT;
											break;
										}
								
									}
								}
								else
								{
									if(nlsStrCmp(PartCatCode,assyCompCode)==0 && nlsStrCmp(subColSrl,assyColSrl)==0 )
									{
										schemeFlg = 1;
										printf(" C. Inside Fields Match in Scheme for Scheme %s \n",SchemeName);fflush(stdout);
										//printf("\n Comp code Comparision:: %s %s",PartCatCode,assyCompCode);fflush(stdout);
										//printf("\n Colour ID Comparision:: %s %s",subColSrl,assyColSrl);fflush(stdout);
										//printf("\n Part NO   Comparision:: %s %s",SchmPrtNo,AssyPartNo);fflush(stdout);
										if (dstat =(ulyAddObjectToSet(low_set_get(soSchmObj,t),&ColSchmSet))) goto EXIT;
										break;
									}
								}
							}
						}
						else
						{
							printf(" No colour scheme found\n"); fflush(stdout);
						}
					}
				}
				else
				{
					printf(" colour Scheme not found \n"); fflush(stdout);
				}
			}
			else
			{
				printf(" 2.colour Scheme not found \n"); fflush(stdout);
			}

			if (setSize(ColSchmSet) >0)
			{
				printf(" Set of color scheme object Size: [%d]\n",setSize(ColSchmSet)); fflush(stdout);

				if(setSize(ColSchmSet) > 1)
				{
					sch = setSize(ColSchmSet) - 1;
					objColScheme = low_set_get(ColSchmSet,sch);
					if (dstat = objGetAttribute(low_set_get(ColSchmSet,sch),NomenclatureAttr,&SchemeName)) goto EXIT;
					if (dstat = objGetAttribute(low_set_get(ColSchmSet,sch),RevisionAttr,&SchemeRev)) goto EXIT;
				}
				else
				{
					objColScheme = low_set_get(ColSchmSet,0);
					if (dstat = objGetAttribute(low_set_get(ColSchmSet,0),NomenclatureAttr,&SchemeName)) goto EXIT;
					if (dstat = objGetAttribute(low_set_get(ColSchmSet,0),RevisionAttr,&SchemeRev)) goto EXIT;
				}

				printf(" !!!!!!!!!!!! Final selected color scheme [ %s#%s ] For color part [%s]!!!!!!!!!!!!!!!!",SchemeName,SchemeRev,partNumDup);fflush(stdout);
				
				for (i = 0; i < strlen(SchemeName); i++)
				{
					if (SchemeName[i] == '-' || SchemeName[i] == '/')
					{
						SchemeName[i] = '_';
					}
				}
				
				//print in file of Part_Rev_Seq_Scheme.txt
				fprintf(fp, "%s#%s,",SchemeName,SchemeRev); fflush(fp);
				levl = 1;
				if(dstat = ExtractColorBOM(ipPartObjPtr,objColScheme,myPrefSet,levl)) goto CLEANUP;			
			}
		}
	}
	/*********************************************Neha code end**************************************************/
CLEANUP:
 	printf("\nI am in CLEAN UP of Main\n");fflush(stdout);
	if(fp)  fclose(fp) ;
	fp=NULL;
	clLogout ();
	clTerminate ();
EXIT:
	printf("I am in EXIT of Main\n");fflush(stdout);
	return 0;
}