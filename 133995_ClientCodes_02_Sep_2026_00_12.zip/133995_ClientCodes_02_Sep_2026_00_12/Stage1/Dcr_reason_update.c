#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <sa/person.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/envelope.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>

	char *GetDmlReasonDisplay(char *DmlReasonCode)
	{
		char	*Dml_ReasonDisplay			= NULL;

		Dml_ReasonDisplay=(char *)MEM_alloc(200);

		printf("\n Print DmlReasonCode==> [%s]",DmlReasonCode);fflush(stdout);
		if(tc_strcmp(DmlReasonCode,"DR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"DR");
			tc_strcpy(Dml_ReasonDisplay,"DRAFTING ERROR CORRECTION/BOM-CAD QUALITY IMPROVEMENT");
		}
		if(tc_strcmp(DmlReasonCode,"AD")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"AD");
			tc_strcpy(Dml_ReasonDisplay,"ALTERNATE SOURCE DEVELOPMENT");
		}
		if(tc_strcmp(DmlReasonCode,"QU")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"QU");
			tc_strcpy(Dml_ReasonDisplay,"QUALITY");
		}
		if(tc_strcmp(DmlReasonCode,"CM")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"CM");
			tc_strcpy(Dml_ReasonDisplay,"END CUSTOMER/FIELD COMPLAINTS & SERVICE FEEDBACK/CCT");
		}
		if(tc_strcmp(DmlReasonCode,"RR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"RR");
			tc_strcpy(Dml_ReasonDisplay,"REGULATORY REQUIREMENT");
		}
		if(tc_strcmp(DmlReasonCode,"CR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"CR");
			tc_strcpy(Dml_ReasonDisplay,"COST REDUCTION");
		}
		if(tc_strcmp(DmlReasonCode,"ATR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"ATR");
			tc_strcpy(Dml_ReasonDisplay,"ATTRIBUTE REQUIREMENT");
		}
		if(tc_strcmp(DmlReasonCode,"EM")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"EM");
			tc_strcpy(Dml_ReasonDisplay,"ENGINEERING MATURITY (CAE, STYLING, VALIDATION, PROTO FEEDBACK ETC.)");
		}
		if(tc_strcmp(DmlReasonCode,"DFAF")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"DFAF");
			tc_strcpy(Dml_ReasonDisplay,"DFA FEEDBACK");
		}
		if(tc_strcmp(DmlReasonCode,"DFSF")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"DFSF");
			tc_strcpy(Dml_ReasonDisplay,"DFS FEEDBACK");
		}
		if(tc_strcmp(DmlReasonCode,"DFCF")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"DFCF");
			tc_strcpy(Dml_ReasonDisplay,"DFC FEEDBACK");
		}
		if(tc_strcmp(DmlReasonCode,"CMR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"CMR");
			tc_strcpy(Dml_ReasonDisplay,"COMMONIZATION/STANDARDIZATION/COMPLEXITY REDUCTION");
		}
		if(tc_strcmp(DmlReasonCode,"CSC")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"CSC");
			tc_strcpy(Dml_ReasonDisplay,"CONDITION OF SUPPLY CHANGE");
		}
		if(tc_strcmp(DmlReasonCode,"SC")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"SC");
			tc_strcpy(Dml_ReasonDisplay,"SCOPE CHANGES");
		}
		if(tc_strcmp(DmlReasonCode,"RSP")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"RSP");
			tc_strcpy(Dml_ReasonDisplay,"RELEASE OF SPARES/KITS (NO NEW PART DEVELOPMENT)");
		}
		if(tc_strcmp(DmlReasonCode,"WR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"WR");
			tc_strcpy(Dml_ReasonDisplay,"WEIGHT REDUCTION");
		}
		if(tc_strcmp(DmlReasonCode,"IFD")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"IFD");
			tc_strcpy(Dml_ReasonDisplay,"INFO-FITMENT DRAWING (IFD)");
		}
		if(tc_strcmp(DmlReasonCode,"ECFR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"ECFR");
			tc_strcpy(Dml_ReasonDisplay,"ECU CALIBRATION FILE RELEASE");
		}
		if(tc_strcmp(DmlReasonCode,"SA")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"SA");
			tc_strcpy(Dml_ReasonDisplay,"SAMPLES TO BE APPROVED");
		}
		if(tc_strcmp(DmlReasonCode,"DFM")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"DFM");
			tc_strcpy(Dml_ReasonDisplay,"DFM");
		}
		if(tc_strcmp(DmlReasonCode,"DFMF")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"DFM");
			tc_strcpy(Dml_ReasonDisplay,"DFM FEEDBACK");
		}
		if(tc_strcmp(DmlReasonCode,"NR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"NR");
			tc_strcpy(Dml_ReasonDisplay,"NEW REQUIREMENTS (NEW VC, NEW AGGREGATE)");
		}
		if(tc_strcmp(DmlReasonCode,"CFL")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"CFL");
			tc_strcpy(Dml_ReasonDisplay,"CHANGE IN FEATURE LIST");
		}
		if(tc_strcmp(DmlReasonCode,"RSR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"RSR");
			tc_strcpy(Dml_ReasonDisplay,"REGULATORY / SAFETY REQUIREMENTS");
		}
		if(tc_strcmp(DmlReasonCode,"DM")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"DM");
			tc_strcpy(Dml_ReasonDisplay,"DESIGN MATURATION");
		}
		if(tc_strcmp(DmlReasonCode,"SCAS")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"SCAS");
			tc_strcpy(Dml_ReasonDisplay,"STYLING SURFACES (CAS)");
		}
		if(tc_strcmp(DmlReasonCode,"EVI")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"EVI");
			tc_strcpy(Dml_ReasonDisplay,"EVI REPLACEMENTS (BLACK BOX)");
		}
		if(tc_strcmp(DmlReasonCode,"FA")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"FA");
			tc_strcpy(Dml_ReasonDisplay,"FEATURE ADDITION");
		}
		if(tc_strcmp(DmlReasonCode,"BTSC")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"BTSC");
			tc_strcpy(Dml_ReasonDisplay,"BTS SUPPLIER CHANGE (GREY BOX)");
		}
		if(tc_strcmp(DmlReasonCode,"DVLO")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"DVLO");
			tc_strcpy(Dml_ReasonDisplay,"DVLO ISSUES");
		}
		if(tc_strcmp(DmlReasonCode,"4DCHANGE")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"4DCHANGE");
			tc_strcpy(Dml_ReasonDisplay,"4D CHANGES");
		}
		if(tc_strcmp(DmlReasonCode,"VCAE")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"VCAE");
			tc_strcpy(Dml_ReasonDisplay,"VALIDATION / CAE FEEDBACK");
		}
		if(tc_strcmp(DmlReasonCode,"FMPCQRI")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"FMPCQRI");
			tc_strcpy(Dml_ReasonDisplay,"TO FACILITATE MANUFACTURING/ PROCESS CHANGES FOR QUALITY RELIABILITY IMPROVEMENT");
		}
		if(tc_strcmp(DmlReasonCode,"ICWCR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"ICWCR");
			tc_strcpy(Dml_ReasonDisplay,"INTEGRATED COST REDUCTION / WEIGHT REDUCTION / COMPLEXITY REDUCTION");
		}
		if(tc_strcmp(DmlReasonCode,"MMDMR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"MMDMR");
			tc_strcpy(Dml_ReasonDisplay,"MODULE MASTER DATA MANAGEMENT REQUEST");
		}
		if(tc_strcmp(DmlReasonCode,"VAC")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"VAC");
			tc_strcpy(Dml_ReasonDisplay,"VC Attribute Change");
		}
		if(tc_strcmp(DmlReasonCode,"WCR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"WCR");
			tc_strcpy(Dml_ReasonDisplay,"WARRANTY COST REDUCTION");
		}
		if(tc_strcmp(DmlReasonCode,"PQ")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"PQ");
			tc_strcpy(Dml_ReasonDisplay,"IMPROVEMENT IN JD POWER INITIAL QUALITY SCORE");
		}
		if(tc_strcmp(DmlReasonCode,"QR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"QR");
			tc_strcpy(Dml_ReasonDisplay,"QUALITY & RELIABILITY IMPROVEMENT");
		}
		if(tc_strcmp(DmlReasonCode,"QRI")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"QR");
			tc_strcpy(Dml_ReasonDisplay,"QUALITY, WARRANTY & RELIABILITY IMPROVEMENT");
		}
		if(tc_strcmp(DmlReasonCode,"FM")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"FM");
			tc_strcpy(Dml_ReasonDisplay,"TO FACILITATE MANUFACTURING");
		}
		if(tc_strcmp(DmlReasonCode,"SR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"SR");
			tc_strcpy(Dml_ReasonDisplay,"SAFETY REQUIREMENT");
		}
		if(tc_strcmp(DmlReasonCode,"ICR")==0)
		{
			//tc_strcpy(Dml_ReasonCode,"ICR");
			tc_strcpy(Dml_ReasonDisplay,"INTEGRATED COST REDUCTION");
		}
		printf("\n Print Dml_ReasonDisplay==> [%s]",Dml_ReasonDisplay);fflush(stdout);
		return Dml_ReasonDisplay;
	}


int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;

	int  i=0;
	int  reasonFound=0;
	int  reasonIndex=0;
	char*           sUserName	                = NULL;
	char*           sPassword                   = NULL;
	char*           sgroup                      = NULL;
	char*           DCR_no                      = NULL;
	char*           reason_code                      = NULL;
	char*           type_name                   = NULL;
	char*           DcrLcState                   = NULL;
	char*  Dml_Reason_Require	= NULL;
	char*  GetDmlReasonDisplayValue	= NULL;

	tag_t           DCR_tag                      = NULLTAG;
	tag_t           latestDCrTag                 = NULLTAG;
	tag_t           objTypeTag                   = NULLTAG; 
	
	Dml_Reason_Require=(char *)MEM_alloc(100);

	//sUserName = ITK_ask_cli_argument("-u=");
	//sPassword = ITK_ask_cli_argument("-p=");
	//sgroup = ITK_ask_cli_argument("-g=");
	DCR_no    = ITK_ask_cli_argument("-dcr_no=");
	reason_code  = ITK_ask_cli_argument("-r=");

	
	char *newReasonUpdated = (char*) MEM_alloc(50*sizeof(char));

	ifail = ITK_auto_login();
	ifail = ITK_init_module(sUserName, sPassword, sgroup);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	tc_strcpy(Dml_Reason_Require,reason_code);
	printf("\n Dml_Reason_Require is ----[%s] [\n",Dml_Reason_Require);


		if(ITEM_find_item(DCR_no,&DCR_tag)!=ITK_ok);
	    printf("\n DCR number found------>");fflush(stdout);
		if(ITEM_ask_latest_rev(DCR_tag,&latestDCrTag)!=ITK_ok);
		printf("\n DCR revision found------>",latestDCrTag);fflush(stdout);
		if(TCTYPE_ask_object_type(latestDCrTag,&objTypeTag)!=ITK_ok);
		printf("\n DCR object type found------>");fflush(stdout);
		if(TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok);
		printf("\n DCR object name found------>[%s] [\n",type_name);fflush(stdout);

		if (tc_strcmp(type_name,"T5_GenDcrChngRepRevision")==0)
		{
			printf("\n\t\t Inside DCRRev Found loop....");fflush(stdout);
			if(AOM_ask_value_string(latestDCrTag,"t5_DcrLcState",&DcrLcState));
			printf("\n Inside DcrLcState [%s] [\n",DcrLcState);fflush(stdout);

			if (tc_strcmp(DcrLcState,"DCR Created")==0)
			{
				printf("\n\t\t Inside DCR Created LC state Found loop....");fflush(stdout);
				GetDmlReasonDisplayValue = GetDmlReasonDisplay(Dml_Reason_Require);
				printf("\n GetDmlReasonDisplayValue ===>[%s]", GetDmlReasonDisplayValue);fflush(stdout);
						
						AOM_lock(latestDCrTag);
						AOM_refresh(latestDCrTag,TRUE);		   
						AOM_UIF_set_value(latestDCrTag,"t5_DcrCreRC",GetDmlReasonDisplayValue);
						AOM_save_without_extensions(latestDCrTag);
						AOM_unlock(latestDCrTag);
						AOM_refresh(latestDCrTag,FALSE);
				
			}	
		}
}