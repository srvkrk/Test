/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : GetRelDmlList.c
* Created By                   : Amol Narke
* Created On                   : 01/01/2019
* Project                      : Tata Motors TCUA-SAP Interface
* Methods Defined              :
* Description                  : Task Wise SVR Bom transfer to SAP
* Specific Notes               : ./GetRelDmlList -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -f="20-Dec-2023" -t="21-Dec-2023"
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <time.h>
#include <tccore/tctype.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
} 


void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
;

void trimTrailing(char * str)
{
    int index, i;

    /* Set default index */
    index = -1;

    /* Find last index of non-white space character */
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }

        i++;
    }

    /* Mark next character to last non-white space character as NULL */
    str[index + 1] = '\0';
}
;

static int report_wso_object_string_and_owning_user(tag_t object)
{
    char *object_string = NULL;
    char *owning_user = NULL;
    char *item_id = NULL;
    char *date_released = NULL;
    //ITK_CALL(WSOM_ask_object_id_string(object, &object_string));
    //ITK_CALL(AOM_UIF_ask_value(object, "owning_user", &owning_user));
    ITK_CALL(AOM_UIF_ask_value(object, "item_id", &item_id));
    ITK_CALL(AOM_UIF_ask_value(object, "date_released", &date_released));
    //printf("       %s - %s \n", object_string, owning_user);
    printf("%s %s\n", item_id,date_released);
    //MEM_free(object_string);
    //MEM_free(owning_user);
	MEM_free(item_id);
	MEM_free(date_released);
	return ITK_ok;
}

extern int ITK_user_main (int argc, char ** argv )
{
	FILE* fsuccess = NULL;
	FILE* AplDmlFile = NULL;
	FILE* StdDmlFile = NULL;
	FILE* PRTaskFile = NULL;
	FILE* EPAFile = NULL;
	FILE* FilereadStdstatus = NULL;
	FILE* FilereadAplstatus = NULL;

	char fsuccess_name[500];
	char AplDmlFile_name[500];
	char StdDmlFile_name[500];
	char PRTaskFile_name[500];
	char EPAFile_name[500];
	char FilereadStdstatus_name[500];
	char FilereadAplstatus_name[500];

	char* dFromDate = NULL;
	char* dToDate = NULL;
	//char* missing = NULL;
	int sret = 0;
	int LineLength = 0;

	int count = 0;
	tag_t* tags;
	char* sUserName	= NULL;
	char* sPassword = NULL;
	char* dDateReleased = NULL;
	char *date=NULL;
	int three_entries = 3;
	int one_entries = 1;
    
    char *entries[3] = {"Released_After", "Released_Before","Release_Status"};
    //char *PRTaskQryAttr[2] = {"Partial Task Release", "Date Released"};
    char *PRTaskQryAttr[1] = {"Date Released"};
    char **values = NULL;
	char *ErcDmlNo = NULL;
	char *APLDmlNo = NULL;
	char *ReleaseStatus = NULL;

	char lineRead[500];

	tag_t ERC_Query = NULLTAG;
	tag_t APL_Query = NULLTAG;
	tag_t STD_Query = NULLTAG;
	tag_t PRTask_Query = NULLTAG;
	tag_t EPA_Query = NULLTAG;
	int n_items = 0;
    tag_t *items = NULL;
	int ii = 0;
	int i = 0;



	char *Apl_Entries[1] = {"APL Release Date"};
	char *Std_Entries[1] = {"Date Released"};
	char **APlQ_Values = NULL;
	char **APlS_Values = NULL;
    char **PRTaskValue = NULL;
    char **EPAValues = NULL;

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	//dDateReleased = ITK_ask_cli_argument("-d=");
	dFromDate = ITK_ask_cli_argument("-f=");
	dToDate = ITK_ask_cli_argument("-t=");
	//missing = ITK_ask_cli_argument("-m=");
	
	//dFromDate=strtok(dDateReleased," ");

	values = (char **) MEM_alloc(three_entries * sizeof(char *));

	sprintf(FilereadStdstatus_name,"%s/PLMSAP/ReleaseStatus/StdReleasedStatus.txt",getenv("ONLREP"));
	sprintf(FilereadAplstatus_name,"%s/PLMSAP/ReleaseStatus/AplReleasedStatus.txt",getenv("ONLREP"));




	//APlQ_Values[0] = (char *)MEM_alloc( strlen( dDateReleased ) + 1);
	//strcpy(APlQ_Values[0], dDateReleased  );

 //   ITK_CALL(QRY_find2("ERCDMLReleased_DateWise", &ERC_Query));
	  ITK_CALL(QRY_find2("ERC_DML_PLMSAP", &ERC_Query));//added Hrishikesh 16.10.2023



	if(ERC_Query)
	{
		//printf("\nFound Query : ERCDMLReleased_DateWise\n"); fflush(stdout);
		printf("\nFound Query : ERC_DML_PLMSAP\n"); fflush(stdout);//added Hrishikesh 16.10.2023

		//sprintf(fsuccess_name,"/user/plmsap/PLMSAP/ErcReleasedDmlList/ErcDmlList_%s.txt",date);
		sprintf(fsuccess_name,"%s/PLMSAP/ErcReleasedDmlList/ErcDmlList_%s.txt",getenv("ONLREP"),dFromDate);
		//sprintf(fsuccess_name,"ErcDmlList_%s.txt",dFromDate);
		fsuccess = fopen(fsuccess_name,"w");

		//values[0] = (char *)MEM_alloc( strlen( "T5_LcsErcRlzd" ) + 1);
		//strcpy(values[0], "T5_LcsErcRlzd" );

		//values[1] = (char *)MEM_alloc( strlen( "01-Jul-2018 00:00" ) + 1);
		values[0] = (char *)MEM_alloc( strlen( dFromDate ) + 1);
		//strcpy(values[1], "01-Jul-2018 00:00"  );
		strcpy(values[0], dFromDate  );

		values[1] = (char *)MEM_alloc( strlen( dToDate ) + 1);
		//strcpy(values[1], "01-Jul-2018 00:00"  );
		strcpy(values[1], dToDate  );

		/*values[2] = (char *)MEM_alloc( strlen( "T5_LcsErcRlzd" ) + 1);
		strcpy(values[2], "T5_LcsErcRlzd" );*/

		values[2] = (char *)MEM_alloc( strlen( "*ERC Released*" ) + 1);
                strcpy(values[2], "*ERC Released*" );



		ITK_CALL(QRY_execute(ERC_Query, three_entries, entries, values, &n_items, &items));
		
		//printf("\nToday's Date : [%s]	ERC DML Found : [%d]\n",dDateReleased,n_items); fflush(stdout);
		printf("\nERC_DML_PLMSAP n_items: [%d]\n",n_items); fflush(stdout);
		if (n_items>0)
		{
			for ( ii = 0; ii < n_items; ii++)
			{
				report_wso_object_string_and_owning_user(items[ii]);
				ITK_CALL(AOM_ask_value_string(items[ii],"item_id",&ErcDmlNo));
				printf("%s\n",ErcDmlNo); fflush(stdout);
				fprintf(fsuccess,"%s\n",ErcDmlNo);
			}
			if(values) MEM_free(values);
			if(items) MEM_free(items);
		}
	}
	else
	{
		printf("\nQuery Not Found : ERC_DML_PLMSAP\n"); fflush(stdout);
	}

    //ITK_CALL(QRY_find2("APLDML_APLReleaseDateWise", &APL_Query));
    ITK_CALL(QRY_find2("APL_DML_PLMSAP", &APL_Query));

	if(APL_Query)
	{
		printf("\nFound Query : APL_DML_PLMSAP\n"); fflush(stdout);

		//sprintf(AplDmlFile_name,"/user/plmsap/PLMSAP/AplReleasedDmlList/AplDmlList_%s.txt",date);
		//sprintf(AplDmlFile_name,"/user/uaprodtrl/PLMSAP/AplReleasedDmlList/AplDmlList_%s.txt",date);
		sprintf(AplDmlFile_name,"%s/PLMSAP/AplReleasedDmlList/AplDmlList_%s.txt",getenv("ONLREP"),dFromDate);
		//sprintf(AplDmlFile_name,"AplDmlList_%s.txt",dFromDate);
		AplDmlFile = fopen(AplDmlFile_name,"w");


		FilereadAplstatus = fopen(FilereadAplstatus_name,"r");

		while(fgets(lineRead,500,FilereadAplstatus))
		{
			
			trimLeading(lineRead);
			trimTrailing(lineRead);

			printf("\nRelease Status in file : [%s]",lineRead); fflush(stdout);
			ReleaseStatus = tc_strtok(lineRead,",");

			while (tc_strcmp(ReleaseStatus,"")!=0)
			{

				printf("\nRelease Status : [%s]",ReleaseStatus); fflush(stdout);

				APlQ_Values = (char **) MEM_alloc(three_entries * sizeof(char *));

				APlQ_Values[0] = (char *)MEM_alloc( strlen( dFromDate ) + 1);
				//strcpy(values[1], "01-Jul-2018 00:00"  );
				strcpy(APlQ_Values[0], dFromDate  );

				APlQ_Values[1] = (char *)MEM_alloc( strlen( dToDate ) + 1);
				//strcpy(values[1], "01-Jul-2018 00:00"  );
				strcpy(APlQ_Values[1], dToDate  );

				//APlQ_Values[2] = (char *)MEM_alloc( strlen( "T5_LcsAplRlzd" ) + 1);
				//strcpy(APlQ_Values[2], "T5_LcsAplRlzd" );

				APlQ_Values[2] = (char *)MEM_alloc( strlen( ReleaseStatus ) + 1);
				strcpy(APlQ_Values[2], ReleaseStatus );

				//ITK_CALL(QRY_execute(APL_Query, one_entries, Apl_Entries, APlQ_Values, &n_items, &items));
				ITK_CALL(QRY_execute(APL_Query, three_entries, entries, APlQ_Values, &n_items, &items));
				//printf("\nToday's Date : [%s]	APL DML Found : [%d]\n",dDateReleased,n_items); fflush(stdout);
				printf("\nAPL_DML_PLMSAP APL released n_items: [%d]\n",n_items); fflush(stdout);

				if (n_items>0)
				{
					for ( ii = 0; ii < n_items; ii++)
					{
						report_wso_object_string_and_owning_user(items[ii]);
						ITK_CALL(AOM_ask_value_string(items[ii],"item_id",&APLDmlNo)!=ITK_ok);
						printf("%s\n",APLDmlNo); fflush(stdout);
						fprintf(AplDmlFile,"%s\n",APLDmlNo);
					}
					if(APlQ_Values) MEM_free(APlQ_Values);
					if(items) MEM_free(items);
				}

				ReleaseStatus = tc_strtok(NULL,",");
			}
		}
		
		//if(lineRead) MEM_free(lineRead);
		fclose(FilereadAplstatus);

	}
	else
	{
		printf("\nQuery Not Found : APL_DML_PLMSAP\n"); fflush(stdout);
	}

	//ITK_CALL(QRY_find2("APLDML_STDReleaseDateWise", &STD_Query));
	ITK_CALL(QRY_find2("APL_DML_PLMSAP", &STD_Query));

	if(STD_Query)
	{
		//printf("\nFound Query : APLDML_STDReleaseDateWise\n"); fflush(stdout);
		printf("\nFound Query : APL_DML_PLMSAP\n"); fflush(stdout);

		//sprintf(StdDmlFile_name,"/user/plmsap/PLMSAP/StdReleasedDmlList/StdDmlList_%s.txt",date);
		//sprintf(StdDmlFile_name,"/user/uaprodtrl/PLMSAP/StdReleasedDmlList/StdDmlList_%s.txt",date);
		sprintf(StdDmlFile_name,"%s/PLMSAP/StdReleasedDmlList/StdDmlList_%s.txt",getenv("ONLREP"),dFromDate);
		//sprintf(StdDmlFile_name,"StdDmlList_%s.txt",dFromDate);
		StdDmlFile = fopen(StdDmlFile_name,"w");

		FilereadStdstatus = fopen(FilereadStdstatus_name,"r");

		while(fgets(lineRead,500,FilereadStdstatus))
		{
			
			trimLeading(lineRead);
			trimTrailing(lineRead);

			printf("\nRelease Status in file : [%s]",lineRead); fflush(stdout);
			ReleaseStatus = tc_strtok(lineRead,",");

			while (tc_strcmp(ReleaseStatus,"")!=0)
			{

				printf("\nRelease Status : [%s]",ReleaseStatus); fflush(stdout);
				APlS_Values = (char **) MEM_alloc(three_entries * sizeof(char *));

				APlS_Values[0] = (char *)MEM_alloc( strlen( dFromDate ) + 1);
				//strcpy(values[1], "01-Jul-2018 00:00"  );
				strcpy(APlS_Values[0], dFromDate  );

				APlS_Values[1] = (char *)MEM_alloc( strlen( dToDate ) + 1);
				//strcpy(values[1], "01-Jul-2018 00:00"  );
				strcpy(APlS_Values[1], dToDate  );

				APlS_Values[2] = (char *)MEM_alloc( strlen( ReleaseStatus ) + 1);
				strcpy(APlS_Values[2], ReleaseStatus );



				ITK_CALL(QRY_execute(STD_Query, three_entries, entries, APlS_Values, &n_items, &items));
				//printf("\nToday's Date : [%s]	STD Released DML Found : [%d]\n",dDateReleased,n_items); fflush(stdout);
				printf("\nAPL_DML_PLMSAP STD released n_items: [%d]\n",n_items); fflush(stdout);

				if (n_items>0)
				{
					for ( ii = 0; ii < n_items; ii++)
					{
						report_wso_object_string_and_owning_user(items[ii]);
						ITK_CALL(AOM_ask_value_string(items[ii],"item_id",&APLDmlNo));
						printf("%s\n",APLDmlNo); fflush(stdout);
						fprintf(AplDmlFile,"%s\n",APLDmlNo);
						fprintf(StdDmlFile,"%s\n",APLDmlNo);
					}
					if(APlS_Values) MEM_free(APlS_Values);
					if(items) MEM_free(items);
				}

				ReleaseStatus = tc_strtok(NULL,",");
			}
		}
		
		//if(lineRead) MEM_free(lineRead);
		fclose(FilereadStdstatus);
	}
	else
	{
		printf("\nQuery Not Found : APL_DML_PLMSAP\n"); fflush(stdout);
	}



	ITK_CALL(QRY_find2("APL_TASK_PLMSAP", &PRTask_Query));

	if(PRTask_Query)
	{
		printf("\nFound Query : tm_APLPRTaskReleased\n"); fflush(stdout);

		//sprintf(PRTaskFile_name,"/user/plmsap/PLMSAP/StdReleasedDmlList/PRTaskList_%s.txt",date);
		//sprintf(PRTaskFile_name,"/user/uaprodtrl/PLMSAP/StdReleasedDmlList/PRTaskList_%s.txt",date);
		sprintf(PRTaskFile_name,"%s/PLMSAP/StdReleasedDmlList/PRTaskList_%s.txt",getenv("ONLREP"),dFromDate);
		//sprintf(PRTaskFile_name,"PRTaskList_%s.txt",dFromDate);
		PRTaskFile = fopen(PRTaskFile_name,"w");

		FilereadStdstatus = fopen(FilereadStdstatus_name,"r");

		while(fgets(lineRead,500,FilereadStdstatus))
		{
			
			trimLeading(lineRead);
			trimTrailing(lineRead);

			printf("\nRelease Status in file : [%s]",lineRead); fflush(stdout);
			ReleaseStatus = tc_strtok(lineRead,",");

			while (tc_strcmp(ReleaseStatus,"")!=0)
			{

				printf("\nRelease Status : [%s]",ReleaseStatus); fflush(stdout);
				PRTaskValue = (char **) MEM_alloc(three_entries * sizeof(char *));


				//values[1] = (char *)MEM_alloc( strlen( "01-Jul-2018 00:00" ) + 1);
				PRTaskValue[0] = (char *)MEM_alloc( strlen( dFromDate ) + 1);
				//strcpy(values[1], "01-Jul-2018 00:00"  );
				strcpy(PRTaskValue[0], dFromDate  );

				PRTaskValue[1] = (char *)MEM_alloc( strlen( dToDate ) + 1);
				//strcpy(values[1], "01-Jul-2018 00:00"  );
				strcpy(PRTaskValue[1], dToDate  );

				//PRTaskValue[2] = (char *)MEM_alloc( strlen( "T5_LcsStdRlzd" ) + 1);
				////strcpy(values[1], "01-Jul-2018 00:00"  );
				//strcpy(PRTaskValue[2], "T5_LcsStdRlzd"  );

				PRTaskValue[2] = (char *)MEM_alloc( strlen( ReleaseStatus ) + 1);
				//strcpy(values[1], "01-Jul-2018 00:00"  );
				strcpy(PRTaskValue[2], ReleaseStatus );




				ITK_CALL(QRY_execute(PRTask_Query, three_entries, entries, PRTaskValue, &n_items, &items));
				//printf("\nToday's Date : [%s]	STD Released PR Task Found : [%d]\n",dDateReleased,n_items); fflush(stdout);
				printf("\nAPL_TASK_PLMSAP n_items: [%d]\n",n_items); fflush(stdout);

				if (n_items>0)
				{
					for ( ii = 0; ii < n_items; ii++)
					{
						report_wso_object_string_and_owning_user(items[ii]);
						ITK_CALL(AOM_ask_value_string(items[ii],"item_id",&APLDmlNo));
						printf("%s\n",APLDmlNo); fflush(stdout);
						fprintf(PRTaskFile,"%s\n",APLDmlNo);
					}
					
					if(PRTaskValue) MEM_free(PRTaskValue);
					if(items) MEM_free(items);
				}

				ReleaseStatus = tc_strtok(NULL,",");
			}
		}
		

		//if(lineRead) MEM_free(lineRead);
		fclose(FilereadStdstatus);
	}
	else
	{
		printf("\nQuery Not Found : tm_APLPRTaskReleased\n"); fflush(stdout);
	}

	//tm_EPA_STDReleased

	//ITK_CALL(QRY_find2("tm_EPA_STDReleased", &EPA_Query));
	ITK_CALL(QRY_find2("EPA_PLMSAP", &EPA_Query));

	if(EPA_Query)
	{
		//printf("\nFound Query : tm_EPA_STDReleased\n"); fflush(stdout);
		printf("\nFound Query : EPA_PLMSAP\n"); fflush(stdout);

		
		//sprintf(EPAFile_name,"/user/plmsap/PLMSAP/EPA_List/EPAList_%s.txt",date);
		//sprintf(EPAFile_name,"/user/uaprodtrl/PLMSAP/EPA_List/EPAList_%s.txt",date);
		sprintf(EPAFile_name,"%s/PLMSAP/EPA_List/EPAList_%s.txt",getenv("ONLREP"),dFromDate);
		//sprintf(EPAFile_name,"EPAList_%s.txt",dFromDate);
		EPAFile = fopen(EPAFile_name,"w");

		FilereadStdstatus = fopen(FilereadStdstatus_name,"r");

		while(fgets(lineRead,500,FilereadStdstatus))
		{
			
			trimLeading(lineRead);
			trimTrailing(lineRead);

			printf("\nRelease Status in file : [%s]",lineRead); fflush(stdout);
			ReleaseStatus = tc_strtok(lineRead,",");

			while (tc_strcmp(ReleaseStatus,"")!=0)
			{

				printf("\nRelease Status : [%s]",ReleaseStatus); fflush(stdout);
				EPAValues = (char **) MEM_alloc(three_entries * sizeof(char *));





				EPAValues[0] = (char *)MEM_alloc( strlen( dFromDate ) + 1);
				//strcpy(values[1], "01-Jul-2018 00:00"  );
				strcpy(EPAValues[0], dFromDate  );

				EPAValues[1] = (char *)MEM_alloc( strlen( dToDate ) + 1);
				//strcpy(values[1], "01-Jul-2018 00:00"  );
				strcpy(EPAValues[1], dToDate  );

				EPAValues[2] = (char *)MEM_alloc( strlen( ReleaseStatus ) + 1);
				//strcpy(values[1], "01-Jul-2018 00:00"  );
				strcpy(EPAValues[2], ReleaseStatus  );


				ITK_CALL(QRY_execute(EPA_Query, three_entries, entries, EPAValues, &n_items, &items));
				printf("\nEPA_PLMSAP n_items: [%d]",n_items); fflush(stdout);

				if (n_items>0)
				{
					for ( ii = 0; ii < n_items; ii++)
					{
						report_wso_object_string_and_owning_user(items[ii]);
						ITK_CALL(AOM_ask_value_string(items[ii],"item_id",&APLDmlNo));
						printf("%s\n",APLDmlNo); fflush(stdout);
						fprintf(EPAFile,"%s\n",APLDmlNo);
					}
					
					if(EPAValues) MEM_free(EPAValues);
					if(items) MEM_free(items);
				}
				ReleaseStatus = tc_strtok(NULL,",");
			}
		}

		//if(lineRead) MEM_free(lineRead);
		fclose(FilereadStdstatus);
	}
	else
	{
		printf("\nQuery Not Found : EPA_PLMSAP\n"); fflush(stdout);
	}




	//if(APlQ_Values) MEM_free(APlQ_Values);
	//if(values) MEM_free(values);
	//if(PRTaskValue) MEM_free(PRTaskValue);
	fclose(fsuccess);
	fclose(AplDmlFile);
	fclose(StdDmlFile);
	fclose(PRTaskFile);
	fclose(EPAFile);

	return ITK_ok;
}
