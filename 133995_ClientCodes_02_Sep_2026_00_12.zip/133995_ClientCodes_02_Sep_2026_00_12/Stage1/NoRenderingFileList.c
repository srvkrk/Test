/****************************************************************************************************
*  File            :   t5UpdSupersededValOnBomLine.c
*  Created By      :   Anu Nair
*  Created On      :   21 Nov 2016
*  Purpose         :   To Update BOMLine Superseded Value to TRUE for Child Parts provided in the input file.
*  Usage		   :   ./NoRenderingFileList -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -fromDate="11-Feb-2025 06:00" -toDate="12-Feb-2025 23:59" -sType="CMI2Part" -rType="DirectModel" -outFile="/proj/plmdownload/scratch/CMI2Part_12_Feb_2025_14_56_nojt.txt"
*****************************************************************************************************/
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h> 
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <user_exits/user_exits.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ctype.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include<stdio.h>
#include<string.h>

#define CONNECT_FAIL (EMH_USER_error_base + 2)

#define WRONG_USAGE 100001
char* subString (char* mainStringf ,int fromCharf,int toCharf);

void dousage()
{
   printf("\nUSAGE: NoRenderingFileList -fromDate= -toDate= -sType= -rType= -outFile= \n");
   printf("\E.g: NoRenderingFileList -fromDate=01-May-2018 -toDate=02-May-2018 -sType=CMI2Part -rType=DirectModel -outFile=out.txt \n");
   return;
}

void lower_string(char s[]) 
{
	int c = 0;

	while (s[c] != '\0') 
	{
		if (s[c] >= 'A' && s[c] <= 'Z') 
		{
			s[c] = s[c] + 32;
		}
		c++;
	}
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

typedef struct  
{
    char partnumbers[100]; 
	char* sequences[4];
} InputFile;

int ITK_user_main(int argc, char* argv[])
{
	int status;
	int i = 0;
	int j = 0;
	int prints = 0;
	int resultCount = 0;
	int secObjCount = 0;
	int n_entries = 3;
	
	int sVersion = 0;
	char *sDsetObj=NULL;
	char *sItemId=NULL;
	char *LatestRevID=NULL;
	char *s;
	
	char *sItemRev			  = NULL;
	char *sItemSeq			  = NULL;

	char *qry_entries4[3] = {"start_last_mod_date","end_last_mod_date","specification_object_type"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	
	FILE *fp = NULL;
	logical is_chkout;
	tag_t queryTag;
	tag_t secObjTypeTag;
	tag_t Relatn_type;
	tag_t Relatn_type1;
	tag_t* rev;
	tag_t* secObj;

	//char type_name2[TCTYPE_name_size_c+1];
	char *type_name2 = NULL;
   
	//Getting Input Arguments
	//char* usr = ITK_ask_cli_argument("-u=");/* gets user */
	//char* upw = ITK_ask_cli_argument("-pf=");/* gets the password */
	//char* ugp = ITK_ask_cli_argument("-g=");/* what the group is */
	char* fromDate = ITK_ask_cli_argument("-fromDate=");/* what is the PartNumber */
	char* toDate = ITK_ask_cli_argument("-toDate=");/* what the REV is */
	char* sType = ITK_ask_cli_argument("-sType=");/* what the SEQ is */
	char* rType = ITK_ask_cli_argument("-rType=");/* Input file name is */
	char* outFile = ITK_ask_cli_argument("-outFile=");/* Input file name is */

	printf("\nStarting Program -- NoRenderingFileList\n");fflush(stdout);
	//If input is missing prompt at command line the usage. 
	/*if (( !usr) || (!upw) || (!ugp) || (!fromDate) || (!toDate) || (!sType) || (!rType) || (!outFile))	    
	{
		dousage();
		return WRONG_USAGE ;
	}*/
	if ((!fromDate) || (!toDate) || (!sType) || (!rType) || (!outFile))	    
	{
		dousage();
		return WRONG_USAGE ;
	}

	ITK_initialize_text_services (0);
	//status = ITK_init_module( "loader","loader7","dba");
	status = ITK_auto_login();

	if(status =ITK_ok)
	{
	   printf("\n LOGIN SUCCESSFUL\n");fflush(stdout);
	}

	if (status != ITK_ok)
	{
	  EMH_ask_error_text( status, &s);
	  printf("\n*** Error with ITK_init_module: %s ***\n",s);fflush(stdout);
	  MEM_free(s);
	  return status;
	}

	printf("\n From Date : %s ***\n",fromDate);
	printf("\n To Date : %s ***\n",toDate);
	printf("\n Dataset Type : %s ***\n",sType);
	printf("\n Visualization Type : %s ***\n",rType);
	printf("\n Output FileName : %s ***\n",outFile);fflush(stdout);
	
	//Find QUery
	status = QRY_find2("QueryDesRevWithNoJTPDF", &queryTag);
	if (status != ITK_ok)
	{
	  EMH_ask_error_text( status, &s);
	  printf("\n*** Error with Finding Query QueryDesRevWithNoJTPDF ***\n");fflush(stdout);
	  MEM_free(s);
	  return status;
	}	

	if (queryTag)
	{
		printf("Found Query QueryDesRevWithNoJTPDF \n"); fflush(stdout);
	}
	else
	{
		printf("*** Query QueryDesRevWithNoJTPDF Not Found *** \n"); fflush(stdout);
		return status;
	}

	//qry_values[0] = User_id;
	qry_values[0] = fromDate;
	qry_values[1] = toDate;
	qry_values[2] = sType;
	
	
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &rev);
	
	printf("\nNo. of Design Revision Object Found are -- %d\n", resultCount);fflush(stdout);

	if(resultCount > 0)
	{		
		if(!fp) fp = fopen(outFile,"w");
		GRM_find_relation_type("IMAN_Rendering",&Relatn_type);
		GRM_find_relation_type("IMAN_specification",&Relatn_type1);
		//Looping
		for (i=0;i<resultCount ; i++)
		{	
			prints = 0;
			RES_is_checked_out(rev[i],&is_chkout);

			printf("\nChecked Out Value is -- %d \n",is_chkout); fflush(stdout);
			
			if(is_chkout == 0)
			{
			
				//Getting IMAN_Rendering Object List
				GRM_list_secondary_objects_only (rev[i],Relatn_type,&secObjCount,&secObj);
				printf("\nNo. of Dataset in Rendering Relationship -- %d\n", secObjCount);fflush(stdout);

				for (j=0;j<secObjCount ; j++)
				{
					if(TCTYPE_ask_object_type(secObj[j],&secObjTypeTag));
					if(TCTYPE_ask_name2(secObjTypeTag,&type_name2));
					printf("\n\t Rendering Object Type Tag  [%s] \n",type_name2); fflush(stdout);

					if(tc_strcmp(type_name2, rType) == 0)
					{
						prints = 1;
						break;
					}
				}		

				MEM_free(secObj);
				
				printf("\nValue of prints -- %d\n", prints);fflush(stdout);
				if(prints == 0)
				{
					//Getting IMAN_specification Object List
					GRM_list_secondary_objects_only (rev[i],Relatn_type1,&secObjCount,&secObj);
					printf("\nNo. of Dataset in Specification Relationship -- %d\n", secObjCount);fflush(stdout);
					for (j=0;j<secObjCount ; j++)
					{
						if(TCTYPE_ask_object_type(secObj[j],&secObjTypeTag));
						if(TCTYPE_ask_name2(secObjTypeTag,&type_name2));
						printf("\n\t Specification Object Type Tag  [%s] \n",type_name2); fflush(stdout);

						if(tc_strcmp(type_name2, sType) == 0)
						{
							AOM_ask_value_int(secObj[j],"revision_number",&sVersion);
							AOM_ask_value_string(secObj[j],"object_string",&sDsetObj);
							AOM_ask_value_string(rev[i],"item_id",&sItemId);
							AOM_ask_value_string(rev[i],"item_revision_id",&LatestRevID);

							sItemRev = strtok(LatestRevID, ";");
							sItemSeq = strtok(NULL, ";");
							//fprintf(fp,"%s,%s,IMAN_Rendering,%s,%d\n",sItemId,LatestRevID,sDsetObj,sVersion);fflush(fp);
							fprintf(fp,"%s %s %s\n",sItemId,sItemRev,sItemSeq);fflush(fp);
						}
					}

					MEM_free(secObj);				
				}
			}
		}

		MEM_free(rev);	
	}
	
	if(fp) fclose(fp);
	
	printf("\nExiting Program -- NoRenderingFileList\n");fflush(stdout);
	return status;		 
}