#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/tctype.h>
#include <fclasses/tc_string.h>
#include <time.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}


void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

extern int ITK_user_main (int argc, char ** argv )
{
	char* UserName		= NULL;
	char* Password		= NULL;
	char* InputFile		= NULL;


	tag_t classTypeTags		= NULLTAG;
	tag_t newPackageTag		= NULLTAG;
	tag_t newPackageObj		= NULLTAG;

	int one_entry = 1;
	int QryOPCount = 0;
	int lineCount = 0;
	int s = 0, iPCount = 0, iFCount = 0;
	
	FILE *InpFile = NULL;

	char  type_name[TCTYPE_name_size_c+1];


	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char text_line[500];
	
	char *PartNum		= NULL;
	char *PartRev		= NULL;
	char *PartSeq		= NULL;
	char *cad2DFlag		= NULL;
	char *pdfFlag		= NULL;
	char *jtFlag		= NULL;
	char *cad3DFlag		= NULL;
	char *supplierID	= NULL;
	char *tcuaUserID	= NULL;
	char *context		= NULL;
	char *view			= NULL;
	
	char *PartNumStr		= (char *) MEM_alloc(20*sizeof(char ));
	char *PackageNumStr		= (char *) MEM_alloc(50*sizeof(char ));

	char **PartNumList = NULL;
	char **DataFormatList = NULL;

	PartNumList = (char**)MEM_alloc( 1 * sizeof *PartNumList );
	DataFormatList = (char**)MEM_alloc( 1 * sizeof *DataFormatList );

	int nClassTypes = 0;

	time_t NowTime;
	struct tm *timeinfo;
	char	*timestamp = (char *) MEM_alloc(20 * sizeof(char));
	char	*EffDate = (char *) MEM_alloc(10 * sizeof(char));

	//ITK_CALL(ITK_init_module("loader" ,"loader7","dba")) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));

	UserName = ITK_ask_cli_argument("-u=");
	Password = ITK_ask_cli_argument("-p=");
	InputFile = ITK_ask_cli_argument("-f=");


	printf("\nInput File : %s\n",InputFile); fflush(stdout);
	
	InpFile = fopen(InputFile,"r");

	time(&NowTime);
	timeinfo = localtime(&NowTime);
	strftime(timestamp, 20, "%Y_%m_%d_%H_%M_%S", timeinfo);
	strftime(EffDate, 20, "%m/%d/%Y", timeinfo);
	printf("\ntimestamp %s",timestamp);
	
	printf("\nEffDate %s",EffDate);

	while (fscanf(InpFile, "%s", text_line)!=EOF)
	{

        printf("\nLine Number : %d\n",lineCount);
        printf("\n%s",text_line);

		PartNum		= tc_strtok(text_line,"~");
		PartRev		= tc_strtok(NULL,"~");
		PartSeq		= tc_strtok(NULL,"~");
		cad2DFlag	= tc_strtok(NULL,"~");
		pdfFlag		= tc_strtok(NULL,"~");
		jtFlag		= tc_strtok(NULL,"~");
		cad3DFlag	= tc_strtok(NULL,"~");
		supplierID	= tc_strtok(NULL,"~");
		tcuaUserID	= tc_strtok(NULL,"~");
		context		= tc_strtok(NULL,"~");
		view		= tc_strtok(NULL,"~");
		
		printf("\n\n");
		printf("\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s",PartNum,PartRev,PartSeq,cad2DFlag,pdfFlag,jtFlag,cad3DFlag,supplierID,tcuaUserID,context,view);

		tc_strcpy(PartNumStr,"");
		tc_strcpy(PartNumStr,PartNum);
		tc_strcat(PartNumStr,"/");
		tc_strcat(PartNumStr,PartRev);
		tc_strcat(PartNumStr,";");
		tc_strcat(PartNumStr,PartSeq);

		printf("\nPartNumStr : [%s]",PartNumStr);

		setAddStr(&iPCount,&PartNumList,PartNumStr);
		
		printf("\nPartNum Added [%d] : [%s]",lineCount,PartNumList[lineCount]);

		lineCount++;
    }

	fclose(InpFile);

	for (s=0;s<lineCount ;s++ )
	{
		printf("\nPartNumList [%d] : [%s]",s,PartNumList[s]);
	}

	if (tc_strcmp(cad2DFlag,"+")==0)
	{
		setAddStr(&iFCount,&DataFormatList,"CAD2D");
	}

	if (tc_strcmp(pdfFlag,"+")==0)
	{
		setAddStr(&iFCount,&DataFormatList,"PDFVis");
	}

	if (tc_strcmp(jtFlag,"+")==0)
	{
		setAddStr(&iFCount,&DataFormatList,"JTVis");
	}

	if (tc_strcmp(cad3DFlag,"+")==0)
	{
		setAddStr(&iFCount,&DataFormatList,"CAD3D");
	}

	tc_strcpy(PackageNumStr,"");
	tc_strcpy(PackageNumStr,PartNumList[0]);
	tc_strcat(PackageNumStr,"_");
	tc_strcat(PackageNumStr,timestamp);

	printf("\nPackageNumStr : [%s]",PackageNumStr);
	
	printf("\nPart Count %d\nData Format Count %d",iPCount,iFCount);

	//DateTime {4/23/2021}

	//TCTYPE_find_types_for_class("T5_Package",&nClassTypes,&classTypeTags);
	ITK_CALL(TCTYPE_find_type("T5_Package", NULL, &classTypeTags));
	ITK_CALL(TCTYPE_construct_create_input(classTypeTags, &newPackageTag));
	
	printf("\nPackage create start");
	ITK_CALL(AOM_set_value_string(newPackageTag,"t5_PackType","t5BuildPack"));
	ITK_CALL(AOM_set_value_string(newPackageTag,"object_name",PackageNumStr));
	ITK_CALL(AOM_set_value_strings(newPackageTag,"t5_PartNumList",iPCount,PartNumList));
	ITK_CALL(AOM_set_value_strings(newPackageTag,"t5_FileType",iFCount,DataFormatList));
	//ITK_CALL(AOM_UIF_set_value(newPackageTag,"t5_FileType",DataFormatList[0]));
	ITK_CALL(AOM_set_value_string(newPackageTag,"t5_CfgContext",context));
	ITK_CALL(AOM_set_value_string(newPackageTag,"t5_ViewName",view));
	ITK_CALL(AOM_set_value_string(newPackageTag,"t5_VendorID",supplierID));
	ITK_CALL(AOM_set_value_string(newPackageTag,"t5_PackTitle",EffDate));

	ITK_CALL(TCTYPE_create_object(newPackageTag, &newPackageObj));
	printf("\nPackage create End\n");

	if(newPackageObj) 
	{
		ITK_CALL(AOM_save(newPackageObj));
		ITK_CALL(AOM_refresh(newPackageObj,TRUE));
		printf("\nNewPackageObj object created\n"); fflush(stdout);

		tag_t LCS_tag      = NULLTAG;
		tag_t ProcessTag   = NULLTAG;
		int attachment_types    = 1;

		ITK_CALL(EPM_find_template2("SupplierDataSharinglcs",0,&LCS_tag));
		ITK_CALL(EPM_create_process("SupplierDataSharinglcs","Package Workflow",LCS_tag,1,&newPackageObj,&attachment_types,&ProcessTag));

	}

	/*if(newPackageObj)
	{
		ITK_CALL(AOM_lock(newPackageObj));
		ITK_CALL(AOM_set_value_strings(newPackageObj,"t5_PartNumList",lineCount+1,PartNumList));
		ITK_CALL(AOM_save(newPackageObj));
		ITK_CALL(AOM_refresh(newPackageObj, TRUE));
	}*/

	printf("\n\n");

	ITK_CALL(POM_logout(false));
	return ITK_ok;

	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP...\n"); fflush(stdout);
}
