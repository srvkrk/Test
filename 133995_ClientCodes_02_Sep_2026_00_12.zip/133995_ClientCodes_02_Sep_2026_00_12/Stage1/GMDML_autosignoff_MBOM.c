#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <time.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <tc/folder.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tc/envelope.h>
#include <tccore/aom_prop.h>
#include <cfm/cfm.h>
int icount1 = 0;
int icount2 = 0;
int icount3 = 0;
int cntFlag = 0;


#define ITK_CALL(x) {           \
    int stat;                     \
    char *err_string;             \
    if( (stat = (x)) != ITK_ok)   \
    {                             \
    EMH_ask_error_text (stat, &err_string);                 \
    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
    if(err_string) MEM_free(err_string);                                \
    exit (EXIT_FAILURE);                                                   \
    }                                                                    \
}

void setAddStrFuction(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStrFuction %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStrFuction===%s",(*strset)[*count-1]);fflush(stdout);

}

void reverse(char *s)
{
   int length, c;
   char *begin, *end, temp;
 
   length = tc_strlen(s);
   begin  = s;
   end    = s;
 
   for (c = 0; c < length - 1; c++)
      end++;
 
   for (c = 0; c < length/2; c++)
   {        
      temp   = *end;
      *end   = *begin;
      *begin = temp;
 
      begin++;
      end--;
   }
}

int	tm_Find_SVR_FROM_CCV(tag_t t_CCVtag, tag_t *t_SVRtag)
{
	int	status;
	
	int		svrcnt				=	0;
	
	char	*CCVNumber			=	NULL;

	tag_t	t_DerivedSVR		=	NULLTAG;
	tag_t	t_SVR				=	NULLTAG;
	tag_t	*svrList			=	NULLTAG;
	
	ITKCALL(GRM_find_relation_type("T5_DerivedFromSVR",&t_DerivedSVR));
	
	if(t_DerivedSVR!=NULLTAG)
	{
		if(AOM_ask_value_string(t_CCVtag,"item_id",&CCVNumber));
		printf("\n123Object name : %s ",CCVNumber);fflush(stdout);
								
		svrcnt	=	0;
		svrList	=	NULLTAG;
		ITKCALL(GRM_list_secondary_objects_only(t_CCVtag,t_DerivedSVR,&svrcnt,&svrList));
		printf("\nNumber of svr attached with CCV : %d",svrcnt);fflush(stdout);
		
		if(svrcnt>0)
		{
			t_SVR	=	svrList[0];
			if(t_SVR!=NULLTAG)
			{
				*t_SVRtag	=	t_SVR;
			}
		}
		else{
			printf("\nZero SSVR Found in Derived from SVR Releation");fflush(stdout);
		}
	}
	else{
		printf("\nt_DerivedSVR relation is NULLTAG");fflush(stdout);
		*t_SVRtag	=	NULLTAG;
	}
	
	printf("\nInside tm_Find_SVR_FROM_CCV");fflush(stdout);
	return status;
}

void PlantWiseRelStatGMDML( char * item_id,char  getLCSAPLRlzd[40],char  getLCSSTDRlzd[40])
{
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	
    
	char  ItemIDCpy[40];

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *LCSAPLRlzd			= NULL;
	 char *LCSSTDRlzd			= NULL;	

	printf( "item_id:%s\n", item_id);
	tc_strcpy(ItemIDCpy,item_id);
	printf("\n ItemIDCpy is : %s\n",ItemIDCpy);fflush(stdout);
	Dsgn_No=tc_strtok(ItemIDCpy,"_");	
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,ItemIDCpy);
	 

	ITKCALL( QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLStateInf";
		qry_valuesCntrl1[1]=PLT_Code;
		qry_valuesCntrl1[2]="0";
		
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	else
	{
		printf("\n Control Object Query not Found \n");fflush(stdout);
	}	
	
	printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

	if(control_number_found1>0)
	{

		ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &LCSAPLRlzd));
		printf("\n LCSAPLRlzd: %s\n",LCSAPLRlzd);fflush(stdout);

		ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &LCSSTDRlzd));
		printf("\n LCSSTDRlzd: %s\n",LCSSTDRlzd);fflush(stdout);

		tc_strcpy(getLCSAPLRlzd,LCSAPLRlzd);
		tc_strcpy(getLCSSTDRlzd,LCSSTDRlzd);
	}

	printf( "getLCSAPLRlzd:%s\n", getLCSAPLRlzd);
	printf( "getLCSSTDRlzd:%s\n", getLCSSTDRlzd);

}

int CheckPrtRelsFrmPlant_APL(tag_t TaskTag,char *SetChildRelErr,int *icount) 
{
	char* inp_Tsk_no=NULL;
	tag_t relation_type	=NULLTAG;
	tag_t	*prtList				=	NULLTAG;
	int prtcnt =0;
	int i,ii=0;
	tag_t prtTAG =NULLTAG;
	char* PartNumbr =NULL;
	char* itemobjecttype =NULL;
	int status_count			=0;
	tag_t*	status_list		=NULLTAG;
	char*  ReleaseStatus	=NULL;
	char LcsAPLRlzd[40];
	char LcsSTDRlzd[40];

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
    int cntrlcnt=0;
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
    tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	int     error =0;
	int     errorFlg=0;
	char *partset =NULL;
	partset=(char *)MEM_alloc(1000);
	int   cnt =0;


	printf("\n###########Inside CheckPrtRelsFrmPlant_APL###################\n");fflush(stdout);

	ITKCALL(AOM_ask_value_string(TaskTag,"item_id",&inp_Tsk_no));
	printf("\n inp_Tsk_no  is :%s",inp_Tsk_no);	fflush(stdout);

	//pravin start
    tag_t TskToDMLRel = NULLTAG;
    tag_t DMLRevTagg = NULLTAG;
    tag_t DMLTypeTag = NULLTAG;
    tag_t *DMLTagg = NULLTAG;
    tag_t *PartTagsB = NULLTAG;
	int		CountDML	= 0;
	int		Counter	= 0;
	char *DMLTyp1=NULL;
	char *type_dml_name = NULL;
	char *Release_Type1 = NULL;
	char *DML_name1 = NULL;

	logical isltstdmll;
					ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
                    if (TskToDMLRel != NULLTAG)
                    {
                        ITKCALL(GRM_list_primary_objects_only(TaskTag, TskToDMLRel, &CountDML, &DMLTagg));
                        printf("\n\n\t\t dss CountDML : %d", CountDML);
                        fflush(stdout);
 
                        for (Counter = 0; Counter < CountDML; Counter++)
                        {
                            ITKCALL(ITEM_rev_sequence_is_latest(DMLTagg[Counter], &isltstdmll));
                            printf("\n\n\t\t isltstdmll : %d\n", isltstdmll);
                            fflush(stdout);
 
                            if (isltstdmll != true)
                            {
                                printf("\n\n\t\t isltstdmll is not true .....\n");
                                fflush(stdout);
                            }
                            else
                            {
                                printf("\n\n\t\t isltstdmll is  true .....\n");
                                fflush(stdout);
                                DMLRevTagg = DMLTagg[Counter];
 
                                ITKCALL(TCTYPE_ask_object_type(DMLRevTagg, &DMLTypeTag));
                                ITKCALL(TCTYPE_ask_name2(DMLTypeTag, &DMLTyp1));
                                printf("\n\n\t\t isltstdmll is  true test .....\n");
                                fflush(stdout);
 
                                if (tc_strcmp(DMLTyp1, "T5_APLDMLRevision") == 0)
                                {

 
                                    ITKCALL(AOM_ask_value_string(DMLRevTagg, "t5_rlstype", &Release_Type1));
                                    printf("\n\t PravinJ Release_Type1 is :%s", Release_Type1);
                                    fflush(stdout);
 
                                    ITKCALL(AOM_ask_value_string(DMLRevTagg, "item_id", &DML_name1));
                                    printf("\n PravinJ Test1 DML_name1 founc : %s", DML_name1);
                                    fflush(stdout);
								}
							}
						}
					}
 
	//pravin end

	ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="ChangRefrnces";
		qry_valuesCntrl1[1]="PrtRlsFrmPlnt";
		qry_valuesCntrl1[2]="0";
		
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	if (control_number_found1>0)
	{

	if((tc_strcmp(Release_Type1,"TODR") == 0) || (tc_strstr(inp_Tsk_no,"MM") !=NULL)) // ERC --GM // MBOM --MM

	{

	PlantWiseRelStatGMDML(inp_Tsk_no,LcsAPLRlzd,LcsSTDRlzd);
	printf("\n LcsAPLRlzd: %s \n",LcsAPLRlzd);

	ITKCALL(GRM_find_relation_type("CMReferences",&relation_type));
	if (relation_type != NULLTAG)
	{
		ITKCALL(GRM_list_secondary_objects_only(TaskTag,relation_type,&prtcnt,&prtList));
		printf("\nNumber of parts found in Reference Folder : %d",prtcnt);fflush(stdout);
		if (prtcnt > 0)
		{
			for (i=0;i<prtcnt;i++)
			{
				prtTAG=prtList[i];
				error =0;
				status_count =0;

				ITKCALL(AOM_ask_value_string(prtTAG,"object_type",&itemobjecttype));
				printf("\n itemobjecttype  is :%s",itemobjecttype);	fflush(stdout);

                if(tc_strcmp(itemobjecttype,"Design Revision") == 0)
                {
				ITKCALL(AOM_ask_value_string(prtTAG,"item_id",&PartNumbr));
				printf("\n PartNumbr  is :%s",PartNumbr);	fflush(stdout);

				ITKCALL(WSOM_ask_release_status_list(prtTAG,&status_count,&status_list));
				printf("\n status_count : %d",status_count);fflush(stdout);

				if ((status_count > 0) && (tc_strcmp(LcsAPLRlzd,"") !=0))
				{

				for (ii= 0;ii<status_count;ii++)
				{
                    ReleaseStatus=NULL;
					ITKCALL(AOM_ask_name(status_list[ii], &ReleaseStatus));
					printf("\n ReleaseStatus %s \n",  ReleaseStatus);fflush(stdout);
					if (tc_strcmp(ReleaseStatus,LcsAPLRlzd)==0)
					{
					  error++;
                      printf("\n part is released from plant.");fflush(stdout);
					  break;
					}
					
				}
				}
				printf("\n error : %d",error);fflush(stdout);
				if (error==0)
				{
						 
					 if (cnt==0)
					  {
						cnt =1;
						tc_strcpy(partset,"This parts is not released from plant: ");
						tc_strcat(partset,PartNumbr);
						
					  }
					  else
					   {
						  tc_strcat(partset,";");
						  tc_strcat(partset,PartNumbr);
						
						  cnt = cnt+1;   
						   
					   }
					   
					   printf("\n Value of cnt is:%d",cnt);fflush(stdout);
					   printf("\n partset is: %s",partset);fflush(stdout);

					   if(cnt==1)
						 { 
							 printf("\n INSIDE if cnt...");fflush(stdout);
							 tc_strcpy(SetChildRelErr,partset);
							 //cntFlag = 1;
							 *icount = *icount + 1;
						  }
					   else
						  {
							  printf("\n INSIDE else cnt...");fflush(stdout);
							  tc_strcpy(SetChildRelErr,partset);
							  //cntFlag = 1;
							  *icount = *icount + 1;
						  }
				}
			}

	    else
		{
		   printf("\n PravinJ object type is not Design Revision hence skiped...");fflush(stdout);
		}
            }


		}
	}
	}
	}


	return 0;
}

int	tm_Platform_From_SVR(tag_t t_SVR, tag_t	*t_Platform)
{
	int status;
	
	int		count_CC		=	0;
	int		count_CC1		=	0;
	int		irel			=	0;
	int		count_plt		=	0;
	int		iplt			=	0;
	
	char	*cSVRName		=	NULL;
	char	*objecttype		=	NULL;
	char	*objectname		=	NULL;
	char	*type_itemRev	=	NULL;
	
	tag_t	t_relation		=	NULLTAG;
	tag_t	t_pltrelation	=	NULLTAG;
	tag_t	itemTypeTag_cdss		=	NULLTAG;
	tag_t	*t_primary		=	NULLTAG;
	tag_t	*t_platform		=	NULLTAG;
	
	printf("\nInside tm_Platform_From_SVR");fflush(stdout);
	ITKCALL(GRM_find_relation_type("IMAN_reference", &t_relation));
	ITKCALL(GRM_find_relation_type("Smc0HasVariantConfigContext", &t_pltrelation));
	
	if(AOM_ask_value_string(t_SVR,"object_name",&cSVRName));
	printf("\nSVR name : %s ",cSVRName);fflush(stdout);
	
	if(t_relation!=NULLTAG)
	{
		ITKCALL(GRM_list_primary_objects_only(t_SVR,t_relation,&count_CC,&t_primary));
		printf("\nNumber of Primary Object FOund : %d",count_CC);fflush(stdout);
		if(count_CC>0)
		{
			printf("\nInside Primary Count");fflush(stdout);
			for(irel=0;irel<count_CC;irel++)
			{	
				if(AOM_ask_value_string(t_primary[irel],"object_type",&objecttype));
				if(AOM_ask_value_string(t_primary[irel],"object_name",&objectname));
				
				if(tc_strcmp(objecttype,"Cfg0ProductItem")==0)
				{
					//ITKCALL(GRM_list_all_related_objects_only(t_primary[irel],&count_plt,&t_primary1)); //Smc0HasVariantConfigContext
					//ITKCALL(GRM_list_primary_objects_only(t_primary[irel],NULLTAG,&count_plt,&t_primary1));
					if(t_pltrelation!=NULLTAG)
					{
						ITKCALL(GRM_list_primary_objects_only(t_primary[irel],t_pltrelation,&count_plt,&t_platform));
						printf("\nNumber of Platform Object Found : %d",count_plt);fflush(stdout);
						if(count_plt>0)
						{
							for(iplt=0;iplt<count_plt;iplt++)
							{
								if(AOM_ask_value_string(t_platform[iplt],"object_type",&objecttype));
								if(AOM_ask_value_string(t_platform[iplt],"object_name",&objectname));
								
								printf("\nplt type : %s, name : %s",objecttype,objectname);fflush(stdout);
								if(tc_strcmp(objecttype,"T5_Platform")==0)
								{
									*t_Platform	=	t_platform[iplt];
									return	status;
								}
							}
						}
					}
					else{
						}
				}
			}
		}
	}
				
	return	status;
}
 
void setAddStrMBOM(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStrMBOM %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStrMBOM===%s",(*strset)[*count-1]);fflush(stdout);

}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

void tm_getAPLReleasedCtxt(char *cPlantname, char **cAPLRevisionRule, char	**cAPLClosureRule)
{
	int     n_entryCntrl2    		= 	3;
	int		control_number_found2	=	0;
	
	char	*cRevisionRule			=	NULL;
	char	*cClosureRule			=	NULL;
	
	char    *qry_entryCntrl1[3]  	= {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1		= (char **) MEM_alloc(5 * sizeof(char *));
	
	tag_t	qryTagCntrl				=	NULLTAG;
	tag_t	*list_of_WSO_cntrl_tags2	=	NULLTAG;
	printf("\nInside tm_getAPLReleasedCtxt : %s",cPlantname);fflush(stdout);
	
	if( QRY_find2("Control Objects...", &qryTagCntrl));
	if(qryTagCntrl!=NULLTAG)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="APLStateInf";
		qry_valuesCntrl1[1]=cPlantname;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl, n_entryCntrl2, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found2, &list_of_WSO_cntrl_tags2));
		printf("\nNumber of control object found : %d",control_number_found2);
		if(control_number_found2>0)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags2[0], "t5_Userinfo8", &cRevisionRule);
			printf("\n cRevisionRule: %s\n",cRevisionRule);fflush(stdout);
			*cAPLRevisionRule	=	NULL;
			*cAPLRevisionRule	=	(char	*)MEM_alloc(tc_strlen(cRevisionRule)+15);
			tc_strcpy(*cAPLRevisionRule,cRevisionRule);
		}
		else
		{
			printf("\nRevision rule query result null");fflush(stdout);
			*cAPLRevisionRule	=	NULL;
			*cAPLRevisionRule	=	(char	*)MEM_alloc(tc_strlen("APLC Release and above")+15);
			tc_strcpy(*cAPLRevisionRule,"APLC Release and above");
		}
		
		qry_valuesCntrl1[0]="APLPltInf";
		qry_valuesCntrl1[1]=cPlantname;
		qry_valuesCntrl1[2]="0";
		
		if(QRY_execute(qryTagCntrl, n_entryCntrl2, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found2, &list_of_WSO_cntrl_tags2));
		printf("\nNumber of control object found : %d",control_number_found2);
		if(control_number_found2>0)
		{
			AOM_ask_value_string( list_of_WSO_cntrl_tags2[0], "t5_Userinfo6", &cClosureRule);
			printf("\n cClosureRule: %s\n",cClosureRule);fflush(stdout);
			*cAPLClosureRule	=	NULL;
			*cAPLClosureRule	=	(char	*)MEM_alloc(tc_strlen(cRevisionRule)+15);
			tc_strcpy(*cAPLClosureRule,cClosureRule);
		}
		else
		{
			printf("\nClosure rule query result null");fflush(stdout);
			*cAPLRevisionRule	=	NULL;
			*cAPLRevisionRule	=	(char	*)MEM_alloc(tc_strlen("BOMViewClosureRuleAPLC")+15);
			tc_strcpy(*cAPLRevisionRule,"BOMViewClosureRuleAPLC");
		}
	}
	
}

void  GetPlantWiseRelStatAtAPL( char * item_id ,char  getLCSAPLWrkg[40],char  getLCSAPLRlzd[40])
{

	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char  ItemIDCpy[40];   

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 
	 char *APLWrkng			= NULL;
	 char *APLRlzd			= NULL;	

	 printf( "item_id:%s\n", item_id);
	tc_strcpy(ItemIDCpy,item_id);
	printf("\n ItemIDCpy is : %s\n",ItemIDCpy);fflush(stdout);
	Dsgn_No=tc_strtok(ItemIDCpy,"_");	
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,ItemIDCpy);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,ItemIDCpy);
	 

	 if( QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLStateInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{			

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &APLWrkng);
				printf("\n APLWrkng: %s\n",APLWrkng);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &APLRlzd);
				printf("\n APLRlzd: %s\n",APLRlzd);fflush(stdout);

				tc_strcpy(getLCSAPLWrkg,APLWrkng);
				tc_strcpy(getLCSAPLRlzd,APLRlzd);
			}
			else
			{
				tc_strcpy(getLCSAPLWrkg,"T5_LcsAPLpWrkg");
				tc_strcpy(getLCSAPLRlzd,"T5_LcsAplpRlzd");
			}

	printf( "getLCSAPLWrkg:%s\n", getLCSAPLWrkg);
	printf( "getLCSAPLRlzd:%s\n", getLCSAPLRlzd);

}

void  GetPlantForDMLORTask( char * item_id ,char  getPlant[40])
{
    printf( "item_id:%s\n", item_id);

	char *item_idCpy =NULL;
	char *revStr =NULL;
	char *tmpStr =NULL;
	char *revStr1 =NULL;
	item_idCpy	=	(char *)MEM_alloc(50);

	tc_strcpy(item_idCpy,item_id);
	reverse(item_idCpy);
	revStr	=	(char *)MEM_alloc(50);
	tc_strcpy(revStr,item_idCpy);
	printf("\n revStr Find %s.......",revStr);fflush(stdout);
	tmpStr	=	strtok(revStr,"_");
	printf("\n tmpStr Find %s.......",tmpStr);fflush(stdout);
	revStr1	=	(char *)MEM_alloc(50);
	reverse(tmpStr);
	tc_strcpy(revStr1,tmpStr);
	printf("\n revStr1 Find %s.......",revStr1);fflush(stdout);
	tc_strcpy(getPlant,revStr1);

	printf( "getPlant:%s\n", getPlant);
}

int GMDML_Part_Release_Check_APL(tag_t item_rev_tag, char *itemid, char *SetChildRelErr, int *icount)
{
    int task_len = 0;
    int k, j = 0;
    int st_ok_Flg = 0;
    int cnt_next = 0;
    int count_task = 0;
    int cnt_tk = 0;
    int count_dml_1 = 0;
    int st_count_dml = 0;
    int NextRevFlagDml = 0;
    int flagerror = 0;
    int st_count = 0;
    int dmlstlst = 0;
    int control_number_found = 0;
    int cntCntrl = 0;
    int iCntl = 0;
    int status = 0;

    // char			*inp_Plant			= NULL;
    // char			*tsk_Plant			= NULL;
    char *Part_no = NULL;
    char *Desc_obj_lt_Rev = NULL;
    char *Desc_obj_Inp_Part = NULL;
    char *part_DRStatus = NULL;
    char *WSO_Name_next_Rev = NULL;
    char *ReleaseStatusDML = NULL;
    char *TaskId = NULL;
    char *Revision = NULL;
    char *attchdPart = NULL;
    char *SubSyscd = NULL;

    char type_class[TCTYPE_name_size_c + 1];
    char type_dml[TCTYPE_name_size_c + 1];

    char *Dsgn_No = NULL;
    char *PLT_Code = NULL;

    tag_t AssyTag = NULLTAG;
    tag_t master = NULLTAG;
    tag_t latestrev = NULLTAG;
    tag_t relation_type_task = NULLTAG;
    tag_t PartTskTag = NULLTAG;
    tag_t itemTypeTag_class = NULLTAG;
    tag_t tsk_dml_rel_type_1 = NULLTAG;
    tag_t DMLRevTag_Prt = NULLTAG;
    tag_t itemTypeTag_Dml = NULLTAG;

    tag_t *status_list = NULLTAG;
    tag_t *dml_status_list = NULLTAG;
    tag_t *PartTaskTags = NULLTAG;
    tag_t *DMLRevision_Prt = NULLTAG;
    tag_t *list_of_WSO_cntrl_tags = NULLTAG;

    int countstmnt = 0;

    char LcsAplWrkg[40];
    char LcsAplRlzd[40];
    char inp_Plant[40];
    char tsk_Plant[40];

    WSO_search_criteria_t criteria_Gcontrol;

    logical is_latest_dml;
    tag_t TskToDMLRel = NULLTAG;
    tag_t DMLRevTagg = NULLTAG;
    tag_t DMLTypeTag = NULLTAG;
    tag_t *DMLTagg = NULLTAG;
    tag_t *RefPartTags = NULLTAG;
    int RefPartCnt = 0;

    int CountDML = 0;
    int Counter = 0;

    logical isltstdmll;

    char DMLTyp[TCTYPE_name_size_c + 1];
    char *ProjectCode = NULL;
    char *Release_Type = NULL;
	attchdPart = (char *)MEM_alloc(1000);
    


    printf("\n ############Inside GMDML_Part_Release_Check_APL : Next revision DML with STDSI Check###########");
    fflush(stdout);

    task_len = 0;
    task_len = strlen(itemid);
    printf("\t  task_len ...%d\n", task_len); // length task
    GetPlantForDMLORTask(itemid, inp_Plant);
    // inp_Plant=subString(itemid,14,task_len);
    printf("\t  inp_Plant after  ...%s\n", inp_Plant);

    // Control Object Base

    int cntt = 0;
    int FlagGot = 0;

    tag_t CntrlTag = NULLTAG;

    tag_t query1 = NULLTAG;
    int n_entries1 = 2;
    int n_found1 = 0;
    tag_t *CntrlObjs = NULLTAG;

    logical delInd = false;

    char *Info1 = NULL;

    char
        *qry_entry[2] = {"SUBSYSCD", "SYSCD"},
        *qry_vall[2] = {"TODR", "LIVE"};

    // del indicator

    ITKCALL(QRY_find2("ControlObjQry", &query1));
    printf("\n After fins qryyy-- ");
    fflush(stdout);
    ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));
    printf("\n n_found1: %d", n_found1);
    fflush(stdout);

    if (n_found1 > 0)
    {
        for (cntt = 0; cntt < n_found1; cntt++)
        {
            CntrlTag = NULLTAG;
            CntrlTag = CntrlObjs[cntt];

            AOM_ask_value_string(CntrlTag, "t5_Userinfo1", &Info1);
            printf("\n Info1: %s\n", Info1);
            fflush(stdout);

            AOM_ask_value_logical(CntrlTag, "t5_DelInd", &delInd);
            printf("\n delInd: %d\n", delInd);
            fflush(stdout);

            if (tc_strstr(Info1, inp_Plant) != NULL && delInd == false)
            {
                printf("\n GOT PLANT...");
                fflush(stdout);
                FlagGot = 1;
                break;
            }
        }
    }
    printf("\n FlagGot: %d", FlagGot);
    fflush(stdout);
    ///

    if (FlagGot == 1)
    {
        char ItemIDCpy[40];
        tc_strcpy(ItemIDCpy, itemid);
        GetPlantWiseRelStatAtAPL(ItemIDCpy, LcsAplWrkg, LcsAplRlzd);
        printf("\n LcsAplWrkg: %s \n", LcsAplWrkg);
        printf("\n LcsAplRlzd: %s \n", LcsAplRlzd);

        // ###########################################################//

        RefPartCnt = 0;
        RefPartTags = NULLTAG;
        ITKCALL(AOM_ask_value_tags(item_rev_tag, "CMReferences", &RefPartCnt, &RefPartTags));
        printf("\n\n\t\t Number of partnumbers in GM DML Task :%d", RefPartCnt);
        fflush(stdout);
        k = 0;
        for (k = 0; k < RefPartCnt; k++)
        {
            printf("\n\n\t\t for k =:%d", k);
            fflush(stdout);

            AssyTag = NULLTAG;
            AssyTag = RefPartTags[k];

            Part_no = NULL;
            ITKCALL(AOM_ask_value_string(AssyTag, "item_id", &Part_no));
            printf("\n\n\t\t Part_no  is :%s", Part_no);
            fflush(stdout);

            Revision = NULL;
            ITKCALL(AOM_ask_value_string(AssyTag, "item_revision_id", &Revision));
            printf("\n\n\t\t Revision  is :%s", Revision);
            fflush(stdout);

            ITKCALL(WSOM_ask_release_status_list(AssyTag, &st_count, &status_list));
            printf("\n st_count :%d is\n", st_count);
            fflush(stdout);

            if (st_count > 0)
            {
                st_ok_Flg = 0;
                for (cnt_next = 0; cnt_next < st_count; cnt_next++)
                {
                    WSO_Name_next_Rev = NULL;
                    ITKCALL(AOM_ask_name(status_list[cnt_next], &WSO_Name_next_Rev));
                    printf("\n WSO_Name_next_Rev is :%s\n", WSO_Name_next_Rev);
                    fflush(stdout);

                    if ((tc_strcmp(WSO_Name_next_Rev, LcsAplRlzd) == 0))
                    {
                        st_ok_Flg = 1;
                    }
                }

                if (st_ok_Flg == 0)
                {
              
                    tc_strcpy(attchdPart,Part_no);

                    printf("attchdPart: %s", attchdPart);
                    fflush(stdout);

                    if (countstmnt == 0)
                    {
                        
						tc_strcpy(SetChildRelErr,"Mention PartNumbers are not Release from APL.Please release since they are attached to Gate Maturation DML: ");
                        countstmnt++;
                        //cntFlag = 1;
						*icount = *icount + 1;
						
                    }
                    
					tc_strcat(SetChildRelErr,attchdPart);
                    
                }

            } // if(st_count>0)
        }
    } // if(FlagGot==1)

    return 0;
}

int CheckPrtRelsFrmPlant_MBOM (tag_t TaskTag,char *SetChildRelErr,int *icount) 
{
	char* inp_Tsk_no=NULL;
	tag_t relation_type	=NULLTAG;
	tag_t	*prtList				=	NULLTAG;
	int prtcnt =0;
	int i,ii=0;
	tag_t prtTAG =NULLTAG;
	char* PartNumbr =NULL;
	char* itemobjecttype =NULL;
	int status_count			=0;
	tag_t*	status_list		=NULLTAG;
	char*  ReleaseStatus	=NULL;
	//char LcsAPLRlzd[40];
	//char LcsSTDRlzd[40];

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
    int cntrlcnt=0;
	int  control_number_found1=0;
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
    tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 3;
	int     error =0;
	int     errorFlg=0;
	char *partset =NULL;
	partset=(char *)MEM_alloc(2000);
	int   cnt =0;
	


	printf("\n########### Inside CheckPrtRelsFrmPlant_MBOM PravinJ ###################\n");fflush(stdout);

	ITKCALL(AOM_ask_value_string(TaskTag,"item_id",&inp_Tsk_no));
	printf("\n inp_Tsk_no plj is :%s",inp_Tsk_no);	fflush(stdout);

	//pravin start
    tag_t TskToDMLRel = NULLTAG;
    tag_t DMLRevTagg = NULLTAG;
    tag_t DMLTypeTag = NULLTAG;
    tag_t *DMLTagg = NULLTAG;
    tag_t *PartTagsB = NULLTAG;
	int		CountDML	= 0;
	int		Counter	= 0;
	char *DMLTyp1=NULL;
	char *type_dml_name = NULL;
	char *Release_Type1 = NULL;
	char *DML_name1 = NULL;
	char *MbomRlsType = NULL;

	logical isltstdmll;
					ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
                    if (TskToDMLRel != NULLTAG)
                    {
                        ITKCALL(GRM_list_primary_objects_only(TaskTag, TskToDMLRel, &CountDML, &DMLTagg));
                        printf("\n\n\t\t dss CountDML : %d", CountDML);
                        fflush(stdout);
 
                        for (Counter = 0; Counter < CountDML; Counter++)
                        {
                            ITKCALL(ITEM_rev_sequence_is_latest(DMLTagg[Counter], &isltstdmll));
                            printf("\n\n\t\t isltstdmll : %d\n", isltstdmll);
                            fflush(stdout);
 
                            if (isltstdmll != true)
                            {
                                printf("\n\n\t\t isltstdmll is not true .....\n");
                                fflush(stdout);
                            }
                            else
                            {
                                printf("\n\n\t\t isltstdmll is  true .....\n");
                                fflush(stdout);
                                DMLRevTagg = DMLTagg[Counter];
 
                                ITKCALL(TCTYPE_ask_object_type(DMLRevTagg, &DMLTypeTag));
                                ITKCALL(TCTYPE_ask_name2(DMLTypeTag, &DMLTyp1));
                                printf("\n\n\t\t isltstdmll is  true test .....\n");
                                fflush(stdout);
 
                                if (tc_strcmp(DMLTyp1, "T5_MBOMDMLRevision") == 0)
                                {
                                    ITKCALL(AOM_ask_value_string(DMLRevTagg, "item_id", &DML_name1));
                                    printf("\n PravinJ Test1 DML_name1 founc : %s", DML_name1);
                                    fflush(stdout);
                                     
                                    ITKCALL(AOM_ask_value_string(DMLRevTagg, "t5_rlstype", &Release_Type1));
                                    printf("\n\t PravinJ ERC Release_Type1 is :%s", Release_Type1);
                                    fflush(stdout);

									ITKCALL(AOM_ask_value_string(DMLRevTagg,"t5_MBOMRlzType",&MbomRlsType));
									printf("\n PravinJ MBOM RlsType : %s\n",MbomRlsType);fflush(stdout);
								}
							}
						}
					}
 
	//pravin end

	ITKCALL(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl1[0]="ChangRefrnces";
		qry_valuesCntrl1[1]="MbomPrtRlsFrmPlnt";
		qry_valuesCntrl1[2]="0";
		
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
	}
	if (control_number_found1>0)
	{

	if((tc_strcmp(Release_Type1,"TODR") == 0) || (tc_strcmp(MbomRlsType,"GM_MMDML") == 0)) // ERC --GM // MBOM -- GM_MMDML

	{

	//PlantWiseRelStatGMDML(inp_Tsk_no,LcsAPLRlzd,LcsSTDRlzd);
	//printf("\n LcsAPLRlzd: %s \n",LcsAPLRlzd);

	ITKCALL(GRM_find_relation_type("CMReferences",&relation_type));
	if (relation_type != NULLTAG)
	{
		ITKCALL(GRM_list_secondary_objects_only(TaskTag,relation_type,&prtcnt,&prtList));
		printf("\nNumber of parts found in Reference Folder : %d",prtcnt);fflush(stdout);
		if (prtcnt > 0)
		{
			for (i=0;i<prtcnt;i++)
			{
				prtTAG=prtList[i];
				error =0;
				status_count =0;

                ITKCALL(AOM_ask_value_string(prtTAG,"object_type",&itemobjecttype));
				printf("\n itemobjecttype  is :%s",itemobjecttype);	fflush(stdout);
                if(tc_strcmp(itemobjecttype,"Design Revision") == 0)

				{

				ITKCALL(AOM_ask_value_string(prtTAG,"item_id",&PartNumbr));
				printf("\n PartNumbr  is :%s",PartNumbr);	fflush(stdout);

				ITKCALL(WSOM_ask_release_status_list(prtTAG,&status_count,&status_list));
				printf("\n status_count : %d",status_count);fflush(stdout);

				if ((status_count > 0))
				{

				for (ii= 0;ii<status_count;ii++)
				{
                    ReleaseStatus=NULL;
					ITKCALL(AOM_ask_name(status_list[ii], &ReleaseStatus));
					printf("\n ReleaseStatus %s \n",  ReleaseStatus);fflush(stdout);
					if (tc_strcmp(ReleaseStatus,"T5_MBOMReleased")==0)
					{
					  error++;
                      printf("\n part is released from MBOM.");fflush(stdout);
					  break;
					}
					
				}
				}
				printf("\n error : %d",error);fflush(stdout);
				if (error==0)
				{
						 
					 if (cnt==0)
					  {
						cnt =1;
					
						tc_strcpy(partset,"This parts is not released from MBOM: ");
						tc_strcat(partset,PartNumbr);
						
					  }
					  else
					   {
						  tc_strcat(partset,";");
						  tc_strcat(partset,PartNumbr);
						
						  cnt = cnt+1;   
						   
					   }
					   
					   printf("\n Value of cnt is:%d",cnt);fflush(stdout);
					   printf("\n partset is: %s",partset);fflush(stdout);

					   if(cnt==1)
						 { 
							 printf("\n INSIDE if cnt...");fflush(stdout);
							 tc_strcpy(SetChildRelErr,partset);
							 //cntFlag = 1;
							 *icount = *icount + 1;
						  }
					   else
						  {
							  printf("\n INSIDE else cnt...");fflush(stdout);
							  tc_strcpy(SetChildRelErr,partset);
							  //cntFlag = 1;
							  *icount = *icount + 1;
						  }
				}

			}
            else
		{
		   printf("\n PravinJ object type is not Design Revision hence skiped...");fflush(stdout);
		}

            }


		}
	}
	}
	else
		{
		   printf("\n PravinJ ERC/MBOM DML Release type is not Gate Maturation  hence skiped...");fflush(stdout);
		}
	}


	return 0;
}


int ITK_user_main(int argc,char *argv[])
{
	int iFail     = 0;
	int status     = 0;
	
	char *u				= ITK_ask_cli_argument("-u=");
	char *pf				= ITK_ask_cli_argument("-pf=");
	char *g				= ITK_ask_cli_argument("-g=");

	tag_t qryTag = NULLTAG;
	char *qry_entry[2] = {"Status", "Name"};
    char *qry_values[2] = {"0", "APLPUNE"};
    tag_t *User_tags = NULLTAG;
    int n_entry = 2;
    int User_found = 0;

	tag_t qryTag1 = NULLTAG;
	char *qry_entry1[2] = {"Name", "Type"};
    tag_t *Task_tags1 = NULLTAG;
    int n_entry1 = 2;
    int Task_found1 = 0;
	char *Task_name =NULL;
	int i=0;
	int j=0;
	int k=0;
	int FlderSize =0;
	int     FlderObjCount =  0;
	tag_t  *FolderObj_tag	= NULLTAG;
	char *Task_name2 =NULL;
	char *obj_name=NULL;
	char *Item_ID =NULL;
	tag_t ItemTag = NULLTAG;
	tag_t ItemRevisionTag = NULLTAG;
	int		n_attchs_ref		=	0;
	GRM_relation_t	*rellist_refs;

	int		n_attchs_ref2		=	0;
	GRM_relation_t	*rellist_refs2;
	int noAttachment =0;
	tag_t *attachments = NULLTAG;
	int l=0;
	int m=0;
	tag_t objTypTag = NULLTAG;
	char *ObjTyp = NULL;
	tag_t roottask = NULLTAG;
	tag_t TskToDMLRel = NULLTAG;
	int CountDML=0;
	tag_t *DMLTagg = NULLTAG;
	tag_t DMLRevTag =NULLTAG;
	tag_t DMLTypeTag = NULLTAG;
	char *DMLTyp = NULL;
	char *Release_Type = NULL;
	char *itemid =NULL;
	char *SetGMErr1 = NULL;
	char *SetGMErr2 = NULL;
	char *env_subject = NULL;
	char *env_body = NULL;
	tag_t		envelope	= NULLTAG;
	int countenvelop=0;
	const char *comments = "Approved by ITK";
	EPM_signoff_decision_t 	decision = EPM_approve_decision;
	tag_t Analyst_user_tag  = NULLTAG;
	tag_t Analyst_person_tag  = NULLTAG;
	tag_t CtrlObjQryTag = NULLTAG;
	char*	eMailTo		= NULL;
	eMailTo=(char *)MEM_alloc(5000);
	char * command    = NULL;
	command = (char *)MEM_alloc(7000);
    
	FILE *fp1;
	int Sr_No=0;
	char	outputFile[2000]			= "";
	char	Data[100]					= "";

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"GMDML_Signoff_Report_MBOM_%s.csv",Data);

	fp1 = fopen(outputFile, "a+");

	fprintf(fp1,"Sr_No,Task No,Task Name,Signoff User,Signoff Status,Error\n");fflush(fp1);

	ITK_CALL(ITK_auto_login( ));  
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_set_journalling( TRUE ));
    
	printf("\n Login to DB succesfully [userID:%s pass:%s Group:%s ] \n",u,pf,g);fflush(stdout);

	//********** MBOM Task signoff ************//

	tc_strcpy(eMailTo," ");
    ITK_CALL(QRY_find2("General...", &qryTag1));
    ITK_CALL(QRY_find2("Control Objects...", &CtrlObjQryTag));
	if (CtrlObjQryTag != NULLTAG)
	{

	int n_count =	3;
	char *SYNCqry_entry[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char **SYNCqry_values = (char **) MEM_alloc(50 * sizeof(char *));
	SYNCqry_values[0] = "GMDML";
	SYNCqry_values[1] = "AutoSignoff";
	SYNCqry_values[2] = "0";
	int SYNCount=0;
	tag_t  *SYNCcntrlobj = NULLTAG;

	ITKCALL(QRY_execute(CtrlObjQryTag, n_count, SYNCqry_entry, SYNCqry_values, &SYNCount, &SYNCcntrlobj));
	if(SYNCount>0)
	{
		char *SYNCinfo1 =NULL;
		char *SYNCinfo2 =NULL;
		char *SYNCinfo5 =NULL;
		ITKCALL(AOM_ask_value_string( SYNCcntrlobj[0], "t5_Userinfo1", &SYNCinfo1));
		ITKCALL(AOM_ask_value_string( SYNCcntrlobj[0], "t5_Userinfo2", &SYNCinfo2));
		ITKCALL(AOM_ask_value_string( SYNCcntrlobj[0], "t5_Userinfo5", &SYNCinfo5));
		int Req_no_run = atoi(SYNCinfo1);
    	printf("\n Req_no_run : %d",Req_no_run);fflush(stdout);
		
    //********** MBOM Task signoff ************//

    qryTag = NULLTAG;
	char *QRY_valu[2] = {"0", "MBOM"};
	User_found = 0;
	tag_t *MBOMuser_tags = NULLTAG;
	int n=0;
	Task_found1=0;
	tag_t *MBOMtask_tags = NULLTAG;
	int o=0;
	char *Mjob_name =NULL;
	char *Mobj_name =NULL;
	int p1 =0;
	int q=0;
	int r =0;

    ITK_CALL(QRY_find2("MBOMuser", &qryTag));
	if (qryTag != NULLTAG)
    {
        printf("\n MBOMuser Query Found \n");fflush(stdout);

        ITK_CALL(QRY_execute(qryTag, n_entry, qry_entry, QRY_valu, &User_found, &MBOMuser_tags));

        printf("\n MBOM User_found is : %d\n", User_found);fflush(stdout);

		if (User_found>0)
		{

			for(n=0;n<User_found;n++)
			{
				char *MBOMusr_name =NULL;
	            char *MBOMusr_ID =NULL;
				Analyst_user_tag  = NULLTAG;
				Analyst_person_tag  = NULLTAG;
				char *MBOM_Analyst_email_addr  = NULL; 

				AOM_ask_value_string(MBOMuser_tags[n], "object_string", &MBOMusr_name);
				AOM_ask_value_string(MBOMuser_tags[n], "user_id", &MBOMusr_ID);
				ITK_CALL(SA_find_user2 (MBOMusr_ID, &Analyst_user_tag));
				ITK_CALL(AOM_ask_value_tag(Analyst_user_tag,"person",&Analyst_person_tag));
                ITK_CALL(SA_ask_person_email_address(Analyst_person_tag,&MBOM_Analyst_email_addr));

				printf("\n MBOMusr_name: %s\n", MBOMusr_name);fflush(stdout);
				printf("\n MBOMusr_ID: %s\n", MBOMusr_ID);fflush(stdout);
				printf("\n MBOM Person EMAIL Address =[%s]",MBOM_Analyst_email_addr);fflush(stdout);
				if(tc_strcmp(MBOM_Analyst_email_addr,"")!=0)
				{
					tc_strcat(eMailTo,MBOM_Analyst_email_addr);
					tc_strcat(eMailTo,",");
				}
				

				if (qryTag1 != NULLTAG)
				{
					printf("\n General... Query Found \n");fflush(stdout);

					char *MBOMqry_values[2] = {MBOMusr_name, "Tasks To Perform"};
					ITK_CALL(QRY_execute(qryTag1, n_entry1, qry_entry1, MBOMqry_values, &Task_found1, &MBOMtask_tags));

					printf("\n MBOM Task_found1: %d\n", Task_found1);fflush(stdout);

					if (Task_found1>0)
					{
						for(o=0; o<Task_found1; o++)
						{
						  FlderSize =0;
	                      FlderObjCount =  0;
	                      tag_t  *MFolderObj_tag	= NULLTAG;
	
						  ITK_CALL(FL_ask_size(MBOMtask_tags[o],&FlderSize));
						  printf("\n MBOM FlderSize is:   %d \n",FlderSize);fflush(stdout);

						  ITK_CALL(FL_ask_references(MBOMtask_tags[o],FL_fsc_by_date_modified,&FlderObjCount,&MFolderObj_tag));
						  printf("\n MBOM FlderObjCount is:   %d \n",FlderObjCount);fflush(stdout);

						  if (FlderObjCount>0)
						  {
							  for(p1=0; p1<FlderObjCount; p1++)
							  {
							  
							  tag_t *Msignoff_tags = NULL;
							  int Msignoff_count=0;
							  tag_t Msignoff_tag =NULLTAG;
							  roottask = NULLTAG;
							  noAttachment =0;
							  objTypTag = NULLTAG;
							  char *MObjTyp = NULL;
							  TskToDMLRel = NULLTAG;
							  CountDML =0;
							  tag_t *MDMLTagg = NULLTAG;
							  tag_t *Mattachments = NULLTAG;
							  char *MBOM_TaskNo =NULL;

							  ITK_CALL(AOM_ask_value_string(MFolderObj_tag[p1], "object_name", &Mobj_name));							  
							  printf("\n Mobj_name: %s\n", Mobj_name);fflush(stdout);

							  // start
							  	ITK_CALL(EPM_ask_root_task(MFolderObj_tag[p1], &roottask));
								if(roottask != NULLTAG)
								{
								ITK_CALL(EPM_ask_attachments(roottask,EPM_target_attachment, &noAttachment, &Mattachments));
								printf("\n noAttachment: [%d]", noAttachment);
								if(noAttachment>0)
								{
								for(q = 0; q < noAttachment; q++)
								{
								   ITK_CALL(TCTYPE_ask_object_type(Mattachments[q], &objTypTag));
								   ITK_CALL(TCTYPE_ask_name2(objTypTag, &MObjTyp));
								   printf("\n obj type: [%s]\n", MObjTyp);fflush(stdout);
								   if(tc_strcmp(MObjTyp,"T5_MBOMTASKRevision")==0)
								   {
									ITKCALL(AOM_ask_value_string(Mattachments[q], "item_id", &MBOM_TaskNo));
								    printf("\n MBOM_TaskNo %s.....\n", MBOM_TaskNo);fflush(stdout);

									ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&TskToDMLRel));
									ITKCALL(GRM_list_primary_objects_only(Mattachments[q],TskToDMLRel,&CountDML,&MDMLTagg));
									if(CountDML>0)
									{
									  for(r = 0; r < CountDML; r++)
									  {
										tag_t MBOM_DMLRevTag = NULLTAG;
										DMLTypeTag=NULLTAG;
										char *MDMLTyp = NULL;
										char *MRelease_Type=NULL;

										MBOM_DMLRevTag = MDMLTagg[r];
										ITKCALL(TCTYPE_ask_object_type(MBOM_DMLRevTag, &DMLTypeTag));
										ITKCALL(TCTYPE_ask_name2(DMLTypeTag, &MDMLTyp));
										if(tc_strcmp(MDMLTyp, "T5_MBOMDMLRevision") == 0)
										{
										  ITKCALL(AOM_ask_value_string(MBOM_DMLRevTag, "t5_rlstype", &MRelease_Type));
										  printf("\n MRelease_Type is :%s", MRelease_Type);fflush(stdout);
										  if((tc_strcmp(MRelease_Type, "TODR") == 0) && ((tc_strcmp(Mobj_name,"Claim ERC Flown Task")==0) || (tc_strcmp(Mobj_name,"Acknowledge ERC Flown Task")==0) || (tc_strcmp(Mobj_name,"Manager Review")==0)))
										  {
											  int MNoofrun_gmautoreleased =0;

											  ITKCALL(AOM_ask_value_int(Mattachments[q], "t5_Noofrun_gmautoreleased", &MNoofrun_gmautoreleased));
											  printf("\n MNoofrun_gmautoreleased is :%d", MNoofrun_gmautoreleased);fflush(stdout);
											  if(MNoofrun_gmautoreleased<Req_no_run)
											  {

											  Sr_No++;
											  MNoofrun_gmautoreleased++;
											  fprintf(fp1,"%d,",Sr_No);fflush(fp1);
											  fprintf(fp1,"%s,",MBOM_TaskNo);fflush(fp1);
											  fprintf(fp1,"%s,",Mobj_name);fflush(fp1);
											  fprintf(fp1,"%s,",MBOMusr_ID);fflush(fp1);
											  ITKCALL(AOM_lock(Mattachments[q]));
										      ITKCALL(AOM_set_value_int(Mattachments[q],"t5_Noofrun_gmautoreleased",MNoofrun_gmautoreleased));
										      ITKCALL(AOM_save_without_extensions(Mattachments[q]));
										      ITKCALL(AOM_unlock(Mattachments[q]));

											  if((tc_strcmp(Mobj_name,"Claim ERC Flown Task")==0) || (tc_strcmp(Mobj_name,"Acknowledge ERC Flown Task")==0))
											  {

												cntFlag = 0;
												icount1 = 0;
												SetGMErr1 = NULL;
												SetGMErr1=(char *)MEM_alloc(5000);

												CheckPrtRelsFrmPlant_MBOM (Mattachments[q],SetGMErr1,&icount1); 
												printf("\n MBOM cntFlag: %d", cntFlag);fflush(stdout);
												printf("\n MBOM SetGMErr1: %s\n",SetGMErr1);fflush(stdout);

												if(icount1 > 0)
												{
													fprintf(fp1,"%s,","Pending");fflush(fp1);
												    fprintf(fp1,"%s,",SetGMErr1);fflush(fp1);

												}
												else
												{
												   printf("\n MBOM,promoting Claim MBOM Task task.");
												   ITK_CALL(EPM_promote_task(MFolderObj_tag[p1],"Promoted by system to move the WF"));
												   fprintf(fp1,"%s,","Completed");fflush(fp1);
												}

											 } // if of "Claim ERC Flown Task"

											if(tc_strcmp(Mobj_name,"Manager Review")==0)
											{

											printf("\n MBOM,promoting Review The Changes/Manager Review task.");
											ITK_CALL(EPM_promote_task(MFolderObj_tag[p1],"Promoted by system to move the WF"));
											fprintf(fp1,"%s,","Completed");fflush(fp1);

											} //else if of "Manager Review"

											fprintf(fp1,"\n");fflush(fp1);
										  }
										  } // if of TODR
										}
									  }
									}
								   }
								}
							  }
							}
						 } //for loop of folder count

						  } // if of folder count
						}			
					}
				}
			}
		}
    } // if of MBOMuser qry

	//QRY aplloader WL
	if(qryTag1 != NULLTAG)
	{

	char *LoaderQry_values[2] = {"APL Loader (aplloader)", "Tasks To Perform"};
	int LoaderTask_found = 0;
	tag_t *LoaderTask_tag = NULLTAG;
	int TaskCnt =0;
	int SignoffCnt =0;

	ITK_CALL(QRY_execute(qryTag1, n_entry1, qry_entry1, LoaderQry_values, &LoaderTask_found, &LoaderTask_tag));
	printf("\n LoaderTask_found: %d\n", LoaderTask_found);fflush(stdout);
	if(LoaderTask_found > 0)
	{
		for(TaskCnt=0; TaskCnt<LoaderTask_found; TaskCnt++)
		{
		  FlderObjCount =  0;
		  tag_t  *LFolderObj_tag	= NULLTAG;
          ITK_CALL(FL_ask_references(LoaderTask_tag[TaskCnt],FL_fsc_by_date_modified,&FlderObjCount,&LFolderObj_tag));
		  printf("\n aplloader FlderObjCount is:   %d \n",FlderObjCount);fflush(stdout);
		  if(FlderObjCount>0)
		  {
			  for(SignoffCnt=0; SignoffCnt<FlderObjCount ; SignoffCnt++)
			  {
				  char *loaderTskName =NULL;
				  char *loaderObjName =NULL;
                  roottask = NULLTAG;
				  noAttachment =0;
				  tag_t *Lattachments = NULLTAG;
				  int LtaskCnt =0;
				  objTypTag = NULLTAG;
				  char *LObjTyp = NULL;
				  char *Litem_ID =NULL;
				  TskToDMLRel = NULLTAG;
				  CountDML=0;
				  tag_t *LDMLTagg = NULLTAG;
				  int s = 0;
				  tag_t LDMLRevTag =NULLTAG;
				  DMLTypeTag=NULLTAG;
				  char *LDMLTyp = NULL;
				  

				  ITK_CALL(AOM_ask_value_string(LFolderObj_tag[SignoffCnt], "object_name", &loaderObjName));
				  printf("\n APL loaderObjName: %s\n", loaderObjName);fflush(stdout);

				  // start  

				   ITK_CALL(EPM_ask_root_task(LFolderObj_tag[SignoffCnt], &roottask));
				   if(roottask != NULLTAG)
				   {
				   ITK_CALL(EPM_ask_attachments(roottask,EPM_target_attachment, &noAttachment, &Lattachments));
				   printf("\n noAttachment: [%d]", noAttachment);
				   if(noAttachment>0)
				   {
					for(LtaskCnt = 0; LtaskCnt < noAttachment; LtaskCnt++)
					{
					   ITK_CALL(TCTYPE_ask_object_type(Lattachments[LtaskCnt], &objTypTag));
					   ITK_CALL(TCTYPE_ask_name2(objTypTag, &LObjTyp));
					   printf("\n LObjTyp: [%s]\n", LObjTyp);fflush(stdout);

					   if(tc_strcmp(LObjTyp,"T5_MBOMTASKRevision")==0)
					   {
						  ITKCALL(AOM_ask_value_string(Lattachments[LtaskCnt], "item_id", &Litem_ID));
					      printf("\n Litem_ID %s.....\n", Litem_ID);fflush(stdout);

						  ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation", &TskToDMLRel));
						  ITKCALL(GRM_list_primary_objects_only(Lattachments[LtaskCnt], TskToDMLRel, &CountDML, &LDMLTagg));
						  printf("\n CountDML : %d", CountDML);fflush(stdout);
						  if(CountDML>0)
						  {
							 for(s= 0; s < CountDML; s++)
							 {
								 LDMLRevTag = LDMLTagg[s];
								 char *LRelease_Type =NULL;
								 ITKCALL(TCTYPE_ask_object_type(LDMLRevTag, &DMLTypeTag));
								 ITKCALL(TCTYPE_ask_name2(DMLTypeTag, &LDMLTyp));
								  
								 if(tc_strcmp(LDMLTyp, "T5_MBOMDMLRevision") == 0)
								 {
									ITKCALL(AOM_ask_value_string(LDMLRevTag, "t5_rlstype", &LRelease_Type));
									printf("\n LRelease_Type is :%s", LRelease_Type);fflush(stdout);
									if(tc_strcmp(LRelease_Type, "TODR") == 0)
									{

										if(tc_strcmp(loaderObjName,"Acknowledge ERC Flown Task")==0)
										{

										Sr_No++;
										
										fprintf(fp1,"%d,",Sr_No);fflush(fp1);
										fprintf(fp1,"%s,",Litem_ID);fflush(fp1);
										fprintf(fp1,"%s,",loaderObjName);fflush(fp1);
										fprintf(fp1,"%s,","aplloader");fflush(fp1);

										cntFlag = 0;
										icount1 = 0;
										SetGMErr1 = NULL;
										SetGMErr1=(char *)MEM_alloc(5000);

										CheckPrtRelsFrmPlant_MBOM (Lattachments[LtaskCnt],SetGMErr1,&icount1); 
										printf("\n MBOM cntFlag: %d", cntFlag);fflush(stdout);
										printf("\n MBOM SetGMErr1: %s\n",SetGMErr1);fflush(stdout);

										if(icount1 > 0)
										{
										fprintf(fp1,"%s,","Pending");fflush(fp1);
										fprintf(fp1,"%s,",SetGMErr1);fflush(fp1);
										}
										else
										{
										printf("\n MBOM, No error found, hence promoting work on dml task.");
										ITK_CALL(EPM_promote_task(LFolderObj_tag[SignoffCnt],"Promoted by system to move the WF"));
										fprintf(fp1,"%s,","Completed");fflush(fp1);

										}
										fprintf(fp1,"\n");fflush(fp1);

										} // if of "Acknowledge ERC Flown Task"
										
									}

								 } // if of Object Typ check MBOMDML Revision
						  
					   }
					}
				   }
				   }
			  }
		  }
		}

	}  // if of "LoaderTask_found"

	}
	}
	}

	fprintf(fp1,"\n=================== Report END======================");fflush(fp1);
	
	printf("\n mail send command line:%s",SYNCinfo2);fflush(stdout);
	printf("\n Set of EMAIL Address cc :%s",SYNCinfo5);fflush(stdout);
	printf("\n Set of EMAIL Address to:%s",eMailTo);fflush(stdout);

   tc_strcat(command,SYNCinfo2);
   tc_strcat(command," ");
   tc_strcat(command,outputFile); // created csv file
   tc_strcat(command," ");
   tc_strcat(command,eMailTo); //to person mail address
   tc_strcat(command," ");
   tc_strcat(command,SYNCinfo5); // cc person mail address

   system(command);
   printf("\n ****************Mail Sending Done*****************");fflush(stdout);
   fclose(fp1);
} //if of SYNCount
} // if of CtrlObjQryTag
				
return ITK_ok;
	
}

