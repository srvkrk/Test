/****************************************************************************************************************************
*  Author               :   Mohan Tayade
*  Module               :   Print DCR properties in txt. file format
*  Code                 :   PartToFolder.c
*  Command				:	./DCR_Report -dcr_no=
*  Created on			:   09/09/2021
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*****************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <ae/dataset.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <epm/epm.h>
#include <ae/datasettype.h>
#include <ae/dataset.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <pie/pie.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#define ITK_err 919002
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))


char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';

	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_ask_error_text (return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"DCR_Report -dcr_no=\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );

    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


void strrpl(char * a)
{
	int i = 0;
	//while(a[i]!='\0')
	for (i = 0; a[i] != '\0'; i++)
    {
        if(a[i]==',')
        {
            a[i]=';';
        }
		if(a[i]=='\n')
        {
            a[i]=' ';
        }
    }
}

int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	int ref_count,cnt,i,j = 0;
	int tskprtcount = 0;
	int n = 1;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* partnumb					= NULL;
	char			* dcr_no					= NULL;

	char	*dcrNumber			=  NULL;  
	char	*DatesetName			=  NULL;  
	tag_t	dcr_tag				=  NULLTAG; 
	tag_t	rev_tag				=  NULLTAG;
	tag_t	dcr_Ref_Rel			=  NULLTAG;
	tag_t	msWordType			=  NULLTAG;
	tag_t	TextType			=  NULLTAG;
	tag_t	RefRelation			=  NULLTAG;
	tag_t	TextLatestDat_t		=  NULLTAG;
	tag_t	TextDataset		=  NULLTAG;
	tag_t	RefRel_t		=  NULLTAG;
	tag_t	filetag		=  NULLTAG;
	tag_t	tool		=  NULLTAG;
	char **ref_list;
	char	*dcrStatus			=  NULL;
	char	*dcrName			=  NULL;
	char	*dcrRevision		=  NULL;
	//char	*OneStar			=  NULL;
	//char	*TwoStar			=  NULL;
	//char	*TwoDsnap			=  NULL;
	//char	*ThreStar			=  NULL;
	//char	*ThreDsnap			=  NULL;
	//char	*FourStar			=  NULL;
	//char	*FiveStar			=  NULL;
	//char	*ActuatedTask		=  NULL;
	//char	*AddresBy			=  NULL;
	char	**AffectedDGrp	=  NULL;
	char	*AffectedItem		=  NULL;
	char	*Aggrigte			=  NULL;
	//char	*AliasID			=  NULL;
	//char	*AllWorkflows		=  NULL;
	//char	*AlterID			=  NULL;
	//char	*Altreps			=  NULL;
	//char	*Analt				=  NULL;
	//char	*Analst				=  NULL;
	//char	*AnalystUsrID		=  NULL;
	char	*ApproverTD			=  NULL;
	/*char	*Attaches			=  NULL;
	char	*AttribOveride		=  NULL;
	char	*AthoriChange		=  NULL;
	char	*AthoriPara			=  NULL;
	char	*AutoPropoRel		=  NULL;
	char	*AvgRating			=  NULL;
	//char	*BOMrollup			=  NULL;
	//char	*BOMviewRevi		=  NULL;
	//char	*BOMrollupAcc		=  NULL;
	//char	*BOMcgiX			=  NULL;
	//char	*BOMcgiY			=  NULL;
	//char	*BOMcgiZ			=  NULL;
	//char	*BOMrollMass		=  NULL;
	//char	*BOMxx				=  NULL;
	//char	*BOMyy				=  NULL;
	//char	*BOMzz				=  NULL;
	//char	*BOMxy				=  NULL;
	//char	*BOMxz				=  NULL;
	//char	*BOMyz				=  NULL;
	//char	*BsdOn				=  NULL;
	//char	*BsdOnRel			=  NULL;
	char	*BkdwnPlntItm		=  NULL;
	char	*Budg_Rel			=  NULL;
	//char	*C3Dview			=  NULL;
	char	*CAE_Analysis		=  NULL;
	//char	*CAE_Crite			=  NULL;
	//char	*CAE_Def			=  NULL;
	//char	*CAE_Incl			=  NULL;
	//char	*CAE_Para			=  NULL;
	//char	*CAE_Res			=  NULL;
	//char	*CAE_Sou_Rel		=  NULL;
	//char	*CAE_Tgt			=  NULL;
	char	*Capt				=  NULL;
	char	*AsyConfRel			=  NULL;*/
	char	*CatOfChange		=  NULL;
	//char	*chang				=  NULL;
	//char	*chngContri			=  NULL;
	//char	*chngImpBord		=  NULL;
	//char	*chngRefes			=  NULL;
	//char	*chngRevBod			=  NULL;
	//char	*chngSplst1			=  NULL;
	//char	*chngSplst1_user_id	=  NULL;
	//char	*chngSplst2			=  NULL;
	//char	*chngSplst2_user_id	=  NULL;
	//char	*chngSplst3			=  NULL;
	//char	*chngSplst3_user_id	=  NULL;
	char	*Cnh_issu_desc		=  NULL;
	//char	*checkedO			=  NULL;
	//char	*checkedOBy			=  NULL;
	//char	*checkedOChID		=  NULL;
	//char	*checkedODT			=  NULL;
	//char	*childIDRev			=  NULL;
	//char	*childValResult		=  NULL;
	/*char	*Classifi			=  NULL;
	char	*Classifed			=  NULL;
	char	*ClassifedIn		=  NULL;
	char	*Closure_			=  NULL;
	//char	*Closure_Comm		=  NULL;
	//char	*Closure_Dat		=  NULL;
	//char	*Commtry			=  NULL;
	//char	*Comp_obj			=  NULL;
	//char	*Config_dwg			=  NULL;
	//char	*Config_rev			=  NULL;
	//char	*connTab_rev		=  NULL;
	char	*contcs				=  NULL;
	char	*Cor_cg_cont		=  NULL;
	char	*corrDesc			=  NULL;
	char	*CorrtID			=  NULL;
	char	*Corr_Loc_code		=  NULL;
	char	*Corrnt_name		=  NULL;
	char	*Corr_rev_ID		=  NULL;
	//char	*Cust_req_Lst		=  NULL;
	char	*custommr			=  NULL;*/
	char	*Cre_Date			=  NULL;
	char	*DnDInMonths		=  NULL;
	/*char	*DCR_CS				=  NULL;
	char	*Obj_Desc			=  NULL;
	char	*DCR_FMQ			=  NULL;
	char	*DCR_PPM			=  NULL;
	char	*DCR_PRP1			=  NULL;
	char	*DCR_PRP2			=  NULL;
	char	*DCR_TS				=  NULL;
	char	*DCR_TVM			=  NULL;
	char	*DCR_VEM			=  NULL;
	char	*DCR_VPG			=  NULL;
	//char	*Achivd_date		=  NULL;
	//char	*bkup_date			=  NULL;
	char	*Dt_modifi			=  NULL;*/
	char	*Dt_pro_Amodifi		=  NULL;
	char	*Dt_relea			=  NULL;
	//char	*Declard_optio		=  NULL;
	//char	*defning_obj		=  NULL;
	//char	*DarivbTypes		=  NULL;
	//char	*Des_BOM_rel		=  NULL;
	char	*Desig_grp			=  NULL;
	char	*Dets_cat_chg		=  NULL;
	//char	*Dig_root_rel		=  NULL;
	//char	*Diag_snp			=  NULL;
	//char	*Dig_tmp_rel		=  NULL;
	//char	*SignAuditLog_		=  NULL;
	char	*SignStatus			=  NULL;
	//char	*Dis_Mod_View		=  NULL;
	//char	*Dis_View_lst		=  NULL;
	//char	*Dislo_Obj			=  NULL;
	//char	*Dis_Def_ID			=  NULL;
	char	*Disposit			=  NULL;
	//char	*Disposit_comm		=  NULL;
	//char	*Dispo_Date			=  NULL;
	//char	*Doc_Page			=  NULL;
	//char	*Dwgs				=  NULL;
	//char	*EC_Snap			=  NULL;
	//char	*Effecti			=  NULL;
	char	*EnvDimensions		=  NULL;
	//char	*Env_Desc			=  NULL;
	//char	*Explo_chkO			=  NULL;
	//char	*ExportedTo			=  NULL;
	//char	*Expoted_To			=  NULL;
	//char	*Ext_proxy_rel		=  NULL;
	//char	*fms_tkts			=  NULL;
	char	*Failure_Info		=  NULL;
	/*char	*Followers_D		=  NULL;
	char	*Found_Help			=  NULL;
	char	*Generi_archi		=  NULL;
	char	*Gen_comp_updated	=  NULL;
	char	*Gove_certifi		=  NULL;
	char	*Group_ID			=  NULL;
	//char	*Has_CAE_Fold		=  NULL;
	char	*Has_Module			=  NULL;
	char	*Has_trace_lk		=  NULL;
	char	*Has_Varient		=  NULL;
	char	*Has_Weld_prt		=  NULL;
	char	*ID_				=  NULL;
	//char	*ifrl_				=  NULL;
	//char	*IP_classifi		=  NULL;
	char	*IP_logged			=  NULL;
	char	*Impacted_			=  NULL;
	char	*impacts_			=  NULL;
	char	*Impliment_by		=  NULL;
	char	*impliments_		=  NULL;
	char	*In_Process			=  NULL;
	//char	*Incorpora			=  NULL;
	//char	*Intent_txt			=  NULL;
	//char	*inter_equ			=  NULL;
	//char	*inter_link			=  NULL;
	//char	*Desc_by_doc		=  NULL;
	char	*is_modified		=  NULL;
	//char	*is_rev_discont		=  NULL;
	//char	*is_suspe			=  NULL;
	char	*is_vi_				=  NULL;
	char	*itm_				=  NULL;
	char	*itm_mster			=  NULL;
	//char	*itm_DefConig		=  NULL;
	char	*is_itemRDC			=  NULL;
	//char	*has_var_mod		=  NULL;
	char	*lst_mod_user		=  NULL;*/
	char	*leadCOC			=  NULL;
	//char	*licenList			=  NULL;
	char	*dcr_loct			=  NULL;
	//char	*dcr_loctns			=  NULL;
	//char	*ME_setup			=  NULL;
	//char	*manifestations_		=  NULL;
	char	*dcr_matr				=  NULL;
	//char	*mat_const				=  NULL;
	char	*matur_					=  NULL;
	char	*may_chkOtBy			=  NULL;
	//char	*measurab_attri			=  NULL;
	//char	*mfg_model			=  NULL;
	char	*mint_ref_no			=  NULL;
	//char	*mlv_txt			=  NULL;
	//char	*motion_			=  NULL;
	char	*mul_k_info			=  NULL;
	//char	*nx_simul			=  NULL;
	//char	*NWeldSpot			=  NULL;
	char	*objects_			=  NULL;
	char	*OC_Prop			=  NULL;
	//char	*obf_Followed			=  NULL;
	//char	*owend_mod_view			=  NULL;
	char	*workflow_task			=  NULL;
	char	*owng_user			=  NULL;
	//char	*owng_org			=  NULL;
	char	*owng_pro			=  NULL;
	//char	*owng_site			=  NULL;
	char	*pnsc_cat			=  NULL;
	//char	*param_reqLst			=  NULL;
	char	*particip_			=  NULL;
	char	*particip_disp			=  NULL;
	char	*plans_			=  NULL;
	//char	*prev_effe			=  NULL;
	//char	*prob_itm			=  NULL;
	char	*probms			=  NULL;
	char	*probs_modif			=  NULL;
	char	*me_proc			=  NULL;
	char	*proce_stg			=  NULL;
	char	*proce_stg_lst			=  NULL;
	//char	*pro_int_geo			=  NULL;
	//char	*pro_int_para			=  NULL;
	char	*Pro_appli			=  NULL;
	char	*proj_code			=  NULL;
	char	*proj_id			=  NULL;
	char	*proj_ids			=  NULL;
	char	*pro_nm			=  NULL;
	char	*pro_nmDup			=  NULL;
	char	*proj_obj			=  NULL;
	char	*projID_			=  NULL;
	char	*projects_			=  NULL;
	//char	*proposalE			=  NULL;
	//char	*prop_resp_prty			=  NULL;
	//char	*prop_revever			=  NULL;
	char	*prop_soln			=  NULL;
	char	*protn			=  NULL;
	//char	*publish_by			=  NULL;
	//char	*ratgs			=  NULL;
	char	*Rison			=  NULL;
	char	*ref_itm			=  NULL;
	char	*refrncs			=  NULL;
	char	*ref_modifabl			=  NULL;
	//char	*regul_nmb			=  NULL;
	char	*regl_nmb			=  NULL;
	//char	*reltd_fmea			=  NULL;
	char	*rel_Aprop			=  NULL;
	//char	*rendrng			=  NULL;
	//char	*reprntFr			=  NULL;
	char	*Req_agcy			=  NULL;
	char	*requstr			=  NULL;
	char	*requstr_			=  NULL;
	char	*req_id_			=  NULL;
	//char	*reqst_prt			=  NULL;
	//char	*reqrtmn			=  NULL;
	//char	*resoSitRel			=  NULL;
	//char	*reu_asmb			=  NULL;
	char	*revignsID			=  NULL;
	char	*rtcuana			=  NULL;
	//char	*sndTo			=  NULL;
	char	*sq_id			=  NULL;
	//char	*sq_inf			=  NULL;
	char	*sq_lmt			=  NULL;
	//char	*seqEvnt			=  NULL;
	//char	*seveRtng			=  NULL;
	//char	*shpreln			=  NULL;
	//char	*simpliRndr			=  NULL;
	//char	*snpshot			=  NULL;
	//char	*solunitm			=  NULL;
	//char	*sol_itmvarconf			=  NULL;
	//char	*sol_var_rep			=  NULL;
	//char	*sulon			=  NULL;
	//char	*spatialR			=  NULL;
	//char	*specialist			=  NULL;
	//char	*specifqn			=  NULL;
	char	*stgOfPr			=  NULL;
	char	*strWFtsk			=  NULL;
	//char	*stat_snp			=  NULL;
	char	*SubAggr			=  NULL;
	char	*Sun_cata			=  NULL;
	/*char	*Aplav			=  NULL;
	char	*Aplcv			=  NULL;
	char	*Apldv			=  NULL;
	char	*Apljv			=  NULL;
	char	*Apllv			=  NULL;
	char	*Aplpv			=  NULL;
	char	*Aplsv			=  NULL;
	char	*Apluv			=  NULL;
	char	*Aplvv			=  NULL;
	char	*Dfmat5			=  NULL;
	char	*STDav			=  NULL;
	char	*STDcv			=  NULL;
	char	*STDdv			=  NULL;
	char	*STDvu			=  NULL;
	char	*STDjv			=  NULL;
	char	*STDlv			=  NULL;
	char	*STDuv			=  NULL;
	char	*sst_rcd			=  NULL;
	char	*xml_confi			=  NULL;
	char	*xml_unconfi			=  NULL;
	char	*tges			=  NULL;
	char	*STDpv			=  NULL;
	char	*STDsv			=  NULL;
	char	*STDvv			=  NULL;
	char	*TCprodManul			=  NULL;
	char	*tgsFrSummry			=  NULL;
	char	*TechRevPrio			=  NULL;
	char	*Thmbnl			=  NULL;
	char	*Thmbnl_sor			=  NULL;
	char	*Totl_ans			=  NULL;
	char	*Totl_Comm			=  NULL;
	char	*Totl_Expr			=  NULL;
	char	*Totl_flw			=  NULL;
	
	
	char	*Totl_Que			=  NULL;
	char	*Totl_Ratn			=  NULL;
	char	*TrcLnk			=  NULL;
	char	*ug_exps			=  NULL;
	char	*ug_pro			=  NULL;
	char	*ug_scen			=  NULL;
	char	*ug_udf			=  NULL;
	char	*ug_wavGeo			=  NULL;
	char	*ug_wav_prt_lnk			=  NULL;
	char	*ug_wav_pos			=  NULL;
	char	*usd_potns			=  NULL;*/
	char	*capexLk			=  NULL;
	char	*DMC_inR			=  NULL;
	char	*Obje_Typ			=  NULL;
	char	*usr_cn_unma			=  NULL;
	char	*usr_rat_val			=  NULL;
	char	*VC_numb			=  NULL;
	char	*veh_calsifi			=  NULL;
	char	*vehic_for			=  NULL;
	/*char	*vchasESTdoc			=  NULL;
	char	*TC_Valida			=  NULL;
	char	*vend_reprs			=  NULL;
	char	*veri_fic			=  NULL;*/
	char	*versi_ltd			=  NULL;
	char	*weitimp			=  NULL;
	char	*vpg_rem			=  NULL;
	char	*aq_rem			=  NULL;
	char	*cs_rem			=  NULL;
	char	*tvm_rem			=  NULL;
	char	*qa_rem			=  NULL;
	char	*ts_rem			=  NULL;
	char	*vem_rem			=  NULL;
	char	*CE_app			=  NULL;
	char	*PM_app			=  NULL;
	char	*cab1_inp			=  NULL;
	char	*cab2_inp			=  NULL;
	/*char	*verg_numb			=  NULL;
	char	*view_			=  NULL;
	char	*view_capt			=  NULL;
	char	*Vizmok			=  NULL;
	char	*VizSess			=  NULL;
	
	char	*weitimp_val			=  NULL;
	char	*wrkContRel			=  NULL;
	char	*wkrinstr			=  NULL;
	char	*wrkngEnvi			=  NULL;
	char	*wsObjthr			=  NULL;
	char	*mtbf			=  NULL;
	char	*catia3D			=  NULL;
	char	*cat_altershap			=  NULL;
	char	*cat_Aux_lnk			=  NULL;
	char	*cat_cht_lk			=  NULL;
	char	*cat_comp_shape			=  NULL;
	char	*cat_ext_lnk			=  NULL;
	char	*cat_mfg_lk			=  NULL;
	char	*cat_mul_mod			=  NULL;
	char	*cat_sec_lnk			=  NULL;
	char	*cat_shp_lnk			=  NULL;*/
	char	*Asuppchange			=  NULL;
	char	*Chingmt			=  NULL;
	char	*Chmfgpro			=  NULL;
	char	*CurrMatthikness			=  NULL;
	char	*CurrRawMatV			=  NULL;
	char	*Currentsupp			=  NULL;
	char	*Currentwt			=  NULL;
	char	*DcrCPVs			=  NULL;
	char	*DcrComdityAffs			=  NULL;
	char	*DcrEstPrtDevTimes			=  NULL;
	char	*DcrExSvrcCosts			=  NULL;
	char	*DcrExSvrcTimes			=  NULL;
	char	*DcrGrnRptFIRAvails			=  NULL;
	char	*DcrIPTVs			=  NULL;
	char	*DcrInterImpacts			=  NULL;
	char	*DcrMfgTimes			=  NULL;
	char	*DcrNVPs			=  NULL;
	char	*DcrPreValues			=  NULL;
	char	*DcrQltyImpcts			=  NULL;
	char	*DcrServicImpcts			=  NULL;
	char	*DcrTrgIncrCosts			=  NULL;
	char	*DcrTrgIncrImpcts			=  NULL;
	char	*Deschpro			=  NULL;
	char * aq_per = NULL;
	char * cs_per = NULL;
	char * qa_per = NULL;
	char * tvm_per = NULL;
	char * ts_per = NULL;
	char * vem_per = NULL;
	char * vpg_per = NULL;
	char	*Prt_DR				= NULL;  
	char	*partdesc			= NULL;  
	char	*partID				= NULL;  
	char	*partNo				= NULL;  
	//char    partNo     =  (char **) MEM_alloc(30 * sizeof(char *));
	int size = 10;
	int DsgnGrp = 0;
	partNo = (char *)malloc((size + 1) * sizeof(char));
	char	**design_grp_list	= NULL;
	tag_t	objTypTag			= NULLTAG;
	tag_t	relation_type			= NULLTAG;
	tag_t	*dcr_task			= NULLTAG;
	tag_t	relationtype			= NULLTAG;
	tag_t	relationofpart			= NULLTAG;
	tag_t	*dcrprts			= NULLTAG;
	tag_t job = NULLTAG;
	tag_t job_type = NULLTAG;
	tag_t roottask = NULLTAG;
	tag_t wftask = NULLTAG;
	tag_t *subtasks = NULLTAG;
	tag_t *DCRForms = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t DCRObjects = NULLTAG;
	int taskcount = 0;
	char *nameofroot =  NULL;
	char *wftaskname =  NULL;
	char *cab1per =  NULL;
	char *cab2per =  NULL;
	char *CAB1comt =  NULL;
	char *CAB2comt =  NULL;
	char *fndObjTyp =  NULL;
	char * wtchng = NULL;
	char * cocrmk = NULL;
	char * DFMSever = NULL;
	char * PrtPrcub = NULL;
	char * ValImpt = NULL;
	char *CarMakeby = NULL;
	char *revision_id = NULL;
	char	*moddetails			= NULL;
	char	*objectname			= NULL;
	char	*ObjTyp				= NULL;
	char	* FileDown			= NULL;
	char	* attachname		= NULL;
	char	*cError				= NULL;
	
	dcr_no 		= ITK_ask_cli_argument("-dcr_no=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);
	IMF_file_t fileDescriptor;

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);


	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		FILE *fd=NULL;

		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");

		ifail = ITEM_find_item(dcr_no, &dcr_tag);
		if (dcr_tag != NULLTAG)
		{
			printf("\nDCR Number %s found in data base \n",dcr_no);fflush(stdout);
			ifail = ITEM_ask_latest_rev(dcr_tag, &rev_tag);
			if (rev_tag != NULLTAG)
			{
				printf("\nDCR Latest Revision for %s is found in data base \n",dcr_no);fflush(stdout);
				FileDown = (char *) MEM_alloc (sizeof (char) * 128);
				attachname = (char *) MEM_alloc (sizeof (char) * 128);

				printf("\nFileDown completed sucessfully \n");fflush(stdout);

				ifail = TCTYPE_ask_object_type(rev_tag,&objTypTag);
				if (objTypTag != NULLTAG)
				{
					printf("\nObject Type Tag found sucessfully \n");fflush(stdout);
					ifail = TCTYPE_ask_name2(objTypTag,&ObjTyp);
					if (ObjTyp != NULL)
					{
						printf("\n Found Object Type for DCR : \n");fflush(stdout);
						if(tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0)
						{
							if(AOM_ask_value_string(rev_tag,"item_id",&dcrNumber)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"release_status_list",&dcrStatus)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"object_name",&dcrName)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"item_revision_id",&dcrRevision)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"s2clTotal1StarFromSummary",&OneStar)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"s2clTotal2StarFromSummary",&TwoStar)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"VisItemRevCreatedSnapshot2D",&TwoDsnap)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"s2clTotal3StarFromSummary",&ThreStar)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_3D_snap_shot",&ThreDsnap)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"s2clTotal4StarFromSummary",&FourStar)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"s2clTotal5StarFromSummary",&FiveStar)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0ActuatedInteractiveTsks",&ActuatedTask)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"EC_addressed_by_rel",&AddresBy)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_strings(rev_tag,"t5_DcrDesgGrp",&DsgnGrp,&AffectedDGrp)!=ITK_ok)PrintErrorStack();
							printf("/n Size of Affected Design group are %d",DsgnGrp);
							int w,x = 0;
							// Calculate the total length needed for the concatenated string
							int totalLength = 0;
							for ( w = 0; w < DsgnGrp; w++) {
								totalLength += strlen(AffectedDGrp[w]);
							}

							// Create a buffer to hold the concatenated string
							char concatenatedString[totalLength + 1];  // +1 for the null-terminator

							// Concatenate the AffectedDGrp
							int currentPosition = 0;
							for (x = 0; x < DsgnGrp; x++) {
								strcpy(concatenatedString + currentPosition, AffectedDGrp[x]);
								currentPosition += strlen(AffectedDGrp[x]);
							}

							// Null-terminate the concatenated string
							concatenatedString[totalLength] = '\0';

							// Print the concatenated string
							printf("/nConcatenated string: %s\n", concatenatedString);
							strrpl(concatenatedString);

							if(AOM_ask_value_string(rev_tag,"EC_affected_item_rel",&AffectedItem)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrAggregate",&Aggrigte)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_aliasid",&AliasID)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0AllWorkflows",&AllWorkflows)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"altid_list",&AlterID)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_UG_altrep",&Altreps)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Analyst",&Analt)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"cm0Analyst",&Analst)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"analyst_user_id",&AnalystUsrID)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrAppNam",&ApproverTD)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"TC_Attaches",&Attaches)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0StruObjAttrOverride",&AttribOveride)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"cm0AuthoringChangeRevision",&AthoriChange)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ead_paragraph",&AthoriPara)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"cm0AutoPropagateRelations",&AutoPropoRel)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"s2clAverageRatingFmSy",&AvgRating)!=ITK_ok)PrintErrorStack();
							/*if(AOM_ask_value_string(rev_tag,"BOM_Rollup",&BOMrollup)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"structure_revisions",&BOMviewRevi)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupAccuracy",&BOMrollupAcc)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupCoMx",&BOMcgiX)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupCoMy",&BOMcgiY)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupCoMz",&BOMcgiZ)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupMass",&BOMrollMass)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupMoIxx",&BOMxx)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupMoIyy",&BOMyy)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupMoIzz",&BOMzz)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupMoIxy",&BOMxy)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupMoIxz",&BOMxz)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0rollupMoIyz",&BOMyz)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"based_on",&BsdOn)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_based_on",&BsdOnRel)!=ITK_ok)PrintErrorStack();*/
							//if(AOM_ask_value_string(rev_tag,"T5_DMLTaskRelation",&BkdwnPlntItm)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Seg0BudgetRelation",&Budg_Rel)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"C3D_View",&C3Dview)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CAEAnalysis",&CAE_Analysis)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"TC_CAE_Criteria",&CAE_Crite)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"TC_CAE_Defining",&CAE_Def)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"TC_CAE_Include",&CAE_Incl)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"TC_CAE_Param",&CAE_Para)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"TC_CAE_Results",&CAE_Res)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"TC_CAE_Source",&CAE_Sou_Rel)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"TC_CAE_Target",&CAE_Tgt)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_capture",&Capt)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Cat2AssyConfigLink",&AsyConfRel)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrCreCatChng",&CatOfChange)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"change",&chang)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"cm0ChangeContributors",&chngContri)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ChangeImplementationBoard",&chngImpBord)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CMReferences",&chngRefes)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ChangeReviewBoard",&chngRevBod)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ChangeSpecialist1",&chngSplst1)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ChangeSpecialist1_user_id",&chngSplst1_user_id)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ChangeSpecialist2",&chngSplst2)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ChangeSpecialist2_user_id",&chngSplst2_user_id)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ChangeSpecialist3",&chngSplst3)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ChangeSpecialist3_user_id",&chngSplst3_user_id)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrDesc",&Cnh_issu_desc)!=ITK_ok)PrintErrorStack();
							strrpl(Cnh_issu_desc);
							//if(AOM_ask_value_string(rev_tag,"checked_out",&checkedO)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"checked_out_user",&checkedOBy)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"checked_out_change_id",&checkedOChID)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"checked_out_date",&checkedODT)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ps_children",&childIDRev)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0TC_valdata_result",&childValResult)!=ITK_ok)PrintErrorStack();
							/*if(AOM_ask_value_string(rev_tag,"fnd0IcsClassNames",&Classifi)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"ics_classified",&Classifed)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"ics_subclass_name",&ClassifedIn)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"CMClosure",&Closure_)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CMClosureComments",&Closure_Comm)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CMClosureDate",&Closure_Dat)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"s2clCommentaryObjects",&Commtry)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0complying_objects",&Comp_obj)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0ConfiguredDrawings",&Config_dwg)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"awp0ConfiguredRevision",&Config_rev)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Mfg0MEConnectorTblFormRel",&connTab_rev)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"ContactInCompany",&contcs)!=ITK_ok)PrintErrorStack();
							
							if(AOM_ask_value_string(rev_tag,"fnd0CurrentChangeContext",&Cor_cg_cont)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"current_desc",&corrDesc)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"current_id",&CorrtID)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0CurrentLocationCode",&Corr_Loc_code)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"current_name",&Corrnt_name)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"current_revision_id",&Corr_rev_ID)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0ListsCustomNotes",&Cust_req_Lst)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"customers",&custommr)!=ITK_ok)PrintErrorStack();*/
							if(AOM_UIF_ask_value(rev_tag,"creation_date",&Cre_Date)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_Dcrdndtmmo",&DnDInMonths)!=ITK_ok)PrintErrorStack();
							/*if(AOM_ask_value_string(rev_tag,"t5_DCR_CS",&DCR_CS)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"object_desc",&Obj_Desc)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DCR_FMQ",&DCR_FMQ)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DCR_PPM",&DCR_PPM)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DCR_PRP1",&DCR_PRP1)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DCR_PRP2",&DCR_PRP2)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DCR_TS",&DCR_TS)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DCR_TVM",&DCR_TVM)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DCR_VEM",&DCR_VEM)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DCR_VPG",&DCR_VPG)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"archive_date",&Achivd_date)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"backup_date",&bkup_date)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"last_mod_date",&Dt_modifi)!=ITK_ok)PrintErrorStack();*/
							if(AOM_ask_value_string(rev_tag,"proj_assign_mod_date",&Dt_pro_Amodifi)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"date_released",&Dt_relea)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"declared_options",&Declard_optio)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0defining_objects",&defning_obj)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"cm0DerivableTypes",&DarivbTypes)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0DesignToBomRelation",&Des_BOM_rel)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5designgroup",&Desig_grp)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrG3Subch",&Dets_cat_chg)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0Diagram_Attaches",&Dig_root_rel)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0DiagramSnapshot",&Diag_snp)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0DiagramTmplRelation",&Dig_tmp_rel)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0DigitalSignAuditLogs",&SignAuditLog_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0DSState",&SignStatus)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0DisclosedViewList",&Dis_View_lst)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0DisclosingObject",&Dislo_Obj)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"id_dispdefault",&Dis_Mod_View)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0DisclosedModelViews",&Dis_Def_ID)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"CMDisposition",&Disposit)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CMDispositionComments",&Disposit_comm)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CMDispositionDate",&Dispo_Date)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0DocPageTypeRel",&Doc_Page)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0Drawings",&Dwgs)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"EC_snapshot_rel",&EC_Snap)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"effectivity_text",&Effecti)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_EnvDimension",&EnvDimensions)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CMEnvironmentDescription",&Env_Desc)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"expl_checkout",&Explo_chkO)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"external_apps",&ExportedTo)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"export_sites",&Expoted_To)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_external_object_link",&Ext_proxy_rel)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fms_tickets",&fms_tkts)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrCreFI",&Failure_Info)!=ITK_ok)PrintErrorStack();
							/*if(AOM_ask_value_string(rev_tag,"s2clSubscribersFromSummary",&Followers_D)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"s2clTotalLikesFromSummary",&Found_Help)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"TC_Generic_Architecture",&Generi_archi)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"gc_updated_from_object_string",&Gen_comp_updated)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"gov_classification",&Gove_certifi)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"owning_group",&Group_ID)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CAE0FileCollectionContents",&Has_CAE_Fold)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"has_module",&Has_Module)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"has_trace_link",&Has_trace_lk)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"has_variants",&Has_Varient)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_HasWeldParts",&Has_Weld_prt)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"awp0Item_item_id",&ID_)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"A4_HasFunctions",&ifrl_)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"ip_classification",&IP_classifi)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"ip_logged",&IP_logged)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"CMHasImpactedItem",&Impacted_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"CMRamification",&impacts_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"CMImplementedBy",&Impliment_by)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"CMImplements",&impliments_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0InProcess",&In_Process)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Cm0Incorporates",&Incorpora)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"intent_text",&Intent_txt)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"interpart_equations",&inter_equ)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"interpart_links",&inter_link)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0IsDescribedByDocument",&Desc_by_doc)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"is_modifiable",&is_modified)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0IsRevisionDiscontinued",&is_rev_discont)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"awp0IsSuspect",&is_suspe)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"is_vi",&is_vi_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"items_tag",&itm_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_master_form_rev",&itm_mster)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0IRDCUsed",&itm_DefConig)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"is_IRDC",&is_itemRDC)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"has_variant_module",&has_var_mod)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"last_mod_user",&lst_mod_user)!=ITK_ok)PrintErrorStack();*/
							if(AOM_ask_value_string(rev_tag,"t5_DcrLeadCoc",&leadCOC)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"license_list",&licenList)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrLocation",&dcr_loct)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"LocationInCompany",&dcr_loctns)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"MESetup",&ME_setup)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_manifestation",&manifestations_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrMaterial",&dcr_matr)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"mating_constraints",&mat_const)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"CMMaturity",&matur_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0IsCheckoutable",&may_chkOtBy)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Att0AttrRelation",&measurab_attri)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_MEMfgModel",&mfg_model)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"t5_MinrefNo",&mint_ref_no)!=ITK_ok)PrintErrorStack();
							if(AOM_UIF_ask_value(rev_tag,"t5_MinrefNo",&mint_ref_no)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"mvl_text",&mlv_txt)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_Motion",&motion_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0mfkinfo",&mul_k_info)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0MyWorkflowTasks",&workflow_task)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_Simulation",&nx_simul)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"t5_NoOfWeldSpots",&NWeldSpot)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"object_string",&objects_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"awp0CellProperties",&OC_Prop)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"s2clSubscriptionsFmSy",&obf_Followed)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0OwnedModelViews",&owend_mod_view)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"owning_user",&owng_user)!=ITK_ok)PrintErrorStack();
							if(AOM_UIF_ask_value(rev_tag,"owning_user",&owng_user)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"owning_organization",&owng_org)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"owning_project",&owng_pro)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"owning_site",&owng_site)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrPSCCategory",&pnsc_cat)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0ListsParamReqments",&param_reqLst)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"HasParticipant",&particip_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"awp0ShowParticipants",&particip_disp)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"CMHasWorkBreakdown",&plans_)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Cm0PreviousEffectivity",&prev_effe)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"EC_problem_item_rel",&prob_itm)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"CMHasProblemItem",&probms)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"cm0IsProblemsModifiable",&probs_modif)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"MEProcess",&me_proc)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"process_stage",&proce_stg)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"process_stage_list",&proce_stg_lst)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"geometric_interfaces",&pro_int_geo)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"parametric_interfaces",&pro_int_para)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrGProg",&Pro_appli)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrProCode",&proj_code)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5projectname",&proj_id)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"project_ids",&proj_ids)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"object_desc",&pro_nm)!=ITK_ok)PrintErrorStack();
							strrpl(pro_nm);
							if(AOM_ask_value_string(rev_tag,"projects_list",&proj_obj)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5project",&projID_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"project_list",&projects_)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Cm0HasProposal",&proposalE)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"epm_proposed_responsible_party",&prop_resp_prty)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"epm_proposed_reviewers",&prop_revever)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrCreProSol",&prop_soln)!=ITK_ok)PrintErrorStack();
							strrpl(prop_soln);
							if(AOM_ask_value_string(rev_tag,"protection",&protn)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"publication_sites",&publish_by)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"s2clCommentaryRatingObjects",&ratgs)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrCreRC",&Rison)!=ITK_ok)PrintErrorStack();
							strrpl(Rison);
							if(AOM_ask_value_string(rev_tag,"EC_reference_item_rel",&ref_itm)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_reference",&refrncs)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"cm0IsReferencesModifiable",&ref_modifabl)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"t5_RiskAreas",&regul_nmb)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrRegNo",&regl_nmb)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"A4Has_FMEA",&reltd_fmea)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"cm0RelationsToPropagate",&rel_Aprop)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"release_status_list",&dcrStatus)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_Rendering",&rendrng)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"representation_for",&reprntFr)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrCreAge",&Req_agcy)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"Requestor",&requstr)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"cm0Requestor",&requstr_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"requestor_user_id",&req_id_)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"awp0RequiredParticipants",&reqst_prt)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_requirement",&reqrtmn)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Mfg0ResourceSiteDataRel",&resoSitRel)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"fnd0reuseAssembly",&reu_asmb)!=ITK_ok)PrintErrorStack();

							if(AOM_ask_value_string(rev_tag,"revision_list",&revignsID)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrRootCausAnalysis",&rtcuana)!=ITK_ok)PrintErrorStack();
							strrpl(rtcuana);
							//if(AOM_ask_value_string(rev_tag,"s2clSendToListFromSummary",&sndTo)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"sequence_id",&sq_id)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"sequence_anchor",&sq_inf)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"sequence_limit",&sq_lmt)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CMSequenceOfEvents",&seqEvnt)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CMSeverityRating",&seveRtng)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0ShapeRelation",&shpreln)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"SimplifiedRendering",&simpliRndr)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_snapshot",&snpshot)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"EC_solution_item_rel",&solunitm)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Smc0SolutionItemConfig",&sol_itmvarconf)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Smc0SolutionVariantSource",&sol_var_rep)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CMHasSolutionItem",&sulon)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0SpatialRendering",&spatialR)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"cm0ChangeSpecialist1",&specialist)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"IMAN_specification",&specifqn)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrCreSP",&stgOfPr)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"fnd0StartedWorkflowTasks",&strWFtsk)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"Fnd0ExportContent",&stat_snp)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrSubAggregate",&SubAggr)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrCreSubCat",&Sun_cata)!=ITK_ok)PrintErrorStack();
							/*if(AOM_ask_value_string(rev_tag,"T5_APLAView",&Aplav)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_APLCView",&Aplcv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_APLDView",&Apldv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_APLJView",&Apljv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_APLLView",&Apllv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_APLPView",&Aplpv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_APLSView",&Aplsv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_APLUView",&Apluv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_APLVView",&Aplvv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_DFMA",&Dfmat5)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_STDAView",&STDav)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_STDCView",&STDcv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_STDDView",&STDdv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_STDJView",&STDjv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_STDLView",&STDlv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_STDPView",&STDpv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_STDSView",&STDsv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_STDUView",&STDvu)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"T5_STDVView",&STDvv)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"TC_ProductManual",&TCprodManul)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"TC_sst_record",&sst_rcd)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"TCEng_rdv_plmxml_configured",&xml_confi)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"TCEng_rdv_plmxml_unconfigured",&xml_unconfi)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"s2clTags",&tges)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"s2clTagsFromSummary",&tgsFrSummry)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"CMTechReviewPriority",&TechRevPrio)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"Thumbnail",&Thmbnl)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"Thumbnail_Source",&Thmbnl_sor)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"s2clTotalAnsweredFmSy",&Totl_ans)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"s2clTotalCommentsFmSy",&Totl_Comm)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"s2clTotalExperiencesFmSy",&Totl_Expr)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"s2clTotalFollowsFromSummary",&Totl_flw)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"s2clTotalQuestionsFmSy",&Totl_Que)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"s2clTotalRatingsFromSummary",&Totl_Ratn)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"FND_TraceLink",&TrcLnk)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_UG_expression",&ug_exps)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_UG_promotion",&ug_pro)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_UG_scenario",&ug_scen)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_UG_udf",&ug_udf)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_UG_wave_geometry",&ug_wavGeo)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_UG_wave_part_link",&ug_wav_prt_lnk)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_UG_wave_position",&ug_wav_pos)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"used_options",&usd_potns)!=ITK_ok)PrintErrorStack();*/
							if(AOM_ask_value_string(rev_tag,"t5_Dcrtcpxinl",&capexLk)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrtoImDMC",&DMC_inR)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"object_type",&Obje_Typ)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"user_can_unmanage",&usr_cn_unma)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"s2clUserRatingValue",&usr_rat_val)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"T8_EstDocHasVC_PIPForm",&vchasESTdoc)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrVCNo",&VC_numb)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"TC_Validation",&TC_Valida)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrVehClassification",&veh_calsifi)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrVehFor",&vehic_for)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"VMRepresents",&vend_reprs)!=ITK_ok)PrintErrorStack();
							//if(AOM_ask_value_string(rev_tag,"CMVerification",&veri_fic)!=ITK_ok)PrintErrorStack();*/
							if(AOM_ask_value_string(rev_tag,"revision_limit",&versi_ltd)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrWtImpact",&weitimp)!=ITK_ok)PrintErrorStack();
							/*if(AOM_ask_value_string(rev_tag,"revision_number",&verg_numb)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"view",&view_)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"Fnd0ViewCapture",&view_capt)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"VisMarkup",&Vizmok)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"VisSession",&VizSess)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_WtImpactGms",&weitimp_val)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"TC_WorkContext_Relation",&wrkContRel)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"IMAN_MEWorkInstruction",&wkrinstr)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"Cm0WorkingEnvironment",&wrkngEnvi)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"wso_thread",&wsObjthr)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"a4_MTBF",&mtbf)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"catia",&catia3D)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"catia_alternateShapeRep",&cat_altershap)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"catia_auxiliaryLink",&cat_Aux_lnk)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"catia_cache_link",&cat_cht_lk)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"catia_componentShapeRep",&cat_comp_shape)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"catia_external_link",&cat_ext_lnk)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"catia_mfgproduct_link",&cat_mfg_lk)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"catia_multi_model",&cat_mul_mod)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"catia_secondary_link",&cat_sec_lnk)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"catia_shapeProperties_link",&cat_shp_lnk)!=ITK_ok)PrintErrorStack();*/
							if(AOM_ask_value_string(rev_tag,"t5_Asuppchange",&Asuppchange)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_Chingmt",&Chingmt)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_Chmfgpro",&Chmfgpro)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_CurrMatthikness",&CurrMatthikness)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_CurrRawMatV",&CurrRawMatV)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_Currentsupp",&Currentsupp)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_Currentwt",&Currentwt)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrCPVs",&DcrCPVs)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrComdityAffs",&DcrComdityAffs)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrEstPrtDevTimes",&DcrEstPrtDevTimes)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrExSvrcCosts",&DcrExSvrcCosts)!=ITK_ok)PrintErrorStack();
							if(AOM_UIF_ask_value(rev_tag,"t5_DcrExSvrcTimes",&DcrExSvrcTimes)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrGrnRptFIRAvails",&DcrGrnRptFIRAvails)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrIPTVs",&DcrIPTVs)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrInterImpacts",&DcrInterImpacts)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrMfgTimes",&DcrMfgTimes)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrNVPs",&DcrNVPs)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrPreValues",&DcrPreValues)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrQltyImpcts",&DcrQltyImpcts)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrServicImpcts",&DcrServicImpcts)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrTrgIncrCosts",&DcrTrgIncrCosts)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_DcrTrgIncrImpcts",&DcrTrgIncrImpcts)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(rev_tag,"t5_Deschpro",&Deschpro)!=ITK_ok)PrintErrorStack();

							printf("\n MT:DCR Number: [%s]", dcrNumber);fflush(stdout);
							printf("\n MT:DCR Revision: [%s]", dcrRevision);fflush(stdout);
							printf("\n MT:DCR Name: [%s]", dcrName);fflush(stdout);
							printf("\n MT:DCR Rlease Status: [%s]", dcrStatus);fflush(stdout);

							tc_strcpy(FileDown,"/user/uaprodtrl/Program_Shells/DCRReport/");
							//tc_strcpy(FileDown,"/user/testcmi/Dev/devgroups/Prasads/DCR/DCR_Pro_Report/");
							//tc_strcpy(FileDown,"/tmp/");
							printf("\nFolder creater for the file \n");fflush(stdout);
							tc_strcat(FileDown,dcrNumber);
							tc_strcat(FileDown,"_DCR_Print_Report.csv");
							
							tc_strcpy(attachname,"");
							//tc_strcat(attachname,"/tmp/");
							tc_strcat(attachname,dcrNumber);
							tc_strcat(attachname,"_DCR_Print_Report");
							printf("\nText file name created [%s]\n",attachname);fflush(stdout);
							TC_write_syslog("Main File = %s\n",FileDown);
							
							fd = fopen(FileDown,"w");
							
							if(fd==NULL)
							{
								printf("\nError in opening the file \n");fflush(stdout);
								return 1;
							}
							printf("\nFile created at with name [%s] \n",FileDown);fflush(stdout);

							printf("\nWrite report\nDCR Number					%s",dcrNumber);fflush(stdout);

							fprintf(fd,",-- DCR Print Report --\n\n"); fflush(fd);
							fprintf(fd,"\n,--DCR/ PCR (Design/ Process Change Request--)");
							fprintf(fd,"\n\nSr NO., ATTRIBUTES				,VALUES");

							fprintf(fd,"\n%d,Project Name/Desc				,%s",n++,pro_nm);fflush(fd);
							fprintf(fd,"\n%d,DCR Number					,%s",n++,dcrNumber);fflush(fd);
							fprintf(fd,"\n%d,Mint Refernce No				,%s",n++,mint_ref_no);fflush(fd);
							fprintf(fd,"\n%d,Project Code					,%s",n++,proj_code);fflush(fd);
							fprintf(fd,"\n%d,Creation Date				,%s",n++,Cre_Date);
							fprintf(fd,"\n%d,Creator							,%s",n++,owng_user);fflush(fd);
							fprintf(fd,"\n%d,Stage of Program				,%s",n++,stgOfPr);fflush(fd);
							fprintf(fd,"\n%d,Requesting Agency				,%s",n++,Req_agcy); fflush(fd);
							fprintf(fd,"\n%d,Reason						,%s",n++,Rison);fflush(fd);
							fprintf(fd,"\n%d,Failure Information				,%s",n++,Failure_Info);fflush(fd);
							fprintf(fd,"\n%d,Affected Design Groups		,%s",n++,concatenatedString); fflush(fd);
							fprintf(fd,"\n%d,Lead CoC					,%s",n++,leadCOC);fflush(fd);
							fprintf(fd,"\n%d,Aggregate						,%s",n++,Aggrigte);fflush(fd);
							fprintf(fd,"\n%d,Change/Issue Description			,%s",n++,Cnh_issu_desc);fflush(fd);
							fprintf(fd,"\n%d,Proposed Solution				,%s",n++,prop_soln);fflush(fd);
							fprintf(fd,"\n%d,Root Cause Analysis				,%s",n++,rtcuana);fflush(fd);

							fprintf(fd,"\n\n,--DCR Cost| Time | Quality Impact Summary Approved by CAB--\n");fflush(fd);

							fprintf(fd,"\n%d,CPV (Rs)					,%s",n++,DcrCPVs);fflush(fd);
							fprintf(fd,"\n%d,Targeted Incremental DMC Impact (Rs)			,%s",n++,DcrTrgIncrImpcts);fflush(fd);
							fprintf(fd,"\n%d,IPTV (Rs)					,%s",n++,DcrIPTVs);fflush(fd);
							fprintf(fd,"\n%d,Estimated part development time including tooling development(Months)			,%s",n++,DcrEstPrtDevTimes);fflush(fd);
							fprintf(fd,"\n%d,QUALITY IMPACT for the Change			,%s",n++,DcrQltyImpcts);fflush(fd);
							fprintf(fd,"\n%d,NPV (In Lakhs)					,%s",n++,DcrNVPs);fflush(fd);
							fprintf(fd,"\n%d,Commodity Affected				,%s",n++,DcrComdityAffs);fflush(fd);
							fprintf(fd,"\n%d,Targeted Incremental Capex including tooling cost (In Lakhs)				,%s ",n++,DcrTrgIncrCosts);fflush(fd);
							fprintf(fd,"\n%d,Perceived Value (Rs)				,%s",n++,DcrPreValues); fflush(fd);
							fprintf(fd,"\n%d,Is there any geometry	change in part?			,%s",n++,Chingmt); fflush(fd);
							fprintf(fd,"\n%d,Current material thickness	,%s",n++,CurrMatthikness);fflush(fd);
							fprintf(fd,"\n%d,Current raw material			,%s",n++,CurrRawMatV);fflush(fd);
							fprintf(fd,"\n%d,Current weight of part		,%s",n++,Currentwt);fflush(fd);
							fprintf(fd,"\n%d,Any change in Supplier?				,%s",n++,Asuppchange); fflush(fd);fflush(fd);
							fprintf(fd,"\n%d,Current supplier				,%s",n++,Currentsupp);fflush(fd);
							fprintf(fd,"\n%d,Any change in part manufacturing process? ,%s",n++,Chmfgpro);fflush(fd);
							fprintf(fd,"\n%d,Describe the changes in process				,%s",n++,Deschpro);fflush(fd);
							fprintf(fd,"\n%d,Total Impact (Capex) in Lakhs.			,%s",n++,capexLk);fflush(fd);	
							fprintf(fd,"\n%d,Extra Service Cost (Rs)				,%s",n++,DcrExSvrcCosts);fflush(fd);
							fprintf(fd,"\n%d,Extra Service Time (Single Man Hour)				,%s ",n++,DcrExSvrcTimes); fflush(fd);
							fprintf(fd,"\n%d,Interchangeability Impact			,%s",n++,DcrInterImpacts);fflush(fd);
							fprintf(fd,"\n%d,Serviceability Impact				,%s",n++,DcrServicImpcts); fflush(fd);

							fprintf(fd,"\n\n,--IMPACT ANALYSIS--\n");

							int p = 0;
							fprintf(fd,"\nSr No,Part No,Part Descriptio, Add/Del/Mod ,Weight increase/decrease(gm),COC Remark,DFMEA severity , Is part procurable?, Validation Impact,Car Make Buy ");
							GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
							GRM_list_secondary_objects_only(rev_tag,relation_type,&cnt,&dcr_task);
							printf("\n Task found impacted items : %d\n",cnt);fflush(stdout);
							for(i= 0; i< cnt; i++)
							{
								if(AOM_ask_value_string(dcr_task[i],"object_name",&objectname));
								printf("\n DCR Task name is : %s\n",objectname);fflush(stdout);
								

								GRM_find_relation_type("T5_DcrTskPrt",&relationtype);
								GRM_list_secondary_objects_only(dcr_task[i],relationtype,&tskprtcount,&dcrprts);
								printf("\n [%d] parts are there in DCR Task : %s\n",tskprtcount,objectname);fflush(stdout);
								
								if(tskprtcount > 0)
								{
									fprintf(fd,"\n,--%s--",objectname);
									printf("\n parts in DCR Task : [%s]\n",objectname);fflush(stdout);
									for(j=0; j < tskprtcount; j++)
									{
										p++;

										AOM_ask_value_string(dcrprts[j],"item_id",&partID);
										AOM_UIF_ask_value(dcrprts[j],"item_revision_id",&revision_id);
										printf("\n %d> part [%s] in DCR Task : [%s]\n",p,partID,objectname);fflush(stdout);
										//AOM_ask_value_string(dcrprts[j],"IMAN_master_form_rev",&partNo);
										tc_strcpy(partNo,partID);
										tc_strcat(partNo,"/");
										tc_strcat(partNo,revision_id);
										AOM_ask_value_string(dcrprts[j],"current_desc",&partdesc);
										strrpl(partdesc);

										AOM_UIF_ask_value(dcrprts[j],"t5_CarMakeBuyIndicator",&CarMakeby);

										GRM_find_relation(dcr_task[i],dcrprts[j],relationtype,&relationofpart);
										if(relationofpart != NULLTAG)
										{
											AOM_UIF_ask_value(relationofpart,"t5_ModDetails",&moddetails);
											AOM_UIF_ask_value(relationofpart,"t5_DcrCapImp",&wtchng);
											AOM_UIF_ask_value(relationofpart,"t5_CocRem",&cocrmk);
											strrpl(cocrmk);
											AOM_UIF_ask_value(relationofpart,"t5_DFMSev",&DFMSever);
											AOM_UIF_ask_value(relationofpart,"t5_DcrPrcuPrt",&PrtPrcub);
											AOM_UIF_ask_value(relationofpart,"t5_ValImpact",&ValImpt);
											
											fprintf(fd,"\n%d,%s,%s,%s,%s,%s,%s,%s,%s,%s",p,partNo,partdesc,moddetails,wtchng,cocrmk,DFMSever,PrtPrcub,ValImpt,CarMakeby);
										}
										else
										{
											printf("\n Part to DCR task relation properties not found for: %s & task : %s \n",partID,objectname);fflush(stdout);
										}
									}

								}

							}
							ITK_CALL(EPM_get_current_job(rev_tag,&job,&job_type));
							printf("\nafter job\n"); fflush(stdout);							

							if (job != NULLTAG)
							{
								ITK_CALL(EPM_ask_root_task(job,&roottask));
								ITK_CALL(EPM_ask_sub_tasks(roottask,&taskcount,&subtasks));

								ITK_CALL(AOM_UIF_ask_value(roottask,"object_name",&nameofroot));
								printf("\n inside %s \n",nameofroot);

								if(tc_strcmp(nameofroot,"DCR Workflow Template")==0)
								{
									if (taskcount>0)
									{
										for(j=0;j<taskcount;j++)
										{
											wftask = subtasks[j]; 
											ITK_CALL(AOM_UIF_ask_value(wftask,"object_name",&wftaskname));
											printf("\nDCR task name", wftaskname);fflush(stdout);

											if (tc_strcmp(wftaskname,"DCR CAB L1 Review") == 0)
											{
												printf("\n Inside the CAB 1 task of DCR [%s]", dcrNumber);fflush(stdout);
												ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&cab1per));
												ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&CAB1comt));
												strrpl(CAB1comt);
												printf("\n CAB2 reviewer :[%s]Comment: [%s]", cab1per,CAB1comt);fflush(stdout);
											}
											else if (tc_strcmp(wftaskname,"DCR CAB L2 Review") == 0)
											{
												printf("\n Inside the CAB 1 task of DCR [%s]", dcrNumber);fflush(stdout); 
												ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&cab2per));
												ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&CAB2comt));
												strrpl(CAB2comt);
												printf("\n CAB2 reviewer :[%s]Comment: [%s]", cab2per,CAB2comt);fflush(stdout);
											}
											else if (tc_strcmp(wftaskname,"Input AQ Values") == 0)
											{
												printf("\n Inside the 'Input AQ Values' task of DCR [%s]", dcrNumber);fflush(stdout);
												ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&aq_per));
												ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&aq_rem));
												strrpl(aq_rem);
												printf("\n AQ Comment: [%s] performer [%s]", aq_rem,aq_per);fflush(stdout);
											}
											else if (tc_strcmp(wftaskname,"Input CS Values") == 0)
											{
												printf("\n Inside the 'Input CS Values' task of DCR [%s]", dcrNumber);fflush(stdout);
												ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&cs_rem));
												ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&cs_per));
												strrpl(cs_rem);
												printf("\n CS Comment: [%s] performer [%s]", cs_rem,cs_per);fflush(stdout);
											}
											else if (tc_strcmp(wftaskname,"Input QA/FMQ Values") == 0)
											{
												printf("\n Inside the 'Input QA/FMQ Values' task of DCR [%s]", dcrNumber);fflush(stdout);
												ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&qa_rem));
												ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&qa_per));
												strrpl(qa_rem);
												printf("\n QA/FMQ Comment: [%s] performer [%s]", qa_rem,qa_per);fflush(stdout);
											}
											else if (tc_strcmp(wftaskname,"Input TVM Values") == 0)
											{
												printf("\n Inside the 'Input TVM Values' task of DCR [%s]", dcrNumber);fflush(stdout);
												ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&tvm_rem));
												ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&tvm_per));
												strrpl(tvm_rem);
												printf("\n TVM Comment: [%s] performer [%s]", tvm_rem, tvm_per);fflush(stdout);
											}
											else if (tc_strcmp(wftaskname,"Input TS Values") == 0)
											{
												printf("\n Inside the 'Input TS Values' task of DCR [%s]", dcrNumber);fflush(stdout);
												ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&ts_rem));
												ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&ts_per));
												strrpl(ts_rem);
												printf("\n TS Comment: [%s] performer [%s]", ts_rem,ts_per);fflush(stdout);
											}
											else if (tc_strcmp(wftaskname,"Input VEM Values") == 0)
											{
												printf("\n Inside the 'Input VEM Values' task of DCR [%s]", dcrNumber);fflush(stdout);
												ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&vem_rem));
												ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&vem_per));
												strrpl(vem_rem);
												printf("\n VEM Comment: [%s] performer [%s]", vem_rem, vem_per);fflush(stdout);
											}
											else if (tc_strcmp(wftaskname,"Input VPG Values") == 0)
											{
												printf("\n Inside the 'Input VPG Values' task of DCR [%s]", dcrNumber);fflush(stdout);
												ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&vpg_rem));
												ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&vpg_per));
												strrpl(vpg_rem);
												printf("\n VPG Comment: [%s] performer [%s]", vpg_rem, vpg_per);fflush(stdout);
											}
										}
									}
								} 
							}


							fprintf(fd,"\n\n,--Affected Agencies feedback: (As Applicable)--\n");
							fprintf(fd,"\n%d,TS Reviewer					,%s",n++,ts_per);fflush(fd);
							fprintf(fd,"\n%d,TS Remarks					,%s",n++,ts_rem);fflush(fd);
							fprintf(fd,"\n%d,AQ Reviewer					,%s",n++,aq_per);fflush(fd);
							fprintf(fd,"\n%d,AQ Remarks					,%s",n++,aq_rem);fflush(fd);
							fprintf(fd,"\n%d,TVM Reviewer					,%s",n++,tvm_per);fflush(fd);
							fprintf(fd,"\n%d,TVM Remarks					,%s",n++,tvm_rem);fflush(fd);
							fprintf(fd,"\n%d,CS Reviewer					,%s",n++,cs_per);fflush(fd);
							fprintf(fd,"\n%d,CS Remarks					,%s",n++,cs_rem);fflush(fd);
							fprintf(fd,"\n%d,QA/FMQ Reviewer				,%s",n++,qa_per);fflush(fd);
							fprintf(fd,"\n%d,QA/FMQ Remarks				,%s",n++,qa_rem);fflush(fd);
							fprintf(fd,"\n%d,VEM Reviewer					,%s",n++,vem_per);fflush(fd);
							fprintf(fd,"\n%d,VEM Remarks					,%s",n++,vem_rem);fflush(fd);
							fprintf(fd,"\n%d,VPG Reviewer					,%s",n++,vpg_per);fflush(fd);
							fprintf(fd,"\n%d,VPG Remarks					,%s",n++,vpg_rem);fflush(fd);
							fprintf(fd,"\n%d,Chief Engineer					,%s",n++,cab1per);fflush(fd);
							fprintf(fd,"\n%d,Program Manager					,%s",n++,cab2per);fflush(fd);
							fprintf(fd,"\n%d,Input from CAB1					,%s",n++,CAB1comt);fflush(fd);
							fprintf(fd,"\n%d,Input from CAB2					,%s",n++,CAB2comt);fflush(fd);



							//printf("\n%d,Date of approval					,%s",n++,vpg_rem); fflush(stdout);


							//fprintf(fd,"\n%d,DCR Rlease Status				,%s",n++,dcrStatus); fflush(fd);
							//fprintf(fd,"\n%d,DCR Name					,%s",n++,dcrName);fflush(fd);
							//fprintf(fd,"\n%d,DCR Revision					,%s",n++,dcrRevision);fflush(fd);
							//fprintf(fd,"\n%d,Affected Item					,%s",n++,AffectedItem);fflush(fd);
							//fprintf(fd,"\n%d,Approver Name					,%s",n++,ApproverTD);fflush(fd);
							//fprintf(fd,"\n%d,Category of Change				,%s",n++,CatOfChange);fflush(fd);
	
							//fprintf(fd,"\n%d,D and D (TimeLine) in Months	,%s",n++,DnDInMonths);fflush(fd);
							//fprintf(fd,"\n%d,Date Project Assignment Modified		,%s",n++,Dt_pro_Amodifi);fflush(fd);
							//fprintf(fd,"\n%d,Date Released					,%s",n++,Dt_relea); fflush(fd);fflush(fd);
							
							//fprintf(fd,"\nDesign Group					,%s",n++,Desig_grp);fflush(fd);
							//fprintf(fd,"\n%d,Details of Category of Change			,%s",n++,Dets_cat_chg);fflush(fd);
							//fprintf(fd,"\n%d,Digital Signature State		,%s",n++,SignStatus);fflush(fd);
							//fprintf(fd,"\n%d,Disposition					,%s",n++,Disposit);fflush(fd);
							//fprintf(fd,"\n%d,Envelop Dimensions			,%s",n++,EnvDimensions);fflush(fd);
							//fprintf(fd,"\n%d,Green Report / FIR Applicable ?			,%s",n++,DcrGrnRptFIRAvails);fflush(fd);
							////fprintf(fd,"\n%d,Location						,%s",n++,dcr_loct);fflush(fd);
							//fprintf(fd,"\n%d,Material						,%s",n++,dcr_matr);fflush(fd);
							//fprintf(fd,"\n%d,Maturity					,%s",n++,matur_);fflush(fd);
							//fprintf(fd,"\n%d,May be checked-out			,%s",n++,may_chkOtBy);fflush(fd);
							//fprintf(fd,"\n%d,Mfg. Time (In Months)				,%s",n++,DcrMfgTimes);fflush(fd);
							//fprintf(fd,"\n%d,Multifield Key Information			,%s",n++,mul_k_info);fflush(fd);
							//fprintf(fd,"\n%d,My Workflow Tasks				,%s",n++,workflow_task);fflush(fd);
							//fprintf(fd,"\n%d,Object						,%s",n++,objects_);fflush(fd);
							//fprintf(fd,"\n%d,Object Cell Properties		,%s",n++,OC_Prop); fflush(fd);
							//fprintf(fd,"\n%d,Owning Project				,%s",n++,owng_pro);fflush(fd);
							//fprintf(fd,"\n%d,P & SC Category				,%s",n++,pnsc_cat);fflush(fd);
							//fprintf(fd,"\n%d,Participants					,%s",n++,particip_);fflush(fd);
							//fprintf(fd,"\n%d,Participants To Display		,%s",n++,particip_disp);fflush(fd);
							//fprintf(fd,"\n%d,Plans							,%s",n++,plans_);fflush(fd);
							//fprintf(fd,"\n%d,Problems						,%s",n++,probms);fflush(fd);
							//fprintf(fd,"\n%d,Problems Modifiable			,%s",n++,probs_modif);fflush(fd);
							//fprintf(fd,"\n%d,Process						,%s",n++,me_proc);fflush(fd);
							//fprintf(fd,"\n%d,Process Stage					,%s",n++,proce_stg);fflush(fd);
							//fprintf(fd,"\n%d,Process Stage List			,%s",n++,proce_stg_lst);fflush(fd);
							//fprintf(fd,"\n%d,Program Applicability				,%s",n++,Pro_appli); fflush(fd);
							//fprintf(fd,"\n%d,Project ID					,%s",n++,proj_id);fflush(fd);
							//fprintf(fd,"\n%d,Project IDs					,%s",n++,proj_ids);fflush(fd);
							//fprintf(fd,"\n%d,Project Objects					,%s",n++,proj_obj);fflush(fd);
							//fprintf(fd,"\n%d,Project_ID					,%s",n++,projID_);fflush(fd);
							//fprintf(fd,"\n%d,Projects						,%s",n++,projects_);fflush(fd);
							//fprintf(fd,"\n%d,Protection					,%s",n++,protn);fflush(fd);
							//fprintf(fd,"\n%d,Reference Item				,%s",n++,ref_itm);fflush(fd);
							//fprintf(fd,"\n%d,References					,%s",n++,refrncs);fflush(fd);
							//fprintf(fd,"\n%d,References Modifiable			,%s",n++,ref_modifabl);fflush(fd);
							//fprintf(fd,"\n%d,Regulation Number				,%s",n++,regl_nmb);fflush(fd);
							//fprintf(fd,"\n%d,Relations to Auto-propagate on Derive			,%s",n++,rel_Aprop);fflush(fd);
							//fprintf(fd,"\n%d,Release Status				,%s",n++,dcrStatus);fflush(fd);
							//fprintf(fd,"\n%d,Requestor						,%s",n++,requstr);fflush(fd);
							//fprintf(fd,"\n%d,Requestor						,%s",n++,requstr_);fflush(fd);
							//fprintf(fd,"\n%d,Requestor User ID				,%s",n++,req_id_);fflush(fd);
							//fprintf(fd,"\n%d,Revision					,%s",n++,dcrRevision);fflush(fd);
							//fprintf(fd,"\n%d,Revisions						,%s",n++,revignsID);fflush(fd);
							//fprintf(fd,"\n%d,Sequence ID					,%s",n++,sq_id);fflush(fd);
							//fprintf(fd,"\n%d,Sequence Limit				,%s",n++,sq_lmt);fflush(fd);
							//fprintf(fd,"\n%d,Started Workflow Tasks		,%s",n++,strWFtsk);fflush(fd);
							//fprintf(fd,"\n%d,Sub Aggregate					,%s",n++,SubAggr);fflush(fd);
							//fprintf(fd,"\n%d,Sub Category					,%s",n++,Sun_cata);fflush(fd);
							//fprintf(fd,"\n%d,Total Impact (DMC) in Rs.		,%s",n++,DMC_inR);fflush(fd);
							//fprintf(fd,"\n%d,Type						,%s",n++,Obje_Typ); fflush(fd);
							//fprintf(fd,"\n%d,User Can Unmanage				,%s",n++,usr_cn_unma);fflush(fd);
							//fprintf(fd,"\n%d,User Rating Value				,%s",n++,usr_rat_val);fflush(fd);
							//fprintf(fd,"\n%d,VC No							,%s",n++,VC_numb); fflush(fd);
							//fprintf(fd,"\n%d,Vehicle Classification		,%s",n++,veh_calsifi);fflush(fd);
							//fprintf(fd,"\n%d,Vehicle For					,%s",n++,vehic_for);fflush(fd);
							//fprintf(fd,"\n%d,Version Limit					,%s",n++,versi_ltd);fflush(fd);
							//fprintf(fd,"\n%d,Weight Impact					,%s",n++,weitimp);fflush(fd);
							
							
							//fprintf(fd,"\nAlias IDs					\t%s",AliasID);
							//fprintf(fd,"\nAll Workflows				\t%s",AllWorkflows);
							//fprintf(fd,"\nAlternate IDs				\t%s",AlterID);
							//fprintf(fd,"\nAltreps					\t%s",Altreps);
							//fprintf(fd,"\nAnalyst					\t%s",Analt);
							//fprintf(fd,"\nAnalyst					\t%s",Analst);
							//fprintf(fd,"\nAnalyst User ID			\t%s",AnalystUsrID);
							
							/*fprintf(fd,"\nAttaches					\t%s",Attaches);
							fprintf(fd,"\nAttribute Override		\t%s",AttribOveride);
							fprintf(fd,"\nAuthoring Change			\t%s",AthoriChange);
							fprintf(fd,"\nAuthorizing Paragraph		\t%s",AthoriPara);
							fprintf(fd,"\nAuto-propagate Relations	\t%s",AutoPropoRel);
							fprintf(fd,"\nAverage Ratings			\t%s",AvgRating);
							//fprintf(fd,"\nBOM Rollup\t%s",BOMrollup);
							//fprintf(fd,"\nBOM View Revisions\t%s",BOMviewRevi);
							//fprintf(fd,"\nBOM rollup accuracy (asserted)\t%s",BOMrollupAcc);
							//fprintf(fd,"\nBOM rollup center of mass x\t%s",BOMcgiX);
							//fprintf(fd,"\nBOM rollup center of mass y\t%s",BOMcgiY);
							//fprintf(fd,"\nBOM rollup center of mass z\t%s",BOMcgiZ);
							//fprintf(fd,"\nBOM rollup mass\t%s",BOMrollMass);
							//fprintf(fd,"\nBOM rollup moment of inertia xx\t%s",BOMxx);
							//fprintf(fd,"\nBOM rollup moment of inertia yy\t%s",BOMyy);
							//fprintf(fd,"\nBOM rollup moment of inertia zz\t%s",BOMzz);
							//fprintf(fd,"\nBOM rollup moment of inertia xy\t%s",BOMxy);
							//fprintf(fd,"\nBOM rollup moment of inertia xz\t%s",BOMxz);
							//fprintf(fd,"\nBOM rollup moment of inertia yz\t%s",BOMyz);
							//fprintf(fd,"\nBased On\t%s",BsdOn);
							//fprintf(fd,"\nBased On Relation\t%s",BsdOnRel);
							fprintf(fd,"\nBreaks Down Into Plan Items	%s",BkdwnPlntItm);
							fprintf(fd,"\nBudget Relation			\t%s",Budg_Rel);
							//fprintf(fd,"\nC3D_View\t%s",C3Dview);
							fprintf(fd,"\nCAE Analysis				\t%s",CAE_Analysis);
							//fprintf(fd,"\nCAE Criteria Relationship\t%s",CAE_Crite);
							//fprintf(fd,"\nCAE Defining Relationship\t%s",CAE_Def);
							//fprintf(fd,"\nCAE Include Relationship\t%s",CAE_Incl);
							//fprintf(fd,"\nCAE Parameter Relationship\t%s",CAE_Para);
							//fprintf(fd,"\nCAE Results Relationship\t%s",CAE_Res);
							//fprintf(fd,"\nCAE Source Relationship\t%s",CAE_Sou_Rel);
							//fprintf(fd,"\nCAE Target Relationship\t%s",CAE_Tgt);
							fprintf(fd,"\nCapture					\t%s",Capt);
							fprintf(fd,"\nCat2AssyConfigLink		\t%s",AsyConfRel);*/
							
							//fprintf(fd,"\nChange					\t%s",chang);
							//fprintf(fd,"\nChange Contributors		\t%s",chngContri);
							//fprintf(fd,"\nChange Implementation Board	%s",chngImpBord);
							//fprintf(fd,"\nChange References			\t%s",chngRefes);
							//fprintf(fd,"\nChange Review Board		\t%s",chngRevBod);
							//fprintf(fd,"\nChange Specialist I\t%s",chngSplst1);
							//fprintf(fd,"\nChange Specialist I User ID\t%s",chngSplst1_user_id);
							//fprintf(fd,"\nChange Specialist II\t%s",chngSplst2);
							//fprintf(fd,"\nChange Specialist II User ID\t%s",chngSplst2_user_id);
							//fprintf(fd,"\nChange Specialist III\t%s",chngSplst3);
							//fprintf(fd,"\nChange Specialist III User ID\t%s",chngSplst3_user_id);
							
							//fprintf(fd,"\nChecked-Out\t%s",checkedO);
							//fprintf(fd,"\nChecked-Out By\t%s",checkedOBy);
							//fprintf(fd,"\nChecked-Out Change Id\t%s",checkedOChID);
							//fprintf(fd,"\nChecked-Out Date\t%s",checkedODT);
							//fprintf(fd,"\nChild Item Revisions\t%s",childIDRev);
							//fprintf(fd,"\nChild Validation Result\t%s",childValResult);
							/*fprintf(fd,"\nClassifications			\t%s",Classifi);
							fprintf(fd,"\nClassified				\t%s",Classifed);
							fprintf(fd,"\nClassified in				\t%s",ClassifedIn);
							fprintf(fd,"\nClosure					\t%s",Closure_);
							//fprintf(fd,"\nClosure Comments\t%s",Closure_Comm);
							//fprintf(fd,"\nClosure Date\t%s",Closure_Dat);
							//fprintf(fd,"\nCommentary\t%s",Commtry);
							//fprintf(fd,"\nComplying Objects\t%s",Comp_obj);
							//fprintf(fd,"\nConfigured Drawings\t%s",Config_dwg);
							//fprintf(fd,"\nConfigured Revision\t%s",Config_rev);
							//fprintf(fd,"\nConnector Table Form Relation\t%s",connTab_rev);
							fprintf(fd,"\nContacts					\t%s",contcs);
							
							fprintf(fd,"\nCurrent Change Context	\t%s",Cor_cg_cont);
							fprintf(fd,"\nCurrent Description		\t%s",corrDesc);
							fprintf(fd,"\nCurrent ID				\t%s",CorrtID);
							fprintf(fd,"\nCurrent Location Code		\t%s",Corr_Loc_code);
							fprintf(fd,"\nCurrent Name				\t%s",Corrnt_name);
							fprintf(fd,"\nCurrent Revision			\t%s",Corr_rev_ID);
							//fprintf(fd,"\nCustom Requirements Lists\t%s",Cust_req_Lst);
							fprintf(fd,"\nCustomers					\t%s",custommr);*/
							
							/*fprintf(fd,"\nDCR CS					\t%s",DCR_CS);
							fprintf(fd,"\nDCR Description			\t%s",Obj_Desc);
							fprintf(fd,"\nDCR FMQ					\t%s",DCR_FMQ);
							fprintf(fd,"\nDCR Name					\t%s",dcrName);
							fprintf(fd,"\nDCR No					\t%s",dcrNumber);
							fprintf(fd,"\nDCR PPM					\t%s",DCR_PPM);
							fprintf(fd,"\nDCR PRP1					\t%s",DCR_PRP1);
							fprintf(fd,"\nDCR PRP2					\t%s",DCR_PRP2);
							fprintf(fd,"\nDCR TS					\t%s",DCR_TS);
							fprintf(fd,"\nDCR TVM					\t%s",DCR_TVM);
							fprintf(fd,"\nDCR VEM					\t%s",DCR_VEM);
							fprintf(fd,"\nDCR VPG					\t%s",DCR_VPG);
							//fprintf(fd,"\nDate Archived\t%s",Achivd_date);
							//fprintf(fd,"\nDate Last Backup\t%s",bkup_date);
							fprintf(fd,"\nDate Modified				\t%s",Dt_modifi);*/
							
							//fprintf(fd,"\nDeclared Options\t%s",Declard_optio);
							//fprintf(fd,"\nDefining Objects\t%s",defning_obj);
							//fprintf(fd,"\nDerivable Types\t%s",DarivbTypes);
							//fprintf(fd,"\nDesign BOM Relation\t%s",Des_BOM_rel);
							
							//fprintf(fd,"\nDiagram Root Relation\t%s",Dig_root_rel);
							//fprintf(fd,"\nDiagram Snapshot\t%s",Diag_snp);
							//fprintf(fd,"\nDiagram Template Relation\t%s",Dig_tmp_rel);
							//fprintf(fd,"\nDigital Signature Audit Logs\t%s",SignAuditLog_);
							
							//fprintf(fd,"\nDisclosed Model Views\t%s",Dis_Mod_View);
							//fprintf(fd,"\nDisclosed View List\t%s",Dis_View_lst);
							//fprintf(fd,"\nDisclosing Object\t%s",Dislo_Obj);
							//fprintf(fd,"\nDisplay Default ID\t%s",Dis_Def_ID);
							
							//fprintf(fd,"\nDisposition Comments\t%s",Disposit_comm);
							//fprintf(fd,"\nDisposition Date\t%s",Dispo_Date);
							//fprintf(fd,"\nDisposition Page\t%s",Doc_Page);
							//fprintf(fd,"\nDrawings\t%s",Dwgs);
							//fprintf(fd,"\nEC Snapshots\t%s",EC_Snap);
							//fprintf(fd,"\nEffectivity\t%s",Effecti);
							
							//fprintf(fd,"\nEnvironment Description\t%s",Env_Desc);
							//fprintf(fd,"\nExCO - Explore Checked-Out\t%s",Explo_chkO);
							//fprintf(fd,"\nExported (proxied) To\t%s",ExportedTo);
							//fprintf(fd,"\nExported To\t%s",Expoted_To);
							//fprintf(fd,"\nExternal Proxy Relation\t%s",Ext_proxy_rel);
							//fprintf(fd,"\nFMS Tickets\t%s",fms_tkts);
							
							/*fprintf(fd,"\nFollowers					\t%s",Followers_D);
							fprintf(fd,"\nFound Helpful				\t%s",Found_Help);
							fprintf(fd,"\nGeneric Architecture		\t%s",Generi_archi);
							fprintf(fd,"\nGeneric Component Updated	\t%s\nFrom",Gen_comp_updated);
							fprintf(fd,"\nGovernment Classification	\t%s",Gove_certifi);
							fprintf(fd,"\nGroup ID					\t%s",Group_ID);
							//fprintf(fd,"\nHas CAE Folders\t%s",Has_CAE_Fold);
							fprintf(fd,"\nHas Module?				\t%s",Has_Module);
							fprintf(fd,"\nHas Tracelink				\t%s",Has_trace_lk);
							fprintf(fd,"\nHas Variants				\t%s",Has_Varient);
							fprintf(fd,"\nHas Weld Parts			\t%s",Has_Weld_prt);
							fprintf(fd,"\nID						\t%s",ID_);
							//fprintf(fd,"\nIFRL\t%s",ifrl_);
							//fprintf(fd,"\nIP Classification\t%s",IP_classifi);
							fprintf(fd,"\nIP Logged					\t%s",IP_logged);
							fprintf(fd,"\nImpacted					\t%s",Impacted_);
							fprintf(fd,"\nImpacts					\t%s",impacts_);
							fprintf(fd,"\nImplemented By			\t%s",Impliment_by);
							fprintf(fd,"\nImplements				\t%s",impliments_);
							fprintf(fd,"\nIn Process				\t%s",In_Process);
							//fprintf(fd,"\nIncorporates\t%s",Incorpora);
							//fprintf(fd,"\nIntent Text\t%s",Intent_txt);
							//fprintf(fd,"\nInterpart Equations\t%s",inter_equ);
							//fprintf(fd,"\nInterpart Links\t%s",inter_link);
							//fprintf(fd,"\nIs Described By Document\t%s",Desc_by_doc);
							fprintf(fd,"\nIs Modifiable				\t%s",is_modified);
							//fprintf(fd,"\nIs Revision Discontinued\t%s",is_rev_discont);
							//fprintf(fd,"\nIs Suspect\t%s",is_suspe);
							fprintf(fd,"\nIs VI?					\t%s",is_vi_);
							fprintf(fd,"\nItem						\t%s",itm_);
							fprintf(fd,"\nItem Masters				\t%s",itm_mster);
							//fprintf(fd,"\nItem Revision Definition Configuration Used\t%s",itm_DefConig);
							fprintf(fd,"\nItem Revision Definition	\t%s\n Configured?",is_itemRDC);
							//fprintf(fd,"\nItem has Module?\t%s",has_var_mod);
							fprintf(fd,"\nLast Modifying User		\t%s",lst_mod_user);*/
							//fprintf(fd,"\nMating Constraints\t%s",mat_const);
							//fprintf(fd,"\nLocations\t%s",dcr_loctns);
							//fprintf(fd,"\nMESetup\t%s",ME_setup);
							//fprintf(fd,"\nLicense List\t%s",licenList);
							//fprintf(fd,"\nProposal\t%s",proposalE);
							//fprintf(fd,"\nProposed Responsible Party\t%s",prop_resp_prty);
							//fprintf(fd,"\nProposed Reviewers\t%s",prop_revever);
							//fprintf(fd,"\nPublished To\t%s",publish_by);
							//fprintf(fd,"\nRatings\t%s",ratgs);
							//fprintf(fd,"\nRegulation Number\t%s",regul_nmb);
							//fprintf(fd,"\nRelated FMEA's\t%s",reltd_fmea);
							//fprintf(fd,"\nRendering\t%s",rendrng);
							//fprintf(fd,"\nRepresentation For\t%s",reprntFr);
							//fprintf(fd,"\nRequired Participants\t%s",reqst_prt);
							//fprintf(fd,"\nRequirements\t%s",reqrtmn);
							//fprintf(fd,"\nResource Site Data Relation\t%s",resoSitRel);
							//fprintf(fd,"\nReuse Assembly\t%s",reu_asmb);
							//fprintf(fd,"\nSequence Of Events\t%s",seqEvnt);
							//fprintf(fd,"\nSeverity Rating\t%s",seveRtng);
							//fprintf(fd,"\nShape Relation\t%s",shpreln);
							//fprintf(fd,"\nSimplifiedRendering\t%s",simpliRndr);
							//fprintf(fd,"\nSnapshot\t%s",snpshot);
							//fprintf(fd,"\nSolution Item\t%s",solunitm);
							//fprintf(fd,"\nSolution Variant Item Configuration\t%s",sol_itmvarconf);
							//fprintf(fd,"\nSolution Variant Source\t%s",sol_var_rep);
							//fprintf(fd,"\nSolutions\t%s",sulon);
							//fprintf(fd,"\nSpatial Rendering\t%s",spatialR);
							//fprintf(fd,"\nSpecialist\t%s",specialist);
							//fprintf(fd,"\nSpecifications\t%s",specifqn);
							//fprintf(fd,"\nStatic Snapshot\t%s",stat_snp);
							//fprintf(fd,"\nSequence Info\t%s",sq_inf);
							//fprintf(fd,"\nSend To\t%s",sndTo);
							/*fprintf(fd,"\nT5_APLAView\t%s",Aplav);
							fprintf(fd,"\nT5_APLCView\t%s",Aplcv);
							fprintf(fd,"\nT5_APLDView\t%s",Apldv);
							fprintf(fd,"\nT5_APLJView\t%s",Apljv);
							fprintf(fd,"\nT5_APLLView\t%s",Apllv);
							fprintf(fd,"\nT5_APLPView\t%s",Aplpv);
							fprintf(fd,"\nT5_APLSView\t%s",Aplsv);
							fprintf(fd,"\nT5_APLUView\t%s",Apluv);
							fprintf(fd,"\nT5_APLVView\t%s",Aplvv);
							fprintf(fd,"\nT5_DFMA\t%s",Dfmat5);
							fprintf(fd,"\nT5_STDAView\t%s",STDav);
							fprintf(fd,"\nT5_STDCView\t%s",STDcv);
							fprintf(fd,"\nT5_STDDView\t%s",STDdv);
							fprintf(fd,"\nT5_STDJView\t%s",STDjv);
							fprintf(fd,"\nT5_STDLView\t%s",STDlv);
							fprintf(fd,"\nT5_STDPView\t%s",STDpv);
							fprintf(fd,"\nT5_STDSView\t%s",STDsv);
							fprintf(fd,"\nT5_STDUView\t%s",STDuv);
							fprintf(fd,"\nT5_STDVView\t%s",STDvv);
							fprintf(fd,"\nTC Product Manual\t%s",TCprodManul);
							fprintf(fd,"\nTC SST Record\t%s",sst_rcd);
							fprintf(fd,"\nTCEng_rdv_plmxml_configured\t%s",xml_confi);
							fprintf(fd,"\nTCEng_rdv_plmxml_unconfigured\t%s",xml_unconfi);
							fprintf(fd,"\nTags\t%s",tges);
							fprintf(fd,"\nTags From Summary\t%s",tgsFrSummry);
							fprintf(fd,"\nTechnical Review Priority\t%s",TechRevPrio);
							fprintf(fd,"\nThumbnail\t%s",Thmbnl);
							fprintf(fd,"\nThumbnail Source\t%s",Thmbnl_sor);
							fprintf(fd,"\nTotal Answered\t%s",Totl_ans);
							fprintf(fd,"\nTotal Comments\t%s",Totl_Comm);
							fprintf(fd,"\nTotal Experiences\t%s",Totl_Comm);
							fprintf(fd,"\nTotal Follows\t%s",Totl_flw);
							fprintf(fd,"\nTotal Questions\t%s",Totl_Que);
							fprintf(fd,"\nTotal Ratings\t%s",Totl_Ratn);
							fprintf(fd,"\nTrace Link\t%s",TrcLnk);
							fprintf(fd,"\nUG Expressions\t%s",ug_exps);
							fprintf(fd,"\nUG Promotions\t%s",ug_pro);
							fprintf(fd,"\nUG Scenarios\t%s",ug_scen);
							fprintf(fd,"\nUG UDFs\t%s",ug_udf);
							fprintf(fd,"\nUG WAVE Geometry\t%s",ug_wavGeo);
							fprintf(fd,"\nUG WAVE Part Links\t%s",ug_wav_prt_lnk);
							fprintf(fd,"\nUG WAVE Positions\t%s",ug_wav_pos);
							fprintf(fd,"\nUsed Options\t%s",usd_potns);*/
							/*fprintf(fd,"\nVC Has Estimate Doc\t%s",vchasESTdoc);
							fprintf(fd,"\nValidation\t%s",TC_Valida);
							fprintf(fd,"\nVendor Representation\t%s",vend_reprs);
							fprintf(fd,"\nVerification\t%s",veri_fic);*/
							/*fprintf(fd,"\nVersion Number\t%s",verg_numb);
							fprintf(fd,"\nView\t%s",view_);
							fprintf(fd,"\nView Capture\t%s",view_capt);
							fprintf(fd,"\nVisMarkup\t%s",Vizmok);
							fprintf(fd,"\nVisSession\t%s",VizSess);
							fprintf(fd,"\nWeight Impact Value(In gms)\t%s",weitimp_val);
							fprintf(fd,"\nWork Context\t%s",wrkContRel);
							fprintf(fd,"\nWork Instructions\t%s",wkrinstr);
							fprintf(fd,"\nWorking Environment\t%s",wrkngEnvi);
							fprintf(fd,"\nWorkspace Object Thread\t%s",wsObjthr);
							fprintf(fd,"\na4_MTBF\t%s",mtbf);
							fprintf(fd,"\ncatia\t%s",catia3D);
							fprintf(fd,"\ncatia_alternateShapeRep\t%s",cat_altershap);
							fprintf(fd,"\ncatia_auxiliaryLink\t%s",cat_Aux_lnk);
							fprintf(fd,"\ncatia_cache_link\t%s",cat_cht_lk);
							fprintf(fd,"\ncatia_componentShapeRep\t%s",cat_comp_shape);
							fprintf(fd,"\ncatia_external_link\t%s",cat_ext_lnk);
							fprintf(fd,"\ncatia_mfgproduct_link\t%s",cat_mfg_lk);
							fprintf(fd,"\ncatia_multi_model\t%s",cat_mul_mod);
							fprintf(fd,"\ncatia_secondary_link\t%s",cat_sec_lnk);
							fprintf(fd,"\ncatia_shapeProperties_link\t%s",cat_shp_lnk);*/
							//fprintf(fd,"\n1 star\t%s",OneStar);
							//fprintf(fd,"\n2 star\t%s",TwoStar);
							//fprintf(fd,"\n2D Snapshot\t%s",TwoDsnap);
							//fprintf(fd,"\n3 star\t%s",ThreStar);
							//fprintf(fd,"\n3D Snapshot\t%s",ThreDsnap);
							//fprintf(fd,"\n4 star\t%s",FourStar);
							//fprintf(fd,"\n5 star\t%s",FiveStar);
							//fprintf(fd,"\nActuated Interactive		\t%s\nTasks",ActuatedTask);
							//fprintf(fd,"\nAddressed By				\t%s",AddresBy);
							//fprintf(fd,"\nManifestations\t%s",manifestations_);
							//fprintf(fd,"\nMeasurable Attribute\t%s",measurab_attri);
							//fprintf(fd,"\nMfg Models\t%s",mfg_model);
							//fprintf(fd,"\nModular variants language Text\t%s",mlv_txt);
							//fprintf(fd,"\nMotion\t%s",motion_);
							//fprintf(fd,"\nNX Simulations\t%s",nx_simul);
							//fprintf(fd,"\nNo Of WeldSpots\t%s",NWeldSpot);
							//fprintf(fd,"\nObjects Followed\t%s",obf_Followed);
							//fprintf(fd,"\nOwned Model Views\t%s",owend_mod_view);
							//fprintf(fd,"\nOwning Site\t%s",owng_site);
							//fprintf(fd,"\nParametric Requirements Lists\t%s",param_reqLst);
							//fprintf(fd,"\nPrevious Effectivity\t%s",prev_effe);
							//fprintf(fd,"\nProblem Item\t%s",prob_itm);
							//fprintf(fd,"\nProduct Interfaces - Geometry\t%s",pro_int_geo);
							//fprintf(fd,"\nProduct Interfaces Parameters\t%s",pro_int_para);
							//fprintf(fd,"\nOwning Organization\t%s",owng_org);
							
							
							//remove(FileDown);
							//if(FileDown) MEM_free(FileDown);
							

							printf("\nData copied in file....\n"); fflush(stdout);
							fflush(fd);
							fclose(fd);
							if (fd != NULL)
							{
								fd = NULL;
							}
							//if(GRM_find_relation_type("CMReferences",&RefRelation));
							if(GRM_find_relation_type("IMAN_reference",&RefRelation));
							if(RefRelation != NULLTAG)
							{
								printf("\nChange Reference Relation Found.");
							}
							//if(AE_find_datasettype2("Text",&TextType));
							if(AE_find_datasettype2("MSExcel",&TextType));
							if(TextType != NULLTAG)
							{
								printf("\nDataset type MSExcel Found.");
							}
							if(AE_create_dataset_with_id(TextType,attachname,"DCR Print Report",NULL,NULL,&TextDataset));
							if(TextDataset != NULLTAG)
							{
								printf("\nDataset create tag Found.");
								if(AE_save_myself(TextDataset));
							}
							
							AE_reference_type_t tagRefType;
							if(AE_set_dataset_format2(TextDataset, "BINARY_REF"));
							if(AE_set_dataset_tool(TextDataset,tool));
							AE_ask_datasettype_refs(TextType, &ref_count, &ref_list);
							IMF_import_file(FileDown,NULL, SS_BINARY, &filetag, &fileDescriptor);
							AOM_save_without_extensions(filetag);

							AE_add_dataset_named_ref2(TextDataset,ref_list[0],tagRefType,filetag);
							AE_set_dataset_tool(TextDataset,tool);
							AOM_save_without_extensions(TextDataset);
							if(GRM_create_relation(rev_tag,TextDataset,RefRelation,NULLTAG,&RefRel_t));
							if(RefRel_t != NULLTAG)
							{
								printf("\nRefRel_t tag Found.");
							}
							if(AE_save_myself(RefRel_t));
							if(GRM_save_relation(RefRel_t));
							if(AE_ask_dataset_latest_rev(TextDataset,&TextLatestDat_t));
							if(TextLatestDat_t != NULLTAG)
							{
								printf("\nTextLatestDat_t tag Found.");
							}
							if(AOM_refresh(TextLatestDat_t,TRUE));
							if(AE_import_named_ref(TextLatestDat_t,"excel",attachname,NULL,SS_BINARY));
							
							AOM_save_without_extensions(TextLatestDat_t);
							AOM_refresh(TextLatestDat_t, FALSE);
							AOM_unload(TextLatestDat_t);
							remove(attachname);
						}
						else
						{
							EMH_ask_error_text(ifail, &cError);
							printf("\n\nError is : %s \n",cError);fflush(stdout);
						}
					}
					else
					{
						EMH_ask_error_text(ifail, &cError);
						printf("\n\nError is : %s \n",cError);fflush(stdout);
					}								
				}
				else
				{
					EMH_ask_error_text(ifail, &cError);
					printf("\n\nError is : %s \n",cError);fflush(stdout);
				}
			}
			else
			{
				EMH_ask_error_text(ifail, &cError);
				printf("\n\nError is : %s \n",cError);fflush(stdout);
			}
		}

		CHECK_FAIL;

		printf("\n*********************");fflush(stdout);

		printf("\nEnd of program.....!!");fflush(stdout);
		printf("\n*********************\n");fflush(stdout);
		ifail = ITK_exit_module(true);
	}	
	return ITK_ok;
}
