/******************************************************************************
*
*------------------------------------------------------------------------------
* Filename              : DML_Report_from_specific_reviewer.c
* Description   : This Utility Mainly Used For AutoLogin in Teamcenter
* Module        :
* Since             :
* ENVIRONMENT   : C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date                  Name                                         Description of Change
* 21/02/2025            Rudresh marde                It will print the DML Number with WF name and pending user details.

* -----------------------------------------------------------------------------
*

INPUT :
Name:Change Request Life Cycle
Created After:19-Mar-2025
Created Before:20-Mar-2025

*****************************************************************************/
/******************************************************************************/
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include "unidefs.h"
#define MAX_LINE_LEN 1024
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_date.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <unidefs.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#include <tc/folder.h>
#include <bom/bom.h>
#include <epm/epm.h>
#include <time.h>
#define MAX_NAME_LENGTH 256
#define MAX_ANALYSTS_LENGTH 1024
int ITK_CALL(int Ifail)
{
        char* cError = NULL;
        int iFail = 0;
            if(iFail!=ITK_ok)
                {
                  EMH_ask_error_text(iFail, &cError);
                  printf("\n Error is : %s", cError);fflush(stdout);
                  exit(0);
                }

                return iFail;
}

int ITK_user_main(int argc, char* argv[])
{
            int iFail = 0;
            char* cError = NULL;
                char* username = NULL;
                tag_t tuser = NULLTAG;
                iFail = ITK_auto_login();
                printf("\nReturn Value is : %d", iFail);fflush(stdout);

                int n_entries = 1;
                int i,k,flag,cnt,cnt1,z=0;
                tag_t tItemobj = NULLTAG;
                tag_t itemtag  = NULLTAG;
                int n_itemobj_found = 0;
                tag_t* titemobj_results = NULLTAG;

                char *PartID = NULL;
                char *PartSequenceID = NULL;
                char *part_type = NULL;
                char *Description = NULL;
                char *object_type = NULL;
                char *Part_ProjID = NULL;
                char *Part_DesgnGrp = NULL;
                char *Revision = NULL;
                tag_t DataSet = NULLTAG;
                char *inputfile=NULL;
                char *PartRevSeqID =NULL;
                char *ItemDesc = NULL;
                char *partType  = NULL;
                char *rev_id    = NULL;
                char *PartRevSeq        = NULL;
                char *objtype1  = NULL;
                char *objtype2  = NULL;
                tag_t LatestRev = NULLTAG;
                int     n_values_bvr=0;
                tag_t   *bvr_assy_part= NULLTAG;
                tag_t* attachments = NULLTAG;
                tag_t* attachments1 = NULLTAG;
                tag_t dataset2 = NULLTAG;
                tag_t dataset3 = NULLTAG;
                tag_t relation_type2 = NULLTAG;

                tag_t itemrev = NULLTAG;
                int Part_Stat_Cnt = 0;
                tag_t *Part_Stat_Lst = NULLTAG;
                char *Part_Rlz_Stat = NULL;
                char *temp= NULL;
                temp = (char *)MEM_alloc(250);

                                int iRev_Count = 0;
                tag_t* tRevList = NULLTAG;


                tag_t child_item=NULLTAG;
                tag_t child_rev=NULLTAG;

                tag_t* tBOM_Children = NULLTAG;
                int iNumber_Child = 0;

                char* cLevel = NULL;
                char* cRev_Name = NULL;
                char* cItem_Id = NULL;
                char* cRevision = NULL;
                char* cParent = NULL;
                char* cOwn_Group = NULL;
                char* cOwn_User = NULL;
                char* cQuantity = NULL;
                char* cFind_No = NULL;
                char* cPacked = NULL;
                char* cDRAR = NULL;
                char* cPart_Type = NULL;
                char* LcsState = NULL;
                tag_t rule = NULLTAG;
                tag_t rule1 = NULLTAG;
                tag_t iteamrev2 = NULLTAG;
                char    **rulename = NULL;
                char    **rulevalue = NULL;
                tag_t   *closurerule = NULLTAG;
                int             rulefound= 0;
                tag_t   close_tag = NULLTAG;

                tag_t query = NULLTAG;
                tag_t* cntr_objects = NULLTAG;
                int entries =2;
                char *qry_entries[2]  = {"Item ID","Revision"};
                tag_t query1 = NULLTAG;
                char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));
                int n_found1=0;
                tag_t* cntr_objects1 = NULLTAG;
                char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
                int n_found=0;
                char* DesignGroup = NULL;
                char* ProjectCode = NULL;

                FILE  *output = NULL;
                char    outputFile[200] = "DML_Report_for_specific_Reviewer.csv";

                char* FromDate = NULL;
                char* ToDate = NULL;
                char* find_for_task = NULL;
                char* user_id = NULL;


                FromDate = ITK_ask_cli_argument("-FromDate=");
                ToDate = ITK_ask_cli_argument("-ToDate=");
                find_for_task = ITK_ask_cli_argument("-find_for_task=");
                user_id = ITK_ask_cli_argument("-user_id=");
                FILE *fp;
                fp=fopen(inputfile,"r");

                //char *cEntries[2]  = {"Item ID","itemRevSeq"};
                //char *cEntries[2]  = {"Revision","ID"};

                char *cEntries[3]  = {"Name","Created After","Created Before"};


                char *inputline = NULL;

                char **cValues = (char **) MEM_alloc(50 * sizeof(char *));

                        output = fopen(outputFile,"w");

                        if (output == NULL)
                        {
                                printf("ERROR: Cannot open File\n");
                                return -1;
                        }
                        fprintf(output, "DML Number,Creation Date,Reviewer Name,Approved Task,Release status");fflush(output);



                if (iFail == ITK_ok)
                {
                        printf("\nTeamcenter Login Success...");fflush(stdout);
                        POM_get_user(&username, &tuser);
                        printf("\nUsername = %s", username);fflush(stdout);
                }
                else
                {
                        EMH_ask_error_text(iFail, &cError);
                        printf("\nError is : %s", cError);fflush(stdout);
                }
                if (cError)
                {
                        MEM_free(cError);
                }
                if (username)
                {
                        MEM_free(username);
                }
                                                int pending_dml_count = 0;
                                                cValues[0] = "Change Request Life Cycle";
                                                cValues[1] = FromDate;
                                                cValues[2] = ToDate;
                                                ITK_CALL(QRY_find2("EPMTaskWF",&tItemobj));
                                                ITK_CALL(QRY_execute(tItemobj, 3, cEntries, cValues, &n_itemobj_found, &titemobj_results));
                                                printf("\n n_itemobj_found --> %d ",n_itemobj_found);fflush(stdout);

                                                //ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&relation_type));
                                                ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_type2));


                                                char* taskType = NULL;
                                                char* TaskObj = NULL;
                                                char* tskName = NULL;
                                                char* analyst = NULL;
                                                int count =0;
                                                char* InteractiveTasks = NULL;
                                                char* ReleaseStatus = NULL;
                                                char* InteractiveTasks1 = NULL;
                                                char* ReleaseStatus1 = NULL;
                                                char* ParticipantsName = NULL;
                                                char* ParticipantsName1 = NULL;
                                                //tag_t* attachments = NULLTAG;
                                                int cntTsk = 0;
                                                tag_t* tskTag = NULLTAG;
						int total_dml_count = 0;



                                                if(n_itemobj_found>0)
                                                {
                                                        for(i=0;i<n_itemobj_found;i++)
                                                        {
                                                                itemrev=titemobj_results[i];
                                                                ITK_CALL(AOM_UIF_ask_value(itemrev, "task_type", &taskType));
                                                                ITK_CALL(AOM_UIF_ask_value(itemrev, "object_name", &TaskObj));
                                                                ITK_CALL(AOM_UIF_ask_value(itemrev, "root_target_attachments", &tskName));
                                                                ITK_CALL(AOM_UIF_ask_value(itemrev, "fnd0Performer", &analyst));
                                                                ITK_CALL(AOM_UIF_ask_value(itemrev, "fnd0ActuatedInteractiveTsks", &InteractiveTasks));
                                                                ITK_CALL(AOM_UIF_ask_value(itemrev, "release_status_list", &ReleaseStatus));

                                                                printf("\n taskType = %s\n", taskType);
                                                                printf("TaskObj = %s\n", TaskObj);
                                                                printf("tskName = %s\n", tskName);
                                                                printf("analyst = %s\n", analyst);

                                                                printf("InteractiveTasks = %s\n", InteractiveTasks);



                                                                ITK_CALL(EPM_ask_attachments (itemrev,EPM_target_attachment,&count,&attachments));
                                                                printf("\n EPM_ask_attachments of :: %d\n",count); fflush(stdout);


                                                                        char* DML_No = NULL;
									                                    char* Creation_Date = NULL;
									                                    char* Last_Modification_Date = NULL;
									                                    char* Tsk_Start_Date = NULL;
                                                                        int t = 0;
                                                                        tag_t objTag= NULLTAG;
                                                                        ParticipantsName1 = (char *)MEM_alloc(250);
                                                                        int St =0;
                                                                        char* AssignedAnalyst = NULL;
                                                                        char* taskType = NULL;
                                                                        char* tskObj = NULL;
                                                                        char* WorkFlowType = NULL;
                                                                        WorkFlowType = (char *)MEM_alloc(250);
                                                                        tc_strcpy(WorkFlowType,"");
                                                                        tc_strcpy(WorkFlowType,"Change Request Life Cycle");



                                                                        if(count > 0)
                                                                        {
                                                                                for(t=0;t<count;t++)
                                                                                {
                                                                                        AOM_ask_value_string(attachments[t],"object_type",&object_type);
                                                                                        printf("\n object_type is :%s\n",object_type);fflush(stdout);

                                                                                        AOM_ask_value_string(attachments[t],"item_id",&DML_No);
                                                                                        printf("\n DML_No is :%s\n",DML_No);fflush(stdout);
                                                                                        
											                                            AOM_UIF_ask_value(attachments[t],"last_mod_date",&Last_Modification_Date);
                                                                                        printf("\n Date_Modify is :%s\n",Last_Modification_Date);fflush(stdout);
                                                                                        if(tc_strcmp(object_type,"ChangeRequestRevision")==0)
                                                                                        {

                                                                                                //ITK_CALL(AOM_UIF_ask_value(attachments[t], "fnd0ActuatedInteractiveTsks", &InteractiveTasks1));
                                                                                                //printf("\n InteractiveTasks1 is :%s\n",InteractiveTasks1);fflush(stdout);

                                                                                                ITK_CALL(AOM_ask_value_tags(attachments[t], "fnd0ActuatedInteractiveTsks", &cntTsk, &tskTag));
                                                                                                printf("\n cntTsk is :%d\n",cntTsk);fflush(stdout);

                                                                                                ITK_CALL(AOM_UIF_ask_value(attachments[t], "release_status_list", &ReleaseStatus1));
                                                                                                printf("\n ReleaseStatus1 is :%s\n",ReleaseStatus1);fflush(stdout);

                                                                                                //ParticipantsName=tc_strtok(InteractiveTasks1,",");
                                                                                                //ParticipantsName1 = tc_strtok (NULL,",");
                                                                                                //printf("\n ParticipantsName1 is :%s\n",ParticipantsName);fflush(stdout);

                                                                                                /*
                                                                                                if(tc_strcmp(ReleaseStatus1,"In Designer Working")==0)
                                                                                                {
                                                                                                        if(cntTsk>0)
                                                                                                        {
                                                                                                                fprintf(output,"\n %s,%s,%s",DML_No,WorkFlowType,ReleaseStatus1);fflush(output);

                                                                                                                for(St=0;St<cntTsk;St++)
                                                                                                                {
                                                                                                                        ITK_CALL(AOM_UIF_ask_value(tskTag[St], "object_name", &tskObj));
                                                                                                                        printf("\n Child Task Object  = %s", tskObj);
                                                                                                                        ITK_CALL(AOM_UIF_ask_value(tskTag[St], "object_type", &taskType));
                                                                                                                        printf("\n taskType = %s", taskType);
                                                                                                                        ITK_CALL(AOM_UIF_ask_value(tskTag[St], "fnd0Performer", &AssignedAnalyst));
                                                                                                                        printf("\n AssignedAnalyst = %s", AssignedAnalyst);
                                                                                                                        // if(tc_strcmp(Child Task Object,"dummy task")==0){
                                                                                                                        //      fprintf(output,",%s,%s",tskObj,AssignedAnalyst);fflush(output);
                                                                                                                        // }

                                                                                                                        else if(tc_strcmp(taskType,"Signoff")==0)
                                                                                                                        {
                                                                                                                                fprintf(output,",%s,%s",tskObj,AssignedAnalyst);fflush(output);
                                                                                                                        }

                                                                                                                }

                                                                                                                //fprintf(output,"\n%s,%s,%s",DML_No,ReleaseStatus1,AssignedAnalyst);fflush(output);
                                                                                                        }


                                                                                                }*/

                                                                                                if ((tc_strcmp(ReleaseStatus1, "In Designer Working") == 0) || (tc_strcmp(ReleaseStatus1, "ERC Released") == 0)) {
                                                                                                   // if (tc_strcmp(ReleaseStatus1, "In Designer Working") == 0) {
                                                                                                        if (cntTsk > 0) {
                                                                                                            //fprintf(output, "\n %s,%s,%s,%s,", DML_No, WorkFlowType, ReleaseStatus1, Last_Modification_Date);
                                                                                                             //fflush(output);
                                                                                                            
                                                                                                            char currentTaskObj[MAX_NAME_LENGTH] = "";
                                                                                                            char tskstartdate[MAX_NAME_LENGTH] = "";
                                                                                                            _Bool firstChildTaskPrinted = false;
                                                                                                            _Bool stopPrinting = false;
                                                                                                            char signoffAnalysts[MAX_ANALYSTS_LENGTH] = "";
                                                                                                    
                                                                                                            for (int St = 0; St < cntTsk; St++) {
                                                                                                                ITK_CALL(AOM_UIF_ask_value(tskTag[St], "object_name", &tskObj));
                                                                                                                printf("\n Child Task Object  = %s", tskObj);
                                                                                                                ITK_CALL(AOM_UIF_ask_value(tskTag[St], "object_type", &taskType));
                                                                                                                printf("\n taskType = %s", taskType);
                                                                                                                ITK_CALL(AOM_UIF_ask_value(tskTag[St], "fnd0Performer", &AssignedAnalyst));
                                                                                                    
                                                                                                                printf("\n AssignedAnalyst = %s", AssignedAnalyst);
                                                                                                                ITK_CALL(AOM_UIF_ask_value(tskTag[St], "fnd0StartDate", &Tsk_Start_Date));
                                                                                                                printf("\n Task_Start_Date is :%s\n", Tsk_Start_Date);
                                                                                                                fflush(stdout);
                                                                                                    
                                                                                                                // if (tc_strcmp(currentTaskObj, tskObj) != 0) {
                                                                                                                //     if (strlen(currentTaskObj) > 0) {
                                                                                                                //         fprintf(output, " ");
                                                                                                                //     }
                                                                                                                //     strcpy(currentTaskObj, tskObj);
                                                                                                                //     fprintf(output, "| %s", tskObj);
                                                                                                                //     fflush(output);
                                                                                                                // }
                                                                                                    
                                                                                                                if (!firstChildTaskPrinted) {
                                                                                                                    fflush(output);
                                                                                                                    firstChildTaskPrinted = true;
                                                                                                                }
                                                                                                    
                                                                                                                // Check for specific conditions to print DML_No
                                                                                                                if (tc_strcmp(tskObj, find_for_task) == 0 && tc_strcmp(AssignedAnalyst, user_id) == 0) {

														    total_dml_count++;
                                                                                                                    ITK_CALL(AOM_UIF_ask_value(tskTag[St], "creation_date", &Creation_Date));
                                                                                                                    //printf("\n Task_Start_Date is :%s\n", Tsk_Start_Date);
                                                                                                                    fprintf(output, "\n %s,%s,%s,%s,%s", DML_No,Creation_Date,AssignedAnalyst,tskObj,ReleaseStatus1);
                                                                                                                    fflush(output);
                                                                                                                }
                                                                                                    
                                                                                                                // if (((tc_strcmp(taskType, "Signoff") == 0) || (tc_strcmp(taskType, "Signoff") != 0)) && (tc_strcmp(currentTaskObj, "select-signoff-team") != 0)) {
                                                                                                                //     if (strlen(signoffAnalysts) > 0) {
                                                                                                                //         strcat(signoffAnalysts, " | ");
                                                                                                                //     }
                                                                                                                //     strcat(signoffAnalysts, AssignedAnalyst);
                                                                                                                // }
                                                                                                    
                                                                                                                // if (tc_strcmp(currentTaskObj, "select-signoff-team") == 0) {
                                                                                                                //     if (strlen(signoffAnalysts) > 0) {
                                                                                                                //         fprintf(output, ", %s", signoffAnalysts);
                                                                                                                //         fflush(output);
                                                                                                                //     }
                                                                                                                //     stopPrinting = true;
                                                                                                                //     break;
                                                                                                                // }
                                                                                                            }
                                                                                                    
                                                                                                            // if (!stopPrinting && strlen(signoffAnalysts) > 0) {
                                                                                                            //    // fprintf(output, ",%s", signoffAnalysts);
                                                                                                            //     fflush(output);
                                                                                                            // }
                                                                                                        }
                                                                                                    //}
                                                                                                    
                                                                                                 }

                                                                                                 //pending_dml_count++;
                                                                                                          

                                                                                        }



                                                                                }
                                                                        }
                                                    }


char emailBody[1024];
                                                char* OwnerMailId                        = NULL;
                                                char* emailCC = NULL;
                                                char* eMailTo = NULL;
                                                //char  *emailBody          = NULL;
                                                char  *emailSub   = NULL;
                                                char* buff                      = NULL;
                                                char **controlqry_entries = (char **) MEM_alloc(30 * sizeof(char *));
                                                char **controlqry_values = (char **) MEM_alloc(100 * sizeof(char *));
                                                buff=(char *) MEM_alloc(500 * sizeof(char *));
                                                eMailTo=(char *) MEM_alloc(1000 * sizeof(char *));
                                                emailCC=(char *) MEM_alloc(1000 * sizeof(char *));
                                                //emailBody = (char *) MEM_alloc( 10000 * sizeof(char) );
                                                emailSub = (char *) MEM_alloc( 1000 * sizeof(char) );
                                                //char emailBody[MAX_EMAIL_BODY_LENGTH];
                                                       // tc_strcpy(emailCC,"mohant.ttl@tatamotors.com");
                                                        tc_strcat(emailCC,",");
                                                        tc_strcat(emailCC,",");
                                                        tc_strcat(emailCC,"r0000992.ttl@tatamotors.com");
                                                        tc_strcat(emailCC,",");
                                                        tc_strcat(emailCC,"ad928811.ttl@tatamotors.com");
                                                       // tc_strcpy(emailBody,"Dear Team,\n\nPlease refer attached Pending DML Report\nTotal Number of DML currently in Workflow = %d.\n\nThanks & Regards,\nPLM TEAM(ERC)");
                                                
                                                
                                                        //char emailBody[1024];
                                                sprintf(emailBody, "Dear Team, \n\nPlease refer attached DML Report for User - %s.\nApproved Task Name: %s \nTotal Number of DML: %d.\n\nThanks & Regards,\nPLM TEAM(ERC)",user_id,find_for_task,total_dml_count);
                                                tc_strcpy(emailBody, emailBody);
                                                
                                                        sprintf(emailSub,"DML REPORT FOR USER - %s || (FROM:%s TO:%s)",user_id,FromDate,ToDate);
                                                        tc_strcpy(emailSub, emailSub);
                                                        //get mail id of session user. and if not loader then send mail if mail id availble.
                                                        if (tc_strlen(OwnerMailId) > 0)
                                                        {
                                                                tc_strcpy(eMailTo,OwnerMailId);
                                                        }
                                                        else
                                                        {
                                                                tc_strcpy(eMailTo,"r0000992.ttl@tatamotors.com");
                                                
                                                        }
                                                //}
                                                
                                                        sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -a \"%s\" -c \"%s\"  \"%s\" ",emailBody,emailSub,"DML_Report_for_specific_Reviewer.csv",emailCC,eMailTo);
                                                        printf("\n buff [%s]!!\n",buff);fflush(stdout);
                                                        system(buff);
                                                        printf("\n After system buff ");fflush(stdout);

                                            }

                                 
                iFail = ITK_exit_module(TRUE);
                printf("\nReturn Value is : %d", iFail);
                if (iFail == ITK_ok)
                {
                        printf("\nTeamcenter Logout Success...");fflush(stdout);
                }
                else
                {
                        EMH_ask_error_text(iFail, &cError);
                        printf("\nError is : %s", cError);fflush(stdout);
                }

        fclose(output);
        return ITK_ok;
}









