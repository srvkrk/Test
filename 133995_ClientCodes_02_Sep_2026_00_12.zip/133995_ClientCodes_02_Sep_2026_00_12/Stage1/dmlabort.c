#include <time.h>
#include <stdio.h>

#include <tc/emh.h>

#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>

#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <Fnd0Participant/participant.h>
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN 128
#include <epm/epm.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>

#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>

#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>

#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>


#include <lov/lov.h>
#include <lov/lov_msg.h>

#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>

#include <tc/folder.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_ask_error_text (return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}

FILE		*output 			= NULL;
int			ifail 				= ITK_ok;
char		*sep				= "^";
int read_value_from_file(char*);
int GateMaturationUpd(char* Input_id);
char * 	ESOattrValue =NULL;

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"GateMaturationUpd -u=<username> -pf=<password file path> -g=<group> -file=<file_name>\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}
void getCurrentDateTime(char cCurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
void setAddTAG_APL(int *count,tag_t **objlist,tag_t obj ) // Added By Ketan 
{
 
	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTAG_11");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
 
	}
	else
	{
		//printf("\n ****setAddTAG_12");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
 
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}	

int ITK_user_main(int argc, char *argv[])
{

	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlnob					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";

	int count			= ITK_ok;
	int ss			= 0;
	tag_t  root_task			= NULLTAG;
	tag_t  DMLRevTag			= NULLTAG;
	tag_t  objTypTag			= NULLTAG;
	tag_t  DMLToTaskRel			= NULLTAG;
	tag_t  DMLTag			= NULLTAG;
	tag_t  reln_typeMdm			= NULLTAG;
	tag_t  old_relation			= NULLTAG;
	tag_t  attWFL			= NULLTAG;
	tag_t  attWFL1			= NULLTAG;
	tag_t  *attachments	= NULLTAG;
	tag_t  *Tsk_objects	= NULLTAG;
	int	taskcnt =0;
	int	j =0;
	int	n_referencers =0;
	int	tsk_cnt =0;
	char *ObjTyp= NULL;
	char *DMLtype= NULL;
	char *dmlreason= NULL;
	char *Synopsis= NULL;
	char *newSynopsis= NULL;
	char *Taskobject_type= NULL;
	char *nSynopsis= NULL;
	char ** relationsRef;

	char 	*attributeNameDup 			= NULL;
	char 	*attributeValueDup 			= NULL;
	attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );

	tag_t *	referencers=NULLTAG;
	tag_t *	PartsTagrf_1=NULLTAG;

	int   *levels					 = 0;
	int   partcntOldModule					 = 0;


	dmlnob 		= ITK_ask_cli_argument("-dmlno=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	tag_t class_id1 = NULLTAG;
	tag_t job_type = NULLTAG;
	tag_t job = NULLTAG;
	tag_t newreferencers = NULLTAG;
	char *class_name1=NULL;
	char*    MPartNo				 = NULL;
	

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nhey Login Successfull.....!!\n");fflush(stdout);
		printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
	}
	printf("\nAAAAAAAAAAA...!!\n");fflush(stdout); 
	//ifail = ITK_set_bypass(true);
	printf("\n BBBBBBBBBBBBB....!!\n");fflush(stdout);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}


	printf("\n DMl no: [%s]\n",dmlnob);fflush(stdout);

	ITK_CALL(ITEM_find_item(dmlnob,&DMLTag));
	ITK_CALL(ITEM_ask_latest_rev(DMLTag,&DMLRevTag));

	ITKCALL(EPM_get_current_job(DMLRevTag,&job,&job_type));

	(AOM_refresh(DMLRevTag,1));

	AOM_delete(job);

	(AOM_refresh(DMLRevTag,0));

	



	//ITK_CALL(GRM_find_relation_type("Fnd0EPMTarget",&reln_typeMdm));

	//ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag, NULLTAG,&partcntOldModule,&PartsTagrf_1));

	//printf("\n partcntOldModule is  ==%d\n",partcntOldModule);fflush(stdout);

	



	


				//	ITKCALL(WSOM_where_referenced2((const tag_t)DMLRevTag,1,&n_referencers,&levels,&referencers,&relationsRef);
				//	printf("\n\t WSOM_where_referenced n_referencers-->%d \n",n_referencers)); fflush(stdout);
				//	if(n_referencers>0)
				//	{
				//		for (ss=0;ss<n_referencers;ss++ )
				//		{
				//			POM_class_of_instance	(referencers[ss],&class_id1);
				//			POM_name_of_class	(class_id1,& class_name1);
				//			printf("\n CLASS NAME FOR ITEM ==%s\n",class_name1);fflush(stdout);
				//
				//			if(tc_strcmp(class_name1,"EPMTask")==0)
				//			{
				//				WSOM_ask_name2(referencers[ss],&MPartNo);
				//				printf("\n Name of refered data is  ==%s\n",MPartNo);fflush(stdout);
				//
				//				newreferencers=referencers[0];
				//
				//				tc_strcpy(attributeNameDup,"");
				//				tc_strcpy(attributeNameDup,relationsRef[ss]);
				//
				//				printf("\n relationsRef Names:[%s] for loop %d ",attributeNameDup,ss);fflush(stdout);

				


				
				//								(AOM_refresh(DMLRevTag,1));
				//								ITKCALL(ITK_set_bypass(true));
				//								ITKCALL(POM_attr_id_of_attr("process_stage_list","ChangeRequestRevision",&attWFL));
				//								
				//								ITKCALL(POM_refresh_instances_any_class(1,&DMLRevTag, POM_modify_lock));
				//								ITKCALL(POM_clear_attr(1,&DMLRevTag,attWFL));
				//								
				//								ITKCALL(POM_save_instances(1,&DMLRevTag,true));
				//				
				//								ITKCALL(POM_refresh_instances_any_class(1,referencers,POM_delete_lock));
				//								ITKCALL(POM_delete_instances(1,referencers));
				//								
				//								(AOM_refresh(DMLRevTag,0));


				//AOM_delete_from_parent(DMLRevTag,referencers[ss]);
				//printf("\n relationsRef  ==%s\n",relationsRef);fflush(stdout);

				

				
				//				ITK_CALL(GRM_find_relation_type("Fnd0EPMTarget",&reln_typeMdm));
				//
				//				ITK_CALL(GRM_list_secondary_objects_only(DMLRevTag,reln_typeMdm,&partcntOldModule,&PartsTagrf_1));
				//				//ITK_CALL(GRM_list_primary_objects_only(newreferencers,reln_typeMdm,&partcntOldModule,&PartsTagrf_1));
				//				//printf("\n partcntOldModule is  ==%d\n",partcntOldModule);fflush(stdout);
				//
				//
				//				//ITKCALL(AOM_ask_value_tags(DMLRevTag,"Fnd0EPMTarget",&partcntOldModule,&PartsTagrf_1));
				//				printf("\n partcntOldModule is  ==%d\n",partcntOldModule);fflush(stdout);
				//
				//				//AOM_delete_from_parent(DMLRevTag,PartsTagrf_1[0]);
				//		
				//
				//				ITK_CALL(GRM_find_relation(DMLRevTag,PartsTagrf_1[0],reln_typeMdm,&old_relation));
				//				ITK_CALL(GRM_delete_relation(old_relation));
				//				ITK_CALL(GRM_save_relation(old_relation));

						

				

				//ITK_CALL(GRM_delete_relation(old_relation));
                //ITK_CALL(GRM_save_relation(old_relation));
			//}
		//}
	//}
	return 0;
}