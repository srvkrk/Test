/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		  : Sachin Divate.
*  Created on	  : 07/06/2023
*  Module		  : AMDML Creation For Module by STD User
*  Code			  : AmDmlCreatefrmModule.c

***************************************************************************/
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>       
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <sa/user.h>
#include <tc/envelope.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#include <tccore/libtccore_exports.h>
#define Debug TRUE
int status=0;
int static totalPartCount=0;
int static flgChildPartDuplcy=0;
logical StatusFound =  false;

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf("\n");							\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status; */													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

#define TCTYPE_name_size_c 100
int stringsize =0;

/*
Deprecated api changes // sachind
AE_add_dataset_named_ref --> AE_add_dataset_named_ref2
AE_find_datasettype --> AE_find_datasettype2
AE_set_dataset_format --> AE_set_dataset_format2
AOM_save --> AOM_save_without_extensions
BOM_line_ask_attribute_tag --> AOM_ask_value_tag
CR_ask_release_status_type --> RELSTAT_ask_release_status_type
CR_create_release_status --> RELSTAT_create_release_status
EPM_add_release_status --> RELSTAT_add_release_status
IMF_set_original_file_name --> IMF_set_original_file_name2
MAIL_initialize_envelope --> MAIL_initialize_envelope2
PROP_ask_property_by_name --> AOM_UIF_ask_name
PROP_ask_value_string --> AOM_ask_value_string
QRY_find --> QRY_find2
SA_find_role --> SA_find_role2
SA_find_user --> SA_find_user2
TCTYPE_ask_name --> TCTYPE_ask_name2
WSOM_effectivity_ask_dates --> WSOM_eff_ask_dates

*/


// Structure Declaration
/*typedef enum MAIL_to_or_cc_e
{
	MAIL_send_to,
	MAIL_send_cc
}MAIL_to_or_cc_t;*/

struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;


struct BomChldStrut_Impl
{
	tag_t parent_objs;//CHild
	char  chldPartItmName[30];
	tag_t parent_objs_bvr;//BVR
	int parent_objs_lvl;//LVL
}*get_BomChldStrut_Impl;


struct structre_PartTagSet
{
	tag_t PartTag;
	char  PrtItemName[30];

};

struct struct_PartPRTagSet
{
	tag_t PartTag;
	char  PartName[30];
	char  partRevision[10];
};

struct struct_PartSetSkp
{
	tag_t PartTag;
	char  PartName[30];
	char  partRevision[10];
};

struct struct_PartrlzSkp
{
	tag_t PartTag;
	char  PartName[30];
	char  partRevision[10];
};


struct struct_PartDRSkp
{
	tag_t PartTag;
	char  PartName[30];
};


int tm_updateObjMasterFormName(tag_t tObj, char	*cupdname)
{
	int		status;
	
	char	*ObjID		=	NULL;
	char	*ObjName	=	NULL;

	tag_t  reln_type_Reference =NULLTAG;
	
	printf("\nInside tm_updateMasterFormName");fflush(stdout);

	ITKCALL(AOM_ask_value_string( tObj, "item_id", &ObjID));
	ITKCALL(AOM_ask_value_string( tObj, "object_name", &ObjName));

	printf("\nItem ID: %s, Object Name : %s",ObjID,ObjName);fflush(stdout);

	int		n_attchs_ref		=	0;
	GRM_relation_t	*rellist_refs;
	if(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));
	if(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));

	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;

			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n Type Name:%s ..............",type_name);fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s ..............",type_name);fflush(stdout);
			
			if (tc_strcmp(type_name,"T5_APLDMLMaster")==0)
			{
				printf("\nInside secondary Type Name:%s,%s ..............",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",cupdname));
				ITKCALL(AOM_save_without_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
			}
		}
	}
	return 0;
}

int tm_updateObjRevMasterFormName(tag_t tObj, char	*cupdname)
{
	int status;
	int		n_attchs_ref		=	0;

	char	*dmlrevision		=	NULL;
	char	*ObjID				=	NULL;
	char	*ObjName			=	NULL;

	tag_t	reln_type_Reference =	NULLTAG;
	GRM_relation_t	*rellist_refs;
	
	printf("\nInside tm_updateObjRevMasterFormName ");fflush(stdout);

	ITKCALL(AOM_ask_value_string(tObj, "item_revision_id", &dmlrevision));
	printf("\n dmlrevision: %s\n",dmlrevision);fflush(stdout);

	ITKCALL(GRM_find_relation_type("IMAN_master_form",&reln_type_Reference));

	ITKCALL(GRM_list_secondary_objects(tObj,reln_type_Reference,&n_attchs_ref,&rellist_refs));

	if (n_attchs_ref>0)
	{
		int i	=	0;
		for (i= 0; i < n_attchs_ref; i++)
		{
			tag_t	secondary		=	NULLTAG;
			tag_t	relationstr		=	NULLTAG;
			tag_t	objTypeTag		=	NULLTAG;
			char	*type_name		=	NULL;
			char	*mstrnamerev	=	NULL;
            char	*type_namer		=	NULL;
			mstrnamerev	=	(char *)MEM_alloc(tc_strlen(cupdname)+tc_strlen(dmlrevision)+15);
			tc_strcpy(mstrnamerev,cupdname);
			tc_strcat(mstrnamerev,"/");
			tc_strcat(mstrnamerev,dmlrevision);
			printf("\n mstrnamerev: %s\n",mstrnamerev);fflush(stdout);


			secondary	=	rellist_refs[i].secondary;
			relationstr	=	rellist_refs[i].the_relation;
			type_name	=	NULL;

			ITKCALL(TCTYPE_ask_object_type(relationstr,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_namer));
			printf("\n Type Name:%s ..............",type_namer);fflush(stdout);

			ITKCALL(TCTYPE_ask_object_type(secondary,&objTypeTag));
			ITKCALL(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n secondary Type Name:%s ..............",type_name);fflush(stdout);
			
			if (tc_strcmp(type_name,"T5_APLDMLRevisionMaster")==0)
			{
				printf("\nInside secondary Type Name:%s,%s ..............",type_name,cupdname);fflush(stdout);

				ITKCALL(AOM_set_value_string(secondary,"object_name",mstrnamerev));
				ITKCALL(AOM_save_without_extensions(secondary));
				ITKCALL(AOM_refresh(secondary,1));
			}
		}
	}
	return 0;
}

int FoundObjectInList(struct struct_PartSetSkp *iList,int Counter,char *PartRevName, char * partRevisionID )
{
	int			 Found		= 0;
	//ObjectList	 * iList	= *iFinalList;
	//*varExpObjTag			= NULLTAG;

	int setIndex=0;

	printf("\n Size of struct_PartSetSkp Set  %d",Counter+1);

	for(setIndex=0;setIndex<=Counter;setIndex++)
	{

		if(strcmp(iList[setIndex].PartName,PartRevName)==0 && strcmp(iList[setIndex].partRevision,partRevisionID) )
		{
			Found	=	1;
			break;
		}
	}

	if(Found==1)
	return 1;
	else
	return 0;
}

int FoundObjectInDRList(struct struct_PartDRSkp *iList,int Counter,char *PartRevName)
{
	int			 Found		= 0;
	//ObjectList	 * iList	= *iFinalList;
	//*varExpObjTag			= NULLTAG;

	int setIndex=0;

	printf("\n Size of struct_PartDRSkp Set  %d",Counter+1);

	for(setIndex=0;setIndex<Counter;setIndex++)
	{

		//if(strcmp(iList[setIndex].PartName,PartRevName)==0 && strcmp(iList[setIndex].partRevision,partRevisionID) )
		if(strcmp(iList[setIndex].PartName,PartRevName)==0)
		{
			Found	=	1;
			break;
		}
	}

	if(Found==1)
		return 1;
	else
		return 0;
}


int FoundObjectInrlzList(struct struct_PartrlzSkp *iList,int Counter,char *PartRevName, char * partRevisionID )
{
	int			 Found		= 0;
	//ObjectList	 * iList	= *iFinalList;
	//*varExpObjTag			= NULLTAG;

	int setIndex=0;

	printf("\n Size of struct_PartrlzSkp Set  %d",Counter+1);

	for(setIndex=0;setIndex<=Counter;setIndex++)
	{

		if(strcmp(iList[setIndex].PartName,PartRevName)==0 && strcmp(iList[setIndex].partRevision,partRevisionID) )
		{
			Found	=	1;
			break;
		}
	}

	if(Found==1)
	return 1;
	else
	return 0;
}


//End of Str
/**
 * Remove leading whitespace characters from string
 */
void trimLeading(char * str)
{
	int index, i, j;

	index = 0;

	/* Find last index of whitespace character */
	while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
	{
		index++;
	}


	if(index != 0)
	{
		/* Shit all trailing characters to its left */
		i = 0;
		while(str[i + index] != '\0')
		{
			str[i] = str[i + index];
			i++;
		}
		str[i] = '\0'; // Make sure that string is NULL terminated
	}
}
char** str_split(char* a_str, const char a_delim)
{
    char** result    = 0;
    size_t count     = 0;
    char* tmp        = a_str;
    char* last_comma = 0;
    char delim[2];
    delim[0] = a_delim;
    delim[1] = 0;

    /* Count how many elements will be extracted. */
    while (*tmp)
    {
        if (a_delim == *tmp)
        {
            count++;
            last_comma = tmp;
        }
        tmp++;
    }
    printf("  last_comma [%s]",last_comma);
    /* Add space for trailing token. */
    count += last_comma < (a_str + strlen(a_str) - 1);

    /* Add space for terminating null string so caller
       knows where the list of returned strings ends. */
    count++;

    result = malloc(sizeof(char*) * count);

    if (result)
    {
        size_t idx  = 0;
        char* token = strtok(a_str, delim);


        while (token)
        {
            assert(idx < count);
            *(result + idx++) = strdup(token);
            token = strtok(0, delim);
			stringsize = stringsize +1;
    		printf("stringsize [%d]",stringsize);
        }
        assert(idx == count - 1);
        *(result + idx) = 0;
    }
    printf("  stringsize1 [%d]",stringsize);

    return result;
}
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
		  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int	validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
	int      retcode    = ITK_ok;     /* Function return code */
	date_t   dt         = NULLDATE;   /* Date structure */
	int      month      = 0;          /* Month */
	int      day        = 0;          /* Day */
	int      year       = 0;          /* Year */
	int      hour       = 0;          /* Hour */
	int      minute     = 0;          /* Minutes */
	int      second     = 0;          /* Seconds */
	int          max_char_size = 80;
	char *    Correct_date = (char *)MEM_alloc(max_char_size * sizeof(char));

	*date_is_valid = TRUE;

	/* Converts a date_t structure into the format specified  */
	//    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for " 21-August-2015" / ""
	//    retcode = DATE_string_to_date ( date , "%m-%d-%y-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for  "07-21-2015-09:05:58"
	if(strlen (date)>10)
	{
		Correct_date=subString(date,0,20);
		printf("  Correct_date [%s]",Correct_date);
		retcode = DATE_string_to_date ( Correct_date , "%y/%m/%d-%H:%M:%S:" , &month , &day , &year , &hour , &minute , &second);
	}
	else
	{
		strcpy(Correct_date,date);
		strcat(Correct_date,"-00:00:00:");
		printf("  Correct_date [%s]",Correct_date);
		retcode = DATE_string_to_date ( Correct_date , "%y/%m/%d-%H:%M:%S:" , &month , &day , &year , &hour , &minute , &second);
	}
	printf("  month [%d]",month);
	printf("  day [%d]",day);
	printf("  year [%d]",year);
	printf("  hour [%d]",hour);
	printf("  minute [%d]",minute);
	printf("  second [%d]",second);

	if ( retcode != ITK_ok )
	{
		*date_is_valid = FALSE;
		printf("  Date is not valid [%d]",month);
	}
	else
	{
		dt.month = month;
		dt.day   = day;
		dt.year  = year;
		dt.hour  = hour;
		dt.minute= minute;
		dt.second= second;

		*the_dt = dt;
		printf("  Date is valid [%d]",month);

	}

	printf("  ---return from validate_date.");

	return retcode;
}
char * trim_space(char *str) {
    char *end;
    /* skip leading whitespace */
    while (isspace(*str)) {
        str = str + 1;
    }
    /* remove trailing whitespace */
    end = str + strlen(str) - 1;
    while (end > str && isspace(*end)) {
        end = end - 1;
    }
    /* write null character */
    *(end+1) = '\0';
    return str;
}


int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}


void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

//Update Life Cycle of DML to APL


void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

void ReverseStr(char str[])
{
    int i,j;
    char temp[100];
    for(i=strlen(str)-1,j=0; i+1!=0; --i,++j)
    {
        temp[j]=str[i];
    }
    temp[j]='\0';
    strcpy(str,temp);
}

int t5GetTaskDmlLastValue(char *DmlTaskName,char *myPlant)
{

	//char *mod_name = "t5GetTaskDmlLastValue";
	char *myPlant1	=NULL;
	char *myPlant2	=NULL; //vit
	//string xx	=NULL;
	int ifail = ITK_ok;
	int LengthOfDmlTaskName=0;
	myPlant1 = (char *) MEM_alloc( 100 * sizeof(char) );


	printf("Inside  t5GetTaskDmlLastValue Function with input value %s\n",DmlTaskName);fflush(stdout);


	// Getting t5GetTaskDmlLastValue truncation.
	LengthOfDmlTaskName = strlen(DmlTaskName);
	if(tc_strcmp(DmlTaskName,NULL)==0 || tc_strcmp(DmlTaskName,"")==0 )
	{
	tc_strcpy(myPlant1,"");
	}
	else
	{
	tc_strcpy(myPlant1,DmlTaskName);
	}
	
	//if (!nlsIsStrNull(myPlant1))
	if(tc_strcmp(myPlant1,NULL)!=0 || tc_strcmp(myPlant1,"")!=0 )
	{
		ReverseStr(myPlant1);
		//myPlant = strtok (myPlant1,"_");
		myPlant2 = strtok (myPlant1,"_");
		ReverseStr(myPlant2);
		printf("\nmyPlant=%s",myPlant2);
		if(tc_strcmp(myPlant1,NULL)!=0 || tc_strcmp(myPlant1,"")!=0 )
		{
		tc_strcpy(myPlant,myPlant2);
		}
		//if(!nlsIsStrNull(myPlant2)) nlsStrCpy(myPlant,myPlant2);
		printf("\n myPlant = %s",myPlant);fflush(stdout);
	}
	return ifail;
}

void getDesignType(tag_t Item, char	**designBORev, char **designBO)
{
	//char	*type_class					=	NULL;
	int		n_parents					=	0;
	tag_t	itemTypeTag_class			=	NULLTAG;
	tag_t	*parents					=	NULLTAG;
	tag_t	parent						=	NULLTAG;

	printf("Inside getDesignType...!!!");
	
	ITKCALL (TCTYPE_ask_object_type(Item,&itemTypeTag_class));
	ITKCALL (TCTYPE_ask_name2(itemTypeTag_class,&designBORev));
	
	printf("\t  type_itemRev ...%s\n", *designBORev);
	//*designBO= (char *) MEM_alloc(tc_strlen(*designBORev) * sizeof(char *) +5);

	ITKCALL (AOM_ask_value_tags(Item,"items_tag",&n_parents,&parents));
	printf("\t  type_item n_parents ...%d\n", n_parents);
	if (n_parents==1)
	{
		parent	=	parents[0];
		
		ITKCALL (TCTYPE_ask_object_type(parent,&itemTypeTag_class));
		ITKCALL (TCTYPE_ask_name2(itemTypeTag_class,&designBO));
	
		printf("\t  type_itemRev ...%s\n", *designBO);
		
	}
	else
	{
		printf("\nMore than one item tag return...!!!");fflush(stdout);
	}


	/*if (tc_strcmp(*designBORev,"T5_EE_PartRevision")==0)
	{
		printf("\t  designBO set as T5_EE_Part\n");
		tc_strcpy(*designBO,"T5_EE_Part");
	}
	else if (tc_strcmp(*designBORev,"T5_CkdDmyRevision")==0)
	{
		printf("\t  designBO set as T5_CkdDmy\n");
		tc_strcpy(*designBO,"T5_CkdDmy");
	}
	else if (tc_strcmp(*designBORev,"T5_DummyPartRevision")==0)
	{
		printf("\t  designBO set as T5_DummyPart\n");
		tc_strcpy(*designBO,"T5_DummyPart");
	}
	else if (tc_strcmp(*designBORev,"T5_RawPartRevision")==0)
	{
		printf("\t  designBO set as T5_RawPart\n");
		tc_strcpy(*designBO,"T5_RawPart");
	}
	else if (tc_strcmp(*designBORev,"T5_SparKitRevision")==0)
	{
		printf("\t  designBO set as T5_SparKit\n");
		tc_strcpy(*designBO,"T5_SparKit");
	}
	else if (tc_strcmp(*designBORev,"Design Revision")==0 || tc_strcmp(*designBORev,"Design_0_Revision_alt")==0)
	{
		printf("\t  designBO set as Design\n");
		tc_strcpy(*designBO,"Design");
	}
	else
	{
		printf("\t  condition not matched, so default Design is assigned.\n");
		tc_strcpy(*designBO,"Design");
	}*/
	
	printf("\t  type_itemRev ...%s, BO CLASS : %s\n", *designBORev,*designBO);

}

//Added By Hemal For PB
void  get_CtrlVal_APLStateInf( char * Plt_Code ,char  APlRevwLC[40],char  AplWrkngLC[40],char  AplRlzdLC[40],char  StdWrkngLC[40],char  StdRlzdLC[40], char PlantLCFlag[40], char StdPlant[40], char StdRevRule[40], char StdCLosRule[40],char StdView[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *APlRevw 			= NULL;
	 char *AplWrkng			= NULL;
	 char *AplRlzd			= NULL;
	 char *StdWrkng			= NULL;
	 char *StdRlzd			= NULL;
	 char *Plant			= NULL;
	 char *stdCode			= NULL;
	 char *RevRule		= NULL;
	 char *stdClsRule		= NULL;
	 char *stdBvr			= NULL;
	 char *PlantOneChar		= NULL;

	 char* viewtocpy		= NULL;
	 int max_char_size = 80;
	 viewtocpy = (char *)MEM_alloc(max_char_size * sizeof(char));

	printf("\n Plt_Code:%s",Plt_Code);fflush(stdout);
	PlantOneChar=subString(Plt_Code,3,1);
	printf("\n PlantOneChar:%s",PlantOneChar);fflush(stdout);
	tc_strcpy(viewtocpy,"");
	tc_strcat(viewtocpy,"STD");
	tc_strcat(viewtocpy,PlantOneChar);
	tc_strcat(viewtocpy," View");
	printf("\n View to copy:%s",viewtocpy);fflush(stdout);
	 

	 if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLStateInf";
				qry_valuesCntrl1[1]=Plt_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &APlRevw);
				printf("\n APlRevw: %s\n",APlRevw);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &AplWrkng);
				printf("\n AplWrkng: %s\n",AplWrkng);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &AplRlzd);
				printf("\n AplRlzd: %s\n",AplRlzd);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &StdWrkng);
				printf("\n StdWrkng: %s\n",StdWrkng);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &StdRlzd);
				printf("\n StdRlzd: %s\n",StdRlzd);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &Plant);
				printf("\n Plant: %s\n",Plant);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &stdCode);
				printf("\n stdCode: %s\n",stdCode);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &RevRule);
				printf("\n RevRule: %s\n",RevRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo9", &stdClsRule);
				printf("\n stdClsRule: %s\n",stdClsRule);fflush(stdout);

				//AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo10", &stdBvr);
				//printf("\n stdBvr: %s\n",stdBvr);fflush(stdout);

							
				if(tc_strlen(APlRevw)>0) 
				{ 
					tc_strcpy(APlRevwLC,APlRevw);
				}
				if(tc_strlen(AplWrkng)>0) 
				{ 
					tc_strcpy(AplWrkngLC,AplWrkng);
				}
				if(tc_strlen(AplRlzd)>0) 				
				{
					tc_strcpy(AplRlzdLC,AplRlzd);
				}
				if(tc_strlen(StdWrkng)>0) 
				{
					tc_strcpy(StdWrkngLC,StdWrkng);
				}
				if(tc_strlen(StdRlzd)>0) 
				{
					tc_strcpy(StdRlzdLC,StdRlzd);
				}
				if(tc_strlen(Plant)>0) 
				{
					tc_strcpy(PlantLCFlag,Plant);
				}
				if(tc_strlen(stdCode)>0) 
				{
					tc_strcpy(StdPlant,stdCode);
				}
				if(tc_strlen(RevRule)>0) 
				{
					tc_strcpy(StdRevRule,RevRule);
				}
				if(tc_strlen(stdClsRule)>0) 
				{
					tc_strcpy(StdCLosRule,stdClsRule);
				}
				if(tc_strlen(viewtocpy)>0) 
				{
					tc_strcpy(StdView,viewtocpy);
				}
			}
			else
			{
				tc_strcpy(APlRevwLC,"T5_LcsAplReview");
				tc_strcpy(AplWrkngLC,"T5_LcsAPLWrkg");
				tc_strcpy(AplRlzdLC,"T5_LcsAplRlzd");
				tc_strcpy(StdWrkngLC,"T5_LcsSTDWrkg");
				tc_strcpy(StdRlzdLC,"T5_LcsStdRlzd");		
				tc_strcpy(PlantLCFlag,"CAR");
				tc_strcpy(StdPlant,"STDC");
				tc_strcpy(StdRevRule,"APLC Release and above");
				tc_strcpy(StdCLosRule,"BOMViewClosureRuleSTDC");
				tc_strcpy(StdView,viewtocpy);
			}
}


static int t5UpdateLifecycleStateAPL(tag_t object_tag, char* lifecycleStateName, char* PlantName)
{
	int n_values_checkin = 0;
	int cunt1 = 0;
	int flag = 0;
	int				ifail=0;
	int releaseStatusFnd =0;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;
	date_t test_date_1;
	date_t test_date_2;
	tag_t    	    propEff_tag				    =NULLTAG;
    logical stat  ;
	char*			value					=NULL;
	char cNextDate[20]={0};

	char *class_name = NULL;
	char *Release_Status = NULL;
	char	*item_type				= NULL;

	tag_t		class_id				=     NULLTAG;
	tag_t		tReleaseStatusList_checkin=NULLTAG;
	tag_t*		attr_tags_checkin		=	NULLTAG;
	tag_t			status_rel					= NULLTAG;
	tag_t*    status_list1=NULLTAG;
	int              st_count1 = 0;

	tag_t*    status_list;
	tag_t	*rev_list				= NULL;
	int       ii=0;
	int       RevFlag=0;
	int       PreRevFlag=0;
	int       st_count=0;
	int Item_count      =  0;
	char*			PreRevOnly				= NULL;
	char*			RevOnly				= NULL;
	char*			Part_Rev				= NULL;
	char*			Part_Rev_copy				= NULL;
	char*			Part_rev_Id				= NULL;
	char*			PlantLCSFlag				= NULL;
	int       iLCS=0;
	int       cntLcs=0;
	int max_char_size = 100;
	int iLCS1 = 0;
	WSOM_open_ended_status_t  	open_ended_or_stock_out;
	char cCurrentAccessDate[20]={0};
	date_t Ltest_date_2;
	date_t *Rel_start_end_values	= NULL;
	int	n_dates 	= 0;
	int	n_effectivities 		= 0;
	int	jj 		= 0;
    char	*old_to_date			= NULL;
	logical date_is_valid  ;
	date_t Ltest_date_1;
	date_t *Lstart_end_date			= NULL;
	tag_t	Leff_d				= NULLTAG;
	tag_t	*effectivities_tag		= NULL;

	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	logical		log1;
	logical		checkout1;
	logical			retain							= 0;
	int	iVldStamp	=	0;//Added by Hemal
	tag_t  CurrentRoleTag = NULLTAG;
	//char       roleName[SA_name_size_c+1]  ;
	char	*releasest_name	=	NULL;
	char AplRvwLC[40];//TZ3.46
	char AplWrkngLC[40];
	char AplRlzdLc[40];
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];
	PlantLCSFlag = (char *)MEM_alloc(max_char_size * sizeof(char));

	ITKCALL(POM_class_of_instance(object_tag,&class_id));
	ITKCALL(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);
	
	ITKCALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
	ITKCALL(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
	printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);


	ITKCALL(POM_unload_instances (1,&object_tag));
	ITKCALL(POM_load_instances(1,&object_tag,class_id,1));
	ITKCALL(POM_is_loaded(object_tag,&log1));
	for (iLCS1=0;iLCS1<st_count1 ;iLCS1++ )
	{
		releasest_name	=	NULL;
		ITKCALL(AOM_ask_value_string(status_list1[iLCS1],"object_name",&releasest_name));
		printf("\n releasest_name: %s\n",releasest_name);fflush(stdout);
		if(tc_strcmp(releasest_name,lifecycleStateName)==0)
		{
			releaseStatusFnd++;
		}
	}
	if(log1 == 1)
	{
		 printf(" Load Success\n " );
	}
	else
	printf("Load Failure\n"  );

	//*****************TZ3.46*******************//
	
	get_CtrlVal_APLStateInf(PlantName,AplRvwLC,AplWrkngLC,AplRlzdLc,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

	printf( "\n AplRlzdLc:%s\n", AplRlzdLc);  fflush(stdout);
	printf( "\n AplRvwLC:%s\n", AplRvwLC);  fflush(stdout);
	printf( "\n AplWrkngLC:%s\n", AplWrkngLC);  fflush(stdout);

	ITKCALL( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		ITKCALL( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
        flag = 0;
		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
			if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
			printf("\n  Release_Status changes done: for workspaceobject     %s,lifecycleStateName : %s\n", Release_Status,lifecycleStateName);fflush(stdout);

			//TZ3.46//
			if(tc_strcmp(lifecycleStateName,AplRlzdLc)==0)
            {
				if((tc_strcmp(Release_Status,AplRvwLC)==0 || tc_strcmp(Release_Status,AplWrkngLC)==0))
				{
					ITKCALL(POM_unload_instances (1,&object_tag));
					ITKCALL(POM_load_instances(1,&object_tag,class_id,1));
					ITKCALL(POM_is_loaded(object_tag,&log1));

					ITKCALL(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
					printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

					ITKCALL(POM_save_instances(1,&object_tag,1));

					ITKCALL(POM_refresh_instances(1,&object_tag,class_id,2));

					ITKCALL(AOM_lock(object_tag));

					ITKCALL(AOM_save_without_extensions(object_tag));
					ITKCALL(AOM_refresh(object_tag,1));
					ITKCALL(AOM_unlock(object_tag));
					tc_strcpy(PlantLCSFlag,PltLcs);//TZ3.46
					//PlantLCSFlag = PltLcs;
					iVldStamp	=	iVldStamp + 1;
				}else
				{
					flag = flag+1;
				}
			}

		}

	}
	
	printf("\niVldStamp : %d",iVldStamp);fflush(stdout);
	
	if (iVldStamp<=0 )
	{
		printf("Check for object type...!!!");fflush(stdout);
		item_type	=	NULL;
		ITKCALL(ITEM_ask_rev_type2(object_tag,&item_type));
		printf("Check for object type : %s",item_type);fflush(stdout);
		
		if(tc_strcmp(item_type,"T5_APLDMLRevision")==0 || tc_strcmp(item_type,"T5_APLTaskRevision")==0 )
		{
			iVldStamp	=	iVldStamp + 1;
		}
	}

	printf("\nAfter iVldStamp : %d",iVldStamp);fflush(stdout);
	printf("\nAfter releaseStatusFnd : %d",releaseStatusFnd);fflush(stdout);
	
	if(iVldStamp>0 && releaseStatusFnd==0)
	{
		printf("\n inside releaseStatus update");fflush(stdout);
		if(RELSTAT_create_release_status(lifecycleStateName,&status_rel));
		if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
	}
	
	if (iVldStamp>0 && (tc_strcmp(class_name,"T5_APLDMLRevision")!=0 && tc_strcmp(class_name,"T5_APLTaskRevision")!=0  ))
	{
		printf("Inside effectivity Check for object type : %s",class_name);fflush(stdout);
		ITKCALL(WSOM_ask_effectivity_mode(&stat));

	
		ITKCALL(AOM_UIF_ask_name(status_rel,"effectivity_text",&propEff_tag));
		//ITKCALL(PROP_ask_value_string(propEff_tag,&value));

		getNextDate(cNextDate);
		printf("\n cNextDate:%s",cNextDate);

		ITKCALL(ITK_string_to_date(cNextDate, &test_date_1 ));
		ITKCALL(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		ITKCALL(WSOM_status_clear_effectivities (status_rel));
		ITKCALL(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		ITKCALL(AOM_save_without_extensions(eff_d));
		ITKCALL(AOM_save_without_extensions(status_rel));
		ITKCALL(AOM_refresh(status_rel,0));

         // Start Privious Rev and stamp the close date
		tag_t		class_id1				=	NULLTAG;
		char		*class_name2			=	NULL;
		ITKCALL(POM_class_of_instance(object_tag,&class_id1));
		ITKCALL(POM_name_of_class(class_id,&class_name2));
		printf("\nclass_name2 : %s",class_name2);fflush(stdout);

		//CALLAPI(ITEM_list_all_revs (object_tag, &Item_count, &rev_list)); //commented
		//ADDED IN BACKEND TZ
		const char *qry_entries[2];//Multiple Item Queried Error
		const char *qry_values[2];//Multiple Item Queried Error
		int n_tags_found=0;
		tag_t	*itemclassp	= NULLTAG;
		tag_t item = NULLTAG;
		char	*Part_clr_ind	=	NULL;
		char*			Part_no				= NULL;

		ITKCALL(AOM_ask_value_string(object_tag,"item_id",&Part_no));
		printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
		Part_clr_ind	=	NULL;
		ITKCALL(AOM_ask_value_string(object_tag,"t5_ColourInd",&Part_clr_ind));
		printf("\n\n\t\t Part_clr_ind  is :%s",Part_clr_ind);	fflush(stdout);

		qry_entries[0] ="item_id";
		qry_entries[1] ="object_type";//Multiple Item Queried Error
		qry_values[0] = Part_no;
		if (tc_strcmp(Part_clr_ind,"C")==0)
		{
			qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
		}
		else
		{
			//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
			//Handle the different design child class.
			char	*designBORev		=	NULL;
			char	*designBO			=	NULL;
			tag_t	AssyTag			=	NULLTAG;
			//AssyTag=PartTags[k];
			printf("\nBefore getDesignType");fflush(stdout);
			getDesignType(object_tag, &designBORev,&designBO);
			printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
			qry_values[1] = designBO;

		}//Multiple Item Queried Error

			ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
			item = itemclassp[0];
			ITKCALL(ITEM_list_all_revs (item, &Item_count, &rev_list)); 
			//END ADDED IN BACKEND TZ

			printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
			if(Item_count > 0)
			{
				RevFlag = 0;
				PreRevFlag = 0;
				for(ii=Item_count-1;ii>=0;ii--)
				{
				   RevOnly = NULL;
				   PreRevOnly = NULL;
				   ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
					printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
					if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
					{
						RevFlag = 1;
					}
					printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
					if(RevFlag == 1)
					{
					   RevOnly= strtok( Part_Rev_copy, ";" );
					   PreRevOnly= strtok( Part_rev_Id, ";" );
					   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
					   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
					   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
						{
						  PreRevFlag = 1;
						}
					}
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					if(PreRevFlag == 1)
					{
						ITKCALL(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
						if(st_count == 0)
						{
						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
						break;
						}
						else
						{
							for (iLCS=0;iLCS<st_count ;iLCS++ )
							{
									ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);

									//*******************************TZ3.46*********************************//
									if(tc_strcmp(class_name,AplRlzdLc)==0)
									{
										getCurrentDateTime(cCurrentAccessDate);
										printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
										if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
										{
											return ifail;
										}
										if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_list[iLCS],&n_effectivities, &effectivities_tag) )) return ifail;
										printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
										if(n_effectivities > 0)
										{
											for(jj=0;jj<n_effectivities;jj++)
											{
												if(ITK_ok != (ifail = WSOM_eff_ask_dates(status_list[jj],effectivities_tag[jj],&n_dates,&Rel_start_end_values,&open_ended_or_stock_out )))return ifail;
												printf("\n Eff:no of Rel_start_end_value:%d\n", n_dates);fflush(stdout);
												if(n_dates > 0)
												{
													if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
													{
														return ifail;
													}
													printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
													if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
													{
														return ifail;
													}
													printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
													if(date_is_valid != true)
													{
														printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
													}
													else
													{
														printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
													}
												}
												else
												{
													printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
												}
											}
										}
										Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
										Lstart_end_date[0] = Ltest_date_1;
										Lstart_end_date[1] = Ltest_date_2;

										printf("\n ERCReview--EFF:Clearing effectivities...");fflush(stdout);
										if(ITK_ok != (ifail = WSOM_status_clear_effectivities (status_list[iLCS])))
										{
											return ifail;
										}

										printf("\n ERCReview--EFF:Creating effectivities...");fflush(stdout);
										if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_list[iLCS], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
										{
											return ifail;
										}
										printf("\n ERCReview--EFF:Saving effectivities...");fflush(stdout);
										if(ITK_ok != (ifail = AOM_save_without_extensions(Leff_d)))
										{
											return ifail;
										}
										printf("\n ERCReview--EFF:Saving Revision...");fflush(stdout);
										if(ITK_ok != (ifail = AOM_save_without_extensions(status_list[iLCS])))
										{
											return ifail;
										}
										printf("\n ERCReview--EFF:Refreshing Revision...");fflush(stdout);
										if(ITK_ok != (ifail = AOM_refresh( status_list[iLCS], 0 )))
										{
											return ifail;
										}
										break;
									}

							}
						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
						break;
						}
					}  /// End Prev Rev  Flag Loop
				}
			} /// End Prev Rev

	}else if(iVldStamp>0 && (tc_strcmp(class_name,"VariantRule")==0))
	{
		ITKCALL(WSOM_ask_effectivity_mode(&stat));

	//	getCurrentDateTime(cCurrentAccessDate);
		ITKCALL(AOM_UIF_ask_name(status_rel,"effectivity_text",&propEff_tag));
		//ITKCALL(PROP_ask_value_string(propEff_tag,&value));

		getNextDate(cNextDate);
		printf("\n cNextDate:%s",cNextDate);

		ITKCALL(ITK_string_to_date(cNextDate, &test_date_1 ));
		ITKCALL(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		ITKCALL(WSOM_status_clear_effectivities (status_rel));
		ITKCALL(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		ITKCALL(AOM_save_without_extensions(eff_d));
		ITKCALL(AOM_save_without_extensions(status_rel));
		ITKCALL(AOM_refresh(status_rel,0));
	}

	return 0;
}


//Sanket

int FunctionToReadDMLNumber(tag_t controlobject, char *PlantName, char *Proj_ID, char *DesignGroup, char *ecntypeVal, char **DMLNumber)
{
    int status;

    // Query control object
    char *qry_entryCntrl[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char **qry_valuesCntrl = (char **)MEM_alloc(5 * sizeof(char *));
    int n_entryT = 3;
    int ValCntT = 0;

    char *syscommand = NULL;
    char *ExePath = NULL;
    char *UsrP = NULL;
    char *PwdP = NULL;
    char *roleP = NULL;

    tag_t *ValCntrlObjectTagT = NULLTAG;
    tag_t qryTagT = NULLTAG;
    tag_t controlobj = NULLTAG;

    *DMLNumber = NULL;
    *DMLNumber = (char *)MEM_alloc(150 * sizeof(char *));

    printf("\nPlant Name : %s, Project : %s, Design group : %s, ECN Type : %s", PlantName, Proj_ID, DesignGroup, ecntypeVal);
    fflush(stdout);

    {
        if (controlobject != NULLTAG)
        {
            // controlobj	=	ValCntrlObjectTagT[0];

            printf("\n consuming web service started : \n");
            fflush(stdout);
            if (AOM_ask_value_string(controlobject, "t5_Userinfo1", &ExePath) != ITK_ok)
            //PrintErrorStack();
            printf("\n consuming web service start  :%s \n", ExePath);
            fflush(stdout);

            syscommand = (char *)MEM_alloc(500);

            tc_strcpy(syscommand, ExePath);
            tc_strcat(syscommand, " ");
            tc_strcat(syscommand, Proj_ID);
            tc_strcat(syscommand, " ");
            tc_strcat(syscommand, PlantName);
            tc_strcat(syscommand, " ");
            tc_strcat(syscommand, DesignGroup);
            tc_strcat(syscommand, " ");
            tc_strcat(syscommand, ecntypeVal);

            printf("\ncommand : %s", syscommand);
            fflush(stdout);

            printf(" \n New 1111");

            int rc;
            FILE *pipe = NULL;
            int i;
            char buffer[3000];
            char *value = NULL;
    
            sprintf(buffer, "%s", syscommand);
            if ((pipe = popen(buffer, "r")) == NULL)
            {
                 printf(" \n New 11");
                perror("popen");
                return 1;
            }
            while (fgets(buffer, 3000, pipe) != NULL)
            {
                if (tc_strstr(buffer, "NODMLCREATED") != NULL)
                {
                    printf("buffer1: %s", buffer);
                    printf("\n Checked in TCE, part is not present in TCE  : %s\n", buffer);
                    fflush(stdout);
                    tc_strcpy(*DMLNumber, "NODMLCREATED");
                    break;
                }
                else if (tc_strstr(buffer, "The rsp is :") != NULL)
                {
                    printf("buffer is : %s", buffer);
                    printf("\n Checked in TCE, part is present in TCE : %s\n", buffer);
                    fflush(stdout);
                    int i=0;
                    while (buffer[i] != '\0' && !(buffer[i] >= '0' && buffer[i] <= '9'))
                    {
                         i++;
                    }
                    if (buffer[i] != '\0') {
                         value = &buffer[i]; // Setting the value pointer to the current position
                    }
                    printf("buffer in while loop : %s", value);
                    tc_strcpy(*DMLNumber, value);
                    break;
                }
                else
                {
                    printf("buffer: %s", buffer);
                  //  printf("\n Checked in TCE, part is present in TCE : %s\n", buffer);
                }
            }
            

                //printf("buffer: %s", buffer);

            if (pclose(pipe) == -1)
            {
                perror("pclose");
                return 1;
            }

            printf("\n consuming web service end \n");
            printf(" \n buffer after webserver send: %s", buffer);
            fflush(stdout);

            /*if (strstr(buffer, "NODMLCREATED") != NULL)
            {
                printf("\n Checked in TCE, part is not present in TCE  : %s\n", buffer);
                fflush(stdout);
                tc_strcpy(*DMLNumber, "NODMLCREATED");
            }
            else
            {
                printf("\n Checked in TCE, part is present in TCE : %s\n", buffer);
                fflush(stdout);
               tc_strcpy(*DMLNumber, buffer);
            }*/
        }
        else
        {
            tc_strcpy(*DMLNumber, "NODMLCREATED");
        }
    }

    return status;
}

// AMDML Creation

 int AMDMLCreateFuncTOO(char  *project,char *dsgnGrp,char  *dvrNum,char  *WbsNameMain,char *WbsDescriptionMain,char *usrNameDup,int FlagPR,char *PlantName,tag_t *AMDmlObj)
 {
	tag_t		APLDTypeTag			=  NULLTAG;
	tag_t		APLDRevTypeTag		=  NULLTAG;
	tag_t		APLDCreInTag		=  NULLTAG;
	tag_t		APLDRevCreInTag		=  NULLTAG;

	//tag_t			APLDTypeTag			= NULLTAG;
	tag_t		TaskRevTag			= NULLTAG;
	tag_t 		APLDMLRevTag		= NULLTAG;
	tag_t		APLTTypeTag			= NULLTAG;
	tag_t		APLTCreInTag		= NULLTAG;
	tag_t		APLTRevTypeTag		= NULLTAG;
	tag_t		APLTRevCreInTag		= NULLTAG;

	tag_t	    Dml_tag		    	= NULLTAG;
	tag_t		APLDMLTag			= NULLTAG;
	tag_t		TaskTagrev		    = NULLTAG;
	tag_t		APLTaskTag			= NULLTAG;
	tag_t 		APLTaskRevTag	    = NULLTAG;
	tag_t 		DmlEcnRlzTypeAttrID = NULLTAG;
	tag_t       *results			=  NULLTAG;
	tag_t		*AmRevObjSet 		=  NULLTAG;

	tag_t       relation_type        = NULLTAG;
	tag_t		apltaskrelation      = NULLTAG;
	tag_t		NewDMLAttrId = NULLTAG;
	tag_t		NewDMLRevAttrId = NULLTAG;


	char		*tempString			= NULL;

	char		*DmlNoRule			= NULL;
	char 		*apldmlno			= NULL;
	char 		*aplTaskno			= NULL;
	char		*Year                = NULL;

	char        *Proj_ID=NULL;
	char		*DMLAPL				= NULL;
	char		*Suffix				= NULL;
	char		*item_id 	   		= NULL;
	char 		*DML_no 			= NULL;
	char		**DesignGroupList	= NULL;
	int			max_char_size 					= 100;

	char cCurrentAccessDate[20]		={0};
	WSO_search_criteria_t  	APLTaskCriteria;
	WSO_search_criteria_t  	APLDMLCriteria;


	char *Dml_Name 	  				=	NULL;
	char *DMLSerial					=	NULL;
	char *DMLitem_id				=	NULL;
	char *DmlLastSerial				=	(char *)MEM_alloc(max_char_size * sizeof(char));

	//Integer declaration
	int apl_dml_found=0,apl_task_number_found=0,index=0,n_entries=0,n_found=0;
	int  DMLSerialInt;
	int				l_strings			= 500;
	status=0;

	tag_t 		    AmDmlFindquery		= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	char*			tempStringt			= NULL;

	char *item_id_apl_dml = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_id_apl_dml_str = (char *)MEM_alloc(max_char_size * sizeof(char));

	char *item_id_apl_task = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_id_dml = (char *)MEM_alloc(max_char_size * sizeof(char));
	//	char *item_id_dml_Str = (char *)MEM_alloc(max_char_size * sizeof(char));

	tag_t *list_of_WSO_tags			= NULLTAG;
	tag_t  NewTaskAttrId 				= NULLTAG;

	int n_strings=1;

	int      num_to_sort  = 1;
	char    *keys[1]      = {"creation_date"};
	int  	 orders[1]     = {2};

	//Webservice changes start
	char	*Response		=	NULL;
	Response = (char *)MEM_alloc(50 * sizeof(char));
	
	char	*amdmltce		=	NULL;
	//Webservice changes ends

	stringArrayAPLD = (char**)malloc( n_strings * sizeof *stringArrayAPLD );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLD[index] = (char*)malloc( l_strings + 1 );
	}
	stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
	for( index=0; index<n_strings; index++ )
	{
		stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
	}
	printf("\n Inside the AMDML Creation Function"); fflush(stdout);

	printf("\n Inside the AMDML Creation Function  Plan Name : %s",PlantName); fflush(stdout);

		   // printf("2.Found Query \n");fflush(stdout);
	getCurrentDateTime(cCurrentAccessDate);
	printf("\n cCurrentAccessDate:%s ",cCurrentAccessDate);
	Year=subString(cCurrentAccessDate,9,2);

	if(strcmp(PlantName,"APLJ")==0)
	{
		strcpy(item_id_apl_dml,Year);
		strcat (item_id_apl_dml,"AM80");
		strcat (item_id_apl_dml,"*");
		printf("\n item_id_apl_dml:%s",item_id_apl_dml);
		tc_strcpy(item_id_apl_dml_str,Year);
		tc_strcat (item_id_apl_dml_str,"AM80");
	}
	else if(strcmp(PlantName,"APLL")==0)
	{
		tc_strcpy(item_id_apl_dml,Year);
		tc_strcat (item_id_apl_dml,"AM70");
		tc_strcat (item_id_apl_dml,"*");
		printf("\n item_id_apl_dml:%s",item_id_apl_dml);
		tc_strcpy(item_id_apl_dml_str,Year);
		tc_strcat (item_id_apl_dml_str,"AM70");
	}
	else
	{
		tc_strcpy(item_id_apl_dml,Year);
		tc_strcat (item_id_apl_dml,"AM90");
		tc_strcat (item_id_apl_dml,"*");
		printf("\n item_id_apl_dml:%s",item_id_apl_dml);
		tc_strcpy(item_id_apl_dml_str,Year);
		tc_strcat (item_id_apl_dml_str,"AM90");
	}
			//Qry Find to Get Latest AMDML Created

	ITK_CALL(QRY_find2("APLDMLQuery", &AmDmlFindquery));
	n_entries=1;
	char
		 *qry_entries[1] = {"ID"},
		 *qry_values[1] =  {item_id_apl_dml};
	printf(" Print  User  values: %s\n",qry_values[0]);fflush(stdout);
			//printf(" Print entries and values: %s\n",qry_entries[1]);fflush(stdout);


	if(AmDmlFindquery!=NULLTAG)
	{
		  QRY_execute_with_sort(AmDmlFindquery, n_entries, qry_entries, qry_values, num_to_sort, keys, orders, &n_found, &results);
	}
	printf("\n Total AMDML Found in DB %d",n_found); fflush(stdout);

			//QRY_execute(AmDmlFindquery, n_entries, qry_entries, qry_values, &n_found, &AmRevObjSet);

	if(n_found>0)
	{
		Dml_tag = results[0];
		AOM_ask_value_string( Dml_tag, "item_id", &Dml_Name);
		printf("\n Dml_Name : %s\n",Dml_Name);fflush(stdout);
		DMLSerial=subString(Dml_Name,6,4);
		printf("\n DMLSerial : %s\n",DMLSerial);fflush(stdout);
		DMLSerialInt =atoi(DMLSerial);
		DMLSerialInt = DMLSerialInt + 1 ;
		printf("\n DMLSerialInt :%d\n",DMLSerialInt);fflush(stdout);
		sprintf(DmlLastSerial,"%d",DMLSerialInt);
		printf("\n DmlLastSerial : %s\n",DmlLastSerial);fflush(stdout);
		tc_strcat (item_id_apl_dml_str,DmlLastSerial);
		tc_strcat (item_id_apl_dml_str,"_");
		tc_strcat (item_id_apl_dml_str,PlantName);
		printf("\n item_id_apl_dml_str:%s",item_id_apl_dml_str);
	}
	else
	{
		tc_strcat (item_id_apl_dml_str,"1001");
		tc_strcat (item_id_apl_dml_str,"_");
		tc_strcat (item_id_apl_dml_str,PlantName);
	}

	char	*cUserInfo2		=	NULL;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	tag_t*	ValCntrlObjectTagT	=	NULLTAG;
	tag_t	qryTagCntrl1				=	NULLTAG;
	tag_t	controlobj			=	NULLTAG;

	int     n_entryCntrl1    = 3;

	if(QRY_find2("Control Objects...", &qryTagCntrl1));
	if (qryTagCntrl1!=NULLTAG)
	{
		printf("\n Control Object Query Found webservice\n");fflush(stdout);
		qry_valuesCntrl1[0]="CreateDMLINTCE";
		qry_valuesCntrl1[1]="CreateDMLINTCE";
		qry_valuesCntrl1[2]="0";
							
		printf("\nBefore Control Object Query Found webservice\n");fflush(stdout);

		int	control_number_found1	=	0;
		tag_t	*list_of_WSO_cntrl_tags1	=	NULLTAG;
		if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\nNumber of control object found :%d",control_number_found1);fflush(stdout);
        
		if (control_number_found1>0)
		{
			//creAMDMLInTCE(PlantName,project,"SYSTEM GENERATED APL DML FOR TCUA", dsgnGrp, "AMDML",&Response);
             //Response	=	creAMDMLInTCE(PlantName,project,"SYSTEM GENERATED APL DML FOR TCUA", dsgnGrp, "AMDML");	
			printf("\n caling FunctionToReadDMLNumber \n");fflush(stdout);
			FunctionToReadDMLNumber(list_of_WSO_cntrl_tags1[0], PlantName, project, dsgnGrp, "AMDML", &Response);

			amdmltce	=	strtok(Response,"_");
			tc_strcat(amdmltce,"_");
			tc_strcat(amdmltce,PlantName);
			
			printf("\nAM DML IN TCE : %s",amdmltce);fflush(stdout);
			if (tc_strstr(amdmltce,PlantName)!=NULL  && tc_strstr(amdmltce,"AM")!=NULL)
			{
				//WSOM_clear_search_criteria(&APLDMLCriteria);
				//tc_strcpy(APLDMLCriteria.name,amdmltce);
				//tc_strcpy(APLDMLCriteria.class_name,"T5_APLDMLRevision");
				//status	= WSOM_search(APLDMLCriteria, &apl_dml_found, &list_of_WSO_tags);
				//printf("\n apl_dml_found as per tce :%d",apl_dml_found);
				printf("\nSearch AMDML as per TCE, so item_is_apl_dml  rename : %s",amdmltce);fflush(stdout);
				item_id_apl_dml_str	=	NULL;
				item_id_apl_dml_str	=	(char *)MEM_alloc(tc_strlen(amdmltce)+25);
				tc_strcpy(item_id_apl_dml_str,amdmltce);
				printf("\nItem Id as per TCE : %s",item_id_apl_dml_str);fflush(stdout);

			}
			else
			 {
				//WSOM_clear_search_criteria(&APLDMLCriteria);
				//tc_strcpy(APLDMLCriteria.name,item_id_apl_dml_str);
				//tc_strcpy(APLDMLCriteria.class_name,"T5_APLDMLRevision");
				//status	= WSOM_search(APLDMLCriteria, &apl_dml_found, &list_of_WSO_tags);
				//printf("\n apl_dml_found as per tcua :%d",apl_dml_found);
				printf("\nSearch AM DML as per TCUA");fflush(stdout);
			 }
		}
		else
		{
			printf("\nCreateDMLINTCE cntrl not found");fflush(stdout);
		}
		

	}

		//Search Formed String of  AM DML in Db
		
	WSOM_clear_search_criteria(&APLDMLCriteria);
	tc_strcpy(APLDMLCriteria.name,item_id_apl_dml_str);
	tc_strcpy(APLDMLCriteria.class_name,"T5_APLDMLRevision");
	status	= WSOM_search(APLDMLCriteria, &apl_dml_found, &list_of_WSO_tags);
	printf("\n apl_dml_found:%d",apl_dml_found);

	if(apl_dml_found==0)
	{

		ITK_CALL( TCTYPE_find_type("T5_APLDML", NULL, &APLDTypeTag) );
		ITK_CALL( TCTYPE_construct_create_input(APLDTypeTag, &APLDCreInTag) );
		ITK_CALL( TCTYPE_find_type("T5_APLDMLRevision", NULL, &APLDRevTypeTag) );
		ITK_CALL( TCTYPE_construct_create_input(APLDRevTypeTag, &APLDRevCreInTag) );

		printf("\n 11APL_dml_name is : %s\n",WbsNameMain);fflush(stdout);
		printf("\n 11APL_dml_desc is : %s\n",WbsDescriptionMain);fflush(stdout);
		printf("\n 11APLDML is : %s\n",item_id_apl_dml_str);fflush(stdout);
	

		tc_strcpy( stringArrayAPLD[0], item_id_apl_dml_str);
		ITK_CALL( TCTYPE_set_create_display_value(APLDCreInTag, "item_id", 1,(const char**)stringArrayAPLD) );

		tc_strcpy( stringArrayAPLD[0], WbsNameMain);
		printf("\n 11APLDML Name  is : %s\n",WbsNameMain);fflush(stdout);
		ITK_CALL( TCTYPE_set_create_display_value( APLDCreInTag, "object_name", 1, (const char**)stringArrayAPLD) );
		tc_strcpy( stringArrayAPLD[0], WbsDescriptionMain);
		printf("\n 11APLDML desc is : %s\n",WbsDescriptionMain);fflush(stdout);
		ITK_CALL( TCTYPE_set_create_display_value( APLDCreInTag, "object_desc", 1, (const char**)stringArrayAPLD) );
		ITK_CALL( AOM_tag_to_string(APLDRevCreInTag, &tempString) );
		tc_strcpy( stringArrayAPLD[0], tempString);
		printf("\nTest0.D1..[%s]\n",stringArrayAPLD[0]);fflush(stdout);
		ITK_CALL( TCTYPE_set_create_display_value( APLDCreInTag, "revision", 1,(const char**)stringArrayAPLD) );

		tc_strcpy( stringArrayAPLD[0], "A");
		ITK_CALL( TCTYPE_set_create_display_value( APLDRevCreInTag, "item_revision_id", 1, (const char**)stringArrayAPLD) );

		printf("\nTest1..\n");fflush(stdout);

		ITK_CALL( TCTYPE_create_object(APLDCreInTag, &APLDMLTag) );

		printf("\nTest2..\n");fflush(stdout);
		printf("\nAPL DML Object created");
		AOM_save_without_extensions(APLDMLTag);
		ITK_CALL(ITEM_ask_latest_rev(APLDMLTag,&APLDMLRevTag));
		if (APLDMLRevTag!=NULLTAG)
		{
			printf("\nAPLDMLRevTag is not NULLTAG");
		}
		else
		{
			printf("\nAPLDMLRevTag is NULLTAG");
		}

		if (APLDMLTag!=NULLTAG)
		{
			printf("\nAPLDMLTag is not nulltag");
		}
		else
		{
			printf("\nAPLDMLTag is nulltag");
		}

		if (APLDMLTag != NULLTAG)
		{
			printf("\nForm APLDMLTag is not null");
			if(POM_attr_id_of_attr("item_id","T5_APLDML",&NewDMLAttrId));
			if(AOM_refresh(APLDMLTag,TRUE));
			if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			if(POM_set_attr_string(1,&APLDMLTag,NewDMLAttrId,item_id_apl_dml_str));
			if(AOM_save_without_extensions(APLDMLTag));
			if(AOM_refresh(APLDMLTag,TRUE));
			ITKCALL(tm_updateObjMasterFormName(APLDMLTag, item_id_apl_dml_str));//Update MASTER
			

		}

		if (APLDMLRevTag != NULLTAG)
		{
			printf("\n form APLDMLRevTag is not null tag");fflush(stdout);
			ITKCALL(tm_updateObjRevMasterFormName(APLDMLRevTag, item_id_apl_dml_str));
			if(POM_attr_id_of_attr("item_id","T5_APLDMLRevision",&NewDMLRevAttrId));
			if(AOM_refresh(APLDMLRevTag,TRUE));
			if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			if(POM_set_attr_string(1,&APLDMLRevTag,NewDMLRevAttrId,item_id_apl_dml_str));
			if(AOM_save_without_extensions(APLDMLRevTag));
			if(AOM_refresh(APLDMLRevTag,TRUE));

			char *ECNTyep="TOODMLR";
			printf("Stamping ECN Type to TOODMLR"); fflush(stdout);
			//ITK_CALL(AOM_set_value_string(APLDMLRevTag,"t5_EcnType",ECNTyep));

			ITK_CALL(POM_attr_id_of_attr("t5_EcnType","T5_APLDMLRevision",&DmlEcnRlzTypeAttrID));
			ITK_CALL(AOM_refresh(APLDMLRevTag,TRUE));
			ITK_CALL(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
			ITK_CALL(POM_set_attr_string(1,&APLDMLRevTag,DmlEcnRlzTypeAttrID,ECNTyep));
			ITK_CALL(AOM_save_without_extensions(APLDMLRevTag));
			ITK_CALL(AOM_refresh(APLDMLRevTag,TRUE));
            

			ITK_CALL(AOM_lock(APLDMLRevTag));

			printf("\n Set Project on AMDML %s and Design Grp : %s ",project,dsgnGrp); fflush(stdout);
			ITK_CALL(AOM_set_value_string(APLDMLRevTag,"t5_cprojectcode",project));
			ITKCALL(AOM_set_value_string(APLDMLRevTag,"t5_rlstype","TPL"));

			if(AOM_save_without_extensions(APLDMLRevTag));
			ITK_CALL( AOM_unlock(APLDMLRevTag) );
			if(AOM_refresh(APLDMLRevTag,TRUE));
			if(FlagPR==1)
			{
				char **prDesignGrp=NULL;
				NewDMLRevAttrId= NULLTAG;
				n_strings=2;

				prDesignGrp=(char **)malloc(n_strings * sizeof *prDesignGrp);

				for( index=0; index<n_strings; index++ )
				{
					prDesignGrp[index] = (char*)malloc( l_strings + 1 );
				}
				prDesignGrp[0]=dsgnGrp;
				prDesignGrp[1]="PR";
				ITK_CALL(AOM_lock(APLDMLRevTag));
				if(POM_attr_id_of_attr("t5_crdesigngroup","T5_APLDMLRevision",&NewDMLRevAttrId));
				if(AOM_refresh(APLDMLRevTag,TRUE));
				if(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));
				if(POM_set_attr_strings(1,&APLDMLRevTag,NewDMLRevAttrId,0,2,prDesignGrp));
				if(AOM_save_without_extensions(APLDMLRevTag));
				ITK_CALL( AOM_unlock(APLDMLRevTag) );
				if(AOM_refresh(APLDMLRevTag,TRUE));
			}
			else
			{
				ITK_CALL(AOM_lock(APLDMLRevTag));
				ITK_CALL ( AOM_set_value_string_at(APLDMLRevTag,"t5_crdesigngroup",0,dsgnGrp));
				if(AOM_save_without_extensions(APLDMLRevTag));
				ITK_CALL( AOM_unlock(APLDMLRevTag) );
				if(AOM_refresh(APLDMLRevTag,TRUE));
			}

			if(tc_strstr(item_id_apl_dml_str,"AM")!=NULL)
			{

				printf("\n Inside AMDML data updated\n");fflush(stdout);
				if(dvrNum!=NULL)
				{
					ITK_CALL( AOM_lock(APLDMLRevTag) );		
					ITK_CALL(AOM_set_value_string(APLDMLRevTag,"t5_DriverVC",dvrNum));
					if(AOM_save_without_extensions(APLDMLRevTag));
					ITK_CALL( AOM_unlock(APLDMLRevTag) );
					if(AOM_refresh(APLDMLRevTag,TRUE));
				}
			}
			
		}
		else
		{
			printf("\n AMDML Tag Not Found . EXIT From Functn"); fflush(stdout);
			return status;
		}
		//Create Task & Create Relation Inbetween DML & Task
		int num=0;

		printf("\n inside class T5_APLDML......\n");fflush(stdout);
		AOM_ask_value_string(APLDMLRevTag, "item_id", &item_id);

		AOM_ask_value_strings(APLDMLRevTag,"t5_crdesigngroup",&num,&DesignGroupList);
		AOM_ask_value_string(APLDMLRevTag, "t5_cprojectcode", &Proj_ID);

		printf("\n item_id : %s\n",item_id);fflush(stdout);
		printf("\n DML_no : %s\n",DML_no);fflush(stdout);
		printf("\n Design Grp Count is : %d\n",num);fflush(stdout);


		int j=0;
		for(j=0;j<num;j++)
		{
			DMLAPL= NULL;
			DML_no= NULL;
			tc_strcpy(item_id_apl_task,"");
			AOM_ask_value_string(APLDMLRevTag, "current_id", &DML_no);
			DMLAPL = strtok (DML_no,"_");
			Suffix = strtok (NULL,"_");
			printf("\n DMLAPL is : %s\n",DMLAPL);fflush(stdout);
			printf("\n Suffix is : %s\n",Suffix);fflush(stdout);

			tc_strcpy(item_id_apl_task,DMLAPL);
			tc_strcat (item_id_apl_task,"_");

			if(DesignGroupList!=NULL)
			{
				printf("\n Design Grp is %s",DesignGroupList[j]);
				if(tc_strcmp(DesignGroupList[j],"")!=0)
				{
					tc_strcat (item_id_apl_task,DesignGroupList[j]);
				}
				else
				{
					printf("\n Design Grp Not Found On APL DML revision "); fflush(stdout);
					status=0;
					return status;
				}
			}
			else
			{
				printf("\n DesignGroupList Tag Null"); fflush(stdout);
				status=0;
				return status;
			}

			tc_strcat (item_id_apl_task,"_");
			tc_strcat(item_id_apl_task,Suffix);

			printf("\n item_id_apl_task to Create :%s\n",item_id_apl_task);fflush(stdout);
			// Serch AM Task Exist in DB or Not
			WSOM_clear_search_criteria(&APLTaskCriteria);
			strcpy(APLTaskCriteria.name,item_id_apl_task);
			strcpy(APLTaskCriteria.class_name,"T5_APLTaskRevision");
			status	= WSOM_search(APLTaskCriteria, &apl_task_number_found, &list_of_WSO_tags);

			printf("\n apl_task_number_found %d\n",apl_task_number_found);fflush(stdout);

			if(apl_task_number_found==0)
			{
				ITK_CALL( TCTYPE_find_type( "T5_APLTask", NULL, &APLTTypeTag) );
				ITK_CALL( TCTYPE_construct_create_input( APLTTypeTag, &APLTCreInTag) );

				ITK_CALL( TCTYPE_find_type( "T5_APLTaskRevision", NULL, &APLTRevTypeTag) );
				ITK_CALL( TCTYPE_construct_create_input( APLTRevTypeTag, &APLTRevCreInTag) );

				tc_strcpy( stringArrayAPLT[0], item_id_apl_task);
				ITK_CALL( TCTYPE_set_create_display_value( APLTCreInTag, "item_id", 1,(const char**)stringArrayAPLT) );

				tc_strcpy( stringArrayAPLT[0], WbsNameMain);

				ITK_CALL( TCTYPE_set_create_display_value( APLTCreInTag, "object_name", 1,(const char**)stringArrayAPLT) );

				tc_strcpy( stringArrayAPLT[0], WbsDescriptionMain);
				ITK_CALL( TCTYPE_set_create_display_value( APLTCreInTag, "object_desc", 1,(const char**)stringArrayAPLT) );

				ITK_CALL( AOM_tag_to_string(APLTRevCreInTag, &tempStringt) );
				tc_strcpy( stringArrayAPLT[0], tempStringt);
				printf("\nTest0.4..[%s]\n",stringArrayAPLT[0]);fflush(stdout);
				ITK_CALL( TCTYPE_set_create_display_value( APLTCreInTag, "revision", 1,(const char**) stringArrayAPLT) );
				tc_strcpy( stringArrayAPLT[0], "A");
				ITK_CALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "item_revision_id", 1,(const char**)stringArrayAPLT) );
				
				tc_strcpy( stringArrayAPLT[0], dsgnGrp);
				ITK_CALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArrayAPLT) );
				tc_strcpy( stringArrayAPLT[0], project);
				ITK_CALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayAPLT) );

				printf("\n Value to set in apl_task_number %s:%s:%s:%s:%s:\n",item_id_apl_task,item_id_apl_dml_str,tempStringt,dsgnGrp,project);fflush(stdout);

				ITK_CALL( TCTYPE_create_object( APLTCreInTag, &APLTaskTag) );
				ITK_CALL( AOM_save_without_extensions(APLTaskTag) );

				ITK_CALL(ITEM_ask_latest_rev(APLTaskTag,&APLTaskRevTag));

                     

				if ((APLDMLRevTag != NULLTAG) && (APLTaskRevTag != NULLTAG))
				{
					int FndDMLTaskrelation=0;
					printf("\n CREATING REL OF APL DML & TASK...\n");fflush(stdout);

					ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
					ITK_CALL(GRM_find_relation(APLDMLRevTag, APLTaskRevTag, relation_type ,&FndDMLTaskrelation));
					if(FndDMLTaskrelation)
					{
						printf("\n\t Relation Already Exist b/w APLDML & Task :[%s],[%s]\n",item_id_apl_dml_str,item_id_apl_task);fflush(stdout);
						//fprintf(fpexception,"\n\t Relation Already Exist b/w APLDML & Task :[%s],[%s]\n",apldmlno,aplTaskno);
					}
					else
					{
						ITK_CALL(GRM_create_relation(APLDMLRevTag, APLTaskRevTag, relation_type,  NULLTAG, &apltaskrelation));
						ITK_CALL(GRM_save_relation(apltaskrelation));
					}
				}
				else
				{
					printf("\n Unable to CREATING REL OF APL DML & TASK...\n");fflush(stdout);
				}
			}
		}
	}

	if(list_of_WSO_tags!=NULLTAG)
	{
		MEM_free(list_of_WSO_tags);
	}
	// APL AMDML Tag
	*AMDmlObj=APLDMLRevTag;
	status=1;

	return status;
}

//End of AMDML Creation

void  GetPlantWiseRelStat( char * item_id ,char  getLCSSTDWrkg[40],char  getLCSSTDRlzd[40],char  getLCSSTDAthrig[40])
{

	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;

    printf( "item_id:%s\n", item_id);
	Dsgn_No=tc_strtok(item_id,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,item_id);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,item_id);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,item_id);
	//PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	if(tc_strcmp(PLT_Code,"APLP")==0)
    {
		tc_strcpy(getLCSSTDAthrig,"LcsSTDpAthrig");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDpWrkg");
		tc_strcpy(getLCSSTDRlzd,"T5_LcsStdpRlzd");
	}
	else if(tc_strcmp(PLT_Code,"APLD")==0)
	{
		tc_strcpy(getLCSSTDAthrig,"T5_LcsSTDdAthrig");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDdWrkg");
		tc_strcpy(getLCSSTDRlzd,"T5_LcsStddRlzd");
	}
	else if(tc_strcmp(PLT_Code,"APLC")==0)
	{
		tc_strcpy(getLCSSTDAthrig,"T5_LcsSTDAthrig");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDWrkg");
		tc_strcpy(getLCSSTDRlzd,"T5_LcsStdRlzd");
	}
	else if(tc_strcmp(PLT_Code,"APLJ")==0)
	{
		tc_strcpy(getLCSSTDAthrig,"T5_LcsSTDjAthrig");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDjWrkg");
		tc_strcpy(getLCSSTDRlzd,"T5_LcsStdjRlzd");
	}
	else if(tc_strcmp(PLT_Code,"APLL")==0)
	{
		tc_strcpy(getLCSSTDAthrig,"T5_LcsSTDlAthrig");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDlWrkg");
		tc_strcpy(getLCSSTDRlzd,"T5_LcsStdlRlzd");
	}
	else if(tc_strcmp(PLT_Code,"APLA")==0)
	{
		tc_strcpy(getLCSSTDAthrig,"T5_LcsSTDaAthrig");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDaWrkg");
		tc_strcpy(getLCSSTDRlzd,"T5_LcsStdaRlzd");
	}
	else if(tc_strcmp(PLT_Code,"APLU")==0)
	{
		tc_strcpy(getLCSSTDAthrig,"T5_LcsSTDuAthrig");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDuWrkg");
		tc_strcpy(getLCSSTDRlzd,"T5_LcsStduRlzd");
	}
	else if(tc_strcmp(PLT_Code,"APLS")==0)
	{
		tc_strcpy(getLCSSTDAthrig,"T5_LcsSTDsAthrig");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDsWrkg");
		tc_strcpy(getLCSSTDRlzd,"T5_LcsStdsRlzd");
	}
	else if(tc_strcmp(PLT_Code,"APLV")==0)
	{
		tc_strcpy(getLCSSTDAthrig,"T5_LcsSTDvAthrig");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDvWrkg");
		tc_strcpy(getLCSSTDRlzd,"T5_LcsStdvRlzd");
	}
	else
	{
		tc_strcpy(getLCSSTDAthrig,"T5_LcsSTDpAthrig");
		tc_strcpy(getLCSSTDWrkg,"T5_LcsSTDpWrkg");
		tc_strcpy(getLCSSTDRlzd,"T5_LcsStdpRlzd");
	}

    printf( "getLCSSTDAthrig:%s\n", getLCSSTDAthrig);
	printf( "getLCSSTDWrkg:%s\n", getLCSSTDWrkg);
	printf( "getLCSSTDRlzd:%s\n", getLCSSTDRlzd);

}

void  GetPlantForDMLORTask( char * item_id ,char  getPlant[40])
{
    printf( "item_id:%s\n", item_id);

	if(tc_strstr(item_id,"APLP")!=NULL)
    {
		tc_strcpy(getPlant,"APLP");
	}
	else if(tc_strstr(item_id,"APLD")!=NULL)
	{
		tc_strcpy(getPlant,"APLD");
	}
	else if(tc_strstr(item_id,"APLC")!=NULL)
	{
		tc_strcpy(getPlant,"APLC");
	}
	else if(tc_strstr(item_id,"APLJ")!=NULL)
	{
		tc_strcpy(getPlant,"APLJ");
	}
	else if(tc_strstr(item_id,"APLL")!=NULL)
	{
		tc_strcpy(getPlant,"APLL");
	}
	else if(tc_strstr(item_id,"APLA")!=NULL)
	{
		tc_strcpy(getPlant,"APLA");
	}
	else if(tc_strstr(item_id,"APLU")!=NULL)
	{
		tc_strcpy(getPlant,"APLU");
	}
	else if(tc_strstr(item_id,"APLS")!=NULL)
	{
		tc_strcpy(getPlant,"APLS");
	}
	else if(tc_strstr(item_id,"APLV")!=NULL)
	{
		tc_strcpy(getPlant,"APLV");
	}
	else
	{
		tc_strcpy(getPlant,"APLP");
	}

	printf( "getPlant:%s\n", getPlant);
}

void  GetPlantFromuserrole( char * userrole ,char  Plantname[50])
{
    printf( "userrole:%s\n", userrole);

	if(tc_strstr(userrole,"STDP")!=NULL)
    {
		tc_strcpy(Plantname,"APLP");
	}
	else if(tc_strstr(userrole,"STDD")!=NULL)
	{
		tc_strcpy(Plantname,"APLD");
	}
	else if(tc_strstr(userrole,"STDC")!=NULL)
	{
		tc_strcpy(Plantname,"APLC");
	}
	else if(tc_strstr(userrole,"STDJ")!=NULL)
	{
		tc_strcpy(Plantname,"APLJ");
	}
	else if(tc_strstr(userrole,"STDL")!=NULL)
	{
		tc_strcpy(Plantname,"APLL");
	}
	else if(tc_strstr(userrole,"STDA")!=NULL)
	{
		tc_strcpy(Plantname,"APLA");
	}
	else if(tc_strstr(userrole,"STDU")!=NULL)
	{
		tc_strcpy(Plantname,"APLU");
	}
	else if(tc_strstr(userrole,"STDS")!=NULL)
	{
		tc_strcpy(Plantname,"APLS");
	}
	else if(tc_strstr(userrole,"STDV")!=NULL)
	{
		tc_strcpy(Plantname,"APLV");
	}
	else
	{
		tc_strcpy(Plantname,"APLP");
	}

	printf( "Plantname:%s\n", Plantname);
}

/***************************************************************************************
*FUNCTION NAME: tm_fnd_Prev_Official_Revision
*ARGUMENT: *req_item(DESIGN REVISION - PART NUMBER), t_currentRevision(CURRENT REVISION), *t_previousRevision(RETURN PREVIOUS REVISION)
**req_item - QUERY THE DESIGN REVISION(PART).
*FIND THE ALL AVAILABLE REVISION OF THE DESIGN REVISION.
*t_currentRevision - FETCH THE CURRENT REVISION OF THE DESIGN REVISION FROM t_currentRevision, WHICH WILL USED TO COMPARE THE REVISION.
*COMPARE ALL AVAIALBE REVISION WITH CURRENT DESIGN REVISION, IF MATCH FOUND SET THE FLAG RevFlag =	1.
*ONCE THE RevFlag =	1, THEN COMPARE THE PREVIOUS REVISION WITH CURRENT REVISION AND SER THE FLAG PreRevFlag =	1.
*ONCE THE PreRevFlag =	1, THEN FIND THE LATEST SEQUENCE OF THE PREVIOUS REVISION AND RETURN WITH TAG t_previousRevision.
*IF t_currentRevision IS NR, THEN IT WILL BE HANDLE WILL CALLING THE FUNCTION.
*/
void tm_fnd_Prev_Official_Revision(char	*req_item,tag_t t_currentRevision, tag_t* t_previousRevision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		PreRevFlag 			=	0;
	int		ii					=	0;
	int		n_tags_found		=	0;

	char	*Part_Rev			=	NULL;
	char	*Part_Rev_copy		=	NULL;
	char	*Part_rev_Id		=	NULL;
	char	*RevOnly			=	NULL;
	char	*PreRevOnly			=	NULL;
	char	*Part_prev_rev_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;

	printf("\ntm_fnd_prev_revision called : %s",req_item);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev_copy));
	printf("\n Part_Rev_copy: %s\n",Part_Rev_copy);fflush(stdout);

	//ITK_CALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
	ITK_CALL(AOM_ask_value_tags(t_currentRevision,"revision_list",&Item_count,&rev_list));
	printf("\nNo of Item : %d",Item_count);fflush(stdout);

	if(Item_count > 0)
	{
		RevFlag		=	0;
		PreRevFlag	=	0;

		for(ii=Item_count-1;ii>=0;ii--)
		{
			RevOnly		=	NULL;
			PreRevOnly	=	NULL;

			ITK_CALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

			printf("\nPart_Rev %s and Part_rev_Id: %s\n",Part_Rev,Part_rev_Id);fflush(stdout);
			//Bypass for one case
			
			if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
			{
				RevFlag = 1;
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			if(RevFlag == 1)
			{
				RevOnly		= strtok( Part_Rev_copy, ";" );
				PreRevOnly	= strtok( Part_rev_Id, ";" );
				printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
				printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
				if(tc_strcmp(RevOnly,PreRevOnly)!=0)
				{
					PreRevFlag = 1;
				}
				if(PreRevFlag == 1)
				{
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					ITK_CALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_prev_rev_Id));
					printf("\n Part_prev_rev_Id: %s\n",Part_prev_rev_Id);fflush(stdout);
					*t_previousRevision	=	rev_list[ii];
					break;
				}
			}
		}
		if(PreRevFlag == 0)
		{
			*t_previousRevision	=	t_currentRevision;
		}
	}
}


//Expand Bom Recursively
void Multi_Get_Part_BOM_LvlAM(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	printf("\n ViewBVR=>[%s] ...\n",ViewBVR);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITKCALL(ITEM_rev_list_bom_view_revs(inputPart, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

	if(n_values_bvr==0)
	{
		flagBVR=0;
	}
	else if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				//if(tc_strcmp(viewTok,"View")==0)
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					flagBVR=1;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		if(flagBVR!=1)
		{
			//Added by Vaibhav
			ITKCALL(AOM_ask_value_string(bvr_assy_part[0],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			printf("\n viewTok ViewBVR not matched...\n");fflush(stdout);
			ViewBVR = (char *)MEM_alloc(100);
			tc_strcpy(ViewBVR,viewTok);
			printf("\n M Pass View as %s",ViewBVR);fflush(stdout);
			flagBVR=1;
			bvr_tag=bvr_assy_part[0];
			//Commented by Vaibhav
			/* for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					if(tc_strcmp(viewTok,"View")==0)
					{
						flagBVR=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			} */
		}

	}
	printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));
	ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITKCALL(BOM_set_window_pack_all (window, true));
	if(flagBVR==1)
	{
		BOM_set_window_top_line(window, null_tag,inputPart ,bvr_tag, &top_line);
		//ITKCALL(BOM_window_hide_suppressed(window));
		ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n; k++)
		{
			BOM_line_unpack (children[k]);
			//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			//BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
			AOM_ask_value_tag(children[k],bomAttr_lineItemRevTag, &t_ChildItemRev);
			
			if(t_ChildItemRev!=NULLTAG)
			{
				AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);
				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; Hemal
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;

				Multi_Get_Part_BOM_LvlAM(t_ChildItemRev,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;
	}

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}
int Get_Part_BOM_LvlAM(tag_t VehicleObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1=0;
	int n=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	int level 				= 0;
	tag_t	window 				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	objChild			= NULLTAG;
	tag_t	objChild_bvr			= NULLTAG;
	int child_lvl=0;
	char	*c_Qty						=	NULL;
	tag_t  *children1=NULLTAG;
	int iChildItemTag=0;
	int assbvr=0;
	int bvrfound=0;
	int flagRevRule=0;
	int flagClosureRule=0;
	char *view_name=NULL;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;

	printf("\nInside Get_Part_BOM_Lvl ....\n");

	if(VehicleObj == NULLTAG)
	{
		printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	CALLAPI(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
	printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);

	ITKCALL(ITEM_rev_list_bom_view_revs(VehicleObj, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					bvrfound++;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		//Added by Hemal, same need to check and add in common file also.
		if(bvrfound!=1)
		{
			//Added By Vaibhav
			printf("\n view_name not matched with cntrlobj bom view Name \n");fflush(stdout);
			ITKCALL(AOM_ask_value_string(bvr_assy_part[0],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			ViewBVR = (char *)MEM_alloc(100);
			tc_strcpy(ViewBVR,viewTok);
			printf("\n Pass View as %s",ViewBVR);fflush(stdout);
			bvrfound=1;
			bvr_tag=bvr_assy_part[0];
			//Commented By Vaibhav
			/* for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITKCALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					if(tc_strcmp(viewTok,"View")==0)
					{
						bvrfound=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			} */
		}
		//Ended by Hemal

	}

	printf("\n bvrfound=>[%d] ",bvrfound);fflush(stdout);
	if(bvrfound==0)
	{
		printf("\n**********BVR NOT Exist*********\n");fflush(stdout);
	}
	else
	{
		CALLAPI(CFM_find(revRuleName, &revRule));
		if (revRule != NULLTAG)
		{
			printf("\nFind revRule\n");fflush(stdout);
			flagRevRule=1;
		}

		scope=PIE_TEAMCENTER;
		CALLAPI(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
			flagClosureRule=1;
		}
		printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
		printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
		if((flagClosureRule==1) && (flagRevRule==1))
		{

			Multi_Get_Part_BOM_LvlAM(VehicleObj,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
		}
		else
		{
			printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
		}

	}
	printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);

	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		child_lvl       =0;

		printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;

		AOM_ask_value_string(objChild,"item_id",&ItemName);
		printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		printf("\nQty==>%s\n",c_Qty);fflush(stdout);

	}
	return ifail;
}

extern int ITK_user_main (int argc, char ** argv )
{

	printf("into main function\n");fflush(stdout);
	int ifail = ITK_ok;
	int status=0;

	char*  Inpt_item_id		= NULL;
	char*  Inpt_item_rev	= NULL;

	int n_tags_found=0;
	int ii=0;
    int		max_char_size = 100;
	const char* u = NULL;
	const char* p = NULL;
	const char* g = NULL;

	char* inputVCNo     = NULL;
	char *inputVCNoRev  = NULL;
	char* userName  = NULL;
	char *userRole  = NULL;

	const char* argstring3 = NULL;
	const char* argstring4 = NULL;
	char  getLCSSTDWrkg[40];
	char  getLCSSTDRlzd[40];
	char  getLCSSTDAthrig[40];

	char *ClosureDatetsk	 = NULL;

	tag_t		*t_item				= NULLTAG;
	tag_t		partrev_tag			= NULLTAG;

	int         n_entries=2;
	int     	n_found=0;
	tag_t       query 	      = NULLTAG;
	tag_t       PersonFindquery		=NULLTAG;
	tag_t 		UsrFindquery  = NULLTAG;
	//tag_t	 	GmTaskObj     = NULLTAG;
	tag_t       *results=NULL;

	tag_t     *usrObjSet		= NULLTAG;
	tag_t     *PersnObjSet		= NULLTAG;
	tag_t     usrObjTag    		= NULLTAG;
	char 	  *usrEmailAddr 	= NULLTAG;
	char      *usrLocation  	= NULLTAG;
	tag_t  InPartVCExpTag      = NULLTAG;

	int personFound=0;
	WSO_search_criteria_t  personQryCriteria;
	char  *personName			  = NULLTAG;
	tag_t  *list_of_person_tags   = NULLTAG;

	userName=(char *) MEM_alloc(200 * sizeof(char *));
	userRole=(char *) MEM_alloc(200 * sizeof(char *));
	inputVCNo=(char *) MEM_alloc(200 * sizeof(char *));
	inputVCNoRev=(char *) MEM_alloc(200 * sizeof(char *));

	struct  struct_PartrlzSkp   UnqSetrlzPart[10000];
    struct	BomChldStrut	VcAllChildPartSet[10000];
	//struct	BomChldStrut_Impl	VcAllChildPartSet[10000];
	struct  structre_PartTagSet PartObjectSet[10000];
	struct  struct_PartPRTagSet PRpartObjectSet[10000];
	struct  struct_PartSetSkp   UnqSetSkpPart[10000];
	struct  struct_PartDRSkp   DRSetSkpPart[10000];

	tag_t		envelope				= NULLTAG;
	tag_t		*recievers				= NULLTAG;
	int countenvelop=0;
	//char env_subject[300] = {'\0'};
	//char env_body[90000]= {'\0'};
	char *env_subject = NULL;
	char *env_body = NULL;

	//Counter Destination For Sets To -1 As Empty
	int CountPartObjectSet = -1;
	int countPrPartSet     = -1;
	int partSkpCounter	   =-1 ;
	//-1 for empty Set
	int totalChldPartCount=0;
	int partrlzCounter	   =-1 ;
    u = ITK_ask_cli_argument( "-u=");
	//p = ITK_ask_cli_argument( "-pf=");
	p=ITK_ask_cli_argument( "-p=");//indira
	g = ITK_ask_cli_argument( "-g=");

	tc_strcpy(inputVCNo,ITK_ask_cli_argument("-part="));
	tc_strcpy(inputVCNoRev,ITK_ask_cli_argument("-rev="));
	tc_strcpy(userName,ITK_ask_cli_argument("-user="));
	tc_strcpy(userRole,ITK_ask_cli_argument("-role="));


	printf("\n ITK Code Execution Started For AMDML Creation for Module");

    printf("\n UserID  [%s]", u);fflush(stdout);
	printf("\n Password [%s] ", p);fflush(stdout);
	printf("\n Grp Name [%s] \n",g); fflush(stdout);

	printf("\n Part Number for DML Creation [%s] ", inputVCNo);fflush(stdout);
	printf("\n Part Revision for DML Creation [%s] ", inputVCNoRev);fflush(stdout);
	printf("\n User Name for AMDML Creation [%s] \n",userName); fflush(stdout);
	printf("\n User Role for AMDML Creation [%s] \n",userRole); fflush(stdout);

	
    char *AmDmlLogFle=             NULL;
    char *dmlPendinginUsrList=     NULL;
	char *fullPath=                NULL;
	char *dmlPendinginUsrListName= NULL;
	AmDmlLogFle= (char *)MEM_alloc(max_char_size * sizeof(char));
	FILE *fpAmDmlCreate=NULL;
	FILE *fpdmlPendinginUsrList=NULL;					
	dmlPendinginUsrList= (char *)MEM_alloc(max_char_size * sizeof(char));	
	fullPath= (char *)MEM_alloc(max_char_size * sizeof(char));	
	dmlPendinginUsrListName= (char *)MEM_alloc(max_char_size * sizeof(char));	
	tag_t datasettype_tag= NULLTAG;
	tag_t default_tool_tag;
	tag_t relation_type;
	tag_t tDataset;
	int count_dataSet= 0;
	
	char **list;
	tag_t imannewFileTag = NULLTAG;
	tag_t Fndrelation = NULLTAG;
	tag_t  relation = NULLTAG;		
	IMF_file_t filedescriptor;
	tag_t   qryTagCntrl1     = NULLTAG;
	int     n_entryCntrl1    = 2;
	int control_number_found1=0;
	char    *qry_entryCntrl1[2]  = {"SYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t *list_of_WSO_cntrl_tags1=NULLTAG;
	char *filrPathServer=NULL;

	int ch;
	struct tm *timeptr;
	char pAccessDate[20];
	time_t	temp;
	//DR Variable
	char *prtLsstdrlzName			=NULL;
	char *fullPathDR				=NULL;
	char *prtLsDrList				=NULL;
	char *prtLsDrListName			=NULL;
	char *prtLsstdrlz				=NULL;
	char *fullPathrlz				=NULL;
	FILE *fpdrLsList=NULL;					
	fullPathDR= (char *)MEM_alloc(max_char_size * sizeof(char));	
	prtLsDrList= (char *)MEM_alloc(max_char_size * sizeof(char));	
	prtLsDrListName= (char *)MEM_alloc(max_char_size * sizeof(char));	
	FILE *fppartrlzList=NULL;
    prtLsstdrlzName= (char *)MEM_alloc(max_char_size * sizeof(char));
	prtLsstdrlz= (char *)MEM_alloc(max_char_size * sizeof(char));
    fullPathrlz= (char *)MEM_alloc(max_char_size * sizeof(char));
    tag_t datasettyperlz_tag	= NULLTAG;
	tag_t default_tool_rlz_tag	=	NULLTAG;
	tag_t tDatasetrlz	=	NULLTAG;
	tag_t imannewFileTagrlz = NULLTAG;
	int count_dataSetrlz= 0;
	char **listrlz;
	IMF_file_t filedescriptorrlz;

	tag_t datasettypeDR_tag	= NULLTAG;
	tag_t default_tool_DR_tag	=	NULLTAG;
	tag_t tDatasetDR	=	NULLTAG;
	tag_t imannewFileTagDR = NULLTAG;
	int count_dataSetDR= 0;
	char **listDR;
	IMF_file_t filedescriptorDR;
    int reqLvl=99;	
	char *plantaplwrkg			=NULL;
	char *plantaplrlz			=NULL;
	char *plantstdwrg			=NULL;
	char *plantstdrlz			=NULL;
	char *ClosureRName			=NULL;
	char *RevisionRName		=NULL;
	char *ViewBVR				=NULL;
	char *partItemName			=NULL;
	char *partType				=NULL;
	char *partdsgndrp	=	NULL;
    char *projectcode	=	NULL;
	char  PlantName[50];
	// Start Code to Explode BOM -2 TESING FOR BOM-EXPLODE
	plantaplwrkg=(char *) MEM_alloc(200 * sizeof(char *));
	plantaplrlz=(char *) MEM_alloc(200 * sizeof(char *));
	plantstdwrg=(char *) MEM_alloc(200 * sizeof(char *));
	plantstdrlz=(char *) MEM_alloc(200 * sizeof(char *));
	ClosureRName=(char *) MEM_alloc(200 * sizeof(char *));
	RevisionRName=(char *) MEM_alloc(200 * sizeof(char *));
	char *PlantOneChar		= NULL;
	ViewBVR=(char *) MEM_alloc(100 * sizeof(char *));
	char* viewtocpy		= NULL;

	tag_t   qryTagCntrl     = NULLTAG;
	int     n_entry   = 3;
    int  control_found=0;	 
	tag_t *list_of_cntrl_tags=NULLTAG;
	partSkpCounter		=	-1;
	CountPartObjectSet	=	-1;
	countPrPartSet		=	-1;
    partrlzCounter		=	-1;
    char  *PartNum		    = NULL;
	char  *PartCreationDate			= NULL;
	char  *partItemRevision		    = NULL;
	int  *partItemRevSeq  			= NULL;
	char  *epaPlantName				= NULL;
	char  *epaLifeCycle				= NULL;
	char  *TaskItemName				= NULL;
	char  *partRevisionID				= NULL;
	char  *PartRev				= NULL;
	char  *partDRStatuss				= NULL;
	char  *PartRevName					= NULL;
	char  *taskClosureTime				= NULL;
	char  *taskLifeCycle				= NULL;
	char  *DmlEcnTypDup				= NULL;
	char  *attchDmlName				= NULL;
	char  *DmlClosureDate				= NULL;
	char  *DmlLCSDup					= NULL;
	char  *PartSelctdItemRevName		= NULL;
	char  *PartSelctdItemRevision		= NULL;

	char	*PrtDRst					=	NULL;
    char	*epaTaskId					=	NULL;
	char	*epanum					=	NULL;
	char	*epatasknum					=	NULL;
	char	*jdlstorelocation			=	NULL;
	//char  RlzStatusName[40];
	//char  stdRlzStatusName[40];
	char  getTaskPlantName[40];
	char*	RlzStatusName	=	NULL;
	char*	stdRlzStatusName	=	NULL;
	

	tag_t *EPATaskRevList			    = NULLTAG;
	tag_t *EPARevList					= NULLTAG;
	tag_t *dmlRevTagList				= NULLTAG;

	tag_t	dmlRevTag					= NULLTAG;
	tag_t epatask_part_rel_type	    = NULLTAG;
	tag_t epaRevTag					= NULLTAG;
	tag_t taskRevTag					= NULLTAG;
	tag_t revstatus	   			    = NULLTAG;
	//char   type_name[TCTYPE_name_size_c+1];
	//char   type_class[TCTYPE_name_size_c+1];
	char *type_class = NULL;
	tag_t	itemTypeTag_class			= NULLTAG;
	tag_t prevBrkTsakObj				= NULLTAG;
	tag_t prevRevPartTag				= NULLTAG;
	tag_t t_previousRevision			= NULLTAG;

	tag_t epatask_Rev_rel_type			= NULLTAG;
	tag_t task_dml_rel_type			= NULLTAG;

	tag_t *status_list					= NULL;
	tag_t *status_liststd				= NULL;
	int cntstd=0;
	//logical	lPrtRevFnd				=	false;
	n_entries=2;
	int cnt=0;
	int lcsflag=0;
	char   *releasestatus=NULL;
	//index Declaration
	int totalTaskcount=0,taskCnt=0,epaCnt=0,j=0,revCnt=0,setIndex=0,tskIndx=0,totalDmlCnt=0,NStatus=0,count=0,stdstatus=0;

	//Flag Declaration
	int IsEpaflg=0,PrevFlag=0,flagPartTagFound=0,flagClosure=0,flgtaskwrk=0,flgdmlwrk=0,flgpartrlz=0;


	tag_t 	*TaskRevList				= NULL;
	tag_t   task_part_rel_type			= NULLTAG;
	int 	totalAttchtskCnt=0;
	int     num_to_sort =1;
	char    *keys[1] = {"creation_date"};
	int  	orders[1]  ={2};


	//ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	//ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_auto_login( ));

	printf("\n getCurrentDateTime calling..........\n");fflush(stdout);
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%b_%Y_%H_%M",timeptr);

	printf("Current Time %s",pAccessDate);fflush(stdout);

	tc_strcpy(AmDmlLogFle,"/tmp/AmDmlCrtlog_");
	tc_strcat(AmDmlLogFle,inputVCNo);
	tc_strcat(AmDmlLogFle,"_");
	tc_strcat(AmDmlLogFle,pAccessDate);

	tc_strcat(AmDmlLogFle,".txt");


	fpAmDmlCreate = fopen(AmDmlLogFle, "w");

	if(fpAmDmlCreate==NULL)
	{
		printf("\n Unable to Create Log File on Server %s ",AmDmlLogFle); fflush(stdout);
		return ifail;
	}

	if(tc_strstr(userRole,"DBA")!=NULL)
	{
		printf("\n Bypass Allowed to DBA Role "); fflush(stdout);
	}
	else if(tc_strstr(userRole,"_STD")==NULL)
	{
		fprintf(fpAmDmlCreate,"\n User Role Not Set As STD Client Code return As Functionality provided to STD User Only inputeRole[%s]",userRole); fflush(stdout);
		//fprintf(,"");
		return ifail;
	}
     
	
	GetPlantFromuserrole(userRole,PlantName);

	printf("\n user plant is  =%s",PlantName);fflush(stdout);
	
		PlantOneChar=subString(PlantName,3,1);
	printf("\n PlantOneChar:%s",PlantOneChar);fflush(stdout);
	tc_strcpy(ViewBVR,"");  
	tc_strcat(ViewBVR,"APL");
	tc_strcat(ViewBVR,PlantOneChar);
	tc_strcat(ViewBVR," View");
	printf("\n ViewBVR is : %s\n",ViewBVR);fflush(stdout);

	char *Analyst_email_addr  = NULL;
	tag_t Analyst_user_tag  = NULLTAG;
	tag_t Analyst_person_tag  = NULLTAG;
	tag_t tc_group  = NULLTAG;
	char	*usergroup				=	NULL;
	ITK_CALL(SA_find_user2 (userName, &Analyst_user_tag));
   printf("\n user role is =%s",userRole);fflush(stdout);

					if(tc_strstr(userRole,"STDP")!=NULL)
					{
						tc_strcpy(usergroup,"STDPUNE");					
					}
					else if(tc_strstr(userRole,"STDD")!=NULL)
					{
						tc_strcpy(usergroup,"STDDWD");
					}
					else if(tc_strstr(userRole,"STDC")!=NULL)
					{
						tc_strcpy(usergroup,"STDCAR");						
					}
					else if(tc_strstr(userRole,"STDJ")!=NULL)
					{
						tc_strcpy(usergroup,"STDJSR");
					}
					else if(tc_strstr(userRole,"STDL")!=NULL)
					{
						tc_strcpy(usergroup,"STDLKO");
					}
					else if(tc_strstr(userRole,"STDA")!=NULL)
					{
						tc_strcpy(usergroup,"STDAHD");
					}
					else if((tc_strstr(userRole,"STDU")!=NULL))
					{
						tc_strcpy(usergroup,"STDPNR");
					}
					else
					{
						printf("\n user group not found");fflush(stdout);
					}

	ITK_CALL(SA_find_group(usergroup,&tc_group));
    printf("\n user group is =%s",usergroup);fflush(stdout);


	ITK_CALL(AOM_ask_value_tag(Analyst_user_tag,"person",&Analyst_person_tag));

	ITK_CALL(SA_ask_person_email_address(Analyst_person_tag,&Analyst_email_addr));
	printf("\n Person EMAIL Address =%s",Analyst_email_addr);fflush(stdout);

       char	**qry_valuesformat= (char **) MEM_alloc(5 * sizeof(char *));
	   tag_t   qryTagobj     = NULLTAG;
	   int Objfound=0;
	   int cntt=0;
	   int n_entryobj=3;
	   tag_t *list_of_part_tags=NULLTAG;
		    
             STRNG_replace_str(inputVCNoRev,";","*",&inputVCNoRev);
              
              printf("final part rev: %s",inputVCNoRev);fflush(stdout);
		    
             ITK_CALL(QRY_find2("Item Revision...", &qryTagobj));
             if (qryTagobj)
	         {
		    
	           char
	           *qry_entryformat[3] = {"Item ID", "Type","Revision"},
	           *qry_valuesformat[3] =  {inputVCNo, "Design Revision",inputVCNoRev};
		    
	           printf("\n Execute qryTagobj...\n");fflush(stdout);
	           QRY_execute(qryTagobj, n_entryobj, qry_entryformat, qry_valuesformat, &Objfound, &list_of_part_tags);
               printf(" no of rev found: %d\n",Objfound);fflush(stdout);
		    
              if(Objfound>0)
	          {
	     		InPartVCExpTag=NULLTAG;
	     		InPartVCExpTag=list_of_part_tags[0];
	          }
	        }


	//Inpute Part Expansion Logic

	 printf("\n plant name is : %s\n",PlantName);fflush(stdout);
     if(QRY_find2("Control Objects...", &qryTagCntrl)); //sachin
     
	 if (qryTagCntrl)
			{
		         char    
	             *qry_eCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"},
	             *qry_vCntrl[3]={"APLStateInf",PlantName,"0"};
				 printf("\n Control Object Query Found \n");fflush(stdout);
			
				
				if(QRY_execute(qryTagCntrl, n_entry, qry_eCntrl, qry_vCntrl, &control_found, &list_of_cntrl_tags));
			}
			else
			{
				printf("\n Control Object Query not Found  \n");fflush(stdout);
			}	
			
			printf("\n control_number_found is : %d\n",control_found);fflush(stdout);

			if(control_found>0)
			{
				AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo2", &plantaplwrkg);
				printf("\n plantaplwrkg: %s\n",plantaplwrkg);fflush(stdout);
				
				AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo3", &plantaplrlz);
				printf("\n plantaplrlz: %s\n",plantaplrlz);fflush(stdout);

				AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo4", &plantstdwrg);
				printf("\n plantstdwrg: %s\n",plantstdwrg);fflush(stdout);

				AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo5", &plantstdrlz);
				printf("\n plantstdrlz: %s\n",plantstdrlz);fflush(stdout);

				AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo8", &RevisionRName);
				printf("\n RevisionRName: %s\n",RevisionRName);fflush(stdout);

				AOM_ask_value_string( list_of_cntrl_tags[0], "t5_Userinfo9", &ClosureRName);
				printf("\n ClosureRName: %s\n",ClosureRName);fflush(stdout);
			}


	    ITK_CALL(AOM_ask_value_string(InPartVCExpTag,"item_id",&partItemName));
	    printf("\n input part num:%s",partItemName);fflush(stdout);
	    char	*object_type	=	NULL;
	    ITK_CALL(AOM_ask_value_string(InPartVCExpTag,"object_type",&object_type));
	    printf("111 object_type: %s",object_type);fflush(stdout);
	    AOM_ask_value_string(InPartVCExpTag,"t5_PartType",&partType);
	    printf("\n1111 Part type : %s",partType);fflush(stdout);
	    AOM_ask_value_string(InPartVCExpTag,"t5_ProjectCode",&projectcode);
	    printf("\n project code : %s",projectcode);fflush(stdout);
        AOM_ask_value_string(InPartVCExpTag,"t5_DesignGrp",&partdsgndrp);
	    printf("\n input part design grp : %s",partdsgndrp);fflush(stdout);
	    
	    totalChldPartCount	= 0;
		
	    if((strcmp(partType,"VC")==0 || strcmp(partType,"V")==0 || strcmp(partType,"A")==0 || strcmp(partType,"R")==0 || strcmp(partType,"C")==0 || strcmp(partType,"M")==0 || strcmp(partType,"T")==0 || strcmp(partType,"G")==0) && InPartVCExpTag!=NULLTAG) //TCE-Sunset Related Changes.
	    {
	    	//Get_Part_BOM_Lvl_ImplAM(InPartVCExpTag,reqLvl,ClosureRName,RevisionRName,ViewBVR,VcAllChildPartSet,&totalChldPartCount);
			
			ITK_CALL(Get_Part_BOM_LvlAM(InPartVCExpTag,reqLvl,ClosureRName,RevisionRName,ViewBVR,VcAllChildPartSet,&totalChldPartCount));
	    }
  	    
	    printf("\n **Total Child Part Found in VC is:%d \n",totalChldPartCount);
	    fprintf(fpAmDmlCreate,"\n  Total Child Part Found in VC is :%s  total Count %d",inputVCNo,totalChldPartCount);
	    
	    //Code Checking All previous of Child Parts    	    
	    			if(InPartVCExpTag!=NULLTAG)
					{
						CountPartObjectSet++;
						PartObjectSet[CountPartObjectSet].PartTag= InPartVCExpTag;
						tc_strcpy(PartObjectSet[CountPartObjectSet].PrtItemName,partItemName);
						printf("\n Part added in set : %d",CountPartObjectSet);fflush(stdout);
					}
	    
	    if(totalChldPartCount>0)
	    {		  
		  for (j=1;j<=totalChldPartCount ;j++ )
		  {
			tag_t PartTag=NULLTAG;
			flagClosure=0;
            partItemName=NULL;
			tag_t	queryPartrev	=	NULLTAG;
			int		n_entriesrev	=	3;
			int    	num_to_sortrev =	1;
			char 	*keysrev[1] 	= 	{"creation_date"};
			int  	ordersrev[1]  	=	{2};
			int		n_foundrev		=	0;
			tag_t   *resultsrev	=	NULL;

			PartTag=VcAllChildPartSet[j].child_objs;

			ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&partItemName));
			
		     ITK_CALL(QRY_find2("Item Revision...", &queryPartrev));
	    
	        char *qry_rev_entries[3] = {"Item ID","Type","Release Status"};
            char *qry_rev_values[3] = {partItemName,"Design Revision",plantaplrlz};
			
			QRY_execute_with_sort(queryPartrev, n_entriesrev, qry_rev_entries, qry_rev_values, num_to_sortrev, keysrev, ordersrev, &n_foundrev, &resultsrev);
			printf("\n Total Revision found in DB above APL Released  %s: total Revision :%d",partItemName,n_foundrev);fflush(stdout);

			// Checking For Any EPA Present on Latest Revision if so then select Previous Revision to Transfer in SAP/attach to AMDML
														
			 for(revCnt=0;revCnt<n_foundrev;revCnt++)
			 {
				tag_t PartrevisionTag;
				totalTaskcount=0;
				IsEpaflg=0;

				PartrevisionTag=resultsrev[revCnt];
				
				PartNum	=	NULL;
				partItemRevision	=	NULL;
				partItemRevSeq		=	NULL;
				PrtDRst				=	NULL;
				jdlstorelocation				=	NULL;
				
				ITK_CALL(AOM_ask_value_string(PartrevisionTag,"item_id",&PartNum));

				ITK_CALL(AOM_ask_value_string(PartrevisionTag,"item_revision_id",&partItemRevision));

				ITK_CALL(AOM_ask_value_int(PartrevisionTag,"sequence_id",&partItemRevSeq));
				printf("\n Item Rev :%s,%s,%d",partItemName,partItemRevision,partItemRevSeq);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(PartrevisionTag,"t5_PartStatus",&PrtDRst));
				printf("\nPart number : %s, revision : %s, DR status : %s",partItemName,partItemRevision,PrtDRst);fflush(stdout);

                ITK_CALL(AOM_ask_value_string(PartrevisionTag,"t5_JdlStoreLocation",&jdlstorelocation));
				printf("\n jdlstorelocation is :%s",jdlstorelocation);fflush(stdout);
				
				if(tc_strstr(jdlstorelocation,"EPA") != NULL)
				{
					printf("\n EPA found on part in TCE");fflush(stdout);
					continue;					
				}
				
				ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &epatask_part_rel_type));
				ITK_CALL(GRM_list_primary_objects_only(PartrevisionTag,epatask_part_rel_type,&totalTaskcount,&EPATaskRevList));
				printf("\n task Count :%d",totalTaskcount);fflush(stdout);
				if(totalTaskcount>0)
				{
					for(taskCnt=0;taskCnt<totalTaskcount;taskCnt++)
					{
						taskRevTag=EPATaskRevList[taskCnt];
						ITK_CALL (TCTYPE_ask_object_type(taskRevTag,&itemTypeTag_class));
						ITK_CALL (TCTYPE_ask_name2(itemTypeTag_class,&type_class));
						printf("\t  type_itemRev ...%s\n", type_class);fflush(stdout);

						
						if(tc_strcmp(type_class,"T5_EPATaskRevision")==0)
						{
							ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &epatask_Rev_rel_type));
							ITK_CALL(GRM_list_primary_objects_only(taskRevTag,epatask_Rev_rel_type,&epaCnt,&EPARevList));
							ITK_CALL(AOM_ask_value_string(taskRevTag,"item_id",&epanum));
                            printf("\n EPAtaskRev is-->[%s]\n",epanum);fflush(stdout);

							if(epaCnt>0)
							{
								epaPlantName=NULL;
                                epaRevTag=NULLTAG;
								epaRevTag=EPARevList[0];
								ITK_CALL(AOM_ask_value_string(epaRevTag,"t5_EpaPlantA",&epaPlantName));
								ITK_CALL(AOM_ask_value_string(epaRevTag,"item_id",&epatasknum));
                                printf("\n EPANum is-->[%s]\n",epatasknum);fflush(stdout);
								printf("\n Inside MM_ReleaseRevision::epaPlantName-->[%s]\n",epaPlantName);fflush(stdout);

								ifail=WSOM_ask_release_status_list(epaRevTag,&count,&status_list);
								printf("\n Inside MM_ReleaseRevision:: release status found count-->[%d]\n",count);fflush(stdout);
								if(count>0)
			                    {
			                    	for (cnt=0;cnt< count;cnt++ )
			                    	{   
										lcsflag=0;
			                    		releasestatus=NULL;
			                    		ITKCALL(AOM_ask_name(status_list[cnt],&releasestatus));
			                    		printf("\n releasestatus is :%s\n",releasestatus);fflush(stdout);
			                    		if(tc_strcmp(releasestatus,"")!=0)
			                    		{
			                    				if (tc_strcmp(releasestatus,plantstdwrg)==0)
			                    				{
			                    					lcsflag = 1;
			                    				}
			                    		}
			                    	}
			                    }
								          	
								 printf("\n lcsflag is --> [%d]",lcsflag);fflush(stdout);
								       
								 if((tc_strstr(epanum,PlantName)!=NULL) && (lcsflag==1))
	                			  {
								  	printf("\n EPA Found On Latest Revision in Wrking State Pls Check Previous Revision \n",IsEpaflg);fflush(stdout);
	                			  	IsEpaflg++;
	                			  	break;
	                			  	
	                			  }
								
							}
						}
						 
					}
					  
				}



				printf("\n\n\t\t IsEpaflg:%d",IsEpaflg);fflush(stdout);

				if(IsEpaflg==1)
				{
					prevBrkTsakObj=PartrevisionTag;
				}
				else
				{
					prevBrkTsakObj=PartrevisionTag;
					break;
				}
                
				printf("\nIsEpaflg[%d] \n",IsEpaflg);fflush(stdout);

			if(IsEpaflg==1)
			{
			   continue;
			
			}

		}//End Of All Revision Traversing


			// Select latest Revision on which there is NO EPA attached or its Std Relesase for Plant

			if(prevBrkTsakObj)
			{
				PartSelctdItemRevName	= NULL;
				PartSelctdItemRevision	= NULL;

				ITK_CALL(AOM_ask_value_string(prevBrkTsakObj,"item_id",&PartSelctdItemRevName));
				ITK_CALL(AOM_ask_value_string(prevBrkTsakObj,"item_revision_id",&PartSelctdItemRevision));

				printf("\n  Part no :%s Part Rev:%s",PartSelctdItemRevName,PartSelctdItemRevision);fflush(stdout);


						ifail=WSOM_ask_release_status_list(prevBrkTsakObj,&count,&status_list);

						flgtaskwrk=0;

						for(NStatus=0;NStatus<count;NStatus++)
						{
							ifail=RELSTAT_ask_release_status_type(status_list[NStatus],&RlzStatusName);
							printf("\n RlzStatusName==>[%s]",RlzStatusName);fflush(stdout);

							
							if(tc_strcmp(RlzStatusName,plantstdwrg)==0)
							{
								flgtaskwrk=1;
								break;
							}
							
						}
						
						flgpartrlz=0;
						
						for(NStatus=0;NStatus<count;NStatus++)
						{
							ifail=RELSTAT_ask_release_status_type(status_list[NStatus],&RlzStatusName);
							printf("\n RlzStatuscheck==>[%s]",RlzStatusName);fflush(stdout);
							
							if((tc_strcmp(RlzStatusName,plantstdrlz)==0) || (tc_strcmp(RlzStatusName,plantaplwrkg)==0))
							{
								printf("\n Part found stds released or apl working==>[%s]",RlzStatusName);fflush(stdout);
								flagClosure =1;	
								break;
								
							}
							
						}
						
						
						if(flgtaskwrk==1)
						{
							// Add to Set  UnqSetSkpPart
							if(FoundObjectInList(UnqSetSkpPart,partSkpCounter,PartSelctdItemRevName,PartSelctdItemRevision)==0)
							{
								//AddParts In Set
								partSkpCounter++;
                                printf("\n partSkpCounter is:%d ",partSkpCounter);fflush(stdout);
								UnqSetSkpPart[partSkpCounter].PartTag=prevBrkTsakObj;
								tc_strcpy(UnqSetSkpPart[partSkpCounter].PartName,PartSelctdItemRevName);
								tc_strcpy(UnqSetSkpPart[partSkpCounter].partRevision,PartSelctdItemRevision);
							}
							else
							{
								printf("\n Part Already present in UnqSetSkpPart Set No Need to Add"); fflush(stdout);
							}
							flagClosure =1;									
						}

				       //if any rev released from stdsi then skip. //sachin
								                      
		                char	**qry_values= (char **) MEM_alloc(5 * sizeof(char *));
		            	tag_t   qryobj     = NULLTAG;
		            	tag_t   revTag     = NULLTAG;
		            	int found=0;
		            	int cnt=0;
		            	int n_entryobj=3;
						int amdmlpartflag  = 0;//indira
		            	tag_t *part_tags=NULLTAG;
		            	char *rlzpart			=NULL;
		            	char *rlzpartrev			=NULL;


                      ITK_CALL(QRY_find2("Item Revision...", &qryobj));
                       if (qryobj)
	                   {
		            
	                     char
	                     *qry_entry[3] = {"Item ID","Type","Release Status"},
	                     *qry_values[3] =  {PartSelctdItemRevName,"Design Revision",plantstdrlz};
		            
	                     printf("\n Execute qryTagobj...\n");fflush(stdout);
	                     QRY_execute(qryobj, n_entryobj, qry_entry, qry_values, &found, &part_tags);
                         printf(" check1111 no of rev found: %d\n",found);fflush(stdout);
		            
                         if(found>0)
		            	  {
		            	  	for (cnt = 0; cnt < found; cnt++)
		            	  	{
		            	  		revTag=NULLTAG;
		            	  		revTag=part_tags[cnt];
                                ITK_CALL(AOM_ask_value_string(revTag,"item_id",&rlzpart));
	                            printf(" stdsi released part num is : %s",rlzpart);
		            			ITK_CALL(AOM_ask_value_string(revTag,"item_revision_id",&rlzpartrev));
	                            printf("stdsi released part rev is : %s",rlzpartrev);
		            		  								
						        	printf("\nInside partrlzCounter : %d",partrlzCounter);fflush(stdout);
						        	partrlzCounter++;
									printf("\n partrlzCounter is:%d ",partrlzCounter);
								   UnqSetrlzPart[partrlzCounter].PartTag=revTag;
								   tc_strcpy(UnqSetrlzPart[partrlzCounter].PartName,rlzpart);
								   tc_strcpy(UnqSetrlzPart[partrlzCounter].partRevision,rlzpartrev);
								   amdmlpartflag=1; //indira
							       break;
		            	  	}
		            	  }
	                  }

				
				//Add Part prevBrkTsakObj in PartObjectSet 

				if((flagClosure==0)&&(amdmlpartflag==0)) //indira
				{
                    int stdrlzflag=0;
					flagPartTagFound=0;
					PartRevName=NULL;

					ITK_CALL(AOM_ask_value_string(prevBrkTsakObj,"item_id",&PartRevName));
					ITK_CALL(AOM_ask_value_string(prevBrkTsakObj,"item_revision_id",&PartRev));
					//Check Duplicacy in Object Set
					for(setIndex=0;setIndex<CountPartObjectSet;setIndex++)
					{
						if(strcmp(PartObjectSet[setIndex].PrtItemName,PartRevName)==0)
						{
							flagPartTagFound=1;
							break;
						}
					}
					//Store Unique Tag Value in Set

					if(flagPartTagFound!=1)
					{
						CountPartObjectSet++;
						PartObjectSet[CountPartObjectSet].PartTag= prevBrkTsakObj;
						tc_strcpy(PartObjectSet[CountPartObjectSet].PrtItemName,PartRevName);
					}
                    prevRevPartTag  = NULLTAG;
					
					prevRevPartTag=prevBrkTsakObj;
                    printf("\n PartRev is :%s",PartRev); fflush(stdout);
					//Store All Previous Revision in Set To Attach it in PR Task skipp if latest Revision is NR Revision
					if(tc_strstr(PartRev,"NR")==NULL)
					{
						printf("\n inside non NR rev "); fflush(stdout);
						PrevFlag = 0;
						do
						{

							PrevFlag			= 1;
							t_previousRevision  = NULLTAG;
							partRevisionID=NULL;

							//Get Previous tm_fnd_Prev_Official_RevisionRevision

							tm_fnd_Prev_Official_Revision(PartRevName,prevRevPartTag, &t_previousRevision);


							if(t_previousRevision!=NULLTAG)
							{
								//Store each Previous Rev Tag in SetofObject
								prevRevPartTag=t_previousRevision;

								ITK_CALL(AOM_ask_value_string(prevRevPartTag,"item_id",&PartRevName));
								ITK_CALL(AOM_ask_value_string(prevRevPartTag,"item_revision_id",&partRevisionID));
								printf("\n Part Prev ID is:%s",PartRevName); fflush(stdout);
								printf("\n Part Prev Revision :%s",partRevisionID); fflush(stdout);

								ITKCALL(WSOM_ask_release_status_list(prevRevPartTag,&cntstd,&status_liststd));
                                    printf("\n Part release status count :%d",cntstd); fflush(stdout);
						            if(cntstd>0)
									{
							    	   for(stdstatus=0;stdstatus<cntstd;stdstatus++)
							    	   {
									   	 stdrlzflag=0;
							    	   	 ITKCALL(RELSTAT_ask_release_status_type(status_liststd[stdstatus],&stdRlzStatusName));
							    	   	 printf("\n stdRlzStatusName==>[%s]",stdRlzStatusName);fflush(stdout);

							    	   	if(tc_strcmp(stdRlzStatusName,plantstdrlz)==0 )
							    	   	{
							    	   		stdrlzflag=1;
									   		break;
							    	   	}
							    	   }
									}
								

								//Check Duplicacy in PR Set struct_PartPRTagSet
                                printf(" countPrPartSet is :%d",countPrPartSet);

								flagPartTagFound=0;
								for(setIndex=0;setIndex<countPrPartSet;setIndex++)
								{
									if((strcmp(PRpartObjectSet[setIndex].PartName,PartRevName)==0) && (strcmp(PRpartObjectSet[setIndex].partRevision,partRevisionID)==0))
									{
										printf("check111111 ");
										flagPartTagFound=1;
										break;
									}
								}
								//Store Unique Tag Value in Set
								if((flagPartTagFound!=1) && (stdrlzflag==0))
								{
									countPrPartSet++;
									PRpartObjectSet[countPrPartSet].PartTag= t_previousRevision;
									tc_strcpy(PRpartObjectSet[countPrPartSet].partRevision,partRevisionID);
								}

                                printf("flag set PrevFlag :%d",PrevFlag);
									PrevFlag=0;
									break;
							}
							else
							{
								//Terminate when there is no prev Revision
								PrevFlag=0;
							}
						}while(PrevFlag!=0);

					}//End of IF for NR Revision Check

				} //End of 	flagClosure if Cndn

			}// End of prevBrkTsakObj if Loop

		} //End of For Loop of Set Found In VC

	} //end of If any object found in Set



	tag_t unqPartTag 		= NULLTAG;
	char *partName		    = NULL;

	printf("\n *******Part Present in VC************\n ");
	printf("\n Total Part Present in VC :%d ",CountPartObjectSet+1);
	printf("\n Total stdsi released partrlzCounter :%d ",partrlzCounter+1);

	if(CountPartObjectSet==-1)
	{
		printf("\n No Part To Create ADML Return to Main .Total Part Present in VC :%d ",CountPartObjectSet+1);
		goto SEND_MAIL;
	}
	if(CountPartObjectSet>5000 || countPrPartSet>5000)
	{
		fprintf(fpAmDmlCreate,"\n Limit of countPrPartSet/CountPartObjectSet is More Than 5000 part Please varify Parts in Set CountPartObjectSet=%d, countPrPartSet=%d ",CountPartObjectSet,countPrPartSet);
		goto SEND_MAIL;
	}

	fprintf(fpAmDmlCreate,"\n ***********Unique Parts in VC to Attach in AMDML :%s  total Count %d ********",inputVCNo,CountPartObjectSet+1);

	for(j=0;j<=CountPartObjectSet;j++)
	{
		unqPartTag 		=NULLTAG;
		partName		    = NULL;
		partRevisionID		= NULL;
		partDRStatuss		=NULL;

		unqPartTag=PartObjectSet[j].PartTag;

		ITK_CALL(AOM_ask_value_string(unqPartTag,"item_id",&partName));
		ITK_CALL(AOM_ask_value_string(unqPartTag,"item_revision_id",&partRevisionID));

		printf("\n  Part in VC:%s :%s",partName,partRevisionID); fflush(stdout);
		fprintf(fpAmDmlCreate,"\n  Unique Part in VC:%s:%s",partName,partRevisionID);
	}

	printf("\n Total Part Present in PrObjectSet :%d ",countPrPartSet+1);
	fprintf(fpAmDmlCreate,"\n ******Unique Parts in VC to Attach  PR Task in AMDML :%s  total Count %d *********",inputVCNo,countPrPartSet+1);

	for(j=0;j<=countPrPartSet;j++)
	{

		unqPartTag 		=NULLTAG;
		partName		    = NULL;
		partRevisionID		= NULL;

		unqPartTag=PRpartObjectSet[j].PartTag;
		ITK_CALL(AOM_ask_value_string(unqPartTag,"item_id",&partName));
		ITK_CALL(AOM_ask_value_string(unqPartTag,"item_revision_id",&partRevisionID));

		printf("\n Unique PR Part in VC:%s:%s",partName,partRevisionID); fflush(stdout);
		fprintf(fpAmDmlCreate,"\n  Unique Part attach to PR  in VC:%s:%s",partName,partRevisionID);
	}

	fprintf(fpAmDmlCreate,"\n ******Unique Parts in VC UnqSetSkpPart  to Attach in AMDML :%s  total Count %d *********",inputVCNo,partSkpCounter+1);

	printf("\n Total Part Present in partSkpCounter :%d ",partSkpCounter+1);

	printf("\n Total part rev released :%d ",partrlzCounter+1);

	if(partSkpCounter>=0)			
	{

		tc_strcat(dmlPendinginUsrListName,inputVCNo);
		tc_strcat(dmlPendinginUsrListName,"_");
		tc_strcat(dmlPendinginUsrListName,"DML_PendingWith_STDSI_WL");
		tc_strcat(dmlPendinginUsrListName,"_");
		tc_strcat(dmlPendinginUsrListName,pAccessDate);
		tc_strcat(dmlPendinginUsrListName,".xls");

		tc_strcpy(dmlPendinginUsrList,"/tmp/");	
		tc_strcat(dmlPendinginUsrList,dmlPendinginUsrListName);	

		fpdmlPendinginUsrList = fopen(dmlPendinginUsrList, "w");

		if(fpdmlPendinginUsrList==NULL)
		{
			printf("\n Unable to Create Log File on Server %s ",fpdmlPendinginUsrList); fflush(stdout);
			return ifail;
		}
		else
		{
			fprintf(fpdmlPendinginUsrList,"\n Below Parts Dml Pending With User`s Worklist");
			for(j=0;j<=partSkpCounter;j++)
			{
				unqPartTag 		=NULLTAG;
				partName		    = NULL;
				partRevisionID		= NULL;

				unqPartTag=UnqSetSkpPart[j].PartTag;

				ITK_CALL(AOM_ask_value_string(unqPartTag,"item_id",&partName));
				ITK_CALL(AOM_ask_value_string(unqPartTag,"item_revision_id",&partRevisionID));

				printf("\n Unique Part in VC To Skipp:%s:%s",partName,partRevisionID); fflush(stdout);

				fprintf(fpAmDmlCreate,"\n  Unique Part  in  UnqSetSkpPart Set :%s:%s",partName,partRevisionID);				
				fprintf(fpdmlPendinginUsrList,"\n %s:%s",partName,partRevisionID);
			}

		}

	}

	if(partrlzCounter>=0)//sachin			
	{
		tc_strcat(prtLsstdrlzName,inputVCNo);
		tc_strcat(prtLsstdrlzName,"_");
		tc_strcat(prtLsstdrlzName,"List_AnyRev_stdsi_rlz");
		tc_strcat(prtLsstdrlzName,"_");
		tc_strcat(prtLsstdrlzName,pAccessDate);
		tc_strcat(prtLsstdrlzName,".xls");

		tc_strcpy(prtLsstdrlz,"/tmp/");	
		tc_strcat(prtLsstdrlz,prtLsstdrlzName);	

		fppartrlzList = fopen(prtLsstdrlz, "w");
		
		if(fppartrlzList==NULL)
		{
			printf("\n Any rev released Unable to Create Log File on Server %s ",fppartrlzList); fflush(stdout);
			return ifail;
		}
		else
		{
			fprintf(fppartrlzList,"\n  Any Rev STDSI Released --> ");

			for(j=0;j<=partrlzCounter;j++)
			{
				unqPartTag 			=	NULLTAG;
				partName		    =	NULL;
				partRevisionID		= NULL;

				unqPartTag=UnqSetrlzPart[j].PartTag;

				ITK_CALL(AOM_ask_value_string(unqPartTag,"item_id",&partName));
				ITK_CALL(AOM_ask_value_string(unqPartTag,"item_revision_id",&partRevisionID));

				printf("\n Any Rev STDSI Released is Skipp:%s:%s",partName,partRevisionID); fflush(stdout);

				fprintf(fpAmDmlCreate,"\n  Any Rev STDSI Released not considered :%s",partName);				
				fprintf(fppartrlzList,"\n  %s:%s",partName,partRevisionID);
			}
		}
	} 
	// AMDML Creation Logic

	char  	   *gmTaskPrjCode      = NULL;
	char 	   *gmTaskDesignGrp 	= NULL;
	char       *AmDmlTaskName		= NULL;
	char       *datrelease		= NULL;
	char       *dmldatrelease		= NULL;

	int 		FlagPRdmlCrt        = 0;
	int        i=0;
	char       Synopsis[100];

	tag_t  	     AMDmlObjTag		= NULLTAG;
	tag_t 		APLTaskTag			= NULLTAG;
	tag_t		APLTaskPrTag		= NULLTAG;
	tag_t      *tskRevTagList		= NULLTAG;
	tag_t		TaskTag				= NULLTAG;
	tag_t      apl_task_part_relation =NULLTAG;
    date_t  Task_Release_date =NULLDATE;
	tag_t			participant_tag		= NULLTAG;
	tag_t			participant_tagana		= NULLTAG;
	tag_t			participant_typeana	= NULLTAG;
	tag_t			relation_typeana		= NULLTAG;
	tag_t			relationana			= NULLTAG;
	tag_t			participant_typerev	= NULLTAG;
	tag_t			relation_typerev		= NULLTAG;
	tag_t			relationrev			= NULLTAG;
    tag_t			participant_typereq	= NULLTAG;
	tag_t			relation_typereq		= NULLTAG;
	tag_t			participant_tagreq		= NULLTAG;
	tag_t			relationreq			= NULLTAG;
	tag_t			relationcs			= NULLTAG;
    tag_t			participant_typecs			= NULLTAG;
    tag_t			relation_typecs		= NULLTAG;
	tag_t			participant_tagcs		= NULLTAG;

	tag_t			usertag			= NULLTAG;
	tag_t			roletag			= NULLTAG;
    int				num_of_members		= 0;
    tag_t*			member_tags			= NULLTAG;
    char*			member_name				= NULL;
    AE_reference_type_t tagRefType =  1;

	if(countPrPartSet>=0)
	{
		FlagPRdmlCrt=1;
	}
	if(CountPartObjectSet>=0 && CountPartObjectSet<5000)
	{
		printf("\n inside AMDML Creation Logic \n");fflush(stdout);

		tc_strcpy(Synopsis,"AMDML Created as per User Request ");
		tc_strcat(Synopsis," For Module:");
		tc_strcat(Synopsis,inputVCNo);


		AMDMLCreateFuncTOO(projectcode,partdsgndrp,NULL,Synopsis,Synopsis,userName,FlagPRdmlCrt,PlantName,&AMDmlObjTag);

		if(AMDmlObjTag==NULLTAG)
		{
			fprintf(fpAmDmlCreate,"\n *********System Unable to Create AMDML********");
		}

		if(AMDmlObjTag!=NULLTAG)
		{
			
			//printf("\nSet owing user on DML...");fflush(stdout);
            dmldatrelease=NULL;
			ITK_CALL(AOM_UIF_ask_value(AMDmlObjTag,"date_released",&dmldatrelease));
			printf("\n DML date released is :%s",dmldatrelease); fflush(stdout);

		    
			ITK_CALL(AOM_lock(AMDmlObjTag));
			ITK_CALL(AOM_UIF_set_value(AMDmlObjTag,"date_released",Task_Release_date));
			ITK_CALL(POM_set_owning_user(AMDmlObjTag,Analyst_user_tag));
			ITK_CALL(AOM_save_without_extensions(AMDmlObjTag));
			ITK_CALL(AOM_unlock(AMDmlObjTag));
			ITK_CALL(AOM_refresh(AMDmlObjTag,TRUE));

			int FndDMLTaskrelation=0;
			totalDmlCnt=0;

			task_dml_rel_type =NULLTAG;

			printf("\n CREATING REL OF APL TASK and Parts\n");fflush(stdout);

			ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&task_dml_rel_type));
			
			ITK_CALL(GRM_list_secondary_objects_only(AMDmlObjTag,task_dml_rel_type,&totalDmlCnt,&tskRevTagList));

			for(i=0;i<totalDmlCnt;i++)
			{
				AOM_ask_value_string_at(tskRevTagList[i],"item_id",0,&AmDmlTaskName);

				if(tc_strstr(AmDmlTaskName,"_PR")!=NULL)
				{
				
					APLTaskPrTag=tskRevTagList[i];
					ITK_CALL(AOM_lock(APLTaskPrTag));
					ITK_CALL(POM_set_owning_user(APLTaskPrTag,Analyst_user_tag));
					ITK_CALL(AOM_save_without_extensions(APLTaskPrTag));
					ITK_CALL(AOM_unlock(APLTaskPrTag));
					ITK_CALL(AOM_refresh(APLTaskPrTag,TRUE));
					
				}
				else
				{
					APLTaskTag=tskRevTagList[i];					
					ITK_CALL(AOM_lock(APLTaskTag));
                    CALLAPI(SA_find_role2(userRole,&roletag));
					

					CALLAPI(SA_find_groupmember_by_role(roletag,tc_group,&num_of_members,&member_tags));
                      printf("\n num_of_members is %d\n",num_of_members);fflush(stdout);

                     if(num_of_members>0)
						{
							for (j=0;j<num_of_members ;j++  )
							{
                               
								ITKCALL(AOM_ask_value_string(member_tags[j],"user_name",&member_name)!=ITK_ok);
								printf("\n member_name :[%s]\n",member_name);fflush(stdout);
								printf("\n userName is  :[%s]\n",userName);fflush(stdout);

								if(tc_strcmp(member_name,userName)==0)
                                {
                                    TCTYPE_find_type("Analyst", "Analyst", &participant_typeana);
									EPM_create_participant(member_tags[j], participant_typeana, &participant_tagana);
					                GRM_find_relation_type("HasParticipant", &relation_typeana);
					                GRM_create_relation(APLTaskTag, participant_tagana, relation_typeana,  NULLTAG, &relationana);
					                GRM_save_relation(relationana);
                                    printf("\n Analyst Assigned..\n");fflush(stdout);

                                    /*
									TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_typecs);
									EPM_create_participant(member_tags[j], participant_typecs, &participant_tagcs);
					                GRM_find_relation_type("HasParticipant", &relation_typecs);
					                GRM_create_relation(APLTaskTag, participant_tagcs, relation_typecs,  NULLTAG, &relationcs);
					                GRM_save_relation(relationcs);
									printf("\n ChangeSpecialist1 Assigned..\n");fflush(stdout);
                                     */

									TCTYPE_find_type("Requestor", "Requestor", &participant_typereq);
								    EPM_create_participant(member_tags[j], participant_typereq, &participant_tagreq);
								    GRM_find_relation_type("HasParticipant", &relation_typereq);								    
								    GRM_create_relation(APLTaskTag, participant_tagreq, relation_typereq,  NULLTAG, &relationreq);
								    GRM_save_relation(relationreq);
								    break;
								    printf("\n Requestor Assigned.\n");
								}		
							}
						}

			        datrelease=NULL;					
					ITK_CALL(AOM_UIF_set_value(APLTaskTag,"date_released",Task_Release_date));
					ITK_CALL(POM_set_owning_user(APLTaskTag,Analyst_user_tag));					
					ITK_CALL(AOM_save_without_extensions(APLTaskTag));
					ITK_CALL(AOM_unlock(APLTaskTag));
					ITK_CALL(AOM_refresh(APLTaskTag,TRUE));
					ITK_CALL(AOM_UIF_ask_value(APLTaskTag,"date_released",&datrelease));
					printf("\n Task date released is :%s",datrelease); fflush(stdout);                   
				
				}
			}

			if(APLTaskTag!=NULLTAG)
			{

				task_part_rel_type=NULLTAG;

				ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &task_part_rel_type));
				printf("\n Attaching Latest Revision to AMDML TASK");
				fprintf(fpAmDmlCreate,"\n :%s",PartObjectSet[j].PrtItemName);

				AOM_ask_value_string_at(APLTaskTag,"item_id",0,&AmDmlTaskName);
				fprintf(fpAmDmlCreate,"\n **********List Of Parts Unable to attach AMDML Task:%s ************* \n ",AmDmlTaskName);

				for(j=0;j<=CountPartObjectSet;j++)
				{
					apl_task_part_relation=NULLTAG;
					ifail=GRM_create_relation(APLTaskTag, PartObjectSet[j].PartTag, task_part_rel_type,  NULLTAG, &apl_task_part_relation);
					if(ifail!=ITK_ok)
					{
						fprintf(fpAmDmlCreate,"\n Unable to attach Part in AMDML Task:%s",PartObjectSet[j].PrtItemName);
					}
					ITK_CALL(GRM_save_relation(apl_task_part_relation));
				}
			}

			if(APLTaskPrTag!=NULLTAG)
			{
				task_part_rel_type=NULLTAG;

				ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &task_part_rel_type));

				AOM_ask_value_string(APLTaskPrTag,"item_id",&AmDmlTaskName);
				fprintf(fpAmDmlCreate,"\n  ********List Of Parts Unable to attach PR Task of AMDML:%s ********** \n ",AmDmlTaskName);

				for(j=0;j<=countPrPartSet;j++)
				{
					apl_task_part_relation=NULLTAG;
					ifail=GRM_create_relation(APLTaskPrTag, PRpartObjectSet[j].PartTag, task_part_rel_type,  NULLTAG, &apl_task_part_relation);
					if(ifail!=ITK_ok)
					{
						fprintf(fpAmDmlCreate,"\n Unable to attach Part in AMDML PR  Task:%s",PRpartObjectSet[j].PartName);
					}
					ITK_CALL(GRM_save_relation(apl_task_part_relation));
				}
			}
		}//AMDML object not NULL
	}//SetofObject more than 1

	//Stamping DML & Task Life Cycle

	char *lifeCylceStmp=NULL;

	printf("\n Plant Name is %s",PlantName);

	//Get Life cycle from Control object
	char AplRvwLC[40];//TZ3.46
	char AplWrkngLC[40];
	char AplRlzdLc[40];
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];

	get_CtrlVal_APLStateInf(PlantName,AplRvwLC,AplWrkngLC,AplRlzdLc,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti

	printf( "\n AplRlzdLc:%s\n", AplRlzdLc);  fflush(stdout);
	printf( "\n AplRvwLC:%s\n", AplRvwLC);  fflush(stdout);
	printf( "\n AplWrkngLC:%s\n", AplWrkngLC);  fflush(stdout);
	printf( "\n Stdwrknglc:%s\n", Stdwrknglc);  fflush(stdout);

	if(AMDmlObjTag!=NULLTAG && Stdwrknglc != NULL)
	{
		printf("\n Stamping APL Released Life Cycle on AMDML"); fflush(stdout);
		t5UpdateLifecycleStateAPL(AMDmlObjTag,Stdwrknglc,PlantName);
	}
	if(APLTaskTag!=NULLTAG)
	{
		printf("\n Stamping APL Released Life Cycle on AMDML TASK"); fflush(stdout);
		t5UpdateLifecycleStateAPL(APLTaskTag,Stdwrknglc,PlantName);
	}
	if(APLTaskPrTag!=NULLTAG)
	{
		printf("\n Stamping APL Released Life Cycle on AMDML PR TASK"); fflush(stdout);
		
		t5UpdateLifecycleStateAPL(APLTaskPrTag,Stdwrknglc,PlantName);
	}

	if(fpdmlPendinginUsrList!=NULL)
	{
		if(APLTaskTag!=NULLTAG)
		{
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found for GM FIle attachemnt \n");fflush(stdout);
				qry_valuesCntrl1[0]="GMFileAtt";
				qry_valuesCntrl1[1]="0";

				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	

			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				ITK_CALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &filrPathServer));
				printf("\n filrPathServer: %s\n",filrPathServer);fflush(stdout);

				tc_strcpy(fullPath,filrPathServer);
				tc_strcat(fullPath,dmlPendinginUsrListName);

				ITK_CALL(AE_find_datasettype2 ("MSExcel",&datasettype_tag));
				printf("\n Finding Datasettype---");fflush(stdout);
				ITK_CALL(AE_ask_datasettype_def_tool(datasettype_tag,&default_tool_tag));
				printf("\n DataSetTypeDef---");fflush(stdout);
				ITK_CALL(AE_create_dataset_with_id(datasettype_tag, dmlPendinginUsrListName,"DML_PendingWith_STDSI_WL", 0, 0, &tDataset));
				printf("\n Creating dataset---");fflush(stdout);
				ITK_CALL(AE_set_dataset_format2(tDataset,"BINARY_REF"));
				printf("\n set dataset format---");fflush(stdout);
				ITK_CALL(AE_set_dataset_tool(tDataset,default_tool_tag));
				ITK_CALL(AE_ask_datasettype_refs(datasettype_tag,&count_dataSet,&list));
				printf("\n set dataset ref---");fflush(stdout);

				ITK_CALL(IMF_import_file (fullPath,NULL,SS_BINARY,&imannewFileTag,&filedescriptor));

				ITK_CALL(IMF_set_original_file_name2(imannewFileTag,dmlPendinginUsrListName));
				ITK_CALL(AOM_save_without_extensions(imannewFileTag));
				printf("\nFile saved---");fflush(stdout);
				ITK_CALL(AE_add_dataset_named_ref2(tDataset,list[0],tagRefType,imannewFileTag));
				printf("\nAE_add_dataset_named_ref-");fflush(stdout);
				ITK_CALL(AOM_save_without_extensions(tDataset));

				ITK_CALL(GRM_find_relation_type("IMAN_reference", &relation_type));
				printf("\n GRM_find_relation_type ");fflush(stdout);
				ITK_CALL(GRM_find_relation( APLTaskTag, tDataset, relation_type ,&Fndrelation));
				printf("\n\t Fndrelation "); fflush(stdout);
				if(Fndrelation)
				{
					printf("\n\t Relation Already Exist with file...\n" );fflush(stdout);
				}
				else
				{
					ITK_CALL(GRM_create_relation(APLTaskTag, tDataset, relation_type, NULLTAG, &relation));
					printf("\n GRM_create_relation ");fflush(stdout);
					ITK_CALL(GRM_save_relation(relation));
					printf("\n GRM_save_relation ");fflush(stdout);
				}
			}

		}
		//fclose (fpdmlPendinginUsrList);
	}

        datasettype_tag=NULLTAG;
        default_tool_tag=NULLTAG;
		tDataset=NULLTAG;

	  if(fppartrlzList!=NULL)//sachin
	  {
		if(APLTaskTag!=NULLTAG)
		{
			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found for module FIle attachemnt \n");fflush(stdout);
				qry_valuesCntrl1[0]="GMFileAtt";
				qry_valuesCntrl1[1]="0";

				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	

			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				ITK_CALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &filrPathServer));
				printf("\n filrPathServer: %s\n",filrPathServer);fflush(stdout);

				tc_strcpy(fullPathrlz,filrPathServer);
				tc_strcat(fullPathrlz,prtLsstdrlzName);

				ITK_CALL(AE_find_datasettype2 ("MSExcel",&datasettype_tag));
				printf("\n Finding Datasettype---");fflush(stdout);
				ITK_CALL(AE_ask_datasettype_def_tool(datasettype_tag,&default_tool_tag));
				printf("\n DataSetTypeDef---");fflush(stdout);
				ITK_CALL(AE_create_dataset_with_id(datasettype_tag, prtLsstdrlzName,"Any_Revision_STDSIReleased_Skip", 0, 0, &tDatasetrlz));
				printf("\n Creating dataset---");fflush(stdout);
				ITK_CALL(AE_set_dataset_format2(tDatasetrlz,"BINARY_REF"));
				printf("\n set dataset format---");fflush(stdout);
				ITK_CALL(AE_set_dataset_tool(tDatasetrlz,default_tool_tag));
				ITK_CALL(AE_ask_datasettype_refs(datasettype_tag,&count_dataSetrlz,&listrlz));
				printf("\n set dataset ref---");fflush(stdout);

				ITK_CALL(IMF_import_file (fullPathrlz,NULL,SS_BINARY,&imannewFileTagrlz,&filedescriptorrlz));

				ITK_CALL(IMF_set_original_file_name2(imannewFileTagrlz,prtLsstdrlzName));
				ITK_CALL(AOM_save_without_extensions(imannewFileTagrlz));
				printf("\nFile saved---");fflush(stdout);
				ITK_CALL(AE_add_dataset_named_ref2(tDatasetrlz,listrlz[0],tagRefType,imannewFileTagrlz));
				printf("\nAE_add_dataset_named_ref-");fflush(stdout);
				ITK_CALL(AOM_save_without_extensions(tDatasetrlz));
                
				relation_type	=	NULLTAG;
				Fndrelation		=	NULLTAG;

				ITK_CALL(GRM_find_relation_type("IMAN_reference", &relation_type));
				printf("\n GRM_find_relation_type ");fflush(stdout);
				ITK_CALL(GRM_find_relation( APLTaskTag, tDatasetrlz, relation_type ,&Fndrelation));
				printf("\n\t Fndrelation "); fflush(stdout);
				if(Fndrelation)
				{
					printf("\n\t Relation Already Exist with file...\n" );fflush(stdout);
				}
				else
				{
					relation	=	NULLTAG;
					ITK_CALL(GRM_create_relation(APLTaskTag, tDatasetrlz, relation_type, NULLTAG, &relation));
					printf("\n GRM_create_relation ");fflush(stdout);
					ITK_CALL(GRM_save_relation(relation));
					printf("\n GRM_save_relation ");fflush(stdout);
				}
			}

		}
		//fclose (fpdmlPendinginUsrList);
	}
    

	if(AMDmlObjTag!=NULLTAG)
	{

		tag_t template_tag = NULLTAG;
		tag_t test_job_a = NULLTAG;
		int attachment_types = 1;
		
		printf("\n Finding CM Release Process Template\n");fflush(stdout);
		ITK_CALL(EPM_find_template2("STDSI DML WorkFlow",0,&template_tag));

		if (template_tag!=NULLTAG)
		{
			printf("\n Submit APL DML in to workflow check1111\n");fflush(stdout);
            ITK_CALL(EPM_assign_responsible_party(APLTaskTag,Analyst_user_tag));
			ITK_CALL(EPM_create_process("STDSI DML WorkFlow","",template_tag,1, &AMDmlObjTag,&attachment_types,&test_job_a));
            						
		}
		else
		{
			fprintf(fpAmDmlCreate,"\n 'STDSI DML WorkFlow' process Not Found ");
			printf("\n 'STDSI DML WorkFlow' process Not Found \n");fflush(stdout);
		}
	}

	env_subject=(char *) MEM_alloc(200 * sizeof(char *));
	env_body=(char *) MEM_alloc(200 * sizeof(char *));

	SEND_MAIL:

	if(AMDmlObjTag!=NULLTAG)
	{
		AOM_ask_value_string(AMDmlObjTag,"item_id",&AmDmlTaskName);

		tc_strcpy(env_subject,"MAIL FROM PLM SYSTEM AMDML Created for Module");

		tc_strcpy(env_body," Hi, \n\n ");

		tc_strcat(env_body,"AMDML ");
		tc_strcat(env_body,"\'");
		tc_strcat(env_body,AmDmlTaskName);
		tc_strcat(env_body,"\'");
		tc_strcat(env_body," has been created for Module ");
		tc_strcat(env_body,"\'");
		tc_strcat(env_body,inputVCNo);
		tc_strcat(env_body,"\'");
		tc_strcat(env_body," \n\n Regards,\n PLM Team ");
	}
	else
	{
		tc_strcpy(env_subject,"MAIL FROM PLM SYSTEM FAILED To Create AMDML for Module");

		tc_strcpy(env_body," Hi, \n\n ");
		tc_strcat(env_body,"AMDML ");
		tc_strcat(env_body,"creation has been failed for Module ");
		tc_strcat(env_body,"\'");
		tc_strcat(env_body,inputVCNo);
		tc_strcat(env_body,"\'");
		tc_strcat(env_body," \n\n Regards,\n PLM Team ");
	}


	printf(" Mail Body String :%s",env_body);
	ITK_CALL(MAIL_create_envelope(env_subject, env_body, &envelope));

	if(envelope != NULLTAG)
	{
		ITK_CALL(MAIL_initialize_envelope2(envelope, env_subject, env_body));
		if(Analyst_email_addr!=NULL)
		{
		   ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,Analyst_email_addr));

		}
		
		ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"deeptim.ttl@tatamotors.com"));
		ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"sk922240.ttl@tatamotors.com"));
		ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
		printf("\n countenvelop %d\n",countenvelop);fflush(stdout);
		ITK_CALL(MAIL_send_envelope(envelope));
		printf("\n Mail Send Successfully");
	}
	else
	{
		printf("\n Unable to  Send MAil");
	}
	return ifail;
}
