/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: keyword_desc.c
**
** Functions:- 	This utility takes the item_id as input from file and find it's latest revision in teamcenter then get it's module_name attr_value and 
**				stamps it on item's and item revision's specific attributes.(object_desc, object_name, t5_CategoryName etc.)
** 
**
**	Date:							Author:								Modification:
**	23-May-2018						Kalpesh Gondhali					Code creation
**
**
** command to run:
** keyword_desc -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


#define PROP_UIF_set_value_msg		"PROP_UIF_set_value" 
#define PROP_set_value_tag_msg		"PROP_set_value_tag" 
#define PROP_set_value_string_msg   "PROP_set_value_string"  

FILE 		*output 			= NULL;

char		*sep				= ",";

int read_value_from_file(char*);
int update_value(char*);
int write_info(char*, char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<filename> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;

	char 			Data[100]    				= "";
	char 			OutputFile[200]    			= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");
	
	time_t now;
	struct tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
	sprintf(OutputFile,"%s_output.txt",Data);

	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	output = fopen(OutputFile,"a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}	
				
		ifail = read_value_from_file(Filename);
		
	printf("\nEnd of program.....!!\n\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;
	
	char 			*itemid					= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, " ");
				printf("\nInput Item_id:%s\n",itemid);

				fprintf(output,"%s",itemid);		

				ifail = update_value(itemid);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       update_value
    Description:    This function takes the item_id as input and find it's latest revision
					in teamcenter then get it's module_name attr_value and stamps it on 
					item's and item revision's specific attributes.(object_desc, object_name, 
					t5_CategoryName etc.)
********************************************************************************************/
int update_value(char* item_id)
{
	int				ifail 						= ITK_ok;
	int				i		 					= 0;
	
	tag_t			item_tag 					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	
	char 			*prt_type					= NULL;
	char 			*type						= "Module";
	char 			*rev_id						= NULL;
	char 			*module_name				= NULL;
	
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_ask_latest_rev (item_tag, &rev_tag);
	if(ifail != ITK_ok)
	{
		printf("Object not found in Teamcenter...!!\n");
		fprintf(output,"%s",sep);
		fprintf(output,"Not Found\n");
		return 0;
	}
	else
	{
		ifail = AOM_UIF_ask_value (rev_tag, "t5_PartType", &prt_type);
		printf("\nPart Type is:%s\n",prt_type);
		
		if((strcmp(prt_type,type) == 0))
		{
			ifail = AOM_UIF_ask_value (rev_tag, "item_revision_id", &rev_id);
			CHECK_FAIL;
			printf("\nLatest rev. found is:%s\n",rev_id);
			
			ifail = AOM_UIF_ask_value (rev_tag, "t5_ModuleName", &module_name);
			CHECK_FAIL;
			
			if(tc_strlen(module_name) > 0)
			{
				ifail = AOM_refresh (item_tag, 1);
			
				ifail = AOM_UIF_set_value (item_tag, "object_name", module_name);
				ifail = AOM_UIF_set_value (item_tag, "object_desc", module_name);
			
				ifail = AOM_save (item_tag);
				ifail = AOM_refresh (item_tag, 0);
				
				ifail = AOM_refresh (rev_tag, 1);
			
				ifail = AOM_UIF_set_value (rev_tag, "object_name", module_name);
				ifail = AOM_UIF_set_value (rev_tag, "object_desc", module_name);
				ifail = AOM_UIF_set_value (rev_tag, "t5_CategoryName", module_name);
			
				ifail = AOM_save (rev_tag);
				ifail = AOM_refresh (rev_tag, 0);
				if(ifail == ITK_ok)
				{
					printf("\nAttribute Value stamped....!!\n");
					ifail = write_info(rev_id, module_name);
					printf("\n*****************************\n");
				}
				else
				{
					printf("\nFailed to stamp Attribute value...!!\n");
					printf("\n************************************\n");
					return ifail;
				}
			}
			else
			{
				printf("Module Name is blank for Module:%s\n", item_id);
				return 0;
			}
		}
		MEM_free(prt_type);
		MEM_free(rev_id);
	}
	return ifail;
}

/********************************************************************************************
    Function:       write_info
    Description:    This function takes rev_id and module_name as input and write it into
					the file.(newly created)
********************************************************************************************/
int write_info(char* rev_id, char* module_name)
{
	int			ifail 				= ITK_ok;
	
	char 		*test2 				= (char*)MEM_alloc(sizeof(char) * 100);
	char		*final2				= (char*)MEM_alloc(sizeof(char) * 100);

		tc_strcpy(test2, "");
		tc_strcpy(test2,sep);
		tc_strcat(test2,rev_id);
		tc_strcat(test2,sep);
		tc_strcat(test2,module_name);

		tc_strcpy(final2,test2);
		
		fprintf(output,"%s\n",final2);	
	
		MEM_free(test2);	
		MEM_free(final2);	
		return ifail;
}
