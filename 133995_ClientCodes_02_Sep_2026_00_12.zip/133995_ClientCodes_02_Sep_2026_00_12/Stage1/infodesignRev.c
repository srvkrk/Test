#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
//#include <qry.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <tccore/aom_prop.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <time.h>
#define ITK_err (EMH_USER_error_base + 2)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

extern int ITK_user_main(int argc, char *argv[] )
{

	//int	iStatus= 0;
	int	login= 0;
//	iStatus = ITK_auto_login();
	char*u = ITK_ask_cli_argument("-u=");
	char*p = ITK_ask_cli_argument("-p=");
	char*g = ITK_ask_cli_argument("-g=");
	 login = ITK_init_module(u,p,g);

//			char	*values[3];
			char	*values[2];
			char	*values2[2];
			char	*qry_Input[2]			= {"Name","Type"};
		   // char	*qry_Input[1]			= {"Id"};
//			int		n_Input					= 2;
			int		n_Input					= 2;
			int		n_Input1				= 2;
			int		Count					= 0;
			tag_t	*Usertag		   = NULLTAG;
			tag_t bom_wnd				=NULLTAG;
			tag_t top_lne				=NULLTAG;
			tag_t	latestRlzRevTag	   = NULLTAG;
			tag_t	Quser			   = NULLTAG;
			tag_t	latestqry			   = NULLTAG;
			tag_t	RelationType	   = NULLTAG;
			tag_t	valueTag		   = NULLTAG;
			tag_t	UserTag1		   = NULLTAG;
			tag_t	latestrev		   = NULLTAG;
			tag_t	*latestqrytag		   = NULLTAG;
			tag_t	*allrev_list		   = NULLTAG;
			tag_t	*rel_status_lst		   = NULLTAG;
			//tag_t	latestrev		   = NULLTAG;
			tag_t	latestrel		   = NULLTAG;
			tag_t	revitem_tag		   = NULLTAG;
			
			char* ItemNametag                   = NULL;
			char* RelItemNametag                   = NULL;
            char* ItemRevid                     = NULL;
            //char* ItemRevid                     = NULL;
            char* Parttypetag                     = NULL;
            char* releasestat                     = NULL;
            char* latestercreleased                     = NULL;
            char* class_name                    = NULL;
            char* RelParttypetag                    = NULL;
            char* RelItemRevid                    = NULL;
            char* MakeBye                    = NULL;
            char* RelObjectDescrtag                    = NULL;
            char* deparmentTag                  = NULL;
            char* useragencyTag                 = NULL;
            char* userlocationTag               = NULL;
            char* Chld_Rel_Stus1               = NULL;
            char* ErcYes               = NULL;
            char* QXPartNum               = NULL;
            char* QXPartRev               = NULL;
            char* QXPartType               = NULL;
            char* RevEffectivity               = NULL;
			int i=0;
			int j=0;
			int usercount=0;
			int count2=0;
			int	n_values =0; 
			int	LCount =0; 
			int	A =0; 
			int	B =0; 
			int	rev_count =0; 
			int	relcount =0; 
			int	rel_status_cunt =0; 
			int	latestRlzRevFlag =0; 

            ErcYes	=(char *) MEM_alloc(sizeof(char)* 50);
			latestercreleased	=(char *) MEM_alloc(sizeof(char)* 50);
			char buffer[50];
			values[0] = "*";
			values[1] = "Design";
			//values[2] = "ERC Released";
//		values[0] = "*";
			FILE* fp = NULL;
			char* filename   = NULL;

//			if(QRY_find2("UserFndACtive", &Quser));
			
			
			if(QRY_find2("General...", &Quser));
			if(Quser)
			{
			 if(QRY_execute(Quser, n_Input, qry_Input, values, &Count, &Usertag));
			 printf("\n QUERY count== %d...................\n", Count);fflush(stdout);
			}
			 fp = fopen("DesignRevdetails.csv","w");

			 fprintf(fp,"PART No,REVISION,PART TYPE,RELEASED STATUS,EFFECTIVITY,MAKE BUY,PARTPART DESCRIPTION,LATEST RELEASED\n");

			  if(fp != NULL)
			{
					
			   printf("\n File is opened \n");fflush(stdout);
		      
			
			}
			else
		   {
				
				printf("\n File is  NOT opened \n");fflush(stdout);
				
			}
			 
			for(i=0; i<Count; i++)
			{


			UserTag1 = Usertag[i];

			ITK_CALL(AOM_UIF_ask_value(UserTag1,"item_id",&ItemNametag));

			printf("\n Name of design revision: %s \n",ItemNametag);fflush(stdout);
		
			//ITK_CALL(AOM_UIF_ask_value(UserTag1,"current_revision_id",&ItemRevid));
			
			//printf("\n Rev id: %s \n",ItemRevid);fflush(stdout);

			//ITK_CALL(AOM_UIF_ask_value(UserTag1,"t5_PartType",&Parttypetag));

			//printf("\n Parttype : %s \n",Parttypetag);fflush(stdout);

			//ITK_CALL(AOM_ask_value_string(latestRlzRevTag,"object_desc",&RelObjectDescrtag));
			// printf("\n latest released part yype .........%s\n", RelObjectDescrtag);fflush(stdout);
		
			//ITK_CALL(AOM_UIF_ask_value(UserTag1,"release_status_list",&releasestat));
			
			//printf("\n release status: %s \n",releasestat);fflush(stdout);
			//fprintf(fp,"\n");fflush(stdout);

			//}

			//ITK_CALL(ITEM_ask_item_of_rev(UserTag1,&revitem_tag));  
		   
			
			//Item of revision
		
			//ITK_CALL(ITEM_ask_latest_rev(revitem_tag,&latestrev));
			ITK_CALL(ITEM_list_all_revs(UserTag1,&rev_count,&allrev_list));

			//ITK_CALL(AOM_ask_value_string(latestrev,"object_name",&ItemNametag));

			printf("\n  rev_count is %d\n", rev_count);fflush(stdout);

			printf("\n IN ERC released ---------\n");fflush(stdout);

			if(rev_count>0)  
			{
			latestRlzRevFlag=0;
			for(A=rev_count-1;A>=0;A--)
			{
			  rel_status_cunt=0;

			  ITK_CALL(WSOM_ask_release_status_list (allrev_list[A], &rel_status_cunt, &rel_status_lst));
			  printf("\n rel_status_cunt is:%d.", rel_status_cunt);fflush(stdout);

			  if(rel_status_cunt>0)
			  {
					for(B=0;B<rel_status_cunt;B++)
					{
						ITK_CALL(AOM_ask_value_string (rel_status_lst[B], "object_name", &Chld_Rel_Stus1));
						printf("\n Chld_Rel_Stus1:%s", Chld_Rel_Stus1);fflush(stdout);

						if((tc_strstr(Chld_Rel_Stus1,"T5_LcsErcRlzd")!=NULL|| tc_strstr(Chld_Rel_Stus1,"ERC Released")!=NULL) && (latestRlzRevFlag==0))
						{
							latestRlzRevFlag = 1;

							//printf("\n inside erc released condition1111111111");fflush(stdout);
					  printf("\n inside erc released condition22222222222");fflush(stdout);
					  tc_strcpy(ErcYes,"");
					  tc_strcpy(ErcYes,"YES");
					  printf("\n yes status .......%s\n", ErcYes);fflush(stdout);
					  latestRlzRevTag=allrev_list[A];


					  ITK_CALL(AOM_ask_value_string(latestRlzRevTag,"item_id",&RelItemNametag));

			           printf("\n latest released .......%s\n", RelItemNametag);fflush(stdout);
			           
			           ITK_CALL(AOM_UIF_ask_value(latestRlzRevTag,"current_revision_id",&RelItemRevid));
			           printf("\n latest released rev id .........%s\n", RelItemRevid);fflush(stdout);
			           
			           ITK_CALL(AOM_ask_value_string(latestRlzRevTag,"t5_PartType",&RelParttypetag));
			           printf("\n latest released part yype .........%s\n", RelParttypetag);fflush(stdout);

					   ITK_CALL(AOM_ask_value_string(latestRlzRevTag,"object_desc",&RelObjectDescrtag));
			           printf("\n Object Description  .........%s\n", RelObjectDescrtag);fflush(stdout);
					   	STRNG_replace_str(RelObjectDescrtag,",",":",&RelObjectDescrtag);
						STRNG_replace_str(RelObjectDescrtag,"\n",":",&RelObjectDescrtag);

					   ITK_CALL(AOM_ask_value_string(latestRlzRevTag,"t5_PunMakeBuyIndicator",&MakeBye));
			           printf("\n Cs Pune Make Bye .........%s\n", MakeBye);fflush(stdout);
			           
			           ITK_CALL(AOM_UIF_ask_value(latestRlzRevTag,"release_status_list",&latestercreleased));
			           printf("\n latest released status .........%s\n", latestercreleased);fflush(stdout);


					   ITKCALL(BOM_create_window(&bom_wnd ));      //set new bom window
		               ITK_CALL( BOM_set_window_top_line( bom_wnd, NULLTAG, latestRlzRevTag, NULLTAG, &top_lne ));

					   ITK_CALL(AOM_UIF_ask_value(top_lne,"bl_revision_effectivity",&RevEffectivity));
			           printf("\n bl_revision_effectivity .........%s\n", RevEffectivity);fflush(stdout);

					   if(tc_strstr(Chld_Rel_Stus1,"T5_LcsErcRlzd")!=NULL|| tc_strstr(Chld_Rel_Stus1,"ERC Released")!=NULL)
					   {
					   
							tc_strcpy(latestercreleased,"");
							tc_strcat(latestercreleased,"ERC Released");
							printf("\n latest released status inside condition .........%s\n", latestercreleased);fflush(stdout);

					   }


			           fprintf(fp,"\n%s,%s,%s,%s,%s,%s,%s,%s",RelItemNametag,RelItemRevid,RelParttypetag,latestercreleased,RevEffectivity,MakeBye,RelObjectDescrtag,ErcYes);fflush(stdout); 

							
							break;
						}
						else if((tc_strstr(Chld_Rel_Stus1,"T5_LcsErcRlzd")!=NULL|| tc_strstr(Chld_Rel_Stus1,"ERC Released")!=NULL))
						{ 
							
						latestRlzRevTag=allrev_list[A];

					  ITK_CALL(AOM_ask_value_string(latestRlzRevTag,"item_id",&RelItemNametag));

			           printf("\n latest released .......%s\n", RelItemNametag);fflush(stdout);
			           
			           ITK_CALL(AOM_UIF_ask_value(latestRlzRevTag,"current_revision_id",&RelItemRevid));
			           printf("\n latest released rev id .........%s\n", RelItemRevid);fflush(stdout);
			           
			           ITK_CALL(AOM_ask_value_string(latestRlzRevTag,"t5_PartType",&RelParttypetag));
			           printf("\n latest released part yype .........%s\n", RelParttypetag);fflush(stdout);
					   ITK_CALL(AOM_ask_value_string(latestRlzRevTag,"object_desc",&RelObjectDescrtag));
			           printf("\n Object Description .........%s\n", RelObjectDescrtag);fflush(stdout);
					   STRNG_replace_str(RelObjectDescrtag,",",":",&RelObjectDescrtag);
						STRNG_replace_str(RelObjectDescrtag,"\n",":",&RelObjectDescrtag);
					   ITK_CALL(AOM_ask_value_string(latestRlzRevTag,"t5_PunMakeBuyIndicator",&MakeBye));
			           printf("\n Cs Pune Make Bye .........%s\n", MakeBye);fflush(stdout);
 
			           ITK_CALL(AOM_UIF_ask_value(latestRlzRevTag,"release_status_list",&latestercreleased));
			           printf("\n latest released status .........%s\n", latestercreleased);fflush(stdout);
					   ITKCALL(BOM_create_window(&bom_wnd ));      //set new bom window
		               ITK_CALL( BOM_set_window_top_line( bom_wnd, NULLTAG, latestRlzRevTag, NULLTAG, &top_lne ));

					   ITK_CALL(AOM_UIF_ask_value(top_lne,"bl_revision_effectivity",&RevEffectivity));
			           printf("\n bl_revision_effectivity .........%s\n", RevEffectivity);fflush(stdout);

						if(tc_strstr(Chld_Rel_Stus1,"T5_LcsErcRlzd")!=NULL|| tc_strstr(Chld_Rel_Stus1,"ERC Released")!=NULL)
					   {
					   
							tc_strcpy(latestercreleased,"");
							tc_strcat(latestercreleased,"ERC Released");
							printf("\n latest released status inside condition .........%s\n", latestercreleased);fflush(stdout);

					   }
			           fprintf(fp,"\n%s,%s,%s,%s,%s,%s,%s",RelItemNametag,RelItemRevid,RelParttypetag,latestercreleased,RevEffectivity,MakeBye,RelObjectDescrtag);fflush(stdout);

						}
					}
			  }
			 
				
			}
			//fprintf(fp,"\n");fflush(stdout);


			}
}


		if(fp)
		{
			fclose(fp);
			fp=NULL;
		}

		
			//}

  return 0;
}
