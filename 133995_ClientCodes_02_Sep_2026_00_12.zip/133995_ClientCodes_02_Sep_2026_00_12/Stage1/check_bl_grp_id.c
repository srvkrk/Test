/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_bl_grp_id.c
**
** Functions:- 	This utility queries item into teamcenter on the basis of part_type and design_group and gets all revision and send it to SM and gets 
				single level bomlines present under part's top bomline & checks for Group ID if found get it's secondary object(Creo Assembly)
				if found check dataset's owner and print it's information into the file.(project_code is command line input)
** 
**
**	Date							Author								Modification
**	26-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_bl_grp_id -u=<username> -p=<password> -g=<group> -prj_code=<project_code>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


FILE		*output 			= NULL;

char		*sep				= ",";
int			ifail 				= ITK_ok;

//int run_item_query();
int get_parts(char *);
//int write_info(char *, char *, char *, char *);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -prj_code=<Project Code> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* prj_code					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	prj_code 		= ITK_ask_cli_argument("-prj_code=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.csv",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(prj_code)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = get_parts(prj_code);
		CHECK_FAIL;
		
	fclose(output);
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/********************************************************************************************
    Function:       get_parts
    Description:    This function takes the item_tag and object_id as input and writes 
					item's information into a file.
********************************************************************************************/
int get_parts(char *prj_code)
{
	int				i 								= 0;
	int				j 								= 0;
	int				k 								= 0;
	int				n_count 						= 0;
	int				results 						= 0;
	int				bl_count						= 0;
	int				sec_count						= 0;
	
	tag_t			latest_rev_tag				= NULLTAG;
	tag_t			window						= NULLTAG;
	tag_t			top_bomline					= NULLTAG;
	tag_t			query_tag					= NULLTAG;
	tag_t			relation					= NULLTAG;
	tag_t			child_tag					= NULLTAG;
	tag_t			child_rev_tag				= NULLTAG;
	tag_t			*rev_tag					= NULL;
	tag_t			*bl_child					= NULL;
	tag_t			*sec_objects				= NULL;
	
	
	char 			*owner						= NULL;
	char 			*item_id					= NULL;
	char 			*rev_id						= NULL;
	char 			*owning_user				= NULL;
	char 			*design_grp					= NULL;
	char 			*bl_child_id				= NULL;
	char 			*bl_object_type				= NULL;
	char 			*sec_object_type			= NULL;
	char 			*bl_type					= "Group Id";
	
	char			*entry0						= "Part Type";
	char			*entry1						= "Project Code";
	
	char			*type						= "Module";
	//char			*prj_code					= "5442";
	
	
	char *test2 		= (char*)MEM_alloc(sizeof(char) * 2);
	char *designGrps	= (char *) MEM_alloc(500);

	char **entries		= (char**) MEM_alloc (sizeof(char*) * 2);
	char **values		= (char**) MEM_alloc (sizeof(char*) * 2);
	
	entries[0] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry0) + 10));
	values[0]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(type) + 10));
			
	entries[1] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry1) + 10));
	values[1]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(prj_code) + 10));
			
	tc_strcpy(entries[0], "");	
	tc_strcpy(entries[0], entry0);
	tc_strcpy(values[0], "");	
	tc_strcpy(values[0], type);
	
	tc_strcpy(entries[1], "");	
	tc_strcpy(entries[1], entry1);
	tc_strcpy(values[1], "");	
	tc_strcpy(values[1], prj_code);
	
	printf("Entering into function");
	strcpy(designGrps,"00,01,02,03,04,05,06,07,08,09,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,55,56,57,58,59");
	
	//attrs[0] 	= "item_id";
	//values[0] 	= "544*";
	
	ifail = QRY_ignore_case_on_search(TRUE);
	ifail = QRY_find2("module_query_kp", &query_tag);
		
	if(query_tag == NULLTAG)
	{
		printf("\nQuery Not Found in TC....!!\n");
		return 0;
	}
	else
	{
		ifail = QRY_execute(query_tag,2, entries, values, &results, &rev_tag);
		if(results > 0)
		{
			printf("\nTotal %d object found...!!\n",results);
			for(i=0; i < results; i++)
			{
				ifail = AOM_UIF_ask_value (rev_tag[i], "item_id", &item_id);
				printf("\n\nitem_id:%s", item_id);
				
				ifail = AOM_UIF_ask_value (rev_tag[i], "item_revision_id", &rev_id);
				printf("\nrev_id:%s", rev_id);
				
				ifail = AOM_UIF_ask_value (rev_tag[i], "t5_DesignGrp", &design_grp);
				printf("\nDesign group:%s\n", design_grp);
				
				if(tc_strstr(designGrps,design_grp))
				{
					printf("Proe Design group...!!");
					ifail = BOM_create_window (&window);
					ifail = BOM_set_window_top_line (window, NULLTAG, rev_tag[i], NULLTAG, &top_bomline);
				
					ifail = BOM_line_ask_child_lines (top_bomline, &bl_count, &bl_child);
					printf("\nbomline_count:%d",bl_count);
					for(j=0; j < bl_count; j++)
					{
						ifail = AOM_UIF_ask_value(bl_child[j], "bl_child_id", &bl_child_id);
						printf("\nBomline child_id:%s",bl_child_id);
						
						ifail = ITEM_find_item (bl_child_id, &child_tag);
						ifail = ITEM_ask_latest_rev (child_tag, &child_rev_tag);
						
						ifail = AOM_UIF_ask_value(bl_child[j], "bl_Design_t5_RevPartType", &bl_object_type);
						printf("\nBomline Part_type:%s",bl_object_type);
						
						if(tc_strcmp(bl_object_type, bl_type) == 0)
						{
							printf("\nBomline found:%s\n", bl_object_type);
							ifail = GRM_find_relation_type ("IMAN_specification", &relation);
							ifail = GRM_list_secondary_objects_only (child_rev_tag, relation, &sec_count, &sec_objects);
							
							for(k=0;k < sec_count; k++)
							{
								ifail = AOM_UIF_ask_value(sec_objects[k], "object_type", &sec_object_type);
								printf("secondary_object_type:%s",sec_object_type);
								if(tc_strcmp(sec_object_type, "Creo assembly") == 0)
								{
									ifail = AOM_UIF_ask_value(sec_objects[k], "owning_user", &owning_user);
									printf("\nOwner of CAD Dataset is:%s\n", owning_user);
									//if(tc_strcmp(owning_user, "loader (loader)") == 0)
									//{
										//ifail = write_info(item_id, rev_id, bl_child_id, owning_user);
										tc_strcpy(test2, "");
										tc_strcpy(test2, item_id);
										tc_strcat(test2,sep);
										tc_strcat(test2,rev_id);
										tc_strcat(test2,sep);
										tc_strcat(test2,bl_child_id);
										tc_strcat(test2,sep);
										tc_strcat(test2,owning_user);
										
										fprintf(output,"%s\n",test2);
									//}
								}
								//MEM_free(owning_user);
								//MEM_free(sec_object_type);
							}
							MEM_free(sec_objects);
							MEM_free(bl_object_type);
						}
						else
						{
							printf("\nGroup ID Not found\n");
						}
						MEM_free(bl_child_id);
					}
				}
			}
			MEM_free(design_grp);
			MEM_free(rev_id);
			MEM_free(item_id);
		}
	}
	return ifail;
}

/********************************************************************************************
    Function:       write_info
    Description:    This function takes item_id, rev_id, bl_child_id and owning_user as input 
					and write it into the file.(newly created)
********************************************************************************************/
/*int write_info(char* item_id, char* rev_id, char* bl_child_id, char* owning_user)
{	
	char 		*test2 				= (char*)MEM_alloc(sizeof(char) * 2);
	char		*final2				= (char*)MEM_alloc(sizeof(char) * 2);
		
		tc_strcpy(test2, "");
		tc_strcpy(test2, item_id);
		tc_strcat(test2,sep);
		tc_strcat(test2,rev_id);
		tc_strcat(test2,sep);
		tc_strcat(test2,bl_child_id);
		tc_strcat(test2,sep);
		tc_strcat(test2,owning_user);
		
		tc_strcpy(final2,test2);
		
		fprintf(output,"%s\n",final2);
	
		//MEM_free(final2);
		//MEM_free(test2);		
		return ifail;
}
*/