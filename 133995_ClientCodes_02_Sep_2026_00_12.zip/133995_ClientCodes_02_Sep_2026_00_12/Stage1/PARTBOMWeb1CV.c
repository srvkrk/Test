/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: CasCave_Des.c
*  Created By      :  ABHI
*  Created On      :23/11/2023
*  Project         :  APL
**
*******************************************************************************/
//#include "soapH.h"								/* get the gSOAP-generated definitions */
//#include "CasCave_Des.nsmap"		 /* get the gSOAP-generated namespace bindings */
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
//#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
//#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tccore/project.h>
#include <cfm/cfm.h>
#include <qry/qry.h>
#include <tc/preferences.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>

FILE	*PrtBomExecutionLog;
FILE	*PartBomQryResult;

#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); Debug("line %d (ifail %d)\n", __LINE__, ifail);}

struct Prt_Bom
{
	char	Level[5];
	char	PartNumber[30];
	char	PartRev[5];
	char PartSeq[5];
	char	PartWeight[20];
	char	PartSurfArea[50];
	char	PartVolume[50];
	char	PartCS[50];
	char	PartMaterial[50];
	char	PartDesc[500];
	char	PartProjCode[10];
	char	PartProjDesc[500];
	char	PEnvDia[500];
	char	PThickness[300];
	char	PParttype[300];
	char	Qty[5];

}get_Prt_List_Rev;


     int ifail =0;
	 int count=0;
	 int n_closure_tags=	0;

	 tag_t* childLines		= NULLTAG;
	 tag_t * 	closure_tags	= NULLTAG;
	 tag_t	closure_tag		=	NULLTAG;

	char*			responseString			= NULL;
	char*			responseString1			= NULL;
	char*			responseString2			= NULL;
	char*			responseString3			= NULL;
	char*			responseString4			= NULL;
	char*			responseString5			= NULL;
	char*			responseString6			= NULL;
	char*			responseString7         = NULL;
	char*			responseString8         = NULL;
	char*			responseString9         = NULL;
	char*			responseString10        = NULL;
	char*			responseString11        = NULL;
	char*			responseString12       = NULL;
	char*			responseString13       = NULL;
	char*			responseString14       = NULL;
	char*			responseString15       = NULL;
	char*			responseString16       = NULL;

	char	*closureRuleName					=	NULL;


PIE_scope_t scope;

char 		szHMCL_file_log[250] 			= "";
char 		szHMCL_file_err[250]			= "";
char 		szHMCL_file_output[250] 		= "";
static void vLog(char* givenFormat, va_list givenArgs, char* fileName)
{
	char			* logFile 			= NULL;
	FILE			* logFp;
	time_t 			now;
	struct 			tm when;
	char 			date_str[50];
	long 			size;
	logical 		check_size 			= false;
	logFile 							= fileName;
	if (logFile)
	{
		logFp = fopen(logFile, "a+");
		if(!logFp)
		{
			fprintf(stderr, "ERROR: Cannot open '%s'\n", logFile);
			perror(logFile);
			logFp = stderr;
		}
		else{
			fseek(logFp, 0, SEEK_END);
			size = ftell(logFp);
			if(size > 3000000 && check_size)
			{	fclose (logFp);
				logFp = fopen(logFile, "w");
			}
			  }
	}
	else
	{	logFp = stderr;
	}
	if (tc_strcmp(logFile, szHMCL_file_output) == 0)
	{
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp,"\n");
		if (logFp != stderr)
		{			fclose(logFp);
		}
	}
	else
	{
		time(&now);
		when = *localtime(&now);
		strftime(date_str, 50, "%d-%m-%Y %H:%M:%S",&when);
		fprintf(logFp, "%s --- ", date_str);
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp, "\n");
		if (logFp != stderr)
		{	fclose(logFp);
		}
	}
}
void Debug(char* givenFormat, ...)
{
	va_list   functArgs;
	va_start(functArgs, givenFormat);
	vLog(givenFormat, functArgs, szHMCL_file_log);
	va_end(functArgs);
}

char* remove_specialCharDesc(char *in) 
{	
	//printf("\n Test Inside Function remove_specialCharDesc \n");fflush(stdout);
	fprintf(PrtBomExecutionLog,"Test Inside Function remove_specialCharDesc\n"); fflush(PrtBomExecutionLog);

	int i,j;
	char *tmp;
	tmp=(char *)malloc(strlen(in)+2);
	i=0;
	j=0;
	while (in[j])
	{
		//if (in[j] != '\x01' && in[j] != '\x02')
		//if (in[j] != '\n' && in[j] != '\r'  && in[j] != ',' )
		if ( (in[j] != '*') )
		{
			tmp[i] = in[j];
			i++;
		}
		j++;
	}
	tmp[i]='\0';

 

return tmp;
}

/* Function to add Tag into a set of Tag */
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{
*count=*count+1;
if(*count==1)
{
printf("\n ****setAddTAG1******************\n");fflush(PrtBomExecutionLog);
(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
}
else
{
printf("\n ****setAddTAG2*********************\n");fflush(PrtBomExecutionLog);
(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
}
(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf);

char* subString
(
	char* mainStringf ,
	int fromCharf     ,
	int toCharf
)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(toCharf+1);
	for(i=0; i < toCharf; i++ )
     *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
 if (return_code != ITK_ok)
	{
	// char *error_msg_string;

	// EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
	// printf("ERROR1: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
	// TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
	// printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
	// TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
	// if(error_msg_string) MEM_free(error_msg_string);

	char *error_msg_string;

	EMH_ask_error_text (return_code, &error_msg_string);
	printf("ERROR1: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
	TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
	TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
	if(error_msg_string) MEM_free(error_msg_string);

	}
	return return_code;
}

int ITK_user_main(int argc, char *argv[])
{
	//return soap_serve(soap_new());
    int iStatus = 0;
	
	char *partnumber  = ITK_ask_cli_argument("-prt=");
	char *revision  = ITK_ask_cli_argument("-rev=");
	char *ISequence  = ITK_ask_cli_argument("-seq=");
	char *ER_EW  = ITK_ask_cli_argument("-lc=");
	char *Plant  = ITK_ask_cli_argument("-pl=");
	printf("part_no ---> [%s,%s,%s,%s,%s]\n",partnumber,revision,ISequence,ER_EW,Plant);fflush(stdout);

/*	struct ns__plmPartDetail
    {
	    char	*PLevel;
		char	*PartNum; 
    	char	*Revision;
		char	*Sequence;
        char *Weight;
     	char	*SurArea;
     	char	*Volume;
     	char	*CS;     
	    char	*Material;
		char	*Descrpt;
		char	*ProjCode;
		char	*ProjDesc;
		char	*PEnvDia;
		char	*Thickness;
		char	*Parttype;		
		char	*c_Qty;
  };

struct ns__CharArray4Test 
{
	int __size;
	struct ns__plmPartDetail *__plmPartDetail;		
};   */

	iStatus = TC_auto_login();

	if(iStatus == ITK_ok)
	{
		printf("\n ** Login Successful ** \n");fflush(stdout);
		ns__getPartDetailCasCave(partnumber,revision,ISequence,ER_EW,Plant);
		printf("\n ** execution of tcua partbomweb Successful ** \n");fflush(stdout);
	
	}
	else
	{
		printf("\n\n\t Login UnSuccessful\n");fflush(stdout);
	}
}


int getBomLineAttributes(tag_t tagBOMline)                /*Getting all attributes of BOM line which is required for web service*/
{
	tag_t  projobj=NULLTAG;
	char*   partNumber = NULL;
	char*   partRevNumber = NULL;
	char*   partSeqNumber = NULL;
	char *  item_level= NULL;
	char *  quantity = NULL;
	char *  PuneCS= NULL;
	char* Weight= NULL;
	char* PartProjCode1 = NULL;
	char* CS= NULLTAG;
	char* PartProjCode = NULLTAG;
	char* PartType = NULLTAG;
	char* Material = NULLTAG;
	char* Description = NULLTAG;
	char*	SurfaceArea =NULL;
	char*	Volume =NULL;
	char*	Thicknes =NULL;
	char*	EnvelopeDimensions =NULL;
	char	*ModItem_Rev			=	NULL;
	char	*ModItem_Seq			=	NULL;

	responseString1=(char *)MEM_alloc(200);
	responseString2=(char *)MEM_alloc(200);
	responseString3=(char *)MEM_alloc(200);
	responseString4=(char *)MEM_alloc(200);
	responseString5=(char *)MEM_alloc(200);
	responseString6=(char *)MEM_alloc(200);
	responseString7=(char *)MEM_alloc(200);
	responseString8=(char *)MEM_alloc(200);
	responseString9=(char *)MEM_alloc(200);
	responseString10=(char *)MEM_alloc(200);
	responseString11=(char *)MEM_alloc(200);
	responseString12=(char *)MEM_alloc(200);
	responseString13=(char *)MEM_alloc(200);
	responseString14=(char *)MEM_alloc(200);
	responseString15=(char *)MEM_alloc(200);
	responseString16=(char *)MEM_alloc(200);

    fprintf(PrtBomExecutionLog,"-----------------------------------------------------------------------------------------***\n");fflush(PrtBomExecutionLog);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_level_starting_0",&item_level);
	fprintf(PrtBomExecutionLog,"Part Level number===>%s\n",item_level);fflush(PrtBomExecutionLog);
	tc_strcpy(responseString1,"");
	tc_strcat(responseString1,item_level);

	ifail=AOM_ask_value_string(tagBOMline,"bl_item_item_id",&partNumber);
	fprintf(PrtBomExecutionLog,"Part number===>%s\n",partNumber);fflush(PrtBomExecutionLog);
    tc_strcpy(responseString2,"");
	tc_strcat(responseString2,partNumber);

    ifail=AOM_ask_value_string(tagBOMline,"bl_rev_item_revision_id",&partRevNumber);
	fprintf(PrtBomExecutionLog,"Part Rev number===>%s\n",partRevNumber);fflush(PrtBomExecutionLog);

   	ModItem_Rev =  tc_strtok(partRevNumber,";");
	fprintf(PrtBomExecutionLog,"Item_Rev --> : %s\n",ModItem_Rev); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString3,"");
	tc_strcat(responseString3,ModItem_Rev);

	ModItem_Seq = tc_strtok(NULL,";");
	fprintf(PrtBomExecutionLog,"Item_Seq ----> : %s\n",ModItem_Seq); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString4,"");
	tc_strcat(responseString4,ModItem_Seq);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_Weight",&Weight);
	fprintf(PrtBomExecutionLog,"Part Weight: [%s]\n", Weight); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString5,"");
	tc_strcat(responseString5,Weight);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_SurfaceArea",&SurfaceArea);
	fprintf(PrtBomExecutionLog,"SurfaceArea : [%s]\n", SurfaceArea); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString6,"");
	tc_strcat(responseString6,SurfaceArea);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_Volume",&Volume);
	fprintf(PrtBomExecutionLog,"Volume : [%s]\n", Volume); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString7,"");
	tc_strcat(responseString7,Volume);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_PunMakeBuyIndicator",&PuneCS);
	fprintf(PrtBomExecutionLog,"Part CS number=>%s\n",PuneCS);fflush(PrtBomExecutionLog);
	tc_strcpy(responseString8,"");
	tc_strcat(responseString8,PuneCS);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_Material",&Material);
	fprintf(PrtBomExecutionLog,"Material: [%s]\n", Material); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString9,"");
	tc_strcat(responseString9,Material);

	ifail=AOM_ask_value_string(tagBOMline,"bl_rev_object_desc",&Description);
	fprintf(PrtBomExecutionLog,"object_description: [%s]\n", Description); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString10,"");
	tc_strcat(responseString10,Description);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_ProjectCode",&PartProjCode);
	fprintf(PrtBomExecutionLog,"Part ProjCode: [%s]\n", PartProjCode); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString11,"");
	tc_strcat(responseString11,PartProjCode);

	 ITKCALL (PROJ_find(PartProjCode,&projobj));
	 if(projobj !=NULLTAG)
	{
		AOM_ask_value_string(projobj,"project_desc",&PartProjCode1);
	 	fprintf(PrtBomExecutionLog,"Project Description:%s", PartProjCode1); fflush(PrtBomExecutionLog);
		tc_strcpy(responseString12,"");
		tc_strcat(responseString12,PartProjCode1);
	}
	else
	{	fprintf(PrtBomExecutionLog,"Project not Resister for Item\n");fflush(PrtBomExecutionLog); }

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_EnvelopeDimensions",&EnvelopeDimensions);
	fprintf(PrtBomExecutionLog,"EnvelopeDimensions : [%s]\n", EnvelopeDimensions); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString13,"");
	tc_strcat(responseString13,EnvelopeDimensions);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_MThickness",&Thicknes);
	fprintf(PrtBomExecutionLog,"Thicknes : [%s]\n", Thicknes); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString14,"");
	tc_strcat(responseString14,Thicknes);

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_PartType",&PartType);
	fprintf(PrtBomExecutionLog,"PartType: [%s]\n", PartType); fflush(PrtBomExecutionLog);
	tc_strcpy(responseString15,"");
	tc_strcat(responseString15,PartType);

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_quantity",&quantity);
	fprintf(PrtBomExecutionLog,"Part Quantity number===>%s\n",quantity);fflush(PrtBomExecutionLog);
	tc_strcpy(responseString16,"");
	tc_strcat(responseString16,quantity);
	fprintf(PrtBomExecutionLog,"--------------------------------------****---------------------------------------------------\n\n");fflush(PrtBomExecutionLog);

	return 0;
}

int findChild(tag_t AffectedObjectBomLineTag1, int  bomlineItemId , int  bomlineRevId , int bomlineItemRevAttr)
{
	int 			count2 					 				= 0;
	int 			childCountCfgTopBomLine1 				= 0;
	int 			childCountCfgTopBomLine2 				= 0;
	tag_t   		*childTagCfgTopBomLine1	  				= NULLTAG;
	tag_t   		*childTagCfgTopBomLine2	  				= NULLTAG;
	char*   partNumber = NULL;
	char *  item_level= NULL;

	ifail=BOM_line_ask_child_lines(AffectedObjectBomLineTag1, &childCountCfgTopBomLine1, &childTagCfgTopBomLine1);
	CHECK_FAIL;

	ifail=AOM_UIF_ask_value(AffectedObjectBomLineTag1,"bl_level_starting_0",&item_level);
	fprintf(PrtBomExecutionLog,"Child Part Level number===>%s\n",item_level);fflush(PrtBomExecutionLog);

	ifail=AOM_ask_value_string(AffectedObjectBomLineTag1,"bl_item_item_id",&partNumber);
	fprintf(PrtBomExecutionLog,"Chilld Part number===>%s\n",partNumber);fflush(PrtBomExecutionLog);

	fprintf(PrtBomExecutionLog,"*********Number of Child Lines are [%d] for Part [ %s] and its level is [%s]  \n",childCountCfgTopBomLine1,partNumber,item_level);fflush(PrtBomExecutionLog);

	for (count2 = 0;count2 < childCountCfgTopBomLine1;count2++)
	{
		ifail=getBomLineAttributes(childTagCfgTopBomLine1[count2]);CHECK_FAIL;

		ifail=BOM_line_ask_child_lines(childTagCfgTopBomLine1[count2], &childCountCfgTopBomLine2, &childTagCfgTopBomLine2);CHECK_FAIL;

		fprintf(PrtBomExecutionLog,"Number of Child Lines %d \n",childCountCfgTopBomLine2);fflush(PrtBomExecutionLog);
        fprintf(PrtBomExecutionLog,"-----------------------------------------------------------------------------------------\n");fflush(PrtBomExecutionLog);

		if (childCountCfgTopBomLine2 != 0)
			{
				ifail = findChild(childTagCfgTopBomLine1[count2],bomlineItemId ,bomlineRevId,bomlineItemRevAttr);CHECK_FAIL;
			}
			else
		    { fprintf(PrtBomExecutionLog,"NO Child Lines Present\n");fflush(PrtBomExecutionLog);
			}
	}
	return 0;
}

/*calling BOM Window Child Part Line Count for tags and calling recursive function as well*/

int findChildTag(tag_t tagBOMline,struct Prt_Bom prtLst[ ],int* StrctInt)
{
	int 			count2 					 				= 0;
	int 			childCountCfgTopBomLine1 				= 0;
	int 			childCountCfgTopBomLine2 				= 0;
	tag_t   		*childTagCfgTopBomLine1	  				= NULLTAG;
	tag_t   		*childTagCfgTopBomLine2	  				= NULLTAG;
	tag_t   projobj	  				= NULLTAG;

	char*   partNumber = NULL;
	char*   partRevNumber = NULL;
	char*   partSeqNumber = NULL;
	char *  item_level= NULL;
	char *  quantity = NULL;
	
	char *  PuneCS= NULL;
	char* Weight= NULL;
	char* PartProjCode1 = NULLTAG;
	char* CS= NULLTAG;
	char* PartProjCode = NULLTAG;
	char* PartType = NULLTAG;
	char* Material = NULLTAG;
	char* Description = NULLTAG;
	char*	SurfaceArea =NULL;
	char*	Volume =NULL;
	char*	Thicknes =NULL;
	char*	EnvelopeDimensions =NULL;
	char	*ModItem_Rev			=	NULL;
	char	*ModItem_Seq			=	NULL;
	char	*Temp1			=	NULL;
	char	*TempReslt			=	NULL;

	TempReslt=(char *)MEM_alloc(3000);
	tc_strcpy(TempReslt,"");

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_level_starting_0",&item_level);
	fprintf(PrtBomExecutionLog,"Part Level number===>%s\n",item_level);fflush(PrtBomExecutionLog);
	if(tc_strcmp(item_level,"")==0)
	{
		item_level=(char *)MEM_alloc(20);
		tc_strcpy(item_level,"NA");
	}
	else//if(tc_strstr(item_level,","))
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(item_level,",","_",&Temp1);

			  item_level=(char *)MEM_alloc(20);
              tc_strcpy(item_level,"");
			  tc_strcpy(item_level,Temp1);
	}
	tc_strcat(TempReslt,item_level);
	tc_strcat(TempReslt,",");
	ifail=AOM_ask_value_string(tagBOMline,"bl_item_item_id",&partNumber);
	fprintf(PrtBomExecutionLog,"Part number===>%s\n",partNumber);fflush(PrtBomExecutionLog);
	if(tc_strcmp(partNumber,"")==0)
	{
		partNumber=(char *)MEM_alloc(100);
		tc_strcpy(partNumber,"NA");
	}
	//if(tc_strstr(partNumber,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(partNumber,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"'\n'"," ",&partNumber);
			  STRNG_replace_str(partNumber,"    ","",&Temp1);

			  partNumber=(char *)MEM_alloc(100);
              tc_strcpy(partNumber,"");
			  tc_strcpy(partNumber,Temp1);
	}
	tc_strcat(TempReslt,partNumber);
	tc_strcat(TempReslt,",");

    ifail=AOM_ask_value_string(tagBOMline,"bl_rev_item_revision_id",&partRevNumber);
	fprintf(PrtBomExecutionLog,"Part Rev number===>%s\n",partRevNumber);fflush(PrtBomExecutionLog);
	if(tc_strcmp(partRevNumber,"")==0)
	{
		partRevNumber=(char *)MEM_alloc(200);
		tc_strcpy(partRevNumber,"NA");
	}

	ModItem_Rev =  tc_strtok(partRevNumber,";");
	fprintf(PrtBomExecutionLog,"Item_Rev --> : %s\n",ModItem_Rev); fflush(PrtBomExecutionLog);
	if(tc_strcmp(ModItem_Rev,"")==0)
	{
		ModItem_Rev=(char *)MEM_alloc(20);
		tc_strcpy(ModItem_Rev,"NA");
	}
	//if(tc_strstr(ModItem_Rev,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(ModItem_Rev,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"'\n'"," ",&ModItem_Rev);
			  STRNG_replace_str(ModItem_Rev,"^"," ",&Temp1);

			  ModItem_Rev=(char *)MEM_alloc(20);
              tc_strcpy(ModItem_Rev,"");
			  tc_strcpy(ModItem_Rev,Temp1);
	}
	tc_strcat(TempReslt,ModItem_Rev);
	tc_strcat(TempReslt,",");

	ModItem_Seq = tc_strtok(NULL,";");
	fprintf(PrtBomExecutionLog,"Item_Seq --> : %s\n",ModItem_Seq); fflush(PrtBomExecutionLog);
	if(tc_strcmp(ModItem_Seq,"")==0)
	{
		ModItem_Seq=(char *)MEM_alloc(200);
		tc_strcpy(ModItem_Seq,"NA");
	}
	//if(tc_strstr(ModItem_Seq,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(ModItem_Seq,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&ModItem_Seq);
			  STRNG_replace_str(ModItem_Seq,"^"," ",&Temp1);

			  ModItem_Seq=(char *)MEM_alloc(20);
              tc_strcpy(ModItem_Seq,"");
			  tc_strcpy(ModItem_Seq,Temp1);
	}
	tc_strcat(TempReslt,ModItem_Seq);
	tc_strcat(TempReslt,",");

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_Weight",&Weight);
	fprintf(PrtBomExecutionLog,"Part Weight: [%s]\n", Weight); fflush(PrtBomExecutionLog);
	if(tc_strcmp(Weight,"")==0)
	{
		Weight=(char *)MEM_alloc(200);
		tc_strcpy(Weight,"NA");
	}
	//if(tc_strstr(Weight,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(Weight,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&Weight);
			  STRNG_replace_str(Weight,"^"," ",&Temp1);

			  Weight=(char *)MEM_alloc(200);
              tc_strcpy(Weight,"");
			  tc_strcpy(Weight,Temp1);
	}
	tc_strcat(TempReslt,Weight);
	tc_strcat(TempReslt,",");

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_SurfaceArea",&SurfaceArea);
	fprintf(PrtBomExecutionLog,"SurfaceArea : [%s]\n", SurfaceArea); fflush(PrtBomExecutionLog);
	if(tc_strcmp(SurfaceArea,"")==0)
	{
		SurfaceArea=(char *)MEM_alloc(200);
		tc_strcpy(SurfaceArea,"NA");
	}
	//if(tc_strstr(SurfaceArea,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(SurfaceArea,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&SurfaceArea);
			  STRNG_replace_str(SurfaceArea,"^"," ",&Temp1);

			  SurfaceArea=(char *)MEM_alloc(200);
              tc_strcpy(SurfaceArea,"");
			  tc_strcpy(SurfaceArea,Temp1);
	}
	tc_strcat(TempReslt,SurfaceArea);
	tc_strcat(TempReslt,",");

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_Volume",&Volume);
	fprintf(PrtBomExecutionLog,"Volume : [%s]\n", Volume); fflush(PrtBomExecutionLog);
	if(tc_strcmp(Volume,"")==0)
	{
		Volume=(char *)MEM_alloc(200);
		tc_strcpy(Volume,"NA");
	}
	//if(tc_strstr(Volume,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(Volume,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&Volume);
			  STRNG_replace_str(Volume,"^"," ",&Temp1);

			  Volume=(char *)MEM_alloc(200);
              tc_strcpy(Volume,"");
			  tc_strcpy(Volume,Temp1);
	}
	tc_strcat(TempReslt,Volume);
	tc_strcat(TempReslt,",");

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_PunMakeBuyIndicator",&PuneCS);
	fprintf(PrtBomExecutionLog,"Part CS number===>%s\n",PuneCS);fflush(PrtBomExecutionLog);
	if(tc_strcmp(PuneCS,"")==0)
	{
		PuneCS=(char *)MEM_alloc(200);
		tc_strcpy(PuneCS,"NA");
	}
	//if(tc_strstr(PuneCS,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(PuneCS,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&PuneCS);
			  STRNG_replace_str(PuneCS,"^"," ",&Temp1);

			  PuneCS=(char *)MEM_alloc(200);
              tc_strcpy(PuneCS,"");
			  tc_strcpy(PuneCS,Temp1);
	}
	tc_strcat(TempReslt,PuneCS);
	tc_strcat(TempReslt,",");

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_Material",&Material);
	fprintf(PrtBomExecutionLog,"Material: [%s]\n", Material); fflush(PrtBomExecutionLog);
	if(tc_strcmp(Material,"")==0)
	{
		Material=(char *)MEM_alloc(200);
		tc_strcpy(Material,"NA");
	}
	//if(tc_strstr(Material,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(Material,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&Material);
			  STRNG_replace_str(Material,"^"," ",&Temp1);
			  STRNG_replace_str(Temp1,"\'"," ",&Material);
			  STRNG_replace_str(Material,"*"," ",&Temp1);
			  STRNG_replace_str(Temp1,"$","",&Material);
			  STRNG_replace_str(Material,"#","",&Temp1);

			  fprintf(PrtBomExecutionLog,"111 New Temp1: [%s]\n", Temp1); fflush(PrtBomExecutionLog);
			
			  Temp1 = remove_specialCharDesc(Temp1);

			  Material=(char *)MEM_alloc(200);
              tc_strcpy(Material,"");
			  tc_strcpy(Material,Temp1);
	}
	tc_strcat(TempReslt,Material);
	tc_strcat(TempReslt,",");

	fprintf(PrtBomExecutionLog,"111 New Material: [%s]\n", Material); fflush(PrtBomExecutionLog);

	ifail=AOM_ask_value_string(tagBOMline,"bl_rev_object_desc",&Description);
	fprintf(PrtBomExecutionLog,"object_description: [%s]\n", Description); fflush(PrtBomExecutionLog);
	if(tc_strcmp(Description,"")==0)
	{
		Description=(char *)MEM_alloc(200);
		tc_strcpy(Description,"NA");
	}
	//if(tc_strstr(Description,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(Description,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&Description);
			  STRNG_replace_str(Description,"^"," ",&Temp1);
			  STRNG_replace_str(Temp1,"\'"," ",&Description);
			  STRNG_replace_str(Description,"*"," ",&Temp1);
			  STRNG_replace_str(Temp1,"#"," ",&Description);
			  STRNG_replace_str(Description,"$"," ",&Temp1);

			  Description=(char *)MEM_alloc(200);
              tc_strcpy(Description,"");
			  tc_strcpy(Description,Temp1);
	}
	tc_strcat(TempReslt,Description);
	tc_strcat(TempReslt,",");

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_ProjectCode",&PartProjCode);
	fprintf(PrtBomExecutionLog,"Part ProjCode: [%s]\n", PartProjCode); fflush(PrtBomExecutionLog);
	if(tc_strcmp(PartProjCode,"")==0)
	{
		PartProjCode=(char *)MEM_alloc(200);
		tc_strcpy(PartProjCode,"NA");
	}
	//if(tc_strstr(PartProjCode,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(PartProjCode,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&PartProjCode);
			  STRNG_replace_str(PartProjCode,"^"," ",&Temp1);

			  PartProjCode=(char *)MEM_alloc(200);
              tc_strcpy(PartProjCode,"");
			  tc_strcpy(PartProjCode,Temp1);
	}
	tc_strcat(TempReslt,PartProjCode);
	tc_strcat(TempReslt,",");

	 //ITKCALL (PROJ_find(PartProjCode,&projobj));
	 //AOM_ask_value_string(projobj,"project_desc",&PartProjCode1);

	  int n_entries11 =	3;
	  char *qry_entries11[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
	  char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
	  int RCount=0;
	  tag_t	Cntl_obj_Qtag11	=	NULLTAG;
	  tag_t *qry_cntrlobjop= NULLTAG;
	  if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
	  {
		 printf("\n Control Object Query Found \n");fflush(stdout);
		 qry_values11[0] =	"PARTBOMWeb1CV" ;
		 qry_values11[1] =	"Project" ;
		 qry_values11[2] =	"1" ;

		 ITKCALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &RCount, &qry_cntrlobjop));
		 fprintf(PrtBomExecutionLog,"\n control object found : %d", RCount); fflush(PrtBomExecutionLog);
          if(RCount>0)
		  {
			  char* Info4 = NULL;
			  char* Info5 = NULL;
			  int p=0;
			  for(p=0;p<RCount;p++)
			  {
		          CALLAPI(AOM_ask_value_string(qry_cntrlobjop[p], "t5_Userinfo4", &Info4));
				  fprintf(PrtBomExecutionLog,"\n PARTBOMWeb1CV Proj Info4 : %s",Info4);fflush(PrtBomExecutionLog);
		          CALLAPI(AOM_ask_value_string(qry_cntrlobjop[p], "t5_Userinfo5", &Info5));
				  fprintf(PrtBomExecutionLog,"\n PARTBOMWeb1CV Proj Info5 : %s",Info5);fflush(PrtBomExecutionLog);

				  if((tc_strstr(Info4,PartProjCode)!=NULL)||(tc_strstr(Info5,PartProjCode)!=NULL))
				  {
					    int n_entries =	1;
                        char *qry_entries[1] = {"Name"};
                        char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
                        int resultCount=0;
                        tag_t	Cntl_obj_Qtag	=	NULLTAG;
                        tag_t *qry_cntrlobj= NULLTAG;
                        if(QRY_find2("General...", &Cntl_obj_Qtag));
                        if(Cntl_obj_Qtag!=NULLTAG)
                        {
                        	printf("\n Control Object Query Found \n");fflush(stdout);
                        	qry_values[0] =PartProjCode;
                        	ITKCALL(QRY_execute(Cntl_obj_Qtag, n_entries, qry_entries, qry_values, &resultCount, &qry_cntrlobj));
                        	fprintf(PrtBomExecutionLog,"No. of control object reslt found : %d", resultCount); fflush(PrtBomExecutionLog);
                        }
                        if(resultCount>0)
                         {
                        	int r =0;
                        	for(r=0;r<resultCount;r++)
                        	 {
                        		projobj=NULLTAG;
                        		projobj=qry_cntrlobj[r];
                        		char* PartProjCode1OBTYPE = NULLTAG;
                        	    AOM_ask_value_string(projobj,"object_type",&PartProjCode1OBTYPE);
                        		fprintf(PrtBomExecutionLog,"\nobject  Type: %s", PartProjCode1OBTYPE); fflush(PrtBomExecutionLog);
                        		if(tc_strcmp(PartProjCode1OBTYPE,"T5_Project")==0)
                        		 {
                        			fprintf(PrtBomExecutionLog,"\n object Type is Poject : %s", PartProjCode1OBTYPE); fflush(PrtBomExecutionLog);
                        			break;
                        		 }
                        	 }
                        
                         }
				  }
				  break;
			  }
		  }
	  }

	 if(projobj !=NULLTAG)
	 {
		AOM_ask_value_string(projobj,"object_desc",&PartProjCode1);	
	 	fprintf(PrtBomExecutionLog,"\nPart Project Description: %s", PartProjCode1); fflush(PrtBomExecutionLog);
          //		int p =0 ;
          //		p= tc_strlen(PartProjCode1);
          //		fprintf(PrtBomExecutionLog,"Part Project Description length : %d", p); fflush(PrtBomExecutionLog);
          //          int k = 0 ;
          //		 printf("Printing the characters:: \n");
          //        for (k = 0; p>=k; k++)
          //		{
          //         // not a white space
          //            printf("%c\n", PartProjCode1[k]); // printing each characters in a new line
          //            
          //        }  commented to reduce execution time
	  }

     if(projobj ==NULLTAG)
     {
		ITKCALL (PROJ_find(PartProjCode,&projobj));
	    AOM_ask_value_string(projobj,"project_desc",&PartProjCode1);
      }
	else
	{	fprintf(PrtBomExecutionLog,"Project not Resister for Item\n");fflush(PrtBomExecutionLog); }
	if(tc_strcmp(PartProjCode1,"")==0)
	{
		PartProjCode1=(char *)MEM_alloc(200);
		tc_strcpy(PartProjCode1,"NA");
	}
	//if(tc_strstr(PartProjCode1,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(PartProjCode1,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"'\n'"," ",&PartProjCode1);
			  STRNG_replace_str(PartProjCode1,"'\t'"," ",&Temp1);
			  //STRNG_replace_str(PartProjCode1,"'"," ",&Temp1);
			  //STRNG_replace_str(PartProjCode1,"*"," ",&Temp1);
			  //STRNG_replace_str(PartProjCode1,"&"," and ",&Temp1);

			  PartProjCode1=(char *)MEM_alloc(200);
              tc_strcpy(PartProjCode1,"");
			  tc_strcpy(PartProjCode1,Temp1);
	}
	tc_strcat(TempReslt,PartProjCode1);
	tc_strcat(TempReslt,",");

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_EnvelopeDimensions",&EnvelopeDimensions);
	fprintf(PrtBomExecutionLog,"EnvelopeDimensions : [%s]\n", EnvelopeDimensions); fflush(PrtBomExecutionLog);
	if(tc_strcmp(EnvelopeDimensions,"")==0)
	{
		EnvelopeDimensions=(char *)MEM_alloc(200);
		tc_strcpy(EnvelopeDimensions,"NA");
	}
	//if(tc_strstr(EnvelopeDimensions,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(EnvelopeDimensions,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&EnvelopeDimensions);
			  STRNG_replace_str(EnvelopeDimensions,"^"," ",&Temp1);

			  EnvelopeDimensions=(char *)MEM_alloc(200);
              tc_strcpy(EnvelopeDimensions,"");
			  tc_strcpy(EnvelopeDimensions,Temp1);
	}
	tc_strcat(TempReslt,EnvelopeDimensions);
	tc_strcat(TempReslt,",");

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_Design Revision_t5_MThickness",&Thicknes);
	fprintf(PrtBomExecutionLog,"Thicknes : [%s]\n", Thicknes); fflush(PrtBomExecutionLog);
	if(tc_strcmp(Thicknes,"")==0)
	{
		Thicknes=(char *)MEM_alloc(200);
		tc_strcpy(Thicknes,"NA");
	}

	//if(tc_strstr(Thicknes,","))
	else{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(Thicknes,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&Thicknes);
			  STRNG_replace_str(Thicknes,"^"," ",&Temp1);

			  Thicknes=(char *)MEM_alloc(200);
              tc_strcpy(Thicknes,"");
			  tc_strcpy(Thicknes,Temp1);
	}
	tc_strcat(TempReslt,Thicknes);
	tc_strcat(TempReslt,",");

	ifail=AOM_ask_value_string(tagBOMline,"bl_Design Revision_t5_PartType",&PartType);
	fprintf(PrtBomExecutionLog,"PartType: [%s]\n", PartType); fflush(PrtBomExecutionLog);
	if(tc_strcmp(PartType,"")==0)
	{
		PartType=(char *)MEM_alloc(200);
		tc_strcpy(PartType,"NA");
	}

	//if(tc_strstr(PartType,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(PartType,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&PartType);
			  STRNG_replace_str(PartType,"^"," ",&Temp1);

			  PartType=(char *)MEM_alloc(200);
              tc_strcpy(PartType,"");
			  tc_strcpy(PartType,Temp1);
	}
	tc_strcat(TempReslt,PartType);
	tc_strcat(TempReslt,",");

	ifail=AOM_UIF_ask_value(tagBOMline,"bl_quantity",&quantity);
	fprintf(PrtBomExecutionLog,"Part Quantity number==>%s\n\n",quantity);fflush(PrtBomExecutionLog);
	if(tc_strcmp(quantity,"")==0)
	{
		quantity=(char *)MEM_alloc(200);
		tc_strcpy(quantity,"NA");
	}
	//if(tc_strstr(quantity,","))
	else
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(quantity,",","_",&Temp1);
			  STRNG_replace_str(Temp1,"\n"," ",&quantity);
			  STRNG_replace_str(quantity,"^"," ",&Temp1);

			  quantity=(char *)MEM_alloc(200);
              tc_strcpy(quantity,"");
			  tc_strcpy(quantity,Temp1);
	}
	tc_strcat(TempReslt,quantity);
	tc_strcat(TempReslt,",");
	//tc_strcpy(TempReslt,'\0');

	

	*StrctInt	=	*StrctInt+1;
	tc_strcpy(prtLst[*StrctInt].Level,item_level);
	tc_strcpy(prtLst[*StrctInt].PartNumber,partNumber);
	tc_strcpy(prtLst[*StrctInt].PartRev,partRevNumber);
	tc_strcpy(prtLst[*StrctInt].PartSeq,ModItem_Seq);
	tc_strcpy(prtLst[*StrctInt].PartWeight,Weight);
	tc_strcpy(prtLst[*StrctInt].PartSurfArea,SurfaceArea);
	tc_strcpy(prtLst[*StrctInt].PartVolume,Volume);
	tc_strcpy(prtLst[*StrctInt].PartCS,PuneCS);
	tc_strcpy(prtLst[*StrctInt].PartMaterial,Material);
	tc_strcpy(prtLst[*StrctInt].PartDesc,Description);
	tc_strcpy(prtLst[*StrctInt].PartProjCode,PartProjCode);
	tc_strcpy(prtLst[*StrctInt].PartProjDesc,PartProjCode1);
	tc_strcpy(prtLst[*StrctInt].PEnvDia,EnvelopeDimensions);
	tc_strcpy(prtLst[*StrctInt].PThickness,Thicknes);
	tc_strcpy(prtLst[*StrctInt].PParttype,PartType);
	tc_strcpy(prtLst[*StrctInt].Qty,quantity);
   if(tc_strstr(Description,","))
	{
              Temp1=(char *)MEM_alloc(100);
              tc_strcpy(Temp1,"");
			  STRNG_replace_str(Description,",","_",&Temp1);

			  Description=(char *)MEM_alloc(200);
              tc_strcpy(Description,"");
			  tc_strcpy(Description,Temp1);
	}
	
	
      fprintf(PartBomQryResult,"%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#%s#*#\n",item_level,partNumber,ModItem_Rev,ModItem_Seq,Weight,SurfaceArea,Volume,PuneCS,Material,Description,PartProjCode,PartProjCode1,EnvelopeDimensions,Thicknes,PartType,quantity); fflush(PartBomQryResult);
      //fprintf(PartBomQryResult,"%s\n",TempReslt); fflush(PartBomQryResult);
	

	ifail=BOM_line_ask_child_lines(tagBOMline, &childCountCfgTopBomLine1, &childTagCfgTopBomLine1);CHECK_FAIL;

	fprintf(PrtBomExecutionLog,"*********Number of Child Lines & its ChildTag*********** %d \n",childCountCfgTopBomLine1);fflush(PrtBomExecutionLog);

	for (count2 = 0;count2 < childCountCfgTopBomLine1;count2++)
	{
		ifail = findChildTag(childTagCfgTopBomLine1[count2],prtLst,StrctInt);		CHECK_FAIL;
		setAddTAG(&count,&childLines,childTagCfgTopBomLine1[count2]);
	}
	fprintf(PrtBomExecutionLog,"\n findChildTag: Total Number of Child Parts Found--->[%d] \n",count);fflush(PrtBomExecutionLog);
	return 0;
}

int Traverse_bom(char *strItemTpnode, char *partRevNo2, char *ER_EW,char *infoVal5,char *infoVal6)
{
	fprintf(PrtBomExecutionLog,"\n------------------------Inside Traverse_bom-----------------------------------------\n");fflush(PrtBomExecutionLog);
	int 			childCountTopBomLine 				= 0;
	int 			bomlineItemId1 						= 0;
	int 			bomlineRevId1      					= 0;
	int 			bomlineItemRevAttr1 				= 0;
	int 			iCount								= 0;

	char	*ModItem_Rev			=	NULL;
	char	*ModItem_Seq			=	NULL;
    char*Group= NULL;
    char*User= NULL;


	tag_t 			tagItemTpnode       				= NULLTAG;
	tag_t 			tagBOMwindow  					= NULLTAG;
	tag_t 			tagItemRevTpnode 			= NULLTAG;
	tag_t 			tagBOMline 							= NULLTAG;
	tag_t 			tagRule 									= NULLTAG;
	tag_t 			*tagTopBLchildLine 			= NULLTAG;
	closureRuleName=(char *) MEM_alloc(200 * sizeof(char *));

	ifail=BOM_create_window(&tagBOMwindow);CHECK_FAIL;
	ifail = BOM_set_window_pack_all(tagBOMwindow, true);CHECK_FAIL;

	ifail=ITEM_find_item(strItemTpnode, &tagItemTpnode);CHECK_FAIL;
	fprintf(PrtBomExecutionLog,"\nTop BomLine ItemID %s \n",strItemTpnode); fflush(PrtBomExecutionLog);

	ITEM_find_rev (strItemTpnode,partRevNo2,&tagItemRevTpnode);

	if(tagItemRevTpnode !=NULLTAG)
	{	 fprintf(PrtBomExecutionLog,"item_revision_id:%s\n",partRevNo2);fflush(PrtBomExecutionLog);	}
	else
	{	fprintf(PrtBomExecutionLog,"No item_revision_id found \n");fflush(PrtBomExecutionLog);	}

	ModItem_Rev =  tc_strtok(partRevNo2,";");
	fprintf(PrtBomExecutionLog,"Item_Rev --> : %s\n",ModItem_Rev); fflush(PrtBomExecutionLog);
	ModItem_Seq = tc_strtok(NULL,";");
	fprintf(PrtBomExecutionLog,"Item_Seq --> : %s\n",ModItem_Seq); fflush(PrtBomExecutionLog);

	fprintf(PrtBomExecutionLog,"ER_EW Lifecycle statte:%s\n",ER_EW);fflush(PrtBomExecutionLog);

if (tc_strcmp(ER_EW,"EW")==0)
{
	fprintf(PrtBomExecutionLog,"\n Latest Working Applied TransferBOM");fflush(PrtBomExecutionLog);
	ifail = CFM_find("Latest Working", &tagRule);CHECK_FAIL;
}
else
	{
	fprintf(PrtBomExecutionLog,"\n ERC release Applied TransferBOM");fflush(PrtBomExecutionLog);
	ifail = CFM_find(infoVal6, &tagRule);CHECK_FAIL;
	}

	ifail = BOM_set_window_config_rule( tagBOMwindow, tagRule );CHECK_FAIL;

    AOM_UIF_ask_value(tagItemRevTpnode,"owning_group",&Group);fflush(PrtBomExecutionLog);
	fprintf(PrtBomExecutionLog,"\n owning_group of part_REV isTraverse  ---->%s\n", Group);fflush(PrtBomExecutionLog);

	 	 AOM_UIF_ask_value(tagItemRevTpnode,"owning_user",&User);fflush(PrtBomExecutionLog);
		 fprintf(PrtBomExecutionLog,"\n owning_user of part_REV is  ---->%s\n", User);fflush(PrtBomExecutionLog);
		 fprintf(PrtBomExecutionLog,"\n infoVal5 is  ---->%s\n", infoVal5);fflush(PrtBomExecutionLog);
		 fprintf(PrtBomExecutionLog,"\n infoVal6 is  ---->%s\n", infoVal6);fflush(PrtBomExecutionLog);

	     if(tc_strstr(Group,"dba")!=NULL)
		 {
             if  (tc_strstr(User,"APL")!=NULL)
			 {
			fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPL******/applied\n");fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,infoVal5);
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
		    }
			else if  (tc_strstr(User,"MBOM")!=NULL)
			 {
			fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleMBOM******/applied\n");fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,"BOMViewClosureRuleMBOM");
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
		    }
			else
		   {
			fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to ERC Group So /****** BOMViewClosureRuleERC ******/applied\n" );fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,"BOMViewClosureRuleERC");
	        scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
			}
		 }
	    else if (tc_strstr(Group,"APL")!=NULL)
		{
		    fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPL******/applied\n");fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,infoVal5);
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
	     }
		 else if (tc_strstr(Group,"MBOM")!=NULL)
		{
		    fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleMBOM******/applied\n");fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,"BOMViewClosureRuleMBOM");
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
	     }
		else
        {
			 fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to ERC Group So /****** BOMViewClosureRuleERC ******/applied\n" );fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,"BOMViewClosureRuleERC");
	        scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
		 }


	if(n_closure_tags==1)
	{
		closure_tag=closure_tags[0];
	}

	ITKCALL(BOM_window_set_closure_rule(tagBOMwindow,closure_tag,0,NULL,NULL));
	ITKCALL(BOM_save_window (tagBOMwindow));

  	ifail=BOM_set_window_top_line(tagBOMwindow, tagItemTpnode, tagItemRevTpnode, NULLTAG, &tagBOMline);CHECK_FAIL;

	ifail=BOM_line_ask_child_lines(tagBOMline, &childCountTopBomLine, &tagTopBLchildLine); CHECK_FAIL;
	fprintf(PrtBomExecutionLog,"BOM Window, Parent Part Child Line Count:-%d \n",childCountTopBomLine);fflush(PrtBomExecutionLog);

	ifail=getBomLineAttributes(tagBOMline);CHECK_FAIL;

	fprintf(PrtBomExecutionLog,"On Parent, Number of Child Lines %d \n\n",childCountTopBomLine);fflush(PrtBomExecutionLog);
   int x=0;
	for(iCount =0 ; iCount < childCountTopBomLine; iCount++)
	{

		 x++;
        fprintf(PrtBomExecutionLog,"%d \n",x);fflush(PrtBomExecutionLog);
		fprintf(PrtBomExecutionLog,"Getting Child Parts and its Attribute Starts \n\n");fflush(PrtBomExecutionLog);
		ifail=getBomLineAttributes(tagTopBLchildLine[iCount]);CHECK_FAIL;

		ifail = findChild(tagTopBLchildLine[iCount],bomlineItemId1 ,bomlineRevId1,bomlineItemRevAttr1);CHECK_FAIL;
	}
	return 0;
}

int ns__getPartDetailCasCave(char *partnumber,char*revision,char*ISequence, char*ER_EW,char	*Plant)
{
	printf("\n inside ns__getPartDetailCasCave :: \n");fflush(stdout);
	char *ExeLogFile = NULL;
	char *ResltLogFile = NULL;
	int ifail =0;
	int i= 0;

	int cnt				= 0;
	int StrctInt   =0;
	int	length			=	0;
	int	PlntFlag			=	0;
    printf("\n before  struct:: \n");fflush(stdout);
	struct Prt_Bom getList[3000];
	printf("\n f1!! struct:: \n");fflush(stdout);
	int	iPrt=0;
	//struct ns__CharArray4Test *aString_test;

	char 	*Num_Rev_ID			=NULL;
	char*	logFile							= NULL;
	char *releaseStatCheck=NULL;
	char *Rev_NumCat=NULL;
		char		*TrevisionS	= NULL;
		char *infoVal0 = NULL;
		char *infoVal1 = NULL;
		char *infoVal2 = NULL;
		char *infoVal3 = NULL;
		char *infoVal4 = NULL;
		char *infoVal5 = NULL;
		char *infoVal6 = NULL;
		char *infoVal7 = NULL;
		char *infoVal8 = NULL;
		
		
	closureRuleName=(char *) MEM_alloc(200 * sizeof(char *));


	tag_t	tagBOMwindow  = NULLTAG;
	tag_t 	tagRule 					= NULLTAG;
	tag_t 	tagBOMline 			= NULLTAG;
	tag_t	VCRevision_tag	= NULLTAG;



    ExeLogFile = (char	*)MEM_alloc(100);
	ResltLogFile = (char	*)MEM_alloc(100);

   printf("\n before  ExeLogFile:: \n");fflush(stdout);
	tc_strcpy(ExeLogFile,"");		
	tc_strcat(ExeLogFile,partnumber);
	tc_strcat(ExeLogFile,"_PartBomCV.log");
	PrtBomExecutionLog = fopen(ExeLogFile,"a+");
	fprintf(PrtBomExecutionLog,"\n Part Execution Log file is :: %s\n",ExeLogFile);
	//PrtBomExecutionLog = fopen(ExeLogFile,"a+");
	printf("\n f2  ExeLogFile:: \n");fflush(stdout);

	tc_strcpy(ResltLogFile,"");
	tc_strcat(ResltLogFile,partnumber);
	tc_strcat(ResltLogFile,"_TCUACV_PARTBOMDETAIL.txt");
	PartBomQryResult = fopen(ResltLogFile,"w");
    printf("\n f3 ExeLogFile:: \n");fflush(stdout);
    fprintf(PrtBomExecutionLog,"\n#####---------------------------------------------------Starting Program For PROD-----------------------------------------------#####"); fflush(PrtBomExecutionLog);
	fprintf(PrtBomExecutionLog,"\nPart No : [%s]\n", partnumber); fflush(PrtBomExecutionLog);
	fprintf(PrtBomExecutionLog,"Part revision : [%s]\n", revision); fflush(PrtBomExecutionLog);
	fprintf(PrtBomExecutionLog,"Part ISequence : [%s]\n", ISequence); fflush(PrtBomExecutionLog);
	fprintf(PrtBomExecutionLog,"Part ER_EW : [%s]\n", ER_EW); fflush(PrtBomExecutionLog);
	fprintf(PrtBomExecutionLog,"Part Plant : [%s]\n", Plant); fflush(PrtBomExecutionLog); 
    fprintf(PrtBomExecutionLog,"\n Length of Plant   is :(%d )",tc_strlen(Plant));fflush(PrtBomExecutionLog);

	if(tc_strlen(Plant)>0)
	{
		PlntFlag=0;
		fprintf(PrtBomExecutionLog,"\nPart BOM Plant input not null : %s ",Plant);fflush(PrtBomExecutionLog);
		infoVal0=(char *)MEM_alloc(100);
		infoVal1=(char *)MEM_alloc(100);
		infoVal2=(char *)MEM_alloc(100);
		infoVal3=(char *)MEM_alloc(100);
		infoVal4=(char *)MEM_alloc(100);
		infoVal5=(char *)MEM_alloc(200);
		infoVal6=(char *)MEM_alloc(200);
		infoVal7=(char *)MEM_alloc(100);
		infoVal8=(char *)MEM_alloc(100);
		if(tc_strcmp(Plant,"PNR")==0)
		{
			PlntFlag=1;
			infoVal0 ="APLU Working";
			infoVal1 ="APLU Review";
			infoVal2 ="APLU Released";
			infoVal3 ="STDSIU Working";
			infoVal4 ="STDSIU Released";
			infoVal5 ="BOMViewClosureRuleAPLU";
			infoVal6 ="ERC release and above";
		}
		else if(tc_strcmp(Plant,"JSR")==0)
		{
			PlntFlag=1;
			infoVal0 ="APLJ Working";
			infoVal1 ="APLJ Review";
			infoVal2 ="APLJ Released";
			infoVal3 ="STDSIJ Working";
			infoVal4 ="STDSIJ Released";
			infoVal5 ="BOMViewClosureRuleAPLJ";
			infoVal6 ="ERC release and above";
		}
		else if (tc_strcmp(Plant,"DWD")==0)
		{
			PlntFlag=1;
			infoVal0 ="APLD Working";
			infoVal1 ="APLD Review";
			infoVal2 ="APLD Released";
			infoVal3 ="STDSID Working";
			infoVal4 ="STDSID Released";
			infoVal5 ="BOMViewClosureRuleAPLD";
			infoVal6 ="ERC release and above";
			
		}
		else if(tc_strcmp(Plant,"LKO")==0)
		{
			PlntFlag=1;
			infoVal0 ="APLL Working";
			infoVal1 ="APLL Review";
			infoVal2 ="APLL Released";
			infoVal3 ="STDSIL Working";
			infoVal4 ="STDSIL Released";
			infoVal5 ="BOMViewClosureRuleAPLL";
			infoVal6 ="ERC release and above";
			
		}
		else if(tc_strcmp(Plant,"AHD")==0)
		{
			PlntFlag=1;
			infoVal0 ="APLS Working";
			infoVal1 ="APLS Review";
			infoVal2 ="APLS Released";
			infoVal3 ="STDSIS Working";
			infoVal4 ="STDSIS Released";
			infoVal5 ="BOMViewClosureRuleAPLS";
			infoVal6 ="ERC release and above";
			
		}
		else if(tc_strcmp(Plant,"PUN")==0)
		{
			PlntFlag=1;
			infoVal0 ="APLP Working";
			infoVal1 ="APLP Review";
			infoVal2 ="APLP Released";
			infoVal3 ="STDSIP Working";
			infoVal4 ="STDSIP Released";
			infoVal5 ="BOMViewClosureRuleAPLP";
			infoVal6 ="ERC release and above";
			
		}
		else
		{
			PlntFlag=0;
			infoVal0 ="APLP Working";
			infoVal1 ="APLP Review";
			infoVal2 ="APLP Released";
			infoVal3 ="STDSIP Working";
			infoVal4 ="STDSIP Released";
			infoVal5 ="BOMViewClosureRuleAPLP";
			infoVal6 ="ERC release and above";
			
		}
		infoVal7 ="MBOM Working";
		infoVal8 ="MBOM Released";
	}
	fprintf(PrtBomExecutionLog,"Part PlntFlag : [%d]\n", PlntFlag); fflush(PrtBomExecutionLog);

	TrevisionS=(char *)MEM_alloc(200);
	if((tc_strcmp(revision,"TBD")!=0)&&(tc_strcmp(ISequence,"TBD")==0))
	{
	     tc_strcpy(TrevisionS,revision);
	     tc_strcat(TrevisionS,"*");
	     
	}
	else if((tc_strcmp(revision,"TBD")==0)||(tc_strcmp(ISequence,"TBD")==0))
	{
		tag_t	queryPart	=	NULLTAG;
		tag_t   *allResult	=	NULL;
		char *partLC= NULL;
		char *partrev= NULL;
        int		n_entries	=	2;
        int		l	=	2;
		int    	num_to_sort =	1;
		int  	orders[]  	=	{2};
		int		n_revfound=	0;
		char 	*keys[] 	= 	{"creation_date"};
		char 	*qry_part_entries[2] = {"Item ID","Revision"};
		char 	*qry_part_values[2] = {partnumber,"*"};

		QRY_find2("Item Revision...", &queryPart);
		QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_revfound, &allResult);
		fprintf(PrtBomExecutionLog,"\nNumber of for Revsion null passed ERC Release and Above rev of part  [%s]found : [%d]\n",partnumber,n_revfound);fflush(PrtBomExecutionLog);

			for (l = 0; l < n_revfound; l++)
			{
		    	AOM_UIF_ask_value(allResult[l],"release_status_list",&partLC);fflush(PrtBomExecutionLog);
		    	fprintf(PrtBomExecutionLog,"\n Its ReleaseStatus_Name==%s\n",partLC);fflush(PrtBomExecutionLog);
		    if(tc_strcmp(ER_EW,"ER")==0)
				{
		         if((tc_strstr(partLC,"ERC Released")!=NULL)||(tc_strstr(partLC,"MBOM")!=NULL)||(tc_strstr(partLC,"APL")!=NULL)||(tc_strstr(partLC,"STDSI")!=NULL))
		    	  { 
				    AOM_UIF_ask_value(allResult[l],"item_revision_id",&partrev);fflush(PrtBomExecutionLog);
		    	    fprintf(PrtBomExecutionLog,"\n Its item_revision_id ==%s\n",partrev);fflush(PrtBomExecutionLog);
				    TrevisionS =  tc_strtok(partrev,";");
				    tc_strcat(TrevisionS,"*");
				    break;
		    	  }
				}
				else
				{
				  if(tc_strstr(partLC,"ERC Working")!=NULL)
		    	  { 
				    AOM_UIF_ask_value(allResult[l],"item_revision_id",&partrev);fflush(PrtBomExecutionLog);
		    	    fprintf(PrtBomExecutionLog,"\n Its item_revision_id ==%s\n",partrev);fflush(PrtBomExecutionLog);
				    TrevisionS =  tc_strtok(partrev,";");
				    tc_strcat(TrevisionS,"*");
				    break;
		    	  }
				}
		    
			 fprintf(PrtBomExecutionLog,"\n\n");fflush(PrtBomExecutionLog);

			}
	}
	else
	{
	   tc_strcpy(TrevisionS,revision);
	   tc_strcat(TrevisionS,"*");
	   tc_strcat(TrevisionS,ISequence);
	}
	fprintf(PrtBomExecutionLog,"\nItem_Rev Seq For Query Run****** ----> : %s\n",TrevisionS); fflush(PrtBomExecutionLog);

		const char *attrs[1];
		const char *values[1];
		attrs[0] ="item_id";
		values[0] = (char *)partnumber;
		fprintf(PrtBomExecutionLog,"values for Part <%s> \n",values[0] );fflush(PrtBomExecutionLog);

        int	n_tags_found= 0;
		int iii=0;
		int st_count		=	0;
		int iStCnt=0;
		int	nCRItem			=	0;
		
		char* 	rev_id1 =NULL;
		char* 	rev_id2=NULL;
		int *j=0;

		char*lifecycle_state= NULL;
		char*Group= NULL;
		char*User= NULL;

		tag_t	queryPart	=	NULLTAG;
		tag_t   *results	=	NULL;
		tag_t *tags_found= NULLTAG;
		tag_t item_t	= NULLTAG;
		tag_t*	status_list			=	NULLTAG;
		tag_t	ChRDsgnTag			=	NULLTAG;
		tag_t		*CRitem_revs_tag		=	NULLTAG;

		if(tc_strcmp(ER_EW,"EW")==0)
		{
		if (  (tc_strlen(partnumber)>0) && (tc_strlen (revision)>0) && ( tc_strlen(ISequence)>0)  )
		{
		fprintf(PrtBomExecutionLog,"\n tc_strlen(of partnumber revision & ISequence )  is :(%d )""(%d)""(%d)",tc_strlen(partnumber),tc_strlen(revision),tc_strlen(ISequence));fflush(PrtBomExecutionLog);
		fprintf(PrtBomExecutionLog,"\n ***INSIDE  _EW  check Query*** --------------------LifeCycValSetEW-----");fflush(PrtBomExecutionLog);

        int		n_entries	=	2;
		int		n_found=	0;
		int    	num_to_sort =	1;
		int  	orders[]  	=	{1};
		char 	*keys[] 	= 	{"creation_date"};
		char 	*qry_part_entries[2] = {"Item ID","Revision"};
		char 	*qry_part_values[2] = {partnumber,TrevisionS};
	

		QRY_find2("Item Revision...", &queryPart);
		QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results);
		fprintf(PrtBomExecutionLog,"\nNumber of ERC Release and Above rev of part  [%s]found : [%d]\n",partnumber,n_found);fflush(PrtBomExecutionLog);

			for (iii = 0; iii < n_found; iii++)
			{
			ITEM_ask_rev_id2 ( results[iii], &rev_id1);
			fprintf(PrtBomExecutionLog,"\n rev_id are  ---->%s", rev_id1);fflush(PrtBomExecutionLog);														//diplay the previous revision

			AOM_UIF_ask_value(results[iii],"release_status_list",&lifecycle_state);fflush(PrtBomExecutionLog);
			fprintf(PrtBomExecutionLog,"\n Its ReleaseStatus_Name********==%s\n",lifecycle_state);fflush(PrtBomExecutionLog);

			if(tc_strstr(lifecycle_state,"ERC Working")!=NULL)
				{

			     ITEM_ask_rev_id2 ( results[iii], &rev_id2);
			     fprintf(PrtBomExecutionLog,"ERC Above Release_Status_Name of required part==%s",rev_id2);fflush(PrtBomExecutionLog);
			     VCRevision_tag = results[iii];
			     break;
				}

			 fprintf(PrtBomExecutionLog,"\n\n");fflush(PrtBomExecutionLog);

			}
		}
	}
	else
	{
		if (  (tc_strlen(partnumber)>0) && (tc_strlen (revision)>0) && ( tc_strlen(ISequence)>0)  )
		{
		fprintf(PrtBomExecutionLog,"\n Lemmgth of partnumber revision & ISequence )  is :(%d )""(%d)""(%d)",tc_strlen(partnumber),tc_strlen(revision),tc_strlen(ISequence));fflush(PrtBomExecutionLog);
		fprintf(PrtBomExecutionLog,"\n ***INSIDE  ER_*******  check Query*** --------------------LifeCycValSetEW-----");fflush(PrtBomExecutionLog);

        int		n_entries	=	2;
		int		n_found=	0;
		int    	num_to_sort =	1;
		int  	orders[]  	=	{1};
		char 	*keys[] 	= 	{"creation_date"};
		char 	*qry_part_entries[2] = {"Item ID","Revision"};
		char 	*qry_part_values[2] = {partnumber,TrevisionS};
	

		QRY_find2("Item Revision...", &queryPart);
		QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results);
		fprintf(PrtBomExecutionLog,"\nNumber of ERC Release and Above rev of part  [%s]found : [%d]\n",partnumber,n_found);fflush(PrtBomExecutionLog);
	     fprintf(PrtBomExecutionLog,"\nNumber of ERC Release and Above rev of part  [%s]found : [%d]\n",partnumber,n_found);fflush(PrtBomExecutionLog);

			for (iii = 0; iii < n_found; iii++)
			{
			ITEM_ask_rev_id2 ( results[iii], &rev_id1);
			fprintf(PrtBomExecutionLog,"\n rev_id are  ---->%s", rev_id1);fflush(PrtBomExecutionLog);														//diplay the previous revision

			AOM_UIF_ask_value(results[iii],"release_status_list",&lifecycle_state);fflush(PrtBomExecutionLog);
			fprintf(PrtBomExecutionLog,"\n Its ReleaseStatus_Name==%s\n",lifecycle_state);fflush(PrtBomExecutionLog);

		if((tc_strstr(lifecycle_state,"ERC Released")!=NULL) ||(tc_strstr(lifecycle_state,infoVal0)!=NULL)|| (tc_strstr(lifecycle_state,infoVal1)!=NULL) ||
			(tc_strstr(lifecycle_state,infoVal2)!=NULL)||(tc_strstr(lifecycle_state,infoVal3)!=NULL)||(tc_strstr(lifecycle_state,infoVal4)!=NULL)||(tc_strstr(lifecycle_state,infoVal7)!=NULL)||(tc_strstr(lifecycle_state,infoVal8)!=NULL))
			{
			ITEM_ask_rev_id2 ( results[iii], &rev_id2);
			fprintf(PrtBomExecutionLog,"ERC Above Release_Status_Name of required part*********==%s",rev_id2);fflush(PrtBomExecutionLog);
			VCRevision_tag = results[iii];
			}
			 fprintf(PrtBomExecutionLog,"\n\n");fflush(PrtBomExecutionLog);
			}

		}
		 else if(tc_strcmp(revision,"-")==0)
		{
		int		n_entries	=	1;
		int    	num_to_sort =	1;
		int  	orders[]  	=	{1};
		int		n_found=	0;
		char 	*keys[] 	= 	{"creation_date"};
		char 	*qry_part_entries[1] = {"Item ID",};
		char 	*qry_part_values[1] = {partnumber};

		QRY_find2("Item Revision...", &queryPart);
		QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results);
		fprintf(PrtBomExecutionLog,"\nNumber of ERC Release and Above rev of part  [%s]found****** : [%d]\n",partnumber,n_found);fflush(PrtBomExecutionLog);


			for (iii = 0; iii < n_found; iii++)
			{
			  ITEM_ask_rev_id2( results[iii], &rev_id1);
			  fprintf(PrtBomExecutionLog,"\n rev_id are  ---->%s", rev_id1);fflush(PrtBomExecutionLog);														//diplay the previous revision

			   AOM_UIF_ask_value(results[iii],"release_status_list",&lifecycle_state);fflush(PrtBomExecutionLog);
			   fprintf(PrtBomExecutionLog,"\n Its ReleaseStatus_Name==%s\n",lifecycle_state);fflush(PrtBomExecutionLog);


			if((tc_strstr(lifecycle_state,"ERC Released")!=NULL) ||(tc_strstr(lifecycle_state,infoVal0)!=NULL)||(tc_strstr(lifecycle_state,infoVal1)!=NULL)||
			(tc_strstr(lifecycle_state,infoVal2)!=NULL)||(tc_strstr(lifecycle_state,infoVal3)!=NULL)||(tc_strstr(lifecycle_state,infoVal4)!=NULL)||(tc_strstr(lifecycle_state,infoVal7)!=NULL)||(tc_strstr(lifecycle_state,infoVal8)!=NULL))

			{
			  ITEM_ask_rev_id2 ( results[iii], &rev_id2);
			  fprintf(PrtBomExecutionLog,"ERC Above Release_Status_Name of required ********part==%s",rev_id2);fflush(PrtBomExecutionLog);
			  VCRevision_tag = results[iii];

			}
			 fprintf(PrtBomExecutionLog,"\n\n");fflush(PrtBomExecutionLog);

			}
		}
      	else  
		{
		if ((tc_strcmp(revision,"")==0)||(tc_strcmp(revision,"*")==0))
		{
         fprintf(PrtBomExecutionLog," Item revision Input is empty or Not Proper:--Please Enter by Initial of Revision or by (-) :\n");fflush(PrtBomExecutionLog);
		}
		else
		{
		fprintf(PrtBomExecutionLog,"\n***** Else Initial *******\n");fflush(PrtBomExecutionLog);
		Rev_NumCat	=	(char *)MEM_alloc(10);
		tc_strcpy(Rev_NumCat,revision);
		tc_strcat(Rev_NumCat,"*");
		printf( "Rev_NumCat:%s\n", Rev_NumCat);fflush(PrtBomExecutionLog);

		int		n_entries	=	2;
		int    	num_to_sort =	1;
		int		orders[]  	=	{1};
		int		n_found		=	0;
		char 	*keys[] 	= 	{"creation_date"};
		char 	*qry_part_entries[2] = {"Item ID","Revision"};
		char 	*qry_part_values[2] = {partnumber,Rev_NumCat,};

		QRY_find2("Item Revision...", &queryPart);
		QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results);
		fprintf(PrtBomExecutionLog,"\nNumber of ERC Release and Above rev of ******part  [%s]found : [%d]\n",partnumber,n_found);fflush(PrtBomExecutionLog);


			for (iii = 0; iii < n_found; iii++)
			{
			ITEM_ask_rev_id2 ( results[iii], &rev_id1);
			fprintf(PrtBomExecutionLog,"\n rev_id are  ---->%s", rev_id1);fflush(PrtBomExecutionLog);														//diplay the previous revision

			AOM_UIF_ask_value(results[iii],"release_status_list",&lifecycle_state);fflush(PrtBomExecutionLog);
			fprintf(PrtBomExecutionLog,"\n Its ReleaseStatus_Name==%s\n",lifecycle_state);fflush(PrtBomExecutionLog);


			if((tc_strstr(lifecycle_state,"ERC Released")!=NULL) ||(tc_strstr(lifecycle_state,infoVal0)!=NULL)|| (tc_strstr(lifecycle_state,infoVal1)!=NULL)||
			(tc_strstr(lifecycle_state,infoVal2)!=NULL)||(tc_strstr(lifecycle_state,infoVal3)!=NULL)||(tc_strstr(lifecycle_state,infoVal4)!=NULL)||(tc_strstr(lifecycle_state,infoVal7)!=NULL)||(tc_strstr(lifecycle_state,infoVal8)!=NULL))
				{
				ITEM_ask_rev_id2 ( results[iii], &rev_id2);
				fprintf(PrtBomExecutionLog,"******ERC Above Release_Status_Name of required part1==%s",rev_id2);fflush(PrtBomExecutionLog);
				VCRevision_tag = results[iii];
			   }
			}
		   }
		}
	}

	 fprintf(PrtBomExecutionLog,"\n\nItem ID **&  item_revision_id for BOM Expansion CAME FROM ELSE : %s\t%s\n",partnumber,rev_id2);fflush(PrtBomExecutionLog);

	 if(rev_id2 !=NULL)
	 {

	 Traverse_bom(partnumber,rev_id2,ER_EW,infoVal5,infoVal6);

     AOM_UIF_ask_value(VCRevision_tag,"owning_group",&Group);fflush(PrtBomExecutionLog);
	 fprintf(PrtBomExecutionLog,"\n owning_group of part_REV is  ---->%s\n", Group);fflush(PrtBomExecutionLog);

	 	 AOM_UIF_ask_value(VCRevision_tag,"owning_user",&User);fflush(PrtBomExecutionLog);
		 fprintf(PrtBomExecutionLog,"\n owning_user of part_REV is  ---->%s\n", User);fflush(PrtBomExecutionLog);

	     if(tc_strstr(Group,"dba")!=NULL)
		 {
             if  (tc_strstr(User,"APL")!=NULL)
			 {
			fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPL******/applied\n");fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,infoVal5);
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags1:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
		    }
			else if (tc_strstr(User,"MBOM")!=NULL)
			{
			fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleMBOM******/applied\n");fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,"BOMViewClosureRuleMBOM");
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags1:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
		    }
			else
		   {
			fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to ERC Group So /****** BOMViewClosureRuleERC ******/applied\n" );fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,"BOMViewClosureRuleERC");
	        scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags2:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
			}
		 }
		 else if(tc_strstr(Group,"APL")!=NULL)
		{
		    fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleAPL******/applied\n");fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,infoVal5);
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags3:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
		 }
		  else if(tc_strstr(Group,"MBOM")!=NULL)
		{
		    fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to APL Group So/ ****** BOMViewClosureRuleMBOM******/applied\n");fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,"BOMViewClosureRuleMBOM");
			scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags3:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
		 }
		 else
         {
			 fprintf(PrtBomExecutionLog,"\n Part Revision Belongs to ERC Group So /****** BOMViewClosureRuleERC ******/applied\n" );fflush(PrtBomExecutionLog);
		    tc_strcpy(closureRuleName,"BOMViewClosureRuleERC");
	        scope=PIE_TEAMCENTER;
			ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
			fprintf(PrtBomExecutionLog,"\n closure_tags4:[%d]\n",n_closure_tags);fflush(PrtBomExecutionLog);
		 }

 																	//function call to get BOM line and its child lines upto end lines

	fprintf(PrtBomExecutionLog,"\n----------------------------------------------For getting Tags for all child parts-----------------------------------------\n");fflush(PrtBomExecutionLog);
	ifail=  BOM_create_window(&tagBOMwindow);CHECK_FAIL;
	ifail = BOM_set_window_pack_all(tagBOMwindow, true);CHECK_FAIL;


 if (tc_strcmp(ER_EW,"EW")==0)
   {
		fprintf(PrtBomExecutionLog,"\n Latest Working Applied");fflush(PrtBomExecutionLog);
	ifail = CFM_find("Latest Working", &tagRule);CHECK_FAIL;
    }
else
	{
	fprintf(PrtBomExecutionLog,"\n ERC release Applied");fflush(PrtBomExecutionLog);
	ifail = CFM_find(infoVal6, &tagRule);CHECK_FAIL;
	}


	ifail = BOM_set_window_config_rule( tagBOMwindow, tagRule );CHECK_FAIL;

	if(n_closure_tags==1)
	{
		closure_tag=closure_tags[0];
	}
	ITKCALL(BOM_window_set_closure_rule(tagBOMwindow,closure_tag,0,NULL,NULL));
	ITKCALL(BOM_save_window (tagBOMwindow));
	ifail=BOM_set_window_top_line(tagBOMwindow, NULLTAG, VCRevision_tag, NULLTAG, &tagBOMline);	CHECK_FAIL;

    fprintf(PrtBomExecutionLog,"\n\n\n**********************************NOW FOR CHILD TAGS TO PRINT******************************\n\n\n");fflush(PrtBomExecutionLog);
	ifail = findChildTag(tagBOMline,getList,&StrctInt);														//function call to get BOM line tag and its child lines tags upto end lines

	fprintf(PrtBomExecutionLog,"\n Total Parts Found from BOM Line count --->[%d]\n", count); fflush(PrtBomExecutionLog);
	fprintf(PrtBomExecutionLog,"\n Total Parts tags Found from Top to Bottom--->[%d]\n\n", StrctInt); fflush(PrtBomExecutionLog);


	 fprintf(PrtBomExecutionLog,"\n\n\n**********************************NOW TO PRINT IN TXT******************************\n\n\n");fflush(PrtBomExecutionLog);

                    


					
	      }
	       else
			{
			fprintf(PrtBomExecutionLog,"\n\n  Exits  item_revision_id for BOM Expansion ");fflush(PrtBomExecutionLog);
			}


fprintf(PrtBomExecutionLog,"\n===========================================================================================\n"); fflush(PrtBomExecutionLog);

	fclose(PartBomQryResult);





	fclose(PrtBomExecutionLog);
	return 0;
	//fflush(PrtBomExecutionLog);
	//dup2(fd, fileno(PrtBomExecutionLog));
	//close(fd);
	//clearerr(PrtBomExecutionLog);
	//fsetpos(PrtBomExecutionLog, &pos);
	//return SOAP_OK;
}
