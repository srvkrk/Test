. /user/aplstdgrp/.bash_profile
echo "Connecting uaprod...."
now="$(date +'%d_%m_%Y')"
echo $1
pwd
cd /user/aplstdgrp/Deepti/TCE_TCUA_CarryOver_Stamp/IncrementalDataStamp/$now
pwd
../tm_TCE_TCUA_PARTStampOneTime -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=/proj/PLMLoading/UAFiles/APL_STDSI_TCE_TCUA_Data_Mig/IncrementalDataUpload_APL_CarryOverPart/$now/Part_List_Info_$now.txt -plname=PlantName1 > PartListInfo.log &

wait
if [ $? != 0 ]
        then
                echo "Problem in Part stamping.."
                exit 1
        else
                echo "Part Stamping Executed Successfully ...."
fi

if grep "Teamcenter ERROR" *.log
then
    echo "Error found"
(
echo "To: awadhutn.ttl@tatamotors.com azmathp.ttl@tatamotors.com ac.ttl@tatamotors.com"
echo "Cc: deeptim.ttl@tatamotors.com"
echo "Subject: STATUS OF CARRYOVER DATA SYNC WITH PLM TCE-TCUA ON $1"
echo "Content-Type: text/html"
echo
echo "<html>
<head>
<title>Status of the jobs during the day</title>
<style>
table, th, td {
    border: 1px solid blue;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
</style>
</head>
<body>
<p><font   color="#ff0000">Dear All,</font></p>
<p><font   color="#ff0000">CarryOver Data Stamping from TCE to TCUA execution successfully completed.Status of the Shells Execution during the day:</font></p>
<table style='width:100%'>
<tr bgcolor='#808080'>
    <th><center>Shell Name</center></th>
    <th><center>Server</center></th>
    <th><center>Status</center></th>
    <th><center>LOG PATH</center></th>
  </tr>
  <tr>
    <td><center>CronJobIncrementDataDownLdCarryOver.sh</center></td>
    <td><center>plmpapp2c3</center></td>
    <td><center>CROSS VERIFY LOG ON SERVER FOLDER AS PER DATE</center></td>
    <td><center>plmpapp2c4:/user/aplstdgrp/Deepti/TCE_TCUA_CarryOver_Stamp/IncrementalDataStamp/</center></td>
  </tr>  
 </table>
 <p><font  color="#ff0000">--</font></p>
 <p><font  color="#ff0000">Regards,</font></p>
 <p><font  color="#ff0000">PLM SYSTEM.....</font></p>
</body></html>"
echo
) | /usr/sbin/sendmail -t
echo "111 finished....."   


 else
	echo "Error not found"

(
echo "To: awadhutn.ttl@tatamotors.com azmathp.ttl@tatamotors.com ac.ttl@tatamotors.com"
echo "Cc: deeptim.ttl@tatamotors.com"
echo "Subject: STATUS OF CARRYOVER DATA SYNC WITH PLM TCE-TCUA ON $1"
echo "Content-Type: text/html"
echo
echo "<html>
<head>
<title>Status of the jobs during the day</title>
<style>
table, th, td {
    border: 1px solid blue;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
</style>
</head>
<body>
<p><font   color="#ff0000">Dear All,</font></p>
<p><font   color="#ff0000">CarryOver Data Stamping from TCE to TCUA execution successfully completed.Status of the Shells Execution during the day:</font></p>
<table style='width:100%'>
<tr bgcolor='#808080'>
    <th><center>Shell Name</center></th>
    <th><center>Server</center></th>
    <th><center>Status</center></th>
    <th><center>LOG PATH</center></th>
  </tr>
  <tr>
    <td><center>CronJobIncrementDataDownLdCarryOver.sh</center></td>
    <td><center>plmpapp2c3</center></td>
    <td><center>CROSS VERIFY LOG ON SERVER FOLDER AS PER DATE</center></td>
    <td><center>plmpapp2c4:/user/aplstdgrp/Deepti/TCE_TCUA_CarryOver_Stamp/IncrementalDataStamp/</center></td>
  </tr>  
 </table>
 <p><font  color="#ff0000">--</font></p>
 <p><font  color="#ff0000">Regards,</font></p>
 <p><font  color="#ff0000">PLM SYSTEM.....</font></p>
</body></html>"
echo
) | /usr/sbin/sendmail -t
echo "finished....." 
fi