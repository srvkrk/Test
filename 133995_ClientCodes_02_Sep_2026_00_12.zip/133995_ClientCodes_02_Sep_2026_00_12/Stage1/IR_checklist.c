/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: IR_checklist.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's all revision's release status and writes
**				it's appropriate information into the file.
** 
**
**	Date							Author								Modification
**	15-March-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** IR_checklist -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        //TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
      //  TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
		
    }
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int IR_checklist(char*,char*,char*,char*);
//int createCheckListRowData(tag_t,char*,char*,tag_t,char*,char*);
int createCheckListRowData(tag_t,char*,char*,char*,tag_t,char*,char*,char*);
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
/*	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);*/
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	{
		print_requirement();
		return -1;
	}
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
/*	output = fopen(outputFile, "a");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}*/
	
		ifail = read_value_from_file(file);
		CHECK_FAIL;
		

		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int		count	 				= 0;
	
	char	*item_id							= NULL;
	char	*module_no					= NULL;
	char	*DesignRuleID						= NULL;
	char	*ChecklistImplemented					= NULL;
	char	*Remark					= NULL;
	char* irchecklist                           =NULL;
	char* irchecklistobj                        =NULL;
//	char 	*rev_id					= NULL;
	char 	 temp[3000];
//    char	*SrNo					= NULL;
   

	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	int flag =0;
	
	if (fp != NULL)
	{
		while (fgets(temp, 3000, fp)!= NULL)
		{
			flag++;
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				//printf("\ntemp:%s",temp);
	//			SrNo = strtok(temp, ",");
	//			printf("\n Sr No:%s",SrNo);

				module_no = strtok(temp, "|");
				printf("\n module no:%s",module_no);

			//	rev_id = strtok(NULL, ",");
		//		printf("\n rev id:%s",rev_id);

				DesignRuleID = strtok(NULL, "|");
				printf("\nDesign RuleID:%s",DesignRuleID);

				ChecklistImplemented = strtok(NULL, "|");
				printf("\nChecklist Implemented:%s",ChecklistImplemented);

				Remark = strtok(NULL, "|");
				printf("\nRemark:%s",Remark);
			
				ifail = IR_checklist(module_no,DesignRuleID,ChecklistImplemented,Remark);

				if(flag == 1)
				{
					printf("\n inside flag");

					ifail = exportpdffile(module_no);

				  
				}
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
//	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       IR_checklist
    Description:    This function takes the item_id as input and get it's all revisions 
					and checks for release status and writes information into a file.
********************************************************************************************/
int IR_checklist(char* module_no,char* DesignRuleID,char* ChecklistImplemented,char* Remark)
{
	int				i 							= 0;
	int				j 							= 0;
	int				count 						= 0;
	int				count_status				= 0;

	//int PorjectCode = atoi(Project);
	
	tag_t			module_tag			= NULLTAG;	
	tag_t			moduleRev_tag			= NULL;
	tag_t           item_type_tag1           = NULLTAG;

	tag_t           item_create_input_tag1   = NULLTAG;
	
	tag_t            object1                = NULLTAG;
	
	tag_t            ChecklistRev            = NULLTAG;
	
    int                 n_items                = 0;
	int                n_items1                = 0;
	int                n_items2                = 0;
	tag_t               item_tag             = NULL;
	tag_t                module_rev         = NULLTAG;
	char               *tempRev_ID	          =NULL;
	tag_t                item_tag1           = NULL;
	
    tag_t relation_type;
	tag_t relation = NULLTAG;
	char* irchecklist=	NULL;
	
	 tag_t            tempChecklistRev            = NULLTAG;
    tag_t relation_type1;
	tag_t relation1 = NULLTAG;
	tag_t latest_rev_id         = NULLTAG;
	char 	*rev_id					= NULL;
   
	printf("\n ******checklist creation********\n");
	
	ITK_CALL(ITEM_find_item(module_no,&item_tag));
	printf("\n  module found ");

 //   ITK_CALL(ITEM_find_revision(item_tag,rev_id,&module_rev));
  //  printf("\n  module rev found");

	ITK_CALL(ITEM_ask_latest_rev(item_tag,&latest_rev_id));

	if (latest_rev_id)
	{
		printf("\n  module rev found");
	}
	else
	{
		printf("\n  module rev not found");
	}
   ITK_CALL(AOM_ask_value_string(latest_rev_id,"item_revision_id",&rev_id));
   printf("\n latest module rev:%s",rev_id);

   ITK_CALL(ITEM_find_revision(item_tag,rev_id,&module_rev));


	// checklist id =Checklist_module_no_tempRev_ID
    char name[]="Checklist_";

	irchecklist=(char *)MEM_alloc(100);
    tc_strcpy(irchecklist,"");
    tc_strcpy(irchecklist,name);
	tc_strcat(irchecklist,stripBlanks(module_no));	    
    tc_strcat(irchecklist,"_");	
    ITK_CALL(STRNG_replace_str(rev_id,";","_",&tempRev_ID));
	printf("\n After STRNG_replace_str tempRev ID %s \n",tempRev_ID);
	tc_strcat(irchecklist,stripBlanks(tempRev_ID));
	
    printf("\n  checklist Number:%s",irchecklist);

	ITK_CALL(ITEM_find_item(irchecklist,&item_tag1));
	printf("\nchecklist creation");

	if(item_tag1)
	{
			// function create CheckList Row Data()
			printf("\nCheck List Object is already Available.....updating\n"); fflush(stdout);
			ITK_CALL(ITEM_ask_latest_rev(item_tag1,&ChecklistRev));
		//	createCheckListRowData(item_tag1,SrNo,irchecklist,ChecklistRev,DesignRuleID,ChecklistImplemented);
            createCheckListRowData(item_tag1,module_no,rev_id,irchecklist,ChecklistRev,DesignRuleID,ChecklistImplemented,Remark);
            if(module_rev)
	       {
			
			printf("\nchecklist relation creation with module.....\n"); fflush(stdout); 
			ITK_CALL(GRM_find_relation_type("IMAN_reference",&relation_type1));
		    printf("\n module relation creation \n"); fflush(stdout);
			ITK_CALL(GRM_create_relation(module_rev,ChecklistRev,relation_type1,NULLTAG,&relation1));				
			ITK_CALL(AOM_unlock(relation1));
			GRM_save_relation(relation1);
			ITK_CALL(AOM_lock(relation1));
			printf("\nmodule RELATIONSHIP CREATED  \n");fflush(stdout);
	       }
	}
	else
	{
			//Check list object not found so creatiing check list object.

			ITK_CALL(TCTYPE_find_type("T5_IR_CHECKLIST", "Document", &item_type_tag1));         
			ITK_CALL(TCTYPE_construct_create_input(item_type_tag1, &item_create_input_tag1));
			ITK_CALL(AOM_set_value_string(item_create_input_tag1,"item_id",irchecklist));
		
			ITK_CALL(AOM_set_value_string(item_create_input_tag1,"object_name",irchecklist));
			ITK_CALL(TCTYPE_create_object (item_create_input_tag1, &object1));

				if(object1)
				{
					ifail = AOM_save(object1);
					ifail = AOM_refresh(object1,0);
					ifail = AOM_unlock(object1);
					printf("\nCheck List Object is created.\n"); fflush(stdout);
					ITK_CALL(ITEM_ask_latest_rev(object1,&ChecklistRev));
//********************************
                    ITK_CALL(AOM_refresh(ChecklistRev,1));
                    ITK_CALL(AOM_set_value_string(ChecklistRev,"item_revision_id","NR;1"));
                    ifail = AOM_save(ChecklistRev);
					ifail = AOM_refresh(ChecklistRev,0);					
					ifail = AOM_unlock(ChecklistRev);
//********************************
					
				//	createCheckListRowData(object1,SrNo,irchecklist,ChecklistRev,DesignRuleID,ChecklistImplemented);
				    createCheckListRowData(item_tag1,module_no,rev_id,irchecklist,ChecklistRev,DesignRuleID,ChecklistImplemented,Remark);
				    if(module_rev)
	                {
			          printf("\nchecklist relation creation with module.....\n"); fflush(stdout); 
			          ITK_CALL(GRM_find_relation_type("IMAN_reference",&relation_type1));
				      printf("\n module relation creation \n"); fflush(stdout);
				      ITK_CALL(GRM_create_relation(module_rev,ChecklistRev,relation_type1,NULLTAG,&relation1));				
				      ITK_CALL(AOM_unlock(relation1));
				      GRM_save_relation(relation1);
				      ITK_CALL(AOM_lock(relation1));
				      printf("\nmodule RELATIONSHIP CREATED  \n");fflush(stdout);
	                }
				}
	}


	return ifail;
}
//int createCheckListRowData(tag_t object,char* srNo,char* irchecklist,tag_t checkListRev,char* designRule,char* checkListImp)  module_no,rev_id
int createCheckListRowData(tag_t object,char* module_no,char* rev_id,char* irchecklist,tag_t checkListRev,char* designRule,char* checkListImp,char* Remark)
{
	printf("\n I am in createCheckListRowData....... \n");


	char*				 irchecklistobj				= NULL;
	tag_t                item_tag2					= NULL;
	tag_t				 item_type_tag2             = NULLTAG;
	tag_t				 item_create_input_tag2     = NULLTAG;	
	tag_t				 object2					= NULLTAG;
	tag_t                ChecklistobjRev            = NULLTAG;
	tag_t				 relation_type;
	tag_t				 relation					= NULLTAG;

/*	irchecklistobj=(char *)MEM_alloc(100);
	tc_strcpy(irchecklistobj,"");
	tc_strcpy(irchecklistobj,irchecklist);
	tc_strcat(irchecklistobj,"_CHKLIST_DATA_");
	tc_strcat(irchecklistobj,stripBlanks(srNo));
	
	printf("\n checklist data object:%s \n",irchecklistobj);*/




	//*****************************
	//checklist object name = ChecklistData_module_no_tempRev_ID_srNo
   
   char* tempRev_ID2=NULL;
   char name2[]="ChecklistData_";

	irchecklistobj=(char *)MEM_alloc(100);
    tc_strcpy(irchecklistobj,"");
    tc_strcpy(irchecklistobj,name2);
	tc_strcat(irchecklistobj,stripBlanks(module_no));	    
    tc_strcat(irchecklistobj,"_");	
    ITK_CALL(STRNG_replace_str(rev_id,";","_",&tempRev_ID2));
	printf("\n After STRNG_replace_str tempRev ID %s \n",tempRev_ID2);
	tc_strcat(irchecklistobj,stripBlanks(tempRev_ID2));
    tc_strcat(irchecklistobj,"_");
//	tc_strcat(irchecklistobj,stripBlanks(srNo));
tc_strcat(irchecklistobj,stripBlanks(designRule));
	
    printf("\n  checklist data Number:%s",irchecklistobj);


//***********************query for fetching IR properties using given design rule id**********************

               tag_t ItemQry     = NULLTAG;
               tag_t* ContainerTag   = NULLTAG;
               tag_t revtag=NULLTAG;
               char* agg =NULL;
               char* agg_grp =NULL;
               char* rule_desc =NULL;
               char* Container_RevSeq=NULL;
               int ConCount=0;
               int Entry_count=2;
		//	   char *Entries[1] = {"Name"};
		//	   char *Entries[2] = {"Type"};
               char **Values = (char **) MEM_alloc(100 * sizeof(char *));
               char* errorString = NULL;
     //        Values[0] =designRule;
		//	   Values[1] = "Interface Rule Revision";
            
             
            char *Entries[2] = {"Name","Type"};

			

			Values[0] = designRule;
            Values[1] = "Interface Rule Revision";

             printf("\nvalue_0:%s",Values[0]);
             printf("\nvalue_1:%s",Values[1]);


			

        ifail=QRY_find("General...", &ItemQry);

	    
		if (ItemQry)
		{ 
	     ITK_CALL(QRY_execute(ItemQry, Entry_count, Entries, Values, &ConCount, &ContainerTag));
		 
		 printf("\n Object Found : %d", ConCount);fflush(stdout);
				
		}	



	//************************************************

	ITK_CALL(ITEM_find_item (irchecklistobj,&item_tag2));

	 if(item_tag2)
	 {

				printf("\nCheck List DATA Object is already Available.....updating properties \n"); fflush(stdout);

				ITK_CALL(ITEM_ask_latest_rev(item_tag2,&ChecklistobjRev));
				ITK_CALL(AOM_refresh(ChecklistobjRev,1));
				ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Design_Rule_ID",designRule));
				ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Checklist_Implemented",checkListImp));
				ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Remark",Remark));
				
				//**************************************************************************
   

      if (ConCount>0)
      {
	

	     revtag=ContainerTag[0];
		 agg=(char *) MEM_alloc(100);
		 agg_grp=(char *) MEM_alloc(100);
		 rule_desc=(char *) MEM_alloc(2000);

		 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRAggregate",&agg));
		 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRAggrGrp",&agg_grp));
		 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRRuleDesc",&rule_desc));
		 
          printf("\n  t5_IRAggregate:%s",agg);
          printf("\n  t5_IRAggrGrp:%s",agg_grp);
          printf("\n  t5_IRRuleDesc:%s",rule_desc);

		
	   }

   
                ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Aggregate",agg));
                ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Aggregate_Group",agg_grp));
				ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Interface_Rule_Desc",rule_desc));




				//********************************************************************
				ITK_CALL(AOM_save(ChecklistobjRev));
				ITK_CALL(AOM_refresh(ChecklistobjRev,0));
				printf("\nProperties are updated\n");

				printf("\n *******checklist relation creation***********");
					
				ITK_CALL(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&relation_type));
				printf("\n aaaaaaaaaa \n"); fflush(stdout);
				ITK_CALL(GRM_create_relation(checkListRev,ChecklistobjRev,relation_type,NULLTAG,&relation));
				printf("\n bbbbbbbbbbb \n"); fflush(stdout);
				ITK_CALL(AOM_unlock(relation));
				GRM_save_relation(relation);
				ITK_CALL(AOM_lock(relation));
				printf("\nRELATIONSHIP CREATED  \n");fflush(stdout);
	 }
	 else
	 {
			printf("\n *******checklist data object creation****");

			ITK_CALL(TCTYPE_find_type("T5_IR_CLIST_DATA", "Document", &item_type_tag2));         
			ITK_CALL(TCTYPE_construct_create_input(item_type_tag2, &item_create_input_tag2));
			ITK_CALL(AOM_set_value_string(item_create_input_tag2,"item_id",irchecklistobj));
			ITK_CALL(AOM_set_value_string(item_create_input_tag2,"object_name",irchecklistobj));
			ITK_CALL(TCTYPE_create_object (item_create_input_tag2, &object2));
			if(object2)
			{
				printf("\n T5_IR_CLIST_DATA : object created.");

				ifail = AOM_save(object2);
				ifail = AOM_refresh(object2,0);
				ifail = AOM_unlock(object2);
				printf("\nCheck List DATA  Object is created.\n"); fflush(stdout);

				ITK_CALL(ITEM_ask_latest_rev(object2,&ChecklistobjRev));
				ITK_CALL(AOM_refresh(ChecklistobjRev,1));
				ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Design_Rule_ID",designRule));
				ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Checklist_Implemented",checkListImp));
				ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Remark",Remark));
				ITK_CALL(AOM_set_value_string(ChecklistobjRev,"item_revision_id","NR;1"));
				


         //**************************************************************************
      
      if (ConCount>0)
      {
	

	     revtag=ContainerTag[0];
		 agg=(char *) MEM_alloc(100);
		 agg_grp=(char *) MEM_alloc(100);
		 rule_desc=(char *) MEM_alloc(2000);

		 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRAggregate",&agg));
		 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRAggrGrp",&agg_grp));
		 ITK_CALL(AOM_ask_value_string(revtag,"t5_IRRuleDesc",&rule_desc));
		 
		 printf("\n  t5_IRAggregate:%s",agg);
          printf("\n  t5_IRAggrGrp:%s",agg_grp);
          printf("\n  t5_IRRuleDesc:%s",rule_desc);
	
	   }

   
                ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Aggregate",agg));
                ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Aggregate_Group",agg_grp));
				ITK_CALL(AOM_set_value_string(ChecklistobjRev,"t5_Interface_Rule_Desc",rule_desc));




//********************************************************************


				ITK_CALL(AOM_save(ChecklistobjRev));
				ITK_CALL(AOM_refresh(ChecklistobjRev,0));
				printf("\nProperties are updated\n");

				printf("\n *******checklist relation creation***********");
					
				ITK_CALL(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&relation_type));
				printf("\n aaaaaaaaaa \n"); fflush(stdout);
				ITK_CALL(GRM_create_relation(checkListRev,ChecklistobjRev,relation_type,NULLTAG,&relation));
				printf("\n bbbbbbbbbbb \n"); fflush(stdout);
				ITK_CALL(AOM_unlock(relation));
				GRM_save_relation(relation);
				ITK_CALL(AOM_lock(relation));
				printf("\nRELATIONSHIP CREATED  \n");fflush(stdout);
			}
	 }

	return 0;
}


int exportpdffile(char* moduleno)
{
/*
logical dataset = false;
tag_t	chklistreltyp = NULLTAG;
tag_t* chkliststag = NULLTAG;
tag_t chklisttag = NULLTAG;
tag_t	chklistobjTypTag		= NULLTAG;
tag_t	chklistdatareltyp = NULLTAG;
tag_t* chklistdatastag = NULLTAG;
tag_t	chklistdatatag = NULLTAG;
tag_t	latestrevid = NULLTAG;


int chklistcnt =0;
int aa = 0;
int bb = 0;
int chklistdatacnt=0;



 ITK_CALL(GRM_find_relation_type("IMAN_reference",&chklistreltyp));
 ITK_CALL(GRM_list_secondary_objects_only(objTag,chklistreltyp,&chklistcnt,&chkliststag));
 printf("\n Ref Relation count : %d \n",chklistcnt);fflush(stdout);
 if (chklistcnt>0)
 {

	  for(bb=0;bb<chklistcnt;bb++)
	   {
           chklisttag =chkliststag[bb];
		   AOM_ask_value_string(chklisttag,"object_type",&Objtyp);
			printf("\n object_type: [%s]\n", Objtyp);fflush(stdout);
			if(tc_strcmp(Objtyp,"PDF") == 0)
			{
				printf("\n Checking IR Checklist PDF Availability under Reference Relation on Module \n");fflush(stdout);
				char *file_type = NULL;
				 AE_reference_type_t     reftype2; 
				 tag_t Named_ref_obj=NULLTAG;  
				 char   NR_Filename[IMF_filename_size_c + 1]; 
				 ITK_CALL(AE_find_dataset_named_ref2(chklisttag,chklistcnt,&file_type,&reftype2,&Named_ref_obj));
				 ITK_CALL(IMF_ask_original_file_name(Named_ref_obj,NR_Filename)); 
				 printf("\n checking file:%s type:%s",NR_Filename,file_type);fflush(stdout);

				if(tc_strcmp(NR_Filename,Fname) == 0)
				{
				 printf("\n IR Checklist PDF is Available under Reference Relation on Module \n");fflush(stdout);
				 dataset=true;
				}

			}
			
	   }
	  
 }
 if (dataset==false)
 {*/
    tag_t dataset_rel_type=NULLTAG;
	tag_t dataset_rel_type2=NULLTAG;
	tag_t datasettype=NULLTAG;
	tag_t* datasetobj1=NULLTAG;
	tag_t datasetobj2=NULLTAG;
	tag_t Datasetobj3=NULLTAG;
	tag_t Datasetobj4=NULLTAG;
	tag_t* Named_ref=NULLTAG;
	tag_t Named_ref_obj=NULLTAG;
	tag_t	itemtag = NULLTAG;
	tag_t	latestrevid = NULLTAG;
	char* class =NULL;
	char* NR_Filename=NULL;
	char* Dataset_name=NULL;
	int i=0;
	int NR_count=0;
	int NRflag=0;
	int DsCnt=0;

	char	*Fname	=  NULL;
	char	*revID_CCA	=  NULL;
	char	*latest_rev_IDCCA	=  NULL;
	char	*tempRev_ID	=  NULL;
	char *FullPath=NULL;
	char* TokCcidNum							=NULL;
	char* rev1							=NULL;
	char* seq							=NULL;
	char	*Dataset_Type	=  NULL;
	FullPath=(char *) MEM_alloc(1000);


	int NRflag2 =0;

	Fname=(char *)MEM_alloc(100);

	 printf("\n adding dataset \n");fflush(stdout);

	 ITK_CALL(ITEM_find_item(moduleno,&itemtag));

	 printf("\n  module found ");


	ITK_CALL(ITEM_ask_latest_rev(itemtag,&latestrevid));

	ITK_CALL( AOM_ask_value_string(latestrevid,"item_id",&revID_CCA));
	printf("\n module item id=> [%s] ",revID_CCA); fflush(stdout);

			 
	ITK_CALL( AOM_ask_value_string(latestrevid,"item_revision_id",&latest_rev_IDCCA));
	printf("\n module itemrev id=> [%s] ",latest_rev_IDCCA); fflush(stdout);

//	ITK_CALL(STRNG_replace_str(latest_rev_IDCCA,";","_",&tempRev_ID));
//	printf("\n After STRNG_replace_str tempRev ID %s \n",tempRev_ID);


	  tempRev_ID=(char *)MEM_alloc(60);

		TokCcidNum=(char *)MEM_alloc(60);
		

		tc_strcpy (TokCcidNum,"" );
		tc_strcat (TokCcidNum,latest_rev_IDCCA);

		rev1 = tc_strtok(TokCcidNum,";");

		seq	 = tc_strtok(NULL,";");

		
		printf("\n Aftertok rev1   ==%s\n",rev1);fflush(stdout);
		printf("\n Aftertok seq   ==%s\n",seq);fflush(stdout);

		tc_strcpy(tempRev_ID,rev1);
		tc_strcat(tempRev_ID,"_");
		tc_strcat(tempRev_ID,seq);

		printf("\n final tempRev_ID   ==%s\n",tempRev_ID);fflush(stdout);








	
  //  Fname = malloc(1500);
/*	tc_strcpy(Fname,"");				
	tc_strcat(Fname,stripBlanks(revID_CCA));
	tc_strcat(Fname,stripBlanks("_"));
	tc_strcat(Fname,stripBlanks(tempRev_ID));
	tc_strcat(Fname,"_IR_report.pdf");*/

	tc_strcpy(Fname,"");				
	tc_strcat(Fname,revID_CCA);
	tc_strcat(Fname,"_");
	tc_strcat(Fname,tempRev_ID);
	tc_strcat(Fname,"_IR_report.pdf");

	FullPath = strcpy(FullPath,"/user/testcmi/Dev/devgroups/Akshay/IR/checkin/");
//	FullPath = strcpy(FullPath,"/user/cvprod/Sagar/");
	tc_strcat(FullPath,Fname);

	printf("\n file name %s \n",Fname);
			
	 class=(char *) MEM_alloc(100);
	 ifail = AOM_ask_value_string(latestrevid,"object_name",&class);
	
	 ifail=GRM_find_relation_type("IMAN_reference", &dataset_rel_type);
	 ifail=GRM_list_secondary_objects_only(latestrevid,dataset_rel_type,&DsCnt,&datasetobj1);
	 printf("\n DsCnt = %d \n",DsCnt);fflush(stdout);
	if(DsCnt>0)
	{
	  for( i=0; i<DsCnt; i++)
		{
			
			Datasetobj3=datasetobj1[i];

			ifail = AOM_ask_value_string(Datasetobj3,"object_type",&Dataset_Type);
			printf("\n Dataset_Type = %s \n",Dataset_Type);fflush(stdout);

		   if(tc_strcmp(Dataset_Type,"PDF")==0)
		   {
			  printf("\n Dataset_Type Is PDF \n");fflush(stdout);

			  ifail = AOM_ask_value_string(Datasetobj3,"object_name",&Dataset_name);
			  printf("\n object_name= %s \n",Dataset_name);fflush(stdout);
				if(tc_strcmp(Dataset_name,Fname)==0)
				{
						
					printf("\nDataset found checking for Named ref file");fflush(stdout);
					ifail=AE_ask_dataset_named_refs(Datasetobj3,&NR_count,&Named_ref);
				  
				    if(NR_count>0)
				    {
					   for( i=0; i<NR_count; i++)
						{
						 Named_ref_obj=Named_ref[i];
						 ifail = AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename);
						 
						// if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
							if(tc_strcmp(NR_Filename,Fname)==0)
							{ 
								printf("\nNamed refrenced file is alredy exists in dataset attached to container");fflush(stdout);
								NRflag=1;
								NRflag2=1;
								printf("\n  NRflag2 is one \n");fflush(stdout);
								

							}
						
					   }
					
				    }
				   if(NRflag==0||NR_count==0)
					{
						printf("\nAdding Named refrenced file in existing dataset attached to container");fflush(stdout);
						ifail=AOM_refresh(Datasetobj3,1);
						ifail=AE_import_named_ref(Datasetobj3,"PDF_Reference",FullPath,NULL,SS_BINARY);
						ifail=AOM_save(Datasetobj3);
						ifail=AOM_refresh(Datasetobj3,0);
						NRflag2=1;
						
					}
						
				}
			/*	else 
				{
				   printf("\nDataset not matched.creating both dataset and Named ref file");fflush(stdout);
				   ifail= AE_find_datasettype2("PDF",&datasettype);
				   ifail=AE_create_dataset_with_id(datasettype,Fname,Fname,Fname,Fname,&Datasetobj4);
				   ifail=AOM_save(Datasetobj4);
				   ifail=AE_find_dataset2(Fname,&datasetobj2);
				   ifail=AOM_refresh(datasetobj2,1);
				   ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
				   ifail=AOM_save(datasetobj2);
				   ifail=AOM_refresh(datasetobj2,0);
				   ifail=GRM_create_relation(latestrevid,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
				   ifail=GRM_save_relation(dataset_rel_type2);      
				   
				}*/
			}
			if(NRflag2==1)
			{
               break;
			}
					
		}
		
	}
	//else
	if(NRflag2==0)
	{	
		printf("\n inside NRflag2 ");fflush(stdout);
		
	  ifail=AE_find_dataset2(Fname,&datasetobj2);
	  
	 if (datasetobj2)
	  {
			printf("\n Dataset found. Creating relation with Module");fflush(stdout);
			ifail=GRM_create_relation(latestrevid,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
			ifail=GRM_save_relation(dataset_rel_type2);      
			ifail=AE_ask_dataset_named_refs(datasetobj2,&NR_count,&Named_ref);
		  
			  if(NR_count>0)
			  {
				   for( i=0; i<NR_count; i++)
					{
					 Named_ref_obj=Named_ref[i];
					 ifail = AOM_UIF_ask_value(Named_ref_obj, "original_file_name",&NR_Filename);
					 
					// if(tc_strcmp(NR_Filename,ImanFile_Name)==0)
					   if(tc_strcmp(NR_Filename,Fname)==0)
						{ 
							printf("\nNamed refrenced file is alredy exists in dataset");fflush(stdout);
							NRflag=1;
						}
					
				   }
				
			}
		   else if(NRflag==0||NR_count==0)
			{
				printf("\nAdding Named refrenced file in existing dataset");fflush(stdout);
				ifail=AOM_refresh(datasetobj2,1);
				ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
				ifail=AOM_save(datasetobj2);
				ifail=AOM_refresh(datasetobj2,0);
				
			}
	  
	  }
	  
	  else 
		{
		   printf("\nDataset not found creating both dataset and Named ref file");fflush(stdout);
		   ifail= AE_find_datasettype2("PDF",&datasettype);
		   ifail=AE_create_dataset_with_id(datasettype,Fname,Fname,Fname,Fname,&Datasetobj4);
		   ifail=AOM_save(Datasetobj4);
		   ifail=AE_find_dataset2(Fname,&datasetobj2);
		   ifail=AOM_refresh(datasetobj2,1);
		   ifail=AE_import_named_ref(datasetobj2,"PDF_Reference",FullPath,NULL,SS_BINARY);
		   ifail=AOM_save(datasetobj2);
		   ifail=AOM_refresh(datasetobj2,0);
		   ifail=GRM_create_relation(latestrevid,datasetobj2,dataset_rel_type,NULLTAG,&dataset_rel_type2);
		   ifail=GRM_save_relation(dataset_rel_type2);      
		   printf("\nDataset is attached to IR");fflush(stdout);
		}
	}
		
   
 //}


	return 0;
}