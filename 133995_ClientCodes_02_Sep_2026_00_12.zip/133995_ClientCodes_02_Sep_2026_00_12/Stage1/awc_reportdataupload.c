#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
//#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
#include <tccore/aom_prop.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <ae/dataset_msg.h>
#include <tccore/grm_msg.h>
//#include <epm/releasestatus.h>
#include <tc/tc_startup.h>
#include <tc/folder.h>
//#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <res/res_itk.h>
#include <ctype.h>
#include <pom/pom/pom.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <time.h>


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
char* subString (char* mainStringf ,int fromCharf,int toCharf);
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
void trim_spaces(char *str) {
    // Trim leading spaces
    int start = 0;
	int i=0;
    while (str[start] != '\0' && isspace((unsigned char)str[start])) {
        start++;
    }

    // Trim trailing spaces
    int end = strlen(str) - 1;
    while (end >= start && isspace((unsigned char)str[end])) {
        end--;
    }

    // Shift the string to remove leading spaces
    int len = end - start + 1;
    for (i = 0; i < len; i++) {
        str[i] = str[start + i];
    }

    // Null-terminate the string
    str[len] = '\0';
}
void remove_backticks(char *str) {
    int readIndex = 0, writeIndex = 0;

    // Iterate over each character in the string
    while (str[readIndex] != '\0') {
        // If the current character is not a backtick, copy it
        if (str[readIndex] != '`') {
            str[writeIndex++] = str[readIndex];
        }
        readIndex++;
    }

    // Null-terminate the string after modifying it
    str[writeIndex] = '\0';
}
void remove_commas(char *str) {
    int readIndex = 0, writeIndex = 0;

    // Iterate over each character in the string
    while (str[readIndex] != '\0') {
        // If the current character is not a comma, copy it to the write position
        if (str[readIndex] != ',') {
            str[writeIndex++] = str[readIndex];
        }
        readIndex++;
    }

    // Null-terminate the string after modifying it
    str[writeIndex] = '\0';
}
void objectcreation(char* VC_NO,char*reasontype,char* NoPOpart,char*Veh_Pro,char*PLM_REV,char*SAP_PO_REV,char*PART_INWARDING_STATUS,char*PARTCS,char*PARTTYPE,char*PARTDRSTATUS,char*PROJECT,char*DESIGNGRP,char*DRW_INDICATOR,char*COLOURINDICATOR,char*PARTDESCRIPTION)
{
 
   tag_t AWCRevisionTag =NULLTAG;
   tag_t AWCRevision =NULLTAG;
   tag_t object_create_input_tag3 =NULLTAG;
   tag_t RevAWCRevision =NULLTAG;
   tag_t Awcrev=NULLTAG;
   logical checkout1;
   char* AwcNo=NULL;
   tag_t AwcItemTag=NULLTAG; 
//   char * reasontype =NULL;
//   char * NoPOpart =NULL;
//   char * VC_NO =NULL;



  ITK_CALL(TCTYPE_find_type("T5_AWC_Report", NULL, &AWCRevisionTag));
//   ITK_CALL( TCTYPE_find_type( "T5_AWC_ReportRevision", NULL, &AWCRevisionTag) );
  if(AWCRevisionTag != NULLTAG)
	{
	   printf("\nTag found\n");
   ITK_CALL(TCTYPE_construct_create_input(AWCRevisionTag, &object_create_input_tag3));
   ITK_CALL(AOM_set_value_string(object_create_input_tag3,"item_id",""));
   //ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",VC_NO));
   ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&AWCRevision));
   //ITK_CALL(AOM_lock(AWCRevisionTag));
   //ITK_CALL(AOM_refresh(AWCRevision,0));
   //ITK_CALL(AOM_lock(AWCRevisionTag));
   //ITK_CALL(AOM_save_with_extensions(AWCRevision));
   ITK_CALL(AOM_save_without_extensions(AWCRevision)); 
   ITK_CALL(AOM_ask_value_string(AWCRevision,"item_id",&AwcNo));
   printf("AWC Item name %s",AwcNo);
   ITK_CALL(ITEM_find_item(AwcNo,&AwcItemTag));

   if(AwcItemTag!=NULLTAG)
		{
   ITK_CALL(ITEM_ask_latest_rev(AwcItemTag,&Awcrev));
	   if(Awcrev!=NULLTAG)
		{

		      printf("\nReason type %s",reasontype);
			  printf("\nVC No************ %s",VC_NO);
			  printf("\nNoPoPart %s",NoPOpart);
			 // printf("\nNoPoPart %s",NoPOpart);
			  //printf("\n PLM_REV %s",PLM_REV);
			 // printf("\n SAP_PO_REV %s",PLM_REV);
			 // printf("\n PART_INWARDING_STATUS %s",PART_INWARDING_STATUS);
			  //printf("\n PARTCS %s",PARTCS);
			 // printf("\n PARTTYPE %s",PARTTYPE);
			 // printf("\n PARTDRSTATUS %s",PARTDRSTATUS);
			 // printf("\n PROJECT %s",PROJECT);
			  //printf("\n DESIGNGRP %s",DESIGNGRP);
			  //printf("\n DRW_INDICATOR %s",DRW_INDICATOR);
			 // printf("\n COLOURINDICATOR %s",COLOURINDICATOR);
			 // printf("\n PARTDESCRIPTION %s",PARTDESCRIPTION);
			  
              printf("\nAWC Revision found");
			  printf("\nPart is checked out");
			  ITK_CALL(AOM_lock(Awcrev));
			  ITK_CALL(AOM_set_value_string(Awcrev,"t5_Type",reasontype));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_VC_NO",VC_NO));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_Veh_Name",Veh_Pro));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_NO_PO_Part_NO",NoPOpart));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_Revisions",PLM_REV));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_SAP_PO_REV",SAP_PO_REV));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_PART_INWARDING_STATUS",PART_INWARDING_STATUS));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_PART_CS",PARTCS));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_PART_TYPE",PARTTYPE));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_PART_DR_STATUS",PARTDRSTATUS));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_PROJECT",PROJECT));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_DESIGN_GRP",DESIGNGRP));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_DRW_INDICATOR",DRW_INDICATOR));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_COLOUR_INDICATOR",COLOURINDICATOR));
              ITK_CALL(AOM_set_value_string(Awcrev,"t5_PART_DESCRIPTION",PARTDESCRIPTION));
			  ITK_CALL(AOM_save_without_extensions(Awcrev));
			  ITK_CALL(AOM_unlock(Awcrev));
			  

              
        }
		else
		{
		 printf("AWC Revision NOT found");
		 }
		}
		else
		{
		       printf("\nItem Tag not found");
		
		}
//	
//	ITK_CALL(TCTYPE_construct_create_input(AWCRevisionTag, &object_create_input_tag3));
//	ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_name",VC_NO));
//	ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc",dfq_use_case_desc));
//	ITK_CALL(AOM_set_value_string(object_create_input_tag3,"t5_DFQUID",dfq_use_case_uid));
//	ITK_CALL(AOM_set_value_logical(object_create_input_tag3,"t5_DFQApplicablility",0));
//	ITK_CALL(AOM_set_value_string(object_create_input_tag3,"t5_DFQ_Project_Code",DVA_project_Code));
//
//	ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&datasettag));
//	ITK_CALL(AOM_lock(datasettag));
//	ITK_CALL(AE_set_dataset_tool( datasettag, tool));
//	ITK_CALL(AE_set_dataset_format2(datasettag, "BINARY_REF"));   //Code Change
//    ITK_CALL(AOM_lock(AWCRevisionTag));
//	ITK_CALL(AOM_save_with_extensions(AWCRevisionTag));
//	ITK_CALL(AOM_refresh(AWCRevisionTag,0));
	}
	else
	{
	 
	 printf("\ntag not found\n");
	
	}
//       ITK_CALL(ITEM_create_item(VC_NO,VC_NO,"T5_AWC_Report","NR;1",&AWCRevisionTag,&AWCRevision));
//       ITK_CALL(AOM_lock(AWCRevisionTag));
//       ITK_CALL(ITEM_create_rev(AWCRevisionTag,"NR;1",&RevAWCRevision));
//	   ITK_CALL(AOM_save(RevAWCRevision));
//	   ITK_CALL(AOM_unlock(RevAWCRevision));



   



}
char* getProject(char* ProjCode)
{
	tag_t TagQryContObj = NULLTAG, *cntr_objects = NULLTAG;

	//int	n_entries = 1;
	int	n_entries = 2;
	int n_found = 0;

	char* ProgName=NULL;

//	char *qry_entries[0] = {"Name"};
//	char *qry_entries[1] = {"Type"};
    char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));


	
	char *qry_entries[2] = {"Name","Type"};
	qry_values[0] = ProjCode;
	qry_values[1] = "T5_Project";
	  

	  printf("\n project in fun %s\n",ProjCode);

	//if(QRY_find2("Prd_Project", &TagQryContObj));
	if(QRY_find2("General...", &TagQryContObj));

	if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	printf("\n getProgramProject-->Objects for Query ControlObjQry == %d", n_found);fflush(stdout);

	if(n_found > 0)
	{
		if( AOM_ask_value_string(cntr_objects[0],"t5_Program",&ProgName));
		printf("\n getProgramProject-->ProgName Value == [%s]", ProgName);fflush(stdout);
	}

	return ProgName;
}

extern int ITK_user_main(int argc, char *argv[] )
{

	int	iStatus= 0;
	int ii=0;
	int iChRItem=0;
    tag_t	queryTag	= NULLTAG;
	tag_t   queryTag1   =NULLTAG;
	char *sUserName		=   NULL;
    char *sPassword		=   NULL;
    char *sGroup          =   NULL;
    char *user_id = NULL;
	int resultCount=0;
    int resultCount1=0;
	tag_t UserTag=NULLTAG;
    tag_t UserTag1=NULLTAG;
    tag_t *rev=NULLTAG;
     tag_t *rev1=NULLTAG;
	int n_Input = 1;
	tag_t	Quser= NULLTAG;
	char	*qry_Input[1]= {"Id"};
	tag_t *lov=NULLTAG;
	tag_t ProjTag=NULLTAG;
	int n_entries = 1;
	char	*values[1];
	tag_t	*Usertag= NULLTAG;
	int n_entries1 = 2;
	char *useridTag=NULL;
	char * Line		=	NULL;
	char * User_Name1       =NULL; 
	char * User_ID	=	NULL;
	char * Project_list = NULL;
	int		Count= 0;
	char *dupproj=NULL;
	char *object_name= NULL;
	char *status1=NULL;
	char* FirstName=NULL;
    char* MiddleName=NULL;
    char* LastName=NULL;
	char * Project_Code		=	NULL;
	//tag_t	UserTag1		   = NULLTAG;
	tag_t	UserTag12		   = NULLTAG;
	char * flag1value=NULL;
	char * flag1valuetok=NULL;
	char *  PLM_REV =NULL;
	char *  PLM_REV1 =NULL;
	char *   SAP_PO_REV  =NULL;
	char *   PART_INWARDING_STATUS  =NULL;
	char *    PARTCS  =NULL;
	char *    PARTTYPE  =NULL;
	char *     DESIGNGRP  =NULL;
	char *      DRW_INDICATOR  =NULL;
	char *    PARTDRSTATUS  =NULL;
	char *    PARTDRSTATUS1  =NULL;
	char *    COLOURINDICATOR  =NULL;
	char *    PARTDESCRIPTION  =NULL;
	char *    PARTDRSTATUS2  =NULL;
	char *    PARTDRSTATUS3  =NULL;
	char *     PROJECT  =NULL;
	char * flag2valuetok=NULL;
	char * flag4valuetok=NULL;
	char * flag3valuetok=NULL;
	char * flag2value=NULL;
	char * flag3value=NULL;
	char * flag4value=NULL;
	flag1value = (char *)MEM_alloc(50);
	PLM_REV  = (char *)MEM_alloc(50);
	PLM_REV1  = (char *)MEM_alloc(50);
	SAP_PO_REV   = (char *)MEM_alloc(50);
	PART_INWARDING_STATUS   = (char *)MEM_alloc(50);
	COLOURINDICATOR   = (char *)MEM_alloc(50);
	PARTDESCRIPTION   = (char *)MEM_alloc(50);
	PARTDRSTATUS2   = (char *)MEM_alloc(50);
	PARTDRSTATUS3   = (char *)MEM_alloc(50);
	PARTCS   = (char *)MEM_alloc(50);
	PARTTYPE   = (char *)MEM_alloc(50);
	 DESIGNGRP   = (char *)MEM_alloc(50);
	  DRW_INDICATOR   = (char *)MEM_alloc(50);
	PARTDRSTATUS   = (char *)MEM_alloc(50);
	PARTDRSTATUS1   = (char *)MEM_alloc(50);
	 PROJECT   = (char *)MEM_alloc(50);
	flag1valuetok = (char *)MEM_alloc(50);
	flag2valuetok = (char *)MEM_alloc(50);
	flag4valuetok = (char *)MEM_alloc(50);
	flag3valuetok = (char *)MEM_alloc(50);
	flag2value = (char *)MEM_alloc(50);
	flag3value = (char *)MEM_alloc(50);
	flag4value = (char *)MEM_alloc(50);

	char * Groups    =	NULL;
	char * Roles			=	NULL;
	char* usernameTag                   = NULL;
	char *status              =NULL;
	char * License_Level =	NULL; 
	char * Projeccode		=	NULL;
	char * User_Agency		=	NULL;
	char * User_Location			=	NULL;
	char * OS_Login			=	NULL;
	char * Email_ID			=	NULL;
	char * Visualization_Sevice_Level			=	NULL;
	char * Last_Login_Date			=	NULL;
    char        *qry_entries[1]                   = {"User ID"};
	char *qry_entries1[2] = {"Project ID","Id"};
    char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));
	char    *qry_values[1];
	int nCRItem=0;
	tag_t person_tag = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t additional_prop_tag = NULLTAG;
	
    printf("\n Auto login1 ");
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
    printf("\n Auto login2 ");

	//ITK_CALL(ITK_auto_login( ));
	iStatus = ITK_auto_login();
	printf("\n Auto login3 ");
	ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login4\n");
	if(iStatus == ITK_ok)
    {
        printf("\n\n\t Login Successful\n");
    }
    else
    {
        printf("\n\n\t Login is Not Successful\n");
    }

    ITK_CALL(POM_get_user_id(&user_id));
	
	printf("\n\n\t logged in User: %s\n",user_id);

   
    FILE *fp=NULL;
    FILE *ftr=NULL;
    
    //char* LineRead = NULL;
    char  temp[8000];
    int count=0;
	int flag1=0;
	int flag2=0;
	int flag3=0;
	int flag4=0;
	int flag5=0;
	int flag6=0;
	char* l1 =NULL;
	char* l2 =NULL;
    char* l3 =NULL;
	char* Row=NULL;
	char* VC_number=NULL;
	char * reasontype1=NULL;
	char * reasontype2=NULL;
	char * reasontype3=NULL;
	char * reasontype4=NULL;
	char * reasontype5=NULL;
	char * projectcode=NULL;
	//int projectcode =0;
	char * Veh_Pro=NULL;
	
	Row = (char *)MEM_alloc(500);
	reasontype1 = (char *)MEM_alloc(50);
	reasontype2 = (char *)MEM_alloc(50);
	reasontype3 = (char *)MEM_alloc(50);
	reasontype4 = (char *)MEM_alloc(50);
	reasontype5 = (char *)MEM_alloc(50);
	//projectcode = (char *)MEM_alloc(50);
	Veh_Pro = (char *)MEM_alloc(50);
	char* VC_NO=NULL;
	char* vcdup=NULL;
	char *inputfile=NULL;
    inputfile = ITK_ask_cli_argument("-i=");
  	printf("\n Auto login5 ");fflush(stdout);
    fp=fopen(inputfile,"r");
    printf("\n Auto login6 ");fflush(stdout);  
  	if(fp==NULL)
  	{
		printf("Read File\n");
  		printf("unable  open  File\n ");fflush(stdout);
  		return 1;
  	}
	

  	else
  	{
  		printf("\n Auto login7 ");fflush(stdout);
        
  		while(fgets(temp,4000,fp)!=NULL)
  		{
  			  count++;  
  			 if(temp != NULL)
  			 {
                 if(count >=5)
				 {
    		    // fputs(temp,stdout);
				// Line = (char *)MEM_alloc(50);
				// User_Name1 = (char *)MEM_alloc(50);
  			 	// Line = strtok(temp," ");
                  
				   trim_spaces(temp);
                   tc_strcpy(Row,temp);
				   if(tc_strstr(Row,"Part Number")!=NULL)
					 {
				   l1=strtok(temp," ");
                   l2=strtok(NULL," ");
                   l3=strtok(NULL," ");
				  // printf("%s\n",l1);
				  // printf("%s\n",l2);
				  // printf("%s\n",l3);
				   VC_NO=strtok(l2,"Number");

				   
				   //printf("\n");
                   trim_spaces(VC_NO);
				   printf("\nVCNO %s\n",VC_NO);
				   tc_strdup(VC_NO,&vcdup);
				   projectcode = subString(vcdup, 0, 4);
				   printf("\n sub project code is %s\n",projectcode);
				    Veh_Pro=getProject(projectcode);
					printf("\n   Veh_Pro ------->  %s\n",Veh_Pro);
				     }
					// printf("\nDuplicate Vehicle No %s",vcdup);
					// printf("Count %d \n",count);
				   if(tc_strstr(Row,"SET OF NO PO CHECK BYPASS PARTS ARE BELOW.")!=NULL)
				    { 
				            break;
				    }
				   if(tc_strstr(Row,"Part Number")!=NULL || tc_strlen(Row)==0  || tc_strlen(Row)==1 || tc_strlen(Row)==2 || tc_strlen(Row)==3 || tc_strstr(Row,"[Parts should be updated to higher DR-status with Gate Maturation DML.]") || tc_strstr(Row,"NOT FOUND") || tc_strstr(Row,"[PO to be placed or VCMS allowed]"))
					 {
					    //printf("\n Inside This conditon\n");
				        continue;
 				     }

					if(tc_strstr(Row,"SET OF NOPO PARTS ARE BELOW.")!=NULL)
					 {
						tc_strcpy(reasontype1,Row);
						//printf("Reason Type 1%s",reasontype1);
					   // printf("Line 1 %s",Row);
						printf("\n Inside This conditon1\n");
						flag1=1;
					 }
					  else if (tc_strstr(Row,"SET OF COLOUR NOPO PARTS ARE BELOW.")!=NULL)
                     {
						printf("\n Inside This conditon2\n");
						 tc_strcpy(reasontype3,Row);
						// printf("Reason Type 4 %s",reasontype1);
                        // printf("Line 4 %s",Row);
						//printf("\n Inside This conditon2\n");
						 flag2=1;
                     }
					 else if (tc_strstr(Row,"SET OF COLOUR NOPO PARTS HAVING PO ON THEIR NON-COLOUR PART ARE BELOW.")!=NULL)
					 {
						 printf("\n Inside This conditon3\n");  
						 tc_strcpy(reasontype2,Row);
						// printf("Reason Type 5%s",reasontype1);
                        // printf("Line 5 %s",Row); 
						//printf("\n Inside This conditon3\n");
						 flag3=1;
					 }
					else if(tc_strstr(Row,"SET OF UNMATURATED DR-STATUS PARTS ARE BELOW.")!=NULL)
					 {
						
						printf("\n Inside This conditon4\n");
						tc_strcpy(reasontype5,Row);
						//printf("Reason Type 2%s",reasontype1);
                        //printf("Line 2 %s",Row);
						//printf("\n Inside This conditon4\n");
						flag4=1;
					 }
//					 else if(tc_strstr(Row,"SET OF UNMATURATED DR-STATUS PARTS ARE BELOW.")!=NULL)
//					 {
//						 printf("\n Inside This conditon3\n");
//						 tc_strcpy(reasontype3,Row);
//						printf("Reason Type 3 %s",reasontype1);
//                        printf("Line 3 %s",Row); 
//						  flag3=1;
//					 }
                 printf("\n value of first condition flag %d,%d,%d,%d\n",flag1,flag2,flag3,flag4);
					 
				     
					//if((flag2==1 || flag2==0) && (flag3==1 || flag3==0) && (flag4==1 || flag4==0) && flag1==1)
					if(flag1==1 && flag2==0 && flag3==0 && flag4==0)
				    { 

	
                        // printf("\n Inside flag1");
						 if(tc_strstr(Row,"SET OF NOPO PARTS ARE BELOW.")!=NULL)
						{
						   continue;
 						}
						// printf("Inside flag 1 length\n");
						 //printf("Length of string is %d",tc_strlen(Row));
						printf("ROW1 %s",Row);
						tc_strcpy(flag1value,Row);
						flag1valuetok=tc_strtok(flag1value,"	");
						remove_backticks(flag1valuetok);
						remove_commas(flag1valuetok);
						printf("\nThe Value of Row is %s,%s",reasontype1,flag1valuetok);
						PLM_REV= tc_strtok(NULL,"	");
						printf("\n PLM_REV1 %s\n",PLM_REV);
						SAP_PO_REV= tc_strtok(NULL,"	");
						printf("\n SAP_PO_REV1 %s\n",SAP_PO_REV);
						PART_INWARDING_STATUS= tc_strtok(NULL,"	");
						
						printf("\n PART_INWARDING_STATUS1 %s\n",PART_INWARDING_STATUS);
						PARTCS= tc_strtok(NULL,"	");
						printf("\n PARTCS1 %s\n",PARTCS);
						PARTTYPE=tc_strtok(NULL,"	");
						printf("\n PARTTYPE1 %s\n",PARTTYPE);
						PARTDRSTATUS=tc_strtok(NULL,"	");
						printf("\n PARTDRSTATUS1 %s\n",PARTDRSTATUS);
						PROJECT=tc_strtok(NULL,"	");
						printf("\n PROJECT1 %s\n",PROJECT);
						DESIGNGRP=tc_strtok(NULL,"	");
						printf("\n DESIGNGRP1 %s\n",DESIGNGRP);
						DRW_INDICATOR=tc_strtok(NULL,"	");
						printf("\n DRW_INDICATOR1 %s\n",DRW_INDICATOR);
						COLOURINDICATOR=tc_strtok(NULL,"	");
						printf("\n COLOURINDICATOR1 %s\n",COLOURINDICATOR);
						PARTDESCRIPTION=tc_strtok(NULL,"	");
						printf("\n PARTDESCRIPTION1 %s\n",PARTDESCRIPTION);
						
                        //PARTDESCRIPTION=flag1value;
                     // printf("\nThe Value of Row is  %s,%s,PLM_REV %s,SAP_PO_REV %s,PART_INWARDING_STATUS %s,PARTCS %s,PARTTYPE %s,PARTDRSTATUS %s,PROJECT %s,DESIGNGRP %s,DRW_INDICATOR %s,COLOURINDICATOR %s,PARTDESCRIPTION %s",reasontype1,flag1valuetok,PLM_REV,SAP_PO_REV,PART_INWARDING_STATUS,PARTDRSTATUS,PARTCS,PROJECT,DESIGNGRP,DRW_INDICATOR,COLOURINDICATOR,PARTDESCRIPTION);
                       //printf("\nThe Value of Row is  %s,%s,PLM_REV %s,SAP_PO_REV %s,PART_INWARDING_STATUS %s,PARTCS %s",reasontype1,flag1valuetok,PLM_REV,SAP_PO_REV,PART_INWARDING_STATUS,PARTCS);

						objectcreation(vcdup,reasontype1,flag1valuetok,Veh_Pro,PLM_REV,SAP_PO_REV,PART_INWARDING_STATUS,PARTCS,PARTTYPE,PARTDRSTATUS,PROJECT,DESIGNGRP,DRW_INDICATOR,COLOURINDICATOR,PARTDESCRIPTION);
						//printf("The Value of Row is  %s",reasontype1,flag1valuetok);
//					   //printf("VC No %s ,Reason Type1 %s , Child Part %s",VC_NO,reasontype1,Row);
					 //   printf("\nVC No*** %s ,Reason Type1** %s\n",VC_NO,reasontype1);
					   // printf("\nVC The value of flag1valuetok %s\n",flag1valuetok);
					   //flag1=0;
					 }
					 printf("\n value of Second condition flag %d,%d,%d,%d\n",flag1,flag2,flag3,flag4);
					 //if((flag1==1 ||flag1==0) && (flag3==1 || flag3==0) && (flag4==0 || flag4==1) && flag2==1)
					if(flag2==1 && flag3==0 && flag4==0)
					 {
						
						  //  printf("\n Inside flag2");
						 if(tc_strstr(Row,"SET OF COLOUR NOPO PARTS ARE BELOW.")!=NULL)
						{
						   continue;
 						}

						tc_strcpy(flag3value,Row);
						flag3valuetok=tc_strtok(flag3value,"	");
						remove_backticks(flag3valuetok);
						remove_commas(flag3valuetok);
						printf("\nThe Value of Row is %s,%s",reasontype3,flag3valuetok);
						//printf("\nThe Value of Row is 3 %s,%s",reasontype3,flag2valuetok);
						  PLM_REV= tc_strtok(NULL,"	");
						printf("\n PLM_REV2 %s\n",PLM_REV);
						SAP_PO_REV= tc_strtok(NULL,"	");
						printf("\n SAP_PO_REV2 %s\n",SAP_PO_REV);
						PART_INWARDING_STATUS= tc_strtok(NULL,"	");
						
						printf("\n PART_INWARDING_STATUS2 %s\n",PART_INWARDING_STATUS);
						PARTCS= tc_strtok(NULL,"	");
						printf("\n PARTCS2 %s\n",PARTCS);
						PARTTYPE=tc_strtok(NULL,"	");
						printf("\n PARTCS2 %s\n",PARTTYPE);
						PARTDRSTATUS=tc_strtok(NULL,"	");
						printf("\n PARTDRSTATUS2 %s\n",PARTDRSTATUS);
						PROJECT=tc_strtok(NULL,"	");
						printf("\n PROJECT2 %s\n",PROJECT);
						DESIGNGRP=tc_strtok(NULL,"	");
						printf("\n DESIGNGRP2 %s\n",DESIGNGRP);
						DRW_INDICATOR=tc_strtok(NULL,"	");
						printf("\n DRW_INDICATOR2 %s\n",DRW_INDICATOR);
						COLOURINDICATOR=tc_strtok(NULL,"	");
						printf("\n COLOURINDICATOR2 %s\n",COLOURINDICATOR);
						PARTDESCRIPTION=tc_strtok(NULL,"	");
						printf("\n PARTDESCRIPTION2 %s\n",PARTDESCRIPTION);
						

                        printf("\n PARTDESCRIPTION 2 %s\n",flag3value);
						tc_strcpy(PARTDESCRIPTION,flag3value);
						//printf("\nThe Value of Row is 1  %s,%s,PLM_REV %s,SAP_PO_REV %s,PART_INWARDING_STATUS %s,PARTCS %s",reasontype1,flag3valuetok,PLM_REV,SAP_PO_REV,PART_INWARDING_STATUS,PARTCS);
						objectcreation(vcdup,reasontype3,flag3valuetok,Veh_Pro,PLM_REV,SAP_PO_REV,PART_INWARDING_STATUS,PARTCS,PARTTYPE,PARTDRSTATUS,PROJECT,DESIGNGRP,DRW_INDICATOR,COLOURINDICATOR,PARTDESCRIPTION);
                       //printf("VC No %s ,Reason Type3 %s , Child Part %s",VC_NO,reasontype3,Row);
                       //printf("Reason Type3 %s",reasontype3);
					   //flag2=0;
					 }
					 printf("\n value of Third condition flag %d,%d,%d,%d\n",flag1,flag2,flag3,flag4);
					 //if((flag1==1 || flag2==1 ) && flag3==1)
					 if(flag3==1 && flag4==0)
                     //if((flag2==1 ||flag2==0) && (flag1==1 || flag1==0) && (flag4==1 || flag4==0) && flag3==1)
					 {  
						
						     // printf("\n Inside flag2");
						  if(tc_strstr(Row,"SET OF COLOUR NOPO PARTS HAVING PO ON THEIR NON-COLOUR PART ARE BELOW.")!=NULL)
						{
						   continue;
 						}
						// printf("Length of string is %d\n",tc_strlen(Row));
                         //printf("\nThe Value of flag2 %s\n",Row);
						  tc_strcpy(flag2value,Row);
						  flag2valuetok=tc_strtok(flag2value,"	");
						  remove_backticks(flag2valuetok);
						  remove_commas(flag2valuetok);

						printf("\nThe Value of Row is 3 %s,%s",reasontype2,flag2valuetok);
						PLM_REV= tc_strtok(NULL,"	");
						printf("\n PLM_REV3 %s\n",PLM_REV);
						SAP_PO_REV= tc_strtok(NULL,"	");
						printf("\n SAP_PO_REV3 %s\n",SAP_PO_REV);
						PART_INWARDING_STATUS= tc_strtok(NULL,"	");
						
						printf("\n PART_INWARDING_STATUS %s\n",PART_INWARDING_STATUS);
						PARTCS= tc_strtok(NULL,"	");
						printf("\n PARTCS3 %s\n",PARTCS);
						PARTTYPE=tc_strtok(NULL,"	");
						printf("\n PARTTYPE3 %s\n",PARTTYPE);
						PARTDRSTATUS=tc_strtok(NULL,"	");
						printf("\n PARTDRSTATUS3 %s\n",PARTDRSTATUS);
						PROJECT=tc_strtok(NULL,"	");
						printf("\n PROJECT3 %s\n",PROJECT);
						DESIGNGRP=tc_strtok(NULL,"	");
						printf("\n DESIGNGRP3 %s\n",DESIGNGRP);
						DRW_INDICATOR=tc_strtok(NULL,"	");
						printf("\n DRW_INDICATOR 3 %s\n",DRW_INDICATOR);
						COLOURINDICATOR=tc_strtok(NULL,"	");
						printf("\n COLOURINDICATOR 3 %s\n",COLOURINDICATOR);
						PARTDESCRIPTION=tc_strtok(NULL,"	");
						printf("\n PARTDESCRIPTION 3 %s\n",PARTDESCRIPTION);

						
						
						//printf("\nThe Value of Row is2  %s,%s,PLM_REV %s,SAP_PO_REV %s,PART_INWARDING_STATUS %s,PARTCS %s",reasontype1,flag2valuetok,PLM_REV,SAP_PO_REV,PART_INWARDING_STATUS,PARTCS);
						objectcreation(vcdup,reasontype2,flag2valuetok,Veh_Pro,PLM_REV,SAP_PO_REV,PART_INWARDING_STATUS,PARTCS,PARTTYPE,PARTDRSTATUS,PROJECT,DESIGNGRP,DRW_INDICATOR,COLOURINDICATOR,PARTDESCRIPTION);


                       // printf("VC No %s ,Reason Type4 %s",VC_NO,reasontype2);
                        //printf("\nThe Value of flag2valuetok %s\n",flag2valuetok);
						//flag3=0;
					 }
					 printf("\n value of Four condition flag %d,%d,%d,%d\n",flag1,flag2,flag3,flag4);
					 if(flag4==1)
					 //if((flag1==1 ||flag1==0) && (flag2==1 || flag2==0) && (flag3==1 || flag3==0) && flag4==1)
					 { 

						 if(tc_strstr(Row,"SET OF UNMATURATED DR-STATUS PARTS ARE BELOW.")!=NULL) 
						{
						   continue;
 						}
						// printf("Length of string is %d\n",tc_strlen(Row));
                         //printf("\nThe Value of flag2 %s\n",Row);
						  tc_strcpy(flag4value,Row);
						  flag4valuetok=tc_strtok(flag4value,"	");
						  remove_backticks(flag4valuetok);
						  remove_commas(flag4valuetok);

						printf("\nThe Value of Row is 3 %s,%s",reasontype5,flag4valuetok);
						PLM_REV= tc_strtok(NULL,"	");
						printf("\n PLM_REV3 %s\n",PLM_REV);
						SAP_PO_REV= tc_strtok(NULL,"	");
						printf("\n SAP_PO_REV3 %s\n",SAP_PO_REV);
						PART_INWARDING_STATUS= tc_strtok(NULL,"	");
						
						printf("\n PART_INWARDING_STATUS %s\n",PART_INWARDING_STATUS);
						PARTCS= tc_strtok(NULL,"	");
						printf("\n PARTCS3 %s\n",PARTCS);
						PARTTYPE=tc_strtok(NULL,"	");
						printf("\n PARTTYPE3 %s\n",PARTTYPE);
						PARTDRSTATUS=tc_strtok(NULL,"	");
						printf("\n PARTDRSTATUS3 %s\n",PARTDRSTATUS);
						PROJECT=tc_strtok(NULL,"	");
						printf("\n PROJECT3 %s\n",PROJECT);
						DESIGNGRP=tc_strtok(NULL,"	");
						printf("\n DESIGNGRP3 %s\n",DESIGNGRP);
						DRW_INDICATOR=tc_strtok(NULL,"	");
						printf("\n DRW_INDICATOR 3 %s\n",DRW_INDICATOR);
						COLOURINDICATOR=tc_strtok(NULL,"	");
						printf("\n COLOURINDICATOR 3 %s\n",COLOURINDICATOR);
						PARTDESCRIPTION=tc_strtok(NULL,"	");
						printf("\n PARTDESCRIPTION 3 %s\n",PARTDESCRIPTION);

						
						
						//printf("\nThe Value of Row is2  %s,%s,PLM_REV %s,SAP_PO_REV %s,PART_INWARDING_STATUS %s,PARTCS %s",reasontype1,reasontype5,PLM_REV,SAP_PO_REV,PART_INWARDING_STATUS,PARTCS);
					objectcreation(vcdup,reasontype5,flag4valuetok,Veh_Pro,PLM_REV,SAP_PO_REV,PART_INWARDING_STATUS,PARTCS,PARTTYPE,PARTDRSTATUS,PROJECT,DESIGNGRP,DRW_INDICATOR,COLOURINDICATOR,PARTDESCRIPTION);
					 //flag4=0;
					 
					 }
//					  if(flag4==1)
//					 {
//                       //printf("VC No %s ,Reason Type4 %s , Child Part %s",VC_NO,reasontype4,Row);
//                       printf("VC No %s ,Reason Type4 %s",VC_NO,reasontype4);
//					 }
//					  if(flag5==1)
//					 {
//                       //printf("VC No %s ,Reason Type5 %s , Child Part %s",VC_NO,reasontype5,Row);
//                       printf("VC No %s ,Reason Type5 %s",VC_NO,reasontype5);
//					 }	 
				 }
				 
                 //User_Name1=strtok(NULL,",");
				 //Project_list=strtok(NULL," ");
				// inputfile=(char *) MEM_alloc(150);
                /* tc_strcpy(inputfile,"/user/cvprod/Asif/UserIdDiff/MoveFile/"); 
                 tc_strcat(inputfile,User_Name);
                 tc_strcat(inputfile,".txt");
				 ftr=fopen(inputfile,"w");
				if(ftr == NULL)
                {
                                printf("\n Unable to Open File User does't have access of Project code and design group in TCUA");fflush(stdout);
                                return 1;
                }*/
		//	values[0] = User_Name1;
			//if(QRY_find2("UserFind", &Quser));
			//if(Quser)
		   // {
			// if(QRY_execute(Quser, n_Input, qry_Input, values, &Count, &Usertag));
			// printf("\n QUERY count== %d...................\n", Count);fflush(stdout);
		  //  }
		//	 if(Count==0)
			//	 {
		//		   fprintf(ftr,"%s\n","USERNOTFOUND"); 
			//	 } 
		//	if(Count>0)

		// {
			//  UserTag1 = Usertag[0];
			//  status1=(char *)MEM_alloc(200);
		   //   MiddleName=(char *)MEM_alloc(200);
		   //   LastName=(char *)MEM_alloc(200);
          //    ITK_CALL(AOM_UIF_ask_value(UserTag1,"status",&status));
			//  printf("\n User ID of user: %s \n",status);fflush(stdout);
			//  if(tc_strcmp(status,"1"))
			// {
			//     tc_strcpy(status1,"Active");
			// }
			// else if(tc_strcmp(status,"0"))
           //  {
			//     tc_strcpy(status1,"Inactive");
			// }
			// ITK_CALL(AOM_ask_value_string(UserTag1,"user_name",&usernameTag));
            // printf("\n Name of user: %s \n",usernameTag);fflush(stdout);
			//FirstName=tc_strtok(usernameTag," ");
			//MiddleName=tc_strtok(NULL," ");
            //LastName=tc_strtok(NULL," ");
	       //if (tc_strcmp(LastName,NULL)==0)
	       //{
           //     printf("Ihside Condition 123.........................");fflush(stdout);
           //     LastName=MiddleName;
			//	 MiddleName="";
	       //}
			//if((tc_strcmp(LastName,NULL)==0) && (tc_strcmp(MiddleName,"")==0) )
			// {
			//	 
			//     LastName="";
			// }
           //printf("\n User ID of user: %s \n",FirstName);fflush(stdout);
           //printf("\n User ID of user: %s \n",MiddleName);fflush(stdout);
           //printf("\n User ID of user: %s \n",LastName);fflush(stdout);
			////tc_strcat(FirstName," ");
			//tc_strcat(FirstName,MiddleName);
			//tc_strcat(FirstName," ");
			//tc_strcat(FirstName,LastName);

                    //    fprintf(ftr,"TcUA_id/%s\n",User_Name1); 
					//	fprintf(ftr,"Actice_Status/%s\n",status1);
					//	fprintf(ftr,"FULL_NAME/%s^\n",usernameTag);

                   

			//	if(QRY_find("Find Projects With Assigned User", &queryTag));
			//	printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
			//	if (queryTag)
			//	{
			//		printf("2.Found Query \n");fflush(stdout);
			//	}
				//else
			//	{
			//		printf("Not Found Query");fflush(stdout);
			//	}
				        //printf("\n User ID: %s",User_Name1);
				    //   qry_values[0] = User_Name1;
					   //tc_strcat(qry_values[0],"*");
					   //printf("\n User ID: %s",User_Name1);
	
	                // QRY_set_name_mode(queryTag,false);
					//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
                  //  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
			      //  printf(" \n resultCount :%d:", resultCount); fflush(stdout);
				//if(resultCount==0)
				// {
				//   fprintf(ftr,"%s\n","USERNOTFOUND"); 
				// }
				 
					//printf("\n User Name: %s",User_Name1);
				//	if(resultCount>0)
				// {


						
                        
						

//                     UserTag = rev[0];
//                       ITKCALL(AOM_ask_value_tags(UserTag,"fnd0SecurityAuditLogs",&nCRItem,&lov));
//                       printf("\n No of project : %d",nCRItem);fflush(stdout);
//					   dupproj=(char *) MEM_alloc(150);
//					   tc_strcpy(dupproj,"");

                       
				/*	  for(iChRItem=resultCount-1;iChRItem>=0;iChRItem--)
				     {
					   ProjTag=rev[iChRItem];
                       ITK_CALL(AOM_ask_value_string(ProjTag,"project_id",&Projeccode)); 
                        if(tc_strstr(Project_list,Projeccode)!=NULL)
						 {
					   printf("\nProject code Match with Given list %s",Projeccode);
						 
                        if(QRY_find("ProjectUserAccessDet", &queryTag1));
				         printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
				         if (queryTag1)
				        {
					  printf("2.Found Query \n");fflush(stdout);
				        }
				       else
				       {
					printf("Not Found Query");fflush(stdout);
				         }

						  //printf("\n%s\n",Projeccode);
						  //if(tc_strstr(dupproj,Projeccode)==NULL)
					      //{
					      //printf("\nTotal No of project %s\n",dupproj);
						  printf("\n%s\n",Projeccode);
						 
						 // tc_strcat(dupproj,Projeccode);
						  //tc_strcat(dupproj,",");
					      qry_values1[0] =Projeccode;
			              qry_values1[1] =User_Name1 ;
						 if(QRY_execute(queryTag1, n_entries1, qry_entries1, qry_values1, &resultCount1, &rev1));
			             printf(" \n resultCount :%d:", resultCount1); fflush(stdout);
						 fprintf(ftr,"\nProject code:-%s\n",Projeccode);
                       
                        for(ii=resultCount1-1;ii>=0;ii--)
				       {
                          UserTag12=rev1[ii];
                         ITK_CALL(AOM_ask_value_string(UserTag12,"object_string",&object_name));
        				 printf("\n%s\n",object_name);
					      fprintf(ftr,"%s\n",object_name);
				        }
						}
					// }

                  
				 }  
				 }
				
			 } 
			

  			 
  			 	
  			 }
    
  			
  		}
                      
                   
      }*/
			 }
             
		} 
	}
      if(fp)
      {
         fclose(fp);
         fp=NULL;
  	  }
	 // if (ftr)
	 // {
	//	  fclose(ftr);
	//	  ftr=NULL;
	//  }

	

  return ITK_ok;
}

