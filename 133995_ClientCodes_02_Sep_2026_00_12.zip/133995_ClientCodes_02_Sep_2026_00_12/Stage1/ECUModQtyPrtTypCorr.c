#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include <epm/cr_effectivity.h>
#include<ics/ics.h>
#include<ics/iman_ics.h>

#define Debug TRUE
#define ITK_CALL(X)														\
	if(Debug)															\
	{																	\
		printf(#X);														\
	}																	\
	fflush(NULL);														\
	status=X;															\
	if (status != ITK_ok )												\
	{																	\
		int				index = 0;										\
		int				n_ifails = 0;									\
		const int*		severities = 0;									\
		const int*		ifails = 0;										\
		const char**	texts = NULL;									\
																		\
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
		printf("\t%3d error(s)\n", n_ifails);							\
		for( index=0; index<n_ifails; index++)							\
		{																\
			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
		}																\
		return status;													\
	}																	\
	else																\
	{																	\
		if(Debug)														\
		printf("\tSUCCESS\n");											\
	}																	\

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
static void initialise_attribute (char *name,  int *attribute);

char	* sUsr			=   NULL;
char	* spass			=   NULL;
char	* sDB			=   NULL;
char	* sOpt			=   NULL;
char	* sRevSeq		=   NULL;
char	* sAttrName		=   NULL;
char	* sAttrVal		=   NULL;

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);
}

int setFindStr1(int *count,char ***strset,char* str)
{
	int j   =0;
	for(j=0;j<*count;j++) 
	{
		printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
		printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);
		if(tc_strcmp((*strset)[j],str)==0) //check this
		return j;
	}
	return -1;
}

static void initialise (void);

extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int iStatus=0;

	(void)argc;
	(void)argv;

	initialise();

	sUsr  = ITK_ask_cli_argument("-u=");
	spass  = ITK_ask_cli_argument("-pf=");
	sDB  = ITK_ask_cli_argument("-g=");
	sOpt  = ITK_ask_cli_argument("-i=");
	//sRevSeq = ITK_ask_cli_argument("-r=");
	//sAttrName = ITK_ask_cli_argument("-n=");
	//sAttrVal = ITK_ask_cli_argument("-v=");

	iStatus = ITK_auto_login();

	//if( ITK_init_module("ercpsup" ,"ERCpsup2019","Engineering")!=ITK_ok) ;
	if( ITK_init_module(sUsr ,spass,sDB)!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\nkk.Input Option is [%s]",sOpt); fflush(stdout);

	char	*sFrmRpl;
	char	*sToRpl;

	int		i = 0;
	int		n_Input = 1;
	int		nPrtCnt = 0;
	int		n_Cnt = 0;
	int		iPCnt = 0;
	int		bl_qty_form = 0;
	//char	*values[3];
	char	*values[1];
	//char	*qry_Input[3] = {"Item ID", "Type", "Revision"};
	char	*qry_Input[1] = {"Part Type"};
	tag_t	QryPrt = NULLTAG;
	tag_t	tPrt = NULLTAG;
	tag_t	*tpPrtObjs = NULL;

	char	*sPrtVal = NULL;
	char	*sPrtRev = NULL;
	char	*sPrtTyp = NULL;
	char	*sCPartNum = NULL;
	char	*sCPartRvSq = NULL;
	char	*sCPartQty = NULL;
	char	*FileName = NULL;

	tag_t	window = NULLTAG;
	tag_t	top_line = NULLTAG;
	tag_t	tChld = NULLTAG;
	tag_t	*children = NULLTAG;

	logical lIsQtyModified = false;

	time_t temp; 
    struct tm *timeptr; 
    char pAccessDate[30];
	char *sCurrentDate = NULL;
	char *sCurrentDateDup = NULL;
	char *strToBereplaceddate;
	char *strToBeUsedInsteaddate;

	FILE *fptr;

	sFrmRpl = (char*)malloc(5);
	sToRpl = (char*)malloc(5);
	FileName =(char *) MEM_alloc(150);
	sCurrentDate =(char *) MEM_alloc(30);
	sCurrentDateDup =(char *) MEM_alloc(30);
	strToBereplaceddate = (char*)malloc(5);
	strToBeUsedInsteaddate = (char*)malloc(5);


	
	tc_strcpy(sFrmRpl,";");
	tc_strcpy(sToRpl,"*");
	ifail =STRNG_replace_str(sRevSeq,sFrmRpl,sToRpl,&sRevSeq); 

	
	//values[0] = sPart;
	//values[1] = "EE Part Revision";
	//values[2] = sRevSeq;
	values[0] = "ECU Module";
/*
    time(&temp); 
    timeptr = localtime(&temp ); 
	tc_strcpy(pAccessDate,"");
    strftime(pAccessDate, sizeof(pAccessDate),"%x-%I_%M_%p", timeptr); 
	tc_strcpy(sCurrentDate,pAccessDate);
	tc_strcpy(strToBereplaceddate,"/");
	tc_strcpy(strToBeUsedInsteaddate,"-");

	ifail =STRNG_replace_str(sCurrentDate,strToBereplaceddate,strToBeUsedInsteaddate,&sCurrentDateDup); 
	
      
    printf("kk.Formatted date & time is : [%s]\n",sCurrentDateDup);

	tc_strcpy(FileName,"ECUModQtyUpdate_");
	tc_strcat(FileName,sCurrentDateDup);
	tc_strcat(FileName,"_log.csv");

	printf("kk.log file name is : [%s]\n",FileName);

	fptr = fopen(FileName,"w");

	if(fptr==NULL)
	{
		printf("Error! in log File opening!!!");  fflush(stdout);
		exit(1);
	}
	fprintf(fptr,"Qty Updated for below parts:");fflush(fptr);
*/



   tag_t objTag     = NULLTAG;
   char* rev_id     = NULL;
   int cnt          =0;
   tag_t * rev_list =NULLTAG;

if(tc_strstr(sOpt,"K2A0")!=NULL || tc_strstr(sOpt,"H1A1")!=NULL)
{
   printf("\n i am in Quantity and Part Type updation for K2A0 or H1A1\n");fflush(stdout);
   ITK_CALL(ITEM_find_item(sOpt,&objTag));
    ITK_CALL(ITEM_list_all_revs(objTag,&cnt,&rev_list));
        
	
		for(iPCnt=0; iPCnt<cnt; ++iPCnt)
		{
			lIsQtyModified = false;
			tPrt = rev_list[iPCnt];
			ITKCALL(AOM_ask_value_string(tPrt,"item_id",&sPrtVal));
			ITKCALL(AOM_ask_value_string(tPrt,"item_revision_id",&sPrtRev));
			ITKCALL(AOM_ask_value_string(tPrt,"t5_PartType",&sPrtTyp));
			printf("\nkk.Value is [%s,%s,%s]\n",sPrtVal,sPrtRev,sPrtTyp);fflush(stdout);

			if(tc_strcmp(sPrtTyp,"M")==0 || tc_strcmp(sPrtTyp,"")==0)
			{
			 ITKCALL(AOM_refresh(tPrt,1));
			 ITKCALL(AOM_set_value_string(tPrt,"t5_PartType","EM"));
			 ITKCALL(AOM_save(tPrt));
			 ITKCALL(AOM_refresh(tPrt,0));
			 printf("\n Part Type ECU Module of %s %s Updated.\n",sPrtVal,sPrtRev);fflush(stdout);
			
			}
			

			ifail =BOM_create_window(&window);
			ifail = BOM_set_window_top_line (window, null_tag, tPrt, null_tag, &top_line);
			CHECK_FAIL;

			ifail = BOM_window_show_suppressed ( window );
			CHECK_FAIL;

			ITK_CALL(BOM_set_window_pack_all(window, FALSE));

			ITKCALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children));
			for (i=0; i<n_Cnt; ++i)
			{
				tChld=children[i];
				//BOM_line_unpack (children[i]);
				//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
				//BOM_line_ask_attribute_tag(children[i], iChildItemTag, &t_ChildItemRev);
				//if(t_ChildItemRev!=NULLTAG)
				
				ITKCALL(AOM_ask_value_string(tChld,"bl_item_item_id",&sCPartNum));
				ITKCALL(AOM_ask_value_string(tChld,"bl_rev_item_revision_id",&sCPartRvSq));
				ITKCALL(AOM_ask_value_string(tChld,"bl_quantity",&sCPartQty));
				printf("\nChild %d [Item,Rev,Qty] [%s,%s,%s]\n",i+1,sCPartNum,sCPartRvSq,sCPartQty);fflush(stdout);
			
			   if(tc_strcmp(sCPartQty,"0")!=0)
				{
	                lIsQtyModified = true;
					
					ITK_CALL(BOM_line_look_up_attribute ("bl_quantity",&bl_qty_form));
					ITK_CALL(BOM_line_set_attribute_string(tChld,bl_qty_form,"0"));
					printf("\nkk.Value Updated.\n");fflush(stdout);
				}
			}
			if(lIsQtyModified == true)
			{
				ITK_CALL(BOM_save_window(window));
				printf("\nkk.BOM Saved.\n");fflush(stdout);
			}
		}

        }
        else
        {
         printf("\n Quantity updation only for K2A0 or H1A1\n");fflush(stdout);
        }


	ITK_exit_module(true);

	return status;
}

static void initialise (void)
{
	int ifail;

	/* <kc> pr#397778 July2595 exit if autologin() fail */
	if ((ifail = ITK_auto_login()) != ITK_ok)
	   printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
	CHECK_FAIL;

	/* these tokens come from bom_attr.h */
	initialise_attribute (bomAttr_lineName, &name_attribute);
	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	CHECK_FAIL;
	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	CHECK_FAIL;
}

static void initialise_attribute (char *name,  int *attribute)
{
	int ifail, mode;

	ifail = BOM_line_look_up_attribute (name, attribute);
	CHECK_FAIL;
	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	CHECK_FAIL;
	if (mode != BOM_attribute_mode_string)
	{
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode); fflush(stdout);
		exit(0);
	}
}

