#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <ps/ps.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <ae/datasettype.h>
#include <ae/dataset.h>
#include <sa/tcfile.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#include <tcinit/tcinit.h>
#include <ae/ae.h>
#include <sa/tcfile_cache.h>
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
int ifail = ITK_ok;
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
        printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
    }
    return ITK_ok;
}

int ITK_user_main(int argc, char *argv[])
{  
	char *username	= NULL;
	char *password	= NULL;
	char *group 	= NULL;
	char *file      =	NULL;
	int status              = ITK_ok;
	
	ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	ifail = ITK_auto_login( );

	if(ifail==0)
	{
		printf("\nLogin Successfully to Teamcenter!!!!!!!!\n");
	}
	ifail = ITK_set_journalling(TRUE);

	username      = ITK_ask_cli_argument("-u=");
	password      = ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
	
	
	
	//ifail = read_value_from_file(file);
	printf("\n Calling ChecklistRegister\n");fflush(stdout);
	ifail = ChecklistRegister(file);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
int ChecklistRegister(char *File)
{
		
	int result=0;
	int ref_count;
	int SysReturn = NULL;

	char *vehicleFile = NULL;
	char *FinalvehicleFile = NULL;
	char *datesetNam = NULL;
	char *datesetNamTemp = NULL;
	char *filepath = NULL;
	

	char **ref_list;
	char *commandd =NULL ;
	char *command =NULL ;
	char* token =NULL;
	char* token1 =NULL;

	
	tag_t DCRTag=NULLTAG;
	tag_t DCRREVTag=NULLTAG;
	tag_t pdfDataset=NULLTAG;
	tag_t latestDataset=NULLTAG;
	tag_t Report_Relation=NULLTAG;
	tag_t relation_type=NULLTAG;
	tag_t specRelationType_t=NULLTAG;
	tag_t PLMSession=NULLTAG;
	char docFile[300];
	char temp[300000];

	char * pdf = NULL;
	char * vehicle = NULL;
	char * vehicle1 = NULL;
	char * vehicle2 = NULL;
	pdf = "PDF";

		
		datesetNam = (char *) MEM_alloc (sizeof (char) * 500);
		datesetNamTemp = (char *) MEM_alloc (sizeof (char) * 500);
		filepath = (char *) MEM_alloc (sizeof (char) * 300);
		token1 = (char *) MEM_alloc (sizeof (char) * 300);
		command = (char *) MEM_alloc (sizeof (char) * 500);
		
		FILE* fp = NULL;
		fp = fopen(File, "r");

		if (fp != NULL)
		{
			while (fgets(temp, 1024, fp)!= NULL)
			{
				tc_strcpy(temp,stripBlanks(temp));

				if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
				{
					token = tc_strtok(temp, ",");
					tc_strcpy(token,stripBlanks(token));
					printf("\nToken :%s",token);fflush(stdout);
					
					
					token1= tc_strtok(NULL, ",");
					//tc_strcpy(token1,stripBlanks(token1));
					printf("\n Token 1:%s\n",token1);fflush(stdout);

					printf("\n vehicle checklist function started:\n");fflush(stdout);	
					sprintf(command,"/user/cvprod/Program_Shells/DML_Support/Pfirst_PDF/Pfirstpdf.sh %s ",token1);

					printf("\n commandd:%s ",command);fflush(stdout);

					SysReturn = system(command);
					printf("\n command:%s ",command);fflush(stdout);
					
					printf("Creating dataset for storing the Text File ");fflush(stdout);

					IMF_file_t fileDescriptor;
					AE_reference_type_t tagRefType =  1;
					tag_t tool =  NULLTAG;
					tag_t filetag =  NULLTAG;
					tag_t PdfDataset =  NULLTAG;
					tag_t pdfType=NULLTAG;
					
					tag_t specificationRel_t =  NULLTAG;
					tag_t PdfLatestDat_t =  NULLTAG;
					tc_strcpy(datesetNam, "");
					tc_strcpy(datesetNamTemp, "");
					
					
					
					tc_strcat(datesetNam,"");
					tc_strcat(datesetNam,token1);
					
					
					if(STRNG_replace_str(datesetNam, ";", "_", &datesetNamTemp)!=ITK_ok)PrintErrorStack();
					

					printf("\n datesetNamTemp: [%s] ",datesetNamTemp); fflush(stdout);
					tc_strcpy(filepath,"PLM_DATA/PROD/2290/GEN4_PDF_PLM");
					tc_strcat(filepath,datesetNamTemp);

					printf("\n finding the Dataset Type PDF.");fflush(stdout);
					if(AE_find_datasettype2("PDF",&pdfType)!=ITK_ok)PrintErrorStack();
					
					if(pdfType == NULLTAG)
					{
						//TC_write_syslog("Could not find Dataset Type PDF. Please check data model\n");
						printf("\n Could not find Dataset Type PDF.");fflush(stdout);
						//continue;
					}
					if(AE_create_dataset_with_id(pdfType,datesetNamTemp,"ChecklistPDF","","",&pdfDataset)!=ITK_ok)PrintErrorStack();
					printf("\n L14:create dataset done..");fflush(stdout);
					//if(AE_create_dataset_with_id(msWordType,dmlNumber,"DML Release Report for DML","","",&pdfDataset)!=ITK_ok)PrintErrorStack();
					if(AE_save_myself(pdfDataset));
					printf(" and saved\n.");fflush(stdout);
					//if(AOM_load(Report_Relation)!=ITK_ok)PrintErrorStack();
					//printf("\n and load.\n");fflush(stdout);
					//if(GRM_save_relation(Report_Relation)!=ITK_ok)PrintErrorStack();
					//printf("\n and saved.\n.");fflush(stdout);
					if(AE_ask_dataset_latest_rev(pdfDataset,&latestDataset));
					printf("\n L16:get dataset_latest_rev..\n");fflush(stdout);
					if(AOM_lock(latestDataset)!=ITK_ok)PrintErrorStack();
					printf("\n and refreshed..\n");fflush(stdout);
					//if(AE_import_named_ref(latestDataset,"word",docFile,NULL,SS_BINARY)!=ITK_ok)PrintErrorStack();
					if(AE_import_named_ref(latestDataset,"PDF_Reference",filepath,NULL,SS_BINARY)!=ITK_ok)PrintErrorStack();
					printf("\n L17:Import data..");fflush(stdout);
					AOM_save(latestDataset);
					printf("\n and save dataset..");fflush(stdout);
					AOM_refresh(latestDataset, FALSE);
					printf("\n 2.and save dataset..");fflush(stdout);
					AOM_unload(latestDataset);
					printf("\n 3.and save dataset..");fflush(stdout);
					
					//Mmmmmmmmmmmmmmmmmmmmmmmmmmm
				
				}
				tc_strcpy(token1, "");
				tc_strcpy(temp, "");
			}
		}
	
}




