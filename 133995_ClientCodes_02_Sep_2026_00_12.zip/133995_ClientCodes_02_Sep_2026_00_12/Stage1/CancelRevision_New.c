#include <time.h>
#include <stdio.h>
//#include <tc/tc.h> 
#include <stdlib.h>
#include <tc/emh.h>
//#include <bom/bom.h> 
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
//#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string; 
        EMH_ask_error_text(return_code, &error_msg_string); 
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}



#define PROP_UIF_set_value_msg		"PROP_UIF_set_value" 
#define PROP_set_value_tag_msg		"PROP_set_value_tag" 
#define PROP_set_value_string_msg   "PROP_set_value_string"  

FILE 		*output 			= NULL;

char		*sep				= ",";

int read_value_from_file(char*);
int update_attr(char*, char*);
int write_info(char*, char*, char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -item_id=<filename> (required)\n"
        " -rev=<filename> (required)\n"
        );	
}
static int PrintErrorStack(tag_t Error_tag )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;
    int count=0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   // fprintf( stderr, "Error(PrintErrorStack): \n");
    printf("Error(PrintErrorStack):");
    for ( i = 0; i < iNumErrs; i++ )
    {
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
        printf("\n%6d: %s", pErrCdeLst[i], pMsgLst[i] );
        count++;
		
    }
	if(count==iNumErrs && count>0)
	{
    exit(1);
	} 
	return ITK_ok;
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* item_id					= NULL;
	char			* rev						= NULL;
	char			Data[100]					= "";
	char             *msg                       =NULL;
	char 			*test						= (char*)MEM_alloc(sizeof(char) * 50);
	char			outputFile[200]				= "";
	int				ifail 						= ITK_ok;
	int				r_count 					= 0;
	int				count 						= 0;
	int				countR	 					= 0;
	int				i		 					= 0;
	int				revloop	 					= 0;
	int				revloopR 					= 0;
		
	tag_t			item_tag 					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	tag_t			relation_type				= NULLTAG;
	tag_t			relation_typeR				= NULLTAG;
	tag_t			*secondary_objects			= NULLTAG;
	tag_t			*secondary_objectsR			= NULLTAG;
	
	char 			*prt_type					= NULL;
	char 			*p_status					= NULL;
	char 			*type						= "Module";
	char 			*rev_id						= NULL;
	char 			*data_set					= NULL;
	char 			*data_setR					= NULL;
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	item_id 		= ITK_ask_cli_argument("-item_id=");
	rev				= ITK_ask_cli_argument("-rev=");
	
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.csv",Data);
	
	
//	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
//	{
//		print_requirement();
//		return -1;
//	}
	
	
	//ifail = ITK_init_module(userid, password, group);
	ifail =	 (ITK_auto_login( ));
	ifail =(ITK_set_journalling( TRUE ));
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
//	ifail = ITK_set_bypass(true);
//    if (ifail != ITK_ok)
//	{
//		printf("\nUser is not Privileged Admin User \n\n");
//		return -1;
//	}
	
	//ifail = ITK_set_bypass(TRUE);
	//ITK_CALL(update_attr(item_id,rev));
		ifail = (ITEM_find_rev(item_id,rev,&rev_tag));	
	if(ifail != ITK_ok)
	{
		printf("Object not found in Teamcenter...!!\n");
		fprintf(output,"%s", sep);
		fprintf(output,"Not Found\n");
		return 0;
	}
	else
	{
		printf("Object Found...!!\n");
	}
	printf("\n\n After Object found\n");
	//ITK_CALL(ITK_set_bypass(TRUE));

	ITK_CALL(GRM_find_relation_type("IMAN_specification",&relation_type));

	ITK_CALL(GRM_list_secondary_objects_only(rev_tag,relation_type,&count,&secondary_objects));

	if(count>0)
	{
	for (revloop=0;revloop<count; revloop++)
	{

       
        ITK_CALL(AOM_ask_value_string(secondary_objects[revloop],"object_name",&data_set));
		printf("Data set Name of IMAN_specification %s\n",data_set);
		if(tc_strstr(data_set,item_id)!=NULL)
		{
		printf("Before dataset Loop for Specification\n");  
		ITK_CALL(AOM_refresh	(secondary_objects[revloop],0));	
		ITK_CALL(AOM_lock_for_delete(secondary_objects[revloop]));
		ITK_CALL(AOM_delete_from_parent(secondary_objects[revloop],rev_tag));	
		printf("After dataset Loop for Specification\n");
		}
	}
	}

	ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&relation_typeR));

	ITK_CALL(GRM_list_secondary_objects_only(rev_tag,relation_typeR,&countR,&secondary_objectsR));

	if(countR>0)
	{
	for (revloopR=0;revloopR<countR; revloopR++)
	{	
		ITK_CALL(AOM_ask_value_string(secondary_objectsR[revloopR],"object_name",&data_setR)); 
		printf("Data set Name of IMAN_Rendering %s\n",data_setR);
		if(tc_strstr(data_setR,item_id)!=NULL)
		{
		printf("Before dataset Loop for Specification\n");
		printf("Before dataset Loop for Rendering\n");
		if(ITK_CALL(AOM_refresh	(secondary_objectsR[revloopR],0))!=ITK_ok);	
		if(ITK_CALL(AOM_lock_for_delete(secondary_objectsR[revloopR]))!=ITK_ok);
		if(ITK_CALL(AOM_delete_from_parent(secondary_objectsR[revloopR],rev_tag))!=ITK_ok);	
		printf("After dataset Loop for Rendering\n");
		}
	}  
	}
	//else
	//{
	//	EMH_ask_error_text(ifail,&msg);
	//	printf("\n\n%s\n\n",msg);
	//}
	printf("Related datasets deleted \n");

	printf("Before AOM_refresh \n");
	//ITK_CALL(AOM_refresh(rev_tag,0));
	printf("After AOM_refresh \n");

	printf("Before  AOM_load\n");
	if(ITK_CALL(AOM_load(rev_tag))!=ITK_ok);PrintErrorStack(rev_tag);	
	printf("After AOM_load\n");
	printf("Before AOM_delete \n");
	//ITK_CALL(ITK_set_bypass(TRUE));
	ifail=ITK_CALL(AOM_delete(rev_tag));PrintErrorStack(rev_tag);
	//EMH_ask_error_text(ifail,&msg);
	//printf("\n\n%s\n\n\n\n%d",msg,ifail);
	printf("After AOM_deleted \n");
	printf("Design revision deleted \n");
	MEM_free(rev_id);
	MEM_free(prt_type);
	printf("\nEnd of program.....!!\n\n");
	printf("\n*****************************\n");
	//ifail = ITK_exit_module(true);
	ITK_CALL(POM_logout(false));
	return ifail; 
}


/********************************************************************************************
    Function:       write_info
    Description:    This function takes rev_id and attr_value as input and write it into
					the file.(newly created)
********************************************************************************************/
int write_info(char* item_id, char* rev_id, char* attr_value)
{
	int			ifail 				= ITK_ok;
	
	char 		*test2 				= (char*)MEM_alloc(sizeof(char) * 50);
	char		*final2				= (char*)MEM_alloc(sizeof(char) * 50);

		tc_strcpy(test2, "");
		tc_strcpy(test2,item_id);
		tc_strcat(test2,sep);
		tc_strcat(test2,rev_id);
		tc_strcat(test2,sep);
		tc_strcat(test2,attr_value);
		
		tc_strcpy(final2,test2);
		
		fprintf(output,"%s\n",final2);
	
		MEM_free(test2);	
		MEM_free(final2);	
		return ifail;
}
