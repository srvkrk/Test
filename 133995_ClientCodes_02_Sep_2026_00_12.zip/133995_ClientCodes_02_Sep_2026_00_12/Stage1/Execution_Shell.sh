######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : JULY-2023
#
#######################################################################################

echo -e "\n~~~~~~~~~~ S H E L L   S T A R T E D ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "SVR: -----> "$1

echo "Revision Rule: -----> "$2

echo "Platform Name: -----> "$3

echo "VC: -----> "$4

echo "Report Date: -----> "$5

echo "User Email: -----> "$6

echo "UnSorted Solved SVR BOM Rpt File: -----> "$7

echo "Sorted Solved SVR BOM Rpt File: -----> "$8

echo "Solved SVR BOM Rpt File: -----> "$9

echo "Standalone VC BOM Rpt File: -----> "${10}

echo "Unsorted Final Rpt File: -----> "${11}

echo "Sorted Final Rpt File: -----> "${12}

echo "Pre Final Report File: -----> "${13}

echo "Report File: -----> "${14}

echo "VC Rev: -----> "${15}

echo "VC Seq: -----> "${16}

echo -e "\nIn Shell Argument Print Ended...."

echo -e "\nConcatination VC Rev & Seq with VC Start...."

vcrev=${15}
vcseq=${16}
fvc=$4/$vcrev/$vcseq
echo "Vehicle Final Rev & Seq: -----> "$fvc

echo -e "\nConcatination VC Rev & Seq with VC End...."

echo -e "\nUnSorted Solved SVR BOM Rpt File Sort Started...."
sort -u $7 -o $8
echo -e "\nUnSorted Solved SVR BOM Rpt File Sort Ended...."
echo -e "\nConsolidated Solved SVR BOM Rpt File Generation Started...."
while read l_line
do
    x=`echo $l_line |awk -F',' '{print $1}'`
	y=`echo $l_line |awk -F',' '{print $2}'`
	y=${y//$'\n'/}
	y=${y%$'\n'}
	y=`echo ${y} | tr -d '\n'`
	MainL="$x","$y"
	FindMod=`echo $(grep -o -i $x $7 | wc -l)`
	if [ -z $FindMod ]
	then
	     echo "Test"
    else
	     ans=`expr $y \* $FindMod`
		 echo "$x,$ans," >> $9
	fi
	
done < $8

echo -e "\nConsolidated Solved SVR BOM Rpt File Generation Ended...."
echo -e "\nUnsorted Final Rpt File Sort Started...."
unsfr=${11}
sfr=${12}
sort -u $unsfr -o $sfr
echo -e "\nUnsorted Final Rpt File Sort Ended...."
stdvc=${10}
pfrpt=${13}
frpt=${14}
echo -e "\nPre Final Report Generation Started...."

while read l_line
do
ftl=`echo $l_line |awk -F',' '{print $1}'`
nftl=`echo $l_line |awk -F',' '{print $2}'`
stl=`echo $l_line |awk -F',' '{print $3}'`
stl=${stl//$'\n'/}
stl=${stl%$'\n'}
stl=`echo ${stl} | tr -d '\n'`
ML="$ftl","$nftl","$stl"
FM=`echo $(grep -n $stl $9 | cut -d : -f 1)`
    if [ -z $FM ]
	then
	     fq="0"
		 echo "$ftl,$nftl,$stl,$fq," >> $pfrpt
	else
	     PreStr=`sed -n "${FM},${FM}p"  $9`
		 pref=`echo $PreStr |awk -F',' '{print $1}'`
		 npref=`echo $PreStr |awk -F',' '{print $2}'`
		 npref=${npref//$'\n'/}
		 npref=${npref%$'\n'}
		 npref=`echo ${npref} | tr -d '\n'`
		 echo "$ftl,$nftl,$stl,$npref," >> $pfrpt
	fi
	
done < $sfr

echo -e "\nPre Final Report Generation Ended...."
echo -e "\nMain Shell Execution Started...."
echo "@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@" >> $frpt
echo ",,,SVR Name: " $1 >> $frpt
echo ",,,Revision Rule: " $2 >> $frpt
echo ",,,Platform Name: " $3 >> $frpt
echo ",,,Standalone VC: " $fvc >> $frpt
echo ",,,Report Date: " $5 >> $frpt
echo "@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@" >> $frpt
frtLine=`echo Submodule Address,Submodule Description,Submodule No,Count of Submodule in Solved VC,Count of Submodule in Standalone VC,Category`

echo $frtLine >> $frpt

while read l_line
do
a=`echo $l_line |awk -F',' '{print $1}'`
desp=`echo $l_line |awk -F',' '{print $2}'`
b=`echo $l_line |awk -F',' '{print $3}'`
c=`echo $l_line |awk -F',' '{print $4}'`
c=${c//$'\n'/}
c=${c%$'\n'}
c=`echo ${c} | tr -d '\n'`
MainLine="$a","$desp","$b","$c"
FindModule=`echo $(grep -n $b $stdvc | cut -d : -f 1)`
    if [ -z $FindModule ]
	then
	     e="0"
		 zr="0"
		 if [[ ($c -gt $zr && $e -gt $zr) && ($c -eq $e || $e -eq $c) ]] ; then
            echo "$a,$desp,$b,$c,$e,OK" >> $frpt
		 elif [[ ($c -gt $zr && $e -gt $zr) && ($c -gt $e || $e -gt $c) ]] ; then
		    echo "$a,$desp,$b,$c,$e,Quantity Mismatch" >> $frpt
		 elif [[ $c -eq $zr && $e -gt $zr ]] ; then
		    echo "$a,$desp,$b,$c,$e,Required Submodule Not Present" >> $frpt
		 elif [[ $c -gt $zr && $e -eq $zr ]] ; then
		    echo "$a,$desp,$b,$c,$e,Extra Submodule Present" >> $frpt
		 else
		    echo "$a,$desp,$b,$c,$e,Rule Undefined" >> $frpt
         fi
    else
	     tempStr=`sed -n "${FindModule},${FindModule}p"  $stdvc`
		 d=`echo $tempStr |awk -F',' '{print $1}'`
		 e=`echo $tempStr |awk -F',' '{print $2}'`
		 e=${e//$'\n'/}
		 e=${e%$'\n'}
		 e=`echo ${e} | tr -d '\n'`
		 #f=`expr $c - 0`
		 #echo "Hellow1"
		 #echo $f
		 zr="0"
		 if [[ ($c -gt $zr && $e -gt $zr) && ($c -eq $e || $e -eq $c) ]] ; then
		    echo "$a,$desp,$b,$c,$e,OK" >> $frpt
		 elif [[ ($c -gt $zr && $e -gt $zr) && ($c -gt $e || $e -gt $c) ]] ; then
		    echo "$a,$desp,$b,$c,$e,Quantity Mismatch" >> $frpt
		 elif [[ $c -eq $zr && $e -gt $zr ]] ; then
		    echo "$a,$desp,$b,$c,$e,Required Submodule Not Present" >> $frpt
		 elif [[ $c -gt $zr && $e -eq $zr ]] ; then
		    echo "$a,$desp,$b,$c,$e,Extra Submodule Present" >> $frpt
		 else
		    echo "$a,$desp,$b,$c,$e,Rule Undefined" >> $frpt
		 fi
	fi
	
done < $pfrpt

echo "@@@@@@,@@@@@@,@@@@@@,@@@@@@,E N D   O F   R E P O R T,@@@@@@,@@@@@@,@@@@@@,@@@@@@" >> $frpt
echo -e "\nMain Shell Execution Ended...."
echo -e "\nReport Send To User Email Started...."
ls -lrt $frpt
if [ $? == 0 ]
      then
        echo "File Successfully Found on Server"
        echo "Sending Solved BOM VS Standalone VC BOM Report To User Email"
        echo -e "Dear All, \n\n                Please Check Attached Solved BOM VS Standalone VC BOM Report.\n                Report Details.\n                SVR: $1\n                Revision Rule: $2\n                Platform Name: $3\n                VC: $4\n                Report Date: $5\n                Users Email: $6\n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM." |Mail -s "SUCCESS : Solved BOM VS Standalone VC BOM Report" -a $frpt $6 souravk.ttl@tatamotors.com
      else
        echo "File NOT Foud on server"
        echo "Sending Solved BOM VS Standalone VC BOM Report To Developer Email"
        echo -e "Dear Team, \n\n                There is Some Issue in Solved BOM VS Standalone VC BOM Report Generation.\n                Please Check Log & Support User.\n                Report Details.\n                SVR: $1\n                Revision Rule: $2\n                Platform Name: $3\n                VC: $4\n                Report Date: $5\n                Users Email: $6\n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED : Solved BOM VS Standalone VC BOM Report" souravk.ttl@tatamotors.com
fi
echo -e "\nReport Send To User Email Ended...."
echo -e "\n~~~~~~~~~~ S H E L L   E N D E D ~~~~~~~~~~~~"