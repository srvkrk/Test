#include <stdlib.h>
#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <vm/vms.h>
#include <tc/emh.h>
#include <pom/pom/pom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <fclasses/tc_string.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/tctype.h>
#include <form/form.h>
#include <epm/cr.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <tccore/idcxt.h>
#include <tccore/idfr.h>
#include <tccore/idcxt_errors.h>
#include <tccore/part.h>
#include <tccore/tctype.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#include <tcinit/tcinit.h>
#include <ae/ae.h>
#include <sa/tcfile_cache.h>
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
int ifail = ITK_ok;
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
        printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
    }
    return ITK_ok;
}
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{
	*count=*count+1;
	if(*count==1)
	{
	(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	}
	else
	{
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));

}
int ITK_user_main(int argc, char *argv[])
{
	char *dcr_no  = NULL;
	char *username = NULL;
	char *password = NULL;
	char*  design_group	= NULL;
	char *Affected_design_groups = NULL;
	char *token = NULL;

	char **Affected_design_groupsList =NULL;
	char **designGrp =NULL;
	tag_t DCRREVTag= NULLTAG;
	tag_t rev_tag= NULLTAG;
	tag_t TagClassId = NULLTAG;
	tag_t designgrouplov = NULLTAG;
	tag_t value = NULLTAG;
	char *ObjClassName=NULL;
	char **DesignGroupList=NULL;
	char **designgroup=NULL;


	
	int status              = ITK_ok;
	int num              = 0;
	int position              = 0;
	int num_values;

	ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	ifail = ITK_auto_login( );

	if(ifail==0)
	{
		printf("\nLogin Successfully to Teamcenter!!!!!!!!\n");
	}
	ifail = ITK_set_journalling(TRUE);

	username      = ITK_ask_cli_argument("-u=");
	password      = ITK_ask_cli_argument("-pf=");
	dcr_no  = ITK_ask_cli_argument("-dcrno=");
	Affected_design_groups  = ITK_ask_cli_argument("-desgrp=");


	
	ifail = ITEM_find_item (dcr_no, &DCRREVTag);
	ifail = ITEM_ask_latest_rev (DCRREVTag, &rev_tag);
		
	printf("\n To set the DCR design group...");fflush(stdout);
		
	if (rev_tag!=NULLTAG)
	{
		if(POM_class_of_instance(rev_tag,&TagClassId));
		if(POM_name_of_class(TagClassId,&ObjClassName));
		printf("\n ObjClassName: %s",ObjClassName);

		if(AOM_ask_displayable_values(rev_tag,"t5_DcrDesgGrp",&num_values,&designgroup)!=ITK_ok);

		printf("\n values count for less than value 1: %d",num_values);

		printf("\n designgroup is :%s\n",designgroup);fflush(stdout);
	   if (num_values>0)
	   {
		   //num_values++;
			
			position = 0;
			printf("\n Position is ::  %d",position);

			if (tc_strcmp(ObjClassName,"T5_DChangeReportRevision")==0)
			{
				ITK_CALL(AOM_lock(rev_tag));

				printf("\n object ready to set value ");fflush(stdout);
				ITK_CALL(AOM_set_value_string_at(rev_tag,"t5_DcrDesgGrp",num_values,design_group));

				ITK_CALL(AOM_save_without_extensions(rev_tag));

				ITK_CALL(AOM_refresh(rev_tag,0));

				ITK_CALL(AOM_ask_value_strings(rev_tag,"t5_DcrDesgGrp",&num,&DesignGroupList));

				printf("\n Replaced value of  designgroup is : %d \n", num);
			}
		}
		MEM_free(designgroup);
	}
}