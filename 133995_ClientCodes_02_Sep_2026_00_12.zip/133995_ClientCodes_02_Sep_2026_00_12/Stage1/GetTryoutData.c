/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File				:   GetESData.c
*  Author			:   Dhanashri Shirsath
*  Module			:   TCUA Downloader.
*  Purpose			:   To get Estimate Sheet for migration to TCUA
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
//#include <ReadFile.h>
#include <tel.h>
#include <Mtimsgh.h>
#define NUMBER 5000

char* ChangeDateFormat(char*,  char*,  char*, char *, char *);
char* subString(char* ,int ,int);
char * itoa (int value, char *result, int base);

status GetTryoutInfo(ObjectPtr TCPartObjP,FILE* fp,integer* mfail )
{
	string AffshopsDup=NULL;
	string Affshops=NULL;
	string TryOutNoDup=NULL;
	string TryOutNo=NULL;
	string Aggregate=NULL;
	string AggregateDup=NULL;
	string Block=NULL;
	string BlockDup=NULL;
	
	//ObjectPtr		genContextObj	= NULL;
	
	//SetOfObjects	aplExpObj		= NULL;

	t5MethodInit("GetESInfo");

	printf("\n Calling GetESInfo......");fflush(stdout);

	if(dstat=objGetAttribute(TCPartObjP,"t5Affshops",&Affshops))goto EXIT;
	if(!nlsIsStrNull(Affshops))AffshopsDup=nlsStrDup(Affshops);
	printf("\n AffshopsDup :%s",AffshopsDup);fflush(stdout);
	if(!nlsIsStrNull(AffshopsDup))
	{
		nlsStrTrimTrailWhiteSpace(AffshopsDup);
		if(nlsStrStr(AffshopsDup,"\n")!= NULL)
		{
			if(nlsStrStr(AffshopsDup,"\n")!= NULL) low_strrpl(AffshopsDup,'\n',';');
			printf("\n After Remove AffshopsDup==>[%s]\n",AffshopsDup);fflush(stdout);
		}
	}


	if(dstat=objGetAttribute(TCPartObjP,"t5TOTryOutNo",&TryOutNo))goto EXIT;
	if(!nlsIsStrNull(TryOutNo))TryOutNoDup=nlsStrDup(TryOutNo);
	printf("\n TryOutNoDup :%s",TryOutNoDup);fflush(stdout);
	if(!nlsIsStrNull(TryOutNoDup))
	{
		nlsStrTrimTrailWhiteSpace(TryOutNoDup);
		if(nlsStrStr(TryOutNoDup,"\n")!= NULL)
		{
			if(nlsStrStr(TryOutNoDup,"\n")!= NULL) low_strrpl(TryOutNoDup,'\n',';');
			printf("\n After Remove TryOutNoDup==>[%s]\n",TryOutNoDup);fflush(stdout);
		}
	}



	if(dstat=objGetAttribute(TCPartObjP,"t5Aggregate",&Aggregate))goto EXIT;
	if(!nlsIsStrNull(Aggregate))AggregateDup=nlsStrDup(Aggregate);
	printf("\n AggregateDup :%s",AggregateDup);fflush(stdout);
	if(!nlsIsStrNull(AggregateDup))
	{
		nlsStrTrimTrailWhiteSpace(AggregateDup);
		if(nlsStrStr(AggregateDup,"\n")!= NULL)
		{
			if(nlsStrStr(AggregateDup,"\n")!= NULL) low_strrpl(AggregateDup,'\n',';');
			printf("\n After Remove AggregateDup==>[%s]\n",AggregateDup);fflush(stdout);
		}
	}

	if(dstat=objGetAttribute(TCPartObjP,"t5Block",&Block))goto EXIT;
	if(!nlsIsStrNull(Block))BlockDup=nlsStrDup(Block);
	printf("\n BlockDup :%s",BlockDup);fflush(stdout);
	if(!nlsIsStrNull(BlockDup))
	{
		nlsStrTrimTrailWhiteSpace(BlockDup);
		if(nlsStrStr(BlockDup,"\n")!= NULL)
		{
			if(nlsStrStr(BlockDup,"\n")!= NULL) low_strrpl(BlockDup,'\n',';');
			printf("\n After Remove BlockDup==>[%s]\n",BlockDup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TryOutNoDup))
		{
			fprintf(fp,"%s",TryOutNoDup);			//PARTNUMBER;								
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


		if(!nlsIsStrNull(AffshopsDup))
		{
			fprintf(fp,"%s",AffshopsDup);			//PARTNUMBER;								
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


		if(!nlsIsStrNull(AggregateDup))
		{
			fprintf(fp,"%s",AggregateDup);			//PARTNUMBER;								
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


		if(!nlsIsStrNull(BlockDup))
		{
			fprintf(fp,"%s",BlockDup);			//PARTNUMBER;								
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string Plant=NULL;
	string PlantDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5Plant",&Plant))goto EXIT;
	if(!nlsIsStrNull(Plant)) PlantDup=nlsStrDup(Plant);	
	printf("\n PlantDup :%s",PlantDup);fflush(stdout);
	if(!nlsIsStrNull(PlantDup))
	{
		nlsStrTrimTrailWhiteSpace(PlantDup);
		if(nlsStrStr(PlantDup,"\n")!= NULL)
		{
			if(nlsStrStr(PlantDup,"\n")!= NULL) low_strrpl(PlantDup,'\n',';');
			printf("\n After Remove PlantDup==>[%s]\n",PlantDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PlantDup))		
		{
			fprintf(fp,"%s",PlantDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



string Area=NULL;
string AreaDup=NULL;
string Mod_value1=NULL;
ObjectPtr orgObj=NULL;
int AreaList=0;
int g=0;
int areacount=0;
if(dstat = objNameValueSize(TCPartObjP, "t5TOArea",&AreaList)) goto EXIT;
if(dstat = objCopy(&orgObj,TCPartObjP)) goto EXIT;
printf("\n AreaList  ...%d",AreaList);fflush(stdout);

if(AreaList>0)
	{
	AreaDup = (char *)calloc(AreaList,  sizeof(char));
	nlsStrCpy(AreaDup, "");
	}
	for(g=0;g<AreaList;g++)
	{
	if(Area) Area=NULL;
	if(Mod_value1) Mod_value1=NULL;
	if(dstat = objNameValueGet_byi(orgObj,t5TOAreaAttr,g,&Area,&Mod_value1)) goto EXIT;
	  printf("\n Mod_value1: %s",Mod_value1);fflush(stdout);

		if(nlsStrCmp(Mod_value1,"+")== 0)
		{
		  printf("\n ...Area Selected ...%s %s",Area,Mod_value1);fflush(stdout);

			if(!nlsIsStrNull(Area))
			{
				nlsStrTrimTrailWhiteSpace(Area);
				if(nlsStrStr(Area,"\n")!= NULL)
				{
					if(nlsStrStr(Area,"\n")!= NULL) low_strrpl(Area,'\n',';');
					printf("\n After Remove Area==>[%s]\n",Area);fflush(stdout);
				}

				nlsStrCat(AreaDup,Area);
				nlsStrCat(AreaDup,"#");
				areacount++;
			}
		}

	}

			
	printf("\n AreaDup ==>[%s]\n",AreaDup);fflush(stdout);
	printf("\n areacount ==>[%d]\n",areacount);fflush(stdout);

	//nlsStrCat(AreaDup,"#");
	char Strareacount[10];
	itoa(areacount,Strareacount,10);
	printf("\n Strareacount==>[%s]\n",Strareacount);fflush(stdout);

	//nlsStrCat(AreaDup,Strareacount);

	if(!nlsIsStrNull(AreaDup))		
	{
		fprintf(fp,"%s",AreaDup);
		fprintf(fp,"^");
	}
	else
	{
		fprintf(fp," ^");
	}


		if(!nlsIsStrNull(Strareacount))		
		{
			fprintf(fp,"%s",Strareacount);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string BatchSize=NULL;
	string BatchSizeDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOBatchSize",&BatchSize))goto EXIT;
	if(!nlsIsStrNull(BatchSize)) BatchSizeDup=nlsStrDup(BatchSize);
	printf("\n BatchSizeDup :%s",BatchSizeDup);fflush(stdout);
	if(!nlsIsStrNull(BatchSizeDup))
	{
		nlsStrTrimTrailWhiteSpace(BatchSizeDup);
		if(nlsStrStr(BatchSizeDup,"\n")!= NULL)
		{
			if(nlsStrStr(BatchSizeDup,"\n")!= NULL) low_strrpl(BatchSizeDup,'\n',';');
			printf("\n After Remove BatchSizeDup==>[%s]\n",BatchSizeDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(BatchSizeDup))		
		{
			fprintf(fp,"%s",BatchSizeDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ChnclBy=NULL;
	string ChnclByDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOChnclBy",&ChnclBy))goto EXIT;
	if(!nlsIsStrNull(ChnclBy)) ChnclByDup=nlsStrDup(ChnclBy);
	printf("\n ChnclByDup :%s",ChnclByDup);fflush(stdout);
	if(!nlsIsStrNull(ChnclByDup))
	{
		nlsStrTrimTrailWhiteSpace(ChnclByDup);
		if(nlsStrStr(ChnclByDup,"\n")!= NULL)
		{
			if(nlsStrStr(ChnclByDup,"\n")!= NULL) low_strrpl(ChnclByDup,'\n',';');
			printf("\n After Remove ChnclByDup==>[%s]\n",ChnclByDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ChnclByDup))		
		{
			fprintf(fp,"%s",ChnclByDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string Chnclcomments=NULL;
	string ChnclcommentsDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOChnclcomments",&Chnclcomments))goto EXIT;
	if(!nlsIsStrNull(Chnclcomments)) ChnclcommentsDup=nlsStrDup(Chnclcomments);
	printf("\n ChnclcommentsDup :%s",ChnclcommentsDup);fflush(stdout);
	if(!nlsIsStrNull(ChnclcommentsDup))
	{
		nlsStrTrimTrailWhiteSpace(ChnclcommentsDup);
		if(nlsStrStr(ChnclcommentsDup,"\n")!= NULL)
		{
			if(nlsStrStr(ChnclcommentsDup,"\n")!= NULL) low_strrpl(ChnclcommentsDup,'\n',';');
			printf("\n After Remove ChnclcommentsDup==>[%s]\n",ChnclcommentsDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ChnclcommentsDup))		
		{
			fprintf(fp,"%s",ChnclcommentsDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}

	string ClnclDt=NULL;
	string ClnclDtDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOClnclDt",&ClnclDt))goto EXIT;  //DATE
	if(!nlsIsStrNull(ClnclDt)) ClnclDtDup=nlsStrDup(ClnclDt);
	printf("\n ClnclDtDup :%s",ClnclDtDup);fflush(stdout);
	if(!nlsIsStrNull(ClnclDtDup))
	{
		nlsStrTrimTrailWhiteSpace(ClnclDtDup);
		if(nlsStrStr(ClnclDtDup,"\n")!= NULL)
		{
			if(nlsStrStr(ClnclDtDup,"\n")!= NULL) low_strrpl(ClnclDtDup,'\n',';');
			printf("\n After Remove ClnclDtDup==>[%s]\n",ClnclDtDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ClnclDtDup))		
		{
			fprintf(fp,"%s",ClnclDtDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string Crecomments=NULL;
	string CrecommentsDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOCrecomments",&Crecomments))goto EXIT;  
	if(!nlsIsStrNull(Crecomments)) CrecommentsDup=nlsStrDup(Crecomments);
	printf("\n CrecommentsDup :%s",CrecommentsDup);fflush(stdout);
	if(!nlsIsStrNull(CrecommentsDup))
	{
		nlsStrTrimTrailWhiteSpace(CrecommentsDup);
		if(nlsStrStr(CrecommentsDup,"\n")!= NULL)
		{
			if(nlsStrStr(CrecommentsDup,"\n")!= NULL) low_strrpl(CrecommentsDup,'\n',';');
			printf("\n After Remove CrecommentsDup==>[%s]\n",CrecommentsDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(CrecommentsDup))		
		{
			fprintf(fp,"%s",CrecommentsDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string CycleTime=NULL;
	string CycleTimeDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOCycleTime",&CycleTime))goto EXIT;  
	if(!nlsIsStrNull(CycleTime)) CycleTimeDup=nlsStrDup(CycleTime);
	printf("\n CycleTimeDup :%s",CycleTimeDup);fflush(stdout);
	if(!nlsIsStrNull(CycleTimeDup))
	{
		nlsStrTrimTrailWhiteSpace(CycleTimeDup);
		if(nlsStrStr(CycleTimeDup,"\n")!= NULL)
		{
			if(nlsStrStr(CycleTimeDup,"\n")!= NULL) low_strrpl(CycleTimeDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",CycleTimeDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(CycleTimeDup))		
		{
			fprintf(fp,"%s",CycleTimeDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string Daviation=NULL;
	string DaviationDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODaviation",&Daviation))goto EXIT;  
	if(!nlsIsStrNull(Daviation)) DaviationDup=nlsStrDup(Daviation);
	printf("\n DaviationDup :%s",DaviationDup);fflush(stdout);
	if(!nlsIsStrNull(DaviationDup))
	{
		nlsStrTrimTrailWhiteSpace(DaviationDup);
		if(nlsStrStr(DaviationDup,"\n")!= NULL)
		{
			if(nlsStrStr(DaviationDup,"\n")!= NULL) low_strrpl(DaviationDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DaviationDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DaviationDup))		
		{
			fprintf(fp,"%s",DaviationDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string DaviationDesc=NULL;
	string DaviationDescDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODaviationDesc",&DaviationDesc))goto EXIT;  
	if(!nlsIsStrNull(DaviationDesc)) DaviationDescDup=nlsStrDup(DaviationDesc);
	printf("\n DaviationDescDup :%s",DaviationDescDup);fflush(stdout);
	if(!nlsIsStrNull(DaviationDescDup))
	{
		nlsStrTrimTrailWhiteSpace(DaviationDescDup);
		if(nlsStrStr(DaviationDescDup,"\n")!= NULL)
		{
			if(nlsStrStr(DaviationDescDup,"\n")!= NULL) low_strrpl(DaviationDescDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DaviationDescDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DaviationDescDup))		
		{
			fprintf(fp,"%s",DaviationDescDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string DmlNo1=NULL;
	string DmlNo1Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODmlNo1",&DmlNo1))goto EXIT;  
	if(!nlsIsStrNull(DmlNo1)) DmlNo1Dup=nlsStrDup(DmlNo1);
	printf("\n DmlNo1Dup :%s",DmlNo1Dup);fflush(stdout);
	if(!nlsIsStrNull(DmlNo1Dup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNo1Dup);
		if(nlsStrStr(DmlNo1Dup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNo1Dup,"\n")!= NULL) low_strrpl(DmlNo1Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DmlNo1Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNo1Dup))		
		{
			fprintf(fp,"%s",DmlNo1Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string DmlNo2=NULL;
	string DmlNo2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODmlNo2",&DmlNo2))goto EXIT;  
	if(!nlsIsStrNull(DmlNo2)) DmlNo2Dup=nlsStrDup(DmlNo2);
	printf("\n DmlNo2Dup :%s",DmlNo2Dup);fflush(stdout);
	if(!nlsIsStrNull(DmlNo2Dup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNo2Dup);
		if(nlsStrStr(DmlNo2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNo2Dup,"\n")!= NULL) low_strrpl(DmlNo2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DmlNo2Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNo2Dup))		
		{
			fprintf(fp,"%s",DmlNo2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string DmlNo3=NULL;
	string DmlNo3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODmlNo3",&DmlNo3))goto EXIT;  
	if(!nlsIsStrNull(DmlNo3)) DmlNo3Dup=nlsStrDup(DmlNo3);
	printf("\n DmlNo3Dup :%s",DmlNo3Dup);fflush(stdout);
	if(!nlsIsStrNull(DmlNo3Dup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNo3Dup);
		if(nlsStrStr(DmlNo3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNo3Dup,"\n")!= NULL) low_strrpl(DmlNo3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DmlNo3Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNo3Dup))		
		{
			fprintf(fp,"%s",DmlNo3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string DmlNo4=NULL;
	string DmlNo4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODmlNo4",&DmlNo4))goto EXIT;  
	if(!nlsIsStrNull(DmlNo4)) DmlNo4Dup=nlsStrDup(DmlNo4);
	printf("\n DmlNo4Dup :%s",DmlNo4Dup);fflush(stdout);
	if(!nlsIsStrNull(DmlNo4Dup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNo4Dup);
		if(nlsStrStr(DmlNo4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNo4Dup,"\n")!= NULL) low_strrpl(DmlNo4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DmlNo4Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNo4Dup))		
		{
			fprintf(fp,"%s",DmlNo4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string DmlNo5=NULL;
	string DmlNo5Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODmlNo5",&DmlNo5))goto EXIT;  
	if(!nlsIsStrNull(DmlNo5)) DmlNo5Dup=nlsStrDup(DmlNo5);
	printf("\n DmlNo5Dup :%s",DmlNo5Dup);fflush(stdout);
	if(!nlsIsStrNull(DmlNo5Dup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNo5Dup);
		if(nlsStrStr(DmlNo5Dup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNo5Dup,"\n")!= NULL) low_strrpl(DmlNo5Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DmlNo5Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNo5Dup))		
		{
			fprintf(fp,"%s",DmlNo5Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string DmlNo6=NULL;
	string DmlNo6Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODmlNo6",&DmlNo6))goto EXIT;  
	if(!nlsIsStrNull(DmlNo6)) DmlNo6Dup=nlsStrDup(DmlNo6);
	printf("\n DmlNo6Dup :%s",DmlNo6Dup);fflush(stdout);
	if(!nlsIsStrNull(DmlNo6Dup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNo6Dup);
		if(nlsStrStr(DmlNo6Dup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNo6Dup,"\n")!= NULL) low_strrpl(DmlNo6Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DmlNo6Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNo6Dup))		
		{
			fprintf(fp,"%s",DmlNo6Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string DmlNo7=NULL;
	string DmlNo7Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODmlNo7",&DmlNo7))goto EXIT;  
	if(!nlsIsStrNull(DmlNo7)) DmlNo7Dup=nlsStrDup(DmlNo7);
	printf("\n DmlNo7Dup :%s",DmlNo7Dup);fflush(stdout);
	if(!nlsIsStrNull(DmlNo7Dup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNo7Dup);
		if(nlsStrStr(DmlNo7Dup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNo7Dup,"\n")!= NULL) low_strrpl(DmlNo7Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DmlNo7Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNo7Dup))		
		{
			fprintf(fp,"%s",DmlNo7Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string DmlNo8=NULL;
	string DmlNo8Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODmlNo8",&DmlNo8))goto EXIT;  
	if(!nlsIsStrNull(DmlNo8)) DmlNo8Dup=nlsStrDup(DmlNo8);
	printf("\n DmlNo8Dup :%s",DmlNo8Dup);fflush(stdout);
	if(!nlsIsStrNull(DmlNo8Dup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNo8Dup);
		if(nlsStrStr(DmlNo8Dup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNo8Dup,"\n")!= NULL) low_strrpl(DmlNo8Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DmlNo8Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNo8Dup))		
		{
			fprintf(fp,"%s",DmlNo8Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string DmlNo9=NULL;
	string DmlNo9Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODmlNo9",&DmlNo9))goto EXIT;  
	if(!nlsIsStrNull(DmlNo9)) DmlNo9Dup=nlsStrDup(DmlNo9);
	printf("\n DmlNo9Dup :%s",DmlNo9Dup);fflush(stdout);
	if(!nlsIsStrNull(DmlNo9Dup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNo9Dup);
		if(nlsStrStr(DmlNo9Dup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNo9Dup,"\n")!= NULL) low_strrpl(DmlNo9Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DmlNo9Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNo9Dup))		
		{
			fprintf(fp,"%s",DmlNo9Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string DmlNo10=NULL;
	string DmlNo10Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TODmlNo10",&DmlNo10))goto EXIT;  
	if(!nlsIsStrNull(DmlNo10)) DmlNo10Dup=nlsStrDup(DmlNo10);
	printf("\n DmlNo10Dup :%s",DmlNo10Dup);fflush(stdout);
	if(!nlsIsStrNull(DmlNo10Dup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNo10Dup);
		if(nlsStrStr(DmlNo10Dup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNo10Dup,"\n")!= NULL) low_strrpl(DmlNo10Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",DmlNo10Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNo10Dup))		
		{
			fprintf(fp,"%s",DmlNo10Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string FactHead=NULL;
	string FactHeadDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOFactHead",&FactHead))goto EXIT;  
	if(!nlsIsStrNull(FactHead)) FactHeadDup=nlsStrDup(FactHead);
	printf("\n FactHeadDup :%s",FactHeadDup);fflush(stdout);
	if(!nlsIsStrNull(FactHeadDup))
	{
		nlsStrTrimTrailWhiteSpace(FactHeadDup);
		if(nlsStrStr(FactHeadDup,"\n")!= NULL)
		{
			if(nlsStrStr(FactHeadDup,"\n")!= NULL) low_strrpl(FactHeadDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",FactHeadDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(FactHeadDup))		
		{
			fprintf(fp,"%s",FactHeadDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string Feedback=NULL;
	string FeedbackDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOFeedback",&Feedback))goto EXIT;  
	if(!nlsIsStrNull(Feedback)) FeedbackDup=nlsStrDup(Feedback);
	printf("\n FeedbackDup :%s",FeedbackDup);fflush(stdout);
	if(!nlsIsStrNull(FeedbackDup))
	{
		nlsStrTrimTrailWhiteSpace(FeedbackDup);
		if(nlsStrStr(FeedbackDup,"\n")!= NULL)
		{
			if(nlsStrStr(FeedbackDup,"\n")!= NULL) low_strrpl(FeedbackDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",FeedbackDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(FeedbackDup))		
		{
			fprintf(fp,"%s",FeedbackDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string Fitment=NULL;
	string FitmentDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOFitment",&Fitment))goto EXIT;  
	if(!nlsIsStrNull(Fitment)) FitmentDup=nlsStrDup(Fitment);
	printf("\n FitmentDup :%s",FitmentDup);fflush(stdout);
	if(!nlsIsStrNull(FitmentDup))
	{
		nlsStrTrimTrailWhiteSpace(FitmentDup);
		if(nlsStrStr(FitmentDup,"\n")!= NULL)
		{
			if(nlsStrStr(FitmentDup,"\n")!= NULL) low_strrpl(FitmentDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",FitmentDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(FitmentDup))		
		{
			fprintf(fp,"%s",FitmentDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string IntVinNo1=NULL;
	string IntVinNo1Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIntVinNo1",&IntVinNo1))goto EXIT;  
	if(!nlsIsStrNull(IntVinNo1)) IntVinNo1Dup=nlsStrDup(IntVinNo1);
	printf("\n IntVinNo1Dup :%s",IntVinNo1Dup);fflush(stdout);
	if(!nlsIsStrNull(IntVinNo1Dup))
	{
		nlsStrTrimTrailWhiteSpace(IntVinNo1Dup);
		if(nlsStrStr(IntVinNo1Dup,"\n")!= NULL)
		{
			if(nlsStrStr(IntVinNo1Dup,"\n")!= NULL) low_strrpl(IntVinNo1Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IntVinNo1Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IntVinNo1Dup))		
		{
			fprintf(fp,"%s",IntVinNo1Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string IntVinNo2=NULL;
	string IntVinNo2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIntVinNo2",&IntVinNo2))goto EXIT;  
	if(!nlsIsStrNull(IntVinNo2)) IntVinNo2Dup=nlsStrDup(IntVinNo2);
	printf("\n IntVinNo2Dup :%s",IntVinNo2Dup);fflush(stdout);
	if(!nlsIsStrNull(IntVinNo2Dup))
	{
		nlsStrTrimTrailWhiteSpace(IntVinNo2Dup);
		if(nlsStrStr(IntVinNo2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(IntVinNo2Dup,"\n")!= NULL) low_strrpl(IntVinNo2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IntVinNo2Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IntVinNo2Dup))		
		{
			fprintf(fp,"%s",IntVinNo2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string IntVinNo3=NULL;
	string IntVinNo3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIntVinNo3",&IntVinNo3))goto EXIT;  
	if(!nlsIsStrNull(IntVinNo3)) IntVinNo3Dup=nlsStrDup(IntVinNo3);
	printf("\n IntVinNo3Dup :%s",IntVinNo3Dup);fflush(stdout);
	if(!nlsIsStrNull(IntVinNo3Dup))
	{
		nlsStrTrimTrailWhiteSpace(IntVinNo3Dup);
		if(nlsStrStr(IntVinNo3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(IntVinNo3Dup,"\n")!= NULL) low_strrpl(IntVinNo3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IntVinNo3Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IntVinNo3Dup))		
		{
			fprintf(fp,"%s",IntVinNo3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string IntVinNo4=NULL;
	string IntVinNo4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIntVinNo4",&IntVinNo4))goto EXIT;  
	if(!nlsIsStrNull(IntVinNo4)) IntVinNo4Dup=nlsStrDup(IntVinNo4);
	printf("\n IntVinNo4Dup :%s",IntVinNo4Dup);fflush(stdout);
	if(!nlsIsStrNull(IntVinNo4Dup))
	{
		nlsStrTrimTrailWhiteSpace(IntVinNo4Dup);
		if(nlsStrStr(IntVinNo4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(IntVinNo4Dup,"\n")!= NULL) low_strrpl(IntVinNo4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IntVinNo4Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IntVinNo4Dup))		
		{
			fprintf(fp,"%s",IntVinNo4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string IntVinNo5=NULL;
	string IntVinNo5Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIntVinNo5",&IntVinNo5))goto EXIT;  
	if(!nlsIsStrNull(IntVinNo5)) IntVinNo5Dup=nlsStrDup(IntVinNo5);
	printf("\n IntVinNo5Dup :%s",IntVinNo5Dup);fflush(stdout);
	if(!nlsIsStrNull(IntVinNo5Dup))
	{
		nlsStrTrimTrailWhiteSpace(IntVinNo5Dup);
		if(nlsStrStr(IntVinNo5Dup,"\n")!= NULL)
		{
			if(nlsStrStr(IntVinNo5Dup,"\n")!= NULL) low_strrpl(IntVinNo5Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IntVinNo5Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IntVinNo5Dup))		
		{
			fprintf(fp,"%s",IntVinNo5Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string IntVinNo6=NULL;
	string IntVinNo6Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIntVinNo6",&IntVinNo6))goto EXIT;  
	if(!nlsIsStrNull(IntVinNo6)) IntVinNo6Dup=nlsStrDup(IntVinNo6);
	printf("\n IntVinNo6Dup :%s",IntVinNo6Dup);fflush(stdout);
	if(!nlsIsStrNull(IntVinNo6Dup))
	{
		nlsStrTrimTrailWhiteSpace(IntVinNo6Dup);
		if(nlsStrStr(IntVinNo6Dup,"\n")!= NULL)
		{
			if(nlsStrStr(IntVinNo6Dup,"\n")!= NULL) low_strrpl(IntVinNo6Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IntVinNo6Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IntVinNo6Dup))		
		{
			fprintf(fp,"%s",IntVinNo6Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string IntVinNo7=NULL;
	string IntVinNo7Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIntVinNo7",&IntVinNo7))goto EXIT;  
	if(!nlsIsStrNull(IntVinNo7)) IntVinNo7Dup=nlsStrDup(IntVinNo7);
	printf("\n IntVinNo7Dup :%s",IntVinNo7Dup);fflush(stdout);
	if(!nlsIsStrNull(IntVinNo7Dup))
	{
		nlsStrTrimTrailWhiteSpace(IntVinNo7Dup);
		if(nlsStrStr(IntVinNo7Dup,"\n")!= NULL)
		{
			if(nlsStrStr(IntVinNo7Dup,"\n")!= NULL) low_strrpl(IntVinNo7Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IntVinNo7Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IntVinNo7Dup))		
		{
			fprintf(fp,"%s",IntVinNo7Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string IntVinNo8=NULL;
	string IntVinNo8Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIntVinNo8",&IntVinNo8))goto EXIT;  
	if(!nlsIsStrNull(IntVinNo8)) IntVinNo8Dup=nlsStrDup(IntVinNo8);
	printf("\n IntVinNo8Dup :%s",IntVinNo8Dup);fflush(stdout);
	if(!nlsIsStrNull(IntVinNo8Dup))
	{
		nlsStrTrimTrailWhiteSpace(IntVinNo8Dup);
		if(nlsStrStr(IntVinNo8Dup,"\n")!= NULL)
		{
			if(nlsStrStr(IntVinNo8Dup,"\n")!= NULL) low_strrpl(IntVinNo8Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IntVinNo8Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IntVinNo8Dup))		
		{
			fprintf(fp,"%s",IntVinNo8Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string IntVinNo9=NULL;
	string IntVinNo9Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIntVinNo9",&IntVinNo9))goto EXIT;  
	if(!nlsIsStrNull(IntVinNo9)) IntVinNo9Dup=nlsStrDup(IntVinNo9);
	printf("\n IntVinNo9Dup :%s",IntVinNo9Dup);fflush(stdout);
	if(!nlsIsStrNull(IntVinNo9Dup))
	{
		nlsStrTrimTrailWhiteSpace(IntVinNo9Dup);
		if(nlsStrStr(IntVinNo9Dup,"\n")!= NULL)
		{
			if(nlsStrStr(IntVinNo9Dup,"\n")!= NULL) low_strrpl(IntVinNo9Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IntVinNo9Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IntVinNo9Dup))		
		{
			fprintf(fp,"%s",IntVinNo9Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string IntVinNo10=NULL;
	string IntVinNo10Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIntVinNo10",&IntVinNo10))goto EXIT;  
	if(!nlsIsStrNull(IntVinNo10)) IntVinNo10Dup=nlsStrDup(IntVinNo10);
	printf("\n IntVinNo10Dup :%s",IntVinNo10Dup);fflush(stdout);
	if(!nlsIsStrNull(IntVinNo10Dup))
	{
		nlsStrTrimTrailWhiteSpace(IntVinNo10Dup);
		if(nlsStrStr(IntVinNo10Dup,"\n")!= NULL)
		{
			if(nlsStrStr(IntVinNo10Dup,"\n")!= NULL) low_strrpl(IntVinNo10Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IntVinNo10Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IntVinNo10Dup))		
		{
			fprintf(fp,"%s",IntVinNo10Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string IsDML=NULL;
	string IsDMLDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIsDML",&IsDML))goto EXIT;   // BOOLEAN
	if(!nlsIsStrNull(IsDML)) IsDMLDup=nlsStrDup(IsDML);
	printf("\n IsDMLDup :%s",IsDMLDup);fflush(stdout);
	if(!nlsIsStrNull(IsDMLDup))
	{
		nlsStrTrimTrailWhiteSpace(IsDMLDup);
		if(nlsStrStr(IsDMLDup,"\n")!= NULL)
		{
			if(nlsStrStr(IsDMLDup,"\n")!= NULL) low_strrpl(IsDMLDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IsDMLDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IsDMLDup))		
		{
			fprintf(fp,"%s",IsDMLDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string IsEPA=NULL;
	string IsEPADup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOIsEPA",&IsEPA))goto EXIT;   // BOOLEAN
	if(!nlsIsStrNull(IsEPA)) IsEPADup=nlsStrDup(IsEPA);
	printf("\n IsEPADup :%s",IsEPADup);fflush(stdout);
	if(!nlsIsStrNull(IsEPADup))
	{
		nlsStrTrimTrailWhiteSpace(IsEPADup);
		if(nlsStrStr(IsEPADup,"\n")!= NULL)
		{
			if(nlsStrStr(IsEPADup,"\n")!= NULL) low_strrpl(IsEPADup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",IsEPADup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(IsEPADup))		
		{
			fprintf(fp,"%s",IsEPADup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string Location=NULL;
	string LocationDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOLocation",&Location))goto EXIT;  
	if(!nlsIsStrNull(Location)) LocationDup=nlsStrDup(Location);
	printf("\n LocationDup :%s",LocationDup);fflush(stdout);
	if(!nlsIsStrNull(LocationDup))
	{
		nlsStrTrimTrailWhiteSpace(LocationDup);
		if(nlsStrStr(LocationDup,"\n")!= NULL)
		{
			if(nlsStrStr(LocationDup,"\n")!= NULL) low_strrpl(LocationDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",LocationDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(LocationDup))		
		{
			fprintf(fp,"%s",LocationDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ManReviewer=NULL;
	string ManReviewerDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOManReviewer",&ManReviewer))goto EXIT;  
	if(!nlsIsStrNull(ManReviewer)) ManReviewerDup=nlsStrDup(ManReviewer);
	printf("\n ManReviewerDup :%s",ManReviewerDup);fflush(stdout);
	if(!nlsIsStrNull(ManReviewerDup))
	{
		nlsStrTrimTrailWhiteSpace(ManReviewerDup);
		if(nlsStrStr(ManReviewerDup,"\n")!= NULL)
		{
			if(nlsStrStr(ManReviewerDup,"\n")!= NULL) low_strrpl(ManReviewerDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ManReviewerDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ManReviewerDup))		
		{
			fprintf(fp,"%s",ManReviewerDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartDesc=NULL;
	string ModPartDescDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartDesc",&ModPartDesc))goto EXIT;  
	if(!nlsIsStrNull(ModPartDesc)) ModPartDescDup=nlsStrDup(ModPartDesc);
	printf("\n ModPartDescDup :%s",ModPartDescDup);fflush(stdout);
	if(!nlsIsStrNull(ModPartDescDup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartDescDup);
		if(nlsStrStr(ModPartDescDup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartDescDup,"\n")!= NULL) low_strrpl(ModPartDescDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartDescDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartDescDup))		
		{
			fprintf(fp,"%s",ModPartDescDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartDesc1=NULL;
	string ModPartDesc1Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartDesc1",&ModPartDesc1))goto EXIT;  
	if(!nlsIsStrNull(ModPartDesc1)) ModPartDesc1Dup=nlsStrDup(ModPartDesc1);
	printf("\n ModPartDesc1Dup :%s",ModPartDesc1Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartDesc1Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartDesc1Dup);
		if(nlsStrStr(ModPartDesc1Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartDesc1Dup,"\n")!= NULL) low_strrpl(ModPartDesc1Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartDesc1Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartDesc1Dup))		
		{
			fprintf(fp,"%s",ModPartDesc1Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartDesc2=NULL;
	string ModPartDesc2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartDesc2",&ModPartDesc2))goto EXIT;  
	if(!nlsIsStrNull(ModPartDesc2)) ModPartDesc2Dup=nlsStrDup(ModPartDesc2);
	printf("\n ModPartDesc2Dup :%s",ModPartDesc2Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartDesc2Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartDesc2Dup);
		if(nlsStrStr(ModPartDesc2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartDesc2Dup,"\n")!= NULL) low_strrpl(ModPartDesc2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartDesc2Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartDesc2Dup))		
		{
			fprintf(fp,"%s",ModPartDesc2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string ModPartDesc3=NULL;
	string ModPartDesc3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartDesc3",&ModPartDesc3))goto EXIT;  
	if(!nlsIsStrNull(ModPartDesc3)) ModPartDesc3Dup=nlsStrDup(ModPartDesc3);
	printf("\n ModPartDesc3Dup :%s",ModPartDesc3Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartDesc3Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartDesc3Dup);
		if(nlsStrStr(ModPartDesc3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartDesc3Dup,"\n")!= NULL) low_strrpl(ModPartDesc3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartDesc3Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartDesc3Dup))		
		{
			fprintf(fp,"%s",ModPartDesc3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartDesc4=NULL;
	string ModPartDesc4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartDesc4",&ModPartDesc4))goto EXIT;  
	if(!nlsIsStrNull(ModPartDesc4)) ModPartDesc4Dup=nlsStrDup(ModPartDesc4);
	printf("\n ModPartDesc4Dup :%s",ModPartDesc4Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartDesc4Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartDesc4Dup);
		if(nlsStrStr(ModPartDesc4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartDesc4Dup,"\n")!= NULL) low_strrpl(ModPartDesc4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartDesc4Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartDesc4Dup))		
		{
			fprintf(fp,"%s",ModPartDesc4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartDesc6=NULL;
	string ModPartDesc6Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartDesc6",&ModPartDesc6))goto EXIT;  
	if(!nlsIsStrNull(ModPartDesc6)) ModPartDesc6Dup=nlsStrDup(ModPartDesc6);
	printf("\n ModPartDesc6Dup :%s",ModPartDesc6Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartDesc6Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartDesc6Dup);
		if(nlsStrStr(ModPartDesc6Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartDesc6Dup,"\n")!= NULL) low_strrpl(ModPartDesc6Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartDesc6Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartDesc6Dup))		
		{
			fprintf(fp,"%s",ModPartDesc6Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string ModPartDesc7=NULL;
	string ModPartDesc7Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartDesc7",&ModPartDesc7))goto EXIT;  
	if(!nlsIsStrNull(ModPartDesc7)) ModPartDesc7Dup=nlsStrDup(ModPartDesc7);
	printf("\n ModPartDesc7Dup :%s",ModPartDesc7Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartDesc7Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartDesc7Dup);
		if(nlsStrStr(ModPartDesc7Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartDesc7Dup,"\n")!= NULL) low_strrpl(ModPartDesc7Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartDesc7Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartDesc7Dup))		
		{
			fprintf(fp,"%s",ModPartDesc7Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartDesc8=NULL;
	string ModPartDesc8Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartDesc8",&ModPartDesc8))goto EXIT;  
	if(!nlsIsStrNull(ModPartDesc8)) ModPartDesc8Dup=nlsStrDup(ModPartDesc8);
	printf("\n ModPartDesc8Dup :%s",ModPartDesc8Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartDesc8Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartDesc8Dup);
		if(nlsStrStr(ModPartDesc8Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartDesc8Dup,"\n")!= NULL) low_strrpl(ModPartDesc8Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartDesc8Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartDesc8Dup))		
		{
			fprintf(fp,"%s",ModPartDesc8Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartDesc9=NULL;
	string ModPartDesc9Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartDesc9",&ModPartDesc9))goto EXIT;  
	if(!nlsIsStrNull(ModPartDesc9)) ModPartDesc9Dup=nlsStrDup(ModPartDesc9);
	printf("\n ModPartDesc9Dup :%s",ModPartDesc9Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartDesc9Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartDesc9Dup);
		if(nlsStrStr(ModPartDesc9Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartDesc9Dup,"\n")!= NULL) low_strrpl(ModPartDesc9Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartDesc9Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartDesc9Dup))		
		{
			fprintf(fp,"%s",ModPartDesc9Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartDesc10=NULL;
	string ModPartDesc10Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartDesc10",&ModPartDesc10))goto EXIT;  
	if(!nlsIsStrNull(ModPartDesc10)) ModPartDesc10Dup=nlsStrDup(ModPartDesc10);
	printf("\n ModPartDesc10Dup :%s",ModPartDesc10Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartDesc10Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartDesc10Dup);
		if(nlsStrStr(ModPartDesc10Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartDesc10Dup,"\n")!= NULL) low_strrpl(ModPartDesc10Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartDesc10Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartDesc10Dup))		
		{
			fprintf(fp,"%s",ModPartDesc10Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string ModPartNo=NULL;
	string ModPartNoDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartNo",&ModPartNo))goto EXIT;  
	if(!nlsIsStrNull(ModPartNo)) ModPartNoDup=nlsStrDup(ModPartNo);
	printf("\n ModPartNoDup :%s",ModPartNoDup);fflush(stdout);
	if(!nlsIsStrNull(ModPartNoDup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartNoDup);
		if(nlsStrStr(ModPartNoDup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartNoDup,"\n")!= NULL) low_strrpl(ModPartNoDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartNoDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartNoDup))		
		{
			fprintf(fp,"%s",ModPartNoDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartNo1=NULL;
	string ModPartNo1Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartNo1",&ModPartNo1))goto EXIT;  
	if(!nlsIsStrNull(ModPartNo1)) ModPartNo1Dup=nlsStrDup(ModPartNo1);
	printf("\n ModPartNo1Dup :%s",ModPartNo1Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartNo1Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartNo1Dup);
		if(nlsStrStr(ModPartNo1Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartNo1Dup,"\n")!= NULL) low_strrpl(ModPartNo1Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartNo1Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartNo1Dup))		
		{
			fprintf(fp,"%s",ModPartNo1Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartNo2=NULL;
	string ModPartNo2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartNo2",&ModPartNo2))goto EXIT;  
	if(!nlsIsStrNull(ModPartNo2)) ModPartNo2Dup=nlsStrDup(ModPartNo2);
	printf("\n ModPartNo2Dup :%s",ModPartNo2Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartNo2Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartNo2Dup);
		if(nlsStrStr(ModPartNo2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartNo2Dup,"\n")!= NULL) low_strrpl(ModPartNo2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartNo2Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartNo2Dup))		
		{
			fprintf(fp,"%s",ModPartNo2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string ModPartNo3=NULL;
	string ModPartNo3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartNo3",&ModPartNo3))goto EXIT;  
	if(!nlsIsStrNull(ModPartNo3)) ModPartNo3Dup=nlsStrDup(ModPartNo3);
	printf("\n ModPartNo3Dup :%s",ModPartNo3Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartNo3Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartNo3Dup);
		if(nlsStrStr(ModPartNo3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartNo3Dup,"\n")!= NULL) low_strrpl(ModPartNo3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartNo3Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartNo3Dup))		
		{
			fprintf(fp,"%s",ModPartNo3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string ModPartNo4=NULL;
	string ModPartNo4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModPartNo4",&ModPartNo4))goto EXIT;  
	if(!nlsIsStrNull(ModPartNo4)) ModPartNo4Dup=nlsStrDup(ModPartNo4);
	printf("\n ModPartNo4Dup :%s",ModPartNo4Dup);fflush(stdout);
	if(!nlsIsStrNull(ModPartNo4Dup))
	{
		nlsStrTrimTrailWhiteSpace(ModPartNo4Dup);
		if(nlsStrStr(ModPartNo4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(ModPartNo4Dup,"\n")!= NULL) low_strrpl(ModPartNo4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",ModPartNo4Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ModPartNo4Dup))		
		{
			fprintf(fp,"%s",ModPartNo4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOModType=NULL;
	string TOModTypeDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModType",&TOModType))goto EXIT;  
	if(!nlsIsStrNull(TOModType)) TOModTypeDup=nlsStrDup(TOModType);
	printf("\n TOModTypeDup :%s",TOModTypeDup);fflush(stdout);
	if(!nlsIsStrNull(TOModTypeDup))
	{
		nlsStrTrimTrailWhiteSpace(TOModTypeDup);
		if(nlsStrStr(TOModTypeDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOModTypeDup,"\n")!= NULL) low_strrpl(TOModTypeDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOModTypeDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOModTypeDup))		
		{
			fprintf(fp,"%s",TOModTypeDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOModType1=NULL;
	string TOModType1Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModType1",&TOModType1))goto EXIT;  
	if(!nlsIsStrNull(TOModType1)) TOModType1Dup=nlsStrDup(TOModType1);
	printf("\n TOModType1Dup :%s",TOModType1Dup);fflush(stdout);
	if(!nlsIsStrNull(TOModType1Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOModType1Dup);
		if(nlsStrStr(TOModType1Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOModType1Dup,"\n")!= NULL) low_strrpl(TOModType1Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOModType1Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOModType1Dup))		
		{
			fprintf(fp,"%s",TOModType1Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOModType2=NULL;
	string TOModType2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModType2",&TOModType2))goto EXIT;  
	if(!nlsIsStrNull(TOModType2)) TOModType2Dup=nlsStrDup(TOModType2);
	printf("\n TOModType2Dup :%s",TOModType2Dup);fflush(stdout);
	if(!nlsIsStrNull(TOModType2Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOModType2Dup);
		if(nlsStrStr(TOModType2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOModType2Dup,"\n")!= NULL) low_strrpl(TOModType2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOModType2Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOModType2Dup))		
		{
			fprintf(fp,"%s",TOModType2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOModType3=NULL;
	string TOModType3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModType3",&TOModType3))goto EXIT;  
	if(!nlsIsStrNull(TOModType3)) TOModType3Dup=nlsStrDup(TOModType3);
	printf("\n TOModType3Dup :%s",TOModType3Dup);fflush(stdout);
	if(!nlsIsStrNull(TOModType3Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOModType3Dup);
		if(nlsStrStr(TOModType3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOModType3Dup,"\n")!= NULL) low_strrpl(TOModType3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOModType3Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOModType3Dup))		
		{
			fprintf(fp,"%s",TOModType3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOModType4=NULL;
	string TOModType4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModType4",&TOModType4))goto EXIT;  
	if(!nlsIsStrNull(TOModType4)) TOModType4Dup=nlsStrDup(TOModType4);
	printf("\n TOModType4Dup :%s",TOModType4Dup);fflush(stdout);
	if(!nlsIsStrNull(TOModType4Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOModType4Dup);
		if(nlsStrStr(TOModType4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOModType4Dup,"\n")!= NULL) low_strrpl(TOModType4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOModType4Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOModType4Dup))		
		{
			fprintf(fp,"%s",TOModType4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOModType5=NULL;
	string TOModType5Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModType5",&TOModType5))goto EXIT;  
	if(!nlsIsStrNull(TOModType5)) TOModType5Dup=nlsStrDup(TOModType5);
	printf("\n TOModType5Dup :%s",TOModType5Dup);fflush(stdout);
	if(!nlsIsStrNull(TOModType5Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOModType5Dup);
		if(nlsStrStr(TOModType5Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOModType5Dup,"\n")!= NULL) low_strrpl(TOModType5Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOModType5Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOModType5Dup))		
		{
			fprintf(fp,"%s",TOModType5Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string TOModType6=NULL;
	string TOModType6Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModType6",&TOModType6))goto EXIT;  
	if(!nlsIsStrNull(TOModType6)) TOModType6Dup=nlsStrDup(TOModType6);
	printf("\n TOModType6Dup :%s",TOModType6Dup);fflush(stdout);
	if(!nlsIsStrNull(TOModType6Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOModType6Dup);
		if(nlsStrStr(TOModType6Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOModType6Dup,"\n")!= NULL) low_strrpl(TOModType6Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOModType6Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOModType6Dup))		
		{
			fprintf(fp,"%s",TOModType6Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string TOModType7=NULL;
	string TOModType7Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModType7",&TOModType7))goto EXIT;  
	if(!nlsIsStrNull(TOModType7)) TOModType7Dup=nlsStrDup(TOModType7);
	printf("\n TOModType7Dup :%s",TOModType7Dup);fflush(stdout);
	if(!nlsIsStrNull(TOModType7Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOModType7Dup);
		if(nlsStrStr(TOModType7Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOModType7Dup,"\n")!= NULL) low_strrpl(TOModType7Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOModType7Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOModType7Dup))		
		{
			fprintf(fp,"%s",TOModType7Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string TOModType8=NULL;
	string TOModType8Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModType8",&TOModType8))goto EXIT;  
	if(!nlsIsStrNull(TOModType8)) TOModType8Dup=nlsStrDup(TOModType8);
	printf("\n TOModType8Dup :%s",TOModType8Dup);fflush(stdout);
	if(!nlsIsStrNull(TOModType8Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOModType8Dup);
		if(nlsStrStr(TOModType8Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOModType8Dup,"\n")!= NULL) low_strrpl(TOModType8Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOModType8Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOModType8Dup))		
		{
			fprintf(fp,"%s",TOModType8Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOModType9=NULL;
	string TOModType9Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOModType9",&TOModType9))goto EXIT;  
	if(!nlsIsStrNull(TOModType9)) TOModType9Dup=nlsStrDup(TOModType9);
	printf("\n TOModType9Dup :%s",TOModType9Dup);fflush(stdout);
	if(!nlsIsStrNull(TOModType9Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOModType9Dup);
		if(nlsStrStr(TOModType9Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOModType9Dup,"\n")!= NULL) low_strrpl(TOModType9Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOModType9Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOModType9Dup))		
		{
			fprintf(fp,"%s",TOModType9Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string PartDesc1=NULL;
	string PartDesc1Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartDesc1",&PartDesc1))goto EXIT;  
	if(!nlsIsStrNull(PartDesc1)) PartDesc1Dup=nlsStrDup(PartDesc1);
	printf("\n PartDesc1Dup :%s",PartDesc1Dup);fflush(stdout);
	if(!nlsIsStrNull(PartDesc1Dup))
	{
		nlsStrTrimTrailWhiteSpace(PartDesc1Dup);
		if(nlsStrStr(PartDesc1Dup,"\n")!= NULL)
		{
			if(nlsStrStr(PartDesc1Dup,"\n")!= NULL) low_strrpl(PartDesc1Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",PartDesc1Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PartDesc1Dup))		
		{
			fprintf(fp,"%s",PartDesc1Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string PartDesc2=NULL;
	string PartDesc2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartDesc2",&PartDesc2))goto EXIT;  
	if(!nlsIsStrNull(PartDesc2)) PartDesc2Dup=nlsStrDup(PartDesc2);
	printf("\n PartDesc2Dup :%s",PartDesc2Dup);fflush(stdout);
	if(!nlsIsStrNull(PartDesc2Dup))
	{
		nlsStrTrimTrailWhiteSpace(PartDesc2Dup);
		if(nlsStrStr(PartDesc2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(PartDesc2Dup,"\n")!= NULL) low_strrpl(PartDesc2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",PartDesc2Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PartDesc2Dup))		
		{
			fprintf(fp,"%s",PartDesc2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string PartDesc3=NULL;
	string PartDesc3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartDesc3",&PartDesc3))goto EXIT;  
	if(!nlsIsStrNull(PartDesc3)) PartDesc3Dup=nlsStrDup(PartDesc3);
	printf("\n PartDesc3Dup :%s",PartDesc3Dup);fflush(stdout);
	if(!nlsIsStrNull(PartDesc3Dup))
	{
		nlsStrTrimTrailWhiteSpace(PartDesc3Dup);
		if(nlsStrStr(PartDesc3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(PartDesc3Dup,"\n")!= NULL) low_strrpl(PartDesc3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",PartDesc3Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PartDesc3Dup))		
		{
			fprintf(fp,"%s",PartDesc3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string PartDesc4=NULL;
	string PartDesc4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartDesc4",&PartDesc4))goto EXIT;  
	if(!nlsIsStrNull(PartDesc4)) PartDesc4Dup=nlsStrDup(PartDesc4);
	printf("\n PartDesc4Dup :%s",PartDesc4Dup);fflush(stdout);
	if(!nlsIsStrNull(PartDesc4Dup))
	{
		nlsStrTrimTrailWhiteSpace(PartDesc4Dup);
		if(nlsStrStr(PartDesc4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(PartDesc4Dup,"\n")!= NULL) low_strrpl(PartDesc4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",PartDesc4Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PartDesc4Dup))		
		{
			fprintf(fp,"%s",PartDesc4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string PartDesc5=NULL;
	string PartDesc5Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartDesc5",&PartDesc5))goto EXIT;  
	if(!nlsIsStrNull(PartDesc5)) PartDesc5Dup=nlsStrDup(PartDesc5);
	printf("\n PartDesc5Dup :%s",PartDesc5Dup);fflush(stdout);
	if(!nlsIsStrNull(PartDesc5Dup))
	{
		nlsStrTrimTrailWhiteSpace(PartDesc5Dup);
		if(nlsStrStr(PartDesc5Dup,"\n")!= NULL)
		{
			if(nlsStrStr(PartDesc5Dup,"\n")!= NULL) low_strrpl(PartDesc5Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",PartDesc5Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PartDesc5Dup))		
		{
			fprintf(fp,"%s",PartDesc5Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string PartDesc6=NULL;
	string PartDesc6Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartDesc6",&PartDesc6))goto EXIT;  
	if(!nlsIsStrNull(PartDesc6)) PartDesc6Dup=nlsStrDup(PartDesc6);
	printf("\n PartDesc6Dup :%s",PartDesc6Dup);fflush(stdout);
	if(!nlsIsStrNull(PartDesc6Dup))
	{
		nlsStrTrimTrailWhiteSpace(PartDesc6Dup);
		if(nlsStrStr(PartDesc6Dup,"\n")!= NULL)
		{
			if(nlsStrStr(PartDesc6Dup,"\n")!= NULL) low_strrpl(PartDesc6Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",PartDesc6Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PartDesc6Dup))		
		{
			fprintf(fp,"%s",PartDesc6Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string PartDesc7=NULL;
	string PartDesc7Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartDesc7",&PartDesc7))goto EXIT;  
	if(!nlsIsStrNull(PartDesc7)) PartDesc7Dup=nlsStrDup(PartDesc7);
	printf("\n PartDesc7Dup :%s",PartDesc7Dup);fflush(stdout);
	if(!nlsIsStrNull(PartDesc7Dup))
	{
		nlsStrTrimTrailWhiteSpace(PartDesc7Dup);
		if(nlsStrStr(PartDesc7Dup,"\n")!= NULL)
		{
			if(nlsStrStr(PartDesc7Dup,"\n")!= NULL) low_strrpl(PartDesc7Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",PartDesc7Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PartDesc7Dup))		
		{
			fprintf(fp,"%s",PartDesc7Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string PartDesc8=NULL;
	string PartDesc8Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartDesc8",&PartDesc8))goto EXIT;  
	if(!nlsIsStrNull(PartDesc8)) PartDesc8Dup=nlsStrDup(PartDesc8);
	printf("\n PartDesc8Dup :%s",PartDesc8Dup);fflush(stdout);
	if(!nlsIsStrNull(PartDesc8Dup))
	{
		nlsStrTrimTrailWhiteSpace(PartDesc8Dup);
		if(nlsStrStr(PartDesc8Dup,"\n")!= NULL)
		{
			if(nlsStrStr(PartDesc8Dup,"\n")!= NULL) low_strrpl(PartDesc8Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",PartDesc8Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PartDesc8Dup))		
		{
			fprintf(fp,"%s",PartDesc8Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string PartDesc9=NULL;
	string PartDesc9Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartDesc9",&PartDesc9))goto EXIT;  
	if(!nlsIsStrNull(PartDesc9)) PartDesc9Dup=nlsStrDup(PartDesc9);
	printf("\n PartDesc9Dup :%s",PartDesc9Dup);fflush(stdout);
	if(!nlsIsStrNull(PartDesc9Dup))
	{
		nlsStrTrimTrailWhiteSpace(PartDesc9Dup);
		if(nlsStrStr(PartDesc9Dup,"\n")!= NULL)
		{
			if(nlsStrStr(PartDesc9Dup,"\n")!= NULL) low_strrpl(PartDesc9Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",PartDesc9Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PartDesc9Dup))		
		{
			fprintf(fp,"%s",PartDesc9Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string PartDesc10=NULL;
	string PartDesc10Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartDesc10",&PartDesc10))goto EXIT;  
	if(!nlsIsStrNull(PartDesc10)) PartDesc10Dup=nlsStrDup(PartDesc10);
	printf("\n PartDesc10Dup :%s",PartDesc10Dup);fflush(stdout);
	if(!nlsIsStrNull(PartDesc10Dup))
	{
		nlsStrTrimTrailWhiteSpace(PartDesc10Dup);
		if(nlsStrStr(PartDesc10Dup,"\n")!= NULL)
		{
			if(nlsStrStr(PartDesc10Dup,"\n")!= NULL) low_strrpl(PartDesc10Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",PartDesc10Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(PartDesc10Dup))		
		{
			fprintf(fp,"%s",PartDesc10Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartNo1=NULL;
	string TOPartNo1Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartNo1",&TOPartNo1))goto EXIT;  
	if(!nlsIsStrNull(TOPartNo1)) TOPartNo1Dup=nlsStrDup(TOPartNo1);
	printf("\n TOPartNo1Dup :%s",TOPartNo1Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartNo1Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartNo1Dup);
		if(nlsStrStr(TOPartNo1Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartNo1Dup,"\n")!= NULL) low_strrpl(TOPartNo1Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartNo1Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartNo1Dup))		
		{
			fprintf(fp,"%s",TOPartNo1Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartNo2=NULL;
	string TOPartNo2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartNo2",&TOPartNo2))goto EXIT;  
	if(!nlsIsStrNull(TOPartNo2)) TOPartNo2Dup=nlsStrDup(TOPartNo2);
	printf("\n TOPartNo2Dup :%s",TOPartNo2Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartNo2Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartNo2Dup);
		if(nlsStrStr(TOPartNo2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartNo2Dup,"\n")!= NULL) low_strrpl(TOPartNo2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartNo2Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartNo2Dup))		
		{
			fprintf(fp,"%s",TOPartNo2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartNo3=NULL;
	string TOPartNo3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartNo3",&TOPartNo3))goto EXIT;  
	if(!nlsIsStrNull(TOPartNo3)) TOPartNo3Dup=nlsStrDup(TOPartNo3);
	printf("\n TOPartNo3Dup :%s",TOPartNo3Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartNo3Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartNo3Dup);
		if(nlsStrStr(TOPartNo3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartNo3Dup,"\n")!= NULL) low_strrpl(TOPartNo3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartNo3Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartNo3Dup))		
		{
			fprintf(fp,"%s",TOPartNo3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartNo4=NULL;
	string TOPartNo4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartNo4",&TOPartNo4))goto EXIT;  
	if(!nlsIsStrNull(TOPartNo4)) TOPartNo4Dup=nlsStrDup(TOPartNo4);
	printf("\n TOPartNo4Dup :%s",TOPartNo4Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartNo4Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartNo4Dup);
		if(nlsStrStr(TOPartNo4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartNo4Dup,"\n")!= NULL) low_strrpl(TOPartNo4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartNo4Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartNo4Dup))		
		{
			fprintf(fp,"%s",TOPartNo4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOPartNo5=NULL;
	string TOPartNo5Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartNo5",&TOPartNo5))goto EXIT;  
	if(!nlsIsStrNull(TOPartNo5)) TOPartNo5Dup=nlsStrDup(TOPartNo5);
	printf("\n TOPartNo5Dup :%s",TOPartNo5Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartNo5Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartNo5Dup);
		if(nlsStrStr(TOPartNo5Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartNo5Dup,"\n")!= NULL) low_strrpl(TOPartNo5Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartNo5Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartNo5Dup))		
		{
			fprintf(fp,"%s",TOPartNo5Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartNo6=NULL;
	string TOPartNo6Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartNo6",&TOPartNo6))goto EXIT;  
	if(!nlsIsStrNull(TOPartNo6)) TOPartNo6Dup=nlsStrDup(TOPartNo6);
	printf("\n TOPartNo6Dup :%s",TOPartNo6Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartNo6Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartNo6Dup);
		if(nlsStrStr(TOPartNo6Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartNo6Dup,"\n")!= NULL) low_strrpl(TOPartNo6Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartNo6Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartNo6Dup))		
		{
			fprintf(fp,"%s",TOPartNo6Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartNo7=NULL;
	string TOPartNo7Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartNo7",&TOPartNo7))goto EXIT;  
	if(!nlsIsStrNull(TOPartNo7)) TOPartNo7Dup=nlsStrDup(TOPartNo7);
	printf("\n TOPartNo7Dup :%s",TOPartNo7Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartNo7Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartNo7Dup);
		if(nlsStrStr(TOPartNo7Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartNo7Dup,"\n")!= NULL) low_strrpl(TOPartNo7Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartNo7Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartNo7Dup))		
		{
			fprintf(fp,"%s",TOPartNo7Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartNo8=NULL;
	string TOPartNo8Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartNo8",&TOPartNo8))goto EXIT;  
	if(!nlsIsStrNull(TOPartNo8)) TOPartNo8Dup=nlsStrDup(TOPartNo8);
	printf("\n TOPartNo8Dup :%s",TOPartNo8Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartNo8Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartNo8Dup);
		if(nlsStrStr(TOPartNo8Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartNo8Dup,"\n")!= NULL) low_strrpl(TOPartNo8Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartNo8Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartNo8Dup))		
		{
			fprintf(fp,"%s",TOPartNo8Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartNo9=NULL;
	string TOPartNo9Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartNo9",&TOPartNo9))goto EXIT;  
	if(!nlsIsStrNull(TOPartNo9)) TOPartNo9Dup=nlsStrDup(TOPartNo9);
	printf("\n TOPartNo9Dup :%s",TOPartNo9Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartNo9Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartNo9Dup);
		if(nlsStrStr(TOPartNo9Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartNo9Dup,"\n")!= NULL) low_strrpl(TOPartNo9Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartNo9Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartNo9Dup))		
		{
			fprintf(fp,"%s",TOPartNo9Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string TOPartNo10=NULL;
	string TOPartNo10Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartNo10",&TOPartNo10))goto EXIT;  
	if(!nlsIsStrNull(TOPartNo10)) TOPartNo10Dup=nlsStrDup(TOPartNo10);
	printf("\n TOPartNo10Dup :%s",TOPartNo10Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartNo10Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartNo10Dup);
		if(nlsStrStr(TOPartNo10Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartNo10Dup,"\n")!= NULL) low_strrpl(TOPartNo10Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartNo10Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartNo10Dup))		
		{
			fprintf(fp,"%s",TOPartNo10Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartRev1=NULL;
	string TOPartRev1Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartRev1",&TOPartRev1))goto EXIT;  
	if(!nlsIsStrNull(TOPartRev1)) TOPartRev1Dup=nlsStrDup(TOPartRev1);
	printf("\n TOPartRev1Dup :%s",TOPartRev1Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartRev1Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartRev1Dup);
		if(nlsStrStr(TOPartRev1Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartRev1Dup,"\n")!= NULL) low_strrpl(TOPartRev1Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartRev1Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartRev1Dup))		
		{
			fprintf(fp,"%s",TOPartRev1Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOPartRev2=NULL;
	string TOPartRev2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartRev2",&TOPartRev2))goto EXIT;  
	if(!nlsIsStrNull(TOPartRev2)) TOPartRev2Dup=nlsStrDup(TOPartRev2);
	printf("\n TOPartRev2Dup :%s",TOPartRev2Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartRev2Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartRev2Dup);
		if(nlsStrStr(TOPartRev2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartRev2Dup,"\n")!= NULL) low_strrpl(TOPartRev2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartRev2Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartRev2Dup))		
		{
			fprintf(fp,"%s",TOPartRev2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartRev3=NULL;
	string TOPartRev3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartRev3",&TOPartRev3))goto EXIT;  
	if(!nlsIsStrNull(TOPartRev3)) TOPartRev3Dup=nlsStrDup(TOPartRev3);
	printf("\n TOPartRev3Dup :%s",TOPartRev3Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartRev3Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartRev3Dup);
		if(nlsStrStr(TOPartRev3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartRev3Dup,"\n")!= NULL) low_strrpl(TOPartRev3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartRev3Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartRev3Dup))		
		{
			fprintf(fp,"%s",TOPartRev3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartRev4=NULL;
	string TOPartRev4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartRev4",&TOPartRev4))goto EXIT;  
	if(!nlsIsStrNull(TOPartRev4)) TOPartRev4Dup=nlsStrDup(TOPartRev4);
	printf("\n TOPartRev4Dup :%s",TOPartRev4Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartRev4Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartRev4Dup);
		if(nlsStrStr(TOPartRev4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartRev4Dup,"\n")!= NULL) low_strrpl(TOPartRev4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartRev4Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartRev4Dup))		
		{
			fprintf(fp,"%s",TOPartRev4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartRev5=NULL;
	string TOPartRev5Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartRev5",&TOPartRev5))goto EXIT;  
	if(!nlsIsStrNull(TOPartRev5)) TOPartRev5Dup=nlsStrDup(TOPartRev5);
	printf("\n TOPartRev5Dup :%s",TOPartRev5Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartRev5Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartRev5Dup);
		if(nlsStrStr(TOPartRev5Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartRev5Dup,"\n")!= NULL) low_strrpl(TOPartRev5Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartRev5Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartRev5Dup))		
		{
			fprintf(fp,"%s",TOPartRev5Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartRev6=NULL;
	string TOPartRev6Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartRev6",&TOPartRev6))goto EXIT;  
	if(!nlsIsStrNull(TOPartRev6)) TOPartRev6Dup=nlsStrDup(TOPartRev6);
	printf("\n TOPartRev6Dup :%s",TOPartRev6Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartRev6Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartRev6Dup);
		if(nlsStrStr(TOPartRev6Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartRev6Dup,"\n")!= NULL) low_strrpl(TOPartRev6Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartRev6Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartRev6Dup))		
		{
			fprintf(fp,"%s",TOPartRev6Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartRev7=NULL;
	string TOPartRev7Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartRev7",&TOPartRev7))goto EXIT;  
	if(!nlsIsStrNull(TOPartRev7)) TOPartRev7Dup=nlsStrDup(TOPartRev7);
	printf("\n TOPartRev7Dup :%s",TOPartRev7Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartRev7Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartRev7Dup);
		if(nlsStrStr(TOPartRev7Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartRev7Dup,"\n")!= NULL) low_strrpl(TOPartRev7Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartRev7Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartRev7Dup))		
		{
			fprintf(fp,"%s",TOPartRev7Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOPartRev8=NULL;
	string TOPartRev8Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartRev8",&TOPartRev8))goto EXIT;  
	if(!nlsIsStrNull(TOPartRev8)) TOPartRev8Dup=nlsStrDup(TOPartRev8);
	printf("\n TOPartRev8Dup :%s",TOPartRev8Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartRev8Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartRev8Dup);
		if(nlsStrStr(TOPartRev8Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartRev8Dup,"\n")!= NULL) low_strrpl(TOPartRev8Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartRev8Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartRev8Dup))		
		{
			fprintf(fp,"%s",TOPartRev8Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartRev9=NULL;
	string TOPartRev9Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartRev9",&TOPartRev9))goto EXIT;  
	if(!nlsIsStrNull(TOPartRev9)) TOPartRev9Dup=nlsStrDup(TOPartRev9);
	printf("\n TOPartRev9Dup :%s",TOPartRev9Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartRev9Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartRev9Dup);
		if(nlsStrStr(TOPartRev9Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartRev9Dup,"\n")!= NULL) low_strrpl(TOPartRev9Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartRev9Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartRev9Dup))		
		{
			fprintf(fp,"%s",TOPartRev9Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartRev10=NULL;
	string TOPartRev10Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartRev10",&TOPartRev10))goto EXIT;  
	if(!nlsIsStrNull(TOPartRev10)) TOPartRev10Dup=nlsStrDup(TOPartRev10);
	printf("\n TOPartRev10Dup :%s",TOPartRev10Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartRev10Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartRev10Dup);
		if(nlsStrStr(TOPartRev10Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartRev10Dup,"\n")!= NULL) low_strrpl(TOPartRev10Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartRev10Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartRev10Dup))		
		{
			fprintf(fp,"%s",TOPartRev10Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartSeq1=NULL;
	string TOPartSeq1Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartSeq1",&TOPartSeq1))goto EXIT;  
	if(!nlsIsStrNull(TOPartSeq1)) TOPartSeq1Dup=nlsStrDup(TOPartSeq1);
	printf("\n TOPartSeq1Dup :%s",TOPartSeq1Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartSeq1Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartSeq1Dup);
		if(nlsStrStr(TOPartSeq1Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartSeq1Dup,"\n")!= NULL) low_strrpl(TOPartSeq1Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartSeq1Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartSeq1Dup))		
		{
			fprintf(fp,"%s",TOPartSeq1Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string TOPartSeq2=NULL;
	string TOPartSeq2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartSeq2",&TOPartSeq2))goto EXIT;  
	if(!nlsIsStrNull(TOPartSeq2)) TOPartSeq2Dup=nlsStrDup(TOPartSeq2);
	printf("\n TOPartSeq2Dup :%s",TOPartSeq2Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartSeq2Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartSeq2Dup);
		if(nlsStrStr(TOPartSeq2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartSeq2Dup,"\n")!= NULL) low_strrpl(TOPartSeq2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartSeq2Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartSeq2Dup))		
		{
			fprintf(fp,"%s",TOPartSeq2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartSeq3=NULL;
	string TOPartSeq3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartSeq3",&TOPartSeq3))goto EXIT;  
	if(!nlsIsStrNull(TOPartSeq3)) TOPartSeq3Dup=nlsStrDup(TOPartSeq3);
	printf("\n TOPartSeq3Dup :%s",TOPartSeq3Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartSeq3Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartSeq3Dup);
		if(nlsStrStr(TOPartSeq3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartSeq3Dup,"\n")!= NULL) low_strrpl(TOPartSeq3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartSeq3Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartSeq3Dup))		
		{
			fprintf(fp,"%s",TOPartSeq3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartSeq4=NULL;
	string TOPartSeq4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartSeq4",&TOPartSeq4))goto EXIT;  
	if(!nlsIsStrNull(TOPartSeq4)) TOPartSeq4Dup=nlsStrDup(TOPartSeq4);
	printf("\n TOPartSeq4Dup :%s",TOPartSeq4Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartSeq4Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartSeq4Dup);
		if(nlsStrStr(TOPartSeq4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartSeq4Dup,"\n")!= NULL) low_strrpl(TOPartSeq4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartSeq4Dup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(TOPartSeq4Dup))		
		{
			fprintf(fp,"%s",TOPartSeq4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	string TOPartSeq5=NULL;
	string TOPartSeq5Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartSeq5",&TOPartSeq5))goto EXIT;  
	if(!nlsIsStrNull(TOPartSeq5)) TOPartSeq5Dup=nlsStrDup(TOPartSeq5);
	printf("\n TOPartSeq5Dup :%s",TOPartSeq5Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartSeq5Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartSeq5Dup);
		if(nlsStrStr(TOPartSeq5Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartSeq5Dup,"\n")!= NULL) low_strrpl(TOPartSeq5Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartSeq5Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartSeq5Dup))		
		{
			fprintf(fp,"%s",TOPartSeq5Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartSeq6=NULL;
	string TOPartSeq6Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartSeq6",&TOPartSeq6))goto EXIT;  
	if(!nlsIsStrNull(TOPartSeq6)) TOPartSeq6Dup=nlsStrDup(TOPartSeq6);
	printf("\n TOPartSeq6Dup :%s",TOPartSeq6Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartSeq6Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartSeq6Dup);
		if(nlsStrStr(TOPartSeq6Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartSeq6Dup,"\n")!= NULL) low_strrpl(TOPartSeq6Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartSeq6Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartSeq6Dup))		
		{
			fprintf(fp,"%s",TOPartSeq6Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOPartSeq7=NULL;
	string TOPartSeq7Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartSeq7",&TOPartSeq7))goto EXIT;  
	if(!nlsIsStrNull(TOPartSeq7)) TOPartSeq7Dup=nlsStrDup(TOPartSeq7);
	printf("\n TOPartSeq7Dup :%s",TOPartSeq7Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartSeq7Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartSeq7Dup);
		if(nlsStrStr(TOPartSeq7Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartSeq7Dup,"\n")!= NULL) low_strrpl(TOPartSeq7Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartSeq7Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartSeq7Dup))		
		{
			fprintf(fp,"%s",TOPartSeq7Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartSeq8=NULL;
	string TOPartSeq8Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartSeq8",&TOPartSeq8))goto EXIT;  
	if(!nlsIsStrNull(TOPartSeq8)) TOPartSeq8Dup=nlsStrDup(TOPartSeq8);
	printf("\n TOPartSeq8Dup :%s",TOPartSeq8Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartSeq8Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartSeq8Dup);
		if(nlsStrStr(TOPartSeq8Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartSeq8Dup,"\n")!= NULL) low_strrpl(TOPartSeq8Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartSeq8Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartSeq8Dup))		
		{
			fprintf(fp,"%s",TOPartSeq8Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartSeq9=NULL;
	string TOPartSeq9Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartSeq9",&TOPartSeq9))goto EXIT;  
	if(!nlsIsStrNull(TOPartSeq9)) TOPartSeq9Dup=nlsStrDup(TOPartSeq9);
	printf("\n TOPartSeq9Dup :%s",TOPartSeq9Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartSeq9Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartSeq9Dup);
		if(nlsStrStr(TOPartSeq9Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartSeq9Dup,"\n")!= NULL) low_strrpl(TOPartSeq9Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartSeq9Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartSeq9Dup))		
		{
			fprintf(fp,"%s",TOPartSeq9Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOPartSeq10=NULL;
	string TOPartSeq10Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPartSeq10",&TOPartSeq10))goto EXIT;  
	if(!nlsIsStrNull(TOPartSeq10)) TOPartSeq10Dup=nlsStrDup(TOPartSeq10);
	printf("\n TOPartSeq10Dup :%s",TOPartSeq10Dup);fflush(stdout);
	if(!nlsIsStrNull(TOPartSeq10Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOPartSeq10Dup);
		if(nlsStrStr(TOPartSeq10Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPartSeq10Dup,"\n")!= NULL) low_strrpl(TOPartSeq10Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPartSeq10Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPartSeq10Dup))		
		{
			fprintf(fp,"%s",TOPartSeq10Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOPhotos=NULL;
	string TOPhotosDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOPhotos",&TOPhotos))goto EXIT;  
	if(!nlsIsStrNull(TOPhotos)) TOPhotosDup=nlsStrDup(TOPhotos);
	printf("\n TOPhotosDup :%s",TOPhotosDup);fflush(stdout);
	if(!nlsIsStrNull(TOPhotosDup))
	{
		nlsStrTrimTrailWhiteSpace(TOPhotosDup);
		if(nlsStrStr(TOPhotosDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOPhotosDup,"\n")!= NULL) low_strrpl(TOPhotosDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOPhotosDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOPhotosDup))		
		{
			fprintf(fp,"%s",TOPhotosDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOQAHead=NULL;
	string TOQAHeadDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOQAHead",&TOQAHead))goto EXIT;  
	if(!nlsIsStrNull(TOQAHead)) TOQAHeadDup=nlsStrDup(TOQAHead);
	printf("\n TOQAHeadDup :%s",TOQAHeadDup);fflush(stdout);
	if(!nlsIsStrNull(TOQAHeadDup))
	{
		nlsStrTrimTrailWhiteSpace(TOQAHeadDup);
		if(nlsStrStr(TOQAHeadDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOQAHeadDup,"\n")!= NULL) low_strrpl(TOQAHeadDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOQAHeadDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOQAHeadDup))		
		{
			fprintf(fp,"%s",TOQAHeadDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOQAHeadcomments=NULL;
	string TOQAHeadcommentsDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOQAHeadcomments",&TOQAHeadcomments))goto EXIT;  
	if(!nlsIsStrNull(TOQAHeadcomments)) TOQAHeadcommentsDup=nlsStrDup(TOQAHeadcomments);
	printf("\n TOQAHeadcommentsDup :%s",TOQAHeadcommentsDup);fflush(stdout);
	if(!nlsIsStrNull(TOQAHeadcommentsDup))
	{
		nlsStrTrimTrailWhiteSpace(TOQAHeadcommentsDup);
		if(nlsStrStr(TOQAHeadcommentsDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOQAHeadcommentsDup,"\n")!= NULL) low_strrpl(TOQAHeadcommentsDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOQAHeadcommentsDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOQAHeadcommentsDup))		
		{
			fprintf(fp,"%s",TOQAHeadcommentsDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOQAReviewer=NULL;
	string TOQAReviewerDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOQAReviewer",&TOQAReviewer))goto EXIT;  
	if(!nlsIsStrNull(TOQAReviewer)) TOQAReviewerDup=nlsStrDup(TOQAReviewer);
	printf("\n TOQAReviewerDup :%s",TOQAReviewerDup);fflush(stdout);
	if(!nlsIsStrNull(TOQAReviewerDup))
	{
		nlsStrTrimTrailWhiteSpace(TOQAReviewerDup);
		if(nlsStrStr(TOQAReviewerDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOQAReviewerDup,"\n")!= NULL) low_strrpl(TOQAReviewerDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOQAReviewerDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOQAReviewerDup))		
		{
			fprintf(fp,"%s",TOQAReviewerDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOQAcomments=NULL;
	string TOQAcommentsDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOQAcomments",&TOQAcomments))goto EXIT;  
	if(!nlsIsStrNull(TOQAcomments)) TOQAcommentsDup=nlsStrDup(TOQAcomments);
	printf("\n TOQAcommentsDup :%s",TOQAcommentsDup);fflush(stdout);
	if(!nlsIsStrNull(TOQAcommentsDup))
	{
		nlsStrTrimTrailWhiteSpace(TOQAcommentsDup);
		if(nlsStrStr(TOQAcommentsDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOQAcommentsDup,"\n")!= NULL) low_strrpl(TOQAcommentsDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOQAcommentsDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOQAcommentsDup))		
		{
			fprintf(fp,"%s",TOQAcommentsDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOReason=NULL;
	string TOReasonDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOReason",&TOReason))goto EXIT;  
	if(!nlsIsStrNull(TOReason)) TOReasonDup=nlsStrDup(TOReason);
	printf("\n TOReasonDup :%s",TOReasonDup);fflush(stdout);
	if(!nlsIsStrNull(TOReasonDup))
	{
		nlsStrTrimTrailWhiteSpace(TOReasonDup);
		if(nlsStrStr(TOReasonDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOReasonDup,"\n")!= NULL) low_strrpl(TOReasonDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOReasonDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOReasonDup))		
		{
			fprintf(fp,"%s",TOReasonDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TORefNo=NULL;
	string TORefNoDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TORefNo",&TORefNo))goto EXIT;  
	if(!nlsIsStrNull(TORefNo)) TORefNoDup=nlsStrDup(TORefNo);
	printf("\n TORefNoDup :%s",TORefNoDup);fflush(stdout);
	if(!nlsIsStrNull(TORefNoDup))
	{
		nlsStrTrimTrailWhiteSpace(TORefNoDup);
		if(nlsStrStr(TORefNoDup,"\n")!= NULL)
		{
			if(nlsStrStr(TORefNoDup,"\n")!= NULL) low_strrpl(TORefNoDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TORefNoDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TORefNoDup))		
		{
			fprintf(fp,"%s",TORefNoDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TORefNo2=NULL;
	string TORefNo2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TORefNo2",&TORefNo2))goto EXIT;  
	if(!nlsIsStrNull(TORefNo2)) TORefNo2Dup=nlsStrDup(TORefNo2);
	printf("\n TORefNo2Dup :%s",TORefNo2Dup);fflush(stdout);
	if(!nlsIsStrNull(TORefNo2Dup))
	{
		nlsStrTrimTrailWhiteSpace(TORefNo2Dup);
		if(nlsStrStr(TORefNo2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TORefNo2Dup,"\n")!= NULL) low_strrpl(TORefNo2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TORefNo2Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TORefNo2Dup))		
		{
			fprintf(fp,"%s",TORefNo2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TORefNo3=NULL;
	string TORefNo3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TORefNo3",&TORefNo3))goto EXIT;  
	if(!nlsIsStrNull(TORefNo3)) TORefNo3Dup=nlsStrDup(TORefNo3);
	printf("\n TORefNo3Dup :%s",TORefNo3Dup);fflush(stdout);
	if(!nlsIsStrNull(TORefNo3Dup))
	{
		nlsStrTrimTrailWhiteSpace(TORefNo3Dup);
		if(nlsStrStr(TORefNo3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TORefNo3Dup,"\n")!= NULL) low_strrpl(TORefNo3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TORefNo3Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TORefNo3Dup))		
		{
			fprintf(fp,"%s",TORefNo3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TORefNo4=NULL;
	string TORefNo4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TORefNo4",&TORefNo4))goto EXIT;  
	if(!nlsIsStrNull(TORefNo4)) TORefNo4Dup=nlsStrDup(TORefNo4);
	printf("\n TORefNo4Dup :%s",TORefNo4Dup);fflush(stdout);
	if(!nlsIsStrNull(TORefNo4Dup))
	{
		nlsStrTrimTrailWhiteSpace(TORefNo4Dup);
		if(nlsStrStr(TORefNo4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TORefNo4Dup,"\n")!= NULL) low_strrpl(TORefNo4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TORefNo4Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TORefNo4Dup))		
		{
			fprintf(fp,"%s",TORefNo4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TORefNo5=NULL;
	string TORefNo5Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TORefNo5",&TORefNo5))goto EXIT;  
	if(!nlsIsStrNull(TORefNo5)) TORefNo5Dup=nlsStrDup(TORefNo5);
	printf("\n TORefNo5Dup :%s",TORefNo5Dup);fflush(stdout);
	if(!nlsIsStrNull(TORefNo5Dup))
	{
		nlsStrTrimTrailWhiteSpace(TORefNo5Dup);
		if(nlsStrStr(TORefNo5Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TORefNo5Dup,"\n")!= NULL) low_strrpl(TORefNo5Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TORefNo5Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TORefNo5Dup))		
		{
			fprintf(fp,"%s",TORefNo5Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TORefNo6=NULL;
	string TORefNo6Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TORefNo6",&TORefNo6))goto EXIT;  
	if(!nlsIsStrNull(TORefNo6)) TORefNo6Dup=nlsStrDup(TORefNo6);
	printf("\n TORefNo6Dup :%s",TORefNo6Dup);fflush(stdout);
	if(!nlsIsStrNull(TORefNo6Dup))
	{
		nlsStrTrimTrailWhiteSpace(TORefNo6Dup);
		if(nlsStrStr(TORefNo6Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TORefNo6Dup,"\n")!= NULL) low_strrpl(TORefNo6Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TORefNo6Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TORefNo6Dup))		
		{
			fprintf(fp,"%s",TORefNo6Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TORefNo7=NULL;
	string TORefNo7Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TORefNo7",&TORefNo7))goto EXIT;  
	if(!nlsIsStrNull(TORefNo7)) TORefNo7Dup=nlsStrDup(TORefNo7);
	printf("\n TORefNo7Dup :%s",TORefNo7Dup);fflush(stdout);
	if(!nlsIsStrNull(TORefNo7Dup))
	{
		nlsStrTrimTrailWhiteSpace(TORefNo7Dup);
		if(nlsStrStr(TORefNo7Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TORefNo7Dup,"\n")!= NULL) low_strrpl(TORefNo7Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TORefNo7Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TORefNo7Dup))		
		{
			fprintf(fp,"%s",TORefNo7Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TORefNo8=NULL;
	string TORefNo8Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TORefNo8",&TORefNo8))goto EXIT;  
	if(!nlsIsStrNull(TORefNo8)) TORefNo8Dup=nlsStrDup(TORefNo8);
	printf("\n TORefNo8Dup :%s",TORefNo8Dup);fflush(stdout);
	if(!nlsIsStrNull(TORefNo8Dup))
	{
		nlsStrTrimTrailWhiteSpace(TORefNo8Dup);
		if(nlsStrStr(TORefNo8Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TORefNo8Dup,"\n")!= NULL) low_strrpl(TORefNo8Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TORefNo8Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TORefNo8Dup))		
		{
			fprintf(fp,"%s",TORefNo8Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TORefNo9=NULL;
	string TORefNo9Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TORefNo9",&TORefNo9))goto EXIT;  
	if(!nlsIsStrNull(TORefNo9)) TORefNo9Dup=nlsStrDup(TORefNo9);
	printf("\n TORefNo9Dup :%s",TORefNo9Dup);fflush(stdout);
	if(!nlsIsStrNull(TORefNo9Dup))
	{
		nlsStrTrimTrailWhiteSpace(TORefNo9Dup);
		if(nlsStrStr(TORefNo9Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TORefNo9Dup,"\n")!= NULL) low_strrpl(TORefNo9Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TORefNo9Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TORefNo9Dup))		
		{
			fprintf(fp,"%s",TORefNo9Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TORefNo10=NULL;
	string TORefNo10Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TORefNo10",&TORefNo10))goto EXIT;  
	if(!nlsIsStrNull(TORefNo10)) TORefNo10Dup=nlsStrDup(TORefNo10);
	printf("\n TORefNo10Dup :%s",TORefNo10Dup);fflush(stdout);
	if(!nlsIsStrNull(TORefNo10Dup))
	{
		nlsStrTrimTrailWhiteSpace(TORefNo10Dup);
		if(nlsStrStr(TORefNo10Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TORefNo10Dup,"\n")!= NULL) low_strrpl(TORefNo10Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TORefNo10Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TORefNo10Dup))		
		{
			fprintf(fp,"%s",TORefNo10Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOSCMReviewer=NULL;
	string TOSCMReviewerDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOSCMReviewer",&TOSCMReviewer))goto EXIT;  
	if(!nlsIsStrNull(TOSCMReviewer)) TOSCMReviewerDup=nlsStrDup(TOSCMReviewer);
	printf("\n TOSCMReviewerDup :%s",TOSCMReviewerDup);fflush(stdout);
	if(!nlsIsStrNull(TOSCMReviewerDup))
	{
		nlsStrTrimTrailWhiteSpace(TOSCMReviewerDup);
		if(nlsStrStr(TOSCMReviewerDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOSCMReviewerDup,"\n")!= NULL) low_strrpl(TOSCMReviewerDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOSCMReviewerDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOSCMReviewerDup))		
		{
			fprintf(fp,"%s",TOSCMReviewerDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOSTDReviewer=NULL;
	string TOSTDReviewerDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOSTDReviewer",&TOSTDReviewer))goto EXIT;  
	if(!nlsIsStrNull(TOSTDReviewer)) TOSTDReviewerDup=nlsStrDup(TOSTDReviewer);
	printf("\n TOSTDReviewerDup :%s",TOSTDReviewerDup);fflush(stdout);
	if(!nlsIsStrNull(TOSTDReviewerDup))
	{
		nlsStrTrimTrailWhiteSpace(TOSTDReviewerDup);
		if(nlsStrStr(TOSTDReviewerDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOSTDReviewerDup,"\n")!= NULL) low_strrpl(TOSTDReviewerDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOSTDReviewerDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOSTDReviewerDup))		
		{
			fprintf(fp,"%s",TOSTDReviewerDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOSubArea=NULL;
	string TOSubAreaDup=NULL;
	string Vall=NULL;
	ObjectPtr orgObjj=NULL;
	 int SubAreaList=0;
	 int subareacount=0;
	int lo=0;
if(dstat = objNameValueSize(TCPartObjP, "t5TOSubArea",&SubAreaList)) goto EXIT;
if(dstat = objCopy(&orgObjj,TCPartObjP)) goto EXIT;
printf("\n SubAreaList  ...%d",SubAreaList);fflush(stdout);

if(SubAreaList>0)
	{
		TOSubAreaDup = (char *)calloc(SubAreaList,  sizeof(char));
		//TOSubAreaDup =nlsStrAlloc(1000);
		nlsStrCpy(TOSubAreaDup, "");
	}

	for(lo=0;lo<SubAreaList;lo++)
	{
	if(TOSubArea) TOSubArea=NULL;
	if(Vall) Vall=NULL;
	if(dstat = objNameValueGet_byi(orgObjj,t5TOSubAreaAttr,lo,&TOSubArea,&Vall)) goto EXIT;

	  printf("\n Vall: %s",Vall);fflush(stdout);

		if(nlsStrCmp(Vall,"+")== 0)
		{
		  printf("\n ...TOSubArea Selected ...%s %s",TOSubArea,Vall);fflush(stdout);

			if(!nlsIsStrNull(TOSubArea))
			{
				nlsStrTrimTrailWhiteSpace(TOSubArea);
				if(nlsStrStr(TOSubArea,"\n")!= NULL)
				{
					if(nlsStrStr(TOSubArea,"\n")!= NULL) low_strrpl(TOSubArea,'\n',';');
					printf("\n After Remove TOSubArea==>[%s]\n",TOSubArea);fflush(stdout);
				}

				nlsStrCat(TOSubAreaDup,TOSubArea);
				nlsStrCat(TOSubAreaDup,"#");
				subareacount++;
			}
		}

	}

	char Strsubareacount[10];
	itoa(subareacount,Strsubareacount,10);
	printf("\n Strsubareacount==>[%s]\n",Strsubareacount);fflush(stdout);
	//nlsStrCat(TOSubAreaDup,Strsubareacount);

	if(!nlsIsStrNull(TOSubAreaDup))		
		{
			fprintf(fp,"%s",TOSubAreaDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


		if(!nlsIsStrNull(Strsubareacount))		
		{
			fprintf(fp,"%s",Strsubareacount);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOTSReviewer=NULL;
	string TOTSReviewerDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOTSReviewer",&TOTSReviewer))goto EXIT; 
	if(!nlsIsStrNull(TOTSReviewer)) TOTSReviewerDup=nlsStrDup(TOTSReviewer);
	printf("\n TOTSReviewerDup :%s",TOTSReviewerDup);fflush(stdout);
	if(!nlsIsStrNull(TOTSReviewerDup))
	{
		nlsStrTrimTrailWhiteSpace(TOTSReviewerDup);
		if(nlsStrStr(TOTSReviewerDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOTSReviewerDup,"\n")!= NULL) low_strrpl(TOTSReviewerDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOTSReviewerDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOTSReviewerDup))		
		{
			fprintf(fp,"%s",TOTSReviewerDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOTScomments=NULL;
	string TOTScommentsDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOTScomments",&TOTScomments))goto EXIT; 
	if(!nlsIsStrNull(TOTScomments)) TOTScommentsDup=nlsStrDup(TOTScomments);
	printf("\n TOTScommentsDup :%s",TOTScommentsDup);fflush(stdout);
	if(!nlsIsStrNull(TOTScommentsDup))
	{
		nlsStrTrimTrailWhiteSpace(TOTScommentsDup);
		if(nlsStrStr(TOTScommentsDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOTScommentsDup,"\n")!= NULL) low_strrpl(TOTScommentsDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOTScommentsDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOTScommentsDup))		
		{
			fprintf(fp,"%s",TOTScommentsDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOTestDetails=NULL;
	string TOTestDetailsDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOTestDetails",&TOTestDetails))goto EXIT; 
	if(!nlsIsStrNull(TOTestDetails)) TOTestDetailsDup=nlsStrDup(TOTestDetails);
	printf("\n TOTestDetailsDup :%s",TOTestDetailsDup);fflush(stdout);
	if(!nlsIsStrNull(TOTestDetailsDup))
	{
		nlsStrTrimTrailWhiteSpace(TOTestDetailsDup);
		if(nlsStrStr(TOTestDetailsDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOTestDetailsDup,"\n")!= NULL) low_strrpl(TOTestDetailsDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOTestDetailsDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOTestDetailsDup))		
		{
			fprintf(fp,"%s",TOTestDetailsDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOTryOutDt=NULL;
	string TOTryOutDtDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOTryOutDt",&TOTryOutDt))goto EXIT;  // DATE
	if(!nlsIsStrNull(TOTryOutDt)) TOTryOutDtDup=nlsStrDup(TOTryOutDt);
	printf("\n TOTryOutDtDup :%s",TOTryOutDtDup);fflush(stdout);
	if(!nlsIsStrNull(TOTryOutDtDup))
	{
		nlsStrTrimTrailWhiteSpace(TOTryOutDtDup);
		if(nlsStrStr(TOTryOutDtDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOTryOutDtDup,"\n")!= NULL) low_strrpl(TOTryOutDtDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOTryOutDtDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOTryOutDtDup))		
		{
			fprintf(fp,"%s",TOTryOutDtDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOVDReviewer=NULL;
	string TOVDReviewerDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVDReviewer",&TOVDReviewer))goto EXIT; 
	if(!nlsIsStrNull(TOVDReviewer)) TOVDReviewerDup=nlsStrDup(TOVDReviewer);
	printf("\n TOVDReviewerDup :%s",TOVDReviewerDup);fflush(stdout);
	if(!nlsIsStrNull(TOVDReviewerDup))
	{
		nlsStrTrimTrailWhiteSpace(TOVDReviewerDup);
		if(nlsStrStr(TOVDReviewerDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVDReviewerDup,"\n")!= NULL) low_strrpl(TOVDReviewerDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVDReviewerDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVDReviewerDup))		
		{
			fprintf(fp,"%s",TOVDReviewerDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOVDcomments=NULL;
	string TOVDcommentsDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVDcomments",&TOVDcomments))goto EXIT; 
	if(!nlsIsStrNull(TOVDcomments)) TOVDcommentsDup=nlsStrDup(TOVDcomments);
	printf("\n TOVDcommentsDup :%s",TOVDcommentsDup);fflush(stdout);
	if(!nlsIsStrNull(TOVDcommentsDup))
	{
		nlsStrTrimTrailWhiteSpace(TOVDcommentsDup);
		if(nlsStrStr(TOVDcommentsDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVDcommentsDup,"\n")!= NULL) low_strrpl(TOVDcommentsDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVDcommentsDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVDcommentsDup))		
		{
			fprintf(fp,"%s",TOVDcommentsDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOVQAReviewer=NULL;
	string TOVQAReviewerDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVQAReviewer",&TOVQAReviewer))goto EXIT; 
	if(!nlsIsStrNull(TOVQAReviewer)) TOVQAReviewerDup=nlsStrDup(TOVQAReviewer);
	printf("\n TOVQAReviewerDup :%s",TOVQAReviewerDup);fflush(stdout);
	if(!nlsIsStrNull(TOVQAReviewerDup))
	{
		nlsStrTrimTrailWhiteSpace(TOVQAReviewerDup);
		if(nlsStrStr(TOVQAReviewerDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVQAReviewerDup,"\n")!= NULL) low_strrpl(TOVQAReviewerDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVQAReviewerDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVQAReviewerDup))		
		{
			fprintf(fp,"%s",TOVQAReviewerDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOVQAcomments=NULL;
	string TOVQAcommentsDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVQAcomments",&TOVQAcomments))goto EXIT; 
	if(!nlsIsStrNull(TOVQAcomments)) TOVQAcommentsDup=nlsStrDup(TOVQAcomments);
	printf("\n TOVQAcommentsDup :%s",TOVQAcommentsDup);fflush(stdout);
	if(!nlsIsStrNull(TOVQAcommentsDup))
	{
		nlsStrTrimTrailWhiteSpace(TOVQAcommentsDup);
		if(nlsStrStr(TOVQAcommentsDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVQAcommentsDup,"\n")!= NULL) low_strrpl(TOVQAcommentsDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVQAcommentsDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVQAcommentsDup))		
		{
			fprintf(fp,"%s",TOVQAcommentsDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOVehNo=NULL;
	string TOVehNoDup=NULL;
	 Mod_value1=NULL;
	 orgObj=NULL;
	 int TOVehlist=0;
	 int Vehcount=0;
	int lm=0;
if(dstat = objNameValueSize(TCPartObjP, "t5TOVehNo",&TOVehlist)) goto EXIT;
if(dstat = objCopy(&orgObj,TCPartObjP)) goto EXIT;
printf("\n TOVehlist  ...%d",TOVehlist);fflush(stdout);

if(TOVehlist>0)
	{
		TOVehNoDup = (char *)calloc(TOVehlist,  sizeof(char));
		// TOVehNoDup = nlsStrAlloc(1000);;
		nlsStrCpy(TOVehNoDup, "");
	}

	for(lm=0;lm<TOVehlist;lm++)
	{
	if(TOVehNo) TOVehNo=NULL;
	if(Mod_value1) Mod_value1=NULL;
	if(dstat = objNameValueGet_byi(orgObj,t5TOVehNoAttr,lm,&TOVehNo,&Mod_value1)) goto EXIT;
	  printf("\n Mod_value1: %s",Mod_value1);fflush(stdout);


		if(nlsStrCmp(Mod_value1,"+")== 0)
		{
		  printf("\n ...TOVehNo Selected ...%s %s",TOVehNo,Mod_value1);fflush(stdout);

			if(!nlsIsStrNull(TOVehNo))
			{
				nlsStrTrimTrailWhiteSpace(TOVehNo);
				if(nlsStrStr(TOVehNo,"\n")!= NULL)
				{
					if(nlsStrStr(TOVehNo,"\n")!= NULL) low_strrpl(TOVehNo,'\n',';');
					printf("\n After Remove TOVehNo==>[%s]\n",TOVehNo);fflush(stdout);
				}

				nlsStrCat(TOVehNoDup,TOVehNo);
				nlsStrCat(TOVehNoDup,"#");
				Vehcount++;
			}
		}

	}

	//nlsStrCat(TOVehNoDup,StrVehcount);

	if(!nlsIsStrNull(TOVehNoDup))		
		{
			fprintf(fp,"%s",TOVehNoDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	char StrVehcount[10];
	itoa(Vehcount,StrVehcount,10);
	printf("\n StrVehcount==>[%s]\n",StrVehcount);fflush(stdout);

	if(!nlsIsStrNull(StrVehcount))		
		{
			fprintf(fp,"%s",StrVehcount);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOVenLogin=NULL;
	string TOVenLoginDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVenLogin",&TOVenLogin))goto EXIT;  
	if(!nlsIsStrNull(TOVenLogin)) TOVenLoginDup=nlsStrDup(TOVenLogin);
	printf("\n TOVenLoginDup :%s",TOVenLoginDup);fflush(stdout);
	if(!nlsIsStrNull(TOVenLoginDup))
	{
		nlsStrTrimTrailWhiteSpace(TOVenLoginDup);
		if(nlsStrStr(TOVenLoginDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVenLoginDup,"\n")!= NULL) low_strrpl(TOVenLoginDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVenLoginDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVenLoginDup))		
		{
			fprintf(fp,"%s",TOVenLoginDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOVenName=NULL;
	string TOVenNameDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVenName",&TOVenName))goto EXIT;  
	if(!nlsIsStrNull(TOVenName)) TOVenNameDup=nlsStrDup(TOVenName);
	printf("\n TOVenNameDup :%s",TOVenNameDup);fflush(stdout);
	if(!nlsIsStrNull(TOVenNameDup))
	{
		nlsStrTrimTrailWhiteSpace(TOVenNameDup);
		if(nlsStrStr(TOVenNameDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVenNameDup,"\n")!= NULL) low_strrpl(TOVenNameDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVenNameDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVenNameDup))		
		{
			fprintf(fp,"%s",TOVenNameDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOVinNo=NULL;
	string TOVinNoDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVinNo",&TOVinNo))goto EXIT;  
	if(!nlsIsStrNull(TOVinNo)) TOVinNoDup=nlsStrDup(TOVinNo);
	printf("\n TOVinNoDup :%s",TOVinNoDup);fflush(stdout);
	if(!nlsIsStrNull(TOVinNoDup))
	{
		nlsStrTrimTrailWhiteSpace(TOVinNoDup);
		if(nlsStrStr(TOVinNoDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVinNoDup,"\n")!= NULL) low_strrpl(TOVinNoDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVinNoDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVinNoDup))		
		{
			fprintf(fp,"%s",TOVinNoDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOVinNo1=NULL;
	string TOVinNo1Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVinNo1",&TOVinNo1))goto EXIT;  
	if(!nlsIsStrNull(TOVinNo1)) TOVinNo1Dup=nlsStrDup(TOVinNo1);
	printf("\n TOVinNo1Dup :%s",TOVinNo1Dup);fflush(stdout);
	if(!nlsIsStrNull(TOVinNo1Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOVinNo1Dup);
		if(nlsStrStr(TOVinNo1Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVinNo1Dup,"\n")!= NULL) low_strrpl(TOVinNo1Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVinNo1Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVinNo1Dup))		
		{
			fprintf(fp,"%s",TOVinNo1Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOVinNo2=NULL;
	string TOVinNo2Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVinNo2",&TOVinNo2))goto EXIT;  
	if(!nlsIsStrNull(TOVinNo2)) TOVinNo2Dup=nlsStrDup(TOVinNo2);
	printf("\n TOVinNo2Dup :%s",TOVinNo2Dup);fflush(stdout);
	if(!nlsIsStrNull(TOVinNo2Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOVinNo2Dup);
		if(nlsStrStr(TOVinNo2Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVinNo2Dup,"\n")!= NULL) low_strrpl(TOVinNo2Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVinNo2Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVinNo2Dup))		
		{
			fprintf(fp,"%s",TOVinNo2Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOVinNo3=NULL;
	string TOVinNo3Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVinNo3",&TOVinNo3))goto EXIT;  
	if(!nlsIsStrNull(TOVinNo3)) TOVinNo3Dup=nlsStrDup(TOVinNo3);
	printf("\n TOVinNo3Dup :%s",TOVinNo3Dup);fflush(stdout);
	if(!nlsIsStrNull(TOVinNo3Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOVinNo3Dup);
		if(nlsStrStr(TOVinNo3Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVinNo3Dup,"\n")!= NULL) low_strrpl(TOVinNo3Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVinNo3Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVinNo3Dup))		
		{
			fprintf(fp,"%s",TOVinNo3Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string TOVinNo4=NULL;
	string TOVinNo4Dup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOVinNo4",&TOVinNo4))goto EXIT;  
	if(!nlsIsStrNull(TOVinNo4)) TOVinNo4Dup=nlsStrDup(TOVinNo4);
	printf("\n TOVinNo4Dup :%s",TOVinNo4Dup);fflush(stdout);
	if(!nlsIsStrNull(TOVinNo4Dup))
	{
		nlsStrTrimTrailWhiteSpace(TOVinNo4Dup);
		if(nlsStrStr(TOVinNo4Dup,"\n")!= NULL)
		{
			if(nlsStrStr(TOVinNo4Dup,"\n")!= NULL) low_strrpl(TOVinNo4Dup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOVinNo4Dup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOVinNo4Dup))		
		{
			fprintf(fp,"%s",TOVinNo4Dup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}



	string TOhlgreq=NULL;
	string TOhlgreqDup=NULL;
	if(dstat=objGetAttribute(TCPartObjP,"t5TOhlgreq",&TOhlgreq))goto EXIT;  
	if(!nlsIsStrNull(TOhlgreq)) TOhlgreqDup=nlsStrDup(TOhlgreq);
	printf("\n TOhlgreqDup :%s",TOhlgreqDup);fflush(stdout);
	if(!nlsIsStrNull(TOhlgreqDup))
	{
		nlsStrTrimTrailWhiteSpace(TOhlgreqDup);
		if(nlsStrStr(TOhlgreqDup,"\n")!= NULL)
		{
			if(nlsStrStr(TOhlgreqDup,"\n")!= NULL) low_strrpl(TOhlgreqDup,'\n',';');
			printf("\n After Remove CycleTimeDupCycleTimeDup==>[%s]\n",TOhlgreqDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TOhlgreqDup))		
		{
			fprintf(fp,"%s",TOhlgreqDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}




	string ESLstModByDup=NULL;
	string ESLstModBy=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5LastModBy",&ESLstModBy))goto EXIT;
	if(!nlsIsStrNull(ESLstModBy)) ESLstModByDup=nlsStrDup(ESLstModBy);
	printf("\n ESLstModByDup :%s",ESLstModByDup);fflush(stdout);
	if(!nlsIsStrNull(ESLstModByDup))
	{
		nlsStrTrimTrailWhiteSpace(ESLstModByDup);
		if(nlsStrStr(ESLstModByDup,"\n")!= NULL)
		{
			if(nlsStrStr(ESLstModByDup,"\n")!= NULL) low_strrpl(ESLstModByDup,'\n',';');
			printf("\n After Remove ESLstModByDup==>[%s]\n",ESLstModByDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ESLstModByDup))		
			{
				fprintf(fp,"%s",ESLstModByDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}



	string CreDateDup=NULL;
	string CreDate=NULL;	
	string CreDatestr=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"CreationDate",&CreDate))goto EXIT;
	if(!nlsIsStrNull(CreDate)) CreDateDup=nlsStrDup(CreDate);
	printf("\n CreDateDup :%s",CreDateDup);fflush(stdout);

	if(!nlsIsStrNull(CreDateDup))
	{
		CreDatestr = subString(CreDateDup,0,10);
		nlsStrTrimTrailWhiteSpace(CreDatestr);
		if(nlsStrStr(CreDatestr,"\n")!= NULL)
		{
			if(nlsStrStr(CreDatestr,"\n")!= NULL) low_strrpl(CreDatestr,'\n',';');
			printf("\n After Remove CreDatestr==>[%s]\n",CreDatestr);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(CreDatestr))		
			{
				fprintf(fp,"%s",CreDatestr);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}

	string LstUpdDup=NULL;
	string LstUpd=NULL;	
	string LstUpdstr=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"LastUpdate",&LstUpd))goto EXIT;
	if(!nlsIsStrNull(LstUpd)) LstUpdDup=nlsStrDup(LstUpd);
	printf("\n LstUpdDup :%s",LstUpdDup);fflush(stdout);
	if(!nlsIsStrNull(LstUpdDup))
	{
		LstUpdstr = subString(LstUpdDup,0,10);
		nlsStrTrimTrailWhiteSpace(LstUpdstr);
		if(nlsStrStr(LstUpdstr,"\n")!= NULL)
		{
			if(nlsStrStr(LstUpdstr,"\n")!= NULL) low_strrpl(LstUpdstr,'\n',';');
			printf("\n After Remove LstUpdstr==>[%s]\n",LstUpdstr);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(LstUpdstr))		
			{
				fprintf(fp,"%s",LstUpdstr);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string CrtrDup=NULL;
	string Crtr=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"Creator",&Crtr))goto EXIT;
	if(!nlsIsStrNull(Crtr)) CrtrDup=nlsStrDup(Crtr);
	printf("\n CrtrDup :%s",CrtrDup);fflush(stdout);
	if(!nlsIsStrNull(CrtrDup))
	{
		nlsStrTrimTrailWhiteSpace(CrtrDup);
		if(nlsStrStr(CrtrDup,"\n")!= NULL)
		{
			if(nlsStrStr(CrtrDup,"\n")!= NULL) low_strrpl(CrtrDup,'\n',';');
			printf("\n After Remove CrtrDup==>[%s]\n",CrtrDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(CrtrDup))		
			{
				fprintf(fp,"%s",CrtrDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}




	string TryoutLCS=NULL;
	string TryoutLCSDup=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"LifeCycleState",&TryoutLCS))goto EXIT;
	if(!nlsIsStrNull(TryoutLCS)) TryoutLCSDup=nlsStrDup(TryoutLCS);
	printf("\n TryoutLCSDup :%s",TryoutLCSDup);fflush(stdout);
	if(!nlsIsStrNull(TryoutLCSDup))
	{
		nlsStrTrimTrailWhiteSpace(TryoutLCSDup);
		if(nlsStrStr(TryoutLCSDup,"\n")!= NULL)
		{
			if(nlsStrStr(TryoutLCSDup,"\n")!= NULL) low_strrpl(TryoutLCSDup,'\n',';');
			printf("\n After Remove TryoutLCSDup==>[%s]\n",TryoutLCSDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(TryoutLCSDup))		
			{
				fprintf(fp,"%s",TryoutLCSDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}




		fprintf(fp,"\n");
	
	
	CLEANUP:

			t5PrintCleanUpModName;

	EXIT:
			t5CheckDstatAndReturn;
}


int main(int argc, char *argv[])
{
	int stat=0;
	string  LoginS=NULL;
	string  PasswordS=NULL;
	//string  OutFileNamePART=NULL;
	string  ProjectCode=NULL;
	string  Plant=NULL;
	string  EpochFlg=NULL;
	string  FiledownloadPath=NULL;
	string  Flag=NULL;
	string  FromDate=NULL;
	string  ToDate=NULL;
	string PartNumberVal=NULL;
	string PartNumberValDup=NULL;
	//string PartNumberRev=NULL;
	//string PartNumberRevDup=NULL;
	//string PartNumberSeq=NULL;
	//string PartNumberSeqDup=NULL;
	string		docobjst	=	NULL;
	string		EstNumber	=	NULL;
	string CurrentDate=NULL;
	string FileName=NULL;
	string FileName1=NULL;
	string FilePath=NULL;
	string FilePath1=NULL;
	string SysDate   = NULL;
	string SysPrevDate   = NULL;
	string Obid   = NULL;
	string ObidDup   = NULL;
	

	SetOfObjects  setOfAssmblyObjs = NULL ;
	SetOfObjects  AsgSigTaskObj = NULL ;

	ObjectPtr	TCPartObjP = NULL ;

	SqlPtr	PrtQrysql = NULL ;
	SqlPtr	Sql_ptr = NULL ;

	FILE	*fp	= NULL;

	int partCnt =0;
	int ii =0;

		SetOfStrings      dbScp	=          NULL;


	
	t5MethodInitWMD("GetESData");

	printf("\n Executing... GetESData.c ... \n");fflush(stdout);


	LoginS=nlsStrAlloc(200);
	PasswordS=nlsStrAlloc(200);
	ProjectCode=nlsStrAlloc(200);
	Plant=nlsStrAlloc(200);
	EpochFlg=nlsStrAlloc(200);
	FiledownloadPath=nlsStrAlloc(200);
	Flag=nlsStrAlloc(200);
	FromDate=nlsStrAlloc(200);
	ToDate=nlsStrAlloc(200);

	LoginS=argv[1];
	PasswordS=argv[2];
	EstNumber=argv[3];
	Plant=argv[4];
	FiledownloadPath=argv[5];
	Flag=argv[6]; //0=one time 1=Incremental (with/without fromdate todate)
	FromDate=argv[7];
	ToDate=argv[8];

	printf("\n Plant :%s \n",Plant);fflush(stdout);
	printf("\n FiledownloadPath :%s \n",FiledownloadPath);fflush(stdout);
	printf("\n Flag :%s \n",Flag);fflush(stdout);
	printf("\n FromDate :%s \n",FromDate);fflush(stdout);
	printf("\n ToDate :%s \n",ToDate);fflush(stdout);
	printf("\n EstNumber :%s \n",EstNumber);fflush(stdout);

	CurrentDate=sysGetCTime();
	low_strrpl(CurrentDate,' ','_');
	low_strrpl(CurrentDate,':','_');
	printf("\n\n CurrentDate is %s ",CurrentDate);fflush(stdout);

	SysDate = sysGetDate2();
	printf("\n System Date = [%s]\n",SysDate); fflush(stdout);	
	
	SysPrevDate  = sysGetOffsetDate (SysDate,0,-1,0);
	printf("System Previous Date = [%s]\n",SysPrevDate);  fflush(stdout);


	FileName=nlsStrAlloc(500);
	nlsStrCpy(FileName,"Tryout");
	//if(!nlsIsStrNull(Flag)) nlsStrCat(FileName,Flag);
//	nlsStrCat(FileName,"_");
	//nlsStrCat(FileName,CurrentDate);
	nlsStrCat(FileName,".txt");

	FileName1=nlsStrAlloc(500);
	nlsStrCpy(FileName1,"ES_OPR");
	//nlsStrCat(FileName1,ProjectCode);
	//nlsStrCat(FileName1,"_");
	//nlsStrCat(FileName1,CurrentDate);
	nlsStrCat(FileName1,".txt");


	FilePath=nlsStrAlloc(500);
	//nlsStrCpy(FilePath,"/user/omfprod/devgroups/dss/ES_TCE_TCUA_Migration/");
	nlsStrCpy(FilePath,FiledownloadPath);
	nlsStrCat(FilePath,"/");
	nlsStrCat(FilePath,FileName);
	printf("\n FilePath :%s \n",FilePath);fflush(stdout);

	FilePath1=nlsStrAlloc(500);
	//nlsStrCpy(FilePath1,"/user/omfprod/devgroups/dss/ES_TCE_TCUA_Migration/");
	nlsStrCpy(FilePath1,FiledownloadPath);
	nlsStrCat(FilePath1,"/");
	nlsStrCat(FilePath1,FileName1);
	printf("\n FilePath1 :%s \n",FilePath1);fflush(stdout);

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));

	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());

	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));

	t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));

	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		goto EXIT;
	}

	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (ii=0;ii<setSize(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}

	low_set_add_str(dbScp, "supprod");
	low_set_add_str(dbScp, "suhprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	for (ii=0;ii<low_set_size(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check -after... :%s\n",docobjst);fflush(stdout);
	}

	
	fp=fopen(FilePath,"a+");
	if(fp==NULL)
	{
				printf("\n%s:fp file is not created...!!!!\n",FilePath);fflush(stdout);
	}
	fflush(fp);

	if(nlsStrCmp(Flag,"1")==0)
	{
		printf("\n Flag =1");fflush(stdout);
		setOfAssmblyObjs=NULL;
		if(PrtQrysql) oiSqlDispose(PrtQrysql); PrtQrysql = NULL; 
		if (dstat = oiSqlCreateSelect(&PrtQrysql)) goto EXIT;
		if(dstat=(oiSqlWhereBegParen(PrtQrysql)));
		if(dstat = oiSqlWhereEQ(PrtQrysql,"t5Plant",Plant)) goto EXIT;
		if(dstat = oiSqlWhereAND(PrtQrysql)) goto EXIT;
		
		if( (!nlsIsStrNull(FromDate) && !nlsIsStrNull(ToDate)) || (nlsStrCmp(FromDate,"-") || nlsStrCmp(ToDate,"-"))  )
		{
		  if(dstat=(oiSqlWhereGE(PrtQrysql,CreationDateAttr,FromDate))) goto EXIT;
		  if(dstat=(oiSqlWhereAND(PrtQrysql))) goto EXIT;
		  if(dstat=(oiSqlWhereLE(PrtQrysql,CreationDateAttr,ToDate))) goto EXIT;
		}
		else
		{
		  if(dstat=(oiSqlWhereGE(PrtQrysql,CreationDateAttr,SysPrevDate))) goto EXIT;
		  if(dstat=(oiSqlWhereAND(PrtQrysql))) goto EXIT;
		  if(dstat=(oiSqlWhereLE(PrtQrysql,CreationDateAttr,SysDate))) goto EXIT;
		}

		if(dstat=(oiSqlWhereEndParen(PrtQrysql))) goto EXIT;
		if(dstat = QueryDbObject(t5TryOutClass,PrtQrysql,0,TRUE,SC_SCOPE_OF_SESSION,&setOfAssmblyObjs,mfail)) goto EXIT;
		if(dstat=oiSqlPrint(PrtQrysql))goto EXIT;

	}
	else // flag=0 one time
	{
		printf("\n Flag =0");fflush(stdout);
		setOfAssmblyObjs=NULL;
		if(PrtQrysql) oiSqlDispose(PrtQrysql); PrtQrysql = NULL; 
		if (dstat = oiSqlCreateSelect(&PrtQrysql)) goto EXIT;
		if(dstat=(oiSqlWhereBegParen(PrtQrysql)));
		if(dstat = oiSqlWhereEQ(PrtQrysql,"t5Plant",Plant)) goto EXIT;
		if(dstat = oiSqlWhereAND(PrtQrysql)) goto EXIT;
		if(dstat = oiSqlWhereEQ(PrtQrysql,"LifeCycleState","LcsApproved")) goto EXIT;
		if( !nlsIsStrNull(EstNumber) && nlsStrCmp(EstNumber,"-") )
		{
			if(dstat = oiSqlWhereAND(PrtQrysql)) goto EXIT;
			if(dstat = oiSqlWhereEQ(PrtQrysql,"t5TOTryOutNo",EstNumber)) goto EXIT;
		}
		if(dstat=(oiSqlWhereEndParen(PrtQrysql))) goto EXIT;
		if(dstat = QueryDbObject(t5TryOutClass,PrtQrysql,0,TRUE,SC_SCOPE_OF_SESSION,&setOfAssmblyObjs,mfail)) goto EXIT;
		if(dstat=oiSqlPrint(PrtQrysql))goto EXIT;
	}
	
	printf("\n setSize(setOfAssmblyObjs) : %d \n",setSize(setOfAssmblyObjs));fflush(stdout);
	
	if(setSize(setOfAssmblyObjs)>0)
	{
		for(partCnt=0;partCnt<setSize(setOfAssmblyObjs);partCnt++)
		{
			TCPartObjP=NULL;
			TCPartObjP=setGet(setOfAssmblyObjs,partCnt);

			PartNumberVal=NULL;
			PartNumberValDup=NULL;

			if(dstat = objGetAttribute(TCPartObjP,"t5TOTryOutNo",&PartNumberVal))goto EXIT;
			if(!nlsIsStrNull(PartNumberVal)) PartNumberValDup=nlsStrDup(PartNumberVal);
			printf("\n TryOut Number:%s \n",PartNumberValDup); fflush(stdout);

			if(dstat = objGetAttribute(TCPartObjP,"OBID",&Obid))goto EXIT;
			if(!nlsIsStrNull(Obid)) ObidDup=nlsStrDup(Obid);
			printf("\n ObidDup :%s \n",ObidDup); fflush(stdout);

			/*AsgSigTaskObj=NULL;
			if(dstat = oiSqlCreateSelect(&Sql_ptr)) goto EXIT;
			if(dstat = oiSqlWhereEQValue(Sql_ptr,LeftAttr,ObidDup)) goto EXIT;
			if(dstat = oiSqlWhereAND(Sql_ptr)) goto EXIT;
			if(dstat = oiSqlWhereBegParen(Sql_ptr)) goto EXIT;
			if(dstat = oiSqlWhereEQValue(Sql_ptr,WorkDescAttr,"Introduction VIN Review")) goto EXIT;
			if(dstat = oiSqlWhereAND(Sql_ptr)) goto EXIT;
			if(dstat = oiSqlWhereEQValue(Sql_ptr,SigStateAttr,"LcmIntHis")) goto EXIT;
			if(dstat = oiSqlWhereEndParen(Sql_ptr)) goto EXIT;
			if(dstat = QueryDbObject("AsgSig",Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&AsgSigTaskObj,mfail)) goto EXIT;
			if (mfail) goto EXIT;
			if(Sql_ptr) oiSqlDispose(Sql_ptr); Sql_ptr = NULL;

			printf("\n setSize(AsgSigTaskObj) : %d \n",setSize(AsgSigTaskObj));fflush(stdout);
			*/
			//if(setSize(AsgSigTaskObj)>0)
			//{
				t5CheckMfail(GetTryoutInfo(TCPartObjP,fp,mfail));
			//}
			//else
			//{
			//	printf("\n Tryout with no "Introduction VIN Review" Assignment " );fflush(stdout);
			//}

		}
	
	}
				
	if(fp) fclose(fp); fp=NULL;


CLEANUP:
		t5PrintCleanUpModName;


EXIT:
		t5CheckDstatAndReturn;
}
;



// GetTryoutData Loader 123loader "TryoutNo" Plant FileDownloadpath Flag FromDate ToDate
// GetTryoutData Loader 123loader "PKEN001412" Z /user/omfprod/devgroups/dss/Tryout_TCE_TCUA_Migration/ 0   
// GetTryoutData Loader 123loader "TryoutNo" Z /user/omfprod/devgroups/dss/Tryout_TCE_TCUA_Migration/ 1 FromDate Todate
// GetTryoutData Loader 123loader "TryoutNo" Z /user/omfprod/devgroups/dss/Tryout_TCE_TCUA_Migration/ 1 "" ""

