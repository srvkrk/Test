/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                :   Rupali Rane
*  Module                :   TCUA Design Revision Update UOM Property
*  Code                  :   UpadateUOMt5UQDup.c
*  Created on			 :   24th Mar 2021
*
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/
#define TE_MAXLINELEN  128
#include <ae/dataset.h>
#include <cfm/cfm.h>
#include <epm/epm.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define Debug TRUE
                                                                              \

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
        printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
    }
    return ITK_ok;
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}



int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dcr						= NULL;
	char *CDStatus = NULL;
	char *TRDate = NULL;
	char *ProposedSolution = NULL;
	char *PR_reason = NULL;
	char *SR_reason = NULL;
	char *PR_reason1 = NULL;
	char *SR_reason1 = NULL;
	char *Manufacturing_Location = NULL;
	char *Affected_design_groups = NULL;
	char *WF_ID = NULL;
	char *Platform = NULL;
	char *vehicle_mode = NULL;
	char *vehicle_mode1 = NULL;
	char *major_affected_design_groups = NULL;
	char *DCR_raising_date = NULL;
	char *DCR_approval_date = NULL;
	char *Proposed_Changes_Description = NULL;
	char *Proposed_Changes_Description1 = NULL;
	char *Program = NULL;
	char *DCR_Category = NULL;
	char *DCR_Category1 = NULL;
	char *Raiser_Function = NULL;
	char *Raiser_Function1 = NULL;
	char *RCA_PDCA_Attachment = NULL;
	char *Product_line_head_approval = NULL;
	char *Details_of_praposed_change_description = NULL;
	char *Details_of_praposed_change_description1 = NULL;
	char *Description = NULL;
	char *Description1 = NULL;
	char *Applicability = NULL;
	char *PSE_Commodity = NULL;
	char *PSE_Cluster = NULL;
	char *Project= NULL;
	char *DRgate= NULL;
	char *DRStatus= NULL;
	char *ObjClassName=NULL;
	char * design_group = NULLTAG;
	char *token =NULL;

	char **designgroup =NULL ;
	char **Affected_design_groupsList =NULL;

	int num_values;
	int position = 0;
	int nopo = 0;
	int Affected_design_groupsCount = 0;

	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dcr				= ITK_ask_cli_argument("-dcr=");                          
	CDStatus		= ITK_ask_cli_argument("-cs=");                               
	TRDate			= ITK_ask_cli_argument("-td=");
	ProposedSolution= ITK_ask_cli_argument("-ps=");                        
	PR_reason		= ITK_ask_cli_argument("-pra=");                               
	SR_reason		= ITK_ask_cli_argument("-sr="); 
	Manufacturing_Location	= ITK_ask_cli_argument("-ml=");                  
	Affected_design_groups	= ITK_ask_cli_argument("-ag=");                  
	WF_ID			= ITK_ask_cli_argument("-wi=");                                 
	Platform		= ITK_ask_cli_argument("-plat=");                                
	vehicle_mode	= ITK_ask_cli_argument("-vm=");
	major_affected_design_groups	= ITK_ask_cli_argument("-mg=");            
	DCR_raising_date	= ITK_ask_cli_argument("-dd=");                       
	DCR_approval_date	= ITK_ask_cli_argument("-dad=");                       
	Proposed_Changes_Description = ITK_ask_cli_argument("-pcd=");  
	Program			= ITK_ask_cli_argument("-pg=");                                
	DCR_Category	= ITK_ask_cli_argument("-dc=");                           
	Raiser_Function = ITK_ask_cli_argument("-rf=");                         
	RCA_PDCA_Attachment = ITK_ask_cli_argument("-ra=");                     
	Product_line_head_approval = ITK_ask_cli_argument("-pa="); 
	Details_of_praposed_change_description = ITK_ask_cli_argument("-pad=");
	Description		 = ITK_ask_cli_argument("-desc=");
	Applicability	 = ITK_ask_cli_argument("-ac=");                           
	PSE_Commodity	 = ITK_ask_cli_argument("-pc=");                           
	PSE_Cluster		 = ITK_ask_cli_argument("-psc=");                             
	Project			 = ITK_ask_cli_argument("-pr=");                                  
	DRgate			 = ITK_ask_cli_argument("-drg=");                                  
	 
	
	date_t TRDate1;


	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	//ifail = ITK_set_bypass(true);

	printf("\nBefor DCR_Auto_Assign call \n\n");
	

	//ifail = DCR_Auto_Assign(dcr);
	tag_t	*type_tag3 =  NULLTAG;
	tag_t	*type_revtag3 =  NULLTAG;
	tag_t	new_object =  NULLTAG;
	tag_t	new_object_Rev =  NULLTAG;
	tag_t	object_create_input_tag =  NULLTAG;
	tag_t	object_create_input_revtag =  NULLTAG;
	tag_t	T5_Revisiontag =  NULLTAG;

	int number_of_types1 =0;

	printf("\nShell DCR...\nDCRno..[%s]\nCDStatus..[%s]\nTRDate..[%s]\nProposedSolution..[%s]\nPR_reason..[%s]\nSR_reason..[%s]\nManufacturing_Location..[%s]\nAffected_design_groups.[%s]\nWF_ID..[%s]\nPlatform[%s]\nVehicle_mode..[%s]\nmajor_affected_design_groups..[%s]\nDCR_raising_date..[%s]\nDCR_approval_date..[%s]\nProposed_Changes_Description..[%s]\nProgram..[%s]\nDCR_Category..[%s]\nRaiser_Function..[%s]\nRCA_PDCA_Attachment..[%s]\nProduct_line_head_approval..[%s]\nDetails_of_praposed_change_description..[%s]\nDescription..[%s]\nApplicability..[%s]\nPSE_Commodity..[%s]\nPSE_Cluster..[%s]\nProject..[%s]\nDRGate..[%s]\n",dcr,CDStatus,TRDate,ProposedSolution,PR_reason,SR_reason,Manufacturing_Location,Affected_design_groups,WF_ID,Platform,vehicle_mode,major_affected_design_groups,DCR_raising_date,DCR_approval_date,Proposed_Changes_Description,Program,DCR_Category,Raiser_Function,RCA_PDCA_Attachment,Product_line_head_approval,Details_of_praposed_change_description,Description,Applicability,PSE_Commodity,PSE_Cluster,Project,DRgate);fflush(stdout);


	if(TCTYPE_find_types_for_class("T5_DChangeReport",&number_of_types1,&type_tag3));
	printf("\n CreateDcrTask-->number_of_types1-------->  : %d\n",number_of_types1);fflush(stdout);

	if(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag));
	
	//if( AOM_set_value_tag ( object_create_input_tag, "revision",T5_Revisiontag )) ;


	//if(AOM_set_value_string(object_create_input_tag,"release_status_list",dcr_objname));
	
	//if(AOM_lock(object_create_input_tag));


	if(AOM_set_value_string(object_create_input_tag,"object_desc","CVBU Mint-DCR"));
	printf("\n DCR Desc: CVBU Mint-DCR");fflush(stdout);

	if(AOM_set_value_string(object_create_input_tag,"item_id",dcr));
	printf("\n DCR Number: [%s]",dcr);fflush(stdout);

	if(AOM_set_value_string(object_create_input_tag,"object_name",dcr));
	printf("\n object Name [%s]",dcr);fflush(stdout);

	if((TCTYPE_create_object(object_create_input_tag, &new_object))!=ITK_ok)PrintErrorStack();

	if (new_object != NULLTAG)
	{
		printf("\n DCR Tag found, Checking DCR Rev Tag.");fflush(stdout); 
		
		if(AOM_save_without_extensions(new_object));
		if(AOM_refresh(new_object,0));
		if(AOM_unlock(new_object));

		ITEM_ask_latest_rev(new_object,&T5_Revisiontag);

		if (T5_Revisiontag != NULLTAG)
		{
			if(AOM_save_without_extensions(T5_Revisiontag));
			if(AOM_unlock(T5_Revisiontag));
			printf("\n DCR Rev Tag found");fflush(stdout);

			if(AOM_refresh(T5_Revisiontag,1));

			if(AOM_set_value_string(T5_Revisiontag,"t5_Advntg",CDStatus));
			printf("\n Current Drawing Status Set..[%s]",CDStatus);fflush(stdout);
			
			if(AOM_set_value_string(T5_Revisiontag,"t5_DcrCreProSol",ProposedSolution));
			printf("\n Proposed Solution Set..[%s]",ProposedSolution);fflush(stdout);
			
			STRNG_replace_str(PR_reason,"_"," ",&PR_reason1);
			STRNG_replace_str(SR_reason,"_"," ",&SR_reason1);
			STRNG_replace_str(DCR_Category,"_"," ",&DCR_Category1);
			STRNG_replace_str(Raiser_Function,"_"," ",&Raiser_Function1);
			STRNG_replace_str(vehicle_mode,"_"," ",&vehicle_mode1);
			STRNG_replace_str(Description,"_"," ",&Description1);
			STRNG_replace_str(Proposed_Changes_Description,"_"," ",&Proposed_Changes_Description1);
			STRNG_replace_str(Details_of_praposed_change_description,"_"," ",&Details_of_praposed_change_description1);
			printf("\n Loop to set PR_reason[%s]\n SR_reason [%s]\n Description [%s]",PR_reason1,SR_reason1,Description1);fflush(stdout);
			if((tc_strcmp(PR_reason1," ")!=0))
			{
				if(AOM_set_value_string(T5_Revisiontag,"t5_DcrCreRC",PR_reason1));
				printf("\n Reason for Change Set.. [%s]",PR_reason1);fflush(stdout);
			}
			else
			{
				if(AOM_set_value_string(T5_Revisiontag,"t5_DcrCreRC",SR_reason1));
				printf("\n Reason for Change Set.. [%s]",SR_reason1);fflush(stdout);
			}
			if(AOM_set_value_string(T5_Revisiontag,"object_desc",Description1));
			printf("\n2. DCR Description set..[%s]",Description1);fflush(stdout);
			
			if(AOM_set_value_string(T5_Revisiontag,"t5_ManufLoc",Manufacturing_Location));
			printf("\n Manufacturing Location Set..[%s]",Manufacturing_Location);fflush(stdout);

			if(AOM_set_value_string(T5_Revisiontag,"t5_WorkflowID",WF_ID));
			printf("\n Workflow Id Set..[%s]",WF_ID);fflush(stdout);
			
			if(AOM_set_value_string(T5_Revisiontag,"t5_DCRPlatform",Platform));
			printf("\n Platform Set..[%s]",Platform);fflush(stdout);
			
			if(AOM_set_value_string(T5_Revisiontag,"t5_DCRVehMode",vehicle_mode1));
			printf("\n Vehicle Mode Set..[%s]",vehicle_mode1);fflush(stdout);

			if(AOM_set_value_string(T5_Revisiontag,"t5_PropChDesc",Proposed_Changes_Description1));
			printf("\n Proposed Changes Description Set..[%s]",Proposed_Changes_Description1);fflush(stdout);

			//if(AOM_set_value_string(T5_Revisiontag,"t5_RaisngDt",DCR_raising_date));
			//printf("\n DCR Raising Date Set..[%s]",DCR_raising_date);fflush(stdout);

			//if(AOM_set_value_string(T5_Revisiontag,"t5_AppvDt",DCR_approval_date));
			//printf("\n DCR Approval Date Set..[%s]",DCR_approval_date);fflush(stdout);

			
			if(AOM_set_value_string(T5_Revisiontag,"t5_DCRCategory",DCR_Category1));
			printf("\n DCR Category Set..[%s]",DCR_Category1);fflush(stdout);
			
			if(AOM_set_value_string(T5_Revisiontag,"t5_RaiserFun",Raiser_Function1));
			printf("\n Raiser Function Set..[%s]",Raiser_Function1);fflush(stdout);
			
			if(AOM_set_value_string(T5_Revisiontag,"t5_RCAPDCAAttach",RCA_PDCA_Attachment));
			printf("\n RCA PDCA Attachment Set..[%s]",RCA_PDCA_Attachment);fflush(stdout);
			
			if(AOM_set_value_string(T5_Revisiontag,"t5_ProdLHeadAppDt",Product_line_head_approval));
			printf("\n Product Line Head Approval Set..[%s]",Product_line_head_approval);fflush(stdout);
			
			if(AOM_set_value_string(T5_Revisiontag,"t5_ChangeDescAttr",Details_of_praposed_change_description1));
			printf("\n Details Of Praposed Change Description Set..[%s]",Details_of_praposed_change_description1);fflush(stdout);
			
			if(AOM_set_value_string(T5_Revisiontag,"t5_Applicability",Applicability));
			printf("\n Applicability Set..[%s]",Applicability);fflush(stdout);

			if(AOM_set_value_string(T5_Revisiontag,"t5_PSECommodity",PSE_Commodity));
			printf("\n PSE Commodity Set..[%s]",PSE_Commodity);fflush(stdout);

			if(AOM_set_value_string(T5_Revisiontag,"t5_PSEClust",PSE_Cluster));
			printf("\n PSE Cluster Set..[%s]",PSE_Cluster);fflush(stdout);

			if(AOM_set_value_string(T5_Revisiontag,"t5_DcrProCode",Project));
			printf("\n Project Set..[%s]",Project);fflush(stdout);

			if(AOM_set_value_string(T5_Revisiontag,"t5_TgtRlzDate",TRDate));
			printf("\n Target release date Set..[%s]",TRDate);fflush(stdout);

			if((tc_strcmp(DRgate,"AR3")==0))
			{
				printf("\n  ...11....");fflush(stdout);
				//tc_strcpy(DRStatus,"DR3");
				tc_strdup("DR3",&DRStatus);
			}
			else if((tc_strcmp(DRgate,"AR3-AR4")==0)||(tc_strcmp(Program,"DEVELOPMENT_PROJECT_DR3_TO_DR4")==0)||(tc_strcmp(DRgate,"DEVELOPMENT_PROJECT_DR3_TO_DR4")==0))
			{
				printf("\n  ...12....");fflush(stdout);
				tc_strdup("DR3-DR4",&DRStatus);
			}// DEVELOPMENT_PROJECT_DR3_TO_DR4
			else if((tc_strcmp(DRgate,"AR4-AR5")==0)||(tc_strcmp(Program,"DEVELOPMENT_PROJECT_DR4_TO_DR5")==0)||(tc_strcmp(DRgate,"DEVELOPMENT_PROJECT_DR4_TO_DR5")==0))
			{
				printf("\n  ...14....");fflush(stdout);
				tc_strdup("DR4-DR5",&DRStatus);
			}
			else if((tc_strcmp(DRgate,"Post AR5")==0)||(tc_strstr(Program,"DR5_ONWARDS")!=NULL)||(tc_strcmp(DRgate,"DR5_ONWARDS")==0) || (tc_strcmp(DRgate,"DR5 onwards")==0) || (tc_strcmp(Program,"DR5 onwards")==0))
			{
				printf("\n  ...15....");fflush(stdout);
				tc_strdup("Post DR5",&DRStatus);
			}
			else
			{
				printf("\n  ...16....");fflush(stdout);
				if(tc_strcmp(DRgate,"")!=0)
				{
					printf("\n  ...21....");fflush(stdout);
					tc_strcpy(DRStatus,DRgate);
				}
			}
			printf("\n 1.DR gate => [%s] ",DRgate);fflush(stdout);
			printf("\n 1.DR status => [%s] ",DRStatus);fflush(stdout);
			
			if((tc_strcmp(DRStatus," ")!=0) && (tc_strcmp(Program,"")==0))
			{
				if(AOM_set_value_string(T5_Revisiontag,"t5_DcrCreSP",DRStatus));
				printf("\n 1.Stage of program or DR status is [%s] ",DRStatus);fflush(stdout);
			}
			else  
			{
				if(AOM_set_value_string(T5_Revisiontag,"t5_DcrCreSP",DRgate));
				printf("\n 2.Stage of program  Set=> [%s] ",DRgate);fflush(stdout);
			}
			if ((tc_strcmp(DRStatus,"")!=0 && (tc_strcmp(DRgate,"")==0)) || (tc_strcmp(Program,"")!=0))
			{
				if(AOM_set_value_string(T5_Revisiontag,"t5_DcrCreSP",Program));
				printf("\n 3.Stage of program  Set=> [%s] ",Program);fflush(stdout);
			}

			
			if((Affected_design_groups==NULL)|| (tc_strcmp(Affected_design_groups,"")==0))
			{
				printf("\n DCR Design group started.....\n");fflush(stdout);
			}
			else
			{
				printf("\n To set the DCR design group...");fflush(stdout);
				nopo=0;
				Affected_design_groupsCount=0;
				if(EPM__parse_string(Affected_design_groups,",",&Affected_design_groupsCount,&Affected_design_groupsList)!=ITK_ok)PrintErrorStack();
				for (nopo=0;nopo<Affected_design_groupsCount ;nopo++ )
				{
					printf("\n DCR group is %s \n",Affected_design_groupsList[nopo]);fflush(stdout);
					//if(ITEM_find_item (Affected_design_groupsList[nopo], &NOPOpart_tg)!=ITK_ok)PrintErrorStack();
					token= Affected_design_groupsList[nopo];
					printf("\n 1 Token : [%s]",token);fflush(stdout);

						
					if((tc_strcmp(token,"00_VC")==0) || (tc_strcmp(token,"00E")==0) )
					{
						if(AOM_set_value_string_at(T5_Revisiontag,"t5_DcrDesgGrp",nopo,"00"));
						printf("\n Affected design groups Set..[%s]",Affected_design_groups);fflush(stdout);
					}
					else if((tc_strcmp(token,"7054")==0) || (tc_strcmp(token,"8054")==0)|| (tc_strcmp(token,"8054_ELECTRICAL_SAFETY")==0) || (tc_strcmp(token,"8054_ELECTRONICS")==0) || (tc_strcmp(token,"1054")==0) || (tc_strcmp(token,"2054")==0) || (tc_strcmp(token,"3054")==0) || (tc_strcmp(token,"4054")==0) || (tc_strcmp(token,"6054")==0) || (tc_strcmp(token,"5054")==0) || (tc_strcmp(token,"8254")==0) || (tc_strcmp(token,"9054")==0) || (tc_strcmp(token,"8554R")==0) )
					{
						if(AOM_set_value_string_at(T5_Revisiontag,"t5_DcrDesgGrp",nopo,"54"));
						printf("\n Affected design groups Set..[%s]",Affected_design_groups);fflush(stdout);
					}
					else if((tc_strcmp(token,"1080")==0) || (tc_strcmp(token,"2080")==0)|| (tc_strcmp(token,"4080")==0) || (tc_strcmp(token,"4480")==0) || (tc_strcmp(token,"5080")==0) || (tc_strcmp(token,"5580")==0) || (tc_strcmp(token,"5880")==0) || (tc_strcmp(token,"6080")==0) || (tc_strcmp(token,"9080")==0) || (tc_strcmp(token,"5580R")==0))
					{
						if(AOM_set_value_string_at(T5_Revisiontag,"t5_DcrDesgGrp",nopo,"80"));
						printf("\n Affected design groups Set..[%s]",Affected_design_groups);fflush(stdout);
					}
					else if((tc_strcmp(token,"15_StartingCharging")==0) || (tc_strcmp(token,"15_Sensors")==0))
					{
						if(AOM_set_value_string_at(T5_Revisiontag,"t5_DcrDesgGrp",nopo,"15"));
						printf("\n Affected design groups Set..[%s]",Affected_design_groups);fflush(stdout);
					}
					else if((tc_strcmp(token,"NA")==0))
					{
						if(AOM_set_value_string_at(T5_Revisiontag,"t5_DcrDesgGrp",nopo,Affected_design_groupsList[nopo]));
						printf("\n 1111DCR design group set successfully...");fflush(stdout);
					}
					else
					{
						
						printf("\n 2.values count for less than value 1: %d",nopo);fflush(stdout);
						if(AOM_set_value_string_at(T5_Revisiontag,"t5_DcrDesgGrp",nopo,Affected_design_groupsList[nopo]))
						printf("\n 2222DCR design group set successfully...");fflush(stdout);;
					}
				}
				
					
			}
			
			if(AOM_save_without_extensions(T5_Revisiontag));
			if(AOM_refresh(T5_Revisiontag,0));
		}
		else
		{
			printf("\n DCR Rev Tag not found");fflush(stdout);
		}
	}
	else
	{
		printf("\n DCR Tag Not found");fflush(stdout);
	}
	
	printf("\n11111\n");fflush(stdout);
	if(new_object != NULLTAG)
	{
		printf("\n Inside New Object Tag not null.\n");fflush(stdout);
		if(AOM_save_without_extensions(new_object));
		if(AOM_refresh(new_object,0));
		if(AOM_unlock(new_object));
		printf("\n DCR is created......\n"); fflush(stdout);
	}
	else
	{
		printf(" \n DCR not created.....\n");
	}

	printf("\nEnd of program.....!!\n\n");
	printf("\n*****************************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
