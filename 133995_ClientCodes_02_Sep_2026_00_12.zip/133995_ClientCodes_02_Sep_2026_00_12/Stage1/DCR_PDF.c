#include <stdlib.h>
#include <time.h>
#include <stdio.h>
#include <ps/ps.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <ae/datasettype.h>
#include <ae/dataset.h>
#include <sa/tcfile.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#include <tcinit/tcinit.h>
#include <ae/ae.h>
#include <sa/tcfile_cache.h>
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
int ifail = ITK_ok;
int PdfRegister(char *DCRId);
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
        printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
    }
    return ITK_ok;
}


int ITK_user_main(int argc, char *argv[])
{
	
	tag_t query_tag         	= NULLTAG;
	tag_t *Rev1Tag      		= NULLTAG;
	tag_t *Rev2Tag      		= NULLTAG;
	tag_t item      		= NULLTAG;
	tag_t Item_Tag				= NULLTAG;
	tag_t Rel_type		   		= NULLTAG;
	tag_t *secondary_obj    	= NULLTAG;
	tag_t PDF_Tag				= NULLTAG;
	tag_t a_datasettype			= NULLTAG;
	//tag_t datasettype_PDF_name	= NULLTAG;
	tag_t referenced_object		= NULLTAG;
	tag_t  newFileTag			= NULLTAG;
	tag_t  CabinKit_no_tag			= NULLTAG;
	//tag_t  *CabinKit_no_tag			= NULLTAG;
	tag_t  CabinKit_no_rev			= NULLTAG;
	tag_t  CabinKit_tag			= NULLTAG;
	tag_t  tRevTypeTag			= NULLTAG;
	tag_t  spareRev			= NULLTAG;
	tag_t  bom_view			= NULLTAG;
	tag_t  bvr			= NULLTAG;
	tag_t  top_bom_line_ck			= NULLTAG;
	tag_t  window			= NULLTAG;

	tag_t dataset = NULLTAG ;          
	AE_reference_type_t ref_type ; 
	tag_t text_file = NULLTAG ;         
	tag_t new_line = NULLTAG ;         
	tag_t childTag = NULLTAG ;         

	AE_reference_type_t   reference_type= 1;
	IMF_file_t  file_descriptor;

	char *dataset_name      = NULL;

	char *Creation_date           = NULL;
	char *Revision          = NULL;
	char *sequence          = NULL;
	char *filename              = NULL;
	char *PDF_dataset		= NULL;
	char *object_desc       = NULL;
	char *t5_DocRemarks     = NULL;
	char *t5_TrackTrace     = NULL;
	char *t5_CTECTS         = NULL;
	char *t5_SheetSize      = NULL;
	char *Object_string     = NULL;
	char *Name_reference 	= NULL;
	char *File_path		 	= NULL;
	char *username = NULL;
	char *password = NULL;
	char *DCRId      =	NULL;

	int n_items             = 0;
	int n_items1             = 0;
	int t                   = 0;
	int i                   = 0;
	int status              = ITK_ok;


	ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	ifail = ITK_auto_login( );

	if(ifail==0)
	{
		printf("\nLogin Successfully to Teamcenter!!!!!!!!\n");
	}
	ifail = ITK_set_journalling(TRUE);

	username      = ITK_ask_cli_argument("-u=");
	password      = ITK_ask_cli_argument("-pf=");
	Creation_date       = ITK_ask_cli_argument("-cd=");
	//Revision      = ITK_ask_cli_argument("-r=");
	//sequence      = ITK_ask_cli_argument("-s=");
	//filename      = ITK_ask_cli_argument("-f=");
	//22-Feb-2024

		
	printf("\n Creation_Date : [%s]\n",Creation_date);fflush(stdout);
	printf("\n!!!Program Starting here!!!\n");fflush(stdout);
	int value_entries       = 3;
	int value_entries1       = 2;
	
	
	printf("\nQuering Part number  : [%s]", Creation_date );fflush(stdout);
	
	ifail = QRY_find2("General...",&query_tag);
 

	if(query_tag)
	{
		printf("\nFound Query : DCR Revision... \n");fflush(stdout);
		char *entries[3]        = {"Created After","Owning User","Type"};
		
		char **values = (char **) MEM_alloc(50 * sizeof(char *));
	
		values[0] = (char *)MEM_alloc( strlen( Creation_date ) + 1);
		tc_strcpy(values[0], Creation_date  );
		//
		values[1] = (char *)MEM_alloc( strlen( "cvprod" ) + 1);
		tc_strcpy(values[1], "cvprod" );
		
		values[2] = (char *)MEM_alloc( strlen( "T5_DChangeReportRevision" ) + 1);
		tc_strcpy(values[2], "T5_DChangeReportRevision" );
	
		printf("\n execute Query : DCR Revision... \n");fflush(stdout);
	
		ifail = QRY_execute(query_tag, value_entries, entries, values, &n_items, &Rev1Tag);
	
		printf("\n DCR Revision...  Found : [%d]\n",n_items);fflush(stdout);
		for(i=0;i<n_items;i++)
		{
			DCRId=NULL;
			ifail=AOM_ask_value_string(Rev1Tag[i],"current_id",&DCRId);
			printf("\n DCR  Id : [%s]\n",DCRId);fflush(stdout);
			PdfRegister(DCRId);
		}

	}
	return status;
}
int PdfRegister(char *DCRId)
{
	int result=0;
	int ref_count;
	int SysReturn = 0;
	int sec_count = 0;

	char *DCRFile = NULL;
	char *FinalDCRFile = NULL;
	char *datesetNam = NULL;
	char *datesetNamTemp = NULL;
	char *filepath = NULL;
	

	char **ref_list;
	char *commandd =NULL ;
	char *command =NULL ;

	
	tag_t DCRTag=NULLTAG;
	tag_t DCRREVTag=NULLTAG;
	tag_t pdfDataset=NULLTAG;
	tag_t latestDataset=NULLTAG;
	tag_t Report_Relation=NULLTAG;
	tag_t relation_type=NULLTAG;
	tag_t specRelationType_t=NULLTAG;
	tag_t PLMSession=NULLTAG;
	tag_t *sec_objects=NULLTAG;
	char docFile[300];

	char * pdf = NULL;
	pdf = "PDF";


		DCRFile = (char *) MEM_alloc (sizeof (char) * 500);
		FinalDCRFile = (char *) MEM_alloc (sizeof (char) * 500);
		datesetNam = (char *) MEM_alloc (sizeof (char) * 500);
		datesetNamTemp = (char *) MEM_alloc (sizeof (char) * 500);
		filepath = (char *) MEM_alloc (sizeof (char) * 300);
		command = (char *) MEM_alloc (sizeof (char) * 500);
	
		
		tc_strcat(DCRFile,DCRId);
		tc_strcat(DCRFile,"-approval");
		tc_strcat(DCRFile,".pdf");
		if(ITEM_find_item(DCRId ,&DCRTag)!=ITK_ok)PrintErrorStack();
		if (DCRTag)
		{
			printf("\n2.DCR tag found"); fflush(stdout);
		
		}
		if(ITEM_ask_latest_rev(DCRTag,&DCRREVTag)!=ITK_ok)PrintErrorStack();
		if(DCRREVTag != NULLTAG)
		{
			printf("\n 2.DCR revision Tag found"); fflush(stdout);
		
		}
		else
		{
			printf("\n 2.DCR revision Tag not found"); fflush(stdout);
		}
		if(GRM_find_relation_type("CMReferences",&relation_type)!=ITK_ok)PrintErrorStack();
		if(GRM_list_secondary_objects_only(DCRREVTag, relation_type,&sec_count,&sec_objects));
		printf("\n dataset name:%d", sec_count);fflush(stdout);
		if(sec_count==0)
		{

			printf("\n DCR PDF Attachment function started:\n");fflush(stdout);	
			sprintf(command,"/user/cvprod/Program_Shells/DML_DCR/CVBUDCR/t5_mint_DCR_pdf_copying.sh %s ",DCRId);

			printf("\n commandd:%s ",command);fflush(stdout);
			SysReturn = system(command);
			//if(ITEM_find_revision(DCRTag,"NR",&DCRREVTag)) ;
			if(STRNG_replace_str(DCRFile, ";", "_", &FinalDCRFile)!=ITK_ok)PrintErrorStack();

			printf("\n FinalDCRFile: [%s] ",FinalDCRFile); fflush(stdout);
			printf("\n Start--attach DCR pdf  under change Reference");fflush(stdout);

			//Creating dataset for storing the Text File *****************

			IMF_file_t fileDescriptor;
			AE_reference_type_t tagRefType =  1;
			tag_t tool =  NULLTAG;
			tag_t filetag =  NULLTAG;
			tag_t PdfDataset =  NULLTAG;
			tag_t pdfType=NULLTAG;
			tag_t specificationRel_t =  NULLTAG;
			tag_t PdfLatestDat_t =  NULLTAG;

			tc_strcpy(datesetNam,DCRId);
			tc_strcat(datesetNam,"-approval");
			tc_strcat(datesetNam,".pdf");
			
			if(STRNG_replace_str(datesetNam, ";", "_", &datesetNamTemp)!=ITK_ok)PrintErrorStack();
			
			printf("\n datesetNamTemp: [%s] ",datesetNamTemp); fflush(stdout);
			tc_strcpy(filepath,"/user/cvprod/Program_Shells/DML_DCR/CVBUDCR/DcrPdf/");
			tc_strcat(filepath,datesetNamTemp);

			printf("\n DCR PDF Creation and attached in Revision FinalDCRFile: [%s] ",FinalDCRFile);fflush(stdout);
			printf("\n pdf name: [%s] ",pdf);fflush(stdout);

			if(AE_find_datasettype2("PDF",&pdfType)!=ITK_ok)PrintErrorStack();

			if(pdfType == NULLTAG)
			{
				TC_write_syslog("Could not find Dataset Type PDF. Please check data model\n");
				printf("\n Could not find Dataset Type PDF.");fflush(stdout);
				//continue;
			}
			if(AE_create_dataset_with_id(pdfType,datesetNamTemp,"DCRPDF","","",&pdfDataset)!=ITK_ok)PrintErrorStack();
			printf("\n L14:create dataset done..");fflush(stdout);
			if(AE_save_myself(pdfDataset));
			printf(" and saved.");fflush(stdout);
			if(GRM_create_relation(DCRREVTag,pdfDataset,relation_type,NULLTAG,&Report_Relation)!=ITK_ok)PrintErrorStack();
			printf("\n L15:create relation done..");fflush(stdout);
			if(AOM_load(Report_Relation)!=ITK_ok)PrintErrorStack();
			printf("\n and load.");fflush(stdout);
			if(GRM_save_relation(Report_Relation)!=ITK_ok)PrintErrorStack();
			printf("\n and saved..");fflush(stdout);
			if(AE_ask_dataset_latest_rev(pdfDataset,&latestDataset));
			printf("\n L16:get dataset_latest_rev..\n");fflush(stdout);
			if(AOM_lock(latestDataset)!=ITK_ok)PrintErrorStack();
			printf("\n and refreshed..");fflush(stdout);
			//if(AE_import_named_ref(latestDataset,"word",docFile,NULL,SS_BINARY)!=ITK_ok)PrintErrorStack();
			if(AE_import_named_ref(latestDataset,"PDF_Reference",filepath,NULL,SS_BINARY)!=ITK_ok)PrintErrorStack();
			printf("\n L17:Import data..");fflush(stdout);
			//if(AE_save_myself(latestDataset)!=ITK_ok)PrintErrorStack();
			AOM_save_without_extensions(latestDataset);
			printf("\n and save dataset..");fflush(stdout);
			AOM_refresh(latestDataset, FALSE);
			printf("\n 2.and save dataset..");fflush(stdout);
			AOM_unload(latestDataset);
			printf("\n 3.and save dataset..");fflush(stdout);
		}
		else
		{
			printf("\n PDF is already attached...\n");fflush(stdout);
		}
}