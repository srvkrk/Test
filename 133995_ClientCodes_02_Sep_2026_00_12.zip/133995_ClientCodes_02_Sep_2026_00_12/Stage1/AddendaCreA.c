#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define STRSIZE 200
#define NUMWORDS 11

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	
	//if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	//{
		//print_requirement();
		//return -1;
	//}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	//ifail = read_value_from_file(file);
	ifail = Addenda_Cre(file);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

/********************************************************************************************
    Function:       Addenda_Cre
    Description:    
********************************************************************************************/
int Addenda_Cre(char* Filename)
{
	int		count			=0;
	int		FlagA			=0;
    int i, j = 0;
	tag_t item_type_tag				= NULLTAG;
	tag_t item_create_input_tag		= NULLTAG;
	tag_t cfg_item_create_input_tag = NULLTAG;
	tag_t object					= NULLTAG;
	tag_t cfg_object				= NULLTAG;
	tag_t cfg_item_type_tag			= NULLTAG;
	tag_t relation_type				= NULLTAG;
	tag_t new_relation				= NULLTAG;
	tag_t cc_item_tag				= NULLTAG;
	tag_t cc_item_Rev_tag			= NULLTAG;
	tag_t	item_tag				= NULLTAG;
	char* error_str					= NULL;
	char* s = "^";

	char *object_name = (char *) MEM_alloc( 100 * sizeof(char) );
	char *obj_item_id = (char *) MEM_alloc( 100 * sizeof(char) );
	char *projectcode = (char *) MEM_alloc( 100 * sizeof(char) );
	char *Addenda_desc = (char *) MEM_alloc( 100 * sizeof(char) );
	char *addPlant = (char *) MEM_alloc( 100 * sizeof(char) );	
	char *temp	=  (char *) MEM_alloc( 200 * sizeof(char) );;

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				obj_item_id = strtok(temp, "^");
				tc_strcpy(object_name,obj_item_id);
				printf("\nInput Item_id:%s",obj_item_id); fflush(stdout);

				projectcode = strtok(NULL, "^");
				tc_strcpy(Addenda_desc,obj_item_id);
				printf("\nInput rev_id:%s",projectcode); fflush(stdout);

				addPlant = strtok(NULL, "^");
				printf("\nInput addPlant:%s\n",addPlant);fflush(stdout);

				printf("\n\t Addenda item_id :%s", obj_item_id);fflush(stdout);
				printf("\n\t object_name :%s", object_name);fflush(stdout);
				printf("\n\t projectcode :%s", projectcode);fflush(stdout);
				printf("\n\t Addenda_desc :%s", Addenda_desc);fflush(stdout);
				printf("\n\t addPlant :%s", addPlant);fflush(stdout);
				char *designgroupA[] = {"00","01","02","03","04","05","06","07","09","11","12","13","14","15","16","17","18","19","20","21","22","23"};
				char *designgroupB[] = {"24","25","26","27","28","29","30","31","32","33","34","35","37","38","39","40","41","42","43","44","45","46","47","49","50","51","52","53","54","55","56","57","58","59"};
				char *designgroupC[] = {"60","61","62","63","64","65","66","67","68","69","70","71","72","73","77","75","76","77","78","79","80","81","82","83","84","85","86","87","88","89","90","91","92","93","94","95","96","97","98","99"};
				for (i =0 ; i < 3 ; i++)
				{
					if (i =0)
					{
						printf("\n\t DML addenda for designgroupA ");
						printf("\n\t *****Creating the T5_DmlAddenda******");fflush(stdout);
						ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
						ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
						ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", NULL));
						//ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
						ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
						ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", projectcode));
						ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", "CU"));
						ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",36, designgroupA));
						ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
						printf("\n\t *****Saving the the T5_DmlAddenda******");fflush(stdout);
						ifail = (AOM_save (object));
						ifail = ITEM_find_item (obj_item_id, &item_tag);
						if(item_tag == NULLTAG)
						{
							printf("\n Addenda ID :%s is not created",obj_item_id);
							return 1;
						}
						else
						{
							printf("\n **************Addenda ID :%s is created*************",obj_item_id);
						}
					}

				}
					printf("\n\t DML addenda not previously present in the system [%s]",obj_item_id);
					printf("\n\t *****Creating the T5_DmlAddenda******");fflush(stdout);
					ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
					ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
					ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_id));
					ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
					ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
					ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
					ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
					ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",36, designgroupB));
					ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
					printf("\n\t *****Saving the the T5_DmlAddenda******");fflush(stdout);
					ifail = (AOM_save (object));
					ifail = ITEM_find_item (obj_item_id, &item_tag);
					if(item_tag == NULLTAG)
					{
						printf("\n Addenda ID :%s is not created",obj_item_id);
						return 1;
					}
					else
					{
						printf("\n **************Addenda ID :%s is created*************",obj_item_id);
					}
				}
				else
				{
					printf("\n\t DML addenda found for %s",obj_item_id);fflush(stdout);
					printf("\n\t************* CODE END *********\n%s",temp);fflush(stdout);
					return 1;
				}
			}
		}
	}

	if(object_name != NULL)
		MEM_free(object_name);

	if(obj_item_id != NULL)
		MEM_free(obj_item_id);

	if(projectcode != NULL)
		MEM_free(projectcode);

	if(Addenda_desc != NULL)
		MEM_free(Addenda_desc);

	if(addPlant != NULL)
		MEM_free(addPlant);

	return ifail;
}
