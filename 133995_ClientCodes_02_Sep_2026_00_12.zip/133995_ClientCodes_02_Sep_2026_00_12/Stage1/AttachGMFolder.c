/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:apl.c
*
* Description		: > This Utility is to do unit testing of functions .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 05/08/2018   	Sanjoy Mondal			    Initial Code
/user/cvprod/TC_ROOT14/tcldPatch/tcPatchExecutable AttachGMFolder
./AttachGMFolder -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -DML=23JU146008_87

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <qry/qry.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define ITEM_CHECKED_OUT  EMH_USER_error_base + 5
#define JT_PDF_NOT_FOUND  EMH_USER_error_base + 8
#define Not_Item_Revision  EMH_USER_error_base + 6
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

/* Function to add Tag into a set of Tag */	
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		printf("\n ****setAddTAG1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		printf("\n ****setAddTAG2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

int ITK_user_main(int argc, char* argv[])
{
	int		error_code				=	ITK_ok;
	int		ifail 			= ITK_ok;
	char 	*user			= NULL;
	char 	*pass			= NULL;
	char	*partNumber		=NULL;
	int		design_rev_cnt			=	0;
	int		dataset_cnt,i			=	0;
	int		result					=   0;
//	int		result,count			=   0;
	tag_t	objTypeTag				=	NULLTAG;

	tag_t	select_itemrev			=   NULLTAG;
	tag_t	dataset_relation_type	=   NULLTAG;
	tag_t	obj_type				=   NULLTAG;
	tag_t	relation				=   NULLTAG;
	
	char	*designrev				=	NULL;
	char	*chkout_val				=   NULL;
	char	*IndentCategory			=   NULL;
	char	*dataset_typeName		=   NULL;
	char	*data_set_Project		= NULL;
	char	*DesRevProj		= NULL;
	char	*ERCIndQtyset		= NULL;
	char	*ERCIndReqQtyset		= NULL;
	tag_t	ERCTaskObjTag				=	NULLTAG;
	
	
	tag_t	PartIndrel				=   NULLTAG;
	tag_t  newPartIndrel = NULLTAG;
	char	*IndentName			=	NULL;
	char	*designrevName			=	NULL;
	char	*designrevNameObjstr			=	NULL;
	
	char   type_name[TCTYPE_name_size_c+1];
	//char   type_name1[TCTYPE_name_size_c+1];
	char *type_name1 = NULL;
	
	tag_t	priObjTypeTag			=	NULLTAG;
	//char ** strngSet = NULL;
	tag_t 	latestReleasedPart = NULLTAG;
	tag_t 	prevOffPart = NULLTAG;
	tag_t latestPart = NULLTAG;
	tag_t partMasterObj = NULLTAG;
	tag_t Attachrelation_type=NULLTAG;
	tag_t DMLTskTag=NULLTAG;
	tag_t DMLTskRevTag=NULLTAG;
	int cnt1=0;
	tag_t *attachments1;


				char  Projj[40]={"0"};
				int Gmcnt1=0;
				int ProjectAccessFound=0;
				int FlaggAssignPlanner=0;
				int countt=0;
				int b=0;
				int z=0;
				tag_t	*GmFound1 = NULLTAG;
				char *Object_Name  =  NULL;
				const char 
		*attrs[1] = {"item_id"},
		*values[1] = {"*"};
	char* TaskNum	= ITK_ask_cli_argument("-DML=");
	char* userid	= ITK_ask_cli_argument("-u=");
	char* password	= ITK_ask_cli_argument("-pf=");
	char* group		= ITK_ask_cli_argument("-g=");

	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	else
	{
		printf("\nUser has not Privileged Admin User \n\n");
	}

	printf("\n *********** Start Of Utility Execution ************* \n");fflush(stdout);
	printf("Login successfull. user[%s], group[%s]\n", user,group);fflush(stdout);	

	
	printf("\n DML Number=[%s]",TaskNum);
	char * DMLno = NULL;
	DMLno =  (char *) MEM_alloc(20 * sizeof(char));
	tc_strcpy(DMLno,"");
	tc_strcat(DMLno,"*");
	tc_strcat(DMLno,TaskNum);
	tc_strcat(DMLno,"*");

	printf("\nFolder to query [%s]  \n",DMLno);fflush(stdout);

	//tag_t TagQryContObj = NULLTAG,*Des_objects = NULLTAG;
	tag_t *GMDFolder = NULLTAG;
	
	int	n_entries = 2;
	int n_found = 0;
	char    **qry_values     =  (char **) MEM_alloc(30 * sizeof(char *));
	char *qry_entries[2]={"Description","Type"};
	//char *qry_entries[1]={"Description"};
	qry_values[0]= DMLno;
	qry_values[1]= "Folder";
	tag_t GeneralQryTag = NULLTAG;

	
	if(QRY_find2("General...", &GeneralQryTag));
	if (GeneralQryTag)
	{
		printf("\nGeneral... Found Query");	fflush(stdout);
	}
	else
	{
		printf("\n General...:Not Found Query \n");fflush(stdout);
		if(POM_logout(false)!=ITK_ok)PrintErrorStack();
		return ifail;
	}
	if(QRY_execute(GeneralQryTag, n_entries, qry_entries, qry_values, &n_found, &GMDFolder));
	printf("\n Objects for Query Design rev == %d", n_found);fflush(stdout);
	
	if(n_found > 0)
	{
		for (i=0;i<n_found ;i++ )
		{
		
			ERCTaskObjTag = GMDFolder[0];
			if (TCTYPE_ask_object_type(ERCTaskObjTag,&priObjTypeTag)!=ITK_ok);
			if (TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok);
			printf("primary obj type_name ::  %s\n", type_name1);
			if (tc_strcmp(type_name1,"Folder")==0)
			{
				printf("\nFould Object is of type folder");	
			
				AOM_ask_value_string(ERCTaskObjTag,"current_desc",&IndentName);
				printf(" Folder Description  %s\n",IndentName);fflush(stdout);
				GRM_find_relation_type("CMReferences", &PartIndrel);
				printf(" find relation CMReferences \n");fflush(stdout);

				if(PartIndrel != NULLTAG)
				{
					printf(" CMReferences null \n");fflush(stdout);
					ITEM_find_item(TaskNum,&DMLTskTag);
					ITEM_ask_latest_rev(DMLTskTag,&DMLTskRevTag);
					
					AOM_ask_value_string(DMLTskRevTag,"item_id",&designrevName);
					printf(" designrevName %s\n",designrevName);fflush(stdout);

					AOM_ask_value_string(DMLTskRevTag,"object_string",&designrevNameObjstr);
					printf(" designrevNameObjstr %s\n",designrevNameObjstr);fflush(stdout);

					if (DMLTskRevTag != NULLTAG && ERCTaskObjTag != NULLTAG)
					{
						(GRM_create_relation(DMLTskRevTag,ERCTaskObjTag,PartIndrel,NULLTAG,&newPartIndrel));
						if(newPartIndrel != NULLTAG)
						{
							(GRM_save_relation(newPartIndrel));
							printf("\n relation created %s",designrevName);fflush(stdout);
						}
						//printf(" relation created");fflush(stdout);
					}
					else
					{
						printf(" Indent number or design rev is null");fflush(stdout);
					}
				}

			}
			else
			{
				printf("\nERRRROOOOORRRRRRRR- Found object is not Folder");
				
			}
		}
	}
	else
	{
		printf("\nERRRROOOOORRRRRRRR- Folund multiple folder tags");
		return 1;
	}
	return 0;
	
}


