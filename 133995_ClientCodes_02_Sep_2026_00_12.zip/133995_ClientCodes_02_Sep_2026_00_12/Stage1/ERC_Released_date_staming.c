/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: ERC_Released_date_staming.c
**
** Functions:- 	This utility takes DML No and DR_status as input from file and updates the value of DR_status attribute for latest revision of
				DML found from input and writes appropriate information into output file.
**
**
**	Date							Author							Modification
**	6-Dec-2025						Mohan Tayade					ERC_Released_Status_staming
**
** command to run:
** ./ERC_Released_date_staming -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -file=<Filename>
***********************************************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#define PROP_UIF_set_value_msg		"PROP_UIF_set_value"
#include <tccore/aom.h>
#include <res/res_itk.h>
//#include <bom/bom.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <tccore/releasestatus.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define PROP_UIF_set_value_msg		"PROP_UIF_set_value"

FILE 		*output 			= NULL;
char		*sep				= ",";
int read_value_from_file(char*);
int DML_property_upd(char*,char*);
int write_info(char*, char*, char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -pf=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<filename> (required)\n"
        );
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
					It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;
	char			* sObjno					= NULL;
	char			* sProperty					= NULL;
	char			* sValue					= NULL;
	char			Data[100]					= "";

	char 			*test						= (char*)MEM_alloc(sizeof(char) * 500);
	char			outputFile[200]				= "";

	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");
	//sObjno		= ITK_ask_cli_argument("-number=");
	//sProperty		= ITK_ask_cli_argument("-property=");
	//sValue		= ITK_ask_cli_argument("-value=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);

	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}

	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	output = fopen(outputFile,"a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully...!!\n");
		}

		tc_strcpy(test, "");
		tc_strcpy(test,"DML_No");
		tc_strcat(test,sep);
		tc_strcat(test,"Property");
		tc_strcat(test,sep);
		tc_strcat(test,"Value");

		fprintf(output,"%s\n",test);
		MEM_free(test);

		ifail = read_value_from_file(Filename);
		//ifail = read_value_from_file(sObjno,sProperty,sValue);

	printf("\nEnd of program.....!!\n\n");
	printf("\n*****************************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;

	char 			*itemid					= NULL;
	char 			*inputDate				= NULL;
	char 			*value					= NULL;
	char 			temp[200];

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, ",");
				//if(itemid)nlsStrTrimTrailWhiteSpace(itemid);
				printf("\nInput Item_id:%s",itemid); fflush(stdout);

				inputDate = strtok(NULL, ",");
				//if(property)nlsStrTrimTrailWhiteSpace(property);
				printf("\nInput rev_id:%s",inputDate); fflush(stdout);

				/*value = strtok(NULL, ",");
				//if(value)nlsStrTrimTrailWhiteSpace(value);
				printf("\nInput value:%s\n",value);fflush(stdout);*/

				ifail = DML_property_upd(itemid,inputDate);
			}
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");fflush(stdout);
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       update_dr_status
    Description:    This function takes the item_id and attr_value as input and stamps the
					attr_value on specific attribute of all revisions of perticular item.
********************************************************************************************/

int DML_property_upd(char* item_id,char* inputDate)
{
	int				ifail 						= ITK_ok;
	int				r_count 					= 0;
	int				i		 					= 0;

	tag_t			DML_tag						= NULLTAG;
	tag_t			rev_tag						= NULLTAG;

	char 			*dr_status_new				= NULL;
	char 			*updvalue					= NULL;
	
	int status_count = 0;
	tag_t parttag = NULLTAG;
	tag_t prtrevtag = NULLTAG;
	tag_t attr_tag = NULLTAG;
	tag_t* status_list = NULLTAG;
	tag_t	tsk_dml_rel_type	= NULLTAG;
	tag_t	*Task = NULLTAG;
	date_t set_date;
	char* DMLno = NULL;
	char* objType = NULL;
	char* status_name = NULL;
	char* task_id = NULL;
	//char* item_id = NULL;
	tag_t objTypTag			=NULLTAG;
	//char* updvalue = NULL;
	char* revid1 = NULL;
	
	ifail = ITEM_find_item (item_id, &DML_tag);
	ifail = ITEM_ask_latest_rev (DML_tag, &rev_tag);
	if(ifail != ITK_ok)
	{
		printf("Object not found in Teamcenter...!!\n");fflush(stdout);
		return 0;
	}
	else
	{
		printf("Object found in Teamcenter...!!\n");fflush(stdout);
		ITKCALL(TCTYPE_ask_object_type(rev_tag,&objTypTag));
		if(objTypTag==NULLTAG)
		{
			printf("\n DML:BBBBB.\n");fflush(stdout);
		}
		ITKCALL(TCTYPE_ask_name2(objTypTag,&objType));
		printf("\n  object_type is %s\n", objType);fflush(stdout);

		if(tc_strcmp(objType,"ChangeRequestRevision")==0)
		{
			//ITKCALL(ITEM_find_revision(parttag,revid1,&rev_tag));
			printf("\n Getting DML no..  \n");fflush(stdout);
			// ITKCALL(ITK_string_to_date(inputDate, &set_date));
			if(AOM_ask_value_string(rev_tag,"item_id",&item_id)!=ITK_ok)PrintErrorStack();
			printf("\n item_id of DML\n\n = %s  \n",item_id);fflush(stdout);
			ITKCALL(ITK_string_to_date(inputDate, &set_date));
			ITKCALL( WSOM_ask_release_status_list(rev_tag,&status_count,&status_list));
			int i =0;
			for(i =0 ; i < status_count; i++)
			{
				ITKCALL(AOM_ask_value_string(status_list[i], "object_name", &status_name));
				printf("\nStatus Name is = %s  \n",status_name);fflush(stdout);
				if ((tc_strcmp(status_name,"T5_LcsErcRlzd") == 0) ||(tc_strcmp(status_name,"ERC Released")==0))
				{
					printf("\n Released Status matched \n");fflush(stdout);
					//23CU001085,23-Dec-2024 11:11,
					ITKCALL(POM_attr_id_of_attr("date_released", "ChangeRequestRevision", &attr_tag)); //date_released
					ITKCALL(POM_refresh_instances_any_class(1, &status_list[i], POM_modify_lock));
					ITKCALL(POM_set_attr_date(1, &status_list[i], attr_tag, set_date));  
					ITKCALL(POM_save_instances(1, &status_list[i], true));
					printf("\n Released status Date Stamped \n");fflush(stdout);

					if(AOM_refresh (rev_tag, 1)!=ITK_ok)PrintErrorStack();
					if(AOM_lock( rev_tag)!=ITK_ok)PrintErrorStack();
					//if(AOM_UIF_set_value (rev_tag, "t5_Platform", value)!=ITK_ok)PrintErrorStack();
					if(AOM_UIF_set_value (rev_tag,"date_released", inputDate)!=ITK_ok)PrintErrorStack();
					if(AOM_save_without_extensions (rev_tag)!=ITK_ok)PrintErrorStack();
					if(AOM_unlock(rev_tag)!=ITK_ok)PrintErrorStack();
					if(AOM_refresh (rev_tag, 0)!=ITK_ok)PrintErrorStack();

					//ifail = AOM_UIF_ask_value (rev_tag,"t5_Platform",&updvalue);
					ifail = AOM_UIF_ask_value (rev_tag,"date_released",&updvalue);
					printf("\n stamped with [%s] on Latest Rev:....!!",updvalue);fflush(stdout);
				}
			}
		}
		printf("\n done for date...\n");fflush(stdout);
	}

	return ifail;
}
