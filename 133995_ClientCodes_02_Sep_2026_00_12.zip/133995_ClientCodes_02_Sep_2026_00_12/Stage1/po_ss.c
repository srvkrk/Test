/*******************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: po_details_stamp.c
**
** Functions:-	This utility takes item id as input from file and queries it into teamcenter. If object found,
				stamps the last_mod_date and last_mod_user on released reivision and PO details(plant, PO_Date etc.)
				on it's rev_master form.
**
**
**	Date							Author								Modification
**	01-Jan-2019						Kalpesh Gondhali					Code Creation
**  01-03-2023                      Anup Sonawane                       Query validation colour parts 
**
**
** command to run:
** po_details_stamp -u=<username> -pf=<password> -g=<group> -file=<Filename>
********************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/emh.h>
#include <stdlib.h>
//#include <bom/bom.h>
#include <qry/qry.h>
#include <fclasses/tc_date.h>
#include <tc/folder.h>
#include <tccore/releasestatus.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
//#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define PROP_UIF_set_value_msg		"PROP_UIF_set_value"
#define PROP_set_value_tag_msg		"PROP_set_value_tag"
#define PROP_ask_value_date_msg		"PROP_ask_value_date"
#define PROP_set_value_date_msg		"PROP_set_value_date"
#define PROP_set_value_string_msg   "PROP_set_value_string"


int			ifail 				= ITK_ok;
char		*sep				= "^";

int read_value_from_file(char*);
int	query_object(char*, char*, char*, char*, char*, char*, char*, char*, char*, char*, char*);

void print_requirement()
{
	printf(
        " HELP:\n"
        " po_details_stamp -u=<username> -pf=<password file> -g=<group> -file=<input Filename>\n"
        );fflush(stdout);
}

static int   validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
//    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day , &year , &hour , &minute , &second);                          // working for " 21-August-2015" / ""
//    retcode = DATE_string_to_date ( date , "%m-%d-%y-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);                          // working for  "07-21-2015-09:05:58"
    retcode = DATE_string_to_date ( date , "%y/%m/%d-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

        printf("\nreturn from validate_date...!!");fflush(stdout);

    return retcode;
}


/*struct PTModule_attr
	{
		char		*PT_aggr_grp;
		char		*PT_aggr;
		char		*PT_module_grp;
		char		*PT_module;
	};
*/

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
					It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	//int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;

	/*char 			Data[100]    				= "";
	char 			OutputFile[200]    			= "";*/

	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");

	/*time_t now;
	struct tm when;

	time(&now);
	when = *localtime(&now);

	strftime(Data, 100, "%d_%m_%Y_%H_%M_%S", &when);
	sprintf(OutputFile, "%s_PO_details_stamp.txt", Data);*/

	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");fflush(stdout);
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");fflush(stdout);
			printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}

	/*output = fopen(OutputFile,"a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}*/

		ifail = read_value_from_file(Filename);

	//fclose(output);
	printf("\n*********************\n");fflush(stdout);
	printf("\nEnd of program.....!!\n");fflush(stdout);
	printf("\n*********************\n");fflush(stdout);
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;
	int totalpartsCnt = 0;

	char 			*itemid					= NULL;
	char 			*plant					= NULL;
	char 			*plant_val				= NULL;
	char 			*po_val					= NULL;
	char 			*po_date				= NULL;
	char 			*net_price				= NULL;
	char 			*vendor_id				= NULL;
	char 			*bulkMaterial			= NULL;
	char 			*stock					= NULL;
	char 			*transaction			= NULL;
	char 			*rev					= NULL;
	char 			temp[1000];
	char 			revid[10];

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 1000, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				totalpartsCnt++ ;

				itemid = strtok(temp, ",");
				printf("\n [%d]  Input Item_id:%s",totalpartsCnt,itemid);fflush(stdout);

				plant = strtok(NULL, ":");
				printf("\nInput Plant:%s",plant);fflush(stdout);

				plant_val = strtok(NULL, ",");
				printf("\nInput plant_val:%s",plant_val);fflush(stdout);

				po_val = strtok(NULL, ",");
				printf("\nInput po_val:%s",po_val);fflush(stdout);

				po_date = strtok(NULL, ",");
				printf("\nInput po_date:%s",po_date);fflush(stdout);

				rev = strtok(NULL, ",");
				printf("\nInput rev:%s",rev);fflush(stdout);

				net_price = strtok(NULL, ",");
				printf("\nInput net_price:%s",net_price);fflush(stdout);

				vendor_id = strtok(NULL, ",");
				printf("\nInput vendor_id:%s",vendor_id);fflush(stdout);

				bulkMaterial = strtok(NULL, ",");
				printf("\nInput bulkMaterial:%s",bulkMaterial);fflush(stdout);

				stock = strtok(NULL, ",");
				printf("\nInput stock:%s",stock);fflush(stdout);

				transaction = strtok(NULL, ",");
				printf("\nInput transaction:%s",transaction);fflush(stdout);

				tc_strcpy(revid, "");
				tc_strcpy(revid, rev);
				tc_strcat(revid, "*");

				printf("\nRevision:%s\n", revid);fflush(stdout);
				/*fprintf(output,"%s", itemid);
				fprintf(output,"%s%s",sep, revid);*/

				ifail = query_object(itemid, revid, plant, plant_val, po_val, po_date, net_price, vendor_id, bulkMaterial, stock, transaction);

				printf("\n----------------------------------------------------------------------\n");fflush(stdout);
			}
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	return ifail;
}


/*****************************************************************************************************
    Function:       query_object
    Description:    This function queries the item into TC and update it's released revision's
					attribute and Revision Master Form's attribute values as per input.
*****************************************************************************************************/
int query_object(char* itemid, char* revid, char* plant, char* plant_val, char* po_val, char* po_date, char* net_price, char* vendor_id, char* bulkMaterial, char* stock, char* transaction)
{
	int				ifail 						= ITK_ok;
	int				i	 						= 0;
	int				ii	 						= 0;
	int				j	 						= 0;
	int				results						= 0;
	int				statusflag						= 0;
	int				sec_count					= 0;
	int             status_count                =0;
	int             FinalReldate                =0;
	int             FinalPOdate                =0;

	char			*entry0						= "ID";
	char			*entry1						= "Revision";
	char			*entry2 					= "EE Part Revision";
    char			*rel_status					= "ERC Released";

	char			*rel_stat				    = NULL;
	char			*sec_obj_type				= NULL;
	char			*rev_last_mod_user			= NULL;
	char			*object_rev_id				= NULL;
	char			*form_last_mod_user			= NULL;
	char			*cp_last_md_dt				= NULL;
	char			*cp_last_md_dt_form			= NULL;
	char			*str_dt						= NULL;
	char			*DateS						= NULL;
	char			*DateTempS					= NULL;
	char			*DateTempS1					= NULL;
	char			*DateTempS2					= NULL;
	char			*DateTempS3					= NULL;
	char			str[5];
	char 			*po_date1				= NULL;

    char			*Year						= NULL;
    char			*Year1						= NULL;
    char			*Month						= NULL;
    char			*Month1						= NULL;
    char			*Day						= NULL;
    char			*Day1						= NULL;
    char			*Hours						= NULL;
    char			*Min						= NULL;
    char			*Sec						= NULL;
    char			*MicroSec					= NULL;
	char			*rel_date		            = NULL;
	char			*eff_date		            = NULL;
	char			*rel_date1		            = NULL;
	char			*poDate		                = NULL;
	char			*current_po_date		    = NULL;
	char			*status_name		    = NULL;

	tag_t			query_tag					= NULLTAG;
	tag_t			query_tag1					= NULLTAG;
    tag_t		    rev_user_tag			    = NULLTAG;
	tag_t			form_user_tag				= NULLTAG;
	tag_t           Release_status=NULLTAG; 
	tag_t			Part_tag					= NULLTAG;
	tag_t			*object_tag					= NULL;
	tag_t			*sec_obj					= NULL;
	tag_t           * Release_status_list=NULL;
	

	date_t			DT_po_date					= NULLDATE;
	date_t			rev_last_mod_dt				= NULLDATE;
	date_t			form_last_mod_dt		    = NULLDATE;
	
	
	
	
	

	char**  		entries						= NULL;
	char**  		values						= NULL;
   //  char*		qry_entries�				= NULL;
	// char** 		qry_values					= NULL;



	char**  		entries1					= NULL;
	char**  		values1						= NULL;
	
	logical			date_is_valid				= FALSE;

	entries		= (char**) MEM_alloc (sizeof(char*) * 20);
	values		= (char**) MEM_alloc (sizeof(char*) * 20);

	entries1  = (char**) MEM_alloc (sizeof(char*) * 20);    // start
	values1   = (char**) MEM_alloc (sizeof(char*) * 20);    // end


	entries[0] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry0) + 20));
	values[0]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(itemid) + 20));

	entries[1] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry1) + 20));
	values[1]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(revid) + 20));

   // new Start
    entries1[0] = (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry0) + 20));
	values1[0]  = (char*) MEM_alloc (sizeof(char) *       20);

	entries1[1] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry1) + 20));
    values1[1]  	= (char*) MEM_alloc (sizeof(char) *   20);

     entries1[2] 	= (char*) MEM_alloc (sizeof(char) *    10);
	 values1[2]  	= (char*) MEM_alloc (sizeof(char) *    20);
	 // END


	DateS		=(char *)MEM_alloc(100);
	DateTempS	=(char *)MEM_alloc(100);



	tc_strcpy(entries[0], "");
	tc_strcpy(entries[0], entry0);
	tc_strcpy(values[0], "");
	tc_strcpy(values[0], itemid);

	tc_strcpy(entries[1], "");
	tc_strcpy(entries[1], entry1);
	tc_strcpy(values[1], "");
	tc_strcpy(values[1], revid);

	// new start
	tc_strcpy(entries1[0], "");
	tc_strcpy(entries1[0], entry0);
	tc_strcpy(values1[0], "");
	tc_strcpy(values1[0], itemid);

	tc_strcpy(entries1[1], "");
	tc_strcpy(entries1[1], entry1);
	tc_strcpy(values1[1], "");
	tc_strcpy(values1[1], revid);

	tc_strcpy(entries1[2], "");
	tc_strcpy(entries1[2],"Type");
	tc_strcpy(values1[2], "");
	tc_strcpy(values1[2],entry2);
     // New End

	ifail = QRY_ignore_case_on_search(TRUE);
	ifail = QRY_find2("Design Revision", &query_tag);

	if(query_tag == NULLTAG)
	{
		printf("\nQuery Not Found in TC....!!\n");fflush(stdout);
		return 0;
	}
	else
	{
		ifail = QRY_execute(query_tag, 2, entries, values, &results, &object_tag);
		printf("\n A.DesignRevision---Count=%d object found ",results); fflush(stdout);
      
		if(results == 0)
		{
			printf("\n  Inside New Item Revision... Query"); fflush(stdout);
			ifail = QRY_find2("Item Revision...", &query_tag1);
			ifail = QRY_execute(query_tag1, 3, entries1, values1, &results, &object_tag);
			printf("\n C.ItemRevision--Count=%d object found ",results); fflush(stdout);
		}
		if(results == 0)
		{
			ifail = QRY_find2("ClrPartRevision", &query_tag);
			ifail = QRY_execute(query_tag, 2, entries, values, &results, &object_tag);
			printf("\n B.ClrPartRevision--Count=%d object found ",results); fflush(stdout);
		}
	}
		statusflag=0;
		if(results > 0)
		{
			printf("\nTotal %d objects found \n", results);fflush(stdout);
			
			for(i=0; i<results; i++)
			{

				ifail = AOM_UIF_ask_value(object_tag[i], "release_status_list", &rel_stat);
				CHECK_FAIL;
				printf("\nRelease status:%s", rel_stat);fflush(stdout);
				
				if(tc_strlen(rel_stat) == 0)
				{
					printf("\n\t Release Flag is Not Found ??\n");fflush(stdout);
				}

				if(tc_strcmp(rel_stat, rel_status) == 0 || tc_strstr(rel_stat, rel_status) != 0)
				{
					ifail = AOM_UIF_ask_value(object_tag[i], "item_revision_id", &object_rev_id);
					ifail = AOM_ask_value_date(object_tag[i], "last_mod_date", &rev_last_mod_dt);
					ifail = ITK_date_to_string(rev_last_mod_dt, &cp_last_md_dt);
					ifail = AOM_UIF_ask_value(object_tag[i], "last_mod_user", &rev_last_mod_user);
					//ifail = AOM_ask_value_tag(object_tag[i], "last_mod_user", &rev_user_tag);
					ifail = AOM_ask_last_modifier(object_tag[i], &rev_user_tag);
					printf("\nLast Modification Date:%s and \nuser:%s for revision:%s", cp_last_md_dt, rev_last_mod_user, object_rev_id);

					ifail = GRM_list_secondary_objects_only(object_tag[i], NULLTAG, &sec_count, &sec_obj);
					CHECK_FAIL;
					printf("\n sec_count = [%d] ", sec_count );fflush(stdout);

					for(j=0; j<sec_count; j++)
					{
						ifail = AOM_UIF_ask_value(sec_obj[j], "object_type", &sec_obj_type);
						printf("\n sec_obj_type = %s ", sec_obj_type);fflush(stdout);

						if(tc_strcmp(sec_obj_type, "Design Revision Master") == 0 || tc_strcmp(sec_obj_type, "EE Part Revision Master") == 0 || tc_strcmp(sec_obj_type, "Clr Part Revision Master") == 0 )
						{
							printf("\nInside Clr Part Revision Master");fflush(stdout);
							ifail = AOM_ask_value_date(sec_obj[j], "last_mod_date", &form_last_mod_dt);
							ifail = ITK_date_to_string(form_last_mod_dt, &cp_last_md_dt_form);
							ifail = AOM_UIF_ask_value(sec_obj[j], "last_mod_user", &form_last_mod_user);
							//ifail = AOM_ask_value_tag(sec_obj[j], "last_mod_user", &form_user_tag);
							ifail = AOM_ask_last_modifier(sec_obj[j], &form_user_tag);
							printf("\nLast Modification Date:%s and user:%s for Master Form", cp_last_md_dt_form, form_last_mod_user);

							ifail = AOM_refresh(sec_obj[j], 1);
							ifail = AOM_UIF_set_value(sec_obj[j], plant, plant_val);
							ifail =  AOM_save_without_extensions(sec_obj[j]);
							ifail = AOM_refresh(sec_obj[j], 0);

							strcpy(DateTempS,"");
							strcpy(DateTempS,po_date);

							Year=strtok(DateTempS,"/");
							Month=strtok(NULL,"/");
							Day=strtok(NULL,"-");
							Hours=strtok(NULL,":");
							Min=strtok(NULL,":");
							Sec=strtok(NULL,":");
							MicroSec=strtok(NULL,":");

							printf("\n1..%s",Year); fflush(stdout);

							strcpy(DateS,"");

							strcpy(DateS,Year);
							strcat(DateS,"/");
							printf("\n2..%s",Month); fflush(stdout);
							strcat(DateS,Month);
							strcat(DateS,"/");
							printf("\n3..%s",Day); fflush(stdout);
							strcat(DateS,Day);
							strcat(DateS,"-");
							printf("\n4..%s",Hours); fflush(stdout);
							strcat(DateS,Hours);
							strcat(DateS,":");
							printf("\n5..%s",Min); fflush(stdout);
							strcat(DateS,Min);
							strcat(DateS,":");
							printf("\n6..%s",Sec); fflush(stdout);
							strcat(DateS,Sec);
							printf("\n"); fflush(stdout);

							printf("\nNew Date is --> [%s]\n",DateS); fflush(stdout);
							ifail = validate_date(DateS, &date_is_valid, &DT_po_date);
							if (ifail != ITK_ok)
							{
							        printf("Error code %d\n", ifail); fflush(stdout);
							        return ifail;
							}

							if(tc_strlen(plant) == 9)
							{
								ifail = AOM_refresh (sec_obj[j], 1);
								CHECK_FAIL;

								str[0] = plant[8];
								str[1] = '\0';

								printf("\nstr===> %s", str);fflush(stdout);
								
								if(tc_strcmp(str, "1") == 0)
								{
									printf("\n\t po_val: %s", po_val);fflush(stdout);
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO1", po_val);
									CHECK_FAIL;

									printf("\n\t DT_po_date: %s", DateS);fflush(stdout);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate1", DT_po_date);
									CHECK_FAIL;

									printf("\n\t vendor_id:%s", vendor_id);fflush(stdout);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID1", " ");

									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID1",vendor_id );
										CHECK_FAIL;
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice1", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice1",net_price );
										CHECK_FAIL;
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial1", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial1", bulkMaterial);
										CHECK_FAIL;
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock1", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock1", stock);
										CHECK_FAIL;
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction1", " ");
									}
									else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction1", transaction);
										CHECK_FAIL;
									}

								}
								else if(tc_strcmp(str, "2") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO2", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate2", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID2", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID2",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice2", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice2",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial2", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial2", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock2", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock2", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction2", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction2", transaction);
									}
								}
								else if(tc_strcmp(str, "3") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO3", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate3", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID3", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID3",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice3", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice3",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial3", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial3", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock3", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock3", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction3", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction3", transaction);
									}
								}
								else if(tc_strcmp(str, "4") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO4", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate4", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID4", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID4",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice4", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice4",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial4", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial4", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock4", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock4", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction4", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction4", transaction);
									}
								}
								else if(tc_strcmp(str, "5") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO5", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate5", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID5", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID5",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice5", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice5",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial5", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial5", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock5", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock5", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction5", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction5", transaction);
									}
								}
								else if(tc_strcmp(str, "6") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO6", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate6", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID6", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID6",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice6", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice6",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial6", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial6", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock6", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock6", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction6", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction6", transaction);
									}
								}
								else if(tc_strcmp(str, "7") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO7", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate7", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID7", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID7",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice7", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice7",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial7", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial7", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock7", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock7", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction7", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction7", transaction);
									}
								}
								else if(tc_strcmp(str, "8") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO8", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate8", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID8", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID8",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice8", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice8",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial8", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial8", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock8", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock8", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction8", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction8", transaction);
									}
								}
								else if(tc_strcmp(str, "9") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO9", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate9", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID9", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID9",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice9", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice9",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial9", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial9", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock9", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock9", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction9", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction9", transaction);
									}
								}
								//printf("\nBefore save objects ");fflush(stdout);



								ifail = AOM_save_without_extensions(sec_obj[j]);
								ifail = AOM_refresh (sec_obj[j], 0);
							}
							else if(tc_strlen(plant) == 10)
							{
								str[0] = plant[8];
								str[1] = plant[9];
								str[2] = '\0';
								printf("\nstr:%s\n", str);

								ifail = AOM_refresh (sec_obj[j], 1);
								if(tc_strcmp(str, "10") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO10", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate10", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID10", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID10",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice10", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice10",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial10", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial10", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock10", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock10", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction10", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction10", transaction);
									}
								}
								else if(tc_strcmp(str, "11") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO11", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate11", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID11", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID11",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice11", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice11",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial11", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial11", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock11", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock11", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction11", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction11", transaction);
									}
								}
								else if(tc_strcmp(str, "12") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO12", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate12", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID12", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID12",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice12", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice12",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial12", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial12", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock12", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock12", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction12", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction12", transaction);
									}
								}

								ifail = AOM_save_without_extensions(sec_obj[j]);
								ifail = AOM_refresh (sec_obj[j], 0);
							}
							//printf("\nBefore save objects2 ");fflush(stdout);

							ifail = AOM_refresh(object_tag[i], 1);
							ifail = ITK_set_bypass(true);
							//ifail = AOM_string_to_tag(rev_last_mod_user, &rev_user_tag);
							ifail = POM_set_modification_date(object_tag[i], rev_last_mod_dt);
							ifail = POM_set_modification_user(object_tag[i], rev_user_tag);
							//ifail = AOM_UIF_set_value(object_tag[i], "last_mod_user", rev_last_mod_user);
							ifail = POM_set_env_info(POM_bypass_attr_update , false, 0, 0.0, NULLTAG, "");
							ifail = AOM_save_without_extensions(object_tag[i]);
							ifail = AOM_refresh (object_tag[i], 0);

							ifail = AOM_refresh (sec_obj[j], 1);
							ifail = ITK_set_bypass(true);
							//ifail = AOM_string_to_tag(form_last_mod_user, &form_user_tag);
							ifail = POM_set_modification_date(sec_obj[j], form_last_mod_dt);
							ifail = POM_set_modification_user(sec_obj[j], form_user_tag);
							//ifail = AOM_UIF_set_value(sec_obj[j], "last_mod_user", form_last_mod_user);
							ifail = POM_set_env_info(POM_bypass_attr_update , false, 0, 0.0, NULLTAG, "");
							ifail = AOM_save_without_extensions(sec_obj[j]);
							ifail = AOM_refresh(sec_obj[j], 0);
							//printf("\nAfter save objects ");fflush(stdout);
						}
					}
					MEM_free(sec_obj);
				}
				else
				{
					printf("\n\t Release Status is skiping");fflush(stdout);
					statusflag=1;
				}
				
			}
		}
		if(results==0 || statusflag==1 )
			{
		
		
		
		ifail=ITEM_find_item(itemid,&Part_tag);
		ifail=ITEM_list_all_revs(Part_tag,&results,&object_tag);
			if(results > 0)
		{
			printf("\n11 Total %d objects found \n", results);fflush(stdout);
			
	
			for(i=results-1; i>=0; i--)
			{
			printf("\n 11 For loop \n", results);fflush(stdout);
			//ITK_CALL (ITK_string_to_date(po_date , &poDate_tag));
			
			ifail = WSOM_ask_release_status_list	(object_tag[i],&status_count,&Release_status_list);
					   printf("\nstatus count:%d",status_count);
					   if(status_count>0)
					   {
					   for(ii=0;ii<status_count;ii++)
					   {
				   
				   
				   Release_status=Release_status_list[ii];
					   RELSTAT_ask_release_status_type(Release_status,&status_name);
				   printf("\nRelease Status:%s",status_name);
				   if(strcmp(status_name,"T5_LcsErcRlzd")==0)
				   {
					   AOM_UIF_ask_value(Release_status,"effectivity_text",&eff_date);
					   rel_date=(char *)MEM_alloc(100);
					   rel_date=strtok(eff_date," ");
					   printf("\nstart date of eff:%s",rel_date);
					   if(strlen(eff_date)==0)
					   {  printf("\nEffectivity is null checking for released date");
						   AOM_UIF_ask_value(Release_status,"date_released",&rel_date);}
					   
					   
				       if(tc_strstr(rel_date,"Jan")) {STRNG_replace_str(rel_date,"Jan","01",&rel_date);}
                       else if(tc_strstr(rel_date,"Feb")) {STRNG_replace_str(rel_date,"Feb","02",&rel_date);}
                       else if(tc_strstr(rel_date,"Mar")) {STRNG_replace_str(rel_date,"Mar","03",&rel_date);}
                       else if(tc_strstr(rel_date,"Apr")) {STRNG_replace_str(rel_date,"Apr","04",&rel_date);}
                       else if(tc_strstr(rel_date,"May")) {STRNG_replace_str(rel_date,"May","05",&rel_date);}
                       else if(tc_strstr(rel_date,"Jun")) {STRNG_replace_str(rel_date,"Jun","06",&rel_date);}
                       else if(tc_strstr(rel_date,"Jul")) {STRNG_replace_str(rel_date,"Jul","07",&rel_date);}
                       else if(tc_strstr(rel_date,"Aug")) {STRNG_replace_str(rel_date,"Aug","08",&rel_date);}
                       else if(tc_strstr(rel_date,"Sep")) {STRNG_replace_str(rel_date,"Sep","09",&rel_date);}
                       else if(tc_strstr(rel_date,"Oct")) {STRNG_replace_str(rel_date,"Oct","010",&rel_date);}
                       else if(tc_strstr(rel_date,"Nov")) {STRNG_replace_str(rel_date,"Nov","011",&rel_date);}
                       else if(tc_strstr(rel_date,"Dec")) {STRNG_replace_str(rel_date,"Dec","012",&rel_date);}
			           printf("\nrel_date : %s", rel_date);fflush(stdout);
				      DateTempS1=(char *)MEM_alloc(100);
				  //DateTempS2=(char *)MEM_alloc(100);
		    strcpy(DateTempS1,"");
			strcpy(DateTempS1,rel_date);
			
			DateTempS2=strtok(DateTempS1," ");
			printf("\nDateTempS2 : %s", DateTempS2);fflush(stdout);
			Day1=strtok(DateTempS2,"-");
			Month1=strtok(NULL,"-");
			Year1=strtok(NULL,"-");
			
			rel_date1=(char *)MEM_alloc(100);
			rel_date1=strcpy(rel_date1,"");
		    rel_date1=strcat(rel_date1,Year1);
		    rel_date1=strcat(rel_date1,Month1);
		    rel_date1=strcat(rel_date1,Day1);
			
			 printf("\nrel_date : %s", rel_date1);fflush(stdout);
                 
				 break;
				  
					}
					
				   }
				   }
				 if(po_date!=NULL && rel_date!=NULL ) 
				 {
		    strcpy(DateTempS,"");
			strcpy(DateTempS,po_date);
			Year=strtok(DateTempS,"/");
			Month=strtok(NULL,"/");
			Day=strtok(NULL,"-");
			Hours=strtok(NULL,":");
			Min=strtok(NULL,":");
			Sec=strtok(NULL,":");
			
			po_date1	=(char *)MEM_alloc(100);
			po_date1=strcpy(po_date1,"");
		    po_date1=strcat(po_date1,Year);
		    po_date1=strcat(po_date1,Month);
		    po_date1=strcat(po_date1,Day);
			
			printf("\nPO_date : %s", po_date1);fflush(stdout);
			
			FinalPOdate=atoi(po_date1);
			FinalReldate=atoi(rel_date1);
			
			if(FinalReldate<FinalPOdate)
			{
			
				ifail = AOM_UIF_ask_value(object_tag[i], "release_status_list", &rel_stat);
				CHECK_FAIL;
				printf("\nRelease status:%s", rel_stat);fflush(stdout);
				
				if(tc_strlen(rel_stat) == 0)
				{
					printf("\n\t Release Flag is Not Found ??\n");fflush(stdout);
				}

				if(tc_strcmp(rel_stat, rel_status) == 0 || tc_strstr(rel_stat, rel_status) != 0)
				{
					ifail = AOM_UIF_ask_value(object_tag[i], "item_revision_id", &object_rev_id);
					ifail = AOM_ask_value_date(object_tag[i], "last_mod_date", &rev_last_mod_dt);
					ifail = ITK_date_to_string(rev_last_mod_dt, &cp_last_md_dt);
					ifail = AOM_UIF_ask_value(object_tag[i], "last_mod_user", &rev_last_mod_user);
					//ifail = AOM_ask_value_tag(object_tag[i], "last_mod_user", &rev_user_tag);
					ifail = AOM_ask_last_modifier(object_tag[i], &rev_user_tag);
					printf("\nLast Modification Date:%s and \nuser:%s for revision:%s", cp_last_md_dt, rev_last_mod_user, object_rev_id);

					ifail = GRM_list_secondary_objects_only(object_tag[i], NULLTAG, &sec_count, &sec_obj);
					CHECK_FAIL;
					printf("\n sec_count = [%d] ", sec_count );fflush(stdout);

					for(j=0; j<sec_count; j++)
					{
						ifail = AOM_UIF_ask_value(sec_obj[j], "object_type", &sec_obj_type);
						printf("\n sec_obj_type = %s ", sec_obj_type);fflush(stdout);

						if(tc_strcmp(sec_obj_type, "Design Revision Master") == 0 || tc_strcmp(sec_obj_type, "EE Part Revision Master") == 0 || tc_strcmp(sec_obj_type, "Clr Part Revision Master") == 0 )
						{
							printf("\nInside Clr Part Revision Master");fflush(stdout);
							ifail = AOM_ask_value_date(sec_obj[j], "last_mod_date", &form_last_mod_dt);
							ifail = ITK_date_to_string(form_last_mod_dt, &cp_last_md_dt_form);
							ifail = AOM_UIF_ask_value(sec_obj[j], "last_mod_user", &form_last_mod_user);
							//ifail = AOM_ask_value_tag(sec_obj[j], "last_mod_user", &form_user_tag);
							ifail = AOM_ask_last_modifier(sec_obj[j], &form_user_tag);
							printf("\nLast Modification Date:%s and user:%s for Master Form", cp_last_md_dt_form, form_last_mod_user);

							ifail = AOM_refresh(sec_obj[j], 1);
							ifail = AOM_UIF_set_value(sec_obj[j], plant, plant_val);
							ifail = AOM_save_without_extensions(sec_obj[j]);
							ifail = AOM_refresh(sec_obj[j], 0);

							strcpy(DateTempS,"");
							strcpy(DateTempS,po_date);

							Year=strtok(DateTempS,"/");
							Month=strtok(NULL,"/");
							Day=strtok(NULL,"-");
							Hours=strtok(NULL,":");
							Min=strtok(NULL,":");
							Sec=strtok(NULL,":");
							MicroSec=strtok(NULL,":");

							printf("\n1..%s",Year); fflush(stdout);

							strcpy(DateS,"");

							strcpy(DateS,Year);
							strcat(DateS,"/");
							printf("\n2..%s",Month); fflush(stdout);
							strcat(DateS,Month);
							strcat(DateS,"/");
							printf("\n3..%s",Day); fflush(stdout);
							strcat(DateS,Day);
							strcat(DateS,"-");
							printf("\n4..%s",Hours); fflush(stdout);
							strcat(DateS,Hours);
							strcat(DateS,":");
							printf("\n5..%s",Min); fflush(stdout);
							strcat(DateS,Min);
							strcat(DateS,":");
							printf("\n6..%s",Sec); fflush(stdout);
							strcat(DateS,Sec);
							printf("\n"); fflush(stdout);

							printf("\nNew Date is --> [%s]\n",DateS); fflush(stdout);
							ifail = validate_date(DateS, &date_is_valid, &DT_po_date);
							if (ifail != ITK_ok)
							{
							        printf("Error code %d\n", ifail); fflush(stdout);
							        return ifail;
							}

							if(tc_strlen(plant) == 9)
							{
								ifail = AOM_refresh (sec_obj[j], 1);
								CHECK_FAIL;

								str[0] = plant[8];
								str[1] = '\0';

								printf("\nstr===> %s", str);fflush(stdout);
								
								if(tc_strcmp(str, "1") == 0)
								{
									printf("\n\t po_val: %s", po_val);fflush(stdout);
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO1", po_val);
									CHECK_FAIL;

									printf("\n\t DT_po_date: %s", DateS);fflush(stdout);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate1", DT_po_date);
									CHECK_FAIL;

									printf("\n\t vendor_id:%s", vendor_id);fflush(stdout);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID1", " ");

									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID1",vendor_id );
										CHECK_FAIL;
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice1", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice1",net_price );
										CHECK_FAIL;
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial1", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial1", bulkMaterial);
										CHECK_FAIL;
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock1", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock1", stock);
										CHECK_FAIL;
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction1", " ");
									}
									else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction1", transaction);
										CHECK_FAIL;
									}

								}
								else if(tc_strcmp(str, "2") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO2", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate2", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID2", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID2",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice2", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice2",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial2", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial2", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock2", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock2", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction2", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction2", transaction);
									}
								}
								else if(tc_strcmp(str, "3") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO3", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate3", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID3", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID3",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice3", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice3",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial3", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial3", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock3", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock3", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction3", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction3", transaction);
									}
								}
								else if(tc_strcmp(str, "4") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO4", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate4", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID4", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID4",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice4", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice4",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial4", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial4", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock4", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock4", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction4", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction4", transaction);
									}
								}
								else if(tc_strcmp(str, "5") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO5", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate5", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID5", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID5",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice5", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice5",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial5", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial5", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock5", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock5", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction5", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction5", transaction);
									}
								}
								else if(tc_strcmp(str, "6") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO6", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate6", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID6", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID6",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice6", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice6",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial6", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial6", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock6", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock6", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction6", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction6", transaction);
									}
								}
								else if(tc_strcmp(str, "7") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO7", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate7", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID7", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID7",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice7", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice7",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial7", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial7", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock7", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock7", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction7", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction7", transaction);
									}
								}
								else if(tc_strcmp(str, "8") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO8", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate8", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID8", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID8",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice8", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice8",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial8", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial8", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock8", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock8", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction8", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction8", transaction);
									}
								}
								else if(tc_strcmp(str, "9") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO9", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate9", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID9", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID9",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice9", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice9",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial9", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial9", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock9", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock9", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction9", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction9", transaction);
									}
								}
								//printf("\nBefore save objects ");fflush(stdout);



								ifail = AOM_save_without_extensions(sec_obj[j]);
								ifail = AOM_refresh (sec_obj[j], 0);
							}
							else if(tc_strlen(plant) == 10)
							{
								str[0] = plant[8];
								str[1] = plant[9];
								str[2] = '\0';
								printf("\nstr:%s\n", str);

								ifail = AOM_refresh (sec_obj[j], 1);
								if(tc_strcmp(str, "10") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO10", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate10", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID10", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID10",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice10", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice10",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial10", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial10", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock10", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock10", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction10", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction10", transaction);
									}
								}
								else if(tc_strcmp(str, "11") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO11", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate11", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID11", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID11",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice11", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice11",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial11", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial11", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock11", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock11", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction11", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction11", transaction);
									}
								}
								else if(tc_strcmp(str, "12") == 0)
								{
									ifail = AOM_UIF_set_value (sec_obj[j], "t5_PO12", po_val);
									ifail = AOM_set_value_date(sec_obj[j], "t5_PODate12", DT_po_date);

									if (tc_strcmp(vendor_id, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID12", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_VendorID12",vendor_id );
									}

									if (tc_strcmp(net_price, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice12", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_NetPrice12",net_price );
									}

									if (tc_strcmp(bulkMaterial, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial12", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_BulkMaterial12", bulkMaterial);
									}

									if (tc_strcmp(stock, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock12", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Stock12", stock);
									}

									if (tc_strcmp(transaction, "NA") == 0)
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction12", " ");
									}else
									{
										ifail = AOM_UIF_set_value (sec_obj[j], "t5_Transaction12", transaction);
									}
								}

								ifail = AOM_save_without_extensions(sec_obj[j]);
								ifail = AOM_refresh (sec_obj[j], 0);
							}
							//printf("\nBefore save objects2 ");fflush(stdout);

							ifail = AOM_refresh(object_tag[i], 1);
							ifail = ITK_set_bypass(true);
							//ifail = AOM_string_to_tag(rev_last_mod_user, &rev_user_tag);
							ifail = POM_set_modification_date(object_tag[i], rev_last_mod_dt);
							ifail = POM_set_modification_user(object_tag[i], rev_user_tag);
							//ifail = AOM_UIF_set_value(object_tag[i], "last_mod_user", rev_last_mod_user);
							ifail = POM_set_env_info(POM_bypass_attr_update , false, 0, 0.0, NULLTAG, "");
							ifail = AOM_save_without_extensions(object_tag[i]);
							ifail = AOM_refresh (object_tag[i], 0);

							ifail = AOM_refresh (sec_obj[j], 1);
							ifail = ITK_set_bypass(true);
							//ifail = AOM_string_to_tag(form_last_mod_user, &form_user_tag);
							ifail = POM_set_modification_date(sec_obj[j], form_last_mod_dt);
							ifail = POM_set_modification_user(sec_obj[j], form_user_tag);
							//ifail = AOM_UIF_set_value(sec_obj[j], "last_mod_user", form_last_mod_user);
							ifail = POM_set_env_info(POM_bypass_attr_update , false, 0, 0.0, NULLTAG, "");
							ifail = AOM_save_without_extensions(sec_obj[j]);
							ifail = AOM_refresh(sec_obj[j], 0);
							//printf("\nAfter save objects ");fflush(stdout);
						}
					}
					MEM_free(sec_obj);
				}
				else
				{
					printf("\n\t Release Status is skiping");fflush(stdout);
				}
				
			break;
			}
			
			
			}
			}
		}
		MEM_free(object_tag);

	}

	return ifail;
}

