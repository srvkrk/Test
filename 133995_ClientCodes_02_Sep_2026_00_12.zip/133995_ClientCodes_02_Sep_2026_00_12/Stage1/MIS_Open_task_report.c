/***************************************************************************
 *
 *Copyright (c) 2018 Tata Technologies Limited (TTL). All Rights
 *Reserved.
 *
 *This software is the confidential and proprietary information of TTL.
 *You shall not disclose such confidential information and shall use it
 *only in accordance with the terms of the license agreement.
 *
 *File                  :   MIS_Open_task_report.c
 *Author                :   Sushant Magdum/Sandeep Goyal/Nilesh Kumar
 *Created On   		 	:   18-Nov-2021
 *Modified On   		:   29-Apr-2022
 *Module       		 	:	
 *Purpose      		 	:   CV Level Open DML TASK Summary
 *Modify                :	Consolidated view of Attachment in Mail Body with stack view.
 ***************************************************************************/
#include <stdlib.h>
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#include <uly.h>
#include <ui.h>
#include <Mtimsg.h>
#include <meta.h>
#include <mserv.h>
#include <msg.h>
#include <msgomf.h>
#include <mutproto.h>
#include <nls.h>
#include <serv.h>
#include <sys.h>
#include <cfg.h>
#include <Mtimsgh.h>
#include <pdmitem.h>


struct Date
{
	int d, m, y;
};

struct date1
{
	int day,month,year;
}sTartDate,endDate;

int LeapYear(int Year)
{
	if(((Year % 4 == 0) && (Year % 100 != 0)) || Year % 400 == 0)
		return 1;
	else
		return 0;
	
}

const int monthDays[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

int countLeapYears(struct Date d)
{
	int years = d.y;

	if (d.m <= 2)
		years--;

	return years / 4 -
		years / 100 +
		years / 400;
}

int getDifference(struct Date dt1, struct Date dt2)
{
	printf("\n Inside get Difference ");fflush(stdout);
	int i, j;
	long int n2;

	long int n1 = dt1.y *365 + dt1.d;
	for (i = 0; i < dt1.m - 1; i++)
	{
		n1 = n1 + monthDays[i];
	}

	n1 = n1 + countLeapYears(dt1);

	n2 = dt2.y *365 + dt2.d;

	for (j = 0; j < dt2.m - 1; j++)
	{
		n2 = n2 + monthDays[j];
	}

	n2 = n2 + countLeapYears(dt2);

	return (n2 - n1);
}

//string CatStrings(string TotalCountStr,string ClosedCountStr,string OpenCountStr,string BelowTenStr,string AboveTenStr,string AbeyanceStr)
string CatStrings(string TotalCountStr,string ClosedCountStr,string AbeyanceStr,string OpenCountStr,string BelowTenStr,string AboveTenStr,string BelowtenclosedStr,string DmlTskCmpltdLTTenDaysstr,string DmlTskCmpltdperstr,string BlwTenClsdTrToAbycStr,string AbeyanceTrnsfPerStr)
{
	printf("\n Inside CatStrings");
	string FullString = NULL;	
	FullString=nlsStrAlloc(500);
	
	nlsStrCpy(FullString,"");
	nlsStrCat(FullString,TotalCountStr);
	nlsStrCat(FullString,",");
	nlsStrCat(FullString,ClosedCountStr);
	nlsStrCat(FullString,",");
	nlsStrCat(FullString,AbeyanceStr);
	nlsStrCat(FullString,",");
	nlsStrCat(FullString,OpenCountStr);
	nlsStrCat(FullString,",");
	nlsStrCat(FullString,BelowTenStr);
	nlsStrCat(FullString,",");
	nlsStrCat(FullString,AboveTenStr);
	nlsStrCat(FullString,",");
	nlsStrCat(FullString,BelowtenclosedStr);
	nlsStrCat(FullString,",");
	nlsStrCat(FullString,DmlTskCmpltdLTTenDaysstr);
	nlsStrCat(FullString,",");
	nlsStrCat(FullString,DmlTskCmpltdperstr);
	nlsStrCat(FullString,",");
	nlsStrCat(FullString,BlwTenClsdTrToAbycStr);
	nlsStrCat(FullString,",");
	nlsStrCat(FullString,AbeyanceTrnsfPerStr);
	
	return FullString;
}

string getMonth (string FromMonth)
{
	printf("\n Inside getMonth");

	string MonthSnd = NULL;	
	MonthSnd=nlsStrAlloc(20);
	nlsStrCpy(MonthSnd,"");

	printf("\n Form Month : %s",FromMonth);

	if((nlsStrCmp(FromMonth,"01") == 0) || (nlsStrCmp(FromMonth,"13") == 0) || (nlsStrCmp(FromMonth,"1") ==0))
	{
        nlsStrCpy(MonthSnd, "January");
	}
	if((nlsStrCmp(FromMonth,"02") == 0) || (nlsStrCmp(FromMonth,"14") == 0) || (nlsStrCmp(FromMonth,"2") == 0))
	{
        nlsStrCpy(MonthSnd, "February");
	}
	if((nlsStrCmp(FromMonth,"03") == 0) || (nlsStrCmp(FromMonth,"15") == 0) || (nlsStrCmp(FromMonth,"3")==0))
	{
        nlsStrCpy(MonthSnd, "March");
	}
	if((nlsStrCmp(FromMonth,"04") == 0) || (nlsStrCmp(FromMonth,"16") == 0) || (nlsStrCmp(FromMonth,"4")==0))
	{
        nlsStrCpy(MonthSnd, "April");
	}
	if((nlsStrCmp(FromMonth,"05") == 0) || (nlsStrCmp(FromMonth,"5")==0))
	{
        nlsStrCpy(MonthSnd, "May");
	}
	if((nlsStrCmp(FromMonth,"06") == 0) || (nlsStrCmp(FromMonth,"6")==0))
	{
        nlsStrCpy(MonthSnd, "June");
	}
	if((nlsStrCmp(FromMonth,"07") == 0) || (nlsStrCmp(FromMonth,"7")==0))
	{
        nlsStrCpy(MonthSnd, "July");
	}
	if((nlsStrCmp(FromMonth,"08") == 0) || (nlsStrCmp(FromMonth,"8")==0))
	{
        nlsStrCpy(MonthSnd, "August");
	}
	if((nlsStrCmp(FromMonth,"09") == 0) || (nlsStrCmp(FromMonth,"9")==0))
	{
        nlsStrCpy(MonthSnd, "September");
	}
	if((nlsStrCmp(FromMonth,"10") == 0) || (nlsStrCmp(FromMonth,"10")==0))
	{
		nlsStrCpy(MonthSnd, "October");
	}
	if((nlsStrCmp(FromMonth,"11") == 0) || (nlsStrCmp(FromMonth,"11") ==0))
	{
        nlsStrCpy(MonthSnd, "November");
	}
	if((nlsStrCmp(FromMonth,"12") == 0) || (nlsStrCmp(FromMonth,"12") ==0))
	{
        nlsStrCpy(MonthSnd, "December");
	}
		
	printf("\n MonthSnd %s",MonthSnd);fflush(stdout);
	
	return MonthSnd;
}


int main(int argc, char *argv[])
{

	t5MethodInitWMD("MIS_Open_task_report");

	FILE *fp_log, *fp_rep;
	int stat = 0;
	// string LoginS = NULL;
	// string PasswordS = NULL;
	SET_PTR DBToSet = NULL;
	string LogFileName = NULL;
	string ReportFileName = NULL;
	string timestamp1 = NULL;

	//string FromDate = NULL;
	string DateFromSet = NULL;
	string DateFromSetDup = NULL;
	string FromDateForMonth = NULL;
	//string ToDate = NULL;
	string ToDateDup = NULL;
	string ToDateDup2 = NULL;
	string FromDateDup = NULL;
	string STy1 = NULL;
	string STm1 = NULL;
	ToDateDup2 = nlsStrAlloc(50);
	ToDateDup = nlsStrAlloc(50);
	//string FromYear = NULL;
	string FromMonth = NULL;
	
	
	string STd1 = NULL;
	int Td1 = 0;
	int Tm1 = 0;
	int Ty1 = 0;
	int d1 = 0;
	int m1 = 0;
	int y1 = 0;
	int d3 = 0;
	int m3 = 0;
	int y3 = 0;
	int num = 0;
	int AvgAge = 0;
	int AvgCount = 0;
	int HisNum = 0;
	int found = 0;
	int s = 0;
	int Sigcount = 0;
	int Taskcount = 0;
	int Plntcount = 0;
	string Plant = NULL;
	string PlantDup = NULL;

	LogFileName = nlsStrAlloc(50);
	ReportFileName = nlsStrAlloc(100);

	//FromDate = nlsStrAlloc(30);
	FromDateDup = nlsStrAlloc(50);
	//ToDate = nlsStrAlloc(30);
	ToDateDup = nlsStrAlloc(50);

	timestamp1 = sysGetCTime();
	low_strrpl(timestamp1, ' ', '_');
	low_strrpl(timestamp1, ':', '_');

	SetOfStrings PlantSet = NULL;

	PlantSet = setCreate(5);
	//************************************************ Creating PLant set - PlantSet - Start ****************************************************************
	low_set_add_str_unique(PlantSet, "PCVBU");					// Modified
	low_set_add_str_unique(PlantSet, "JSR");                        
	low_set_add_str_unique(PlantSet, "LKO");                      // Modified
	low_set_add_str_unique(PlantSet, "PNR");                      // Modified
	low_set_add_str_unique(PlantSet, "DWD");						// Modified
	//************************************************ Creating PLant set - PlantSet - End ******************************************************************
	
	//************************************************ Creating set for date starting from April to one month privious to current month - Start *************
	SetOfStrings DateSet = NULL;
	SetOfStrings Strs = NULL;
	SetOfStrings Strs2 = NULL;

	DateSet = setCreate(1);
	
	string CurrDate	= NULL; 					// Current Date
	CurrDate = nlsStrAlloc(50);
	CurrDate	= sysGetDate();
	//nlsStrCpy(CurrDate,"2023-4-01");
	string year = NULL;							// Current Year
	string month = NULL;						// Current Month
	string Day = NULL;							// Current Day
	year = nlsStrAlloc(50);
	month = nlsStrAlloc(50);
	Day = nlsStrAlloc(50);
	string DateSetStr = NULL;					// Create DateSet String
	DateSetStr = nlsStrAlloc(50);

	//SetOfStrings DateSet = NULL;
	//DateSet = setCreate(1);
	
	nlsStrCpy(year,strtok(CurrDate,"-"));					// tok current year into year var
	nlsStrCpy(month,strtok(NULL,"-"));						// tok current month into year var
	nlsStrCpy(Day,strtok(NULL,"-"));						// tok current Day into year var
	
	
	int yearInt = atoi(year);								// current year in int format
	int monthInt = atoi(month);								// current month in int format
	int CurrentMonth = atoi(month);							// stores current month in int format
	
	
	int fincYearStart = 0; 		// finanacial year	start						
	int fincYearEnd = 0;		// financial year End
	int tempMonth2 = 0; 		// for jan to mar next year
	int flag = 0;
	int tempMonth = monthInt;
	int tempYear =yearInt;
	int tempYear2 =yearInt;
	string toYearStr = NULL;
	toYearStr = nlsStrAlloc(10);
	string toMonth = NULL;
	toMonth = nlsStrAlloc(10);
	string EndYearStr = NULL;
	EndYearStr = nlsStrAlloc(10);
	string EndMonth = NULL;
	EndMonth = nlsStrAlloc(10);
	string EndDay = NULL;
	EndDay = nlsStrAlloc(10);
	
	if (monthInt <= 4)
	{
		tempMonth	= 13;
		tempMonth2 = monthInt;
		tempYear = yearInt;
		tempYear2 = yearInt - 1;
	}
	int MonthIterator = 0;
	for ( MonthIterator = 4;  MonthIterator<tempMonth; MonthIterator++)
	{
		 printf("\n inside MonthIterator");fflush(stdout);
		sTartDate.year = tempYear2;
		sTartDate.month = MonthIterator;
		
		endDate.year = tempYear2;
		endDate.month = MonthIterator;
		endDate.day = monthDays[MonthIterator - 1];
		
		nlsStrCpy(DateSetStr,"");
		sprintf(toYearStr,"%d",sTartDate.year);
		nlsStrCat(DateSetStr,toYearStr);
		nlsStrCat(DateSetStr,"/");
		if(sTartDate.month<10)
			sprintf(toMonth,"0%d",sTartDate.month);
		else
			sprintf(toMonth,"%d",sTartDate.month);
		nlsStrCat(DateSetStr,toMonth);
		nlsStrCat(DateSetStr,"/");
		nlsStrCat(DateSetStr,"01");
		
		nlsStrCat(DateSetStr,"~");
		sprintf(EndYearStr,"%d",endDate.year);
		nlsStrCat(DateSetStr,EndYearStr);
		nlsStrCat(DateSetStr,"/");
		if(endDate.month<10)
			sprintf(EndMonth,"0%d",endDate.month);
		else
			sprintf(EndMonth,"%d",endDate.month);
		nlsStrCat(DateSetStr,EndMonth);
		nlsStrCat(DateSetStr,"/");
		sprintf(EndDay,"%d",endDate.day);
		nlsStrCat(DateSetStr,EndDay);
		low_set_add_str_unique(DateSet,DateSetStr);
		if(flag == 0)
		{
			fincYearStart = yearInt;
			fincYearEnd = yearInt + 1;
			flag = 1;
		}
		
	}

	for	(MonthIterator = 1;MonthIterator<tempMonth2;MonthIterator++)
	{
		
		endDate.year = tempYear;
		endDate.month = MonthIterator;
		endDate.day = monthDays[MonthIterator-1];
		
		sTartDate.year = tempYear;
		sTartDate.month = MonthIterator;
		nlsStrCpy(DateSetStr,"");
		sprintf(toYearStr,"%d",sTartDate.year);
		nlsStrCat(DateSetStr,toYearStr);
		nlsStrCat(DateSetStr,"/");
		sprintf(toMonth,"0%d",sTartDate.month);
		nlsStrCat(DateSetStr,toMonth);
		nlsStrCat(DateSetStr,"/");
		nlsStrCat(DateSetStr,"01");
		
		nlsStrCat(DateSetStr,"~");
		sprintf(EndYearStr,"%d",endDate.year);
		nlsStrCat(DateSetStr,EndYearStr);
		nlsStrCat(DateSetStr,"/");
		sprintf(EndMonth,"0%d",endDate.month);
		nlsStrCat(DateSetStr,EndMonth);
		nlsStrCat(DateSetStr,"/");
		if(LeapYear(yearInt) == 1 && MonthIterator==2 )
			endDate.day =29;
		
		sprintf(EndDay,"%d",endDate.day);
		nlsStrCat(DateSetStr,EndDay);
		
		low_set_add_str_unique(DateSet,DateSetStr);
	}	
	// End of Custom code
	//low_set_add_str_unique(DateSet,"2022/04/01~2022/04/30");
	//low_set_add_str_unique(DateSet,"2022/05/01~2022/05/01");
	//low_set_add_str_unique(DateSet,"2022/06/01~2022/06/01");
	//low_set_add_str_unique(DateSet,"2021/07/01~2021/07/31");
	//low_set_add_str_unique(DateSet,"2021/08/01~2021/08/31");
	//low_set_add_str_unique(DateSet,"2021/09/01~2021/09/30");
	//low_set_add_str_unique(DateSet,"2021/10/01~2021/10/31");
	//low_set_add_str_unique(DateSet,"2021/11/01~2021/11/30"); 
	//low_set_add_str_unique(DateSet,"2021/12/01~2021/12/31");
	//low_set_add_str_unique(DateSet,"2022/01/01~2022/01/31");
	//low_set_add_str_unique(DateSet,"2022/02/01~2022/02/28");
	//low_set_add_str_unique(DateSet,"2022/03/01~2022/03/31");
/* 	low_set_add_str_unique(DateSet,"/12/01~/12/31");
	low_set_add_str_unique(DateSet,"/01/01~/01/31");
	low_set_add_str_unique(DateSet,"/02/01~/02/29");
	low_set_add_str_unique(DateSet,"/03/01~/03/31");  */
	printf("\n DateSet Size = %d",setSize(DateSet));fflush(stdout);
		
	//************************************************ Creating set for date starting from April to one month privious to current month - End ****************	
	
	string FromDateSet = NULL;           
	string MonthPrint = NULL;           
	string ToDateSet = NULL;

	int DateCount = 0;
	string sysdate = NULL;
	string sysdateDup = NULL;
	sysdate = nlsStrAlloc(100);
	MonthPrint = nlsStrAlloc(20);

	sysdate = sysGetDate2();
	sysdateDup = nlsStrDup(sysdate);
	integer			reportWidth			= 1000;
	Strs			= setCreate(1);
	Strs2			= setCreate(1);

	printf("\n System Date : %s\n", sysdateDup);fflush(stdout);		

	nlsStrCpy(LogFileName, "CV_Level_Open_DML_TASK_Summary_Log");
	nlsStrCat(LogFileName, timestamp1);
	nlsStrCat(LogFileName, ".log");

	//nlsStrCpy(ReportFileName, "CV_Level_Open_DML_TASK_Summary_");
	nlsStrCpy(ReportFileName, "ECM_CV_Level_DML_Dashboard_");
	nlsStrCat(ReportFileName, timestamp1);
	nlsStrCat(ReportFileName, ".csv");
	fp_log = fopen(LogFileName, "w");
	fp_rep = fopen(ReportFileName, "w");
	
	// if(dstat = ulyValueLines("ECM CV Level Open DML Task Summary as on ",TRUE,0,45,reportWidth,&Strs2)) goto EXIT;
	// if(dstat = ulyValueLines(sysdateDup,FALSE,46,75,reportWidth,&Strs2)) goto EXIT;
	// if(dstat = ulyValueLines("Plant,CV-PUNE,CV-JSR,CV-LKN,CV-UTK,CV-DWD,Year Wise Total",TRUE,0,60,reportWidth,&Strs2)) goto EXIT;
	// if(dstat = ulyValueLines("Financial Year 2022-2023,",TRUE,0,30,reportWidth,&Strs2)) goto EXIT;
	// if(dstat = ulyValueLines("\n\n CV Level Monthwise DML TASK Count Break up - Finacial Year : 2022-2023",TRUE,0,75,reportWidth,&Strs)) goto EXIT;
	// if(dstat = ulyValueLines("Plant-->,CV-PUNE,,,,,,CV-JSR,,,,,,CV-LKO,,,,,,CV-UTK,,,,,,CV-DWD",TRUE,0,200,reportWidth,&Strs)) goto EXIT;
	// if(dstat = ulyValueLines("Month ,Total Task,TASK Released,Total Open TASK,Open(Less than / Equal to 10 Days),Open(More than 10 Days),Transferred to Abeyance,Total Task,TASK Released,Total Open TASK,Open(Less than / Equal to 10 Days),Open(More than 10 Days),Transferred to Abeyance,Total Task,TASK Released,Total Open TASK,Open(Less than / Equal to 10 Days),Open(More than 10 Days),Transferred to Abeyance,Total Task,TASK Released,Total Open TASK,Open(Less than / Equal to 10 Days),Open(More than 10 Days),Transferred to Abeyance,Total Task,TASK Released,Total Open TASK,Open(Less than / Equal to 10 Days),Open(More than 10 Days),Transferred to Abeyance",TRUE,0,reportWidth,reportWidth,&Strs)) goto EXIT;
	// if(dstat = ulyValueLines("Month ,Total Task,TASK Released,Transferred to Abeyance,Total Open TASK,Open(Less than / Equal to 10 Days),Open(More than 10 Days),% DML Task Completed,Total Task,TASK Released,Transferred to Abeyance,Total Open TASK,Open(Less than / Equal to 10 Days),Open(More than 10 Days),% DML Task Completed,Total Task,TASK Released,Transferred to Abeyance,Total Open TASK,Open(Less than / Equal to 10 Days),Open(More than 10 Days),% DML Task Completed,Total Task,TASK Released,Transferred to Abeyance,Total Open TASK,Open(Less than / Equal to 10 Days),Open(More than 10 Days),% DML Task Completed,Total Task,TASK Released,Transferred to Abeyance,Total Open TASK,Open(Less than / Equal to 10 Days),Open(More than 10 Days),% DML Task Completed",TRUE,0,reportWidth,reportWidth,&Strs)) goto EXIT;
	// fprintf(fp_rep, "CV Level Monthwise DML TASK Count Break up");fflush(fp_rep);
	// fprintf(fp_rep, "DML Number,Owner,TimestampIn,Pending status,Reviewer/Planner\n");fflush(fp_rep);
	 fprintf(fp_rep, "\nMonth,Plant Name,Task Name,Pending On,Timestamp IN,User Type, Status, DR Status ,Release Type, Days Elapsed ,Project Code");fflush(fp_rep);
	// LoginS = nlsStrAlloc(15);
	// PasswordS = nlsStrAlloc(15);

	// nlsStrCpy(LoginS, "jsr_su");
	// nlsStrCpy(PasswordS, "omfjsr06");

	DBToSet = low_set_create_str(2);

	/*enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2(argc, &argv, NULL));
	t5CheckDstat(clTestNetwork());
	t5CheckDstat(clInitialize2(FALSE));

	t5CheckDstat(clLogin2("jsr_su", "omfjsr06", &stat));

	if (low_set_add_str_unique(DBToSet, "supprod") < 0)
	{
		t5CheckDstat(uiShowText("t5OutOfMemError", NULL, UI_DIALOG_TEXT, dstat, WHERE));
		dstat = uiOutOfMemory();
		goto CLEANUP;
	}
	if (low_set_add_str_unique(DBToSet, "sujprod") < 0)
	{
		t5CheckDstat(uiShowText("t5OutOfMemError", NULL, UI_DIALOG_TEXT, dstat, WHERE));
		dstat = uiOutOfMemory();
		goto CLEANUP;
	}
	if (low_set_add_str_unique(DBToSet, "sulprod") < 0)
	{
		t5CheckDstat(uiShowText("t5OutOfMemError", NULL, UI_DIALOG_TEXT, dstat, WHERE));
		dstat = uiOutOfMemory();
		goto CLEANUP;
	}
	if (low_set_add_str_unique(DBToSet, "suhprod") < 0)
	{
		t5CheckDstat(uiShowText("t5OutOfMemError", NULL, UI_DIALOG_TEXT, dstat, WHERE));
		dstat = uiOutOfMemory();
		goto CLEANUP;
	}
	smSetSessionDbScope(DBToSet);

	if (stat != OKAY)
	{
		printf("\n Inside stat !OKEY");
		fflush(stdout);
		goto EXIT;
	}
	printf("\n Login successfull\n");fflush(stdout);
	
	int OpenYearlyPune  = 0;
	int OpenYearlyJsr   = 0;
	int OpenYearlyLko  = 0;
	int OpenYearlyUtk  = 0;
	int OpenYearlyDwd  = 0;
	int OpenYearlyTotal  = 0;
	
	string OpenYearlyPuneStr = NULL;
	string OpenYearlyJsrStr   =NULL; 
	string OpenYearlyLkoStr   = NULL;
	string OpenYearlyUtkStr  = NULL;
    string OpenYearlyDwdStr  = NULL;
    string OpenYearlyTotalStr  = NULL;
	string MailheaderStr		  = NULL; // added by Nilesh
	//string 				MonthHtml			= NULL;
	//MonthHtml							= nlsStrAlloc(20);
	SetOfStrings		MailBodySetTemp		= NULL;
	
	
	OpenYearlyPuneStr   = nlsStrAlloc(50);
	OpenYearlyJsrStr    =  nlsStrAlloc(50);
	OpenYearlyLkoStr    = nlsStrAlloc(50);
	OpenYearlyUtkStr    = nlsStrAlloc(50);
	OpenYearlyDwdStr   = nlsStrAlloc(50);
	OpenYearlyTotalStr   = nlsStrAlloc(50);
	MailheaderStr			= nlsStrAlloc(1000); // Added by Nilesh
	MailBodySetTemp							= low_set_create(1);
	//MailHeaderSetTemp						= low_set_create(1); // Added by Nilesh
	
	SetOfStrings	CummMonthlyAllPlants		=	 NULL;
					CummMonthlyAllPlants				= low_set_create(1);

	string TotalCountCumMthStr,ClosedCountCumMthStr,AbeyanceCumMthStr,OpenCountCumMthStr,BelowTenCumMthStr,AboveTenCumMthStr,BelowtenclosedCumMthStr,DmlTskCmpltdLTTenDaysCumMthStr,DmlTskCmpltdperCumMthStr,AbeyanceTrnsfPerCumMthStr,BlwTenClsdTrToAbycCumMthStr,AvgCountCummStr	=	NULL;
	
	TotalCountCumMthStr						=	nlsStrAlloc(100);
	ClosedCountCumMthStr					=	nlsStrAlloc(100);
	AbeyanceCumMthStr						=	nlsStrAlloc(100);
	OpenCountCumMthStr						=	nlsStrAlloc(100);
	BelowTenCumMthStr						=	nlsStrAlloc(100);
	AboveTenCumMthStr						=	nlsStrAlloc(100);
	BelowtenclosedCumMthStr					=	nlsStrAlloc(100);
	DmlTskCmpltdLTTenDaysCumMthStr			=	nlsStrAlloc(100);
	DmlTskCmpltdperCumMthStr				=	nlsStrAlloc(100);
	AbeyanceTrnsfPerCumMthStr				=	nlsStrAlloc(100);
	BlwTenClsdTrToAbycCumMthStr				=	nlsStrAlloc(100);
	AvgCountCummStr							=	nlsStrAlloc(100);
	

	int TskClsdAndAbeyenceLTTendaysCumMth		=	0;
	int TotalCountCumMthGlb							=	0; 


	if (setSize(DateSet) > 0)
	{
		string OpenYearlyString = NULL;
		OpenYearlyString = nlsStrAlloc(100);
		nlsStrCpy(OpenYearlyString,"");
		
		for (DateCount = 0; DateCount < setSize(DateSet) ; DateCount++)						// looping over dateset created - one month at a time
		{	
			int TotalCountCumMth		= 0;
			int ClosedCountCumMth		= 0;
			int AbeyanceCumMth			= 0;
			int OpenCountCumMth			= 0;
			int BelowTenCumMth			= 0;
			int AboveTenCumMth			= 0;
			int BelowtenclosedCumMth 	= 0;

			double DmlTskCmpltdLTTenDaysCumMth				=	0;
			double AbeyanceTrnsfPerCumMth					=	0;
			double BlwTenClsdTrToAbycCumMth					=	0;
			// double TskClsdAndAbeyenceLTTendaysCumMth		=	0;  // changed to global
			double TotalTskCntCumMthDeno					=	0;
			double TskClsdAndAbeyenceCumMth					=	0;
			double BlwTenClsdTrToAbycCumMthPer				=	0;
			double DmlTskCmpltdperCumMth					=	0;
			double AvgCountCumm								=	0;

			nlsStrCpy(FromDateDup,"");
			nlsStrCpy(ToDateDup,"");
			DateFromSet = setGet(DateSet, DateCount);
			if (!nlsIsStrNull(DateFromSet)) DateFromSetDup = nlsStrDup(DateFromSet);

			FromDateSet = strtok(DateFromSetDup, "~");
			nlsStrCat(FromDateDup, FromDateSet);
			nlsStrCat(FromDateDup, "-00:00:00:000");
			
			ToDateSet = strtok(NULL, "~");
			
			nlsStrCat(ToDateDup, ToDateSet);
			nlsStrCat(ToDateDup, "-23:59:59:999");
			
			FromDateForMonth = nlsStrDup(FromDateDup);

			string MonthName = NULL;
			MonthName = nlsStrAlloc(10);

			nlsStrCpy(MonthName,"");
			nlsStrCpy(MonthName,FromDateForMonth);
			strtok(MonthName, "-");
			MonthName = strtok(MonthName, "/");
			printf("\n MonthName : %s",MonthName);
			MonthName = strtok(NULL, "/");
			printf("\n MonthName : %s",MonthName);
			// MonthName = strtok(NULL, "/");
			// printf("\n MonthName : %s",MonthName);

			
			//FromYear = strtok(FromDateForMonth, "/");
			// FromMonth = strtok(FromDateForMonth, "/");

			nlsStrCpy(MonthPrint,"");
			nlsStrCpy(MonthPrint,getMonth(MonthName));

			printf("\n MonthPrint : %s",MonthPrint);
			
			
				
			ToDateDup2 = nlsStrDup(sysdateDup);
			printf("\n System date : %s",ToDateDup2);fflush(stdout);
			STy1 = strtok(ToDateDup2, "/");
			STm1 = strtok(NULL, "/");
			STd1 = strtok(NULL, "/");

			Td1 = atoi(STd1);
			Tm1 = atoi(STm1);
			Ty1 = atoi(STy1);

			printf("\n FromDateDup ============= : %s\n", FromDateDup);fflush(stdout);			//2023/04/01-00:00:00:000
			printf("\n ToDateDup :============= %s\n", ToDateDup);fflush(stdout);				//2023/04/30-23:59:59:999

			
			if (setSize(PlantSet) > 0)
			{
				for (Plntcount = 0; Plntcount < setSize(PlantSet); Plntcount++)
				{
					int OpenCount = 0;
					int ClosedCount = 0;
					int TotalCount = 0;
					int Abeyance = 0;
					int BelowTen = 0;
					int AboveTen = 0;

					int AvgAgeMth 									=	0;
					int	AvgCountMth									=	0;
					double AvgDaysPlant								=	0;
					
					// Variable defined by Nilesh
					
					int OpenCountLT10days   			= 0;
					int OpenCountGT10days   			= 0;
					int ClosedCountLT10days 			= 0;
					int ClosedCountGT10days 			= 0;
					int Belowtenclosed 					= 0;
					int BlwTenClsdTrToAbyc 				= 0;
					int DmlTskCmpltdLTTenDays			= 0;

					string BelowtenclosedStr			= NULL;
					string BlwTenClsdTrToAbycStr		= NULL;		
					string DmlTskCmpltdLTTenDaysstr		= NULL;		
					string AbeyanceTrnsfPerStr			= NULL;		
					
					// End of Variable defined by Nilesh
					string OpenCountStr 		= NULL;
					string ClosedCountStr		= NULL;
					string TotalCountStr 		= NULL; 
					string AbeyanceStr 			= NULL;
					string BelowTenStr 			= NULL;
					string AboveTenStr			= NULL;
					string DmlTskCmpltdperstr	= NULL;
					string AvgDaysPlantStr		= NULL;
					
					Plant = setGetStr(PlantSet, Plntcount);
					if (!nlsIsStrNull(Plant)) PlantDup = nlsStrDup(Plant);
					printf("\n Plant Name : %s", PlantDup);fflush(stdout);

					SqlPtr sqlPtr = NULL;
					SetOfObjects Users = NULL;

					SetOfObjects TaskList = NULL;
					SetOfObjects controlobjs = NULL;
					string Abyuserfound = NULL;
					string AbyuserfoundDup = NULL;

					printf("\n Before query ");

					if (dstat = oiSqlCreateSelect(&sqlPtr)) goto CLEANUP;
					if (dstat = oiSqlWhereEQ(sqlPtr, t5UsrLocationAttr, PlantDup)) goto CLEANUP;
					if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
					//if (dstat = oiSqlWhereEQ(sqlPtr, t5UsrAgencyAttr, "STDS")) goto CLEANUP;
					if (dstat = oiSqlWhereEQ(sqlPtr, DeptAttr, "STDS")) goto CLEANUP;
					if (dstat = QueryDbObject("Usr", sqlPtr, 0, TRUE, SC_SCOPE_WHERE_NECESSARY, &Users, mfail)) goto CLEANUP;
					oiSqlPrint(sqlPtr);
					oiSqlDispose(sqlPtr);
					printf("\n Total %d STDS Users found for Plant : %s \n",setSize(Users),PlantDup);fflush(stdout);

					if (dstat = oiSqlCreateSelect(&sqlPtr)) goto EXIT;
					if (dstat = oiSqlWhereEQ(sqlPtr, "t5Syscd", "AbyPlntID")) goto EXIT;
					if (dstat = oiSqlWhereAND(sqlPtr)) goto EXIT;
					if (dstat = oiSqlWhereEQ(sqlPtr, "t5SubSyscd", PlantDup)) goto EXIT;
					if (dstat = QueryDbObject(t5CntrolClass, sqlPtr, 0, TRUE, SC_SCOPE_WHERE_NECESSARY, &controlobjs, mfail)) goto EXIT;
					if (*mfail) goto CLEANUP;
					printf("\n No of Control Object found for Abbyence user is : %d  for plant is : %s", setSize(controlobjs),PlantDup);fflush(stdout);
					oiSqlPrint(sqlPtr);
					oiSqlDispose(sqlPtr);
					
					if (setSize(controlobjs) > 0)
					{
						ObjectPtr AbyUser = NULL;

						AbyUser = setGet(controlobjs, 0);

						if (dstat = objGetAttribute(AbyUser, "t5Userinfo1", &Abyuserfound)) goto EXIT;
						if (!nlsIsStrNull(Abyuserfound)) AbyuserfoundDup = nlsStrDup(Abyuserfound);
						printf("\n Abyuser User for plant : %s  is : %s ", AbyuserfoundDup,PlantDup);fflush(stdout);
					} 

					int users = 0;
					for (users = 0; users < setSize(Users); users++)						
					{
						ObjectPtr UsersPtr = NULL;
						string UserNameDup = NULL;
						string UserName = NULL;
						UsersPtr = setGet(Users, users);

						/***********************Adding one user to task list to make it greater than 0 for below usage***************/
						if (users == 0)
						{
							printf("\n Task list added for first time \n");
							fflush(stdout);
							if (dstat = ulyCopyObjectToSet(UsersPtr, &TaskList)) goto CLEANUP;
						}
						
						
						if (dstat = objGetAttribute(UsersPtr, "Participant", &UserName)) goto EXIT;
						if (!nlsIsStrNull(UserName)) UserNameDup = nlsStrDup(UserName);
						printf("\n Users = %s \n", UserNameDup);
						fflush(stdout);

						if (nlsStrCmp(UserNameDup, AbyuserfoundDup) == 0 || nlsStrStr(UserNameDup,"HODSTD") || nlsStrCmp(UserNameDup,"cks98324") == 0 || nlsStrCmp(UserNameDup,"cks98324") == 0)
						{
							printf("\n User : %s Abyuserfound : %s", UserNameDup, AbyuserfoundDup);fflush(stdout);
							fprintf(fp_log, "\n User : %s Abyuserfound : %s \n", UserNameDup, AbyuserfoundDup);fflush(fp_log);
							continue;
						}

						SetOfObjects SigObjects = NULL;

						if (dstat = oiSqlCreateSelect(&sqlPtr)) goto CLEANUP;
						if (dstat = oiSqlWhereGE(sqlPtr, TimestampInAttr, FromDateDup)) goto CLEANUP;
						if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
						if (dstat = oiSqlWhereLE(sqlPtr, TimestampInAttr, ToDateDup)) goto CLEANUP;
						if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
						if (dstat = oiSqlWhereEQ(sqlPtr, CurrentUserAttr, UserNameDup)) goto CLEANUP;
						if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
						if (dstat = oiSqlWhereEQ(sqlPtr, WorkDescAttr, "Create EPA")) goto CLEANUP;
						if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
						if (dstat = oiSqlWhereEQ(sqlPtr, Class1Attr, "CmTaskIt")) goto CLEANUP;
						if (dstat = oiSqlAscOrder(sqlPtr, TimestampInAttr));
						oiSqlPrint(sqlPtr);
						if (dstat = QueryDbObject("AsgSig", sqlPtr, 0, TRUE, SC_SCOPE_WHERE_NECESSARY, &SigObjects, mfail)) goto CLEANUP;
						oiSqlDispose(sqlPtr);

						printf("\n Signoff Objects = %d \n", setSize(SigObjects));fflush(stdout);

						if (setSize(SigObjects) > 0)
						{
							for (Sigcount = 0; Sigcount < setSize(SigObjects); Sigcount++)
							{
								string Leftclass 				= NULL;
								string LeftclassDup 			= NULL;
								string LeftMem 					= NULL;
								string LeftMemDup 				= NULL;
								string DMLDRStatus				= NULL;
								string DMLDRStatusDup			= NULL;
								string DMLECNType				= NULL;
								string DMLECNTypeDup			= NULL;
								string ProjectCode				= NULL;
								string ProjectCodeDup			= NULL;
								SetOfObjects TaskObjs 			= NULL;
								ObjectPtr SigObjectsPtr 		= NULL;
								SetOfObjects DMLSet				= NULL;	

								SigObjectsPtr = setGet(SigObjects, Sigcount);

								if (dstat = objGetAttribute(SigObjectsPtr, "Left", &LeftMem)) goto EXIT;
								if (!nlsIsStrNull(LeftMem)) LeftMemDup = nlsStrDup(LeftMem);
								fflush(stdout);

								if (dstat = objGetAttribute(SigObjectsPtr, "Class1", &Leftclass)) goto EXIT;
								if (!nlsIsStrNull(Leftclass)) LeftclassDup = nlsStrDup(Leftclass);
								fflush(stdout);

								if (dstat = oiSqlCreateSelect(&sqlPtr)) goto CLEANUP;
								if (dstat = oiSqlWhereEQ(sqlPtr, "OBID", LeftMemDup)) goto CLEANUP;
								if (dstat = QueryDbObject(LeftclassDup, sqlPtr, 0, TRUE, SC_SCOPE_WHERE_NECESSARY, &TaskObjs, mfail)) goto CLEANUP;
								oiSqlDispose(sqlPtr);

								printf("\n Task size = %d \n", setSize(TaskObjs));
								fflush(stdout);

								if(setSize(TaskObjs) > 0)
								{
									string currentUser = NULL;
									string currentUserDup = "-";
									string TaskIwkDup = NULL;
									string TaskIwk = NULL;
									string task_obid = NULL;
									string TaskPlant = NULL;
									string task_obidDup = NULL;
									ObjectPtr TaskObjsInd = NULL;
									TaskObjsInd = setGet(TaskObjs, 0);

									string Design = NULL;
									string Taskname = NULL;
									string TaskIwkDup2 = NULL;
									string PlantSub = NULL;

									if (dstat = ExpandObject4("WbsRvRv", TaskObjsInd, "CMPrdPlanRollsUpInTo", &DMLSet, mfail));

									printf("\n DML size = %d \n", setSize(DMLSet));
									fflush(stdout);
									if(setSize(DMLSet) > 0)
									{
										if (dstat = objGetAttribute(setGet(DMLSet, 0), "t5PartStatus", &DMLDRStatus)) goto EXIT;
										if (!nlsIsStrNull(DMLDRStatus)) DMLDRStatusDup = nlsStrDup(DMLDRStatus);
										fflush(stdout);

										if (dstat = objGetAttribute(setGet(DMLSet, 0), "t5EcnType", &DMLECNType)) goto EXIT;
										if (!nlsIsStrNull(DMLECNType)) DMLECNTypeDup = nlsStrDup(DMLECNType);
										fflush(stdout);

										if (dstat = objGetAttribute(setGet(DMLSet, 0), "ProjectName", &ProjectCode)) goto EXIT;
										if (!nlsIsStrNull(ProjectCode)) ProjectCodeDup = nlsStrDup(ProjectCode);
										fflush(stdout);
									}
									else{
										nlsStrCpy(DMLDRStatusDup,"");
										nlsStrCpy(DMLDRStatusDup,"DML NOT FOUND");
									}
									
									// if(nlsStrStr("DR4,DR5,AR4,AR5",DMLDRStatusDup) == NULL) 
									// {
									// 	printf("\n DR STATUS LESS THAN REQUIRED DR/AR : %s",DMLDRStatusDup);fflush(stdout);
									// 	continue;
									// }
									
									if (dstat = objGetAttribute(TaskObjsInd, "WbsID", &TaskIwk)) goto EXIT;
									if (!nlsIsStrNull(TaskIwk)) TaskIwkDup = nlsStrDup(TaskIwk);
									if (!nlsIsStrNull(TaskIwk)) TaskIwkDup2 = nlsStrDup(TaskIwk);
									printf("\n Task Name : %s\n",TaskIwkDup);fflush(stdout);
									Taskname = strtok(TaskIwkDup, "_");
									Design = strtok(NULL, "_");
									TaskPlant = strtok(NULL, "_");
									printf("\n Task Plant : %s\n",TaskPlant);fflush(stdout);
									printf("\n Task Name after dup: %s\n",TaskIwkDup);fflush(stdout);
									printf("\n PlantDup: %s\n",PlantDup);fflush(stdout);

									if (nlsStrCmp(PlantDup, "JSR") == 0)
									{
										PlantSub = "APLJ";
									}
									//else if (nlsStrCmp(Plant, "PUNE") == 0)
									else if ((nlsStrCmp(PlantDup, "PUNE") == 0) || (nlsStrCmp(PlantDup, "PCVBU") == 0))
									{
										PlantSub = "APL";
									}
									else if (nlsStrCmp(PlantDup, "PNR") == 0)
									{
										PlantSub = "APLU";
									}
									else if (nlsStrCmp(PlantDup, "DWD") == 0)
									{
										PlantSub = "APLD";
									}
									else if (nlsStrCmp(PlantDup, "LKO") == 0)
									{
										PlantSub = "APLL";
									}

									if (nlsStrCmp(TaskPlant, PlantSub) == 0)		//if (nlsStrCmp(TaskIwkDup, TaskPlant) != 0)
									{
										int    flag 								= 0;
										int    NoPartPoAssign 						= 0;
										string TaskLcs 								= NULL;
										string TAskworkDescDup 						= NULL;
										string TaskLcsDup 							= NULL;
										string TaskTimestampInDup 					= NULL;
										string TaskTimestampInDup3 					= NULL;
										string TaskIwkDup1 							= NULL;
										string yy_lastModificationDate 				= NULL;
										string mm_lastModificationDate 				= NULL;
										string dd_lastModificationDate 				= NULL;
										string yy_signOffDate 		   				= NULL;
										string mm_signOffDate 		   				= NULL;
										string dd_signOffDate 		   				= NULL;
										string SignOffDate			   				= NULL;
										string SignOffDateDup		   				= NULL;
										//string TimestampOut			   			= NULL;
										string TimestampOutDup		   				= NULL;
										SetOfStrings SigstateValue1 				= NULL;
										string yy_FromDateDup2 						= NULL;
										string mm_FromDateDup2 						= NULL;
										string dd_FromDateDup2 						= NULL;
										string taskassignstatusDUP 					= NULL;

										yy_lastModificationDate = nlsStrAlloc(10);
										mm_lastModificationDate = nlsStrAlloc(10);
										dd_lastModificationDate = nlsStrAlloc(10);

										SigstateValue1 = setCreate(2);
										low_set_add_str_unique(SigstateValue1, "LcmIntRdy");
										low_set_add_str_unique(SigstateValue1, "LcmIntReq");
										low_set_add_str_unique(SigstateValue1, "LcmIntHis");
										
										

										string TaskTimestampInDupR1 = NULL;
										string TaskTimestampInDupR2 = NULL;
										
										string FromDateDup2 = NULL;
										FromDateDup2 = nlsStrDup(FromDateDup);

										TaskIwkDup1 = nlsStrDup(TaskIwkDup2);

										/****************************************Getting Current pending user**************************************/

										if (dstat = objGetAttribute(TaskObjsInd, "OBID", &task_obid));
										if (!nlsIsStrNull(task_obid)) task_obidDup = nlsStrDup(task_obid);

										SetOfObjects AsigTaskSet = NULL;
										SetOfObjects RAsigTaskSet = NULL;
										//SetOfObjects HAsigTaskSet = NULL; //History 

										if (dstat = oiSqlCreateSelect(&sqlPtr)) goto CLEANUP;
										//if (dstat = oiSqlWhereBegParen(sqlPtr)) goto CLEANUP;
										if (dstat = oiSqlWhereEQ(sqlPtr, LeftAttr, task_obidDup)) goto CLEANUP;
										if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
										if (dstat = oiSqlWhereEQ(sqlPtr, WorkDescAttr, "Create EPA")) goto CLEANUP;
										if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
										if (dstat = oiSqlWhereIN(sqlPtr, SigStateAttr, SigstateValue1, mfail)) goto CLEANUP;
										if (dstat = oiSqlAscOrder(sqlPtr, TimestampInAttr));
										//if (dstat = oiSqlWhereEndParen(sqlPtr)) goto CLEANUP;
										oiSqlPrint(sqlPtr);
										if (dstat = QueryDbObject(AsgSigClass, sqlPtr, 0, TRUE, SC_SCOPE_OF_SESSION, &AsigTaskSet, mfail)) goto EXIT;
										if (sqlPtr) oiSqlDispose(sqlPtr);
										printf("\n AsigTaskSet = %d \n", setSize(AsigTaskSet));fflush(stdout);
										
										int pendingflag = 0;
										//int Analystpendingflag = 0;
										//int ReviewerPendingFlag = 0;
										if (setSize(AsigTaskSet) > 0)
										{
											ObjectPtr taskAsig = NULL;
											string TAskworkDesc = NULL;
											string TaskTimestampIn = NULL;
											
											string PendingstateDup = NULL;
											string Pendingstate = NULL;
											
											TaskTimestampIn = nlsStrAlloc(20);
											
											int w = 0;
											for (w = 0; w < setSize(AsigTaskSet); w++)
											{
												
												taskAsig = setGet(AsigTaskSet, w);
												//objDump(taskAsig);
												if (dstat = objGetAttribute(taskAsig, "SigState", &Pendingstate)) goto EXIT;
												if (!nlsIsStrNull(Pendingstate)) PendingstateDup = nlsStrDup(Pendingstate);

												if (dstat = objGetAttribute(taskAsig, "WorkDesc", &TAskworkDesc)) goto EXIT;
												if (!nlsIsStrNull(TAskworkDesc)) TAskworkDescDup = nlsStrDup(TAskworkDesc);
												
												if (flag == 0)
												{
													if (nlsStrCmp(TAskworkDescDup, "Create EPA") == 0)
													{
														flag = 1;
														if (dstat = objGetAttribute(taskAsig, "TimestampIn", &TaskTimestampIn)) goto EXIT;
														if (!nlsIsStrNull(TaskTimestampIn)) TaskTimestampInDup = nlsStrDup(TaskTimestampIn);
														TaskTimestampInDupR1 = nlsStrDup(TaskTimestampIn);
														TaskTimestampInDup3 = strtok(TaskTimestampInDup, "-");
														printf("\n TaskTimestampInDup = %s \n", TaskTimestampInDup);			// 2023/04/18	
														fflush(stdout);
														printf("\n FromDateDup2 = %s \n", FromDateDup2);						// 2023/04/01-00:00:00:000	month start date from dateset
														fflush(stdout);

														yy_lastModificationDate = strtok(TaskTimestampInDup3, "/");		// 2023
														mm_lastModificationDate = strtok(NULL, "/");					// 04
														dd_lastModificationDate = strtok(NULL, "/");					// 18

														yy_FromDateDup2 = strtok(FromDateDup2, "/");			// 2023
														mm_FromDateDup2 = strtok(NULL, "/");					// 04
														dd_FromDateDup2 = strtok(NULL, "/");					// 01

														printf("\nTIN = %s,%s,%s_______________________________FIN = %s,%s,%s \n", yy_lastModificationDate, mm_lastModificationDate, dd_lastModificationDate, yy_FromDateDup2, mm_FromDateDup2, dd_FromDateDup2);

														if (atoi(yy_FromDateDup2) > atoi(yy_lastModificationDate))
														{
															flag = 2;
															printf("\n if(atoi(yy_FromDateDup2)>atoi(yy_lastModificationDate)) %s______%s\n", yy_FromDateDup2, yy_lastModificationDate);
															fflush(stdout);
														
															goto NextIteration;
														}
														else if (atoi(yy_FromDateDup2) == atoi(yy_lastModificationDate))
														{
															if (atoi(mm_FromDateDup2) == atoi(mm_lastModificationDate))
															{
																if (atoi(dd_FromDateDup2) > atoi(dd_lastModificationDate))
																{
																	flag = 2;
																	printf("\n if(atoi(dd_FromDateDup2)>atoi(dd_lastModificationDate))  %s______%s\n", dd_FromDateDup2, dd_lastModificationDate);
																	fflush(stdout);
														
																	goto NextIteration;
																}
															}
															else if (atoi(mm_FromDateDup2) > atoi(mm_lastModificationDate))
															{
																flag = 2;
																printf("\n else(atoi(mm_FromDateDup2)>atoi(mm_lastModificationDate))   %s______%s\n", mm_FromDateDup2, mm_lastModificationDate);
																fflush(stdout);
															
																goto NextIteration;
															}
														}
													}
												}
												if (nlsStrCmp(PendingstateDup, "LcmIntRdy") == 0 || nlsStrCmp(PendingstateDup, "LcmIntReq") == 0)
												{
													pendingflag = 1;
													t5CheckDstat(objGetAttribute(taskAsig, "CurrentUser", &currentUser));
													if (!nlsIsStrNull(currentUser)) currentUserDup = nlsStrDup(currentUser);
													//fprintf(fp_rep, "\n %s,%s,%s,%s,%s,%s - Analyst",FromDateDup,PlantDup,TaskIwkDup2,currentUserDup,TaskTimestampInDupR1,PendingstateDup);fflush(fp_rep);
													fprintf(fp_log, "\n %s,%s,%s,%s,Analyst",TaskIwkDup2,currentUserDup,TaskTimestampInDupR1,PendingstateDup);fflush(fp_log);
													//printf("\n ******Analystt******currentUserDup =%s \n", currentUserDup);
													fflush(stdout);
												}
											}
										}
										if (pendingflag == 0)
										{
											if (dstat = oiSqlCreateSelect(&sqlPtr)) goto CLEANUP;
											if (dstat = oiSqlWhereEQ(sqlPtr, LeftAttr, task_obidDup)) goto CLEANUP;
											if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
											if (dstat = oiSqlWhereEQ(sqlPtr, WorkDescAttr, "Review the Changes")) goto CLEANUP;
											if (dstat = oiSqlWhereAND(sqlPtr)) goto CLEANUP;
											if (dstat = oiSqlWhereIN(sqlPtr, SigStateAttr, SigstateValue1, mfail)) goto CLEANUP;
											if (dstat = oiSqlDescOrder(sqlPtr, TimestampInAttr));
											oiSqlPrint(sqlPtr);
											if (dstat = QueryDbObject(RevSigClass, sqlPtr, 0, TRUE, SC_SCOPE_OF_SESSION, &RAsigTaskSet, mfail)) goto EXIT;
											if (sqlPtr) oiSqlDispose(sqlPtr);
											
											printf("\n Total Review object found in Review class is : %d",setSize(RAsigTaskSet));fflush(stdout);

											if (RAsigTaskSet > 0)
											{
												ObjectPtr 	RtaskAsig 			= NULL;
												string 		taskassignstatus 	= NULL;
												taskassignstatus  				= nlsStrAlloc(20);
												string 		Action			 	= NULL;
												string 		ActionDUP		 	= NULL;
												Action			  				= nlsStrAlloc(20);
												//int 		RAsigTaskSetItr 	= 0;
												RtaskAsig = setGet(RAsigTaskSet, 0);
												if (dstat = objGetAttribute(RtaskAsig, "SigState", &taskassignstatus)) goto EXIT;
												if (!nlsIsStrNull(taskassignstatus)) taskassignstatusDUP = nlsStrDup(taskassignstatus);

												if (dstat = objGetAttribute(RtaskAsig, "IntStamp", &Action)) goto EXIT;
												if (!nlsIsStrNull(Action)) ActionDUP = nlsStrDup(Action);
													
												if(nlsStrCmp(taskassignstatusDUP,"LcmIntReq") == 0) 
												{
													nlsStrCpy(taskassignstatusDUP,"UnClaimed");
												}
												if(nlsStrCmp(taskassignstatusDUP,"LcmIntRdy") == 0)
												{
													nlsStrCpy(taskassignstatusDUP,"Claimed");
												}
												if(nlsStrCmp(taskassignstatusDUP,"LcmIntHis") == 0)
												{
													nlsStrCpy(taskassignstatusDUP,"History");
												}
												t5CheckDstat(objGetAttribute(RtaskAsig, "CurrentUser", &currentUser));
												if (!nlsIsStrNull(currentUser)) currentUserDup = nlsStrDup(currentUser);
												
												if (dstat = objGetAttribute(RtaskAsig, "TimestampOut", &SignOffDate)) goto EXIT;
												if (!nlsIsStrNull(SignOffDate)) SignOffDateDup = nlsStrDup(SignOffDate);
												if (!nlsIsStrNull(SignOffDate)) TimestampOutDup = nlsStrDup(SignOffDate);
												
												
												if(nlsIsStrNull(SignOffDate))
												{
													if (nlsStrCmp(currentUserDup, AbyuserfoundDup) == 0)
													{
														printf("\n ,%s,%s,%s,%s,%s - Transfered to Abeyance",PlantDup,TaskIwkDup2,currentUserDup,TaskTimestampInDupR1,taskassignstatusDUP);fflush(stdout);
													}
													else
													{
														printf("\n ,%s,%s,%s,%s,%s - Pending with Reviewer",PlantDup,TaskIwkDup2,currentUserDup,TaskTimestampInDupR1,taskassignstatusDUP);fflush(stdout);
													}		
													
												}
												else
												{
													TaskTimestampInDupR2 = strtok(SignOffDateDup, "-");
													yy_signOffDate = strtok(TaskTimestampInDupR2, "/");		// 2023
													mm_signOffDate = strtok(NULL, "/");					// 04
													dd_signOffDate = strtok(NULL, "/");					// 18

													printf("\n Task : %s is Assigned to Analyst on : %s ",TaskIwkDup2,TaskTimestampInDupR1);fflush(stdout);
													printf("\n Task : %s is completed from Reviewer on : %s ",TaskIwkDup2,TimestampOutDup);fflush(stdout);
												}
											}
											else
											{
												NoPartPoAssign = 1;
												fprintf(fp_log, "\n ,%s,%s,%s,,NO PO Part Assignment",PlantDup,TaskIwkDup2,currentUserDup);fflush(fp_log);
											}
										}
										/****************************************Getting Current pending user**************************************/

										if (dstat = objGetAttribute(TaskObjsInd, "LifeCycleState", &TaskLcs));
										if (!nlsIsStrNull(TaskLcs)) TaskLcsDup = nlsStrDup(TaskLcs);
										printf("\n Inside Getting Current pending user");fflush(stdout);
										d1 = atoi(dd_lastModificationDate);
										m1 = atoi(mm_lastModificationDate);
										y1 = atoi(yy_lastModificationDate);

										printf("\n D1 : %d",d1);fflush(stdout);
										printf("\n M! : %d",m1);fflush(stdout);
										printf("\n Y1 : %d",y1);fflush(stdout);
										printf("\n Test line 1 : ****************************************");fflush(stdout);
										struct Date dt1 = { d1, m1, y1};
										struct Date dt2 = { Td1, Tm1, Ty1};
													
										printf("\n Test line 2 : ****************************************");fflush(stdout);

										num = getDifference(dt1, dt2);
										
										
										printf("\n************Difference***********=%d", num);

										if (nlsStrCmp(TaskLcsDup, "LcsSTDWrkg") == 0 && NoPartPoAssign == 0)
										{
											printf("\n *************************Inside LcsWorking");
											if (setSize(TaskList) > 0)
											{
												printf("\n *************************Inside if tasklist>0");
												for (s = 0; s < setSize(TaskList); s++)
												{
													t5CheckDstat(ulyFindObjectInSet(TaskObjsInd, TaskList, OBIDAttr, 0, &found));
													if (found < 0)
													{
														printf("\n *************************Inside if task obid not found");
														t5CheckDstat(ulyCopyObjectToSet(TaskObjsInd, &TaskList));

														printf("\n Current User : %s",currentUserDup);fflush(stdout);
														printf("\n Abeyance User : %s",AbyuserfoundDup);fflush(stdout);

														if (nlsStrCmp(currentUserDup, AbyuserfoundDup) == 0)
														{
															Abeyance++;
															printf("\n Transfer to abeyance : %d",Abeyance);fflush(stdout);
															if(num <= 11 )
															{
																fprintf(fp_rep, "\n %s,%s,%s,%s - Abeyance user,Transfered to abeyance Within 10 days,,Abeyance Assignment,%s,%s,%d,%s",MonthPrint,PlantDup,TaskIwkDup1,currentUserDup,DMLDRStatusDup,DMLECNTypeDup,num,ProjectCodeDup);fflush(fp_rep);
															}
															if(num > 11 )
															{
																fprintf(fp_rep, "\n %s,%s,%s,%s - Abeyance user,Transfered to abeyance After 10 days,,Abeyance Assignment,%s,%s,%d,%s",MonthPrint,PlantDup,TaskIwkDup1,currentUserDup,DMLDRStatusDup,DMLECNTypeDup,num,ProjectCodeDup);fflush(fp_rep);
															}
															
															printf("\n Open - %s pending on %s - Abeyance user",TaskIwkDup1,currentUserDup);fflush(stdout);
														}
														else if (num <= 11)
														{
															BelowTen++;
															// OpenCount++;
															if(pendingflag == 1)
															{
																fprintf(fp_rep,"\n %s,%s,%s,%s,%s, Analyst, Open < 10 days,%s,%s,%d,%s",MonthPrint,PlantDup,TaskIwkDup2,currentUserDup,TaskTimestampInDupR1,DMLDRStatusDup,DMLECNTypeDup,num,ProjectCodeDup);fflush(fp_rep);
															}
															if(pendingflag == 0)
															{
																fprintf(fp_rep,"\n %s,%s,%s,%s,%s,Reviewer, Open < 10 days,%s,%s,%d,%s",MonthPrint,PlantDup,TaskIwkDup2,currentUserDup,TaskTimestampInDupR1,DMLDRStatusDup,DMLECNTypeDup,num,ProjectCodeDup);fflush(fp_rep);
															}
															//printf("\n DML %s is pending on %s (Current User) for less than 10 days");fflush(stdout);
														}
														else
														{
															AboveTen++;
															OpenCount++;
															if(pendingflag == 1)
															{
																fprintf(fp_rep,"\n %s,%s,%s,%s,%s,Analyst, Open > 10 days,%s,%s,%d,%s",MonthPrint,PlantDup,TaskIwkDup2,currentUserDup,TaskTimestampInDupR1,DMLDRStatusDup,DMLECNTypeDup,num,ProjectCodeDup);fflush(fp_rep);
															}
															if(pendingflag == 0)
															{
																fprintf(fp_rep,"\n %s,%s,%s,%s,%s,Reviewer, open > 10 days,%s,%s,%d,%s",MonthPrint,PlantDup,TaskIwkDup2,currentUserDup,TaskTimestampInDupR1,DMLDRStatusDup,DMLECNTypeDup,num,ProjectCodeDup);fflush(fp_rep);
															}
															// Modified By Nilesh
															printf("\n DML %s is pending on %s (Current User) for more than 10 days",TaskIwkDup1,currentUserDup);fflush(stdout);
														}
													}
												}
											}
										}
										if (nlsStrCmp(TaskLcsDup, "LcsSTDRlzd") == 0 && RAsigTaskSet > 0)
										{
											printf("\n *************************Inside lcsReleased");
											if (setSize(TaskList) > 0)
											{
												printf("\n *************************Inside if tasklist>0  Released");
												for (s = 0; s < setSize(TaskList); s++)
												{
													t5CheckDstat(ulyFindObjectInSet(TaskObjsInd, TaskList, OBIDAttr, 0, &found));
													if (found < 0)
													{
														printf("\n *************************Inside if task obid not found Released");
														t5CheckDstat(ulyCopyObjectToSet(TaskObjsInd, &TaskList));
														d3 = atoi(dd_signOffDate);
														m3 = atoi(mm_signOffDate);
														y3 = atoi(yy_signOffDate);
														struct Date dt3 = { d3, m3, y3};
														HisNum = getDifference(dt1,dt3);
														AvgAge = AvgAge + HisNum;
														AvgAgeMth = AvgAgeMth + HisNum;
														AvgCount++;
														AvgCountMth++;
														printf("\n Curtrent User , Task LcsSTDRlz : %s",currentUserDup); fflush(stdout);
														if (nlsStrCmp(currentUserDup, AbyuserfoundDup) == 0)
														{
															BlwTenClsdTrToAbyc++;
															//printf("\n DML %s is pending on %s (Current User) for more than 10 days");fflush(stdout);
														}
														if(HisNum <= 11)
														{
															printf("\n DML %s is closed before 10 days",TaskIwkDup1);fflush(stdout);
															Belowtenclosed++;
															ClosedCount++;
															fprintf(fp_rep,"\n %s,%s,%s,%s,%s,Reviewer, closed < 10 days,%s,%s,%d,%s",MonthPrint,PlantDup,TaskIwkDup2,currentUserDup,TaskTimestampInDupR1,DMLDRStatusDup,DMLECNTypeDup,HisNum,ProjectCodeDup);fflush(fp_rep);
														}
														else
														{
															printf("\n DML %s is closed after 10 days",TaskIwkDup1);fflush(stdout);
															ClosedCount++;
															fprintf(fp_rep,"\n %s,%s,%s,%s,%s,Reviewer, closed > 10 days,%s,%s,%d,%s",MonthPrint,PlantDup,TaskIwkDup2,currentUserDup,TaskTimestampInDupR1,DMLDRStatusDup,DMLECNTypeDup,HisNum,ProjectCodeDup);fflush(fp_rep);
														}
															
													}
												}
											}
										}
										NextIteration:
										if (flag == 2)
										{
											printf("\n Task : %s Work Desc : %s ", TaskIwkDup1, TAskworkDescDup);
											fflush(stdout);
										}
									}
								}
							}
						}
						else
						{
							printf("\nNo Signoff History\n");
							fflush(stdout);
						}
					}
					printf("\n [ Plant : %s ] [ Date range : %s - %s ] Task completed within 10 days : %d and tansfered to abeyance in 10 days : %d.",PlantDup,FromDateDup,ToDateDup,Belowtenclosed,BlwTenClsdTrToAbyc);fflush(stdout);

					//Freeing all strings
					if(!nlsIsStrNull(OpenCountStr))
					{
						nlsStrFree(OpenCountStr);
						OpenCountStr=NULL;
					}
					if(!nlsIsStrNull(ClosedCountStr))
					{
						nlsStrFree(ClosedCountStr);
						ClosedCountStr=NULL;
					}
					if(!nlsIsStrNull(TotalCountStr))
					{
						nlsStrFree(TotalCountStr);
						TotalCountStr=NULL;
					}
					if(!nlsIsStrNull(BelowTenStr))
					{
						nlsStrFree(BelowTenStr);
						BelowTenStr=NULL;
					}
					if(!nlsIsStrNull(AboveTenStr))
					{
						nlsStrFree(AboveTenStr);
						AboveTenStr=NULL;
					}
					if(!nlsIsStrNull(AbeyanceStr))
					{
						nlsStrFree(AbeyanceStr);
						AbeyanceStr=NULL;
					}
					if(!nlsIsStrNull(DmlTskCmpltdperstr))
					{
						nlsStrFree(DmlTskCmpltdperstr);
						DmlTskCmpltdperstr=NULL;
					}
					if(!nlsIsStrNull(DmlTskCmpltdLTTenDaysstr))
					{
						nlsStrFree(DmlTskCmpltdLTTenDaysstr);
						DmlTskCmpltdLTTenDaysstr=NULL;
					}
					if(!nlsIsStrNull(BelowtenclosedStr))
					{
						nlsStrFree(BelowtenclosedStr);
						BelowtenclosedStr=NULL;
					}
					if(!nlsIsStrNull(BlwTenClsdTrToAbycStr))
					{
						nlsStrFree(BlwTenClsdTrToAbycStr);
						BlwTenClsdTrToAbycStr=NULL;
					}
					if(!nlsIsStrNull(AbeyanceTrnsfPerStr))
					{
						nlsStrFree(AbeyanceTrnsfPerStr);
						AbeyanceTrnsfPerStr=NULL;
					}
					if(!nlsIsStrNull(AvgDaysPlantStr))
					{
						nlsStrFree(AvgDaysPlantStr);
						AvgDaysPlantStr=NULL;
					}
					//Freeing all strings end
					OpenCountStr 						=  	nlsStrAlloc(50);
					ClosedCountStr						=	nlsStrAlloc(50);
					TotalCountStr 						= 	nlsStrAlloc(50);
					AbeyanceStr 						=  	nlsStrAlloc(50);
					BelowTenStr 						=  	nlsStrAlloc(50);
					AboveTenStr 						=  	nlsStrAlloc(50);
					DmlTskCmpltdperstr 					=  	nlsStrAlloc(50);
					DmlTskCmpltdLTTenDaysstr			=  	nlsStrAlloc(50);
					BelowtenclosedStr 					=  	nlsStrAlloc(50);
					BlwTenClsdTrToAbycStr 				=  	nlsStrAlloc(50);
					AbeyanceTrnsfPerStr 				=  	nlsStrAlloc(50);
					AvgDaysPlantStr 					=  	nlsStrAlloc(50);
					

					/* if (nlsStrStr(PlantDup,"PCVBU") || nlsStrStr(PlantDup,"PUNE"))			// if (Plntcount == 0  && nlsStrStr(PlantDup,"PCVBU"))
					{ */
						string 	FullString 						= NULL;
						double	DMLTskCmpltd 					= 0;
						double	DMLTskCmpltTend 				= 0;
						int	TskClsdAndAbeyence 					= 0; 
						double	TskClsdAndAbeyenceLTTendays 	= 0;
						double BlwTenClsdTrToAbycPerCalc 		= 0;
						int TotalTskCntDeno 					= 0;						
						TotalCount = ClosedCount + OpenCount + Abeyance;
						double AbeyanceTrnsfPer					= 0;		// % (Task transfer to abeyance/ Total Task )

						

						AbeyanceTrnsfPer = ((double)Abeyance / (double) TotalCount) * 100;	// % (Task transfer to abeyance/ Total Task )
						// OpenYearlyPune = OpenYearlyPune + OpenCount;
						
						printf("\n ClosedCount is = %d",ClosedCount);
						printf("\n Abeyance is = %d",Abeyance);
						printf("\n TotalCount is = %d",TotalCount);
						
						TskClsdAndAbeyence = ClosedCount+Abeyance;
						TskClsdAndAbeyenceLTTendays = Belowtenclosed+Abeyance;
						TotalTskCntDeno = TotalCount;
						printf("\n Nemuretor Task Completed and Trnsfr to Abeyence is  = %d \n",TskClsdAndAbeyence);
						printf("\n Denomenator Toatl Task count is  = %d \n",TotalTskCntDeno);
						
						DMLTskCmpltd =((double)TskClsdAndAbeyence / (double)TotalTskCntDeno) * 100;
						DMLTskCmpltTend =(TskClsdAndAbeyenceLTTendays / (double)TotalTskCntDeno) * 100;

						
						printf("\n DMLTskCmpltd percentage is  = %.2f \n",DMLTskCmpltd);
						printf("\n Task Closed in Less than 10 days   = %.2f \n",DMLTskCmpltTend);

						BlwTenClsdTrToAbycPerCalc = ((double)BlwTenClsdTrToAbyc /(double)Abeyance)*100;

						AvgDaysPlant = (double)AvgAgeMth / (double)AvgCountMth ;
						
						//Total Task
						sprintf(TotalCountStr,"%d",TotalCount);
						printf("\n Total Task : %s",TotalCountStr);								

						// Task Released
						sprintf(ClosedCountStr,"%d",ClosedCount);
						printf("\n Task Released : %s",ClosedCountStr);

						//Transferred to Abeyance
						sprintf(AbeyanceStr,"%d",Abeyance);
						printf("\n Transferred to Abeyance : %s",AbeyanceStr);

						//Total Open task
						sprintf(OpenCountStr,"%d",OpenCount);
						printf("\n Total Open task : %s",OpenCountStr);

						//Open(Less than/ Equal to 10 Days)
						sprintf(BelowTenStr,"%d",BelowTen);
						printf("\n Open(Less than/ Equal to 10 Days) : %s",BelowTenStr);

						//Open(More than 10 Days)
						sprintf(AboveTenStr,"%d",AboveTen);
						printf("\n Open(More than 10 Days) : %s",AboveTenStr);

						//Closed(Less than/ equal to 10 Days)
						sprintf(BelowtenclosedStr,"%d",Belowtenclosed);
						printf("\n Closed(Less than/ equal to 10 Days) : %s",BelowtenclosedStr);

						//DML Task completed within 10 days(%)
						sprintf(DmlTskCmpltdLTTenDaysstr,"%.2f",DMLTskCmpltTend);
						printf("\n DML Task completed within 10 days  : %s",DmlTskCmpltdLTTenDaysstr);

						//DML Task completed(%)
						sprintf(DmlTskCmpltdperstr,"%.2f",DMLTskCmpltd);
						printf("\n DML Task completed  : %s",DmlTskCmpltdperstr);

						//Transferred to Abeyance %
						sprintf(AbeyanceTrnsfPerStr,"%.2f",AbeyanceTrnsfPer);
						printf("\n Transferred to Abeyance : %s",AbeyanceTrnsfPerStr);

						//Transferred to abeyance(Less than/ equal to 10 Days %)
						sprintf(BlwTenClsdTrToAbycStr,"%.2f",BlwTenClsdTrToAbycPerCalc);
						printf("\n Transferred to abeyance(Less than/ equal to 10 Days ) : %s",BlwTenClsdTrToAbycStr);


						sprintf(AvgDaysPlantStr,"%.2f",AvgDaysPlant);
						printf("\n Avg Days for exh month is : %s",AvgDaysPlantStr);
						
						FullString = CatStrings(TotalCountStr,ClosedCountStr,AbeyanceStr,OpenCountStr,BelowTenStr,AboveTenStr,BelowtenclosedStr,AvgDaysPlantStr,DmlTskCmpltdLTTenDaysstr,DmlTskCmpltdperstr,AbeyanceTrnsfPerStr);
						printf("\n FullString =%s\n",FullString);
						
						// if(dstat = ulyValueLines(MonthPrint,TRUE,0,10,reportWidth,&Strs)) goto EXIT;
						// if(dstat = ulyValueLines(",",FALSE,11,12,reportWidth,&Strs)) goto EXIT;
						// if(dstat = ulyValueLines(FullString,FALSE,13,200,reportWidth,&Strs)) goto EXIT;
						low_set_add_str(MailBodySetTemp,FullString);// Added by Nilesh
						printf("\n Pant: %s  Month : %s  FullString : %s",PlantDup,MonthPrint,FullString);fflush(stdout);
						// fprintf(fp_rep, "%s,%d,%d,%d,%d,%d,%d,", FromDateSet,TotalCount, ClosedCount, OpenCount, BelowTen, AboveTen, Abeyance);fflush(fp_rep);
					//}

						if (nlsStrStr(PlantDup,"PCVBU") || nlsStrStr(PlantDup,"PUNE")) 					OpenYearlyPune = OpenYearlyPune + OpenCount;
						if (nlsStrStr(PlantDup,"JSR")) 													OpenYearlyJsr = OpenYearlyJsr + OpenCount;
						if (nlsStrStr(PlantDup,"LKO"))													OpenYearlyLko = OpenYearlyLko + OpenCount;
						if (nlsStrStr(PlantDup,"PNR"))													OpenYearlyUtk = OpenYearlyUtk + OpenCount;
						if (nlsStrStr(PlantDup,"DWD"))													OpenYearlyDwd = OpenYearlyDwd + OpenCount;







					/*if (nlsStrStr(PlantDup,"JSR"))
					{
						string FullString = NULL;
						double	DMLTskCmpltd = 0;
						double	DMLTskCmpltTend = 0;
						int	TskClsdAndAbeyence = 0;
						double	TskClsdAndAbeyenceLTTendays = 0; 
						int TotalTskCntDeno = 0;
						TotalCount = ClosedCount + OpenCount + Abeyance;
						OpenYearlyJsr = OpenYearlyJsr + OpenCount;
						
						printf("\n ClosedCount is = %d",ClosedCount);
						printf("\n Abeyance is = %d",Abeyance);
						printf("\n TotalCount is = %d",TotalCount);
						
						TskClsdAndAbeyence = ClosedCount+Abeyance;
						TskClsdAndAbeyenceLTTendays = Belowtenclosed+BlwTenClsdTrToAbyc;
						TotalTskCntDeno = TotalCount;
						printf("\n Nemuretor Task Completed and Trnsfr to Abeyence is  =%d \n",TskClsdAndAbeyence);
						printf("\n Denomenator Toatl Task count is  =%d \n",TotalTskCntDeno);
						
						DMLTskCmpltd =((double)TskClsdAndAbeyence / (double)TotalTskCntDeno) * 100;
						DMLTskCmpltTend =((double)TskClsdAndAbeyenceLTTendays / (double)TotalTskCntDeno) * 100;
						
						printf("\n DMLTskCmpltd percentage is  =%.2f \n",DMLTskCmpltd);
						
						sprintf(TotalCountStr,"%d",TotalCount);								//Total Task
						sprintf(ClosedCountStr,"%d",ClosedCount);
						sprintf(AbeyanceStr,"%d",Abeyance);
						sprintf(OpenCountStr,"%d",OpenCount);
						sprintf(BelowTenStr,"%d",BelowTen);
						sprintf(AboveTenStr,"%d",AboveTen);
						sprintf(BelowtenclosedStr,"%d",Belowtenclosed);
						sprintf(BlwTenClsdTrToAbycStr,"%d",BlwTenClsdTrToAbyc);
						sprintf(DmlTskCmpltdLTTenDaysstr,"%.2f",DMLTskCmpltTend);
						sprintf(DmlTskCmpltdperstr,"%.2f",DMLTskCmpltd);
						
						printf("\n DMLTskCmpltd percentage in string format is  =%s \n",DmlTskCmpltdperstr);
						FullString = CatStrings(TotalCountStr,ClosedCountStr,AbeyanceStr,OpenCountStr,BelowTenStr,AboveTenStr,BelowtenclosedStr,BlwTenClsdTrToAbycStr,DmlTskCmpltdLTTenDaysstr,DmlTskCmpltdperstr);
						printf("\n FullString =%s\n",FullString);

						if(dstat = ulyValueLines(FullString,FALSE,201,300,reportWidth,&Strs)) goto EXIT;
						printf("\n FullString JSR: %s",FullString);fflush(stdout);
						low_set_add_str(MailBodySetTemp,FullString);// Added by Nilesh
					}
					if (nlsStrStr(PlantDup,"LKO"))
					{
						string FullString = NULL;
						double	DMLTskCmpltd = 0;
						double	DMLTskCmpltTend = 0;
						int	TskClsdAndAbeyence = 0;
						double	TskClsdAndAbeyenceLTTendays = 0; 
						int TotalTskCntDeno = 0;
						TotalCount = ClosedCount + OpenCount + Abeyance;
						OpenYearlyLko = OpenYearlyLko + OpenCount;
						
						printf("\n ClosedCount is = %d",ClosedCount);
						printf("\n Abeyance is = %d",Abeyance);
						printf("\n TotalCount is = %d",TotalCount);
						
						TskClsdAndAbeyence = ClosedCount+Abeyance;
						TskClsdAndAbeyenceLTTendays = Belowtenclosed+BlwTenClsdTrToAbyc;
						TotalTskCntDeno = TotalCount;
						printf("\n Nemuretor Task Completed and Trnsfr to Abeyence is  =%d \n",TskClsdAndAbeyence);
						printf("\n Denomenator Toatl Task count is  =%d \n",TotalTskCntDeno);
						
						DMLTskCmpltd =((double)TskClsdAndAbeyence / (double)TotalTskCntDeno) * 100;
						DMLTskCmpltTend =((double)TskClsdAndAbeyenceLTTendays / (double)TotalTskCntDeno) * 100;
						
						printf("\n DMLTskCmpltd percentage is  =%.2f \n",DMLTskCmpltd);
						
						sprintf(TotalCountStr,"%d",TotalCount);								//Total Task
						sprintf(ClosedCountStr,"%d",ClosedCount);
						sprintf(AbeyanceStr,"%d",Abeyance);
						sprintf(OpenCountStr,"%d",OpenCount);
						sprintf(BelowTenStr,"%d",BelowTen);
						sprintf(AboveTenStr,"%d",AboveTen);
						sprintf(BelowtenclosedStr,"%d",Belowtenclosed);
						sprintf(BlwTenClsdTrToAbycStr,"%d",BlwTenClsdTrToAbyc);
						sprintf(DmlTskCmpltdLTTenDaysstr,"%.2f",DMLTskCmpltTend);
						sprintf(DmlTskCmpltdperstr,"%.2f",DMLTskCmpltd);
						
						printf("\n DMLTskCmpltd percentage in string format is  =%s \n",DmlTskCmpltdperstr);
						FullString = CatStrings(TotalCountStr,ClosedCountStr,AbeyanceStr,OpenCountStr,BelowTenStr,AboveTenStr,BelowtenclosedStr,BlwTenClsdTrToAbycStr,DmlTskCmpltdLTTenDaysstr,DmlTskCmpltdperstr);
						printf("\n FullString =%s\n",FullString);

						if(dstat = ulyValueLines(FullString,FALSE,301,400,reportWidth,&Strs)) goto EXIT;
						printf("\n FullString LKO: %s",FullString);fflush(stdout);
						low_set_add_str(MailBodySetTemp,FullString);// Added by Nilesh
					}
					if (nlsStrStr(PlantDup,"PNR"))
					{
						string FullString = NULL;
						double	DMLTskCmpltd = 0;
						double	DMLTskCmpltTend = 0;
						int	TskClsdAndAbeyence = 0;
						double	TskClsdAndAbeyenceLTTendays = 0; 
						int TotalTskCntDeno = 0;
						TotalCount = ClosedCount + OpenCount + Abeyance;
						OpenYearlyUtk = OpenYearlyUtk + OpenCount;
						
						printf("\n ClosedCount is = %d",ClosedCount);
						printf("\n Abeyance is = %d",Abeyance);
						printf("\n TotalCount is = %d",TotalCount);
						
						TskClsdAndAbeyence = ClosedCount+Abeyance;
						TskClsdAndAbeyenceLTTendays = Belowtenclosed+BlwTenClsdTrToAbyc;
						TotalTskCntDeno = TotalCount;
						printf("\n Nemuretor Task Completed and Trnsfr to Abeyence is  =%d \n",TskClsdAndAbeyence);
						printf("\n Denomenator Toatl Task count is  =%d \n",TotalTskCntDeno);
						
						DMLTskCmpltd =((double)TskClsdAndAbeyence / (double)TotalTskCntDeno) * 100;
						DMLTskCmpltTend =((double)TskClsdAndAbeyenceLTTendays / (double)TotalTskCntDeno) * 100;
						
						printf("\n DMLTskCmpltd percentage is  =%.2f \n",DMLTskCmpltd);
						
						sprintf(TotalCountStr,"%d",TotalCount);								//Total Task
						sprintf(ClosedCountStr,"%d",ClosedCount);
						sprintf(AbeyanceStr,"%d",Abeyance);
						sprintf(OpenCountStr,"%d",OpenCount);
						sprintf(BelowTenStr,"%d",BelowTen);
						sprintf(AboveTenStr,"%d",AboveTen);
						sprintf(BelowtenclosedStr,"%d",Belowtenclosed);
						sprintf(BlwTenClsdTrToAbycStr,"%d",BlwTenClsdTrToAbyc);
						sprintf(DmlTskCmpltdLTTenDaysstr,"%.2f",DMLTskCmpltTend);
						sprintf(DmlTskCmpltdperstr,"%.2f",DMLTskCmpltd);
						
						printf("\n DMLTskCmpltd percentage in string format is  =%s \n",DmlTskCmpltdperstr);
						FullString = CatStrings(TotalCountStr,ClosedCountStr,AbeyanceStr,OpenCountStr,BelowTenStr,AboveTenStr,BelowtenclosedStr,BlwTenClsdTrToAbycStr,DmlTskCmpltdLTTenDaysstr,DmlTskCmpltdperstr);
						printf("\n FullString =%s\n",FullString);

						if(dstat = ulyValueLines(FullString,FALSE,401,500,reportWidth,&Strs)) goto EXIT;
						low_set_add_str(MailBodySetTemp,FullString);
						printf("\n FullString UTK: %s",FullString);fflush(stdout);
						//fprintf(fp_rep, "%d,%d,%d,%d,%d,%d,", TotalCount, ClosedCount, OpenCount, BelowTen, AboveTen, Abeyance);fflush(fp_rep);
					}
					if (nlsStrStr(PlantDup,"DWD"))
					{
						string FullString = NULL;
						double	DMLTskCmpltd = 0;
						double	DMLTskCmpltTend = 0;
						int	TskClsdAndAbeyence = 0;
						double	TskClsdAndAbeyenceLTTendays = 0; 
						int TotalTskCntDeno = 0;
						TotalCount = ClosedCount + OpenCount + Abeyance;
						OpenYearlyDwd = OpenYearlyDwd + OpenCount;
						
						printf("\n ClosedCount is = %d",ClosedCount);
						printf("\n Abeyance is = %d",Abeyance);
						printf("\n TotalCount is = %d",TotalCount);
						
						TskClsdAndAbeyence = ClosedCount+Abeyance;
						TskClsdAndAbeyenceLTTendays = Belowtenclosed+BlwTenClsdTrToAbyc;
						TotalTskCntDeno = TotalCount;
						printf("\n Nemuretor Task Completed and Trnsfr to Abeyence is  =%d \n",TskClsdAndAbeyence);
						printf("\n Denomenator Toatl Task count is  =%d \n",TotalTskCntDeno);
						
						DMLTskCmpltd =((double)TskClsdAndAbeyence / (double)TotalTskCntDeno) * 100;
						DMLTskCmpltTend =((double)TskClsdAndAbeyenceLTTendays / (double)TotalTskCntDeno) * 100;
						
						printf("\n DMLTskCmpltd percentage is  =%.2f \n",DMLTskCmpltd);
						
						sprintf(TotalCountStr,"%d",TotalCount);								//Total Task
						sprintf(ClosedCountStr,"%d",ClosedCount);
						sprintf(AbeyanceStr,"%d",Abeyance);
						sprintf(OpenCountStr,"%d",OpenCount);
						sprintf(BelowTenStr,"%d",BelowTen);
						sprintf(AboveTenStr,"%d",AboveTen);
						sprintf(BelowtenclosedStr,"%d",Belowtenclosed);
						sprintf(BlwTenClsdTrToAbycStr,"%d",BlwTenClsdTrToAbyc);
						sprintf(DmlTskCmpltdLTTenDaysstr,"%.2f",DMLTskCmpltTend);
						sprintf(DmlTskCmpltdperstr,"%.2f",DMLTskCmpltd);
						
						printf("\n DMLTskCmpltd percentage in string format is  =%s \n",DmlTskCmpltdperstr);
						FullString = CatStrings(TotalCountStr,ClosedCountStr,AbeyanceStr,OpenCountStr,BelowTenStr,AboveTenStr,BelowtenclosedStr,BlwTenClsdTrToAbycStr,DmlTskCmpltdLTTenDaysstr,DmlTskCmpltdperstr);
						printf("\n FullString =%s\n",FullString);

						if(dstat = ulyValueLines(FullString,FALSE,501,600,reportWidth,&Strs)) goto EXIT;
						printf("\n FullString DWD: %s",FullString);fflush(stdout);
						//fprintf(fp_rep, "%d,%d,%d,%d,%d,%d\n", TotalCount, ClosedCount, OpenCount, BelowTen, AboveTen, Abeyance);fflush(fp_rep);
						low_set_add_str(MailBodySetTemp,FullString);
					} */

					TskClsdAndAbeyenceLTTendaysCumMth = TskClsdAndAbeyenceLTTendaysCumMth + TskClsdAndAbeyenceLTTendays;
					TskClsdAndAbeyenceCumMth = TskClsdAndAbeyenceCumMth + TskClsdAndAbeyence;

					BlwTenClsdTrToAbycCumMthPer = BlwTenClsdTrToAbycCumMthPer + BlwTenClsdTrToAbyc;
					// TotalTskCntCumMthDeno			=	TotalTskCntCumMthDeno +  TotalCount;

					TotalCountCumMth						=	TotalCountCumMth 						+ 	TotalCount;
					ClosedCountCumMth						=	ClosedCountCumMth 						+ 	ClosedCount;
					AbeyanceCumMth							=	AbeyanceCumMth							+	Abeyance;
					OpenCountCumMth							=	OpenCountCumMth							+	OpenCount;
					BelowTenCumMth							=	BelowTenCumMth							+	BelowTen;
					AboveTenCumMth							=	AboveTenCumMth							+	AboveTen;
					BelowtenclosedCumMth					=	BelowtenclosedCumMth					+	Belowtenclosed;

					

					
					
				}
			}
					TotalCountCumMthGlb						=	TotalCountCumMthGlb						+	TotalCountCumMth;
					printf("\n TotalCountCumMthGlb : %d ",TotalCountCumMthGlb);
					printf("\n TotalCountCumMth : %d ",TotalCountCumMth);
					printf("\n TskClsdAndAbeyenceLTTendaysCumMth : %d ",TskClsdAndAbeyenceLTTendaysCumMth);
			// Calculation for monthwise for all plants.
					// DmlTskCmpltdLTTenDaysCumMth				=	(TskClsdAndAbeyenceLTTendaysCumMth	/ (double)TotalCountCumMth)* 100;			existing logic 
					DmlTskCmpltdLTTenDaysCumMth				=	((double)TskClsdAndAbeyenceLTTendaysCumMth	/ (double)TotalCountCumMthGlb)* 100;				//	updated logic as per requirment
					DmlTskCmpltdperCumMth					=	(TskClsdAndAbeyenceCumMth	/	(double)TotalCountCumMth) * 100 ;
					AbeyanceTrnsfPerCumMth					=	((double)AbeyanceCumMth		/	(double)TotalCountCumMth) * 100;
					BlwTenClsdTrToAbycCumMth				=	(BlwTenClsdTrToAbycCumMthPer	/	(double)AbeyanceCumMth) * 100;
					AvgCountCumm							=	((double)AvgAge / (double)AvgCount);

					sprintf(TotalCountCumMthStr,"%d",TotalCountCumMth);
					sprintf(ClosedCountCumMthStr,"%d",ClosedCountCumMth);
					sprintf(AbeyanceCumMthStr,"%d",AbeyanceCumMth);
					sprintf(OpenCountCumMthStr,"%d",OpenCountCumMth);
					sprintf(BelowTenCumMthStr,"%d",BelowTenCumMth);
					sprintf(AboveTenCumMthStr,"%d",AboveTenCumMth);
					sprintf(BelowtenclosedCumMthStr,"%d",BelowtenclosedCumMth);
					sprintf(DmlTskCmpltdLTTenDaysCumMthStr,"%.2f",DmlTskCmpltdLTTenDaysCumMth);
					sprintf(DmlTskCmpltdperCumMthStr,"%.2f",DmlTskCmpltdperCumMth);
					sprintf(AbeyanceTrnsfPerCumMthStr,"%.2f",AbeyanceTrnsfPerCumMth);
					sprintf(BlwTenClsdTrToAbycCumMthStr,"%.2f",BlwTenClsdTrToAbycCumMth);
					sprintf(AvgCountCummStr,"%.2f",AvgCountCumm);

					printf("\n TotalCountCumMthStr : %s , TotalCountCumMth : %d",TotalCountCumMthStr,TotalCountCumMth);fflush(stdout);
					printf("\n ClosedCountCumMthStr : %s , ClosedCountCumMth : %d",ClosedCountCumMthStr,ClosedCountCumMth);fflush(stdout);
					printf("\n AbeyanceCumMthStr : %s , AbeyanceCumMth : %d",AbeyanceCumMthStr,AbeyanceCumMth);fflush(stdout);
					printf("\n OpenCountCumMthStr : %s , OpenCountCumMth : %d",OpenCountCumMthStr,OpenCountCumMth);fflush(stdout);
					printf("\n AboveTenCumMthStr : %s , AboveTenCumMth : %d",AboveTenCumMthStr,AboveTenCumMth);fflush(stdout);

				string CumPlantStr		=	NULL;
				CumPlantStr = CatStrings(TotalCountCumMthStr,ClosedCountCumMthStr,AbeyanceCumMthStr,OpenCountCumMthStr,BelowTenCumMthStr,AboveTenCumMthStr,BelowtenclosedCumMthStr,AvgCountCummStr,DmlTskCmpltdLTTenDaysCumMthStr,DmlTskCmpltdperCumMthStr,AbeyanceTrnsfPerCumMthStr);
				low_set_add_str(CummMonthlyAllPlants,CumPlantStr);

				// TotalCountCumMthStr						= NULL;
				// ClosedCountCumMthStr					= NULL;
				// AbeyanceCumMthStr						= NULL;
				// OpenCountCumMthStr						= NULL;
				// BelowTenCumMthStr						= NULL;
				// AboveTenCumMthStr						= NULL;
				// BelowtenclosedCumMthStr					= NULL;
				// DmlTskCmpltdLTTenDaysCumMthStr			= NULL;
				// DmlTskCmpltdperCumMthStr				= NULL;
				// AbeyanceTrnsfPerCumMthStr				= NULL;
				// BlwTenClsdTrToAbycCumMthStr				= NULL;
		}
		
		OpenYearlyTotal=OpenYearlyPune+OpenYearlyJsr+OpenYearlyLko+OpenYearlyUtk+OpenYearlyDwd;
		
		sprintf(OpenYearlyPuneStr,"%d",OpenYearlyPune);
		sprintf(OpenYearlyJsrStr,"%d",OpenYearlyJsr);
		sprintf(OpenYearlyLkoStr,"%d",OpenYearlyLko);
		sprintf(OpenYearlyUtkStr,"%d",OpenYearlyUtk);
		sprintf(OpenYearlyDwdStr,"%d",OpenYearlyDwd);
		sprintf(OpenYearlyTotalStr,"%d",OpenYearlyTotal);
		
		nlsStrCat(OpenYearlyString,OpenYearlyPuneStr);
		nlsStrCat(OpenYearlyString,",");
		nlsStrCat(OpenYearlyString,OpenYearlyJsrStr);
		nlsStrCat(OpenYearlyString,",");
		nlsStrCat(OpenYearlyString,OpenYearlyLkoStr);
		nlsStrCat(OpenYearlyString,",");
		nlsStrCat(OpenYearlyString,OpenYearlyUtkStr);
		nlsStrCat(OpenYearlyString,",");
		nlsStrCat(OpenYearlyString,OpenYearlyDwdStr);
		nlsStrCat(OpenYearlyString,",");
		nlsStrCat(OpenYearlyString,OpenYearlyTotalStr);
		
		if(dstat = ulyValueLines(OpenYearlyString,FALSE,31,55,reportWidth,&Strs2)) goto EXIT;
		nlsStrCpy(MailheaderStr,OpenYearlyString);
	}
	if(setSize(Strs)>0)
	{
		if(dstat = ulyValueLines(",,,****,END, OF, REPORT,****",TRUE,0,50,reportWidth,&Strs)) goto EXIT;
		//string Path= NULL;
		//Path = nlsStrAlloc(100);
		//nlsStrCpy(Path,"/user/omfprod/Sushant/MIS_Open_task_report/");
		//nlsStrCpy(Path,"/user/omfprod/Manish/Nilesh/");
		//nlsStrCat(Path,ReportFileName);
		
		//if (dstat = ftAppendStringSet(NULL,NULL,Path,Strs2,mfail)) goto EXIT;
		//if (dstat = ftAppendStringSet(NULL,NULL,Path,Strs,mfail)) goto EXIT;
	}
	//************************************************* HTML ***************************************************
	SetOfStrings		MailBodyStrSet			= NULL;
	MailBodyStrSet								= low_set_create(1);
	
	SetOfStrings	    extraStr			= NULL;
	extraStr 	   						    = low_set_create(1);
	int MailbodysetIterator					= 0;
	string				MailBodyStr			= NULL;
	int 				DateSetIterator		= 0;
	int 				Month				= 0;
	string 				MonthStr			= NULL;
	MonthStr								= nlsStrAlloc(20);
	string				EmailHeadDate		= NULL;
	EmailHeadDate							= nlsStrAlloc(50);
	EmailHeadDate							= sysGetDate2();
	
	
	string 				EmailBodyDate		= NULL;
	EmailBodyDate							= nlsStrAlloc(50);
	EmailBodyDate							= sysGetDate();
	
	int NextYear							= 0;
	int CurrYearInt							= 0;
	
	string Curryear 						= NULL;
	Curryear = nlsStrAlloc(10);
	string CurryearSub = NULL;
	CurryearSub = nlsStrAlloc(10);
	string CurrMonth = NULL;
	CurrMonth = nlsStrAlloc(10);
	string CurrDay = NULL;
	CurrDay = nlsStrAlloc(10);
	string NextYearStr=  NULL;
	NextYearStr	=	nlsStrAlloc(10);
	string SubjectDate = NULL;
	SubjectDate = nlsStrAlloc(100);
	nlsStrCpy(Curryear,strtok(EmailBodyDate,"-"));
	nlsStrCpy(CurrMonth,strtok(NULL,"-"));
	nlsStrCpy(CurrDay,strtok(NULL,"-"));
	nlsStrCpy(CurryearSub,Curryear);
	
	nlsStrCpy(SubjectDate,"");
	nlsStrCat(SubjectDate,"Monthly ECM CV Level DML TASK Summary as ");
	nlsStrCat(SubjectDate,CurrDay);
	nlsStrCat(SubjectDate,"-");
	nlsStrCat(SubjectDate,getMonth(CurrMonth));
	nlsStrCat(SubjectDate,"-");
	nlsStrCat(SubjectDate,CurryearSub);
	
	if(atoi(CurrMonth) <= 4 )
	{
	nlsStrCpy(NextYearStr,Curryear);
	CurrYearInt = atoi(Curryear) - 1;
	sprintf(Curryear,"%d",CurrYearInt);
	printf("\n Current Year : %s",Curryear);fflush(stdout);
	}
	else
	{
	NextYear = atoi(Curryear) + 1;
	printf("\n Next Year int : %d",NextYear);fflush(stdout);
	sprintf(NextYearStr,"%d",NextYear);
	printf("\n Next Year str : %s",NextYearStr);fflush(stdout);
	}
	low_set_add_str_unique (extraStr, "MIME-Version:1.0");
	low_set_add_str_unique (extraStr, "Content-Type:text/html; charset='us-ascii'");
	low_set_add_str_unique (extraStr, "Content-Disposition:inline");
	low_set_add_str_unique (extraStr, "Cc:nitish.kumar@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:gupta.manish@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:netaji.katkar@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:suhas.chitragar@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:saurav.goyal@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:edrina@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:prasanna.handore@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:sudarshan.vattamwar@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:anup.barik@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:vinay1.ttl@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:subrata.sen@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:aruna.ttl@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:dhrubak.ttl@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:sanjayj1.ttl@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:sandeepg.ttl@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:manindrap.ttl@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:monazirn.ttl@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:manishk1.ttl@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:ashwanik.ttl@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:nk2.ttl@tatamotors.com");
	low_set_add_str_unique (extraStr, "Cc:gupta.manish@tatamotors.com");			// kindly remove before finalize

	low_set_add_str(MailBodyStrSet,"<!DOCTYPE html>");
	low_set_add_str(MailBodyStrSet, "<html><head>");
	low_set_add_str(MailBodyStrSet,"<style media='screen'>td { border-style: ridge; border-collapse: collapse;}</style>");
	low_set_add_str(MailBodyStrSet,"</head>");
	low_set_add_str(MailBodyStrSet,"<body style='font-family: Georgia;'>");
	low_set_add_str(MailBodyStrSet,"<p>Dear Team,<br>Please find consolidated view of <b>Monthly ECM CV Level DML TASK Summary</b>.</p>");
	low_set_add_str(MailBodyStrSet,"<table style ='width:100% ; text-align:center;'>");
	low_set_add_str(MailBodyStrSet,"<tr style='background: #66ccff; height:60px;'>");
	low_set_add_str(MailBodyStrSet,"<td style='font-size:20px; font-weight: bold;' colspan = 7 >ECM CV LEVEL DML TASK SUMMARY AS ON ");
	low_set_add_str(MailBodyStrSet,EmailHeadDate);
	low_set_add_str(MailBodyStrSet,"</td></tr>");
	low_set_add_str(MailBodyStrSet,"<tr style='background:#ebde34;height:20px; width:100%; font-weight: bold;'>");
    low_set_add_str(MailBodyStrSet,"<td>Plant</td>");
    low_set_add_str(MailBodyStrSet,"<td>CV-PUNE</td>");
    low_set_add_str(MailBodyStrSet,"<td>CV-JSR</td>");
    low_set_add_str(MailBodyStrSet,"<td>CV-LKN</td>");
    low_set_add_str(MailBodyStrSet,"<td>CV-UTK</td>");
    low_set_add_str(MailBodyStrSet,"<td>CV-DWD</td>");
    low_set_add_str(MailBodyStrSet,"<td>Year Wise Total</td></tr>");
	low_set_add_str(MailBodyStrSet,"<tr style='height:20px; width:100%;'>");
	low_set_add_str(MailBodyStrSet,"<td style='font-weight: bold;'>Financial Year [ ");
	low_set_add_str(MailBodyStrSet,Curryear);
	low_set_add_str(MailBodyStrSet,"-");
	low_set_add_str(MailBodyStrSet,NextYearStr);
	low_set_add_str(MailBodyStrSet," ]</td>");
	low_set_add_str(MailBodyStrSet,"<td>");
	low_set_add_str(MailBodyStrSet,strsep(&MailheaderStr,","));
	low_set_add_str(MailBodyStrSet,"</td><td>");
	low_set_add_str(MailBodyStrSet,strsep(&MailheaderStr,","));
	low_set_add_str(MailBodyStrSet,"</td><td>");
	low_set_add_str(MailBodyStrSet,strsep(&MailheaderStr,","));
	low_set_add_str(MailBodyStrSet,"</td><td>");
	low_set_add_str(MailBodyStrSet,strsep(&MailheaderStr,","));
	low_set_add_str(MailBodyStrSet,"</td><td>");
	low_set_add_str(MailBodyStrSet,strsep(&MailheaderStr,","));
	low_set_add_str(MailBodyStrSet,"</td><td>");
	low_set_add_str(MailBodyStrSet,strsep(&MailheaderStr,","));
	low_set_add_str(MailBodyStrSet,"</td></tr></table>");

	low_set_add_str(MailBodyStrSet,"<br><br><table style ='width:100% ; text-align:center;'>");
	low_set_add_str(MailBodyStrSet,"<tr style='background: #66ccff; height:60px;'>");
	low_set_add_str(MailBodyStrSet,"<td style='font-size:20px; font-weight: bold;' colspan = 12 >CV LEVEL PLANT CUMULATIVE MONTHWISE DML TASK COUNT BREAK UP - FINANCIAL YEAR : ");
	low_set_add_str(MailBodyStrSet,EmailHeadDate);
	low_set_add_str(MailBodyStrSet,"</td></tr>");
	low_set_add_str(MailBodyStrSet,"<tr style ='font-weight: bold;'><td>Month</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Task Released</td>");
    low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Open task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(Less than/ Equal to 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(More than 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Closed(Less than/ equal to 10 Days)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Average Age</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed within 10 days(%)</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed(%)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance %</td></tr>");
	int				plantCummItr	=	0;
	string 			CummMonthlyAllPlantsStr	=	NULL;
					CummMonthlyAllPlantsStr = 	nlsStrAlloc(100);
					Month					=	4;
	for(plantCummItr = 0; plantCummItr < setSize(CummMonthlyAllPlants); plantCummItr++)
	{
		sprintf(MonthStr,"%d",Month);
		CummMonthlyAllPlantsStr = setGetStr(CummMonthlyAllPlants,plantCummItr);

		low_set_add_str(MailBodyStrSet,"<tr><td style='font-weight: bold;'>");
		low_set_add_str(MailBodyStrSet,getMonth(MonthStr));
		low_set_add_str(MailBodyStrSet,"</td>");
		low_set_add_str(MailBodyStrSet,"<td >");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&CummMonthlyAllPlantsStr,","));
		low_set_add_str(MailBodyStrSet,"</td></tr>");

		Month++;
	}
	low_set_add_str(MailBodyStrSet,"</table>");

	low_set_add_str(MailBodyStrSet,"<br><br><table style ='width:100%; text-align:center;'>");
	low_set_add_str(MailBodyStrSet,"<tr style='background:#66ccff;height:60px;'>");
	low_set_add_str(MailBodyStrSet,"<td style='font-size:20px; font-weight: bold;' colspan = 12>CV LEVEL MONTHWISE DML TASK COUNT BREAK UP - FINANCIAL YEAR : ");
	low_set_add_str(MailBodyStrSet,Curryear);
	low_set_add_str(MailBodyStrSet,"-");
	low_set_add_str(MailBodyStrSet,NextYearStr);
	low_set_add_str(MailBodyStrSet," </td></tr>");
	low_set_add_str(MailBodyStrSet,"<tr style='background:#ebde34;height:20px; width:100%; font-weight: bold;'>");
	low_set_add_str(MailBodyStrSet,"<td style='font-weight: bold;'>Plant</td>");
	//Pune Plant
	low_set_add_str(MailBodyStrSet,"<td colspan = 11>CV-PUNE</td></tr>");
	low_set_add_str(MailBodyStrSet,"<tr style='font-weight: bold;'><td>Month</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Task Released</td>");
    low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Open task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(Less than/ Equal to 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(More than 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Closed(Less than/ equal to 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Average Age</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed within 10 days(%)</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed(%)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance %</td></tr>");
	
	for(MailbodysetIterator = 0; MailbodysetIterator<setSize(MailBodySetTemp);MailbodysetIterator+=5)
	{
		if(MailbodysetIterator == 0)printf("\n ********************************Inside Pune Plant************************************************");fflush(stdout);
		MailBodyStr = setGet(MailBodySetTemp,MailbodysetIterator);
		Month = DateSetIterator+4;
		sprintf(MonthStr,"%d",Month);
		low_set_add_str(MailBodyStrSet,"<tr><td style='font-weight: bold;'>");
		low_set_add_str(MailBodyStrSet,getMonth(MonthStr));
		low_set_add_str(MailBodyStrSet,"</td>");
		low_set_add_str(MailBodyStrSet,"<td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td></tr>");
		DateSetIterator++;
		printf("\n End Pune Plant");fflush(stdout);
		
	}
	DateSetIterator = 0;
	//JSR
	low_set_add_str(MailBodyStrSet,"<tr style='background:#0ef1d6;height:20px; width:100%; font-weight: bold;'>");
	low_set_add_str(MailBodyStrSet,"<td>Plant</td><td  colspan = 11>CV-JSR</td></tr>");
	low_set_add_str(MailBodyStrSet,"<tr style='font-weight: bold;'><td>Month</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Task Released</td>");
    low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Open task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(Less than/ Equal to 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(More than 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Closed(Less than/ equal to 10 Days)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Average Age</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed within 10 days(%)</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed(%)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance %</td></tr>");
	
	for(MailbodysetIterator = 1; MailbodysetIterator<setSize(MailBodySetTemp);MailbodysetIterator+=5)
	{
		if(MailbodysetIterator == 1)printf("\n ************************************Inside JSR Plant************************************");fflush(stdout);
		MailBodyStr = setGet(MailBodySetTemp,MailbodysetIterator);
		Month = DateSetIterator+4;
		sprintf(MonthStr,"%d",Month);
		low_set_add_str(MailBodyStrSet,"<tr><td style='font-weight: bold;'>");
		low_set_add_str(MailBodyStrSet,getMonth(MonthStr));
		low_set_add_str(MailBodyStrSet,"</td>");
		low_set_add_str(MailBodyStrSet,"<td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td></tr>");
		DateSetIterator++;
	}
	DateSetIterator = 0;
	//LKO
	low_set_add_str(MailBodyStrSet,"<tr style='background:#ebde34;height:20px; width:100%; font-weight: bold;'>");
	low_set_add_str(MailBodyStrSet,"<td>Plant</td><td  colspan = 11>CV-LKO</td></tr>");
	low_set_add_str(MailBodyStrSet,"<tr style='font-weight: bold;'><td>Month</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Task Released</td>");
    low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Open task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(Less than/ Equal to 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(More than 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Closed(Less than/ equal to 10 Days)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Average Age</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed within 10 days(%)</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed(%)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance %</td></tr>");
	
	for(MailbodysetIterator = 2; MailbodysetIterator<setSize(MailBodySetTemp);MailbodysetIterator+=5)
	{
		printf("\n Inside LKO Plant");fflush(stdout);
		MailBodyStr = setGet(MailBodySetTemp,MailbodysetIterator);
		Month = DateSetIterator+4;
		sprintf(MonthStr,"%d",Month);
		low_set_add_str(MailBodyStrSet,"<tr><td style='font-weight: bold;'>");
		low_set_add_str(MailBodyStrSet,getMonth(MonthStr));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td></tr>");
		DateSetIterator++;
	}
	DateSetIterator = 0;
	//UTK
	low_set_add_str(MailBodyStrSet,"<tr style='background:#0ef1d6;height:20px; width:100%; font-weight: bold;'>");
	low_set_add_str(MailBodyStrSet,"<td>Plant</td><td  colspan = 11>CV-UTK</td></tr>");
	low_set_add_str(MailBodyStrSet,"<tr style='font-weight: bold;'><td>Month</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Task Released</td>");
    low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Open task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(Less than/ Equal to 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(More than 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Closed(Less than/ equal to 10 Days)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Average Age</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed within 10 days(%)</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed(%)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance %</td></tr>");
	
	for(MailbodysetIterator = 3; MailbodysetIterator<setSize(MailBodySetTemp);MailbodysetIterator+=5)
	{
		printf("\n Inside UTK Plant");fflush(stdout);
		MailBodyStr = setGet(MailBodySetTemp,MailbodysetIterator);
		Month = DateSetIterator+4;
		sprintf(MonthStr,"%d",Month);
		low_set_add_str(MailBodyStrSet,"<tr><td style='font-weight: bold;'>");
		low_set_add_str(MailBodyStrSet,getMonth(MonthStr));
		low_set_add_str(MailBodyStrSet,"</td>");
		low_set_add_str(MailBodyStrSet,"<td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td></tr>");
		DateSetIterator++;
	}
	DateSetIterator = 0;
	// DWD
	low_set_add_str(MailBodyStrSet,"<tr style='background:#ebde34;height:20px; width:100%; font-weight: bold;'>");
	low_set_add_str(MailBodyStrSet,"<td >Plant</td><td colspan = 11>CV-DWD</td></tr>");
	low_set_add_str(MailBodyStrSet,"<tr style ='font-weight: bold;'><td>Month</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Task Released</td>");
    low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance</td>");
    low_set_add_str(MailBodyStrSet,"<td >Total Open task</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(Less than/ Equal to 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Open(More than 10 Days)</td>");
    low_set_add_str(MailBodyStrSet,"<td >Closed(Less than/ equal to 10 Days)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Average Age</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed within 10 days(%)</td>");
    low_set_add_str(MailBodyStrSet,"<td >DML Task completed(%)</td>");
	low_set_add_str(MailBodyStrSet,"<td >Transferred to Abeyance %</td></tr>");
	
	for(MailbodysetIterator = 4; MailbodysetIterator<setSize(MailBodySetTemp);MailbodysetIterator+=5)
	{
		printf("\n Inside DWD Plant");fflush(stdout);
		MailBodyStr = setGet(MailBodySetTemp,MailbodysetIterator);
		
		Month = DateSetIterator+4;
		sprintf(MonthStr,"%d",Month);
		low_set_add_str(MailBodyStrSet,"<tr><td style='font-weight: bold;'>");
		low_set_add_str(MailBodyStrSet,getMonth(MonthStr));
		low_set_add_str(MailBodyStrSet,"</td>");
		low_set_add_str(MailBodyStrSet,"<td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td >");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td><td>");
		low_set_add_str(MailBodyStrSet,strsep(&MailBodyStr,","));
		low_set_add_str(MailBodyStrSet,"</td></tr>");
		DateSetIterator++;
	}
	low_set_add_str(MailBodyStrSet,"</table>");
	
	low_set_add_str(MailBodyStrSet,"<br><br>");
	low_set_add_str(MailBodyStrSet,"<p>Warm regards,<br><br>JSR PLM Team</p>");
	low_set_add_str(MailBodyStrSet,"</body></html>");
	
	printf("\n\n *********,**************,*******End, Of Program ***,**************,*************\n\n");fflush(stdout);
	if(fp_rep!= NULL)
	{
		fclose(fp_rep);
	}
	/*************************Mail code here**************************************************************************/
	string MailTo	= NULL;
	MailTo = nlsStrAlloc(100);
	FILE * fpToMAilID = NULL;
	fpToMAilID	= fopen("ToMailID.txt","r");
	fscanf(fpToMAilID,"%s",MailTo);
	int exeflg = 0;
	printf("\n Going to mail .....!!!!");fflush(stdout);
		if (dstat = MailInterface( "Usr","OMF Distributed Production Environment ","omfprod@plmpapp2c3.localdomain","TMCV STDS ",MailTo,SubjectDate,MailBodyStrSet,extraStr,mfail)) goto EXIT;
		if (exeflg != 0)
		{
			printf("\n  mail sending failed");fflush(stdout);
			fprintf(fp_log, "\n mail sending failed \n");fflush(fp_log);
			goto CLEANUP;
		}
		dstat = clReleaseServers();
	/*************************Mail code end**************************************************************************/

	CLEANUP:
		printf("\n Inside Clean-Up\n");
	fflush(stdout);
	t5PrintCleanUpModName;

	EXIT:
		printf("\n Inside Exit\n");
	fflush(stdout);
	t5CheckDstatAndReturn;
};
