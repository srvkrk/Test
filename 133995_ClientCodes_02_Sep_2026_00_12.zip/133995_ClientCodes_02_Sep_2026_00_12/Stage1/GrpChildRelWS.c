#include "soapH.h"
#include "GrpChildRelWS.nsmap"

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tccore/project.h>
#include <cfm/cfm.h>
#include <qry/qry.h>
#include <tc/preferences.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include "tm_apl_std_common_function.c"


#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); Debug("line %d (ifail %d)\n", __LINE__, ifail);}

/*struct BomChldStrut
{
	tag_t child_objs;
	tag_t child_objs_bvr;
	int child_objs_lvl;
}*get_BomChldStrut;
*/

struct ChldStruct
{
	char child_parts[40];

}*get_ChldStruct;

FILE	*GrpChildRelWSLog;

char 		szHMCL_file_log[250] 			= "";
char 		szHMCL_file_err[250]			= "";
char 		szHMCL_file_output[250] 		= "";
static void vLog(char* givenFormat, va_list givenArgs, char* fileName)
{
	char			* logFile 			= NULL;
	FILE			* logFp;
	time_t 			now;
	struct 			tm when;
	char 			date_str[50];
	long 			size;
	logical 		check_size 			= false;
	logFile 							= fileName;
	if (logFile)
	{
		logFp = fopen(logFile, "a+");
		if(!logFp)
		{
			fprintf(stderr, "ERROR: Cannot open '%s'\n", logFile);
			perror(logFile);
			logFp = stderr;
		}
		else{
			fseek(logFp, 0, SEEK_END);
			size = ftell(logFp);
			if(size > 3000000 && check_size)
			{	fclose (logFp);
				logFp = fopen(logFile, "w");
			}
			  }
	}
	else
	{	logFp = stderr;
	}
	if (tc_strcmp(logFile, szHMCL_file_output) == 0)
	{
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp,"\n");
		if (logFp != stderr)
		{			fclose(logFp);
		}
	}
	else
	{
		time(&now);
		when = *localtime(&now);
		strftime(date_str, 50, "%d-%m-%Y %H:%M:%S",&when);
		fprintf(logFp, "%s --- ", date_str);
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp, "\n");
		if (logFp != stderr)
		{	fclose(logFp);
		}
	}
}
void Debug(char* givenFormat, ...)
{
	va_list   functArgs;
	va_start(functArgs, givenFormat);
	vLog(givenFormat, functArgs, szHMCL_file_log);
	va_end(functArgs);
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}
//#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
 if (return_code != ITK_ok)
	{
	char *error_msg_string;

	EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
	printf("ERROR1: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
	TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
	TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
	if(error_msg_string) MEM_free(error_msg_string);

	}
	return return_code;
}


extern int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new()); /* call the request dispatcher */

};


int ns__getGrpChildRelWS(struct soap* soap,char *Grp_prt,char *Plant,struct ns__CharArray1 *aString_test)
{
	
	    int reqlevel = 99;
		int StructChldCnt = 0;
		int ifail  =  0;
		int j=0,i=0;
		int k=0,ip=0,p=0;
		int strcount = 0;
		int	d=0;
		int chcnt=0,childcnt;
		int flag = 0;
		int prtptr=0;
		int PartCnt = 0;
        int cnt = 0;
		int BPSFlg = 0;
		int	SysReturn =	0;
		int cntdp = 0;
		int Released_cnt = 0;

		char *ExeLogFile =	NULL;
		char *loggedInUser = NULL;
		
		char *ClosureRName= NULL;
        char *RevisionRName= NULL;
		char *ViewBVR= NULL;
		char *Released_status = NULL;
		
		/*char ClosureRName[50];
        char RevisionRName[50];
		char ViewBVR[50];
		*/

		char *PartName	= NULL;
		char *PartRevision	= NULL;
		char *itemId = NULL;
		char *partRev = NULL;
		char filewrite[3000];
		
        tag_t	Childobj = NULLTAG;
		tag_t PrtRltnTag = NULLTAG;
		tag_t PartTag = NULLTAG;
		tag_t itemRev_tag = NULLTAG;
		//tag_t rev_tag = NULLTAG;
		tag_t *PartsTags = NULLTAG;
		tag_t *status_list = NULLTAG;

		struct BomChldStrut ChldStrutPart[3000];
        struct ChldStruct ChldPrtList[3000];
		
		char *inputfile	=	NULL;
		FILE *fp1;

		ExeLogFile = (char	*)MEM_alloc(100);
	    tc_strcpy(ExeLogFile,"");
	    tc_strcpy(ExeLogFile,"/tmp/");
	    tc_strcat(ExeLogFile,Grp_prt);
		//tc_strcat(ExeLogFile,"_");
		//tc_strcat(ExeLogFile,Plant);
	    tc_strcat(ExeLogFile,"_GrpChildRelWS.log");
	    GrpChildRelWSLog = fopen(ExeLogFile,"w");
	  
	    fprintf(GrpChildRelWSLog,"\n Part Execution Log file is :: %s\n",ExeLogFile);

		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/tmp/GrpChildRelWS.txt", "a", stdout);

        CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login());
		CALLAPI(ITK_set_journalling( TRUE ));

		fprintf(GrpChildRelWSLog," Auto Login Successfull..!!\n");fflush(GrpChildRelWSLog);
		POM_get_user_id(&loggedInUser);
		fprintf(GrpChildRelWSLog," Logged in User: [%s]\n",loggedInUser);fflush(GrpChildRelWSLog);

		tag_t	queryGrpPart	=	NULLTAG;
		tag_t   rev_tag = NULLTAG;
		tag_t*  result	=	NULLTAG;
        
		int RlzdStatusFlag = 0;
        int		n_entries	=	2;
		int StrctInt = 0;
		int Release_count = 0;
        int		l	=	2;
		int    	num_to_sort =	1;
		//int  	orders[]  	=	{2};
		int  	orders[1]  	=	{2};
		int		n_found=	0;
		char 	*keys[1] 	= 	{"creation_date"};
		char 	*qry_GrpPart_entries[2] = {"Item ID","Release Status"};
		char 	*qry_GrpPart_values[2] = {Grp_prt,"T5_LcsErcRlzd;T5_LcsAPLlWrkg;T5_LcsApllRlzd;T5_LcsAPLpWrkg;T5_LcsAplpRlzd;T5_LcsAPLuWrkg;T5_LcsApluRlzd;T5_LcsAPLjWrkg;T5_LcsApljRlzd;T5_LcsAPLdWrkg;T5_LcsApldRlzd;T5_LcsAPLsWrkg;T5_LcsAplsRlzd;T5_LcsStdsRlzd;T5_LcsSTDsWrkg;T5_LcsSTDjWrkg;T5_LcsStdjRlzd;T5_LcsSTDdWrkg;T5_LcsStddRlzd;T5_LcsSTDlWrkg;T5_LcsStdlRlzd;T5_LcsSTDuWrkg;T5_LcsStduRlzd;T5_LcsSTDpWrkg;T5_LcsStdpRlzd;T5_MBOMReleased;T5_MBOMWorking"};
		//char 	*qry_GrpPart_values[2] = {Grp_prt,"T5_LcsErcRlzd;T5_LcsAPLlWrkg;T5_LcsApllRlzd"};
        
		CALLAPI(QRY_find("Item Revision...", &queryGrpPart));
		CALLAPI(QRY_execute_with_sort(queryGrpPart, n_entries, qry_GrpPart_entries, qry_GrpPart_values, num_to_sort, keys, orders, &Release_count, &result));
	
        
		fprintf(GrpChildRelWSLog,"\n 111 Number of Group part  [%s]found : [%d]\n",Grp_prt,Release_count);fflush(GrpChildRelWSLog);
		if(Release_count>0)
	    {
		//fprintf(GrpChildRelWSLog,"\n Release_count of group part :%d \n",Release_count);fflush(GrpChildRelWSLog);
		rev_tag = result[0];
        //CALLAPI(ITEM_ask_latest_rev(rev_tag,&itemRev_tag));
	    CALLAPI(AOM_ask_value_string(rev_tag,"item_id",&itemId));
        fprintf(GrpChildRelWSLog,"\nitemRev_tag : %s ",itemId);fflush(GrpChildRelWSLog);

		CALLAPI(AOM_ask_value_string(rev_tag,"item_revision_id",&partRev));
		fprintf(GrpChildRelWSLog,"\n partRev : %s ",partRev);fflush(GrpChildRelWSLog);

            //int j = 0;
			int k = 0;
			int Length = 0;
			int PartLength = 0;
			int childcnt = 0;
			
			//char *itemId = NULL;
			char *PartNumber = NULL;
			//char *partfnd_type = NULL;

			ClosureRName=(char *) MEM_alloc(200 * sizeof(char *));
	        RevisionRName=(char *) MEM_alloc(200 * sizeof(char *));
	        ViewBVR=(char *) MEM_alloc(100 * sizeof(char *));
			

			if(tc_strcmp(Plant,"CVBUJSR")==0)
			{
			    tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLJ");
	            tc_strcpy(RevisionRName,"ERC1 Release and Above");
	            tc_strcpy(ViewBVR,"View");

			}
			else if(tc_strcmp(Plant,"DHARWAD")==0)
			{
	            tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLD");
	            tc_strcpy(RevisionRName,"ERC1 Release and Above");
	            tc_strcpy(ViewBVR,"View");

			}
			else if(tc_strcmp(Plant,"CVBULKO")==0)
			{
				tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLL");
	            tc_strcpy(RevisionRName,"ERC1 Release and Above");
	            tc_strcpy(ViewBVR,"View");

			}
			else if(tc_strcmp(Plant,"CVBUPUNE")==0)
			{
			    tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLP");
	            tc_strcpy(RevisionRName,"ERC1 Release and Above");
                //tc_strcpy(RevisionRName,"ERC release and above");
                fprintf(GrpChildRelWSLog,"\n RevisionRName :%s \n",RevisionRName);fflush(GrpChildRelWSLog);
	            tc_strcpy(ViewBVR,"View");

			}
			else if(tc_strcmp(Plant,"CVBUPNR")==0)
			{
				tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLU");
	            tc_strcpy(RevisionRName,"ERC1 Release and Above");
	            tc_strcpy(ViewBVR,"View");

			}
			else
			{
				tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLP");
	            tc_strcpy(RevisionRName,"ERC1 Release and Above");
	            tc_strcpy(ViewBVR,"View");
			}


            
			ITKCALL(Get_Part_BOM_Lvl(rev_tag,reqlevel,ClosureRName,RevisionRName,ViewBVR,ChldStrutPart,&StructChldCnt));
			fprintf(GrpChildRelWSLog,"\nChild Part Release_count = %d \n",StructChldCnt);fflush(GrpChildRelWSLog);
           
			int partCnt=0;
			if(StructChldCnt>0)
			{
				childcnt=0;

				for(childcnt=1;childcnt<=StructChldCnt;childcnt++)
			    {
					    flag = 1;
						PartName	=	NULL;
						PartRevision	=	NULL;
						Childobj		= NULLTAG;
							
		                Childobj	=	ChldStrutPart[childcnt].child_objs;
						
						ITKCALL(AOM_ask_value_string(Childobj,"item_id",&PartName));
						
						fprintf(GrpChildRelWSLog,"\n PartNumber is :%s \n",PartName);fflush(GrpChildRelWSLog);

						ITKCALL(AOM_ask_value_string(Childobj,"current_revision_id",&PartRevision));
						
						fprintf(GrpChildRelWSLog,"\n PartRevision is :%s \n",PartRevision);fflush(GrpChildRelWSLog);

						PartLength=tc_strlen(PartName);

						fprintf(GrpChildRelWSLog,"\nPartLength = %d \n",PartLength);fflush(GrpChildRelWSLog);
                        
						partCnt=childcnt-1;
						tc_strcpy(ChldPrtList[partCnt].child_parts,PartName);
						fprintf(GrpChildRelWSLog,"\n ChldPrtList[partCnt].child_parts = %s \n",ChldPrtList[partCnt].child_parts);fflush(GrpChildRelWSLog);

						//Length = strlen(ChldStrutPart[childcnt].child_objs);				  
			    }


			}
			fprintf(GrpChildRelWSLog,"\nflag : %d\n",flag);fflush(GrpChildRelWSLog);
		    
            if(flag>0)
			{
				childcnt = 0;
			    aString_test->__size = StructChldCnt  ;
                aString_test->__ptrPrt = malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__ptrPrt) );
				for(childcnt=0;childcnt<StructChldCnt;childcnt++)
				//for(childcnt=0;childcnt<=partCnt;childcnt++)
			    {

					aString_test->__ptrPrt[childcnt].prt_no = malloc(StructChldCnt* sizeof(char*)+5);

					fprintf(GrpChildRelWSLog,"\nPartLength : %d \n",PartLength);fflush(GrpChildRelWSLog);
                    fprintf(GrpChildRelWSLog,"\nchild Parts : %s \n",ChldPrtList[childcnt].child_parts);fflush(GrpChildRelWSLog);
                    tc_strcpy(aString_test->__ptrPrt[childcnt].prt_no,ChldPrtList[childcnt].child_parts);
                    fprintf(GrpChildRelWSLog,"\n WS child Parts : %s \n",aString_test->__ptrPrt[childcnt].prt_no);fflush(GrpChildRelWSLog);
				}

			}
			else
			{
				StrctInt = StrctInt + 1;
				aString_test->__size = StrctInt;
				aString_test->__ptrPrt = malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__ptrPrt) );

				aString_test->__ptrPrt[i].prt_no = malloc(StrctInt* sizeof(char*)+5);
				fprintf(GrpChildRelWSLog,"\nChild Parts Not found\n");fflush(GrpChildRelWSLog);
				tc_strcpy(ChldPrtList[i].child_parts,"NA");
				tc_strcpy(aString_test->__ptrPrt[i].prt_no,ChldPrtList[i].child_parts);
				//fprintf(GrpChildRelWSLog,"\nWS child_parts : %s \n",aString_test->__ptrPrt[i].prt_no);fflush(GrpChildRelWSLog);
				
			}
			

		}
		if((Release_count==0)||(StructChldCnt==0))
	    {
			
			fprintf(GrpChildRelWSLog,"\n Group Part not found in TCUA , then check in TCE : %d\n",flag);fflush(GrpChildRelWSLog);
			char* Response = NULL;
			Response=(char *)MEM_alloc(200);
			tc_strcpy(Response,"");
			tc_strcat(Response,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_GrpChildRel/TCE_GrpChildRel.sh");
			tc_strcat(Response," ");
			tc_strcat(Response,Grp_prt);
			tc_strcat(Response," ");
			tc_strcat(Response,Plant);
			system(Response);
			fprintf(GrpChildRelWSLog,"\nResponse path : %s",Response);fflush(GrpChildRelWSLog);


            inputfile = (char *)MEM_alloc(500);
			tc_strcpy(inputfile,"");	
			tc_strcat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_GrpChildRel/");
			tc_strcat(inputfile,Grp_prt);
			tc_strcat(inputfile,Plant);
			tc_strcat(inputfile,"_TCEGrpChildRelWS.txt");
			fprintf(GrpChildRelWSLog,"\n FIleNameSDup: [%s]\n",inputfile);  fflush(GrpChildRelWSLog);

//			    inputfile = (char *)MEM_alloc(500);
//				tc_strcpy(inputfile,"");
//				tc_strcat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_GrpChildRel/");
//				tc_strcat(inputfile,"/");
//				tc_strcat(inputfile,Plant);
//				tc_strcat(inputfile,"");
//				tc_strcat(inputfile,".txt");
//				fprintf(GrpChildRelWSLog,"\nFilename : %s",inputfile);fflush(GrpChildRelWSLog);
				
				fp1=fopen(inputfile,"r");

				if(fp1!=NULL)
				{
					int partCnt=0;
					fprintf(GrpChildRelWSLog,"\n file not null : ");fflush(GrpChildRelWSLog);
					char *Response1 =NULL;

					while (fgets(filewrite,1000,fp1)!=NULL )
					{
						//fputs(filewrite,inputfile);
						fprintf(GrpChildRelWSLog,"\n fgets open and fp1 not null :");fflush(GrpChildRelWSLog);
						fprintf(GrpChildRelWSLog,"\n filewrite %s :",filewrite);fflush(GrpChildRelWSLog);
						fputs(inputfile,stdout);
		                Response1=NULL;
						Response1=tc_strtok(filewrite,",");
						fprintf(GrpChildRelWSLog,"\n Response1 is : %s",Response1);fflush(GrpChildRelWSLog);

                       
			      	    if(tc_strcmp(Response1,"")!=0)
			      	    {
							StructChldCnt++;
							partCnt=StructChldCnt-1;
							fprintf(GrpChildRelWSLog,"\n StructChldCnt is : %d",StructChldCnt);fflush(GrpChildRelWSLog);
							tc_strcpy(ChldPrtList[partCnt].child_parts,Response1);
						    fprintf(GrpChildRelWSLog,"\n ChldPrtList[partCnt].child_parts = %s \n",ChldPrtList[partCnt].child_parts);fflush(GrpChildRelWSLog);
			      	    }
				       

					}

					if(StructChldCnt>0)
			      	    {
							childcnt = 0;
							
			                aString_test->__size = StructChldCnt  ;
                            aString_test->__ptrPrt = malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__ptrPrt) );
				            for(childcnt=0;childcnt<StructChldCnt;childcnt++)
			                {
					              aString_test->__ptrPrt[childcnt].prt_no = malloc(StructChldCnt* sizeof(char*)+5);

					             // fprintf(GrpChildRelWSLog,"\nPartLength : %d \n",PartLength);fflush(GrpChildRelWSLog);
                                  fprintf(GrpChildRelWSLog,"\nchild Parts : %s \n",ChldPrtList[childcnt].child_parts);fflush(GrpChildRelWSLog);
                                  tc_strcpy(aString_test->__ptrPrt[childcnt].prt_no,ChldPrtList[childcnt].child_parts);
                                  fprintf(GrpChildRelWSLog,"\n WS child Parts : %s \n",aString_test->__ptrPrt[childcnt].prt_no);fflush(GrpChildRelWSLog);
				             }
			      	    }
				        else
					    {
							strcount = strcount + 1;
				            aString_test->__size = strcount;
				            aString_test->__ptrPrt = malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__ptrPrt) );
					 	    tc_strcpy(aString_test->__ptrPrt[p].prt_no,"NA");
						    fprintf(GrpChildRelWSLog,"\n Response is : %s",aString_test->__ptrPrt[p].prt_no);fflush(GrpChildRelWSLog);
				        }

				}
				fclose(fp1);

		}
//		else
//		{
//			StrctInt = StrctInt + 1;
//			aString_test->__size = StrctInt;
//			aString_test->__ptrPrt = malloc((aString_test ->__size + 1) * sizeof(*aString_test ->__ptrPrt) );
//
//			aString_test->__ptrPrt[i].prt_no = malloc(StrctInt* sizeof(char*)+5);
//			fprintf(GrpChildRelWSLog,"\nChild Parts Not found\n");fflush(GrpChildRelWSLog);
//			tc_strcpy(ChldPrtList[i].child_parts,"NA");
//			tc_strcpy(aString_test->__ptrPrt[i].prt_no,ChldPrtList[i].child_parts);
//			//fprintf(GrpChildRelWSLog,"\nWS child_parts : %s \n",aString_test->__ptrPrt[i].prt_no);fflush(GrpChildRelWSLog);
//			
//		}
	
	fclose(GrpChildRelWSLog);
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;


}
;
