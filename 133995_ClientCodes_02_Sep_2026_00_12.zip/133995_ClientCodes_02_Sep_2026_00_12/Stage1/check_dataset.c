/********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: check_dataset.c
**
** Functions:- This utility reads the part number from file and checks that part's latest revision's dataset is present or not, if present  
**			   checks for name reference and writes it's info. into the new file.(Newly created)
** 
**
**	Date							Author								Modification
**	20-September-2017				Kalpesh Gondhali					Code creation
**
**
** command to run:
** check_dataset -u=<username> -p=<password> -g=<group> -file=<file name>
********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>


#define CHECK_FAIL	ITKCALL(ifail)	\
				if (ifail != ITK_ok) { printf("line %d (ifail %d)\n", __LINE__, ifail); return ifail;}\

	
int check_part(char *);

char			*sep							= "^";

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<Input file name> (required)\n"
        );	
}

/*****************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*****************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
    char			* FileName					= NULL;
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	FileName		= ITK_ask_cli_argument("-file=");

	if(tc_strlen(stripBlanks(userid)) == 0 || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(FileName)) == 0)
    {
		print_requirement();
        return -1;
    }
	
	ifail = ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	CHECK_FAIL;
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull...!!\n");
			printf("\nWelcome to Teamcenter...!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("User is not Privileged Admin User \n\n");
		CHECK_FAIL;
	}
	
	ifail=read_value_from_file(FileName);

	printf("\n\nEnd of program....!!\n\n");

	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads part_no from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* FileName)
{
	int				ifail 					= ITK_ok;
	
	char 			*part_no				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	
	fp = fopen(FileName, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				part_no = strtok(temp, "^");
				printf("\nPart_NO.:%s",part_no);
				
				ifail = check_part(part_no);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	return ifail;
}


/****************************************************************************************************************
    Function:       check_part
    Description:    This function will check the part in Teamcenter and will check that part's latest revision's
					dataset, if it is present it will check for it's name reference, if not present it will write 
					the appropriate information into the file.
*****************************************************************************************************************/
int check_part(char *part_no)
{
	int				ifail 							= ITK_ok;
	int				count 							= 0;
	int				count1							= 0;
	int				nFound 							= 0;
	
	tag_t			item							= NULLTAG;
	tag_t			rev								= NULLTAG;
	tag_t			relation_CAD					= NULLTAG;
	tag_t			*dataset_CAD					= NULLTAG;
	tag_t			relation_JT						= NULLTAG;
	tag_t			*dataset_JT						= NULLTAG;
	
	char			*rev_id							= NULL;
		
	char 			*test 							= (char*)MEM_alloc(sizeof(char) * 50);
	char 			*test1 							= (char*)MEM_alloc(sizeof(char) * 50);
	char 			*test3							= (char*)MEM_alloc(sizeof(char) * 50);
	char			*final							= (char*)MEM_alloc(sizeof(char) * 50);
	
	FILE 			*output;
	FILE 			*output_JT;
	FILE 			*output_CAD;
	
	output 			= fopen("output.txt", "a+");
	output_JT 		= fopen("output_JT.txt", "a+");
	output_CAD 		= fopen("output_CAD.txt", "a+");

	ifail = ITEM_find_item(part_no, &item);
	CHECK_FAIL;
	
	ifail = ITEM_ask_latest_rev(item, &rev);
	ifail = AOM_UIF_ask_value (rev,"item_revision_id", &rev_id);
	printf("\nLatest Revision ID is:%s", rev_id);
	
	ifail = GRM_find_relation_type("IMAN_specification", &relation_CAD);
	ifail = GRM_list_secondary_objects_only(rev, relation_CAD, &count, &dataset_CAD);
	
	ifail = GRM_find_relation_type("IMAN_Rendering", &relation_JT);
	ifail = GRM_list_secondary_objects_only(rev, relation_JT, &count1, &dataset_JT);
	
	printf("\nTotal no. of datasets(CAD): %d",count);
	printf("\nTotal no. of datasets(JT): %d",count1);
	
	if(count == 0 && count1 == 0)
	{
		tc_strcpy(test, "");
		tc_strcpy(test,part_no);
		tc_strcat(test,sep);
		tc_strcat(test,rev_id);
		tc_strcat(test,sep);
		tc_strcat(test,"No_Dataset");
			
		tc_strcpy(final,test);
		
		fprintf(output,"%s\n",final);
		return 0;
	}
	else
	{
		if(count == 0 && count1 != 0)
			{
				printf("\nNo any CAD File available for this revision.%s,%s\n",part_no,rev_id);
				
				tc_strcpy(test1, "");
				tc_strcpy(test1, part_no);
				tc_strcat(test1,sep);
				tc_strcat(test1,rev_id);
				tc_strcat(test1,sep);
				tc_strcat(test1,"No CAD File");
				fprintf(output_CAD,"%s\n",test1);
				
				ifail = get_dataset_JT(count1, dataset_JT, part_no,rev_id, output_JT);
				CHECK_FAIL;
			}
			
		else if(count != 0 && count1 == 0)
			{
				printf("\nNo any JT File available for this revision.%s,%s\n",part_no,rev_id);
				
				tc_strcpy(test3, "");
				tc_strcpy(test3, part_no);
				tc_strcat(test3,sep);
				tc_strcat(test3,rev_id);
				tc_strcat(test3,sep);
				tc_strcat(test3,"No JT File");
				fprintf(output_JT,"%s\n",test3);
				
				ifail = get_dataset_CAD(count, dataset_CAD, part_no ,rev_id, output_CAD);
				CHECK_FAIL;
			}
			else
			{
				if(count != 0 && count1 != 0)
				{
					ifail = get_dataset_JT(count1, dataset_JT, part_no ,rev_id, output_JT);
					ifail = get_dataset_CAD(count, dataset_CAD, part_no ,rev_id, output_CAD);
				}
			}	
	}
	
	fclose(output_JT);
	fclose(output_CAD);
	fclose(output);
	
	MEM_free(dataset_JT);
	MEM_free(dataset_CAD);
	MEM_free(rev_id);
	return ifail;
}

/****************************************************************************************************************
    Function:       get_dataset_JT 
    Description:    This function takes item_id and rev_id as input and if dataset(JT) is attached to revision
				    then it checks for named reference if not present print it's information into the file.
*****************************************************************************************************************/
int get_dataset_JT(int count1, tag_t* dataset_JT, char* part_no, char* rev_id, FILE *output_JT)
{
	int				ifail 						= ITK_ok;
	int				i 							= 0;
	int				nFound						= 0;
	
	char			*type_jt					= NULL;
	char 			*test2						= (char*)MEM_alloc(sizeof(char) * 50);
	char			*final2						= (char*)MEM_alloc(sizeof(char) * 50);
	tag_t			*refObject					= NULL;
	
		for(i=0;i<count1;i++)
		{
			ifail = AOM_ask_value_string(dataset_JT[i], "object_type", &type_jt);
			printf("\nType of dataset(JT) is:- %s",type_jt);

			ifail = AE_ask_dataset_named_refs(dataset_JT[i], &nFound, &refObject);
			printf("\nNo. of name references are:- %d",nFound);
			
			if(nFound == 0)
			{
				tc_strcpy(test2, "");
				tc_strcpy(test2,part_no);
				tc_strcat(test2,sep);
				tc_strcat(test2,rev_id);
				tc_strcat(test2,sep);
				tc_strcat(test2,type_jt);
				tc_strcat(test2,sep);
				tc_strcat(test2,"No_NameReference");
				tc_strcpy(final2,test2);
				
				fprintf(output_JT,"%s\n",final2);
				printf("\n***********************************\n");	
			}
			MEM_free (refObject);
			MEM_free (type_jt);
		}
	MEM_free (test2);	
	MEM_free (final2);
	
	return ifail;
	
}

/****************************************************************************************************************
    Function:       get_dataset_CAD
    Description:    This function takes item_id and rev_id as input and if dataset(CAD) is attached to revision
				    then it checks for named reference if not present print it's information into the file.
*****************************************************************************************************************/
int get_dataset_CAD(int count, tag_t* dataset_CAD, char* part_no, char* rev_id, FILE *output_CAD)
{
	int				ifail 						= ITK_ok;
	int				j	 						= 0;
	int				nFound1	 					= 0;
	
	char			*type_CAD					= NULL;
	
	tag_t			*refObject1					= NULLTAG;
	char 			*test4						= (char*)MEM_alloc(sizeof(char) * 50);
	char			*final3						= (char*)MEM_alloc(sizeof(char) * 50);
	
		for(j=0;j<count;j++)
		{
			ifail = AOM_ask_value_string(dataset_CAD[j], "object_type", & type_CAD);
			printf("\nType of dataset is:- %s",type_CAD);

			ifail = AE_ask_dataset_named_refs(dataset_CAD[j], &nFound1, &refObject1); 
			printf("\nNo. of name references are:- %d",nFound1);
			
			if(nFound1 == 0)
			{
				tc_strcpy(test4, "");
				tc_strcpy(test4,part_no);
				tc_strcat(test4,sep);
				tc_strcat(test4,rev_id);
				tc_strcat(test4,sep);
				tc_strcat(test4,type_CAD);
				tc_strcat(test4,sep);
				tc_strcat(test4,"No_NameReference");
				tc_strcpy(final3,test4);
				
				fprintf(output_CAD,"%s\n",final3);
				printf("\n***********************************\n");
			}
			MEM_free (refObject1);
			MEM_free (type_CAD);
		}
	MEM_free (test4);	
	MEM_free (final3);

	
	return ifail;
}
