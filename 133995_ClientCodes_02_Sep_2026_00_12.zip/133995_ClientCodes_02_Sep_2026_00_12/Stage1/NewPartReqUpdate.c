/*=============================================================================
                Copyright (c) 2003-2005 UGS Corporation
                   Unpublished - All Rights Reserved
===============================================================================
File description:

    Filename: Extract_ItemID
    USAGE:    Extract_ItemID -u=username -p=password -g=groupname"

=================================================================================*/
#include <tc/tc.h>
#include <vm/vms.h>
#include <tc/emh.h>
#include <pom/pom/pom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <fclasses/tc_string.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/tctype.h>
#include <form/form.h>
#include <epm/cr.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <tccore/idcxt.h>
#include <tccore/idfr.h>
#include <tccore/idcxt_errors.h>
#include <tccore/part.h>
#include <tccore/tctype.h>

static void handle_ifail(char *file, int line);

#define WHITESPACE " \t"
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;



extern void checkerror(int ifail,char *msg)
{
    if(ifail==ITK_ok)
    {
        printf("\nSuccess in  : : < %s >",msg);
    }
    else
    {
        int n_ifails;
        int inx;
        const int *severities;
        const int *ifails;
        const char **texts;

        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );

        for ( inx = 0; inx < n_ifails; inx ++ )
        {
            printf("\n Error is ......... <%s>", texts[inx]);
        }
    }
}


int ITK_user_main(int argc,char *argv[])
{

    int ifail = ITK_ok;
   
    char*  item_id		= NULL;
    char*  tmlpartnumber	= NULL;
    char*  temp_tmlpartnumber	= NULL;

	
	int n_tags_found=0;
	int n_revtags_found,p1=0;

    const char* argstring1 = NULL;
    const char* argstring2 = NULL;
	const char* u = NULL;
    const char* p = NULL;
    const char* g = NULL;



	tag_t	*npr_tagitems		= NULLTAG;
	tag_t	new_part_req_tag	= NULLTAG;


	const char
        *attrs[2] = {"item_id","object_type"},
        *values[2]	= {"*","*"};

	u = ITK_ask_cli_argument( "-u=");
	p = ITK_ask_cli_argument( "-p=");
	g = ITK_ask_cli_argument( "-g=");
	argstring1 = ITK_ask_cli_argument( "-i=");
	argstring2 = ITK_ask_cli_argument( "-n=");
	//ITK_set_journalling( TRUE );
	//ITK_initialize_text_services (0);
	//ITK_auto_login();

	if (ITK_init_module(u,p,g) == ITK_ok )
	{
		printf("\n login successfully!!!!");fflush(stdout);
		temp_tmlpartnumber=(char *) MEM_alloc(200);

		printf("\n New Part Req ===>[%s]", argstring1);fflush(stdout);
		printf("\n TML Part Number ===>[%s]", argstring2);fflush(stdout);
		values[0] = argstring1;
		values[1] = "New Part Request";
		ITEM_find_items_by_key_attributes(1, attrs, values, &n_tags_found, &npr_tagitems);
		printf("\n n_tags_found [%d]*******",n_tags_found);fflush(stdout);
		if(n_tags_found>0)
		{
			new_part_req_tag = npr_tagitems[0];
			AOM_ask_value_string(new_part_req_tag,"t5_NwTmlPtNo",&tmlpartnumber);
			printf("\n tmlpartnumber ===>[%s]", tmlpartnumber);fflush(stdout);
			if(tmlpartnumber!=NULL)
			{
				tc_strcpy(temp_tmlpartnumber,tmlpartnumber);
				tc_strcat(temp_tmlpartnumber,",");
				tc_strcat(temp_tmlpartnumber,argstring2);
			}
			else
			{
				tc_strcpy(temp_tmlpartnumber,argstring2);
			}
			printf("\n temp_tmlpartnumber ===>[%s]", temp_tmlpartnumber);fflush(stdout);
			AOM_lock(new_part_req_tag);
			AOM_set_value_string(new_part_req_tag,"t5_NwTmlPtNo",temp_tmlpartnumber);
			AOM_set_value_string(new_part_req_tag,"t5_NwLCState","LcsNwAppr");
			AOM_save_with_extensions (new_part_req_tag);
			AOM_unlock(new_part_req_tag);
		}
		MEM_free(npr_tagitems);
		
	}
return ifail;
	
}



static void handle_ifail( char * file, int line )

/*  Prints out the full error stack.
**
*/
{
    int  i, n_errors;
    const int *severities;
    const int *ifails;
    const char **messages;
    EMH_ask_errors( &n_errors, &severities, &ifails, &messages );
    printf( "\nERROR: (%s:%d)", file, line);
    for (i = 0; i < n_errors; i++)
    {
        printf( "\n    %6d: %s\n", ifails[i], messages[i] );
    }
    exit( EXIT_FAILURE );
}
