/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                :   Vivek Patil
*  Module                :   EBOM  
*  Code                  :   CPartVAQRev.c
*  Created on			 :   30th Jul 2024
*
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/
#define TE_MAXLINELEN  128
#include  <time.h>
#include <fclasses/tc_string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tcinit/tcinit.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define Debug TRUE


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string = NULL;      \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
		EMH_ask_error_text (stat, &err_string);                 \
		printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
		printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
		if(err_string) MEM_free(err_string);                                \
		exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}														\
	
	
int ifail = ITK_ok;		
int iFail = ITK_ok;
char* sError = NULL;

char* c_OriginalFileName = NULL;

int tm_Analyse_Dataset (tag_t, char*);
int tm_Download_PDF (tag_t, char*);
int tm_Download_JT  (tag_t, char*);
int tm_build_report (tag_t ,char*);

static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}



int ITK_user_main(int argc, char *argv[])
{
	
	
	
	char* userid			= ITK_ask_cli_argument("-u=");
	char* password 			= ITK_ask_cli_argument("-pf=");
	char* group 			= ITK_ask_cli_argument("-g=");
	char* PartNo 			= ITK_ask_cli_argument("-Part=");
	//char* PartNo = "547632108705";
	char *cError = NULL;
	char *c_Relestat = NULL;
	char *c_revID = NULL;
	char *c_LatrevID = NULL;
	char *c_ItemID = NULL;
	char *c_LatRevStat = NULL;
	
	
	int i_RevCount = 0;
	int i = 0;
	
	tag_t t_item = NULLTAG ;
	tag_t t_LatRlsRev = NULLTAG ;
	tag_t* t_revs = NULLTAG ;

	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		EMH_ask_error_text(ifail, &cError);
		printf ("\n --xxxxxxxxxxxxx----Login Error---xxxxxxxx-----\n %s \n --xxxxxxxxxxxxx----Login Error---xxxxxxxx-----", cError);fflush(stdout);
		return ifail;
	}
	else
	{
		printf ("\n ====================LOGIN SUCCESSFUL==================== LOGIN SUCCESSFUL==================== \n");	fflush(stdout);
	}
	
	ITK_CALL(ITEM_find_item(PartNo,&t_item));
	ITK_CALL(ITEM_list_all_revs(t_item,&i_RevCount,&t_revs));
	
	for(i=(i_RevCount-1) ; i >= 0; i--)
	{
		ITK_CALL(AOM_UIF_ask_value(t_revs[i],"release_status_list",&c_Relestat));
		ifail = AOM_ask_value_string(t_revs[i],"item_revision_id",&c_revID);
		
		if( c_Relestat!= NULL )
		{
			//printf("\n Rev ID = %s | Release status =%s", c_revID, c_Relestat);
			if((tc_strstr(c_Relestat,"T5_LcsErcRlzd")!= NULL) ||(tc_strstr(c_Relestat,"ERC Released") != NULL))
			{
				t_LatRlsRev= t_revs[i];
				ifail = AOM_ask_value_string(t_LatRlsRev,"item_id",&c_ItemID);
				ifail = AOM_ask_value_string(t_LatRlsRev,"item_revision_id",&c_LatrevID);
				ITK_CALL(AOM_UIF_ask_value(t_LatRlsRev,"release_status_list",&c_LatRevStat));
				printf("\n ============================================================================================================");fflush(stdout);
				printf("\n Latest ERC_Released Revision FOUND = %s;%s | RELEASE STATUS = %s", c_ItemID,c_revID, c_LatRevStat);fflush(stdout);
				printf("\n ============================================================================================================");fflush(stdout);
				
				tm_Analyse_Dataset(t_LatRlsRev, c_ItemID);
				
				break;
			}
		}
		else
		{
			printf("\n\t ERROR:: BLANK STATUS on %s;%s   \t Hence, EXIT FROM CODE",PartNo,c_revID);fflush(stdout);
			exit(0);
		}
	}
	
	tm_build_report(t_LatRlsRev, c_ItemID);

	printf ("\n\n --XXXXXXXXXXXXXXX----END OF CODE---XXXXXXXX-------XXXXXXXXXXXXX----END OF CODE---XXXXXXXX-----");fflush(stdout);
	
	ifail = ITK_exit_module(true);
	return ifail;
}

int tm_Analyse_Dataset(tag_t t_LatRlsRev, char* c_ItemID)
{
	tag_t t_Render_Rel = NULLTAG;
	tag_t t_Dataset = NULLTAG;
	tag_t t_objType = NULLTAG;
	tag_t* t_Dsets = NULLTAG;
	
	int n_attchs_JT = 0;
	int i = 0;
	int Direct_Model_flag = 0;
	//char c_TypeName[TCTYPE_name_size_c+1];
	char* c_TypeName = NULL;
	
	//printf("\n\n INSIDE Vivek_P function ---->>  tm_Analyse_Dataset <<-----");fflush(stdout);
	ITK_CALL(GRM_find_relation_type("IMAN_Rendering",&t_Render_Rel));
	ITK_CALL(GRM_list_secondary_objects_only(t_LatRlsRev,t_Render_Rel,&n_attchs_JT,&t_Dsets));
	
	printf("\n Total Rendering Relation Count = %d \n\n",n_attchs_JT);fflush(stdout);
	
	
	for (i= 0; i < n_attchs_JT; i++)
	{
		//printf("\n Inside loop ..............");fflush(stdout);
		t_Dataset = t_Dsets[i];
		
		ITK_CALL (TCTYPE_ask_object_type(t_Dataset,&t_objType));
		ITK_CALL (TCTYPE_ask_name2(t_objType,&c_TypeName));
		
		//printf("\n Type Name =  %s ", c_TypeName);
		
		if(tc_strcmp(c_TypeName, "DirectModel") == 0)
		{
			// printf("\n\n --------------------------------------------------- ");fflush(stdout);
			printf("\n------------------------  Direct Model JT Dataset found ------------------------ ");fflush(stdout);
			//Direct_Model_flag = 1;
			tm_Download_JT(t_Dataset, c_ItemID);
			printf("\n\n ");fflush(stdout);
			
		}
		else if(tc_strcmp(c_TypeName, "PDF") == 0)
		{
			// printf("\n\n --------------------------------------------------- ");fflush(stdout);
			printf("\n------------------------ PDF Dataset found ------------------------ ");fflush(stdout);
			//Direct_Model_flag = 1;
			tm_Download_PDF(t_Dataset, c_ItemID);
			//printf("\n ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ \n\n ");fflush(stdout);
			printf("\n\n ");fflush(stdout);
		}
		else
		{
			printf("\n Continue ");
			continue;
		}			
		
	}
	
	return 0;
}

int tm_Download_JT(tag_t t_Dataset, char* c_ItemID)
{
	
	printf("\nVivek_P Inside Function tm_Download_JT ------->>>>>>>>>>>>>>>>>>>>> ");fflush(stdout);
	int i_JT_Ref_Count = 0;
	int j =0;
	int status_system = 0;
	
	//char refname[AE_reference_size_c + 1];
	
//	AE_reference_type_t reftype;
	
	
	// long byte1   =0;
	tag_t* t_NamedRefJT = NULLTAG;

	

	//char *c_JT_fileName = NULL;
	
	char *c_DownloadJT_Path = NULL;
	c_DownloadJT_Path =(char *) MEM_alloc(200);
	
	char *cItemID = NULL;
	cItemID =(char *) MEM_alloc(20);
	
	char command[200];
	
	
	
	ITK_CALL(AE_ask_dataset_named_refs(t_Dataset,&i_JT_Ref_Count,&t_NamedRefJT));
	printf("\nNamed Ref Count in Direct MODEL = %d",i_JT_Ref_Count);fflush(stdout);
	if(i_JT_Ref_Count > 0)
	{
		for(j=0 ; j < i_JT_Ref_Count ; j++)
		{
			
			// ITK_CALL(AOM_ask_value_string(t_NamedRefJT[j],"file_name",&c_JT_fileName));
			// printf ("\n JT_FileName = %s",c_JT_fileName);
			ITK_CALL(AOM_ask_value_string(t_NamedRefJT[j],"original_file_name",&c_OriginalFileName));
			printf ("\nOrginal FileName = %s",c_OriginalFileName);fflush(stdout);
			// ITK_CALL( AOM_UIF_ask_value(t_NamedRefJT[j],"file_size",&byte1));   
			// printf("\nbyte1 size is --------- [%s]\n",byte1); fflush(stdout);
			
		
			if(t_NamedRefJT[j] != NULLTAG)
			{
				
				if(tc_strstr(c_OriginalFileName,".jt")!=NULL)
				{
					tc_strcpy(cItemID,"");
					tc_strcat(cItemID,c_ItemID);
					tc_strcat(cItemID,".jt");
					
					//c_DownloadJT_Path = "/tmp/547632108705/InputData/547632108705.jt";
					tc_strcpy(c_DownloadJT_Path,"");
					tc_strcat(c_DownloadJT_Path,"/tmp/");
					tc_strcat(c_DownloadJT_Path, c_ItemID);    					// Append Item_ID
					tc_strcat(c_DownloadJT_Path, "/InputData/");
					tc_strcat(c_DownloadJT_Path, cItemID);
					
					sprintf(command,"/user/cvprod/shells/DownloadJTPDF/JT_DownloadPath.sh %s ",c_ItemID);
					TC_write_syslog("Command = %s\n",command);
					status_system = system(command);
					if(status_system == -1)
					{
						printf("\n\n\t --xx---Failed to execute Shell  < JT Download > --xx---\n");fflush(stdout);
					}
					else
					{
						
						printf("\nShell Executed SUCCESSFUL --->> JT Download  %s",c_ItemID);fflush(stdout);
						printf("\n\n\t ***************************************************************************************************** ");fflush(stdout);
						printf("\n\t EXPORTING FILE AT-->> %s", c_DownloadJT_Path);fflush(stdout);
						iFail = IMF_export_file(t_NamedRefJT[j], c_DownloadJT_Path);
						if(iFail != ITK_ok)
						{
							EMH_ask_error_text(iFail, &sError);
							printf("\n ----xxx-----xxx----- \n Unable to EXPORT Named Ref \n\t ERROR - %s \n ----xxx-----xxx----- ",sError);	fflush(stdout);
						}
						else
						{
							
							printf("\n\n\t [JT] Exported Successfully to --> %s ",c_DownloadJT_Path);fflush(stdout);
							printf("\n\t ***************************************************************************************************** \n");fflush(stdout);
						}
						}
					
					
				}
				
				
			} // END if(t_NamedRefObj)
		}
	}
	else
	{
		printf("\nNamed Ref Count in Direct MODEL = [%d] ________________Hence, EXIT",i_JT_Ref_Count);fflush(stdout);
		exit(0);
	}
	return 0;
}

int tm_Download_PDF(tag_t t_Dataset, char* c_ItemID)
{
	printf("\nVivek_P Inside Function tm_Download_PDF ------->>>>>>>>>>>>>>>>>>>>> ");fflush(stdout);
	
	int i_PDF_Ref_Count = 0;
	int j =0;
	int status_system = 0;
	
	 long byte1   =0;
	tag_t* t_NamedRefPDF = NULLTAG;

	char* c_OriginalFileName = NULL;

	//char *c_PDF_fileName = NULL;
	
	char *c_Download_PDF_Path = NULL;
	c_Download_PDF_Path =(char *) MEM_alloc(200);
	
	char *cItemID = NULL;
	cItemID =(char *) MEM_alloc(20);
	
	char command[200];
	
	
	
	ITK_CALL(AE_ask_dataset_named_refs(t_Dataset,&i_PDF_Ref_Count,&t_NamedRefPDF));
	printf("\nNamed Ref Count in PDF = %d",i_PDF_Ref_Count);fflush(stdout);
	if(i_PDF_Ref_Count > 0)
	{
		for(j=0 ; j < i_PDF_Ref_Count ; j++)
		{
			
			// ITK_CALL(AOM_ask_value_string(t_NamedRefPDF[j],"file_name",&c_PDF_fileName));
			// printf ("\n\t JT_FileName = %s",c_PDF_fileName);
			ITK_CALL(AOM_ask_value_string(t_NamedRefPDF[j],"original_file_name",&c_OriginalFileName));
			printf ("\nOrginal FileName = %s",c_OriginalFileName);fflush(stdout);
			// ITK_CALL( AOM_UIF_ask_value(t_NamedRefPDF[j],"file_size",&byte1));   
			// printf("\nbyte1 size is --------- [%s]\n",byte1); fflush(stdout);
			
		
			if(t_NamedRefPDF[j] != NULLTAG)
			{
				
				if(tc_strstr(c_OriginalFileName,".pdf")!=NULL)
				{
					tc_strcpy(cItemID,"");
					tc_strcat(cItemID,c_ItemID);
					tc_strcat(cItemID,".pdf");
					
					//c_Download_PDF_Path = "/tmp/547632108705/InputData/547632108705.jt";
					tc_strcpy(c_Download_PDF_Path,"");
					tc_strcat(c_Download_PDF_Path,"/tmp/");
					tc_strcat(c_Download_PDF_Path, c_ItemID);    					// Append Item_ID
					tc_strcat(c_Download_PDF_Path, "/InputData/");
					tc_strcat(c_Download_PDF_Path, cItemID);
					
					sprintf(command,"/user/cvprod/shells/DownloadJTPDF/PDF_DownloadPath.sh %s ",c_ItemID);
					TC_write_syslog("Command = %s\n",command);
					status_system = system(command);
					if(status_system == -1)
					{
						printf("\n\n\t --xx---Failed to execute < /user/uaprodtrl/shells/DownloadJTPDF/PDF_DownloadPath.sh > --xx---\n");fflush(stdout);
					}
					else
					{
						
						printf("\nShell Executed SUCCESSFUL --->> PDF Download %s",c_ItemID);fflush(stdout);
						printf("\n\n\t ************************************************************************************** ");fflush(stdout);
						printf("\n\t EXPORTING FILE AT-->> %s", c_Download_PDF_Path);fflush(stdout);
						iFail = IMF_export_file(t_NamedRefPDF[j], c_Download_PDF_Path);
						if(iFail != ITK_ok)
						{
							EMH_ask_error_text(iFail, &sError);
							printf("\n ----xxx-----xxx----- \n Unable to EXPORT Named Ref \n\t ERROR - %s \n ----xxx-----xxx----- ",sError);	fflush(stdout);
						}
						else
						{
							
							printf("\n\n\t [PDF] Exported Successfully to --> %s ",c_Download_PDF_Path);fflush(stdout);
							printf("\n\t ************************************************************************************** \n");fflush(stdout);
						}
					}
					
					
				}
				
				
			} // END if(t_NamedRefObj)
		}
	}
	else
	{
		printf("\nNamed Ref Count in PDF = [%d]  ________________Hence, EXIT",i_PDF_Ref_Count);fflush(stdout);
		
		exit(0);
	}
	
return 0;
	
}


int tm_build_report(tag_t t_LatRlsRev, char* c_ItemID)
{
	
	char* c_RevID = NULL;
	char* c_ObjDesc = NULL;
	char* c_revision = NULL;
	char* c_Seq = NULL;
	char* c_Material = NULL;
	char* c_EnvDim = NULL;
	char* c_Weight = NULL;
	char* c_VendrName = NULL;
	
	char command[200];
	int status_system = 0;
	
	printf("\nVivek_P Building Report Initiated ------->>>>>>>>>>>>>>>>>>>>> "); fflush(stdout);
	
	sprintf(command,"/user/cvprod/shells/DownloadJTPDF/CSV_ReportDownload.sh %s ",c_ItemID);
	TC_write_syslog("Command = %s\n",command);
	status_system = system(command);
	if(status_system == -1)
	{
		 printf("\n\n\t --xx---Failed to execute shell < CSV File Creation > --xx---\n");fflush(stdout);
	}
	else
	{
		printf("\nShell Executed SUCCESSFUL --->> CV Report %s",c_ItemID);fflush(stdout);
	}
	
	FILE *fprpt = NULL;
	char * filename = NULL;
	filename =(char *) MEM_alloc(150);
	
	char *Filepath = NULL;
	Filepath =(char *) MEM_alloc(200);
	
	tc_strcpy(Filepath,"");
	tc_strcat(Filepath,"/tmp/");
	tc_strcat(Filepath,c_ItemID);
	tc_strcat(Filepath,"/OutputData/");
	tc_strcat(Filepath,c_ItemID);
	tc_strcat(Filepath,".csv");
		
	printf("\n\n\t CSV FILEPATH  =  %s \n\n -",Filepath);	fflush(stdout);
	fprpt	 =	fopen(Filepath,"w");
	if (fprpt == NULL)
	{
		printf("\n\t ----xxxxxxx-ERROR-->> fprpt == NULL <<----xxxx----ERROR--");fflush(stdout);
		return ITK_ok;
	}
	else
	{
		printf("\n\nCSV File Opened");fflush(stdout);	
	}
	 ITK_CALL(AOM_ask_value_string(t_LatRlsRev,"item_revision_id", &c_RevID));
	 ITK_CALL(AOM_UIF_ask_value(t_LatRlsRev,"sequence_id", &c_Seq));
	 ITK_CALL(AOM_ask_value_string(t_LatRlsRev,"object_desc", &c_ObjDesc));
	 
	 c_revision = tc_strtok(c_RevID,";");
	 
	 
	ITK_CALL(AOM_ask_value_string(t_LatRlsRev,"t5_Material", &c_Material));
	ITK_CALL(AOM_ask_value_string(t_LatRlsRev,"t5_EnvelopeDimensions", &c_EnvDim));
	ITK_CALL(AOM_UIF_ask_value(t_LatRlsRev,"t5_Weight", &c_Weight));
	ITK_CALL(AOM_ask_value_string(t_LatRlsRev,"t5_VendorName", &c_VendrName));
	if(c_VendrName == NULL)
	{
		tc_strcpy(c_VendrName,"NULL");
	}
	
	printf("\n\n -------------------------- OutputData -------------------------- \n");fflush(stdout);
	printf("\nOriginal_File_Name=%s\nitem_id=%s\nrevision_id=%s\nsequence_id=%s\nDescription=%s\nPart Material=%s\nEnvelope Dimensions=%s\nWeight=%s\nVendor Name=%s",c_OriginalFileName,c_ItemID,c_revision,c_Seq,c_ObjDesc,c_Material,c_EnvDim,c_Weight,c_VendrName);fflush(stdout);
	fprintf(fprpt,"%s,%s,%s,%s,%s,%s,%s,%s,%s",c_OriginalFileName,c_ItemID,c_revision,c_Seq,c_ObjDesc,c_Material,c_EnvDim,c_Weight,c_VendrName);fflush(fprpt);
	printf("\n -------------------------- OutputData -------------------------- \n");fflush(stdout);
	
	fclose(fprpt);
	printf("\n-CSV File Closed-x-");fflush(stdout);
	return 0;
	
}