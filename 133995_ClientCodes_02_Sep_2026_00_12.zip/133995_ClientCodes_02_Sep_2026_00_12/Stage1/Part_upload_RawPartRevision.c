/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Ketan Bhut
*  Module		 :   Raw Part Upload
*  Code			 :   ERCStdPartUpload.c.c
*  Created on	 :   August 10, 2023
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

static int validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day ,
                                    &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

    return retcode;
}




int convertDate(char* date,char* rDate)
{
	int status;

}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		Monthas;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char*	strDay;
	char*	newCurrentDate;
	char*	strMon;
	char*	strYear;
	char	DateS[20];
	char* cMonth ;
	char CCMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	

	newCurrentDate=NULL;
	newCurrentDate=(char *) MEM_alloc(100);
	tc_strcpy(newCurrentDate,DatetoConvert);

    strYear =  strtok(newCurrentDate,"/"); //1
    cMonth  =  strtok(NULL,"'/'"); //2
    strDay  =  strtok(NULL,"'/'"); //3
    Monthas =  atoi(cMonth);
	getMonth(Monthas,CCMonth);

	printf("\n strYear:%s\n",strYear);fflush(stdout);
	printf("\n CCMonth:%s\n",CCMonth);fflush(stdout);
	printf("\n strDay:%s\n",strDay);fflush(stdout);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,CCMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);fflush(stdout);
}


static date_t TML_token_to_date(char *str )
{
	date_t   date		  = NULLDATE;

	int      month      = 0;          /* Month */
	int      day        = 0;          /* Day */
	int      year       = 0;          /* Year */
	int      hour       = 0;          /* Hour */
	int      minute     = 0;          /* Minutes */
	int      second     = 0;          /* Seconds */

	int ifail=0;

	//printf("\n tc_strlen(str) :%d %s",tc_strlen(str),str);fflush(stdout);

	printf("\n Debugging ==> %s \n",str);fflush(stdout);

	if(tc_strlen(str)>0)
	{
		//printf("\n Debugging ==> 0008999 \n");fflush(stdout);
		//sscanf_s( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		//scanf("%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		sscanf( str , "%d/%d/%d-%d:%d:%d" , &year , &month ,&day , &hour , &minute , &second);
		month--;

		date.month = month;
		date.day   = day;
		date.year  = year;
		date.hour  = hour;
		date.minute= minute;
		date.second= second;
		printf("\n month ==>[%d]",month);fflush(stdout);
		printf("\n day ==>[%d]",day);fflush(stdout);
		printf("\n year ==>[%d]",year);fflush(stdout);
		printf("\n hour ==>[%d]",hour);fflush(stdout);
		printf("\n minute ==>[%d]",minute);fflush(stdout);

	}
	return date;
}

int MM_Change_Creation_Date(tag_t revTag,char* creation_date, char* mod_date)
{
	printf("\n Inside MM_Change_Creation_Date \n");fflush(stdout);

	int		status;
	int		ifail		= 0;

	date_t   crtndate	= NULLDATE;
	date_t   mdfcndate	= NULLDATE;

	tag_t	mod_datetag	= NULLTAG;

	char* objTyp		 = NULL;

	date_t dcreation_date;
	date_t dLast_mod_date;
	date_t *apl_last_md_dt_cpy = NULL;

	char* cCreation_date = NULL;
	char* cLast_mod_date = NULL;
	
	ITK_CALL(AOM_ask_value_string(revTag,"object_type",&objTyp));
	printf("\n objTyp is ==> %s\n",objTyp); fflush(stdout);

	printf("\n creation_date [%s]\n",creation_date);fflush(stdout);
	printf("\n mod_date [%s] \n",mod_date);fflush(stdout);

	crtndate = TML_token_to_date(creation_date);
	mdfcndate = TML_token_to_date(mod_date);

	//printf("\n creation_date [%s]\n",crtndate);fflush(stdout);
	//printf("\n mod_date [%s] \n",mdfcndate);fflush(stdout);

	//ITK_CALL(AOM_ask_value_string(revTag,"object_type",&objTyp));
	//printf("\n objTyp is -->%s\n",objTyp); fflush(stdout);

	if(DATE_IS_NULL(crtndate) == 0)
	{
		printf("\n Ketan 1 \n");fflush(stdout);
		ITK_CALL(AOM_refresh(revTag,true));
		ITK_CALL(POM_set_creation_date(revTag,crtndate));
		ITK_CALL(AOM_save_without_extensions(revTag));
		ITK_CALL(AOM_refresh(revTag,true));
	}
	if(DATE_IS_NULL(mdfcndate) == 0)
	{
		printf("\n Ketan 2 \n");fflush(stdout);
		ITK_CALL(AOM_refresh(revTag,true));
		ITK_CALL(POM_set_modification_date(revTag,mdfcndate));
		ITK_CALL(AOM_save_without_extensions(revTag));
		if(tc_strcmp(objTyp,"Design Revision")==0)
		{
			ITK_CALL(AOM_refresh(revTag,true));
			ITK_CALL(POM_attr_id_of_attr("date_released", "WorkspaceObject", &mod_datetag));
			ITK_CALL(POM_set_attr_date(1,&revTag,mod_datetag,mdfcndate));
			ITK_CALL(AOM_save_without_extensions(revTag));
		}
		ITK_CALL(AOM_refresh(revTag,true));
	}
	
	printf("\n After Change on object [%s] \n",objTyp);fflush(stdout);
	ITK_CALL(AOM_ask_value_date(revTag,"creation_date",&dcreation_date));
	ITK_date_to_string(dcreation_date, &cCreation_date);
	printf("\n cCreation_date ==> %s \n",cCreation_date);fflush(stdout);
	
	//ITK_CALL(AOM_lock(revTag));
	//apl_last_md_dt_cpy = (date_t *)MEM_alloc(sizeof(date_t)*2);
	//apl_last_md_dt_cpy[0] = mdfcndate;
	//
	//ITK_CALL(AOM_set_value_date(revTag,"last_mod_date",apl_last_md_dt_cpy));
	//ITK_CALL(AOM_save_without_extensions(revTag));
	//ITK_CALL(AOM_unlock(revTag));

	ITK_CALL(AOM_ask_value_date(revTag,"last_mod_date",&dLast_mod_date));
	ITK_date_to_string(dLast_mod_date, &cLast_mod_date);
	printf("\n cLast_mod_date ==> %s \n",cLast_mod_date);fflush(stdout);


	return ITK_ok;
}




int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}



int setAttributesOnDesign(tag_t* item,char* Uom)
{
	printf("\n Inside setAttributesOnDesign \n");fflush(stdout);
	
	int		status;
	int		ifail	=0;

	char* ent_uom=NULL;
	tag_t unit_of_measure=NULLTAG;

	ent_uom=(char *) MEM_alloc(10 * sizeof(char *));

	ITK_CALL(AOM_lock(*item));

	if(strcmp(Uom,"1")==0)
	{
		strcpy(ent_uom,ONE);
	}
	else if(strcmp(Uom,"2")==0)
	{
		strcpy(ent_uom,TWO);
	}
	else if(strcmp(Uom,"3")==0)
	{
		strcpy(ent_uom,THREE);
	}
	else if(strcmp(Uom,"4")==0)
	{
		strcpy(ent_uom,FOUR);
	}
	else if(strcmp(Uom,"5")==0)
	{
		strcpy(ent_uom,FIVE);
	}
	else if(strcmp(Uom,"6")==0)
	{
		strcpy(ent_uom,SIX);
	}
	else if(strcmp(Uom,"7")==0)
	{
		strcpy(ent_uom,SEVEN);
	}
	else if(strcmp(Uom,"8")==0)
	{
		strcpy(ent_uom,EIGHT);
	}
	else
	{
		strcpy(ent_uom,"-");
	}

	ITK_CALL(UOM_find_by_symbol(ent_uom,&unit_of_measure));
	if(ITK_ok != (ifail =ITEM_set_unit_of_measure(*item, unit_of_measure)))
	{
		return ifail;
	}

	ITK_CALL ( AOM_set_value_string(*item,"t5_uom",ent_uom));

	ITK_CALL(AOM_save_without_extensions(*item));
	ITK_CALL(AOM_unlock(*item));
}

int setAttributesOnDesignRevision(tag_t* rev,char* Part_MakeBuy,char* Part_SLOC,char* Part_Type,char* Drawing_Indicator,char* Material_In_drawing,char* EnvelopeDimensions,
char* Weight,char* MThickness,char* StdPartIndicator,char* SpareInd,char* CMVRCertificationReqd,char* ModelIndS,char* ColourIndS,char* DeignOwnUnitS,char* t5HomologationReqdS,char* mod_desc,char* DrawingNoS)
{
	printf("\n Inside setAttributesOnDesignRevision \n");fflush(stdout);

	int status;

	double dweight=0;

	int     ifail               = ITK_ok;

	ITK_CALL(AOM_lock(*rev));

	printf("\n Part_MakeBuy ==> %s\n",Part_MakeBuy);fflush(stdout);
	printf("\n Part_SLOC ==> %s\n",Part_SLOC);fflush(stdout);

	printf("\n Setting the value for CS... \n");fflush(stdout);
	//ITK_CALL ( AOM_set_value_string(*rev,GenPlantCS,Part_MakeBuy));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator",Part_MakeBuy));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_CarMakeBuyIndicator",Part_MakeBuy));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator",Part_MakeBuy));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_JsrMakeBuyIndicator",Part_MakeBuy));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_JdlMakeBuyIndicator",Part_MakeBuy));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_LkoMakeBuyIndicator",Part_MakeBuy));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PnrMakeBuyIndicator",Part_MakeBuy));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",Part_MakeBuy));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator",Part_MakeBuy));
	ITK_CALL ( AOM_set_value_string(*rev,"t5_PunUVMakeBuyIndicator",Part_MakeBuy));
	
	
	printf("\n Setting the value for Store Location... \n");fflush(stdout);
	//ITK_CALL ( AOM_set_value_string(*rev,getPlantStore,Part_SLOC));
	
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator",Part_SLOC));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_JsrMakeBuyIndicator",Part_SLOC));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_JdlMakeBuyIndicator",Part_SLOC));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_LkoMakeBuyIndicator",Part_SLOC));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_PnrMakeBuyIndicator",Part_SLOC));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",Part_SLOC));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator",Part_SLOC));
	//ITK_CALL ( AOM_set_value_string(*rev,"t5_PunUVMakeBuyIndicator",Part_SLOC));

	ITK_CALL(AOM_save_without_extensions(*rev));
	ITK_CALL(AOM_unlock(*rev));
	ITK_CALL(AOM_lock(*rev));

	printf("\n Part_Type ==> %s\n",Part_Type);fflush(stdout);
	if(Part_Type!=NULL)
	{
		if (tc_strcmp(Part_Type,"D")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","D"));
		}
		if (tc_strcmp(Part_Type,"A")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","A"));
		}
		if (tc_strcmp(Part_Type,"C")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","C"));
		}
		if (tc_strcmp(Part_Type,"VC")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","VC"));
		}
		if (tc_strcmp(Part_Type,"V")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","V"));
		}
		if (tc_strcmp(Part_Type,"T")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","T"));
		}
		if (tc_strcmp(Part_Type,"VCCR")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","VCCR"));
		}
		if (tc_strcmp(Part_Type,"G")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","G"));
		}
		if (tc_strcmp(Part_Type,"R")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","R"));
		}
		if (tc_strcmp(Part_Type,"SA")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","SA"));
		}
		if (tc_strcmp(Part_Type,"SP")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","SP"));
		}
		if (tc_strcmp(Part_Type,"PE")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","PE"));
		}
		if (tc_strcmp(Part_Type,"P")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","P"));
		}
		if (tc_strcmp(Part_Type,"M")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","M"));
		}
		if (tc_strcmp(Part_Type,"CM")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","CM"));
		}
		if (tc_strcmp(Part_Type,"DC")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","DC"));
		}
		if (tc_strcmp(Part_Type,"DA")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","DA"));
		}
		if (tc_strcmp(Part_Type,"IFD")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","IFD"));
		}
		if (tc_strcmp(Part_Type,"CR TPL")==0)
		{
			ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","CR TPL"));
		}
	}
	ITK_CALL(AOM_save_without_extensions(*rev));
	ITK_CALL(AOM_refresh(*rev,true));
	ITK_CALL(AOM_unlock(*rev));

	printf("\n Drawing_Indicator ==> %s\n",Drawing_Indicator);fflush(stdout);
	printf("\n Material_In_drawing ==> %s\n",Material_In_drawing);fflush(stdout);

	ITK_CALL(AOM_lock(*rev));
	if(Drawing_Indicator!=NULL) 
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingInd",Drawing_Indicator));
	}
	if((Material_In_drawing!=NULL)||(strcmp(Material_In_drawing," ")!=0)) 
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_Material",Material_In_drawing));
	}

	printf("\n EnvelopeDimensions ==> %s\n",EnvelopeDimensions);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_EnvelopeDimensions",EnvelopeDimensions));

	printf("\n Weight ==> %s\n",Weight);fflush(stdout);
	dweight=atof(Weight);
	ITK_CALL ( AOM_set_value_double(*rev,"t5_Weight",dweight));

	printf("\n MThickness ==> %s\n",MThickness);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_MThickness",MThickness));

	printf("\n StdPartIndicator ==> %s\n",StdPartIndicator);fflush(stdout);
	if(strcmp(StdPartIndicator,"-")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_StdPartIndicator",false));
	}
	else if(strcmp(StdPartIndicator,"+")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_SpareInd",true));
	}

	printf("\n SpareInd ==> %s\n",SpareInd);fflush(stdout);
	if(strcmp(SpareInd,"-")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_SpareInd",false));
	}
	else if(strcmp(SpareInd,"+")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_SpareInd",true));
	}

	printf("\n CMVRCertificationReqd ==> %s\n",CMVRCertificationReqd);fflush(stdout);
	if(strcmp(CMVRCertificationReqd,"-")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_CMVRCertificationReqd",false));
	}
	else if(strcmp(CMVRCertificationReqd,"+")==0)
	{
		ITK_CALL ( AOM_set_value_logical(*rev,"t5_CMVRCertificationReqd",true));
	}

	printf("\n ModelIndS ==> %s\n",ModelIndS);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ModelIndicator",ModelIndS));

	printf("\n ColourIndS ==> %s\n",ColourIndS);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_ColourInd",ColourIndS));

	printf("\n DeignOwnUnitS ==> %s\n",DeignOwnUnitS);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DsgnOwn",DeignOwnUnitS));

	printf("\n t5HomologationReqdS ==> %s\n",t5HomologationReqdS);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_HomologationReqd",t5HomologationReqdS));

	printf("\n mod_desc ==>%s\n",mod_desc);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc));

	printf("\n DrawingNoS ==>%s\n",DrawingNoS);fflush(stdout);
	ITK_CALL ( AOM_set_value_string(*rev,"t5_DrawingNo",DrawingNoS));
	
	ITK_CALL(AOM_save_without_extensions(*rev));
	ITK_CALL(AOM_unlock(*rev));

	
		
	

}

/*******MAIN FUNCTION************/

extern int ITK_user_main (int argc, char ** argv )
{
   
	logical isCheckOut=false;
	FILE* fp						= NULL;
	FILE* fperror					= NULL;
	FILE* fp_partStampingList		= NULL;
	FILE* fp_Efferror				= NULL;

	char*	inputline				= NULL;
	char*	inputpartline			= NULL;
	char*	Part_List_File			= NULL;
	char*	PlantName				= NULL;
	char*	inputuser				= NULL;
	char*	inputpwd				= NULL;
	char*	inputgrp				= NULL;
	char*	PartListName			= NULL;
	char*	Part_Number				= NULL; 
	char*	Part_revision			= NULL;
	char*	Sequence				= NULL;
	char*	Part_Type				= NULL;
	char*	Drawing_Indicator		= NULL;
	char*	Material_In_drawing		= NULL;
	char*	Uom						= NULL;
	char*	Material_Class			= NULL;
	char*	Part_Description		= NULL;
	char*	Part_ORGID				= NULL;
	char*	Part_MakeBuy			= NULL;
	char*	Part_SLOC				= NULL;
	char*	Part_LCS				= NULL;
	char*	getCreatndate			= NULL;
	char*	getlstMdfddate			= NULL;
	char**	display_value;
	char*	tempStringt				= NULL;
	char*	GenPlantCS				= NULL;
	char*	getPlantStore			= NULL;
	char*	EnvelopeDimensions		= NULL; 
	char*	Weight					= NULL; 
	char*	MThickness				= NULL; 
	char*	StdPartIndicator		= NULL; 
	char*	SpareInd				= NULL; 
	char*	CMVRCertificationReqd	= NULL;
	char*	ModelIndS				= NULL;
	char*	ColourIndS				= NULL;
	char*	DeignOwnUnitS			= NULL;
	char*	t5HomologationReqdS		= NULL;
	char*	mod_desc				= NULL;
	char*	DrawingNoS				= NULL;
	char*	RawPart_Family			= NULL;

	int     ifail               = ITK_ok;
	int		n_strings			= 1;
	int		l_strings			= 500;
	int		index				= 0;
	int		status;

	tag_t	t_dsgtyp			= NULLTAG;
	tag_t	t_dsgrevtyp			= NULLTAG;
	tag_t	t_dsgcre			= NULLTAG;
	tag_t	t_dsgrevcre			= NULLTAG;
	tag_t	t_dsgtag			= NULLTAG;

	inputuser	   = ITK_ask_cli_argument("-u=");
	inputpwd	   = ITK_ask_cli_argument("-p=");
	inputgrp	   = ITK_ask_cli_argument("-g=");
	Part_List_File = ITK_ask_cli_argument("-i=");
	//PlantName	   = ITK_ask_cli_argument("-plant=");
		

	//ITK_CALL(ITK_auto_login( ));  

	//printf("\n BEFORE Auto login ");fflush(stdout);
	//ITK_CALL(ITK_auto_login( ));

	//ITK_CALL( ITK_init_module("infodba","infodba","dba"));
	//ITK_CALL( ITK_init_module("infodba","infodba","dba"));

	if (ITK_init_module(inputuser,inputpwd,inputgrp) == ITK_ok )
	{
		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		//printf("\n Auto login ");fflush(stdout);
		ITK_CALL(ITK_set_journalling( TRUE ));
		ITK_set_bypass(true);

	
	//printf("\n Auto login .......\n");fflush(stdout);


	fp=fopen(Part_List_File,"r");
	fperror=fopen("ERC_Part_Stamping_error.log","a");
	fp_Efferror=fopen("Effectivity_error.log","a");
	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			fputs(inputline,stdout);		
					
			Part_Number				= NULL; 
			Part_revision			= NULL;
			Sequence				= NULL;
			Part_Type				= NULL;
			Drawing_Indicator		= NULL;
			Material_In_drawing		= NULL;
			Uom						= NULL;
			Material_Class			= NULL;
			Part_Description		= NULL;
			Part_ORGID				= NULL;
			Part_MakeBuy			= NULL;
			Part_SLOC				= NULL;
			Part_LCS				= NULL;
			getCreatndate			= NULL;
			getlstMdfddate			= NULL;
			EnvelopeDimensions		= NULL; 
			Weight					= NULL; 
			MThickness				= NULL; 
			StdPartIndicator		= NULL; 
			SpareInd				= NULL; 
			CMVRCertificationReqd	= NULL;
			ModelIndS				= NULL;
			ColourIndS				= NULL;
			DeignOwnUnitS			= NULL;
			t5HomologationReqdS		= NULL;

			mod_desc				= NULL;
			DrawingNoS				= NULL;
			
			// Part_Number ^ Part_revision ^ Sequence ^ Part_Type ^ Drawing_Indicator ^ Material_In_drawing ^ Uom ^ Material_Class ^ Part_Description ^ Part_ORGID ^ Part_MakeBuy ^ Part_SLOC ^ Part_LCS ^
			// 59148280775 ^	NR	       ^   1      ^     R     ^     S             ^     1               ^  2  ^     NULL       ^ COIL 0.63X1530 BH220 SS4011S3 ^ ERC ^ F ^LcsSTDRlzd

			Part_Number				= strtok(inputline,"^"); 
			Part_revision			= strtok(NULL,"^");
			Sequence				= strtok(NULL,"^");
			Part_Type				= strtok(NULL,"^");
			Drawing_Indicator		= strtok(NULL,"^");
			Material_In_drawing		= strtok(NULL,"^");
			Uom						= strtok(NULL,"^");
			Material_Class			= strtok(NULL,"^");
			Part_Description		= strtok(NULL,"^");
			Part_ORGID				= strtok(NULL,"^");
			Part_MakeBuy			= strtok(NULL,"^");
			Part_SLOC				= strtok(NULL,"^");
			Part_LCS				= strtok(NULL,"^");
			getCreatndate			= strtok(NULL,"^");
			getlstMdfddate			= strtok(NULL,"^");
			EnvelopeDimensions		= strtok(NULL,"^");
			Weight					= strtok(NULL,"^");
			MThickness				= strtok(NULL,"^");
			StdPartIndicator		= strtok(NULL,"^");
			SpareInd				= strtok(NULL,"^");
			CMVRCertificationReqd	= strtok(NULL,"^");
			ModelIndS				= strtok(NULL,"^");
			ColourIndS				= strtok(NULL,"^");
			DeignOwnUnitS			= strtok(NULL,"^");
			t5HomologationReqdS		= strtok(NULL,"^");

			mod_desc				= strtok(NULL,"^");
			DrawingNoS				= strtok(NULL,"^");

			printf("\n Part_Number ==> \t[%s]\n",Part_Number);fflush(stdout);
			printf(" Part_revision ==> \t[%s]\n",Part_revision);fflush(stdout);
			printf(" Sequence ==> \t\t[%s]\n",Sequence);fflush(stdout);
			printf(" Part_Type ==> \t\t[%s]\n",Part_Type);fflush(stdout);
			printf(" Drawing_Indicator ==> \t[%s]\n",Drawing_Indicator);fflush(stdout);
			printf(" Material_In_drawing ==> [%s]\n",Material_In_drawing);fflush(stdout);
			printf(" Unit_of_measure ==> \t[%s]\n",Uom);fflush(stdout);
			printf(" Material_Class ==> \t[%s]\n",Material_Class);fflush(stdout);
			printf(" Part_Description ==> \t[%s]\n",Part_Description);fflush(stdout);
			printf(" Part_ORGID ==> \t[%s]\n",Part_ORGID);fflush(stdout);
			printf(" Part_MakeBuy ==> \t[%s]\n",Part_MakeBuy);fflush(stdout);
			printf(" Part_SLOC ==> \t\t[%s]\n",Part_SLOC);fflush(stdout);
			printf(" Part_LCS ==> \t\t[%s]\n",Part_LCS);fflush(stdout);
			printf(" getCreatndate ==> \t[%s]\n",getCreatndate);fflush(stdout);
			printf(" getlstMdfddate ==>\t[%s]\n",getlstMdfddate);fflush(stdout);
			printf(" EnvelopeDimensions ==>\t[%s]\n",EnvelopeDimensions);fflush(stdout);
			printf(" Weight ==>\t\t[%s]\n",Weight);fflush(stdout);
			printf(" MThickness ==>\t\t[%s]\n",MThickness);fflush(stdout);
			printf(" StdPartIndicator ==>\t[%s]\n",StdPartIndicator);fflush(stdout);
			printf(" SpareInd ==>\t\t[%s]\n",SpareInd);fflush(stdout);
			printf(" CMVRCertification   ==>[%s]\n",CMVRCertificationReqd);fflush(stdout);
			printf(" ModelIndS ==>\t\t[%s]\n",ModelIndS);fflush(stdout);
			printf(" ColourIndS ==>\t\t[%s]\n",ColourIndS);fflush(stdout);
			printf(" DeignOwnUnitS ==>\t[%s]\n",DeignOwnUnitS);fflush(stdout);
			printf(" t5HomologationReqdS ==>[%s]\n",t5HomologationReqdS);fflush(stdout);
			printf(" mod_desc ==>\t\t[%s]\n",mod_desc);fflush(stdout);
			printf(" DrawingNoS ==>\t\t[%s]\n",DrawingNoS);fflush(stdout);
			
			printf("\n Checking Part Number [%s] is already created or not .....\n",Part_Number);
			
			const char *qry_entries[1];
			const char *qry_values[1];
			
			tag_t		*itemclass	=	NULLTAG;
			tag_t		item		=	NULLTAG;

			int			n_tags_found=0;

			qry_entries[0] ="item_id";
			qry_values[0] = Part_Number;

			//Find Item by its ID.
			ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
			printf("\n Number of Tags found : %d \n",n_tags_found);fflush(stdout);

			if(n_tags_found==0)
			{
				printf("\n Inside tm_create_design : %s \n",Part_Number);fflush(stdout);

				// if((tc_strcmp(PlantName,"PlantName1")==0) || (tc_strcmp(PlantName,"PlantName4")==0))
				// {
				// 	printf("\n Inside PlantName ==> [%s]\n",PlantName);fflush(stdout);
				// 
				// 	GenPlantCS=NULL;
				// 	GenPlantCS=(char *) MEM_alloc(100);
				// 	tc_strcpy(GenPlantCS,"t5_CarMakeBuyIndicator");
				// 
				// 	getPlantStore=NULL;
				// 	getPlantStore=(char *) MEM_alloc(100);
				// 	tc_strcpy(getPlantStore,"t5_CarStoreLocation");
				// 	printf("OPCS Name After Conversion ==> [%s]\n",GenPlantCS);fflush(stdout);
				// 	
				// }
				// else if(tc_strcmp(PlantName,"PlantName2")==0)
				// {
				// 	printf("\n Inside PlantName ==> [%s]\n",PlantName);fflush(stdout);
				// 
				// 	GenPlantCS=NULL;
				// 	GenPlantCS=(char *) MEM_alloc(100);
				// 	tc_strcpy(GenPlantCS,"t5_PnrMakeBuyIndicator");
				// 
				// 	getPlantStore=NULL;
				// 	getPlantStore=(char *) MEM_alloc(100);
				// 	tc_strcpy(getPlantStore,"t5_PnrStoreLocation");
				// 	printf("OPCS Name After Conversion ==> [%s]\n",GenPlantCS);fflush(stdout);
				// }
				// else if(tc_strcmp(PlantName,"PlantName3")==0)
				// {
				// 	printf("\n Inside PlantName ==> [%s]\n",PlantName);fflush(stdout);
				// 
				// 	GenPlantCS=NULL;
				// 	GenPlantCS=(char *) MEM_alloc(100);
				// 	tc_strcpy(GenPlantCS,"t5_PunMakeBuyIndicator");
				// 
				// 	getPlantStore=NULL;
				// 	getPlantStore=(char *) MEM_alloc(100);
				// 	tc_strcpy(getPlantStore,"t5_PunStoreLocation");
				// 	printf("OPCS Name After Conversion ==> [%s]\n",GenPlantCS);fflush(stdout);
				// }
				// else if(tc_strcmp(PlantName,"PlantName8")==0)
				// {
				// 	printf("\n Inside PlantName ==> [%s]\n",PlantName);fflush(stdout);
				// 
				// 	GenPlantCS=NULL;
				// 	GenPlantCS=(char *) MEM_alloc(100);
				// 	tc_strcpy(GenPlantCS,"t5_JsrMakeBuyIndicator");
				// 
				// 	getPlantStore=NULL;
				// 	getPlantStore=(char *) MEM_alloc(100);
				// 	tc_strcpy(getPlantStore,"t5_JsrStoreLocation");
				// 	printf("OPCS Name After Conversion ==> [%s]\n",GenPlantCS);fflush(stdout);
				// }
				// else if(tc_strcmp(PlantName,"PlantName9")==0)
				// {
				// 	printf("\n Inside PlantName ==> [%s]\n",PlantName);fflush(stdout);
				// 
				// 	GenPlantCS=NULL;
				// 	GenPlantCS=(char *) MEM_alloc(100);
				// 	tc_strcpy(GenPlantCS,"t5_LkoMakeBuyIndicator");
				// 
				// 	getPlantStore=NULL;
				// 	getPlantStore=(char *) MEM_alloc(100);
				// 	tc_strcpy(getPlantStore,"t5_LkoStoreLocation");
				// 	printf("OPCS Name After Conversion ==> [%s]\n",GenPlantCS);fflush(stdout);
				// }
				// else if(tc_strcmp(PlantName,"PlantName11")==0)
				// {
				// 	printf("\n Inside PlantName ==> [%s]\n",PlantName);fflush(stdout);
				// 
				// 	GenPlantCS=NULL;
				// 	GenPlantCS=(char *) MEM_alloc(100);
				// 	tc_strcpy(GenPlantCS,"t5_DwdMakeBuyIndicator");
				// 
				// 	getPlantStore=NULL;
				// 	getPlantStore=(char *) MEM_alloc(100);
				// 	tc_strcpy(getPlantStore,"t5_DwdStoreLocation");
				// 	printf("OPCS Name After Conversion ==> [%s]\n",GenPlantCS);fflush(stdout);
				// }
				// else if(tc_strcmp(PlantName,"PlantName6")==0)
				// {
				// 	printf("\n Inside PlantName ==> [%s]\n",PlantName);fflush(stdout);
				// 
				// 	GenPlantCS=NULL;
				// 	GenPlantCS=(char *) MEM_alloc(100);
				// 	tc_strcpy(GenPlantCS,"t5_AhdMakeBuyIndicator");
				// 
				// 	getPlantStore=NULL;
				// 	getPlantStore=(char *) MEM_alloc(100);
				// 	tc_strcpy(getPlantStore,"t5_AhdStoreLocation");
				// 	printf("OPCS Name After Conversion ==> [%s]\n",GenPlantCS);fflush(stdout);
				// }
				// else if(tc_strcmp(PlantName,"PlantName13")==0)
				// {
				// 	printf("\n Inside PlantName ==> [%s]\n",PlantName);fflush(stdout);
				// 
				// 	GenPlantCS=NULL;
				// 	GenPlantCS=(char *) MEM_alloc(100);
				// 	tc_strcpy(GenPlantCS,"t5_PunUVMakeBuyIndicator");
				// 
				// 	getPlantStore=NULL;
				// 	getPlantStore=(char *) MEM_alloc(100);
				// 	tc_strcpy(getPlantStore,"t5_PunUVStoreLocation");
				// 	printf("OPCS Name After Conversion ==> [%s]\n",GenPlantCS);fflush(stdout);
				// }
				
				display_value = (char**)malloc( n_strings * sizeof *display_value );
				for( index=0; index<n_strings; index++ )
				{
					display_value[index] = (char*)malloc( l_strings + 1 );
				}
				// RawPart_Family
				RawPart_Family	=(char *) MEM_alloc(10 * sizeof(char *));
				
				if(strstr(Part_Description,"SHEET") || strstr(Part_Description,"SHT"))
				{
					printf("\n Inside RawPart_Family SHEETS \n");fflush(stdout);
					strcpy(RawPart_Family,"SHEETS");
				}
				else if(strstr(Part_Description,"COIL") || strstr(Part_Description,"Coil"))
				{
					printf("\n Inside RawPart_Family COILS \n");fflush(stdout);
					strcpy(RawPart_Family,"COILS");
				}
				else if(strstr(Part_Description,"TUBE"))
				{
					printf("\n Inside RawPart_Family TUBES \n");fflush(stdout);
					strcpy(RawPart_Family,"TUBES");
				}
				else if(strstr(Part_Description,"BEAM"))
				{
					printf("\n Inside RawPart_Family BEAM \n");fflush(stdout);
					strcpy(RawPart_Family,"BEAM");
				}
				else if(strstr(Part_Description,"CHANNEL"))
				{
					printf("\n Inside RawPart_Family CHANNEL \n");fflush(stdout);
					strcpy(RawPart_Family,"CHANNEL");
				}
				else if(strstr(Part_Description,"STRIP"))
				{
					printf("\n Inside RawPart_Family STRIPS \n");fflush(stdout);
					strcpy(RawPart_Family,"STRIPS");
				}
				else if(strstr(Part_Description,"PLATE"))
				{
					printf("\n Inside RawPart_Family PLATE \n");fflush(stdout);
					strcpy(RawPart_Family,"PLATES");
				}
				else
				{
					printf("\n Inside else of RawPart_Family \n");fflush(stdout);
					strcpy(RawPart_Family,"COILS");
				}
				
				// Design // 
				ITK_CALL(TCTYPE_find_type("T5_RawPart",NULL,&t_dsgtyp));
				if (t_dsgtyp!=NULLTAG)
				{
					printf("\n t_dsgtyp is not null tag \n");fflush(stdout);
				}
				ITK_CALL(TCTYPE_construct_create_input(t_dsgtyp,&t_dsgcre));
				//
				
				// Design Revision //
				ITK_CALL(TCTYPE_find_type("T5_RawPartRevision",NULL,&t_dsgrevtyp));
				ITK_CALL(TCTYPE_construct_create_input(t_dsgrevtyp,&t_dsgrevcre));
				//

				printf("\n new Setting Value in Design \n");fflush(stdout);
				tc_strcpy(display_value[0],Part_Number);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"item_id",1,(const char**)display_value));

				//tc_strcpy(display_value[0],Part_Number);
				tc_strcpy(display_value[0],Part_Description);
				printf("\n display_value[0]=%s",display_value[0]);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"object_name",1,(const char**)display_value));

				tc_strcpy(display_value[0],Part_Description);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"object_desc",1,(const char**)display_value));

				tc_strcpy(display_value[0],RawPart_Family);
				//tc_strcpy(display_value[0],"SHEETS");
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"t5_Family",1,(const char**)display_value));

				ITK_CALL( AOM_tag_to_string(t_dsgrevcre, &tempStringt) );
				tc_strcpy(display_value[0],tempStringt);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgcre,"revision",1,(const char**)display_value));
				
				printf("\n Setting Value in Design Revision\n");fflush(stdout);
				tc_strcpy( display_value[0], "NR;1");
				ITK_CALL( TCTYPE_set_create_display_value( t_dsgrevcre, "item_revision_id", 1,(const char**)display_value));

				tc_strcpy(display_value[0],Part_Description);
				//tc_strcpy(display_value[0],Part_Number);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgrevcre,"object_name",1,(const char**)display_value));

				tc_strcpy(display_value[0],Part_Description);
				ITK_CALL(TCTYPE_set_create_display_value(t_dsgrevcre,"object_desc",1,(const char**)display_value));

				ITK_CALL( TCTYPE_create_object( t_dsgcre,&t_dsgtag));
				printf("\n Test test 1111 \n");fflush(stdout);
				ITK_CALL( AOM_save_without_extensions(t_dsgtag));
				
				tag_t 			DesignRevTag	    = NULLTAG;
				ITEM_ask_latest_rev(t_dsgtag,&DesignRevTag);

				ITK_CALL( AOM_save_without_extensions(DesignRevTag));
				
				printf("\n *****  Updating Attributes On Design *****\n");fflush(stdout);
				setAttributesOnDesign(&t_dsgtag,Uom);

				printf("\n *****  Updating Attributes On Design Revision *****\n");fflush(stdout);
				setAttributesOnDesignRevision(&DesignRevTag,Part_MakeBuy,Part_SLOC,Part_Type,Drawing_Indicator,Material_In_drawing,EnvelopeDimensions,Weight,MThickness,StdPartIndicator,
					SpareInd,CMVRCertificationReqd,ModelIndS,ColourIndS,DeignOwnUnitS,t5HomologationReqdS,mod_desc,DrawingNoS);

				//
				tag_t   qryTagCntrlobj		= NULLTAG;
				tag_t*	list_of_cntrl_tags	= NULLTAG;

				char*	qry_entryCntrlformat[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};	
				char**	qry_valuesCntrlformat	= (char **) MEM_alloc(5 * sizeof(char *));

				int controlObjfound	= 0;
				int	n_entryCntrlobj = 3;
				int	cntrlcnt		= 0;
				
				char*	PlantLcs 		= NULL;
				char*	Plant_Lcs_stamp	= NULL;
				Plant_Lcs_stamp	=(char *) MEM_alloc(100 * sizeof(char *));

				if(QRY_find2("Control Objects...", &qryTagCntrlobj));

				if (qryTagCntrlobj)
				{
					printf("\n Control Object Query Found \n");fflush(stdout);
					qry_valuesCntrlformat[0]="Stamping";
					qry_valuesCntrlformat[1]="LCS";
					qry_valuesCntrlformat[2]="0";
										
					if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
				}
				else
				{
					printf("\n Control Object Query not Found  \n");fflush(stdout);
				}

				printf("\n controlObjfound is for Stamping ==> %d\n",controlObjfound);fflush(stdout);

				tag_t         Design_RelTag1 = NULLTAG;
				
				char*         Design_RelStatus1 = NULL;
				
				logical       retain_released_date1 =false;

				tag_t         DesignRev_RelTag1 = NULLTAG;
				
				char*         DesignRev_RelStatus1 = NULL;
				
				logical       retain_released_date2 =false;


				if(controlObjfound>0)
				{
					AOM_ask_value_string( list_of_cntrl_tags[cntrlcnt], "t5_Userinfo1", &PlantLcs);
					printf("\n Ketan LCS : %s\n",PlantLcs);fflush(stdout);
					Plant_Lcs_stamp =  tc_strtok(PlantLcs,",");
					
					do
					{
					
						printf("\n Plant_Lcs_stamp : %s\n",Plant_Lcs_stamp);fflush(stdout);
						ifail = CR_create_release_status(Plant_Lcs_stamp,&Design_RelTag1);
						ifail = AOM_ask_name(Design_RelTag1, &Design_RelStatus1);
						printf("\n\n\t\t Design_RelStatus1 :%s\n",Design_RelStatus1); fflush(stdout);
						ifail = EPM_add_release_status(Design_RelTag1,1,&t_dsgtag,retain_released_date1);
						printf("\n Release status [%s] is updated to Design Object \n",Design_RelStatus1); fflush(stdout);

						ifail = CR_create_release_status(Plant_Lcs_stamp,&DesignRev_RelTag1);
						ifail = AOM_ask_name(DesignRev_RelTag1, &DesignRev_RelStatus1);
						printf("\n\n\t\t DesignRev_RelStatus1 :%s\n",DesignRev_RelStatus1); fflush(stdout);
						ifail = EPM_add_release_status(DesignRev_RelTag1,1,&DesignRevTag,retain_released_date2);
						printf("\n Release status [%s] is updated to Design Revision Object \n",DesignRev_RelStatus1); fflush(stdout);
						
						Plant_Lcs_stamp =  tc_strtok(NULL,",");

					}while(Plant_Lcs_stamp != NULL);
					
				}
				//

				printf("\n *****  Changing Creation Date and Modification Date *****\n");fflush(stdout);
				
				printf("\n *****  1 Changing Creation Date and Modification Date On Design *****\n");fflush(stdout);
				MM_Change_Creation_Date(t_dsgtag,getCreatndate,getlstMdfddate);
				
				printf("\n *****  2 Changing Creation Date and Modification Date On DesignRevision *****\n");fflush(stdout);
				MM_Change_Creation_Date(DesignRevTag,getCreatndate,getlstMdfddate);
				

				/*
				date_t   crtndate		  = NULLDATE;
				date_t   mdfcndate		  = NULLDATE;
				
				char* objTyp = NULL;
				
				printf("\n creation_date [%s]\n",getCreatndate);fflush(stdout);
				printf("\n mod_date [%s] \n",getlstMdfddate);fflush(stdout);
				crtndate = TML_token_to_date(getCreatndate);
				mdfcndate = TML_token_to_date(getlstMdfddate);
				
				ITK_CALL(AOM_ask_value_string(t_dsgtag,"object_type",&objTyp));
				printf("\n objTyp is -->%s\n",objTyp); fflush(stdout);
				
				if(DATE_IS_NULL(crtndate) == 0)
				{
					printf("\n ketan 1 \n");fflush(stdout);
					ITK_CALL(AOM_refresh(t_dsgtag,true));
					ITK_CALL(POM_set_creation_date(t_dsgtag,crtndate));
					ITK_CALL(AOM_save_without_extensions(t_dsgtag));
					ITK_CALL(AOM_refresh(t_dsgtag,true));
				}
				*/

			}
			else
			{
				printf("\n Part/Design already exists...\n");fflush(stdout);
			}

		

			
					
			

		}
		printf("----------------END OF PART-----------------------------------\n");fflush(stdout);

	}
	else
	{
		printf("PartListName [%s] is NULL..\n",PartListName);fflush(stdout);				
	}

	printf("-----------PART LOADING SUCCESS-----------------------------------------\n");fflush(stdout);
}
		
	
	//ITK_CALL(POM_logout(false));

	/*if (inputline)MEM_free(inputline);
	if (level)MEM_free(level);
	if(item_id)MEM_free(item_id);
	if(item_revision_id)MEM_free(item_revision_id);
	if(item_sequence_id)MEM_free(item_sequence_id);
	if(t5CarMakeBuyIndiS)MEM_free(t5CarMakeBuyIndiS);
	if(t5CarStoreLoc)MEM_free(t5CarStoreLoc);t5CarStoreLoc=NULL;
	if(lifecycleS)MEM_free(lifecycleS);lifecycleS=NULL;
	if(APLEffFromDate)MEM_free(APLEffFromDate);APLEffFromDate=NULL;
	if(APLEffToDate)MEM_free(APLEffToDate);APLEffToDate=NULL;
	if(STDEffFromDate)MEM_free(STDEffFromDate);STDEffFromDate=NULL;
	if(STDEffToDate)MEM_free(STDEffToDate);STDEffToDate=NULL;
	if(itemRevSeq)MEM_free(itemRevSeq);itemRevSeq=NULL;
	if(rel_list)MEM_free(rel_list);rel_list=NULL;
	if(fperror)fclose(fperror);fperror=NULL;*/

	
	return status;

   
}
 
