
//./Assign_CRB -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -DML_No="22DG002000/NR;1" -DML_CRB="ERC_Designers_Group/00_Managers/Karamchand Kalet (kkk04778)"

#include <stdio.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <sa/groupmember.h>
#include <qry/qry.h>
#include <epm/epm.h>
#include <string.h>
#include <Fnd0Participant/participant.h>

static int report_error( char *, int, char *, int);
int AssignCRBParticipant(char*,char*);

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int index = 0;
		int n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;
		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

int			ifail 				= ITK_ok;
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		fprintf( stderr, "Error(PrintErrorStack): \n");
		fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
	}
	return ITK_ok;
}

int ITK_user_main(int argc, char *argv[])
{

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* DML_No					= NULL;
	char			* UserName					= NULL;
	char			* rev_id					= NULL;
	

	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	DML_No 			= ITK_ask_cli_argument("-DML_No=");
	UserName 	    = ITK_ask_cli_argument("-DML_CRB=");
	//rev_id 	        = ITK_ask_cli_argument("-rev_id=");
	
	
	
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	ifail = AssignCRBParticipant(DML_No,UserName);

	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


int AssignCRBParticipant(char* DML_No,char* DML_CRB)
{
	int status = 0;
	int error_code = ITK_ok;
	int No_User = 0 , iii=0;
    int member_count=0;
	tag_t* User_Tags= NULLTAG;
	tag_t groupName_tag= NULLTAG;
	tag_t CRB_Patri_Type= NULLTAG;
	tag_t roleName_tag= NULLTAG;
	tag_t CRB_Party =  NULLTAG;
	tag_t User_tag =  NULLTAG;
	tag_t dml_rev_tag =  NULLTAG;
	tag_t dml_tag =  NULLTAG;
	char* groupName=NULL;
	char* roleName=NULL;
	char* UserName=NULL;
	//char* UserName1=NULL;
	//char* UserNameFull=NULL;
	char* DML_Number=NULL;
	char* DMLRevSeq=NULL;
	char* DML_Rev=NULL;
	char* DML_Seq=NULL;
	tag_t DMLRevSeqQry     = NULLTAG;
	tag_t *DMLTags   = NULL;
	tag_t *CRB_memberstag   = NULL;
	int DMLCount=0;
	int Entry_count=3;
    logical hasbypass =true;
	groupName = (char *)MEM_alloc(70);
	roleName = (char *)MEM_alloc(70);
	UserName = (char *)MEM_alloc(70);
	//UserName1 = (char *)MEM_alloc(70);
	//UserNameFull = (char *)MEM_alloc(70);
 
 	
	printf("\n AssignCRBParticipant-->DML No == [%s] DML CRB == [%s]", DML_No,DML_CRB);fflush(stdout);
   if (DML_CRB != NULL)
	{
                groupName = strtok(DML_CRB,"/");
				printf("\nGroup_Name:%s",groupName);
                roleName = strtok(NULL,"/");
				printf("\nRolename:%s",roleName);
                UserName = strtok(NULL,"/");
				printf("\nUserName:%s",UserName);
				
				if(SA_find_groupmember_by_rolename(roleName,groupName,UserName,&member_count,&CRB_memberstag)!=ITK_ok)PrintErrorStack();
				/*if(SA_find_group(groupName,&CRB_Grouptag)!=ITK_ok)PrintErrorStack();
				if(SA_find_role2(roleName,&CRB_ROletag)!=ITK_ok)PrintErrorStack();
	            if(SA_find_groupmember_by_role(CRB_Grouptag,CRB_ROletag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
				if(UserNameFull!=NULL)
				{
				UserName1 = strtok(UserNameFull,"(");
				printf("\nUserName1:%s",UserName1);
				UserName = strtok(NULL,")");
				printf("\nUserName:%s",UserName);
				}*/
				
   }
	
   if (DML_No != NULL)
	{
                DML_Number = strtok(DML_No,"/");
				printf("\nDML_Number:%s",DML_Number);
                DMLRevSeq = strtok(NULL,"/");
				printf("\nDMLRevSeq:%s",DMLRevSeq);
		  if (DMLRevSeq != NULL)
	         {
                DML_Rev = strtok(DMLRevSeq,";");
				printf("\n DML_Rev:%s",DML_Rev);
                DML_Seq = strtok(NULL,"-");
				printf("\n DML_Seq:%s",DML_Seq);
				
				
	         }
	}
	//char *Entries[3] = {"ID","Revision","Sequence Id"};
char **Entries = (char **) MEM_alloc(500 * sizeof(char *));
char **Values = (char **) MEM_alloc(500 * sizeof(char *));

Entries[0] = "ID";
Entries[1] = "Revision";
Entries[2] = "Sequence Id";
Values[0] =DML_Number;
Values[1] = DML_Rev;
Values[2] = DML_Seq;
	ifail=QRY_find2("ERC DML RevSeq", &DMLRevSeqQry);

	    
		if (DMLRevSeqQry!= NULLTAG)
		{ 
	             printf("\n inside execute qry");
			ITK_CALL(QRY_execute(DMLRevSeqQry,Entry_count, Entries, Values, &DMLCount, &DMLTags));
			printf("\n DMLCount:%d",DMLCount);
		}
	       
	
	if(DMLCount>0)
	{
		//ITK_CALL(SA_find_user2(UserName,&User_tag));
		ITK_CALL(EPM_get_participanttype ("ChangeReviewBoard",&CRB_Patri_Type));
		if (CRB_Patri_Type != NULLTAG && CRB_memberstag != NULL && DMLTags[0]!= NULLTAG)
	     {
	            printf("\n inside assign participants");
		 if(EPM_create_participant(CRB_memberstag[0],CRB_Patri_Type,&CRB_Party)!=ITK_ok)PrintErrorStack();
		 //EPM_create_participant(Ana_Tag_TR,TP_Ana_Patri_Type,&TP_Ana_Party)!=ITK_ok)PrintErrorStack();
		if(CRB_Party!=NULLTAG)
		{
	   printf("\n inside 230 ");
				if(AOM_refresh(DMLTags[0],1)!=ITK_ok)PrintErrorStack();
				//if(AOM_lock( DMLTags[0])!=ITK_ok)PrintErrorStack();
				if(PARTICIPANT_add_participant(DMLTags[0],hasbypass,CRB_Party)!=ITK_ok)PrintErrorStack();
	        if(AOM_save_without_extensions(DMLTags[0])!=ITK_ok)PrintErrorStack();
			//if(AOM_unlock(DMLTags[0])!=ITK_ok)PrintErrorStack();
			if(AOM_refresh(DMLTags[0],0)!=ITK_ok)PrintErrorStack();
		}
	     }
	
			
	}
	
	//MEM_free(CRB_Patri_Type);
		//}
	return ITK_ok;
}
