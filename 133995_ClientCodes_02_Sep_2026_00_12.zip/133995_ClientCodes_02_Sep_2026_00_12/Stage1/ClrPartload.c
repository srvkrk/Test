
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"



#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

static int	validate_date ( char *date , logical *date_is_valid , date_t *the_dt )
{
    int      retcode    = ITK_ok;     /* Function return code */
    date_t   dt         = NULLDATE;   /* Date structure */
    int      month      = 0;          /* Month */
    int      day        = 0;          /* Day */
    int      year       = 0;          /* Year */
    int      hour       = 0;          /* Hour */ 
    int      minute     = 0;          /* Minutes */
    int      second     = 0;          /* Seconds */

    *date_is_valid = TRUE;

    /* Converts a date_t structure into the format specified  */
//    retcode = DATE_string_to_date ( date , "%d-%b-%Y %H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for " 21-August-2015" / ""
//    retcode = DATE_string_to_date ( date , "%m-%d-%y-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);				// working for  "07-21-2015-09:05:58"
    retcode = DATE_string_to_date ( date , "%y/%m/%d-%H:%M:%S" , &month , &day , &year , &hour , &minute , &second);
    if ( retcode != ITK_ok )
    {
        *date_is_valid = FALSE;
    }
    else
    {
        dt.month = month;
        dt.day   = day;
        dt.year  = year;
        dt.hour  = hour;
        dt.minute= minute;
        dt.second= second;

        *the_dt = dt;
    }

	printf("  ---return from validate_date....\n");

    return retcode;
}

int setAttributesOnDesignRev(tag_t* rev,char* item_id,int sequence_id,char* desc,char* ColourIndS,char* t5PrtCatCodeS,char* t5ColourIDS,char* t5CoatedS,char* t5PartStatusS,char* designgroup,char* projectcode,char* mod_desc,char* DrawingIndS,char * PartTypeS,char * t5PartCodeS,char * t5AhdMakeBuyIndS,char * t5PunPCBUMakeBuyIndS,char * t5PunMakeBuyIndS,char * t5DwdMakeBuyIndS,char * NonColorPart)
{
	int status;
	double dweight=0;
	tag_t  projobj=NULLTAG;
	tag_t user_tag=NULLTAG;
	char* username=NULL;

	printf("\n item_id ---->%s\n",item_id);fflush(stdout);
	printf("\n sequence_id ---->%d\n",sequence_id);fflush(stdout);
	printf("\n Part Desc ---->%s\n",desc);fflush(stdout);
	printf("\n ColourIndS ---->%s\n",ColourIndS);fflush(stdout);
	printf("\n t5PrtCatCodeS---->%s\n",t5PrtCatCodeS);fflush(stdout);
	printf("\n t5ColourIDS---->%s\n",t5ColourIDS);fflush(stdout);
	printf("\n t5CoatedS---->%s\n",t5CoatedS);fflush(stdout);
	printf("\n t5PartStatusS---->%s\n",t5PartStatusS);fflush(stdout);
	printf("\n designgroup---->%s\n",designgroup);fflush(stdout);
	printf("\n projectcode---->%s\n",projectcode);fflush(stdout);
	printf("\n mod_desc---->%s\n",mod_desc);fflush(stdout);
	printf("\n DrawingIndS---->%s\n",DrawingIndS);fflush(stdout);
	printf("\n PartTypeS---->%s\n",PartTypeS);fflush(stdout);
	printf("\n t5PartCodeS---->%s\n",t5PartCodeS);fflush(stdout);
	printf("\n t5AhdMakeBuyIndS---->%s\n",t5AhdMakeBuyIndS);fflush(stdout);
	printf("\n t5PunPCBUMakeBuyIndS---->%s\n",t5PunPCBUMakeBuyIndS);fflush(stdout);
	printf("\n t5PunMakeBuyIndS---->%s\n",t5PunMakeBuyIndS);fflush(stdout);
	printf("\n t5DwdMakeBuyIndS---->%s\n",t5DwdMakeBuyIndS);fflush(stdout);
	
	ITK_CALL(AOM_lock(*rev));
	//ITK_CALL(AOM_set_value_string(*rev,"item_id",item_id));
	//ITK_CALL(AOM_set_value_string(*rev,"object_name",item_id));
	ITK_CALL(AOM_set_value_int(*rev,"sequence_id",sequence_id));
	ITK_CALL(AOM_set_value_string(*rev,"object_desc",desc));
	ITK_CALL(AOM_set_value_string(*rev,"t5_ColourInd","C"));
	ITK_CALL(AOM_set_value_string(*rev,"t5_PrtCatCode",t5PrtCatCodeS));
	ITK_CALL(AOM_set_value_string(*rev,"t5_ColourID",t5ColourIDS));
	ITK_CALL(AOM_set_value_string(*rev,"t5_Coated","N"));
	ITK_CALL(AOM_set_value_string(*rev,"t5_NcPartNo",NonColorPart));
	ITK_CALL(AOM_set_value_string(*rev,"t5_PartStatus",t5PartStatusS));
	ITK_CALL(AOM_set_value_string(*rev,"t5_DesignGrp",designgroup));
	ITK_CALL(AOM_set_value_string(*rev,"t5_ProjectCode",projectcode));
	ITK_CALL(AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc));
	//ITK_CALL(AOM_set_value_string(*rev,"t5_DrawingInd",DrawingIndS));
	if (strstr(PartTypeS,"D")!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","D"));
	}
	if (strstr(PartTypeS,"A")!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","A"));
	}
	if (strstr(PartTypeS,"C")!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","C"));
	}
	if (strstr(PartTypeS,"VC")!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","VC"));
	}
	if (strstr(PartTypeS,"V")!=NULL)
	{
		ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","V"));
	}

	ITK_CALL(AOM_set_value_string(*rev,"t5_PartCode",t5PartCodeS));
	if(tc_strcmp(t5AhdMakeBuyIndS,"-")==0)
	{
		ITK_CALL(AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator",""));
	}else
	{
		ITK_CALL(AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator",t5AhdMakeBuyIndS));
	}

	if(tc_strcmp(t5PunPCBUMakeBuyIndS,"-")==0)
	{
		ITK_CALL(AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator",""));
	}else
	{
		ITK_CALL(AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator",t5PunPCBUMakeBuyIndS));
	}

	if(tc_strcmp(t5PunMakeBuyIndS,"-")==0)
	{
		ITK_CALL(AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",""));
	}else
	{
		ITK_CALL(AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",t5PunMakeBuyIndS));
	}
	
	if(tc_strcmp(t5DwdMakeBuyIndS,"-")==0)
	{
		ITK_CALL(AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator",""));
	}else
	{
		ITK_CALL(AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator",t5DwdMakeBuyIndS));
	}	
		
	ITK_CALL(AOM_save_without_extensions(*rev));
	ITK_CALL(AOM_unlock(*rev));
}

int setAttributesOnDesign(tag_t* item,char * item_id,char* desc,char* UnitOfMeasureS)
{
	int status;
	char* ent_uom=NULL;
	tag_t unit_of_measure=NULLTAG;
	tag_t ItemTag = NULLTAG;
	tag_t ItemTagRevision = NULLTAG;

	ent_uom=(char *) MEM_alloc(10 * sizeof(char *));

	if(strcmp(UnitOfMeasureS,"1")==0){strcpy(ent_uom,ONE);}
	else if(strcmp(UnitOfMeasureS,"2")==0){strcpy(ent_uom,TWO);}
	else if(strcmp(UnitOfMeasureS,"3")==0){strcpy(ent_uom,THREE);}
	else if(strcmp(UnitOfMeasureS,"4")==0){strcpy(ent_uom,FOUR);}
	else if(strcmp(UnitOfMeasureS,"5")==0){strcpy(ent_uom,FIVE);}
	else if(strcmp(UnitOfMeasureS,"6")==0){strcpy(ent_uom,SIX);}
	else if(strcmp(UnitOfMeasureS,"7")==0){strcpy(ent_uom,SEVEN);}
	else if(strcmp(UnitOfMeasureS,"8")==0){strcpy(ent_uom,EIGHT);}
	else {strcpy(ent_uom,"");}

	printf("\n ent_uom ... [%s]",ent_uom);
	printf("\n item_id--------->%s\n",item_id);
	printf("\n object_name------------>%s\n",item_id);
	printf("\n object_desc:%s\n",desc);
	printf("\n UnitOfMeasureS:%s\n",UnitOfMeasureS);

	ITK_CALL(ITEM_find_item(item_id,&ItemTag));	
	ITK_CALL(ITEM_ask_latest_rev(ItemTag, &ItemTagRevision));
	if(ItemTag)
	{	
		ITK_CALL(AOM_lock(ItemTag));
		ITK_CALL(AOM_set_value_logical(ItemTag,"is_designrequired",true));
		ITK_CALL(AOM_save_without_extensions(ItemTag));
		ITK_CALL(AOM_unlock(ItemTag));
		ITK_CALL(AOM_refresh(ItemTag,0));
		printf("\n is_designrequired updated on Master to false-------------->\n");
	}

	ITK_CALL(AOM_lock(*item));
	if(strcmp(UnitOfMeasureS,"4")!=0)
	{
		ITK_CALL(UOM_find_by_symbol(ent_uom,&unit_of_measure));
		ITK_CALL(ITEM_set_unit_of_measure(*item, unit_of_measure));
	}
	ITK_CALL(AOM_set_value_string(*item,"item_id",item_id));
	ITK_CALL(AOM_set_value_string(*item,"object_name",item_id));
	ITK_CALL(AOM_set_value_string(*item,"object_desc",desc));
	ITK_CALL(AOM_save_without_extensions(*item));
	ITK_CALL(AOM_unlock(*item));	
}

int setLifeCycle(tag_t* itemRev,char* lifeCycleS)
{
		int status;
		tag_t   status2=NULLTAG;
		logical retain=false;
		char* lcsToset=NULL;

		lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

		if(strcmp(lifeCycleS,"LcsReview")==0){strcpy(lcsToset,ERCREVIEW);}
		else if(strcmp(lifeCycleS,"LcsWorking")==0){strcpy(lcsToset,ERCWORKING);}
		else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){strcpy(lcsToset,APLWORKING);}
		else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){strcpy(lcsToset,APLRELEASED);}
		else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){strcpy(lcsToset,STDWORKING);}
		else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0)
		{
			printf("\n This is std rel...");
			strcpy(lcsToset,STDRELEASED);
		}

		ITK_CALL(CR_create_release_status2(lcsToset,&status2));
		ITK_CALL(RELSTAT_add_release_status(status2,1,itemRev,retain));

		ITK_CALL(AOM_save_without_extensions(*itemRev));
		ITK_CALL(AOM_unlock(*itemRev));
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

int convertDate(char* date,char* rDate)
{
	int status;

}

void getNextDate(char *DatetoConvert,char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		Monthas;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char*	strDay;
	char*	strMon;
	char*	strYear;
	char	DateS[20];
	char* cMonth ;
	char CCMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
//	timeptr = (struct tm *)localtime(&temp);
//	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

//	day=timeptr->tm_mday;
//	month=(timeptr->tm_mon)+1;
//	year=(timeptr->tm_year+1900);

    strYear =  strtok(DatetoConvert,"/"); //1
    cMonth  =  strtok(NULL,"'/'"); //2
    strDay  =  strtok(NULL,"'/'"); //3
    Monthas =  atoi(cMonth);
	getMonth(Monthas,CCMonth);

	printf("\n strYear:%s\n",strYear);
	printf("\n CCMonth:%s\n",CCMonth);
	printf("\n strDay:%s\n",strDay);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,CCMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s",cnextAccessDate);
}




int AssignProject(tag_t  itemRev,char* projectcode)
{

	int status;
	tag_t  projobj=NULLTAG;
	char* username=NULL;
	tag_t user_tag=NULLTAG;

   // ITK_CALL(AOM_lock(itemRev));
	printf("\n projectcode [%s]\n",projectcode);fflush(stdout);
	ITK_CALL (PROJ_find(projectcode,&projobj));
	printf("\n Assigned to Project111\n");fflush(stdout);
	
	/*
	if(projobj !=NULLTAG)
	{
	//	POM_get_user(&username,&user_tag);
	//	ITK_CALL(PROJ_add_members(projobj,1,&user_tag));
		ITK_CALL (PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
		printf("\n Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n Project not found\n");fflush(stdout);
	}
	*/
//   ITK_CALL(AOM_save(itemRev));
//  ITK_CALL(AOM_unlock(itemRev));

  return status;
}

int setDateCreationOnRev(tag_t rev_t,char* CreDateTempS)
{
	int status;
	int retcode = ITK_ok;
	char* Year = NULL;
	char* Month	= NULL;
	char* Day = NULL;
	char* Hours	= NULL;
	char* Min = NULL;
	char* Sec = NULL;
	char* MicroSec = NULL;
	char* PrtCreDateS = NULL;
	char* Year2 = NULL;
	char* Month2	= NULL;
	char* Day2 = NULL;
	char* Hours2	= NULL;
	char* Min2 = NULL;
	char* Sec2 = NULL;
	char* MicroSec2 = NULL;
	
	date_t creationDate_D;
    logical date_is_valid = FALSE;
	PrtCreDateS = ( char * ) MEM_alloc(30);

	printf("\nCreDateTempS---> : [%s]\n",CreDateTempS); fflush(stdout);
	if(strlen(CreDateTempS)> 1)
	{
		ITK_CALL(AOM_lock(rev_t));

		Year=strtok(CreDateTempS,"/");
		Month=strtok(NULL,"/");
		Day=strtok(NULL,"-");
		Hours=strtok(NULL,":");
		Min=strtok(NULL,":");
		Sec=strtok(NULL,":");
		MicroSec=strtok(NULL,":");

		strcpy(PrtCreDateS,"");
		strcpy(PrtCreDateS,Year);
		strcat(PrtCreDateS,"/");
		strcat(PrtCreDateS,Month);
		strcat(PrtCreDateS,"/");
		strcat(PrtCreDateS,Day);
		strcat(PrtCreDateS,"-");
		strcat(PrtCreDateS,Hours);
		strcat(PrtCreDateS,":");
		strcat(PrtCreDateS,Min);
		strcat(PrtCreDateS,":");
		strcat(PrtCreDateS,Sec);

		printf("New Creation Date is --> [%s]",PrtCreDateS); fflush(stdout);
		retcode = validate_date( PrtCreDateS , &date_is_valid , &creationDate_D );
		if ( retcode != ITK_ok )
		{
			printf ( " Creation Date--error code %d\n\n", retcode); fflush(stdout);
			return EXIT_FAILURE;
		}
		
		printf ("\n validate_date successfully done\n\n"); fflush(stdout);
		ITK_CALL(POM_set_creation_date(rev_t, creationDate_D));
		printf ("\n Creation Date has been updated on Color Part : %d\n\n", retcode); fflush(stdout);
		
		//ITK_CALL(AOM_save(rev_t));
		//ITK_CALL(AOM_unlock(rev_t));
	}
  return status;
}


int setEffectivity(tag_t* itemRev,char* date)
{

	int status;
	logical   date_is_valid   = FALSE;
	tag_t	  st_date_id =NULLTAG;
	tag_t     end_date_id =NULLTAG;
	tag_t     eff_t =NULLTAG;
	date_t	  st_date;
	date_t    end_date;
	int       st_count=0;
	tag_t*    status_list;
	tag_t class_id=NULLTAG;
	char* class_name=NULL;
	logical ans=false;


	ITK_CALL(WSOM_ask_release_status_list(*itemRev,&st_count,&status_list));

	printf("\n No. of status found:[%d]",st_count);
	if(st_count>0)
	{
		ITK_CALL(POM_class_of_instance(status_list[0],&class_id));
		ITK_CALL(POM_name_of_class(class_id,&class_name));
		ITK_CALL(POM_unload_instances (st_count,status_list));
		ITK_CALL(POM_load_instances(st_count,status_list,class_id,1));
		ITK_CALL(POM_is_loaded(status_list[0],&ans));
		if(ans==1)
		{
			//ITK_CALL(WSOM_effectivity_create_with_dates(status_list[0],NULLTAG,1,&range_date,EFFECTIVITY_closed,&eff_t));
			//ITK_CALL(WSOM_eff_set_date_range(status_list[0]));
			//WSOM_status_ask_effectivitie
			//ITK_CALL(WSOM_effectivity_create_with_text(status_list[0],NULLTAG,"05-Jul-2011 00:00 to 13-Jul-2011 00:00",&eff_t));
			ITK_CALL(WSOM_eff_create_with_date_text(status_list[0],NULLTAG,date,&eff_t));
			ITK_CALL(AOM_save_without_extensions(status_list[0]));
			ITK_CALL(POM_save_instances(st_count,status_list,1));

		}else
		{
			printf("\n Cannot load this......");
		}
		//ITK_CALL(AOM_save(*itemRev));
		//ITK_CALL(AOM_unlock(*itemRev));
	}
}

int CreateEffctivity(tag_t itemrev,char *FromDate,char *ToDate,char *lifeCycleS)
{
		tag_t   release_status =NULLTAG;
		char   *ReleaseStatus=NULL;
		logical  retain_released_date =false;
		logical  is_v7  ;
		logical  date_is_valid;
		char FrmNextDate[20]={0};
		char ToNextDate[20]={0};
		date_t test_date_1;
		date_t DayTommorow ;
		date_t test_date_2;
		date_t *start_end_date = NULL;
		tag_t eff_d = NULLTAG;
		int		ifail	=0;
		char* lcsToset=NULL;
		tag_t class_id=NULLTAG;
		char* class_name=NULL;

		int	   status_count=0;
		int	   ss=0;
		int	   StatusFlg=0;
		tag_t* status_list = NULLTAG;

		int status;
		lcsToset =(char *) MEM_alloc(20 * sizeof(char *));
		printf("\n lifeCycleS: [%s]\n",lifeCycleS);fflush(stdout);
		printf("\n FrmNextDate ------> : %s",FromDate);
		printf("\n ToNextDate -------> : %s",ToDate);

		if(strcmp(lifeCycleS,"LcsReview")==0){strcpy(lcsToset,ERCREVIEW);}
		else if(strcmp(lifeCycleS,"LcsWorking")==0){strcpy(lcsToset,ERCREVIEW);}
		else if(strcmp(lifeCycleS,"LcsErcRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsAPLWrkg")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsAplRlzd")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsSTDWrkg")==0){strcpy(lcsToset,ERCRELEASED);}
		else if(strcmp(lifeCycleS,"LcsSTDRlzd")==0){strcpy(lcsToset,ERCRELEASED);}

		if((strcmp(lcsToset,"T5_LcsErcRlzd")==0))
		{
		    if(ITK_ok != (ifail = WSOM_ask_release_status_list(itemrev,&status_count,&status_list)))
			{
			   return ifail;
			}
			printf("\n REV status_count: %d\n",status_count);fflush(stdout);
			if (status_count == 0)  /* No Status, so the Item is not yet Released */
			{
				printf("\n No Status, so the Item is not yet Released \n");

			}else{

				for(ss=0; ss<status_count ; ss++)
				{
    			ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&class_name));
                printf("\n class_name: %s\n",class_name);fflush(stdout);
                if(strcmp(class_name,lcsToset)==0)
					{
				       StatusFlg ++;
					}
				}
			}

			printf("\n StatusFlg: [%d]\n",StatusFlg);fflush(stdout);

			if(StatusFlg != 0)
			return 0;

			printf("\n *********Stamping Releasing item*******......\n");
			if(ITK_ok != (ifail = CR_create_release_status2(lcsToset,&release_status)))	 return ifail;


			if(ITK_ok != (ifail = AOM_ask_name(release_status, &ReleaseStatus))) return ifail;
			printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);

			printf("\n release_status \n");

			if(ITK_ok != (ifail = RELSTAT_add_release_status(release_status,1,&itemrev,retain_released_date)))return ifail;

			 printf("\n 111release_status \n");

			 printf("\n FromDate..[%s]\n",FromDate);
			 printf("\n ToDate..[%s]\n",ToDate);
			 if((strcmp(FromDate,"-")==0) || (strcmp(ToDate,"-")==0))
				 return 0;

			if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&is_v7)))	 return ifail;
			printf("\n is_v7:%d\n",is_v7);
			if(is_v7 != true)
			{
				printf("\n is_v7 is not true .....\n");
			}
			else
			{
				printf("\n is_v7 is  true .....\n");
			}

			getNextDate(FromDate,FrmNextDate);
			getNextDate(ToDate,ToNextDate);
			printf("\n FrmNextDate : %s",FrmNextDate);
			printf("\n ToNextDate  : %s\n",ToNextDate);
			//if(ITK_ok != (ifail = ITK_string_to_date( cNextDate, &DayTommorow )))	return ifail;

			if(ITK_ok != (ifail = DATE_string_to_date_t(FrmNextDate, &date_is_valid, &test_date_1 )))
			{
				printf("\n date_is_valid : %d\n",date_is_valid);
				return ifail;
			}

			if(ITK_ok != (ifail = DATE_string_to_date_t(ToNextDate, &date_is_valid, &test_date_2 )))
			{
				printf("\n date_is_valid : %d\n",date_is_valid);
				return ifail;
			}

			start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

			start_end_date[0] = test_date_1;
			start_end_date[1] = test_date_2;

			if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( release_status)))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_save_without_extensions(eff_d)))
			{
				return ifail;
			}

			if(ITK_ok != (ifail = AOM_save_without_extensions(release_status)))
			{
				return ifail;
			}
			ITK_CALL(AOM_refresh( release_status, 0 ));
			printf("\n effectivity done-------------:%s",FrmNextDate);
			printf("\n 111release_status [%d] \n",ifail);fflush(stdout);

		}else
	    {

		 if(ITK_ok != (ifail = WSOM_ask_release_status_list(itemrev,&status_count,&status_list)))
			{
			   return ifail;
			}
			printf("\n REV status_count: %d\n",status_count);fflush(stdout);
			if (status_count == 0)  /* No Status, so the Item is not yet Released */
			{
				printf("\n No Status, so the Item is not yet Released \n");

			}else
				{

				for(ss=0; ss<status_count ; ss++){
    			ITK_CALL(AOM_ask_value_string(status_list[ss],"object_name",&class_name));
                printf("\n class_name: %s\n",class_name);fflush(stdout);
                if(strcmp(class_name,lcsToset)==0)
					{
				       StatusFlg ++;
					}

				}
			  }

			printf("\n StatusFlg: [%d]\n",StatusFlg);fflush(stdout);
			if(StatusFlg != 0)
			 return 0;
			printf("\n *********Stamping Releasing item*******......\n");
			if(ITK_ok != (ifail = CR_create_release_status2(lcsToset,&release_status)))	 return ifail;

			if(ITK_ok != (ifail = AOM_ask_name(release_status, &ReleaseStatus))) return ifail;
			printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);

			printf("\n release_status \n");
			ITK_CALL( RELSTAT_add_release_status(release_status,1,&itemrev,retain_released_date));
			printf("\n 111release_status [%d] \n",ifail);fflush(stdout);
		}
  return status;
}


extern int ITK_user_main (int argc, char ** argv )
{

    int status;
	int org_seq_id_int=0;
	int j=0;
	int i=0;
	int		n_strings = 1;
	int		l_strings = 80;			// Arbitrary values - Please verify proper lengths for your application!
	int		tempStrLength = 80;
	int index;
	int item_revision_id_int;
	logical isCheckOut=false;
	FILE* fp=NULL;
	FILE* fd=NULL;
	FILE* fup=NULL;
	FILE* Upfp=NULL;

	char* inputline=NULL;
	char* level=NULL;
	char* item_id=NULL;
	char* item_name=NULL;
	char* item_revision_id=NULL;
	char* item_sequence_id=NULL;
	char* desc=NULL;
	char* qty=NULL;
	char* dtype=NULL;
	char* atype="L";
	char *unit_of_measure="-";

	char* ModDescriptionDupS=NULL;
	char* mod_desc=NULL;
	char* DrawingNoDupS=NULL;
	char* Materialclass=NULL;
	char* DrawingIndDupS=NULL;
	char* DrawingIndS=NULL;
	char* MaterialDupS=NULL;
	char* MaterialS=NULL;
	char* MaterialInDrwDupS=NULL;
	char* MaterialInDrwS=NULL;
	char* LeftRhDupS=NULL;
	char* LeftRhS=NULL;
	char* DeignOwnUnitDupS=NULL;
	char* DeignOwnUnitS=NULL;
	char* ModelIndDupS=NULL;
	char* ModelIndS=NULL;
	char* UnitOfMeasureDupS=NULL;
	char* UnitOfMeasureS=NULL;
	char* ColourIndDupS=NULL;
	char* ColourIndS=NULL;
	char* WeightDupS=NULL;
	char* WeightS=NULL;
	char* MaterialThickNessS=NULL;
	char* DrawingNoS=NULL;
	char* projectcode=NULL;
	char* designgroup=NULL;
	char * rel_list=NULL;
	char * lifecycleS=NULL;

	// Added By Raghavendra B T

	char * t5SpareIndS=NULL;
	char * t5SpareCriteriaS=NULL;
	char * t5ReliabilityS=NULL;
	char * t5RefPartNumberS=NULL;
	char * t5RecyclabilityS=NULL;
	char * t5RecoverableS=NULL;
	char * t5PunMakeBuyIndS=NULL;
	char * t5PunIntialAgS=NULL;
	char * t5PrtCatCodeS=NULL;
	char * t5ProductS=NULL;
	char * t5PkgStdS=NULL;
	char * t5PartStatusS=NULL;
	char * t5PartPropertyS=NULL;
	char * t5PartCodeS=NULL;
	char * t5NcPartNoS=NULL;
	char * t5ListRecSparess=NULL;
	char * t5HomologationReqdS=NULL;
	char * t5HazardousContS=NULL;
	char * t5EnvelopeDimenS=NULL;
	char * t5DismantableS=NULL;
	char * t5ConfigIDS=NULL;
	char * t5ColourIDS=NULL;
	char * t5ClassificationHazS=NULL;
	char * t5CMVRCertificationS=NULL;
	char * t5SurfPrtStdS=NULL;
	char * t5SamplesToApprS=NULL;
	char * t5AsmDisposalS=NULL;
	char * t5FinDisposalInstrS=NULL;
	char * t5RPDisposalInstrS=NULL;
	char * t5SPDisposalInstrS=NULL;
	char * t5WIPDisposalInstrS=NULL;
	char * t5LastModByS=NULL;
	char * t5VerCreatorS=NULL;
	char * t5CAEDocES=NULL;
	char * t5CoatedS=NULL;
	char * t5ConvDocS=NULL;
	char * t5AplCopyOfErcRevS=NULL;
	char * t5AppCodeS=NULL;
	char * t5RqstNumS=NULL;
	char * t5RsnCodeS=NULL;
	char * t5SurfaceAreaS=NULL;
	char * t5VolumeS=NULL;
	char * t5CarIntialAgencyS=NULL;
	char * t5CarMakeBuyIndiS=NULL;
	char * t5ErcIndNameS=NULL;
	char * t5PostRelReqS=NULL;
	char * t5ItmCategoryS=NULL;
	char * t5CopReqS=NULL;
	char * t5AplInvalidateS=NULL;
	char * t5PrtValiStatusS=NULL;
	char * t5DRSubStateS=NULL;
	char * t5KnxtDocIndS=NULL;
	char * t5SimValS=NULL;
	char * t5PerYieldS=NULL;
	char * t5PunStoreLocationS=NULL;
	char * t5AltPartNoS=NULL;
	char * t5RolledupWtS=NULL;
	char * t5PFDModReqdS=NULL;
	char * t5ToolIndentReqdS=NULL;
	char * CategoryNameS=NULL;
	char * t5DsgnDeptS=NULL;
	char * t5AplCopyOfErcSeqS=NULL;
	char * PartTypeS=NULL;
	char * t5AhdMakeBuyIndS=NULL;
	char * t5PunPCBUMakeBuyIndS=NULL;
	char * t5DwdMakeBuyIndS=NULL;
	char * NonColorPart=NULL;
	char * NonRev=NULL;
	char * NonSeq=NULL;
	char * ClrSuperseded=NULL;
	char * ClrDateCreated=NULL;
	char *FromDate;
	char *ToDate;
	tag_t tRelationFind;
	int si;
	int lat_seq_id_int;
	int lat_seq_id_int_1;
	char *itemRevSeq = NULL;

	// Ended By Raghavendra B T

	char**	stringArray = NULL;
	tag_t newItemTag=NULLTAG;
	tag_t itemRevCreInTag=NULLTAG;
	tag_t itemRevTypeTag=NULLTAG;
	tag_t item=NULLTAG;
	tag_t ClrPartitem=NULLTAG;
	tag_t rev=NULLTAG;
	tag_t *tags_found = NULL;
	char *inputfile=NULL;
	int n_tags_found= 0;
	char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
	char **values = (char **) MEM_alloc(1 * sizeof(char *));

	char **attrs1 = (char **) MEM_alloc(1 * sizeof(char *));
	char **values1 = (char **) MEM_alloc(1 * sizeof(char *));

	 int stat_count=0;
	 int stat_count2=0;
	 tag_t relPropTag=NULLTAG ;
	 tag_t relPropTag2=NULLTAG ;
	 tag_t status2=NULLTAG ;
	 tag_t reln_type=NULLTAG ;
	 tag_t reln_type2=NULLTAG ;
	 tag_t *secondary_objects=NULLTAG ;
	 tag_t *secondary_objects2=NULLTAG ;
	 tag_t *status1=NULL;
	 tag_t  attr_name_id   = NULLTAG;
	 tag_t  primary=NULLTAG,objTypeTag=NULLTAG;
	 tag_t  primary2=NULLTAG,objTypeTag2=NULLTAG;
     char   *value         = NULL;
     char   *eff_date         = NULL;
	 tag_t class_id = NULLTAG;
	 char szClassName[100 + 1] = "";
     logical is_it_empty = FALSE;
     logical is_it_null  = FALSE;
     logical is_loaded   = FALSE;
	 char   type_name[100+1];
	 char   type_name2[100+1];
	 int release_status   = 0;
	 FILE* fperror=NULL;
	 char * Owne_site ;
	 tag_t	new_object		= NULLTAG;
	tag_t	latest_rev		= NULLTAG;
	tag_t	ClrPartRev		= NULLTAG;
	tag_t	latestrev		= NULLTAG;
	tag_t	class_id1		= NULLTAG;
	char *class_name;
	tag_t queryds = NULLTAG;
	tag_t queryes = NULLTAG;
	int n_entriesds=1;
	int ds_tags_found=0;
	tag_t	*itemrevdsclass	= NULLTAG;
	tag_t	DesignrevTag	= NULLTAG;
	tag_t relation_type;
	tag_t 	   Rel_task	= NULLTAG;
	tag_t  	   tRelationExist = NULLTAG;
	tag_t	ItemTag	= NULLTAG;
	tag_t   queryds1 = NULLTAG;
	logical design_Required = false;
	tag_t	*rev1 	= NULL;
	int n_rev =0;

	//int ds_tags_found=0;
	char	*itemRevSeq1	 = NULL;
	char **qry_valuesds = (char **) MEM_alloc(50 * sizeof(char *));
	int n_entries = 3;
	char *qry_entriesds[3] = {"Revision","Sequence Id","ID"};

	char *szbom_revision_status = NULL;
	tag_t   window, window2, rule, item_tag = null_tag, top_line;

	char *FileDown = NULL;
	FileDown=(char *) MEM_alloc(100 * sizeof(char ));

	char *FileUp = NULL;
	FileUp=(char *) MEM_alloc(100 * sizeof(char ));

	char *FilenonBom = NULL;
	FilenonBom=(char *) MEM_alloc(100 * sizeof(char ));

	inputfile = ITK_ask_cli_argument("-i=");
	
	/*
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	//ITK_CALL(ITK_auto_login( ));
	if( ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......");fflush(stdout);
	*/
	
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Line  ====%s ",inputfile );fflush(stdout);

	fp=fopen(inputfile,"r");
	//fperror=fopen("error.log","a");

	strcpy(FileDown,"");
	strcat(FileDown,"CreateClrBOM.txt");
	printf("\n FileDown---------> %s\n",FileDown);fflush(stdout);
	fd=fopen(FileDown,"w");
	fflush(fd);

	strcpy(FilenonBom,"");
	strcat(FilenonBom,"CreateNonClrBOM.txt");
	printf("\n FilenonBom---------> %s\n",FilenonBom);fflush(stdout);
	Upfp=fopen(FilenonBom,"w");
	fflush(Upfp);

	strcpy(FileUp,"");
	strcat(FileUp,"NonClrNOTPresent.txt");
	printf("\n FileUp---------> %s\n",FileUp);fflush(stdout);
	fup=fopen(FileUp,"w");
	fflush(fup);
	
	fprintf(fd,"#DELIMITER ^\n"); fflush(fd);
	fprintf(fd,"#COL   Level  item  rev Seq desc occs Name Uom Qty LhRh\n"); fflush(fd);

	if(fp!=NULL)
	{
		printf("fp----------------------------------------------------\n");
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			fputs(inputline,stdout);
			level=strtok(inputline,"^");  
			item_id=strtok(NULL,"^");  
			item_revision_id=strtok(NULL,"^"); 
			item_sequence_id=strtok(NULL,"^"); 
			desc=strtok(NULL,"^");
			ColourIndS=strtok(NULL,"^");
			t5PrtCatCodeS=strtok(NULL,"^");
			t5ColourIDS=strtok(NULL,"^");
			t5CoatedS=strtok(NULL,"^");
			t5PartStatusS=strtok(NULL,"^");
			designgroup=strtok(NULL,"^");
			projectcode=strtok(NULL,"^");
			lifecycleS=strtok(NULL,"^");
			mod_desc=strtok(NULL,"^");
			DrawingIndS=strtok(NULL,"^");
			PartTypeS=strtok(NULL,"^");
			t5PartCodeS=strtok(NULL,"^");			
			FromDate=strtok(NULL,"^");
			ToDate=strtok(NULL,"^");
			NonColorPart=strtok(NULL,"^");
			NonRev=strtok(NULL,"^");
			NonSeq=strtok(NULL,"^");
			ClrSuperseded=strtok(NULL,"^");
			ClrDateCreated=strtok(NULL,"^");

			printf("level [%s]\n",level);fflush(stdout);
			printf("item_id [%s]\n",item_id);fflush(stdout);
			printf("item_revision_id [%s]\n",item_revision_id);fflush(stdout);
			printf("item_sequence_id [%s]\n",item_sequence_id);fflush(stdout);
			printf("desc [%s]\n",desc);fflush(stdout);
			printf("ColourIndS [%s]\n",ColourIndS);fflush(stdout);
			printf("t5PrtCatCodeS [%s]\n",t5PrtCatCodeS);fflush(stdout);
			printf("t5ColourIDS [%s]\n",t5ColourIDS);fflush(stdout);
			printf("t5CoatedS [%s]\n",t5CoatedS);fflush(stdout);
			printf("t5PartStatusS [%s]\n",t5PartStatusS);fflush(stdout);
			printf("designgroup [%s]\n",designgroup);fflush(stdout);
			printf("projectcode [%s]\n",projectcode);fflush(stdout);
			printf("lifecycleS [%s]\n",lifecycleS);fflush(stdout);
			printf("mod_desc [%s]\n",mod_desc);fflush(stdout);
			printf("DrawingIndS [%s]\n",DrawingIndS);fflush(stdout);
			printf("PartTypeS [%s]\n",PartTypeS);fflush(stdout);
			printf("t5PartCodeS [%s]\n",t5PartCodeS);fflush(stdout);
			printf("FromDate [%s]\n",FromDate);fflush(stdout);
			printf("ToDate [%s]\n",ToDate);fflush(stdout);
			printf("NonColorPart [%s]\n",NonColorPart);fflush(stdout);
			printf("NonRev [%s]\n",NonRev);fflush(stdout);
			printf("NonSeq [%s]\n",NonSeq);fflush(stdout);
			printf("ClrSuperseded [%s]\n",ClrSuperseded);fflush(stdout);
			printf("ClrDateCreated [%s]\n",ClrDateCreated);fflush(stdout);
			
			item_revision_id_int=atoi(item_sequence_id);			
			attrs[0] ="item_id";
			values[0] = (char *)item_id;
		    ITK_CALL(ITEM_find_item(item_id,&item));
			
			ITK_CALL(QRY_find2("GetLatestItemRev", &queryds));
			printf("\n found qryy ");fflush(stdout);
			char *qry_entriesds[1] = {"ID"}, *qry_valuesds[1] =  {NonColorPart};

			ITK_CALL(QRY_execute(queryds, n_entriesds, qry_entriesds, qry_valuesds, &ds_tags_found, &itemrevdsclass));
			printf("\n ds_tags_found :: %d\n", ds_tags_found);fflush(stdout);
			
			if(tc_strcmp(item_id,"544254245054RZZ")!=0)
			{
			if(ds_tags_found > 0)
			{	
				if(item==NULLTAG)
				{
						itemRevSeq = NULL;
						itemRevSeq=(char *) MEM_alloc(32);
						strcpy(itemRevSeq,item_revision_id);
						strcat(itemRevSeq,";");
						strcat(itemRevSeq,item_sequence_id);

						printf("\n itemRevSeq : [%s] ",itemRevSeq);fflush(stdout);
					
						ITK_CALL(ITEM_create_item(item_id,item_id,"T5_ClrPart",default_empty_to_A(itemRevSeq),&item,&rev));
						printf("\n T5_ClrPart is created----------> [%s]\n",itemRevSeq);fflush(stdout);
						
						setAttributesOnDesignRev(&rev,item_id,item_revision_id_int,desc,ColourIndS,t5PrtCatCodeS,t5ColourIDS,t5CoatedS,t5PartStatusS,designgroup,projectcode,mod_desc,DrawingIndS,PartTypeS,t5PartCodeS,t5AhdMakeBuyIndS,t5PunPCBUMakeBuyIndS,t5PunMakeBuyIndS,t5DwdMakeBuyIndS,NonColorPart);
						printf("\n Set Attribute on Class T5_ClrPartRevision--------->\n");
						
						setAttributesOnDesign(&item,item_id,desc,"4");					
						printf("\n Set Attribute on Class T5_ClrPart------------>\n");fflush(stdout);
								
						ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
						printf("\n CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(stdout);

						ITK_CALL(AssignProject(rev,projectcode));
						printf("\n Assign Project to T5_ClrPartsRevision--------->\n");	fflush(stdout);

						ITK_CALL(setDateCreationOnRev(rev,ClrDateCreated));
						printf("\n Set ClrDateCreated on Class T5_ClrPartRevision------------>\n");fflush(stdout);
				}
				else
				{
						printf("Item already exists\n");fflush(stdout);
						
						
						itemRevSeq = NULL;
						itemRevSeq=(char *) MEM_alloc(32);
						strcpy(itemRevSeq,item_revision_id);
						strcat(itemRevSeq,";");
						strcat(itemRevSeq,item_sequence_id);
						printf("\n Revision & seq for Color Part to find is :: %s\n",itemRevSeq);fflush(stdout);

						ITK_CALL(ITEM_find_revision(item,itemRevSeq,&rev));
						if(rev != NULLTAG)
						{
							printf("\n required revision is already exists in PLM------>\n");fflush(stdout);

							//setAttributesOnDesignRev(&rev,item_id,item_revision_id_int,desc,ColourIndS,t5PrtCatCodeS,t5ColourIDS,t5CoatedS,t5PartStatusS,designgroup,projectcode,mod_desc,DrawingIndS,PartTypeS,t5PartCodeS,t5AhdMakeBuyIndS,t5PunPCBUMakeBuyIndS,t5PunMakeBuyIndS,t5DwdMakeBuyIndS,NonColorPart);
							//printf("\n Set Attribute on Class T5_ClrPartRevision--------->\n");
							
							//setAttributesOnDesign(&item,item_id,desc,"4");					
							//printf("\n Set Attribute on Class T5_ClrPart------------>\n");fflush(stdout);
			
							//ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
							//printf("\n CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(stdout);

							//ITK_CALL(AssignProject(rev,projectcode));
							//printf("\n Assign Project to T5_ClrPartsRevision--------->\n");	fflush(stdout);

							//ITK_CALL(setDateCreationOnRev(rev,ClrDateCreated));
							//printf("\n Set ClrDateCreated on Class T5_ClrPartRevision------------>\n");fflush(stdout);

						}
						else
						{
								printf("Item Revision not found\n");
								itemRevSeq = NULL;
								itemRevSeq=(char *) MEM_alloc(32);
								strcpy(itemRevSeq,item_revision_id);
								strcat(itemRevSeq,";");
								strcat(itemRevSeq,item_sequence_id);
								printf("\n itemRevSeq--------->%s\n",itemRevSeq);

								ITK_CALL(ITEM_create_rev(item,default_empty_to_A(itemRevSeq),&rev));
								ITK_CALL(AOM_save_without_extensions(rev));
								ITK_CALL(AOM_unlock(rev));

								setAttributesOnDesignRev(&rev,item_id,item_revision_id_int,desc,ColourIndS,t5PrtCatCodeS,t5ColourIDS,t5CoatedS,t5PartStatusS,designgroup,projectcode,mod_desc,DrawingIndS,PartTypeS,t5PartCodeS,t5AhdMakeBuyIndS,t5PunPCBUMakeBuyIndS,t5PunMakeBuyIndS,t5DwdMakeBuyIndS,NonColorPart);
								printf("\n Set Attribute on Class T5_ClrPartRevision--------->\n");
								
								setAttributesOnDesign(&item,item_id,desc,"4");					
								printf("\n Set Attribute on Class T5_ClrPart------------>\n");fflush(stdout);
				
								ITK_CALL(CreateEffctivity(rev,FromDate,ToDate,lifecycleS));
								printf("\n CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(stdout);

								ITK_CALL(AssignProject(rev,projectcode));
								printf("\n Assign Project to T5_ClrPartsRevision--------->\n");	fflush(stdout);

								ITK_CALL(setDateCreationOnRev(rev,ClrDateCreated));
								printf("\n Set ClrDateCreated on Class T5_ClrPartRevision------------>\n");fflush(stdout);
								printf("Item Revision Created\n");
						}
						
					}
					
					printf("ClrSuperseded for Color Part is :: [%s]\n",ClrSuperseded);fflush(stdout);
					if(tc_strcmp(ClrSuperseded,"-")==0)
					{						
						int n_tags_found2=0;
						tag_t *tags_found2 = NULL;
						fprintf(fd,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s\n",level,item_id,item_revision_id,item_sequence_id,desc,"1",item_id,"-","1",""); fflush(fp);															
						const char *attrs2[2];
						const char *values2[2];
						attrs2[0] ="item_id";
						attrs2[1] ="object_type";
						values2[0] = (char *)NonColorPart;
						values2[1] = "Design";
						if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2));
						printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);
						if(n_tags_found2 > 0)
						{
							ItemTag = tags_found2[0];
							MEM_free(tags_found2);							
							
							ITK_CALL(ITEM_ask_latest_rev(ItemTag,&latestrev));
							printf("\n ITEM_ask_latest_rev-------->\n");fflush(stdout);

							ITK_CALL(ITEM_ask_latest_rev(item,&ClrPartRev));
							printf("\n ITEM_ask_latest_rev Color Part-------->\n");fflush(stdout);						
							
							ITK_CALL(GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind));
							if(tRelationFind!=NULLTAG)
							{
								ITK_CALL(GRM_find_relation(ClrPartRev,latestrev,tRelationFind,&tRelationExist));
								if(tRelationExist == NULLTAG)
								{
									ITK_CALL(GRM_create_relation(ClrPartRev,latestrev,tRelationFind,NULLTAG,&Rel_task));
									ITK_CALL(AOM_load(Rel_task)); 								
									ITK_CALL(GRM_save_relation(Rel_task)); 
									ITK_CALL(AOM_refresh(Rel_task,0));
									printf("\nRelation Created Successfully\n");fflush(stdout);
								}							
							}							
						}											
				    }
					else { printf(" Relationship with noncolour is not created----------->\n"); }
					fprintf(Upfp,"%s^%s^%s^%s^%s^%s^%s\n",level,item_id,item_revision_id,item_sequence_id,NonColorPart,NonRev,NonSeq); fflush(Upfp);
			}
			else
			{				
				fprintf(fup,"%s^%s^%s^%s\n",level,NonColorPart,NonRev,NonSeq); fflush(fp);
				printf("\n Please confirm Non-Colour Part in PLM before loading Colour Part\n");		
			}
			}
	
			//wait();
			//sleep(5);
			printf("----------------------------------------------------\n");
		}

		return status;
	}	

	ITK_CALL(POM_logout(false));
	if(fd)fclose(fd);fd=NULL;
	if(fup)fclose(fup);fup=NULL;
	if(Upfp)fclose(Upfp);Upfp=NULL;
	return status;
}
