/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Ritik Dadhe
*  Module		 :   T4B04 Correction
*  Code			 :   Colour_CC_for_Clr_T4B04.c
*  Module		 :   Modify Current View Mask Property of Module T4B04 through CC (Color VC)
*  Created on	 :   August 21, 2025
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes

* Input: Colour_CC_for_Clr_T4B04 -u=username -p=password -g=PLM_Support_Group -File=Input.txt
 Input.txt format: 

54420528RZV;E;1
54420528RZY;E;1
54420528RZX;E;1
54420528RZW;E;1

***************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>
#include <ae/dataset_msg.h>
//#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <stdio.h>
//#include "tm_apl_std_common_function.c"
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)



#define Debug TRUE


#define ITK_CALL(x)                                                                 \
	{                                                                               \
		int stat;                                                                   \
		char *err_string;                                                           \
		if ((stat = (x)) != ITK_ok)                                                 \
		{                                                                           \
			EMH_ask_error_text(stat, &err_string);                       \
			printf("\n ERROR: %d ERROR MSG: %s.\n", stat, err_string);              \
			printf("\n FUNCTION: %s\nFILE: %s LINE: %d\n", #x, __FILE__, __LINE__); \
			if (err_string)                                                         \
				MEM_free(err_string);                                               \
			exit(EXIT_FAILURE);                                                     \
		}                                                                           \
	}

extern int ITK_user_main (int argc, char ** argv )
{
    char*						InputfileS			    	=	NULL;
    char*						FuelType			    	=	NULL;
    char*						partNumber		        	=	NULL;
    char*						revision					=	NULL;
	char*						view_name					= 	NULL;
	char*						ItemRevView_name			=	NULL;
	char*						class_name					=	NULL;
	char*						cProjectCode				=	NULL;
	char*						objectString				=	NULL;
	char*						Revitem_id					=	NULL;
	char*						item_id 					= 	NULL;
	char* 						Revision_string				=	NULL;
	char*						Part_Rev 					= 	NULL;
	char*						Part_rev_Id 				= 	NULL;
	char*						attributeNameDup 			= 	NULL;
	char*						attributeValueDup 			= 	NULL;
	char* 						attrId 						= 	NULL;
	char**						theAttributeNames 			= 	NULL;
	char***       				theAttributeValues 			= 	NULL;
	char***       				theAttributeOptimizedUnits 	= 	NULL;
	char                        fileRead[100];
   
	tag_t						window 					= 	NULLTAG;
	tag_t 						ColSchmRevTag			= 	NULLTAG;
	tag_t 						query1 					= 	NULLTAG;
	tag_t 						query2 					= 	NULLTAG;
	tag_t 						Design_rev_cls_tag    	= 	NULLTAG;
	tag_t						DesignMasterTag			= 	NULLTAG;
	tag_t						RevisionTag				= 	NULLTAG;
	tag_t						item_tag				= 	NULLTAG;
	tag_t*                     	bvr_assy_part       	= 	NULLTAG;
	tag_t*						CntrlObjs				=	NULLTAG;
	tag_t*						CntrlObjs1				=	NULLTAG;
	tag_t*						rev_list				= 	NULLTAG;
	tag_t*						status_list				= 	NULLTAG;

    int                         ifail                   =   ITK_ok;
	int 						cntt					=	0;
	int 						cntt1					=	0;
	int 						Z,ii,iLCS,ic,xc			=	0;
	int 						n_entries1				=	2;
	int 						n_entries2				=	1;
	int 						n_found1				=	0;
	int 						n_found2				=	0;
	int							t5NoEcuDupint  			=	0;
	int 						theAttributeCount 		=	0;
	int 						Item_count				=	0;
	int 						st_count				=	0;
	int*						theAttributeValCounts	=	0;
	int*						theAttributeIds ;

	char	*cUserName		=	NULL;
	char	*cPassWord		=	NULL;
	char	*cUserGrp		=	NULL;
	
	tag_t   t_ChildItemRev;

	attrId 				= (char *) MEM_alloc( 50 * sizeof(char) );

	attributeValueDup 	= (char *) MEM_alloc( 5000 * sizeof(char) );

    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	//ITK_CALL(ITK_auto_login( ));

	cUserName		=	ITK_ask_cli_argument("-u=");
	cPassWord		=	ITK_ask_cli_argument("-p=");
	cUserGrp		=	ITK_ask_cli_argument("-g=");
    InputfileS 		= 	ITK_ask_cli_argument("-File=");
  //  FuelType 		= 	ITK_ask_cli_argument("-Ftype=");

	
	
	ITK_CALL(ITK_init_module(cUserName,cPassWord,cUserGrp));
	
	printf("\n *****************___Login Successfully...___***************** \n");fflush(stdout);

  
   // InputfileS = ITK_ask_cli_argument("-File=");

    FILE  *Ifp = NULL;
	Ifp=fopen(InputfileS,"r");

	FILE *file = fopen("T4B04_Correction_Required.txt", "w");

	FILE *NRfile = fopen("T4B04_Correction_Not_Required.txt", "w");

	fprintf(file, "Vehicle/Rev^APPLICABILITY^BEFORE^AFTER\n");
	
	while(fgets(fileRead,100,Ifp)!=NULL)
	{
		printf("\nAt Begining of While Loop..\n");fflush(stdout);
		
		partNumber	=strtok(fileRead,";");
		revision	=strtok(NULL,";");

		printf("Part Number: %s\n", partNumber);
		printf("RevSequence: %s\n", revision);

		MEM_free(Revision_string);
		Revision_string=(char *)MEM_alloc(200);
		tc_strcpy(Revision_string,revision);
		tc_strcat(Revision_string,"*");

		printf("\n Revision_string --> : %s\n",Revision_string); fflush(stdout);

		char
		*qry_entry[2] = {"Item ID","Revision"},
		*qry_vall[2] =  {partNumber,Revision_string};

		ITKCALL( QRY_find2("Item Revision...", &query1));

		printf("\n After Searching Query... ");fflush(stdout);

		ITKCALL(QRY_execute(query1, n_entries1, qry_entry, qry_vall, &n_found1, &CntrlObjs));

		printf("\n n_found1: %d", n_found1);fflush(stdout);

		if(n_found1>0)
		{

			for (cntt = 0; cntt < n_found1; cntt++)
			{				
				ColSchmRevTag=CntrlObjs[cntt];
				
				ITK_CALL(AOM_ask_value_string(ColSchmRevTag,"object_name",&view_name));
				printf("\n Object Name: %s",view_name);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(ColSchmRevTag,"item_revision_id",&ItemRevView_name));
				printf("\n Given Revision: %s\n",ItemRevView_name);fflush(stdout);
				ITKCALL(AOM_ask_value_string(ColSchmRevTag, "item_id", &item_id));

			//	if(tc_strcmp(ItemRevView_name,"NR")!=0)
			//	{
			//		ITKCALL(AOM_ask_value_string(ColSchmRevTag,"item_revision_id",&Part_Rev));
			//		printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
				
					ITKCALL(AOM_ask_value_tags(ColSchmRevTag,"revision_list",&Item_count,&rev_list));
					printf("\nNo of Revisions: %d",Item_count);fflush(stdout);
				
					if(Item_count > 0)
					{
						int PreRevFlag	=	0;
				
						for(ii=Item_count-1;ii>=0;ii--)
						{
				
							ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

							printf("\n................................................................................................................... \n");
				
							printf("\n Revision : %s", Part_rev_Id);fflush(stdout);

							ITKCALL(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
							for (iLCS=0;iLCS<st_count ;iLCS++ )
							{
								ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
								printf("\n Released Status: %s\n",class_name);fflush(stdout);
								
								// Latest STD Released Object
								//

								if((tc_strcmp(class_name,"T5_LcsStdRlzd")==0) || (tc_strcmp(class_name,"T5_LcsAPLWrkg")==0) || (tc_strcmp(class_name,"T5_LcsAplRlzd")==0) ||(tc_strcmp(class_name,"T5_LcsSTDWrkg")==0))
								{
									ITKCALL(AOM_ask_value_string(rev_list[ii],"t5_ProjectCode",&cProjectCode));

									printf("\n Project Code: %s\n",cProjectCode);fflush(stdout);					

									ITKCALL(AOM_ask_value_string(rev_list[ii],"item_id",&Revitem_id));

									printf("\n Rev_Item_ID: %s\n",Revitem_id);fflush(stdout);	
									
									char nonClrVeh[10];   // 9 chars + null terminator

									strncpy(nonClrVeh, Revitem_id, 9);
									nonClrVeh[9] = '\0';   // Ensure null-termination

									printf("First 9 chars: %s\n", nonClrVeh);
										
									if(ITEM_find_item(nonClrVeh,&item_tag)!=ITK_ok);
										

									tag_t			classificationObject = NULLTAG;
									int theAttributeCount =0;
									int *theAttributeIds ;
									char 			**theAttributeNames;
									int *theAttributeValCounts=0;
									char***       theAttributeValues;
									char***       theAttributeOptimizedUnits;
									char* 	attrId 					= NULL;
									attrId = (char *) MEM_alloc( 50 * sizeof(char) );
									char 	*attributeNameDup 			= NULL;
									char 	*attributeValueDup 			= NULL;
									attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
									attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
									int i,x=0;
									int TotVCAttrCount=0;
							
									char*	 ModelrevPartRev = NULL;

									ITK_CALL(ICS_ask_classification_object(item_tag,&classificationObject));

									if (classificationObject != NULLTAG)
									{
										ITK_CALL( ICS_ico_ask_attributes_optimized(classificationObject,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
										//printf("### ICS_ico_ask_named_attributes nAttributes = %d\n", theAttributeCount);fflush(stdout);

										if(theAttributeCount>0)
										{
											for(ic=0;ic<theAttributeCount;ic++)
											{
												sprintf(attrId,"%d",theAttributeIds[ic]);

												tc_strcpy(attributeNameDup,"");
												tc_strcpy(attributeNameDup,theAttributeNames[ic]);

												if(tc_strcmp(attributeNameDup,"[VC]FUEL(FUEL)")==0)
												{
													tc_strcpy(attributeValueDup,"");
													for(xc=0;xc<theAttributeValCounts[ic];xc++)
													{
														//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[ic][x]);fflush(stdout);
														tc_strcat(attributeValueDup,theAttributeValues[ic][xc]);
														//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
													}

													printf("\n theAttribute Name :[%s]",attributeNameDup,ic);fflush(stdout);
													//printf("\n attrId:[%s]",attrId);fflush(stdout);//
													printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);

													t5NoEcuDupint=atoi(attributeValueDup);
													//printf("\n final ECU COUNT is t5NoEcuDupint  =%d",t5NoEcuDupint); fflush(stdout);//10*/

                                                    
                                                    printf("\n Fuel_Type : %s\n",attributeValueDup);fflush(stdout);

													char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
													char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));
													
													tag_t   qryTagCntrl			= NULLTAG;
													tag_t*	list_of_WSO_cntrl_tags = NULLTAG;
													
													int     n_entryCntrl					= 3;
													int		control_number_found_APLPltInf	= 0;

													char	*ApplicableProjCodes	= NULL;
																																				
													if( QRY_find2("Control Objects...", &qryTagCntrl));
													if (qryTagCntrl)
													{
														printf("\n Control Object Query Found \n");fflush(stdout);
														qry_valuesCntrl[0]="CAR";
														qry_valuesCntrl[1]="T4B04";  
														qry_valuesCntrl[2]="0";
														
														if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found_APLPltInf, &list_of_WSO_cntrl_tags));
													}
													else
													{
														printf("\n Control Object Query not Found \n");fflush(stdout);
													}	
														
													printf("\n control_number_found_T4B04 is : %d\n",control_number_found_APLPltInf);fflush(stdout);
													
													if(control_number_found_APLPltInf>0)
													{			
														AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo1", &ApplicableProjCodes);
														printf("\n ApplicableProjCodes: %s\n",ApplicableProjCodes);fflush(stdout);
													
														tm_validate_t4b04module(file, NRfile, rev_list[ii],cProjectCode,ApplicableProjCodes,attributeValueDup,class_name);
														// Break it
													}
												}
											}
										}
										else
										{
											printf("\n VCclassificationObject NOt found");fflush(stdout);
										}
									}
								}						
							}
						}
					}
			//	}
			}
		}
	}
	return ITK_ok;
}



void tm_validate_t4b04module(FILE *file, FILE* NRfile, tag_t t_currentRevision,char* cProjectCode, char* COApplicableProjCode, char* VehType, char* release_status)
{

	tag_t						ClrPrtwindow 			= 	NULLTAG;
	tag_t 						ClrPrtrule				= 	NULLTAG;
	tag_t			 			bvr_tag					= 	NULLTAG;
	tag_t						top_line				= 	NULLTAG;
	tag_t*	         			chldParts       		= 	NULLTAG;
	tag_t*						status_list				=	NULLTAG;

	int 						noprts,Z,O,st_count,PreRevFlag,iLCS				=	0;

	char*						VehicleNum				=	NULL;
	char*						VehicleNumRev			=	NULL;
	char*						ViewMask				=	NULL;
	char*						quantity				=	NULL;
	char*						object_string			=	NULL;
	char*						item_revision_id			=	NULL;
	char* class_name=NULL;

	ITKCALL(AOM_ask_value_string(t_currentRevision,"object_name",&object_string));
	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&item_revision_id));
	printf("\n Vehicle : %s\n",object_string);fflush(stdout);
	printf("\n release_status : %s\n",release_status);fflush(stdout);

	ITKCALL(WSOM_ask_release_status_list(t_currentRevision,&st_count,&status_list));
	for (iLCS=0;iLCS<st_count ;iLCS++ )
	{
		ITKCALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
		printf("\n class_name: %s\n",class_name);fflush(stdout);
		
		if(tc_strcmp(class_name,"T5_LcsStdRlzd")==0)
		{
			PreRevFlag = 1;
			break;
		}
	}


	ITK_CALL(BOM_create_window (&ClrPrtwindow));
	ITK_CALL(CFM_find("STDC Released and Above", &ClrPrtrule));

	ITK_CALL(BOM_set_window_config_rule(ClrPrtwindow, ClrPrtrule));
	ITK_CALL(BOM_set_window_top_line(ClrPrtwindow, NULLTAG, t_currentRevision, bvr_tag, &top_line));

	ITK_CALL(BOM_set_window_pack_all(ClrPrtwindow, false));
	ITK_CALL(BOM_line_ask_child_lines(top_line,&noprts,&chldParts));

	printf(" VC child parts count: %d\n",noprts);

	int FlagT4B04 =0;
	
	for(Z=0;Z<noprts;Z++)
	{
							
		ITK_CALL(AOM_ask_value_string(chldParts[Z],"bl_item_item_id",&VehicleNum));
		
		ITK_CALL(AOM_ask_value_string(chldParts[Z],"bl_rev_item_revision_id",&VehicleNumRev));
								
		if((tc_strstr(VehicleNum, "T4B04") != NULL))							
		{

			ITK_CALL(BOM_line_unpack (chldParts[Z]));
			
			printf("\n--------------------xxx-------------------------------- \n");

			printf("Got T4B04 ERC Module from BOM ..... \n");
			printf("\n\nModule:\t%s/%s\n",VehicleNum,VehicleNumRev);fflush(stdout);
			//printf("\nT4B04 Module Revision:\t%s\n",VehicleNumRev);fflush(stdout);	
								
			ITK_CALL(AOM_ask_value_string(chldParts[Z],"bl_occ_t5_CurrentViewMaskC",&ViewMask));
			printf("\nCVM:\t%s\n",ViewMask);fflush(stdout);

			printf("\ncProjectCode:\t%s\n",cProjectCode);fflush(stdout);
			printf("\nCOApplicableProjCode:\t%s\n\n",COApplicableProjCode);fflush(stdout);
			

			// Create a new string with commas at the start and end of variable2
			char modifiedVariable2[256];
			snprintf(modifiedVariable2, sizeof(modifiedVariable2), ",%s,", COApplicableProjCode);
		
			// Create the search pattern with commas at the start and end
			char searchPattern[64];
			snprintf(searchPattern, sizeof(searchPattern), ",%s,", cProjectCode);
		
			// Use strstr to search for the pattern

			// CHECK CONTROL OBJECT PROJECT CODE AND VEHICLE PROJECT CODE ARE SAME
			if (strstr(modifiedVariable2, searchPattern) != NULL)
			{
				
				if((tc_strstr(VehType,"DIESEL")!=NULL)  || (tc_strstr(VehType,"EV"))|| (tc_strstr(VehType,"ELECTRIC")))	// Add ELECTRIC
				{
					if(tc_strcmp(ViewMask,"")==0) 
					{
						printf("\nPART: %s/%s\n", object_string,item_revision_id);
						printf("\nCVM is already ENABLED for all Agencies...!\n");
						fprintf(NRfile, "%s/%s^%s\n", object_string,item_revision_id,ViewMask);
						FlagT4B04++;										
					}
					else
					{						
						FlagT4B04++;
						//WRITE IN LOG FILE WHEN VEHICLE STDC RELEASED AND CHANGES REQUIRED--> TO SEND SAP					
						printf("\nPreRevFlag:\t%d\n", PreRevFlag);
						if (PreRevFlag == 1)
						{
							fprintf(file, "%s/%s^APPLICABLE^%s^TO^ENABLED for all Agencies\n", object_string,item_revision_id,ViewMask);							
						}

						printf("\nPART: %s/%s\n", object_string,item_revision_id);
						printf("\nCVM is not ENABLED for all Agencies...Going to change it...! %s/%s\n",object_string,item_revision_id);
						ITK_CALL(AOM_set_value_string(chldParts[Z],"bl_occ_t5_CurrentViewMaskC",""));
						printf("\n<<<<<<-----------------------T4B04 Found and set CVM (ENABLED for all Agencies)----------------------->>>>>>>>>>>>>>>\n");
					}
						
				}
				else
				{
					if(tc_strcmp(ViewMask,"0--")==0) 
					{
						printf("\nPART: %s/%s\n", object_string,item_revision_id);
						printf("\nCVM is alredy ( 0-- )...!");
						fprintf(NRfile, "%s/%s^%s\n", object_string,item_revision_id,ViewMask);
						FlagT4B04++;										
					}
					else
					{
						FlagT4B04++;
						//WRITE IN LOG FILE WHEN VEHICLE STDC RELEASED AND CHANGES REQUIRED--> TO SEND SAP
						printf("\nPreRevFlag:\t%d\n", PreRevFlag);

						if (PreRevFlag == 1)
						{
							fprintf(file, "%s/%s^APPLICABLE^%s^TO^0--\n", object_string,item_revision_id,ViewMask);							
						}
						printf("\nPART: %s/%s\n", object_string,item_revision_id);
						printf("\nCVM is not 0--...Going to change it...! %s/%s\n",object_string,item_revision_id);
						ITK_CALL(AOM_set_value_string(chldParts[Z],"bl_occ_t5_CurrentViewMaskC","0--"));
						printf("\n<<<<<<-----------------------T4B04 Found and set CVM (0--)----------------------->>>>>>>>>>>>>>>\n");						
						
					}
				}					
			}
			else
			{
				printf("\n<<<<<<-----------------------Control Object is not found for this project code----------------------->>>>>>>>>>>>>>>\n");

				printf("\n<<<<<<-----------------------Checking T4B04 Module is have CVM is (0--)----------------------->>>>>>>>>>>>>>>\n");
				if(tc_strcmp(ViewMask,"0--")==0) 
				{
					printf("\nPART: %s/%s\n", object_string,item_revision_id);
					printf("\nCVM is alredy 0--...!");
					fprintf(NRfile, "%s/%s^%s\n", object_string,item_revision_id,ViewMask);
					FlagT4B04++;										
				}
				else
				{
					//WRITE IN LOG FILE WHEN VEHICLE STDC RELEASED AND CHANGES REQUIRED--> TO SEND SAP
					FlagT4B04++;
					printf("\nPreRevFlag:\t%d\n", PreRevFlag);

					if (PreRevFlag == 1)
					{
						fprintf(file, "%s/%s^NOT APPLICABLE^%s^TO^0--\n",object_string,item_revision_id,ViewMask);
					}
					printf("\nPART: %s/%s\n", object_string,item_revision_id);
					printf("\nCVM is not 0--...Going to change it...! %s/%s\n",object_string,item_revision_id);
					ITK_CALL(AOM_set_value_string(chldParts[Z],"bl_occ_t5_CurrentViewMaskC","0--"));
					printf("\n<<<<<<-----------------------T4B04 Found and set CVM (0--)----------------------->>>>>>>>>>>>>>>\n");
					
				}
			}												
		}	
	}

	printf("\n Final Flag Value %d\n",FlagT4B04);
	
	char*						VehicleNum1				=	NULL;
	char*						VehicleNumRev1			=	NULL;

	if(FlagT4B04>=2)
	{
		printf("\nGot Two T4B04 Modules...\n");
		for(O=0;O<noprts;O++)
		{
			ITK_CALL(AOM_ask_value_string(chldParts[O],"bl_item_item_id",&VehicleNum1));

			//printf("\n\nVehicle_Number:				 %s\n",VehicleNum);fflush(stdout);
			
			ITK_CALL(AOM_ask_value_string(chldParts[O],"bl_rev_item_revision_id",&VehicleNumRev1));
									
			if((tc_strstr(VehicleNum1, "T4B04") != NULL))							
			{
				ITK_CALL(AOM_ask_value_string(chldParts[O],"bl_quantity",&quantity));
				printf("\n\nQuantity1:\t%s\n",quantity);fflush(stdout);
				
			//	ITK_CALL(BOM_set_window_pack_all(ClrPrtwindow, false));
				printf("\nPART: %s/%s\n", object_string,item_revision_id);
				printf("\nPreRevFlag:\t%d\n", PreRevFlag);

				if (PreRevFlag == 1)
				{
					fprintf(file, "%s/%s^TWO QUANTITY^MODULE REMOVE FROM BOM\n", object_string,item_revision_id);					
				}

				ITK_CALL(BOM_line_unpack (chldParts[O]));

				printf("Got T4B04 ERC Module from BOM ..... \n");
				printf("\n\nModule:\t%s/%s\n",object_string,item_revision_id);fflush(stdout);
				printf("\nGoing to cut Module from BOMLine... \n");
				
				ITK_CALL(BOM_line_cut(chldParts[O]));
				ITK_CALL(BOM_save_window(ClrPrtwindow));

					
				break;

			}
		}
	}
}
