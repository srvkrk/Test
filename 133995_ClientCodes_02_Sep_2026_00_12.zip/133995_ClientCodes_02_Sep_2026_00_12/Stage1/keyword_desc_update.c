/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: keyword_desc_update.c
**
** Functions:- 	This utility takes the module_id as input from file and find it's latest revision in teamcenter then get it's module_name attr_value and 
**				stamps it on item's and item revision's specific attributes.(object_desc, object_name, t5_CategoryName etc.)
** 
**
**	Date:							Author:								Modification:
**	23-May-2018						Kalpesh Gondhali					Code creation
**	11-Sept-2018					Kalpesh Gondhali					Option added for module and arch_module
**
**
** command to run:
** keyword_desc_update -u=<username> -pf=<password file path> -g=<group> -file=<Filename> -update_module/-update_arch_module
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define PROP_UIF_set_value_msg		"PROP_UIF_set_value" 
#define PROP_set_value_tag_msg		"PROP_set_value_tag" 
#define PROP_set_value_string_msg   "PROP_set_value_string"  

FILE 		*output 			= NULL;

int			ifail 				= ITK_ok;
char		*sep				= "^";

int get_object(char*, char *);
int keyword_desc_update(tag_t, tag_t, char*, char*);

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"keyword_desc_update -u=<username> -pf=<password file path> -g=<group> -file=<input filename> -update_module/-update_arch_module\n"
	"-------------------------------------------------------------------------------------------------------------------------------\n\n"
	);
}
/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				count	 					= 0;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;
	char 			* object					= NULL;
	char 			* itemid					= NULL;
	
	char 			temp[200];
	char 			Data[100]    				= "";
	char 			OutputFile[200]    			= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");
	object			= ITK_ask_cli_argument("-update_");
	
	time_t now;
	struct tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data, 100, "%d_%b_%Y_%H_%M_%S", &when);
	sprintf(OutputFile, "%s_output.txt", Data);

	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0 || argc != 6)
	{
		print_requirement();
		return -1;
	}
	if(tc_strcmp(object, "module") != 0 && tc_strcmp(object, "arch_module") != 0)
	{
		printf("\nPlease provide appropriate object(module/arch_module)\n");
		return 0;
	}
	
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successful.....!!\n");
			printf("Welcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	output = fopen(OutputFile,"w");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
	printf("Input Exe:%s\n", argv[0]);
	printf("Object:%s\n",object);
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");			
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "");
				printf("\nInput Item_id:%s\n",itemid);

				fprintf(output,"%s",itemid);		
				
				ifail = get_object(itemid, object);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/********************************************************************************************
    Function:       get_object
    Description:    This function takes the item_id as input and find it's latest revision
					in teamcenter.
********************************************************************************************/
int get_object(char* item_id, char* object)
{
	int				i		 					= 0;
	
	tag_t			item_tag 					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	
	char 			*prt_type					= NULL;
	char 			*type						= "Module";
	char 			*type_arch					= "Architecture Module Revision";
	char 			*rev_id						= NULL;
	char 			*module_name				= NULL;
	
	ifail = ITEM_find_item (item_id, &item_tag);
	CHECK_FAIL;
	
	ifail = ITEM_ask_latest_rev (item_tag, &rev_tag);
	if(ifail != ITK_ok)
	{
		printf("Object not found in Teamcenter...!!\n");
		fprintf(output,"%s",sep);
		fprintf(output,"Not Found\n");
		return 0;
	}
	else
	{
		if(tc_strcmp(object, "module") == 0)
		{
			ifail = AOM_UIF_ask_value (rev_tag, "t5_PartType", &prt_type);
			printf("\nPart Type is:%s\n",prt_type);
			
			if((strcmp(prt_type,type) == 0))
			{
				ifail = AOM_UIF_ask_value (rev_tag, "item_revision_id", &rev_id);
				CHECK_FAIL;
				printf("\nLatest rev. found is:%s\n",rev_id);
				
				ifail = AOM_UIF_ask_value (rev_tag, "t5_ModuleName", &module_name);
				CHECK_FAIL;
				
				if(tc_strlen(module_name) > 0)
				{
					ifail = keyword_desc_update(item_tag, rev_tag, rev_id, module_name);
				}
				else
				{
					printf("Name is blank for Module:%s\n", item_id);
					fprintf(output,"%s%s\n",sep, rev_id);
					return 0;
				}
			}
			else
			{
				printf("Part type is not module...!!\n");
				fprintf(output, "\n");
				return 0;
			}
		}
		else
		{
			ifail = AOM_UIF_ask_value (rev_tag, "object_type", &prt_type);
			printf("\nPart Type is:%s\n",prt_type);
		
			if((strcmp(prt_type,type_arch) == 0))
			{
				ifail = AOM_UIF_ask_value (rev_tag, "item_revision_id", &rev_id);
				CHECK_FAIL;
				printf("\nLatest rev. found is:%s\n",rev_id);
				
				ifail = AOM_UIF_ask_value (rev_tag, "t5_ArchModuleName", &module_name);
				CHECK_FAIL;
				
				if(tc_strlen(module_name) > 0)
				{
					ifail = keyword_desc_update(item_tag, rev_tag, rev_id, module_name);
				}
				else
				{
					printf("Name is blank for Arch_Module:%s\n", item_id);
					fprintf(output,"%s%s\n",sep, rev_id);
					return 0;
				}
			}
			else
			{
				printf("Object type is not arch_module...!!\n");
				fprintf(output, "\n");
				return 0;
			}
		}
	}
	return ifail;
}


/********************************************************************************************
    Function:       keyword_desc_update
    Description:    This function takes the item_tag and rev_tag and module_name as input 
					then stamps it on item's and item revision's specific attributes.
					(object_desc, object_name, t5_CategoryName etc.)
********************************************************************************************/
int keyword_desc_update(tag_t item_tag, tag_t rev_tag, char* rev_id, char* module_name)
{
		ifail = AOM_refresh (item_tag, 1);	
		ifail = AOM_UIF_set_value (item_tag, "object_name", module_name);
		ifail = AOM_UIF_set_value (item_tag, "object_desc", module_name);
		ifail = AOM_save (item_tag);
		ifail = AOM_refresh (item_tag, 0);
		
		ifail = AOM_refresh (rev_tag, 1);
		ifail = AOM_UIF_set_value (rev_tag, "object_name", module_name);
		ifail = AOM_UIF_set_value (rev_tag, "object_desc", module_name);
		ifail = AOM_UIF_set_value (rev_tag, "t5_CategoryName", module_name);
		ifail = AOM_save (rev_tag);
		ifail = AOM_refresh (rev_tag, 0);
		if(ifail == ITK_ok)
		{
			printf("\nAttribute Value stamped....!!\n");
			fprintf(output,"%s%s%s%s\n",sep, rev_id, sep, module_name);
			printf("\n*****************************\n");
		}
		else
		{
			printf("\nFailed to stamp Attribute value...!!\n");
			printf("\n************************************\n");
			return ifail;
		}
		return ifail;
}
