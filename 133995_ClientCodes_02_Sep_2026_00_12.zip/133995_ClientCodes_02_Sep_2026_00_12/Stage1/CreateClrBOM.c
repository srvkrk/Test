#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>
#include <tccore/imantype.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/tc.h>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <tccore/workspaceobject.h>
#include <ps/ps.h>
#include <bom/bom.h>
#include <bom/bom_tokens.h>
#include <pom/pom/pom.h>
#include <tccore/aom.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <ps/ps_errors.h>
#include <ps/vrule.h>
#include <tccore/grm.h>
#include <tc/emh_errors.h>
#include <tc/tc_errors.h>
#include <ss/ss_errors.h>
#include <fclasses/tc_string.h>
#include <property/prop.h>
#include <error.h>
#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


typedef struct
{
    int     size;
    int     capacity;
    int     increment;
    void  **content;
} vector_t;

static vector_t *vector_new( int capacity, int increment );
static vector_t *vector_add( vector_t *v, void *element );
static vector_t *vector_add_n( vector_t *v, int n, void *elements[] );
static vector_t *vector_ensure_capacity( vector_t *v, int n );
static vector_t *vector_free( vector_t *v );
static vector_t *vector_insert( vector_t *in, void *element );
static vector_t *vector_insert_n_at( vector_t *in, int n, void *elements[], int at );
static void *vector_get( const vector_t *v, int index );
static int vector_size( const vector_t *v );
static int vector_rem_at( vector_t *in, int n );
static int vector_rem_n_at( vector_t *in, int n, int at );

#define VOO_HASH_SIZE 4099
#define MAX_INT_LENGTH 10      //maximum no of characters required to hold an integer

typedef vector_t *variant_rule_option_data_t[VOO_HASH_SIZE];

static int       VOO_debug                     = FALSE;
static char     *VOO_prog                      = (char *)"generate_variant_overlay_option_constraints";
static char     *VOO_stand_alone_option_prefix = NULL;
static char     *VOO_family_option_prefix      = NULL;
static char     *VOO_family_code_separators    = NULL;
static logical   VOO_binary_options            = FALSE;
static logical   VOO_exclude_off_stand_alones  = FALSE;
static vector_t *VOO_binary_off_values         = NULL;

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );
static int VOO_show_wso
    ( tag_t       wso                         /* <I> */
    );
static int VOO_list_saved_variant_rules
    ( tag_t       itemRev,                    /* <I> */
      int *       nVRules,                    /* <O> */
      tag_t **    vRules                      /* <OF> */
    );
static logical VOO_option_value_hash
    ( int         hash_size,                  /* <I> */
      vector_t *  hash[],                     /* <I> */
      tag_t       option_rev,                 /* <I> */
      int         option_rev_value_index,     /* <I> */
      int         add_if_new                  /* <I> */
    );
static int VOO_hash_to_array
    ( int         hash_size,                  /* <I> */
      vector_t *  hash[],                     /* <I> */
      int *       n_option_data,              /* <O> */
      void ***    option_data                 /* <OF> */
    );
static char *VOO_time_stamp
    ();
static int VOO_is_option_excluded
    ( vector_t *excluded,                     /* <I> */
      tag_t     bom_variant_rule,             /* <I> */
      tag_t     option,                       /* <I> */
      int      *option_value_index,           /* <I> */
      logical  *is_excluded                   /* <O> */
    );
static logical VOO_is_stand_alone_option
    ( char *option_name                       /* <I> */
    );
static logical VOO_value_is_set_to_off
    ( char *option_value                      /* <I> */
    );
static int VOO_is_value_pair_excluded
    ( tag_t    option1,                       /* <I> */
      tag_t    option1_rev,                   /* <I> */
      int      option1_value_index,           /* <I> */
      tag_t    option2,                       /* <I> */
      tag_t    option2_rev,                   /* <I> */
      int      option2_value_index,           /* <I> */
      logical *is_excluded                    /* <O> */
    );
static void VOO_option_family_and_code
    ( char  *option_name,                     /* <I> */
      char **option_family,                   /* <OF> */
      char **option_code                      /* <OF> */
    );
static int VOO_n_referencers
    ( tag_t obj,                              /* <I> */
      int n_levels                            /* <I> */
    );
static int VOO_variant_expression
    ( tag_t        v1,                        /* <I> */
      int          op,                        /* <I> */
      tag_t        v2,                        /* <I> */
      const char * text,                      /* <I> */
      tag_t      * ve,                        /* <O> */
      logical    * was_new                    /* <O> */
    );
static int VOO_expression_hash
    ( int          hash_size,                 /* <I> */
      vector_t   * hash[],                    /* <I> */
      tag_t        val1,                      /* <I> */
      int          oper,                      /* <I> */
      tag_t        val2,                      /* <I> */
      const char * text,                      /* <I> */
      logical      add_if_new,                /* <I> */
      tag_t      * var_exp,                   /* <O> */
      logical    * was_new                    /* <O> */
    );
static int VOO_combine_ves
    ( int       n_ves,                        /* <I> */
      tag_t   * ves,                          /* <I> */
      int       oper,                         /* <I> */
      tag_t   * combined_ve,                  /* <I/O> */
      int     * n_ves_2_save,                 /* <I/O> */
      tag_t  ** ves_2_save                    /* <I/OF> */
    );
static int VOO_binary_constraints
    ( int      n_option_data,                 /* <I> */
      void  ** option_data,                   /* <I> */
      char   * constraint_error_text,         /* <I> */
      char   * toggle_ve_string,              /* <I> */
      tag_t    bom_variant_rule,              /* <I> */
      tag_t  * e_block,                       /* <I/O> */
      int    * n_ves_2_save,                  /* <I/O> */
      tag_t ** ves_2_save                     /* <I/OF> */
    );
static int VOO_off_variant_expressions
    ( int      oper,                          /* <I> */
      int      n_off_expressions,             /* <I> */
      tag_t  * option_revs,                   /* <I> */
      tag_t  * off_expressions,               /* <O> */
      int    * n_ves_2_save,                  /* <I/O> */
      tag_t ** ves_2_save                     /* <I/OF> */
    );

/*
 * The macro "ITK" is a wrapper for all ITK calls: It submitts the call `(x)'
 * only if the variable `stat' (must be defined outside!) is equal to ITK_ok.
 * This way we prevent to continue to submit ITK calls if an error occured.
 * For convenience this macro prints out the IMAN error string (don't forget
 * to call `ITK_initialize_text_services()' prior to `ITK_auto_login()'), the
 * source file name (__FILE__) and the source code line number (__LINE__).
 *
 * Note: __LINE__ and  __FILE__ are replaced with the actual values during the
 * cpp (c pre processor) run.
 */
#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}



#define CLI_OPTION_ITEM_ID                   "-item_id="
#define CLI_OPTION_REV_ID                    "-rev_id="
#define CLI_OPTION_CONSTRAINT_ERROR_TEXT     "-constraint_error_text="
#define CLI_OPTION_DEBUG_LEVEL               "-debug_level="
#define CLI_OPTION_BYPASS                    "-bypass"
#define CLI_OPTION_DELETE_CONSTRAINTS_ONLY   "-delete_constraints_only"
#define CLI_OPTION_BINARY_OPTIONS            "-binary_options"
#define CLI_OPTION_BINARY_OFF_VALUE          "-binary_off_value="
#define CLI_OPTION_ACTIVATING_EXPRESSION     "-activating_expression="
#define CLI_OPTION_EXCLUDED_OPTION           "-excluded_option="
#define CLI_OPTION_STAND_ALONE_OPTION_PREFIX "-stand_alone_option_prefix="
#define CLI_OPTION_FAMILY_OPTION_PREFIX      "-family_option_prefix="
#define CLI_OPTION_FAMILY_CODE_SEPARATORS    "-family_code_separators="
#define CLI_OPTION_EXCLUDE_OFF_STAND_ALONES  "-exclude_off_stand_alones"
#define CLI_OPTION_HELP                      "-help"
#define CLI_OPTION_H                         "-h"
#define USAGE(S) {                                                                                                      \
    fprintf ( (S), "\nUSAGE: %s\n",                                             VOO_prog );                             \
    fprintf ( (S), "\t%sItem_ID\n",                                             CLI_OPTION_ITEM_ID );                   \
    fprintf ( (S), "\t%sRev_ID\n",                                              CLI_OPTION_REV_ID );                    \
    fprintf ( (S), "\t%sError_Text\n",                                          CLI_OPTION_CONSTRAINT_ERROR_TEXT );     \
    fprintf ( (S), "\t[%s or %s]\n",                                            CLI_OPTION_HELP, CLI_OPTION_H );        \
    fprintf ( (S), "\t[%sOption_Name]\n",                                       CLI_OPTION_EXCLUDED_OPTION );           \
    fprintf ( (S), "\t[%sOther_Option_Name]\n",                                 CLI_OPTION_EXCLUDED_OPTION );           \
    fprintf ( (S), "\t[%sOption=Value]\n",                                      CLI_OPTION_ACTIVATING_EXPRESSION );     \
    fprintf ( (S), "\t[%s]\n",                                                  CLI_OPTION_BYPASS );                    \
    fprintf ( (S), "\t[%s]\n",                                                  CLI_OPTION_DELETE_CONSTRAINTS_ONLY );   \
    fprintf ( (S), "\t[%sInteger]\n",                                           CLI_OPTION_DEBUG_LEVEL );               \
    fprintf ( (S), "\t[%s]\n",                                                  CLI_OPTION_BINARY_OPTIONS );            \
    fprintf ( (S), "\t[%sValue_for_Off]\n",                                     CLI_OPTION_BINARY_OFF_VALUE );          \
    fprintf ( (S), "\t[%sAnother_Value_for_Off]\n",                             CLI_OPTION_BINARY_OFF_VALUE );          \
    fprintf ( (S), "\t[%sDefaultsAreCaseInsensitive:N,F,0,No,None,Off,False]\n",CLI_OPTION_BINARY_OFF_VALUE );          \
    fprintf ( (S), "\t[%sDefaultIs:___]\n",                                     CLI_OPTION_STAND_ALONE_OPTION_PREFIX ); \
    fprintf ( (S), "\t[%sNoDefault]\n",                                         CLI_OPTION_FAMILY_OPTION_PREFIX ); \
    fprintf ( (S), "\t[%sDefaultIs:<>[]|_: \\t\\r\\f\\v\\a]\n",                 CLI_OPTION_FAMILY_CODE_SEPARATORS );    \
    fprintf ( (S), "\t[%s]\n",                                                  CLI_OPTION_EXCLUDE_OFF_STAND_ALONES );  \
}
#define HELP(S) {                                                                                                          \
    USAGE ( S )                                                                                                            \
    fprintf( stderr, "\nThis utility uses saved variant rules associated to the item rev\n" );                             \
    fprintf( stderr, "specified with %s and %s to generate option constraints\n", CLI_OPTION_ITEM_ID, CLI_OPTION_REV_ID ); \
    fprintf( stderr, "(\"rule checks\") for option value combinations, which are not found in\n" );                        \
    fprintf( stderr, "any saved variant rule.\n" );                                                                        \
    fprintf( stderr, "This may be useful if the list of saved variant rules associated to the\n" );                        \
    fprintf( stderr, "top level ItemRevision is large enough to cover all or nearly all valid\n" );                        \
    fprintf( stderr, "option value combinations.\n" );                                                                     \
    fprintf( stderr, "Option constraints are used by RDV DesignContext when filtering invalid\n" );                        \
    fprintf( stderr, "background parts (\"Valid Overlays Only\").\n" );                                                    \
    fprintf( stderr, "If binary options (with values of either ON or OFF, e.g. ENG_V8={Y,N} )\n" );                        \
    fprintf( stderr, "are used instead of family options (e.g. ENG={V8,V6}) you should use the\n" );                       \
    fprintf( stderr, "%s switch.\n", CLI_OPTION_BINARY_OPTIONS );                                                          \
    fprintf( stderr, "Binary options are expected to store both option family and code in the\n" );                        \
    fprintf( stderr, "option name. Family and code are expected to be separated by characters\n" );                        \
    fprintf( stderr, "provided by the %s switch.\n", CLI_OPTION_FAMILY_CODE_SEPARATORS );                                  \
    fprintf( stderr, "The default \"<>[]|_: \\t\\r\\f\\v\\a\" allows for formats including but not\n" );                   \
    fprintf( stderr, "limited to:\n" );                                                                                    \
    fprintf( stderr, "\t\"FAM_CODE\";\n" );                                                                                \
    fprintf( stderr, "\t\"FAM:CODE\";\n" );                                                                                \
    fprintf( stderr, "\t\"FAM CODE\";\n" );                                                                                \
    fprintf( stderr, "\t\"<FAM>CODE\";\n" );                                                                               \
    fprintf( stderr, "\t\"<FAM>: CODE\";\n" );                                                                             \
    fprintf( stderr, "\t\"[FAM] CODE\";\n" );                                                                              \
    fprintf( stderr, "\t\"FAM|CODE\"\n" );                                                                                 \
    fprintf( stderr, "To reduce the likelyhood for false positives, constraints on Stand Alone\n" );                       \
    fprintf( stderr, "options with a value set to off can optionally by excluded.\n" );                                    \
    fprintf( stderr, "(switch %s).\n", CLI_OPTION_EXCLUDE_OFF_STAND_ALONES );                                              \
    fprintf( stderr, "\nAssumptions:\n" );                                                                                 \
    fprintf( stderr, "A Stand Alone option is a binary option without a family code.\n" );                                 \
    fprintf( stderr, "An option is a Family Option if it is not a Stand Alone option.\n" );                                \
    fprintf( stderr, "Exactly one Family Option of each family must be set to On.\n\n" );                                  \
}

int OccurSetTopLine(tag_t  clrbvr, char* UsesPartNo, int NClrQty3)
{	
	int          stat                = ITK_ok;
	int			 status;
	int			 ifail				 = ITK_ok;
	int n_occs;
	tag_t *occsal;
	int ChildOccNon,iy,i=0;
	tag_t	ChildItem		= NULLTAG;
	tag_t	bvrchild		= NULLTAG;
	char	*occ_item_id	= NULL;
	tag_t  *occs=NULL;
	tag_t        UseMaster           = NULLTAG;
	tag_t        Nrev                = NULLTAG;


	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)UsesPartNo;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2));
	printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if(n_tags_found2 > 0)
	{
		UseMaster = tags_found2[0];
		MEM_free(tags_found2);	


	//ITK_CALL(ITEM_find_item(UsesPartNo,&UseMaster))
	//printf("\n UseMaster found------>\n");
	
	ITK_CALL(ITEM_ask_latest_rev(UseMaster, &Nrev));
	printf("\n Childrev found------>\n");

	ITK_CALL(PS_list_occurrences_of_bvr(clrbvr, &n_occs, &occsal));
	printf("\n InMain  no:of:occurances are --->%d\n",n_occs); fflush(stdout);
	ChildOccNon=0;
	if(n_occs > 0)
	{	
		 for (iy = 0; iy<n_occs; iy++)
		 {
			 ITK_CALL(PS_ask_occurrence_child(clrbvr,occsal[iy], &ChildItem, &bvrchild));
			 ITK_CALL(AOM_ask_value_string(ChildItem, "item_id", &occ_item_id));
			 printf("\n occ_item_id & child_item_id  :%s=%s\n\n",occ_item_id,UsesPartNo);fflush(stdout);
			 if(tc_strcmp(occ_item_id,UsesPartNo)==0)
			 {
				ChildOccNon=1;
				break;
			 }								 
		 }
	}
	
	printf("\n ChildOccNon values is----------------->%d\n",ChildOccNon); fflush(stdout);
	printf("\n NClrQty3----------------->%d\n",NClrQty3); fflush(stdout);
	if(ChildOccNon==0)
	{
		if(NClrQty3>0)
		{
			for (i=0; i<NClrQty3; i++)
			{	
				ITK_CALL(PS_create_occurrences(clrbvr, Nrev, NULLTAG,1, &occs ))
				printf("\n PS_create_occurrences successfully in PSE------->\n");
			}
		}else if (NClrQty3==0)
		{
			ITK_CALL(PS_create_occurrences(clrbvr, Nrev, NULLTAG,1, &occs ))
			printf("\n PS_create_occurrences successfully in PSE------->\n");
		}
		ITK_CALL(AOM_save_without_extensions(clrbvr))
		ITK_CALL(AOM_refresh(clrbvr,0));
	}
	}
	return ITK_ok;
};

/*
int OccurSetTopLine(tag_t  bvr,char* UsesPartNo)
{
	int          stat                = ITK_ok;
	int			 ifail				 = ITK_ok;
    tag_t        UseMaster           = NULLTAG;
	tag_t        Nrev                = NULLTAG;
	char		*PartNumber			 = NULL;
	tag_t       objNameType=NULLTAG;
	char   type_name[TCTYPE_name_size_c+1];
	tag_t  *occs=NULL;

	printf("\n Uses Part Number is ------> %s\n",UsesPartNo);

    ITK(ITEM_find_item(UsesPartNo,&UseMaster))
	printf("\n UseMaster found------>\n");
	
	ITK(ITEM_ask_latest_rev(UseMaster, &Nrev));
	printf("\n Childrev found------>\n");
	
	ITK(AOM_UIF_ask_value(Nrev,"item_id",&PartNumber));
	printf("\n PartNumber : %s ..............",PartNumber);fflush(stdout);

	ITK(TCTYPE_ask_object_type(Nrev,&objNameType));
	ITK(TCTYPE_ask_name(objNameType,type_name));
	printf("\n type_name	   :: [%s]\n",type_name);

	ITK(PS_create_occurrences(bvr, Nrev, NULLTAG,1, &occs ))
	printf("\n PS_create_occurrences successfully in PSE------->\n");

	ITK(AOM_save_without_extensions( bvr) )
	printf("\n AOM_save_without_extensions successfully of bvr------->\n");

	ITK(AOM_refresh(bvr,0));
	printf("\n AOM_refresh successfully of bvr------->\n"); 

	return ITK_ok;
};
*/

int MultilevelColourBOMCreate(char* UsesClrPart, char* ClrPartRev1, char* UsesNonColorPart)
{
	int status;
    char        *item_id                 = NULL;
    char        *rev_id                  = NULL;
    char        *constraint_error_text   = NULL;
    char        *toggle_ve_string        = NULL;
    char        *debug_level             = NULL;
    char        *excluded_option         = NULL;
    char        *binary_off_value        = NULL;
    char        *varaintrule_name        = NULL;
    logical      bypass                  = FALSE;
    logical      delete_constraints_only = FALSE;
    tag_t        rev                     = NULLTAG;
	tag_t		*rev1 = NULL;
	tag_t		*rev2 = NULL;
	tag_t        VCrev                   = NULLTAG;
    tag_t        parent_master           = NULLTAG;
    tag_t        Child_master           = NULLTAG;
    tag_t        Childrev                   = NULLTAG;
    //tag_t        Childrev                = NULLTAG;
    //tag_t        rev1                    = NULLTAG;
    tag_t        InputItemtag                    = NULLTAG;
    tag_t        bv,bvr,parentBvr        = NULLTAG;
    tag_t        bom_view                = NULLTAG;
    variant_rule_option_data_t option_value_dictionary={NULL};
    vector_t    *excluded                = NULL;
    time_t       start_time;
    time_t       now_time;
	int p=0;
	tag_t *bvs, *bvrs;
    int    bv_count, bvr_count;
	char *inputfile=NULL;
	char *ClrPart=NULL;
	char *ClrPartRev=NULL;
	char *ClrPartSeq=NULL;
	char *PartType=NULL;
	tag_t   e_block=NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	tag_t   Childobject=NULLTAG;
	tag_t   Childobject1=NULLTAG;
	tag_t   ClrPartobjPtr=NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULL;
	tag_t   bom_variant_rule=NULLTAG;
	logical list_changed=FALSE;
	int     n_options=0;
	tag_t  *options=NULL;
	tag_t  *option_revs=NULL;
	int     option_value_index=-1;
	tag_t   option1=NULLTAG;
	tag_t  *option1_rev=NULL;
	int    *option1_value_index=NULL;
	tag_t   option2=NULLTAG;
	tag_t  *option2_rev=NULL;
	int    *option2_value_index=NULL;
	int     inx, jnx, knx;
	int     n_option_data=0,p1,k1=0;
	tag_t topline = NULLTAG;
	void  **option_data=NULL;
	variant_rule_option_data_t *variant_rule_option_data=NULL;
	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;
	int     n_ves_2_save=0;
	tag_t  *ves_2_save=NULL;
	tag_t   toggle_ve=NULLTAG;
	int n_lines,n_lines1,Item_ID,i = 0;
	tag_t *lines = NULL;
	tag_t *lines1 = NULL;
	tag_t *Newlines = NULL;
	char *Item_ID_str=NULL;
	char *child_item_id=NULL;
	char *child_item_ColorId=NULL;
	char *child_item_id_new=NULL;
	char *Color_item_id_new=NULL;
	char *t5PrtCatCode=NULL;
	 logical modB=FALSE;
	 tag_t tRelationFind;
	 tag_t objTypeTag2;
	 int NClrQty3=0;

	
	char  type_name1[TCTYPE_name_size_c+1];
	
	char *Usesdesc = NULL;
	char *UsesColourIndS = NULL;
	char *Usest5PrtCatCodeS = NULL;
	char *Usest5ColourIDS = NULL;
	char *Usest5CoatedS = NULL;
	char *Usest5PartStatusS = NULL;
	char *Usesdesigngroup = NULL;
	char *Usesprojectcode = NULL;
	char *UseslifecycleS = NULL;
	char *Usesmod_desc = NULL;
	char *UsesDrawingIndS = NULL;
	char *UsesPartTypeS = NULL;
	char *Usest5PartCodeS = NULL;
	char *UsesFromDate = NULL;
	char *UsesToDate = NULL;
	char *Clrbl_item_item_id = NULL;
	int n_rev,n_rev2= 0;
	int count,z =0;
	tag_t	new_object		= NULLTAG;
	int flag = 0;
	FILE* fp=NULL;
	tag_t *ClrPartRevision = NULLTAG;
	tag_t ChildrevTypeTag=NULLTAG;
	char   * Childrevtype_name;
	tag_t        UseClrMaster           = NULLTAG;
	tag_t        NonClrRev                = NULLTAG;
	char		*NClrPartNumber			 = NULL;
	char		*t5item_id			 = NULL;
	char		*t5sequence_id			 = NULL;
	char		*BomlineCmpcd			 = NULL;
	//int QuantityAttrId=0;

    //VOO_prog = argv[0];
	
	int          stat                = ITK_ok;
	int			 ifail				 = ITK_ok;

	ITK(ITEM_find_item (UsesClrPart, &new_object));
	printf("\n new_object found------->\n");fflush(stdout);

	printf("\n ClrPartRev1------->%s\n",ClrPartRev1);fflush(stdout);
	ITK(ITEM_find_revisions(new_object,ClrPartRev1,&n_rev,&rev1));
	printf("\n n_revis found ---------> : %d\n", n_rev); fflush(stdout);
	//ITK_CALL(BOM_line_look_up_attribute("bl_quantity", &QuantityAttrId));

	//ITK(ITEM_ask_latest_rev(new_object, &rev));
	//printf("\n rev is found --------->\n");fflush(stdout);

	if(n_rev > 0)
	{
		rev = rev1[0];
	}	
	
	if (rev != NULLTAG)
	{
		if ( NULLTAG == rev )
		{	
			printf("\n inside rev NULLTAG--------->\n");fflush(stdout);				
		}else
		{
			char *property_value = NULL;
			char *view_type_name=NULL;
			tag_t view_type=NULLTAG;

			ITK(AOM_ask_value_string(rev,"t5_PartType",&PartType));
			printf("\n PartType is :: %s\n",PartType);fflush(stdout);

			ITK(AOM_ask_value_string(rev,"item_id",&t5item_id));
			printf("\n t5item_id is :: %s\n",t5item_id);fflush(stdout);

			ITK(AOM_ask_value_string(rev,"current_revision_id",&t5sequence_id));
			printf("\n t5sequence_id is :: %s\n",t5sequence_id);fflush(stdout);

			ITK_CALL(PS_find_view_type( "view", &view_type ));
			printf("\n view_type found----->\n");fflush(stdout);

			if ( NULLTAG != view_type )
			{
				int    n_bom_views=0;
				tag_t *bom_views=NULL;
				tag_t  bom_view_type=NULLTAG;
				int    bom_view_index=0;
				tag_t  item=NULLTAG;
				
				ITK_CALL(ITEM_ask_item_of_rev( rev, &item ));
				ITK_CALL(ITEM_list_bom_views( item, &n_bom_views, &bom_views ));
				printf("\n n_bom_views :: %d\n",n_bom_views);fflush(stdout);

				if (n_bom_views>0)
				{
					bom_view = bom_views[0];
					flag=0;
				}
			}else
			printf("\n View not found check..\n");fflush(stdout);		
		 }

		 if ( flag == 0)
		 {
			ITK(AOM_lock(rev));
			printf("\n before BOM_create_window-------->\n");
			ITK_CALL(BOM_create_window( &bom_window ));
			ITK_CALL(CFM_find("Latest Working", &rule ));
			ITK_CALL(BOM_set_window_config_rule(bom_window,rule));
			ITK_CALL(BOM_set_window_pack_all(bom_window,TRUE));
			ITK_CALL(BOM_set_window_top_line(bom_window, NULLTAG, rev, NULLTAG, &top_line ));
			
			if(top_line!=NULLTAG)
			{
				ITK(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
				printf("\n BOM_line_ask_child_lines-------->%d\n",n_lines);

				if (n_lines >0)
				{
					for (p1=0;p1<n_lines ;p1++ )
					{
						if(Childobject) Childobject=NULLTAG;
						Childobject=lines[p1];
						ITK(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
						fprintf( stderr, " child_item_id ..:%s\n",child_item_id);
					}
				}	
			}else
			{
				printf("\n Top line is NULL\n");
			}

			/* delete old constraints */
			if ( top_line!=NULLTAG )
			{
			 fprintf( stderr, "%s %s: inside topline Revision is \n", VOO_prog, VOO_time_stamp() );
			//ITK ( VOO_show_wso( rev ) )
		
			int ifail = ITK_ok;
			tag_t  v1=NULLTAG;
			tag_t  primary=NULLTAG;
			tag_t  primary1=NULLTAG;
			//const tag_t * 	primary1;
			int ix=0;
			char *option_item_s     =NULL;
			char *option_s          =NULL;
			char *option_eq_s       =NULL;
			char *option_val_s      =NULL;
			tag_t  item1=NULLTAG;

			tag_t option;
			tag_t option_rev;
			
			tag_t  objNameTypeTag=NULLTAG;
			tag_t  objTypeTagDi1=NULLTAG;
			tag_t  opt_tag=NULLTAG;
			tag_t  master_tag=NULLTAG;
			tag_t  *opts=NULLTAG;
			tag_t  *rootLine=NULL;
			tag_t * 	bom_variant_config=NULL;
			tag_t  *opt_revs=NULLTAG;
			tag_t  *secondaries=NULL;
			tag_t  *occs=NULL;
			tag_t  relation_dep	= NULLTAG;
			tag_t  *secondary_objects	= NULLTAG;
			tag_t  *secondary_objects1	= NULLTAG;
			GRM_relation_t *primary_list_Dep	= NULLTAG;
			int grm_count = 0;
			tag_t *grm_tag;
		   
			int    opcode=-1;
			tag_t  v2=NULLTAG;
			char  *str=NULL;
			char  *object_type=NULL;
			char  *find_option_name_p=NULL;
		   char  *find_option_desc_p=NULL;
			char  *Context_Str=NULL;
			tag_t *ves=NULL;
			int *ind=NULL;
			int *ind1=NULL;
			int    n_ves,n_opts,k=0,k1=0,Opt1=0,n_values1=0,n_secondaries=0,countDep,countDep1=0;
			 tag_t owning_item = NULLTAG;
			char *name = NULL;
			char   type_name2[TCTYPE_name_size_c+1];
			char   type_name[TCTYPE_name_size_c+1];
			//char   type_name1[TCTYPE_name_size_c+1];
			char *desc = NULL;
			char *PartNumber = NULL;
			//int * count=NULL;
			int inx;
			tag_t cond_ve;
			tag_t loadif_ve;
			tag_t veb;
			tag_t ** 	variant_rule_list= NULLTAG;
			tag_t top_bomline;
			tag_t clause_list = NULLTAG;
			char   *Quantity3=NULL;
			char   *bl_rev_item_revision_id=NULL;

			//ITK_CALL(ITEM_ask_item_of_rev( rev, &parent_master ));
			//printf("\n parent_master found---->%s");fflush(stdout);
			
			printf("\n ClrPart  :: %s\n",UsesClrPart);
			ITK(ITEM_find_item(UsesClrPart,&parent_master))
			printf("\n parent_master found test------>\n"); //Rohit

			if(parent_master !=NULLTAG)
			{
					ITK(ITEM_list_bom_views(parent_master,&bv_count, &bvs))
					fprintf( stderr, "\n bv_count :%d..\n",bv_count);
					
					 if (bv_count)
					 {
						bv = bvs[0];
						MEM_free(bvs);
					 }else
					 {
						ITK( PS_create_bom_view( NULLTAG, "", "", parent_master,&bv ));
						ITK(AOM_save_without_extensions( bv ))
						ITK( AOM_save_without_extensions( parent_master ))
						ITK( AOM_unlock( parent_master ))
						fprintf( stderr, "\n inside PS_create_bom_view..\n");
				
					 }

					 ITK(ITEM_find_revisions(parent_master,ClrPartRev1,&n_rev2,&rev2));
					 printf("\n n_revis found ---------> : %d\n", n_rev2); fflush(stdout); //Rohit
					 if(n_rev2 > 0)
					 {
						VCrev = rev2[0];
					 }	
					
					//ITK(ITEM_ask_latest_rev(parent_master, &VCrev));
					//printf("\n ITEM_ask_latest_rev found------>\n");
					//ITK(ITEM_find_rev( "544204457000R", "NR;1", &VCrev ) )

					ITK(VOO_show_wso( VCrev ) )
					ITK(ITEM_rev_list_bom_view_revs(VCrev,&bvr_count, &bvrs))
					fprintf( stderr, "\n bvr_count :%d..\n",bvr_count);   fflush(stdout);
					 if (bvr_count)
					{
						bvr = bvrs[0];
						MEM_free(bvrs);
					}
					else
					{
						ITK(PS_create_bvr( bv, "", "", false, VCrev,&bvr) )
						if(bvr !=NULLTAG)
						{								
							ITK( AOM_save_without_extensions( bvr) )
							ITK (AOM_save_without_extensions( VCrev ))
							ITK( AOM_unlock( VCrev ))
							fprintf( stderr, "\n inside  PS_create_bvr..\n");   fflush(stdout);
						}
					}
				  fprintf( stderr, "\n After PS_create_bvr..\n");
				}

				if(top_line!=NULLTAG)
				{
						ITK(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
						printf("\n LLlast Before setting option n_lines1: %d \n", n_lines1);  fflush(stdout);
						
						if(n_lines1>0)
						//{							
						printf("\n Uses Non-ColorPart  :: %s\n",UsesNonColorPart);   fflush(stdout);
						ITK(ITEM_find_item(UsesNonColorPart,&Child_master))
						printf("\n Child_master found------>\n");   fflush(stdout);

						ITK(ITEM_ask_latest_rev(Child_master, &Childrev));
						printf("\n ITEM_ask_latest_rev found------>\n");    fflush(stdout);

						ITK(TCTYPE_ask_object_type(Childrev,&ChildrevTypeTag));
						ITK(TCTYPE_ask_name2(ChildrevTypeTag,Childrevtype_name));
						printf("\n ChildrevTypeTag found------> %s\n",Childrevtype_name);   fflush(stdout);


						
						ITK(BOM_create_window (&window));		
						ITK(CFM_find("ERC release and above", &rule ));
						printf("\n Status of the object");    fflush(stdout);
						ITK(BOM_set_window_config_rule( window, rule ));
						printf("\n Config Rule");    fflush(stdout);
						ITK(BOM_set_window_pack_all (window, true));
			
						ITK(BOM_set_window_top_line (window, NULLTAG, Childrev, NULLTAG, &top_line1));
						printf("\n Top Line Found");    fflush(stdout);

						if(top_line1!=NULLTAG)
                        
						{
							printf("\n Top Line Not Found");    fflush(stdout);
							ITK(BOM_line_ask_child_lines(top_line1, &n_lines1, &lines1));
							printf("\n BOM_line_ask_child_lines n_lines1------> %d\n",n_lines1);    fflush(stdout);

							if (n_lines1 >0)
							{
								for (p1=0;p1<n_lines1 ;p1++ )
								{
									if(Childobject1) Childobject1=NULLTAG;
									Childobject1=lines1[p1];
									ITK(AOM_ask_value_string(Childobject1, "bl_item_item_id", &child_item_id_new ));
									printf("\n child_item_id_new ..:%s\n",child_item_id_new);    fflush(stdout);

									ITK(AOM_ask_value_string(Childobject1, "bl_rev_item_revision_id", &bl_rev_item_revision_id ));
									printf("\n bl_rev_item_revision_id ..:%s\n",bl_rev_item_revision_id);    fflush(stdout);
									
									ITK(AOM_ask_value_string(Childobject1, "bl_Design Revision_t5_ColourInd", &child_item_ColorId ));
									printf("\n child_item_ColorId----->:%s\n",child_item_ColorId);    fflush(stdout);

									//ITK(BOM_line_ask_attribute_string(Childobject1,QuantityAttrId, &Quantity3));
									ITK(AOM_ask_value_string(Childobject1,"bl_quantity", &Quantity3));
									NClrQty3=atoi(Quantity3);
									printf("\n NClrQty3 is--> : %d\n\n",NClrQty3); fflush(stdout);
																			
									if(tc_strcmp(child_item_ColorId,"Y")!=0)
									{	
										ITK_CALL(OccurSetTopLine(bvr,child_item_id_new,NClrQty3));
										printf("\n\n Function OccurSetTopLine getting call--------->\n\n");												
									}else
									printf("\n\n getting call for Color part--------->\n\n");    fflush(stdout);										
								}
							}
						}

						else
					    {
                          printf("\nTOP Line is already available------->\n");
						}
						
						}
						
						
					}

					ITK(AOM_save_without_extensions( bv) )
					ITK(AOM_save_without_extensions( VCrev) )
					ITK(AOM_save_without_extensions( Childrev) )
					ITK(AOM_save_without_extensions( bvr) )
					ITK(BOM_save_window(bom_window))
					ITK(BOM_close_window(bom_window))
			}

		ITK ( AOM_save_without_extensions( e_block ) )
		ITK ( AOM_unlock( e_block ) )
		ITK ( ITEM_set_rev_variants( rev, e_block ) )
		ITK ( AOM_save_without_extensions( rev ) )
		ITK ( AOM_unlock( rev ) )
	}

		else
  
  {
   printf("\n inside rev NULLTAG--------->\n");fflush(stdout);				
  }

   return ITK_ok;
  }

  


int ITK_user_main ( int argc, char *argv[] ) 
{
    int          stat                    = ITK_ok;
	int status;
    char        *item_id                 = NULL;
    char        *rev_id                  = NULL;
    char        *constraint_error_text   = NULL;
    char        *toggle_ve_string        = NULL;
    char        *debug_level             = NULL;
    char        *excluded_option         = NULL;
    char        *binary_off_value        = NULL;
    char        *varaintrule_name        = NULL;
    logical      bypass                  = FALSE;
    logical      delete_constraints_only = FALSE;
    tag_t        rev                     = NULLTAG;
	tag_t        VCrev                   = NULLTAG;
    tag_t        parent_master           = NULLTAG;
    tag_t        Child_master           = NULLTAG;
    tag_t        Childrev                   = NULLTAG;
    //tag_t        Childrev                = NULLTAG;
    tag_t        rev1                    = NULLTAG;
    tag_t        InputItemtag                    = NULLTAG;
    tag_t        bv,bvr,parentBvr        = NULLTAG;
    tag_t        bom_view                = NULLTAG;
    variant_rule_option_data_t option_value_dictionary={NULL};
    vector_t    *excluded                = NULL;
    time_t       start_time;
    time_t       now_time;
	int p=0;
	tag_t *bvs, *bvrs;
    int    bv_count, bvr_count;
	char *inputfile=NULL;
	char *ClrPart=NULL;
	char *ClrPartRev=NULL;
	char *ClrPartSeq=NULL;
	char *PartType=NULL;
	tag_t   e_block=NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	tag_t   Childobject=NULLTAG;
	tag_t   Childobject1=NULLTAG;
	tag_t   ClrPartobjPtr=NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULL;
	tag_t   bom_variant_rule=NULLTAG;
	logical list_changed=FALSE;
	int     n_options=0;
	tag_t  *options=NULL;
	tag_t  *option_revs=NULL;
	int     option_value_index=-1;
	tag_t   option1=NULLTAG;
	tag_t  *option1_rev=NULL;
	int    *option1_value_index=NULL;
	tag_t   option2=NULLTAG;
	tag_t  *option2_rev=NULL;
	int    *option2_value_index=NULL;
	int     inx, jnx, knx;
	int     n_option_data=0,p1=0;
	tag_t topline = NULLTAG;
	void  **option_data=NULL;
	variant_rule_option_data_t *variant_rule_option_data=NULL;
	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;
	int     n_ves_2_save=0;
	tag_t  *ves_2_save=NULL;
	tag_t   toggle_ve=NULLTAG;
	int n_lines,n_lines1,Item_ID,i = 0;
	tag_t *lines = NULL;
	tag_t *lines1 = NULL;
	tag_t *Newlines = NULL;
	char *Item_ID_str=NULL;
	char *child_item_id=NULL;
	char *child_item_ColorId=NULL;
	char *child_item_id_new=NULL;
	char *Color_item_id_new=NULL;
	 logical modB=FALSE;
	 tag_t tRelationFind;
	 tag_t objTypeTag2;

	char *UsesLevel = NULL;
	char *UsesClrPart = NULL;
	char *UsesClrRev  = NULL;
	char *UsesClrSeq  = NULL;
	char* inputline   = NULL;
	char  type_name1[TCTYPE_name_size_c+1];
	
	char *Usesdesc = NULL;
	char *UsesColourIndS = NULL;
	char *Usest5PrtCatCodeS = NULL;
	char *Usest5ColourIDS = NULL;
	char *Usest5CoatedS = NULL;
	char *Usest5PartStatusS = NULL;
	char *Usesdesigngroup = NULL;
	char *Usesprojectcode = NULL;
	char *UseslifecycleS = NULL;
	char *Usesmod_desc = NULL;
	char *UsesDrawingIndS = NULL;
	char *UsesPartTypeS = NULL;
	char *Usest5PartCodeS = NULL;
	char *UsesFromDate = NULL;
	char *UsesToDate = NULL;
	char *UsesNonColorPart = NULL;
	char *NonRev = NULL;
	char *NonSeq = NULL;
	char *Clrbl_item_item_id = NULL;
	int count,z =0;
	tag_t	new_object		= NULLTAG;
	int flag = 0;
	FILE* fp=NULL;
	tag_t *ClrPartRevision = NULLTAG;
	tag_t ChildrevTypeTag=NULLTAG;
	char   Childrevtype_name[TCTYPE_name_size_c+1];
	tag_t        UseClrMaster           = NULLTAG;
	tag_t        NonClrRev                = NULLTAG;
	char		*NClrPartNumber			 = NULL;
	char *itemRevSeq = NULL;


    VOO_prog = argv[0];	
	
	ITK_initialize_text_services ( 0 );
		ITK_auto_login();

    //ITK ( ITK_initialize_text_services ( 0 )!=ITK_ok)   PrintErrorStack();
    //ITK ( ITK_auto_login()!=ITK_ok)   PrintErrorStack();
	
	inputfile = ITK_ask_cli_argument("-i=");

	fp=fopen(inputfile,"r");
	printf("\n\n");fflush(stdout);

	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{			
			fputs(inputline,stdout);
			UsesLevel=strtok(inputline,"^");  
			UsesClrPart=strtok(NULL,"^");  
			UsesClrRev=strtok(NULL,"^");
			UsesClrSeq=strtok(NULL,"^");
			UsesNonColorPart=strtok(NULL,"^");
			NonRev=strtok(NULL,"^");
			NonSeq=strtok(NULL,"^");
			
			
			/*Usesdesc=strtok(NULL,"^");
			UsesColourIndS=strtok(NULL,"^");
			Usest5PrtCatCodeS=strtok(NULL,"^");
			Usest5ColourIDS=strtok(NULL,"^");
			Usest5CoatedS=strtok(NULL,"^");
			Usest5PartStatusS=strtok(NULL,"^");
			Usesdesigngroup=strtok(NULL,"^");
			Usesprojectcode=strtok(NULL,"^");
			UseslifecycleS=strtok(NULL,"^");
			Usesmod_desc=strtok(NULL,"^");
			UsesDrawingIndS=strtok(NULL,"^");
			UsesPartTypeS=strtok(NULL,"^");
			Usest5PartCodeS=strtok(NULL,"^");			
			UsesFromDate=strtok(NULL,"^");
			UsesToDate=strtok(NULL,"^");
			*/			

			printf("UsesLevel	   :: [%s]\n",UsesLevel);
			printf("UsesClrPart	   :: [%s]\n",UsesClrPart);
			printf("UsesClrRev	   :: [%s]\n",UsesClrRev);
			printf("UsesClrSeq	   :: [%s]\n",UsesClrSeq);
			printf("UsesNonColorPart:: [%s]\n",UsesNonColorPart);
			printf("NonRev:: [%s]\n",NonRev);
			printf("NonSeq:: [%s]\n",NonSeq);

			itemRevSeq = NULL;
			itemRevSeq=(char *) MEM_alloc(32);
			strcpy(itemRevSeq,UsesClrRev);
			strcat(itemRevSeq,";");
			strcat(itemRevSeq,UsesClrSeq);
			printf("\n itemRevSeq:: [%s]\n",itemRevSeq);
						
			if(tc_strcmp(UsesLevel,"0")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"1")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"2")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"3")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"4")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"5")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"6")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"7")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"8")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"9")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"10")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"11")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"12")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"13")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"14")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"15")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"16")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"17")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"18")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"19")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"20")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"21")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"22")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"23")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"24")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"25")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"26")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"27")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"28")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"29")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else if(tc_strcmp(UsesLevel,"30")==0)
			{
				ITK_CALL(MultilevelColourBOMCreate(UsesClrPart,itemRevSeq,UsesNonColorPart));
			}else
			{
				printf("UsesLevel is not match	   :: [%s]\n",UsesLevel);
			}
		}
	}

    ITK_exit_module ( TRUE );
    if ( SS_NOMEM == stat )
    return 4;
    
	if ( ITK_ok != stat )
    return 6;
    
	return ITK_ok;
}

static void handle_itk_error
    ( int stat,                           /* <I> */
      int source_code_line,               /* <I> */
      const char *source_code_file_name   /* <I> */
    )
{
    if ( VOO_debug )
    {
        int          n_ifails=0;
        const int   *severities=NULL;
        const int   *ifails=NULL;
        const char **texts=NULL;
        char        *errstring=NULL;

        fprintf( stderr, "Error detected\n" );
        fflush( stderr);
        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts );
        if ( n_ifails && texts != NULL )
        {
            if ( ifails[n_ifails-1] == stat )
            {
                fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (texts[n_ifails-1]==NULL?"null":texts[n_ifails-1]) );
            }
            else
            {
                EMH_ask_error_text( stat, &errstring );
                fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (errstring==NULL?"null":errstring) );
                MEM_free( errstring );
            }
        }
        else
        {
            EMH_ask_error_text( stat, &errstring );
            fprintf( stderr, "%s: Error %d: %s\n", VOO_prog, stat, (errstring==NULL?"null":errstring) );
            MEM_free( errstring );
        }
        fprintf( stderr, "%s %s: Error: Line %d in %s\n", VOO_prog, VOO_time_stamp(), source_code_line, source_code_file_name );
    }
}

static int VOO_variant_expression
    ( tag_t        v1,               /* <I> */
      int          op,               /* <I> */
      tag_t        v2,               /* <I> */
      const char * text,             /* <I> */
      tag_t      * ve,               /* <O> */
      logical    * was_new           /* <O> */
    )
{
    static variant_rule_option_data_t expression_hash={NULL};

    return VOO_expression_hash( VOO_HASH_SIZE, expression_hash, v1, op, v2, text, TRUE, ve, was_new );
}

static int VOO_expression_hash
    ( int          hash_size,            /* <I> */
      vector_t   * hash[],               /* <I> */
      tag_t        val1,                 /* <I> */
      int          oper,                 /* <I> */
      tag_t        val2,                 /* <I> */
      const char * text,                 /* <I> */
      logical      add_if_new,           /* <I> */
      tag_t      * var_exp,              /* <O> */
      logical    * was_new               /* <O> */
    )
{
    int     stat=ITK_ok;
    int     key;
    int     inx;
    tag_t * hashed_val1=NULL;
    int   * hashed_oper=NULL;
    tag_t * hashed_val2=NULL;
    char  * hashed_text=NULL;
    tag_t * hashed_var_exp=NULL;

    *was_new = TRUE;
    if ( val1 != NULLTAG )
    {
        key = (val1+val2) % hash_size;
        if ( NULL != hash[key] )
        {
            for ( inx=vector_size( hash[key] )-5; inx>=0; inx-=5 )
            {
                hashed_val1 = (tag_t *)vector_get( hash[key], inx );
                hashed_oper = (int *)  vector_get( hash[key], inx+1 );
                hashed_val2 = (tag_t *)vector_get( hash[key], inx+2 );
                hashed_text = (char *) vector_get( hash[key], inx+3 );
                if ( *hashed_val1 == val1 &&
                     *hashed_oper == oper &&
                     *hashed_val2 == val2 &&
                     0 == tc_strcmp( hashed_text, text ) )
                {
                    hashed_var_exp = (tag_t *)vector_get( hash[key], inx+4 );
                    *was_new = FALSE;
                    break;
                }
            }
        }
        if ( *was_new && add_if_new )
        {
            if ( NULL == hash[key] )
                hash[key] = vector_new( 50, 50 );
            if ( (hashed_val1 = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                *hashed_val1 = val1;
            if ( (hashed_oper = (int *)MEM_alloc( sizeof ( int ) )) != NULL )
                *hashed_oper = oper;
            if ( (hashed_val2 = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                *hashed_val2 = val2;
            if ( NULL == text )
                hashed_text = NULL;
            else
                hashed_text = MEM_string_copy( text );
            if ( (hashed_var_exp = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                ITK ( BOM_new_variant_expression( val1, oper, val2, text, hashed_var_exp ) )
            hash[key] = vector_add( hash[key], hashed_val1 );
            hash[key] = vector_add( hash[key], hashed_oper );
            hash[key] = vector_add( hash[key], hashed_val2 );
            hash[key] = vector_add( hash[key], hashed_text );
            hash[key] = vector_add( hash[key], hashed_var_exp );
        }
    }
    else /* flush hash table */
    {
        for ( key=0; key<hash_size; key++ )
        {
            if ( NULL != hash[key] )
            {
                for ( inx=vector_size( hash[key] )-1; inx>=0; inx-- )
                    MEM_free( vector_get( hash[key], inx ) );
                hash[key] = vector_free( hash[key] );
            }
        }
    }
    *var_exp = (hashed_var_exp==NULL?NULLTAG:*hashed_var_exp);
    if ( VOO_debug )
    {
        char *t=NULL;

        ITK ( BOM_variant_expression_as_text( *var_exp, &t ) )
        fprintf( stderr, "%s %s: %s variant expression %s\n", VOO_prog, VOO_time_stamp(), (*was_new?"new":"re-using"), (NULL==t?"null":t) );
        MEM_free( t );
    }
    return stat;
}

static int VOO_combine_ves
    ( int       n_ves,            /* <I> */
      tag_t   * ves,              /* <I> */
      int       oper,             /* <I> */
      tag_t   * combined_ve,      /* <O> */
      int     * n_ves_2_save,     /* <O> */
      tag_t  ** ves_2_save        /* <OF> */
    )
{
    int stat=ITK_ok;

    *combined_ve = NULLTAG;
    if ( 0 < n_ves )
    {
        if ( 1 == n_ves )
        {
            *combined_ve = ves[0];
        }
        else if ( 2 == n_ves )
        {
            logical was_new=FALSE;

            ITK ( VOO_variant_expression( ves[0], oper, ves[1], NULL, combined_ve, &was_new ) )
            if ( was_new )
            {
                *n_ves_2_save += 1;
                if ( ((*ves_2_save) = (tag_t *)MEM_realloc( (void *)(*ves_2_save),
                                                                      *n_ves_2_save * sizeof( tag_t ) ))
                                    != NULL )
                    (*ves_2_save)[*n_ves_2_save - 1] = *combined_ve;
                else
                    ITK ( SS_NOMEM )
            }
        }
        else
        {
            tag_t ves_2_combine[2];

            ves_2_combine[1] = ves[n_ves-1];
            ITK ( VOO_combine_ves( n_ves-1, ves,     oper, &ves_2_combine[0], n_ves_2_save, ves_2_save ) )
            ITK ( VOO_combine_ves( 2,       ves_2_combine, oper, combined_ve, n_ves_2_save, ves_2_save ) )
        }
    }

    return stat;
}

static int VOO_off_variant_expressions
    ( int      oper,                          /* <I> */
      int      n_off_expressions,             /* <I> */
      tag_t  * option_revs,                   /* <I> */
      tag_t  * off_expressions,               /* <O> */
      int    * n_ves_2_save,                  /* <I/O> */
      tag_t ** ves_2_save                     /* <I/OF> */
    )
{
    int     stat=ITK_ok;
    int     inx, jnx;
    int     n_option_rev_value_indexes=0;
    int    *option_rev_value_indexes=NULL;
    char   *option_rev_value=NULL;

    for ( inx=0; inx<n_off_expressions; inx++ )
    {
        n_option_rev_value_indexes = 0;
        option_rev_value_indexes = NULL;
        ITK ( BOM_list_option_rev_values( option_revs[inx], &n_option_rev_value_indexes, &option_rev_value_indexes ) )
        off_expressions[inx] = NULLTAG;
        for ( jnx=0; jnx<n_option_rev_value_indexes; jnx++ )
        {
            logical value_is_set_to_off;

            option_rev_value = NULL;
            ITK ( BOM_ask_option_rev_value(  option_revs[inx], option_rev_value_indexes[jnx], &option_rev_value ) )
            value_is_set_to_off = VOO_value_is_set_to_off( option_rev_value );
            MEM_free( option_rev_value );
            if ( value_is_set_to_off )
            {
                char   *option_rev_value_index_text=NULL;
                logical was_new=FALSE;
                tag_t   option=NULLTAG;

                option_rev_value_index_text = (char*)MEM_alloc(( MAX_INT_LENGTH + 1 ) * sizeof (char));
                if ( option_rev_value_index_text == NULL )
                   ITK ( SS_NOMEM )
                sprintf( option_rev_value_index_text, "%d", option_rev_value_indexes[jnx] );
                ITK ( BOM_ask_option_of_rev( option_revs[inx], &option ) )
                ITK ( VOO_variant_expression( option, oper, NULLTAG, option_rev_value_index_text, &off_expressions[inx], &was_new ) )
                if ( was_new )
                {
                    *n_ves_2_save += 1;
                    if ( ((*ves_2_save) = (tag_t *)MEM_realloc( (void *)(*ves_2_save),
                                                                          *n_ves_2_save * sizeof( tag_t ) ))
                                        != NULL )
                        (*ves_2_save)[*n_ves_2_save - 1] = off_expressions[inx];
                    else
                        ITK ( SS_NOMEM )
                }
                MEM_free( option_rev_value_index_text );
                break;
            }
        }
        MEM_free( option_rev_value_indexes );
        if ( ITK_ok == stat && NULLTAG == off_expressions[inx] )
        {
            tag_t option=NULLTAG;
            tag_t option_item=NULLTAG;
            char *option_name=NULL;
            char *option_desc=NULL;

            ITK ( BOM_ask_option_of_rev( option_revs[inx], &option ) )
            ITK ( BOM_ask_option_data( option, &option_item, &option_name, &option_desc ) )
            ITK ( ITK_internal_error )
            fprintf( stderr, "%s %s: none of the values of option %s are detected as an off value\n",
                              VOO_prog, VOO_time_stamp(), (NULL==option_name?"null":option_name) );
            MEM_free( option_name );
            MEM_free( option_desc );
        }
    }

    return stat;
}

static int VOO_binary_constraints
    ( int      n_option_data,                 /* <I> */
      void  ** option_data,                   /* <I> */
      char   * constraint_error_text,         /* <I> */
      char   * toggle_ve_string,              /* <I> */
      tag_t    bom_variant_rule,              /* <I> */
      tag_t  * e_block,                       /* <I/O> */
      int    * n_ves_2_save,                  /* <I/O> */
      tag_t ** ves_2_save                     /* <I/OF> */
    )
{
    int     stat=ITK_ok;
    char   *option_name=NULL;
    int     inx, jnx, knx;
    tag_t   option1=NULLTAG;
    tag_t  *option1_rev=NULL;
    tag_t   option1_item=NULLTAG;
    char   *option1_name=NULL;
    char   *option1_desc=NULL;
    char   *option1_family=NULL;
    char   *option1_code=NULL;
    tag_t   option2=NULLTAG;
    tag_t  *option2_rev=NULL;
    tag_t   option2_item=NULLTAG;
    char   *option2_name=NULL;
    char   *option2_desc=NULL;
    char   *option2_family=NULL;
    char   *option2_code=NULL;
    int     family_size=2;
    int     n_ves=0;
    tag_t  *ves=NULL;
    tag_t   toggle_ve=NULLTAG;



    if ( NULL != toggle_ve_string && NULLTAG == toggle_ve )
    {
        char   *toggle_value=NULL;
        tag_t   toggle_option=NULLTAG;
        tag_t   toggle_option_rev=NULLTAG;
        int     toggle_value_index=-1;
        char   *v2_text=NULL;
        logical was_new=FALSE;

        toggle_ve_string = MEM_string_copy( toggle_ve_string );
        if ( (toggle_value = strchr( toggle_ve_string, '=' )) != NULL )
        {
            *toggle_value++ = '\0';
            ITK ( BOM_variant_rule_find_option( bom_variant_rule, NULLTAG, toggle_ve_string, &toggle_option, &toggle_option_rev ) )
            ITK ( BOM_ask_index_of_opt_rev_value( toggle_option_rev, toggle_value, &toggle_value_index ) )
            v2_text = (char*)MEM_alloc(( MAX_INT_LENGTH + 1 ) * sizeof (char));
            if ( v2_text == NULL )
               ITK ( SS_NOMEM )
            sprintf( v2_text, "%d", toggle_value_index);
            ITK ( VOO_variant_expression( toggle_option, BOM_variant_operator_is_equal + BOM_variant_op_rhs_is_string, NULLTAG, v2_text, &toggle_ve, &was_new ) )
            if ( ITK_ok == stat && was_new )
            {
                *n_ves_2_save += 1;
                if ( ((*ves_2_save) = (tag_t *)MEM_realloc( (void *)(*ves_2_save),
                                                                      *n_ves_2_save * sizeof( tag_t ) ))
                                    != NULL )
                    (*ves_2_save)[*n_ves_2_save - 1] = toggle_ve;
                else
                    ITK ( SS_NOMEM )
            }
            MEM_free( v2_text );
        }
        else
        {
            ITK ( BOM_option_condition_not_added )
            fprintf( stderr, "%s %s: Error: option expression >%s< contains no equal sign (=)\n", VOO_prog, VOO_time_stamp(), toggle_ve_string );
            toggle_ve_string = NULL;
            toggle_ve = NULLTAG;
        }
        MEM_free( toggle_ve_string );
    }

    if ( NULLTAG == *e_block )
    {
        ITK ( BOM_new_variant_e_block ( e_block ) )
    }
    else
    {
        ITK ( BOM_ask_variant_e_block ( *e_block, &n_ves, &ves ) )
    }
    for ( inx=0; inx<n_option_data; inx+=family_size )
    {
        family_size = 2;
        option1_name = NULL;
        option1_desc = NULL;
        option1_family = NULL;
        option1_code = NULL;
        option1_rev = (tag_t *)option_data[inx];
        option1     = NULLTAG;
        ITK ( BOM_ask_option_of_rev( *option1_rev, &option1 ) )
        ITK ( BOM_ask_option_data( option1, &option1_item, &option1_name, &option1_desc ) )
        if ( VOO_debug )
        {
            fprintf( stderr, "%s %s: processing option >%s<\n", VOO_prog, VOO_time_stamp(), (option1_name==NULL?"null":option1_name) );
        }
        if ( VOO_is_stand_alone_option( option1_name ) )
        {
            MEM_free( option1_name );
            MEM_free( option1_desc );
            continue;
        }
        VOO_option_family_and_code( option1_name, &option1_family, &option1_code );

        for ( jnx=inx+family_size; jnx<n_option_data; jnx+=2 )
        {
            option2_name = NULL;
            option2_desc = NULL;
            option2_family = NULL;
            option2_code = NULL;
            option2_rev = (tag_t *)option_data[jnx];
            option2     = NULLTAG;
            ITK ( BOM_ask_option_of_rev( *option2_rev, &option2 ) )
            ITK ( BOM_ask_option_data( option2, &option2_item, &option2_name, &option2_desc ) )
            if ( !VOO_is_stand_alone_option( option2_name ) )
            {
                VOO_option_family_and_code( option2_name, &option2_family, &option2_code );

                if ( 0 == tc_strcmp( option1_family, option2_family ) ) /* a member of the same family */
                {
                    void *swap_rev=NULL;
                    void *swap_inx=NULL;

                    swap_rev = option_data[jnx];
                    swap_inx = option_data[jnx+1];
                    option_data[jnx]   = option_data[inx+family_size];
                    option_data[jnx+1] = option_data[inx+family_size+1];
                    option_data[inx+family_size]   = swap_rev;
                    option_data[inx+family_size+1] = swap_inx;
                    family_size += 2;
                }
            }
            MEM_free( option2_name );
            MEM_free( option2_desc );
            MEM_free( option2_family );
            MEM_free( option2_code );
        }
        if ( VOO_debug )
        {
            fprintf( stderr, "%s %s: family >%s< is represented with %d option revs\n", VOO_prog, VOO_time_stamp(), (option1_family==NULL?"null":option1_family), family_size/2 );
        }
        if ( family_size != 2 )
        {
            int  n_unique_family_option_revs=0;
            tag_t *unique_family_option_revs=NULL;

            if ( (unique_family_option_revs = (tag_t *)MEM_realloc( (void *)unique_family_option_revs,
                                                                              (n_unique_family_option_revs+1) * sizeof ( tag_t ) ))
                                            == NULL )
                ITK ( SS_NOMEM )
            else
                unique_family_option_revs[n_unique_family_option_revs++] = *option1_rev;
            for ( jnx=inx+2; jnx<inx+family_size; jnx+=2 )
            {
                option2_rev = (tag_t *)option_data[jnx];
                knx = 0;
                while ( knx<n_unique_family_option_revs )
                {
                    if ( *option2_rev == unique_family_option_revs[knx] ) /* duplicate */
                        break;
                    else
                        knx++;
                }
                if ( knx == n_unique_family_option_revs )
                {
                    if ( (unique_family_option_revs = (tag_t *)MEM_realloc( (void *)unique_family_option_revs,
                                                                                      (n_unique_family_option_revs+1) * sizeof ( tag_t ) ))
                                                    == NULL )
                        ITK ( SS_NOMEM )
                    else
                        unique_family_option_revs[n_unique_family_option_revs++] = *option2_rev;
                }
            }
            if ( n_unique_family_option_revs > 1 )
            {
                tag_t  *off_expressions=NULL;
                tag_t  *on_expressions=NULL;
                tag_t  *combined_expressions=NULL;
                tag_t   top_level_family_expression=NULLTAG;
                tag_t   error_if_ve=NULLTAG;
                logical was_new=FALSE;

                if ( VOO_debug )
                {
                    fprintf( stderr, "%s %s: family >%s< has %d options\n", VOO_prog, VOO_time_stamp(), (option1_family==NULL?"null":option1_family), n_unique_family_option_revs );
                }

                if ( (off_expressions = (tag_t *)MEM_alloc( n_unique_family_option_revs * sizeof ( tag_t ) )) == NULL )
                    ITK ( SS_NOMEM )
                if ( ( on_expressions = (tag_t *)MEM_alloc( n_unique_family_option_revs * sizeof ( tag_t ) )) == NULL )
                    ITK ( SS_NOMEM )
                if ( (combined_expressions = (tag_t *)MEM_alloc( n_unique_family_option_revs * sizeof ( tag_t ) )) == NULL )
                    ITK ( SS_NOMEM )
                ITK ( VOO_off_variant_expressions( BOM_variant_operator_is_equal + BOM_variant_op_rhs_is_string,
                                                   n_unique_family_option_revs,
                                                   unique_family_option_revs,
                                                   off_expressions,
                                                   n_ves_2_save,
                                                   ves_2_save ) )
                ITK ( VOO_off_variant_expressions( BOM_variant_operator_not_equal + BOM_variant_op_rhs_is_string,
                                                   n_unique_family_option_revs,
                                                   unique_family_option_revs,
                                                   on_expressions,
                                                   n_ves_2_save,
                                                   ves_2_save ) )
                for ( jnx=0; jnx<n_unique_family_option_revs-1; jnx++ )
                {
                    tag_t ves_2_combine[2];

                    ves_2_combine[0] = on_expressions[jnx];
                    ITK ( VOO_combine_ves( n_unique_family_option_revs-(1+jnx),
                                           &on_expressions[jnx+1],
                                           BOM_variant_operator_or,
                                           &ves_2_combine[1],
                                           n_ves_2_save,
                                           ves_2_save ) )
                    ITK ( VOO_combine_ves( 2,
                                           ves_2_combine,
                                           BOM_variant_operator_and,
                                           &combined_expressions[jnx],
                                           n_ves_2_save,
                                           ves_2_save ) )
                }
                ITK ( VOO_combine_ves( n_unique_family_option_revs,
                                       off_expressions,
                                       BOM_variant_operator_and,
                                       &combined_expressions[n_unique_family_option_revs-1],
                                       n_ves_2_save,
                                       ves_2_save ) )
                ITK ( VOO_combine_ves( n_unique_family_option_revs,
                                       combined_expressions,
                                       BOM_variant_operator_or,
                                       &top_level_family_expression,
                                       n_ves_2_save,
                                       ves_2_save ) )

                if ( NULLTAG != toggle_ve )
                {
                    tag_t ves_2_combine[2];

                    ves_2_combine[0] = top_level_family_expression;
                    ves_2_combine[1] = toggle_ve;
                    ITK ( VOO_combine_ves( 2, ves_2_combine, BOM_variant_operator_and, &top_level_family_expression, n_ves_2_save, ves_2_save ) )
                }

                ITK ( VOO_variant_expression( top_level_family_expression,
                                              BOM_variant_operator_error_if+BOM_variant_op_rhs_is_string,
                                              NULLTAG,
                                              constraint_error_text,
                                              &error_if_ve,
                                              &was_new ) )
                if ( ITK_ok == stat && was_new )
                {
                    *n_ves_2_save += 1;
                    if ( ((*ves_2_save) = (tag_t *)MEM_realloc( (void *)(*ves_2_save),
                                                                          *n_ves_2_save * sizeof( tag_t ) ))
                                        != NULL )
                        (*ves_2_save)[*n_ves_2_save - 1] = error_if_ve;
                    else
                        ITK ( SS_NOMEM )
                }

                n_ves += 1;
                ves = (tag_t *)MEM_realloc( (void *)ves, n_ves * sizeof( tag_t ) );
                ves[n_ves-1] = error_if_ve;

                if ( VOO_debug )
                {
                    char *t=NULL;

                    ITK ( BOM_variant_expression_as_text( error_if_ve, &t ) )
                    fprintf( stderr, "%s %s: constraint for family >%s<: %s\n",
                                      VOO_prog, VOO_time_stamp(), (NULL==option1_family?"null":option1_family), (NULL==t?"null":t) );
                    MEM_free( t );
                }
                MEM_free( off_expressions );
                MEM_free( on_expressions );
                MEM_free( combined_expressions );
            }
        }
        MEM_free( option1_name );
        MEM_free( option1_desc );
        MEM_free( option1_family );
        MEM_free( option1_code );
    }
    ITK ( BOM_set_variant_e_block ( *e_block, n_ves, ves ) )
    MEM_free( ves );

    return stat;
}

static int VOO_n_referencers
    ( tag_t obj,                            /* <I> */
      int n_levels                          /* <I> */
    )
{
    static int level=0;
    int     stat=ITK_ok;
    tag_t   instance_tag=NULLTAG;
    tag_t  *ref_instances=NULL;
    tag_t  *ref_classes=NULL;
    int     n_instances=0;
    int    *instance_levels=NULL;
    int    *instance_where_found=NULL;
    int     n_classes=0;
    int    *class_levels=NULL;
    int    *class_where_found=NULL;
    int     inx, jnx;

    if ( level >= n_levels )
        return stat;

    level += 1;
    ITK ( POM_referencers_of_instance( obj, 1, POM_in_ds_and_db,
                                       &n_instances, &ref_instances, &instance_levels, &instance_where_found,
                                       &n_classes, &ref_classes, &class_levels, &class_where_found ) )
    for ( inx=0; inx<n_instances; inx++ )
    {
        if ( VOO_debug )
        {
            char *as_string=NULL;

            fprintf( stderr, "%s %s: ", VOO_prog, VOO_time_stamp() );
            for ( jnx=0; jnx<level; jnx++ )
                fprintf( stderr, "  " );

            ITK ( AOM_tag_to_string( ref_instances[inx], &as_string ) )
            fprintf( stderr, "%s(%s): ", (as_string==NULL?"null":as_string),
                                (POM_in_ds_only==instance_where_found[inx]   ? "DS only":
                                (POM_in_db_only==instance_where_found[inx]   ? "DB only":
                                (POM_in_ds_and_db==instance_where_found[inx] ? "DS & DB":
                                                                               "Unknown"))) );
            VOO_show_wso( ref_instances[inx] );
            VOO_n_referencers( ref_instances[inx], n_levels );
            MEM_free( as_string );
        }
    }
    MEM_free( ref_instances );
    MEM_free( instance_levels );
    MEM_free( instance_where_found );
    MEM_free( ref_classes );
    MEM_free( class_levels );
    MEM_free( class_where_found );
    level -= 1;
    return n_instances;
}

static void VOO_option_family_and_code
    ( char  *option_name,               /* <I> */
      char **option_family,             /* <OF> */
      char **option_code                /* <OF> */
    )
{
    char *local_option_family=NULL;
    char *local_option_code=NULL;

    *option_family = NULL;
    *option_code = NULL;
    if ( NULL != option_name )
    {
        while ( '\0' != *option_name && NULL != strchr( VOO_family_code_separators, *option_name ) )
        {
            option_name += 1;
        }
        if ( NULL != option_name && NULL != VOO_family_option_prefix )
            if ( 0 == strncmp( option_name, VOO_family_option_prefix, tc_strlen( VOO_family_option_prefix ) ) )
        {
            option_name += tc_strlen( VOO_family_option_prefix );
        }
        local_option_family = MEM_string_copy( option_name );
        if ( (local_option_code = strpbrk( local_option_family, VOO_family_code_separators )) != NULL )
        {
            *local_option_code++ = '\0';
            while ( '\0' != *local_option_code && NULL != strchr( VOO_family_code_separators, *local_option_code ) )
            {
                *local_option_code++ = '\0';
            }
        }
    }
    *option_family = MEM_string_copy( local_option_family );
    *option_code = MEM_string_copy( local_option_code );
    MEM_free( local_option_family );
}

static int VOO_is_value_pair_excluded
    (
      tag_t    option1,                 /* <I> */
      tag_t    option1_rev,             /* <I> */
      int      option1_value_index,     /* <I> */
      tag_t    option2,                 /* <I> */
      tag_t    option2_rev,             /* <I> */
      int      option2_value_index,     /* <I> */
      logical *is_excluded              /* <O> */
    )
{
    int    stat=ITK_ok;
    tag_t  option_item_1=NULLTAG;
    char  *option_name_1=NULL;
    char  *option_desc_1=NULL;
    char  *option_value_1=NULL;
    tag_t  option_item_2=NULLTAG;
    char  *option_name_2=NULL;
    char  *option_desc_2=NULL;
    char  *option_value_2=NULL;
    logical option_is_stand_alone_1=FALSE;
    logical option_is_stand_alone_2=FALSE;

    *is_excluded = option1 == option2; /* two values of the same option are not selectable anyways */

    if ( !*is_excluded && VOO_binary_options )
    {
        ITK ( BOM_ask_option_data( option1, &option_item_1, &option_name_1, &option_desc_1 ) )
        ITK ( BOM_ask_option_data( option2, &option_item_2, &option_name_2, &option_desc_2 ) )
        option_is_stand_alone_1 = VOO_is_stand_alone_option( option_name_1 );
        option_is_stand_alone_2 = VOO_is_stand_alone_option( option_name_2 );

        if ( !option_is_stand_alone_1 && !option_is_stand_alone_2 )
        {
            char *option_family_1=NULL;
            char *option_family_2=NULL;
            char *option_code_1=NULL;
            char *option_code_2=NULL;

            /* if both binary options belong to the same option family we can exlcude this value pair:
             * both options can never be set at the same time anyway */
            VOO_option_family_and_code( option_name_1, &option_family_1, &option_code_1 );
            VOO_option_family_and_code( option_name_2, &option_family_2, &option_code_2 );
            if ( 0 == tc_strcmp( option_family_1, option_family_2 ) )
            {
                *is_excluded = TRUE;
            }
            MEM_free( option_family_1 );
            MEM_free( option_family_2 );
            MEM_free( option_code_1 );
            MEM_free( option_code_2 );
        }
        else if ( VOO_exclude_off_stand_alones )
        {
            /* if one of the two options is a stand alone option with a value of 'OFF' we exlcude this value pair.
             * There would be too many and it is likely the result of an incomplete set of saved variant rules. */
            if ( option_is_stand_alone_1 )
            {
                ITK ( BOM_ask_option_rev_value( option1_rev, option1_value_index, &option_value_1 ) )
                *is_excluded = VOO_value_is_set_to_off( option_value_1 );
            }
            if ( !*is_excluded && ITK_ok == stat )
            {
                if ( option_is_stand_alone_2 )
                {
                    ITK ( BOM_ask_option_rev_value( option2_rev, option2_value_index, &option_value_2 ) )
                    *is_excluded = VOO_value_is_set_to_off( option_value_2 );
                }
            }
        }

        MEM_free( option_name_1 );
        MEM_free( option_desc_1 );
        MEM_free( option_value_1 );
        MEM_free( option_name_2 );
        MEM_free( option_desc_2 );
        MEM_free( option_value_2 );
    }
    return stat;
}

static int VOO_is_option_excluded
    ( vector_t *excluded,               /* <I> */
      tag_t     bom_variant_rule,       /* <I> */
      tag_t     option,                 /* <I> */
      int      *option_value_index,     /* <O> */
      logical  *is_excluded             /* <O> */
    )
{
    static variant_rule_option_data_t excluded_option_values={NULL};
    static variant_rule_option_data_t included_option_values={NULL};
           int                        stat=ITK_ok;
           tag_t                      option_item=NULLTAG;
           tag_t                      option_rev=NULLTAG;
           int                        *option_how_set=-1;
           int                       count;
           char                      *option_name=NULL;
           char                      *option_desc=NULL;
           char                      *option_value=NULL;
           char                      *option_where_set=NULL;


    *option_value_index = -1;
    ITK ( BOM_variant_rule_ask_option_values( bom_variant_rule, option, &option_rev, count,option_value_index, &option_how_set, &option_where_set ) )
    if ( OPTION_UNSET           == option_how_set ||
         OPTION_UNSET_DERIVABLE == option_how_set )
    {
        if ( VOO_debug )
        {
            ITK ( BOM_ask_option_data( option, &option_item, &option_name, &option_desc ) )
            fprintf( stderr, "%s %s: unset: %s(%d)\n", VOO_prog, VOO_time_stamp(), (NULL==option_name?"null":option_name), *option_value_index );
            MEM_free( option_name );
            MEM_free( option_desc );
        }
        MEM_free( option_where_set );
        *is_excluded = TRUE;
        return stat;
    }


    *is_excluded = VOO_option_value_hash( VOO_HASH_SIZE, excluded_option_values, option, *option_value_index, FALSE );
    if ( !VOO_option_value_hash( VOO_HASH_SIZE, included_option_values, option, *option_value_index, FALSE ) )
    {
        if ( !*is_excluded )
        {
            ITK ( BOM_ask_option_data( option, &option_item, &option_name, &option_desc ) )

            /* `excluded' is a vector of option name strings, which is filled with command line option -excluded_option=Option_Name */
            if ( NULL != excluded )
            {
                int    inx;

                for ( inx=0; inx<vector_size( excluded ); inx++ )
                {
                    if ( 0 == tc_strcmp( vector_get( excluded, inx ), option_name ) )
                    {
                        *is_excluded = TRUE;
                        break;
                    }
                }
            }
        }

        if ( !*is_excluded && ITK_ok == stat && VOO_binary_options )
        {
            ITK ( BOM_ask_option_rev_value( option_rev, *option_value_index, &option_value ) )
            /* exlcude 'OFF' values for binary family options.
             * Family options cannot have no value set - one of the values *must* be set.
             * Therefore we can safely exclude constraints involving 'OFF' values. */
            if ( !VOO_is_stand_alone_option( option_name ) && VOO_value_is_set_to_off( option_value ) )
            {
                *is_excluded = TRUE;
            }
        }

    }

    if ( ITK_ok == stat )
    {
        if ( *is_excluded )
        {
            if ( !VOO_option_value_hash( VOO_HASH_SIZE, excluded_option_values, option, *option_value_index, TRUE ) &&
                  VOO_debug )
            {
                fprintf( stderr, "%s %s: excluded: %s=%s(%d)\n", VOO_prog, VOO_time_stamp(), (NULL==option_name?"null":option_name), (NULL==option_value?"*":option_value), *option_value_index );
            }
        }
        else
        {
            if ( !VOO_option_value_hash( VOO_HASH_SIZE, included_option_values, option, *option_value_index, TRUE ) &&
                  VOO_debug )
            {
                fprintf( stderr, "%s %s: added: %s=%s(%d)\n", VOO_prog, VOO_time_stamp(), (NULL==option_name?"null":option_name), (NULL==option_value?"*":option_value), *option_value_index );
            }
        }
    }

    MEM_free( option_name );
    MEM_free( option_desc );
    MEM_free( option_where_set );
    MEM_free( option_value );

    return stat;
}

static logical VOO_is_stand_alone_option
    ( char *option_name                  /* <I> */
    )
{
    return 0 == tc_strncasecmp( option_name, VOO_stand_alone_option_prefix, tc_strlen( VOO_stand_alone_option_prefix ) );
}

static logical VOO_value_is_set_to_off
    ( char *option_value                 /* <I> */
    )
{
    logical value_is_set_to_off=FALSE;

    if ( NULL != VOO_binary_off_values )
    {
        int inx;

        for ( inx=0; inx<vector_size( VOO_binary_off_values ) && !value_is_set_to_off; inx++ )
        {
            value_is_set_to_off = 0 == tc_strcasecmp( (char *)vector_get( VOO_binary_off_values, inx ), option_value );
        }
    }
    else if ( NULL != option_value )
    {
        if ( tc_strcasecmp( "N",     option_value ) ||
             tc_strcasecmp( "F",     option_value ) ||
             tc_strcasecmp( "0",     option_value ) ||
             tc_strcasecmp( "No",    option_value ) ||
             tc_strcasecmp( "None",  option_value ) ||
             tc_strcasecmp( "Off",   option_value ) ||
             tc_strcasecmp( "False", option_value )    )
            value_is_set_to_off = TRUE;
    }

    return value_is_set_to_off;
}

static logical VOO_option_value_hash
    ( int       hash_size,               /* <I> */
      vector_t *hash[],                  /* <I> */
      tag_t     option_rev,              /* <I> */
      int       option_rev_value_index,  /* <I> */
      int       add_if_new               /* <I> */
    )
{
    logical was_new=TRUE;
    int     key;
    int     inx;
    tag_t * hashed_option_rev=NULL;
    int   * hashed_option_rev_value_index=NULL;

    if ( option_rev != NULLTAG )
    {
        key = option_rev % hash_size;
        if ( NULL != hash[key] )
        {
            for ( inx=vector_size( hash[key] )-2; inx>=0; inx-=2 )
            {
                hashed_option_rev             = (tag_t *)vector_get( hash[key], inx );
                hashed_option_rev_value_index = (int *)  vector_get( hash[key], inx+1 );
                if ( *hashed_option_rev == option_rev && *hashed_option_rev_value_index == option_rev_value_index )
                {
                    was_new = FALSE;
                    break;
                }
            }
        }
        if ( was_new && add_if_new )
        {
            if ( NULL == hash[key] )
                hash[key] = vector_new( 10, 10 );
            if ( (hashed_option_rev = (tag_t *)MEM_alloc( sizeof ( tag_t ) )) != NULL )
                *hashed_option_rev = option_rev;
            if ( (hashed_option_rev_value_index = (int *)MEM_alloc( sizeof ( int ) )) != NULL )
                *hashed_option_rev_value_index = option_rev_value_index;
            hash[key] = vector_add( hash[key], hashed_option_rev );
            hash[key] = vector_add( hash[key], hashed_option_rev_value_index );
        }
    }
    else /* flush hash table */
    {
        for ( key=0; key<hash_size; key++ )
        {
            if ( NULL != hash[key] )
            {
                for ( inx=vector_size( hash[key] )-1; inx>=0; inx-- )
                    MEM_free( vector_get( hash[key], inx ) );
                hash[key] = vector_free( hash[key] );
            }
        }
    }
    return !was_new;
}

/****************************************************************************
 * Function:        VOO_list_saved_variant_rules
 *
 * Purpose:         same as ICTVariantRule::listVRules
 *
 * Parameter:       int itemRev: the ItemRevision for which variant rules
 *                               are asked e.g. the top level ItemRev
 *                  int * nVRules: the numebr of returned variant rules
 *                  tag_t ** vRules: Tag Array of variant rules.<OF>
 *
 * Return codes:    The last ITK return status, ITK_ok on success
 *
 ***************************************************************************/
static int VOO_list_saved_variant_rules
    ( tag_t    itemRev,
      int *    n_variant_rules,
      tag_t ** variant_rules
    )
{
    int         n_secondaries=0;
    tag_t      *secondaries=NULL;
    int         stat=ITK_ok;

    *variant_rules = NULL;
    *n_variant_rules = 0;

	//   fprintf( stderr, "inside functionss VOO_list_saved_variant_rules" );

    ITK ( GRM_list_secondary_objects_only( itemRev, NULLTAG, &n_secondaries, &secondaries ) )
	
//	fprintf( stderr, "n_secondaries :%d" ,n_secondaries	);

    /*  Collect together all the variant_rules */

    if ( n_secondaries )
    {
        *variant_rules = (tag_t *)MEM_alloc( n_secondaries * sizeof ( tag_t ) );
        if ( NULL == variant_rules )
        {
            ITK ( SS_NOMEM )
        }
        else
        {
            int inx;
            tag_t varRuleClass=NULLTAG;

            ITK ( POM_class_id_of_class ( "VariantRule", &varRuleClass ) )
            for ( inx = 0; inx < n_secondaries; inx++ )
            {
                tag_t   classId=NULLTAG;
                logical isVRule=FALSE;

                ITK ( POM_class_of_instance( secondaries[inx], &classId ) )
                ITK ( POM_is_descendant( varRuleClass, classId, &isVRule ) )
                if ( isVRule )
                {
                    (*variant_rules)[(*n_variant_rules)++] = secondaries[inx];
                }
            }
        }
    }
    MEM_free( secondaries );
    return stat;
}

/*
 * function:        VOO_show_wso
 *
 * purpose:         print out some information about a WorkspaceObject (debug)
 *
 * description:     displays the name, type, desc and the object ID string
 *                  of a WorkspaceObject.
 *
 * parameters:      tag_t wso:                  WorkspaceObject to show <I>
 *
 * return codes:    The last ITK return status, ITK_ok on success
 *
 */
static int VOO_show_wso ( tag_t wso ) {
    int                  stat=ITK_ok;
    tag_t                instance_class=NULLTAG;
    static tag_t         wso_class=NULLTAG;
    static tag_t         ve_class=NULLTAG;
    static int           not_initialized=TRUE;
    logical              is_wso=FALSE;

    // fprintf( stderr, "inside function VOO_show_wso");

	if ( not_initialized ) {
        ITK ( POM_class_id_of_class ( "WorkspaceObject", &wso_class ) )
        ITK ( POM_class_id_of_class ( "VariantExpression", &ve_class ) )
        not_initialized = FALSE;
    }

    if ( NULLTAG == wso ) {
        fprintf( stderr, "VOO_show_wso: Can't show info for a NULLTAG\n" );
        return stat;
    }

    ITK ( POM_class_of_instance ( wso, &instance_class ) )
    ITK ( POM_is_descendant ( wso_class, instance_class, &is_wso ) )
    if ( ! is_wso ) {
        logical is_ve=FALSE;

        ITK ( POM_is_descendant ( ve_class, instance_class, &is_ve ) )
        if ( is_wso ) {
            char *t=NULL;

            ITK ( BOM_variant_expression_as_text( wso, &t ) )
            fprintf( stderr, "%s %s: VariantExpression: %s: ", VOO_prog, VOO_time_stamp(), (NULL==t?"null":t) );
            MEM_free( t );
        }
        else
        {
            char    *class_name=NULL;

            ITK ( POM_name_of_class ( instance_class, &class_name ) )
            fprintf( stderr, "%s", (NULL==class_name?"null":class_name) );
        }
    }
    else
    {
        char              *obj_id=NULL;
        WSO_description_t  wso_desc;

        ITK ( WSOM_describe ( wso, &wso_desc ) )
        ITK ( WSOM_ask_object_id_string ( wso, &obj_id ) )
        if ( stat == ITK_ok ) {
            fprintf( stderr, "obj_id=%s", (NULL==obj_id?"null":obj_id) );
            MEM_free( obj_id );
/*            fprintf( stderr, ", name=%s", wso_desc.object_name );                             */
/*            fprintf( stderr, ", description=%s", wso_desc.description );                      */
            fprintf( stderr, ", type=%s", wso_desc.object_type );
/*            fprintf( stderr, ", owner=%s", wso_desc.owners_name );                            */
/*            fprintf( stderr, ", owning_group=%s", wso_desc.owning_group_name );               */
/*            fprintf( stderr, ", appl=%s", wso_desc.application );                             */
/*            fprintf( stderr, ", created=%s", wso_desc.date_created );                         */
/*            fprintf( stderr, ", modified=%s", wso_desc.date_modified );                       */
/*            fprintf( stderr, ", last_modifying_user=%s", wso_desc.last_modifying_user_name ); */
/*            fprintf( stderr, ", release_date=%s", wso_desc.date_released );                   */
/*            fprintf( stderr, ", release_status=%s", wso_desc.released_for );                  */
/*            fprintf( stderr, ", id=%s", wso_desc.id_string );                                 */
/*            fprintf( stderr, ", revision=%d", wso_desc.revision_number );                     */
/*            fprintf( stderr, ", revision_limit=%d", wso_desc.revision_limit );                */
/*            fprintf( stderr, ", archive_date=%s", wso_desc.archive_date );                    */
/*            fprintf( stderr, ", backup_date=%s", wso_desc.backup_date );                      */
/*            fprintf( stderr, ", is_frozen=%d", wso_desc.is_frozen );                          */
/*            fprintf( stderr, ", is_reserved=%d", wso_desc.is_reserved );                      */
/*            fprintf( stderr, ", revision_id=%s", wso_desc.revision_id );                      */
/*            fprintf( stderr, ", owning_site=%s", wso_desc.owning_site_name );                 */
        }
    }
    fprintf( stderr, "\n" );
    return stat;
}

static int VOO_hash_to_array(
        int       hash_size,        /* <I> */
        vector_t *hash[],           /* <I> */
        int      *n_option_data,    /* <O> */
        void   ***option_data )     /* <OF> */
{
    int    inx, jnx;
    int    local_n_option_data=0;
    void **local_option_data = NULL;

    *n_option_data = 0;
    *option_data   = NULL;
    for ( inx=0; inx<hash_size; inx++ )
    {
        if ( NULL != hash[inx] )
        {
            for ( jnx=vector_size( hash[inx] )-2; jnx>=0; jnx-=2 )
            {
                local_n_option_data += 2;
                if ( (local_option_data = (void **)MEM_realloc( (void *)local_option_data, local_n_option_data * 2 * sizeof( void * ) )) == NULL )
                    return SS_NOMEM;
                local_option_data[local_n_option_data-2] = vector_get( hash[inx], jnx );
                local_option_data[local_n_option_data-1] = vector_get( hash[inx], jnx+1 );
            }
        }
    }
    *n_option_data = local_n_option_data;
    *option_data   = local_option_data;
    return ITK_ok;
}

static char *VOO_time_stamp()
{
    time_t now;
    static char time_stamp[512];

    time( &now );
    sprintf( time_stamp, "%s", ctime( &now ) );
    time_stamp[tc_strlen(time_stamp)-1] = '\0'; /* strip off new line */
    return time_stamp;
}

/*==================================================================================================
      vector stuff
==================================================================================================*/
/**********************************************************************************
 * Function:          vector_new
 *
 * Purpose:           allocates new vector, inital capacity=`capacity'
 *
 * Description:       returns a pointer to a dynamically allocated vector or
 *                    NULL if no memory can be allocated. On success, the
 *                    vector has a initial capacity of `capacity' and will
 *                    grow in steps of `increment'.
 *
 * Parameters:        int capacity;    initial capacity
 *                    int increment;    incremental growth rate when needed
 *
 * Example:           v = vector_new ( 100, 10 );
 *
 * Return Value:      pointer to a dynamically allocated vector
 *                    NULL if no memory can be allocated
 *
 *********************************************************************************/
static vector_t *vector_new ( int capacity, int increment )
{
    vector_t *vector;

    vector = (vector_t *)MEM_alloc( sizeof ( vector_t ) );
    if ( vector == NULL ) {
        return NULL;
    }
    vector->size = 0;
    vector->capacity = capacity;
    vector->increment = increment;
    vector->content = (void **)MEM_alloc( capacity * sizeof ( void * ) );
    if ( vector->content == NULL ) {
        MEM_free( vector );
        return NULL;
    }
    return vector;
}

/***********************************************************************************
 * Function:          vector_add
 *
 * Purpose:           appaends one pointer at the end of the vector
 *
 * Description:       convenient form of vector_add_n(), calls vector_add_n().
 *
 * Parameters:        vector_t *in;    vector to which the element is added
 *                    void *element;    pointer to the element to be added
 *
 * Example:           v = vector_add ( v, "line 1" );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_add ( vector_t *in, void *element )
{
    return vector_add_n ( in, 1, &element );
}

/***********************************************************************************
 * Function:          vector_add_n
 *
 * Purpose:           appaends n pointers at the end of the vector
 *
 * Description:       extend vector `in' if necessary and append n pointers
 *                    to the (possibly reallocated) vector `in'.
 *
 * Parameters:        vector_t *in;        vector to which the element is added
 *                    int n;                number of elements to append
 *                    void *elements[];    array of pointers to elements to add
 *
 * Example:           v = vector_add_n ( v, argc, (void **)argv );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_add_n ( vector_t *in, int n, void *elements[] )
{
    vector_t *out;

    out = vector_ensure_capacity ( in, n );
    if ( out == NULL ) {
        return NULL;
    }
    memcpy ( &out->content[out->size], elements, n * sizeof ( void * ) );
    out->size += n;
    out->capacity -= n;
    return out;
}

/***********************************************************************************
 * Function:          vector_rem_at
 *
 * Purpose:           removes 1 pointer at position `at'
 *
 * Description:       convenient form of vector_rem_n_at, calls vector_rem_n_at()
 *
 * Parameters:        vector_t *in;        vector of which the element is removed
 *                    int at;                position of the element to be removed
 *
 * Example:           v = vector_add_n ( v, 0 );
 *
 * Return Value:      0     if `at' is within bounds [0,`size')
 *                    2     if `at' is out of bounds [0,`size')
 *
 ***********************************************************************************/
static int vector_rem_at ( vector_t *in, int at )
{
    return vector_rem_n_at ( in, 1, at );
}

/***********************************************************************************
 * Function:          vector_rem_n_at
 *
 * Purpose:           removes n pointers from position `at' on
 *
 * Description:       removes `n' pointers beginning at position `at'. Elements
 *                    beyond position `n'+`at' are block moved upward so that
 *                    their sequence is not changed.
 *
 * Parameters:        vector_t *in;        vector of which the elements are removed
 *                    int n;                number of elements to remove
 *                    int at;                position of 1st element to remove
 *
 * Example:           v = vector_add_n ( v, 1, 0 );
 *
 * Return Value:      0   if `at' is within bounds [0,`size')
 *                    2   if `at' is out of bounds [0,`size')
 *
 ***********************************************************************************/
static int vector_rem_n_at ( vector_t *in, int n, int at )
{
    int ret;

    if ( at + n <= in->size ) {
        int i;

        for ( i=at; i<in->size - n; i++ ) {
            in->content[i] = in->content[i+n];
        }
        in->size -= n;
        in->capacity += n;
        ret = 0;
    }
    else {
        fprintf( stderr, "vector_rem_n_at: cannot remove %d elements from position %d in a vector of %d elements\n",
                    n, at, in->size );
        ret = 2;
    }
    return ret;
}

/***********************************************************************************
 * Function:          vector_insert
 *
 * Purpose:           inserts 1 pointer at position 0
 *
 * Description:       inserts 1 pointer at position 0
 *
 * Parameters:        vector_t *in;        vector the elements are to be inserted in
 *                    void *elements;      element to insert
 *
 * Example:           v = vector_insert ( v, (void *)argv[1] );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_insert ( vector_t *in, void *element )
{
    return vector_insert_n_at ( in, 1, &element, 0 );
}

/***********************************************************************************
 * Function:          vector_insert_n_at
 *
 * Purpose:           inserts `n' pointers at position `at'.
 *
 * Description:       inserts `n' pointers at position `at'.
 *
 * Parameters:        vector_t *in;        vector the elements are to be inserted in
 *                    int n;               number of elements to insert
 *                    void *elements[];    elements to insert
 *                    int at;              position of 1st element to insert
 *
 * Example:           v = vector_add_n ( v, argc, (void **)argv, 0 );
 *
 * Return Value:      pointer to a potentially dynamically reallocated vector
 *                    NULL if capacity was not sufficient and no memory can be
 *                    allocated
 *
 ***********************************************************************************/
static vector_t *vector_insert_n_at ( vector_t *in, int n, void *elements[], int at )
{
    vector_t *out;

    if ( at <= in->size ) {
        int i;

        out = vector_ensure_capacity ( in, n );
        for ( i=in->size-1; i>=at; i-- ) {
            out->content[i+n] = out->content[i];
        }
        for ( i=0; i<n; i++ ) {
            out->content[i+at] = elements[i];
        }
        out->size += n;
        out->capacity -= n;
    }
    else {
        fprintf( stderr, "vector_rem_n_at: cannot add %d elements from position %d in a vector of %d elements\n",
                    n, at, in->size );
        out = in;
    }
    return out;
}

/***********************************************************************************
 * Function:          vector_ensure_capacity
 *
 * Purpose:           ensures capacity for `n' more elements
 *
 * Description:       If the current capacity does not allow for `n' more elements
 *                    the vector is reallocated with the minimum amount of more
 *                    memory to allow for `n' more elements.
 *
 * Parameters:        vector_t *in;        vector of which the elements are removed
 *                    int n;                number of elements to remove
 *                    int at;                position of 1st element to remove
 *
 * Example:           v = vector_ensure_capacity( v, 5 );
 *
 * Return Value:      0   if `at' is within bounds [0,`size')
 *                    2   if `at' is out of bounds [0,`size')
 *
 ***********************************************************************************/
static vector_t *vector_ensure_capacity ( vector_t *in, int n )
{
    vector_t *out;

    if ( in->capacity < n ) {
        n = ( n + in->increment - 1 ) / in->increment;
        out = vector_new ( in->size + ( n * in->increment ), in->increment );
        if ( out == NULL ) {
            return NULL;
        }
        out->size = in->size;
        out->capacity = n * in->increment;
        memcpy ( out->content, in->content, in->size * sizeof ( void * ) );
        vector_free ( in );
    }
    else {
        out = in;
    }
    return out;
}

/***********************************************************************************
 * Function:          vector_get
 *
 * Purpose:           returns element at position `index'
 *
 * Description:       returns element at position `index'
 *
 * Parameters:        vector_t *in;        vector of which the elements is returned
 *                    int index;            position of the elements to return
 *
 * Example:           printf ( "Element is: %s\n", (char *)vector_get ( v, 0 ) );
 *
 * Return Value:      pointer to the element at position `index'
 *
 ***********************************************************************************/
static void *vector_get ( const vector_t *in, int index )
{
    return in->content[index];
}

/***********************************************************************************
 * Function:          vector_size
 *
 * Purpose:           returns the current number of stored elements in the vector
 *
 * Description:       returns the current number of stored elements in the vector
 *
 * Parameters:        vector_t *in;        vector of which the size is returned
 *
 * Example:           for ( i=0; i<vector_size ( v ); i++ ) ;
 *
 * Return Value:      current number of stored elements in the vector
 *
 ***********************************************************************************/
static int vector_size ( const vector_t *in )
{
    return in->size;
}

/***********************************************************************************
 * Function:          vector_free
 *
 * Purpose:           frees memory of a vector (does not free the elements!)
 *
 * Description:       frees all dynamically allocated memory in structure
 *                    vector_t for the vector `in'. This does not free the
 *                    memory for the elements for which this vector held
 *                    pointers!
 *
 * Parameters:        vector_t *in;        vector to be freed
 *
 * Example:           v = vector_free ( v );
 *
 * Return Value:      NULL
 *
 ***********************************************************************************/
static vector_t *vector_free ( vector_t *in )
{
    if ( in != NULL )
    {
        MEM_free( in->content );
        MEM_free( in );
    }
    return NULL;
}
