echo "Shell DR3 VC NOPO report startt"
fromdate=`date +"%d-%h-%Y" --date="1 day ago"`
echo "$fromdate"
todate=`date +"%d-%h-%Y" --date="1 days ago"`
echo "$todate"
cd /user/uaprodtrl/Program_Shells/DML_Support/tm_Part_based_NOPO_DR3_VC
echo "To patch rel exe exe"
nohup ./tm_DR3VC_NOPO_Report -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -g=dba -fromdate=$fromdate -todate=$todate > NOPOReport1.log &
echo "DR3 VC NOPO Shell Execution completedd"
