/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME		:	Party_part_Report.c
**
** Author				:	AWW917697 
**
** Date					:	15/01/2020
**	
**************************************************************************************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <epm/cr_effectivity.h>
#include <epm/epm.h>
#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <property/prop.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tc/iman.h>
#include <tc/preferences.h>
#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/iman_msg.h>
#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <unidefs.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"


void write2xml(FILE * , char*);
int ctr=0;

 int a=0;

FILE *Report; 

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *replaceWord(const char *s, const char *oldW, 
                                 const char *newW) 
{ 
    char *result; 
    int i, cnt = 0; 
    int newWlen = strlen(newW); 
    int oldWlen = strlen(oldW); 
  
    // Counting the number of times old word 
    // occur in the string 
    for (i = 0; s[i] != '\0'; i++) 
    { 
        if (strstr(&s[i], oldW) == &s[i]) 
        { 
            cnt++; 
  
            // Jumping to index after the old word. 
            i += oldWlen - 1; 
        } 
    } 
  
    // Making new string of enough length 
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1); 
  
    i = 0; 
    while (*s) 
    { 
        // compare the substring with the result 
        if (strstr(s, oldW) == s) 
        { 
            strcpy(&result[i], newW); 
            i += newWlen; 
            s += oldWlen; 
        } 
        else
            result[i++] = *s++; 
    } 
  
    result[i] = '\0'; 
    return result; 
} 

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

void print_requirement()
{
     printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -Part_Number=<Item ID> (required)\n"
        " -Only_SpareKit_Assembly=<Yes or No>(case sensetive) (required)\n"
        );    
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{ 
		char    * Part_Dataset		= NULL;
		char    * Party_Part_Dataset		= NULL;
		char    * Vendor_Dataset		= NULL;
		char    * HELP		= NULL;
		char    * HELP1		= NULL;
		char    * HELP2		= NULL;
		char    * HELP3		= NULL;
		tag_t	queryTag1	= NULLTAG;
		tag_t	queryTag2	= NULLTAG;
		int n_entries1 =1;
		int n_entries2 =1;
		char ***qry_entries1 = (char ***) MEM_alloc(10 * sizeof(char *));
		char ***qry_values1 = (char ***) MEM_alloc(10 * sizeof(char *));
		char ***qry_entries2 = (char ***) MEM_alloc(10 * sizeof(char *));
		char ***qry_values2 = (char ***) MEM_alloc(10 * sizeof(char *));
		int resultCount1=0;
		int resultCount2=0;
		int vendorcount=0;
		int y=0;
		int refnum=0;
		tag_t *qry_output1= NULLTAG;
		tag_t *qry_output2= NULLTAG;
		tag_t DatasetTag= NULLTAG;
		tag_t DesrevusgpartypartTag= NULLTAG;
		tag_t Item= NULLTAG;
		tag_t ItemRev= NULLTAG;
		tag_t Vendortag= NULLTAG;
		tag_t VendorRevtag= NULLTAG;
		tag_t PartypartNoRevTag= NULLTAG;
		tag_t PartypartNoTag= NULLTAG;
		char * Datasetname = NULL;
		tag_t *namedRef_tag		   = NULLTAG;
		char *FileLoc;
		FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
		FILE *fptr;
		char* inputline=NULL;
		char* PartNumber1=NULL;
		char* VendorID=NULL;
		char* partyPartNumber1=NULL;
		char* PartypartNo=NULL;
		char* PartypartNoDesc=NULL;
		char* PartypartNoproj=NULL;
		char* PartypartNodsggrp=NULL;
		char* PartypartNovendorid=NULL;
		char* DesrevID=NULL;
		char* PartDesc=NULL;
		char* PartOwner=NULL;					
		char* punemakebuy=NULL;	
		int a=0;
		tag_t vendorparts_relation_type = NULLTAG;
		tag_t *Vendor_part_list = NULLTAG;
		int s= 0;
		char *vendorpartID = NULL ;
		char c[] = "&"; 
	    char d[] = "&#38;";
		char e[] = "'"; 
	    char f[] = "&#39;";
		char g[] = "\""; 
	    char h[] = "&#34;";
		char *result = NULL;
		char *result1 = NULL;
		char *result2 = NULL;
		char *result3 = NULL;
		char *result4 = NULL;
		char *result5 = NULL;
		char *result6 = NULL;
		char *result7 = NULL;
		char *result8 = NULL;


	ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ) ;
//	ITK_init_module("ercpsup","password","Engineering");
	ITK_init_module("infodba","infodba","dba");
	ITK_set_bypass(true);

	Party_Part_Dataset		=	 ITK_ask_cli_argument("-Party_part_number_wise=");
	Part_Dataset		=		 ITK_ask_cli_argument("-TML_part_number_wise=");
	Vendor_Dataset		=		 ITK_ask_cli_argument("-Vendor_ID_wise=");

//******************************** PARTY Part Number Wise *****************************
	if(tc_strlen(Party_Part_Dataset) > 0)
	{
		printf("\n Welcome in Report using ***** Party_part_number_wise ***** \n");

						Report=fopen("/tmp/PartyPartReport.xml","w");			

						write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
						write2xml(Report,"\n<Top>\n");					
						
					(QRY_find("Dataset Name", &queryTag1));				

					char *qry_entries1[1] = {"Dataset Name"};
					char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));

					qry_values1[0] = Party_Part_Dataset ;

					(QRY_execute(queryTag1, n_entries1, qry_entries1, qry_values1, &resultCount1, &qry_output1));
					printf("\n Count of Dataset Part Number ------------------>  %d \n",resultCount1);
					if(resultCount1 > 0)
		{
						DatasetTag = qry_output1[0];
					AOM_UIF_ask_value(DatasetTag,"object_name",&Datasetname); 
					printf("\n Datasetname ------------------>  %s \n",Datasetname);

						tc_strcpy(FileLoc,"/tmp/");
						tc_strcat(FileLoc,Datasetname);
						tc_strcat(FileLoc,".txt");

					AE_export_named_ref(DatasetTag, "Text", FileLoc);

					fptr=fopen(FileLoc,"r");
					if(fptr!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fptr)!=NULL)
		{
			a++;
		fputs(inputline,stdout);
		partyPartNumber1=tc_strtok(inputline,",");
		if(tc_strlen(partyPartNumber1) > 0)
		{
		printf("\n Party_Part_Number in File ------------------>  %s \n",partyPartNumber1);
		write2xml(Report,"<logo>\n");

					(QRY_find("DesRevUsgPartyPart", &queryTag2));				

//					char *qry_entries2[1] = {"t5_RefPartNumber"};	//production
					char *qry_entries2[1] = {"Party Part Number"};
					char **qry_values2 = (char **) MEM_alloc(50 * sizeof(char *));

					qry_values2[0] = partyPartNumber1 ;

					ITEM_find_item(partyPartNumber1, &PartypartNoTag);	

					ITEM_ask_latest_rev (PartypartNoTag,&PartypartNoRevTag);

					(QRY_execute(queryTag2, n_entries2, qry_entries2, qry_values2, &resultCount2, &qry_output2));
					if(resultCount2 > 0)
		{
					DesrevusgpartypartTag = qry_output2[0];

					printf("\nWriting to XML\n");	
					fprintf(Report,"<field key =\"SR.NO\">");
					fprintf(Report,"%d",a);
					fprintf(Report,"</field>\n");

					fprintf(Report,"<field key =\"Party Part Number\">");
					fprintf(Report,"%s",partyPartNumber1);
					fprintf(Report,"</field>\n");

					AOM_UIF_ask_value(PartypartNoTag,"object_desc",&PartypartNoDesc);
						result = replaceWord(PartypartNoDesc, c, d);
						result1 = replaceWord(result, e, f);
						result2 = replaceWord(result1, g, h);
					fprintf(Report,"<field key =\"Party Part Description\">");
					fprintf(Report,"%s",result2);
					fprintf(Report,"</field>\n");

					AOM_UIF_ask_value(PartypartNoTag,"owning_project",&PartypartNoproj);
					fprintf(Report,"<field key =\"Project Code\">");
					fprintf(Report,"%s",PartypartNoproj);
					fprintf(Report,"</field>\n");

					AOM_UIF_ask_value(PartypartNoRevTag,"t5designgroup",&PartypartNodsggrp);
					fprintf(Report,"<field key =\"Design Group\">");
					fprintf(Report,"%s",PartypartNodsggrp);
					fprintf(Report,"</field>\n");

					AOM_UIF_ask_value(PartypartNoRevTag,"vendor_part_num",&PartypartNovendorid);
					fprintf(Report,"<field key =\"Vendor ID\">");
					fprintf(Report,"%s",PartypartNovendorid);
					fprintf(Report,"</field>\n");

					AOM_UIF_ask_value(DesrevusgpartypartTag,"item_id",&DesrevID);
					fprintf(Report,"<field key =\"TML Part No\">");
					fprintf(Report,"%s",DesrevID);
					fprintf(Report,"</field>\n");	

					AOM_UIF_ask_value(DesrevusgpartypartTag,"object_desc",&PartDesc);
						result3 = replaceWord(PartDesc, c, d);
						result4 = replaceWord(result3, e, f);
						result5 = replaceWord(result4, g, h);
					fprintf(Report,"<field key =\"TML Part Description\">");
					fprintf(Report,"%s",result5);
					fprintf(Report,"</field>\n");	

					AOM_UIF_ask_value(DesrevusgpartypartTag,"owning_user",&PartOwner);
					fprintf(Report,"<field key =\"TML Part Owner\">");
					fprintf(Report,"%s",PartOwner);
					fprintf(Report,"</field>\n");	

					AOM_UIF_ask_value(DesrevusgpartypartTag,"t5_PunMakeBuyIndicator",&punemakebuy);
						result6 = replaceWord(punemakebuy, c, d);
						result7 = replaceWord(result6, e, f);
						result8 = replaceWord(result7, g, h);
					fprintf(Report,"<field key =\"Pune Make/Buy\">");
					fprintf(Report,"%s",result8);
					fprintf(Report,"</field>\n");
		}
		write2xml(Report,"</logo>\n");
		}		
		}
		}
		}
		write2xml(Report,"</Top>\n");
		return 0;
	}
//******************************** PART Number Wise *****************************	
	if(tc_strlen(Part_Dataset) > 0)
	{
		printf("\n Welcome in Report using ***** TML_part_number_wise ***** \n");

						Report=fopen("/tmp/PartyPartReport.xml","w");			

						write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
						write2xml(Report,"\n<Top>\n");					
						
					(QRY_find("Dataset Name", &queryTag1));				

					char *qry_entries1[1] = {"Dataset Name"};
					char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));

					qry_values1[0] = Part_Dataset ;

					(QRY_execute(queryTag1, n_entries1, qry_entries1, qry_values1, &resultCount1, &qry_output1));
					printf("\n Count of Part Number ------------------>  %d \n",resultCount1);
					if(resultCount1 > 0)
		{
						DatasetTag = qry_output1[0];
					AOM_UIF_ask_value(DatasetTag,"object_name",&Datasetname); 
					printf("\n Datasetname ------------------>  %s \n",Datasetname);

					AE_ask_dataset_named_refs(DatasetTag,&refnum,&namedRef_tag);

						tc_strcpy(FileLoc,"/tmp/");
						tc_strcat(FileLoc,Datasetname);
						tc_strcat(FileLoc,".txt");

					AE_export_named_ref(DatasetTag, "Text", FileLoc);

					fptr=fopen(FileLoc,"r");
					if(fptr!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fptr)!=NULL)
		{
			a++;
		fputs(inputline,stdout);
		PartNumber1=tc_strtok(inputline,",");
		if(tc_strlen(PartNumber1) > 0)
		{
		printf("\n TML PartNumber in File ------------------>  %s \n",PartNumber1);
		write2xml(Report,"<logo>\n");
		ITEM_find_item(PartNumber1, &Item);
		ITEM_ask_latest_rev (Item,&ItemRev);		
		printf("\nWriting to XML\n");
		

		fprintf(Report,"<field key =\"SR.NO\">");
		fprintf(Report,"%d",a);
		fprintf(Report,"</field>\n");


		AOM_UIF_ask_value(ItemRev,"t5_RefPartNumber",&PartypartNo);
		fprintf(Report,"<field key =\"Party Part Number\">");
		fprintf(Report,"%s",PartypartNo);
		fprintf(Report,"</field>\n");

		ITEM_find_item(PartypartNo, &PartypartNoTag);	
		if(PartypartNoTag)
		{
		ITEM_ask_latest_rev (PartypartNoTag,&PartypartNoRevTag);	
		AOM_UIF_ask_value(PartypartNoTag,"object_desc",&PartypartNoDesc);
						result = replaceWord(PartypartNoDesc, c, d);
						result1 = replaceWord(result, e, f);
						result2 = replaceWord(result1, g, h);
		fprintf(Report,"<field key =\"Party Part Description\">");
		fprintf(Report,"%s",result2);
		fprintf(Report,"</field>\n");

		AOM_UIF_ask_value(PartypartNoTag,"owning_project",&PartypartNoproj);
		fprintf(Report,"<field key =\"Project Code\">");
		fprintf(Report,"%s",PartypartNoproj);
		fprintf(Report,"</field>\n");

		AOM_UIF_ask_value(PartypartNoRevTag,"t5designgroup",&PartypartNodsggrp);
		fprintf(Report,"<field key =\"Design Group\">");
		fprintf(Report,"%s",PartypartNodsggrp);
		fprintf(Report,"</field>\n");

		AOM_UIF_ask_value(PartypartNoTag,"vendor_id",&PartypartNovendorid);
		fprintf(Report,"<field key =\"Vendor ID\">");
		fprintf(Report,"%s",PartypartNovendorid);
		fprintf(Report,"</field>\n");	
		}

		fprintf(Report,"<field key =\"TML Part No\">");
		fprintf(Report,"%s",PartNumber1);
		fprintf(Report,"</field>\n");	

		AOM_UIF_ask_value(Item,"object_desc",&PartDesc);
						result3 = replaceWord(PartDesc, c, d);
						result4 = replaceWord(result3, e, f);
						result5 = replaceWord(result4, g, h);
		fprintf(Report,"<field key =\"TML Part Description\">");
		fprintf(Report,"%s",result5);
		fprintf(Report,"</field>\n");	

		AOM_UIF_ask_value(Item,"owning_user",&PartOwner);
		fprintf(Report,"<field key =\"TML Part Owner\">");
		fprintf(Report,"%s",PartOwner);
		fprintf(Report,"</field>\n");	

		AOM_UIF_ask_value(ItemRev,"t5_PunMakeBuyIndicator",&punemakebuy);
						result6 = replaceWord(punemakebuy, c, d);
						result7 = replaceWord(result6, e, f);
						result8 = replaceWord(result7, g, h);
		fprintf(Report,"<field key =\"Pune Make/Buy\">");
		fprintf(Report,"%s",result8);
		fprintf(Report,"</field>\n");


		write2xml(Report,"</logo>\n");
		}		
		}
		}
		}
		write2xml(Report,"</Top>\n");
		return 0;
	}
//******************************** VENDOR ID Wise ******************************
	if(tc_strlen(Vendor_Dataset) > 0)
	{
		printf("\n Welcome in Report using ***** Vendor_ID_wise ***** \n");

		Report=fopen("/tmp/PartyPartReport.xml","w");			

						write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
						write2xml(Report,"\n<Top>\n");
												
					(QRY_find("Dataset Name", &queryTag1));				

					char *qry_entries1[1] = {"Dataset Name"};
					char **qry_values1 = (char **) MEM_alloc(50 * sizeof(char *));

					qry_values1[0] = Vendor_Dataset ;

					(QRY_execute(queryTag1, n_entries1, qry_entries1, qry_values1, &resultCount1, &qry_output1));
					printf("\n Count of Part Number ------------------>  %d \n",resultCount1);
					if(resultCount1 > 0)
		{
						DatasetTag = qry_output1[0];
					AOM_UIF_ask_value(DatasetTag,"object_name",&Datasetname); 
					printf("\n Datasetname ------------------>  %s \n",Datasetname);

					AE_ask_dataset_named_refs(DatasetTag,&refnum,&namedRef_tag);

						tc_strcpy(FileLoc,"/tmp/");
						tc_strcat(FileLoc,Datasetname);
						tc_strcat(FileLoc,".txt");

					AE_export_named_ref(DatasetTag, "Text", FileLoc);

					fptr=fopen(FileLoc,"r");
					if(fptr!=NULL)
		{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fptr)!=NULL)
		{
			a++;
		fputs(inputline,stdout);
		VendorID=tc_strtok(inputline,",");
		if(tc_strlen(VendorID) > 0)
		{
		printf("\n VendorID in File ------------------>  %s \n",VendorID);

		ITEM_find_item(VendorID, &Vendortag);
		ITEM_ask_latest_rev (Vendortag,&VendorRevtag);
				write2xml(Report,"<logo>\n");
				fprintf(Report,"<field key =\"SR.NO\">");
				fprintf(Report,"%d",a);
				fprintf(Report,"</field>\n");
		
				fprintf(Report,"<field key =\"Vendor ID\">");
				fprintf(Report,"%s",VendorID);
				fprintf(Report,"</field>\n");
				write2xml(Report,"</logo>\n");

		AOM_ask_value_tags(Vendortag,"vendorparts",&vendorcount,&Vendor_part_list);
		printf("\n vendorcount ------------------>  %d \n",vendorcount);

		for(s=0;s<vendorcount;s++)
		{
				write2xml(Report,"<logo>\n");		
				fprintf(Report,"<field key =\"SR.NO\">");
				fprintf(Report,"</field>\n");
				fprintf(Report,"<field key =\"Vendor ID\">");
				fprintf(Report,"</field>\n");
				AOM_UIF_ask_value(Vendor_part_list[s],"item_id",&vendorpartID);
				printf("Party Part Number -------> %s \n",vendorpartID);
				fprintf(Report,"<field key =\"Party Part Number\">");
				fprintf(Report,"%s",vendorpartID);
				fprintf(Report,"</field>\n");
				
				AOM_UIF_ask_value(Vendor_part_list[s],"object_desc",&PartypartNoDesc);
						result = replaceWord(PartypartNoDesc, c, d);
						result1 = replaceWord(result, e, f);
						result2 = replaceWord(result1, g, h);
				fprintf(Report,"<field key =\"Party Part Description\">");
				fprintf(Report,"%s",result2);
				fprintf(Report,"</field>\n");	
				
				AOM_UIF_ask_value(Vendor_part_list[s],"owning_project",&PartypartNoproj);
				fprintf(Report,"<field key =\"Project Code\">");
				fprintf(Report,"%s",PartypartNoproj);
				fprintf(Report,"</field>\n");

				AOM_UIF_ask_value(Vendor_part_list[s],"t5designgroup",&PartypartNodsggrp);
				fprintf(Report,"<field key =\"Design Group\">");
				fprintf(Report,"%s",PartypartNodsggrp);
				fprintf(Report,"</field>\n");
//TML Part
				(QRY_find("DesRevUsgPartyPart", &queryTag2));				

//					char *qry_entries2[1] = {"t5_RefPartNumber"};	//production
					char *qry_entries2[1] = {"Party Part Number"};	//uadev & cmitest

					char **qry_values2 = (char **) MEM_alloc(50 * sizeof(char *));

					qry_values2[0] = vendorpartID ;

					(QRY_execute(queryTag2, n_entries2, qry_entries2, qry_values2, &resultCount2, &qry_output2));
					if(resultCount2 > 0)
		{
					DesrevusgpartypartTag = qry_output2[0];

					AOM_UIF_ask_value(DesrevusgpartypartTag,"item_id",&DesrevID);
					fprintf(Report,"<field key =\"TML Part No\">");
					fprintf(Report,"%s",DesrevID);
					fprintf(Report,"</field>\n");	

					AOM_UIF_ask_value(DesrevusgpartypartTag,"object_desc",&PartDesc);
						result3 = replaceWord(PartDesc, c, d);
						result4 = replaceWord(result3, e, f);
						result5 = replaceWord(result4, g, h);
					fprintf(Report,"<field key =\"TML Part Description\">");
					fprintf(Report,"%s",result5);
					fprintf(Report,"</field>\n");	

					AOM_UIF_ask_value(DesrevusgpartypartTag,"owning_user",&PartOwner);
					fprintf(Report,"<field key =\"TML Part Owner\">");
					fprintf(Report,"%s",PartOwner);
					fprintf(Report,"</field>\n");	

					AOM_UIF_ask_value(DesrevusgpartypartTag,"t5_PunMakeBuyIndicator",&punemakebuy);
						result6 = replaceWord(punemakebuy, c, d);
						result7 = replaceWord(result6, e, f);
						result8 = replaceWord(result7, g, h);
					fprintf(Report,"<field key =\"Pune Make/Buy\">");
					fprintf(Report,"%s",result8);
					fprintf(Report,"</field>\n");

		}

				write2xml(Report,"</logo>\n");
		}
		}
		}
		}
		}
		write2xml(Report,"</Top>\n");
		return 0;
	}

//*********************************************

}
