/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: change_group.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and on the basis of option selected it performs respective
**				action (Lock and Unlock) on objects.
** 
**
**	Date							Author								Modification
**	31-March-2018					Kalpesh Gondhali					Code creation
**	11-April-2018					Kalpesh Gondhali					Locking And Unlocking of objects(options added)
**	
** command to run:
** change_group -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


int			ifail 				= ITK_ok;
FILE		*output 			= NULL;

int read_value_from_file1(char*);
int read_value_from_file2(char*);
int get_object1(char*);
int get_object2(char*);
int get_owning_user_and_group1(tag_t);
int get_owning_user_and_group2(char*, char*, tag_t);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter Usr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<filename> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper Usr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int 			choice;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");

	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%m_%Y",&when);
	sprintf(outputFile,"%s_output.csv",Data);
			
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
		
	printf("\n*******MENU*******\n");
	printf("1:-Unlock\n");
	printf("2:-Lock\n");
	printf("3:-Exit\n");
	printf("******************\n");
	scanf("%d",&choice);
	
	switch(choice)
	{
		case 1:
			printf("\nGoing to Unlock the Parts...!!\n");
			ifail = read_value_from_file1(Filename);
			break;
		case 2:
			printf("\nGoing to Lock the Parts...!!\n");
			
			output = fopen(outputFile, "a+");
			if (output == NULL)
			{
				printf("ERROR: Cannot open File\n");
				return -1;
			}
			else
			{
				printf("File opened successfully.\n");
			}
			
			ifail = read_value_from_file2(Filename);
			break;

		case 3:
			printf("\nExit...As your wish...!!\n");
			return 0;		
	}
	
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file1
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file1(char* Filename)
{	
	char 		*itemid					= NULL;
	char 		temp[200];
	
	FILE		* fp 					= NULL;
	
	fp = fopen(Filename, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));
		
			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, " ");
				printf("\nInput Item_id:%s\n",itemid);
				
				ifail = get_object1(itemid);
			}
			printf("***************************************\n");
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file2
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file2(char* Filename)
{	
	char 		*itemid					= NULL;
	char 		temp[200];
	
	FILE		* fp 					= NULL;
	
	fp = fopen(Filename, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));
		
			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, " ");
				printf("\nInput Item_id:%s\n",itemid);
				
				ifail = get_object2(itemid);
			}
			printf("***************************************\n");
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       get_object1
    Description:    This function takes the item_id as input and queries into TC and gets
					item, BV, item_rev, it's BVR, and secondary object.
********************************************************************************************/
int get_object1(char* item_id)
{
	int				i 							= 0;
	int				j		 					= 0;
	int				k		 					= 0;
	int				bv_count 					= 0;
	int				bvr_count 					= 0;
	int				sec_count 					= 0;
	
	tag_t			item_tag 					= NULLTAG;
	tag_t			latest_rev_tag				= NULLTAG;
	tag_t			relation					= NULLTAG;
	tag_t			*bv_list					= NULL;
	tag_t			*bvr_list					= NULL;
	tag_t			*sec_objects				= NULL;
	
	char 			*latest_rev_id				= NULL;
	
	ifail = ITEM_find_item (item_id, &item_tag);
	if(item_tag == NULLTAG)
	{
		printf("Object not found in TC...!!\n");
		printf("***************************\n");
		return 0;
	}
	
	printf("\nUpdating item");
	ifail = get_owning_user_and_group1(item_tag);
	CHECK_FAIL;
	
	printf("\nUpdating bom_view");
	ifail = ITEM_list_bom_views (item_tag, &bv_count, &bv_list);
	printf("\nTotal %d Bom_View found...!!\n", bv_count);
	
	for(i=0;i<bv_count;i++)
	{
		ifail = get_owning_user_and_group1(bv_list[i]);		
		CHECK_FAIL;
	}

	ifail = ITEM_ask_latest_rev (item_tag, &latest_rev_tag);
	printf("\nUpdating Revision");
	ifail = AOM_UIF_ask_value (latest_rev_tag, "item_revision_id", &latest_rev_id);
	printf("\nLatest Rev. found is:%s\n",latest_rev_id);
	
	ifail = get_owning_user_and_group1(latest_rev_tag);
	CHECK_FAIL;

	printf("\nUpdating bom_view Revision");
	ifail = ITEM_rev_list_bom_view_revs (latest_rev_tag, &bvr_count, &bvr_list);
	printf("\nTotal %d Bom_View Revision found...!!\n", bvr_count);
	
	for(j=0;j<bvr_count;j++)
	{
		ifail = get_owning_user_and_group1(bvr_list[j]);	
		CHECK_FAIL;
	}
	
	ifail = GRM_find_relation_type ("IMAN_specification", &relation);
	ifail = GRM_list_secondary_objects_only (latest_rev_tag, relation, &sec_count, &sec_objects);
	CHECK_FAIL;
	printf("\nTotal %d sec_object found...!!\n", sec_count);
	
	printf("\nUpdating datasets");
	for(k=0;k<sec_count;k++)
	{
		ifail = get_owning_user_and_group1(sec_objects[k]);
		CHECK_FAIL;
	}
	
	MEM_free(sec_objects);
	MEM_free(bv_list);
	MEM_free(latest_rev_id);
	MEM_free(bvr_list);
	
	
	return ifail;
}


/********************************************************************************************
    Function:       get_object2
    Description:    This function takes the item_id as input and queries into TC and gets
					item, BV, item_rev, it's BVR, and secondary object.
********************************************************************************************/
int get_object2(char* item_id)
{
	int				i 							= 0;
	int				j		 					= 0;
	int				k		 					= 0;
	int				bv_count 					= 0;
	int				bvr_count 					= 0;
	int				sec_count 					= 0;
	
	tag_t			item_tag 					= NULLTAG;
	tag_t			latest_rev_tag				= NULLTAG;
	tag_t			relation					= NULLTAG;
	tag_t			*bv_list					= NULL;
	tag_t			*bvr_list					= NULL;
	tag_t			*sec_objects				= NULL;
	
	char 			*latest_rev_id				= NULL;
	
	ifail = ITEM_find_item (item_id, &item_tag);
	if(item_tag == NULLTAG)
	{
		printf("Object not found in TC...!!\n");
		printf("***************************\n");
		return 0;
	}
	
	/*printf("\nUpdating item");
	ifail = get_owning_user_and_group2(item_tag);
	CHECK_FAIL;
	
	printf("\nUpdating bom_view");
	ifail = ITEM_list_bom_views (item_tag, &bv_count, &bv_list);
	printf("\nTotal %d Bom_View found...!!\n", bv_count);
	
	for(i=0;i<bv_count;i++)
	{
		ifail = get_owning_user_and_group2(bv_list[i]);		
		CHECK_FAIL;
	}*/

	ifail = ITEM_ask_latest_rev (item_tag, &latest_rev_tag);
	printf("\nUpdating Latest Revision");
	ifail = AOM_UIF_ask_value (latest_rev_tag, "item_revision_id", &latest_rev_id);
	printf("\nLatest Rev. found is:%s\n",latest_rev_id);
	
	ifail = get_owning_user_and_group2(item_id, latest_rev_id, latest_rev_tag);
	CHECK_FAIL;

	/*printf("\nUpdating bom_view Revision");
	ifail = ITEM_rev_list_bom_view_revs (latest_rev_tag, &bvr_count, &bvr_list);
	printf("\nTotal %d Bom_View Revision found...!!\n", bvr_count);
	
	for(j=0;j<bvr_count;j++)
	{
		ifail = get_owning_user_and_group2(bvr_list[j]);	
		CHECK_FAIL;
	}
	
	ifail = GRM_find_relation_type ("IMAN_specification", &relation);
	ifail = GRM_list_secondary_objects_only (latest_rev_tag, relation, &sec_count, &sec_objects);
	CHECK_FAIL;
	printf("\nTotal %d sec_object found...!!\n", sec_count);
	
	printf("\nUpdating datasets");
	for(k=0;k<sec_count;k++)
	{
		ifail = get_owning_user_and_group2(sec_objects[k]);
		CHECK_FAIL;
	}*/
	
	//MEM_free(sec_objects);
	//MEM_free(bv_list);
	MEM_free(latest_rev_id);
	//MEM_free(bvr_list);
	
	
	return ifail;
}


/********************************************************************************************
    Function:       get_owning_user_and_group1
    Description:    This function takes the object_tag as input and get owning user and
					owning group of perticular object and change it's ownership.
					
********************************************************************************************/
int get_owning_user_and_group1(tag_t object_tag)
{	
	tag_t			new_group_tag				= NULLTAG;
	tag_t 			owning_user_tag				= NULLTAG;
	tag_t 			owning_group_tag			= NULLTAG;
	
	char			*obj_owning_user			= NULL;
	char			*obj_owning_group			= NULL;
	
	ifail = AOM_ask_owner (object_tag, &owning_user_tag);
	ifail = AOM_ask_group (object_tag, &owning_group_tag);
	
	ifail = AOM_UIF_ask_value (object_tag, "owning_user", &obj_owning_user);
	printf("\nObject owning user:%s",obj_owning_user);
	
	ifail = AOM_UIF_ask_value (object_tag, "owning_group", &obj_owning_group);
	printf("\nObject owning group:%s\n",obj_owning_group);
	
	ifail = SA_find_group("ERC_Designers_Group",&new_group_tag);
	
	if(tc_strcmp(obj_owning_user, "loader (loader)") == 0 && tc_strcmp(obj_owning_group, "dba") == 0)
	{
		ifail = AOM_set_ownership(object_tag, owning_user_tag, new_group_tag);
		CHECK_FAIL;
		printf("\nGroup updated\n");
	}
	else
	{
		printf("\nRequired owning user or group not found for object...!!\n");
	}
	MEM_free(obj_owning_user);
	MEM_free(obj_owning_group);
	
	return ifail;
}


/********************************************************************************************
    Function:       get_owning_user_and_group2
    Description:    This function takes the object_tag as input and get owning user and
					owning group of perticular object and change it's ownership.
					
********************************************************************************************/
int get_owning_user_and_group2(char* item_id, char* latest_rev_id, tag_t object_tag)
{	
	tag_t			new_group_tag				= NULLTAG;
	tag_t 			owning_user_tag				= NULLTAG;
	tag_t 			owning_group_tag			= NULLTAG;
	
	char			*obj_owning_user			= NULL;
	char			*obj_owning_group			= NULL;
	
	ifail = AOM_ask_owner (object_tag, &owning_user_tag);
	ifail = AOM_ask_group (object_tag, &owning_group_tag);
	
	ifail = AOM_UIF_ask_value (object_tag, "owning_user", &obj_owning_user);
	printf("\nObject owning user:%s",obj_owning_user);
	
	ifail = AOM_UIF_ask_value (object_tag, "owning_group", &obj_owning_group);
	printf("\nObject owning group:%s\n",obj_owning_group);
	
	ifail = SA_find_group("dba",&new_group_tag);
	
	if(tc_strcmp(obj_owning_user, "loader (loader)") == 0 && tc_strcmp(obj_owning_group, "ERC_Designers_Group") == 0)
	{
		ifail = AOM_set_ownership(object_tag, owning_user_tag, new_group_tag);
		CHECK_FAIL;
		printf("\nGroup updated\n");
	}
	else
	{
		printf("\nDifferent owning user[%s] or group[%s] found for Latest Revision\n", obj_owning_user, obj_owning_group);
		fprintf(output, "%s,%s,%s\n", item_id, latest_rev_id, obj_owning_user);
	}
	
	MEM_free(obj_owning_user);
	MEM_free(obj_owning_group);
	
	return ifail;
}