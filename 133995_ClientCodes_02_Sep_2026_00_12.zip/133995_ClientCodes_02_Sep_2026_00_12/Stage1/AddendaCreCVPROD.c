#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define STRSIZE 200
#define NUMWORDS 11

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			//TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


FILE		*output 			= NULL;

char		*sep				= "^";
int			ifail 				= ITK_ok;


int read_value_from_file(char*);
int check_rel_status(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* file						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	file 			= ITK_ask_cli_argument("-file=");
		
	
	//if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(file)) == 0)
	//{
		//print_requirement();
		//return -1;
	//}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		CHECK_FAIL;
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}

	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	
	//ifail = read_value_from_file(file);
	ifail = Addenda_Cre(file);
	CHECK_FAIL;
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


/********************************************************************************************
    Function:       Addenda_Cre
    Description:    
********************************************************************************************/
int Addenda_Cre(char* Filename)
{
	int		piStringCount			=0;
	int		nextnum			=0;
	int		num			=0;
	int		count			=0;
	int		FlagA			=0;
	char **DesignGroupList;
    int i, j = 0;
	tag_t item_type_tag				= NULLTAG;
	tag_t item_create_input_tag		= NULLTAG;
	tag_t cfg_item_create_input_tag = NULLTAG;
	tag_t object					= NULLTAG;
	tag_t cfg_object				= NULLTAG;
	tag_t cfg_item_type_tag			= NULLTAG;
	tag_t relation_type				= NULLTAG;
	tag_t new_relation				= NULLTAG;
	tag_t cc_item_tag				= NULLTAG;
	tag_t cc_item_Rev_tag			= NULLTAG;
	tag_t	item_tag				= NULLTAG;
	tag_t	item_tagg				= NULLTAG;
	tag_t	item_taggg			= NULLTAG;
	char* DesgList					= NULL;
	char* sprojj					= NULL;
	char* sproj					= NULL;
	char* error_str					= NULL;
	char* s = "^";

	/*char *object_name = (char *) MEM_alloc( 100 * sizeof(char) );
	char *obj_item_idd = (char *) MEM_alloc( 100 * sizeof(char) );
	char *obj_item_id = (char *) MEM_alloc( 100 * sizeof(char) );
	char *Seq = (char *) MEM_alloc( 100 * sizeof(char) );
	char *plnt = (char *) MEM_alloc( 100 * sizeof(char) );
	char *year = (char *) MEM_alloc( 100 * sizeof(char) );
	char *TCEAddenda = (char *) MEM_alloc( 100 * sizeof(char) );
	char *DesgGroup = (char *) MEM_alloc( 100 * sizeof(char) );
	char *projectcode = (char *) MEM_alloc( 100 * sizeof(char) );
	char *Addenda_desc = (char *) MEM_alloc( 100 * sizeof(char) );
	char *addPlant = (char *) MEM_alloc( 100 * sizeof(char) );	
	char *temp	=  (char *) MEM_alloc( 200 * sizeof(char) );
	DesgList     =  (char *) MEM_alloc(1000 * sizeof(char));*/
	char *temp	=  (char *) MEM_alloc( 200 * sizeof(char) );
	

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				char *object_name = (char *) MEM_alloc( 100 * sizeof(char) );
				char *obj_item_idd = (char *) MEM_alloc( 100 * sizeof(char) );
				char *obj_item_id = (char *) MEM_alloc( 100 * sizeof(char) );
				char *Seq = (char *) MEM_alloc( 100 * sizeof(char) );
				char *plnt = (char *) MEM_alloc( 100 * sizeof(char) );
				char *year = (char *) MEM_alloc( 100 * sizeof(char) );
				char *TCEAddenda = (char *) MEM_alloc( 100 * sizeof(char) );
				char *DesgGroup = (char *) MEM_alloc( 100 * sizeof(char) );
				char *projectcode = (char *) MEM_alloc( 100 * sizeof(char) );
				char *Addenda_desc = (char *) MEM_alloc( 100 * sizeof(char) );
				char *addPlant = (char *) MEM_alloc( 100 * sizeof(char) );	
				
				DesgList     =  (char *) MEM_alloc(1000 * sizeof(char));
				char **	AStringList =NULL;
				//obj_item_id=NULL;
				//Addenda_desc=NULL;
				//object_name=NULL;
				//Seq=NULL;
				//year=NULL;
				//plnt=NULL;
				//obj_item_id=NULL;
				tc_strcpy (DesgList,"" );
				num=0;
				piStringCount=0;
				nextnum=0;
				//5175,21PM453,58,04,45,55,09,08,17,07,13,00,21,11,12,18,01,20,19,22,16,03,05,10,02,14,15,06,23
				tc_strcpy (DesgList,(temp+13));
				printf("\nInput DesgList:::%s",DesgList); fflush(stdout);
				projectcode = strtok(temp, ",");
				//tc_strcpy(object_name,obj_item_id);
				printf("\nInput projectcode:%s",projectcode); fflush(stdout);
				obj_item_id = strtok(NULL, ",");
				printf("\nInput obj_item_id:%s",obj_item_id);fflush(stdout);
				//DesgList = strtok(NULL, ",");
				
				//nlsStrCpy(xowner,(plnttoplntDup+6));
				year=subString(obj_item_id, 0, 2);
				plnt=subString(obj_item_id, 2, 2);
				
				printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
				if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
				{
					Seq=subString(obj_item_id, 5, 2);
					printf("\n  Seq: %s",Seq);fflush(stdout);
					tc_strcpy (addPlant,"" );
					tc_strcpy (addPlant,"CU" );
					tc_strcpy (obj_item_idd,"" );
					//tc_strcpy (obj_item_idd,year );
					tc_strcpy (obj_item_idd,"22" );
					tc_strcat (obj_item_idd,"CUE");
					tc_strcat (obj_item_idd,Seq);
				}
				if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
				{
					Seq=subString(obj_item_id, 4, 3);
					printf("\n  Seq:: %s",Seq);fflush(stdout);
					tc_strcpy (addPlant,"" );
					tc_strcpy (addPlant,"LU" );
					tc_strcpy (obj_item_idd,"" );
					//tc_strcpy (obj_item_idd,year );
					tc_strcpy (obj_item_idd,"22" );
					tc_strcat (obj_item_idd,"LU");
					tc_strcat (obj_item_idd,Seq);
				}

				if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
				{
					Seq=subString(obj_item_id, 4, 3);
					printf("\n  Seq:::: %s",Seq);fflush(stdout);
					tc_strcpy (addPlant,"" );
					tc_strcpy (addPlant,"JU" );
					tc_strcpy (obj_item_idd,"" );
					//tc_strcpy (obj_item_idd,year );
					tc_strcpy (obj_item_idd,"22" );
					tc_strcat (obj_item_idd,"JU");
					tc_strcat (obj_item_idd,Seq);
				}
				tc_strcpy(Addenda_desc,obj_item_idd);
				tc_strcpy(object_name,obj_item_idd);
				

				printf("\n\t TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
				printf("\n\t New Addenda item_id :%s", obj_item_idd);fflush(stdout);
				printf("\n\t object_name :%s", object_name);fflush(stdout);
				printf("\n\t projectcode :%s", projectcode);fflush(stdout);
				printf("\n\t Addenda_desc :%s", Addenda_desc);fflush(stdout);
				printf("\n\t addPlant :%s", addPlant);fflush(stdout);

				if(EPM__parse_string(DesgList,",",&piStringCount,&AStringList)!=ITK_ok)PrintErrorStack();
				printf("\n\t piStringCount :%d", piStringCount);fflush(stdout);
				//for (nopo=0;nopo<piStringCount ;nopo++ )
				//{
				//	printf("\n SKIP:design group Part:%s \n",AStringList[nopo]);fflush(stdout);
				//	char *designgroupA[nopo] = AStringList[nopo];
				//}
				//char *designgroupA[] = {"00","01","02","03","04","05","06","07","08","08","10","11","12","13","14","15","16","17","18","19","20","21","22","23"};
				//char *designgroupA[] = {"00","01","02","03","04","05","06","07","08","08","10","11","12","13","14","15","16","17","18","19","20","21","22","23"};
				//char *designgroupB[] = {"24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58","59"};
				//char *designgroupC[] = {"60","61","62","63","64","65","66","67","68","69","70","71","72","73","77","75","76","77","78","79","80","81","82","83","84","85","86","87","88","89","90","91","92","93","94","95","96","97","98","99"};
				ifail = ITEM_find_item (obj_item_idd, &item_tag);
				if (item_tag == NULLTAG)
				{
					printf("\n\t DML addenda not previously present in the system [%s]",obj_item_idd);
					printf("\n\t *****Creating the T5_DmlAddenda******");fflush(stdout);
					ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
					ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
					ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
					ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
					ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
					ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
					ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
					ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
					ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
					printf("\n\t *****Saving the the T5_DmlAddenda******");fflush(stdout);
					ifail = (AOM_save (object));
					/*ifail = ITEM_find_item (obj_item_idd, &item_tag);
					if(item_tag == NULLTAG)
					{
						printf("\n Addenda ID :%s is not created",obj_item_idd);
						return 1;
					}
					else
					{
						printf("\n **************Addenda ID :%s is created*************",obj_item_idd);
					}*/
				}
				else
				{
					printf("\n\t AA:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
					if(AOM_ask_value_string(item_tag,"t5_ProjectCode",&sproj)!=ITK_ok)   PrintErrorStack();
					printf(" with Project: %s",sproj);	fflush(stdout);	
					if (tc_strcmp(projectcode,sproj)==0)
					{
						printf("\n\t Addenda already available for same project...");fflush(stdout);
					}
					else
					{
						printf("\n\t Addenda already available for different project, so creating with new addenda...");fflush(stdout);
					
						tc_strcpy (obj_item_idd,"" );
						year=subString(obj_item_id, 0, 2);
						plnt=subString(obj_item_id, 2, 2);
						
						printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
						if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
						{
							Seq=subString(obj_item_id, 5, 2);
							tc_strcpy (addPlant,"" );
							tc_strcpy (addPlant,"CU" );
							tc_strcpy (obj_item_idd,"" );
							//tc_strcpy (obj_item_idd,year );
							tc_strcpy (obj_item_idd,"22" );
							tc_strcat (obj_item_idd,"CUF");
							tc_strcat (obj_item_idd,Seq);
							//tc_strcpy(Addenda_desc,obj_item_idd);
							//tc_strcpy(object_name,obj_item_idd);
						}
						if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
						{
							Seq=subString(obj_item_id, 4, 3);
							tc_strcpy (addPlant,"" );
							tc_strcpy (addPlant,"LU" );
							tc_strcpy (obj_item_idd,"" );
							//tc_strcpy (obj_item_idd,year );
							tc_strcpy (obj_item_idd,"23" );
							tc_strcat (obj_item_idd,"LU");
							tc_strcat (obj_item_idd,Seq);
						}
						if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
						{
							Seq=subString(obj_item_id, 4, 3);
							tc_strcpy (addPlant,"" );
							tc_strcpy (addPlant,"JU" );
							tc_strcpy (obj_item_idd,"" );
							//tc_strcpy (obj_item_idd,year );
							tc_strcpy (obj_item_idd,"23" );
							tc_strcat (obj_item_idd,"JU");
							tc_strcat (obj_item_idd,Seq);
						}
						tc_strcpy(Addenda_desc,"");
						tc_strcpy(object_name,"");
						tc_strcpy(Addenda_desc,obj_item_idd);
						tc_strcpy(object_name,obj_item_idd);
					
						if(tc_strlen(obj_item_idd) != 0)
						{
							printf("\n\t AA:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
							printf("\n\t AA:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
							printf("\n\t AA:object_name :%s", object_name);fflush(stdout);
							printf("\n\t AA:projectcode :%s", projectcode);fflush(stdout);
							printf("\n\t AA:Addenda_desc :%s", Addenda_desc);fflush(stdout);
							printf("\n\t AA:addPlant :%s", addPlant);fflush(stdout);
							/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
							printf("\n\t Desg count :%d", num);fflush(stdout);
							nextnum=num+1;
							printf("\n\t nextnum :%d",nextnum);fflush(stdout);
							ITK_CALL(AOM_lock(item_tag));
							ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
							ITK_CALL(AOM_save(item_tag));
							ITK_CALL(AOM_unlock(item_tag));
							ITK_CALL(AOM_refresh(item_tag,0));*/
							ifail = ITEM_find_item (obj_item_idd, &item_tagg);
							if (item_tagg == NULLTAG)
							{
								printf("\n\t************* CODE END *********\n%s",temp);fflush(stdout);
								printf("\n\t AA:DML addenda not previously present in the system [%s]",obj_item_idd);
								printf("\n\t AA:*****Creating the T5_DmlAddenda******");fflush(stdout);
								ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
								ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
								ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
								ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
								ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
								ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
								ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
								ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
								ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
								printf("\n\t AA:*****Saving the the T5_DmlAddenda******");fflush(stdout);
								ifail = (AOM_save (object));
							}
							else
							{
								printf("\n\t BB:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
								if(AOM_ask_value_string(item_tagg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
								printf(" with Project: %s",sprojj);	fflush(stdout);	
								if (tc_strcmp(projectcode,sprojj)==0)
								{
									printf("\n\t BB:Addenda already available for same project...");fflush(stdout);
								}
								else
								{

									printf("\n\t BB:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
								
									tc_strcpy (obj_item_idd,"" );
									year=subString(obj_item_id, 0, 2);
									plnt=subString(obj_item_id, 2, 2);
									Seq=subString(obj_item_id, 5, 2);
									
									printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
									if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
									{
										tc_strcpy (addPlant,"" );
										tc_strcpy (addPlant,"CU" );
										tc_strcpy (obj_item_idd,"" );
										//tc_strcpy (obj_item_idd,year );
										tc_strcpy (obj_item_idd,"22" );
										tc_strcat (obj_item_idd,"CUG");
										tc_strcat (obj_item_idd,Seq);
										//tc_strcpy(Addenda_desc,obj_item_idd);
										//tc_strcpy(object_name,obj_item_idd);
									}
									/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
									{
										tc_strcpy (addPlant,"" );
										tc_strcpy (addPlant,"LU" );
										tc_strcpy (obj_item_idd,"" );
										//tc_strcpy (obj_item_idd,year );
										tc_strcpy (obj_item_idd,"23" );
										tc_strcat (obj_item_idd,"LUA");
										tc_strcat (obj_item_idd,Seq);
									}
									if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
									{
										tc_strcpy (addPlant,"" );
										tc_strcpy (addPlant,"JU" );
										tc_strcpy (obj_item_idd,"" );
										//tc_strcpy (obj_item_idd,year );
										tc_strcpy (obj_item_idd,"23" );
										tc_strcat (obj_item_idd,"JUA");
										tc_strcat (obj_item_idd,Seq);
									}*/
								
									if(tc_strlen(obj_item_idd) != 0)
									{
										tc_strcpy(Addenda_desc,"");
										tc_strcpy(object_name,"");
										tc_strcpy(Addenda_desc,obj_item_idd);
										tc_strcpy(object_name,obj_item_idd);
										printf("\n\t BB:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
										printf("\n\t BB:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
										printf("\n\t BB:object_name :%s", object_name);fflush(stdout);
										printf("\n\t BB:projectcode :%s", projectcode);fflush(stdout);
										printf("\n\t BB:Addenda_desc :%s", Addenda_desc);fflush(stdout);
										printf("\n\t BB:addPlant :%s", addPlant);fflush(stdout);
										/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
										printf("\n\t Desg count :%d", num);fflush(stdout);
										nextnum=num+1;
										printf("\n\t nextnum :%d",nextnum);fflush(stdout);
										ITK_CALL(AOM_lock(item_tag));
										ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
										ITK_CALL(AOM_save(item_tag));
										ITK_CALL(AOM_unlock(item_tag));
										ITK_CALL(AOM_refresh(item_tag,0));*/
										ifail = ITEM_find_item (obj_item_idd, &item_taggg);
										if (item_taggg == NULLTAG)
										{
											printf("\n\tBB:************* CODE END *********\n%s",temp);fflush(stdout);
											printf("\n\t BB:DML addenda not previously present in the system [%s]",obj_item_idd);
											printf("\n\t BB:*****Creating the T5_DmlAddenda******");fflush(stdout);
											ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
											ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
											ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
											ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
											ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
											ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
											ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
											ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
											ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
											printf("\n\t BB:*****Saving the the T5_DmlAddenda******");fflush(stdout);
											ifail = (AOM_save (object));
										}
										else
										{
											printf("\n\t CC:T5_DmlAddenda already available******");fflush(stdout);
											printf("\n\t CC:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
											if(AOM_ask_value_string(item_taggg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
											printf(" with Project: %s",sprojj);	fflush(stdout);	
											if (tc_strcmp(projectcode,sprojj)==0)
											{
												printf("\n\t CC:Addenda already available for same project...");fflush(stdout);
											}
											else
											{

												printf("\n\t CC:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
											
												tc_strcpy (obj_item_idd,"" );
												year=subString(obj_item_id, 0, 2);
												plnt=subString(obj_item_id, 2, 2);
												Seq=subString(obj_item_id, 5, 2);
												
												printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
												if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
												{
													tc_strcpy (addPlant,"" );
													tc_strcpy (addPlant,"CU" );
													tc_strcpy (obj_item_idd,"" );
													//tc_strcpy (obj_item_idd,year );
													tc_strcpy (obj_item_idd,"22" );
													tc_strcat (obj_item_idd,"CUH");
													tc_strcat (obj_item_idd,Seq);
													//tc_strcpy(Addenda_desc,obj_item_idd);
													//tc_strcpy(object_name,obj_item_idd);
												}
												/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
												{
													tc_strcpy (addPlant,"" );
													tc_strcpy (addPlant,"LU" );
													tc_strcpy (obj_item_idd,"" );
													//tc_strcpy (obj_item_idd,year );
													tc_strcpy (obj_item_idd,"23" );
													tc_strcat (obj_item_idd,"LUA");
													tc_strcat (obj_item_idd,Seq);
												}
												if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
												{
													tc_strcpy (addPlant,"" );
													tc_strcpy (addPlant,"JU" );
													tc_strcpy (obj_item_idd,"" );
													//tc_strcpy (obj_item_idd,year );
													tc_strcpy (obj_item_idd,"23" );
													tc_strcat (obj_item_idd,"JUA");
													tc_strcat (obj_item_idd,Seq);
												}*/
											
												if(tc_strlen(obj_item_idd) != 0)
												{
													tc_strcpy(Addenda_desc,"");
													tc_strcpy(object_name,"");
													tc_strcpy(Addenda_desc,obj_item_idd);
													tc_strcpy(object_name,obj_item_idd);
													printf("\n\t CC:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
													printf("\n\t CC:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
													printf("\n\t CC:object_name :%s", object_name);fflush(stdout);
													printf("\n\t CC:projectcode :%s", projectcode);fflush(stdout);
													printf("\n\t CC:Addenda_desc :%s", Addenda_desc);fflush(stdout);
													printf("\n\t CC:addPlant :%s", addPlant);fflush(stdout);
													/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
													printf("\n\t Desg count :%d", num);fflush(stdout);
													nextnum=num+1;
													printf("\n\t nextnum :%d",nextnum);fflush(stdout);
													ITK_CALL(AOM_lock(item_tag));
													ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
													ITK_CALL(AOM_save(item_tag));
													ITK_CALL(AOM_unlock(item_tag));
													ITK_CALL(AOM_refresh(item_tag,0));*/
													ifail = ITEM_find_item (obj_item_idd, &item_taggg);
													if (item_taggg == NULLTAG)
													{
														printf("\n\t CC:************* CODE END *********\n%s",temp);fflush(stdout);
														printf("\n\t CC:DML addenda not previously present in the system [%s]",obj_item_idd);
														printf("\n\t CC:*****Creating the T5_DmlAddenda******");fflush(stdout);
														ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
														ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
														ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
														ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
														ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
														ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
														ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
														ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
														ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
														printf("\n\t CC:*****Saving the the T5_DmlAddenda******");fflush(stdout);
														ifail = (AOM_save (object));
													}
													else
													{
														printf("\n\t CC:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
														if(AOM_ask_value_string(item_taggg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
														printf(" with Project: %s",sprojj);	fflush(stdout);	
														if (tc_strcmp(projectcode,sprojj)==0)
														{
															printf("\n\t CC:Addenda already available for same project...");fflush(stdout);
														}
														else
														{

															printf("\n\t CC:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
														
															tc_strcpy (obj_item_idd,"" );
															year=subString(obj_item_id, 0, 2);
															plnt=subString(obj_item_id, 2, 2);
															Seq=subString(obj_item_id, 5, 2);
															
															printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
															if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
															{
																tc_strcpy (addPlant,"" );
																tc_strcpy (addPlant,"CU" );
																tc_strcpy (obj_item_idd,"" );
																//tc_strcpy (obj_item_idd,year );
																tc_strcpy (obj_item_idd,"22" );
																tc_strcat (obj_item_idd,"CUI");
																tc_strcat (obj_item_idd,Seq);
																//tc_strcpy(Addenda_desc,obj_item_idd);
																//tc_strcpy(object_name,obj_item_idd);
															}
															/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
															{
																tc_strcpy (addPlant,"" );
																tc_strcpy (addPlant,"LU" );
																tc_strcpy (obj_item_idd,"" );
																//tc_strcpy (obj_item_idd,year );
																tc_strcpy (obj_item_idd,"23" );
																tc_strcat (obj_item_idd,"LUA");
																tc_strcat (obj_item_idd,Seq);
															}
															if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
															{
																tc_strcpy (addPlant,"" );
																tc_strcpy (addPlant,"JU" );
																tc_strcpy (obj_item_idd,"" );
																//tc_strcpy (obj_item_idd,year );
																tc_strcpy (obj_item_idd,"23" );
																tc_strcat (obj_item_idd,"JUA");
																tc_strcat (obj_item_idd,Seq);
															}*/
														
															if(tc_strlen(obj_item_idd) != 0)
															{
																tc_strcpy(Addenda_desc,"");
																tc_strcpy(object_name,"");
																tc_strcpy(Addenda_desc,obj_item_idd);
																tc_strcpy(object_name,obj_item_idd);
																printf("\n\t CC:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
																printf("\n\t CC:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
																printf("\n\t CC:object_name :%s", object_name);fflush(stdout);
																printf("\n\t CC:projectcode :%s", projectcode);fflush(stdout);
																printf("\n\t CC:Addenda_desc :%s", Addenda_desc);fflush(stdout);
																printf("\n\t CC:addPlant :%s", addPlant);fflush(stdout);
																/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
																printf("\n\t Desg count :%d", num);fflush(stdout);
																nextnum=num+1;
																printf("\n\t nextnum :%d",nextnum);fflush(stdout);
																ITK_CALL(AOM_lock(item_tag));
																ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
																ITK_CALL(AOM_save(item_tag));
																ITK_CALL(AOM_unlock(item_tag));
																ITK_CALL(AOM_refresh(item_tag,0));*/
																ifail = ITEM_find_item (obj_item_idd, &item_taggg);
																if (item_taggg == NULLTAG)
																{
																	printf("\n\t CC:************* CODE END *********\n%s",temp);fflush(stdout);
																	printf("\n\t CC:DML addenda not previously present in the system [%s]",obj_item_idd);
																	printf("\n\t CC:*****Creating the T5_DmlAddenda******");fflush(stdout);
																	ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
																	ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
																	ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
																	ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
																	ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
																	ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
																	ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
																	ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
																	ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
																	printf("\n\t CC:*****Saving the the T5_DmlAddenda******");fflush(stdout);
																	ifail = (AOM_save (object));
																}
																else
																{
																	printf("\n\t J:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
																	if(AOM_ask_value_string(item_taggg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
																	printf(" with Project: %s",sprojj);	fflush(stdout);	
																	if (tc_strcmp(projectcode,sprojj)==0)
																	{
																		printf("\n\t CC:Addenda already available for same project...");fflush(stdout);
																	}
																	else
																	{

																		printf("\n\t CC:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
																	
																		tc_strcpy (obj_item_idd,"" );
																		year=subString(obj_item_id, 0, 2);
																		plnt=subString(obj_item_id, 2, 2);
																		Seq=subString(obj_item_id, 5, 2);
																		
																		printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
																		if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
																		{
																			tc_strcpy (addPlant,"" );
																			tc_strcpy (addPlant,"CU" );
																			tc_strcpy (obj_item_idd,"" );
																			//tc_strcpy (obj_item_idd,year );
																			tc_strcpy (obj_item_idd,"22" );
																			tc_strcat (obj_item_idd,"CUJ");
																			tc_strcat (obj_item_idd,Seq);
																			//tc_strcpy(Addenda_desc,obj_item_idd);
																			//tc_strcpy(object_name,obj_item_idd);
																		}
																		/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
																		{
																			tc_strcpy (addPlant,"" );
																			tc_strcpy (addPlant,"LU" );
																			tc_strcpy (obj_item_idd,"" );
																			//tc_strcpy (obj_item_idd,year );
																			tc_strcpy (obj_item_idd,"23" );
																			tc_strcat (obj_item_idd,"LUA");
																			tc_strcat (obj_item_idd,Seq);
																		}
																		if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
																		{
																			tc_strcpy (addPlant,"" );
																			tc_strcpy (addPlant,"JU" );
																			tc_strcpy (obj_item_idd,"" );
																			//tc_strcpy (obj_item_idd,year );
																			tc_strcpy (obj_item_idd,"23" );
																			tc_strcat (obj_item_idd,"JUA");
																			tc_strcat (obj_item_idd,Seq);
																		}*/
																	
																		if(tc_strlen(obj_item_idd) != 0)
																		{
																			tc_strcpy(Addenda_desc,"");
																			tc_strcpy(object_name,"");
																			tc_strcpy(Addenda_desc,obj_item_idd);
																			tc_strcpy(object_name,obj_item_idd);
																			printf("\n\t CC:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
																			printf("\n\t CC:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
																			printf("\n\t CC:object_name :%s", object_name);fflush(stdout);
																			printf("\n\t CC:projectcode :%s", projectcode);fflush(stdout);
																			printf("\n\t CC:Addenda_desc :%s", Addenda_desc);fflush(stdout);
																			printf("\n\t CC:addPlant :%s", addPlant);fflush(stdout);
																			/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
																			printf("\n\t Desg count :%d", num);fflush(stdout);
																			nextnum=num+1;
																			printf("\n\t nextnum :%d",nextnum);fflush(stdout);
																			ITK_CALL(AOM_lock(item_tag));
																			ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
																			ITK_CALL(AOM_save(item_tag));
																			ITK_CALL(AOM_unlock(item_tag));
																			ITK_CALL(AOM_refresh(item_tag,0));*/
																			ifail = ITEM_find_item (obj_item_idd, &item_taggg);
																			if (item_taggg == NULLTAG)
																			{
																				printf("\n\t CC:************* CODE END *********\n%s",temp);fflush(stdout);
																				printf("\n\t CC:DML addenda not previously present in the system [%s]",obj_item_idd);
																				printf("\n\t CC:*****Creating the T5_DmlAddenda******");fflush(stdout);
																				ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
																				ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
																				ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
																				ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
																				ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
																				ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
																				ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
																				ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
																				ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
																				printf("\n\t CC:*****Saving the the T5_DmlAddenda******");fflush(stdout);
																				ifail = (AOM_save (object));
																			}
																			else
																			{
																				printf("\n\t K:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
																				if(AOM_ask_value_string(item_taggg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
																				printf(" with Project: %s",sprojj);	fflush(stdout);	
																				if (tc_strcmp(projectcode,sprojj)==0)
																				{
																					printf("\n\t CC:Addenda already available for same project...");fflush(stdout);
																				}
																				else
																				{

																					printf("\n\t CC:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
																				
																					tc_strcpy (obj_item_idd,"" );
																					year=subString(obj_item_id, 0, 2);
																					plnt=subString(obj_item_id, 2, 2);
																					Seq=subString(obj_item_id, 5, 2);
																					
																					printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
																					if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
																					{
																						tc_strcpy (addPlant,"" );
																						tc_strcpy (addPlant,"CU" );
																						tc_strcpy (obj_item_idd,"" );
																						//tc_strcpy (obj_item_idd,year );
																						tc_strcpy (obj_item_idd,"22" );
																						tc_strcat (obj_item_idd,"CUK");
																						tc_strcat (obj_item_idd,Seq);
																						//tc_strcpy(Addenda_desc,obj_item_idd);
																						//tc_strcpy(object_name,obj_item_idd);
																					}
																					/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
																					{
																						tc_strcpy (addPlant,"" );
																						tc_strcpy (addPlant,"LU" );
																						tc_strcpy (obj_item_idd,"" );
																						//tc_strcpy (obj_item_idd,year );
																						tc_strcpy (obj_item_idd,"23" );
																						tc_strcat (obj_item_idd,"LUA");
																						tc_strcat (obj_item_idd,Seq);
																					}
																					if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
																					{
																						tc_strcpy (addPlant,"" );
																						tc_strcpy (addPlant,"JU" );
																						tc_strcpy (obj_item_idd,"" );
																						//tc_strcpy (obj_item_idd,year );
																						tc_strcpy (obj_item_idd,"23" );
																						tc_strcat (obj_item_idd,"JUA");
																						tc_strcat (obj_item_idd,Seq);
																					}*/
																				
																					if(tc_strlen(obj_item_idd) != 0)
																					{
																						tc_strcpy(Addenda_desc,"");
																						tc_strcpy(object_name,"");
																						tc_strcpy(Addenda_desc,obj_item_idd);
																						tc_strcpy(object_name,obj_item_idd);
																						printf("\n\t CC:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
																						printf("\n\t CC:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
																						printf("\n\t CC:object_name :%s", object_name);fflush(stdout);
																						printf("\n\t CC:projectcode :%s", projectcode);fflush(stdout);
																						printf("\n\t CC:Addenda_desc :%s", Addenda_desc);fflush(stdout);
																						printf("\n\t CC:addPlant :%s", addPlant);fflush(stdout);
																						/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
																						printf("\n\t Desg count :%d", num);fflush(stdout);
																						nextnum=num+1;
																						printf("\n\t nextnum :%d",nextnum);fflush(stdout);
																						ITK_CALL(AOM_lock(item_tag));
																						ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
																						ITK_CALL(AOM_save(item_tag));
																						ITK_CALL(AOM_unlock(item_tag));
																						ITK_CALL(AOM_refresh(item_tag,0));*/
																						ifail = ITEM_find_item (obj_item_idd, &item_taggg);
																						if (item_taggg == NULLTAG)
																						{
																							printf("\n\t CC:************* CODE END *********\n%s",temp);fflush(stdout);
																							printf("\n\t CC:DML addenda not previously present in the system [%s]",obj_item_idd);
																							printf("\n\t CC:*****Creating the T5_DmlAddenda******");fflush(stdout);
																							ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
																							ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
																							ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
																							ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
																							ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
																							ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
																							ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
																							ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
																							ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
																							printf("\n\t CC:*****Saving the the T5_DmlAddenda******");fflush(stdout);
																							ifail = (AOM_save (object));
																						}
																						else
																						{
																							printf("\n\t L:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
																							if(AOM_ask_value_string(item_taggg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
																							printf(" with Project: %s",sprojj);	fflush(stdout);	
																							if (tc_strcmp(projectcode,sprojj)==0)
																							{
																								printf("\n\t CC:Addenda already available for same project...");fflush(stdout);
																							}
																							else
																							{

																								printf("\n\t CC:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
																							
																								tc_strcpy (obj_item_idd,"" );
																								year=subString(obj_item_id, 0, 2);
																								plnt=subString(obj_item_id, 2, 2);
																								Seq=subString(obj_item_id, 5, 2);
																								
																								printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
																								if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
																								{
																									tc_strcpy (addPlant,"" );
																									tc_strcpy (addPlant,"CU" );
																									tc_strcpy (obj_item_idd,"" );
																									//tc_strcpy (obj_item_idd,year );
																									tc_strcpy (obj_item_idd,"22" );
																									tc_strcat (obj_item_idd,"CUL");
																									tc_strcat (obj_item_idd,Seq);
																									//tc_strcpy(Addenda_desc,obj_item_idd);
																									//tc_strcpy(object_name,obj_item_idd);
																								}
																								/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
																								{
																									tc_strcpy (addPlant,"" );
																									tc_strcpy (addPlant,"LU" );
																									tc_strcpy (obj_item_idd,"" );
																									//tc_strcpy (obj_item_idd,year );
																									tc_strcpy (obj_item_idd,"23" );
																									tc_strcat (obj_item_idd,"LUA");
																									tc_strcat (obj_item_idd,Seq);
																								}
																								if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
																								{
																									tc_strcpy (addPlant,"" );
																									tc_strcpy (addPlant,"JU" );
																									tc_strcpy (obj_item_idd,"" );
																									//tc_strcpy (obj_item_idd,year );
																									tc_strcpy (obj_item_idd,"23" );
																									tc_strcat (obj_item_idd,"JUA");
																									tc_strcat (obj_item_idd,Seq);
																								}*/
																							
																								if(tc_strlen(obj_item_idd) != 0)
																								{
																									tc_strcpy(Addenda_desc,"");
																									tc_strcpy(object_name,"");
																									tc_strcpy(Addenda_desc,obj_item_idd);
																									tc_strcpy(object_name,obj_item_idd);
																									printf("\n\t CC:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
																									printf("\n\t CC:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
																									printf("\n\t CC:object_name :%s", object_name);fflush(stdout);
																									printf("\n\t CC:projectcode :%s", projectcode);fflush(stdout);
																									printf("\n\t CC:Addenda_desc :%s", Addenda_desc);fflush(stdout);
																									printf("\n\t CC:addPlant :%s", addPlant);fflush(stdout);
																									/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
																									printf("\n\t Desg count :%d", num);fflush(stdout);
																									nextnum=num+1;
																									printf("\n\t nextnum :%d",nextnum);fflush(stdout);
																									ITK_CALL(AOM_lock(item_tag));
																									ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
																									ITK_CALL(AOM_save(item_tag));
																									ITK_CALL(AOM_unlock(item_tag));
																									ITK_CALL(AOM_refresh(item_tag,0));*/
																									ifail = ITEM_find_item (obj_item_idd, &item_taggg);
																									if (item_taggg == NULLTAG)
																									{
																										printf("\n\t CC:************* CODE END *********\n%s",temp);fflush(stdout);
																										printf("\n\t CC:DML addenda not previously present in the system [%s]",obj_item_idd);
																										printf("\n\t CC:*****Creating the T5_DmlAddenda******");fflush(stdout);
																										ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
																										ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
																										ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
																										ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
																										ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
																										ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
																										ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
																										ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
																										ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
																										printf("\n\t CC:*****Saving the the T5_DmlAddenda******");fflush(stdout);
																										ifail = (AOM_save (object));
																									}
																									else
																									{
																										printf("\n\t M:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
																										if(AOM_ask_value_string(item_taggg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
																										printf(" with Project: %s",sprojj);	fflush(stdout);	
																										if (tc_strcmp(projectcode,sprojj)==0)
																										{
																											printf("\n\t CC:Addenda already available for same project...");fflush(stdout);
																										}
																										else
																										{

																											printf("\n\t CC:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
																										
																											tc_strcpy (obj_item_idd,"" );
																											year=subString(obj_item_id, 0, 2);
																											plnt=subString(obj_item_id, 2, 2);
																											Seq=subString(obj_item_id, 5, 2);
																											
																											printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
																											if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
																											{
																												tc_strcpy (addPlant,"" );
																												tc_strcpy (addPlant,"CU" );
																												tc_strcpy (obj_item_idd,"" );
																												//tc_strcpy (obj_item_idd,year );
																												tc_strcpy (obj_item_idd,"22" );
																												tc_strcat (obj_item_idd,"CUM");
																												tc_strcat (obj_item_idd,Seq);
																												//tc_strcpy(Addenda_desc,obj_item_idd);
																												//tc_strcpy(object_name,obj_item_idd);
																											}
																											/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
																											{
																												tc_strcpy (addPlant,"" );
																												tc_strcpy (addPlant,"LU" );
																												tc_strcpy (obj_item_idd,"" );
																												//tc_strcpy (obj_item_idd,year );
																												tc_strcpy (obj_item_idd,"23" );
																												tc_strcat (obj_item_idd,"LUA");
																												tc_strcat (obj_item_idd,Seq);
																											}
																											if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
																											{
																												tc_strcpy (addPlant,"" );
																												tc_strcpy (addPlant,"JU" );
																												tc_strcpy (obj_item_idd,"" );
																												//tc_strcpy (obj_item_idd,year );
																												tc_strcpy (obj_item_idd,"23" );
																												tc_strcat (obj_item_idd,"JUA");
																												tc_strcat (obj_item_idd,Seq);
																											}*/
																										
																											if(tc_strlen(obj_item_idd) != 0)
																											{
																												tc_strcpy(Addenda_desc,"");
																												tc_strcpy(object_name,"");
																												tc_strcpy(Addenda_desc,obj_item_idd);
																												tc_strcpy(object_name,obj_item_idd);
																												printf("\n\t CC:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
																												printf("\n\t CC:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
																												printf("\n\t CC:object_name :%s", object_name);fflush(stdout);
																												printf("\n\t CC:projectcode :%s", projectcode);fflush(stdout);
																												printf("\n\t CC:Addenda_desc :%s", Addenda_desc);fflush(stdout);
																												printf("\n\t CC:addPlant :%s", addPlant);fflush(stdout);
																												/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
																												printf("\n\t Desg count :%d", num);fflush(stdout);
																												nextnum=num+1;
																												printf("\n\t nextnum :%d",nextnum);fflush(stdout);
																												ITK_CALL(AOM_lock(item_tag));
																												ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
																												ITK_CALL(AOM_save(item_tag));
																												ITK_CALL(AOM_unlock(item_tag));
																												ITK_CALL(AOM_refresh(item_tag,0));*/
																												ifail = ITEM_find_item (obj_item_idd, &item_taggg);
																												if (item_taggg == NULLTAG)
																												{
																													printf("\n\t CC:************* CODE END *********\n%s",temp);fflush(stdout);
																													printf("\n\t CC:DML addenda not previously present in the system [%s]",obj_item_idd);
																													printf("\n\t CC:*****Creating the T5_DmlAddenda******");fflush(stdout);
																													ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
																													ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
																													ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
																													ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
																													ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
																													ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
																													ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
																													ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
																													ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
																													printf("\n\t CC:*****Saving the the T5_DmlAddenda******");fflush(stdout);
																													ifail = (AOM_save (object));
																												}
																												else
																												{
																													printf("\n\t N:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
																													if(AOM_ask_value_string(item_taggg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
																													printf(" with Project: %s",sprojj);	fflush(stdout);	
																													if (tc_strcmp(projectcode,sprojj)==0)
																													{
																														printf("\n\t CC:Addenda already available for same project...");fflush(stdout);
																													}
																													else
																													{

																														printf("\n\t CC:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
																													
																														tc_strcpy (obj_item_idd,"" );
																														year=subString(obj_item_id, 0, 2);
																														plnt=subString(obj_item_id, 2, 2);
																														Seq=subString(obj_item_id, 5, 2);
																														
																														printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
																														if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
																														{
																															tc_strcpy (addPlant,"" );
																															tc_strcpy (addPlant,"CU" );
																															tc_strcpy (obj_item_idd,"" );
																															//tc_strcpy (obj_item_idd,year );
																															tc_strcpy (obj_item_idd,"22" );
																															tc_strcat (obj_item_idd,"CUN");
																															tc_strcat (obj_item_idd,Seq);
																															//tc_strcpy(Addenda_desc,obj_item_idd);
																															//tc_strcpy(object_name,obj_item_idd);
																														}
																														/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
																														{
																															tc_strcpy (addPlant,"" );
																															tc_strcpy (addPlant,"LU" );
																															tc_strcpy (obj_item_idd,"" );
																															//tc_strcpy (obj_item_idd,year );
																															tc_strcpy (obj_item_idd,"23" );
																															tc_strcat (obj_item_idd,"LUA");
																															tc_strcat (obj_item_idd,Seq);
																														}
																														if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
																														{
																															tc_strcpy (addPlant,"" );
																															tc_strcpy (addPlant,"JU" );
																															tc_strcpy (obj_item_idd,"" );
																															//tc_strcpy (obj_item_idd,year );
																															tc_strcpy (obj_item_idd,"23" );
																															tc_strcat (obj_item_idd,"JUA");
																															tc_strcat (obj_item_idd,Seq);
																														}*/
																													
																														if(tc_strlen(obj_item_idd) != 0)
																														{
																															tc_strcpy(Addenda_desc,"");
																															tc_strcpy(object_name,"");
																															tc_strcpy(Addenda_desc,obj_item_idd);
																															tc_strcpy(object_name,obj_item_idd);
																															printf("\n\t CC:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
																															printf("\n\t CC:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
																															printf("\n\t CC:object_name :%s", object_name);fflush(stdout);
																															printf("\n\t CC:projectcode :%s", projectcode);fflush(stdout);
																															printf("\n\t CC:Addenda_desc :%s", Addenda_desc);fflush(stdout);
																															printf("\n\t CC:addPlant :%s", addPlant);fflush(stdout);
																															/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
																															printf("\n\t Desg count :%d", num);fflush(stdout);
																															nextnum=num+1;
																															printf("\n\t nextnum :%d",nextnum);fflush(stdout);
																															ITK_CALL(AOM_lock(item_tag));
																															ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
																															ITK_CALL(AOM_save(item_tag));
																															ITK_CALL(AOM_unlock(item_tag));
																															ITK_CALL(AOM_refresh(item_tag,0));*/
																															ifail = ITEM_find_item (obj_item_idd, &item_taggg);
																															if (item_taggg == NULLTAG)
																															{
																																printf("\n\t CC:************* CODE END *********\n%s",temp);fflush(stdout);
																																printf("\n\t CC:DML addenda not previously present in the system [%s]",obj_item_idd);
																																printf("\n\t CC:*****Creating the T5_DmlAddenda******");fflush(stdout);
																																ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
																																ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
																																ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
																																ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
																																ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
																																ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
																																ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
																																ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
																																ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
																																printf("\n\t CC:*****Saving the the T5_DmlAddenda******");fflush(stdout);
																																ifail = (AOM_save (object));
																															}
																															else
																															{
																																printf("\n\t O:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
																																if(AOM_ask_value_string(item_taggg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
																																printf(" with Project: %s",sprojj);	fflush(stdout);	
																																if (tc_strcmp(projectcode,sprojj)==0)
																																{
																																	printf("\n\t CC:Addenda already available for same project...");fflush(stdout);
																																}
																																else
																																{

																																	printf("\n\t CC:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
																																
																																	tc_strcpy (obj_item_idd,"" );
																																	year=subString(obj_item_id, 0, 2);
																																	plnt=subString(obj_item_id, 2, 2);
																																	Seq=subString(obj_item_id, 5, 2);
																																	
																																	printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
																																	if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
																																	{
																																		tc_strcpy (addPlant,"" );
																																		tc_strcpy (addPlant,"CU" );
																																		tc_strcpy (obj_item_idd,"" );
																																		//tc_strcpy (obj_item_idd,year );
																																		tc_strcpy (obj_item_idd,"22" );
																																		tc_strcat (obj_item_idd,"CUO");
																																		tc_strcat (obj_item_idd,Seq);
																																		//tc_strcpy(Addenda_desc,obj_item_idd);
																																		//tc_strcpy(object_name,obj_item_idd);
																																	}
																																	/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
																																	{
																																		tc_strcpy (addPlant,"" );
																																		tc_strcpy (addPlant,"LU" );
																																		tc_strcpy (obj_item_idd,"" );
																																		//tc_strcpy (obj_item_idd,year );
																																		tc_strcpy (obj_item_idd,"23" );
																																		tc_strcat (obj_item_idd,"LUA");
																																		tc_strcat (obj_item_idd,Seq);
																																	}
																																	if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
																																	{
																																		tc_strcpy (addPlant,"" );
																																		tc_strcpy (addPlant,"JU" );
																																		tc_strcpy (obj_item_idd,"" );
																																		//tc_strcpy (obj_item_idd,year );
																																		tc_strcpy (obj_item_idd,"23" );
																																		tc_strcat (obj_item_idd,"JUA");
																																		tc_strcat (obj_item_idd,Seq);
																																	}*/
																																
																																	if(tc_strlen(obj_item_idd) != 0)
																																	{
																																		tc_strcpy(Addenda_desc,"");
																																		tc_strcpy(object_name,"");
																																		tc_strcpy(Addenda_desc,obj_item_idd);
																																		tc_strcpy(object_name,obj_item_idd);
																																		printf("\n\t CC:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
																																		printf("\n\t CC:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
																																		printf("\n\t CC:object_name :%s", object_name);fflush(stdout);
																																		printf("\n\t CC:projectcode :%s", projectcode);fflush(stdout);
																																		printf("\n\t CC:Addenda_desc :%s", Addenda_desc);fflush(stdout);
																																		printf("\n\t CC:addPlant :%s", addPlant);fflush(stdout);
																																		/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
																																		printf("\n\t Desg count :%d", num);fflush(stdout);
																																		nextnum=num+1;
																																		printf("\n\t nextnum :%d",nextnum);fflush(stdout);
																																		ITK_CALL(AOM_lock(item_tag));
																																		ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
																																		ITK_CALL(AOM_save(item_tag));
																																		ITK_CALL(AOM_unlock(item_tag));
																																		ITK_CALL(AOM_refresh(item_tag,0));*/
																																		ifail = ITEM_find_item (obj_item_idd, &item_taggg);
																																		if (item_taggg == NULLTAG)
																																		{
																																			printf("\n\t CC:************* CODE END *********\n%s",temp);fflush(stdout);
																																			printf("\n\t CC:DML addenda not previously present in the system [%s]",obj_item_idd);
																																			printf("\n\t CC:*****Creating the T5_DmlAddenda******");fflush(stdout);
																																			ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
																																			ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
																																			ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
																																			ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
																																			ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
																																			ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
																																			ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
																																			ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
																																			ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
																																			printf("\n\t CC:*****Saving the the T5_DmlAddenda******");fflush(stdout);
																																			ifail = (AOM_save (object));
																																		}
																																		else
																																		{
																																			printf("\n\t P:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
																																			if(AOM_ask_value_string(item_taggg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
																																			printf(" with Project: %s",sprojj);	fflush(stdout);	
																																			if (tc_strcmp(projectcode,sprojj)==0)
																																			{
																																				printf("\n\t CC:Addenda already available for same project...");fflush(stdout);
																																			}
																																			else
																																			{

																																				printf("\n\t CC:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
																																			
																																				tc_strcpy (obj_item_idd,"" );
																																				year=subString(obj_item_id, 0, 2);
																																				plnt=subString(obj_item_id, 2, 2);
																																				Seq=subString(obj_item_id, 5, 2);
																																				
																																				printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
																																				if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
																																				{
																																					tc_strcpy (addPlant,"" );
																																					tc_strcpy (addPlant,"CU" );
																																					tc_strcpy (obj_item_idd,"" );
																																					//tc_strcpy (obj_item_idd,year );
																																					tc_strcpy (obj_item_idd,"22" );
																																					tc_strcat (obj_item_idd,"CUP");
																																					tc_strcat (obj_item_idd,Seq);
																																					//tc_strcpy(Addenda_desc,obj_item_idd);
																																					//tc_strcpy(object_name,obj_item_idd);
																																				}
																																				/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
																																				{
																																					tc_strcpy (addPlant,"" );
																																					tc_strcpy (addPlant,"LU" );
																																					tc_strcpy (obj_item_idd,"" );
																																					//tc_strcpy (obj_item_idd,year );
																																					tc_strcpy (obj_item_idd,"23" );
																																					tc_strcat (obj_item_idd,"LUA");
																																					tc_strcat (obj_item_idd,Seq);
																																				}
																																				if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
																																				{
																																					tc_strcpy (addPlant,"" );
																																					tc_strcpy (addPlant,"JU" );
																																					tc_strcpy (obj_item_idd,"" );
																																					//tc_strcpy (obj_item_idd,year );
																																					tc_strcpy (obj_item_idd,"23" );
																																					tc_strcat (obj_item_idd,"JUA");
																																					tc_strcat (obj_item_idd,Seq);
																																				}*/
																																			
																																				if(tc_strlen(obj_item_idd) != 0)
																																				{
																																					tc_strcpy(Addenda_desc,"");
																																					tc_strcpy(object_name,"");
																																					tc_strcpy(Addenda_desc,obj_item_idd);
																																					tc_strcpy(object_name,obj_item_idd);
																																					printf("\n\t CC:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
																																					printf("\n\t CC:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
																																					printf("\n\t CC:object_name :%s", object_name);fflush(stdout);
																																					printf("\n\t CC:projectcode :%s", projectcode);fflush(stdout);
																																					printf("\n\t CC:Addenda_desc :%s", Addenda_desc);fflush(stdout);
																																					printf("\n\t CC:addPlant :%s", addPlant);fflush(stdout);
																																					/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
																																					printf("\n\t Desg count :%d", num);fflush(stdout);
																																					nextnum=num+1;
																																					printf("\n\t nextnum :%d",nextnum);fflush(stdout);
																																					ITK_CALL(AOM_lock(item_tag));
																																					ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
																																					ITK_CALL(AOM_save(item_tag));
																																					ITK_CALL(AOM_unlock(item_tag));
																																					ITK_CALL(AOM_refresh(item_tag,0));*/
																																					ifail = ITEM_find_item (obj_item_idd, &item_taggg);
																																					if (item_taggg == NULLTAG)
																																					{
																																						printf("\n\t CC:************* CODE END *********\n%s",temp);fflush(stdout);
																																						printf("\n\t CC:DML addenda not previously present in the system [%s]",obj_item_idd);
																																						printf("\n\t CC:*****Creating the T5_DmlAddenda******");fflush(stdout);
																																						ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
																																						ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
																																						ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
																																						ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
																																						ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
																																						ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
																																						ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
																																						ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
																																						ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
																																						printf("\n\t CC:*****Saving the the T5_DmlAddenda******");fflush(stdout);
																																						ifail = (AOM_save (object));
																																					}
																																					else
																																					{
																																						printf("\n\t Q:DML addenda already found for [%s] so going for next..",obj_item_idd);fflush(stdout);
																																						if(AOM_ask_value_string(item_taggg,"t5_ProjectCode",&sprojj)!=ITK_ok)   PrintErrorStack();
																																						printf(" with Project: %s",sprojj);	fflush(stdout);	
																																						if (tc_strcmp(projectcode,sprojj)==0)
																																						{
																																							printf("\n\t CC:Addenda already available for same project...");fflush(stdout);
																																						}
																																						else
																																						{

																																							printf("\n\t CC:Addenda already available for different project, so creating with new addenda...");fflush(stdout);
																																						
																																							tc_strcpy (obj_item_idd,"" );
																																							year=subString(obj_item_id, 0, 2);
																																							plnt=subString(obj_item_id, 2, 2);
																																							Seq=subString(obj_item_id, 5, 2);
																																							
																																							printf("\n vc_release--DML DR status: year: %s plnt: %s and Seq: %s",year,plnt,Seq);fflush(stdout);
																																							if((strstr(plnt,"PM") != NULL)||(strstr(plnt,"PP") != NULL))
																																							{
																																								tc_strcpy (addPlant,"" );
																																								tc_strcpy (addPlant,"CU" );
																																								tc_strcpy (obj_item_idd,"" );
																																								//tc_strcpy (obj_item_idd,year );
																																								tc_strcpy (obj_item_idd,"22" );
																																								tc_strcat (obj_item_idd,"CUQ");
																																								tc_strcat (obj_item_idd,Seq);
																																								//tc_strcpy(Addenda_desc,obj_item_idd);
																																								//tc_strcpy(object_name,obj_item_idd);
																																							}
																																							/*if((strstr(plnt,"LM") != NULL)||(strstr(plnt,"LP") != NULL))
																																							{
																																								tc_strcpy (addPlant,"" );
																																								tc_strcpy (addPlant,"LU" );
																																								tc_strcpy (obj_item_idd,"" );
																																								//tc_strcpy (obj_item_idd,year );
																																								tc_strcpy (obj_item_idd,"23" );
																																								tc_strcat (obj_item_idd,"LUA");
																																								tc_strcat (obj_item_idd,Seq);
																																							}
																																							if((strstr(plnt,"JM") != NULL)||(strstr(plnt,"JP") != NULL))
																																							{
																																								tc_strcpy (addPlant,"" );
																																								tc_strcpy (addPlant,"JU" );
																																								tc_strcpy (obj_item_idd,"" );
																																								//tc_strcpy (obj_item_idd,year );
																																								tc_strcpy (obj_item_idd,"23" );
																																								tc_strcat (obj_item_idd,"JUA");
																																								tc_strcat (obj_item_idd,Seq);
																																							}*/
																																						
																																							if(tc_strlen(obj_item_idd) != 0)
																																							{
																																								tc_strcpy(Addenda_desc,"");
																																								tc_strcpy(object_name,"");
																																								tc_strcpy(Addenda_desc,obj_item_idd);
																																								tc_strcpy(object_name,obj_item_idd);
																																								printf("\n\t CC:TCE Addenda item_id :%s", obj_item_id);fflush(stdout);
																																								printf("\n\t CC:New Addenda item_id :%s", obj_item_idd);fflush(stdout);
																																								printf("\n\t CC:object_name :%s", object_name);fflush(stdout);
																																								printf("\n\t CC:projectcode :%s", projectcode);fflush(stdout);
																																								printf("\n\t CC:Addenda_desc :%s", Addenda_desc);fflush(stdout);
																																								printf("\n\t CC:addPlant :%s", addPlant);fflush(stdout);
																																								/*ITK_CALL(AOM_ask_value_strings( item_tag,"t5_DesignGroupA",&num,&DesignGroupList));
																																								printf("\n\t Desg count :%d", num);fflush(stdout);
																																								nextnum=num+1;
																																								printf("\n\t nextnum :%d",nextnum);fflush(stdout);
																																								ITK_CALL(AOM_lock(item_tag));
																																								ITK_CALL(AOM_set_value_string_at(item_tag,"t5_DesignGroupA",nextnum,DesgGroup));
																																								ITK_CALL(AOM_save(item_tag));
																																								ITK_CALL(AOM_unlock(item_tag));
																																								ITK_CALL(AOM_refresh(item_tag,0));*/
																																								ifail = ITEM_find_item (obj_item_idd, &item_taggg);
																																								if (item_taggg == NULLTAG)
																																								{
																																									printf("\n\t CC:************* CODE END *********\n%s",temp);fflush(stdout);
																																									printf("\n\t CC:DML addenda not previously present in the system [%s]",obj_item_idd);
																																									printf("\n\t CC:*****Creating the T5_DmlAddenda******");fflush(stdout);
																																									ITK_CALL(TCTYPE_find_type("T5_DmlAddenda", NULL, &item_type_tag));
																																									ITK_CALL(TCTYPE_construct_create_input(item_type_tag, &item_create_input_tag));
																																									ITK_CALL(AOM_set_value_string(item_create_input_tag, "item_id", obj_item_idd));
																																									ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_name", object_name));
																																									ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_ProjectCode", projectcode));
																																									ITK_CALL(AOM_set_value_string(item_create_input_tag, "object_desc", Addenda_desc));
																																									ITK_CALL(AOM_set_value_string(item_create_input_tag, "t5_dmladdplant", addPlant));
																																									ITK_CALL(AOM_set_value_strings(item_create_input_tag, "t5_DesignGroupA",piStringCount, AStringList));
																																									ITK_CALL(TCTYPE_create_object (item_create_input_tag, &object));
																																									printf("\n\t CC:*****Saving the the T5_DmlAddenda******");fflush(stdout);
																																									ifail = (AOM_save (object));
																																								}
																																								else
																																								{
																																									printf("\n\t CC:T5_DmlAddenda already available******");fflush(stdout);
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					//return 1;
				}
				/*if(object_name != NULL)
						MEM_free(object_name);

					if(obj_item_id != NULL)
						MEM_free(obj_item_id);

					if(projectcode != NULL)
						MEM_free(projectcode);

					if(Addenda_desc != NULL)
						MEM_free(Addenda_desc);

					if(addPlant != NULL)
						MEM_free(addPlant);*/
			}
		}
	}

	

	return ifail;
}
