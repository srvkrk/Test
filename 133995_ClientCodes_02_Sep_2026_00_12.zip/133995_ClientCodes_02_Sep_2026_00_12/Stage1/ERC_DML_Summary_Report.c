#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <sa/user.h>
#include <tc/folder.h>
#include <sa/person.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
;
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_ask_error_text (return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}
FILE		*DMLoutput 			= NULL;
int			ifail 				= ITK_ok;
char		*sep				= "^";
//int tm_DML_Mail_Fun(char* Input_id);
int tm_DML_Mail_Fun(char* FromDate,char* ToDate);

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"GateMaturationUpd -u=<username> -pf=<password file path> -g=<group> -file=<file_name>\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
void removeSpecialChars(char* str) 
{
    int len = tc_strlen(str);
    //char* result = new char[len + 1];
	len = len + 1;
    char * result = NULL;
	result=(char *) MEM_alloc(len* sizeof(char*)+5);
	int j = 0,i=0;
    for(i = 0; i < len; i++) 
	{
        if((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z') || (str[i] >= '0' && str[i] <= '9')|| (str[i] == '.') || (str[i] == ' ')|| (str[i] == '%')|| (str[i] == ';'))
		{
            result[j++] = str[i];
        }
    }
    result[j] = '\0';
	tc_strcpy(str,"");
    tc_strcpy(str, result);
    //delete[] result;
}
void getCurrentDateTimeAJ(char cCurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%b_%Y",timeptr);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* user_name 				= NULL;
	char			* dmlnob					= NULL;
	char			Data[100]					= "";
	char			DMLoutputFile[200]			= "";
	char* FromDate=NULL;
	char* ToDate=NULL;

	//userid			= ITK_ask_cli_argument("-u=");
	//password 		= ITK_ask_cli_argument("-pf=");
	//group 			= ITK_ask_cli_argument("-g=");
	//dmlnob 		= ITK_ask_cli_argument("-dmlno=");
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	FromDate 		= ITK_ask_cli_argument("-I1=");
	ToDate 			= ITK_ask_cli_argument("-I2=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);

	/*if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}*/

	//ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);

	if(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	if(ITK_auto_login( ));
    if(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nhey Login Successfull.....!!\n");fflush(stdout);
		printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
	}
	//sprintf(DMLoutputFile,"%s_mailoutput.csv",dmlnob);
	
	printf("\nOutput file name : %s",DMLoutputFile);fflush(stdout);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}

	

	printf("\n FromDate: [%s]\n",FromDate);fflush(stdout);
	printf("\n ToDate: [%s]\n",ToDate);fflush(stdout);
	//printf("\n user_name: [%s]\n",user_name);fflush(stdout);
	ifail = tm_DML_Mail_Fun(FromDate,ToDate);
	CHECK_FAIL;

	printf("\n*********************");fflush(stdout);
	printf("\nEnd of program.....!!");fflush(stdout);
	printf("\n*********************\n");fflush(stdout);
	ifail = ITK_exit_module(true);

	return ifail;
}

//int tm_DML_Mail_Fun(char* Input_id)
int tm_DML_Mail_Fun(char* FromDate,char* ToDate)
{
	int		ifail 		= ITK_ok;
	tag_t	item_tag		= NULLTAG;
	tag_t   DMLqryTag     = NULLTAG;
	tag_t	objTag		= NULLTAG;
	char	*DML_info1		= NULL;
	char	*DML_info2		= NULL;
	char	*DML_info3	= NULL;
	char	*DMLManager	= NULL;
	char	*DMLVertical	= NULL;
	char	*Dml_DR	= NULL;
	char	*sDMLBU	= NULL;
	char	*DMLReason	= NULL;
	char	*DMLRlsType	= NULL;
	tag_t   *DML_CntrlObjectTag      = NULLTAG;
	int      i      =  0;
	char	*revId			=  NULL;
	char	*sDMLRlsType			=  NULL;
	char	*dmlNumber			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char   ObjTyp[TCTYPE_name_size_c+1];
	tag_t dml_Ref_Rel	= NULLTAG;
	tag_t dml_Ref_Rel_t	= NULLTAG;
	/*char *mainFile =  NULL;
	char *command =  NULL;
	char *docFile =  NULL;*/
	int k=0;
	int fld=0;
	int tsk=0;
	int partcnt=0;
	int Tskcnt=0;
	int     FlderSize     =  0;
	int     FlderObjCount =  0;
	char *Tsk_object_type =NULL;
	char *Part_no =NULL;
	char *Part_nobr =NULL;
	char *Prtobj_type =NULL;
	char *FldrName =NULL;
	char *sSystPrtName =NULL;
	char *tsknm =NULL;
	char *Part_DR =NULL;
	char *Part_type =NULL;
	char *Part_Descr =NULL;
	char *Part_Rev =NULL;
	char *Part_Proj =NULL;
	char *ncRel_status =NULL;
	char *Part_Desg =NULL;
	char *DMLwbs =NULL;
	char *DMLRel_status =NULL;
	char *DMLClsuDate =NULL;
	char *DMLwbsDesc =NULL;
	tag_t		*PartsTg	= NULLTAG;
	tag_t		*Dml_tasks	= NULLTAG;
	tag_t  *FolderObj_tag	= NULLTAG;
	tag_t AssyTg = NULLTAG;
	tag_t PartTag = NULLTAG;
	tag_t Relationtag = NULLTAG;
	tag_t		*PartsTg4dRef4DDfmea    = NULLTAG;
	char*		PartHasDFSSet			= NULL;
	char*		PartHasDFASet			= NULL;
	char*		PartHasDFMSet			= NULL;
	char*		parthasDfmeaSet			= NULL;
	char*		parthasrefdfemaSet		= NULL;
	char*		parthas4dobjname		= NULL;
	char*		parthasdfmeadobjname	= NULL;
	char*		parthasrefdobjname		= NULL;
	char*		parthas4d				= NULL;
	char*		parthas4d1				= NULL;
	char*		parthas4d2				= NULL;
	char*		Prt_no					= NULL;
	char*		Prt_Tp					= NULL;
	char*		sDMLDesc					= NULL;
	char*		SDMLDesc					= NULL;
	tag_t		person_tag				= NULLTAG;
	tag_t		PartRevTag				= NULLTAG;
	tag_t		PartRevTag1				= NULLTAG;
	tag_t		PartRevTag2				= NULLTAG;
	tag_t		PartRevTag3				= NULLTAG;
	tag_t		*PartsTg4dDfmea			= NULLTAG;
	tag_t		*PartHas4Dflag				= NULLTAG;
	tag_t		*PartsTg4d				= NULLTAG;
	int			j2			=	0;
	int			j1			=	0;
	int			j3			=	0;
	int			Flag4D			=	0;
	int			Srlnum			=	0;
	int			NOofModules			=	0;
	int			ModuleHasFlag4D			=	0;
	int			ModuleHas4Dflag			=	0;
	int			partcnt4dDfmea			=	0;
	int			TotalPartCount				=	0;
	int			partcnt4d				=	0;
	int			partcnt4dRef4DDfmea		=	0;
	int			Support_n_entry		=	1;
	int			Support_rsltCount		=	1;
	tag_t		DCR_RelType		= NULLTAG;
	tag_t		object_owner		= NULLTAG;
	tag_t		DMLtag			= NULLTAG;
	tag_t		DMLtagg			= NULLTAG;
	tag_t		SupportqryTag			= NULLTAG;
	tag_t		part_tsk_relc		= NULLTAG;
	char*		person_name			= NULL;
	char		*sDml_TP				= NULL;
	char*		sDMLFrmTOPlnt			= NULL;
	char*		sDMLdesigngrp			= NULL;
	char*		DMLDesc			= NULL;
	char*		sDMLOwner			= NULL;
	char*		sDMLManager			= NULL;
	char*		DMLDescr			= NULL;
	char*		sDMLname			= NULL;
	char*		DMLnumbstrg			= NULL;
	char*		DMLtrg			= NULL;
	char		 *Prt_object_type =NULL;
	char*		ProjectID			= NULL;
	char*		dcrname			= NULL;
	char*		DMLDCRPARTComInfo5			= NULL;
	char*		DMLDCRPARTComInfo1			= NULL;
	char*		DMLDCRPARTComInfo6			= NULL;
	char            *emailCC                    = NULL;
	char            *eMailTo                    = NULL;
	char            *emailBody	                = NULL;
	char            *emailSub	                = NULL;
	char            *buff	                = NULL;
	int     DCR_cnt      =  0;
	int     iDML      =  0;
	int     Mstr      =  0;
	int     rptline      =  0;
	int     DML_rsltCount      =  0;
	int     DML_n_entry    = 3;
	int     partcntrf    = 3;
	int     pr    = 3;
	tag_t *DCR_list					= NULLTAG;
	tag_t *SupportCntrlObjectTag					= NULLTAG;
	tag_t *PartsTagrf					= NULLTAG;
	tag_t  DCRtag					= NULLTAG;
	char			DMLoutputFile[200]			= "";
	char            *Support_qry_entry[1]  = {"SYSCD"};
	char    **Support_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	eMailTo=(char *) MEM_alloc(1000 * sizeof(char *));
	emailCC=(char *) MEM_alloc(1000 * sizeof(char *));
	emailBody = (char *) MEM_alloc( 10000 * sizeof(char) );
	emailSub = (char *) MEM_alloc( 500 * sizeof(char) );
	buff=(char *) MEM_alloc(5000 * sizeof(char *));
	//char    *DML_qry_entry[4]  = {"Type","Created After","Created Before","Release Status"};
	//char    *DML_qry_entry[3]  = {"Type","Created After","Created Before"};
	//char    *DML_qry_entry[3]  = {"Type","Released After","Released Before"};
	char    *DML_qry_entry[3]  = {"Type","Created After","Created Before"};
	char    **DML_qry_values2     =  (char **) MEM_alloc(5000 * sizeof(char *));
	const char *attrs2[1];
	tag_t   OutPutTag     = NULLTAG;
	tag_t   DesignrevTagR     = NULLTAG;
	int n_tags_found2=0;
	int j8=0;
	int SecondaryCount=0;
	tag_t *tags_found2 = NULL;
	tag_t *part4d = NULL;
	DMLtrg=(char *)MEM_alloc(5000000);
	DMLnumbstrg=(char *)MEM_alloc(5000000);
	parthasDfmeaSet=(char *)MEM_alloc(50000);
	parthasrefdfemaSet=(char *)MEM_alloc(50000);
	PartHasDFASet=(char *)MEM_alloc(50000);
	PartHasDFSSet=(char *)MEM_alloc(50000);
	PartHasDFMSet=(char *)MEM_alloc(50000);
	tc_strcpy(DMLnumbstrg,"");
	//printf("\n P1:....Inside DML Part details.....:[%s]\n",user_name);fflush(stdout);
	printf("\n P2:....Inside DML Part details.From Date:[%s]\n",FromDate);fflush(stdout);
	printf("\n P2:....Inside DML Part details.To Date:[%s]\n",ToDate);fflush(stdout);
	sprintf(DMLoutputFile,"ERC_Released_DML_4D_Summary_Report.csv");
//ifail = ITK_set_bypass(true);
	printf("\nOutput file name : %s",DMLoutputFile);fflush(stdout);
	DMLoutput = fopen(DMLoutputFile, "w+");
	if (DMLoutput == NULL)
	{
		printf("\n ERROR: Cannot open File\n");
		return -1;
	}
	else
	{
		printf("\n File opened successfully.\n");
	}
	//fprintf(DMLoutput,"DML Number,Business_Unit,Release Type, Project, Creator,DR-status,DML Desc,DML Reason,Vertical,DML Manager,DML LC,Closure Date, WBS,WBS Desc,Part no,Rev, DR-status,Part type,Part Project,Design Group,LC status,Part Desc,");
	fprintf(DMLoutput,"Sr No,DML Number,Project,Design Group,Program,Creator,Part Count,No Of DFA/DFS/DFM, No Of DFEMA,No Of RefDFEMA,NO of Modules,No of ModuleHas4D,No of ModuleHasDFMEA,No of ModuleHasRef4D,Release Date,DML Reason,DR-status,Release Type,DML Manager,FROM_TO DR status,DML Synopsis,Reason Description,DFA/DFS/DFM Name,DFMEA Name,Ref.4D Name,No of Part with FIR Request,DCR availability,Business_Unit,Vertical,DR Gateway CheckList,Target Plant, WBS,WBS Desc,");
	if(QRY_find2("Control Objects...", &SupportqryTag));
	if (SupportqryTag)
	{
		printf("\n DCR-->L2:Found Query SupportqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n DCR-->L3:Not Found Query SupportqryTag \n");fflush(stdout);
	}

	Support_qry_values2[0] = "DMLGen4D";
	if(QRY_execute(SupportqryTag, Support_n_entry, Support_qry_entry, Support_qry_values2, &Support_rsltCount, &SupportCntrlObjectTag));
	printf(" \n CheckSupportLogin-->L4:DR_rsltCount :%d:", Support_rsltCount); fflush(stdout);
	if(Support_rsltCount > 0)
	{
		//ON/OFF
		if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo1",&DMLDCRPARTComInfo1)!=ITK_ok) ;  
		printf("\n CheckSupportLogin-->DMLDCRPARTComInfo1 is : [%s]\n", DMLDCRPARTComInfo1);fflush(stdout);
		//Mail Ids.
		if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo5",&DMLDCRPARTComInfo5)!=ITK_ok);   
		printf("\n CheckSupportLogin-->DMLDCRPARTComInfo5 is : [%s]\n", DMLDCRPARTComInfo5);fflush(stdout);
		//Mail Ids.
		if (AOM_ask_value_string(SupportCntrlObjectTag[0],"t5_Userinfo6",&DMLDCRPARTComInfo6)!=ITK_ok);
		printf("\n CheckSupportLogin-->DMLDCRPARTComInfo6 is : [%s]\n", DMLDCRPARTComInfo6);fflush(stdout);
		if(QRY_find2("General...", &DMLqryTag));
		if (DMLqryTag)
		{
			printf("\n P10::Found Query General... \n");fflush(stdout);
		}
		else
		{
			printf("\n P11::Not Found Query General... \n");fflush(stdout);
		}

		DML_qry_values2[0] = "ERC DML Revision";
		//DML_qry_values2[1] = "ERC Released;In Designer Working;In Manager Review";
		//DML_qry_values2[1] = "01-Apr-2023";
		//DML_qry_values2[2] = "31-Aug-2023";

		DML_qry_values2[1] = FromDate;
		DML_qry_values2[2] = ToDate;

		if(QRY_execute(DMLqryTag, DML_n_entry, DML_qry_entry, DML_qry_values2, &DML_rsltCount, &DML_CntrlObjectTag));
		printf(" \n P12::DML_rsltCount :%d:", DML_rsltCount); fflush(stdout);
		if(DML_rsltCount > 0)
		{
			Srlnum=0;
			//for (iDML=0; iDML<DML_rsltCount;iDML++ )
			for (iDML=0; iDML<DML_rsltCount;iDML++ )
			{
				Srlnum++;
				DMLRel_status=NULL;
				sDMLManager=NULL;
				DMLDescr=NULL;
				DMLDesc=NULL;
				sDMLRlsType=NULL;
				DMLRlsType=NULL;
				sDMLOwner=NULL;
				DMLtag			= NULLTAG;
				DMLtag= DML_CntrlObjectTag[iDML];
				//if(ITEM_ask_latest_rev(DMLtagg,&DMLtag)!=ITK_ok)PrintErrorStack();
				if(AOM_ask_value_string(DMLtag,"item_id",&dmlNumber)!=ITK_ok)PrintErrorStack();
				printf("\n MT:DML Number:: [%s]", dmlNumber);fflush(stdout);

				if(AOM_ask_owner(DMLtag,&object_owner)!=ITK_ok)PrintErrorStack();
				if(SA_ask_user_person(object_owner,&person_tag)!=ITK_ok)PrintErrorStack();
				if(SA_ask_person_name2(person_tag,&person_name)!=ITK_ok)PrintErrorStack();
				STRNG_replace_str(person_name,",",";",&person_name);
				STRNG_replace_str(person_name,"\n",";",&person_name);
				printf("\nCreator Name %s",person_name);fflush(stdout);
				if(AOM_UIF_ask_value(DMLtag,"t5_rlstype",&sDMLRlsType));
				if(AOM_UIF_ask_value(DMLtag,"t5_PlntToPlnt",&sDMLFrmTOPlnt));
				if(AOM_UIF_ask_value(DMLtag,"t5_crdesigngroup",&sDMLdesigngrp));
				if(AOM_UIF_ask_value(DMLtag,"owning_user",&sDMLOwner));
				if(AOM_ask_value_string(DMLtag,"t5_rlstype",&DMLRlsType));
				if(AOM_ask_value_string(DMLtag,"t5_TargetPlant",&sDml_TP)!=ITK_ok)PrintErrorStack();
				//if(AOM_ask_value_string(DMLtag,"CMClosureDate",&DMLClsuDate));
				if(AOM_UIF_ask_value(DMLtag,"date_released",&DMLClsuDate));
				if(AOM_UIF_ask_value(DMLtag,"t5_ERCBusiUt",&sDMLBU));
				STRNG_replace_str(sDMLBU,",",";",&sDMLBU);
				STRNG_replace_str(sDMLBU,"\n",";",&sDMLBU);
				if(AOM_UIF_ask_value(DMLtag,"t5_cDRstatus",&Dml_DR)!=ITK_ok)PrintErrorStack();
				STRNG_replace_str(Dml_DR,",",";",&Dml_DR);
				STRNG_replace_str(Dml_DR,"\n",";",&Dml_DR);
				printf("\n DMLRlsType: [%s] sDMLFrmTOPlnt [%s] sDMLRlsType:%s sDMLBU:%s Dml_DR:%s  DMLClsuDate:%s sDMLOwner:%s\n",DMLRlsType,sDMLFrmTOPlnt,sDMLRlsType,sDMLBU,Dml_DR,DMLClsuDate,sDMLOwner);fflush(stdout);
				if(AOM_UIF_ask_value(DMLtag,"t5_DmlReasonDisplay",&DMLReason)!=ITK_ok)PrintErrorStack();
				STRNG_replace_str(DMLReason,",",";",&DMLReason);
				STRNG_replace_str(DMLReason,",",";",&DMLReason);
				STRNG_replace_str(DMLReason,",",";",&DMLReason);
				STRNG_replace_str(DMLReason,",",";",&DMLReason);
				STRNG_replace_str(DMLReason,",",";",&DMLReason);
				STRNG_replace_str(DMLReason,"\n",";",&DMLReason);
				STRNG_replace_str(DMLReason,"\n",";",&DMLReason);
				STRNG_replace_str(DMLReason,"\n",";",&DMLReason);
				STRNG_replace_str(DMLReason,"\n",";",&DMLReason);
				STRNG_replace_str(DMLReason,"\n",";",&DMLReason);
				STRNG_replace_str(DMLReason,"\n",";",&DMLReason);
				
				if(AOM_UIF_ask_value(DMLtag,"t5_ProductLine",&DMLVertical)!=ITK_ok)PrintErrorStack();
				STRNG_replace_str(DMLVertical,",",";",&DMLVertical);
				STRNG_replace_str(DMLVertical,"\n",";",&DMLVertical);
				if(AOM_UIF_ask_value(DMLtag,"ChangeReviewBoard",&sDMLManager)!=ITK_ok)PrintErrorStack();
				if(AOM_UIF_ask_value(DMLtag,"object_name",&sDMLname)!=ITK_ok)PrintErrorStack();
				STRNG_replace_str(sDMLname,",",";",&sDMLname);
				STRNG_replace_str(sDMLname,"\n",";",&sDMLname);
				if(AOM_UIF_ask_value(DMLtag,"t5_reasondesc",&sDMLDesc)!=ITK_ok)PrintErrorStack();
				STRNG_replace_str(sDMLDesc,",","_",&SDMLDesc);
				STRNG_replace_str(SDMLDesc,"\n","_",&SDMLDesc);
				if(AOM_UIF_ask_value(DMLtag,"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
				STRNG_replace_str(ProjectID,",",";",&ProjectID);
				STRNG_replace_str(ProjectID,"\n",";",&ProjectID);
				printf("\n DMLReason: [%s]  DMLVertical:[%s] sDMLManager:[%s] ProjectID:[%s] DMLname: [%s]\n",DMLReason,DMLVertical,sDMLManager,ProjectID,SDMLDesc);fflush(stdout);
				DMLManager = tc_strtok(sDMLManager,",");
				printf("\n   DMLManager:[%s] \n",DMLManager);fflush(stdout);
				if(AOM_UIF_ask_value(DMLtag,"t5_ERCWBS",&DMLwbs)!=ITK_ok)PrintErrorStack();
				STRNG_replace_str(DMLwbs,",",";",&DMLwbs);
				STRNG_replace_str(DMLwbs,"\n",";",&DMLwbs);
				if(AOM_UIF_ask_value(DMLtag,"t5_ERCWbsDes",&DMLwbsDesc)!=ITK_ok)PrintErrorStack();
				STRNG_replace_str(DMLwbsDesc,",",";",&DMLwbsDesc);
				STRNG_replace_str(DMLwbsDesc,",",";",&DMLwbsDesc);
				STRNG_replace_str(DMLwbsDesc,",",";",&DMLwbsDesc);
				STRNG_replace_str(DMLwbsDesc,",",";",&DMLwbsDesc);
				STRNG_replace_str(DMLwbsDesc,",",";",&DMLwbsDesc);
				STRNG_replace_str(DMLwbsDesc,"\n",";",&DMLwbsDesc);
				STRNG_replace_str(DMLwbsDesc,"\n",";",&DMLwbsDesc);
				STRNG_replace_str(DMLwbsDesc,"\n",";",&DMLwbsDesc);
				STRNG_replace_str(DMLwbsDesc,"\n",";",&DMLwbsDesc);
				STRNG_replace_str(DMLwbsDesc,"\n",";",&DMLwbsDesc);
				printf("\n DMLwbs: [%s]  DMLwbsDesc:[%s] \n",DMLwbs,DMLwbsDesc);fflush(stdout);
				if(AOM_UIF_ask_value (DMLtag, "release_status_list", &DMLRel_status)!=ITK_ok)PrintErrorStack();
				STRNG_replace_str(DMLRel_status,",",";",&DMLRel_status);
				STRNG_replace_str(DMLRel_status,",",";",&DMLRel_status);
				STRNG_replace_str(DMLRel_status,",",";",&DMLRel_status);
				STRNG_replace_str(DMLRel_status,",",";",&DMLRel_status);
				STRNG_replace_str(DMLRel_status,",",";",&DMLRel_status);
				STRNG_replace_str(DMLRel_status,"\n",";",&DMLRel_status);
				STRNG_replace_str(DMLRel_status,"\n",";",&DMLRel_status);
				STRNG_replace_str(DMLRel_status,"\n",";",&DMLRel_status);
				STRNG_replace_str(DMLRel_status,"\n",";",&DMLRel_status);
				STRNG_replace_str(DMLRel_status,"\n",";",&DMLRel_status);
				printf("\n   DMLRel_status:[%s] \n",DMLRel_status);fflush(stdout);
				
				tc_strcpy(DMLtrg,"");
				if(tc_strcmp(ProjectID,"29999")!=0)
				{
					//AOM_UIF_ask_value
					//if(dmlNumber !=NULL)
					if (tc_strlen(dmlNumber)> 0)
					{
						fprintf(DMLoutput,"\n%d,%s,",Srlnum,dmlNumber); fflush(DMLoutput);
						tc_strcpy(DMLtrg,"\n");
						tc_strcpy(DMLtrg,dmlNumber);
						//tc_strcat(DMLnumbstrg,dmlNumber);
						//tc_strcat(DMLnumbstrg,",");
						tc_strcat(DMLtrg,",");
					}
					else
					{
						fprintf(DMLoutput,"\nNA,"); fflush(DMLoutput);
						tc_strcpy(DMLtrg,"\nNA");
						tc_strcat(DMLtrg,",");
					}

					//ProjectID
					//if(ProjectID !=NULL)
					if (tc_strlen(ProjectID)> 0)
					{
						fprintf(DMLoutput,"%s,",ProjectID);fflush(DMLoutput);
						tc_strcat(DMLtrg,ProjectID);
						tc_strcat(DMLtrg,",");
					}
					else
					{
						fprintf(DMLoutput,"NA,");fflush(DMLoutput);
						tc_strcat(DMLtrg,"NA");
						tc_strcat(DMLtrg,",");
					}
					
					//Design group
					//if(sDMLdesigngrp !=NULL)
					if (tc_strlen(sDMLdesigngrp)> 0)
					{
						fprintf(DMLoutput,"%s,",sDMLdesigngrp);fflush(DMLoutput);
						tc_strcat(DMLtrg,sDMLdesigngrp);
						tc_strcat(DMLtrg,",");
					}
					else
					{
						fprintf(DMLoutput,"NA,");fflush(DMLoutput);
						tc_strcat(DMLtrg,"NA");
						tc_strcat(DMLtrg,",");
					}
					
					//Program
					if (tc_strlen(person_name)> 0)
					{
						printf("\n A55555555555.. \n");fflush(stdout);
						fprintf(DMLoutput,"%s,",DMLVertical);fflush(DMLoutput);
						tc_strcat(DMLtrg,DMLVertical);
						tc_strcat(DMLtrg,",");
					}
					else
					{
						printf("\n A6666666666666.. \n");fflush(stdout);
						fprintf(DMLoutput,"NA,");fflush(DMLoutput);
						tc_strcat(DMLtrg,"NA");
						tc_strcat(DMLtrg,",");
					}

					//creator
					//if(person_name !=NULL)
					if (tc_strlen(person_name)> 0)
					{
						fprintf(DMLoutput,"%s,",person_name);fflush(DMLoutput);
						tc_strcat(DMLtrg,person_name);
						tc_strcat(DMLtrg,",");
					}
					else
					{
						fprintf(DMLoutput,"NA,");fflush(DMLoutput);
						tc_strcat(DMLtrg,"NA");
						tc_strcat(DMLtrg,",");
					}
					
					printf("\n PO: DMLtrg:%s",DMLtrg);fflush(stdout);
					//DML to task and task to part.
					//if (tc_strcmp(DMLRlsType,"MR")==0) VCMDU
					rptline=0;
					//ProjectID
					//Check for DCR.
					DCR_cnt=0;
					if(GRM_find_relation_type("CMImplements",&DCR_RelType)!=ITK_ok)PrintErrorStack();
					if(GRM_list_secondary_objects_only(DMLtag,DCR_RelType,&DCR_cnt,&DCR_list)!=ITK_ok)PrintErrorStack();
					printf("\n DML HAVING DCRs: [%d] ", DCR_cnt);fflush(stdout);
					if(DCR_cnt>0)
					{
					for (j8=0;j8<DCR_cnt ;j8++ )
					{
						DCRtag=DCR_list[j8];

						if(AOM_ask_value_string(DCRtag,"current_id",&dcrname));
						
					}
					}
					int DRGatewayFlag=0;
					//Check for DR-gate way list
					if(GRM_find_relation_type("IMAN_reference", &part_tsk_relc)!=ITK_ok)PrintErrorStack();
					printf("\n For MDM DML -Expanding IMAN_reference expanded \n"); fflush(stdout);

					 if (part_tsk_relc!=NULLTAG)
					 {
					   printf("\n For MDM DML Inside not null tag part_tsk_relc -- tt value  \n" ); fflush(stdout);

					   if(GRM_list_secondary_objects_only(DMLtag, part_tsk_relc, &partcntrf, &PartsTagrf));//3 sept
					   printf("\n For MDM DML Dataset attached to refrence folder .:%d \n",partcntrf);fflush(stdout);

					   if (partcntrf>0)
						 {
						   for (pr=0;pr<partcntrf;pr++)
							{
								printf("\n Inside Dataset found for MDM DML  \n"); fflush(stdout);
								DesignrevTagR=PartsTagrf[pr];

								if(AOM_ask_value_string(DesignrevTagR,"object_name",&Prt_object_type)!=ITK_ok);
								printf("\n In Mdm dml for Dataset, object_name is :%s \n",Prt_object_type);fflush(stdout);

								if(tc_strstr(Prt_object_type,"Gateway_Checklist")!=NULL)
								{
									DRGatewayFlag++;
								}
							}
						}
					}
					
						

					if((tc_strcmp(DMLRlsType,"VCMDU")==0)||(tc_strcmp(DMLRlsType,"TODR")==0)||(tc_strcmp(DMLRlsType,"RBQU")==0)||(tc_strcmp(DMLRlsType,"CP")==0)||(tc_strcmp(DMLRlsType,"CM")==0)||(tc_strcmp(DMLRlsType,"EP")==0)||(tc_strcmp(DMLRlsType,"MR")==0)||(tc_strcmp(DMLRlsType,"DFMR")==0)||(tc_strcmp(DMLRlsType,"TPL")==0)||(tc_strcmp(DMLRlsType,"Veh")==0)||(tc_strcmp(DMLRlsType,"TSKR")==0))
					{
						if(AOM_ask_value_tags(DMLtag,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
						printf("\n Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
						if (Tskcnt>0)
						{
							int NO4Dflag=0;
							//creation set of parts atached to task for updation.
							/*TotalPartCount=0;
							for (tskk=0;tskk<Tskcnt ;tskk++ )
							{
								if((tc_strcmp(DMLRlsType,"MR")==0)||(tc_strcmp(DMLRlsType,"RBQU")==0)||(tc_strcmp(DMLRlsType,"CP")==0)||(tc_strcmp(DMLRlsType,"CM")==0)||(tc_strcmp(DMLRlsType,"EP")==0)||(tc_strcmp(DMLRlsType,"DFMR")==0)||(tc_strcmp(DMLRlsType,"TPL")==0)||(tc_strcmp(DMLRlsType,"Veh")==0)||(tc_strcmp(DMLRlsType,"TSKR")==0))
								{
									if(AOM_ask_value_tags(Dml_tasks[tskk],"CMHasSolutionItem",&Tpartcnt,&TPartsTg)!=ITK_ok)   PrintErrorStack();
									printf("\n 1.Part count check:%d",Tpartcnt);fflush(stdout);
									if (Tpartcnt>0)
									{
										for (tk=0;tk<Tpartcnt;tk++ )
										{
											TotalPartCount++;
										}
									}
								}
								else if ((tc_strcmp(DMLRlsType,"TODR")==0) ||(tc_strcmp(DMLRlsType,"VCMDU")==0))
								{
									if(AOM_ask_value_tags(Dml_tasks[tskk],"CMReferences",&Tpartcnt,&TPartsTg)!=ITK_ok)PrintErrorStack();
									printf("\n 2.Part count check:%d",Tpartcnt);fflush(stdout);
									if (Tpartcnt>0)
									{
										for (tk=0;tk<Tpartcnt;tk++)
										{
											TotalPartCount++;
										}
									}
								}
							}*/
							//printf("\n 2.Number of parts attached: [%d]",TotalPartCount);fflush(stdout);
							NOofModules=0;
							TotalPartCount=0;
							ModuleHasFlag4D=0;
							PartHas4Dflag=0;
							int ModuleHasRef4Dflag=0;
							int PartHasRef4Dflag=0;
							int First_DFMEA_flag=0;
							int PartHasDFMEAflag=0;
							int First_DFS_Flag=0;
							int NoOfPartWithTR=0;
							int First_Ref_flag=0;
							int ModuleHasDFMEAflag=0;
							int TRcount=0;
							tag_t *TRTag=NULLTAG;
							tag_t TRRelationtag=NULLTAG;

							printf("\n INITIAL:NOofModules:[%d] ModuleHas4Dflag[%d] TotalPartCount:[%d] PartHas4Dflag:[%d]",NOofModules,ModuleHas4Dflag,TotalPartCount,PartHas4Dflag);fflush(stdout);

							tc_strcpy(PartHasDFMSet,"");
							tc_strcpy(PartHasDFSSet,"");
							tc_strcpy(parthasrefdfemaSet,"");
							tc_strcpy(PartHasDFASet,"");
							tc_strcpy(parthasDfmeaSet,"");
							for (tsk=0;tsk<Tskcnt ;tsk++ )
							{
								if(AOM_ask_value_string(Dml_tasks[tsk],"item_id",&tsknm)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();
								printf("\n Task:%s ObjType :%s\n",tsknm,Tsk_object_type);fflush(stdout);

								if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
								{
									//Task expanssion till parts.
									if((tc_strcmp(DMLRlsType,"MR")==0)||(tc_strcmp(DMLRlsType,"RBQU")==0)||(tc_strcmp(DMLRlsType,"CP")==0)||(tc_strcmp(DMLRlsType,"CM")==0)||(tc_strcmp(DMLRlsType,"EP")==0)||(tc_strcmp(DMLRlsType,"DFMR")==0)||(tc_strcmp(DMLRlsType,"TPL")==0)||(tc_strcmp(DMLRlsType,"Veh")==0)||(tc_strcmp(DMLRlsType,"TSKR")==0))
									{
										if(AOM_ask_value_tags(Dml_tasks[tsk],"CMHasSolutionItem",&partcnt,&PartsTg)!=ITK_ok)   PrintErrorStack();
										printf("\n 1.PO: Now partcnt:%d",partcnt);fflush(stdout);
										
									}
									else if ((tc_strcmp(DMLRlsType,"TODR")==0) ||(tc_strcmp(DMLRlsType,"VCMDU")==0))
									{
										if(AOM_ask_value_tags(Dml_tasks[tsk],"CMReferences",&partcnt,&PartsTg)!=ITK_ok)PrintErrorStack();
										printf("\n 2.PO: Now partcnt:%d",partcnt);fflush(stdout);
									}
									if (partcnt>0)
									{
										for (k=0;k<partcnt ;k++ )
										{
											TRcount=0;
											Flag4D=0;
											PartRevTag=PartsTg[k];
											printf("\n X26:Design Mstr:%d",Mstr);fflush(stdout);
											if(AOM_ask_value_string(PartRevTag,"object_type",&Prt_object_type)!=ITK_ok)PrintErrorStack();
											printf("\n X27:Prt_object_type is :%s\n",Prt_object_type);fflush(stdout);
											if(strcmp(Prt_object_type,"Folder")!=0)
											{
												if(AOM_ask_value_string(PartRevTag,"item_id",&Prt_no)!=ITK_ok)PrintErrorStack();
												if(AOM_ask_value_string(PartRevTag,"t5_PartType",&Prt_Tp)!=ITK_ok)PrintErrorStack();
												//Get Part to FIR Request.
												if(GRM_find_relation_type("T5_TR_DesRev_Rel",&TRRelationtag)!=ITK_ok)   PrintErrorStack();
												if(GRM_list_secondary_objects_only(PartRevTag,TRRelationtag,&TRcount,&TRTag)!=ITK_ok)   PrintErrorStack();
												printf("\n P1:Prt_no: %s TRcount:%d\n",Prt_no,TRcount);fflush(stdout);
												if (TRcount >0)
												{
													NoOfPartWithTR++;
												}
												
												if(GRM_find_relation_type("T5_PartHas4D",&Relationtag)!=ITK_ok)   PrintErrorStack();
												if(GRM_list_secondary_objects_only(PartRevTag,Relationtag,&partcnt4d,&part4d)!=ITK_ok)   PrintErrorStack();
												printf("\n P1:Prt_no:%s Part type: %s Now partcnt4d:%d\n",Prt_no,Prt_Tp,partcnt4d);fflush(stdout);
												TotalPartCount ++;
												if(tc_strcmp(Prt_Tp,"M")==0)
												{
													NOofModules ++;
												}
												//DFA/DFS/DFM
												if (partcnt4d >0)
												{
													if(tc_strcmp(Prt_Tp,"M")==0)
													{
														//NOofModules ++;
														//TotalPartCount ++;
														
															ModuleHas4Dflag ++;
															PartHas4Dflag ++;
															//Flag4D=1;
													}
													else
													{

															PartHas4Dflag ++;
															//Flag4D=1;
													}
												}
												//DFM/DFS/DFA
												printf("\n TotalPartCount:%d   NOofModules:%d",TotalPartCount,NOofModules);fflush(stdout);
												if(partcnt4d >0)
												{
													for (j1=0;j1<partcnt4d ;j1++ )
													{
														PartRevTag1=part4d[j1];
														
														if(AOM_ask_value_string(PartRevTag1,"object_name",&parthas4dobjname));
														printf("\n P7: Now parthas4dobjname:%s\n",parthas4dobjname);fflush(stdout);

														if (First_DFS_Flag==0)
														{
															if(tc_strstr(parthas4dobjname,"DFA")!=NULL)
															{
																
																strcat(PartHasDFASet,parthas4dobjname);
																//strcat(PartHasDFASet,"; ");
															}
															else if(tc_strstr(parthas4dobjname,"DFS")!=NULL)
															{
																
																strcat(PartHasDFSSet,parthas4dobjname);
																//strcat(PartHasDFSSet,"; ");
															}
															else if(tc_strstr(parthas4dobjname,"DFM")!=NULL)
															{
																
																strcat(PartHasDFMSet,parthas4dobjname);
																//strcat(PartHasDFMSet,"; ");
															}
														}
														else
														{
															if(tc_strstr(parthas4dobjname,"DFA")!=NULL)
															{
																strcat(PartHasDFASet,": ");
																strcat(PartHasDFASet,parthas4dobjname);
																
															}
															else if(tc_strstr(parthas4dobjname,"DFS")!=NULL)
															{
																strcat(PartHasDFSSet,": ");
																strcat(PartHasDFSSet,parthas4dobjname);
																
															}
															else if(tc_strstr(parthas4dobjname,"DFM")!=NULL)
															{
																strcat(PartHasDFMSet,": ");
																strcat(PartHasDFMSet,parthas4dobjname);
																
															}
														}
														First_DFS_Flag++;
													}	
												}

												//DFMEA
												if(AOM_ask_value_tags(PartRevTag,"T5_PartHasDfmea",&partcnt4dDfmea,&PartsTg4dDfmea)!=ITK_ok)   PrintErrorStack();
												printf("\n P7: Now partcnt4dDfmea:%d\n",partcnt4dDfmea);fflush(stdout);
												if (partcnt4dDfmea >0)
												{
													if(tc_strcmp(Prt_Tp,"M")==0)
													{
														ModuleHasDFMEAflag ++;
														//if (Flag4DFMEA ==0)
														//{														
															PartHasDFMEAflag ++;
															//Flag4DFMEA=1;
														//}
													}
													else
													{
														
														//if (Flag4DFMEA ==0)
														//{
															PartHasDFMEAflag ++;	
															//Flag4DFMEA=1;
														//}
		
													}
												}
												if(partcnt4dDfmea>0)
												{
													for (j2=0;j2<partcnt4dDfmea ;j2++ )
													{
														PartRevTag2=PartsTg4dDfmea[j2];
														
														if(AOM_ask_value_string(PartRevTag2,"object_name",&parthasdfmeadobjname));
														printf("\n P7: Now parthasdfmeadobjname:%s\n",parthasdfmeadobjname);fflush(stdout);
														
														//strcat(parthasDfmeaSet,parthasdfmeadobjname);
														//strcat(parthasDfmeaSet,"; ");
														if (First_DFMEA_flag ==0)
														{
															printf("\n FFFF.\n");fflush(stdout);
															strcat(parthasDfmeaSet,parthasdfmeadobjname);
														}
														else
														{
															printf("\n SSSS.\n");fflush(stdout);
															strcat(parthasDfmeaSet,": ");
															strcat(parthasDfmeaSet,parthasdfmeadobjname);
														}
														First_DFMEA_flag++;
													}
												}
												else
												{
													
													//strcat(parthasDfmeaSet,"NA");
													//strcat(parthasDfmeaSet,"; ");

												}
												if(AOM_ask_value_tags(PartRevTag,"T5_PartHasRef4DDfmea",&partcnt4dRef4DDfmea,&PartsTg4dRef4DDfmea)!=ITK_ok)   PrintErrorStack();
												printf("\n P7: Now partcnt4dRef4DDfmea:%d\n",partcnt4dRef4DDfmea);fflush(stdout);
												if (partcnt4dRef4DDfmea >0)
												{
													if(tc_strcmp(Prt_Tp,"M")==0)
													{
														ModuleHasRef4Dflag ++;
														PartHasRef4Dflag ++;
													}
													else
													{
														/////////
														PartHasRef4Dflag ++;
														//Flag4D=1;
													}
												}
												
												
												if(partcnt4dRef4DDfmea>0)
												{
													for (j3=0;j3<partcnt4dRef4DDfmea;j3++ )
													{
														PartRevTag3=PartsTg4dRef4DDfmea[j3];
														
														if(AOM_ask_value_string(PartRevTag3,"object_name",&parthasrefdobjname));
														printf("\n P7: Now parthasrefdobjname:%s\n",parthasrefdobjname);fflush(stdout);
														
														if (First_Ref_flag ==0)
														{
															printf("\n FF.\n");fflush(stdout);
															strcat(parthasrefdfemaSet,parthasrefdobjname);
														}
														else
														{
															printf("\n SS.\n");fflush(stdout);
															strcat(parthasrefdfemaSet,": ");
															strcat(parthasrefdfemaSet,parthasrefdobjname);
														}
														First_Ref_flag++;
													}
												}
												else
												{
													//strcat(parthasrefdfemaSet,"NA");
													//strcat(parthasrefdfemaSet,"; ");
												}
											}
											else
											{
												//for folder
												printf("\n X67: Expanssion for Folder.");fflush(stdout);
												if(AOM_ask_value_string(PartRevTag,"object_name",&FldrName)!=ITK_ok)PrintErrorStack();
												printf("\n X68:FldrName:: %s\n", FldrName);fflush(stdout);
												if(tc_strcmp(FldrName,"Parts For Gate Maturation")==0)
												{
													printf("\n X69: getting parts.\n");fflush(stdout);
													if(FL_ask_size(PartRevTag,&FlderSize));
													printf("\n X70:FlderSize is:   %d\n",FlderSize);fflush(stdout);
													if(FL_ask_references(PartRevTag,FL_fsc_by_date_modified ,&FlderObjCount,&FolderObj_tag));
													printf("\n X71:FlderObjCount is..:   %d\n",FlderObjCount);fflush(stdout);
													if(FlderObjCount>0)
													{
														fld=0;
														for (fld=0;fld<FlderObjCount;fld++)
														{
															TRcount=0;
															if(AOM_ask_value_string(FolderObj_tag[fld],"item_id",&Prt_no)!=ITK_ok)PrintErrorStack();
															if(AOM_ask_value_string(FolderObj_tag[fld],"t5_PartType",&Prt_Tp)!=ITK_ok)PrintErrorStack();
															//Get Part to FIR Request.
															if(GRM_find_relation_type("T5_TR_DesRev_Rel",&TRRelationtag)!=ITK_ok)   PrintErrorStack();
															if(GRM_list_secondary_objects_only(PartRevTag,TRRelationtag,&TRcount,&TRTag)!=ITK_ok)   PrintErrorStack();
															printf("\n P1:Prt_no: %s TRcount:%d\n",Prt_no,TRcount);fflush(stdout);
															if (TRcount >0)
															{
																NoOfPartWithTR++;
															}
															
															if(GRM_find_relation_type("T5_PartHas4D",&Relationtag)!=ITK_ok)   PrintErrorStack();
															if(GRM_list_secondary_objects_only(FolderObj_tag[fld],Relationtag,&partcnt4d,&part4d)!=ITK_ok)   PrintErrorStack();
															printf("\n P1:Prt_no:%s Part type: %s Now partcnt4d:%d\n",Prt_no,Prt_Tp,partcnt4d);fflush(stdout);
															TotalPartCount ++;
															if(tc_strcmp(Prt_Tp,"M")==0)
															{
																NOofModules ++;
															}
															//DFA/DFS/DFM
															if (partcnt4d >0)
															{
																if(tc_strcmp(Prt_Tp,"M")==0)
																{
																	//NOofModules ++;
																	//TotalPartCount ++;
																	
																		ModuleHas4Dflag ++;
																		PartHas4Dflag ++;
																		//Flag4D=1;
																}
																else
																{

																		PartHas4Dflag ++;
																		//Flag4D=1;
																}
															}
															//DFM/DFS/DFA
															printf("\n TotalPartCount:%d   NOofModules:%d",TotalPartCount,NOofModules);fflush(stdout);
															if(partcnt4d >0)
															{
																for (j1=0;j1<partcnt4d ;j1++ )
																{
																	PartRevTag1=part4d[j1];
																	
																	if(AOM_ask_value_string(PartRevTag1,"object_name",&parthas4dobjname));
																	printf("\n P1: Now parthas4dobjname:%s\n",parthas4dobjname);fflush(stdout);
																	if (First_DFS_Flag==0)
																	{
																		if(tc_strstr(parthas4dobjname,"DFA")!=NULL)
																		{
																			
																			strcat(PartHasDFASet,parthas4dobjname);
																			//strcat(PartHasDFASet,"; ");
																		}
																		else if(tc_strstr(parthas4dobjname,"DFS")!=NULL)
																		{
																			
																			strcat(PartHasDFSSet,parthas4dobjname);
																			//strcat(PartHasDFSSet,"; ");
																		}
																		else if(tc_strstr(parthas4dobjname,"DFM")!=NULL)
																		{
																			
																			strcat(PartHasDFMSet,parthas4dobjname);
																			//strcat(PartHasDFMSet,"; ");
																		}
																	}
																	else
																	{
																		if(tc_strstr(parthas4dobjname,"DFA")!=NULL)
																		{
																			strcat(PartHasDFASet,": ");
																			strcat(PartHasDFASet,parthas4dobjname);
																			
																		}
																		else if(tc_strstr(parthas4dobjname,"DFS")!=NULL)
																		{
																			strcat(PartHasDFSSet,": ");
																			strcat(PartHasDFSSet,parthas4dobjname);
																			
																		}
																		else if(tc_strstr(parthas4dobjname,"DFM")!=NULL)
																		{
																			strcat(PartHasDFMSet,": ");
																			strcat(PartHasDFMSet,parthas4dobjname);
																			
																		}
																	}
																	First_DFS_Flag++;
																}
																
															}
			
															//DFMEA
															if(AOM_ask_value_tags(FolderObj_tag[fld],"T5_PartHasDfmea",&partcnt4dDfmea,&PartsTg4dDfmea)!=ITK_ok)   PrintErrorStack();
															printf("\n P2: Now partcnt4dDfmea:%d\n",partcnt4dDfmea);fflush(stdout);
															if (partcnt4dDfmea >0)
															{
																if(tc_strcmp(Prt_Tp,"M")==0)
																{
																	ModuleHasDFMEAflag ++;
																	//if (Flag4DFMEA ==0)
																	//{														
																		PartHasDFMEAflag ++;
																		//Flag4DFMEA=1;
																	//}
																}
																else
																{
																	
																	//if (Flag4DFMEA ==0)
																	//{
																		PartHasDFMEAflag ++;	
																		//Flag4DFMEA=1;
																	//}
					
																}
															}
															if(partcnt4dDfmea>0)
															{
																for (j2=0;j2<partcnt4dDfmea ;j2++ )
																{
																	PartRevTag2=PartsTg4dDfmea[j2];
																	
																	if(AOM_ask_value_string(PartRevTag2,"object_name",&parthasdfmeadobjname));
																	printf("\n P2: Now parthasdfmeadobjname:%s\n",parthasdfmeadobjname);fflush(stdout);
																	
																	//strcat(parthasDfmeaSet,parthasdfmeadobjname);
																	//strcat(parthasDfmeaSet,"; ");
																	if (First_DFMEA_flag ==0)
																	{
																		printf("\n FFF.\n");fflush(stdout);
																		strcat(parthasDfmeaSet,parthasdfmeadobjname);
																	}
																	else
																	{
																		printf("\n SSS.\n");fflush(stdout);
																		strcat(parthasDfmeaSet,": ");
																		strcat(parthasDfmeaSet,parthasdfmeadobjname);
																	}
																	First_DFMEA_flag++;
																}
															}

															if(AOM_ask_value_tags(FolderObj_tag[fld],"T5_PartHasRef4DDfmea",&partcnt4dRef4DDfmea,&PartsTg4dRef4DDfmea)!=ITK_ok)   PrintErrorStack();
															printf("\n P3:: Now partcnt4dRef4DDfmea:%d\n",partcnt4dRef4DDfmea);fflush(stdout);
															if (partcnt4dRef4DDfmea >0)
															{
																if(tc_strcmp(Prt_Tp,"M")==0)
																{
																	ModuleHasRef4Dflag ++;
																	PartHasRef4Dflag ++;
																}
																else
																{
																	/////////
																	PartHasRef4Dflag ++;
																	//Flag4D=1;
																}
															}
															
															
															if(partcnt4dRef4DDfmea>0)
															{
																for (j3=0;j3<partcnt4dRef4DDfmea;j3++ )
																{
																	printf("\n j3:%d",j3);fflush(stdout);
																	PartRevTag3=PartsTg4dRef4DDfmea[j3];
																	
																	if(AOM_ask_value_string(PartRevTag3,"object_name",&parthasrefdobjname));
																	printf("\n P3:: Now parthasrefdobjname:%s\n",parthasrefdobjname);fflush(stdout);
																	if (First_Ref_flag ==0)
																	{
																		strcat(parthasrefdfemaSet,parthasrefdobjname);
																	}
																	else
																	{
																		strcat(parthasrefdfemaSet,": ");
																		strcat(parthasrefdfemaSet,parthasrefdobjname);
																	}

																	//strcat(parthasrefdfemaSet,parthasrefdobjname);
																	//strcat(parthasrefdfemaSet,",,,,,,,,,,,,,,,,,,,,,,,,");
																	First_Ref_flag++;
																}
															}
															else
															{
																//strcat(parthasrefdfemaSet,"NA");
																//strcat(parthasrefdfemaSet,"; ");
															}
															
														}
													}
												}
											}
										}


										//stamping in report
										printf("\n For task:NOofModules:[%d] ModuleHas4Dflag[%d] TotalPartCount:[%d] PartHas4Dflag:[%d]",NOofModules,ModuleHas4Dflag,TotalPartCount,PartHas4Dflag);fflush(stdout);
									}
									printf("\n in another loops");fflush(stdout);
		
								}
		
							}
							//ModuleHasDFMEAflag
							printf("\n FINAL:TotalPartCount:[%d] PartHas4Dflag[%d] PartHasDFMEAflag:[%d] PartHasRef4Dflag:[%d]\n NOofModules:[%d] ModuleHas4Dflag[%d] ModuleHasDFMEAflag:[%d] ModuleHasRef4Dflag:[%d]",TotalPartCount,PartHas4Dflag,PartHasDFMEAflag,PartHasRef4Dflag,NOofModules,ModuleHas4Dflag,ModuleHasDFMEAflag,ModuleHasRef4Dflag);fflush(stdout);
							printf("\n FIR Request NoOfPartWithTR: %d ",NoOfPartWithTR);fflush(stdout);	
							fprintf(DMLoutput,"%d,%d,%d,%d,%d,%d,%d,%d,",TotalPartCount,PartHas4Dflag,PartHasDFMEAflag,PartHasRef4Dflag,NOofModules,ModuleHas4Dflag,ModuleHasDFMEAflag,ModuleHasRef4Dflag);fflush(DMLoutput);
							// FINAL:NOofModules:[4] ModuleHas4Dflag[0] TotalPartCount:[16] PartHas4Dflag:[0]
					   
							//if(DMLClsuDate !=NULL)
							if (tc_strlen(DMLClsuDate)> 0)
							{
								fprintf(DMLoutput,"%s,",DMLClsuDate);fflush(DMLoutput);
								tc_strcat(DMLtrg,DMLClsuDate);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}

							//if(DMLReason !=NULL)
							if (tc_strlen(DMLReason)> 0)
							{
								printf("\n A33333333333.. \n");fflush(stdout);
								fprintf(DMLoutput,"%s,",DMLReason);fflush(DMLoutput);
								tc_strcat(DMLtrg,DMLReason);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								printf("\n A444444444444.. \n");fflush(stdout);
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}

							//if(Dml_DR !=NULL)
							if (tc_strlen(Dml_DR)> 0)
							{
								printf("\n A111111111111.. \n");fflush(stdout);
								fprintf(DMLoutput,"%s,",Dml_DR);fflush(DMLoutput);
								tc_strcat(DMLtrg,Dml_DR);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								printf("\n A222222.. \n");fflush(stdout);
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}

							//if(sDMLRlsType !=NULL)
							if (tc_strlen(sDMLRlsType)> 0)
							{
								fprintf(DMLoutput,"%s,",sDMLRlsType);fflush(DMLoutput);
								tc_strcat(DMLtrg,sDMLRlsType);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}
				
							//if(DMLManager !=NULL)
							if (tc_strlen(DMLManager)> 0)
							{
								fprintf(DMLoutput,"%s,",DMLManager);fflush(DMLoutput);
								tc_strcat(DMLtrg,DMLManager);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}
							
							//sDMLFrmTOPlnt
							//if(sDMLFrmTOPlnt !=NULL)
							if (tc_strlen(sDMLFrmTOPlnt)> 0)
							{
								printf("\n A1SSS.. \n");fflush(stdout);
								fprintf(DMLoutput,"%s,",sDMLFrmTOPlnt);fflush(DMLoutput);
								tc_strcat(DMLtrg,sDMLFrmTOPlnt);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								printf("\n DSDS.. \n");fflush(stdout);
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}

							//if(sDMLname !=NULL)
							if (tc_strlen(sDMLname)> 0)
							{
								printf("\n DSDS11.. \n");fflush(stdout);
								fprintf(DMLoutput,"%s,",sDMLname);fflush(DMLoutput);
								tc_strcat(DMLtrg,sDMLname);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								printf("\n DSDS2222.. \n");fflush(stdout);
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}
							
							//if(sDMLDesc !=NULL)
							if (tc_strlen(SDMLDesc)> 0)
							{
								printf("\n DSDS333.. \n");fflush(stdout);
								fprintf(DMLoutput,"%s,",SDMLDesc);fflush(DMLoutput);
								tc_strcat(DMLtrg,sDMLDesc);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								printf("\n DSDS44444.. \n");fflush(stdout);
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}

							if (tc_strlen(PartHasDFASet)> 0)
							{
								NO4Dflag++;
								printf("\n PartHasDFASet AA [%s] ",PartHasDFASet);fflush(stdout);
								fprintf(DMLoutput,"%s",PartHasDFASet);fflush(DMLoutput);
							}
							else
							{
								printf("\n PartHasDFASet AAA [%s] ",PartHasDFASet);fflush(stdout);
							}
							if (tc_strlen(PartHasDFMSet)> 0)
							{
								NO4Dflag++;
								printf("\n PartHasDFMSet BB [%s] ",PartHasDFMSet);fflush(stdout);
								fprintf(DMLoutput,"%s",PartHasDFMSet);fflush(DMLoutput);
							}
							else
							{
								printf("\n PartHasDFMSet BBB [%s] ",PartHasDFMSet);fflush(stdout);
							}
							if (tc_strlen(PartHasDFSSet)> 0)
							{
								NO4Dflag++;
								printf("\n PartHasDFSSet CC [%s] ",PartHasDFSSet);fflush(stdout);
								fprintf(DMLoutput,"%s ",PartHasDFSSet);fflush(DMLoutput);
							}
							else
							{
								printf("\n PartHasDFSSet CC [%s] ",PartHasDFSSet);fflush(stdout);
							}
							printf("\n NO4Dflag [%d] ",NO4Dflag);fflush(stdout);
							if (NO4Dflag ==0)
							{
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
							}
							else
							{
								fprintf(DMLoutput,",");fflush(DMLoutput);
							}
							//For DFMEA
							if (tc_strlen(parthasDfmeaSet)> 0)
							{
								NO4Dflag++;
								printf("\n parthasDfmeaSet BB: [%s] ",parthasDfmeaSet);fflush(stdout);
								fprintf(DMLoutput,"%s,",parthasDfmeaSet);fflush(DMLoutput);
							}
							else
							{
								printf("\n parthasDfmeaSet BBB: [%s] ",parthasDfmeaSet);fflush(stdout);
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
							}
							//For Ref DFMEA
							if (tc_strlen(parthasrefdfemaSet)> 0)
							{
								NO4Dflag++;
								printf("\n parthasrefdfemaSet AA: [%s] ",parthasrefdfemaSet);fflush(stdout);
								fprintf(DMLoutput,"%s,",parthasrefdfemaSet);fflush(DMLoutput);
							}
							else
							{
								printf("\n parthasrefdfemaSet AAA: [%s] ",parthasrefdfemaSet);fflush(stdout);
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
							}

							//FIR Request
							
							if (TRcount >0)
							{
								printf("\n No of FIR request AA: [%s] ",NoOfPartWithTR);fflush(stdout);
								fprintf(DMLoutput,"%s,",NoOfPartWithTR);fflush(DMLoutput);
							}
							
							else
							{
								printf("\n No of FIR request AAA: [%s] ",NoOfPartWithTR);fflush(stdout);
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
							}

							//dcrname
							if (DCR_cnt >0)
							{
								
								printf("\n P7: Now DCR name:%s\n",dcrname);fflush(stdout);
								fprintf(DMLoutput,"%s,",dcrname);fflush(DMLoutput);
							}
							else
							{
								fprintf(DMLoutput,"NO,");fflush(DMLoutput);
							}
		
							//business unit 
							//if(sDMLBU !=NULL)
							//if (sDMLBU >0)
							if (tc_strlen(sDMLBU)> 0)
							{
								fprintf(DMLoutput,"%s,",sDMLBU);fflush(DMLoutput);
								tc_strcat(DMLtrg,sDMLBU);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}

							//Vertical
							//if(DMLVertical !=NULL)
							if (tc_strlen(DMLVertical)> 0)
							{
								printf("\n A55555555555.. \n");fflush(stdout);
								fprintf(DMLoutput,"%s,",DMLVertical);fflush(DMLoutput);
								tc_strcat(DMLtrg,DMLVertical);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								printf("\n A6666666666666.. \n");fflush(stdout);
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}

							//DR gateway checklist
							if (DRGatewayFlag >0)
							{
								fprintf(DMLoutput,"YES,");fflush(DMLoutput);
							}
							else
							{
								fprintf(DMLoutput,"NO,");fflush(DMLoutput);
							}

							//DML Target plant sDml_TP
							//if(sDml_TP !=NULL)
							if (tc_strlen(sDml_TP)> 0)
							{
								printf("\n A55555555555.. \n");fflush(stdout);
								fprintf(DMLoutput,"%s,",sDml_TP);fflush(DMLoutput);
								tc_strcat(DMLtrg,sDml_TP);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								printf("\n A6666666666666.. \n");fflush(stdout);
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}

							
							
							//DMLwbs
							if(DMLwbs !=NULL)
							if (tc_strlen(DMLwbs)> 0)
							{
								fprintf(DMLoutput,"%s,",DMLwbs);fflush(DMLoutput);
								tc_strcat(DMLtrg,DMLwbs);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}
							
							//Wbsdescription
							//if(DMLwbsDesc !=NULL)
							if (tc_strlen(DMLwbsDesc)> 0)
							{
								fprintf(DMLoutput,"%s,",DMLwbsDesc);fflush(DMLoutput);
								tc_strcat(DMLtrg,DMLwbsDesc);
								tc_strcat(DMLtrg,",");
							}
							else
							{
								fprintf(DMLoutput,"NA,");fflush(DMLoutput);
								tc_strcat(DMLtrg,"NA");
								tc_strcat(DMLtrg,",");
							}
						}
					}
				}
			}
			if(DMLtrg !=NULL)
			MEM_free(DMLtrg);
		}
		printf("\n For dataset...");fflush(stdout);
		
		if (tc_strlen(DMLDCRPARTComInfo5) >0)
		{
			tc_strcpy(eMailTo,DMLDCRPARTComInfo5);
		}
		if (tc_strlen(DMLDCRPARTComInfo6) >0)
		{
			tc_strcpy(emailCC,DMLDCRPARTComInfo6);
		}
		tc_strcpy(emailBody,"Hello, \n \n    Please find the attach DML/DCR and 4D data details Report.");
		tc_strcat(emailBody,"\n");
		tc_strcat(emailBody,"\n");
		tc_strcat(emailBody,"Thanks & Regards,\n");
		tc_strcat(emailBody,"DML Support Team.");
		tc_strcpy(emailSub,"ERC_Released_DML_4D_Summary_Report");
		printf("\n eMailTo [%s]\n",eMailTo);fflush(stdout);
		printf("\n emailBody [%s]\n",emailBody);fflush(stdout);
		printf("\n emailSub [%s]!!\n",emailSub);fflush(stdout);
		sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -a \"%s\"  -c \"%s\"  \"%s\" ",emailBody,emailSub,DMLoutputFile,emailCC,eMailTo);
		printf("\n buff [%s]!!\n",buff);fflush(stdout);
		system(buff);
		   
	    
		
	}
	printf("\nMemory releaseing.....................................");fflush(stdout);
	if(dmlNumber !=NULL)
		MEM_free(dmlNumber);
	if(sDMLBU !=NULL)
		MEM_free(sDMLBU);
	if(DMLRlsType !=NULL)
		MEM_free(DMLRlsType);
	if(person_name !=NULL)
		MEM_free(person_name);
	if(Dml_DR !=NULL)
		MEM_free(Dml_DR);
	if(DMLReason !=NULL)
		MEM_free(DMLReason);
	if(DMLVertical !=NULL)
		MEM_free(DMLVertical);
	if(DMLManager !=NULL)
		MEM_free(DMLManager);
	if(ProjectID !=NULL)
		MEM_free(ProjectID);
	fclose(DMLoutput);

	printf("\n DML details collection end........");fflush(stdout);
	return ifail;
}
