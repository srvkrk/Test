//gsoap ns service name:                         PalmSysToTcua
//gsoap ns service style:                        rpc
//gsoap ns service namespace:                    urn:PalmSysToTcua
//gsoap ns service location:                     http://172.22.99.106:9080/cgi/PalmSysToTcua.cgi
//gsoap ns service encoding:                     encoded
//gsoap ns schema namespace:                     urn:PalmSysToTcua
//gsoap ns service method-documentation: Tests the Simple Web service

struct ns__getPalmSysToTcuaResponse {
    char *Flag;
    char *response;
};
int ns__getPalmSysToTcua(char *operation,   char *MostFrequency,
											char *MostDiv,
											char *MostMen,
											char *MostOnOff,
											char *CT,
											char *CW,
											struct ns__getPalmSysToTcuaResponse *out);

