/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2023  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: ModuleInfoReport.c
* Description	: This Utility Mainly Used For AutoLogin in Teamcenter
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change
* 22.05.2024            Saurabh Yadav            DateWiseVehicleReport

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>

#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <tc/folder.h>

#define MAX_LINE_LEN 10024
#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
FILE *Report = NULL;
int ctr=0;

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

static int report_error(char *file, int line, char *call, int status,
    logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int
            n_errors = 0;
        const int
            *severities = NULL,
            *statuses = NULL;
        const char
            **messages;

        EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
        if (n_errors > 0)
        {
            ECHO("\n%s\n", messages[n_errors-1]);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            EMH_get_error_string (NULLTAG, status, &error_message_string);
            ECHO("\n%s\n", error_message_string);
        }

        ECHO("error %d at line %d in %s\n", status, line, file);
        ECHO("%s\n", call);
        if (exit_on_error)
        {
            ECHO("%s", "Exiting program!\n");
            exit (status);
        }
    }
    return status;
}


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

// Function to check if a character is printable
int isPrintable(char ch) {
    return ch >= 32 && ch <= 126;
}

// Function to remove non-ASCII, non-printable, and special characters from string
void removeNonAsciiChars(char *str) {
    int i = 0;
    char ch;
    while ((ch = str[i]) != '\0') {
        if (!isPrintable(ch))
        {
            str[i] = ' ';
        }
        i++;
    }
}



int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y_%H_%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%m_%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}


void tm_find_Prev_Official_Rev(char	*req_item,tag_t t_currentRevision, tag_t* t_previousRevision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		PreRevFlag 			=	0;
	int		ii					=	0;
	int		n_tags_found		=	0;

	char	*Part_Rev			=	NULL;
	char	*Part_Rev_copy		=	NULL;
	char	*Part_rev_Id		=	NULL;
	char	*RevOnly			=	NULL;
	char	*PreRevOnly			=	NULL;
	char	*Part_prev_rev_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;

	printf("\ntm_fnd_prev_revision called : %s",req_item);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev_copy));
	printf("\n Part_Rev_copy: %s\n",Part_Rev_copy);fflush(stdout);

	//ITKCALL(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
	ITKCALL(AOM_ask_value_tags(t_currentRevision,"revision_list",&Item_count,&rev_list));
	printf("\nNo of Item : %d",Item_count);fflush(stdout);

	if(Item_count > 0)
	{
		RevFlag		=	0;
		PreRevFlag	=	0;

		for(ii=Item_count-1;ii>=0;ii--)
		{
			RevOnly		=	NULL;
			PreRevOnly	=	NULL;

			ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

			printf("\nPart_Rev %s and Part_rev_Id: %s\n",Part_Rev,Part_rev_Id);fflush(stdout);
			if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
			{
				RevFlag = 1;
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			if(RevFlag == 1)
			{
				RevOnly		= strtok( Part_Rev_copy, ";" );
				PreRevOnly	= strtok( Part_rev_Id, ";" );
				printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
				printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
				if(tc_strcmp(RevOnly,PreRevOnly)!=0)
				{
					PreRevFlag = 1;

				}
				if(PreRevFlag == 1)
				{
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_prev_rev_Id));
					printf("\n Part_prev_rev_Id: %s\n",Part_prev_rev_Id);fflush(stdout);
					*t_previousRevision	=	rev_list[ii];
					break;
				}
			}
		}
		if(PreRevFlag == 0)
		{
			*t_previousRevision	=	t_currentRevision;
		}
	}
}


void tm_find_DR4_Rev(tag_t t_currentRevision, tag_t* t_first_DR4_Revision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		PreRevFlag 			=	0;
	int		iii					=	0;
	int		n_tags_found		=	0;

	
	
	char	*PreRevOnly			=	NULL;
	char	*Part_prev_rev_Id	=	NULL;
	char	*DR_Part_value	=	NULL;
	char	*Part_DR_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	master		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;

	
	
	ITKCALL(AOM_ask_value_string(t_currentRevision,"t5_PartStatus",&DR_Part_value));
	printf("\n DR_Part_value %s\n",DR_Part_value);fflush(stdout);
	
	ITEM_ask_item_of_rev(t_currentRevision, &master);
	
	ITKCALL(ITEM_list_all_revs (master, &Item_count, &rev_list));
	
	if(Item_count > 0)
	{
		for(iii=0;iii<Item_count;iii++)
		{
			
			AOM_ask_value_string(rev_list[iii],"t5_PartStatus",&Part_DR_Id);
			
			if(tc_strcmp(Part_DR_Id,"DR4")==0)
			{
				RevFlag = 1;
				
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			
		
		if(RevFlag == 1)
		{
			AOM_ask_value_string(rev_list[iii],"item_revision_id",&Part_prev_rev_Id);
			printf("\n Part_prev_rev_Id: %s\n",Part_prev_rev_Id);fflush(stdout);
			*t_first_DR4_Revision	=	rev_list[iii];
			break;
		}
		}
		
	}
}





int ITK_user_main(int argc, char* argv[])
{
    char* cError = NULL;
	char*  F_date = ITK_ask_cli_argument("-F=");
	char*  T_date = ITK_ask_cli_argument("-T=");
	
	char*   From_date = NULL;
	char*   To_date = NULL;
	int ifail = ITK_ok;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	if(ITK_auto_login() == ITK_ok)	
	{
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		char Data[100] = "";

	//	Report=fopen("/user/cvprod/suryansh/DateWiseVehicleReport/VCDateWiseReport.xml","w");
		Report=fopen("/tmp/VCDateWiseReport_New.xml","w");
		if (Report == NULL)
		{
			printf("ERROR: XML Cannot open File\n");
			return -1;
		}
		else
		{
			printf("XML File opened successfully.\n");
		}

		strftime(Data,100,"%d-%m-%Y %H:%M:%S",&when);
		write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		write2xml(Report,"\n<PLMXML date=\"");
		write2xml(Report,Data);
		write2xml(Report,"\" >\n");

		tag_t itemrev = NULLTAG;
		int  rows = 0, i = 0;
		tag_t* itemobj_results = NULLTAG;
		int FieldCount = 2;
		tag_t ItemObjs = NULLTAG;
		tag_t TagClassId = NULLTAG;
		char *ObjClassName=NULL;
		tag_t GCI_relation_tag = NULLTAG;
		tag_t Vc_spec_relation_type = NULLTAG;
		
		//char *FieldList[2]  = {"Part Type","Type"};
		char **FieldVaule = (char **) MEM_alloc(50 * sizeof(char *));
		
		From_date = (char *) MEM_alloc(100);
		To_date = (char *) MEM_alloc(100);
		
		
		
		tc_strcpy(From_date,"");
		tc_strcpy(From_date,F_date);
		tc_strcat(From_date," 00:00");
		
		
		tc_strcpy(To_date,"");
		tc_strcpy(To_date,T_date);
		tc_strcat(To_date," 23:59");
		printf("\n\n\n\n\nFrom date [%s] \n To Date [%s]",From_date,To_date);fflush(stdout);
		
		
		char    	*FieldList[4]	= {"ID","Name","date_released_after","date_released_before"};	
		//char		**qryvalue= (char **) MEM_alloc(500 * sizeof(char *));
		ITK_CALL(QRY_find("ERCDMLReleased",&ItemObjs));
		
		
	
		if (ItemObjs)
		{
			printf("\nFound Query_for_Report\n");fflush(stdout);
		}
		else
		{
			printf("\n-----------Not Found Query_for_Module_Info_Report\n");fflush(stdout);
		}

		//FieldVaule[0] = "M";
		//FieldVaule[1] = "Design Revision";
		printf("Before Query Execute"); fflush(stdout);
		//if (QRY_execute(ItemObjs, FieldCount, FieldList, FieldVaule, &rows, &itemobj_results) != ITK_ok) PrintErrorStack();
		
		FieldVaule[0]="*";
		FieldVaule[1]="T5_LcsErcRlzd"; //ERC Released
		FieldVaule[2]=From_date;
		FieldVaule[3]=To_date;
		ITK_CALL(QRY_execute(ItemObjs,4, FieldList, FieldVaule, &rows, &itemobj_results));
		if (rows != 0)
		{
			printf("\n Total DML : %d",rows); fflush(stdout);
			for(i=0;i<rows;i++)
			{
				printf("\n entering into loop of i");
				itemrev=itemobj_results[i];
				
			if(POM_class_of_instance(itemrev,&TagClassId));
			if(POM_name_of_class(TagClassId,&ObjClassName));
			if (tc_strcmp(ObjClassName,"ChangeRequestRevision")==0)
			{
				
				char*  DML_Release_Type =NULL;
				int p,cnt = 0;
				tag_t *Dml_tasks= NULLTAG;
				tag_t DMLToTaskReln = NULLTAG;

				char*	first_DR4_rev=	NULL;
				char*	first_DR4_rev_f=	NULL;
				char*	first_DR4_rev_f1=	NULL;
				char*	prev_rev_DR_status=	NULL;
				char*	prev_rev_DR_status_f=	NULL;
				char*	prev_rev_DR_status_f1=	NULL;
				char*	prev_rev_DR_status_dup=	NULL;
				char*	prev_rev_DR_status_dup_f=	NULL;
				char*	prev_rev_DR_status_dup_f1=	NULL;
				char*	first_DR4_rev_dup=	NULL;
				char*	first_DR4_rev_dup_f=	NULL;
				char*	first_DR4_rev_dup_f1=	NULL;
				
				prev_rev_DR_status_dup_f=(char *)MEM_alloc(500);
				first_DR4_rev_dup_f=(char *)MEM_alloc(500);
				
				prev_rev_DR_status_dup_f1 = (char *) MEM_alloc(500);
				first_DR4_rev_dup_f1 = (char *) MEM_alloc(500);

				ITK_CALL(AOM_UIF_ask_value(itemrev,"t5_rlstype",&DML_Release_Type));
	
				//if((tc_strcmp(DML_Release_Type,"Veh")==0) || (tc_strcmp(DML_Release_Type,"XO")==0) || (tc_strcmp(DML_Release_Type,"CP")==0) || (tc_strcmp(DML_Release_Type,"VCMDU")==0))
				if((tc_strcmp(DML_Release_Type,"Vehicle Release")==0) || (tc_strcmp(DML_Release_Type,"Gate Maturation")==0))
				{
				
				GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskReln);	
				GRM_list_secondary_objects_only(itemrev,DMLToTaskReln,&cnt,&Dml_tasks);
				printf("\n Now cnt: %d\n",cnt);fflush(stdout);
				
				
			if (cnt>0)
			{
			for (p=0;p<cnt;p++)
			{
				int k,partcnt,change_partcnt,r =0;
				tag_t *PartsTag= NULLTAG;
				tag_t *change_PartsTag= NULLTAG;
				tag_t PartTag= NULLTAG;
				tag_t change_AssyTag= NULLTAG;
				char*	object_type	=NULL;
				char*	Prt_object_type =NULL;
				
				AOM_ask_value_string(Dml_tasks[p],"object_type",&object_type);
				printf("\n object_type is :%s\n",object_type);fflush(stdout);
				if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
						
			if(tc_strcmp(DML_Release_Type,"Gate Maturation")==0)
			{
				AOM_ask_value_tags(Dml_tasks[p],"CMReferences",&change_partcnt,&change_PartsTag);
				printf("\n Now change_partcnt:%d\n",change_partcnt);fflush(stdout);
				if(change_partcnt> 0)
				{
					for(r=0;r<change_partcnt;r++)
					{
						char*  item_id_f =NULL;
						char*  item_id_f1 =NULL;
						char*  parttype =NULL;
						char*  parttype_f =NULL;
						char*  item_revision_id_f =NULL;
						char*  item_revision_id_f1 =NULL;
						char*  DR_status_f =NULL;
						char*  DR_status_f_Dup =NULL;
						char*  DR_status_f1 =NULL;
						char*  desc_f =NULL;
						char*  desc_f1 =NULL;
						char*  color_ind_f =NULL;
						char*  color_ind_f1 =NULL;
						char*  DR_status_f1_Dup =NULL;
						
						tag_t prevoffRev_tag_f= NULLTAG;
						tag_t prevoffRev_tag_f1= NULLTAG;
						tag_t DR4Rev_tag_f= NULLTAG;
						tag_t DR4Rev_tag_f1= NULLTAG;
						
						tag_t iteamrev2 = NULLTAG;
					
						change_AssyTag=change_PartsTag[r];
						AOM_ask_value_string(change_AssyTag,"object_type",&Prt_object_type);
						printf("\n for CM refrences object_type is :%s \n",Prt_object_type);fflush(stdout);
					if(tc_strcmp(Prt_object_type,"Folder")==0)
					{
							char* FldrName =NULL;
							AOM_ask_value_string(change_AssyTag,"object_name",&FldrName);
							printf("\n for FldrName is:: %s \n", FldrName);fflush(stdout);
							if(tc_strcmp(FldrName,"Parts For Gate Maturation")==0)
							{
								printf("\n Inside folder found \n");fflush(stdout);
								int FlderSize=0;
								if(FL_ask_size(change_AssyTag,&FlderSize));
								printf("\n FlderSize is:   %d \n",FlderSize);fflush(stdout);
								int FlderObjCount=0;
								tag_t* FolderObj_tag=NULL;
								if(FL_ask_references(change_AssyTag,FL_fsc_by_date_modified,&FlderObjCount,&FolderObj_tag));
								printf("\n  FlderObjCount is..:   %d \n",FlderObjCount);fflush(stdout);
								if(FlderObjCount>0)
								{
									int fld=0;
									for (fld=0;fld<FlderObjCount;fld++)
									{
										iteamrev2 = FolderObj_tag[fld];
										
										ITK_CALL(AOM_ask_value_string(iteamrev2, "t5_PartType", &parttype_f)) ;
										printf ( "\nPart type_f : [%s]", parttype_f );fflush(stdout);
									if((tc_strcmp(parttype_f,"V")==0) || (tc_strcmp(parttype_f,"VCCR")==0) || (tc_strcmp(parttype_f,"VC")==0))
									{
										AOM_ask_value_string(iteamrev2,"item_id",&item_id_f);
										AOM_ask_value_string(iteamrev2,"item_revision_id",&item_revision_id_f);
										AOM_ask_value_string(iteamrev2,"t5_PartStatus",&DR_status_f);
										
										if(tc_strlen(DR_status_f)>0)
										{
											tc_strdup(DR_status_f,&DR_status_f_Dup);
										}
										
										else
										{
											tc_strdup("NA",&DR_status_f_Dup);
											printf("\n DR ST is  NULL..!!");fflush(stdout);
										}
										
										AOM_ask_value_string(iteamrev2,"t5_ColourInd",&color_ind_f);
										AOM_ask_value_string(iteamrev2,"object_desc",&desc_f);
										
										
										printf("\n item_id  is :%s\n",item_id_f);	fflush(stdout);
										printf("\n Revision_id  is :%s\n",item_revision_id_f);fflush(stdout);
										printf("\n DR_status is :%s\n",DR_status_f);fflush(stdout);
										printf("\n color_ind :%s\n",color_ind_f);fflush(stdout);
										printf("\n object_desc :%s\n",desc_f);fflush(stdout);
				
								tm_find_Prev_Official_Rev(item_id_f,iteamrev2,&prevoffRev_tag_f);
								if(prevoffRev_tag_f!=NULLTAG)
								{
								//	char	*prev_rev_DR_status=	NULL;

								printf("\nPrevious official Revision found \n");fflush(stdout);
								
								AOM_ask_value_string(prevoffRev_tag_f,"t5_PartStatus",&prev_rev_DR_status_f);
								printf("\n previous_revision_DR_status_f is  :%s\n",prev_rev_DR_status_f);fflush(stdout);
								
								tc_strcpy(prev_rev_DR_status_dup_f,prev_rev_DR_status_f);
								printf("\n prev_rev_DR_status_dup_f is  :%s\n",prev_rev_DR_status_dup_f);fflush(stdout);
								}
								
								else{
									
									printf("\n under else of previous_revision_DR_status is\n");fflush(stdout);
									tc_strcpy(prev_rev_DR_status_dup_f,"NA");
									printf("\n previous_revision_DR_status is  :%s\n",prev_rev_DR_status_dup_f);fflush(stdout);
								}
								
								tm_find_DR4_Rev(iteamrev2,&DR4Rev_tag_f);
										
								if(DR4Rev_tag_f!=NULLTAG)
								{
								//	char	*first_DR4_rev=	NULL;
									AOM_ask_value_string(DR4Rev_tag_f,"item_revision_id",&first_DR4_rev_f);
								//	printf("\n 11111111111first_rev_DR_id  :%s\n",first_DR4_rev);fflush(stdout);
									
									tc_strcpy(first_DR4_rev_dup_f,first_DR4_rev_f);
									printf("\n 2222222222first_DR4_rev_dup  :%s\n",first_DR4_rev_dup_f);fflush(stdout);
								}
								else{
									
									printf("\n under else of first DR4 revsiion");fflush(stdout);
									tc_strcpy(first_DR4_rev_dup_f,"NA");
									printf("\n first_DR4_rev_dup_f  :%s\n",first_DR4_rev_dup_f);fflush(stdout);
								}
								
						//	char *slNo=(char *) MEM_alloc(200);
						//	sprintf(slNo,"%d",(i+1));

							write2xml(Report,"<DesignRevision>\n");
						//	write2xml(Report,"<field key =\"slNo\">");
						//	write2xml(Report,slNo);
						//	write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"item_id\">");
							write2xml(Report,item_id_f);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"desc\">"); if(desc_f != NULL) write2xml(Report,desc_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"item_revision_id\">"); write2xml(Report,item_revision_id_f); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"color_ind\">"); if(color_ind_f != NULL) write2xml(Report,color_ind_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DR_status\">"); if(DR_status_f_Dup != NULL) write2xml(Report,DR_status_f_Dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"prev_rev_DR_status_dup\">"); if(prev_rev_DR_status_dup_f != NULL) write2xml(Report,prev_rev_DR_status_dup_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"first_DR4_rev_dup\">"); if(first_DR4_rev_dup_f != NULL) write2xml(Report,first_DR4_rev_dup_f); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"</DesignRevision>\n");
						}			
						}
						}
						}
					}
					else{
							ITK_CALL(AOM_ask_value_string(change_AssyTag, "t5_PartType", &parttype)) ;
							printf("\nPart type : [%s]", parttype );fflush(stdout);
							if((tc_strcmp(parttype,"V")==0) || (tc_strcmp(parttype,"VCCR")==0) || (tc_strcmp(parttype,"VC")==0))
							{
							
							AOM_ask_value_string(change_AssyTag,"item_id",&item_id_f1);
							AOM_ask_value_string(change_AssyTag,"item_revision_id",&item_revision_id_f1);
							AOM_ask_value_string(change_AssyTag,"t5_PartStatus",&DR_status_f1);

							if(tc_strlen(DR_status_f1)>0)
							{
								tc_strdup(DR_status_f1,&DR_status_f1_Dup);
							}
							
							else
							{
								tc_strdup("NA",&DR_status_f1_Dup);
								printf("\n DR ST is  NULL..!!");fflush(stdout);
							}
							AOM_ask_value_string(change_AssyTag,"t5_ColourInd",&color_ind_f1);
							AOM_ask_value_string(change_AssyTag,"object_desc",&desc_f1);
							
							
							printf("\n item_id_f1  is :%s\n",item_id_f1);fflush(stdout);
							printf("\n item_revision_id_f1  is :%s\n",item_revision_id_f1);fflush(stdout);
							printf("\n DR_status_f1 is :%s\n",DR_status_f1);fflush(stdout);
							printf("\n color_ind_f1 :%s\n",color_ind_f1);fflush(stdout);
							printf("\n desc_f1 :%s\n",desc_f1);fflush(stdout);
							
							printf("\n enetring into tm_find_Prev_Official_Rev function\n");fflush(stdout);
							
							tm_find_Prev_Official_Rev(item_id_f1,change_AssyTag,&prevoffRev_tag_f1);
							if(prevoffRev_tag_f1!=NULLTAG)
							{
							//	char	*prev_rev_DR_status=	NULL;

							printf("\nPrevious official Revision found \n");fflush(stdout);
							
							AOM_ask_value_string(prevoffRev_tag_f1,"t5_PartStatus",&prev_rev_DR_status_f1);
							printf("\n previous_revision_DR_status_f1 is  :%s\n",prev_rev_DR_status_f1);fflush(stdout);
							
							tc_strcpy(prev_rev_DR_status_dup_f1,prev_rev_DR_status_f1);
							printf("\n prev_rev_DR_status_dup_f1 is  :%s\n",prev_rev_DR_status_dup_f1);fflush(stdout);
							}
							
							else{
								
								printf("\n under else of previous_revision_DR_status is\n");
								tc_strcpy(prev_rev_DR_status_dup_f1,"NA");
								printf("\n previous_revision_DR_status is  :%s\n",prev_rev_DR_status_dup_f1);fflush(stdout);
							}
							
							printf("\n enetring into tm_find_DR4_Rev function\n");fflush(stdout);
							tm_find_DR4_Rev(change_AssyTag,&DR4Rev_tag_f1);
									
							if(DR4Rev_tag_f1!=NULLTAG)
							{
							//	char	*first_DR4_rev=	NULL;
								AOM_ask_value_string(DR4Rev_tag_f1,"item_revision_id",&first_DR4_rev_f1);
							//	printf("\n 11111111111first_rev_DR_id  :%s\n",first_DR4_rev);fflush(stdout);
								
								tc_strcpy(first_DR4_rev_dup_f1,first_DR4_rev_f1);
								printf("\n 2222222222first_DR4_rev_dup_f1  :%s\n",first_DR4_rev_dup_f1);fflush(stdout);
							}
							else{
								
								printf("\n under else of first DR4 revsiion");
								tc_strcpy(first_DR4_rev_dup_f1,"NA");
								printf("\n first_DR4_rev_dup_f1  :%s\n",first_DR4_rev_dup_f1);fflush(stdout);
							}
						//	char *slNo_f=(char *) MEM_alloc(200);
						//	sprintf(slNo_f,"%d",(i+1));

							write2xml(Report,"<DesignRevision>\n");
						//	write2xml(Report,"<field key =\"slNo\">");
						//	write2xml(Report,slNo_f);
						//	write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"item_id\">");
							write2xml(Report,item_id_f1);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"desc\">"); if(desc_f1 != NULL) write2xml(Report,desc_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"item_revision_id\">"); write2xml(Report,item_revision_id_f1); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"color_ind\">"); if(color_ind_f1 != NULL) write2xml(Report,color_ind_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DR_status\">"); if(DR_status_f1_Dup != NULL) write2xml(Report,DR_status_f1_Dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"prev_rev_DR_status_dup\">"); if(prev_rev_DR_status_dup_f1 != NULL) write2xml(Report,prev_rev_DR_status_dup_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"first_DR4_rev_dup\">"); if(first_DR4_rev_dup_f1 != NULL) write2xml(Report,first_DR4_rev_dup_f1); else write2xml(Report,""); write2xml(Report,"</field>\n");	
							write2xml(Report,"</DesignRevision>\n");
					}
					else
					{
						printf("\n VC not found in change refrence\n");fflush(stdout);
					}
					}
					}
				}
			}
			else if(tc_strcmp(DML_Release_Type,"Vehicle Release")==0)				
		//	if(tc_strcmp(DML_Release_Type,"Vehicle Release")==0)				
			{
						
			AOM_ask_value_tags(Dml_tasks[p],"CMHasSolutionItem",&partcnt,&PartsTag);
			printf("\n Now partcnt:%d\n",partcnt);fflush(stdout);
			if (partcnt>0)
			{
				for(k=0;k<partcnt;k++)
				{
					char*  parttype3 =NULL;
					PartTag=PartsTag[k];
					
					ITK_CALL(AOM_ask_value_string(PartTag, "t5_PartType", &parttype3)) ;
					printf ( "\nPart type_f : [%s]", parttype3 );fflush(stdout);
					if((tc_strcmp(parttype3,"V")==0) || (tc_strcmp(parttype3,"VCCR")==0) || (tc_strcmp(parttype3,"VC")==0))
					{
					char*  item_id =NULL;
					char*  item_revision_id =NULL;
					char*  DR_status =NULL;
					char*  desc =NULL;
					char*  color_ind =NULL;
					char*  platform =NULL;
					char*  platform_Dup =NULL;
					char*  rolledupwt =NULL;
					char*  t5_BOMCompl =NULL;
					tag_t prevoffRev_tag= NULLTAG;
					tag_t	DR4Rev_tag = NULLTAG;
					
					int ii =0;
					
					prev_rev_DR_status_dup =(char *)MEM_alloc(500);
					first_DR4_rev_dup =(char *)MEM_alloc(500);
					
				
					AOM_ask_value_string(PartTag,"item_id",&item_id);
					AOM_ask_value_string(PartTag,"item_revision_id",&item_revision_id);
					AOM_ask_value_string(PartTag,"t5_PartStatus",&DR_status);
					AOM_ask_value_string(PartTag,"t5_ColourInd",&color_ind);
					AOM_ask_value_string(PartTag,"object_desc",&desc);
					
					printf("\n item_id  is :%s\n",item_id);	fflush(stdout);
					printf("\n Revision_id  is :%s\n",item_revision_id);fflush(stdout);
					printf("\n DR_status is :%s\n",DR_status);fflush(stdout);
					printf("\n color_ind :%s\n",color_ind);fflush(stdout);
					printf("\n object_desc :%s\n",desc);fflush(stdout);
					
					
					tm_find_Prev_Official_Rev(item_id,PartTag,&prevoffRev_tag);
					if(prevoffRev_tag!=NULLTAG)
					{
					//	char	*prev_rev_DR_status=	NULL;

					printf("\nPrevious official Revision found \n");fflush(stdout);
					
					AOM_ask_value_string(prevoffRev_tag,"t5_PartStatus",&prev_rev_DR_status);
					printf("\n previous_revision_DR_status is  :%s\n",prev_rev_DR_status);fflush(stdout);
					
					tc_strcpy(prev_rev_DR_status_dup,prev_rev_DR_status);
					printf("\n previous_revision_DR_status is  :%s\n",prev_rev_DR_status_dup);fflush(stdout);
					}
					
					else{
						
						printf("\n under else of previous_revision_DR_status is\n");fflush(stdout);
						tc_strcpy(prev_rev_DR_status_dup,"NA");
						printf("\n previous_revision_DR_status is  :%s\n",prev_rev_DR_status_dup);fflush(stdout);
					}
						
					tm_find_DR4_Rev(PartTag,&DR4Rev_tag);
					
					if(DR4Rev_tag!=NULLTAG)
					{
					//	char	*first_DR4_rev=	NULL;
						AOM_ask_value_string(DR4Rev_tag,"item_revision_id",&first_DR4_rev);
					//	printf("\n 11111111111first_rev_DR_id  :%s\n",first_DR4_rev);fflush(stdout);
						
						tc_strcpy(first_DR4_rev_dup,first_DR4_rev);
						printf("\n 2222222222first_DR4_rev_dup  :%s\n",first_DR4_rev_dup);fflush(stdout);
					}
					else{
						
						printf("\n under else of first DR4 revsiion");fflush(stdout);
						tc_strcpy(first_DR4_rev_dup,"NA");
						printf("\n first_DR4_rev_dup  :%s\n",first_DR4_rev_dup);fflush(stdout);
					}
					
					
				//	}
					
				
					
					//char *t5_DR_status = NULL;
					//char *t5_color_ind = NULL;
					char *t5_desc = NULL;
				
					char *t5_prev_rev_DR_status = NULL;
					char *t5_first_DR4_rev = NULL;
					
					//if(DR_status != NULL) STRNG_replace_str(DR_status,"&","&amp;",&t5_DR_status);
					//if(color_ind != NULL) STRNG_replace_str(color_ind,"&","&amp;",&t5_color_ind);
					if(desc != NULL) STRNG_replace_str(desc,"&","&amp;",&t5_desc);
				//	if(platform != NULL) STRNG_replace_str(platform,"&","&amp;",&t5_platform);
				//	if(rolledupwt != NULL) STRNG_replace_str(rolledupwt,"&","&amp;",&t5_rolledupwt);
				//	if(DML_DR_Status != NULL) STRNG_replace_str(DML_DR_Status,"&","&amp;",&t5_DML_DR_Status);
				//	if(prev_rev_DR_status != NULL) STRNG_replace_str(prev_rev_DR_status,"&","&amp;",&t5_prev_rev_DR_status);
				//	if(first_DR4_rev != NULL) STRNG_replace_str(first_DR4_rev,"&","&amp;",&t5_first_DR4_rev);
				//	if(DML_synopsis != NULL) STRNG_replace_str(DML_synopsis,"&","&amp;",&t5_DML_synopsis);
				//	if(DML_reasoncode != NULL) STRNG_replace_str(DML_reasoncode,"&","&amp;",&t5_DML_reasoncode);
				//	if(dml_type_dup != NULL) STRNG_replace_str(dml_type_dup,"&","&amp;",&t5_dml_type_dup);
				//	if(dmlProj != NULL) STRNG_replace_str(dmlProj,"&","&amp;",&t5_dmlProj);
				//	if(DML_from_to != NULL) STRNG_replace_str(DML_from_to,"&","&amp;",&t5_DML_from_to);
				//	if(t5_BOMCompl != NULL) STRNG_replace_str(t5_BOMCompl,"&","&amp;",&t5_BOMCompl_val);
				//	if(proj_des != NULL) STRNG_replace_str(proj_des,"&","&amp;",&t5_proj_des);
					
					
					
				//	char *slNo=(char *) MEM_alloc(200);
				//	sprintf(slNo,"%d",(i+1));

					write2xml(Report,"<DesignRevision>\n");
				//	write2xml(Report,"<field key =\"slNo\">");
				//	write2xml(Report,slNo);
				//	write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"item_id\">");
					write2xml(Report,item_id);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"desc\">"); if(t5_desc != NULL) write2xml(Report,t5_desc); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"item_revision_id\">"); write2xml(Report,item_revision_id); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"color_ind\">"); if(color_ind != NULL) write2xml(Report,color_ind); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"DR_status\">"); if(DR_status != NULL) write2xml(Report,DR_status); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"prev_rev_DR_status_dup\">"); if(prev_rev_DR_status_dup != NULL) write2xml(Report,prev_rev_DR_status_dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"first_DR4_rev_dup\">"); if(first_DR4_rev_dup != NULL) write2xml(Report,first_DR4_rev_dup); else write2xml(Report,""); write2xml(Report,"</field>\n");
					write2xml(Report,"</DesignRevision>\n");

			//	}
			//	}
			//	}
			//	}
				}
			}
			}
							//	}
						}
					}
				}
				
			}
				printf("\n out of the DML \n");
			}
				
			}
		}
		write2xml(Report,"</PLMXML>\n");
		fclose(Report);
		
		printf("\n report is generted\n");

		ifail = ITK_exit_module(TRUE);
		if (ifail == ITK_ok)
		{
			printf("\nTeamcenter Logout Success...");fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(ifail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
	}
	return ITK_ok;
}


