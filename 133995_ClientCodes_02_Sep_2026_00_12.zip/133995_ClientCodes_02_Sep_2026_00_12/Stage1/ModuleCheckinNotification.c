#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <ps/ps.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tccore/tctype.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <sa/user.h>



#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define PROP_set_value_string_msg   "PROP_set_value_string"

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

FILE            *output                         = NULL;
int                     ifail                           = ITK_ok;
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
         int                            index                           = 0;
         int                            n_ifails                        = 0;
         const int*                     severities                      = 0;
         const int*                     ifails                          = 0;
         const char**           texts                           = NULL;

         EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
         printf("%3d error(s)\n", n_ifails);
         for( index=0; index<n_ifails; index++)
         {
              printf("ERROR: %d\tERROR MSG: [%s]\n", ifails[index], texts[index]);
              TC_write_syslog("ERROR: %d\tERROR MSG: [%s]\n", ifails[index], texts[index]);
              printf ("FUNCTION: [%s]\nFILE: [%s] LINE: %d\n\n", function, file, line);
              TC_write_syslog("FUNCTION: [%s]\nFILE: [%s] LINE: %d\n", function, file, line);
         }
         EMH_clear_errors();
    }
    return return_code;
}
int Mail_Notification(char*,char*,char*);
int read_value_from_file(char*,char*,char*,char*);
void print_requirement()
{
        printf(
        "\nHELP:\n"
        "parameter_creation -u=<username> -pf=<password file path> -g=<group> -file=<input filename>\n"
        "-------------------------------------------------------------------------------------------\n\n"
        );
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
                                        It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
        char                    * userid                                        = NULL;
        char                    * password                                      = NULL;
        char                    * group                                         = NULL;        
		char                    * Submodule                                     = NULL;
		char                    * Revseq                                     = NULL;
        char                    * id                                     = NULL;


        userid                  = ITK_ask_cli_argument("-u=");
        password                = ITK_ask_cli_argument("-pf=");
        group                   = ITK_ask_cli_argument("-g=");       
		Submodule               = ITK_ask_cli_argument("-SM=");
		Revseq                       = ITK_ask_cli_argument("-R=");
		id                       = ITK_ask_cli_argument("-id=");

        if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Submodule)) == 0)
        {
                print_requirement();
                return -1;
        }

        ifail = ITK_auto_login();
        //ifail = ITK_init_module(userid, password, group);

        if (ifail != ITK_ok)
        {
                printf("Error in Login to Teamcenter\n");
                return ifail;
        }
        else
		{
				printf("\nLogin Successfull.....!!\n");
				printf("\nWelcome to Teamcenter.....!!\n");
				printf("\n\t Submodule => %s*****\n",Submodule);fflush(stdout);
				printf("\n\t Revseq => %s*****\n",Revseq);fflush(stdout);
				printf("\n\t id => %s*****\n",id);fflush(stdout);

				printf("\n**START : Abort workflow on IR Objects from Previous revisions**"); fflush(stdout);
				int dsgnRevIRCnt = 0;
				int irDsgn = 0;
				int cc = 0;
				int chklistct = 0;
				int refcnt =0;
				int cheklistdatacnt =0;
				char *revSrc = (char *)MEM_alloc(50);
				char *RevSeqMatch = (char *)MEM_alloc(50);
				char* DsgnRev = NULL;
				char* DsgnSeq = NULL;
				char* itemIDDsgn = NULL;
				char* revIDDsgn = NULL;
				char* DsgnRevSeq = NULL;
				tag_t qryTagDsgnRevIR = NULLTAG;
				tag_t dsgnRevIRTag = NULLTAG;
				tag_t cheklistdata = NULLTAG;
				tag_t* dsgnRevIRTags = NULLTAG;
				tag_t* 	chklistsobjtag	= NULLTAG;
				tag_t* cheklistdatastag = NULLTAG;
				tag_t	chklistobjtag 	= NULLTAG;
				tag_t	chklistobjreltyp 	= NULLTAG;
				tag_t cheklistdatareltyp = NULLTAG;
				char* chklistObjType = NULLTAG;
				tag_t chklistobjeTypTag = NULLTAG;
				ITK_CALL(GRM_find_relation_type("IMAN_reference",&chklistobjreltyp));

				tc_strcpy(revSrc,"");
				tc_strcpy(RevSeqMatch,"");
				tc_strdup(Revseq,&DsgnRevSeq);
				DsgnRev = tc_strtok(DsgnRevSeq,"_");
				DsgnSeq = tc_strtok(NULL,"_");
				tc_strcpy(revSrc,DsgnRev);
				tc_strcat(revSrc,"*");
				tc_strcpy(RevSeqMatch,DsgnRev);
				tc_strcat(RevSeqMatch,";");
				tc_strcat(RevSeqMatch,DsgnSeq);
				printf("\nLatest Checkin Revision: %s --> Search for: -%s-%s-*** %s ***",Revseq,Submodule,revSrc,RevSeqMatch); fflush(stdout);
				ITK_CALL(QRY_find2("Design Revision",&qryTagDsgnRevIR));
				if (qryTagDsgnRevIR)
				{
					char *qryentIR[2] = {"ID","Revision"};
					char **qryvalIR = (char **) MEM_alloc(2 * sizeof(char *));
					qryvalIR[0] = Submodule;
					qryvalIR[1] = revSrc;
					ITK_CALL(QRY_execute(qryTagDsgnRevIR,2,qryentIR,qryvalIR,&dsgnRevIRCnt,&dsgnRevIRTags));
					printf("\nNo of Revisions: %d",dsgnRevIRCnt); fflush(stdout);
					if (dsgnRevIRCnt > 0)
					{
						for (irDsgn = 0; irDsgn < dsgnRevIRCnt; ++irDsgn)
						{
							dsgnRevIRTag = dsgnRevIRTags[irDsgn];
							ITK_CALL( AOM_ask_value_string(dsgnRevIRTag,"item_id",&itemIDDsgn));
							ITK_CALL( AOM_ask_value_string(dsgnRevIRTag,"item_revision_id",&revIDDsgn));
							printf("\nItem ID: %s Revision: %s ---- ******* Main Part Revision: %s",itemIDDsgn,revIDDsgn,RevSeqMatch); fflush(stdout);
							if (tc_strcmp(revIDDsgn,RevSeqMatch)!=0)
							{
								ITK_CALL(GRM_list_secondary_objects_only(dsgnRevIRTag,chklistobjreltyp,&chklistct,&chklistsobjtag));
								printf("\n IR WF Check | Ref Relation count : %d ",chklistct);fflush(stdout);
								if (chklistct>0)
								{
									for(refcnt=0;refcnt<chklistct;refcnt++)
									{
										chklistobjtag =chklistsobjtag[refcnt];

										if(TCTYPE_ask_object_type(chklistobjtag,&chklistobjeTypTag)!=ITK_ok);
										if(TCTYPE_ask_name2(chklistobjeTypTag,&chklistObjType)!=ITK_ok);
										printf("\n IR WF Check | Object Type: [%s]", chklistObjType);fflush(stdout);

										if(tc_strcmp(chklistObjType,"T5_IR_CHECKLISTRevision") == 0)
										{
											printf("\n checklist Object Type is: [%s]\n", chklistObjType);fflush(stdout);
											ITK_CALL(GRM_find_relation_type("T5_IR_CHECKLIST_DATA_REL",&cheklistdatareltyp));
											ITK_CALL(GRM_list_secondary_objects_only(chklistobjtag,cheklistdatareltyp,&cheklistdatacnt,&cheklistdatastag));
											
											printf("\nIR WF Check | *****************Old Revisions Submitted for workflow -> Going to Abort START**********");fflush(stdout);
											for(cc=0;cc<cheklistdatacnt;cc++)
											{
												int statuscnt=0;
												int nJobs = 0;
												logical chkprocess;
												char *Ruleid	=  NULL;
												char *status	=  NULL;
												char *chklistdataid	=  NULL;
												char *RevObjName	=  NULL;
												char *chkLstRelStat = NULL;
												char *procedure_name = NULL;
												tag_t* Relstatus = NULLTAG;
												tag_t* jobTags = NULLTAG;

												cheklistdata =cheklistdatastag[cc];
												ITK_CALL(AOM_ask_value_string(cheklistdata,"t5_Design_Rule_ID",&Ruleid));
												ITK_CALL(AOM_ask_value_string(cheklistdata,"t5_Checklist_Implemented",&status));
												ITK_CALL(AOM_ask_value_string(cheklistdata,"item_id",&chklistdataid));
												ITK_CALL(AOM_ask_value_string(cheklistdata,"object_string",&RevObjName));
											    ITK_CALL(AOM_ask_value_logical(cheklistdata,"fnd0InProcess",&chkprocess));
												ITK_CALL(WSOM_ask_release_status_list(cheklistdata,&statuscnt,&Relstatus));
												ITK_CALL(AOM_UIF_ask_value(cheklistdata,"release_status_list",&chkLstRelStat));

												ITK_CALL(EPM_ask_active_job_for_target(cheklistdata,&nJobs,&jobTags));
												if (nJobs > 0)
												{
													ITK_CALL(EPM_ask_procedure_name2(jobTags[0],&procedure_name));
													printf("\n Start of Abort - procedure_nameprocedure_name----->%s\n",procedure_name); fflush(stdout);
													ITK_CALL(AOM_delete(jobTags[0]));
													printf("\n End of Abort - procedure_nameprocedure_name----->%s\n",procedure_name); fflush(stdout);
												}
												printf("\n IRDeviationWorkflow-Abort--|%s|--|%s|--|%s|--|%s|--|%s|--|%d|--",Ruleid,status,chklistdataid,RevObjName,chkLstRelStat,chkprocess);fflush(stdout);
											}
											printf("\nIR WF Check | *****************Old Revisions Submitted for workflow -> Going to Abort END**********");fflush(stdout);
										}
									}
								}
							}
							else
							{
								printf("\nSkipped checking for Latest Checkin Revision: %s",revIDDsgn); fflush(stdout);
							}
						}
					}
				}
				printf("\n**END : Abort workflow on IR Objects from Previous revisions**"); fflush(stdout);

				ifail=Mail_Notification(Submodule,Revseq,id);

		}

        ifail = ITK_set_bypass(true);
    
	   if (ifail != ITK_ok)
        {
                printf("\nUser is not Privileged Admin User \n\n");
                return -1;
        }

        printf("\nEnd of program.....!!\n");
        ifail = ITK_exit_module(true);
        return ifail;
}

int Mail_Notification(char* Submodule,char* Revseq,char* id)
{

    tag_t	qryTag			= NULLTAG;
	tag_t *CntrlObjTag		= NULLTAG;


	char **qry_val			= (char **) MEM_alloc(100 * sizeof(char *));
	char *qry_entri[2] = {"SYSCD","SUBSYSCD"};
	qry_val[0] = "IR";
	qry_val[1] = "MailNotification";
	char* FilePath          =NULL;
	char *InpFile=NULL;;
	char* error_text	=NULL;
	int n_entries				= 2;
	int qrycount			= 0;
	
						
    InpFile=(char *)MEM_alloc(100);

    tc_strcpy(InpFile,"");
    tc_strcpy(InpFile,"interfering_module.csv");

    printf("\n Input FILE NAME=> [%s] ",InpFile); fflush(stdout);


	if(QRY_find("Control Objects...", &qryTag));
	if (qryTag)
	{
		printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);

		if(QRY_execute(qryTag, n_entries, qry_entri, qry_val, &qrycount, &CntrlObjTag));

	    printf("\n\t ****qrycount => %d*****\n",qrycount);fflush(stdout);
	}
	else
	{
		printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
	}

	
	

   if(qrycount>0)
	{

	   if (AOM_ask_value_string(CntrlObjTag[0],"t5_Userinfo3",&FilePath))
	   //  FilePath="/user/cvprod/shells/InterfaceRule/checkinMailNotification/";
	   printf("\n Input File path is : [%s]\n", FilePath);fflush(stdout);

		char *IpFile= NULL;
		IpFile=(char *)MEM_alloc(100);
		tc_strcpy(IpFile,"");
		strcpy(IpFile,FilePath);		
		strcat(IpFile,InpFile);
		
		printf("\n CHECKLIST FILE PATH=> [%s] ",IpFile); fflush(stdout);

		ifail = read_value_from_file(IpFile,Submodule,Revseq,id);
	}
	else
	{
		printf("\n Mail Notificatio is OFF  :: Mail_Notification !! \n");fflush(stdout);
		
	}

}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename,char* Submodule,char* Revseq,char* id)
{
        char                    *DependentSubmodule                                        = NULL;
        char                    *chKOutSubmodule                                         = NULL;  
		char* error_text							=NULL;
        char                    temp[10000];
		 char                    tmp[10000];
		 char* Rev							=NULL;
		 char* rev1							=NULL;
		 
		 char* seq							=NULL;
	//	 char* Submodule							=NULL;
		  char* TokCcidNum							=NULL;
        FILE            * fp                                    = NULL;
		int ifail=0;
		
        FILE			*output 			= NULL;
			                        
		tag_t item_tag		= NULLTAG;
		tag_t latest_rev_id		= NULLTAG;
		tag_t	object_owner						= NULLTAG;
		tag_t	object_owner_person					= NULLTAG;
		char* object_name          =NULL;		
		char *person_name							=NULL;
		char	*CC_MailList						= (char*)MEM_alloc(sizeof(char) * 2000);
		char	*CoC						= (char*)MEM_alloc(sizeof(char) * 5000);
		
		char			Data[100]					= "";
		char			outputFile[200]				= "";
		char command[512]							="";
		char command2[512]							="";
		char osUserName[SA_name_size_c+1];
		char*object_owner_email						= (char*)MEM_alloc(sizeof(char) * 5000);
		char                    *MailTo                                      = NULL;
		char                    *aggregate                                      = NULL;
		MailTo						= (char*)MEM_alloc(sizeof(char) * 350000);
	//	tc_strcpy(CC_MailList,"");
		tc_strcpy(CC_MailList,"at924736.ttl@tatamotors.com,ss927416.ttl@tatamotors.com,gk926356.ttl@tatamotors.com");
		tc_strcat(CC_MailList,",");
		tc_strcpy(MailTo,"");

		tc_strcpy(CoC,"");

		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);


		tc_strcat(outputFile,"/user/cvprod/shells/InterfaceRule/checkinMailNotification/");
	//    tc_strcat(outputFile,"/user/testcmi/Dev/devgroups/Akshay/IR/MailNotificationOnCheckin/");
		tc_strcat(outputFile,Data);
		tc_strcat(outputFile,"_output.txt");


		printf("\nAfter Concatination of File path from crontrol object :: %s\n",outputFile);

         char	ModTime[100]= "";
	     strftime(ModTime,100,"%d %b %Y %H:%M:%S",&when);

	//**************

    Rev=(char *)MEM_alloc(60);

		TokCcidNum=(char *)MEM_alloc(60);
		

		tc_strcpy (TokCcidNum,"" );
		tc_strcat (TokCcidNum,Revseq);

		rev1 = tc_strtok(TokCcidNum,"_");

		seq	 = tc_strtok(NULL,"_");

		printf("\n Submodule   ==%s\n",Submodule);fflush(stdout);
		printf("\n Aftertok rev   ==%s\n",rev1);fflush(stdout);
		printf("\n Aftertok seq   ==%s\n",seq);fflush(stdout);

		tc_strcpy(Rev,rev1);
	//	tc_strcat(Rev,rev1);
		tc_strcat(Rev,";");
		tc_strcat(Rev,seq);

		printf("\n final Rev   ==%s\n",Rev);fflush(stdout);

	//*****************

			

		ITK_CALL(ITEM_find_item(Submodule,&item_tag));
			
		if (item_tag)
		{
			 printf("\n  module found ");
		 

		//	ITK_CALL(ITEM_ask_latest_rev(item_tag,&latest_rev_id));

		   ITK_CALL(ITEM_find_revision(item_tag,Rev,&latest_rev_id));	


				
			if (latest_rev_id)
			{
				printf("\n  module rev found");
			}
			else
			{
				printf("\n  module rev not found");
			}

			ifail = AOM_ask_value_string(latest_rev_id,"object_string",&object_name);
			printf("\nObject Name :---%s\n", object_name);

			ifail = AOM_ask_value_string(latest_rev_id,"t5_Aggregate",&aggregate);
			printf("\n aggregate :---%s\n", aggregate);

			if(tc_strstr(aggregate,"APPLICATIONS")!=NULL)
			{
			 tc_strcpy(CoC,"Rajeeve Dave");
			 tc_strcat(CC_MailList,"rajeev.dave@tatamotors.com");
			 tc_strcat(CC_MailList,",");

			}
			else if(tc_strstr(aggregate,"EXTERIOR")!=NULL)
			{
			 tc_strcpy(CoC,"Prashant Navsariwala");
			 tc_strcat(CC_MailList,"prashant.navsariwala@tatamotors.com");
			 tc_strcat(CC_MailList,",");
			}
			else if(tc_strstr(aggregate,"INTERIOR")!=NULL)
			{
			 tc_strcpy(CoC,"Vijay Veer Singh");
			 tc_strcat(CC_MailList,"vijayveer.singh@tatamotors.com");
			 tc_strcat(CC_MailList,",");
			}
			else if(tc_strstr(aggregate,"CHASSIS INTEGRATION AGGREGATES")!=NULL)
			{
			 tc_strcpy(CoC,"Rahul Pathak");
			  tc_strcat(CC_MailList,"rahul.pathak@tatamotors.com");
			  tc_strcat(CC_MailList,",");
			}
			else if(tc_strstr(aggregate,"DRIVELINE INTEGRATION AGGREGATES")!=NULL)
			{
			 tc_strcpy(CoC,"N Ganesh Kumar");
			 tc_strcat(CC_MailList,"n.ganeshkumar@tatamotors.com");
			 tc_strcat(CC_MailList,",");
			}
			else if(tc_strstr(aggregate,"ENGINE INTEGRATION AGGREGATES")!=NULL)
			{
			 tc_strcpy(CoC,"Mahendra Petale");
			  tc_strcat(CC_MailList,"m.petale@tatamotors.com");
			  tc_strcat(CC_MailList,",");
			}
			else if(tc_strstr(aggregate,"SUSPENSION")!=NULL)
			{
			 tc_strcpy(CoC,"P Premlal");
			 tc_strcat(CC_MailList,"premlal.p@tatamotors.com");
			 tc_strcat(CC_MailList,",");
			}
			else if(tc_strstr(aggregate,"BRAKES & WHEELS")!=NULL)
			{
			 tc_strcpy(CoC,"Mahesh Shridhare");
			 tc_strcat(CC_MailList,"mahesh.shridhare@tatamotors.com");
			 tc_strcat(CC_MailList,",");
			}
			else if(tc_strstr(aggregate,"POWER AND DISTRIBUTION")!=NULL)
			{
			 tc_strcpy(CoC,"Ajai Gupta");
			 tc_strcat(CC_MailList,"ajai.gupta@tatamotors.com");
			 tc_strcat(CC_MailList,",");
			}
			else if(tc_strstr(aggregate,"ENGINEBASE ENGINEERING")!=NULL)
			{
			 tc_strcpy(CoC,"Atul D Joshi");
			 tc_strcat(CC_MailList,"atul.djoshi@tatamotors.com");
			 tc_strcat(CC_MailList,",");
			}
			else if(tc_strstr(aggregate,"TRANSMISSION")!=NULL)
			{
			 tc_strcpy(CoC,"Kiran Bhandari");
			 tc_strcat(CC_MailList,"kiran.bhandari@tatamotors.com");
			 tc_strcat(CC_MailList,",");
			}
			else if(tc_strstr(aggregate,"POWERTRAIN")!=NULL)
			{
			 tc_strcpy(CoC,"Mallappa Achanur");
			  tc_strcat(CC_MailList,"mallappa.achanur@tatamotors.com");
			  tc_strcat(CC_MailList,",");
			}
			
			


         
            fp = fopen(Filename, "r");
			if (fp != NULL)
			{
					while (fgets(temp, 10000, fp)!= NULL)
					{
							tc_strcpy(temp,stripBlanks(temp));

							if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
							{
								   DependentSubmodule = strtok(temp, "~");
									printf("\nInput DependentSubmodule:%s",DependentSubmodule);

									chKOutSubmodule = strtok(NULL, "~");
									printf("\nInput chKOutSubmodule:%s",chKOutSubmodule);

									
									char                    *chkout1                                         = NULL;
									char                    *chkout2                                         = NULL;
									char                    *chkout3                                         = NULL;
									char                    *chkout4                                         = NULL;
									char                    *chkout5                                         = NULL;
									char                    *chkout6                                         = NULL;
									char                    *chkout7                                         = NULL;
									char                    *chkout8                                         = NULL;
									char                    *chkout9                                         = NULL;
									char                    *chkout10                                         = NULL;
									char                    *chkout11                                         = NULL;
									char                    *chkout12                                         = NULL;
									char                    *chkout13                                         = NULL;
									char                    *chkout14                                         = NULL;
									char                    *chkout15                                       = NULL;
									char                    *chkout16                                       = NULL;
									char                    *chkout17                                       = NULL;
									char                    *chkout18                                       = NULL;
									char                    *chkout19                                       = NULL;
									char                    *chkout20                                      = NULL;
																		
								    char                    *DependentSubmodule1                                      = NULL;
								    char                    *DependentSubmodule2                                      = NULL;
								    char                    *DependentSubmodule3                                      = NULL;



									
									DependentSubmodule1 = strtok(DependentSubmodule,"-");
								//	printf("\n DependentSubmodule1:%s",DependentSubmodule1);								

									DependentSubmodule2 = strtok(NULL,"-");
								//	printf("\n DependentSubmodule2:%s",DependentSubmodule2);

									DependentSubmodule3 = strtok(NULL,"-");
								//	printf("\n DependentSubmodule3:%s",DependentSubmodule3);
									  
									chkout1 = strtok(chKOutSubmodule, ";");
								//  printf("\nchkout1:%s",chkout1);

									chkout2 = strtok(NULL, ";");
								//	printf("\nchkout2:%s",chkout2);

									chkout3 = strtok(NULL, ";");
								//	printf("\n chkout3:%s",chkout3);

									chkout4 = strtok(NULL, ";");
								//	printf("\n chkout4:%s",chkout4);

									chkout5 = strtok(NULL, ";");
								//	printf("\n chkout5:%s",chkout5);

									chkout6 = strtok(NULL, ";");
								//	printf("\n chkout6:%s",chkout6);

									chkout7 = strtok(NULL, ";");
								//	printf("\n chkout7:%s",chkout7);

									chkout8 = strtok(NULL, ";");
								//	printf("\n chkout8:%s",chkout8);

									chkout9 = strtok(NULL, ";");
								//	printf("\n chkout9:%s",chkout9);

									chkout10 = strtok(NULL, ";");
								//	printf("\n chkout10:%s",chkout10);

									chkout11 = strtok(NULL, ";");
								//	printf("\n chkout11:%s",chkout11);

									chkout12 = strtok(NULL, ";");
								//	printf("\n chkout12:%s",chkout12);

									chkout13 = strtok(NULL, ";");
								//	printf("\n chkout13:%s",chkout13);

									chkout14 = strtok(NULL, ";");
								//	printf("\n chkout14:%s",chkout14);

									chkout15 = strtok(NULL, ";");
								//	printf("\n chkout15:%s",chkout15);

									chkout16 = strtok(NULL, ";");
								//	printf("\n chkout16:%s",chkout16);

									chkout17 = strtok(NULL, ";");
								//	printf("\n chkout17:%s",chkout17);

									chkout18 = strtok(NULL, ";");
								//	printf("\n chkout18:%s",chkout18);

									chkout19 = strtok(NULL, ";");
								//	printf("\n chkout19:%s",chkout19);

									chkout20 = strtok(NULL, ";");
								//	printf("\n chkout20:%s",chkout20);



									if((tc_strstr(Submodule,chkout1)!=NULL) || (tc_strstr(Submodule,chkout2)!=NULL) || (tc_strstr(Submodule,chkout3)!=NULL) || (tc_strstr(Submodule,chkout4)!=NULL) || (tc_strstr(Submodule,chkout5)!=NULL) || (tc_strstr(Submodule,chkout6)!=NULL) || (tc_strstr(Submodule,chkout7)!=NULL) || (tc_strstr(Submodule,chkout8)!=NULL) || (tc_strstr(Submodule,chkout9)!=NULL) || (tc_strstr(Submodule,chkout10)!=NULL) || (tc_strstr(Submodule,chkout11)!=NULL) || (tc_strstr(Submodule,chkout12)!=NULL) ||(tc_strstr(Submodule,chkout13)!=NULL) || (tc_strstr(Submodule,chkout14)!=NULL) || (tc_strstr(Submodule,chkout15)!=NULL) || (tc_strstr(Submodule,chkout16)!=NULL) || (tc_strstr(Submodule,chkout17)!=NULL) || (tc_strstr(Submodule,chkout18)!=NULL) || (tc_strstr(Submodule,chkout19)!=NULL) || (tc_strstr(Submodule,chkout20)!=NULL))
									{

										 int n_parents = 0;
										 int *levels1 = 0;
										 int ii;
										 int n_Cnt=0;
										 int i;
										 
										char **relation_type_name = NULL;
										char* modulerev = NULL;
										char	*sCPartNum = NULL;
										char	*sCPartRvSq = NULL;
										char	*PartType = NULL;
										char	*aggCC = NULL;

										tag_t *parents = NULL;
										tag_t	window = NULLTAG;
										tag_t	top_line = NULLTAG;
										tag_t	tChld = NULLTAG;
										tag_t	*children = NULLTAG;												
										tag_t	modrevtag = NULLTAG;
										tag_t	modtag = NULLTAG;

								
									   
									    ITK_CALL(PS_where_used_all(latest_rev_id, 1, &n_parents, &levels1, &parents));
									   printf("\n n_parents --->[%d]\n", n_parents); fflush(stdout);

									   for (ii = 0; ii < n_parents; ii++)
										{       
												char  type_name1[WSO_name_size_c + 1] = "";

												
												ITK_CALL(WSOM_ask_object_type(parents[ii], type_name1));

											//	printf("\n type_name1 --->[%s]\n", type_name1); fflush(stdout);
											//	printf("\n relation_type_name[ii] --->[%s]\n", relation_type_name[ii]); fflush(stdout);
											
											    ifail = AOM_ask_value_string(parents[ii],"t5_PartType",&PartType);
											//	printf("\n PartType --->[%s]\n", PartType); fflush(stdout);

											
												if((tc_strcmp(type_name1,"Design Revision")==0) && tc_strcmp(PartType,"V")==0 ) 
												{
											
											        ifail =BOM_create_window(&window);
													ifail = BOM_set_window_top_line (window, null_tag, parents[ii], null_tag, &top_line);
													CHECK_FAIL;

													ifail = BOM_window_show_suppressed ( window );
													CHECK_FAIL;

													ITK_CALL(BOM_set_window_pack_all(window, FALSE));

													ITKCALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children));
													printf("\n mdule count --->[%d]\n", n_Cnt); fflush(stdout);


												/*	ifail =BOM_create_window(&window);
													ifail = BOM_set_window_top_line (window, null_tag, parents[ii], null_tag, &top_line);
													CHECK_FAIL;

													ifail = BOM_window_show_suppressed ( window );
													CHECK_FAIL;

													ITK_CALL(BOM_set_window_pack_all(window, FALSE));

													ITKCALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children));
												printf("\n mdule count --->[%d]\n", n_Cnt); fflush(stdout);*/
													for (i=0; i<n_Cnt; ++i)
													{
														tChld=children[i];
														
														
														ITKCALL(AOM_ask_value_string(tChld,"bl_item_item_id",&sCPartNum));
														ITKCALL(AOM_ask_value_string(tChld,"bl_rev_item_revision_id",&sCPartRvSq)); 
                                                        ITKCALL(AOM_ask_value_string(tChld,"bl_Design Revision_t5_Aggregate",&aggCC));

														ITK_CALL(ITEM_find_item(sCPartNum,&modtag));
														ITK_CALL(ITEM_find_revision(modtag,sCPartRvSq,&modrevtag));	
														ITKCALL(AOM_ask_value_string(modrevtag,"item_revision_id",&modulerev));


													//	printf("\n bommodule --->[%s]\n", sCPartNum); fflush(stdout);
													//	printf("\n bommodulerev --->[%s]\n", sCPartRvSq); fflush(stdout);
													//	 printf("\n modulerev --->[%s]\n", modulerev); fflush(stdout);

														 if(tc_strstr(sCPartNum,DependentSubmodule2)!=NULL)
														{      
															
															ifail = AOM_ask_owner(modrevtag,&object_owner);
																if(ifail ==ITK_ok){

																} else 
																{
																	EMH_ask_error_text(ifail,&error_text);
																	printf("\nError %s", error_text);
																}
																ifail = SA_ask_user_person(object_owner,&object_owner_person);
																if(ifail ==ITK_ok){

																} else 
																{
																	EMH_ask_error_text(ifail,&error_text);
																	printf("\nError %s", error_text);
																}


																ifail =SA_ask_person_name2(object_owner_person,&person_name);
																printf("\nPerson Name: %s",person_name);
																

																ifail =SA_ask_person_email_address(object_owner_person,&object_owner_email);
															
															 //   object_owner_email="at924736.ttl@tatamotors.com";

													
															/*	SA_ask_os_user_name	(object_owner,&osUserName);
																printf("\nuser Name %s",osUserName);
																
																 tc_strcpy(object_owner_email,"");
																 tc_strcpy(object_owner_email,osUserName);
															tc_strcat(object_owner_email,"@tatamotors.com");*/

																 printf("\n owninguser Mail id :---%s\n",object_owner_email);
																 int emaillength = strlen(object_owner_email);

					                                           printf("\n\t object_owner_email Lenght :%d",emaillength);


															 
																 if((tc_strstr(object_owner_email,"loader")==NULL) && (emaillength !=0))
																 {
																	 printf("Inside loader condition");
															       if((tc_strstr(MailTo,object_owner_email)==NULL))
															        {
																      tc_strcat(MailTo,object_owner_email);
																	  tc_strcat(MailTo,",");
																	}
																	 
																 }

																   

																   
														
													//*************

                                                     //    if((tc_strstr(CC_MailList,"rajeev.dave@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"prashant.navsariwala@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"vijayveer.singh@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"rahul.pathak@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"n.ganeshkumar@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"m.petale@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"premlal.p@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"mahesh.shridhare@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"ajai.gupta@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"atul.djoshi@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"kiran.bhandari@tatamotors.com")==NULL) || (tc_strstr(CC_MailList,"mallappa.achanur@tatamotors.com")==NULL))
													       
																      
																	
																if((tc_strstr(aggCC,"APPLICATIONS")!=NULL) && (tc_strstr(CC_MailList,"rajeev.dave@tatamotors.com")==NULL))
																{
																	 
																 
																 tc_strcat(CC_MailList,"rajeev.dave@tatamotors.com");
																 tc_strcat(CC_MailList,",");

																}
																else if((tc_strstr(aggCC,"EXTERIOR")!=NULL) && (tc_strstr(CC_MailList,"prashant.navsariwala@tatamotors.com")==NULL))
																{
																
																 tc_strcat(CC_MailList,"prashant.navsariwala@tatamotors.com");
																 tc_strcat(CC_MailList,",");
																}
																else if((tc_strstr(aggCC,"INTERIOR")!=NULL) && (tc_strstr(CC_MailList,"vijayveer.singh@tatamotors.com")==NULL))
																{
																 
																 tc_strcat(CC_MailList,"vijayveer.singh@tatamotors.com");
																 tc_strcat(CC_MailList,",");
																}
																else if((tc_strstr(aggCC,"CHASSIS INTEGRATION AGGREGATES")!=NULL) && (tc_strstr(CC_MailList,"rahul.pathak@tatamotors.com")==NULL))
																{
																 
																  tc_strcat(CC_MailList,"rahul.pathak@tatamotors.com");
																  tc_strcat(CC_MailList,",");
																}
																else if((tc_strstr(aggCC,"DRIVELINE INTEGRATION AGGREGATES")!=NULL) && (tc_strstr(CC_MailList,"n.ganeshkumar@tatamotors.com")==NULL))
																{
																
																 tc_strcat(CC_MailList,"n.ganeshkumar@tatamotors.com");
																 tc_strcat(CC_MailList,",");
																}
																else if((tc_strstr(aggCC,"ENGINE INTEGRATION AGGREGATES")!=NULL) && (tc_strstr(CC_MailList,"m.petale@tatamotors.com")==NULL))
																{
																
																  tc_strcat(CC_MailList,"m.petale@tatamotors.com");
																  tc_strcat(CC_MailList,",");
																}
																else if((tc_strstr(aggCC,"SUSPENSION")!=NULL) && (tc_strstr(CC_MailList,"premlal.p@tatamotors.com")==NULL))
																{
																 
																 tc_strcat(CC_MailList,"premlal.p@tatamotors.com");
																 tc_strcat(CC_MailList,",");
																}
																else if((tc_strstr(aggCC,"BRAKES & WHEELS")!=NULL) && (tc_strstr(CC_MailList,"mahesh.shridhare@tatamotors.com")==NULL))
																{
																 
																 tc_strcat(CC_MailList,"mahesh.shridhare@tatamotors.com");
																 tc_strcat(CC_MailList,",");
																}
																else if((tc_strstr(aggCC,"POWER AND DISTRIBUTION")!=NULL) && (tc_strstr(CC_MailList,"ajai.gupta@tatamotors.com")==NULL))
																{
																 
																 tc_strcat(CC_MailList,"ajai.gupta@tatamotors.com");
																 tc_strcat(CC_MailList,",");
																}
																else if((tc_strstr(aggCC,"ENGINEBASE ENGINEERING")!=NULL) && (tc_strstr(CC_MailList,"atul.djoshi@tatamotors.com")==NULL))
																{
																 
																 tc_strcat(CC_MailList,"atul.djoshi@tatamotors.com");
																 tc_strcat(CC_MailList,",");
																}
																else if((tc_strstr(aggCC,"TRANSMISSION")!=NULL) && (tc_strstr(CC_MailList,"kiran.bhandari@tatamotors.com")==NULL))
																{
																 
																 tc_strcat(CC_MailList,"kiran.bhandari@tatamotors.com");
																 tc_strcat(CC_MailList,",");
																}
																else if((tc_strstr(aggCC,"POWERTRAIN")!=NULL) && (tc_strstr(CC_MailList,"mallappa.achanur@tatamotors.com")==NULL))
																{
																 
																  tc_strcat(CC_MailList,"mallappa.achanur@tatamotors.com");
																  tc_strcat(CC_MailList,",");
																}

														}
														   
			                                          //*************
														
													
													   
													}

														
											   }
										}


									}
									else
									{

										printf("\nchecking next\n");

									}


							}

							printf("\n***************************************\n");

							tc_strcpy(temp, "");

					}

					int len = strlen(MailTo);

					printf("\n\t mail To Lenght :%d",len);

					if(len >10)
					{

						output = fopen(outputFile, "w");
						if (output == NULL)
						{
							printf("ERROR: Cannot open File\n");
							return -1;
						}
						else
						{
							printf("File opened successfully.\n");
							
						}

	                   

						fprintf(output,"To:%s\n",MailTo);
						fprintf(output,"CC:%s\n",CC_MailList);
						fprintf(output,"Subject: Attention: Sub module modification -%s/%s\n",Submodule,Rev);
					//	fprintf(output,"Hello,\n\n","");
						fprintf(output,"The following submodule is modified in the PLM database\n\n\n","");					
						fprintf(output,"Sub -module name:%s\n\n",Submodule);
						fprintf(output,"Rev. seq:%s\n\n",Rev);
						fprintf(output,"Aggregate:%s\n\n",aggregate);
						fprintf(output,"Modified by:%s\n\n",id);
						fprintf(output,"CoC head:%s\n\n",CoC);
						fprintf(output,"Modification time:%s\n\n",ModTime);
						

						fclose(output);

						tc_strcat(command2,"chmod 777 /user/cvprod/shells/InterfaceRule/checkinMailNotification/*");
					//    tc_strcat(command2,"chmod 777 /user/testcmi/Dev/devgroups/Akshay/IR/MailNotificationOnCheckin/*");
						system(command2);

						tc_strcat(command,"/user/cvprod/shells/InterfaceRule/checkinMailNotification/SendMail.sh");
					//	tc_strcat(command,"/user/testcmi/Dev/devgroups/Akshay/IR/MailNotificationOnCheckin/SendMail.sh");	
						tc_strcat(command," ");
						tc_strcat(command,outputFile);
						tc_strcat(command," ");
						tc_strcat(command,"cvprod@localhost"); //From
						tc_strcat(command," ");
						tc_strcat(command,MailTo);											   
						tc_strcat(command," > myoutput.txt &");

					   
						printf("\n\tCommand :%s",command);

					
					  	system(command);
					}
					
					printf("\n*************************End of Handler*********************\n");
				
			}
			else
			{
					printf("File Unable to Open...!!");
			}
	
        fclose(fp);
        

	}
	return ifail;
}



































