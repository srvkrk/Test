/*   */
#include "soapH.h"								/* get the gSOAP-generated definitions */
#include "PalmSysToTcua.nsmap"		 /* get the gSOAP-generated namespace bindings */
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h>
#include <tccore/project.h>
#include <cfm/cfm.h>
#include <qry/qry.h>
#include <tc/preferences.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <iostream>
#include <sstream>
#include <fstream>  
#include <vector>
#include <string>
#include <typeinfo>
#include <unistd.h>
#include <ctime>
#include <tcinit/tcinit.h>
using namespace std;

string getCurrentDateTime1() {
    // Get the current time
    time_t now = time(nullptr);
    tm* localTime = localtime(&now);

    // Format the time into a string (e.g., "2025-02-13_12-45-30")
    ostringstream oss;
    oss << (1900 + localTime->tm_year) << "_"
        << (1 + localTime->tm_mon) << "_"
        << localTime->tm_mday << "_"
        << localTime->tm_hour << "_"
        << localTime->tm_min << "_"
        << localTime->tm_sec;

    return oss.str();
}
class Item{
	private :
	string OpItemID;

	public :
	//Item(string operation) : OpItemID(operation) {}
	Item(string operation){}
	Item() = default;
	tag_t ReturnItemRevision(string operation)
	{
		this->OpItemID = operation;
		tag_t OperationItemTag = NULLTAG;
		tag_t OperationLatestRevisionTag = NULLTAG;
		logical isCheckOut = 0;
		ITEM_find_item(OpItemID.c_str(),&OperationItemTag);
		if(OperationItemTag!=NULLTAG)
		{
			char *OperationLatestRevisionItemId = NULL;
			char *OperationLatestRevisionItemRevisionid = NULL;
			int OperationLatestRevisionItemSequenceid = NULL;
			ITEM_ask_latest_rev(OperationItemTag,&OperationLatestRevisionTag);
			AOM_ask_value_string(OperationLatestRevisionTag,"item_id",&OperationLatestRevisionItemId);
			AOM_ask_value_string(OperationLatestRevisionTag,"item_revision_id",&OperationLatestRevisionItemRevisionid);
			AOM_ask_value_int(OperationLatestRevisionTag,"sequence_id",&OperationLatestRevisionItemSequenceid);

			return OperationLatestRevisionTag;
		}
	}

};
extern int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new());										/* call the request dispatcher */
};
int ns__getPalmSysToTcua(struct soap* soap, 
											char *operation,
											char *MostFrequency,
											char *MostDiv,
											char *MostMen,
											char *MostOnOff,
											char *CT,
											char *CW,
											struct ns__getPalmSysToTcuaResponse *out)
{
	ofstream MainFile;
	string dateTime = getCurrentDateTime1();
	string line;
	stringstream ss;
	string FileLoc;
	string Filename1;
	string operation_Str = operation;
	string MostFrequency_Str = MostFrequency;
	string MostDiv_Str = MostDiv;
	string MostMen_Str = MostMen;
	string MostOnOff_Str = MostOnOff;
	string CT_Str = CT;
	string CW_Str = CW;
	string LocPath = "/user/cvprod/NON_ERC_PUNE/TEST_CC/vishal/PalmsysToMpp/logPath/";
	Filename1 = "PalmSysToTCUA_" + dateTime + ".txt";
	cout<< "Filename ======" <<Filename1<< endl;
	FileLoc = LocPath +  Filename1;
	cout<< "FileLoc ======" <<FileLoc<< endl;
	//variable decleration
	char *loggedInUser = NULL;
	tag_t ItemRevisionQryTag = NULLTAG;
	MainFile.open(FileLoc);
	if(MainFile.is_open())
	{	
		fpos_t pos;
		fgetpos(stdout, &pos);
		int fd = dup(fileno(stdout));
		freopen("/user/cvprod/NON_ERC_PUNE/TEST_CC/vishal/PalmsysToMpp/logPath/ALTMAT.txt", "a", stdout); 		
		ITK_init_module("aj928455.ttl","Anirva@12#anirva","PLM_Support_Group");
		MainFile << "File is created and getting called" << endl;
		POM_get_user_id(&loggedInUser);
		MainFile << "Loged in user is : " << loggedInUser << endl;
		if( (operation_Str=="")   || (MostFrequency_Str=="")   || (MostDiv_Str=="")   || (MostMen_Str=="")   || (MostOnOff_Str=="")   || (CT_Str=="")   || (CW_Str=="") || 
			(operation_Str=="?")  || (MostFrequency_Str=="?")  || (MostDiv_Str=="?")  || (MostMen_Str=="?")  || (MostOnOff_Str=="?")  || (CT_Str=="?")  || (CW_Str=="?"))
		{
			MainFile << "Wrong Inputs" << endl;
			out->Flag = soap_strdup(soap, "ERROR");
        	out->response = soap_strdup(soap, "Wrong Inputs");
 
		}
		else
		{
			MainFile << "operation id given as input is : " << operation << endl; 
			MainFile << "operation MostFrequency given as input is : " << MostFrequency << endl; 
			MainFile << "operation MostDiv given as input is       : " << MostDiv << endl; 
			MainFile << "operation MostMen given as input is       : " << MostMen << endl; 
			MainFile << "operation MostOnOff given as input is     : " << MostOnOff << endl; 
			MainFile << "operation CT given as input is            : " << CT << endl;  
			MainFile << "operation CW given as input is            : " << CW << endl;
			string OperationId = operation;
			string MostFrequencyStr = MostFrequency;
			string MostDivStr = MostDiv;
			string MostMenStr = MostMen;
			string MostOnOffStr = MostOnOff;
			string CTStr = CT;
			string CWStr = CW;
			
			Item p;
			tag_t ItemRevTag = NULLTAG;
			logical isCheckOut = 0;
			char *OperationLatestRevisionItemId = NULL;
			char *OperationLatestRevisionItemRevisionid = NULL;
			int OperationLatestRevisionItemSequenceid = NULL;
			ItemRevTag = p.ReturnItemRevision(OperationId);
			if(ItemRevTag!=NULLTAG)
			{
				
				AOM_ask_value_string(ItemRevTag,"item_id",&OperationLatestRevisionItemId);
				AOM_ask_value_string(ItemRevTag,"item_revision_id",&OperationLatestRevisionItemRevisionid);
				AOM_ask_value_int(ItemRevTag,"sequence_id",&OperationLatestRevisionItemSequenceid);
				MainFile << "OperationLatestRevisionItemId         : " << OperationLatestRevisionItemId  << endl;
				MainFile << "OperationLatestRevisionItemRevisionid : " << OperationLatestRevisionItemRevisionid  << endl;
				MainFile << "OperationLatestRevisionItemSequenceid : " << OperationLatestRevisionItemSequenceid  << endl;
				RES_is_checked_out(ItemRevTag,&isCheckOut);
				if(isCheckOut==1)
				{
					tag_t MostFrequencyAttributeID = NULLTAG;
					tag_t MostDivAttributeID = NULLTAG;
					tag_t MostMenAttributeID = NULLTAG;
					tag_t MostOnOffAttributeID = NULLTAG;
					tag_t CTAttributeID = NULLTAG;
					tag_t CWAttributeID = NULLTAG;
					AOM_lock(ItemRevTag);
					POM_attr_id_of_attr("t5_OP_PEMstFrequency", "MEOPRevision", &MostFrequencyAttributeID);
					POM_attr_id_of_attr("t5_OP_PEMstDivision", "MEOPRevision", &MostDivAttributeID);
					POM_attr_id_of_attr("t5_OP_PEMstMen", "MEOPRevision", &MostMenAttributeID);
					POM_attr_id_of_attr("t5_OP_PEMstonoff", "MEOPRevision", &MostOnOffAttributeID);
					POM_attr_id_of_attr("t5_OP_PEDPECT", "MEOPRevision", &CTAttributeID);
					POM_attr_id_of_attr("t5_OP_PEDPECW", "MEOPRevision", &CWAttributeID);
					POM_set_env_info(POM_bypass_attr_update, FALSE, 0, 0, NULLTAG, NULL);
					POM_set_attr_string(1, &ItemRevTag, MostFrequencyAttributeID, MostFrequencyStr.c_str());
					POM_set_attr_string(1, &ItemRevTag, MostDivAttributeID, MostDivStr.c_str());
					POM_set_attr_string(1, &ItemRevTag, MostMenAttributeID, MostMenStr.c_str());
					POM_set_attr_string(1, &ItemRevTag, MostOnOffAttributeID, MostOnOffStr.c_str());
					POM_set_attr_string(1, &ItemRevTag, CTAttributeID, CTStr.c_str());
					POM_set_attr_string(1, &ItemRevTag, CWAttributeID, CWStr.c_str());
					AOM_save_without_extensions(ItemRevTag);
					AOM_unlock(ItemRevTag);
					char *MostFrequencySet = NULL;
					char *MostDivSet = NULL;
					char *MostMenSet = NULL;
					char *MostOnOffSet = NULL;
					char *CTSet = NULL;
					char *CWSet = NULL;
					char *PsdCalTimeSet = NULL;
					char *AplCalTimeSet = NULL;
					AOM_ask_value_string(ItemRevTag,"t5_OP_PEMstFrequency",&MostFrequencySet);
					AOM_ask_value_string(ItemRevTag,"t5_OP_PEMstDivision",&MostDivSet);
					AOM_ask_value_string(ItemRevTag,"t5_OP_PEMstMen",&MostMenSet);
					AOM_ask_value_string(ItemRevTag,"t5_OP_PEMstonoff",&MostOnOffSet);
					AOM_ask_value_string(ItemRevTag,"t5_OP_PEDPECT",&CTSet);
					AOM_ask_value_string(ItemRevTag,"t5_OP_PEDPECW",&CWSet);
					MainFile << "operation MostFrequency Set as : " << MostFrequencySet << endl; 
					MainFile << "operation MostDiv Set as       : " << MostDivSet << endl; 
					MainFile << "operation MostMen Set as       : " << MostMenSet << endl; 
					MainFile << "operation MostOnOff Set as     : " << MostOnOffSet << endl; 
					MainFile << "operation CT Set as            : " << CTSet << endl;
					MainFile << "operation CW Set as            : " << CWSet << endl;
					AOM_refresh(ItemRevTag,0);
					out->Flag = soap_strdup(soap, "SUCCESS");
        			out->response = soap_strdup(soap, "Attributes updated in MPP, Refresh and check");
				}
				else
				{	
					out->Flag = soap_strdup(soap, "ERROR");
        			out->response = soap_strdup(soap, "Operation mentioned is not checked out --- Please check out the operation in TCUA");
				}
			}
			else{
				MainFile << "Operation not found" << endl;
				out->Flag = soap_strdup(soap, "ERROR");
				out->response = soap_strdup(soap,  "Attributes are not updated in MPP, either operation is not available or some technical issue");
			}
		}
		fflush(stdout);
		dup2(fd, fileno(stdout));
		close(fd);
		clearerr(stdout);
		fsetpos(stdout, &pos);

	}
	MainFile.close();

	return SOAP_OK;
};


