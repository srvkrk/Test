
/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename     :ModuleNameSchemaReportNew.c
*
* Description       : > This Utility is to do unit testing of functions .
* Module                
* Since         :    

* ENVIRONMENT       :    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date           Name                       Description of Change
* 10/12/2024    Sanjoy Mondal               change as per Teamcenter 14.3
* 

* -----------------------------------------------------------------------------
*
*****************************************************************************/


#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>        
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
//#include <tccore/libtccore_exports.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>


void write2xml(FILE * , char*);
int ctr=0;

 int a=0;

FILE *Report; 

void write2xml(FILE *Report , char* str)
{
    fprintf(Report,str);
    ctr++;
}

static int PrintErrorStack( void )
{
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/

    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
    //fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}




void print_requirement()
{
    printf(
    "\nHELP:\n"
    "ModuleNameSchemaReportNew -u=<username> -pf=<password file path> -g=<group> -file=<input filename>\n"
    "--------------------------------------------------------------------------------------------\n\n"
    );
}
/******************************************************
command to run:
** ModuleNameSchemaReportNew -u=<username> -p=<password> -g=<group> 
Uadev = ./ModuleNameSchemaReportNew -u=infodba -pf=infodba -g=dba 

UA Prod = ./ModuleNameSchemaReportNew -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba 
                                                  ///user/uaprod/shells/Admin/loaderpasswdFile.pwf 

UAProd = ./ModuleNameSchemaReportNew -u=ercpsup -pf=ERCpsup2019 -g=Engineering 

CMI Test == ./ModuleNameSchemaReportNew -u=loader -pf=/home/cmitest/shells/Admin/loaderpwffile.pwf -g=dba

scp -rp ModuleNameSchemaReportNew bsd05818@172.22.97.12:/user/bsd05818/harshad/Module_schema_report
******************************************************/

/*********************************************************************************************/

typedef struct ModuleSchemaRepModel1_
{
	// Aggregate Group 	 Aggregate 	 Module Group 	  Module 	  Module Address 	 Design Group 

	char AggregateGroup[200];
	char Aggregate[200];
	char ModuleGroup[200];
	char Module[200];
	char ModuleAddress[50];
	char DesignGroup[20];

}ModuleSchemaRepModel1;

typedef struct ModuleSchemaRepModel_
{
	// Aggregate Group 	 Aggregate 	 Module Group 	  Module 	  Module Address 	 Design Group 

	char* AggregateGroup;
	char* Aggregate;
	char* ModuleGroup;
	char* Module;
	char* ModuleAddress;
	char* DesignGroup;

}ModuleSchemaRepModel;


void setAddModuleSchemaRepModel(int *count,ModuleSchemaRepModel **objlist,ModuleSchemaRepModel obj )
{

	*count=*count+1;
	if(*count==1)
	{
		(*objlist) = (ModuleSchemaRepModel *)malloc((*count ) * sizeof(ModuleSchemaRepModel ));
	}
	else
	{
		(*objlist) = (ModuleSchemaRepModel *)realloc((*objlist),(*count) * sizeof(ModuleSchemaRepModel ));
	}

	(*objlist)[*count-1] = obj;
}

/* Function to tokenize input string by ';'
   Returns dynamically allocated array of strings
   Number of tokens is returned via count */
char **tokenize(const char *input, int *count) {
    if (!input || !count)
        return NULL;

    char *copy = strdup(input);  // Make modifiable copy
    if (!copy)
        return NULL;

    int capacity = 10;  // Initial array capacity
    char **result = malloc(capacity * sizeof(char *));
    if (!result) {
        free(copy);
        return NULL;
    }

    *count = 0;

    char *token = strtok(copy, ";");
    while (token != NULL) {
        // Resize array if needed
        if (*count >= capacity) {
            capacity *= 2;
            char **temp = realloc(result, capacity * sizeof(char *));
            if (!temp) {
                free(copy);
                return NULL;
            }
            result = temp;
        }

        result[*count] = strdup(token);  // Copy token
        if (!result[*count]) {
            free(copy);
            return NULL;
        }

        (*count)++;
        token = strtok(NULL, ";");
    }

    free(copy);
    return result;
}

/* Free allocated memory */
void free_tokens(char **tokens, int count) {
    for (int i = 0; i < count; i++) {
        free(tokens[i]);
    }
    free(tokens);
}

// Function definition
char* getModuleAddress(char*  AggregateGroup,char* Aggregates,char* ModuleGroup,char* Module) {
    // Check minimum length requirements
    if (strlen(AggregateGroup) < 1 || strlen(Aggregates) < 1 || strlen(ModuleGroup) < 1 || strlen(Module) < 2) {
        return NULL;
    }

    // Allocate memory for:
    // M + 3 chars + 2 chars + null terminator = 7 characters
    char* result = (char*)malloc(7 * sizeof(char));
    if (result == NULL) {
        return NULL;
    }

    result[0] = 'M';
    result[1] = AggregateGroup[0];
    result[2] = Aggregates[0];
    result[3] = ModuleGroup[0];
    result[4] = Module[0];
    result[5] = Module[1];
    result[6] = '\0';

    return result;
}

int getDesignGroup (char* ModuleAddress, char** DesignGrp)
{
	int ifail = ITK_ok;
	char* inputValue = NULL;
	tag_t queryTag = NULLTAG;
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	int ctrlCount = 0;
	tag_t* ctrlTags = NULLTAG;
	tc_strdup(ModuleAddress, &inputValue);
	
	ifail = QRY_find2("Control Objects...", &queryTag);
	if (queryTag) 
	{
		//printf("\n Found Query \n\n");fflush(stdout);
	}
	else 
	{
		printf("\n Error!!!! - Not Found Query\n");fflush(stdout);
		return ifail;
	}
	
	qry_entries[0] = "SYSCD";
	qry_values[0]=inputValue;
	ifail = QRY_execute(queryTag, 1, qry_entries, qry_values, &ctrlCount, &ctrlTags);
		
	//printf("Module Add: ctrlCount -> [%d]\n",ctrlCount);fflush(stdout);
	
	if(ctrlCount > 0)
	{
		char* sDsignGrpId = NULL;
		tag_t ctrlTag = ctrlTags[0];
		ifail = AOM_ask_value_string(ctrlTag,"t5_Userinfo1",&sDsignGrpId);
		*DesignGrp = sDsignGrpId;
	}
	
	return ifail;
}

char* trimString(char* str)
{
    char* end;

    // Trim leading whitespace (space, tab, newline, etc.)
    while (isspace((unsigned char)*str))
        str++;

    if (*str == 0)
        return str;

    // Trim trailing whitespace
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end))
        end--;

    *(end + 1) = '\0';

    return str;
}

int ITK_user_main(int argc, char *argv[])
{
	int ifail = ITK_ok;
	
	printf("\n \n ************** Inside Main Func **************** \n\n");
    
    
    ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
     
    ifail = ITK_auto_login();


    if (ifail == ITK_ok) 
    {
         printf( "Login successfull. .........\n");
             
    } else 
    {
         printf("\n*** Error with ITK_init_module ***\n");fflush(stdout);
        return ifail;
    }

    ifail = ITK_set_bypass(true);
	
	//Get Modules
	int count = 0;
	const char *arrr [6]={"B*", "C*", "E*", "P*", "T*", "Z*"};
	const char *arrrVal[6] = {"B-BIWModGrp*", "C-CHASSISModGrp*", "E-E&EModGrp*", "P-POWERTRAINModGrp*", "T-TRIMModGrp*", "Z-DEV MODULEModGrp*"};
	const char *AggregateGrpArr[6] = {"B-BIW", "C-CHASSIS", "E-E&E", "P-POWERTRAIN", "T-TRIM", "Z-DEV MODULE"};
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	ModuleSchemaRepModel *moduleSchRepModelList= NULL;
	int moduleSchRepModelListCnt = 0;
	// Aggregate Group 	 Aggregate 	 Module Group 	  Module 	  Module Address 	 Design Group 

	for(count =0 ;count<6 ;count++)
	{
		tag_t queryTag = NULLTAG;
		tag_t *ctrlTags = NULL;
		int ctrlCount = 0;
		char* AggregateGrp = NULL;
		char* AggreGrpStr = NULL;
		int i = 0;
		printf("%d -> [%s] -> [%s] -> [%s] \n",count + 1, arrr[count],arrrVal[count],AggregateGrpArr[count]);fflush(stdout);
		
		ifail = QRY_find2("Control Objects...", &queryTag);
        if (queryTag) 
        {
            //printf("\n Found Query \n\n");fflush(stdout);
        }
        else 
        {
            printf("\n Error!!!! - Not Found Query\n");fflush(stdout);
            continue;
        }

		tc_strdup(arrrVal[count],&AggreGrpStr);
		tc_strdup(AggregateGrpArr[count],&AggregateGrp);
		qry_entries[0] = "SYSCD";
		qry_values[0] = AggreGrpStr;
		
		printf("AggreGrpStr:[%s], Aggregate Group: [%s]\n",AggreGrpStr,AggregateGrp);fflush(stdout);
		
		
		ifail = QRY_execute(queryTag, 1, qry_entries, qry_values, &ctrlCount, &ctrlTags);
		
		printf("ctrlCount -> [%d]\n",ctrlCount);fflush(stdout);
		
		
		//Loop through the control object
		
		for (i=0;i<ctrlCount ;i++ )
		{
			char* AggrAndModuleGrp = NULL;
			char* strModuleInfo2 = NULL;
			char* strModuleInfo3 = NULL;
			char* strModuleInfo4 = NULL;
			char* strModuleInfo5 = NULL;
			char* strModuleInfo6 = NULL;
			//char* strModuleInfo7 = NULL;
			char* Aggregates = NULL;
			char* ModuleGroup = NULL;
			logical chkOut = FALSE;
			RES_is_checked_out(ctrlTags[i],&chkOut);
			if(chkOut)
			{
				printf("\nChecked out control tag[%s]. Skipping\n",AggreGrpStr);fflush(stdout);
				continue;
			}
			
			ifail = AOM_ask_value_string(ctrlTags[i],"t5_Userinfo1",&AggrAndModuleGrp);
			ifail = AOM_ask_value_string(ctrlTags[i],"t5_Userinfo2",&strModuleInfo2);
			ifail = AOM_ask_value_string(ctrlTags[i],"t5_Userinfo3",&strModuleInfo3);
			ifail = AOM_ask_value_string(ctrlTags[i],"t5_Userinfo4",&strModuleInfo4);
			ifail = AOM_ask_value_string(ctrlTags[i],"t5_Userinfo5",&strModuleInfo5);
			ifail = AOM_ask_value_string(ctrlTags[i],"t5_Userinfo6",&strModuleInfo6);
			//ifail = AOM_ask_value_string(ctrlTags[i],"t5_Userinfo7",&strModuleInfo7);
			
			char* AggAndModuleGrpDup = NULL;
			char* AllModuleString = NULL;
			char* AllModuleStringDup = NULL;
			if(AggrAndModuleGrp != NULL)
			{
				tc_strdup(AggrAndModuleGrp,&AggAndModuleGrpDup);
			}
			else
			{
				continue;
			}
			
			if(tc_strstr(AggAndModuleGrpDup,"~") != NULL)
			{
				Aggregates = tc_strtok (AggAndModuleGrpDup,"~") ;
				ModuleGroup = tc_strtok (NULL,"~") ;	
			}
			
			//printf("Aggregates:[%s], ModuleGroup:[%s]\n",Aggregates,ModuleGroup);fflush(stdout);
			
			int total_len = tc_strlen(strModuleInfo2) + tc_strlen(strModuleInfo3) + tc_strlen(strModuleInfo4) + tc_strlen(strModuleInfo5) + tc_strlen(strModuleInfo6);
			
			AllModuleString = MEM_alloc((total_len + 10000)*sizeof(char));
			
			tc_strcpy(AllModuleString,trimString(strModuleInfo2));
			if(tc_strlen(strModuleInfo3) >  5)
			{
				tc_strcat(AllModuleString,trimString(strModuleInfo3));
			}
			if(tc_strlen(strModuleInfo4) >  5)
			{
				tc_strcat(AllModuleString,trimString(strModuleInfo4));
			}
			if(tc_strlen(strModuleInfo5) >  5)
			{
				tc_strcat(AllModuleString,trimString(strModuleInfo5));
			}
			if(tc_strlen(strModuleInfo6) >  5)
			{
				tc_strcat(AllModuleString,trimString(strModuleInfo6));
			}
			
			tc_strdup(AllModuleString,&AllModuleStringDup);
			trimString(AllModuleStringDup);
			//printf("\nAllModuleStringDup:[%s]\n",AllModuleStringDup);fflush(stdout);
			
			if(ModuleGroup != NULL && AllModuleStringDup != NULL)
			{
				int tokenCount = 0;
				char **tokens = tokenize(AllModuleStringDup, &tokenCount);
				
				if (!tokens) 
				{
					printf("Tokenization failed.\n");
				}
				
				for (int j = 0; j < tokenCount; j++) 
				{
					char* Module = NULL;
					char* ModuleAddress = NULL;
					char* ModuleAddressDup = NULL;
					char* DesignGroup = NULL;
					
					if(tokens[j] == NULL)
					{
						continue;
					}
					
					tc_strdup(tokens[j],&Module);
					ModuleAddress = getModuleAddress(AggregateGrp,Aggregates,ModuleGroup,Module);
					tc_strdup(ModuleAddress,&ModuleAddressDup);
					
					
					//Get the Design group				
					ifail = getDesignGroup(ModuleAddressDup,&DesignGroup);
					
					//printf("Token %d: %s, Module:[%s], ModuleAddress[%s], Design Group:[%s]\n", j, tokens[j],Module,ModuleAddress,DesignGroup);fflush(stdout);
					
					
					//Build the array of structure
					char* AggregateGroupDup = NULL;
					char* AggregateDup = NULL;
					char* ModuleGroupDup = NULL;
					char* ModuleDup = NULL;
					//char* ModuleAddressDup1 = NULL;
					char* DesignGroupDup = NULL;				
					ModuleSchemaRepModel moduleScheRepMdl;
					
					tc_strdup(AggregateGrp,&AggregateGroupDup);
					tc_strdup(Aggregates,&AggregateDup);
					tc_strdup(ModuleGroup,&ModuleGroupDup);
					tc_strdup(Module,&ModuleDup);
					tc_strdup(DesignGroup,&DesignGroupDup);
					moduleScheRepMdl.AggregateGroup = AggregateGroupDup;
					moduleScheRepMdl.Aggregate = AggregateDup;
					moduleScheRepMdl.ModuleGroup = ModuleGroupDup;
					moduleScheRepMdl.Module = ModuleDup;
					moduleScheRepMdl.ModuleAddress = ModuleAddressDup;
					
					moduleScheRepMdl.DesignGroup = DesignGroupDup;
					
					setAddModuleSchemaRepModel(&moduleSchRepModelListCnt,&moduleSchRepModelList,moduleScheRepMdl);
					
					
					if(ModuleAddress != NULL) free(ModuleAddress);
				}

				free_tokens(tokens, tokenCount);
			}
			
			if(AllModuleString)
			{
				MEM_free(AllModuleString);
			}
		}
		
		
		
		
		
	}
	
	
	
	printf("\nModule Schema Report record count:[%d]\n",moduleSchRepModelListCnt);fflush(stdout);
	
	//Generate Filename
	time_t now;
	struct tm* now_tm;
	char CurrDateTime_str[26] = {'\0'};
	
	char DataSetName[300]        = "Module Naming Schema Report";
	char reportFileLoc[280];
	
	
	
	time(&now);
	now_tm = localtime(&now);
	strftime (CurrDateTime_str, 26, "%d_%m_%Y_%H_%M_%S", now_tm);
	//printf("\n CurrDateTime_str is===>[%s]",CurrDateTime_str);fflush(stdout);
	strcat(DataSetName,CurrDateTime_str );
    printf("\n Data Set Name = %s\n",DataSetName);fflush(stdout);
    sprintf(reportFileLoc,"%s_output.xls",CurrDateTime_str);
	
	FILE *fp;
	
	fp = fopen(reportFileLoc, "w");
	if(fp!=NULL)
	{
		char DateStr[100] = "";
		int k =0;
		strftime(DateStr,100,"%d-%m-%Y",now_tm);
		printf("\n %s Date\n",DateStr);
		 
		fprintf(fp,"Module Schema Report %s\n",DateStr);fflush(fp);
		fprintf(fp,"Aggregate Group \t Aggregate \t Module Group \t  Module \t  Module Address \t Design Group \t \n");fflush(fp);
		
		for(k=0;k<moduleSchRepModelListCnt;k++)
		{
			ModuleSchemaRepModel repMdl;
			repMdl = moduleSchRepModelList[k];
			fprintf(fp,"%s \t %s \t %s \t  %s \t  %s \t %s \t \n",repMdl.AggregateGroup,repMdl.Aggregate,repMdl.ModuleGroup,repMdl.Module,repMdl.ModuleAddress,repMdl.DesignGroup);fflush(fp);
		}
		 
		 
		 
	}
	else
	{
		printf("\nError in opening file!!!\n");fflush(stdout);
	}
	
	
	if(fp)fclose(fp);
	
	//Dataset structure
	tag_t           msWordType              = NULLTAG;
	tag_t           wordDataset             = NULLTAG;
	tag_t           wordLatestDat_t         = NULLTAG;	
    
	printf("\nGoing for creation of dataset\n");fflush(stdout);
	if(AE_find_datasettype2("MSExcel",&msWordType)!=ITK_ok)PrintErrorStack();
	if(msWordType == NULLTAG)
	{
		printf("\n Could not find Dataset\n");fflush(stdout);
	}
	else
	{
		printf("Dataset Type Fond");fflush(stdout);
	}
	printf("\n File Path %s\n",reportFileLoc);fflush(stdout);
	
	ifail = AE_create_dataset_with_id(msWordType,DataSetName,"ModuleNamingSchema","","",&wordDataset);
	ifail = AE_save_myself(wordDataset);
	ifail = AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t);
	ifail = AOM_refresh(wordLatestDat_t,TRUE);
	ifail = AE_import_named_ref(wordLatestDat_t,"excel",reportFileLoc,NULL,SS_BINARY);
	ifail = AOM_save_without_extensions(wordLatestDat_t);
	ifail = AOM_refresh(wordLatestDat_t, FALSE);
	
	// Attach the dataset to the Folder - "Module Schema Reports"
	tag_t qryTag = NULLTAG;
	ifail = QRY_find2("folder custom", &qryTag);
	if (qryTag != NULLTAG)
	{
		int rsltCount = 0;
		tag_t* CntrolObjectTag = NULL;
		qry_entries[0] = "Name";
		qry_values[0] = "Module Schema Reports";
		ifail = QRY_execute(qryTag, 1, qry_entries, qry_values, &rsltCount, &CntrolObjectTag);
		printf("\t  rsltCount for folder:%d:", rsltCount); fflush(stdout);
		if(rsltCount > 0)
		{

			ifail = AOM_lock(CntrolObjectTag[0]);
			ifail = FL_insert(CntrolObjectTag[0],wordLatestDat_t,999);
			ifail = AOM_save_without_extensions(CntrolObjectTag[0]);
			ifail = AOM_unlock(CntrolObjectTag[0]);
			ifail = AOM_refresh(CntrolObjectTag[0],0);
			

		}
	}
	
	printf("\n********************END OF PROGRAM ******************************\n");fflush(stdout);
	return ifail;
	
}