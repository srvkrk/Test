/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Ketan Bhut
*  Module		 :   MBOM DML Stamping through CC
*  Code			 :   MBOM_DML_Stamping.c
*  Created on	 :   Aug 23, 2023
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <time.h>
#include <sys/stat.h>


#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

char* subString_mbom (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

void getCurrentDateTime_CC(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr2;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime_CC calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr2 = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr2);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr2->tm_mday));
	printf("Month:%d\n",(timeptr2->tm_mon)+1);
	printf("Year:%d\n",(timeptr2->tm_year+1900));
	fflush(stdout);
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

void getDesignType_CC(tag_t Item, char	**designBORev, char **designBO)
{
	//char	*type_class					=	NULL;
	int		n_parents					=	0;
	tag_t	itemTypeTag_class			=	NULLTAG;
	tag_t	*parents					=	NULLTAG;
	tag_t	parent						=	NULLTAG;

	printf("Inside getDesignType_CC...!!!");
	
	ITKCALL (TCTYPE_ask_object_type(Item,&itemTypeTag_class));
	ITKCALL (TCTYPE_ask_name2(itemTypeTag_class,designBORev));
	
	printf("\t  type_itemRev ...%s\n", *designBORev);
	//*designBO= (char *) MEM_alloc(tc_strlen(*designBORev) * sizeof(char *) +5);

	ITKCALL (AOM_ask_value_tags(Item,"items_tag",&n_parents,&parents));
	printf("\t  type_item n_parents ...%d\n", n_parents);
	if (n_parents==1)
	{
		parent	=	parents[0];
		
		ITKCALL (TCTYPE_ask_object_type(parent,&itemTypeTag_class));
		ITKCALL (TCTYPE_ask_name2(itemTypeTag_class,designBO));
	
		printf("\t  type_itemRev ...%s\n", *designBO);
		
	}
	else
	{
		printf("\nMore than one item tag return...!!!");fflush(stdout);
	}
	
	printf("\t  type_itemRev ...%s, BO CLASS : %s\n", *designBORev,*designBO);

}

int tm_check_SOR_MBOMDML_Val_control_object_CC ( char *syscd, char *subsyscd )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	ITKCALL ( QRY_find ( "ControlObjQry", &query ) ) ;
	ITKCALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
	printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
	

	printf ("\n--------------tm_check_SOR_MBOMDML_Val_control_object_CC=Completed--------------------\n");fflush(stdout);
	return n_found ;
}

static int t5UpdateLifecycleStateMBOM(tag_t object_tag, char* lifecycleStateName)
{
	int		status;

	int n_values_checkin	= 0;
	int cunt1				= 0;
	int flag				= 0;
	int	ifail				= 0;
	int st_count1			= 0;

	date_t*	start_end_date	= NULL;
	
	date_t	test_date_1;
	date_t	test_date_2;
	
    char*	value					=NULL;
	char	cNextDate[20]={0};

	char *class_name	 = NULL;
	char *Release_Status = NULL;

	tag_t		class_id					= NULLTAG;
	tag_t		tReleaseStatusList_checkin	= NULLTAG;
	tag_t*		attr_tags_checkin			= NULLTAG;
	tag_t		status_rel					= NULLTAG;
	tag_t*		status_list1				= NULLTAG;
	tag_t    	propEff_tag				    = NULLTAG;
	tag_t		eff_d						= NULLTAG;

	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	logical		log1;
	logical		checkout1;
	logical		retain							= 0;
	logical		stat;

	printf("\n Ketan Inside t5UpdateLifecycleStateMBOM \n");

	ITK_CALL(POM_class_of_instance(object_tag,&class_id));
	ITK_CALL(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
	ITK_CALL(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
	printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

	ITK_CALL(POM_unload_instances (1,&object_tag));
	ITK_CALL(POM_load_instances(1,&object_tag,class_id,1));
	ITK_CALL(POM_is_loaded(object_tag,&log1));
	if(log1 == 1)
	{
		 printf("\n Load Success \n");
	}
	else
	{
		printf("\n Load Failure \n");
	}

	ITK_CALL( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
	printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);
	if(n_values_checkin>0)
	{
		ITK_CALL( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
		printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
        flag = 0;
		for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
		{
			printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
			if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
		    printf("\n  Release_Status changes done: for workspaceobject     %s\n", Release_Status);fflush(stdout);
            if(tc_strcmp(lifecycleStateName,"T5_MBOMReleased")==0)
            {
				if(tc_strcmp(Release_Status,"T5_MBOMReview")==0 || (tc_strcmp(Release_Status,"T5_MBOMWorking")==0) || (strcmp(Release_Status,"MBOM Review")==0) || (strcmp(Release_Status,"MBOM Working")==0))
				{
					ITK_CALL(POM_unload_instances (1,&object_tag));
					ITK_CALL(POM_load_instances(1,&object_tag,class_id,1));
					ITK_CALL(POM_is_loaded(object_tag,&log1));

					ITK_CALL(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
					printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

					ITK_CALL(POM_save_instances(1,&object_tag,1));

					ITK_CALL(POM_refresh_instances(1,&object_tag,class_id,2));

					ITK_CALL(AOM_lock(object_tag));

					ITK_CALL(AOM_save(object_tag));
					ITK_CALL(AOM_refresh(object_tag,1));
					ITK_CALL(AOM_unlock(object_tag));

				}
				else
				{
					flag = flag+1;
				}
			}
			

		}

	}

	if (CR_create_release_status(lifecycleStateName,&status_rel));
	if(EPM_add_release_status(status_rel,1,&object_tag,retain));
	/*
	if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 )
	{
		ITK_CALL(WSOM_ask_effectivity_mode(&stat));

		ITK_CALL(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
		ITK_CALL(PROP_ask_value_string(propEff_tag,&value));

		getNextDate(cNextDate);
		printf("\n cNextDate:%s",cNextDate);

		ITK_CALL(ITK_string_to_date(cNextDate, &test_date_1 ));
		ITK_CALL(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		ITK_CALL(WSOM_status_clear_effectivities (status_rel));
		ITK_CALL(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		ITK_CALL(AOM_save(eff_d));
		ITK_CALL(AOM_save(status_rel));
		ITK_CALL(AOM_refresh(status_rel,0));
	}*/
	
	char*	PreRevOnly			= NULL;
	char*	RevOnly				= NULL;
	char*	Part_Rev			= NULL;
	char*	Part_Rev_copy		= NULL;
	char*	Part_rev_Id			= NULL;
	char*	PlantLCSFlag		= NULL;
	char*	Part_clr_ind		= NULL;
	char*	Part_no				= NULL;
	char*	old_to_date			= NULL;
	char*	WSO_Name			= NULL;
	char cCurrentAccessDate[20]={0};

	const char *qry_entries[2];	// Multiple Item Queried Error
	const char *qry_values[2];	// Multiple Item Queried Error

	tag_t*	itemclassp			= NULLTAG;
	tag_t	item				= NULLTAG;
	tag_t*	rev_list			= NULL;
	tag_t	Leff_d				= NULLTAG;
	tag_t*	effectivities_tag	= NULL;
	tag_t*  status_list;
	
	int		Item_count      = 0;
	int     ii				= 0;
	int     RevFlag			= 0;
	int     PreRevFlag		= 0;
	int     st_count		= 0;
	int     iLCS			= 0;
	int     cntLcs			= 0;
	int		n_tags_found	= 0;
	int		jj 				= 0;
	int		n_effectivities = 0;
	int		n_dates		 	= 0;
    
	date_t	Ltest_date_1;
	date_t	Ltest_date_2;
	date_t*	Rel_start_end_values	= NULL;
	date_t*	Lstart_end_date			= NULL;

	logical date_is_valid;

	WSOM_open_ended_status_t  	open_ended_or_stock_out;

	//if ((tc_strcmp(class_name,"T5_APLDMLRevision")!=0) && (tc_strcmp(class_name,"T5_APLTaskRevision")!=0) && (tc_strcmp(class_name,"T5_EPARevision")!=0) && (tc_strcmp(class_name,"T5_EPATaskRevision")!=0))
	if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 || tc_strcmp(class_name,"T5_ClrPartRevision")==0 )
	{
		
		ITK_CALL(WSOM_ask_effectivity_mode(&stat));

		//	getCurrentDateTime_CC(cCurrentAccessDate);
		ITK_CALL(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
		ITK_CALL(PROP_ask_value_string(propEff_tag,&value));

		getNextDate(cNextDate);
		printf("\n cNextDate:%s",cNextDate);

		ITK_CALL(ITK_string_to_date(cNextDate, &test_date_1 ));
		ITK_CALL(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		ITK_CALL(WSOM_status_clear_effectivities (status_rel));
		ITK_CALL(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		ITK_CALL(AOM_save(eff_d));
		ITK_CALL(AOM_save(status_rel));
		ITK_CALL(AOM_refresh(status_rel,0));

         // Start Privious Rev and stamp the close date
		 ITK_CALL(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev));
		 ITK_CALL(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev_copy));
		 printf("\n Part_Rev: %s", Part_Rev);fflush(stdout);
		 printf("\n Part_Rev_copy: %s", Part_Rev_copy);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(object_tag,"item_id",&Part_no));
		printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
		Part_clr_ind	=	NULL;
		ITK_CALL(AOM_ask_value_string(object_tag,"t5_ColourInd",&Part_clr_ind));
		printf("\n\n\t\t Part_clr_ind  is :%s",Part_clr_ind);	fflush(stdout);

		qry_entries[0] ="item_id";
		qry_entries[1] ="object_type";//Multiple Item Queried Error
		qry_values[0] = Part_no;
		if (tc_strcmp(Part_clr_ind,"C")==0)
		{
			qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
		}
		else
		{
			//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
			//Handle the different design child class.
			char	*designBORev		=	NULL;
			char	*designBO			=	NULL;
			tag_t	AssyTag			=	NULLTAG;
			//AssyTag=PartTags[k];
			printf("\nBefore getDesignType_CC");fflush(stdout);
			getDesignType_CC(object_tag, &designBORev,&designBO);
			printf("\nAfter getDesignType_CC : %s",designBO);fflush(stdout);
			qry_values[1] = designBO;

		}//Multiple Item Queried Error
		//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
		ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
		//ITKCALL(ITEM_find_item(Part_no,&itemclassp));
		item = itemclassp[0];

		ITK_CALL(ITEM_list_all_revs (item, &Item_count, &rev_list));
		printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
			if(Item_count > 0)
			{
				RevFlag = 0;
				PreRevFlag = 0;
				for(ii=Item_count-1;ii>=0;ii--)
				{
				   RevOnly = NULL;
				   PreRevOnly = NULL;
				   ITK_CALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
					printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
					if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
					{
						RevFlag = 1;
					}
					printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
					if(RevFlag == 1)
					{
					   RevOnly= strtok( Part_Rev_copy, ";" );
					   PreRevOnly= strtok( Part_rev_Id, ";" );
					   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
					   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
					   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
						{
						  PreRevFlag = 1;
						}
					}
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					if(PreRevFlag == 1)
					{
						ITK_CALL(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
						if(st_count == 0)
						{
						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
						break;
						}
						else
						{
							for (iLCS=0;iLCS<st_count ;iLCS++ )
							{
									ITK_CALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);
									//if(tc_strcmp(PlantLCSFlag,"CAR")==0)
									//{
									if(tc_strcmp(class_name,lifecycleStateName)==0)
									{
										getCurrentDateTime_CC(cCurrentAccessDate);
										printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
										if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
										{
											return ifail;
										}
										if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_list[iLCS],&n_effectivities, &effectivities_tag) )) return ifail;
										printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
										if(n_effectivities > 0)
										{
											for(jj=0;jj<n_effectivities;jj++)
											{
												if(ITK_ok != (ifail = WSOM_effectivity_ask_dates(effectivities_tag[jj],&n_dates,&Rel_start_end_values,&open_ended_or_stock_out )))return ifail;
												printf("\n Eff:no of Rel_start_end_value:%d\n", n_dates);fflush(stdout);
												if(n_dates > 0)
												{
													if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
													{
														return ifail;
													}
													printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
													if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
													{
														return ifail;
													}
													printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
													if(date_is_valid != true)
													{
														printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
													}
													else
													{
														printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
													}
												}
												else
												{
													printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
												}
											}
											
											// //
											// printf("\n KEtan update Value\n");fflush(stdout);
											// 
											// ITK_CALL(ITK_string_to_date("25-Jul-2023 00:00", &Ltest_date_1 ));
											// ITK_CALL(ITK_string_to_date("28-Jul-2023 00:00", &Ltest_date_2 ));
											// 
											// //
											Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
											Lstart_end_date[0] = Ltest_date_1;
											Lstart_end_date[1] = Ltest_date_2;

											printf("\n ERCReview--EFF:Clearing effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = WSOM_status_clear_effectivities (status_list[iLCS])))
											{
												return ifail;
											}

											printf("\n ERCReview--EFF:Creating effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_list[iLCS], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Saving effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_save(Leff_d)))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Saving Revision...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_save(status_list[iLCS])))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Refreshing Revision...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_refresh( status_list[iLCS], 0 )))
											{
												return ifail;
											}
										}
										
										break;

									}
							}
						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
						break;
						}
					}  /// End Prev Rev  Flag Loop
				}
			} /// End Prev Rev

	}



	return 0;
}

/*******MAIN FUNCTION************/

extern int ITK_user_main (int argc, char ** argv )
{
	// 
	int		status;
	int max_char_size = 80;
	tag_t			rootTask				=NULLTAG;
	char		*CurrentTask					= NULL;
	char       *parent_name				=NULL;
	char       *Proj_Code				=NULL;
	char*			Part_no				= NULL;
	char*			PartTypeStr			= NULL;
	char*			type_name1			= NULL;
	char*			DML_Num				= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	int n_tags_found = 0;
	tag_t			*attachments			=NULLTAG;
	int   ifail				= 0;
    char* lcsToset=NULL;
	tag_t   status2=NULLTAG;
	logical retain=false;


	int
	error_code	= ITK_ok,
	n_entries	= 2,
	n_found		= 0,
	num=0,
	i=0,
	j=0,
	ii			= 0;
	tag_t
	query			= NULLTAG,
	*cntr_objects	= NULL,
	objTypeTag=NULLTAG,
	objErcTypeTag=NULLTAG,
	item=NULLTAG,
	rev=NULLTAG,
	user			= NULLTAG;
	char *item_id 	   = NULL;
	char *PlantName 	   = NULL;
	tag_t *tags_found = NULL;
	int	  noAttachment,noTaskAttachment 	= 0;
	tag_t DMLTag = NULLTAG;

	tag_t			item_apl					=NULLTAG;
	tag_t			rev_apl					=NULLTAG;
	tag_t			APLDRevTypeTag		= NULLTAG;
	tag_t			APLDRevCreInTag		= NULLTAG;
	tag_t			TaskSVRRevisionTag		= NULLTAG;
	tag_t*			TaskRevision		= NULLTAG;
	tag_t*			TaskSVRRevision		= NULLTAG;
	tag_t*			ERCDMLRevision		= NULLTAG;
	tag_t*			PartTags			= NULLTAG;

	char**			stringArrayAPLD		= NULL;
	char**			stringArrayAPLT		= NULL;
	int			    	n_strings			= 1;
	char*			object_type			= NULL;
	 char FrmNextDate[20]="2016/10/12";
	 char ToNextDate[20]="9999/12/31";


	//char *item_id_dup 	   = NULL;
	int   apl_task_number_found;
	int  apl_number_found;
	int * erc_number_found;
	int  control_number_found;

	tag_t *list_of_WSO_tags=NULLTAG;
	tag_t *list_of_WSO_erc_tags=NULLTAG;
	tag_t *list_of_WSO_cntrl_tags=NULLTAG;
	tag_t			APLDTypeTag			= NULLTAG;
	tag_t			APLDCreInTag		= NULLTAG;
	tag_t			APLDMLTag			= NULLTAG;
	tag_t			TaskRevTag			= NULLTAG;
	tag_t			tsk_part_sol_rel_type= NULLTAG;
	tag_t			DerivedsvrRelationTAG= NULLTAG;
	tag_t			AssyTag				= NULLTAG;
	tag_t			ERCDMLTag				= NULLTAG;
	tag_t			tsk_part_APL_rel	= NULLTAG;
	date_t Release_date;


	int				index				= 0;
	int				l_strings			= 80;
	char*			tempStringt			= NULL;
	char*			APL_Task_No			= NULL;
	int				count				= 0;
	int				countSVR				= 0;
	int				count_erc			= 0;
	int				TaskCnt				= 0;
	int				PartCnt				= 0;
	int				AttCnt				= 0;
	int				k					= 0;
    int 	n_instances =1;
	tag_t			APLDMLRevTag		= NULLTAG;
	tag_t			APLTTypeTag			= NULLTAG;
	tag_t			APLTCreInTag		= NULLTAG;
	tag_t			APLTRevTypeTag		= NULLTAG;
	tag_t			APLTRevCreInTag		= NULLTAG;
	tag_t			APLTaskTag			= NULLTAG;
	tag_t			APLTaskRevTag		= NULLTAG;
	tag_t         Fndrelation = NULLTAG;
     tag_t 	  *ReleaseDateTgs = NULLTAG;
     tag_t 	  ReleaseDateTg = NULLTAG;
	char *item_erc_id_dup = (char *)MEM_alloc(max_char_size * sizeof(char));
	char *item_erc_id_dup1 = (char *)MEM_alloc(max_char_size * sizeof(char));
	char*			tempString			= NULL;
     logical * 	date_is_valid  = false;
	char cCurrentAccessDate[20]={0};
	char   *ReleaseStatus=NULL;
	char *item_name   = NULL;
	char *Design_group = NULL;
	char *RlsType = NULL;
	char *DML_no = NULL;
	char **DesignGroupList;
	char   type_name[TCTYPE_name_size_c+1];
	char   type_name_erc[TCTYPE_name_size_c+1];
	tag_t	relation_type,relation	,propTag	= NULLTAG;
	tag_t  aplrelation = NULLTAG;
	tag_t  apltaskrelation = NULLTAG;
	WSO_search_criteria_t  	criteria;
	WSO_search_criteria_t  	criteria_erc;
	WSO_search_criteria_t  	criteria_control;
	char AplRlzdLc[40] ;
	char AplRvwLC[40];//TZ3.46
	char AplWrkngLC[40];	
	char Stdwrknglc[40];
	char Stdrlzdlc[40];
	char PltLcs[40];
	char StdPlant[40];
	char StdRevRule[40];
	char StdCLosRule[40];
	char StdView[40];
	char	*parttype=NULL;

	/********************AutoSor Priyanka*******************/

	tag_t status_Part_SOR_Tag	   = NULLTAG;
	tag_t status_part_SOR_Rel	   = NULLTAG;
	tag_t *status_part_SOR_objects = NULLTAG;
	int status_part_SOR_cnt = 0;
	int status_prt_c		= 0;
	char *status_part_SOR_num          = NULL;
	char *status_rel_part_SOR          = NULL;
	int SOR_MBOMDML_Val = 0;
	int AutoSorFlag = 0;
	/********************AutoSor Priyanka*******************/

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));



	//
	
	char*	inputDML			= NULL;
	
	tag_t	DMLNo					= NULLTAG;
	
	inputDML	   = ITK_ask_cli_argument("-dml=");
	//inputDate	   = ITK_ask_cli_argument("-date=");

	printf("\n Test 1 \n");fflush(stdout);

	ITK_CALL( ITK_init_module("infodba","APLinfo2020","dba"));	// for tcuaadev
	//ITK_CALL( ITK_init_module("loader","loader123","dba"));	// for production
	

	printf("\n Test 2 \n");fflush(stdout);
	ITK_CALL(ITEM_find_item(inputDML,&DMLNo));
	
	ITK_CALL(ITEM_ask_latest_rev(DMLNo,&DMLTag));

	if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
	if(TCTYPE_ask_name(objTypeTag,type_name));
	printf("\n type_name changes done: for workspaceobject %s\n", type_name);fflush(stdout);

	if(strcmp(type_name,"T5_MBOMDMLRevision")==0)
	{
		    printf("\n inside class T5_MBOMDMLRevision......\n");fflush(stdout);
			AOM_ask_value_string( DMLTag, "item_id", &item_id);
			AOM_ask_value_string( DMLTag, "current_id", &DML_no);
			AOM_ask_value_strings(DMLTag,"t5_crdesigngroup",&num,&DesignGroupList);
			AOM_ask_value_string(DMLTag,"t5_MBOMRlzType",&RlsType);
			AOM_ask_value_string( DMLTag, "t5_cprojectcode", &Proj_Code);


   			DML_Num=tc_strtok(DML_no,"_");
			printf("\nTest0.11..DML_Num:[%s],[%s]\n",DML_Num,DML_no);
			PLT_Code = tc_strtok(NULL,"_");
			printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,DML_no);

			strcpy(lcsToset,"T5_MBOMReleased");

			getCurrentDateTime_CC(cCurrentAccessDate);
			printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
		    ITK_CALL(ITK_string_to_date(cCurrentAccessDate, &Release_date ));
     	  
			printf("\n Proj_Code : %s\n",Proj_Code);fflush(stdout);
			printf("\n item_id : %s\n",item_id);fflush(stdout);
			printf("\n DML_no : %s\n",DML_no);fflush(stdout);
			printf("\n RlsType : %s\n",RlsType);fflush(stdout);
			printf("\n num is : %d\n",num);fflush(stdout);
			printf("\n Item created first time only with item_id \n");fflush(stdout);

			if (DMLTag != NULLTAG)
			{
				GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
						
				ITK_CALL(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
				
				printf("\n MBOM DML to Task Count : %d",count);fflush(stdout);
				TaskRevTag = TaskRevision[TaskCnt];
				for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
				{
					TaskRevTag = TaskRevision[TaskCnt];

					//counted_tag_list_t tlNewTargets = {0};
					//int initial_tag_list_size = 16; // Reference PR-8968371 // 26062023
					//tlNewTargets.list = (tag_t *)MEM_alloc(initial_tag_list_size * (sizeof(tag_t)));

					//ITK_CALL(EPM__add_to_tag_list(TaskRevTag, &tlNewTargets));

					ITK_CALL(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
					printf("\n object_type is :%s",object_type);fflush(stdout);
					if(strcmp(object_type,"T5_MBOMTASKRevision")==0)
					{
						PartCnt=0;

						printf("\n Task Stamping \n");fflush(stdout);
						status = t5UpdateLifecycleStateMBOM(TaskRevTag, lcsToset);

						ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
						printf("\n MBOM Task DML PartCnt: %d",PartCnt);fflush(stdout);
						if (PartCnt>0)
						{
							GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
							for (k=0;k<PartCnt ;k++ )
							{
								printf("\n MBOM DML for k =:%d",k);fflush(stdout);
								AssyTag=PartTags[k];

								ITK_CALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
								printf("\n MBOM DML Part_no is :%s",Part_no);	fflush(stdout);

								ITK_CALL(AOM_ask_value_string(AssyTag,"t5_PartType",&parttype));
								printf("\n MBOM DML Parttype  is :%s",parttype);	fflush(stdout);

								if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
								if(TCTYPE_ask_name2(objTypeTag,&type_name1));
								printf("\n MBOM DML AssyTag type_name1 := %s", type_name1);fflush(stdout);

								ITK_CALL(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
								printf("\n MBOM DML AssyTag PartTypeStr := %s", PartTypeStr);fflush(stdout);

								//ITK_CALL(EPM__add_to_tag_list(AssyTag, &tlNewTargets));
								//printf("\n Test 1  \n");fflush(stdout);

								printf("\n Part Stamping \n");fflush(stdout);
								status = t5UpdateLifecycleStateMBOM(AssyTag, lcsToset);

								/***************Auto SOR Stamping Priyanka*************************************/
								
								SOR_MBOMDML_Val = 0;
								SOR_MBOMDML_Val = tm_check_SOR_MBOMDML_Val_control_object_CC ( "AUTOSORMBOM" , "ON" );
								if ( SOR_MBOMDML_Val > 0)
								{
									status_Part_SOR_Tag	   = NULLTAG;
									status_part_SOR_Rel	   = NULLTAG;
									status_part_SOR_objects = NULLTAG;
									status_part_SOR_cnt = 0;
									status_prt_c		= 0;
									status_part_SOR_num          = NULL;
									status_rel_part_SOR          = NULL;

								ITK_CALL(GRM_find_relation_type("T5_PartSorRel",&status_part_SOR_Rel));
								printf("\nExpanding Part to MBOM SOR relation");fflush(stdout);
								ITK_CALL(GRM_list_secondary_objects_only(AssyTag, status_part_SOR_Rel, &status_part_SOR_cnt, &status_part_SOR_objects));
								printf("\n status_part_MBOMSOR_cnt : [%d]\n",status_part_SOR_cnt);fflush(stdout);
								if ( status_part_SOR_cnt > 0)
									{
										for ( status_prt_c = 0; status_prt_c < status_part_SOR_cnt; status_prt_c++ )
										{
											status_Part_SOR_Tag= status_part_SOR_objects[status_prt_c];
											ITK_CALL(AOM_UIF_ask_value(status_Part_SOR_Tag,"item_id",&status_part_SOR_num));
											ITK_CALL(AOM_UIF_ask_value(status_Part_SOR_Tag,"release_status_list",&status_rel_part_SOR));
											printf("\nstatus_part_MBOMSOR_num : [%s]\tstatus_rel_part_MBOMSOR : [%s]",status_part_SOR_num,status_rel_part_SOR);fflush(stdout);
											if((tc_strcmp ( status_rel_part_SOR,"MBOM Working" )==0) || (tc_strcmp( status_rel_part_SOR,"T5_MBOMWorking" )==0) || (tc_strcmp ( status_rel_part_SOR,"MBOM Review" )==0) || (tc_strcmp( status_rel_part_SOR,"T5_MBOMReview" )==0))
											{
												printf("\n Inside Autosor stamping \n");fflush(stdout);
												AutoSorFlag = 1;
												break;
											}
										}
									}
									if(AutoSorFlag == 1)
									{
											//printf("\n Inside AutoSorFlag \n");fflush(stdout);
											//ITK_CALL(EPM__add_to_tag_list(status_Part_SOR_Tag, &tlNewTargets));

											printf("\n Autosor Stamping \n");fflush(stdout);
											status = t5UpdateLifecycleStateMBOM(status_Part_SOR_Tag, lcsToset);
									}
								}
								else 
								{
									printf("\nControl object not present for AUTOSORMBOM,ON");fflush(stdout);
								}


								/***************Auto SOR Stamping Priyanka*************************************/

								// Ketan Added for Dataset // 01072023

								int		dataset_count		= 0;
								int		i_dataset			= 0;
								int		datset_st_count1	= 0;
								int		data_cnt			= 0;
								int		DatasetFlag			= 0;

								tag_t*	dataset_secObjsList		= NULLTAG;
								tag_t	Dataset_Tag_Name		= NULLTAG;
								tag_t	dataset_objNameType		= NULLTAG;
								tag_t*  dataset_status_list1	= NULLTAG;

								char*	DatasetNameOfObjTyp = NULL;
								char*   dataset_WSO_Name	= NULL;
								
								ITK_CALL(GRM_list_secondary_objects_only(AssyTag, NULLTAG, &dataset_count, &dataset_secObjsList));
								printf("\n dataset_count ==> [%d]\n", dataset_count);fflush(stdout);

								if (dataset_count > 0)
								{
									for (i_dataset=0;i_dataset<dataset_count;i_dataset++ )
									{
										Dataset_Tag_Name= dataset_secObjsList[i_dataset];
										TCTYPE_ask_object_type(Dataset_Tag_Name,&dataset_objNameType);
										if(dataset_objNameType != NULLTAG)
										{
											TCTYPE_ask_name2(dataset_objNameType,&DatasetNameOfObjTyp);
											printf("\n[%d]Sec Object Type is %s \n",i_dataset,DatasetNameOfObjTyp);fflush(stdout);
											if ((tc_strcmp(DatasetNameOfObjTyp,"CMI2Product")==0) ||(tc_strcmp(DatasetNameOfObjTyp,"CMI2Part")==0)||(tc_strcmp(DatasetNameOfObjTyp,"CMI2Drawing")==0)||(tc_strcmp(DatasetNameOfObjTyp,"DirectModel")==0)||(tc_strcmp(DatasetNameOfObjTyp,"ProAsm")==0)||
													(tc_strcmp(DatasetNameOfObjTyp,"ProPrt")==0)||(tc_strcmp(DatasetNameOfObjTyp,"ProDrw")==0)||(tc_strcmp(DatasetNameOfObjTyp,"PDF")==0))
											{
												printf("\n Found Sec obj is of type ::[%s]\n", DatasetNameOfObjTyp);fflush(stdout);

												ITK_CALL(WSOM_ask_release_status_list(Dataset_Tag_Name,&datset_st_count1,&dataset_status_list1));
												printf("\n datset_st_count1 :%d is\n",datset_st_count1);fflush(stdout);
												
												DatasetFlag	= 0;

												if(datset_st_count1>0)
												{
													for (data_cnt=0;data_cnt< datset_st_count1;data_cnt++ )
													{
														dataset_WSO_Name=NULL;
														ITK_CALL(AOM_ask_name(dataset_status_list1[data_cnt],&dataset_WSO_Name));
														printf("\n dataset_WSO_Name => :%s\n",dataset_WSO_Name);fflush(stdout);
														if(tc_strcmp(dataset_WSO_Name,"")!=0)
															{
																if ((tc_strcmp(dataset_WSO_Name,"T5_MBOMWorking")==0) || (tc_strcmp(dataset_WSO_Name,"T5_MBOMReview")==0) )
																{
																	printf("\n Inside dataset_WSO_Name \n");fflush(stdout);
																	DatasetFlag = 1;
																	break;
																}
															}
													}
												}
												if(DatasetFlag == 1)
												{
													//printf("\n Inside DatasetFlag \n");fflush(stdout);
													//ITK_CALL(EPM__add_to_tag_list(Dataset_Tag_Name, &tlNewTargets));

													printf("\n Dataset Stamping \n");fflush(stdout);
													status = t5UpdateLifecycleStateMBOM(Dataset_Tag_Name, lcsToset);
												}
												
											}
										}
									}
								}

								// Ketan Ended

								//printf("\n Assy Stamping \n");fflush(stdout);
								//status = t5UpdateLifecycleStateMBOM(AssyTag, lcsToset);
								
							}
						}
							// printf("\n Test 2  \n");fflush(stdout);
							// int *piAttachTypes = NULL;
							// int ii = 0;
							// piAttachTypes = (int *) MEM_alloc (tlNewTargets.count * sizeof(int));
							// for (ii = 0; ii < tlNewTargets.count; ii++)
							// {
							// 	printf("\n Test 2.1  \n");fflush(stdout);
							// 	piAttachTypes[ii] = EPM_target_attachment;
							// }
							// printf("\n Test 4  \n");fflush(stdout);
							// ITK_CALL(AOM_refresh(rootTask, TRUE));
							// printf("\n Test 3 \n");fflush(stdout);
							// 
							// ITK_CALL(EPM_add_attachments(rootTask, tlNewTargets.count, tlNewTargets.list, piAttachTypes));
							// printf("\n Test 5  \n");fflush(stdout);
							// 
							// if(piAttachTypes) MEM_free(piAttachTypes);
							// 
							// ITK_CALL(AOM_save(rootTask));
							// printf("\n Test 6  \n");fflush(stdout);
							// 
							// for (ii = 0; ii < tlNewTargets.count; ii++)
							// {
							// 	printf("\n Stamping : %d\n",ii);fflush(stdout);
							// 	status = t5UpdateLifecycleStateMBOM(tlNewTargets.list[ii], lcsToset);
							// 
							// }
							// printf("\n Test 7  \n");fflush(stdout);
							// ITK_CALL(EPM_remove_attachments(rootTask,tlNewTargets.count,tlNewTargets.list));
							// printf("\n Test 8 \n");fflush(stdout);
							
						//}
						
					}

				}  /// Solution Item end
						   
			printf("\n DML Stamping \n");fflush(stdout);
			status = t5UpdateLifecycleStateMBOM(DMLTag, lcsToset); //DML status stamped thru workflow.
			}

	}
	else
	{
	  	printf("\n No proper class class T5_MBOMDMLRevision......\n");fflush(stdout);
	}
	
	
	printf("----------- MBOM DML Stamped Successfully -----------------------------------------\n");fflush(stdout);

return status;
   
}
 
