/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                :   Rupali Rane
*  Module                :   TCUA Design Revision Update UOM Property
*  Code                  :   UpadateUOMt5UQDup.c
*  Created on			 :   24th Mar 2021
*
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/
#define TE_MAXLINELEN  128
#include <ae/dataset.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define Debug TRUE
                                                                              \

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
        printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
    }
    return ITK_ok;
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}



int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dcr						= NULL;

	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	//dcr				= ITK_ask_cli_argument("-dcr=");

	//time_t 	now;
	//struct 	tm when;

	//time(&now);
	//when = *localtime(&now);

	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);

	//	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(dcr)) == 0)
	//	{
	//		print_requirement();
	//		return -1;
	//	}

	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	//ifail = ITK_set_bypass(true);

	printf("\nBefor DCR_Auto_Assign call \n\n");
	

	//ifail = DCR_Auto_Assign(dcr);
	tag_t	*type_tag3 =  NULLTAG;
	tag_t	new_object =  NULLTAG;
	tag_t	new_object_Rev =  NULLTAG;
	tag_t	object_create_input_tag =  NULLTAG;

	 int number_of_types1 =0;

	printf("\n PartiType Value == []");fflush(stdout);

	if(TCTYPE_find_types_for_class("T5_DChangeReport",&number_of_types1,&type_tag3));
	printf("\n CreateDcrTask-->number_of_types1-------->  : %d\n",number_of_types1);fflush(stdout);

	if(TCTYPE_construct_create_input(type_tag3[0], &object_create_input_tag));

	//if(AOM_set_value_string(object_create_input_tag,"release_status_list",dcr_objname));
	
	//if(AOM_lock(object_create_input_tag));
	if(AOM_set_value_string(object_create_input_tag,"object_desc","CVBU Mint-DCR"));
	printf("\n DCR Number: CVBU Mint-DCR");fflush(stdout);

	if(AOM_set_value_string(object_create_input_tag,"item_id","123-123-123"));
	printf("\n DCR Number:  ");fflush(stdout);

	if(AOM_set_value_string(object_create_input_tag,"object_name","TEST"));
	printf("\n object Number TEST ");fflush(stdout);
	printf("\n11111\n");fflush(stdout);
	if((TCTYPE_create_object(object_create_input_tag, &new_object))!=ITK_ok)PrintErrorStack();
	
	//if(ITEM_find_item(DCRno ,&DCRTag)!=ITK_ok)PrintErrorStack();
	printf("\n22222\n");fflush(stdout);
	
	//if (new_object!=NULLTAG)
	if(new_object != NULLTAG)
	{
		printf("\n Inside New Object Tag not null.\n");fflush(stdout);
		if(AOM_save_without_extensions(new_object));
		if(AOM_refresh(new_object,0));
		if(AOM_unlock(new_object));
		printf("\n CreateDcrTask-->1.DCR task is created......\n"); fflush(stdout);

		//ITEM_ask_latest_rev(new_object,&new_object_Rev);
		//printf("\n CreateDcrTask-->2.DCR Task Revision is queried......\n");fflush(stdout);

		//if(AOM_save_without_extensions(new_object_Rev));
		//if(AOM_unlock(new_object_Rev));
	}
	else
	{
		printf(" \n DCR not created \n");
	}

	printf("\nEnd of program.....!!\n\n");
	printf("\n*****************************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
