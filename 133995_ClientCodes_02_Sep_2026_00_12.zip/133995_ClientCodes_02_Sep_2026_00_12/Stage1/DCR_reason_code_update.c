#include <stdlib.h>
#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <vm/vms.h>
#include <tc/emh.h>
#include <pom/pom/pom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <fclasses/tc_string.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/tctype.h>
#include <form/form.h>
#include <epm/cr.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <tccore/idcxt.h>
#include <tccore/idfr.h>
#include <tccore/idcxt_errors.h>
#include <tccore/part.h>
#include <tccore/tctype.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#include <tcinit/tcinit.h>
#include <ae/ae.h>
#include <sa/tcfile_cache.h>
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
int ifail = ITK_ok;
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
        printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
    }
    return ITK_ok;
}
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{
	*count=*count+1;
	if(*count==1)
	{
	(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	}
	else
	{
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));

}

char *GetDmlReasonDisplay(char *DmlReasonCode)
{
	char	*Dml_ReasonDisplay			= NULL;

	Dml_ReasonDisplay=(char *)MEM_alloc(200);

	printf("\n Print DmlReasonCode==> [%s]",DmlReasonCode);fflush(stdout);
	if(tc_strcmp(DmlReasonCode,"DR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DR");
		tc_strcpy(Dml_ReasonDisplay,"DRAFTING ERROR CORRECTION/BOM-CAD QUALITY IMPROVEMENT");
	}
	if(tc_strcmp(DmlReasonCode,"AD")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"AD");
		tc_strcpy(Dml_ReasonDisplay,"ALTERNATE SOURCE DEVELOPMENT");
	}
	if(tc_strcmp(DmlReasonCode,"QU")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"QU");
		tc_strcpy(Dml_ReasonDisplay,"QUALITY");
	}
	if(tc_strcmp(DmlReasonCode,"CM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CM");
		tc_strcpy(Dml_ReasonDisplay,"END CUSTOMER/FIELD COMPLAINTS & SERVICE FEEDBACK/CCT");
	}
	if(tc_strcmp(DmlReasonCode,"RR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"RR");
		tc_strcpy(Dml_ReasonDisplay,"REGULATORY REQUIREMENT");
	}
	if(tc_strcmp(DmlReasonCode,"CR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CR");
		tc_strcpy(Dml_ReasonDisplay,"COST REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"ATR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ATR");
		tc_strcpy(Dml_ReasonDisplay,"ATTRIBUTE REQUIREMENT");
	}
	if(tc_strcmp(DmlReasonCode,"EM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"EM");
		tc_strcpy(Dml_ReasonDisplay,"ENGINEERING MATURITY (CAE, STYLING, VALIDATION, PROTO FEEDBACK ETC.)");
	}
	if(tc_strcmp(DmlReasonCode,"DFAF")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFAF");
		tc_strcpy(Dml_ReasonDisplay,"DFA FEEDBACK");
	}
	if(tc_strcmp(DmlReasonCode,"DFSF")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFSF");
		tc_strcpy(Dml_ReasonDisplay,"DFS FEEDBACK");
	}
	if(tc_strcmp(DmlReasonCode,"DFCF")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFCF");
		tc_strcpy(Dml_ReasonDisplay,"DFC FEEDBACK");
	}
	if(tc_strcmp(DmlReasonCode,"CMR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CMR");
		tc_strcpy(Dml_ReasonDisplay,"COMMONIZATION/STANDARDIZATION/COMPLEXITY REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"CSC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CSC");
		tc_strcpy(Dml_ReasonDisplay,"CONDITION OF SUPPLY CHANGE");
	}
	if(tc_strcmp(DmlReasonCode,"SC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SC");
		tc_strcpy(Dml_ReasonDisplay,"SCOPE CHANGES");
	}
	if(tc_strcmp(DmlReasonCode,"RSP")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"RSP");
		tc_strcpy(Dml_ReasonDisplay,"RELEASE OF SPARES/KITS (NO NEW PART DEVELOPMENT)");
	}
	if(tc_strcmp(DmlReasonCode,"WR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"WR");
		tc_strcpy(Dml_ReasonDisplay,"WEIGHT REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"IFD")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"IFD");
		tc_strcpy(Dml_ReasonDisplay,"INFO-FITMENT DRAWING (IFD)");
	}
	if(tc_strcmp(DmlReasonCode,"ECFR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ECFR");
		tc_strcpy(Dml_ReasonDisplay,"ECU CALIBRATION FILE RELEASE");
	}
	if(tc_strcmp(DmlReasonCode,"SA")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SA");
		tc_strcpy(Dml_ReasonDisplay,"SAMPLES TO BE APPROVED");
	}
	if(tc_strcmp(DmlReasonCode,"DFM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFM");
		tc_strcpy(Dml_ReasonDisplay,"DFM");
	}
	if(tc_strcmp(DmlReasonCode,"DFMF")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DFM");
		tc_strcpy(Dml_ReasonDisplay,"DFM FEEDBACK");
	}
	if(tc_strcmp(DmlReasonCode,"NR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"NR");
		tc_strcpy(Dml_ReasonDisplay,"NEW REQUIREMENTS (NEW VC, NEW AGGREGATE)");
	}
	if(tc_strcmp(DmlReasonCode,"CFL")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"CFL");
		tc_strcpy(Dml_ReasonDisplay,"CHANGE IN FEATURE LIST");
	}
	if(tc_strcmp(DmlReasonCode,"RSR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"RSR");
		tc_strcpy(Dml_ReasonDisplay,"REGULATORY / SAFETY REQUIREMENTS");
	}
	if(tc_strcmp(DmlReasonCode,"DM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DM");
		tc_strcpy(Dml_ReasonDisplay,"DESIGN MATURATION");
	}
	if(tc_strcmp(DmlReasonCode,"SCAS")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SCAS");
		tc_strcpy(Dml_ReasonDisplay,"STYLING SURFACES (CAS)");
	}
	if(tc_strcmp(DmlReasonCode,"EVI")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"EVI");
		tc_strcpy(Dml_ReasonDisplay,"EVI REPLACEMENTS (BLACK BOX)");
	}
	if(tc_strcmp(DmlReasonCode,"FA")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"FA");
		tc_strcpy(Dml_ReasonDisplay,"FEATURE ADDITION");
	}
	if(tc_strcmp(DmlReasonCode,"BTSC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"BTSC");
		tc_strcpy(Dml_ReasonDisplay,"BTS SUPPLIER CHANGE (GREY BOX)");
	}
	if(tc_strcmp(DmlReasonCode,"DVLO")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"DVLO");
		tc_strcpy(Dml_ReasonDisplay,"DVLO ISSUES");
	}
	if(tc_strcmp(DmlReasonCode,"4DCHANGE")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"4DCHANGE");
		tc_strcpy(Dml_ReasonDisplay,"4D CHANGES");
	}
	if(tc_strcmp(DmlReasonCode,"VCAE")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"VCAE");
		tc_strcpy(Dml_ReasonDisplay,"VALIDATION / CAE FEEDBACK");
	}
	if(tc_strcmp(DmlReasonCode,"FMPCQRI")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"FMPCQRI");
		tc_strcpy(Dml_ReasonDisplay,"TO FACILITATE MANUFACTURING/ PROCESS CHANGES FOR QUALITY RELIABILITY IMPROVEMENT");
	}
	if(tc_strcmp(DmlReasonCode,"ICWCR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ICWCR");
		tc_strcpy(Dml_ReasonDisplay,"INTEGRATED COST REDUCTION / WEIGHT REDUCTION / COMPLEXITY REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"MMDMR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"MMDMR");
		tc_strcpy(Dml_ReasonDisplay,"MODULE MASTER DATA MANAGEMENT REQUEST");
	}
	if(tc_strcmp(DmlReasonCode,"VAC")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"VAC");
		tc_strcpy(Dml_ReasonDisplay,"VC Attribute Change");
	}
	if(tc_strcmp(DmlReasonCode,"WCR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"WCR");
		tc_strcpy(Dml_ReasonDisplay,"WARRANTY COST REDUCTION");
	}
	if(tc_strcmp(DmlReasonCode,"PQ")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"PQ");
		tc_strcpy(Dml_ReasonDisplay,"IMPROVEMENT IN JD POWER INITIAL QUALITY SCORE");
	}
	if(tc_strcmp(DmlReasonCode,"QR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"QR");
		tc_strcpy(Dml_ReasonDisplay,"QUALITY & RELIABILITY IMPROVEMENT");
	}
	if(tc_strcmp(DmlReasonCode,"QRI")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"QR");
		tc_strcpy(Dml_ReasonDisplay,"QUALITY, WARRANTY & RELIABILITY IMPROVEMENT");
	}
	if(tc_strcmp(DmlReasonCode,"FM")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"FM");
		tc_strcpy(Dml_ReasonDisplay,"TO FACILITATE MANUFACTURING");
	}
	if(tc_strcmp(DmlReasonCode,"SR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"SR");
		tc_strcpy(Dml_ReasonDisplay,"SAFETY REQUIREMENT");
	}
	if(tc_strcmp(DmlReasonCode,"ICR")==0)
	{
		//tc_strcpy(Dml_ReasonCode,"ICR");
		tc_strcpy(Dml_ReasonDisplay,"INTEGRATED COST REDUCTION");
	}
	printf("\n Print Dml_ReasonDisplay==> [%s]",Dml_ReasonDisplay);fflush(stdout);
	return Dml_ReasonDisplay;
}
int ITK_user_main(int argc, char *argv[])
{
	
	
	char *dcr_no  = NULL;
    char *reason_code = NULL;       
	tag_t TagClassId = NULLTAG;
	char *ObjClassName=NULL;
	char *username = NULL;
	char *password = NULL;
	char *DmlreasonDis = NULL;
	char *DmlreasonDisDup = NULL;
	char *reason = NULL;
	char *reasonDup = NULL;
	char*  GetDmlReasonDisplayValue	= NULL;
    char*  Dml_Reason_Display	= NULL;
	char*  Dml_ReasonCode	= NULL;
	char*  Dml_Reason_Require	= NULL;
	char*  reasonUpdate	= NULL;
	
	Dml_Reason_Require=(char *)MEM_alloc(100);
	
	

	
	int status              = ITK_ok;


	ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	ifail = ITK_auto_login( );

	if(ifail==0)
	{
		printf("\nLogin Successfully to Teamcenter!!!!!!!!\n");
	}
	ifail = ITK_set_journalling(TRUE);

	username      = ITK_ask_cli_argument("-u=");
	password      = ITK_ask_cli_argument("-pf=");
	dcr_no  = ITK_ask_cli_argument("-i=");
    reason_code  = ITK_ask_cli_argument("-r=");
	

	printf("Entering fun");
	tc_strcpy(Dml_Reason_Require,reason_code);

	if (dcr_no !=NULL)
    {
		logical retain_released_date =TRUE;
		tag_t DCRTag = NULLTAG;
		tag_t DCRREVTag = NULLTAG;


		char *reasoncode=NULL;

		if(ITEM_find_item(dcr_no ,&DCRTag)!=ITK_ok)PrintErrorStack();
		if (DCRTag)
		{
			printf("\nDCR TAG found");fflush(stdout);
		
		}
		if(ITEM_ask_latest_rev(DCRTag, &DCRREVTag)!=ITK_ok)PrintErrorStack();

          if (DCRREVTag)
		{
			printf("\nDCR Revision TAG found");fflush(stdout);
		
		}
		if (DCRREVTag!=NULLTAG)
		{

			if(POM_class_of_instance(DCRREVTag,&TagClassId));
			if(POM_name_of_class(TagClassId,&ObjClassName));
			printf("\n ObjClassName: %s",ObjClassName);

			if (tc_strcmp(ObjClassName,"T5_DChangeReportRevision")==0)
			{
				GetDmlReasonDisplayValue = GetDmlReasonDisplay(Dml_Reason_Require);
				printf("\n GetDmlReasonDisplayValue ===>[%s]", GetDmlReasonDisplayValue);fflush(stdout);
				Dml_Reason_Display=(char *)MEM_alloc(200);
				Dml_ReasonCode=(char *)MEM_alloc(100);
				tc_strcpy(Dml_Reason_Display,GetDmlReasonDisplayValue);
				tc_strcpy(Dml_ReasonCode,Dml_Reason_Require);
				if	(tc_strcmp(GetDmlReasonDisplayValue,"") == 0)
				{
					AOM_lock(DCRREVTag);	
					AOM_set_value_string(DCRREVTag,"t5_DcrCreRC",Dml_ReasonCode);
					AOM_save_without_extensions(DCRREVTag);
					AOM_unlock(DCRREVTag);
				}
				else
				{
					AOM_lock(DCRREVTag);	
					AOM_set_value_string(DCRREVTag,"t5_DcrCreRC",GetDmlReasonDisplayValue);
					AOM_save_without_extensions(DCRREVTag);
					AOM_unlock(DCRREVTag);
				}


				AOM_ask_value_string(DCRREVTag,"t5_DcrCreRC",&reasonUpdate);

				printf("\n in if After update reasonUpdate ===>[%s]", reasonUpdate);fflush(stdout);
				
			}
			MEM_free(reasoncode);
			}
	}
		else
		{
			printf("\n DCRREVTag NOT found------>");fflush(stdout);
		}

	printf("\n ");
	ITK_CALL(POM_logout(false));
	return status;
}
