 /***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : Adddeletionbcp.c
* Created By                   : Aadarsh kumar
* Created On                   : 06/11/2022
* Project                      :
* Methods Defined              :
* Description                  : Generate Estimate sheet
* Specific Notes               : ./CL_Task -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -Fromdate=01-Feb-2023 -Todate=03-Feb-2023
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pie/pie.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

FILE		*fp 			= NULL;
//FILE *Report;
FILE		*fp1 			= NULL;
FILE		*Report 			= NULL;
int expansionLevel = 0;
int cntflag = 0;
int Qtyflag = 0;
int start =0;
int ia = 0;
int times =0;
int f1 = 0;
int f2 = 0;
int f3 = 0;
int f4 = 0;
int SerialNo=0;
int DrStatusflag = 0;
char *Qtypart	= NULL;
char *partdiff	= NULL;
char *RevstatusN	= NULL;
char *RevstatusC	= NULL;
char *Plant	= NULL;
char **LatChildSet = NULL;
char *tempbom = NULL;
//char *symbole = "#";
char *charPtr = NULL; //my
char **childPart      = NULL;
char **childParttwo      = NULL;
char **childPartRep1      = NULL;
char **childPartRep2      = NULL;
char **childPartthree      = NULL;
char **childPartFour      = NULL;
char **childPartFive      = NULL;
char **childPartSix      = NULL;

int tt=0;
int tt1=0;
int tt2=0;
int tt3=0;
int tt4=0;
int tt5=0;
int tt6=0;
int tt7=0;
int uniquecountfirst = 0;
int uniquecounttwo = 0;
int commancountinboth = 0;
char *Value1 = NULL;
char *Value2 = NULL;
char *Value3 = NULL;

////here is the declaration of child part for add
//
//char *parent_item_idforadd = NULL;
//char *parentrev_foradd = NULL;
//char *Parentqty_foradd = NULL;
//char *parent_item_idmodadd = NULL;
//char *Parent_item_idmodName = NULL;

//time_t t = time(NULL);
//struct tm tm = *localtime(&t);
//tag_t IteamprintTagx	= NULL;
//tag_t IteamprintTagTwox	= NULL;
//char *Setofstring = NULL;
//char ***strset =  NULLTAG
//sFinalDataSet = (char **) MEM_alloc(1000 * sizeof(char *));
//LatChildSet = (char**)MEM_alloc( 1 * sizeof *LatChildSet );
void write2xml(FILE * , char*);
int ctr=0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
int i;
char *retStringf;
retStringf = (char*) malloc(200);
for(i=0; i < toCharf; i++ )
		  *(retStringf+i) = *(mainStringf+i+fromCharf);
*(retStringf+i) = '\0';
return retStringf;
}

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);


}
;
int setFindStr1(int *count,char ***strset,char* str)
	{
		int j   =0;

		//tmp = sizeof(*strset);

		for(j=0;j<*count;j++)
		{
			printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
			//printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
			printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

			//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
			if(tc_strcmp((*strset)[j],str)==0) //check this
			//if(tc_strcmp(*strset[j],str)==0)

			return j;

		}
		return -1;
	 }
int setFindStr2s(int *count,char ***strset,char* str)
	{
		int j   =0;

		//tmp = sizeof(*strset);

		for(j=0;j<*count;j++)
		{
			printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
			//printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
			printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

			//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
			if(tc_strcmp((*strset)[j],str)==0) //check this
			//if(tc_strcmp(*strset[j],str)==0)

			return j;

		}
		return -1;
	 }
int setFindStr3s(int *count,char ***strset,char* str)
	{
		int j   =0;

		//tmp = sizeof(*strset);

		for(j=0;j<*count;j++)
		{
			printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
			printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
			printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

			//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
			if(tc_strcmp((*strset)[j],str)==0)
			{//check this
			//if(tc_strcmp(*strset[j],str)==0)
			printf("\n Value of J is [%d]",j);fflush(stdout);

			return j;
			}

		}
		return -1;
	 }

void setAddStrTwo(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrtwo===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
void setAddStrThree(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrthree===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
void setAddStrFour(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrFour===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
void setAddStrFive(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrFive===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
void setAddStrSix(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrSix===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;

void setAddStrRep(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrRep1===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
void setAddStrRep2(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrRep1===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
char* intToString(int value) {
    // Determine the length of the resulting string
    int length = snprintf(NULL, 0, "%d", value);
    
    // Allocate memory for the string (+1 for null-terminator)
    char* str = (char*)malloc((length + 1) * sizeof(char));
    if (str == NULL) {
        // Failed to allocate memory
        return NULL;
    }

    // Convert the integer to a string
    sprintf(str, "%d", value);

    return str;
}


//	void printstrset(int count,char **strset){
//
//				for (ia =0;ia<count;ia++)
//				{
//					printf("%shere is the string set value one by one\n",strset[ia]);
//				}
//
//	}
//void addstring(int count,char* charPrt, char* str){
//					count = count+1;
//					tc_strcpy(charPrt,str);
//
//			}

//void autoresizestrAdd(char **src,char* dest)
//{
//	char * desc = dest ? dest : "NA";
//	printf("\n autoresizestrAdd desc len==%d",strlen(desc));
//	printf("this is the value of src before concadinating %s",src);
//	const size_t a = strlen(*src);
//	const size_t b = strlen(desc);
//	const size_t size_ab = a + b + 2;
//	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
//	tc_strcat(*src , desc);
//	printf("this is the value of src After concadinating %s",src);
//}

//void autoresizestrAdd2(char **src,char* dest)
//{
//	char * desc = dest ? dest : "NA";
//	//printf("\n autoresizestrAdd desc len==%d",strlen(desc));
//	const size_t a = strlen(*src);
//	const size_t b = strlen(desc);
//	const size_t size_ab = a + b + 2;
//	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
//	tc_strcat(*src , desc);
//}
//static int report_wso_object_string_and_owning_user(tag_t object)
//{
//    char *object_string = NULL;
//    char *owning_user = NULL;
//    char *item_id = NULL;
//    char *date_released = NULL;
//    //ITK_CALL(WSOM_ask_object_id_string(object, &object_string));
//    //ITK_CALL(AOM_UIF_ask_value(object, "owning_user", &owning_user));
//    ITK_CALL(AOM_UIF_ask_value(object, "item_id", &item_id));
//    ITK_CALL(AOM_UIF_ask_value(object, "date_released", &date_released));
//    //printf("       %s - %s \n", object_string, owning_user);
//    printf("%s %s\n", item_id,date_released);
//    //MEM_free(object_string);
//    //MEM_free(owning_user);
//	MEM_free(item_id);
//	MEM_free(date_released);
//	return ITK_ok;
//}
/*********BOMExpansionforcommon**********/
int BOMExpansionforcommon(tag_t Child_bom_linestwo,tag_t Child_bom_linesone,FILE *fp)
{
	int ifail = ITK_ok;
	int i1;
	int i2;
	//int SerialNocommon=0;
	int level0=0;
	int CSFoundFlag=0;
	int F18CSFoundFlag=0;
	int m1=0;
	int subchildno_bom_linesx;
	int subchildno_bom_linesonex;
	tag_t subchilditeam = NULLTAG;
	tag_t subchilditeamone = NULLTAG;
	char *subchild_item_idtwo = NULL;
	char *subchild_item_idone = NULL;
	//char *subchild_bom_linesonex = NULL;
	char *subchild_item_idquantity = NULL;
	char *subchild_item_idmodadd = NULL;
	char *subchild_item_idmodName = NULL;
	char *subchild_item_idTwoRev = NULL;
	char *subchild_item_idOneRev = NULL;
	char *subchild_item_idquantityref = NULL;
	char *subchild_item_idquantityNew = NULL;
	char *methodplant = NULL;
	char *tokenX2 = NULL;
	char *catry = NULL;
	char *SrNOP = NULL;
	tag_t *subchild_bom_linesx = NULLTAG;
	tag_t *subchild_bom_linesonex = NULLTAG;
	//depthExpandVC2++;

	printf("\n Common--please wait Second part is running\n");fflush(stdout);
	ifail = BOM_line_ask_child_lines(Child_bom_linestwo, &subchildno_bom_linesx, &subchild_bom_linesx);
	printf("\n Common--Size of ref VC BOM is %d \n",subchildno_bom_linesx);fflush(stdout);

	if(subchildno_bom_linesx>0)
	{
		for (i1=0; i1<subchildno_bom_linesx; i1++)
		{
			subchild_item_idtwo=NULL;
			subchild_item_idTwoRev=NULL;

			subchilditeam=subchild_bom_linesx[i1];

			ifail = AOM_ask_value_string(subchilditeam,"bl_item_item_id",&subchild_item_idtwo);
			ifail = AOM_ask_value_string(subchilditeam ,"bl_rev_item_revision_id",&subchild_item_idTwoRev);
			ifail = AOM_ask_value_string(subchilditeam,"bl_quantity",&subchild_item_idquantityref);
			//printf("\nsubchild of VCT %s\n",subchild_item_idtwo);fflush(stdout);
			printf("\n Common--subchild part of ref vc [%s] [%s] \n",subchild_item_idtwo,subchild_item_idTwoRev);fflush(stdout);

			ifail = BOM_line_ask_child_lines(Child_bom_linesone,&subchildno_bom_linesonex,&subchild_bom_linesonex);
			printf("\n Common--Size of New VC BOM is %d \n",subchildno_bom_linesonex);fflush(stdout);

			if(subchildno_bom_linesonex>0)
			{
				for (i2=0;i2<subchildno_bom_linesonex; i2++)
				{
					catry = "Common";
					subchild_item_idone = NULL;
					subchild_item_idOneRev=NULL;

					subchilditeamone=subchild_bom_linesonex[i2];

					ifail = AOM_ask_value_string(subchilditeamone,"bl_item_item_id",&subchild_item_idone);
					ifail = AOM_ask_value_string(subchilditeamone,"bl_rev_item_revision_id",&subchild_item_idOneRev);

					printf("\n Common--subchild part of New VC [%s] [%s] \n",subchild_item_idone,subchild_item_idOneRev);fflush(stdout);

					ifail = AOM_ask_value_string(subchilditeamone,"bl_quantity",&subchild_item_idquantityNew);

					if (tc_strcmp(subchild_item_idtwo,subchild_item_idone)==0 && tc_strcmp(subchild_item_idTwoRev,subchild_item_idOneRev)==0 && tc_strcmp(subchild_item_idquantityref,subchild_item_idquantityNew)==0)
					{
						printf("\n Common--Both parts are eqaul in this condition\n");fflush(stdout);
						SrNOP=NULL;
						//SerialNocommon=SerialNocommon+1;
						SerialNo=SerialNo+1;
						char* SrNOP = intToString(SerialNo);
						ifail = AOM_ask_value_string(subchilditeamone,"bl_quantity",&subchild_item_idquantity);
						ifail = AOM_ask_value_string(subchilditeamone,"bl_Design Revision_t5_ModuleAddress",&subchild_item_idmodadd);
						ifail = AOM_ask_value_string(subchilditeamone,"bl_Design Revision_t5_ModuleName",&subchild_item_idmodName);
						STRNG_replace_str(subchild_item_idmodName,",","-",&subchild_item_idmodName);
						STRNG_replace_str(subchild_item_idmodName,"\n","-",&subchild_item_idmodName);
						STRNG_replace_str(subchild_item_idmodName,"&","and",&subchild_item_idmodName);

						printf("\n subchild_item_idmodadd: [%s] ",subchild_item_idmodadd); fflush(stdout);
						
						write2xml(Report,"<logo>\n");
						if (SrNOP != NULL)
							{
							 printf("Converted string: %s\n", SrNOP);
								write2xml(Report,"<field key =\"Serial_No\">");
								write2xml(Report,SrNOP);
								write2xml(Report,"</field>\n");
							}
							else 
								{
									 printf("Failed to convert the integer to string.\n");
								}
						write2xml(Report,"<field key =\"Module_address\">");
						write2xml(Report,subchild_item_idmodadd);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module_Name\">");
						write2xml(Report,subchild_item_idmodName);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Category\">");
						write2xml(Report,catry);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module NVC\">");
						write2xml(Report,subchild_item_idone);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Revision NVC\">");
						write2xml(Report,subchild_item_idOneRev);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Quantity NVC\">");
						write2xml(Report,subchild_item_idquantityNew);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child level NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module's Child NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Revision NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Quantity NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Car make BY NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module RVC\">");
						write2xml(Report,subchild_item_idtwo);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Revision RVC\">");
						write2xml(Report,subchild_item_idTwoRev);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Quantity RVC\">");
						write2xml(Report,subchild_item_idquantityref);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child level RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module's Child RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Revision RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Quantity RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Car make BY RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"</logo>\n");

						printf("\n Common--fp.0==> %s,%s,%s,%s,%s,%s,,,,,,,%s,%s,%s,,,,,,,",subchild_item_idmodadd,subchild_item_idmodName,catry,subchild_item_idone,subchild_item_idOneRev,subchild_item_idquantity,subchild_item_idone,subchild_item_idOneRev,subchild_item_idquantity,"","","","","","");fflush(stdout);

						fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,,,,,,,%s,%s,%s,,,,,,,\n",SrNOP,subchild_item_idmodadd,subchild_item_idmodName,catry,subchild_item_idone,subchild_item_idOneRev,subchild_item_idquantity,subchild_item_idone,subchild_item_idOneRev,subchild_item_idquantity,"","","","","","");fflush(fp);
						free(SrNOP); // Free the dynamically allocated memory
						break;
					}
				}
			}
		}
	}
	return 0;
}

int BOMExpansionforadd(tag_t Child_bom_linesone,tag_t Child_bom_linestwo)
	{
		printf("\n This is function BOMExpansionforadd \n");
		int ifail = ITK_ok;
		int subchildno_bom_linesonex = 0;
		int subchildno_bom_linestwox = 0;
		tag_t *subchild_bom_linesonex = NULLTAG;
		tag_t *subchild_bom_linestwox = NULLTAG;
		int i1 = 0;
		int i2 = 0;
		int countflag=0;
		tag_t subchilditeam = NULLTAG;
		tag_t subchilditeamtwo = NULLTAG;
		tag_t *subchild_bom_linesx = NULLTAG;
		char *subchild_item_idOne = NULL;
		char *subchild_item_idtwo = NULL;
		char *subchild_item_idTwoRev = NULL;
		char *subchild_item_idOneRev = NULL;
		char *child_item_idmodaddone = NULL;
		char *child_item_idmodaddtwo = NULL;
		ifail = BOM_line_ask_child_lines(Child_bom_linesone,&subchildno_bom_linesonex,&subchild_bom_linesonex);
		printf("\n value of subchildno_bom_linesonex in first VC is %d",subchildno_bom_linesonex);
		for (i1=0;i1<subchildno_bom_linesonex;i1++)
					{
						countflag=0;
						subchild_item_idOne=NULL;
						subchild_item_idOneRev=NULL;
						subchilditeam=subchild_bom_linesonex[i1];
						ifail = AOM_ask_value_string(subchilditeam,"bl_item_item_id",&subchild_item_idOne);
						ifail = AOM_ask_value_string(subchilditeam ,"bl_rev_item_revision_id",&subchild_item_idOneRev);
						ifail = AOM_ask_value_string(subchilditeam,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodaddone);
						//printf("\nsubchild of VCT %s\n",subchild_item_idtwo);
						printf("\n subchild part of New vc in add function [%s] [%s] \n",subchild_item_idOne,subchild_item_idOneRev);
						ifail = BOM_line_ask_child_lines(Child_bom_linestwo,&subchildno_bom_linestwox,&subchild_bom_linestwox);
						//printf("\n Size of ref VC BOM is %d \n",subchildno_bom_linesonex);fflush(stdout);
						for (i2=0; i2<subchildno_bom_linestwox;i2++)
							{
								subchild_item_idtwo=NULL;
								subchild_item_idTwoRev=NULL;
								subchilditeamtwo=subchild_bom_linestwox[i2];
								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_item_item_id",&subchild_item_idtwo);
								ifail = AOM_ask_value_string(subchilditeamtwo ,"bl_rev_item_revision_id",&subchild_item_idTwoRev);
								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodaddtwo);
								printf("\nHere we are printing Both parts revision and sequence[%s] [%s] [%s] [%s] \n",subchild_item_idtwo,subchild_item_idTwoRev,subchild_item_idOne,subchild_item_idOneRev);
								if (((tc_strcmp(subchild_item_idOne,subchild_item_idtwo)==0) && (tc_strcmp(subchild_item_idOneRev,subchild_item_idTwoRev)==0)) || (tc_strcmp(child_item_idmodaddone,child_item_idmodaddtwo)==0))
									{
									  printf("\nThis printf is for increasing the value of countflag\n");fflush(stdout);
									  countflag++;

									}

							}
						if(countflag==0)
							{
								addelement(subchild_item_idOne,subchild_item_idOneRev);

							}

					 }
	}
int addelement(char* subchild_item_idOne, char *subchild_item_idOneRev)
	{
		tc_strcat(subchild_item_idOne,"#");
		tc_strcat(subchild_item_idOne,subchild_item_idOneRev);
		if(setFindStr1(&tt2,&childPartthree,subchild_item_idOne)==-1)
		{
			//setAddStr(&iWrite,&SSDetails,PartNumber);
			setAddStrThree(&tt2,&childPartthree,subchild_item_idOne);
			printf("\n Set of add element into New VC [%s] added directly \n",subchild_item_idOne);fflush(stdout);
		}
		return 0;
	}
int Printaddelement(tag_t Child_bom_linesone,FILE *fp)
{
	int ifail = ITK_ok;
	int i = 0;
	int i1 = 0;
	int SerialNoAdd = 0;
	int printflag = 0;
	int CSFoundFlag = 0;
	char* item_level = NULL;
	int subchildno_bom_linesonex = 0;
	tag_t subchilditeamtwo = NULLTAG;
	tag_t *subchild_bom_linesonex = NULLTAG;
	char* tokenX3 = NULL;
	char* split1 = NULL;
	char* split2 = NULL;
	char* methodplant = NULL;
	char* subchild_item_idtwo = NULL;
	char* subchild_item_idTwoRev = NULL;
	char* ChildDescOne = NULL;
	char* Childqty_foradd = NULL;
	char* child_item_idmodadd = NULL;
	char* Child_item_idmodName = NULL;
	char* catry = NULL;
	char *SrNOP = NULL;
	catry = "ADD";
	for (i=0;i<tt2;i++)
	{
		tokenX3=childPartthree[i];
		printf("\nhere is the string set value to be print for add element %s\n",tokenX3);fflush(stdout);
		split1 = strtok(tokenX3,"#");
		split2 = strtok(NULL,"#");
		ifail = BOM_line_ask_child_lines(Child_bom_linesone,&subchildno_bom_linesonex,&subchild_bom_linesonex);
		for (i1=0;i1<subchildno_bom_linesonex;i1++)
							{
								subchild_item_idtwo=NULL;
								subchild_item_idTwoRev=NULL;
								subchilditeamtwo=subchild_bom_linesonex[i1];
								printf("\nThis printf is for parent-child part\n");fflush(stdout);
//								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_item_item_id",&parent_item_idforadd);
//								ifail = AOM_ask_value_string(subchilditeamtwo ,"bl_rev_item_revision_id",&parentrev_foradd);
//								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_quantity",&Parentqty_foradd);
//								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_Design Revision_t5_ModuleAddress",&parent_item_idmodadd);
//								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_Design Revision_t5_ModuleName",&Parent_item_idmodName);

								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_item_item_id",&subchild_item_idtwo);
								ifail = AOM_ask_value_string(subchilditeamtwo ,"bl_rev_item_revision_id",&subchild_item_idTwoRev);
								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_quantity",&Childqty_foradd);
								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodadd);
								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_Design Revision_t5_ModuleName",&Child_item_idmodName);
								STRNG_replace_str(Child_item_idmodName,",","-",&Child_item_idmodName);
								STRNG_replace_str(Child_item_idmodName,"\n","-",&Child_item_idmodName);
								STRNG_replace_str(Child_item_idmodName,"&","and",&Child_item_idmodName);
								ifail = AOM_UIF_ask_value(subchilditeamtwo,"bl_Design Revision_t5_CarMakeBuyIndicator",&methodplant);
								ifail = AOM_UIF_ask_value(subchilditeamtwo,"bl_level_starting_0",&item_level);
								ifail = AOM_UIF_ask_value(subchilditeamtwo,"object_desc",&ChildDescOne);
								STRNG_replace_str(ChildDescOne,",","-",&ChildDescOne);
								STRNG_replace_str(ChildDescOne,"\n","-",&ChildDescOne);
								STRNG_replace_str(ChildDescOne,"&","and",&ChildDescOne);
										//printf("\nHere we are printing Both parts revision and sequence[%s] [%s] [%s] [%s] \n",subchild_item_idtwo,subchild_item_idTwoRev,split1,split2);
								if ((tc_strcmp(subchild_item_idtwo,split1)==0) && (tc_strcmp(subchild_item_idTwoRev,split2)==0))
									{
										SrNOP=NULL;
										SerialNo=SerialNo+1;
										char* SrNOP = intToString(SerialNo);
										//fprintf(fp,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,,,,,,,,\n",parent_item_idmodadd,Parent_item_idmodName,catry,parent_item_idforadd,parentrev_foradd,Parentqty_foradd,item_level,subchild_item_idtwo,subchild_item_idTwoRev,ChildDescOne,Childqty_foradd,methodplant,"","","","","","","","","");fflush(stdout);
										StopAtFforAdd(SrNOP,subchilditeamtwo,child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_foradd,printflag,fp);
										//fprintf(fp,"\n%s,%s,%s,%s,%s,%s\n",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_foradd);
										free(SrNOP); // Free the dynamically allocated memory
									}

							}

	}

}

int StopAtFforAdd(char* SrNOP,tag_t subchilditeamtwo,char *child_item_idmodadd,char *Child_item_idmodName,char *catry,char *subchild_item_idtwo,char *subchild_item_idTwoRev,char *Childqty_foradd,int printflag,FILE *fp)
{
		int ifail = ITK_ok;
		int CSFoundFlag = 0;
		int i1 =0;
		int qty =0;
		int subchildno_bom_linesonex = 0;
		char* methodplant = NULL;
		char* methodplantsplit = NULL;
		char* subchild_item_idtwoExp = NULL;
		char* subchild_item_idTwoRevExp = NULL;
		char* Childqty_foraddExp = NULL;
		char* child_item_idmodaddExp = NULL;
		char* Child_item_idmodNameExp = NULL;
		char* methodplantExp = NULL;
		char* item_levelExp = NULL;
		char* ChildDescOneExp = NULL;
		tag_t subchilditeamtwoex = NULLTAG;
		tag_t *subchild_bom_linesonex = NULLTAG;
		ifail = BOM_line_ask_child_lines(subchilditeamtwo,&subchildno_bom_linesonex,&subchild_bom_linesonex);
		if(subchildno_bom_linesonex>0)
		{
			for (i1=0;i1<subchildno_bom_linesonex;i1++)
				{
					printf("\nwe are under STOP AT F function\n");
					subchilditeamtwoex = subchild_bom_linesonex[i1];
					ifail = AOM_UIF_ask_value(subchilditeamtwoex,"bl_Design Revision_t5_CarMakeBuyIndicator",&methodplant);
					methodplantsplit = strtok(methodplant, " ");
					printf("value of methodplantsplit in add elemet function is %s",methodplantsplit);
					ifail = AOM_ask_value_string(subchilditeamtwoex,"bl_item_item_id",&subchild_item_idtwoExp);
					if (strstr(subchild_item_idtwoExp,"_")!=NULL)
						{
							continue;
						}
					ifail = AOM_ask_value_string(subchilditeamtwoex ,"bl_rev_item_revision_id",&subchild_item_idTwoRevExp);
					ifail = AOM_ask_value_string(subchilditeamtwoex,"bl_quantity",&Childqty_foraddExp);
					qty =  atoi(Childqty_foraddExp);
					ifail = AOM_ask_value_string(subchilditeamtwoex,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodaddExp);
					ifail = AOM_ask_value_string(subchilditeamtwoex,"bl_Design Revision_t5_ModuleName",&Child_item_idmodNameExp);
					STRNG_replace_str(Child_item_idmodNameExp,",","-",&Child_item_idmodNameExp);
					STRNG_replace_str(Child_item_idmodNameExp,"\n","-",&Child_item_idmodNameExp);
					STRNG_replace_str(Child_item_idmodNameExp,"&","and",&Child_item_idmodNameExp);
					ifail = AOM_UIF_ask_value(subchilditeamtwoex,"bl_level_starting_0",&item_levelExp);
					ifail = AOM_UIF_ask_value(subchilditeamtwoex,"bl_item_object_desc",&ChildDescOneExp);
					STRNG_replace_str(ChildDescOneExp,",","-",&ChildDescOneExp);
					STRNG_replace_str(ChildDescOneExp,"\n","-",&ChildDescOneExp);
					STRNG_replace_str(ChildDescOneExp,"&","and",&ChildDescOneExp);
					if (qty==0)
						{
							continue;
						}
					if((tc_strcmp(methodplantsplit,"F")==0) || (tc_strcmp(methodplantsplit,"F35")==0) || (tc_strcmp(methodplantsplit,"F40")==0) ||(tc_strcmp(methodplantsplit,"F18")==0) || (tc_strcmp(methodplantsplit,"F19")==0) || (tc_strcmp(methodplantsplit,"E99")==0))
						{
							CSFoundFlag=1;
						}
					else
						{
							printf(" P42:Found Other CS.\n");fflush(stdout);
							CSFoundFlag=0;
						}
					if(CSFoundFlag==0)
						{
							write2xml(Report,"<logo>\n");
							if (SrNOP != NULL)
							{
								printf("Converted string in Add function: %s\n", SrNOP);
								write2xml(Report,"<field key =\"Serial_No\">");
								write2xml(Report,SrNOP);
								write2xml(Report,"</field>\n");
							}
							write2xml(Report,"<field key =\"Module_address\">");
							write2xml(Report,child_item_idmodadd);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Module_Name\">");
							write2xml(Report,Child_item_idmodName);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Category\">");
							write2xml(Report,catry);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Module NVC\">");
							write2xml(Report,subchild_item_idtwo);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Revision NVC\">");
							write2xml(Report,subchild_item_idTwoRev);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Quantity NVC\">");
							write2xml(Report,Childqty_foradd);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child level NVC\">");
							write2xml(Report,item_levelExp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Module's Child NVC\">");
							write2xml(Report,subchild_item_idtwoExp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Revision NVC\">");
							write2xml(Report,subchild_item_idTwoRevExp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
							write2xml(Report,ChildDescOneExp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Quantity NVC\">");
							write2xml(Report,Childqty_foraddExp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Car make BY NVC\">");
							write2xml(Report,methodplant);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Module RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Revision RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Quantity RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child level RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Module's Child RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Revision RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Quantity RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Car make BY RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"</logo>\n");
							printf("\nfp.1==> %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,,,,,,,,",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_foradd,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant);fflush(stdout);
							fprintf(fp,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,,,,,,,,",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_foradd,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant);fflush(fp);
							StopAtFforAdd(SrNOP,subchilditeamtwoex,child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_foradd,printflag,fp);
						}
					else if(CSFoundFlag == 1)
						{
							write2xml(Report,"<logo>\n");
							if (SrNOP != NULL)
							{
							 printf("Converted string in Add function: %s\n", SrNOP);
								write2xml(Report,"<field key =\"Serial_No\">");
								write2xml(Report,SrNOP);
								write2xml(Report,"</field>\n");
							}
							write2xml(Report,"<field key =\"Module_address\">");
							write2xml(Report,child_item_idmodadd);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Module_Name\">");
							write2xml(Report,Child_item_idmodName);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Category\">");
							write2xml(Report,catry);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Module NVC\">");
							write2xml(Report,subchild_item_idtwo);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Revision NVC\">");
							write2xml(Report,subchild_item_idTwoRev);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Quantity NVC\">");
							write2xml(Report,Childqty_foradd);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child level NVC\">");
							write2xml(Report,item_levelExp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Module's Child NVC\">");
							write2xml(Report,subchild_item_idtwoExp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Revision NVC\">");
							write2xml(Report,subchild_item_idTwoRevExp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
							write2xml(Report,ChildDescOneExp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Quantity NVC\">");
							write2xml(Report,Childqty_foraddExp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Car make BY NVC\">");
							write2xml(Report,methodplant);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Module RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Revision RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Quantity RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child level RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Module's Child RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Revision RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Child Quantity RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Car make BY RVC\">");
							write2xml(Report," ");
							write2xml(Report,"</field>\n");
							write2xml(Report,"</logo>\n");
							printf("\nfp.2==> %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,,,,,,,,",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_foradd,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant);fflush(stdout);
							fprintf(fp,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,,,,,,,,",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_foradd,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant);fflush(fp);

						}
			}
		}
	else
		{
			if(printflag==0)
				{
					item_levelExp = " --- ";
					subchild_item_idtwoExp = " --- ";
					subchild_item_idTwoRevExp = " --- ";
					ChildDescOneExp = " --- ";
					Childqty_foraddExp = " --- ";
					methodplant = " --- ";
					write2xml(Report,"<logo>\n");
					if (SrNOP != NULL)
							{
								printf("Converted string in Add function: %s\n", SrNOP);
								write2xml(Report,"<field key =\"Serial_No\">");
								write2xml(Report,SrNOP);
								write2xml(Report,"</field>\n");
							}
					write2xml(Report,"<field key =\"Module_address\">");
					write2xml(Report,child_item_idmodadd);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Module_Name\">");
					write2xml(Report,Child_item_idmodName);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Category\">");
					write2xml(Report,catry);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Module NVC\">");
					write2xml(Report,subchild_item_idtwo);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Revision NVC\">");
					write2xml(Report,subchild_item_idTwoRev);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Quantity NVC\">");
					write2xml(Report,Childqty_foradd);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child level NVC\">");
					write2xml(Report,item_levelExp);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Module's Child NVC\">");
					write2xml(Report,subchild_item_idtwoExp);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Revision NVC\">");
					write2xml(Report,subchild_item_idTwoRevExp);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
					write2xml(Report,ChildDescOneExp);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Quantity NVC\">");
					write2xml(Report,Childqty_foraddExp);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Car make BY NVC\">");
					write2xml(Report,methodplant);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Module RVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Revision RVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Quantity RVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child level RVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Module's Child RVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Revision RVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Quantity RVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Car make BY RVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"</logo>\n");
					printf("\nfp.3==> %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,,,,,,,,",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_foradd,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant,"","","","","","","","","");fflush(stdout);
					fprintf(fp,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,,,,,,,,",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_foradd,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant,"","","","","","","","","");fflush(fp);
				}

		}
}
int BOMExpansionfordelete(tag_t Child_bom_linestwo,tag_t Child_bom_linesone)
	{
		int ifail = ITK_ok;
		int i1=0;
		int i2=0;
		int countflag=0;
		char *subchild_item_idtwo=NULL;
		char *subchild_item_idone=NULL;
		char *subchild_item_idtwoRev=NULL;
		char *subchild_item_idoneRev=NULL;
		char *child_item_idmodaddone=NULL;
		char *child_item_idmodaddtwo=NULL;
		int subchildno_bom_linestwox = 0;
		int subchildno_bom_linesonex = 0;
		tag_t *subchild_bom_linestwox = NULLTAG;
		tag_t *subchild_bom_linesonex = NULLTAG;
		tag_t subchilditeam = NULLTAG;
		tag_t subchilditeamone = NULLTAG;
		ifail = BOM_line_ask_child_lines(Child_bom_linestwo,&subchildno_bom_linestwox,&subchild_bom_linestwox);
		printf("\n value of subchildno_bom_linestwox in ref VC is in delete Expand function %d",subchildno_bom_linestwox);
		for (i1=0;i1<subchildno_bom_linestwox;i1++)
					{
						countflag=0;
						subchild_item_idtwo=NULL;
						subchild_item_idtwoRev=NULL;
						child_item_idmodaddtwo=NULL;
						subchilditeam=subchild_bom_linestwox[i1];
						ifail = AOM_ask_value_string(subchilditeam,"bl_item_item_id",&subchild_item_idtwo);
						ifail = AOM_ask_value_string(subchilditeam ,"bl_rev_item_revision_id",&subchild_item_idtwoRev);
						ifail = AOM_ask_value_string(subchilditeam,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodaddtwo);
						//printf("\nsubchild of VCT %s\n",subchild_item_idtwo);
						printf("\n subchild part of ref vc in delete function [%s] [%s] \n",subchild_item_idtwo,subchild_item_idtwoRev);
						ifail = BOM_line_ask_child_lines(Child_bom_linesone,&subchildno_bom_linesonex,&subchild_bom_linesonex);
						//printf("\n Size of ref VC BOM is %d \n",subchildno_bom_linesonex);fflush(stdout);
						for (i2=0; i2<subchildno_bom_linesonex;i2++)
							{
								subchild_item_idone=NULL;
								subchild_item_idoneRev=NULL;
								child_item_idmodaddone=NULL;
								subchilditeamone=subchild_bom_linesonex[i2];
								ifail = AOM_ask_value_string(subchilditeamone,"bl_item_item_id",&subchild_item_idone);
								ifail = AOM_ask_value_string(subchilditeamone ,"bl_rev_item_revision_id",&subchild_item_idoneRev);
								ifail = AOM_ask_value_string(subchilditeamone,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodaddone);
								printf("\nHere we are printing Both parts revision and sequence[%s] [%s] [%s] [%s] \n",subchild_item_idtwo,subchild_item_idtwoRev,subchild_item_idone,subchild_item_idoneRev);
								if ((tc_strcmp(subchild_item_idtwo,subchild_item_idone)==0) && (tc_strcmp(subchild_item_idtwoRev,subchild_item_idoneRev)==0))
									{
									  printf("\nThis printf is for increasing the value of countflag in delete function\n");fflush(stdout);
									  countflag++;
									}

							}
						if(countflag==0)
							{
								addelementfordelete(subchild_item_idtwo,subchild_item_idtwoRev);
							}

					 }



	}
int addelementfordelete(char* subchild_item_idtwo, char *subchild_item_idtwoRev)
	{
		tc_strcat(subchild_item_idtwo,"#");
		tc_strcat(subchild_item_idtwo,subchild_item_idtwoRev);
		if(setFindStr1(&tt3,&childPartFour,subchild_item_idtwo)==-1)
		{
			//setAddStr(&iWrite,&SSDetails,PartNumber);
			setAddStrFour(&tt3,&childPartFour,subchild_item_idtwo);
			printf("\n Set of add element into ref VC [%s] added directly inside delete function \n",subchild_item_idtwo);fflush(stdout);
		}
		return 0;
	}
int Printdeleteelement(tag_t Child_bom_linestwo,FILE *fp)
	{
		int ifail = ITK_ok;
		int i = 0;
		int i1 = 0;
		int Printflag = 0;
		int CSFoundFlag = 0;
		char* item_level = 0;
		int subchildno_bom_linestwox = 0;
		tag_t subchilditeamtwo = NULLTAG;
		tag_t *subchild_bom_linestwox = NULLTAG;
		char* tokenX3 = NULL;
		char* split1 = NULL;
		char* split2 = NULL;
		char* methodplant = NULL;
		char* subchild_item_idtwo = NULL;
		char* subchild_item_idTwoRev = NULL;
		char* ChildDescOne = NULL;
		char* Childqty_fordel = NULL;
		char* child_item_idmodadd = NULL;
		char* Child_item_idmodName = NULL;
		char *SrNOP = NULL;
		char* catry = NULL;
		catry = "Delete";
		for (i=0;i<tt3;i++)
			{
				tokenX3=childPartFour[i];
				printf("\nhere is the string set value to be print for add element %s\n",tokenX3);fflush(stdout);
				split1 = strtok(tokenX3,"#");
				split2 = strtok(NULL,"#");
				ifail = BOM_line_ask_child_lines(Child_bom_linestwo,&subchildno_bom_linestwox,&subchild_bom_linestwox);
				for (i1=0;i1<subchildno_bom_linestwox;i1++)
							{
								subchild_item_idtwo=NULL;
								subchild_item_idTwoRev=NULL;
								subchilditeamtwo=subchild_bom_linestwox[i1];
								printf("\nThis printf is for parent-child part\n");fflush(stdout);
//								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_item_item_id",&parent_item_idforadd);
//								ifail = AOM_ask_value_string(subchilditeamtwo ,"bl_rev_item_revision_id",&parentrev_foradd);
//								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_quantity",&Parentqty_foradd);
//								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_Design Revision_t5_ModuleAddress",&parent_item_idmodadd);
//								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_Design Revision_t5_ModuleName",&Parent_item_idmodName);

								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_item_item_id",&subchild_item_idtwo);
								ifail = AOM_ask_value_string(subchilditeamtwo ,"bl_rev_item_revision_id",&subchild_item_idTwoRev);
								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_quantity",&Childqty_fordel);
								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodadd);
								ifail = AOM_ask_value_string(subchilditeamtwo,"bl_Design Revision_t5_ModuleName",&Child_item_idmodName);
								STRNG_replace_str(Child_item_idmodName,",","-",&Child_item_idmodName);
								STRNG_replace_str(Child_item_idmodName,"\n","-",&Child_item_idmodName);
								STRNG_replace_str(Child_item_idmodName,"&","and",&Child_item_idmodName);
								ifail = AOM_UIF_ask_value(subchilditeamtwo,"bl_Design Revision_t5_CarMakeBuyIndicator",&methodplant);
								ifail = AOM_UIF_ask_value(subchilditeamtwo,"bl_level_starting_0",&item_level);
								ifail = AOM_UIF_ask_value(subchilditeamtwo,"object_desc",&ChildDescOne);
								STRNG_replace_str(ChildDescOne,",","-",&ChildDescOne);
								STRNG_replace_str(ChildDescOne,"\n","-",&ChildDescOne);
								STRNG_replace_str(ChildDescOne,"&","and",&ChildDescOne);
								printf("\nHere we are printing Both parts revision and sequence in delete [%s] [%s] [%s] [%s] \n",subchild_item_idtwo,subchild_item_idTwoRev,split1,split2);
								if ((tc_strcmp(subchild_item_idtwo,split1)==0) && (tc_strcmp(subchild_item_idTwoRev,split2)==0))
									{
										SrNOP=NULL;
										SerialNo=SerialNo+1;
										char* SrNOP = intToString(SerialNo);
										printf("\nThis is going into stop at F function for module %s\n",subchild_item_idtwo);
										//fprintf(fp,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,,,,,,,,\n",parent_item_idmodadd,Parent_item_idmodName,catry,parent_item_idforadd,parentrev_foradd,Parentqty_foradd,item_level,subchild_item_idtwo,subchild_item_idTwoRev,ChildDescOne,Childqty_foradd,methodplant,"","","","","","","","","");fflush(stdout);
										StopAtFfordelete(SrNOP,subchilditeamtwo,child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_fordel,Printflag,fp);
										//fprintf(fp,"\n%s,%s,%s,%s,%s,%s\n",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_foradd);
										free(SrNOP); // Free the dynamically allocated memory
									}

							}

			}

}
int StopAtFfordelete(char* SrNOP,tag_t subchilditeamtwo,char *child_item_idmodadd,char *Child_item_idmodName,char *catry,char *subchild_item_idtwo,char *subchild_item_idTwoRev,char *Childqty_fordel,int Printflag,FILE *fp)
{
		printf("\nThis is Stop at F funtion of delete modules\n");
		int ifail = ITK_ok;
		int CSFoundFlag = 0;
		int i1 =0;
		int qty =0;
		int subchildno_bom_linesonex = 0;
		char* methodplant = NULL;
		char* subchild_item_idtwotest = NULL;
		char* methodplantsplit = NULL;
		char* subchild_item_idtwoExp = NULL;
		char* subchild_item_idTwoRevExp = NULL;
		char* Childqty_foraddExp = NULL;
		char* child_item_idmodaddExp = NULL;
		char* Child_item_idmodNameExp = NULL;
		char* methodplantExp = NULL;
		char* item_levelExp = NULL;
		char* ChildDescOneExp = NULL;
		tag_t subchilditeamtwoex = NULLTAG;
		tag_t *subchild_bom_linesonex = NULLTAG;
		ifail = AOM_ask_value_string(subchilditeamtwo,"bl_item_item_id",&subchild_item_idtwotest);
		printf("\nPrint delete module for check %s\n",subchild_item_idtwotest);
		ifail = BOM_line_ask_child_lines(subchilditeamtwo,&subchildno_bom_linesonex,&subchild_bom_linesonex);
		if(subchildno_bom_linesonex>0)
			{
				for (i1=0;i1<subchildno_bom_linesonex;i1++)
					{
						CSFoundFlag = 0;
						printf("\nwe are under STOP AT F function\n");
						subchilditeamtwoex = subchild_bom_linesonex[i1];
						ifail = AOM_UIF_ask_value(subchilditeamtwoex,"bl_Design Revision_t5_CarMakeBuyIndicator",&methodplant);
						methodplantsplit = strtok(methodplant, " ");
						ifail = AOM_ask_value_string(subchilditeamtwoex,"bl_item_item_id",&subchild_item_idtwoExp);
						if (strstr(subchild_item_idtwoExp,"_")!=NULL)
						{
							continue;
						}
						printf("value of methodplantsplit in delete elemet function is %s for part %s",methodplantsplit,subchild_item_idtwoExp);
						ifail = AOM_ask_value_string(subchilditeamtwoex ,"bl_rev_item_revision_id",&subchild_item_idTwoRevExp);
						ifail = AOM_ask_value_string(subchilditeamtwoex,"bl_quantity",&Childqty_foraddExp);
						qty = atoi(Childqty_foraddExp);
						ifail = AOM_ask_value_string(subchilditeamtwoex,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodaddExp);
						ifail = AOM_ask_value_string(subchilditeamtwoex,"bl_Design Revision_t5_ModuleName",&Child_item_idmodNameExp);
						STRNG_replace_str(Child_item_idmodNameExp,",","-",&Child_item_idmodNameExp);
						STRNG_replace_str(Child_item_idmodNameExp,"\n","-",&Child_item_idmodNameExp);
						STRNG_replace_str(Child_item_idmodNameExp,"&","and",&Child_item_idmodNameExp);
						ifail = AOM_UIF_ask_value(subchilditeamtwoex,"bl_level_starting_0",&item_levelExp);
						ifail = AOM_UIF_ask_value(subchilditeamtwoex,"bl_item_object_desc",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,",","-",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,"\n","-",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,"&","and",&ChildDescOneExp);
						if (qty==0)
							{
								continue;
							}
						if((tc_strcmp(methodplantsplit,"F")==0) || (tc_strcmp(methodplantsplit,"F35")==0) || (tc_strcmp(methodplantsplit,"F40")==0) ||(tc_strcmp(methodplantsplit,"F18")==0) || (tc_strcmp(methodplantsplit,"F19")==0) || (tc_strcmp(methodplantsplit,"E99")==0))
							{
								CSFoundFlag=1;
							}
						else
							{
								printf(" P42:Found Other CS.\n");fflush(stdout);
								CSFoundFlag=0;
							}
						if(CSFoundFlag==0)
							{
								Printflag=Printflag+1;
								write2xml(Report,"<logo>\n");
								if (SrNOP != NULL)
									{
										printf("Converted string in delete function: %s\n", SrNOP);
										write2xml(Report,"<field key =\"Serial_No\">");
										write2xml(Report,SrNOP);
										write2xml(Report,"</field>\n");
									}
								write2xml(Report,"<field key =\"Module_address\">");
								write2xml(Report,child_item_idmodadd);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module_Name\">");
								write2xml(Report,Child_item_idmodName);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Category\">");
								write2xml(Report,catry);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Revision NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Quantity NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child level NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module's Child NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Revision NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Quantity NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Car make BY NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module RVC\">");
								write2xml(Report,subchild_item_idtwo);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Revision RVC\">");
								write2xml(Report,subchild_item_idTwoRev);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Quantity RVC\">");
								write2xml(Report,Childqty_fordel);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child level RVC\">");
								write2xml(Report,item_levelExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module's Child RVC\">");
								write2xml(Report,subchild_item_idtwoExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Revision RVC\">");
								write2xml(Report,subchild_item_idTwoRevExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
								write2xml(Report,ChildDescOneExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Quantity RVC\">");
								write2xml(Report,Childqty_foraddExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Car make BY RVC\">");
								write2xml(Report,methodplant);
								write2xml(Report,"</field>\n");
								write2xml(Report,"</logo>\n");
								printf("\nfp.4==> %s,%s,%s,,,,,,,,,,%s,%s,%s,%s,%s,%s,%s,%s,%s",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_fordel,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant);fflush(stdout);
								fprintf(fp,"\n%s,%s,%s,,,,,,,,,,%s,%s,%s,%s,%s,%s,%s,%s,%s",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_fordel,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant);fflush(fp);
								StopAtFfordelete(SrNOP,subchilditeamtwoex,child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_fordel,Printflag,fp);
							}
						else if(CSFoundFlag == 1)
							{
								write2xml(Report,"<logo>\n");
								if (SrNOP != NULL)
									{
										printf("Converted string in delete function: %s\n", SrNOP);
										write2xml(Report,"<field key =\"Serial_No\">");
										write2xml(Report,SrNOP);
										write2xml(Report,"</field>\n");
									}
								write2xml(Report,"<field key =\"Module_address\">");
								write2xml(Report,child_item_idmodadd);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module_Name\">");
								write2xml(Report,Child_item_idmodName);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Category\">");
								write2xml(Report,catry);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Revision NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Quantity NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child level NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module's Child NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Revision NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Quantity NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Car make BY NVC\">");
								write2xml(Report," ");
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module RVC\">");
								write2xml(Report,subchild_item_idtwo);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Revision RVC\">");
								write2xml(Report,subchild_item_idTwoRev);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Quantity RVC\">");
								write2xml(Report,Childqty_fordel);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child level RVC\">");
								write2xml(Report,item_levelExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module's Child RVC\">");
								write2xml(Report,subchild_item_idtwoExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Revision RVC\">");
								write2xml(Report,subchild_item_idTwoRevExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
								write2xml(Report,ChildDescOneExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Quantity RVC\">");
								write2xml(Report,Childqty_foraddExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Car make BY RVC\">");
								write2xml(Report,methodplant);
								write2xml(Report,"</field>\n");
								write2xml(Report,"</logo>\n");
								printf("\nfp.5==> %s,%s,%s,,,,,,,,,,%s,%s,%s,%s,%s,%s,%s,%s,%s",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_fordel,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant);fflush(stdout);
								fprintf(fp,"\n%s,%s,%s,,,,,,,,,,%s,%s,%s,%s,%s,%s,%s,%s,%s",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_fordel,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant);fflush(fp);

							}
			}
	}
	else
		{
			if(Printflag == 0)
				{
					item_levelExp = " --- ";
					subchild_item_idtwoExp = " --- ";
					subchild_item_idTwoRevExp = " --- ";
					ChildDescOneExp = " --- ";
					Childqty_foraddExp = " --- ";
					methodplant = " --- ";
					write2xml(Report,"<logo>\n");
					if (SrNOP != NULL)
						{
							printf("Converted string in Delete Function: %s\n", SrNOP);
							write2xml(Report,"<field key =\"Serial_No\">");
							write2xml(Report,SrNOP);
							write2xml(Report,"</field>\n");
						}
					write2xml(Report,"<field key =\"Module_address\">");
					write2xml(Report,child_item_idmodadd);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Module_Name\">");
					write2xml(Report,Child_item_idmodName);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Category\">");
					write2xml(Report,catry);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Module NVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Revision NVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Quantity NVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child level NVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Module's Child NVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Revision NVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Quantity NVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Car make BY NVC\">");
					write2xml(Report," ");
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Module RVC\">");
					write2xml(Report,subchild_item_idtwo);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Revision RVC\">");
					write2xml(Report,subchild_item_idTwoRev);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Quantity RVC\">");
					write2xml(Report,Childqty_fordel);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child level RVC\">");
					write2xml(Report,item_levelExp);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Module's Child RVC\">");
					write2xml(Report,subchild_item_idtwoExp);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Revision RVC\">");
					write2xml(Report,subchild_item_idTwoRevExp);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
					write2xml(Report,ChildDescOneExp);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Child Quantity RVC\">");
					write2xml(Report,Childqty_foraddExp);
					write2xml(Report,"</field>\n");
					write2xml(Report,"<field key =\"Car make BY RVC\">");
					write2xml(Report,methodplant);
					write2xml(Report,"</field>\n");
					write2xml(Report,"</logo>\n");
					printf("fp.6==> \n%s,%s,%s,,,,,,,,,,%s,%s,%s,%s,%s,%s,%s,%s,%s",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_fordel,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant);fflush(stdout);
					fprintf(fp,"\n%s,%s,%s,,,,,,,,,,%s,%s,%s,%s,%s,%s,%s,%s,%s",child_item_idmodadd,Child_item_idmodName,catry,subchild_item_idtwo,subchild_item_idTwoRev,Childqty_fordel,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplant);fflush(fp);
				}

		}
}
int BOMExpansionforReplace(tag_t Child_bom_linestwo,tag_t Child_bom_linesone)
	{
		int ifail = ITK_ok;
		int i1=0;
		int i2=0;
		char *subchild_item_idtwo=NULL;
		char *subchild_item_idone=NULL;
		char *subchild_item_idtwoRev=NULL;
		char *subchild_item_idoneRev=NULL;
		char *child_item_idmodaddone=NULL;
		char *child_item_idmodaddtwo=NULL;
		int subchildno_bom_linestwox = 0;
		int subchildno_bom_linesonex = 0;
		tag_t *subchild_bom_linestwox = NULLTAG;
		tag_t *subchild_bom_linesonex = NULLTAG;
		tag_t subchilditeam = NULLTAG;
		tag_t subchilditeamone = NULLTAG;
		ifail = BOM_line_ask_child_lines(Child_bom_linestwo,&subchildno_bom_linestwox,&subchild_bom_linestwox);
		printf("\n value of subchildno_bom_linestwox in ref VC is in Replace Expand function %d",subchildno_bom_linestwox);
		for (i1=0;i1<subchildno_bom_linestwox;i1++)
					{
						subchild_item_idtwo=NULL;
						subchild_item_idtwoRev=NULL;
						subchilditeam=subchild_bom_linestwox[i1];
						ifail = AOM_ask_value_string(subchilditeam,"bl_item_item_id",&subchild_item_idtwo);
						ifail = AOM_ask_value_string(subchilditeam ,"bl_rev_item_revision_id",&subchild_item_idtwoRev);
						ifail = AOM_ask_value_string(subchilditeam,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodaddtwo);
						//printf("\nsubchild of VCT %s\n",subchild_item_idtwo);
						//printf("\n subchild part of ref vc in Replace function BOMExpansionforReplace [%s] [%s] [%s] \n",subchild_item_idtwo,subchild_item_idtwoRev,child_item_idmodaddtwo);
						ifail = BOM_line_ask_child_lines(Child_bom_linesone,&subchildno_bom_linesonex,&subchild_bom_linesonex);
						//printf("\n Size of ref VC BOM is %d \n",subchildno_bom_linesonex);fflush(stdout);
						for (i2=0; i2<subchildno_bom_linesonex;i2++)
							{
								subchild_item_idone=NULL;
								subchild_item_idoneRev=NULL;
								subchilditeamone=subchild_bom_linesonex[i2];
								ifail = AOM_ask_value_string(subchilditeamone,"bl_item_item_id",&subchild_item_idone);
								ifail = AOM_ask_value_string(subchilditeamone ,"bl_rev_item_revision_id",&subchild_item_idoneRev);
								ifail = AOM_ask_value_string(subchilditeamone,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodaddone);
								printf("\nHere we are printing Both parts revision and sequence inside function BOMExpansionforReplace[%s] [%s] [%s] [%s] [%s] [%s]\n",subchild_item_idtwo,subchild_item_idtwoRev,child_item_idmodaddtwo,subchild_item_idone,subchild_item_idoneRev,child_item_idmodaddone);
								if (((tc_strcmp(child_item_idmodaddone,child_item_idmodaddtwo)==0)) && ((tc_strcmp(subchild_item_idtwo,subchild_item_idone)!=0)))
									{
										if((tc_strlen(child_item_idmodaddone) > 2) && (tc_strlen(child_item_idmodaddtwo)) > 2)
										{
											addelementforReplaceT(subchild_item_idtwo,subchild_item_idtwoRev);
											addelementforReplaceO(subchild_item_idone,subchild_item_idoneRev);
											break;
										}
									}

							}

					 }
	}

int addelementforReplaceT(char* subchild_item_idtwo, char* subchild_item_idtwoRev)
	{
		tc_strcat(subchild_item_idtwo,"#");
		tc_strcat(subchild_item_idtwo,subchild_item_idtwoRev);
		if(setFindStr1(&tt4,&childPartFive,subchild_item_idtwo)==-1)
		{
			//setAddStr(&iWrite,&SSDetails,PartNumber);
			setAddStrFive(&tt4,&childPartFive,subchild_item_idtwo);
			printf("\n Set of add element into ref VC [%s] added directly inside Replace function \n",subchild_item_idtwo);fflush(stdout);
		}
		return 0;

	}
int addelementforReplaceO(char* subchild_item_idone, char* subchild_item_idoneRev)
	{
		tc_strcat(subchild_item_idone,"#");
		tc_strcat(subchild_item_idone,subchild_item_idoneRev);
		if(setFindStr1(&tt5,&childPartSix,subchild_item_idone)==-1)
		{
			//setAddStr(&iWrite,&SSDetails,PartNumber);
			setAddStrSix(&tt5,&childPartSix,subchild_item_idone);
			printf("\n Set of add element into New VC [%s] added directly inside Replace function \n",subchild_item_idone);fflush(stdout);
		}
		return 0;

	}
int GetValuefromStrFunc(tag_t Child_bom_linestwo,tag_t Child_bom_linesone)
	{
		int LLM=0;
		int tempcount=0;
		int MAX1=0;
		int MAX2=0;
		int diff1=0;
		int diff2=0;
		int count1=0;
		int count2=0;
		int add1=0;
		int add2=0;
		int NLP=0;
		int S=0;
		int tt6pre=0;
		int tt7pre=0;
		int* count1_ptr=&count1;
		int* count2_ptr=&count2;
		char* StrFromStr1 = NULL;
		char* StrFromStr2 = NULL;
		for (LLM=0;LLM<tt4;LLM++)
		{
			MAX1=0;
			MAX2=0;
			diff1=0;
			diff2=0;
			count1=0;
			count2=0;
			add1=0;
			add2=0;
			StrFromStr1 = NULL;
			StrFromStr2 = NULL;
			StrFromStr1=childPartFive[LLM];
			StrFromStr2=childPartSix[LLM];
			Printtocheck(Child_bom_linestwo,Child_bom_linesone,StrFromStr1,StrFromStr2);
			printf("\n Count of tt6 before is %d \n",tt6);fflush(stdout);
			printf("\n Count of tt7 before is %d \n",tt7);fflush(stdout);
			printf("\n Count of tt6pre before is %d \n",tt6pre);fflush(stdout);
			printf("\n Count of tt7pre before is %d \n",tt7pre);fflush(stdout);
			diff1=tt6-tt6pre;
			printf("\n Count of diff1 is %d \n",diff1);fflush(stdout);
			diff2=tt7-tt7pre;
			printf("\n Count of diff2 is %d \n",diff2);fflush(stdout);
			printf("\n Count of TT6 is %d \n",tt6);fflush(stdout);
			printf("\n Count of TT7 is %d \n",tt7);fflush(stdout);
			//printf("\n value of Count1 and Cont2 is %d %d \n",*count1_ptr,*count2_ptr);fflush(stdout);
			if(diff1>diff2)
				{
					add1=diff1-diff2;
					MAX1=diff1;

				}
			else if(diff1<diff2)
				{
					add2=diff2-diff1;
					MAX2=diff2;
				}
			if(MAX1>0)
			{
				for (NLP=0;NLP<add1;NLP++)
					{
						setAddStrRep2(&tt7,&childPartRep2,"###*###*###");
					}
				printf("\n After adding Count of TT7 is %d \n",tt7);fflush(stdout);
			}
			else if(MAX2>0)
			{
				for (S=0;S<add2;S++)
					{
						setAddStrRep(&tt6,&childPartRep1,"###*###*###");

					}
					printf("\n After adding Count of TT6 is %d \n",tt6);fflush(stdout);

			}
		setAddStrRep2(&tt7,&childPartRep2,"$");
		setAddStrRep(&tt6,&childPartRep1,"$");
		tt7pre=tt7;
		tt6pre=tt6;
		printf("\n tt6 value in each traversal %d \n",tt6);fflush(stdout);
		printf("\n tt7 value in each traversal %d \n",tt7);fflush(stdout);
		}
	printf("\n final tt6 vlaue is %d \n",tt6);fflush(stdout);
	printf("\n final tt7 vlaue is %d \n",tt7);fflush(stdout);
	return 0;
	}
int Printtocheck(tag_t Child_bom_linestwo,tag_t Child_bom_linesone,char* StrFromStr1,char* StrFromStr2)
	{
		int ifail = ITK_ok;
		int i1=0;
		int i=0;
		int i2=0;
		int i5=0;
		int subchildno_bom_linestwo=0;
		int subchildno_bom_linesone=0;
		int i6=0;
		int returnvalue=0;
		int subchildno_bom_linesx=0;
		int countflag=0;
		char *subchild_item_idtwo=NULL;
		char *split1=NULL;
		char *split2=NULL;
		char *split3=NULL;
		char *split4=NULL;
		char *temppartone=NULL;
		char *temppart=NULL;
		char *subchild_item_idone=NULL;
		char *subchild_item_idtwoRev=NULL;
		char *subchild_item_idoneRev=NULL;
		char *child_item_idmodaddnone=NULL;
		char *child_item_idmodaddtwo=NULL;
		int subchildno_bom_linestwox = 0;
		int subchildno_bom_linesonex = 0;
		tag_t *subchild_bom_linestwox = NULLTAG;
		tag_t *subchild_bom_linesonex = NULLTAG;
		tag_t *Child_bom_linestwox = NULLTAG;
		tag_t *Child_bom_linesonex = NULLTAG;
		tag_t subchilditeam = NULLTAG;
		tag_t subchilditeamone = NULLTAG;
		split1 = strtok(StrFromStr1,"#");
		split2 = strtok(NULL,"#");
		ifail = BOM_line_ask_child_lines(Child_bom_linestwo,&subchildno_bom_linestwox,&subchild_bom_linestwox);
		printf("\nValue of count in Child_bom_linestwo is %d\n",subchildno_bom_linestwox);fflush(stdout);
			for (i1=0;i1<subchildno_bom_linestwox;i1++)
				{
						//countflag=0;
						subchild_item_idtwo=NULL;
						subchild_item_idtwoRev=NULL;
						child_item_idmodaddtwo=NULL;
						subchilditeam=subchild_bom_linestwox[i1];
						ifail = AOM_ask_value_string(subchilditeam,"bl_item_item_id",&subchild_item_idtwo);
						ifail = AOM_ask_value_string(subchilditeam ,"bl_rev_item_revision_id",&subchild_item_idtwoRev);
						ifail = AOM_ask_value_string(subchilditeam,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodaddtwo);
						if ((tc_strcmp(subchild_item_idtwo,split1)==0))
									{
										printf("\n value of subchild_item_idtwo in Printtocheck %s\n",subchild_item_idtwo);fflush(stdout);										
										ifail = BOM_line_ask_child_lines(subchilditeam,&subchildno_bom_linestwo,&Child_bom_linestwox);
										printf("\nvalue of subchildno_bom_linestwo in function Printtocheck %d\n",subchildno_bom_linestwo);
										if(subchildno_bom_linestwo>0)
											{
												ExpandtillstopAtFvalue(subchilditeam,split1,split2);
												break;
											}
										else
											{
												break;												
											}
										//printforchildPartRep1value(subchilditeam);
									}

				}
			split3 = strtok(StrFromStr2,"#");
			split4 = strtok(NULL,"#");
			ifail = BOM_line_ask_child_lines(Child_bom_linesone,&subchildno_bom_linesx,&subchild_bom_linesonex);
			printf("\nValue of count in Child_bom_linesone is %d\n",subchildno_bom_linesx);fflush(stdout);
			for (i6=0;i6<subchildno_bom_linesx;i6++)
				{
						//countflag=0;
						subchild_item_idone=NULL;
						subchild_item_idoneRev=NULL;
						child_item_idmodaddnone=NULL;
						subchilditeamone=subchild_bom_linesonex[i6];
						ifail = AOM_ask_value_string(subchilditeamone,"bl_item_item_id",&subchild_item_idone);
						ifail = AOM_ask_value_string(subchilditeamone ,"bl_rev_item_revision_id",&subchild_item_idoneRev);
						ifail = AOM_ask_value_string(subchilditeamone,"bl_Design Revision_t5_ModuleAddress",&child_item_idmodaddnone);
						if ((tc_strcmp(subchild_item_idone,split3)==0))
								{
									printf("\n value of subchild_item_idone in Printtocheck %s\n",subchild_item_idone);fflush(stdout);
									ifail = BOM_line_ask_child_lines(subchilditeamone,&subchildno_bom_linesone,&Child_bom_linesonex);
									printf("\nvalue of subchildno_bom_linesone in function Printtocheck %d\n",subchildno_bom_linestwo);
									if(subchildno_bom_linesone>0)
										{
											ExpandtillstopAtFvalueTwo(subchilditeamone,split3,split4);
											break;
										}
									else
										{
											break;												
										}
									//break;
									//printforchildPartRep2value(subchilditeamone);
								}

				}
	return 0;
}
int ExpandtillstopAtFvalue(tag_t subchilditeamEX, char* split1, char* split2)
{
	int ifail = ITK_ok;
	int subchildno_bom_linestwo = 0;
	int CSFoundFlag = 0;
	char* subchild_item_idtwo= NULL;
	char* subchild_item_idtwoPre= NULL;
	char* item_levelExpchecktwo= NULL;
	char* subchild_item_idtwoRev= NULL;
	char* subchild_item_idtwomodaddnone= NULL;
	char* carmethodplant= NULL;
	char* methodplantsplit= NULL;
	int ML = 0;
	tag_t subchilditeamtwo = NULLTAG;
	tag_t *Child_bom_linestwox = NULLTAG;
	printf("\nInside function ExpandtillstopAtFvalue\n");fflush(stdout);
	ifail = AOM_ask_value_string(subchilditeamEX,"bl_item_item_id",&subchild_item_idtwoPre);
	ifail = BOM_line_ask_child_lines(subchilditeamEX,&subchildno_bom_linestwo,&Child_bom_linestwox);
	if(subchildno_bom_linestwo>0)
	{
	    for (ML=0;ML<subchildno_bom_linestwo;ML++)
	    {
	    	subchilditeamtwo=Child_bom_linestwox[ML];
			printf(" Print value of ML. %d\n",ML);fflush(stdout);
	    	ifail = AOM_ask_value_string(subchilditeamtwo,"bl_item_item_id",&subchild_item_idtwo);
	    	if (strstr(subchild_item_idtwo,"_")!=NULL)
	    		{
	    			continue;
	    		}
	    	ifail = AOM_ask_value_string(subchilditeamtwo ,"bl_rev_item_revision_id",&subchild_item_idtwoRev);
	    	ifail = AOM_ask_value_string(subchilditeamtwo,"bl_Design Revision_t5_ModuleAddress",&subchild_item_idtwomodaddnone);
	    	ifail = AOM_UIF_ask_value(subchilditeamtwo,"bl_Design Revision_t5_CarMakeBuyIndicator",&carmethodplant);
	    	ifail = AOM_UIF_ask_value(subchilditeamtwo,"bl_level_starting_0",&item_levelExpchecktwo);
	    	tc_strcat(subchild_item_idtwo,"*");
	    	tc_strcat(subchild_item_idtwo,subchild_item_idtwoPre);
	    	tc_strcat(subchild_item_idtwo,"*");
	    	tc_strcat(subchild_item_idtwo,item_levelExpchecktwo);
	    	methodplantsplit = strtok(carmethodplant, " ");
	    	if((tc_strcmp(methodplantsplit,"F")==0) || (tc_strcmp(methodplantsplit,"F35")==0) || (tc_strcmp(methodplantsplit,"F40")==0) ||(tc_strcmp(methodplantsplit,"F18")==0) || (tc_strcmp(methodplantsplit,"F19")==0) || (tc_strcmp(methodplantsplit,"E99")==0))
	    						{
	    							CSFoundFlag=1;
	    						}
	    					else
	    						{
	    							printf(" P42:Found Other CS.\n");fflush(stdout);
	    							CSFoundFlag=0;
	    						}
	    					if(CSFoundFlag==0)
	    						{
	    							if(setFindStr2s(&tt6,&childPartRep1,subchild_item_idtwo)==-1)
	    								{
	    									setAddStrRep(&tt6,&childPartRep1,subchild_item_idtwo);
	    									printf("\n Set of add element into concadinated with in ref VC * value in and CSFoundFlag is %d tt6 \n",CSFoundFlag);fflush(stdout);
	    									printf("\n After adding %s in childPartRep1\n",subchild_item_idtwo);fflush(stdout);
	    									ExpandtillstopAtFvalue(subchilditeamtwo,split1,split2);
	    								}
	    
	    						}
	    					else if(CSFoundFlag==1)
	    						{
	    							if(setFindStr2s(&tt6,&childPartRep1,subchild_item_idtwo)==-1)
	    								{
	    									setAddStrRep(&tt6,&childPartRep1,subchild_item_idtwo);
	    									printf("\n After adding %s in childPartRep1\n",subchild_item_idtwo);fflush(stdout);
	    									printf("\n Set of add element into concadinated in ref VC with * value and CSFoundFlag value is %d in tt6 \n",CSFoundFlag);fflush(stdout);
	    								}
	    							else
	    								{
	    									printf("\nAdding for debugging in else condition of addsring1\n");fflush(stdout);
	    								}
	    							printf("\nAfter countflag printf\n");fflush(stdout);
	    						}
	    						printf("\nBefore memory free\n");fflush(stdout);
	}
}
else
	{
		printf("\n Function ExpandtillstopAtFvalue ==> %s part not having any BOM line\n",subchild_item_idtwoPre);fflush(stdout);
	}
return 0;
	//printforchildPartRep1value(subchilditeamEX);
}
//int printforchildPartRep1value(tag_t subchilditeamEX)
//{
//	int ifail = ITK_ok;
//	int CV = 0;
//	int subchildno_bom_linestwo = 0;
//	tag_t *Child_bom_linestwoP = NULLTAG;
//	char* subchilditeamtwoPT = NULLTAG;
//	for (CV=0;CV<tt6;CV++)
//	{
//		subchilditeamtwoPT=childPartRep1[CV];
//		printf("\nThe value of subchilditeamtwoPT is %s\n",subchilditeamtwoPT);fflush(stdout);
//
//
//	}
//}
int ExpandtillstopAtFvalueTwo(tag_t subchilditeamoneEx,char* split3, char* split4)
{
	int ifail = ITK_ok;
	int subchildno_bom_linesone = 0;
	int CSFoundFlagone = 0;
	char* subchild_item_idone= NULL;
	char* subchild_item_idoneRev= NULL;
	char* subchild_item_idonePre= NULL;
	char* subchild_item_idonemodaddnone= NULL;
	char* carmethodplantone= NULL;
	char* carmethodplant= NULL;
	char* methodplantsplitone= NULL;
	char* item_levelExpcheckOne= NULL;
	int DL = 0;
	//int count2_add = *count2;
	tag_t subchilditeamone = NULLTAG;
	tag_t *Child_bom_linesonex = NULLTAG;
	ifail = AOM_ask_value_string(subchilditeamoneEx,"bl_item_item_id",&subchild_item_idonePre);
	ifail = BOM_line_ask_child_lines(subchilditeamoneEx,&subchildno_bom_linesone,&Child_bom_linesonex);
	if(subchildno_bom_linesone>0)
	{
	    for (DL=0;DL<subchildno_bom_linesone;DL++)
	    {
	    	subchilditeamone=Child_bom_linesonex[DL];
	    	ifail = AOM_ask_value_string(subchilditeamone,"bl_item_item_id",&subchild_item_idone);
	    	if (strstr(subchild_item_idone,"_")!=NULL)
	    		{
	    			continue;
	    		}
	    	ifail = AOM_ask_value_string(subchilditeamone ,"bl_rev_item_revision_id",&subchild_item_idoneRev);
	    	ifail = AOM_ask_value_string(subchilditeamone,"bl_Design Revision_t5_ModuleAddress",&subchild_item_idonemodaddnone);
	    	ifail = AOM_UIF_ask_value(subchilditeamone,"bl_Design Revision_t5_CarMakeBuyIndicator",&carmethodplantone);
	    	ifail = AOM_UIF_ask_value(subchilditeamone,"bl_level_starting_0",&item_levelExpcheckOne);
	    	tc_strcat(subchild_item_idone,"*");
	    	tc_strcat(subchild_item_idone,subchild_item_idonePre);
	    	tc_strcat(subchild_item_idone,"*");
	    	tc_strcat(subchild_item_idone,item_levelExpcheckOne);
	    	methodplantsplitone = strtok(carmethodplantone, " ");
	    	if((tc_strcmp(methodplantsplitone,"F")==0) || (tc_strcmp(methodplantsplitone,"F35")==0) || (tc_strcmp(methodplantsplitone,"F40")==0) ||(tc_strcmp(methodplantsplitone,"F18")==0) || (tc_strcmp(methodplantsplitone,"F19")==0) || (tc_strcmp(methodplantsplitone,"E99")==0))
	    						{
	    							CSFoundFlagone=1;
	    						}
	    					else
	    						{
	    							printf(" P42:Found Other CS.\n");fflush(stdout);
	    							CSFoundFlagone=0;
	    						}
	    					if(CSFoundFlagone==0)
	    								{
	    									if(setFindStr3s(&tt7,&childPartRep2,subchild_item_idone)==-1)
	    										{
	    											setAddStrRep2(&tt7,&childPartRep2,subchild_item_idone);
	    											printf("\n Set of add element into concadinated with in Main VC * value for CSFoundFlagone value is %d in tt7 \n",CSFoundFlagone);fflush(stdout);
	    											ExpandtillstopAtFvalueTwo(subchilditeamone,split3,split4);
	    										}
	    
	    							}
	    							else if(CSFoundFlagone == 1)
	    								{
	    									if(setFindStr3s(&tt7,&childPartRep2,subchild_item_idone)==-1)
	    										{
	    											setAddStrRep2(&tt7,&childPartRep2,subchild_item_idone);
	    											printf("\nchanging for debugging Set of add element into concadinated with in Main VC * value for CSFoundFlagone value is %d in tt7\n",CSFoundFlagone);fflush(stdout);
	    										}
	    								}
	     }

	}
else
	{
		printf("\n Function ExpandtillstopAtFvalueTwo ==> %s part not having any BOM line\n",subchild_item_idonePre);fflush(stdout);
	}
return 0;
}
//int printforchildPartRep2value(tag_t subchilditeamEXRep2)
//{
//	int ifail = ITK_ok;
//	int DS = 0;
//	int subchildno_bom_linesone = 0;
//	tag_t *Child_bom_linesoneP = NULLTAG;
//	char* subchilditeamonePT = NULLTAG;
//	for (DS=0;DS<tt7;DS++)
//	{
//		subchilditeamonePT=childPartRep2[DS];
//		printf("\nThe value of subchilditeamonePT is %s\n",subchilditeamonePT);fflush(stdout);
//
//
//	}
//}
int Getprintaddmodvalue(tag_t Child_bom_linestwo,tag_t Child_bom_linesone,FILE *fp)
	{
		int ifail = ITK_ok;
		int PP = 0;
		int KK = 0;
		int JJ = 0;
		int countF = 0;
		//char *SrNOP = NULL;
		int countF2 = 0;
		int subchildno_bom_linestwo = 0;
		int subchildno_bom_linesone = 0;
		char* StrFromStrP1 = NULL;
		char* StrFromStrP2 = NULL;
		char* subchild_item_idone = NULL;
		char* subchild_item_idtwo = NULL;
		char* subchild_item_idonetwo = NULL;
		char* subchild_item_idonemodaddntwo = NULL;
		char* item_levelExpchecktwo = NULL;
		char* carmethodplanttwo = NULL;
		char* Child_item_idmodNametwo = NULL;
		char* subchild_item_idoneRev = NULL;
		char* subchild_item_idonemodaddnone = NULL;
		char* Child_item_idmodNameone = NULL;
		char* carmethodplantone = NULL;
		char* item_levelExpcheckOne = NULL;
		char* Childqty_foraddtwo = NULL;
		char* Childqty_foraddone = NULL;
		char* subchild_item_idonetemp = NULL;
		char* subchild_item_idtwotemp = NULL;
		char* Caty = NULL;
		char* SrNOP = NULL;
		Caty="Replace";
		tag_t *Child_bom_linestwox = NULLTAG;
		tag_t *Child_bom_linesonex = NULLTAG;
		tag_t Subchildtag = NULLTAG;
		tag_t SubchildtagOne = NULLTAG;
		for(PP=0;PP<tt5;PP++)
		{
			Child_bom_linestwox = NULLTAG;
			Child_bom_linesonex = NULLTAG;
			Subchildtag = NULLTAG;
			SubchildtagOne = NULLTAG;
			subchild_item_idone = NULL;
			subchild_item_idoneRev = NULL;
			Child_item_idmodNameone = NULL;
			subchild_item_idonemodaddnone = NULL;
			item_levelExpcheckOne = NULL;
			carmethodplantone = NULL;
			subchild_item_idtwo = NULL;
			subchild_item_idonemodaddntwo = NULL;
			carmethodplanttwo = NULL;
			Child_item_idmodNametwo = NULL;
			item_levelExpchecktwo = NULL;
			subchild_item_idonetwo = NULL;
			Childqty_foraddone = NULL;
			Childqty_foraddtwo = NULL;
			subchildno_bom_linestwo=0;
			subchildno_bom_linesone=0;
			countF=0;
			countF2=0;
			StrFromStrP1=childPartFive[PP];
			StrFromStrP2=childPartSix[PP];
			printf("\nInside GetValuefromStrFuncP for check print\n");fflush(stdout);
			printf("value of StrFromStrP1 is [%s]",StrFromStrP1);fflush(stdout);
			printf("value of StrFromStrP2 is [%s]",StrFromStrP2);fflush(stdout);
			ifail = BOM_line_ask_child_lines(Child_bom_linestwo,&subchildno_bom_linestwo,&Child_bom_linestwox);
			printf("\ncount of subchildno_bom_linestwo is %d\n",subchildno_bom_linestwo);
			for (KK=0;KK<subchildno_bom_linestwo;KK++)
			{
				Subchildtag=Child_bom_linestwox[KK];
				ifail = AOM_ask_value_string(Subchildtag,"bl_item_item_id",&subchild_item_idtwo);
				ifail = AOM_ask_value_string(Subchildtag ,"bl_rev_item_revision_id",&subchild_item_idonetwo);
				ifail = AOM_ask_value_string(Subchildtag,"bl_Design Revision_t5_ModuleAddress",&subchild_item_idonemodaddntwo);
				ifail = AOM_ask_value_string(Subchildtag,"bl_Design Revision_t5_ModuleName",&Child_item_idmodNametwo);
				ifail = AOM_UIF_ask_value(Subchildtag,"bl_Design Revision_t5_CarMakeBuyIndicator",&carmethodplanttwo);
				ifail = AOM_ask_value_string(Subchildtag,"bl_quantity",&Childqty_foraddtwo);
				ifail = AOM_UIF_ask_value(Subchildtag,"bl_level_starting_0",&item_levelExpchecktwo);
				countF2=countF2+1;
				if((tc_strcmp(subchild_item_idtwo,StrFromStrP1)==0))
					{
						printf("\nModule address parts matched here in subchildno_bom_linestwo %d\n",countF2);fflush(stdout);
						break;
					}
				printf("\ncountF2 value in subchildno_bom_linestwo %d\n",countF2);fflush(stdout);

			}
			ifail = BOM_line_ask_child_lines(Child_bom_linesone,&subchildno_bom_linesone,&Child_bom_linesonex);
			for (JJ=0;JJ<subchildno_bom_linesone;JJ++)
			{
				SubchildtagOne=Child_bom_linesonex[JJ];
				ifail = AOM_ask_value_string(SubchildtagOne,"bl_item_item_id",&subchild_item_idone);
				ifail = AOM_ask_value_string(SubchildtagOne ,"bl_rev_item_revision_id",&subchild_item_idoneRev);
				ifail = AOM_ask_value_string(SubchildtagOne,"bl_Design Revision_t5_ModuleAddress",&subchild_item_idonemodaddnone);
				ifail = AOM_ask_value_string(SubchildtagOne,"bl_Design Revision_t5_ModuleName",&Child_item_idmodNameone);
				STRNG_replace_str(Child_item_idmodNameone,",","-",&Child_item_idmodNameone);
				STRNG_replace_str(Child_item_idmodNameone,"\n","-",&Child_item_idmodNameone);
				STRNG_replace_str(Child_item_idmodNameone,"&","and",&Child_item_idmodNameone);
				ifail = AOM_UIF_ask_value(SubchildtagOne,"bl_Design Revision_t5_CarMakeBuyIndicator",&carmethodplantone);
				ifail = AOM_ask_value_string(SubchildtagOne,"bl_quantity",&Childqty_foraddone);
				ifail = AOM_UIF_ask_value(SubchildtagOne,"bl_level_starting_0",&item_levelExpcheckOne);
				countF=countF+1;
				if((tc_strcmp(subchild_item_idone,StrFromStrP2)==0))
					{
						printf("\nModule address parts matched here in subchildno_bom_linesone %d\n",countF);fflush(stdout);
						break;
					}
				printf("\n CountF value printing in subchildno_bom_linesone %d\n",countF);fflush(stdout);

			}
		 ifail = AOM_ask_value_string(SubchildtagOne,"bl_item_item_id",&subchild_item_idonetemp);
		 ifail = AOM_ask_value_string(Subchildtag,"bl_item_item_id",&subchild_item_idtwotemp);
		 printf("\nvalue of subchild_item_idonetemp and subchild_item_idtwotemp is in Getprintaddmodvalue [%s] [%s]\n",subchild_item_idonetemp,subchild_item_idtwotemp);
		 printf("\n value printing of  StrFromStrP2 and StrFromStrP1 [%s] [%s]\n",StrFromStrP2,StrFromStrP1);fflush(stdout);
		 SerialNo=SerialNo+1;
		 char* SrNOP = intToString(SerialNo);
		 printf("value of SrNOP is %s",SrNOP);fflush(stdout);
		 PrintFuncforreplace(SrNOP,SubchildtagOne,subchild_item_idonemodaddnone,Child_item_idmodNameone,Caty,subchild_item_idone,subchild_item_idoneRev,Childqty_foraddone,Subchildtag,subchild_item_idtwo,subchild_item_idonetwo,Childqty_foraddtwo,fp);
		free(SrNOP); // Free the dynamically allocated memory
		}
	return 0;
	}
int PrintFuncforreplace(char* SrNOP,tag_t SubchildtagOne,char* subchild_item_idonemodaddnone,char* Child_item_idmodNameone,char* Caty,char* subchild_item_idone,char* subchild_item_idoneRev,char* Childqty_foraddone,tag_t Subchildtag,char* subchild_item_idtwo,char* subchild_item_idonetwo,char* Childqty_foraddtwo,FILE *fp)
	{
		char* tokenX4 = NULL;
		char* tokenX3 = NULL;
		int LL=0;
		int i1 =0;
		int subchildno_bom_linestwo=0;
		tag_t *subchild_bom_linestwo = NULLTAG;
		tag_t subchilditeamX = NULLTAG;
		for(LL=start;LL<tt6;LL++)
		{
			tokenX4=childPartRep2[LL];
			tokenX3=childPartRep1[LL];
			if((tc_strcmp(tokenX4,"$")==0) && (tc_strcmp(tokenX3,"$")==0))
					{
						break;
					}
			printf("\nvalue of tokenX4 and tokenX3 is %s %s\n",tokenX4,tokenX3);fflush(stdout);
			 write2xml(Report,"<logo>\n");
			 if (SrNOP != NULL)
				{
					printf("Converted string: %s\n", SrNOP);
					write2xml(Report,"<field key =\"Serial_No\">");
					write2xml(Report,SrNOP);
					write2xml(Report,"</field>\n");
				/*** Converting int to string ***/
			callingVCOforptint(tokenX4,SubchildtagOne,subchild_item_idonemodaddnone,Child_item_idmodNameone,Caty,subchild_item_idone,subchild_item_idoneRev,Childqty_foraddone,fp);
			callingVCTforptint(tokenX3,Subchildtag,subchild_item_idtwo,subchild_item_idoneRev,Childqty_foraddone,fp);
				}
			write2xml(Report,"</logo>\n");
		}
	start=LL;
	start++;
	printf("value of in LL=start %d == %d",LL,start);fflush(stdout);
	return 0;
	}
int callingVCOforptint(char* tokenX4,tag_t SubchildtagOne,char* subchild_item_idonemodaddnone,char* Child_item_idmodNameone,char* Caty,char* subchild_item_idone,char* subchild_item_idoneRev,char* Childqty_foraddone,FILE *fp)
	{
		printf("\nvalue of tokenX4 in function callingVCOforptint %s\n",tokenX4);fflush(stdout);
		char* split1 = NULL;
		char* split2 = NULL;
		char* split3 = NULL;
		if (tc_strstr(tokenX4,"#")!=NULL)
		{
			split1 = strtok(tokenX4,"*");
			split2 = strtok(NULL,"*");
			split3 = strtok(NULL,"*");
		}
		else
			{
			split1 = strtok(tokenX4,"*");
			split2 = strtok(NULL,"*");
			split3 = strtok(NULL,"*");
			}
		printf("\nvalue of split1 split2 split3 is [%s] [%s] [%s]\n",split1,split2,split3);fflush(stdout);
		Pirntreplacestopatf(split1,split2,split3,SubchildtagOne,subchild_item_idonemodaddnone,Child_item_idmodNameone,Caty,subchild_item_idone,subchild_item_idoneRev,Childqty_foraddone,fp);
		return 0;

	}
int Pirntreplacestopatf(char* split1,char* split2,char* split3,tag_t SubchildtagOne,char* subchild_item_idonemodaddnone,char* Child_item_idmodNameone,char* Caty,char* subchild_item_idone,char* subchild_item_idoneRev,char* Childqty_foraddone,FILE *fp)
{
		int ifail = ITK_ok;
		char* subchild_item_idOne = NULL;
		char* subchild_item_idOneRev = NULL;
		char* child_item_idmodadd = NULL;
		char* Child_item_idmodName = NULL;
		char* Childqty_foraddExp = NULL;
		tag_t subchilditeamX = NULLTAG;
		int subchildno_bom_linesOnechild = 0;
		tag_t *subchild_bom_linesOnechild = NULLTAG;
		tag_t subchilditeamEX = NULLTAG;
		char* subchild_item_idtwoExp = NULL;
		char* temppartmatch = NULL;
		char* subchild_item_idTwoRevExp = NULL;
		char* methodplantExp = NULL;
		char* methodplantsplit = NULL;
		char* item_levelExp = NULL;
		char* ChildDescOneExp = NULL;
		int i1 = 0;
		int MM = 0;
		int fcount = 0;
		printf("\nvalue of split1 split2 split3 is in Pirntreplacestopatf [%s] [%s] [%s]\n",split1,split2,split3);fflush(stdout);
		if(strstr(split1,"#")!=NULL)
			{
				printf("\nhere split1 have value # in function Pirntreplacestopatf %s\n",split1);fflush(stdout);
				subchild_item_idtwoExp="---";
				subchild_item_idTwoRevExp="---";
				Childqty_foraddExp="---";
				methodplantExp="---";
				item_levelExp="---";
				ChildDescOneExp="---";
				printf("The value of subchild_item_idtwoExp == split1 temppartmatch==split2 item_levelExp == split3 %s==%s %s==%s %s==%s",subchild_item_idtwoExp,split1,temppartmatch,split2,item_levelExp,split3);fflush(stdout);
				printf("fp.7==> \n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,",subchild_item_idonemodaddnone,Child_item_idmodNameone,Caty,subchild_item_idone,subchild_item_idoneRev,Childqty_foraddone,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplantExp);fflush(stdout);
				//write2xml(Report,"<logo>\n");
				write2xml(Report,"<field key =\"Module_address\">");
				write2xml(Report,subchild_item_idonemodaddnone);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Module_Name\">");
				write2xml(Report,Child_item_idmodNameone);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Category\">");
				write2xml(Report,Caty);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Module NVC\">");
				write2xml(Report,subchild_item_idone);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Revision NVC\">");
				write2xml(Report,subchild_item_idoneRev);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Quantity NVC\">");
				write2xml(Report,Childqty_foraddone);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Child level NVC\">");
				write2xml(Report,item_levelExp);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Module's Child NVC\">");
				write2xml(Report,subchild_item_idtwoExp);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Child Revision NVC\">");
				write2xml(Report,subchild_item_idTwoRevExp);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
				write2xml(Report,ChildDescOneExp);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Child Quantity NVC\">");
				write2xml(Report,Childqty_foraddExp);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Car make BY NVC\">");
				write2xml(Report,methodplantExp);
				write2xml(Report,"</field>\n");
				//write2xml(Report,"</logo>\n");
				fprintf(fp,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,",subchild_item_idonemodaddnone,Child_item_idmodNameone,Caty,subchild_item_idone,subchild_item_idoneRev,Childqty_foraddone,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplantExp);fflush(fp);
			}
		else
			{
				ifail = AOM_ask_value_string(SubchildtagOne,"bl_item_item_id",&temppartmatch);
				printf("\nvalue of temppartmatch in Pirntreplacestopatf is %s\n",temppartmatch);fflush(stdout);
				ifail = BOM_line_ask_child_lines(SubchildtagOne,&subchildno_bom_linesOnechild,&subchild_bom_linesOnechild);
				printf("\nvalue of subchildno_bom_linesOnechild in Pirntreplacestopatf is %d\n",subchildno_bom_linesOnechild);fflush(stdout);
				for(MM=0;MM<subchildno_bom_linesOnechild;MM++)
					{
						subchild_item_idtwoExp=NULL;
						subchild_item_idTwoRevExp=NULL;
						Childqty_foraddExp=NULL;
						methodplantExp=NULL;
						methodplantsplit=NULL;
						item_levelExp=NULL;
						ChildDescOneExp=NULL;
						fcount=0;
						subchilditeamX=subchild_bom_linesOnechild[MM];
						ifail = AOM_ask_value_string(subchilditeamX,"bl_item_item_id",&subchild_item_idtwoExp);
						ifail = AOM_ask_value_string(subchilditeamX ,"bl_rev_item_revision_id",&subchild_item_idTwoRevExp);
						ifail = AOM_ask_value_string(subchilditeamX,"bl_quantity",&Childqty_foraddExp);
						ifail = AOM_UIF_ask_value(subchilditeamX,"bl_Design Revision_t5_CarMakeBuyIndicator",&methodplantExp);
						methodplantsplit = strtok(methodplantExp, " ");
						printf("\nvalue of methodplantsplit in replacement elemet function is %s\n",methodplantsplit);fflush(stdout);
						ifail = AOM_UIF_ask_value(subchilditeamX,"bl_level_starting_0",&item_levelExp);
						ifail = AOM_UIF_ask_value(subchilditeamX,"bl_item_object_desc",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,",","-",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,",","-",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,"\n","-",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,"&","and",&ChildDescOneExp);
						if((tc_strcmp(methodplantsplit,"F")==0) || (tc_strcmp(methodplantsplit,"F35")==0) || (tc_strcmp(methodplantsplit,"F40")==0) ||(tc_strcmp(methodplantsplit,"F18")==0) || (tc_strcmp(methodplantsplit,"F19")==0) || (tc_strcmp(methodplantsplit,"E99")==0))
							{
								fcount=1;
							}
						if ((tc_strcmp(subchild_item_idtwoExp,split1)==0) && (tc_strcmp(temppartmatch,split2)==0) && (tc_strcmp(item_levelExp,split3)==0))
							{
								printf("The value of subchild_item_idtwoExp == split1 temppartmatch==split2 item_levelExp == split3 %s==%s %s==%s %s==%s",subchild_item_idtwoExp,split1,temppartmatch,split2,item_levelExp,split3);fflush(stdout);
								printf("fp.8==> \n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,",subchild_item_idonemodaddnone,Child_item_idmodNameone,Caty,subchild_item_idone,subchild_item_idoneRev,Childqty_foraddone,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplantExp);fflush(stdout);
								//write2xml(Report,"<logo>\n");
								write2xml(Report,"<field key =\"Module_address\">");
								write2xml(Report,subchild_item_idonemodaddnone);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module_Name\">");
								write2xml(Report,Child_item_idmodNameone);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Category\">");
								write2xml(Report,Caty);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module NVC\">");
								write2xml(Report,subchild_item_idone);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Revision NVC\">");
								write2xml(Report,subchild_item_idoneRev);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Quantity NVC\">");
								write2xml(Report,Childqty_foraddone);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child level NVC\">");
								write2xml(Report,item_levelExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module's Child NVC\">");
								write2xml(Report,subchild_item_idtwoExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Revision NVC\">");
								write2xml(Report,subchild_item_idTwoRevExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
								write2xml(Report,ChildDescOneExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Quantity NVC\">");
								write2xml(Report,Childqty_foraddExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Car make BY NVC\">");
								write2xml(Report,methodplantExp);
								write2xml(Report,"</field>\n");
								//write2xml(Report,"</logo>\n");
								fprintf(fp,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,",subchild_item_idonemodaddnone,Child_item_idmodNameone,Caty,subchild_item_idone,subchild_item_idoneRev,Childqty_foraddone,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplantExp);fflush(fp);
								break;
							}
						if(fcount==0)
							{
								Pirntreplacestopatf(split1,split2,split3,subchilditeamX,subchild_item_idonemodaddnone,Child_item_idmodNameone,Caty,subchild_item_idone,subchild_item_idoneRev,Childqty_foraddone,fp);
							}

					}
			}
	 return 0;
}
int callingVCTforptint(char* tokenX3,tag_t Subchildtag,char* subchild_item_idtwo,char* subchild_item_idoneRev,char* Childqty_foraddone,FILE *fp)
	{
		printf("\nvalue of tokenX3 in function callingVCTforptint %s\n",tokenX3);fflush(stdout);
		char* split4 = NULL;
		char* split5 = NULL;
		char* split6 = NULL;
		if (tc_strstr(tokenX3,"#")!=NULL)
		{
			split4 = strtok(tokenX3,"*");
			split5 = strtok(NULL,"*");
			split6 = strtok(NULL,"*");
		}
		else
			{
			split4 = strtok(tokenX3,"*");
			split5 = strtok(NULL,"*");
			split6 = strtok(NULL,"*");
			}
		printf("\nvalue of split4 split5 split6 is [%s] [%s] [%s]\n",split4,split5,split6);fflush(stdout);
		Pirntreplacestopatftwo(split4,split5,split6,Subchildtag,subchild_item_idtwo,subchild_item_idoneRev,Childqty_foraddone,fp);

	}
int Pirntreplacestopatftwo(char* split4,char* split5,char* split6,tag_t Subchildtag,char* subchild_item_idref,char* subchild_item_idRefRev,char* Childqtyref_foraddone,FILE *fp)
{
		int ifail = ITK_ok;
		char* subchild_item_idOne = NULL;
		char* subchild_item_idOneRev = NULL;
		char* child_item_idmodadd = NULL;
		char* Child_item_idmodName = NULL;
		char* Childqty_foraddExp = NULL;
		tag_t subchilditeamX = NULLTAG;
		tag_t subchilditeamXtwo = NULLTAG;
		int subchildno_bom_linestwochild = 0;
		tag_t *subchild_bom_linestwochild = NULLTAG;
		tag_t subchilditeamEX = NULLTAG;
		char* subchild_item_idtwoExp = NULL;
		char* temppartmatchtwo = NULL;
		char* subchild_item_idTwoRevExp = NULL;
		char* methodplantExp = NULL;
		char* methodplantsplit = NULL;
		char* item_levelExp = NULL;
		char* ChildDescOneExp = NULL;
		int i1 = 0;
		int NN = 0;
		int MM = 0;
		int subchildno_bom_linesOnechild = 0;
		int fcount = 0;
		printf("\nvalue of split4 split5 split6 is in Pirntreplacestopatftwo [%s] [%s] [%s]\n",split4,split5,split6);fflush(stdout);
		if(strstr(split4,"#")!=NULL)
			{
				printf("\nhere split4 have value # in function Pirntreplacestopatf %s\n",split4);fflush(stdout);
				subchild_item_idtwoExp="---";
				subchild_item_idTwoRevExp="---";
				Childqty_foraddExp="---";
				methodplantExp="---";
				item_levelExp="---";
				ChildDescOneExp="---";
				printf("The value of subchild_item_idtwoExp == split4 temppartmatchtwo==split5 item_levelExp == split6 %s==%s %s==%s %s==%s",subchild_item_idtwoExp,split4,temppartmatchtwo,split5,item_levelExp,split6);fflush(stdout);
				printf("fp.8==> %s,%s,%s,%s,%s,%s,%s,%s,%s",subchild_item_idref,subchild_item_idRefRev,Childqtyref_foraddone,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplantExp);fflush(stdout);
				//write2xml(Report,"<logo>\n");
				write2xml(Report,"<field key =\"Module RVC\">");
				write2xml(Report,subchild_item_idref);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Revision RVC\">");
				write2xml(Report,subchild_item_idRefRev);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Quantity RVC\">");
				write2xml(Report,Childqtyref_foraddone);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Child level RVC\">");
				write2xml(Report,item_levelExp);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Module's Child RVC\">");
				write2xml(Report,subchild_item_idtwoExp);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Child Revision RVC\">");
				write2xml(Report,subchild_item_idTwoRevExp);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
				write2xml(Report,ChildDescOneExp);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Child Quantity RVC\">");
				write2xml(Report,Childqty_foraddExp);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Car make BY RVC\">");
				write2xml(Report,methodplantExp);
				write2xml(Report,"</field>\n");
				//write2xml(Report,"</logo>\n");
				fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s",subchild_item_idref,subchild_item_idRefRev,Childqtyref_foraddone,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplantExp);fflush(fp);
			}
		else
			{
				ifail = AOM_ask_value_string(Subchildtag,"bl_item_item_id",&temppartmatchtwo);
				printf("\nvalue of temppartmatchtwo in Pirntreplacestopatf is %s\n",temppartmatchtwo);fflush(stdout);
				ifail = BOM_line_ask_child_lines(Subchildtag,&subchildno_bom_linestwochild,&subchild_bom_linestwochild);
				for(NN=0;NN<subchildno_bom_linestwochild;NN++)
					{
						subchild_item_idtwoExp=NULL;
						subchild_item_idTwoRevExp=NULL;
						Childqty_foraddExp=NULL;
						methodplantExp=NULL;
						methodplantsplit=NULL;
						item_levelExp=NULL;
						ChildDescOneExp=NULL;
						fcount=0;
						subchilditeamXtwo=subchild_bom_linestwochild[NN];
						ifail = AOM_ask_value_string(subchilditeamXtwo,"bl_item_item_id",&subchild_item_idtwoExp);
						ifail = AOM_ask_value_string(subchilditeamXtwo ,"bl_rev_item_revision_id",&subchild_item_idTwoRevExp);
						ifail = AOM_ask_value_string(subchilditeamXtwo,"bl_quantity",&Childqty_foraddExp);
						ifail = AOM_UIF_ask_value(subchilditeamXtwo,"bl_Design Revision_t5_CarMakeBuyIndicator",&methodplantExp);
						methodplantsplit = strtok(methodplantExp, " ");
						printf("\nvalue of methodplantsplit in replacement elemet function is %s\n",methodplantsplit);fflush(stdout);
						ifail = AOM_UIF_ask_value(subchilditeamXtwo,"bl_level_starting_0",&item_levelExp);
						ifail = AOM_UIF_ask_value(subchilditeamXtwo,"bl_item_object_desc",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,",","-",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,",","-",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,"\n","-",&ChildDescOneExp);
						STRNG_replace_str(ChildDescOneExp,"&","and",&ChildDescOneExp);
						if((tc_strcmp(methodplantsplit,"F")==0) || (tc_strcmp(methodplantsplit,"F35")==0) || (tc_strcmp(methodplantsplit,"F40")==0) ||(tc_strcmp(methodplantsplit,"F18")==0) || (tc_strcmp(methodplantsplit,"F19")==0) || (tc_strcmp(methodplantsplit,"E99")==0))
							{
								fcount=1;
							}
						if ((tc_strcmp(subchild_item_idtwoExp,split4)==0) && (tc_strcmp(temppartmatchtwo,split5)==0) && (tc_strcmp(item_levelExp,split6)==0))
							{
								printf("The value of subchild_item_idtwoExp == split4 temppartmatchtwo==split5 item_levelExp == split6 %s==%s %s==%s %s==%s",subchild_item_idtwoExp,split4,temppartmatchtwo,split5,item_levelExp,split6);fflush(stdout);
								printf("fp.9==> %s,%s,%s,%s,%s,%s,%s,%s,%s",subchild_item_idref,subchild_item_idRefRev,Childqtyref_foraddone,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplantExp);fflush(stdout);
								//write2xml(Report,"<logo>\n");
								write2xml(Report,"<field key =\"Module RVC\">");
								write2xml(Report,subchild_item_idref);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Revision RVC\">");
								write2xml(Report,subchild_item_idRefRev);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Quantity RVC\">");
								write2xml(Report,Childqtyref_foraddone);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child level RVC\">");
								write2xml(Report,item_levelExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Module's Child RVC\">");
								write2xml(Report,subchild_item_idtwoExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Revision RVC\">");
								write2xml(Report,subchild_item_idTwoRevExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
								write2xml(Report,ChildDescOneExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Child Quantity RVC\">");
								write2xml(Report,Childqty_foraddExp);
								write2xml(Report,"</field>\n");
								write2xml(Report,"<field key =\"Car make BY RVC\">");
								write2xml(Report,methodplantExp);
								write2xml(Report,"</field>\n");
								//write2xml(Report,"</logo>\n");
								fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s",subchild_item_idref,subchild_item_idRefRev,Childqtyref_foraddone,item_levelExp,subchild_item_idtwoExp,subchild_item_idTwoRevExp,ChildDescOneExp,Childqty_foraddExp,methodplantExp);fflush(fp);
								break;
							}
						if(fcount==0)
							{
								Pirntreplacestopatftwo(split4,split5,split6,subchilditeamXtwo,subchild_item_idref,subchild_item_idRefRev,Childqtyref_foraddone,fp);
							}

					}
			}
	 return 0;
}
/*********Rev change function *******/
int RevChange(tag_t Child_bom_linestwo,tag_t Child_bom_linesone,FILE *fp)
{
	int ifail = ITK_ok;
	int i1;
	int i2;
	int Rev=0;
	int level0=0;
	int CSFoundFlag=0;
	int F18CSFoundFlag=0;
	int m1=0;
	char *SrNOP = NULL;
	int subchildno_bom_linesx;
	int subchildno_bom_linesonex;
	tag_t subchilditeam = NULLTAG;
	tag_t subchilditeamone = NULLTAG;
	char *subchild_item_idtwo = NULL;
	char *subchild_item_idone = NULL;
	//char *subchild_bom_linesonex = NULL;
	char *subchild_item_idquantity = NULL;
	char *subchild_item_idmodadd = NULL;
	char *subchild_item_idmodName = NULL;
	char *subchild_item_idTwoRev = NULL;
	char *subchild_item_idOneRev = NULL;
	char *subchild_item_idquantityref = NULL;
	char *subchild_item_idquantityNew = NULL;
	char *methodplant = NULL;
	char *tokenX2 = NULL;
	char *catry = NULL;
	char *subchild_item_idonemodaddnoneRev = NULL;
	tag_t *subchild_bom_linesx = NULLTAG;
	tag_t *subchild_bom_linesonex = NULLTAG;
	//fprintf(fp,"\n");
	//depthExpandVC2++;

	printf("\n Rev change--please wait Second part is running\n");fflush(stdout);
	ifail = BOM_line_ask_child_lines(Child_bom_linestwo, &subchildno_bom_linesx, &subchild_bom_linesx);
	printf("\n Rev change--Size of ref VC BOM is %d \n",subchildno_bom_linesx);fflush(stdout);

	if(subchildno_bom_linesx>0)
	{
		for (i1=0; i1<subchildno_bom_linesx; i1++)
		{
			subchild_item_idtwo=NULL;
			subchild_item_idTwoRev=NULL;
			subchild_item_idonemodaddnoneRev=NULL;
			subchilditeam=NULLTAG;
			Rev=0;

			subchilditeam=subchild_bom_linesx[i1];

			ifail = AOM_ask_value_string(subchilditeam,"bl_item_item_id",&subchild_item_idtwo);
			ifail = AOM_ask_value_string(subchilditeam,"bl_Design Revision_t5_ModuleAddress",&subchild_item_idonemodaddnoneRev);
			ifail = AOM_ask_value_string(subchilditeam ,"bl_rev_item_revision_id",&subchild_item_idTwoRev);
			ifail = AOM_ask_value_string(subchilditeam,"bl_quantity",&subchild_item_idquantityref);
			//printf("\nsubchild of VCT %s\n",subchild_item_idtwo);fflush(stdout);
			printf("\n Rev change--subchild part of ref vc [%s] [%s] \n",subchild_item_idtwo,subchild_item_idTwoRev);fflush(stdout);

			ifail = BOM_line_ask_child_lines(Child_bom_linesone,&subchildno_bom_linesonex,&subchild_bom_linesonex);
			printf("\n Rev change--Size of New VC BOM is %d \n",subchildno_bom_linesonex);fflush(stdout);

			if(subchildno_bom_linesonex>0)
			{
				for (i2=0;i2<subchildno_bom_linesonex; i2++)
				{
					catry = "Rev change";
					subchild_item_idone = NULL;
					subchild_item_idOneRev=NULL;
					subchild_item_idmodadd=NULL;
					subchilditeamone=NULLTAG;

					subchilditeamone=subchild_bom_linesonex[i2];

					ifail = AOM_ask_value_string(subchilditeamone,"bl_item_item_id",&subchild_item_idone);
					ifail = AOM_ask_value_string(subchilditeamone,"bl_rev_item_revision_id",&subchild_item_idOneRev);
					ifail = AOM_ask_value_string(subchilditeamone,"bl_Design Revision_t5_ModuleAddress",&subchild_item_idmodadd);

					printf("\n Rev change--subchild part of New VC [%s] [%s] \n",subchild_item_idone,subchild_item_idOneRev);fflush(stdout);

					ifail = AOM_ask_value_string(subchilditeamone,"bl_quantity",&subchild_item_idquantityNew);

					if((tc_strcmp(subchild_item_idtwo,subchild_item_idone)==0) && (tc_strcmp(subchild_item_idTwoRev,subchild_item_idOneRev)!=0))
					{
						SrNOP=NULL;
						//SerialNocommon=SerialNocommon+1;
						SerialNo=SerialNo+1;
						char* SrNOP = intToString(SerialNo);
						printf("\n Rev change--Both parts are eqaul in this condition\n");fflush(stdout);
						printf("\n Rev change--subchild part of New VC [%s] [%s] [%s] [%s] \n",subchild_item_idmodadd,subchild_item_idonemodaddnoneRev,subchild_item_idTwoRev,subchild_item_idOneRev);fflush(stdout);
						ifail = AOM_ask_value_string(subchilditeamone,"bl_quantity",&subchild_item_idquantity);
						ifail = AOM_ask_value_string(subchilditeamone,"bl_Design Revision_t5_ModuleName",&subchild_item_idmodName);
						STRNG_replace_str(subchild_item_idmodName,",","-",&subchild_item_idmodName);
						STRNG_replace_str(subchild_item_idmodName,"\n","-",&subchild_item_idmodName);
						STRNG_replace_str(subchild_item_idmodName,"&","and",&subchild_item_idmodName);

						printf("\n subchild_item_idmodadd: [%s] ",subchild_item_idmodadd); fflush(stdout);

						write2xml(Report,"<logo>\n");
						if (SrNOP != NULL)
							{
								printf("Converted string: %s\n", SrNOP);
								write2xml(Report,"<field key =\"Serial_No\">");
								write2xml(Report,SrNOP);
								write2xml(Report,"</field>\n");
							}
						write2xml(Report,"<field key =\"Module_address\">");
						write2xml(Report,subchild_item_idmodadd);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module_Name\">");
						write2xml(Report,subchild_item_idmodName);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Category\">");
						write2xml(Report,catry);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module NVC\">");
						write2xml(Report,subchild_item_idone);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Revision NVC\">");
						write2xml(Report,subchild_item_idOneRev);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Quantity NVC\">");
						write2xml(Report,subchild_item_idquantityNew);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child level NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module's Child NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Revision NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Quantity NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Car make BY NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module RVC\">");
						write2xml(Report,subchild_item_idtwo);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Revision RVC\">");
						write2xml(Report,subchild_item_idTwoRev);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Quantity RVC\">");
						write2xml(Report,subchild_item_idquantityref);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child level RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module's Child RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Revision RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Quantity RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Car make BY RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"</logo>\n");

						printf("\n Common--fp.0==> %s,%s,%s,%s,%s,%s,,,,,,,%s,%s,%s,,,,,,,",subchild_item_idmodadd,subchild_item_idmodName,catry,subchild_item_idone,subchild_item_idOneRev,subchild_item_idquantity,subchild_item_idone,subchild_item_idOneRev,subchild_item_idquantity,"","","","","","");fflush(stdout);

						fprintf(fp,"%s,%s,%s,%s,%s,%s,,,,,,,%s,%s,%s,,,,,,,\n",subchild_item_idmodadd,subchild_item_idmodName,catry,subchild_item_idone,subchild_item_idOneRev,subchild_item_idquantity,subchild_item_idtwo,subchild_item_idTwoRev,subchild_item_idquantityref,"","","","","","");fflush(fp);
						free(SrNOP); // Free the dynamically allocated memory
						break;
					}
				}
			}
		}
	}
	return 0;
}

/*********Qty change function *************/

int QtyChange(tag_t Child_bom_linestwo,tag_t Child_bom_linesone,FILE *fp)
{
	int ifail = ITK_ok;
	int i1;
	int i2;
	int Rev=0;
	int level0=0;
	int CSFoundFlag=0;
	int F18CSFoundFlag=0;
	int m1=0;
	int subchildno_bom_linesx;
	int subchildno_bom_linesonex;
	tag_t subchilditeam = NULLTAG;
	tag_t subchilditeamone = NULLTAG;
	char *subchild_item_idtwo = NULL;
	char *subchild_item_idone = NULL;
	char *SrNOP = NULL;
	//char *subchild_bom_linesonex = NULL;
	char *subchild_item_idquantity = NULL;
	char *subchild_item_idmodadd = NULL;
	char *subchild_item_idmodName = NULL;
	char *subchild_item_idTwoRev = NULL;
	char *subchild_item_idOneRev = NULL;
	char *subchild_item_idquantityref = NULL;
	char *subchild_item_idquantityNew = NULL;
	char *methodplant = NULL;
	char *tokenX2 = NULL;
	char *catry = NULL;
	char *subchild_item_idonemodaddnoneRev = NULL;
	tag_t *subchild_bom_linesx = NULLTAG;
	tag_t *subchild_bom_linesonex = NULLTAG;
	//fprintf(fp,"\n");
	//depthExpandVC2++;

	printf("\n Qty change--please wait Second part is running\n");fflush(stdout);
	ifail = BOM_line_ask_child_lines(Child_bom_linestwo, &subchildno_bom_linesx, &subchild_bom_linesx);
	printf("\n Qty change--Size of ref VC BOM is %d \n",subchildno_bom_linesx);fflush(stdout);

	if(subchildno_bom_linesx>0)
	{
		for (i1=0; i1<subchildno_bom_linesx; i1++)
		{
			subchild_item_idtwo=NULL;
			subchild_item_idTwoRev=NULL;
			subchild_item_idonemodaddnoneRev=NULL;
			subchilditeam=NULLTAG;
			Rev=0;

			subchilditeam=subchild_bom_linesx[i1];

			ifail = AOM_ask_value_string(subchilditeam,"bl_item_item_id",&subchild_item_idtwo);
			ifail = AOM_ask_value_string(subchilditeam,"bl_Design Revision_t5_ModuleAddress",&subchild_item_idonemodaddnoneRev);
			ifail = AOM_ask_value_string(subchilditeam ,"bl_rev_item_revision_id",&subchild_item_idTwoRev);
			ifail = AOM_ask_value_string(subchilditeam,"bl_quantity",&subchild_item_idquantityref);
			//printf("\nsubchild of VCT %s\n",subchild_item_idtwo);fflush(stdout);
			printf("\n Qty change--subchild part of ref vc [%s] [%s] \n",subchild_item_idtwo,subchild_item_idTwoRev);fflush(stdout);

			ifail = BOM_line_ask_child_lines(Child_bom_linesone,&subchildno_bom_linesonex,&subchild_bom_linesonex);
			printf("\n Qty change--Size of New VC BOM is %d \n",subchildno_bom_linesonex);fflush(stdout);

			if(subchildno_bom_linesonex>0)
			{
				for (i2=0;i2<subchildno_bom_linesonex; i2++)
				{
					catry = "Qty change";
					subchild_item_idone = NULL;
					subchild_item_idOneRev=NULL;
					subchild_item_idmodadd=NULL;
					subchilditeamone=NULLTAG;

					subchilditeamone=subchild_bom_linesonex[i2];

					ifail = AOM_ask_value_string(subchilditeamone,"bl_item_item_id",&subchild_item_idone);
					ifail = AOM_ask_value_string(subchilditeamone,"bl_rev_item_revision_id",&subchild_item_idOneRev);
					ifail = AOM_ask_value_string(subchilditeamone,"bl_Design Revision_t5_ModuleAddress",&subchild_item_idmodadd);

					printf("\n Qty change--subchild part of New VC [%s] [%s] \n",subchild_item_idone,subchild_item_idOneRev);fflush(stdout);

					ifail = AOM_ask_value_string(subchilditeamone,"bl_quantity",&subchild_item_idquantityNew);

					if((tc_strcmp(subchild_item_idmodadd,subchild_item_idonemodaddnoneRev)==0) && (tc_strcmp(subchild_item_idTwoRev,subchild_item_idOneRev)==0) && (tc_strcmp(subchild_item_idquantityNew,subchild_item_idquantityref)!=0))
					{
						SrNOP=NULL;
						//SerialNocommon=SerialNocommon+1;
						SerialNo=SerialNo+1;
						char* SrNOP = intToString(SerialNo);
						printf("\n Qty change--Both parts are eqaul in this condition\n");fflush(stdout);
						printf("\n Qty change--subchild part of New VC [%s] [%s] [%s] [%s] [%s] [%s] \n",subchild_item_idmodadd,subchild_item_idonemodaddnoneRev,subchild_item_idTwoRev,subchild_item_idOneRev,subchild_item_idquantityNew,subchild_item_idquantityref);fflush(stdout);
						ifail = AOM_ask_value_string(subchilditeamone,"bl_quantity",&subchild_item_idquantity);
						ifail = AOM_ask_value_string(subchilditeamone,"bl_Design Revision_t5_ModuleName",&subchild_item_idmodName);
						STRNG_replace_str(subchild_item_idmodName,",","-",&subchild_item_idmodName);
						STRNG_replace_str(subchild_item_idmodName,"\n","-",&subchild_item_idmodName);
						STRNG_replace_str(subchild_item_idmodName,"&","and",&subchild_item_idmodName);

						printf("\n subchild_item_idmodadd: [%s] ",subchild_item_idmodadd); fflush(stdout);

						write2xml(Report,"<logo>\n");
						if (SrNOP != NULL)
							{
								printf("Converted string: %s\n", SrNOP);
								write2xml(Report,"<field key =\"Serial_No\">");
								write2xml(Report,SrNOP);
								write2xml(Report,"</field>\n");
							}
						write2xml(Report,"<field key =\"Module_address\">");
						write2xml(Report,subchild_item_idmodadd);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module_Name\">");
						write2xml(Report,subchild_item_idmodName);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Category\">");
						write2xml(Report,catry);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module NVC\">");
						write2xml(Report,subchild_item_idone);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Revision NVC\">");
						write2xml(Report,subchild_item_idOneRev);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Quantity NVC\">");
						write2xml(Report,subchild_item_idquantityNew);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child level NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module's Child NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Revision NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Part_Desc NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Quantity NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Car make BY NVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module RVC\">");
						write2xml(Report,subchild_item_idtwo);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Revision RVC\">");
						write2xml(Report,subchild_item_idTwoRev);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Quantity RVC\">");
						write2xml(Report,subchild_item_idquantityref);
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child level RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Module's Child RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Revision RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Part_Desc RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Child Quantity RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"<field key =\"Car make BY RVC\">");
						write2xml(Report," ");
						write2xml(Report,"</field>\n");
						write2xml(Report,"</logo>\n");

						printf("\n Qty--fp.0==> %s,%s,%s,%s,%s,%s,,,,,,,%s,%s,%s,,,,,,,",subchild_item_idmodadd,subchild_item_idmodName,catry,subchild_item_idone,subchild_item_idOneRev,subchild_item_idquantity,subchild_item_idone,subchild_item_idOneRev,subchild_item_idquantity,"","","","","","");fflush(stdout);

						fprintf(fp,"%s,%s,%s,%s,%s,%s,,,,,,,%s,%s,%s,,,,,,,\n",subchild_item_idmodadd,subchild_item_idmodName,catry,subchild_item_idone,subchild_item_idOneRev,subchild_item_idquantity,subchild_item_idtwo,subchild_item_idTwoRev,subchild_item_idquantityref,"","","","","","");fflush(fp);
						free(SrNOP);
						break;
					}
				}
			}
		}
	}
	return 0;
}

/************main function*******************/
int ITK_user_main (int argc, char ** argv )
{
	//FILE *fp;
	//FILE *fp1;
	int ifail = ITK_ok;
	int	n_rev_entries = 2;
	int	n_rev_entriestwo = 2;
	int status = 0;
	int n_tags_found1 = 0;
	int n_tags_found2 = 0;
	int Count = 0;
	int ij = 0;
	int ik = 0;
	int It = 0;
	int Itt = 0;
	int pCnt = 0;
	int pCnt1 = 0;
	int rev_cnt = 0;
	int rev_cnttwo = 0;
	int n_attchsNON1 = 0;
	int n_attchsNON2 = 0;
	int RCnt = 0;
	int revCnt = 0;
	int PartCnt = 0;
	int PartCnt1 = 0;
	int num_to_sort = 1;
	int one_entry = 1;
	int QryOPCount = 0;
	int sort_order[1]  ={2};
	int no_bom_linesO=0;
	int no_bom_linesT=0;
	//int tt = 0;
	int m =0;
	int m1 =0;
	int m2 =0;
	int b =0;
	int rulefound = 0;
	int rulefoundtwo = 0;
	int transfermode1Cnt = 0;
	int depthExpandVC1 = 0;
	int depthExpandVC2 = 0;
	int depthforfind1 = 0;
	int depthforfind2 = 0;
	int depthforfind3 = 0;
	int depthforprint1 = 0;
	int depthforprint2 = 0;
	int depthforprint3 = 0;
	int rulefoundqty = 0;
	int ctr = 0;
	//int ifail;
	char *qry_entries[2] = {"Item ID","Revision"};
	char *qry_entriesTwo[2] = {"Item ID","Revision"};
	//char *qry_entries[1] = {"ID"};
	char *sUserName		=   NULL;
	char *sPassword		=   NULL;
	char *sgrp		=   NULL;
	char *IteamNumberone		=	NULL;
	char *IteamNumberTwo		=	NULL;
	char *PartNumC	=	NULL;
	char *PartNumCDup	=	NULL;
	char *DmlprojectcodeDup	=	NULL;
	char *RelStat		=	NULL;
	char *RelStatDup		=	NULL;
	char *RevSeq		=	NULL;
	char *partClrInd		=	NULL;
	char *partClrIndDup		=	NULL;
	char **valuesone             = NULL;
	char **valuesTwo             = NULL;
	char **rulename				 = NULL;
	char **rulevalue			 = NULL;
	char *itemid	    =   NULL;
	char *itemidDup	    =   NULL;
	char	*PrtNoone			= NULL;
	char	*PrtNoTwo			= NULL;
	//char *ReferStd_cnt	    =   NULL;
	char *Fromdate	    =   NULL;
	char *Todate	    =   NULL;
	char* CLName;
	char lineRead[500];
	char* CLNum = NULL;
	char* CLNump = NULL;
	char* PartName = NULL;
	char    *Assym1			= NULL;
	char    *Rev1			= NULL;
	char    *Seq1			= NULL;
	char    *Assym2			= NULL;
	char    *Rev2			= NULL;
	char    *Seq2			= NULL;
	char	*PrtNooneRevId		= NULL;
	char	*PrtNoTwoRevId		= NULL;
	char	*PrtNoOneSeqId		= NULL;
	char	*PrtNoTwoSeqId		= NULL;
	char* Dmlprojectcode = NULL;
	char* NonColorPar1 = NULL;
	char* NonColorPar2 = NULL;
	char* PartName1 = NULL;
	char* NonColorPart = NULL;
	char* objtype = NULL;
	char* objtypep = NULL;
	char* objtyperev = NULL;
	//char* ChPartTags = NULL;
	char* CLNumDup = NULL;
	char* CLNumpDup = NULL;
	char* DMLStr = NULL;
	char* PartNameDup = NULL;
	char* PartNameDup1 = NULL;
	char* NonColorPartDup1 = NULL;
	char* NonColorPartDup2 = NULL;
	char* objtypeDup = NULL;
	char* objtypepDup = NULL;
	char* objtyperevDup = NULL;
	char *keysAttr[1]		    =  {"creation_date"};
	//char *RevisionRule	    = NULL;
	char *RRForNewVC	    = NULL;
	char *RRForRefVC	    = NULL;
	//char *ClosureView	    = NULL;
	//char *ClosureVForNewVC	    = NULL;
	char *ClosureViewNewVC	    = NULL;
	//char *ClosureVForRefVC	    = NULL;
	char *ClosureViewRefVC	    = NULL;
	char *Date	    = NULL;
	char *WithoutZeroQty	    = NULL;
	char *Plant	    = NULL;
	char* DmlRelType	= NULL;
	char* PrtNooneDup1 = NULL;
	char* IteamNumberoneDup = NULL;
	char* IteamNumberTwoDup = NULL;
	char* PrtNoTwoDup2 = NULL;
	char* PrtNoTwoRevIdDup2 = NULL;
	char* PrtNoTwoSeqIdDup2 = NULL;
	char* RevSeqCat1 = NULL;
	char* RevSeqCat2 = NULL;
	char *expansionLvl = NULL;
	char *Without_underscore = NULL;
	char *Stop_AT_F = NULL;
	char *tokenX = NULL;
	char *tokenX2 = NULL;
	char *tokenX3 = NULL;
	char *IteamNumberonecompare = NULL;
	char *ChildRevSeqTwo = NULL;
	char *ChildDescTwo = NULL;
	//char			fpFile[200]				= "";
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesTwo = (char **) MEM_alloc(10 * sizeof(char *));
	childPart = (char**)MEM_alloc( 1000 * sizeof *childPart );
	childParttwo = (char**)MEM_alloc( 1000 * sizeof *childParttwo );
	childPartthree = (char**)MEM_alloc( 1000 * sizeof *childPartthree );
	childPartFour = (char**)MEM_alloc( 1000 * sizeof *childPartFour );
	childPartFive = (char**)MEM_alloc( 1000 * sizeof *childPartFive );
	childPartSix = (char**)MEM_alloc( 1000 * sizeof *childPartSix );
	childPartRep1 = (char**)MEM_alloc( 1000 * sizeof *childPartRep1 );
	childPartRep2 = (char**)MEM_alloc( 1000 * sizeof *childPartRep2 );
	tag_t   Query_Tag    = NULLTAG;
	tag_t	PartTag		      = NULLTAG;
	tag_t	PartTagC		      = NULLTAG;
    tag_t *items              = NULL;
    tag_t *ColPartTags              = NULL;
	tag_t   CL_TASK_Query    = NULLTAG;
	tag_t	CLTag		      = NULLTAG;
	tag_t	tRelationFindOne	  = NULLTAG;
	tag_t	tRelationFindTwo	  = NULLTAG;
	tag_t		AssemoneQuery			= NULLTAG;
	tag_t		AssemTwoQuery			= NULLTAG;
	tag_t		CLprintTag			= NULLTAG;
	tag_t		PartTag1			= NULLTAG;
	tag_t		PartTag2			= NULLTAG;
	tag_t		PartTag3			= NULLTAG;
	tag_t		PartTag4			= NULLTAG;
	tag_t		PartTag5			= NULLTAG;
	tag_t		ERCDMLTag			= NULLTAG;
	tag_t		ERCDMLQry			= NULLTAG;
	tag_t		*ChPartTags			= NULLTAG;
	tag_t		*allRevTag			= NULLTAG;
	tag_t		*ChPartTags1			= NULLTAG;
	tag_t		*secondary_objects1			= NULLTAG;
	tag_t		*secondary_objects2		= NULLTAG;
	tag_t		*ERCDMLTags				= NULLTAG;
	tag_t		*rev_list_set		= NULLTAG;
	tag_t		*rev_list_settwo		= NULLTAG;
	tag_t		 Obj_tagone				= NULLTAG;
	tag_t		 Obj_tagtwo				=	NULLTAG;
	tag_t		 Rev_tone				= NULLTAG;
	tag_t		 Rev_tTwo				= NULLTAG;
	tag_t		*t_allrevdocs              = NULL;
	tag_t		*t_allrevdocsTwo              = NULL;
	tag_t		*child_bom_linesOne		= NULLTAG;
	tag_t		*child_bom_linesTwo		= NULLTAG;
	tag_t		*closurerule			= NULL;
	tag_t		*closureruletwo			= NULL;
	tag_t		*transfermodes1			= NULLTAG;
	tag_t		*Partclosurerule			= NULLTAG;
	tag_t		IteamprintTag			= NULLTAG;
	tag_t		Bomlinetagone			= NULLTAG;
	tag_t		windowVCO				= NULLTAG;
	tag_t		windowVCT				= NULLTAG;
	tag_t		ruleone					= NULLTAG;
	tag_t		ruleTwo					= NULLTAG;
	tag_t		top_lineVCO				= NULLTAG;
	tag_t		top_lineVCT				= NULLTAG;
	tag_t		IteamprintTagTwo		= NULLTAG;
	tag_t		Bomlinetagonex		= NULLTAG;
	tag_t		Partclose_tag		= NULLTAG;
	tag_t		close_tag;
	tag_t		close_tagtwo;
	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	char **Partrulenamee = NULL;
	char **Partrulevaluee = NULL;


	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	
	//sUserName = ITK_ask_cli_argument("-u=");
	//sPassword = ITK_ask_cli_argument("-pf=");
	//sgrp = ITK_ask_cli_argument("-g=");
	Assym1 = ITK_ask_cli_argument("-New_VC=");
	Rev1 = ITK_ask_cli_argument("-Revision1=");
	Seq1 = ITK_ask_cli_argument("-Sequence1=");
	RRForNewVC = ITK_ask_cli_argument("-RevisionRuleNewVC=");
	ClosureViewNewVC = ITK_ask_cli_argument("-ClosureVForNewVC=");
	Assym2 = ITK_ask_cli_argument("-Ref_VC=");
	Rev2 = ITK_ask_cli_argument("-Revision2=");
	Seq2 = ITK_ask_cli_argument("-Sequence2=");
	//ViewS = ITK_ask_cli_argument("-ViewS=");
	RRForRefVC = ITK_ask_cli_argument("-RevisionRuleRefVC=");
	ClosureViewRefVC = ITK_ask_cli_argument("-ClosureVForRefVC=");
	Plant = ITK_ask_cli_argument("-Plant=");
	WithoutZeroQty = ITK_ask_cli_argument("-WithoutZeroQty=");
	expansionLvl = ITK_ask_cli_argument("-level=");
	Without_underscore = ITK_ask_cli_argument("-Without_underscore=");
	Stop_AT_F = ITK_ask_cli_argument("-Stop_AT_F=");
	
	if (expansionLvl)
	{
		expansionLevel=atoi(expansionLvl);
	}

	Report=fopen("/tmp/ADD_Delete_Modification_latest.xml","a+");
	//Report=fopen("/plmpv16/reports/ADD_Delete_Modification_latest.xml","a+");
	if (Report == NULL)
	{
		printf("ERROR: XML Cannot open File\n");
		return -1;
	}
	else
	{
		printf("XML File opened successfully.\n");
	}
	write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	write2xml(Report,"\n<Top>\n");

	write2xml(Report,"\n<New_VC>");
	write2xml(Report,Assym1);
	write2xml(Report,"</New_VC>");

	write2xml(Report,"\n<Revision1>");
	write2xml(Report,Rev1);
	write2xml(Report,"</Revision1>");

	write2xml(Report,"\n<Sequence1>");
	write2xml(Report,Seq1);
	write2xml(Report,"</Sequence1>");

	write2xml(Report,"\n<RevisionRuleNewVC>");
	write2xml(Report,RRForNewVC);
	write2xml(Report,"</RevisionRuleNewVC>");

	write2xml(Report,"\n<ClosureVForNewVC>");
	write2xml(Report,ClosureViewNewVC);
	write2xml(Report,"</ClosureVForNewVC>");

	write2xml(Report,"\n<Ref_VC>");
	write2xml(Report,Assym2);
	write2xml(Report,"</Ref_VC>");

	write2xml(Report,"\n<Revision2>");
	write2xml(Report,Rev2);
	write2xml(Report,"</Revision2>");

	write2xml(Report,"\n<Sequence2>");
	write2xml(Report,Seq2);
	write2xml(Report,"</Sequence2>");

	write2xml(Report,"\n<RevisionRuleRefVC>");
	write2xml(Report,RRForRefVC);
	write2xml(Report,"</RevisionRuleRefVC>");

	write2xml(Report,"\n<ClosureVForRefVC>");
	write2xml(Report,ClosureViewRefVC);
	write2xml(Report,"</ClosureVForRefVC>");

	printf("Date: %d-%d-%d\n", tm.tm_year + 1900, tm.tm_mon + 1,tm.tm_mday); fflush(stdout);
	write2xml(Report,"\n<Date>");
	fprintf(Report,"%d-%d-%d",tm.tm_mday, tm.tm_mon + 1,  tm.tm_year + 1900); fflush(Report);
	write2xml(Report,"</Date>\n");

//	printf("Date: %d-%d-%d\n", tm.tm_year + 1900, tm.tm_mon + 1,tm.tm_mday);
//	write2xml(Report,"\n<Date>");
//	fprintf(Report,"%d-%d-%d",tm.tm_mday, tm.tm_mon + 1,  tm.tm_year + 1900);
//	write2xml(Report,"</Date>\n");

	//status=ITK_init_module(sUserName, sPassword, sgrp);
	//if (status == 0)
	//{
		printf("Login succesfully");

		//fp = fopen("/tmp/ADD_Delete_Modification.csv","w");
		fp = fopen("/plmpv16/reports/ADD_Delete_Modification.csv","w");
		//fp = fopen("/tmp/ADD_Delete_Modification2.csv","w");
		if (fp == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
			printf("File opened successfully.\n");
		}
		//fp1 = fopen("/tmp/check2.txt","w");
		//fprintf(fp,"\n\tComparision of given assembly\n\t");
		//fprintf(fp,"\n\t==============================================================================\n\t");
		//fprintf(fp,"\n\t View :%s\n\t",mode);
		valuesone = (char **) MEM_alloc(n_rev_entries * sizeof(char *));
		valuesone[0] = (char *)MEM_alloc( strlen( Assym1 ) + 1);

		tc_strcpy(valuesone[0], Assym1);
		
		RevSeqCat1 = (char *)MEM_alloc(50);
		tc_strcpy(RevSeqCat1, Rev1);
		tc_strcat(RevSeqCat1, "*");
		tc_strcat(RevSeqCat1, Seq1);
		valuesone[1] = (char *)MEM_alloc( strlen( RevSeqCat1 ) + 1);
		tc_strcpy(valuesone[1], RevSeqCat1);
		printf("\nthe Revision sequence of the part 1 is %s\n",RevSeqCat1);
		
		RevSeqCat2 = (char *)MEM_alloc(50);
		tc_strcpy(RevSeqCat2, Rev2);
		tc_strcat(RevSeqCat2, "*");
		tc_strcat(RevSeqCat2, Seq2);

		printf("\nthe Revision sequence of the part 2 is %s\n",RevSeqCat2);

		QRY_find2("Item Revision...", &AssemoneQuery);
		printf("\nafter Iteam revision\n");fflush(stdout);
		ifail = BOM_create_window(&windowVCO);
		ifail = BOM_create_window(&windowVCT);

        ifail = CFM_find(RRForNewVC, &ruleone);
        ifail = CFM_find(RRForRefVC, &ruleTwo);

		 //For withoutzeroquantity
		 if (tc_strcmp(WithoutZeroQty,"Yes")==0)
		{
			printf("\n Without ZeroQty \n"); fflush(stdout);
			ifail = PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &rulefoundqty,&Partclosurerule);
			//TC_write_syslog("\n\n\n\n\n INside regular GenTPL........  \n\n\n\n\n");
		}
		else
		{
			printf("\n with Zero quantity\n"); fflush(stdout);
		}

		if (rulefoundqty > 0)
		{
			Partclose_tag = Partclosurerule[0];
			//printf ("P129:closure rule found \n");fflush(stdout);
		}

		// Below code is for closure rule for New VC
		if (tc_strcmp(ClosureViewNewVC,"ERC")==0)
		{
			printf("inside ERC closure rule..\n");fflush(stdout);
			ifail = PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER,&rulefound,&closurerule);
		}
		else if (tc_strcmp(ClosureViewNewVC,"APLC")==0)
		{
			printf("inside APLC closure rule..\n");fflush(stdout);
			ifail = PIE_find_closure_rules2("BOMViewClosureRuleAPLC",PIE_TEAMCENTER,&rulefound,&closurerule);
		}
		else if (tc_strcmp(ClosureViewNewVC,"STDSI")==0)
		{
			printf("inside STDSI closure rule..\n");fflush(stdout);
			ifail = PIE_find_closure_rules2("BOMViewClosureRuleSTDC",PIE_TEAMCENTER,&rulefound,&closurerule);
		}

		printf ("rule count %d \n",rulefound);fflush(stdout);
		if (rulefound > 0)
		{
			close_tag = closurerule[0];
			printf ("closure rule found New VC \n");fflush(stdout);
		}

		// Below code id for closure rule for refrence VC
		if (tc_strcmp(ClosureViewRefVC,"ERC")==0)
		{
			printf("inside ERC closure rule..\n");fflush(stdout);
			ifail = PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER,&rulefoundtwo,&closureruletwo);
		}
		else if (tc_strcmp(ClosureViewRefVC,"APLC")==0)
		{
			printf("inside APLC closure rule..\n");fflush(stdout);
			ifail = PIE_find_closure_rules2("BOMViewClosureRuleAPLC",PIE_TEAMCENTER,&rulefoundtwo,&closureruletwo);
		}
		else if (tc_strcmp(ClosureViewRefVC,"STDSI")==0)
		{
			printf("inside STDSI closure rule..\n");fflush(stdout);
			ifail = PIE_find_closure_rules2("BOMViewClosureRuleSTDC",PIE_TEAMCENTER,&rulefoundtwo,&closureruletwo);
		}
		
		printf ("rule count %d \n",rulefoundtwo);fflush(stdout);
		if (rulefoundtwo > 0)
		{
			close_tagtwo = closureruletwo[0];
			printf ("closure rule found for ref VC \n");fflush(stdout);
		}

		if (AssemoneQuery!=NULLTAG)
		{
			if (QRY_execute(AssemoneQuery, n_rev_entries, qry_entries, valuesone, &n_tags_found1, &t_allrevdocs));
			printf("\nInside first part tag  n_tags_found1: [%d] \n",n_tags_found1);fflush(stdout);
			
			if (n_tags_found1>0)
			{
				for (It=0;It<n_tags_found1 ;It++)
					{
						IteamprintTag=t_allrevdocs[0];
						ITK_CALL(AOM_UIF_ask_value(IteamprintTag,"object_string",&IteamNumberone));
						tc_strdup(IteamNumberone,&IteamNumberoneDup);

						printf("\ninside running function first\n");

						ITK_CALL(BOM_window_set_closure_rule(windowVCO,close_tag, 0,rulename,rulevalue));
						ITK_CALL(BOM_set_window_config_rule(windowVCO, ruleone));
					    ITK_CALL(BOM_set_window_pack_all (windowVCO, true));
					    ITK_CALL(BOM_set_window_top_line(windowVCO, NULLTAG, IteamprintTag, NULLTAG, &top_lineVCO));
					}

			}
		}
		printf("before querying Second part");
		QRY_find2("Item Revision...", &AssemTwoQuery);
		valuesTwo = (char **) MEM_alloc(n_rev_entriestwo * sizeof(char *));
		valuesTwo[0] = (char *)MEM_alloc( strlen( Assym2 ) + 1);
		tc_strcpy(valuesTwo[0], Assym2);
		valuesTwo[1] = (char *)MEM_alloc( strlen( RevSeqCat2 ) + 1);
		tc_strcpy(valuesTwo[1], RevSeqCat2);
		if (AssemTwoQuery!=NULLTAG)
		{
			printf("inside AssemTwoQuery Tag");
			if (QRY_execute(AssemTwoQuery, n_rev_entriestwo, qry_entriesTwo, valuesTwo, &n_tags_found2, &t_allrevdocsTwo));
			printf("value of n_tags_found2 is:%d",n_tags_found2);
			if (n_tags_found2>0)
				{
					for (Itt=0;Itt<n_tags_found2 ;Itt++)
						{
							IteamprintTagTwo=t_allrevdocsTwo[0];
							ITK_CALL(AOM_UIF_ask_value(IteamprintTagTwo,"object_string",&IteamNumberTwo));
							tc_strdup(IteamNumberTwo,&IteamNumberTwoDup);

							ITK_CALL(BOM_window_set_closure_rule(windowVCT,close_tagtwo, 0, rulename,rulevalue));
							ITK_CALL(BOM_set_window_config_rule(windowVCT, ruleTwo));
							ITK_CALL(BOM_set_window_pack_all(windowVCT, true));
							ITK_CALL(BOM_set_window_top_line(windowVCT, NULLTAG, IteamprintTagTwo, NULLTAG, &top_lineVCT));

						}
				}
		}
		printf("Module_address,Module_Name,Category,New_VC_chiled_part,Revision,Qty,Level,Part_No,Rev,Part_Description,Qty,CAR_make_buy,Reference_VC_child_part,Revision,Qty,Level,Part number,Revision,Part_Description,Qty,CAR_make_buy");fflush(stdout);
		fprintf(fp,"Serial_no,Module_address,Module_Name,Category,New_VC_chiled_part,Revision,Qty,Level,Part_No,Rev,Part_Description,Qty,CAR_make_buy,Reference_VC_child_part,Revision,Qty,Level,Part number,Revision,Part_Description,Qty,CAR_make_buy");fflush(fp);
		
		BOMExpansionforcommon(top_lineVCT,top_lineVCO,fp);  //Function call for common
		BOMExpansionforadd(top_lineVCO,top_lineVCT);        //Function call for Add
		Printaddelement(top_lineVCO,fp);					//Function call for Add
		BOMExpansionfordelete(top_lineVCT,top_lineVCO);		//Function call for delete
		Printdeleteelement(top_lineVCT,fp);					//Function call for delete
		BOMExpansionforReplace(top_lineVCT,top_lineVCO);	//Function call for Replace
		GetValuefromStrFunc(top_lineVCT,top_lineVCO);       //Function call for Replace
		Getprintaddmodvalue(top_lineVCT,top_lineVCO,fp);    //Function call for Replace
//		//printforchildPartRep1value(top_lineVCT);
//		//printforchildPartRep2value(top_lineVCO);
		RevChange(top_lineVCT,top_lineVCO,fp);              //Function call for Revision change
		QtyChange(top_lineVCT,top_lineVCO,fp);				//Function call for Quantity change

	//}
	
	printf("\n***********************************Now report Genration is completed***************************\n");fflush(stdout);
	write2xml(Report,"\n</Top>\n");
	
	if (Report!=NULL)
	{
		fclose(Report);
	}
	if (fp!=NULL)
	{
		fclose(fp);
	}

//CLEANUP:
//	printf("\nCLEANUP..."); fflush(stdout);
//	ITK_CALL(POM_logout(false));
	//return status;

//EXIT:
	printf("\nExiting...\n");
	ITK_CALL(POM_logout(false));
	//return status;
	
	return ITK_ok;
}
