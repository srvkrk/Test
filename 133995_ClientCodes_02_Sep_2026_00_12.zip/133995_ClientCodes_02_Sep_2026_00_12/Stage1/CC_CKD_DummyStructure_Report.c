#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
//#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>


#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
        printf ("\n ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("\n FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

void CKDDummystrcat(char **src,char* dest)
{
	//printf("\n Inside Function CKDDummystrcat\n");fflush(stdout);
			
	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	 char * desc = dest ? dest : "NA";
	
	//printf("\n autoresizestrcat src len==%d",strlen(*src));
	//printf("\n autoresizestrcat desc len==%d",strlen(desc));
	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;

	 //src = MEM_realloc(src, size_ab);
	
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}


char* removeChar(char *in) 
{	
	printf("\n Test Inside Function removeChar \n");fflush(stdout);
	int i,j;
	char *tmp;
	tmp=(char *)malloc(strlen(in)+2);
	i=0;
	j=0;
	while (in[j])
	{
		//if (in[j] != '\x01' && in[j] != '\x02')
		if (in[j] != '\n' && in[j] != '\r' )
		{
			tmp[i] = in[j];
			i++;
		}
		j++;
	}
	tmp[i]='\0';

return tmp;
}

char* removeSpecialChar(char *in) 
{	
	printf("\n Test Inside (Space Exclude) Function removeSpecialChar \n");fflush(stdout);
	int i,j;
	char *tmp;
	tmp=(char *)malloc(strlen(in)+2);
	i=0;
	j=0;
	while (in[j])
	{
		//if (in[j] != '\x01' && in[j] != '\x02')
		if (in[j] != '\x01' && in[j] != '\x02' && in[j] != '\x03' && in[j] != '\x04' && in[j] != '\x05' && in[j] != '\x06' && in[j] != '\x07' && in[j] != '\x08' && in[j] != '\x09' && in[j] != '\x10' && in[j] != '\x11' && in[j] != '\x12' && in[j] != '\x13' && in[j] != '\x14' && in[j] != '\x15' && in[j] != '\x16' && in[j] != '\x17' && in[j] != '\x18' && in[j] != '\x19' /*&& in[j] != '\x20'*/ && in[j] != '\x21')
		{
			tmp[i] = in[j];
			i++;
		}
		j++;
	}
	tmp[i]='\0';

return tmp;
}

int get_child(int count,int* Srcount, tag_t *child, FILE *fp, char* CKD_DMLName, char* DummyPart_id, char* DummyPart_desc, char** output)
{
	
	int ifail = ITK_ok;
	int i,z,count1,attr,count3,j,k;
	
	tag_t *sub_child= NULLTAG;
	tag_t bl_rev	= NULLTAG;

	char tempsrl[5];

	char* name						= NULL;
	char* object_type				= NULL;
	char* s							= NULL;
	char* sChlPrtno					= NULL;
	char* level						= NULL;
	char* FindNo					= NULL;
	char* revision					= NULL;
	char* Description				= NULL;
	char* Unit						= NULL;
	char* quantity					= NULL;
	char* CMVR_Cert_Reqd			= NULL;
	char* release_status_list		= NULL;
	char* LastModifiedDate			= NULL;
	char* last_mod_user				= NULL;
	char* Release_Status1			= NULL;
	char* Release_Status2			= NULL;
	char* Desc2						= NULL;
	char* Description1				= NULL;
	char* Description2				= NULL;
	
	//
	int	CountTask	= 0;
	int	iTask		= 0;
	int CountDML	= 0;
	int iDML		= 0;
	int StopExpand	= 1;
	
	char *PlantCS			= NULL;

	//

	int ruleConfigByID 	 =0;
	char* rules_configured_by = NULL;
	
	ITK_CALL(BOM_line_look_up_attribute("bl_config_string", &ruleConfigByID));
	
	printf("\n Inside Function get_child :: CKD_DMLName => %s | DummyPart_id => %s | DummyPart_desc => %s\n",CKD_DMLName,DummyPart_id,DummyPart_desc);fflush(stdout);
	
	printf("\n Srcount => %d \n",*Srcount); fflush(stdout);

	for(i=0;i<count;i++)
	{
		printf("\n Inside Loop Child %d \n",i+1);fflush(stdout);

		ITK_CALL(BOM_line_ask_attribute_string(child[i], ruleConfigByID, &rules_configured_by));
		printf("\n getChildObjectsInView:..rules_configured_by: %s \n",rules_configured_by);fflush(stdout);

		if(tc_strcmp(rules_configured_by, "No configured Revision") == 0 )
		{
			printf("\n skipping as no configured revision: \n");fflush(stdout);	
			continue;
		}
		
		ITK_CALL(BOM_line_look_up_attribute("bl_revision",&attr));
		ITK_CALL(BOM_line_ask_attribute_tag(child[i],attr,&bl_rev));		
		
		// Getting Plant CS
		ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_PunMakeBuyIndicator",&PlantCS));
		
		
		printf("\n Checking Child BOM-Line Property \n");fflush(stdout);
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_level_starting_0",&level));
		printf("\n Test 00.1 \n");fflush(stdout); 
		int level1 = atoi(level);

		printf("\n Test 0.1  \n");fflush(stdout); 

		ITK_CALL(AOM_ask_value_string(child[i],"bl_item_item_id",&sChlPrtno));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_rev_item_revision_id",&revision));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_sequence_no",&FindNo));
		
		// Description //
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_rev_object_desc",&Description1));
		printf("\n Before Description1 => %s \n",Description1);fflush(stdout);
		Description2=removeSpecialChar(Description1);
		STRNG_replace_str(Description2,",",";",&Desc2);
		printf("\n  test Desc2 => %s \n",Desc2);fflush(stdout);
		Description = removeChar(Desc2);
		printf("\n After Description => %s \n",Description);fflush(stdout);

		printf("\n Test 0.3  \n");fflush(stdout); 
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_uom",&Unit));
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_quantity",&quantity));
		
		
		ITK_CALL(AOM_UIF_ask_value(child[i],"bl_rev_release_status_list",&Release_Status1));
		STRNG_replace_str(Release_Status1,",",";",&Release_Status2);
		STRNG_replace_str(Release_Status2,"\n",";",&release_status_list);		
		
		printf("\n sChlPrtno:%s \n",sChlPrtno); fflush(stdout);

		//*Srcount++;	
		printf("\n Before Srcount => %d \n",*Srcount); fflush(stdout);

		*Srcount = *Srcount +1;

		printf("\n After Srcount => %d \n",*Srcount); fflush(stdout);

		sprintf(tempsrl,"%d",*Srcount);

		printf("\n tempsrl => %s \n",tempsrl); fflush(stdout);
		
		fprintf(fp,"\n %s,%s,%s,%s,%s,%s,%s,%s,%s,%s",tempsrl,CKD_DMLName,DummyPart_id,DummyPart_desc,sChlPrtno,revision,release_status_list,Description,quantity,PlantCS);fflush(fp);

		CKDDummystrcat(output,"\n");
		CKDDummystrcat(output,tempsrl);
		CKDDummystrcat(output,",");
		CKDDummystrcat(output,CKD_DMLName);
		CKDDummystrcat(output,",");
		CKDDummystrcat(output,DummyPart_id);
		CKDDummystrcat(output,",");
		CKDDummystrcat(output,",");
		CKDDummystrcat(output,DummyPart_desc);
		CKDDummystrcat(output,",");
		CKDDummystrcat(output,sChlPrtno);
		CKDDummystrcat(output,",");
		CKDDummystrcat(output,revision);
		CKDDummystrcat(output,",");
		CKDDummystrcat(output,release_status_list);
		CKDDummystrcat(output,",");
		CKDDummystrcat(output,Description);
		CKDDummystrcat(output,",");
		CKDDummystrcat(output,quantity);
		CKDDummystrcat(output,",");
		CKDDummystrcat(output,PlantCS);				
	}	
		
	return ifail;
}


int tm_DummyStructure(tag_t DML_Tag, tag_t DummyPart_Tag,FILE *fp,char** output,int* Srcount)
{
	printf("\n Inside tm_DummyStructure Function \n");fflush(stdout);
	printf("\n tm_DummyStructure-Srcount => %d \n",*Srcount);fflush(stdout);

	//char*	closureRuleName ="BOMViewClosureRuleAPLP";
	char*	CKD_DMLName			= NULL;
	char*	DummyPart_id		= NULL;
	char*	DummyPart_desc		= NULL;
	char*	CKD_DML_TargetPlant	= NULL;

	tag_t	window			= NULLTAG;
	tag_t	rule			= NULLTAG;
	tag_t*	closure_tags	= NULLTAG;
	tag_t  	closure_tag		= NULLTAG;
	tag_t	item			= NULLTAG;
	tag_t	top_line		= NULLTAG;
	tag_t*	child			= NULLTAG;

	int n_closure_tags;

	int z,i,j,count,countz;

	char*	closureRuleName	= NULL;
	char*	RevisionRule	= NULL;
	
	closureRuleName	= (char *)MEM_alloc(100);
	RevisionRule	= (char *)MEM_alloc(100);
		
	tc_strcpy(closureRuleName,"");
	tc_strcpy(RevisionRule,"");	

	AOM_ask_value_string(DML_Tag,"item_id",&CKD_DMLName);
	printf("\n CKD_DMLName => %s \n",CKD_DMLName);fflush(stdout);

	AOM_ask_value_string(DummyPart_Tag,"item_id",&DummyPart_id);
	printf("\n DummyPart_id => %s \n",DummyPart_id);fflush(stdout);

	AOM_ask_value_string(DummyPart_Tag,"object_desc",&DummyPart_desc);
	printf("\n DummyPart_desc => %s \n",DummyPart_desc);fflush(stdout);

	AOM_ask_value_string(DML_Tag,"t5_TargetPlant",&CKD_DML_TargetPlant);
	printf("\n CKD_DML_TargetPlant => %s \n",CKD_DML_TargetPlant);fflush(stdout);

	if (tc_strcmp(CKD_DML_TargetPlant,"JAMSHEDPUR") == 0)
	{
		printf("\n Inside JAMSHEDPUR \n");fflush(stdout);
	    tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDJ");
		tc_strcpy(RevisionRule,"STDJ Working and Above");		
	}
	else if (tc_strcmp(CKD_DML_TargetPlant,"LUCKNOW") == 0)
	{
		printf("\n Inside LUCKNOW \n");fflush(stdout);
	    tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDL");
		tc_strcpy(RevisionRule,"STDL Working and Above");		
	}
	else if (tc_strcmp(CKD_DML_TargetPlant,"DHARWAD") == 0)
	{
		printf("\n Inside DHARWAD \n");fflush(stdout);
	    tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDD");
		tc_strcpy(RevisionRule,"STDD Working and Above");		
	}
	else if (tc_strcmp(CKD_DML_TargetPlant,"PCVBU") == 0)
	{
		printf("\n Inside PCVBU \n");fflush(stdout);
	    tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDP");
		tc_strcpy(RevisionRule,"STDP Working and Above");		
	}
	else if (tc_strcmp(CKD_DML_TargetPlant,"PANTNAGAR") == 0)
	{
		printf("\n Inside PANTNAGAR \n");fflush(stdout);
	    tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDU");
		tc_strcpy(RevisionRule,"STDU Working and Above");		
	}
	else
	{
		printf("\n Inside else \n");fflush(stdout);
		tc_strcpy(closureRuleName,"BOMViewClosureRuleSTDP");
		tc_strcpy(RevisionRule,"STDP Working and Above");		
	}

	printf("\n Final ClosureRule is => [%s] || RevisionRule is => [%s] \n", closureRuleName,RevisionRule);
	

	ITK_CALL(BOM_create_window(&window));
	//ITK_CALL(CFM_find( "STDP Working and Above", &rule ));
	ITK_CALL(CFM_find( RevisionRule, &rule ));
	ITK_CALL(BOM_set_window_config_rule( window, rule ));
	ITK_CALL(BOM_set_window_pack_all(window, true));	

	ITK_CALL(PIE_find_closure_rules2( closureRuleName,PIE_TEAMCENTER, &n_closure_tags, &closure_tags )); // Ketan
			
	printf ("\n n_closure_tags => %d \n",n_closure_tags);fflush(stdout);
	if (n_closure_tags > 0)
	{
		closure_tag=closure_tags[0];
		printf ("\n closure rule found \n");fflush(stdout);				
	}
	
	ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	
	// Find out bom line tag
	ITK_CALL(BOM_set_window_top_line(window,item,DummyPart_Tag,NULLTAG,&top_line));
	ITK_CALL(BOM_window_hide_unconfigured( window ));
	ITK_CALL(BOM_window_hide_suppressed( window ));
	// Find out the all childs
	ITK_CALL(BOM_line_ask_all_child_lines(top_line,&count,&child));

	printf("\n Number Of Child in CKD-VC => [%d] \n",count);
	
	// Getting Child property
	get_child(count,Srcount,child,fp,CKD_DMLName,DummyPart_id,DummyPart_desc,output);

	if(window!=NULLTAG)
			BOM_close_window(window);
	
}

void autoresizestrAdd_Dummy(char **src,char* dest)
{
	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	char * desc = dest ? dest : "NA";
	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
	// src = MEM_realloc(src, size_ab);
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
	tc_strcat(*src , desc);
}

extern int ITK_user_main( int argc, char **argv )
{
	//VARIABLE DECLARATION STARTS
	int     status;
	int     ifail;
	
	char*	Input_DML			= NULL;
	char*	inputuser			= NULL;
	char*	inputpwd			= NULL;
	char*	inputgrp			= NULL;
	char*	s					= NULL;
	char*	type_name			= NULL;
	char*	object_type			= NULL;
	char*	DMLName				= NULL;
	char*	TaskName			= NULL;
	char*	Part_no				= NULL;
	char*	Part_Type			= NULL;
	char*	Input_CKD_DML		= NULL;
	char*	Login_User			= NULL;
	char*	username			= NULL;
	char*	user_email			= NULL;

	tag_t	DML_No					= NULLTAG;
	tag_t	DML_RevTag				= NULLTAG;
	tag_t*	PartTags				= NULLTAG;	
	tag_t	objTypeTag				= NULLTAG;
	tag_t	relation_type			= NULLTAG;
	tag_t*	TaskRevision			= NULLTAG;
	tag_t	TaskRevTag				= NULLTAG;
	tag_t	tsk_part_sol_rel_type	= NULLTAG;
	tag_t	AssyTag					= NULLTAG;
	tag_t	user_tag				= NULLTAG;
	tag_t	person_tag				= NULLTAG;

	int		count				= 0;
	int		TaskCnt				= 0;
	int		PartCnt				= 0;
	int		k					= 0;
	int		Srcount				= 0;

	FILE *fp;

	char *output							= NULL;
	
	output = (char *) MEM_alloc( 1000 * sizeof(char) );

	printf("\n ~~~~~~~~~ Ketan Inside Program CKD_DummyStructure_Report ~~~~~~~~~~~\n");fflush(stdout);
	
	ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	ITK_CALL(ITK_auto_login());
	ITK_set_bypass(true);

	ITK_CALL(ITK_set_journalling(TRUE));
	if (status == 0 )
	{
		printf("\n login to Teamcenter successful");fflush(stdout);
	}
	else
	{
	  printf("\n Error code:%d",status);fflush(stdout);
	  EMH_ask_error_text(status,&s);
	  printf("\n Error message:%s",s);fflush(stdout);
	}
	
	//
	Input_CKD_DML   = (char *) MEM_alloc(1 * sizeof(char *));
	Login_User	= (char *) MEM_alloc(1 * sizeof(char *));

	printf("\n  Test 1 \n");fflush(stdout);
	
	autoresizestrAdd_Dummy(&Input_CKD_DML,argv[3]);
	autoresizestrAdd_Dummy(&Login_User,argv[4]);

	printf("\n  Test 2 \n");fflush(stdout);

	printf("\n Input_CKD_DML :: %s ",Input_CKD_DML);fflush(stdout);
	printf("\n Login_User :: %s ",Login_User);fflush(stdout);

	ITK_CALL(SA_find_user2(Login_User,&user_tag));

	if(user_tag != NULLTAG )
	{
		ITK_CALL(SA_ask_user_person_name2(user_tag,&username));
		ITK_CALL(SA_find_person2(username,&person_tag));
		ITK_CALL(SA_ask_person_email_address(person_tag,&user_email));	
	}
	printf("\n username => %s user_email => %s \n",username,user_email);
	
	char ReportFiredDate[26] = {'\0'};
	time_t now;
	struct tm* now_tm;
	time(&now);
	now_tm = localtime(&now);
	strftime (ReportFiredDate, 26,"%d-%B-%Y:%H:%M:%S", now_tm);
	printf("\n ReportFiredDate is===>[%s]",ReportFiredDate);fflush(stdout);

	char*       FileName           = NULL;
	FileName = (char *) MEM_alloc(100 * sizeof(char *));
	
	tc_strcpy(FileName,"/tmp/DummyPartStructure");
	tc_strcat(FileName,"_");
	tc_strcat(FileName,Input_CKD_DML);
	tc_strcat(FileName,"_");
	tc_strcat(FileName,ReportFiredDate);
	tc_strcat(FileName,".csv");

	fp = fopen(FileName,"w");

	printf("\n Test 11111 \n");fflush(stdout);

	// Only For Header
	fprintf(fp,"SRNO,DMLNO,DUMMY ASSY PART NO,DUMMY ASSY PART DESC,DUMMY CHILD PART NO,Revision,LifeCycleStatus,DUMMY CHILD PART DESC,QTY,CS");fflush(fp); 
	CKDDummystrcat(&output,"SRNO,DMLNO,DUMMY ASSY PART NO,DUMMY ASSY PART DESC,DUMMY CHILD PART NO,Revision,LifeCycleStatus,DUMMY CHILD PART DESC,QTY,CS");

	ITK_CALL(ITEM_find_item(Input_CKD_DML,&DML_No));
	ITK_CALL(ITEM_ask_latest_rev(DML_No,&DML_RevTag));

	AOM_ask_value_string(DML_RevTag,"item_id",&DMLName);
	printf("\n DMLName is :%s \n",DMLName);fflush(stdout);

	if(TCTYPE_ask_object_type(DML_RevTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n type_name : %s \n",type_name);fflush(stdout);

	if(strcmp(type_name,"T5_CkdDmlRevision")==0)
	{
		printf("\n inside class T5_CkdDmlRevision ......\n");fflush(stdout);

		if (DML_RevTag != NULLTAG)
		{
			GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);

			GRM_list_secondary_objects_only(DML_RevTag,relation_type,&count,&TaskRevision);
			printf("\n CKD DML to Task : %d\n",count);fflush(stdout);

			for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
			{
				TaskRevTag = TaskRevision[TaskCnt];

				AOM_ask_value_string(TaskRevTag,"object_type",&object_type);
				printf("\n object_type is :%s \n",object_type);fflush(stdout);

				AOM_ask_value_string(TaskRevTag,"item_id",&TaskName);
				printf("\n TaskName is :%s \n",TaskName);fflush(stdout);

				//if((strcmp(object_type,"T5_ChangeTaskRevision")==0) || (strcmp(object_type,"T5_SMDMLTaskRevision")==0))
				if((strcmp(object_type,"T5_ChangeTaskRevision")==0) || (strcmp(object_type,"T5_SMDMLTaskRevision")==0)|| (strcmp(object_type,"T5_CKDTaskRevision")==0))
				{
					PartCnt=0;

					AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags);
					printf("\n CKD DML Task PartCnt: %d \n",PartCnt);fflush(stdout);

					if (PartCnt>0)
					{
						GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
						for (k=0;k<PartCnt ;k++ )
						{
							//printf("\n Part Count k =:%d",k);fflush(stdout);
							AssyTag=PartTags[k];

							AOM_ask_value_string(AssyTag,"item_id",&Part_no);
							AOM_ask_value_string(AssyTag,"t5_PartType",&Part_Type);
							
							printf("\n [%d].Part_no is => [%s] Part_Type => [%s] \n",k+1,Part_no,Part_Type);fflush(stdout);

							if(strcmp(Part_Type,"D")==0)
							{
								printf("\n calling Function for Dummy\n");fflush(stdout);
								printf("\n Main_Srcount => %d \n",Srcount);fflush(stdout);
								tm_DummyStructure(DML_RevTag,AssyTag,fp,&output,&Srcount);
								printf("\n output => %s\n",output);
							}
						}
					}
				}
			}
		}
	}
	fclose(fp);

	// For Executing Mail // 
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
    char    *qry_valuesCntrl1[3]= {"CKD","Dummy","0"};
	
    tag_t qryTagCntrl1				= NULLTAG;
    tag_t* list_of_WSO_cntrl_tags1	= NULLTAG;

	int n_entryCntrl1		  = 3;
	int control_number_found1 = 0;;

	ITK_CALL(QRY_find2("Control Objects...", &qryTagCntrl1));

	if (qryTagCntrl1)
	{
	    printf("\n Control Object Query Found \n");fflush(stdout);
    
	    ITK_CALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

		printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);
	}

	if(control_number_found1>0)
	{
		printf("\n Inside control_number_found1 \n");fflush(stdout);

	    char* t5_Userinfo2 = NULL;
		char cmd[100];

		tag_t CKD_obj = list_of_WSO_cntrl_tags1[0];
		ITK_CALL(AOM_ask_value_string(CKD_obj,"t5_Userinfo2",&t5_Userinfo2));	
		sprintf(cmd,"%s %s %s",t5_Userinfo2,FileName,user_email);
		printf("\n Ketan Excuting Command for Mail of CKD_DummyStructure_Report => %s \n",cmd);fflush(stdout);
		system(cmd);
		printf("\n After executing Command for Mail of CKD_DummyStructure_Report \n");fflush(stdout);
	}
	else
	{
		printf("\n Control Object not exitst for CKD_DummyStructure_Report \n");fflush(stdout);
	}

	printf("\n Ketan CKD_DummyStructure_Report Code ends...\n");fflush(stdout);
	
	
	return status;

}
