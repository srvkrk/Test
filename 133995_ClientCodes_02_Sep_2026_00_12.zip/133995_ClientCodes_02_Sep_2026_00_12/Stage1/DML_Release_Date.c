/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Item
*  Description  :   WebService For DML Release Date
*  File Name    :   DML_Release_Date.c
*  Created on   :   July 28th, 2023
*  Usage        :   DML_Release_Date.c
***************************************************************************/

#include "soapH.h"
#include "DML_Release_Date.nsmap"
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define ITEM_id_size_c   128

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -pno=<Part Number 10 Digit> (Required)\n"
		" -ptype=<Part Type> (Required)\n"
        );	
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
	const int*      pSevLst = 0;
	const int*      pErrCdeLst = 0;
	const char**    pMsgLst = NULL;
 

    //register int i = 0;
    int i =0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
   //ffprintf(fp, stderr, "CopyTemplates Error(s): \n");
   //fprintf(fp,"CopyTemplates Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
       //   ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
-      //   fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
       //   ffprintf(fp, stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
       //   fprintf(fp,"\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
	   printf("Test");
    }
    return ITK_ok;
}

extern int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); 

}
;

int ns__getDMLReleaseDate(struct soap* soap,char *DMLnumber,char *Drgate,char **Response)
{
	int				ifail 						= ITK_ok;
	int				r_count 					= 0;
	int				Dmlcount		 			= 0;
	int				status		 				= 0;
	char*			s		 					= NULL;
	char*			inputfile		 			= NULL;
	char			filewrite[500];
	tag_t*			soResult					= NULLTAG;
	tag_t			dmlidTag					= NULLTAG;
	tag_t			dmllatRevTag				= NULLTAG;
	tag_t			ErcDmlPtr					= NULLTAG;
	tag_t			query						= NULLTAG;
	char *          dmlid						= NULL;
	char *          dmlNo						= NULL;
	char *          Release_Date				= NULL;
	char *          Finaldate					= NULL;
	FILE *          fp1							= NULL;
	char			**Response1					= NULL;

	char**  qry_values          = NULL;
	char*   qry_entry[1]		= {"ID"};
	qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/tcuadml.txt", "a", stdout);

	
	//**************************For Auto Login**************************//

		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		ITK_CALL(ITK_auto_login());
		ITK_set_bypass(true);

		ITK_CALL(ITK_set_journalling(TRUE));
		if (status == 0 )
		{
		  printf("\n Auto login to Teamcenter successful \n");fflush(stdout);
		}
		else
		{
		  printf("\n Error code:%d",status);fflush(stdout);
		  EMH_ask_error_text(status,&s);
		  printf("\n Error message:%s",s);fflush(stdout);
		}

	//**************************Ended**************************//


	//printf("\n\n ******* DML_Details ***** \n");fflush(stdout);

	if(QRY_find("ERC DML Revision",&query));
	{
		//printf("\n\n ******* DML_Details in TCUA ***** \n");fflush(stdout);
		
		if (query)
		{
			qry_values[0] = (char *)MEM_alloc( strlen( DMLnumber ) + 1);
		    tc_strcpy(qry_values[0], DMLnumber );
			//printf("\n 11111 \n");fflush(stdout);

			ITK_CALL(QRY_execute(query, 1, qry_entry, qry_values, &Dmlcount, &soResult));
			//printf("\n 22222 \n");fflush(stdout);
			//printf("\n 33333 \n");fflush(stdout);
			if (Dmlcount > 0)
			{
				ErcDmlPtr =  soResult[0];
				ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr,"item_id",&dmlid));
				ITK_CALL(ITEM_find_item(dmlid, &dmlidTag));
				ITK_CALL(ITEM_ask_latest_rev(dmlidTag,&dmllatRevTag));

				ITK_CALL(AOM_UIF_ask_value(dmllatRevTag,"item_id",&dmlNo));
				//printf("\n\n\t\t DML No ==> %s",dmlNo);fflush(stdout);;

				ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr, "date_released", &Release_Date));
				//printf("\n\n\t\t Release Date ==> %s",Release_Date);fflush(stdout);

				Finaldate=subString(Release_Date, 0, 11);

				if(Finaldate)
				{
					*Response = (char *) malloc( (50) * sizeof(char));
					strcpy(*Response,Finaldate);
				}
				else
				{
					printf("\n 2. Response is NA");fflush(stdout);
					*Response = (char *) malloc( (50) * sizeof(char));
					strcpy(*Response,"NA");
				}
			}
			else
			{
				//printf("\n\n ******* DML_Details in TCE ***** \n");fflush(stdout);
				//TCE shell calling
				char* Response2 = NULL;
				Response2=(char *)MEM_alloc(200);
				tc_strcpy(Response2,"");
				tc_strcat(Response2,"/proj/PLMLoading/UAFiles/TCUA/ERC/Webservice_CV/TCE_DML_RLZ_DATE.sh");
				tc_strcat(Response2," ");
				tc_strcat(Response2,DMLnumber);
				system(Response2);
				//printf("\n\n\t\t execution command ==> %s",Response2);fflush(stdout);

				 inputfile = (char *)MEM_alloc(500);
				tc_strcpy(inputfile,"");	
				tc_strcat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/ERC/Webservice_CV/");
				tc_strcat(inputfile,DMLnumber);
				tc_strcat(inputfile,"_Rlz_date.txt");
				//printf("\n\n\t\t inputfile ==> %s",inputfile);fflush(stdout);
				fp1=fopen(inputfile,"r");

					if(fp1!=NULL)
					{
						int partCnt=0;
						//printf("\n file not null : ");fflush(stdout);
						char *Response1 =NULL;

						while (fgets(filewrite,1000,fp1)!=NULL)
						{
							//fputs(filewrite,inputfile);
							//printf("\n fgets open and fp1 not null :");fflush(stdout);
							//printf("\n filewrite %s :",filewrite);fflush(stdout);
							fputs(inputfile,stdout);
							Response1=NULL;
							Response1=tc_strtok(filewrite,",");
							//printf("\n Response1 is : %s",Response1);fflush(stdout);

						   
							if(tc_strcmp(Response1,"")!=0)
							{
								//printf("\n Response is : %s",Response1);fflush(stdout);
								*Response = (char *) malloc( (50) * sizeof(char));
								strcpy(*Response,Response1);
								break;
							}
							else
							{
								//printf("\n 1.Response is NA");fflush(stdout);
								*Response = (char *) malloc( (50) * sizeof(char));
								strcpy(*Response,"NA");

							}
						   

						}

						

					}
				fclose(fp1);
			}
		}
	}
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);
	return SOAP_OK;
}