//gsoap ns service name:				 PartDetails
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:PartDetails
//gsoap ns service location:			 https://172.22.99.106:9081/cgi/PartDetails.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:PartDetails
//gsoap ns service method-documentation: Tests the Simple Web service


struct ns__ItemDet
{
   char *PART_NO;
   char *PART_REV;
   char *PART_SEQ;
   char *PART_DESC;
   char *PART_LC;
}
;
struct ns__CharArray1
{
   struct ns__ItemDet *__ptrItem;
   int __size;
}
;

int ns__getItemData(char *Item,struct ns__CharArray1 *aString_test);


