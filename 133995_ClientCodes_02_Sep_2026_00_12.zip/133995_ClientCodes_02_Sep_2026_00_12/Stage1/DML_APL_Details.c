/* *********************************************************************************************************************************************************
**
** SOURCE FILE NAME: tm_DML_to_Part_Detail_Report.c
**
**
**	Date							Author					Modification
**	22-09-2023						Mohan Tayade			Code creation
**
** command to run:
*
* SrNo		Modified By		Date			Modification
*
* Info:
* KSP=Kit and Spare Part Release
* TSKR=Module with Spare Kit Release
* EP=ECU Parts Release
* MMDMR=Module Master Data Management Request
* RBQU=Released BOM Quantity Update

./tm_DML_to_Part_Detail_Report_CV -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=17-05-21 -I2=18-05-21 -I3=pd923493.ttl
./tm_DML_to_Part_Detail_Report_CV -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=01-01-25 -I2=31-01-25 -I3=mohant.ttl
./tm_DML_to_Part_Detail_Report_CV -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=19-01-25 -I2=21-01-25 -I3=mohant.ttl
* ./tm_DML_to_Part_Detail_Report_CRON -I1=04-07-2024 -I2=05-07-2024 -I3=pd923493.ttl -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
********************************************************************************************************************************************************** */

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <ae/datasettype.h>
#include <sa/user.h>
#include <tc/folder.h>
#include <sa/person.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <ics/ics.h>
#include <ics/ics2.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
;

int getClsValueFrmICSTagAct( tag_t  IcsClsTag ,char **AttrVal);
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(2000);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_ask_error_text (return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}

FILE		*DMLoutput 			= NULL;
int			ifail 				= ITK_ok;
char		*sep				= "^";
int tm_DML_Mail_Fun(char*,char*);

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"GateMaturationUpd -u=<username> -pf=<password file path> -g=<group> -file=<file_name>\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
void getCurrentDateTimeAJ(char cCurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%b_%Y",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlnob					= NULL;
	char			Data[100]					= "";
	char* FromDate=NULL;
	char* ToDate=NULL;
	FromDate 		= ITK_ask_cli_argument("-I1=");
	ToDate 		= ITK_ask_cli_argument("-I2=");
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nhey Login Successfull.....!!\n");fflush(stdout);
		printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
	}
	
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}
	ifail = tm_DML_Mail_Fun(FromDate,ToDate);
	CHECK_FAIL;

	printf("\n*********************");fflush(stdout);
	printf("\nEnd of program.....!!");fflush(stdout);
	printf("\n*********************\n");fflush(stdout);
	ifail = ITK_exit_module(true);

	return ifail;
}
int getClsValueFrmICSTagAct( tag_t  IcsClsTag ,char **AttrVal)
{
	tag_t objTypeTag=NULLTAG;
	tag_t objTypeTag2=NULLTAG;
	char   Ptype_name[TCTYPE_name_size_c+1];
	char   Stype_name[TCTYPE_name_size_c+1];
	char   relation_name[TCTYPE_name_size_c+1];
	char   *username  = NULL;
	char *RetAttrVal=NULL;
	char *AttrKeyValue=NULL;
	int       st_count=0;
	int iStCnt				=	0;
	int		status;
	int  ifail = ITK_ok;
	int cnt		=0;
	int lcstatcnt =0;
	tag_t *ClsObjTag = NULLTAG;
	tag_t*    status_list;
	int	  ic				= 0;
	int   t5NoEcuDupint		= 0;
	int	  nAttributes		= 0;
	int   na				= 0;
	char* ErrorText			= NULL;
	char* VCMasterTagObjStr	= NULL;
	char* vcLatestRevID		= NULL;
	char* attributeValue	= NULL;
	char* t5NoEcuDup		= NULL;
	char** attributeNames	= NULL;
	char** attributeValues	= NULL;

	tag_t VCMasterTag		= NULLTAG;
	tag_t VCLatestRev		= NULLTAG;
	tag_t Design_rev_cls_tag    = NULLTAG;

	int theAttributeCount =0;
	int *theAttributeIds ;
	char 			**theAttributeNames;
	int *theAttributeValCounts=0;
	char***       theAttributeValues;
	char***       theAttributeOptimizedUnits;
	char* 	attrId 					= NULL;
	attrId = (char *) MEM_alloc( 50 * sizeof(char) );
	char 	*attributeNameDup 			= NULL;
	char 	*attributeValueDup 			= NULL;
	attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
	int i,j,x=0;
	int TotVCAttrCount=0;
	//struct VCAttrDetails VCAttrDetailsList[5000];
	int *vcattr = 0;
	char    *key_lov_name;
	char    *owning_site;
	int  	options;
	int  	n_lov_entries;
	char    **lov_keys;
	char	**lov_values;
	logical * deprecated_staus;
	int  	n_shared_sites;
	char	** shared_sites ;

    printf("\n getClsValueFrmICSTagAct Function started...");fflush(stdout);
	TC_write_syslog("\n getClsValueFrmICSTagAct Function started...");

	ITK_CALL( ICS_ico_ask_attributes_optimized(IcsClsTag,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
	if(theAttributeCount>0)
	{
			for(i=0;i<theAttributeCount;i++)
			{
				TotVCAttrCount=TotVCAttrCount+theAttributeCount;

				sprintf(attrId,"%d",theAttributeIds[i]);
				//printf("\n attrId:[%s]",attrId);fflush(stdout);

				tc_strcpy(attributeNameDup,"");
				tc_strcpy(attributeNameDup,theAttributeNames[i]);

				printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,i);fflush(stdout);

				if((tc_strcmp(attributeNameDup,"EPC/Driver VC No")==0))
				{

					tc_strcpy(attributeValueDup,"");

					for(x=0;x<theAttributeValCounts[i];x++)
					{
						//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[i][x]);fflush(stdout);
						tc_strcat(attributeValueDup,theAttributeValues[i][x]);
						//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
					}
					printf("\n theAttribute Name :[%s]",attributeNameDup,i);fflush(stdout);
					printf("\n attrId:[%s]",attrId);fflush(stdout);
					printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);
					*AttrVal=attributeValueDup;

				}

			}
			//printf("\n total VC attribute value:[%d] ",TotVCAttrCount);fflush(stdout);
			//printf("\n total vcattr value:[%d] ",*vcattr);fflush(stdout);
	}

	printf("\n attributeValueDup=%s ",attributeValueDup); fflush(stdout);

	printf("\n getClsValueFrmICSTagAct Function end...");fflush(stdout);
	TC_write_syslog("\n getClsValueFrmICSTagAct Function end...");

	//return ITK_ok;
	return 0;

}

int tm_DML_Mail_Fun(char* FromDate,char* ToDate)
{
	int		ifail 		= ITK_ok;
	tag_t	item_tag		= NULLTAG;
	tag_t   DMLqryTag     = NULLTAG;
	tag_t	objTag		= NULLTAG;
	char	*DML_info1		= NULL;
	char	*DML_info2		= NULL;
	char	*DML_info3	= NULL;
	char	*DMLManager	= NULL;
	char	*DMLVertical	= NULL;
	char	*Dml_DR	= NULL;
	char	*sDMLBU	= NULL;
	char	*DMLSynopsis	= NULL;
	char	*DMLReason	= NULL;
	char	*DMLRlsType	= NULL;
	tag_t   *DML_CntrlObjectTag      = NULLTAG;
	int      i      =  0;
	char	*revId			=  NULL;
	char	*sDMLRlsType			=  NULL;
	char	*taskitemid			=  NULL;
	char	*DMLID			=  NULL;
	char	*dmlNumber			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char   ObjTyp[TCTYPE_name_size_c+1];
	tag_t dml_Ref_Rel	= NULLTAG;
	tag_t dml_Ref_Rel_t	= NULLTAG;
	int k=0;
	int fld=0;
	int tsk=0;
	int partcnt=0;
	int Tskcnt=0;
	int status_countt = 0;

	char *vehERCreldate = NULL;
	char *Tsk_object_type =NULL;
	char *Part_no =NULL;
	char *Part_nobr =NULL;
	char *Prtobj_type =NULL;
	char *FldrName =NULL;
	char *sSystPrtName =NULL;
	char *tsknm =NULL;
	char *Part_DR =NULL;
	char *Part_type =NULL;
	char *Part_Descr =NULL;
	char *Part_modiDescr =NULL;
	char *Part_Rev =NULL;
	char *Part_Proj =NULL;
	char *ncRel_status =NULL;
	char *Part_Desg =NULL;
	char *DMLwbs =NULL;
	char *DMLRel_status =NULL;
	char *DMLStatus =NULL;
	char *DMLCreDate =NULL;
	char *DMLClsuDate =NULL;
	char *DMFrmTODR =NULL;
	char *DMLwbsDesc =NULL;
	char *AttrKeyValue =NULL;
	char *latest_rev_Rel_Stus = NULL;
	tag_t *chkrelStatus_list = NULLTAG;
	tag_t		*PartsTg	= NULLTAG;
	tag_t		*Dml_tasks	= NULLTAG;
	tag_t  *FolderObj_tag	= NULLTAG;
	tag_t  *ClsObjTag	= NULLTAG;
	tag_t AssyTg = NULLTAG;
	tag_t PartTag = NULLTAG;
	tag_t item = NULLTAG;
	tag_t		Prtobject_owner		= NULLTAG;
	tag_t		object_owner		= NULLTAG;
	tag_t		DMLtag			= NULLTAG;
	tag_t		DMLtagg			= NULLTAG;
	tag_t		Prtperson_tag			= NULLTAG;
	tag_t       *task_obj_tag  =       NULLTAG;
	tag_t		person_tag			= NULLTAG;
	tag_t		TaskRevTag			= NULLTAG;
	tag_t		ClsObj			= NULLTAG;
	char*		sPart_type			= NULL;
	char*		PartOwner			= NULL;
	char*		person_name			= NULL;
	char*		DMLDesc			= NULL;
	char*		sDMLManager			= NULL;
	char*		DMLDescr			= NULL;
	char*		DMLnumbstrg			= NULL;
	char*		DMLtrg			= NULL;
	char*		ProjectID			= NULL;
	char*  PartColInd   =NULL;
	char*  PartCompCod   =NULL;
	char*  PartDrwInd   =NULL;
	char*  MakbuyPune   =NULL;
	char*  MakbuyCar   =NULL;
	char*  MakbuyUV   =NULL;
	char*  MakbuyAHD   =NULL;
	char*  MakbuyLKO   =NULL;
	char*  MakbuyDWD   =NULL;
	char*  MakbuyPNR   =NULL;
	char*  MakbuyJSR   =NULL;
	char*  MakbuyRJV   =NULL;
	char*  MakbuySND   =NULL;
	int     iDML      =  0;
	int     iDML1      =  0;
	int     rptline      =  0;
	int     DML_rsltCount      =  0;
	int     cnt_ccvcls      =  0;
	int     DML_n_entry    = 3;
	int     FlderSize    = 0;
	int     noOfTask    = 0;
	int     FlderObjCount    = 0;
	printf("\n P1:....Inside DML Part details.From Date:[%s]\n",FromDate);fflush(stdout);
	printf("\n P1:....Inside DML Part details.To Date:[%s]\n",ToDate);fflush(stdout);
	char *Path =NULL;
	Path = (char *)MEM_alloc(100);
	tag_t msExcelType       = NULLTAG;
	tag_t ExcelDataset      = NULLTAG;
	tag_t ExlLatestDat_t    = NULLTAG;
	tag_t user_tag    = NULLTAG;
	tag_t homefoldertag    = NULLTAG;
	 tag_t relatnType_tag=NULLTAG;
           int APLFlag = 0;
			int STDFlag = 0;
			int MBOMFlag = 0;
	char cCurrentAccessDate[20]={0};
	char*			DMLoutputFile				= NULL;
	char *FinalRel_status = NULL;
	DMLoutputFile = (char *)MEM_alloc(100);
	getCurrentDateTimeAJ(cCurrentAccessDate);

	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	char date_str[11]; // dd-mm-yyyy + '\0'
	strftime(date_str, sizeof(date_str), "%d-%m-%Y", &tm);

	printf("\n Todays Date is %s \n", date_str);

	tc_strcpy(DMLoutputFile,"");

	tc_strcat(DMLoutputFile,"APL_DML_DATA_");


	//tc_strcpy(Path,"/tmp/");
	tc_strcpy(Path,"/user/cvprod/Program_Shells/DML_DCR/Cronjob/APL_DML_Check/");
	//tc_strcat(Path,"Vehicle_Varient_Report_CV_");
	tc_strcat(Path,"APL_DML_DATA_");
	tc_strcat(Path,date_str);
	tc_strcat(Path,".csv");

	printf(" - Path = %s ",Path);

	printf("\n DMLSTAMP:M1: FromDate: [%s]  ToDate: [%s]\n",FromDate,ToDate);fflush(stdout);
	if(strstr(FromDate,"-01-")!=NULL){STRNG_replace_str(FromDate,"-01-","-Jan-",&FromDate);}
	if(strstr(FromDate,"-02-")!=NULL){STRNG_replace_str(FromDate,"-02-","-Feb-",&FromDate);}
	if(strstr(FromDate,"-03-")!=NULL){STRNG_replace_str(FromDate,"-03-","-Mar-",&FromDate);}
	if(strstr(FromDate,"-04-")!=NULL){STRNG_replace_str(FromDate,"-04-","-Apr-",&FromDate);}
	if(strstr(FromDate,"-05-")!=NULL){STRNG_replace_str(FromDate,"-05-","-May-",&FromDate);}
	if(strstr(FromDate,"-06-")!=NULL){STRNG_replace_str(FromDate,"-06-","-Jun-",&FromDate);}
	if(strstr(FromDate,"-07-")!=NULL){STRNG_replace_str(FromDate,"-07-","-Jul-",&FromDate);}
	if(strstr(FromDate,"-08-")!=NULL){STRNG_replace_str(FromDate,"-08-","-Aug-",&FromDate);}
	if(strstr(FromDate,"-09-")!=NULL){STRNG_replace_str(FromDate,"-09-","-Sep-",&FromDate);}
	if(strstr(FromDate,"-10-")!=NULL){STRNG_replace_str(FromDate,"-10-","-Oct-",&FromDate);}
	if(strstr(FromDate,"-11-")!=NULL){STRNG_replace_str(FromDate,"-11-","-Nov-",&FromDate);}
	if(strstr(FromDate,"-12-")!=NULL){STRNG_replace_str(FromDate,"-12-","-Dec-",&FromDate);}
	
	if(strstr(ToDate,"-01-")!=NULL){STRNG_replace_str(ToDate,"-01-","-Jan-",&ToDate);}
	if(strstr(ToDate,"-02-")!=NULL){STRNG_replace_str(ToDate,"-02-","-Feb-",&ToDate);}
	if(strstr(ToDate,"-03-")!=NULL){STRNG_replace_str(ToDate,"-03-","-Mar-",&ToDate);}
	if(strstr(ToDate,"-04-")!=NULL){STRNG_replace_str(ToDate,"-04-","-Apr-",&ToDate);}
	if(strstr(ToDate,"-05-")!=NULL){STRNG_replace_str(ToDate,"-05-","-May-",&ToDate);}
	if(strstr(ToDate,"-06-")!=NULL){STRNG_replace_str(ToDate,"-06-","-Jun-",&ToDate);}
	if(strstr(ToDate,"-07-")!=NULL){STRNG_replace_str(ToDate,"-07-","-Jul-",&ToDate);}
	if(strstr(ToDate,"-08-")!=NULL){STRNG_replace_str(ToDate,"-08-","-Aug-",&ToDate);}
	if(strstr(ToDate,"-09-")!=NULL){STRNG_replace_str(ToDate,"-09-","-Sep-",&ToDate);}
	if(strstr(ToDate,"-10-")!=NULL){STRNG_replace_str(ToDate,"-10-","-Oct-",&ToDate);}
	if(strstr(ToDate,"-11-")!=NULL){STRNG_replace_str(ToDate,"-11-","-Nov-",&ToDate);}
	if(strstr(ToDate,"-12-")!=NULL){STRNG_replace_str(ToDate,"-12-","-Dec-",&ToDate);}
	
	printf("\n P2:....Inside DML Part details.From Date:[%s]\n",FromDate);fflush(stdout);
	printf("\n P2:....Inside DML Part details.To Date:[%s]\n",ToDate);fflush(stdout);
    char    **DML_qry_values2     =  (char **) MEM_alloc(50 * sizeof(char *));
	//char *DML_qry_entry[3]     = {"Type","Released After","Released Before"};
	char *DML_qry_entry[3]     = {"Released_After","Released_Before","Release_Status"};
	//char *DML_qry_values2[3]   = {"ERC DML Revision",FromDate,ToDate};

	DML_qry_values2[0] = FromDate;
	DML_qry_values2[1] = ToDate;
	DML_qry_values2[2] = "*ERC Released*";

	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	DMLtrg = (char*) malloc(5000);
	sPart_type=(char *)MEM_alloc(1000);
	//if(QRY_find2("General...", &DMLqryTag));
	if(QRY_find2("ERC_DML_PLMSAP", &DMLqryTag));
	if (DMLqryTag)
	{
		printf("\n P10::Found Query General... \n");fflush(stdout);
	}
	else
	{
		printf("\n P11::Not Found Query General... \n");fflush(stdout);
	}
	time_t timer;
	char buffer[50];
	struct tm* tm_info;

	time(&timer);
	tm_info = localtime(&timer);

	strftime(buffer, 50, "%Y-%m-%d %H:%M:%S", tm_info);

	printf ("Current Date and Time : %s\n", buffer);

	DMLoutput = fopen(Path, "w+");
	printf ("11");
	fprintf(DMLoutput,"Date and Time -> %s",buffer);
	printf ("12");
	
	fprintf(DMLoutput,"\n DML Number,Release Type,DR Status,Release Status,APL DML,STD DML,MBOM DML");
	printf ("13");
	if (DMLoutput == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
	{
printf("File opened successfully.\n");
if(QRY_execute(DMLqryTag, 3, DML_qry_entry, DML_qry_values2, &DML_rsltCount, &DML_CntrlObjectTag));
printf ("14");
printf(" \n P12::DML_rsltCount :%d:", DML_rsltCount); fflush(stdout);
if(DML_rsltCount > 0)
	{
		for (iDML=0; iDML<DML_rsltCount;iDML++ )
		{
			DMLRel_status=NULL;
			DMLStatus=NULL;
			sDMLManager=NULL;
			DMLDescr=NULL;
			DMLDesc=NULL;
			sDMLRlsType=NULL;
			DMLID=NULL;
			DMLRlsType=NULL;
			APLFlag = 0;
		    STDFlag = 0;
			 MBOMFlag = 0;

			DMLtag			= NULLTAG;
			DMLtag= DML_CntrlObjectTag[iDML];
			if(AOM_UIF_ask_value(DMLtag,"t5_rlstype",&sDMLRlsType));
			if(AOM_UIF_ask_value(DMLtag,"item_id",&DMLID));
			if(AOM_ask_value_string(DMLtag,"t5_rlstype",&DMLRlsType));
			if(AOM_UIF_ask_value (DMLtag, "release_status_list", &DMLRel_status)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (DMLtag, "t5_cDRstatus", &DMLStatus)!=ITK_ok)PrintErrorStack();
			printf("\n DMLID = [%d::%s] AOM_UIF_ask_value=  [%s] AOM_ask_value_string = [%s]",iDML,DMLID, sDMLRlsType,DMLRlsType);fflush(stdout);
			printf("\n DMLRel_status [%s], DMLDRStatus [%s]", DMLRel_status,DMLStatus);fflush(stdout);

			//if((tc_strcmp(DMLRlsType,"Veh")==0) || (tc_strcmp(DMLRlsType,"TODR")==0))
			//{
			if(GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag));
			if (relatnType_tag!=NULLTAG)
			{
				if(GRM_list_secondary_objects_only( DMLtag, relatnType_tag, &noOfTask, &task_obj_tag));

			for (iDML1=0; iDML1<noOfTask;iDML1++ )
			{
					TaskRevTag = task_obj_tag[iDML1];
					if(AOM_ask_value_string(TaskRevTag,"item_id",&taskitemid));
					printf("\n ATask ID =  [%s]\n\t",taskitemid);fflush(stdout);
					if((tc_strstr(taskitemid,"APL") != NULL))
					{
						printf("\n Innside APL loop [%s]\n\t", taskitemid);fflush(stdout);
						APLFlag ++;
					}
					if ((tc_strstr(taskitemid,"STD") != NULL))
					{
						printf("\n Innside STD loop [%s]\n\t", taskitemid);fflush(stdout);
						STDFlag ++;
					}
					if ((tc_strstr(taskitemid,"MBOM") != NULL))
					{
						printf("\n Innside MBOM loop [%s]\n\t", taskitemid);fflush(stdout);
						MBOMFlag ++;
					}
			}
			
					fprintf(DMLoutput,"\n%s,%s,%s,",DMLID,sDMLRlsType,DMLStatus);
					if (DMLRel_status != NULL)
					{
						if (tc_strstr(DMLRel_status, "ERC Released") != NULL)
						{
							fprintf(DMLoutput,"ERC Released,");
						}
						else
						{
							fprintf(DMLoutput,"NOT ERC Released,");
						}
					}
					else
					{
						fprintf(DMLoutput,"NO STATUS,");
					}
					if (APLFlag >0)
					{
						fprintf(DMLoutput,"APL DML Available,");
					}
					else
					{
						fprintf(DMLoutput,"NOT Available,");
					}
					if (STDFlag >0)
					{
						fprintf(DMLoutput,"STD DML Available,");
					}
					else
					{
						fprintf(DMLoutput,"NOT Available,");
					}
					if (MBOMFlag >0)
					{
						fprintf(DMLoutput,"MBOM DML Available,");
					}
					else
					{
						fprintf(DMLoutput,"NOT Available,");
					}
					
			}
		}
    }
}
printf("\n creating FILE");fflush(stdout);
	ITK_CALL(AE_find_datasettype2("MSExcel",&msExcelType));
	if(msExcelType!=NULLTAG)
	{
		printf("\nExcel type created successfully");fflush(stdout);
	}

	ITK_CALL(AE_create_dataset_with_id(msExcelType,DMLoutputFile,DMLoutputFile,"","",&ExcelDataset));
	if(ExcelDataset!=NULLTAG)
	{
		printf("\nDataset of Excel type created successfully");fflush(stdout);
	}
	else 
	{
		printf("\nDataset of Excel type not created successfully");fflush(stdout);
	}
	ITK_CALL(AOM_save_without_extensions(ExcelDataset));
	if(ExcelDataset!=NULLTAG){printf("\nDataset saved successfully");fflush(stdout);}
	ITK_CALL(AE_find_dataset2(DMLoutputFile,&ExlLatestDat_t));	
	ITK_CALL(AOM_refresh(ExlLatestDat_t,1));
	printf("\n Dataset File name=%s\n",DMLoutputFile);
	ITK_CALL(AE_import_named_ref(ExlLatestDat_t,"excel",Path,NULL,SS_BINARY));
	ITK_CALL(AOM_save_without_extensions(ExlLatestDat_t));
	ITK_CALL(AOM_refresh(ExlLatestDat_t,0));

	char* emailCC = NULL;
	char* eMailTo = NULL;
	char  *emailBody	  = NULL;
	char  *emailSub	  = NULL;
	char* buff			= NULL;
	buff=(char *) MEM_alloc(500 * sizeof(char *));
						
	eMailTo=(char *) MEM_alloc(100 * sizeof(char *));
	emailCC=(char *) MEM_alloc(100 * sizeof(char *));
	emailBody = (char *) MEM_alloc( 100 * sizeof(char) );
	emailSub = (char *) MEM_alloc( 100 * sizeof(char) );
	tc_strcpy(eMailTo,"as925914.ttl@tatamotors.com");
	tc_strcat(eMailTo,",");
	tc_strcat(eMailTo,"sg923352.ttl@tatamotors.com");
	tc_strcat(eMailTo,",");
	tc_strcat(eMailTo,"r0000992.ttl@tatamotors.com");
	tc_strcat(eMailTo,",");
	tc_strcat(eMailTo,"ra922216.ttl@tatamotors.com");
	tc_strcat(eMailTo,",");
	tc_strcat(eMailTo,"mangeshp.ttl@tatamotors.com");
	tc_strcat(eMailTo,",");
	tc_strcat(eMailTo,"at927464.ttl@tatamotors.com");

	tc_strcpy(emailCC,"mohant.ttl@tatamotors.com");

	//emailBody = (char *) MEM_alloc( 100 * sizeof(char) );
	
	/* Build the body as a single literal, then allocate exact length */
	const char *bodyText =
	"Dear Team,\r\n\n"
	"Please save attached Excel sheet in Local Drive and apply filter on Release Type Column "
	"and check which is pending in Workflow (Check Symbol only).\r\n\n"
	"Below are the Release Type:\r\n\n"
	"Colour Part Release\r\n"
	"DFM-A Module Release\r\n"
	"ECU Part Release\r\n"
	"Gate Maturation\r\n"
	"Info Fitment Drawing Release\r\n"
	"Module With Spare kit Release\r\n"
	"Kit and Spare part Release\r\n"
	"Module Release\r\n"
	"Standard Part Release\r\n"
	"Update Variant Formula\r\n"
	"Vehicle Offer Drawing\r\n"
	"Vehicle Release\r\n\n"
	"Thanks & Regards\r\n"
	"TCUA\r\n";

	emailBody= (char *)MEM_alloc(strlen(bodyText) + 1);
	tc_strcpy(emailBody, bodyText);



	//tc_strcpy(emailBody,"Dear Team, \n Please save atatched Excel sheet in Local Drive and apply filter on Release Type Column and check which is pending in Workflow(Check Symbol only) \n Below are the Release Type \n Colour Part Release \n DFM-A Module Release \n ECU Part Release \n Gate Maturation \n Info Fitment Draeing Release \n Kit and Spare part Release \n Module Release \n Standard Part Release \n Update Varient Formula \n Vehicle offer Drawing \n Verhicle Release");
	tc_strcpy(emailSub,"APL DML Check");

	//mail send Command
	sprintf(buff,"( echo \"%s\"   )  | nail  -s \"%s\" -a \"%s\" -c \"%s\"  \"%s\" ",emailBody,emailSub,Path,emailCC,eMailTo);
	printf("\n buff [%s]!!\n",buff);fflush(stdout);
	system(buff);


	printf("\nMemory releaseing.....");fflush(stdout);
	if(dmlNumber !=NULL)
	MEM_free(dmlNumber);
	if(sDMLBU !=NULL)
	MEM_free(sDMLBU);
	if(DMLRlsType !=NULL)
	MEM_free(DMLRlsType);
	if(person_name !=NULL)
	MEM_free(person_name);
	if(Dml_DR !=NULL)
	MEM_free(Dml_DR);
	if(DMLReason !=NULL)
	MEM_free(DMLReason);
	if(DMLVertical !=NULL)
	MEM_free(DMLVertical);
	//DMLReason
	if(DMLManager !=NULL)
	MEM_free(DMLManager);
	if(ProjectID !=NULL)
	MEM_free(ProjectID);

	fclose(DMLoutput);
	printf("\n DML details collection end........");fflush(stdout);
	return ifail;

}




