package com.java.mail;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.*;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.search.AndTerm;
import javax.mail.search.ComparisonTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.ReceivedDateTerm;
import javax.mail.search.SearchTerm;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.mail.internet.InternetAddress;

import javax.mail.BodyPart;
import javax.mail.Multipart;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeBodyPart;
import org.jsoup.Jsoup;

public class DcrMailReader 
{
	private static String executeCommand(String command) {

	System.out.println(" Before Command:"+command);
	StringBuffer output = new StringBuffer();

	Process p;
	try 
	{
		p = Runtime.getRuntime().exec(command);
		p.waitFor();
		BufferedReader reader =	new BufferedReader(new InputStreamReader(p.getInputStream()));

		String line = "";
		while ((line = reader.readLine())!= null) {
			output.append(line + "\n");
		}

	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	}

   System.out.println(" After Command:"+command);
   System.out.println(" After Command output.toString():"+output.toString());
	return output.toString();

	}


	public static void main(String args[]) throws Exception 
	{

		// mail server info
		String host = "smtp.office365.com";
		//String user = "FirReqReview@tatamotors.com";
		String user = "FirReqReview.CVODT@tatamotors.com";
		String password = "CVBUODT@2016";

		//String user = "dnn911483@myttl.tatatechnologies.com";
		
		String emailSubject="-Decision-for-DCR-Review:"; 
	
		Properties props = new Properties();
		props.setProperty("mail.smtp.host",host);
		//props.setProperty("mail.smtp.port","443");
		props.setProperty("mail.store.protocol", "imaps");

        props.setProperty("mail.smtp.socketFactory.fallback", "false");
        props.setProperty("mail.smtp.port", "443");
        props.setProperty("mail.smtp.socketFactory.port", "443");
        props.setProperty("mail.smtps.auth", "true");
		try 
		{
			Session session = Session.getInstance(props, null);
			Store store = session.getStore();

			System.out.println("\nDADA... username:"+user+"\n: pwd: "+password+"\n: host: "+host);
			store.connect(host, user, password);
			Folder inbox = store.getFolder("inbox");
			inbox.open(Folder.READ_WRITE);

			// search for all "unseen" messages
			Flags seen = new Flags(Flags.Flag.SEEN);
			FlagTerm unseenFlagTerm = new FlagTerm(seen, false);
			SimpleDateFormat dateFormat = new SimpleDateFormat( "MM/dd/yyyy" );
			Date date = new Date();
			// System.out.println(dateFormat.format(date)); //2016/11/16 12:08:43
			java.util.Date dDate = dateFormat.parse(dateFormat.format(date));//df1.parse(dt);
			// SearchTerm olderThan = new ReceivedDateTerm(ComparisonTerm.LT, someFutureDate);
			SearchTerm newerThan = new ReceivedDateTerm(ComparisonTerm.GT, dDate);
			SearchTerm andTerm = new AndTerm(unseenFlagTerm, newerThan);
			// inbox.search(andTerm)

			Message messages[] = inbox.search(andTerm);//unseenFlagTerm);

			if (messages.length == 0) System.out.println("No messages found.");

			for (int i =  messages.length-1; i >=0; i--) 
			{
			
				String subject= messages[i].getSubject();

				System.out.println("SUB==="+subject);

				if(subject==null)
				{
					System.out.println("NULL SUB");
					messages[i].setFlag(Flag.SEEN, true);
					continue;
				}

				if(subject.contains(emailSubject))
				{
					System.out.println("Dada...Inside -Decision-for-DCR-Review subject : ");

					String from=((InternetAddress)messages[i].getFrom()[0]).getAddress();	
					messages[i].setFlag(Flag.SEEN, true);
					System.out.println("Message " + (i + 1));
					System.out.println("From : " + ((InternetAddress)messages[i].getFrom()[0]).getAddress());
					//System.out.println("From : " + messages[i].getFrom()[0]);
					System.out.println("Subject : " + messages[i].getSubject());

					String command="";

					StringTokenizer stringTokenizer=new StringTokenizer(subject," ");
					stringTokenizer.nextElement();
					String objno=stringTokenizer.nextElement().toString();
					String descion=stringTokenizer.nextElement().toString();

					StringTokenizer stringTokenizer1=new StringTokenizer(subject,"-");
					stringTokenizer1.nextElement();
					String assignment=stringTokenizer1.nextElement().toString();

					//String body = messages[i].getContent().toString();
					String body="";
					//System.out.println("body ::: "+body);

					String contentType = messages[i].getContentType();

					System.out.println("contentType ::: "+contentType);

//					String result = "";	
//					result = result + "\n" + Jsoup.parse(body).text();				
//					System.out.println("result: " + result);

					if (contentType.contains("multipart")) 
					{
						Multipart multiPart = (Multipart) messages[i].getContent();
						int numberOfParts = multiPart.getCount();

						for (int partCount = 0; partCount < numberOfParts; partCount++) 
						{
							MimeBodyPart part = (MimeBodyPart) multiPart.getBodyPart(partCount);
							body = part.getContent().toString();
							
						}

					}
					else if (contentType.contains("text/plain") || contentType.contains("text/html")) 
					{
						//System.out.println("contentType 2 " + contentType);
						Object content = messages[i].getContent();
						if (content != null)
						{
							body = content.toString();
						}
					}
					//System.out.println("body ::: "+body);
					String result = "";	
					result = result + "\n" + Jsoup.parse(body).text();				
					System.out.println("result: " + result);


					StringTokenizer s1=new StringTokenizer(result,"~");

					if(s1.hasMoreTokens())
					{
						String replaceStringP=s1.nextElement().toString();

						System.out.println("replaceStringP:"+replaceStringP);
						if(s1.hasMoreTokens())
						{
							String replaceStringT=s1.nextElement().toString();
							System.out.println("replaceStringT:"+replaceStringT);
							String replaceString="\""+replaceStringT+"\"";
						
							String s3=replaceString.replace(" ","^");
							String resultT=s3.replace("\n",";");
							
							System.out.println("resultT: " + resultT);
							command="/user/uaprod/TC_ROOT12/bin/tml_tools/ApproveDcrFromMail.sh"+" "+assignment+" "+objno+" "+descion+" "+from+" "+resultT;

							System.out.println("in Java Command::"+command);
							executeCommand(command);	//messages[i].getSubject());
							System.out.println("Sent Date : " + messages[i].getSentDate());
							System.out.println();
						}
						else
						{
							String s2 = "";				
							if(descion.equals("APPROVE"))
							{
								s2 = "Approved by mail.";
							}
							else if(descion.equals("REJECT"))
							{
								s2 = "Rjected by mail.";
							}

							String replaceString = "\""+s2+"\"";;
							String resultT=replaceString.replace(" ","^");
							System.out.println("resultT in else part: " + resultT);

							command="/user/uaprod/TC_ROOT12/bin/tml_tools/ApproveDcrFromMail.sh"+" "+assignment+" "+objno+" "+descion+" "+from+" "+resultT;
							System.out.println("in Java Command::"+command);
							executeCommand(command);	//messages[i].getSubject());
							System.out.println("Sent Date : " + messages[i].getSentDate());
							System.out.println();
						}
					}
					else
					{
						String s2 = "";				
						if(descion.equals("APPROVE"))
						{
							s2 = "Approved by mail.";
						}
						else if(descion.equals("REJECT"))
						{
							s2 = "Rjected by mail.";
						}

						String replaceString = "\""+s2+"\"";;
						String resultT=replaceString.replace(" ","^");
						System.out.println("resultT in else part: " + resultT);

						command="/user/uaprod/TC_ROOT12/bin/tml_tools/ApproveDcrFromMail.sh"+" "+" "+assignment+" "+objno+" "+descion+" "+from+" "+resultT;
						System.out.println("in Java Command::"+command);
						executeCommand(command);	//messages[i].getSubject());
						System.out.println("Sent Date : " + messages[i].getSentDate());
						System.out.println();
					}
				}
				else
				{
					System.out.println("SUB==="+subject+": NOT a PLM Message");
					messages[i].setFlag(Flag.SEEN, true);
				}
			}
			inbox.close(true);
			store.close();
			System.exit(0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	  
}


