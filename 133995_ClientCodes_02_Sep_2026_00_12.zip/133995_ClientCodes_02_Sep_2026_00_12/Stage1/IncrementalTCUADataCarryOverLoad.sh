. /user/aplstdgrp/.bash_profile
echo "Connecting uaprod...."
now="$(date +'%d_%m_%Y')"
echo $1
pwd
cd /user/aplstdgrp/Deepti/TCE_TCUA_CarryOver_Stamp/IncrementalDataStamp
mkdir $now
pwd
cd /user/aplstdgrp/Deepti/TCE_TCUA_CarryOver_Stamp/IncrementalDataStamp/$now

../tm_TCE_TCUA_CarryOver_PARTStamp -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba > PartListInfo.log

wait
if [ $? != 0 ]
        then
                echo "Problem in Part Query.."
                exit 1
        else
                echo "Part Query Executed Successfully ....."					
					
fi
size=$(wc -c <Part_List.txt)
echo $size
if [  $size > 0 ]
	then 
		echo "file has something"
		cd /proj/PLMLoading/UAFiles/APL_STDSI_TCE_TCUA_Data_Mig/IncrementalDataUpload_APL_CarryOverPart/
		pwd
		cp /user/aplstdgrp/Deepti/TCE_TCUA_CarryOver_Stamp/IncrementalDataStamp/$now/*.txt .
		sort Part_List.txt | uniq  | tee output.txt
		mv output.txt Part_List_$now.txt
	else 
		echo "file is empty"
fi

