
// ./DRStatus -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -part=5445T5A0294002 -rev=NR -seq=1

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h> 
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h> 
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include "soapH.h"
#include "DRStatus.nsmap"

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

int ITK_user_main(int argc, char *argv[])
{

	return soap_serve(soap_new()); /* call the request dispatcher */

};

int ns__DRStatus(struct soap* soap,char *part,char *rev,char *seq,char **Response)
{

	int status = ITK_ok;
	char *s;

	int count = 0;
	int i  = 0;
	int one_entries = 3;

	char*  PartItemId		= NULL;
	char*  PRev_1		= NULL;
	char*  PRev		= NULL;
	char*  PSeq		= NULL;
	char*  PartSeq		= NULL;
	char*  rev1             =NULL;
	char*  PartDRStatus		= NULL;
	char*  RevName		    = NULL;
	char*  Parttype		    = NULL;
	char*  LifCycleState	= NULL;
	char*  CARMakeBuy		= NULL;
	char*  AHDMakeBuy		= NULL;
	char*  Uom				= NULL;
	char*  Objectid			= NULL;
	char*  Dml_type			= NULL;
	char*  CreationDate		= NULL;
	char*  RelDate			= NULL;
	char** qry_values		= NULL;

	tag_t   query			 = NULLTAG;
	tag_t	parttag			 = NULLTAG;
	tag_t	prtidTag		 = NULL;
	tag_t	prtlatRevTag	 = NULLTAG;
	tag_t*  list_of_parts	 = NULLTAG;

	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/dml.txt", "a", stdout);


	char    *qry_entry[3]  = {"Revision","ID"};
	qry_values= (char **) MEM_alloc(100 * sizeof(char *));

	//part   = ITK_ask_cli_argument("-p=");
	//rev	 = ITK_ask_cli_argument("-r=");
	//seq	 = ITK_ask_cli_argument("-s=");

	rev1 = tc_strcat(rev, "*");

	printf("\n part1, rev1, seq1 --> %s %s %s \n",part, rev1, seq);fflush(stdout);


	//*********For Auto Login***********//

    ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
    ITK_CALL(ITK_auto_login());
    ITK_set_bypass(true);
    ITK_CALL(ITK_set_journalling(TRUE));
    //printf("\n Line  ====%s \n", line);fflush(stdout);
    if (status == 0 )
    {
            printf("\n Auto login to Teamcenter successful \n");fflush(stdout);
    }
    else
    {
      printf("\n Error code:%d",status);fflush(stdout);
      EMH_ask_error_text(status,&s);
      printf("\n Error message:%s",s);fflush(stdout);
    }

	//*******Ended*******//


	//*******************************Programe Start***************************************//


	printf("\n ******* Start hear ***** %s \n");fflush(stdout);

	
	if(QRY_find("DesignRevision Sequence", &query));
	{

		if(query)
		{

			printf("\n Query Found \n");fflush(stdout);

			printf("\n part, rev, seq --> %s %s %s \n",part, rev1, seq);fflush(stdout);

			qry_values[0] = (char*)MEM_alloc(tc_strlen(rev1));
			tc_strcpy(qry_values[0], rev1);

			qry_values[1] = (char*)MEM_alloc(tc_strlen(part));
			tc_strcpy(qry_values[1], part);

			ITK_CALL(QRY_execute(query, 2, qry_entry, qry_values, &count, &list_of_parts));
			printf("\n count --> %d \n",count);fflush(stdout);

			if ( count > 0 )
			{
			
				for (i = 0; i < count; i++)
				{

					parttag = list_of_parts[i];

					ITK_CALL( AOM_UIF_ask_value(parttag,"item_id",&PartItemId));
					printf("\n\n PartItemId --> %s ",PartItemId);fflush(stdout);

					ITK_CALL(AOM_UIF_ask_value(parttag, "item_revision_id", &PRev_1));
					printf("\n PRev_1 : %s",PRev_1);fflush(stdout);

					PRev=tc_strtok(PRev_1, ";");
					printf("\n PRev : [%s]",PRev);

					PSeq=tc_strtok(NULL, "");
					printf("\n PSeq : %s",PSeq);fflush(stdout);


					if ((tc_strcmp(PSeq,seq) == 0))
					{

						ITK_CALL( AOM_ask_value_string(parttag,"t5_PartStatus",&PartDRStatus));
						printf("\n PartDRStatus --> %s \n",PartDRStatus);fflush(stdout);

						if ((tc_strcmp(PartDRStatus,"") !=0))
						{
							*Response = (char *) malloc( (50) * sizeof(char));
							 tc_strcpy(*Response,PartDRStatus);
							 
						}
						else
						{
							*Response = (char *) malloc( (50) * sizeof(char));
						     tc_strcpy(*Response,"DR Status Not Found");
							 printf("\n DR Status Not Found \n");fflush(stdout);
							 
						}
						
					}
					
				}

			}
			else
			{
				*Response = (char *) malloc( (50) * sizeof(char));
			     tc_strcpy(*Response,"Part Not Found");
				 printf("\n Part Not Found \n");fflush(stdout);
			}


		}

	}
	
	printf("\n\n\n Query search results completed \n\n");fflush(stdout);

	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	//ITK_CALL(ITK_exit_module(true));
	return SOAP_OK;


CLEANUP:
	    
		return SOAP_OK;

EXIT:
		return SOAP_OK;


}


































	
