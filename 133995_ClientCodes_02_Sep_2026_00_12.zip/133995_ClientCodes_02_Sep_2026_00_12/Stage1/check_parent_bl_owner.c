/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: check_parent_bl_owner.c
**
** Functions:- 	This utility queries item(Group_ID) into teamcenter and gets it's parent bomline(where used) and check for owning group
				of latest revision of that parent bomline. if owner found as loader then print it's information into the file.
				(project_code is command line input)
** 
**
**	Date							Author								Modification
**	19-April-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** check_parent_bl_owner -u=<username> -p=<password> -g=<group> -prj_code=<project_code>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <ps/ps.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


FILE		*output 			= NULL;

char		*sep				= ",";
int			ifail 				= ITK_ok;

int read_value_from_file(char*);
int get_parts(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<Filename> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* prj_code					= NULL;
	char			* Filename					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.csv",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = read_value_from_file(Filename);
		CHECK_FAIL;

	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{	
	char 		*itemid					= NULL;
	char 		temp[200];
	
	FILE		* fp 					= NULL;
	
	fp = fopen(Filename, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));
		
			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "^");
				printf("\nInput Item_id:%s\n",itemid);
				
				ifail = get_parts(itemid);
			}
			printf("\n***************************************\n");
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       get_parts
    Description:    This function takes the item_tag and object_id as input and writes 
					item's information into a file.
********************************************************************************************/
int get_parts(char* item_id)
{
	int				i 							= 0;
	int				n_parent 					= 0;
	int				*levels	 					= 0;
	
	tag_t			parent						= NULLTAG;
	tag_t			item_tag					= NULLTAG;
	tag_t			latest_rev					= NULLTAG;
	tag_t			parent_latest_rev			= NULLTAG;
	tag_t			*parent_rev_tag				= NULL;
	
	char 			*part_type					= NULL;
	char 			*owning_user				= NULL;
	char 			*parent_item_id				= NULL;
	char 			*parent_rev_id				= NULL;
	char 			*bl_object_type				= NULL;
	char 			*sec_object_type			= NULL;
	
	char 			*owner						= "loader (loader)";
	char			*type						= "Module";
	char			*Test						= (char*)MEM_alloc(sizeof(char) * 50);
	
	ifail = ITEM_find_item (item_id, &item_tag);
	ifail = ITEM_ask_latest_rev (item_tag, &latest_rev);
			
	ifail = PS_where_used_all (latest_rev, 1, &n_parent, &levels, &parent_rev_tag);
	
	for(i=0; i<n_parent; i++)
	{
		ifail = ITEM_ask_item_of_rev (parent_rev_tag[i], &parent);
		ifail = ITEM_ask_latest_rev (parent, &parent_latest_rev);
		
		ifail = AOM_UIF_ask_value (parent_latest_rev, "item_id", &parent_item_id);
		printf("\nparent item_id:%s", parent_item_id);
	
		ifail = AOM_UIF_ask_value (parent_latest_rev, "item_revision_id", &parent_rev_id);
		printf("\nparent latest rev_id:%s", parent_rev_id);
	
		ifail = AOM_UIF_ask_value (parent_latest_rev, "t5_PartType", &part_type);
		printf("\nparent latest rev. part_type:%s", part_type);
		
		if(tc_strcmp(part_type, type) != 0)
		{
			ifail = AOM_UIF_ask_value (parent_latest_rev, "owning_user", &owning_user);
			printf("\nparent latest rev. owning_user:%s", owning_user);
			if(tc_strcmp(owning_user, owner) == 0)
			{
				tc_strcpy(Test, "");
				tc_strcpy(Test, item_id);
				tc_strcat(Test, sep);
				tc_strcat(Test, parent_item_id);
				tc_strcat(Test,sep);
				tc_strcat(Test,parent_rev_id);
				tc_strcat(Test,sep);
				tc_strcat(Test,part_type);
				tc_strcat(Test,sep);
				tc_strcat(Test,owning_user);
					
				fprintf(output,"%s\n",Test);
			}
		}
	}
	MEM_free(levels);
	MEM_free(parent_rev_tag);
						
	return ifail;
}
