cd /home/cmitest/
./.bash_profile

echo "Shell file is called"

user="aplplanner"
pass="XYT1ESA1"
group="APL_Support_Group"

echo $1
echo $2
echo $3

cd /home/cmitest/shells/APL/mppstamping/plBOP_stamping
./plBOP_stamping -u=$user -p=$pass -g=$group -t="$1" -r=$2 -s=$3

echo "Shell calling completed..."