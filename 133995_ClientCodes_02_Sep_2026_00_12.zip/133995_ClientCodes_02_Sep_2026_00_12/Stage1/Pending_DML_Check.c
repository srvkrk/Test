#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#include <pom/enq/enq.h>
#include <time.h>
#define PLM_error6 (EMH_USER_error_base+26)
#define ITK_err (EMH_USER_error_base + 2)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
;
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}
void removeNewLineChar(char *ptr)
{
    while((ptr != NULL) && (*ptr != '\n'))
    {
        ++ptr;
    }
    *ptr = '\0';
}
FILE		*VCoutput 			= NULL;
int			ifail 				= ITK_ok;
char		*sep				= "^";
int tm_Part_to_DML_Details(char* filename);

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"GateMaturationUpd -u=<username> -pf=<password file path> -g=<!-- <group> --> -file=<!-- <file_name> -->\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//printf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

//Pending_DML_Check Start
int Pending_DML_Check(char* FromDate,char* ToDate)
{

	tag_t     qry_tg            = NULLTAG;
	tag_t     Dml_tag        = NULLTAG;
	tag_t     DmlRev         = NULLTAG;
	//tag_t     Revtag           = NULLTAG;
	tag_t     Obj                 = NULLTAG;
	tag_t *  DmlObj          = NULLTAG;

	char *   DmlNo            = NULL;
	char *   Revtag            = NULL;
	char *   Owner_tag    = NULL;
	char *   Relstslist         = NULL;
	char *entry = (char *) MEM_alloc(30 * sizeof(char *));
	char ** Value = (char **) MEM_alloc(50 * sizeof(char *));

	int          Count              = 0;
	int          i                        = 0;

	char env_subject[400] = {'\0'};
	char env_body[400]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	
	printf("\nInside function  Pending_DML_Check ");fflush(stdout);
    if(QRY_find("ERC DML Revision_2", &qry_tg)); //MAIN CODE
	//if(QRY_find2("UserFind", &qry_tg));
	if(qry_tg != NULLTAG)
	{
			
		printf("\n Inside Qry Tag found");
		//entry[0] = "t5_rlstype";
		//entry[1] = "ID";
		//entry[2] = "Date Released";
		//entry[3] = "Date Created";
		//entry[4] = "Name";
		char *entry[5]		 = {"t5_rlstype","ID","Date Released","Date Created","Name"}; //"Release Type"
		Value[0] = "*";
		Value[1] = "*";
		Value[2] = ToDate;
		Value[3] = FromDate;
		Value[4] = "*";

		if(QRY_execute(qry_tg, 5, entry, Value, &Count, &DmlObj));
		printf("\n:Count is: [%d]\n",Count);fflush(stdout);

		for (i=0;i<Count;i++)
		{
			Obj=DmlObj[i];
			printf("******************DML Recived**********************\n");fflush(stdout);

			//ifail = ITEM_find_item(Obj,&Dml_tag);    //find the item

			//ifail = ITEM_ask_latest_rev(Dml_tag,&DmlRev); //find latest rev

			if (Obj != NULLTAG)
			{

			 ifail = AOM_UIF_ask_value(Obj, "release_status_list" ,&Relstslist);
			 //printf("\nRelstslist>>>>>>>> : [%s]\n",Relstslist); fflush(stdout);
			 

			 //char * ownerid = NULL;

			 char *ownerid = (char *) MEM_alloc(sizeof(char)* 90);
			char * ownername =NULL;
		    char * ownerUserid =NULL;

				if (tc_strstr(Relstslist,"In Designer Working")!=NULL)
				{
				ifail = AOM_UIF_ask_value(Obj, "item_id" ,&Revtag);
				printf("\nDML Rev no is>>>>>>>> : [%s]\n",Revtag); fflush(stdout);

				ifail = AOM_UIF_ask_value(Obj, "owning_user" ,&Owner_tag);
				printf("\nDML_Owner_ is>>>>>>>> : [%s]\n",Owner_tag); fflush(stdout);
			   
			    ownername = tc_strtok(Owner_tag, "(");// DFA
			    ownerUserid = tc_strtok(NULL, ")");		// 1234567
			  	
				printf("\n ownername is>>>>>>>>.......................................... : [%s]\n",ownername); fflush(stdout);
			 	printf("\nownerUserid_ is>>>>>>>>.......................................... : [%s]\n",ownerUserid); fflush(stdout);

				

				tc_strcpy(ownerid,"");
				tc_strcpy(ownerid,ownerUserid);
				tc_strcat(ownerid,"@tatamotors.com");

			    printf("\nowner Email ID_ is>>>>>>>> : [%s]\n",ownerid); fflush(stdout);

					tc_strcpy(env_subject,"SUCCESS: MAIL FROM UAPROD DML IS NOT RELEASED");
					tc_strcpy(env_body,"Dear All, \n\n ");
					tc_strcat(env_body,"\n\n                    DML is pending at Design reviewer");
					tc_strcat(env_body,"\n\n                    DMl number");
					tc_strcat(env_body," : ");
					tc_strcat(env_body,Revtag);
					tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
					tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. for any issues, Raise TMS on PLM. ");

			ITK_CALL(MAIL_create_envelope(env_subject, env_body, &envelope));
			if(envelope != NULLTAG)
			{
				ITK_CALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"ownerid"));
				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"aj922213.ttl@tatamotors.com"));
				ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
				printf("\n Count Envelop --------> %d\n",countenvelop);fflush(stdout);
				ITK_CALL(MAIL_send_envelope(envelope));
				printf("\n Mail Send Successfully...");fflush(stdout);
			}
			else
			{
				printf("\n Sorry! Unable to Send Email\n");fflush(stdout);
			}

				}
			}

		}
	}
	else
	{
		printf("\n************************Qury not found*******************");
	}

}
int ITK_user_main(int argc, char *argv[])
{
	char			* FromDate				 = NULL;
	char			* ToDate				     = NULL;
	char			* password		         = NULL;
	char			* group				         = NULL;
	char			* user				         = NULL;
	char			* pass				         = NULL;
	

	FromDate = ITK_ask_cli_argument("-From=");
	ToDate = ITK_ask_cli_argument("-To=");
	//user = ITK_ask_cli_argument("-u=");
	//pass = ITK_ask_cli_argument("-p=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);


	ifail = ITK_auto_login();
	//fail = ITK_init_module(userid, password, group);
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);

	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nhey Login Successfull.....!!\n");fflush(stdout);
		printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
	}
	printf("\nAfter Login Successfull.\n");fflush(stdout);
	//printf("\nOutput file name : %s",VCoutputFile);fflush(stdout);
// if (ifail != ITK_ok)
//{
//	printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
//	return -1;
//}
	//printf("\n dml no: [%s]\n",FromDate,ToDate);fflush(stdout);
	ifail=Pending_DML_Check(FromDate,ToDate);
	//CHECK_FAIL;

	printf("\n*********************");
	printf("\n****End of program****!!");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}






//char env_subject[300] = {'\0'};
//char env_body[300]= {'\0'};
//tag_t envelope	= NULLTAG;
//tag_t* recievers = NULLTAG;
//int countenvelop = 0;
//
//
//	tc_strcpy(env_subject,"SUCCESS: MAIL FROM UAPROD PART NO GENERATION REPORT");
//	tc_strcpy(env_body,"Dear All, \n\n ");
//	tc_strcat(env_body,"\n\n                    Part No Generated Successfully");
//	tc_strcat(env_body,"\n\n                    Part Number");
//	tc_strcat(env_body,": ");
//	tc_strcat(env_body,responseString);
//	tc_strcat(env_body," \n\n\n Regards,\n PLM Team \n\n\n");
//	tc_strcat(env_body," \n\n *Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM. ");
//
//				if(envelope != NULLTAG)
//			{
//				ITK_CALL(MAIL_initialize_envelope(envelope, env_subject, env_body));
//				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_to,"aj922213.ttl@tatamotors.com"));
//				ITK_CALL(MAIL_add_external_receiver(envelope, MAIL_send_cc,"sr922347.ttl@tatamotors.com"));
//				ITK_CALL(MAIL_list_envelope_receivers(envelope,&countenvelop,&recievers));
//				printf("\n Count Envelop --------> %d\n",countenvelop);fflush(stdout);
//				ITK_CALL(MAIL_send_envelope(envelope));
//				printf("\n Mail Send Successfully...");fflush(stdout);
//			}
//			else
//			{
//				printf("\n Sorry! Unable to Send Email\n");fflush(stdout);
//			}
