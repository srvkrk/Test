/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   A
*  Module		 :   CR client-code request Checked in TCUA environment
*  Code			 :   DesRevCheckedInFromDateToDate.c
*  Created on	 :   Jan 20th, 2018
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <ae/dataset.h>
#include <stdlib.h>
#include <time.h>
#include <tccore/libtccore_exports.h>
#define Debug TRUE
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

#define TCTYPE_name_size_c 100
char*  getMonth(char* cMonth)
{
	  char *m;
	  m = (char*) malloc(3);
      if(tc_strcmp(cMonth,"Jan")==0)
	  {
		  tc_strcpy(m,"01");		
	  }
	  else if(tc_strcmp(cMonth,"Feb")==0)
	  {
		tc_strcpy(m,"02");
	  }
	  else if(tc_strcmp(cMonth,"Mar")==0)
	  {
		tc_strcpy(m,"03");
	  }
	  else if(tc_strcmp(cMonth,"Apr")==0)
	  {
		tc_strcpy(m,"04");
	  }
	  else if(tc_strcmp(cMonth,"May")==0)
	  {
		tc_strcpy(m,"05");
	  }
	  else if(tc_strcmp(cMonth,"Jun")==0)
	  {
		tc_strcpy(m,"06");
	  }
	  else if(tc_strcmp(cMonth,"Jul")==0)
	  {
		tc_strcpy(m,"07");
	  }
	  else if(tc_strcmp(cMonth,"Aug")==0)
	  {
		tc_strcpy(m,"08");
	  }
	  else if(tc_strcmp(cMonth,"Sep")==0)
	  {
		tc_strcpy(m,"09");
	  }
	  else if(tc_strcmp(cMonth,"Oct")==0)
	  {
		tc_strcpy(m,"10");
	  }
	  else if(tc_strcmp(cMonth,"Nov")==0)
	  {
		tc_strcpy(m,"11");
	  }
	  else if(tc_strcmp(cMonth,"Dec")==0)
	  {
		tc_strcpy(m,"12");
	  }
return m;
}
extern int ITK_user_main(int argc, char ** argv )
{

    int status;

	int						result											= 0;
	int						count											= 0;
	int						iCounter1										= 0;
	int						i												= 0;
	char					*value											= NULL;
	char					*argstring1										= NULL;
	char					*argstring2										= NULL;
	char					*argstring3										= NULL;

	char					*user										= NULL;
	char					*pass										= NULL;
	char					*group										= NULL;
	char					*RefNo										= NULL;

	char					*itemId											= NULL;
	char					*revId											= NULL;
	char					*SeqID											= NULL;
	char					*revisionID										= NULL;
	char					*ItmSeqID										= NULL;
	char					 JTFile[256];
	char					*JTFileDesc										= NULL;
	char					*JTFileSeq										= NULL;
	char					*CreatedDate									= NULL;
	char					*ModifyDate										= NULL;
	char					*fullPath										= NULL;
	char					*VaultLocation									= NULL;
	char					*HostName										= NULL;
	char					*Owner											= NULL;
	char					*ProjectCode									= NULL;
	char					*PartType										= NULL;
	char					*InDatabase										= NULL;
	char					*Randomized										= NULL;
	char					*Superseded										= NULL;
	char					*Frozen											= NULL;
	char					*LifeCycleState									= NULL;
	char					*FileStatus										= NULL;
	char					*Externallymanaged								= NULL;
	char					*FileRegisteredBy								= NULL;
	char					*ShadowCopy										= NULL;
	char					*Categoryname									= NULL;
	char					*Sitename										= NULL;
	char					*WorkingFileName								= NULL;
	char					*WorkingpathFormat								= NULL;
	char					*BulkdataLocation								= NULL;

	char					*Bulkdata										= NULL;
	char					*DataBasename									= NULL;
	char					*PartSequence									= NULL;

	char					*Status											= NULL;
	char					*relation_input									= NULL;
	char					*file_type										= NULL;

	char					*error_Text										= NULL;
	tag_t					JTDataset										= NULLTAG;
	tag_t					relation_JTDataset								= NULLTAG;

//	char  					line[500]										= {'\0'};
	FILE					*input											= NULL;
	char					*relation_form									= NULL;
	tag_t					t_item											= NULLTAG;
	tag_t					revision										= NULLTAG;
	tag_t					*status_list									= NULLTAG;
	tag_t					release_status									= NULLTAG;
	tag_t					revstatus										= NULLTAG;
	int						x												= 0;
	int						ref_count = 0;
	tag_t					datasettype										= NULLTAG;
	tag_t					Newdataset										= NULLTAG;
	tag_t					tool											= NULLTAG;
	tag_t					filetag											= NULLTAG;
	char					**ref_list;
	char					pathbuff[1000];
    char					*creation_date									= NULL;
	char					*text											= NULL;
	tag_t					datasetAvl										= NULLTAG;
	IMF_file_t				fileDescriptor;
	AE_reference_type_t		tagRefType										= 1;
	int						iCountSecondary									= 0;
	tag_t					*secondaryObjects								= NULL;

	date_t				    test											= NULLDATE;
	date_t					test1										    = NULLDATE;
	char					*o											    = NULL;
	char					result1 [ 10000 ] ;
	char					 result2 [ 10000 ] ;
	char					*f												=NULL;

	char					*test11											=NULL;
	char					*test12											=NULL;
	char					*test13											=NULL;
	char					*JTid											=NULL;
	char					*JTid1											=NULL;
	char					*itemId12											=NULL;
	char					*Creator										=NULL;
	char					*aDatasetId										=NULL;
	char					*aDatasetRev										=NULL;
	char * parent_name ;
	char * dataset_name ;
	char * parent_revision_id ;
	int parent_sequence_id ;
	int ItmSeqID_int ;

	tag_t 	aDataset =NULLTAG;


	int ii,itemcount,j=0;
	int sPartNumberTokint=0;
	int c =0;
	tag_t item=NULLTAG;
	tag_t *rev=NULLTAG;
	tag_t revTag=NULLTAG;
	char *format=NULL;
	char *StrWeightArrayMain1=NULL;
	tag_t relation_type, relation;

	char **attrs = (char **) MEM_alloc(2 * sizeof(char *));
    char **values = (char **) MEM_alloc(2 * sizeof(char *));

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	char ***qry_entries1 = (char ***) MEM_alloc(10 * sizeof(char *));
	char ***qry_values1 = (char ***) MEM_alloc(10 * sizeof(char *));

	tag_t  reln_type = NULLTAG;
	int    n_attchs =0;
	int    flag =0;
	GRM_relation_t *rellist;
	tag_t  *secondary_objects,primary,objTypeTag,refobject=NULLTAG;
	tag_t Fndrelation = NULLTAG;
	int nameRef_cnt;
	tag_t *namRefObject = NULL;
    int  * nFound;
    int   nlFound;
    int   ds;
    int   ass = 0;
    tag_t **  datasets;
	int ref_count_d=0;


	int n_tags_found = 0;
	tag_t query = NULLTAG;
	tag_t	LatestRev		=	NULLTAG;
	tag_t *cntr_objects = NULL;
	tag_t	*t_item1		=	NULLTAG;
	tag_t	latestrev	=	NULLTAG;
	int n_entries = 2;
	int n_found = 1;
	int dd = 0;
	int org_seq_id_int=0;
	char *inputfile=NULL;
	char *type=NULL;
	tag_t *tags_found = NULL;
	char* inputline=NULL;
	tag_t	queryTag	= NULLTAG;
	int resultCount=0;
	tag_t item_tag = NULLTAG;
	char
		*qry_entries4[2] = {"creation_date_after","creation_date_before"},
        *qry_values4[2]	= {"*"};
	char *itemRevSeq = NULL;

	char *drawingnumber;
	FILE* fp=NULL;
	char *drawingtype;
	char *relationstr;
	char *user_data_1;
	//char *type_name;
	char  type_name[TCTYPE_name_size_c+1];
    char object_name[TCTYPE_name_size_c+1] ;
	tag_t *namRefObject_d = NULL;



	char *DataSetNm2 = NULL;
	char *DataSetNm = NULL;
	const char *qry_entries[1] = {"item_id"};
	const char *qry_values123[1];
	char *rev_id123 = NULL;
	char *checkout = NULL;
	char *last_mod_date = NULL;
	char *currentRevID = NULL;
	char *IsDataset = NULL;
	char *currentRevID2 = NULL;
	char *currentRevID3 = NULL;
	char *LatestRevID = NULL;
	char *object_type = NULL;
	char *object_type1 = NULL;
	char *sRef_list		= NULL;
	char *sRelStatus		= NULL;
	char *owning_user1 = NULL;
	char *checked_out_user1 = NULL;
	char *newSeqID = NULL;
	char *newRevID = NULL;
	char *Dataset = NULL;
	char *NmdRef = NULL;
	char *revIDCheck = NULL;
	char *revIDCheck1 = NULL;
	char *revIDCheck2 = NULL;

	int n_count_item=0;
	int newSeqID1=0;
	int n_rev_cnt=0;
	tag_t all_rev;
	tag_t *secObj;
	tag_t *namedRef_tag =NULLTAG;
	tag_t Relatn_type;
	tag_t Relatn_type1;
	int revloop=0;
	int secObjCount=0;
	int revIDInt1=0;
	int refnum=0;
	int reference_count=0;
	FILE *fptr;
	FILE *fptr1;
	FILE *fptr2;
	FILE *fptr3;
	FILE *fptr4;
	char* line;
	
	tag_t newRev= NULLTAG;
	char *DataSetNmOrg = NULL;
	char *fullpath = NULL;
	int RevSeq=1;
	int revCount=0;
	int Latest_count=0;
	int Latest_count123=0;
	int Lastest_corct_count123=0;
	tag_t *rev_list=NULLTAG;
	char	*BOMtype	=NULL;

	tag_t secObjTypeTag = NULLTAG;

	char type_name2[TCTYPE_name_size_c+1];
	char *reference_nameDS=NULL;

	char *User_id=NULL;
	char *fromDate=NULL;
	char *ToDate=NULL;
	char *OwnSite=NULL;
	char *sItemId=NULL;

	logical is_chkout;
	int iOwnSite=0;
	char	*sday	= NULL;
	char	*sMonth	= NULL;
	char	*sDate	= NULL;
	char	*sTmSec	= NULL;
	char	*sYear	= NULL;
	char	*Monthas = NULL;
	char	*getInt = NULL;
	char	*outfileNm = NULL;
	char	*sConTime = NULL;
	char	*sMnt = NULL;
	char	*sHr = NULL;
	char	*sHrMnt = NULL;
	char	*sHrMntFrom = NULL;
	char	*ModFileNm = NULL;
	char	*command = NULL;
	char	*sHrBfr = NULL;
	char	*s24Hrs = NULL;
	char	*s24Min	= NULL;
	char	*s24Sec	= NULL;
	char	*sowning_site	= NULL;
	int HrInt=0;
	char *DesignGrp = "60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,54,16";
	char *DesignGrpCatia = NULL;


	IsDataset=(char *) MEM_alloc(1000);
	reference_nameDS=(char *) MEM_alloc(10);
	outfileNm=(char *) MEM_alloc(200);
	sConTime=(char *) MEM_alloc(200);
	sHrMnt=(char *) MEM_alloc(100);
	s24Hrs=(char *) MEM_alloc(20);
	sHrMntFrom=(char *) MEM_alloc(100);
	ModFileNm=(char *) MEM_alloc(100);
	command=(char *) MEM_alloc(150);
	sHrBfr=(char *) MEM_alloc(10);
	

	time_t t = time(NULL);
	struct tm *tm = localtime(&t);
    char sTime[64];
    strftime(sTime, sizeof(sTime), "%c", tm);

	time_t t1 = time(NULL);
	struct tm *tm1 = localtime(&t1);
    char sTime1[64];
	strftime(sTime1, 100, "%T", tm1);
    
	//printf("\ntime given by funtion:  [%s][%s]\n", sTime,sTime1);
    
	//printf("\ntime given by funtion:  [%s]\n", sTime);//Mon Jan 29 19:40:47 2018  // 29Jan2018

	//sMonth = subString(sTime,4,7);
	sday = strtok(sTime," ");
	sMonth = strtok(NULL," ");
	sDate = strtok(NULL," ");
	sTmSec = strtok(NULL," ");
	sYear = strtok(NULL," ");
	//printf("strtok today's date-----  [%s][%s][%s][%s][%s]",sday,sMonth,sDate,sTmSec,sYear);//[Tue][May][15][16:24:09][2018]
	// uaprod -- strtok today's date-----  [Thu][17][May][2018][10:42:19]

	s24Hrs = strtok(sTime1,":");
	s24Min = strtok(NULL,":");
	s24Sec = strtok(NULL,"");
	
	printf("\n s24Hrs: [%s][%s][%s]\n",s24Hrs,s24Min,s24Sec);fflush(stdout);


     (ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
   // printf("\n Auto login ");fflush(stdout);
	//if( ITK_init_module("loader","loader7","dba")!=ITK_ok) ;
	//if( ITK_init_module("infodba","infodba","dba")!=ITK_ok) ;
	 (ITK_auto_login( ));
	 (ITK_set_journalling( TRUE ));
		
	
	sConTime = strcpy(sConTime,"");
	if(strlen(sMonth)==3)
	{
		sConTime = strcat(sConTime,sDate);
		getInt = getMonth(sMonth);
		sConTime = strcat(sConTime,getInt);
		sConTime = strcat(sConTime,sYear);

		sHr = strtok(sTmSec,":");//[16:16:50]
		sMnt = strtok(NULL,":");//15-May-2018 12:00

		sHrMnt = strcpy(sHrMnt,"");
		sHrMnt = strcat(sHrMnt,sDate);
		sHrMnt = strcat(sHrMnt,"-");
		sHrMnt = strcat(sHrMnt,sMonth);
		sHrMnt = strcat(sHrMnt,"-");
		sHrMnt = strcat(sHrMnt,sYear);
		sHrMnt = strcat(sHrMnt," ");
		sHrMnt = strcat(sHrMnt,sHr);
		sHrMnt = strcat(sHrMnt,":");
		sHrMnt = strcat(sHrMnt,sMnt);

		sHrMntFrom = strcpy(sHrMntFrom,"");
		sHrMntFrom = strcat(sHrMntFrom,sDate);
		sHrMntFrom = strcat(sHrMntFrom,"-");
		sHrMntFrom = strcat(sHrMntFrom,sMonth);
		sHrMntFrom = strcat(sHrMntFrom,"-");
		sHrMntFrom = strcat(sHrMntFrom,sYear);
		sHrMntFrom = strcat(sHrMntFrom," ");

		HrInt = atoi(sHr);
		//printf("\n --------Hrs:  %d \n",HrInt);fflush(stdout);
		if(HrInt==1)
		{
			HrInt=11;
		}
		if(HrInt==2)
		{
			HrInt=12;
		}
		else
		{
			HrInt-=2;
		}
		
		sprintf(sHrBfr,"%d",HrInt);
		//printf("sHrBfr = %s\n", sHrBfr);

		sHrMntFrom = strcat(sHrMntFrom,sHrBfr);
		sHrMntFrom = strcat(sHrMntFrom,":");
		sHrMntFrom = strcat(sHrMntFrom,sMnt);

		//printf("sHrMntFrom: %s",sHrMntFrom);
		
	}
	else
	{
		sConTime = strcat(sConTime,sMonth); // Thu 17 May 2018 10:42:19
		getInt = getMonth(sDate);  
		sConTime = strcat(sConTime,getInt);
		sConTime = strcat(sConTime,sTmSec);
	
		sHr = strtok(sYear,":");//[16:16:50]
		sMnt = strtok(NULL,":");//15-May-2018 12:00

		sHrMnt = strcpy(sHrMnt,"");
		sHrMnt = strcat(sHrMnt,sMonth);
		sHrMnt = strcat(sHrMnt,"-");
		sHrMnt = strcat(sHrMnt,sDate);
		sHrMnt = strcat(sHrMnt,"-");
		sHrMnt = strcat(sHrMnt,sTmSec);
		sHrMnt = strcat(sHrMnt," ");
		sHrMnt = strcat(sHrMnt,s24Hrs);
		sHrMnt = strcat(sHrMnt,":");
		sHrMnt = strcat(sHrMnt,s24Min);
		sHrMnt = strcat(sHrMnt,":");
		sHrMnt = strcat(sHrMnt,s24Sec);

		sHrMntFrom = strcpy(sHrMntFrom,"");
		sHrMntFrom = strcat(sHrMntFrom,sMonth);
		sHrMntFrom = strcat(sHrMntFrom,"-");
		sHrMntFrom = strcat(sHrMntFrom,sDate);
		sHrMntFrom = strcat(sHrMntFrom,"-");
		sHrMntFrom = strcat(sHrMntFrom,sTmSec);
		sHrMntFrom = strcat(sHrMntFrom," ");

		HrInt = atoi(s24Hrs);
		//HrInt = atoi(sHr);
		//printf("\n --------Hrs:  %d \n",HrInt);fflush(stdout);
		if(HrInt==1)
		{
			HrInt=11;
		}
		else if(HrInt==2)
		{
			HrInt=12;
		}
		else
		{
			HrInt-=2;
		}
		//printf("\n --------Hrs:  %d \n",HrInt);fflush(stdout);
		sprintf(sHrBfr,"%d",HrInt);
		//printf("sHrBfr = %s\n", sHrBfr);

		sHrMntFrom = strcat(sHrMntFrom,sHrBfr);
		sHrMntFrom = strcat(sHrMntFrom,":");
		sHrMntFrom = strcat(sHrMntFrom,s24Min);
		sHrMntFrom = strcat(sHrMntFrom,":");
		sHrMntFrom = strcat(sHrMntFrom,s24Sec);

		//printf("sHrMntFrom: %s",sHrMntFrom);
		
	}

	//printf("\n :sConTime: [%s]  : sTmSec : [%s] : sHrMnt: [%s] : sHrMntFrom: [%s]",sConTime,sTmSec,sHrMnt,sHrMntFrom);fflush(stdout);	

	//sConTime = strcat(sConTime,"_CheckedInDesRev");
	//sConTime = strcat(sConTime,".txt");

	//printf("\n Auto login .......");fflush(stdout);

	//fptr=fopen("CheckedInDesRevInLast2Hrs.txt","a");///user/bsd05818/Ashish/Last2HrsCheckInData/catia
	//fptr=fopen("/user/bsd05818/Ashish/Last2HrsCheckInData/catia/CheckedInDesRevInLast2Hrs.txt","a");
	//fptr=fopen("/user/ukprod/shells/TRILIX_CMS/Catia/CheckedInDesRevInLast2Hrs.txt","a");fflush(stdout);//TMETC_TO_TRILIX
	//fptr=fopen("/user/ukprod/shells/UAPROD_CMS/Catia/CheckedInDesRevInLast2Hrs.txt","a");fflush(stdout);//TMETC_TO_UAPROD
	//fptr=fopen("/home/trlprod/shells/TMETC_CMS/Catia/CheckedInDesRevInLast2Hrs.txt","a");fflush(stdout);//TRILIX_TO_TMETC
	fptr=fopen("/home/trlprod/shells/UAPROD_CMS/Catia/CheckedInDesRevInLast2Hrs.txt","a");fflush(stdout);//TRILIX_TO_UAPROD
	//fptr=fopen("/user/uaprod/shells/TMETC_CMS/Catia/CheckedInDesRevInLast2Hrs.txt","a");fflush(stdout);//TMETC
	//fptr=fopen("/user/uaprod/shells/TRILIX_CMS/Catia/CheckedInDesRevInLast2Hrs.txt","a");fflush(stdout);// TRILIX
	//fptr=fopen(sConTime,"a");
	if(fptr)
	{
		//printf("File Opened");
	}
	if(fptr==NULL){
		printf("\n Error! File not opened1");
		exit(1);
	}   
	
	//fptr1=fopen("/user/bsd05818/Ashish/Last2HrsCheckInData/proe/CheckedInDesRevInLast2Hrs.txt","a");
//	fptr1=fopen("/user/uaprod/shells/TMETC_CMS/Proe/CheckedInDesRevInLast2Hrs.txt","a");
//	if(fptr1)
//	{
//		//printf("File Opened");
//	}
//	if(fptr1==NULL){
//		printf("\n Error! File not opened");
//		exit(1);
//	}  

	ModFileNm = strcpy(ModFileNm,"");
	//ModFileNm = strcat(ModFileNm,"/user/bsd05818/Ashish/Last2HrsCheckInData/");
	//ModFileNm = strcat(ModFileNm,"/user/ukprod/shells/TRILIX_CMS/Modules/CatiaModulesBOM/");//TMETC_TO_TRILIX
	//ModFileNm = strcat(ModFileNm,"/user/ukprod/shells/UAPROD_CMS/Modules/CatiaModulesBOM/");//TMETC_TO_UAPROD
	//ModFileNm = strcat(ModFileNm,"/home/trlprod/shells/TMETC_CMS/Modules/CatiaModulesBOM/");//TRILIX_TO_TMETC
	ModFileNm = strcat(ModFileNm,"/home/trlprod/shells/UAPROD_CMS/Modules/CatiaModulesBOM/");//TRILIX_TO_UAPROD
	//ModFileNm = strcat(ModFileNm,"/user/uaprod/shells/TMETC_CMS/Modules/CatiaModulesBOM/");//TMETC
	//ModFileNm = strcat(ModFileNm,"/user/uaprod/shells/TRILIX_CMS/Modules/CatiaModulesBOM/");// TRILIX
	ModFileNm = strcat(ModFileNm,"CheckedInCatModuleRevInLast2Hrs_");
	ModFileNm = strcat(ModFileNm,sConTime);
	ModFileNm = strcat(ModFileNm,"_");
	ModFileNm = strcat(ModFileNm,s24Hrs);
	ModFileNm = strcat(ModFileNm,"_");
	ModFileNm = strcat(ModFileNm,s24Min);
	ModFileNm = strcat(ModFileNm,"_");
	ModFileNm = strcat(ModFileNm,s24Sec);
	ModFileNm = strcat(ModFileNm,".txt");

	
	fptr2=fopen(ModFileNm,"a");
	//fptr2=fopen("/user/uaprod/shells/TMETC_CMS/Catia/CheckedInDesRevInLast2Hrs.txt","a");fflush(stdout);
	//fptr=fopen(sConTime,"a");
	if(fptr2)
	{
		//printf("File Opened");
	}
	if(fptr2==NULL){
		printf("\n Error! File not opened2");
		exit(1);
	}  
	
	   if(QRY_find("CMS_DesRevFromDateToDate", &queryTag));
		//printf("\n\t QRY_find DesRevFromDateToDate.... "); fflush(stdout);

		if (queryTag)
		{
			//printf("Found Query DesRevFromDateToDate \n"); fflush(stdout);
		}
		else
		{
			//printf("Not Found Query DesRevFromDateToDate \n"); fflush(stdout);

			 (POM_logout(false));
			return status;
		}

		//qry_values[0] = User_id;
		qry_values[0] = sHrMntFrom;
		qry_values[1] = sHrMnt;
/*		qry_values[0] = "19-Oct-2018 8:48:09";
		qry_values[1] = "21-Oct-2018 8:48:09";*/

		 (QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &rev));
		
		// (GRM_find_relation_type("IMAN_specification",&Relatn_type1));

		//printf("\n\t INPUT [%s---%s----%d]",fromDate,ToDate,resultCount); fflush(stdout);
		printf("\n\t INPUT \n From-[%s] \nTo-[%s] \n ",sHrMntFrom,sHrMnt); fflush(stdout);
		printf("\n\t Please wait... \n"); fflush(stdout);
		if(resultCount>0)
			{
				for (revloop=0;revloop<resultCount ; revloop++)
				{
				
				(RES_is_checked_out	(rev[revloop],&is_chkout));	
				(AOM_ask_value_string(rev[revloop],"item_id",&sItemId));
				(AOM_UIF_ask_value(rev[revloop],"release_status_list",&sRelStatus));//DesignGrpCatia
				(AOM_UIF_ask_value(rev[revloop],"owning_site",&sowning_site));
				
				//printf("\n\t sItemId: [%s] is_chkout  %d sRelStatus: %s\n",sItemId,is_chkout,sRelStatus); fflush(stdout);
				
				iOwnSite = 	tc_strlen(sowning_site);
				printf("\n\t sowning_site: [%d] \n",iOwnSite); fflush(stdout);

				if(((tc_strcmp(sRelStatus,"ERC Released")==0)) && iOwnSite==0)
					{
						 
						(AOM_ask_value_string(rev[revloop],"item_id",&sItemId));
						(AOM_ask_value_string(rev[revloop],"item_revision_id",&LatestRevID));
						(AOM_ask_value_string(rev[revloop],"t5_DesignGrp",&DesignGrpCatia));
						(AOM_ask_value_string(rev[revloop],"t5_ProjectCode",&ProjectCode));
						(AOM_ask_value_string(rev[revloop],"t5_PartType",&PartType));//

						//printf("\n\t Project Code: [%s] \n",ProjectCode); fflush(stdout);
					
						if((tc_strcmp(ProjectCode,"5442")==0) || (tc_strcmp(ProjectCode,"5445")==0) || (tc_strcmp(ProjectCode,"5447")==0) 
							|| (tc_strcmp(ProjectCode,"5715")==0) || (tc_strcmp(ProjectCode,"5457")==0) || (tc_strcmp(ProjectCode,"5464")==0) || (tc_strcmp(ProjectCode,"5438")==0) || (tc_strcmp(ProjectCode,"5468")==0) || (tc_strcmp(ProjectCode,"5471")==0) || (tc_strcmp(ProjectCode,"2956")==0))//5715 5457
						{
					
							revId=tc_strtok(LatestRevID,";");
							SeqID=tc_strtok(NULL,"");		
							if(strstr(DesignGrp,DesignGrpCatia)!=NULL)
							{								
								if((tc_strcmp(PartType,"M")==0) || (tc_strcmp(PartType,"A")==0))
								{
									fprintf(fptr2,"%s,%s;%s\n",sItemId,revId,SeqID);
									strcpy(command,"");
									//strcat(command,"/user/bsd05818/Ashish/Last2HrsCheckInData/ModuleBOMList");
									//strcat(command,"/user/ukprod/shells/TRILIX_CMS/Modules/CatiaModulesBOM/CatModuleBOMList");//TMETC_TO_TRILIX
									//strcat(command,"/user/ukprod/shells/UAPROD_CMS/Modules/CatiaModulesBOM/CatModuleBOMList");//TMETC_TO_UAPROD
									//strcat(command,"/home/trlprod/shells/TMETC_CMS/Modules/CatiaModulesBOM/CatModuleBOMList");//TRILIX_TO_TMETC
									strcat(command,"/home/trlprod/shells/UAPROD_CMS/Modules/CatiaModulesBOM/CatModuleBOMList");//TRILIX_TO_UAPROD
									//strcat(command,"/user/uaprod/shells/TMETC_CMS/Modules/CatiaModulesBOM/CatModuleBOMList");//TMETC
									//strcat(command,"/user/uaprod/shells/TRILIX_CMS/Modules/CatiaModulesBOM/CatModuleBOMList");//TRILIX								
									strcat(command," -u=loader");
									strcat(command," -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf");
									strcat(command," -g=dba");
									strcat(command," -i=");
									strcat(command,sItemId);
									printf("\ncommand line: %s",command);
									system(command);
								}
								else
								{
								fprintf(fptr,"%s,%s;%s\n",sItemId,revId,SeqID);
								}
							}
							//else
							//{
								//printf("\n\t It's a proe part \n"); fflush(stdout);
							//	fprintf(fptr1,"%s,%s;%s\n",sItemId,revId,SeqID);
							//}
						}
					}						
				}
				printf("\n\t Done. Please check output in file CheckedInDesRevInLast2Hrs.txt \n"); fflush(stdout);
			}
			else
			{
				printf("\n\t Design Revisions are not checked in within given criteria \n");fflush(stdout);
			}
			
			GetLastModifiedDatasets(sHrMntFrom,sHrMnt,"DirectModel");
			GetLastModifiedDatasets(sHrMntFrom,sHrMnt,"PDF");

	 (POM_logout(false));
	return status;

}
int GetLastModifiedDatasets(char *sHrFrom,char *sHrto,char *sDatasettype)
{
	int status = ITK_ok;
	FILE *fptr;
	tag_t	queryTag	= NULLTAG;
	int n_entries		= 3;
	int resultCount		= 0;
	int revloop			= 0;
	char *qry_entries[3] = {"Dataset Type","Modified After","Modified Before"};
	tag_t *dataset_tag = NULLTAG;
	char  *sobject_name		=NULL;
	char	*OutputFile = NULL;
	char	*sowner		= NULL;


	OutputFile=(char *) MEM_alloc(100);
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	

	OutputFile = strcpy(OutputFile,"");
	//OutputFile = strcat(OutputFile,"/home/uadev/muktesh/");
	//OutputFile = strcat(OutputFile,"/user/ukprod/shells/TRILIX_CMS/Modules/CatiaModulesBOM/");//TMETC_TO_TRILIX
	//OutputFile = strcat(OutputFile,"/user/ukprod/shells/UAPROD_CMS/Modules/CatiaModulesBOM/");//TMETC_TO_UAPROD
	//OutputFile = strcat(OutputFile,"/home/trlprod/shells/TMETC_CMS/Modules/CatiaModulesBOM/");//TRILIX_TO_TMETC
	OutputFile = strcat(OutputFile,"/home/trlprod/shells/UAPROD_CMS/Modules/CatiaModulesBOM/");//TRILIX_TO_UAPROD
	//OutputFile = strcat(OutputFile,"/user/uaprod/shells/TMETC_CMS/Modules/CatiaModulesBOM/");//TMETC
	//OutputFile = strcat(OutputFile,"/user/uaprod/shells/TRILIX_CMS/Modules/CatiaModulesBOM/");//TRILIX
	OutputFile = strcat(OutputFile,"CheckedInLast2Hrs_");
	OutputFile = strcat(OutputFile,sDatasettype);
	OutputFile = strcat(OutputFile,".txt");
	

	fptr=fopen(OutputFile,"a");fflush(stdout);
	
	if(fptr)
	{
		printf("File Opened");
	}
	if(fptr==NULL){
		printf("\n Error! File not opened3");
		exit(1);
	}  

		
	if(QRY_find("Dataset...", &queryTag));
	printf("\n\t QRY_find Dataset... "); fflush(stdout);

	if (queryTag)
	{
		printf("Found Query Dataset... \n"); fflush(stdout);
	}
	else
	{
		printf("Not Found Query Dataset... \n"); fflush(stdout);

		 (POM_logout(false));
		return status;
	}
	
	qry_values[0] = sDatasettype;
	qry_values[1] = sHrFrom;
	qry_values[2] = sHrto;	

	(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &dataset_tag));
	
	printf("\n\t INPUT \n From-[%s] \nTo-[%s] \n ",sHrFrom,sHrto); fflush(stdout);
	printf("\n\t Please wait... resultCount: %d\n",resultCount); fflush(stdout);
	if(resultCount>0)
		{
		for (revloop=0;revloop<resultCount ; revloop++)
				{
					(AOM_UIF_ask_value(dataset_tag[revloop],"owning_user",&sowner));				
					if(tc_strcmp(sowner,"loader (loader)")!=0)
					{
					(AOM_ask_value_string(dataset_tag[revloop],"object_name",&sobject_name));
					fprintf(fptr,"%s\n",sobject_name);					
					}
				}
		}

		return status;
}
