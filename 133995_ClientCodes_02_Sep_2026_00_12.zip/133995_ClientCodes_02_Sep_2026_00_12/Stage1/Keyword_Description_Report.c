#include <stdio.h>
#include <tc/tc.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <string.h>
#include <time.h>
#include <ae/dataset_msg.h>
#include <ae/dataset.h>
#include <ss/ss_const.h>

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

int			ifail 				= ITK_ok;
int ctr=0;
FILE *Report = NULL;
int Get_Qry_Execute(char*);

int isPrintable(char ch) {
    return ch >= 32 && ch <= 126;
}
// Function to remove non-ASCII, non-printable, and special characters from string
void removeNonAsciiChars(char *str) {
    int i = 0;
    char ch;
    while ((ch = str[i]) != '\0') {
        if (!isPrintable(ch))
        {
            str[i] = ' ';
        }
        i++;
    }
}

int ITK_user_main(int argc, char *argv[])
{

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Date_1					= NULL;
	char			* Date_2					= NULL;
    char			* design_grp				= NULL;
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	design_grp		= ITK_ask_cli_argument("-i=");
	
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	ifail = Get_Qry_Execute(design_grp);

	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

int Get_Qry_Execute(char* design_grp)
{
		int ifail           = ITK_ok;
		tag_t KWDescQry     = NULLTAG;
	    tag_t *moduleTags   = NULL;
		
		char *Keyword_descp	= NULL;
		char *Keyword_info	= NULL;
		char *Track_and_Trace	= NULL;
	    char *CTE_CTS	= NULL;
	    char *Category	= NULL;
	    char *Sub_category	= NULL;
		char *Class_id=NULL;
		char *part_family=NULL;
		
		
		int modCount=0;
		int Entry_count=2;
		FILE* fp = NULL;
		char*Dataset=NULL;
		Dataset=(char*) MEM_alloc(1000);
		
		char*Path=NULL;
		Path=(char*) MEM_alloc(1000);
		char*Filename=NULL;
		Filename=(char*) MEM_alloc(1000);
		
		int i =0;
		tag_t parent_tag=NULLTAG;
		tag_t parent_tag_1=NULLTAG;
		tag_t parent_tag_2=NULLTAG;
		char* parent_id=NULL;
		char* parent_id_1=NULL;
		char* parent_id_2=NULL;
		char* Aggregate=NULL;
		
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		char Date[100] = "";
		

		strftime(Date,100,"%d_%m_%Y_%H_%M_%S",&when);
		
		printf("\nDate %s\n",Date);
		
		tc_strcpy(Dataset,"Keyword_Description_Report");
		tc_strcat(Dataset,Date);
		
		
		
		tc_strcpy(Path,"/tmp/");
		tc_strcat(Path,Dataset);
		tc_strcat(Path,"csv");
		
		
		
		
        fp=fopen(Path,"w");
		fprintf(fp,"Sr. No.~Classification Unique number~Aggregate Name~Keyword Decription~Design group~Part family~Track_and_Trace~CTE_CTS~Category~Sub_category\n");

char *Entries[2] = {"Name","ext_1"};
char **Values = (char **) MEM_alloc(500 * sizeof(char *));

Values[0] = "*";
Values[1] = design_grp;


 ifail=QRY_find("QryKyWrd_iDsgGrp_oClsfObj", &KWDescQry);
 
if (KWDescQry)
{ 
	QRY_execute(KWDescQry, Entry_count, Entries, Values, &modCount, &moduleTags);

	printf("\nModule Object Found : %d", modCount);fflush(stdout);
	
        for(i=0;i<modCount;i++)
        {       
	            ifail=AOM_ask_value_string(moduleTags[i],"ext_1",&design_grp);
				printf("\nDesign group : %s", design_grp);fflush(stdout);
				ifail=AOM_ask_value_string(moduleTags[i],"name",&Keyword_descp);
				printf("\nkeyword description : %s", Keyword_descp);fflush(stdout);
                ifail=AOM_ask_value_string(moduleTags[i],"cid",&Class_id);
				printf("\nClassification identifier : %s", Class_id);fflush(stdout);
				
				if(Class_id !=NULL)
				{
			    printf("\nClass is not null");fflush(stdout);
				ifail=ICS_class_ask_parent(Class_id,&parent_tag,&parent_id);
			    ifail=AOM_ask_value_string(parent_tag,"name",&part_family);
				printf("\npart_family : %s", part_family);fflush(stdout);
				ifail=ICS_class_ask_parent(parent_id,&parent_tag_1,&parent_id_1);
				ifail=ICS_class_ask_parent(parent_id_1,&parent_tag_2,&parent_id_2);
				ifail=AOM_ask_value_string(parent_tag_2,"name",&Aggregate);
				printf("\nAggregate : %s", Aggregate);fflush(stdout);
				}
				
				ifail=AOM_ask_value_string(moduleTags[i],"ext_2",&Keyword_info);
				printf("\nkeyword info : %s", Keyword_info);fflush(stdout);
				printf("\nkeyword length : %d", tc_strlen(stripBlanks(Keyword_info)));fflush(stdout);
				if(tc_strlen(stripBlanks(Keyword_info))!=0)
				{
			
			    Track_and_Trace=(char *) MEM_alloc(100);
                CTE_CTS=(char *) MEM_alloc(100);
                Category=(char *) MEM_alloc(100);
                Sub_category=(char *) MEM_alloc(100);
				
			    Track_and_Trace = tc_strtok(Keyword_info,",");
				
			    
				if( tc_strcmp(stripBlanks(Track_and_Trace), NULL) ==0)
				{tc_strcpy(Track_and_Trace,"");}
			    CTE_CTS = tc_strtok(NULL,",");
			   
				if( tc_strcmp(stripBlanks(CTE_CTS), NULL) ==0)
				{tc_strcpy(CTE_CTS,"");}
			    Category = tc_strtok(NULL,",");
			    
				if( tc_strcmp(stripBlanks(Category), NULL) ==0)
				{tc_strcpy(Category,"");}
				Sub_category=tc_strtok(NULL,",");
				
				if( tc_strcmp(stripBlanks(Sub_category), NULL) ==0)
				{tc_strcpy(Sub_category,"");}
				}
				else
				{
					tc_strcpy(Track_and_Trace,"");
					tc_strcpy(CTE_CTS,"");
					tc_strcpy(Category,"");
					tc_strcpy(Sub_category,"");
					}
					
				printf("\nTrack_and_Trace : %s",Track_and_Trace);fflush(stdout);
				 printf("\nCTE_CTS : %s",CTE_CTS);fflush(stdout);
				 printf("\nCategory : %s",Category);fflush(stdout);
				 printf("\nSub_category : %s",Sub_category);fflush(stdout);
				
				
				 char *slNo=(char *) MEM_alloc(200);
				sprintf(slNo,"%d",(i+1));

				fprintf(fp,"%s~%s~%s~%s~%s~%s~%s~%s~%s~%s\n",slNo,Class_id,Aggregate,Keyword_descp,design_grp,part_family,Track_and_Trace,CTE_CTS,Category,Sub_category);
				
        }
		
		
		
		
		printf("\nAll keywords completed");fflush(stdout);
		
		
		
		tag_t msExcelType       = NULLTAG;
        tag_t ExcelDataset      = NULLTAG;
        tag_t ExlLatestDat_t    = NULLTAG;
		char* error_text=NULL;

        
        AE_find_datasettype2("MSExcel",&msExcelType);
        if(msExcelType == NULLTAG)
        {
                printf("\n Could not find Dataset\n");fflush(stdout);
        }
        printf("\n Dataset Creation, ");fflush(stdout);
        AE_create_dataset_with_id(msExcelType,Dataset,Dataset,"","",&ExcelDataset);
        AOM_save(ExcelDataset);
        
       // AE_ask_dataset_latest_rev(ExcelDataset,&ExlLatestDat_t);
	   ifail=AE_find_dataset2(Dataset,&ExlLatestDat_t);
        printf(" lst rev, ");fflush(stdout);
        AOM_refresh(ExlLatestDat_t,1);
		 printf("\n Dataset File name=%s\n",Path);fflush(stdout);
        ifail=AE_import_named_ref(ExlLatestDat_t,"excel",Path,NULL,SS_BINARY);
		if(ifail !=ITK_ok)
		{
			EMH_ask_error_text(ifail,&error_text);
			printf("\n ERROR=%s\n",error_text);fflush(stdout);
		
		}
		else
		{
			printf("\nFile imported successfully\n");fflush(stdout);
			}
		
		
        printf(" \nname ref\n, ");fflush(stdout);
        ifail=AOM_save(ExlLatestDat_t);
		if(ifail !=ITK_ok)
		{
			EMH_ask_error_text(ifail,&error_text);
			printf("\n ERROR=%s\n",error_text);fflush(stdout);
		
		}
		else
		{
			printf("\n281_Saved successfully\n");fflush(stdout);
			}
        
	
		if(ifail !=ITK_ok)
		{
			EMH_ask_error_text(ifail,&error_text);
			printf("\n ERROR=%s\n",error_text);fflush(stdout);
		
		}
		else
		{
			printf("\n282_Saved successfully\n");fflush(stdout);
			}
			
			
			AOM_refresh(ExlLatestDat_t,0);
		
		 int n_entry = 1;
        int rsltCount = 0;
        tag_t qryTag = NULLTAG;
        tag_t *CntrolObjectTag = NULLTAG;
        char *qry_entry[1] = {"Name"};
        char **qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));
		



        if(QRY_find("folder custom", &qryTag));
        if (qryTag)
        {
                //printf("\n ERCVali:Found Query ControlObjects \n");fflush(stdout);
                qry_values2[0] = "Keyword_Description_Report";
                if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrolObjectTag));
                printf("\t  rsltCount :%d:", rsltCount); fflush(stdout);
                if(rsltCount > 0)
                {

                AOM_lock(CntrolObjectTag[0]);
                FL_insert(CntrolObjectTag[0],ExlLatestDat_t,999);
                AOM_save(CntrolObjectTag[0]);
                AOM_unlock(CntrolObjectTag[0]);
                AOM_refresh(CntrolObjectTag[0],1);


                }
        }

		 if (fp)
        {
                fclose(fp);
        }
}     
            if(Keyword_info)
		     { MEM_free(Keyword_info); }
	              if(Class_id)
		     { MEM_free(Class_id); }
		       if(parent_id)
		     { MEM_free(parent_id); }
		      if(part_family)
		     { MEM_free(part_family); }
		     if(parent_id_1)
		     { MEM_free(parent_id_1); }
		    if(parent_id_2)
		     { MEM_free(parent_id_2); }
		 if(Aggregate)
		     { MEM_free(Aggregate); }
		 if(design_grp)
		 { MEM_free(design_grp); }
	       if(Keyword_descp)
		 { MEM_free(Keyword_descp); }	
	    
else
	{
               
		 printf("\nModule not found with given input\n");fflush(stdout);
		 
	}
	
	return ifail;
	  
}

