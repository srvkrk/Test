#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <sa/person.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/envelope.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>

int ITK_user_main(int argc, char *argv[])
{

	int				ifail 						= ITK_ok;
	int             j                           = 0;
	int             i                           = 0;
	int             Flag                           = 0;
	int             n_entries                   = 2;
	int             resultCount                 = 0;
	tag_t           queryTag                    = NULLTAG;
	tag_t           DMLReleaseTag                    = NULLTAG;
	tag_t          *Releasedparts               = NULLTAG;
	char           *FromDate                    = NULL;
	char           *ToDate                      = NULL;
	char           *qry_entries[2]              = {"date_released_after","date_released_before"};
	char           **qry_values                 =  (char **) MEM_alloc(500 * sizeof(char *));
	char            *ChangeRBoard                      = NULL;
	char* sUserName	= NULL;
	char* sPassword = NULL;
	char* ChangReviewName = NULL;
	char* stringDML = NULL;
	char* dml_no = NULL;
	FILE* a=NULL;

	char buffer[200]="";
	
	stringDML= (char*) malloc(20000000);
	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
    FromDate 		= ITK_ask_cli_argument("-I1=");
	ToDate 			= ITK_ask_cli_argument("-I2=");

	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	sprintf(buffer,"DML_COCAproveReport.csv");

	a=fopen(buffer,"w+");
	if (buffer == NULL)
	{
		printf("\nERROR: Cannot open File\n");
    	return -1;
	}

	else
	{
		printf("\nFile opened successfully.\n");
	}

	if(QRY_find2("DML_Release_Btwn_Dates", &queryTag));
	printf("\n\t DML_Release_Btwn_Dates : QRY_find");fflush(stdout);
	if( queryTag != NULLTAG )
	   { 

		qry_values[0] = FromDate;
		qry_values[1] = ToDate;

		 if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &Releasedparts));
		     printf("\n DML_Release--resultCount : %d\n", resultCount);fflush(stdout);

			 for(i=0;i<resultCount;i++)
		     {
				 DMLReleaseTag = Releasedparts[i];

				 if(AOM_ask_value_string(DMLReleaseTag,"item_id",&dml_no));
				 printf("\n DML Number : %s",dml_no);fflush(stdout);

				if(AOM_UIF_ask_value(DMLReleaseTag,"ChangeReviewBoard",&ChangReviewName));
				printf("\n 2.ChangeReviewBoard  :: %s \n",ChangReviewName);fflush(stdout);
					
				 if(tc_strstr(ChangReviewName,"sks658585")!=NULL)
				 {
					 Flag++;
					 strcat(stringDML,dml_no);
					 strcat(stringDML,"\n");

				 }
		      }
				printf("\nDML count %d\n",Flag);fflush(stdout);
				printf("\nDML Number [%s]",stringDML);fflush(stdout);
				fprintf(a,"%s",stringDML);fflush(a);
	   }
	   fclose(a);
}
