
//  ./Test4dObj -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=DFM_282960000102_NR_1
//  ./Test4dObj -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=DFM_282960001452_NR_1
//  ./Test4dObj -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=InputFile.txt



//   ./PDF_DFMEA4D_Attachment -u=ercpsup -p=ERCpsup2019 -g=dba -i=Input_test.txt
//   ./PDF_DFMEA4D_Attachment -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=Input_test.txt
//  ./PDF_DFMEA4D_Attachment -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=InputFile2.txt

// ./PDF_DFMEA4D_Attachment -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=InputFile3.txt

//./PDF_DFMEA4D_Attachment -u=infodba -pf=/home/uaprod/shells/Admin/infodbapassfile.pwf -g=dba -i=shellInputfile.txt


//./PDF_DFMEA4D_Attachment -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=shellInputfile.txt
//./PDF_DFMEA4D_Attachment -u=bsd05818 -p=XYT1ESA -g=dba -i=shellInputfile.txt
//./PDF_DFMEA4D_Attachment -u=bsd05818 -p=XYT1ESA -g=dba -i=ShellPdfFiles.txt

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <bom/bom_tokens.h>
#include <cfm/cfm_item.h>
#include <cfm/cfm_tokens.h>
#include <dispatcher/dispatcher_itk.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <sa/tcfile.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <sa/user.h>
#include <unistd.h>
#include <sys/types.h>
#include <property/prop.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <time.h>
#include <tccore/grm_msg.h>
#include <stdlib.h>
#include <string.h>
#include <epm/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ss/ss_errors.h>
#include <tccore/grm.h>
#include <epm/cr_effectivity.h>
#include<ics/ics.h>
#include<ics/iman_ics.h>
//#include <tcfile_cache.h>

#define Debug TRUE
//#define ITK_CALL(X)														\
//	if(Debug)															\
//	{																	\
//		printf(#X);														\
//	}																	\
//	fflush(NULL);														\
//	status=X;															\
//	if (status != ITK_ok )												\
//	{																	\
//		int				index = 0;										\
//		int				n_ifails = 0;									\
//		const int*		severities = 0;									\
//		const int*		ifails = 0;										\
//		const char**	texts = NULL;									\
//																		\
//		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
//		printf("\t%3d error(s)\n", n_ifails);							\
//		for( index=0; index<n_ifails; index++)							\
//		{																\
//			printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
//		}																\
//		return status;													\
//	}																	\
//	else																\
//	{																	\
//		if(Debug)														\
//		printf("\tSUCCESS\n");											\
//	}																	\



	#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
static int report_error ( char *file, int line, char *function, int return_code)
{
if (return_code != ITK_ok)
{
int index = 0;
int n_ifails = 0;
const int* severities = 0;
const int* ifails = 0;
const char** texts = NULL;



EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
printf("%3d error(s)\n", n_ifails);
for( index=0; index<n_ifails; index++)
{
printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
}
EMH_clear_errors();

}
return return_code;
}



#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

void removeNewLineChar(char *ptr)
{
    while((ptr != NULL) && (*ptr != '\n'))
    {
        ++ptr;
    }
    *ptr = '\0';
}

extern int ITK_user_main(int argc, char ** argv )
{

    int status;

	tag_t PartObj		 = NULLTAG;	
	tag_t queryTagK		 = NULLTAG;
	tag_t *children		 = NULLTAG;
	char *itemname		 = NULL;
	char *itemnameParent = NULL;
	int		nAttributes  = 0;


	char		*PartNumberS		= NULL;	
	char		*PartNumberSxls		= NULL;	
	char		*curentname			= NULL;	
	char		*curentnameid			= NULL;	
	char		*curentnamexls		= NULL;	
	char		*ProjctCdeS			= NULL;	
	tag_t  ProjctCdeS1 = NULLTAG;
	char		*ProjctCdeSxls		= NULL;	
	char		*tok				= NULL;
	char		*tokxls				= NULL;
	char		*Parttok			= NULL;
	char		*Parttokxls			= NULL;
	char		*PartRevtok			= NULL;
	char		*PartRevtokxls		= NULL;
	char		*PartSeqtok			= NULL;
	char		*PartSeqtokxls		= NULL;
	char		*ObjTok				= NULL;
	char		*ObjTokxls			= NULL;
	tag_t		Part_tag			= NULLTAG;	
	tag_t		Part_tagxls			= NULLTAG;	
	tag_t		latestrev			= NULLTAG;	
	tag_t		latestrevxls		= NULLTAG;	
	int			ifail				= 0;	
	tag_t		relationSpeci_type;
	tag_t		relationSpeci_typexls;
	tag_t		FndSpeciRelation;		
	tag_t		FndSpeciRelationxls;		
	tag_t		DatasetType			= NULLTAG;
	tag_t		DatasetTypexls		= NULLTAG;
	tag_t		PdfDataset			= NULLTAG;
	tag_t		XlsDataset			= NULLTAG;
	tag_t		specificationRel_t	= NULLTAG;
	tag_t		specificationRel_txls	= NULLTAG;
	tag_t		PdfLatestDat_t		= NULLTAG;
	int			iStatus				= 0;
	FILE		*fptr;
	char		* inputfile			= NULL;
	char		*nwRev				= NULL;
	char		*nwRev1				= NULL;
	char		*nwRevxls			= NULL;
	tag_t		 ReqRev				= NULLTAG;
	int			n_tags_found4		= 0;
	tag_t		*tags_found4		= NULL;

	nwRev		=(char *) MEM_alloc(10);
	//char		 pdfpath1[300];
	char		 *pdfpath1			=	NULL;
	char		 *xlspath1			=	NULL;
	//char		 pdfpath[300];
	char		 *pdfpath			=	NULL;
	char		 *xlspath			=	NULL;
	char		*inputline			=	NULL;
	char		*inputlinenew		=	NULL;
	char		*inputlinenew1		=	NULL;
	char		*TypeNmetok			=	NULL;
	char		*TypeNmetokxls		=	NULL;
	char		*SerialNumtok		=	NULL;
	char		*SerialNumtokxls	=	NULL;

	int         number_of_types1	= 0;
	int         number_of_types1xls	= 0;
	tag_t		type_tag3=NULLTAG;
	tag_t*		type_tag3xls;
	tag_t		object_create_input_tag3 =NULLTAG;
	tag_t		object_create_input_tag3xls =NULLTAG ;
	tag_t		dad_tag =NULLTAG;
	tag_t		dad_tagxls =NULLTAG;
	tag_t		DADRel_t		= NULLTAG;
	tag_t		DADRel_txls		= NULLTAG;
	tag_t		tRelationFind	= NULLTAG;
	tag_t		tRelationFindxls	= NULLTAG;
	tag_t		tRelationExistxls	= NULLTAG;
	tag_t		tRelationExist	= NULLTAG;
	char *		Typetok			= NULL;
	char *		Typetokxls			= NULL;
	char *		inputfilenew	= NULL;

	tag_t	ProQry4dObj		= NULLTAG;
	tag_t	DAD4DCountObj	=NULL;
	int		DAD4DCount		= 0;
	int		n_Input			= 3;
	char	*qry_Input[3]	= {"ItemID", "Type", "Revision"};
	char	*valuesx[3];
	tag_t	DAD4D_rev_tag	= NULLTAG;
	tag_t	DADrevTag		= NULLTAG;
	tag_t	DADrevTagxls		= NULLTAG;
	char * PartTypeS		= NULL;
	char * PartTypeSxls		= NULL;
	char * DADNumber		= NULL;

	logical			checkout			= 0;
	logical			checkoutxls			= 0;
	logical			checkout2			= 0;
	logical			checkout2xls			= 0;
	char*			ReleaseStatus		= NULL;
	char*			ReleaseStatusxls		= NULL;
	char*			ReleaseStatuspdf	= NULL;
	tag_t			status_rel			= NULLTAG;
	tag_t			status_relxls			= NULLTAG;
	tag_t			status_relpdf		= NULLTAG;
	logical			retain				= 0;
	logical			retainpdf			= 0;
	tag_t*			relStatus_list;
	tag_t*			relStatus_listxls;
	int				status_count		= 0;
	int				status_countxls		= 0;
	int				ss					= 0;
	int				ss1					= 0;
	char			*latest_rev_Rel_Stus= NULL;
	char			*latest_rev_Rel_Stusxls= NULL;
	char		*T5_DAD_Document_item_id			= NULL;
	char		*PartRevSeq			= NULL;
	int line_count = 0;



	(void)argc;
	(void)argv;


	inputfile  = ITK_ask_cli_argument("-i=");//DFA_1234567_NR_1_01.pdf

	iStatus = ITK_auto_login();

	

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));

	ITK_CALL(ITK_set_journalling( TRUE ));

	printf("\n After Auto login .......\n");fflush(stdout);



	fptr=fopen(inputfile,"r");
	if(fptr!=NULL)
	{
	  printf("\n Input File is %s",inputfile);
	
	  printf("\n inputfile-------->  : [%s]\n",inputfile);fflush(stdout);//abcd.txt 

	  inputline=(char *) MEM_alloc(1500);
	  inputlinenew =(char *)MEM_alloc(1500);
	  //inputlinenew1 =(char *)MEM_alloc(1500);

	  while(fgets(inputline,1500,fptr)!=NULL)
	  {

		printf("inputline[%03d]: %s", ++line_count, inputline);
//		 if (inputline[strlen(inputline) - 1] != '\n')
//         printf("\n");
		
		printf("\n inputline -------->  : [%s]\n",inputline);fflush(stdout);
//		printf("\n inputlinenew------>  : [%s]\n",inputlinenew);fflush(stdout);

		removeNewLineChar(inputline);

		tc_strcpy(inputlinenew,inputline);
		printf("\n inputlinenew------>  : [%s]\n",inputlinenew);fflush(stdout);

		ObjTok = tc_strtok(inputlinenew, ".");

		printf("\n ObjTok  : [%s]\n",ObjTok);fflush(stdout);
		DADNumber	=	(char	*)MEM_alloc(90);
		tc_strcpy(DADNumber,ObjTok);
		printf("\n DADNumber------>  : [%s]\n",DADNumber);fflush(stdout);


	   if (tc_strstr(inputline,".pdf")!=NULL)
	   {
			pdfpath1	=	NULL;
			pdfpath1	=	(char	*)MEM_alloc(tc_strlen(inputline)+2);
			tc_strcpy(pdfpath1,inputline);
			printf("\n PDF Name pdfpath1 ------------------->{%s}\n",pdfpath1); fflush(stdout);

			pdfpath	=	NULL;
			pdfpath	=	(char	*)MEM_alloc(150);

			tc_strcpy(pdfpath,"");
			//printf("\n pdfpath 111111 ----------------->	[%s]\n ",pdfpath);fflush(stdout);
			////tc_strcat(pdfpath,"/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/MovedFiles_TCUA");
			//tc_strcat(pdfpath,"/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/PDFFiles");
			//tc_strcat(pdfpath,"/user/uaprod/shells/4D");
			tc_strcat(pdfpath,"/user/bsd05818/Adi");///user/bsd05818/Adi
			//tc_strcat(pdfpath,"/tmp");
			//tc_strcat(pdfpath,"/user/testcmi/devgroups/Adi/Test4dObj");
			//tc_strcat(pdfpath,"/user/plmsap/PLMSAP/dbk/sap_prod/Jan2022/05012022");
			tc_strcat(pdfpath,"/");
			tc_strcat(pdfpath,pdfpath1);

			//printf("\n pdfpath ----------------->	[%s]\n ",pdfpath);fflush(stdout);
			removeNewLineChar(pdfpath);
			printf("\n after removal pdfpath ----------------->	[%s]\n ",pdfpath);fflush(stdout);

			Typetok =NULL;
			Parttok =NULL;
			PartRevtok =NULL;
			PartSeqtok =NULL;
			SerialNumtok =NULL;

			Typetok = tc_strtok(inputlinenew, "_");// DFA
			Parttok = tc_strtok(NULL, "_");		// 1234567
			PartRevtok = tc_strtok(NULL, "_");	//NR
			PartSeqtok = tc_strtok(NULL, "_");	//1
			SerialNumtok = tc_strtok(NULL, "_");//01

			PartRevSeq = MEM_alloc(5);
//			T5_DAD_Document_item_id = MEM_alloc(50);

			tc_strcpy(PartRevSeq,PartRevtok);

//			tc_strcpy(T5_DAD_Document_item_id,Typetok);
//			tc_strcat(T5_DAD_Document_item_id,"_");
//			tc_strcat(T5_DAD_Document_item_id,Parttok);

			printf("\n Typetok to find----------> = %s\n", Typetok);fflush(stdout);
			printf("\n Parttok to find----------> = %s\n", Parttok);fflush(stdout);
			printf("\n PartRevtok to find----------> = %s\n", PartRevtok);fflush(stdout);
			printf("\n PartSeqtok to find----------> = %s\n", PartSeqtok);fflush(stdout);
			printf("\n SerialNumtok to find----------> = %s\n", SerialNumtok);fflush(stdout);
			printf("\n PartRevSeq to find----------> = %s\n", PartRevSeq);fflush(stdout);
			//printf("\n T5_DAD_Document_item_id to find----------> = %s\n", T5_DAD_Document_item_id);fflush(stdout);


			nwRev		=	NULL;
			nwRev		=(char *) MEM_alloc(10);

			if (tc_strcmp(PartRevSeq,"N")==0)
			{
			tc_strcpy(nwRev,"");
			tc_strcat(nwRev,PartRevSeq);
			tc_strcat(nwRev,"*");
			}
			else
			{
			tc_strcpy(nwRev,"");
			tc_strcat(nwRev,PartRevSeq);
			tc_strcat(nwRev,"*");
			}


//			tc_strcpy(nwRev,"");
//			tc_strcat(nwRev,PartRevtok);
//			tc_strcat(nwRev,"*");
			//tc_strcat(nwRev,PartSeqtok);
			printf("\n  nwRev to find----------> = %s\n", nwRev);fflush(stdout);

			PartTypeS = (char	*)MEM_alloc(10);
			tc_strcpy(PartTypeS,Typetok);
			printf("\n PartTypeS= [%s]\n",PartTypeS);fflush(stdout);

			PartNumberS = (char	*)MEM_alloc(50);
			tc_strcpy(PartNumberS,Parttok);
			printf("\n Part Number to find = [%s]\n",PartNumberS);fflush(stdout);

			//ITK_CALL(ITEM_find_item (PartNumberS,&Part_tag));


//			char	**values[3];
//			char	*qry_Input[3]			= {"Item ID", "Type", "Revision"};
			//char* qry_Input = (char **) MEM_alloc(100 * sizeof(char *));
			//char **values = (char **) MEM_alloc(50 * sizeof(char *));
			//values = (char **) MEM_alloc(100 * sizeof(char *));

			int		n_Input					= 3;
			int		Count4D					= 0;
			tag_t	*Obj4D					= NULLTAG;
			tag_t	ProQry4DObj				= NULLTAG;
			tag_t  *tags_found4   = NULL;
			int		n_tags_found4 = 0;
			char buffer[50];


			char *qry_Input[3] = {"Item ID","Type","Revision"};
			char **values = (char **) MEM_alloc(100 * sizeof(char *));
			printf("\n nwRev:::::::: = %s", nwRev);fflush(stdout);
			values[0] = PartNumberS;
			values[1] = "Design Revision";
			values[2] = nwRev;

			if(QRY_find("Item Revision...", &ProQry4DObj));
			if(ProQry4DObj!=NULLTAG)
			{
				 printf("\n qUERY for 4D count***== %d", Count4D);fflush(stdout);

				 if(QRY_execute(ProQry4DObj, n_Input, qry_Input, values, &Count4D, &Obj4D));
				 printf("\n qUERY for 4D count== %d", Count4D);fflush(stdout);
			}

			if (Count4D == 0)
			{
				printf ("\n XXXXXXX Count4D ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", PartNumberS); fflush(stdout);
				continue;
			}

			///if(Count4D>0)
			//{
			//   latestrev = Obj4D[0];
			//}
			sprintf(buffer, "%d", Count4D);
			printf("\n buffer value %s \n", buffer);

			
			
			nwRev1		=	NULL;
			nwRev1		=(char *) MEM_alloc(10);

			if (tc_strcmp(PartRevSeq,"N")==0)
			{
			tc_strcpy(nwRev1,"");
			tc_strcat(nwRev1,PartRevSeq);
			tc_strcat(nwRev1,";*");
			tc_strcat(nwRev1,buffer);
			}
			else
			{
			tc_strcpy(nwRev1,"");
			tc_strcat(nwRev1,PartRevSeq);
			tc_strcat(nwRev1,"*");
			tc_strcat(nwRev1,buffer);
			}


//			tc_strcpy(nwRev1,"");
//			tc_strcat(nwRev1,PartRevtok);
//			tc_strcat(nwRev1,"*");
//			tc_strcat(nwRev1,buffer);
			//tc_strcat(nwRev,PartSeqtok);
			printf("\n  nwRev 1111111 to find----------> = %s\n", nwRev1);fflush(stdout);

			 const char **attrs3  = ( const char **) MEM_alloc(2 * sizeof(char *));
			 const char **values3 = ( const char **) MEM_alloc(2 * sizeof(char *));
			attrs3[0]	   ="item_id";
			values3[0]     = (char *)PartNumberS;
		
			ifail = ITEM_find_item_revs_by_key_attributes(1,attrs3, values3,nwRev1, &n_tags_found4, &tags_found4);
			MEM_free(attrs3);
			MEM_free(values3);

			if (n_tags_found4>0)
			{
			   latestrev= tags_found4[0];
			}
			else
		    {
				continue;
		    }

	

//			
//			if (Part_tag!=NULLTAG)
//			{
//				printf("\nPart_tag is not null \n");fflush(stdout);
//			}
//			else
//			{
//				printf("\nPart_tag is null tag\n");fflush(stdout);
//			}

//			ITK_CALL(ITEM_ask_latest_rev(Part_tag,&latestrev));//write query latest rev of part


			//ITK_CALL( AOM_ask_value_string(latestrev,"object_string",&curentname));//changed
			ITK_CALL(AOM_ask_value_string(latestrev,"item_id",&curentname));
			printf("\ncurentname:%s",curentname);

			ITK_CALL(AOM_ask_value_string(latestrev,"item_revision_id",&curentnameid));
			printf("\n curentnameid:%s \n",curentnameid);



			//if( AOM_ask_value_string(latestrev,"t5_ProjectCode",&ProjctCdeS)==ITK_ok);

//			ITK_CALL(POM_attr_id_of_attr("t5_ProjectCode","Design_0_Revision_alt",&ProjctCdeS1));
//
//				AOM_lock(latestrev);
//				ITK_CALL(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,NULLTAG,NULL));//remove
//				ITK_CALL(POM_set_attr_string(1,&latestrev,ProjctCdeS1,"5442")); //remove
//				AOM_save(latestrev);
//				printf("\n SET PROJ CODE t5_ProjectCode :[%s]  \n",ProjctCdeS1);fflush(stdout);

			ITK_CALL( AOM_ask_value_string(latestrev,"t5_ProjectCode",&ProjctCdeS));
			printf("\n Required revision---------------> [%s]and project code ---------->[%s]\n",curentnameid,ProjctCdeS);fflush(stdout);

			//return 0;
			if(access(pdfpath,F_OK)!=-1)
			{
				printf("\n FILE PRESENT qqqqqqqqqqqqqqqqqqqqqqqqqqqqQ  \n ");
			}
			else
			{
				printf("\n FILE NOT PRESENT qqqqqqqqqqqqqqqqqqqqqqqqqqqqQ  \n ");
			}
			system("pwd");

		   if(tc_strcmp(ProjctCdeS,"2829")==0|| tc_strcmp(ProjctCdeS,"2956")==0|| tc_strcmp(ProjctCdeS,"5483")==0|| tc_strcmp(ProjctCdeS,"5482")==0|| tc_strcmp(ProjctCdeS,"5481")==0|| tc_strcmp(ProjctCdeS,"5480")==0|| tc_strcmp(ProjctCdeS,"5479")==0|| tc_strcmp(ProjctCdeS,"5478")==0|| tc_strcmp(ProjctCdeS,"5477")==0||tc_strcmp(ProjctCdeS,"5458")==0|| tc_strcmp(ProjctCdeS,"5442")==0|| tc_strcmp(ProjctCdeS,"5485")==0 || tc_strcmp(ProjctCdeS,"5445")==0 || tc_strcmp(ProjctCdeS,"5447")==0 || tc_strcmp(ProjctCdeS,"5438")==0 || tc_strcmp(ProjctCdeS,"5457")==0 || tc_strcmp(ProjctCdeS,"5464")==0 || tc_strcmp(ProjctCdeS,"5465")==0 || tc_strcmp(ProjctCdeS,"5466")==0 || tc_strcmp(ProjctCdeS,"5468")==0 || tc_strcmp(ProjctCdeS,"5471")==0 || tc_strcmp(ProjctCdeS,"5472")==0 || tc_strcmp(ProjctCdeS,"5473")==0 || tc_strcmp(ProjctCdeS,"5474")==0|| tc_strcmp(ProjctCdeS,"5476")==0)
			{
				printf("\n PROJECT CODE FOUND [%s] \n", ProjctCdeS);fflush(stdout);

				if (tc_strstr(pdfpath,".pdf")!=NULL)
				{
					printf("\n PDF FOUND \n");fflush(stdout);
					ITK_CALL(AE_find_datasettype2("PDF",&DatasetType));

					if((tc_strcmp(PartTypeS,"DFA")==0)||(tc_strcmp(PartTypeS,"DFS")==0)||(tc_strcmp(PartTypeS,"DFM")==0))
					{
						ITK_CALL(ITEM_find_item (DADNumber,&dad_tag));
						//ITK_CALL(ITEM_find_item (T5_DAD_Document_item_id,&dad_tag));//changed
						if (dad_tag!=NULLTAG)
						{
							printf("\n  T5_DADDoc already exists \n");fflush(stdout);
						}
						else
						{					
							printf("\n  T5_DADDoc does not exist hence creating \n");fflush(stdout);
							//ITK_CALL(TCTYPE_find_types_for_class("T5_DADDoc",&number_of_types1,&type_tag3));
							ITK_CALL( TCTYPE_find_type( "T5_DADDoc", NULL, &type_tag3) );
							//ITK_CALL ( TCTYPE_ask_object_type ( wsobj_tag [ wsobj_index ], &wsob_type ) ) ;
							printf("\n number_of_types T5_DADDoc-------->  : %d\n",number_of_types1);fflush(stdout);	
							ITK_CALL(TCTYPE_construct_create_input(type_tag3, &object_create_input_tag3));

							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"item_id",DADNumber));
							//ITK_CALL(AOM_set_value_string(object_create_input_tag3,"item_id",T5_DAD_Document_item_id));
							ITK_CALL(AOM_set_value_string(object_create_input_tag3,"object_desc","PFIRST DATA"));

							printf("\n test 123 \n");fflush(stdout);
							printf("\nDADNumber:%s\n",DADNumber);fflush(stdout);
							printf("\n test 123 \n");fflush(stdout);

							ITK_CALL(TCTYPE_create_object(object_create_input_tag3,&dad_tag));			//DFA Item Master
							//CALLAPI( TCTYPE_create_object(object_create_input_tag3, &dad_tag) );
							printf("\n 4d obj dad_tag created......\n");fflush(stdout);

						
							if(dad_tag) 
								{
									ITK_CALL(AOM_save(dad_tag));
									ITK_CALL(AOM_refresh(dad_tag,0));
									ITK_CALL(AOM_unlock(dad_tag));
									printf("\n  object created.\n"); fflush(stdout);
								}
						
							printf("\n afterrrrrrr 4d obj dad_tag created finding revision  now......\n");fflush(stdout);
						//}

							//ITK_CALL(ITEM_find_revision(dad_tag,nwRev,&rev));
							if(ITEM_ask_latest_rev(dad_tag,&DADrevTag));					//DFA Item Revision

							printf("\n AFTER 4D_REV_TAG\n");fflush(stdout);
							if(AOM_lock(DADrevTag));
							ITK_CALL(AOM_set_value_string(DADrevTag,"t5_DsgnNum",DADNumber));
							ITK_CALL(AOM_set_value_string(DADrevTag,"item_revision_id","A;1"));//NEW CHANGE
							ITK_CALL(AOM_set_value_string(DADrevTag,"t5_DsgnAnlysisDocType",PartTypeS));//NEW CHANGE

							if(AOM_save(DADrevTag));
							if(AOM_unlock(DADrevTag));
							printf("\n AFTER setting value on dad revision \n");fflush(stdout);
						
				
							printf("\n CREATING RELATION BETWEEN PART AND DAD DOC\n");
						
							if(GRM_find_relation_type("T5_PartHas4D",&tRelationFind));

							if (tRelationFind!=NULLTAG && DADrevTag !=NULLTAG && DADrevTag!=NULLTAG)
							  {
								printf("\n TESTING HERE \n");fflush(stdout);
								ITK_CALL( GRM_find_relation(latestrev,DADrevTag,tRelationFind,&tRelationExist)); 
								
								printf("\n AFTER TESTING HERE tRelationExist \n");fflush(stdout);
								if(tRelationExist)
								  {
									 printf("\n tRelationExist tRelationExist tRelationExist \n");fflush(stdout);
								  }
								  else
								  {
									  printf("\n tRelationExist DOES NOT EXIST HENCE CREATING \n");fflush(stdout);
									 ITK_CALL(GRM_create_relation(latestrev,DADrevTag,tRelationFind,NULLTAG,&DADRel_t));//latest part revision and dad doc revision
									 //ITK_CALL(GRM_create_relation(latestrev,dad_tag,tRelationFind,NULLTAG,&DADRel_t));
									 ITK_CALL(GRM_save_relation(DADRel_t));
									 ITK_CALL(AOM_refresh(latestrev,0));
								  }
							  }
								  
						ITK_CALL(GRM_find_relation_type("IMAN_specification", &relationSpeci_type));
						//ITK_CALL(GRM_find_relation_type("TC_Attaches", &relationSpeci_type));
						if(relationSpeci_type != NULLTAG)
							{
								printf("\n pdfpath  ---------------[%s] \n",pdfpath);fflush(stdout);
								printf("\n pdfpath1  ----------------- [%s] \n",pdfpath1);fflush(stdout);
								//ITK_CALL(AE_find_datasettype2("PDF",&DatasetType));
								ITK_CALL(AE_create_dataset_with_id(DatasetType,pdfpath1,"Dataset Creation Tool","","",&PdfDataset));
								
								ITK_CALL(AE_save_myself(PdfDataset));

								printf("\n PDF created \n");fflush(stdout);

								if(PdfDataset != NULLTAG)
								{
//									 tag_t file_tag			   = NULLTAG;
//									 IMF_file_t 	file_descriptor;
//									 AE_reference_type_t		tagRefTypePDF	= 1;
//
//									 ITK_CALL(IMF_import_file(pdfpath,NULL, SS_BINARY, &file_tag, &file_descriptor));
//									 printf("\n\t after IMF_import_file \n"); fflush(stdout);
//
//									 ITK_CALL(AOM_save(file_tag));
//
//									 ITK_CALL(AOM_lock(PdfDataset));	
//									 printf("\n\t after AOM_save FIRST TIME -  \n"); fflush(stdout);
//
//									
//									 ITK_CALL(AE_add_dataset_named_ref(PdfDataset,DatasetType,tagRefTypePDF,file_tag));
//			
//									 printf("\n\t after named reference  \n"); fflush(stdout);
//
//									 ITK_CALL(AOM_save(PdfDataset));
//									 printf("\n\t AOM_save Dataset ALIAS \n"); fflush(stdout);
//									 ITK_CALL(AOM_unlock(PdfDataset));
//
//									 ITK_CALL(GRM_create_relation(DADrevTag,PdfDataset,relationSpeci_type,NULLTAG,&specificationRel_t));
//									 printf("\n\t after creating specificationRel_t between dataset\n"); fflush(stdout);
//									 ITK_CALL(GRM_save_relation(specificationRel_t));
//									 ITK_CALL(AOM_refresh(DADrevTag,0));
//									 printf("\n\t after AOM_refresh 2ND TIME \n"); fflush(stdout);



									printf("\n PdfDataset tag found as dataset registered \n");fflush(stdout);
									ITK_CALL(GRM_create_relation(DADrevTag,PdfDataset,relationSpeci_type,NULLTAG,&specificationRel_t));//dad doc revision and pdf
									//ITK_CALL(GRM_create_relation(latestrev,PdfDataset,relationSpeci_type,NULLTAG,&specificationRel_t));
									ITK_CALL(AOM_load(specificationRel_t));
									ITK_CALL(GRM_save_relation(specificationRel_t));
									if(specificationRel_t != NULLTAG)
									{
										tag_t PdfLatestDat_t=NULLTAG;

										printf("\n Spec rel found  \n");fflush(stdout);

										ITK_CALL(AOM_refresh(PdfDataset,TRUE));
										printf("\n Spec rel found  222222 [%s]\n",pdfpath );fflush(stdout);

										ITK_CALL(AE_ask_dataset_latest_rev(PdfDataset,&PdfLatestDat_t));
										ITK_CALL(AOM_refresh(PdfLatestDat_t,TRUE));

										//ITK_CALL(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference","/tmp/DFM_544249201659_B_3_30.pdf",NULL,SS_BINARY));
										ITK_CALL(AE_import_named_ref(PdfDataset,"PDF_Reference",pdfpath,NULL,SS_BINARY));

							

										printf("\n Spec rel found  333333333 \n");fflush(stdout);
										//CALLAPI(AE_import_named_ref(PdfLatestDat_t,"PDF_Reference",docFile,NULL,SS_BINARY));
										//ITK_CALL(AE_add_dataset_named_ref(tDataset,list[0],SS_BINARY,imannewFileTag));
													
										AOM_save(PdfLatestDat_t);
										AOM_refresh(PdfLatestDat_t, FALSE);
										AOM_unload(PdfLatestDat_t);
										ITK_CALL(AE_save_myself(PdfLatestDat_t));
										printf("\n AFTER IMPORTING NAMED REFERENCE \n");fflush(stdout);

										//return 0;

										printf("\n check in the 4D Doc \n");fflush(stdout);

										ITK_CALL(RES_is_checked_out(DADrevTag,&checkout));
										printf("\nValue of checkout Attribute in Checkin DADrevTag : [%d]\n",checkout);fflush(stdout);
										  if (checkout==1)
										  {
												ITK_CALL(RES_checkin(DADrevTag));
												printf("\n %d DADrevTag Checked In \n");
										  }									
										  
										ITK_CALL(RES_is_checked_out(PdfDataset,&checkout2));
										printf("\nValue of checkout Attribute in Checkin PdfDataset : [%d]\n",checkout2);fflush(stdout);
										  if (checkout2==1)
										  {
												ITK_CALL(RES_checkin(PdfDataset));
												printf("\n %d PdfDataset Checked In \n");
										  }
									

										ITK_CALL(WSOM_ask_release_status_list(latestrev, &status_count, &relStatus_list));
										if(status_count>0)
										{
											for(ss=0; ss<status_count ; ss++)
											{
												ITK_CALL(AOM_ask_value_string(relStatus_list[ss],"object_name",&latest_rev_Rel_Stus));
												printf("\n latest_rev_Rel_Stus: %s \n",latest_rev_Rel_Stus);fflush(stdout);
											
												if((strcmp(latest_rev_Rel_Stus,"ERC Review")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsReview")==0))
												{
													if (CR_create_release_status("T5_LcsReview",&status_rel));
													ITK_CALL( AOM_ask_name(status_rel, &ReleaseStatus));
													if(EPM_add_release_status(status_rel,1,&DADrevTag,retain));
													printf("\n after setting review status to the 4D Doc \n");fflush(stdout);

													//if (CR_create_release_status("T5_LcsReview",&status_relpdf));
													//ITK_CALL( AOM_ask_name(status_relpdf, &ReleaseStatuspdf));
													//if(EPM_add_release_status(status_relpdf,1,&PdfDataset,retainpdf));
													//printf("\n after setting review status to the 4D PDF \n");fflush(stdout);

												}

												else if((strcmp(latest_rev_Rel_Stus,"ERC Released")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsErcRlzd")==0))
												{
													if (CR_create_release_status("T5_LcsErcRlzd",&status_rel));
													ITK_CALL( AOM_ask_name(status_rel, &ReleaseStatus));
													if(EPM_add_release_status(status_rel,1,&DADrevTag,retain));
													printf("\n after setting release status to the 4D Doc \n");fflush(stdout);

													//if (CR_create_release_status("T5_LcsErcRlzd",&status_relpdf));
													//ITK_CALL( AOM_ask_name(status_relpdf, &ReleaseStatuspdf));
													//if(EPM_add_release_status(status_relpdf,1,&PdfDataset,retainpdf));
													//printf("\n after setting release status to the 4D PDF \n");fflush(stdout);
												}
											}
										}
//
//									
//										//ITK_CALL(RES_checkin(DADrevTag));
//										//printf("\n after check in the 4D Doc check in the pdf \n");fflush(stdout);
//										//ITK_CALL(RES_checkin(PdfDataset));
//										//printf("\n after pdf check in \n");fflush(stdout);
									}
								}
							}
						}
					}
				}
			}
		}
//		else if (tc_strstr(inputline,".xls")!=NULL) //FOR D01
//		{
//			printf("\n  XLS hence creating DFMEA doc ------------------->\n"); fflush(stdout);
//			xlspath1 = NULL;
//			xlspath1 = (char *) MEM_alloc(tc_strlen(inputline)+2);
//			tc_strcpy(xlspath1,inputline);
//
//			xlspath = NULL;
//			xlspath = MEM_alloc(150);
//			tc_strcpy(xlspath,"");
//			//tc_strcat(xlspath,"/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/PDFFiles");
//			tc_strcat(xlspath,"/user/uaprod/shells/4D");
//			tc_strcat(xlspath,"/");
//			tc_strcat(xlspath,xlspath1);
//
//			removeNewLineChar(xlspath);
//			printf("\n after removal xlspath ----------------->	[%s]\n ",xlspath);fflush(stdout);
//
//			Typetokxls =NULL;
//			Parttokxls =NULL;
//			PartRevtokxls =NULL;
//			PartSeqtokxls =NULL;
//			SerialNumtokxls =NULL;
//
//			Typetokxls = tc_strtok(inputlinenew, "_");// DFA
//			Parttokxls = tc_strtok(NULL, "_");		// 1234567
//			PartRevtokxls = tc_strtok(NULL, "_");	//NR
//			PartSeqtokxls = tc_strtok(NULL, "_");	//1
//			SerialNumtokxls = tc_strtok(NULL, "_");//01
//
//			printf("\n Typetok D01to find----------> = %s\n", Typetokxls);fflush(stdout);
//			printf("\n Parttok  D01to find----------> = %s\n", Parttokxls);fflush(stdout);
//			printf("\n PartRevtok D01 to find----------> = %s\n", PartRevtokxls);fflush(stdout);
//			printf("\n PartSeqtok D01 to find----------> = %s\n", PartSeqtokxls);fflush(stdout);
//			printf("\n SerialNumtok D01 to find----------> = %s\n", SerialNumtokxls);fflush(stdout);
//
//			//return 0;
//
//			nwRevxls		=	NULL;
//			nwRevxls		=(char *) MEM_alloc(10);
//			tc_strcpy(nwRevxls,"");
//			tc_strcat(nwRevxls,PartRevtokxls);
//			tc_strcat(nwRevxls,"*");
//			tc_strcat(nwRevxls,PartSeqtokxls);
//			printf("\n  nwRevxls to find----------> = %s\n", nwRevxls);fflush(stdout);
//
//			PartTypeSxls = (char	*)MEM_alloc(10);
//			tc_strcpy(PartTypeSxls,Typetokxls);
//			printf("\n PartTypeSxls= [%s]\n",PartTypeSxls);fflush(stdout);
//
//			PartNumberSxls = (char	*)MEM_alloc(50);
//			tc_strcpy(PartNumberSxls,Parttokxls);
//			printf("\n Part Number to find = [%s]\n",PartNumberSxls);fflush(stdout);
//
//			ITK_CALL(ITEM_find_item (PartNumberSxls,&Part_tagxls));
//			
//			if (Part_tagxls!=NULLTAG)
//			{
//				printf("\nPart_tag is not tag\n");fflush(stdout);
//			}
//			else
//			{
//				printf("\nPart_tag is null tag\n");fflush(stdout);
//			}
//
//			ITK_CALL(ITEM_ask_latest_rev(Part_tagxls,&latestrevxls));//latest rev of part
//
//			if( AOM_ask_value_string(latestrevxls,"object_string",&curentnamexls)==ITK_ok)
//
//			if( AOM_ask_value_string(latestrevxls,"t5_ProjectCode",&ProjctCdeSxls)==ITK_ok)
//
//			printf("\n Required revision---------------> [%s]and project code ---------->[%s]\n",curentnamexls,ProjctCdeSxls);fflush(stdout);
//
//			//return 0;
//			if(access(xlspath,F_OK)!=-1)
//			{
//				printf("\n FILE PRESENT qqqqqqqqqqqqqqqqqqqqqqqqqqqqQ  \n ");
//			}
//			else
//			{
//				printf("\n FILE NOT PRESENT qqqqqqqqqqqqqqqqqqqqqqqqqqqqQ  \n ");
//			}
//			system("pwd");
//
//		  if(tc_strcmp(ProjctCdeSxls,"2829")==0 || tc_strcmp(ProjctCdeSxls,"5442")==0 || tc_strcmp(ProjctCdeSxls,"5445")==0 || tc_strcmp(ProjctCdeSxls,"5447")==0 || tc_strcmp(ProjctCdeSxls,"5438")==0 || tc_strcmp(ProjctCdeSxls,"5457")==0)
//			{
//				printf("\n PROJECT CODE FOUND [%s] \n", ProjctCdeSxls);fflush(stdout);
//
//				if (tc_strstr(xlspath,".xlsx")!=NULL)
//				{
//					printf("\n XLSxxxxxx FOUND \n");fflush(stdout);
//					ITK_CALL(AE_find_datasettype2("MSExcelX",&DatasetTypexls));//CHECK THIS
//				}
//
//				else if (tc_strstr(xlspath,".xls")!=NULL)
//				{
//					printf("\n XLS FOUND \n");fflush(stdout);
//					ITK_CALL(AE_find_datasettype2("MSExcel",&DatasetTypexls));//CHECK THIS
//
//				}
//
//					if(tc_strcmp(PartTypeSxls,"D01")==0)
//					{
//						ITK_CALL(ITEM_find_item (DADNumber,&dad_tagxls));
//						if (dad_tagxls!=NULLTAG)
//						{
//							printf("\n  T5_DADDoc already exists \n");fflush(stdout);
//						}
//						else
//						{					
//							printf("\n  T5_DADDoc does not exist hence creating \n");fflush(stdout);
//							
//							//ITK_CALL( TCTYPE_find_type( "T5_Dfmea", NULL, &type_tag3xls) );
//							ITK_CALL(TCTYPE_find_types_for_class("T5_Dfmea",&number_of_types1xls,&type_tag3xls));//change this
//							printf("\n number_of_types T5_DADDoc-------->  : %d\n",number_of_types1xls);fflush(stdout);
//
//							ITK_CALL(TCTYPE_construct_create_input(type_tag3xls[0], &object_create_input_tag3xls));
//
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3xls,"item_id",DADNumber));
//							ITK_CALL(AOM_set_value_string(object_create_input_tag3xls,"object_desc","PFIRST DATA"));
//							ITK_CALL(TCTYPE_create_object(object_create_input_tag3xls, &dad_tagxls));//DFA Item Master
//							printf("\n DFMEA obj dad_tag created......\n");
//							ITK_CALL(AOM_save(dad_tagxls));
//							printf("\n afterrrrrrr 4d obj dad_tag created finding revision  now......\n");
//						}
//
//						//ITK_CALL(ITEM_find_revision(dad_tagxls,nwRev,&rev));
//						if(ITEM_ask_latest_rev(dad_tagxls,&DADrevTagxls))					//D01 Item Revision
//
//						printf("\n AFTER 4D_REV_TAG\n");fflush(stdout);
//						if(AOM_lock(DADrevTagxls));
//						ITK_CALL(AOM_set_value_string(DADrevTagxls,"t5_DsgnNum",DADNumber));
//						ITK_CALL(AOM_set_value_string(DADrevTagxls,"item_revision_id","A;1"));//NEW CHANGE
//						ITK_CALL(AOM_set_value_string(DADrevTagxls,"t5_DsgnAnlysisDocType",PartTypeSxls));//NEW CHANGE
//						if(AOM_save(DADrevTagxls));
//						if(AOM_unlock(DADrevTagxls));
//						printf("\n AFTER setting value on dad revision \n");fflush(stdout);
//					
//			
//						printf("\n CREATING RELATION BETWEEN PART AND DAD DOC\n");
//					
//						if(GRM_find_relation_type("T5_PartHasDfmea",&tRelationFindxls));
//
//						if (tRelationFindxls!=NULLTAG && DADrevTagxls !=NULLTAG )
//						  {
//							printf("\n TESTING HERE \n");fflush(stdout);
//							ITK_CALL( GRM_find_relation(latestrevxls,DADrevTagxls,tRelationFindxls,&tRelationExistxls)); 
//							
//							printf("\n AFTER TESTING HERE tRelationExistxls \n");fflush(stdout);
//							if(tRelationExistxls)
//							  {
//								 printf("\n tRelationExistxls tRelationExist tRelationExist \n");fflush(stdout);
//							  }
//							  else
//							  {
//								  printf("\n tRelationExistxls DOES NOT EXIST HENCE CREATING \n");fflush(stdout);
//								 ITK_CALL(GRM_create_relation(latestrevxls,DADrevTagxls,tRelationFindxls,NULLTAG,&DADRel_txls));//latest part revision and dad doc revision
//								 //ITK_CALL(GRM_create_relation(latestrev,dad_tag,tRelationFind,NULLTAG,&DADRel_t));
//								 ITK_CALL(GRM_save_relation(DADRel_txls));
//								 ITK_CALL(AOM_refresh(latestrevxls,0));
//							  }
//						  }
//							  
//					ITK_CALL(GRM_find_relation_type("IMAN_specification", &relationSpeci_typexls));
//				    //ITK_CALL(GRM_find_relation_type("TC_Attaches", &relationSpeci_type));
//					if(relationSpeci_typexls != NULLTAG)
//						{
//							printf("\n Attaches/IMAN SPECIFICATION Relationship tag found \n");fflush(stdout);
//							//ITK_CALL(AE_find_datasettype2("PDF",&DatasetType));
//							ITK_CALL(AE_create_dataset_with_id(DatasetTypexls,xlspath1,"Dataset Creation Tool","","",&XlsDataset));
//							ITK_CALL(AE_save_myself(XlsDataset));
//
//							printf("\n PDF created \n");fflush(stdout);
//
//							if(XlsDataset != NULLTAG)
//							{
//								printf("\n XlsDataset tag found as dataset registered \n");fflush(stdout);
//								ITK_CALL(GRM_create_relation(DADrevTagxls,XlsDataset,relationSpeci_typexls,NULLTAG,&specificationRel_txls));//dad doc revision and pdf
//								//ITK_CALL(GRM_create_relation(latestrev,XlsDataset,relationSpeci_type,NULLTAG,&specificationRel_t));
//								//ITK_CALL(AOM_load(specificationRel_t));
//								ITK_CALL(GRM_save_relation(specificationRel_txls));
//								if(specificationRel_txls != NULLTAG)
//								{
//									printf("\n Spec rel found  \n");fflush(stdout);
//
//									ITK_CALL(AOM_refresh(XlsDataset,TRUE));
//									ITK_CALL(AE_import_named_ref(XlsDataset,"excel",xlspath,NULL,SS_BINARY));//check this
//									//ITK_CALL(AE_add_dataset_named_ref(tDataset,list[0],SS_BINARY,imannewFileTag));
//
//									AOM_save(XlsDataset);
//									AOM_refresh(XlsDataset, FALSE);
//									AOM_unload(XlsDataset);
//									ITK_CALL(AE_save_myself(XlsDataset));
//									printf("\n AFTER IMPORTING NAMED REFERENCE \n");fflush(stdout);
//
//									printf("\n check in the 4D Doc \n");fflush(stdout);
//
//									ITK_CALL(RES_is_checked_out(DADrevTagxls,&checkoutxls));
//								    printf("\nValue of checkoutxls Attribute in Checkin DADrevTagxls : [%d]\n",checkoutxls);fflush(stdout);
//									  if (checkoutxls==1)
//									  {
//											ITK_CALL(RES_checkin(DADrevTagxls));
//											printf("\n %d DADrevTagxls Checked In \n");
//									  }									
//									  
//									ITK_CALL(RES_is_checked_out(XlsDataset,&checkout2xls));
//								    printf("\nValue of checkoutxls Attribute in Checkin PdfDataset : [%d]\n",checkout2xls);fflush(stdout);
//									  if (checkout2xls==1)
//									  {
//											ITK_CALL(RES_checkin(XlsDataset));
//											printf("\n %d XlsDataset Checked In \n");
//									  }
//								
//
//									ITK_CALL(WSOM_ask_release_status_list(latestrevxls, &status_countxls, &relStatus_listxls));
//									if(status_countxls>0)
//									{
//										for(ss1=0; ss1<status_countxls ; ss1++)
//										{
//											ITK_CALL(AOM_ask_value_string(relStatus_listxls[ss1],"object_name",&latest_rev_Rel_Stusxls));
//											printf("\n latest_rev_Rel_Stusxls: %s \n",latest_rev_Rel_Stusxls);fflush(stdout);
//										
//											if((tc_strcmp(latest_rev_Rel_Stusxls,"ERC Review")==0) || (tc_strcmp(latest_rev_Rel_Stusxls,"T5_LcsReview")==0))
//											{
//												if (CR_create_release_status("T5_LcsReview",&status_relxls));
//												ITK_CALL( AOM_ask_name(status_relxls, &ReleaseStatusxls));
//												if(EPM_add_release_status(status_relxls,1,&DADrevTagxls,retain));
//												printf("\n after setting review status to the 4D Doc \n");fflush(stdout);
//
//												//if (CR_create_release_status("T5_LcsReview",&status_relpdf));
//												//ITK_CALL( AOM_ask_name(status_relpdf, &ReleaseStatuspdf));
//												//if(EPM_add_release_status(status_relpdf,1,&PdfDataset,retainpdf));
//												//printf("\n after setting review status to the 4D PDF \n");fflush(stdout);
//
//											}
//
//											else if((tc_strcmp(latest_rev_Rel_Stusxls,"ERC Released")==0) || (tc_strcmp(latest_rev_Rel_Stusxls,"T5_LcsErcRlzd")==0))
//											{
//											   	if (CR_create_release_status("T5_LcsErcRlzd",&status_relxls));
//												ITK_CALL( AOM_ask_name(status_relxls, &ReleaseStatusxls));
//												if(EPM_add_release_status(status_relxls,1,&DADrevTagxls,retain));
//												printf("\n after setting release status to the 4D Doc \n");fflush(stdout);
//
//												//if (CR_create_release_status("T5_LcsErcRlzd",&status_relpdf));
//												//ITK_CALL( AOM_ask_name(status_relpdf, &ReleaseStatuspdf));
//												//if(EPM_add_release_status(status_relpdf,1,&PdfDataset,retainpdf));
//												//printf("\n after setting release status to the 4D PDF \n");fflush(stdout);
//											}
//										}
//									}
//
//								
//									//ITK_CALL(RES_checkin(DADrevTag));
//									//printf("\n after check in the 4D Doc check in the pdf \n");fflush(stdout);
//									//ITK_CALL(RES_checkin(PdfDataset));
//									//printf("\n after pdf check in \n");fflush(stdout);
//								}
//							}
//						}					
//					}
//				//}
//			}
//
//		}
//		++line_count;
	 }

  }
  else
  {
	printf("\n Error while opening input file \n");
	exit(1);
  } 

  
  if(fptr)
	  {
	   fclose(fptr);fptr=NULL;
	  }
  return status;
}
;

