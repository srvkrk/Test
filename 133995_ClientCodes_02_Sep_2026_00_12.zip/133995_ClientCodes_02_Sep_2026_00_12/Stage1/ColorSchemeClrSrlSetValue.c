				#include <stdio.h>
				#include <stdlib.h>
				#include <string.h>
				#include <unidefs.h>
				//#include <itk/mem.h>
				#include <tcinit/tcinit.h>
				#include <tccore/item.h>
				#include <bom/bom.h>
				#include <cfm/cfm.h>
				#include <ps/ps_errors.h>
				#include <tccore/item_errors.h>
				#include <tc/emh.h>
				#include <time.h>
				#include <ae/dataset.h>
				#include <tccore/tctype.h>
				#include <pom/pom/pom.h>
				#include <pie/pie.h>	
				#define Debug TRUE
				#define ITK_CALL(X) 							\
					if(Debug)								\
					{										\
						printf(#X);							\
					}										\
					fflush(NULL);							\
					status=X; 							    \
					if (status != ITK_ok ) 					\
					{										\
						int				index = 0;			\
						int				n_ifails = 0;		\
						const int*		severities = 0;		\
						const int*		ifails = 0;			\
						const char**	texts = NULL;		\
															\
						EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
						printf("\t%3d error(s)\n", n_ifails);							\
						for( index=0; index<n_ifails; index++)							\
						{																\
							printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
						}																\
						return status;													\
					}																	\
					else									\
					{										\
						if(Debug)							\
						printf("\tSUCCESS\n");				\
					}										\

				#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
				#define MAX_LEN 100
				static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute;
				static void initialise (void);
				static void initialise_attribute (char *name,  int *attribute);
				tag_t FunToReturnLatestRevision(char *Item_ID);
				tag_t FunToReturnLatestRelzRevision(char *Item_ID);
				int createDatasetSuffixFixTable(FILE* fp);
				int createDatasetClrPart(FILE* fp);
				static void ExpandMultiLevelBom (tag_t bom_line_tag, int depth,FILE *fptr,FILE *fptrP,FILE *fptrC,FILE *fptrA,char* sbl_item_id,char* sbl_rev_id,char* sParentCompCode,char* sParentColID);

				tag_t LatestRev = NULLTAG;
				char *reportfile =NULL;
				char *rptFixTblMstrClrSchm=NULL;
				tag_t 	class_to_load_as;
				FILE* fplog = NULL;
				FILE* fReport = NULL;
				FILE* fMstClrSchRpt=NULL;
				int 	lock_type = POM_no_lock;
				char *matchclrPart= NULL;
				char *PoclrPart=NULL;
				//Start for Implosion Dcl
				void WhereUsed(tag_t partTag);
				int WhereUsedPo(tag_t partTag);
				int vcflag=0;
				//FILE *ImplosionReport = NULL;
				//FILE *ImplosionReportDatew = NULL;
				//int	 levl			  = 0;
				char *topLevelVC= NULL;
				struct tm old_date = {0};
				int oYears=0;
				int oMonth=0;
				int oDate= 0;
				struct tm latest_date = {0};
				int lYears=0;
				int lMonth=0;
				int lDate= 0;
				int vcCnt=0;
				int oldvcCnt=0;
				char* allUniqueVC= NULL;
				char* modulelist= NULL;
				tag_t *tagSET;
				int DRFlag =0;
				int ia =0;
				char **sFinalDataSet;
			  
			 
		static int PrintErrorStack( void )
		/*
		*
		* PURPOSE : Function to dump the ITK error stack
		*
		* RETURN : causes program termination. If you made it here
		*          you're not coming back modified for cust.c to not call exit()
		*          but to just print the error stack
		*
		* NOTES : This version will always return ITK_ok, which is quite strange
		*           actually. But if the error reporting was "OK" then that makes
		*           sense
		*
		*/
		{
			int iNumErrs = 0;
			const int *pSevLst;
			const int *pErrCdeLst;
			const char **pMsgLst;
			register int i = 0;

			EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
			//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
			for ( i = 0; i < iNumErrs; i++ )
			{
				fprintf( stderr, "Error(PrintErrorStack): \n");
				fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
			}
			return ITK_ok;
		}

				 //End for Implosion Dcl

				// Defining comparator function as per the requirement
				static int myCompare(const void* a, const void* b)
				{

					// setting up rules for comparison
					return strcmp(*(const char**)a, *(const char**)b);
				}

				// Function to sort the array
				//void sort(const char* arr[], int n)
				void sort( char* arr[], int n)
				{
					// calling qsort function to sort the array
					// with the help of Comparator
					qsort(arr, n, sizeof( char*), myCompare);
				}
				char* subString (char* mainStringf, int fromCharf, int toCharf)
				{
					int i;
					char *retStringf;
					retStringf = (char*) malloc(3);
					for(i=0; i < toCharf; i++ )
							  *(retStringf+i) = *(mainStringf+i+fromCharf);
					*(retStringf+i) = '\0';
					return retStringf;
				}
				void selectionSort(char name[][MAX_LEN], int n)
				{
					int i=0,j=0;
					char* temp=NULL;
					temp=(char *) MEM_alloc(100);

					printf("\n in selectionSort %d \n",n);fflush(stdout);

					for (i = 0; i < n - 1 ; i++)
					{
					for (j = i + 1; j < n; j++)
					{
					if (strcmp(name[i], name[j]) > 0)
					{
					strcpy(temp, name[i]);
					strcpy(name[i], name[j]);
					strcpy(name[j], temp);
					}
					}
					}

					 for (i = 0; i < n; i++)
					 {
						 printf("\t%s\n", name[i]);
					 }


					printf("\n end selectionSort \n");fflush(stdout);
				}
				char *replaceWord(const char *s, const char *oldW, const char *newW)
				{
					char *result;
					int i, cnt = 0;
					int newWlen = strlen(newW);
					int oldWlen = strlen(oldW);

					// Counting the number of times old word
					// occur in the string
					for (i = 0; s[i] != '\0'; i++)
					{
						if (strstr(&s[i], oldW) == &s[i])
						{
							cnt++;

							// Jumping to index after the old word.
							i += oldWlen - 1;
						}
					}

					// Making new string of enough length
					result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

					i = 0;
					while (*s)
					{
						// compare the substring with the result
						if (strstr(s, oldW) == s)
						{
							strcpy(&result[i], newW);
							i += newWlen;
							s += oldWlen;
						}
						else
							result[i++] = *s++;
					}

					result[i] = '\0';
					return result;
				}
				// fun To Find String is present in array.
				void setFindStr(char **str_list,int count,char *str,int *found)
				{

					int k=0;
					*found=0;
					for(k=0;k<count;k++)
					{

						//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
						if(tc_strcmp(str_list[k],str)==0)
						{
							*found=1;
							printf("\n str found in str_list \n");
							break;
						}

					}
				}
				// fun to find array values contains strstr some string
				void setGetStrStr(char **str_list,int count,char *str,char *str1,int *found)
				{

					int k=0;
					*found=0;
					for(k=0;k<count;k++)
					{

						//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
						if((tc_strstr(str_list[k],str)!=NULL) && (tc_strstr(str_list[k],str1)!=NULL))
						{
							*found=1;
							break;
						}

					}
				}
				void setAddStr(int *count,char ***strset,char* str)
				{

					*count=*count+1;
					printf("\n setAddStr %d",*count);fflush(stdout);
					if(*count==1)
					{
						(*strset) = (char **)malloc((*count ) * sizeof(char *));
					}
					else
					{
						(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
					}
					(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
					 tc_strcpy((*strset)[*count-1],str);
					 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

				}
				void setAddStr1(int *count,char ***strset,char* str)
				{

					*count=*count+1;
					printf("\n setAddStr1 %d",*count);fflush(stdout);
					if(*count==1)
					{
						(*strset) = (char **)malloc((*count ) * sizeof(char *));
					}
					else
					{
						(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
					}
					(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
					 tc_strcpy((*strset)[*count-1],str);
					 printf("\n setAddStr1===%s",(*strset)[*count-1]);fflush(stdout);

				}
				 int returnmin(int a[],int n)
				 {
					int min,max,i;
					min=max=a[0];
					for(i=1; i<n; i++)
					{
						 if(min>a[i])
						  min=a[i];
						   if(max<a[i])
							max=a[i];
					}

					printf("minimum of array is : %d",min);
					printf("\nmaximum of array is : %d",max);
					return min;
				 }
				int IsDesignRevisionAvail(char* InputPart)
				{
					int		IsAvailInUA		=	0;
					tag_t   OutPutTag		=	NULLTAG;
					int		n_tags_found2	=	0;
					tag_t	*tags_found2	=	NULL;

					//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
					//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
					int		n_tags_foundd2	=	0;
					tag_t	*tags_foundd2	=	NULL;
					//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
					//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
					const char *attrss2[2];
					const char *valuess2[2];
					//MT end
					//fprintf(fplog,"\t sOldSuf %s spartnumber [%s]\n",sOldSuf,spartnumber); fflush(fplog);
					fprintf(fplog,"\n FUN:part no :%s.", InputPart);fflush(fplog);
					//GETTING RELEASED REVISION
					const char *attrs2[1];
					const char *values2[1];
					attrs2[0] ="item_id";
					//attrs2[1] ="object_type";
					values2[0] = (char *)InputPart;
					//values2[1] = "Colour Part";
					if(ITEM_find_items_by_key_attributes(1,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok);
					fprintf(fplog,"\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(fplog);

					if (n_tags_found2>0)
					{
						OutPutTag= tags_found2[0];
						IsAvailInUA = 1;
						fprintf(fplog,"\n Part found in TCUA:");fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Part not found in TCUA:");fflush(fplog);
						IsAvailInUA = 0;
					}
					return IsAvailInUA;
				}
		void GetInfo(tag_t partTag)
		{
			char		*ParentItemID			= NULL;
			char		*obj_type				= NULL;
			char		*partType				= NULL;
			char		*rev					= NULL;
			char		*desc					= NULL;
			char		*modDesc				= NULL;
			char		*keyDesc				= NULL;
			char		*projectCode			= NULL;
			char		*designGrp				= NULL;
			char		*ownerDesUnit			= NULL;
			char		*partCatgory			= NULL;
			char		*drawingInd				= NULL;
			char		*material				= NULL;
			double		weight					= 0;
			char		*materialThickness		= NULL;
			char		*matlClass				= NULL;
			char		*envelopeDimensions		= NULL;
			char		*owner					= NULL;
			char		*drStatus				= NULL;
			char		*rolledupWeight			= NULL;
			char		*uom					= NULL;
			char		*Rlstatus1				= NULL;
			char		*t5PunMakeBuyIndS		= NULL;
			
			printf("*****************Printing in Report*****************\n");fflush(stdout);

			if(AOM_ask_value_string(partTag,"item_id",&ParentItemID));
			printf("ParentItemID: [%s] \t",ParentItemID);fflush(stdout);

			printf("\n[%s] Will pass to WhereUsed function\n",ParentItemID);fflush(stdout);
			WhereUsed(partTag);
			printf("\n End Function GetInfo in Recursive: \t");fflush(stdout);

		}
		void WhereUsed(tag_t partTag)
		{
			int			n_parents				= 0;
			int			*levels					= 0;
			tag_t		*parents				= NULLTAG;
			tag_t		parentMaster			= NULLTAG;
			tag_t		ParentRevTag			= NULLTAG;
			int			parCtr					= 0;
			char		*ParentItemID			= NULL;
			char		*obj_type				= NULL;
			char		*partType				= NULL;
			char		*t5_DRStatus			= NULL;
			char        *RelStatuslist          = NULL;
			tag_t item_id_tag =NULLTAG;
			tag_t*	item_rev_list	= NULLTAG;
			tag_t LatRelzRevision = NULLTAG;
			char		*sitem_id =NULL;
			int mn =0 ;
			int n_rev =0;
			int status;
			 int oflag=0;
			 int pflag=0;
			printf("Inside WhereUsed Function.......\n");fflush(stdout);

			if(PS_where_used_all(partTag,1,&n_parents,&levels,&parents))PrintErrorStack();
			printf("PS_where_used_all count of objects : [%d]  \n",n_parents); fflush(stdout);

			if(n_parents > 0)
			{
				//levl = levl+1;
				for (parCtr = 0; parCtr < n_parents; parCtr++) 
				{
						 parentMaster = NULLTAG;
						 ParentRevTag	= NULLTAG;
						  ParentItemID			= NULL; 
						  obj_type				= NULL; 
						  partType				= NULL; 
						  t5_DRStatus			= NULL; 



					if(ITEM_ask_item_of_rev(parents[parCtr], &parentMaster)!=ITK_ok);
					if(ITEM_ask_latest_rev(parentMaster,&ParentRevTag)!=ITK_ok); // ERC Released
                    if(AOM_ask_value_string(ParentRevTag,"item_id",&ParentItemID));
                    if(ITEM_find_item(ParentItemID,&item_id_tag));
					if(ITEM_list_all_revs(item_id_tag,&n_rev,&item_rev_list));
					if(n_rev > 0)
					{

						for(mn = n_rev-1 ; mn >= 0 ; mn--)
							{
								if(AOM_UIF_ask_value (item_rev_list[mn], "release_status_list", &RelStatuslist));
								if((tc_strstr(RelStatuslist,"ERC Released")!=NULL)||(tc_strstr(RelStatuslist,"T5_LcsErcRlzd")!=NULL))
								{
									LatRelzRevision=item_rev_list[mn];
									if(AOM_ask_value_string(LatRelzRevision,"item_id",&sitem_id));
									//fprintf(fplog,"\n sitem_id: %s \n\n",sitem_id);	 fflush(fplog);
									break;
								}

							}
					}

					if(LatRelzRevision != NULLTAG)
					{
						if(AOM_ask_value_string(LatRelzRevision,"item_id",&ParentItemID));
						if(AOM_UIF_ask_value(LatRelzRevision,"object_type",&obj_type)!=ITK_ok);
						if(AOM_ask_value_string(LatRelzRevision,"t5_PartType",&partType)!=ITK_ok);
						if(AOM_ask_value_string(ParentRevTag,"t5_DRStatus",&t5_DRStatus)!=ITK_ok);
						printf(" BOM is ..%s %s\n",partType,ParentItemID);fflush(stdout);			
						//skipp Colour Part Revision & part type Dummy, IFD, R, SA, SC
						
					if(tc_strcmp(partType,"M")==0 ||(tc_strcmp(partType,"V")==0))
					 {
						   printf("\n Colour Module   == %s\n",ParentItemID);fflush(stdout);
						   char *sModuleid=subString(ParentItemID,0,14);
                        if (tc_strstr(modulelist,subString(ParentItemID,0,14))!=NULL)
							{
                               printf("\n Matching Colour Module   == %s\n",ParentItemID);fflush(stdout);
							  vcflag=1;

							  break;

							}
							else
							{
								GetInfo(ParentRevTag);   
						
							}
                            
						if(tc_strcmp(partType,"V")==0)
						{
							
							 printf("Top level BOM is ..%s %s\n",partType,ParentItemID);fflush(stdout);
							 if(strcmp(t5_DRStatus,"DR3P")==0 || strcmp(t5_DRStatus,"DR4")==0 || strcmp(t5_DRStatus,"AR3P")==0 || strcmp(t5_DRStatus,"DR5")==0 || strcmp(t5_DRStatus,"AR4")==0 || strcmp(t5_DRStatus,"AR5")==0)
							 {
								
							   printf("\n ParentItemID  ==%s\n",ParentItemID);fflush(stdout);
							   if (strcmp(allUniqueVC,"")==0 || strcmp(allUniqueVC,"NULL")==0)
								 {
									strcat(allUniqueVC,ParentItemID);
									strcat(allUniqueVC,",");
									printf("\n if allUniqueVC allUniqueVC  ==%s\n",allUniqueVC);fflush(stdout);
									vcCnt++;
								 }
								else if (strstr(allUniqueVC,ParentItemID)==NULL)
								{
								  strcat(allUniqueVC,ParentItemID);
								  strcat(allUniqueVC,",");
								
								vcCnt++;
								printf("\n all Vehicle Count  ==[%d]\n",vcCnt);fflush(stdout);
								
								//printf("\n else if allUniqueVC allUniqueVC  ==%s\n",allUniqueVC);fflush(stdout);

			
								
								int   n_referencers					 = 0;
								int   *levels					 = 0;
								tag_t *	referencers;
								char ** relationsRef;
								int ii=0;
								char * ItemIDn=NULL;
								char*    MPartNo				 = NULL;
								tag_t class_id = NULLTAG;
								char *class_name=NULL;
							   
								int   n_referencers1					 = 0;						
								int   *levels1					 = 0;
								tag_t *	referencers1;
								char ** relationsRef1;
								int ij=0;
								char * ItemIDn1;
								char*    MPartNo1				 = NULL;
								tag_t class_id1 = NULLTAG;
								char *class_name1=NULL;

								tag_t tsk_dml_rel_type=NULLTAG;
								int dmlcount=0;
								tag_t	*DMLRevision	= NULLTAG;
								  int k=0;
								  tag_t DMLRevTag=NULLTAG;
								  char *DmlName=NULL;
								  char *DMLtype=NULL;
								  char *DMLClsuDate=NULL;
								  char *clRlzDate=NULL;
								  char *RlzDateString=NULL;
								  struct tm tm;
							   if(strcmp(t5_DRStatus,"DR4")==0 || strcmp(t5_DRStatus,"DR5")==0 || strcmp(t5_DRStatus,"AR4")==0 || strcmp(t5_DRStatus,"AR5")==0)
								{
							//	   DRFlag=1;
							//	WSOM_where_referenced(LatRelzRevision,1,&n_referencers,&levels,&referencers,&relationsRef);
							//	printf("\n DR4 WSOM_where_referenced n_referencers  ==%d\n",n_referencers);fflush(stdout);
							//	if (n_referencers>0)
							//	{
							//		for (ii=0;ii<n_referencers;ii++)
							//		{
							//			tsk_dml_rel_type=NULLTAG;
							//			ItemIDn=NULL;
							//			class_name=NULL;
							//			class_id = NULLTAG;
							//			
							//		  printf("\n inside for single ittem  ==%d\n",ii);fflush(stdout);
							//		 POM_class_of_instance	(referencers[ii],&class_id);
							//		 POM_name_of_class	(class_id,& class_name);
							//		 printf("\n CLASS NAME FOR ITEM ==%s\n",class_name);fflush(stdout);
							//		WSOM_ask_name2(referencers[ii],&MPartNo);
							//		printf("\n Name of refered data is  ==%s\n",MPartNo);fflush(stdout);
							//		WSOM_ask_object_id_string(referencers[ii],&ItemIDn);
							//		printf("\n Item Id ==%s\n",ItemIDn);fflush(stdout);	
							//		if (strcmp(ItemIDn,"Parts For Gate Maturation")==0)
							//		{
							//			printf("\n Inside IF CLASS NAME FOR ITEM ==\n");fflush(stdout);
							//		   WSOM_where_referenced(referencers[ii],1,&n_referencers1,&levels1,&referencers1,&relationsRef1);
							//		  
							//		   if (n_referencers1>0)
							//		   {
							//		   for (ij=0;ij<n_referencers1;ij++)
							//		   {
							//		  
							//		   POM_class_of_instance	(referencers1[ij],&class_id1);
							//		   POM_name_of_class	(class_id1,& class_name1);
							//		   printf("\n 1.CLASS NAME FOR ITEM ==%s\n",class_name1);fflush(stdout);
							//		   WSOM_ask_name2(referencers1[ij],&MPartNo1);
							//		   printf("\n 1.Name of refered data is  ==%s\n",MPartNo1);fflush(stdout);
							//		   WSOM_ask_object_id_string(referencers1[ij],&ItemIDn1);
							//		   printf("\n 1.Item Id ==%s\n",ItemIDn1);fflush(stdout);	
							//
							//			if (strcmp(class_name1,"T5_ChangeTaskRevision")==0)
							//			{
							//			  if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
							//			   if(GRM_list_primary_objects_only(referencers1[ij],tsk_dml_rel_type,&dmlcount,&DMLRevision));
							//				  for (k=0;k<dmlcount ;k++ )
							//						{
							//						   DMLRevTag = DMLRevision[k];
							//							DMLClsuDate=NULL;
							//						   if(AOM_ask_value_string(DMLRevTag, "item_id",&DmlName));
							//							printf("\n GM DmlName %s.....\n",DmlName);fflush(stdout);
							//
							//							if(AOM_UIF_ask_value(DMLRevTag,"t5_rlstype",&DMLtype));
							//							printf("\nGM DMLtype :%s",DMLtype);fflush(stdout);
							//
							//						   if(AOM_UIF_ask_value(DMLRevTag,"date_released",&DMLClsuDate));
							//						   printf("\n GM date_released :%s",DMLClsuDate);fflush(stdout);
							//						   if (strlen(DMLClsuDate)>0)
							//						   {
							//						   
							//							 clRlzDate= strtok(DMLClsuDate," ");
							//
							//							   if(strstr(clRlzDate,"JAN")!=NULL)
							//								{
							//								   STRNG_replace_str(clRlzDate,"JAN","01",&RlzDateString);
							//								}
							//								else if (strstr(clRlzDate,"Feb")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Feb","02",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Mar")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Mar","03",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Apr")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Apr","04",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"May")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"May","05",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Jun")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Jun","06",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Jul")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Jul","07",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Aug")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Aug","08",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Sep")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Sep","09",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Oct")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Oct","10",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Nov")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Nov","11",&RlzDateString);
							//								}
							//								else
							//								{
							//									STRNG_replace_str(clRlzDate,"Dec","12",&RlzDateString);
							//								}
							//
							//								char* sDate=strtok(RlzDateString,"-");
							//								int iDate=atoi(sDate);
							//								char* sMonth=strtok(NULL,"-");
							//								int iMonth=atoi(sMonth);
							//								char* sYears=strtok(NULL,"-");
							//								int iYears=atoi(sYears);
							//								struct tm new_date = {0};
							//								 new_date.tm_year = iYears - 1900;  // Year since 1900
							//								 new_date.tm_mon = iMonth - 1;         // Month (0-based, so 5 for June)
							//								 new_date.tm_mday = iDate;
							//								 if (oflag==0)
							//								 {
							//									oYears=iYears;
							//									oMonth=iMonth;
							//									oDate= iDate;
							//									topLevelVC = (char *) MEM_alloc(5000 * sizeof(char));
							//									strcpy(topLevelVC,"");
							//									strcat(topLevelVC,",");
							//									strcat(topLevelVC,ParentItemID);
							//									strcat(topLevelVC,",");
							//									strcat(topLevelVC,t5_DRStatus);
							//									strcat(topLevelVC,",");
							//									strcat(topLevelVC,DmlName);
							//									strcat(topLevelVC,",");
							//									strcat(topLevelVC,DMLtype);
							//									strcat(topLevelVC,",");
							//									strcat(topLevelVC,clRlzDate);
							//
							//									oflag++;
							//								 }
	 						//
							//																						
							//								 old_date.tm_year = oYears - 1900;  
							//								 old_date.tm_mon = oMonth - 1;         
							//								 old_date.tm_mday = oDate;
							//								printf("\n old date part1= %d-%d-%d",old_date.tm_mday,old_date.tm_mon,old_date.tm_year);
							//								printf("\n New Date Part2= %d-%d-%d",new_date.tm_mday,new_date.tm_mon,new_date.tm_year);
							//								 
							//								 time_t new_time = mktime(&new_date);
							//								 time_t old_time = mktime(&old_date);
							//								
							//								if (new_time > old_time) 
							//									{
							//
							//										oYears=iYears;
							//										oMonth=iMonth;
							//										oDate= iDate;
							//										printf("\n The new date is later than the old date.\n");
							//										printf("\n new Date= %d-%d-%d",new_date.tm_mday,new_date.tm_mon,new_date.tm_year);
							//										topLevelVC = (char *) MEM_alloc(5000 * sizeof(char));
							//										 strcpy(topLevelVC,"");
							//										 strcat(topLevelVC,",");
							//										 strcat(topLevelVC,ParentItemID);
							//										 strcat(topLevelVC,",");
							//										 strcat(topLevelVC,t5_DRStatus);
							//										 strcat(topLevelVC,",");
							//										 strcat(topLevelVC,DmlName);
							//										 strcat(topLevelVC,",");
							//										 strcat(topLevelVC,DMLtype);
							//										 strcat(topLevelVC,",");
							//										 strcat(topLevelVC,clRlzDate);
							//										 pflag==1;
							//
							//								   } else if (new_time < old_time) {
							//
							//									 printf("\n The new date is earlier than the old date.\n");
							//									printf("\n old date= %d-%d-%d",old_date.tm_mday,old_date.tm_mon,old_date.tm_year);
							//
							//								 } else {
							//
							//									   printf("\n The dates are the same.\n");
							//								 } 
							//
							//
							//
							//								  printf("\n topLevelVC.........%s\n",topLevelVC);
							//
							//						}
							//						else
							//							{
							//							   printf("\n GM date_released  is Empty %s\n",DMLClsuDate);
							//							}
							//
							//						}
							//
							//			}
							//
							//
							//		   }
							//		  }
							//
							//		}
							//		else
							//		  {
							//			printf("\n Inside else CLASS NAME FOR ITEM ==\n");fflush(stdout);
							//		  }
							//		
							//
							//		}
							//	
							//	}
								}

							// if (DRFlag=0)
							// {
							//   
							//	WSOM_where_referenced(LatRelzRevision,1,&n_referencers,&levels,&referencers,&relationsRef);
							//	printf("\n DR3 WSOM_where_referenced n_referencers  ==%d\n",n_referencers);fflush(stdout);
							//	if (n_referencers>0)
							//	{
							//		for (ii=0;ii<n_referencers;ii++)
							//		{
							//			tsk_dml_rel_type=NULLTAG;
							//			ItemIDn=NULL;
							//			class_name=NULL;
							//			class_id = NULLTAG;
							//			
							//		  printf("\n inside for single ittem  ==%d\n",ii);fflush(stdout);
							//		 POM_class_of_instance	(referencers[ii],&class_id);
							//		 POM_name_of_class	(class_id,& class_name);
							//		 printf("\n CLASS NAME FOR ITEM ==%s\n",class_name);fflush(stdout);
							//		WSOM_ask_name2(referencers[ii],&MPartNo);
							//		printf("\n Name of refered data is  ==%s\n",MPartNo);fflush(stdout);
							//		WSOM_ask_object_id_string(referencers[ii],&ItemIDn);
							//		printf("\n Item Id ==%s\n",ItemIDn);fflush(stdout);	
							//		if (strcmp(ItemIDn,"Parts For Gate Maturation")==0)
							//		{
							//			printf("\n Inside IF CLASS NAME FOR ITEM ==\n");fflush(stdout);
							//		   WSOM_where_referenced(referencers[ii],1,&n_referencers1,&levels1,&referencers1,&relationsRef1);
							//		  
							//		   if (n_referencers1>0)
							//		   {
							//		   for (ij=0;ij<n_referencers1;ij++)
							//		   {
							//		  
							//		   POM_class_of_instance	(referencers1[ij],&class_id1);
							//		   POM_name_of_class	(class_id1,& class_name1);
							//		   printf("\n 1.CLASS NAME FOR ITEM ==%s\n",class_name1);fflush(stdout);
							//		   WSOM_ask_name2(referencers1[ij],&MPartNo1);
							//		   printf("\n 1.Name of refered data is  ==%s\n",MPartNo1);fflush(stdout);
							//		   WSOM_ask_object_id_string(referencers1[ij],&ItemIDn1);
							//		   printf("\n 1.Item Id ==%s\n",ItemIDn1);fflush(stdout);	
							//
							//			if (strcmp(class_name1,"T5_ChangeTaskRevision")==0)
							//			{
							//			  if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type));
							//			   if(GRM_list_primary_objects_only(referencers1[ij],tsk_dml_rel_type,&dmlcount,&DMLRevision));
							//				  for (k=0;k<dmlcount ;k++ )
							//						{
							//						   DMLRevTag = DMLRevision[k];
							//							DMLClsuDate=NULL;
							//						   if(AOM_ask_value_string(DMLRevTag, "item_id",&DmlName));
							//							printf("\n GM DmlName %s.....\n",DmlName);fflush(stdout);
							//
							//							if(AOM_UIF_ask_value(DMLRevTag,"t5_rlstype",&DMLtype));
							//							printf("\nGM DMLtype :%s",DMLtype);fflush(stdout);
							//
							//						   if(AOM_UIF_ask_value(DMLRevTag,"date_released",&DMLClsuDate));
							//						   printf("\n GM date_released :%s",DMLClsuDate);fflush(stdout);
							//						   if (strlen(DMLClsuDate)>0)
							//						   {
							//						   
							//							 clRlzDate= strtok(DMLClsuDate," ");
							//
							//							   if(strstr(clRlzDate,"JAN")!=NULL)
							//								{
							//								   STRNG_replace_str(clRlzDate,"JAN","01",&RlzDateString);
							//								}
							//								else if (strstr(clRlzDate,"Feb")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Feb","02",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Mar")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Mar","03",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Apr")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Apr","04",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"May")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"May","05",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Jun")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Jun","06",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Jul")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Jul","07",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Aug")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Aug","08",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Sep")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Sep","09",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Oct")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Oct","10",&RlzDateString);
							//								}
							//								else if(strstr(clRlzDate,"Nov")!=NULL)
							//								{
							//									STRNG_replace_str(clRlzDate,"Nov","11",&RlzDateString);
							//								}
							//								else
							//								{
							//									STRNG_replace_str(clRlzDate,"Dec","12",&RlzDateString);
							//								}
							//
							//								char* sDate=strtok(RlzDateString,"-");
							//								int iDate=atoi(sDate);
							//								char* sMonth=strtok(NULL,"-");
							//								int iMonth=atoi(sMonth);
							//								char* sYears=strtok(NULL,"-");
							//								int iYears=atoi(sYears);
							//								struct tm new_date = {0};
							//								 new_date.tm_year = iYears - 1900;  // Year since 1900
							//								 new_date.tm_mon = iMonth - 1;         // Month (0-based, so 5 for June)
							//								 new_date.tm_mday = iDate;
							//								 if (oflag==0)
							//								 {
							//									oYears=iYears;
							//									oMonth=iMonth;
							//									oDate= iDate;
							//									topLevelVC = (char *) MEM_alloc(5000 * sizeof(char));
							//									strcpy(topLevelVC,"");
							//									strcat(topLevelVC,",");
							//									strcat(topLevelVC,ParentItemID);
							//									strcat(topLevelVC,",");
							//									strcat(topLevelVC,t5_DRStatus);
							//									strcat(topLevelVC,",");
							//									strcat(topLevelVC,DmlName);
							//									strcat(topLevelVC,",");
							//									strcat(topLevelVC,DMLtype);
							//									strcat(topLevelVC,",");
							//									strcat(topLevelVC,clRlzDate);
							//
							//									oflag++;
							//								 }
	 						//
							//																						
							//								 old_date.tm_year = oYears - 1900;  
							//								 old_date.tm_mon = oMonth - 1;         
							//								 old_date.tm_mday = oDate;
							//								printf("\n old date part1= %d-%d-%d",old_date.tm_mday,old_date.tm_mon,old_date.tm_year);
							//								printf("\n New Date Part2= %d-%d-%d",new_date.tm_mday,new_date.tm_mon,new_date.tm_year);
							//								 
							//								 time_t new_time = mktime(&new_date);
							//								 time_t old_time = mktime(&old_date);
							//								
							//								if (new_time > old_time) 
							//									{
							//
							//										oYears=iYears;
							//										oMonth=iMonth;
							//										oDate= iDate;
							//										printf("\n The new date is later than the old date.\n");
							//										printf("\n new Date= %d-%d-%d",new_date.tm_mday,new_date.tm_mon,new_date.tm_year);
							//										topLevelVC = (char *) MEM_alloc(5000 * sizeof(char));
							//										 strcpy(topLevelVC,"");
							//										 strcat(topLevelVC,",");
							//										 strcat(topLevelVC,ParentItemID);
							//										 strcat(topLevelVC,",");
							//										 strcat(topLevelVC,t5_DRStatus);
							//										 strcat(topLevelVC,",");
							//										 strcat(topLevelVC,DmlName);
							//										 strcat(topLevelVC,",");
							//										 strcat(topLevelVC,DMLtype);
							//										 strcat(topLevelVC,",");
							//										 strcat(topLevelVC,clRlzDate);
							//										 pflag==1;
							//
							//								   } else if (new_time < old_time) {
							//
							//									 printf("\n The new date is earlier than the old date.\n");
							//									printf("\n old date= %d-%d-%d",old_date.tm_mday,old_date.tm_mon,old_date.tm_year);
							//
							//								 } else {
							//
							//									   printf("\n The dates are the same.\n");
							//								 } 
							//
							//
							//
							//								  printf("\n topLevelVC.........%s\n",topLevelVC);
							//
							//						}
							//						else
							//							{
							//							   printf("\n GM date_released  is Empty %s\n",DMLClsuDate);
							//							}
							//
							//						}
							//
							//			}
							//
							//
							//		   }
							//		  }
							//
							//		}
							//		else
							//		  {
							//			printf("\n Inside else CLASS NAME FOR ITEM ==\n");fflush(stdout);
							//		  }
							//		
							//
							//		}
							//	
							//	}
							//
							//
							// }


							 }
							 else
								 {
								  printf("\n  Vehicle already present \n");fflush(stdout);
								 }

						}
						else
							{
						  printf("\n  else DR status ==\n");fflush(stdout);
							}
								
						}
						else
						{
							GetInfo(ParentRevTag); 
						}
					}
					else
					{
						GetInfo(ParentRevTag); 
					}

						printf("lopping .............%d\n",parCtr);fflush(stdout);
					}

					printf("inside  for WhereUsed Function.......\n");fflush(stdout);
				}
			
				printf("\n outof for WhereUsed Function.......\n");fflush(stdout);
				//levl = levl-1;
			}
			printf("\n End WhereUsed Function.......\n");fflush(stdout);
		}

		void GetInfoPo(tag_t partTag)
		{
			char		*ParentItemID			= NULL;
			char		*obj_type				= NULL;
			char		*partType				= NULL;
			char		*rev					= NULL;
			char		*desc					= NULL;
			char		*modDesc				= NULL;
			char		*keyDesc				= NULL;
			char		*projectCode			= NULL;
			char		*designGrp				= NULL;
			char		*ownerDesUnit			= NULL;
			char		*partCatgory			= NULL;
			char		*drawingInd				= NULL;
			char		*material				= NULL;
			double		weight					= 0;
			char		*materialThickness		= NULL;
			char		*matlClass				= NULL;
			char		*envelopeDimensions		= NULL;
			char		*owner					= NULL;
			char		*drStatus				= NULL;
			char		*rolledupWeight			= NULL;
			char		*uom					= NULL;
			char		*Rlstatus1				= NULL;
			char		*t5PunMakeBuyIndS		= NULL;
			
			printf("*****************Printing in Report*****************\n");fflush(stdout);

			if(AOM_ask_value_string(partTag,"item_id",&ParentItemID));
			printf("ParentItemID: [%s] \t",ParentItemID);fflush(stdout);

			printf("\n[%s] Will pass to WhereUsed function\n",ParentItemID);fflush(stdout);
			WhereUsedPo(partTag);
			printf("\n End Function GetInfo in Recursive: \t");fflush(stdout);

		}

		int WhereUsedPo(tag_t partTag)
		{
			
			
				char* t5_PO1=NULL;
				char* t5_PO2=NULL;
				char* t5_PO3=NULL;
				char* t5_PO4=NULL;
				char* t5_PO5=NULL;
				char* t5_PO6=NULL;
				char* t5_PO7=NULL;
				char* t5_PO8=NULL;
				char* t5_PO9=NULL;
				char* t5_PO10=NULL;
				char* t5_PO11=NULL;
				char* t5_PO12=NULL;
				char* t5_PODate1=NULL;
				char* t5_PODate2=NULL;
				char* t5_PODate3=NULL;
				char* t5_PODate4=NULL;
				char* t5_PODate5=NULL;
				char* t5_PODate6=NULL;
				char* t5_PODate7=NULL;
				char* t5_PODate8=NULL;
				char* t5_PODate9=NULL;
				char* t5_PODate10=NULL;
				char* t5_PODate11=NULL;
				char* t5_PODate12=NULL;
				char* sObjNameLatestRev=NULL;
				char* sObjNameMasFormRev=NULL;
				tag_t Gen_qry_tag=NULLTAG;
				tag_t *ClrpartRev_Master_tag=NULLTAG;
				int Gen_qry_Count=0;
				char    *Gen_qry_entry[2]		=	{"Name","Type"};
				char    **Gen_qry_values		=  (char **) MEM_alloc(50 * sizeof(char *));
				char *sClItem_id=NULL;
				char *ClrItem = NULL;
				 int     qry_entry					=	2;
				 int status3 =0;
				 int status =0;
				int x=0;

				
				char *clRlzDate=NULL;

								
				ClrItem=(char *) MEM_alloc(25);
				  strcpy(ClrItem,"");
				ITK_CALL(AOM_ask_value_string(partTag,"item_id",&sClItem_id));
				ITK_CALL(AOM_ask_value_string(partTag,"object_string",&sObjNameLatestRev));
			   ITK_CALL(QRY_find2("General...", &Gen_qry_tag));
			
				if (Gen_qry_tag!=NULLTAG)
				{
					fprintf(fplog,"\n -- Found Query General for Clr Part Revision Master... \n");fflush(fplog);
					
					strcat(ClrItem,sClItem_id);
					strcat(ClrItem,"*");
					fprintf(fplog,"\n Input for Clr Part Revision Master... [%s]\n",ClrItem);fflush(fplog);
					Gen_qry_values[0] = ClrItem;
					Gen_qry_values[1] = "Clr Part Revision Master" ;
					ITK_CALL(QRY_execute(Gen_qry_tag, qry_entry, Gen_qry_entry, Gen_qry_values, &Gen_qry_Count, &ClrpartRev_Master_tag));
				  MEM_free(ClrItem);
				}
				else
				{
					fprintf(fplog,"\n Not Found Query General... \n");fflush(fplog);
				}
			   printf("\n Clr Part master Revision count ....%d \n",Gen_qry_Count);
				fprintf(fplog,"\n  Clr Part master Revision count ....%d  \n",Gen_qry_Count);fflush(fplog);
				if (Gen_qry_Count>0)
				{
					for (x=0;x<Gen_qry_Count;x++ )
					{
					ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"object_name",&sObjNameMasFormRev));
					  printf("\n Clr PartObject Name  ....%s=%s \n",sObjNameMasFormRev,sObjNameLatestRev);
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO1",&t5_PO1));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO2",&t5_PO2));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO3",&t5_PO3));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO4",&t5_PO4));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO5",&t5_PO5));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO6",&t5_PO6));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO7",&t5_PO7));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO8",&t5_PO8));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO9",&t5_PO9));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO10",&t5_PO10));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO11",&t5_PO11));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO12",&t5_PO12));
					 if (((t5_PO1 !=NULL) && (strcmp(t5_PO1,"") !=0)) || (t5_PO2 !=NULL && strcmp(t5_PO2,"") !=0) ||(t5_PO3 !=NULL && strcmp(t5_PO3,"") !=0) || (t5_PO4 != NULL && strcmp(t5_PO4,"") !=0) || (t5_PO5 != NULL && strcmp(t5_PO5,"") !=0) || (t5_PO6 !=NULL && strcmp(t5_PO6,"") !=0)|| (t5_PO7 !=NULL && strcmp(t5_PO7,"") !=0) ||(t5_PO8 !=NULL && strcmp(t5_PO8,"") !=0) || (t5_PO9 !=NULL && strcmp(t5_PO9,"") !=0) || (t5_PO10 !=NULL && strcmp(t5_PO10,"") !=0) || (t5_PO11 !=NULL && strcmp(t5_PO11,"") !=0) || (t5_PO12 !=NULL && strcmp(t5_PO12,"") !=0) )
					 {
							 
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate1",&t5_PODate1));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate2",&t5_PODate2));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate3",&t5_PODate3));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate4",&t5_PODate4));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate5",&t5_PODate5));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate6",&t5_PODate6));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate7",&t5_PODate7));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate8",&t5_PODate8));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate9",&t5_PODate9));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate10",&t5_PODate10));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate11",&t5_PODate11));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate12",&t5_PODate12));
						 printf("\n t5_PODate1 is size= .%d \n",strlen(t5_PODate1));
							if (strlen(t5_PODate1)>0)
							{
							   fprintf(fplog,"\n  t5_PODate1 = .%s  \n",t5_PODate1);fflush(fplog);
							   printf("\n t5_PODate1 = .%s  \n",t5_PODate1);
							   clRlzDate= strtok(t5_PODate1," ");
							   iDateComparison(clRlzDate,sClItem_id);
							}
							else
							{
								printf("\n t5_PODate1 is empty= . \n");
							}
						printf("\n t5_PODate2 is size= .%d \n",strlen(t5_PODate2));
							if (strlen(t5_PODate2)>0)
							{
							   fprintf(fplog,"\n  t5_PODate2 = .%s  \n",t5_PODate2);fflush(fplog);
							   printf("\n t5_PODate2 = .%s  \n",t5_PODate2);
							   clRlzDate= strtok(t5_PODate2," ");
							   iDateComparison(clRlzDate,sClItem_id);
							}
							else
							{
								printf("\n t5_PODate2 is empty= . \n");
							}
						printf("\n t5_PODate3 is size= .%d \n",strlen(t5_PODate3));
							if (strlen(t5_PODate3)>0)
							{
							   fprintf(fplog,"\n  t5_PODate3 = .%s  \n",t5_PODate3);fflush(fplog);
							   printf("\n t5_PODate3 = .%s  \n",t5_PODate3);
							   clRlzDate= strtok(t5_PODate3," ");
							  iDateComparison(clRlzDate,sClItem_id);
							}
							else
							{
								printf("\n t5_PODate3 is empty= . \n");
							}
						printf("\n t5_PODate4 is size= .%d \n",strlen(t5_PODate4));
							if (strlen(t5_PODate4)>0)
							{
							   fprintf(fplog,"\n  t5_PODate4 = .%s  \n",t5_PODate4);fflush(fplog);
							   printf("\n t5_PODate4 = .%s  \n",t5_PODate4);
							   clRlzDate= strtok(t5_PODate4," ");
							   iDateComparison(clRlzDate,sClItem_id);
							}
							else
							{
								printf("\n t5_PODate4 is empty= . \n");
							}
						printf("\n t5_PODate5 is size= .%d \n",strlen(t5_PODate5));
							if (strlen(t5_PODate5)>0)
							{
							   fprintf(fplog,"\n  t5_PODate5 = .%s  \n",t5_PODate5);fflush(fplog);
							   printf("\n t5_PODate5 = .%s  \n",t5_PODate5);
							   clRlzDate= strtok(t5_PODate5," ");
							   iDateComparison(clRlzDate,sClItem_id);
							}
							else
							{
								printf("\n t5_PODate5 is empty= . \n");
							}
						printf("\n t5_PODate6 is size= .%d \n",strlen(t5_PODate6));
							if (strlen(t5_PODate6)>0)
							{
							   fprintf(fplog,"\n  t5_PODate6 = .%s  \n",t5_PODate6);fflush(fplog);
							   printf("\n t5_PODate6 = .%s  \n",t5_PODate6);
							   clRlzDate= strtok(t5_PODate6," ");
							  iDateComparison(clRlzDate,sClItem_id);
							}
							 else
							{
								printf("\n t5_PODate6 is empty= . \n");
							}
						printf("\n t5_PODate7 is size= .%d \n",strlen(t5_PODate7));
							if (strlen(t5_PODate7)>0)
							{
							   fprintf(fplog,"\n  t5_PODate7 = .%s  \n",t5_PODate7);fflush(fplog);
							   printf("\n t5_PODate7 = .%s  \n",t5_PODate7);
							   clRlzDate= strtok(t5_PODate7," ");
							   iDateComparison(clRlzDate,sClItem_id);
							}
							else
							{
								printf("\n t5_PODate7 is empty= . \n");
							}
						printf("\n t5_PODate8 is size= .%d \n",strlen(t5_PODate8));
							if (strlen(t5_PODate8)>0)
							{
							   fprintf(fplog,"\n  t5_PODate8 = .%s  \n",t5_PODate8);fflush(fplog);
							   printf("\n t5_PODate8 = .%s  \n",t5_PODate8);
							   clRlzDate= strtok(t5_PODate8," ");						
							    iDateComparison(clRlzDate,sClItem_id);
							 }
							 else
							{
								printf("\n t5_PODate8 is empty= . \n");
							}
						printf("\n t5_PODate9 is size= .%d \n",strlen(t5_PODate9));
							if (strlen(t5_PODate9)>0)
							{
								 fprintf(fplog,"\n  t5_PODate9 = .%s  \n",t5_PODate9);fflush(fplog);
								printf("\n t5_PODate9 = .%s  \n",t5_PODate9);
								clRlzDate= strtok(t5_PODate9," ");
								iDateComparison(clRlzDate,sClItem_id);
							}
							else
							{
								printf("\n t5_PODate9 is empty= . \n");
							}
						printf("\n t5_PODate10 is size= .%d \n",strlen(t5_PODate10));
							if (strlen(t5_PODate10)>0)
							{
							   fprintf(fplog,"\n  t5_PODate10 = .%s  \n",t5_PODate10);fflush(fplog);
							   printf("\n t5_PODate10 = .%s  \n",t5_PODate10);
							   clRlzDate= strtok(t5_PODate10," ");
							   iDateComparison(clRlzDate,sClItem_id);
							}
							else
							{
								printf("\n t5_PODate10 is empty= . \n");
							}
						printf("\n t5_PODate11 is size= .%d \n",strlen(t5_PODate11));
							if (strlen(t5_PODate11)>0)
							{
							   fprintf(fplog,"\n  t5_PODate11 = .%s  \n",t5_PODate11);fflush(fplog);
							   printf("\n t5_PODate11 = .%s  \n",t5_PODate11);
							   clRlzDate= strtok(t5_PODate11," ");
							   iDateComparison(clRlzDate,sClItem_id);
							}
							else
							{
								printf("\n t5_PODate11 is empty= . \n");
							}
						printf("\n t5_PODate12 is size= .%d \n",strlen(t5_PODate12));
							if (strlen(t5_PODate12)>0)
							{
								fprintf(fplog,"\n  t5_PODate12 = .%s  \n",t5_PODate12);fflush(fplog);
								printf("\n t5_PODate12 = .%s  \n",t5_PODate12);
								clRlzDate= strtok(t5_PODate12," ");
								iDateComparison(clRlzDate,sClItem_id);
							}
							else
							{
								printf("\n t5_PODate12 is empty= . \n");
							}

							 status3 = 1;
							 break ;
				   
						}
						else
						   {
			
							 printf("\n Clr Part master Revision PO not Found .... \n");
							 fprintf(fplog,"\n  Clr Part master Revision PO Not Found ....  \n");fflush(fplog);
			
						   }
					   
							   
							   
					}
				}


													 

	
			return status;	
			
		}
        int iDateComparison(char* clRlzDate, char* sClItem_id ) 
		{
				char *RlzDateString=NULL;
				struct tm tm;
				
				int oflag=0;
				int pflag=0;

			if(strstr(clRlzDate,"JAN")!=NULL)
			{
			   STRNG_replace_str(clRlzDate,"JAN","01",&RlzDateString);
			}
			else if (strstr(clRlzDate,"Feb")!=NULL)
			{
				STRNG_replace_str(clRlzDate,"Feb","02",&RlzDateString);
			}
			else if(strstr(clRlzDate,"Mar")!=NULL)
			{
				STRNG_replace_str(clRlzDate,"Mar","03",&RlzDateString);
			}
			else if(strstr(clRlzDate,"Apr")!=NULL)
			{
				STRNG_replace_str(clRlzDate,"Apr","04",&RlzDateString);
			}
			else if(strstr(clRlzDate,"May")!=NULL)
			{
				STRNG_replace_str(clRlzDate,"May","05",&RlzDateString);
			}
			else if(strstr(clRlzDate,"Jun")!=NULL)
			{
				STRNG_replace_str(clRlzDate,"Jun","06",&RlzDateString);
			}
			else if(strstr(clRlzDate,"Jul")!=NULL)
			{
				STRNG_replace_str(clRlzDate,"Jul","07",&RlzDateString);
			}
			else if(strstr(clRlzDate,"Aug")!=NULL)
			{
				STRNG_replace_str(clRlzDate,"Aug","08",&RlzDateString);
			}
			else if(strstr(clRlzDate,"Sep")!=NULL)
			{
				STRNG_replace_str(clRlzDate,"Sep","09",&RlzDateString);
			}
			else if(strstr(clRlzDate,"Oct")!=NULL)
			{
				STRNG_replace_str(clRlzDate,"Oct","10",&RlzDateString);
			}
			else if(strstr(clRlzDate,"Nov")!=NULL)
			{
				STRNG_replace_str(clRlzDate,"Nov","11",&RlzDateString);
			}
			else
			{
				STRNG_replace_str(clRlzDate,"Dec","12",&RlzDateString);
			}
		
			char* sDate=strtok(RlzDateString,"-");
			int iDate=atoi(sDate);
			char* sMonth=strtok(NULL,"-");
			int iMonth=atoi(sMonth);
			char* sYears=strtok(NULL,"-");
			int iYears=atoi(sYears);
			struct tm new_date = {0};
			 new_date.tm_year = iYears - 1900;  // Year since 1900
			 new_date.tm_mon = iMonth - 1;         // Month (0-based, so 5 for June)
			 new_date.tm_mday = iDate;
			  if (oflag==0)
			  {
				oYears=iYears;
				oMonth=iMonth;
				oDate= iDate;
				 topLevelVC = (char *) MEM_alloc(5000 * sizeof(char));
				 strcpy(topLevelVC,"");
				 strcat(topLevelVC,",");
				 strcat(topLevelVC,sClItem_id);
				 strcat(topLevelVC,",");
				 strcat(topLevelVC,clRlzDate);
		
				oflag++;
			  }
		
																	
			 old_date.tm_year = oYears - 1900;  
			 old_date.tm_mon = oMonth - 1;         
			 old_date.tm_mday = oDate;
			 printf("\n old date part1= %d-%d-%d",old_date.tm_mday,old_date.tm_mon,old_date.tm_year);
			 printf("\n New Date Part2= %d-%d-%d",new_date.tm_mday,new_date.tm_mon,new_date.tm_year);														
			 time_t new_time = mktime(&new_date);
			 time_t old_time = mktime(&old_date);
			
			if (new_time > old_time) 
				{
		
					oYears=iYears;
					oMonth=iMonth;
					oDate= iDate;
					printf("\n The new date is later than the old date.\n");
					 printf("\n new Date= %d-%d-%d",new_date.tm_mday,new_date.tm_mon,new_date.tm_year);
					 topLevelVC = (char *) MEM_alloc(5000 * sizeof(char));
					 strcpy(topLevelVC,"");
					  strcat(topLevelVC,",");
					  strcat(topLevelVC,sClItem_id);
					  strcat(topLevelVC,",");
					  strcat(topLevelVC,clRlzDate);
					  pflag==1;
		
			   } else if (new_time < old_time) {
				// if(pflag==0)
				// {
				 //  topLevelVC = (char *) MEM_alloc(1000 * sizeof(char));
				//	 strcpy(topLevelVC,"");
				 //   strcat(topLevelVC,",");
				//	 strcat(topLevelVC,ParentItemID);
				//	 strcat(topLevelVC,",");
				//	 strcat(topLevelVC,t5_DRStatus);
				//	 strcat(topLevelVC,",");
				//	 strcat(topLevelVC,DmlName);
				//	 strcat(topLevelVC,",");
				//	 strcat(topLevelVC,DMLtype);
				//	 strcat(topLevelVC,",");
				//	 strcat(topLevelVC,clRlzDate);
				// }
		
				 printf("\n The new date is earlier than the old date.\n");
				printf("\n old date= %d-%d-%d",old_date.tm_mday,old_date.tm_mon,old_date.tm_year);
		
			 } else {
		
				   printf("\n The dates are the same.\n");
			 } 
			 printf("\n topLevelVC.....%s\n",topLevelVC);




			return 0;
		}

		extern int ITK_user_main (int argc, char ** argv )
				{
					int ifail;
					int status;
					char *inputfile = NULL;
					reportfile =NULL;
					rptFixTblMstrClrSchm=NULL;
					char *itemId = NULL;
					char *outputfile=NULL;
					char *Parentfile=NULL;
					char *Childfile=NULL;
					char *AllFiles=NULL;
					char *input=NULL;
					char *sParentCompCode=NULL;
					char *sParentColID=NULL;
					char *sbl_item_id=NULL;
					char *sbl_rev_id=NULL;
					//tag_t *LatestRev = NULL;
					tag_t SchmHasClrData_RelTag = NULLTAG;
					tag_t window, rule, item_tag = null_tag, top_line;
					FILE *fptr;
					FILE *fptr1;
					FILE *fptrP;
					FILE *fptrC;
					FILE *fptrA;
					char* line;
					char *sitem_id =NULL;
					char *sSVRNo   =NULL;
					char *sPlatform   =NULL;
					char *ofileLoc   =NULL;
					tag_t VC_Tag=NULLTAG;
					int Child_Rev_count = 0;
					int dd = 0;
					tag_t*	Child_rev_list	= NULLTAG;
					tag_t*	ChildVc_rev_list	= NULLTAG;
					char *Relstatus=NULL;
					char *Veh_RevSeq=NULL;
					tag_t VCRlzRevLatest=NULLTAG;

				//	int DOstatus =0;
				//	int	DelStatus	=0;

					(void)argc;
					(void)argv;

					fpos_t pos;
					fgetpos(stdout, &pos);
					int fd = dup(fileno(stdout));
					//freopen("/user/bsd05818/Ashish/SuffixSelection/test.txt", "a", stdout);


				//	initialise();

					

					itemId = ITK_ask_cli_argument("-i=");
					ofileLoc = ITK_ask_cli_argument("-outF=");
						
						//int Rstatus =0;
						char	Data[100]			= "";
						time_t				now;
						struct				tm when;
						
						time(&now);
						when = *localtime(&now);
						//for output file with date.
						strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
					
					reportfile =(char *) MEM_alloc(100);
					rptFixTblMstrClrSchm =(char *) MEM_alloc(100);
				

					tc_strcpy(reportfile,"");
					tc_strcpy(reportfile,"/plmpv16/reports");
					//tc_strcpy(reportfile,ofileLoc);
					tc_strcat(reportfile,"/");
					//tc_strcat(reportfile,sPlatform);
					//tc_strcat(reportfile,"_");
					tc_strcat(reportfile,itemId);
					tc_strcat(reportfile,"_");
					tc_strcat(reportfile,Data);
					tc_strcat(reportfile,"_FixTable_Suffix_Report.csv");
					fReport = fopen(reportfile,"w");

					tc_strcpy(rptFixTblMstrClrSchm,"");
					tc_strcpy(rptFixTblMstrClrSchm,"/plmpv16/reports");
					//tc_strcpy(rptFixTblMstrClrSchm,ofileLoc);
					tc_strcat(rptFixTblMstrClrSchm,"/");
					tc_strcat(rptFixTblMstrClrSchm,itemId);
					//tc_strcat(rptFixTblMstrClrSchm,"_");
					//tc_strcat(rptFixTblMstrClrSchm,sSVRNo);
					tc_strcat(rptFixTblMstrClrSchm,Data);
					tc_strcat(rptFixTblMstrClrSchm,"_ClrPart_Report.csv");
					fMstClrSchRpt = fopen(rptFixTblMstrClrSchm,"w");


					if(itemId== NULL)
					{
						printf("\n Please use exe as ColorSchemeClrSrlSetValue -i=$ColorSchemeNumber");fflush(stdout);
						(POM_logout(false));
						return status;
					}

					//if( ITK_init_module("ercpsup" ,"XYT1ESA","dba")!=ITK_ok) ;

					ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
					ITK_CALL(ITK_auto_login( ));
					ITK_CALL(ITK_set_journalling( TRUE ));
					printf("\n login .......");fflush(stdout);

					if ( itemId )
					{

						LatestRev = FunToReturnLatestRevision(itemId);

						ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&sitem_id));
						ITK_CALL(AOM_ask_value_string(LatestRev,"t5_VehNO",&sSVRNo));
						ITK_CALL(AOM_ask_value_string(LatestRev,"t5_SchmPlant",&sPlatform));

						printf("\nColor scheme Name: [%s] SVR number: [%s]\n",sitem_id,sSVRNo);

						char *VCName=subString(sSVRNo,0,12);
						ITK_CALL(ITEM_find_item(VCName, &VC_Tag));

						if(VC_Tag)
						{		
							ifail = ITEM_list_all_revs (VC_Tag, &Child_Rev_count, &Child_rev_list);
							printf("\n Child_rev_list---------------> : %d", Child_Rev_count);fflush(stdout);
							if(Child_Rev_count > 0)
							{
								for(dd=Child_Rev_count-1;dd>=0;dd--)
								{
									ITK_CALL(AOM_UIF_ask_value (Child_rev_list[dd], "release_status_list", &Relstatus));
									if((tc_strstr(Relstatus,"ERC Released")!=NULL)||(tc_strstr(Relstatus,"T5_LcsErcRlzd")!=NULL))
									{
										VCRlzRevLatest=Child_rev_list[dd];

										ITK_CALL(AOM_ask_value_string(VCRlzRevLatest, "item_revision_id", &Veh_RevSeq));

										printf("\n Veh_RevSeq==>: %s", Veh_RevSeq);fflush(stdout);
										break;
									}							
								}
							}	
							
                                int rulefound,no_bom_lines,vi,ij,n_linesvc= 0;
								tag_t *closurerule = NULL;
								tag_t close_tag;
								char **rulename = NULL;
								char **rulevalue = NULL;
								char *blPartType = NULL;
								char *blColInd = NULL;
								char *blItemId = NULL;
								tag_t vctop_line=NULLTAG;
								tag_t vcbom_window=NULLTAG;
								tag_t rule=NULLTAG;
								tag_t *bom_line_tag=NULLTAG;
								tag_t *child_bom_lines=NULLTAG;
								tag_t *vclines= NULLTAG;
                                modulelist = (char *) MEM_alloc(50000 * sizeof(char));
								strcpy(modulelist,"");
								ITK_CALL(BOM_create_window(&vcbom_window));
								ITK_CALL(CFM_find("ERC release and above", &rule));
								ITK_CALL(BOM_set_window_config_rule(vcbom_window, rule ));
								PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule);
								if (rulefound > 0)
								{
									close_tag = closurerule[0];
									printf ("closure rule found \n");fflush(stdout);
								}
								BOM_window_set_closure_rule(vcbom_window,close_tag, 0, rulename,rulevalue);

								ITK_CALL(BOM_set_window_pack_all(vcbom_window, TRUE));
								ITK_CALL(BOM_set_window_top_line(vcbom_window , NULLTAG, VCRlzRevLatest, NULLTAG, &bom_line_tag));
								ITK_CALL(BOM_window_show_suppressed (vcbom_window));
							    if (bom_line_tag != NULLTAG)
							    {
									 if(BOM_line_ask_child_lines(vctop_line, &n_linesvc, &vclines));

									 for (vi=0;vi<n_linesvc; vi++)
									 {
                                           BOM_line_ask_child_lines (bom_line_tag[vi], &no_bom_lines, &child_bom_lines);

										   if (child_bom_lines!=NULLTAG)
										   {
											   for (ij=0;ij<no_bom_lines;ij++ )
											   {
                                                 AOM_UIF_ask_value(child_bom_lines[ij],"bl_Design Revision_t5_PartType",&blPartType);
												 AOM_UIF_ask_value(child_bom_lines[ij],"bl_Design Revision_t5_ColourInd",&blColInd);
												 printf ("Part type and Colour Ind =%s , %s  \n",blPartType,blColInd); fflush(stdout);
												 if (tc_strcmp(blPartType,"M")==0&&tc_strcmp(blColInd,"Y")==0)
												 {
                                                    AOM_UIF_ask_value(child_bom_lines[ij],"bl_item_item_id",&blItemId);
													printf ("Module Bomline item Id  = %s  \n",blItemId); fflush(stdout);
													strcat(modulelist,blItemId);
													strcat(modulelist,",");
												 }

											   }
                                              


										   }

									 }
							    }
								

                             printf ("All Module list colInd Y   = %s  \n",modulelist); fflush(stdout);


						}

					}
					else
					{
						printf ("Pls enter input part ?? \n"); fflush(stdout);
						exit (0);
					}

					ITK_CALL(GRM_find_relation_type	("T5_ShmHasClrData",&SchmHasClrData_RelTag));

					int		i					 =	0;
					int		SchemeDataCnt		 =	0;
					int		IntRem				 =	0;
					int		IntRem1				 =	0;
					int		IntRem4				 =	0;
					int		IntRem5				 =	0;
					int		YNFlag11			 =	0;
					int		YNFlag22			 =	0;
					int		rm					 =	0;
					tag_t	*ClrSchemeData_tag	 =	NULLTAG;
					tag_t   ColData_relation_type	 =	NULLTAG;
					tag_t   ClrToClrDatarel_tag	 =	NULLTAG;
					char **sPartNumberSet = (char **) MEM_alloc(1 * sizeof(char *));
					char **sPartNumberSet4 = (char **) MEM_alloc(1 * sizeof(char *));
					char **sPrtCompCodeSet = (char **) MEM_alloc(1 * sizeof(char *));
					char **sPrtCompCodeSet5 = (char **) MEM_alloc(1 * sizeof(char *));



					ITK_CALL(GRM_list_secondary_objects_only(LatestRev,SchmHasClrData_RelTag,&SchemeDataCnt,&ClrSchemeData_tag));
				//
					printf("\n Color scheme data count SchemeDataCnt: %d\n",SchemeDataCnt);
				//
				//	if(SchemeDataCnt>0)
				//	{
				// for (i=0;i<SchemeDataCnt;i++)
			   //{
						char *sPrtCompCode		= NULL;
						char *sClrSerial		= NULL;
						char *sDataPartNumber	= NULL;
						char *sInternalScheme	= NULL;
						tag_t LatestRev_tag		= NULLTAG;
						


				  if(fReport == NULL)
					{
					printf ("\n Could not open reportfile file : %s\n", reportfile); fflush(stdout);
					exit( EXIT_FAILURE );
					}
					else
					{
						fprintf(fReport,"\nColor scheme Name: [%s] SVR number: [%s]\n",sitem_id,sSVRNo); fflush(fReport);
						fprintf(fReport,"\nComp Code, NewSuffix, oldSuffix ,Legacy Part Number,Existing"); fflush(fReport);
					}

					if(fMstClrSchRpt == NULL)
					{
					printf ("\n Could not open fMstClrSchRpt file : %s\n", fMstClrSchRpt); fflush(stdout);
					exit( EXIT_FAILURE );
					}
					else
					{
						fprintf(fMstClrSchRpt,"\nColor scheme Name: [%s] SVR number: [%s]\n",sitem_id,sSVRNo); fflush(fReport);
						fprintf(fMstClrSchRpt,"\nComp Code=BOM Matching Part= PO part\n"); fflush(fReport);

					}



					char	*sFileName				= NULL;
					char	*sFileName1				= NULL;

					//char	*sCompCodeF				= NULL;
					//char	*sIntSchemF				= NULL;
					//char	*sCategory				= NULL;
					//char	*sPartNum				= NULL;
					// int Isallow=0;

					int  count 	= 0;
					tag_t *contrlObjs = NULLTAG;
					char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
					char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
					tag_t query = NULLTAG;
					tag_t cntrlObj = NULLTAG;
					char* cntrlStr = NULL;

					qry_entries[0] = "SYSCD";
					qry_entries[1] = "SUBSYSCD";

					qry_values[0] = "CLRSCM";
					qry_values[1] = "CLRSCM";

					ITK_CALL(QRY_find2("Control Objects...", &query));

					if (query!=NULLTAG)
					{
						ITK_CALL(QRY_execute(query, 2, qry_entries, qry_values, &count, &contrlObjs));
					}
					printf("\nCLRSCM:Control objects CLRSCM: count==>%d", count);fflush(stdout);
					if (count > 0)
					{
						cntrlObj = contrlObjs[0];

						if(cntrlObj!=NULLTAG)
						{

							ITK_CALL(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&cntrlStr));
							printf("\nCVBUUVF: Control object ===>%s", cntrlStr);fflush(stdout);

						}
					}


					//char	temp[200];
					
					sFileName1=(char *) MEM_alloc(100);

					sFileName1	=	strcpy(sFileName1,"");
					sFileName1	=	strcpy(sFileName1,"/plmpv16/reports");
				   //sFileName1	=	strcpy(sFileName1,ofileLoc);
					sFileName1	=	strcat(sFileName1,"/");
					sFileName1	=	strcat(sFileName1,sPlatform);
					sFileName1	=	strcat(sFileName1,"_");
					sFileName1	=	strcat(sFileName1,sSVRNo);
					sFileName1	=	strcat(sFileName1,"_");
					sFileName1	=	strcat(sFileName1,itemId);
					sFileName1	=	strcat(sFileName1,"_");
					sFileName1	=	strcat(sFileName1,"Suf");
					sFileName1	=	strcat(sFileName1,"_");
					sFileName1	=	strcat(sFileName1,"CompCode.log");

					fplog=fopen(sFileName1, "w");

					sFileName=(char *) MEM_alloc(100);

					sFileName	=	strcpy(sFileName,"");
					sFileName	=	strcpy(sFileName,"/plmpv16/reports");
					//sFileName	=	strcat(sFileName,ofileLoc);
					sFileName	=	strcat(sFileName,"/");
				//	sFileName	=	strcat(sFileName,sPlatform); // comment 09-07-2025
					sFileName	=	strcat(sFileName,itemId); // comment 09-07-2025
					sFileName	=	strcat(sFileName,"_");
					sFileName	=	strcat(sFileName,sSVRNo);
					sFileName	=	strcat(sFileName,"_");
					sFileName	=	strcat(sFileName,"Suf");
					sFileName	=	strcat(sFileName,"_");
					sFileName	=	strcat(sFileName,"CompCode.txt");

					printf("\n Input sFileName:[%s]  and colour Scheme Number : [%s]\n",sFileName,itemId);
					fprintf(fplog," Input sFileName:[%s]  and colour Scheme Number : [%s]\n",sFileName,itemId); fflush(fplog);
				  fprintf(fplog," First time excecuted is started *********************************"); fflush(fplog);
				   recursivefunctionforsuffixSelection(sFileName,"CLRPARTREPORT");
				  fprintf(fplog," ***********************Second time excecuted is started *********************************"); fflush(fplog);
				   recursivefunctionforsuffixSelection(sFileName,"");
				   fprintf(fplog," *********************************FINISH suffix selection*********************************"); fflush(fplog);


		
				printf("\n start of Non CAA-- %d >>>  \n",SchemeDataCnt);
				fprintf(fplog,"\n  start of Non CAA-- %d >>> \n",SchemeDataCnt);fflush(fplog);

				
					 for (i=0;i<SchemeDataCnt;i++)
						{
						(AOM_ask_value_string(ClrSchemeData_tag[i],"t5_PrtCatCode",&sPrtCompCode));
						(AOM_ask_value_string(ClrSchemeData_tag[i],"t5_ClSrl",&sClrSerial));

						 printf("\n comp code and colour serial---%d= %s=%s >>>  \n",i,sPrtCompCode,sClrSerial);
						if(tc_strstr(sPrtCompCode,"CCA_")==NULL)
						{
							printf("\n comp code and colour serial %s=%s >>>  \n",sPrtCompCode,sClrSerial);
							fprintf(fReport,"\n %s,%s,%s,%s,%s",sPrtCompCode,"","","",sClrSerial); fflush(fReport);
							
						}
						}
				
					fprintf(fplog,"\n start Suffix fix table of dataset >>> \n");fflush(fplog);
					printf("\n start Suffix fix table of dataset>>>  \n");
					createDatasetSuffixFixTable(fReport);
					fprintf(fplog,"\n End Suffix fix table of dataset>>> \n");fflush(fplog);
					printf("\n End Suffix fix table of dataset>>> \n");
				   fprintf(fplog,"\n start Clr part  dataset >>> \n");fflush(fplog);
				   createDatasetClrPart(fMstClrSchRpt);
					fprintf(fplog,"\n End Clr part  dataset >>> \n");fflush(fplog);
					fprintf(fplog,"\n end of program>>> \n");fflush(fplog);

					ITK_exit_module(true);
					fclose(fplog);
					fsetpos(stdout, &pos);
					fclose(fReport);
					fclose(fMstClrSchRpt);


					return status;
				}

			int recursivefunctionforsuffixSelection(char *sFileName,char *CLRPARTREPORT)
				{
					char	temp[200];
					char	*sCompCodeF				= NULL;
					char	*sIntSchemF				= NULL;
					char	*sCategory				= NULL;
					char	*sPartNum				= NULL;
					int     Isallow=0;
					int status=0;
					int Rstatus =0;
					int		DOstatus =0;
					int		DelStatus	=0;
					 FILE* fp = NULL;
					
					int		i					 =	0;
					int     DOFlag				 =  0;
					int		IntRem				 =	0;
					int		IntRem1				 =	0;
					int		IntRem4				 =	0;
					int		IntRem5				 =	0;
					int		YNFlag11			 =	0;
					int		YNFlag22			 =	0;
					int		rm					 =	0;
					tag_t	*ClrSchemeData_tag	 =	NULLTAG;
					tag_t   ColData_relation_type	 =	NULLTAG;
					tag_t   ClrToClrDatarel_tag	 =	NULLTAG;
					char **sPartNumberSet = (char **) MEM_alloc(1 * sizeof(char *));
					char **sPartNumberSet4 = (char **) MEM_alloc(1 * sizeof(char *));
					char **sPrtCompCodeSet = (char **) MEM_alloc(1 * sizeof(char *));
					char **sPrtCompCodeSet5 = (char **) MEM_alloc(1 * sizeof(char *));

				   fp = fopen(sFileName, "r");
					//neha need to check code here
					if (fp != NULL)
					{
						printf("\n Enters into if of file pointer \n");
						while (fgets(temp, 400, fp)!= NULL)
						{
							tc_strcpy(temp,stripBlanks(temp));
							printf("\n temp - [%s] \n",temp);

							if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
							{
								sCompCodeF = strtok(temp, "^");//compcode :CCA_T1A05
								sIntSchemF = strtok(NULL, "^");// internal Scheme:  T
								sCategory  = strtok(NULL, "^");//category: Interior
								sPartNum   = strtok(NULL, "^");//part Number :544583200651
								printf("\n\n\t sPartNum:[%s]\n\n",sPartNum);
								//fprintf(fplog,"\n\t sPartNum:[%s]\n\n",sPartNum); fflush(fplog);
								if((strlen(sPartNum)>0) &&(strcmp(sIntSchemF,"T")==0))
								{
									if (strcmp(CLRPARTREPORT,"CLRPARTREPORT")==0)
									{
										 FiXTableMasterSchemeReport(sPartNum,sCompCodeF,LatestRev,"Yes");

									}
								printf("\n sPrtCompCode : [%s] & sPartNum : [%s]\n",sCompCodeF,sPartNum);
								fprintf(fplog,"sPrtCompCode : [%s] & sPartNum : [%s] \n",sCompCodeF,sPartNum); fflush(fplog);

								fprintf(fplog,"1. Before function: FunToFindDmyClRelWithColScm  \n"); fflush(fplog);

								Isallow = FunToFindDmyClRelWithColScm(LatestRev,sCompCodeF);

								printf("\n  1. After Return from function FunToFindDmyClRelWithColScm: sPartNum: [%s] \n Isallow %d\n",sPartNum,Isallow);
								fprintf(fplog,"1. After  Return from function FunToFindDmyClRelWithColScm : sPartNum: [%s] \n Isallow %d\n",sPartNum,Isallow); fflush(fplog);

								if((tc_strlen(sPartNum)>0)&& (Isallow==1))
								{
								fprintf(fplog,"1.  Before Return from function: FunExpPartToGetChildCompCodes Rstatus \n"); fflush(fplog);
								Rstatus = FunExpPartToGetChildCompCodes(sPartNum,sCompCodeF,LatestRev,IntRem);
								printf("\n 1. after Return from function: FunExpPartToGetChildCompCodes Rstatus %d \n",Rstatus);
								fprintf(fplog,"1.  After Return from function: FunExpPartToGetChildCompCodes Rstatus %d \n",Rstatus); fflush(fplog);
								if(Rstatus==0)
								{
								printf("\n 1. Before FunToFindDummyClrSrlNDelRel  Color scheme and color scheme data relation deletion Rstatus: %d \n",Rstatus);
								fprintf(fplog,"1. Before FunToFindDummyClrSrlNDelRel Color scheme and color scheme data relation deletion Rstatus: %d \n",Rstatus); fflush(fplog);

								DelStatus = FunToFindDummyClrSrlNDelRel(LatestRev,sCompCodeF);

								printf("\n *************** Refreshing Color scheme **************************\n");
								fprintf(fplog,"1. After FunToFindDummyClrSrlNDelRel ***** Refreshing Color scheme *** \n"); fflush(fplog);

								ITK_CALL(AOM_refresh(LatestRev,0));
								ITK_CALL(AOM_lock(LatestRev));
								ITK_CALL(AOM_save_without_extensions(LatestRev));
								//ITK_CALL(AOM_unlock(LatestRev));
								ITK_CALL(AOM_refresh(LatestRev,1));
								//ITK_CALL(AOM_load(LatestRev));

								printf("\n POM_refresh_instances \n");
								fprintf(fplog," POM_refresh_instances \n"); fflush(fplog);

								ITK_CALL(POM_refresh_instances(1,&LatestRev,class_to_load_as,lock_type));
								//ITK_CALL(POM_load_instances(1,&LatestRev,class_to_load_as,lock_type));

								printf("\n *********************D END OF PROGRAM***********************************\n");
								fprintf(fplog," *******D END OF PROGRAM**** \n"); fflush(fplog);

								}
								else if(Rstatus==1)
								{

								printf("\n *************** Refreshing Color scheme without updating color scheme **************************\n");
								fprintf(fplog," ** Refreshing Color scheme without updating color scheme *** \n"); fflush(fplog);fflush(fplog);

								ITK_CALL(AOM_refresh(LatestRev,0));
								ITK_CALL(AOM_lock(LatestRev));
								ITK_CALL(AOM_save_without_extensions(LatestRev));
								ITK_CALL(AOM_refresh(LatestRev,1));
								ITK_CALL(AOM_load(LatestRev));


								ITK_CALL(POM_refresh_instances(1,&LatestRev,class_to_load_as,lock_type));
								//(POM_load_instances(1,&LatestRev,class_to_load_as,lock_type));


								fprintf(fplog,"\n closing program without updating color scheme data\n");fflush(fplog);
								fprintf(fplog,"\n **********************************C END OF PROGRAM***************************\n");fflush(fplog);
								}
								else if(Rstatus==2)
								{
									fprintf(fplog,"\n 1. *************** comp code children contains CCA and ##, so process later **************************\n");fflush(fplog);
									fprintf(fplog,"\n ******** sPartNum: %s  sCompCodeF %s\n",sPartNum,sCompCodeF);fflush(fplog);

									printf("\n *************** comp code children contains CCA and ##, so process later  **************************\n");
									printf("\n ******** sPartNum: %s  sCompCodeF: %s **********\n",sPartNum,sCompCodeF);

									setAddStr(&IntRem,&sPartNumberSet,sPartNum);
									setAddStr(&IntRem1,&sPrtCompCodeSet,sCompCodeF);
								}
								else
								{
									fprintf(fplog,"\n *************** LIVE LOVE LOUGH**************************\n");
								}
								}
								else
									{
									  fprintf(fplog," \n else Return from function: sPartNum: [%s] \n Isallow %d\n",sPartNum,Isallow); fflush(fplog);
									}
								

								fprintf(fplog,"\n IntRem: [%d] , proceed to update all remaining color scheme data.\n",IntRem);fflush(fplog);
								printf("\n IntRem: [%d] , proceed to update all remaining color scheme data.\n",IntRem);
							}
									
							}
						}
						printf("\n Before closing of file pointer \n");
						fprintf(fplog,"\nBefore closing of file pointer \n");fflush(fplog);
						fclose(fp);


					}
					else
					{
						 fprintf(fplog,"\n File is empty or Not Found \n");fflush(fplog);
					}


					// try to update...
				   printf("\n try to update...\n");
				   fprintf(fplog,"\nBefore for loop of  IntRem IntRem: [%d] , try to update...  \n",IntRem);fflush(fplog);
					
					int remaining=IntRem;
					do
					{
						fprintf(fplog,"\n *********IntRem: %d************** \n",IntRem);fflush(fplog);
						printf("\n *********IntRem: %d************** \n",IntRem);
						for(rm=(IntRem-1);rm>=0;rm--)
						{
							ITK_CALL(AOM_refresh(LatestRev,0));
							ITK_CALL(AOM_lock(LatestRev));
							ITK_CALL(AOM_save_without_extensions(LatestRev));
							ITK_CALL(AOM_refresh(LatestRev,1));
							ITK_CALL(AOM_load(LatestRev));

							Isallow=0;
							fprintf(fplog,"\n 2. Inside do While Before  FunToFindDmyClRelWithColScm \n");fflush(fplog);
							Isallow = FunToFindDmyClRelWithColScm(LatestRev,sPrtCompCodeSet[rm]);

							fprintf(fplog,"\n 2. Inside do While after   FunToFindDmyClRelWithColScm*******Isallow: %d************** \n",Isallow);fflush(fplog);
							printf("\n *******Isallow: %d************** \n",Isallow);

							if(Isallow==1)
							{
								ITK_CALL(POM_refresh_instances(1,&LatestRev,class_to_load_as,lock_type));
								//(POM_load_instances(1,&LatestRev,class_to_load_as,lock_type));

								fprintf(fplog,"\n 1. ********remaining: %d************** \n",remaining);fflush(fplog);
								printf("\n 1.  ********remaining: %d************** \n",remaining);

								fprintf(fplog,"\n 1. *********rm: %d************** \n",rm);fflush(fplog);
								printf("\n 1.  *********rm: %d************** \n",rm);
								fprintf(fplog,"\n 2. Before Return from function: FunExpPartToGetChildCompCodes Rstatus \n");fflush(fplog);
								DOstatus = FunExpPartToGetChildCompCodes(sPartNumberSet[rm],sPrtCompCodeSet[rm],LatestRev,IntRem);
								fprintf(fplog,"\n 2. Return from function: FunExpPartToGetChildCompCodes*********DOstatus: %d************** \n",DOstatus);fflush(fplog);
								printf("\n *********DOstatus: %d************** \n",DOstatus);
								if(DOstatus==0)
								{
									fprintf(fplog,"\n 2. Before FunToFindDummyClrSrlNDelRel in do while loop.. deleted ## comp codes \n");fflush(fplog);
									DelStatus = FunToFindDummyClrSrlNDelRel(LatestRev,sPrtCompCodeSet[rm]);								
									fprintf(fplog,"\n 2.  After FunToFindDummyClrSrlNDelRel in do while loop.. deleted ## comp codes*******DelStatus: %d************** \n",DelStatus);fflush(fplog);
									printf("\n *******DelStatus: %d************** \n",DelStatus);
								}
								if(DOstatus==2)
								{
								   DOFlag = 1;
								}
								else
								{
									fprintf(fplog,"\n in do while loop ... in else of not delete ##  %d\n",DOstatus);fflush(fplog);
									printf("\n in do while loop ... in else of not delete ##  %d\n",DOstatus);
									//remaining++;
									setAddStr(&IntRem4,&sPartNumberSet4,sPartNumberSet[rm]);
									setAddStr(&IntRem5,&sPrtCompCodeSet5,sPrtCompCodeSet[rm]);
								}
							}
							else
							{
								fprintf(fplog,"\n **********not allow to update ************** \n");fflush(fplog);
								printf("\n **********not allow to update ************** \n");
							}
						}
					}while(rm==0);

					fprintf(fplog,"\n **********Out of while loop ************** \n");fflush(fplog);
					printf("\n IntRem4 IntRem4: [%d] , Before recursivefunctionforsuffixSelectio.  \n",IntRem4);
					fprintf(fplog,"\n IntRem4 IntRem4: [%d] , Before recursivefunctionforsuffixSelectio. \n",IntRem4);fflush(fplog);
					  

					return 0;

				}

				int createDatasetSuffixFixTable(FILE* fp)
					{
								int status;
								 printf ("\n================================================\n");
								tag_t		msWordType				= NULLTAG;
								tag_t		wordDataset				= NULLTAG;
								tag_t		dataset_tag				= NULLTAG;
								tag_t		wordLatestDat_t			= NULLTAG;
								tag_t		qryTag					= NULLTAG;
								tag_t		*CntrolObjectTag		= NULLTAG;
								tag_t IMANReferences_type;
								tag_t Rel_References	= NULLTAG;
								tag_t *secondary_objects = NULLTAG;
								tag_t CMRefExist = NULLTAG;
								char				*DataSetName		= NULL;
								char                *schemeNo             = NULL;
								char                *sVC             = NULL;
								char				*qry_entry[1]		= {"Name"};
								char				**qry_values2		= (char **) MEM_alloc(10 * sizeof(char *));
								int					n_entry				= 1;
								int					rsltCount			= 0;
								int                n_attchs  = 0;
								char				* DataSet_Id		= NULL;
								char	Data1[100]			= "";
								time_t				now;
								struct				tm when;
								
								time(&now);
								when = *localtime(&now);
								//for output file with date.
								strftime(Data1,100,"%d_%b_%Y_%H_%M_%S",&when);

									printf ("\n Inside  Dataset function .. ....\n");
									fprintf(fplog,"\n Inside  Dataset function .. ....>>> \n");fflush(fplog);
									ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&schemeNo));
									ITK_CALL(AOM_ask_value_string(LatestRev,"t5_VehNO",&sVC));

									ITK_CALL(AE_find_datasettype2("Text",&msWordType));

									DataSetName=(char *) MEM_alloc(100 * sizeof(char ));
									tc_strcpy(DataSetName,"");
									tc_strcat(DataSetName,schemeNo);
									tc_strcat(DataSetName,"_");
									tc_strcat(DataSetName,sVC);
									tc_strcat(DataSetName,"_");
									tc_strcat(DataSetName,Data1);
									tc_strcat(DataSetName,"_FixSuffixTable_Report");

								ITK_CALL(GRM_find_relation_type("IMAN_reference", &IMANReferences_type));	//References folder
								ITK_CALL(GRM_list_secondary_objects_only(LatestRev,IMANReferences_type,&n_attchs,&secondary_objects));
								printf("\nRelation count is  %d\n",n_attchs); fflush(stdout);
								if (n_attchs>0)
								{
									ITK_CALL(GRM_find_relation(LatestRev,secondary_objects[0],IMANReferences_type,&CMRefExist));
									if (CMRefExist!=NULLTAG)
									{
									//ITK_CALL(GRM_delete_relation(CMRefExist));
									//ITK_CALL(AOM_lock(LatestRev));
									//ITK_CALL(AOM_save_without_extensions(LatestRev));
									//ITK_CALL(AOM_unlock(LatestRev));
									ITK_CALL(AOM_refresh(LatestRev,0));
									printf("\nRelation Deleted Successfully\n"); fflush(stdout);
									}

								}

									printf ("\n Dataset Name is .....%s \n",DataSetName);
									fprintf(fplog,"\n Dataset Name is .....%s>>> \n",DataSetName);fflush(fplog);

									ITK_CALL(AE_find_dataset2(DataSetName,&dataset_tag));
									printf ("\n Dataset Name is ....3.%s \n",DataSetName);
									if (dataset_tag !=NULLTAG)
									{
									   if(AOM_ask_value_string(dataset_tag, "object_name", &DataSet_Id)!=ITK_ok);
									   if (tc_strcmp(DataSet_Id,DataSetName)==0)
									   {
										//   ITK_CALL(AE_delete_all_dataset_revs(dataset_tag));
											printf ("\n Dataset is  Deleted : ");
									   }
									   else
										{
										   printf ("\n Dataset not present in TC Need to create%s \n",DataSetName);
										}

									}
									else
									{
									  printf ("\n Dataset not present \n");
									}
									printf ("\n Dataset Name is .....1111%s=%s \n",DataSetName,reportfile);
									ITK_CALL(AE_create_dataset_with_id(msWordType,DataSetName,"FixTableReport","","",&wordDataset));
									ITK_CALL(AE_save_myself(wordDataset));
									ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
									ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
									ITK_CALL(AE_import_named_ref(wordLatestDat_t,"Text",reportfile,NULL,SS_TEXT));
									AOM_save_without_extensions(wordLatestDat_t);
									AOM_refresh(wordLatestDat_t, FALSE);
									AOM_unload(wordLatestDat_t);
									printf ("\n ClrUnitBOMError Dataset Create Suggessfully \n");



							if(IMANReferences_type!=NULLTAG)
							{
								//ITK_CALL(GRM_find_relation(LatestRev,wordLatestDat_t,IMANReferences_type,&CMRefExist));
								//if(CMRefExist==NULLTAG)
								//{
									ITK_CALL(GRM_create_relation(LatestRev,wordLatestDat_t,IMANReferences_type, NULLTAG, &Rel_References));
									ITK_CALL(AOM_load(Rel_References));
									ITK_CALL(GRM_save_relation(Rel_References));
									ITK_CALL(AOM_refresh(Rel_References,0));
								//}else
								//printf("\n Fix Table Report is already attached to Scheme-------------------->>>>");fflush(stdout);
							}


						return 0;
					}

				int createDatasetClrPart(FILE* fp)
					{
								int status;
								 printf ("\n================================================\n");
								tag_t		msWordType				= NULLTAG;
								tag_t		wordDataset				= NULLTAG;
								tag_t		dataset_tag				= NULLTAG;
								tag_t		wordLatestDat_t			= NULLTAG;
								tag_t		qryTag					= NULLTAG;
								tag_t		*CntrolObjectTag		= NULLTAG;
								tag_t IMANReferences_type;
								tag_t Rel_References	= NULLTAG;
								tag_t *secondary_objects = NULLTAG;
								tag_t CMRefExist = NULLTAG;
								char				*DataSetName		= NULL;
								char                *schemeNo             = NULL;
								char                *sVC             = NULL;
								char				*qry_entry[1]		= {"Name"};
								char				**qry_values2		= (char **) MEM_alloc(10 * sizeof(char *));
								int					n_entry				= 1;
								int					rsltCount			= 0;
								int                n_attchs  = 0;
								char				* DataSet_Id		= NULL;
								char	Data1[100]			= "";
								time_t				now;
								struct				tm when;
								
								time(&now);
								when = *localtime(&now);
								//for output file with date.
								strftime(Data1,100,"%d_%b_%Y_%H_%M_%S",&when);

									printf ("\n Inside  Dataset function .. ....\n");
									fprintf(fplog,"\n Inside  Dataset function .. ....>>> \n");fflush(fplog);
									ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&schemeNo));
									ITK_CALL(AOM_ask_value_string(LatestRev,"t5_VehNO",&sVC));

									ITK_CALL(AE_find_datasettype2("Text",&msWordType));

									DataSetName=(char *) MEM_alloc(100 * sizeof(char ));
									tc_strcpy(DataSetName,"");
									tc_strcat(DataSetName,schemeNo);
									tc_strcat(DataSetName,"_");
									tc_strcat(DataSetName,sVC);
									tc_strcat(DataSetName,"_");
									tc_strcat(DataSetName,Data1);
									tc_strcat(DataSetName,"_ClrPart_Report");

								ITK_CALL(GRM_find_relation_type("IMAN_reference", &IMANReferences_type));	//References folder
								ITK_CALL(GRM_list_secondary_objects_only(LatestRev,IMANReferences_type,&n_attchs,&secondary_objects));
								printf("\nRelation count is  %d\n",n_attchs); fflush(stdout);
								if (n_attchs>0)
								{
									ITK_CALL(GRM_find_relation(LatestRev,secondary_objects[0],IMANReferences_type,&CMRefExist));
									if (CMRefExist!=NULLTAG)
									{
									//ITK_CALL(GRM_delete_relation(CMRefExist));
									//ITK_CALL(AOM_lock(LatestRev));
									//ITK_CALL(AOM_save_without_extensions(LatestRev));
									//ITK_CALL(AOM_unlock(LatestRev));
									ITK_CALL(AOM_refresh(LatestRev,0));
									printf("\nRelation Deleted Successfully\n"); fflush(stdout);
									}

								}

									printf ("\n Dataset Name is .....%s \n",DataSetName);
									fprintf(fplog,"\n Dataset Name is .....%s>>> \n",DataSetName);fflush(fplog);

									ITK_CALL(AE_find_dataset2(DataSetName,&dataset_tag));
									printf ("\n Dataset Name is ....3.%s \n",DataSetName);
									if (dataset_tag !=NULLTAG)
									{
									   if(AOM_ask_value_string(dataset_tag, "object_name", &DataSet_Id)!=ITK_ok);
									   if (tc_strcmp(DataSet_Id,DataSetName)==0)
									   {
										//   ITK_CALL(AE_delete_all_dataset_revs(dataset_tag));
											printf ("\n Dataset is  Deleted : ");
									   }
									   else
										{
										   printf ("\n Dataset not present in TC Need to create%s \n",DataSetName);
										}

									}
									else
									{
									  printf ("\n Dataset not present \n");
									}
									printf ("\n Dataset Name is .....1111%s=%s \n",DataSetName,rptFixTblMstrClrSchm);
									ITK_CALL(AE_create_dataset_with_id(msWordType,DataSetName,"FixTableReport","","",&wordDataset));
									ITK_CALL(AE_save_myself(wordDataset));
									ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
									ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
									ITK_CALL(AE_import_named_ref(wordLatestDat_t,"Text",rptFixTblMstrClrSchm,NULL,SS_TEXT));
									AOM_save_without_extensions(wordLatestDat_t);
									AOM_refresh(wordLatestDat_t, FALSE);
									AOM_unload(wordLatestDat_t);
									printf ("\n ClrUnitBOMError Dataset Create Suggessfully \n");



							if(IMANReferences_type!=NULLTAG)
							{
								//ITK_CALL(GRM_find_relation(LatestRev,wordLatestDat_t,IMANReferences_type,&CMRefExist));
								//if(CMRefExist==NULLTAG)
								//{
									ITK_CALL(GRM_create_relation(LatestRev,wordLatestDat_t,IMANReferences_type, NULLTAG, &Rel_References));
									ITK_CALL(AOM_load(Rel_References));
									ITK_CALL(GRM_save_relation(Rel_References));
									ITK_CALL(AOM_refresh(Rel_References,0));
								//}else
								//printf("\n Fix Table Report is already attached to Scheme-------------------->>>>");fflush(stdout);
							}


						return 0;
					}

				int FunToFindDmyClRelWithColScm(tag_t ClrSchmTag,char* compCodeStrInList)
				{
					int		status						=	0;
					int		flagallow					=	0;
					int		n_entriesF					=	3;
					tag_t	queryTagF					=	NULLTAG;
					char*	clrsrlmain1					=	NULL;
					int		resultCountF				=	0;
					tag_t	*qry_outputF				=	NULLTAG;
					char *item_id_ColDatamain			=	NULL;
					char* dupintrnalscheme				=	NULL;
					char* ClrsrlCat						=	NULL;
					char* sObjectNameDt					=	NULL;
					char* clrsrlmain2					=	NULL;
					char* sPrtCompCode					=	NULL;
					char* sObjectName					=	NULL;
					char* sClrSerial					=	NULL;
					char* sInternalScheme				=	NULL;
					tag_t SchmHasClrData_RelTag			=	NULLTAG;
					tag_t del_relation					=	NULLTAG;
					int m = 0;
					int SchemeDataCnt = 0;
					tag_t* ClrSchemeData_tag = NULLTAG;
					clrsrlmain2=(char *)MEM_alloc(100);

					fprintf(fplog," \n Inside FunToFindDmyClRelWithColScm \n\t"); fflush(stdout); fflush(fplog);

					(POM_refresh_instances(1,&LatestRev,class_to_load_as,lock_type));

					(GRM_find_relation_type	("T5_ShmHasClrData",&SchmHasClrData_RelTag));


					(GRM_list_secondary_objects_only(LatestRev,SchmHasClrData_RelTag,&SchemeDataCnt,&ClrSchemeData_tag));

					fprintf(fplog,"\n Color scheme data count SchemeDataCnt: %d\n",SchemeDataCnt); fflush(fplog);

					if(SchemeDataCnt>0)
					{
						for (m=0;m<SchemeDataCnt;m++ )
						{
							(AOM_ask_value_string(ClrSchemeData_tag[m],"item_id",&sObjectName));
							(AOM_ask_value_string(ClrSchemeData_tag[m],"t5_PrtCatCode",&sPrtCompCode));
							(AOM_ask_value_string(ClrSchemeData_tag[m],"t5_ClSrl",&sClrSerial));
							(AOM_ask_value_string(ClrSchemeData_tag[m],"t5_InternalSchm",&sInternalScheme));
							//fprintf(fplog,"\n sClrSerial and sInternalScheme: %s : %s \n",sClrSerial,sInternalScheme); fflush(fplog);
						   // fprintf(fplog,"\n Before compare in file compcode  and latest colour scheme comp code: %s : %s \n",compCodeStrInList,compCodeStrInList); fflush(fplog);
							if(tc_strcmp(compCodeStrInList,sPrtCompCode)==0)
							{
							 fprintf(fplog,"\n sClrSerial and sInternalScheme: %s : %s \n",sClrSerial,sInternalScheme); fflush(fplog);
								//if(tc_strcmp(sInternalScheme,"T")==0)
								if((tc_strcmp(sClrSerial,"##;DUMMY_COLSRL")==0) && (tc_strcmp(sInternalScheme,"T")==0))
								{
								 fprintf(fplog,"\n inside ##;DUMMY_COLSRL After compare in file compcode  and latest colour scheme comp code: %s : %s \n",compCodeStrInList,sPrtCompCode); fflush(fplog);
									flagallow=1;
									break;
								}
								else
								{
									flagallow=0;
								}
							}
						}

					fprintf(fplog,"\n closing FunToFindDmyClRelWithColScm flagallow: %d\n",flagallow); fflush(fplog);

					}

					return flagallow;
				}
				int FunToFindDummyClrSrlNDelRel(tag_t ClrSchmTag, char* PrtCmpCodeDel)
				{
					int		status						=	0;
					int		n_entriesF					=	3;
					//int		n_entriesF					=	1;
					tag_t	queryTagF					=	NULLTAG;
					char*	clrsrlmain1					=	NULL;
					int		resultCountF				=	0;
					tag_t	*qry_outputF				=	NULLTAG;
					char *item_id_ColDatamain			=	NULL;
					char* dupintrnalscheme				=	NULL;
					char* ClrsrlCat						=	NULL;
					char* sObjectNameDt					=	NULL;
					char* sInternalScheme					=	NULL;
					char* clrsrlmain2					=	NULL;
					tag_t SchmHasClrData_RelTag			=	NULLTAG;
					tag_t del_relation					=	NULLTAG;
					int m = 0;

					clrsrlmain2=(char *)MEM_alloc(100);

					fprintf(fplog," \n Inside FunToFindDummyClrSrlNDelRel \n\t"); fflush(stdout); fflush(fplog);

					ITK_CALL(GRM_find_relation_type	("T5_ShmHasClrData",&SchmHasClrData_RelTag));

					//	 Find ##;DUMMY_COLSRL comp code

					if(QRY_find2("ColorSchemeDataRevision", &queryTagF));
					//if(QRY_find2("ColorSchemeCompCodeDataRevision", &queryTagF));
					if (queryTagF)
					{
					fprintf(fplog,"Found Query 'ColorSchemeDataRevision' \n\t"); fflush(stdout); fflush(fplog);
					}
					else
					{
					fprintf(fplog,"Not Found Query 'ColorSchemeDataRevision' \n\t"); fflush(stdout); fflush(fplog);
					return status;
					}
					char *qry_entriesF[3] = {"Comp Code","Internal Scheme","Color Serial"};
					char **qry_valuesF = (char **) MEM_alloc(50 * sizeof(char *));

					//char *qry_entriesF[1] = {"Name"};
					//char **qry_valuesF = (char **) MEM_alloc(50 * sizeof(char *));

					//tc_strcpy(clrsrlmain2,"");
					//tc_strcat(clrsrlmain2,PrtCmpCodeDel);
					//tc_strcat(clrsrlmain2,"*T*");
					//tc_strcat(clrsrlmain2,"##");
					//tc_strcat(clrsrlmain2,"*");
					//tc_strcat(clrsrlmain2,"DUMMY_COLSRL");

					tc_strcat(clrsrlmain2,"##");
					tc_strcat(clrsrlmain2,"*");
					tc_strcat(clrsrlmain2,"DUMMY_COLSRL");

					fprintf(fplog,"clrsrlmain2 --------> %s\n",clrsrlmain2); fflush(fplog);

					qry_valuesF[0] = PrtCmpCodeDel;
					qry_valuesF[1] = "*T*";
					qry_valuesF[2] = clrsrlmain2;

					//qry_valuesF[0] = clrsrlmain2;

					ITK_CALL(QRY_execute(queryTagF, n_entriesF, qry_entriesF, qry_valuesF, &resultCountF, &qry_outputF));
					fprintf(fplog,"\n Count of Query Values resultCountF ------------------>  %d \n",resultCountF); fflush(fplog);
					if(resultCountF>0)
					{
						for (m=0;m<resultCountF ;m++ )
						{
							ITK_CALL(AOM_UIF_ask_value(qry_outputF[m],"object_name",&sObjectNameDt));
							ITK_CALL(AOM_UIF_ask_value(qry_outputF[m],"t5_InternalSchm",&sInternalScheme));

						   fprintf(fplog," \n Inside FunToFindDummyClrSrlNDelRel: Object name is : %s \n\t",sObjectNameDt); fflush(stdout);

							ITK_CALL(GRM_find_relation(ClrSchmTag,qry_outputF[m],SchmHasClrData_RelTag,&del_relation));
							if(del_relation!=NULLTAG)
							{
							if ((tc_strstr(sObjectNameDt,"DUMMY_COLSRL")!=NULL) && (tc_strcmp(sInternalScheme,"T")==0))
							{
							fprintf(fplog," \n Inside FunToFindDummyClrSrlNDelRel: found relation, now deleting it\n\t"); fflush(stdout);
							ITK_CALL(GRM_delete_relation(del_relation));
							}
							}
							ITK_CALL(AOM_refresh(LatestRev,0));
							ITK_CALL(AOM_lock(LatestRev));
							ITK_CALL(AOM_save_without_extensions(LatestRev));
							//ITK_CALL(AOM_unlock(LatestRev));
							ITK_CALL(AOM_refresh(LatestRev,1));
							ITK_CALL(AOM_load(LatestRev));

							ITK_CALL(POM_refresh_instances(1,&LatestRev,class_to_load_as,lock_type));
							//(POM_load_instances(1,&LatestRev,class_to_load_as,lock_type));

						}
					}
					fprintf(fplog," \n closing FunToFindDummyClrSrlNDelRel \n\t"); fflush(stdout); fflush(fplog);
				//	 end

					return status;
				}

				tag_t FunToReturnLatestRelzRevision(char *Item_ID)  // added by Gajanan disscused with Sharvari Mam for latest Relz revision date 18/05/23
				{
					int status =0;
					tag_t *tags_found = NULL;
					int n_tags_found= 0;
					int n_rev= 0;
					int i = 0;
					tag_t item_tag =NULLTAG;
					tag_t*	rev_list	= NULLTAG;
					char *sitem_id=NULL;
					char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
					char **values = (char **) MEM_alloc(1 * sizeof(char *));
					char *RelStatusmatch = NULL;
					tag_t LatestRelzRevision;
					attrs[0] ="item_id";
					values[0] = (char *) Item_ID;

					ITK_CALL(ITEM_find_item(Item_ID,&item_tag));


					//ITK_CALL(ITEM_ask_latest_rev(item_tag,&LatestRevision));
					ITK_CALL(ITEM_list_all_revs(item_tag,&n_rev,&rev_list));
					if(n_rev > 0)
					{

						for(i = n_rev-1 ; i >= 0 ; i--)
							{
								ITK_CALL(AOM_UIF_ask_value (rev_list[i], "release_status_list", &RelStatusmatch));
								if((tc_strstr(RelStatusmatch,"ERC Released")!=NULL)||(tc_strstr(RelStatusmatch,"T5_LcsErcRlzd")!=NULL))
								{
									LatestRelzRevision=rev_list[i];
									ITK_CALL(AOM_ask_value_string(LatestRelzRevision,"item_id",&sitem_id));
									//fprintf(fplog,"\n sitem_id: %s \n\n",sitem_id);	 fflush(fplog);
									break;
								}

							}
					}

					MEM_free(tags_found);

					return LatestRelzRevision;
				}

				tag_t FunToReturnLatestRevision(char *Item_ID)
				{
					int status =0;
					tag_t *tags_found = NULL;
					int n_tags_found= 0;
					int n_rev= 0;
					tag_t item_tag =NULLTAG;
					char *sitem_id=NULL;
					char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
					char **values = (char **) MEM_alloc(1 * sizeof(char *));
					tag_t LatestRevision;
					attrs[0] ="item_id";
					values[0] = (char *) Item_ID;

					ITK_CALL(ITEM_find_item(Item_ID,&item_tag));

					//item_tag = tags_found[0];

					ITK_CALL(ITEM_ask_latest_rev(item_tag,&LatestRevision));

					ITK_CALL(AOM_ask_value_string(LatestRevision,"item_id",&sitem_id));

					//fprintf(fplog,"\n sitem_id: %s \n\n",sitem_id);	 fflush(fplog);

					MEM_free(tags_found);

					return LatestRevision;

				}
				// This function returns color ID when input is as CCA_CENTER_AIR_VENT~CLRPRT_ASY_4
				// input Colour ID as CLRPRT_ASY_4*
				char* FunToGetColorID(char *ColorIDStr)
				{
					int status =0;
					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int     n_entry				=	1;
					char    *qry_sys_entry[1]	=	{"Colour ID"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCount			=	0;
					int		IsValidFlag			=	0;
					tag_t   *ClrSuf_tag			=	NULLTAG;
					char	*sClrSerSuf			=	NULL;
					char	*sClrID				=	NULL;
					char	*sInternalschm		=	NULL;
					char	*compcode1			=	NULL;
					char	*colorid1			=	NULL;
					char	*clrid				=	NULL;
					int m=0;

					clrid=(char *)MEM_alloc(100);
					//ColorIDStr= CCA_CENTER_AIR_VENT~CLRPRT_ASY_4
					printf("\n  ");fflush(fplog);
					fprintf(fplog,"\n inside FunToGetColorID ColorIDStr [%s] ",ColorIDStr);fflush(fplog);

					(QRY_find2("Colour Master", &Cntl_obj_Qtag));
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n Found Query Colour Master... \n");fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Not Found Query Colour Master... \n");fflush(fplog);
					}

					compcode1 =	strtok(ColorIDStr,"~");
					colorid1 =	strtok(NULL,"");

					strcpy(clrid,"");
					strcpy(clrid,colorid1);
					strcpy(clrid,"*");

					qry_sys_values[0] = clrid;
					(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCount, &ClrSuf_tag));
					printf(" \n "); fflush(stdout);
					if(IntCount>0)
					{
						for (m=0;m<IntCount;m++)
						{
							(AOM_UIF_ask_value(ClrSuf_tag[m],"t5_IntScheme",&sInternalschm));
							fprintf(fplog,"\n sInternalschm[%s] \n",sInternalschm);fflush(fplog);
							if (strcmp(sInternalschm,"T")==0)
							{
								(AOM_UIF_ask_value(ClrSuf_tag[m],"object_name",&sClrSerSuf));
								(AOM_UIF_ask_value(ClrSuf_tag[m],"t5_ColourId",&sClrID));
								fprintf(fplog,"\n sClrSerSuf[%s] sClrID[%s]\n",sClrSerSuf,sClrID);fflush(fplog);
							}
							else
							{
								fprintf(fplog,"\n sInternalschm is Y or N \n");fflush(fplog);

							}
				
						}
						// Function to Create Color Scheme Data and Add it in Color Scheme.
						//FunToCreClrSchData(sCompCodeS,sClrSerSuf,sClrID);
					}

					return sClrSerSuf;
				}

				char* FunToGetColorSerial(char *colorsuf)
				{
					int status =0;
					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int     n_entry				=	1;
					char    *qry_sys_entry[1]	=	{"Colour Serial"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCount			=	0;
					int		IsValidFlag			=	0;
					tag_t   *ClrSuf_tag			=	NULLTAG;
					char	*ClrSerSuf			=	NULL;
					char	*Internalschm		=	NULL;
					char	*sClrID				=	NULL;
					char	*object_string		=	NULL;
					char	*clrsuf				=	NULL;
					int m=0;
					clrsuf=(char *)MEM_alloc(100);
					object_string=(char *)MEM_alloc(100);
					//ColorIDStr= CCA_CENTER_AIR_VENT~CLRPRT_ASY_4
					printf("\n  ");fflush(fplog);
					fprintf(fplog,"\n inside FunToGetColorID colorsuf [%s] ",colorsuf);fflush(fplog);

					(QRY_find2("Colour Master", &Cntl_obj_Qtag));
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n Found Query Colour Master... \n");fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Not Found Query Colour Master... \n");fflush(fplog);
					}


					strcpy(clrsuf,"");
					strcpy(clrsuf,"*");
					strcpy(clrsuf,colorsuf);
					

					qry_sys_values[0] = clrsuf;
					(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCount, &ClrSuf_tag));
					printf(" \n "); fflush(stdout);
					if(IntCount>0)
					{
					 
					 for (m=0;m<IntCount;m++)
						{
							(AOM_UIF_ask_value(ClrSuf_tag[m],"t5_IntScheme",&Internalschm));
							fprintf(fplog,"\n Internalschm......[%s] \n",Internalschm);fflush(fplog);
							if (strcmp(Internalschm,"T")==0)
							{
								(AOM_UIF_ask_value(ClrSuf_tag[m],"object_name",&ClrSerSuf));
								(AOM_UIF_ask_value(ClrSuf_tag[m],"t5_ColourId",&sClrID));
								
								strcpy(clrsuf,"");
								strcat(object_string,ClrSerSuf);
								strcat(object_string,";");
								strcat(object_string,sClrID);
								fprintf(fplog,"\n sClrSerSuf[%s] sClrID[%s]  object_string[%s]\n",ClrSerSuf,sClrID,object_string);fflush(fplog);
							}
							else
							{
								fprintf(fplog,"\n sInternalschm is Y or N \n");fflush(fplog);

							}
						}
							

					}

					return object_string;
				}
				char* FunToGetColorID_NEW(char *ColorIDStr)
				{
					int status =0;
					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int     n_entry				=	1;
					char    *qry_sys_entry[1]	=	{"Colour Serial"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCount			=	0;
					int		IsValidFlag			=	0;
					tag_t   *ClrSuf_tag			=	NULLTAG;
					char	*sClrSerSuf			=	NULL;
					char	*sClrID				=	NULL;
					char    *sInternalschm      =   NULL;
					char	*compcode1			=	NULL;
					char	*colorid1			=	NULL;
					char	*clrid				=	NULL;
					int m=0;

					clrid=(char *)MEM_alloc(100);
					//ColorIDStr= CCA_CENTER_AIR_VENT~CLRPRT_ASY_4
					printf("\n  ");fflush(fplog);
					fprintf(fplog,"\n inside FunToGetColorID_NEW ColorIDStr [%s] ",ColorIDStr);fflush(fplog);

					(QRY_find2("Colour Master", &Cntl_obj_Qtag));
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n FunToGetColorID_NEW Found Query Colour Master... \n");fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n FunToGetColorID_NEW Not Found Query Colour Master... \n");fflush(fplog);
					}

					//compcode1 =	strtok(ColorIDStr,"~");
					//colorid1 =	strtok(NULL,"");

					//strcpy(clrid,"");
					//strcpy(clrid,colorid1);
					//strcpy(clrid,"*");

					qry_sys_values[0] = ColorIDStr;
					(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCount, &ClrSuf_tag));
					printf(" \n "); fflush(stdout);
					if(IntCount>0)
					{
						
						for (m=0;m<IntCount;m++)
						{
							(AOM_UIF_ask_value(ClrSuf_tag[m],"t5_IntScheme",&sInternalschm));
							fprintf(fplog,"\n sInternalschm[%s] \n",sInternalschm);fflush(fplog);
							if (strcmp(sInternalschm,"T")==0)
							{
								(AOM_UIF_ask_value(ClrSuf_tag[m],"object_name",&sClrSerSuf));
								(AOM_UIF_ask_value(ClrSuf_tag[m],"t5_ColourId",&sClrID));
								fprintf(fplog,"\n sClrSerSuf[%s] sClrID[%s]\n",sClrSerSuf,sClrID);fflush(fplog);
							}
							else
							{
								fprintf(fplog,"\n sInternalschm is Y or N \n");fflush(fplog);

							}
				
						}
						
						
						// Function to Create Color Scheme Data and Add it in Color Scheme.
						//FunToCreClrSchData(sCompCodeS,sClrSerSuf,sClrID);
					}

					return sClrID;
				}
				char* funToGetPlaceHolderSuffix(char* compcodeStr)
				{
					// query parent fix table data

					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int		l					=	0;
					int     n_entry				=	1;
					char    *qry_sys_entry[1]	=	{"Colour ID"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCountI			=	0;
					tag_t   *PrntClrSuf_tag		=	NULLTAG;
					char*	Obj_name			=	NULL;
					char*	sPlcHoldSuf			=	NULL;
					char	*Internalschm		=    NULL;
					char*	compcode			=	NULL;
					char*	d="~";
					char*	e="*";
					int m=0;

					compcode=(char *)MEM_alloc(100);

					fprintf(fplog,"\n inside funToGetPlaceHolderSuffix...compcodeStr %s \n",compcodeStr); fflush(fplog);

					(QRY_find2("Colour Master", &Cntl_obj_Qtag));
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n Get Colour Master... \n"); fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n No Colour Master... \n"); fflush(fplog);
					}

					//compcode = replaceWord(compcodeStr, d, e);

					strcpy(compcode,"");
					strcpy(compcode,compcodeStr);
					strcat(compcode,"*");

					fprintf(fplog,"\n No Colour Master... compcode %s \n",compcode); fflush(fplog);

					qry_sys_values[0] = compcode;
					//qry_sys_values[1] = StrSuf;
					(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCountI, &PrntClrSuf_tag));
					fprintf(fplog," \n inside funToGetPlaceHolderSuffix Parent color suffix count IntCountI: [%d]\n",IntCountI);  fflush(fplog);
					if(IntCountI>0)
					{
						
						for (m=0;m<IntCountI;m++)
						{
							(AOM_UIF_ask_value(PrntClrSuf_tag[m],"t5_IntScheme",&Internalschm));
							fprintf(fplog,"\n Internalschm......[%s] \n",Internalschm);fflush(fplog);
							if (strcmp(Internalschm,"T")==0)
							{
								AOM_ask_value_string(PrntClrSuf_tag[0],"object_name",&Obj_name);
							}
							else
							{
								fprintf(fplog,"\n sInternalschm is Y or N \n");fflush(fplog);

							}
						}
						
						
						//AOM_ask_value_string(PrntClrSuf_tag[0],"t5_PlaceHolderSuffix",&sPlcHoldSuf);

					}

					return Obj_name;
				}
				int FunToGetNewObjName(char* sOldObjName,char **sObjNm)
				{

					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int		l					=	0;
					int     n_entry				=	1;
					int     flag_i				=	0;
					int     Iseq				=	0;
					int     INum				=	0;
					int     IClrID				=	0;

					char    *qry_sys_entry[1]	=	{"Name"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCount			=	0;
					tag_t   *PrntClrSuf_tag		=	NULLTAG;


					char*	compcode			=	NULL;
					char*	SplcHoldr			=	NULL;
					char*	SClrID				=	NULL;
					char*	Sseq				=	NULL;
					char*	Num					=	NULL;
					char*	Num1				=	NULL;
					char*	sNewObjName			=	NULL;
					char*	CLRPRT				=	NULL;
					char*	ASY					=	NULL;
					int		IntCldCmp			=	0;
					char	SnwSeq[50];
					char	SNumS[50];
					char	*SclrSuf_Nm			=	NULL;
					SclrSuf_Nm=(char *) MEM_alloc(250);
					Num=(char *) MEM_alloc(15);
					*sObjNm=(char *) MEM_alloc(250);


					fprintf(fplog,"\n inside FunToGetNewObjName...sOldObjName %s\n",sOldObjName);fflush(fplog);//CCA_CENTER_AIR_VENT~CLRPRT_ASY_1

					if(QRY_find2("Color_Suffix_Query", &Cntl_obj_Qtag)!=ITK_ok);
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n -- Found Query Color_Suffix_Query... \n");fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Not Found Query Color_Suffix_Query... \n");fflush(fplog);
					}

					qry_sys_values[0] = sOldObjName;//CCA_AIR_VENT~CLRPART_ASSY~1
					//CCA_CENTER_AIR_VENT~CLRPRT_ASY_1
					(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCount, &PrntClrSuf_tag));
					fprintf(fplog," \n inside FunToGetNewObjName Parent color suffix count IntCount: [%d]\n",IntCount);fflush(fplog);
					if(IntCount>0)
					{
						for (l=0;l<IntCount;l++)
						{
							flag_i=1;

							SplcHoldr = strtok(sOldObjName,"~");
							if(tc_strstr(sOldObjName,"~")!=NULL)
							{
								fprintf(fplog,"\n tt \n");fflush(fplog);
							SClrID	  = strtok(NULL,"~");
							Sseq	  = strtok(NULL,"");
							}
							else
							{
							fprintf(fplog,"\n mm \n");fflush(fplog);
							SClrID	  = strtok(NULL,"");
							}
							fprintf(fplog,"\n SClrID:[%s] \n",SClrID);fflush(fplog);
							if(tc_strlen(Sseq)>0)
							{
							Iseq = atoi(Sseq);
							fprintf(fplog,"\n :: Iseq is :: %d\n",Iseq);fflush(fplog);
							Iseq = Iseq+1;
							fprintf(fplog,"\n :: Iseq after append :: %d\n",Iseq);fflush(fplog);
							sprintf(SnwSeq, "%d",Iseq);

							fprintf(fplog,"\n :: SnwSeq after append :: %s\n",SnwSeq);fflush(fplog);

							strcpy(SclrSuf_Nm,"");
							strcat(SclrSuf_Nm,SplcHoldr);
							strcat(SclrSuf_Nm,"~");
							strcat(SclrSuf_Nm,SClrID);
							strcat(SclrSuf_Nm,"~");
							strcat(SclrSuf_Nm,SnwSeq);
							}
							else
							{
							fprintf(fplog,"\n else cat CLRPRT_ASY_NUM");fflush(fplog);//CLRPART_ASSY~2 CLRPART_ASY_2
							fprintf(fplog,"\n 3333SClrID:  %s",SClrID);fflush(fplog);//CLRPART_ASSY~2 CLRPART_ASY_2
							//CLRPRT_ASY10
							if (strstr(SClrID,"_ASY")!=NULL)
							{
								Num1 = subString(SClrID,10,12);
								fprintf(fplog,"\n substring Num1:  %s",Num1);fflush(fplog);
							}
							else
							{

								Num1 = subString(SClrID,9,12);
								fprintf(fplog,"\n substring Num1:  %s",Num1);fflush(fplog);

							}


							CLRPRT = tc_strtok(SClrID,"_");

							fprintf(fplog,"\n 4444CLRPRT:  %s",CLRPRT);fflush(fplog);

							if(tc_strcmp(CLRPRT,"CLRPART")==0)
								{
									strcpy(SclrSuf_Nm,"");
									strcat(SclrSuf_Nm,SplcHoldr);
									strcat(SclrSuf_Nm,"~");
									strcat(SclrSuf_Nm,"CLRPRT_ASY_1");
								}
								else
								{
								fprintf(fplog,"\n SClrID in else:  %s",SClrID);fflush(fplog);
								if(strstr(SClrID,"~")!=NULL)
								{
								fprintf(fplog,"\n inside if SClrID in else: ");fflush(fplog);
								ASY = tc_strtok(NULL,"~");
								Num = tc_strtok(NULL,"~");
								}
								else if(atoi(Num1)>9)
								{
								fprintf(fplog,"\n inside else if SClrID in else: ");fflush(fplog);
								strcpy(Num,"");
								strcpy(Num,Num1);
								}
								else
								{
								fprintf(fplog,"\n inside else SClrID  ");fflush(fplog);
								ASY = tc_strtok(NULL,"_");
								Num= tc_strtok(NULL,"_");

								}
								fprintf(fplog,"\n outside if else  ");fflush(fplog);
								INum = atoi(Num);//CLRPRT_ASY_1
								fprintf(fplog,"\n :: INum is :: %d\n",INum);fflush(fplog);
								INum = INum+1;
								fprintf(fplog,"\n :: INum after append :: %d\n",INum);fflush(fplog);
								sprintf(SNumS, "%d",INum);
								fprintf(fplog,"\n :: SplcHoldr: %s \n CLRPRT: %s \n ASY: %s \n INum  :: %d\n",SplcHoldr,CLRPRT,ASY,INum);fflush(fplog);
								strcpy(SclrSuf_Nm,"");
								strcat(SclrSuf_Nm,SplcHoldr);
								strcat(SclrSuf_Nm,"~");
								strcat(SclrSuf_Nm,CLRPRT);
								if(INum>99)
								{
								  strcat(SclrSuf_Nm,"_");
								  strcat(SclrSuf_Nm,"AS");
								}
								else if(INum>9 && INum<=99)
								{
								strcat(SclrSuf_Nm,"_");
								strcat(SclrSuf_Nm,"ASY");
								}
								else
								{
								strcat(SclrSuf_Nm,"_");
								strcat(SclrSuf_Nm,ASY);
								}

								// if value is more than 9 then concat directly.
								fprintf(fplog,"\n :: check  SclrSuf_Nm: %s INum  :: %d\n",SclrSuf_Nm ,INum);fflush(fplog);
								if(INum<=9)
								{
								strcat(SclrSuf_Nm,"_");
								strcat(SclrSuf_Nm,SNumS);
								}
								else if(INum>9)
								{
								strcat(SclrSuf_Nm,SNumS);
								}
								}
							}
							FunToGetNewObjName(SclrSuf_Nm,&sNewObjName);

							strcpy(*sObjNm,"");
							tc_strcat(*sObjNm,sNewObjName);
							//tc_strcat(*sObjNm,SclrSuf_Nm);
							break;
						}
					}
					else
					{
					flag_i=0;
					strcpy(*sObjNm,"");
					tc_strcat(*sObjNm,sOldObjName);
					}
					return flag_i;
				}
				// function to new entry in fix table as given input CCA_CENTER_AIR_VENT~CLRPRT_ASY_4
				int funToNewEntryInFixTable(char* compcodeStr,char** CompCodeSet,int CompCodeInt,char **LtstCompCode)
				{
					fprintf(fplog,"\n inside funToNewEntryInFixTable...compcodeStr %s\n",compcodeStr); fflush(fplog);

					// query parent fix table data
					int status			=	0;
					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int		l					=	0;
					int		m					=	0;
					char* d	= "~";
					char* e  = "*";
					int     n_entry				=	2;
					int     Nflag				=	0;
					int     IntCmCode			=	0;
					char    *qry_sys_entry[2]	=	{"Name","Place Holder"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCount			=	0;
					tag_t   *PrntClrSuf_tag		=	NULLTAG;
					char*	Obj_name			=	NULL;
					char*	ChildCompCode		=	NULL;
					char*	compcode			=	NULL;
					int		IntCldCmp			=	0;
					char	**sChldClrSufixvalues  =	NULL;
					char	*ChldCompCode		  =	NULL;
					char	*ChldCompCodeCpy		  =	NULL;
					char	*SplcHoldr			  =	NULL;
					char	*ScatSuf		  =	NULL;
					char	*StrSufStr		  =	NULL;
					char	*placeholderS		  =	NULL;
					char	*clrSerialS		  =	NULL;
					char	*plchlS		  =	NULL;

					tag_t	Clr_type_tag				= NULLTAG;
					tag_t	object_create_input_tag		= NULLTAG;
					tag_t	Chd_type_tag				= NULLTAG;
					tag_t	object_create_chd_tag		= NULLTAG;
					tag_t	ColSufTag					= NULLTAG;
					tag_t	ChdColSufTag				= NULLTAG;
					tag_t   Cntl_obj_tag				=	NULLTAG;
					int     n					=	2;
					char    *qry_entry[2]		=	{"Name","Type"};
					char    **qry_values		=  (char **) MEM_alloc(10 * sizeof(char *));
					int		Count				=	0;
					tag_t   *ChildClrSuf_tag    =	NULLTAG;


					ChldCompCodeCpy= (char *) MEM_alloc (250);
					ChldCompCodeCpy= (char *) MEM_alloc (250);
					char **ChldCompCodeSet = (char **) MEM_alloc(1 * sizeof(char *));
					compcode= (char *) MEM_alloc (100);
					ScatSuf= (char *) MEM_alloc (100);
					plchlS= (char *) MEM_alloc (100);
					*LtstCompCode=(char *) MEM_alloc(250);


					strcpy(*LtstCompCode,"");

					fprintf(fplog,"\n inside funToNewEntryInFixTable...compcodeStr %s\n",compcodeStr); fflush(fplog);//CLRPRT_ASY_1

					(QRY_find2("Color_Suffix_Query", &Cntl_obj_Qtag));
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n -- Found Query Color_Suffix_Query... \n"); fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Not Found Query Color_Suffix_Query... \n"); fflush(fplog);
					}

					strcpy(plchlS,"");
					strcpy(plchlS,compcodeStr);
					placeholderS = strtok(plchlS,"~");
					clrSerialS = strtok(NULL,"");
					compcode = replaceWord(compcodeStr, d, e);

					fprintf(fplog,"\n  placeholderS %s\n clrSerialS %s",placeholderS,clrSerialS); fflush(fplog);

					qry_sys_values[0] = compcode;
					qry_sys_values[1] = placeholderS;
					(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCount, &PrntClrSuf_tag));
					fprintf(fplog," \n inside funToNewEntryInFixTable Parent color suffix count IntCount: [%d] \n",IntCount);  fflush(fplog);
					if(IntCount==0)
					{

						ITK_CALL(TCTYPE_find_type("T5_ColorSuffix", NULL, &Clr_type_tag));
						ITK_CALL(TCTYPE_construct_create_input(Clr_type_tag, &object_create_input_tag));

						ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",compcodeStr));
						ITK_CALL(TCTYPE_create_object(object_create_input_tag, &ColSufTag));

						if(ColSufTag)
						{
						fprintf(fplog,"\n t5CreateObject : object created."); fflush(fplog);
						ITK_CALL(AOM_save_without_extensions(ColSufTag));
						ITK_CALL(AOM_refresh(ColSufTag,0));

						ITK_CALL(AOM_refresh(ColSufTag,1));

						if(strstr(compcodeStr,"~")!=NULL)
							{
						SplcHoldr = strtok(compcodeStr,"~");
						if(strstr(compcodeStr,"~")!=NULL)
							{
							ScatSuf = strtok(NULL,"~");
							}
							else
							{
							ScatSuf = strtok(NULL,"");
							}
							}
							else
							{
								strcpy(ScatSuf,"");
								strcat(ScatSuf,compcodeStr);
							}

						StrSufStr = funToGetPlaceHolderSuffix(ScatSuf);

						ITK_CALL(AOM_set_value_string(ColSufTag,"t5_PlaceHolder",SplcHoldr));
						ITK_CALL(AOM_set_value_string(ColSufTag,"t5_PlaceHolderSuffix",StrSufStr));

						ITK_CALL(AOM_save_without_extensions(ColSufTag));
						ITK_CALL(AOM_refresh(ColSufTag,1));

						fprintf(fplog,"\n CompCodeInt:[%d]\n",CompCodeInt); fflush(fplog);

							if(CompCodeInt>0)
							{

							fprintf(fplog,"\n CompCodeInt:[%d]\n",CompCodeInt); fflush(fplog);

							for(l=0;l<CompCodeInt;l++)
								{
								fprintf(fplog,"\n suffixInt22:[%d]\n",CompCodeInt); fflush(fplog);
								fprintf(fplog,"\n Child Color Suffix: [%s]\n",CompCodeSet[l]); fflush(fplog);

								ITK_CALL(QRY_find2("General...", &Cntl_obj_tag));
								if (Cntl_obj_tag)
								{
									fprintf(fplog,"\n -- Found Query General... \n"); fflush(fplog);
								}
								else
								{
									fprintf(fplog,"\n Not Found Query General... \n"); fflush(fplog);
								}
								fprintf(fplog,"\n CompCodeSet [%s] \n",CompCodeSet[l]); fflush(fplog);

								ChildCompCode = replaceWord(CompCodeSet[l], d, e);

								qry_values[0] = ChildCompCode;
								qry_values[1] = "Child Color Suffix" ;
								ITK_CALL(QRY_execute(Cntl_obj_tag, n, qry_entry, qry_values, &Count, &ChildClrSuf_tag));
								fprintf(fplog," \n Child Color Suffix Count:[%d] \n",Count);  fflush(fplog);
								if(Count>0)
								{
									// create relation between color suffix and child color suffix.
									fprintf(fplog,"\n create relation between color suffix and child color suffix. \n"); fflush(fplog);
									if(FL_insert(ColSufTag,ChildClrSuf_tag[0],99));
									if(AOM_save_without_extensions(ColSufTag));

								}
								else
								{
								// create child color suffix
								ITK_CALL(TCTYPE_find_type("T5_Child_Color_Suffix", NULL, &Chd_type_tag));
								ITK_CALL(TCTYPE_construct_create_input(Chd_type_tag, &object_create_chd_tag));
								ITK_CALL(AOM_set_value_string(object_create_chd_tag,"object_name",CompCodeSet[l]));
								ITK_CALL(TCTYPE_create_object(object_create_chd_tag, &ChdColSufTag));
								if(ChdColSufTag)
								{
									fprintf(fplog,"\n t5CreateObject : object created."); fflush(fplog);
									ITK_CALL(AOM_save_without_extensions(ChdColSufTag));
									ITK_CALL(AOM_refresh(ChdColSufTag,0));


								}
								//CombCompCodeArr[l] = ChdColSufTag;

								if(FL_insert(ColSufTag,ChdColSufTag,99));
								if(AOM_save_without_extensions(ColSufTag));

								}
								// Create relation betwn color suffix and child color suffix.
							}
							}
						}
					}
				}

				// function to entry as CLRPART_ASSY as new entry in fix table as it is not available.
				int funToEntryInFixTable(char* compcodeStr,char** CompCodeSet,int CompCodeInt,char **LtstCompCode)
				{
						// query parent fix table data
					int status			=	0;
					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int		l					=	0;
					int		m					=	0;
					char* d	= "~";
					char* e  = "*";
					int     n_entry				=	1;
					int     Nflag				=	0;
					int     IntCmCode			=	0;
					char    *qry_sys_entry[1]	=	{"Name"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCount			=	0;
					tag_t   *PrntClrSuf_tag		=	NULLTAG;
					char*	Obj_name			=	NULL;
					char*	ChildCompCode		=	NULL;
					char*	compcode			=	NULL;
					int		IntCldCmp			=	0;
					char	**sChldClrSufixvalues  =	NULL;
					char	*ChldCompCode		  =	NULL;
					char	*ChldCompCodeCpy		  =	NULL;
					char	*SplcHoldr			  =	NULL;
					char	*ScatSuf		  =	NULL;
					char	*StrSufStr		  =	NULL;

					tag_t	Clr_type_tag				= NULLTAG;
					tag_t	object_create_input_tag		= NULLTAG;
					tag_t	Chd_type_tag				= NULLTAG;
					tag_t	object_create_chd_tag		= NULLTAG;
					tag_t	ColSufTag					= NULLTAG;
					tag_t	ChdColSufTag				= NULLTAG;
					tag_t   Cntl_obj_tag				=	NULLTAG;
					int     n					=	2;
					char    *qry_entry[2]		=	{"Name","Type"};
					char    **qry_values		=  (char **) MEM_alloc(10 * sizeof(char *));
					int		Count				=	0;
					tag_t   *ChildClrSuf_tag    =	NULLTAG;


					ChldCompCodeCpy= (char *) MEM_alloc (250);
					char **ChldCompCodeSet = (char **) MEM_alloc(1 * sizeof(char *));
					compcode= (char *) MEM_alloc (100);
					*LtstCompCode=(char *) MEM_alloc(250);


					strcpy(*LtstCompCode,"");

					fprintf(fplog,"\n inside funToEntryInFixTable...compcodeStr %s\n",compcodeStr); fflush(fplog);

					(QRY_find2("Color_Suffix_Query", &Cntl_obj_Qtag));
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n -- Found Query Color_Suffix_Query... \n"); fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Not Found Query Color_Suffix_Query... \n"); fflush(fplog);
					}

					strcpy(compcode,"");
					strcpy(compcode,compcodeStr);
					strcpy(compcode,"~");
					strcpy(compcode,"CLRPART_ASSY");
					compcode = replaceWord(compcodeStr, d, e);

					qry_sys_values[0] = compcode;
					//qry_sys_values[1] = StrSuf;
					(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCount, &PrntClrSuf_tag));
					fprintf(fplog," \n inside funToEntryInFixTable Parent color suffix count IntCount: [%d]\n",IntCount);  fflush(fplog);
					if(IntCount==0)
					{

						ITK_CALL(TCTYPE_find_type("T5_ColorSuffix", NULL, &Clr_type_tag));
						ITK_CALL(TCTYPE_construct_create_input(Clr_type_tag, &object_create_input_tag));

						ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",compcodeStr));
						ITK_CALL(TCTYPE_create_object(object_create_input_tag, &ColSufTag));

						if(ColSufTag)
						{
						fprintf(fplog,"\n t5CreateObject : object created."); fflush(fplog);
						ITK_CALL(AOM_save_without_extensions(ColSufTag));
						ITK_CALL(AOM_refresh(ColSufTag,0));

						ITK_CALL(AOM_refresh(ColSufTag,1));

						SplcHoldr = strtok(compcodeStr,"~");
						if(strstr(compcodeStr,"~")!=NULL)
							{
							ScatSuf = strtok(NULL,"~");
							}
							else
							{
							ScatSuf = strtok(NULL,"");
							}

						StrSufStr = funToGetPlaceHolderSuffix(ScatSuf);

						fprintf(fplog,"\n StrSufStr:: %s",StrSufStr); fflush(fplog);

						ITK_CALL(AOM_set_value_string(ColSufTag,"t5_PlaceHolder",SplcHoldr));
						ITK_CALL(AOM_set_value_string(ColSufTag,"t5_PlaceHolderSuffix",StrSufStr));

						ITK_CALL(AOM_save_without_extensions(ColSufTag));
						ITK_CALL(AOM_refresh(ColSufTag,1));

						fprintf(fplog,"\n CompCodeInt:[%d]\n",CompCodeInt); fflush(fplog);

							if(CompCodeInt>0)
							{

							fprintf(fplog,"\n CompCodeInt:[%d]\n",CompCodeInt); fflush(fplog);

							for(l=0;l<CompCodeInt;l++)
								{
								fprintf(fplog,"\n suffixInt22:[%d]\n",CompCodeInt); fflush(fplog);
								fprintf(fplog,"\n Child Color Suffix: [%s]\n",CompCodeSet[l]); fflush(fplog);

								ITK_CALL(QRY_find2("General...", &Cntl_obj_tag));
								if (Cntl_obj_tag)
								{
									fprintf(fplog,"\n -- Found Query General... \n"); fflush(fplog);
								}
								else
								{
									fprintf(fplog,"\n Not Found Query General... \n"); fflush(fplog);
								}
								fprintf(fplog,"\n CompCodeSet [%s] \n",CompCodeSet[l]); fflush(fplog);

								ChildCompCode = replaceWord(CompCodeSet[l], d, e);

								qry_values[0] = ChildCompCode;
								qry_values[1] = "Child Color Suffix" ;
								ITK_CALL(QRY_execute(Cntl_obj_tag, n, qry_entry, qry_values, &Count, &ChildClrSuf_tag));
								fprintf(fplog," \n Child Color Suffix Count:[%d] \n",Count);  fflush(fplog);
								if(Count>0)
								{
									// create relation between color suffix and child color suffix.
									fprintf(fplog,"\n create relation between color suffix and child color suffix. \n"); fflush(fplog);
									if(FL_insert(ColSufTag,ChildClrSuf_tag[0],99));
									if(AOM_save_without_extensions(ColSufTag));

								}
								else
								{
								// create child color suffix
								ITK_CALL(TCTYPE_find_type("T5_Child_Color_Suffix", NULL, &Chd_type_tag));
								ITK_CALL(TCTYPE_construct_create_input(Chd_type_tag, &object_create_chd_tag));
								ITK_CALL(AOM_set_value_string(object_create_chd_tag,"object_name",CompCodeSet[l]));
								ITK_CALL(TCTYPE_create_object(object_create_chd_tag, &ChdColSufTag));
								if(ChdColSufTag)
								{
									fprintf(fplog,"\n t5CreateObject : object created."); fflush(fplog);
									ITK_CALL(AOM_save_without_extensions(ChdColSufTag));
									ITK_CALL(AOM_refresh(ChdColSufTag,0));


								}
								//CombCompCodeArr[l] = ChdColSufTag;

								if(FL_insert(ColSufTag,ChdColSufTag,99));
								if(AOM_save_without_extensions(ColSufTag));

								}
								// Create relation betwn color suffix and child color suffix.
							}
							}
						}
					}

					return status;
				}
				int funToGetLatClrSufData(char* compcodeStr,char** CompCodeSet,int CompCodeInt,char **LtstCompCode)
				{
					// query parent fix table data

					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int		l					=	0;
					int		m,n					=	0;
					int     n_entry				=	1;
					int     Nflag				=	0;
					int     IntCmCode			=	0;
					int     YNFlag				=	0;
					int     flag_j				=	0;
					char    *qry_sys_entry[1]	=	{"Place Holder"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCount			=	0;
					tag_t   *PrntClrSuf_tag		=	NULLTAG;
					char*	Obj_name			=	NULL;
					char*	ChildCompCode		=	NULL;
					char*	compcode			=	NULL;
					int		IntCldCmp			=	0;
					char	**sChldClrSufixvalues  =	NULL;
					char	*ChldCompCode		  =	NULL;
					char	*ChldCompCodeCpy		  =	NULL;

					ChldCompCodeCpy= (char *) MEM_alloc (250);
					char **ChldCompCodeSet = (char **) MEM_alloc(1 * sizeof(char *));
					compcode= (char *) MEM_alloc (100);
					*LtstCompCode=(char *) MEM_alloc(250);


					strcpy(*LtstCompCode,"");

					fprintf(fplog,"\n inside funToGetLatClrSufData...compcodeStr %s\n",compcodeStr); fflush(fplog);

					(QRY_find2("Color_Suffix_Query", &Cntl_obj_Qtag));
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n -- Found Query Color_Suffix_Query... \n"); fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Not Found Query Color_Suffix_Query... \n"); fflush(fplog);
					}

					strcpy(compcode,"");
					strcpy(compcode,compcodeStr);
					//strcat(compcode,"*");

					qry_sys_values[0] = compcode;
					//qry_sys_values[1] = StrSuf;
					(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCount, &PrntClrSuf_tag));
					fprintf(fplog," \n  inside funToGetLatClrSufData. Parent color suffix count IntCount: [%d]\n",IntCount); fflush(fplog);
					if(IntCount>0)
					{
						for (l=0;l<IntCount;l++)
						{
							Nflag=0;
							AOM_ask_value_string(PrntClrSuf_tag[l],"object_name",&Obj_name);
							AOM_UIF_ask_values(PrntClrSuf_tag[l],"contents",&IntCldCmp,&sChldClrSufixvalues);

							fprintf(fplog," \n checking for Obj_name: [%s]\n",Obj_name); fflush(stdout); fflush(fplog);
							fprintf(fplog," \n IntCldCmp [%d] CompCodeInt [%d]\n",IntCldCmp,CompCodeInt); fflush(fplog);
							if(CompCodeInt>0)
							{
							if(IntCldCmp==CompCodeInt)// if count of comp codes and child color suffix is same.
							{
								IntCmCode=0;
								YNFlag=0;
								for(m=0;m<IntCldCmp;m++)
								{
								fprintf(fplog,"\n sChldClrSufixvalues[m]: %s\n",sChldClrSufixvalues[m]); fflush(fplog);
								//ChldCompCode = tc_strtok(sChldClrSufixvalues[m],"/");
								//printf("\n ChldCompCode: %s\n",ChldCompCode);
								if (ChldCompCodeCpy)tc_strcpy(ChldCompCodeCpy,"");
								strcat(ChldCompCodeCpy,sChldClrSufixvalues[m]);
								setFindStr(ChldCompCodeSet,IntCmCode,ChldCompCodeCpy,&YNFlag);
								if(YNFlag==0)
								{
								setAddStr(&IntCmCode,&ChldCompCodeSet,ChldCompCodeCpy);// create array of child color suffix.
								sort(ChldCompCodeSet,IntCmCode); // sort
								}
								}
								// compare set of comp code and child color suffix.

								for (n=0;n<IntCldCmp;n++)
								{
								fprintf(fplog,"\n ChldCompCodeSet: [%s] CompCodeSet: [%s]\n",ChldCompCodeSet[n],CompCodeSet[n]); fflush(fplog);

								setFindStr(ChldCompCodeSet,IntCmCode,CompCodeSet[n],&YNFlag);// if YNFlag=0,not found;if YNFlag=1, found
								fprintf(fplog,"\t\n YNFlag: [%d] \n",YNFlag);
								if(YNFlag==0)
								{
									Nflag=1;
									fprintf(fplog,"\t\n ChldCompCodeSet does not contain: [%s]\n",CompCodeSet[n]); fflush(fplog);
									break;
								}
								if(n==(IntCldCmp-1) && Nflag==0)
								{
									flag_j=1;
									fprintf(fplog,"\t\n for loop complete, arrays are equal.\n"); fflush(fplog);
									break;
								}
								}
							}
							else
							{
								Nflag=1;
								fprintf(fplog,"\t IntCldCmp!=CompCodeInt, so setting Obj_name: [%s] Nflag [%d]\n",Obj_name,Nflag); fflush(fplog);
							}

							}
							else
							{
								Nflag=3;
								fprintf(fplog,"\t CompCodeInt is zero, so setting Obj_name: [%s] Nflag [%d]\n",Obj_name,Nflag);
							}

							if(flag_j==1)
							{
								fprintf(fplog,"\n \t All the values are equal. Please proceed with parent color suffix: [%s]\n",Obj_name); fflush(fplog);
								break;
							}
						}
					}
					else
					{
						fprintf(fplog,"\t inside else funToGetLatClrSufData...IntCount is: %d,No data found so Exit function",IntCount); fflush(fplog);
						tc_strcat(*LtstCompCode,"NOTAVAIL");
					}
					if(flag_j==1)
					{
					tc_strcat(*LtstCompCode,Obj_name);
					fprintf(fplog,"\t exiting funToGetLatClrSufData...Nflag: %d ,Exit",Nflag); fflush(fplog);
					}
					else if((Nflag==1))
					{
					tc_strcat(*LtstCompCode,Obj_name);
					fprintf(fplog,"\t exiting funToGetLatClrSufData...Nflag: %d ,Exit",Nflag); fflush(fplog);
					}


					return Nflag;
				}
		int FiXTableMasterSchemeReport(char *Part_no,char *sCompCode, tag_t LatestClrSchRev ,char* rFlag)
		{
			tag_t ClrPartQryTag			= NULLTAG;
			tag_t *ClrPartTags			= NULLTAG;
			tag_t ColPartItemTag		= NULLTAG;
			tag_t *trev_list			= NULLTAG;
			tag_t tFixlatestRelzRevision= NULLTAG;
			tag_t sFixTbom_window		= NULLTAG;            
			tag_t item_tag				= null_tag, topline_tag;   
			tag_t sFixTtop_line			= NULLTAG;  
			tag_t *sFixlines			= NULLTAG;  
			tag_t childline				= NULLTAG;	
			tag_t revRule				= NULLTAG;  
			tag_t Fixbom_variant_config	= NULLTAG;    
			tag_t FixVarientRuletag		= NULLTAG;  
			tag_t sFixColData_relation_type		= NULLTAG;    
			tag_t *sFixClrSchemeData_tag		= NULLTAG;    
			tag_t *tFixClrSchemeData_tag		= NULLTAG;    
			tag_t tFixClrToClrDatarel_tag		= NULLTAG;    
			logical sFixmodB=FALSE;
			char *NCItem = NULL;
		
			char  *sitem_id  =NULL;
			char  *clrInd  =NULL;
			NCItem=(char *) MEM_alloc(25);	
				
			matchclrPart = (char *) MEM_alloc(1000 * sizeof(char));
			strcpy(matchclrPart,"");
			PoclrPart = (char *) MEM_alloc(1000 * sizeof(char));
			strcpy(PoclrPart,"");
			char **valuesClrPrt = (char **) MEM_alloc(20 * sizeof(char *));
			char *qry_entries[1] = {"ID"};
			char *sFixClrInd			=NULL;
			char *sFixClrprtCompCode	=NULL;
			char *sFixRelStatusmatch	=NULL;
			char *sFixItem_id			=NULL;
			char *sFixPrtCompCode		=NULL;          
			char *sFixClrSerial			=NULL;            
			char *sClrSufIn				=NULL; 
			char *sClrSufName			=NULL; 
			char *sFixTClrItemId		=NULL;           
			char *sFixColourID			=NULL;             
			char *sFixClrpItemId		=NULL;           
			const char *sufPart;                 
			int n_Fixlines = 0;	
			int iFixSchemeDataCnt		 =	0;
			int ClrCount=0;
			int status2 =0;
			int status =0;
			int relstatus=0;
			int ii=0 ;
			int ij=0;
			int j=0;
			int k=0;
			int in_rev=0;	
			int len =0;
			int count =0;
			int flag =0;
			 

				if(QRY_find2("ClrPart", &ClrPartQryTag));

				 if (ClrPartQryTag!=NULLTAG)
				 {
					printf("\n CL=Found Query ClrPartQryTag \n"); fflush(stdout);
				 }else {
					printf("\n\t CL=Not Found Query ClrPartQryTag, hence skipping ??? \n"); fflush(stdout);
					return 0;
				 }
				 strcpy(NCItem,"");
				 strcat(NCItem,Part_no);
				 strcat(NCItem,"*");
				 printf("\t\n ClrPart_Query ... %s\n",NCItem);fflush(stdout);
				 fprintf(fplog,"\n ClrPart_Query ...   %s \n\n",NCItem);fflush(fplog);
				 valuesClrPrt[0] = NCItem;
				if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &ClrCount, &ClrPartTags));
				printf("\t\n ClrPart_QryCount FiXTableMasterSchemeReport ------> %d \n",ClrCount);fflush(stdout);
				fprintf(fplog,"\nClrPart_QryCount FiXTableMasterSchemeReport ------>  %d \n\n",ClrCount);fflush(fplog);
				if (ClrCount > 0)
				{
				  for (ii=0;ii<ClrCount;ii++)
				  {
						sufPart =NULL;
						len =0;
						count =0;
						flag =0;
						relstatus=0;

					 if(ColPartItemTag) ColPartItemTag =NULLTAG;
					 ColPartItemTag=ClrPartTags[ii];
					 AOM_ask_value_string(ColPartItemTag,"item_id",&sitem_id);
					 
					  
					  printf("\n sitem_id: %s = %d\n\n",sitem_id,ii);
					   ITK_CALL(ITEM_list_all_revs(ColPartItemTag,&in_rev,&trev_list));
						if(in_rev > 0)
						{

							for(ij = in_rev-1 ; ij >= 0 ; ij--)
								{


									ITK_CALL(AOM_UIF_ask_value (trev_list[ij], "release_status_list", &sFixRelStatusmatch));
									if((tc_strstr(sFixRelStatusmatch,"ERC Released")!=NULL)||(tc_strstr(sFixRelStatusmatch,"T5_LcsErcRlzd")!=NULL))
									{
										relstatus=1;
										if(tFixlatestRelzRevision) tFixlatestRelzRevision =NULLTAG;
										tFixlatestRelzRevision=trev_list[ij];
										
										//fprintf(fplog,"\n sitem_id: %s \n\n",sitem_id);	 fflush(fplog);
										break;
									}

								}
						}
					if (relstatus==1)
					{
					ITK_CALL(AOM_ask_value_string(tFixlatestRelzRevision,"item_id",&sFixItem_id));
					ITK_CALL(AOM_ask_value_string(tFixlatestRelzRevision,"t5_ColourInd",&clrInd));
					
					printf("\n sFixItem_id:t5_ColourInd  %s = %s\n\n",sFixItem_id,clrInd);
					fprintf(fplog,"\n sFixItem_id:t5_ColourInd  %s = %s\n\n",sFixItem_id,clrInd);fflush(fplog);

					if (strcmp(clrInd,"C")==0)
					  {
					ITK_CALL (BOM_create_window(&sFixTbom_window));
					ITK_CALL(CFM_find("ERC release and above", &revRule));
					ITK_CALL(BOM_set_window_config_rule(sFixTbom_window,revRule));
					ITK_CALL(BOM_set_window_pack_all(sFixTbom_window, TRUE));
					ITK_CALL(BOM_set_window_top_line(sFixTbom_window ,NULLTAG,tFixlatestRelzRevision,NULLTAG, &sFixTtop_line));
					if(sFixTbom_window != NULLTAG)
					{
						printf("\n before inside sFixTbom_window-----\n");fflush(stdout);

						ITK_CALL(BOM_window_hide_unconfigured(sFixTbom_window));
						ITK_CALL(BOM_window_show_variants(sFixTbom_window));
						ITK_CALL(BOM_create_window_variant_config(sFixTbom_window,1,&Fixbom_variant_config));
						ITK_CALL(BOM_variant_config_apply (Fixbom_variant_config));
						printf("\n After inside sFixTbom_window-----\n"); fflush(stdout);	
						ITK_CALL(BOM_window_hide_variants(sFixTbom_window));
						AOM_UIF_ask_value(sFixTtop_line,"bl_item_item_id",&sFixClrpItemId);
						printf("\n Top Line id parent Id : %s \n", sFixClrpItemId);
						ITK_CALL(BOM_line_ask_child_lines(sFixTtop_line, &n_Fixlines, &sFixlines));
						printf("\n bom line count: %d \n", n_Fixlines);

						if(n_Fixlines>0)
						{
							printf("\n n_Fixlines>0");
						  for(j=0;j<n_Fixlines;j++)
							{
							 printf("\n j= %d ",j);
								 childline= sFixlines[j];
								 AOM_UIF_ask_value(childline,"bl_Design Revision_t5_PrtCatCode",&sFixClrprtCompCode);
								 AOM_UIF_ask_value(childline,"bl_Design Revision_t5_ColourInd",&sFixClrInd);
								 AOM_UIF_ask_value(childline,"bl_Design Revision_t5_ColourID",&sFixColourID);
								  AOM_UIF_ask_value(childline,"bl_item_item_id",&sFixTClrItemId);
								   printf("\n Child colour sFixClrprtCompCode   : %s\n", sFixClrprtCompCode );
								   printf("\n Child colour sFixClrInd   : %s\n", sFixClrInd );
								   printf("\n Child colour sFixColourID   : %s\n", sFixColourID );
								   printf("\n Child colour sFixTClrItemId   : %s\n", sFixTClrItemId );

									len = strlen(sFixTClrItemId);
									printf("\n Child len   : %d\n", len );
									sufPart = &sFixTClrItemId[len-2];
									printf("\n Child sufPart   : %s\n", sufPart );

								 if (tc_strcmp(sFixClrInd,"C")==0 || tc_strcmp(sFixClrInd,"Y")==0)
								 {
									
									 printf("\n colour part count  : %d \n", count);
									GRM_find_relation_type	("T5_ShmHasClrData",&sFixColData_relation_type);
									GRM_list_secondary_objects_only(LatestClrSchRev,sFixColData_relation_type,&iFixSchemeDataCnt,&tFixClrSchemeData_tag);
									printf("iFixSchemeDataCnt %d",iFixSchemeDataCnt);
									if (iFixSchemeDataCnt>0)
									{
										for (k=0;k<iFixSchemeDataCnt;k++)
										{

											(AOM_ask_value_string(tFixClrSchemeData_tag[k],"t5_PrtCatCode",&sFixPrtCompCode));
											(AOM_ask_value_string(tFixClrSchemeData_tag[k],"t5_ClSrl",&sFixClrSerial));
											sClrSufIn = tc_strtok(sFixClrSerial,";");
											sClrSufName = tc_strtok(NULL,"");
											 printf("\n Child colour sFixPrtCompCode   : %s\n", sFixPrtCompCode );
											   printf("\n Child colour sFixClrSerial   : %s\n", sFixClrSerial );
											   printf("\n Child colour sClrSufIn   : %s\n", sClrSufIn );
											   printf("\n Child colour sClrSufName   : %s\n", sClrSufName );

											//  printf("\n Comp code :%s=%s  colour serial : %s=%s  suffix : %s=%s\n", sFixPrtCompCode,sFixClrprtCompCode,sClrSufName,sFixColourID,sufPart,sClrSufIn);
											
											if (tc_strcmp(sFixPrtCompCode,sFixClrprtCompCode)==0)
											{
												fprintf(fplog,"\n Comp code sFixPrtCompCode,sFixClrprtCompCode %s=%s \n", sFixPrtCompCode,sFixClrprtCompCode);fflush(fplog);
												 count++;
												 
												if (tc_strcmp(sClrSufName,sFixColourID)==0)
												{
												fprintf(fplog,"\n Colour id sClrSufName Scheme ,sFixColourIDpart %s=%s \n", sClrSufName,sFixColourID);fflush(fplog);
													flag++;
												printf("\n Matching count .....: %d \n", flag);
												fprintf(fplog,"\n colour id  Count Matching  : %d=%d \n", count,flag);fflush(fplog);

												}

											}

										}
									}

								 }


							}
							 printf("\n Count Matching  : %d=%d \n", count,flag);
							 fprintf(fplog,"\n Count Matching  : %d=%d \n", count,flag);fflush(fplog);

					if (strcmp(rFlag,"Yes")==0)
						 {
							if (count==flag)
							{
							 printf("\n starting forPoFunction ...... : \n");
							 status2 = forPoFunction(tFixlatestRelzRevision);
							 printf("\n Ending forPoFunction ...... :%d \n",status2);
							  fprintf(fplog,"\n  Ending forPoFunction ...... :  %d \n",status2);fflush(fplog);
							 // status2=1;
								if (status2==1)
								{
								   fprintf(fplog,"\n  Break.................... :  %d \n",status2);fflush(fplog);
								   printf("\n PO Count Matching colour part & Scheme : %s \n", sFixClrpItemId);
								   strcat(PoclrPart,sFixClrpItemId);
								   strcat(PoclrPart,",");
								  
								}else
								{

								   printf("\n Count Matching colour part & Scheme : %s \n", sFixClrpItemId);
								   strcat(matchclrPart,sFixClrpItemId);
								   strcat(matchclrPart,",");
								}
							}
							 }
							 else
							{

							if (count==flag)
							{
							  printf("\n starting forPoFunction ...... : \n");
							  status2 = forPoFunction(tFixlatestRelzRevision);
							  printf("\n Ending forPoFunction ...... :%d \n",status2);
							  fprintf(fplog,"\n  Ending forPoFunction ...... :  %d \n",status2);fflush(fplog);
							 // status2=1;
							   if (status2==1)
								{
								   fprintf(fplog,"\n  Break.................... :  %d \n",status2);fflush(fplog);
								   printf("\n PO Count Matching colour part & Scheme : %s \n", sFixClrpItemId);
								   strcat(PoclrPart,sFixClrpItemId);
								   strcat(PoclrPart,",");
								  // break;
								}
								else
								{

									//  implosion logic 

									 printf("\n Count Matching colour part & Scheme : %s \n", sFixClrpItemId);
									 strcat(matchclrPart,sFixClrpItemId);
									 strcat(matchclrPart,",");


								}
							  

							  
							}
							}


						}

					}

					  printf("\n End of old part & coming  new part  :  %d\n",status2);
				  }
				  
				  }
				  else
					  {
					  printf("\n Colour Part Not found in release status  :  \n");
					  fprintf(fplog,"\n  Colour Part Not found in release status \n");fflush(fplog);
					  }
					

				  }
				if (strcmp(rFlag,"Yes")==0)
				{
				  printf("\n All Matching colour part & Scheme : %s \n", matchclrPart);
				  fprintf(fMstClrSchRpt,"\n %s = %s = %s ",sCompCode,matchclrPart,PoclrPart); fflush(fMstClrSchRpt);
				}
				
			}

			printf("\n Return status----2  :  %d\n",status2);
			fprintf(fplog,"\n  Rerun status2  ....2  %d \n",status2);fflush(fplog);

		  return status2;
		}


	 int forPoFunction(tag_t tFixlatestRelzRevision)
		{

				char* t5_PO1=NULL;
				char* t5_PO2=NULL;
				char* t5_PO3=NULL;
				char* t5_PO4=NULL;
				char* t5_PO5=NULL;
				char* t5_PO6=NULL;
				char* t5_PO7=NULL;
				char* t5_PO8=NULL;
				char* t5_PO9=NULL;
				char* t5_PO10=NULL;
				char* t5_PO11=NULL;
				char* t5_PO12=NULL;
				char* t5_PODate1=NULL;
				char* t5_PODate2=NULL;
				char* t5_PODate3=NULL;
				char* t5_PODate4=NULL;
				char* t5_PODate5=NULL;
				char* t5_PODate6=NULL;
				char* t5_PODate7=NULL;
				char* t5_PODate8=NULL;
				char* t5_PODate9=NULL;
				char* t5_PODate10=NULL;
				char* t5_PODate11=NULL;
				char* t5_PODate12=NULL;
				char* sObjNameLatestRev=NULL;
				char* sObjNameMasFormRev=NULL;
				tag_t Gen_qry_tag=NULLTAG;
				tag_t *ClrpartRev_Master_tag=NULLTAG;
				int Gen_qry_Count=0;
				char    *Gen_qry_entry[2]		=	{"Name","Type"};
				char    **Gen_qry_values		=  (char **) MEM_alloc(50 * sizeof(char *));
				char *sClItem_id=NULL;
				char *ClrItem = NULL;
				 int     qry_entry					=	2;
				 int status3 =0;
				 int status =0;
				int x=0;
				ClrItem=(char *) MEM_alloc(25);
				  strcpy(ClrItem,"");
				ITK_CALL(AOM_ask_value_string(tFixlatestRelzRevision,"item_id",&sClItem_id));
				ITK_CALL(AOM_ask_value_string(tFixlatestRelzRevision,"object_string",&sObjNameLatestRev));
			   ITK_CALL(QRY_find2("General...", &Gen_qry_tag));
			
				if (Gen_qry_tag!=NULLTAG)
				{
					fprintf(fplog,"\n -- Found Query General for Clr Part Revision Master... \n");fflush(fplog);
					
					strcat(ClrItem,sClItem_id);
					strcat(ClrItem,"*");
					fprintf(fplog,"\n Input for Clr Part Revision Master... [%s]\n",ClrItem);fflush(fplog);
					Gen_qry_values[0] = ClrItem;
					Gen_qry_values[1] = "Clr Part Revision Master" ;
					ITK_CALL(QRY_execute(Gen_qry_tag, qry_entry, Gen_qry_entry, Gen_qry_values, &Gen_qry_Count, &ClrpartRev_Master_tag));
				  MEM_free(ClrItem);
				}
				else
				{
					fprintf(fplog,"\n Not Found Query General... \n");fflush(fplog);
				}
			   printf("\n Clr Part master Revision count ....%d \n",Gen_qry_Count);
				fprintf(fplog,"\n  Clr Part master Revision count ....%d  \n",Gen_qry_Count);fflush(fplog);
				if (Gen_qry_Count>0)
				{
					for (x=0;x<Gen_qry_Count;x++ )
					{
					ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"object_name",&sObjNameMasFormRev));
					  printf("\n Clr PartObject Name  ....%s=%s \n",sObjNameMasFormRev,sObjNameLatestRev);
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO1",&t5_PO1));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO2",&t5_PO2));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO3",&t5_PO3));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO4",&t5_PO4));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO5",&t5_PO5));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO6",&t5_PO6));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO7",&t5_PO7));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO8",&t5_PO8));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO9",&t5_PO9));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO10",&t5_PO10));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO11",&t5_PO11));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PO12",&t5_PO12));
					 if (((t5_PO1 !=NULL) && (strcmp(t5_PO1,"") !=0)) || (t5_PO2 !=NULL && strcmp(t5_PO2,"") !=0) ||(t5_PO3 !=NULL && strcmp(t5_PO3,"") !=0) || (t5_PO4 != NULL && strcmp(t5_PO4,"") !=0) || (t5_PO5 != NULL && strcmp(t5_PO5,"") !=0) || (t5_PO6 !=NULL && strcmp(t5_PO6,"") !=0)|| (t5_PO7 !=NULL && strcmp(t5_PO7,"") !=0) ||(t5_PO8 !=NULL && strcmp(t5_PO8,"") !=0) || (t5_PO9 !=NULL && strcmp(t5_PO9,"") !=0) || (t5_PO10 !=NULL && strcmp(t5_PO10,"") !=0) || (t5_PO11 !=NULL && strcmp(t5_PO11,"") !=0) || (t5_PO12 !=NULL && strcmp(t5_PO12,"") !=0) )
					 {
							 
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate1",&t5_PODate1));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate2",&t5_PODate2));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate3",&t5_PODate3));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate4",&t5_PODate4));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate5",&t5_PODate5));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate6",&t5_PODate6));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate7",&t5_PODate7));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate8",&t5_PODate8));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate9",&t5_PODate9));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate10",&t5_PODate10));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate11",&t5_PODate11));
						ITK_CALL(AOM_UIF_ask_value(ClrpartRev_Master_tag[x],"t5_PODate12",&t5_PODate12));
							 
							 printf("\n Clr Part master Revision PO  Found .... \n");
							 fprintf(fplog,"\n  Clr Part master Revision PO  Found ....  \n");fflush(fplog);	  
							 printf("\n t5_PO1 : %s , t5_PO2: %s , t5_PO3 : %s , t5_PO4 : %s , t5_PO5 : %s , t5_PO6 : %s , t5_PO7 : %s t5_PO8 : %s  , t5_PO9: %s , t5_PO10 : %s , t5_PO11 : %s  , t5_PO12 : %s\n",t5_PO1,t5_PO2,t5_PO3,t5_PO4,t5_PO5,t5_PO6,t5_PO7,t5_PO8,t5_PO9,t5_PO10,t5_PO11,t5_PO12);
							 fprintf(fplog,"\n t5_PO1 : %s , t5_PO2: %s , t5_PO3 : %s , t5_PO4 : %s , t5_PO5 : %s , t5_PO6 : %s , t5_PO7 : %s t5_PO8 : %s  , t5_PO9: %s , t5_PO10 : %s , t5_PO11 : %s  , t5_PO12 : %s\n",t5_PO1,t5_PO2,t5_PO3,t5_PO4,t5_PO5,t5_PO6,t5_PO7,t5_PO8,t5_PO9,t5_PO10,t5_PO11,t5_PO12);fflush(fplog);
							 status3 = 1;
							 break ;
				   
						}
						else
						   {
			
							 printf("\n Clr Part master Revision PO not Found .... \n");
							 fprintf(fplog,"\n  Clr Part master Revision PO Not Found ....  \n");fflush(fplog);
			
						   }
						   printf("\n Return status----1  :  %d\n",status3);
						  fprintf(fplog,"\n  Rerun status2  ....1  %d \n",status3);fflush(fplog);
					   
							   
							   
					}
				}

		  return status3;
		}
		int FunExpPartToGetChildCompCodes(char *sClrDataPartNumber,char* PrtCompCodeStr,tag_t ClrScheme_tag,int IntRemClr)
		{
					int status =0;
					//tag_t* LatestRevision_tag = NULLTAG;
					tag_t LatestRevision_tag = NULLTAG;

					char* c = ",";
					char* d	= ";";
					char* e  = "/";
					char* f  = "-";
					char* h  = "*";
					char* s  = "~";

					int numBVRs =0;
					int j=0;
					int p=0;
					int suffixCnt=0;
					int suffixCnt1=0;
					tag_t* bvr_tags = NULLTAG;
					tag_t bom_view = NULLTAG;
					tag_t bom_window=NULLTAG;
					tag_t rule, item_tag = null_tag, topline_tag;
					tag_t top_line=NULLTAG;
					int n_lines,n_lines1 = 0;
					tag_t *lines = NULLTAG;
					tag_t bom_variant_config=NULLTAG;
					tag_t VarientRuletag = NULLTAG;
					logical modB=FALSE;
					char *sChildCompCode =NULL;
					char *sClrInd		  =NULL;
					char *ItemId		  =NULL;
					char *sitem_id		  =NULL;
					int flag =0,i=0;
					tag_t   ColData_relation_type=	NULLTAG;
					char* sPrntCompCode=NULL;
					char **CompCodeData = (char **) MEM_alloc(1 * sizeof(char *));
					char **AllCompCodes = (char **) MEM_alloc(1 * sizeof(char *));
					char *RplccombCompCodeClrID =NULL;
					char *combCompCodeClrID =NULL;
					char *combCompCode =NULL;
					char *sParentCompCode =NULL;
					char *sCombCompCodeClrID =NULL;

					int 	num_to_sort			=	1;
					int 	r					=	0;
					char	*keys[1]			=	{"creation_date"};
					int		orders				=	1;

					char	*sParentClrSufName	=	NULL;
					sParentClrSufName=(char *) MEM_alloc(100);
					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int     n_entry				=	1;
					char    *qry_sys_entry[1]	=	{"Place Holder"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCount			=	0;
					tag_t   *PrntClrSuf_tag		=	NULLTAG;
					int		num_values			=	0;
					char	**sChldClrSufixvalues	=	NULL;
					int		cnt					=	0;
					int		YNFlag				=	0;
					int		YNFlag1				=	0;
					int		ccaincca			=	0;
					char	*ClrSchmDt			=	NULL;

					//int		i					 =	0;
					int		ICnt				 =	0;
					int		SchemeDataCnt		 =	0;
					tag_t	*ClrSchemeData_tag	 =	NULLTAG;
					tag_t   ClrToClrDatarel_tag	 =	NULLTAG;
					char	*sPrtCompCode		 = NULL;
					char	*sClrSerial			 = NULL;
					char	*sInternalScheme	 = NULL;
					char	*sClrSufIn			 = NULL;
					char	*sClrSufName		 = NULL;



					combCompCodeClrID= (char *) MEM_alloc (250);
					combCompCode= (char *) MEM_alloc (250);

					char	**sListOfChildSuffix = (char **) MEM_alloc(500 * sizeof(char *));
					ClrSchmDt= (char *) MEM_alloc (100);
					sCombCompCodeClrID= (char *) MEM_alloc (100);
					char **ClrSchemDataList = (char **) MEM_alloc(500 * sizeof(char *));

					printf("\n Inside FunExpPartToGetChildCompCodes \n");
					fprintf(fplog," Inside FunExpPartToGetChildCompCodes");fflush(fplog);

					ITK_CALL(GRM_find_relation_type	("T5_ShmHasClrData",&ColData_relation_type));

					ITK_CALL(AOM_load(ClrScheme_tag));


					ITK_CALL(POM_refresh_instances(1,&ClrScheme_tag,class_to_load_as,lock_type));
					//(POM_load_instances(1,&ClrScheme_tag,class_to_load_as,lock_type));

					// new logic

					// BOM Comp Code Logic

					LatestRevision_tag = FunToReturnLatestRelzRevision(sClrDataPartNumber);

					ITK_CALL(AOM_ask_value_string(LatestRevision_tag,"item_id",&sitem_id));

					fprintf(fplog,"Design Revision ID sitem_id: %s",sitem_id);fflush(fplog);

					ITK_CALL(ITEM_rev_list_bom_view_revs(LatestRevision_tag, &numBVRs, &bvr_tags));

					if ( numBVRs == 0 )
					{
						fprintf(fplog, " Error : No BOM View Revision Exists \n\n " );fflush(fplog);
						fprintf(fplog, " Exiting the program \n " );fflush(fplog);
						//exit(0);
						//continue1;
						status=1;
						return status;

					}

					ITK_CALL(PS_ask_bom_view_of_bvr(bvr_tags[0],&bom_view));
					ITK_CALL ( BOM_create_window(&bom_window));
					ITK_CALL(CFM_find("ERC release and above", &rule));
					ITK_CALL(BOM_set_window_config_rule(bom_window, rule));
					ITK_CALL(BOM_set_window_pack_all(bom_window, TRUE));
					ITK_CALL(BOM_set_window_top_line(bom_window , NULLTAG, LatestRevision_tag, NULLTAG, &top_line));
					fprintf(fplog," BOM_set_window_top_line..\n");fflush(fplog);

					if(bom_window != NULLTAG)
					{
						fprintf(fplog,"\n before inside bom_window-----\n");fflush(fplog);

						ITK_CALL(BOM_window_hide_unconfigured(bom_window));
						ITK_CALL(BOM_window_show_variants(bom_window));
						ITK_CALL(BOM_create_window_variant_config(bom_window,1,&bom_variant_config));
						ITK_CALL(BOM_variant_config_apply (bom_variant_config));

						fprintf(fplog,"\n After inside bom_window-----\n"); fflush(fplog);
						//ITK_CALL(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag));
						fprintf(fplog,"\n After BOM_window_apply_variant_configuration-----\n");fflush(fplog);
						ITK_CALL(BOM_window_hide_variants(bom_window));
						ITK_CALL(BOM_window_ask_is_modified(bom_window,&modB));
						if(modB)
						{
							fprintf(fplog, "\n modified bom window:..\n");fflush(fplog);
						}
						else
						{
							fprintf(fplog, "\n not modfiifed ..\n");fflush(fplog);
						}

						ITK_CALL(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
						printf("\n bom line count: %d \n", n_lines1);
						fprintf(fplog,"\n bom line count: %d \n", n_lines1);fflush(fplog);

						// code to check CCA under CCA

						if(n_lines1>0)
						{
						for(p=0;p<n_lines1;p++)
						{
							(AOM_UIF_ask_value(lines[p],"bl_Design Revision_t5_PrtCatCode",&sParentCompCode));//ARM_REST
							(AOM_UIF_ask_value(lines[p],"bl_Design Revision_t5_ColourInd",&sClrInd));
							(AOM_UIF_ask_value(lines[p],"bl_item_item_id",&ItemId));

							printf("\n bl_Design Revision_t5_PrtCatCode : %s \n", sParentCompCode);
							printf("\n bl_Design Revision_t5_ColourInd : %s \n", sClrInd);
							printf("\n bl_item_item_id : %s \n", ItemId);

							if((tc_strlen(sParentCompCode)>0) && (tc_strcmp(sClrInd,"Y")==0))
							{
								if(tc_strstr(sParentCompCode,"CCA_")!=NULL)
								{


									(GRM_list_secondary_objects_only(ClrScheme_tag,ColData_relation_type,&SchemeDataCnt,&ClrSchemeData_tag));
									////ASHISH
									//fprintf(fplog,"\n Color scheme data count of given color scheme SchemeDataCnt: %d\n",SchemeDataCnt);fflush(fplog);

									if(SchemeDataCnt>0)
									{
									for (i=0;i<SchemeDataCnt;i++)
									{
									(AOM_ask_value_string(ClrSchemeData_tag[i],"t5_PrtCatCode",&sPrtCompCode));
									(AOM_ask_value_string(ClrSchemeData_tag[i],"t5_ClSrl",&sClrSerial));

									// printf("\n bl_item_item_id=%s,bl_Design Revision_t5_PrtCatCode = %s , t5_PrtCatCode= %s ,  t5_ClSrl=%s \n",ItemId,sParentCompCode,sPrtCompCode,sClrSerial);

									 //fprintf(fplog,"\n bl_item_item_id=%s,bl_Design Revision_t5_PrtCatCode = %s , t5_PrtCatCode= %s ,  t5_ClSrl=%s \n",ItemId,sParentCompCode,sPrtCompCode,sClrSerial);fflush(fplog);
									if((tc_strcmp(sParentCompCode,sPrtCompCode)==0) && (tc_strstr(sClrSerial,"##")!=NULL))
									{

										fprintf(fplog,"\n bl_item_item_id=%s,bl_Design Revision_t5_PrtCatCode = %s , t5_PrtCatCode= %s ,  t5_ClSrl=%s \n",ItemId,sParentCompCode,sPrtCompCode,sClrSerial);fflush(fplog);
										printf("\n bl_item_item_id=%s,bl_Design Revision_t5_PrtCatCode = %s , t5_PrtCatCode= %s ,  t5_ClSrl=%s \n",ItemId,sParentCompCode,sPrtCompCode,sClrSerial);
										ccaincca=1;
										break;
									}
									//if((tc_strcmp(sParentCompCode,sPrtCompCode)==0) && (tc_strstr(sClrSerial,"##")==NULL))
									//{
									 // fprintf(fReport,"\n %s,%s,%s,%s,%s",sPrtCompCode,"","","",sClrSerial); fflush(fReport);

									//}
									}
									}
								}
							}
						}
						if(ccaincca==1)
						{
						status=2;
						printf("\n CCA contains CCA ccaincca :  %d \n",ccaincca);
						fprintf(fplog,"\n CCA contains CCA ccaincca %d \n",ccaincca);fflush(fplog);
						return status;
						}
						else
						{
							ccaincca=0;
							fprintf(fplog,"\n CCA not contains CCA ccaincca %d \n",ccaincca);fflush(fplog);
						}
						}
						if(ccaincca==0)   // remove  by Gajanan for testing ccaincca==1
						{
						if(n_lines1>0)
						{
						for(j=0;j<n_lines1;j++)
						{
							(AOM_UIF_ask_value(lines[j],"bl_Design Revision_t5_PrtCatCode",&sParentCompCode));//ARM_REST
							(AOM_UIF_ask_value(lines[j],"bl_Design Revision_t5_ColourInd",&sClrInd));

							 //printf("sParentCompCode: %s^%s\n",sParentCompCode,sColorID);

							//printf( "\n  find out comp codes whose and color indicator Y in BOM Line \n");
							if((tc_strlen(sParentCompCode)>0) && (tc_strcmp(sClrInd,"Y")==0))
							{
							ITK_CALL(AOM_load(ClrScheme_tag));

							ITK_CALL(POM_refresh_instances(1,&ClrScheme_tag,class_to_load_as,lock_type));
							//(POM_load_instances(1,&ClrScheme_tag,class_to_load_as,lock_type));

							(GRM_list_secondary_objects_only(ClrScheme_tag,ColData_relation_type,&SchemeDataCnt,&ClrSchemeData_tag));
					////ASHISH
							//fprintf(fplog,"\n Color scheme data count of given color scheme SchemeDataCnt: %d\n",SchemeDataCnt);fflush(fplog);



							if(SchemeDataCnt>0)
							{
							for (i=0;i<SchemeDataCnt;i++)
							{
								(AOM_ask_value_string(ClrSchemeData_tag[i],"t5_PrtCatCode",&sPrtCompCode));
								(AOM_ask_value_string(ClrSchemeData_tag[i],"t5_ClSrl",&sClrSerial));

								//printf("\n sParentCompCode:[%s] sPrtCompCode:[%s]\n",sParentCompCode,sPrtCompCode);

								if(tc_strcmp(sParentCompCode,sPrtCompCode)==0)
								{
									fprintf(fplog,"\n sParentCompCode:[%s] sPrtCompCode:[%s]\n",sParentCompCode,sPrtCompCode);fflush(fplog);
									fprintf(fplog,"\n sClrSerial:[%s]\n",sClrSerial);fflush(fplog);


									// find if string array contains CCA as child of color suffix

									if((tc_strstr(sParentCompCode,"CCA_")!=NULL) && (tc_strstr(sClrSerial,"##")!=NULL))
									{
									fprintf(fplog,"\n : Parent comp code contains CCA child comp codes, return to function and process further. \n"); fflush(fplog);
				//					if (IntRemClr>0)
				//					{
				//						printf("\n try once \n");
				//					}
				//					else
				//					{

									status=2;
									return status; // uncommented by gajanan for testing 08/05/23
									//}
									}
									// query parent fix table data

									sClrSufIn = tc_strtok(sClrSerial,";");
									sClrSufName = tc_strtok(NULL,"");
									fprintf(fplog,"\n sClrSufName: %s \n", sClrSufName);fflush(fplog);
									if (combCompCodeClrID)tc_strcpy(combCompCodeClrID,"");
									tc_strcat(combCompCodeClrID,sPrtCompCode);
									tc_strcat(combCompCodeClrID,"/");
									tc_strcat(combCompCodeClrID,sClrSufName);
				//					CompCodeData[suffixCnt]=(char *) MEM_alloc(tc_strlen(combCompCodeClrID)* sizeof(char ));
				//					tc_strcpy(CompCodeData[suffixCnt],combCompCodeClrID);
				//					//printf("\n CompCodeData: compcode and colsrl concat after comparing with clrscheme data: [%s]\n",CompCodeData[suffixCnt]);
				//					printf("\t [%s]\n",CompCodeData[suffixCnt]);
								//	suffixCnt = suffixCnt+1;
									if (combCompCode)tc_strcpy(combCompCode,"");
									tc_strcat(combCompCode,sPrtCompCode);

									setFindStr(CompCodeData,suffixCnt,combCompCodeClrID,&YNFlag);
									if(YNFlag==0)
									{
									setAddStr(&suffixCnt,&CompCodeData,combCompCodeClrID);
									sort(CompCodeData,suffixCnt);
									}
									setFindStr(AllCompCodes,suffixCnt1,combCompCode,&YNFlag1);
									if(YNFlag1==0)
									{
									setAddStr(&suffixCnt1,&AllCompCodes,combCompCode);
									sort(AllCompCodes,suffixCnt1);
									}

								}
							}
							}
							}
						}

					}
					}


					}
					fprintf(fplog,"\n count after comparing bomline comp codes and clrschemdata comp codes suffixCnt [%d]\n",suffixCnt); fflush(fplog);
					int l=0;
					int flag_i=0;
					int Eqflag=0;
					(QRY_find2("Color_Suffix_Query", &Cntl_obj_Qtag));
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n -- Found Query General... \n"); fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Not Found Query General... \n"); fflush(fplog);
					}

					qry_sys_values[0] = PrtCompCodeStr;
					QRY_execute_with_sort(Cntl_obj_Qtag,n_entry,qry_sys_entry,qry_sys_values,num_to_sort,keys,&orders,&IntCount,&PrntClrSuf_tag);
					fprintf(fplog," \n QRY_execute_with_sort Parent color suffix count IntCount: [%d]\n",IntCount); fflush(fplog);
					int	ListCount =0;

					if(IntCount==0)
					{
						fprintf(fplog," \n ERROR: ENTRY NOT FOUND IN FIX TABLE, ADD LOGIC TO CREATE FIX TABLE ENTRY."); fflush(fplog);
						FunToEntryDataInFIXTable(PrtCompCodeStr,CompCodeData,AllCompCodes,&suffixCnt);

					}

					QRY_execute_with_sort(Cntl_obj_Qtag,n_entry,qry_sys_entry,qry_sys_values,num_to_sort,keys,&orders,&IntCount,&PrntClrSuf_tag);
					fprintf(fplog," \n 1111--Parent color suffix count IntCount: [%d]\n",IntCount); fflush(fplog);

					if(IntCount>0)
					{
						fprintf(fplog," \n MORE THAN 0 ENTRY FOUND IN FIX TABLE."); fflush(fplog);
						int cnt11=0;
						int cnt2=0;
						int IntClr=0;
						char **CldClrSufSet = (char **) MEM_alloc(1 * sizeof(char *));

						for(i=0;i<IntCount;i++)
						{
							(AOM_UIF_ask_value(PrntClrSuf_tag[i],"object_name",&sParentClrSufName));
							fprintf(fplog," \n Parent color suffix found: [%s] \n",sParentClrSufName); fflush(fplog);

							(AOM_UIF_ask_values(PrntClrSuf_tag[i],"contents",&num_values,&sChldClrSufixvalues));
							fprintf(fplog," \n child color suffix count [%d] suffixCnt [%d] for Parent color suffix: [%s] \n",num_values,suffixCnt,sParentClrSufName); fflush(fplog);

							if(num_values==suffixCnt)
							{
							ListCount=0;
							flag_i=0;
							//fprintf(fplog," \n number of child suffix and comp codes in bomline are same \n");  fflush(fplog);
							for (cnt=0;cnt<num_values;cnt++)
							{
								//printf("\n count is[%d]:sChldClrSufixvalues[%s]\n",cnt,sChldClrSufixvalues[cnt]);fflush(stdout);
								sListOfChildSuffix[cnt]=(char *) MEM_alloc(tc_strlen(sChldClrSufixvalues[cnt])* sizeof(char ));
								tc_strcpy(sListOfChildSuffix[cnt],"");
								tc_strcpy(sListOfChildSuffix[cnt],sChldClrSufixvalues[cnt]);
								fprintf(fplog,"\t sListOfChildSuffix[cnt]>>>> [%s]\n",sListOfChildSuffix[cnt]); fflush(fplog);
								ListCount = ListCount +1;
								// Ashish
								//setAddStr1(&IntClr,&CldClrSufSet,sListOfChildSuffix[cnt]);// create array of child color suffix.

							}
							sort(sListOfChildSuffix,ListCount);// sort

							for (cnt11=0;cnt11<cnt;cnt11++)
							{
								fprintf(fplog,"\t\n selectionSort >>> [%s]\n",sListOfChildSuffix[cnt11]); fflush(fplog);
							}
							for (cnt2=0;cnt2<cnt;cnt2++)
							{
								fprintf(fplog,"\t\n CompCodeData[cnt2] >>> [%s]",CompCodeData[cnt2]); fflush(fplog);
							}

							for (l=0;l<suffixCnt;l++)
							{
								Eqflag=0;
								fprintf(fplog,"\n CompCodeData: [%s] sListOfChildSuffix: [%s]\n",CompCodeData[l],sListOfChildSuffix[l]); fflush(fplog);

								//fprintf(fplog,"\t\n\n Finding the string in array using setFindStr \n\n"); fflush(fplog);

								setFindStr(sListOfChildSuffix,ListCount,CompCodeData[l],&YNFlag);// if YNFlag=0,not found;if YNFlag=1, found
								fprintf(fplog,"\t\n YNFlag: [%d]\n",YNFlag); fflush(fplog);
								if(YNFlag==0)//not found
								{
									flag_i=1;
									fprintf(fplog,"\t\n flag_i: [%d], break the loop as data not found.\n",flag_i); fflush(fplog);
									break;//data not found, then break.
								}
								fprintf(fplog,"\t\n flag_i: [%d] \n",flag_i); fflush(fplog);
								if((l==(suffixCnt-1)) && (flag_i==0))//for loop complete and flag_i=0, data is same.
								{
									Eqflag=1;
									fprintf(fplog,"\t\n flag_i: [%d] and for loop completed. setting Eqflag:[%d], as data is same. \n",flag_i,Eqflag); fflush(fplog);
									break;
								}
							}
							}
							else
							{
								//fprintf(fplog," \n number of child suffix and comp codes in bomline are not same \n"); fflush(fplog);
								flag_i=3;
							}
							fprintf(fplog," \n nnnnnnnflag_i: %d Eqflag : %d\n",flag_i,Eqflag); fflush(stdout);

							if(Eqflag==1)
							{
								fprintf(fplog,"\n \t All the values are equal. Please proceed with parent color suffix: [%s]\n",sParentClrSufName); fflush(fplog);
								break;
							}
						}
					}

					//check here part number is present on part number field of color suffix in fix table.

					//sParentClrSufName [CCA_REAR_DOOR_TRIM_LH~CLRPRT_ASY30]
					fprintf(fplog,"\t sParentClrSufName [%s]\n",sParentClrSufName); fflush(fplog);

					char* svalidClrSuf = NULL;
					char* qry_inp_str = NULL;
					int intvalid =0;
					tag_t *valid_col_suf_tag = NULLTAG;
					char *sOldsuffixIDs = NULL;
					char* sOldClrPartIDs = NULL;
					char* spartnumber =NULL;
					char* allPartnumber =NULL;
					int isAvailInUA = 0;
					char* org_clr_id = NULL;
					char* org_compcdNew = NULL;
					char* sColourIdsuffix = NULL;
					char    **valid_value    =  (char **) MEM_alloc(10 * sizeof(char *));
					char*  sOldSuf =NULL;
					char*  clrpart =NULL;
					char*  clrpart1 =NULL;
					char*  clrSufpart =NULL;
					char*  sNewSuf =NULL;
					char*  org_compcode =NULL;

					svalidClrSuf=(char *) MEM_alloc(100);
					spartnumber=(char *) MEM_alloc(100);
					org_compcdNew=(char *) MEM_alloc(150);
					sColourIdsuffix=(char *) MEM_alloc(2000);
					allPartnumber=(char *) MEM_alloc(2000);
					tc_strcpy(allPartnumber,"");
					char *sclrPart =NULL;
					char *mClrPart = NULL;
					mClrPart = (char *) MEM_alloc(1000 * sizeof(char));

					//start implosion declaration here

							//char		*ImplosionFile			= (char *) MEM_alloc(128);
							//char		*ImplosionFileDatew			= (char *) MEM_alloc(128);
							char		*partNumber				= NULL;
							char		*revisionRule 			= NULL;
							char		*entries[1]				= {"ID"};
							char		*Part_Number			= NULL;
							char		*RevSeq					= NULL;
							char		*ReleaseStatus			= NULL;
							char		*PartType				= NULL;
							 
							int			value_entries			= 1;
							int			n_items					= 0;
							int			iij						= 0;
							tag_t		ITEM_tag                = NULLTAG;
							tag_t 		*rev_listt 	            = NULLTAG;
							int			count1					= 0;
							char*     rev_id					= NULL;
							char*     rev_num					= NULL;
							char*     rell_status				= NULL;
							char		**values				= NULL;
							tag_t		*items					= NULLTAG;
							tag_t		Query_Tag				= NULLTAG;
							tag_t		PartTag					= NULLTAG;
							int			n_parents				= 0;
							int			*levels					= 0;
							tag_t		*parents				= NULLTAG;
							tag_t		parentMaster			= NULLTAG;
							tag_t		ParentRevTag			= NULLTAG;
							int			parCtr					= 0;
							char		*ParentItemID			= NULL;
							char		*obj_type				= NULL;
							char		*partType				= NULL;
							char        *sClrPart=NULL;

							 lYears=0; 
							 lMonth=0; 
							 lDate= 0;
							 char* maxDateClrpart= NULL;
							 char* sClrpartDate= NULL;
							  int ik=0;
							 ia =0;
							tagSET = (tag_t *) MEM_alloc(30000 * sizeof(tag_t));
							sFinalDataSet = (char **) MEM_alloc(1 * sizeof(char *));

							maxDateClrpart = (char *) MEM_alloc(1000 * sizeof(char));
							strcpy(maxDateClrpart,"");
							sClrpartDate=  (char *) MEM_alloc(1000 * sizeof(char));
							strcpy(sClrpartDate,"");
							
							allUniqueVC = (char *) MEM_alloc(500000 * sizeof(char));
							
							int lflag=1;
							char* iFile =NULL;
							values = (char **) MEM_alloc(value_entries * sizeof(char *));

							//tc_strcpy(ImplosionFile,"/user/uaprodtrl/Gajanan/ImplosionReport/");
							//tc_strcat(ImplosionFile,partNumber);
							//tc_strcat(ImplosionFile,"ImplosionReport.csv");

							//tc_strcpy(ImplosionFileDatew,"/user/uaprodtrl/Gajanan/ImplosionReport/");
							//tc_strcat(ImplosionFile,partNumber);
							//tc_strcat(ImplosionFileDatew,"latestDateClrPartReport.csv");

							//ImplosionReport=fopen(ImplosionFile,"w");
							//ImplosionReportDatew=fopen(ImplosionFileDatew,"w");

							//if (ImplosionReport == NULL)
							//{
							//	printf("ERROR:ImplosionReport Cannot open File\n"); fflush(stdout);
							//	return -1;
							//}
							//else
							//{
							//	printf("ImplosionReport File opened successfully.\n"); fflush(stdout);
							//}
			
							//fprintf(ImplosionReport,"Part Number, VEHICLE, DRStatus, GM DML Name , DML Rlz Type, DML Rlz Date\n"); fflush(ImplosionReport);

							ITK_CALL(QRY_find2("ClrPart", &Query_Tag));
							if (Query_Tag!=NULLTAG)
							{
								printf("Found Query Design Revision... \n"); fflush(stdout);
							}
							else
							{
								printf("Not Found Query Design Revision... \n"); fflush(stdout);
							}
				 //End implosion declaration here

					tc_strcpy(svalidClrSuf,"");
					tc_strcat(svalidClrSuf,sParentClrSufName);

					fprintf(fplog,"\t svalidClrSuf [%s]\n",svalidClrSuf); fflush(fplog);


					qry_inp_str = replaceWord(svalidClrSuf, s, h);
					fprintf(fplog,"\t qry_inp_str [%s]\n",qry_inp_str); fflush(fplog);
					char    *valid_entry[1]	=	{"Name"};
					valid_value[0] = qry_inp_str;

					QRY_execute_with_sort(Cntl_obj_Qtag,n_entry,valid_entry,valid_value,num_to_sort,keys,&orders,&intvalid,&valid_col_suf_tag);

					fprintf(fplog,"\t intvalid [%d]\n",intvalid); fflush(fplog);

					if(intvalid>0)
					{
						ITK_CALL(AOM_UIF_ask_value(valid_col_suf_tag[0],"t5_colourid",&sOldsuffixIDs));
						fprintf(fplog,"\n \t old colour suffix [%s]\n",sOldsuffixIDs); fflush(fplog);

						 ITK_CALL(AOM_UIF_ask_value(valid_col_suf_tag[0],"t5_PlaceHolderSuffix",&sNewSuf));
						 fprintf(fplog,"\n \t new colour suffix [%s]\n",sNewSuf); fflush(fplog);

						ITK_CALL(AOM_UIF_ask_value(valid_col_suf_tag[0],"t5_partnumber",&sOldClrPartIDs));
						fprintf(fplog,"\n\t legacy part number list  [%s]\n",sOldClrPartIDs); fflush(fplog);
						printf("\n\t legacy part number list  [%s]\n",sOldClrPartIDs);fflush(fplog);
						printf("\n\t Base clr partNumber sClrDataPartNumber  [%s]\n",sClrDataPartNumber);fflush(fplog);
						tc_strcpy(sColourIdsuffix,"");
						tc_strcat(sColourIdsuffix,sOldClrPartIDs);
						//fprintf(fplog,"\n\t list ofcolour sufix [%d], [%s]\n",tc_strlen(sOldsuffixIDs),sColourIdsuffix); fflush(fplog);


			   //if (isAvailInUA==0)
			  // {  
					fprintf(fplog,"\n\t Colour part Not avaiablebe in fix table get all colour part [%s]\n",sClrDataPartNumber); fflush(fplog);
					 FiXTableMasterSchemeReport(sClrDataPartNumber,"",LatestRev,"NO");
					fprintf(fplog,"\tPO all matching colour part   %s , %d\n",PoclrPart,strlen(PoclrPart)); fflush(fplog);
					if (PoclrPart!=NULL && strcmp(PoclrPart,"")!=0 && strlen(PoclrPart)>0)
					{   
						   if (strlen(PoclrPart)>17)
						   {					   
							 sClrPart = strtok(PoclrPart,",");
							   while(sClrPart!=NULL)
								{
								  fprintf(fplog,"\n Colour part from fix Table ..... %s ",sClrPart);fflush(fplog);
								   printf("\n Colour part from fix Table ..... %s ",sClrPart);fflush(fplog);
								   char *ItemId	=NULL;    
									 if (Query_Tag)
										{
											values[0] = (char *)MEM_alloc(strlen(sClrPart) + 1);
											tc_strcpy(values[0],sClrPart);

											ITK_CALL(QRY_execute(Query_Tag, value_entries, entries, values, &n_items, &items));

											printf("n_items : [%d]\n",n_items);
											
											printf("Query Executed\n");fflush(stdout);

											if ( n_items > 0 )
											{
												ITEM_tag = items[0];
												tagSET[ia]=ITEM_tag;
												ITK_CALL(AOM_ask_value_string(tagSET[ia], "item_id", &ItemId));
												setAddStr(&ia,&sFinalDataSet,ItemId);
											}
										}
		
									sClrPart=strtok(NULL,","); 
								}
								printf("Po is colour part cnt for Imposion process ia: %d\n",ia);fflush(stdout);
								fprintf(fplog,"\n Po is colour part cnt for Imposion process ia: %d ",ia);fflush(fplog);
								if (ia>0)
								  {
									 for (ik=0;ik<ia ;ik++ )				
									  {
										   char *sClrItemId=NULL;
										   ITEM_tag =tagSET[ik];
										   if(AOM_UIF_ask_value(ITEM_tag,"item_id", &sClrItemId)!=ITK_ok)   PrintErrorStack();

												fprintf(fplog,"\n PO Getting single  Colour part from fix Table ..... %s ",sClrItemId);fflush(fplog);
												printf("\n PO Getting single Colour part from fix Table ..... %s ",sClrItemId);fflush(fplog);
												Part_Number=NULL;
												oYears=0;
												oMonth=0;
												oDate=0;
												vcCnt=0;
												topLevelVC = (char *) MEM_alloc(1000 * sizeof(char));
												strcpy(topLevelVC,"");
												strcpy(allUniqueVC,"");
															
												if(ITEM_list_all_revs(ITEM_tag, &count1, &rev_listt)!=ITK_ok)   PrintErrorStack();
												if(count1 > 0)
													{
													  iij=0;
														for(iij=count1-1;iij>=0;iij--)
														  {
																printf("\n Total rev rev_listt: %d.", count1);fflush(stdout);
																PartTag = rev_listt[iij];

																if(AOM_UIF_ask_value(PartTag,"item_id", &rev_num)!=ITK_ok)   PrintErrorStack();
																if(AOM_UIF_ask_value(PartTag,"item_revision_id", &rev_id)!=ITK_ok)   PrintErrorStack();
																if (AOM_UIF_ask_value(PartTag,"release_status_list", &rell_status)!=ITK_ok)   PrintErrorStack();

																printf("\n rev_id:%s and rell_status:%s", rev_id,rell_status);fflush(stdout);
																if(tc_strstr(rell_status, "ERC Released") !=NULL)
																{
																	printf("\n for %s %s",rev_num,rev_id);fflush(stdout);
																	break ;
																}
															}
													}
															
													ITK_CALL(AOM_ask_value_string(PartTag,"current_id",&Part_Number));
													printf("Part Number:%s\n",Part_Number);fflush(stdout);
													
													ITK_CALL(AOM_ask_value_string(PartTag,"current_revision_id",&RevSeq));
													printf("Rev Seq:%s\n",RevSeq);fflush(stdout);
													
													ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&ReleaseStatus));
													printf("Release Status:%s\n",ReleaseStatus);fflush(stdout);

													ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_PartType",&PartType));
													printf("Part Type:%s\n",PartType);fflush(stdout);

													if((tc_strcmp(partType,"D")==0) || (tc_strcmp(partType,"IFD")==0))
													{
														printf("We are not generating this report as %s part number is part type %s\n",Part_Number,PartType);fflush(stdout);
													}
													else
													{
														fprintf(fplog,"\n\t PO start  GetInfo in Main:  [%s]\n",Part_Number); fflush(fplog);
														printf("\n PO start  GetInfo in Main: %s \t",Part_Number);fflush(stdout);
														GetInfoPo(PartTag);
														printf("\nPO End  GetInfo in Main: %s\t",Part_Number);fflush(stdout);
														fprintf(fplog,"\n\t PO End  GetInfo in Main:  [%s]\n",Part_Number); fflush(fplog);
													}
													if (lflag==1)
													{
														struct tm test_date = {0};
														test_date.tm_year = oYears - 1900;  
														test_date.tm_mon = oMonth - 1;         
														test_date.tm_mday = oDate;
														printf("\n part First Date  = %d-%d-%d",test_date.tm_mday,test_date.tm_mon,test_date.tm_year);

														lYears=oYears; 
														lMonth=oMonth; 
														lDate= oDate;
														printf("\n inside if if lflag......1  \t");fflush(stdout);
														maxDateClrpart = (char *) MEM_alloc(1000 * sizeof(char));
														strcpy(maxDateClrpart,"");
														strcat(maxDateClrpart,Part_Number);
														//strcat(maxDateClrpart,";");
														//strcat(maxDateClrpart,topLevelVC);
														printf("\n maxDateClrpart......1  %s\t",maxDateClrpart);fflush(stdout);
														lflag++;
													 }
													printf("\n start compare date logic.......1 \t");fflush(stdout);
													latest_date.tm_year = lYears - 1900;  
													latest_date.tm_mon = lMonth - 1;         
													latest_date.tm_mday = lDate;
															  
													time_t latest_time = mktime(&latest_date);
													time_t old_time1 = mktime(&old_date);
													printf("\n start compare date logic.......2 \t");fflush(stdout);

													if (old_time1 > latest_time) 
														{
														   printf("\n start compare date logic.......3 \t");fflush(stdout);

															lYears=oYears; 
															lMonth=oMonth; 
															lDate= oDate;

															 maxDateClrpart = (char *) MEM_alloc(1000 * sizeof(char));
															 strcpy(maxDateClrpart,"");
															 strcat(maxDateClrpart,Part_Number);
															 //strcat(maxDateClrpart,";");
															 //strcat(maxDateClrpart,topLevelVC);
																				   
															 printf("\n Mul part The new date is later than the old date.\n");
															printf("\n Mul part new Date= %d-%d-%d",latest_date.tm_mday,latest_date.tm_mon,latest_date.tm_year);
													   } 
													   else if (latest_time < old_time1)
														  {
															printf("\n The new date is earlier than the old date.\n");

														  }
															
													  else 
																
														  {
															  printf("\n Mul part The new date is later than the old date.\n");
															
														 } 
										
											   }
											   
									   }
									   else
										   {
												isAvailInUA = 0; 
												fprintf(fplog,"\n unable to match stucture..... :");fflush(fplog);
										  }
							  

						//fprintf(ImplosionReportDatew,"%s\n",maxDateClrpart); fflush(ImplosionReport);
						printf("\n Final PO Date old part2= %s=%d-%d-%d",topLevelVC,old_date.tm_mday,old_date.tm_mon,old_date.tm_year);
						printf("\n Final Date latest part1= %d-%d-%d",latest_date.tm_mday,latest_date.tm_mon,latest_date.tm_year);
						printf("\n maxDateClrpart : %s  \n",maxDateClrpart);fflush(stdout);
						fprintf(fplog,"\n\t Po maxDateClrpart.....1 [%s]\n",maxDateClrpart); fflush(fplog);
						   if (strcmp(maxDateClrpart,"NULL")!= 0 && strcmp(maxDateClrpart,"")!=0)
						   {
								   int len = strlen(maxDateClrpart);
								   sOldSuf = &maxDateClrpart[len-2];
								   isAvailInUA = 1;
						   }
						fprintf(fplog,"\n\t isAvailInUA.....1 [%d]\n",isAvailInUA); fflush(fplog);
						printf("\n isAvailInUA.....1 [%d]  \n",isAvailInUA);fflush(stdout);
					}
					else
					   {
									
						sOldSuf = "";
						sclrPart = strtok(PoclrPart,",");
						fprintf(fplog,"\t sclrPart colour part  PoclrPart %s\n",PoclrPart); fflush(fplog);
						int len = strlen(sclrPart);
						sOldSuf = &sclrPart[len-2];
						fprintf(fplog,"\t sOldSuf from  colour part PoclrPart  %s\n",sOldSuf); fflush(fplog);
						isAvailInUA =1;
					  }
				  }				
				else  // logic start from NO PO
				   {  
					if (strlen(matchclrPart)>17)
					   {

							 sClrPart = strtok(matchclrPart,",");
							   while(sClrPart!=NULL)
								{
								   fprintf(fplog,"\n Colour part from fix Table ..... %s ",sClrPart);fflush(fplog);
									printf("\n Colour part from fix Table ..... %s ",sClrPart);fflush(fplog);
									char *ItemId	=NULL;    
									 if (Query_Tag!=NULLTAG)
										{
										 printf("\n Query_Tag ..... %s ",sClrPart);fflush(fplog);
											values[0] = (char *)MEM_alloc(strlen(sClrPart) + 1);
											printf("\n Query_Tag .....1 %s ",sClrPart);fflush(fplog);
											tc_strcpy(values[0],sClrPart);
                                             printf("\n Query_Tag ..... %s ",sClrPart);fflush(fplog);
											ITK_CALL(QRY_execute(Query_Tag, value_entries, entries, values, &n_items, &items));

											printf("n_items : [%d]\n",n_items);
											
											printf("Query Executed\n");fflush(stdout);

											if ( n_items > 0 )
											{
												ITEM_tag = items[0];
												tagSET[ia]=ITEM_tag;
												ITK_CALL(AOM_ask_value_string(tagSET[ia], "item_id", &ItemId));
												setAddStr(&ia,&sFinalDataSet,ItemId);
											}
										}
										else
											{
											printf("Query Executed not null\n");fflush(stdout);
											}
		
										   sClrPart=strtok(NULL,","); 
								  }
								  printf("Po is not  colour part cnt for Imposion process ia: %d\n",ia);fflush(stdout);
								 if (ia>0)
								  {
									 DRFlag =0;
									 vcflag=0;
									 for (ik=0;ik<ia ;ik++ )				
									  {
										   char *sClrItemId=NULL;
												Part_Number=NULL;
												oYears=0;
												oMonth=0;
												oDate=0;
												vcCnt=0;
												topLevelVC = (char *) MEM_alloc(1000 * sizeof(char));
												strcpy(topLevelVC,"");
												strcpy(allUniqueVC,"");
										   ITEM_tag =tagSET[ik];
										   if(AOM_UIF_ask_value(ITEM_tag,"item_id", &sClrItemId)!=ITK_ok)   PrintErrorStack();

											fprintf(fplog,"\n Non-PO Getting single  Colour part from fix Table ..... %s ",sClrItemId);fflush(fplog);
											printf("\n Non-PO Getting single Colour part from fix Table ..... %s ",sClrItemId);fflush(fplog);
												
															
												if(ITEM_list_all_revs(ITEM_tag, &count1, &rev_listt)!=ITK_ok)   PrintErrorStack();
												if(count1 > 0)
													{
													  iij=0;
														for(iij=count1-1;iij>=0;iij--)
														  {
																printf("\n Total rev rev_listt: %d.", count1);fflush(stdout);
																PartTag = rev_listt[iij];

																if(AOM_UIF_ask_value(PartTag,"item_id", &rev_num)!=ITK_ok)   PrintErrorStack();
																if(AOM_UIF_ask_value(PartTag,"item_revision_id", &rev_id)!=ITK_ok)   PrintErrorStack();
																if (AOM_UIF_ask_value(PartTag,"release_status_list", &rell_status)!=ITK_ok)   PrintErrorStack();

																printf("\n rev_id:%s and rell_status:%s", rev_id,rell_status);fflush(stdout);
																if(tc_strstr(rell_status, "ERC Released") !=NULL)
																{
																	printf("\n for %s %s",rev_num,rev_id);fflush(stdout);
																	break ;
																}
															}
													}
															
													ITK_CALL(AOM_ask_value_string(PartTag,"current_id",&Part_Number));
													printf("Part Number:%s\n",Part_Number);fflush(stdout);
													
													ITK_CALL(AOM_ask_value_string(PartTag,"current_revision_id",&RevSeq));
													printf("Rev Seq:%s\n",RevSeq);fflush(stdout);
													
													ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&ReleaseStatus));
													printf("Release Status:%s\n",ReleaseStatus);fflush(stdout);

													ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_PartType",&PartType));
													printf("Part Type:%s\n",PartType);fflush(stdout);

													if((tc_strcmp(partType,"D")==0) || (tc_strcmp(partType,"IFD")==0))
													{
														printf("We are not generating this report as %s part number is part type %s\n",Part_Number,PartType);fflush(stdout);
													}
													else
													{
														printf("\n start  GetInfo in Main: %s\t",Part_Number);fflush(stdout);
														GetInfo(PartTag);
														printf("\n End  GetInfo in Main:  %s \t",Part_Number);fflush(stdout);
													}
                                                    

									if (vcflag==1)
										{
											maxDateClrpart = (char *) MEM_alloc(1000 * sizeof(char));
											strcpy(maxDateClrpart,"");													
											strcat(maxDateClrpart,Part_Number);
											break;
										}
										else
										  {
													if (lflag==1)
													{
														//lYears=oYears; 
														//lMonth=oMonth; 
													//	lDate= oDate;
                                                       oldvcCnt= vcCnt;
														maxDateClrpart = (char *) MEM_alloc(1000 * sizeof(char));
														strcpy(maxDateClrpart,"");													
														strcat(maxDateClrpart,Part_Number);
														sClrpartDate = (char *) MEM_alloc(1000 * sizeof(char));
														strcpy(sClrpartDate,"");
														strcat(sClrpartDate,Part_Number);	
														strcat(sClrpartDate,";");
														strcat(sClrpartDate,topLevelVC);
														printf("\n one time maxDateClrpart......1  %s\t",sClrpartDate);fflush(stdout);
														lflag++;
													 }
													 printf("\n start compare date logic.......1 \t");fflush(stdout);
												//	fprintf(fplog,"\n Clr Part ......%s = %s=%d-%d-%d\n",Part_Number,topLevelVC,old_date.tm_mday,old_date.tm_mon,old_date.tm_year); fflush(fplog);

													printf("\n start compare date logic Part_Number : %s= oldvcCnt=%d =vcCnt=%d.......1 \t",Part_Number,oldvcCnt,vcCnt);fflush(stdout);
													fprintf(fplog,"\n\t start compare date logic Part_Number: %s = oldvcCnt=%d =vcCnt=%d.......1\n",Part_Number,oldvcCnt,vcCnt); fflush(fplog);
												//	latest_date.tm_year = lYears - 1900;  
												//	latest_date.tm_mon = lMonth - 1;         
												//	latest_date.tm_mday = lDate;
												   // fprintf(fplog,"\n Clr Part .....%s.=%d-%d-%d \n",Part_Number,latest_date.tm_mday,latest_date.tm_mon,latest_date.tm_year); fflush(fplog);

												//	printf("\n start compare date Part1.......%d-%d-%d \t",latest_date.tm_mday,latest_date.tm_mon,latest_date.tm_year);fflush(stdout);
													////printf("\n start compare date Part2.......%d-%d-%d \t",old_date.tm_mday,old_date.tm_mon,old_date.tm_year);fflush(stdout);		  
													//time_t latest_time = mktime(&latest_date);
													//time_t old_time1 = mktime(&old_date);


													//if (old_time1>latest_time) 
													if (vcCnt>oldvcCnt) 
														{
														   printf("\n start compare date logic= %d.......3 \t",vcCnt);fflush(stdout);
														   fprintf(fplog,"\n\t start compare date logic= %d.......3\n",vcCnt); fflush(fplog);

														//	lYears=oYears; 
														//	lMonth=oMonth; 
														//	lDate= oDate;

															 maxDateClrpart = (char *) MEM_alloc(1000 * sizeof(char));
															 strcpy(maxDateClrpart,"");
															 strcat(maxDateClrpart,Part_Number);
															 
															sClrpartDate = (char *) MEM_alloc(1000 * sizeof(char));
															strcpy(sClrpartDate,"");
															strcat(sClrpartDate,Part_Number);	
															strcat(sClrpartDate,";");
															strcat(sClrpartDate,topLevelVC);
																				   
															 printf("\n Mul part The new date is later than the old date.\n");
															//printf("\n Mul part new Date= %d-%d-%d",latest_date.tm_mday,latest_date.tm_mon,latest_date.tm_year);
													   } 
													   //else if (latest_time<old_time1)
													   else if (oldvcCnt<vcCnt)
														  {
															printf("\n The new date is earlier than the old date.\n");
															//printf("\n The new date is earlier than the old date.......%d-%d-%d \t",old_date.tm_mday,old_date.tm_mon,old_date.tm_year);fflush(stdout);

														  }
															
													  else 
																
														  {
															  printf("\n Mul part The new date is later than the old date.\n");
															
														 } 
												   


													fprintf(fplog,"\n sClrpartDate Single part Date. %s:",sClrpartDate);fflush(fplog);
													printf("\n sClrpartDate Single part Date. %s\n",sClrpartDate);


									  }
									  

											   }

											   
											   
									   }
									   else
											{
												isAvailInUA = 0; 
												 fprintf(fplog,"\n unable to match stucture..... :");fflush(fplog);
											   }
							  

					   // fprintf(ImplosionReportDatew,"%s\n",maxDateClrpart); fflush(ImplosionReport);
						printf("\n Final Date old part2= %s=%d-%d-%d",sClrpartDate);
						//printf("\n Final Date latest part1= %d-%d-%d",latest_date.tm_mday,latest_date.tm_mon,latest_date.tm_year);
						printf("\n maxDateClrpart : %s  \n",maxDateClrpart);fflush(stdout);
						//fprintf(fplog,"\n Final Date old part2= %s=%d-%d-%d",topLevelVC,old_date.tm_mday,old_date.tm_mon,old_date.tm_year); fflush(fplog);
						//fprintf(fplog,"\n Final Date latest part1= %d-%d-%d",latest_date.tm_mday,latest_date.tm_mon,latest_date.tm_year); fflush(fplog);
						fprintf(fplog,"\n\t maxDateClrpart.....1 [%s]\n",maxDateClrpart); fflush(fplog);
						   if (strcmp(maxDateClrpart,"NULL")!= 0 && strcmp(maxDateClrpart,"")!=0)
						   {
								   int len = strlen(maxDateClrpart);
								   sOldSuf = &maxDateClrpart[len-2];
								   isAvailInUA = 1;
						   }
						fprintf(fplog,"\n\t isAvailInUA.....1 [%d]\n",isAvailInUA); fflush(fplog);
						printf("\n isAvailInUA.....1 [%d]  \n",isAvailInUA);fflush(stdout);
				   }
				else
					 {
					 fprintf(fplog,"\t PO is not available all matching colour part   %s , %d\n",matchclrPart,strlen(matchclrPart)); fflush(fplog);
					  if (matchclrPart!=NULL && strcmp(matchclrPart,"")!=0 &&strlen(matchclrPart)>0)
						{   sOldSuf = "";
							sclrPart = strtok(matchclrPart,",");
						 fprintf(fplog,"\t sclrPart colour part  matchclrPart ..  %s\n",matchclrPart); fflush(fplog);
							 int len = strlen(sclrPart);
							sOldSuf = &sclrPart[len-2];
						 fprintf(fplog,"\t sOldSuf from  colour part matchclrPart ...   %s\n",sOldSuf); fflush(fplog);
						 isAvailInUA =1;
						}
				  }
			   
				   }
				   
			  //  }
			
			
						if(isAvailInUA==1)
						{
						org_clr_id = FunToGetColorID_NEW(sOldSuf);

						org_compcode = tc_strtok(svalidClrSuf,"~");

						tc_strcpy(org_compcdNew,"");
						tc_strcat(org_compcdNew,org_compcode);
						tc_strcat(org_compcdNew,"~");
						tc_strcat(org_compcdNew,org_clr_id);

						fprintf(fplog,"\t org_compcode %s org_clr_id %s org_compcdNew [%s]\n",org_compcode,org_clr_id,org_compcdNew); fflush(fplog);

						tc_strcpy(sParentClrSufName,org_compcdNew);
						Eqflag=1;
						}
						else
						{
							fprintf(fplog,"\t Part not found in tcua, proceed with old logic \n"); fflush(fplog);
						}
						

						fprintf(fplog,"\t sParentClrSufName [%s] after copying org_compcdNew\n",sParentClrSufName); fflush(fplog);

					}

					fprintf(fplog,"\t flag_i: [%d] Eqflag: [%d]\n",flag_i,Eqflag); fflush(fplog);
					//if Eqflag=1,all the values are same, use same sParentClrSufName for updating color serial for CCA comp code.
					//if Eqflag=0,values are not same, create new entry in fix table.

					//if(flag_i==3 && Eqflag!=4)
					if(Eqflag==0)
					{

						fprintf(fplog,"\n\t flag_i [3], please create new entry in FIX Table, as no child clr suffix available as of BOM Comp Codes. \n"); fflush(fplog);
						status = FunToEntryDataInFIXTable(PrtCompCodeStr,CompCodeData,AllCompCodes,&suffixCnt);
						QRY_execute_with_sort(Cntl_obj_Qtag,n_entry,qry_sys_entry,qry_sys_values,num_to_sort,keys,&orders,&IntCount,&PrntClrSuf_tag);

						(AOM_UIF_ask_value(PrntClrSuf_tag[IntCount-1],"object_name",&sParentClrSufName));
						fprintf(fplog," \n After creating new color suffix: sParentClrSufName: [%s] status {%d} \n",sParentClrSufName,status);  fflush(fplog);
						fprintf(fplog," \n New entry added in fix table. setting Eqflag=1 to change color scheme data in color scheme.\n");  fflush(fplog);
						Eqflag=1;

					}
					if((Eqflag==1) && (status!=1))
					{
						fprintf(fplog,"\t Please proceed with parent color suffix: [%s]\n",sParentClrSufName); fflush(fplog);

						char *sCompCode = NULL;
						char *sColorID	= NULL;
						fprintf(fplog,"\n sParentClrSufName [%s]\n",sParentClrSufName); fflush(fplog);
						sCompCode =	tc_strtok(sParentClrSufName,"~");
						sColorID = tc_strtok(NULL,"~");

						fprintf(fplog,"\n sColorID [%s]\n",sColorID); fflush(fplog);

						//int status =0;
						tag_t   Cntl_obj_Ctag		=	NULLTAG;
						int     n_entry_C			=	1;
						char    *qry_sys_entryC[1]	=	{"Colour ID"};
						char    **qry_sys_valuesC   =  (char **) MEM_alloc(10 * sizeof(char *));
						int		IntCountC			=	0;
						int		IsValidFlag			=	0;
						tag_t   *ClrSuf_tag			=	NULLTAG;
						char	*sClrSerSuf			=	NULL;
						char	*sClrID				=	NULL;
						char	*sIntScheme			=   NULL;
						char*	clr_SerSuf			= NULL;
						char	*CID				=	NULL;
						CID=(char *) MEM_alloc(50);

						int m=0;
						fprintf(fplog,"\n  "); fflush(fplog);
						strcpy(CID,sColorID);
						strcat(CID,"*");
						fprintf(fplog,"\n CID:[%s]",CID); fflush(fplog);


						fprintf(fplog,"\n  "); fflush(fplog);
						fprintf(fplog,"\n "); fflush(fplog);

						ITK_CALL(QRY_find2("Colour Master", &Cntl_obj_Ctag));
						if (Cntl_obj_Ctag)
						{
							fprintf(fplog,"\n Found Query Colour Master... \n"); fflush(fplog);
						}
						else
						{
							fprintf(fplog,"\n Not Found Query Colour Master... \n"); fflush(fplog);
						}

						qry_sys_valuesC[0] = CID;
						ITK_CALL(QRY_execute(Cntl_obj_Ctag, n_entry_C, qry_sys_entryC, qry_sys_valuesC, &IntCountC, &ClrSuf_tag));
						fprintf(fplog,"IntCountC: [%d] \n",IntCountC);  fflush(fplog);

							fprintf(fplog," \n ");  fflush(fplog);
							if(IntCountC>0)
							{
								clr_SerSuf = FunToGetColorSerial(sNewSuf);
								fprintf(fplog,"\n FunToGetColorSerial clr_SerSuf== %s \n",clr_SerSuf); fflush(fplog);
								fprintf(fReport,"\n %s,%s,%s,%s",PrtCompCodeStr,clr_SerSuf,sOldSuf,allPartnumber); fflush(fReport);
								for (m=0;m<IntCountC;m++)
								{ 
									ITK_CALL(AOM_UIF_ask_value(ClrSuf_tag[m],"t5_IntScheme",&sIntScheme));
									if (strcmp(sIntScheme,"T")==0)
									{
									 ITK_CALL(AOM_UIF_ask_value(ClrSuf_tag[m],"object_name",&sClrSerSuf));
									 ITK_CALL(AOM_UIF_ask_value(ClrSuf_tag[m],"t5_ColourId",&sClrID));
									}
									
								}
															
								
								fprintf(fplog,"\n sClrSerSuf[%s] sClrID[%s]\n",sClrSerSuf,sClrID); fflush(fplog);
								// Function to Create Color Scheme Data and Add it in Color Scheme.
								//FunToCreClrSchData(sCompCodeS,sClrSerSuf,sClrID);
								//FunToCreClrSchData(char *sCompCodeS,char *sClrSerSuffix,char* sClrID)



						/***********************************************************************************************/
								//int		status		=	0;
								int		n_entries	=	3;
								//int		n_entries	=	1;
								tag_t	queryTag	=	NULLTAG;
								char*	clrsrlmain1	=	NULL;
								char*	clrsrl	=	NULL;
								int		resultCount	=	0;
								tag_t	*qry_output	=	NULLTAG;
								char *item_id_ColDatamain=NULL;
								char* dupintrnalscheme=NULL;
								char* ClrsrlCat=NULL;

								dupintrnalscheme=(char *)MEM_alloc(100);
								ClrsrlCat=(char *)MEM_alloc(100);

								char* item_id_ColData=NULL;
								item_id_ColData=(char *)MEM_alloc(100);

								clrsrlmain1=(char *)MEM_alloc(100);
								clrsrl=(char *)MEM_alloc(100);
								// Query Is color scheme data available for give inputs.

								fprintf(fplog,"\n sClrSerSuf[%s] sClrID[%s]\n",sClrSerSuf,sClrID); fflush(fplog);
								fprintf(fplog,"sCompCode --------> %s\n",sCompCode); fflush(fplog);
								//if(QRY_find2("ColorSchemeCompCodeDataRevision", &queryTag));
								if(QRY_find2("ColorSchemeDataRevision", &queryTag));
								if (queryTag)
								{
								fprintf(fplog,"Found Query 'ColorSchemeDataRevision' \n\t"); fflush(fplog);
								}
								else
								{
								fprintf(fplog,"Not Found Query 'ColorSchemeDataRevision' \n\t"); fflush(fplog);
								return status;
								}
								char *qry_entries4[3] = {"Comp Code","Internal Scheme","Color Serial"};
								char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));

								//char *qry_entries4[1] = {"Name"};
								//char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));


								tc_strcpy(clrsrlmain1,"");
								tc_strcat(clrsrlmain1,sClrSerSuf);
								tc_strcat(clrsrlmain1,"*");
								tc_strcat(clrsrlmain1,sClrID);



								//tc_strcpy(clrsrlmain1,"");
								//tc_strcat(clrsrlmain1,sCompCode);
								//tc_strcat(clrsrl,"`");
								//tc_strcat(clrsrl,"T");
								//tc_strcat(clrsrl,"`");
								//tc_strcat(clrsrlmain1,sClrSerSuf);
								//tc_strcat(clrsrlmain1,"*");
								//tc_strcat(clrsrlmain1,sClrID);


								fprintf(fplog,"clrsrlmain1 --------> %s\n",clrsrlmain1); fflush(fplog);

								qry_values[0] = sCompCode ;
								qry_values[1] = "T" ;
								qry_values[2] = clrsrlmain1 ;

								//qry_values[0] = clrsrlmain1;

								ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &qry_output));
								fprintf(fplog,"\n Final Count of Query Values ------------------>  %d \n",resultCount); fflush(fplog);
							//	if (resultCount == 0)
							//	{
							//		tc_strcpy(clrsrlmain1,"");
							//		tc_strcat(clrsrlmain1,sCompCode);
							//		tc_strcat(clrsrlmain1,"`");
							//		tc_strcat(clrsrlmain1,"T");
							//		tc_strcat(clrsrlmain1,"`");
							//		tc_strcat(clrsrlmain1,sClrID);
							//		tc_strcat(clrsrlmain1,"*");
							//		tc_strcat(clrsrlmain1,sClrSerSuf);
							//		 qry_values[0] = clrsrlmain1;
							//
							//		ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &qry_output));
							//		fprintf(fplog,"\n Final Count of Query Values ------------------>  %d \n",resultCount); fflush(fplog);
							//
							//	}

								tag_t object_create_input_tag1		=	NULLTAG;
								tag_t Colordata_type_tag			=	NULLTAG;
								tag_t new_COLDATA_object			=	NULLTAG;
								tag_t clrdatarevtag					=	NULLTAG;
								tag_t clrdatarevtag1				=	NULLTAG;
								tag_t ColData_relation_type			=	NULLTAG;
								tag_t del_relation					=	NULLTAG;
								tag_t new_relation					=	NULLTAG;
								if (resultCount == 0)
								{
									tc_strcpy(dupintrnalscheme,"");
									tc_strcat(dupintrnalscheme,sClrID);
									tc_strcat(dupintrnalscheme,";");
									tc_strcat(dupintrnalscheme,sClrSerSuf);

									tc_strcpy(ClrsrlCat,"");
									tc_strcat(ClrsrlCat,sClrSerSuf);
									tc_strcat(ClrsrlCat,";");
									tc_strcat(ClrsrlCat,sClrID);

									tc_strcpy(item_id_ColData,"");
									tc_strcat(item_id_ColData,sCompCode);
									tc_strcat(item_id_ColData,"`");
									tc_strcat(item_id_ColData,"T");
									tc_strcat(item_id_ColData,"`");
									tc_strcat(item_id_ColData,dupintrnalscheme);

									item_id_ColDatamain = replaceWord(item_id_ColData, c, d);
									fprintf(fplog,"\n**************** item_id_ColDatamain: %s  ***************\n",item_id_ColDatamain); fflush(fplog);

									ITK_CALL(TCTYPE_find_type("T5_ClrShmData", NULL, &Colordata_type_tag));

									ITK_CALL(TCTYPE_construct_create_input(Colordata_type_tag, &object_create_input_tag1));

									ITK_CALL(AOM_set_value_string(object_create_input_tag1,"object_name",item_id_ColDatamain));
									ITK_CALL(AOM_set_value_string(object_create_input_tag1,"item_id",item_id_ColDatamain));

									ITK_CALL(TCTYPE_create_object(object_create_input_tag1, &new_COLDATA_object));

									if(new_COLDATA_object)
									{
									fprintf(fplog,"\n t5CreateClrschm ---------------------------> new_COLDATA_object created."); fflush(fplog);
									ITK_CALL(AOM_save_without_extensions(new_COLDATA_object));
									ITK_CALL(AOM_refresh(new_COLDATA_object,0));
									}

									ITK_CALL( ITEM_ask_latest_rev (new_COLDATA_object,&clrdatarevtag) );
									if(clrdatarevtag)
									{
									ITK_CALL(AOM_refresh(clrdatarevtag,1));
									ITK_CALL(AOM_set_value_string(clrdatarevtag,"t5_PrtCatCode",sCompCode));
									ITK_CALL(AOM_set_value_string(clrdatarevtag,"t5_InternalSchm","T"));
									ITK_CALL(AOM_set_value_string(clrdatarevtag,"t5_ClSrl",ClrsrlCat));
									ITK_CALL(AOM_save_without_extensions(clrdatarevtag));
									ITK_CALL(AOM_refresh(clrdatarevtag,0));
									}

									ITK_CALL(GRM_find_relation_type("T5_ShmHasClrData",&ColData_relation_type));
									ITK_CALL(GRM_find_relation(ClrScheme_tag,clrdatarevtag,ColData_relation_type,&del_relation));
									if(del_relation != NULLTAG)
									{
									fprintf(fplog,"\n  FunExpPartToGetChildCompCodes relation already available. \n"); fflush(fplog);

									ITK_CALL(AOM_refresh(del_relation,0));
									ITK_CALL(AOM_lock(del_relation));
									ITK_CALL(GRM_save_relation(del_relation));
									ITK_CALL(AOM_refresh(del_relation,1));
									ITK_CALL(AOM_load(del_relation));

									status=0;
									}
									else
									{
									if(ColData_relation_type != NULLTAG)
									{
										ITK_CALL(GRM_create_relation(ClrScheme_tag,clrdatarevtag,ColData_relation_type,NULLTAG,&new_relation));
										if(new_relation != NULLTAG)
											{
											ITK_CALL(GRM_save_relation(new_relation));
											fprintf(fplog,"\n  FunExpPartToGetChildCompCodes relation is created . \n"); fflush(fplog);

											}
									}
									status=0;
									}

								}
								else
									{
										fprintf(fplog,"\n Inside else of relation creation .............\n");fflush(fplog);
										char *sObjName = NULL;
										ITK_CALL(GRM_find_relation_type("T5_ShmHasClrData",&ColData_relation_type));
										if(ColData_relation_type != NULLTAG)
											{
												clrdatarevtag1 = qry_output[0];
												 AOM_ask_value_string(clrdatarevtag1,"object_name",&sObjName);
												 fprintf(fplog,"\n  FunExpPartToGetChildCompCodes object_name is : %s. \n",sObjName); fflush(fplog);
												ITK_CALL(GRM_find_relation(ClrScheme_tag,clrdatarevtag1,ColData_relation_type,&del_relation));
												if(del_relation != NULLTAG)
												{
												fprintf(fplog,"\n  FunExpPartToGetChildCompCodes relation already available. \n"); fflush(fplog);

												ITK_CALL(AOM_refresh(del_relation,0));
												ITK_CALL(AOM_lock(del_relation));
												ITK_CALL(GRM_save_relation(del_relation));
												ITK_CALL(AOM_refresh(del_relation,1));
												ITK_CALL(AOM_load(del_relation));

												status=0;
												}
												else
												{
												  fprintf(fplog,"\n  FunExpPartToGetChildCompCodes relation Created. \n"); fflush(fplog);
												  ITK_CALL(GRM_create_relation(ClrScheme_tag,clrdatarevtag1,ColData_relation_type,NULLTAG,&new_relation));
												if(new_relation != NULLTAG)
												{
												fprintf(fplog,"\n inside if  FunExpPartToGetChildCompCodes relation Created. \n"); fflush(fplog);
												ITK_CALL(GRM_save_relation(new_relation));
												ITK_CALL(AOM_refresh(new_relation,0));
												}
												}
											}
									}
							}
							else
							{
								fprintf(fplog,"\n Suffix not found in the System, Need to create in the system  . \n"); fflush(fplog);
								status = 3;

							}
					}
					// new logic
					return status;
				}



				// function to replace CCA comp code with new color serial
				int FunToReplaceColorSchemeData(char* ClrSufixName,char* OrgcompcodeStr)
				{

					fprintf(fplog,"\t Please proceed with parent color suffix: [%s] OrgcompcodeStr [%s]\n",ClrSufixName,OrgcompcodeStr);fflush(fplog);
					//ClrSufixName: CCA_CENTER_AIR_VENT~CLRPRT_ASY_1
					//ClrSufixName: CCA_CENTER_AIR_VENT
					//CCA_GLOVE_BOX~CLRPRT_ASY_3
					//CCA_STEERING_WHEEL~CLRPRT_ASY_1
					char *sCompCode = NULL;
					char *sColorID	= NULL;
					char* c = ",";
					char* d	= ";";

					fprintf(fplog,"\n 77ClrSufixName [%s]\n",ClrSufixName);fflush(fplog);

					if(strstr(ClrSufixName,"~")!=NULL)
					{
						sCompCode =	tc_strtok(ClrSufixName,"~");
						sColorID = tc_strtok(NULL,"");

					if(strstr(ClrSufixName,"~")!=NULL)
					{
						fprintf(fplog,"\n AAClrSufixName [%s]\n",ClrSufixName);fflush(fplog);
						sColorID = strtok(NULL,"~");
						fprintf(fplog,"\n CCsColorID [%s]\n",sColorID);fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n 1111ClrSufixName [%s]\n",ClrSufixName);fflush(fplog);
						fprintf(fplog,"\n 1111sColorID [%s]\n",sColorID);fflush(fplog);
						//sColorID = strtok(NULL,"");
						//sColorID=(char *) MEM_alloc(50);
						//tc_strcpy(sColorID,ClrSufixName);
					}
					}
					else
					{
						fprintf(fplog,"\n BBClrSufixName [%s]\n",ClrSufixName);fflush(fplog);
						sCompCode =	tc_strtok(ClrSufixName,"~");
						sColorID =	tc_strtok(NULL,"");
						//sColorID=(char *) MEM_alloc(50);
						//tc_strcpy(sColorID,ClrSufixName);
					}

					fprintf(fplog,"\n 77sColorID [%s]\n",sColorID);fflush(fplog);

					int		status						=	0;
					tag_t   Cntl_obj_Ctag				=	NULLTAG;
					int     n_entry_C					=	1;
					char    *qry_sys_entryC[1]			=	{"Colour ID"};
					char    **qry_sys_valuesC			=  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCountC					=	0;
					int		IsValidFlag					=	0;
					tag_t   *ClrSuf_tag					=	NULLTAG;
					char	*sClrSerSuf					=	NULL;
					char	*sClrID						=	NULL;
					char	*CID						=	NULL;
					tag_t object_create_input_tag1		=	NULLTAG;
					tag_t Colordata_type_tag			=	NULLTAG;
					tag_t new_COLDATA_object			=	NULLTAG;
					tag_t clrdatarevtag					=	NULLTAG;
					tag_t clrdatarevtag1				=	NULLTAG;
					tag_t ColData_relation_type			=	NULLTAG;
					tag_t new_relation					=	NULLTAG;
					tag_t del_relation					=	NULLTAG;


					//int		n_entries					=	3;
					int		n_entries					=	1;
					tag_t	queryTag					=	NULLTAG;
					char*	clrsrlmain1					=	NULL;
					int		resultCount					=	0;
					tag_t	*qry_output					=	NULLTAG;
					char *item_id_ColDatamain			=	NULL;
					char* dupintrnalscheme				=	NULL;
					char* ClrsrlCat						=	NULL;
					char	*sIntScheme=NULL;
					int m=0;

					dupintrnalscheme=(char *)MEM_alloc(100);
					ClrsrlCat=(char *)MEM_alloc(100);

					char* item_id_ColData=NULL;
					item_id_ColData=(char *)MEM_alloc(100);

					clrsrlmain1=(char *)MEM_alloc(100);
					CID=(char *) MEM_alloc(50);


					fprintf(fplog,"\n  ");fflush(fplog);
					strcpy(CID,sColorID);
					strcat(CID,"*");
					fprintf(fplog,"\n inside FunToReplaceColorSchemeData 1: CID:[%s]",CID);fflush(fplog);

					ITK_CALL(GRM_find_relation_type("T5_ShmHasClrData",&ColData_relation_type));

					// Find ##;DUMMY_COLSRL comp code

					// end

					ITK_CALL(AOM_load(LatestRev));

					ITK_CALL(POM_refresh_instances(1,&LatestRev,class_to_load_as,lock_type));
					//(POM_load_instances(1,&LatestRev,class_to_load_as,lock_type));

					fprintf(fplog,"\n  ");fflush(fplog);
					fprintf(fplog,"\n inside FunToReplaceColorSchemeData  2");fflush(fplog);

					ITK_CALL(QRY_find2("Colour Master", &Cntl_obj_Ctag));
					if (Cntl_obj_Ctag)
					{
						fprintf(fplog,"\n 11 Found Query Colour Master... \n");fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Not Found Query Colour Master... \n");fflush(fplog);
					}

					qry_sys_valuesC[0] = CID;
					ITK_CALL(QRY_execute(Cntl_obj_Ctag, n_entry_C, qry_sys_entryC, qry_sys_valuesC, &IntCountC, &ClrSuf_tag));
					fprintf(fplog,"11 IntCountC: [%d] \n",IntCountC);fflush(fplog);

						fprintf(fplog," \n "); fflush(fplog);
						if(IntCountC>0)
						{
							for (m=0;m<IntCountC;m++)
								{ 
									ITK_CALL(AOM_UIF_ask_value(ClrSuf_tag[m],"t5_IntScheme",&sIntScheme));
									if (strcmp(sIntScheme,"T")==0)
									{
									 ITK_CALL(AOM_UIF_ask_value(ClrSuf_tag[m],"object_name",&sClrSerSuf));
									 ITK_CALL(AOM_UIF_ask_value(ClrSuf_tag[m],"t5_ColourId",&sClrID));
									}
									
								}

							fprintf(fplog,"\n sClrSerSuf[%s] sClrID[%s]\n",sClrSerSuf,sClrID);fflush(fplog);
							// Function to Create Color Scheme Data and Add it in Color Scheme.
							//FunToCreClrSchData(sCompCodeS,sClrSerSuf,sClrID);
							//FunToCreClrSchData(char *sCompCodeS,char *sClrSerSuffix,char* sClrID)

					/***********************************************************************************************/

							// Query Is color scheme data available for give inputs.

							fprintf(fplog,"\n sClrSerSuf[%s] sClrID[%s]\n",sClrSerSuf,sClrID);fflush(fplog);
							fprintf(fplog,"sCompCode --------> %s\n",sCompCode);fflush(fplog);
							if(QRY_find2("ColorSchemeCompCodeDataRevision", &queryTag));
							//if(QRY_find2("ColorSchemeDataRevision", &queryTag));
							if (queryTag)
							{
							fprintf(fplog,"Found Query 'ColorSchemeDataRevision' \n\t");fflush(fplog);
							}
							else
							{
							fprintf(fplog,"Not Found Query 'ColorSchemeDataRevision' \n\t"); fflush(fplog);
							return status;
							}
							//char *qry_entries4[3] = {"Comp Code","Internal Scheme","Color Serial"};
							//char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));

							char *qry_entries4[1] = {"Name"};
							char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));

							//tc_strcpy(clrsrlmain1,"");
							//tc_strcat(clrsrlmain1,sClrSerSuf);
							//tc_strcat(clrsrlmain1,"*");
							//tc_strcat(clrsrlmain1,sClrID);

							tc_strcpy(clrsrlmain1,"");
							tc_strcat(clrsrlmain1,sCompCode);
							tc_strcat(clrsrlmain1,"`");
							tc_strcat(clrsrlmain1,"T");
							tc_strcat(clrsrlmain1,"`");
							tc_strcat(clrsrlmain1,sClrSerSuf);
							tc_strcat(clrsrlmain1,"*");
							tc_strcat(clrsrlmain1,sClrID);

							fprintf(fplog,"clrsrlmain1 --------> %s\n",clrsrlmain1);fflush(fplog);

							//qry_values[0] = sCompCode ;
							//qry_values[1] = "T" ;
							//qry_values[2] = clrsrlmain1 ;

							qry_values[0] = clrsrlmain1;

							ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &qry_output));
							fprintf(fplog,"\n Count of Query Values ------------------>  %d \n",resultCount);fflush(fplog);

							if (resultCount == 0)
							{
								tc_strcpy(clrsrlmain1,"");
								tc_strcat(clrsrlmain1,sCompCode);
								tc_strcat(clrsrlmain1,"`");
								tc_strcat(clrsrlmain1,"T");
								tc_strcat(clrsrlmain1,"`");
								tc_strcat(clrsrlmain1,sClrID);
								tc_strcat(clrsrlmain1,"*");
								tc_strcat(clrsrlmain1,sClrSerSuf);

								fprintf(fplog,"if clrsrlmain1 --------> %s\n",clrsrlmain1);fflush(fplog);

								//qry_values[0] = sCompCode ;
								//qry_values[1] = "T" ;
								//qry_values[2] = clrsrlmain1 ;

								qry_values[0] = clrsrlmain1;

								ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries4, qry_values, &resultCount, &qry_output));
								fprintf(fplog,"\n if Count of Query Values ------------------>  %d \n",resultCount);fflush(fplog);

							}

							if (resultCount == 0)
							{
								tc_strcpy(dupintrnalscheme,"");
								tc_strcat(dupintrnalscheme,sClrID);
								tc_strcat(dupintrnalscheme,";");
								tc_strcat(dupintrnalscheme,sClrSerSuf);

								tc_strcpy(ClrsrlCat,"");
								tc_strcat(ClrsrlCat,sClrSerSuf);
								tc_strcat(ClrsrlCat,";");
								tc_strcat(ClrsrlCat,sClrID);

								tc_strcpy(item_id_ColData,"");
								tc_strcat(item_id_ColData,sCompCode);
								tc_strcat(item_id_ColData,"`");
								tc_strcat(item_id_ColData,"T");
								tc_strcat(item_id_ColData,"`");
								tc_strcat(item_id_ColData,dupintrnalscheme);

								item_id_ColDatamain = replaceWord(item_id_ColData, c, d);
								fprintf(fplog,"\n**************** item_id_ColDatamain: %s  ***************\n",item_id_ColDatamain);fflush(fplog);

								ITK_CALL(TCTYPE_find_type("T5_ClrShmData", NULL, &Colordata_type_tag));

								ITK_CALL(TCTYPE_construct_create_input(Colordata_type_tag, &object_create_input_tag1));

								ITK_CALL(AOM_set_value_string(object_create_input_tag1,"object_name",item_id_ColDatamain));
								ITK_CALL(AOM_set_value_string(object_create_input_tag1,"item_id",item_id_ColDatamain));

								ITK_CALL(TCTYPE_create_object(object_create_input_tag1, &new_COLDATA_object));

								if(new_COLDATA_object)
								{
								fprintf(fplog,"\n t5CreateClrschm ---------------------------> new_COLDATA_object created.");fflush(fplog);
								ITK_CALL(AOM_save_without_extensions(new_COLDATA_object));
								ITK_CALL(AOM_refresh(new_COLDATA_object,0));
								}

								ITK_CALL( ITEM_ask_latest_rev (new_COLDATA_object,&clrdatarevtag) );
								if(clrdatarevtag)
								{
								ITK_CALL(AOM_refresh(clrdatarevtag,1));
								ITK_CALL(AOM_set_value_string(clrdatarevtag,"t5_PrtCatCode",sCompCode));
								ITK_CALL(AOM_set_value_string(clrdatarevtag,"t5_InternalSchm","T"));
								ITK_CALL(AOM_set_value_string(clrdatarevtag,"t5_ClSrl",ClrsrlCat));
								ITK_CALL(AOM_save_without_extensions(clrdatarevtag));
								ITK_CALL(AOM_refresh(clrdatarevtag,0));
								}


								if(ColData_relation_type != NULLTAG)
								{
									ITK_CALL(GRM_find_relation(LatestRev,clrdatarevtag,ColData_relation_type,&del_relation));
									if(del_relation!=NULLTAG)
									{
										fprintf(fplog,"\n relation already available. \n");fflush(fplog);
									}
									else
										{
									ITK_CALL(GRM_create_relation(LatestRev,clrdatarevtag,ColData_relation_type,NULLTAG,&new_relation));
									if(new_relation != NULLTAG)
										{
										ITK_CALL(GRM_save_relation(new_relation));
										ITK_CALL(AOM_load(LatestRev));
										ITK_CALL(POM_refresh_instances(1,&LatestRev,class_to_load_as,lock_type));
										//(POM_load_instances(1,&LatestRev,class_to_load_as,lock_type));
										}
										}
								}

							}
							else
								{
									fprintf(fplog,"\n Inside else of relation creation if not available \n");fflush(fplog);
									//ITK_CALL(GRM_find_relation_type("T5_ShmHasClrData",&ColData_relation_type));
									if(ColData_relation_type != NULLTAG)
										{
										clrdatarevtag1 = qry_output[0];
										ITK_CALL(GRM_find_relation(LatestRev,clrdatarevtag1,ColData_relation_type,&del_relation));
										if(del_relation!=NULLTAG)
											{
												fprintf(fplog,"\n relation already available. \n");fflush(fplog);
											}
											else
											{
											ITK_CALL(GRM_create_relation(LatestRev,clrdatarevtag1,ColData_relation_type,NULLTAG,&new_relation));
											if(new_relation != NULLTAG)
											{
											ITK_CALL(GRM_save_relation(new_relation));
											}
											}
										}
								}
							}
							ITK_CALL(AOM_load(LatestRev));

							ITK_CALL(POM_refresh_instances(1,&LatestRev,class_to_load_as,lock_type));
							//(POM_load_instances(1,&LatestRev,class_to_load_as,lock_type));

				}

				int FunToEntryDataInFIXTable(char *compcodeStr, char** CombCompCodeArr,char** AllCompCodes,int* suffixInt)
				{
					int status=0;

					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int		l					=	0;
					int     n_entry				=	1;
					char    *qry_sys_entry[1]	=	{"Place Holder"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCount			=	0;
					tag_t   *PrntClrSuf_tag		=	NULLTAG;
					char*	Obj_name			=	NULL;
					char*	ChildCompCode			=	NULL;
					char* d	= ";";
					char* e  = "*";

					tag_t	Clr_type_tag				= NULLTAG;
					tag_t	object_create_input_tag		= NULLTAG;
					tag_t	Chd_type_tag				= NULLTAG;
					tag_t	object_create_chd_tag		= NULLTAG;
					tag_t	ColSufTag					= NULLTAG;
					tag_t	ChdColSufTag				= NULLTAG;
					tag_t	rev_type_tag				= NULLTAG;
					char*	ModuleSyscdStr				= NULL;
					tag_t   Cntl_obj_tag		=	NULLTAG;
					int     n					=	2;
					char    *qry_entry[2]		=	{"Name","Type"};
					char    **qry_values		=  (char **) MEM_alloc(20 * sizeof(char *));
					int		Count				=	0;
					tag_t   *ChildClrSuf_tag    =	NULLTAG;

					int 	num_to_sort			=	1;
					char	*keys[1]			=	{"creation_date"};
					int		orders				=	1;
					int		Count4				=	0;
					tag_t	*qry_tag_sort		=	NULLTAG;
					int		ii					=	0;
					char*	SclrSuf_Name		=	NULL;
					char*	SplcHolder			=	NULL;

					char	*SplcHoldr			=	NULL;
					char	*SClrID				=	NULL;
					char	*subColID			=	NULL;
					int		IntsubColID			=	0;
					char	SsubColID[50];
					char	*SclrSuf_Nm			=	NULL;
					char	*subSuf				=	NULL;
					char	*ScatSuf			=	NULL;
					char	*ObjName			=	NULL;
					char	*SplcHolSuf			=	NULL;


					Obj_name=(char *) MEM_alloc(100);
					ChildCompCode=(char *) MEM_alloc(100);
					SclrSuf_Nm=(char *) MEM_alloc(100);
					ObjName=(char *) MEM_alloc(100);
					ScatSuf=(char *) MEM_alloc(100);

					fprintf(fplog,"\n Inside Function FunToEntryDataInFIXTable \n");fflush(fplog);
					printf("\n Inside Function FunToEntryDataInFIXTable \n");

					fprintf(fplog,"\n compcodeStr:[%s] suffixInt:[%d]\n",compcodeStr,*suffixInt);fflush(fplog);

					// query parent fix table data

					(QRY_find2("Color_Suffix_Query", &Cntl_obj_Qtag));
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n -- Found Query General... \n");fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Not Found Query General... \n");fflush(fplog);
					}

					qry_sys_values[0] = compcodeStr;
					(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCount, &PrntClrSuf_tag));
					fprintf(fplog," \n Inside Function FunToEntryDataInFIXTable Parent color suffix count IntCount: [%d]\n",IntCount);fflush(fplog);
					if(IntCount==0)
					{
						// Create Color Suffix with below details if it is first entry:
						// object_name: compcodeStr~CLRPRT_ASY
						// t5_PlaceHolder: compcodeStr
						// t5_PlaceHolderSuffix: ZZ

						strcpy(Obj_name,"");
						strcat(Obj_name,compcodeStr);
						strcat(Obj_name,"~");
						strcat(Obj_name,"CLRPART_ASSY");
						ITK_CALL(TCTYPE_find_type("T5_ColorSuffix", NULL, &Clr_type_tag));
						ITK_CALL(TCTYPE_construct_create_input(Clr_type_tag, &object_create_input_tag));

						ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",Obj_name));
						ITK_CALL(TCTYPE_create_object(object_create_input_tag, &ColSufTag));

						if(ColSufTag)
						{
							fprintf(fplog,"\n t5CreateObject : object created.");fflush(fplog);
							ITK_CALL(AOM_save_without_extensions(ColSufTag));
							ITK_CALL(AOM_refresh(ColSufTag,0));

							ITK_CALL(AOM_refresh(ColSufTag,1));

							ITK_CALL(AOM_set_value_string(ColSufTag,"t5_PlaceHolder",compcodeStr));
							ITK_CALL(AOM_set_value_string(ColSufTag,"t5_PlaceHolderSuffix","ZZ"));

							ITK_CALL(AOM_save_without_extensions(ColSufTag));
							ITK_CALL(AOM_refresh(ColSufTag,1));


							fprintf(fplog,"\n suffixInt:[%d]\n",*suffixInt);fflush(fplog);

							if(*suffixInt>0)
							{

							fprintf(fplog,"\n suffixInt11:[%d]\n",*suffixInt);fflush(fplog);

							for(l=0;l<*suffixInt;l++)
								{
								fprintf(fplog,"\n suffixInt22:[%d]\n",*suffixInt);fflush(fplog);
								fprintf(fplog,"\n Child Color Suffix: [%s]\n",CombCompCodeArr[l]);fflush(fplog);

								ITK_CALL(QRY_find2("General...", &Cntl_obj_tag));
								if (Cntl_obj_tag)
								{
									fprintf(fplog,"\n -- Found Query General... \n");fflush(fplog);
								}
								else
								{
									fprintf(fplog,"\n Not Found Query General... \n");fflush(fplog);
								}
								fprintf(fplog,"\n CombCompCodeArr [%s] \n",CombCompCodeArr[l]);fflush(fplog);

								ChildCompCode = replaceWord(CombCompCodeArr[l], d, e);

								qry_values[0] = ChildCompCode;
								qry_values[1] = "Child Color Suffix" ;
								ITK_CALL(QRY_execute(Cntl_obj_tag, n, qry_entry, qry_values, &Count, &ChildClrSuf_tag));
								fprintf(fplog," \n Child Color Suffix Count:[%d] \n",Count); fflush(fplog);
								if(Count>0)
								{
									// create relation between color suffix and child color suffix.
									fprintf(fplog,"\n create relation between color suffix and child color suffix. \n");fflush(fplog);
									if(FL_insert(ColSufTag,ChildClrSuf_tag[0],99));
									if(AOM_save_without_extensions(ColSufTag));

								}
								else
								{
									// create child color suffix
									ITK_CALL(TCTYPE_find_type("T5_Child_Color_Suffix", NULL, &Chd_type_tag));
									ITK_CALL(TCTYPE_construct_create_input(Chd_type_tag, &object_create_chd_tag));
									ITK_CALL(AOM_set_value_string(object_create_chd_tag,"object_name",CombCompCodeArr[l]));
									ITK_CALL(TCTYPE_create_object(object_create_chd_tag, &ChdColSufTag));
									if(ChdColSufTag)
									{
										fprintf(fplog,"\n t5CreateObject : object created.");fflush(fplog);
										ITK_CALL(AOM_save_without_extensions(ChdColSufTag));
										ITK_CALL(AOM_refresh(ChdColSufTag,0));


									}
									//CombCompCodeArr[l] = ChdColSufTag;

									if(FL_insert(ColSufTag,ChdColSufTag,99));
									if(AOM_save_without_extensions(ColSufTag));

								}

								// Create relation betwn color suffix and child color suffix.

							}
						}
						else
						{
						fprintf(fplog,"\n ELSE \n");fflush(fplog);
						}
						}
					}
					else if(IntCount>=1)
					{
						// Create Color Suffix with below details if it is first entry:
						// object_name: compcodeStr~'Incremental_CLRPRT'
						// t5_PlaceHolder: compcodeStr
						// t5_PlaceHolderSuffix: 'Incremental_suffix'
						int IntSub[1000];
						int min=0;
						int flag_n=0;
						char *StrSub=NULL;
						char *StrSuf = NULL;
						char *LtstCompCode = NULL;
						char *LtstCompCodeData = NULL;
						char *NewLtstCompCodeData = NULL;
						char *sNewObjName = NULL;
						StrSuf=(char *)MEM_alloc(100);
						char *StrSufStr = NULL;
						StrSufStr=(char *)MEM_alloc(100);
						NewLtstCompCodeData=(char *)MEM_alloc(200);
						QRY_execute_with_sort(Cntl_obj_Qtag,n_entry,qry_sys_entry,qry_sys_values,num_to_sort,keys,&orders,&Count4,&qry_tag_sort);

						for (min=0;min<Count4;min++)
						{
						AOM_ask_value_string(qry_tag_sort[min],"object_name",&SclrSuf_Name);
						fprintf(fplog,"\n :: SclrSuf_Name is :: %s\n",SclrSuf_Name);fflush(fplog);
						AOM_ask_value_string(qry_tag_sort[min],"t5_PlaceHolder",&SplcHolder);
						fprintf(fplog,"\n :: SplcHolder is :: %s\n",SplcHolder);fflush(fplog);
						AOM_ask_value_string(qry_tag_sort[min],"t5_PlaceHolderSuffix",&SplcHolSuf);
						fprintf(fplog,"\n :: SplcHolSuf is :: %s\n",SplcHolSuf);fflush(fplog);
						//CLRPRT_ASY_1
				//		StrSub=subString(SplcHolSuf,1,1);
				//		printf("\n :: StrSub : [%c]\n",*StrSub);fflush(stdout);
				//		IntSub[min] = *StrSub;

						}
				//		int intSuf = returnmin(IntSub,Count4);
				//		printf("\n :: intSuf is :: %d\n",intSuf);fflush(stdout);//
				//		sprintf(StrSuf, "%c",intSuf);//
				//		printf("\n :: StrSuf is :: %c\n",StrSuf);fflush(stdout);//
				//		strcpy(StrSufStr,"");
				//		strcpy(StrSufStr,"Z");
				//		strcat(StrSufStr,StrSuf);
						int NFlag =0;
						NFlag = funToGetLatClrSufData(compcodeStr,CombCompCodeArr,*suffixInt,&LtstCompCode);
						//if LtstCompCode = CCA_CENTER_AIR_VENT~CLRPRT_ASY_1
						//if NFlag ==0 then arrays are equal and return LtstCompCode value.
						//if NFlag ==1 then count are not same or arrays are not equal,
						// Increment value of color serial with ~+1 as its child color suffix having same comp code as of color scheme.

						fprintf(fplog,"\n :: LtstCompCode is :: %s\n",LtstCompCode);fflush(fplog);

						if(NFlag==0)
						{
							fprintf(fplog,"\n NFlag is: %d , so return status as arrays are equal and return LtstCompCode value.	\n");fflush(fplog);
							FunToReplaceColorSchemeData(LtstCompCode,compcodeStr);
							status=1;
							fprintf(fplog,"\n :: closed function when NFlag=0 FunToReplaceColorSchemeData with status %d \n",status);fflush(fplog);
							return status;
						}
						else if((NFlag==1) && tc_strcmp(LtstCompCode,"NOTAVAIL")==0)
						{
							// count is not equal, so add entry in fix table for new color suffix and child color suffix.
							funToEntryInFixTable(compcodeStr,CombCompCodeArr,*suffixInt,&LtstCompCode);
							StrSufStr = funToGetPlaceHolderSuffix(LtstCompCode);
							SplcHoldr = tc_strtok(LtstCompCode,"~");
							SClrID	  = tc_strtok(NULL,"");
						}
						else if(NFlag==3)
						{
							fprintf(fplog,"\n  Child BOMline does not have comp code \n");fflush(fplog);
							status=3;
							return status;
						}
						else
						{
							FunToGetNewObjName(LtstCompCode,&LtstCompCodeData);
							fprintf(fplog,"\n :: LtstCompCodeData is :: %s\n",LtstCompCodeData);fflush(fplog);
							strcpy(NewLtstCompCodeData,LtstCompCodeData);
							funToNewEntryInFixTable(NewLtstCompCodeData,CombCompCodeArr,*suffixInt,&LtstCompCode);
							fprintf(fplog,"\n ::LtstCompCodeData [%s] LtstCompCode is :: %s\n",LtstCompCodeData,LtstCompCode);fflush(fplog);
							FunToReplaceColorSchemeData(LtstCompCodeData,compcodeStr);
							//StrSufStr = FunToGetColorID(LtstCompCodeData);
							status=2;
							fprintf(fplog,"\n :: closed function FunToReplaceColorSchemeData when NFlag is other than 0,1,3 with status %d \n",status);fflush(fplog);
							//printf("\n :: _StrSufStr is :: %s  LtstCompCodeData  %s \n",StrSufStr,LtstCompCodeData);fflush(stdout);
						// if StrSufStr=ZX Decrement in place holder suffix [ex. if ZX then it should be ZW]
							//SplcHoldr = tc_strtok(LtstCompCodeData,"~");
							//SClrID	  = tc_strtok(NULL,"");
							NFlag =1;

						}
						fprintf(fplog,"\n closing function FunToEntryDataInFIXTable \n");fflush(fplog);

						// try to compare values of color suffix and its child present with comp codes only and create entries accorrdingly...

					}

					return status;
				}

				int FunToGetParentCompCode(char *sCombCompCodeClrID, char** Psuffix)
				{
					int status =0;

					tag_t   Cntl_obj_Qtag		=	NULLTAG;
					int     n_entry				=	2;
					char    *qry_sys_entry[2]	=	{"Name","Type"};
					char    **qry_sys_values    =  (char **) MEM_alloc(10 * sizeof(char *));
					int		IntCount			=	0;
					int		IsValidFlag			=	0;
					tag_t   *ChildClrSuf_tag    =	NULLTAG;

					int		n_refs				=	0;
					int		j=0,cnt=0;
					int*	levels;
					tag_t* 	referencers			=	NULLTAG;
					char ** relations			=	NULL;
					tag_t	objTypeRefTag		=	NULLTAG;
					char *sParentClrSuffix=NULL;

					char *sCompCode				=	NULL;
					char *sColorID				=	NULL;
					char *sParentClrSufName		=	NULL;
					char **sChldClrSufixvalues	=	NULL;
					*Psuffix = malloc(10*sizeof(char));
					char **sListOfChildSuffix = (char **) MEM_alloc(500 * sizeof(char *));

					fprintf(fplog,"\n ");fflush(fplog);

					ITK_CALL(QRY_find2("General...", &Cntl_obj_Qtag));
					if (Cntl_obj_Qtag)
					{
						fprintf(fplog,"\n -- Found Query General... \n");fflush(fplog);
					}
					else
					{
						fprintf(fplog,"\n Not Found Query General... \n");fflush(fplog);
					}
					fprintf(fplog,"\n sCombCompCodeClrID [%s] \n",sCombCompCodeClrID);fflush(fplog);

					qry_sys_values[0] = sCombCompCodeClrID;
					qry_sys_values[1] = "Child Color Suffix" ;
					ITK_CALL(QRY_execute(Cntl_obj_Qtag, n_entry, qry_sys_entry, qry_sys_values, &IntCount, &ChildClrSuf_tag));
					fprintf(fplog," \n "); fflush(stdout);
					if(IntCount>0)
					{
						fprintf(fplog,"IntCount: %d",IntCount);fflush(fplog);

						ITK_CALL(WSOM_where_referenced2(ChildClrSuf_tag[0],1,&n_refs,&levels,&referencers,&relations));

						int	num_values =0;
						char **	values = NULL;

						if(n_refs==1)
						{
							//object_name
							ITK_CALL(AOM_UIF_ask_value(referencers[0],"object_name",&sParentClrSufName));

							//sCompCode =	tc_strtok(sParentClrSufName,"~");
							//sColorID = tc_strtok(NULL,"~");

							fprintf(fplog,"\n sParentClrSufName [%s]\n",sParentClrSufName);fflush(fplog);
							//printf("\n sColorID [%s]\n",sColorID);fflush(stdout);

							tc_strcpy(*Psuffix,sParentClrSufName);

							// Function to find color master using color ID

						}
						else if(n_refs>1)
						{
						for (j=0;j<n_refs;j++)
						{
							ITK_CALL(TCTYPE_ask_object_type(referencers[j],&objTypeRefTag));
							ITK_CALL(TCTYPE_ask_name2(objTypeRefTag,&sParentClrSuffix));
							fprintf(fplog,"\n sParentClrSuffix :%s\n",sParentClrSuffix);fflush(fplog);
						}
						}
					}


					return status;
				}

