/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   PartList_PC.c
*  Author		 :   Sagar Baviskar
*  Module		 :   Finds parts on the basis of "Project Code" then write parts data to file.
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes

***************************************************************************/
#include <stdio.h>
#include <tc/tc.h>
#include <string.h>
#include <stdlib.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <itk/mem.h>
#include <stdlib.h>
#include <tccore/grm.h>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/tctype.h>
#include <tccore/imantype.h>
#include <tccore/workspaceobject.h>
#include <tccore/custom.h>
#include <tccore/imantype.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


int ITK_user_main(int argc,char* argv[]) // Main Function
{
   int Part_count = 0;
   int Rev_Count = 0;
   char *message;
   char *loggedInUser = NULL;
   char *PartID = NULL;
   char *PartRevID = NULL;
      
   FILE *fpPart = NULL;  
   FILE *fpQry_Result = NULL;
   int PartCount = 0;
   int	ifail=0;
   int	i=0;
   int n_entries = 1;
   int	Part_Count=0; 
   tag_t *Part_list = NULLTAG;
   tag_t *Rev_list = NULLTAG;
   tag_t *PartTag = NULLTAG;
   tag_t Req_Part_Rev = NULLTAG;
   
   char *Part_List_File = NULL;  
   char *PartType = NULL;
   tag_t PartType_tag = NULLTAG;
   tag_t QryTag = NULLTAG;
   //char	**qry_values		=	(char **) MEM_alloc(10 * sizeof(char *));

   
		
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	//ITK_CALL(ITK_set_journalling( TRUE ));
	//Auto-Logging in to TC
    status = ITK_auto_login ();

    if (status != ITK_ok ) 
	{
		EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login : \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
     }
	else
	{
		printf(" Auto login Successfully\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User is : %s\n",loggedInUser);fflush(stdout);
	}

    ITK_set_journalling (TRUE);	
	fpQry_Result=fopen("2856_Part_Count.txt","w");
	//fpPart=fopen("5442_Part_Count_Log.txt","w");  
	
	//char *qry_entries[1];
	//qry_entries[0] = "Project Code";
	//qry_values[0] = "5445";
	//tc_strcpy(qry_values[0], "5445");
	//char *qry_entries[1] = {"Project Code"};
	char *qry_entries[1] = {"t5_ProjectCode"};
	char *qry_values[1] = {"2856"};

	ITK_CALL(QRY_find("DesignRevision",&QryTag));

	if(QryTag != NULLTAG) printf("\n Query Tag Found\n");fflush(stdout);

	ITK_CALL(QRY_execute(QryTag,n_entries, qry_entries, qry_values,&Part_Count,&PartTag));
	printf("\n Part_Count(Qry Result) = %d \n",Part_Count);
	
	for(i=0;i<Part_Count;i++)
	{
		
		TCTYPE_ask_object_type(PartTag[i],&PartType_tag);fflush(stdout);
		TCTYPE_ask_name2(PartType_tag,&PartType);
		printf("\n PartType  : %s\n ",PartType);fflush(stdout);	
		
		if(PartType == NULL)
		{
		  printf("\n PartType = NULL\n");
		  continue;
		}
		if(tc_strcmp(PartType,"")==0)
		{
		  printf("\n PartType2 = NULL\n");
		  continue;
		}

		ITK_CALL(AOM_ask_value_string(PartTag[i],"item_id",&PartID));			
		ITK_CALL(AOM_ask_value_string(PartTag[i],"item_revision_id",&PartRevID));
		printf("\n Part Count [ %s / %s ] \n",PartID,PartRevID);fflush(stdout);
		
		fprintf(fpQry_Result,"Part Count for Project Code 2856 : ^%s^%s^ \n ",PartID,PartRevID);
					
	}

			 
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}




// compile PartList_PC.c
// linkitk -o 2856_PartList_PC PartList_PC.o
// 2856_PartList_PC -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba > 2856_Log.log &
// 2856_PartList_PC -u=infodba -p=APLinfo2020 -g=dba > 5724_Log.log &
// scp tcuaadev@172.22.97.90:/user/tcuaadev/devgroups/sagar/PartList_PC/2856_PartList_PC .
// 2856_PartList_PC -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba
