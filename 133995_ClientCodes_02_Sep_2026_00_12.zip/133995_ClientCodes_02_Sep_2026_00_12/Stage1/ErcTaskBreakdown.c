/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                :   Prasad Sagare
*  Module                :   This Rule handler checks the NR revision singoff check at Add item solution assignment.
*  Code                  :   erc_task_breakdown.c
*  Created on			 :   24th June 2023
*
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
*************************************************************************************/
#define TE_MAXLINELEN  128
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_date.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#define ITK_err 919002
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define Debug TRUE
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
#define ERROR_CHECK(X) if (IFERR_REPORT(X)) return (X)

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <fnd0booleansolve/booleansolve.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define PLM_error (EMH_USER_error_base+25)
#define PLM_error1 (EMH_USER_error_base+26)
//#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define PLM_error2 (EMH_USER_error_base+26)
#define PLM_error3 (EMH_USER_error_base+26)
#define PLM_error4 (EMH_USER_error_base+26)
#define PLM_error5 (EMH_USER_error_base+26)
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define Debug TRUE

int erc_task_breakdown( char * dml);
char allItemArchNode[1900] ={ 0 };

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int index = 0;
		int n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
			  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
        printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
    }
    return ITK_ok;
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}


int ITK_user_main(int argc, char *argv[])
{
	int ifail = ITK_ok;
	char * userid = NULL;
	char * password = NULL;
	char * group = NULL;
	char * dml = NULL;

	dml = ITK_ask_cli_argument("-dml=");

	ifail = ITK_auto_login();
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	printf("\nBefor erc_task_breakdown call \n\n");

	ifail = erc_task_breakdown(dml);

	printf("\nEnd of program.....!!\n\n");
	printf("\n*****************************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
void  getMonth( int m ,char cMonth[30])
{
	  if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
int days( int m, int y )
{
	   if ( m < 1 || m > 12 ) return 0;
	   switch ( m ) {
	   case 1: return 31;
	   case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
	   }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
	date_t DayTommorow ;
	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
	nm= month;
	nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
	printf( "Given date is %d:%d:%d\n", day, month, year );
	printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}
int tm_check_SOR_ERCDML_Val_control_object ( char *syscd, char *subsyscd )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
	printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
	TC_write_syslog ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	printf ("\n--------------tm_check_SOR_ERCDML_Val_control_object=Completed--------------------\n");fflush(stdout);
	return n_found ;
}
void getCurrentDateTime(char cCurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
//int erc_task_breakdown( EPM_action_message_t msg )
int erc_task_breakdown( char * dml)
{
	int ifail = 0;
	int iTsk = 0;
	int noAttachment=0,i=0, cnt=0;
	int  attype = 1,partcnt=0,k=0;
	int n_entry = 1;
	int Item_count =  0;
	int jj= 0;
	int j= 0;
	int ii =  0;
	int n_dtes = 0;
	int n_effectivities = 0;
	int count_status = 0;
	int rsltCount =  0;
	int n_tags_found2=0;

	char *job_name = NULL;
	char *job_name_new = NULL;
	char* parent_name =NULL;
	char* object_type =NULL;
	char* Analyst_name =NULL;
	char* DmlAnalyst_name =NULL;
	char* task_no =NULL;
	char* CurrentTask =NULL;
	char* TaskName =NULL;
	char* username =NULL;
	char* ImplbyTaskNo =NULL;
	char* token =NULL;
	char* Tasktoken =NULL;
	char* Part_no =NULL;
	char* ReleaseStatus =NULL;
	char* value =NULL;
	char *eff_date = NULL;
	char *ReviewStartDate=NULL;
	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char *DMLtype = NULL;
	char *info4 = NULL;
	char *info7 = NULL;
	char *cPartNo = NULL;
	char *Comobject_type = NULL;
	char *latest_rev_Rel_Stus = NULL;
	char *rev_idd = NULL;
	char *rel_status = NULL;
	char *status_name = NULL;
	char *EffvalueAfter = NULL;
	char *Effvalue = NULL;
	char *old_to_date = NULL;
	char *ObjClassName=NULL;

	tag_t parent_task =NULLTAG;
	tag_t rootTask =NULLTAG;
	tag_t *attachments =NULLTAG;
	tag_t *Taskattachments =NULLTAG;
	tag_t item =NULLTAG;
	tag_t *Dml_Task_Tag =NULLTAG;
	tag_t *objTypeTagTask = NULLTAG;
	tag_t primary =NULLTAG;
	tag_t *secondary_objects =NULLTAG;
	tag_t remove = NULLTAG;
	tag_t user_tag =NULLTAG;
	tag_t job = NULLTAG;
	tag_t Analystusertag = NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t AssyTag = NULLTAG;
	tag_t PrtTag = NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t *PartsTag= NULLTAG;
	tag_t attach = NULLTAG;
	tag_t release_status =NULLTAG;
	tag_t propEff_tag =NULLTAG;
	tag_t *rev_list = NULLTAG;
	tag_t *effectivities_tag = NULLTAG;
	tag_t *status_lst = NULLTAG;
	tag_t LpropEff_tag = NULLTAG;
	tag_t Leff_d = NULLTAG;
	tag_t *CntrlObjectTag = NULLTAG;
	tag_t qryTag = NULLTAG;
	tag_t AftpropEff_tag = NULLTAG;
	tag_t All_item_tag = NULLTAG;
	tag_t UpdateRlease_t1 = NULLTAG;
	tag_t UpdateRlease_t2 = NULLTAG;
	tag_t UpdateRlease_t3 = NULLTAG;
	tag_t *tags_found2 = NULL;
	tag_t TagClassId = NULLTAG;
	tag_t DMLToTaskReln = NULLTAG;
	tag_t eff_d = NULLTAG;
	tag_t task_tag = NULLTAG;

	date_t test_date_1;
	date_t cCurrent_date_1;
	date_t DayTommorow ;
	date_t test_date_2;
	date_t *start_end_date = NULL;
	logical  retain_released_date =TRUE;
	logical stat  ;
	date_t Ltest_date_2;
	date_t Ltest_date_1;
	date_t *Rel_start_end_values = NULL;
	date_t *Lstart_end_date = NULL;
	char *qry_entry[1] = {"SYSCD"};
	char **qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));
	WSOM_open_ended_status_t EFFECTIVITY_stock_out ;
	logical date_is_valid  ;
	logical stat1 ;
	tag_t objTypTag = NULLTAG;
	char* obj_type= NULL;
	const char *attrs2[2];
	const char *values2[2];

	ITEM_find_item(dml, &task_tag);
	ITEM_ask_latest_rev(task_tag, &DMLTag);

	printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);
	if(TCTYPE_ask_object_type(DMLTag,&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&obj_type));

	if(QRY_find2("ControlObjects", &qryTag));
	if (qryTag)
	{
		printf("\n Eff:Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n Eff:Not Found Query ControlObjects \n");fflush(stdout);
	}

	qry_values2[0] = "CREVali";
	if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
	printf(" \n Eff:rsltCount :%d:", rsltCount); fflush(stdout);
	if(rsltCount > 0)
	{
		CALLAPI(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info4));
		printf("\n Eff: info4 is  = [%s]\n", info4);fflush(stdout);

		CALLAPI(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo7",&info7));
		printf("\n Eff: info7 is  = [%s]\n", info7);fflush(stdout);
	}

	printf("\n ********** erc_task_breakdown obj type: [%s]*************\n", obj_type);fflush(stdout);

	if (tc_strcmp(obj_type,"ChangeRequestRevision")!=0)
	{
		printf("\n Passed Object is not ERC DML Revision\n");fflush(stdout);
		return 1;
	}

	if ( DMLTag != NULLTAG )
	{
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskReln));
		CALLAPI(GRM_list_secondary_objects_only(DMLTag,DMLToTaskReln,&cnt,&Dml_tasks));
	}

	CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
	CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

	if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
	{
		CALLAPI(RELSTAT_add_release_status(release_status,1,&DMLTag,retain_released_date));
	}

	if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
	{
		if(tc_strstr(info7,"CNT1") == NULL)
		{
			printf("\n ETB: Continue1");fflush(stdout);
			//continue;
		}
		else
		{
			printf("\nETB: return1\n");fflush(stdout);
			return ifail;
		}
	}

	if(POM_class_of_instance(DMLTag,&TagClassId));
	if(POM_name_of_class(TagClassId,&ObjClassName));
	printf("\n erc_breakdown---ObjClassName: %s",ObjClassName);

	if (tc_strcmp(ObjClassName,"ChangeRequestRevision")==0)
	{
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskReln));
		CALLAPI(GRM_list_secondary_objects_only(DMLTag,DMLToTaskReln,&cnt,&Dml_tasks));
	}
	printf("\n erc_breakdown---Now cnt: %d\n",cnt);fflush(stdout);

	if (cnt>0)
	{
		for (iTsk=0;iTsk<cnt ;iTsk++ )
		//while (i<cnt)
		{
			i++;
			CALLAPI(AOM_ask_value_string(Dml_tasks[iTsk],"object_type",&object_type));
			printf("\n erc_breakdown---[i= %d]: object_type is :%s  \n",i,object_type);fflush(stdout);

			CALLAPI(AOM_ask_value_string(Dml_tasks[iTsk],"item_id",&task_no));
			printf("\n erc_breakdown---task_no is :%s  \n",task_no);fflush(stdout);

			if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
			{
				getCurrentDateTime(cCurrentAccessDate);
				printf("\n erc_breakdown---cCurrentAccessDate : %s\n",cCurrentAccessDate);

				CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
				CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

				if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0  )
				{
					CALLAPI(RELSTAT_add_release_status(release_status,1,&Dml_tasks[iTsk],retain_released_date));
				}
				if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[iTsk], 0 )))
				{
					if(tc_strstr(info7,"CNT1") == NULL)
					{
						printf("\n erc_breakdown---ETB: Continue2");fflush(stdout);
						continue;
					}
					else
					{
						printf("\n erc_breakdown---ETB: return2");fflush(stdout);
						return ifail;
					}
				}

				CALLAPI(AOM_UIF_ask_value(Dml_tasks[iTsk],"Analyst",&DmlAnalyst_name));
				printf("\nerc_breakdown---Dml Task Analyst_name:%s ",DmlAnalyst_name);fflush(stdout);

				CALLAPI(AOM_ask_value_tags(Dml_tasks[iTsk],"CMHasSolutionItem",&partcnt,&PartsTag));
				printf("\n erc_breakdown---Now partcnt:%d ",partcnt);fflush(stdout);

				if (partcnt>0)
				{
					for (k=0;k<partcnt ;k++ )
					{
						printf("\n erc_breakdown---for k= %d ",k);fflush(stdout);
						AssyTag=PartsTag[k];

						CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
						CALLAPI(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype));
						printf("\n erc_breakdown--- [k=%d ]Part_no:[%s] DMLType:[%s] DMLtaskno:[%s]",k,Part_no,DMLtype,task_no);fflush(stdout);

						printf("\n erc_breakdown---In If Condn--info4 is  = [%s] ", info4);fflush(stdout);

						if(tc_strstr(info4,"EFFECTIVITY") == NULL)
						{
							int status_count=0;
							int ss=0;
							int ERCStatusFlg=0;
							int ERCReviewStatusFlg=0;
							tag_t* relStatus_list;
							int ERCRelFlag=0;

							getCurrentDateTime(cCurrentAccessDate);
							printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
							if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue3");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return3");fflush(stdout);
									return ifail;
								}
							}

							if((strcmp(DMLtype,"Veh")==0)||(strcmp(DMLtype,"MR")==0)||(strcmp(DMLtype,"DFMR")==0)||(strcmp(DMLtype,"EP")==0)||(strcmp(DMLtype,"CP")==0)||(strcmp(DMLtype,"CM")==0)||(strcmp(DMLtype,"EIDL")==0)||(strcmp(DMLtype,"VPL")==0))
							{
								printf("\n erc_breakdown---Eff:Setting effectivity on latest released revision!!\n");fflush(stdout);
								CALLAPI(AOM_UIF_ask_value (AssyTag, "item_id", &cPartNo));

								CALLAPI(WSOM_ask_release_status_list(AssyTag, &status_count, &relStatus_list));	//Added by RRR on 02.10.2018
								if (status_count > 0)
								{
									for(ss=0; ss<status_count ; ss++)
									{
										CALLAPI(AOM_ask_value_string(relStatus_list[ss],"object_name",&latest_rev_Rel_Stus));
										printf("\n erc_breakdown---latest_rev_Rel_Stus: %s",latest_rev_Rel_Stus);fflush(stdout);

										if((strcmp(latest_rev_Rel_Stus,"ERC Review")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsReview")==0))
										{
											ERCReviewStatusFlg ++;

											//if(ITK_ok != (ifail = PROP_ask_property_by_name(relStatus_list[ss],"effectivity_text",&propEff_tag)))	 return ifail;
											CALLAPI(AOM_UIF_ask_name(relStatus_list[ss],"effectivity_text",&value));
											//if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
											//CALLAPI(PROP_ask_value_string(propEff_tag,&value));
											printf("\n erc_breakdown---erc_breakdown---ERCReview--effectivity_text is value : %s",value); fflush(stdout);

											printf("\n erc_breakdown---ERCReview--effectivity_text is length : %d",strlen(value)); fflush(stdout);

											if(tc_strlen(value) == 0)
											{
												if( AOM_UIF_ask_value (AssyTag, "creation_date", &value)!=ITK_ok);  //rev_CreDt
												printf("\nERCReview--creation_date----value:::: [%s]", value);fflush(stdout);
											}
											printf("\nerc_breakdown---ERCReview--StartDate: [%s]   EndDate:[%s]", value,cCurrentAccessDate);fflush(stdout);
											if(tc_strlen(value) == 0)
											{
												printf("  --Skipping from ERC Review validation as blank.....\n");fflush(stdout);
												continue;  // skipping this case if value found NULL/Blank
											}
											else
											{
												ReviewStartDate=subString(value,0,17);
												printf("\n ERCReview--ReviewStartDate: %s",ReviewStartDate); fflush(stdout);

												if(ITK_ok != (ifail = DATE_string_to_date_t(ReviewStartDate, &date_is_valid,&Ltest_date_1 )))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue4");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return4");fflush(stdout);
														return ifail;
													}
												}

												Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
												Lstart_end_date[0] = Ltest_date_1;
												Lstart_end_date[1] = Ltest_date_2;

												printf("\n ERCReview--EFF:Clearing effectivities...");fflush(stdout);
												if(ITK_ok != (ifail = WSOM_status_clear_effectivities (relStatus_list[ss])))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue5");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return5");fflush(stdout);
														return ifail;
													}
												}

												printf("\n ERCReview--EFF:Creating effectivities...");fflush(stdout);
												if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(relStatus_list[ss], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue6");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return6");fflush(stdout);
														return ifail;
													}
												}
												printf("\n ERCReview--EFF:Saving effectivities...");fflush(stdout);
												if(ITK_ok != (ifail = AOM_save_without_extensions(Leff_d)))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue7");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return7");fflush(stdout);
														return ifail;
													}
												}
												printf("\n ERCReview--EFF:Saving Revision...");fflush(stdout);
												if(ITK_ok != (ifail = AOM_save_without_extensions(relStatus_list[ss])))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue8");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return8");fflush(stdout);
														return ifail;
													}
												}
												printf("\n ERCReview--EFF:Refreshing Revision...");fflush(stdout);
												if(ITK_ok != (ifail = AOM_refresh( relStatus_list[ss], 0 )))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue9");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return9");fflush(stdout);
														return ifail;
													}
												}
											}
										}

										if((strcmp(latest_rev_Rel_Stus,"ERC Released")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsErcRlzd")==0))
										{
										   ERCStatusFlg ++;
										}
									}
								}

								printf("\n Eff:Part no:[%s]  latest_rev_Rel_Stus:[%s]  ERCStatusFlg: [%d] ",cPartNo,latest_rev_Rel_Stus,ERCStatusFlg);fflush(stdout);

								if ((tc_strstr(latest_rev_Rel_Stus, "ERC Released") == NULL) && (ERCStatusFlg == 0)) //Added by RRR on 02.10.2018
								{
									CALLAPI(AOM_UIF_ask_value (AssyTag, "object_type", &Comobject_type));//Added for EE_Part(kalpesh_14_sept19)
									printf("\n Comobject_type found:%s cPartNo: %s ", Comobject_type,cPartNo);fflush(stdout);

									attrs2[0] ="item_id";
									attrs2[1] ="object_type";
									values2[0] = (char *)cPartNo;
									if(tc_strcmp(Comobject_type, "EE Part Revision") == 0)
									{
										values2[1] = "T5_EE_Part";
									}else if (tc_strcmp(Comobject_type, "Colour Part Revision") == 0)
									{
										values2[1] = "T5_ClrPart";
									}else
									{
										values2[1] = "Design";
									}
									CALLAPI(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
									printf("\n n_tags_found2: %d", n_tags_found2);fflush(stdout);


									if (n_tags_found2>0)
									{
										All_item_tag= tags_found2[0];

										CALLAPI(ITEM_list_all_revs (All_item_tag, &Item_count, &rev_list));
										printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
									}

									if(Item_count > 0)
									{
										for(ii=Item_count-1;ii>=0;ii--)
										{
											CALLAPI(AOM_UIF_ask_value (rev_list[ii], "item_revision_id", &rev_idd));
											printf("\n Eff: Latest released rev is:%s.", rev_idd);fflush(stdout);

											CALLAPI(WSOM_ask_release_status_list (rev_list[ii], &count_status, &status_lst));
											printf("\n Eff: count_status is:%d.", count_status);fflush(stdout);
											if(count_status > 0)
											{
												for(j=0;j<count_status;j++)
												{
													ERCRelFlag=0;
													CALLAPI(AOM_ask_value_string (status_lst[j], "object_name", &status_name));
													printf("\n Eff: Release Status name:%s", status_name);fflush(stdout);
													if((tc_strstr(status_name,"ERC Released")!=NULL) ||tc_strstr(status_name,"T5_LcsErcRlzd")!=NULL)
													{
														printf("\n Eff:Status name:%s for rev:%s\n", status_name, rev_idd);
														if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat1)))	 return ifail;
														printf("\n Eff:stat1:%d",stat1);fflush(stdout);

														if(stat1 != true)
														{
															printf("\n Eff:stat1 is not true .....");fflush(stdout);
														}
														else
														{
															printf("\n Eff:stat1 is  true .....");fflush(stdout);
														}

														//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&LpropEff_tag))) return ifail;
														//if(ITK_ok != (ifail = PROP_ask_value_string(LpropEff_tag,&Effvalue)))	 return ifail;
														if(ITK_ok != (ifail = AOM_UIF_ask_name(status_lst[j],"effectivity_text",&Effvalue))) return ifail;
														printf("\n Eff:effectivity_text Effvalue..: %s",Effvalue);fflush(stdout);

														if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_lst[j],&n_effectivities, &effectivities_tag) )) return ifail;
														printf("\n Eff:n_effectivities count:[%d] ",n_effectivities);fflush(stdout);
														if(n_effectivities > 0)
														{
															for(jj=0;jj<n_effectivities;jj++)
															{
																if(ITK_ok != (ifail = WSOM_eff_ask_dates(status_lst[j],effectivities_tag[jj],&n_dtes,&Rel_start_end_values,&EFFECTIVITY_stock_out )))return ifail;
																printf("\n Eff:no of Rel_start_end_value:%d", n_dtes);fflush(stdout);
																if(n_dtes > 0)
																{
																	if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
																	{
																		if(tc_strstr(info7,"CNT1") == NULL)
																		{
																			printf("\n erc_breakdown---ETB: Continue10");fflush(stdout);
																			continue;
																		}
																		else
																		{
																			printf("\n erc_breakdown---ETB: return10");fflush(stdout);
																			return ifail;
																		}
																	}
																	printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
																	if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
																	{
																		if(tc_strstr(info7,"CNT1") == NULL)
																		{
																			printf("\n erc_breakdown---ETB: Continue11");fflush(stdout);
																			continue;
																		}
																		else
																		{
																			printf("\n erc_breakdown---ETB: return11");fflush(stdout);
																			return ifail;
																		}
																	}
																	printf(" and  DATE_string_to_date_t..");fflush(stdout);
																	if(date_is_valid != true)
																	{
																		printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
																	}
																	else
																	{
																		printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
																	}
																}
																else
																{
																	printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
																}
															}
														}

														printf("\n EFF:ITK_string_to_date..2");fflush(stdout);
														Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
														Lstart_end_date[0] = Ltest_date_1;
														Lstart_end_date[1] = Ltest_date_2;

														printf("\n EFF:Clearing effectivities...");fflush(stdout);

														if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_lst[j])))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue12");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return12");fflush(stdout);
																return ifail;
															}
														}
														printf("\n EFF:Creating effectivities...");fflush(stdout);
														if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_lst[j], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue13");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return13");fflush(stdout);
																return ifail;
															}
														}
														printf("\n EFF:Saving effectivities...");fflush(stdout);
														if(ITK_ok != (ifail = AOM_save_without_extensions(Leff_d)))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue14");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return14");fflush(stdout);
																return ifail;
															}
														}
														printf("\n EFF:Saving Revision...");fflush(stdout);
														if(ITK_ok != (ifail = AOM_save_without_extensions(status_lst[j])))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue15");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return15");fflush(stdout);
																return ifail;
															}
														}
														printf("\n EFF:Refreshing Revision...");fflush(stdout);
														if(ITK_ok != (ifail = AOM_refresh( status_lst[j], 0 )))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue16");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return16");fflush(stdout);
																return ifail;
															}
														}
														printf("\n EFF:Checking effectivities txt...");fflush(stdout);
														//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&AftpropEff_tag)))return ifail;
														//if(ITK_ok != (ifail = PROP_ask_value_string(AftpropEff_tag,&EffvalueAfter)))return ifail;
														if(ITK_ok != (ifail = AOM_UIF_ask_name(status_lst[j],"effectivity_text",&EffvalueAfter)))return ifail;
														printf("\n Eff:effectivity_text EffvalueAfter : %s ",EffvalueAfter);fflush(stdout);
														if(ITK_ok != (ifail = AOM_refresh( rev_list[ii], 0 )))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue17");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return17");fflush(stdout);
																return ifail;
															}
														}

														ERCRelFlag=1;

														break;  //Added on 19.10.2018 for multiple release status
													}
													else
													{
														printf("\n Eff: Status name:%s for rev: %s ", status_name, rev_idd); fflush(stdout);
													}
													MEM_free(status_name);
												}
											}
											else
											{
												printf("\n Eff:Status not found on revision %s...!!",rev_idd);fflush(stdout);
											}

											if (ERCRelFlag>0)
											{
												break;
											}
										}
									}
								}
								else
								{
									printf("\n EFF:part already released.");fflush(stdout);
								}
							}
						}
						//PSS918119 - Release stamping on BVR

						int bvr_count = 0;
						int count = 0;
						char *NameOfObjTyp = NULL;
						char *NameOfbvrObjTyp = NULL;
						char *ReleaseStatusBVR = NULL;
						char *ReleaseStatusBVR1 = NULL;
						tag_t bvrsTypeTag = NULLTAG;
						tag_t *bvrs = NULLTAG;
						tag_t release_statusBVR = NULLTAG;
						tag_t release_statusBVR1 = NULLTAG;
						tag_t *secObjsList = NULLTAG;
						tag_t Tag_Name = NULLTAG;
						tag_t objNameType = NULLTAG;

						if(ITEM_rev_list_bom_view_revs( AssyTag, &bvr_count, &bvrs));
						printf("\n BVR Obj Count is---[%d]", bvr_count);
						if (bvr_count > 0)
						{
							for(ii=0;ii<bvr_count;ii++)
							{
								printf("\nFor Loop started");fflush(stdout);
								TCTYPE_ask_object_type(bvrs[ii] , &bvrsTypeTag);
								TCTYPE_ask_name2(bvrsTypeTag,&NameOfbvrObjTyp);
								printf("\nObject Type of Found is %s ",NameOfbvrObjTyp);fflush(stdout);
								ifail =(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_statusBVR));
								ifail =( AOM_ask_name(release_statusBVR, &ReleaseStatusBVR));
								if((strcmp(ReleaseStatusBVR,"ERC Released")==0)||strcmp(ReleaseStatusBVR,"T5_LcsErcRlzd")==0 )
								{
									RELSTAT_add_release_status(release_statusBVR,1,&bvrs[ii],retain_released_date);
									printf("\nRelease stamping marked on BVR Object:: [%s]\n",NameOfbvrObjTyp);fflush(stdout);
								}
							}
						}
						else
						{
							printf("\nBOM View Rev not found for the Item  [%s], task no [%s] \n",Part_no,task_no);fflush(stdout);
						}

						ifail = GRM_list_secondary_objects_only(AssyTag, NULLTAG, &count, &secObjsList);
						printf("\n secObjCnt---[%d]\n", count);fflush(stdout);

						if (count > 0)
						{
							for (i=0; i<count;i++ )
							{
								Tag_Name= secObjsList[i];
								TCTYPE_ask_object_type(Tag_Name,&objNameType);
								if(objNameType != NULLTAG)
								{
									TCTYPE_ask_name2(objNameType,&NameOfObjTyp);
									printf("\n[%d]Sec Object Type is %s \n",i,NameOfObjTyp);fflush(stdout);
									if ((tc_strcmp(NameOfObjTyp,"CMI2Product")==0) ||(tc_strcmp(NameOfObjTyp,"CMI2Part")==0)||(tc_strcmp(NameOfObjTyp,"CMI2Drawing")==0)||(tc_strcmp(NameOfObjTyp,"DirectModel")==0)||(tc_strcmp(NameOfObjTyp,"ProAsm")==0)||
											(tc_strcmp(NameOfObjTyp,"ProPrt")==0)||(tc_strcmp(NameOfObjTyp,"ProDrw")==0)||(tc_strcmp(NameOfObjTyp,"PDF")==0))
									{
										printf("\n Found Sec obj is of type ::[%s]\n", NameOfObjTyp);fflush(stdout);
										ifail =(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_statusBVR1));
										ifail =( AOM_ask_name(release_statusBVR1, &ReleaseStatusBVR1));
										if((strcmp(ReleaseStatusBVR1,"ERC Released")==0)||strcmp(ReleaseStatusBVR1,"T5_LcsErcRlzd")==0 )
										{
											ifail =(RELSTAT_add_release_status(release_statusBVR1,1,&Tag_Name,retain_released_date));
											printf("\n Release staming done on Sec Object type ::[%s]\n", NameOfObjTyp);fflush(stdout);
										}
									}
								}
							}
						}

						/********SOR Release Status stamping*******/
						int SOR_ERCDML_Val = 0;

						SOR_ERCDML_Val = tm_check_SOR_ERCDML_Val_control_object ( "SORERCDMLVAL" , "ON" );

						if ( SOR_ERCDML_Val > 0)
						{
							printf("\n erc_breakdown--A-SOR Release Status stamping");fflush(stdout);
							TC_write_syslog("\n erc_breakdown--A-SOR Release Status stamping");fflush(stdout);

							int status_part_SOR_cnt = 0;
							int status_prt_c = 0;

							char *status_part_SOR_num = NULL;
							char *status_rel_part_SOR = NULL;
							char *SOR_numbers = NULL;
							logical  retain_released_date_SOR = TRUE;

							tag_t status_Part_SOR_Tag = NULLTAG;
							tag_t status_part_SOR_Rel = NULLTAG;
							tag_t *status_part_SOR_objects = NULLTAG;
							tag_t status_rel_SOR = NULLTAG;
							tag_t release_status_SOR = NULLTAG;

							ITK_CALL(GRM_find_relation_type("T5_PartSorRel",&status_part_SOR_Rel));
							printf("\n erc_breakdown--A-Expanding Part to SOR relation");fflush(stdout);
							TC_write_syslog("\nExpanding Part to SOR relation");fflush(stdout);
							ITK_CALL(GRM_list_secondary_objects_only(AssyTag, status_part_SOR_Rel, &status_part_SOR_cnt, &status_part_SOR_objects));
							printf("\n erc_breakdown--A-status_part_SOR_cnt : [%d]\n",status_part_SOR_cnt);fflush(stdout);
							TC_write_syslog("\nstatus_part_SOR_cnt : [%d]\n",status_part_SOR_cnt);fflush(stdout);

							if ( status_part_SOR_cnt > 0)
							{
								for ( status_prt_c = 0; status_prt_c < status_part_SOR_cnt; status_prt_c++ )
								{
									status_Part_SOR_Tag= status_part_SOR_objects[status_prt_c];
									ITK_CALL(AOM_UIF_ask_value(status_Part_SOR_Tag,"item_id",&status_part_SOR_num));
									ITK_CALL(AOM_UIF_ask_value(status_Part_SOR_Tag,"release_status_list",&status_rel_part_SOR));
									printf("\nstatus_part_SOR_num : [%s]\tstatus_rel_part_SOR : [%s]",status_part_SOR_num,status_rel_part_SOR);fflush(stdout);
									TC_write_syslog("\nstatus_part_SOR_num : [%s]\tstatus_rel_part_SOR : [%s]",status_part_SOR_num,status_rel_part_SOR);fflush(stdout);
									printf("\n erc_breakdown--A-status_rel_part_SOR : [%s]\n", status_rel_part_SOR);fflush(stdout);
									TC_write_syslog("\n erc_breakdown--A-status_rel_part_SOR : [%s]\n", status_rel_part_SOR);fflush(stdout);

									if((tc_strcmp ( status_rel_part_SOR,"ERC Review" )==0) || (tc_strcmp( status_rel_part_SOR,"T5_LcsReview" )==0) )
									{
										ITK_CALL (RELSTAT_create_release_status("T5_LcsErcRlzd",&status_rel_SOR));
										ITK_CALL(RELSTAT_add_release_status(status_rel_SOR,1,&status_Part_SOR_Tag ,retain_released_date_SOR));
										printf("\n erc_breakdown--A-ERC released stamping on SOR : [%s]\n", status_part_SOR_num);fflush(stdout);
										TC_write_syslog("\n erc_breakdown--A-ERC released stamping on SOR : [%s]\n", status_part_SOR_num);fflush(stdout);

									}
								}
							}
						}
						// Adi add 4D Doc rel status START here 2021

						tag_t RelationFind4D = NULLTAG;
						tag_t RelationFindDfmea = NULLTAG;
						tag_t relationTag4D = NULLTAG;
						tag_t relationTagDfmea = NULLTAG;
						int sec_count4D = 0;
						int sec_countDfmea = 0;
						int iQ = 0;
						int dQ = 0;
						tag_t *sec_objects = NULLTAG;
						tag_t *sec_objectsDfmea = NULLTAG;
						logical retain_released_date4D = TRUE;
						logical retain_released_dateDfmea = TRUE;
						tag_t release_status4D = NULLTAG;
						tag_t release_statusDfmea = NULLTAG;
						tag_t status_rel4D = NULLTAG;
						tag_t status_relDfmea = NULLTAG;
						char* ReleaseStatus4D = NULL;
						char* ReleaseStatusDfmea = NULL;

						if(GRM_find_relation_type("T5_PartHas4D",&RelationFind4D));
						if (RelationFind4D!=NULLTAG)
						{
							printf("\n erc_breakdown--A-Inside for 4D After finding RelType ");fflush(stdout);
							CALLAPI(GRM_list_secondary_objects_only(AssyTag, RelationFind4D, &sec_count4D, &sec_objects));
							printf("\n erc_breakdown--A-for 4D Total objects found sec_count4D------[%d]", sec_count4D);

							if(sec_count4D > 0)
							{
								printf("\n erc_breakdown--A-inside sec_count4D find  --------- [%d]", sec_count4D);fflush(stdout);
								for(iQ=0;iQ<sec_count4D;iQ++)
								{
									relationTag4D=sec_objects[iQ];
									printf("\n erc_breakdown--A-inside sec count find IQ---------");fflush(stdout);

									if (relationTag4D != NULLTAG)
									{
										CALLAPI(RELSTAT_create_release_status("T5_LcsReview",&release_status4D));
										CALLAPI( AOM_ask_name(release_status4D, &ReleaseStatus4D));
										printf("\n erc_breakdown--A-ReleaseStatus4D ----------[%s]", ReleaseStatus4D);fflush(stdout);

										if((strcmp(ReleaseStatus4D,"ERC Review")==0)||strcmp(ReleaseStatus4D,"T5_LcsReview")==0 )
										{
											printf("\n erc_breakdown--A-BEFORE epm add rel status ERC released ");fflush(stdout);
											printf("\n erc_breakdown--A-before removing all rel status ---------");fflush(stdout);
											//t5removeAllReleaseStatus(relationTag4D);
											CALLAPI (RELSTAT_create_release_status("T5_LcsErcRlzd",&status_rel4D));
											CALLAPI(RELSTAT_add_release_status(status_rel4D,1,&relationTag4D,retain_released_date4D));

											printf("\n erc_breakdown--A-after adding rel status ERC Released 4d return 0---------");fflush(stdout);
										}
									}
								}
							}
						}

						if(GRM_find_relation_type("T5_PartHasDfmea",&RelationFindDfmea));
						if (RelationFindDfmea!=NULLTAG)
						{
							printf("\n erc_breakdown--B-Inside for 4D After finding RelType ");fflush(stdout);
							CALLAPI(GRM_list_secondary_objects_only(AssyTag, RelationFindDfmea, &sec_countDfmea, &sec_objectsDfmea));
							printf("\n erc_breakdown--B-for 4D Total objects found------[%d] ", sec_countDfmea);
							if(sec_countDfmea > 0)
							{
								printf("\n erc_breakdown--B-inside sec_countDfmea find  --------- [%d]", sec_countDfmea);fflush(stdout);
								for(dQ=0;dQ<sec_countDfmea;dQ++)
								{
									relationTagDfmea=sec_objectsDfmea[dQ];
									printf("\n erc_breakdown--B-inside sec count find dQ--------");fflush(stdout);

									if (relationTagDfmea != NULLTAG)
									{
										CALLAPI(RELSTAT_create_release_status("T5_LcsReview",&release_statusDfmea));
										CALLAPI( AOM_ask_name(release_statusDfmea, &ReleaseStatusDfmea));
										printf("\n erc_breakdown--B-ReleaseStatusDfmea ----------[%s] ", ReleaseStatusDfmea);fflush(stdout);

										if((strcmp(ReleaseStatusDfmea,"ERC Review")==0)||strcmp(ReleaseStatusDfmea,"T5_LcsReview")==0 )
										{
											printf("\n erc_breakdown--B-BEFORE epm add rel status ERC released ");fflush(stdout);
											printf("\n erc_breakdown--B-before removing all rel status -------");fflush(stdout);
											//t5removeAllReleaseStatus(relationTagDfmea);
											CALLAPI (RELSTAT_create_release_status("T5_LcsErcRlzd",&status_relDfmea));
											CALLAPI(RELSTAT_add_release_status(status_relDfmea,1,&relationTagDfmea,retain_released_dateDfmea));

											printf("\n erc_breakdown--B-after adding rel status ERC Released 4d return 0---");fflush(stdout);
										}
									}
								}
							}
						}

						// Adi add 4D Doc rel status END HERE 2021
						CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
						CALLAPI( AOM_ask_name(release_status, &ReleaseStatus));

						if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
						{
							CALLAPI(RELSTAT_add_release_status(release_status,1,&AssyTag,retain_released_date));
						}
						printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);

						if((strcmp(ReleaseStatus,"ERC Released")==0) ||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0)
						{
							if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat))) return ifail;
							printf("\n stat:%d\n",stat);fflush(stdout);

							if(stat != true)
							{
								printf("\n stat is not true .....\n");fflush(stdout);
							}
							else
							{
								printf("\n stat is  true .....\n");fflush(stdout);
							}

							getCurrentDateTime(cCurrentAccessDate);
							//if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))	 return ifail;
							//if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value))) return ifail;
							if(ITK_ok != (ifail = AOM_UIF_ask_name(release_status,"effectivity_text",&value)))	 return ifail;
							printf("\n effectivity_text is value : %s\n",value);fflush(stdout);

							getNextDate(cNextDate);
							printf("\n cNextDate:%s",cNextDate);fflush(stdout);

							if(ITK_ok != (ifail = ITK_string_to_date(cNextDate, &test_date_1 )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue18");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return18");fflush(stdout);
									return ifail;
								}
							}
							if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue19");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown--ETB: return19");fflush(stdout);
									return ifail;
								}
							}
							start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

							printf( "\n erc_breakdown--Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");
							fflush(stdout);

							start_end_date[0] = test_date_1;
							start_end_date[1] = test_date_2;

							if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( release_status)))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue20");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return20");fflush(stdout);
									return ifail;
								}
							}
							if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue21");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return21");fflush(stdout);
									return ifail;
								}
							}

							if(ITK_ok != (ifail = AOM_save_without_extensions(eff_d)))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue22");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return22");fflush(stdout);
									return ifail;
								}
							}

							if(ITK_ok != (ifail = AOM_save_without_extensions(release_status)))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue23");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return23");fflush(stdout);
									return ifail;
								}
							}
							if(ITK_ok != (ifail = AOM_refresh( release_status, 0 )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue24");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return24");fflush(stdout);
									return ifail;
								}
							}

							//if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))return ifail;
							//if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))return ifail;
							
							if(ITK_ok != (ifail = AOM_UIF_ask_name(release_status,"effectivity_text",&value)))return ifail;
							printf("\n After setting effectivity_text value : %s\n",value);
							if(ITK_ok != (ifail = AOM_refresh( AssyTag, 0 )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue25");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return25");fflush(stdout);
									return ifail;
								}
							}
							else
							{
								printf("\nerc_breakdown---AOM_refresh sucessful");fflush(stdout);
							}
						}
						printf("\nerc_breakdown---Outside the ERC Release stamping check.");fflush(stdout);
					}
					printf("\n erc_breakdown---outside the Release stamping of task [%s] ",task_no);fflush(stdout);
				} //End of if (partcnt>0)
				printf("\n erc_breakdown---outside the part count > 0 loop for task [%s] ",task_no);fflush(stdout);
			}
		}
		printf("\n erc_breakdown---After the end of for loop of task ");fflush(stdout);

	} //End of DML Task Cnt if (cnt>0)

	printf ("\n--------------erc_task_breakdown=Completed---------------------------------------------------------------------\n");
	fflush(stdout);

	return ITK_ok;
}