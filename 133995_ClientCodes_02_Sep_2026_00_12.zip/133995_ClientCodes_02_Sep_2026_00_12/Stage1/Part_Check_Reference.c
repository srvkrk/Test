#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <tc/folder.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <ict/ict_userservice.h>

#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <time.h>

#include <sa/sa.h>
#include <sa/tcfile_cache.h>
#define PLM_error6 (EMH_USER_error_base+26)
#define ITK_err (EMH_USER_error_base + 2)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
;
char *substring(char *string, int position, int length)
{
   char *pointer;
   int c;

   pointer = malloc(length+1);

   if (pointer == NULL)
   {
      printf("Unable to allocate memory.\n");
      exit(1);
   }

   for (c = 0 ; c < length ; c++)
   {
      *(pointer+c) = *(string+position-1);
      string++;
   }

   *(pointer+c) = '\0';

   return pointer;
}

 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_ask_error_text(return_code,&error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}


int	 ifail 	=  ITK_ok;


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int Part_check_reference(char* dmlno)
{

	tag_t	idtag					= NULLTAG;
	tag_t	itemtag					= NULLTAG;
	tag_t   rev						= NULLTAG;
	tag_t   obj						= NULLTAG;
	tag_t   Pobj					= NULLTAG;
	tag_t   revtag					= NULLTAG;
	tag_t   RevTag					= NULLTAG;
	tag_t	TskTypeTag				= NULLTAG;
	tag_t   relation_type			= NULLTAG;
	tag_t   relation_tp				= NULLTAG;
	tag_t   relation_t				= NULLTAG;
	tag_t   relation_task			= NULLTAG;
	tag_t   task_tag				= NULLTAG;
	tag_t   Part_tag				= NULLTAG;
	tag_t   Dataset_tag				= NULLTAG;
	tag_t   Part_tag1				= NULLTAG;
	tag_t   qry_tg					= NULLTAG;
	tag_t   Namereferancetag		= NULLTAG;
	tag_t   latestRlzRevTag			= NULLTAG;
	tag_t   refobjectAttach			= NULLTAG;
	tag_t   latestNamereferancetag			= NULLTAG;
	tag_t   refrelation_t			= NULLTAG;
	tag_t   newrefsecondary_P			= NULLTAG;
	tag_t   newoldNmdref_object			= NULLTAG;

	tag_t   *secondary_task		 = NULLTAG;
	tag_t   *part_Rev			 = NULLTAG;
	tag_t   *secondary_objects	 = NULLTAG;
	tag_t   *secondary_P		 = NULLTAG;
	tag_t   *parents			 = NULLTAG;
	tag_t   *DataObj			 = NULLTAG;
	tag_t   *rel_status_lst		 = NULLTAG;
	tag_t   *latestTag			 = NULLTAG;
	tag_t   *Nmdref_object		 = NULLTAG;
	tag_t   *refsecondary_P		 = NULLTAG;
	tag_t   *rendsecondary_P		 = NULLTAG;
	tag_t   *Rendsecondary		 = NULLTAG;
	tag_t   oldNmdref_object		 = NULLTAG;
	tag_t   Primarypdf_relation		 = NULLTAG;
	tag_t   old_relation		 = NULLTAG;
	tag_t   new_relation		 = NULLTAG;
	tag_t   rendrelation_t		 = NULLTAG;
	tag_t   relationrend		 = NULLTAG;



	char* ObjType			= NULL;
	char* partType			= NULL;
	char* ObjType1			= NULL;
	char* ObjName			= NULL;
	char* partName			= NULL;
	char* ObjTag			= NULL;
	char* ObjStatus			= NULL;
	char* latest			= NULL;
	char* DataRevName		= NULL;
	char* ObjT				= NULL;
	char* ObjN				= NULL;
	char* ObjName1			= NULL;
	char* Chld_Rel_Stus1	= NULL;
	char* QXPartNum			= NULL;
	char* QXPartNumDup		= NULL;
	char* FileStr			= NULL;
	char* pdfpath			= NULL;
	char* refObjT			= NULL;
	char* refObjname			= NULL;
	char* creObjT			= NULL;
	char* ProcreObjT			= NULL;
	char* latObjTag			= NULL;
	char* Specname			= NULL;


	int ParentCount		  = 0;
	int count			  = 0;
	int count_T			  = 0;
	int count_P			  = 0;
	int CountQ			  = 0;
	int count_K			  = 0;
	int count_O			  = 0;
	int i				  = 0;
	int j				  = 0;
	int g				  = 0;
	int p				  = 0;
	int k				  = 0;
	int c				  = 0;
	int A				  = 0;
	int B				  = 0;
	int s				  = 0;
	int latestRlzRevFlag  = 0;
	int latestRevFlag	  = 0;
	int rel_status_cunt	  = 0;
	int relcount		  = 0;
	int refnumfnd		  = 0;
	int NmdrefFound		  = 0;
	int jA				  = 0;
	int m				  = 0;
	int n				  = 0;
	int o				  = 0;
	int q				  = 0;
	int r				  = 0;
	int t				  = 0;
	int v				  = 0;
	int u				  = 0;
	int l				  = 0;
	int refcount_P				  = 0;
	int oldNmdrefFound				  = 0;
	int creFlag				  = 0;
	int Rendcount				  = 0;
	int rendcount_P				  = 0;

	int pdfc              = 1;

	char**  entry   = (char **)  MEM_alloc(30 * sizeof(char *));
	char** Value   = (char **) MEM_alloc(50 * sizeof(char *));
	char * path    = (char *)  MEM_alloc(sizeof(char)* 100);


	AE_reference_type_t     reftypeAttach;
	FileStr  =  MEM_alloc(1000);

	ifail=ITEM_find_item(dmlno,&idtag);      //finding DML
	ifail=ITEM_ask_latest_rev(idtag,&rev);

	ifail=GRM_find_relation_type("T5_DMLTaskRelation",&relation_task );//CMHasSolutionItem
	ifail=GRM_list_secondary_objects_only(rev,relation_task,&count,&secondary_task);
	printf("\n rev: count:%d", count);fflush(stdout);

	for (i=0; i< count; i++)
	{
		task_tag=secondary_task[i];
		if(AOM_ask_value_string(task_tag,"object_type",&ObjType)!=ITK_ok)PrintErrorStack();
		printf("\n :object_type : %s\n ",ObjType);fflush(stdout);

		if(AOM_ask_value_string(task_tag,"object_string",&ObjName)!=ITK_ok)PrintErrorStack();
		printf("\n :object_string : %s\n ",ObjName);fflush(stdout);

		ifail=GRM_find_relation_type("CMHasSolutionItem",&relation_type );//CMHasSolutionItem
		ifail=GRM_list_secondary_objects_only(task_tag,relation_type,&count_T,&secondary_objects);
		printf("\n rev: count_T  is :%d", count_T);fflush(stdout);

		for (j=0; j< count_T; j++)
		{
			Part_tag=secondary_objects[j];
			if(AOM_ask_value_string(Part_tag,"object_type",&partType)!=ITK_ok)PrintErrorStack();
			printf("\n :object_type : %s\n ",partType);fflush(stdout);

			if(AOM_ask_value_string(Part_tag,"object_string",&partName)!=ITK_ok)PrintErrorStack();
			printf("\n :object_string : %s\n ",partName);fflush(stdout);

			//GRM_list_secondary_objects_only

			ifail=GRM_find_relation_type("IMAN_specification",&relation_t );
			ifail=GRM_list_secondary_objects_only(Part_tag,relation_t,&count_P,&secondary_P);
			printf("\n rev: count_P:%d", count_P);fflush(stdout);


            creFlag				  = 0;
			for (k=0; k< count_P; k++)
			{

				if(AOM_ask_value_string(secondary_P[k],"object_string",&Specname)!=ITK_ok)PrintErrorStack();
				printf("\n Specname :Dataset type: %s\n ",Specname);fflush(stdout);

				if(AOM_ask_value_string(secondary_P[k],"object_type",&ProcreObjT)!=ITK_ok)PrintErrorStack();
				printf("\n ProcreObjT :Dataset type: %s\n ",ProcreObjT);fflush(stdout);

				if((tc_strcmp(ProcreObjT,"Creo drawing")==0) || (tc_strcmp(ProcreObjT,"CMI2Drawing")==0)|| (tc_strcmp(ProcreObjT,"ProDrw")==0))
				{
					Dataset_tag=secondary_P[k];

					creFlag=1;
					printf("\n rev: creFlag:%d", creFlag);fflush(stdout);
					break;
				}
			}
			printf("\n rev::::::::: creFlag:%d", creFlag);fflush(stdout);

			if(creFlag>0)
			{
				ifail=GRM_find_relation_type("IMAN_Rendering",&rendrelation_t );
				ifail=GRM_list_secondary_objects_only(Part_tag,rendrelation_t,&rendcount_P,&rendsecondary_P);
				printf("\n rev: rendcount_P:%d", rendcount_P);fflush(stdout);

				if(AOM_ask_value_string(Dataset_tag,"object_name",&ObjN)!=ITK_ok)PrintErrorStack();
				printf("\n :Dataset : %s\n ",ObjN);fflush(stdout);
				if(tc_strstr(partName,ObjN)!=NULL)
				{
					for(l=0; l< rendcount_P; l++)
					{
						if(AOM_ask_value_string(rendsecondary_P[l],"object_type",&creObjT)!=ITK_ok)PrintErrorStack();
						printf("\n :Dataset type creObjT: %s\n ",creObjT);fflush(stdout);
						if((tc_strcmp(creObjT,"PDF")==0))
						{
							if(QRY_find2("Dataset...", &qry_tg)); //MAIN CODE
							if(qry_tg != NULLTAG)
							{
								if(tc_strcmp(ProcreObjT,"ProDrw")==0)
								{
									entry[0] = "Name";
									entry[1] = "Dataset Type";//"Dataset ID","Revision"
									Value[0] = ObjN;
									Value[1] = "Creo drawing";
								}
								else
								{
									entry[0] = "Name";
									entry[1] = "Dataset Type";
									Value[0] = ObjN;
									Value[1] = "CMI2Drawing";
								}
								if(QRY_execute(qry_tg, 2, entry, Value, &CountQ, &DataObj));
								printf("\n:CountQ is: [%d]\n",CountQ);fflush(stdout);

								for (m=0;m<CountQ;m++)
								{
									printf("\n ____Proccessing Data____\n");

									obj=DataObj[m];

									if(AOM_ask_value_string(obj,"object_string",&DataRevName)!=ITK_ok)PrintErrorStack();
									printf("\n :Dataset Rev Name is : %s\n ",DataRevName);fflush(stdout);

									ifail=GRM_find_relation_type("IMAN_reference",&relation_tp );
									ifail = GRM_list_primary_objects_only(obj,relation_tp,&count_K,&part_Rev);
									printf("\n rev: count_K:%d",count_K);fflush(stdout);


									for(n=0;n<count_K;n++ )
									{
										if(count_K>0)
										{
											printf("\n ____Proccessing Data with count K____\n");
											Pobj=part_Rev[n];

											if(AOM_ask_value_string(Pobj,"object_string",&ObjTag)!=ITK_ok)PrintErrorStack();
											printf("\n :Revision Id : %s\n ",ObjTag);fflush(stdout);

											if(AOM_UIF_ask_value(Pobj,"release_status_list",&ObjStatus)!=ITK_ok)PrintErrorStack();
											printf("\n :release_status Is: %s\n ",ObjStatus);fflush(stdout);

											ifail= ITEM_ask_item_of_rev(Pobj,&itemtag);
											//ifail= ITEM_list_all_revs(itemtag,&count_O,&latestTag);
											//printf("\n :count_O is: %d\n ",count_O);fflush(stdout);

											ifail= ITEM_ask_latest_rev(itemtag,&latestRlzRevTag);

											rel_status_cunt=0;

											ITK_CALL(WSOM_ask_release_status_list (latestRlzRevTag, &rel_status_cunt, &rel_status_lst));
											printf("\n rel_status_cunt is:%d.", rel_status_cunt);fflush(stdout);

											if(rel_status_cunt>0)
											{
												for(p=0;p<rel_status_cunt;p++)
												{
													ITK_CALL(AOM_ask_value_string (rel_status_lst[p], "object_name", &Chld_Rel_Stus1));
													printf("\n Chld_Rel_Stus1:%s", Chld_Rel_Stus1);fflush(stdout);

													if((tc_strstr(Chld_Rel_Stus1,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(Chld_Rel_Stus1,"ERC Released")!=NULL))
													{
														latestRlzRevFlag = 1;
														printf("\n latestRlzRevFlag:[%d]", latestRlzRevFlag);fflush(stdout);
														//latestRlzRevTag=latestTag[o];
														if (latestRlzRevTag!=NULLTAG)
														{
															if(AOM_ask_value_string(latestRlzRevTag,"object_string",&latObjTag)!=ITK_ok)PrintErrorStack();
															printf("\n :Revision Id latest : %s\n ",latObjTag);fflush(stdout);
															printf("\n latestRlzRevTag is not NULL");fflush(stdout);
															ifail=GRM_find_relation_type("IMAN_reference",&refrelation_t );
															ifail=GRM_list_secondary_objects_only(latestRlzRevTag,refrelation_t,&refcount_P,&refsecondary_P);
															printf("\n rev: refcount_P:%d", refcount_P);fflush(stdout);

															if (refcount_P>0)
															{
																for(p=0;p<refcount_P;p++)
																{
																	printf("\n AOM Refresh");fflush(stdout);

																	if(AOM_ask_value_string(refsecondary_P[p],"object_type",&refObjT)!=ITK_ok)PrintErrorStack();
																	printf("\n :Dataset type refObjT: %s\n ",refObjT);fflush(stdout);

																	if(AOM_ask_value_string(refsecondary_P[p],"object_name",&refObjname)!=ITK_ok)PrintErrorStack();
																	printf("\n :Dataset type refObjname: %s\n ",refObjname);fflush(stdout);

																	ifail=GRM_find_relation_type("IMAN_reference",&refrelation_t );

																	if(tc_strstr(refObjT,"PDF")!=NULL)
																	{
																		ITK_CALL(GRM_find_relation(latestRlzRevTag,refsecondary_P[p],refrelation_t,&old_relation));
																		if (old_relation!=NULLTAG)
																		{
																			printf("\nbeFore GRM_delete_relation\n");fflush(stdout);
																			ITK_CALL(GRM_delete_relation(old_relation));
																			printf("\nafter GRM_delete_relation\n");fflush(stdout);
																			ITK_CALL(GRM_save_relation(old_relation));
																			printf("\nafter GRM_save_relation\n");fflush(stdout);
																		}
																		ITK_CALL(GRM_find_relation(latestRlzRevTag,refsecondary_P[p],refrelation_t,&new_relation));

																		if (new_relation==NULLTAG)
																		{

																			if(GRM_create_relation(latestRlzRevTag,rendsecondary_P[l],refrelation_t,NULLTAG,&Primarypdf_relation));	 //Working API
																			if(Primarypdf_relation != NULLTAG)
																			{
																				printf("\nFor saving rendering relation\n");fflush(stdout);
																				if(GRM_save_relation(Primarypdf_relation))PrintErrorStack();
																				printf("\nFor GRM_save_relation Primarypdf_relation relation\n");fflush(stdout);
																			}
																		}
																	}
																	else
																	{
																		printf("\nFor saving rendering relation..........\n");fflush(stdout);

																		if(GRM_create_relation(latestRlzRevTag,rendsecondary_P[l],refrelation_t,NULLTAG,&Primarypdf_relation));	 //Working API
																		if(Primarypdf_relation != NULLTAG)
																		{
																			printf("\nFor saving rendering relation\n");fflush(stdout);
																			if(GRM_save_relation(Primarypdf_relation))PrintErrorStack();
																			printf("\nFor GRM_save_relation Primarypdf_relation relation\n");fflush(stdout);
																		}
																	}
																}
															}
															else
															{
																printf("\nFor saving rendering relation..........\n");fflush(stdout);

																if(GRM_create_relation(latestRlzRevTag,rendsecondary_P[l],refrelation_t,NULLTAG,&Primarypdf_relation));	 //Working API
																if(Primarypdf_relation != NULLTAG)
																{
																	printf("\nFor saving rendering relation\n");fflush(stdout);
																	if(GRM_save_relation(Primarypdf_relation))PrintErrorStack();
																	printf("\nFor GRM_save_relation Primarypdf_relation relation\n");fflush(stdout);
																}
															}	
														}
														break;
													}	
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			else
			{
				ifail=GRM_find_relation_type("IMAN_Rendering",&relationrend);
				ifail=GRM_list_secondary_objects_only(Part_tag,relationrend,&Rendcount,&Rendsecondary);
				printf("\n rev: Rendcount:%d", Rendcount);fflush(stdout);
				for (q=0; q< Rendcount; q++)
				{
					if(AOM_ask_value_string(Rendsecondary[q],"object_type",&ObjT)!=ITK_ok)PrintErrorStack();
					printf("\n :Dataset type: %s\n ",ObjT);fflush(stdout);

					if(tc_strcmp(ObjT,"PDF")==0)
					{
						Dataset_tag=Rendsecondary[q];

						if(AOM_ask_value_string(Dataset_tag,"object_name",&ObjN)!=ITK_ok)PrintErrorStack();
						printf("\n :Dataset : %s\n ",ObjN);fflush(stdout);

						printf("\n NMRef found str......");fflush(stdout);
						ITK_CALL(AE_ask_all_dataset_named_refs2(Dataset_tag,"PDF_Reference",&NmdrefFound,&Nmdref_object));
						printf("\n NMRef count = [%d]",NmdrefFound);fflush(stdout);


						if(tc_strstr(partName,ObjN)!=NULL)
						{
							if(QRY_find2("Dataset...", &qry_tg)); //MAIN CODE
							if(qry_tg != NULLTAG)
							{
								entry[0] = "Name";
								entry[1] = "Dataset Type";//"Dataset ID","Revision"
								Value[0] = ObjN;
								Value[1] = "PDF";

								if(QRY_execute(qry_tg, 2, entry, Value, &CountQ, &DataObj));
								printf("\n:CountQ is: [%d]\n",CountQ);fflush(stdout);

								for (r=0;r<CountQ;r++)
								{
									printf("\n ____Proccessing Data____\n");

									obj=DataObj[r];

									if(AOM_ask_value_string(obj,"object_string",&DataRevName)!=ITK_ok)PrintErrorStack();
									printf("\n :Dataset Rev Name is : %s\n ",DataRevName);fflush(stdout);

									ifail=GRM_find_relation_type("IMAN_reference",&relation_tp );
									ifail = GRM_list_primary_objects_only(obj,relation_tp,&count_K,&part_Rev);
									printf("\n rev: count_K:%d",count_K);fflush(stdout);

									for(s=0;s<count_K;s++ )
									{
										if(count_K>0)
										{
											printf("\n ____Proccessing Data with count K____\n");
											Pobj=part_Rev[s];

											if(AOM_ask_value_string(Pobj,"object_string",&ObjTag)!=ITK_ok)PrintErrorStack();
											printf("\n :Revision Id : %s\n ",ObjTag);fflush(stdout);

											if(AOM_UIF_ask_value(Pobj,"release_status_list",&ObjStatus)!=ITK_ok)PrintErrorStack();
											printf("\n :release_status Is: %s\n ",ObjStatus);fflush(stdout);

											ifail= ITEM_ask_item_of_rev(Pobj,&itemtag);
											

											ifail= ITEM_ask_latest_rev(itemtag,&latestRlzRevTag);

											latestRlzRevFlag=0;
												
											rel_status_cunt=0;

											ITK_CALL(WSOM_ask_release_status_list (latestRlzRevTag, &rel_status_cunt, &rel_status_lst));
											printf("\n rel_status_cunt is:%d.", rel_status_cunt);fflush(stdout);

											if(rel_status_cunt>0)
											{
												for(u=0;u<rel_status_cunt;u++)
												{
													ITK_CALL(AOM_ask_value_string (rel_status_lst[u], "object_name", &Chld_Rel_Stus1));
													printf("\n Chld_Rel_Stus1:%s", Chld_Rel_Stus1);fflush(stdout);

													if((tc_strstr(Chld_Rel_Stus1,"T5_LcsErcRlzd")!=NULL)||(tc_strstr(Chld_Rel_Stus1,"ERC Released")!=NULL))
													{
														if (latestRlzRevTag!=NULLTAG)
														{
															ifail=GRM_find_relation_type("IMAN_reference",&refrelation_t );
															ifail=GRM_list_secondary_objects_only(latestRlzRevTag,refrelation_t,&refcount_P,&refsecondary_P);
															printf("\n rev: refcount_P:%d", refcount_P);fflush(stdout);

															if (refcount_P>0)
															{
																for(v=0;v<refcount_P;v++)
																{
																	printf("\n AOM Refresh");fflush(stdout);

																	if(AOM_ask_value_string(refsecondary_P[v],"object_type",&refObjT)!=ITK_ok)PrintErrorStack();
																	printf("\n :Dataset type refObjT: %s\n ",refObjT);fflush(stdout);

																	if(AOM_ask_value_string(refsecondary_P[v],"object_name",&refObjname)!=ITK_ok)PrintErrorStack();
																	printf("\n :Dataset type refObjname: %s\n ",refObjname);fflush(stdout);

																	if(tc_strcmp(refObjT,"PDF")==0)
																	{
																		if (tc_strstr(refObjname,ObjN)!=NULL)
																		{
																			ifail=GRM_find_relation_type("IMAN_reference",&refrelation_t );

																			ITK_CALL(GRM_find_relation(latestRlzRevTag,refsecondary_P[v],refrelation_t,&new_relation));

																			ITK_CALL(GRM_find_relation(latestRlzRevTag,refsecondary_P[v],refrelation_t,&old_relation));
																			if (old_relation!=NULLTAG)
																			{
																				printf("\nbeFore GRM_delete_relation\n");fflush(stdout);
																				ITK_CALL(GRM_delete_relation(old_relation));
																				printf("\nafter GRM_delete_relation\n");fflush(stdout);
																				printf("\nafter GRM_save_relation\n");fflush(stdout);
																			}
																			ITK_CALL(GRM_find_relation(latestRlzRevTag,refsecondary_P[v],refrelation_t,&new_relation));

																			if (new_relation==NULLTAG)
																			{
																				if(GRM_create_relation(latestRlzRevTag,Dataset_tag,refrelation_t,NULLTAG,&Primarypdf_relation));	 //Working API
																				if(Primarypdf_relation != NULLTAG)
																				{
																					printf("\nFor saving rendering relation\n");fflush(stdout);
																					if(GRM_save_relation(Primarypdf_relation))PrintErrorStack();
																					printf("\nFor GRM_save_relation Primarypdf_relation relation\n");fflush(stdout);
																				}
																			}
																		}
																	}
																	else
																	{
																		if(GRM_create_relation(latestRlzRevTag,Dataset_tag,refrelation_t,NULLTAG,&Primarypdf_relation));	 //Working API
																		if(Primarypdf_relation != NULLTAG)
																		{
																			printf("\nFor saving rendering relation\n");fflush(stdout);
																			if(GRM_save_relation(Primarypdf_relation))PrintErrorStack();
																			printf("\nFor GRM_save_relation Primarypdf_relation relation\n");fflush(stdout);
																		}
																	}
																}
															}
															else
															{
																if(GRM_create_relation(latestRlzRevTag,Dataset_tag,refrelation_t,NULLTAG,&Primarypdf_relation));	 //Working API
																if(Primarypdf_relation != NULLTAG)
																{
																	printf("\nFor saving rendering relation\n");fflush(stdout);
																	if(GRM_save_relation(Primarypdf_relation))PrintErrorStack();
																	printf("\nFor GRM_save_relation Primarypdf_relation relation\n");fflush(stdout);
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}

int ITK_user_main(int argc, char *argv[])
{
	char			* sdmlno				 = NULL;
	char			* password		= NULL;
	char			* group				= NULL;
	char			* newdml				= NULL;
	char			* dmlnos				= NULL;

	sdmlno          = ITK_ask_cli_argument("-dmlno=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);


	ifail = ITK_auto_login();
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);

	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nhey Login Successfull.....!!\n");fflush(stdout);
		printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
	}
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}
	printf("\n dmlnoooo : [%s]\n",sdmlno);fflush(stdout);

	ifail=Part_check_reference(sdmlno);

	printf("\n*********************");
	printf("\n       End of program.....!!");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	return ifail;
}
