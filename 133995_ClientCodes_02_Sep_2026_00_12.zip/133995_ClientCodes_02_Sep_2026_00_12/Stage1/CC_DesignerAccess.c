#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <tccore/aom_prop.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <ae/dataset_msg.h>
#include <tccore/grm_msg.h>
#include <epm/releasestatus.h>
#include <tc/tc_startup.h>
#include <tc/folder.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <res/res_itk.h>
#include <ctype.h>
#include <pom/pom/pom.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <time.h>


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}


static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

void trimTrailing(char* str)
{
    int index, i;

    /* Set default index */
    index = -1;

    /* Find last index of non-white space character */
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }

        i++;
    }

    /* Mark next character to last non-white space character as NULL */
    str[index + 1] = '\0';
}
;

void trimLeading(char* str)
{
    int index, i;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
;
extern int ITK_user_main(int argc, char *argv[] )
{

	int	iStatus= 0;
	int ii=0;
	int iChRItem=0;
    tag_t	queryTag	= NULLTAG;
	tag_t   queryTag1   =NULLTAG;
	char *sUserName		=   NULL;
    char *sPassword		=   NULL;
    char *sGroup          =   NULL;
    char *user_id = NULL;
	int resultCount=0;
    int resultCount1=0;
	tag_t UserTag=NULLTAG;
    tag_t UserTag1=NULLTAG;
    tag_t *rev=NULLTAG;
     tag_t *rev1=NULLTAG;
	tag_t *lov=NULLTAG;
	tag_t ProjTag=NULLTAG;
	int n_entries = 1;
	int n_entries1 = 2;
	char *useridTag=NULL;
	char * User_Name		=	NULL;
	char * User_Name1       =NULL;
	char * User_ID	=	NULL;
	char *inputfile= NULL;
	char *dupproj=NULL;
	char *object_name= NULL;
	char * Project_Code		=	NULL;
	char * Groups    =	NULL;
	char * Roles			=	NULL;
	char * License_Level =	NULL; 
	char * Projeccode		=	NULL;
	char * User_Agency		=	NULL;
	char * User_Location			=	NULL;
	char * OS_Login			=	NULL;
	char * Email_ID			=	NULL;
	char * Visualization_Sevice_Level			=	NULL;
	char * Last_Login_Date			=	NULL;
    char        *qry_entries[1]                   = {"User ID"};
	char *qry_entries1[2] = {"Project ID","Id"};
    char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));
	char    *qry_values[1];
	int nCRItem=0;
	tag_t person_tag = NULLTAG;
	tag_t user_tag = NULLTAG;
	tag_t additional_prop_tag = NULLTAG;
	


    printf("\n Auto login1 ");
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
    printf("\n Auto login2 ");

	//ITK_CALL(ITK_auto_login( ));
	iStatus = ITK_auto_login();
	printf("\n Auto login3 ");
	ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login4\n");
	if(iStatus == ITK_ok)
    {
        printf("\n\n\t Login Successful\n");
    }
    else
    {
        printf("\n\n\t Login is Not Successful\n");
    }

    ITK_CALL(POM_get_user_id(&user_id));
	
	printf("\n\n\t logged in User: %s\n",user_id);

   
    FILE *fp=NULL;
    FILE *ftr=NULL;
    
    //char* LineRead = NULL;
    char  temp[1000];
    
  	printf("\n Auto login5 ");fflush(stdout);
    
     fp=fopen("/user/cvprod/Asif/UserInformation/CC_DesignerAccess/ProjectCode_Input.txt","r");
     printf("\n Auto login6 ");fflush(stdout);
    
    
  	if(fp==NULL)
  	{
		printf("Read File\n");
  		printf("unable  open  File\n ");fflush(stdout);
  		return 1;
  	}
	

  	else
  	{
  		printf("\n Auto login7 ");fflush(stdout);
        
  		while(fgets(temp,1000,fp)!=NULL)
  		{
  			
  			 if(temp != NULL)
  			 {

    		     fputs(temp,stdout);
				 User_Name= (char *)MEM_alloc(1000);
				 Project_Code= (char *)MEM_alloc(1500);
				 trimLeading(temp);
                 trimTrailing(temp);
  			 	 User_Name = strtok(temp,",");
                 Project_Code=strtok(NULL," ");

				if(QRY_find("Find Projects With Assigned User", &queryTag));
				printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
				if (queryTag)
				{
					printf("2.Found Query \n");fflush(stdout);
				}
				else
				{
					printf("Not Found Query");fflush(stdout);
				}
				        printf("\n User ID: %s",User_Name);
				       qry_values[0] = User_Name;
					   //tc_strcat(qry_values[0],"*");
					   printf("\n User ID: %s",User_Name);
	
	                // QRY_set_name_mode(queryTag,false);
					//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
                    if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
			        printf(" \n resultCount :%d:", resultCount); fflush(stdout);
					printf("\n User Name: %s",User_Name);
					if(resultCount>0)
				 {
//                     UserTag = rev[0];
//                       ITKCALL(AOM_ask_value_tags(UserTag,"fnd0SecurityAuditLogs",&nCRItem,&lov));
//                       printf("\n No of project : %d",nCRItem);fflush(stdout);
//					   dupproj=(char *) MEM_alloc(150);
//					   tc_strcpy(dupproj,"");

                     
					  for(iChRItem=resultCount-1;iChRItem>=0;iChRItem--)
				     {
					   ProjTag=rev[iChRItem];
                       ITK_CALL(AOM_ask_value_string(ProjTag,"project_id",&Projeccode));
                      if(tc_strstr(Project_Code,Projeccode)!=NULL)
						 { 

					   inputfile=(char *) MEM_alloc(250);
                       tc_strcpy(inputfile,"/user/cvprod/Asif/UserInformation/CC_DesignerAccess/output/");	
					   tc_strcat(inputfile,Projeccode);
                       tc_strcat(inputfile,"_");
                       tc_strcat(inputfile,User_Name);
                       tc_strcat(inputfile,".txt");
				       ftr=fopen(inputfile,"w");
					   printf("\nfile name ===%s",inputfile);
                        if(QRY_find("ProjectUserAccessDet", &queryTag1));
				         printf("\n After IFERR_REPORT : QRY_find \n");fflush(stdout);
				         if (queryTag1)
				        {
					  printf("2.Found Query \n");fflush(stdout);
				        }
				       else
				       {
					printf("Not Found Query");fflush(stdout);
				         }

						  printf("\n Project code for Compaire %s\n",Projeccode);
						  //if(tc_strstr(dupproj,Projeccode)==NULL)
					      //{
					      //printf("\nTotal No of project %s\n",dupproj);
						  printf("\n%s\n",Projeccode);
						 // tc_strcat(dupproj,Projeccode);
						  //tc_strcat(dupproj,",");
					      qry_values1[0] =Projeccode;
			              qry_values1[1] =User_Name ;
						 if(QRY_execute(queryTag1, n_entries1, qry_entries1, qry_values1, &resultCount1, &rev1));
			             printf(" \n resultCount :%d:", resultCount1); fflush(stdout);
						 printf("\nProject code:-%s\n",Projeccode);
                        for(ii=resultCount1-1;ii>=0;ii--)
				       {
                          UserTag1=rev1[ii];
                         ITK_CALL(AOM_ask_value_string(UserTag1,"object_string",&object_name));
        				 printf("\n%s\n",object_name);
					      fprintf(ftr,"%s\n",object_name);
				        }
						 }
					// }

				 }
					 
				 }
					 

  			 
  			 	
  			 }
    
  			
  		}
                      
                   
      }
                      
      if(fp)
      {
         fclose(fp);
         fp=NULL;
  	  }
	  if (ftr)
	  {
		  fclose(ftr);
		  ftr=NULL;
	  }

	

  return ITK_ok;
}
