#!/bin/bash
. /home/apldev/.bash_profile
user=$1
password=$2
group=$3
#file="c"
downloadpath=$4
item_ID=$5
rev=$6


class="PSBOMViewRevision"
echo "Start downloading....."
echo "$user"
echo "$password"
echo "$group"
#echo "$file"
echo "$item_ID"
echo "$rev"

current_path=$(pwd)
echo "Current working directory: $current_path"

current_time=$(date)
echo "Current date and time: $current_time"

#Started .exe execuation.
#/home/apldev/TC_ROOT14/bin/bomwriter -u=$user -p=$password -g=$group -item=$item_ID -rev=$rev -revision_rule="Latest Working" -output_file="/home/apldev/devgroups/Aniket/bomexpension/export/$item_ID.psup" -format=psup+delimiter="|"+props=bl_item_item_id
/home/apldev/TC_ROOT14/bin/bomwriter -u=$user -p=$password -g=$group -item=$item_ID -rev=$rev -revision_rule="Latest Working" -output_file="$downloadpath$item_ID.psup" -format=psup+delimiter="|"+props=bl_item_item_id
if [ $? -eq 0 ]; then
    echo "Program ran successfully!"
    current_time=$(date)
    echo "Current date and time: $current_time"
    #exit 0
else
    echo "Program failed with exit code $?"
    exit -1
    current_time=$(date)
    echo "Current date and time: $current_time"

fi
echo "Operation peform successfully........................................."
