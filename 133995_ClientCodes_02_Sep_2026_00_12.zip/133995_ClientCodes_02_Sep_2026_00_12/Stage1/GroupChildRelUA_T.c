/********************************************************************************************************************************************************************
File Name	:	GroupChildRelUA.c
Purpose		:	Query the group part, find the all revision released revision
				Explode the Released Part with 99 level and collect the unique part in list
				print the unique part in file. File will be created at shared location between
				tcua and tce.
Date		:	02-Nov-2020
Modification:	02-Nov-2020	: created code for first time.
********************************************************************************************************************************************************************/
#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <time.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <pie/pie.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
		
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100
//#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
//#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return


static void handle_ifail(char *file, int line);
static void MultiExplosion (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,int reqLevel,int level);
static void MultiExplosionLinkInfo (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,char *Uidd,int reqLevel,int level);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
// #define ITK_CALL(X) 							\
// 		status=X; 								\
// 		if (status != ITK_ok ) 					\
// 		{										\
// 			int				index = 0;			\
// 			int				n_ifails = 0;		\
// 			const int*		severities = 0;		\
// 			const int*		ifails = 0;			\
// 			const char**	texts = NULL;		\
// 												\
// 			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
// 			printf("%3d error(s) with #X\n", n_ifails);						\
// 			for( index=0; index<n_ifails; index++)							\
// 			{																\
// 				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
// 			}																\
// 			return status;													\
// 		}																	\
// 	;
#define ITK_CALL(x) {           \
    int stat;                     \
    char *err_string;             \
    if( (stat = (x)) != ITK_ok)   \
    {                             \
    EMH_ask_error_text (stat, &err_string);                 \
    printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
    printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
    if(err_string) MEM_free(err_string);                                \
    exit (EXIT_FAILURE);                                                   \
    }                                                                    \
}
struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;

/////////////////////////////////
FILE	*GRP_CHILD;
FILE    *GRP_CHILD1;
char 		szHMCL_file_log[250] 			= "";
char 		szHMCL_file_err[250]			= "";
char 		szHMCL_file_output[250] 		= "";
static void vLog(char* givenFormat, va_list givenArgs, char* fileName)
{
	char			* logFile 			= NULL;
	FILE			* logFp;
	time_t 			now;
	struct 			tm when;
	char 			date_str[50];
	long 			size;
	logical 		check_size 			= false;
	logFile 							= fileName;
	if (logFile)
	{
		logFp = fopen(logFile, "a+");
		if(!logFp)
		{
			fprintf(stderr, "ERROR: Cannot open '%s'\n", logFile);
			perror(logFile);
			logFp = stderr;
		}
		else{
			fseek(logFp, 0, SEEK_END);
			size = ftell(logFp);
			if(size > 3000000 && check_size)
			{	fclose (logFp);
				logFp = fopen(logFile, "w");
			}
			  }
	}
	else
	{	logFp = stderr;
	}
	if (tc_strcmp(logFile, szHMCL_file_output) == 0)
	{
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp,"\n");
		if (logFp != stderr)
		{			fclose(logFp);
		}
	}
	else
	{
		time(&now);
		when = *localtime(&now);
		strftime(date_str, 50, "%d-%m-%Y %H:%M:%S",&when);
		fprintf(logFp, "%s --- ", date_str);
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp, "\n");
		if (logFp != stderr)
		{	fclose(logFp);
		}
	}
}
void Debug(char* givenFormat, ...)
{
	va_list   functArgs;
	va_start(functArgs, givenFormat);
	vLog(givenFormat, functArgs, szHMCL_file_log);
	va_end(functArgs);
}
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}

//#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
 if (return_code != ITK_ok)
{
	char *error_msg_string;
	EMH_ask_error_text(return_code,&error_msg_string);
	//EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
	printf("ERROR1: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
	TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
	TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
	if(error_msg_string) MEM_free(error_msg_string);

	}
	return return_code;
}

////////////////////////////////
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void Multi_Get_Part_BOM_Lvl(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITK_CALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	printf("\n ViewBVR=>[%s] ...\n",ViewBVR);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITK_CALL(ITEM_rev_list_bom_view_revs(inputPart, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

	if(n_values_bvr==0)
	{
		flagBVR=0;
	}
	else if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITK_CALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				//if(tc_strcmp(viewTok,"View")==0)
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					flagBVR=1;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		if(flagBVR!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITK_CALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					//if(tc_strcmp(viewTok,"View")==0)
					//{
						flagBVR=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					//}
				}
			}
		}

	}
	printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

	ITK_CALL(BOM_create_window (&window));
	ITK_CALL(BOM_set_window_config_rule(window,revRule));
	ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	//ITK_CALL(BOM_set_window_pack_all (window, true));
	if(flagBVR==1)
	{
		BOM_set_window_top_line(window, null_tag,inputPart ,bvr_tag, &top_line);
		ITK_CALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n; k++)
		{
			BOM_line_unpack (children[k]);
			//BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
			//BOM_line_ask_attribute_tag(children[k], iChildItemTag, &t_ChildItemRev);
			AOM_ask_value_tag(children[k],bomAttr_lineItemRevTag, &t_ChildItemRev);
			
			if(t_ChildItemRev!=NULLTAG)
			{
				AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);
				*StructChldCnt	=	*StructChldCnt+1;
				//get_BomChldStrut[*StructChldCnt].child_objs = childrenTag[k]; Hemal
				BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut[*StructChldCnt].child_objs_lvl=level;

				Multi_Get_Part_BOM_Lvl(t_ChildItemRev,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
			}
		}
		level = level - 1;
	}

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}
int Get_Part_BOM_Lvl(tag_t VehicleObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1=0;
	int n=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	int level 				= 0;
	tag_t	window 				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	objChild			= NULLTAG;
	tag_t	objChild_bvr			= NULLTAG;
	int child_lvl=0;
	char	*c_Qty						=	NULL;
	tag_t  *children1=NULLTAG;
	int iChildItemTag=0;
	int assbvr=0;
	int bvrfound=0;
	int flagRevRule=0;
	int flagClosureRule=0;
	char *view_name=NULL;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;

	printf("\nInside Get_Part_BOM_Lvl ....\n");

	if(VehicleObj == NULLTAG)
	{
		printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	ITK_CALL(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
	printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);

	ITK_CALL(ITEM_rev_list_bom_view_revs(VehicleObj, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITK_CALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				if(tc_strcmp(viewTok,ViewBVR)==0)
				{
					bvrfound++;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		//Added by Hemal, same need to check and add in common file also.
		if(bvrfound!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITK_CALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					//if(tc_strcmp(viewTok,"View")==0)
					//{
						bvrfound=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					//}
				}
			}
		}
		//Ended by Hemal

	}

	printf("\n bvrfound=>[%d] ",bvrfound);fflush(stdout);
	if(bvrfound==0)
	{
		printf("\n**********BVR NOT Exist*********\n");fflush(stdout);
	}
	else
	{
		ITK_CALL(CFM_find(revRuleName, &revRule));
		if (revRule != NULLTAG)
		{
			printf("\nFind revRule\n");fflush(stdout);
			flagRevRule=1;
		}

		scope=PIE_TEAMCENTER;
		ITK_CALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
			flagClosureRule=1;
		}
		printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
		printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
		if((flagClosureRule==1) && (flagRevRule==1))
		{

			Multi_Get_Part_BOM_Lvl(VehicleObj,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut,StructChldCnt);
		}
		else
		{
			printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
		}

	}
	printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);

	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		child_lvl       =0;

		printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;

		AOM_ask_value_string(objChild,"item_id",&ItemName);
		printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		printf("\nQty==>%s\n",c_Qty);fflush(stdout);

	}
	return ifail;
}

void GrpPartbom(char* cGroupPart, char* ClosureRName, char* RevisionRName, char* Rlzd_status,char* cFilename)
{
	int		num_to_sort		=	1;
	int		n_entries		=	2;
	int		n_found			=	0;
	int		revCnt			=	0;
	char	*keys[1]		=	{"creation_date"};
	int		orders[1]		=	{2};
	int		icount				=	0;
	int		ichk				=	0;
	int		ifnd				=	0;
	int 	i  				=   0;
	int iLength = 0;

	tag_t	queryPart		=	NULLTAG;
	tag_t*	results			=	NULLTAG;

	char*	cgchildnum			=	NULL;
	char*	tempErr				=	NULL;
	struct			BomChldStrut	ChldStrutBdySh[5000];
	int	StructCntBdyShProdPlan	= 0;
	char*	qry_part_entries[2]	= {"Item ID","Release Status"};
	char*	qry_part_values[2]	= {cGroupPart,Rlzd_status};
	char	**SetChildRelErr	=	NULL;
	char*	cGrpPrtRev			=	NULL;
	int		iChildItemTag		=	0;
	int		igchild				=	0;
	tag_t	t_gchildtag			=	NULLTAG;
	tag_t	t_gchildtag_bvr		=	NULLTAG;
	



	ITK_CALL(QRY_find2("Item Revision...", &queryPart));

	if (queryPart!=NULLTAG)
	{
		//qry_part_values[0]= cGroupPart;

		QRY_execute_with_sort(queryPart, n_entries, qry_part_entries, qry_part_values, num_to_sort, keys, orders, &n_found, &results);

		fprintf(GRP_CHILD,"\nNumber of Part found : %d",n_found);fflush(GRP_CHILD);
		
		
		if (n_found>0)
		{
			SetChildRelErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelErr );
			setAddStr(&icount,&SetChildRelErr,cGroupPart);
			setAddStr(&icount,&SetChildRelErr,"\n");
			for(revCnt=0;revCnt<n_found;revCnt++)
			{
				tag_t	PartrevisionTag		=	NULLTAG;
				
				PartrevisionTag		=	results[revCnt];

				ITK_CALL(AOM_ask_value_string(PartrevisionTag,"item_revision_id",&cGrpPrtRev));

				fprintf(GRP_CHILD,"\nGroup Part Revision : %s", cGrpPrtRev);fflush(GRP_CHILD);

				StructCntBdyShProdPlan	=	0;
				ITK_CALL(Get_Part_BOM_Lvl(PartrevisionTag,99,ClosureRName,RevisionRName,"View",ChldStrutBdySh,&StructCntBdyShProdPlan));

				fprintf(GRP_CHILD,"\nNo of child part found : %d",StructCntBdyShProdPlan);fflush(GRP_CHILD);

				if (StructCntBdyShProdPlan>0)
				{
					for (igchild=1;igchild<=StructCntBdyShProdPlan ;igchild++ )
					{
						t_gchildtag		=	NULLTAG;
						t_gchildtag_bvr	=	NULLTAG;

						t_gchildtag_bvr	=	ChldStrutBdySh[igchild].child_objs_bvr;

						ITK_CALL(BOM_line_unpack (t_gchildtag_bvr));
						ITK_CALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
						ITK_CALL(BOM_line_ask_attribute_tag(t_gchildtag_bvr, iChildItemTag, &t_gchildtag));
						
						cgchildnum=NULL;
						ITK_CALL(AOM_ask_value_string(t_gchildtag,"item_id",&cgchildnum));
						fprintf(GRP_CHILD,"\n child cgchildnum:%s ..............",cgchildnum);fflush(GRP_CHILD);
						fprintf(GRP_CHILD,"\n child lemgth:%d ..............",tc_strlen(cgchildnum));fflush(GRP_CHILD);
						if(tc_strlen(cgchildnum)>0)
						{
							//Check if part is already present in set or not
							//iLength	=	0;
							if (!tempErr) MEM_free(tempErr);
							ifnd	=	0;
							for (ichk=0;ichk<icount ;ichk++ )
							{
								if (!tempErr) MEM_free(tempErr);
								tempErr	=	NULL;
								tempErr	=	SetChildRelErr[ichk];
								fprintf(GRP_CHILD,"\nTemp Part : %s, Group child Number : %s",tempErr,cgchildnum);fflush(GRP_CHILD);
								//compare
								if (tc_strcmp(tempErr,cgchildnum)==0)
								{
									fprintf(GRP_CHILD,"\nPart is already availble in Set");fflush(GRP_CHILD);
									ifnd++;
									break;
								}
								fprintf(GRP_CHILD,"\nfound : %d",ifnd);fflush(GRP_CHILD);
	//										else
	//										{
	//											//Add part in set
	//											setAddStr(&icount,&SetChildRelErr,cgchildnum);
	//											setAddStr(&icount,&SetChildRelErr,"\n");
	//										}
							}
							if (ifnd<=0)
							{
								fprintf(GRP_CHILD,"\nPart not found in set so add it in set");fflush(GRP_CHILD);
								setAddStr(&icount,&SetChildRelErr,cgchildnum);
								setAddStr(&icount,&SetChildRelErr,"\n");
							}
						}
					}
				}
			}
		}
	}
	GRP_CHILD1	=	fopen(cFilename,"w");
	if (icount>0)
	{
		iLength	=	0;
		if (!tempErr) MEM_free(tempErr);
		i	=	0;
		for (i=0; i < icount; i++)
		{
			//printf("%s",SetChildRelErr[i]);fflush(stdout);
			tempErr	=	SetChildRelErr[i];
			iLength	=	iLength	+	tc_strlen(tempErr);
		}
		printf("iLength : %d",iLength);fflush(stdout);

		if (!tempErr) MEM_free(tempErr);
		tempErr	=	(char *)MEM_alloc(iLength+20);

		for (i=0; i < icount; i++)
		{
			//printf("%s",SetChildRelErr[i]);fflush(stdout);
			if(i==0)
				tc_strcpy(tempErr,SetChildRelErr[i]);
			else
				tc_strcat(tempErr,SetChildRelErr[i]);
		}
		printf("\nPrinting Errors...!!!\n");fflush(stdout);
		printf("%s",tempErr);fflush(stdout);
		fprintf(GRP_CHILD1,"%s",tempErr);fflush(GRP_CHILD1);

	}
}
int ITK_user_main(int argc,char* argv[])
{
	int     ifail 				=   ITK_ok;
	int		status				=	0;
	int		cntrev				=	0;
	int		iChildItemTag		=	0;
	int		iLength				=	0;
	int		igchild				=	0;
	int		i					=	0;
	int 	n_items             =   0;

	char*	cGroupPart			=	NULL;
    char*   Plant               =   NULL;
	char*	FilePath			=	NULL;
	char*	cFilename			=	NULL;
	char*	cFirstChar			=	NULL;
	char*	cGrpPrtNum			=	NULL;
    char*   ExeLogFile          =	NULL;
	char*   Owner               =   NULL;
	char*   owning_group        =   NULL;
	char*   ClosureRName        =   NULL;
	char*   RevisionRName       =   NULL;
	char*   ViewBVR             =   NULL;
	char*   Rlzd_status         =   NULL;
	char*   PartTagrevid        =   NULL;

	tag_t   cGroupPart_tag      =   NULLTAG;
	tag_t   PartTag             =   NULLTAG;
	tag_t   PartTagrev          =   NULLTAG;
	tag_t	t_GrpPrt			=	NULLTAG;
	tag_t	t_GrpPrtRev			=	NULLTAG;
	tag_t*	t_GrpPrtRevs		=	NULLTAG;
    tag_t* 	items               =   NULLTAG;
	
	

	ClosureRName=(char *) MEM_alloc(200 * sizeof(char *));
	RevisionRName=(char *) MEM_alloc(200 * sizeof(char *));
	ViewBVR=(char *) MEM_alloc(100 * sizeof(char *));
	Rlzd_status=(char *) MEM_alloc(50 * sizeof(char *));

	printf("\n parameters \n");fflush(stdout);

	cGroupPart	= ITK_ask_cli_argument("-i=");
    Plant	= ITK_ask_cli_argument("-pl=");
	FilePath	= ITK_ask_cli_argument("-fp=");

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_auto_login( ));
	
	printf("\n Login Successfull \n");fflush(stdout);

	const char * 	attribute_names[1]= {"item_id"};
	const char * 	attribute_values[1]= {cGroupPart};

	printf("Group Part : %s, Plant : %s",cGroupPart,Plant);fflush(stdout);
	//printf("Group Part : %s, Plant : %s, File Path : %s",cGroupPart,Plant,FilePath);fflush(stdout);

    ExeLogFile = (char	*)MEM_alloc(100);
    tc_strcpy(ExeLogFile,"");
   // tc_strcpy(ExeLogFile,"/home/apldev/devgroups/Akshata/PV_webservices/PV_GroupChildRelUA_T/LOG/");
	tc_strcpy(ExeLogFile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_GRP_CHILD/UA_GRP_CHILD_LOG/");
    tc_strcat(ExeLogFile,cGroupPart);
    tc_strcat(ExeLogFile,"_GrpChild.log");
    GRP_CHILD = fopen(ExeLogFile,"w");
  
    fprintf(GRP_CHILD,"\n Part Execution Log file is :: %s\n",ExeLogFile);fflush(GRP_CHILD);

	cFilename	=	(char*)malloc(tc_strlen(FilePath)+tc_strlen(cGroupPart)+20);
	tc_strcpy(cFilename,FilePath);
	tc_strcat(cFilename,cGroupPart);
	tc_strcat(cFilename,"_GrpChild.txt");
    fprintf(GRP_CHILD,"\nFile Name : %s",cFilename);fflush(GRP_CHILD);

    if(tc_strcmp(Plant,"CAR")==0)
    {
        tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLC");
        tc_strcpy(RevisionRName,"APLC Release and above");
        tc_strcpy(ViewBVR,"View");
        tc_strcpy(Rlzd_status,"T5_LcsAplRlzd");

    }
    else if(tc_strcmp(Plant,"AHD")==0)
    {
        tc_strcpy(ClosureRName,"BOMViewClosureRuleAPLA");
        tc_strcpy(RevisionRName,"APLA Release and above");
        fprintf(GRP_CHILD,"\n RevisionRName :%s \n",RevisionRName);fflush(GRP_CHILD);
        tc_strcpy(ViewBVR,"View");
        tc_strcpy(Rlzd_status,"T5_LcsAplaRlzd");

    }
    else
    {
        fprintf(GRP_CHILD,"\n Invalid Plant :%s \n",Plant);fflush(GRP_CHILD);
       
    }

    fprintf(GRP_CHILD,"Group Part : %s",cGroupPart);fflush(GRP_CHILD);
    fprintf(GRP_CHILD,"\nClosureRName = %s \n",ClosureRName);fflush(GRP_CHILD);
    fprintf(GRP_CHILD,"\nRevisionRName = %s \n",RevisionRName);fflush(GRP_CHILD);
    fprintf(GRP_CHILD,"\nRlzd_status = %s \n",Rlzd_status);fflush(GRP_CHILD);

	ITEM_find_items_by_key_attributes(1,attribute_names,attribute_values,&n_items,&items);
	fprintf(GRP_CHILD,"\n n_items = %d \n",n_items);fflush(GRP_CHILD);

	if (n_items > 0)
    {
		fprintf(GRP_CHILD,"\n **** Inside if **** \n");fflush(GRP_CHILD);
		for (i = 0; i < n_items; i++)
		{
			PartTag = items[i];
			ITK_CALL(ITEM_ask_latest_rev(PartTag, &PartTagrev));
			ITK_CALL(AOM_ask_value_string(PartTagrev, "item_id", &PartTagrevid));
			fprintf(GRP_CHILD,"\n item_id= [%s]\n", PartTagrevid);fflush(GRP_CHILD);

			ITK_CALL(AOM_ask_value_string(PartTagrev, "item_revision_id", &PartTagrevid));
			fprintf(GRP_CHILD,"\n item_revision_id= [%s]\n", PartTagrevid);fflush(GRP_CHILD);

			ITK_CALL(AOM_UIF_ask_value(PartTagrev, "owning_group", &owning_group));
			fprintf(GRP_CHILD,"\n\n\t\t owning_group  is :%s",owning_group);	fflush(GRP_CHILD);
		
			ITK_CALL(AOM_UIF_ask_value(PartTagrev, "owning_user", &Owner));
			fprintf(GRP_CHILD,"\n\n\t\t Owner  is :%s",Owner);	fflush(GRP_CHILD);
		}
	}
	fprintf(GRP_CHILD,"\n**** After finding part tag **** \n");fflush(GRP_CHILD);


	if (cGroupPart!=NULL)
	{
		fprintf(GRP_CHILD,"\nGroup part is not NULL");fflush(GRP_CHILD);
		cFirstChar	=	subString(cGroupPart,0,1);
		fprintf(GRP_CHILD,"\nFirst character : %s",cFirstChar);fflush(GRP_CHILD);

		if (tc_strcmp(cFirstChar,"G")==0)
		{
			if((tc_strstr(owning_group,"ERC") != NULL) || (tc_strcmp(owning_group,"dba")==0 && tc_strcmp(Owner,"loader")==0))
			{
				//function to check Group Part with ERC Released status
				fprintf(GRP_CHILD,"\n Inside ERC condition\n");fflush(GRP_CHILD);
            	GrpPartbom(cGroupPart,"BOMViewClosureRuleERC","ERC release and above","T5_LcsErcRlzd",cFilename);
			}	
			else if((tc_strstr(owning_group,"APL") != NULL)|| (tc_strcmp(owning_group,"dba")==0 && tc_strcmp(Owner,"aplloader")==0))
			{
				//function to check Group Part with APL Released status
				fprintf(GRP_CHILD,"\n Inside APL condition\n");fflush(GRP_CHILD);
				GrpPartbom(cGroupPart,ClosureRName,RevisionRName,Rlzd_status,cFilename);
			}
			else
			{
				fprintf(GRP_CHILD,"\n Invalid owning grp\n");fflush(GRP_CHILD);
			}

		}
		else
		{
			fprintf(GRP_CHILD,"\nG is not a first character in input part");fflush(GRP_CHILD);
		}
	}
	else
	{
		fprintf(GRP_CHILD,"\nGroup part is NULL");fflush(GRP_CHILD);
	}

	fclose(GRP_CHILD);
	fflush(stdout);
	// dup2(fd, fileno(stdout));
	// close(fd);
	// clearerr(stdout);
	// fsetpos(stdout, &pos);

	return ITK_ok;
}