#include <time.h>
#include <stdio.h>

#include <tc/emh.h>
//#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
//#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <Fnd0Participant/participant.h>
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN 128
#include <epm/epm.h>
#include <ae/dataset_msg.h>

#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>

#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_date.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>

#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>

#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <tc/folder.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_ask_error_text (return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

void tm_find_Prev_Official_Rev(char	*req_item,tag_t t_currentRevision, tag_t* t_previousRevision)
{
	int		Item_count			=	0;
	int		RevFlag				=	0;
	int		PreRevFlag 			=	0;
	int		ii					=	0;
	int		n_tags_found		=	0;

	char	*Part_Rev			=	NULL;
	char	*Part_Rev_copy		=	NULL;
	char	*Part_rev_Id		=	NULL;
	char	*RevOnly			=	NULL;
	char	*PreRevOnly			=	NULL;
	char	*Part_prev_rev_Id	=	NULL;

	tag_t	All_item_tag		=	NULLTAG;
	tag_t	*rev_list			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;

	printf("\ntm_fnd_prev_revision called : %s",req_item);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev));
	printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);

	ITKCALL(AOM_ask_value_string(t_currentRevision,"item_revision_id",&Part_Rev_copy));
	printf("\n Part_Rev_copy: %s\n",Part_Rev_copy);fflush(stdout);

	//ITKCALL(ITEM_list_all_revs (All_item_tag,&Item_count,&rev_list));
	ITKCALL(AOM_ask_value_tags(t_currentRevision,"revision_list",&Item_count,&rev_list));
	printf("\nNo of Item : %d",Item_count);fflush(stdout);

	if(Item_count > 0)
	{
		RevFlag		=	0;
		PreRevFlag	=	0;

		for(ii=Item_count-1;ii>=0;ii--)
		{
			RevOnly		=	NULL;
			PreRevOnly	=	NULL;

			ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));

			printf("\nPart_Rev %s and Part_rev_Id: %s\n",Part_Rev,Part_rev_Id);fflush(stdout);
			if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
			{
				RevFlag = 1;
			}
			printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
			if(RevFlag == 1)
			{
				RevOnly		= strtok( Part_Rev_copy, ";" );
				PreRevOnly	= strtok( Part_rev_Id, ";" );
				printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
				printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
				if(tc_strcmp(RevOnly,PreRevOnly)!=0)
				{
					PreRevFlag = 1;

				}
				if(PreRevFlag == 1)
				{
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					ITKCALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_prev_rev_Id));
					printf("\n Part_prev_rev_Id: %s\n",Part_prev_rev_Id);fflush(stdout);
					*t_previousRevision	=	rev_list[ii];
					break;
				}
			}
		}
		if(PreRevFlag == 0)
		{
			*t_previousRevision	=	t_currentRevision;
		}
	}
}
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int tm_check_SOR_ERCDML_Val_control_object ( char *syscd, char *subsyscd )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	ITK_CALL ( QRY_find2 ( "ControlObjQry",&query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values,&n_found,&cntr_objects ) ) ;
	printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
	TC_write_syslog ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	printf ("\n--------------tm_check_SOR_ERCDML_Val_control_object=Completed--------------------\n");fflush(stdout);
	return n_found ;
}
void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}
int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}
void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}


static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

int ITK_user_main(int argc, char* argv[])
{
    int ifail = 0;
	int noAttachment=0,i=0,zz=0, cnt=0;
	int  attype = 1,partcnt=0,k=0;
	int n_entry = 1;
	int Item_count =  0;
	int jj= 0;
	int j= 0;
	int ii =  0;
	int n_dtes = 0;
	int n_effectivities = 0;
	int count_status = 0;
	int rsltCount =  0;
	int n_tags_found2=0;

	char *job_name = NULL;
	char *job_name_new = NULL;
	char* parent_name =NULL;
	char* object_type =NULL;
	char* Analyst_name =NULL;
	char* DmlAnalyst_name =NULL;
	char* task_no =NULL;
	char* CurrentTask =NULL;
	char* TaskName =NULL;
	char* username =NULL;
	char* ImplbyTaskNo =NULL;
	char* token =NULL;
	char* Tasktoken =NULL;
	char* Part_no =NULL;
	char* parttype =NULL;
	char* ReleaseStatus =NULL;
	char* value =NULL;
	char *eff_date = NULL;
	char *ReviewStartDate=NULL;
	char cNextDate[20]={0};
	char cCurrentAccessDate[20]={0};
	char *DMLtype = NULL;
	char *info2 = NULL;
	char *info4 = NULL;
	char *info7 = NULL;
	char *cPartNo = NULL;
	char *Comobject_type = NULL;
	char *latest_rev_Rel_Stus = NULL;
	char *CMR_Rel_Stus = NULL;
	char *rev_idd = NULL;
	char *rel_status = NULL;
	char *status_name = NULL;
	char *EffvalueAfter = NULL;
	char *Effvalue = NULL;
	char *old_to_date = NULL;
	char *ObjClassName=NULL;
	char *dmlnob=NULL;
	char *ReleaseStatussvr=NULL;
	char *ReleaseStatussnap=NULL;
	char *relstatSVR=NULL;
	char *SVRtype=NULL;
	char *relstatspec=NULL;
	char *relstatsnap=NULL;
	char *relstatdoc=NULL;
	char *relstatdml=NULL;
	char *relstattsk=NULL;
	char *relstatbvr=NULL;
	char *relstatSOR=NULL;
	char *relstat4D=NULL;
	char *relstatDfmea=NULL;
	char *relstatassy=NULL;
	char *relstatAssy=NULL;
	char *relstatDMLTag=NULL;

	int status_count = 0;
	int RelStusFnd = 0;
	char * latest_rev_Rel_Stus1 = NULL;
	char * latest_rev_Rel_Stus2 = NULL;
	char * latest_rev_Rel_Stus3 = NULL;
	char * ReleaseStatusSpec = NULL;
	char * ReleaseStatusdoc = NULL;
	tag_t *relStatus_list = NULLTAG;
	tag_t *chkrelStatus_list = NULLTAG;
	tag_t attRelStatus = NULLTAG;
	tag_t *SVRsTag = NULLTAG;
	tag_t *sec_objectsSpec = NULLTAG;
	tag_t RelationFindTEchSpec = NULLTAG;
	tag_t release_statusSpec = NULLTAG;
	tag_t status_relSpec = NULLTAG;
	tag_t relationTagSpec = NULLTAG;
	tag_t RelationFindTEchSnap = NULLTAG;
	tag_t status_relSnap = NULLTAG;
	tag_t relationTagSnap = NULLTAG;
	tag_t RelationFindTEchdoc = NULLTAG;
	tag_t relationTagdoc = NULLTAG;
	tag_t release_statusdoc = NULLTAG;
	tag_t status_reldoc = NULLTAG;
	tag_t *sec_objectsSnap = NULLTAG;
	tag_t *sec_objectsdoc = NULLTAG;
	int k1 = 0;
	int k2 = 0;
	int k3 = 0;
	int num1 = 0;
	int delStat = 0;
	int SVRtcnt = 0;
	int s = 0;
	int sec_countSpec = 0;
	int sp = 0;
	int sec_countSnap = 0;
	int sn = 0;
	int sec_countdoc = 0;
	int sd = 0;

	logical retain_released_dateSpec;
	logical retain_released_datesnap;
	logical retain_released_datedoc;

	tag_t parent_task =NULLTAG;
	tag_t rootTask =NULLTAG;
	tag_t attachments =NULLTAG;
	tag_t Taskattachments =NULLTAG;
	tag_t item =NULLTAG;
	tag_t *Dml_Task_Tag =NULLTAG;
	tag_t *objTypeTagTask = NULLTAG;
	tag_t primary =NULLTAG;
	tag_t *secondary_objects =NULLTAG;
	tag_t remove = NULLTAG;
	tag_t user_tag =NULLTAG;
	tag_t job = NULLTAG;
	tag_t Analystusertag = NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t AssyTag = NULLTAG;
	tag_t PrtTag = NULLTAG;
	tag_t *Dml_tasks= NULLTAG;
	tag_t *PartsTag= NULLTAG;
	tag_t attach = NULLTAG;
	tag_t release_status =NULLTAG;
	tag_t superuserTag = NULLTAG;
	tag_t propEff_tag =NULLTAG;
	tag_t cmpropEff_tag =NULLTAG;
	tag_t *rev_list = NULLTAG;
	tag_t *effectivities_tag = NULLTAG;
	tag_t *status_lst = NULLTAG;
	tag_t LpropEff_tag = NULLTAG;
	tag_t Leff_d = NULLTAG;
	tag_t CMLeff_d = NULLTAG;
	tag_t *CntrlObjectTag = NULLTAG;
	tag_t qryTag = NULLTAG;
	tag_t AftpropEff_tag = NULLTAG;
	tag_t All_item_tag = NULLTAG;
	tag_t UpdateRlease_t1 = NULLTAG;
	tag_t UpdateRlease_t2 = NULLTAG;
	tag_t UpdateRlease_t3 = NULLTAG;
	tag_t *tags_found2 = NULL;
	tag_t TagClassId = NULLTAG;
	tag_t DMLToTaskReln = NULLTAG;
	tag_t eff_d = NULLTAG;
	tag_t item_tag = NULLTAG;
	tag_t release_statussvr = NULLTAG;
	tag_t release_statussnap = NULLTAG;

	date_t test_date_1;
	date_t cCurrent_date_1;
	date_t DayTommorow ;
	date_t test_date_2;
	date_t *start_end_date = NULL;
	logical  retain_released_date =TRUE;
	logical stat  ;
	date_t Ltest_date_2;
	date_t Ltest_date_1;
	date_t *Rel_start_end_values = NULL;
	date_t *Lstart_end_date = NULL;
	char *qry_entry[1] = {"SYSCD"};
	char **qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));
	WSOM_open_ended_status_t EFFECTIVITY_stock_out ;
	logical date_is_valid  ;
	logical stat1 ;
	logical retain_released_dateSVR ;

	const char *attrs2[2];
	const char *values2[2];

	dmlnob 		= ITK_ask_cli_argument("-dmlno=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	//strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	//sprintf(outputFile,"%s_output.txt",Data);

	/*if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}*/

	//ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nhey Login Successfull.....!!\n");fflush(stdout);
		printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
	}
	printf("\nAAAAAAAAAAA...!!\n");fflush(stdout); 
	//ifail = ITK_set_bypass(true);
	printf("\n BBBBBBBBBBBBB....!!\n");fflush(stdout);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}

	POM_get_user(&username,&user_tag);
	printf("\nStarting for taskbreskdownnn :%s....\n",username);fflush(stdout);

	//CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
	//printf("\n erc_dml_assignnnnnnnnnn \n"); fflush(stdout);

	//CALLAPI(AOM_ask_value_string(msg.task,"object_name",&CurrentTask));
	//printf("\nCurrentTask:%s\n",CurrentTask);

	//CALLAPI(AOM_ask_value_string(rootTask,"object_name",&parent_name));
	//printf("\nParent Name:%s\n",parent_name);fflush(stdout);

	getCurrentDateTime(cCurrentAccessDate);
	printf("\n added by :: skk - cCurrentAccessDate : %s\n",cCurrentAccessDate);

	if(QRY_find2("ControlObjects",&qryTag));
	if (qryTag)
	{
		printf("\n Eff:Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n Eff:Not Found Query ControlObjects \n");fflush(stdout);
	}

	qry_values2[0] = "CREVali";
	if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2,&rsltCount,&CntrlObjectTag));
	printf(" \n Eff:rsltCount :%d:", rsltCount); fflush(stdout);
	if(rsltCount > 0)
	{
		CALLAPI(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2));
		printf("\n Eff: info2 is  = [%s]\n", info4);fflush(stdout);

		CALLAPI(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo4",&info4));
		printf("\n Eff: info4 is  = [%s]\n", info4);fflush(stdout);

		CALLAPI(AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo7",&info7));
		printf("\n Eff: info7 is  = [%s]\n", info7);fflush(stdout);
	}
	//CALLAPI(SA_find_user2("infodba",&superuserTag));
	//CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));
	//printf("Target Attachment in erc_task_breakdown:[%d] \n",noAttachment);fflush(stdout);

	if(ITEM_find_item (dmlnob, &item_tag)!=ITK_ok)PrintErrorStack();


	if(ITEM_ask_latest_rev (item_tag, &attachments)!=ITK_ok)PrintErrorStack();

	tag_t objTypTag = NULLTAG;
	char* obj_type=NULL;
	

	
		
	if(TCTYPE_ask_object_type(attachments,&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&obj_type));
	printf("\n ********** erc_task_breakdown obj type: [%s]*************\n", obj_type);fflush(stdout);

	if (tc_strcmp(obj_type,"ChangeRequestRevision")==0)
	{
		DMLTag = attachments;
		//break;
	}

	
	if ( DMLTag != NULLTAG )
	{
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&DMLToTaskReln));
		CALLAPI(GRM_list_secondary_objects_only(DMLTag,DMLToTaskReln,&cnt,&Dml_tasks));
	}
	

	//CALLAPI( CR_create_release_status2("T5_LcsErcRlzd",&release_status));
	CALLAPI( RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
	CALLAPI( AOM_ask_name(release_status,&ReleaseStatus));



	CALLAPI(AOM_UIF_ask_value(DMLTag,"release_status_list",&relstatdml));
	printf("\nerc_breakdown---Dml Task relstatdml:%s ",relstatdml);fflush(stdout);

	if((strstr(relstatdml,"ERC Released")!=NULL)|| (strstr(relstatdml,"T5_LcsErcRlzd")!=NULL))
	{
		printf("\n Already found relstatdml, so skipped for DMLTag1...\n");  fflush(stdout);
	}
	else
	{

		if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
		{
			CALLAPI(RELSTAT_add_release_status(release_status,1,&DMLTag,retain_released_date));
		}
	}

	if(ITK_ok != (ifail = AOM_refresh( DMLTag, 0 )))
	{
		if(tc_strstr(info7,"CNT1") == NULL)
		{
			printf("\n ETB: Continue1");fflush(stdout);
			//continue;
		}
		else
		{
			printf("\nETB: return1\n");fflush(stdout);
			return ifail;
		}
	}

	if(POM_class_of_instance(DMLTag,&TagClassId));
	if(POM_name_of_class(TagClassId,&ObjClassName));
	printf("\n erc_breakdown---ObjClassName: %s",ObjClassName);

	if (tc_strcmp(ObjClassName,"ChangeRequestRevision")==0)
	{
		CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&DMLToTaskReln));
		CALLAPI(GRM_list_secondary_objects_only(DMLTag,DMLToTaskReln,&cnt,&Dml_tasks));

		CALLAPI(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype));
	}
	printf("\n erc_breakdown---Now cnt: %d of DMLType: [%s]\n",cnt,DMLtype);fflush(stdout);

	if (cnt>0)
	{
		for (zz=0;zz<cnt ;zz++ )
		{
			CALLAPI(AOM_ask_value_string(Dml_tasks[zz],"object_type",&object_type));
			printf("\n erc_breakdown---[zz= %d]: object_type is :%s  \n",zz,object_type);fflush(stdout);

			CALLAPI(AOM_ask_value_string(Dml_tasks[zz],"item_id",&task_no));
			printf("\n erc_breakdown---task_no is :%s  \n",task_no);fflush(stdout);

			if(strcmp(object_type,"T5_ChangeTaskRevision")==0)
			{
				getCurrentDateTime(cCurrentAccessDate);
				printf("\n erc_breakdown---cCurrentAccessDate : %s\n",cCurrentAccessDate);

                if(tc_strstr(info7,"REL2") == NULL)
				{
					if(strcmp(DMLtype,"Veh")==0)
					{
						if(strstr(task_no,"_00")!=NULL)
						{

							CALLAPI(AOM_ask_value_tags(Dml_tasks[zz],"CMReferences",&SVRtcnt,&SVRsTag));
							printf("\n erc_breakdown---Now SVRtcnt:%d ",SVRtcnt);fflush(stdout);

							if (SVRtcnt>0)
							{
								for (s=0; s<SVRtcnt; s++)
								{
									CALLAPI(AOM_UIF_ask_value(SVRsTag[s],"release_status_list",&relstatSVR));
									printf("\nerc_breakdown---Dml Task relstatSVR:%s ",relstatSVR);fflush(stdout);

									ITKCALL(AOM_UIF_ask_value(SVRsTag[s],"object_type",&SVRtype));
									printf("\n\t\t SVR Type is %s \n\n",SVRtype);  fflush(stdout);

									if (tc_strcmp(SVRtype,"VariantRule")==0)
									{
										if((strstr(relstatSVR,"ERC Released")!=NULL)|| (strstr(relstatSVR,"T5_LcsErcRlzd")!=NULL))
										{
											printf("\n Already found released relstatSVR, so skipped...\n");  fflush(stdout);
										}
										else
										{
											CALLAPI( RELSTAT_create_release_status("T5_LcsErcRlzd",&release_statussvr));
											CALLAPI( AOM_ask_name(release_statussvr,&ReleaseStatussvr));
											printf("\n erc_breakdown---Now ReleaseStatussvr:%s ",ReleaseStatussvr);fflush(stdout);

											CALLAPI(AOM_UIF_ask_value(SVRsTag[s],"release_status_list",&relstatSVR));
											printf("\nerc_breakdown---Dml Task relstatSVR:%s ",relstatSVR);fflush(stdout);

											if((strcmp(ReleaseStatussvr,"ERC Released")==0)||strcmp(ReleaseStatussvr,"T5_LcsErcRlzd")==0)
											{
												CALLAPI(RELSTAT_add_release_status(release_statussvr,1,&SVRsTag[s],retain_released_dateSVR));
											}
											
											if(ITK_ok != (ifail = AOM_refresh( SVRsTag[s], 0 )))
											{
												if(tc_strstr(info7,"CNT1") == NULL)
												{
													printf("\n erc_breakdown---SVR: Continue2");fflush(stdout);
													continue;
												}
												else
												{
													printf("\n erc_breakdown---SVR: return2");fflush(stdout);
													return ifail;
												}
											}
										}
									}
								}
							}
						}
					}
				}

				//CALLAPI( CR_create_release_status2("T5_LcsErcRlzd",&release_status));
				CALLAPI( RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
				CALLAPI( AOM_ask_name(release_status,&ReleaseStatus));

				CALLAPI(AOM_UIF_ask_value(Dml_tasks[zz],"release_status_list",&relstattsk));
				printf("\nerc_breakdown---Dml Task relstattsk:%s ",relstattsk);fflush(stdout);

				
				if((strstr(relstattsk,"ERC Released")!=NULL)|| (strstr(relstattsk,"T5_LcsErcRlzd")!=NULL))
				{
					printf("\n Already found released relstattsk, so skipped...\n");  fflush(stdout);
				}
				else
				{
					if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0  )
					{
						CALLAPI(RELSTAT_add_release_status(release_status,1,&Dml_tasks[zz],retain_released_date));
					}
				}
				if(ITK_ok != (ifail = AOM_refresh( Dml_tasks[zz], 0 )))
				{
					if(tc_strstr(info7,"CNT1") == NULL)
					{
						printf("\n erc_breakdown---ETB: Continue2");fflush(stdout);
						continue;
					}
					else
					{
						printf("\n erc_breakdown---ETB: return2");fflush(stdout);
						return ifail;
					}
				}

				CALLAPI(AOM_UIF_ask_value(Dml_tasks[zz],"Analyst",&DmlAnalyst_name));
				printf("\nerc_breakdown---Dml Task Analyst_name:%s ",DmlAnalyst_name);fflush(stdout);

				CALLAPI(AOM_ask_value_tags(Dml_tasks[zz],"CMHasSolutionItem",&partcnt,&PartsTag));
				printf("\n erc_breakdown---Now partcnt:%d ",partcnt);fflush(stdout);

				if (partcnt>0)
				{
					for (k=0; k<partcnt; k++)
					{
						printf("\n erc_breakdown---for k= %d ",k);fflush(stdout);
						AssyTag=PartsTag[k];

						CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
						CALLAPI(AOM_ask_value_string(AssyTag,"t5_PartType",&parttype));
						printf("\n erc_breakdown--- [k=%d ]Part_no:[%s] parttype [%s] DMLType:[%s] DMLtaskno:[%s]",k,Part_no,parttype,DMLtype,task_no);fflush(stdout);


						printf("\n erc_breakdown---In If Condn--info4 is  = [%s] ", info4);fflush(stdout);

						if(tc_strstr(info4,"EFFECTIVITY") == NULL)
						{
							int status_count=0;
							int ss=0;
							int ERCStatusFlg=0;
							int ERCReviewStatusFlg=0;
							tag_t* relStatus_list;
							int ERCRelFlag=0;

							getCurrentDateTime(cCurrentAccessDate);
							printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
							if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate,&Ltest_date_2 )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue3");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return3");fflush(stdout);
									return ifail;
								}
							}

							if((strcmp(DMLtype,"Veh")==0)||(strcmp(DMLtype,"MR")==0)||(strcmp(DMLtype,"TSKR")==0)||(strcmp(DMLtype,"DFMR")==0)||(strcmp(DMLtype,"EP")==0)||(strcmp(DMLtype,"CP")==0)||(strcmp(DMLtype,"CM")==0)||(strcmp(DMLtype,"EIDL")==0)||(strcmp(DMLtype,"VPL")==0))
							{
								printf("\n erc_breakdown---Eff:Setting effectivity on latest released revision!!\n");fflush(stdout);
								CALLAPI(AOM_UIF_ask_value (AssyTag, "item_id",&cPartNo));

								CALLAPI(WSOM_ask_release_status_list(AssyTag,&status_count,&relStatus_list));	//Added by RRR on 02.10.2018
								if (status_count > 0)
								{
									for(ss=0; ss<status_count ; ss++)
									{
										CALLAPI(AOM_ask_value_string(relStatus_list[ss],"object_name",&latest_rev_Rel_Stus));
										printf("\n erc_breakdown---latest_rev_Rel_Stus: %s",latest_rev_Rel_Stus);fflush(stdout);

										if((strcmp(latest_rev_Rel_Stus,"ERC Review")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsReview")==0))
										{
											ERCReviewStatusFlg ++;

											//if(ITK_ok != (ifail = PROP_ask_property_by_name(relStatus_list[ss],"effectivity_text",&propEff_tag)))	 return ifail;
											//CALLAPI(PROP_ask_property_by_name(relStatus_list[ss],"effectivity_text",&propEff_tag));14.3
											//if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))	 return ifail;
											//CALLAPI(PROP_ask_value_string(propEff_tag,&value));
											
											CALLAPI(AOM_ask_value_string(relStatus_list[ss],"effectivity_text",&value));
											printf("\n erc_breakdown---erc_breakdown---ERCReview--effectivity_text is value : %s",value); fflush(stdout);

											printf("\n erc_breakdown---ERCReview--effectivity_text is length : %d",strlen(value)); fflush(stdout);

											if(tc_strlen(value) == 0)
											{
												if( AOM_UIF_ask_value (AssyTag, "creation_date",&value)!=ITK_ok);  //rev_CreDt
												printf("\nERCReview--creation_date----value:::: [%s]", value);fflush(stdout);
											}
											printf("\nerc_breakdown---ERCReview--StartDate: [%s]   EndDate:[%s]", value,cCurrentAccessDate);fflush(stdout);
											if(tc_strlen(value) == 0)
											{
												printf("  --Skipping from ERC Review validation as blank.....\n");fflush(stdout);
												continue;  // skipping this case if value found NULL/Blank
											}
											else
											{
												ReviewStartDate=subString(value,0,17);
												printf("\n ERCReview--ReviewStartDate: %s",ReviewStartDate); fflush(stdout);

												if(ITK_ok != (ifail = DATE_string_to_date_t(ReviewStartDate,&date_is_valid,&Ltest_date_1 )))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue4");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return4");fflush(stdout);
														return ifail;
													}
												}

												Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
												Lstart_end_date[0] = Ltest_date_1;
												Lstart_end_date[1] = Ltest_date_2;

												printf("\n ERCReview--EFF:Clearing effectivities...");fflush(stdout);
												if(ITK_ok != (ifail = WSOM_status_clear_effectivities (relStatus_list[ss])))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue5");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return5");fflush(stdout);
														return ifail;
													}
												}

												printf("\n ERCReview--EFF:Creating effectivities...");fflush(stdout);
												if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(relStatus_list[ss], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed,&Leff_d )))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue6");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return6");fflush(stdout);
														return ifail;
													}
												}
												printf("\n ERCReview--EFF:Saving effectivities...");fflush(stdout);
												if(ITK_ok != (ifail = AOM_save_without_extensions(Leff_d)))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue7");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return7");fflush(stdout);
														return ifail;
													}
												}
												printf("\n ERCReview--EFF:Saving Revision...");fflush(stdout);
												if(ITK_ok != (ifail = AOM_save_without_extensions(relStatus_list[ss])))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue8");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return8");fflush(stdout);
														return ifail;
													}
												}
												printf("\n ERCReview--EFF:Refreshing Revision...");fflush(stdout);
												if(ITK_ok != (ifail = AOM_refresh( relStatus_list[ss], 0 )))
												{
													if(tc_strstr(info7,"CNT1") == NULL)
													{
														printf("\n erc_breakdown---ETB: Continue9");fflush(stdout);
														continue;
													}
													else
													{
														printf("\n erc_breakdown---ETB: return9");fflush(stdout);
														return ifail;
													}
												}
											}
										}

										if((strcmp(latest_rev_Rel_Stus,"ERC Released")==0) || (strcmp(latest_rev_Rel_Stus,"T5_LcsErcRlzd")==0))
										{
										   ERCStatusFlg ++;
										}
									}
								}

								printf("\n Eff:Part no:[%s]  latest_rev_Rel_Stus:[%s]  ERCStatusFlg: [%d] ",cPartNo,latest_rev_Rel_Stus,ERCStatusFlg);fflush(stdout);

								if ((tc_strstr(latest_rev_Rel_Stus, "ERC Released") == NULL) && (ERCStatusFlg == 0)) //Added by RRR on 02.10.2018
								{
									CALLAPI(AOM_UIF_ask_value (AssyTag, "object_type",&Comobject_type));//Added for EE_Part(kalpesh_14_sept19)
									printf("\n Comobject_type found:%s cPartNo: %s ", Comobject_type,cPartNo);fflush(stdout);

									attrs2[0] ="item_id";
									attrs2[1] ="object_type";
									values2[0] = (char *)cPartNo;
									if(tc_strcmp(Comobject_type, "EE Part Revision") == 0)
									{
										values2[1] = "T5_EE_Part";
									}else if (tc_strcmp(Comobject_type, "Colour Part Revision") == 0)
									{
										values2[1] = "T5_ClrPart";
									}else
									{
										values2[1] = "Design";
									}
									CALLAPI(ITEM_find_items_by_key_attributes(2,attrs2, values2,&n_tags_found2,&tags_found2)!=ITK_ok)PrintErrorStack();
									printf("\n n_tags_found2: %d", n_tags_found2);fflush(stdout);


									if (n_tags_found2>0)
									{
										All_item_tag= tags_found2[0];

										CALLAPI(ITEM_list_all_revs (All_item_tag,&Item_count,&rev_list));
										printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
									}

									if(Item_count > 0)
									{
										for(ii=Item_count-1;ii>=0;ii--)
										{
											CALLAPI(AOM_UIF_ask_value (rev_list[ii], "item_revision_id",&rev_idd));
											printf("\n Eff: Latest released rev is:%s.", rev_idd);fflush(stdout);

											CALLAPI(WSOM_ask_release_status_list (rev_list[ii],&count_status,&status_lst));
											printf("\n Eff: count_status is:%d.", count_status);fflush(stdout);
											if(count_status > 0)
											{
												for(j=0;j<count_status;j++)
												{
													ERCRelFlag=0;
													CALLAPI(AOM_ask_value_string(status_lst[j], "object_name",&status_name));
													printf("\n Eff: Release Status name:%s", status_name);fflush(stdout);
													if((tc_strstr(status_name,"ERC Released")!=NULL) ||tc_strstr(status_name,"T5_LcsErcRlzd")!=NULL)
													{
														printf("\n Eff:Status name:%s for rev:%s\n", status_name, rev_idd);
														if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat1)))	 return ifail;
														printf("\n Eff:stat1:%d",stat1);fflush(stdout);

														if(stat1 != true)
														{
															printf("\n Eff:stat1 is not true .....");fflush(stdout);
														}
														else
														{
															printf("\n Eff:stat1 is  true .....");fflush(stdout);
														}

														//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&LpropEff_tag))) return ifail;
														//if(ITK_ok != (ifail = PROP_ask_value_string(LpropEff_tag,&Effvalue)))	 return ifail;14.3
														CALLAPI(AOM_ask_value_string(status_lst[j],"effectivity_text",&Effvalue));
														
														printf("\n Eff:effectivity_text Effvalue..: %s",Effvalue);fflush(stdout);

														if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_lst[j],&n_effectivities,&effectivities_tag) )) return ifail;
														printf("\n Eff:n_effectivities count:[%d] ",n_effectivities);fflush(stdout);
														if(n_effectivities > 0)
														{
															for(jj=0;jj<n_effectivities;jj++)
															{
														       //if(ITK_ok != (ifail = WSOM_effectivity_ask_dates(effectivities_tag[jj],&n_dtes,&Rel_start_end_values,&EFFECTIVITY_stock_out )))return ifail;14.3
																
																if(ITK_ok != (ifail = WSOM_eff_ask_dates(status_lst[j],effectivities_tag[jj],&n_dtes,&Rel_start_end_values,&EFFECTIVITY_stock_out )))return ifail;
																printf("\n Eff:no of Rel_start_end_value:%d", n_dtes);fflush(stdout);
																if(n_dtes > 0)
																{
																	if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M",&old_to_date )))
																	{
																		if(tc_strstr(info7,"CNT1") == NULL)
																		{
																			printf("\n erc_breakdown---ETB: Continue10");fflush(stdout);
																			continue;
																		}
																		else
																		{
																			printf("\n erc_breakdown---ETB: return10");fflush(stdout);
																			return ifail;
																		}
																	}
																	printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
																	if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date,&date_is_valid,&Ltest_date_1 )))
																	{
																		if(tc_strstr(info7,"CNT1") == NULL)
																		{
																			printf("\n erc_breakdown---ETB: Continue11");fflush(stdout);
																			continue;
																		}
																		else
																		{
																			printf("\n erc_breakdown---ETB: return11");fflush(stdout);
																			return ifail;
																		}
																	}
																	printf(" and  DATE_string_to_date_t..");fflush(stdout);
																	if(date_is_valid != true)
																	{
																		printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
																	}
																	else
																	{
																		printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
																	}
																}
																else
																{
																	printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
																}
															}
														}

														printf("\n EFF:ITK_string_to_date..2");fflush(stdout);
														Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
														Lstart_end_date[0] = Ltest_date_1;
														Lstart_end_date[1] = Ltest_date_2;

														printf("\n EFF:Clearing effectivities...");fflush(stdout);

														if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( status_lst[j])))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue12");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return12");fflush(stdout);
																return ifail;
															}
														}
														printf("\n EFF:Creating effectivities...");fflush(stdout);
														if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_lst[j], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed,&Leff_d )))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue13");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return13");fflush(stdout);
																return ifail;
															}
														}
														printf("\n EFF:Saving effectivities...");fflush(stdout);
														if(ITK_ok != (ifail = AOM_save_without_extensions(Leff_d)))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue14");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return14");fflush(stdout);
																return ifail;
															}
														}
														printf("\n EFF:Saving Revision...");fflush(stdout);
														if(ITK_ok != (ifail = AOM_save_without_extensions(status_lst[j])))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue15");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return15");fflush(stdout);
																return ifail;
															}
														}
														printf("\n EFF:Refreshing Revision...");fflush(stdout);
														if(ITK_ok != (ifail = AOM_refresh( status_lst[j], 0 )))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue16");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return16");fflush(stdout);
																return ifail;
															}
														}
														printf("\n EFF:Checking effectivities txt...");fflush(stdout);
														//if(ITK_ok != (ifail = PROP_ask_property_by_name(status_lst[j],"effectivity_text",&AftpropEff_tag)))return ifail;
														//if(ITK_ok != (ifail = PROP_ask_value_string(AftpropEff_tag,&EffvalueAfter)))return ifail;14.3
														CALLAPI(AOM_ask_value_string(status_lst[j],"effectivity_text",&EffvalueAfter));
														printf("\n Eff:effectivity_text EffvalueAfter : %s ",EffvalueAfter);fflush(stdout);
														if(ITK_ok != (ifail = AOM_refresh( rev_list[ii], 0 )))
														{
															if(tc_strstr(info7,"CNT1") == NULL)
															{
																printf("\n erc_breakdown---ETB: Continue17");fflush(stdout);
																continue;
															}
															else
															{
																printf("\n erc_breakdown---ETB: return17");fflush(stdout);
																return ifail;
															}
														}

														ERCRelFlag=1;

														break;  //Added on 19.10.2018 for multiple release status
													}
													else
													{
														printf("\n Eff: Status name:%s for rev: %s ", status_name, rev_idd); fflush(stdout);
													}
													MEM_free(status_name);
												}
											}
											else
											{
												printf("\n Eff:Status not found on revision %s...!!",rev_idd);fflush(stdout);
											}

											if (ERCRelFlag>0)
											{
												break;
											}
										}
									}
								}
								else
								{
									printf("\n EFF:part already released.");fflush(stdout);
								}
							}
						}
						printf("\n erc_breakdown: VC DR-status logic. \n");fflush(stdout);
						if((strcmp(DMLtype,"Veh")==0) && ((strcmp(parttype,"V") == 0)||(strcmp(parttype,"Vehicle") == 0)))
						{
							printf("\n erc_breakdown: Inside DML: type Veh & Part type Vehicle \n");fflush(stdout);
							int BU_n_entry = 1;
							int BU_rsltCount = 0;
							char *BUInfo4 = NULL;
							char *VCpartDR = NULL;
							char *partDR = NULL;
							char *VCnm = NULL;
							char *BU_qry_entry[1] = {"SYSCD"};
							VCnm =  (char *) MEM_alloc(10 * sizeof(char));
							char **BU_qry_values2 =  (char **) MEM_alloc(50 * sizeof(char *));
							tag_t VCTag = NULLTAG;
							tag_t VCLatsRev = NULLTAG;
							tag_t BUqryTag = NULLTAG;
							tag_t *BUntrlObjectTag = NULLTAG;
							if(QRY_find2("ControlObjects",&BUqryTag));
							if (BUqryTag)
							{
								printf("\n erc_breakdown:Found Query ControlObjects \n");fflush(stdout);
							}
							else
							{
								printf("\n erc_breakdown:Not Found Query ControlObjects \n");fflush(stdout);
							}

							BU_qry_values2[0] = "VCDmlBU";

							if(QRY_execute(BUqryTag, BU_n_entry, BU_qry_entry, BU_qry_values2,&BU_rsltCount,&BUntrlObjectTag));
							printf(" \nerc_breakdown::BU_rsltCount :%d:", BU_rsltCount); fflush(stdout);
							if(BU_rsltCount > 0)
							{
								//ON/OFF
								if (AOM_ask_value_string(BUntrlObjectTag[0],"t5_Userinfo4",&BUInfo4)!=ITK_ok)   PrintErrorStack();
								printf("\n erc_breakdown:BUInfo4 is  = [%s]",BUInfo4);fflush(stdout);
							}
							if(tc_strstr(BUInfo4,"DRON")==NULL)
							{
								strncpy(VCnm,Part_no,8);
								tc_strcat(VCnm,"000R");
								printf("\n erc_breakdown:Found VC number = [%s]",VCnm);fflush(stdout);
								if(ITEM_find_item(VCnm,&VCTag));
								if(ITEM_ask_latest_rev(VCTag,&VCLatsRev));
								if (VCLatsRev != NULLTAG)
								{
									if(AOM_ask_value_string(AssyTag,"t5_PartStatus",&partDR));
									if(AOM_ask_value_string(VCLatsRev,"t5_PartStatus",&VCpartDR));
									printf("\n erc_breakdown--- [k=%d ]Part_no:[%s] parttype [%s] V PartDR [%s] & VC number [%s] VC DR status",k,Part_no,parttype,partDR,VCnm,VCpartDR);

									if (strcmp(partDR,"DR1")==0 && (strcmp(VCpartDR,"DR0")==0))
									{
										printf("\n erc_breakdown:Updating VCnm = [%s] DR status to DR1",VCnm);fflush(stdout);
										CALLAPI(AOM_refresh(VCLatsRev,1));
										if(AOM_set_value_string(VCLatsRev, "t5_PartStatus", "DR1")!=ITK_ok)   PrintErrorStack();
										CALLAPI(AOM_save_without_extensions( VCLatsRev) )
										CALLAPI(AOM_refresh(VCLatsRev,0));
									}
									if (strcmp(partDR,"DR2")==0 && (strcmp(VCpartDR,"DR1")==0 || strcmp(VCpartDR,"DR0")==0))
									{
										printf("\n erc_breakdown:Updating VCnm = [%s] DR status to DR2",VCnm);fflush(stdout);
										CALLAPI(AOM_refresh(VCLatsRev,1));
										if(AOM_set_value_string(VCLatsRev, "t5_PartStatus", "DR2")!=ITK_ok)   PrintErrorStack();
										CALLAPI(AOM_save_without_extensions( VCLatsRev) )
										CALLAPI(AOM_refresh(VCLatsRev,0));
									}
									if (strcmp(partDR,"DR3")==0 && (strcmp(VCpartDR,"DR2")==0 || strcmp(VCpartDR,"DR1")==0 || strcmp(VCpartDR,"DR0")==0))
									{
										printf("\n erc_breakdown:Updating VCnm = [%s] DR status to DR3",VCnm);fflush(stdout);
										CALLAPI(AOM_refresh(VCLatsRev,1));
										if(AOM_set_value_string(VCLatsRev, "t5_PartStatus", "DR3")!=ITK_ok)   PrintErrorStack();
										CALLAPI(AOM_save_without_extensions( VCLatsRev) )
										CALLAPI(AOM_refresh(VCLatsRev,0));
									}
									if (strcmp(partDR,"DR4")==0 && (strcmp(VCpartDR,"DR3")==0 || strcmp(VCpartDR,"DR2")==0 || strcmp(VCpartDR,"DR1")==0 || strcmp(VCpartDR,"DR0")==0))
									{
										printf("\n erc_breakdown:Updating VCnm = [%s] DR status to DR4",VCnm);fflush(stdout);
										CALLAPI(AOM_refresh(VCLatsRev,1));
										if(AOM_set_value_string(VCLatsRev, "t5_PartStatus", "DR4")!=ITK_ok)   PrintErrorStack();
										CALLAPI(AOM_save_without_extensions( VCLatsRev) )
										CALLAPI(AOM_refresh(VCLatsRev,0));
									}
									if (strcmp(partDR,"DR5")==0 && (strcmp(VCpartDR,"DR4")==0 || strcmp(VCpartDR,"DR3")==0 || strcmp(VCpartDR,"DR2")==0 || strcmp(VCpartDR,"DR1")==0 || strcmp(VCpartDR,"DR0")==0))
									{
										printf("\n erc_breakdown:Updating VCnm = [%s] DR status to DR5",VCnm);fflush(stdout);
										CALLAPI(AOM_refresh(VCLatsRev,1));
										if(AOM_set_value_string(VCLatsRev, "t5_PartStatus", "DR5")!=ITK_ok)   PrintErrorStack();
										CALLAPI(AOM_save_without_extensions( VCLatsRev) )
										CALLAPI(AOM_refresh(VCLatsRev,0));
									}
								}
							}
						}
						//PSS918119 - Release stamping on BVR

						int bvr_count = 0;
						int count = 0;
						char *NameOfObjTyp = NULL;
						char *NameOfbvrObjTyp = NULL;
						char *ReleaseStatusBVR = NULL;
						char *ReleaseStatusBVR1 = NULL;
						tag_t bvrsTypeTag = NULLTAG;
						tag_t *bvrs = NULLTAG;
						tag_t release_statusBVR = NULLTAG;
						tag_t release_statusBVR1 = NULLTAG;
						tag_t *secObjsList = NULLTAG;
						tag_t Tag_Name = NULLTAG;
						tag_t objNameType = NULLTAG;

						if(ITEM_rev_list_bom_view_revs( AssyTag,&bvr_count,&bvrs));
						printf("\n BVR Obj Count is---[%d]", bvr_count);
						if (bvr_count > 0)
						{
							for(ii=0;ii<bvr_count;ii++)
							{
								printf("\nFor Loop started");fflush(stdout);
								TCTYPE_ask_object_type(bvrs[ii] ,&bvrsTypeTag);
								TCTYPE_ask_name2(bvrsTypeTag,&NameOfbvrObjTyp);
								printf("\nObject Type of Found is %s ",NameOfbvrObjTyp);fflush(stdout);
								//ifail =( CR_create_release_status2("T5_LcsErcRlzd",&release_statusBVR));
								ifail =( RELSTAT_create_release_status("T5_LcsErcRlzd",&release_statusBVR));
								ifail =( AOM_ask_name(release_statusBVR,&ReleaseStatusBVR));

								CALLAPI(AOM_UIF_ask_value(bvrs[ii],"release_status_list",&relstatbvr));
								printf("\nerc_breakdown---Dml Task relstatbvr:%s ",relstatbvr);fflush(stdout);

								
								if((strstr(relstatbvr,"ERC Released")!=NULL)|| (strstr(relstatbvr,"T5_LcsErcRlzd")!=NULL))
								{
									printf("\n Already found released relstatbvr, so skipped...\n");  fflush(stdout);
								}
								else
								{
									if((strcmp(ReleaseStatusBVR,"ERC Released")==0)||strcmp(ReleaseStatusBVR,"T5_LcsErcRlzd")==0 )
									{
										RELSTAT_add_release_status(release_statusBVR,1,&bvrs[ii],retain_released_date);
										printf("\nRelease stamping marked on BVR Object:: [%s]\n",NameOfbvrObjTyp);fflush(stdout);
									}
								}
							}
						}
						else
						{
							printf("\nBOM View Rev not found for the Item  [%s], task no [%s] \n",Part_no,task_no);fflush(stdout);
						}

						ifail = GRM_list_secondary_objects_only(AssyTag, NULLTAG,&count,&secObjsList);
						printf("\n secObjCnt---[%d]\n", count);fflush(stdout);

						if (count > 0)
						{
							for (i=0; i<count;i++ )
							{
								Tag_Name= secObjsList[i];
								TCTYPE_ask_object_type(Tag_Name,&objNameType);
								if(objNameType != NULLTAG)
								{
									TCTYPE_ask_name2(objNameType,&NameOfObjTyp);
									printf("\n[%d]Sec Object Type is %s \n",i,NameOfObjTyp);fflush(stdout);
									if ((tc_strcmp(NameOfObjTyp,"CMI2Product")==0) ||(tc_strcmp(NameOfObjTyp,"CMI2Part")==0)||(tc_strcmp(NameOfObjTyp,"CMI2Drawing")==0)||(tc_strcmp(NameOfObjTyp,"DirectModel")==0)||(tc_strcmp(NameOfObjTyp,"ProAsm")==0)||
											(tc_strcmp(NameOfObjTyp,"ProPrt")==0)||(tc_strcmp(NameOfObjTyp,"ProDrw")==0)||(tc_strcmp(NameOfObjTyp,"PDF")==0)||(tc_strcmp(NameOfObjTyp,"T5_IndepBin")==0))
									{
										printf("\n Found Sec obj is of type ::[%s]\n", NameOfObjTyp);fflush(stdout);
										//ifail =( CR_create_release_status2("T5_LcsErcRlzd",&release_statusBVR1));
										ifail =( RELSTAT_create_release_status("T5_LcsErcRlzd",&release_statusBVR1));
										ifail =( AOM_ask_name(release_statusBVR1,&ReleaseStatusBVR1));

										CALLAPI(AOM_UIF_ask_value(Tag_Name,"release_status_list",&relstatbvr));
										printf("\nerc_breakdown---Dml Task relstatbvr:%s ",relstatbvr);fflush(stdout);

										
										if((strstr(relstatbvr,"ERC Released")!=NULL)|| (strstr(relstatbvr,"T5_LcsErcRlzd")!=NULL))
										{
											printf("\n Already found released relstatbvr, so skipped...\n");  fflush(stdout);
										}
										else
										{
											if((strcmp(ReleaseStatusBVR1,"ERC Released")==0)||strcmp(ReleaseStatusBVR1,"T5_LcsErcRlzd")==0 )
											{
												ifail =(RELSTAT_add_release_status(release_statusBVR1,1,&Tag_Name,retain_released_date));
												printf("\n Release staming done on Sec Object type ::[%s]\n", NameOfObjTyp);fflush(stdout);
											}
										}
									}
								}
							}
						}

						/********SOR Release Status stamping*******/
						int SOR_ERCDML_Val = 0;

						SOR_ERCDML_Val = tm_check_SOR_ERCDML_Val_control_object ( "SORERCDMLVAL" , "ON" );

						if ( SOR_ERCDML_Val > 0)
						{
							printf("\n erc_breakdown--A-SOR Release Status stamping");fflush(stdout);
							TC_write_syslog("\n erc_breakdown--A-SOR Release Status stamping");fflush(stdout);

							int status_part_SOR_cnt = 0;
							int status_prt_c = 0;

							char *status_part_SOR_num = NULL;
							char *status_rel_part_SOR = NULL;
							char *SOR_numbers = NULL;
							logical  retain_released_date_SOR = TRUE;

							tag_t status_Part_SOR_Tag = NULLTAG;
							tag_t status_part_SOR_Rel = NULLTAG;
							tag_t *status_part_SOR_objects = NULLTAG;
							tag_t status_rel_SOR = NULLTAG;
							tag_t release_status_SOR = NULLTAG;

							ITK_CALL(GRM_find_relation_type("T5_PartSorRel",&status_part_SOR_Rel));
							printf("\n erc_breakdown--A-Expanding Part to SOR relation");fflush(stdout);
							TC_write_syslog("\nExpanding Part to SOR relation");fflush(stdout);
							ITK_CALL(GRM_list_secondary_objects_only(AssyTag, status_part_SOR_Rel,&status_part_SOR_cnt,&status_part_SOR_objects));
							printf("\n erc_breakdown--A-status_part_SOR_cnt : [%d]\n",status_part_SOR_cnt);fflush(stdout);
							TC_write_syslog("\nstatus_part_SOR_cnt : [%d]\n",status_part_SOR_cnt);fflush(stdout);

							if ( status_part_SOR_cnt > 0)
							{
								for ( status_prt_c = 0; status_prt_c < status_part_SOR_cnt; status_prt_c++ )
								{
									status_Part_SOR_Tag= status_part_SOR_objects[status_prt_c];
									ITK_CALL(AOM_UIF_ask_value(status_Part_SOR_Tag,"item_id",&status_part_SOR_num));
									ITK_CALL(AOM_UIF_ask_value(status_Part_SOR_Tag,"release_status_list",&status_rel_part_SOR));
									printf("\nstatus_part_SOR_num : [%s]\tstatus_rel_part_SOR : [%s]",status_part_SOR_num,status_rel_part_SOR);fflush(stdout);
									TC_write_syslog("\nstatus_part_SOR_num : [%s]\tstatus_rel_part_SOR : [%s]",status_part_SOR_num,status_rel_part_SOR);fflush(stdout);
									printf("\n erc_breakdown--A-status_rel_part_SOR : [%s]\n", status_rel_part_SOR);fflush(stdout);
									TC_write_syslog("\n erc_breakdown--A-status_rel_part_SOR : [%s]\n", status_rel_part_SOR);fflush(stdout);

									if((tc_strcmp ( status_rel_part_SOR,"ERC Review" )==0) || (tc_strcmp( status_rel_part_SOR,"T5_LcsReview" )==0) )
									{
										//ITK_CALL ( CR_create_release_status2("T5_LcsErcRlzd",&status_rel_SOR));
										ITK_CALL ( RELSTAT_create_release_status("T5_LcsErcRlzd",&status_rel_SOR));

										CALLAPI(AOM_UIF_ask_value(status_Part_SOR_Tag,"release_status_list",&relstatSOR));
										printf("\nerc_breakdown---Dml Task relstatSOR:%s ",relstatSOR);fflush(stdout);

										
										if((strstr(relstatSOR,"ERC Released")!=NULL)|| (strstr(relstatSOR,"T5_LcsErcRlzd")!=NULL))
										{
											printf("\n Already found released relstatSOR, so skipped...\n");  fflush(stdout);
										}
										else
										{
											ITK_CALL(RELSTAT_add_release_status(status_rel_SOR,1,&status_Part_SOR_Tag ,retain_released_date_SOR));
										}
										printf("\n erc_breakdown--A-ERC released stamping on SOR : [%s]\n", status_part_SOR_num);fflush(stdout);
										TC_write_syslog("\n erc_breakdown--A-ERC released stamping on SOR : [%s]\n", status_part_SOR_num);fflush(stdout);

									}
								}
							}
						}
						// Adi add 4D Doc rel status START here 2021

						tag_t RelationFind4D = NULLTAG;
						tag_t RelationFindDfmea = NULLTAG;
						tag_t relationTag4D = NULLTAG;
						tag_t relationTagDfmea = NULLTAG;
						int sec_count4D = 0;
						int sec_countDfmea = 0;
						int iQ = 0;
						int dQ = 0;
						tag_t *sec_objects = NULLTAG;
						tag_t *sec_objectsDfmea = NULLTAG;
						logical retain_released_date4D = TRUE;
						logical retain_released_dateDfmea = TRUE;
						tag_t release_status4D = NULLTAG;
						tag_t release_statusDfmea = NULLTAG;
						tag_t status_rel4D = NULLTAG;
						tag_t status_relDfmea = NULLTAG;
						char* ReleaseStatus4D = NULL;
						char* ReleaseStatusDfmea = NULL;

						if(GRM_find_relation_type("T5_PartHas4D",&RelationFind4D));
						if (RelationFind4D!=NULLTAG)
						{
							printf("\n erc_breakdown--A-Inside for 4D After finding RelType ");fflush(stdout);
							CALLAPI(GRM_list_secondary_objects_only(AssyTag, RelationFind4D,&sec_count4D,&sec_objects));
							printf("\n erc_breakdown--A-for 4D Total objects found sec_count4D------[%d]", sec_count4D);

							if(sec_count4D > 0)
							{
								printf("\n erc_breakdown--A-inside sec_count4D find  --------- [%d]", sec_count4D);fflush(stdout);
								for(iQ=0;iQ<sec_count4D;iQ++)
								{
									relationTag4D=sec_objects[iQ];
									printf("\n erc_breakdown--A-inside sec count find IQ---------");fflush(stdout);

									if (relationTag4D != NULLTAG)
									{
										//CALLAPI( CR_create_release_status2("T5_LcsReview",&release_status4D));
										CALLAPI( RELSTAT_create_release_status("T5_LcsReview",&release_status4D));
										CALLAPI( AOM_ask_name(release_status4D,&ReleaseStatus4D));
										printf("\n erc_breakdown--A-ReleaseStatus4D ----------[%s]", ReleaseStatus4D);fflush(stdout);

										if((strcmp(ReleaseStatus4D,"ERC Review")==0)||strcmp(ReleaseStatus4D,"T5_LcsReview")==0 )
										{
											printf("\n erc_breakdown--A-BEFORE epm add rel status ERC released ");fflush(stdout);
											printf("\n erc_breakdown--A-before removing all rel status ---------");fflush(stdout);
											//t5removeAllReleaseStatus(relationTag4D);
											//CALLAPI ( CR_create_release_status2("T5_LcsErcRlzd",&status_rel4D));
											CALLAPI ( RELSTAT_create_release_status("T5_LcsErcRlzd",&status_rel4D));

											CALLAPI(AOM_UIF_ask_value(relationTag4D,"release_status_list",&relstat4D));
											printf("\nerc_breakdown---Dml Task relstat4D:%s ",relstat4D);fflush(stdout);

											
											if((strstr(relstat4D,"ERC Released")!=NULL)|| (strstr(relstat4D,"T5_LcsErcRlzd")!=NULL))
											{
												printf("\n Already found released relstat4D, so skipped...\n");  fflush(stdout);
											}
											else
											{
												CALLAPI(RELSTAT_add_release_status(status_rel4D,1,&relationTag4D,retain_released_date4D));
											}
											printf("\n erc_breakdown--A-after adding rel status ERC Released 4d return 0---------");fflush(stdout);
										}
									}
								}
							}
						}

						if(GRM_find_relation_type("T5_PartHasDfmea",&RelationFindDfmea));
						if (RelationFindDfmea!=NULLTAG)
						{
							printf("\n erc_breakdown--B-Inside for 4D After finding RelType ");fflush(stdout);
							CALLAPI(GRM_list_secondary_objects_only(AssyTag, RelationFindDfmea,&sec_countDfmea,&sec_objectsDfmea));
							printf("\n erc_breakdown--B-for 4D Total objects found------[%d] ", sec_countDfmea);
							if(sec_countDfmea > 0)
							{
								printf("\n erc_breakdown--B-inside sec_countDfmea find  --------- [%d]", sec_countDfmea);fflush(stdout);
								for(dQ=0;dQ<sec_countDfmea;dQ++)
								{
									relationTagDfmea=sec_objectsDfmea[dQ];
									printf("\n erc_breakdown--B-inside sec count find dQ--------");fflush(stdout);

									if (relationTagDfmea != NULLTAG)
									{
										//CALLAPI( CR_create_release_status2("T5_LcsReview",&release_statusDfmea));
										CALLAPI( RELSTAT_create_release_status("T5_LcsReview",&release_statusDfmea));
										CALLAPI( AOM_ask_name(release_statusDfmea,&ReleaseStatusDfmea));
										printf("\n erc_breakdown--B-ReleaseStatusDfmea ----------[%s] ", ReleaseStatusDfmea);fflush(stdout);

										if((strcmp(ReleaseStatusDfmea,"ERC Review")==0)||strcmp(ReleaseStatusDfmea,"T5_LcsReview")==0 )
										{
											printf("\n erc_breakdown--B-BEFORE epm add rel status ERC released ");fflush(stdout);
											printf("\n erc_breakdown--B-before removing all rel status -------");fflush(stdout);
											//t5removeAllReleaseStatus(relationTagDfmea);
											//CALLAPI ( CR_create_release_status2("T5_LcsErcRlzd",&status_relDfmea));
											CALLAPI ( RELSTAT_create_release_status("T5_LcsErcRlzd",&status_relDfmea));

											CALLAPI(AOM_UIF_ask_value(relationTagDfmea,"release_status_list",&relstatDfmea));
											printf("\nerc_breakdown---Dml Task relstatDfmea:%s ",relstatDfmea);fflush(stdout);

											
											if((strstr(relstatDfmea,"ERC Released")!=NULL)|| (strstr(relstatDfmea,"T5_LcsErcRlzd")!=NULL))
											{
												printf("\n Already found released relstatDfmea, so skipped...\n");  fflush(stdout);
											}
											else
											{
												CALLAPI(RELSTAT_add_release_status(status_relDfmea,1,&relationTagDfmea,retain_released_dateDfmea));
											}
											printf("\n erc_breakdown--B-after adding rel status ERC Released 4d return 0---");fflush(stdout);
										}
									}
								}
							}
						}

						// Adi add 4D Doc rel status END HERE 2021
						//CALLAPI(  CR_create_release_status2("T5_LcsErcRlzd",&release_status));
						CALLAPI(  RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
						CALLAPI( AOM_ask_name(release_status,&ReleaseStatus));

						CALLAPI(AOM_UIF_ask_value(AssyTag,"release_status_list",&relstatassy));
						printf("\nerc_breakdown---Dml Task relstatassy:%s ",relstatassy);fflush(stdout);

											
						if((strstr(relstatassy,"ERC Released")!=NULL)|| (strstr(relstatassy,"T5_LcsErcRlzd")!=NULL))
						{
							printf("\n Already found released relstatassy, so skipped...\n");  fflush(stdout);
						}
						else
						{
							if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0 )
							{
								CALLAPI(RELSTAT_add_release_status(release_status,1,&AssyTag,retain_released_date));
							}
						}
						printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);

						if((strcmp(ReleaseStatus,"ERC Released")==0) ||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0)
						{
							if(ITK_ok != (ifail = WSOM_ask_effectivity_mode(&stat))) return ifail;
							printf("\n stat:%d\n",stat);fflush(stdout);

							if(stat != true)
							{
								printf("\n stat is not true .....\n");fflush(stdout);
							}
							else
							{
								printf("\n stat is  true .....\n");fflush(stdout);
							}

							getCurrentDateTime(cCurrentAccessDate);
							//if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))	 return ifail;
							//if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value))) return ifail;14.3
							CALLAPI(AOM_ask_value_string(release_status,"effectivity_text",&value));
							printf("\n effectivity_text is value : %s\n",value);fflush(stdout);

							getNextDate(cNextDate);
							printf("\n cNextDate:%s",cNextDate);fflush(stdout);

							if(ITK_ok != (ifail = ITK_string_to_date(cNextDate,&test_date_1 )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue18");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return18");fflush(stdout);
									return ifail;
								}
							}
							if(ITK_ok != (ifail = ITK_string_to_date("31-Dec-9999 00:00",&test_date_2 )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue19");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown--ETB: return19");fflush(stdout);
									return ifail;
								}
							}
							start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

							printf( "\n erc_breakdown--Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");
							fflush(stdout);

							start_end_date[0] = test_date_1;
							start_end_date[1] = test_date_2;

							if(ITK_ok != (ifail = WSOM_status_clear_effectivities ( release_status)))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue20");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return20");fflush(stdout);
									return ifail;
								}
							}
							if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(release_status, NULLTAG, 2,start_end_date, EFFECTIVITY_closed,&eff_d )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue21");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return21");fflush(stdout);
									return ifail;
								}
							}

							if(ITK_ok != (ifail = AOM_save_without_extensions(eff_d)))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue22");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return22");fflush(stdout);
									return ifail;
								}
							}

							if(ITK_ok != (ifail = AOM_save_without_extensions(release_status)))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue23");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return23");fflush(stdout);
									return ifail;
								}
							}
							if(ITK_ok != (ifail = AOM_refresh( release_status, 0 )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue24");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return24");fflush(stdout);
									return ifail;
								}
							}

							//if(ITK_ok != (ifail = PROP_ask_property_by_name(release_status,"effectivity_text",&propEff_tag)))return ifail;
							//if(ITK_ok != (ifail = PROP_ask_value_string(propEff_tag,&value)))return ifail;
							CALLAPI(AOM_ask_value_string(release_status,"effectivity_text",&value));
							
							printf("\n After setting effectivity_text value : %s\n",value);
							if(ITK_ok != (ifail = AOM_refresh( AssyTag, 0 )))
							{
								if(tc_strstr(info7,"CNT1") == NULL)
								{
									printf("\n erc_breakdown---ETB: Continue25");fflush(stdout);
									continue;
								}
								else
								{
									printf("\n erc_breakdown---ETB: return25");fflush(stdout);
									return ifail;
								}
							}
							else
							{
								printf("\nerc_breakdown---AOM_refresh sucessful");fflush(stdout);
							}
						}
						printf("\nerc_breakdown---Outside the ERC Release stamping check.");fflush(stdout);

						if(tc_strstr(info7,"REL1") == NULL)
						{
							printf("\n erc_breakdown---Now parttype:%s DMLtype: %s ",parttype,DMLtype);fflush(stdout);
							if((strcmp(DMLtype,"Veh")==0) && ((strcmp(parttype,"V") == 0)||(strcmp(parttype,"Vehicle") == 0)))
							{
								printf("\n erc_breakdown---Now task_no:%s ",task_no);fflush(stdout);
								if(strstr(task_no,"_00")!=NULL)
								{
									//T5_VCSpec
									if(GRM_find_relation_type("T5_VCSpec",&RelationFindTEchSpec));
									if (RelationFindTEchSpec!=NULLTAG)
									{
										printf("\n erc_breakdown--A-Inside for Spec After finding RelType ");fflush(stdout);
										CALLAPI(GRM_list_secondary_objects_only(AssyTag, RelationFindTEchSpec,&sec_countSpec,&sec_objectsSpec));
										printf("\n erc_breakdown--A-for Spec Total objects found sec_countSpec------[%d]", sec_countSpec);

										if(sec_countSpec > 0)
										{
											printf("\n erc_breakdown--A-inside sec_countSpec find  --------- [%d]", sec_countSpec);fflush(stdout);
											for(sp=0;sp<sec_countSpec;sp++)
											{
												relationTagSpec=sec_objectsSpec[sp];
												printf("\n erc_breakdown--A-inside sec count find sp---------");fflush(stdout);


												CALLAPI(AOM_UIF_ask_value(relationTagSpec,"release_status_list",&relstatspec));
												printf("\nerc_breakdown---Dml Task relstatspec:%s ",relstatspec);fflush(stdout);

												if((strstr(relstatspec,"ERC Released")!=NULL)|| (strstr(relstatspec,"T5_LcsErcRlzd")!=NULL))
												{
													printf("\n Already found released, so skipped for techspec...\n");  fflush(stdout);
												}
												else
												{
													if (relationTagSpec != NULLTAG)
													{
														//CALLAPI( CR_create_release_status2("T5_LcsReview",&release_status4D));
														CALLAPI( RELSTAT_create_release_status("T5_LcsErcRlzd",&release_statusSpec));
														CALLAPI( AOM_ask_name(release_statusSpec,&ReleaseStatusSpec));
														printf("\n erc_breakdown--A-ReleaseStatusSpec ----------[%s]", ReleaseStatusSpec);fflush(stdout);

														if((strcmp(ReleaseStatusSpec,"ERC Released")==0)||strcmp(ReleaseStatusSpec,"T5_LcsErcRlzd")==0 )
														{
															printf("\n erc_breakdown--A-BEFORE epm add rel status ERC released Spec ");fflush(stdout);
															printf("\n erc_breakdown--A-before removing all rel status Spec ---------");fflush(stdout);
															//t5removeAllReleaseStatus(relationTag4D);
															//CALLAPI ( CR_create_release_status2("T5_LcsErcRlzd",&status_rel4D));
															CALLAPI (RELSTAT_create_release_status("T5_LcsErcRlzd",&status_relSpec));

															CALLAPI(RELSTAT_add_release_status(status_relSpec,1,&relationTagSpec,retain_released_dateSpec));

															printf("\n erc_breakdown--A-after adding rel status ERC Released Spec return 0---------");fflush(stdout);
														}
													}
												}
											}
										}
									}
									//T5_PartHasSnapShot

									if(GRM_find_relation_type("T5_PartHasSnapShot",&RelationFindTEchSnap));
									if (RelationFindTEchSnap!=NULLTAG)
									{
										printf("\n erc_breakdown--A-Inside for Snap After finding RelType ");fflush(stdout);
										CALLAPI(GRM_list_secondary_objects_only(AssyTag, RelationFindTEchSnap,&sec_countSnap,&sec_objectsSnap));
										printf("\n erc_breakdown--A-for Snap Total objects found sec_countSnap------[%d]", sec_countSnap);

										if(sec_countSnap > 0)
										{
											printf("\n erc_breakdown--A-inside sec_countSnapshot find  --------- [%d]", sec_countSnap);fflush(stdout);
											for(sn=0;sn<sec_countSnap;sn++)
											{
												relationTagSnap=sec_objectsSnap[sn];
												printf("\n erc_breakdown--A-inside sec count find sn---------");fflush(stdout);


												CALLAPI(AOM_UIF_ask_value(relationTagSnap,"release_status_list",&relstatsnap));
												printf("\nerc_breakdown---Dml Task relstatsnap:%s ",relstatsnap);fflush(stdout);

												if((strstr(relstatsnap,"ERC Released")!=NULL)|| (strstr(relstatsnap,"T5_LcsErcRlzd")!=NULL))
												{
													printf("\n Already found released, so skipped for snap...\n");  fflush(stdout);
												}
												else
												{
													if (relationTagSnap != NULLTAG)
													{
														//CALLAPI( CR_create_release_status2("T5_LcsReview",&release_status4D));
														CALLAPI( RELSTAT_create_release_status("T5_LcsErcRlzd",&release_statussnap));
														CALLAPI( AOM_ask_name(release_statussnap,&ReleaseStatussnap));
														printf("\n erc_breakdown--A-ReleaseStatussnap ----------[%s]", ReleaseStatussnap);fflush(stdout);

														if((strcmp(ReleaseStatussnap,"ERC Released")==0)||strcmp(ReleaseStatussnap,"T5_LcsErcRlzd")==0 )
														{
															printf("\n erc_breakdown--A-BEFORE epm add rel status ERC released snap");fflush(stdout);
															printf("\n erc_breakdown--A-before removing all rel status snap---------");fflush(stdout);
															//t5removeAllReleaseStatus(relationTag4D);
															//CALLAPI ( CR_create_release_status2("T5_LcsErcRlzd",&status_rel4D));
															CALLAPI (RELSTAT_create_release_status("T5_LcsErcRlzd",&status_relSnap));
															CALLAPI(RELSTAT_add_release_status(status_relSnap,1,&relationTagSnap,retain_released_datesnap));

															printf("\n erc_breakdown--A-after adding rel status ERC Released snap return 0---------");fflush(stdout);
														}
													}
												}
											}
										}
									}
									//IMAN_specification

									if(GRM_find_relation_type("IMAN_specification",&RelationFindTEchdoc));
									if (RelationFindTEchdoc!=NULLTAG)
									{
										printf("\n erc_breakdown--A-Inside for doc After finding doc ");fflush(stdout);
										CALLAPI(GRM_list_secondary_objects_only(AssyTag, RelationFindTEchdoc,&sec_countdoc,&sec_objectsdoc));
										printf("\n erc_breakdown--A-for doc Total objects found sec_countdoc------[%d]", sec_countdoc);

										if(sec_countdoc > 0)
										{
											printf("\n erc_breakdown--A-inside sec_countdoc find doc  --------- [%d]", sec_countdoc);fflush(stdout);
											for(sd=0;sd<sec_countdoc;sd++)
											{
												relationTagdoc=sec_objectsdoc[sd];
												printf("\n erc_breakdown--A-inside sec count find sd doc---------");fflush(stdout);

												CALLAPI(AOM_UIF_ask_value(relationTagdoc,"release_status_list",&relstatdoc));
												printf("\nerc_breakdown---Dml Task relstatdoc:%s ",relstatdoc);fflush(stdout);

												if((strstr(relstatdoc,"ERC Released")!=NULL)|| (strstr(relstatdoc,"T5_LcsErcRlzd")!=NULL))
												{
													printf("\n Already found released, so skipped for docs...\n");  fflush(stdout);
												}
												else
												{
													if (relationTagdoc != NULLTAG)
													{
														//CALLAPI( CR_create_release_status2("T5_LcsReview",&release_status4D));
														CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_statusdoc));
														CALLAPI(AOM_ask_name(release_statusdoc,&ReleaseStatusdoc));
														printf("\n erc_breakdown--A-ReleaseStatusdoc doc ----------[%s]", ReleaseStatusdoc);fflush(stdout);

														if((strcmp(ReleaseStatusdoc,"ERC Released")==0)||strcmp(ReleaseStatusdoc,"T5_LcsErcRlzd")==0 )
														{
															printf("\n erc_breakdown--A-BEFORE epm add rel status ERC released doc");fflush(stdout);
															printf("\n erc_breakdown--A-before removing all rel status doc---------");fflush(stdout);
															//t5removeAllReleaseStatus(relationTag4D);
															//CALLAPI ( CR_create_release_status2("T5_LcsErcRlzd",&status_rel4D));
															CALLAPI(RELSTAT_create_release_status("T5_LcsErcRlzd",&status_reldoc));
															CALLAPI(RELSTAT_add_release_status(status_reldoc,1,&relationTagdoc,retain_released_datedoc));

															printf("\n erc_breakdown--A-after adding rel status ERC Released doc return 0---------");fflush(stdout);
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					printf("\n erc_breakdown---outside the Release stamping of task [%s] ",task_no);fflush(stdout);
				} //End of if (partcnt>0)
				//Prasad Sagare:DML Type: VOD
				if(strcmp(DMLtype,"VOD")==0)
				{
					printf("\n CMR:erc_breakdown---Now partcnt:%d ",partcnt);fflush(stdout);
					tag_t qryTagCntrVC = NULLTAG;
					tag_t *ctrlObjVCTags = NULLTAG;

					int ctrlCntVC =0;
					char *VCDMLinfo2 = NULL;
					char *VCDMLinfo3 = NULL;

					char *qry_entryCntrlVC[2]	= {"SYSCD","SUBSYSCD"};
					char **qry_valuesCntrlVC	= (char **) MEM_alloc(10 * sizeof(char *));

					if(QRY_find2("Control Objects...",&qryTagCntrVC));
					if(qryTagCntrVC != NULLTAG)
					{
						printf("\n CMR:erc_breakdown-->Validation Query Found VOD DML release stamping...");fflush(stdout);

						qry_valuesCntrlVC[0]="ERCVCDML";
						qry_valuesCntrlVC[1]="true";

						if(QRY_execute(qryTagCntrVC, 2, qry_entryCntrlVC, qry_valuesCntrlVC,&ctrlCntVC,&ctrlObjVCTags));
						printf("\n CMR:erc_breakdown-->Control table found count: [%d]",ctrlCntVC);fflush(stdout);

						if(ctrlCntVC>0)
						{
							ITK_CALL(AOM_ask_value_string(ctrlObjVCTags[0],"t5_Userinfo2",&VCDMLinfo2));
							ITK_CALL(AOM_ask_value_string(ctrlObjVCTags[0],"t5_Userinfo3",&VCDMLinfo3));
							printf("\nCMR: erc_breakdown--> VCDMLinfo2: [%s] VCDMLinfo2:[%s]\n",VCDMLinfo2,VCDMLinfo3); fflush(stdout);
						}

						if (tc_strstr(VCDMLinfo2,"ON")==NULL)
						{
							// control obj
							int cmpartcnt = 0;
							tag_t *cmPartsTag = NULLTAG;

							CALLAPI(AOM_ask_value_tags(Dml_tasks[zz],"CMReferences",&cmpartcnt,&cmPartsTag));
							printf("\n CMR:erc_breakdown---Now cmpartcnt:%d ",cmpartcnt);fflush(stdout);
							k = 0;

							if (cmpartcnt > 0)
							{
								for (k=0; k<cmpartcnt; k++)
								{
									printf("\n CMR:erc_breakdown---for k= %d ",k);fflush(stdout);
									AssyTag=cmPartsTag[k];

									CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
									CALLAPI(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype));
									printf("\n CMR:erc_breakdown--- [k=%d ]Part_no:[%s] DMLType:[%s] DMLtaskno:[%s]",k,Part_no,DMLtype,task_no);fflush(stdout);

									printf("\n CMR:erc_breakdown---In If Condn--info4 is  = [%s] ", info4);fflush(stdout);
									int statusC=0;
									int sv=0;
									int ERCStatusFlgVOD=0;
									tag_t* relStatus_listCM = NULLTAG;
									int ERCRelFlag=0;

									getCurrentDateTime(cCurrentAccessDate);
									printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
									ITK_string_to_date(cCurrentAccessDate,&Ltest_date_2);


									printf("\nCMR: erc_breakdown---Eff:Setting effectivity on latest released revision!!\n");fflush(stdout);
									CALLAPI(AOM_UIF_ask_value (AssyTag,"item_id",&cPartNo));

									CALLAPI(WSOM_ask_release_status_list(AssyTag,&statusC,&relStatus_listCM));	//Added by RRR on 02.10.2018
									if (statusC > 0)
									{
										for(sv=0; sv<statusC ; sv++)
										{
											CALLAPI(AOM_ask_value_string(relStatus_listCM[sv],"object_name",&CMR_Rel_Stus));
											printf("\nCMR: erc_breakdown---CMR_Rel_Stus: %s",CMR_Rel_Stus);fflush(stdout);

											if((strcmp(CMR_Rel_Stus,"ERC Review")==0) || (strcmp(CMR_Rel_Stus,"T5_LcsReview")==0))
											{
												if(tc_strstr(VCDMLinfo3,"WEFF")== NULL)
												{
													//if(ITK_ok != (ifail = PROP_ask_property_by_name(relStatus_listCM[sv],"effectivity_text",&propEff_tag)))	 return ifail;
													//if(PROP_ask_property_by_name(relStatus_listCM[sv],"effectivity_text",&cmpropEff_tag));
													//if(ITK_ok != (ifail = PROP_ask_value_string(cmpropEff_tag,&value)))	 return ifail;
													//if(PROP_ask_value_string(cmpropEff_tag,&value));
													CALLAPI(AOM_ask_value_string(relStatus_listCM[sv],"effectivity_text",&value));
													printf("\nCMR: erc_breakdown---erc_breakdown---ERCReview--effectivity_text is value : %s",value); fflush(stdout);

													printf("\nCMR: erc_breakdown---ERCReview--effectivity_text is length : %d",strlen(value)); fflush(stdout);

													if(tc_strlen(value) == 0)
													{
														if( AOM_UIF_ask_value (AssyTag,"creation_date",&value)!=ITK_ok);  //rev_CreDt
														printf("\nCMR:ERCReview--creation_date----value:::: [%s]", value);fflush(stdout);
													}
													printf("\nCMR:erc_breakdown---ERCReview--StartDate: [%s]   EndDate:[%s]", value,cCurrentAccessDate);fflush(stdout);
													if(tc_strlen(value) == 0)
													{
														printf("CMR:  --Skipping from ERC Review validation as blank.....\n");fflush(stdout);
														continue;  // skipping this case if value found NULL/Blank
													}
													else
													{
														ReviewStartDate=subString(value,0,17);
														printf("\nCMR: ERCReview--ReviewStartDate: %s",ReviewStartDate); fflush(stdout);

														if(ITK_ok != (ifail = DATE_string_to_date_t(ReviewStartDate,&date_is_valid,&Ltest_date_1 )))
														{
															printf("\nCMR: erc_breakdown---ETB: return4");fflush(stdout);
															return ifail;
														}

														Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
														Lstart_end_date[0] = Ltest_date_1;
														Lstart_end_date[1] = Ltest_date_2;

														printf("\nCMR: ERCReview--EFF:Clearing effectivities...");fflush(stdout);
														if(ITK_ok != (ifail = WSOM_status_clear_effectivities (relStatus_listCM[sv])))
														{
															printf("\nCMR: erc_breakdown---ETB: return5");fflush(stdout);
															return ifail;
														}

														printf("\nCMR: ERCReview--EFF:Creating effectivities...");fflush(stdout);
														if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(relStatus_listCM[sv], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed,&CMLeff_d )))
														{
															printf("\nCMR: erc_breakdown---ETB: return6");fflush(stdout);
															return ifail;
														}
														printf("\nCMR: ERCReview--EFF:Saving effectivities...");fflush(stdout);
														if(ITK_ok != (ifail = AOM_save_without_extensions(CMLeff_d)))
														{
															printf("\nCMR: erc_breakdown---ETB: return7");fflush(stdout);
															return ifail;
														}
														printf("\nCMR: ERCReview--EFF:Saving Revision...");fflush(stdout);
														if(ITK_ok != (ifail = AOM_save_without_extensions(relStatus_listCM[sv])))
														{
															printf("\nCMR: erc_breakdown---ETB: return8");fflush(stdout);
															return ifail;
														}
														printf("\nCMR: ERCReview--EFF:Refreshing Revision...");fflush(stdout);
														if(ITK_ok != (ifail = AOM_refresh( relStatus_listCM[sv], 0 )))
														{
															printf("\nCMR: erc_breakdown---ETB: return9");fflush(stdout);
															return ifail;
														}
													}

													CALLAPI(AOM_UIF_ask_value(AssyTag,"release_status_list",&relstatAssy));
													printf("\nerc_breakdown---Dml Task relstatAssy:%s ",relstatAssy);fflush(stdout);

													if((strstr(relstatAssy,"ERC Released")!=NULL)|| (strstr(relstatAssy,"T5_LcsErcRlzd")!=NULL))
													{
														printf("\n Already found released relstatAssy, so skipped...\n");  fflush(stdout);
													}
													else
													{
														CALLAPI(RELSTAT_add_release_status(release_status,1,&AssyTag,retain_released_date));
													}
													ifail = AOM_refresh( AssyTag, 0 );
												}
												else if(tc_strstr(VCDMLinfo3,"NOEFF")== NULL)
												{
													CALLAPI(AOM_UIF_ask_value(AssyTag,"release_status_list",&relstatAssy));
													printf("\nerc_breakdown---Dml Task relstatAssy:%s ",relstatAssy);fflush(stdout);

													if((strstr(relstatAssy,"ERC Released")!=NULL)|| (strstr(relstatAssy,"T5_LcsErcRlzd")!=NULL))
													{
														printf("\n Already found released relstatAssy, so skipped...\n");  fflush(stdout);
													}
													else
													{
														CALLAPI(RELSTAT_add_release_status(release_status,1,&AssyTag,retain_released_date));
													}
													ifail = AOM_refresh( AssyTag, 0 );
												}
											}
										}
									}
									
									// attach the latest VOD -CR-FY25-0002
									tag_t qryVODTag = NULLTAG;
   									CALLAPI(QRY_find2("Control Objects...",&qryVODTag));
									if (qryVODTag)
									{
										int ctrlObjVODCnt = 0;
										
										tag_t* ctrlObjVODTags = NULLTAG;
										tag_t ctrlObjVODTag = NULLTAG;
										tag_t 	VOD_relation_type =NULLTAG;
									//	tag_t 	iman_relation_type =NULLTAG;
										tag_t	vodrel_tag			= NULLTAG;
										tag_t	new_relation			= NULLTAG;
										tag_t	Vehicle_Rev			= NULLTAG;
										tag_t	*Vehicle_Revs		=NULLTAG;
										tag_t	*pre_rev_Objects		= NULLTAG;
										tag_t	pre_rev_Object		= NULLTAG;
										tag_t	*VODObjects		= NULLTAG;
										tag_t	VODObject		= NULLTAG;
										tag_t	t_VodpreviousRevision		= NULLTAG;
										
										char*		VOD_NUM= NULL;
										char*		VOD_NUM_REV_ID= NULL;
										char*		pre_revid= NULL;
										char*		voditemid_str= NULL;
										char*		vodrev_str= NULL;
										char*		VOD_Userinfo= NULL;
										char*		VodCurrent_revid= NULL;
										
										int Veh_count =0;
										int	pre_rev_count	=	0;
										int vodcount	=	0;
										int ki,pi =0;
									
										char *qryctrlent[2] = {"SYSCD","SUBSYSCD"};
	   									char *qryctrlval[2] = {"VODVEHICLERELATION","DML"};
										
										CALLAPI(QRY_execute(qryVODTag,2,qryctrlent,qryctrlval,&ctrlObjVODCnt,&ctrlObjVODTags));
   										if(ctrlObjVODCnt > 0)
   										{
											printf("\n inside the control object of VODVEHICLERELATION"); fflush(stdout);
   											ctrlObjVODTag=ctrlObjVODTags[0];
   											CALLAPI(AOM_ask_value_string(ctrlObjVODTag,"t5_Userinfo1",&VOD_Userinfo));
											printf("\n under control object of VOD the value of VOD_Userinfo is %s",VOD_Userinfo);fflush(stdout);
											
											if(tc_strstr(VOD_Userinfo,"VODVEHICLERELATION")!=NULL)
											{
												CALLAPI(AOM_ask_value_string(AssyTag,"item_id",&VOD_NUM));
												CALLAPI(AOM_ask_value_string(AssyTag,"item_revision_id",&VOD_NUM_REV_ID));
												printf("\n 222222VOD_NUM is %s",VOD_NUM);fflush(stdout);
												printf("\n 222222VOD_NUM_REV_ID is %s",VOD_NUM_REV_ID);fflush(stdout);

												if ((tc_strstr(VOD_NUM_REV_ID,"NR")==NULL))//not NR
												{
													tm_find_Prev_Official_Rev(VOD_NUM,AssyTag,&t_VodpreviousRevision);
													pre_rev_Object=t_VodpreviousRevision;
													printf("\n VODVEHICLERELATION");fflush(stdout);
												}
												
												
												//GRM_find_relation_type("IMAN_based_on",&iman_relation_type);
												GRM_find_relation_type("T5_HasVOD",&VOD_relation_type);																				
												
												//GRM_list_secondary_objects_only(AssyTag, iman_relation_type, &pre_rev_count, &pre_rev_Objects);
												//printf("\n The previous revision count of AssyTag is %d",pre_rev_count);fflush(stdout);
												
												if(pre_rev_Object!=NULLTAG)
												{
													//pre_rev_Object=pre_rev_Objects[0];
													
													CALLAPI(AOM_ask_value_string(pre_rev_Object,"item_revision_id",&pre_revid));
													printf("\n pre_rev_id is %s",pre_revid);fflush(stdout);
													
													GRM_list_primary_objects_only(pre_rev_Object,VOD_relation_type,&Veh_count,&Vehicle_Revs);
													printf("\n primary objet count is %d",Veh_count);fflush(stdout);
													
													if(Veh_count > 0)
													{
														for(ki=0;ki<Veh_count;ki++)
														{
															Vehicle_Rev =Vehicle_Revs[ki];
															GRM_list_secondary_objects_only(Vehicle_Rev, VOD_relation_type, &vodcount, &VODObjects);
					
															printf("\n the attached vod count for vehicle is %d",vodcount);fflush(stdout);
															
															if (vodcount >0)
															{
																for(pi=0;pi<vodcount;pi++)
																{
																	AOM_ask_value_string(VODObjects[pi],"item_id",&voditemid_str);fflush(stdout);
																	AOM_ask_value_string(VODObjects[pi],"item_revision_id",&vodrev_str);fflush(stdout);
																	printf("\n under vehicle attached VOD item id: [%s]\n",voditemid_str);fflush(stdout);
																	printf("\n under vehicle attached VOD Item revision id: [%s]\n",vodrev_str);fflush(stdout);
																	
																	if(tc_strcmp(voditemid_str,VOD_NUM)==0)
																	{
																		if(tc_strcmp(vodrev_str,VOD_NUM_REV_ID)==0)
																		{
																			printf("\n correct vod is alredy added");fflush(stdout);
																		}
																		else
																		{
																			GRM_find_relation(Vehicle_Rev, pre_rev_Object, VOD_relation_type, &vodrel_tag);
																			GRM_delete_relation(vodrel_tag);
																			AOM_refresh(vodrel_tag, TRUE);
																			printf("\n vodrel_tag locked --->");fflush(stdout);
																			AOM_save_without_extensions(vodrel_tag);
																			AOM_refresh(vodrel_tag,FALSE);
																			printf("\n vodrel_tag unlocked --->");fflush(stdout);
																		
																			if(AssyTag !=NULLTAG)
																			{
																				printf("\n VODVEHICLERELATION:Under creating relation!!");fflush(stdout);
																				GRM_create_relation(Vehicle_Rev, AssyTag, VOD_relation_type, NULLTAG, &new_relation);
																				GRM_save_relation(new_relation);
																				printf("\n VODVEHICLERELATION::Relation Created !!");fflush(stdout);
																			}
																			else
																			{
																				printf("\n VOD revision tag is null");fflush(stdout);
																			}
																		}
																	}
																	else
																	{
																		printf("\n item id of attached vod and selscted vod is not matched");fflush(stdout);
																	}
																}
															}
															else
															{
																printf("\n there is no VOD attached with this vehicle");fflush(stdout);
															}
														}
													}
													else
													{
														printf("\n there is no vehicle found for this VOD");fflush(stdout);
													}
													
												}
												else
												{
													printf("\n there is no previous revision found");fflush(stdout);
												}
											}
											else
											{
												printf("\n the value of Userinfo1 is not matched");fflush(stdout);
											}
											
										}
										else
										{
											printf("\n control object not found");fflush(stdout);
										}
									}
									else
									{
										printf("\n control object for VOD Relation not found");fflush(stdout);
									}	
								}// for loop end of attached VOD in task
							}
							printf("\n erc_breakdown---Now cmpartcnt:%d ",cmpartcnt);fflush(stdout);
							printf("\n erc_breakdown---outside the part count > 0 loop for task [%s] ",task_no);fflush(stdout);
						}
					}
					else
					{
						printf("\n erc_breakdown--- control object - ERCVCDML-true not found");fflush(stdout);
					}
				}
				
			}
		}
		printf("\n erc_breakdown---After the end of for loop of task ");fflush(stdout);

	} //End of DML Task Cnt if (cnt>0)

	//Prasad - Release status correction
	if (tc_strcmp(ObjClassName,"ChangeRequestRevision")==0)
	{
		
		printf("\nInside : Release status correction loop\n");fflush(stdout);
		if(tc_strstr(info2,"RelStampCorr") == NULL)
		{
			ifail = WSOM_ask_release_status_list(DMLTag,&status_count,&relStatus_list);
			printf("\n\t WSOM_ask_release_status_list count is :: %d\n",status_count);fflush(stdout);

			if (status_count > 1)
			{
				for (k1=0;k1 < status_count; k1++)
				{
					ifail = AOM_ask_value_string(relStatus_list[k1],"object_name",&latest_rev_Rel_Stus1);
					printf("\n\t %d. Release status is : %s>>>>>>>>>\n",k1,latest_rev_Rel_Stus1);fflush(stdout);
					if ((tc_strcmp(latest_rev_Rel_Stus1,"T5_LcsErcRlzd") == 0) ||(tc_strcmp(latest_rev_Rel_Stus1,"ERC Released")==0))
					{
						printf("\n\t Release status found for the DML ");fflush(stdout);
						RelStusFnd = 1;
						printf("\n\t RelStusFnd Set to 1");fflush(stdout);
						break;
					}
				}
				if (RelStusFnd > 0)
				{
					for (k2=0;k2 < status_count; k2++)
					{
						printf("\n\t RelStusFnd > 1 ");fflush(stdout);
						ifail = AOM_ask_value_string(relStatus_list[k2],"object_name",&latest_rev_Rel_Stus2);
						printf("\n\t %d. Release status is : %s>>>>>>>>>\n",k2,latest_rev_Rel_Stus2);fflush(stdout);
						if((delStat != 1) &&((tc_strcmp(latest_rev_Rel_Stus2,"T5_LcsReview") == 0) || (tc_strcmp(latest_rev_Rel_Stus2,"ERC Review")==0)|| (tc_strcmp(latest_rev_Rel_Stus2,"In Designer Working")==0)|| (tc_strcmp(latest_rev_Rel_Stus2,"T5_LcsDesignerWorking")==0)|| (tc_strcmp(latest_rev_Rel_Stus2,"In Manager Review")==0)))
						{
							delStat = 1;

							printf("\nFound release status is : %s\n",latest_rev_Rel_Stus2);fflush(stdout);
							(AOM_refresh(DMLTag,1));
							CHECK_FAIL(ITK_set_bypass(true));
							CHECK_FAIL(POM_attr_id_of_attr("release_status_list","ChangeRequestRevision",&attRelStatus));
							CHECK_FAIL(POM_refresh_instances_any_class(1,&DMLTag, POM_modify_lock));
							CHECK_FAIL(POM_clear_attr(1,&DMLTag,attRelStatus));
							CHECK_FAIL(POM_save_instances(1,&DMLTag,true));
							CHECK_FAIL(POM_refresh_instances_any_class(1,relStatus_list,POM_delete_lock));
							CHECK_FAIL(POM_delete_instances(1,relStatus_list));
							(AOM_refresh(DMLTag,0));

							ifail = WSOM_ask_release_status_list(DMLTag,&num1,&chkrelStatus_list);
							printf("\nAfter Update release status of count is : [%d]\n",num1);fflush(stdout);
							break;
						}
						else
						{
							if(delStat == 0)
							{
								printf("\n\t Skipping Release status from Delete [%s]",latest_rev_Rel_Stus2);fflush(stdout);
							}
							else
							{
								printf("\nDelStat is set to 1, no deletion loop");fflush(stdout);
							}
						}
					}
					if (delStat == 1)
					{
						printf("\nInside the delStat == 1 loop, for part cut for loop");fflush(stdout);
						for(k3 = 0; k3 < status_count; k3++)
						{
							ifail = AOM_ask_value_string(relStatus_list[k3],"object_name",&latest_rev_Rel_Stus3);
							printf("\nInside to set the old release status  [%s]",latest_rev_Rel_Stus3);fflush(stdout);
							if((tc_strcmp(latest_rev_Rel_Stus3,"T5_LcsReview") != 0) && (tc_strcmp(latest_rev_Rel_Stus3,"ERC Review")!=0)&& (tc_strcmp(latest_rev_Rel_Stus3,"In Designer Working")!=0)&& (tc_strcmp(latest_rev_Rel_Stus3,"T5_LcsDesignerWorking")!=0)&& (tc_strcmp(latest_rev_Rel_Stus3,"In Manager Review")!=0))
							{
									ifail = AOM_refresh(DMLTag,1);
									CALLAPI(AOM_UIF_ask_value(DMLTag,"release_status_list",&relstatDMLTag));
									printf("\nerc_breakdown---Dml Task relstatDMLTag:%s ",relstatDMLTag);fflush(stdout);

									if((strstr(relstatDMLTag,"ERC Released")!=NULL)|| (strstr(relstatDMLTag,"T5_LcsErcRlzd")!=NULL))
									{
										printf("\n Already found released relstatDMLTag, so skipped...\n");  fflush(stdout);
									}
									else
									{
										ifail = RELSTAT_add_release_status(relStatus_list[k3],1,&DMLTag,false);
									}
									ifail = AOM_save_without_extensions(DMLTag);
									ifail = AOM_refresh(DMLTag,0);
									printf("\nAdded Release status [%s] at posiotion [%d]",latest_rev_Rel_Stus3);fflush(stdout);
							}
						}
					}
				}
			}
		}
		printf("\nInside : Release status correction loop complete\n");fflush(stdout);
	}
	printf ("\n--------------erc_task_breakdown=Completed---------------------------------------------------------------------\n");
	fflush(stdout);


	printf("\n*********************");
	printf("\nEnd of program.....!!");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);

	//return ITK_ok;
	return 0;
}