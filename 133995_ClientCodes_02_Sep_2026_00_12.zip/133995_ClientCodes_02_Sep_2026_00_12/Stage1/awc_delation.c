/**********************************************************************************************************************************************************
** Functions:- This utility takes item_id and attribute_value as input from file and updates the value of specific attribute of latest revision of perticular 

** command to run:
** update_attr -u=<username> -p=<password> -g=<group> -file=<Filename>

./deleteReplicaObj -item_id="544260121213" -rev="NR;6"

./deleteReplicaObj -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -item_id="265462600102" -rev="F;2"
***********************************************************************************************************************************************************/


#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}



#define PROP_UIF_set_value_msg		"PROP_UIF_set_value" 
#define PROP_set_value_tag_msg		"PROP_set_value_tag" 
#define PROP_set_value_string_msg   "PROP_set_value_string"  
void awc_delation();
FILE 		*output 			= NULL;

char		*sep				= ",";

int read_value_from_file(char*);
int update_attr(char*);
int write_info(char*, char*, char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -item_id=<filename> (required)\n"
        " -rev=<filename> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* item_id					= NULL;
	char			* rev						= NULL;
	char			Data[100]					= "";
	
	char 			*test						= (char*)MEM_alloc(sizeof(char) * 50);
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	item_id 		= ITK_ask_cli_argument("-item_id=");
	//rev				= ITK_ask_cli_argument("-rev=");
	ifail =	 (ITK_auto_login( ));
	ifail =(ITK_set_journalling( TRUE ));
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}

		awc_delation();
		return  ifail;
}

/********************************************************************************************
    Function:       update_attr
    Description:    This function takes the item_id and attr_value as input and stamps the 
					attr_value on specific attribute of all revisions of perticular item.
********************************************************************************************/

void awc_delation()
{
	int				ifail 						= ITK_ok;
	int				r_count 					= 0;
	int				count 						= 0;
	int				countR	 					= 0;
	int				i		 					= 0;
	int				revloop	 					= 0;
	int				revloopR 					= 0;
	int				*instance_levels;
	int	   *instance_where_found;
	int    *class_levels;
	int    *class_where_found;
	int    n_classes		= 0;
	tag_t  *ref_classes		= NULLTAG;
	tag_t Item_tag=NULLTAG;
	tag_t			item_tag 					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	tag_t			relation_type				= NULLTAG;
	tag_t			relation_type1				= NULLTAG;
	tag_t			relation_typeR				= NULLTAG;
	tag_t			relation_typeS				= NULLTAG;
	tag_t			relation_typeR1				= NULLTAG;
	tag_t			*secondary_objects			= NULLTAG;
	tag_t			*secondary_objectsR			= NULLTAG;
	tag_t			*secondary_objectsR1	    = NULLTAG;
	tag_t			*ref_instances	= NULLTAG;
	tag_t			ref_instancesTemp	= NULLTAG;
	tag_t			relation_tag	= NULLTAG;
	int             value_enteries=1;
	
	char 			*prt_type					= NULL;
	char 			*p_status					= NULL;
	char 			*type						= "Module";
	char 			*rev_id						= NULL;
	char            *object_name                =NULL;
	tag_t            class_id                   =NULL;
	char            *class_name                 =NULL;
	int              n_instances                =0;
	int              ref_count_d                =0;
	char             **nameref;
	tag_t	Revision_Tag				= NULLTAG;
	int n_Input=1;
	char *qry_Input[1] = {"Type"};
	int QryCount=0;
	tag_t *Qry_Revision_Tag=NULLTAG;
	char *values[1];
	values[0] =	"AWC Report";	
	int k=0;
	char *revision_id=NULL;
	tag_t latest_rev=NULLTAG;
	tag_t rev=NULLTAG;
	char *re_id;
	ITK_CALL(QRY_find2("General...", &Revision_Tag));
	if(Revision_Tag!=NULLTAG)
				{
	          ITK_CALL(QRY_execute(Revision_Tag, n_Input, qry_Input, values, &QryCount, &Qry_Revision_Tag)); 
	          printf("\n qUERY for check in count== %d\n", QryCount);fflush(stdout);



			for(k=0;k<QryCount;k++)
			 
				{	
					printf("Before  AOM_load\n");
	                ITK_CALL(AOM_load(Qry_Revision_Tag[k]));	
	                printf("After AOM_load\n");
	                printf("Before AOM_delete \n");
	                ITK_CALL(AOM_delete(Qry_Revision_Tag[k]));	
					 printf("After AOM_delete \n");
					}
				
			 
					
    
				}
}
