#include<stdio.h>
#include<tc/tc.h>
int ControlObjQry ();
int ITK_user_main(int argc, char *argv[])
{
	int iFail=0;
	char *cError;
	//iFail=ITK_init_module("asp910737", "asp0737", "Engineering");
	iFail=ITK_auto_login();
	if(iFail==0)
	{
		printf("Login Sucessful");
		iFail = ControlObjQry();
	}
	else
	{
		EMH_ask_error_text(iFail, &cError);
		printf("Login UnSucessful: \n\n %s", cError);
	}
		
	return iFail;

}

int ControlObjQry ()
{
	int n = 0;
	tag_t *VCReviseCtrObj = NULLTAG;
	tag_t *CtrObjVCReviseQryTag = NULLTAG;

	char *VCReviseQryEntry[2]  = {"SYSCD","SUBSYSCD"};
	char **VCReviseEntryValue = (char **) MEM_alloc(50 * sizeof(char *));

	(QRY_find2("Control Objects...", &CtrObjVCReviseQryTag));

	VCReviseEntryValue[0] = "DmlVCRevise";	//SYSCD
	VCReviseEntryValue[1] = "ON";			//SUBSYSCD

	(QRY_execute(CtrObjVCReviseQryTag, 2, VCReviseQryEntry, VCReviseEntryValue, &n, &VCReviseCtrObj));
	printf("\n vc_release--Control Object AltrozVCRevise count:--> [%d] ",n); fflush(stdout);

	if(n>0)	
	{
		printf("\n Control Object DmlVCRevise Found. [%d] ",n); fflush(stdout);
	}
	return 0;
}