/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: NewPartRequest.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and on the basis of option selected it performs respective
**				action (Lock and Unlock) on objects.
**
**
**	Date							Author								Modification
**	08/01/2024						Suhdir
**
** command to run:
** change_group_unlock -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <epm/signoff.h>
#include <ce/ce.h>
#include <tc/folder.h>
#include <tccore/project.h>
//#include <tc/tc.h>
#include <tc/tc_startup.h>
#include <ae/datasettype.h>
#include <tccore/grm_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <tccore/aom_prop.h>
#include <tccore/releasestatus.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <base_utils/Mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/item_msg.h>
#include <constants/constants.h>
#include <common/emh_const.h>
#include <sa/groupmember.h>
#include <ps/ps_tokens.h>
#include <tc/envelope.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <Fnd0Participant/participant.h>
#include <unistd.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


int			ifail 				= ITK_ok;

int endsWithPDF(const char *filename) 
{
    const char *ext = strrchr(filename, '.');
    return ext && (strcasecmp(ext, ".pdf") == 0);  // Case-insensitive match
}

int ITK_user_main(int argc, char *argv[])
{
	int 			a;
	const char* u = NULL;
	const char* p = NULL;
	const char* g = NULL;
	char			* itemId						= NULL;
	char			* rev						= NULL;
	char			* propName					= NULL;
	char			* propValue					= NULL;
	char *inputline = NULL;
	char	*f	=NULL;
	char	result1 [ 100000 ] ;
	FILE	*fptr;
	FILE	*newfptr;
	char	result2 [ 100000 ] ;
	int 		i				=0;
	int 		flagFound		=0;
	int 		count		=0;
	int			cnt			=0;
	int n_entries = 2;
	int n_itemobj_found = 0;

	tag_t			*tags_found				= NULLTAG;
	tag_t			itemRev_t				= NULLTAG;
	tag_t			latest_rev_tag			= NULLTAG;
	tag_t			Ref_type =NULLTAG;
	tag_t			*doc_tags		= NULLTAG;
	tag_t			titemobj_result		= NULLTAG;
	tag_t			doc_tag		= NULLTAG;
	tag_t			*titemobj_results		= NULLTAG;
	tag_t			NewPdfdataset	= NULLTAG;
	tag_t			datasettype		= NULLTAG;
	tag_t			tool			= NULLTAG;
	tag_t			filetag			= NULLTAG;
	tag_t			tItemobj = NULLTAG;
	tag_t			relation		= NULLTAG;
	
	IMF_file_t	fileDescriptor;
	AE_reference_type_t	tagRefType = 1;
	
	int		ref_count;
	int j= 0;
	char **ref_list;
	char *DocDesc		= NULL;
	char *TempdirectoryPath		= NULL;
	
	char filenameCopy[256];
	char Partnodup[100];
	char revisioniddup[100];
	char sequencedup[100];
	char runningnodup[100];
	char rev_seq_concat[200]; 
	char filename_new[256]; 
	
	
	

	u = ITK_ask_cli_argument( "-u=");
	p = ITK_ask_cli_argument( "-pf=");
	g = ITK_ask_cli_argument( "-g=");
		
	
	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");fflush(stdout);
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");fflush(stdout);
		printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
	}

	if (ITK_init_module(u,p,g) == ITK_ok )
	{
		
		//const char *directoryPath = "/plmpv16/omfprod/CCDOCS_FROM_PFIRST";
		const char *directoryPath = "/user/cvprod/suryansh/CCDOCS_FROM_PFIRST";
		struct dirent *entry;
		DIR *dir = opendir(directoryPath);
		

		if(dir == NULL)
		{
			printf("Unable to open directory");
			return EXIT_FAILURE;
		}

		printf("PDF files in directory '%s':\n", directoryPath);
		
			char *pdfFiles[5000];
			int fileCount = 0;
		
		while ((entry = readdir(dir)) != NULL) 
		{
			if (entry->d_type == DT_REG && endsWithPDF(entry->d_name)) 
			{
				printf("%s\n", entry->d_name);
				
				pdfFiles[fileCount] = strdup(entry->d_name);
				fileCount++;
			}
		}
		for (int i = 0; i < fileCount; i++)
		{
			strcpy(rev_seq_concat, "");
			printf("Processing filenames are: %s\n", pdfFiles[i]);
			
			MEM_free(TempdirectoryPath);
			TempdirectoryPath=(char *)MEM_alloc(500);
			
			
			strcpy(TempdirectoryPath, "");
			strcat(TempdirectoryPath, "/user/cvprod/suryansh/CCDOCS_FROM_PFIRST/");
			strcat(TempdirectoryPath, pdfFiles[i]);
			
			//strcpy(filenameCopy,pdfFiles[i]);
			strncpy(filenameCopy, pdfFiles[i], sizeof(filenameCopy));
			filenameCopy[sizeof(filenameCopy) - 1] = '\0';
			
			char *dot = strrchr(filenameCopy, '.');
			if (dot) *dot = '\0';
			
			// Tokenize filename using "_"
			char *token = strtok(filenameCopy, "_");
			int tokenIndex = 0;
			
			// Reset variables
			strcpy(Partnodup, "");
			strcpy(revisioniddup, "");
			strcpy(sequencedup, "");
			strcpy(runningnodup, "");
			
			while (token != NULL)
			{
				if (tokenIndex == 1) 
				{
					strncpy(Partnodup, token, sizeof(Partnodup));
				} 
				else if (tokenIndex == 2) 
				{
					strncpy(revisioniddup, token, sizeof(revisioniddup));
				}
				else if (tokenIndex == 3)
				{
					strncpy(sequencedup, token, sizeof(sequencedup));
				}
				else if (tokenIndex == 4)
				{
					strncpy(runningnodup, token, sizeof(runningnodup));
				}
				token = strtok(NULL, "_");
				tokenIndex++;
			}
			
			printf("Partnodup is : %s\n", Partnodup);
			printf("revisioniddup is: %s\n", revisioniddup);
			printf("sequencedup is: %s\n", sequencedup);
			printf("runningnodup is: %s\n", runningnodup);
			
			strcpy(rev_seq_concat, revisioniddup);
			strcat(rev_seq_concat, ";");
			strcat(rev_seq_concat, sequencedup);
			
			strcpy(filename_new,"CC");
			strcat(filename_new,"_");
			strcat(filename_new,Partnodup);
			strcat(filename_new,"_");
			strcat(filename_new,revisioniddup);
			strcat(filename_new,"_");
			strcat(filename_new,sequencedup);
			strcat(filename_new,"_");
			strcat(filename_new,runningnodup);
			
			printf("\n pppppp filename_new is %s",filename_new);fflush(stdout);
			
			
			printf("\n rev_seq_concat is: %s\n", rev_seq_concat);
			GRM_find_relation_type("IMAN_reference",&Ref_type);
			
			QRY_find2("DesignRevision Sequence",&tItemobj);
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {rev_seq_concat,Partnodup};
				
				QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
				
				if(n_itemobj_found >0)
				{	
					titemobj_result=titemobj_results[0];
					
					GRM_list_secondary_objects_only(titemobj_result,Ref_type,&cnt,&doc_tags);
					printf("\n now secondary object count is %d",cnt);
					
					bool cc_document_found = false;
					
				for(j=0;j<cnt;j++)
				{	
						doc_tag=doc_tags[j];
						
						AOM_ask_value_string(doc_tag,"object_desc",&DocDesc);
						printf("\n DocDesc .......[%s]",DocDesc);fflush(stdout);
						
						if(tc_strstr(DocDesc,"CC_")!=NULL)
						{
							
							printf("\n CC document is alredy added");
							cc_document_found = true;
							break;
						}
				}
				
				if(cc_document_found) 
				{
					
					printf("\nSkipping attaching new CC document as one is already attached.\n");
				} 
				else 
				{
					// Attach the new document here
					printf("\nNo CC document found. Attaching new document.\n");
					// Attach document code goes here
					printf("\n Inside the else for attachment");
					AE_find_datasettype2("PDF", &datasettype);
					printf("\n CC_Step 22222222 --->");fflush(stdout);
					AE_create_dataset_with_id(datasettype,filename_new,filename_new, NULL, NULL, &NewPdfdataset);
					printf("\n CC_Step 3333333 --->");fflush(stdout);
					AOM_lock(NewPdfdataset);
					
					AE_set_dataset_format2(NewPdfdataset, "BINARY_REF");
					
				/*	printf("\n CC_Step 4444444 --->");fflush(stdout);
					AE_ask_datasettype_def_tool(datasettype, &tool);
					printf("\n CC_Step 555555 --->");fflush(stdout);
					AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
					printf("\n CC_Step 666666 --->");fflush(stdout);
					IMF_import_file(directoryPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
					printf("\n CC_Step 777777 --->");fflush(stdout);
					AOM_save_without_extensions(filetag);
					printf("\n CC_Step 8888888 --->");fflush(stdout);
					AE_add_dataset_named_ref2(NewPdfdataset,ref_list[0],tagRefType,filetag);
					printf("\n CC_Step 9999999 --->");fflush(stdout);*/
					
					AE_set_dataset_tool(NewPdfdataset,tool);
					printf("\n CC_Step 4444444 --->");fflush(stdout);
					
					printf("\n before importing TempdirectoryPath is %s",TempdirectoryPath);fflush(stdout);
					////user/cvprod/suryansh/CCDOCS_FROM_PFIRST/CC_2661H2D0135054_NR_1_01.pdf
					IMF_import_file(TempdirectoryPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
					printf("\n CC_Step 555555 --->");fflush(stdout);
					AE_import_named_ref(NewPdfdataset,"PDF",filename_new,NULL,SS_BINARY);
					printf("\n CC_Step 666666 --->");fflush(stdout);
					AOM_save_without_extensions(filetag);
					printf("\n CC_Step 777777 --->");fflush(stdout);
					AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
					printf("\n CC_Step 8888888 --->");fflush(stdout);
					AE_add_dataset_named_ref2(NewPdfdataset,ref_list[0],tagRefType,filetag);
					printf("\n CC_Step 9999999 --->");fflush(stdout);
					AE_set_dataset_tool(NewPdfdataset,tool);
					printf("\n CC_Step 1010101010101010101 --->");fflush(stdout);
					AOM_save_without_extensions(NewPdfdataset);
					printf("\n CC_Step 11 --->");fflush(stdout);
					
					AOM_save_without_extensions(NewPdfdataset);
					AOM_refresh(NewPdfdataset,0);
					AOM_unlock(NewPdfdataset);
				//	AE_set_dataset_tool(NewPdfdataset,tool);
				//	printf("\n CC_Step 10 --->");fflush(stdout);
				//	AOM_save_without_extensions(NewPdfdataset);
				//	printf("\n CC_Step 11 --->");fflush(stdout);
					
					GRM_create_relation(titemobj_result, NewPdfdataset, Ref_type, NULLTAG, &relation);
					printf("\n CC_Step 12 --->");fflush(stdout);
					GRM_save_relation(relation);
					printf("\n CC_Step 13 --->");fflush(stdout);
				}
				
					
					//	if(cnt>0)
					//	{
							
					//		printf("\n alredy added");
					//	}
					/*	else 
						{
							//need to attach 
							printf("\n Inside the else for attachment");
							AE_find_datasettype2("PDF", &datasettype);
							printf("\n CC_Step 22222222 --->");fflush(stdout);
							AE_create_dataset_with_id(datasettype,filename_new,filename_new, NULL, NULL, &NewPdfdataset);
							printf("\n CC_Step 3333333 --->");fflush(stdout);
							AE_set_dataset_format2(NewPdfdataset, "BINARY_REF");
							printf("\n CC_Step 4444444 --->");fflush(stdout);
							AE_ask_datasettype_def_tool(datasettype, &tool);
							printf("\n CC_Step 555555 --->");fflush(stdout);
							AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
							printf("\n CC_Step 666666 --->");fflush(stdout);
							IMF_import_file(directoryPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
							printf("\n CC_Step 777777 --->");fflush(stdout);
							AOM_save_without_extensions(filetag);
							printf("\n CC_Step 8888888 --->");fflush(stdout);
							AE_add_dataset_named_ref2(NewPdfdataset,ref_list[0],tagRefType,filetag);
							printf("\n CC_Step 9999999 --->");fflush(stdout);
							AE_set_dataset_tool(NewPdfdataset,tool);
							printf("\n CC_Step 10 --->");fflush(stdout);
							AOM_save_without_extensions(NewPdfdataset);
							printf("\n CC_Step 11 --->");fflush(stdout);
							
							GRM_create_relation(titemobj_result, NewPdfdataset, Ref_type, NULLTAG, &relation);
							printf("\n CC_Step 12 --->");fflush(stdout);
							GRM_save_relation(relation);
							printf("\n CC_Step 13 --->");fflush(stdout);
						}
						*/
				//}
				}
				
				
			}
			
			
			

        
		}

		
		
	}
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}

	printf("\nEnd of program.....!!\n");fflush(stdout);
	printf("\n*********************\n");fflush(stdout);
	ifail = ITK_exit_module(true);
	return ifail;
}


