/***************************************************************************
*  File				:   ACMISReportESOct.c
*  Created By		: 	Sai D. Raypalwar.
*  Created On		:   20-Dec-2023
*  Project			:   TML
*  Purpose			:  Cost Estimate MIS Report-->Daily/Weekly/Monthly MIS Report to be auto circulated for all E99 Parts in TCUA.
*  
*****************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#include <tc/folder.h>
//#include "tm_apl_std_common_function.c"
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;

signed long daysInSecond(signed int day){
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

struct Date 
{
    int d, m, y;
};

const int monthDays[12]= { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

int countLeapYears(struct Date d)
{
    int years = d.y;

    if (d.m <= 2)
        years--;

    return years / 4
           - years / 100
           + years / 400;
}


int getDifference(struct Date dt1,struct Date dt2)
{
	int i,j;
    long int n2;
    long int n1 = dt1.y * 365 + dt1.d;
    //printf("\n N1 for year mult=%ld",n1);
	
	for (i = 0; i < dt1.m - 1; i++)
	{
		n1 += monthDays[i];
	}
	
//printf("\n N1 after adding mnth=%ld",n1);
	n1 += countLeapYears(dt1);
    //printf("\n N1 after adding leap years=%ld",n1);

    n2 = dt2.y * 365 + dt2.d;
    //printf("\n n2 for year mult=%ld",n2);

    for (j = 0; j < dt2.m - 1; j++)
    {
		n2 += monthDays[j];
    }     
	//printf("\n n2 after adding mnth=%ld",n2);
	
	n2 += countLeapYears(dt2);
	
    //printf("\n n2 after adding leap years=%ld",n2);
	
	return (n2 - n1);
}

 char* PendingWithDecode(char* ProcessEDNtypeDup) 
{
	char* PendingWith =NULL;
	PendingWith = (char*) MEM_alloc(20);
	if(tc_strcmp(ProcessEDNtypeDup,"APLJ Working")==0)//tc_strcmp
		tc_strcpy(PendingWith, "APL Planner");
	if(tc_strcmp(ProcessEDNtypeDup,"APL Pre-Released")==0)
		tc_strcpy(PendingWith, "APL Reviewer");
	if(tc_strcmp(ProcessEDNtypeDup,"APL Final Released")==0)
		tc_strcpy(PendingWith, "PSD Planner");
	if(tc_strcmp(ProcessEDNtypeDup,"PSD Working")==0)
		tc_strcpy(PendingWith, "PSD Planner");
	if(tc_strcmp(ProcessEDNtypeDup,"PSD Final Released")==0)
		tc_strcpy(PendingWith, "PSD Reviewer");
	
	return PendingWith;
}

char* Daycalculation(char* TimeStampInDup,char* TimeStampoutDup)
{
	//t5MethodInitWMD("Daycalculation");
	
	char*   TimeStampInDup1 = NULL;
	TimeStampInDup1=(char*) MEM_alloc(80);
    char*   Year            = NULL;
    char*  	Month           = NULL;
    //char*  	Month0           = NULL;
    char*  	Date            = NULL;
	
	int d1=0,m1=0,y1=0;
	
	char*   TimeStampInDup12 = NULL;
	TimeStampInDup12=(char*) MEM_alloc(80);
    char*   Year1            = NULL;
    char*   Month1           = NULL;
    char*   Date1            = NULL;
	
	int d2=0,m2=0,y2=0;
	int             num                 = 0;
	
	if(TimeStampInDup!=NULL)
	{
		
		//TimeStampInDup1 = nlsStrDup(TimeStampInDup);
		tc_strcpy(TimeStampInDup1,TimeStampInDup);
		Date=strtok(TimeStampInDup1,"-");
        Month=strtok(NULL,"-");
        Year=strtok(NULL,"-");
		m1=getMonth(Month);
		printf("Month %d ",m1);fflush(stdout);
		if((Date!=NULL)&&(Year!=NULL))
        {
			
			d1 = atoi(Date);
           // m1 = atoi(Month);
            y1 = atoi(Year);  
			                          
        }
		
    }
	if(TimeStampoutDup!=NULL)
	{
		
		//TimeStampInDup12 = nlsStrDup(TimeStampoutDup);
		tc_strcpy(TimeStampInDup12,TimeStampoutDup);
		Date1=strtok(TimeStampInDup12,"-");
        Month1=strtok(NULL,"-");
        Year1=strtok(NULL,"-");
		
		if((Date1!=NULL)&&(Month1!=NULL)&&(Year1!=NULL))
        {
			d2 = atoi(Date1);
            m2 = atoi(Month1);
            y2 = atoi(Year1);                     
        }
		
    }
	printf("\n Date: %d , Month :%d, Year :%d \n",d1,m1,y1);fflush(stdout);
	printf("\n Date: %d , Month :%d, Year :%d \n",d2,m2,y2);fflush(stdout);  
	struct Date dt1 = { d1, m1, y1 };
    struct Date dt2 = { d2, m2, y2 };                                                                               
    num = getDifference(dt1,dt2);
	printf("\n num  Diff %d \n",num);fflush(stdout);  
    
	char *numD =NULL;
	numD = (char*) MEM_alloc(25);
    sprintf(numD,"%d",num); 
	printf(" numD %s",numD);fflush(stdout);
	return numD;
	//return num;
}

int getMonth( char* m)
{
	char* cMonth =NULL;
	cMonth = (char*) MEM_alloc(100); 
    if(tc_strstr(m,"Jan")!=NULL)
	{
		return 1;
	}
	else if(tc_strstr(m,"Feb")!=NULL)
	{
		return 2;
	}
	else if(tc_strstr(m,"Mar")!=NULL)
	{
		return 3;
	}
	else if(tc_strstr(m,"Apr")!=NULL)
	{
		return 4;
	}
	else if(tc_strstr(m,"May")!=NULL)
	{
		return 5;
	}
	else if(tc_strstr(m,"Jun")!=NULL)
	{
		return 6;
	}
	else if(tc_strstr(m,"Jul")!=NULL)
	{
		return 7;
	}
	else if(tc_strstr(m,"Aug")!=NULL)
	{
		return 8;
	}
	else if(tc_strstr(m,"Sep")!=NULL)
	{
		return 9;
	}
	else if(tc_strstr(m,"Oct")!=NULL)
	{
		return 10;
	}
	else if(tc_strstr(m,"Nov")!=NULL)
	{
		return 11;
	}
	else if(tc_strstr(m,"Dec")!=NULL)
	{
		return 12;
	}
	
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");fflush(stdout);
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%m-%Y",timeptr);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%m-%Y-%H-%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%m_%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);fflush(stdout);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));fflush(stdout);
	printf("Month:%d\n",(timeptr->tm_mon)+1);fflush(stdout);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

void autoresizestrAdd1(char **src,char* dest)
{
	char * desc = dest ? dest : "NA";
	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
	tc_strcat(*src , desc);
	tc_strcat(*src ,"/");
}

void projectcodefind(char * ProjectCode,char * GroupName,char * APLPlanner,char**userinfo)
{
	tag_t group_tag =NULLTAG;
	tag_t user_tag =NULLTAG;
	tag_t *role_tags =NULLTAG;
	tag_t *member_tags =NULLTAG;
	
	ITKCALL(SA_find_group(GroupName,&group_tag));
	int num_of_members = 0;
	int num_of_roles = 0;
	 char    rolename[SA_name_size_c+1]; 
	int q = 0;
	int t = 0;
	int usercount = 0;
	char* *MBOMUserset =NULLTAG;
	char** UserIDlist =NULLTAG;
	UserIDlist =(char**)MEM_alloc(sizeof(char*)*1);
	MBOMUserset =(char**)MEM_alloc(sizeof(char*)*1);
	ITKCALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags));
	printf("\nNo of Role found in Group are :%d\n",num_of_roles);
	if(num_of_roles>0)
	{
		for(q=0;q<num_of_roles ;q++) 
		{
			ITKCALL(SA_ask_role_name(role_tags[q],rolename));
			printf("\nRol Name :[%d][%s]\n",q,rolename);
			if(tc_strstr(rolename,APLPlanner)!=NULL) 
			{
				ITKCALL(SA_find_groupmember_by_role(role_tags[q],group_tag,&num_of_members,&member_tags));
				printf("\nNo of Group sr922335.ttl	manishk1.ttlSep@70 found in Group/Role are :%d\n",num_of_members);
				if(num_of_members>0)
				{
					tc_strcpy(*userinfo,"");
					for (t=0;t<num_of_members;t++)
					{
						ITKCALL(SA_ask_groupmember_user(member_tags[t],&user_tag));
						char * userid =NULL;
						char * surname1 =NULL;
						
						ITKCALL(SA_ask_user_identifier2(user_tag,&userid));
						printf("\nUser ID Name :[%s]\n",userid);fflush(stdout); 
						SA_ask_user_person_name2(user_tag,&surname1);
						printf("\n surname1 %s\n",surname1);fflush(stdout);
						
						tc_strcat(*userinfo,surname1); //sai raypalwar (srr922335)
						tc_strcat(*userinfo,"(");
						tc_strcat(*userinfo,userid);
						tc_strcat(*userinfo,")");
						tc_strcat(*userinfo,"/");
						
						/* tag_t*  DMLREVTag 	= NULLTAG;
						tag_t   querytag	= NULLTAG;
						ITKCALL(QRY_find2("ProjectUserAccessDet_updated",&querytag));
						
						
						printf("\n\n Inside Query Execute ");fflush(stdout);
						int Obj_Count = 0;
						char    *QryEntries[4]  = {"Project ID","Group Name","Role Name","Id"};
						char	**QryValues= (char **) MEM_alloc(5 * sizeof(char *));
						QryValues[0]=ProjectCode;
						QryValues[1]=GroupName;
						QryValues[2]=APLPlanner;
						QryValues[3]=userid;
						
						ITKCALL(QRY_execute(querytag,4, QryEntries, QryValues, &Obj_Count, &DMLREVTag));
						printf("\n DMLREVTag count :%d \n",Obj_Count);fflush(stdout);
						
						if(Obj_Count==1)
						{
							printf("\n user Having Project Acess ");fflush(stdout);
							
							
							tc_strcat(*userinfo,surname1); //sai raypalwar (srr922335)
							tc_strcat(*userinfo,"(");
							tc_strcat(*userinfo,userid);
							tc_strcat(*userinfo,")");
							tc_strcat(*userinfo,"/");
							
						}
						else
						{
							printf("\n user not Having Project Acess ");fflush(stdout);
						} */
					} 
				}
				break;
				
			}
			
			//break;
		}
	}
	printf("\n userinfo end  :%s ",*userinfo);
	
}

int ITK_user_main(int argc,char *argv[])
{
	int iFail     = 0;
	int status     = 0;
	
	//*******************************AUTO Login **************** 
	ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	ITKCALL(ITK_auto_login());
	ITK_set_bypass(true);
	ITKCALL(ITK_set_journalling(TRUE));
	
	printf("\n Login Sucessful\n");fflush(stdout);
	
	//**************************END*********************************
	FILE *Report = NULL;
	
	char* PlantName = NULL;
	PlantName=(char*) MEM_alloc(10);
	PlantName=ITK_ask_cli_argument("-s=");
	
	char CurrentDate[20]={0};
	getCurrentDateTime(CurrentDate);
	printf("\n\n Current Date is [%s] \n\n",CurrentDate);fflush(stdout);
	
	char* GenMakeBuyInd =NULL;
	GenMakeBuyInd=(char*) MEM_alloc(50);
	char* CVBUPlantName =NULL;
	CVBUPlantName=(char*) MEM_alloc(50);
	char* Plantdecode =NULL;
	Plantdecode=(char*) MEM_alloc(20);
	char* GroupName =NULL;
	GroupName=(char*) MEM_alloc(20);
	char* ReleaseStatus =NULL;
	ReleaseStatus =(char*) MEM_alloc(60);
	
	if (tc_strcmp(PlantName,"JSR")==0)
	{
		tc_strcpy(ReleaseStatus,"T5_LcsApljRlzd");
		tc_strcpy(CVBUPlantName, "CVBU JSR");
		tc_strcpy(Plantdecode, "APLJ");
		tc_strcpy(GroupName, "APLJSR");
		tc_strcpy(GenMakeBuyInd,"t5_JsrMakeBuyIndicator");
	}
	else if (tc_strcmp(PlantName,"PUNE")==0)
	{
		tc_strcpy(ReleaseStatus, "T5_LcsAplpRlzd");
		tc_strcpy(CVBUPlantName, "CVBU PUNE");
		tc_strcpy(Plantdecode, "APLP");
		tc_strcpy(GroupName, "APLPUNE");
        tc_strcpy(GenMakeBuyInd,"t5_PunMakeBuyIndicator");
	}
	else if (tc_strcmp(PlantName,"LKO")==0)
	{
		tc_strcpy(ReleaseStatus, "T5_LcsApllRlzd");
		tc_strcpy(CVBUPlantName, "CVBU LKO");
		tc_strcpy(Plantdecode, "APLL");
		tc_strcpy(GroupName, "APLLKO");
        tc_strcpy(GenMakeBuyInd,"t5_LkoMakeBuyIndicator");
	}
    else if (tc_strcmp(PlantName,"DWD")==0)
	{
		tc_strcpy(ReleaseStatus, "T5_LcsApldRlzd");
		tc_strcpy(CVBUPlantName, "DHARWAD");
		tc_strcpy(Plantdecode, "APLD");
		tc_strcpy(GroupName, "APLDWD");
        tc_strcpy(GenMakeBuyInd,"t5_DwdMakeBuyIndicator");
	}
    else if (tc_strcmp(PlantName,"PNR")==0)
	{
		tc_strcpy(ReleaseStatus, "T5_LcsApluRlzd"); 
		tc_strcpy(CVBUPlantName, "CVBU UTK");
		tc_strcpy(Plantdecode, "APLU"); 		
		tc_strcpy(GroupName, "APLUTK"); 		
        tc_strcpy(GenMakeBuyInd,"t5_PnrMakeBuyIndicator");
	}
	
	printf("\n ReleaseStatus :%s ,CVBUPlantName :%s ,Plantdecode %s ,GenMakeBuyInd %s \n",ReleaseStatus,CVBUPlantName,Plantdecode,GenMakeBuyInd);fflush(stdout);
	
	//Get Date Range
	struct tm *timeinfo;
	time_t t1;
	time_t t3;
	char buffer[256];
	
	t1 = time(NULL);
	
	char* sysdateFrom =NULL;
	sysdateFrom=(char*) MEM_alloc(50);
	tc_strcpy(sysdateFrom,"01-Oct-2023 00:00");
	printf("\n Date Range From:	%s ",sysdateFrom);fflush(stdout);
	
	char* sysdateTo =NULL;
	sysdateTo=(char*) MEM_alloc(50);
	t3 = shiftDate(t1,-1);
	timeinfo = localtime(&t3);
	strftime (buffer, 20, "%d-%b-%Y",timeinfo);
	tc_strcpy(sysdateTo,buffer);
	tc_strcpy(sysdateTo,"");
	tc_strcpy(sysdateTo,buffer);
	tc_strcat(sysdateTo," 23:59");
	printf("\n Date Range To:	%s ",sysdateTo);fflush(stdout);
	
	char* DesignDe =NULL;
	DesignDe=(char*) MEM_alloc(100);
	char* filename =NULL;
	filename=(char*) MEM_alloc(10000);
	tc_strcpy(filename,"");
	tc_strcat(filename,"ACMISReportESUA_");
	tc_strcat(filename,PlantName);
	tc_strcat(filename,"-");
	tc_strcat(filename,CurrentDate);
	tc_strcat(filename,".csv");
	printf("\n File Name %s \n",filename);fflush(stdout);
	
	//********************************** FILE print *********************************
	
	Report = fopen(filename,"w");
	fprintf(Report,"\n ,, MIS Report for Estimate Sheet & SMH Data For E98/E99 parts Released from ");fflush(Report); //XXXX Plant between,,,,
	fprintf(Report,PlantName);fflush(Report);
	fprintf(Report," Plant between,,,,");fflush(Report);
	fprintf(Report,"\n ,from Date : %s",sysdateFrom);fflush(Report);
	fprintf(Report,"\n ,To Date	 : %s",sysdateTo);fflush(Report);
	fprintf(Report,"\n ------,-------------------,-------------,--------------,-------,--------------,-------,--------------,--------------,--------------,--------------,--------------,---------,--------------,------------,-------------,--------------,---------,--------------,-----------,-----------,------------,--------------");fflush(Report);
	
	fprintf(Report,"\n Sr No,VC / Agg No.,Rev/Seq,Colour Part,Part CS,Project code,Design Group,DR/AR Status,Desc,APL DML Number,APL Release Date,Is E.S Created By Planner,Estimate Sheet No,Process EDN No,Process EDN Type,Pending at APL planner,No. of Days with APL Planner,Pending at APL Reviewer,No. of Days with  APL Reviewer,Pending at PSD planner,No. of Days with PSD planner ,Pending at PSD Reviewer,No. of Days with PSD Reviewer \n");fflush(Report);
	
	
	
	//************************************************************************************
	
	int Obj_Count = 0;
	int serial =0;
	int ReleaseEScnt =0;
	int TotalEScnt =0;
	int APLEScnt =0;
	int PSDEScnt =0;
	tag_t*  DMLREVTag 	= NULLTAG;
	tag_t   querytag	= NULLTAG;
	ITKCALL(QRY_find2("General...",&querytag));
	if(querytag != NULLTAG)
	{
		printf("\n\n Inside Query Execute ");fflush(stdout);
		
		char    *QryEntries[5]  = {"Name","Type","Created After","Created Before","Release Status"};
		char	**QryValues= (char **) MEM_alloc(5 * sizeof(char *));
		QryValues[0]="*";
		QryValues[1]="T5_APLDMLRevision";
		QryValues[2]=sysdateFrom;
		QryValues[3]=sysdateTo;
		QryValues[4]=ReleaseStatus;
		ITKCALL(QRY_execute(querytag,5, QryEntries, QryValues, &Obj_Count, &DMLREVTag));
		printf("\n DMLREVTag count :%d \n",Obj_Count);fflush(stdout);
		
		char*  DMLNO =NULL;
		char*  DMlReleaseType =NULL;
		char*  EDNdesc1 =NULL;
		char*  Taskno =NULL;
		char*  FINALSTATUSNAME =NULL;
		char*  bmomRLZdDate =NULL;
		tag_t*  listRLZ =NULLTAG;
		tag_t*  aplmbomTAsk =NULLTAG;
		if(Obj_Count>0)
		{
			int i =0;
			int q =0;
			int CCRLZ=0;
			int countptask=0;
			for(i=0;i<Obj_Count; i++)
			//for(i=0;i<700; i++)  
			{
				ITKCALL(AOM_ask_value_string(DMLREVTag[i],"item_id",&DMLNO));
				printf("\n DMLNO Number :%s \n",DMLNO);fflush(stdout);
				
				ITKCALL(AOM_ask_value_string(DMLREVTag[i],"t5_rlstype",&DMlReleaseType));
				printf("\n DMl ReleaseType :%s \n",DMlReleaseType);fflush(stdout);
				
				if(tc_strstr(DMlReleaseType,"TODR")!=NULL || tc_strstr(DMlReleaseType,"DM")!=NULL )
				{
					printf("\n Skeep TODR DML \n");fflush(stdout);
					continue;
				}
				
				WSOM_ask_release_status_list(DMLREVTag[i],&CCRLZ,&listRLZ);
				for(q=0;q<CCRLZ;q++)
				{
					AOM_ask_value_string(listRLZ[q],"object_name", &FINALSTATUSNAME);
					printf("\n\t\t\t\t==============Release Status APLJ %s\n\n",FINALSTATUSNAME);fflush(stdout);
					if(tc_strstr(FINALSTATUSNAME,ReleaseStatus)!=NULL)
					{
						AOM_UIF_ask_value(listRLZ[q],"date_released", &bmomRLZdDate);
						printf("\n\t\t\t\t==============Release Date %s\n\n",bmomRLZdDate);fflush(stdout);
					}
				}
				AOM_ask_value_tags(DMLREVTag[i],"T5_DMLTaskRelation",&countptask,&aplmbomTAsk);
				if (countptask>0)
				{
					int m =0;
					int countppart =0;
					tag_t* aplmbompart = NULLTAG;
					tag_t		solrelation_type	= NULLTAG;
					
					for(m=0;m<countptask;m++)
					{
						ITKCALL(AOM_ask_value_string(aplmbomTAsk[m],"item_id",&Taskno));
						printf("\n Taskno  :%s \n",Taskno);fflush(stdout);
						
						if(tc_strstr(Taskno,"PR")!=NULL)
						{
							printf("\n Skeep PR Task \n");fflush(stdout);
							continue;
						}
						else
						{
							printf(" \n Not PR task \n ");fflush(stdout);
							
							ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&solrelation_type));
							ITKCALL(GRM_list_secondary_objects_only(aplmbomTAsk[m],solrelation_type,&countppart,&aplmbompart));
							
							printf("\n countppart %d",countppart);fflush(stdout);
							
							if(countppart == 0)
							{
								ITKCALL(GRM_find_relation_type("CMReferences",&solrelation_type));
								ITKCALL(GRM_list_secondary_objects_only(aplmbomTAsk[m],solrelation_type,&countppart,&aplmbompart));
								
							}
							
							printf("\n part Count %d \n ",countppart);fflush(stdout);
							if(countppart>0)
							{
								int p =0;
								
								char* PartNo =NULL;
								char* Drstatus =NULL;
								char* RevSeqno =NULL;
								char* PartDec =NULL;
								char* PartDec1 =NULL;
								char* ProjectCode =NULL;
								char* DesignGrp =NULL;
								char* objectType =NULL;
								char* ColorPartNo =NULL;
								char* TestPartNo =NULL;
								char* objtype =NULL;
								char* CSNo =NULL;
								char* GrpMembName =NULL;
								char* EstShtPlant =NULL;
								char* EstShtID =NULL;
								char* EstShtname =NULL;
								char* ESEDNno =NULL;
								char* ESEdnType =NULL;
								tag_t Proj_tag =NULLTAG;
								tag_t partmaster =NULLTAG;
								tag_t EstimateSheetRel =NULLTAG;
								int grpmemitr =0;
								int GM_Count =0;
								tag_t* GM_Found1 =NULLTAG;
								int Admin_count =0;
								tag_t* GM_Found2 =NULLTAG;
								tag_t* GM_Found3 =NULLTAG;
								tag_t* ESheetTag =NULLTAG;
								int Priv_count =0;
								int Sheetcount =0;
								char * ESyn =NULL;
								ESyn =(char*) MEM_alloc(50);
								tag_t		ColorPartRel_type	= NULLTAG;
								
								char* APLPlanner =NULL;
								char* surname =NULL;
								char* surname1 =NULL;
								char*  APLPlannergrp =NULL;
								APLPlannergrp=(char*)MEM_alloc(1*sizeof(char*));
								char*  Assignegrp =NULL;
								Assignegrp=(char*)MEM_alloc(1*sizeof(char*));
								char* plannername =NULL;
								APLPlanner=(char*) MEM_alloc(120);
								char* userinfo =NULL;
								userinfo=(char*) MEM_alloc(1000*sizeof(char*));
								tc_strcpy(userinfo,"");
								
								for(p=0;p<countppart;p++)
								{
									tag_t part = NULLTAG;
									part =aplmbompart[p];
									int CntColorpart =0;
									tag_t* Colorpart = NULLTAG;
									//ITKCALL(AOM_ask_value_string(part,"object_type",&objtype));
									//printf("\n objtype  :%s \n",objtype);fflush(stdout);
									//if(tc_strstr(objtype,"Folder")==NULL)
									/* { */
										//ITKCALL(AOM_ask_value_string(part,"item_id",&PartNo));
										//printf("\n PartNo  :%s \n",PartNo);;fflush(stdout);
										
										ITKCALL(AOM_ask_value_string(part,GenMakeBuyInd,&CSNo));
										printf("\n CSNo  :%s \n",CSNo);fflush(stdout);
										
										ITKCALL(AOM_ask_value_string(part,"item_id",&TestPartNo));
										printf("\n TestPartNo  :%s \n",TestPartNo);fflush(stdout);
										
										if(tc_strstr(CSNo,"E99")!=NULL || tc_strstr(CSNo,"E98")!=NULL)
										{
											printf("\n After CS print   ");fflush(stdout);
											
											char* serialNo = NULL;
											serialNo = (char*) MEM_alloc(10);
											
											ITKCALL(AOM_ask_value_string(part,"object_type",&objectType));
											printf("\n objectType  :%s \n",objectType);fflush(stdout);
											
											if(tc_strstr(objectType,"T5_ClrPartRevision")!=NULL)
											{
												ITKCALL(AOM_ask_value_string(part,"item_id",&ColorPartNo));
												printf("\n ColorPartNo  :%s \n",ColorPartNo);fflush(stdout);
												ITKCALL(GRM_find_relation_type("TC_Is_Represented_By",&ColorPartRel_type));
												ITKCALL(GRM_list_secondary_objects_only(aplmbompart[p],ColorPartRel_type,&CntColorpart,&Colorpart));
												
												printf("\n Colorpart Count %d \n ",CntColorpart);fflush(stdout);
												if(CntColorpart>0)
												{
													int cp =0;
													for( cp=0;cp<CntColorpart;cp++)
													{
														tag_t cptag = NULLTAG;
														cptag =Colorpart[cp];
														
														ITKCALL(AOM_ask_value_string(cptag,"item_id",&PartNo));
														printf("\n PartNo  :%s \n",PartNo);fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(cptag,"item_revision_id",&RevSeqno));
														printf("\n RevSeqno  :%s \n",RevSeqno);fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(cptag,"object_desc",&PartDec));
														printf("\n PartDec  :%s \n",PartDec);fflush(stdout);
														STRNG_replace_str(PartDec,","," ",&PartDec1);
														printf("\n PartDec1  :%s \n",PartDec1);fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(cptag,"t5_ProjectCode",&ProjectCode));
														printf("\n ProjectCode  :%s \n",ProjectCode);fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(cptag,"t5_DesignGrp",&DesignGrp));
														printf("\n DesignGrp  :%s \n",DesignGrp);fflush(stdout);
														
														tc_strcpy(DesignDe,"");
														tc_strcat(DesignDe,"'");
														tc_strcat(DesignDe,DesignGrp);
														
														ITKCALL(AOM_ask_value_string(cptag,"t5_PartStatus",&Drstatus));
														printf("\n Drstatus  :%s \n",Drstatus);fflush(stdout);
													}
												}	
											}
											else
											{
											
												ITKCALL(AOM_ask_value_string(part,"item_id",&PartNo));
												printf("\n PartNo  :%s \n",PartNo);fflush(stdout);
												
												ITKCALL(AOM_ask_value_string(part,"item_revision_id",&RevSeqno));
												printf("\n RevSeqno  :%s \n",RevSeqno);fflush(stdout);
												
												ITKCALL(AOM_ask_value_string(part,"object_desc",&PartDec));
												printf("\n PartDec  :%s \n",PartDec);fflush(stdout);
												STRNG_replace_str(PartDec,","," ",&PartDec1);
												printf("\n PartDec1  :%s \n",PartDec1);fflush(stdout);
												
												ITKCALL(AOM_ask_value_string(part,"t5_ProjectCode",&ProjectCode));
												printf("\n ProjectCode  :%s \n",ProjectCode);fflush(stdout);
												
												ITKCALL(AOM_ask_value_string(part,"t5_DesignGrp",&DesignGrp));
												printf("\n DesignGrp  :%s \n",DesignGrp);fflush(stdout);
												tc_strcpy(DesignDe,"");
												tc_strcat(DesignDe,"'");
												tc_strcat(DesignDe,DesignGrp);
												
												ITKCALL(AOM_ask_value_string(part,"t5_PartStatus",&Drstatus));
												printf("\n Drstatus  :%s \n",Drstatus);fflush(stdout);
											
											}
											char* ColorPartNoDup =NULL;
											ColorPartNoDup=(char*) MEM_alloc(120);
											if(ColorPartNo!=NULL)
											{
												strcpy(ColorPartNoDup,ColorPartNo);
											}
											else
											{
												strcpy(ColorPartNoDup,"NA");
											}
											
											
											tc_strcpy(APLPlanner,DesignGrp);
											tc_strcat(APLPlanner,"_");
											tc_strcat(APLPlanner,Plantdecode);//APLD
											tc_strcat(APLPlanner,"_");
											tc_strcat(APLPlanner,"Planner");
											tag_t usern = NULLTAG;
											//ProjectCode,char * GroupName,char * APLPlanner
											printf ("\n befor print planner");fflush(stdout);
											projectcodefind(ProjectCode,GroupName,APLPlanner,&userinfo);
											const size_t a = strlen(userinfo);
											const size_t size_ab = a + 2;
											userinfo=(char *)MEM_realloc(userinfo,size_ab * sizeof(char *));
											printf ("\n Afr print planner");fflush(stdout);
											//PROJ_find(ProjectCode,&Proj_tag);
											/* if(Proj_tag!=NULLTAG)
											{
												printf("\n Going to find  Project Team.........\n");fflush(stdout);
												ITKCALL(PROJ_ask_team(Proj_tag,&GM_Count,&GM_Found1,&Admin_count,&GM_Found2,&Priv_count,&GM_Found3));
												printf("\n GM_Count %d",GM_Count);fflush(stdout);
												printf("\n Admin_count %d",Admin_count);fflush(stdout);
												printf("\n Priv_count %d",Priv_count);fflush(stdout);
												if(GM_Count>0)
												{
													for(grpmemitr=0;grpmemitr<GM_Count;grpmemitr++)
													{
														AOM_ask_value_string(GM_Found1[grpmemitr],"object_name",&GrpMembName); //00_APLJ_planner
														if(tc_strstr(GrpMembName,APLPlanner)!=NULL)
														{
															AOM_ask_value_string(GM_Found1[grpmemitr],"user_name",&plannername);
															
															printf("\n plannername %s\n",plannername);fflush(stdout);
															SA_find_user(plannername,&usern);
															SA_ask_user_person_name2(usern,&surname1);
															printf("\n surname1 %s\n",surname1);fflush(stdout);
															//WSOM_ask_name2(usern,&surname);
															//printf("\n surname %s\n",surname);fflush(stdout);
															tc_strcat(userinfo,surname1); //sai raypalwar (srr922335)
															tc_strcat(userinfo,"(");
															tc_strcat(userinfo,plannername);
															tc_strcat(userinfo,")");
															tc_strcat(userinfo,"/");
															
															//autoresizestrAdd1(&APLPlannergrp,userinfo); 
														}
														
												
													}
												}
												else
												{
													printf("\n GM_Count Zero ");fflush(stdout);
												}
											}
											else
											{
												printf("\n Paroject code Not Found :%s\n",ProjectCode);fflush(stdout);
											} */
											printf("userinfo %s \n",userinfo);fflush(stdout);
											//printf("APLPlannergrp %s \n",APLPlannergrp);fflush(stdout);
											ITEM_find_item(PartNo,&partmaster);
											ITKCALL(GRM_find_relation_type("T5_Design_Estimate_Relation",&EstimateSheetRel));
											if(EstimateSheetRel!=NULLTAG)
											{
												printf("\n Estimate foulder found\n");fflush(stdout);
												ITKCALL(GRM_list_secondary_objects_only(partmaster,EstimateSheetRel,&Sheetcount,&ESheetTag));
												printf("\n Number of estimate sheet found %d \n",Sheetcount);fflush(stdout);
												
												int S=0;
												int taskcount = 0;
												int subtask = 0;
												tag_t taskjob =NULLTAG;
												tag_t task_job_type =NULLTAG;
												tag_t *subtaskstag =NULLTAG;
												tag_t roottask =NULLTAG;
												char *nameoftaskjob =NULL;
												char *nameofroot =NULL;
												char *Assignee =NULL;
												char *Satartdate =NULL;
												char *ENDdate =NULL;
												char *taskstatus =NULL;
												char*  AnalystMA =NULL;
												AnalystMA=MEM_alloc(500);
												tc_strcpy(AnalystMA,"");
												char *currenttaskname =NULL;
												char*  Assignee1 =NULL;
												Assignee1=MEM_alloc(500);
												char * APLpendingDays =NULL;
												APLpendingDays=MEM_alloc(25);
												char * APLReviewpendingDays =NULL;
												APLReviewpendingDays=MEM_alloc(25);
												char * PSDpendingDays =NULL;
												PSDpendingDays=MEM_alloc(25);
												char * PSDReviewpendingDays =NULL;
												PSDReviewpendingDays=MEM_alloc(25);
												if(Sheetcount>0)
												{
													tc_strcpy(ESyn,"Yes");
													for(S=0;S<Sheetcount;S++)
													{
														ITKCALL(AOM_ask_value_string(ESheetTag[S],"item_id",&EstShtID));
														printf("\n Estimate sheet No %s  \n",EstShtID);fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(ESheetTag[S],"object_name",&EstShtname));
														printf("\n Estimate sheet name : %s  \n",EstShtname);fflush(stdout);
														
														ITKCALL(AOM_ask_value_string(ESheetTag[S],"t5_PEProcessEDNNo",&ESEDNno));
														printf("\n Estimate sheet EDN no %s  \n",ESEDNno);fflush(stdout);
														
														ITKCALL(AOM_UIF_ask_value(ESheetTag[S],"release_status_list",&ESEdnType));
														printf("\n release_status  %s  \n",ESEdnType);fflush(stdout);
														STRNG_replace_str(ESEdnType,",","-",&EDNdesc1);
														ITKCALL(AOM_ask_value_string(ESheetTag[S],"t5_PEPlantName",&EstShtPlant));
														printf("\n Estimate sheet Plant name is %s  \n",EstShtPlant);fflush(stdout);
														
														if ((tc_strstr(ESEdnType,"PSD Final Released")!=NULL))
														{
															ReleaseEScnt++;
															printf ("\n inside if PSD Final Released  \n");fflush(stdout);
															//continue;
															break;
														}
														else if((tc_strstr(EstShtPlant,CVBUPlantName)!=NULL) &&(tc_strstr(ESEdnType,"APL Working")!=NULL) )
														{
															printf("\n inside 1 \n");
															EPM_get_current_job(ESheetTag[S],&taskjob,&task_job_type);
															if(taskjob!=NULLTAG)
															{
																printf("\n Inside task job \n ");
																AOM_UIF_ask_value(taskjob,"object_name",&nameoftaskjob);
																printf("\n nameoftaskjob:- %s\n ",nameoftaskjob);fflush(stdout);
																EPM_ask_root_task(taskjob,&roottask);
																AOM_UIF_ask_value(roottask,"object_name",&nameofroot);
																printf("\n nameofroot:- %s\n ",nameofroot);fflush(stdout);
																EPM_ask_sub_tasks(roottask,&taskcount,&subtaskstag);
																printf("\n taskcount is  %d \n",taskcount);fflush(stdout);
																
																for(subtask=0;subtask<taskcount;subtask++)
																{
																	AOM_UIF_ask_value(subtaskstag[subtask],"task_state",&taskstatus);
																	AOM_UIF_ask_value(subtaskstag[subtask],"current_name",&currenttaskname);
																	printf("\n Task Status is :-------------->> %s   currenttaskname :- %s \n",taskstatus,currenttaskname);fflush(stdout);
																	
																	//AOM_UIF_ask_value(subtaskstag[subtask],"fnd0Assignee",&Assignee);
																	//STRNG_replace_str(Assignee,","," ",&Assignee1);
																	
																	printf("\n    \n Assignee [%s] \n",Assignee);fflush(stdout);
																	
																	AOM_UIF_ask_value(subtaskstag[subtask],"fnd0StartDate",&Satartdate);
																	printf("\n    \n Satart date [%s] \n",Satartdate);fflush(stdout);
																	
																	AOM_UIF_ask_value(subtaskstag[subtask],"fnd0EndDate",&ENDdate);
																	printf("\n    \n END date [%s] \n",ENDdate);fflush(stdout);
																	
																	//if((tc_strstr(taskstatus,"Pending")!=NULL) && (tc_strstr(currenttaskname,"Assign Estimate Sheet")!=NULL))
																	if((tc_strstr(currenttaskname,"Assign APL/PSD")!=NULL))
																	{
																		printf("\n    \n inside if Satart date [%s] \n",Satartdate);fflush(stdout);
																		printf("\n    \n inside if  END date [%s] \n",ENDdate);fflush(stdout);
																		
																		AOM_UIF_ask_value(subtaskstag[subtask],"awp0Acknowledgers",&Assignee);
																		//AOM_ask_value_string(subtaskstag[subtask],"awp0Acknowledgers",&Assignee);
																		printf("\n    \n pending signoff [%s] \n",Assignee);fflush(stdout);
																		
																		char* token = NULL;
																		char* token1 = NULL;
																		char* token2 = NULL;
																		
																		token = strtok(Assignee, "/");
																		printf("\n token: %s ",token);fflush(stdout);
																		token1 = strtok(NULL, "/");
																		printf("\n token1: %s ",token1);fflush(stdout);
																		token2 = strtok(NULL, ",");
																		printf("\n token2: %s ",token2);fflush(stdout);
																	
																		// Keep printing tokens while one of the
																		// delimiters present in str[].
																		/* while (token != NULL) {
																			autoresizestrAdd1(&Assignegrp,token); 
																			printf(" % s\n", token);
																			token = strtok(NULL, "/");
																			token = strtok(NULL, "/");
																			token = strtok(NULL, ",");
																		} */
																		//printf("APLPlannergrp %s \n",APLPlannergrp);fflush(stdout);
																		//STRNG_replace_str(Assignee,","," ",&Assignee1);
																		
																		printf("\n    \n pending signoff Detail [%s] \n",token2);fflush(stdout);
																		
																		printf("\n\n Current Date is [%s] \n\n",CurrentDate);fflush(stdout);
																		APLpendingDays = Daycalculation(Satartdate,CurrentDate);
																		printf("APLpendingDays %s",APLpendingDays);fflush(stdout);
																		serial++;
																		sprintf(serialNo,"%d",serial);
																		TotalEScnt++;
																		APLEScnt++;
																		fprintf(Report,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NA,NA,NA,NA,NA,NA \n",serialNo,PartNo,RevSeqno,ColorPartNoDup,CSNo,ProjectCode,DesignDe,Drstatus,PartDec1,DMLNO,bmomRLZdDate,ESyn,EstShtID,ESEDNno,EDNdesc1,token2,APLpendingDays);fflush(Report);
																	}
																	
																}
																
															}
															
															
														}
														else if((tc_strstr(EstShtPlant,CVBUPlantName)!=NULL) &&(tc_strstr(ESEdnType,"APL Pre-Released")!=NULL) )
														{
															printf("\n inside 1 \n");fflush(stdout);
															EPM_get_current_job(ESheetTag[S],&taskjob,&task_job_type);
															if(taskjob!=NULLTAG)
															{
																printf("\n Inside task job \n ");fflush(stdout);
																AOM_UIF_ask_value(taskjob,"object_name",&nameoftaskjob);
																printf("\n nameoftaskjob:- %s\n ",nameoftaskjob);fflush(stdout);
																EPM_ask_root_task(taskjob,&roottask);
																AOM_UIF_ask_value(roottask,"object_name",&nameofroot);
																printf("\n nameofroot:- %s\n ",nameofroot);fflush(stdout);
																EPM_ask_sub_tasks(roottask,&taskcount,&subtaskstag);
																printf("\n taskcount is  %d \n",taskcount);fflush(stdout);
																
																for(subtask=0;subtask<taskcount;subtask++)
																{
																	AOM_UIF_ask_value(subtaskstag[subtask],"task_state",&taskstatus);
																	AOM_UIF_ask_value(subtaskstag[subtask],"current_name",&currenttaskname);
																	printf("\n Task Status is :-------------->> %s   currenttaskname :- %s \n",taskstatus,currenttaskname);fflush(stdout);
																	
																	//AOM_UIF_ask_value(subtaskstag[subtask],"fnd0Assignee",&Assignee);
																	//STRNG_replace_str(Assignee,","," ",&Assignee1);
																	
																	printf("\n    \n Assignee [%s] \n",Assignee);fflush(stdout);
																	
																	AOM_UIF_ask_value(subtaskstag[subtask],"fnd0StartDate",&Satartdate);
																	printf("\n    \n Satart date [%s] \n",Satartdate);fflush(stdout);
																	
																	AOM_UIF_ask_value(subtaskstag[subtask],"fnd0EndDate",&ENDdate);
																	printf("\n    \n END date [%s] \n",ENDdate);fflush(stdout);
																	
																	//if((tc_strstr(taskstatus,"Pending")!=NULL) && (tc_strstr(currenttaskname,"APL Review Of Estimate Sheet")!=NULL))
																	if((tc_strstr(currenttaskname,"APL Pre-Released Status")!=NULL))
																	{
																		printf("\n    \n inside if Satart date [%s] \n",Satartdate);fflush(stdout);
																		printf("\n    \n inside if  END date [%s] \n",ENDdate);fflush(stdout);
																		
																		AOM_UIF_ask_value(subtaskstag[subtask],"awp0Acknowledgers",&Assignee);
																		//AOM_ask_value_string(subtaskstag[subtask],"valid_signoffs",&Assignee);
																		printf("\n    \n pending signoff [%s] \n",Assignee);fflush(stdout);
																		
																		char* token = NULL;
																		char* token1 = NULL;
																		char* token2 = NULL;
																		
																		token = strtok(Assignee, "/");
																		printf("\n token: %s ",token);fflush(stdout);
																		token1 = strtok(NULL, "/");
																		printf("\n token1: %s ",token1);fflush(stdout);
																		token2 = strtok(NULL, ",");
																		printf("\n token2: %s ",token2);fflush(stdout);
																	
																		// Keep printing tokens while one of the
																		// delimiters present in str[].
																		/* while (token != NULL) {
																			autoresizestrAdd1(&Assignegrp,token); 
																			printf(" % s\n", token);
																			token = strtok(NULL, "/");
																			token = strtok(NULL, "/");
																			token = strtok(NULL, ",");
																		} */
																		
																		//STRNG_replace_str(Assignee,","," ",&Assignee1);
																		
																		//printf("\n    \n pending signoff Detail [%s] \n",Assignegrp);fflush(stdout);
																		printf("\n    \n pending signoff Detail [%s] \n",token2);fflush(stdout);
																		
																		APLReviewpendingDays = Daycalculation(Satartdate,CurrentDate);
																		printf("APLReviewpendingDays %s",APLReviewpendingDays);fflush(stdout);
																		serial++;
																		sprintf(serialNo,"%d",serial);
																		TotalEScnt++;
																		APLEScnt++;
																		fprintf(Report,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NA,NA,%s,%s,NA,NA,NA,NA \n",serialNo,PartNo,RevSeqno,ColorPartNoDup,CSNo,ProjectCode,DesignDe,Drstatus,PartDec1,DMLNO,bmomRLZdDate,ESyn,EstShtID,ESEDNno,EDNdesc1,token2,APLReviewpendingDays);fflush(Report);
																		
																	}
																	
																}
																
															}
														}
														else if((tc_strstr(EstShtPlant,CVBUPlantName)!=NULL) &&(tc_strstr(ESEdnType,"PSD Working")!=NULL) )
														{
															printf("\n inside 1 \n");
															EPM_get_current_job(ESheetTag[S],&taskjob,&task_job_type);
															if(taskjob!=NULLTAG)
															{
																printf("\n Inside task job \n ");fflush(stdout);
																AOM_UIF_ask_value(taskjob,"object_name",&nameoftaskjob);
																printf("\n nameoftaskjob:- %s\n ",nameoftaskjob);fflush(stdout);
																EPM_ask_root_task(taskjob,&roottask);
																AOM_UIF_ask_value(roottask,"object_name",&nameofroot);
																printf("\n nameofroot:- %s\n ",nameofroot);fflush(stdout);
																EPM_ask_sub_tasks(roottask,&taskcount,&subtaskstag);
																printf("\n taskcount is  %d \n",taskcount);fflush(stdout);
																
																for(subtask=0;subtask<taskcount;subtask++)
																{
																	
																	AOM_UIF_ask_value(subtaskstag[subtask],"task_state",&taskstatus);
																	AOM_UIF_ask_value(subtaskstag[subtask],"current_name",&currenttaskname);
																	printf("\n Task Status is :-------------->> %s   currenttaskname :- %s \n",taskstatus,currenttaskname);fflush(stdout);
																	
																	//AOM_UIF_ask_value(subtaskstag[subtask],"fnd0Assignee",&Assignee);
																	//STRNG_replace_str(Assignee,","," ",&Assignee1);
																	
																	printf("\n    \n Assignee [%s] \n",Assignee);fflush(stdout);
																	
																	AOM_UIF_ask_value(subtaskstag[subtask],"fnd0StartDate",&Satartdate);
																	printf("\n    \n Satart date [%s] \n",Satartdate);fflush(stdout);
																	
																	AOM_UIF_ask_value(subtaskstag[subtask],"fnd0EndDate",&ENDdate);
																	printf("\n    \n END date [%s] \n",ENDdate);fflush(stdout);
																	
																	//if((tc_strstr(taskstatus,"Pending")!=NULL) && (tc_strstr(currenttaskname,"Update Time by PSD")!=NULL))
																	//if((tc_strstr(currenttaskname,"Acknowledge Task For PSD Planner")!=NULL) || (tc_strstr(currenttaskname,"Acknowledge Task For PSD Reviewer")!=NULL))
																	if((tc_strstr(currenttaskname,"Acknowledge Task For PSD Planner")!=NULL))
																	{
																		//AOM_UIF_ask_value(subtaskstag[subtask],"fnd0StartDate",&Satartdate);
																		printf("\n    \n inside if Satart date [%s] \n",Satartdate);fflush(stdout);
																		
																		AOM_UIF_ask_value(subtaskstag[subtask],"awp0Acknowledgers",&Assignee);
																		//AOM_ask_value_string(subtaskstag[subtask],"valid_signoffs",&Assignee);
																		printf("\n    \n pending signoff [%s] \n",Assignee);fflush(stdout);
																		
																		char* token = NULL;
																		char* token1 = NULL;
																		char* token2 = NULL;
																		
																		token = strtok(Assignee, "/");
																		printf("\n token: %s ",token);fflush(stdout);
																		token1 = strtok(NULL, "/");
																		printf("\n token1: %s ",token1);fflush(stdout);
																		token2 = strtok(NULL, ",");
																		printf("\n token2: %s ",token2);fflush(stdout);
																		// Keep printing tokens while one of the
																		// delimiters present in str[].
																		/* while (token != NULL) {
																			autoresizestrAdd1(&Assignegrp,token); 
																			printf(" % s\n", token);
																			token = strtok(NULL, "/");
																			token = strtok(NULL, "/");
																			token = strtok(NULL, ",");
																		} */
																		
																		//STRNG_replace_str(Assignee,","," ",&Assignee1);
																		
																		printf("\n    \n pending signoff Detail [%s] \n",token2);fflush(stdout);
																		//printf("\n    \n pending signoff Detail [%s] \n",Assignegrp);fflush(stdout);
																	
																		//AOM_UIF_ask_value(subtaskstag[subtask],"fnd0EndDate",&ENDdate);
																		printf("\n    \n inside if  END date [%s] \n",ENDdate);fflush(stdout);
																		
																		PSDpendingDays = Daycalculation(Satartdate,CurrentDate);
																		printf("PSDpendingDays %s",PSDpendingDays);fflush(stdout);
																		serial++;
																		sprintf(serialNo,"%d",serial);
																		TotalEScnt++;
																		PSDEScnt++;
																		fprintf(Report,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NA,NA,NA,NA,%s,%s,NA,NA \n",serialNo,PartNo,RevSeqno,ColorPartNoDup,CSNo,ProjectCode,DesignDe,Drstatus,PartDec1,DMLNO,bmomRLZdDate,ESyn,EstShtID,ESEDNno,EDNdesc1,token2,PSDpendingDays);fflush(Report);
																		printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NA,NA,NA,NA,%s,%s,NA,NA \n",serialNo,PartNo,RevSeqno,ColorPartNoDup,CSNo,ProjectCode,DesignDe,Drstatus,PartDec1,DMLNO,bmomRLZdDate,ESyn,EstShtID,ESEDNno,EDNdesc1,token2,PSDpendingDays);fflush(stdout);
																		
																	}
																	
																}
																
															}
														}
														/*else
														{
															printf("\n inside 1 \n");
															EPM_get_current_job(ESheetTag[S],&taskjob,&task_job_type);
															if(taskjob!=NULLTAG)
															{
																printf("\n Inside task job \n ");
																AOM_UIF_ask_value(taskjob,"object_name",&nameoftaskjob);
																printf("\n nameoftaskjob:- %s\n ",nameoftaskjob);
																EPM_ask_root_task(taskjob,&roottask);
																AOM_UIF_ask_value(roottask,"object_name",&nameofroot);
																printf("\n nameofroot:- %s\n ",nameofroot);
																EPM_ask_sub_tasks(roottask,&taskcount,&subtaskstag);
																printf("\n taskcount is  %d \n",taskcount);fflush(stdout);
																
																for(subtask=0;subtask<taskcount;subtask++)
																{
																	AOM_UIF_ask_value(subtaskstag[subtask],"task_state",&taskstatus);
																	AOM_UIF_ask_value(subtaskstag[subtask],"current_name",&currenttaskname);
																	printf("\n Task Status is :-------------->> %s   currenttaskname :- %s \n",taskstatus,currenttaskname);fflush(stdout);
																	
																	AOM_UIF_ask_value(subtaskstag[subtask],"fnd0Assignee",&Assignee);
																	STRNG_replace_str(Assignee,","," ",&Assignee1);
																	
																	printf("\n    \n Assignee [%s] \n",Assignee);fflush(stdout);
																	
																	AOM_UIF_ask_value(subtaskstag[subtask],"fnd0StartDate",&Satartdate);
																	printf("\n    \n Satart date [%s] \n",Satartdate);fflush(stdout);
																	
																	AOM_UIF_ask_value(subtaskstag[subtask],"fnd0EndDate",&ENDdate);
																	printf("\n    \n END date [%s] \n",ENDdate);fflush(stdout);
																	
																	//if((tc_strstr(taskstatus,"Pending")!=NULL) && (tc_strstr(currenttaskname,"PSD Review of Estimate Sheet")!=NULL))
																	if((tc_strstr(currenttaskname,"Acknowledge Task For PSD Reviewer")!=NULL))
																	{
																		printf("\n    \n inside if Satart date [%s] \n",Satartdate);fflush(stdout);
																		printf("\n    \n inside if  END date [%s] \n",ENDdate);fflush(stdout);
																		
																		PSDReviewpendingDays = Daycalculation(Satartdate,CurrentDate);
																		printf("PSDReviewpendingDays %s",PSDReviewpendingDays);fflush(stdout);
																		serial++;
																		sprintf(serialNo,"%d",serial);
																		fprintf(Report,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NA,NA,NA,NA,NA,NA,%s,%s \n",serialNo,PartNo,RevSeqno,PartDec1,DMLNO,bmomRLZdDate,ESyn,EstShtID,ESEDNno,ESEdnType,Assignee,PSDReviewpendingDays);fflush(Report);
																	}
																	
																}
																
															}
															
														}
														 */
													}
												}
												else
												{
													tc_strcpy(ESyn,"No");
													
													APLpendingDays = Daycalculation(bmomRLZdDate,CurrentDate);
													serial++;
													sprintf(serialNo,"%d",serial);
													TotalEScnt++;
													//printf("APLPlannergrp %s \n",APLPlannergrp);fflush(stdout);
													printf("APLPlannergrp %s \n",userinfo);fflush(stdout);
													fprintf(Report,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NA,NA,NA,%s,%s,NA,NA,NA,NA,NA,NA \n",serialNo,PartNo,RevSeqno,ColorPartNoDup,CSNo,ProjectCode,DesignDe,Drstatus,PartDec1,DMLNO,bmomRLZdDate,ESyn,userinfo,APLpendingDays);fflush(Report);
													printf("%s,%s,%s,%s,%s,%s,%s,%s,%s,NA,NA,NA,%s,NA,NA,NA,NA,NA,NA,NA \n",serialNo,PartNo,RevSeqno,CSNo,Drstatus,PartDec1,DMLNO,bmomRLZdDate,ESyn,EstShtID,ESEDNno,userinfo);fflush(stdout);
													
												}
											}
										}
										
										
									/* } */
								}
							}
							else
							{
								printf("\n Parts Not Found \n");fflush(stdout);
							}
						}
						
					}
				}
				else
				{
					printf("\n Task Not Found \n");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\n DML Not Found \n");fflush(stdout);
		}
	}	
	else
	{
		printf("\n Qury find Fail \n");fflush(stdout);
	}
	
	fprintf(Report,"\n END of Report  ------,-------------------,-------------,--------------,-------,--------------,-------,--------------,--------------,--------------,--------------,--------------,---------,--------------,------------,-------------,--------------,---------,--------------,-----------,-----------,------------,--------------");fflush(Report);
	
	fprintf(Report,"\n  Estimate Sheet Pending Total 	: %d ",TotalEScnt);fflush(Report);
	fprintf(Report,"\n  Estimate Sheet Released Total	: %d ",ReleaseEScnt);fflush(Report);
	fprintf(Report,"\n  Estimate Sheet Pending with APL : %d ",APLEScnt);fflush(Report); 
	fprintf(Report,"\n  Estimate Sheet Pending with PSD : %d ",PSDEScnt);fflush(Report);
	return ITK_ok;
}