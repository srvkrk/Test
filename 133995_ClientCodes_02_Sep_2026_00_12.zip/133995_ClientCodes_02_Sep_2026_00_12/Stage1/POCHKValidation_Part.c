/**************************************************************************
* Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*	Client code	: CHILD_PARENT_DML.c
*	Author		: Mohan Tayade
*	Created On	: 13/03/2014
*	PURPOSE		: This code is for Full path of PDF as per part number, revision and sequence.
*	Command		: CHILD_PARENT_DML InpFile.csv wrk_location
*	Input File	: Need to create input file "InpFile.csv" having list of parts.


*	Modification History :5523312060R
*	S.No    Date        CR No       Modified By                Modification Notes
************************************************************************/
#define _CLMAIN_DEFNS
#define _CLMAIN_DEFNS
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
int FetchCountDataFromTableSAPMATBULK(char* part_noDup,char* PartRev, int* iBulkCount,int *iStockCount,int *iPoCount,int *iTrnsctnCount,int *oPOREV);
char* t5EsSubString(char* mainStringf, int fromCharf, int toCharf) ;
int DZ_Check_RvlPOForFandF30_ERC(char PartNumber[60],char sPrtRevLDup[5],char PlantName[30]);
int DZ_Check_BulkMaterial_ERC(char PartNumber[60],char PlantName[30]);
int DZ_Check_POForFandF30_ERC(char PartNumber[60],char PlantName[30]);
int DZ_Check_Transection_ERC(char PartNumber[60],char PlantName[30]);
int DZ_Check_Stock_ERC(char PartNumber[60],char PlantName[30]);
int SetFlagforDBScope(SetOfObjects ScopeObjects ,integer *mfail);
status t5GetSapPlantAtERC(string planttype, string *SAPPlant, integer* mfail)
{
	char*  mod_name	= "t5GetSapPlantAtERC";
	status dstat = OKAY;
	if(*SAPPlant==NULL)   *SAPPlant=nlsStrAlloc(50);

	printf("\nInside t5GetSapPlantAtERC...planttype:[%s] \n",planttype);fflush(stdout);

	if (nlsStrCmp(planttype,"PCVBU")==0)
	{
		printf("\nInside PUNE CVBU.\n");fflush(stdout);
		nlsStrCpy(*SAPPlant,"1001");
	}
	else if (nlsStrCmp(planttype,"AHD")==0)
	{
		printf("\nInside AHD.\n");fflush(stdout);
		nlsStrCpy(*SAPPlant,"7501");
	}
	else if (nlsStrCmp(planttype,"CARPLT")==0)
	{
		printf("\nInside CARPLT.\n");fflush(stdout);
		nlsStrCpy(*SAPPlant,"1100");
	}
	else if (nlsStrCmp(planttype,"PUVBU")==0)
	{
		printf("\nInside PUVBU.\n");fflush(stdout);
		nlsStrCpy(*SAPPlant,"1140");
	}
	else  if (nlsStrCmp(planttype,"LKO")==0)
	{
		printf("\nInside LKO.\n");fflush(stdout);
		nlsStrCpy(*SAPPlant,"3001");
	}
	else if (nlsStrCmp(planttype,"JSR")==0)
	{
		printf("\nInside JSR.\n");fflush(stdout);
		nlsStrCpy(*SAPPlant,"2001");
	}
	else if (nlsStrCmp(planttype,"PNR")==0)
	{
		printf("\nInside PNR.\n");fflush(stdout);
		nlsStrCpy(*SAPPlant,"3100");
	}
	else if(nlsStrCmp(planttype,"DWD")==0)
	{
		printf("\nInside DWD.\n");fflush(stdout);
		nlsStrCpy(*SAPPlant,"1500");
	}
	else
	{
		printf("\n... Pune Plant\n");fflush(stdout);
		nlsStrCpy(*SAPPlant,"1001");
	}

	//	CLEANUP :
	//		t5PrintCleanUpModName;
	EXIT :
		t5CheckDstatAndReturn;
}

int SetFlagforDBScope(SetOfObjects ScopeObjects ,integer *mfail)
{
	int osc = 0;
	int oscitm = 0;
	int dbcnt = 0;
	int DBFlag = 0;
	int CheckOSCItemStats = 0;
	string sClsNmDup = NULL;
	string sClsNm = NULL;
	string docobjst1 = NULL;
	string databaseNameS = NULL;
	string databaseNameDupS = NULL;
	string DBInfo1Dup = NULL;
	SqlPtr DBsql = NULL;
	string DBInfo1 = NULL;
	status	dstat = OKAY;
	ObjectPtr oscItemObj = NULL;
	SetOfObjects soDbSet = NULL;
	SetOfStrings dbScpe1 = NULL;

	//printf("\n TOO: Checking DB Scope. \n");fflush(stdout);
	if (setSize(ScopeObjects)>0)
	{
		dbcnt=0;
		for(dbcnt=0;dbcnt<setSize(ScopeObjects);dbcnt++)
		{
			if(sClsNmDup) sClsNmDup=NULL;
			if(sClsNm) sClsNm=NULL;
			oscItemObj = setGet(ScopeObjects,dbcnt);
			if(oscItemObj)
			{
				if (dstat = objGetAttribute(oscItemObj,ClassAttr,&sClsNm)) goto CLEANUP;
				if(sClsNm) sClsNmDup = nlsStrDup(sClsNm);
				if(nlsStrCmp(sClsNmDup,"OscItem")==0)
				{
					printf("\n TOO:Obj class:[%s] ",sClsNmDup);fflush(stdout);
					DBFlag=1;
					printf(" OscItem found... \n");fflush(stdout);
					if(CheckOSCItemStats < 4)
					{
						if( dstat= objGetAttribute(oscItemObj,CurDbNameAttr,&databaseNameDupS)) goto CLEANUP;
						if(databaseNameDupS) databaseNameS = nlsStrDup(databaseNameDupS);
						printf(" Obj DB..:[%s]",databaseNameS);fflush(stdout);

						if (dstat = oiSqlCreateSelect(&DBsql)) goto CLEANUP;
						if(dstat = oiSqlWhereEQ(DBsql,t5SyscdAttr,"DBSET")) goto CLEANUP;
						if(dstat = QueryDbObject(t5CntrolClass,DBsql,0,TRUE,SC_SCOPE_OF_SESSION,&soDbSet,mfail)) goto CLEANUP;
						printf("\n No of DBset:[%d]",setSize(soDbSet));fflush(stdout);
						if (setSize(soDbSet)>0)
						{
							if(dstat=objGetAttribute(setGet(soDbSet,0),"t5Userinfo1",&DBInfo1Dup)) goto CLEANUP;
							if(DBInfo1Dup) DBInfo1 = nlsStrDup(DBInfo1Dup);
							printf(" DB name:[%s]",DBInfo1);fflush(stdout);
							if(nlsStrStr(DBInfo1,databaseNameS)!=NULL)
							{
								osc=0;
								GetDatabaseScope(PdmSessnClass,&dbScpe1,mfail);
								for (osc=0;osc<setSize(dbScpe1) ; osc++)
								{
									docobjst1=low_set_get(dbScpe1,osc);
									printf("\n DB pref check before..:%s\n",docobjst1);fflush(stdout);
								}

								low_set_add_str_unique(dbScpe1, databaseNameS);
								SetDatabaseScope(PdmSessnClass,dbScpe1,mfail);
								
								GetDatabaseScope(PdmSessnClass,&dbScpe1,mfail);
								oscitm=0;
								for (oscitm=0;oscitm<low_set_size(dbScpe1) ; oscitm++)
								{
									docobjst1=low_set_get(dbScpe1,oscitm);
									printf("\n DB pref check -after..:%s\n",docobjst1);fflush(stdout);
								}
								CheckOSCItemStats++;
							}
						}
					}
				}
			}
			else
			{
				printf("\nThe object provided in null");fflush(stdout);
			}
			if (DBFlag>0)
			{
				printf("\nGM: DB set done and return 1");fflush(stdout);
				return 1;
			}
		}
	}
	CLEANUP:
	return 0;
}

int t5CheckPOForPartt(ObjectPtr opAffPart,string SAPPlant,int SkipStockFlg,integer *mfail)
{
	int POCount = 0;
	int	StkIndCnt		=0;
	int	BulkIndCnt		=0;
	int	TrnsIndCnt		=0;
	int	RvlPOFlg		=0;
	int	BULKCount		=0;
	int	PLMPOcount		=0;
	int	STOCKCount		=0;
	int	STOCKFlag		=0;
	int	TrsnCount		=0;
	int	PORev		=0;
	string		StkCnt1	= NULL;
	int	POCunt		=0;
	string StkCnt = NULL;
	string sPrtRevLDup = NULL;
	string sPrtRevL = NULL;
	string sGrpChildPrt = NULL;
	string sGrpChildP = NULL;
	string sPrtOwnLDup = NULL;
	string sPrtOwnL = NULL;
	ObjectPtr opPrvAffPart = NULL;

	t5MethodInit("t5CheckPOForPartt");
	t5PrintModName;

	printf("\n POCHCK:F30: Checking t5CheckPOForPartt:%s",SAPPlant);fflush(stdout);
	if (dstat = objGetAttribute(opAffPart,PartNumberAttr,&sGrpChildP)) goto EXIT;
	if(!nlsIsStrNull(sGrpChildP)) sGrpChildPrt = nlsStrDup(sGrpChildP);
	if (dstat = objGetAttribute(opAffPart,RevisionAttr,&sPrtRevL)) goto EXIT;
	if(!nlsIsStrNull(sPrtRevL)) sPrtRevLDup = nlsStrDup(sPrtRevL);
	if (dstat = objGetAttribute(opAffPart,OwnerNameAttr,&sPrtOwnL)) goto EXIT;
	if(!nlsIsStrNull(sPrtOwnL)) sPrtOwnLDup = nlsStrDup(sPrtOwnL);
	printf("\n POCHCK:F30::Part[%s]  rev:[%s] Own:[%s].",sGrpChildPrt,sPrtRevLDup,sPrtOwnLDup);fflush(stdout);
	if(nlsStrStr(sPrtOwnLDup,"Release Vault")==NULL)
	{
		if(nlsStrCmp(sPrtRevLDup,"NR")!=0)
		{
			if(sPrtRevLDup)	sPrtRevLDup=NULL;
			if(sPrtRevL)	sPrtRevL=NULL;
			opPrvAffPart=NULL;
			if(dstat = GetPrevOfficialRev(opAffPart,&opPrvAffPart,mfail))goto CLEANUP;
			if(dstat=objGetAttribute(opPrvAffPart,RevisionAttr,&sPrtRevL)) goto CLEANUP;
			if(!nlsIsStrNull(sPrtRevL)) sPrtRevLDup = nlsStrDup(sPrtRevL);
			printf("Prev official rev is : [%s] \n",sPrtRevLDup);fflush(stdout);
			RvlPOFlg=1;
		}
	}
	if(!nlsIsStrNull(sGrpChildPrt))
	{
		PLMPOcount	=	0;
		BULKCount	=	0;
		STOCKFlag	=	0;
		STOCKCount	=	0;
		TrsnCount	=	0;
		POCunt	=	0;
		PORev	=	0;
		PLMPOcount= FetchCountDataFromTableSAPMATBULK(sGrpChildPrt,sPrtRevLDup,&BULKCount,&STOCKCount,&POCunt,&TrsnCount,&PORev);
		printf("\n PLM PO Count when FetchDataFromTableSAPMATBULK [%d]",PLMPOcount);fflush(stdout);

		printf("\n BULKCount : %d",BULKCount);fflush(stdout);
		printf("\n STOCKCount : %d",STOCKCount);fflush(stdout);
		printf("\n TrsnCount : %d",TrsnCount);fflush(stdout);
		printf("\n POCunt : %d",POCunt);fflush(stdout);
		printf("\n PORev : %d",PORev);fflush(stdout);
		if (STOCKCount >0)
		{
			StkCnt1			=	NULL;
			StkCnt1			=	nlsStrAlloc(10);
			nlsStrCpy(StkCnt1,"");
			sprintf(StkCnt1,"%d",STOCKCount);
			printf("\n POCHK:NonCol:: STOCKCount : [%d], STOCK string:[%s] available",STOCKCount,StkCnt1);fflush(stdout);
			printf("\n POCHK:NonCol:: STOCK count length : [%d] available",(nlsStrLen(StkCnt1)));fflush(stdout);
			if((nlsStrLen(StkCnt1) > 2) && (STOCKCount >0))
			{
				STOCKFlag=1;
				printf("\n POCHK:Found Valid STOCK.............");fflush(stdout);
			}
		}
		if (BULKCount >0)
		{
			return 1;
			printf("\n POCHK:NonCol::Found BULK COUNT.............");fflush(stdout);
		}
		else if(STOCKFlag >0)
		{
			return 2;
			printf("\n POCHK:NonCol::Found STOCK COUNT.............");fflush(stdout);
		}
		else if (TrsnCount >0)
		{
			return 3;
			printf("\n POCHK:NonCol::Found TrsnCount COUNT.............");fflush(stdout);
		}
		else if (POCunt >0)
		{
			printf("\n POCHK:NonCol:: Part:[%s]  Rev: [%s]  PORev:[%d] PO Count:[%d]\n",sGrpChildPrt,sPrtRevLDup,PORev,POCunt);
			if(PORev >0)
			{
				printf("\n POCHCK:NONCOL:P23::PO and Rev available..:[%s] \n",sGrpChildPrt);fflush(stdout);
				return 4;
			}
			else
			{
				printf("\n POCHCK:NONCOL:P2::...........PO Available Only:[%s] \n",sGrpChildPrt);fflush(stdout);
				return 5;
			}
		}
		else
		{
			//Informing manager to wait.
			printf("\n POCHCK:F30:Going for BULK COUNT check.");fflush(stdout);
			BulkIndCnt	=	0;
			BulkIndCnt	=	DZ_Check_BulkMaterial_ERC(sGrpChildPrt,SAPPlant);
			if(BulkIndCnt <=0)
			{
				StkIndCnt	=	0;
				StkCnt		=	NULL;
				StkCnt		=	nlsStrAlloc(10);
				printf("\n POCHCK:F30::Going for STOCK COUNT check.");fflush(stdout);
				/*CHECK ALTMAT PART, IF FOUND THEN TRANSACTION,PO, MRP AND STOCK WILL CHECK ON ALTMAT PART.
				ELSE TRANSACTION,PO, MRP AND STOCK WILL CHECK ON CURRENT CHILD PART.*/
				//CHECK STOCK IN SAP, IF STOCK IS LESS THAN 2 DIGIT, IT WILL CATCH IN SOFT CHECK.
				StkIndCnt	=	0;
				StkIndCnt	=	DZ_Check_Stock_ERC(sGrpChildPrt,SAPPlant);
				printf("\n POCHCK:F30:: STOCK COUNT is...: %d",StkIndCnt);fflush(stdout);
				//StkCnt			=	NULL;
				//StkCnt			=	nlsStrAlloc(10);
				nlsStrCpy(StkCnt,"");
				sprintf(StkCnt,"%d",StkIndCnt);
				printf("\n POCHCK:F30:: STOCK count : %d,STOCK string:%s available",StkIndCnt,StkCnt);fflush(stdout);
				printf("\n POCHCK:F30:: STOCK count length : %d available",(nlsStrLen(StkCnt)));fflush(stdout);
				//Convert the Stock to and check, If Stock is not in 2 digit then warning msg display.
				
				printf("\n POCHCK:F30:: STOCK count : [%d],STOCK string:[%s]",StkIndCnt,StkCnt);fflush(stdout);
				if(nlsStrLen(StkCnt) < 2 || StkIndCnt <=0 )
				{
					//printf("\nchild added in unique list StkCnt DML3: %d",nlsStrLen(StkCnt));fflush(stdout);
					printf("\n POCHCK:F30::Going for TRANSACTION COUNT check.");fflush(stdout);
					//GOING TO CHECK FOR TRANSACTION OF PartnmbrChkDup PART.
					printf("\n POCHCK:F30:: for Part number [%s]",sGrpChildPrt);fflush(stdout);
					TrnsIndCnt	=	0;
					TrnsIndCnt	=	DZ_Check_Transection_ERC(sGrpChildPrt,SAPPlant);
					printf("\n POCHCK:F30::TRANSACTION count....: %d",TrnsIndCnt);fflush(stdout);
					//If Transection is not found in SAP, we will check for PO for that Part.
					if(TrnsIndCnt <=0)
					{
						printf("\n POCHCK:F30::Going for PO check.");fflush(stdout);
						POCount=0;
						POCount=DZ_Check_RvlPOForFandF30_ERC(sGrpChildPrt,sPrtRevLDup,SAPPlant);
						printf("\n POCHCK:F30:: PO Count For Part:[%s] is:[%d]\n",sGrpChildPrt,POCount);
						//TZ 3.68
						if (POCount>0)
						{
							printf("\n POCHCK:F30:P1:...........PO Available with Revision:[%s] \n",sGrpChildPrt);fflush(stdout);
							return 4;
						}
						else
						{
							if (POCount==-1)
							{
								printf("\n POCHCK:F30:P2:...........PO Available Only:[%s] \n",sGrpChildPrt);fflush(stdout);
								return 5;
							}
							else
							{
								printf("\n POCHCK:F30:P3:...........Nooooo PO found:[%s] \n",sGrpChildPrt);fflush(stdout);
								return 0;
							}
						}
					}
					else
					{
						printf("\n POCHCK:F30:...........TRANSACTION COUNT is valid.\n");fflush(stdout);
						return 3;
						//break;
					}

				}
				else
				{
					printf("\n POCHCK:F30::.............STOCK COUNT is valid. \n");fflush(stdout);
					return 2;
					//break;
				}
			}
			else
			{
				printf("\n POCHCK:F30::..........BULK COUNT is valid. \n");fflush(stdout);
				return 1;
				//break;
			}
		}
	}


	CLEANUP:
		return 0;	
	EXIT:
		return 0;
}
;

int main(int argc, char *argv[])
{
	int stat=0;
	int ji=0;
	int jj=0;
	string	sPrtTypDup		= NULL;
	string	sPrtTyp			= NULL;
	string	sPrtCSDup		= NULL;
	string	sPrtCS			= NULL;
	string	sPrtRevDup		= NULL;
	string	sPrtRev			= NULL;
	string	sPrtColIndDup	= NULL;
	string	sPrtColInd		= NULL;
	string	sPrtDRDup		= NULL;
	string	sPrtDR			= NULL;
	string  sCarCSDup		= NULL;
	string  sCarCS			= NULL;
	string  sJsrCSDup		= NULL;
	string  sJsrCS			= NULL;
	string  sLkoCSDup		= NULL;
	string  sLkoCS			= NULL;
	string  sAhdCSDup		= NULL;
	string  sAhdCS			= NULL;
	string  sPnrCSDup		= NULL;
	string  sPnrCS			= NULL;
	string  sJdldCSDup		= NULL;
	string  sJdldCS			= NULL;
	string  sDwdCSDup		= NULL;
	string  sDwdCS			= NULL;
	string  sEEswoftTypDup	= NULL;
	string  sEEswoftTyp		= NULL;
	string  sPrtClassDup	= NULL;
	string  sEEprtTypeDup	= NULL;
	string  sEEprtType		= NULL;
	string  sPrtClass		= NULL;
	string  sPrtOwnDup		= NULL;
	string  sPrtOwn			= NULL;
	string	PartList		= NULL;
	string	fpname		= NULL;
	SqlPtr	Sql_ptr			= NULL;
	SetOfObjects	ARGateSetObj 		= NULL;
	SetOfObjects	soChildPartSet	= NULL;
	int prt=0;
	int	CSFoundF18	= 0;
	int	CSFoundFlag	= 0;
	int	EEPartByPass	= 0;
	int	pt =0;
	int	SkipStockFlg =0;
	int	POAvailFlg =0;
	FILE  *fp  =  NULL; 
	FILE  *fp1  =  NULL; 
	char fileRead[500];	
	//string			LoginS          =  "super user" ;
   // string			PasswordS       =  "abc123" ;
	string			LoginS          =  "Loader" ;
    string			PasswordS       =  "123loader" ;
	string			InpFile			= NULL;
	string			PartNo			= NULL;
	string			sPrtNumDup		= NULL;
	string			sPrtNum			= NULL;
	string			docobjst		= NULL;
	SqlPtr			sqlPrt			= NULL;
	string			lineReadDup		= NULL;
	string			lineRead		= NULL;
	string			lineRead1		= NULL;
	string	sPrtCS1			= NULL;
	string	sPrtCS1Dup		= NULL;
	string	sCarCS1Dup		= NULL;
	string	sCarCS1			= NULL;
	string	sJsrCS1			= NULL;
	string	sJsrCS1Dup		= NULL;
	string	sLkoCS1			= NULL;
	string	sLkoCS1Dup		= NULL;
	string	sAhdCS1			= NULL;
	string	sAhdCS1Dup		= NULL;
	string	sPnrCS1			= NULL;
	string	sPnrCS1Dup		= NULL;
	string	sDwdCS1Dup		= NULL;
	string	sDwdCS1			= NULL;
	string	sJdldCS1		= NULL;
	string	sJdldCS1Dup		= NULL;
	string	sPrtVlt			= NULL;
	string	sPrtVltDup		= NULL;
	string	sPrtCodeDup		= NULL;
	string	sPrtCode		= NULL;
	string	TsDescSDup		= NULL;
	string	TsDescS		= NULL;
	string	sPrtNmDup		= NULL;
	string	sPrtNm			= NULL;
	string	sClsNmeDup		= NULL;
	string	sClsNme			= NULL;
	string	sPrtNum1Dup			= NULL;
	string	sPrtNum1			= NULL;
	string	sPrtOrgDup			= NULL;
	string	sPrtOrg			= NULL;
	string	sTargetPlntGlb			= NULL;
	string	SAPPlant			= NULL;
	ObjectPtr		PrtObjP	= NULL;
	SetOfObjects    TaskSet			= NULL;
	SetOfStrings	dbScp			= NULL;
	SetOfStrings	SetOfPrtNum			= NULL;
	SetOfObjects	SetOfPrtNum1	= NULL;
	t5MethodInitWMD("POCHKValidation.c");
	//INPUT ARGU ITEM.........
  	LoginS		=nlsStrAlloc(20);
	PasswordS	=nlsStrAlloc(20);
	fpname		=nlsStrAlloc(100); 
	InpFile		=nlsStrAlloc(20);
	PartList		=nlsStrAlloc(20);
	sTargetPlntGlb		=nlsStrAlloc(20);
	PartList=argv[1];
	sTargetPlntGlb=argv[2];
	printf("\n Arg1:[%s]  sTargetPlntGlb:[%s]",PartList,sTargetPlntGlb);fflush(stdout);

	t5CheckDstat(clInitMB2(argc,&argv,NULL));	
	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());
	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));
	t5CheckDstat(clLogin2(LoginS,PasswordS,&stat));
	if (stat!=OKAY)
	{
		////printf("\n Invalid User Name or PasswordS : %s, %s \n", LoginS,PasswordS);
		goto EXIT;
	}
	//SET DATABASE
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (ji=0;ji<setSize(dbScp) ; ji++)
	{
		docobjst=low_set_get(dbScp,ji);
		printf("\nDB pref check beforeA... :%s\n",docobjst);fflush(stdout);
	}

	set_add_str_unique(dbScp, "supprod");
	set_add_str_unique(dbScp, "suhprod");
	set_add_str_unique(dbScp, "sulprod");
	set_add_str_unique(dbScp, "sujprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (jj=0;jj<low_set_size(dbScp) ; jj++)
	{
		docobjst=low_set_get(dbScp,jj);
		printf("\nDB pref check after... :%s\n",docobjst);fflush(stdout);
	}
	fp=fopen(PartList,"r");
	if(fp==NULL)
	{
		printf("unable  open  File.\n ");fflush(stdout);
		goto  CLEANUP;
	}
	if(nlsIsStrNull(sTargetPlntGlb))
	{
		printf("please give target plant.\n ");fflush(stdout);
		goto  CLEANUP;
	}
	
	//file creation start
	nlsStrCpy(fpname,"PartPODetailERC.csv");
	fp1 = fopen(fpname,"w");
	if(fp1)
	{
		printf("AAAAAAA  open  File.\n ");fflush(stdout);
	}
	else
	{
		printf("BBBBBB not  open  File.\n ");fflush(stdout);
	}
	if(fp1) fprintf(fp1,"Parent Parts, Child Parts,Revision,Part type,DR-status,Desc,Colour Indi,Owner, Project, Class, PUNE CS, CAR CS,JSR CS,LKO CS,AHD CS,PNR CS,DHWD CS,JDL CS");
	if(fp1) fprintf(fp1,"\n");
	while(fgets(fileRead,500,fp)!=NULL)
	{  		
		if(!nlsIsStrNull(fileRead))
		{
			if(PartNo)	PartNo	=NULL;
			//if(Rev)	Rev	=NULL;
			//if(Seq)	Seq	=NULL;
			lineReadDup = nlsStrAlloc(500);
			nlsStrCpy(lineReadDup,fileRead);
			lineRead1 =low_strssra(lineReadDup,",,",", ,");		
			lineRead  =low_strssra(lineRead1,",,",", ,");
			PartNo =strtok(lineRead,",");
			//Rev   =strtok(NULL,",");
			//Seq   =strtok(NULL,",");
			if(PartNo)nlsStrTrimTrailWhiteSpace(PartNo);

			printf("\n########################## Part number..:: %s\n",PartNo);fflush(stdout);
			//printf("Rev number...:: %s\n",Rev);fflush(stdout);
			//printf("Seq number...:: %s\n",Seq);fflush(stdout);
		}					
		//Query the Part
		t5CheckDstat(oiSqlCreateSelect(&sqlPrt)) ;
		t5CheckDstat(oiSqlWhereEQ(sqlPrt, PartNumberAttr,PartNo));
		t5CheckDstat(oiSqlWhereAND(sqlPrt));
		t5CheckDstat(oiSqlWhereLike(sqlPrt,SupersededAttr,"-"));
		t5CheckDstat(QueryDbObject(PartClass,sqlPrt,-1,TRUE,SC_SCOPE_OF_SESSION,&TaskSet,mfail))
		printf("\n..PART count: %d",setSize(TaskSet));fflush(stdout);

		if(setSize(TaskSet)>0)
		{
			SetOfPrtNum1	= setCreate(1);
			SetOfPrtNum	= setCreate(1);
			soChildPartSet	= setCreate(1);
			PrtObjP=setGet(TaskSet,0);
			if(dstat = objGetAttribute(PrtObjP,PartNumberAttr,&sPrtNum1)) goto EXIT;
			if(sPrtNum1)   sPrtNum1Dup = nlsStrDup(sPrtNum1);
			printf("Part number added to set111: %s\n",sPrtNum1Dup);fflush(stdout);

			//To bypass EE sowftware info2
			if (dstat = oiSqlCreateSelect(&Sql_ptr)) goto EXIT;
			if(dstat = oiSqlWhereEQ(Sql_ptr,t5SyscdAttr,"ARSTUS")) goto EXIT;
			if(dstat = QueryDbObject(t5CntrolClass,Sql_ptr,0,TRUE,SC_SCOPE_OF_SESSION,&ARGateSetObj,mfail)) goto EXIT;
			printf("\n POCHCK: No of  ARSTUS object found: [%d] \n",low_set_size(ARGateSetObj));fflush(stdout);
			if (setSize(ARGateSetObj)>0)
			{
				if(dstat=objGetAttribute(setGet(ARGateSetObj,0),"t5Userinfo2",&sEEswoftTyp)) goto CLEANUP;
				if(!nlsIsStrNull(sEEswoftTyp))		sEEswoftTypDup = nlsStrDup(sEEswoftTyp);
				printf("\n POCHCK: EE part software Type [%s] \n",sEEswoftTypDup);fflush(stdout);
			}
			//Part detals:
			if(sPrtNumDup)		sPrtNumDup		=NULL;
			if(sPrtNum)			sPrtNum			=NULL;
			if(sPrtTypDup)		sPrtTypDup		=NULL;
			if(sPrtTyp)			sPrtTyp			=NULL;
			if(sPrtRevDup)		sPrtRevDup		=NULL;
			if(sPrtRev)			sPrtRev			=NULL;
			if(sPrtCSDup)		sPrtCSDup		=NULL;
			if(sPrtCS)			sPrtCS			=NULL;
			if(sPrtDRDup)		sPrtDRDup		=NULL;
			if(sPrtDR)			sPrtDR			=NULL;
			if(sPrtColIndDup)	sPrtColIndDup	=NULL;
			if(sPrtColInd)		sPrtColInd		=NULL;
			if(sPrtClassDup)	sPrtClassDup	=NULL;
			if(sPrtClass)		sPrtClass		=NULL;
			if(sEEprtTypeDup)	sEEprtTypeDup	=NULL;
			if(sEEprtType)		sEEprtType		=NULL;
			if(sPrtOwnDup)		sPrtOwnDup		=NULL;
			if(sPrtOwn)			sPrtOwn			=NULL;
			if(sPrtOrgDup)		sPrtOrgDup			=NULL;
			if(sPrtOrg)			sPrtOrg			=NULL;

			if (dstat = objGetAttribute(PrtObjP,PartNumberAttr,&sPrtNum)) goto EXIT;
			if(!nlsIsStrNull(sPrtNum)) sPrtNumDup = nlsStrDup(sPrtNum);
			if (dstat = objGetAttribute(PrtObjP,RevisionAttr,&sPrtRev)) goto EXIT;
			if(!nlsIsStrNull(sPrtRev)) sPrtRevDup = nlsStrDup(sPrtRev);
			if (dstat = objGetAttribute(PrtObjP,PartTypeAttr,&sPrtTyp)) goto EXIT;
			if(!nlsIsStrNull(sPrtTyp)) sPrtTypDup = nlsStrDup(sPrtTyp);
			if (dstat = objGetAttribute(PrtObjP,t5PartStatusAttr,&sPrtDR)) goto EXIT;
			if(!nlsIsStrNull(sPrtDR)) sPrtDRDup = nlsStrDup(sPrtDR);
			if (dstat = objGetAttribute(PrtObjP,t5ColourIndAttr,&sPrtColInd)) goto EXIT;
			if(!nlsIsStrNull(sPrtColInd)) sPrtColIndDup = nlsStrDup(sPrtColInd);
			if (dstat = objGetAttribute(PrtObjP,OwnerNameAttr,&sPrtOwn)) goto EXIT;
			if(!nlsIsStrNull(sPrtOwn)) sPrtOwnDup = nlsStrDup(sPrtOwn);
			if (dstat = objGetAttribute(PrtObjP,OrganizationIDAttr,&sPrtOrg)) goto EXIT;
			if(!nlsIsStrNull(sPrtOrg)) sPrtOrgDup = nlsStrDup(sPrtOrg);
			printf("\n POCHCK::Part no :[%s] Rev:[%s] Type:[%s] DR:[%s] Col Indi:[%s] Org:[%s].",sPrtNumDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,sPrtColIndDup,sPrtOrgDup);fflush(stdout);
			//EE part skip...
			if(dstat = objGetClass(PrtObjP,&sPrtClass)) goto EXIT;
			if(!nlsIsStrNull(sPrtClass)) sPrtClassDup = nlsStrDup(sPrtClass);
			EEPartByPass=0;
			if(nlsStrCmp(sPrtClassDup,"t5EeAsm")==0)
			{
				if (dstat = objGetAttribute(PrtObjP,t5EESwPartTypeAttr,&sEEprtType)) goto EXIT;
				if(!nlsIsStrNull(sEEprtType)) sEEprtTypeDup = nlsStrDup(sEEprtType);
				printf("\n POCHCK: EE PART TYPE:[%s]",sEEprtTypeDup);fflush(stdout);
				if(nlsStrStr(sEEswoftTypDup,sEEprtTypeDup)!=NULL)
				{
					printf("\n POCHCK: Bypassing EE part for PO.");fflush(stdout);
					EEPartByPass=1;
					//BYPASS
				}
			}
			if (nlsStrCmp(sPrtClassDup,"t5SpKit")==0)
			{
				printf("\n POCHCK: Bypassing Spare kit part for PO.");fflush(stdout);
				EEPartByPass=1;
				//BYPASS
			}
			if(!nlsIsStrNull(sPrtOrgDup))
			{
				//if (nlsStrCmp(sPrtOrgDup,"ERC")!=0)
				if(nlsStrStr(sPrtOrgDup,"ERC")==NULL)
				{
					printf("\n POCHCK: Bypassing other ORG part part for PO.");fflush(stdout);
					//EEPartByPass=1;
					//BYPASS
				}
			}
			printf("\n POCHCK: EEPartByPass:%d \n",EEPartByPass);fflush(stdout);

			if (EEPartByPass==0)
			{
				if(sCarCSDup)	sCarCSDup	=NULL;
				if(sCarCS)		sCarCS		=NULL;
				if(sJsrCS)		sJsrCS		=NULL;
				if(sJsrCSDup)	sJsrCSDup	=NULL;
				if(sLkoCS)		sLkoCS		=NULL;
				if(sLkoCSDup)	sLkoCSDup	=NULL;
				if(sAhdCS)		sAhdCS		=NULL;
				if(sAhdCSDup)	sAhdCSDup	=NULL;
				if(sPnrCS)		sPnrCS		=NULL;
				if(sPnrCSDup)	sPnrCSDup	=NULL;
				if(sDwdCSDup)	sDwdCSDup	=NULL;
				if(sDwdCS)		sDwdCS		=NULL;
				if(sJdldCS)		sJdldCS		=NULL;
				if(sJdldCSDup)	sJdldCSDup	=NULL;
				CSFoundFlag=0;
				CSFoundF18=0;
				//PUNE CS 1001
				if (dstat = objGetAttribute(PrtObjP,t5PunMakeBuyIndicatorAttr,&sPrtCS)) goto EXIT;
				if(!nlsIsStrNull(sPrtCS)) sPrtCSDup = nlsStrDup(sPrtCS);
				if (dstat = objGetAttribute(PrtObjP,t5CarMakeBuyIndicatorAttr,&sCarCS)) goto EXIT;
				if(!nlsIsStrNull(sCarCS)) sCarCSDup = nlsStrDup(sCarCS);
				if (dstat = objGetAttribute(PrtObjP,t5JsrMakeBuyIndicatorAttr,&sJsrCS)) goto EXIT;
				if(!nlsIsStrNull(sJsrCS)) sJsrCSDup = nlsStrDup(sJsrCS);
				if (dstat = objGetAttribute(PrtObjP,t5LkoMakeBuyIndicatorAttr,&sLkoCS)) goto EXIT;
				if(!nlsIsStrNull(sLkoCS)) sLkoCSDup = nlsStrDup(sLkoCS);
				if (dstat = objGetAttribute(PrtObjP,t5AhdMakeBuyIndicatorAttr,&sAhdCS)) goto EXIT;
				if(!nlsIsStrNull(sAhdCS)) sAhdCSDup = nlsStrDup(sAhdCS);
				if (dstat = objGetAttribute(PrtObjP,t5PnrMakeBuyIndicatorAttr,&sPnrCS)) goto EXIT;
				if(!nlsIsStrNull(sPnrCS)) sPnrCSDup = nlsStrDup(sPnrCS);
				if (dstat = objGetAttribute(PrtObjP,t5DwdMakeBuyIndicatorAttr,&sDwdCS)) goto EXIT;
				if(!nlsIsStrNull(sDwdCS)) sDwdCSDup = nlsStrDup(sDwdCS);
				if (dstat = objGetAttribute(PrtObjP,t5JdlMakeBuyIndicatorAttr,&sJdldCS)) goto EXIT;
				if(!nlsIsStrNull(sJdldCS)) sJdldCSDup = nlsStrDup(sJdldCS);
				printf("\n POCHCK::PUNE CS:[%s] CAR:[%s] JSR:[%s] LKO:[%s] AHD:[%s] PNR:[%s] DHWD:[%s] JDL:[%s] \n",sPrtCSDup,sCarCSDup,sJsrCSDup,sLkoCSDup,sAhdCSDup,sPnrCSDup,sDwdCSDup,sJdldCSDup);fflush(stdout);
				if(!nlsIsStrNull(sPrtNumDup))
				{
					printf("\n POCHCK:::");fflush(stdout);
					if(nlsStrCmp(sPrtCSDup,"F")==0 || nlsStrCmp(sPrtCSDup,"F30")==0)
					{
						//PUNE 1001
						printf(" PUNE: F or F30.");fflush(stdout);
						CSFoundFlag=1;
					}
					else if(nlsStrCmp(sCarCSDup,"F")==0 || nlsStrCmp(sCarCSDup,"F30")==0)
					{
						//CAR CS 1100
						printf(" CAR: F or F30.");fflush(stdout);
						CSFoundFlag=1;
					}
					else if(nlsStrCmp(sJsrCSDup,"F")==0 || nlsStrCmp(sJsrCSDup,"F30")==0)
					{
						//JSR CS 2001
						printf(" JSR: F or F30.");fflush(stdout);
						CSFoundFlag=1;
					}
					else if(nlsStrCmp(sLkoCSDup,"F")==0 || nlsStrCmp(sLkoCSDup,"F30")==0)
					{
						//LKO CS 3001
						printf(" LKO: F or F30.");fflush(stdout);
						CSFoundFlag=1;
					}
					else if(nlsStrCmp(sAhdCSDup,"F")==0 || nlsStrCmp(sAhdCSDup,"F30")==0)
					{
						//AHD CS 7501
						printf(" AHD: F or F30.");fflush(stdout);
						CSFoundFlag=1;
					}
					else if(nlsStrCmp(sPnrCSDup,"F")==0 || nlsStrCmp(sPnrCSDup,"F30")==0)
					{
						//PNR CS 3100
						printf(" PNR: F or F30.");fflush(stdout);
						CSFoundFlag=1;
					}
					else if(nlsStrCmp(sDwdCSDup,"F")==0 || nlsStrCmp(sDwdCSDup,"F30")==0)
					{
						//DHWD CS 1500
						printf(" DHWD: F or F30.");fflush(stdout);
						CSFoundFlag=1;
					}
					else
					{
						if(nlsStrCmp(sJdldCSDup,"F")==0 || nlsStrCmp(sJdldCSDup,"F30")==0)
						{
							//JDL
							printf(" JDL: F or F30.");fflush(stdout);
							CSFoundFlag=1;
						}
					}
				}
				printf("\n POCHCK: Inside flag for Part Number : %s :CSFoundFlag:%d",sPrtNumDup,CSFoundFlag);fflush(stdout);
				printf("\n PO04:Valid Tagret Plant is:[%s]",sTargetPlntGlb);fflush(stdout);
				if(!nlsIsStrNull(sTargetPlntGlb))
				{
					if(nlsStrCmp(sTargetPlntGlb,"PV")==0)
					{
						if(dstat = t5GetSapPlantAtERC("AHD", &SAPPlant, mfail)) goto EXIT;
						printf("\n PO0555:Valid SAPPlant is:[%s]",SAPPlant);fflush(stdout);
					}
					else
					{
						if(dstat = t5GetSapPlantAtERC("PCVBU", &SAPPlant, mfail)) goto EXIT;
						printf("\n PO04444:Valid SAPPlant is:[%s]",SAPPlant);fflush(stdout);
					}
				}
				else
				{
					if(dstat = t5GetSapPlantAtERC("PCVBU", &SAPPlant, mfail)) goto EXIT;
					printf("\n PO04:Valid SAPPlant is:[%s]",SAPPlant);fflush(stdout);
				}

				POAvailFlg=0;
				POAvailFlg= t5CheckPOForPartt(PrtObjP,SAPPlant,SkipStockFlg,mfail);
				if(POAvailFlg >0)
				{
					printf("\n  POCHCK: Part:[%s], Having PO available.\n",sPrtNumDup);fflush(stdout);
					if(sPrtNmDup)		sPrtNmDup		=NULL;
					if(sPrtNm)			sPrtNm			=NULL;
					if(sPrtTypDup)		sPrtTypDup		=NULL;
					if(sPrtTyp)			sPrtTyp			=NULL;
					if(sPrtRevDup)		sPrtRevDup		=NULL;
					if(sPrtRev)			sPrtRev			=NULL;
					if(sPrtCSDup)		sPrtCSDup		=NULL;
					if(sPrtCS)			sPrtCS			=NULL;
					if(sPrtDRDup)		sPrtDRDup		=NULL;
					if(sPrtDR)			sPrtDR			=NULL;
					if(sPrtColIndDup)	sPrtColIndDup	=NULL;
					if(sPrtColInd)		sPrtColInd		=NULL;
					if(sPrtCodeDup)		sPrtCodeDup		=NULL;
					if(sPrtCode)		sPrtCode		=NULL;
					if(sPrtVltDup)		sPrtVltDup		=NULL;
					if(sPrtVlt)			sPrtVlt			=NULL;
					if(sClsNmeDup)		sClsNmeDup		=NULL;
					if(sClsNme)			sClsNme			=NULL;
					if(sPrtCS1)		sPrtCS1		=NULL;
					if(sCarCS1)		sCarCS1		=NULL;
					if(sJsrCS1)		sJsrCS1		=NULL;
					if(sLkoCS1)		sLkoCS1		=NULL;
					if(sAhdCS1)		sAhdCS1		=NULL;
					if(sPnrCS1)		sPnrCS1		=NULL;
					if(sDwdCS1)		sDwdCS1		=NULL;
					if(sJdldCS1)	sJdldCS1	=NULL;
					if(sPrtCS1Dup)	sPrtCS1Dup	=NULL;
					if(sCarCS1Dup)	sCarCS1Dup	=NULL;
					if(sJsrCS1Dup)	sJsrCS1Dup	=NULL;
					if(sLkoCS1Dup)	sLkoCS1Dup	=NULL;
					if(sAhdCS1Dup)	sAhdCS1Dup	=NULL;
					if(sPnrCS1Dup)	sPnrCS1Dup	=NULL;
					if(sDwdCS1Dup)	sDwdCS1Dup	=NULL;
					if(sJdldCS1Dup)	sJdldCS1Dup	=NULL;
					if (dstat = objGetAttribute(PrtObjP,PartNumberAttr,&sPrtNm)) goto EXIT;
					if(!nlsIsStrNull(sPrtNm)) sPrtNmDup = nlsStrDup(sPrtNm);
					if (dstat = objGetAttribute(PrtObjP,NomenclatureAttr,&TsDescS)) goto EXIT;
					if(!nlsIsStrNull(TsDescS)) TsDescSDup = nlsStrDup(TsDescS); else TsDescSDup = nlsStrDup("NA");
					TsDescSDup=strssra(TsDescSDup, ",", ";");//replace all ',' in description by ';'
					TsDescSDup=strssra(TsDescSDup, "\n", "; ");//replace all ',' in description by ';'
					printf("\n Document Description : %s\n",TsDescSDup);fflush(stdout);
					if (dstat = objGetAttribute(PrtObjP,RevisionAttr,&sPrtRev)) goto EXIT;
					if(!nlsIsStrNull(sPrtRev)) sPrtRevDup = nlsStrDup(sPrtRev);
					if (dstat = objGetAttribute(PrtObjP,PartTypeAttr,&sPrtTyp)) goto EXIT;
					if(!nlsIsStrNull(sPrtTyp)) sPrtTypDup = nlsStrDup(sPrtTyp);
					if (dstat = objGetAttribute(PrtObjP,t5PartStatusAttr,&sPrtDR)) goto EXIT;
					if(!nlsIsStrNull(sPrtDR)) sPrtDRDup = nlsStrDup(sPrtDR);
					if (dstat = objGetAttribute(PrtObjP,t5ColourIndAttr,&sPrtColInd)) goto EXIT;
					if(!nlsIsStrNull(sPrtColInd)) sPrtColIndDup = nlsStrDup(sPrtColInd);
					if (dstat = objGetAttribute(PrtObjP,OwnerNameAttr,&sPrtVlt)) goto EXIT;
					if(!nlsIsStrNull(sPrtVlt)) sPrtVltDup = nlsStrDup(sPrtVlt);
					if (dstat = objGetAttribute(PrtObjP,ProjectNameAttr,&sPrtCode)) goto EXIT;
					if(!nlsIsStrNull(sPrtCode)) sPrtCodeDup = nlsStrDup(sPrtCode);
					if (dstat = objGetAttribute(PrtObjP,ClassAttr,&sClsNmeDup)) goto CLEANUP;
					if(!nlsIsStrNull(sClsNmeDup)) sClsNme = nlsStrDup(sClsNmeDup);
					if (dstat = objGetAttribute(PrtObjP,t5PunMakeBuyIndicatorAttr,&sPrtCS1)) goto EXIT;
					if(!nlsIsStrNull(sPrtCS1)) sPrtCS1Dup = nlsStrDup(sPrtCS1);
					if (dstat = objGetAttribute(PrtObjP,t5CarMakeBuyIndicatorAttr,&sCarCS1)) goto EXIT;
					if(!nlsIsStrNull(sCarCS1)) sCarCS1Dup = nlsStrDup(sCarCS1);
					if (dstat = objGetAttribute(PrtObjP,t5JsrMakeBuyIndicatorAttr,&sJsrCS1)) goto EXIT;
					if(!nlsIsStrNull(sJsrCS1)) sJsrCS1Dup = nlsStrDup(sJsrCS1);
					if (dstat = objGetAttribute(PrtObjP,t5LkoMakeBuyIndicatorAttr,&sLkoCS1)) goto EXIT;
					if(!nlsIsStrNull(sLkoCS1)) sLkoCS1Dup = nlsStrDup(sLkoCS1);
					if (dstat = objGetAttribute(PrtObjP,t5AhdMakeBuyIndicatorAttr,&sAhdCS1)) goto EXIT;
					if(!nlsIsStrNull(sAhdCS1)) sAhdCS1Dup = nlsStrDup(sAhdCS1);
					if (dstat = objGetAttribute(PrtObjP,t5PnrMakeBuyIndicatorAttr,&sPnrCS1)) goto EXIT;
					if(!nlsIsStrNull(sPnrCS1)) sPnrCS1Dup = nlsStrDup(sPnrCS1);
					if (dstat = objGetAttribute(PrtObjP,t5DwdMakeBuyIndicatorAttr,&sDwdCS1)) goto EXIT;
					if(!nlsIsStrNull(sDwdCS1)) sDwdCS1Dup = nlsStrDup(sDwdCS1);
					if (dstat = objGetAttribute(PrtObjP,t5JdlMakeBuyIndicatorAttr,&sJdldCS1)) goto EXIT;
					if(!nlsIsStrNull(sJdldCS1)) sJdldCS1Dup = nlsStrDup(sJdldCS1);
					printf("\n POCHCK:Parttt: [%s] Rev: [%s] Type: [%s] DR: [%s] Desc: [%s] Col: [%s] Vault: [%s] proj: [%s] Class: [%s]",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme);fflush(stdout);
					printf("\n POCHCK:Punett: [%s] CAR: [%s] JSR: [%s] LKO: [%s] AHD: [%s] PNR: [%s] DHWD: [%s] JDL: [%s]",sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(stdout);
					printf("\n\n	PO AVAILABLE FOR PART-----:%s\n ",sPrtNmDup);fflush(stdout);
					if (CSFoundFlag >1)
					{
						if(POAvailFlg ==1)
						{
							//BULK
							fprintf(fp1,"'%s,BULK AVAILABLE,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
						}
						else if (POAvailFlg ==2)
						{
							//STOCK
							fprintf(fp1,"'%s,STOCK AVAILABLE,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
						}
						else if (POAvailFlg ==3)
						{
							//TRANSC
							fprintf(fp1,"'%s,TRANSECTION AVAILABLE,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
						}
						else if (POAvailFlg ==4)
						{
							//REV LVL
							fprintf(fp1,"'%s,REVISION LEVEL PO AVAILABLE,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
						}
						else if (POAvailFlg ==5)
						{
							//PO
							fprintf(fp1,"'%s,PO AVAILABLE,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
						}
					}
					else
					{
						printf("\n POCHCK:Other CS part %s..",sPrtNumDup);fflush(stdout);
						if(POAvailFlg ==1)
						{
							//BULK
							fprintf(fp1,"'%s,BULK AVAILABLE (Other CS),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
						}
						else if (POAvailFlg ==2)
						{
							//STOCK
							fprintf(fp1,"'%s,STOCK AVAILABLE (Other CS),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
						}
						else if (POAvailFlg ==3)
						{
							//TRANSC
							fprintf(fp1,"'%s,TRANSECTION AVAILABLE (Other CS),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
						}
						else if (POAvailFlg ==4)
						{
							//REV LVL
							fprintf(fp1,"'%s,REVISION LEVEL PO AVAILABLE (Other CS),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
						}
						else if (POAvailFlg ==5)
						{
							//PO
							fprintf(fp1,"'%s,PO AVAILABLE (Other CS),%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
						}

					}

				}
				else
				{
					printf("\n  POCHCK: Part:[%s], Having no Transaction and no PO so catch in PO ERROR\n",sPrtNumDup);fflush(stdout);
					if(sPrtNmDup)		sPrtNmDup		=NULL;
					if(sPrtNm)			sPrtNm			=NULL;
					if(sPrtTypDup)		sPrtTypDup		=NULL;
					if(sPrtTyp)			sPrtTyp			=NULL;
					if(sPrtRevDup)		sPrtRevDup		=NULL;
					if(sPrtRev)			sPrtRev			=NULL;
					if(sPrtCSDup)		sPrtCSDup		=NULL;
					if(sPrtCS)			sPrtCS			=NULL;
					if(sPrtDRDup)		sPrtDRDup		=NULL;
					if(sPrtDR)			sPrtDR			=NULL;
					if(sPrtColIndDup)	sPrtColIndDup	=NULL;
					if(sPrtColInd)		sPrtColInd		=NULL;
					if(sPrtCodeDup)		sPrtCodeDup		=NULL;
					if(sPrtCode)		sPrtCode		=NULL;
					if(sPrtVltDup)		sPrtVltDup		=NULL;
					if(sPrtVlt)			sPrtVlt			=NULL;
					if(sClsNmeDup)		sClsNmeDup		=NULL;
					if(sClsNme)			sClsNme			=NULL;
					if(sPrtCS1)		sPrtCS1		=NULL;
					if(sCarCS1)		sCarCS1		=NULL;
					if(sJsrCS1)		sJsrCS1		=NULL;
					if(sLkoCS1)		sLkoCS1		=NULL;
					if(sAhdCS1)		sAhdCS1		=NULL;
					if(sPnrCS1)		sPnrCS1		=NULL;
					if(sDwdCS1)		sDwdCS1		=NULL;
					if(sJdldCS1)	sJdldCS1	=NULL;
					if(sPrtCS1Dup)	sPrtCS1Dup	=NULL;
					if(sCarCS1Dup)	sCarCS1Dup	=NULL;
					if(sJsrCS1Dup)	sJsrCS1Dup	=NULL;
					if(sLkoCS1Dup)	sLkoCS1Dup	=NULL;
					if(sAhdCS1Dup)	sAhdCS1Dup	=NULL;
					if(sPnrCS1Dup)	sPnrCS1Dup	=NULL;
					if(sDwdCS1Dup)	sDwdCS1Dup	=NULL;
					if(sJdldCS1Dup)	sJdldCS1Dup	=NULL;

					if (dstat = objGetAttribute(PrtObjP,PartNumberAttr,&sPrtNm)) goto EXIT;
					if(!nlsIsStrNull(sPrtNm)) sPrtNmDup = nlsStrDup(sPrtNm);
					if (dstat = objGetAttribute(PrtObjP,NomenclatureAttr,&TsDescS)) goto EXIT;
					if(!nlsIsStrNull(TsDescS)) TsDescSDup = nlsStrDup(TsDescS); else TsDescSDup = nlsStrDup("NA");
					TsDescSDup=strssra(TsDescSDup, ",", ";");//replace all ',' in description by ';'
					TsDescSDup=strssra(TsDescSDup, "\n", "; ");//replace all ',' in description by ';'
					printf("\n Document Description : %s\n",TsDescSDup);fflush(stdout);
					if (dstat = objGetAttribute(PrtObjP,RevisionAttr,&sPrtRev)) goto EXIT;
					if(!nlsIsStrNull(sPrtRev)) sPrtRevDup = nlsStrDup(sPrtRev);
					if (dstat = objGetAttribute(PrtObjP,PartTypeAttr,&sPrtTyp)) goto EXIT;
					if(!nlsIsStrNull(sPrtTyp)) sPrtTypDup = nlsStrDup(sPrtTyp);
					if (dstat = objGetAttribute(PrtObjP,t5PartStatusAttr,&sPrtDR)) goto EXIT;
					if(!nlsIsStrNull(sPrtDR)) sPrtDRDup = nlsStrDup(sPrtDR);
					if (dstat = objGetAttribute(PrtObjP,t5ColourIndAttr,&sPrtColInd)) goto EXIT;
					if(!nlsIsStrNull(sPrtColInd)) sPrtColIndDup = nlsStrDup(sPrtColInd);
					if (dstat = objGetAttribute(PrtObjP,OwnerNameAttr,&sPrtVlt)) goto EXIT;
					if(!nlsIsStrNull(sPrtVlt)) sPrtVltDup = nlsStrDup(sPrtVlt);
					if (dstat = objGetAttribute(PrtObjP,ProjectNameAttr,&sPrtCode)) goto EXIT;
					if(!nlsIsStrNull(sPrtCode)) sPrtCodeDup = nlsStrDup(sPrtCode);
					if (dstat = objGetAttribute(PrtObjP,ClassAttr,&sClsNmeDup)) goto CLEANUP;
					if(!nlsIsStrNull(sClsNmeDup)) sClsNme = nlsStrDup(sClsNmeDup);
					if (dstat = objGetAttribute(PrtObjP,t5PunMakeBuyIndicatorAttr,&sPrtCS1)) goto EXIT;
					if(!nlsIsStrNull(sPrtCS1)) sPrtCS1Dup = nlsStrDup(sPrtCS1);
					if (dstat = objGetAttribute(PrtObjP,t5CarMakeBuyIndicatorAttr,&sCarCS1)) goto EXIT;
					if(!nlsIsStrNull(sCarCS1)) sCarCS1Dup = nlsStrDup(sCarCS1);
					if (dstat = objGetAttribute(PrtObjP,t5JsrMakeBuyIndicatorAttr,&sJsrCS1)) goto EXIT;
					if(!nlsIsStrNull(sJsrCS1)) sJsrCS1Dup = nlsStrDup(sJsrCS1);
					if (dstat = objGetAttribute(PrtObjP,t5LkoMakeBuyIndicatorAttr,&sLkoCS1)) goto EXIT;
					if(!nlsIsStrNull(sLkoCS1)) sLkoCS1Dup = nlsStrDup(sLkoCS1);
					if (dstat = objGetAttribute(PrtObjP,t5AhdMakeBuyIndicatorAttr,&sAhdCS1)) goto EXIT;
					if(!nlsIsStrNull(sAhdCS1)) sAhdCS1Dup = nlsStrDup(sAhdCS1);
					if (dstat = objGetAttribute(PrtObjP,t5PnrMakeBuyIndicatorAttr,&sPnrCS1)) goto EXIT;
					if(!nlsIsStrNull(sPnrCS1)) sPnrCS1Dup = nlsStrDup(sPnrCS1);
					if (dstat = objGetAttribute(PrtObjP,t5DwdMakeBuyIndicatorAttr,&sDwdCS1)) goto EXIT;
					if(!nlsIsStrNull(sDwdCS1)) sDwdCS1Dup = nlsStrDup(sDwdCS1);
					if (dstat = objGetAttribute(PrtObjP,t5JdlMakeBuyIndicatorAttr,&sJdldCS1)) goto EXIT;
					if(!nlsIsStrNull(sJdldCS1)) sJdldCS1Dup = nlsStrDup(sJdldCS1);
					printf("\n POCHCK:Part: [%s] Rev: [%s] Type: [%s] DR: [%s] Desc: [%s] Col: [%s] Vault: [%s] proj: [%s] Class: [%s]",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme);fflush(stdout);
					printf("\n POCHCK:Pune: [%s] CAR: [%s] JSR: [%s] LKO: [%s] AHD: [%s] PNR: [%s] DHWD: [%s] JDL: [%s]",sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(stdout);
					printf("\n\n	NO PO FOR PART-----:%s\n ",sPrtNmDup);fflush(stdout);
					fprintf(fp1,"'%s,NO PO FOUND,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
				}
			}
			if (EEPartByPass >0)
			{
				printf("\n  POCHCK: Part:[%s], Bypasseddd\n",sPrtNumDup);fflush(stdout);
				if(sPrtNmDup)		sPrtNmDup		=NULL;
				if(sPrtNm)			sPrtNm			=NULL;
				if(sPrtTypDup)		sPrtTypDup		=NULL;
				if(sPrtTyp)			sPrtTyp			=NULL;
				if(sPrtRevDup)		sPrtRevDup		=NULL;
				if(sPrtRev)			sPrtRev			=NULL;
				if(sPrtCSDup)		sPrtCSDup		=NULL;
				if(sPrtCS)			sPrtCS			=NULL;
				if(sPrtDRDup)		sPrtDRDup		=NULL;
				if(sPrtDR)			sPrtDR			=NULL;
				if(sPrtColIndDup)	sPrtColIndDup	=NULL;
				if(sPrtColInd)		sPrtColInd		=NULL;
				if(sPrtCodeDup)		sPrtCodeDup		=NULL;
				if(sPrtCode)		sPrtCode		=NULL;
				if(sPrtVltDup)		sPrtVltDup		=NULL;
				if(sPrtVlt)			sPrtVlt			=NULL;
				if(sClsNmeDup)		sClsNmeDup		=NULL;
				if(sClsNme)			sClsNme			=NULL;
				if(sPrtCS1)		sPrtCS1		=NULL;
				if(sCarCS1)		sCarCS1		=NULL;
				if(sJsrCS1)		sJsrCS1		=NULL;
				if(sLkoCS1)		sLkoCS1		=NULL;
				if(sAhdCS1)		sAhdCS1		=NULL;
				if(sPnrCS1)		sPnrCS1		=NULL;
				if(sDwdCS1)		sDwdCS1		=NULL;
				if(sJdldCS1)	sJdldCS1	=NULL;
				if(sPrtCS1Dup)	sPrtCS1Dup	=NULL;
				if(sCarCS1Dup)	sCarCS1Dup	=NULL;
				if(sJsrCS1Dup)	sJsrCS1Dup	=NULL;
				if(sLkoCS1Dup)	sLkoCS1Dup	=NULL;
				if(sAhdCS1Dup)	sAhdCS1Dup	=NULL;
				if(sPnrCS1Dup)	sPnrCS1Dup	=NULL;
				if(sDwdCS1Dup)	sDwdCS1Dup	=NULL;
				if(sJdldCS1Dup)	sJdldCS1Dup	=NULL;

				if (dstat = objGetAttribute(PrtObjP,PartNumberAttr,&sPrtNm)) goto EXIT;
				if(!nlsIsStrNull(sPrtNm)) sPrtNmDup = nlsStrDup(sPrtNm);
				if (dstat = objGetAttribute(PrtObjP,NomenclatureAttr,&TsDescS)) goto EXIT;
				if(!nlsIsStrNull(TsDescS)) TsDescSDup = nlsStrDup(TsDescS); else TsDescSDup = nlsStrDup("NA");
				TsDescSDup=strssra(TsDescSDup, ",", ";");//replace all ',' in description by ';'
				TsDescSDup=strssra(TsDescSDup, "\n", "; ");//replace all ',' in description by ';'
				printf("\n Document Description : %s\n",TsDescSDup);fflush(stdout);
				if (dstat = objGetAttribute(PrtObjP,RevisionAttr,&sPrtRev)) goto EXIT;
				if(!nlsIsStrNull(sPrtRev)) sPrtRevDup = nlsStrDup(sPrtRev);
				if (dstat = objGetAttribute(PrtObjP,PartTypeAttr,&sPrtTyp)) goto EXIT;
				if(!nlsIsStrNull(sPrtTyp)) sPrtTypDup = nlsStrDup(sPrtTyp);
				if (dstat = objGetAttribute(PrtObjP,t5PartStatusAttr,&sPrtDR)) goto EXIT;
				if(!nlsIsStrNull(sPrtDR)) sPrtDRDup = nlsStrDup(sPrtDR);
				if (dstat = objGetAttribute(PrtObjP,t5ColourIndAttr,&sPrtColInd)) goto EXIT;
				if(!nlsIsStrNull(sPrtColInd)) sPrtColIndDup = nlsStrDup(sPrtColInd);
				if (dstat = objGetAttribute(PrtObjP,OwnerNameAttr,&sPrtVlt)) goto EXIT;
				if(!nlsIsStrNull(sPrtVlt)) sPrtVltDup = nlsStrDup(sPrtVlt);
				if (dstat = objGetAttribute(PrtObjP,ProjectNameAttr,&sPrtCode)) goto EXIT;
				if(!nlsIsStrNull(sPrtCode)) sPrtCodeDup = nlsStrDup(sPrtCode);
				if (dstat = objGetAttribute(PrtObjP,ClassAttr,&sClsNmeDup)) goto CLEANUP;
				if(!nlsIsStrNull(sClsNmeDup)) sClsNme = nlsStrDup(sClsNmeDup);
				if (dstat = objGetAttribute(PrtObjP,t5PunMakeBuyIndicatorAttr,&sPrtCS1)) goto EXIT;
				if(!nlsIsStrNull(sPrtCS1)) sPrtCS1Dup = nlsStrDup(sPrtCS1);
				if (dstat = objGetAttribute(PrtObjP,t5CarMakeBuyIndicatorAttr,&sCarCS1)) goto EXIT;
				if(!nlsIsStrNull(sCarCS1)) sCarCS1Dup = nlsStrDup(sCarCS1);
				if (dstat = objGetAttribute(PrtObjP,t5JsrMakeBuyIndicatorAttr,&sJsrCS1)) goto EXIT;
				if(!nlsIsStrNull(sJsrCS1)) sJsrCS1Dup = nlsStrDup(sJsrCS1);
				if (dstat = objGetAttribute(PrtObjP,t5LkoMakeBuyIndicatorAttr,&sLkoCS1)) goto EXIT;
				if(!nlsIsStrNull(sLkoCS1)) sLkoCS1Dup = nlsStrDup(sLkoCS1);
				if (dstat = objGetAttribute(PrtObjP,t5AhdMakeBuyIndicatorAttr,&sAhdCS1)) goto EXIT;
				if(!nlsIsStrNull(sAhdCS1)) sAhdCS1Dup = nlsStrDup(sAhdCS1);
				if (dstat = objGetAttribute(PrtObjP,t5PnrMakeBuyIndicatorAttr,&sPnrCS1)) goto EXIT;
				if(!nlsIsStrNull(sPnrCS1)) sPnrCS1Dup = nlsStrDup(sPnrCS1);
				if (dstat = objGetAttribute(PrtObjP,t5DwdMakeBuyIndicatorAttr,&sDwdCS1)) goto EXIT;
				if(!nlsIsStrNull(sDwdCS1)) sDwdCS1Dup = nlsStrDup(sDwdCS1);
				if (dstat = objGetAttribute(PrtObjP,t5JdlMakeBuyIndicatorAttr,&sJdldCS1)) goto EXIT;
				if(!nlsIsStrNull(sJdldCS1)) sJdldCS1Dup = nlsStrDup(sJdldCS1);
				printf("\n POCHCK:Part: [%s] Rev: [%s] Type: [%s] DR: [%s] Desc: [%s] Col: [%s] Vault: [%s] proj: [%s] Class: [%s]",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme);fflush(stdout);
				printf("\n POCHCK:Pune: [%s] CAR: [%s] JSR: [%s] LKO: [%s] AHD: [%s] PNR: [%s] DHWD: [%s] JDL: [%s]",sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(stdout);
				printf("\n\n	Part BYPASSED..-----:%s\n ",sPrtNmDup);fflush(stdout);
				fprintf(fp1,"'%s,Part BYPASSED,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,\n",sPrtNmDup,sPrtRevDup,sPrtTypDup,sPrtDRDup,TsDescSDup,sPrtColIndDup,sPrtVltDup,sPrtCodeDup,sClsNme,sPrtCS1Dup,sCarCS1Dup,sJsrCS1Dup,sLkoCS1Dup,sAhdCS1Dup,sPnrCS1Dup,sDwdCS1Dup,sJdldCS1Dup);fflush(fp1);
			}
		}
		else
		{
			fprintf(fp1,"'%s,NO PART IN PLMDB,\n",PartNo);fflush(fp1);

		}
	}

	printf("\n		~~~~~~~~  L I V E   L O N G   &   P R O S P E R    ~~~~~~~~~~~~~~ \n\n ");fflush(stdout);

CLEANUP :

EXIT:
        if (dstat != OKAY) dlow_return_trace(mod_name, dstat);
         return (dstat);
}
;