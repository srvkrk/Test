#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <sa/person.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/envelope.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <user_exits/epm_toolkit_utils.h>

int ITK_user_main(int argc, char *argv[])
{
	FILE				 *F1=NULL;
	int				ifail 						= ITK_ok;
	int             j                           = 0;
	int             i                           = 0;
	int             Flag                           = 0;
	int             n_entries                   = 2;
	int             n_entries1                   = 2;
	int             resultCount                 = 0;
	int             AuditobjectCount                 = 0;
	tag_t           queryTag                    = NULLTAG;
	tag_t           queryTag1                    = NULLTAG;
	tag_t           DMLReleaseTag                    = NULLTAG;
	tag_t           AuditobjectTag                    = NULLTAG;
	tag_t          *Releasedparts               = NULLTAG;
	tag_t          *Auditobject              = NULLTAG;
	char           *FromDate                    = NULL;
	char           *approverID                    = NULL;
	char           *ToDate                      = NULL;
	char           *qry_entries[2]              = {"date_released_after","date_released_before"};
	char           *qry_entries1[3]              = {"Performer","Job Name","Approve"};
	char           **qry_values                 =  (char **) MEM_alloc(500 * sizeof(char *));
	char           **qry_values1                 =  (char **) MEM_alloc(500 * sizeof(char *));
	
	char* sUserName	= NULL;
	char* sPassword = NULL;
	char* ChangReviewName = NULL;
	char* stringDML = NULL;
	char* dml_no = NULL;
	char* AssignmentName = NULL;
	char* performer = NULL;
	char* StartDate = NULL;
	char* ApproverDate = NULL;
	char* EndDate = NULL;
	char* DMLDRStatus = NULL;
	char* DMLOwner = NULL;
	char* DMLdescription = NULL;
	char DMLOutput[200] ="";
	
	stringDML= (char*) malloc(200);
	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
    FromDate 		= ITK_ask_cli_argument("-I1=");
	ToDate 			= ITK_ask_cli_argument("-I2=");
	approverID 			= ITK_ask_cli_argument("-ID=");

	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}
	sprintf(DMLOutput,"DML_Approvedeatailsreport.csv");

	F1=fopen(DMLOutput,"w+");
	if (F1 == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
	{
		printf("File opened successfully.\n");
	}
//DML number, DR-status, DML desc, DML owner,Assignment name, Performer, Start date, Approve date, DML LC
	if(QRY_find2("DML_Release_Btwn_Dates", &queryTag));
	printf("\n\t DML_Release_Btwn_Dates : QRY_find");fflush(stdout);
	if( queryTag != NULLTAG )
	{ 

		qry_values[0] = FromDate;
		qry_values[1] = ToDate;

		if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &Releasedparts));
		printf("\n DML_Release--resultCount : %d\n", resultCount);fflush(stdout);

		for(i=0;i<resultCount;i++)
		{
				strcpy(stringDML,"");
				DMLReleaseTag = Releasedparts[i];
		
				if(AOM_ask_value_string(DMLReleaseTag,"item_id",&dml_no));
				printf("\n DML Number : %s",dml_no);fflush(stdout);
				if(AOM_ask_value_string(DMLReleaseTag,"t5_cDRstatus",&DMLDRStatus));
				printf("\n DML DRStatus : %s",DMLDRStatus);fflush(stdout);
				if(AOM_ask_value_string(DMLReleaseTag,"object_desc",&DMLdescription));
				printf("\n DML description : %s",DMLdescription);fflush(stdout);
				if(AOM_ask_value_string(DMLReleaseTag,"requestor_user_id",&DMLOwner));
				printf("\n DML Owner : %s",DMLOwner);fflush(stdout);
				
				strcat(stringDML,"*");
				strcat(stringDML,dml_no);
				strcat(stringDML,"*");
				printf("\n stringDML  :: %s \n",stringDML);fflush(stdout);
				printf("\n Approver ID is  :: %s \n",approverID);fflush(stdout);
         

		        if(QRY_find2("AuditPerformerdetails", &queryTag1));
	            printf("\n\t AuditPerformerdetails : QRY_find");fflush(stdout);
				if( queryTag1 != NULLTAG )
			    {

					qry_values1[0] = approverID;
					qry_values1[1] = stringDML;
					qry_values1[2] = "Approve";

					if(QRY_execute(queryTag1, n_entries1, qry_entries1, qry_values1, &AuditobjectCount, &Auditobject));
					printf("\n DML_Release--AuditobjectCount : %d\n", AuditobjectCount);fflush(stdout);

					for(j=0;j<AuditobjectCount;j++)
					{
						AuditobjectTag = Auditobject[j];

						if(AOM_ask_value_string(AuditobjectTag,"parent_taskDisp",&AssignmentName));
						printf("\n Assignment_Name : %s",AssignmentName);fflush(stdout);
						if(AOM_ask_value_string(AuditobjectTag,"fnd0UserId",&performer));
						printf("\n performer_Id : %s",performer);fflush(stdout);
						if(AOM_ask_value_string(AuditobjectTag,"fnd0StartDate",&StartDate));
						printf("\n Start_Date : %s",StartDate);fflush(stdout);
						if(AOM_ask_value_string(AuditobjectTag,"fnd0LoggedDate",&ApproverDate));
						printf("\n Approve_Date : %s",StartDate);fflush(stdout);
						if(AOM_ask_value_string(AuditobjectTag,"fnd0EndDate",&EndDate));
						printf("\n End_Date : %s",EndDate);fflush(stdout);


						fprintf(F1,"%s,%s,%s,%s,%s,%s,%s,%s,%s\n",dml_no,DMLDRStatus,DMLdescription,DMLOwner,AssignmentName,performer,StartDate,ApproverDate,EndDate);fflush(F1);


					}

				}
					
		}
		fclose(F1);
   }

}
