/**********************************************************************************************************************************************************
**Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
**
** This software is the confidential and proprietary information of TTL.
** You shall not disclose such confidential information and shall use it
** only in accordance with the terms of the license agreement.
**
** SOURCE FILE NAME: closure_date_stamp.c
**
** Functions:- 	This utility queries DML into teamcenter and get it's revision's closure date, if found null then stamps released date as a closure date 
				on DML Revision and it's associated tasks and writes required information into the file.
** 
**
**	Date							Author								Modification
**	02-July-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** closure_date_stamp -u=<username> -p=<password> -g=<group>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


FILE		*output 			= NULL;

char		*sep				= "^";

int run_dml_query();
int write_info(tag_t, char* );

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        );	
}


/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);

	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
		}
	
		ifail = run_dml_query();
		CHECK_FAIL;
		
	fclose(output);
	printf("\n*********************");
	printf("\nEnd of program.....!!");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/**********************************************************************************************
    Function:       run_dml_query
    Description:    This function queries the dml in teamcenter and checks for closure date,
					if found null then stamps released date on closure date of dml revision.
**********************************************************************************************/
int run_dml_query()
{
	int				ifail 						= ITK_ok;
	int				i	 						= 0;
	//int			j	 						= 0;
	int				k	 						= 0;
	int				results						= 0;
	int				task_count					= 0;
	
	char			*entry0						= "Name";
	char			*entry1						= "Type";
	
	char			*obj_name					= "*";
	char			*obj_type					= "ERC DML";
	char			*closure_date1				= NULL;
	char			*release_date1				= NULL;
	char			*task_id					= NULL;
	char			*dml_no						= NULL;
	char			*value						= NULL;
	
	date_t			closure_date				= NULLDATE;
	date_t			release_date				= NULLDATE;

	tag_t			query_tag					= NULLTAG;
	tag_t			relation					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	tag_t			*dml_tag					= NULL;
	tag_t			*task_tag					= NULL;

	char**  		entries						= NULL;
	char**  		values						= NULL;
		
	entries		= (char**) MEM_alloc (sizeof(char*) * 5);
	values		= (char**) MEM_alloc (sizeof(char*) * 5);
	
	entries[0] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry0) + 20));
	values[0]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(obj_name) + 20));
			
	entries[1] 	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry1) + 20));
	values[1]  	= (char*) MEM_alloc (sizeof(char) * (tc_strlen(obj_type) + 20));
			
	tc_strcpy(entries[0], "");	
	tc_strcpy(entries[0], entry0);
	tc_strcpy(values[0], "");	
	tc_strcpy(values[0], obj_name);
	
	tc_strcpy(entries[1], "");	
	tc_strcpy(entries[1], entry1);
	tc_strcpy(values[1], "");	
	tc_strcpy(values[1], obj_type);
	
	ifail = QRY_ignore_case_on_search(TRUE);
	ifail = QRY_find2("get_dml", &query_tag);
		
	if(query_tag == NULLTAG)
	{
		printf("\nQuery Not Found in TC....!!\n");
		return 0;
	}
	else
	{
		ifail = QRY_execute(query_tag,2, entries, values, &results, &dml_tag);
		if(results > 0)
		{
			printf("\nTotal %d ERC DML found\n", results);
			for(i=0;i<results;i++)
			{
				ifail = ITEM_ask_id2(dml_tag[i], &dml_no);
				ifail = ITEM_ask_latest_rev(dml_tag[i], &rev_tag);
				//ifail = ITEM_ask_id2(rev_tag, &rev_id);
				
				ifail = AOM_ask_value_date(rev_tag, "CMClosureDate", &closure_date);
				ifail = ITK_date_to_string(closure_date, &closure_date1);
				if(tc_strcmp(closure_date1, "") == 0)
				{
					printf("\nClosure Date is Null...!!");
					ifail = AOM_ask_value_date(rev_tag, "date_released", &release_date);
					ifail = ITK_date_to_string(release_date, &release_date1);
					if(tc_strcmp(release_date1, "") != 0)
					{
						printf("\nReleased date is:%s\n", release_date1);
						ifail = AOM_refresh(rev_tag, 1);
						ifail = AOM_set_value_date(rev_tag, "CMClosureDate", release_date);
						ifail = AOM_save(rev_tag);
						ifail = AOM_refresh(rev_tag, 0);
						if(ifail == ITK_ok)
						{
							printf("\nReleased Date stamped on rev:%s\n", release_date1);
							fprintf(output, "%s", dml_no);fflush(stdout);
						}
						else
						{
							printf("\nFailed to stamp released date...!!\n");
							return 0;
						}

						ifail = GRM_find_relation_type("T5_DMLTaskRelation", &relation);
						CHECK_FAIL;

						ifail = GRM_list_secondary_objects_only(rev_tag, relation, &task_count, &task_tag);
						for(k=0;k<task_count;k++)
						{
							ifail = AOM_UIF_ask_value(task_tag[k], "item_id", &task_id);
							ifail = AOM_refresh(task_tag[k], 1);
							ifail = AOM_set_value_date(task_tag[k], "CMClosureDate", release_date);
							ifail = AOM_save(task_tag[k]);
							ifail = AOM_refresh(task_tag[k], 0);
							if(ifail == ITK_ok)
							{
								printf("\nReleased Date stamped on task:%s\n", release_date1);
								fprintf(output, "%s%s%s%s", sep, task_id, sep, release_date1);fflush(stdout);
							}
							else
							{
								printf("\nFailed to stamp released date on task...!!\n");
								return 0;
							}
						}
						fprintf(output, "\n");
						MEM_free(task_tag);						
					}
					else
					{
						printf("\nReleased Date is NULL...!!\n");
						return 0;
					}
				}
				else
				{
					printf("\nClosure date is:%s\n", closure_date1);
					return 0;
				}				
			}
			MEM_free(closure_date1);
			MEM_free(release_date1);
		}
		MEM_free(dml_tag);
	}

	/*MEM_free(entries[0]);
	MEM_free(values[0]);
	MEM_free(entries[1]);
	MEM_free(values[1]);
	MEM_free(entries);
	MEM_free(values);*/

	return ifail;	
}
