. /user/uaprod/.bash_profile
#!/bin/ksh
#echo $1
#rm -f $1*
cd /user/rrr05503/Programs/ERC_DML_VCMS/
if [ -f "$1_TCUA_VCMS_NOPOList.txt" ]; then
mv "$1_TCUA_VCMS_NOPOList.txt" "$1_TCUA_VCMS_NOPOList.txt_old"
fi
touch "$1_TCUA_VCMS_NOPOList.txt"
chmod 777 "$1_TCUA_VCMS_NOPOList.txt"
/user/rrr05503/Programs/ERC_DML_VCMS/TCUANOPOERCDml -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -dml=$1
#pwd
#ls -ltr
if [ ! -f "$1_TCUA_VCMS_NOPOList.txt" ]; then
#    echo "File not found!"
    touch $1_TCUA_VCMS_NOPOList.txt
fi
