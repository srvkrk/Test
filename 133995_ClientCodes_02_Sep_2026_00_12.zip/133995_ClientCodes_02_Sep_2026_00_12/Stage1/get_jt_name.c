/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: get_jt_name.c
**
** Functions:- 	This utility takes item_id as input from file and queries it into teamcenter and get it's latest revision's secondary objects with 
				(IMAN_Rendering) relation and get it's name.
** 
**
**	Date							Author								Modification
**	02-April-2018					Kalpesh Gondhali					Code creation
**
** command to run:
** get_jt_name -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value" 

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

FILE		*output 			= NULL;
int			ifail 				= ITK_ok;

char		*sep				= ",";

int read_value_from_file(char*);
int get_jt_name(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter Usr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<filename> (required)\n"
        );	
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper Usr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;
	char			Data[50]					= "";
	char			outputFile[100]				= "";
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-p=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");
		
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.csv",Data);
	
	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	
	
	output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
	{
		printf("File opened successfully.\n");
	}
			
	ifail = read_value_from_file(Filename);
		
	printf("\nEnd of program.....!!\n");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{	
	char 		*itemid					= NULL;
	char 		temp[200];
	
	FILE		* fp 					= NULL;
	
	fp = fopen(Filename, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));
		
			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "^");
				printf("\nInput Item_id:%s\n",itemid);
								
				ifail = get_jt_name(itemid);
				printf("***************************\n");
			}			
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       get_jt_name
    Description:    This function takes the item_id as input and queries into TC and gets
					latest revision's secondary object_name.
********************************************************************************************/
int get_jt_name(char* item_id)
{
	int				i 							= 0;
	int				sec_count 					= 0;
	
	tag_t			item_tag 					= NULLTAG;
	tag_t			latest_rev_tag				= NULLTAG;
	tag_t			relation					= NULLTAG;
	tag_t			*sec_objects				= NULL;
	
	char 			*jt_name					= NULL;
	char 			*latest_rev_id				= NULL;
	char			*test						= (char *)MEM_alloc(sizeof (char) * 50);

	ifail = ITEM_find_item (item_id, &item_tag);
	if(item_tag == NULLTAG)
	{
		printf("Object not found in TC...!!\n");
		printf("***************************\n");
		return 0;
	}
	
	ifail = ITEM_ask_latest_rev (item_tag, &latest_rev_tag);
	CHECK_FAIL;

	ifail = AOM_UIF_ask_value (latest_rev_tag, "item_revision_id", &latest_rev_id);
	printf("\nLatest Rev. found is:%s\n",latest_rev_id);
	CHECK_FAIL;
		
	ifail = GRM_find_relation_type ("IMAN_Rendering", &relation);
	CHECK_FAIL;
	ifail = GRM_list_secondary_objects_only (latest_rev_tag, relation, &sec_count, &sec_objects);
	CHECK_FAIL;
	
	if(sec_count > 1)
	{
		tc_strcpy(test, "");
		tc_strcpy(test,item_id);
		tc_strcat(test,sep);
		tc_strcat(test,latest_rev_id);

		fprintf(output, "\n%s", test);

		printf("\nTotal %d sec_object found...!!", sec_count);
		
		for(i=0; i<sec_count ;i++)
		{
			ifail = AOM_UIF_ask_value (sec_objects[i], "object_name", &jt_name);
			printf("\nName of JT:%s\n",jt_name);
			fprintf(output, "%s%s", sep, jt_name);
		}		
	}
	else
	{
		printf("\nTotal %d sec_object found...!!\n", sec_count);
		return 0;
	}
	
	MEM_free(latest_rev_id);
	MEM_free(sec_objects);	
	MEM_free(jt_name);

	return ifail;
}
