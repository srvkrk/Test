/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: ERC_Released_Remove_Add_Status_staming.c
**
** Functions:- 	This utility takes DML No and DR_status as input from file and updates the value of DR_status attribute for latest revision of
				DML found from input and writes appropriate information into output file.
**
**
**	Date							Author							Modification
**	6-Dec-2025						Mohan Tayade					ERC_Released_Status_Remove_Fun
**
** command to run:
/home/cvprod/SLES15_patch/tcldPatch/tcPatchExecutable ERC_Released_status_Remove
** ./ERC_Released_status_Remove -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -inputPart=557646703306 -R=NR -S=3
***********************************************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#define PROP_UIF_set_value_msg		"PROP_UIF_set_value"
#include <tccore/aom.h>
#include <res/res_itk.h>
//#include <bom/bom.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <tccore/releasestatus.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <tccore/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define PROP_UIF_set_value_msg		"PROP_UIF_set_value"

FILE 		*output 			= NULL;
char		*sep				= ",";
int read_value_from_file(char*);
int ERC_Released_Status_Remove_Fun(char*,char*);
int write_info(char*, char*, char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -pf=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<filename> (required)\n"
        );
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
					It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* inputPart					= NULL;
	char			* Filename					= NULL;
	char			* sObjno					= NULL;
	char			* sProperty					= NULL;
	char			* sValue					= NULL;
	char			Data[100]					= "";
	

	char 			*test						= (char*)MEM_alloc(sizeof(char) * 500);
	//char			outputFile[200]				= "";
	char* revid1 = NULL;
	revid1=(char *) MEM_alloc(100);

	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	inputPart		= ITK_ask_cli_argument("-inputPart=");
	char* revid	   = ITK_ask_cli_argument("-R=");
	char* seq	   = ITK_ask_cli_argument("-S=");
	//sObjno		= ITK_ask_cli_argument("-number=");
	//sProperty		= ITK_ask_cli_argument("-property=");
	//sValue		= ITK_ask_cli_argument("-value=");

//	time_t 	now;
//	struct 	tm when;
//
//	time(&now);
//	when = *localtime(&now);
//
//	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
//	sprintf(outputFile,"%s_output.txt",Data);

//	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
//	{
//		print_requirement();
//		return -1;
//	}

	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

		revid1=tc_strcpy(revid1,"");
		revid1=tc_strcat(revid1,revid);
		revid1=tc_strcat(revid1,";");
		revid1=tc_strcat(revid1,seq);

	

		//ifail = read_value_from_file(Filename);
		ifail = ERC_Released_Status_Remove_Fun(inputPart,revid1);
		//ifail = read_value_from_file(sObjno,sProperty,sValue);

	printf("\nEnd of program.....!!\n\n");
	printf("\n*****************************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}

/********************************************************************************************
    Function:       update_dr_status
    Description:    This function takes the item_id and attr_value as input and stamps the
					attr_value on specific attribute of all revisions of perticular item.
********************************************************************************************/

int ERC_Released_Status_Remove_Fun(char* inputPart ,char* revid1)
{
	int				ifail 						= ITK_ok;
	int				r_count 					= 0;
	int				i		 					= 0;

	tag_t			DML_tag						= NULLTAG;
	tag_t			*rev_tag						= NULLTAG;

	char 			*dr_status_new				= NULL;
	char 			*updvalue					= NULL;
	
	int count = 0;
	tag_t parttag = NULLTAG;
	tag_t prtrevtag = NULLTAG;
	tag_t attr_tag = NULLTAG;
	tag_t* status_list = NULLTAG;
	tag_t	tsk_dml_rel_type	= NULLTAG;
	tag_t	*Task = NULLTAG;
	date_t set_date;
	char* DMLno = NULL;
	char* objType = NULL;
	char* status_name = NULL;
	char* task_id = NULL;
	//char* item_id = NULL;
	tag_t objTypTag			=NULLTAG;
	int k,k1,x,k2 = 0;
	int num = 0;
	int loc = 1;
	int delStat = 0;
	int count2 = 0;
	int FoundRel = 0;
	int status = 0;
	int n_entries = 1;
	int status_count = 0;
	int RelStusFnd = 0;
	int resultCount1 = 0;
	int FlagRelStat = 0;
	int FlagReltoget = 0;
	int status_countt = 0;
	int count_rev = 0;
   char* ReleaseStatus = NULL;
	char *sNOPOFldr = NULL;
	char *DMLNo = NULL;
	char *s_objtype = NULL;
	char **UpdRlzStatus = NULL;
	char *latest_rev_Rel_Stus1 = NULL;
	char *latest_rev_Rel_Stus = NULL;
	char *obj_type = NULL;
	char *item_id = NULL;
	tag_t DMLTag = NULLTAG;
	tag_t *ERCDMLRlz = NULLTAG;
	tag_t *secondary_objects = NULLTAG;
	tag_t *relStatus_list = NULLTAG;
	tag_t *chkrelStatus_list = NULLTAG;
	tag_t attRelStatus = NULLTAG;
	tag_t s_relation_type = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t old_form_relation = NULLTAG;
	tag_t release_status =NULLTAG;
	logical retain_released_dateSVR ;
	
	ifail = ITEM_find_item (inputPart, &DML_tag);
	ifail = ITEM_list_all_revs(DML_tag, &count_rev, &rev_tag);
	printf("ITEM_list_all_revs count = [%d]\n",count_rev);fflush(stdout);
	for(int zz=0;zz<count_rev;zz++)
   {

		if(ifail != ITK_ok)
		{
			printf("Object not found in Teamcenter...!!\n");fflush(stdout);
			return 0;
		}
		else
		{
			printf("\nObject found in Teamcenter........!!\n");fflush(stdout);

			if(AOM_UIF_ask_value(rev_tag[zz],"object_type",&objType)!=ITK_ok)PrintErrorStack();

			printf("\n  object_type is %s\n", objType);fflush(stdout);

			if((tc_strcmp(objType,"ChangeRequestRevision")==0)||(strcmp(objType,"T5_ChangeTaskRevision")==0)|| (strcmp(objType,"Design Revision")==0) || (tc_strcmp(objType,"ERC DML Revision")==0) || (tc_strcmp(objType,"Colour Part Revision")==0) || (tc_strcmp(objType,"Vehicle Offer/PassOfNorms Drawing Revision")==0))
			{

				printf("\n Getting DML no..  \n");fflush(stdout);

				if(AOM_ask_value_string(rev_tag[zz],"item_id",&item_id)!=ITK_ok)PrintErrorStack();
				printf("\n item_id of DML\n\n = %s  \n",item_id);fflush(stdout);
				char* Child_rev_idd=NULL;
				if(AOM_UIF_ask_value (rev_tag[zz], "item_revision_id",&Child_rev_idd)!=ITK_ok)PrintErrorStack();
				printf("\n DR:Latest released rev is:%s.", Child_rev_idd);fflush(stdout);
				printf("\n Input Rev %s.", revid1);fflush(stdout);
				if (tc_strcmp(revid1,Child_rev_idd)==0)
				{
					printf("\n Inside rev is:%s.", Child_rev_idd);fflush(stdout);
					ifail = WSOM_ask_release_status_list(rev_tag[zz], &status_countt, &relStatus_list);
					printf("\n\t WSOM_ask_release_status_list count is :: [%d] & Matching :: [%s]\n",status_countt, Child_rev_idd);fflush(stdout);
					if (status_countt > 0)
					{
						for (k1=0;k1 < status_countt; k1++)
						{
							ifail = AOM_ask_value_string(relStatus_list[k1],"object_name",&latest_rev_Rel_Stus1);
							printf("\n\t %d. Release status is11 : %s>>>>>>>>>\n",k1,latest_rev_Rel_Stus1);fflush(stdout);
							if ((tc_strcmp(latest_rev_Rel_Stus1,"T5_LcsErcRlzd") == 0) ||(tc_strcmp(latest_rev_Rel_Stus1,"ERC Released")==0) ||(tc_strcmp(latest_rev_Rel_Stus1,"ERC Review")==0) ||(tc_strcmp(latest_rev_Rel_Stus1,"T5_LcsReview")==0))
							{
								//printf("\n\t Release status found for the DML : %s\n",rev_tag[zz]);fflush(stdout);
								printf("\n\t RelStusFnd Set to 1");fflush(stdout);


								ifail = AOM_ask_value_string(relStatus_list[k1],"object_name",&latest_rev_Rel_Stus);
								printf("\n\t %d. Release status is part :: %s>>>>>>>>>\n",k1,latest_rev_Rel_Stus);fflush(stdout);

								//if ((tc_strcmp(latest_rev_Rel_Stus,"T5_LcsErcRlzd") == 0) ||(tc_strcmp(latest_rev_Rel_Stus,"ERC Released")==0))
								//{
									

									printf("\n  inside to clear status of part loop Found release status is22 : %s \n  Revision which is clear status of Released = [%s] \n",latest_rev_Rel_Stus, Child_rev_idd);fflush(stdout);
									(AOM_refresh(rev_tag[zz],1));
									CHECK_FAIL(ITK_set_bypass(true));
									CHECK_FAIL(POM_attr_id_of_attr("release_status_list","T5_VODRevision",&attRelStatus));
									CHECK_FAIL(POM_refresh_instances_any_class(1,&rev_tag[zz], POM_modify_lock));
									CHECK_FAIL(POM_clear_attr(1,&rev_tag[zz],attRelStatus));
									CHECK_FAIL(POM_save_instances(1,&rev_tag[zz],true));
									CHECK_FAIL(POM_refresh_instances_any_class(1,relStatus_list,POM_delete_lock));
									CHECK_FAIL(POM_delete_instances(1,relStatus_list));

									CHECK_FAIL(RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status));
									CHECK_FAIL(AOM_ask_name(release_status,&ReleaseStatus));
									printf("\n ReleaseStatus:%s ",ReleaseStatus);fflush(stdout);
									if((strcmp(ReleaseStatus,"ERC Released")==0)||strcmp(ReleaseStatus,"T5_LcsErcRlzd")==0)
									{
										CHECK_FAIL(RELSTAT_add_release_status(release_status,1,&rev_tag[zz],retain_released_dateSVR));
									}
									(AOM_refresh(rev_tag[zz],0));

									
									

									ifail = WSOM_ask_release_status_list(rev_tag[zz], &num, &chkrelStatus_list);
									printf("\nAfter remove released status of part [%s]\n",Child_rev_idd);fflush(stdout);
									break;
								//}
								
							}
							printf("\n No release status found \n");fflush(stdout);

						}
					}
				}
				printf("\n Input Revision sequence not found\n");fflush(stdout);

			}


			printf("\n**********Done*************\n");fflush(stdout);
		}
  }
  return ifail;
}
