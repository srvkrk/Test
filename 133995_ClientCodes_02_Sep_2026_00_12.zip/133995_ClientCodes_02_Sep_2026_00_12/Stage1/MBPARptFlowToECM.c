#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <pom/enq/enq.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/pom/pom.h>
#include <epm/epm.h>
#include <user_exits/libuser_exits_exports.h>
#include <user_exits/libuser_exits_undef.h>
#include <time.h>
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
//#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
//#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <stdio.h>
#include <string.h>






#define Debug TRUE

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text (stat, &err_string);                  \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

char*       ReportExecutionPath   = NULL;
char*       DevOption             = NULL;
char*       ReportHTMLFileName    = NULL;
char*       LastWeekFromDate      = NULL;
char*       LastWeekToDate        = NULL;

int getMonth(char *mon)
{
    const char *months[] = {"Jan","Feb","Mar","Apr","May","Jun",
                           "Jul","Aug","Sep","Oct","Nov","Dec"};
    for (int i = 0; i < 12; i++) {
        if (strcmp(mon, months[i]) == 0)
            return i;
    }
    return 0;
}

time_t extractTime(const char *filename) {
    char day[4], mon[4];
    int date, hr, min, sec, year;

    sscanf(filename, "%*[^_]_%3s_%3s_%d_%d_%d_%d_%d",
           day, mon, &date, &hr, &min, &sec, &year);

    struct tm t = {0};
    t.tm_mday = date;
    t.tm_mon = getMonth(mon);
    t.tm_year = year - 1900;
    t.tm_hour = hr;
    t.tm_min = min;
    t.tm_sec = sec;

    return mktime(&t);
}

int compare(const void *a, const void *b) {
    char *file1 = *(char **)a;
    char *file2 = *(char **)b;

    time_t t1 = extractTime(file1);
    time_t t2 = extractTime(file2);

    return (t1 > t2) - (t1 < t2);
}




int IsRptExistINMBPAObj(tag_t MBPAObj)
{
	int RptPresent = 0;
	tag_t  relation_type = NULLTAG;
    GRM_find_relation_type("IMAN_specification",&relation_type);
	if(relation_type != NULLTAG)
	{
		char* relation_name;
		char* MBPARptObjectNameStr = NULL;
        tag_t*  attachments = NULLTAG;
        int Tcnt = 0;
        TCTYPE_ask_name2( relation_type, &relation_name);
        GRM_list_secondary_objects_only(MBPAObj,relation_type,&Tcnt,&attachments);
        tag_t  dataset = NULLTAG;
        tag_t  objTypeTag = NULLTAG;
        char*   ObjectClassType;
		AOM_ask_value_string(MBPAObj,"item_id",&MBPARptObjectNameStr);
		printf("\n Tcnt = %d",Tcnt);fflush(stdout);
		printf("\n MBPARptObjectNameStr = %s",MBPARptObjectNameStr);fflush(stdout);
			
		if (Tcnt > 0)
        {
            int Index = 0;
            for (Index = 0;Index<Tcnt;Index++)
            {
                dataset = attachments[Index];
                TCTYPE_ask_object_type(dataset,&objTypeTag);
                TCTYPE_ask_name2(objTypeTag,&ObjectClassType);
                printf("\n ObjectClassType :: %s\n", ObjectClassType);
				
                if(tc_strcmp(ObjectClassType,"PDF") == 0)
				{
					RptPresent = 1;
					break;
				}
			}
		}
	}
	return RptPresent;
}



void GetLastWeekFromDateAndToDate(char* LastWeekFromDate,char* LastWeekToDate)
{
	time_t now;
    struct tm from_date, to_date;

    // Get current time
    time(&now);

    // Convert to local time
    struct tm *current = localtime(&now);

    // Copy current date into structs
    from_date = *current;
    to_date = *current;

    // Calculate last week's "to" date (7 days ago)
    to_date.tm_mday -= current->tm_wday ;  
    mktime(&to_date);

    // Calculate last week's "from" date (6 days before "to")
    from_date = to_date;
    from_date.tm_mday -= 6;
    mktime(&from_date);

    char from_str[20], to_str[20];

    // Format: dd-MMM-yyyy
    strftime(from_str, sizeof(from_str), "%d-%b-%Y", &from_date);
    strftime(to_str, sizeof(to_str), "%d-%b-%Y", &to_date);

    printf("Last Week From: %s\n", from_str);
    printf("Last Week To  : %s\n", to_str);
	
	tc_strcpy(LastWeekFromDate,from_str);
	tc_strcpy(LastWeekToDate,to_str);
}



void ReportFileHeaderCreation(FILE* ReportHTML,char* PlantName)
{
	fprintf(ReportHTML,"<!DOCTYPE html>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<html>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<head>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<style>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n#EPABASEDMBPA {");fflush(ReportHTML);
	fprintf(ReportHTML,"\nfont-family: Arial, Helvetica, sans-serif;");fflush(ReportHTML);
	fprintf(ReportHTML,"\nborder-collapse: collapse;");fflush(ReportHTML);
	fprintf(ReportHTML,"\nwidth: 100%;");fflush(ReportHTML);
	fprintf(ReportHTML,"\n}");fflush(ReportHTML);
	fprintf(ReportHTML,"\n#EPABASEDMBPA td, #customers th {");fflush(ReportHTML);
	fprintf(ReportHTML,"\nborder: 1px solid #ddd;");fflush(ReportHTML);
	fprintf(ReportHTML,"\npadding: 8px;");fflush(ReportHTML);
	fprintf(ReportHTML,"\n}");fflush(ReportHTML);
	fprintf(ReportHTML,"\n#EPABASEDMBPA tr:nth-child(even){background-color: #f2f2f2;}}");fflush(ReportHTML);
	fprintf(ReportHTML,"\n#EPABASEDMBPA tr:hover {background-color: #ddd;}");fflush(ReportHTML);
	fprintf(ReportHTML,"\n#EPABASEDMBPA th {");fflush(ReportHTML);
	fprintf(ReportHTML,"\npadding-top: 12px;");fflush(ReportHTML);
	fprintf(ReportHTML,"\npadding-bottom: 12px;");fflush(ReportHTML);
	fprintf(ReportHTML,"\ntext-align: left;");fflush(ReportHTML);
	fprintf(ReportHTML,"\n	background-color: #04AA6D;");fflush(ReportHTML);
	fprintf(ReportHTML,"\ncolor: white;");fflush(ReportHTML);
	fprintf(ReportHTML,"\n}");fflush(ReportHTML);
	fprintf(ReportHTML,"\n</style>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n</head>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<body>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<h2>EPA Based MBPA Created for ECM-%s between %s to %s</h2>",PlantName,LastWeekFromDate,LastWeekToDate);fflush(ReportHTML);
	fprintf(ReportHTML,"\n<table id=EPABASEDMBPA>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<tr>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<th>MBPA Number</th>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<th>MBPA Description</th>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<th>Aggrigate</th>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<th>EPA Number</th>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n</tr>");fflush(ReportHTML);
}


void ReportADDRowInTable(FILE* ReportHTML,char* MBPANum,char* MBPADesc,char* MBPAAggr,char* MBPAEPANum)
{
	fprintf(ReportHTML,"\n<tr>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<td>%s</td>",MBPANum);fflush(ReportHTML);
	fprintf(ReportHTML,"\n<td>%s</td>",MBPADesc);fflush(ReportHTML);
	fprintf(ReportHTML,"\n<td>%s</td>",MBPAAggr);fflush(ReportHTML);
	fprintf(ReportHTML,"\n<td>%s</td>",MBPAEPANum);fflush(ReportHTML);
	fprintf(ReportHTML,"\n</tr>");fflush(ReportHTML);
}

void ReportFileEndCreation(FILE* ReportHTML)
{
	fprintf(ReportHTML,"\n</table>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n<h3>Thanks & Regards,<br>PLM NON-ERC</h3>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n</body>");fflush(ReportHTML);
	fprintf(ReportHTML,"\n</html>");fflush(ReportHTML);
}



void SentMailToUser(FILE* ReportHTML,char **Masterfiles,int PlantIndex,int MasterFileIndex)
{
	ReportFileEndCreation(ReportHTML);
	// Print
	char* ReportMail = NULL;
    ReportMail = (char *) MEM_alloc(1000);
	strcpy(ReportMail,"");
	if(PlantIndex == 1)
	{
	    if(tc_strcmp(DevOption,"1") == 0)
	    {
	    	strcat(ReportMail,"/user/cvprod/Abinesh/MBPARptFlowToECM/MBPARptFlowToECMJSR.sh ");
	    }
		else
		{
			strcat(ReportMail,"/user/cvprod/shells/STDSEBOM/MBPARptFlowToECM/Script/MBPARptFlowToECMJSR.sh");
		}
	}
	if(PlantIndex == 2)
	{
	    if(tc_strcmp(DevOption,"1") == 0)
	    {
	    	strcat(ReportMail,"/user/cvprod/Abinesh/MBPARptFlowToECM/MBPARptFlowToECMPUNE.sh ");
	    }
		else
		{
			strcat(ReportMail,"/user/cvprod/shells/STDSEBOM/MBPARptFlowToECM/Script/MBPARptFlowToECMPUNE.sh");
		}
	}
	if(PlantIndex == 3)
	{
	    if(tc_strcmp(DevOption,"1") == 0)
	    {
	    	strcat(ReportMail,"/user/cvprod/Abinesh/MBPARptFlowToECM/MBPARptFlowToECMLKO.sh ");
	    }
		else
		{
			strcat(ReportMail,"/user/cvprod/shells/STDSEBOM/MBPARptFlowToECM/Script/MBPARptFlowToECMLKO.sh");
		}
	}
	if(PlantIndex == 4)
	{
	    if(tc_strcmp(DevOption,"1") == 0)
	    {
	    	strcat(ReportMail,"/user/cvprod/Abinesh/MBPARptFlowToECM/MBPARptFlowToECMPNR.sh ");
	    }
		else
		{
			strcat(ReportMail,"/user/cvprod/shells/STDSEBOM/MBPARptFlowToECM/Script/MBPARptFlowToECMPNR.sh");
		}
	}
	if(PlantIndex == 5)
	{
	    if(tc_strcmp(DevOption,"1") == 0)
	    {
	    	strcat(ReportMail,"/user/cvprod/Abinesh/MBPARptFlowToECM/MBPARptFlowToECMDWD.sh ");
	    }
		else
		{
			strcat(ReportMail,"/user/cvprod/shells/STDSEBOM/MBPARptFlowToECM/Script/MBPARptFlowToECMDWD.sh");
		}
	}
	
	
	
	
	int FileIndex =0;
	strcat(ReportMail,ReportHTMLFileName);
	for (FileIndex = 0; FileIndex < MasterFileIndex; FileIndex++) 
	{
		printf("%s\n", Masterfiles[FileIndex]);
		strcat(ReportMail," ");
		strcat(ReportMail,Masterfiles[FileIndex]);
	}
	printf("\n %s",ReportMail);fflush(stdout);
	
	if(MasterFileIndex >0)
	{
		int SysReturn = 0;
		SysReturn = system(ReportMail);
	}
}

int startsWith(char *str, char *prefix) 
{
    return strncmp(str, prefix, 1) == 0;
}

void ProcessMBPASet(int NoOfMBPA, tag_t* MBPASet, int PlantIndex,char* PlantEPAStartWith)
{
	int itrMBPA = 0;
	int MasterFileIndex = 0;
	char **Masterfiles = malloc(1 * sizeof(char *));
	Masterfiles[0] = malloc(100);
	
	
	ReportHTMLFileName = (char *) MEM_alloc(1000);
	FILE *ReportHTML = NULL;
	const char *plantNames[] = {"JSR","PUNE","LKO","PNR","DWD"};
	if (PlantIndex >= 1 && PlantIndex <= 5)
	{
		sprintf(ReportHTMLFileName,"TCUA_EPA_Based_MBPA_For_ECM_%s_Generated.html",plantNames[PlantIndex - 1]);
		ReportHTML = fopen(ReportHTMLFileName,"w");
		ReportFileHeaderCreation(ReportHTML,plantNames[PlantIndex - 1]);
	}
	
	
	
	for (itrMBPA = 0;itrMBPA<NoOfMBPA;itrMBPA++)
	{
		tag_t MBPAObj = NULLTAG;
		tag_t MBPARevObj = NULLTAG;
		char 		*checkedout 	=	NULL;
		MBPAObj = MBPASet[itrMBPA];
		ITK_CALL(ITEM_ask_latest_rev(MBPAObj,&MBPARevObj));
		ITK_CALL(AOM_ask_value_string(MBPARevObj,"checked_out",&checkedout));
		printf(" Checkeout status is  [%s]\n",checkedout);fflush(stdout);
		
		char* MBPANum = NULL;
		ITK_CALL(AOM_ask_value_string(MBPARevObj,"item_id",&MBPANum));
		printf("\nMBPANum %s", MBPANum);
		char* MBPAEPANum = NULL;
		ITK_CALL(AOM_ask_value_string(MBPARevObj,"t5_TmpEcnNo",&MBPAEPANum));
		printf("\nMBPAEPANum %s", MBPAEPANum);
		printf("\nPlantEPAStartWith %s", PlantEPAStartWith);
		if (startsWith(MBPAEPANum, PlantEPAStartWith)) 
		{
			//OK Proceed
		}
		else
		{
			continue;
		}
		if(tc_strcmp(checkedout,"Y")==0)
		{
			continue;
		}
		tag_t  relation_type = NULLTAG;
        GRM_find_relation_type("IMAN_specification",&relation_type);
	    if(relation_type != NULLTAG)
	    {
	    	char* relation_name;
	    	char* MBPARptObjectNameStr = NULL;
            tag_t*  attachments = NULLTAG;
            int Tcnt = 0;
            TCTYPE_ask_name2( relation_type, &relation_name);
            GRM_list_secondary_objects_only(MBPARevObj,relation_type,&Tcnt,&attachments);
            tag_t  dataset = NULLTAG;
            tag_t  objTypeTag = NULLTAG;
            char*   ObjectClassType;
	    	AOM_ask_value_string(MBPARevObj,"item_id",&MBPARptObjectNameStr);
	    	printf("\n Tcnt = %d",Tcnt);fflush(stdout);
	    	printf("\n MBPARptObjectNameStr = %s\n",MBPARptObjectNameStr);fflush(stdout);
	    	
			char **files = malloc(Tcnt * sizeof(char *));	
			int NoOfMBPADataSet = Tcnt;			
	    	if (Tcnt > 0)
            {
                int Index = 0;
				
                for (Index = 0;Index<Tcnt;Index++)
                {
                    dataset = attachments[Index];
                    TCTYPE_ask_object_type(dataset,&objTypeTag);
                    TCTYPE_ask_name2(objTypeTag,&ObjectClassType);
                    printf("ObjectClassType :: %s\n", ObjectClassType);
					if(tc_strcmp(ObjectClassType,"PDF") == 0)
					{
						int reference_Count = 0;
						ITKCALL(AE_ask_dataset_ref_count(dataset, &reference_Count));
						
						int refCounter = 0;
						for (refCounter = 0;refCounter<reference_Count;refCounter++)
						{
						    char   *refname=NULL;
						    AE_reference_type_t reftype;
						    tag_t refobject = NULLTAG;
						    ITKCALL(AE_find_dataset_named_ref2(dataset,refCounter,&refname,&reftype,&refobject));
							char* OrgFileName = NULL;
							OrgFileName = (char *) MEM_alloc(250 * sizeof(char ));
							ITKCALL(IMF_ask_original_file_name2(refobject,&OrgFileName));
							printf("OrgFileName = %s\n", OrgFileName);fflush(stdout);
							files[Index] = strdup(OrgFileName);
							
						}
					}
					
	    		}
	    	}
			if(Tcnt>0)
			{
				int Index = 0;
				qsort(files, (NoOfMBPADataSet), sizeof(char *), compare);
				printf("\n %s", files[NoOfMBPADataSet-1]);
				int fWhentoBreak = 0;
                for (Index = 0;Index<Tcnt;Index++)
				{
					dataset = attachments[Index];
                    TCTYPE_ask_object_type(dataset,&objTypeTag);
                    TCTYPE_ask_name2(objTypeTag,&ObjectClassType);
                    printf("ObjectClassType :: %s\n", ObjectClassType);
					if(tc_strcmp(ObjectClassType,"PDF") == 0)
					{
						int reference_Count = 0;
						ITKCALL(AE_ask_dataset_ref_count(dataset, &reference_Count));
						
						int refCounter = 0;
						for (refCounter = 0;refCounter<reference_Count;refCounter++)
						{
						    char   *refname=NULL;
						    AE_reference_type_t reftype;
						    tag_t refobject = NULLTAG;
						    ITKCALL(AE_find_dataset_named_ref2(dataset,refCounter,&refname,&reftype,&refobject));
							char* OrgFileName = NULL;
							OrgFileName = (char *) MEM_alloc(250 * sizeof(char ));
							ITKCALL(IMF_ask_original_file_name2(refobject,&OrgFileName));
							printf("OrgFileName = %s\n", OrgFileName);fflush(stdout);
							if(tc_strcmp(OrgFileName,files[NoOfMBPADataSet-1]) == 0)
							{
							    char* ReportExecutionPathTemp = NULL;
							    ReportExecutionPathTemp = (char *) MEM_alloc(100 * sizeof(char ));
							    tc_strcpy(ReportExecutionPathTemp,ReportExecutionPath);
							    tc_strcat(ReportExecutionPathTemp,"/");
							    tc_strcat(ReportExecutionPathTemp,OrgFileName);
							    printf("ReportExecutionPathTemp = %s\n", ReportExecutionPathTemp);fflush(stdout);
							    IMF_export_file(refobject,ReportExecutionPathTemp);
								fWhentoBreak = 1;
								strcpy(Masterfiles[MasterFileIndex], ReportExecutionPathTemp);
								MasterFileIndex = MasterFileIndex +1;
								char **temp = realloc(Masterfiles, (MasterFileIndex + 1) * sizeof(char *));
								Masterfiles[MasterFileIndex] = malloc(100);
								
								char* MBPADesc = NULL;
								char* MBPAAggr = NULL;
								//char* MBPAEPANum = NULL;
								ITK_CALL(AOM_ask_value_string(MBPARevObj,"object_desc",&MBPADesc));
								ITK_CALL(AOM_ask_value_string(MBPARevObj,"t5_tcfAggregate",&MBPAAggr));
								//ITK_CALL(AOM_ask_value_string(MBPARevObj,"t5_TmpEcnNo",&MBPAEPANum));
								ReportADDRowInTable(ReportHTML,MBPANum,MBPADesc,MBPAAggr,MBPAEPANum);
								break;
							}
						}
					}
					if (fWhentoBreak == 1)
					{
						break;
					}
				}
			}
	    }
		
		
	}
	SentMailToUser(ReportHTML,Masterfiles,PlantIndex,MasterFileIndex);
	


    // Free memory
	int FileIndex =0;
    for (FileIndex = 0; FileIndex < MasterFileIndex; FileIndex++) 
	{
          free(Masterfiles[FileIndex]);
    }
    free(Masterfiles);
}


/*******MAIN FUNCTION************/

extern int ITK_user_main (int argc, char* argv[] )
{
	int                 status;
	ReportExecutionPath         = (char *) MEM_alloc(100 * sizeof(char *));
	DevOption         = (char *) MEM_alloc(2 * sizeof(char *));
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
    ITK_CALL(ITK_set_journalling( TRUE ));
    ITK_CALL(ITK_auto_login ());
	ReportExecutionPath = ITK_ask_cli_argument("-RptPath=");
	DevOption = ITK_ask_cli_argument("-DevOpt=");
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
    
	
	
	LastWeekFromDate = (char *) MEM_alloc(100 * sizeof(char *));
	LastWeekToDate = (char *) MEM_alloc(100 * sizeof(char *));
	GetLastWeekFromDateAndToDate(LastWeekFromDate,LastWeekToDate);
	printf("LastWeekFromDate: %s\n", LastWeekFromDate);
    printf("LastWeekToDate : %s\n", LastWeekToDate);
	tc_strcat(LastWeekFromDate," 00:00");
	tc_strcat(LastWeekToDate," 23:59");
	
	int PlantIndex = 1;
	
	for (PlantIndex = 1;PlantIndex<6;PlantIndex++)
	{
		char *plantsMBPAStartWith[] = {"", "MJ*", "MP*", "ML*", "MU*", "MD*"};
		char *plantsEPAStartWith[] = {"", "J", "C", "L", "B", "D"};
		char *PlantMBPAStartWith = (char *) MEM_alloc(4 * sizeof(char));
		char *PlantEPAStartWith = (char *) MEM_alloc(1 * sizeof(char));
		tc_strcpy(PlantMBPAStartWith, plantsMBPAStartWith[PlantIndex]);
		tc_strcpy(PlantEPAStartWith, plantsEPAStartWith[PlantIndex]);
		
		
		
		tag_t   Generalqrytag           = NULLTAG;
	    ITK_CALL(QRY_find2("General...", &Generalqrytag));
	    if(Generalqrytag != NULLTAG)
	    {
	    	printf("General query found\n");fflush(stdout);
	    } 
	    else
	    {
	    	printf("General Query not found\n");fflush(stdout);
	    }
        char *attribute[4] = {"Type","Name","Created After","Created Before"};
        char *values[4]; 
        values[0] = "MBPA (NON-EPA)";
        values[1] = PlantMBPAStartWith;
        values[2] = LastWeekFromDate;
        values[3] = LastWeekToDate;
		
		printf("values[0]: %s\n", values[0]);
		printf("values[1]: %s\n", values[1]);
		printf("values[2]: %s\n", values[2]);
		printf("values[3]: %s\n", values[3]);
		
	    int NoOfMBPA = 0;
	    tag_t* MBPASet = NULLTAG;
        ITK_CALL(QRY_execute(Generalqrytag,4,attribute,values,&NoOfMBPA,&MBPASet));
		ProcessMBPASet(NoOfMBPA,MBPASet,PlantIndex,PlantEPAStartWith);
	    
	}
	
   
	
	

   
	
	
	
	return status;
}

