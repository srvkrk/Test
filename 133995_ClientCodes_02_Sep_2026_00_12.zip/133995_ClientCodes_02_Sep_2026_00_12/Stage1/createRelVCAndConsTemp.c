#include<tccore/item.h>
#include<string.h>
#include<tccore/aom_prop.h>
#include<sa/tcfile.h>
#include<ae/dataset.h>
#include<unidefs.h>
#include <ict/ict_userservice.h>
#include <tccore/custom.h>
#include <tccore/tctype.h>
#include <sa/imanfile.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc_arguments.h>
#include <cfm/cfm.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)

#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
int cnt = 0;
int cntFlag = 0;


#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

extern int ITK_user_main( int argc, char **argv )
{
	int     status;
	int     ifail;
	int		length					=	0;
	int		m						=	0;
	int		n_tags_found			=	0;
	int		n_tags_temp_found		=	0;
	int		n_rev					=	0;
	int		iclr					=	0;
	int		iclrrev					=	0;
	int		aplRlzFnd				=	0;

	char	*inputfile				=	NULL;
	char	*line					=	NULL;
	char	*FileName				=	NULL;
	char	*cProject				=	NULL;
	char	*cParttype				=	NULL;
	char	*clrpartNum				=	NULL;
	char	*clr_rev_Id				=	NULL;
	char	*clrPart_Type			=	NULL;
	char	*constempname			=	NULL;


	tag_t	*itemclassp				=	NULLTAG;
	tag_t	*tempclassp				=	NULLTAG;
	tag_t	*clr_revs				=	NULLTAG;

	tag_t	clrpart					=	NULLTAG;
	tag_t	clrpartrev				=	NULLTAG;
	tag_t	constemp				=	NULLTAG;
	tag_t	clr_cons_temp_rel		=	NULLTAG;
	tag_t	Fndrelation				=	NULLTAG;
	tag_t	clr_cons_temp_rel_cre	=	NULLTAG;
	
	FILE	*fpInput;
	FILE	*fpOutput;

	size_t len = 0;
	ssize_t read;

	CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	CALLAPI(ITK_set_journalling( TRUE ));
	CALLAPI(ITK_auto_login( ));
	printf("\nLogin successfully");fflush(stdout);

	FileName	=	(char *)MEM_alloc(200);
	tc_strcpy(FileName,"Consumable_Template_VC1.txt");

	fpOutput	=	fopen(FileName,"a+");

	printf("\n11111111");fflush(stdout);
	const char *attrs[2];//Multiple Item Queried Error Hemal
	const char *values[2];//Multiple Item Queried Error Hemal
	
	const char	*attr_temp[2];
	const char	*values_temp[2];
	//attrs[0] ="t5_ProjectCode";
	//attrs[1] ="t5_PartType";
	attrs[0] ="object_type";
	attrs[1] ="item_id";
	
	char	*cPartNumber	=	NULL;
	cPartNumber	=	(char *)MEM_alloc(50);
	tc_strcpy(cPartNumber,"5442");
	tc_strcat(cPartNumber,"*");
	//tc_strcat(cPartNumber,"PB");
	//tc_strcat(cPartNumber,"*");
	printf("\n222222 cPartNumber :%s",cPartNumber);fflush(stdout);
	values[0] = "T5_ClrPart";
	values[1] = cPartNumber;
	//values[2] = "T5_ClrPart";
	printf("\n333333");fflush(stdout);
	
	ITKCALL(ITEM_find_items_by_key_attributes(2, attrs, values,&n_tags_found, &itemclassp));
	printf("\nNumber of stage assembly found : %d",n_tags_found);fflush(stdout);

	attr_temp[0]	=	"object_type";
	attr_temp[1]	=	"item_id";//T5_ConsumableTmp

	values_temp[0]	=	"T5_ConsumableTmp";
	values_temp[1]	=	"MANZA_DOMESTIC_TEMPLATE";


	ITKCALL(ITEM_find_items_by_key_attributes(2, attr_temp, values_temp,&n_tags_temp_found, &tempclassp));

	if (n_tags_found>0 && n_tags_temp_found > 0)
	{
		ITKCALL(ITEM_ask_latest_rev(tempclassp[0],&constemp));
		ITKCALL(AOM_ask_value_string(constemp,"item_id",&constempname));
		printf("\nconsumable template name : %s",constempname);fflush(stdout);
		if (constemp!=NULLTAG)
		{
			//constemp	=	tempclassp[0];
			for (iclr=0;iclr< n_tags_found ;iclr++ )
			{
				clrpart	=	itemclassp[iclr];
				if (clrpart!=NULLTAG)
				{
					//find revision of part
					ITKCALL(ITEM_list_all_revs(clrpart,&n_rev,&clr_revs));
					if (n_rev>0)
					{
						for (iclrrev=0;iclrrev<n_rev;iclrrev++ )
						{
							clrpartrev	=	clr_revs[iclrrev];
							clrpartNum	=	NULL;
							clr_rev_Id	=	NULL;
							clrPart_Type=	NULL;
							ITKCALL(AOM_ask_value_string(clrpartrev,"item_id",&clrpartNum));
							ITKCALL(AOM_ask_value_string(clrpartrev,"item_revision_id",&clr_rev_Id));
							ITKCALL(AOM_ask_value_string(clrpartrev,"t5_PartType",&clrPart_Type));
							printf("color part number %s, revision : %s, part type : %s",clrpartNum,clr_rev_Id,clrPart_Type);fflush(stdout);
							if (tc_strcmp(clrPart_Type,"VC")==0)
							{
								int	stcount	=	0;
								tag_t	*status_list	=	NULLTAG;

								if (WSOM_ask_release_status_list(clrpartrev,&stcount,&status_list)==ITK_ok);
								printf("\nNumber of release status found : %d",stcount);fflush(stdout);
								if (stcount>0)
								{
									int		ist	=	0;
									aplRlzFnd	=	0;
									char	*class_name	=	NULL;
									for (ist=0;ist<stcount ;ist++ )
									{
										class_name	=	NULL;
										ITKCALL(AOM_ask_value_string(status_list[ist],"object_name",&class_name));
										printf("\n Release status name : %s\n",class_name);fflush(stdout);
										
										if(tc_strcmp(class_name,"T5_LcsAplRlzd")==0)
										{
											aplRlzFnd = 1;
											break;
										}
									}
									//if (aplRlzFnd>0)
									{
										ITKCALL(GRM_find_relation_type("T5_VCConsumableTemplateRel",&clr_cons_temp_rel));
										if (clr_cons_temp_rel!=NULLTAG)
										{
											ITKCALL(GRM_find_relation(clrpartrev,constemp,clr_cons_temp_rel,&Fndrelation));	
											if (Fndrelation==NULLTAG)
											{
												printf("\ncreate relation");fflush(stdout);
												ITKCALL(GRM_create_relation(clrpartrev,constemp,clr_cons_temp_rel,NULLTAG,&clr_cons_temp_rel_cre));
												ITKCALL(GRM_save_relation(clr_cons_temp_rel_cre)); 
												ITKCALL(AOM_refresh(clr_cons_temp_rel_cre,0));
												printf("\nconsumable temaplate Relation Created Successfully\n");fflush(stdout);
												fprintf(fpOutput,"%s,%s,%s,%s,Releation created successfully\n",clrpartNum,clr_rev_Id,clrPart_Type,constempname);fflush(fpOutput);

											}
											printf("\nrelation between clr part %s ad consumable template created : %s",clrpartNum,constempname);fflush(stdout);
										}
										else
										{
											printf("\nclr_cons_temp_rel is not found");fflush(stdout);
										}
									}
//									else
//									{
//										printf("\nAPLC Release not found");fflush(stdout);
//										fprintf(fpOutput,"%s,%s,%s,%s,APLC Release status not found \n",clrpartNum,clr_rev_Id,clrPart_Type,constempname);fflush(fpOutput);
//									}
									
								}
								else
								{
									printf("\nRelease status not found...");fflush(stdout);
									fprintf(fpOutput,"%s,%s,%s,%s,Relase status not found \n",clrpartNum,clr_rev_Id,clrPart_Type,constempname);fflush(fpOutput);
								}
							}
						}
					}
					else
					{
						printf("\nrevs are not found");fflush(stdout);
					}
				}
				else
				{
					printf("\nClr part tag is null");fflush(stdout);
				}
			}
		}
		else
		{
			printf("\nconsumable template revision is nulltag...");fflush(stdout);
		}
	}
	else
	{
		printf("\neither template or color part not found...");fflush(stdout);
	}
	if (fpOutput!=NULL)
	{
		fclose(fpOutput);
	}
	ITKCALL(POM_logout(false));
    return ITK_ok;

}