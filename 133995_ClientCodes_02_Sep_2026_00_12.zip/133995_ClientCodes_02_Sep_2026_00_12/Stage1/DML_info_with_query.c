#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <tc/folder.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <time.h>
#define PLM_error6 (EMH_USER_error_base+26)
#define ITK_err (EMH_USER_error_base + 2)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
;
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	//printf("\n return string found %s ",retStringf);fflush(stdout);
	return retStringf;
}
static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);

    }
	return return_code;
}
void removeNewLineChar(char *ptr)
{
    while((ptr != NULL) && (*ptr != '\n'))
    {
        ++ptr;
    }
    *ptr = '\0';
}
FILE		*VCoutput 			= NULL;
int			ifail 				= ITK_ok;
char		*sep				= "^";
int tm_Part_to_DML_Details(char* filename);

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"GateMaturationUpd -u=<username> -pf=<password file path> -g=<!-- <group> --> -file=<!-- <file_name> -->\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
struct tm stringToDate(char *dateStr) 
{
    struct tm date = {0}; // Initialize to all zeros

    if (sscanf(dateStr, "%d-%d-%d", &date.tm_mday, &date.tm_mon, &date.tm_year) != 3) 
	{
        printf("\n*********Error: Invalid date format. [%s]*********\n",dateStr);
    }

    date.tm_mon -= 1;  // Adjust for zero-based month
    date.tm_year -= 1900;  // Adjust for year starting from 1900
    return date;
}
int countDays(char *startDateStr, char *endDateStr) 
{

		printf("\nInside countdays function.................:\n");fflush(stdout);

    // Convert date strings to struct tm
	//printf("\n\tInside countDays startDateStr:[%s] & endDateStr:[%s]",startDateStr,endDateStr);
    struct tm start_date = stringToDate(startDateStr);
    struct tm end_date = stringToDate(endDateStr);

    // Convert struct tm to time_t
    time_t start_time = mktime(&start_date);
    time_t end_time = mktime(&end_date);

    // Calculate the difference in seconds and convert to days
    int daysDifference = (int)difftime(end_time, start_time) / (24 * 60 * 60);
 // (24 * 60 * 60);


	printf("\n	daysDifference.............:[%d]\n",daysDifference);fflush(stdout);

	printf("\nEnd of countdays function.............:\n");fflush(stdout);


    return abs(daysDifference);  // Absolute value in case dates are in different order
}
void convertDateFormat( char *inputDate, char *outputDate) 
//char convertDateFormat( char *today) 
{
    char *months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
	char * dateoutput = NULL;
    int day, year;
    char month[4];
   printf("\nInside convertDateFormat function:......................\n");fflush(stdout);

    sscanf(inputDate, "%d-%3s-%d", &day, month, &year);
    int monthIndex;
    for (monthIndex = 0; monthIndex < 12; ++monthIndex) 
	{
        if (strcmp(month, months[monthIndex]) == 0) 
		{
            break;
        }
    }

    sprintf(outputDate, "%02d-%02d-%d", day, monthIndex + 1, year);
	printf("\nEnd convertDateFormat function:........................\n");fflush(stdout);
}


int DML_info_with_query(char* FromDate,char* ToDate)
{
	tag_t	  DML_tag		                 		= NULLTAG;
	tag_t	  DmlRev_tag		             	= NULLTAG;
	tag_t    dml_tsk_rel_type        		= NULLTAG;
	tag_t    dml_tsk_rel_type2      		= NULLTAG;
	tag_t     Sec_obj                          		= NULLTAG;
	tag_t     qry_tg                                 = NULLTAG;
	tag_t*   sec_objects                 		= NULLTAG;
	tag_t     WKFL                              		= NULLTAG;
	tag_t     Wtask                             		= NULLTAG;
	tag_t*   WKFLS		                 		    = NULLTAG;
	tag_t*   task_name		                    = NULLTAG;
	tag_t*   DmlObj    		                    = NULLTAG;
	tag_t     obj           		                        = NULLTAG;
	tag_t	    task_tag		                     	= NULLTAG;
	tag_t*	secondary_objects	 		= NULLTAG;

	char*		Obj_name          				= NULL;
	char*		WKFL_name      				= NULL;
	char*		WKFL_Task         				= NULL;
	char*		WKFL_n              				= NULL;
	char*      ObjectType       				= NULL;
	char*      DMLCreation_date    		= NULL;
	char*      DML_last_modify    		= NULL;
	char*      DML_modify_date    		= NULL;
	char*      DML_date_release    		= NULL;
	char*      DML_release_status    	= NULL;
	char*      DML_release_Type     	= NULL;
	char*      DML_Desc                    	= NULL;
	char*      ERCRelzDate     				= NULL;
	char*      Obj_Type           				= NULL;
	char*      itemIdtag           				= NULL;
	char*      Current_Name    				= NULL;
	char*      OutTime             				= NULL;
	char*      InTime                				= NULL;
	char*      Reviwer_name   				= NULL;
	char*      Obj_N                				= NULL;
	char*      task_type                			= NULL;
	char*      task_N                    			= NULL;
	char*      PropertyName 				= NULL;
	char*      Analyst_name        			= NULL;
	char*      Analyst_id             			= NULL;
	//char*      inputline                           = NULL;
	char*      dmlno                                = NULL;
	char*      prtRevSeq                         = NULL;
	char*      inputfile                             = NULL;
	char*      output                                = NULL;
	char*      Rlsts                                    = NULL;
	char*      Decr                                    = NULL;
	char*      NAME                                 = NULL;
	char*      WK_N                                 = NULL;
	char*      CN                                       = NULL;
	 
	int   count        									= 0;
	int   count1      									= 0;
	int   Tcount       									= 0;
	int   T_count    									= 0;
	int   i                  									= 0;
	int   g                  								= 0;
	int   k                 									= 0;
	int   j                  									= 0;
	int   p                  								= 0;
	int   CountQ                                      = 0;
	int  status                                          = ITK_ok;
	char dateString[12];
	char date_string[12];
	
	int diff = 0;
	int diff1 = 0;
	int TotaldaysDifference = 0;
   TotaldaysDifference=MEM_alloc(10);

	char EndDateFor[11] ;
	char StartDateFor[11] ;
	char *entry = (char *) MEM_alloc(30 * sizeof(char *));
	char ** Value = (char **) MEM_alloc(50 * sizeof(char *));

	FILE *flogPtr  = NULL;
	prtRevSeq = (char *)MEM_alloc(10);

	time_t t;
    struct tm *today;
    struct tm *currentDate;
    time(&t);
	today = localtime(&t);

	sprintf(dateString, "%02d-%02d-%d", today->tm_mday, today->tm_mon + 1, today->tm_year + 1900);

    t -= 5 * 24 * 60 * 60;
    today = localtime(&t);
    strftime(date_string, sizeof(date_string), "%d-%m-%Y", today);
   
    printf("\nTodays Date : [%s], And 5 days ago: %s\n",dateString, date_string);

if(QRY_find("ERC DML Revision_2", &qry_tg)); //MAIN CODE
	if(qry_tg != NULLTAG)
{
			
		printf("\n Inside Qry Tag found");
		//entry[0] = "t5_rlstype";
		//entry[1] = "ID";
		//entry[2] = "Date Released";
		//entry[3] = "Date Created";
		//entry[4] = "Name";
		char *entry[5]		 = {"ID","t5_rlstype","Date Released","Date Created","Name"}; //"Release Type"//"t5_rlstype"
		Value[0] = "*";
		Value[1] = "*";
		Value[2] = ToDate;
		Value[3] = FromDate;
		Value[4] = "*";

		if(QRY_execute(qry_tg, 5, entry, Value, &CountQ, &DmlObj));
		printf("\n:CountQ is: [%d]\n",CountQ);fflush(stdout);

		flogPtr=fopen("/user/cvprod/AjinkyaJ/DML_Log/DML_CHECK_Query_REPORT.csv","w");
		fprintf(flogPtr," DML No,DML Description,DML Creation date,Date Modified,Date Released,Release Status,Release Type,WF_names,Current Assignment,Assignment task,Analyst_Name, Analyst_ID,GM DML Review,CVBU DMU Review,Add solution items,Add Items for Gate maturation,\n");


        
    for (g=0;g<CountQ;g++)
	{
		obj=DmlObj[g];

		if(flogPtr==NULL)
	{
		printf("\nError in opening the file flogPtr:\n");fflush(stdout);
		return 1;
	}
	if (obj!=NULLTAG)
	{

		printf("\n**********************Starting here*************************\n");fflush(stdout);



			   printf("\n**********************In whileloop*************************\n");fflush(stdout);
			   
			   ifail=AOM_UIF_ask_value(obj,"item_id",&itemIdtag);
			   printf("\n :item id : %s\n ",itemIdtag);fflush(stdout);

		      if(tc_strstr(itemIdtag,"_MBOM")!=NULL ||tc_strstr(itemIdtag,"_APLJ")!=NULL ||tc_strstr(itemIdtag,"_APLP")!=NULL ||tc_strstr(itemIdtag,"_STDL")!=NULL)//_APLP //_STDL
		       {
		       tc_strtok(itemIdtag,"_MBOM");
		       printf("\n :DML without _MBOM. : %s\n ",itemIdtag);fflush(stdout);
		       }
			      
			   ifail=AOM_UIF_ask_value(obj,"current_desc",&DML_Desc);
			   ifail=STRNG_replace_str(DML_Desc,","," / ",&Decr);
			   printf("\n :DML Description: %s\n ",DML_Desc);fflush(stdout);
			   
			   ifail=AOM_UIF_ask_value(obj,"creation_date",&DMLCreation_date);
			   printf("\n :DML Creation date : %s\n ",DMLCreation_date);fflush(stdout);
			   
			   //ifail=AOM_UIF_ask_value(obj,"last_mod_user",&DML_last_modify);
			   //printf("\n :Last Modifying User: %s\n ",DML_last_modify);fflush(stdout);
			   
			   ifail=AOM_UIF_ask_value(obj,"last_mod_date",&DML_modify_date);
			   printf("\n :Date Modified: %s\n ",DML_modify_date);fflush(stdout);
			   
			   ifail=AOM_UIF_ask_value(obj,"date_released",&DML_date_release);
			   printf("\n :Date Released: %s\n ",DML_date_release);fflush(stdout);
			   
			   ifail=AOM_UIF_ask_value(obj,"release_status_list",&DML_release_status);
			   ifail=STRNG_replace_str(DML_release_status,","," / ",&Rlsts);
			   printf("\n :Release Status: %s\n ",DML_release_status);fflush(stdout);

			   ifail=AOM_UIF_ask_value(obj,"t5_rlstype",&DML_release_Type);
			   printf("\n :Release Type: %s\n ",DML_release_Type);fflush(stdout);
			   
			   ifail=AOM_UIF_ask_value(obj,"fnd0AllWorkflows",&WKFL_n);
			   ifail=STRNG_replace_str(WKFL_n,","," / ",&output);
			   printf("\n WF_names :%s \n",WKFL_n);fflush(stdout);
			   
			   ifail=AOM_UIF_ask_value(obj,"process_stage_list",&WKFL_name);
			   ifail=STRNG_replace_str(WKFL_name,","," / ",&WK_N);
			   printf("\n Current Assignment :%s \n",WKFL_name);fflush(stdout);

			   if(tc_strcmp(DML_release_status,"In Designer Working")==0)
		{
			   
//			   ifail = GRM_find_relation_type ( "T5_DMLTaskRelation",&dml_tsk_rel_type );
//			   ifail = GRM_list_secondary_objects_only(obj,dml_tsk_rel_type,&Tcount,&secondary_objects);
//			   printf("\n rev: Tcount:%d",Tcount);fflush(stdout);

			   ifail = GRM_find_relation_type ( "T5_DMLTaskRelation",&dml_tsk_rel_type2);
			   ifail = GRM_list_secondary_objects_only(obj,dml_tsk_rel_type2,&T_count,&sec_objects);
			   printf("\n Total task count :%d \n",T_count);fflush(stdout);

				if(T_count > 0)
				   {

					printf("\n inside  T_count condition............................................................................ \n");fflush(stdout);


					for (i=0; i< T_count; i++)
					{
							printf("\n inside  For condition........................................................ \n");fflush(stdout);

					task_tag=sec_objects[i];

					ifail=AOM_UIF_ask_value(task_tag,"object_type",&ObjectType);
					printf("\n :ObjectType : %s\n ",ObjectType);fflush(stdout);							
					
//					if (tc_strcmp(ObjectType,"ERC Task Revision")==0)
//					{
//					
//					 ifail=AOM_UIF_ask_value(task_tag,"date_released",&ERCRelzDate);
//					 printf("\n Realeased Date is :%s \n",ERCRelzDate);fflush(stdout);
//												  
//					}
//					else
//					{
//						tc_strcpy(ERCRelzDate , "-");
//					}


								   printf("\n********Proccess history Loading**********\n");
								   
								   ifail=AOM_ask_value_tags(task_tag,"fnd0ActuatedInteractiveTsks",&count,&WKFLS);
								   printf("\n count :%d \n",count);fflush(stdout);


								   							   
								   ifail=AOM_UIF_ask_value(task_tag,"cm0Analyst",&Analyst_name);
								   printf("Analyst_Name is : %s\n",Analyst_name);fflush(stdout);	
								   
								   ifail=AOM_UIF_ask_value(task_tag,"analyst_user_id",&Analyst_id);
								   printf("Analyst_ID is : %s\n",Analyst_id);fflush(stdout);	
									 
								   if(count>0)
									{
											 for(j=0;j<count;j++)
											   {
											   
													printf("----\n");
													WKFL=WKFLS[j];
											   
													ifail=AOM_UIF_ask_value(WKFL,"fnd0ActuatedInteractiveTsks",&Current_Name);
													ifail=STRNG_replace_str(Current_Name,","," / ",&CN);
													printf("Assignment task is : %s\n",Current_Name);fflush(stdout);

													if (tc_strstr(DML_release_status,"Submit For ECN")!=NULL || tc_strstr(DML_release_status,"MBOM Working")!=NULL || tc_strstr(DML_release_status,"MBOM Released")!=NULL || tc_strstr(DML_release_status,"STDSIU Released")!=NULL || tc_strstr(DML_release_status,"APLL Released")!=NULL )
												   {

														printf("Contact to APL team is : \n");fflush(stdout);

												   }
												   else
													{

											   
													ifail=AOM_ask_value_tags(WKFL,"fnd0ActuatedInteractiveTsks",&count1,&task_name);
													printf("\n count1 :%d \n",count1);fflush(stdout);

													 if (tc_strstr(DML_release_status,"ERC Released")!=NULL) 
													 {
																printf("ERC released hence skipping...... \n");fflush(stdout);

													 }
											   
													if(tc_strstr(Current_Name,"CVBU DMU Review")!=NULL || tc_strstr(Current_Name,"GM DML Review")!=NULL || tc_strstr(Current_Name,"dummy task")!=NULL) //|| tc_strstr(Current_Name,"Add Items for Gate maturation")!=NULL
													{
												
									                  			ifail=AOM_UIF_ask_value(WKFL,"fnd0StartDate",&InTime);
									                  			printf("In Time is : %s\n",InTime);fflush(stdout);	
									                  			convertDateFormat(InTime, StartDateFor);
																printf("StartDateFor is : %d\n",StartDateFor);fflush(stdout);
																printf("StartDateFor is : %s\n",StartDateFor);fflush(stdout);
									                  
									                  		    ifail=AOM_UIF_ask_value(WKFL,"fnd0EndDate",&OutTime);
									                  	     	printf("Out Time is : %s\n",OutTime);fflush(stdout);
									                  			convertDateFormat(OutTime,  EndDateFor);
																printf("EndDateFor is : %d\n",EndDateFor);fflush(stdout);
																printf("EndDateFor is : %s\n",EndDateFor);fflush(stdout);

									                  			diff = countDays(StartDateFor,dateString);
									                  		   printf("diffarence : %d\n",diff);fflush(stdout);

															   	diff1 = countDays(EndDateFor,date_string);
																printf("diffarence : %d\n",diff1);fflush(stdout);

                                                               TotaldaysDifference = countDays(EndDateFor,StartDateFor);

														
																printf("TotaldaysDifference : %d\n",TotaldaysDifference);fflush(stdout);
									                  
									                  			if(tc_strcmp(InTime,"")==0||tc_strcmp(OutTime,"")==0)
									                  			{
									                  				 printf("Skipping time is not found :\n");fflush(stdout);
									                  
									                  			}
													}
			                                     // else
			                                     // {
			                                     //		fprintf(flogPtr,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d\n",inputline,Decr,DMLCreation_date,DML_modify_date,DML_date_release,Rlsts,DML_release_Type,output,WK_N,CN,Analyst_name,Analyst_id,diff);
			                                     // }
											   }//ECN else condition

													}
													
											   }


									


				   }//

				   }

		}


	fprintf(flogPtr,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d\n",itemIdtag,Decr,DMLCreation_date,DML_modify_date,DML_date_release,Rlsts,DML_release_Type,output,WK_N,CN,Analyst_name,Analyst_id,TotaldaysDifference,TotaldaysDifference,TotaldaysDifference);

						
				   }


	              }  

	   }
	   fclose(flogPtr);

   // }
//	else
//	{
//	   printf("\n*************************File not opned***************************\n");
//	}	

 return status;
}
			


int ITK_user_main(int argc, char *argv[])
{
	char			* dml				    = NULL;
	char			* obj				    = NULL;
	char			* password	   	= NULL;
	char			* group				 = NULL;
	char            *inputfile           = NULL;
	char			* FromDate	     = NULL;
	char			* ToDate		     = NULL;

	//inputfile = ITK_ask_cli_argument("-f=");
	FromDate = ITK_ask_cli_argument("-From=");
	ToDate = ITK_ask_cli_argument("-To=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);


	ifail = ITK_auto_login();
	//fail = ITK_init_module(userid, password, group);
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);

	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nhey Login Successfull.....!!\n");fflush(stdout);
		printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
	}
	//printf("\nOutput file name : %s",VCoutputFile);fflush(stdout);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");fflush(stdout);
		return -1;
	}
	printf("\n inputfile no: [%s]\n",obj);fflush(stdout);
	ifail=DML_info_with_query(FromDate,ToDate);
	CHECK_FAIL;


	printf("\n**********************");
	printf("\n****End of program****!!");
	printf("\n*********************\n");
	//ifail = ITK_exit_module(true);

	return ifail;

}
