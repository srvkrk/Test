/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author                :   Prasad Sagare
*  Module                :   TCUA DCR VLD Mail Intiate ITK
*  Code                  :   UpadateUOMt5UQDup.c
*  Created on			 :   24th Mar 2021
*
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/
#define TE_MAXLINELEN  128
#include <ae/dataset.h>

#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <epm/epm.h>
#include <Fnd0Participant/participant.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define Debug TRUE
#define ITK_CALL(X)                                                     \
                if(Debug)                                                               \
                {                                                                               \
                        printf(#X);                                                     \
                }                                                                               \
                fflush(NULL);                                                   \
                status=X;                                                               \
                if (status != ITK_ok )                                  \
                {                                                                               \
                        int                             index = 0;                      \
                        int                             n_ifails = 0;           \
                        const int*              severities = 0;         \
                        const int*              ifails = 0;                     \
                        const char**    texts = NULL;           \
                                                                                                \
                        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                        printf("\t%3d error(s)\n", n_ifails);                                                   \
                        for( index=0; index<n_ifails; index++)                                                  \
                        {                                                                                                                               \
                                printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                        }                                                                                                                               \
                        return status;                                                                                                  \
                }                                                                                                                                       \
                else                                                                    \
                {                                                                               \
                        if(Debug)                                                       \
                        printf("\tSUCCESS\n");                          \
                }                                                                               \

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
        printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
    }
    return ITK_ok;
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}


int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dcr						= NULL;

	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	dcr				= ITK_ask_cli_argument("-dcr=");

	ifail = ITK_auto_login();

	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}


	printf("\nBefor CM_DCR_MailApproval call \n\n");

	ifail = CM_DCR_MailApproval(dcr);

	printf("\nEnd of program.....!!\n\n");
	printf("\n*****************************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


int CM_DCR_MailApproval(char* DCR_No)
{
	int i=0;
	int j=0;
	int status=ITK_ok;
	int attachmentCount=0, transfermodeCnt=0;

	char *obj_type=NULL;
	char *dmlNumber=NULL;
	char *emailID=NULL;
	char *revId=NULL;
	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;

	//char mainFile[50];
	char command[512];
	char docFile[50];
	char *emailIDstr= NULL;
	int participant_count	= 0;
	tag_t DCR_tag=NULLTAG;
	tag_t rootTask_t=NULLTAG;
	tag_t msWordType=NULLTAG;
	tag_t person_tag=NULLTAG;
	tag_t wordDataset=NULLTAG;
	tag_t wordLatestDat_t=NULLTAG;
	tag_t specRelationType_t=NULLTAG;
	tag_t specificationRel_t=NULLTAG;
	tag_t PLMSession=NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t	Patricipant_Type	= NULLTAG;
	char*   ObjTyp= NULL;
	tag_t *transfermodes=NULLTAG;
	tag_t	*participant_list	= NULLTAG;
	emailIDstr =  (char*) malloc(500);

	//ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	//ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
	
	ITEM_find_item(DCR_No,&DCR_tag);
	printf("\nDCR task found\n\n");
	ITEM_ask_latest_rev(DCR_tag,&objTag);

	EPM_get_participanttype ("T5_DcrVEH_LINE_DIR",&Patricipant_Type);

	//if(attachmentCount>0)
	//{
		tc_strcpy(emailIDstr,"");
		printf("\n CM_DCR_MailApproval: Root Task Count is [%d]\n",attachmentCount);fflush(stdout);
		//for(j=0;j<attachmentCount;j++)
		//{
			//objTag=taskAttachments[j];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			printf("\n CM_DCR_MailApproval: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			//if(AOM_ask_value_string(objTag,"item_id",&DCR)!=ITK_ok)PrintErrorStack();
			//printf("\n DCR OBJ ID: [%s].", DCR);fflush(stdout);

			//CALLAPI(GRM_find_relation_type("HasParticipant", &DCR_Particpant_rel_type));
			//CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &DCR_rel_type));
			
			if ((tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0))
			{
				printf("\n CM_DCR_MailApproval: DCR Revision obj Found.\n");fflush(stdout);
				PARTICIPANT_ask_participants(objTag,Patricipant_Type,&participant_count,&participant_list);
				printf("\n Number Of participant_count==>[%d]",participant_count);fflush(stdout);
				ITK_CALL(GRM_find_relation_type("IMAN_specification",&specRelationType_t));

				ITK_CALL(AOM_ask_value_string(objTag,"item_id",&dmlNumber));
				ITK_CALL(AOM_ask_value_string(objTag,"item_revision_id",&revId));

				for(i=0;i<participant_count;i++)
				{
					//ITK_CALL(WSOM_ask_object_type2(participant_list[0],&obj_type));
					//TC_write_syslog("Object Type = %s\n",obj_type);
					//if(tc_strcasecmp(obj_type,"ChangeRequestRevision")==0)
					//{
					ITK_CALL(AOM_ask_value_string(participant_list[i],"fnd0AssigneeEmail",&emailID));
					printf("%d > Found User Mail ID is [%s]\n",i+1,emailID);fflush(stdout);
					tc_strcat(emailIDstr,emailID);
					printf("\t\t emailIDstr is [%s] & emailID is [%s]\n",emailIDstr,emailID);fflush(stdout);
					tc_strcat(emailIDstr," ");
					printf("Mail ID =====",emailIDstr);fflush(stdout);
					//ITK_CALL(SA_ask_user_person(participant_list[0],&person_tag));
					//ITK_CALL(SA_ask_person_email_address(person_tag,&emailID));
					//tc_strcpy(mainFile,"");
					//tc_strcat(mainFile,"/tmp/");
					//tc_strcat(mainFile,dmlNumber);
					//tc_strcat(mainFile,"_");
					//tc_strcat(mainFile,revId);
					//tc_strcat(mainFile,".xml");
					//TC_write_syslog("Main File = %s\n",mainFile);
					//tc_strcpy(docFile,"");
					//tc_strcat(docFile,"/tmp/dmlprint_report_");
					//tc_strcat(docFile,dmlNumber);
					//tc_strcat(docFile,"_");
					//tc_strcat(docFile,revId);
					//tc_strcat(docFile,".doc");
					//TC_write_syslog("Doc File = %s\n",docFile);
					//ITK_CALL(PIE_create_session(&PLMSession));
					//ITK_CALL(PIE_session_set_file(PLMSession,mainFile));
					//ITK_CALL(PIE_find_transfer_mode2("T5_DML_Print_Report_TM","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
					//TC_write_syslog("No of TrasnferModes = %d\n",transfermodeCnt);
					//ITK_CALL(PIE_session_set_transfer_mode(PLMSession,transfermodes[0]));
					//ITK_CALL(PIE_session_export_objects(PLMSession,1,&taskAttachments[i]));
					//sprintf(command,"java -classpath /home/uadev/TC_ROOT/bin/tml_tools/xalan.jar org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadev/TC_ROOT/bin/tml_tools/DML_print_report_template.xsl >/tmp/wfout.log",mainFile,dmlNumber);
					//sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/DCR_approval_Mail.sh %s %s",dmlNumber,emailID);
					//TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					//system(command);
					//if(access(docFile,F_OK)!=-1)
					//{
						//TC_write_syslog("Doc file created successfully\n");
						//ITK_CALL(AE_find_datasettype2("MSWord",&msWordType));
						//if(msWordType == NULLTAG)
						//{
							//TC_write_syslog("Could not find Dataset Type MSWord. Please check data model\n");
							//continue;
						//}
						//ITK_CALL(AE_create_dataset_with_id(msWordType,dmlNumber,"DML Print Report for DML","","",&wordDataset));
						//ITK_CALL(AE_save_myself(wordDataset));
						//ITK_CALL(GRM_create_relation(taskAttachments[i],wordDataset,specRelationType_t,NULLTAG,&specificationRel_t));
						//ITK_CALL(AOM_load(specificationRel_t));
						//ITK_CALL(GRM_save_relation(specificationRel_t));
						//ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
						//ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
						//ITK_CALL(AE_import_named_ref(wordLatestDat_t,"word",docFile,NULL,SS_BINARY));
						//ITK_CALL(AE_save_myself(wordLatestDat_t));
						//remove(docFile);
						//}		}
				}
				printf("Found User Mail ID are [%s]\n",emailIDstr);fflush(stdout);
				sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/DCR_approval_Mail.sh %s %s",dmlNumber,emailIDstr);
				TC_write_syslog("Command = %s\n",command);
				system(command);
				//break;
			}
		//}
	//}

	return status;
}


