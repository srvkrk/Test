/*
./compile MIS_VC_DateWise_Rep.c
./linkitk -o MIS_VC_DateWise_Rep MIS_VC_DateWise_Rep.o
scp MIS_VC_DateWise_Rep tkr06466@172.22.97.12:/user/plmsap/PLMSAP/tkr/clientcode/MIS_VC_DateWise_Rep
nohup ./MIS_VC_DateWise_Rep -u=tkr06466 -p=XYT1ESA -fromdate="01-Mar-2022" -todate="20-Mar-2022" -type='M' >1.log &
*/
#define TE_MAXLINELEN  128

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include <unidefs.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <stdarg.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <time.h>
#include <sa/am.h>
#define Debug TRUE
#define ITK_err 910001

int DFQApplCntflag=0;
int falseflagg=0;
int DFQpdfCount=0;
int DFQexcelsCount=0;
int MeetexpectationCnt=0;

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))



static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		//printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			//printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %s",len,text,str);fflush(stdout);
  return;
}




void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}



char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}



extern int ITK_user_main(int argc, char ** argv )
{
	int status				= ITK_ok;
     char*partnum=NULL;
     char*gcinam=NULL;
     char*VehicleNo=NULL;
	 char*Rev=NULL;
     char*Seq=NULL;
     char*UID_Vaule=NULL;
     char*UID_value_master=NULL;
	 partnum	=(char *) MEM_alloc(sizeof(char)* 50);
	 VehicleNo	=(char *) MEM_alloc(sizeof(char)* 50);
	 Seq	=(char *) MEM_alloc(sizeof(char)* 50);
	 Rev	=(char *) MEM_alloc(sizeof(char)* 50);
	 //VehicleDR	=(char *) MEM_alloc(sizeof(char)* 50);
	 gcinam	=(char *) MEM_alloc(sizeof(char)* 50);
	  char*rev_id=NULL;
	 rev_id	=(char *) MEM_alloc(sizeof(char)* 50);
	 char*DvloName=NULL;
	 DvloName	=(char *) MEM_alloc(sizeof(char)* 50);


	tag_t view_bom_tag			 = NULLTAG;
	 tag_t VechRevTag		 = NULLTAG;
	 tag_t*GciObj=NULLTAG;
	 tag_t*Master_tag=NULLTAG;
	 tag_t *view_tag=NULLTAG;
	 tag_t Vechtag=NULLTAG;
	 tag_t relType=NULLTAG;
	 tag_t relTypeTag=NULLTAG;
	 int gcicnt=0;
	 int gci=0;

	 
	char*	VcNumber		=NULL;
	char*	VcNumber1		=NULL;
	char*	DVLODsetID	=NULL;
	char*	UID_Vaule1		=NULL;
	char*	Current_name		=NULL;

	int DemeritScore=0;
	int d=0;
	int count=0;
	int result_count=0;

	FILE*fptr=NULL;

	tag_t class_id=NULLTAG; 
char*class_name=NULL;
	
char*UID	=	NULL;
			UID	=	(char	*)MEM_alloc(sizeof(char)*200);
	//GCIStr= (char *) MEM_alloc(sizeof(char)* 10);

    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login());
	ITK_CALL(ITK_set_journalling( TRUE ));
	partnum = ITK_ask_cli_argument("-part=");
	Rev = ITK_ask_cli_argument("-rev=");
	Seq = ITK_ask_cli_argument("-seq=");

printf("\n part--Input: [%s] [%s] [%s]  ",partnum,Rev,Seq);fflush(stdout);

  tc_strcpy(UID,"");
  tc_strcat(UID, "/tmp/");
  tc_strcat(UID,partnum);

  tc_strcat(UID,"_UID.txt");
   fptr=fopen(UID,"w");

        if(fptr!=NULL)
	   {
		     printf("\n file is opening\n");   fflush(stdout);	
	   }
		else
	   {
		printf("\n file is not opening\n");   fflush(stdout);	
	   }

//fprintf(fptr,"Part Number,UID \n");

if(partnum && Rev && Seq )
{

        tc_strcpy(rev_id,"");
		tc_strcat(rev_id,Rev);
		tc_strcat(rev_id,";");
		tc_strcat(rev_id,Seq);

        printf("\n Rev Input: [%s]  ",rev_id);fflush(stdout);


        ITEM_find_item(partnum,&Vechtag);

		if(Vechtag != NULLTAG)
	    {
         ITEM_find_revision(Vechtag,rev_id,&VechRevTag);

           if(VechRevTag != NULLTAG)
		   {
                AOM_ask_value_string(VechRevTag,"item_id",&VcNumber1);
				printf("Item ID****1111 :: %s\n",VcNumber1);fflush(stdout);


				ITK__convert_tag_to_uid(VechRevTag,&UID_Vaule);

				 printf("\n UID value: [%s]  ",UID_Vaule);fflush(stdout);

				 fprintf(fptr,"%s\n",UID_Vaule);

				 GRM_find_relation_type("IMAN_master_form_rev",&relTypeTag);

				//Get Attached form
				ITK_CALL(GRM_list_secondary_objects_only(VechRevTag, relTypeTag, &result_count,&Master_tag));
				printf("\n No of Attached master form are :: %d\n",result_count);fflush(stdout);

				if(result_count>0)
			    {
					for (d=0;d<result_count; d++ )
					{
					  AOM_ask_value_string(Master_tag[d],"current_name",&Current_name);

					  ITK_CALL(POM_class_of_instance(Master_tag[d],&class_id));
                      ITK_CALL(POM_name_of_class(class_id,&class_name));

					  printf("\n\nObject Classname:%s\n",class_name);fflush(stdout);
                      
					    if((tc_strstr(Current_name,rev_id)!=NULL) && (tc_strcmp(class_name,"Form")==0))
						{

                           ITK__convert_tag_to_uid(Master_tag[d],&UID_value_master);
				           printf("\n UID value1*****: [%s] [%s] ",Current_name,UID_value_master);fflush(stdout);
				           fprintf(fptr,"%s\n",UID_value_master);

							break;

						}
                    }
			   }

                 ITEM_rev_list_all_bom_view_revs(VechRevTag, &count, &view_tag);

				 printf("\n count****: [%d]  ",count);fflush(stdout);

				 if(count >0)
				 {

					printf("\n inside the count  \n");fflush(stdout);

                    view_bom_tag=view_tag[0];

					AOM_ask_value_string(view_bom_tag,"current_name",&VcNumber);
				    printf("Item ID**** :: %s\n",VcNumber);fflush(stdout);

					ITK__convert_tag_to_uid(view_bom_tag,&UID_Vaule1);

					printf("\n UID value1: [%s]  ",UID_Vaule1);fflush(stdout);

					fprintf(fptr,"%s\n",UID_Vaule1);



                 }



			   }
			   fclose(fptr);





           
		   
		    

	       }
		    printf("\n Rev Input:********");fflush(stdout);

               


	   }
		 
       

	CLEANUP:
	ITK_CALL(POM_logout(false));
	return status;
	printf("\nCLEANUP...\n"); fflush(stdout);
}
