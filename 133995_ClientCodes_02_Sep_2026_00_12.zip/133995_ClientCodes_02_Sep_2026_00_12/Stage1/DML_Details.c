/********************************************************************************************************************************
* File                         : DML_Details.c
* Created By                   : Pruthviraj Shinde & Shrivardhan Patil
* Created On                   : 10/08/2013
* Project                      : Tata Motors PLM 4D Doc.
* Methods Defined              :
* Description                  : 
* Specific Notes               :
************************************************************************************************************************************/
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#include "DML_Details.nsmap"	/* get the gSOAP-generated namespace bindings */
#include "soapH.h"					/* get the gSOAP-generated definitions */
#include <ae/ae.h>                  /* for dataset id and rev */
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <ae/dataset_msg.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <constants/constants.h>
#include <ecm/ecm.h>
#include <epm/epm.h> 
#include <epm/epm_task_template_itk.h>
#include <fclasses/tc_string.h>
#include <form/form.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <pom/enq/enq.h>
#include <pom/pom/pom.h>
#include <property/prop.h>
#include <property/prop_errors.h>
#include <property/prop_msg.h>
#include <ps/ps.h>
#include <publication/dist_user_exits.h> 
#include <qry/qry.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <sa/groupmember.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/site.h> 
#include <sa/tcfile.h>
#include <sa/user.h>
#include <setjmp.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <tc/emh.h>
//#include <tc/emh_const.h>
#include <tc/folder.h>
//#include <tc/iman.h>
#include <tc/preferences.h>
//#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/method.h>
#include <tccore/tc_msg.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <tie/tie_errors.h>
#include <time.h>
#include <ug_va_copy.h>
#include <unidefs.h>
#include <user_exits/epm_toolkit_utils.h>
#include <user_exits/user_exit_msg.h>
#include <user_exits/user_exits.h>



#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}


int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new()); /* call the request dispatcher */
};




int ns__DML_Details(struct soap* soap,char *DmlNumber,struct ns__CharArray *aString)
{

	int status = ITK_ok;
	int Dmlcount;
	int DmlRevcount;
	int TaskRevcount;
	int PartCnt;
	int i  = 0;
	int j  = 0;
	int k  = 0;
	int l  = 0;
	int Tskcount;
	int Apl_tskc  = 0;
	int count     = 0;
	int Item_count     = 0;
	int d =0;

	char*	ObjectName			= NULL;
	char*	Dml_type			= NULL;
	char*	PlantDmlTag_Type	= NULL;
	char*	CreationDate		= NULL;
	char*	RelDate				= NULL;
	char*	Part_no				= NULL;
	char*   Dml_Name			= NULL;
	char*   DmlRev_Name			= NULL;
	char*   Task_RevName		= NULL;
	char*   TaskRev_Name		= NULL;
	char*   type_name			= NULL;
	char*	TaskTypeName		= NULL;
	char*	Dml_sequence		= NULL;
	char*   Dml_TypeSet			= NULL;
	char*   DesignGroup_Name    = NULL;
	char*   DesignGroup         = NULL;
	char*   LifeCycleState_Name = NULL;
	char*   DRStatus            = NULL;
	char*   ERCWBSid            = NULL;
	char*   ReasonVal           = NULL;
	char*   DesignGroupAll      = NULL;
	char*   DCRNo               = NULL;
	char*   ReleaseNotes1       = NULL;
	char*   ReleaseNotes2		= NULL;
	char*   ReleaseNotes3		= NULL;
	char*   ReleaseNotes4		= NULL;
	char*   ReleaseNotes5		= NULL;
	char*   ReleaseNotes6		= NULL;
	char*   ReleaseNotes7		= NULL;
	char*   ReleaseNotes8		= NULL;
	char*   ReleaseNotes9		= NULL;
	char*   ReleaseNotes10		= NULL;
	char*   ReleaseNotes11		= NULL;
	char*   ReleaseNotes12		= NULL;
	char*   ReleaseNotes13		= NULL;
	char*   ReleaseNotes14		= NULL;
	char*   ReleaseNotes15		= NULL;
	char*   PlantDml_release_status  = NULL;
	char*   ReleaseTypeSet      = NULL;
	char*   dmlNo               = NULL;
	char*   dmlid               = NULL;
	char*   revision            = NULL;
	char*   seq					= NULL;
	char*   PlantDmlidrevision  = NULL;
	char*   synopsis            = NULL;
	char*   ReleaseType         = NULL;
	char*   Reason              = NULL;
	char*   ReasonValDup        = NULL;
	char*   PlantDmlid          = NULL;
	char*   DesgGrp             = NULL;
	char*   DesgGrpAll          = NULL;
	char*   s;
	char*   PlantObj_type       = NULL;

	char**  qry_values          = NULL;
	char*   qry_entry[1]  = {"ID"};
	qry_values = (char **) MEM_alloc(100 * sizeof(char *));


	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/dml.txt", "a", stdout);


	tag_t   query			 = NULLTAG;
	tag_t	DMLTag			 = NULLTAG;
	tag_t	DMLRevTag		 = NULLTAG;
	tag_t	AssyTag			 = NULLTAG;
	tag_t	relation_type	 = NULLTAG;
	tag_t	TaskRevTag		 = NULLTAG;
	tag_t	TaskTag			 = NULLTAG;
	tag_t	TaskRevTag1		 = NULLTAG;
	tag_t   dml_tsk_rel_type = NULLTAG;
	tag_t   PlantDmlTag	     = NULLTAG;
	//char**   ErcDmlPtr	     = NULLTAG;
	tag_t   ErcDmlPtr	     = NULLTAG;
	tag_t   ERCDml	         = NULLTAG;
	tag_t   dmlidTag	     = NULL;
	tag_t   dmllatRevTag	     = NULL;


	tag_t*	soResult		 = NULLTAG;
	tag_t*	DML_List		 = NULLTAG;
	tag_t*	PartTags  		 = NULLTAG;
	tag_t*	DmlRevision		 = NULLTAG;
	tag_t*	TaskList	     = NULLTAG;
	tag_t*	APLTskRevision	 = NULLTAG;
	tag_t*	PlantDml	     = NULLTAG;
	tag_t*  ERCDmlrev	     = NULLTAG;

	tag_t  ErcTag1	           = NULLTAG;
	char*   dmlid1               = NULL;
	tag_t   dmlidTag1	     = NULL;
	tag_t   dmllatRevTag1	     = NULL;

	//**************************For Auto Login**************************//

		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		ITK_CALL(ITK_auto_login());
		ITK_set_bypass(true);

		ITK_CALL(ITK_set_journalling(TRUE));
		if (status == 0 )
		{
		  printf("\n Auto login to Teamcenter successful \n");fflush(stdout);
		}
		else
		{
		  printf("\n Error code:%d",status);fflush(stdout);
		  EMH_ask_error_text(status,&s);
		  printf("\n Error message:%s",s);fflush(stdout);
		}

	//**************************Ended**************************//


	printf("\n\n ******* DML_Details ***** \n");fflush(stdout);

	if(QRY_find2("ERC DML Revision",&query));
	{
		if (query)
		{
			qry_values[0] = (char *)MEM_alloc( strlen( DmlNumber ) + 1);
		    tc_strcpy(qry_values[0], DmlNumber  );

			ITK_CALL(QRY_execute(query, 1, qry_entry, qry_values, &Dmlcount, &soResult));

			d=Dmlcount;
	        aString->__size = d;

	        //return_->__partPtr = malloc( (return_->__size + 1) * sizeof(*return_->__partPtr) );
	        aString->__ptr = malloc( (aString->__size + 1) * sizeof(*aString->__ptr) );

			//for (i = 0; i < Dmlcount; i++)
			//{

				 dmllatRevTag =  soResult[0];

				if (dmllatRevTag)
				{

					ITK_CALL(AOM_UIF_ask_value(dmllatRevTag,"current_id",&dmlid));
					printf("\n\n\t\t DML id ==> %s",dmlid);fflush(stdout);    

					ITK_CALL(ITEM_find_item(dmlid, &dmlidTag));
					ITK_CALL(ITEM_ask_latest_rev(dmlidTag,&ErcDmlPtr));

					ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr,"item_id",&dmlNo));
					printf("\n\n\t\t DML No ==> %s",dmlNo);fflush(stdout);     

					ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr, "item_revision_id", &revision));
					printf("\n\n\t\t revision ==> %s",revision);fflush(stdout); 

					ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr, "sequence_id", &seq));
					printf("\n\n\t\t sequence ==> %s",seq);fflush(stdout);       

					ITK_CALL(AOM_ask_value_string(ErcDmlPtr, "object_name", &synopsis));
				    printf("\n\n\t\t Synopsis ==> %s",synopsis);fflush(stdout);

					ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr,"t5_cDRstatus",&DRStatus));
					if(tc_strcmp(DRStatus,"NULL")!=0 && tc_strcmp(DRStatus," ")!=0 && tc_strcmp(DRStatus,"")!=0)
					{
						printf("\n\n\t\t DR Status ==> %s",DRStatus);fflush(stdout);
					}
					else
					{
						printf("\n\n\t\t DRStatus Not Found ");fflush(stdout);
					}


					//ITK_CALL(AOM_ask_value_string(ErcDmlPtr, "t5_rlstype", &ReleaseType));
					//printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					//ITK_CALL(AOM_ask_value_string(ErcDmlPtr, "t5_reason", &Reason));
					//printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);


					if(ErcDmlPtr)
					{

						ITK_CALL(AOM_ask_value_string(ErcDmlPtr, "t5_rlstype", &ReleaseTypeSet));
						printf("\n\n\t\t ReleaseTypeSet ----> %s",ReleaseTypeSet);fflush(stdout);

						ReleaseType = NULL;
						ReleaseType = malloc(100);
						strcpy(ReleaseType,"");

						if(tc_strcmp(ReleaseTypeSet,"Veh")==0)
						{
						     tc_strcat(ReleaseType,"Vehicle Release");
						     printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

						}
						else if(tc_strcmp(ReleaseTypeSet,"TPL")==0)
						{
						     tc_strcat(ReleaseType,"Technical Part List");
						     printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

						}
						else if(tc_strcmp(ReleaseTypeSet,"CQ")==0)
						{
							 tc_strcat(ReleaseType,"Change Quantity");
							 printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

						}
					    else if(tc_strcmp(ReleaseTypeSet,"DL")==0)
					    {
					         tc_strcat(ReleaseType,"Deviation List");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"PR")==0)
					    {
							 tc_strcat(ReleaseType,"Prototype Release");
							 printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"KSP")==0)
					    {
					         tc_strcpy(ReleaseType,"Kit and Spare Part Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"TODR")==0)
					    {
					         tc_strcat(ReleaseType,"Gate Maturation");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"SP")==0)
					    {
					         tc_strcat(ReleaseType,"Standard Part Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"VOD")==0)
					    {
					         tc_strcat(ReleaseType,"Vehicle Offer/Pass off norms Drawing");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"CP")==0)
					    {
					         tc_strcat(ReleaseTypeSet,"Colour Part Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseTypeSet);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"CM")==0)
					    {
					         tc_strcat(ReleaseType,"Colour Modification Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"TS")==0)
					    {
					         tc_strcat(ReleaseType,"Tech Spec Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"WT")==0)
					    {
					         tc_strcat(ReleaseType,"Withdraw TPL");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"TSKR")==0)
					    {
					         tc_strcat(ReleaseType,"TPL/Module with Spare Kit Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"EP")==0)
					    {
							 tc_strcat(ReleaseType,"ECU Parts Release");
							 printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    } 
					    else if(tc_strcmp(ReleaseTypeSet,"WO")==0)
					    {
					         tc_strcat(ReleaseType,"Withdraw From Obsolete");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"WTR")==0)
					    {
					         tc_strcat(ReleaseType,"Workshop Tools Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"CKC")==0)
					    {
					         tc_strcat(ReleaseType,"Cabin Kit Release / Cabin Kit Creation For Released VC");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"RDL")==0)
					    {
					         tc_strcat(ReleaseType,"Reference Drawing Linkage");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"VCMDU")==0)
					    {
					         tc_strcat(ReleaseType,"VC/TPL/Module Master Data Update");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"DTR")==0)
					    {
					         tc_strcat(ReleaseType,"Dummy TPL Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"MR")==0)
					    {
					         tc_strcat(ReleaseType,"Module Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"BEC")==0)
					    {
					         tc_strcat(ReleaseType,"BOM Error Cleanup");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"TOO")==0)
					    {
					         tc_strcat(ReleaseType,"Transfer of Design Site Ownership");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"PDR")==0)
					    {
					         tc_strcat(ReleaseType,"Positional Dummy Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"PPR")==0)
					    {
					         tc_strcat(ReleaseType,"Production Part Regularization");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else if(tc_strcmp(ReleaseTypeSet,"COL")==0)
					    {
					         tc_strcat(ReleaseType,"Comp Code and Colour Indicator update");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"IFR")==0)
					    {
					         tc_strcat(ReleaseType,"Info Fitment Drawing Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"DM")==0)
					    {
					         tc_strcat(ReleaseType,"Delete Module");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"SVR")==0)
					    {
					         tc_strcat(ReleaseType,"SVR Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"CPR")==0)
					    {
					         tc_strcat(ReleaseType,"CP Module Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"MMDMR")==0)
					    {
					         tc_strcat(ReleaseType,"Module Master Data Management Request");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"DFMR")==0)
					    {
					         tc_strcat(ReleaseType,"DFM-A Module Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"SSR")==0)
					    {
					         tc_strcat(ReleaseType,"Snapshot Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"UVF")==0)
					    {
					         tc_strcat(ReleaseType,"Update Variant Formula");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"SPIUP")==0)
					    {
					         tc_strcat(ReleaseType,"Spare Indicator Update");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"BKC")==0)
					    {
					         tc_strcat(ReleaseType,"Backward Compatible VCID Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"CCU")==0)
					    {
					         tc_strcat(ReleaseType,"VCID Update");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"MD")==0)
					    {
					         tc_strcat(ReleaseType,"Master Data Management For ECU");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"RBQU")==0)
					    {
					         tc_strcat(ReleaseType,"Released BOM Quantity Update");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"MDMFD")==0)
					    {
					         tc_strcat(ReleaseType,"MDM DML for 4D/DVA Document Attachment");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"EMR")==0)
					    {
					         tc_strcat(ReleaseType,"MDM for ECU Module Replacement");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"GIR")==0)
					    {
					         tc_strcat(ReleaseType,"Group ID Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"ES")==0)
					    {
					         tc_strcat(ReleaseType,"Export Specification");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"PP")==0)
					    {
					         tc_strcat(ReleaseType,"Prototype Part");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"SCR")==0)
					    {
					         tc_strcat(ReleaseType,"SVR cluster Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"EIDL")==0)
					    {
					         tc_strcat(ReleaseType,"ERC Internal Data Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }

						else if(tc_strcmp(ReleaseTypeSet,"DFR")==0)
					    {
					         tc_strcat(ReleaseType,"Durafit Release");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"VPL")==0)
					    {
					         tc_strcat(ReleaseType,"VPL");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"MMUD")==0)
					    {
					         tc_strcat(ReleaseType,"MDM Milestone update DML");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"EIDRME")==0)
					    {
					         tc_strcat(ReleaseType,"ERC Internal Data Release - Material Engg");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"NMGA")==0)
					    {
					         tc_strcat(ReleaseType,"New Material Grade Approval");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"UCKA")==0)
					    {
					         tc_strcat(ReleaseType,"Update Cabin kit Applicability");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
						else if(tc_strcmp(ReleaseTypeSet,"MERC")==0)
					    {
					         tc_strcat(ReleaseType,"MDM ECU Reports for Container");
					         printf("\n\n\t\t Release Type ----> %s",ReleaseType);fflush(stdout);

					    }
					    else
					    {
					         printf("\n\n\t\t Release Type Not Found");fflush(stdout);

					    }

					}

					if(ErcDmlPtr)
					{

						ITK_CALL(AOM_ask_value_string(ErcDmlPtr, "t5_reason", &ReasonValDup));
						printf("\n\n\t\t ReasonValDup ----> %s",ReasonValDup);fflush(stdout);

						Reason = NULL;
						Reason = malloc(500);
						strcpy(Reason,"");


					    if(tc_strcmp(ReasonValDup,"CcfEnhancement")==0)
					    {
					        tc_strcat(Reason,"IMPRV PRDCTVTY & EFFICIENCY");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);

					    }
					    else if(tc_strcmp(ReasonValDup,"Safety")==0)
					    {
					        tc_strcat(Reason,"SAFETY");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }

						else if(tc_strcmp(ReasonValDup,"NR")==0)
					    {
					        tc_strcat(Reason,"NEW REQUIREMENTS (NEW VC, NEW AGGREGATE)");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"TO FACILITATE PRODUCTION")==0)
					    {
					        tc_strcat(Reason,"TO FACILITATE PRODUCTION");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"FM")==0)
					    {
					        tc_strcat(Reason,"TO FACILITATE MANUFACTURING");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"CcfDefect")==0)
					    {
					        tc_strcat(Reason,"CUSTOMERS REQUIREMENT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"CcfDevelopment")==0)
					    {
					        tc_strcat(Reason,"PRODUCT DEVELOPMENT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }

						else if(tc_strcmp(ReasonValDup,"QRI")==0)
					    {
					        tc_strcat(Reason,"QUALITY, WARRANTY & RELIABILITY IMPROVEMENT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }

						else if(tc_strcmp(ReasonValDup,"CM")==0)
					    {
					        tc_strcat(Reason,"END CUSTOMER/FIELD COMPLAINTS & SERVICE FEEDBACK/CCT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }

					    else if(tc_strcmp(ReasonValDup,"ICWCR")==0)
					    {
					        tc_strcat(Reason,"INTEGRATED COST REDUCTION / WEIGHT REDUCTION / COMPLEXITY REDUCTION");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"WCR")==0)
					    {
					        tc_strcat(Reason,"WARRANTY COST REDUCTION");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"PQ")==0)
					    {
					        tc_strcat(Reason,"IMPROVEMENT IN JD POWER INITIAL QUALITY SCORE");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"CFL")==0)
					    {
					        tc_strcat(Reason,"CHANGE IN FEATURE LIST");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }

					    else if(tc_strcmp(ReasonValDup,"QR")==0)
					    {
					        tc_strcat(Reason,"QUALITY & RELIABILITY IMPROVEMENT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"FM")==0)
					    {
					        tc_strcat(Reason,"TO FACILITATE MANUFACTURING");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"CM")==0)
					    {
					        tc_strcat(Reason,"END CUSTOMER/FIELD COMPLAINTS & SERVICE FEEDBACK/CCT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"CR")==0)
					    {
					        tc_strcat(Reason,"COST REDUCTION");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"SR")==0)
					    {
					        tc_strcat(Reason,"SAFETY REQUIREMENT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"RR")==0)
					    {
					        tc_strcat(Reason,"REGULATORY REQUIREMENT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"DR")==0)
					    {
					        tc_strcat(Reason,"DRAFTING ERROR CORRECTION/BOM-CAD QUALITY IMPROVEMENT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"AD")==0)
					    {
					        tc_strcat(Reason,"ALTERNATE SOURCE DEVELOPMENT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else if(tc_strcmp(ReasonValDup,"CMR")==0)
					    {
					        tc_strcat(Reason,"COMMONIZATION/STANDARDIZATION/COMPLEXITY REDUCTION");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"DM")==0)
					    {
					        tc_strcat(Reason,"DESIGN MATURATION");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"FMPCQRI")==0)
					    {
					        tc_strcat(Reason,"TO FACILITATE MANUFACTURING/ PROCESS CHANGES FOR QUALITY RELIABILITY IMPROVEMENT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"FA")==0)
					    {
					        tc_strcat(Reason,"FEATURE ADDITION");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"ECFR")==0)
					    {
					        tc_strcat(Reason,"ECU CALIBRATION FILE RELEASE");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"DVLO")==0)
					    {
					        tc_strcat(Reason,"DVLO ISSUES");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"RSR")==0)
					    {
					        tc_strcat(Reason,"REGULATORY / SAFETY REQUIREMENTS");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"QU")==0)
					    {
					        tc_strcat(Reason,"QUALITY");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"ATR")==0)
					    {
					        tc_strcat(Reason,"ATTRIBUTE REQUIREMENT");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"EM")==0)
					    {
					        tc_strcat(Reason,"ENGINEERING MATURITY (CAE, STYLING, VALIDATION, PROTO FEEDBACK ETC.)");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"DFAF")==0)
					    {
					        tc_strcat(Reason,"DFA FEEDBACK");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"DFSF")==0)
					    {
					        tc_strcat(Reason,"DFS FEEDBACK");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"DFCF")==0)
					    {
					        tc_strcat(Reason,"DFC FEEDBACK");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"CSC")==0)
					    {
					        tc_strcat(Reason,"CONDITION OF SUPPLY CHANGE");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"SC")==0)
					    {
					        tc_strcat(Reason,"SCOPE CHANGES");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"RSP")==0)
					    {
					        tc_strcat(Reason,"RELEASE OF SPARES/KITS (NO NEW PART DEVELOPMENT)");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"IFD")==0)
					    {
					        tc_strcat(Reason,"INFO-FITMENT DRAWING (IFD)");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"DFM")==0)
					    {
					        tc_strcat(Reason,"DFM");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"SCAS")==0)
					    {
					        tc_strcat(Reason,"STYLING SURFACES (CAS)");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"EVI")==0)
					    {
					        tc_strcat(Reason,"EVI REPLACEMENTS (BLACK BOX)");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"BTSC")==0)
					    {
					        tc_strcat(Reason,"BTS SUPPLIER CHANGE (GREY BOX)");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"4DCHANGE")==0)
					    {
					        tc_strcat(Reason,"4D CHANGES");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"VCAE")==0)
					    {
					        tc_strcat(Reason,"VALIDATION / CAE FEEDBACK");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"WR")==0)
					    {
					        tc_strcat(Reason,"WEIGHT REDUCTION");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"ICR")==0)
					    {
					        tc_strcat(Reason,"INTEGRATED COST REDUCTION");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"MMDMR")==0)
					    {
					        tc_strcat(Reason,"MODULE MASTER DATA MANAGEMENT REQUEST");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"VAC")==0)
					    {
					        tc_strcat(Reason,"VC Attribute Change");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
						else if(tc_strcmp(ReasonValDup,"SA")==0)
					    {
					        tc_strcat(Reason,"SAMPLES TO BE APPROVED");
					        printf("\n\n\t\t Reason ----> %s",Reason);fflush(stdout);
					    }
					    else
					    {
					        printf("\n\n\t\t Reason Not Found");fflush(stdout);
					        
					    }

					}
					
					ReleaseNotes1	  = NULL;
					ReleaseNotes1	  = malloc(4000);

					ITK_CALL(AOM_ask_value_string(ErcDmlPtr, "t5_rlsltrnotes", &ReleaseNotes1));
					if(tc_strcmp(ReleaseNotes1,"NULL")!=0 && tc_strcmp(ReleaseNotes1," ")!=0 && tc_strcmp(ReleaseNotes1,"")!=0)
					{
						printf("\n\n\t\t Release Notes ----> %s",ReleaseNotes1);fflush(stdout);
					}
					else
					{
						printf("\n\n\t\t Release Notes Not Found ");fflush(stdout);
					}

					ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr, "t5_crdesigngroup", &DesgGrp));
					if((tc_strcmp(DesgGrp,"") !=0))
					{
						printf("\n\n\t\t Design Group ==> %s",DesgGrp);fflush(stdout);
					}
					else
					{
						printf("\n\n\t\t Design Group is Empty ");fflush(stdout);
					}


					ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr, "t5_ERCWBS",&ERCWBSid));
					//printf("\n\n\t\t ERC-WBS ==> %s",ERCWBSid);fflush(stdout);

					if(tc_strcmp(ERCWBSid,"NULL")!=0 && tc_strcmp(ERCWBSid," ")!=0 && tc_strcmp(ERCWBSid,"")!=0)
					{
						printf("\n\n\t\t ERC-WBS ==> %s",ERCWBSid);fflush(stdout);
					}
					else
					{
						printf("\n\n\t\t ERC-WBS Not Found ");fflush(stdout);
					}


					ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr, "CMImplements", &DCRNo));
					if(tc_strcmp(DCRNo,"NULL")!=0 && tc_strcmp(DCRNo," ")!=0 && tc_strcmp(DCRNo,"")!=0)
					{
						printf("\n\n\t\t DML-DCR  ----> %s",DCRNo);fflush(stdout);
					}
					else
					{
						printf("\n\n\t\t DML-DCR Not Found ");fflush(stdout);
					}
                    aString-> __size =1;
			        aString->__ptr = malloc( (aString->__size + 1) * sizeof(*aString->__ptr) );

			        aString->__ptr[0].DML = malloc(30 * sizeof(char *) );
			        aString->__ptr[0].Synopsis = malloc(200 * sizeof(char *) );
			        aString->__ptr[0].Design_Grp = malloc(200 * sizeof(char *) );
			        aString->__ptr[0].DR_Status = malloc(30 * sizeof(char *) );
			        aString->__ptr[0].Reason = malloc(100 * sizeof(char *) );
			        aString->__ptr[0].Release_Type = malloc(100 * sizeof(char *) );
			        aString->__ptr[0].Release_Notes = malloc(1000 * sizeof(char *) );
			        aString->__ptr[0].ERC_WBS = malloc(30 * sizeof(char *) );
			        aString->__ptr[0].DML_DCR = malloc(200 * sizeof(char *) );

			        tc_strcpy(aString->__ptr[0].DML,dmlNo);
			        tc_strcpy(aString->__ptr[0].Synopsis,synopsis);
			        tc_strcpy(aString->__ptr[0].Design_Grp,DesgGrp);
			        tc_strcpy(aString->__ptr[0].DR_Status,DRStatus);
			        tc_strcpy(aString->__ptr[0].Reason,Reason);
			        tc_strcpy(aString->__ptr[0].Release_Type,ReleaseType);
			        tc_strcpy(aString->__ptr[0].Release_Notes,ReleaseNotes1);
			        tc_strcpy(aString->__ptr[0].ERC_WBS,ERCWBSid);
			        tc_strcpy(aString->__ptr[0].DML_DCR,DCRNo);



				}
				else
				{
					printf("\n\n\t\t ERC DML Not Found ");fflush(stdout);
				}

			//}


		}
		else
		{
			printf("\n\n\t\t Query Not Found ");fflush(stdout);
		}

	}

	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;

 CLEANUP :
	    
		return SOAP_OK;

EXIT:
		return SOAP_OK;
}



void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}


int ns__DML_Part_Details(struct soap* soap, char *DmlNumber, struct ns__CharArray2 *cString)
{

	            int n_items                = 0;
				int Apl_Dmlc               = 0;
				int status                 = ITK_ok;
				int value_entries          = 1;
				int Tskcount               = 0;
				int Referencesitemcount               = 0;
				int solutionitemcount               = 0;
				int solutionitem               = 0;
				int Dfmeacount               = 0;
				int j               = 0;
				int iCount                 = 0;
				int iCount2                 = 0;
				int DesRevc                = 0;
				int sorCount               = 0;
				int SORc                   = 0;
				int count                   = 0;
				int d                   = 0;
				int m                   = 0;
				int i                   = 0;
				int n                   = 0;
				int o                   = 0;
				int p                   = 0;
				int k                   = 0;
				int L                   = 0;
				int soDadObjs                   = 0;
				int soRefObjs                   = 0;
				int iCount7;
				int S;
				int T;

				char *sUserName            = NULL;
				char *sPassword            = NULL;
				char *ID            = NULL;
				char *entries[1]           = {"ID"};
				char **values              = NULL;
				char *filename             = NULL;
				char *filename1            = NULL;
				char* DML_Number           = NULL;
				char* Synopsis   = NULL;
				char* Design_Grp          = NULL;
				char* tsk_Id   = NULL;
				char* Drev_release_status  = NULL;
				char* SOR_release_status   = NULL;
				char* SOR_item_ID          = NULL;
				char* Reason          = NULL;
				char* ReleaseType          = NULL;
				char* ReleaseNote          = NULL;
				char* DesgGrpAll           = NULL;
				char* ERC_WBS           = NULL;
				char* tsk_designGrp           = NULL;
				char* DR_Status           = NULL;
				char* DML_task_Number           = NULL;
				char* s           = NULL;
				char* PlantObjNo           = NULL;
				char* Tsk_release_status           = NULL;
				char* PlantObj_type           = NULL;
				char** parts           = NULL;
				char*  InDadFmeaPrt	     = NULL;
				char*  InDadFmeaPrttype	     = NULL;
				char*  InDFmeaPrt		 = NULL;
				char*  item_type		 = NULL;
				char*  Part_Type		 = NULL;
				char *itemid = NULL;
				char *itemRevid = NULL;
				char *PNo = NULL;
				char *PRev = NULL;
				char *PRev8 = NULL;
				char *PSeq = NULL;
				char *PType1 = NULL;
				char*  fourDoc		 = NULL;
				char*  DfmeaDoc		 = NULL;
				char*  Ref4DDfmeaDoc		 = NULL;
				char*  InDadFmeaPrtDup   = NULL;
				char*  InDadFmeaClassDup = NULL;
				char*  InDFmeaPrtDup	 = NULL;
				char*  DFM_Doc			 = NULL;
				char*  DFA_Doc			 = NULL;
				char*  DFS_Doc			 = NULL;

				char*  PNo7			     = NULL;
				char*  PRev7			     = NULL;
				char*  PRev9			     = NULL;
				char*  PSeq7			     = NULL;
				char*  PType7			     = NULL;

				char*  Folder_name7		 = NULL;
				char*  itemid7		 = NULL;
				char*  itemRevid7		 = NULL;
				char*  PartDetFullStr		 = NULL;
				PartDetFullStr=(char* )MEM_alloc(50000 * sizeof(char) );
				tc_strcpy(PartDetFullStr,"");

				int counter = 0;

                tag_t query_tag            = NULLTAG;
				tag_t *ErcDMLt             = NULLTAG;
				tag_t *ErcTskRevision	   = NULLTAG;
				tag_t *DfmeRevision	   = NULLTAG;
				tag_t *soDadRelObj	   = NULLTAG;
				tag_t *soRefRelObjs	   = NULLTAG;
				tag_t *solutionitemTags	   = NULLTAG;
				tag_t *DmlTaskObjs	   = NULLTAG;
				tag_t *ReferencesitemTags	   = NULLTAG;		
				tag_t dml_tsk_rel_type	   = NULLTAG;
				tag_t solutionitemreltag	   = NULLTAG;
				tag_t Referencesitemreltag	   = NULLTAG;
				tag_t Dfmea_tsk_rel_type	   = NULLTAG;
				tag_t PartRefDFMEA_rel	   = NULLTAG;
				tag_t PartHas4D_rel	   = NULLTAG;
				tag_t tsk_design_rev_rel   = NULLTAG;
				tag_t TskTag	           = NULLTAG;
				tag_t TskTag1	           = NULLTAG;
				tag_t *DesignRevision	   = NULLTAG;
				tag_t DesRevTag	           = NULLTAG;
				tag_t des_sor_rel	       = NULLTAG;
				tag_t *SorRevision	       = NULLTAG;
				tag_t SORRevTag	           = NULLTAG;
				tag_t TaskTag	           = NULLTAG;
				tag_t ErcDMLTag	           = NULLTAG;
				tag_t ChRefItm	           = NULLTAG;
				tag_t fordDco	           = NULLTAG;
				tag_t Dfmea	           = NULLTAG;
				tag_t Ref4DDfmea	           = NULLTAG;
				tag_t ErcTag1	           = NULLTAG;
				char*  FourDdocs		 = NULL;

				char*  part_details		 = NULL;
				FourDdocs=malloc(15000); 

				tc_strcpy(FourDdocs,"");
				part_details=malloc(15000);

				char*   dmlid               = NULL;
				char*   dmlSeqid               = NULL;
				tag_t   dmlidTag	     = NULL;
				tag_t   dmllatRevTag	     = NULL;



				fpos_t pos;
	            fgetpos(stdout, &pos);
	            int fd = dup(fileno(stdout));
	            freopen("/tmp/dml.txt", "a", stdout);


				ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
				ITK_CALL(ITK_auto_login());
				ITK_set_bypass(true);

				ITK_CALL(ITK_set_journalling(TRUE));
				if (status == 0 )
				{
					printf("\n Auto login to Teamcenter successful \n");fflush(stdout);
				}
				else
				{
					printf("\n Error code:%d",status);fflush(stdout);
					EMH_ask_error_text(status,&s);
					printf("\n Error message:%s",s);fflush(stdout);
				}

				values = (char **) MEM_alloc(8000 * sizeof(char *));

				ITK_CALL(QRY_find2("ERC DML Revision",&query_tag));

				if (query_tag)
				{
		            values[0] = (char *)MEM_alloc( strlen( DmlNumber ) + 1);
		            tc_strcpy(values[0], DmlNumber  );

					ITK_CALL(QRY_execute(query_tag, value_entries, entries, values, &n_items, &ErcDMLt));

                    count=0;
					if (n_items >0)
					{
						
						ErcTag1 = ErcDMLt[0];

						ITK_CALL(AOM_UIF_ask_value(ErcTag1,"item_id",&dmlid));
						printf("\nErcDML : %s",dmlid);fflush(stdout);

						//ITK_CALL(AOM_UIF_ask_value(ErcTag1,"sequence_id",&dmlSeqid));
						//printf("\ErcDmlSeqid : %s",dmlSeqid);fflush(stdout);

						ITK_CALL(ITEM_find_item(dmlid, &dmlidTag));
						ITK_CALL(ITEM_ask_latest_rev(dmlidTag,&dmllatRevTag));	


                        ITK_CALL(AOM_UIF_ask_value(dmllatRevTag, "item_id" ,&DML_Number));
						ITK_CALL(AOM_UIF_ask_value(dmllatRevTag,"sequence_id",&dmlSeqid));
						printf("\nErcDmlSeqid : %s",dmlSeqid);fflush(stdout);

						ITK_CALL(GRM_find_relation_type ( "T5_DMLTaskRelation", &dml_tsk_rel_type ) );
	                    ITK_CALL(GRM_list_secondary_objects_only ( dmllatRevTag, dml_tsk_rel_type, &Tskcount, &ErcTskRevision )) ;//dml rev to task traversal


                         for (j=0 ; j < Tskcount ; j++ )
                         {
							  ErcDMLTag = ErcTskRevision[j];
							  
							  ITK_CALL(AOM_UIF_ask_value(ErcDMLTag,"current_id",&PlantObjNo));
							  printf("\nErcTaskDML : %s",PlantObjNo);fflush(stdout);
							  							  
							  ITK_CALL(AOM_UIF_ask_value(ErcDMLTag, "object_type", &PlantObj_type));
							  printf("\nPlantObj_type : %s",PlantObj_type);fflush(stdout);
							  
							  if(tc_strcmp(PlantObj_type,"ERC Task Revision")== 0)
							  {
							 		
							 		ITK_CALL(GRM_find_relation_type ( "CMHasSolutionItem", &solutionitemreltag ) );
							 		ITK_CALL(GRM_list_secondary_objects_only ( ErcDMLTag, solutionitemreltag, &solutionitemcount, &solutionitemTags ) );
									printf("\nsolutionitemcount : %d",solutionitemcount);fflush(stdout);
							  
							  
							 		if(solutionitemcount>0)
							 		{
							 			count=count+solutionitemcount;
										cString->__size = count;
										cString->__ptr = malloc( (cString->__size + 1) * sizeof(*cString->__ptr) );
							  
										for(d=0;d<count;d++)
										{
											cString->__ptr[d].Part_Details = malloc(15000 * sizeof(char *) );
										}

							 		}
							 		else
							 		{
							 			ITK_CALL(GRM_find_relation_type ( "CMReferences", &Referencesitemreltag )) ;
							 		    ITK_CALL(GRM_list_secondary_objects_only ( ErcDMLTag, Referencesitemreltag, &Referencesitemcount, &ReferencesitemTags )) ;
										printf("\nReferencesitemcount : %d",Referencesitemcount);fflush(stdout);
							 		    //count=count+Referencesitemcount;
							 		}
							  
							 		
							 		ITK_CALL(AOM_UIF_ask_value(ErcDMLTag, "item_id" ,&DML_task_Number));
							 		//printf("\nErcTaskDml : %s",DML_task_Number);fflush(stdout);
							 		
							 		ITK_CALL(GRM_find_relation_type ( "CMReferences", &Referencesitemreltag ) );
							 		ITK_CALL(GRM_list_secondary_objects_only ( ErcDMLTag, Referencesitemreltag, &Referencesitemcount, &ReferencesitemTags ) );
							  

							 		if (Referencesitemcount == 0) //Solution Parts
							 		{
							 			ITK_CALL(GRM_find_relation_type ( "CMHasSolutionItem", &solutionitemreltag ) );
							 		    ITK_CALL(GRM_list_secondary_objects_only ( ErcDMLTag, solutionitemreltag, &solutionitemcount, &solutionitemTags )) ;
							  
							 			if (solutionitemcount > 0)
							 			{
							 				printf("\nSolution.count : %d\n",solutionitemcount);fflush(stdout);
							 				k=0;
							 			
							 				for (m = 0;m < solutionitemcount ; m++ )
							 				{
							 					ChRefItm = solutionitemTags[m];
							  
							 					char *itemid = NULL;
							 					char *itemRevid = NULL;
							 					char *PNo = NULL;
							 					char *PRev = NULL;
							 					char *PRev_1 = NULL;
							 					char *PSeq = NULL;
							 					char *PType1 = NULL;
							 					char*  fourDoc		 = NULL;
							 					char*  DfmeaDoc		 = NULL;
							 					char*  Ref4DDfmeaDoc		 = NULL;
							 					char*  part_details		 = NULL;
							 					char*  InDadFmeaPrtDup   = NULL;
							 					char*  InDadFmeaClassDup = NULL;
							 					char*  InDFmeaPrtDup	 = NULL;
							 					char*  DFM_Doc			 = NULL;
							 					char*  DFA_Doc			 = NULL;
							 					char*  DFS_Doc			 = NULL;
							 					char*  IDPart		 = NULL;
							  
							 					tag_t   itemTag_1		 = NULL;
							 					tag_t   partRevTag_1	 = NULL;
							  
							 					part_details=malloc(12000);
							 					FourDdocs= NULL;
							 					FourDdocs=malloc(12000);
							 					tc_strcpy(FourDdocs,"");
							  
							 					InDadFmeaPrtDup=malloc(12000);
							 					InDadFmeaClassDup=malloc(12000);
							 					InDFmeaPrtDup=malloc(12000);
							 					part_details=malloc(12000);
							  
							 					DfmeaDoc=malloc(12000);
							 					tc_strcpy(DfmeaDoc,"");
							 					DFM_Doc=malloc(12000);
							 					tc_strcpy(DFM_Doc,"");
							 					DFA_Doc=malloc(12000);
							 					tc_strcpy(DFA_Doc,"");
							 					DFS_Doc=malloc(12000);
							 					tc_strcpy(DFS_Doc,"");
							  
							 				 ITK_CALL(AOM_UIF_ask_value(ChRefItm,"item_id", &IDPart));
							 				 printf("\nID : [%s]",IDPart);
							  
							 				 ITK_CALL(AOM_UIF_ask_value(ChRefItm,"object_type", &item_type));
							 				 printf("\nType : [%s]",item_type);
							 				 
							 				 if ((tc_strcmp(item_type,"Design Revision")==0) || (tc_strcmp(item_type,"EE Part Revision")==0)) // 18.06.2024
											 //if (tc_strcmp(item_type,"Design Revision")==0) 
							 				 {
												 
											   printf("\nInside Solution");
							  
							 				   ITK_CALL(AOM_UIF_ask_value(ChRefItm,"item_id", &itemid));
											   printf("\nPruthvi 1 : [%s]",itemid);
							 				   ITK_CALL(AOM_UIF_ask_value(ChRefItm,"item_revision_id", &itemRevid));
											   printf("\nPruthvi 2 : [%s]",itemRevid);
							  
							 				   ITK_CALL(ITEM_find_item(itemid, &itemTag_1));
							 				   ITK_CALL(ITEM_ask_latest_rev(itemTag_1, &partRevTag_1));
							  
							 				   ITK_CALL(AOM_UIF_ask_value(partRevTag_1, "item_id", &PNo));
							 				   printf("\nPNo : %s",PNo);fflush(stdout);
							  
							 				   ITK_CALL(AOM_UIF_ask_value(ChRefItm, "item_revision_id", &PRev_1));
							 				   printf("\nPRev_1 : %s",PRev_1);fflush(stdout);
							  
							 				   PRev=tc_strtok(PRev_1, ";");
							 				   printf("\nPRev : [%s]",PRev);

							 				   PSeq=tc_strtok(NULL, "");
							 				   printf("\nPSeq : %s",PSeq);fflush(stdout);
							  
							 				   ITK_CALL(AOM_ask_value_string(ChRefItm, "t5_PartType", &PType1));
							 				   printf("\nPType1 : %s",PType1);fflush(stdout);
							  
							 				   ITK_CALL(GRM_find_relation_type ( "T5_PartHas4D", &PartHas4D_rel )); //Part has 4D
							 				   ITK_CALL(GRM_list_secondary_objects_only ( ChRefItm, PartHas4D_rel, &soDadObjs, &soDadRelObj ));
							  
							 				   ITK_CALL(GRM_find_relation_type ( "T5_PartHasDfmea", &Dfmea_tsk_rel_type )); //Part has Dfmea
							 				   ITK_CALL(GRM_list_secondary_objects_only ( ChRefItm, Dfmea_tsk_rel_type, &Dfmeacount, &DfmeRevision ));
							  
							 				   ITK_CALL(GRM_find_relation_type ( "T5_PartHasRef4DDfmea", &PartRefDFMEA_rel )); //Part has Ref4D Dfmea
							 				   ITK_CALL(GRM_list_secondary_objects_only ( ChRefItm, PartRefDFMEA_rel, &soRefObjs, &soRefRelObjs ));
							 				   
							 				   if( (soDadObjs > 0) || (Dfmeacount > 0) || (soRefObjs > 0) )
							 				   {
							 				
							 						if (Dfmeacount > 0) //Part has Dfmea
							 						{
							 							for (o = 0;o < Dfmeacount ; o++)
							 							{
							 								Dfmea = DfmeRevision[o];
							 						        ITK_CALL(AOM_UIF_ask_value(Dfmea,"item_id", &InDFmeaPrt));
							 								//printf("\n Part has Dfmea Id: IS >>>>>>>>>>>>>>>>>>> %s",InDFmeaPrt);
							  
							 								if((tc_strcmp(InDFmeaPrt,"") !=0))
							 								{
							 									  tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);
							 								} 
							  
							 								if (tc_strcmp(InDFmeaPrtDup,"")!=0)
							 								{
							 									tc_strcpy(DfmeaDoc,InDFmeaPrtDup);
							 								}
							 																			                          
							 							 }
							  
							 						}
							  
							 						if (soRefObjs > 0) //Part has Ref4D Dfmea
							 						{
							 						
							 							for (p = 0;p < soRefObjs ; p++)
							 							{
							 								Ref4DDfmea = soRefRelObjs[p];
							  
							 								ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea,"object_type", &item_type));
							 								//printf("\n item_type : [%s]",item_type);
							 								
							 								if ((tc_strcmp(item_type,"DAD Doc Revision")==0) ||  (tc_strcmp(item_type,"Dfmea Revision")==0))
							 								{
							  
							 									ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea,"current_id", &InDadFmeaPrt));
							 									//printf("\n Part has Ref4D Dfmea Id: IS >>>>>>>>>>>>>>>>>>> %s",InDadFmeaPrt);
							  
							 									if((tc_strcmp(InDadFmeaPrt,"") !=0))
							 									{
							 										tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
							 									} 
							  
							 									ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea, "object_type" ,&InDadFmeaPrttype));
							 									//printf("\n Part has Ref4D Dfmea type Id: IS >>>>>>>>>>>>>>>>>>> %s",InDadFmeaPrttype);
							 									if((tc_strcmp(InDadFmeaPrttype,"") !=0))
							 									{
							 										tc_strcpy(InDadFmeaClassDup,InDadFmeaPrttype);
							 									}
							  
							 									if((tc_strcmp(InDadFmeaClassDup,"Dfmea Revision") == 0) )
							 									{
							  
							 										ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea,"item_id", &InDFmeaPrt)); 
							  
							 										if((tc_strcmp(InDFmeaPrt,"") !=0))
							 										{
							 											tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);
							  
							 										}
							 					
							 										if (tc_strcmp(InDFmeaPrtDup,"")!=0)
							 										{
							 											tc_strcpy(DfmeaDoc,InDFmeaPrtDup);
							 										}
							 										
							 									}
							  
							 									if (tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
							 									{
							 										tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
							 									}
							 									
							 									else if (tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
							 									{
							 										tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
							 									}
							 									
							 									else if (tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
							 									{
							 										tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
							 									}
							  
							 								}
							  
							 							}
							  
							  
							 						}
							  
							 						if (soDadObjs > 0) //Part has 4D
							 						{
							 							for (n = 0; n < soDadObjs ;n++ )
							 							{
							 								fordDco = soDadRelObj[n];
							  
							 								ITK_CALL(AOM_UIF_ask_value(fordDco,"object_type", &item_type));
							 								//printf("\n item_type Part has 4D: [%s]",item_type);
							 								
							 								if (tc_strcmp(item_type,"DAD Doc Revision")==0)
							 								{
							  
							 									ITK_CALL(AOM_UIF_ask_value(fordDco,"current_id", &InDadFmeaPrt));
							 									printf("\n Part has 4D Id: IS >>>>>>>>>>>>>>>>>>> %s",InDadFmeaPrt);
							  
							 									if((tc_strcmp(InDadFmeaPrt,"") !=0))
							 									{
							 											tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
							 									}
							 									
							 									if (tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
							 									{
							 										tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
							 									} 
							 									
							 									else if (tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
							 									{
							 										tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
							 									}
							 									
							 									else if (tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
							 									{
							 										tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
							 									}	
							 								
							 								}
							 						        
							 							}
							 						}
							  
							  
							 						if(tc_strcmp(DfmeaDoc,"") !=0 )
							 						{
							 							printf("\n\t\t DFMEA_Doc : %s",DfmeaDoc);
							 							tc_strcpy(FourDdocs,DfmeaDoc);
							 							tc_strcat(FourDdocs,",");
							 							//printf("\n\n\t DfmeaDoc FourDdocs : IS %s",FourDdocs);
							 						}
							 						if(tc_strcmp(DfmeaDoc,"") ==0 )
							 						{
							 							tc_strcpy(DfmeaDoc,"NA");
							 							printf("\n\t\t DFMEA_Doc : %s",DfmeaDoc);
							 							tc_strcat(FourDdocs,DfmeaDoc);               
							 							tc_strcat(FourDdocs,",");                     
							 							//printf("\n\n\t DfmeaDoc FourDdocs : IS %s",FourDdocs);
							 						}
							  
							 						if(tc_strcmp(DFM_Doc,"") !=0 )
							 						{
							 							printf("\n\t\t DFM_Doc : %s",DFM_Doc);
							 							tc_strcat(FourDdocs,DFM_Doc);
							 							tc_strcat(FourDdocs,",");
							 							//printf("\n\n\t DFM_Doc FourDdocs : IS %s",FourDdocs);
							 						}
							 						if(tc_strcmp(DFM_Doc,"") ==0 )
							 						{
							 							tc_strcpy(DFM_Doc,"NA");
							 							printf("\n\t\t DFM_Doc : %s",DFM_Doc);
							 							tc_strcat(FourDdocs,DFM_Doc);
							 							tc_strcat(FourDdocs,",");
							 							//printf("\n\n\t DFM_Doc FourDdocs : IS %s",FourDdocs);
							 							
							 						}
							  
							 						if(tc_strcmp(DFA_Doc,"") !=0 )
							 						{ 
							 							printf("\n\t\t DFA_Doc : %s",DFA_Doc);
							 							tc_strcat(FourDdocs,DFA_Doc);
							 							tc_strcat(FourDdocs,",");
							 							//printf("\n\n\t DFA_Doc FourDdocs : IS %s",FourDdocs);
							 							
							 						}
							 						if(tc_strcmp(DFA_Doc,"") ==0 )
							 						{
							 							tc_strcpy(DFA_Doc,"NA"); 
							 							printf("\n\t\t DFA_Doc : %s",DFA_Doc);
							 							tc_strcat(FourDdocs,DFA_Doc);                 
							 							tc_strcat(FourDdocs,","); 
							 							//printf("\n\n\t DFA_Doc FourDdocs : IS %s",FourDdocs);
							 							
							 						}
							  
							 						if(tc_strcmp(DFS_Doc,"") !=0 )
							 						{
							 							printf("\n\t\t DFS_Doc : %s",DFS_Doc);
							 							tc_strcat(FourDdocs,DFS_Doc);                  
							 							//tc_strcat(FourDdocs,",");                    
							 							//printf("\n\n\t DFS_Doc FourDdocs : IS %s",FourDdocs);       
							 						}
							 						if(tc_strcmp(DFS_Doc,"") ==0 )
							 						{
							 							tc_strcpy(DFS_Doc,"NA"); 
							 							printf("\n\t\t DFS_Doc : %s",DFS_Doc);
							 							tc_strcat(FourDdocs,DFS_Doc);                 
							 							//printf("\n\n\t DFS_Doc FourDdocs : IS %s",FourDdocs);   
							 							
							 						}																	
							 																							
							 				   }
							 				   else
							 				   {
							 					   tc_strcpy(FourDdocs,"NA,NA,NA,NA");
							 					   //printf("\n\n\t FourDdocs : IS %s",FourDdocs);  
							 				   }
							  
							  
							 					tc_strcpy(part_details,PNo);
							 		            tc_strcat(part_details,",");
							 		            tc_strcat(part_details,PRev);
							 		            tc_strcat(part_details,",");
							 		            tc_strcat(part_details,PSeq);
							 		            tc_strcat(part_details,",");
							 		            tc_strcat(part_details,PType1);
							 		            tc_strcat(part_details,",");
							 		            tc_strcat(part_details,FourDdocs);
							  
							  
							 					printf("\n\n\t\t All 4d Doc %s \n\n",part_details);
							  
							 					//setAddStr(&counter,&parts,part_details);                 //commented on 23-05-24
							 					//tc_strcpy(cString->__ptr[k].Part_Details,part_details);  //commented on 23-05-24
							 					//k++;                                                     //commented on 23-05-24

												tc_strcat(PartDetFullStr,part_details);
												tc_strcat(PartDetFullStr,"$");
							  
							 					//printf("\n\n\t\t All 4d Doc 2 %s \n\n",part_details);
							  
							 				 }
							 				
							 				}
							  
							 			}
							  
							 		}
							 		else //Reference Parts
							 		{   
							 		    k=0;
							 		    L=0;
							 		    printf("\nReference count : %d\n",Referencesitemcount);fflush(stdout);
							 		       
							 		    if (Referencesitemcount > 0)
							 		    {
							  
											for( m = 0; m < Referencesitemcount; m++ )
											{
											
												ChRefItm = ReferencesitemTags[m];
											
												FourDdocs= NULL;
												FourDdocs=malloc(13000);
												tc_strcpy(FourDdocs,"");
												part_details= NULL;
												part_details=malloc(13000);
												tc_strcpy(part_details,"");
											
												tag_t   PartPtr7	       = NULLTAG;
												tag_t   itemTag7		   = NULL;
												tag_t   partRevTag7	       = NULL;
												tag_t   itemTag8		   = NULL;
												tag_t   partRevTag8	       = NULL;
												tag_t*  Part_tag7	       = NULLTAG;
											
																		
												InDadFmeaPrtDup=malloc(13000);
												InDadFmeaClassDup=malloc(13000);
												InDFmeaPrtDup=malloc(12000);
												
												DfmeaDoc=malloc(13000);
												tc_strcpy(DfmeaDoc,"");
												DFM_Doc=malloc(13000);
												tc_strcpy(DFM_Doc,"");
												DFA_Doc=malloc(13000);
												tc_strcpy(DFA_Doc,"");
												DFS_Doc=malloc(13000);
												tc_strcpy(DFS_Doc,"");
											
												ITK_CALL(AOM_UIF_ask_value(ChRefItm,"object_type", &item_type));
												printf("\nitem_type : [%s]",item_type);fflush(stdout);
																							
												if ((tc_strcmp(item_type,"Design Revision")==0) || (tc_strcmp(item_type,"EE Part Revision")==0)) // 18.06.24
												//if (tc_strcmp(item_type,"Design Revision")==0)
												{
											
												   ITK_CALL(AOM_UIF_ask_value(ChRefItm,"item_id", &itemid));
												   ITK_CALL(AOM_UIF_ask_value(ChRefItm,"item_revision_id", &itemRevid));
											
												   ITK_CALL(ITEM_find_item(itemid, &itemTag8));
												   ITK_CALL(ITEM_ask_latest_rev(itemTag8,&partRevTag8));
											
												   ITK_CALL(AOM_UIF_ask_value(partRevTag8, "item_id", &PNo));
												   printf("\nPNo : [%s]",PNo);fflush(stdout);
											
												   ITK_CALL(AOM_UIF_ask_value(ChRefItm, "item_revision_id", &PRev8));
												   printf("\nPRev8 : [%s]",PRev8);fflush(stdout);
											
												   PRev=tc_strtok(PRev8, ";");
												   printf("\nPRev : [%s]",PRev);fflush(stdout);
											
												   PSeq=tc_strtok(NULL, "");
												   printf("\nPSeq : [%s]",PSeq);fflush(stdout);
											
												   ITK_CALL(AOM_ask_value_string(ChRefItm, "t5_PartType", &PType1));
												   printf("\nPType1 : [%s]",PType1);fflush(stdout);
											
												   ITK_CALL(GRM_find_relation_type ( "T5_PartHas4D", &PartHas4D_rel )); //Part has 4D
												   ITK_CALL(GRM_list_secondary_objects_only ( ChRefItm, PartHas4D_rel, &soDadObjs, &soDadRelObj ));
											
												   ITK_CALL(GRM_find_relation_type ( "T5_PartHasDfmea", &Dfmea_tsk_rel_type )); //Part has Dfmea
												   ITK_CALL(GRM_list_secondary_objects_only ( ChRefItm, Dfmea_tsk_rel_type, &Dfmeacount, &DfmeRevision ));
											
												   ITK_CALL(GRM_find_relation_type ( "T5_PartHasRef4DDfmea", &PartRefDFMEA_rel )); //Part has Ref4D Dfmea
												   ITK_CALL(GRM_list_secondary_objects_only ( ChRefItm, PartRefDFMEA_rel, &soRefObjs, &soRefRelObjs ));
											
											
												   if( (soDadObjs > 0) || (Dfmeacount > 0) || (soRefObjs > 0) )
												   {
													   
														if (Dfmeacount > 0) //Part has Dfmea
														{
															for (o = 0;o < Dfmeacount ; o++)
															{
																Dfmea = DfmeRevision[o];
														        ITK_CALL(AOM_UIF_ask_value(Dfmea,"item_id", &InDFmeaPrt));
																//printf("\n Part has Dfmea Id: IS >>>>>>>>>>>>>>>>>>> %s",InDFmeaPrt);
											
																if((tc_strcmp(InDFmeaPrt,"") !=0))
																{
																	  tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);
																} 
											
																if (tc_strcmp(InDFmeaPrtDup,"")!=0)
																{
																	tc_strcpy(DfmeaDoc,InDFmeaPrtDup);
																}
																											                          
															 }
											
														}
											
														if (soRefObjs > 0) //Part has Ref4D Dfmea
														{
														
															for (p = 0;p < soRefObjs ; p++)
															{
																Ref4DDfmea = soRefRelObjs[p];
											
																ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea,"object_type", &item_type));
																//printf("\n item_type : [%s]",item_type);
																
																if ((tc_strcmp(item_type,"DAD Doc Revision")==0) ||  (tc_strcmp(item_type,"Dfmea Revision")==0))
																{
											
																	ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea,"item_id", &InDadFmeaPrt));
																	//printf("\n Part has Ref4D Dfmea Id: IS >>>>>>>>>>>>>>>>>>> %s",InDadFmeaPrt);
											
																	if((tc_strcmp(InDadFmeaPrt,"") !=0))
																	{
																		tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
																	}
											
																	ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea, "object_type" ,&InDadFmeaPrttype));
																	//printf("\n Part has Ref4D Dfmea type Id: IS >>>>>>>>>>>>>>>>>>> %s",InDadFmeaPrttype);
																	if((tc_strcmp(InDadFmeaPrttype,"") !=0))
																	{
																		tc_strcpy(InDadFmeaClassDup,InDadFmeaPrttype);
																	}
											
																	if((tc_strcmp(InDadFmeaClassDup,"Dfmea Revision") == 0) )
																	{
											
																		ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea,"item_id", &InDFmeaPrt));
											
																		if((tc_strcmp(InDFmeaPrt,"") !=0))
																		{
																			tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);
											
																		}
													
																		if (tc_strcmp(InDFmeaPrtDup,"")!=0)
																		{
																			tc_strcpy(DfmeaDoc,InDFmeaPrtDup);
																		}
																		
																	}
											
																	if (tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
																	{
																		tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
																	}
																	
																	else if (tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
																	{
																		tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
																	}
																	
																	else if (tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
																	{
																		tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
																	}
											
											
																}
											
															}
											
											
														}
											
														if (soDadObjs > 0) //Part has 4D
														{
															for (n = 0; n < soDadObjs ;n++ )
															{
																fordDco = soDadRelObj[n];
											
																ITK_CALL(AOM_UIF_ask_value(fordDco,"object_type", &item_type));
																//printf("\n item_type : [%s]",item_type);
																
																if (tc_strcmp(item_type,"DAD Doc Revision")==0)
																{
											
																	ITK_CALL(AOM_UIF_ask_value(fordDco,"item_id", &InDadFmeaPrt));
																	//printf("\n Part has 4D Id: IS >>>>>>>>>>>>>>>>>>> %s",InDadFmeaPrt);
											
																	if((tc_strcmp(InDadFmeaPrt,"") !=0))
																	{
																			tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
																	}
																	
																	if (tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
																	{
																		tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
																	}
																	
																	else if (tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
																	{
																		tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
																	}
																	
																	else if (tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
																	{
																		tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
																	}
															
																}
														        
															}
														}
														
														if(tc_strcmp(DfmeaDoc,"") !=0 )
														{
															printf("\n\t\t DFMEA_Doc : %s",DfmeaDoc);
															tc_strcpy(FourDdocs,DfmeaDoc);
															tc_strcat(FourDdocs,",");
														}
														if(tc_strcmp(DfmeaDoc,"") ==0 )
														{
															tc_strcpy(DfmeaDoc,"NA"); 
															printf("\n\t\t DFMEA_Doc : %s",DfmeaDoc);
															tc_strcat(FourDdocs,DfmeaDoc);               
															tc_strcat(FourDdocs,",");                     
														}
											
														if(tc_strcmp(DFM_Doc,"") !=0 )
														{
															printf("\n\t\t DFM_Doc : %s",DFM_Doc);
															tc_strcat(FourDdocs,DFM_Doc);
															tc_strcat(FourDdocs,",");
											
														}
														if(tc_strcmp(DFM_Doc,"") ==0 )
														{
															tc_strcpy(DFM_Doc,"NA");
															printf("\n\t\t DFM_Doc : %s",DFM_Doc);
															tc_strcat(FourDdocs,DFM_Doc);
															tc_strcat(FourDdocs,",");																			
														}
											
														if(tc_strcmp(DFA_Doc,"") !=0 )
														{ 
															printf("\n\t\t DFA_Doc : %s",DFA_Doc);
															tc_strcat(FourDdocs,DFA_Doc);
															tc_strcat(FourDdocs,",");																			
														}
														if(tc_strcmp(DFA_Doc,"") ==0 )
														{
															tc_strcpy(DFA_Doc,"NA"); 
															printf("\n\t\t DFA_Doc : %s",DFA_Doc);
															tc_strcat(FourDdocs,DFA_Doc);                 
															tc_strcat(FourDdocs,","); 																			
														}
											
														if(tc_strcmp(DFS_Doc,"") !=0 )
														{
															printf("\n\t\t DFS_Doc : %s",DFS_Doc);
															tc_strcat(FourDdocs,DFS_Doc);                  
															//tc_strcat(FourDdocs,",");                    
														}
														if(tc_strcmp(DFS_Doc,"") ==0 )
														{
															tc_strcpy(DFS_Doc,"NA"); 
															printf("\n\t\t DFS_Doc : %s",DFS_Doc);
															tc_strcat(FourDdocs,DFS_Doc);                 																			
														}
																															
												   }
												   else
												   {
													   tc_strcat(FourDdocs,"NA,NA,NA,NA");
												   }
											
												   tc_strcpy(part_details,PNo);
												   tc_strcat(part_details,",");
												   tc_strcat(part_details,PRev);
												   tc_strcat(part_details,",");
												   tc_strcat(part_details,PSeq);
												   tc_strcat(part_details,",");
												   tc_strcat(part_details,PType1);
												   tc_strcat(part_details,",");
												   tc_strcat(part_details,FourDdocs);
												      														      
												      
												   printf("\n\n\t\t All 4d Doc %s \n\n",part_details);fflush(stdout);fflush(stdout);
												      											
												   tc_strcat(PartDetFullStr,part_details);
												   tc_strcat(PartDetFullStr,"$");																   
												  
												   //printf("\nPartDetFullStr 1 : %s",PartDetFullStr);fflush(stdout);
											
											
												}
											
												if (tc_strcmp(item_type,"Folder")==0)
												{
											
												   ITK_CALL(AOM_UIF_ask_value(ChRefItm,"object_string", &Folder_name7));	
												   printf("\nFolder_name : [%s]",Folder_name7);fflush(stdout);
												      
												   if (tc_strcmp(Folder_name7,"Parts For Gate Maturation")==0)
												   {
													  printf("\nINSIDE Folder");fflush(stdout);
													     
													  ITK_CALL(AOM_ask_value_tags(ChRefItm,"contents",&iCount7, &Part_tag7));
													  printf("\nFolder Parts Count : [%d] \n",iCount7);fflush(stdout);
													     
													  for(T=0;T<iCount7;T++)
													  {
											
													    PartPtr7 = Part_tag7[T];
											
														ITK_CALL(AOM_UIF_ask_value(PartPtr7,"item_id", &itemid7));
														//ITK_CALL(AOM_UIF_ask_value(PartPtr7,"item_revision_id", &itemRevid7));
											
														ITK_CALL(ITEM_find_item(itemid7, &itemTag7));
														ITK_CALL(ITEM_ask_latest_rev(itemTag7,&partRevTag7));
											
														ITK_CALL(AOM_UIF_ask_value(partRevTag7, "item_id", &PNo7));
														printf("\nPNo7 : [%s]",PNo7);fflush(stdout);
											
														ITK_CALL(AOM_UIF_ask_value(PartPtr7, "item_revision_id", &PRev9));
														printf("\nPRev9 : [%s]",PRev9);fflush(stdout);
											
														PRev7=tc_strtok(PRev9, ";");
														printf("\nPRev7 : [%s]",PRev7);fflush(stdout);
											
														PSeq7=tc_strtok(NULL, "");																		
														printf("\nPSeq7 : [%s]",PSeq7);fflush(stdout);
											
														ITK_CALL(AOM_ask_value_string(PartPtr7, "t5_PartType", &PType7));
														printf("\nPType7 : [%s]",PType7);fflush(stdout);
											
														ITK_CALL(GRM_find_relation_type ( "T5_PartHas4D", &PartHas4D_rel )); //Part has 4D
														ITK_CALL(GRM_list_secondary_objects_only ( PartPtr7, PartHas4D_rel, &soDadObjs, &soDadRelObj ));
											
														ITK_CALL(GRM_find_relation_type ( "T5_PartHasDfmea", &Dfmea_tsk_rel_type )); //Part has Dfmea
														ITK_CALL(GRM_list_secondary_objects_only ( PartPtr7, Dfmea_tsk_rel_type, &Dfmeacount, &DfmeRevision ));
											
														ITK_CALL(GRM_find_relation_type ( "T5_PartHasRef4DDfmea", &PartRefDFMEA_rel )); //Part has Ref4D Dfmea
														ITK_CALL(GRM_list_secondary_objects_only ( PartPtr7, PartRefDFMEA_rel, &soRefObjs, &soRefRelObjs ));
											
											
														if( (soDadObjs > 0) || (Dfmeacount > 0) || (soRefObjs > 0) )
														{
													   
														    if (Dfmeacount > 0) //Part has Dfmea
															{
																for (o = 0;o < Dfmeacount ; o++)
																{
																	Dfmea = DfmeRevision[o];
															        ITK_CALL(AOM_UIF_ask_value(Dfmea,"item_id", &InDFmeaPrt));
																	//printf("\n Part has Dfmea Id: IS >>>>>>>>>>>>>>>>>>> %s",InDFmeaPrt);
											
																	if((tc_strcmp(InDFmeaPrt,"") !=0))
																	{
																		  tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);
																	} 
											
																	if (tc_strcmp(InDFmeaPrtDup,"")!=0)
																	{
																		tc_strcpy(DfmeaDoc,InDFmeaPrtDup);
																	}
																												                          
																 }
											
															}
														
											
															if (soRefObjs > 0) //Part has Ref4D Dfmea
															{
															
																for (p = 0;p < soRefObjs ; p++)
																{
																	Ref4DDfmea = soRefRelObjs[p];
											
																	ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea,"object_type", &item_type));
																	//printf("\n item_type : [%s]",item_type);
																	
																	if ((tc_strcmp(item_type,"DAD Doc Revision")==0) ||  (tc_strcmp(item_type,"Dfmea Revision")==0))
																	{
											
																		ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea,"item_id", &InDadFmeaPrt));
																		//printf("\n Part has Ref4D Dfmea Id: IS >>>>>>>>>>>>>>>>>>> %s",InDadFmeaPrt);
											
																		if((tc_strcmp(InDadFmeaPrt,"") !=0))
																		{
																			tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
																		}
											
																		ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea, "object_type" ,&InDadFmeaPrttype));
																		//printf("\n Part has Ref4D Dfmea type Id: IS >>>>>>>>>>>>>>>>>>> %s",InDadFmeaPrttype);
																		if((tc_strcmp(InDadFmeaPrttype,"") !=0))
																		{
																			tc_strcpy(InDadFmeaClassDup,InDadFmeaPrttype);
																		}
											
																		if((tc_strcmp(InDadFmeaClassDup,"Dfmea Revision") == 0) )
																		{
											
																			ITK_CALL(AOM_UIF_ask_value(Ref4DDfmea,"item_id", &InDFmeaPrt));
											
																			if((tc_strcmp(InDFmeaPrt,"") !=0))
																			{
																				tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);
											
																			}
													
																			if (tc_strcmp(InDFmeaPrtDup,"")!=0)
																			{
																				tc_strcpy(DfmeaDoc,InDFmeaPrtDup);
																			}
																			
																		}
											
																		if (tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
																		{
																			tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
																		}
																		
																		else if (tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
																		{
																			tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
																		}
																		
																		else if (tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
																		{
																			tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
																		}
											
											
																	}
											
																}
											
											
															}
											
															if (soDadObjs > 0) //Part has 4D
															{
																for (n = 0; n < soDadObjs ;n++ )
																{
																	fordDco = soDadRelObj[n];
											
																	ITK_CALL(AOM_UIF_ask_value(fordDco,"object_type", &item_type));
																	//printf("\n item_type : [%s]",item_type);
																	
																	if (tc_strcmp(item_type,"DAD Doc Revision")==0)
																	{
											
																		ITK_CALL(AOM_UIF_ask_value(fordDco,"item_id", &InDadFmeaPrt));
																		//printf("\n Part has 4D Id: IS >>>>>>>>>>>>>>>>>>> %s",InDadFmeaPrt);
											
																		if((tc_strcmp(InDadFmeaPrt,"") !=0))
																		{
																				tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
																		}
																		
																		if (tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
																		{
																			tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
																		}
																		
																		else if (tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
																		{
																			tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
																		}
																		
																		else if (tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
																		{
																			tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
																		}
																
																	}
															        
																}
															}
															
															if(tc_strcmp(DfmeaDoc,"") !=0 )
															{
																printf("\n\t\t DFMEA_Doc : %s",DfmeaDoc);
																tc_strcpy(FourDdocs,DfmeaDoc);
																tc_strcat(FourDdocs,",");
															}
															if(tc_strcmp(DfmeaDoc,"") ==0 )
															{
																tc_strcpy(DfmeaDoc,"NA"); 
																printf("\n\t\t DFMEA_Doc : %s",DfmeaDoc);
																tc_strcat(FourDdocs,DfmeaDoc);               
																tc_strcat(FourDdocs,",");                     
															}
											
															if(tc_strcmp(DFM_Doc,"") !=0 )
															{
																printf("\n\t\t DFM_Doc : %s",DFM_Doc);
																tc_strcat(FourDdocs,DFM_Doc);
																tc_strcat(FourDdocs,",");
											
															}
															if(tc_strcmp(DFM_Doc,"") ==0 )
															{
																tc_strcpy(DFM_Doc,"NA");
																printf("\n\t\t DFM_Doc : %s",DFM_Doc);
																tc_strcat(FourDdocs,DFM_Doc);
																tc_strcat(FourDdocs,",");																			
															}
											
															if(tc_strcmp(DFA_Doc,"") !=0 )
															{ 
																printf("\n\t\t DFA_Doc : %s",DFA_Doc);
																tc_strcat(FourDdocs,DFA_Doc);
																tc_strcat(FourDdocs,",");																			
															}
															if(tc_strcmp(DFA_Doc,"") ==0 )
															{
																tc_strcpy(DFA_Doc,"NA"); 
																printf("\n\t\t DFA_Doc : %s",DFA_Doc);
																tc_strcat(FourDdocs,DFA_Doc);                 
																tc_strcat(FourDdocs,","); 																			
															}
											
															if(tc_strcmp(DFS_Doc,"") !=0 )
															{
																printf("\n\t\t DFS_Doc : %s",DFS_Doc);
																tc_strcat(FourDdocs,DFS_Doc);                  
																//tc_strcat(FourDdocs,",");                    
															}
															if(tc_strcmp(DFS_Doc,"") ==0 )
															{
																tc_strcpy(DFS_Doc,"NA"); 
																printf("\n\t\t DFS_Doc : %s",DFS_Doc);
																tc_strcat(FourDdocs,DFS_Doc);                 																			
															}
																															
														}
														else
														{
														   tc_strcpy(FourDdocs,"NA,NA,NA,NA");
														}
											
														tc_strcpy(part_details,PNo7);
														tc_strcat(part_details,",");
														tc_strcat(part_details,PRev7);
														tc_strcat(part_details,",");
														tc_strcat(part_details,PSeq7);
														tc_strcat(part_details,",");
														tc_strcat(part_details,PType7);
														tc_strcat(part_details,",");
														tc_strcat(part_details,FourDdocs);
														   														      
														   
														printf("\n\n\t\t All 4d Doc %s \n\n",part_details);fflush(stdout);
														   
														tc_strcat(PartDetFullStr,part_details);
												        tc_strcat(PartDetFullStr,"$");
																									
														//printf("\n\nPartDetFullStr 2 : %s",PartDetFullStr);fflush(stdout);
											
													  }
													 
											
												   }
											
												}
													
											
											}
							  
							 		    }
								
							  
							 		}
							 		
							  
							  }

                         }


					}

					if (tc_strcmp(PartDetFullStr,"")!= 0) 
					{
						printf("\n\n\nALL Parts List : [%s]\n",PartDetFullStr);fflush(stdout);
					
						char *tokDup  =   NULL;
						int count1 = 1;
						char *PartDetFullStrDup = NULL;
						char *tok  =   NULL;
						PartDetFullStrDup=(char* )MEM_alloc(50000 * sizeof(char) );
						tc_strcpy(PartDetFullStrDup,PartDetFullStr);


						tokDup = tc_strtok(PartDetFullStrDup,"$");
						while (tokDup != NULL)
						{			

								if ( (tc_strcmp(tokDup,"")!=0))
								{
									printf("\ntokDup : %s\n",tokDup);fflush(stdout);
									printf("\ncount1 : %d\n",count1);fflush(stdout);
									count1++;

								}
								tokDup = tc_strtok(NULL, "$");			
								
						 
						}
						//printf("\n\nTotal Parts : %d\n",count1);fflush(stdout);


						cString->__size = count1;
						cString->__ptr = malloc( (cString->__size + 1) * sizeof(*cString->__ptr) );

						for(d=0;d<count1;d++)
						{
							cString->__ptr[d].Part_Details = malloc(70000 * sizeof(char *) );
						}


						tok = tc_strtok(PartDetFullStr,"$");
						int t=0;

						while (tok != NULL)
						{			

								if ( (tc_strcmp(tok,"")!=0))
								{
									//printf("\ntok : %s\n",tok);fflush(stdout);
									tc_strcpy(cString->__ptr[t].Part_Details,tok);
									t++;
									//printf("\nt : %d\n",t);fflush(stdout);

								}
								tok = tc_strtok(NULL, "$");			
								
						 
						}

					}						


				}

	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;

 CLEANUP :
	   
		return SOAP_OK;

EXIT:
		return SOAP_OK;

}
			




int ns__Part_Details(struct soap* soap,char *DmlNumber, char *PartNumber, char *Revision, char *Sequence,struct ns__CharArray1 *bString)
{

	int  d =0,mstar=0;
	int  count =0;
	int  e,i,DadPrtObjCnt,ii =0,k=0;
	int  Dmlcount ;
	int  Apl_tskc;
	int  iCount;
	int  iCount2;
	int  iCount3;
	int  iCount4;
	int  iCount5;
	int  iCount6;
	int  j;
	int  P;
	int  K;
	int  M;
	int  l=0;
	int  Pconut;
	int  PlantObjs;
	int  soDadObjs      = 0;
	int  soRefObjs      = 0;
	int  dfmdocObj      = 0;
	int  status         = ITK_ok;
	int  Tskcount;
	int  Tskcount2;
	int  Dmlcount2;  
	int  PlantDmlcount;
	int  InputCount;

	char*  partNo			 = NULL;
	char*  uname			 = NULL;
	char*  pass			     = NULL;
	char*  partNodup		 = NULL;
	char*  responseString    = NULL;
	char*  InDadFmeaPrt	     = NULL;
	char*  InDadFmeaPrtDup   = NULL;
	char*  InDadFmeaClass    = NULL;
	char*  InDadFmeaClassDup = NULL;
	char*  FourDdocs		 = NULL;
	char*  PNo			     = NULL;
	char*  PNo2			     = NULL;
	char*  itemid            = NULL;
	char**  InputItem        = NULL;
	char*  InputRev          = NULL;
	char*  InputSeq          = NULL;
	char*  itemRevid         = NULL;
	char*  itemRevid2         = NULL;
	char*  PRev			     = NULL;
	char*  PRev1		     = NULL;
	char*  PRev2		     = NULL;
	char*  PRev3		     = NULL;
	char*  PSeq			     = NULL;
	char*  PSeq2			     = NULL;
	char*  PType		     = NULL;
	char*  PartStr		     = NULL;
	char*  PartStr_in	     = NULL;
	char*  ChldPNo		     = NULL;
	char*  ChldPNoDup	     = NULL;
	char*  ChldPRevDup	     = NULL;
	char*  ChldPRev		     = NULL;
	char*  ChldPSeqDup	     = NULL;
	char*  ChldPSeq		     = NULL;
	char*  ChldPartStr	     = NULL;
	char*  InDFmeaPrt		 = NULL;
	char*  InDFmeaPrtDup	 = NULL;
	char*  DFMEA_Doc		 = NULL;
	char*  DFM_Doc			 = NULL;
	char*  DFA_Doc			 = NULL;
	char*  DFS_Doc			 = NULL;
	char*  TaskNo			 = NULL;
	char*  TaskNoDup		 = NULL;
	char*  part_details	     = NULL;
	char*  Part_no		     = NULL;
	char*  Folder_name		     = NULL;
	char*  s	 = NULL;
	char*  PlantDml_release_status  = NULL;
	char*  Tsk_release_status       = NULL;
	char*  DmlTask_release_status   = NULL;
	char*  Erc_release_status       = NULL;
	char*  TskTag_Type              = NULL;
	char*  ErcDmlNo                 = NULL;
	char*  PlantObjNo               = NULL;
	char*  PlantObj_type            = NULL;
	char*  DmlTask_type             = NULL;
	char*  DmlTaskNo                = NULL;
	char*  PlantDmlid               = NULL;
	char*  ErcDmlDmlid              = NULL;
	char*  ErcDMLRelStatus          = NULL;
	char*  PType1                   = NULL;
	char*  PType2                   = NULL;
	char*  item_type                = NULL;
	char*  type_name1                = NULL;


	tag_t *  Part_tag	          = NULL;
	tag_t   partRevTag	          = NULL;
	tag_t   partRevTag2	          = NULL;
	tag_t   DmlPtr		          = NULL;
	tag_t   Pitem		          = NULL;
	tag_t   itemTag		          = NULL;
	tag_t   itemTag2		          = NULL;
	tag_t   InputItemTag		  = NULL;
	tag_t   InputRevTag		      = NULL;
	tag_t   InputSeqTag		      = NULL;
	tag_t   Part_InDadPrtObj_Ptr  = NULLTAG;
	tag_t   query	              = NULLTAG;
	tag_t   TskTag			      = NULLTAG;
	tag_t   ErcDmlPtr	          = NULLTAG;
	tag_t   dml_tsk_rel_type      = NULLTAG;
	tag_t   Plantdml_tsk_rel_type = NULLTAG;
	tag_t   partPtr               = NULLTAG;
	tag_t   ChRefpartPtr          = NULLTAG;
	tag_t   PartPtr1			  = NULLTAG;
	tag_t   GateMatuPtr           = NULLTAG;
	tag_t   PartHasDfmea_rel      = NULLTAG;
	tag_t   PartHas4D_rel         = NULLTAG;
	tag_t   PartRefDFMEA_rel      = NULLTAG;
	tag_t   PlantDmlTag	          = NULLTAG;
	tag_t   PlantObjPtr	          = NULLTAG;
	tag_t   DmlTaskPtr	          = NULLTAG;
	tag_t   Plantitem	          = NULLTAG;
	tag_t   tsk_design_rev_rel	  = NULLTAG;
	tag_t   Part_rel	          = NULLTAG;
	tag_t   ChangeRef_rel	      = NULLTAG;
	tag_t   Content_rel	      = NULLTAG;
	tag_t   PlantDml_rel	      = NULLTAG;
	tag_t   priObjTypeTag	     = NULLTAG;
	tag_t   Folder_type	     = NULLTAG;

	tag_t*  taskObjsRel	     = NULLTAG;
	tag_t*	DMLList		     = NULLTAG;
	tag_t*  TskItem	         = NULL;
	tag_t*  partObjs	     = NULLTAG;
	tag_t*  ChRefpartObjs	 = NULLTAG;
	tag_t*  FolderpartObjs	 = NULLTAG;
	tag_t*  GateMatuObjs	 = NULLTAG;
	tag_t*  soResult1	     = NULL;
	tag_t*  part_revs	     = NULL;
	tag_t*	PartMstersSet	 = NULL;
	tag_t*	PartMstersSetRel = NULL;
	tag_t*	soTCPart		 = NULL;
	tag_t*	soTCPartRel		 = NULL;
	tag_t*  soDadRelObj	     = NULLTAG;
	tag_t*  dfmdocRelObj	 = NULLTAG;
	tag_t  Folder_rel		 = NULLTAG;
	tag_t*  soRefRelObjs	 = NULLTAG;
	tag_t*	soResult	     = NULLTAG;
	tag_t*	soResult2	     = NULLTAG;
	tag_t*	PlantDmls	     = NULLTAG;
	tag_t*	taskDmls	     = NULLTAG;
	tag_t*  PlantObjsRel	 = NULLTAG;
	tag_t*  DmlTaskObjs	     = NULLTAG;

	part_details=NULL;
    part_details=malloc(5000);

	char*   dmlid            = NULL;
    tag_t   dmlidTag	     = NULL;
    tag_t   dmllatRevTag	 = NULL;



	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/dml.txt", "a", stdout);

	char**  qry_values    = NULL;
	char*   qry_entry[1]  = {"ID"};
	qry_values = (char **) MEM_alloc(100 * sizeof(char *));

	bString->__size =1;
	bString->__ptr = malloc( (bString->__size + 1) * sizeof(*bString->__ptr) );

	bString->__ptr[0].FourD_Doc_Numbers = malloc(500 * sizeof(char *) );
	bString->__ptr[0].Part_Number = malloc(50 * sizeof(char *) );
	bString->__ptr[0].Part_Sequence = malloc(10 * sizeof(char *) );
	bString->__ptr[0].Part_Revision = malloc(10 * sizeof(char *) );
	bString->__ptr[0].DML_Number = malloc(15 * sizeof(char *) );


	//**************************For Auto Login**************************//

		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		ITK_CALL(ITK_auto_login());
		ITK_set_bypass(true);

		ITK_CALL(ITK_set_journalling(TRUE));
		if (status == 0 )
		{
		  printf("\n Auto login to Teamcenter successful \n");
		  fflush(stdout);
		}
		else
		{
		  printf("\n Error code:%d",status);fflush(stdout);
		  EMH_ask_error_text(status,&s);
		  //printf("\n Error message:%s",s);fflush(stdout);
		}

	//**************************Ended**************************//

	//tc_strcpy(bString->__ptr[0].DML_Number,"1234");
	//tc_strcpy(bString->__ptr[0].Part_Number,"1234");
	//tc_strcpy(bString->__ptr[0].Part_Revision,"A");
	//tc_strcpy(bString->__ptr[0].Part_Sequence,"1");
	//tc_strcpy(bString->__ptr[0].FourD_Doc_Numbers,"");


	printf("\n\n ******* Part_Details *****DBK \n");fflush(stdout);



	if(QRY_find2("ERC DML Revision",&query));
	{
		if (query)
		{
			qry_values[0] = (char *)MEM_alloc( strlen( DmlNumber ) + 1);
			tc_strcpy(qry_values[0], DmlNumber  );

			ITK_CALL(QRY_execute(query, 1, qry_entry, qry_values, &Dmlcount2, &soResult2));
			//printf("\nDmlcount2 : [%d]",Dmlcount2);

			if(Dmlcount2 > 0)
			{
			
			   	 ErcDmlPtr = soResult2[0];

				 ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr,"item_id",&dmlid));
				 printf("\nDML id ==> %s",dmlid);fflush(stdout);    

				 ITK_CALL(ITEM_find_item(dmlid, &dmlidTag));
				 ITK_CALL(ITEM_ask_latest_rev(dmlidTag,&dmllatRevTag));	


			     ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr,"current_id",&ErcDmlNo));
				 printf("\nErcDml : [%s]",ErcDmlNo);

			     ITK_CALL(AOM_UIF_ask_value(ErcDmlPtr,"release_status_list",&ErcDMLRelStatus));
				 printf("\nErcDMLRelStatus : [%s]",ErcDMLRelStatus);

			     ITK_CALL(GRM_find_relation_type ( "T5_DMLTaskRelation", &PlantDml_rel ));
			     ITK_CALL(GRM_list_secondary_objects_only ( dmllatRevTag,PlantDml_rel, &PlantObjs, &PlantObjsRel ));

				 
			     if (PlantObjs > 0)
			     {
					for ( Apl_tskc= 0 ; Apl_tskc < PlantObjs ; Apl_tskc++ )
					{
						PlantObjPtr = PlantObjsRel[Apl_tskc];

						ITK_CALL(AOM_UIF_ask_value(PlantObjPtr,"current_id",&PlantObjNo));
						printf("\nErcTaskDml : [%s]",PlantObjNo);

						ITK_CALL(AOM_UIF_ask_value(PlantObjPtr,"release_status_list",&Tsk_release_status));
						printf("\nErcTskRelStatus : [%s]",Tsk_release_status);

						ITK_CALL(AOM_UIF_ask_value(PlantObjPtr, "object_type", &PlantObj_type));
						printf("\nPlantObj_type : [%s]",PlantObj_type);

						
							
							if (tc_strcmp(PlantObj_type,"ERC Task Revision") == 0)
							{
													
								ITK_CALL( GRM_find_relation_type ( "CMHasSolutionItem", &Part_rel ) );
								ITK_CALL( GRM_list_secondary_objects_only ( PlantObjPtr, Part_rel, &iCount3, &partObjs ) );
								//printf("\niCount3 : [%d]",iCount3);


									if ( iCount3 > 0 )
									{
										//printf("\nInside1  :");

										for(P=0;P<iCount3;P++)
										{
											//printf("\nInside2  :");

											partPtr = partObjs[P];

											ITK_CALL(AOM_UIF_ask_value(partPtr,"item_id", &itemid));
											printf("\nitemid : [%s]",itemid);

											ITK_CALL(AOM_UIF_ask_value(partPtr,"object_type", &item_type));
											printf("\nitem_type : [%s]",item_type);
											 
											if ((tc_strcmp(item_type,"Design Revision")==0) || (tc_strcmp(item_type,"EE Part Revision")==0)) //18.06.24
											//if (tc_strcmp(item_type,"Design Revision")==0) 
											{

											   ITK_CALL(AOM_UIF_ask_value(partPtr,"item_id", &itemid));

											   ITK_CALL(AOM_UIF_ask_value(partPtr,"item_revision_id", &itemRevid));

											   ITK_CALL(ITEM_find_item(itemid, &itemTag));
											   ITK_CALL(ITEM_ask_latest_rev(itemTag,&partRevTag));

											   ITK_CALL(AOM_UIF_ask_value(partRevTag, "item_id", &PNo));
											   printf("\nPNo : [%s]",PNo);

											   ITK_CALL(AOM_UIF_ask_value(partPtr, "item_revision_id", &PRev1));
											   printf("\nPRev1 : [%s]",PRev1);

											   //char *str = PRev;
											   //char *token = strtok(str, ";");

											   //while (token != NULL)
											   //{											    
											      //token = strtok(NULL, ";");
											   //}

											   PRev=tc_strtok(PRev1, ";");
											   printf("\nPRev : [%s]",PRev);
											   PSeq=tc_strtok(NULL, "");

											   //ITK_CALL(AOM_UIF_ask_value(partPtr, "sequence_id", &PSeq));
											   printf("\nPSeq : [%s]",PSeq);

											   ITK_CALL(AOM_ask_value_string(partPtr, "t5_PartType", &PType1));
											   printf("\nPType1 : [%s]",PType1);	
											   
											   //printf("\n\nDmlNumber  :%s",DmlNumber);fflush(stdout);  
											   //printf("\nPartNumber :%s",PartNumber);fflush(stdout); 
											   //printf("\nRevision   :%s",Revision);fflush(stdout);   
											   //printf("\nSequence   :%s \n\n\n",Sequence);fflush(stdout); 

											   if( (tc_strcmp(PNo,PartNumber) == 0) && (tc_strcmp(PRev,Revision) == 0) && (tc_strcmp(PSeq,Sequence) == 0) )
											   {	
													char*  FourDdocs		 = NULL;
		                                            char*  InDFmeaPrtDup	 = NULL;
		                                            char*  InDFmeaPrt		 = NULL;
		                                            char*  DFMEA_Doc		 = NULL;
		                                            char*  InDadFmeaPrt	     = NULL;
		                                            char*  InDadFmeaPrtDup   = NULL;
		                                            char*  DFM_Doc			 = NULL;
		                                            char*  DFA_Doc			 = NULL;
		                                            char*  DFS_Doc			 = NULL;
		                                            char*  InDadFmeaClassDup = NULL;
		                                            char*  part_details	     = NULL;

		                                            tag_t   Part_InDadPrtObj_Ptr  = NULLTAG;
		                                            int  DadPrtObjCnt;
		                                            int  status         = ITK_ok;														        	                                                  
                                                    FourDdocs=malloc(500);  
													tc_strcpy(FourDdocs,"");

       	                                            InDadFmeaPrtDup=malloc(300);
       	                                            InDadFmeaClassDup=malloc(300);
       	                                            InDFmeaPrtDup=malloc(300);
													part_details=malloc(1000);
													
       	                                            DFMEA_Doc=malloc(500);	
													tc_strcpy(DFMEA_Doc,"");
       	                                            DFM_Doc=malloc(300);
													tc_strcpy(DFM_Doc,"");
       	                                            DFA_Doc=malloc(300);
													tc_strcpy(DFA_Doc,"");
       	                                            DFS_Doc=malloc(300);
													tc_strcpy(DFS_Doc,"");


													ITK_CALL( GRM_find_relation_type ( "T5_PartHas4D", &PartHas4D_rel ) );  //Part has 4D
													ITK_CALL( GRM_list_secondary_objects_only ( partPtr, PartHas4D_rel, &soDadObjs, &soDadRelObj ) );
													
													ITK_CALL( GRM_find_relation_type ( "T5_PartHasDfmea", &PartHasDfmea_rel ) ); //Part has Dfmea
													ITK_CALL( GRM_list_secondary_objects_only ( partPtr, PartHasDfmea_rel, &dfmdocObj, &dfmdocRelObj ) );

													ITK_CALL( GRM_find_relation_type ( "T5_PartHasRef4DDfmea", &PartRefDFMEA_rel ) ); //Part has Ref4D Dfmea
													ITK_CALL( GRM_list_secondary_objects_only ( partPtr, PartRefDFMEA_rel, &soRefObjs, &soRefRelObjs ) );


                                                       if ((soDadObjs > 0) || (dfmdocObj > 0) || (soRefObjs > 0))
                                                       {
														   
															if(dfmdocObj > 0) //Part has Dfmea
		                                                    {     	                                                  	 
																for(DadPrtObjCnt=0;DadPrtObjCnt<(dfmdocObj);DadPrtObjCnt++)
																{
																     
																     Part_InDadPrtObj_Ptr = dfmdocRelObj[DadPrtObjCnt];

																     ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id", &InDFmeaPrt));
																     
																     if((tc_strcmp(InDFmeaPrt,"") !=0))
																     {
																     	  tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);
																     }

																	 if (tc_strcmp(InDFmeaPrtDup,"") != 0)
																	 {																    
																		tc_strcpy(DFMEA_Doc,InDFmeaPrtDup);
																	 }
																																
																}
															}
															
       	                                                    if(soRefObjs > 0) //Part has Ref4D Dfmea
       	                                                    {
																for(DadPrtObjCnt=0;DadPrtObjCnt<(soRefObjs);DadPrtObjCnt++)
																{      	                                                  			
																	Part_InDadPrtObj_Ptr = soRefRelObjs[DadPrtObjCnt];

																	ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr,"object_type", &item_type));
																	
																	if ((tc_strcmp(item_type,"DAD Doc Revision")==0) ||  (tc_strcmp(item_type,"Dfmea Revision")==0))
																	{

																		ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id" ,&InDadFmeaPrt));
																		if((tc_strcmp(InDadFmeaPrt,"") !=0))
																		{
																			tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
																		}
																  
																		ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "object_type" ,&InDadFmeaPrt));
																		if((tc_strcmp(InDadFmeaPrt,"") !=0))
																		{
																			tc_strcpy(InDadFmeaClassDup,InDadFmeaPrt);
																		}

																		if((tc_strcmp(InDadFmeaClassDup,"Dfmea Revision") == 0) )
																		{
																			ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id" ,&InDFmeaPrt));

																			if((tc_strcmp(InDFmeaPrt,"") !=0))
																		    {
																		   		tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);

																		    }

																			if (tc_strcmp(InDFmeaPrtDup,"") != 0)
																			{
																				tc_strcpy(DFMEA_Doc,InDFmeaPrtDup);
																			}
																			
																			
																		}

																		if(tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
																		{      	                                                  				
																			tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
																		}
																		
																		else if(tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
																		{       	                                                  				
																			tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
																		}
																		
																		else if(tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
																		{       	                                                  				
																			tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
																		}

																	}
																	

																}

       	                                                    }
															
															if(soDadObjs > 0) //Part has 4D
       	                                                    {
																for(DadPrtObjCnt=0;DadPrtObjCnt<(soDadObjs);DadPrtObjCnt++)
																{
																	   
																	   Part_InDadPrtObj_Ptr = soDadRelObj[DadPrtObjCnt];

																	   ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr,"object_type", &item_type));
																	   
																	   if (tc_strcmp(item_type,"DAD Doc Revision")==0)
																	   {
																	   
																			ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id", &InDadFmeaPrt));
  
																			if((tc_strcmp(InDadFmeaPrt,"") !=0))
																			{
																					tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
																			}
																	  
																			if(tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
																			{      	                                                  				
																				tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
																			}
																	  
																			else if(tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
																			{       	                                                  				
																				tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
																			}																  

																			else if(tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
																			{       	                                                  				
																				tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
																			}
																	 
																																	
																	   }

																}

       	                                                    }

															if(tc_strcmp(DFMEA_Doc,"") !=0 )
															{
																printf("\n\t\t DFMEA_Doc : %s",DFMEA_Doc);
																tc_strcpy(FourDdocs,DFMEA_Doc);
																tc_strcat(FourDdocs,",");
															}
															if(tc_strcmp(DFMEA_Doc,"") ==0 )
															{
																tc_strcpy(DFMEA_Doc,"NA");
																printf("\n\t\t DFMEA_Doc : %s",DFMEA_Doc);
																tc_strcat(FourDdocs,DFMEA_Doc);               
																tc_strcat(FourDdocs,",");                     
															}

															if(tc_strcmp(DFM_Doc,"") !=0 )
															{
																printf("\n\t\t DFM_Doc : %s",DFM_Doc);
																tc_strcat(FourDdocs,DFM_Doc);
																tc_strcat(FourDdocs,",");
															}
															if(tc_strcmp(DFM_Doc,"") ==0 )
															{
																tc_strcpy(DFM_Doc,"NA");
																printf("\n\t\t DFM_Doc : %s",DFM_Doc);
																tc_strcat(FourDdocs,DFM_Doc);
																tc_strcat(FourDdocs,",");
																
															}

															if(tc_strcmp(DFA_Doc,"") !=0 )
															{ 
																printf("\n\t\t DFA_Doc : %s",DFA_Doc);
																tc_strcat(FourDdocs,DFA_Doc);
																tc_strcat(FourDdocs,",");
																
															}
															if(tc_strcmp(DFA_Doc,"") ==0 )
															{
																tc_strcpy(DFA_Doc,"NA"); 
																printf("\n\t\t DFA_Doc : %s",DFA_Doc);
																tc_strcat(FourDdocs,DFA_Doc);                 
																tc_strcat(FourDdocs,","); 
																
															}

															if(tc_strcmp(DFS_Doc,"") !=0 )
															{
																printf("\n\t\t DFS_Doc : %s",DFS_Doc);
																tc_strcat(FourDdocs,DFS_Doc);                  
																tc_strcat(FourDdocs,",");                    
															}
															if(tc_strcmp(DFS_Doc,"") ==0 )
															{
																tc_strcpy(DFS_Doc,"NA");
																printf("\n\t\t DFS_Doc : %s",DFS_Doc);
																tc_strcat(FourDdocs,DFS_Doc);                 
																
															}
       	                                                    
													   }
                                                       else
                                                       {                                                          	  
                                                       	  tc_strcpy(FourDdocs,"NA,NA,NA,NA");
                                                       }

                                                       
                                                       tc_strcpy(part_details,PNo);
                                                       tc_strcat(part_details,",");
                                                       tc_strcat(part_details,PRev);
                                                       tc_strcat(part_details,",");
                                                       tc_strcat(part_details,PSeq);
                                                       tc_strcat(part_details,",");
                                                       tc_strcat(part_details,PType1);
                                                       tc_strcat(part_details,",");
                                                       tc_strcat(part_details,FourDdocs);
                                                       
													   tc_strcpy(bString->__ptr[0].DML_Number,ErcDmlNo);
				                                       tc_strcpy(bString->__ptr[0].Part_Number,PNo);
				                                       tc_strcpy(bString->__ptr[0].Part_Revision,PRev);
				                                       tc_strcpy(bString->__ptr[0].Part_Sequence,PSeq);
				                                       tc_strcpy(bString->__ptr[0].FourD_Doc_Numbers,FourDdocs);

													   printf("\n\t\t All 4d Doc %s \n\n\n",part_details);    

											   }
											   //else
											   //{											     
												  //continue; 

											}

										}

									}
									else // reference parts
									{
										ITK_CALL( GRM_find_relation_type ( "CMReferences", &ChangeRef_rel ) );
										ITK_CALL( GRM_list_secondary_objects_only ( PlantObjPtr, ChangeRef_rel, &iCount4, &ChRefpartObjs ) );

										//printf("\niCount4 : [%d]",iCount4);
											
										if ( iCount4 > 0 )
										{

											for(K=0;K<iCount4;K++)
											{
												
												ChRefpartPtr = ChRefpartObjs[K];

												ITK_CALL(AOM_UIF_ask_value(ChRefpartPtr,"object_type", &item_type));
												printf("\nitem_type : [%s]",item_type);

												//if ( (tc_strcmp(item_type,"Design Revision")==0) || (tc_strcmp(item_type,"Folder")==0) ) //13.02.24 
												if ( (tc_strcmp(item_type,"Design Revision")==0) || (tc_strcmp(item_type,"Folder")==0) || (tc_strcmp(item_type,"EE Part Revision")==0) ) // 18.06.24
												{

													if ((tc_strcmp(item_type,"Design Revision")==0) || (tc_strcmp(item_type,"EE Part Revision")==0)) // 18.06.24
													//if (tc_strcmp(item_type,"Design Revision")==0)
													{
													
														ITK_CALL(AOM_UIF_ask_value(ChRefpartPtr,"item_id", &itemid));
														printf("\nitemid : [%s]",itemid);
														ITK_CALL(AOM_UIF_ask_value(ChRefpartPtr,"item_revision_id", &itemRevid));
														
														ITK_CALL(ITEM_find_item(itemid, &itemTag));
														ITK_CALL(ITEM_ask_latest_rev(itemTag,&partRevTag));
														
														ITK_CALL(AOM_UIF_ask_value(partRevTag, "item_id", &PNo));
														printf("\nPNo : [%s]",PNo);
														
														ITK_CALL(AOM_UIF_ask_value(ChRefpartPtr, "item_revision_id", &PRev1));
														printf("\nPRev1 : [%s]",PRev1);
															
														PRev=tc_strtok(PRev1, ";");
														printf("\nPRev : [%s]",PRev);
														PSeq=tc_strtok(NULL, "");
																							    
														//ITK_CALL(AOM_UIF_ask_value(ChRefpartPtr, "sequence_id", &PSeq));
														printf("\nPSeq : [%s]",PSeq);

														ITK_CALL(AOM_ask_value_string(ChRefpartPtr, "t5_PartType", &PType1));
														printf("\nPType2 : [%s]\n",PType1);
	
														//printf("\n\nDmlNumber  :%s",DmlNumber);fflush(stdout);  
														//printf("\nPartNumber :%s",PartNumber);fflush(stdout); 
														//printf("\nRevision   :%s",Revision);fflush(stdout);   
														//printf("\nSequence   :%s",Sequence);fflush(stdout);   

													
											  
														if ((tc_strcmp(PNo,PartNumber) == 0) && (tc_strcmp(PRev,Revision) == 0) && (tc_strcmp(PSeq,Sequence) == 0))
														{
														   printf("\n INSIDE  :\n");fflush(stdout);
														   
															char*  FourDdocs		 = NULL;
															char*  InDFmeaPrtDup	 = NULL;
															char*  InDFmeaPrt		 = NULL;
															char*  DFMEA_Doc		 = NULL;
															char*  InDadFmeaPrt	     = NULL;
															char*  InDadFmeaPrtDup   = NULL;
															char*  DFM_Doc			 = NULL;
															char*  DFA_Doc			 = NULL;
															char*  DFS_Doc			 = NULL;
															char*  InDadFmeaClassDup = NULL;
															char*  part_details	     = NULL;
															tag_t   Part_InDadPrtObj_Ptr  = NULLTAG;
															int  DadPrtObjCnt;
															int  status         = ITK_ok;
															   
															FourDdocs=malloc(5000);
															tc_strcpy(FourDdocs,"");														  
															InDFmeaPrtDup=malloc(5000);
															tc_strcpy(InDFmeaPrtDup,"");
															InDadFmeaPrtDup=malloc(5000);
															tc_strcpy(InDadFmeaPrtDup,"");
															InDadFmeaClassDup=malloc(5000);
															tc_strcpy(InDadFmeaClassDup,"");

															DFMEA_Doc=malloc(5000);
															tc_strcpy(DFMEA_Doc,"");
															DFM_Doc=malloc(5000);
															tc_strcpy(DFM_Doc,"");
															DFA_Doc=malloc(5000);
															tc_strcpy(DFA_Doc,"");
															DFS_Doc=malloc(5000);
															tc_strcpy(DFS_Doc,"");

															part_details=malloc(5000);

															if (ChRefpartPtr)
															{													
																ITK_CALL( GRM_find_relation_type ( "T5_PartHas4D", &PartHas4D_rel ) );
																ITK_CALL( GRM_list_secondary_objects_only ( ChRefpartPtr, PartHas4D_rel, &soDadObjs, &soDadRelObj ) );

																ITK_CALL( GRM_find_relation_type ( "T5_PartHasDfmea", &PartHasDfmea_rel ) );
																ITK_CALL( GRM_list_secondary_objects_only ( ChRefpartPtr, PartHasDfmea_rel, &dfmdocObj, &dfmdocRelObj ) );
						
																ITK_CALL( GRM_find_relation_type ( "T5_PartHasRef4DDfmea", &PartRefDFMEA_rel ) );
																ITK_CALL( GRM_list_secondary_objects_only ( ChRefpartPtr, PartRefDFMEA_rel, &soRefObjs, &soRefRelObjs ) );
															}

															//if (PartPtr1)
															//{

																//ITK_CALL( GRM_find_relation_type ( "T5_PartHas4D", &PartHas4D_rel ) );
																//ITK_CALL( GRM_list_secondary_objects_only ( PartPtr1, PartHas4D_rel, &soDadObjs, &soDadRelObj ) );

																//ITK_CALL( GRM_find_relation_type ( "T5_PartHasDfmea", &PartHasDfmea_rel ) );
																//ITK_CALL( GRM_list_secondary_objects_only ( PartPtr1, PartHasDfmea_rel, &dfmdocObj, &dfmdocRelObj ) );
						
																//ITK_CALL( GRM_find_relation_type ( "T5_PartHasRef4DDfmea", &PartRefDFMEA_rel ) );
																//ITK_CALL( GRM_list_secondary_objects_only ( PartPtr1, PartRefDFMEA_rel, &soRefObjs, &soRefRelObjs ) );
															//}



														    if ((soDadObjs > 0) || (dfmdocObj > 0) || (soRefObjs > 0))
															{

																if(dfmdocObj > 0) //Part has Dfmea
														         {     	                                                  	 
																	for(DadPrtObjCnt=0;DadPrtObjCnt<(dfmdocObj);DadPrtObjCnt++)
																	{
																	     
																	     Part_InDadPrtObj_Ptr = dfmdocRelObj[DadPrtObjCnt];

																	     ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id", &InDFmeaPrt));
																	     
																	     if((tc_strcmp(InDFmeaPrt,"") !=0))
																	     {
																	     	  tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);
																	     }

																		 if (tc_strcmp(InDFmeaPrtDup,"") != 0)
																		 {																    
																			tc_strcpy(DFMEA_Doc,InDFmeaPrtDup);
																		 }
																																	
																	}
																}
																
														         if(soRefObjs > 0) //Part has Ref4D Dfmea
														         {
																	for(DadPrtObjCnt=0;DadPrtObjCnt<(soRefObjs);DadPrtObjCnt++)
																	{      	                                                  			
																		Part_InDadPrtObj_Ptr = soRefRelObjs[DadPrtObjCnt];

																		ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr,"object_type", &item_type));
																		//printf("\n item_type : [%s]",item_type);
																		
																		if ((tc_strcmp(item_type,"DAD Doc Revision")==0) ||  (tc_strcmp(item_type,"Dfmea Revision")==0))
																		{

																			ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id" ,&InDadFmeaPrt));
																			if((tc_strcmp(InDadFmeaPrt,"") !=0))
																			{
																				tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
																			}
																	  
																			ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "object_type" ,&InDadFmeaPrt));
																			if((tc_strcmp(InDadFmeaPrt,"") !=0))
																			{
																				tc_strcpy(InDadFmeaClassDup,InDadFmeaPrt);
																			}

																			if((tc_strcmp(InDadFmeaClassDup,"Dfmea Revision") == 0) )
																			{
																				ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id" ,&InDFmeaPrt));

																				if((tc_strcmp(InDFmeaPrt,"") !=0))
																			    {
																			   		tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);

																			    }

																				if (tc_strcmp(InDFmeaPrtDup,"") != 0)
																				{
																					tc_strcpy(DFMEA_Doc,InDFmeaPrtDup);
																				}
																				
																				
																			}

																			if(tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
																			{      	                                                  				
																				tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
																			}
																			
																			else if(tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
																			{       	                                                  				
																				tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
																			}
																			
																			else if(tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
																			{       	                                                  				
																				tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
																			}

																		}
																		
																	}

														         }
																
																if(soDadObjs > 0) //Part has 4D
														         {
																	for(DadPrtObjCnt=0;DadPrtObjCnt<(soDadObjs);DadPrtObjCnt++)
																	{  
																		   Part_InDadPrtObj_Ptr = soDadRelObj[DadPrtObjCnt]; 
																		   
																		   ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr,"object_type", &item_type));
																		   //printf("\n item_type : [%s]",item_type);
																		   
																		   if (tc_strcmp(item_type,"DAD Doc Revision")==0)
																		   {
																				ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id", &InDadFmeaPrt));
																				//printf("\n\n\t\t Part has 4D Id: IS %s",InDadFmeaPrt);
  
																				if((tc_strcmp(InDadFmeaPrt,"") !=0))
																				{
																						tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
																				}
																		  
																				if(tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
																				{      	                                                  				
																					tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
																				}
																		  
																				else if(tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
																				{       	                                                  				
																					tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
																				}																  

																				else if(tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
																				{       	                                                  				
																					tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
																				}
																		 

																		   }

																	}

														         }

																if(tc_strcmp(DFMEA_Doc,"") !=0 )
																{
																	printf("\n\t\t DFMEA_Doc : %s",DFMEA_Doc);
																	tc_strcpy(FourDdocs,DFMEA_Doc);
																	tc_strcat(FourDdocs,",");
																}
																if(tc_strcmp(DFMEA_Doc,"") ==0 )
																{
																	tc_strcpy(DFMEA_Doc,"NA");
																	printf("\n\t\t DFMEA_Doc : %s",DFMEA_Doc);
																	tc_strcat(FourDdocs,DFMEA_Doc);               
																	tc_strcat(FourDdocs,",");                     
																}

																if(tc_strcmp(DFM_Doc,"") !=0 )
																{
																	printf("\n\t\t DFM_Doc : %s",DFM_Doc);
																	tc_strcat(FourDdocs,DFM_Doc);
																	tc_strcat(FourDdocs,",");
																}
																if(tc_strcmp(DFM_Doc,"") ==0 )
																{
																	tc_strcpy(DFM_Doc,"NA");
																	printf("\n\t\t DFM_Doc : %s",DFM_Doc);
																	tc_strcat(FourDdocs,DFM_Doc);
																	tc_strcat(FourDdocs,",");
																	
																}

																if(tc_strcmp(DFA_Doc,"") !=0 )
																{
																	printf("\n\t\t DFA_Doc : %s",DFA_Doc);
																	tc_strcat(FourDdocs,DFA_Doc);
																	tc_strcat(FourDdocs,",");
																	
																}
																if(tc_strcmp(DFA_Doc,"") ==0 )
																{
																	tc_strcpy(DFA_Doc,"NA"); 
																	printf("\n\t\t DFA_Doc : %s",DFA_Doc);
																	tc_strcat(FourDdocs,DFA_Doc);                 
																	tc_strcat(FourDdocs,","); 
																	
																}

																if(tc_strcmp(DFS_Doc,"") !=0 )
																{
																	printf("\n\t\t DFS_Doc : %s",DFS_Doc);
																	tc_strcat(FourDdocs,DFS_Doc);                  
																	tc_strcat(FourDdocs,",");                    
																}
																if(tc_strcmp(DFS_Doc,"") ==0 )
																{
																	tc_strcpy(DFS_Doc,"NA"); 
																	printf("\n\t\t DFS_Doc : %s",DFS_Doc);
																	tc_strcat(FourDdocs,DFS_Doc);                 
																	
																}
																

																
															}
															else
															{                                                          	  
																  tc_strcpy(FourDdocs,"NA,NA,NA,NA");
															}

														    
														    tc_strcpy(part_details,PNo);
														    tc_strcat(part_details,",");
														    tc_strcat(part_details,PRev);
														    tc_strcat(part_details,",");
														    tc_strcat(part_details,PSeq);
														    tc_strcat(part_details,",");
														    tc_strcat(part_details,PType1);
														    tc_strcat(part_details,",");
														    tc_strcat(part_details,FourDdocs);
														    
														   tc_strcpy(bString->__ptr[0].DML_Number,ErcDmlNo);
														    tc_strcpy(bString->__ptr[0].Part_Number,PNo);
														    tc_strcpy(bString->__ptr[0].Part_Revision,PRev);
														    tc_strcpy(bString->__ptr[0].Part_Sequence,PSeq);
														    tc_strcpy(bString->__ptr[0].FourD_Doc_Numbers,FourDdocs);

														   printf("\n\n\t\t All 4d Doc %s \n\n",part_details);

														   //tc_strcpy(bString->__ptr[K].DML_Number,ErcDmlNo);
														    //tc_strcpy(bString->__ptr[K].Part_Number,PNo);
														    //tc_strcpy(bString->__ptr[K].Part_Revision,PRev);
														    //tc_strcpy(bString->__ptr[K].Part_Sequence,PSeq);
														    //tc_strcpy(bString->__ptr[K].FourD_Doc_Numbers,FourDdocs);



														}
													}

												    else if (tc_strcmp(item_type,"Folder")==0)
												    {
													 	 ITK_CALL(AOM_UIF_ask_value(ChRefpartPtr,"object_string", &Folder_name));	
													 	 printf("\nFolder_name : [%s]",Folder_name);
												    
													     //if( (tc_strcmp(item_type,"Folder")==0) || (tc_strcmp(item_type,"Design Revision")==0) )
													     if (tc_strcmp(Folder_name,"Parts For Gate Maturation")==0)
													 	{
													 		printf("\n\nINSIDE Folder");
													 															
													 		ITK_CALL(AOM_ask_value_tags(ChRefpartPtr,"contents",&iCount6, &Part_tag));
												    
													 		printf("\nFolder Parts Count : [%d] \n",iCount6);
												    
													 		for(l=0;l<iCount6;l++)
													 		{
													 			PartPtr1 = Part_tag[l];
												    
													 			ITK_CALL(AOM_UIF_ask_value(PartPtr1,"item_id", &Part_no));	
													 			printf("\nFolder Part No : [%s]",Part_no);
												    
													 			ITK_CALL(AOM_UIF_ask_value(PartPtr1,"item_revision_id", &itemRevid2));
												    
													 			ITK_CALL(ITEM_find_item(Part_no, &itemTag2));
													 			ITK_CALL(ITEM_ask_latest_rev(itemTag2,&partRevTag2));
												    
													 			ITK_CALL(AOM_UIF_ask_value(partRevTag2, "item_id", &PNo2));
													 			printf("\nPNo2 : [%s]",PNo2);
												    
													 			ITK_CALL(AOM_UIF_ask_value(PartPtr1, "item_revision_id", &PRev3));
																printf("\nPRev3 : [%s]",PRev3);
												    
													 			PRev2=tc_strtok(PRev3, ";");
													 			printf("\nPRev2 : [%s]",PRev2);
																PSeq2=tc_strtok(NULL, "");
												    
													 			//ITK_CALL(AOM_UIF_ask_value(PartPtr1, "sequence_id", &PSeq2));
													 			printf("\nPSeq2 : [%s]",PSeq2);
												    
													 			ITK_CALL(AOM_ask_value_string(PartPtr1, "t5_PartType", &PType2));
													 			printf("\nPType2 : [%s]\n",PType2);
													 		
												    
													 			//printf("\n\n PNo2 : [%s]",PNo2);
													 			//printf("\n\n PRev2 : [%s]",PRev2);
													 			//printf("\n\n PSeq2 : [%s]",PSeq2);
													 					 
													 			//printf("\n\n PartNumber2 : [%s]",PartNumber);
													 			//printf("\n\n Revision2 : [%s]",Revision);
													 			//printf("\n\n Sequence2 : [%s]",Sequence);
												    
												    
												    
													 			if ((tc_strcmp(PNo2,PartNumber) == 0) && (tc_strcmp(PRev2,Revision) == 0) && (tc_strcmp(PSeq2,Sequence) == 0)) 
													 			{
													 			   printf("\nINSIDE 4D Doc :\n");fflush(stdout);
													 			   
													 				char*  FourDdocs		 = NULL;
													 				char*  InDFmeaPrtDup	 = NULL;
													 				char*  InDFmeaPrt		 = NULL;
													 				char*  DFMEA_Doc		 = NULL;
													 				char*  InDadFmeaPrt	     = NULL;
													 				char*  InDadFmeaPrtDup   = NULL;
													 				char*  DFM_Doc			 = NULL;
													 				char*  DFA_Doc			 = NULL;
													 				char*  DFS_Doc			 = NULL;
													 				char*  InDadFmeaClassDup = NULL;
													 				char*  part_details	     = NULL;
													 				tag_t   Part_InDadPrtObj_Ptr  = NULLTAG;
													 				int  DadPrtObjCnt;
													 				int  status         = ITK_ok;
													 				   
													 				FourDdocs=malloc(5000);
													 				tc_strcpy(FourDdocs,"");														  
													 				InDFmeaPrtDup=malloc(5000);
													 				tc_strcpy(InDFmeaPrtDup,"");
													 				InDadFmeaPrtDup=malloc(5000);
													 				tc_strcpy(InDadFmeaPrtDup,"");
													 				InDadFmeaClassDup=malloc(5000);
													 				tc_strcpy(InDadFmeaClassDup,"");
												    
													 				DFMEA_Doc=malloc(5000);
													 				tc_strcpy(DFMEA_Doc,"");
													 				DFM_Doc=malloc(5000);
													 				tc_strcpy(DFM_Doc,"");
													 				DFA_Doc=malloc(5000);
													 				tc_strcpy(DFA_Doc,"");
													 				DFS_Doc=malloc(5000);
													 				tc_strcpy(DFS_Doc,"");
												    
													 				part_details=malloc(5000);
												    
													 				if (PartPtr1)
													 				{
												    
													 					ITK_CALL( GRM_find_relation_type ( "T5_PartHas4D", &PartHas4D_rel ) );
													 					ITK_CALL( GRM_list_secondary_objects_only ( PartPtr1, PartHas4D_rel, &soDadObjs, &soDadRelObj ) );
												    
													 					ITK_CALL( GRM_find_relation_type ( "T5_PartHasDfmea", &PartHasDfmea_rel ) );
													 					ITK_CALL( GRM_list_secondary_objects_only ( PartPtr1, PartHasDfmea_rel, &dfmdocObj, &dfmdocRelObj ) );
												    
													 					ITK_CALL( GRM_find_relation_type ( "T5_PartHasRef4DDfmea", &PartRefDFMEA_rel ) );
													 					ITK_CALL( GRM_list_secondary_objects_only ( PartPtr1, PartRefDFMEA_rel, &soRefObjs, &soRefRelObjs ) );
													 				}
												    
												    
												    
													 			     if ((soDadObjs > 0) || (dfmdocObj > 0) || (soRefObjs > 0))
													 				{
												    
													 					if(dfmdocObj > 0) //Part has Dfmea
													 			         {     	                                                  	 
													 						for(DadPrtObjCnt=0;DadPrtObjCnt<(dfmdocObj);DadPrtObjCnt++)
													 						{
													 						     
													 						     Part_InDadPrtObj_Ptr = dfmdocRelObj[DadPrtObjCnt];
												    
													 						     ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id", &InDFmeaPrt));
													 						     
													 						     if((tc_strcmp(InDFmeaPrt,"") !=0))
													 						     {
													 						     	  tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);
													 						     }
												    
													 							 if (tc_strcmp(InDFmeaPrtDup,"") != 0)
													 							 {																    
													 								tc_strcpy(DFMEA_Doc,InDFmeaPrtDup);
													 							 }
													 																						
													 						}
													 					}
													 					
													 			         if(soRefObjs > 0) //Part has Ref4D Dfmea
													 			         {
													 						for(DadPrtObjCnt=0;DadPrtObjCnt<(soRefObjs);DadPrtObjCnt++)
													 						{      	                                                  			
													 							Part_InDadPrtObj_Ptr = soRefRelObjs[DadPrtObjCnt];
												    
													 							ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr,"object_type", &item_type));
													 							//printf("\n item_type : [%s]",item_type);
													 							
													 							if ((tc_strcmp(item_type,"DAD Doc Revision")==0) ||  (tc_strcmp(item_type,"Dfmea Revision")==0))
													 							{
												    
													 								ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id" ,&InDadFmeaPrt));
													 								if((tc_strcmp(InDadFmeaPrt,"") !=0))
													 								{
													 									tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
													 								}
													 						  
													 								ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "object_type" ,&InDadFmeaPrt));
													 								if((tc_strcmp(InDadFmeaPrt,"") !=0))
													 								{
													 									tc_strcpy(InDadFmeaClassDup,InDadFmeaPrt);
													 								}
												    
													 								if((tc_strcmp(InDadFmeaClassDup,"Dfmea Revision") == 0) )
													 								{
													 									ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id" ,&InDFmeaPrt));
												    
													 									if((tc_strcmp(InDFmeaPrt,"") !=0))
													 								    {
													 								   		tc_strcpy(InDFmeaPrtDup,InDFmeaPrt);
												    
													 								    }
												    
													 									if (tc_strcmp(InDFmeaPrtDup,"") != 0)
													 									{
													 										tc_strcpy(DFMEA_Doc,InDFmeaPrtDup);
													 									}
													 									
													 									
													 								}
												    
													 								if(tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
													 								{      	                                                  				
													 									tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
													 								}
													 								
													 								else if(tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
													 								{       	                                                  				
													 									tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
													 								}
													 								
													 								else if(tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
													 								{       	                                                  				
													 									tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
													 								}
												    
													 							}
													 							
													 						}
												    
													 			         }
													 					
													 					if(soDadObjs > 0) //Part has 4D
													 			         {
													 						for(DadPrtObjCnt=0;DadPrtObjCnt<(soDadObjs);DadPrtObjCnt++)
													 						{  
													 							   Part_InDadPrtObj_Ptr = soDadRelObj[DadPrtObjCnt]; 
													 							   
													 							   ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr,"object_type", &item_type));
													 							   //printf("\n item_type : [%s]",item_type);
													 							   
													 							   if (tc_strcmp(item_type,"DAD Doc Revision")==0)
													 							   {
													 									ITK_CALL(AOM_UIF_ask_value(Part_InDadPrtObj_Ptr, "current_id", &InDadFmeaPrt));
													 									//printf("\n\n\t\t Part has 4D Id: IS %s",InDadFmeaPrt);
  												    
													 									if((tc_strcmp(InDadFmeaPrt,"") !=0))
													 									{
													 											tc_strcpy(InDadFmeaPrtDup,InDadFmeaPrt);
													 									}
													 							  
													 									if(tc_strstr(InDadFmeaPrtDup,"DFM")!=NULL)
													 									{      	                                                  				
													 										tc_strcpy(DFM_Doc,InDadFmeaPrtDup);
													 									}
													 							  
													 									else if(tc_strstr(InDadFmeaPrtDup,"DFA")!=NULL)
													 									{       	                                                  				
													 										tc_strcpy(DFA_Doc,InDadFmeaPrtDup);
													 									}																  
												    
													 									else if(tc_strstr(InDadFmeaPrtDup,"DFS")!=NULL)
													 									{       	                                                  				
													 										tc_strcpy(DFS_Doc,InDadFmeaPrtDup);
													 									}
													 							 
												    
													 							   }
												    
													 						}
												    
													 			         }
												    
													 					if(tc_strcmp(DFMEA_Doc,"") !=0 )
													 					{
													 						printf("\n\t\t DFMEA_Doc : %s",DFMEA_Doc);
													 						tc_strcpy(FourDdocs,DFMEA_Doc);
													 						tc_strcat(FourDdocs,",");
													 					}
													 					if(tc_strcmp(DFMEA_Doc,"") ==0 )
													 					{
													 						tc_strcpy(DFMEA_Doc,"NA");
													 						printf("\n\t\t DFMEA_Doc : %s",DFMEA_Doc);
													 						tc_strcat(FourDdocs,DFMEA_Doc);               
													 						tc_strcat(FourDdocs,",");                     
													 					}
												    
													 					if(tc_strcmp(DFM_Doc,"") !=0 )
													 					{
													 						printf("\n\t\t DFM_Doc : %s",DFM_Doc);
													 						tc_strcat(FourDdocs,DFM_Doc);
													 						tc_strcat(FourDdocs,",");
													 					}
													 					if(tc_strcmp(DFM_Doc,"") ==0 )
													 					{
													 						tc_strcpy(DFM_Doc,"NA");
													 						printf("\n\t\t DFM_Doc : %s",DFM_Doc);
													 						tc_strcat(FourDdocs,DFM_Doc);
													 						tc_strcat(FourDdocs,",");
													 						
													 					}
												    
													 					if(tc_strcmp(DFA_Doc,"") !=0 )
													 					{
													 						printf("\n\t\t DFA_Doc : %s",DFA_Doc);
													 						tc_strcat(FourDdocs,DFA_Doc);
													 						tc_strcat(FourDdocs,",");
													 						
													 					}
													 					if(tc_strcmp(DFA_Doc,"") ==0 )
													 					{
													 						tc_strcpy(DFA_Doc,"NA"); 
													 						printf("\n\t\t DFA_Doc : %s",DFA_Doc);
													 						tc_strcat(FourDdocs,DFA_Doc);                 
													 						tc_strcat(FourDdocs,","); 
													 						
													 					}
												    
													 					if(tc_strcmp(DFS_Doc,"") !=0 )
													 					{
													 						printf("\n\t\t DFS_Doc : %s",DFS_Doc);
													 						tc_strcat(FourDdocs,DFS_Doc);                  
													 						tc_strcat(FourDdocs,",");                    
													 					}
													 					if(tc_strcmp(DFS_Doc,"") ==0 )
													 					{
													 						tc_strcpy(DFS_Doc,"NA"); 
													 						printf("\n\t\t DFS_Doc : %s",DFS_Doc);
													 						tc_strcat(FourDdocs,DFS_Doc);                 
													 						
													 					}
													 					
												    
													 					
													 				}
													 				else
													 				{                                                          	  
													 					  tc_strcpy(FourDdocs,"NA,NA,NA,NA");
													 				}
												    
													 			    
													 			    tc_strcpy(part_details,PNo2);
													 			    tc_strcat(part_details,",");
													 			    tc_strcat(part_details,PRev2);
													 			    tc_strcat(part_details,",");
													 			    tc_strcat(part_details,PSeq2);
													 			    tc_strcat(part_details,",");
													 			    tc_strcat(part_details,PType2);
													 			    tc_strcat(part_details,",");
													 			    tc_strcat(part_details,FourDdocs);
													 			    
													 			    tc_strcpy(bString->__ptr[0].DML_Number,ErcDmlNo);
													 			    tc_strcpy(bString->__ptr[0].Part_Number,PNo2);
													 			    tc_strcpy(bString->__ptr[0].Part_Revision,PRev2);
													 			    tc_strcpy(bString->__ptr[0].Part_Sequence,PSeq2);
													 			    tc_strcpy(bString->__ptr[0].FourD_Doc_Numbers,FourDdocs);
												    
													 			    printf("\n\n\t\t All 4d Doc %s \n\n",part_details);
												    
													 			    //tc_strcpy(bString->__ptr[K].DML_Number,ErcDmlNo);
													 			    //tc_strcpy(bString->__ptr[K].Part_Number,PNo);
													 			    //tc_strcpy(bString->__ptr[K].Part_Revision,PRev);
													 			    //tc_strcpy(bString->__ptr[K].Part_Sequence,PSeq);
													 			    //tc_strcpy(bString->__ptr[K].FourD_Doc_Numbers,FourDdocs);
												    
												    
												    
													 			}
													 		}
													 		
													 	
													 	}
													 	else
													 	{
													 		printf("\nFolder Not Found");
													 		
													 	}
												    }
 

												}
											}
										}

									}

									

									//else
									//{
									   //printf("\n\n\t\t Parts Not Found \n\n");
									//}

							}

					
					}
				 }
				 else
				 {
				    //printf("\n\n\t\t Plant DML Not Found \n\n");
					fflush(stdout);
				 }


			}
			else
			{
			   //printf("\n\n\t\t ERC DML Not Found \n\n");
			   fflush(stdout);
			}

		}
		else
		{
		  //printf("\n\n\t\t Query Not Found \n\n");
		  fflush(stdout);
		}

	}


	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;

 CLEANUP :
	   
		return SOAP_OK;

EXIT:
		return SOAP_OK;

}



