		
	#define _CRT_SECURE_NO_DEPRECATE
	#define NUM_ENTRIES 1
	#define TE_MAXLINELEN  128
	#include <epm/epm.h>
	#include <ae/dataset_msg.h>
	//#include <tccore/iman_msg.h>
	#include <ps/ps.h>
	#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
	#include <ps/ps_errors.h>
	#include <time.h>
	#include <ai/sample_err.h>
	//#include <tc/tc.h>
	#include <tccore/grm_msg.h>
	#include <tccore/workspaceobject.h>
	#include <bom/bom.h>
	#include <ae/dataset.h>
	#include <ps/ps_errors.h>
	#include <sa/sa.h>
	#include <stdarg.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <sys/stat.h>
	#include <fclasses/tc_string.h>
	#include <tccore/item.h>
	#include <tccore/item_errors.h>
	#include <sa/tcfile.h>
	//#include <epm/releasestatus.h>
	#include <tcinit/tcinit.h>
	#include <tccore/tctype.h>
	#include <res/reservation.h>
	#include <tccore/aom.h>
	#include <tccore/custom.h>
	#include <tc/emh.h>
	#include <ict/ict_userservice.h>
	//#include <tc/iman.h>
	//#include <tccore/imantype.h>
	//#include <sa/imanfile.h>
	#include <lov/lov.h>
	#include <lov/lov_msg.h>
	//#include <itk/mem.h>
	#include <ss/ss_errors.h>
	#include <sa/user.h>
	#include <tccore/grm.h>
	#include <tccore/item_msg.h>
	#include <string.h>
	//#include <epm/cr_effectivity.h>
	#include <tc/folder.h>


	#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

	#define Debug TRUE

	#define ITK_CALL(X) 							\
			if(Debug)								\
			{										\
				printf(#X);							\
			}										\
			fflush(NULL);							\
			status=X; 								\
			if (status != ITK_ok ) 					\
			{										\
				int				index = 0;			\
				int				n_ifails = 0;		\
				const int*		severities = 0;		\
				const int*		ifails = 0;			\
				const char**	texts = NULL;		\
													\
				EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
				printf("\t%3d error(s)\n", n_ifails);							\
				for( index=0; index<n_ifails; index++)							\
				{																\
					printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
				}																\
				return status;													\
			}																	\
			else									\
			{										\
				if(Debug)							\
				printf("\tSUCCESS\n");				\
			}
	
int UpdateCurrentviewmask(tag_t CKDVC_Dummy_PartTag, tag_t CKDVC_Dummy_PartTagrev, tag_t close_tag,tag_t rule,char* Action,char* Plant_CurrentViewMask)
{
	tag_t		window		=	NULLTAG;
	tag_t		bom_line	=	NULLTAG;
	tag_t*		child		=	NULLTAG;

	char* aplc_cvm = NULL;

	int count			= 0;
	int childIterator	= 0;

	printf("\n Inside UpdateCurrentviewmask Function \n");fflush(stdout);
	printf("\n Action => %s \n",Action);fflush(stdout);
	printf("\n Plant_CurrentViewMask => %s \n",Plant_CurrentViewMask);fflush(stdout);

	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule( window, rule ));
	ITKCALL(BOM_set_window_pack_all(window, true));	

	ITKCALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITKCALL(BOM_set_window_top_line(window,CKDVC_Dummy_PartTag,CKDVC_Dummy_PartTagrev,NULLTAG,&bom_line));
	ITKCALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d",count);fflush(stdout);
	
	for(childIterator=0;childIterator<count;childIterator++)
	{
		//ITKCALL( AOM_ask_value_string(child[childIterator],"bl_occ_t5_CurrentViewMaskP",&aplc_cvm));
		ITKCALL( AOM_ask_value_string(child[childIterator],Plant_CurrentViewMask,&aplc_cvm));
		printf("\n aplc_cvm => %s \n",aplc_cvm);fflush(stdout);

		if(tc_strcmp(aplc_cvm,"-12")==0)
		{
			printf("\n continue \n");fflush(stdout);
			continue;
		}
		else
		{
			printf("\n inside else \n");fflush(stdout);
			//ITKCALL( AOM_set_value_string(child[childIterator],"bl_occ_t5_CurrentViewMaskP","-12"));			
			ITKCALL( AOM_set_value_string(child[childIterator],Plant_CurrentViewMask,"-12"));			
			printf("\n Value set as -12  \n");fflush(stdout);
		}
		printf("\n set Action as CK/DM \n");fflush(stdout);
		ITKCALL( AOM_set_value_string(child[childIterator],"bl_occ_t5_ActionInd",Action));

	}	
	ITKCALL(BOM_save_window(window));
	ITKCALL(BOM_close_window(window));

}

int QueryPart(char* Part_Number,tag_t* PartTag)
{
	printf("\n Inside QueryPart Function \n");fflush(stdout);

	int ifail  = 0;
	int status = 0;

	const char *qry_entries[1];
	const char *qry_values[1];
	
	tag_t		*itemclass	=	NULLTAG;
	tag_t		item		=	NULLTAG;

	int			n_tags_found=0;

	qry_entries[0] ="item_id";
	qry_values[0] = Part_Number;

	//Find Item by its ID.
	ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclass);
	printf("\n Number of Tags found : %d \n",n_tags_found);fflush(stdout);

	if(n_tags_found>0)
	{
		*PartTag= itemclass[0];
	}

	return ifail;
}

char* subString_CKD (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

int tm_create_ckd_bom(tag_t CKDVC_Dummy_PartTag, tag_t CKDVC_Dummy_PartTagrev, char* Component_number, char* Qty,char* Main_srl,char* Action,char* PlantName)
{			
	int ifail  = 0;
	int status = 0;
	tag_t	window					= NULLTAG;
	tag_t	window_BS				= NULLTAG;
	tag_t	rule					= NULLTAG;
	tag_t	rule_BS					= NULLTAG;
	tag_t	*closure_tags			= NULLTAG;
	tag_t  	closure_tag				= NULLTAG;
	tag_t	view_type_tag			= NULLTAG;
	tag_t	bom_view_grp98			= NULLTAG;
	tag_t	bvr_grp98Rev1			= NULLTAG;
	tag_t	TemplateTag				= NULLTAG;
	tag_t	PartTag					= NULLTAG;
	tag_t	PartRelTag				= NULLTAG;
	tag_t	PartTagrev				= NULLTAG;
	tag_t	*occurrences			= NULLTAG;
	tag_t	bvr_BSRev1				= NULLTAG;
	tag_t	top_line				= NULLTAG;
	tag_t	top_line_BS				= NULLTAG;
	tag_t	objChild_BS				= NULLTAG;
	tag_t	bom_view_bs				= NULLTAG;
	tag_t	tRelationFind			= NULLTAG;
	tag_t	Rel_task				= NULLTAG;
	tag_t	project_itempr			= NULLTAG;
	tag_t*	bvrs_BSRev				= NULLTAG;
	tag_t	NewDMLAttrId			= NULLTAG;		
	
	char*	part_id					= NULL;
	char*	consumableClass			= NULL;
	char*	consumableqty			= NULL;
	char*	RevisionRNameBdySh		= NULL;
	char*	ViewBVRBdySh			= NULL;
	char*	ItemName_BS				= NULL;
	char*	part_type				= NULL;
	char*	getPlantViewName		= NULL;
	char*	bs_view_type_name		= NULL;
	//char*	PlantName				= NULL;
	char*	Part_Number				= NULL; 
	char*	Part_Qty				= NULL;
	char*	view_name				= NULL;
	
	int n_closure_tags;
	int num;
	float consumableQtyD;
	int scope;
	FILE* fp						= NULL;

	int bvr_count_bsRev = 0;
	
	getPlantViewName	=	(char *) MEM_alloc(100);

	char*	closureRuleName			= NULL;
	char*	RevisionRule			= NULL;
	char*	Plant_CurrentViewMask	= NULL;
	
	closureRuleName			= (char *)MEM_alloc(100);
	RevisionRule			= (char *)MEM_alloc(100);
	Plant_CurrentViewMask	= (char *)MEM_alloc(100);
		
	tc_strcpy(closureRuleName,"");
	tc_strcpy(RevisionRule,"");
	tc_strcpy(Plant_CurrentViewMask,"");

	printf("\n Inside tm_create_ckd_bom Function \n");fflush(stdout);

	printf("\n Main_srl => %s \n",Main_srl);fflush(stdout);
	printf("\n Action => %s \n",Action);fflush(stdout);
	//printf("\n User_Role => %s \n",User_Role);fflush(stdout);

	//PlantName=subString_CKD(User_Role,3,4);
    printf("\n PlantName => %s\n", PlantName);

	if (tc_strcmp(PlantName,"STDJ") == 0)
	{
		printf("\n Inside STDJ \n");fflush(stdout);
	    tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDJ");
		tc_strcpy(RevisionRule,"STDJ Working and Above");	
		tc_strcpy(getPlantViewName,"T5_APLJView");
		tc_strcpy(Plant_CurrentViewMask,"bl_occ_t5_CurrentViewMaskJ");
	}
	else if (tc_strcmp(PlantName,"STDL") == 0)
	{
		printf("\n Inside STDL \n");fflush(stdout);
	    tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDL");
		tc_strcpy(RevisionRule,"STDL Working and Above");
		tc_strcpy(getPlantViewName,"T5_APLLView");
		tc_strcpy(Plant_CurrentViewMask,"bl_occ_t5_CurrentViewMaskL");
	}
	else if (tc_strcmp(PlantName,"STDD") == 0)
	{
		printf("\n Inside STDD \n");fflush(stdout);
	    tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDD");
		tc_strcpy(RevisionRule,"STDD Working and Above");
		tc_strcpy(getPlantViewName,"T5_APLDView");
		tc_strcpy(Plant_CurrentViewMask,"bl_occ_t5_CurrentViewMaskD");
	}
	else if (tc_strcmp(PlantName,"STDP") == 0)
	{
		printf("\n Inside STDP \n");fflush(stdout);
	    tc_strcpy(closureRuleName,"BOMViewClosureRuleSTDP");
		tc_strcpy(RevisionRule,"STDP Working and Above");
		tc_strcpy(getPlantViewName,"T5_APLPView");
		tc_strcpy(Plant_CurrentViewMask,"bl_occ_t5_CurrentViewMaskP");
	}
	else if (tc_strcmp(PlantName,"STDU") == 0)
	{
		printf("\n Inside STDU \n");fflush(stdout);
	    tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDU");
		tc_strcpy(RevisionRule,"STDU Working and Above");
		tc_strcpy(getPlantViewName,"T5_APLUView");
		tc_strcpy(Plant_CurrentViewMask,"bl_occ_t5_CurrentViewMaskU");
	}
	else
	{
		printf("\n Inside else \n");fflush(stdout);

		//tc_strcpy(closureRuleName,"BOMViewClosureRuleSTDP");
		//tc_strcpy(RevisionRule,"STDP Working and Above");
		//tc_strcpy(getPlantViewName,"T5_APLPView");
		//tc_strcpy(Plant_CurrentViewMask,"bl_occ_t5_CurrentViewMaskP");

		//tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDU");
		//tc_strcpy(RevisionRule,"STDU Working and Above");
		//tc_strcpy(getPlantViewName,"T5_APLUView");
		//tc_strcpy(Plant_CurrentViewMask,"bl_occ_t5_CurrentViewMaskU");

		tc_strcpy(closureRuleName, "BOMViewClosureRuleSTDJ");
		tc_strcpy(RevisionRule,"STDJ Working and Above");	
		tc_strcpy(getPlantViewName,"T5_APLJView");
		tc_strcpy(Plant_CurrentViewMask,"bl_occ_t5_CurrentViewMaskJ");
	}

	printf("\n Final ClosureRule is => [%s] || RevisionRule is => [%s] \n", closureRuleName,RevisionRule);
	printf("\n Final ViewName is => [%s] || Plant_CurrentViewMask is => [%s] \n",getPlantViewName,Plant_CurrentViewMask);

	ITKCALL(ITEM_rev_list_bom_view_revs(CKDVC_Dummy_PartTagrev, &bvr_count_bsRev, &bvrs_BSRev));

	if(bvr_count_bsRev ==0)
	{
		printf("\n test 1 \n");fflush(stdout);
	
		//tc_strcpy(getPlantViewName,"T5_APLPView");

		ITKCALL(PS_find_view_type(getPlantViewName,&view_type_tag ));

		ITKCALL(BOM_create_window (&window));
		//ITKCALL(CFM_find( "STDP Working and Above", &rule ));
		ITKCALL(CFM_find(RevisionRule, &rule ));
		ITKCALL(BOM_set_window_config_rule( window, rule));

		scope=PIE_TEAMCENTER;

		ITKCALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		printf("\n n_closure_tags => %d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
		}

		ITKCALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));

		ITKCALL(BOM_set_window_top_line (window, CKDVC_Dummy_PartTag, null_tag, null_tag, &top_line));
		ITKCALL(BOM_save_window (window));

		if(view_type_tag==NULLTAG)
		{
			printf("\n view_type_tag is null \n");fflush(stdout);
		}
		else
		{
			printf("\n view_type_tag is not null \n");fflush(stdout);
		}
		
		ITKCALL(PS_ask_view_type_name (view_type_tag,&bs_view_type_name));
		printf("\n bs_view_type_name %s \n",bs_view_type_name);fflush(stdout);
		
		ITKCALL(AOM_lock(CKDVC_Dummy_PartTag));	
		ITKCALL(PS_create_bom_view (view_type_tag,"","",CKDVC_Dummy_PartTag,&bom_view_grp98));//BOM View created.
		ITKCALL(AOM_save_without_extensions(bom_view_grp98));
		ITKCALL(AOM_save_without_extensions(CKDVC_Dummy_PartTag));
		ITKCALL(AOM_unlock(CKDVC_Dummy_PartTag));

		ITKCALL(AOM_lock(CKDVC_Dummy_PartTagrev));
		ITKCALL(PS_create_bvr (bom_view_grp98,"","",false,CKDVC_Dummy_PartTagrev,&bvr_grp98Rev1));//BVR created.
		ITKCALL(AOM_save_without_extensions(bvr_grp98Rev1));
		ITKCALL(AOM_save_without_extensions(CKDVC_Dummy_PartTagrev));
		ITKCALL(AOM_unlock(CKDVC_Dummy_PartTagrev));

	}
	else
	{
		printf("\n test 2 \n");fflush(stdout);
		bvr_grp98Rev1 = bvrs_BSRev[0];
	}

	ITKCALL(AOM_ask_value_string(bvr_grp98Rev1,"object_name",&view_name));
	printf("\n view_name => %s \n",view_name);fflush(stdout);
	
	printf("\n Part_Number ==> [%s]\n",Component_number);fflush(stdout);
	printf("\n Part_Qty ==> [%s]\n",Qty);fflush(stdout);
	
	QueryPart(Component_number,&PartTag);

	int conTpPartCnt;
	
	if(PartTag != NULLTAG)
	{
		printf("\n\n Inside PartTag \n");fflush(stdout);

		part_id	=	NULL;
		ITKCALL(AOM_ask_value_string(PartTag,"item_id",&part_id));
		printf("\n part_id  is :%s",part_id);fflush(stdout);
		
		PartTagrev	=	NULLTAG;
		ITKCALL(ITEM_ask_latest_rev(PartTag,&PartTagrev));

		consumableQtyD	=	atof(Qty);
		printf("\n consumableQtyD : %f \n",consumableQtyD);fflush(stdout);

		part_type	=	NULL;
		ITKCALL(AOM_ask_value_string(PartTagrev,"t5_PartType",&part_type));
		printf("\n part_id  is :%s \n",part_type);fflush(stdout);

		ITKCALL(PS_create_occurrences(bvr_grp98Rev1,PartTagrev,NULLTAG,1,&occurrences));
		printf("\n set Qty \n");fflush(stdout);
		ITKCALL(PS_set_occurrence_qty( bvr_grp98Rev1, occurrences[0], consumableQtyD ));

		printf("\n set find no \n");fflush(stdout);
		ITKCALL(PS_set_seq_no(bvr_grp98Rev1,occurrences[0],Main_srl));
		ITKCALL(AOM_save_without_extensions(bvr_grp98Rev1));
		
		printf("\n UpdateCurrentviewmask function calling \n");fflush(stdout);
		
		UpdateCurrentviewmask(CKDVC_Dummy_PartTag,CKDVC_Dummy_PartTagrev,closure_tag,rule,Action,Plant_CurrentViewMask);
	}
																		
	return ifail;			
}
		

void autoresizestrAdd_CKDBOM(char **src,char* dest)
{
	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	char * desc = dest ? dest : "NA";
	//printf("\n autoresizestrAdd src len==%d",strlen(*src));
	//printf("\n autoresizestrAdd desc len==%d",strlen(desc));
	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
	// src = MEM_realloc(src, size_ab);
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
	tc_strcat(*src , desc);
}

															
extern int ITK_user_main( int argc, char **argv )
{
	//VARIABLE DECLARATION STARTS
	int     status;
	int     ifail;

	char*	inputuser				= NULL;
	char*	inputpwd				= NULL;
	char*	inputgrp				= NULL;
	char*	Part_List_File			= NULL;
	char*	Main_srl				= NULL;
	char*	Component_number		= NULL;
	char*	Qty						= NULL;
	char*	CKDVC_Dummy_Part		= NULL;
	char*	Action					= NULL;
	char*	ParentPartNumber		= NULL;
	char*	ParentRevision			= NULL;
	char*	Input_String			= NULL;
	char*	Login_User				= NULL;
	char*	username				= NULL;
	char*	user_email				= NULL;
	char*	User_Role				= NULL;
	char*	PlantName				= NULL;
	char*	s						= NULL;
	
	FILE* fp						= NULL;

	tag_t	user_tag				= NULLTAG;
	tag_t	person_tag				= NULLTAG;

	char*	inputline				= NULL;

	int Row		 = 0;	

	//
	printf("\n ~~~~~~~~~ Ketan Inside Program bomloadingCKD ~~~~~~~~~~~\n");fflush(stdout);

	inputuser	   = ITK_ask_cli_argument("-u=");
	inputpwd	   = ITK_ask_cli_argument("-pf=");
	inputgrp	   = ITK_ask_cli_argument("-g=");
	Part_List_File = ITK_ask_cli_argument("-i=");	
	
	ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	ITK_CALL(ITK_auto_login());
	ITK_set_bypass(true);

	char ReportFiredDate[26] = {'\0'};
	time_t now;
	struct tm* now_tm;
	time(&now);
	now_tm = localtime(&now);
	//strftime (ReportFiredDate, 26,"%d-%B-%Y", now_tm);
	strftime (ReportFiredDate, 26,"%d-%B-%Y:%H:%M:%S", now_tm);
	printf("\n ReportFiredDate is===>[%s]",ReportFiredDate);fflush(stdout);

	char*       Output_Part_List_File           = NULL;
	Output_Part_List_File = (char *) MEM_alloc(100 * sizeof(char *));

	tc_strcpy(Output_Part_List_File,"BOM_Create_Validation");
	tc_strcat(Output_Part_List_File,"_");
	tc_strcat(Output_Part_List_File,ReportFiredDate);
	tc_strcat(Output_Part_List_File,".txt");

	printf("\n Output_Part_List_File => %s \n", Output_Part_List_File);fflush(stdout);
	
	FILE*	fp_Output = NULL;
	fp_Output = fopen(Output_Part_List_File,"w");

	int IsError = 0;
	
	////////////// For Query //////////

	fp=fopen("Part_List_File.txt","r");

	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			fputs(inputline,stdout);	
			
			Main_srl			= NULL;
			Component_number	= NULL;
			Qty					= NULL;
			CKDVC_Dummy_Part	= NULL;
			Action				= NULL;
			PlantName			= NULL;

			Main_srl			=strtok(inputline,"~");  
			Component_number	=strtok(NULL,"~"); 
			Qty					=strtok(NULL,"~"); 
			CKDVC_Dummy_Part	=strtok(NULL,"~");
			Action				=strtok(NULL,"~");
			PlantName			=strtok(NULL,"~");
			
			printf("\n \t\t\t Part Query : RowNo: %d CKD data %s || %s || %s || %s || %s || %s\n",Row+1,Main_srl,Component_number,Qty,CKDVC_Dummy_Part,Action,PlantName);fflush(stdout);
			Row++;

			tag_t	Component_numberTag		= NULLTAG;
			tag_t	Component_numberTagrev	= NULLTAG;

			QueryPart(Component_number,&Component_numberTag);

			if(Component_numberTag == NULLTAG )
			{
				if(IsError == 0)
				{	
					IsError = 1;
				}
				fprintf(fp_Output,"%s\n",Component_number);fflush(fp_Output);
			}			
		}

		fclose(fp_Output);
		if(IsError == 1)
		{
			printf("\n Part Quety : Error found for missing part so stopping\n");fflush(stdout);
			return status;			
		}
		else
		{
			printf("\n Part Quety : No Error found. So Going to create BOM\n");fflush(stdout);
		}

	}
	else
	{
		printf("\n Part Quety : Can't open file \n");fflush(stdout);
	}
	fclose(fp);
	fp=NULL;
	printf("\n CVprod - Ketan bomCreateValidation SUCCESS.\n");fflush(stdout);
	//

	////////////// For BOM //////////
	fp=fopen("Part_List_File.txt","r");

	if(fp!=NULL)
	{
		inputline=(char *) MEM_alloc(1000);
		while(fgets(inputline,1000,fp)!=NULL)
		{
			fputs(inputline,stdout);	
			
			Main_srl			= NULL;
			Component_number	= NULL;
			Qty					= NULL;
			CKDVC_Dummy_Part	= NULL;
			Action				= NULL;
			PlantName			= NULL;

			Main_srl			=strtok(inputline,"~");  
			Component_number	=strtok(NULL,"~"); 
			Qty					=strtok(NULL,"~"); 
			CKDVC_Dummy_Part	=strtok(NULL,"~");
			Action				=strtok(NULL,"~");
			PlantName			=strtok(NULL,"~");
			
			printf("\n RowNo: %d CKD data %s || %s || %s || %s || %s || %s\n",Row+1,Main_srl,Component_number,Qty,CKDVC_Dummy_Part,Action,PlantName);fflush(stdout);

			tag_t	CKDVC_Dummy_PartTag		= NULLTAG;
			tag_t	CKDVC_Dummy_PartTagrev	= NULLTAG;

			QueryPart(CKDVC_Dummy_Part,&CKDVC_Dummy_PartTag);

			ITKCALL( ITEM_ask_latest_rev(CKDVC_Dummy_PartTag,&CKDVC_Dummy_PartTagrev));

			ITKCALL( AOM_ask_value_string(CKDVC_Dummy_PartTagrev,"current_id",&ParentPartNumber));
			
			ITKCALL( AOM_ask_value_string(CKDVC_Dummy_PartTagrev,"current_revision_id",&ParentRevision));
			printf("\n ParentPartNumber and ParentRevision --> [%s,%s] \n",ParentPartNumber,ParentRevision);fflush(stdout);

			printf("\n calling Function1 \n");fflush(stdout);
			tm_create_ckd_bom(CKDVC_Dummy_PartTag,CKDVC_Dummy_PartTagrev, Component_number,Qty,Main_srl,Action,PlantName);
			
		}
		printf("\n----------------END OF PART-----------------------------------\n");fflush(stdout);

	}
	else
	{
		printf("\n Can't open file \n");fflush(stdout);
	}

	printf("\n CVprod - Ketan bomloadingCKD SUCCESS \n");fflush(stdout);
	
	

	return status;
	
}																		
																			