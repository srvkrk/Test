//#include <tccore/iman_msg.h>
//#include <tc/tc.h>
//#include <epm/releasestatus.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
//#include <itk/mem.h>
//#include <epm/cr_effectivity.h>
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>//Added by Anshul Multilevel BOM explode
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <tc/folder.h>

#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}


#define Debug TRUE

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;



void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

int days( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}

void  getMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

void getNextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= days( month, year );//calling days function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

int ES_PSDFinalReleased(tag_t  ES_Rev_Tag)
{
	int		status;
	int		max_char_size	= 80;
	int		ifail			= 0;
	
	char*	CurrentTask		= NULL;
	char*	parent_name		= NULL;
	char*	type_name1		= NULL;
	char*	lcsToset		= NULL;
	char*	object_type		= NULL;
	char*	ReleaseStatus	= NULL;
	char*	ReleaseStatus_ES= NULL;
	char*	item_name		= NULL;
	char*	WSO_Name		= NULL;
	char	cNextDate[20]={0};
	char	cCurrentAccessDate[20]={0};
	char*	type_name		= NULL;
	//char	type_name[TCTYPE_name_size_c+1];

	tag_t	status2		= NULLTAG;
	tag_t	status2_ES	= NULLTAG;
	tag_t	objTypeTag	= NULLTAG;
	tag_t*	PartTags	= NULLTAG;
	tag_t	AssyTag		= NULLTAG;
	tag_t*  status_list1= NULLTAG;

	logical retain		= false;
	logical retain_ES	= false;
    logical stat;

	int		error_code	= ITK_ok;
	int		num			= 0;
	int		i			= 0;
	int		j			= 0;
	int		ii			= 0;
	int		count		= 0;
	int		PartCnt		= 0;
	int		k			= 0;
	int     st_count1	= 0;
	
	date_t Release_date;

	lcsToset =(char *) MEM_alloc(20 * sizeof(char *));

    printf("\n **************inside ES_PSDFinalReleased***************\n ");fflush(stdout);
	strcpy(lcsToset,"T5_PSDFinalReleased");

	printf("\n ES_PSDFinalReleased \n"); fflush(stdout);

	if(TCTYPE_ask_object_type(ES_Rev_Tag,&objTypeTag));
    if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n     type_name changes done: for workspaceobject     %s\n", type_name);fflush(stdout);

	getCurrentDateTime(cCurrentAccessDate);
	printf("\n cCurrentAccessDate:%s",cCurrentAccessDate);
	CALLAPI(ITK_string_to_date(cCurrentAccessDate, &Release_date ));
	CALLAPI(AOM_lock(ES_Rev_Tag));
	CALLAPI(AOM_set_value_date(ES_Rev_Tag,"t5_ActualRelDate",Release_date));
	CALLAPI(AOM_save_without_extensions(ES_Rev_Tag));
	CALLAPI(AOM_unlock(ES_Rev_Tag));
	
	if(strcmp(type_name,"T5_EstimateSheetRevision")==0 )
	{
	    printf("\n inside class T5_EstimateSheetRevision......\n");fflush(stdout);

		printf("\n T5_EstimateSheetRevision Stamping \n");fflush(stdout);

		int st_count_1			= 0;
		int cnt					= 0;
		int	ESFlag				= 0;
		
		char*	WSO_Name		= NULL;
		char*	ES_ReleaseStatus= NULL;
				
		tag_t*	status_list1	= NULLTAG;
		tag_t	status_rel		= NULLTAG;
		
		logical		retain		= 0;
		
		CALLAPI(WSOM_ask_release_status_list(ES_Rev_Tag,&st_count_1,&status_list1));
		printf("\n st_count_1 :%d is\n",st_count_1);fflush(stdout);

		if(st_count_1>0)
		{
			for (cnt=0;cnt< st_count_1;cnt++ )
			{
				WSO_Name=NULL;
				ITKCALL(AOM_ask_name(status_list1[cnt],&WSO_Name));
				printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
				if(tc_strcmp(WSO_Name,"")!=0)
				{
					if (tc_strcmp(WSO_Name,lcsToset)==0)
					{
						printf("\n Release status matched. \n");fflush(stdout);
						ESFlag = 1;
					}
				}
			}
		}
		printf("\n ####### ESFlag :%d is\n",ESFlag);fflush(stdout);

		if(ESFlag == 0)
		{
			printf("\n Inside Flag. Removing release status \n");fflush(stdout);
			// Remove status in Estimate Sheet // 
			tag_t	tReleaseStatusList_checkin_ES	= NULLTAG; 
			tag_t	class_id_ES						= NULLTAG;

			char	*class_name_ES					=    NULL;

			int			n_values_checkin_ES	= 0; 
			int			cunt1_ES			= 0; 
			int			cunt2_ES			= 0; 

			logical		log1_ES;
			tag_t*		attr_tags_checkin_ES	=	NULLTAG; 
			logical		*is_it_null_checkin_ES	=   NULL; 
			logical		*is_it_empty_checkin_ES	=   NULL; 

			int       st_count_ES=0;
			tag_t*    status_list_ES;

			ITK_CALL(POM_class_of_instance(ES_Rev_Tag,&class_id_ES));
			ITK_CALL(POM_name_of_class(class_id_ES,&class_name_ES));
			printf("\n class_name_ES is :%s\n",class_name_ES);fflush(stdout);

			ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name_ES,&tReleaseStatusList_checkin_ES));fflush(stdout);
			printf("\n after getting rel stat...\n");fflush(stdout);

			POM_unload_instances (1,&ES_Rev_Tag);
			printf("\n test2 \n");fflush(stdout);
			ITK_CALL(POM_load_instances(1,&ES_Rev_Tag,class_id_ES,1));
			printf("\n test3 \n");fflush(stdout);
			ITK_CALL(POM_is_loaded(ES_Rev_Tag,&log1_ES));
			printf("\n test4 \n");fflush(stdout);

			if(log1_ES == 1)
			{
				 printf(" Load Success\n " );
			}
			else
			printf("Load Failure\n"  );
			
			ITK_CALL( POM_length_of_attr(ES_Rev_Tag, tReleaseStatusList_checkin_ES, &n_values_checkin_ES) );
			printf("\n n_values_checkin_ES is :%d\n",n_values_checkin_ES);fflush(stdout);

			if(n_values_checkin_ES>0)
			{
				printf("\n Inside cunt1_ES: [%d]",cunt1_ES);fflush(stdout);
				ITK_CALL( POM_ask_attr_tags(ES_Rev_Tag, tReleaseStatusList_checkin_ES, 0, n_values_checkin_ES, &attr_tags_checkin_ES, &is_it_null_checkin_ES, &is_it_empty_checkin_ES ));
				printf("\n n_values_checkin_ES is :%d\n",n_values_checkin_ES);fflush(stdout);

				for (cunt1_ES =  0; cunt1_ES < n_values_checkin_ES; cunt1_ES++)
				{
					printf("\n before cunt1_ES: [%d]",cunt1_ES);fflush(stdout);
					ITK_CALL(POM_remove_from_attr(1,&ES_Rev_Tag,tReleaseStatusList_checkin_ES,cunt1_ES,1));

					printf("\n cunt1_ES == 0 removedd is :%d\n",cunt1_ES);fflush(stdout);
					
					ITK_CALL(POM_save_instances(1,&ES_Rev_Tag,1));
					ITK_CALL(AOM_lock(ES_Rev_Tag));
					ITK_CALL(AOM_save_without_extensions(ES_Rev_Tag));
					ITK_CALL(AOM_refresh(ES_Rev_Tag,1));
					ITK_CALL(AOM_unlock(ES_Rev_Tag));
				}
			}

			CALLAPI(RELSTAT_create_release_status(lcsToset,&status2_ES));
			CALLAPI(AOM_ask_name(status2_ES, &ReleaseStatus_ES));
			printf("\n ******************* ReleaseStatus_ES: %s\n",ReleaseStatus_ES);fflush(stdout);
			CALLAPI(RELSTAT_add_release_status(status2_ES,1,&ES_Rev_Tag,retain_ES));

		}

		// End of remove status in Estimate Sheet //
		
		PartCnt=0;
		CALLAPI(AOM_ask_value_tags(ES_Rev_Tag,"T5_EstimateOprationRelation",&PartCnt,&PartTags));
		printf("\n\n\t\t Operations Count is :%d",PartCnt);fflush(stdout);
		if (PartCnt>0)
		{
			for (k=0;k<PartCnt ;k++ )
			{
				printf("\n\n\t\t APL DML Cre:for k =:%d",k);fflush(stdout);
				AssyTag=PartTags[k];

				// Remove status in Estimate Sheet Opration // 
				tag_t		tReleaseStatusList_checkin=NULLTAG; 
				tag_t		class_id				=     NULLTAG;

				char		*class_name				=    NULL;

				int			n_values_checkin			=0; 
				int			cunt1			=0; 
				int			cunt2			=0; 

				logical		log1;
				tag_t*		attr_tags_checkin		=	NULLTAG; 
				logical		*is_it_null_checkin		=   NULL; 
				logical		*is_it_empty_checkin	=   NULL; 

				int       st_count=0;
				tag_t*    status_list;

				ITK_CALL(POM_class_of_instance(AssyTag,&class_id));
				ITK_CALL(POM_name_of_class(class_id,&class_name));
				printf("\n class_name is :%s\n",class_name);fflush(stdout);

				ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
				printf("\n after getting rel stat...");fflush(stdout);

				POM_unload_instances (1,&AssyTag);
				printf("\n test2 \n");fflush(stdout);
				ITK_CALL(POM_load_instances(1,&AssyTag,class_id,1));
				printf("\n test3 \n");fflush(stdout);
				ITK_CALL(POM_is_loaded(AssyTag,&log1));
				printf("\n test4 \n");fflush(stdout);

				if(log1 == 1)
				{
					 printf(" Load Success\n " );
				}
				else
				printf("Load Failure\n"  );
				
				ITK_CALL( POM_length_of_attr(AssyTag, tReleaseStatusList_checkin, &n_values_checkin) );
				printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

				if(n_values_checkin>0)
				{
					printf("\n Inside cunt1: [%d]",cunt1);fflush(stdout);
					ITK_CALL( POM_ask_attr_tags(AssyTag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
					printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);

					for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
					{
						printf("\n before cunt1: [%d]",cunt1);fflush(stdout);
						ITK_CALL(POM_remove_from_attr(1,&AssyTag,tReleaseStatusList_checkin,cunt1,1));

						printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);
						
						ITK_CALL(POM_save_instances(1,&AssyTag,1));
						ITK_CALL(AOM_lock(AssyTag));
						ITK_CALL(AOM_save_without_extensions(AssyTag));
						ITK_CALL(AOM_refresh(AssyTag,1));
						ITK_CALL(AOM_unlock(AssyTag));
					}
				}

				// End of remove status in Estimate Sheet Opration //

				CALLAPI(RELSTAT_create_release_status(lcsToset,&status2));
				CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
				printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
				CALLAPI(RELSTAT_add_release_status(status2,1,&AssyTag,retain));
			}
		}
	}
	return error_code;
}


void autoresizestrAdd_ES(char **src,char* dest)
{
        // char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
         char * desc = dest ? dest : "NA";
        //printf("\n autoresizestrAdd src len==%d",strlen(*src));
        //printf("\n autoresizestrAdd desc len==%d",strlen(desc));
        const size_t a = strlen(*src);
        const size_t b = strlen(desc);
        const size_t size_ab = a + b + 2;
   // src = MEM_realloc(src, size_ab);
        *src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
        tc_strcat(*src , desc);
}

extern int ITK_user_main( int argc, char **argv )
{
	//VARIABLE DECLARATION STARTS
	int     status;
	int     ifail;
	
	char	*PlantCS				=	NULL;
	char	*item_type				=	NULL;
	char	*type_name				=	NULL;
	char	*req_item				=	NULL;
	char	*cUserName				=	NULL;
	char	*cPassWord				=	NULL;
	char	*cUserGrp				=	NULL;
	char	*ClosureRule			=	NULL;
	char	*revStr					=	NULL;
	char	*revStr1				=	NULL;
	char	*tmpStr					=	NULL;
	char	*FromDate					=	NULL;
	char	*erc_rel_type_check					=	NULL;
	char	*item_id					=	NULL;
	char	*Proj_Code					=	NULL;
	tag_t tag_query;
  	int n_entries=1;
  	int n_tags_found=0;
  	int itmRCnt=0;

	tag_t	task_tag				=	NULLTAG;
	tag_t	tsk_rev_tag				=	NULLTAG;
	tag_t	objTypeTag				=	NULLTAG;
	char *entries[1] = {"Item ID"};
		char **values =	(char **) MEM_alloc(10 * sizeof(char *));
	tag_t *tags_found = NULL;
	FILE* fperror=NULL;

	char*	Input_ES       = NULL;

	tag_t	ES_No		= NULLTAG;
	tag_t	ES_Rev_Tag	= NULLTAG;
	//FromDate = ITK_ask_cli_argument("-i=");

	char*	inputuser			= NULL;
	char*	inputpwd			= NULL;
	char*	inputgrp			= NULL;
	char*	s					= NULL;

	printf("\n Inside Ketan Main Function for ES Stamping\n");fflush(stdout);

	//inputuser	   = ITK_ask_cli_argument("-u=");
	//inputpwd	   = ITK_ask_cli_argument("-p=");
	//inputgrp	   = ITK_ask_cli_argument("-g=");
	//
	//if (ITK_init_module(inputuser,inputpwd,inputgrp) == ITK_ok )
	//{
		ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
		CALLAPI(ITK_auto_login());
		ITK_set_bypass(true);

		CALLAPI(ITK_set_journalling(TRUE));
		if (status == 0 )
		{
			printf("\n login to Teamcenter successful");fflush(stdout);
		}
		else
		{
		  printf("\n Error code:%d",status);fflush(stdout);
		  EMH_ask_error_text(status,&s);
		  printf("\n Error message:%s",s);fflush(stdout);
		}

		printf("\n  Test 1.1 \n");fflush(stdout);

		Input_ES   = (char *) MEM_alloc(1 * sizeof(char *));
		printf("\n  Test 1.2 \n");fflush(stdout);
		

		printf("\n  Test 1.3 \n");fflush(stdout);

		autoresizestrAdd_ES(&Input_ES,argv[4]);

		printf("\n  Test 1.4 \n");fflush(stdout);

		printf("\n  Test 1.5 \n");fflush(stdout);

		printf("\n Input_ES :: %s ",Input_ES);fflush(stdout);

		char* ES_Num		= NULL;
		int max_char_size = 80;
		ES_Num = (char *)MEM_alloc(max_char_size * sizeof(char));

		tc_strcpy(ES_Num,Input_ES);

		printf("\n Final ES_Num => [%s]\n",ES_Num);;fflush(stdout);
	

		// //VARIABLE DECLARATION ENDS
		// ITK_CALL(ITK_auto_login());  
		// 
		// ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		// printf("\n Auto login ");fflush(stdout);
		// ITK_CALL(ITK_set_journalling( TRUE ));
		// 
		// Input_ES = ITK_ask_cli_argument("-es=");
		// 
		// printf("\n Input_ES => %s\n",Input_ES); fflush(stdout);

		char*	qry_entryCntrlformat[2]  = {"Type","Item ID"};	
		char**	qry_valuesCntrlformat= (char **) MEM_alloc(5 * sizeof(char *));

		tag_t   qryTagCntrlobj	= NULLTAG;
		tag_t*	ES_tags			= NULLTAG;

		int     n_entryCntrlobj		= 2;
		int		controlObjfound		= 0;
		int		cntt				= 0;
		
		if(QRY_find2("Item Revision...", &qryTagCntrlobj));
		if (qryTagCntrlobj)
		{
			printf("\n Control Object Query Found \n");fflush(stdout);
			qry_valuesCntrlformat[0]="Estimate Sheet Revision";
			qry_valuesCntrlformat[1]=ES_Num;

			
			if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &ES_tags));
		}
		else
		{
			printf("\n Item Revision... Query not Found \n");fflush(stdout);
		}	
		
		printf("\n controlObjfound : %d\n",controlObjfound);fflush(stdout);

		if(controlObjfound>0)
		{
			for (cntt = 0; cntt < controlObjfound; cntt++)
			{
				ES_Rev_Tag = NULLTAG;
				ES_Rev_Tag = ES_tags[cntt];

				if(TCTYPE_ask_object_type(ES_Rev_Tag,&objTypeTag));
				if(TCTYPE_ask_name2(objTypeTag,&type_name));
				printf("\n type_name : %s",type_name);fflush(stdout);

				if(strcmp(type_name,"T5_EstimateSheetRevision")==0)
				{
					printf("\n Inside Ketan Class  T5_EstimateSheetRevision \n",type_name);fflush(stdout);
					ES_PSDFinalReleased( ES_Rev_Tag );
				}
			}
		}

	//}
	
	printf("\n Ketan Code ends...\n");fflush(stdout);

	printf("\n----------- ES Stamped Successfully -----------------------------------------\n");fflush(stdout);
	return status;

}
