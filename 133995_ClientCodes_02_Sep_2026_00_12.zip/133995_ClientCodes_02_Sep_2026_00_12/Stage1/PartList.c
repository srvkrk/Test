/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   PartList.c
*  Author		 :   Sagar Baviskar
*  Module		 :   Checks the status of Parts if APLC Rlzd and APLC Wrkg both are found then deletes APLC Wrkg Status
Similarly STDSIC Rlzd and STDSIC Wrkg both are found then deletes STDSIC Wrkg Status from Part, write parts data to file.
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes

***************************************************************************/
#include <stdio.h>
#include <tc/tc.h>
#include <string.h>
#include <stdlib.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <itk/mem.h>
#include <stdlib.h>
#include <tccore/grm.h>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/tctype.h>
#include <tccore/imantype.h>
#include <tccore/workspaceobject.h>
#include <tccore/custom.h>
#include <tccore/imantype.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\


int Remove_RlzStat(tag_t Part_tag,FILE *fpPart )
{	
	tag_t PrtClass_id = NULLTAG;
	char *PartClass_name = NULL;
	tag_t PrtStatLst_AttrID = NULLTAG;
	int st_count2 = 0;
	int i = 0;
	int k = 0;
	tag_t *status_list2 = NULLTAG;
	logical	log2;
	int PrtStatLst_Length = 0;
	tag_t *PrtStatLst_Attr_tag = NULLTAG;
	logical	*is_it_null2 = NULL;
	logical	*is_it_empty2 = NULL;
	logical	Retain_Released_Date = 0;
	tag_t PrtType_tag = NULLTAG;
	char *PartTypeName = NULL;
	char *PrtRlz_Status = NULL;
	tag_t TaskTypeTag = NULLTAG;
	char *Task_Type = NULL;
	int ERC_Task_Flag = 0;
	int APL_Task_Flag = 0;
	int ERC_Review_Flag = 0;
	int ERC_Rlz_Flag = 0;
	int APL_Wrkg_Flag = 0;
	int APL_Rlz_Flag = 0;
	int STD_Wrkg_Flag = 0;
	int STD_Rlz_Flag = 0;
	int DML_Task_Count = 0;
	tag_t *DML_Task_tag = NULLTAG;
	tag_t PrtTask_RelType_tag = NULLTAG;
	char *PartID2 = NULL;
	char *PartRevID2 = NULL;
	char *Obj_Type2 = NULL;
	int count = 0;

	tag_t APLTask_DML_RelType_tag = NULLTAG;
	int APLDML_Count = 0;
	tag_t *APLDML_tag = NULLTAG;
	char *APLDML_id = NULL;
	int PP_APLDML_Flag = 0;
    int AM_APLDML_Flag = 0;

	int Flag_1 =0;
	int Flag_2 =0;
	int st_count3 =0;
	tag_t *status_list3 = NULLTAG;
	logical	log3;
	int PrtStatLst_Length3 = 0;
	tag_t *PrtStatLst_Attr_tag3 = NULLTAG;
	logical	*is_it_null3 = NULL;
	logical	*is_it_empty3 = NULL;
	char *PrtRlz_Status3 = NULL;
	tag_t ERC_Review_Status = NULLTAG;
	char *ERCReviewStatus = NULL;
	tag_t ERC_Rlz_Status = NULLTAG;
	char *ERCRlzStatus = NULL;
	
	printf("\n In Remove_RlzStat Function \n");fflush(stdout);
	ITK_CALL(POM_class_of_instance(Part_tag,&PrtClass_id)); 
	ITK_CALL(POM_name_of_class(PrtClass_id,&PartClass_name));
	printf("\n Part Class Name is : %s\n",PartClass_name);fflush(stdout);
	ITK_CALL(POM_attr_id_of_attr("release_status_list",PartClass_name,&PrtStatLst_AttrID));
	ITK_CALL(WSOM_ask_release_status_list(Part_tag,&st_count2,&status_list2));
	printf("\n st_count2 is : %d \n",st_count2);fflush(stdout);
	ITK_CALL(POM_unload_instances(1,&Part_tag));
	ITK_CALL(POM_load_instances(1,&Part_tag,PrtClass_id,1));
	ITK_CALL(POM_is_loaded(Part_tag,&log2));
	if(log2 == 1)
	{
		 printf(" Load Success\n " );fflush(stdout);
	}
	else
	{
	printf(" Load Failure\n"  );fflush(stdout);
	}
	ITK_CALL( POM_length_of_attr(Part_tag, PrtStatLst_AttrID, &PrtStatLst_Length) );
	ITK_CALL( POM_ask_attr_tags(Part_tag, PrtStatLst_AttrID, 0, PrtStatLst_Length, &PrtStatLst_Attr_tag, &is_it_null2, &is_it_empty2 ));
    int statusfnd=0;

	AOM_ask_value_string(Part_tag,"item_id",&PartID2);
	AOM_ask_value_string(Part_tag,"item_revision_id",&PartRevID2);
	TCTYPE_ask_object_type(Part_tag,&PrtType_tag);fflush(stdout);
	TCTYPE_ask_name2(PrtType_tag,&PartTypeName);

	for(count=0; count<PrtStatLst_Length;count++)
		{
			AOM_ask_name(PrtStatLst_Attr_tag[count], &PrtRlz_Status);
			printf("\n Release status is : %s",PrtRlz_Status);fflush(stdout);
			
			if((tc_strcmp(PrtRlz_Status,"T5_LcsAPLWrkg")==0))	
			{
				APL_Wrkg_Flag++;
				printf("\n APL_Wrkg_Flag = %d ",APL_Wrkg_Flag);fflush(stdout);
			}
			if((tc_strcmp(PrtRlz_Status,"T5_LcsAplRlzd")==0))	
			{
				APL_Rlz_Flag++;
				printf("\n APL_Rlz_Flag = %d ",APL_Rlz_Flag);fflush(stdout);
			}
			if((tc_strcmp(PrtRlz_Status,"T5_LcsSTDWrkg")==0))	
			{
				STD_Wrkg_Flag++;
				printf("\n STD_Wrkg_Flag = %d ",STD_Wrkg_Flag);fflush(stdout);
			}
			if((tc_strcmp(PrtRlz_Status,"T5_LcsStdRlzd")==0))	
			{
				STD_Rlz_Flag++;
				printf("\n STD_Rlz_Flag = %d ",STD_Rlz_Flag);fflush(stdout);
			}
			
		}

	
	if (STD_Wrkg_Flag > 0 && STD_Rlz_Flag >0)
	{
		printf("\n Part having both STDSIC Wrkg and STDSIC Rlz status \n");fflush(stdout);
		printf("\n Removine STDSIC Wrkg status \n");fflush(stdout);	

		st_count3 = 0;
		status_list3 = NULLTAG;							
		PrtStatLst_Length3 = 0;
		PrtStatLst_Attr_tag3 = NULLTAG;
		is_it_null3 = NULL;
		is_it_empty3 = NULL;

		ITK_CALL(WSOM_ask_release_status_list(Part_tag,&st_count3,&status_list3));
		printf("\n st_count3 is : %d \n",st_count3);fflush(stdout);
		ITK_CALL(POM_unload_instances(1,&Part_tag));
		ITK_CALL(POM_load_instances(1,&Part_tag,PrtClass_id,1));
		ITK_CALL(POM_is_loaded(Part_tag,&log3));
		if(log3 == 1)
		{
			 printf(" Load Success\n " );fflush(stdout);
		}
		else
		{
		printf(" Load Failure\n"  );fflush(stdout);
		}
		ITK_CALL( POM_length_of_attr(Part_tag, PrtStatLst_AttrID, &PrtStatLst_Length3) );
		ITK_CALL( POM_ask_attr_tags(Part_tag, PrtStatLst_AttrID, 0, PrtStatLst_Length3, &PrtStatLst_Attr_tag3, &is_it_null3, &is_it_empty3 ));

		Flag_1 = 0;
		count = 0;
		for(count=0; count<PrtStatLst_Length3;count++)
			{
				AOM_ask_name(PrtStatLst_Attr_tag3[count], &PrtRlz_Status3);
		              printf("\n Release status is : %s",PrtRlz_Status3);fflush(stdout);

				if( (tc_strcmp(PrtRlz_Status3,"T5_LcsSTDWrkg")==0))	
				{
					printf("\n STDSIC Working status found on Part\n");fflush(stdout);
					printf("\n Removing STDSIC Working Status from Part\n");fflush(stdout);
					fprintf(fpPart,"Part Count : [%s],[%s], both STDSIC Wrkg and STDSIC Rlz status found (Removing STDSIC Working Status from Part) \n ",PartID2,PartRevID2);
					
					ITK_CALL(POM_remove_from_attr(1,&Part_tag,PrtStatLst_AttrID,Flag_1,1));  //Removes status from object
					ITK_CALL(POM_save_instances(1,&Part_tag,1));
					ITK_CALL(POM_refresh_instances(1,&Part_tag,PrtClass_id,2));
					ITK_CALL(AOM_lock(Part_tag));
					ITK_CALL(AOM_save(Part_tag));
					ITK_CALL(AOM_refresh(Part_tag,1));
					ITK_CALL(AOM_unlock(Part_tag));
					printf("\n STDSIC Working Rlz Status Removed Successfully \n");fflush(stdout);
					
					break;
				}
				Flag_1++;							
			}
	
	}
	
	if (APL_Wrkg_Flag > 0 && APL_Rlz_Flag >0)
	{
		printf("\n Part having both APL Wrkg and APL Rlz status\n");fflush(stdout);
		printf("\n Removing APL Wrkg status \n");fflush(stdout);
		
		st_count3 = 0;
		status_list3 = NULLTAG;							
		PrtStatLst_Length3 = 0;
		PrtStatLst_Attr_tag3 = NULLTAG;
		is_it_null3 = NULL;
		is_it_empty3 = NULL;
		
		ITK_CALL(WSOM_ask_release_status_list(Part_tag,&st_count3,&status_list3));
		printf("\n st_count3 is : %d \n",st_count3);fflush(stdout);
		ITK_CALL(POM_unload_instances(1,&Part_tag));
		ITK_CALL(POM_load_instances(1,&Part_tag,PrtClass_id,1));
		ITK_CALL(POM_is_loaded(Part_tag,&log3));
		if(log3 == 1)
		{
			 printf(" Load Success\n " );fflush(stdout);
		}
		else
		{
		printf(" Load Failure\n"  );fflush(stdout);
		}
		ITK_CALL( POM_length_of_attr(Part_tag, PrtStatLst_AttrID, &PrtStatLst_Length3) );
		ITK_CALL( POM_ask_attr_tags(Part_tag, PrtStatLst_AttrID, 0, PrtStatLst_Length3, &PrtStatLst_Attr_tag3, &is_it_null3, &is_it_empty3 ));                                         
		                    
		Flag_2 = 0;
		count = 0;
		for(count=0; count<PrtStatLst_Length3;count++)
		{
		        AOM_ask_name(PrtStatLst_Attr_tag3[count], &PrtRlz_Status3);
		        printf("\n Release status is : %s",PrtRlz_Status3);fflush(stdout);
		        
		        if( (tc_strcmp(PrtRlz_Status3,"T5_LcsAPLWrkg")==0) )	
				{
					printf("\n APLC Working status found on Part\n");fflush(stdout);
					printf("\n Removing APLC Working Status from Part\n");fflush(stdout);
					fprintf(fpPart,"Part Count : [%s],[%s],both APL Wrkg and APL Rlz status found (Removing APLC Working Status from Part) \n ",PartID2,PartRevID2);
					
					ITK_CALL(POM_remove_from_attr(1,&Part_tag,PrtStatLst_AttrID,Flag_2,1));  //Removes status from object
					ITK_CALL(POM_save_instances(1,&Part_tag,1));
					ITK_CALL(POM_refresh_instances(1,&Part_tag,PrtClass_id,2));
					ITK_CALL(AOM_lock(Part_tag));
					ITK_CALL(AOM_save(Part_tag));
					ITK_CALL(AOM_refresh(Part_tag,1));
					ITK_CALL(AOM_unlock(Part_tag));
					printf("\n APLC Working Rlz Status Removed Successfully \n");fflush(stdout);
					
					break;
				}									
			Flag_2++;	                    		
		}				
	}
	
}

int Check_RlzStat(tag_t Part_tag,FILE *fpPart )
{
	tag_t PrtClass_id = NULLTAG;
	char *PartClass_name = NULL;
	tag_t PrtStatLst_AttrID = NULLTAG;
	int PrtStatLst_Length = 0;
	tag_t *PrtStatLst_Attr_tag = NULLTAG;
	logical	*is_it_null = NULL;
	logical	*is_it_empty = NULL;
	logical	Retain_Released_Date = 0;
	int st_count = 0;
	int count = 0;
	tag_t *status_list = NULLTAG;
	logical	log;

	char *PartID = NULL;
    char *PartRevID = NULL;
	tag_t PrtType_tag = NULLTAG;
	char *PartTypeName = NULL;
	char *PrtRlz_Status = NULL;

	tag_t TaskTypeTag = NULLTAG;
	char *Task_Type = NULL;
	
	int APL_Wrkg_Flag = 0;
	int APL_Rlz_Flag = 0;
	int STD_Wrkg_Flag = 0;
	int STD_Rlz_Flag = 0;
	


	printf("\n In Check_RlzStat Function \n");fflush(stdout);
	//ITK_CALL(POM_class_of_instance(Part_tag,&PrtClass_id)); 
	//ITK_CALL(POM_name_of_class(PrtClass_id,&PartClass_name));
	//printf("\n Part Class Name is : %s\n",PartClass_name);fflush(stdout);
	//ITK_CALL(POM_attr_id_of_attr("release_status_list",PartClass_name,&PrtStatLst_AttrID));
	ITK_CALL(WSOM_ask_release_status_list(Part_tag,&st_count,&status_list));
	printf("\n st_count is : %d \n",st_count);fflush(stdout);

	for(count=0; count<st_count;count++)
	{
		AOM_ask_name(status_list[count], &PrtRlz_Status);
		printf("\n Release status is : %s",PrtRlz_Status);fflush(stdout);

		if((tc_strcmp(PrtRlz_Status,"T5_LcsAPLWrkg")==0))	
		{
			APL_Wrkg_Flag++;
			printf("\n APL_Wrkg_Flag = %d ",APL_Wrkg_Flag);fflush(stdout);
		}
		if((tc_strcmp(PrtRlz_Status,"T5_LcsAplRlzd")==0))	
		{
			APL_Rlz_Flag++;
			printf("\n APL_Rlz_Flag = %d ",APL_Rlz_Flag);fflush(stdout);
		}
		if((tc_strcmp(PrtRlz_Status,"T5_LcsSTDWrkg")==0))	
		{
			STD_Wrkg_Flag++;
			printf("\n STD_Wrkg_Flag = %d ",STD_Wrkg_Flag);fflush(stdout);
		}
		if((tc_strcmp(PrtRlz_Status,"T5_LcsStdRlzd")==0))	
		{
			STD_Rlz_Flag++;
			printf("\n STD_Rlz_Flag = %d ",STD_Rlz_Flag);fflush(stdout);
		}
	}
	
	if (STD_Wrkg_Flag > 0 && STD_Rlz_Flag >0)
	{
		AOM_ask_value_string(Part_tag,"item_id",&PartID);
	    AOM_ask_value_string(Part_tag,"item_revision_id",&PartRevID);
		printf("\n Part having both STDSIC Wrkg and STDSIC Rlz status \n");
		fprintf(fpPart,"Part Count : [%s],[%s], Status = STDSIC Working + STDSIC Released (Project Code = 5445) \n ",PartID,PartRevID);
		// Function call for removing status
	}
	
}

int ITK_user_main(int argc,char* argv[]) // Main Function
{
   int Part_count = 0;
   int Rev_Count = 0;
   char *message;
   char *loggedInUser = NULL;
   char *PartID = NULL;
   char *PartRevID = NULL;
      
   FILE *fpPart = NULL;  
   FILE *fpQry_Result = NULL;
   int PartCount = 0;
   int	ifail=0;
   int	i=0;
   int n_entries = 1;
   int	Part_Count=0; 
   tag_t *Part_list = NULLTAG;
   tag_t *Rev_list = NULLTAG;
   tag_t *PartTag = NULLTAG;
   tag_t Req_Part_Rev = NULLTAG;
   
   char *Part_List_File = NULL;  
   char *PartType = NULL;
   tag_t PartType_tag = NULLTAG;
   tag_t QryTag = NULLTAG;
   //char	**qry_values		=	(char **) MEM_alloc(10 * sizeof(char *));

   
		
		ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		//ITK_CALL(ITK_set_journalling( TRUE ));
	    //Auto-Logging in to TC
        status = ITK_auto_login ();
		
        if (status != ITK_ok ) 
			{
               EMH_ask_error_text(status, &message);
               printf(" Error with ITK_auto_login : \"%d\", \"%s\"\n", status, message);
               MEM_free(message);
               return status;
            }
		else
			{
				printf(" Auto login Successfully\n");fflush(stdout);
				POM_get_user_id(&loggedInUser);
				printf(" Logged in User is : %s\n",loggedInUser);fflush(stdout);
			}

        ITK_set_journalling (TRUE);	
		//fpQry_Result=fopen("Qry_Result_Count.txt","w");
		fpPart=fopen("5442_Part_Count_Log.txt","w");	
	   
			
			//char *qry_entries[1];
			//qry_entries[0] = "Project Code";
			//qry_values[0] = "5445";
			//tc_strcpy(qry_values[0], "5445");
			char *qry_entries[1] = {"t5_ProjectCode"};
			char *qry_values[1] = {"5442"};
			ITK_CALL(QRY_find("DesignRevision",&QryTag));
			if(QryTag != NULLTAG) printf("\n Query Tag Found\n");fflush(stdout);
			ITK_CALL(QRY_execute(QryTag,n_entries, qry_entries, qry_values,&Part_Count,&PartTag));
			printf("\n Part_Count(Qry Result) = %d \n",Part_Count);
			
			for(i=0;i<Part_Count;i++)
			{
				
				TCTYPE_ask_object_type(PartTag[i],&PartType_tag);fflush(stdout);
				TCTYPE_ask_name2(PartType_tag,&PartType);
				printf("\n PartType  : %s\n ",PartType);fflush(stdout);	
				
				if(PartType == NULL)
				{
				  printf("\n PartType = NULL\n");
				  continue;
				}
				if(tc_strcmp(PartType,"")==0)
				{
				  printf("\n PartType2 = NULL\n");
				  continue;
				}
				ITK_CALL(AOM_ask_value_string(PartTag[i],"item_id",&PartID));			
				ITK_CALL(AOM_ask_value_string(PartTag[i],"item_revision_id",&PartRevID));
				printf("\n Part Count [ %s / %s ] ",PartID,PartRevID);fflush(stdout);
				//fprintf(fpQry_Result,"Qry Part Count : [%s],[%s] \n ",PartID,PartRevID);
				
				Remove_RlzStat(PartTag[i],fpPart); //Function call to check Rlz status			

			}

			 
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}




// compile PartList.c
// linkitk -o 5442_PartList PartList.o
// 5442_PartList -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba > 5442_Result.log &
// 5442_PartList -u=infodba -p=infodba -g=dba
// scp tcuaadev@172.22.97.90:/user/tcuaadev/devgroups/sagar/Part_List/5442_PartList .
//PartList3 -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba
