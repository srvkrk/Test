/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File			 :   Add_Status.c
*  Author		 :   Sagar Baviskar
*  Module		 :   Adds required Status to a particular part having required Revision and Sequence Id.
*                            
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes

***************************************************************************/
#include <stdio.h>
#include <tc/tc.h>
#include <string.h>
#include <stdlib.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <itk/mem.h>
#include <stdlib.h>
#include <tccore/grm.h>
#include <tcinit/tcinit.h>
#include <tc/emh.h>
#include <tccore/tctype.h>
#include <tccore/imantype.h>
#include <tccore/workspaceobject.h>
#include <tccore/custom.h>
#include <tccore/imantype.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define Debug TRUE
int status =0;
char *loggedInUser = NULL;
char *message = NULL;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\



int ITK_user_main(int argc,char* argv[]) // Main Function
{
	tag_t obj_tag = NULLTAG;
	tag_t *Part_list = NULLTAG;
	int Part_count = 0;
	int Rev_Count = 0;
	int i = 0;
	int j = 0;
	const char *attrs[1];
    const char *values[1];
	char *Part_ID = "5442B3C0172001";
	char *PartID = NULL;
	char *PartRevID = NULL;
	char *ReleaseStatus = NULL;
	int *PartSequenceID = NULL;
	tag_t *Rev_list = NULLTAG;
	tag_t ERC_Review_Status = NULLTAG;
	logical	Retain_Released_Date = 0;
	

	ITK_initialize_text_services (0);
	    //Auto-Logging in to TC
        status = ITK_auto_login ();
        if (status != ITK_ok ) 
	    {
             EMH_ask_error_text(status, &message);
             printf(" Error with ITK_auto_login : \"%d\", \"%s\"\n", status, message);
             MEM_free(message);
             return status;
        }
		else
		{
			printf(" Auto login Successfully\n");
			POM_get_user_id(&loggedInUser);
			printf(" Logged in User is : %s\n",loggedInUser);
		}

        ITK_set_journalling (TRUE);

		attrs[0] ="item_id";
	    values[0] = (char *)Part_ID;
		ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs,values, &Part_count, &Part_list));

		for(i=0; i<Part_count; i++)  //Start of Part_count loop
		{
			AOM_ask_value_tags(Part_list[0],"revision_list",&Rev_Count, &Rev_list);
            printf("\n Rev_Count : %d\n", Rev_Count);fflush(stdout);
			if (Rev_Count > 0)
			{
				for(j=0; j<Rev_Count; j++)
				{
					ITK_CALL(AOM_ask_value_string(Rev_list[j],"item_id",&PartID));
					ITK_CALL(AOM_ask_value_string(Rev_list[j],"item_revision_id",&PartRevID));
					ITK_CALL(AOM_ask_value_int(Rev_list[j],"sequence_id",&PartSequenceID));
					printf("\n Part ID/Part Revision ID/Sequence ID : %s / %s ; %d \n",PartID,PartRevID,PartSequenceID);

					if (tc_strcmp(PartRevID,"F;4")==0)
					{
						//if (PartSequenceID == 5)
						//{
							obj_tag = Rev_list[j];
							printf("\n Required Revision-Sequence Found... ");
							printf("\n Adding T5_LcsStdRlzd status... ");
							ITK_CALL(CR_create_release_status("T5_LcsStdRlzd",&ERC_Review_Status));
							ITK_CALL(AOM_ask_name(ERC_Review_Status, &ReleaseStatus));
							printf("\n Created %s status",ReleaseStatus);
							ITK_CALL(EPM_add_release_status(ERC_Review_Status,1,&obj_tag,Retain_Released_Date));
							printf("\n T5_LcsStdRlzd status added successfully \n");
						//}
											
					}
				}
			}
		}  //End of Part_count loop
	CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


// ./compile Add_Status.c
// ./linkitk -o Add_Status Add_Status.o
// Add_Status -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba 
// Add_Status -u=infodba -p=infodba -g=dba
// scp tcuaadev@172.22.97.90:/user/tcuaadev/devgroups/sagar/Add_Status/Add_Status .