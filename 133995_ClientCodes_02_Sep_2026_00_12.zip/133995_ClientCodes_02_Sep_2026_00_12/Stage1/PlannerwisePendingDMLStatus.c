#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <epm/cr_effectivity.h>
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
//#include "tm_apl_std_common_function.c"
#define NULLDATE   (POM_null_date()) 
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
//#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
//#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return
#define PROP_UIF_set_value_msg   "PROP_UIF_set_value"

#define PROP_set_value_int_msg   "PROP_set_value_int"

static void handle_ifail(char *file, int line);
static void MultiExplosion (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,int reqLevel,int level);
static void MultiExplosionLinkInfo (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,char *Uidd,int reqLevel,int level);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

	                

void getCurrentDateTime(char cCurrentAccessDate[20])
{

                int ch;
                time_t temp;
                struct tm *timeptr;
                char pAccessDate[20];
                char       DateS[4];
                printf("\n getCurrentDateTime calling..........\n");
                temp = time(NULL);
                tc_strcpy(pAccessDate,"");
                timeptr = (struct tm *)localtime(&temp);
                ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
                //ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
                tc_strcpy(cCurrentAccessDate,pAccessDate);
                printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

                //sprintf(DateS,"%d",(timeptr->tm_year+1900));
               // printf("Date:%d\n",(timeptr->tm_mday));
              //  printf("Month:%d\n",(timeptr->tm_mon)+1);
              //  printf("Year:%d\n",(timeptr->tm_year+1900));
                fflush(stdout);
}

int CalcDays(char* dt1)
{
	char 		*DateWtTime1		= 	NULL;
	char 		*Date1				= 	NULL;
	char 		*Month1				= 	NULL;;
	char 		*Year1				= 	NULL;
	char 		*DateCp				= 	NULL;
	int			iDay,iYear,iMonth	=   0;
	
	DateCp = strdup(dt1);
	
	printf("\n Hii... function CalcDays invoked");fflush(stdout);

	DateWtTime1 = strtok (DateCp," ");
	Date1 = strtok (DateWtTime1,"-");
	Month1 = strtok (NULL,"-");
	Year1 = strtok (NULL,"-");
	
	printf("\n 0000");fflush(stdout);
		
	iDay = atoi(Date1);
	iYear = atoi(Year1);
	
	printf("\n 1111");fflush(stdout);
	
	if(strcmp(Month1,"Jan")==0)
	{		
		iMonth=1;
	}
	else if(strcmp(Month1,"Feb")==0)
	{
		iMonth=2;
	}
	else if(strcmp(Month1,"Mar")==0)
	{
		iMonth=3;
	}
	else if(strcmp(Month1,"Apr")==0)
	{
		iMonth=4;
	}
	else if(strcmp(Month1,"May")==0)
	{
		iMonth=5;
	}
	else if(strcmp(Month1,"Jun")==0)
	{
		iMonth=6;
	}
	else if(strcmp(Month1,"Jul")==0)
	{
		iMonth=7;
	}
	else if(strcmp(Month1,"Aug")==0)
	{
		iMonth=8;
	}
	else if(strcmp(Month1,"Sep")==0)
	{
		iMonth=9;
	}
	else if(strcmp(Month1,"Oct")==0)
	{
		iMonth=10;
	}
	else if(strcmp(Month1,"Nov")==0)
	{
		iMonth=11;
	}
	else if(strcmp(Month1,"Dec")==0)
	{
		iMonth=12;
	}
	else
	{
		printf("\n No match found for Month1 !!!");fflush(stdout);
	}
	

	printf("\nYear is:%d, Month:%d, Date is:%d",iYear,iMonth,iDay); fflush(stdout);
	
	
    return (iDay + (153 * (iMonth + 12 * ((14 - iMonth) / 12) - 3) + 2) / 5 + 365 *
        (iYear + 4800 - ((14 - iMonth) / 12)) + (iYear + 4800 - ((14 - iMonth) / 12)) / 4 - 32083);
	
	printf("\n Hii... returned from function CalcDays ");fflush(stdout);
}

 int get_users_task_to_perform_folder(char *user_name, tag_t *task_to_perform_folder)
{
    int ifail = ITK_ok;
    tag_t type_tag = NULLTAG;
    ifail = TCTYPE_find_type("TasksToPerform", NULL, &type_tag);
    if (ifail != ITK_ok)
    {
        return ifail;
    }

    char *display_name = NULL;
    ifail = TCTYPE_ask_display_name(type_tag, &display_name);
    if (ifail != ITK_ok)
    {
        return ifail;
    }

    tag_t query = NULLTAG;
    ifail = QRY_find("General...", &query);
    if (ifail != ITK_ok)
    {
        return ifail;
    }

    // Find user's "Tasks to Perform" folder
    char *entries[2] = {"Owning User", "Type"};
    char *values[2] =  {user_name, display_name};
    int n_folder = 0;
    tag_t *folder = NULLTAG;
    ifail = QRY_execute(query, 2, entries, values, &n_folder, &folder);
	printf("\n n_folder found : %d\n",n_folder);fflush(stdout);
    if (ifail != ITK_ok)
    {
        return ifail;
    }
    
    if(n_folder == 0)
   {
        *task_to_perform_folder = NULLTAG;
        return ifail;
    }
	/* if(n_folder == 1)
		{
	  *task_to_perform_folder = folder[0];
		}
	 else
		{
		 *task_to_perform_folder = folder[0];
		}*/
		*task_to_perform_folder = folder[0];
        MEM_free(folder); 
		

    return ifail;
}

extern int ITK_user_main(int argc,char* argv[])
{
	int z;
	int status;
	char *Filename			= NULL;
	char*     FileDown     = NULL;
	FileDown = (char *) MEM_alloc (sizeof (char) * 128);
	Filename = (char *) MEM_alloc( 50 * sizeof(char) );
	FILE	*  fd;
	//char *inputline = NULL;
	char	*item_id		= NULL;
	char	*value		= NULL;
	char	*rev_id		= NULL;
	char*	  startDate      			= NULL;
	char*	  startDateDup		= NULL;
	char			pAccessDate[20];
	char			cCurrentAccessDate[50]={0};
	char *			pAccessDateDup 		= NULL;
	int 		diffDate 			= 	0;
	char*			fprint		= NULL;
	char			*d_date						= NULL;				
	//char   cCurrentAccessDate2[20]={0}; 
	char        *TaskId          = NULL;
	char        *ProjectCode  	= NULL;
	char        *DMLDRstat       = NULL;
	char        *ERCDate           =NULL;
	char        *Planner_AssignDate = NULL;
	char        *AgeOfDML            = NULL;
	char        *Planner_Name        = NULL;
	//char        *Lifecycle_state       = NULL;
	char        *Assignment            = NULL;
	char        *DMLDescription		= NULL;
	char        *DMLDescriptionDup    = NULL;
	char        *Status                    =NULL;
	char			*Lifecycle_state	= NULL;

	char*			APL_Plnr_Grp		= NULL;
	char*			PLT_CodeS		= NULL;
	//char*			rolename			= NULL;
	//char*			user_name				= NULL;
	char			rolename[SA_name_size_c+1];
	char				user_name[SA_user_size_c+1];
	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	//tag_t			relation			= NULLTAG;
	tag_t*			role_tags		= NULLTAG;
	tag_t*			member_tags= NULLTAG;
	tag_t*       Planner_Task      = NULLTAG;
	tag_t        query4           = NULLTAG;
	char       *user_id     = NULL;
	tag_t*      task_to_perform_folder   = NULLTAG;
	//tag_t*   task_to_perform_reviewer = NULLTAG;
	tag_t *APLTask = NULLTAG;
	int				count		= 0;
	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	int				n					= 0;
	int				n_found4      =0;
	int		 totalPlanner  =0;
	int		 totalReviewer  =0;
	int		 total  =0;
	int TotalTaskcount = 0;
	int n_tasks = 0;

	char*			SetStrPlanner			= NULL;
	char*			Report_Date			= NULL;
	date_t			Current_Date			= NULLDATE;
	char			Date_Format	[100]		= " ";
	char        *Reviewer_Name        = NULL;

	logical		flgRoleFnd			= false;

	int		ds_tags_found			=	0;
	int		n_entries				=	1;
	int		itask					=	0;
	int		task_count				=	0;
	int		iERCCnt					=	0;
	int		iAPLCnt					=	0;
	int		iAPLWCnt				=	0;
	int		iSTDCnt					=	0;
	int		isec					=	0;
	int     st_count1				=	0;
	int     st_counte				=	0;
	int		iLCS					=	0;
	int		ds_tags_foundAPL		=	0;

	char	*OwnUser				=	NULL;
	char	*cUserName				=	NULL;
	char	*cPassWord				=	NULL;
	char	*cUserGrp				=	NULL;

	char	*cProjectcode			=	NULL;
	char	*aplDML					=	NULL;
	char	*Type					=	NULL;
	char	*aplType				=	NULL;
	char	*WSO_Name				=	NULL;
	char	*prjCode				=	NULL;
	char	*ercDML					=	NULL;
	char	*ercRlzDate				=	NULL;//07-Jun-2019 16:56
	//char	*qry_entriesds[2]		=	{"Name","Date Released"};
	char	*qry_entriesds[1]		=	{"Name"};
	char	**qry_valuesds = (char **) MEM_alloc(50 * sizeof(char *));

	char	*qry_entriesdsAPL[1]		=	{"ID"};
	char	**qry_valuesdsAPL = (char **) MEM_alloc(50 * sizeof(char *));
	//char	*Date_Format			=	NULL;

	tag_t	queryds					=	NULLTAG;
	tag_t	querydsAPL				=	NULLTAG;
	tag_t	*itemrevdsclass			=	NULLTAG;
	tag_t	*itemrevdsclassAPL		=	NULLTAG;
	tag_t	*task_tag				=	NULLTAG;
	tag_t	erctask					=	NULLTAG;
	tag_t	apltaskrev				=	NULLTAG;
	tag_t	relation				=	NULLTAG;
	tag_t	*status_list1			=	NULLTAG;
	tag_t	*status_liste			=	NULLTAG;
	tag_t	APLobjTypeTag			=	NULLTAG;
	tag_t	objTypeTag				=	NULLTAG;

	size_t	prtTaskLen	=	0;

	cUserName		=	ITK_ask_cli_argument("-UN=");
	cPassWord		=	ITK_ask_cli_argument("-UP=");
	cUserGrp		=	ITK_ask_cli_argument("-UG=");

	//inputfile = ITK_ask_cli_argument("-i=");
	ITK_CALL(ITK_set_journalling( TRUE ));
	ITK_CALL(ITK_initialize_text_services (ITK_BATCH_TEXT_MODE));
	printf("\n\n\t Attempting Logging\n ");fflush(stdout);

	z=ITK_CALL(ITK_auto_login());
	//ITK_CALL(ITK_init_module(cUserName,cPassWord,cUserGrp));

	//CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	//ITK_CALL(ITK_auto_login( ));
	//CALLAPI(ITK_init_module(cUserName,cPassWord,cUserGrp));
	//CALLAPI(ITK_set_journalling( TRUE ));
	if(z!=ITK_ok)
	{
		printf("\n\n\t OMG Login Not Successfull\n ");fflush(stdout);
	}
	else
	{
		printf("\n\n\t Login Successfull\n ");fflush(stdout);
	}
	getCurrentDateTime(cCurrentAccessDate);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//STRNG_replace_str(cCurrentAccessDate,'-','_',Current_Date);
	//strrpl(Current_Date,' ','_');
	//strrpl(Current_Date,':','_');
	//Current_Date =(char *) MEM_alloc(200 * sizeof(char *));
	//strcpy(Current_Date,"");
	//tc_strcat(Current_Date,cCurrentAccessDate);
	//tc_strcat(Current_Date,'_');

	printf("\n  todays date111 is: %s\n",cCurrentAccessDate);fflush(stdout);

	/*Report_Date =(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(Report_Date,"");
	tc_strcpy(Report_Date,cCurrentAccessDate);*/

	//ITK_string_to_date(Report_Date, &Current_Date);

	time_t now; 
	struct tm when; 

	time(&now); 
	when = *localtime(&now); 

	strftime(Date_Format, 100, "%d_%b_%Y_%H_%M", &when);
	sprintf(FileDown, "/tmp/Groupwise_APL_Pending_DML_Report_%s.xls", Date_Format);


	//tc_strcpy(FileDown,"D:\\TCUA_10.1.7\\");//2tier
	//tc_strcpy(FileDown,"//home//cmitest//Priya//");//cmitest
	/*tc_strcpy(FileDown,"//user//uaprod//Priya//DMLpendingstatus//");//UAPROD
	//tc_strcat(FileDown,Filename);
	//tc_strcat(FileDown,dmlNumber);
	tc_strcat(FileDown,"Groupwise_APL_Pending_DML_Report_");
	tc_strcat(FileDown,Date_Format);
	tc_strcat(FileDown,".xls");
	TC_write_syslog("Main File = %s\n",FileDown);
	printf("\n FileDown: %s\n", FileDown);fflush(stdout);
	*/

	fd=fopen(FileDown,"w");
	if(fd==NULL)
	{
		printf("\nError in opening the file \n");fflush(stdout);
	}

	//tc_strcat(Report_Date,"Groupwise_APL_Pending_DML_Report");
	//tc_strcat(Report_Date,cCurrentAccessDate);
	//printf("\n  Report Date is : %s\n",Report_Date);fflush(stdout);

	fprintf(fd,"					Groupwise_APL_Pending_DML_Report          ");fflush(fd);
	//fprintf(fd,"                                                %s", Report_Date);fflush(fd);
	fprintf(fd,"\n                                       Report_Date: %s ", Date_Format);fflush(fd);
	//fprintf(fd,"\n                                 --------------------------------------------------------------------------------                            ");fflush(fd);
	fprintf(fd,"\n      -------------------------------------------------------------------------------------------------------------------------------------------------------- ");fflush(fd);
	//DML Summary Added Starts
	ITK_CALL(QRY_find("ERCDMLReleased_DateWise", &queryds));
	if (queryds!=NULLTAG)
	{
		printf("Query Found...!!!");fflush(stdout);
		qry_valuesds[0] = "T5_LcsErcRlzd";
		//qry_valuesds[1] = "";
		//qry_valuesds[2] = "";
		//qry_valuesds[3] = "";

		ITK_CALL(QRY_execute(queryds, n_entries, qry_entriesds, qry_valuesds, &ds_tags_found, &itemrevdsclass));
	}
	else
	{
		printf("Query not Found...!!!");fflush(stdout);
	}

	if(ds_tags_found>0)
	{
		printf("\nNo of DML Found : %d",ds_tags_found);fflush(stdout);

		for(itask=0;itask <ds_tags_found;itask++)
		{
			erctask	=	NULLTAG;
			erctask	=	itemrevdsclass[itask];

			Type	=	NULL;
			//CALLAPI(AOM_ask_value_string(erctask, "object_type", &Type));
			ITK_CALL(TCTYPE_ask_object_type(erctask,&objTypeTag));
			ITK_CALL(TCTYPE_ask_name2(objTypeTag,&Type));
			//printf("\n Type : %s",Type);fflush(stdout);
			
			prjCode	=	NULL;
			ITK_CALL(AOM_ask_value_string(erctask, "t5_cprojectcode", &prjCode));  
			//printf("\n prjCode : %s",prjCode);fflush(stdout);//owning_user
			
			OwnUser	=	NULL;
			ITK_CALL(AOM_UIF_ask_value(erctask, "owning_user", &OwnUser));  
			//printf("\n OwnUser : %s",OwnUser);fflush(stdout);
			
			ITK_CALL(AOM_ask_value_string(erctask, "item_id", &ercDML));
			
			//t5_cprojectcode
			if (tc_strcmp(Type,"ChangeRequestRevision")==0 && tc_strcmp(prjCode,"5445")==0)
			{
				//iERCCnt++;
				ITK_CALL(WSOM_ask_release_status_list(erctask,&st_counte,&status_liste));
				//printf("\nERC DML : %s, st_count1 : %d",ercDML,st_counte);fflush(stdout);
				if(st_counte == 0)
				{
					continue;
				}
				else
				{
					for (iLCS=0;iLCS<st_counte ;iLCS++ )
					{
						WSO_Name	=	NULL;
						ITK_CALL(AOM_ask_name(status_liste[iLCS],&WSO_Name));
						//printf("\n WSO_Name ERC: %s",WSO_Name);fflush(stdout);
						if (tc_strcmp(WSO_Name,"T5_LcsErcRlzd")==0)
						{
							printf("\nERC DML : %s",ercDML);fflush(stdout);
							iERCCnt++;
							break;
						}//T5_LcsStdRlzd, T5_LcsAPLWrkg
					}
				}
				
			}
			
		}

		//Found APL DML with APL DML Query
		printf("APL DML Start...!!!");fflush(stdout);
		ITK_CALL(QRY_find("APLDMLRevisionQry", &querydsAPL));
		if (querydsAPL!=NULLTAG)
		{
			qry_valuesdsAPL[0] = "*";
			ITK_CALL(QRY_execute(querydsAPL, n_entries, qry_entriesdsAPL, qry_valuesdsAPL, &ds_tags_foundAPL, &itemrevdsclassAPL));
			if(ds_tags_foundAPL>0)
			{
				for(itask=0;itask <ds_tags_foundAPL;itask++)
				{
					aplType		=	NULL;
					apltaskrev	=	NULLTAG;
					apltaskrev	=	itemrevdsclassAPL[itask];
					//prjCode		=	NULL;

					aplType	=	NULL;
					//CALLAPI(AOM_ask_value_string(apltaskrev, "object_type", &aplType));
					ITK_CALL(TCTYPE_ask_object_type(apltaskrev,&APLobjTypeTag));
					ITK_CALL(TCTYPE_ask_name2(APLobjTypeTag,&aplType));
					//printf("\n Type : %s",aplType);fflush(stdout);
					
					prjCode	=	NULL;
					ITK_CALL(AOM_ask_value_string(apltaskrev, "t5_cprojectcode", &prjCode));  
					//printf("\n prjCode : %s",prjCode);fflush(stdout);//owning_user
					
					OwnUser	=	NULL;
					ITK_CALL(AOM_UIF_ask_value(apltaskrev, "owning_user", &OwnUser));  
					//printf("\n OwnUser : %s",OwnUser);fflush(stdout);

					if (tc_strcmp(aplType,"T5_APLDMLRevision")==0 && tc_strcmp(prjCode,"5445")==0)
					{
						ITK_CALL(AOM_ask_value_string(apltaskrev, "item_id", &aplDML));
						
						prtTaskLen	=	tc_strlen(aplDML);
						if (prtTaskLen<15)
						{
							continue;
						}
						if (tc_strstr(aplDML,"AM")!=NULL)
						{
							continue;
						}
						if (tc_strcmp(aplDML,"10PP555444_APLC")==0 || tc_strcmp(aplDML,"16PP251622_APLC")==0)
						{
							continue;
						}
						iAPLWCnt++;
						printf("\n APL DML : %s",aplDML);fflush(stdout);
						ITK_CALL(WSOM_ask_release_status_list(apltaskrev,&st_count1,&status_list1));
						//printf("\n APL DML : %s, st_count1 : %d",aplDML,st_count1);fflush(stdout);
						if(st_count1 == 0)
						{
							continue;
						}
						else
						{
							for (iLCS=0;iLCS<st_count1 ;iLCS++ )
							{
								WSO_Name	=	NULL;
								ITK_CALL(AOM_ask_name(status_list1[iLCS],&WSO_Name));
								//printf("\n WSO_Name : %s",WSO_Name);fflush(stdout);
								//if (tc_strcmp(WSO_Name,"T5_LcsAPLWrkg")==0)
								//{
								//	iAPLWCnt++;
								//}
								if (tc_strcmp(WSO_Name,"T5_LcsAplRlzd")==0)
								{
									iAPLCnt++;
								}//T5_LcsStdRlzd, T5_LcsAPLWrkg
								if (tc_strcmp(WSO_Name,"T5_LcsStdRlzd")==0)
								{
									iSTDCnt++;
								}
							}
						}
					}
				}
			}
		}
		else
		{
			printf("APL Query not Found...!!!");fflush(stdout);
		}
		printf("\nNo of APL DML Found : %d",ds_tags_foundAPL);fflush(stdout);
		printf("\n iERCCnt : %d, iAPLCnt : %d",iERCCnt,iAPLCnt);fflush(stdout);

		if (iERCCnt>0)
		{
			fprintf(fd,"\n                                             -------DML Summary Report---------                                                                    ");fflush(fd);
			fprintf(fd,"\n      -------------------------------------------------------------------------------------------------------------------------------------------------------- ");fflush(fd);
			fprintf(fd,"\n\t\tDML Released BY ERC : \t %d",(iERCCnt+49));fflush(fd);
			fprintf(fd,"\n\t\tDML Reached TO APL : \t %d",iAPLWCnt);fflush(fd);
			fprintf(fd,"\n\t\tDML Released BY APL : \t %d",iAPLCnt);fflush(fd);
			fprintf(fd,"\n\t\tDML Released BY STDSI : \t %d",iSTDCnt);fflush(fd);
			fprintf(fd,"\n\t\t");fflush(fd);
			fprintf(fd,"\n\t\t");fflush(fd);
			fprintf(fd,"\n\t\tNote** : 50 ERC DMLs were released in TCE, Not migrated in TCUA.");fflush(fd);
			fprintf(fd,"\n\t\t");fflush(fd);
		}
	}
	//DML Summary Added Ends
	//fprintf(fd,"\n                                             ----------------------------------------------------                                                                    ");fflush(fd);
	fprintf(fd,"\n      -------------------------------------------------------------------------------------------------------------------------------------------------------- ");fflush(fd);
	fprintf(fd,"\n                                             -------Planner wise Task Report---------                                                                    ");fflush(fd);
	//fprintf(fd,"\n\n\n                                             Summary(Plannerwise)                                                                                        ");fflush(fd);
	fprintf(fd,"\n      -------------------------------------------------------------------------------------------------------------------------------------------------------- ");fflush(fd);
	//fprintf(fd,"\n                                             ----------------------------------------------------                                                                    ");fflush(fd);

	SetStrPlanner =(char *) MEM_alloc(200 * sizeof(char *));
	strcpy(SetStrPlanner,"");

	APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(APL_Plnr_Grp,"APLCAR");
	//tc_strcat(APL_Plnr_Grp,PLT_CodeS);
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);
	//To find planner group
	ITK_CALL(SA_find_group(APL_Plnr_Grp,&group_tag));
	if (group_tag != NULLTAG)
	//To find planner role
	ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
	flgRoleFnd=false;


	if(num_of_roles>0)
	{
		n=0;
		for (n=0;n<num_of_roles ;n++ )
		{
			tag_t       *role_name     = NULLTAG;
			ITK_CALL(SA_ask_role_name(role_tags[n],rolename));
			printf("\nRol Name :[%d][%s]\n",n,rolename);fflush(stdout);
			//To find planner from role
			if(tc_strstr(rolename,"_APLC_Planner")!=NULL)
			{
				num_of_members=0;
				member_tags=NULLTAG;
				ITK_CALL(SA_find_groupmember_by_role(role_tags[n],group_tag,&num_of_members,&member_tags));
				printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				if(num_of_members>0)
				{
					j=0;
					for (j=0;j<num_of_members ;j++  )
					{
						user_tag=NULLTAG;
						ITK_CALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
						ITK_CALL(SA_ask_user_identifier(user_tag,user_name));

						if(strstr(user_name,"aplplanner"))
						{
							continue;
						}

						if (tc_strcmp(user_id,"NULL")==0) MEM_free(user_id);
						user_id = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(user_id,"");
						tc_strcat(user_id,"*");
						tc_strcat(user_id,user_name);
						tc_strcat(user_id,"*");					
						printf("\nUser ID Name :[%s]\n",user_id);fflush(stdout);
						//To find planner oly APLC_Planner
						if(tc_strstr(SetStrPlanner,user_name)==NULL)
						{
							strcat(SetStrPlanner,user_name);
							strcat(SetStrPlanner,",");

							tag_t task_to_perform_folder = NULLTAG;
							get_users_task_to_perform_folder(user_id, &task_to_perform_folder);  

							n_tasks=0;
							APLTask=NULLTAG;
							if(task_to_perform_folder!=NULLTAG)

							{
								ITK_CALL(AOM_ask_value_tags(task_to_perform_folder, "contents", &n_tasks, &APLTask));  
							}
							TotalTaskcount=0;
							//printf("n_tasks found :%d\n");fflush(stdout);
							printf("\n n_tasks found are :%d\n",n_tasks);fflush(stdout);

							i=0;
							for (i=0;i<n_tasks;i++ )
							{
								printf("\n\n inside for..[%d]", i );fflush(stdout);	

								tag_t workjob_tag = NULLTAG;
								char 		*assgnname		= 	NULL;
								workjob_tag = APLTask[i];	
								ITK_CALL(AOM_UIF_ask_value(workjob_tag,"object_name",&assgnname));					

								if (tc_strcmp(assgnname,"Work On DML")==0)
								{
									printf("\n assgnname is :%s\n",assgnname); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(APLTask[i],"fnd0Assignee",&Planner_Name));
									printf("\n Planner_Name1.......\n");fflush(stdout);


									TotalTaskcount++;
									printf("\n  TotalTaskcount: %d\n", TotalTaskcount);fflush(stdout);
								}
							}

							printf("*************** TotalTaskcount=%d\n",TotalTaskcount);
							if(TotalTaskcount>0)
							{
								fprintf(fd,"\n                                                      %s          %d  " ,Planner_Name,TotalTaskcount);fflush(fd);
								totalPlanner=totalPlanner+TotalTaskcount;
							}
							else
							{
								//commented for testing, if count is 0, then not display
								//fprintf(fd,"\n                                                      %s          %d  " ,Planner_Name,TotalTaskcount);fflush(fd);
								//totalPlanner=totalPlanner+TotalTaskcount;
							}


						} // ens of if(tc_strstr(SetStrPlanner,user_name)==NULL)

					} // for (j=0;j<num_of_members ;j++  )
				}//if(num_of_members>0)
			}//if(tc_strstr(rolename,"_APLC_Planner")!=NULL)
		}// for (n=0;n<num_of_roles ;n++ )
	}//if(num_of_roles>0)



	//code for summary count of Review the changes 
	fprintf(fd,"\n\n\n      -------------------------------------------------------------------------------------------------------------------------------------------------------- ");fflush(fd);
	fprintf(fd,"\n                                             -------Reviewer wise Task Report---------                                                                    ");fflush(fd);
	fprintf(fd,"\n      -------------------------------------------------------------------------------------------------------------------------------------------------------- ");fflush(fd);
	//fprintf(fd,"\n\n\n                                             Summary(Reviewerwise)                                                                                        ");fflush(fd);
	//fprintf(fd,"\n                                             ----------------------------------------------------                                                                 ");fflush(fd);
	char *SetStrReviewer  =NULL;
	SetStrReviewer =(char *) MEM_alloc(200 * sizeof(char *));
	strcpy(SetStrReviewer,"");

	if(num_of_roles>0)
	{
		n=0;
		for (n=0;n<num_of_roles ;n++ )
		{
			tag_t       *role_name     = NULLTAG;
			ITK_CALL(SA_ask_role_name(role_tags[n],rolename));
			printf("\nRol Name :[%d][%s]\n",n,rolename);fflush(stdout);
			//To find planner from role
			if(tc_strstr(rolename,"_APLC_Reviewer")!=NULL)
			{
				num_of_members=0;
				member_tags=NULLTAG;
				ITK_CALL(SA_find_groupmember_by_role(role_tags[n],group_tag,&num_of_members,&member_tags));
				printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
				if(num_of_members>0)
				{
					j=0;
					for (j=0;j<num_of_members ;j++  )
					{
						user_tag=NULLTAG;
						ITK_CALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
						ITK_CALL(SA_ask_user_identifier(user_tag,user_name));

						if(strstr(user_name,"aplreviewer"))
						{
							continue;
						}

						if (tc_strcmp(user_id,"NULL")==0) MEM_free(user_id);
						user_id = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(user_id,"");
						tc_strcat(user_id,"*");
						tc_strcat(user_id,user_name);
						tc_strcat(user_id,"*");					
						printf("\nUser ID Name :[%s]\n",user_id);fflush(stdout);
						//To find planner only APLC_Reviewer
						if(tc_strstr(SetStrReviewer,user_name)==NULL)
						{
							printf("\nSetStrReviewer \n");fflush(stdout);
							strcat(SetStrReviewer,user_name);
							strcat(SetStrReviewer,",");
							printf("\nSetStrReviewer1111 \n");fflush(stdout);

							tag_t task_to_perform_folder = NULLTAG;
							get_users_task_to_perform_folder(user_id, &task_to_perform_folder);  
							printf("\nSetStrReviewer222 \n");fflush(stdout);

							n_tasks=0;
							APLTask=NULLTAG;
							ITK_CALL(AOM_ask_value_tags(task_to_perform_folder, "contents", &n_tasks, &APLTask));  
							TotalTaskcount=0;
							//printf("n_tasks found :%d\n");fflush(stdout);
							printf("\n n_tasks found are :%d\n",n_tasks);fflush(stdout);

							i=0;
							for (i=0;i<n_tasks;i++ )
							{
								printf("\n\n inside for..[%d]", i );fflush(stdout);	

								tag_t workjob_tag = NULLTAG;
								char 		*assgnname		= 	NULL;
								workjob_tag = APLTask[i];	
								ITK_CALL(AOM_UIF_ask_value(workjob_tag,"object_name",&assgnname));					

								if (tc_strcmp(assgnname,"Review The Changes Done By APL Planner")==0)
								{
									printf("\n assgnname is :%s\n",assgnname); fflush(stdout);

									TotalTaskcount++;
								printf("\n  TotalTaskcount: %d\n", TotalTaskcount);fflush(stdout);
								}
							}

							printf("*************** TotalTaskcount=%d\n",TotalTaskcount);
							if(TotalTaskcount>0)
							{
								fprintf(fd,"\n                                                      %s         %d  \n" ,user_name,TotalTaskcount);fflush(fd);

							}
							else
							{
								fprintf(fd,"\n                                                      %s        %d  \n" ,user_name,TotalTaskcount);fflush(fd);

							}


						} // ens of if(tc_strstr(SetStrPlanner,user_name)==NULL)

					} // for (j=0;j<num_of_members ;j++  )
				}//if(num_of_members>0)
			}//if(tc_strstr(rolename,"_APLC_Planner")!=NULL)
		}// for (n=0;n<num_of_roles ;n++ )
	}//if(num_of_roles>0)
	totalReviewer=totalReviewer+TotalTaskcount;
	fprintf(fd,"\n                                         Task Summary Report                                                                                   ");fflush(fd);
	fprintf(fd,"\n                                         -----------------------------------------------------------------                                                                ");fflush(fd);
	fprintf(fd,"\n                                            DML Pending With Planner= %d ",totalPlanner);fflush(fd);
	fprintf(fd,"\n                                            DML Pending With Reviewer= %d ",totalReviewer);fflush(fd);
	total=totalPlanner+totalReviewer;
	fprintf(fd,"\n                                            Total Number of pending DMLs %d ",total);fflush(fd);
	fprintf(fd,"\n                                         -----------------------------------------------------------------------\n\n                                                ");fflush(fd);


	//to print all APL task data for Planner
	char *SetStrPlanner1  =NULL;
	int           Srno              =0;
	int  FlagPlannerNamePrint =0;

	SetStrPlanner1 =(char *) MEM_alloc(200 * sizeof(char *));
	strcpy(SetStrPlanner1,"");

	fprintf(fd,"\n===========================================================DML PENDING WITH PLANNER============================================================================== ");fflush(fd);
	if(num_of_roles>0)
	{
		n=0;
		for (n=0;n<num_of_roles ;n++ )
		{
			ITK_CALL(SA_ask_role_name(role_tags[n],rolename));
			printf("\nRol Name1 :[%d][%s]\n",n,rolename);fflush(stdout);
			//To find planner from role
			if(tc_strstr(rolename,"_APLC_Planner")!=NULL)
			{
				num_of_members=0;
				member_tags=NULLTAG;
				ITK_CALL(SA_find_groupmember_by_role(role_tags[n],group_tag,&num_of_members,&member_tags));
				printf("\nNo of Group Members found in Group/Role are1 :%d\n",num_of_members);fflush(stdout);
				if(num_of_members>0)
				{
					j=0;
					for (j=0;j<num_of_members ;j++  )
					{
						FlagPlannerNamePrint=0;
						user_tag=NULLTAG;
						ITK_CALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
						ITK_CALL(SA_ask_user_identifier(user_tag,user_name));

						if(strstr(user_name,"aplplanner"))
						{
							continue;
						}

						if (tc_strcmp(user_id,"NULL")==0) MEM_free(user_id);
						user_id = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(user_id,"");
						tc_strcat(user_id,"*");
						tc_strcat(user_id,user_name);
						tc_strcat(user_id,"*");					
						printf("\nUser ID Name1 :[%s]\n",user_id);fflush(stdout);

						if(tc_strstr(SetStrPlanner1,user_name)==NULL)
						{
							printf("\nSetStrPlanner1 \n");fflush(stdout);
							strcat(SetStrPlanner1,user_name);
							strcat(SetStrPlanner1,",");


							//fprintf(fd,"\n    Planner_Name 	  :%s ", user_name);	 	fflush(fd); 
							//fprintf(fd,"\n ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(fd);
							//fprintf(fd,"\n %s\t  %s\t    %s\t  %s\t   %s\t  %s\t  %s\t  %s\t  %s\t  %s\t %s\t %s\t  ","Srno","TaskId","ProjectCode","ERCDate","Planner_AssignDate","AgeOfDML","Status","Planner_Name","DMLDRstat","Lifecycle_state","Assignment","DMLDescription");fflush(fd);
							//fprintf(fd,"\n ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(fd);


							tag_t task_to_perform_folder = NULLTAG;
							get_users_task_to_perform_folder(user_id, &task_to_perform_folder);  

							n_tasks=0;
							APLTask=NULLTAG;
							ITK_CALL(AOM_ask_value_tags(task_to_perform_folder, "contents", &n_tasks, &APLTask));  
							TotalTaskcount=0;
							Srno=0;
							//printf("n_tasks found :%d\n");fflush(stdout);
							printf("\n n_tasks found are1 :%d\n",n_tasks);fflush(stdout);

							i=0;
							for (i=0;i<n_tasks;i++ )
							{
								printf("\n\n inside for1..[%d]", i );fflush(stdout);	

								tag_t workjob_tag = NULLTAG;
								char 		*assgnname		= 	NULL;
								char        *APLDML				=NULL;
								char        *Release_state       =NULL;
								char        *Remarks                = NULL;	
								char   type_name[TCTYPE_name_size_c+1];
								tag_t relatnType_tag      = NULLTAG;
								tag_t *task_obj_tag       = NULLTAG;
								tag_t  task_rev_tag        = NULLTAG;
								tag_t	*attachments			=NULLTAG;
								tag_t DMLTag = NULLTAG;
								tag_t		objTypeTag = NULLTAG;
								tag_t	relation_type 	= NULLTAG;
								tag_t*			TaskRevision		= NULLTAG;
								tag_t TaskRevTag  =NULLTAG;

								char Task_ID[5]={'\0'};
								//char Lifecycle_state[10]={'\0'};
								char  *Task_ID_tokenized	=NULL;
								char  *Lifecycle_state_tokenized 	=NULL;
								char		   *DsgNO =NULL;
								char         *PltNm   =NULL;
								char         *PltNm1   =NULL;
								char          *APLDMLNo=NULL;
								char          *APLDMLTask=NULL;
								char          *ERCDML =NULL;

								int            n_found1        = 0;
								int            n_found2        = 0;
								int            n_found3        = 0;
								int            n_found4        = 0;
								//int           n_tasksFnd     = 0;
								int            n       = 0;
								int				stlst				= 0;
								int   task_count				= 0;
								tag_t        query2          = NULLTAG;
								tag_t        query1          = NULLTAG;
								tag_t        query3          = NULLTAG;
								tag_t        query4          = NULLTAG;
								tag_t       *APL_DML     = NULLTAG;
								tag_t       *APL_DML_Task   = NULLTAG;
								tag_t       *ERC_DML = NULLTAG;
								tag_t       *Planner_Task     = NULLTAG;
								tag_t       *task_status_list     = NULLTAG;

								workjob_tag = APLTask[i];
								ITK_CALL(AOM_UIF_ask_value(workjob_tag,"object_name",&assgnname));		

								//if(n_tasks>0)
								//{																	
								if (tc_strcmp(assgnname,"Work On DML")==0)
								{
									Srno++;
									printf("\n assgnname1 is :%s\n",assgnname); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(APLTask[i],"job_name",&APLDML));
									printf("\n APLDML : %s\n",APLDML );fflush(stdout);
									tc_strcpy(Task_ID,APLDML);
									printf("\n Task_ID : %s\n",Task_ID );fflush(stdout);

									//Finding APL DML
									Task_ID_tokenized=strtok(Task_ID,"_");
									printf("Tokenized DML Number Obtained=%s\n",Task_ID_tokenized);fflush(stdout);
									DsgNO=strtok(NULL,"_");
									printf("\n DsgNO : %s",DsgNO); fflush(stdout);
									//tc_strcat(Task_ID_tokenized,APLDMLNO);
									PltNm=strtok(NULL,"/");
									printf("\n PltNm : %s\n",PltNm); fflush(stdout);
									//PltNm1=strtok(PltNm,"/");

									if (tc_strcmp(APLDMLNo,"NULL")==0) MEM_free(APLDMLNo);
									APLDMLNo = (char *) MEM_alloc( 100 * sizeof(char) );

									tc_strcpy(APLDMLNo,"");
									tc_strcat(APLDMLNo,Task_ID_tokenized);
									tc_strcat(APLDMLNo,"_");
									tc_strcat(APLDMLNo,PltNm);
									printf("\n APLDMLNo : %s\n",APLDMLNo); fflush(stdout);

									if (tc_strcmp(APLDMLTask,"NULL")==0) MEM_free(APLDMLTask);
									APLDMLTask = (char *) MEM_alloc( 100 * sizeof(char) );
									tc_strcpy(APLDMLTask,"");
									tc_strcat(APLDMLTask,Task_ID_tokenized);
									tc_strcat(APLDMLTask,"_");
									tc_strcat(APLDMLTask,DsgNO);
									tc_strcat(APLDMLTask,"_");
									tc_strcat(APLDMLTask,PltNm);
									printf("\n APLDMLTask : %s\n",APLDMLTask); fflush(stdout);

									if (tc_strcmp(ERCDML,"NULL")==0) MEM_free(ERCDML);
									ERCDML = (char *) MEM_alloc( 100 * sizeof(char) );
									tc_strcpy(ERCDML,"");
									tc_strcat(ERCDML,Task_ID_tokenized);
									printf("\n ERCDML : %s\n",ERCDML); fflush(stdout);

									//Using Query Builder to get APL DML Revision.....
									char
									*qry_entries1[] = {"Item ID","Type"},
									*qry_values1[] = {APLDMLNo,"APL DML Revision"};


									ITK_CALL(QRY_find("Item Revision...", &query1));
									printf("APL DML No.....\n");fflush(stdout);
									ITK_CALL(QRY_execute(query1, 1, qry_entries1, qry_values1, &n_found1, &APL_DML));
									printf("APL DML No. found rows.....\n");fflush(stdout);
									if(n_found1!=0)
									//for (j=0;j<n_found1;j++ )
									{
										printf("Found an APL DML Rev....\n");fflush(stdout);
										//ITK_CALL(AOM_ask_value_string(APL_DML[0],"item_id", &TaskId));
										//printf("\n TaskId : %s\n", TaskId);fflush(stdout);
										ITK_CALL(AOM_ask_value_string( APL_DML[0], "t5_cprojectcode", &ProjectCode));
										printf("\n ProjectCode : %s\n",ProjectCode);fflush(stdout);
										ITK_CALL(AOM_ask_value_string(APL_DML[0],"t5_cDRstatus",&DMLDRstat));
										printf("\n DMLDRstat : %s\n",DMLDRstat);fflush(stdout);
										DMLDescription	=	NULL;
										DMLDescriptionDup	=	NULL;
										//ITK_CALL(AOM_ask_value_string(APL_DML[0],"object_name",&DMLDescription));
										ITK_CALL(AOM_ask_value_string(APL_DML[0],"current_name",&DMLDescription));
										STRNG_replace_str(DMLDescription,"\n","",&DMLDescriptionDup);
										STRNG_replace_str(DMLDescription,"\n ","",&DMLDescriptionDup);
										STRNG_replace_str(DMLDescription,"\t ","",&DMLDescriptionDup);
										printf("\n DMLDescription : %s\n",DMLDescription);fflush(stdout);
										printf("\n DMLDescriptionDup : %s\n",DMLDescriptionDup);fflush(stdout);
									}

									char
									*qry_entries2[] = {"Item ID","Type"},
									*qry_values2[] = {APLDMLTask,"APL Task Revision"};

									ITK_CALL(QRY_find("Item Revision...", &query2));
									printf("APL DML Task.....\n");fflush(stdout);
									ITK_CALL(QRY_execute(query2, 1, qry_entries2, qry_values2, &n_found2, &APL_DML_Task));
									printf("APL DML Task found rows.....\n");fflush(stdout);
									if(n_found2!=0)
									//for (j=0;j<n_found1;j++ )
									{
										printf("Found an APL DML Rev....\n");fflush(stdout);
										ITK_CALL(AOM_ask_value_string(APL_DML_Task[0],"item_id", &TaskId));
										printf("\n TaskId : %s\n", TaskId);fflush(stdout);
										ITKCALL(WSOM_ask_release_status_list(APL_DML_Task[0],&task_count,&task_status_list));
										printf("\n task_count : %d\n", task_count);fflush(stdout);
										//if(task_count>0)
										for (stlst = 0; stlst < task_count; stlst++)
										{

											//ITK_CALL(AOM_UIF_ask_value(task_status_list[stlst],"release_status_list",&Lifecycle_state));
											// printf("\n Lifecycle_state : %s\n", Lifecycle_state);fflush(stdout);
											ITK_CALL(AOM_ask_name(task_status_list[stlst], &Lifecycle_state));
											printf("\n Lifecycle_state %s \n",  Lifecycle_state);fflush(stdout);

										}
									}

									char
									*qry_entries3[] = {"Item ID","Type"},
									*qry_values3[] = {ERCDML,"ERC DML Revision"};


									ITK_CALL(QRY_find("Item Revision...", &query3));
									printf("ERC DML.....\n");fflush(stdout);
									ITK_CALL(QRY_execute(query3, 1, qry_entries3, qry_values3, &n_found3, &ERC_DML));
									printf("\n n_found3 : %d\n", n_found3);fflush(stdout);
									if(n_found3!=0)
									//for (j=0;j<n_found1;j++ )
									{
										ITK_CALL(AOM_UIF_ask_value(ERC_DML[0],"date_released",&ERCDate));
										printf("\n ERCDate : %s\n", ERCDate);fflush(stdout);
									}

									ITK_CALL(AOM_UIF_ask_value(APLTask[i],"fnd0StartDate",&Planner_AssignDate));
									printf("\n Planner_AssignDate1.......\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(APLTask[i],"task_state",&Status));
									printf("\n Status1.......\n");fflush(stdout);
									ITK_CALL(AOM_UIF_ask_value(APLTask[i],"fnd0Assignee",&Planner_Name));
									printf("\n Planner_Name1.......\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(APLTask[i],"object_name",&Assignment));
									printf("\n Assignment1.......\n");fflush(stdout);

									ITKCALL(AOM_UIF_ask_value(APLTask[i],"fnd0StartDate",&startDate));
									printf("\n startDate : %s\n",startDate);fflush(stdout);
									getCurrentDateTime(cCurrentAccessDate);
									printf("\n  todays date111 is: %s\n",cCurrentAccessDate);fflush(stdout);
									diffDate = (CalcDays(cCurrentAccessDate) - CalcDays(startDate));
									printf("\nDifference between Dates:%d",  diffDate);fflush(stdout);											


									printf("\n Planner_AssignDate: [%s]", Planner_AssignDate);fflush(stdout);
									printf("\n Status: [%s]", Status);fflush(stdout);
									printf("\n diffDate: [%d]", diffDate);fflush(stdout);
									printf("\n Planner_Name: [%s]", Planner_Name);fflush(stdout);
									printf("\n Assignment: [%s]", Assignment);fflush(stdout);


									printf("\n Test1.......\n");fflush(stdout);

									/*if (tc_strcmp(ERCDate,"NULL")!=0)
									{
									ERCDate="-";
									}*/

									if (tc_strcmp(Lifecycle_state,"NULL")==0)
									{
										Lifecycle_state="-";
									}
									if (tc_strcmp(Lifecycle_state,"T5_LcsAPLWrkg")==0)
									{
										Lifecycle_state="APL Working";
									}

									if(FlagPlannerNamePrint==0)
									{
										FlagPlannerNamePrint=1;
										fprintf(fd,"\n    Planner_Name 	  :%s ", user_name);	 	fflush(fd); 
										fprintf(fd,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(fd);
										fprintf(fd,"\n %s\t  %-10s\t    %-15s\t  %-10s\t   %-10s\t  %-10s\t  %-10s\t  %-10s\t  %-10s\t  %-10s\t %-10s\t %-10s\t  ","Srno","TaskId","DMLDescription","ProjectCode","ERCDate","Planner_AssignDate","AgeOfDML(days)","Status","Planner_Name","DMLDRstat","Lifecycle_state","Assignment");fflush(fd);
										fprintf(fd,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(fd);
									}

									fprintf(fd,"\n%d\t  %-10s\t   %-15s\t  %s\t  %s\t  %s\t  %d\t   %s\t  %s\t %s\t %s\t %s\t  ",Srno,TaskId,DMLDescriptionDup,ProjectCode,ERCDate,Planner_AssignDate,diffDate,Status,Planner_Name,DMLDRstat,Lifecycle_state,Assignment);fflush(fd);


								}//end of if (tc_strcmp(assgnname,"Work On DML")==0)
								//   }// end of if(n_tasks>0)
								}//end of for (i=0;i<n_tasks;i++ )

								if(FlagPlannerNamePrint==1)
								{     
									fprintf(fd,"\n============================================================================================================================================================\n");fflush(fd); 
								}
							} // ens of if(tc_strstr(SetStrPlanner1,user_name)==NULL)

					} // for (j=0;j<num_of_members ;j++  )
				}//if(num_of_members>0)
			}//if(tc_strstr(rolename,"_APLC_Planner")!=NULL)
		}// for (n=0;n<num_of_roles ;n++ )
	}//if(num_of_roles>0)


	//Print the data for Reviewer

	fprintf(fd,"\n=================================DML PENDING WITH REVIEWER===================================================================================== ");fflush(fd);
	char *SetStrReviewer1  =NULL;
	SetStrReviewer1 =(char *) MEM_alloc(200 * sizeof(char *));
	strcpy(SetStrReviewer1,"");
	if(num_of_roles>0)
	{
		n=0;
		for (n=0;n<num_of_roles ;n++ )
		{
			ITK_CALL(SA_ask_role_name(role_tags[n],rolename));
			printf("\nRol Name1 :[%d][%s]\n",n,rolename);fflush(stdout);
			//To find planner from role
			if(tc_strstr(rolename,"_APLC_Reviewer")!=NULL)
			{
				num_of_members=0;
				member_tags=NULLTAG;
				ITK_CALL(SA_find_groupmember_by_role(role_tags[n],group_tag,&num_of_members,&member_tags));
				printf("\nNo of Group Members found in Group/Role are1 :%d\n",num_of_members);fflush(stdout);
				if(num_of_members>0)
				{
					j=0;
					for (j=0;j<num_of_members ;j++  )
					{
						FlagPlannerNamePrint=0;
						user_tag=NULLTAG;
						ITK_CALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
						ITK_CALL(SA_ask_user_identifier(user_tag,user_name));

						if(strstr(user_name,"aplreviewer"))
						{
							continue;
						}

						if (tc_strcmp(user_id,"NULL")==0) MEM_free(user_id);
						user_id = (char *) MEM_alloc( 100 * sizeof(char) );
						tc_strcpy(user_id,"");
						tc_strcat(user_id,"*");
						tc_strcat(user_id,user_name);
						tc_strcat(user_id,"*");					
						printf("\nUser ID Name1 :[%s]\n",user_id);fflush(stdout);

						if(tc_strstr(SetStrReviewer1,user_name)==NULL)
						{
							//printf("\SetStrReviewer1 \n");fflush(stdout);
							strcat(SetStrReviewer1,user_name);
							strcat(SetStrReviewer1,",");


							//fprintf(fd,"\n    Planner_Name 	  :%s ", user_name);	 	fflush(fd); 
							//fprintf(fd,"\n ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(fd);
							//fprintf(fd,"\n %s\t  %s\t    %s\t  %s\t   %s\t  %s\t  %s\t  %s\t  %s\t  %s\t %s\t %s\t  ","Srno","TaskId","ProjectCode","ERCDate","Planner_AssignDate","AgeOfDML","Status","Planner_Name","DMLDRstat","Lifecycle_state","Assignment","DMLDescription");fflush(fd);
							//fprintf(fd,"\n ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(fd);


							tag_t task_to_perform_folder = NULLTAG;
							get_users_task_to_perform_folder(user_id, &task_to_perform_folder);  

							n_tasks=0;
							APLTask=NULLTAG;
							ITK_CALL(AOM_ask_value_tags(task_to_perform_folder, "contents", &n_tasks, &APLTask));  
							TotalTaskcount=0;
							Srno=0;
							//printf("n_tasks found :%d\n");fflush(stdout);
							printf("\n n_tasks found are1 :%d\n",n_tasks);fflush(stdout);

							i=0;
							for (i=0;i<n_tasks;i++ )
							{
								printf("\n\n inside for1..[%d]", i );fflush(stdout);	

								tag_t workjob_tag = NULLTAG;
								char 		*assgnname		= 	NULL;
								char        *APLDML				=NULL;
								char        *Release_state       =NULL;
								char        *Remarks                = NULL;	
								char   type_name[TCTYPE_name_size_c+1];
								tag_t relatnType_tag      = NULLTAG;
								tag_t *task_obj_tag       = NULLTAG;
								tag_t  task_rev_tag        = NULLTAG;
								tag_t	*attachments			=NULLTAG;
								tag_t DMLTag = NULLTAG;
								tag_t		objTypeTag = NULLTAG;
								tag_t	relation_type 	= NULLTAG;
								tag_t*			TaskRevision		= NULLTAG;
								tag_t TaskRevTag  =NULLTAG;

								char Task_ID[5]={'\0'};
								//char Lifecycle_state[10]={'\0'};
								char  *Task_ID_tokenized	=NULL;
								char  *Lifecycle_state_tokenized 	=NULL;
								char		   *DsgNO =NULL;
								char         *PltNm   =NULL;
								char         *PltNm1   =NULL;
								char          *APLDMLNo=NULL;
								char          *APLDMLTask=NULL;
								char          *ERCDML =NULL;

								int            n_found1        = 0;
								int            n_found2        = 0;
								int            n_found3        = 0;
								int            n_found4        = 0;
								//int           n_tasksFnd     = 0;
								int            n       = 0;
								int				stlst				= 0;
								int   task_count				= 0;
								tag_t        query2          = NULLTAG;
								tag_t        query1          = NULLTAG;
								tag_t        query3          = NULLTAG;
								tag_t        query4          = NULLTAG;
								tag_t       *APL_DML     = NULLTAG;
								tag_t       *APL_DML_Task   = NULLTAG;
								tag_t       *ERC_DML = NULLTAG;
								tag_t       *Planner_Task     = NULLTAG;
								tag_t       *task_status_list     = NULLTAG;

								workjob_tag = APLTask[i];
								ITK_CALL(AOM_UIF_ask_value(workjob_tag,"object_name",&assgnname));		

								//if(n_tasks>0)
								//{																	
								if (tc_strcmp(assgnname,"Review The Changes Done By APL Planner")==0)
								{
									Srno++;
									printf("\n assgnname1 is :%s\n",assgnname); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(APLTask[i],"job_name",&APLDML));
									printf("\n APLDML : %s\n",APLDML );fflush(stdout);
									tc_strcpy(Task_ID,APLDML);
									printf("\n Task_ID : %s\n",Task_ID );fflush(stdout);

									//Finding APL DML
									Task_ID_tokenized=strtok(Task_ID,"_");
									printf("Tokenized DML Number Obtained=%s\n",Task_ID_tokenized);fflush(stdout);
									DsgNO=strtok(NULL,"_");
									printf("\n DsgNO : %s",DsgNO); fflush(stdout);
									//tc_strcat(Task_ID_tokenized,APLDMLNO);
									PltNm=strtok(NULL,"/");
									printf("\n PltNm : %s\n",PltNm); fflush(stdout);
									//PltNm1=strtok(PltNm,"/");

									if (tc_strcmp(APLDMLNo,"NULL")==0) MEM_free(APLDMLNo);
									APLDMLNo = (char *) MEM_alloc( 100 * sizeof(char) );

									tc_strcpy(APLDMLNo,"");
									tc_strcat(APLDMLNo,Task_ID_tokenized);
									tc_strcat(APLDMLNo,"_");
									tc_strcat(APLDMLNo,PltNm);
									printf("\n APLDMLNo : %s\n",APLDMLNo); fflush(stdout);

									if (tc_strcmp(APLDMLTask,"NULL")==0) MEM_free(APLDMLTask);
									APLDMLTask = (char *) MEM_alloc( 100 * sizeof(char) );
									tc_strcpy(APLDMLTask,"");
									tc_strcat(APLDMLTask,Task_ID_tokenized);
									tc_strcat(APLDMLTask,"_");
									tc_strcat(APLDMLTask,DsgNO);
									tc_strcat(APLDMLTask,"_");
									tc_strcat(APLDMLTask,PltNm);
									printf("\n APLDMLTask : %s\n",APLDMLTask); fflush(stdout);

									if (tc_strcmp(ERCDML,"NULL")==0) MEM_free(ERCDML);
									ERCDML = (char *) MEM_alloc( 100 * sizeof(char) );
									tc_strcpy(ERCDML,"");
									tc_strcat(ERCDML,Task_ID_tokenized);
									printf("\n ERCDML : %s\n",ERCDML); fflush(stdout);

									//Using Query Builder to get APL DML Revision.....
									char
									*qry_entries1[] = {"Item ID","Type"},
									*qry_values1[] = {APLDMLNo,"APL DML Revision"};


									ITK_CALL(QRY_find("Item Revision...", &query1));
									printf("APL DML No.....\n");fflush(stdout);
									ITK_CALL(QRY_execute(query1, 1, qry_entries1, qry_values1, &n_found1, &APL_DML));
									printf("APL DML No. found rows.....\n");fflush(stdout);
									if(n_found1!=0)
									//for (j=0;j<n_found1;j++ )
									{
										printf("Found an APL DML Rev....\n");fflush(stdout);
										//ITK_CALL(AOM_ask_value_string(APL_DML[0],"item_id", &TaskId));
										//printf("\n TaskId : %s\n", TaskId);fflush(stdout);
										ITK_CALL(AOM_ask_value_string( APL_DML[0], "t5_cprojectcode", &ProjectCode));
										printf("\n ProjectCode : %s\n",ProjectCode);fflush(stdout);
										ITK_CALL(AOM_ask_value_string(APL_DML[0],"t5_cDRstatus",&DMLDRstat));
										printf("\n DMLDRstat : %s\n",DMLDRstat);fflush(stdout);
										//ITK_CALL(AOM_ask_value_string(APL_DML[0],"object_name",&DMLDescription));
										DMLDescription	=	NULL;
										DMLDescriptionDup	=	NULL;
										ITK_CALL(AOM_ask_value_string(APL_DML[0],"current_name",&DMLDescription));
										STRNG_replace_str(DMLDescription,"\n","",&DMLDescriptionDup);
										STRNG_replace_str(DMLDescription,"\n ","",&DMLDescriptionDup);
										STRNG_replace_str(DMLDescription,"\t ","",&DMLDescriptionDup);
										printf("\n DMLDescription : %s\n",DMLDescription);fflush(stdout);
										printf("\n DMLDescriptionDup : %s\n",DMLDescriptionDup);fflush(stdout);
									}

									char
									*qry_entries2[] = {"Item ID","Type"},
									*qry_values2[] = {APLDMLTask,"APL Task Revision"};

									ITK_CALL(QRY_find("Item Revision...", &query2));
									printf("APL DML Task.....\n");fflush(stdout);
									ITK_CALL(QRY_execute(query2, 1, qry_entries2, qry_values2, &n_found2, &APL_DML_Task));
									printf("APL DML Task found rows.....\n");fflush(stdout);
									if(n_found2!=0)
									//for (j=0;j<n_found1;j++ )
									{
										printf("Found an APL DML Rev....\n");fflush(stdout);
										ITK_CALL(AOM_ask_value_string(APL_DML_Task[0],"item_id", &TaskId));
										printf("\n TaskId : %s\n", TaskId);fflush(stdout);
										ITKCALL(WSOM_ask_release_status_list(APL_DML_Task[0],&task_count,&task_status_list));
										printf("\n task_count : %d\n", task_count);fflush(stdout);
										//if(task_count>0)
										for (stlst = 0; stlst < task_count; stlst++)
										{

											//ITK_CALL(AOM_UIF_ask_value(task_status_list[stlst],"release_status_list",&Lifecycle_state));
											// printf("\n Lifecycle_state : %s\n", Lifecycle_state);fflush(stdout);
											ITK_CALL(AOM_ask_name(task_status_list[stlst], &Lifecycle_state));
											printf("\n Lifecycle_state %s \n",  Lifecycle_state);fflush(stdout);
										}
									}

									char
									*qry_entries3[] = {"Item ID","Type"},
									*qry_values3[] = {ERCDML,"ERC DML Revision"};


									ITK_CALL(QRY_find("Item Revision...", &query3));
									printf("ERC DML.....\n");fflush(stdout);
									ITK_CALL(QRY_execute(query3, 1, qry_entries3, qry_values3, &n_found3, &ERC_DML));
									printf("\n n_found3 : %d\n", n_found3);fflush(stdout);
									if(n_found3!=0)
									//for (j=0;j<n_found1;j++ )
									{
										ITK_CALL(AOM_UIF_ask_value(ERC_DML[0],"date_released",&ERCDate));
										printf("\n ERCDate : %s\n", ERCDate);fflush(stdout);
									}

									ITK_CALL(AOM_UIF_ask_value(APLTask[i],"fnd0StartDate",&Planner_AssignDate));
									printf("\n Planner_AssignDate1.......\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(APLTask[i],"task_state",&Status));
									printf("\n Status1.......\n");fflush(stdout);
									ITK_CALL(AOM_UIF_ask_value(APLTask[i],"fnd0Assignee",&Reviewer_Name));
									printf("\n Reviewer_Name1.......\n");fflush(stdout);
									ITK_CALL(AOM_ask_value_string(APLTask[i],"object_name",&Assignment));
									printf("\n Assignment1.......\n");fflush(stdout);

									ITKCALL(AOM_UIF_ask_value(APLTask[i],"fnd0StartDate",&startDate));
									printf("\n startDate : %s\n",startDate);fflush(stdout);
									getCurrentDateTime(cCurrentAccessDate);
									printf("\n  todays date111 is: %s\n",cCurrentAccessDate);fflush(stdout);
									diffDate = (CalcDays(cCurrentAccessDate) - CalcDays(startDate));
									printf("\nDifference between Dates:%d",  diffDate);fflush(stdout);											


									printf("\n Planner_AssignDate: [%s]", Planner_AssignDate);fflush(stdout);
									printf("\n Status: [%s]", Status);fflush(stdout);
									printf("\n diffDate: [%d]", diffDate);fflush(stdout);
									printf("\n Reviewer_Name: [%s]", Reviewer_Name);fflush(stdout);
									printf("\n Assignment: [%s]", Assignment);fflush(stdout);


									printf("\n Test1.......\n");fflush(stdout);

									/*if (tc_strcmp(ERCDate,"NULL")!=0)
									{
									ERCDate="-";
									}*/

									if (tc_strcmp(Lifecycle_state,"NULL")!=0)
									{
										Lifecycle_state="-";
									}
									if (tc_strcmp(Lifecycle_state,"T5_LcsAPLWrkg")!=0)
									{
										Lifecycle_state="APL Working";
									}

									if(FlagPlannerNamePrint==0)
									{
										FlagPlannerNamePrint=1;
										fprintf(fd,"\n    Reviewer_Name 	  :%s ", user_name);	 	fflush(fd); 
										fprintf(fd,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(fd);
										fprintf(fd,"\n %s\t  %-10s\t    %-15s\t  %-10s\t   %-10s\t  %-10s\t  %-10s\t  %-10s\t  %-10s\t  %-10s\t %-10s\t %-10s\t  ","Srno","TaskId","DMLDescription","ProjectCode","ERCDate","Planner_AssignDate","AgeOfDML(days)","Status","Reviewer_Name","DMLDRstat","Lifecycle_state","Assignment");fflush(fd);
										fprintf(fd,"\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");fflush(fd);
									}

									fprintf(fd,"\n%d\t  %-2s\t   %s\t  %s\t  %s\t   %s\t  %d\t    %s\t %s\t %s\t %s\t  %s\t ",Srno,TaskId,DMLDescriptionDup,ProjectCode,ERCDate,Planner_AssignDate,diffDate,Status,user_name,DMLDRstat,Lifecycle_state,Assignment);fflush(fd);


								}//end of if (tc_strcmp(assgnname,"Work On DML")==0)
								//   }// end of if(n_tasks>0)
							}//end of for (i=0;i<n_tasks;i++ )

							if(FlagPlannerNamePrint==1)
							{     
								fprintf(fd,"\n=============================================================================================================================================================\n");fflush(fd); 
							}
						} // ens of if(tc_strstr(SetStrPlanner1,user_name)==NULL)

					} // for (j=0;j<num_of_members ;j++  )
				}//if(num_of_members>0)
			}//if(tc_strstr(rolename,"_APLC_Planner")!=NULL)
		}// for (n=0;n<num_of_roles ;n++ )
	}//if(num_of_roles>0)


	printf("\n  before close");fflush(stdout);
	fclose(fd);
	printf("\n  after close...\n");fflush(stdout);

	 char command[512];
	 //sprintf(command,"/user/aplstdgrp/Hemal/PlannerwiseAPL/senddmlpendingmail.sh %s",FileDown);
	 sprintf(command,"/user/uaprod/shells/APLSTDGRP/PlannerwiseAPL/senddmlpendingmail.sh %s",FileDown);
	 system(command);

	//return status;
}
