#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>




static FILE *fp1;



#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}


int ITK_user_main(int argc, char* argv[])
{

        int status=0;
        int i=0;
		int j=0;
		int count0=0;
		int count_status=0;
        tag_t query0=NULLTAG;
        tag_t *result0=NULLTAG;
		tag_t	*status_lst				= NULLTAG;
		char *partno=NULL;
		char *release_status=NULL;
		char *status_name=NULL;

		

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char * From_Date				= NULL;
	char * To_Date				    = NULL;


	 userid			= ITK_ask_cli_argument("-u=");
	 password 		= ITK_ask_cli_argument("-p=");
	 group 			= ITK_ask_cli_argument("-g=");
	 From_Date	    = ITK_ask_cli_argument("-fd=");
	 To_Date	    = ITK_ask_cli_argument("-td=");
		
	//-u=sjj919305 -p=XYT1ESA -g=APLPNR -fd=12-Jun-2023 -td=05-Sep-2023
		
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	qry_entries[0] = "Type";
	qry_entries[1] = "Release Status";
	
	qry_entries[2] = "Released After";
	qry_entries[3] = "Released Before";
	
	qry_values[0] = "ERC DML Revision";
	qry_values[1] = "T5_LcsErcRlzd"; // ERC Released state
	
	qry_values[2] = From_Date;
	qry_values[3] = To_Date;
		
		
		/*
		 char **Qry_Values0 = (char **) MEM_alloc(2* sizeof(char*));
		 Qry_Values0[0]=argv[1];
		 Qry_Values0[1]=argv[2];
         //Qry_Values0[1]="0";
		 char *names0[]={"Logged In After","Logged In Before","Status"};
		*/
		
       
        char *s= NULL;
		char *fnd0InProcess=NULL;
        

        fp1= fopen("ERC_DML_Details.csv","w");
        //printf("\n val=%s",argv[1]);fflush(stdout);
		//ITK_CALL( ITK_init_module("sjj919305","XYT1ESA","APLPNR"));
		ITK_CALL( ITK_init_module(userid,password,group));
        ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
        //ITK_CALL(ITK_auto_login());
        ITK_set_bypass(true);
        ITK_CALL(ITK_set_journalling(TRUE));

        if (status == 0 )
        {
		
        printf("\n sjj919305 login successful");fflush(stdout);

        }
        else
        {
          printf("\n Error code:%d",status);fflush(stdout);
          ITK_CALL(EMH_ask_error_text(status,&s));
          printf("\n Error message:%s",s);fflush(stdout);
        }
		ITK_CALL(QRY_find("Item Revision...",&query0));

      ITK_CALL(QRY_execute(query0,4,qry_entries,qry_values,&count0,&result0));
      printf("\n count qury01=%d",count0);fflush(stdout);
	  fprintf(fp1,"DML NO,InProcess,Status Name,Start Date,WF Name,Workflows list");fflush(fp1);
      //fprintf(fp1,"%s-%s\n",argv[1],argv[2]);fflush(fp1);
	  for(i=0;i<count0;i++)
	  {
		ITK_CALL(AOM_ask_value_string(result0[i],"item_id",&partno))	
		ITK_CALL(AOM_UIF_ask_value(result0[i],"release_status_list",&release_status))	
		//printf("\n Part NO: %s Release status: %s",partno,release_status);fflush(stdout);
		//fprintf(fp1,"%s",partno);fflush(fp1);

		ITK_CALL(AOM_UIF_ask_value(result0[i],"fnd0InProcess",&fnd0InProcess))	
		//printf("\n fnd0InProcess: %s"fnd0InProcess);fflush(stdout);
		int k=0;
				tag_t *AllWorkflows=NULLTAG;
		int val_count=0;
		char *Workflowslist=NULL;
		char *StartDate=NULL;
		char *current_name=NULL;
		char *Workflowslist1=NULL;

		ITK_CALL(AOM_UIF_ask_value(result0[i],"fnd0AllWorkflows",&Workflowslist))
			

		STRNG_replace_str(Workflowslist,",",";",&Workflowslist1);
			printf("\n Workflowslist: %s",Workflowslist1);fflush(stdout);
		
		

        ITK_CALL(AOM_ask_value_tags(result0[i],"fnd0AllWorkflows",&val_count,&AllWorkflows));

        if(val_count==0)
        {

        printf("\n Skipping %s as not submitted in WF",partno);fflush(stdout);
        continue;
        }
		for(k=0;k<val_count;k++)
		{


		AOM_UIF_ask_value(AllWorkflows[k],"current_name",&current_name);
		printf("\n current_name:%s",current_name);fflush(stdout);

        AOM_UIF_ask_value(AllWorkflows[k],"fnd0StartDate",&StartDate);
        printf("\n StartDate:%s",StartDate);fflush(stdout);

		
		ITK_CALL(WSOM_ask_release_status_list (result0[i], &count_status, &status_lst));
		if(count_status > 0)
					{
						for(j=0;j<count_status;j++)
						{
							ITK_CALL(AOM_ask_value_string (status_lst[j], "object_name", &status_name));
							//printf("\n Eff: Release Status name:%s", status_name);fflush(stdout);
							        //if(tc_strcmp(status_name,"T5_LcsErcRlzd")==0 && tc_strcmp(fnd0InProcess,"True")==0 )
										if(tc_strcmp(status_name,"T5_LcsErcRlzd")==0 )
                                    {
                                               printf("\n ERC DMLNO: %s ERC fnd0InProcess: %s Release status: %s StartDate:%s current_name:%s Workflowslist1:%s",partno,fnd0InProcess,status_name,StartDate,current_name,Workflowslist1);fflush(stdout);
                                             fprintf(fp1,"\n %s,%s,%s,%s,%s,%s",partno,fnd0InProcess,status_name,StartDate,current_name,Workflowslist1);fflush(fp1);
                                    }
                             

						}
						
					}




	  }
	  }
 
	fprintf(fp1,"\n=============================================================== Report END=============================================================================================");fflush(fp1);

        fclose(fp1);

        return 0;
    }
