#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <sa/tcfile.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <tccore/aom.h>
#include <sa/tcfile.h>
#include <tccore/aom_prop.h>
#define _DEBUG
#include <tccore/grm.h>
#include <ae/dataset.h>
#include <tccore/item.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <sa/sa.h>
int ltst_Veh_CL();
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
	char *refname[AE_reference_size_c + 1];
	AE_reference_type_t reftype;
int		status				= 0;

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"



#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
		}																	\
	;

int ITK_user_main(int argc, char* argv[])
{
				char				* DML_No			= NULL;
				
				int					 ifail   = ITK_ok;
				char                 command[200];


				DML_No					= ITK_ask_cli_argument("-DML_No=");
				


				printf("\n\t INSIDE ERC DML print report 2c4 exe \n");fflush(stdout);
				
				ITK_auto_login();
				ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
				ITK_CALL(ITK_set_bypass(true));
				
				sprintf(command,"/user/cvprod/shells/DML_DCR/tm_ERCDML_PrintCV.sh %s",DML_No);
				TC_write_syslog("Command = %s\n",command);
				system(command);
				
				
				return ifail;
}


					


