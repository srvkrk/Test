#define TE_MAXLINELEN  128
#include <ae/dataset.h>
//#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>


#define Debug TRUE

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string = NULL;      \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
		EMH_ask_error_text (stat, &err_string);                 \
		printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
		printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
		if(err_string) MEM_free(err_string);                                \
		exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}


// Define maximum line length (arbitrary large size)
#define MAX_LINE_LENGTH 3000

int iFail = ITK_ok;
char *cError = NULL;
char *dError = NULL;


extern int ITK_user_main(int argc, char** argv)
{
	char *ip_itemID = NULL;  //Declration of arguments to be taken
	char* c_RevID = NULL;
	char* c_Rels_Stat = NULL;
	char* c_NewRevID = NULL;
	char* c_NewRev1_ID = NULL;
	char* c_Revision = NULL;
	char* c_CheckOutBy = NULL;
	char* c_Owner = NULL;
	
	const char	   *reason1	=	NULL;
	const char     *change_id1	=	NULL;
	const char     *dir_name1	=	NULL;
	
	int i_NewRev_Seq = 0;
	int i_CO_Seq = 0;
	char   c_Revision_1[20];
	
	logical is_CheckedOut = false ;    // 0 = False(Not checked-out) AND 1 = True (Checked-out)
	
	tag_t t_NewRev = NULLTAG;
	tag_t t_item = NULLTAG;
	tag_t t_LatestRev = NULLTAG;
	tag_t t_NewRev1 = NULLTAG;
	tag_t t_attr_id = NULLTAG;
	
	FILE		*fp 			= NULL;
	FILE		*fpNotRev 			= NULL;
	FILE		*fpNotCko			= NULL;
	FILE		*fpRevCko			= NULL;
	
	fp = fopen("/user/cvprod/Vineet/Support/TRY_revise_CICO/CreoReviseCheckout/notreleased.txt","a+");
	if (fp == NULL)
	{
		printf("ERROR: Cannot open File\n");
	}
	
	fpNotRev = fopen("/user/cvprod/Vineet/Support/TRY_revise_CICO/CreoReviseCheckout/notrevised.txt","a+");
	if (fpNotRev == NULL)
	{
		printf("ERROR: Cannot open File\n");
	}
	
	fpNotCko = fopen("/user/cvprod/Vineet/Support/TRY_revise_CICO/CreoReviseCheckout/notcheckout.txt","a+");
	if (fpNotCko == NULL)
	{
		printf("ERROR: Cannot open File\n");
	}
	
	fpRevCko = fopen("/user/cvprod/Vineet/Support/TRY_revise_CICO/CreoReviseCheckout/revisecheckout.txt","a+");
	if (fpRevCko == NULL)
	{
		printf("ERROR: Cannot open File\n");
	}


	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	printf(" \n\n\n *****STARTING TO REVISE AND CHECK OUT*****\n\n\n");fflush(stdout);

	ip_itemID = ITK_ask_cli_argument( "-IpId=" );	// Asking arguments for input

	printf("\n\n Input : ip_itemID: [%s]\n\n",ip_itemID);fflush(stdout);
	//iFail = ITEM_find_item_in_idcontext(ip_itemID, NULLTAG, &t_item);
	if(ITEM_find_item(ip_itemID,&t_item));
	if (t_item != NULLTAG) 
	{
		printf("\n --->> ITEM_ID FOUND"); fflush(stdout);
	}
	else 
	{
		printf("\n ---x---x-----x---x---- ITEM TAG of [%s] NOT FOUND HENCE EXIT ---x------x------x----x-",ip_itemID);fflush(stdout);
		//continue;
	}
	
	iFail = ITEM_ask_latest_rev(t_item, &t_LatestRev);
	
	ITK_CALL(AOM_ask_value_string(t_LatestRev,"item_revision_id",&c_RevID));
	ITK_CALL(AOM_UIF_ask_value(t_LatestRev,"release_status_list",&c_Rels_Stat));
	
	ITK_CALL(AOM_UIF_ask_value(t_LatestRev,"owning_user",&c_Owner));
	
	printf("\n --->> ITEM_ID = %s",ip_itemID);
	printf("\n --->> Latest Revision_ID = %s",c_RevID);
	printf("\n --->> Release Status = %s",c_Rels_Stat);
	printf("\n --->> Owing user (owner) = %s",c_Owner);
	
	if (tc_strcmp(c_Rels_Stat,"ERC Working")==0)
	{
		
		ITK_CALL(AOM_UIF_ask_value(t_LatestRev,"checked_out_user",&c_CheckOutBy));
		printf("\n\n\n --->> checked out by  = %s",c_CheckOutBy);
		printf("\n\nThe design revision [%s] is ERC Working\n\n", ip_itemID);
		fprintf(fp,"\n%s,ERC Working,%s,%s,",ip_itemID,c_Owner,c_CheckOutBy);fflush(fp);
		
	}
	
	else if (tc_strcmp(c_Rels_Stat,"ERC Review")==0)
	{
		printf("\n\nThe design revision [%s] is ERC Review\n\n", ip_itemID);
		
		fprintf(fp,"\n%s,ERC Review,%s,",ip_itemID,c_Owner);fflush(fp);
	}
	else
		{
			if(tc_strstr(c_Rels_Stat,"ERC Released")!=NULL)  //the part is ERC Released so revision and checking out 
			{
			
				printf("\n\nRevising the item revision %s\n\n", ip_itemID);
				iFail = ITEM_copy_rev(t_LatestRev, NULL, &t_NewRev);     //REVISE 
				
				
				
				if(iFail != ITK_ok)
				{
					EMH_ask_error_text(iFail, &cError);
					printf("\n ---xx Could NOT Revise the part --xx \n\t %s ", cError);
					fprintf(fpNotRev,"\n%s,",ip_itemID);fflush(fpNotRev);
				}
				else
				{
					printf("\n\n ============================================================================================================================ ");fflush(stdout);
					printf("\n\n --->> [%s] REVISE ACTION SUCCESSFUL \t ",ip_itemID);
					ITK_CALL(AOM_ask_value_string(t_NewRev,"item_revision_id",&c_NewRevID));
					printf("\n\n --->> New Revision created from Latest Rev with ID as  = [%s] \t REVISED REVISED SUCCESSFUL",c_NewRevID);
					printf("\n\n ============================================================================================================================ ");fflush(stdout);
					
					
					printf("\n\nChecking out  the revised item [%s] revision [%s]\n\n", ip_itemID,c_NewRevID);

					
					 iFail = ITEM_copy_rev(t_NewRev, NULL, &t_NewRev1); //check out
					 //ITK_CALL(RES_checkout2(t_NewRev,reason1,change_id1,dir_name1,RES_EXCLUSIVE_RESERVE));
					 ITK_CALL(RES_is_checked_out(t_NewRev1, &is_CheckedOut));
					if(is_CheckedOut == 1)
					{
						ITK_CALL(AOM_ask_value_string(t_NewRev1,"item_revision_id",&c_NewRev1_ID));
					printf("\n --->> checked out revision item [%s] as revision [%s] CHECK-OUT SUCESSFULLY ",ip_itemID,c_NewRev1_ID);
						fprintf(fpRevCko,"\n%s,%s,",ip_itemID,c_NewRev1_ID);fflush(fpNotRev);
					}
					else
					{
						EMH_ask_error_text(iFail, &dError);
						printf("\n ---xx Could NOT check out the part --xx \n\t %s ",dError);
						fprintf(fpNotCko,"\n%s,",ip_itemID);fflush(fpNotCko);				
					}
				
				
				
				}
			}
			else
			{
				printf("\n\nThe design revision [%s] is not ERC Released\n\n", ip_itemID);
				fprintf(fp,"\n%s,notERCReleased",ip_itemID);fflush(fp);
			}
		}
		
	
	
	
	
	printf ("\n\n --XXXXXXXXXXXXXXX----END OF PROGRAM---XXXXXXXX-------XXXXXXXXXXXXX----END OF PROGRAM---XXXXXXXX----- \n ");fflush(stdout);
	iFail = ITK_exit_module(true);
	
	if (fp!=NULL)
	{
		fclose(fp);
	}
    
    return ITK_ok;
}
	
	

/*
command line 
// $TC_ROOT/tcldPatch/tcPatchExecutable CPartVAQRev
./ERC_Revise_CheckOut -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g="ERC_Designers_Group" -IpId=$ShDesRev
*/