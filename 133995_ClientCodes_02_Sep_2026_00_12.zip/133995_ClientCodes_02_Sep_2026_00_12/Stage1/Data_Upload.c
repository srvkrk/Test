/****************************************************************************************************
*  File            :   Data_Upload.c
*  Created By      :   Anvesh Bujule
*  Created On      :   15 Jun 2023
*  Purpose         :   Upload data for DFQ Use Cases
*  scp testcmi@172.22.97.28:/user/testcmi/devgroups/Tushar/clientcode/DVA/Data_Upload .
*  Usage		   :./Data_Upload -u=ercpsup -p=XYT1ESA -g="" -formObjName="DVA_PV_MB2A03_001" -Desc="FRONT SUSPENSION (CAMBER VARIATION UNDER NONADJUSTABLE SYSTEM)" -BUnit="PCBU" -CocHead="tkr06466" -DfQApp="True" -Modadd="MB2A03" -UseCaseType="F"
*  Usage		   :./Data_Upload -u=ercpsup -p=XYT1ESA -g="" -formObjName="DVA_PV_MB2A03_001" -Desc="FRONT SUSPENSION (CAMBER VARIATION UNDER NONADJUSTABLE SYSTEM)" -BUnit="PCBU" -CocHead="tkr06466" -DfQApp="False" -Modadd="MB2A03" -UseCaseType="A"
*****************************************************************************************************/
//#include <stdio.h>
//#include <string.h>
//#include <stdlib.h>
//#include <unidefs.h>
//#include <itk/mem.h>
//#include <tcinit/tcinit.h>
//#include <tccore/item.h>
//#include <bom/bom.h>
//#include <cfm/cfm.h>
//#include <ps/ps_errors.h>
//#include <tccore/item_errors.h>
//#include <tc/emh.h>
//#include <pie/pie.h>
//#include <sa/am.h>
//#include <ae/dataset.h>
//#include <tccore/tctype.h>
//#include <res/reservation.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include <unidefs.h>
//#include <bom/bom.h>
//#include <bom/bom_attr.h>
#include <cfm/cfm.h>
//#include <propdesc/propdesc.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <stdarg.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_date.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
//#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <time.h>
#include <sa/am.h>
#include<tc/tc_startup.h>
#define Debug TRUE
#define ITK_err 910001

#define CONNECT_FAIL (EMH_USER_error_base + 2)

#define Debug TRUE
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))


static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int index = 0;
		int n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

void removeNewLineChar(char *ptr)
{
    while((ptr != NULL) && (*ptr != '\n'))
    {
        ++ptr;
    }
    *ptr = '\0';
}

#define WRONG_USAGE 100001
char* subString (char* mainStringf ,int fromCharf,int toCharf);

void dousage()
{
   printf("\nUSAGE: t5ListEmptyVisPdfDesRev -fromDate= -toDate= -sType= -outFile= \n");
   printf("\E.g: t5ListEmptyVisPdfDesRev -fromDate=01-May-2018 -toDate=02-May-2018 -sType=CMI2Part -outFile=out.txt \n");
   return;
}

void lower_string(char s[]) 
{
	int c = 0;

	while (s[c] != '\0') 
	{
		if (s[c] >= 'A' && s[c] <= 'Z') 
		{
			s[c] = s[c] + 32;
		}
		c++;
	}
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

int ITK_user_main(int argc, char* argv[])
{
	int status;
	int resultCount = 0;
	int n_entries	= 1;
	int number_of_types = 0;
	int Conobj_count = 0;
	
	tag_t queryTag = NULLTAG;
	tag_t queryTag1 = NULLTAG;
	tag_t GMXqry_tg = NULLTAG;
	tag_t object_uasecase = NULLTAG;
	tag_t datasettag = NULLTAG;
	tag_t Controluse = NULLTAG;
	tag_t* rev;
	tag_t *type_tag = NULLTAG;
	tag_t *Con_object = NULLTAG;
	tag_t object_create_input_tag = NULLTAG;
	tag_t docTag = NULLTAG;
	tag_t atti_id = NULLTAG;
	tag_t object_create_input_taginstatnce = NULLTAG;

	char *s;
	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(n_entries * sizeof(char *));
	char *logPath       = (char*) MEM_alloc(200*sizeof(char));

	char* formObjName	= NULL;
	char* Desc			= NULL;
	char* BUnit			= NULL;
	char* CocHead		= NULL;
	char* DfQApp		= NULL;
	char* Modadd		= NULL;
	char *timeStr            =   NULL;
	char* UseCaseType	= NULL;
	char* object_create_class	= NULL;
	char* NameMod	= NULL;
	char *timeStrUpdatedNew  =   NULL;
	char *timeStrUpdated     =   NULL;
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	int dirStatus=0;
	when = *localtime(&now);

	NameMod = (char *)MEM_alloc(50);
	time_t mytime = time(NULL);
	timeStr = ctime(&mytime);
	timeStr[strlen(timeStr)-1] = '\0';
	STRNG_replace_str(timeStr," ","_",&timeStrUpdated);
	STRNG_replace_str(timeStrUpdated,":","_",&timeStrUpdatedNew);

	
	
	
	
	strftime(GenDate,100,"%d_%b_%Y",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);

	//char type_name2[TCTYPE_name_size_c+1];
	printf("\n Starting Program -- Data Upload ::");fflush(stdout);

	char type_name2[TCTYPE_name_size_c+1];

	if ((status = ITK_auto_login()) != ITK_ok)
    {
		printf("Login fail !!: Error code = %d \n\n",status);
		return 1;
	}
   
	//Getting Input Arguments
	char* usr = ITK_ask_cli_argument("-u=");/* gets user */	
	char* upw = ITK_ask_cli_argument("-p=");/* gets the password */
	if(!upw) 
	{
		char* upf = ITK_ask_cli_argument("-pf=");/* gets the password */
	}

	char* ugp = ITK_ask_cli_argument("-g=");/* what the group is */

	formObjName = ITK_ask_cli_argument("-formObjName=");/* what is the PartNumber */
	Desc = ITK_ask_cli_argument("-Desc=");/* what is the Description */
	BUnit = ITK_ask_cli_argument("-BUnit=");/* what is the Buisness Unit */
	CocHead = ITK_ask_cli_argument("-CocHead=");/* what is the COC Head */
	DfQApp = ITK_ask_cli_argument("-DfQApp=");/* what is the DfQ Applicability */
	Modadd = ITK_ask_cli_argument("-Modadd=");/* what is the Module address */
	UseCaseType = ITK_ask_cli_argument("-UseCaseType=");/* what is the Use Case Type */
	//tc_strcpy(logPath,"/tmp/");  // /tmp/ - to be added if required


	tc_strcat(logPath,"Created_Usecase_Log_");
	tc_strcat(logPath,GenDate);
	tc_strcat(logPath,"_.txt");
	FILE *flogPtr=fopen(logPath,"r");	
	printf("\n Usecase Creation Start\n");

	 if(flogPtr== NULL)
     {

		flogPtr = fopen(logPath,"a+");

		printf("\n New Fill Created \n");	

      }
	  else
	  {
		printf("\n File found so only opened in append mode.\n");					
		flogPtr = fopen(logPath,"a+");
	  }
 
	 

	if(status =ITK_ok)
	{
	   printf("\n LOGIN SUCCESSFUL\n");fflush(stdout);
	}

	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with ITK_init_module: %s ***\n",s);fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	//Find QUery


	if(QRY_find2("Control Objects...", &GMXqry_tg));

	char *GMsc_entry1[3] = {"Name","SYSCD","SUBSYSCD"};
	char **GMsc_RelVal = (char **) MEM_alloc(50 * sizeof(char *));
	GMsc_RelVal[0] = "Module";
	GMsc_RelVal[1] = Modadd;
	GMsc_RelVal[2] = "Module";

	//char **Name = (char **) MEM_alloc(50 * sizeof(char *));

    tc_strcpy(NameMod,"");
    tc_strcat(NameMod,"Module");

	printf("After cat %s \n",NameMod); fflush(stdout);

	ITK_CALL(QRY_execute(GMXqry_tg, 2, GMsc_entry1, GMsc_RelVal, &Conobj_count, &Con_object));

	printf("\n Query count for Control Object :[%d]\n",Conobj_count); fflush(stdout);

	if(Conobj_count == 0)
	{
		printf("Inside control object creation \n"); fflush(stdout);

	    ITK_CALL(TCTYPE_find_type( "T5_ControlObject", NULL, &Controluse));
		ITK_CALL(TCTYPE_construct_create_input(Controluse, &object_uasecase)); 
		ITK_CALL(AOM_set_value_string(object_uasecase,"object_name",NameMod));
		ITK_CALL(AOM_set_value_string(object_uasecase,"t5_SubSyscd",NameMod));
		ITK_CALL(AOM_set_value_string(object_uasecase,"t5_Syscd",Modadd));
		ITK_CALL(AOM_set_value_string(object_uasecase,"t5_RecordType","1"));
		ITK_CALL(TCTYPE_create_object(object_uasecase,&datasettag));
		//ITK_CALL(AOM_save(datasettag));
		ITK_CALL(AOM_save_with_extensions(datasettag));
		ITK_CALL(AOM_refresh(datasettag,0));
	
	
	}
	else
	{
	   printf("Control object found \n"); fflush(stdout);
	
	}


	status = QRY_find2("DFQ Use Case", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}	

	if (queryTag)
	{
		printf("Found Query for DFQ Use Cases Object \n"); fflush(stdout);
	}
	else
	{
		printf("*** Query Not Found for DFQ Use Cases Object *** \n"); fflush(stdout);
		return status;
	}

	char* documentName;
	documentName = NULL;
	documentName = (char *)MEM_alloc(50);
	tc_strcpy(documentName, formObjName);
	tc_strcat(documentName, "*");

	qry_entries[0] = (char *)MEM_alloc(10);
	strcpy(qry_entries[0], "Name");

	qry_values[0] = (char *)MEM_alloc(strlen(documentName ) + 1);
	tc_strcpy(qry_values[0], documentName);
	
	QRY_set_name_mode(queryTag,false);

	printf("\n After cat documentName %s\n",documentName);

	//Execute Query
	//status = QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev);
	ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));

	printf("\n No. of DFQ Use Cases Object Found are -- %d\n", resultCount);fflush(stdout);

	if(resultCount == 0)
	{		
		printf("\n Creating DFQ Use Cases Object  = %s -- \n", formObjName);fflush(stdout);
        //T5_DFQ_Document 
		ITK_CALL(TCTYPE_find_types_for_class("T5_DFQ_UseCase",&number_of_types,&type_tag));
		printf("\n Number of class found are-------->  : %d\n",number_of_types);fflush(stdout);
		
		if ((tc_strcmp(Desc,"") != 0) && (tc_strcmp(BUnit,"") != 0) && (tc_strcmp(DfQApp,"") != 0) && (tc_strcmp(Modadd,"") != 0) && (tc_strcmp(UseCaseType,"") != 0))
		{
			//Construct Class Type
			ITK_CALL(TCTYPE_construct_create_input(type_tag[0], &object_create_input_tag));

			//ITK_CALL(POM_class_of_instance(object_create_input_tag,&object_create_input_taginstatnce));
			//ITK_CALL(POM_name_of_class(object_create_input_taginstatnce,&object_create_class));
			//ITK_CALL(POM_set_attr_null(1,object_create_input_taginstatnce,&atti_id));	

			//ITK_CALL(POM_set_attr_string(object_create_input_tag,"object_name",formObjName));

			ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_name",formObjName));					
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"object_desc",Desc));									
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"t5_DfQBUInitS",BUnit));	
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"t5_DfqUseOwner",CocHead));	
			
			if (tc_strcmp(DfQApp,"True") == 0)
			{
				ITK_CALL(AOM_set_value_logical(object_create_input_tag,"t5_DfQApplicablility",1));	
			}
			else
			{
				ITK_CALL(AOM_set_value_logical(object_create_input_tag,"t5_DfQApplicablility",0));	
			}
						
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"t5_DesignGroup",Modadd));									
			ITK_CALL(AOM_set_value_string(object_create_input_tag,"t5_DFQ_UseCase_Type",UseCaseType));									
			
			TCTYPE_create_object(object_create_input_tag, &docTag);
			
			ITK_CALL(AOM_lock(docTag));
			ITK_CALL(AOM_save_with_extensions(docTag));
			ITK_CALL(AOM_refresh(docTag,false));

			printf("\n %s Successfully Created -- \n", formObjName);fflush(stdout);
			printf("\n Desc =%s, BUnit =%s, CocHead=%s, DfQApp =%s, Modadd=%s, UseCaseType=%s \n",Desc,BUnit,CocHead,DfQApp,Modadd,UseCaseType);fflush(stdout);
			ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
			printf("\n  object Found Count is %d \n",resultCount);fflush(stdout);

			if(resultCount>0)
			{ 
				printf("\n  object Found*********** \n");fflush(stdout);

			   fprintf(flogPtr,"%s\n",formObjName);
			}
			else
			{
			
			  printf("\n  This Usecase is not created %s \n",formObjName);fflush(stdout);
			  fprintf(flogPtr,"This Usecase is not created %s\n",formObjName);
			
			}
		}
		else
		{
			printf("\n Business Unit,,, are the Mandatory attributes... \n");fflush(stdout);
		}
	}
	else
	{
		printf("\n DFQ Use Cases Object  = %s already found in PLM -- \n", formObjName);fflush(stdout);
	}
	fclose(flogPtr);
	
	printf("\n Exiting Program Data Upload--  \n");fflush(stdout);
	return status;		 
}