/*
rm -f combineClientEv.a soapC.o soapClient.o stdsoap2.o combineClientEv.o
http://172.22.97.50:8080/pFirst_SOA/cgi/service.cgi?action=pronext_pv

./wsdl2h -c -o combineClient.h  http://172.22.97.50:8080/pFirst_SOA/cgi/service.cgi?action=pronext_pv
./soapcpp2  -1 -e -c -C combineClient.h

cc -c -fPIC soapC.c
cc -c -fPIC soapClient.c
cc -c -fPIC stdsoap2.c
cc -c -fPIC combineClientEv.c

ar -cr combineClientEv.a soapC.o soapClient.o stdsoap2.o combineClientEv.o
./compile CCPLMToProNext_EV_prod_part_dbk.c
./linkitk -o CCPLMToProNext_EV_prod_part_dbk CCPLMToProNext_EV_prod_part_dbk.o combineClientEv.a
$TC_ROOT/tcldPatch/tcPatchExecutable CCPLMToProNext_EV_prod_part_dbk
#CCPLMToProNext_EV_prod_part_dbk -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -i=548154630240 -r=A -s=1

*/
#include <ae/dataset.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <qry/qry.h>
#include <sa/person.h>
#include <sa/user.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tc/preferences.h>
//#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <time.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
;

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}
char* Create_SOR_ProNext_Frm_WS_EV(char *part_number,char *PPPMprojcode,char *part_desc,char *revision1,char *sequence1,char *auto_sor_no,char *sor_date,char *sor_category,char *sVariantId,char *colorble,char *rfq_path,char *SORCreatorId, char *dvp_path, char *drawing_path);
int ifail = ITK_ok;

int tm_check_info_control_object(char* syscd, char* subsyscd, char* info1, char* info2)
{
	int n_found = 0;
	int n_entries = 2;
	char* qry_entries[2] = { "SYSCD", "SUBSYSCD" };
	char* qry_values[2] = { syscd, subsyscd };
	tag_t query = NULLTAG;
	tag_t* cntr_objects = NULL;

	char* l_info1 = NULL;
	char* l_info2 = NULL;

	ITK_CALL(QRY_find2("ControlObjQry", &query));
	ITK_CALL(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
	printf("\n[%s] [%s] n_found : [%d]", syscd, subsyscd, n_found); fflush(stdout);
	TC_write_syslog("\n[%s] [%s] n_found : [%d]", syscd, subsyscd, n_found); fflush(stdout);

	if (n_found > 0)
	{
		ITK_CALL(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo1", &l_info1));
		tc_strcpy(info1, l_info1);
		ITK_CALL(AOM_ask_value_string(cntr_objects[0], "t5_Userinfo2", &l_info2));
		tc_strcpy(info2, l_info2);

		TC_write_syslog("\ninfo1 : [%s] info2 : [%s]", info1, info2); fflush(stdout);
	}

	return n_found;
}

int tm_querysor_html ( char *sor_no )
{
	char *type_name = NULL;
	char *s_prj_code = NULL;
	int n_entries = 2 ;
    int n_found = 0 ;
	tag_t query = NULLTAG;
    tag_t *cntr_objects	= NULL;
	char *qry_entries[2] = { "Item ID", "Type" } ;
	char *qry_values[2]	= { sor_no, "T5_quicksorRevision" } ;

	char *t5_CtrlSorCat = NULL;
	char *part_number = NULL;
	char *item_revision_id = NULL;
	char *object_desc = NULL;
	char *mail_body = NULL;
	char *Mailsubject = NULL;

	tag_t Part_sor_rel_type = NULLTAG;
	tag_t *PartRevision = NULLTAG;
	int Tskcount = 0;
	char sor_mbdy_fname[200] = { 0  };
	char *sor_cmd_to_execute = NULL;
	FILE *fsor = NULL;
	FILE *f_mail_body = NULL;
	
	int count = 0;
	int NStatus = 0;
	tag_t *status_list=NULLTAG;
	char *name = NULL;
	date_t drelease_date ;
	char *ccreation_date = NULL;
	char *path1 = NULL;
	char *path2 = NULL;
	int n_found_qSOR_mail_shell = 0;
		
		
	
	mail_body = MEM_alloc ( 2000 ) ;
	Mailsubject = MEM_alloc ( 200 ) ;
	sor_cmd_to_execute = MEM_alloc ( 2000 ) ;

	
		

    ITK_CALL ( QRY_find2 ( "Item Revision...", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;

	printf("\nQuick sor Revision found : [%d] \n",n_found);fflush(stdout);
	TC_write_syslog("\nQuick sor Revision found : [%d] \n",n_found);
	sprintf ( sor_mbdy_fname, "/tmp/QuickSORMailBody_%s.html",sor_no );
	f_mail_body = fopen ( sor_mbdy_fname, "w" );
	//fprintf ( f_mail_body, "%s", mail_body );
	if ( n_found > 0 )
	{
		fprintf ( f_mail_body, "<html lang=\"en\">");
		fprintf ( f_mail_body, "<head>");
		fprintf ( f_mail_body, "  <style>");
		fprintf ( f_mail_body, "table, th, td {");
		fprintf ( f_mail_body, "  border: 1px solid black;");
		fprintf ( f_mail_body, "}");
		fprintf ( f_mail_body, "</style>");
		fprintf ( f_mail_body, "</head>");
		fprintf ( f_mail_body, "<body>");

		fprintf ( f_mail_body, "Hello Team,<br>");
		fprintf ( f_mail_body, "Pls refer below details of TCUA SOR as submitted by Engineering Team.<br><br>");

		fprintf ( f_mail_body, "<b>Cost Management Team,</b><br>");
		fprintf ( f_mail_body, "Request you to take it ahead for Should Costing & Capex Detailing.<br><br>");

		fprintf ( f_mail_body, "<b>Project / Program Management Team,</b><br>");
		fprintf ( f_mail_body, "Pls intimate PMT team for taking this request ahead for TRSO closure, Supplier Nomination and Part Development.<br><br>");

		fprintf ( f_mail_body, "<b>VIG / Chief Engineer,</b><br>");
		fprintf ( f_mail_body, "For information pls.<br>");


		fprintf ( f_mail_body, "<br>");
		fprintf ( f_mail_body, "<br>");
		fprintf ( f_mail_body, "<br>");

	

		//table start here
		ITK_CALL ( WSOM_ask_release_status_list(cntr_objects[0] ,&count,&status_list) );
		printf("\nRelease status count : [%d] \n",count);fflush(stdout);
		TC_write_syslog("\nRelease status count : [%d] \n",count);
		for ( NStatus = 0; NStatus < count; NStatus++ )
		{
			//CR_ask_release_status_type(status_list[NStatus],name);
			ITK_CALL ( AOM_ask_name(status_list[NStatus], &name) );
			printf("\nrelease status : [%s] \n",name);fflush(stdout);
			TC_write_syslog("\nrelease status : [%s] \n",name);
			if ( tc_strcmp( name, "T5_LcsErcRlzd" ) == 0 )
			{
				ITK_CALL ( WSOM_status_ask_date_released ( status_list[NStatus],&drelease_date));
				ITK_CALL ( ITK_date_to_string(drelease_date, &ccreation_date) );

				printf("\tccreation_date : [%s] \n",ccreation_date);fflush(stdout);
				TC_write_syslog("\tccreation_date : [%s] \n",ccreation_date);
			}
		}

		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_qCtrlSorCat", &t5_CtrlSorCat ) ) ;
		TC_write_syslog ( "\nCategory : [%s]", t5_CtrlSorCat ) ;
		printf ( "\nCategory : [%s]", t5_CtrlSorCat ) ;fflush(stdout);

		ITK_CALL ( GRM_find_relation_type ( "T5_PartSorRel", &Part_sor_rel_type ) ) ;
		ITK_CALL ( GRM_list_primary_objects_only ( cntr_objects[0], Part_sor_rel_type, &Tskcount, &PartRevision ) ) ;//sor to part traverse
		if ( Tskcount > 0 )
		{
			ITK_CALL ( AOM_ask_value_string ( PartRevision[0], "item_id", &part_number ) ) ;
			ITK_CALL ( AOM_ask_value_string ( PartRevision[0], "item_revision_id", &item_revision_id ) ) ;
			ITK_CALL ( AOM_ask_value_string ( PartRevision[0], "object_desc", &object_desc ) ) ;

			TC_write_syslog ( "\npart_number : [%s]", part_number ) ;
			TC_write_syslog ( "\nitem_revision_id : [%s]", item_revision_id ) ;
			TC_write_syslog ( "\nobject_desc : [%s]", object_desc ) ;

			TC_write_syslog("%s %s %s %s",part_number,item_revision_id,object_desc,t5_CtrlSorCat);
			printf("\nPart Details : %s %s %s %s",part_number,item_revision_id,object_desc,t5_CtrlSorCat);fflush(stdout);
			//fprintf(f_mail_body,"\t%s\t%s\t%s\t%s\t%s\n",part_number,item_revision_id,object_desc,t5_CtrlSorCat,ccreation_date);
		}


		fprintf ( f_mail_body, "<table>");

		fprintf ( f_mail_body, "<tr>");
		fprintf ( f_mail_body, "<th>Program Name</th>");
		fprintf ( f_mail_body, "<th>Part Number</th>");
		fprintf ( f_mail_body, "<th>Part Description</th>");
		fprintf ( f_mail_body, "<th>SOR Category</th>");
		fprintf ( f_mail_body, "<th>Date of SOR Release</th>");
		fprintf ( f_mail_body, "</tr>");//header end

		fprintf ( f_mail_body, "<tr>");//row 1		//add for loop for multiple parts
		fprintf ( f_mail_body, "<td> ?? </td>");
		fprintf ( f_mail_body, "<td>%s</td>",part_number);
		fprintf ( f_mail_body, "<td>%s</td>",object_desc);
		fprintf ( f_mail_body, "<td>%s</td>",t5_CtrlSorCat);
		fprintf ( f_mail_body, "<td>%s</td>",ccreation_date);
		fprintf ( f_mail_body, "</tr>");

		fprintf ( f_mail_body, "</table>");
		//table end here


		fprintf ( f_mail_body, "<br>");
		fprintf ( f_mail_body, "<br>");
		fprintf ( f_mail_body, "<br>");

		fprintf ( f_mail_body, "<u>This is a system generated \n, Pls get in touch with EV PMO Team if in case of any issue / doubt.</u>");

		fprintf ( f_mail_body, "</body>");
		fprintf ( f_mail_body, "</html>");

		TC_write_syslog ( "\nsor_mbdy_fname : [%s]", sor_mbdy_fname ) ;
	}



	

	fclose ( f_mail_body ) ;

	//sprintf ( Mailsubject, "** TCUA SOR:[%s]  Part Number:[%s] Part Description:[%s] **",sor_no,part_number,object_desc);
	sprintf ( Mailsubject, "TCUA SOR %s  Part Number %s Part Description %s",sor_no,part_number,object_desc);
	
	path1 = ( char* ) MEM_alloc ( 200 * sizeof ( char ) ) ;
	path2 = ( char* ) MEM_alloc ( 200 * sizeof ( char ) ) ;
	n_found_qSOR_mail_shell = tm_check_info_control_object("QSOR_MAIL_SHELL_PATH", "PATH", path1, path2);
	if (n_found_qSOR_mail_shell < 0)
	{
		TC_write_syslog ( "\nQuick SOR \n shell path not found, check control object  syscd=QSOR_MAIL_SHELL_PATH and subsyscd=PATH" ) ;
		return 0;
	}

	//sprintf ( sor_cmd_to_execute, "/user/testcmi/Dev/devgroups/dbk/ITK_codes/mail_test/new_sor_mail.sh %s '%s'",sor_mbdy_fname,Mailsubject ) ;//cmitest
	//sprintf ( sor_cmd_to_execute, "/user/uaprodtrl/PLMSAP/liveXfr/new_sor_mail.sh %s '%s'",sor_mbdy_fname,Mailsubject ) ;//uaprodtrl
	sprintf ( sor_cmd_to_execute, "%s/new_sor_mail.sh %s '%s'",path1,sor_mbdy_fname,Mailsubject ) ;
	TC_write_syslog("\nsor_cmd_to_execute : [%s]", sor_cmd_to_execute ) ;
	printf("\nsor_cmd_to_execute : [%s]\n", sor_cmd_to_execute ) ;fflush(stdout);
	system( sor_cmd_to_execute );
	return 0;
}
int check_vertical ( char *quick_sor_no, tag_t *qsor_object ) 
{
	tag_t qSor_newsor_rel_type_t  = NULLTAG ;
	int new_sor_obj_c = 0 ;
	tag_t *new_sor_objects = NULLTAG ;
	int new_sor_c = 0 ;
	tag_t new_sor_t = NULLTAG ;
	char *t5_newsor_BulkBusinessUnit = NULL;
	FILE *fpbu = NULL;
	char *fname = NULL;
	int n_found_SOR_ProNext_info1 = 0;
	int EvPvFlag = -1;//sor can not transfer as no valid business unit selected it should be pv or ev
	char *qsor_no = NULL;
	char *qsor_revision_id = NULL;
	char *t5_newsor_BulkVertical = NULL;
	
	fname = ( char * ) MEM_alloc ( 200 * sizeof ( char ) );
	
	char* log_path = NULL;
	char* info2 = NULL;
	int n_vertical_log_path = 0;
	
	log_path = ( char * ) MEM_alloc ( 200 * sizeof ( char ) );
	info2 = ( char * ) MEM_alloc ( 200 * sizeof ( char ) );
	
	ITK_CALL ( AOM_ask_value_string(*qsor_object,"item_id",&qsor_no) );
	ITK_CALL ( AOM_ask_value_string(*qsor_object,"item_revision_id",&qsor_revision_id) );
	
	printf("\nqsor_no : [%s]",qsor_no);
	TC_write_syslog("\nqsor_no : [%s]",qsor_no);
	
	printf("\nqsor_revision_id : [%s]",qsor_revision_id);
	TC_write_syslog("\nqsor_revision_id : [%s]",qsor_revision_id);
	
	
	n_vertical_log_path = tm_check_info_control_object("QUICKSOR_LOG", "PRONEXT_TRNS", log_path, info2);

	if (n_vertical_log_path <= 0)
	{
		printf("\nlog PATH required");
		TC_write_syslog("\nlog PATH required");
		return 0;
	}
						
	sprintf (fname, "%s/%s_vertical_ev.txt",log_path,quick_sor_no) ;
	//sprintf (fname, "/tmp/%s_vertical.txt",quick_sor_no) ;
	fpbu = fopen ( fname,"w" );
	printf ( "\nfname : [%s]", fname ) ;
	TC_write_syslog ( "\nfname : [%s]", fname ) ;
	ITK_CALL ( GRM_find_relation_type ( "T5_Bulk_part_has_qSor" , &qSor_newsor_rel_type_t ) ) ;
	ITK_CALL ( GRM_list_primary_objects_only ( *qsor_object, qSor_newsor_rel_type_t, &new_sor_obj_c, &new_sor_objects ) ) ;//sor to pdf
	printf ( "\nnew_sor_obj_c : [%d]",new_sor_obj_c ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nnew_sor_obj_c : [%d]",new_sor_obj_c ) ;
	if (new_sor_obj_c > 0)
	{
		for ( new_sor_c = 0; new_sor_c < new_sor_obj_c ; new_sor_c++ )
		{
			new_sor_t	= new_sor_objects[new_sor_c];
			ITK_CALL ( AOM_ask_value_string ( new_sor_t,"t5_BulkBusinessUnit", &t5_newsor_BulkBusinessUnit ) );
			if ( tc_strcmp ( t5_newsor_BulkBusinessUnit, "PV") == 0 )
			{
				printf ( "\nPV" ) ; fflush ( stdout) ;
				TC_write_syslog ( "\nPV" ) ;
				fprintf ( fpbu, "\nPV");
				EvPvFlag = 0;//do not transfer qsor using this program use pv program
			}
			else if ( tc_strcmp ( t5_newsor_BulkBusinessUnit, "EV") == 0 )
			{
				printf ( "\nEV" ) ; fflush ( stdout) ;
				TC_write_syslog ( "\nEV" ) ;
				fprintf ( fpbu, "\nEV");
				EvPvFlag = 1;//transfering qsor ev
			}
			else
			{
				ITK_CALL ( AOM_ask_value_string ( new_sor_t,"t5_BulkVertical", &t5_newsor_BulkVertical ) );
				TC_write_syslog ( "\nt5_newsor_BulkVertical : [%s]\n",t5_newsor_BulkVertical ) ;
				fprintf ( fpbu, "\nt5_newsor_BulkVertical : [%s]\n",t5_newsor_BulkVertical);
				//t5_BulkVertical
				if ( tc_strcmp ( t5_newsor_BulkVertical, "TMPV" ) == 0 )//PV
				{
					EvPvFlag = 0;//do not transfer qsor using this program use pv program
				}
				if ( tc_strcmp ( t5_newsor_BulkVertical, "TPEM" ) == 0 )//EV
				{
					EvPvFlag = 1;//transfer qsor ev
				}
				else
				{
					EvPvFlag = -1;
				}
			}
		}
	}
	if ( fpbu != NULL )
	{
		fclose ( fpbu );
	}
	fpbu = NULL;
	//return 0;
	return EvPvFlag;
}
int Get_drw_path_cpy_drw(tag_t *part_tag, char *drw_orig_name)
{
	int iPart_drw_count = 0;
	tag_t *part_drw_t = NULLTAG;
	int iDrwCnter = 0;
	tag_t part_drw_rel_type_t = NULLTAG;
	tag_t drw_objTypeTag = NULLTAG;
	char *drw_type_name = NULL;
	int reference_number_found = 0;
	char *refname = NULL;
	AE_reference_type_t reftype;
	tag_t refobject = NULLTAG;
	char *drw_orig_name_local = NULL ;
	char *drw_path_name = NULL ;
	char *drw_file_path = NULL ;
	int ref_c = 0;
	char *path1 = NULL ;
	char *path2 = NULL ;
	int n_found_qSOR_drw_pdf_path = 0;
	char *command_drwing_cpy = NULL;
	
	
	path1 = (char*) MEM_alloc (200 * sizeof ( char ) ) ;
	path2 = (char*) MEM_alloc (200 * sizeof ( char ) ) ;
	drw_file_path = (char*) MEM_alloc (500 * sizeof ( char ) ) ;
	n_found_qSOR_drw_pdf_path = tm_check_info_control_object("QSOR_PDF_PATH", "PATH", path1, path2);
	if (n_found_qSOR_drw_pdf_path < 0)
	{
		TC_write_syslog ( "\nQuick SOR pdf path not found, check control object  syscd=QSOR_PDF_PATH and subsyscd=PATH" ) ;
		return 0;
	}
	
	ITK_CALL( GRM_find_relation_type("IMAN_Rendering" ,&part_drw_rel_type_t) );//own drawing
	ITK_CALL( GRM_list_secondary_objects_only(*part_tag,part_drw_rel_type_t,&iPart_drw_count,&part_drw_t) );
	printf ( "\niPart_drw_count IMAN_Rendering : [%d]", iPart_drw_count ) ;fflush(stdout);
	TC_write_syslog ( "\niPart_drw_count IMAN_Rendering : [%d]", iPart_drw_count ) ;fflush(stdout);
	if ( iPart_drw_count < 0)
	{
		ITK_CALL( GRM_find_relation_type("IMAN_reference" ,&part_drw_rel_type_t) );//reference drawing
		ITK_CALL( GRM_list_secondary_objects_only(*part_tag,part_drw_rel_type_t,&iPart_drw_count,&part_drw_t) );
		printf ( "\niPart_drw_count IMAN_reference : [%d]", iPart_drw_count ) ;fflush(stdout);
		TC_write_syslog ( "\niPart_drw_count IMAN_reference : [%d]", iPart_drw_count ) ;fflush(stdout);
	}
	
	for ( iDrwCnter = 0; iDrwCnter < iPart_drw_count; iDrwCnter++ )
	{
		ITK_CALL ( TCTYPE_ask_object_type ( part_drw_t[iDrwCnter], &drw_objTypeTag ) ) ;
		ITK_CALL ( TCTYPE_ask_name2 ( drw_objTypeTag, &drw_type_name ) );
		printf ( "\ndrw_type_name : [%s]", drw_type_name ) ;fflush(stdout);
		TC_write_syslog ( "\ndrw_type_name : [%s]", drw_type_name ) ;fflush(stdout);
		if ( tc_strcmp ( drw_type_name, "PDF" ) == 0 )
		{
			printf ( "\nFound PDF doc" ) ;fflush(stdout);
			TC_write_syslog ( "\nFound PDF doc" ) ;fflush(stdout);
			
			ITK_CALL ( AE_ask_dataset_ref_count ( part_drw_t[iDrwCnter], &reference_number_found ) );
			
			for ( ref_c = 0; ref_c < reference_number_found ; ref_c++)
			{	
				ITK_CALL ( AE_find_dataset_named_ref2 ( part_drw_t[iDrwCnter], ref_c, &refname, &reftype, &refobject ) );
				printf("\ndrawing refname : [%s]",refname); fflush(stdout);//PDF_Reference
				TC_write_syslog("\ndrawing refname : [%s]",refname); fflush(stdout);
				ITK_CALL ( IMF_ask_original_file_name2( refobject, &drw_orig_name_local ) );
				printf("\ndrw_orig_name_local : [%s]\n",drw_orig_name_local); fflush(stdout);
				TC_write_syslog("\ndrw_orig_name_local : [%s]\n",drw_orig_name_local); fflush(stdout);
				ITK_CALL ( IMF_ask_file_pathname2 (refobject, SS_UNIX_MACHINE, &drw_path_name) );
				printf("\ndrw_path_name : [%s]\n",drw_path_name); fflush(stdout);
				TC_write_syslog("\ndrw_path_name : [%s]\n",drw_path_name); fflush(stdout);
				
				tc_strcpy (  drw_orig_name, drw_orig_name_local );
				//drw_orig_name[tc_strlen(drw_orig_name_local)] = '\0';
				
				printf("\ndrw_orig_name : [%s]\n",drw_orig_name); fflush(stdout);
				TC_write_syslog("\ndrw_orig_name : [%s]\n",drw_orig_name); fflush(stdout);
				
				
				////tc_strcpy(file_path,"/home/uadev/devgroups/hps/");
				////sprintf(file_path,"/home/uadev/devgroups/hps/%s",orig_name);//need to provide path from control object
				sprintf(drw_file_path, "%s/%s", path1,drw_orig_name_local);//control object
				////sprintf(file_path,"/tmp/%s",orig_name);//kept for cmitest testing

				printf("\ndrw_file_path : [%s]\n",drw_file_path); fflush(stdout);
				TC_write_syslog("\ndrw_file_path : [%s]\n",drw_file_path); fflush(stdout);

				ITK_CALL ( IMF_export_file	(refobject, drw_file_path) );//exported file to Linux os from teamcenter
				
				printf("\ndrw_file_path exported to path : [%s]\n",drw_file_path); fflush(stdout);
				TC_write_syslog("\ndrw_file_path exported to path : [%s]\n",drw_file_path); fflush(stdout);
				
				
				//system command to copy file to pronext start
				command_drwing_cpy = ( char * ) MEM_alloc ( 600 * sizeof ( char ) ) ;
				printf("\n*file_path_drw : [%s]\n",drw_file_path); fflush(stdout);
				TC_write_syslog("\n*file_path_drw : [%s]\n",drw_file_path); fflush(stdout);//file_path_dvp

				sprintf(command_drwing_cpy,"scp %s sapmaster@172.22.99.133:/usr1/people/sapmaster/PLM_DATA/PROD/1691/PLM_RFQ",drw_file_path);

				printf("\n*command_drwing_cpy : [%s]\n",command_drwing_cpy); fflush(stdout);
				TC_write_syslog("\n*command_drwing_cpy : [%s]\n",command_drwing_cpy); fflush(stdout);
				
				if ( tc_strcmp (drw_file_path, "") == 0 )
				{
					printf("\ndrw file is blank hence skipping copy"); fflush(stdout);
					TC_write_syslog("\ndrw file is blank hence skipping copy"); fflush(stdout);
					
				}
				else
				{
					system( command_drwing_cpy );
				}
				//system command to copy file to pronext end

			}
			break;//on 1st PDF downlo and break;
		}
	
	}
	MEM_free ( path1 ) ;	path1 = NULL;
	MEM_free ( path2 ) ;	path2 = NULL;
	MEM_free ( drw_file_path ) ;	drw_file_path = NULL;
	MEM_free ( command_drwing_cpy ) ;	command_drwing_cpy = NULL;
	return 0;
}

int ITK_user_main(int argc, char *argv[])
{

	tag_t part_query_tag        = NULLTAG;
	tag_t *part_obj_t           = NULLTAG;
	tag_t Sor_tag          = NULLTAG;
	tag_t part_Sor_rel_type_t  = NULLTAG;
	tag_t Sor_pdf_rel_type_t  = NULLTAG;
	tag_t *part_Sor_t          = NULLTAG;
	tag_t part_tag          = NULLTAG;
	tag_t Tsak_t               = NULLTAG;
	tag_t Part_t               = NULLTAG;
	tag_t *table_rows          = NULLTAG;
	tag_t SOR_item_t           = NULLTAG;
	tag_t design_tsk_rel_type  = NULLTAG;
	tag_t *TskRevision         = NULLTAG;
	tag_t dml_tsk_rel_type     = NULLTAG;
	tag_t *ERCDmlRevision      = NULLTAG;
	tag_t ERC_DML_t            = NULLTAG;
	tag_t ERCDml_t            = NULLTAG;
	tag_t *Sor_pdf_t = NULLTAG; 
	tag_t PDF_Tag		   		= NULLTAG;

	//char refname[AE_reference_size_c + 1];
	char *refname = NULL;
	tag_t refobject = NULLTAG;
	AE_reference_type_t reftype;
	//char   orig_name[IMF_filename_size_c + 1] = { 0  } ;
	char   *orig_name = NULL;
	//char   orig_name_dvp[IMF_filename_size_c + 1] = { 0 } ;
	char   *orig_name_dvp = NULL ;
	//char   drw_orig_name_test[IMF_filename_size_c + 1] = { 0 } ;
	char   *drw_orig_name = NULL ;
	//char   path_name[SS_MAXPATHLEN];
	//char   path_name_dvp[SS_MAXPATHLEN];
	char   *path_name = NULL ;
	char   *path_name_dvp = NULL ;
	int ref_c = 0;
	int ref_dvp = 0;


	char *prtNo                = NULL;
	//char *entries[2]           = {"ID","Revision"};
	char *entries[2]           = {"Item ID","Revision"};
	char **values              = NULL;
	char *SOR_id               = NULL;
	char *qPPPMPrjCode        = NULL;
	char *SOR_Cre_date         = NULL;
	char *SOR_Category         = NULL;
	char *SOR_process_type     = NULL;
	char *SOR_commodity        = NULL;
	char *SOR_aq_lead          = NULL;
	char *SOR_Var              = NULL;
	char *SOR_AQEngg           = NULL;
	char *SOR_Pur_lead         = NULL;
	char *SOR_Pur_buyer        = NULL;
	char *SOR_Owner            = NULL;
	char *SOR_part_no          = NULL;
	char *Part_Desc            = NULL;
	char *Part_Rev             = NULL;
	char *Part_Ahd_MB          = NULL;
	char *Part_Pun_MB          = NULL;
	char *Part_Rel_status      = NULL;
	char *Part_DR_status       = NULL;
	char *Part_Spareind        = NULL;
	char *Part_SpareKit        = NULL;
	char *Part_TrackTrace      = NULL;
	char *Part_Item_id         = NULL;
	char *st5_VaraintId        = NULL;
	char *st5_VariantName	   = NULL;
	char *var                  = NULL;
	char *PartRevision         = NULL;
	char *PartSequence         = NULL;
	char *DwdMakeBuyp          = NULL;
	char *DwdMakeBuypD         = NULL;
	char *SORCreDate           = NULL;
	char *SORCreTime           = NULL;
	char *SORCreName           = NULL;
	char *SORCreID             = NULL;
	char *SORCreID1            = NULL;
	char *num                  = NULL;
	char *ReasonCode           = NULL;
	char *t5_CTECTS            = NULL;
	char *DMLPrjCode           = NULL;
	char *SORPPPMCode          = NULL;
	char *SORDesc              = NULL;
	char *SOR_DML_Barrel       = NULL;
	char *DwdMakeBuy           = NULL;
	char *commodity           = NULL;
	char *commodityp           = NULL;

	char *Part_Ahd_MBp = NULL;
	char *Part_Ahd_MBD = NULL;
	char *Part_Pun_MBp = NULL;
	char *Part_Pun_MBD = NULL;
	char *JsrMakeBuyp = NULL;
	char *JsrMakeBuypD = NULL;
	char *LkoMakeBuyp = NULL;
	char *LkoMakeBuypD = NULL;
	char *JsrMakeBuy = NULL;
	char *LkoMakeBuy = NULL;
	char *releaseStatus = NULL;
	char *month = NULL;
	char *SorRemark = NULL;

	char *prtRev = NULL;
	char *prtSeq = NULL;
	char *prtRevSeq = NULL;
	char *CreDate =NULL;
	char *CreMnt = NULL;
	char *CreYer = NULL;
	char *DateTime = NULL;
	int n_prt_count            = 0;
	int t                      = 0;
	int status                 = ITK_ok;
	int value_entries          = 2;
	int Part_sor_c             = 0;
	int i                      = 0;
	int j                      = 0;
	int ntablerows             = 0;
	//int st5_Quantity;
	char *st5_Quantity = NULL;
	int st5_Dom			       = 0;
	int st5_IB			       = 0;
	int Tskcount			   = 0;
	int Tskcount1			   = 0;

	char *qSorPartNumber = NULL;
	char *qSorPartRevision = NULL;
	char *qSorPartSeq = NULL;
	char *qSorPrtClrlnd = NULL;
	char *qSORPartDesc = NULL;
	char *qBarrelCode = NULL;
	char *qCtrlSorCat = NULL;

	//int month = 0;
	int sor_pdf_c = 0;
	int pdf_c = 0;
	int day = 0;
	int year = 0;
	int hour = 0;
	int minute = 0;
	int second = 0;
	char *SOR_Rel_status = NULL;
	char *file_path = NULL;
	char *file_path_dvp = NULL;
	char *SOR_item_revision_id = NULL;
	//char *SOR_sequence_id = NULL;
	int SOR_sequence_id = 0;
	int iCntr = 0 ;
	tag_t sor_obj_type_tag = NULLTAG;
	//char sor_type_name[TCTYPE_name_size_c+1] = "";
	char *sor_type_name = NULL;
	char *path1 = NULL;
	char *path2 = NULL;
	int n_found_qSOR_pdf_path = 0;
	int PvEvBu = -1;
	
	////////////////////////////////////////////////////////////////////////////////////////
//	int iPart_drw_count = 0;
//	tag_t *part_drw_t = NULLTAG;
//	int iDrwCnter = 0;
//	tag_t part_drw_rel_type_t = NULLTAG;
//	tag_t drw_objTypeTag = NULLTAG;
//	char *drw_type_name = NULL;
//	int reference_number_found = 0;
//	char *drw_refname = NULL;
//	AE_reference_type_t drw_reftype;
//	tag_t drw_refobject = NULLTAG;
//	char *drw_orig_name_local = NULL ;
//	char *drw_path_name = NULL ;
//	char *drw_file_path = NULL ;
//	int ref_drw_c = 0;
//	char *drw_path1 = NULL ;
//	char *drw_path2 = NULL ;
//	int n_found_qSOR_drw_pdf_path = 0;
//	char *command_drwing_cpy = NULL;
	
	
	
	////////////////////////////////////////////////////////////////////////////////////////
	
	

	month = MEM_alloc ( 50 ) ;
	DateTime = MEM_alloc ( 50 ) ;
	releaseStatus = MEM_alloc ( 50 ) ;

	//bool date_is_valid;
	date_t tcengDate;

	commodity = (char *)MEM_alloc(100);
	file_path = (char *)MEM_alloc(500);
	file_path_dvp = (char *)MEM_alloc(500);
	commodityp = (char *)MEM_alloc(100);
	prtRevSeq = (char *)MEM_alloc(10);
	SorRemark = (char *)MEM_alloc(100);

	tc_strcpy(SorRemark,"Shopping cart successfully created and released for ");



	ITK_CALL(  ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL( ITK_auto_login( ));

	if(ifail==0)
	{
		printf("\nLogin Successfully.................\n");
		TC_write_syslog("\nLogin Successfully.................\n");
	}
	ifail  = ITK_set_journalling(TRUE);
	prtNo  = ITK_ask_cli_argument("-i="); 
	prtRev = ITK_ask_cli_argument("-r="); 
	prtSeq = ITK_ask_cli_argument("-s="); 

	tc_strcpy(prtRevSeq,"");
	tc_strcpy(prtRevSeq,prtRev);
	tc_strcat(prtRevSeq,"*");
	tc_strcat(prtRevSeq,prtSeq);

	
	
	
	printf("\n Part No : %s\n",prtRevSeq);fflush(stdout);
	TC_write_syslog("\n Part No : %s\n",prtRevSeq);fflush(stdout);

	values = (char **) MEM_alloc(10 * sizeof(char *));
	var = (char *)MEM_alloc(1000*sizeof(char ));
	
	printf("\n*****************Starting here*************************\n");fflush(stdout);
	TC_write_syslog("\n*****************Starting here*************************\n");fflush(stdout);


	printf("\nQuering Part  : [%s]", prtNo );fflush(stdout);
	TC_write_syslog("\nQuering Part  : [%s]", prtNo );fflush(stdout);

	//ITK_CALL( QRY_find("Design Revision",&part_query_tag));
	ITK_CALL( QRY_find2("Item Revision...",&part_query_tag));

	if (part_query_tag)
	{
		printf("\nFound Query : Design Revision\n"); fflush(stdout);
		TC_write_syslog("\nFound Query : Design Revision\n"); fflush(stdout);
		

		values[0] = (char *)MEM_alloc( strlen( prtNo ) + 1);
		strcpy(values[0], prtNo  );

		values[1] = (char *)MEM_alloc( strlen( prtRevSeq ) + 1);
		strcpy(values[1], prtRevSeq  );

		printf("\nexecute Query : Design Revision\n"); fflush(stdout);
		TC_write_syslog("\nexecute Query : Design Revision\n"); fflush(stdout);

		ITK_CALL( QRY_execute(part_query_tag, value_entries, entries, values, &n_prt_count, &part_obj_t));
		printf("\nPrt Count : [%d]\n",n_prt_count); fflush(stdout);
		TC_write_syslog("\nPrt Count : [%d]\n",n_prt_count); fflush(stdout);

		part_tag = part_obj_t[0];
		
		if (part_tag != NULLTAG)
		{
			drw_orig_name = (char *)MEM_alloc(50 * sizeof ( char ) );
			//tc_strcpy ( drw_orig_name, "548180600102.pdf" ) ;
			//tc_strcpy ( drw_orig_name, "" ) ;
	
			Get_drw_path_cpy_drw ( &part_tag, drw_orig_name ) ;
			
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
//			drw_path1 = (char*) MEM_alloc (200 * sizeof ( char ) ) ;
//			drw_path2 = (char*) MEM_alloc (200 * sizeof ( char ) ) ;
//			drw_file_path = (char*) MEM_alloc (500 * sizeof ( char ) ) ;
//			n_found_qSOR_drw_pdf_path = tm_check_info_control_object("QSOR_PDF_PATH", "PATH", drw_path1, drw_path2);
//			if (n_found_qSOR_drw_pdf_path < 0)
//			{
//				TC_write_syslog ( "\nDRW Quick SOR pdf path not found, check control object  syscd=QSOR_PDF_PATH and subsyscd=PATH" ) ;
//				return 0;
//			}
//			
//			ITK_CALL( GRM_find_relation_type("IMAN_Rendering" ,&part_drw_rel_type_t) );//own drawing
//			ITK_CALL( GRM_list_secondary_objects_only(part_tag,part_drw_rel_type_t,&iPart_drw_count,&part_drw_t) );
//			printf ( "\niPart_drw_count IMAN_Rendering : [%d]", iPart_drw_count ) ;fflush(stdout);
//			TC_write_syslog ( "\niPart_drw_count IMAN_Rendering : [%d]", iPart_drw_count ) ;fflush(stdout);
//			if ( iPart_drw_count < 0)
//			{
//				ITK_CALL( GRM_find_relation_type("IMAN_reference" ,&part_drw_rel_type_t) );//reference drawing
//				ITK_CALL( GRM_list_secondary_objects_only(part_tag,part_drw_rel_type_t,&iPart_drw_count,&part_drw_t) );
//				printf ( "\niPart_drw_count IMAN_reference : [%d]", iPart_drw_count ) ;fflush(stdout);
//				TC_write_syslog ( "\niPart_drw_count IMAN_reference : [%d]", iPart_drw_count ) ;fflush(stdout);
//			}
//			
//			for ( iDrwCnter = 0; iDrwCnter < iPart_drw_count; iDrwCnter++ )
//			{
//				ITK_CALL ( TCTYPE_ask_object_type ( part_drw_t[iDrwCnter], &drw_objTypeTag ) ) ;
//				ITK_CALL ( TCTYPE_ask_name2 ( drw_objTypeTag, &drw_type_name ) );
//				printf ( "\ndrw_type_name : [%s]", drw_type_name ) ;fflush(stdout);
//				TC_write_syslog ( "\ndrw_type_name : [%s]", drw_type_name ) ;fflush(stdout);
//				if ( tc_strcmp ( drw_type_name, "PDF" ) == 0 )
//				{
//					printf ( "\nFound PDF doc" ) ;fflush(stdout);
//					TC_write_syslog ( "\nFound PDF doc" ) ;fflush(stdout);
//					
//					ITK_CALL ( AE_ask_dataset_ref_count ( part_drw_t[iDrwCnter], &reference_number_found ) );
//					
//					for ( ref_drw_c = 0; ref_drw_c < reference_number_found ; ref_drw_c++)
//					{	
//						ITK_CALL ( AE_find_dataset_named_ref2 ( part_drw_t[iDrwCnter], ref_drw_c, &drw_refname, &drw_reftype, &drw_refobject ) );
//						printf("\ndrawing drw_refname : [%s]",drw_refname); fflush(stdout);//PDF_Reference
//						TC_write_syslog("\ndrawing drw_refname : [%s]",drw_refname); fflush(stdout);
//						ITK_CALL ( IMF_ask_original_file_name2( drw_refobject, &drw_orig_name ) );
//						printf("\ndrw_orig_name : [%s]\n",drw_orig_name); fflush(stdout);
//						TC_write_syslog("\ndrw_orig_name : [%s]\n",drw_orig_name); fflush(stdout);
//						ITK_CALL ( IMF_ask_file_pathname2 (drw_refobject, SS_UNIX_MACHINE, &drw_path_name) );
//						printf("\ndrw_path_name : [%s]\n",drw_path_name); fflush(stdout);
//						TC_write_syslog("\ndrw_path_name : [%s]\n",drw_path_name); fflush(stdout);
//						
//						tc_strcpy (  drw_orig_name, drw_orig_name );
//						
//						printf("\ndrw_orig_name : [%s]\n",drw_orig_name); fflush(stdout);
//						TC_write_syslog("\ndrw_orig_name : [%s]\n",drw_orig_name); fflush(stdout);
//						
//						
//						sprintf(drw_file_path, "%s/%s", drw_path1,drw_orig_name);//control object
//						
//						printf("\ndrw_file_path : [%s]\n",drw_file_path); fflush(stdout);
//						TC_write_syslog("\ndrw_file_path : [%s]\n",drw_file_path); fflush(stdout);
//
//						ITK_CALL ( IMF_export_file	(drw_refobject, drw_file_path) );//exported file to Linux os from teamcenter
//						
//						printf("\ndrw_file_path exported to path : [%s]\n",drw_file_path); fflush(stdout);
//						TC_write_syslog("\ndrw_file_path exported to path : [%s]\n",drw_file_path); fflush(stdout);
//						
//						
//						command_drwing_cpy = ( char * ) MEM_alloc ( 600 * sizeof ( char ) ) ;
//						printf("\n*file_path_drw : [%s]\n",drw_file_path); fflush(stdout);
//						TC_write_syslog("\n*file_path_drw : [%s]\n",drw_file_path); fflush(stdout);//file_path_dvp
//
//						sprintf(command_drwing_cpy,"scp %s sapmaster@172.22.99.133:/usr1/people/sapmaster/PLM_DATA/PROD/1691/PLM_RFQ",drw_file_path);
//
//						printf("\n*command_drwing_cpy : [%s]\n",command_drwing_cpy); fflush(stdout);
//						TC_write_syslog("\n*command_drwing_cpy : [%s]\n",command_drwing_cpy); fflush(stdout);
//						
//						if ( tc_strcmp (drw_file_path, "") == 0 )
//						{
//							printf("\ndrw file is blank hence skipping copy"); fflush(stdout);
//							TC_write_syslog("\ndrw file is blank hence skipping copy"); fflush(stdout);
//							
//						}
//						else
//						{
//							system( command_drwing_cpy );
//						}
//						
//
//					}
//					break;
//				}
//			
//			}
			
			
			
			
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
			//tc_strcpy(drw_orig_name_test, drw_orig_name ) ;
			
			//drw_orig_name[tc_strlen(drw_orig_name)] = '\0';
			
			printf("\ndrw_orig_name : [%s]",drw_orig_name);fflush(stdout);
			TC_write_syslog("\ndrw_orig_name : [%s]",drw_orig_name);fflush(stdout);

			//return 0;
		
			ITK_CALL( AOM_UIF_ask_value(part_tag, "object_desc" ,&Part_Desc));
			printf("\nPart_Desc : [%s]\n",Part_Desc); fflush(stdout);
			TC_write_syslog("\nPart_Desc : [%s]\n",Part_Desc); fflush(stdout);
		
			ITK_CALL( AOM_UIF_ask_value(part_tag, "item_revision_id" ,&Part_Rev));
			printf("\nPart_Rev : [%s]\n",Part_Rev); fflush(stdout);
			TC_write_syslog("\nPart_Rev : [%s]\n",Part_Rev); fflush(stdout);
		
			
		
			ITK_CALL( GRM_find_relation_type("T5_PartSorRel" ,&part_Sor_rel_type_t));
			ITK_CALL( GRM_list_secondary_objects_only(part_tag,part_Sor_rel_type_t,&Part_sor_c,&part_Sor_t));//sor to part
			
			printf("\nPart_sor_c : [%d]",Part_sor_c);fflush(stdout);
			TC_write_syslog("\nPart_sor_c : [%d]",Part_sor_c);fflush(stdout);
		
			
			if (Part_sor_c <= 0 )
			{
				printf("\nsor count : [%d] attached to part [%s]",Part_sor_c,Part_Item_id);fflush(stdout);
				TC_write_syslog("\nsor count : [%d] attached to part [%s]",Part_sor_c,Part_Item_id);fflush(stdout);
				return 0;
			}
			for ( iCntr = 0 ; iCntr < Part_sor_c; iCntr++ )
			{
				
				Sor_tag = part_Sor_t[iCntr];
		
				ITK_CALL(TCTYPE_ask_object_type(Sor_tag, &sor_obj_type_tag));
		
				ITK_CALL(TCTYPE_ask_name2(sor_obj_type_tag, &sor_type_name));
		
				printf("\n**********************sor_type_name : [%s] **********************\n",sor_type_name); fflush(stdout);
				TC_write_syslog("\n**********************sor_type_name : [%s] **********************\n",sor_type_name); fflush(stdout);
		
				if ( tc_strcmp(sor_type_name,"T5_quicksorRevision" ) == 0 )
				{
		
					ITK_CALL( AOM_UIF_ask_value(Sor_tag, "item_id" ,&SOR_id));
					printf("\nQSOR_id : [%s]\n",SOR_id); fflush(stdout);
					TC_write_syslog("\nQSOR_id : [%s]\n",SOR_id); fflush(stdout);
					
					//PvEvBu = check_vertical ( SOR_id, &Sor_tag ) ; 
					//if ( PvEvBu !=  1 )
					//{
					//	printf ( "\nnot Valid Bu value to transfer EV SOR [%d] ( information PV = 0 EV = 1 INVALID BU = -1 )" ,PvEvBu ) ; fflush ( stdout) ;
					//	TC_write_syslog ( "\nnot Valid Bu value to transfer EV SOR [%d] ( information PV = 0 EV = 1 INVALID BU = -1 ) " ,PvEvBu ) ; fflush ( stdout) ;
					//	return 0;
					//}	
					//EV = 1 hence use this program to transfer
					
					
					ITK_CALL( AOM_ask_value_string(Sor_tag, "t5_qSorPartNumber" ,&qSorPartNumber));
					printf("\nqSorPartNumber  : [%s]\n",qSorPartNumber); fflush(stdout);
					TC_write_syslog("\nqSorPartNumber  : [%s]\n",qSorPartNumber); fflush(stdout);
		
					ITK_CALL( AOM_ask_value_string(Sor_tag, "t5_qSorPartRevision" ,&qSorPartRevision));
					printf("\nqSorPartRevision  : [%d]\n",qSorPartRevision); fflush(stdout);
					TC_write_syslog("\nqSorPartRevision  : [%d]\n",qSorPartRevision); fflush(stdout);
					
					
					ITK_CALL( AOM_UIF_ask_value(Sor_tag, "t5_qSorPartSeq" ,&qSorPartSeq));
					printf("\nqSorPartSeq  : [%s]\n",qSorPartSeq); fflush(stdout);
					TC_write_syslog("\nqSorPartSeq  : [%s]\n",qSorPartSeq); fflush(stdout);
		
					ITK_CALL( AOM_UIF_ask_value(Sor_tag, "t5_qSorPrtClrInd" ,&qSorPrtClrlnd));
					printf("\nqSorPrtClrlnd  : [%s]\n",qSorPrtClrlnd); fflush(stdout);
					TC_write_syslog("\nqSorPrtClrlnd  : [%s]\n",qSorPrtClrlnd); fflush(stdout);
		
		
					ITK_CALL( AOM_UIF_ask_value(Sor_tag, "t5_qSORPartDesc" ,&qSORPartDesc));
					printf("\nqSORPartDesc  : [%s]\n",qSORPartDesc); fflush(stdout);
					TC_write_syslog("\nqSORPartDesc  : [%s]\n",qSORPartDesc); fflush(stdout);
		
		
					ITK_CALL( AOM_UIF_ask_value(Sor_tag, "t5_qBarrelCode" ,&qBarrelCode));
					printf("\nproject code  : [%s]\n",qBarrelCode); fflush(stdout);
					TC_write_syslog("\nproject code  : [%s]\n",qBarrelCode); fflush(stdout);
		
		
					ITK_CALL( AOM_UIF_ask_value(Sor_tag, "t5_qCtrlSorCat" ,&qCtrlSorCat));
					printf("\nqCtrlSorCat  : [%s]\n",qCtrlSorCat); fflush(stdout);
					TC_write_syslog("\nqCtrlSorCat  : [%s]\n",qCtrlSorCat); fflush(stdout);
		
					
					ITK_CALL( AOM_UIF_ask_value(Sor_tag, "t5_qPPPMPrjCode" ,&qPPPMPrjCode));
					printf("\nqPPPMPrjCode  : [%s]\n",qPPPMPrjCode); fflush(stdout);
					TC_write_syslog("\nqPPPMPrjCode  : [%s]\n",qPPPMPrjCode); fflush(stdout);
		
					ITK_CALL( AOM_UIF_ask_value(Sor_tag, "release_status_list" ,&SOR_Rel_status));
					printf("\nSOR_Rel_status  : [%s]\n",SOR_Rel_status); fflush(stdout);
					TC_write_syslog("\nSOR_Rel_status  : [%s]\n",SOR_Rel_status); fflush(stdout);
		
		
		
					
					if ( tc_strstr ( qPPPMPrjCode, "$$" ) != NULL )
					{
						SORPPPMCode = strtok(qPPPMPrjCode, "$$");
						SORDesc = strtok(NULL, "$$");
					}
					else
					{
						SORPPPMCode = MEM_alloc ( 100 ) ;
						SORDesc = MEM_alloc ( 100 ) ;
						tc_strcpy ( SORPPPMCode, qPPPMPrjCode ) ;
						tc_strcpy ( SORDesc, "" ) ;
					}
					
					printf("\nqPPPMPrjCode  : [%s]\n",SORPPPMCode); fflush(stdout);
					TC_write_syslog("\nqPPPMPrjCode  : [%s]\n",SORPPPMCode); fflush(stdout);
		
					
		
					//pdf path

					path1 = (char*)MEM_alloc(200 * sizeof(char));
					path2 = (char*)MEM_alloc(200 * sizeof(char));
					n_found_qSOR_pdf_path = tm_check_info_control_object("QSOR_PDF_PATH", "PATH", path1, path2);
					if (n_found_qSOR_pdf_path < 0)
					{
						TC_write_syslog ( "\nQuick SOR pdf path not found, check control object  syscd=QSOR_PDF_PATH and subsyscd=PATH" ) ;
						return 0;
					}

					tc_strcpy ( orig_name, "" ) ;
					tc_strcpy ( orig_name_dvp, "" ) ;
					
							
	
					ITK_CALL( GRM_find_relation_type("IMAN_Specification" ,&Sor_pdf_rel_type_t) );
					ITK_CALL( GRM_list_secondary_objects_only(Sor_tag,Sor_pdf_rel_type_t,&sor_pdf_c,&Sor_pdf_t));//sor to pdf
		
					if (sor_pdf_c > 0)
					{
		
						for(pdf_c = 0; pdf_c < sor_pdf_c ; pdf_c++ )
						{
							PDF_Tag	= Sor_pdf_t[pdf_c];
							char *datasettype_PDF_name = NULL;
							char *datasettype_PDF_type = NULL;
		
							//ITK_CALL( AOM_UIF_ask_value (PDF_Tag,"object_type",&datasettype_PDF_type));
							
							tag_t PDF_objTypeTag = NULLTAG;
							ITK_CALL ( TCTYPE_ask_object_type ( PDF_Tag, &PDF_objTypeTag ) ) ;
							ITK_CALL ( TCTYPE_ask_name2 ( PDF_objTypeTag, &datasettype_PDF_type ) );
							
							printf("\ndatasettype_PDF_type  : [%s]",datasettype_PDF_type); fflush(stdout);
							TC_write_syslog("\ndatasettype_PDF_type  : [%s]",datasettype_PDF_type); fflush(stdout);
							
		
							if ( tc_strcmp(datasettype_PDF_type,"PDF")!=0 )
							{
								printf("\t...skipping not valid doc type"); fflush(stdout);
								TC_write_syslog("\t...skipping not valid doc type"); fflush(stdout);
								continue;
							}
							
							//ITK_CALL( AOM_UIF_ask_value (PDF_Tag,"object_name",&datasettype_PDF_name));
							ITK_CALL( AOM_ask_value_string (PDF_Tag,"object_name",&datasettype_PDF_name));
							//ITK_CALL( AOM_ask_name (PDF_Tag, &datasettype_PDF_name));
		
							printf("\ndatasettype_PDF_name  : [%s]\n",datasettype_PDF_name); fflush(stdout);
							TC_write_syslog("\ndatasettype_PDF_name  : [%s]\n",datasettype_PDF_name); fflush(stdout);
						
							
							//download RFQ PDF
							if(tc_strcmp(datasettype_PDF_type,"PDF")==0 && tc_strstr(datasettype_PDF_name,"RFQ")!=NULL )
							{
								int referencenumberfound = 0;
								ITK_CALL( AE_ask_dataset_ref_count(PDF_Tag,&referencenumberfound));
		
								printf("\nreferencenumberfound  : [%d]\n",referencenumberfound); fflush(stdout);
								TC_write_syslog("\nreferencenumberfound  : [%d]\n",referencenumberfound); fflush(stdout);
							
								if (referencenumberfound > 0)
								{
		
									for (ref_c = 0; ref_c < referencenumberfound ; ref_c++)
									{
										//ITK_CALL( AE_find_dataset_named_ref(PDF_Tag,ref_c,refname,&reftype,&refobject));
										ITK_CALL( AE_find_dataset_named_ref2(PDF_Tag,ref_c,&refname,&reftype,&refobject));
										printf("\nrefname  : [%s]\n",refname); fflush(stdout);
										TC_write_syslog("\nrefname  : [%s]\n",refname); fflush(stdout);
										//ifail = IMF_ask_original_file_name(refobject,orig_name);
										ITK_CALL( IMF_ask_original_file_name2(refobject,&orig_name));
										printf("\norig_name  : [%s]\n",orig_name); fflush(stdout);
										TC_write_syslog("\norig_name  : [%s]\n",orig_name); fflush(stdout);
										//ITK_CALL( IMF_ask_file_pathname(refobject,SS_UNIX_MACHINE,path_name));
										ITK_CALL( IMF_ask_file_pathname2(refobject,SS_UNIX_MACHINE,&path_name));
										printf("\npath_name  : [%s]\n",path_name); fflush(stdout);
										TC_write_syslog("\npath_name  : [%s]\n",path_name); fflush(stdout);
										
										//tc_strcpy(file_path,"/home/uadev/devgroups/hps/");
										//sprintf(file_path,"/home/uadev/devgroups/hps/%s",orig_name);//need to provide path from control object
										sprintf(file_path,"%s/%s",path1,orig_name);//control object
										//sprintf(file_path,"/tmp/%s",orig_name);//kept for cmitest testing

										printf("\nfile_path  : [%s]\n",file_path); fflush(stdout);
										TC_write_syslog("\nfile_path  : [%s]\n",file_path); fflush(stdout);

										ITK_CALL( IMF_export_file ( refobject, file_path ) );
		
									}
								}
							}//RFQ
							
							
							//download DVP PDF
							if(tc_strcmp(datasettype_PDF_type,"PDF")==0 && tc_strstr(datasettype_PDF_name,"DVP")!=NULL )
							{
								int referencenumberfound_dvp = 0;
								ITK_CALL( AE_ask_dataset_ref_count(PDF_Tag,&referencenumberfound_dvp));
		
								printf("\nreferencenumberfound_dvp  : [%d]\n",referencenumberfound_dvp); fflush(stdout);
								TC_write_syslog("\nreferencenumberfound_dvp  : [%d]\n",referencenumberfound_dvp); fflush(stdout);
							
								if (referencenumberfound_dvp > 0)
								{
		
									for (ref_dvp = 0; ref_dvp < referencenumberfound_dvp ; ref_dvp++)
									{
										//ITK_CALL( AE_find_dataset_named_ref(PDF_Tag,ref_dvp,refname,&reftype,&refobject));
										ITK_CALL( AE_find_dataset_named_ref2(PDF_Tag,ref_dvp,&refname,&reftype,&refobject));
										printf("\nrefname  : [%s]\n",refname); fflush(stdout);
										TC_write_syslog("\nrefname  : [%s]\n",refname); fflush(stdout);
										//ifail = IMF_ask_original_file_name(refobject,orig_name_dvp);
										ITK_CALL(IMF_ask_original_file_name2(refobject,&orig_name_dvp));
										printf("\norig_name_dvp  : [%s]\n",orig_name_dvp); fflush(stdout);
										TC_write_syslog("\norig_name_dvp  : [%s]\n",orig_name_dvp); fflush(stdout);
										//ITK_CALL(IMF_ask_file_pathname(refobject,SS_UNIX_MACHINE,path_name_dvp));
										ITK_CALL(IMF_ask_file_pathname2(refobject,SS_UNIX_MACHINE,&path_name_dvp));
										printf("\npath_name_dvp  : [%s]\n",path_name_dvp); fflush(stdout);
										TC_write_syslog("\npath_name_dvp  : [%s]\n",path_name_dvp); fflush(stdout);
										
										//tc_strcpy(file_path_dvp,"/home/uadev/devgroups/hps/");
										//sprintf(file_path_dvp,"/home/uadev/devgroups/hps/%s",orig_name_dvp);//need to provide path from control object
										sprintf(file_path_dvp,"%s/%s",path1,orig_name_dvp);//control object
										//sprintf(file_path_dvp,"/tmp/%s",orig_name_dvp);//kept for cmitest testing

										printf("\nfile_path_dvp  : [%s]\n",file_path_dvp); fflush(stdout);
										TC_write_syslog("\nfile_path_dvp  : [%s]\n",file_path_dvp); fflush(stdout);

										ITK_CALL(IMF_export_file (refobject,file_path_dvp));
		
									}
								}
							}//RFQ
						}
					}
					
					ITK_CALL( AOM_UIF_ask_value(Sor_tag, "creation_date" ,&SOR_Cre_date));
					printf("\nSOR_Cre_date : [%s]",SOR_Cre_date); fflush(stdout);
					TC_write_syslog("\nSOR_Cre_date : [%s]",SOR_Cre_date); fflush(stdout);
					
					
					if ( tc_strstr ( SOR_Cre_date, " " ) != NULL )
					{
						SORCreDate = strtok(SOR_Cre_date, " ");
						SORCreTime = strtok(NULL, " ");
					}
					else
					{
						SORCreDate = MEM_alloc ( 10 ) ;
						SORCreTime = MEM_alloc ( 10 ) ;
						tc_strcpy ( SORCreDate, SOR_Cre_date ) ;
						tc_strcpy ( SORCreTime, "" ) ;
					}
					
					printf("\nSOR_Cre_date_1 : [%s]",SORCreDate); fflush(stdout);
					TC_write_syslog("\nSOR_Cre_date_1 : [%s]",SORCreDate); fflush(stdout);
					
					
					tc_strcat ( SORCreTime, ":00" ) ;
					
					printf("\nSORCreTime_1 : [%s]",SORCreTime); fflush(stdout);
					TC_write_syslog("\nSORCreTime_1 : [%s]",SORCreTime); fflush(stdout);
					
					if ( tc_strstr ( SORCreDate, "-" ) != NULL )
					{
						CreDate = strtok(SORCreDate, "-");
						CreMnt = strtok(NULL, "-");
						CreYer = strtok(NULL, "-");
					}
					else
					{
						CreDate = MEM_alloc ( 10 ) ;
						CreMnt = MEM_alloc ( 10 ) ;
						CreYer = MEM_alloc ( 10 ) ;
						tc_strcpy ( CreDate, SORCreDate ) ;
						tc_strcpy ( CreMnt, "" ) ;
					}
					printf("\nCre_date_1 : [%s]",CreDate); fflush(stdout);
					TC_write_syslog("\nCre_date_1 : [%s]",CreDate); fflush(stdout);
					printf("\nCreMnt_1 : [%s]",CreMnt); fflush(stdout);
					TC_write_syslog("\nCreMnt_1 : [%s]",CreMnt); fflush(stdout);
					printf("\nCreYer_1 : [%s]",CreYer); fflush(stdout);
					TC_write_syslog("\nCreYer_1 : [%s]",CreYer); fflush(stdout);
					
					if (tc_strcmp(CreMnt, "Jan") == 0)
					{
						month = "01";
					}
					else if (tc_strcmp(CreMnt, "Feb") == 0)
					{
						month = "02";
					}
					else if (tc_strcmp(CreMnt, "Mar") == 0)
					{
						month = "03";
					}
					else if (tc_strcmp(CreMnt, "Apr") == 0)
					{
						month = "04";
					}
					else if (tc_strcmp(CreMnt, "May") == 0)
					{
						month = "05";
					}
					else if (tc_strcmp(CreMnt, "Jun") == 0)
					{
						month = "06";
					}
					else if (tc_strcmp(CreMnt, "Jul") == 0)
					{
						month = "07";
					}
					else if (tc_strcmp(CreMnt, "Aug") == 0)
					{
						month = "08";
					}
					else if (tc_strcmp(CreMnt, "Sep") == 0)
					{
						month = "09";
					}
					else if (tc_strcmp(CreMnt, "Oct") == 0)
					{
						month = "10";
					}
					else if (tc_strcmp(CreMnt, "Nov") == 0)
					{
						month = "11";
					}
					else 
					{
						month = "12";
					}
					
					
					tc_strcpy ( DateTime, "" ) ;
					tc_strcat ( DateTime, CreDate) ;
					tc_strcat ( DateTime, "-") ;
					tc_strcat ( DateTime, CreMnt) ;
					tc_strcat ( DateTime, "-") ;
					tc_strcat ( DateTime, CreYer) ;

					
					
					printf("\nFinal Date  : [%s]\n",DateTime); fflush(stdout);
					TC_write_syslog("\nFinal Date  : [%s]\n",DateTime); fflush(stdout);
					
					
					
							
					ITK_CALL( AOM_ask_table_rows(Sor_tag, "t5_qSORVar", &ntablerows, &table_rows));
					printf("\ncount : %d",ntablerows);fflush(stdout);
					TC_write_syslog("\ncount : %d",ntablerows);fflush(stdout);
					
					tc_strcpy(var,"");
					
					for (i=0; i<ntablerows; i++)
					{
					
						ITK_CALL( AOM_ask_value_string(table_rows[i],"t5_qVariantId",&st5_VaraintId));
						ITK_CALL( AOM_ask_value_string(table_rows[i],"t5_qVariant_Name",&st5_VariantName));
						ITK_CALL( AOM_UIF_ask_value(table_rows[i],"t5_qQuantity",&st5_Quantity));
					
						printf("\nt5_VaraintId : [%s]",st5_VaraintId); fflush(stdout);
						TC_write_syslog("\nt5_VaraintId : [%s]",st5_VaraintId); fflush(stdout);
						printf("\nt5_VariantName : [%s]",st5_VariantName); fflush(stdout);
						TC_write_syslog("\nt5_VariantName : [%s]",st5_VariantName); fflush(stdout);
						printf("\nt5_Quantity : [%s]",st5_Quantity); fflush(stdout);
						TC_write_syslog("\nt5_Quantity : [%s]",st5_Quantity); fflush(stdout);
					
						tc_strcat(var, st5_VaraintId);
						tc_strcat(var, ":");
						tc_strcat(var, st5_Quantity);
						tc_strcat(var,";");

						/*if (i < (ntablerows-1))
						{
							tc_strcat(var,";");
						}*/
						
					
					}
					printf("\nVariant : [%s]\n",var); fflush(stdout);
					TC_write_syslog("\nVariant : [%s]\n",var); fflush(stdout);
					
					
						
					
					ITK_CALL( AOM_UIF_ask_value(Sor_tag, "owning_user" ,&SOR_Owner));
					
					
						
					if ( tc_strstr ( SOR_Owner, "(" ) != NULL )
					{
						SORCreName = strtok(SOR_Owner, "(");
						SORCreID = strtok(NULL, "(");
						if (tc_strstr ( SORCreID, ")" ) != NULL)
						{
							SORCreID1 = strtok(SORCreID, ")");
						}
					}
					else
					{
						SORCreName = MEM_alloc ( 10 ) ;
						SORCreID = MEM_alloc ( 10 ) ;
						tc_strcpy ( SORCreName, "" ) ;
						tc_strcpy ( SORCreID, SOR_Owner ) ;
					}
					printf("\nSOR_Owner : [%s]\n",SORCreID1); fflush(stdout);
					TC_write_syslog("\nSOR_Owner : [%s]\n",SORCreID1); fflush(stdout);
					
					
				}
		
			}
		
			
		
		}
		else
		{
		
		   printf("\n*********************************SOR Not Found************************************ \n"); fflush(stdout);
		   TC_write_syslog("\n*********************************SOR Not Found************************************ \n"); fflush(stdout);
		
		}
		

		printf("\nMain Function EVRequest->part_USCOREno : %s",qSorPartNumber); fflush(stdout);
		printf("\nMain Function EVRequest->pppm_USCOREcode : %s",qPPPMPrjCode); fflush(stdout);
		printf("\nMain Function EVRequest->part_USCOREdesc : %s",qSORPartDesc); fflush(stdout);
		printf("\nMain Function EVRequest->revision : %s",qSorPartRevision); fflush(stdout);
		printf("\nMain Function EVRequest->sequence : %s",qSorPartSeq); fflush(stdout);
		printf("\nMain Function EVRequest->auto_USCOREsor_USCOREno : %s",SOR_id); fflush(stdout);
		printf("\nMain Function EVRequest->sor_USCOREdt : %s",DateTime); fflush(stdout);
		printf("\nMain Function EVRequest->sor_USCOREcategory : %s",qCtrlSorCat); fflush(stdout);
		printf("\nMain Function EVRequest->variant_USCOREcode : %s",var); fflush(stdout);
		printf("\nMain Function EVRequest->colorble :%s",qSorPrtClrlnd); fflush(stdout);
		printf("\nMain Function EVRequest->rfq_USCOREpath : [%s]",orig_name); fflush(stdout);
		printf("\nMain Function EVRequest->sor_USCOREowner : %s",SORCreID1); fflush(stdout);
		printf("\nMain Function EVRequest->dvp_USCOREpath : [%s]",orig_name_dvp); fflush(stdout);
		printf("\nMain Function EVRequest->drawing_path : [%s]",drw_orig_name); fflush(stdout);


		TC_write_syslog("\nMain Function EVRequest->part_USCOREno : %s",qSorPartNumber); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->pppm_USCOREcode : %s",qPPPMPrjCode); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->part_USCOREdesc : %s",qSORPartDesc); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->revision : %s",qSorPartRevision); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->sequence : %s",qSorPartSeq); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->auto_USCOREsor_USCOREno : %s",SOR_id); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->sor_USCOREdt : %s",DateTime); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->sor_USCOREcategory : %s",qCtrlSorCat); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->variant_USCOREcode : %s",var); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->colorble : %s",qSorPrtClrlnd); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->rfq_USCOREpath : %s",orig_name); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->sor_USCOREowner : %s",SORCreID1); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->dvp_USCOREpath : %s",orig_name_dvp); fflush(stdout);
		TC_write_syslog("\nMain Function EVRequest->drawing_path : %s",drw_orig_name); fflush(stdout);


		if (tc_strcmp(SOR_Rel_status,"ERC Released")==0)
		{
			char *command = NULL;
			command = ( char * ) MEM_alloc ( 500 * sizeof ( char ) ) ;
			printf("\n***************Transferring Quick SOR to pronext***************************\n"); fflush(stdout);
			TC_write_syslog("\n***************Transferring Quick SOR to pronext***************************\n"); fflush(stdout);

			//rfq scp
			printf("\n*file_path : [%s]\n",file_path); fflush(stdout);
			TC_write_syslog("\n*file_path : [%s]\n",file_path); fflush(stdout);//

			sprintf(command,"scp %s sapmaster@172.22.99.133:/usr1/people/sapmaster/PLM_DATA/PROD/1691/PLM_RFQ",file_path);

			printf("\n*command : [%s]\n",command); fflush(stdout);
			TC_write_syslog("\n*command : [%s]\n",command); fflush(stdout);

			if ( tc_strcmp (file_path, "") == 0 )
			{
				printf("\nrfq file is blank hence skipping copy"); fflush(stdout);
				TC_write_syslog("\nrfq file is blank hence skipping copy"); fflush(stdout);
			}
			else
			{
				system( command );
			}
			
			//dvp scp

			char *command_dvp = NULL;
			command_dvp = ( char * ) MEM_alloc ( 500 * sizeof ( char ) ) ;
			printf("\n*file_path_dvp : [%s]\n",file_path_dvp); fflush(stdout);
			TC_write_syslog("\n*file_path_dvp : [%s]\n",file_path_dvp); fflush(stdout);//file_path_dvp

			sprintf(command_dvp,"scp %s sapmaster@172.22.99.133:/usr1/people/sapmaster/PLM_DATA/PROD/1691/PLM_RFQ",file_path_dvp);

			printf("\n*command_dvp : [%s]\n",command_dvp); fflush(stdout);
			TC_write_syslog("\n*command_dvp : [%s]\n",command_dvp); fflush(stdout);
			
			if ( tc_strcmp (file_path_dvp, "") == 0 )
			{
				printf("\ndvp file is blank hence skipping copy"); fflush(stdout);
				TC_write_syslog("\ndvp file is blank hence skipping copy"); fflush(stdout);
				
			}
			else
			{
				system( command_dvp );
			}

			//file copy done


			char *response_ev = NULL; 
			response_ev = (char*)MEM_alloc(3000); 
			//response_ev = (char *)Create_SOR_ProNext_Frm_WS_EV(qSorPartNumber,qPPPMPrjCode,qSORPartDesc,qSorPartRevision,qSorPartSeq,SOR_id,DateTime,qCtrlSorCat,st5_VaraintId,qSorPrtClrlnd,orig_name,SORCreID1,orig_name_dvp) ;
			response_ev = (char *)Create_SOR_ProNext_Frm_WS_EV(qSorPartNumber,qPPPMPrjCode,qSORPartDesc,qSorPartRevision,qSorPartSeq,SOR_id,DateTime,qCtrlSorCat,var,qSorPrtClrlnd,orig_name,SORCreID1,orig_name_dvp,drw_orig_name) ;
			printf("\nwebservice response : [%s]",response_ev);fflush(stdout);
			TC_write_syslog("\nwebservice response : [%s]",response_ev);fflush(stdout);
			
			//Added below logic to recieved response on SOR Remark filed.
//Response: This api is only for CAT 1,2,3,4a,4b,5,6,7,8 SOR parts::SUCCESS:::Part Updated in sor table and master table: SOR_546880559914_NR!@!SUCCESS:::Updated Part Inserted in Logs Table for SOR:SOR_546880559914_NR!@!SUCCESS:::Updated Part Inserted in History Table for SOR:SOR_546880559914_NR


			//if (tc_strstr(response_ev, "This api is only for CAT 1,2,3,4a,4b,5,6,7,8 SOR parts::SUCCESS" ) != NULL )
			//{
			//	char *SorRemark = NULL;
			//	tag_t partnotag = NULLTAG;
			//	tag_t partrevtag = NULLTAG;
			//
			//	SorRemark = (char *)MEM_alloc(100);
			//
			//	tc_strcpy(SorRemark,"sor_master - updated, sor_logs - inserted, sor_history - inserted,");
			//	printf("\nPart transfer to pronext");fflush(stdout);
			//
			//	if(ITEM_find_item(qSorPartNumber,&partnotag)!=ITK_ok);
			//	if (partnotag)
			//	{
			//		printf("\n2.partnotag found"); fflush(stdout);
			//	}
			//	if(ITEM_ask_latest_rev(partnotag,&partrevtag)!=ITK_ok);
			//	if(partrevtag != NULLTAG)
			//	{
			//		printf("\n 2.partrevtag found"); fflush(stdout);
			//	}
			//	else
			//	{
			//		printf("\n 2.partrevtag not found"); fflush(stdout);
			//	}
			//
			//	AOM_lock(partrevtag);
			//
			//	ITK_CALL(AOM_set_value_string(partrevtag,"t5_qsorRemark",SorRemark));
			//
			//	AOM_save_without_extensions(partrevtag);
			//
			//	ITK_CALL(AOM_refresh(partrevtag, TRUE));
			//
			//}
			
			//tm_querysor_html ( SOR_id ) ;

			printf("mail sent %s",SOR_id);fflush(stdout);
			TC_write_syslog("mail sent %s",SOR_id);
			
		}
		else
		{
			printf("\n***************QSOR is not ERC Released ***************************\n"); fflush(stdout);
			TC_write_syslog("\n***************QSOR is not ERC Released ***************************\n"); fflush(stdout);
		}
					
	}
		MEM_free( drw_orig_name );
		drw_orig_name = NULL;
		printf("\n*************************END***************************\n");
		TC_write_syslog("\n*************************END***************************\n");

		return status;
}

