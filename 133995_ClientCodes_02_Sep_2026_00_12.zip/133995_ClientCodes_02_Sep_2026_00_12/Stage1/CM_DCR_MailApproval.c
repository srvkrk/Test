/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Shivkumar Birnale
*  Module               :   Workflow Action Handler to create DML Print Report and attach to DML as MSWord dataset
*  Code                 :   CM_DCR_MailApproval.c
*  Created on			:   March 22nd, 2018
* Modification History :
* S.No    Date         CR No     Modified By            Modification Notes
*  01	   19.4.22		-			Prasad				Uploaded Data from Bhaskar Folder to DV
***************************************************************************/

#include "TMLLibrary_server_exits.h"

/*
	Action Handler		:		CM_DCR_MailApproval
	Description			:		This handler fire the shell to send the mail for DCR approval at VLD
*/
int CM_DCR_MailApproval(EPM_action_message_t msg)
{
	int i=0;
	int j=0;
	int status=ITK_ok;
	int attachmentCount=0, transfermodeCnt=0;

	char *obj_type=NULL;
	char *dmlNumber=NULL;
	char *emailID=NULL;
	char *revId=NULL;
	tag_t	objTag			=NULLTAG;
	tag_t	objTypTag			=NULLTAG;

	//char mainFile[50];
	char command[512];
	char docFile[50];
	int participant_count	= 0;
	tag_t rootTask_t=NULLTAG;
	tag_t msWordType=NULLTAG;
	tag_t person_tag=NULLTAG;
	tag_t wordDataset=NULLTAG;
	tag_t wordLatestDat_t=NULLTAG;
	tag_t specRelationType_t=NULLTAG;
	tag_t specificationRel_t=NULLTAG;
	tag_t PLMSession=NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t	Patricipant_Type	= NULLTAG;
	char   ObjTyp[TCTYPE_name_size_c+1];
	tag_t *transfermodes=NULLTAG;
	tag_t	*participant_list	= NULLTAG;

	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	EPM_get_participanttype ("T5_DcrVEH_LINE_DIR",&Patricipant_Type);

	if(attachmentCount>0)
	{
		printf("\n CM_DCR_MailApproval: Root Task Count is [%d]\n",attachmentCount);fflush(stdout);
		for(j=0;j<attachmentCount;j++)
		{
			objTag=taskAttachments[j];
			if(TCTYPE_ask_object_type(objTag,&objTypTag));
			if(TCTYPE_ask_name(objTypTag,ObjTyp));
			printf("\n CM_DCR_MailApproval: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

			//if(AOM_ask_value_string(objTag,"item_id",&DCR)!=ITK_ok)PrintErrorStack();
			//printf("\n DCR OBJ ID: [%s].", DCR);fflush(stdout);

			//CALLAPI(GRM_find_relation_type("HasParticipant", &DCR_Particpant_rel_type));
			//CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &DCR_rel_type));

			if ((tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0))
			{
				printf("\n CM_DCR_MailApproval: DCR Revision obj Found.\n");fflush(stdout);
				ITEM_rev_ask_participants(objTag,Patricipant_Type,&participant_count,&participant_list);
				printf("\n Number Of participant_count==>[%d]",participant_count);fflush(stdout);
				ITK_CALL(GRM_find_relation_type("IMAN_specification",&specRelationType_t));

				ITK_CALL(AOM_ask_value_string(objTag,"item_id",&dmlNumber));
				ITK_CALL(AOM_ask_value_string(objTag,"item_revision_id",&revId));

				for(i=0;i<participant_count;i++)
				{
					//ITK_CALL(WSOM_ask_object_type2(participant_list[0],&obj_type));
					TC_write_syslog("Object Type = %s\n",obj_type);
					//if(tc_strcasecmp(obj_type,"ChangeRequestRevision")==0)
					//{
					
					ITK_CALL(AOM_ask_value_string(participant_list[i],"fnd0AssigneeEmail",&emailID));
					//ITK_CALL(SA_ask_user_person(participant_list[0],&person_tag));
					//ITK_CALL(SA_ask_person_email_address(person_tag,&emailID));

					//tc_strcpy(mainFile,"");
					//tc_strcat(mainFile,"/tmp/");
					//tc_strcat(mainFile,dmlNumber);
					//tc_strcat(mainFile,"_");
					//tc_strcat(mainFile,revId);
					//tc_strcat(mainFile,".xml");
					//TC_write_syslog("Main File = %s\n",mainFile);

					//tc_strcpy(docFile,"");
					//tc_strcat(docFile,"/tmp/dmlprint_report_");
					//tc_strcat(docFile,dmlNumber);
					//tc_strcat(docFile,"_");
					//tc_strcat(docFile,revId);
					//tc_strcat(docFile,".doc");
					//TC_write_syslog("Doc File = %s\n",docFile);

					//ITK_CALL(PIE_create_session(&PLMSession));
					//ITK_CALL(PIE_session_set_file(PLMSession,mainFile));
					//ITK_CALL(PIE_find_transfer_mode2("T5_DML_Print_Report_TM","DEFAULT_PIE_CONTEXT_STRING",&transfermodeCnt,&transfermodes));
					//TC_write_syslog("No of TrasnferModes = %d\n",transfermodeCnt);
					//ITK_CALL(PIE_session_set_transfer_mode(PLMSession,transfermodes[0]));
					//ITK_CALL(PIE_session_export_objects(PLMSession,1,&taskAttachments[i]));
					//sprintf(command,"java -classpath /home/uadev/TC_ROOT/bin/tml_tools/xalan.jar org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadev/TC_ROOT/bin/tml_tools/DML_print_report_template.xsl >/tmp/wfout.log",mainFile,dmlNumber);
					sprintf(command,"/user/uaprod/TC_ROOT12/bin/tml_tools/DCR_approval_Mail.sh %s %s",dmlNumber,emailID);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					//if(access(docFile,F_OK)!=-1)
					//{
						//TC_write_syslog("Doc file created successfully\n");
						//ITK_CALL(AE_find_datasettype2("MSWord",&msWordType));
						//if(msWordType == NULLTAG)
						//{
							//TC_write_syslog("Could not find Dataset Type MSWord. Please check data model\n");
							//continue;
						//}
						//ITK_CALL(AE_create_dataset_with_id(msWordType,dmlNumber,"DML Print Report for DML","","",&wordDataset));
						//ITK_CALL(AE_save_myself(wordDataset));
						//ITK_CALL(GRM_create_relation(taskAttachments[i],wordDataset,specRelationType_t,NULLTAG,&specificationRel_t));
						//ITK_CALL(AOM_load(specificationRel_t));
						//ITK_CALL(GRM_save_relation(specificationRel_t));
						//ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
						//ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
						//ITK_CALL(AE_import_named_ref(wordLatestDat_t,"word",docFile,NULL,SS_BINARY));
						//ITK_CALL(AE_save_myself(wordLatestDat_t));
						//remove(docFile);
						//}		}
				}	
			}
		}
	}

	return status;
}
