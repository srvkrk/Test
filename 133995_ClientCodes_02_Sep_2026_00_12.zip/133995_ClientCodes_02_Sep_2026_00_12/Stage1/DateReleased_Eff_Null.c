/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Ketan Bhut
*  Module		 :   Clear Released Date and Effectivity on Part
*  Code			 :   DateReleased_Eff_Null.c
*  Created on	 :   June 26, 2023
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/libtccore_exports.h>

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;


static int remove_effectivity(tag_t wso_tag)
{
	int     ifail               = ITK_ok;
	int status = 0 ;

    int n_statuses = 0;
	int ii=0;
    tag_t *statuses  = NULL;
	char *existing_status = NULL;

    ifail = WSOM_ask_release_status_list(wso_tag, &n_statuses , &statuses);
    if (ifail != ITK_ok) { /* your error logic here */ }
    
    for(ii = 0; ii < n_statuses; ii++)
    {
        
        ifail = RELSTAT_ask_release_status_type(statuses[ii], &existing_status);
		printf("\n Ketan existing_status %s \n",existing_status);fflush(stdout);
        if (ifail != ITK_ok) { /* your error logic here */ }
        
        if(strcmp(existing_status, "T5_MBOMReleased") == 0)
		{
			printf("\n Inside Remove effectivity \n");fflush(stdout);
			ifail = AOM_refresh(statuses[ii], TRUE);

			WSOM_status_clear_effectivities(statuses[ii]);
			
			ifail = AOM_save(statuses[ii]);
			ifail = AOM_refresh(statuses[ii], FALSE);

			ifail = AOM_unload(statuses[ii]);  
		}
        
    }
    if(statuses) MEM_free(statuses);    

	return ifail;
}


static int modify_date_released(tag_t wso_tag, char *new_date_released)
{
	int     ifail  = ITK_ok;
	int		status = 0 ;
    
    date_t set_date;
    ITK_CALL(ITK_string_to_date(new_date_released, &set_date));
    
    tag_t attr_tag = NULLTAG;
    ITK_CALL(POM_attr_id_of_attr("date_released", "ItemRevision", &attr_tag)); 
    
    ITK_CALL(POM_refresh_instances_any_class(1, &wso_tag, POM_modify_lock));
    ITK_CALL(POM_set_attr_date(1, &wso_tag, attr_tag, set_date));  
    ITK_CALL(POM_save_instances(1, &wso_tag, true));

	return ifail;
}


/*******MAIN FUNCTION************/

extern int ITK_user_main (int argc, char ** argv )
{
	char*	inputuser			= NULL;
	char*	inputpwd			= NULL;
	char*	inputgrp			= NULL;
	char*	inputDML			= NULL;
	char*	inputDate			= NULL;
	char*	Task_item_id		= NULL;
	char*	Part_no				= NULL;
	char*	parttype			= NULL;
	char*	type_name1			= NULL;
	char*	PartTypeStr			= NULL;
	char*	cPart_date_released	= NULL;
	char*	tsk_object_name		= NULL ;

	date_t Part_date_released;
	
	int     ifail               = ITK_ok;
	int		index				= 0;
	int		status;
	int		count				= 0;
	int		TaskCnt				= 0;
	int		PartCnt				= 0;
	int		k					= 0;

	tag_t	DMLNo					= NULLTAG;
	tag_t	DMLrev					= NULLTAG;
	tag_t*	PartTags				= NULLTAG;
	tag_t	tsk_part_sol_rel_type	= NULLTAG;
	tag_t	AssyTag					= NULLTAG;
	tag_t	objTypeTag				= NULLTAG;
	tag_t	relation_type			= NULLTAG;
	tag_t*	TaskRevision			= NULLTAG;
	tag_t	TaskRevTag				= NULLTAG;

	inputDML	   = ITK_ask_cli_argument("-dml=");
	inputDate	   = ITK_ask_cli_argument("-date=");

	printf("\n Test 1 \n");fflush(stdout);

	//ITK_CALL( ITK_init_module("infodba","APLinfo2020","dba"));	// for tcuaadev
	ITK_CALL( ITK_init_module("loader","loader123","dba"));	// for production
	

	printf("\n Test 2 \n");fflush(stdout);
	ITK_CALL(ITEM_find_item(inputDML,&DMLNo));
	
	ITK_CALL(ITEM_ask_latest_rev(DMLNo,&DMLrev));

	printf("\n Updating date Released in DML  \n");fflush(stdout);
	ITK_CALL(modify_date_released(DMLrev,inputDate));
			 
	AOM_refresh(DMLrev, FALSE);

	if (DMLrev != NULLTAG)
	{
		GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
						
		ITK_CALL(GRM_list_secondary_objects_only(DMLrev,relation_type,&count,&TaskRevision));

		printf("\n DML to Task Count : %d \n",count);fflush(stdout);

		for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
		{
			TaskRevTag = TaskRevision[TaskCnt];

			ITK_CALL(AOM_ask_value_string(TaskRevTag,"item_id",&tsk_object_name));
			PartCnt=0;
			ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags));
			printf("\n [%d] Task ==> [%s] and Number of parts ==>[%d] \n",TaskCnt+1,tsk_object_name,PartCnt);fflush(stdout);

			if (PartCnt>0)
			{
				GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
				for (k=0;k<PartCnt ;k++ )
				{
					printf("\n Task for k =:%d\n",k);fflush(stdout);
					AssyTag=PartTags[k];
			
					ITK_CALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
					printf("\n Part_no is :%s\n",Part_no);	fflush(stdout);
			
					ITK_CALL(AOM_ask_value_string(AssyTag,"t5_PartType",&parttype));
					printf("\n Parttype  is :%s\n",parttype);	fflush(stdout);
			
					if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
					if(TCTYPE_ask_name2(objTypeTag,&type_name1));
					printf("\n  AssyTag type_name1 := %s\n", type_name1);fflush(stdout);
			
					ITK_CALL(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
					printf("\n  AssyTag PartTypeStr := %s\n", PartTypeStr);fflush(stdout);
			
					ITK_CALL(AOM_ask_value_date(AssyTag,"date_released",&Part_date_released));
					ITK_date_to_string(Part_date_released, &cPart_date_released);
					printf("\n  Before cPart_date_released := %s\n", cPart_date_released);fflush(stdout);
					
			 		printf("\n Function modify_date_released calling for AssyTag \n");fflush(stdout);
			 		ITK_CALL(modify_date_released(AssyTag,inputDate));
			 
			 		AOM_refresh(AssyTag, FALSE);
			 
			 		ITK_CALL(AOM_ask_value_date(AssyTag,"date_released",&Part_date_released));
			 		ITK_date_to_string(Part_date_released, &cPart_date_released);
			 		printf("\n  After cPart_date_released := %s\n", cPart_date_released);fflush(stdout);
			 		
			 		printf("\n Function remove_effectivity calling for AssyTag \n");fflush(stdout);
			 		ITK_CALL(remove_effectivity(AssyTag));
					
					
				}
			}
		}
	}

	//ITK_CALL(AOM_ask_value_tags(DMLrev,"CMHasSolutionItem",&PartCnt,&PartTags));
	//printf("\n Part count => %d",PartCnt);fflush(stdout);
	//
	//if (PartCnt>0)
	//{
	//	GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
	//	for (k=0;k<PartCnt ;k++ )
	//	{
	//		printf("\n Task for k =:%d\n",k);fflush(stdout);
	//		AssyTag=PartTags[k];
	//
	//		ITK_CALL(AOM_ask_value_string(AssyTag,"item_id",&Part_no));
	//		printf("\n Part_no is :%s\n",Part_no);	fflush(stdout);
	//
	//		ITK_CALL(AOM_ask_value_string(AssyTag,"t5_PartType",&parttype));
	//		printf("\n Parttype  is :%s\n",parttype);	fflush(stdout);
	//
	//		if(TCTYPE_ask_object_type(AssyTag,&objTypeTag));
	//		if(TCTYPE_ask_name2(objTypeTag,&type_name1));
	//		printf("\n  AssyTag type_name1 := %s\n", type_name1);fflush(stdout);
	//
	//		ITK_CALL(AOM_ask_value_string(AssyTag,"object_type",&PartTypeStr));
	//		printf("\n  AssyTag PartTypeStr := %s\n", PartTypeStr);fflush(stdout);
	//
	//		ITK_CALL(AOM_ask_value_date(AssyTag,"date_released",&Part_date_released));
	//		ITK_date_to_string(Part_date_released, &cPart_date_released);
	//		printf("\n  Before cPart_date_released := %s\n", cPart_date_released);fflush(stdout);
	//		
	// 		printf("\n Function calling Test 1  \n");fflush(stdout);
	// 		ITK_CALL(modify_date_released(DMLrev,inputDate));
	// 
	// 		AOM_refresh(DMLrev, FALSE);
	// 
	// 		ITK_CALL(AOM_ask_value_date(DMLrev,"date_released",&Part_date_released));
	// 		ITK_date_to_string(Part_date_released, &cPart_date_released);
	// 		printf("\n  After cPart_date_released := %s\n", cPart_date_released);fflush(stdout);
	// 		
	// 		printf("\n Function calling Test 2  \n");fflush(stdout);
	// 		ITK_CALL(remove_effectivity(AssyTag));
	//		
	//		
	//	}
	//}


	printf("----------- END -----------------------------------------\n");fflush(stdout);

return status;
   
}
 
