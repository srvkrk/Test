/*
./compile MIS_VC_DateWise_Rep.c
./linkitk -o MIS_VC_DateWise_Rep MIS_VC_DateWise_Rep.o
scp MIS_VC_DateWise_Rep tkr06466@172.22.97.12:/user/plmsap/PLMSAP/tkr/clientcode/MIS_VC_DateWise_Rep
nohup ./MIS_VC_DateWise_Rep -u=tkr06466 -p=XYT1ESA -fromdate="01-Mar-2022" -todate="20-Mar-2022" -type='M' >1.log &
*/
#define TE_MAXLINELEN  128

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include <unidefs.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <cfm/cfm.h>
//#include <propdesc/propdesc.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <stdarg.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_date.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
//#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <time.h>
#include <sa/am.h>
#include<tc/tc_startup.h>
#define Debug TRUE
#define ITK_err 910001

FILE * fsuccess;
FILE* fp=NULL;
char fsuccess_name[200];
FILE* file=NULL;
char fsuccess_nam[200];
FILE* fptr=NULL;
char fsuccess_na[200];

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

char* userId = NULL;
char* usernameDir = NULL;

char group;
FILE *fsuccess,*ferror1;
char cComma[14]={",,,,,,,,,,,,"};
char SiamFile[100]={0};
char ferror_name[200] = {0};
int	cmvrFlag	= 0;
char *inputDML=NULL;

char *ColorIDPart = NULL;
char *ColorIDPartDup = NULL;
char *UrnCode = NULL;

char *st5Pollutant_CM1 = NULL;
char *CMUnit = NULL;
char *st5Pollutant_HC1 = NULL;
char *HCUnit = NULL;
char *st5Pollutant_NH1 = NULL;
char *NMHCUnit = NULL;
char *st5Pollutant_RHC1 = NULL;
char *RHCUnit = NULL;
char *st5Pollutant_NO1 = NULL;
char *NOUnit = NULL;
char *st5Pollutant_HCNO1 = NULL;
char *HCNOUnit = NULL;
char *st5Pollutant_PM1 = NULL;
char *PMUnit = NULL;
char *st5Pollutant_HO1 = NULL;
char *st5BystanderPos = NULL;

char *st5Pollutant_CM1Dup = NULL;
char *CMUnitDup = NULL;
char *st5Pollutant_HC1Dup = NULL;
char *HCUnitDup = NULL;
char *st5Pollutant_NH1Dup = NULL;
char *NMHCUnitDup = NULL;
char *st5Pollutant_RHC1Dup = NULL;
char *RHCUnitDup = NULL;
char *st5Pollutant_NO1Dup = NULL;
char *NOUnitDup = NULL;
char *st5Pollutant_HCNO1Dup = NULL;
char *HCNOUnitDup = NULL;
char *st5Pollutant_PM1Dup = NULL;
char *PMUnitDup = NULL;
char *st5Pollutant_HO1Dup = NULL;
char *st5BystanderPosDup = NULL;

char *st5Pollutant_CM1Dup1 = NULL;
char *st5Pollutant_HC1Dup1 = NULL;
char *st5Pollutant_NH1Dup1 = NULL;
char *st5Pollutant_RHC1Dup1 = NULL;
char *st5Pollutant_NO1Dup1 = NULL;
char *st5Pollutant_HCNO1Dup1 = NULL;
char *st5Pollutant_PM1Dup1 = NULL;

char *AmoniaUnit			= NULL;
char *AmoniaUnitDup		= NULL;
char *MethaneUnit			= NULL;
char *MethaneUnitDup		= NULL;
char *ParticleUnit		= NULL;
char *ParticleUnitDup		= NULL;

char *t5Pol_Amonia1		= NULL;
char *t5Pol_Amonia1Dup1	= NULL;
char *t5Pol_Methane1		= NULL;
char *t5Pol_Methane1Dup1	= NULL;
char *t5Pol_Particle1		= NULL;
char *t5Pol_Particle1Dup1	= NULL;

char *t5Pol_Amonia1Dup	= NULL;
char *t5Pol_Methane1Dup	= NULL;
char *t5Pol_Particle1Dup	= NULL;

char *BBBACNUM			= NULL;
char *BBBACNUMDup		= NULL;
char *BBBACISDT		= NULL;
char *BBBACISDTDup		= NULL;
char *BBBACVLDT		= NULL;
char *BBBACVLDTDup		= NULL;
char *VBCAPRCNUM		= NULL;
char *VBCAPRCNUMDup	= NULL;
char *VBCAPRDT			= NULL;
char *VBCAPRDTDup		= NULL;

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		//printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			//printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %s",len,text,str);fflush(stdout);
  return;
}

struct VCAttrDetails
{
	char VCAttrID[500];
	char VCAttrName[500]; //car
	char VCAttrNameValue[500];
};
struct BomChldStrut
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
}*get_BomChldStrut;

void Multi_Get_Part_BOM_Lvl(tag_t inputPart,int reqLevel,int level,tag_t revRule,struct BomChldStrut BomChldStrut[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	//printf("\n Inside Multi_Get_Part_BOM_Lvl[%d] ...\n",*StructChldCnt);

	ITKCALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	//printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITKCALL(BOM_create_window (&window));
	ITKCALL(BOM_set_window_config_rule(window,revRule));

	BOM_set_window_top_line(window, null_tag,inputPart ,null_tag, &top_line);
	ITKCALL(BOM_line_ask_child_lines (top_line, &n, &children));
	//printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

	level = level + 1;
	for (k = 0; k < n; k++)
	{
		BOM_line_unpack (children[k]);
		// TCTYPE_ask_property_by_name (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
		// AOM_ask_value_tag(children[k], iChildItemTag, &t_ChildItemRev);
		if(t_ChildItemRev!=NULLTAG)
		{
			AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName);
			*StructChldCnt	=	*StructChldCnt+1;
			BomChldStrut[*StructChldCnt].child_objs = t_ChildItemRev;
			BomChldStrut[*StructChldCnt].child_objs_bvr=children[k];
			BomChldStrut[*StructChldCnt].child_objs_lvl=level;

			Multi_Get_Part_BOM_Lvl(t_ChildItemRev,reqLevel,level,revRule,BomChldStrut,StructChldCnt);
		}
	}
	level = level - 1;

	MEM_free (childrenTag);

	CLEANUP:
		 printf("\n Inside Multi_Get_Part_BOM_Lvl CLEANUP");fflush(stdout);
}
int Get_Part_BOM_Lvl(tag_t VehicleObj,int reqLevel,char*  revRuleName,struct BomChldStrut BomChldStrut[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1	= 0;
	int n	= 0;
	int 	n_values_bvr = 0;
	tag_t *bvr_assy_part	= NULLTAG;
	tag_t bvr_tag			= NULLTAG;
	int level 				= 0;
	tag_t	window 			= NULLTAG;
	tag_t	top_line		= NULLTAG;
	tag_t	objChild		= NULLTAG;
	tag_t	objChild_bvr	= NULLTAG;
	int child_lvl			= 0;
	char	*c_Qty			=	NULL;
	tag_t  *children1		= NULLTAG;
	int iChildItemTag		= 0;
	int assbvr				= 0;
	int bvrfound			= 0;
	int flagRevRule			= 0;
	int flagClosureRule		= 0;
	char *view_name			= NULL;
	char* partTok			= NULL;
	char* viewTok			= NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;

	//printf("\nInside Get_Part_BOM_Lvl ....\n");

	if(VehicleObj == NULLTAG)
	{
		//printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	ITKCALL(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	//printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	//printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	//printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	//printf("\nBefore level==>%d\n",level);fflush(stdout);
	//printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	//printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);

	ITKCALL(CFM_find(revRuleName, &revRule));
	if (revRule != NULLTAG)
	{
		//printf("\nFind revRule\n");fflush(stdout);
		flagRevRule=1;
	}

	scope=PIE_TEAMCENTER;

	//printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
	//printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
	if(flagRevRule==1)
	{

		Multi_Get_Part_BOM_Lvl(VehicleObj,reqLevel,level,revRule,BomChldStrut,StructChldCnt);
	}
	else
	{
		printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
	}

	//printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	for (j=1;j<= *StructChldCnt;j++ )
	{
		objChild		= NULLTAG;
		objChild_bvr	= NULLTAG;
		c_Qty			= NULL;
		child_lvl       = 0;

		//printf("\nPrint Item ID==>%d\n",j);fflush(stdout);

		objChild=BomChldStrut[j].child_objs;
		objChild_bvr=BomChldStrut[j].child_objs_bvr;
		child_lvl=BomChldStrut[j].child_objs_lvl;

		AOM_ask_value_string(objChild,"item_id",&ItemName);
		//printf("\nItemName==>%s\n",ItemName);fflush(stdout);

		//printf("\nchild_lvl==>%d\n",child_lvl);fflush(stdout);

		AOM_ask_value_string(objChild_bvr,"bl_quantity",&c_Qty);
		//printf("\nQty==>%s\n",c_Qty);fflush(stdout);
	}
	return ifail;
}
void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

int tm_ebom_mbom_rpt(tag_t VObjTag,char ***SetModulePart,int *icount)
{
	int		ifail 				=   ITK_ok;
	char	*tasknumber			=	NULL;
	char	*type_name			=	NULL;
	char	*type_nameP			=	NULL;
	char	*type_name2			=	NULL;
	char	*tsk_object_name	=	NULL;
	char	*ClrSVROnly			=	NULL;
	char	*tmpSVR				=	NULL;
	char	*nonClrSvr			=	NULL;
	char	*clrSlr				=	NULL;
	char	*qry_entries3[1]	= {"Name"};
	char	*qry_entries10[1]	= {"ID"};
	char	*itemid;
	char	*svrName			=	NULL;
	char	*t5_SchmPlant		=	NULL;
	char	*t5_ClSrl			=	NULL;
	char	*arch_item_id		=	NULL;
	char	*arch_item_idrev	=	NULL;
	char	*Archtype_name		=	NULL;
	char	**rulename			=	NULL;
	char	**rulevalue			=	NULL;
	char	*item_Rev_Seq		=	NULL;
	char	*StagePartNo		=	NULL;
	char	*Stage_item_Rev_Seq	=	NULL;
	char	*StagePartType		=	NULL;
	char	*ModPartNo			=	NULL;
	char	*ModPartType		=	NULL;
	char	*ModPartLine		=	NULL;
	char	*ModItem_Rev		=	NULL;
	char	*ModItem_Seq		=	NULL;
	char	*ChildColInd		=	NULL;
	char	*Item_ID_str		=	NULL;
	char	*ModPartAct			=	NULL;

	char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
	char	**valuesPlatfrom = (char **) MEM_alloc(1 * sizeof(char *));

	date_t  eff_date;

	tag_t	objTypeTag			=	NULLTAG;
	tag_t	ItemTypeTag			=	NULLTAG;
	tag_t	*PartTags			=	NULLTAG;
	tag_t	t_svr				=	NULLTAG;
	tag_t	ClrVariqueryTag		=	NULLTAG;
	tag_t	*ColVRule_tags		=	NULLTAG;
	tag_t	*t5_clrscm			=	NULLTAG;
	tag_t	PlatformTag			=	NULLTAG;
	tag_t	*tags_found			=	NULLTAG;
	tag_t	item_tag			=	NULLTAG;
	tag_t	PlatformTypeTag		=	NULLTAG;
	tag_t	PlatformRevTag		=	NULLTAG;
	tag_t	PlatformRevTypeTag	=	NULLTAG;
	tag_t   e_block				=	NULLTAG;
	tag_t	*lines2				=	NULLTAG;
	tag_t	*lines3				=	NULLTAG;
	tag_t	PartChildobj		=	NULLTAG;
	tag_t	StageChildobj		=	NULLTAG;
	tag_t   t_ChildItemRev		=	NULLTAG;


	int		PartCnt			=	0;
	int		n_entriesV		=	1;
	int		n_entriesP		=	1;
	int		n_tags_found	=	0;
	int		n_count			=	0;
	int		ClrCnt = 0;
	int		iSVR = 0;
	int		count_clrscm	=	0;
	int		rulefound		=	0;
	int		count			=	0;
	int		ichld			=	0;
	int		n_lines2		=	0;
	int		n_lines3		=	0;
	int		iMod			=	0;
	int		iMod1			=	0;
	int		NonClrPartlevel =	0;
	int		iChildItemTag	=   0;
	int		Revformula;
	const char *qry_entries[1];
	const char *qry_values[1];
	struct	BomChldStrut ChldStrutBdySh[5000];

	tag_t	*itemclass			=	NULLTAG;
	tag_t	item				=	NULLTAG;
	tag_t	tsk_HSI_rel_type	=	NULLTAG;
	tag_t	t5_appl_SVR			=	NULLTAG;
	tag_t	item_rev_tag		=	NULLTAG;
	tag_t	bom_wnd				=	NULLTAG;
	tag_t	rule				=	NULLTAG;
	tag_t	*closurerule		=	NULLTAG;
	tag_t	close_tag			=	NULLTAG;
	tag_t   bom_variant_rule	=	NULLTAG;
	tag_t  	objTypeTag1			=	NULLTAG;
	tag_t	top_lne				=	NULLTAG;
	tag_t	*ArchNodeLines		=	NULLTAG;
	tag_t	VarientRuletag		=	NULLTAG;
	tag_t	*ColIndChilds		=	NULLTAG;
	tag_t	Childobject			=	NULLTAG;
	char   *taskowning_groupVal =	NULL;

	//printf("\nInSide tm_ebom_mbom_rpt");fflush(stdout);

	char *VPrtNum=NULL;
	char *VPrtType=NULL;

	ITK_CALL(AOM_ask_value_string(VObjTag,"item_id",&VPrtNum));
	ITK_CALL(AOM_ask_value_string(VObjTag,"item_revision_id",&VPrtType));

	//printf("\n Platform name------> %s\n",VPrtNum);fflush(stdout);
	//printf("\n Platform name------> %s\n",VPrtType);fflush(stdout);
	if(VObjTag!=NULLTAG)
	{
		ITKCALL(BOM_create_window(&bom_wnd ));
		ITKCALL(CFM_find("ERC release and above", &rule));
		//printf ("\nrule count %d \n",rulefound);fflush(stdout);

		ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE));
		ITKCALL(BOM_set_window_top_line( bom_wnd, NULLTAG, VObjTag, NULLTAG, &top_lne ));

		if(top_lne!=NULLTAG)
		{
			ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
			//printf("\n n_count --------> : %d\n", n_count);
			ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
			//printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node

			if (count >0)
			{
				for (ichld=0;ichld<count ;ichld++ )
				{
					//if(Childobject) Childobject=NULLTAG;
					Childobject=ColIndChilds[ichld];

					ITKCALL(AOM_ask_value_string(Childobject, "bl_item_item_id", &arch_item_id ));
					//printf("\n arch_item_id ..:%s\n",arch_item_id); fflush(stdout);
					ITKCALL(AOM_ask_value_string(Childobject, "bl_rev_item_revision_id", &arch_item_idrev ));
					//printf("\n arch_item_idrev ..:%s\n",arch_item_idrev); fflush(stdout);
					char*	 arch_item_ModAdd    			= NULL;
					ITKCALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_ModuleAddress",&arch_item_ModAdd));
					//printf("\n arch_item_idrev ..:%s\n",arch_item_ModAdd); fflush(stdout);

					if((tc_strcmp(arch_item_ModAdd,"MC1D01")==0) || (tc_strcmp(arch_item_ModAdd,"MC2A01")==0)|| (tc_strcmp(arch_item_ModAdd,"MC3Z01")==0)|| (tc_strcmp(arch_item_ModAdd,"MP1A01")==0)|| (tc_strcmp(arch_item_ModAdd,"MP1N01")==0)|| (tc_strcmp(arch_item_ModAdd,"MP3A01")==0)|| (tc_strcmp(arch_item_ModAdd,"MC1D02")==0)|| (tc_strcmp(arch_item_ModAdd,"MP1L01")==0))
					{
						ModPartAct	=	(char	*)MEM_alloc(300);
						tc_strcpy(ModPartAct,arch_item_id);
						tc_strcat(ModPartAct,"/");
						tc_strcat(ModPartAct,arch_item_idrev);

						//printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
						setAddStr(icount,SetModulePart,ModPartAct);
					}
						//Find the ERC and explode and find PB part.
					if(lines2) lines2=NULL;

					ITKCALL(BOM_line_ask_child_lines(Childobject, &n_lines2, &lines2));
					//printf("\n Child parts count--> %d\n",n_lines2);fflush(stdout);

					if(n_lines2 > 0)
					{
						for (iMod=0;iMod<n_lines2 ;iMod++ )
						{
							if(PartChildobj) PartChildobj=NULLTAG;
							if(ModPartNo) ModPartNo=NULL;
							if(item_Rev_Seq) item_Rev_Seq=NULL;
							if(ModPartType) ModPartType=NULL;
							if(ModPartLine) ModPartLine=NULL;
							if(taskowning_groupVal) taskowning_groupVal=NULL;
							PartChildobj=lines2[iMod];

							ITKCALL(AOM_ask_value_string(PartChildobj, "bl_item_item_id", &ModPartNo ));
							//printf("\n No of Modules Under Architechtures --> : %s\n",ModPartNo); fflush(stdout);

							ITKCALL(AOM_ask_value_string(PartChildobj, "bl_line_name", &ModPartLine ));
							//printf("\n ModPartLine --> : %s\n",ModPartLine); fflush(stdout);

							ITKCALL(AOM_ask_value_string(PartChildobj, "bl_rev_item_revision_id", &item_Rev_Seq));
							//printf("\n item_Rev_Seq --> : %s\n",item_Rev_Seq); fflush(stdout);

							ITKCALL(AOM_ask_value_string(PartChildobj, "bl_Design_t5_RevPartType", &ModPartType ));
							//printf("\n Part type Modules Under Architechtures --> : %s\n",ModPartType); fflush(stdout);

							char*	 ModPart_ModAdd    			= NULL;
							ITKCALL(AOM_ask_value_string(PartChildobj,"bl_Design Revision_t5_ModuleAddress",&ModPart_ModAdd));


							if((tc_strcmp(ModPart_ModAdd,"MC1D01")==0) || (tc_strcmp(ModPart_ModAdd,"MC2A01")==0)|| (tc_strcmp(ModPart_ModAdd,"MC3Z01")==0)|| (tc_strcmp(ModPart_ModAdd,"MP1A01")==0)|| (tc_strcmp(ModPart_ModAdd,"MP1N01")==0)|| (tc_strcmp(ModPart_ModAdd,"MP3A01")==0)|| (tc_strcmp(ModPart_ModAdd,"MC1D02")==0)|| (tc_strcmp(ModPart_ModAdd,"MP1L01")==0))
							{
								ModPartAct	=	(char	*)MEM_alloc(300);
								tc_strcpy(ModPartAct,ModPartNo);
								tc_strcat(ModPartAct,"/");
								tc_strcat(ModPartAct,item_Rev_Seq);
								//printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);

								setAddStr(icount,SetModulePart,ModPartAct);
							}

							iChildItemTag=0;
							t_ChildItemRev=NULLTAG;
							// TCTYPE_ask_property_by_name (( char * ) bomAttr_lineItemRevTag , &iChildItemTag);
							// AOM_ask_value_tag(PartChildobj, iChildItemTag, &t_ChildItemRev);
							if(t_ChildItemRev!=NULLTAG)
							{
								n_lines3=0;

								ITKCALL(Get_Part_BOM_Lvl(t_ChildItemRev,1,"ERC release and above",ChldStrutBdySh,&n_lines3));
								//printf("\n\t\t n_lines3:%d",n_lines3);fflush(stdout);

								//printf("\n Stage Assembly count--> %d\n",n_lines3);fflush(stdout);

								if(n_lines3 > 0)
								{
									for (iMod1=1;iMod1<=n_lines3 ;iMod1++ )
									{
										if(StageChildobj) StageChildobj=NULLTAG;
										if(StagePartNo) StagePartNo=NULL;
										if(Stage_item_Rev_Seq) Stage_item_Rev_Seq=NULL;
										if(StagePartType) StagePartType=NULL;

										char*	 StagePartNo_ModAdd    			= NULL;

										StageChildobj=ChldStrutBdySh[iMod1].child_objs_bvr;

										ITKCALL(AOM_ask_value_string(StageChildobj, "bl_item_item_id", &StagePartNo ));
										//printf("\n StagePartNo --> : %s\n",StagePartNo); fflush(stdout);

										ITKCALL(AOM_ask_value_string(StageChildobj, "bl_rev_item_revision_id", &Stage_item_Rev_Seq));
										//printf("\n Stage_item_Rev_Seq --> : %s\n",Stage_item_Rev_Seq); fflush(stdout);

										ITKCALL(AOM_ask_value_string(StageChildobj, "bl_Design_t5_RevPartType", &StagePartType ));
										//printf("\n StagePartType --> : %s\n",StagePartType); fflush(stdout);

										ITKCALL(AOM_ask_value_string(StageChildobj,"bl_Design Revision_t5_ModuleAddress",&StagePartNo_ModAdd));
										//printf("\n stage Part type Modules Under StagePartNo_ModAdd for child parts --> : %s\n",StagePartNo_ModAdd); fflush(stdout);

										if((tc_strcmp(StagePartNo_ModAdd,"MC1D01")==0) || (tc_strcmp(StagePartNo_ModAdd,"MC2A01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MC3Z01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP1A01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP1N01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP3A01")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MC1D02")==0)|| (tc_strcmp(StagePartNo_ModAdd,"MP1L01")==0))
										{
											//To add in set
											ModPartAct	=	(char	*)MEM_alloc(300);
											tc_strcpy(ModPartAct,StagePartNo);
											tc_strcat(ModPartAct,"/");
											tc_strcat(ModPartAct,Stage_item_Rev_Seq);

											//printf("\n ModPartAct --> : %s\n",ModPartAct); fflush(stdout);
											setAddStr(icount,SetModulePart,ModPartAct);
										}
									}
								}
							}
						}//for loop
					}//if(n_lines2 > 0)
				}
			}
		}

	}
	else
	{
		printf ("\n  Object is null\n"); fflush(stdout);
	}

	return ifail;
}

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

/*int getClassifiedValue(char ***bufferedXmlStrOut,int *buff_cnt,int* vcattr,struct VCAttrDetails VCAttrDetailsList[])
{
	int ifail = ITK_ok;
	int m =0;
	int m1 =0;
	printf("\nBuff count=%d\n",*buff_cnt);fflush(stdout);
	char* ModPartNUmberREvseq	= NULL;
	char* ModPartNUmberREvseq1	= NULL;
	char* ModPartNum	= NULL;

	//printf("\nTotal Number of Model Found=%d\n",*buff_cnt);fflush(stdout);
	//fprintf(fUASAPMapping,"\n Number of Solved Module:%d",*buff_cnt); fflush(fUASAPMapping);
	for(m1=0;m1<*buff_cnt;m1++)
	{
		ModPartNUmberREvseq1	= NULL;
		ModPartNUmberREvseq1 = (*bufferedXmlStrOut)[m1];
		//printf("\nModel solved Part number rev seq: %s",ModPartNUmberREvseq1);fflush(stdout);
		//fprintf(fUASAPMapping,"\n :%s",ModPartNUmberREvseq1); fflush(fUASAPMapping);
	}

	m1=0;
	char**	ModPartNumSet = NULL;
	ModPartNumSet = (char**)MEM_alloc( 1 * sizeof *ModPartNumSet );
	int	ModPrtSr=0;
	for(m1=0;m1<*buff_cnt;m1++)
	{
		ModPartNum	= NULL;
		ModPartNUmberREvseq = (*bufferedXmlStrOut)[m1];
		ModPartNum = strtok (ModPartNUmberREvseq,"/");
		//printf("\nModel Part number:: %s",ModPartNum);fflush(stdout);
		setAddStr(&ModPrtSr,&ModPartNumSet,ModPartNum);
	}
	m1=0;
	char**	ModPartNumUqSet = NULL;
	ModPartNumUqSet = (char**)MEM_alloc( 1 * sizeof *ModPartNumUqSet );
	int	ModPrtSrUq=0;

	for(m1=0;m1<ModPrtSr;m1++)
	{
		int FoundFlag=0;
		ModPartNum	= NULL;
		printf("\n%s",(ModPartNumSet)[m1]);fflush(stdout);
		ModPartNum = (ModPartNumSet)[m1];
		//printf("\n Serching part number %s",ModPartNum);fflush(stdout);
		int j=0;
		for(j=0;j<ModPrtSrUq;j++)
		{
			//printf("\n Compareing with  ===%s",(ModPartNumUqSet)[j]);fflush(stdout);
			if(tc_strcmp((ModPartNumUqSet)[j],ModPartNum)==0)
			{
				//printf("\n String Found ===%d",j);fflush(stdout);
				FoundFlag=1;
				break;
			}
			else
			{
				printf("\n Part Number NOT Found %s",ModPartNum);fflush(stdout);
				//setAddStr(&ModPrtSrUq,&ModPartNumUqSet,ModPartNum);
				//FoundFlag=1;
			}

		}
		if(FoundFlag==0)
		{
			//printf("\n Part Number %s Added",ModPartNum);fflush(stdout);
			setAddStr(&ModPrtSrUq,&ModPartNumUqSet,ModPartNum);
		}
	}
	m1=0;
	//printf("\nTotal Number of Unique Model Found=%d\n",ModPrtSrUq);fflush(stdout);
	//fprintf(fUASAPMapping,"\n Number of Solved Unique Module:%d",ModPrtSrUq); fflush(fUASAPMapping);
	for(m1=0;m1<ModPrtSrUq;m1++)
	{
		ModPartNum	= NULL;
		ModPartNum = (ModPartNumUqSet)[m1];
		//printf("\nFinal Unique set is: %s",ModPartNum);fflush(stdout);
		//fprintf(fUASAPMapping,"\n :%s",ModPartNum); fflush(fUASAPMapping);
	}
	for(m=0;m<ModPrtSrUq;m++)
	{
		ModPartNum	= NULL;
		//printf("\n Loop Number %d",m);fflush(stdout);
		tag_t Modelrev_tag = NULLTAG;
		ModPartNum = (ModPartNumUqSet)[m];
		//printf("\nModel Part number: %s",ModPartNum);fflush(stdout);

		if(ITEM_find_item(ModPartNum,&Modelrev_tag)!=ITK_ok)PrintErrorStack();
		//printf("\n selected part part Master found");fflush(stdout);

		tag_t			classificationObject = NULLTAG;
		int theAttributeCount =0;
		int *theAttributeIds ;
		char 			**theAttributeNames;
		int *theAttributeValCounts=0;
		char***       theAttributeValues;
		char***       theAttributeOptimizedUnits;
		char* 	attrId 					= NULL;
		attrId = (char *) MEM_alloc( 50 * sizeof(char) );
		char 	*attributeNameDup 			= NULL;
		char 	*attributeValueDup 			= NULL;
		attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
		attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
		int i,x=0;
		int TotVCAttrCount=0;

		char*	 ModelrevPartRev = NULL;

		ITK_CALL(ICS_ask_classification_object(Modelrev_tag,&classificationObject));

		if (classificationObject != NULLTAG)
		{
		ITK_CALL( ICS_ico_ask_attributes_optimized(classificationObject,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));
		//printf("### ICS_ico_ask_named_attributes nAttributes = %d\n", theAttributeCount);fflush(stdout);
		if(theAttributeCount>0)
		{
			for(i=0;i<theAttributeCount;i++)
			{

					TotVCAttrCount=TotVCAttrCount+theAttributeCount;

					//printf("\n theAttributeIds id:[%d]",theAttributeIds[i]);fflush(stdout);
					//printf("\n theAttributeNames:[%s]",theAttributeNames[i]);fflush(stdout);
					sprintf(attrId,"%d",theAttributeIds[i]);
					//printf("\n attrId:[%s]",attrId);fflush(stdout);

					tc_strcpy(attributeNameDup,"");
					tc_strcpy(attributeNameDup,theAttributeNames[i]);

					//printf("\n theAttribute Names:[%s] for loop %d ",attributeNameDup,i);fflush(stdout);

					tc_strcpy(attributeValueDup,"");

					//printf("\n Number of attribute value is %d ",*theAttributeValCounts);fflush(stdout);

					for(x=0;x<theAttributeValCounts[i];x++)
					{
						//printf("\n [%d]aattributeNames Val:[%s]",x,theAttributeValues[i][x]);fflush(stdout);
						tc_strcat(attributeValueDup,theAttributeValues[i][x]);
						//printf("\n attributeValueDup:[%s]",attributeValueDup);fflush(stdout);
					}

					//printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);
					tc_strcpy(VCAttrDetailsList[*vcattr].VCAttrID,attrId);
					tc_strcpy(VCAttrDetailsList[*vcattr].VCAttrName,attributeNameDup);
					tc_strcpy(VCAttrDetailsList[*vcattr].VCAttrNameValue,attributeValueDup);

					//printf("\n attribute id in loop :[%s]",VCAttrDetailsList[*vcattr].VCAttrID);fflush(stdout);
					//printf("\n attribute name  in loop:[%s]",VCAttrDetailsList[*vcattr].VCAttrName);fflush(stdout);
					//printf("\n attribute Value in loop:[%s]",VCAttrDetailsList[*vcattr].VCAttrNameValue);fflush(stdout);
					*vcattr=*vcattr+1;
			}
				//printf("\n total VC attribute value:[%d] ",TotVCAttrCount);fflush(stdout);
				//printf("\n total vcattr value:[%d] ",*vcattr);fflush(stdout);
		}
	}
	else
	{
		//printf("\n VCclassificationObject NOt found");fflush(stdout);
	}
	}
	//printf("\n END For Loop");fflush(stdout);

	int j=0;
	for(j=0 ;j<*vcattr;j++ )
	{
		printf("\n value of J:[%d] ",j);fflush(stdout);fflush(stdout);
		printf("\n attribute id :[%s]",VCAttrDetailsList[j].VCAttrID);fflush(stdout);
		printf("\n attribute name :[%s]",VCAttrDetailsList[j].VCAttrName);fflush(stdout);
		printf("\n attribute Value:[%s]",VCAttrDetailsList[j].VCAttrNameValue);fflush(stdout);
	}

	printf("\nGoing from getClassifiedValue");fflush(stdout);
	return ifail;
}*/

void getMoRTHAttributes(tag_t PartObj)
{
	cmvrFlag=0;
	st5Pollutant_CM1Dup		= NULL;
	st5Pollutant_HC1Dup		= NULL;
	st5Pollutant_NH1Dup		= NULL;
	st5Pollutant_RHC1Dup	= NULL;
	st5Pollutant_NO1Dup		= NULL;
	st5Pollutant_HCNO1Dup	= NULL;
	st5Pollutant_PM1Dup		= NULL;
	st5Pollutant_HO1Dup		= NULL;
	st5BystanderPosDup		= NULL;
	BBBACNUMDup				= NULL;
	BBBACISDTDup			= NULL;
	BBBACVLDTDup			= NULL;
	VBCAPRCNUMDup			= NULL;
	t5Pol_Amonia1Dup		= NULL;
	t5Pol_Methane1Dup		= NULL;
	t5Pol_Particle1Dup		= NULL;
	int ifail = ITK_ok;
	char* VehNo				= NULL;

	tag_t relType			= NULLTAG;
	tag_t* CMVRObjs			= NULL;
	int CMVRObjsCount		= 0;
	tag_t CMVRObjTag		= NULLTAG;

	ITK_CALL(AOM_ask_value_string(PartObj,"item_id",&VehNo));
	//printf("\n  vehicleNumber1 : %s \n",VehNo); fflush(stdout);

	ITK_CALL(GRM_find_relation_type("T5_CmvrVeh", &relType));
	//printf("\n CMVRObj=%u relType=%u\n",PartObj,relType);fflush(stdout);

	if( relType != NULLTAG )
	{
		ITK_CALL(GRM_list_primary_objects_only(PartObj,relType,&CMVRObjsCount,&CMVRObjs));
		//printf("\n CMVRObjsCount=%d \n",CMVRObjsCount);fflush(stdout);
		if(CMVRObjsCount > 0)
		{
			CMVRObjTag = CMVRObjs[0];
		}
	}

	if(CMVRObjsCount == 0)
	{
		tag_t	*rev_list	= NULL;
		int Item_count      =  0;
		tag_t cPartOPtr		= NULLTAG;
		tag_t All_item_tag	= NULLTAG;
		ITK_CALL(ITEM_find_item (VehNo, &All_item_tag));
		ITK_CALL(ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list));
		//printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
		int ii = 0;
		if(Item_count > 0)
		{
			for(ii=Item_count-1;ii>=0;ii--)
			{
				cPartOPtr=rev_list[ii];
				char 	*rev_idd				= NULL;
				ITK_CALL(GRM_list_primary_objects_only(cPartOPtr,relType,&CMVRObjsCount,&CMVRObjs));

				ITK_CALL(AOM_UIF_ask_value (cPartOPtr, "item_revision_id", &rev_idd));
				//printf("\n Eff: Latest released rev is:%s.", rev_idd);fflush(stdout);

				if(CMVRObjsCount > 0)
					break;
				else
					continue;
			}
		}

	}

	if(CMVRObjsCount > 0)
	{
		cmvrFlag=1;

		CMVRObjTag = CMVRObjs[0];
		char *CmvrIntentNum 	   = NULL;
		char *CmvrIntentNumDup 	   = NULL;
		char* status_rel			= NULL;

		AOM_ask_value_string( CMVRObjTag, "t5_IntentNumber", &CmvrIntentNum);
		//printf( "CmvrIntentNum:%s\n", CmvrIntentNum);fflush(stdout);
		if(CmvrIntentNum)
		{
			 tc_strdup(CmvrIntentNum,&CmvrIntentNumDup);
			//printf( "CmvrIntentNumDup:%s\n", CmvrIntentNumDup);fflush(stdout);
		}
		ITK_CALL(AOM_UIF_ask_value(CMVRObjTag,"release_status_list",&status_rel));
		//printf( "release_status_list:%s\n", status_rel);fflush(stdout);
		//if(tc_strstr(status_rel,"ERC Released")!=NULL)
		//{
		st5Pollutant_CM1Dup		= MEM_alloc(50);
		st5Pollutant_HC1Dup		= MEM_alloc(50);
		st5Pollutant_NH1Dup		= MEM_alloc(50);
		st5Pollutant_RHC1Dup	= MEM_alloc(50);
		st5Pollutant_NO1Dup		= MEM_alloc(50);
		st5Pollutant_HCNO1Dup	= MEM_alloc(50);
		st5Pollutant_PM1Dup		= MEM_alloc(50);
		t5Pol_Amonia1Dup		= MEM_alloc(50);
		t5Pol_Methane1Dup		= MEM_alloc(50);
		t5Pol_Particle1Dup		= MEM_alloc(50);

		//Hydrocarbon, (THC/HC)
		AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_CM", &st5Pollutant_CM1);
		//printf( "st5Pollutant_CM1:%s\n", st5Pollutant_CM1);fflush(stdout);
		if(st5Pollutant_CM1)
		{
			//tc_strdup(st5Pollutant_CM1Dup1,&st5Pollutant_CM1);
			tc_strdup(st5Pollutant_CM1,&st5Pollutant_CM1Dup1);
		}
		//printf( "st5Pollutant_CM1Dup1:%s\n", st5Pollutant_CM1Dup1);fflush(stdout);

		if(tc_strcmp(st5Pollutant_CM1Dup1,"NA") != 0)
		{

			AOM_ask_value_string( CMVRObjTag, "t5_CMUoM", &CMUnit);
			//printf( "CMUnit:%s\n", CMUnit);fflush(stdout);
			if(CMUnit)
			{
				tc_strdup(CMUnit,&CMUnitDup);
			}

			tc_strcpy(st5Pollutant_CM1Dup,st5Pollutant_CM1Dup1);
			tc_strcat(st5Pollutant_CM1Dup," ");
			tc_strcat(st5Pollutant_CM1Dup,CMUnitDup);
		}
		else
		{	tc_strcpy(st5Pollutant_CM1Dup,st5Pollutant_CM1Dup1); }
			//printf( "st5Pollutant_CM1Dup:%s\n", st5Pollutant_CM1Dup);fflush(stdout);

		AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_HC", &st5Pollutant_HC1);

		//printf( "st5Pollutant_HC1:%s\n", st5Pollutant_HC1);fflush(stdout);

		if(st5Pollutant_HC1)
		{
			tc_strdup(st5Pollutant_HC1,&st5Pollutant_HC1Dup1);
		}

		if(tc_strcmp(st5Pollutant_HC1Dup1,"NA") != 0)
		{
			AOM_ask_value_string( CMVRObjTag, "t5_HCUoM", &HCUnit);
			//printf( "HCUnit:%s\n", HCUnit);fflush(stdout);

			if(HCUnit)
			{
				tc_strdup(HCUnit,&HCUnitDup);
			}
			tc_strcpy(st5Pollutant_HC1Dup,st5Pollutant_HC1Dup1);
			tc_strcat(st5Pollutant_HC1Dup," ");
			tc_strcat(st5Pollutant_HC1Dup,HCUnitDup);
		}
		else
		{
			tc_strcpy(st5Pollutant_HC1Dup,st5Pollutant_HC1Dup1);
		}
		//printf( "st5Pollutant_HC1Dup:%s\n", st5Pollutant_HC1Dup);fflush(stdout);

		//Non-Methane Hydrocarbon (NMHC)
		AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_NH", &st5Pollutant_NH1);

		//printf( "st5Pollutant_NH1:%s\n", st5Pollutant_NH1);fflush(stdout);

		if(st5Pollutant_NH1)
		{
			tc_strdup(st5Pollutant_NH1,&st5Pollutant_NH1Dup1);
		}
		if(tc_strcmp(st5Pollutant_NH1Dup1,"NA") != 0)
		{
			AOM_ask_value_string( CMVRObjTag, "t5_NMHCUoM", &NMHCUnit);
			//printf( "NMHCUnit:%s\n", NMHCUnit);fflush(stdout);
			if(NMHCUnit)
			{
				tc_strdup(NMHCUnit,&NMHCUnitDup);
			}
			tc_strcpy(st5Pollutant_NH1Dup,st5Pollutant_NH1Dup1);
			tc_strcat(st5Pollutant_NH1Dup," ");
			tc_strcat(st5Pollutant_NH1Dup,NMHCUnitDup);
		}
		else
		{	tc_strcpy(st5Pollutant_NH1Dup,st5Pollutant_NH1Dup1); }
			//printf( "st5Pollutant_NH1Dup:%s\n", st5Pollutant_NH1Dup);fflush(stdout);

			//THC + Nox
			AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_RHC", &st5Pollutant_RHC1);

			//printf( "st5Pollutant_RHC1:%s\n", st5Pollutant_RHC1);fflush(stdout);
			if(st5Pollutant_RHC1)
			{
				tc_strdup(st5Pollutant_RHC1,&st5Pollutant_RHC1Dup1);
			}

			if(tc_strcmp(st5Pollutant_RHC1Dup1,"NA") != 0)
			{
				AOM_ask_value_string( CMVRObjTag, "t5_RHCUoM", &RHCUnit);
			//printf( "RHCUnit:%s\n", RHCUnit);fflush(stdout);
				if(RHCUnit)
				{
					tc_strdup(RHCUnit,&RHCUnitDup);
				}
				tc_strcpy(st5Pollutant_RHC1Dup,st5Pollutant_RHC1Dup1);
				tc_strcat(st5Pollutant_RHC1Dup," ");
				tc_strcat(st5Pollutant_RHC1Dup,RHCUnitDup);
		}
		else
		{	tc_strcpy(st5Pollutant_RHC1Dup,st5Pollutant_RHC1Dup1);}
			//printf( "st5Pollutant_RHC1Dup:%s\n", st5Pollutant_RHC1Dup);fflush(stdout);

			//Oxides of Nitrogen (NOx)
			AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_NO", &st5Pollutant_NO1);
			//printf( "st5Pollutant_NO1:%s\n", st5Pollutant_NO1);fflush(stdout);

		if(st5Pollutant_NO1)
		{
			tc_strdup(st5Pollutant_NO1,&st5Pollutant_NO1Dup1);
		}
		if(tc_strcmp(st5Pollutant_NO1Dup1,"NA") != 0)
		{
			AOM_ask_value_string( CMVRObjTag, "t5_NOUoM", &NOUnit);
			//printf( "NOUnit:%s\n", NOUnit);fflush(stdout);
			if(NOUnit)
			{
				tc_strdup(NOUnit,&NOUnitDup);
			}
			tc_strcpy(st5Pollutant_NO1Dup,st5Pollutant_NO1Dup1);
			tc_strcat(st5Pollutant_NO1Dup," ");
			tc_strcat(st5Pollutant_NO1Dup,NOUnitDup);
		}
		else
		{	tc_strcpy(st5Pollutant_NO1Dup,st5Pollutant_NO1Dup1);}
			//printf( "st5Pollutant_NO1Dup:%s\n", st5Pollutant_NO1Dup);fflush(stdout);

		//HC + Nox
		AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_HCNO", &st5Pollutant_HCNO1);

		//printf( "st5Pollutant_HCNO1:%s\n", st5Pollutant_HCNO1);fflush(stdout);

		if(st5Pollutant_HCNO1)
		{
			tc_strdup(st5Pollutant_HCNO1,&st5Pollutant_HCNO1Dup1);
		}
		if(tc_strcmp(st5Pollutant_HCNO1Dup1,"NA") != 0)
		{
			AOM_ask_value_string( CMVRObjTag, "t5_HCNOUoM", &HCNOUnit);

			//printf( "HCNOUnit:%s\n", HCNOUnit);fflush(stdout);

			if(HCNOUnit)
			{
				tc_strdup(HCNOUnit,&HCNOUnitDup);
			}
			tc_strcpy(st5Pollutant_HCNO1Dup,st5Pollutant_HCNO1Dup1);
			tc_strcat(st5Pollutant_HCNO1Dup," ");
			tc_strcat(st5Pollutant_HCNO1Dup,HCNOUnitDup);
		}
		else
		{	tc_strcpy(st5Pollutant_HCNO1Dup,st5Pollutant_HCNO1Dup1);	}

		//printf( "st5Pollutant_HCNO1Dup:%s\n", st5Pollutant_HCNO1Dup);fflush(stdout);

		//Mass of Particulate Matter (PM)
		AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_PM", &st5Pollutant_PM1);

		//printf( "st5Pollutant_PM1:%s\n", st5Pollutant_PM1);fflush(stdout);

		if(st5Pollutant_PM1)
		{
			tc_strdup(st5Pollutant_PM1,&st5Pollutant_PM1Dup1);
		}
		if(tc_strcmp(st5Pollutant_PM1Dup1,"NA") != 0)
		{
			AOM_ask_value_string( CMVRObjTag, "t5_PMUoM", &PMUnit);

			//printf( "PMUnit:%s\n", PMUnit);fflush(stdout);

			if(PMUnit)
			{
				tc_strdup(PMUnit,&PMUnitDup);
			}
			tc_strcpy(st5Pollutant_PM1Dup,st5Pollutant_PM1Dup1);
			tc_strcat(st5Pollutant_PM1Dup," ");
			tc_strcat(st5Pollutant_PM1Dup,PMUnitDup);
		}
		else
		{	tc_strcpy(st5Pollutant_PM1Dup,st5Pollutant_PM1Dup1);	}

		//printf( "st5Pollutant_PM1Dup:%s\n", st5Pollutant_PM1Dup);fflush(stdout);

		//Methane
		AOM_ask_value_string( CMVRObjTag, "t5_Pol_Methane", &t5Pol_Methane1);
		//printf( "t5Pol_Methane1:%s\n", t5Pol_Methane1);fflush(stdout);
		if(t5Pol_Methane1)
		{
			tc_strdup(t5Pol_Methane1,&t5Pol_Methane1Dup1);
		}
		//printf( "t5Pol_Methane1Dup1:%s\n", t5Pol_Methane1Dup1);fflush(stdout);

		if(tc_strcmp(t5Pol_Methane1Dup1,"NA") != 0)
		{
			AOM_ask_value_string( CMVRObjTag, "t5_MethUoM", &MethaneUnit);
			//printf( "MethaneUnit:%s\n", MethaneUnit);fflush(stdout);
			if(MethaneUnit)
			{
				tc_strdup(MethaneUnit,&MethaneUnitDup);
			}

			tc_strcpy(t5Pol_Methane1Dup,t5Pol_Methane1Dup1);
			tc_strcat(t5Pol_Methane1Dup," ");
			tc_strcat(t5Pol_Methane1Dup,MethaneUnitDup);
		}
		else
		{	tc_strcpy(t5Pol_Methane1Dup,t5Pol_Methane1Dup1); }

		//printf( "t5Pol_Methane1Dup:%s\n", t5Pol_Methane1Dup);fflush(stdout);

		//Amonia
		AOM_ask_value_string( CMVRObjTag, "t5_Pol_Amonia", &t5Pol_Amonia1);
		//printf( "t5Pol_Amonia1:%s\n", t5Pol_Amonia1);fflush(stdout);
		if(t5Pol_Amonia1)
		{
			tc_strdup(t5Pol_Amonia1,&t5Pol_Amonia1Dup1);
		}
		//printf( "t5Pol_Amonia1Dup1:%s\n", t5Pol_Amonia1Dup1);fflush(stdout);

		if(tc_strcmp(t5Pol_Amonia1Dup1,"NA") != 0)
		{
			AOM_ask_value_string( CMVRObjTag, "t5_AmoUoM", &AmoniaUnit);
			//printf( "AmoniaUnit:%s\n", AmoniaUnit);fflush(stdout);
			if(AmoniaUnit)
			{
				tc_strdup(AmoniaUnit,&AmoniaUnitDup);
			}

			tc_strcpy(t5Pol_Amonia1Dup,t5Pol_Amonia1Dup1);
			tc_strcat(t5Pol_Amonia1Dup," ");
			tc_strcat(t5Pol_Amonia1Dup,AmoniaUnitDup);
		}
		else
		{	tc_strcpy(t5Pol_Amonia1Dup,t5Pol_Amonia1Dup1); }

		//printf( "t5Pol_Amonia1Dup:%s\n", t5Pol_Amonia1Dup);fflush(stdout);

		//Number of particles
		AOM_ask_value_string( CMVRObjTag, "t5_Pol_Particle", &t5Pol_Particle1);
		//printf( "t5Pol_Particle1:%s\n", t5Pol_Particle1);fflush(stdout);
		if(t5Pol_Particle1)
		{
			tc_strdup(t5Pol_Particle1,&t5Pol_Particle1Dup1);
		}
		//printf( "t5Pol_Particle1Dup1:%s\n", t5Pol_Particle1Dup1);fflush(stdout);

		if(tc_strcmp(t5Pol_Particle1Dup1,"NA") != 0)
		{

			AOM_ask_value_string( CMVRObjTag, "t5_NoPUoM", &ParticleUnit);
			//printf( "ParticleUnit:%s\n", ParticleUnit);fflush(stdout);
			if(ParticleUnit)
			{
				tc_strdup(ParticleUnit,&ParticleUnitDup);
			}

			tc_strcpy(t5Pol_Particle1Dup,t5Pol_Particle1Dup1);
			tc_strcat(t5Pol_Particle1Dup," ");
			tc_strcat(t5Pol_Particle1Dup,ParticleUnitDup);
		}
		else
		{	tc_strcpy(t5Pol_Particle1Dup,t5Pol_Particle1Dup1); }

		//printf( "t5Pol_Particle1Dup:%s\n", t5Pol_Particle1Dup);fflush(stdout);

		//Sound level of horn as installed on the vehicle
		AOM_ask_value_string( CMVRObjTag, "t5_Pollutant_HO", &st5Pollutant_HO1);

		//printf( "st5Pollutant_HO1:%s\n", st5Pollutant_HO1);fflush(stdout);

		if(st5Pollutant_HO1)
		{
			tc_strdup(st5Pollutant_HO1,&st5Pollutant_HO1Dup);
		}
		//printf( "st5Pollutant_HO1Dup:%s\n", st5Pollutant_HO1Dup);fflush(stdout);

		//Pass-by Noise value
		AOM_ask_value_string( CMVRObjTag, "t5_BystanderPos", &st5BystanderPos);

		//printf( "st5BystanderPos:%s\n", st5BystanderPos);fflush(stdout);
		if(st5BystanderPos)
		{
			tc_strdup(st5BystanderPos,&st5BystanderPosDup);
		}
		//printf( "st5BystanderPosDup:%s\n", st5BystanderPosDup);fflush(stdout);
		AOM_ask_value_string( CMVRObjTag, "t5_BBBACNum", &BBBACNUM);
		//printf( "BBBACNUM:%s\n", BBBACNUM);fflush(stdout);
		if(BBBACNUM)
		{
			tc_strdup(BBBACNUM,&BBBACNUMDup);
		}
		//printf( "st5BystanderPos:%s\n", st5BystanderPos);fflush(stdout);
		AOM_ask_value_string( CMVRObjTag, "t5_BBBACIsDt", &BBBACISDT);
		//printf( "BBBACISDT:%s\n", BBBACISDT);fflush(stdout);
		if(BBBACISDT)
		{
			tc_strdup(BBBACISDT,&BBBACISDTDup);
		}
		//printf( "st5BystanderPos:%s\n", BBBACISDTDup);fflush(stdout);
		AOM_ask_value_string( CMVRObjTag, "t5_BBBACVlDt", &BBBACVLDT);
		//printf( "BBBACVLDT:%s\n", BBBACVLDT);fflush(stdout);
		if(BBBACVLDT)
		{
			tc_strdup(BBBACVLDT,&BBBACVLDTDup);
		}
		AOM_ask_value_string( CMVRObjTag, "t5_VBCAprCNum", &VBCAPRCNUM);
		//printf( "VBCAPRCNUM:%s\n", VBCAPRCNUM);fflush(stdout);
		if(VBCAPRCNUM)
		{
			tc_strdup(VBCAPRCNUM,&VBCAPRCNUMDup);
		}
		AOM_ask_value_string( CMVRObjTag, "t5_VBCAprDt", &VBCAPRDT);
		printf( "VBCAPRDT:%s\n", VBCAPRDT);fflush(stdout);
		if(VBCAPRDT)
		{
			tc_strdup(VBCAPRDT,&VBCAPRDTDup);
		}

	}
	else
	{
		printf("\ncmvrFlag : %d CMVRObjs not Found for Vehicle : %s",cmvrFlag,VehNo);fflush(stdout);
		//fprintf(fsuccess,"\ncmvrFlag : %d CMVRObjs not Found for Vehicle : %s",cmvrFlag,VehNo);fflush(stdout);
		//goto CLEANUP;
	}
}

static tag_t ask_item_revision_from_bom_line_SnapShot(tag_t bom_line)
{
    tag_t item_revision = NULLTAG;
    char *item_id = NULL, *rev_id = NULL;

    ITKCALL(AOM_ask_value_string(bom_line, "bl_item_item_id", &item_id ));
    ITKCALL(AOM_ask_value_string(bom_line, "bl_rev_item_revision_id", &rev_id));
    ITKCALL(ITEM_find_rev(item_id, rev_id, &item_revision));

    if (item_id) MEM_free(item_id);
    if (rev_id) MEM_free(rev_id);
    return item_revision;
}

void GetAllChild_SnapShot(tag_t* top_line,int depth,char ***SetModulePart,int *icount)
{
	int n = 0;
	tag_t* children = NULLTAG;
	int k = 0;
	int Item_ID = 0;
	int Item_RevSeq = 0;
	char *Item_ID_str = NULL;
	char *Item_RevSeq_str = NULL;
	tag_t ChildItemRev = NULLTAG;
	char	*ModPartType=	NULL;
	int			modadd			= 0;
	char	*ModPartAct	=	NULL;
	char *mod_addr = NULL;
	int bomvalue =1;

	depth++;
	//printf("\nInside GetAllChild_SnapShot********");fflush(stdout);
	//ITKCALL(   TCTYPE_ask_property_by_name ("bl_item_item_id",&Item_ID));
	//ITKCALL(   TCTYPE_ask_property_by_name ("bl_rev_item_revision_id",&Item_RevSeq));
	//ITKCALL(  AOM_ask_displayable_values(*top_line, Item_ID,&Item_ID_str));
	//ITKCALL(  AOM_ask_displayable_values(*top_line, Item_RevSeq,&Item_RevSeq_str));
	//printf("\n%d]Item_ID_str: [%s] [%s]",depth,Item_ID_str,Item_RevSeq_str);fflush(stdout);
	ChildItemRev = ask_item_revision_from_bom_line_SnapShot(*top_line);
	tag_t ChildTagLatestRev	 = NULLTAG;

	if(ITEM_ask_latest_rev(ChildItemRev,&ChildTagLatestRev));

	if (ChildItemRev==NULLTAG)
	{
		printf("\nNULLTAG FOUND FOR BOM LINE ITEM : %s",Item_ID_str);fflush(stdout);
	}
	else
	{
		if(ModPartType) ModPartType=NULL;

		ITKCALL(AOM_ask_value_string(*top_line, "bl_Design_t5_RevPartType", &ModPartType ));
		//printf("\n Part type Modules Under Architechtures --> : %s\n",ModPartType); fflush(stdout);

		//if(  TCTYPE_ask_property_by_name("bl_Design Revision_t5_ModuleAddress",&modadd))PrintErrorStack();
		//if(  AOM_ask_displayable_values(*top_line, modadd,&mod_addr))PrintErrorStack();
		//printf("\n mod_addr:%s\n",mod_addr);fflush(stdout);

		if((tc_strcmp(ModPartType,"M")==0) || (tc_strcmp(ModPartType,"CM")==0))
		{
			/*X4MC1D01
			X4MC2A01
			X4MC3Z01vi
			X4MP1A01
			X4MP1N01
			X4MP3A01
			X4MC1D02*/
			//this module is not menstioned in excel shee added as per mail MP1L01
			if((tc_strcmp(mod_addr,"MC1D01")==0) || (tc_strcmp(mod_addr,"MC2A01")==0)|| (tc_strcmp(mod_addr,"MC3Z01")==0)|| (tc_strcmp(mod_addr,"MP1A01")==0)|| (tc_strcmp(mod_addr,"MP1N01")==0)|| (tc_strcmp(mod_addr,"MP3A01")==0)|| (tc_strcmp(mod_addr,"MC1D02")==0)|| (tc_strcmp(mod_addr,"MP1L01")==0))
			{
				//printf("\nFor Adding Item_ID_str: [%s] [%s]",Item_ID_str,Item_RevSeq_str);fflush(stdout);
				//printf("\n adding Modules adderess --> : %s\n",mod_addr); fflush(stdout);
				//To add in set
				ModPartAct	=	(char	*)MEM_alloc(300);
				tc_strcpy(ModPartAct,Item_ID_str);
				tc_strcat(ModPartAct,"/");
				tc_strcat(ModPartAct,Item_RevSeq_str);

				//printf("\n ModPartAct --> : %s",ModPartAct); fflush(stdout);
				setAddStr(icount,SetModulePart,ModPartAct);
			}
		}
		ITKCALL(BOM_line_ask_child_lines (*top_line, &n, &children));

		//printf("\nAssembly:%s no of child found:%d",Item_ID_str,n);fflush(stdout);
		for (k = 0; k < n; k++)
		{
			GetAllChild_SnapShot(&children[k],depth,SetModulePart,icount);
		}
	}
}

int tm_ebom_snapshot(char *snapshot,char ***SetModulePart,int *icount)
{
	int	ifail 	=   ITK_ok;

	WSO_search_criteria_t SSCriteria;

	tag_t* SSobjTag		= NULLTAG;
	int SScount			= 0;
	int Item_ID			= 0;
	tag_t Snapshot_tag	= NULLTAG;
	tag_t window		= NULLTAG;
	tag_t item_rev_tags	= NULLTAG;
	tag_t top_line		= NULLTAG;
	char* SSTopLineRev	= NULL;
	char *Item_ID_str	= NULL;

	PIE_scope_t scope;
	scope=PIE_TEAMCENTER;

	//printf("\nInSide tm_ebom_snapshot functionssssssss");fflush(stdout);

	//printf("\nsnapshot ...%s\n", snapshot);fflush(stdout);

	ITKCALL(WSOM_clear_search_criteria(&SSCriteria));
	tc_strcpy(SSCriteria.class_name,"Snapshot");
	tc_strcpy(SSCriteria.name,snapshot);
	ITKCALL(WSOM_search(SSCriteria,&SScount,&SSobjTag));
	//printf("\nSnapShot found :%d",SScount);fflush(stdout);

	int		rulefound		=	0;
	tag_t	*closurerule	=	NULLTAG;
	tag_t	close_tag		=	NULLTAG;
	char	**rulename		=	NULL;
	char	**rulevalue		=	NULL;
	int bomvalue =1;

	if (SScount > 0)
	{
		Snapshot_tag = SSobjTag[0];

		ITKCALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
		//printf("\nSnapshot Top Line : %s",SSTopLineRev);fflush(stdout);

		ITKCALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));

		ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));

		ITKCALL( PIE_find_closure_rules2("BOMLineskipforunconfigured",scope, &rulefound, &closurerule ));
		//printf ("\nrule count %d \n",rulefound);fflush(stdout);
		if (rulefound > 0)
		{
			close_tag = closurerule[0];
			//printf ("closure rule found \n"); fflush(stdout);
		}
		ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
		//printf ("closure rule found applied \n"); fflush(stdout);
		ITKCALL(BOM_set_window_pack_all (window, FALSE));
		ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
		ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));

		//ITKCALL(  TCTYPE_ask_property_by_name ("bl_item_item_id",&Item_ID));
		//ITKCALL(  AOM_ask_displayable_values(top_line,Item_ID, &Item_ID_str));
		//printf("\nItem_ID_str#:%s",Item_ID_str);fflush(stdout);

		GetAllChild_SnapShot(&top_line,2,SetModulePart,icount);

	}
	else
	{
		//printf ("\n  SnapShot not found [%s]\n", snapshot); fflush(stdout);
	}

	return ifail;
}

int GetDVAUseCaseFromLibrary(tag_t PartTag, char* t5_business_unit_type_mod, int* resultCount, tag_t **dfq_use_case_tags)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char* documentName =NULL;
	char* s;
	char* moduleAddressS = NULL;
	char* moduleAddressB = NULL;
	char* partsub = NULL;
	char* itemid = NULL;
	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	moduleAddressB = (char *)MEM_alloc(200);
	moduleAddressS = (char *)MEM_alloc(200);
	partsub = (char *)MEM_alloc(200);
	tag_t queryTag = NULLTAG;
	tag_t *dfq_use_case_tags1 = NULLTAG;


	/*--------------------------------------------------------
		Get Applicable DFQ USE CASE
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"t5_ModuleAddress",&moduleAddressS);
	printf("Module Address:: 111111 %s\n",moduleAddressS);fflush(stdout);

	AOM_ask_value_string(PartTag,"item_id",&itemid);
	printf("part number is 1 %s\n",itemid);fflush(stdout);
    partsub=subString(itemid,4,5);
	printf("substring is %s\n",partsub);fflush(stdout);


	if(tc_strcmp(moduleAddressS,"")==0)
	{

	 printf("\n Inside the module address balank conditoin \n");fflush(stdout);

	 tc_strcpy(moduleAddressB,"");
	 tc_strcat(moduleAddressB,"M");
	 moduleAddressS=tc_strcat(moduleAddressB,partsub);
	 printf("substring is %s\n",partsub);fflush(stdout);
	 printf("Module is in blank condition %s\n",moduleAddressB);fflush(stdout);
	
	
	}

	queryTag = NULLTAG;
	status =   QRY_find2("General...", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	if(tc_strcmp(t5_business_unit_type_mod,"CVBU") == 0) t5_business_unit_type_mod = "CV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU") == 0) t5_business_unit_type_mod = "PV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU and CVBU Both") == 0) t5_business_unit_type_mod = "PSE";
	else
	{
			EMH_ask_error_text( status, &s);
			MEM_free(s);
			return status;
	}

	//Query DFQ Use Case
	documentName = NULL;
	documentName = (char *)MEM_alloc(50);
	tc_strcpy(documentName, "DVA_");
	tc_strcat(documentName, t5_business_unit_type_mod);
	tc_strcat(documentName, "_");
	tc_strcat(documentName, moduleAddressS);
	tc_strcat(documentName, "*");

	qry_values1[0] = (char *)MEM_alloc(strlen(documentName ) + 1);
	tc_strcpy(qry_values1[0], documentName);

	qry_entries[0] = (char *)MEM_alloc(10);
	strcpy(qry_entries[0], "Name");

	ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values1, &resultCount1, &dfq_use_case_tags1));
	printf("\nNo. of DFQ Use Case Document found are %d -- %s\n",resultCount1,documentName);fflush(stdout);

	if(resultCount1 > 0)
	{
		*dfq_use_case_tags = dfq_use_case_tags1;
		*resultCount = resultCount1;
	}

	return 0;
}

int getBusinessUnitFunc(tag_t PartTag, char** ProjbussDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"t5_ProjectCode",&t5_projectc_code_string);
	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status =  QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}

int getBusinessUnitFunct(tag_t PartTag, char** ProjbussDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"bl_Design Revision_t5_ProjectCode",&t5_projectc_code_string);

	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status =  QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}

int getBusinessUnitFun(tag_t PartTag, char** ProjdescDup,char** Projname)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char *t5_business_unit_type_mod1;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"t5_ProjectCode",&t5_projectc_code_string);

	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status =  QRY_find2("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"object_desc",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjdescDup = t5_business_unit_type_mod;

	AOM_ask_value_string(proj_tags[0],"t5_VehicleClass",&t5_business_unit_type_mod1);
	printf("Vechile class -- %s\n",t5_business_unit_type_mod1);fflush(stdout);

	*Projname = t5_business_unit_type_mod1;

	return 0;
}
//int getBusinessUnit(tag_t PartTag, char** Projname)
//{
//	int status = 0;
//	int n_entries = 1;
//	int resultCount1 = 0;
//	char *s;
//	char *t5_business_unit_type_mod;
//	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
//	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
//	char* t5_projectc_code_string;
//	tag_t queryTag = NULLTAG;
//	tag_t* proj_tags = NULLTAG;
//	/*--------------------------------------------------------
//		Get Business Unit from Project Code"
//	---------------------------------------------------------*/
//	AOM_ask_value_string(PartTag,"t5_ProjectCode",&t5_projectc_code_string);
//
//	printf("%s\n",t5_projectc_code_string);fflush(stdout);
//
//	queryTag = NULLTAG;
//	status =  QRY_find2("Project for DSRpt", &queryTag);
//	if (status != ITK_ok)
//	{
//		  EMH_ask_error_text( status, &s);
//		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
//		  MEM_free(s);
//		  return status;
//	}
//
//	qry_entries2[0] = (char *)MEM_alloc(15);
//	strcpy(qry_entries2[0], "Project Number");
//
//	qry_values3[0] = (char *)MEM_alloc(10);
//	tc_strcpy(qry_values3[0], t5_projectc_code_string);
//
//	QRY_set_name_mode(queryTag,false);
//	//Execute Query
//	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);
//
//	if(resultCount1 == 0)
//	{
//			EMH_ask_error_text( status, &s);
//			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
//			MEM_free(s);
//			return status;
//	}
//
//	AOM_ask_value_string(proj_tags[0],"t5_VehicleClass",&t5_business_unit_type_mod);
//	printf("Vechile class -- %s\n",t5_business_unit_type_mod);fflush(stdout);
//
//	*Projname = t5_business_unit_type_mod;
//
//	return 0;
//}

int GetDVAUseCaseFromLibraryt(tag_t PartTag, char* t5_business_unit_type_mod, int* resultCount, tag_t **dfq_use_case_tags)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char* documentName = NULL;
	char* s;
	char* moduleAddressS =NULL;
	char* moduleAddressB =NULL;
	char* itemid =NULL;
	char* partsub =NULL;
	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	tag_t queryTag = NULLTAG;
	moduleAddressB = (char *)MEM_alloc(200);
	moduleAddressS = (char *)MEM_alloc(200);
	partsub = (char *)MEM_alloc(200);
	tag_t *dfq_use_case_tags1 = NULLTAG;


	/*--------------------------------------------------------
		Get Applicable DFQ USE CASE
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"bl_Design Revision_t5_ModuleAddress",&moduleAddressS);
	printf("Module Address  ::2222222 %s\n",moduleAddressS);fflush(stdout);

	AOM_ask_value_string(PartTag,"bl_item_item_id",&itemid);
	printf("part number is 2 %s\n",itemid);fflush(stdout);
    partsub=subString(itemid,4,5);
	printf("substring is %s\n",partsub);fflush(stdout);


	if(tc_strcmp(moduleAddressS,"")==0)
	{

	 printf("\n Inside the module address balank conditoin \n");fflush(stdout);

	 tc_strcpy(moduleAddressB,"");
	 tc_strcat(moduleAddressB,"M");
	 moduleAddressS=tc_strcat(moduleAddressB,partsub);
	 printf("substring is %s\n",partsub);fflush(stdout);
	 printf("Module is in blank condition %s\n",moduleAddressB);fflush(stdout);
	
	
	}

	queryTag = NULLTAG;
	status =  QRY_find2("DFQ Use Case", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}
	else
	{
      printf("Tag found query\n");fflush(stdout);
	}

	if(tc_strcmp(t5_business_unit_type_mod,"CVBU") == 0) t5_business_unit_type_mod = "CV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU") == 0) t5_business_unit_type_mod = "PV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU and CVBU Both") == 0) t5_business_unit_type_mod = "PSE";
	else
	{
			EMH_ask_error_text( status, &s);
			MEM_free(s);
			return status;
	}

	//Query DFQ Use Case
	documentName = NULL;
	documentName = (char *)MEM_alloc(50);
	tc_strcpy(documentName, "DVA_");
	tc_strcat(documentName, t5_business_unit_type_mod);
	tc_strcat(documentName, "_");
	tc_strcat(documentName, moduleAddressS);
	tc_strcat(documentName, "*");

	qry_values1[0] = (char *)MEM_alloc(strlen(documentName ) + 1);
	tc_strcpy(qry_values1[0], documentName);

	//qry_values1[1] = (char *)MEM_alloc(10);
	//tc_strcpy(qry_values1[1], "DFQ Use Case");

    qry_entries[0] = (char *)MEM_alloc(10);
	strcpy(qry_entries[0], "Name");

	//qry_entries[1] = (char *)MEM_alloc(10);
	//strcpy(qry_entries[1], "Type");
	//strcpy(qry_entries[1], "object_type");

  

   printf("Name is  :: %s\n",qry_values1[0]);fflush(stdout);
  // printf("Type is  :: %s\n",qry_values1[1]);fflush(stdout);


	ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values1, &resultCount1, &dfq_use_case_tags1));
	printf("\nNo. of DFQ Use Case Document found are %d -- %s\n",resultCount1,documentName);fflush(stdout);

	if(resultCount1 > 0)
	{
		*dfq_use_case_tags = dfq_use_case_tags1;
		*resultCount = resultCount1;
	}
	else
	{

	printf("\n inside the else condition\n");
      // int abd=0;
     resultCount1 = 0;
	 *resultCount = resultCount1;

	 printf("\nresult count1 %d \n",resultCount1);fflush(stdout);
	
	}

	return 0;
}


extern int ITK_user_main(int argc, char ** argv )
{
	int status				= ITK_ok;
	char *fromdate			= NULL;
	char *todate			= NULL;
	char *type				= NULL;
	int i = 0;
	int n_entries;
	int n_entries1;

	tag_t queryTag			= NULLTAG;
	tag_t queryTag1			= NULLTAG;
	int resultCount			= 0;
	int resultCount11			= 0;
	tag_t *ERCDMLTags		= NULLTAG;
	tag_t *ERCDMLTags1		= NULLTAG;
	tag_t ERCDMLTag			= NULLTAG;
	tag_t ERCDMLTag1			= NULLTAG;
	tag_t objTypeTag		= NULLTAG;
	//char  type_name[TCTYPE_name_size_c+1];

	char *DmlId = NULL;
	char *type_name = NULL;
	char *DmlIdDup = NULL;
	char *DmlRelType = NULL;
	char *DmlRelTypeDup = NULL;
	char *DmlRelStat = NULL;
	char *DmlRelStatDup = NULL;


	tag_t* TechSPecObjSet	= NULLTAG;
	int TechSpecCount		= 0;
	tag_t TechSPecObj		= NULLTAG;
	char *descDup			= NULL;

	tag_t snapshotObj		= NULLTAG;
	int snapshotCount		= 0;
	tag_t* snapshotObjSet	= NULLTAG;
	char snapshotObjtype_name[TCTYPE_name_size_c+1];
	tag_t snapshotObjTypeTag = NULLTAG;
	char* snapshot_itemid	 = NULL;
	char* SSTopLineRev		 = NULL;

	char** bufferedXmlStrOut;
	int buff_cnt=0;

	int vcattr =0;
	struct VCAttrDetails VCAttrDetailsList[5000];
	descDup = (char *)malloc(500 * sizeof(char));

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	fromdate = ITK_ask_cli_argument("-fromdate=");
	todate = ITK_ask_cli_argument("-todate=");
	type = ITK_ask_cli_argument("-type=");

	OUTS("ERC DML Query fromdate",10,15, fromdate);
	OUTS("ERC DML Query fromdate",10,15, todate);
	OUTS("ERC DML Query fromdate",10,13, type);

	
	n_entries = 3;
	char *qry_entries[3] = {"Name","date_released_after","date_released_before"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	qry_values[0] = (char *)MEM_alloc( strlen( "T5_LcsErcRlzd" ) + 1);
	strcpy(qry_values[0], "T5_LcsErcRlzd" );

	//qry_values[1] = (char *)MEM_alloc( strlen( "01-Mar-2021 00:00" ) + 1);
	qry_values[1] = (char *)MEM_alloc( strlen( fromdate ) + 1);
	//strcpy(qry_values[1], "01-Mar-2021 00:00"  );
	strcpy(qry_values[1], fromdate  );

	//qry_values[2] = (char *)MEM_alloc( strlen( "04-Mar-2021 00:00" ) + 1);
	qry_values[2] = (char *)MEM_alloc( strlen( todate ) + 1);
	//strcpy(qry_values[2], "04-Mar-2021 00:00"  );
	strcpy(qry_values[2], todate  );

		
	n_entries1 = 3;
	char *qry_entries1[3] = {"Name","date_released_after","date_released_before"};
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));

	qry_values1[0] = (char *)MEM_alloc( strlen( "T5_LcsErcRlzd" ) + 1);
	strcpy(qry_values1[0], "T5_LcsErcRlzd" );

	//qry_values[1] = (char *)MEM_alloc( strlen( "01-Mar-2021 00:00" ) + 1);
	qry_values1[1] = (char *)MEM_alloc( strlen( fromdate ) + 1);
	//strcpy(qry_values[1], "01-Mar-2021 00:00"  );
	strcpy(qry_values1[1], fromdate  );

	//qry_values[2] = (char *)MEM_alloc( strlen( "04-Mar-2021 00:00" ) + 1);
	qry_values1[2] = (char *)MEM_alloc( strlen( todate ) + 1);
	//strcpy(qry_values[2], "04-Mar-2021 00:00"  );
	strcpy(qry_values1[2], todate  );

   if( QRY_find2("ERCDMLInManager", &queryTag1));
	printf("\n After ERCDMLInManager :  QRY_find2 \n");fflush(stdout);
	if (queryTag1)
	{
		printf("\n Found Query ERCDMLInManager  \n");fflush(stdout);
	}
	else
	{
		printf("\n NotFound Query ERCDMLInManager");fflush(stdout);
		goto CLEANUP;
	}


	if( QRY_find2("ERCDMLReleased", &queryTag));
	printf("\n After ERCDMLReleased :  QRY_find2 \n");fflush(stdout);
	if (queryTag)
	{
		printf("\n Found Query ERCDMLReleased  \n");fflush(stdout);
	}
	else
	{
		printf("\n NotFound Query ERCDMLReleased");fflush(stdout);
		goto CLEANUP;
	}

	if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &ERCDMLTags));

	if(QRY_execute(queryTag1, n_entries1, qry_entries1, qry_values1, &resultCount11, &ERCDMLTags1));

    printf("\t resultCount :%d:\n", resultCount);fflush(stdout);
    printf("\t resultCount1 :%d:\n", resultCount11);fflush(stdout);

	printf("\n MIS_VC_DateWise_Rep fromdate: [%s] , todate: [%s]",fromdate,todate);fflush(stdout);

	if( resultCount > 0)
	{
		for (i=0;i<resultCount;i++ )
		{
			ERCDMLTag = ERCDMLTags[i];
           // printf("\t testcnt :%d:\n", i);fflush(stdout);
			if(TCTYPE_ask_object_type(ERCDMLTag,&objTypeTag));
			if( TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n ErcDmlTag -> objTypeTag  %s\n", type_name);fflush(stdout);

			OUTS("type_name",10,15,type_name);

			if(strcmp(type_name,"ChangeRequestRevision")==0)
				{
				ITK_CALL(AOM_ask_value_string(ERCDMLTag,"item_id",&DmlId));
				tc_strdup(DmlId,&DmlIdDup);
				ITK_CALL(AOM_ask_value_string(ERCDMLTag,"t5_rlstype",&DmlRelType));
				tc_strdup(DmlRelType,&DmlRelTypeDup);
				ITK_CALL(AOM_UIF_ask_value(ERCDMLTag,"release_status_list",&DmlRelStat));
				tc_strdup(DmlRelStat,&DmlRelStatDup);

				printf("\nDmlIdDup [%s] DmlRelTypeDup [%s] DmlRelStatDup [%s]  \n",DmlIdDup,DmlRelTypeDup,DmlRelStatDup);fflush(stdout);

				//if(tc_strcmp(DmlRelTypeDup,"Veh")==0 || tc_strcmp(DmlRelTypeDup,"TODR")==0 || tc_strcmp(DmlRelTypeDup,"MR")==0)
				if(tc_strcmp(DmlRelTypeDup,"Veh")==0 )
				{

					
					int tskcnt =0,t=0,p=0;
					tag_t *SetOfDmlTasksTag= NULLTAG;
					char *TaskId=NULL;
					int partCnt=0;
					tag_t *SetOfPartTags= NULLTAG;

					ITK_CALL(AOM_ask_value_tags(ERCDMLTag,"T5_DMLTaskRelation",&tskcnt,&SetOfDmlTasksTag));
					printf("\nDML Task Count : %d\n",tskcnt);fflush(stdout);

					if (tskcnt>0)
					{
						for(t=0;t<tskcnt;t++)
						{
							ITK_CALL(AOM_ask_value_string(SetOfDmlTasksTag[t],"item_id",&TaskId));
							printf("\nDML Task [%s]",TaskId);fflush(stdout);

							if (tc_strstr(TaskId,"APL")!=NULL)
							{
								printf("\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
								continue;
							}

							AOM_ask_value_tags(SetOfDmlTasksTag[t],"CMHasSolutionItem",&partCnt,&SetOfPartTags);
							printf("\nNo of Design Rev=%d\n",partCnt);
							if (partCnt>0)
							{
								char *PartNum=NULL;
								char *PartNumDup=NULL;
								char *PartRev=NULL;
								char *PartRevDup=NULL;
								char *PartRelStat=NULL;
								tag_t PartTag= NULLTAG;
								char *part_type=NULL;
								char *part_typeDup=NULL;
								char *desc=NULL;
								char *descDup=NULL;
								char *ModuleAddress=NULL;
								char *ModuleAddressDup=NULL;
								char *partsts=NULL;
								char *partstsDup=NULL;
								char *prjcode=NULL;
								char *prjcodeDup=NULL;
								char* PartColInd = NULL;
								char* PartColIndDup = NULL;
								char *ColorIDPart = NULL;
								char *ColorIDPartDup = NULL;
								char *UrnCode = NULL;
								char *prepartsts = NULL;
								char* PrerevDRstat	 = NULL;

								char* ProjVehclass = NULL;
								char* ProjVehclassDup = NULL;
								char* Projplnname = NULL;
								char* ProjplnnameDup = NULL;
								char* Projbuss = NULL;
								char* ProjbussDup = NULL;
								char* Projdesc = NULL;
								char* ProjdescDup = NULL;

								PrerevDRstat	=	(char	*)MEM_alloc(10);
								char* FirstrlzDR4	 = NULL;
								FirstrlzDR4	=	(char	*)MEM_alloc(10);

								char* Owner	= NULL;
								Owner = (char *)MEM_alloc(50);

								//displaying_objects();
								for(p=0;p<partCnt;p++)
								{
									PartTag=SetOfPartTags[p];

									printf("\n Part Class [%s]",type_name); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
									tc_strdup(PartNum,&PartNumDup);

									ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_CategoryName",&desc));
									tc_strdup(desc,&descDup);
									STRNG_replace_str(descDup,","," ",&descDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
									tc_strdup(PartRev,&PartRevDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ModuleAddress",&ModuleAddress));
									tc_strdup(ModuleAddress,&ModuleAddressDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartStatus",&partsts));
									tc_strdup(partsts,&partstsDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&PartColInd));
									tc_strdup(PartColInd,&PartColIndDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ProjectCode",&prjcode));
									tc_strdup(prjcode,&prjcodeDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
									tc_strdup(part_type,&part_typeDup);
									printf("\nPart type is*** [%s]",part_typeDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&PartRelStat));

									if(tc_strstr(PartRelStat,"ERC Released")==NULL)
									{
										printf("\nPart [%s] is not ERC Released LifeCycleState [%s] Skipping...",PartNum,PartRelStat); fflush(stdout);
										continue;
									}
									else
									{
										printf("\nPart [%s] Release Status [%s]",PartNum,PartRelStat); fflush(stdout);
										tc_strcpy(Owner,"Release Vault");
									}
									printf("\n PartNum [%s] PartRev [%s] PartColInd [%s] part_type[%s]",PartNum,PartRev,PartColInd,part_type); fflush(stdout);




									//if((tc_strcmp(part_typeDup,"V")==0) || (tc_strcmp(part_typeDup,"VC")==0) || (tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0))
									/*if((tc_strcmp(part_typeDup,"M")==0) && (tc_strcmp(DmlRelTypeDup,"MR")==0) && (tc_strcmp(type,"M")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{
										//tc_strcat(fsuccess_name,"/user/cvprod/MIS_Client_Code_CV/Reports/");
										sprintf(fsuccess_name,"%s_%s_%s_%s.csv",PartNum,fromdate,todate,type);
	                                    fsuccess = fopen(fsuccess_name,"w");

	                                  fprintf(fsuccess,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update\n");

										int revi = 0, revCnt = 0, preOffDR4 = 0, preOffDRstat = 0, ChkpreRev= 0;
										tag_t *allRevTag	 = NULLTAG;
										char* CurRev		 = NULL;
										char* CurSeq		 = NULL;
										tag_t relTypeTag = NULLTAG;
										tag_t* DVA_document_tags = NULLTAG;
										logical dfq_applicability;;
										int DVA_result_count = 0;
										int d = 0;
										int k = 0;

										logical DFQApplicablilitycheck	= 0;
										logical DFQApplicablility	= 0;
										char* DFQApplicablilityDup	= NULL;
										//DFQApplicablilityDup = (char *)MEM_alloc(100);

										double Designnominal;
										double Definedtarget;
										double Achievednominal;
										double Achievedtarget;
										double CpkDup;

										char* DFQdocno				= NULL;
										char* DFQdocnoDup			= NULL;
										char* DFQUID				= NULL;
										char* DFQUIDDup				= NULL;
										char* DVADesc				= NULL;
										char* DVADescDup			= NULL;
										char* DFQComment			= NULL;
										char* DFQCommentDup			= NULL;
										char* Meetexpectations		= NULL;
										char* MeetexpectationsDup	= NULL;
										char* Foundpdf				= NULL;
										char* Foundexcel			= NULL;
										date_t Lastmoddate;
										char* LastmoddateDup		= NULL;
                                        char*MeetexpectationDupMMM=NULL;

										int resultCount1 = 0;
										tag_t* dfq_use_case_tags = NULLTAG;

										int nFoundpdf= 0;
										int nFoundexcel= 0;
										int trueflag= 0;
										int falseflag= 0;
										tag_t* refobjpdf  = NULLTAG;
										tag_t* refobjexcel  = NULLTAG;

                                        char* DVADescDup1			= NULL;
                                        char* DVADescDup2			= NULL;
										DVADescDup	=	(char	*)MEM_alloc(100);
										DVADescDup1	=	(char	*)MEM_alloc(100);
										DVADescDup2	=	(char	*)MEM_alloc(100);

										CurRev = strtok(PartRevDup,";");
										CurSeq = strtok(NULL,";");

										printf("\n Current Revision is %s",CurRev);fflush(stdout);
										printf("\n Current Sequence is %s",CurSeq);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(GetDVAUseCaseFromLibrary(PartTag, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount1);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTag);

										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(PartTag, relTypeTag, &DVA_result_count,&DVA_document_tags));
										printf("\n No of Attached DFQ Documetns are :: %d\n",DVA_result_count);fflush(stdout);


										if (DVA_result_count >0)
										{
											for (k=0;k<DVA_result_count; k++ )
											{
												AOM_ask_value_logical(DVA_document_tags[k],"t5_DFQApplicablility",&DFQApplicablilitycheck);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck);

												if(DFQApplicablilitycheck == 1)
												{
													trueflag++;
												}
												else
												{
													falseflag++;
												}
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumDup,CurRev,CurSeq,partstsDup,ModuleAddressDup,PrerevDRstat,ProjbussDup,descDup,Owner);fflush(stdout);
										fprintf(fsuccess,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",PartNumDup,CurRev,CurSeq,partstsDup,ModuleAddressDup,ProjbussDup,descDup,Owner,resultCount1,falseflag,trueflag);

										if (DVA_result_count >0)
										{
											for (d=0;d<DVA_result_count; d++ )
											{
												AOM_ask_value_string(DVA_document_tags[d],"current_name",&DFQdocno);
												tc_strdup(DFQdocno,&DFQdocnoDup);

												AOM_ask_value_string(DVA_document_tags[d],"t5_DFQUID",&DFQUID);
												tc_strdup(DFQUID,&DFQUIDDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tags[d],"object_desc",&DVADesc));
												tc_strdup(DVADesc,&DVADescDup1);

												STRNG_replace_str(DVADescDup1,","," ",&DVADescDup2);
												STRNG_replace_str(DVADescDup2,"@"," ",&DVADescDup);

												AOM_ask_value_logical(DVA_document_tags[d],"t5_DFQApplicablility",&DFQApplicablility);

												printf("\n DFQApplicablility [%d] ",DFQApplicablility);

												if(DFQApplicablility == 1)
												{
													tc_strdup("Yes",&DFQApplicablilityDup);
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilityDup);fflush(stdout);
												}
												else
												{
													tc_strdup("No",&DFQApplicablilityDup);
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilityDup);fflush(stdout);
												}

												ITK_CALL(AOM_ask_value_string(DVA_document_tags[d],"t5_DFQComment",&DFQComment));
												tc_strdup(DFQComment,&DFQCommentDup);

												STRNG_replace_str(DFQCommentDup,","," ",&DFQCommentDup);
												STRNG_replace_str(DFQCommentDup,"\n"," ",&DFQCommentDup);

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tags[d],"T5_DFQ_PDF",&nFoundpdf,&refobjpdf));
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tags[d],"T5_DFQ_EXCEL",&nFoundexcel,&refobjexcel));

												printf("*n Foundpdf --- %d* \n",nFoundpdf);fflush(stdout);
												printf("*n Foundexcel --- %d* \n",nFoundexcel);fflush(stdout);

												if (nFoundpdf == 0)
												{
													tc_strdup("No",&Foundpdf);
												}else{
													tc_strdup("Yes",&Foundpdf);
												}

												if (nFoundexcel == 0)
												{
													tc_strdup("No",&Foundexcel);
												}else{
													tc_strdup("Yes",&Foundexcel);
												}

												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQDesNom",&Designnominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DNDefTarget",&Definedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQAchNom",&Achievednominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_ANDefTarget",&Achievedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQCpkVal",&CpkDup));

												ITK_CALL(AOM_ask_value_string(DVA_document_tags[d],"t5_DFQMeetExp",&Meetexpectations));
												tc_strdup(Meetexpectations,&MeetexpectationsDup);

												if(tc_strcmp(MeetexpectationsDup,"N")==0)
												{

                                                     tc_strdup("No",&MeetexpectationDupMMM);
												}
												if(tc_strcmp(MeetexpectationsDup,"Y")==0)
												{
                                                      tc_strdup("Yes",&MeetexpectationDupMMM);
												}
												if(tc_strcmp(MeetexpectationsDup,"NA")==0)
												{
                                                      tc_strdup("NA",&MeetexpectationDupMMM);
												}

												//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

												ITK_CALL(AOM_ask_value_date(DVA_document_tags[d],"last_mod_date",&Lastmoddate));
												ITK_CALL(DATE_date_to_string(Lastmoddate,"%d/%m/%Y",&LastmoddateDup));

												printf("\n DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",DFQUIDDup,DVADescDup,DFQApplicablilityDup,DFQCommentDup,DFQdocnoDup,Foundpdf,Foundexcel,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationsDup,LastmoddateDup);fflush(stdout);
												fprintf(fsuccess,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDDup,LastmoddateDup,DFQApplicablilityDup,DFQCommentDup,DFQdocnoDup,Foundpdf,Foundexcel,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationDupMMM,DVADescDup);
											}
										}
										fclose(fsuccess);
									}*/
									//else if ((tc_strcmp(part_typeDup,"V")==0) && (tc_strcmp(DmlRelTypeDup,"Veh")==0) && (tc_strcmp(type,"V")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									if ((tc_strcmp(part_typeDup,"V")==0) && (tc_strcmp(DmlRelTypeDup,"Veh")==0) && (tc_strcmp(type,"V")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{

										printf("\n first conditin part_type [%s] DmlRelStatDup [%s] PartNum [%s] \n",part_typeDup,DmlRelTypeDup,PartNum);fflush(stdout);
										
										char *VPrtModNum=NULL;
	                                    char *VPrtModNumType=NULL;
                                        tag_t	bom_wnd				=	NULLTAG;
                                        tag_t	rule				=	NULLTAG;
                                        tag_t	top_lne				=	NULLTAG;
										//int		n_count			=	0;
                                        int count=0;
										int		ichld			=	0;
										tag_t	*ArchNodeLines		=	NULLTAG;

	                                    tag_t	*ColIndChilds		=	NULLTAG;
	                                    tag_t	Childobject			=	NULLTAG;
										char* Owners	= NULL;
								         Owners = (char *)MEM_alloc(50);
                                         char *PartNums=NULL;
										 char *PartNumsDup=NULL;
										 char *PartNumstypDup=NULL;
										 char*PartNumstyp=NULL;
                                         char *descp=NULL;
										 char *descpDup=NULL;
                                         char *PartRevs=NULL;
										 char *PartRevsDup=NULL;
										 char *ModuleAddressp=NULL;
										 char *ModuleAddresspDup=NULL;
                                         char *partst=NULL;
										 char *partstDup=NULL;
										 char *PartRelStats=NULL;
										 char* CurRevs		 = NULL;
										char* CurSeqs		 = NULL;
										char *CurRe=NULL;
										char*CurSe=NULL;
										char*VPrtdesc=NULL;
										char*PsProgScale=NULL;
										int i=0;
										tag_t relTypeTags = NULLTAG;
										tag_t ItemTypeTag=NULLTAG;
										tag_t* DVA_document_tag = NULLTAG;
										int DVA_result_counts=0;
                                         int resultCount=0;
										 logical DFQApplicablilitycheck1= 0;
										 logical DFQApplicablilitys=0;
										 // int trueflagg=0;
										 // int falseflagg=0;
                                          int d=0;
                                       char* DFQdocnos				= NULL;
										char* DFQdocnosDup			= NULL;
										char* DFQUIDs				= NULL;
										char* DFQUIDsDup				= NULL;
										char* DVADescs				= NULL;
										char* DVADescsDup			= NULL;
										char* DFQComments			= NULL;
										char* DFQCommentsDup			= NULL;
										char* Meetexpectation		= NULL;
										char* MeetexpectationDup	= NULL;
										char* Foundpdfs				= NULL;
										char* Foundexcels			= NULL;
										date_t Lastmoddates;
										char* LastmoddatesDup		= NULL;
                                        char* DFQApplicablilitysDup=NULL;
										char*ItemType=NULL;
										int nFoundpdfs= 0;
										int nFoundexcels= 0;

										tag_t* refobjpdfs  = NULLTAG;
										tag_t* refobjexcels  = NULLTAG;

										double Designnominals;
										double Definedtargets;
										double Achievednominals;
										double Achievedtargets;
										double CpkDups;
                                        tag_t* dfq_use_case_tags = NULLTAG;
										char* ProjdescDup = NULL;
                                        char*Projname=NULL;
                                        char*MeetexpectationDupMM=NULL;
										char			Data[100]					= "";
										tag_t GCI_relation=NULLTAG;
										tag_t*GciObj=NULLTAG;
										int GCI=0;
										int Demerit_rating=0;
										int Demerit=0;
										double GCIind =0;
										int gc=0;
										tag_t GCItag=NULLTAG;
									
                                  time_t 	now;
	                              struct 	tm when;

								  PIE_scope_t scope;
	                              scope=PIE_TEAMCENTER;
								  int rulefound= 0;
								  tag_t *closurerule = NULLTAG;
								  tag_t close_tag = NULLTAG;
								  tag_t bom_variant_rule = NULLTAG;
								  tag_t objTypeTag=NULLTAG;
								  char type_name[TCTYPE_name_size_c+1];
								  tag_t e_block		= NULLTAG;
								  char **rulename = NULL;
	                              char **rulevalue = NULL;
	                              char *VPrtdescdup5 = NULL;
	                              char *VPrtdescdup6 = NULL;
	                              char *DVADescsDup3 = NULL;
	                              char *DVADescsDup4 = NULL;
	                              char *DVADescsDupJ5 = NULL;
								  VPrtdescdup6 = (char *)MEM_alloc(100);
								  VPrtdescdup5 = (char *)MEM_alloc(100);
								  DVADescsDup3 = (char *)MEM_alloc(100);
								  DVADescsDup4 = (char *)MEM_alloc(100);
								  DVADescsDupJ5 = (char *)MEM_alloc(100);
								  DVADescsDup = (char *)MEM_alloc(100);
								  char *VPrtdescdup2 = NULL;
								  VPrtdescdup2 = (char *)MEM_alloc(100);
								  int des =0;

	                             time(&now);
	                            when = *localtime(&now);
                               strftime(Data,100,"%Y/%b/%d-%H_%M_%S",&when);


										ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&VPrtModNum));
	                                    ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&VPrtModNumType));
                                     printf("\nV number is [%s]",VPrtModNum); fflush(stdout);
									 CurRe = strtok(VPrtModNumType,";");
										CurSe = strtok(NULL,";");

										ITK_CALL(AOM_ask_value_string(PartTag,"object_desc",&VPrtdesc));
										printf("\nV part desc before1 [%s]",VPrtdesc); fflush(stdout);
										tc_strdup(VPrtdesc,&VPrtdescdup5);
										//STRNG_replace_str(VPrtdescdup,","," ",&VPrtdescdup1);
										STRNG_replace_str(VPrtdescdup5,","," ",&VPrtdescdup6);
										STRNG_replace_str(VPrtdescdup6,"."," ",&VPrtdescdup2);

										printf("\nV part desc After dup1[%s]",VPrtdescdup6); fflush(stdout);
										printf("\nV part desc After dup3[%s]",VPrtdescdup2); fflush(stdout);
										

										ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_ProgramScale",&PsProgScale));
										printf("\nV program scale is [%s]",PsProgScale); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(getBusinessUnitFun(PartTag, &ProjdescDup,&Projname));
										printf("\n Project Descp :[%s]\n",ProjdescDup);   fflush(stdout);

										//ITK_CALL(getBusinessUnit(PartTag, &Projname));
										printf("\n Project Name :[%s]\n",Projname);   fflush(stdout);

										ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

										ITK_CALL(GRM_list_secondary_objects_only(PartTag,GCI_relation,&GCI,&GciObj));

										if(GCI>0)
										{
											for(gc=0;gc<GCI;gc++)
													{
														printf("\n inside for loop gc count****.\n");fflush(stdout);

														GCItag=GciObj[gc];

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&Demerit));
														printf("\n Demerit :[%d]\n",Demerit);fflush(stdout);
                                                       
														
														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_rating_S1",&Demerit_rating));
														printf("\n Demerit_rating :[%d]\n",Demerit_rating);fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCItag,"t5_geometry_conf_index_a1",&GCIind));
														printf("\n GCIind:[%lf]\n",GCIind);fflush(stdout);
                                                    }
										}
										  




                        //tc_strcat(fsuccess_nam,"/user/cvprod/MIS_Client_Code_CV/Reports/");
                        //sprintf(fsuccess_nam,"/user/cvprod/MIS_Client_Code_CV/Reports/MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname);
                        sprintf(fsuccess_nam,"MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname);
	                    file = fopen(fsuccess_nam,"w");


                     if(GciObj==0)
					{

                      printf("\n inside GCI object count is Zero.\n");fflush(stdout);

                     fprintf(file,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
					 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
					 fprintf(file,",,,Description,%s,,Program Scale,%s,,,\n",VPrtdescdup2,PsProgScale);
					 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
                     fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
                     fprintf(file,",,,Last Updated,,,,,,,\n");
                     fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
					 fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
                     if(Demerit)
					 {
                        fprintf(file,",,,Demerit Score(V),%d,,,,,,\n","Nil");                                  
					 }
					 else{
						 fprintf(file,",,,Demerit Score(V),%s,,,,,,\n","Nil");
					 }
					 if(Demerit_rating)
					{
                      fprintf(file,",,,Demerit Score Rating(S),%d,,,,,,\n","Nil");
					}
					 else
					{	
					 fprintf(file,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
					}
					if(GCIind)
					{
                      fprintf(file,",,,Geometry conformance Index(A),%lf,,,,,,\n","Nil");
					}
					else{

					 fprintf(file,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
					}
                     fprintf(file,"\n\n");
					}
					else if (GciObj>0)
					{

						printf("\n inside GCI object count is one\n");fflush(stdout);
					
                     fprintf(file,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
					 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
					 fprintf(file,",,,Description,%s,,Program Scale,%s,,,\n",VPrtdescdup2,PsProgScale);
					 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
                     fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
                     fprintf(file,",,,Last Updated,,,,,,,\n");
                     fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
					 fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
                     if(Demerit)
					 {
                        fprintf(file,",,,Demerit Score(V),%d,,,,,,\n",Demerit);                                  
					 }
					 else{
						 fprintf(file,",,,Demerit Score(V),%s,,,,,,\n","Nil");
					 }
					 if(Demerit_rating)
					{
                      fprintf(file,",,,Demerit Score Rating(S),%d,,,,,,\n",Demerit_rating);
					}
					 else
					{	
					 fprintf(file,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
					}
					if(GCIind)
					{
                      fprintf(file,",,,Geometry conformance Index(A),%lf,,,,,,\n",GCIind);
					}
					else{

					 fprintf(file,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
					}
                     fprintf(file,"\n\n");
					
					}

fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update\n");





										if(PartTag!=NULLTAG)
	                                  {
										    ITKCALL(BOM_create_window(&bom_wnd ));      //set new bom window
											ITK_CALL ( BOM_set_window_top_line( bom_wnd, NULLTAG, PartTag, NULLTAG, &top_lne ));
											ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE)); 
		                                    ITKCALL(CFM_find("ERC release and above", &rule));  //find the revision rule
											ITKCALL(BOM_set_window_config_rule(bom_wnd, rule));  // set revision rule for window

											//ITK_CALL( PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
											ITK_CALL( PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));

					                        printf ("vc_rule count %d \n",rulefound);fflush(stdout);
					                        
					                        if (rulefound > 0)
					                        {
					                        	close_tag = closurerule[0];
					                        	printf (" vc closure rule found \n");fflush(stdout);
					                        	// MEM_free(tags_found);
					                        }

											ITK_CALL(BOM_window_set_closure_rule( bom_wnd,close_tag, 0, rulename,rulevalue ));

					                       
					                       
                                            if(top_lne!=NULLTAG)
										  {  
                                             printf (" vc top found \n");fflush(stdout);
										  }
					                        printf( " vc_After BOM_set_window_top_line..\n");fflush(stdout);

//											ITK_CALL (  BOM_window_ask_variant_rules( bom_wnd,&bomcoutn,&bomcoutn,&bom_variant_rule ));
//					                        printf( " vc_release  BOM_window_ask_variant_rules..\n");fflush(stdout);
//											if(bom_variant_rule!=NULLTAG)
//										  {  
//                                             printf (" bom_variant_rule found \n");fflush(stdout);
//										  }
//
//											ITK_CALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
//					                        ITK_CALL( TCTYPE_ask_name2(objTypeTag,&type_name));
//											if(objTypeTag!=NULLTAG)
//										  {  
//                                             printf (" objTypeTag found \n");fflush(stdout);
//										  }

											ITK_CALL ( ITEM_ask_rev_variants ( PartTag, &e_block ));
					                        printf(" vc_ITEM_ask_rev_variants..\n");fflush(stdout);
											if(e_block!=NULLTAG)
										  {  
                                             printf (" e_block found \n");fflush(stdout);
										  }
					                        
											
                                           // ITKCALL(BOM_set_window_top_line( bom_wnd, NULLTAG, PartTag, NULLTAG, &top_lne ));



											if(top_lne!=NULLTAG)
		                                   {
			                                // ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
			                               //  printf("\n n_count --------> : %d\n", n_count);

										   ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
//										   if(ColIndChilds!=NULLTAG)
//										  {  
//                                             printf (" ColIndChilds found \n");fflush(stdout);
//										  }

										   ITK_CALL(BOM_window_hide_unconfigured(bom_wnd))   ;
						                   ITK_CALL(BOM_window_show_variants(bom_wnd))   ;

										   printf("\n vc_release After inside bom_window-----\n"); fflush(stdout);
						                   ITK_CALL(BOM_window_apply_variant_configuration(bom_wnd,1,&PartTag))   ;
						                   printf("\n vc_release After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
										    if(PartTag!=NULLTAG)
										  {  
                                             printf (" PartTag found \n");fflush(stdout);
										  }


                                           ITK_CALL(BOM_window_hide_variants(bom_wnd))   ;

						                  ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
//										   if(ColIndChilds!=NULLTAG)
//										  {  
//                                             printf (" ColIndChilds1 found \n");fflush(stdout);
//										  }

						                  printf("\n vcBom_count --------> : [%d]  ",count); fflush(stdout);
			                                 //ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
			                                // printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node

			                                 if (count >0)
			                                 {
				                              for (ichld=0;ichld<count ;ichld++ )
				                               {
					                           // if(Childobject) Childobject=NULLTAG;
					                                 Childobject=ColIndChilds[ichld];


									ITK_CALL(AOM_ask_value_string(Childobject,"bl_item_item_id",&PartNums));
									tc_strdup(PartNums,&PartNumsDup);
									printf("\nPart number is 8 [%s]",PartNumsDup); fflush(stdout);

                                    ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartType",&PartNumstyp));
									tc_strdup(PartNumstyp,&PartNumstypDup);
									printf("\nPart type is [%s]",PartNumstypDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_Design Revision_t5_CategoryName",&descp));
									tc_strdup(descp,&descpDup);
									STRNG_replace_str(descpDup,","," ",&descpDup);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_rev_item_revision_id",&PartRevs));
									tc_strdup(PartRevs,&PartRevsDup);
									printf("\nPart number revision [%s]",PartRevsDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddressp));
									tc_strdup(ModuleAddressp,&ModuleAddresspDup);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartStatus",&partst));
									tc_strdup(partst,&partstDup);


									ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_rev_release_status_list",&PartRelStats));
                                     printf("\nPart release is [%s]",PartRelStats); fflush(stdout);
									if(tc_strstr(PartRelStats,"ERC Released")!=NULL)
									{
										printf("\nPart [%s] Release Status [%s]",PartNums,PartRelStats); fflush(stdout);
										tc_strcpy(Owners,"Release Vault");
									}

									    CurRevs = strtok(PartRevsDup,";");
										CurSeqs = strtok(NULL,";");

										printf("\n Current Revision is %s",CurRevs);fflush(stdout);
										printf("\n Current Sequence is %s",CurSeqs);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);
										if(tc_strcmp(PartNumstypDup,"M")==0)
							          {

                                        ITK_CALL(getBusinessUnitFunct(Childobject, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										resultCount=0;

										ITK_CALL(GetDVAUseCaseFromLibraryt(Childobject, ProjbussDup, &resultCount, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										tag_t itemTag = NULLTAG;
										tag_t itemRevTag = NULLTAG;

										tag_t itemRevTagm1	 =	NULLTAG;
										ITEM_find_item(PartNums, &itemTag);
										//ITEM_ask_latest_rev(itemTag,&itemRevTag);


										ITEM_find_revision(itemTag,PartRevs,&itemRevTagm1);
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);

										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm1, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										printf("\n No of Attached DFQ Documetns are** :: %d\n",DVA_result_counts);fflush(stdout);

										int trueflagg=0;
										int falseflagg=0;

                                        if (DVA_result_counts >0)
										{
											for (i=0;i<DVA_result_counts; i++ )
											{
												AOM_ask_value_logical(DVA_document_tag[i],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												if(DFQApplicablilitycheck1 == 1)
												{
													trueflagg++;
												}
												else
												{
													falseflagg++;
												}
											}
										}

										printf("\n PartNumDup* [%s] CurRev* [%s] CurSeq* [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,PrerevDRstat,ProjbussDup,descpDup,Owners);fflush(stdout);
										fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d\n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,ProjbussDup,descpDup,Owners,resultCount,falseflagg,trueflagg);
                                        resultCount=0;

																		if (DVA_result_counts >0)
																	{
																		for (d=0;d<DVA_result_counts; d++ )
																		{
																			AOM_ask_value_string(DVA_document_tag[d],"current_name",&DFQdocnos);
																			tc_strdup(DFQdocnos,&DFQdocnosDup);

																			AOM_ask_value_string(DVA_document_tag[d],"t5_DFQUID",&DFQUIDs);
																			tc_strdup(DFQUIDs,&DFQUIDsDup);

																			tc_strcpy(DVADescsDup,"");
																			ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[d],"object_desc",&DVADescs));
																			//des=tc_strlen(DVADescs);

																			int an=0;
																			DVADescsDup = (char*)MEM_alloc(1000);
                                                                            
// Testing 

                                                                            int ax=0; 
                                                                            printf(" Value of desc found = %s \n",DVADescs);
                                                                            printf(" Value of DFQdocnos found = %s \n",DFQdocnos);

																			for(ax=0;DVADescs[ax]!='\0';ax++)
																			{
                                                                                printf("\n char found = %c , ascii found = %d \n",DVADescs[ax],DVADescs[ax]);

																				//if(DVADescs[ax]==13)
																				if((DVADescs[ax]==13) || (DVADescs[ax]==10))
																				{
                                                                                    DVADescsDup[an]='\0';
																				}
																				else
																				{
                                                                                     DVADescsDup[an]=DVADescs[ax];
																					 an++;
																				}

																			} 

																			printf(" Length of DVADescs = %d ",tc_strlen(DVADescs));
																			printf(" Length of DVADescsDup = %d ",tc_strlen(DVADescsDup));

																			printf(" DVADescs = %s\n",DVADescs);
																			printf(" DVADescsDup = %s\n",DVADescsDup);







// Testing









//																			des=tc_strlen(DVADescs);
//																			DVADescsDup = (char *)MEM_alloc(des);
//																			//qry_values1[2] = (char *)MEM_alloc( strlen( todate ) + 1);
//																			//STRNG_replace_str(DVADescsDup3,","," ",&DVADescsDup4);
//																			//STRNG_replace_str(DVADescs,"\n",";",&DVADescsDup);
//
//																			tc_strcpy(DVADescsDup,"");
//																			tc_strcat(DVADescsDup,DVADescs);
//																			tc_strcat(DVADescsDup,"");
//																			
//																			x=0;
//																			for(z=0;z<des;z++)
//																			{
//																			
//																			if(DVADescsDup[z]!='\n')
//																			{
//																				printf("\n Inside assif loop\n");
//																			
//																			DVADescsDup[x++]=DVADescsDup[z];
//																			
//																			
//																			}
//																			
//																			
//																			}
//																			DVADescsDup[x]='\0';
//
//
//																			printf("After remove New Line \n %s",DVADescsDup);
//   



																			

//
//
//																			
//																			
//																			printf("\n des len 4 [%d] ",des);
//																			printf("\n DVADescs value is [%s] ",DVADescs);fflush(stdout);
//																			printf("\n DVADescs current_name is [%s] ",DFQdocnos);fflush(stdout);
//																			tc_strcpy(DVADescsDup3,"");
//																			tc_strcpy(DVADescsDup3,DVADescs);
//													    					//tc_strdup(DVADescs,&DVADescsDup3);


//

//																			printf("\n DVADescsDup3 value is 2[%s] ",DVADescsDup3);fflush(stdout);
//
//																			
																			//STRNG_replace_str(DVADescsDupJ5,")"," ",&DVADescsDup);
																			printf("\n DVADescsDup value is 2[%s] ",DVADescsDup);fflush(stdout);

																			STRNG_replace_str(DVADescsDup,","," ",&DVADescsDupJ5);

																			AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitys);

																			printf("\n DFQApplicablility [%d] ",DFQApplicablilitys);

																			if(DFQApplicablilitys == 1)
																			{
																				tc_strcpy(DFQApplicablilitysDup,"");
																				tc_strdup("Yes",&DFQApplicablilitysDup);
																				printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
																			}
																			else
																			{
																				tc_strcpy(DFQApplicablilitysDup,"");
																				tc_strdup("No",&DFQApplicablilitysDup);
																				printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
																			}
//																			STRNG_replace_str(DFQApplicablilitysDup,"\n",",",&DFQApplicablilitysDup1);
//																			printf("\n DFQApplicablilityDup [%s]  DVA name DFQdocnos[%s]",DFQApplicablilitysDup1,DFQdocnos);fflush(stdout);


																			ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQComment",&DFQComments));
																			tc_strdup(DFQComments,&DFQCommentsDup);

																			STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
																			STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

																			ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
																			ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

																			printf("*n Foundpdf --- %d* \n",nFoundpdfs);fflush(stdout);
																			printf("*n Foundexcel --- %d* \n",nFoundexcels);fflush(stdout);

																			if (nFoundpdfs == 0)
																			{
																				tc_strdup("No",&Foundpdfs);
																			}else{
																				tc_strdup("Yes",&Foundpdfs);
																			}

																			if (nFoundexcels == 0)
																			{
																				tc_strdup("No",&Foundexcels);
																			}else{
																				tc_strdup("Yes",&Foundexcels);
																			}

																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQDesNom",&Designnominals));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DNDefTarget",&Definedtargets));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQAchNom",&Achievednominals));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_ANDefTarget",&Achievedtargets));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQCpkVal",&CpkDups));

																			ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQMeetExp",&Meetexpectation));
																			tc_strdup(Meetexpectation,&MeetexpectationDup);

																			if(tc_strcmp(MeetexpectationDup,"N")==0)
																			{

														                         tc_strdup("No",&MeetexpectationDupMM);
																			}
																			if(tc_strcmp(MeetexpectationDup,"Y")==0)
																			{
														                          tc_strdup("Yes",&MeetexpectationDupMM);
																			}
																			if(tc_strcmp(MeetexpectationDup,"NA")==0)
																			{
														                          tc_strdup("NA",&MeetexpectationDupMM);
																			}
																			printf("\n After String replace Veh [%s] ",DVADescsDupJ5);fflush(stdout);

																			//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

																			ITK_CALL(AOM_ask_value_date(DVA_document_tag[d],"last_mod_date",&Lastmoddates));
																			//printf("\n After String replace Veh [%s] ",Lastmoddates);fflush(stdout);
																			ITK_CALL(DATE_date_to_string(Lastmoddates,"%d/%m/%Y",&LastmoddatesDup));

																			printf("\n DFQUIDDup* [%s] DVADescsDupJ5* [%s] DFQApplicablilityDup*  [%s] DFQCommentDup* [%s] DFQdocnoDup* [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",ProjbussDup,DVADescsDupJ5,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDup,LastmoddatesDup);fflush(stdout);
																			fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDupJ5,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDupMM,LastmoddatesDup);
											}
										 }

											   }
											   }
											 }
											
										   }
									  }
									  fclose(file);
								   }
								   else if (((tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0)) && (tc_strcmp(DmlRelTypeDup,"Veh")==0) && (tc_strcmp(type,"VC")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{
									   printf("\n Second conditin part_type [%s] DmlRelStatDup [%s] PartNum [%s] \n",part_typeDup,DmlRelTypeDup,PartNum);fflush(stdout);

                                        char *VCPrtModNum=NULL;
	                                    char *VCPrtModNumType=NULL;
										char *CurReC=NULL;
										char*CurSeC=NULL;
										char*PartNums1=NULL;
										char*PartNums1Dup=NULL;
										char*ModuleName=NULL;
										char*ModuleNameDup=NULL;
										char*ModuleNumstyp=NULL;
										char*ModuleNumstypDup=NULL;
										char*Moduledescp=NULL;
										char*ModuledescpDup=NULL;
										char*ModulePartRevs=NULL;
										char*ModulePartRevsDup=NULL;
										char*ModuleAddre=NULL;
										char*ModuleAddreDup=NULL;
										char*Modulepartst=NULL;
										char*ModulepartstDup=NULL;
										char*ModulePartRelStats=NULL;
										char*ModuleOwners=NULL;
										char*MCurRevs=NULL;
										char*MCurSeqs=NULL;


										tag_t ChildMobject= NULLTAG;
                                        tag_t Snapshot_tag = NULLTAG;
		                                tag_t snapshotObjTypeTag = NULLTAG;
										tag_t *snapshotObjSet = NULLTAG;
										// char snapshotObjtype_name[TCTYPE_name_size_c+1];
		                                 char *ObjName = NULL;
		                                 char *snapshotObjtype_name = NULL;
										 int snapshotCount=0;
										 tag_t item_rev_tags	= NULLTAG;
		                                 char* SSTopLineRev	= NULL;
										 tag_t window		= NULLTAG;
										 int		rulefound		=	0;
	                                     tag_t	*closurerule	=	NULLTAG;
										 PIE_scope_t scope;
	                                     scope=PIE_TEAMCENTER;
										 tag_t	close_tag		=	NULLTAG;
	                                     char	**rulename		=	NULL;
	                                     char	**rulevalue		=	NULL;
										 char *Item_ID_str	= NULL;
										 tag_t top_line		= NULLTAG;
										  int Item_ID=0;
										  tag_t	*ColIndChilds		=	NULLTAG;
									      tag_t	*Modulechilds=NULLTAG;
                                    int count=0;
									int ichld=0;
									int count1=0;
									int chld=0;

									
	                                    tag_t	Childobject1			=	NULLTAG;

										tag_t* DVA_document_tag = NULLTAG;
										int DVA_result_counts=0;
                                         
										 logical DFQApplicablilitys1= 0;
										 logical DFQApplicablilitys=0;
										 
                                          int d=0;
										  int j=0;
                                       char* DFQdocnos				= NULL;
										char* DFQdocnosDup			= NULL;
										char* DFQUIDs				= NULL;
										char* DFQUIDsDup				= NULL;
										char* DVADescs				= NULL;
										char* DVADescsDup			= NULL;
										char* DFQComments			= NULL;
										char* DFQCommentsDup			= NULL;
										char* Meetexpectation		= NULL;
										char* MeetexpectationDup	= NULL;
										char*MeetexpectationDupM=NULL;
										char* Foundpdfs				= NULL;
										char* Foundexcels			= NULL;
										date_t Lastmoddates;
										char* LastmoddatesDup		= NULL;
                                        char* DFQApplicablilitysDup=NULL;
										char*ItemType=NULL;
										int nFoundpdfs= 0;
										int nFoundexcels= 0;

										tag_t* refobjpdfs  = NULLTAG;
										tag_t* refobjexcels  = NULLTAG;

										double Designnominals;
										double Definedtargets;
										double Achievednominals;
										double Achievedtargets;
										double CpkDups;
                                        tag_t* dfq_use_case_tags = NULLTAG;
										tag_t relTypeTags = NULLTAG;
										char* ProjdescDup = NULL;
                                        char*Projname=NULL;
										Projname = (char *)MEM_alloc(50);
										char*VPrtdescM=NULL;
										char*PsProgScaleCC=NULL;
										tag_t GCI_relation=NULLTAG;
										tag_t*GciObj=NULLTAG;
										int GCI=0;
										int Demerit_rating=0;
										int Demerit=0;
										double GCIind;
										int gc=0;
										tag_t GCItag=NULLTAG;
										char *VPrtdescMdup = NULL;
										char *VPrtdescMdup1 = NULL;
										char *VPrtdescMdup2 = NULL;
										char *DVADescsDup6 = NULL;
										char *DVADescsDup7 = NULL;
								        VPrtdescMdup1 = (char *)MEM_alloc(100);
								        VPrtdescMdup = (char *)MEM_alloc(100);
								        VPrtdescMdup2 = (char *)MEM_alloc(100);
								        DVADescsDup6 = (char *)MEM_alloc(100);
								        DVADescsDup7 = (char *)MEM_alloc(100);
								        DVADescsDup = (char *)MEM_alloc(100);

										char			Data[100]					= "";
                                  time_t 	now;
	                              struct 	tm when;
								  int des =0;
								  int bomvalue =1;

	                             time(&now);
	                            when = *localtime(&now);
                               strftime(Data,100,"%Y/%b/%d-%H_%M_%S",&when);
										

									   ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&VCPrtModNum));
	                                    ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&VCPrtModNumType));
                                     printf("\nVC number is [%s]",VCPrtModNum); fflush(stdout);
									 CurReC = strtok(VCPrtModNumType,";");
										CurSeC = strtok(NULL,";");
										 printf("\nVC number rev and seq is [%s],[%s]",CurReC,CurSeC); fflush(stdout);

										 ITK_CALL(AOM_ask_value_string(PartTag,"object_desc",&VPrtdescM));
										 printf("\n desc before dup2 [%s]",VPrtdescM); fflush(stdout);

										 tc_strdup(VPrtdescM,&VPrtdescMdup);

										 STRNG_replace_str(VPrtdescMdup,"."," ",&VPrtdescMdup1);
										 STRNG_replace_str(VPrtdescMdup1,","," ",&VPrtdescMdup2);

										  printf("\n desc after VPrtdescMdup1 [%s]",VPrtdescMdup1); fflush(stdout);
										  printf("\n desc after VPrtdescMdup2 [%s]",VPrtdescMdup2); fflush(stdout);
										  

										 ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_ProgramScale",&PsProgScaleCC));
										printf("\nCCVC program scale is [%s]",PsProgScaleCC); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(getBusinessUnitFun(PartTag, &ProjdescDup,&Projname));
										printf("\n Project Descp :[%s]\n",ProjdescDup);   fflush(stdout);

										//ITK_CALL(getBusinessUnit(PartTag, &Projname));
										printf("\n Project Name :[%s]\n",Projname);   fflush(stdout);

										ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

										ITK_CALL(GRM_list_secondary_objects_only(PartTag,GCI_relation,&GCI,&GciObj));

										if(GCI>0)
										{
											for(gc=0;gc<GCI;gc++)
													{
														printf("\n inside for loop gc count****.\n");fflush(stdout);

														GCItag=GciObj[gc];

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&Demerit));
														printf("\n Demerit :[%d]\n",Demerit);fflush(stdout);

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_rating_S1",&Demerit_rating));
														printf("\n Demerit_rating :[%d]\n",Demerit_rating);fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCItag,"t5_geometry_conf_index_a1",&GCIind));
														printf("\n GCIind:[%lf]\n",GCIind);fflush(stdout);
                                                    }
										}

                              printf("\n GCIind******\n");fflush(stdout);
                        //tc_strcat(fsuccess_na,"/user/cvprod/MIS_Client_Code_CV/Reports/");
                       // sprintf(fsuccess_na,"/user/cvprod/MIS_Client_Code_CV/Reports/MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VCPrtModNum,CurReC,CurSeC,ProjbussDup,Projname);
                        sprintf(fsuccess_na,"MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VCPrtModNum,CurReC,CurSeC,ProjbussDup,Projname);
	                    fptr = fopen(fsuccess_na,"w");



                     fprintf(fptr,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
					 fprintf(fptr,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VCPrtModNum,CurReC,CurSeC);
					 fprintf(fptr,",,,Description,%s,,Program Scale,%s,,,\n",VPrtdescMdup2,PsProgScaleCC);
					 fprintf(fptr,",,,VC Status,%s,,,,,,\n",partstsDup);
                     fprintf(fptr,",,,Owner,%s,,,,,,\n",Owner);
                     fprintf(fptr,",,,Last Updated,,,,,,,\n");
                     fprintf(fptr,",,,Project Name,%s,,,,,,\n",prjcodeDup);
					 fprintf(fptr,",,,Project Description,%s,,,,,,\n",ProjdescDup);
					  printf("\n ****GCIind******\n");fflush(stdout);
					 if(Demerit)
					 {
                        fprintf(fptr,",,,Demerit Score(V),%d,,,,,,\n",Demerit);                                  
					 }
					 else
					 {
						 fprintf(fptr,",,,Demerit Score(V),%s,,,,,,\n","Nil");
					 }
					 if(Demerit_rating)
					{
                      fprintf(fptr,",,,Demerit Score Rating(S),%d,,,,,,\n",Demerit_rating);
					}
					 else
					{	
					 fprintf(fptr,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
					}
					if(GCIind)
					{
                      fprintf(fptr,",,,Geometry conformance Index(A),%lf,,,,,,\n",GCIind);
					}
					else{

					 fprintf(fptr,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
					}
                     fprintf(fptr,"\n\n");

fprintf(fptr,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update\n");





										 if(AOM_ask_value_tags(PartTag,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet)!= ITK_ok);
		                                 printf("\n WTRoll::snapshotCount ::  %d ", snapshotCount);fflush(stdout);

		                                if(snapshotCount>0)
		                                   {
											 printf("inside the snapshotCount**\n");fflush(stdout);
				                             Snapshot_tag = NULLTAG;
				                             snapshotObjTypeTag = NULLTAG;
				                             Snapshot_tag = snapshotObjSet[0];
                                               //printf(" the snapshotCount**\n");fflush(stdout);
				                             ITK_CALL(TCTYPE_ask_object_type(Snapshot_tag,&snapshotObjTypeTag));
				                             ITK_CALL( TCTYPE_ask_name2(snapshotObjTypeTag,&snapshotObjtype_name));
				                             printf("\n CCVC snapshotObjtype_name := %s\n", snapshotObjtype_name);fflush(stdout);
				                              
				                             ITK_CALL(AOM_ask_value_string(Snapshot_tag,"object_name",&ObjName));
				                             printf(" ObjName***: [%s] \n", ObjName);fflush(stdout);
				                              
				                             //if (AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev) != ITK_ok);
			                                  // if (AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags) != ITK_ok);
                                                //printf(" the snapshotCount topline**\n");fflush(stdout);
				                             ITK_CALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
				                             ITK_CALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));
                                              printf(" Snapshot tag is***: [%s] \n", SSTopLineRev);fflush(stdout);
				                              
                                                // printf(" the snapshotCount topline1**\n");fflush(stdout);
                                             ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));
				                             ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
				                             ITKCALL(BOM_set_window_pack_all (window, FALSE));
                                               //printf("after top line**\n");fflush(stdout);
					
					

				                             ITK_CALL( PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
				                              printf ("\n rule count %d \n",rulefound);fflush(stdout);
				                              if (rulefound > 0)
				                              {
				                             	close_tag = closurerule[0];
				                             	//printf ("closure rule found \n"); fflush(stdout);
				                              }
				                              ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
				                              printf ("closure rule found applied \n"); fflush(stdout);
				                             // ITKCALL(BOM_set_window_pack_all (window, FALSE));
				                              //ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
		                                     ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));
		                                     
		                                    // ITKCALL( TCTYPE_ask_property_by_name (top_line,"bl_item_item_id",&Item_ID));
		                                     //ITKCALL( AOM_ask_displayable_values(top_line, Item_ID,&bomvalue &Item_ID_str));
											 ///printf(" BOm line string is***: [%s] \n", Item_ID_str);fflush(stdout);
											 ITKCALL(BOM_line_ask_child_lines(top_line, &count, &ColIndChilds));
											 printf(" BOm line count is***: [%d] \n", count);fflush(stdout);

											 if (count >0)
			                                 {
				                              for (ichld=0;ichld<count ;ichld++ )
				                               {
					                            //if(Childobject1) Childobject1=NULLTAG;
					                                 Childobject1=ColIndChilds[ichld];
                                                
												ITK_CALL(AOM_ask_value_string(Childobject1,"bl_item_item_id",&PartNums1));
									            tc_strdup(PartNums1,&PartNums1Dup);
									            printf("\nPart number is in module*** [%s]",PartNums1Dup); fflush(stdout);

												
												ITKCALL(BOM_line_ask_child_lines(Childobject1, &count1, &Modulechilds));
												 printf("\n module line count is***: [%d]", count1);fflush(stdout);

                                                if (count1 >0)
			                                   {
                                               printf("\n module line****************** count is****\n");fflush(stdout);
				                              
												for (chld=0;chld<count1 ;chld++ )
				                               {
					                            if(ChildMobject) ChildMobject=NULLTAG;
					                                 ChildMobject=Modulechilds[chld];
                                    int resultCount1=0;
                                   
									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_item_item_id",&ModuleName));
									tc_strdup(ModuleName,&ModuleNameDup);
									printf("\n module number is [%s]",ModuleNameDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartType",&ModuleNumstyp));
									tc_strdup(ModuleNumstyp,&ModuleNumstypDup);
									printf("\nPart type is [%s]",ModuleNumstypDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_Design Revision_t5_CategoryName",&Moduledescp));
									tc_strdup(Moduledescp,&ModuledescpDup);
									STRNG_replace_str(ModuledescpDup,","," ",&ModuledescpDup);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_rev_item_revision_id",&ModulePartRevs));
									tc_strdup(ModulePartRevs,&ModulePartRevsDup);
									printf("\nPart number revision [%s]",ModulePartRevsDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddre));
									tc_strdup(ModuleAddre,&ModuleAddreDup);
                                    printf("\nPart number address [%s]",ModuleAddreDup); fflush(stdout);


									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartStatus",&Modulepartst));
									tc_strdup(Modulepartst,&ModulepartstDup);
									 printf("\nPart number status [%s]",ModulepartstDup); fflush(stdout);



									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_rev_release_status_list",&ModulePartRelStats));
                                     printf("\nPart release is [%s]",ModulePartRelStats); fflush(stdout);
									if(tc_strstr(ModulePartRelStats,"ERC Released")!=NULL)
									{
										printf("\nPart [%s] Release Status [%s]",ModuleNameDup,ModulePartRelStats); fflush(stdout);
										//tc_strcpy(ModuleOwners,"Release Vault");
										tc_strdup("Release Vault",&ModuleOwners);
                                          printf("\nPart release is** [%s]",ModuleOwners); fflush(stdout);
									}

									    MCurRevs = strtok(ModulePartRevsDup,";");
										MCurSeqs = strtok(NULL,";");

										printf("\n Current Revision is %s",MCurRevs);fflush(stdout);
										printf("\n Current Sequence is %s",MCurSeqs);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);

										if(tc_strcmp(ModuleNumstypDup,"M")==0)
							           {


										ITK_CALL(getBusinessUnitFunct(ChildMobject, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(GetDVAUseCaseFromLibraryt(ChildMobject, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount1);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										tag_t itemTagm = NULLTAG;
										tag_t itemRevTagm = NULLTAG;
										ITEM_find_item(ModuleName, &itemTagm);
										//ITEM_ask_latest_rev(itemTagm,&itemRevTagm);
										printf("\n checking :[%s],[%s]\n",ModuleName,ModulePartRevs);   fflush(stdout);
									    ITEM_find_revision(itemTagm,ModulePartRevs,&itemRevTagm);
										/*if(itemRevTagm==NULLTAG)
												   {
                                                    printf("inside the NULLTAG\n");fflush(stdout);
                                                    exit(0);
												   }
												   else
												   {

                                                      printf("\nTag found");fflush(stdout);
												   }*/
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);
                                   
										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										printf("\n No of Attached DFQ Documetns are**m :: %d\n",DVA_result_counts);fflush(stdout);

										  int trueflaggg=0;
									     int falseflaggg=0;

                                        if (DVA_result_counts >0)
										{
											
											for (j=0;j<DVA_result_counts; j++ )
											{
												AOM_ask_value_logical(DVA_document_tag[j],"t5_DFQApplicablility",&DFQApplicablilitys1);

												printf("\n DFQApplicablility [%d] ",DFQApplicablilitys1);

												if(DFQApplicablilitys1 == 1)
												{
													//tc_strdup("Yes",&DFQApplicablilitysDup);
                                                    trueflaggg++;
													//printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													//tc_strdup("No",&DFQApplicablilitysDup);
													falseflaggg++;
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}

											}
										}

										printf("\n PartNumDup** [%s] CurRev** [%s] CurSeq** [%s]  partstsDup** [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",ModuleNameDup,MCurRevs,MCurSeqs,ModulepartstDup,ModuleAddreDup,PrerevDRstat,ProjbussDup,ModuledescpDup,ModuleOwners);fflush(stdout);
										fprintf(fptr,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d\n",ModuleNameDup,MCurRevs,MCurSeqs,ModulepartstDup,ModuleAddreDup,ProjbussDup,ModuledescpDup,ModuleOwners,resultCount1,falseflaggg,trueflaggg);

										if (DVA_result_counts >0)
										{
										printf("in there-------------------------------------------------------------------------------------------------------");;fflush(stdout);

											for (d=0;d<DVA_result_counts; d++ )
											{
												AOM_ask_value_string(DVA_document_tag[d],"current_name",&DFQdocnos);
												tc_strdup(DFQdocnos,&DFQdocnosDup);

												AOM_ask_value_string(DVA_document_tag[d],"t5_DFQUID",&DFQUIDs);
												tc_strdup(DFQUIDs,&DFQUIDsDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[d],"object_desc",&DVADescs));
//												des=tc_strlen(DVADescs);
//												printf("\n des len 3 [%d] ",des);
//												tc_strdup(DVADescs,&DVADescsDup6);
//
//												STRNG_replace_str(DVADescsDup6,","," ",&DVADescsDup7);
//												STRNG_replace_str(DVADescsDup7,"\n",";",&DVADescsDup);


												//DVADescsDup = (char*)MEM_alloc(1000);
												

                                                int an=0;
												int ax=0; 
												printf(" Value of desc found = %s \n",DVADescs);
												printf(" Value of DFQdocnos found = %s \n",DFQdocnos);

												for(ax=0;DVADescs[ax]!='\0';ax++)
												{
													printf("\n char found2 = %c , ascii found = %d \n",DVADescs[ax],DVADescs[ax]);

													//if(DVADescs[ax]==13)
													if((DVADescs[ax]==13) || (DVADescs[ax]==10))
													{
														DVADescsDup[an]='\0';
													}
													else
													{
														 DVADescsDup[an]=DVADescs[ax];
														 an++;
													}

												} 

												printf(" Length of DVADescs = %d ",tc_strlen(DVADescs));
												printf(" Length of DVADescsDup = %d ",tc_strlen(DVADescsDup));

												printf(" DVADescs = %s\n",DVADescs);
												printf(" DVADescsDup = %s\n",DVADescsDup);

												AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitys);

												printf("\n DFQApplicablility [%d] ",DFQApplicablilitys);

												if(DFQApplicablilitys == 1)
												{
													tc_strdup("Yes",&DFQApplicablilitysDup);
                                                   
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													tc_strdup("No",&DFQApplicablilitysDup);
													
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQComment",&DFQComments));
												tc_strdup(DFQComments,&DFQCommentsDup);

												STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
												STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

												printf("*n Foundpdf --- %d* \n",nFoundpdfs);fflush(stdout);
												printf("*n Foundexcel --- %d* \n",nFoundexcels);fflush(stdout);

												if (nFoundpdfs == 0)
												{
													tc_strdup("No",&Foundpdfs);
												}else{
													tc_strdup("Yes",&Foundpdfs);
												}

												if (nFoundexcels == 0)
												{
													tc_strdup("No",&Foundexcels);
												}else{
													tc_strdup("Yes",&Foundexcels);
												}

												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQDesNom",&Designnominals));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DNDefTarget",&Definedtargets));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQAchNom",&Achievednominals));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_ANDefTarget",&Achievedtargets));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQCpkVal",&CpkDups));

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQMeetExp",&Meetexpectation));
												tc_strdup(Meetexpectation,&MeetexpectationDup);
												printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

												if(tc_strcmp(MeetexpectationDup,"N")==0)
												{

                                                     tc_strdup("No",&MeetexpectationDupM);
												}
												if(tc_strcmp(MeetexpectationDup,"Y")==0)
												{
                                                      tc_strdup("Yes",&MeetexpectationDupM);
												}
												if(tc_strcmp(MeetexpectationDup,"NA")==0)
												{
                                                      tc_strdup("NA",&MeetexpectationDupM);
												}


												//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

												ITK_CALL(AOM_ask_value_date(DVA_document_tag[d],"last_mod_date",&Lastmoddates));
												ITK_CALL(DATE_date_to_string(Lastmoddates,"%d/%m/%Y",&LastmoddatesDup));

												printf("\n DFQUIDDup** [%s] DVADescDup** [%s] DFQApplicablilityDup**  [%s] DFQCommentDup** [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDup,LastmoddatesDup);fflush(stdout);
												fprintf(fptr,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDupM,LastmoddatesDup);
											}
										 }





									            }
                                               }

											 }

                                         }

										}

                                      }
									 
                                            


                                         fclose(fptr);
									}
									else
									{
										printf("\nPart : %s  having Part type : %s is NON Valide",PartNumDup,part_typeDup);fflush(stdout);
									}
																		
									
									 
									 

								}

							}
						}
					}
				}
				else if(tc_strcmp(DmlRelTypeDup,"TODR")==0)
		        {

					int tskcnt =0,t=0,p=0;
					tag_t *SetOfDmlTasksTag= NULLTAG;
					char *TaskId=NULL;
					int partCnt=0;
					tag_t *SetOfPartTags= NULLTAG;

					ITK_CALL(AOM_ask_value_tags(ERCDMLTag,"T5_DMLTaskRelation",&tskcnt,&SetOfDmlTasksTag));
					printf("\nDML Task Count : %d\n",tskcnt);fflush(stdout);

					printf("\n Inside Gate Maturation first condition\n");fflush(stdout);


					if (tskcnt>0)
					{
						for(t=0;t<tskcnt;t++)
						{
							ITK_CALL(AOM_ask_value_string(SetOfDmlTasksTag[t],"item_id",&TaskId));
							printf("\nDML Task [%s]",TaskId);fflush(stdout);

							if (tc_strstr(TaskId,"APL")!=NULL)
							{
								printf("\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
								continue;
							}

							AOM_ask_value_tags(SetOfDmlTasksTag[t],"CMReferences",&partCnt,&SetOfPartTags);
							printf("\nNo of Design Rev=%d\n",partCnt);
							if (partCnt>0)
							{
								char *PartNum=NULL;
								char *PartNumDup=NULL;
								char *PartRev=NULL;
								char *PartRevDup=NULL;
								char *PartRelStat=NULL;
								tag_t PartTag= NULLTAG;
								char *part_type=NULL;
								char *part_typeDup=NULL;
								char *desc=NULL;
								char *descDup=NULL;
								char *ModuleAddress=NULL;
								char *ModuleAddressDup=NULL;
								char *partsts=NULL;
								char *partstsDup=NULL;
								char *prjcode=NULL;
								char *prjcodeDup=NULL;
								char* PartColInd = NULL;
								char* PartColIndDup = NULL;
								char *ColorIDPart = NULL;
								char *ColorIDPartDup = NULL;
								char *UrnCode = NULL;
								char *prepartsts = NULL;
								char* PrerevDRstat	 = NULL;

								char* ProjVehclass = NULL;
								char* ProjVehclassDup = NULL;
								char* Projplnname = NULL;
								char* ProjplnnameDup = NULL;
								char* Projbuss = NULL;
								char* ProjbussDup = NULL;
								char* Projdesc = NULL;
								char* ProjdescDup = NULL;
								

								PrerevDRstat	=	(char	*)MEM_alloc(10);
								
								char* FirstrlzDR4	 = NULL;
								FirstrlzDR4	=	(char	*)MEM_alloc(10);

								char* Owner	= NULL;
								Owner = (char *)MEM_alloc(50);

								//displaying_objects();
								for(p=0;p<partCnt;p++)
								{
									PartTag=SetOfPartTags[p];

									printf("\n Part Class [%s]",type_name); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
									tc_strdup(PartNum,&PartNumDup);

									ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_CategoryName",&desc));
									tc_strdup(desc,&descDup);
									STRNG_replace_str(descDup,","," ",&descDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
									tc_strdup(PartRev,&PartRevDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ModuleAddress",&ModuleAddress));
									tc_strdup(ModuleAddress,&ModuleAddressDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartStatus",&partsts));
									tc_strdup(partsts,&partstsDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&PartColInd));
									tc_strdup(PartColInd,&PartColIndDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ProjectCode",&prjcode));
									tc_strdup(prjcode,&prjcodeDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
									tc_strdup(part_type,&part_typeDup);
									printf("\nPart type is*** [%s]",part_typeDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&PartRelStat));

									if(tc_strstr(PartRelStat,"ERC Released")==NULL)
									{
										printf("\nPart [%s] is not ERC Released LifeCycleState [%s] Skipping...",PartNum,PartRelStat); fflush(stdout);
										continue;
									}
									else
									{
										printf("\nPart [%s] Release Status [%s]",PartNum,PartRelStat); fflush(stdout);
										tc_strcpy(Owner,"Release Vault");
									}

									//if((tc_strcmp(part_typeDup,"V")==0) || (tc_strcmp(part_typeDup,"VC")==0) || (tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0))
									/*if((tc_strcmp(part_typeDup,"M")==0) && (tc_strcmp(DmlRelTypeDup,"MR")==0) && (tc_strcmp(type,"M")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{
										//tc_strcat(fsuccess_name,"/user/cvprod/MIS_Client_Code_CV/Reports/");
										sprintf(fsuccess_name,"%s_%s_%s_%s.csv",PartNum,fromdate,todate,type);
	                                    fsuccess = fopen(fsuccess_name,"w");

	                                  fprintf(fsuccess,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,Last Update,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),DVA Use case Description\n");

										int revi = 0, revCnt = 0, preOffDR4 = 0, preOffDRstat = 0, ChkpreRev= 0;
										tag_t *allRevTag	 = NULLTAG;
										char* CurRev		 = NULL;
										char* CurSeq		 = NULL;
										tag_t relTypeTag = NULLTAG;
										tag_t* DVA_document_tags = NULLTAG;
										logical dfq_applicability;;
										int DVA_result_count = 0;
										int d = 0;
										int k = 0;

										logical DFQApplicablilitycheck	= 0;
										logical DFQApplicablility	= 0;
										char* DFQApplicablilityDup	= NULL;
										//DFQApplicablilityDup = (char *)MEM_alloc(100);

										double Designnominal;
										double Definedtarget;
										double Achievednominal;
										double Achievedtarget;
										double CpkDup;

										char* DFQdocno				= NULL;
										char* DFQdocnoDup			= NULL;
										char* DFQUID				= NULL;
										char* DFQUIDDup				= NULL;
										char* DVADesc				= NULL;
										char* DVADescDup			= NULL;
										char* DFQComment			= NULL;
										char* DFQCommentDup			= NULL;
										char* Meetexpectations		= NULL;
										char* MeetexpectationsDup	= NULL;
										char* Foundpdf				= NULL;
										char* Foundexcel			= NULL;
										date_t Lastmoddate;
										char* LastmoddateDup		= NULL;
                                        char*MeetexpectationDupMMM=NULL;

										int resultCount1 = 0;
										tag_t* dfq_use_case_tags = NULLTAG;
										char* DVADescDup8 = NULL;
										char* DVADescDup9 = NULL;
										DVADescDup8	=	(char	*)MEM_alloc(100);
										DVADescDup9	=	(char	*)MEM_alloc(100);
										DVADescDup	=	(char	*)MEM_alloc(100);

										int nFoundpdf= 0;
										int nFoundexcel= 0;
										int trueflag= 0;
										int falseflag= 0;
										tag_t* refobjpdf  = NULLTAG;
										tag_t* refobjexcel  = NULLTAG;

										CurRev = strtok(PartRevDup,";");
										CurSeq = strtok(NULL,";");

										printf("\n Current Revision is %s",CurRev);fflush(stdout);
										printf("\n Current Sequence is %s",CurSeq);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(GetDVAUseCaseFromLibrary(PartTag, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount1);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTag);

										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(PartTag, relTypeTag, &DVA_result_count,&DVA_document_tags));
										printf("\n No of Attached DFQ Documetns are :: %d\n",DVA_result_count);fflush(stdout);


										if (DVA_result_count >0)
										{
											for (k=0;k<DVA_result_count; k++ )
											{
												AOM_ask_value_logical(DVA_document_tags[k],"t5_DFQApplicablility",&DFQApplicablilitycheck);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck);

												if(DFQApplicablilitycheck == 1)
												{
													trueflag++;
												}
												else
												{
													falseflag++;
												}
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumDup,CurRev,CurSeq,partstsDup,ModuleAddressDup,PrerevDRstat,ProjbussDup,descDup,Owner);fflush(stdout);
										fprintf(fsuccess,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",PartNumDup,CurRev,CurSeq,partstsDup,ModuleAddressDup,ProjbussDup,descDup,Owner,resultCount1,falseflag,trueflag);

										if (DVA_result_count >0)
										{
											for (d=0;d<DVA_result_count; d++ )
											{
												AOM_ask_value_string(DVA_document_tags[d],"current_name",&DFQdocno);
												tc_strdup(DFQdocno,&DFQdocnoDup);

												AOM_ask_value_string(DVA_document_tags[d],"t5_DFQUID",&DFQUID);
												tc_strdup(DFQUID,&DFQUIDDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tags[d],"object_desc",&DVADesc));
												tc_strdup(DVADesc,&DVADescDup8);

												STRNG_replace_str(DVADescDup8,","," ",&DVADescDup9);
												STRNG_replace_str(DVADescDup9,"@"," ",&DVADescDup);

												AOM_ask_value_logical(DVA_document_tags[d],"t5_DFQApplicablility",&DFQApplicablility);

												printf("\n DFQApplicablility [%d] ",DFQApplicablility);

												if(DFQApplicablility == 1)
												{
													tc_strdup("Yes",&DFQApplicablilityDup);
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilityDup);fflush(stdout);
												}
												else
												{
													tc_strdup("No",&DFQApplicablilityDup);
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilityDup);fflush(stdout);
												}

												ITK_CALL(AOM_ask_value_string(DVA_document_tags[d],"t5_DFQComment",&DFQComment));
												tc_strdup(DFQComment,&DFQCommentDup);

												STRNG_replace_str(DFQCommentDup,","," ",&DFQCommentDup);
												STRNG_replace_str(DFQCommentDup,"\n"," ",&DFQCommentDup);

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tags[d],"T5_DFQ_PDF",&nFoundpdf,&refobjpdf));
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tags[d],"T5_DFQ_EXCEL",&nFoundexcel,&refobjexcel));

												printf("*n Foundpdf --- %d* \n",nFoundpdf);fflush(stdout);
												printf("*n Foundexcel --- %d* \n",nFoundexcel);fflush(stdout);

												if (nFoundpdf == 0)
												{
													tc_strdup("No",&Foundpdf);
												}else{
													tc_strdup("Yes",&Foundpdf);
												}

												if (nFoundexcel == 0)
												{
													tc_strdup("No",&Foundexcel);
												}else{
													tc_strdup("Yes",&Foundexcel);
												}

												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQDesNom",&Designnominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DNDefTarget",&Definedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQAchNom",&Achievednominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_ANDefTarget",&Achievedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQCpkVal",&CpkDup));

												ITK_CALL(AOM_ask_value_string(DVA_document_tags[d],"t5_DFQMeetExp",&Meetexpectations));
												tc_strdup(Meetexpectations,&MeetexpectationsDup);

												if(tc_strcmp(MeetexpectationsDup,"N")==0)
												{

                                                     tc_strdup("No",&MeetexpectationDupMMM);
												}
												if(tc_strcmp(MeetexpectationsDup,"Y")==0)
												{
                                                      tc_strdup("Yes",&MeetexpectationDupMMM);
												}
												if(tc_strcmp(MeetexpectationsDup,"NA")==0)
												{
                                                      tc_strdup("NA",&MeetexpectationDupMMM);
												}

												//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

												ITK_CALL(AOM_ask_value_date(DVA_document_tags[d],"last_mod_date",&Lastmoddate));
												ITK_CALL(DATE_date_to_string(Lastmoddate,"%d/%m/%Y",&LastmoddateDup));

												printf("\n DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",DFQUIDDup,DVADescDup,DFQApplicablilityDup,DFQCommentDup,DFQdocnoDup,Foundpdf,Foundexcel,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationsDup,LastmoddateDup);fflush(stdout);
												fprintf(fsuccess,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDDup,LastmoddateDup,DFQApplicablilityDup,DFQCommentDup,DFQdocnoDup,Foundpdf,Foundexcel,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationDupMMM,DVADescDup);
											}
										}
										fclose(fsuccess);
									}*/
									//else if ((tc_strcmp(part_typeDup,"V")==0) && (tc_strcmp(DmlRelTypeDup,"Veh")==0) && (tc_strcmp(type,"V")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									if ((tc_strcmp(part_typeDup,"V")==0) && (tc_strcmp(DmlRelTypeDup,"TODR")==0) && (tc_strcmp(type,"V")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{
										printf("\n TODR Third condition conditin part_type [%s] DmlRelStatDup [%s] PartNum [%s] \n",part_typeDup,DmlRelTypeDup,PartNum);fflush(stdout);
										char *VPrtModNum=NULL;
	                                    char *VPrtModNumType=NULL;
                                        tag_t	bom_wnd				=	NULLTAG;
                                        tag_t	rule				=	NULLTAG;
                                        tag_t	top_lne				=	NULLTAG;
										//int		n_count			=	0;
                                        int count=0;
										int		ichld			=	0;
										tag_t	*ArchNodeLines		=	NULLTAG;

	                                    tag_t	*ColIndChilds		=	NULLTAG;
	                                    tag_t	Childobject			=	NULLTAG;
										char* Owners	= NULL;
								        Owners = (char *)MEM_alloc(50);
                                         char *PartNums=NULL;
										 char *PartNumsDup=NULL;
										 char *PartNumstypDup=NULL;
										 char*PartNumstyp=NULL;
                                         char *descp=NULL;
										 char *descpDup=NULL;
                                         char *PartRevs=NULL;
										 char *PartRevsDup=NULL;
										 char *ModuleAddressp=NULL;
										 char *ModuleAddresspDup=NULL;
                                         char *partst=NULL;
										 char *partstDup=NULL;
										 char *PartRelStats=NULL;
										 char* CurRevs		 = NULL;
										char* CurSeqs		 = NULL;
										char *CurRe=NULL;
										char*CurSe=NULL;
										char*VPrtdesc=NULL;
										char*PsProgScale=NULL;
										int i=0;
										tag_t relTypeTags = NULLTAG;
										tag_t ItemTypeTag=NULLTAG;
										tag_t* DVA_document_tag = NULLTAG;
										int DVA_result_counts=0;
                                         int resultCount=0;
										 logical DFQApplicablilitycheck1= 0;
										 logical DFQApplicablilitys=0;
										 // int trueflagg=0;
										 // int falseflagg=0;
                                          int d=0;
                                       char* DFQdocnos				= NULL;
										char* DFQdocnosDup			= NULL;
										char* DFQUIDs				= NULL;
										char* DFQUIDsDup				= NULL;
										char* DVADescs				= NULL;
										char* DVADescsDup			= NULL;
										char* DFQComments			= NULL;
										char* DFQCommentsDup			= NULL;
										char* Meetexpectation		= NULL;
										char* MeetexpectationDup	= NULL;
										char* Foundpdfs				= NULL;
										char* Foundexcels			= NULL;
										date_t Lastmoddates;
										char* LastmoddatesDup		= NULL;
                                        char* DFQApplicablilitysDup=NULL;
										char*ItemType=NULL;
										int nFoundpdfs= 0;
										int nFoundexcels= 0;

										tag_t* refobjpdfs  = NULLTAG;
										tag_t* refobjexcels  = NULLTAG;

										double Designnominals;
										double Definedtargets;
										double Achievednominals;
										double Achievedtargets;
										double CpkDups;
                                        tag_t* dfq_use_case_tags = NULLTAG;
										char* ProjdescDup = NULL;
                                        char*Projname=NULL;
                                        char*MeetexpectationDupMM=NULL;
										char			Data[100]					= "";
										tag_t GCI_relation=NULLTAG;
										tag_t*GciObj=NULLTAG;
										int GCI=0;
										int Demerit_rating=0;
										int Demerit=0;
										double GCIind =0;
										int gc=0;
										tag_t GCItag=NULLTAG;
										int des =0;
									
                                  time_t 	now;
	                              struct 	tm when;

								  PIE_scope_t scope;
	                              scope=PIE_TEAMCENTER;
								  int rulefound= 0;
								  tag_t *closurerule = NULLTAG;
								  tag_t close_tag = NULLTAG;
								  tag_t bom_variant_rule = NULLTAG;
								  tag_t objTypeTag=NULLTAG;
								  //char type_name[TCTYPE_name_size_c+1];
								  tag_t e_block		= NULLTAG;
								  char **rulename = NULL;
	                              char **rulevalue = NULL;
	                              char *VPrtdescdup5 = NULL;
	                              char *VPrtdescdup6 = NULL;
	                              char *type_name = NULL;
								  VPrtdescdup6 = (char *)MEM_alloc(100);
								  VPrtdescdup5 = (char *)MEM_alloc(100);
								  char *VPrtdescdup2 = NULL;
								  char *DVADescsDup10 = NULL;
								  char *DVADescsDup11 = NULL;
								  VPrtdescdup2 = (char *)MEM_alloc(100);
								  DVADescsDup10 = (char *)MEM_alloc(100);
								  DVADescsDup11 = (char *)MEM_alloc(100);
								  DVADescsDup = (char *)MEM_alloc(100);

	                             time(&now);
	                            when = *localtime(&now);
                               strftime(Data,100,"%Y/%b/%d-%H_%M_%S",&when);


										ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&VPrtModNum));
	                                    ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&VPrtModNumType));
                                     printf("\nV number is [%s]",VPrtModNum); fflush(stdout);
									 CurRe = strtok(VPrtModNumType,";");
										CurSe = strtok(NULL,";");

										ITK_CALL(AOM_ask_value_string(PartTag,"object_desc",&VPrtdesc));
										printf("\nV part desc before1 [%s]",VPrtdesc); fflush(stdout);
										tc_strdup(VPrtdesc,&VPrtdescdup5);
										//STRNG_replace_str(VPrtdescdup,","," ",&VPrtdescdup1);
										STRNG_replace_str(VPrtdescdup5,","," ",&VPrtdescdup6);
										STRNG_replace_str(VPrtdescdup6,"."," ",&VPrtdescdup2);

										printf("\nV part desc After dup1[%s]",VPrtdescdup6); fflush(stdout);
										printf("\nV part desc After dup3[%s]",VPrtdescdup2); fflush(stdout);
										

										ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_ProgramScale",&PsProgScale));
										printf("\nV program scale is [%s]",PsProgScale); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(getBusinessUnitFun(PartTag, &ProjdescDup,&Projname));
										printf("\n Project Descp :[%s]\n",ProjdescDup);   fflush(stdout);

										//ITK_CALL(getBusinessUnit(PartTag, &Projname));
										printf("\n Project Name :[%s]\n",Projname);   fflush(stdout);

										ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

										ITK_CALL(GRM_list_secondary_objects_only(PartTag,GCI_relation,&GCI,&GciObj));

										if(GCI>0)
										{
											for(gc=0;gc<GCI;gc++)
													{
														printf("\n inside for loop gc count****.\n");fflush(stdout);

														GCItag=GciObj[gc];

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&Demerit));
														printf("\n Demerit :[%d]\n",Demerit);fflush(stdout);
                                                       
														
														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_rating_S1",&Demerit_rating));
														printf("\n Demerit_rating :[%d]\n",Demerit_rating);fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCItag,"t5_geometry_conf_index_a1",&GCIind));
														printf("\n GCIind:[%lf]\n",GCIind);fflush(stdout);
                                                    }
										}
										  




                        //tc_strcat(fsuccess_nam,"/user/cvprod/MIS_Client_Code_CV/Reports/");
                        //sprintf(fsuccess_nam,"/user/cvprod/MIS_Client_Code_CV/Reports/MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname);
                        sprintf(fsuccess_nam,"MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname);
	                    file = fopen(fsuccess_nam,"w");


                     if(GciObj==0)
					{

                      printf("\n inside GCI object count is Zero.\n");fflush(stdout);

                     fprintf(file,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
					 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
					 fprintf(file,",,,Description,%s,,Program Scale,%s,,,\n",VPrtdescdup2,PsProgScale);
					 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
                     fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
                     fprintf(file,",,,Last Updated,,,,,,,\n");
                     fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
					 fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
                     if(Demerit)
					 {
                        fprintf(file,",,,Demerit Score(V),%d,,,,,,\n","Nil");                                  
					 }
					 else{
						 fprintf(file,",,,Demerit Score(V),%s,,,,,,\n","Nil");
					 }
					 if(Demerit_rating)
					{
                      fprintf(file,",,,Demerit Score Rating(S),%d,,,,,,\n","Nil");
					}
					 else
					{	
					 fprintf(file,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
					}
					if(GCIind)
					{
                      fprintf(file,",,,Geometry conformance Index(A),%lf,,,,,,\n","Nil");
					}
					else{

					 fprintf(file,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
					}
                     fprintf(file,"\n\n");
					}
					else if (GciObj>0)
					{

						printf("\n inside GCI object count is one\n");fflush(stdout);
					
                     fprintf(file,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
					 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
					 fprintf(file,",,,Description,%s,,Program Scale,%s,,,\n",VPrtdescdup2,PsProgScale);
					 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
                     fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
                     fprintf(file,",,,Last Updated,,,,,,,\n");
                     fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
					 fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
                     if(Demerit)
					 {
                        fprintf(file,",,,Demerit Score(V),%d,,,,,,\n",Demerit);                                  
					 }
					 else{
						 fprintf(file,",,,Demerit Score(V),%s,,,,,,\n","Nil");
					 }
					 if(Demerit_rating)
					{
                      fprintf(file,",,,Demerit Score Rating(S),%d,,,,,,\n",Demerit_rating);
					}
					 else
					{	
					 fprintf(file,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
					}
					if(GCIind)
					{
                      fprintf(file,",,,Geometry conformance Index(A),%lf,,,,,,\n",GCIind);
					}
					else{

					 fprintf(file,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
					}
                     fprintf(file,"\n\n");
					
					}

fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update\n");





										if(PartTag!=NULLTAG)
	                                  {
										    ITKCALL(BOM_create_window(&bom_wnd ));      //set new bom window
											ITK_CALL ( BOM_set_window_top_line( bom_wnd, NULLTAG, PartTag, NULLTAG, &top_lne ));
											ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE)); 
		                                    ITKCALL(CFM_find("ERC release and above", &rule));  //find the revision rule
											ITKCALL(BOM_set_window_config_rule(bom_wnd, rule));  // set revision rule for window

											//ITK_CALL( PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
											ITK_CALL( PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));

					                        printf ("vc_rule count %d \n",rulefound);fflush(stdout);
					                        
					                        if (rulefound > 0)
					                        {
					                        	close_tag = closurerule[0];
					                        	printf (" vc closure rule found \n");fflush(stdout);
					                        	// MEM_free(tags_found);
					                        }

											ITK_CALL(BOM_window_set_closure_rule( bom_wnd,close_tag, 0, rulename,rulevalue ));

					                       
					                       
                                            if(top_lne!=NULLTAG)
										  {  
                                             printf (" vc top found \n");fflush(stdout);
										  }
					                        printf( " vc_After BOM_set_window_top_line..\n");fflush(stdout);

//											ITK_CALL (  BOM_window_ask_variant_rules( bom_wnd,&bomcoutn,&bom_variant_rule ));
//					                        printf( " vc_release  BOM_window_ask_variant_rules..\n");fflush(stdout);
//											if(bom_variant_rule!=NULLTAG)
//										  {  
//                                             printf (" bom_variant_rule found \n");fflush(stdout);
//										  }
//
//											ITK_CALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
//					                        ITK_CALL( TCTYPE_ask_name2(objTypeTag,&type_name));
//											if(objTypeTag!=NULLTAG)
//										  {  
//                                             printf (" objTypeTag found \n");fflush(stdout);
//										  }

											ITK_CALL ( ITEM_ask_rev_variants ( PartTag, &e_block ));
					                        printf(" vc_ITEM_ask_rev_variants..\n");fflush(stdout);
											if(e_block!=NULLTAG)
										  {  
                                             printf (" e_block found \n");fflush(stdout);
										  }
					                        
											
                                           // ITKCALL(BOM_set_window_top_line( bom_wnd, NULLTAG, PartTag, NULLTAG, &top_lne ));



											if(top_lne!=NULLTAG)
		                                   {
			                                // ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
			                               //  printf("\n n_count --------> : %d\n", n_count);

										   ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
//										   if(ColIndChilds!=NULLTAG)
//										  {  
//                                             printf (" ColIndChilds found \n");fflush(stdout);
//										  }

										   ITK_CALL(BOM_window_hide_unconfigured(bom_wnd))   ;
						                   ITK_CALL(BOM_window_show_variants(bom_wnd))   ;

										   printf("\n vc_release After inside bom_window-----\n"); fflush(stdout);
						                   ITK_CALL(BOM_window_apply_variant_configuration(bom_wnd,1,&PartTag))   ;
						                   printf("\n vc_release After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
										    if(PartTag!=NULLTAG)
										  {  
                                             printf (" PartTag found \n");fflush(stdout);
										  }


                                           ITK_CALL(BOM_window_hide_variants(bom_wnd))   ;

						                  ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
//										   if(ColIndChilds!=NULLTAG)
//										  {  
//                                             printf (" ColIndChilds1 found \n");fflush(stdout);
//										  }

						                  printf("\n vcBom_count --------> : [%d]  ",count); fflush(stdout);
			                                 //ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
			                                // printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node

			                                 if (count >0)
			                                 {
				                              for (ichld=0;ichld<count ;ichld++ )
				                               {
					                            //if(Childobject) Childobject=NULLTAG;
					                                 Childobject=ColIndChilds[ichld];


									ITK_CALL(AOM_ask_value_string(Childobject,"bl_item_item_id",&PartNums));
									tc_strdup(PartNums,&PartNumsDup);
									printf("\nPart number is 4 [%s]",PartNumsDup); fflush(stdout);

                                    ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartType",&PartNumstyp));
									tc_strdup(PartNumstyp,&PartNumstypDup);
									printf("\nPart type is [%s]",PartNumstypDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_Design Revision_t5_CategoryName",&descp));
									tc_strdup(descp,&descpDup);
									STRNG_replace_str(descpDup,","," ",&descpDup);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_rev_item_revision_id",&PartRevs));
									tc_strdup(PartRevs,&PartRevsDup);
									printf("\nPart number revision [%s]",PartRevsDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddressp));
									tc_strdup(ModuleAddressp,&ModuleAddresspDup);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartStatus",&partst));
									tc_strdup(partst,&partstDup);


									ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_rev_release_status_list",&PartRelStats));
                                     printf("\nPart release is [%s]",PartRelStats); fflush(stdout);
									if(tc_strstr(PartRelStats,"ERC Released")!=NULL)
									{
										printf("\nPart [%s] Release Status [%s]",PartNums,PartRelStats); fflush(stdout);
										tc_strcpy(Owners,"Release Vault");
									}

									    CurRevs = strtok(PartRevsDup,";");
										CurSeqs = strtok(NULL,";");

										printf("\n Current Revision is %s",CurRevs);fflush(stdout);
										printf("\n Current Sequence is %s",CurSeqs);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);
										if(tc_strcmp(PartNumstypDup,"M")==0)
							          {

                                        ITK_CALL(getBusinessUnitFunct(Childobject, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										resultCount=0;

										ITK_CALL(GetDVAUseCaseFromLibraryt(Childobject, ProjbussDup, &resultCount, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										tag_t itemTag = NULLTAG;
										tag_t itemRevTag = NULLTAG;

										tag_t itemRevTagm1	 =	NULLTAG;
										ITEM_find_item(PartNums, &itemTag);
										//ITEM_ask_latest_rev(itemTag,&itemRevTag);


										ITEM_find_revision(itemTag,PartRevs,&itemRevTagm1);
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);

										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm1, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										printf("\n No of Attached DFQ Documetns are** :: %d\n",DVA_result_counts);fflush(stdout);

										int trueflagg=0;
										int falseflagg=0;

                                        if (DVA_result_counts >0)
										{
											for (i=0;i<DVA_result_counts; i++ )
											{
												AOM_ask_value_logical(DVA_document_tag[i],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												if(DFQApplicablilitycheck1 == 1)
												{
													trueflagg++;
												}
												else
												{
													falseflagg++;
												}
											}
										}

										printf("\n PartNumDup*** [%s] CurRev*** [%s] CurSeq*** [%s]  partstsDup*** [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,PrerevDRstat,ProjbussDup,descpDup,Owners);fflush(stdout);
										fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d\n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,ProjbussDup,descpDup,Owners,resultCount,falseflagg,trueflagg);
                                        resultCount=0;

											if (DVA_result_counts >0)
																	{
																		for (d=0;d<DVA_result_counts; d++ )
																		{
																			AOM_ask_value_string(DVA_document_tag[d],"current_name",&DFQdocnos);
																			tc_strdup(DFQdocnos,&DFQdocnosDup);

																			AOM_ask_value_string(DVA_document_tag[d],"t5_DFQUID",&DFQUIDs);
																			tc_strdup(DFQUIDs,&DFQUIDsDup);

																			tc_strcpy(DVADescsDup,"");
																			ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[d],"object_desc",&DVADescs));
																			//des=tc_strlen(DVADescs);

																			int an=0;
																			DVADescsDup = (char*)MEM_alloc(1000);
                                                                            
// Testing 

                                                                            int ax=0; 
                                                                            printf(" Value of desc found = %s \n",DVADescs);
                                                                            printf(" Value of DFQdocnos found = %s \n",DFQdocnos);

																			for(ax=0;DVADescs[ax]!='\0';ax++)
																			{
                                                                                printf("\n char found = %c , ascii found = %d \n",DVADescs[ax],DVADescs[ax]);

																				//if(DVADescs[ax]==13)
																				if((DVADescs[ax]==13) || (DVADescs[ax]==10))
																				{
                                                                                    DVADescsDup[an]='\0';
																				}
																				else
																				{
                                                                                     DVADescsDup[an]=DVADescs[ax];
																					 an++;
																				}

																			} 

																			printf(" Length of DVADescs = %d ",tc_strlen(DVADescs));
																			printf(" Length of DVADescsDup = %d ",tc_strlen(DVADescsDup));

																			printf(" DVADescs = %s\n",DVADescs);
																			printf(" DVADescsDup = %s\n",DVADescsDup);







// Testing









//																			des=tc_strlen(DVADescs);
//																			DVADescsDup = (char *)MEM_alloc(des);
//																			//qry_values1[2] = (char *)MEM_alloc( strlen( todate ) + 1);
//																			//STRNG_replace_str(DVADescsDup3,","," ",&DVADescsDup4);
//																			//STRNG_replace_str(DVADescs,"\n",";",&DVADescsDup);
//
//																			tc_strcpy(DVADescsDup,"");
//																			tc_strcat(DVADescsDup,DVADescs);
//																			tc_strcat(DVADescsDup,"");
//																			
//																			x=0;
//																			for(z=0;z<des;z++)
//																			{
//																			
//																			if(DVADescsDup[z]!='\n')
//																			{
//																				printf("\n Inside assif loop\n");
//																			
//																			DVADescsDup[x++]=DVADescsDup[z];
//																			
//																			
//																			}
//																			
//																			
//																			}
//																			DVADescsDup[x]='\0';
//
//
//																			printf("After remove New Line \n %s",DVADescsDup);
//   



																			

//
//
//																			
//																			
//																			printf("\n des len 4 [%d] ",des);
//																			printf("\n DVADescs value is [%s] ",DVADescs);fflush(stdout);
//																			printf("\n DVADescs current_name is [%s] ",DFQdocnos);fflush(stdout);
//																			tc_strcpy(DVADescsDup3,"");
//																			tc_strcpy(DVADescsDup3,DVADescs);
//													    					//tc_strdup(DVADescs,&DVADescsDup3);


//

//																			printf("\n DVADescsDup3 value is 2[%s] ",DVADescsDup3);fflush(stdout);
//
//																			
																			//STRNG_replace_str(DVADescsDupJ5,")"," ",&DVADescsDup);
																			printf("\n DVADescsDup value is 2[%s] ",DVADescsDup);fflush(stdout);

																			STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup11);

																			printf(" DVADescsDup11 = %s\n",DVADescsDup11);

																			AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitys);

																			printf("\n DFQApplicablility [%d] ",DFQApplicablilitys);

																			if(DFQApplicablilitys == 1)
																			{
																				tc_strcpy(DFQApplicablilitysDup,"");
																				tc_strdup("Yes",&DFQApplicablilitysDup);
																				printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
																			}
																			else
																			{
																				tc_strcpy(DFQApplicablilitysDup,"");
																				tc_strdup("No",&DFQApplicablilitysDup);
																				printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
																			}
//																			STRNG_replace_str(DFQApplicablilitysDup,"\n",",",&DFQApplicablilitysDup1);
//																			printf("\n DFQApplicablilityDup [%s]  DVA name DFQdocnos[%s]",DFQApplicablilitysDup1,DFQdocnos);fflush(stdout);


																			ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQComment",&DFQComments));
																			tc_strdup(DFQComments,&DFQCommentsDup);

																			STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
																			STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

																			ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
																			ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

																			printf("*n Foundpdf --- %d* \n",nFoundpdfs);fflush(stdout);
																			printf("*n Foundexcel --- %d* \n",nFoundexcels);fflush(stdout);

																			if (nFoundpdfs == 0)
																			{
																				tc_strdup("No",&Foundpdfs);
																			}else{
																				tc_strdup("Yes",&Foundpdfs);
																			}

																			if (nFoundexcels == 0)
																			{
																				tc_strdup("No",&Foundexcels);
																			}else{
																				tc_strdup("Yes",&Foundexcels);
																			}

																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQDesNom",&Designnominals));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DNDefTarget",&Definedtargets));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQAchNom",&Achievednominals));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_ANDefTarget",&Achievedtargets));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQCpkVal",&CpkDups));

																			ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQMeetExp",&Meetexpectation));
																			tc_strdup(Meetexpectation,&MeetexpectationDup);

																			if(tc_strcmp(MeetexpectationDup,"N")==0)
																			{

														                         tc_strdup("No",&MeetexpectationDupMM);
																			}
																			if(tc_strcmp(MeetexpectationDup,"Y")==0)
																			{
														                          tc_strdup("Yes",&MeetexpectationDupMM);
																			}
																			if(tc_strcmp(MeetexpectationDup,"NA")==0)
																			{
														                          tc_strdup("NA",&MeetexpectationDupMM);
																			}

																			//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

																			ITK_CALL(AOM_ask_value_date(DVA_document_tag[d],"last_mod_date",&Lastmoddates));
																			ITK_CALL(DATE_date_to_string(Lastmoddates,"%d/%m/%Y",&LastmoddatesDup));

																			printf("\n DFQUIDDup* [%s] DVADescsDup11* [%s] DFQApplicablilityDup*  [%s] DFQCommentDup* [%s] DFQdocnoDup* [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",ProjbussDup,DVADescsDup11,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDup,LastmoddatesDup);fflush(stdout);
																			fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup11,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDupMM,LastmoddatesDup);
											}
										 }

											   }
											   }
											 }
											
										   }
									  }
									  fclose(file);
								   }
								   else if (((tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0)) && (tc_strcmp(DmlRelTypeDup,"TODR")==0) && (tc_strcmp(type,"VC")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{
									   printf("\n TODR Fourth condition conditin part_type [%s] DmlRelStatDup [%s] PartNum [%s] \n",part_typeDup,DmlRelTypeDup,PartNum);fflush(stdout);

                                        char *VCPrtModNum=NULL;
	                                    char *VCPrtModNumType=NULL;
										char *CurReC=NULL;
										char*CurSeC=NULL;
										char*PartNums1=NULL;
										char*PartNums1Dup=NULL;
										char*ModuleName=NULL;
										char*ModuleNameDup=NULL;
										char*ModuleNumstyp=NULL;
										char*ModuleNumstypDup=NULL;
										char*Moduledescp=NULL;
										char*ModuledescpDup=NULL;
										char*ModulePartRevs=NULL;
										char*ModulePartRevsDup=NULL;
										char*ModuleAddre=NULL;
										char*ModuleAddreDup=NULL;
										char*Modulepartst=NULL;
										char*ModulepartstDup=NULL;
										char*ModulePartRelStats=NULL;
										char*ModuleOwners=NULL;
										char*MCurRevs=NULL;
										char*MCurSeqs=NULL;


										tag_t ChildMobject= NULLTAG;
                                        tag_t Snapshot_tag = NULLTAG;
		                                tag_t snapshotObjTypeTag = NULLTAG;
										tag_t *snapshotObjSet = NULLTAG;
										 //char snapshotObjtype_name[TCTYPE_name_size_c+1];
		                                 char *snapshotObjtype_name = NULL;
		                                 char *ObjName = NULL;
										 int snapshotCount=0;
										 tag_t item_rev_tags	= NULLTAG;
		                                 char* SSTopLineRev	= NULL;
										 tag_t window		= NULLTAG;
										 int		rulefound		=	0;
	                                     tag_t	*closurerule	=	NULLTAG;
										 PIE_scope_t scope;
	                                     scope=PIE_TEAMCENTER;
										 tag_t	close_tag		=	NULLTAG;
	                                     char	**rulename		=	NULL;
	                                     char	**rulevalue		=	NULL;
										 char *Item_ID_str	= NULL;
										 tag_t top_line		= NULLTAG;
										  int Item_ID=0;
										  tag_t	*ColIndChilds		=	NULLTAG;
									      tag_t	*Modulechilds=NULLTAG;
                                    int count=0;
									int ichld=0;
									int count1=0;
									int chld=0;

									
	                                    tag_t	Childobject1			=	NULLTAG;

										tag_t* DVA_document_tag = NULLTAG;
										int DVA_result_counts=0;
                                         
										 logical DFQApplicablilitys1= 0;
										 logical DFQApplicablilitys=0;
										 
                                          int d=0;
										  int j=0;
                                       char* DFQdocnos				= NULL;
										char* DFQdocnosDup			= NULL;
										char* DFQUIDs				= NULL;
										char* DFQUIDsDup				= NULL;
										char* DVADescs				= NULL;
										char* DVADescsDup			= NULL;
										char* DFQComments			= NULL;
										char* DFQCommentsDup			= NULL;
										char* Meetexpectation		= NULL;
										char* MeetexpectationDup	= NULL;
										char*MeetexpectationDupM=NULL;
										char* Foundpdfs				= NULL;
										char* Foundexcels			= NULL;
										date_t Lastmoddates;
										char* LastmoddatesDup		= NULL;
                                        char* DFQApplicablilitysDup=NULL;
										char*ItemType=NULL;
										int nFoundpdfs= 0;
										int nFoundexcels= 0;

										tag_t* refobjpdfs  = NULLTAG;
										tag_t* refobjexcels  = NULLTAG;

										double Designnominals;
										double Definedtargets;
										double Achievednominals;
										double Achievedtargets;
										double CpkDups;
                                        tag_t* dfq_use_case_tags = NULLTAG;
										tag_t relTypeTags = NULLTAG;
										char* ProjdescDup = NULL;
                                        char*Projname=NULL;
										Projname = (char *)MEM_alloc(50);
										char*VPrtdescM=NULL;
										char*PsProgScaleCC=NULL;
										tag_t GCI_relation=NULLTAG;
										tag_t*GciObj=NULLTAG;
										int GCI=0;
										int Demerit_rating=0;
										int Demerit=0;
										double GCIind;
										int gc=0;
										tag_t GCItag=NULLTAG;
										char *VPrtdescMdup = NULL;
										char *VPrtdescMdup1 = NULL;
										char *VPrtdescMdup2 = NULL;
										char *DVADescsDup12 = NULL;
										char *DVADescsDup13 = NULL;
								        VPrtdescMdup1 = (char *)MEM_alloc(100);
								        VPrtdescMdup = (char *)MEM_alloc(100);
								        VPrtdescMdup2 = (char *)MEM_alloc(100);
								        DVADescsDup = (char *)MEM_alloc(100);
								        DVADescsDup12 = (char *)MEM_alloc(100);
								        DVADescsDup13 = (char *)MEM_alloc(100);

										char			Data[100]					= "";
                                  time_t 	now;
	                              struct 	tm when;
								  int des =0;

	                             time(&now);
	                            when = *localtime(&now);
                               strftime(Data,100,"%Y/%b/%d-%H_%M_%S",&when);
										

									   ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&VCPrtModNum));
	                                    ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&VCPrtModNumType));
                                     printf("\nVC number is [%s]",VCPrtModNum); fflush(stdout);
									 CurReC = strtok(VCPrtModNumType,";");
										CurSeC = strtok(NULL,";");
										 printf("\nVC number rev and seq is [%s],[%s]",CurReC,CurSeC); fflush(stdout);

										 ITK_CALL(AOM_ask_value_string(PartTag,"object_desc",&VPrtdescM));
										 printf("\n desc before dup2 [%s]",VPrtdescM); fflush(stdout);

										 tc_strdup(VPrtdescM,&VPrtdescMdup);

										 STRNG_replace_str(VPrtdescMdup,"."," ",&VPrtdescMdup1);
										 STRNG_replace_str(VPrtdescMdup1,","," ",&VPrtdescMdup2);

										  printf("\n desc after VPrtdescMdup1 [%s]",VPrtdescMdup1); fflush(stdout);
										  printf("\n desc after VPrtdescMdup2 [%s]",VPrtdescMdup2); fflush(stdout);
										  

										 ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_ProgramScale",&PsProgScaleCC));
										printf("\nCCVC program scale is [%s]",PsProgScaleCC); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(getBusinessUnitFun(PartTag, &ProjdescDup,&Projname));
										printf("\n Project Descp :[%s]\n",ProjdescDup);   fflush(stdout);

										//ITK_CALL(getBusinessUnit(PartTag, &Projname));
										printf("\n Project Name :[%s]\n",Projname);   fflush(stdout);

										ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

										ITK_CALL(GRM_list_secondary_objects_only(PartTag,GCI_relation,&GCI,&GciObj));

										if(GCI>0)
										{
											for(gc=0;gc<GCI;gc++)
													{
														printf("\n inside for loop gc count****.\n");fflush(stdout);

														GCItag=GciObj[gc];

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&Demerit));
														printf("\n Demerit :[%d]\n",Demerit);fflush(stdout);

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_rating_S1",&Demerit_rating));
														printf("\n Demerit_rating :[%d]\n",Demerit_rating);fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCItag,"t5_geometry_conf_index_a1",&GCIind));
														printf("\n GCIind:[%lf]\n",GCIind);fflush(stdout);
                                                    }
										}

                              printf("\n GCIind******\n");fflush(stdout);
                        //tc_strcat(fsuccess_na,"/user/cvprod/MIS_Client_Code_CV/Reports/");
                       // sprintf(fsuccess_na,"/user/cvprod/MIS_Client_Code_CV/Reports/MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VCPrtModNum,CurReC,CurSeC,ProjbussDup,Projname);
                        sprintf(fsuccess_na,"MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VCPrtModNum,CurReC,CurSeC,ProjbussDup,Projname);
	                    fptr = fopen(fsuccess_na,"w");



                     fprintf(fptr,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
					 fprintf(fptr,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VCPrtModNum,CurReC,CurSeC);
					 fprintf(fptr,",,,Description,%s,,Program Scale,%s,,,\n",VPrtdescMdup2,PsProgScaleCC);
					 fprintf(fptr,",,,VC Status,%s,,,,,,\n",partstsDup);
                     fprintf(fptr,",,,Owner,%s,,,,,,\n",Owner);
                     fprintf(fptr,",,,Last Updated,,,,,,,\n");
                     fprintf(fptr,",,,Project Name,%s,,,,,,\n",prjcodeDup);
					 fprintf(fptr,",,,Project Description,%s,,,,,,\n",ProjdescDup);
					  printf("\n ****GCIind******\n");fflush(stdout);
					 if(Demerit)
					 {
                        fprintf(fptr,",,,Demerit Score(V),%d,,,,,,\n",Demerit);                                  
					 }
					 else
					 {
						 fprintf(fptr,",,,Demerit Score(V),%s,,,,,,\n","Nil");
					 }
					 if(Demerit_rating)
					{
                      fprintf(fptr,",,,Demerit Score Rating(S),%d,,,,,,\n",Demerit_rating);
					}
					 else
					{	
					 fprintf(fptr,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
					}
					if(GCIind)
					{
                      fprintf(fptr,",,,Geometry conformance Index(A),%lf,,,,,,\n",GCIind);
					}
					else{

					 fprintf(fptr,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
					}
                     fprintf(fptr,"\n\n");

fprintf(fptr,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update\n");





										 if(AOM_ask_value_tags(PartTag,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet)!= ITK_ok);
		                                 printf("\n WTRoll::snapshotCount ::  %d ", snapshotCount);fflush(stdout);

		                                if(snapshotCount>0)
		                                   {
											 printf("inside the snapshotCount**\n");fflush(stdout);
				                             Snapshot_tag = NULLTAG;
				                             snapshotObjTypeTag = NULLTAG;
				                             Snapshot_tag = snapshotObjSet[0];
                                               //printf(" the snapshotCount**\n");fflush(stdout);
				                             ITK_CALL(TCTYPE_ask_object_type(Snapshot_tag,&snapshotObjTypeTag));
				                             ITK_CALL( TCTYPE_ask_name2(snapshotObjTypeTag,&snapshotObjtype_name));
				                             printf("\n CCVC snapshotObjtype_name := %s\n", snapshotObjtype_name);fflush(stdout);
				                              
				                             ITK_CALL(AOM_ask_value_string(Snapshot_tag,"object_name",&ObjName));
				                             printf(" ObjName***: [%s] \n", ObjName);fflush(stdout);
				                              
				                             //if (AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev) != ITK_ok);
			                                  // if (AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags) != ITK_ok);
                                                //printf(" the snapshotCount topline**\n");fflush(stdout);
				                             ITK_CALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
				                             ITK_CALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));
                                              printf(" Snapshot tag is***: [%s] \n", SSTopLineRev);fflush(stdout);
				                              
                                                // printf(" the snapshotCount topline1**\n");fflush(stdout);
                                             ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));
				                             ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
				                             ITKCALL(BOM_set_window_pack_all (window, FALSE));
                                               //printf("after top line**\n");fflush(stdout);
					
					

				                             ITK_CALL( PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
				                              printf ("\n rule count %d \n",rulefound);fflush(stdout);
				                              if (rulefound > 0)
				                              {
				                             	close_tag = closurerule[0];
				                             	//printf ("closure rule found \n"); fflush(stdout);
				                              }
				                              ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
				                              printf ("closure rule found applied \n"); fflush(stdout);
				                             // ITKCALL(BOM_set_window_pack_all (window, FALSE));
				                              //ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
		                                     ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));
		                                     
		                                    // ITKCALL( TCTYPE_ask_property_by_name (top_line,"bl_item_item_id",&Item_ID));
		                                   ///  ITKCALL( AOM_ask_displayable_values(top_line, Item_ID,& &Item_ID_str));
											// printf(" BOm line string is***: [%s] \n", Item_ID_str);fflush(stdout);
											 ITKCALL(BOM_line_ask_child_lines(top_line, &count, &ColIndChilds));
											 printf(" BOm line count is***: [%d] \n", count);fflush(stdout);

											 if (count >0)
			                                 {
				                              for (ichld=0;ichld<count ;ichld++ )
				                               {
					                           // if(Childobject1) Childobject1=NULLTAG;
					                                 Childobject1=ColIndChilds[ichld];
                                                
												ITK_CALL(AOM_ask_value_string(Childobject1,"bl_item_item_id",&PartNums1));
									            tc_strdup(PartNums1,&PartNums1Dup);
									            printf("\nPart number is in module*** [%s]",PartNums1Dup); fflush(stdout);

												
												ITKCALL(BOM_line_ask_child_lines(Childobject1, &count1, &Modulechilds));
												 printf("\n module line count is***: [%d]", count1);fflush(stdout);

                                                if (count1 >0)
			                                   {
                                               printf("\n module line****************** count is****\n");fflush(stdout);
				                              
												for (chld=0;chld<count1 ;chld++ )
				                               {
					                            if(ChildMobject) ChildMobject=NULLTAG;
					                                 ChildMobject=Modulechilds[chld];
                                    int resultCount1=0;
                                   
									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_item_item_id",&ModuleName));
									tc_strdup(ModuleName,&ModuleNameDup);
									printf("\n module number is [%s]",ModuleNameDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartType",&ModuleNumstyp));
									tc_strdup(ModuleNumstyp,&ModuleNumstypDup);
									printf("\nPart type is [%s]",ModuleNumstypDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_Design Revision_t5_CategoryName",&Moduledescp));
									tc_strdup(Moduledescp,&ModuledescpDup);
									STRNG_replace_str(ModuledescpDup,","," ",&ModuledescpDup);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_rev_item_revision_id",&ModulePartRevs));
									tc_strdup(ModulePartRevs,&ModulePartRevsDup);
									printf("\nPart number revision [%s]",ModulePartRevsDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddre));
									tc_strdup(ModuleAddre,&ModuleAddreDup);
                                    printf("\nPart number address [%s]",ModuleAddreDup); fflush(stdout);


									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartStatus",&Modulepartst));
									tc_strdup(Modulepartst,&ModulepartstDup);
									 printf("\nPart number status [%s]",ModulepartstDup); fflush(stdout);



									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_rev_release_status_list",&ModulePartRelStats));
                                     printf("\nPart release is [%s]",ModulePartRelStats); fflush(stdout);
									if(tc_strstr(ModulePartRelStats,"ERC Released")!=NULL)
									{
										printf("\nPart [%s] Release Status [%s]",ModuleNameDup,ModulePartRelStats); fflush(stdout);
										//tc_strcpy(ModuleOwners,"Release Vault");
										tc_strdup("Release Vault",&ModuleOwners);
                                          printf("\nPart release is** [%s]",ModuleOwners); fflush(stdout);
									}

									    MCurRevs = strtok(ModulePartRevsDup,";");
										MCurSeqs = strtok(NULL,";");

										printf("\n Current Revision is %s",MCurRevs);fflush(stdout);
										printf("\n Current Sequence is %s",MCurSeqs);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);

										if(tc_strcmp(ModuleNumstypDup,"M")==0)
							           {


										ITK_CALL(getBusinessUnitFunct(ChildMobject, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(GetDVAUseCaseFromLibraryt(ChildMobject, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount1);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										tag_t itemTagm = NULLTAG;
										tag_t itemRevTagm = NULLTAG;
										ITEM_find_item(ModuleName, &itemTagm);
										//ITEM_ask_latest_rev(itemTagm,&itemRevTagm);
										printf("\n checking :[%s],[%s]\n",ModuleName,ModulePartRevs);   fflush(stdout);
									    ITEM_find_revision(itemTagm,ModulePartRevs,&itemRevTagm);
										/*if(itemRevTagm==NULLTAG)
												   {
                                                    printf("inside the NULLTAG\n");fflush(stdout);
                                                    exit(0);
												   }
												   else
												   {

                                                      printf("\nTag found");fflush(stdout);
												   }*/
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);
                                   
										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										printf("\n No of Attached DFQ Documetns are**m :: %d\n",DVA_result_counts);fflush(stdout);

										  int trueflaggg=0;
									     int falseflaggg=0;

                                        if (DVA_result_counts >0)
										{
											
											for (j=0;j<DVA_result_counts; j++ )
											{
												AOM_ask_value_logical(DVA_document_tag[j],"t5_DFQApplicablility",&DFQApplicablilitys1);

												printf("\n DFQApplicablility [%d] ",DFQApplicablilitys1);

												if(DFQApplicablilitys1 == 1)
												{
													//tc_strdup("Yes",&DFQApplicablilitysDup);
                                                    trueflaggg++;
													//printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													//tc_strdup("No",&DFQApplicablilitysDup);
													falseflaggg++;
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}

											}
										}

										printf("\n PartNumDup**** [%s] CurRev**** [%s] CurSeq**** [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",ModuleNameDup,MCurRevs,MCurSeqs,ModulepartstDup,ModuleAddreDup,PrerevDRstat,ProjbussDup,ModuledescpDup,ModuleOwners);fflush(stdout);
										fprintf(fptr,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d\n",ModuleNameDup,MCurRevs,MCurSeqs,ModulepartstDup,ModuleAddreDup,ProjbussDup,ModuledescpDup,ModuleOwners,resultCount1,falseflaggg,trueflaggg);

										if (DVA_result_counts >0)
										{
										printf("in there-------------------------------------------------------------------------------------------------------");;fflush(stdout);

											for (d=0;d<DVA_result_counts; d++ )
											{
												AOM_ask_value_string(DVA_document_tag[d],"current_name",&DFQdocnos);
												tc_strdup(DFQdocnos,&DFQdocnosDup);

												AOM_ask_value_string(DVA_document_tag[d],"t5_DFQUID",&DFQUIDs);
												tc_strdup(DFQUIDs,&DFQUIDsDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[d],"object_desc",&DVADescs));
//												des=tc_strlen(DVADescs);
//												printf("\n des len 1 [%d] ",des);
//												tc_strdup(DVADescs,&DVADescsDup12);
//
//												STRNG_replace_str(DVADescsDup12,","," ",&DVADescsDup13);
//												STRNG_replace_str(DVADescsDup13," "," ",&DVADescsDup);


                                                int an=0;
												int ax=0; 
												printf(" Value of desc found = %s \n",DVADescs);
												printf(" Value of DFQdocnos found = %s \n",DFQdocnos);

												for(ax=0;DVADescs[ax]!='\0';ax++)
												{
													printf("\n char found4 = %c , ascii found = %d \n",DVADescs[ax],DVADescs[ax]);

													//if(DVADescs[ax]==13)
													if((DVADescs[ax]==13) || (DVADescs[ax]==10))
													{
														DVADescsDup[an]='\0';
													}
													else
													{
														 DVADescsDup[an]=DVADescs[ax];
														 an++;
													}

												} 

												printf(" Length of DVADescs = %d ",tc_strlen(DVADescs));
												printf(" Length of DVADescsDup = %d ",tc_strlen(DVADescsDup));

												printf(" DVADescs = %s\n",DVADescs);
												printf(" DVADescsDup = %s\n",DVADescsDup);
												//STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup13);


												AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitys);

												printf("\n DFQApplicablility [%d] ",DFQApplicablilitys);

												if(DFQApplicablilitys == 1)
												{
													tc_strdup("Yes",&DFQApplicablilitysDup);
                                                   
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													tc_strdup("No",&DFQApplicablilitysDup);
													
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQComment",&DFQComments));
												tc_strdup(DFQComments,&DFQCommentsDup);

												STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
												STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

												printf("*n Foundpdf --- %d* \n",nFoundpdfs);fflush(stdout);
												printf("*n Foundexcel --- %d* \n",nFoundexcels);fflush(stdout);

												if (nFoundpdfs == 0)
												{
													tc_strdup("No",&Foundpdfs);
												}else{
													tc_strdup("Yes",&Foundpdfs);
												}

												if (nFoundexcels == 0)
												{
													tc_strdup("No",&Foundexcels);
												}else{
													tc_strdup("Yes",&Foundexcels);
												}

												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQDesNom",&Designnominals));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DNDefTarget",&Definedtargets));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQAchNom",&Achievednominals));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_ANDefTarget",&Achievedtargets));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQCpkVal",&CpkDups));

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQMeetExp",&Meetexpectation));
												tc_strdup(Meetexpectation,&MeetexpectationDup);
												printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

												if(tc_strcmp(MeetexpectationDup,"N")==0)
												{

                                                     tc_strdup("No",&MeetexpectationDupM);
												}
												if(tc_strcmp(MeetexpectationDup,"Y")==0)
												{
                                                      tc_strdup("Yes",&MeetexpectationDupM);
												}
												if(tc_strcmp(MeetexpectationDup,"NA")==0)
												{
                                                      tc_strdup("NA",&MeetexpectationDupM);
												}


												//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

												ITK_CALL(AOM_ask_value_date(DVA_document_tag[d],"last_mod_date",&Lastmoddates));
												ITK_CALL(DATE_date_to_string(Lastmoddates,"%d/%m/%Y",&LastmoddatesDup));

												printf("\n DFQUIDDup**** [%s] DVADescsDup**** [%s] DFQApplicablilityDup****  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDup,LastmoddatesDup);fflush(stdout);
												fprintf(fptr,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDupM,LastmoddatesDup);
											}
										 }





									            }
                                               }

											 }

                                         }

										}

                                      }
									 
                                            


                                         fclose(fptr);
									}
									else
									{
										printf("\nPart : %s  having Part type : %s is NON Valide",PartNumDup,part_typeDup);fflush(stdout);
									}
																		
									
									 
									 

								}

							}
						}
					}
				}
			}
		}
	}
	else
	{
		printf("\n ERC Released DML not Found fromdate: [%s] , todate: [%s]",fromdate,todate);fflush(stdout);
		return 0;
	}

	if( resultCount11 > 0)
	{
		for (i=0;i<resultCount11;i++ )
		{
			ERCDMLTag1 = ERCDMLTags1[i];
           // printf("\t testcnt :%d:\n", i);fflush(stdout);
			if(TCTYPE_ask_object_type(ERCDMLTag1,&objTypeTag));
			if( TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n ErcDmlTag -> objTypeTag  %s\n", type_name);fflush(stdout);
			printf("\n Inside resultCount11 \n");fflush(stdout);

			OUTS("type_name",10,15,type_name);

	   if(strcmp(type_name,"ChangeRequestRevision")==0)
	   {
				ITK_CALL(AOM_ask_value_string(ERCDMLTag1,"item_id",&DmlId));
				tc_strdup(DmlId,&DmlIdDup);
				ITK_CALL(AOM_ask_value_string(ERCDMLTag1,"t5_rlstype",&DmlRelType));
				tc_strdup(DmlRelType,&DmlRelTypeDup);
				ITK_CALL(AOM_UIF_ask_value(ERCDMLTag1,"release_status_list",&DmlRelStat));
				tc_strdup(DmlRelStat,&DmlRelStatDup);

				printf("\nDmlIdDup [%s] DmlRelTypeDup [%s] DmlRelStatDup [%s]  \n",DmlIdDup,DmlRelTypeDup,DmlRelStatDup);fflush(stdout);

				if((tc_strcmp(DmlRelTypeDup,"Veh")==0) && (tc_strstr(DmlRelStatDup,"Released")==NULL))
				{

					printf("\nDmlIdDup1 [%s] DmlRelTypeDup1 [%s] DmlRelStatDup1 [%s]  \n",DmlIdDup,DmlRelTypeDup,DmlRelStatDup);fflush(stdout);
					int tskcnt =0,t=0,p=0;
					tag_t *SetOfDmlTasksTag= NULLTAG;
					char *TaskId=NULL;
					int partCnt=0;
					tag_t *SetOfPartTags= NULLTAG;

					ITK_CALL(AOM_ask_value_tags(ERCDMLTag1,"T5_DMLTaskRelation",&tskcnt,&SetOfDmlTasksTag));
					printf("\nDML Task Count : %d\n",tskcnt);fflush(stdout);

					if (tskcnt>0)
					{
						for(t=0;t<tskcnt;t++)
						{
							ITK_CALL(AOM_ask_value_string(SetOfDmlTasksTag[t],"item_id",&TaskId));
							printf("\nDML Task [%s]",TaskId);fflush(stdout);

							if (tc_strstr(TaskId,"APL")!=NULL)
							{
								printf("\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
								continue;
							}

							AOM_ask_value_tags(SetOfDmlTasksTag[t],"CMHasSolutionItem",&partCnt,&SetOfPartTags);
							printf("\nNo of Design Rev=%d\n",partCnt);
							if (partCnt>0)
							{
								char *PartNum=NULL;
								char *PartNumDup=NULL;
								char *PartRev=NULL;
								char *PartRevDup=NULL;
								char *PartRelStat=NULL;
								tag_t PartTag= NULLTAG;
								char *part_type=NULL;
								char *part_typeDup=NULL;
								char *desc=NULL;
								char *descDup=NULL;
								char *ModuleAddress=NULL;
								char *ModuleAddressDup=NULL;
								char *partsts=NULL;
								char *partstsDup=NULL;
								char *prjcode=NULL;
								char *prjcodeDup=NULL;
								char* PartColInd = NULL;
								char* PartColIndDup = NULL;
								char *ColorIDPart = NULL;
								char *ColorIDPartDup = NULL;
								char *UrnCode = NULL;
								char *prepartsts = NULL;
								char* PrerevDRstat	 = NULL;

								char* ProjVehclass = NULL;
								char* ProjVehclassDup = NULL;
								char* Projplnname = NULL;
								char* ProjplnnameDup = NULL;
								char* Projbuss = NULL;
								char* ProjbussDup = NULL;
								char* Projdesc = NULL;
								char* ProjdescDup = NULL;

								PrerevDRstat	=	(char	*)MEM_alloc(10);
								char* FirstrlzDR4	 = NULL;
								FirstrlzDR4	=	(char	*)MEM_alloc(10);

								char* Owner	= NULL;
								Owner = (char *)MEM_alloc(50);

								//displaying_objects();
								for(p=0;p<partCnt;p++)
								{
									PartTag=SetOfPartTags[p];

									printf("\n Part Class [%s]",type_name); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
									tc_strdup(PartNum,&PartNumDup);

									ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_CategoryName",&desc));
									tc_strdup(desc,&descDup);
									STRNG_replace_str(descDup,","," ",&descDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
									tc_strdup(PartRev,&PartRevDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ModuleAddress",&ModuleAddress));
									tc_strdup(ModuleAddress,&ModuleAddressDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartStatus",&partsts));
									tc_strdup(partsts,&partstsDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&PartColInd));
									tc_strdup(PartColInd,&PartColIndDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ProjectCode",&prjcode));
									tc_strdup(prjcode,&prjcodeDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
									tc_strdup(part_type,&part_typeDup);
									printf("\nPart type is*** [%s]",part_typeDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&PartRelStat));

									if(tc_strstr(PartRelStat,"ERC Review")==NULL)
									{
										printf("\nPart [%s] is not ERC Released LifeCycleState [%s] Skipping...",PartNum,PartRelStat); fflush(stdout);
										continue;
									}
									else
									{
										printf("\nPart [%s] Release Status [%s]",PartNum,PartRelStat); fflush(stdout);
										tc_strcpy(Owner,"WIP Vault");
									}

									//if((tc_strcmp(part_typeDup,"V")==0) || (tc_strcmp(part_typeDup,"VC")==0) || (tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0))
									if((tc_strcmp(part_typeDup,"M")==0) && (tc_strcmp(DmlRelTypeDup,"MR")==0) && (tc_strcmp(type,"M")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{
										//tc_strcat(fsuccess_name,"/user/cvprod/MIS_Client_Code_CV/Reports/");
										sprintf(fsuccess_name,"%s_%s_%s_%s.csv",PartNum,fromdate,todate,type);
	                                    fsuccess = fopen(fsuccess_name,"w");

	                                  fprintf(fsuccess,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,Last Update,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),DVA Use case Description\n");

										int revi = 0, revCnt = 0, preOffDR4 = 0, preOffDRstat = 0, ChkpreRev= 0;
										tag_t *allRevTag	 = NULLTAG;
										char* CurRev		 = NULL;
										char* CurSeq		 = NULL;
										tag_t relTypeTag = NULLTAG;
										tag_t* DVA_document_tags = NULLTAG;
										logical dfq_applicability;;
										int DVA_result_count = 0;
										int d = 0;
										int k = 0;

										logical DFQApplicablilitycheck	= 0;
										logical DFQApplicablility	= 0;
										char* DFQApplicablilityDup	= NULL;
										//DFQApplicablilityDup = (char *)MEM_alloc(100);

										double Designnominal;
										double Definedtarget;
										double Achievednominal;
										double Achievedtarget;
										double CpkDup;

										char* DFQdocno				= NULL;
										char* DFQdocnoDup			= NULL;
										char* DFQUID				= NULL;
										char* DFQUIDDup				= NULL;
										char* DVADesc				= NULL;
										char* DVADescDup			= NULL;
										char* DFQComment			= NULL;
										char* DFQCommentDup			= NULL;
										char* Meetexpectations		= NULL;
										char* MeetexpectationsDup	= NULL;
										char* Foundpdf				= NULL;
										char* Foundexcel			= NULL;
										date_t Lastmoddate;
										char* LastmoddateDup		= NULL;
										char* DVADescDup14		= NULL;
										char* DVADescDup15		= NULL;
                                        char*MeetexpectationDupMMM=NULL;
                                        char*DVADescsDup=NULL;

										int resultCount1 = 0;
										tag_t* dfq_use_case_tags = NULLTAG;

										int nFoundpdf= 0;
										int nFoundexcel= 0;
										int trueflag= 0;
										int falseflag= 0;
										tag_t* refobjpdf  = NULLTAG;
										tag_t* refobjexcel  = NULLTAG;
										DVADescDup	=	(char	*)MEM_alloc(100);
										DVADescDup14	=	(char	*)MEM_alloc(100);
										DVADescDup15	=	(char	*)MEM_alloc(100);
										DVADescsDup = (char *)MEM_alloc(100);

										CurRev = strtok(PartRevDup,";");
										CurSeq = strtok(NULL,";");

										printf("\n Current Revision is %s",CurRev);fflush(stdout);
										printf("\n Current Sequence is %s",CurSeq);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(GetDVAUseCaseFromLibrary(PartTag, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount1);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTag);

										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(PartTag, relTypeTag, &DVA_result_count,&DVA_document_tags));
										printf("\n No of Attached DFQ Documetns are :: %d\n",DVA_result_count);fflush(stdout);


										if (DVA_result_count >0)
										{
											for (k=0;k<DVA_result_count; k++ )
											{
												AOM_ask_value_logical(DVA_document_tags[k],"t5_DFQApplicablility",&DFQApplicablilitycheck);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck);

												if(DFQApplicablilitycheck == 1)
												{
													trueflag++;
												}
												else
												{
													falseflag++;
												}
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumDup,CurRev,CurSeq,partstsDup,ModuleAddressDup,PrerevDRstat,ProjbussDup,descDup,Owner);fflush(stdout);
										fprintf(fsuccess,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",PartNumDup,CurRev,CurSeq,partstsDup,ModuleAddressDup,ProjbussDup,descDup,Owner,resultCount1,falseflag,trueflag);

										if (DVA_result_count >0)
										{
											for (d=0;d<DVA_result_count; d++ )
											{
												AOM_ask_value_string(DVA_document_tags[d],"current_name",&DFQdocno);
												tc_strdup(DFQdocno,&DFQdocnoDup);

												AOM_ask_value_string(DVA_document_tags[d],"t5_DFQUID",&DFQUID);
												tc_strdup(DFQUID,&DFQUIDDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tags[d],"object_desc",&DVADesc));
//												tc_strdup(DVADesc,&DVADescDup14);
//
//												STRNG_replace_str(DVADescDup14,","," ",&DVADescDup15);
//												STRNG_replace_str(DVADescDup15,"@"," ",&DVADescDup);
                                                int an=0;
												int ax=0; 
												printf(" Value of desc found = %s \n",DVADesc);
												printf(" Value of DFQdocno found = %s \n",DFQdocno);

												for(ax=0;DVADesc[ax]!='\0';ax++)
												{
													printf("\n char found5 =   %c , ascii found = %d \n",DVADesc[ax],DVADesc[ax]);

													//if(DVADesc[ax]==13)
													if((DVADesc[ax]==13) || (DVADesc[ax]==10))
													{
														DVADescsDup[an]='\0';
													}
													else
													{
														 DVADescsDup[an]=DVADesc[ax];
														 an++;
													}

												} 

												printf(" Length of DVADesc = %d ",tc_strlen(DVADesc));
												printf(" Length of DVADescsDup = %d ",tc_strlen(DVADescsDup));

												printf(" DVADesc = %s\n",DVADesc);
												printf(" DVADescsDup = %s\n",DVADescsDup);

												AOM_ask_value_logical(DVA_document_tags[d],"t5_DFQApplicablility",&DFQApplicablility);

												printf("\n DFQApplicablility [%d] ",DFQApplicablility);

												if(DFQApplicablility == 1)
												{
													tc_strdup("Yes",&DFQApplicablilityDup);
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilityDup);fflush(stdout);
												}
												else
												{
													tc_strdup("No",&DFQApplicablilityDup);
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilityDup);fflush(stdout);
												}

												ITK_CALL(AOM_ask_value_string(DVA_document_tags[d],"t5_DFQComment",&DFQComment));
												tc_strdup(DFQComment,&DFQCommentDup);

												STRNG_replace_str(DFQCommentDup,","," ",&DFQCommentDup);
												STRNG_replace_str(DFQCommentDup,"\n"," ",&DFQCommentDup);

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tags[d],"T5_DFQ_PDF",&nFoundpdf,&refobjpdf));
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tags[d],"T5_DFQ_EXCEL",&nFoundexcel,&refobjexcel));

												printf("*n Foundpdf --- %d* \n",nFoundpdf);fflush(stdout);
												printf("*n Foundexcel --- %d* \n",nFoundexcel);fflush(stdout);

												if (nFoundpdf == 0)
												{
													tc_strdup("No",&Foundpdf);
												}else{
													tc_strdup("Yes",&Foundpdf);
												}

												if (nFoundexcel == 0)
												{
													tc_strdup("No",&Foundexcel);
												}else{
													tc_strdup("Yes",&Foundexcel);
												}

												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQDesNom",&Designnominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DNDefTarget",&Definedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQAchNom",&Achievednominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_ANDefTarget",&Achievedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQCpkVal",&CpkDup));

												ITK_CALL(AOM_ask_value_string(DVA_document_tags[d],"t5_DFQMeetExp",&Meetexpectations));
												tc_strdup(Meetexpectations,&MeetexpectationsDup);

												if(tc_strcmp(MeetexpectationsDup,"N")==0)
												{

                                                     tc_strdup("No",&MeetexpectationDupMMM);
												}
												if(tc_strcmp(MeetexpectationsDup,"Y")==0)
												{
                                                      tc_strdup("Yes",&MeetexpectationDupMMM);
												}
												if(tc_strcmp(MeetexpectationsDup,"NA")==0)
												{
                                                      tc_strdup("NA",&MeetexpectationDupMMM);
												}

												//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

												ITK_CALL(AOM_ask_value_date(DVA_document_tags[d],"last_mod_date",&Lastmoddate));
												ITK_CALL(DATE_date_to_string(Lastmoddate,"%d/%m/%Y",&LastmoddateDup));

												printf("\n DFQUIDDup [%s] DVADescsDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",DFQUIDDup,DVADescDup,DFQApplicablilityDup,DFQCommentDup,DFQdocnoDup,Foundpdf,Foundexcel,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationsDup,LastmoddateDup);fflush(stdout);
												fprintf(fsuccess,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDDup,DVADescsDup,DFQApplicablilityDup,DFQCommentDup,DFQdocnoDup,Foundpdf,Foundexcel,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationDupMMM,LastmoddateDup);
											}
										}
										fclose(fsuccess);
									}
									else if ((tc_strcmp(part_typeDup,"V")==0) && (tc_strcmp(DmlRelTypeDup,"Veh")==0) && (tc_strcmp(type,"V")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{
										printf("\n WIP First condition conditin part_type [%s] DmlRelStatDup [%s] PartNum [%s] \n",part_typeDup,DmlRelTypeDup,PartNum);fflush(stdout);
										char *VPrtModNum=NULL;
	                                    char *VPrtModNumType=NULL;
                                        tag_t	bom_wnd				=	NULLTAG;
                                        tag_t	rule				=	NULLTAG;
                                        tag_t	top_lne				=	NULLTAG;
										//int		n_count			=	0;
                                        int count=0;
										int		ichld			=	0;
										tag_t	*ArchNodeLines		=	NULLTAG;

	                                    tag_t	*ColIndChilds		=	NULLTAG;
	                                    tag_t	Childobject			=	NULLTAG;
										char* Owners	= NULL;
								     Owners = (char *)MEM_alloc(50);
                                         char *PartNums=NULL;
										 char *PartNumsDup=NULL;
										 char *PartNumstypDup=NULL;
										 char*PartNumstyp=NULL;
                                         char *descp=NULL;
										 char *descpDup=NULL;
                                         char *PartRevs=NULL;
										 char *PartRevsDup=NULL;
										 char *ModuleAddressp=NULL;
										 char *ModuleAddresspDup=NULL;
                                         char *partst=NULL;
										 char *partstDup=NULL;
										 char *PartRelStats=NULL;
										 char* CurRevs		 = NULL;
										char* CurSeqs		 = NULL;
										char *CurRe=NULL;
										char*CurSe=NULL;
										char*VPrtdesc=NULL;
										char*PsProgScale=NULL;
										int i=0;
										tag_t relTypeTags = NULLTAG;
										tag_t ItemTypeTag=NULLTAG;
										tag_t* DVA_document_tag = NULLTAG;
										int DVA_result_counts=0;
                                         int resultCount=0;
										 logical DFQApplicablilitycheck1= 0;
										 logical DFQApplicablilitys=0;
										 // int trueflagg=0;
										 // int falseflagg=0;
                                          int d=0;
                                       char* DFQdocnos				= NULL;
										char* DFQdocnosDup			= NULL;
										char* DFQUIDs				= NULL;
										char* DFQUIDsDup				= NULL;
										char* DVADescs				= NULL;
										char* DVADescsDup			= NULL;
										char* DFQComments			= NULL;
										char* DFQCommentsDup			= NULL;
										char* Meetexpectation		= NULL;
										char* MeetexpectationDup	= NULL;
										char* Foundpdfs				= NULL;
										char* Foundexcels			= NULL;
										date_t Lastmoddates;
										char* LastmoddatesDup		= NULL;
                                        char* DFQApplicablilitysDup=NULL;
										char*ItemType=NULL;
										int nFoundpdfs= 0;
										int nFoundexcels= 0;

										tag_t* refobjpdfs  = NULLTAG;
										tag_t* refobjexcels  = NULLTAG;

										double Designnominals;
										double Definedtargets;
										double Achievednominals;
										double Achievedtargets;
										double CpkDups;
                                        tag_t* dfq_use_case_tags = NULLTAG;
										char* ProjdescDup = NULL;
                                        char*Projname=NULL;
                                        char*MeetexpectationDupMM=NULL;
										char			Data[100]					= "";
										tag_t GCI_relation=NULLTAG;
										tag_t*GciObj=NULLTAG;
										int GCI=0;
										int Demerit_rating=0;
										int Demerit=0;
										double GCIind;
										int gc=0;
										tag_t GCItag=NULLTAG;
									
                                  time_t 	now;
	                              struct 	tm when;

								  PIE_scope_t scope;
	                              scope=PIE_TEAMCENTER;
								  int rulefound= 0;
								  tag_t *closurerule = NULLTAG;
								  tag_t close_tag = NULLTAG;
								  tag_t bom_variant_rule = NULLTAG;
								  tag_t objTypeTag=NULLTAG;
								  char type_name[TCTYPE_name_size_c+1];
								  tag_t e_block		= NULLTAG;
								  char **rulename = NULL;
	                              char **rulevalue = NULL;
								 // char *VPrtdescdup = NULL;
								  char *VPrtdescdup = NULL;
								  char *VPrtdescdup1 = NULL;
								  char *VPrtdescdup22 = NULL;
								  char *DVADescsDup16 = NULL;
								  char *DVADescsDup17 = NULL;
								  VPrtdescdup = (char *)MEM_alloc(100);
								  VPrtdescdup1 = (char *)MEM_alloc(100);
								  VPrtdescdup22 = (char *)MEM_alloc(100);
								  DVADescsDup = (char *)MEM_alloc(100);
								  DVADescsDup16 = (char *)MEM_alloc(100);
								  DVADescsDup17 = (char *)MEM_alloc(100);

	                             time(&now);
	                            when = *localtime(&now);
                               strftime(Data,100,"%Y/%b/%d-%H_%M_%S",&when);


										ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&VPrtModNum));
	                                    ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&VPrtModNumType));
                                     printf("\nV number is [%s]",VPrtModNum); fflush(stdout);
									 CurRe = strtok(VPrtModNumType,";");
										CurSe = strtok(NULL,";");

										ITK_CALL(AOM_ask_value_string(PartTag,"object_desc",&VPrtdesc));
										printf("\n desc before dup3 [%s]",VPrtdesc); fflush(stdout);
										tc_strdup(VPrtdesc,&VPrtdescdup);


										 STRNG_replace_str(VPrtdescdup,"."," ",&VPrtdescdup1);
										 STRNG_replace_str(VPrtdescdup1,","," ",&VPrtdescdup22);

										 printf("\n desc before VPrtdescdup1 [%s]",VPrtdescdup1); fflush(stdout);
										 printf("\n desc before VPrtdescdup22 [%s]",VPrtdescdup22); fflush(stdout);
										  
										   
										    

										ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_ProgramScale",&PsProgScale));
										printf("\nV program scale is [%s]",PsProgScale); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(getBusinessUnitFun(PartTag, &ProjdescDup,&Projname));
										printf("\n Project Descp :[%s]\n",ProjdescDup);   fflush(stdout);

										//ITK_CALL(getBusinessUnit(PartTag, &Projname));
										printf("\n Project Name :[%s]\n",Projname);   fflush(stdout);

										ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

										ITK_CALL(GRM_list_secondary_objects_only(PartTag,GCI_relation,&GCI,&GciObj));

										if(GCI>0)
										{
											for(gc=0;gc<GCI;gc++)
													{
														printf("\n inside for loop gc count****.\n");fflush(stdout);

														GCItag=GciObj[gc];

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&Demerit));
														printf("\n Demerit :[%d]\n",Demerit);fflush(stdout);
                                                       
														
														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_rating_S1",&Demerit_rating));
														printf("\n Demerit_rating :[%d]\n",Demerit_rating);fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCItag,"t5_geometry_conf_index_a1",&GCIind));
														printf("\n GCIind:[%lf]\n",GCIind);fflush(stdout);
                                                    }
										}
										  


                         //tc_strcat(fsuccess_nam,"/user/cvprod/MIS_Client_Code_CV/Reports/");
                        //sprintf(fsuccess_nam,"/user/cvprod/MIS_Client_Code_CV/Reports/MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname);
                        sprintf(fsuccess_nam,"MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname);
	                    file = fopen(fsuccess_nam,"w");

                     fprintf(file,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
					 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
					 fprintf(file,",,,Description,%s,,Program Scale,%s,,,\n",VPrtdescdup22,PsProgScale);
					 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
                     fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
                     fprintf(file,",,,Last Updated,,,,,,,\n");
                     fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
					 fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
                     if(Demerit)
					 {
                        fprintf(file,",,,Demerit Score(V),%d,,,,,,\n",Demerit);                                  
					 }
					 else{
						 fprintf(file,",,,Demerit Score(V),%s,,,,,,\n","Nil");
					 }
					 if(Demerit_rating)
					{
                      fprintf(file,",,,Demerit Score Rating(S),%d,,,,,,\n",Demerit_rating);
					}
					 else
					{	
					 fprintf(file,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
					}
					if(GCIind)
					{
                      fprintf(file,",,,Geometry conformance Index(A),%lf,,,,,,\n",GCIind);
					}
					else{

					 fprintf(file,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
					}
                     fprintf(file,"\n\n");

fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update\n");





										if(PartTag!=NULLTAG)
	                                  {
										    ITKCALL(BOM_create_window(&bom_wnd ));      //set new bom window
											ITK_CALL ( BOM_set_window_top_line( bom_wnd, NULLTAG, PartTag, NULLTAG, &top_lne ));
											ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE)); 
		                                    ITKCALL(CFM_find("ERC release and above", &rule));  //find the revision rule
											ITKCALL(BOM_set_window_config_rule(bom_wnd, rule));  // set revision rule for window

											//ITK_CALL( PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
											ITK_CALL( PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));

					                        printf ("vc_rule count %d \n",rulefound);fflush(stdout);
					                        
					                        if (rulefound > 0)
					                        {
					                        	close_tag = closurerule[0];
					                        	printf (" vc closure rule found \n");fflush(stdout);
					                        	// MEM_free(tags_found);
					                        }

											ITK_CALL(BOM_window_set_closure_rule( bom_wnd,close_tag, 0, rulename,rulevalue ));

					                       
					                       
                                            if(top_lne!=NULLTAG)
										  {  
                                             printf (" vc top found \n");fflush(stdout);
										  }
					                        printf( " vc_After BOM_set_window_top_line..\n");fflush(stdout);

//											ITK_CALL (  BOM_window_ask_variant_rules( bom_wnd,&bomcoutn,&bom_variant_rule ));
//					                        printf( " vc_release  BOM_window_ask_variant_rules..\n");fflush(stdout);
//											if(bom_variant_rule!=NULLTAG)
//										  {  
//                                             printf (" bom_variant_rule found \n");fflush(stdout);
//										  }
//
//											ITK_CALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
//					                        ITK_CALL( TCTYPE_ask_name2(objTypeTag,&type_name));
//											if(objTypeTag!=NULLTAG)
//										  {  
//                                             printf (" objTypeTag found \n");fflush(stdout);
//										  }

											ITK_CALL ( ITEM_ask_rev_variants ( PartTag, &e_block ));
					                        printf(" vc_ITEM_ask_rev_variants..\n");fflush(stdout);
											if(e_block!=NULLTAG)
										  {  
                                             printf (" e_block found \n");fflush(stdout);
										  }
					                        
											
                                           // ITKCALL(BOM_set_window_top_line( bom_wnd, NULLTAG, PartTag, NULLTAG, &top_lne ));



											if(top_lne!=NULLTAG)
		                                   {
			                                // ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
			                               //  printf("\n n_count --------> : %d\n", n_count);

										   ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
//										   if(ColIndChilds!=NULLTAG)
//										  {  
//                                             printf (" ColIndChilds found \n");fflush(stdout);
//										  }

										   ITK_CALL(BOM_window_hide_unconfigured(bom_wnd))   ;
						                   ITK_CALL(BOM_window_show_variants(bom_wnd))   ;

										   printf("\n vc_release After inside bom_window-----\n"); fflush(stdout);
						                   ITK_CALL(BOM_window_apply_variant_configuration(bom_wnd,1,&PartTag))   ;
						                   printf("\n vc_release After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
										    if(PartTag!=NULLTAG)
										  {  
                                             printf (" PartTag found \n");fflush(stdout);
										  }


                                           ITK_CALL(BOM_window_hide_variants(bom_wnd))   ;

						                  ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
//										   if(ColIndChilds!=NULLTAG)
//										  {  
//                                             printf (" ColIndChilds1 found \n");fflush(stdout);
//										  }

						                  printf("\n vcBom_count --------> : [%d]  ",count); fflush(stdout);
			                                 //ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
			                                // printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node

			                                 if (count >0)
			                                 {
				                              for (ichld=0;ichld<count ;ichld++ )
				                               {
					                            //if(Childobject) Childobject=NULLTAG;
					                                 Childobject=ColIndChilds[ichld];


									ITK_CALL(AOM_ask_value_string(Childobject,"bl_item_item_id",&PartNums));
									tc_strdup(PartNums,&PartNumsDup);
									printf("\nPart number is 5[%s]",PartNumsDup); fflush(stdout);

                                    ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartType",&PartNumstyp));
									tc_strdup(PartNumstyp,&PartNumstypDup);
									printf("\nPart type is [%s]",PartNumstypDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_Design Revision_t5_CategoryName",&descp));
									tc_strdup(descp,&descpDup);
									STRNG_replace_str(descpDup,","," ",&descpDup);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_rev_item_revision_id",&PartRevs));
									tc_strdup(PartRevs,&PartRevsDup);
									printf("\nPart number revision [%s]",PartRevsDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddressp));
									tc_strdup(ModuleAddressp,&ModuleAddresspDup);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartStatus",&partst));
									tc_strdup(partst,&partstDup);


									ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_rev_release_status_list",&PartRelStats));
                                     printf("\nPart release is [%s]",PartRelStats); fflush(stdout);
									if(tc_strstr(PartRelStats,"ERC Review")!=NULL)
									{
										printf("\nPart [%s] Release Status [%s]",PartNums,PartRelStats); fflush(stdout);
										tc_strcpy(Owners,"WIP Vault");
									}

									    CurRevs = strtok(PartRevsDup,";");
										CurSeqs = strtok(NULL,";");

										printf("\n Current Revision is %s",CurRevs);fflush(stdout);
										printf("\n Current Sequence is %s",CurSeqs);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);
										if(tc_strcmp(PartNumstypDup,"M")==0)
							          {

                                        ITK_CALL(getBusinessUnitFunct(Childobject, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(GetDVAUseCaseFromLibraryt(Childobject, ProjbussDup, &resultCount, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										tag_t itemTag = NULLTAG;
										tag_t itemRevTag = NULLTAG;

										tag_t	itemRevTagm2	=	NULLTAG;
										ITEM_find_item(PartNums, &itemTag);


										ITEM_find_revision(itemTag,PartRevs,&itemRevTagm2);




										//ITEM_ask_latest_rev(itemTag,&itemRevTag);
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);

										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm2, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										printf("\n No of Attached DFQ Documetns are** :: %d\n",DVA_result_counts);fflush(stdout);

										int trueflagg=0;
										int falseflagg=0;

                                        if (DVA_result_counts >0)
										{
											for (i=0;i<DVA_result_counts; i++ )
											{
												AOM_ask_value_logical(DVA_document_tag[i],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												if(DFQApplicablilitycheck1 == 1)
												{
													trueflagg++;
												}
												else
												{
													falseflagg++;
												}
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,PrerevDRstat,ProjbussDup,descpDup,Owners);fflush(stdout);
										fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,ProjbussDup,descpDup,Owners,resultCount,falseflagg,trueflagg);

										if (DVA_result_counts >0)
																	{
																		for (d=0;d<DVA_result_counts; d++ )
																		{
																			AOM_ask_value_string(DVA_document_tag[d],"current_name",&DFQdocnos);
																			tc_strdup(DFQdocnos,&DFQdocnosDup);

																			AOM_ask_value_string(DVA_document_tag[d],"t5_DFQUID",&DFQUIDs);
																			tc_strdup(DFQUIDs,&DFQUIDsDup);

																			tc_strcpy(DVADescsDup,"");
																			ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[d],"object_desc",&DVADescs));
																			//des=tc_strlen(DVADescs);

																			
																		   DVADescsDup = (char*)MEM_alloc(1000);
                                                                            
// Testing 
                                                                            int an=0;
                                                                            int ax=0; 
                                                                            printf(" Value of desc found = %s \n",DVADescs);
                                                                            printf(" Value of DFQdocnos found = %s \n",DFQdocnos);

																			for(ax=0;DVADescs[ax]!='\0';ax++)
																			{
                                                                                printf("\n char found = %c , ascii found = %d \n",DVADescs[ax],DVADescs[ax]);

																				//if(DVADescs[ax]==13)
																				if((DVADescs[ax]==13) || (DVADescs[ax]==10))
																				{
                                                                                    DVADescsDup[an]='\0';
																				}
																				else
																				{
                                                                                     DVADescsDup[an]=DVADescs[ax];
																					 an++;
																				}

																			} 

																			printf(" Length of DVADescs = %d ",tc_strlen(DVADescs));
																			printf(" Length of DVADescsDup = %d ",tc_strlen(DVADescsDup));

																			printf(" DVADescs = %s\n",DVADescs);
																			printf(" DVADescsDup = %s\n",DVADescsDup);
																			printf("\n DVADescsDup value is 2[%s] ",DVADescsDup);fflush(stdout);
																			STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup17);
																			printf(" DVADescsDup17 = %s\n",DVADescsDup17);







// Testing









//																			des=tc_strlen(DVADescs);
//																			DVADescsDup = (char *)MEM_alloc(des);
//																			//qry_values1[2] = (char *)MEM_alloc( strlen( todate ) + 1);
//																			//STRNG_replace_str(DVADescsDup3,","," ",&DVADescsDup4);
//																			//STRNG_replace_str(DVADescs,"\n",";",&DVADescsDup);
//
//																			tc_strcpy(DVADescsDup,"");
//																			tc_strcat(DVADescsDup,DVADescs);
//																			tc_strcat(DVADescsDup,"");
//																			
//																			x=0;
//																			for(z=0;z<des;z++)
//																			{
//																			
//																			if(DVADescsDup[z]!='\n')
//																			{
//																				printf("\n Inside assif loop\n");
//																			
//																			DVADescsDup[x++]=DVADescsDup[z];
//																			
//																			
//																			}
//																			
//																			
//																			}
//																			DVADescsDup[x]='\0';
//
//
//																			printf("After remove New Line \n %s",DVADescsDup);
//   



																			

//
//
//																			
//																			
//																			printf("\n des len 4 [%d] ",des);
//																			printf("\n DVADescs value is [%s] ",DVADescs);fflush(stdout);
//																			printf("\n DVADescs current_name is [%s] ",DFQdocnos);fflush(stdout);
//																			tc_strcpy(DVADescsDup3,"");
//																			tc_strcpy(DVADescsDup3,DVADescs);
//													    					//tc_strdup(DVADescs,&DVADescsDup3);


//

//																			printf("\n DVADescsDup3 value is 2[%s] ",DVADescsDup3);fflush(stdout);
//
//																			
																			//STRNG_replace_str(DVADescsDupJ5,")"," ",&DVADescsDup);
																			

																			AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitys);

																			printf("\n DFQApplicablility [%d] ",DFQApplicablilitys);

																			if(DFQApplicablilitys == 1)
																			{
																				tc_strcpy(DFQApplicablilitysDup,"");
																				tc_strdup("Yes",&DFQApplicablilitysDup);
																				printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
																			}
																			else
																			{
																				tc_strcpy(DFQApplicablilitysDup,"");
																				tc_strdup("No",&DFQApplicablilitysDup);
																				printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
																			}
//																			STRNG_replace_str(DFQApplicablilitysDup,"\n",",",&DFQApplicablilitysDup1);
//																			printf("\n DFQApplicablilityDup [%s]  DVA name DFQdocnos[%s]",DFQApplicablilitysDup1,DFQdocnos);fflush(stdout);


																			ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQComment",&DFQComments));
																			tc_strdup(DFQComments,&DFQCommentsDup);

																			STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
																			STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

																			ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
																			ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

																			printf("*n Foundpdf --- %d* \n",nFoundpdfs);fflush(stdout);
																			printf("*n Foundexcel --- %d* \n",nFoundexcels);fflush(stdout);

																			if (nFoundpdfs == 0)
																			{
																				tc_strdup("No",&Foundpdfs);
																			}else{
																				tc_strdup("Yes",&Foundpdfs);
																			}

																			if (nFoundexcels == 0)
																			{
																				tc_strdup("No",&Foundexcels);
																			}else{
																				tc_strdup("Yes",&Foundexcels);
																			}

																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQDesNom",&Designnominals));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DNDefTarget",&Definedtargets));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQAchNom",&Achievednominals));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_ANDefTarget",&Achievedtargets));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQCpkVal",&CpkDups));

																			ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQMeetExp",&Meetexpectation));
																			tc_strdup(Meetexpectation,&MeetexpectationDup);

																			if(tc_strcmp(MeetexpectationDup,"N")==0)
																			{

														                         tc_strdup("No",&MeetexpectationDupMM);
																			}
																			if(tc_strcmp(MeetexpectationDup,"Y")==0)
																			{
														                          tc_strdup("Yes",&MeetexpectationDupMM);
																			}
																			if(tc_strcmp(MeetexpectationDup,"NA")==0)
																			{
														                          tc_strdup("NA",&MeetexpectationDupMM);
																			}

																			//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

																			ITK_CALL(AOM_ask_value_date(DVA_document_tag[d],"last_mod_date",&Lastmoddates));
																			ITK_CALL(DATE_date_to_string(Lastmoddates,"%d/%m/%Y",&LastmoddatesDup));

																			printf("\n DFQUIDDup* [%s] DVADescsDup17* [%s] DFQApplicablilityDup*  [%s] DFQCommentDup* [%s] DFQdocnoDup* [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",ProjbussDup,DVADescsDup17,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDup,LastmoddatesDup);fflush(stdout);
																			fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup17,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDupMM,LastmoddatesDup);
											}
										 }

											   }
											   }
											 }
											
										   }
									  }
									  fclose(file);
								   }
								   else if (((tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0)) && (tc_strcmp(DmlRelTypeDup,"Veh")==0) && (tc_strcmp(type,"VC")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{

									   printf("\n WIP Second condition conditin part_type [%s] DmlRelStatDup [%s] PartNum [%s] \n",part_typeDup,DmlRelTypeDup,PartNum);fflush(stdout);

                                        char *VCPrtModNum=NULL;
	                                    char *VCPrtModNumType=NULL;
										char *CurReC=NULL;
										char*CurSeC=NULL;
										char*PartNums1=NULL;
										char*PartNums1Dup=NULL;
										char*ModuleName=NULL;
										char*ModuleNameDup=NULL;
										char*ModuleNumstyp=NULL;
										char*ModuleNumstypDup=NULL;
										char*Moduledescp=NULL;
										char*ModuledescpDup=NULL;
										char*ModulePartRevs=NULL;
										char*ModulePartRevsDup=NULL;
										char*ModuleAddre=NULL;
										char*ModuleAddreDup=NULL;
										char*Modulepartst=NULL;
										char*ModulepartstDup=NULL;
										char*ModulePartRelStats=NULL;
										char*ModuleOwners=NULL;
										char*MCurRevs=NULL;
										char*MCurSeqs=NULL;


										tag_t ChildMobject= NULLTAG;
                                        tag_t Snapshot_tag = NULLTAG;
		                                tag_t snapshotObjTypeTag = NULLTAG;
										tag_t *snapshotObjSet = NULLTAG;
										// char snapshotObjtype_name[TCTYPE_name_size_c+1];
		                                 char *ObjName = NULL;
		                                 char *snapshotObjtype_name = NULL;
										 int snapshotCount=0;
										 tag_t item_rev_tags	= NULLTAG;
		                                 char* SSTopLineRev	= NULL;
										 tag_t window		= NULLTAG;
										 int		rulefound		=	0;
	                                     tag_t	*closurerule	=	NULLTAG;
										 PIE_scope_t scope;
	                                     scope=PIE_TEAMCENTER;
										 tag_t	close_tag		=	NULLTAG;
	                                     char	**rulename		=	NULL;
	                                     char	**rulevalue		=	NULL;
										 char *Item_ID_str	= NULL;
										 tag_t top_line		= NULLTAG;
										  int Item_ID=0;
										  tag_t	*ColIndChilds		=	NULLTAG;
									      tag_t	*Modulechilds=NULLTAG;
                                    int count=0;
									int ichld=0;
									int count1=0;
									int chld=0;

									
	                                    tag_t	Childobject1			=	NULLTAG;

										tag_t* DVA_document_tag = NULLTAG;
										int DVA_result_counts=0;
                                         
										 logical DFQApplicablilitys1= 0;
										 logical DFQApplicablilitys=0;
										 
                                          int d=0;
										  int j=0;
                                       char* DFQdocnos				= NULL;
										char* DFQdocnosDup			= NULL;
										char* DFQUIDs				= NULL;
										char* DFQUIDsDup				= NULL;
										char* DVADescs				= NULL;
										char* DVADescsDup			= NULL;
										char* DFQComments			= NULL;
										char* DFQCommentsDup			= NULL;
										char* Meetexpectation		= NULL;
										char* MeetexpectationDup	= NULL;
										char*MeetexpectationDupM=NULL;
										char* Foundpdfs				= NULL;
										char* Foundexcels			= NULL;
										date_t Lastmoddates;
										char* LastmoddatesDup		= NULL;
                                        char* DFQApplicablilitysDup=NULL;
										char*ItemType=NULL;
										int nFoundpdfs= 0;
										int nFoundexcels= 0;
										int bomvalue= 1;

										tag_t* refobjpdfs  = NULLTAG;
										tag_t* refobjexcels  = NULLTAG;

										double Designnominals;
										double Definedtargets;
										double Achievednominals;
										double Achievedtargets;
										double CpkDups;
                                        tag_t* dfq_use_case_tags = NULLTAG;
										tag_t relTypeTags = NULLTAG;
										char* ProjdescDup = NULL;
                                        char*Projname=NULL;
										Projname = (char *)MEM_alloc(50);
										char*VPrtdescM=NULL;
										char*PsProgScaleCC=NULL;
										tag_t GCI_relation=NULLTAG;
										tag_t*GciObj=NULLTAG;
										int GCI=0;
										int Demerit_rating=0;
										int Demerit=0;
										double GCIind;
										int gc=0;
										tag_t GCItag=NULLTAG;

										char			Data[100]					= "";
                                  time_t 	now;
	                              struct 	tm when;
								  char *VPrtdescMdup = NULL;
								  char *VPrtdescMdup1 = NULL;
								  char *VPrtdescMdup2 = NULL;
								  char *DVADescsDup18 = NULL;
								  char *DVADescsDup19 = NULL;
								        VPrtdescMdup = (char *)MEM_alloc(100);
								        DVADescsDup19 = (char *)MEM_alloc(100);
								        DVADescsDup18 = (char *)MEM_alloc(100);
								        DVADescsDup = (char *)MEM_alloc(100);

	                             time(&now);
	                            when = *localtime(&now);
                               strftime(Data,100,"%Y/%b/%d-%H_%M_%S",&when);
										

									   ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&VCPrtModNum));
	                                    ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&VCPrtModNumType));
                                     printf("\nVC number is [%s]",VCPrtModNum); fflush(stdout);
									 CurReC = strtok(VCPrtModNumType,";");
										CurSeC = strtok(NULL,";");
										 printf("\nVC number rev and seq is [%s],[%s]",CurReC,CurSeC); fflush(stdout);

										 ITK_CALL(AOM_ask_value_string(PartTag,"object_desc",&VPrtdescM));
										 printf("\n desc befor dup4 [%s]",VPrtdescM); fflush(stdout);

										 tc_strdup(VPrtdescM,&VPrtdescMdup);
										  STRNG_replace_str(VPrtdescMdup,"."," ",&VPrtdescMdup1);
										  STRNG_replace_str(VPrtdescMdup1,","," ",&VPrtdescMdup2);
										   
										    printf("\ndes after VPrtdescMdup1 [%s]",VPrtdescMdup1); fflush(stdout);
										    printf("\ndes after VPrtdescMdup2 [%s]",VPrtdescMdup2); fflush(stdout);

										 ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_ProgramScale",&PsProgScaleCC));
										printf("\nCCVC program scale is [%s]",PsProgScaleCC); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(getBusinessUnitFun(PartTag, &ProjdescDup,&Projname));
										printf("\n Project Descp :[%s]\n",ProjdescDup);   fflush(stdout);

										//ITK_CALL(getBusinessUnit(PartTag, &Projname));
										printf("\n Project Name :[%s]\n",Projname);   fflush(stdout);

										ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

										ITK_CALL(GRM_list_secondary_objects_only(PartTag,GCI_relation,&GCI,&GciObj));

										if(GCI>0)
										{
											for(gc=0;gc<GCI;gc++)
													{
														printf("\n inside for loop gc count****.\n");fflush(stdout);

														GCItag=GciObj[gc];

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&Demerit));
														printf("\n Demerit :[%d]\n",Demerit);fflush(stdout);

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_rating_S1",&Demerit_rating));
														printf("\n Demerit_rating :[%d]\n",Demerit_rating);fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCItag,"t5_geometry_conf_index_a1",&GCIind));
														printf("\n GCIind:[%lf]\n",GCIind);fflush(stdout);
                                                    }
										}

                              printf("\n GCIind******\n");fflush(stdout);
                        //tc_strcat(fsuccess_na,"/user/cvprod/MIS_Client_Code_CV/Reports/");
                       // sprintf(fsuccess_na,"/user/cvprod/MIS_Client_Code_CV/Reports/MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VCPrtModNum,CurReC,CurSeC,ProjbussDup,Projname);
                        sprintf(fsuccess_na,"MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VCPrtModNum,CurReC,CurSeC,ProjbussDup,Projname);
	                    fptr = fopen(fsuccess_na,"w");



                     fprintf(fptr,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
					 fprintf(fptr,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VCPrtModNum,CurReC,CurSeC);
					 fprintf(fptr,",,,Description,%s,,Program Scale,%s,,,\n",VPrtdescMdup2,PsProgScaleCC);
					 fprintf(fptr,",,,VC Status,%s,,,,,,\n",partstsDup);
                     fprintf(fptr,",,,Owner,%s,,,,,,\n",Owner);
                     fprintf(fptr,",,,Last Updated,,,,,,,\n");
                     fprintf(fptr,",,,Project Name,%s,,,,,,\n",prjcodeDup);
					 fprintf(fptr,",,,Project Description,%s,,,,,,\n",ProjdescDup);
					  printf("\n ****GCIind******\n");fflush(stdout);
					 if(Demerit)
					 {
                        fprintf(fptr,",,,Demerit Score(V),%d,,,,,,\n",Demerit);                                  
					 }
					 else
					 {
						 fprintf(fptr,",,,Demerit Score(V),%s,,,,,,\n","Nil");
					 }
					 if(Demerit_rating)
					{
                      fprintf(fptr,",,,Demerit Score Rating(S),%d,,,,,,\n",Demerit_rating);
					}
					 else
					{	
					 fprintf(fptr,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
					}
					if(GCIind)
					{
                      fprintf(fptr,",,,Geometry conformance Index(A),%lf,,,,,,\n",GCIind);
					}
					else{

					 fprintf(fptr,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
					}
                     fprintf(fptr,"\n\n");

fprintf(fptr,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update\n");





										 if(AOM_ask_value_tags(PartTag,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet)!= ITK_ok);
		                                 printf("\n WTRoll::snapshotCount ::  %d ", snapshotCount);fflush(stdout);

		                                if(snapshotCount>0)
		                                   {
											 printf("inside the snapshotCount**\n");fflush(stdout);
				                             Snapshot_tag = NULLTAG;
				                             snapshotObjTypeTag = NULLTAG;
				                             Snapshot_tag = snapshotObjSet[0];
                                               //printf(" the snapshotCount**\n");fflush(stdout);
				                             ITK_CALL(TCTYPE_ask_object_type(Snapshot_tag,&snapshotObjTypeTag));
				                             ITK_CALL( TCTYPE_ask_name2(snapshotObjTypeTag,&snapshotObjtype_name));
				                             printf("\n CCVC snapshotObjtype_name := %s\n", snapshotObjtype_name);fflush(stdout);
				                              
				                             ITK_CALL(AOM_ask_value_string(Snapshot_tag,"object_name",&ObjName));
				                             printf(" ObjName***: [%s] \n", ObjName);fflush(stdout);
				                              
				                             //if (AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev) != ITK_ok);
			                                  // if (AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags) != ITK_ok);
                                                //printf(" the snapshotCount topline**\n");fflush(stdout);
				                             ITK_CALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
				                             ITK_CALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));
                                              printf(" Snapshot tag is***: [%s] \n", SSTopLineRev);fflush(stdout);
				                              
                                                // printf(" the snapshotCount topline1**\n");fflush(stdout);
                                             ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));
				                             ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
				                             ITKCALL(BOM_set_window_pack_all (window, FALSE));
                                               //printf("after top line**\n");fflush(stdout);
					
					

				                             ITK_CALL( PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
				                              printf ("\n rule count %d \n",rulefound);fflush(stdout);
				                              if (rulefound > 0)
				                              {
				                             	close_tag = closurerule[0];
				                             	//printf ("closure rule found \n"); fflush(stdout);
				                              }
				                              ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
				                              printf ("closure rule found applied \n"); fflush(stdout);
				                             // ITKCALL(BOM_set_window_pack_all (window, FALSE));
				                              //ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
		                                     ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));
		                                     
		                                    // ITKCALL( TCTYPE_ask_property_by_name (top_line,"bl_item_item_id",&Item_ID));
		                                   //  ITKCALL( AOM_ask_displayable_values(top_line, Item_ID,&bomvalue &Item_ID_str));
											 //printf(" BOm line string is***: [%s] \n", Item_ID_str);fflush(stdout);
											 ITKCALL(BOM_line_ask_child_lines(top_line, &count, &ColIndChilds));
											 printf(" BOm line count is***: [%d] \n", count);fflush(stdout);

											 if (count >0)
			                                 {
				                              for (ichld=0;ichld<count ;ichld++ )
				                               {
					                            //if(Childobject1) Childobject1=NULLTAG;
					                                 Childobject1=ColIndChilds[ichld];
                                                
												ITK_CALL(AOM_ask_value_string(Childobject1,"bl_item_item_id",&PartNums1));
									            tc_strdup(PartNums1,&PartNums1Dup);
									            printf("\nPart number is in module*** [%s]",PartNums1Dup); fflush(stdout);

												
												ITKCALL(BOM_line_ask_child_lines(Childobject1, &count1, &Modulechilds));
												 printf("\n module line count is***: [%d]", count1);fflush(stdout);

                                                if (count1 >0)
			                                   {
                                               printf("\n module line****************** count is****\n");fflush(stdout);
				                              
												for (chld=0;chld<count1 ;chld++ )
				                               {
					                            if(ChildMobject) ChildMobject=NULLTAG;
					                                 ChildMobject=Modulechilds[chld];
                                    int resultCount1=0;
                                   
									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_item_item_id",&ModuleName));
									tc_strdup(ModuleName,&ModuleNameDup);
									printf("\n module number is [%s]",ModuleNameDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartType",&ModuleNumstyp));
									tc_strdup(ModuleNumstyp,&ModuleNumstypDup);
									printf("\nPart type is [%s]",ModuleNumstypDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_Design Revision_t5_CategoryName",&Moduledescp));
									tc_strdup(Moduledescp,&ModuledescpDup);
									STRNG_replace_str(ModuledescpDup,","," ",&ModuledescpDup);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_rev_item_revision_id",&ModulePartRevs));
									tc_strdup(ModulePartRevs,&ModulePartRevsDup);
									printf("\nPart number revision [%s]",ModulePartRevsDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddre));
									tc_strdup(ModuleAddre,&ModuleAddreDup);
                                    printf("\nPart number address [%s]",ModuleAddreDup); fflush(stdout);


									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartStatus",&Modulepartst));
									tc_strdup(Modulepartst,&ModulepartstDup);
									 printf("\nPart number status [%s]",ModulepartstDup); fflush(stdout);



									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_rev_release_status_list",&ModulePartRelStats));
                                     printf("\nPart release is [%s]",ModulePartRelStats); fflush(stdout);
									if(tc_strstr(ModulePartRelStats,"ERC Review")!=NULL)
									{
										printf("\nPart [%s] Release Status [%s]",ModuleNameDup,ModulePartRelStats); fflush(stdout);
										//tc_strcpy(ModuleOwners,"Release Vault");
										tc_strdup("WIP Vault",&ModuleOwners);
                                          printf("\nPart release is** [%s]",ModuleOwners); fflush(stdout);
									}

									    MCurRevs = strtok(ModulePartRevsDup,";");
										MCurSeqs = strtok(NULL,";");

										printf("\n Current Revision is %s",MCurRevs);fflush(stdout);
										printf("\n Current Sequence is %s",MCurSeqs);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);

										if(tc_strcmp(ModuleNumstypDup,"M")==0)
							           {


										ITK_CALL(getBusinessUnitFunct(ChildMobject, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(GetDVAUseCaseFromLibraryt(ChildMobject, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount1);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										tag_t itemTagm = NULLTAG;
										tag_t itemRevTagm = NULLTAG;
										ITEM_find_item(ModuleName, &itemTagm);
										//ITEM_ask_latest_rev(itemTagm,&itemRevTagm);
										printf("\n checking :[%s],[%s]\n",ModuleName,ModulePartRevs);   fflush(stdout);
									    ITEM_find_revision(itemTagm,ModulePartRevs,&itemRevTagm);
										/*if(itemRevTagm==NULLTAG)
												   {
                                                    printf("inside the NULLTAG\n");fflush(stdout);
                                                    exit(0);
												   }
												   else
												   {

                                                      printf("\nTag found");fflush(stdout);
												   }*/
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);
                                   
										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										printf("\n No of Attached DFQ Documetns are**m :: %d\n",DVA_result_counts);fflush(stdout);

										  int trueflaggg=0;
									     int falseflaggg=0;

                                        if (DVA_result_counts >0)
										{
											
											for (j=0;j<DVA_result_counts; j++ )
											{
												AOM_ask_value_logical(DVA_document_tag[j],"t5_DFQApplicablility",&DFQApplicablilitys1);

												printf("\n DFQApplicablility [%d] ",DFQApplicablilitys1);

												if(DFQApplicablilitys1 == 1)
												{
													//tc_strdup("Yes",&DFQApplicablilitysDup);
                                                    trueflaggg++;
													//printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													//tc_strdup("No",&DFQApplicablilitysDup);
													falseflaggg++;
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}

											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",ModuleNameDup,MCurRevs,MCurSeqs,ModulepartstDup,ModuleAddreDup,PrerevDRstat,ProjbussDup,ModuledescpDup,ModuleOwners);fflush(stdout);
										fprintf(fptr,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",ModuleNameDup,MCurRevs,MCurSeqs,ModulepartstDup,ModuleAddreDup,ProjbussDup,ModuledescpDup,ModuleOwners,resultCount1,falseflaggg,trueflaggg);

										if (DVA_result_counts >0)
										{
										printf("\nin there-------------------------------------------------------------------------------------------------------\n");;fflush(stdout);

											for (d=0;d<DVA_result_counts; d++ )
											{
												AOM_ask_value_string(DVA_document_tag[d],"current_name",&DFQdocnos);
												tc_strdup(DFQdocnos,&DFQdocnosDup);

												AOM_ask_value_string(DVA_document_tag[d],"t5_DFQUID",&DFQUIDs);
												tc_strdup(DFQUIDs,&DFQUIDsDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[d],"object_desc",&DVADescs));
//												tc_strdup(DVADescs,&DVADescsDup18);
//
//												STRNG_replace_str(DVADescsDup18,","," ",&DVADescsDup19);
//												STRNG_replace_str(DVADescsDup19,"@"," ",&DVADescsDup);
                                                 int an=0;
												int ax=0; 
												printf(" Value of desc found = %s \n",DVADescs);
												printf(" Value of DFQdocnos found = %s \n",DFQdocnos);

												for(ax=0;DVADescs[ax]!='\0';ax++)
												{
													printf("\n char found7 = %c , ascii found = %d \n",DVADescs[ax],DVADescs[ax]);

													//if(DVADescs[ax]==13)
													if((DVADescs[ax]==13) || (DVADescs[ax]==10))
													{
														DVADescsDup[an]='\0';
													}
													else
													{
														 DVADescsDup[an]=DVADescs[ax];
														 an++;
													}

												} 

												printf(" Length of DVADescs = %d ",tc_strlen(DVADescs));
												printf(" Length of DVADescsDup = %d ",tc_strlen(DVADescsDup));

												printf(" DVADescs = %s\n",DVADescs);
												printf(" DVADescsDup = %s\n",DVADescsDup);

												AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitys);

												printf("\n DFQApplicablility [%d] ",DFQApplicablilitys);

												if(DFQApplicablilitys == 1)
												{
													tc_strdup("Yes",&DFQApplicablilitysDup);
                                                   
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													tc_strdup("No",&DFQApplicablilitysDup);
													
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQComment",&DFQComments));
												tc_strdup(DFQComments,&DFQCommentsDup);

												STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
												STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

												printf("*n Foundpdf --- %d* \n",nFoundpdfs);fflush(stdout);
												printf("*n Foundexcel --- %d* \n",nFoundexcels);fflush(stdout);

												if (nFoundpdfs == 0)
												{
													tc_strdup("No",&Foundpdfs);
												}else{
													tc_strdup("Yes",&Foundpdfs);
												}

												if (nFoundexcels == 0)
												{
													tc_strdup("No",&Foundexcels);
												}else{
													tc_strdup("Yes",&Foundexcels);
												}

												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQDesNom",&Designnominals));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DNDefTarget",&Definedtargets));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQAchNom",&Achievednominals));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_ANDefTarget",&Achievedtargets));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQCpkVal",&CpkDups));

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQMeetExp",&Meetexpectation));
												tc_strdup(Meetexpectation,&MeetexpectationDup);
												printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

												if(tc_strcmp(MeetexpectationDup,"N")==0)
												{

                                                     tc_strdup("No",&MeetexpectationDupM);
												}
												if(tc_strcmp(MeetexpectationDup,"Y")==0)
												{
                                                      tc_strdup("Yes",&MeetexpectationDupM);
												}
												if(tc_strcmp(MeetexpectationDup,"NA")==0)
												{
                                                      tc_strdup("NA",&MeetexpectationDupM);
												}


												//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

												ITK_CALL(AOM_ask_value_date(DVA_document_tag[d],"last_mod_date",&Lastmoddates));
												ITK_CALL(DATE_date_to_string(Lastmoddates,"%d/%m/%Y",&LastmoddatesDup));

												printf("\n DFQUIDDup [%s] DVADescsDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDup,LastmoddatesDup);fflush(stdout);
												fprintf(fptr,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDupM,LastmoddatesDup);
											}
										 }





									            }
                                               }

											 }

                                         }

										}

                                      }
									 
                                            


                                         fclose(fptr);
									}
									else
									{
										printf("\nPart : %s  having Part type : %s is NON Valide",PartNumDup,part_typeDup);fflush(stdout);
									}
																		
									
									 
									 

								}

							}
						}
					}
				}
				//else if(tc_strcmp(DmlRelTypeDup,"TODR")==0)
				else if((tc_strcmp(DmlRelTypeDup,"TODR")==0) && (tc_strstr(DmlRelStatDup,"Released")==NULL))
		        {
					printf("\nDmlIdDup1 [%s] DmlRelTypeDup12 [%s] DmlRelStatDup1 [%s]  \n",DmlIdDup,DmlRelTypeDup,DmlRelStatDup);fflush(stdout);
					int tskcnt =0,t=0,p=0;
					tag_t *SetOfDmlTasksTag= NULLTAG;
					char *TaskId=NULL;
					int partCnt=0;
					tag_t *SetOfPartTags= NULLTAG;

					ITK_CALL(AOM_ask_value_tags(ERCDMLTag1,"T5_DMLTaskRelation",&tskcnt,&SetOfDmlTasksTag));
					printf("\nDML Task Count : %d\n",tskcnt);fflush(stdout);
					printf("\n Inside Second Condition of Gate Maturation \n");fflush(stdout);
					if (tskcnt>0)
					{
						for(t=0;t<tskcnt;t++)
						{
							ITK_CALL(AOM_ask_value_string(SetOfDmlTasksTag[t],"item_id",&TaskId));
							printf("\nDML Task [%s]",TaskId);fflush(stdout);

							if (tc_strstr(TaskId,"APL")!=NULL)
							{
								printf("\nSkipping APL DML Task [%s]",TaskId);fflush(stdout);
								continue;
							}

							AOM_ask_value_tags(SetOfDmlTasksTag[t],"CMReferences",&partCnt,&SetOfPartTags);
							printf("\nNo of Design Rev=%d\n",partCnt);
							if (partCnt>0)
							{
								char *PartNum=NULL;
								char *PartNumDup=NULL;
								char *PartRev=NULL;
								char *PartRevDup=NULL;
								char *PartRelStat=NULL;
								tag_t PartTag= NULLTAG;
								char *part_type=NULL;
								char *part_typeDup=NULL;
								char *desc=NULL;
								char *descDup=NULL;
								char *ModuleAddress=NULL;
								char *ModuleAddressDup=NULL;
								char *partsts=NULL;
								char *partstsDup=NULL;
								char *prjcode=NULL;
								char *prjcodeDup=NULL;
								char* PartColInd = NULL;
								char* PartColIndDup = NULL;
								char *ColorIDPart = NULL;
								char *ColorIDPartDup = NULL;
								char *UrnCode = NULL;
								char *prepartsts = NULL;
								char* PrerevDRstat	 = NULL;

								char* ProjVehclass = NULL;
								char* ProjVehclassDup = NULL;
								char* Projplnname = NULL;
								char* ProjplnnameDup = NULL;
								char* Projbuss = NULL;
								char* ProjbussDup = NULL;
								char* Projdesc = NULL;
								char* ProjdescDup = NULL;

								PrerevDRstat	=	(char	*)MEM_alloc(10);
								char* FirstrlzDR4	 = NULL;
								FirstrlzDR4	=	(char	*)MEM_alloc(10);

								char* Owner	= NULL;
								Owner = (char *)MEM_alloc(50);

								//displaying_objects();
								for(p=0;p<partCnt;p++)
								{
									PartTag=SetOfPartTags[p];

									printf("\n Part Class [%s]",type_name); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&PartNum));
									tc_strdup(PartNum,&PartNumDup);

									ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_CategoryName",&desc));
									tc_strdup(desc,&descDup);
									STRNG_replace_str(descDup,","," ",&descDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&PartRev));
									tc_strdup(PartRev,&PartRevDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ModuleAddress",&ModuleAddress));
									tc_strdup(ModuleAddress,&ModuleAddressDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartStatus",&partsts));
									tc_strdup(partsts,&partstsDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ColourInd",&PartColInd));
									tc_strdup(PartColInd,&PartColIndDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_ProjectCode",&prjcode));
									tc_strdup(prjcode,&prjcodeDup);

									ITK_CALL(AOM_ask_value_string(PartTag,"t5_PartType",&part_type));
									tc_strdup(part_type,&part_typeDup);
									printf("\nPart type is*** [%s]",part_typeDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(PartTag,"release_status_list",&PartRelStat));

									if(tc_strstr(PartRelStat,"ERC Review")==NULL)
									{
										printf("\nPart [%s] is not ERC Released LifeCycleState [%s] Skipping...",PartNum,PartRelStat); fflush(stdout);
										continue;
									}
									else
									{
										printf("\nPart [%s] Release Status [%s]",PartNum,PartRelStat); fflush(stdout);
										tc_strcpy(Owner,"WIP Vault");
									}

									//if((tc_strcmp(part_typeDup,"V")==0) || (tc_strcmp(part_typeDup,"VC")==0) || (tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0))
									if((tc_strcmp(part_typeDup,"M")==0) && (tc_strcmp(DmlRelTypeDup,"MR")==0) && (tc_strcmp(type,"M")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{
										//tc_strcat(fsuccess_name,"/user/cvprod/MIS_Client_Code_CV/Reports/");
										sprintf(fsuccess_name,"%s_%s_%s_%s.csv",PartNum,fromdate,todate,type);
	                                    fsuccess = fopen(fsuccess_name,"w");

	                                  fprintf(fsuccess,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update\n");

										int revi = 0, revCnt = 0, preOffDR4 = 0, preOffDRstat = 0, ChkpreRev= 0;
										tag_t *allRevTag	 = NULLTAG;
										char* CurRev		 = NULL;
										char* CurSeq		 = NULL;
										tag_t relTypeTag = NULLTAG;
										tag_t* DVA_document_tags = NULLTAG;
										logical dfq_applicability;;
										int DVA_result_count = 0;
										int d = 0;
										int k = 0;

										logical DFQApplicablilitycheck	= 0;
										logical DFQApplicablility	= 0;
										char* DFQApplicablilityDup	= NULL;
										//DFQApplicablilityDup = (char *)MEM_alloc(100);

										double Designnominal;
										double Definedtarget;
										double Achievednominal;
										double Achievedtarget;
										double CpkDup;

										char* DFQdocno				= NULL;
										char* DFQdocnoDup			= NULL;
										char* DFQUID				= NULL;
										char* DFQUIDDup				= NULL;
										char* DVADesc				= NULL;
										char* DVADescDup			= NULL;
										char* DFQComment			= NULL;
										char* DFQCommentDup			= NULL;
										char* Meetexpectations		= NULL;
										char* MeetexpectationsDup	= NULL;
										char* Foundpdf				= NULL;
										char* Foundexcel			= NULL;
										date_t Lastmoddate;
										char* LastmoddateDup		= NULL;
                                        char*MeetexpectationDupMMM=NULL;

										int resultCount1 = 0;
										tag_t* dfq_use_case_tags = NULLTAG;

										int nFoundpdf= 0;
										int nFoundexcel= 0;
										int trueflag= 0;
										int falseflag= 0;
										tag_t* refobjpdf  = NULLTAG;
										tag_t* refobjexcel  = NULLTAG;
										char* DVADescDup20	 = NULL;
										char* DVADescDup21	= NULL;
										char* DVADescsDup	= NULL;
										DVADescDup = (char*)MEM_alloc(100);
										DVADescDup20 = (char*)MEM_alloc(100);
										DVADescDup21 = (char*)MEM_alloc(100);
										DVADescsDup = (char *)MEM_alloc(100);

										CurRev = strtok(PartRevDup,";");
										CurSeq = strtok(NULL,";");

										printf("\n Current Revision is %s",CurRev);fflush(stdout);
										printf("\n Current Sequence is %s",CurSeq);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(GetDVAUseCaseFromLibrary(PartTag, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount1);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTag);

										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(PartTag, relTypeTag, &DVA_result_count,&DVA_document_tags));
										printf("\n No of Attached DFQ Documetns are :: %d\n",DVA_result_count);fflush(stdout);


										if (DVA_result_count >0)
										{
											for (k=0;k<DVA_result_count; k++ )
											{
												AOM_ask_value_logical(DVA_document_tags[k],"t5_DFQApplicablility",&DFQApplicablilitycheck);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck);

												if(DFQApplicablilitycheck == 1)
												{
													trueflag++;
												}
												else
												{
													falseflag++;
												}
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumDup,CurRev,CurSeq,partstsDup,ModuleAddressDup,PrerevDRstat,ProjbussDup,descDup,Owner);fflush(stdout);
										fprintf(fsuccess,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",PartNumDup,CurRev,CurSeq,partstsDup,ModuleAddressDup,ProjbussDup,descDup,Owner,resultCount1,falseflag,trueflag);

										if (DVA_result_count >0)
										{
											for (d=0;d<DVA_result_count; d++ )
											{
												AOM_ask_value_string(DVA_document_tags[d],"current_name",&DFQdocno);
												tc_strdup(DFQdocno,&DFQdocnoDup);

												AOM_ask_value_string(DVA_document_tags[d],"t5_DFQUID",&DFQUID);
												tc_strdup(DFQUID,&DFQUIDDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tags[d],"object_desc",&DVADesc));
//												tc_strdup(DVADesc,&DVADescDup20);
//
//												STRNG_replace_str(DVADescDup20,","," ",&DVADescDup21);
//												STRNG_replace_str(DVADescDup21,"@"," ",&DVADescDup);
                                                int an=0;
												int ax=0; 
												printf(" Value of desc found = %s \n",DVADesc);
												printf(" Value of DFQdocnos found = %s \n",DFQdocno);

												for(ax=0;DVADesc[ax]!='\0';ax++)
												{
													printf("\n char found8 = %c , ascii found = %d \n",DVADesc[ax],DVADesc[ax]);

													//if(DVADesc[ax]==13)
													if((DVADesc[ax]==13) || (DVADesc[ax]==10))
													{
														DVADescsDup[an]='\0';
													}
													else
													{
														 DVADescsDup[an]=DVADesc[ax];
														 an++;
													}

												} 

												printf(" Length of DVADesc = %d ",tc_strlen(DVADesc));
												printf(" Length of DVADescsDup = %d ",tc_strlen(DVADescsDup));

												printf(" DVADesc = %s\n",DVADesc);
												printf(" DVADescsDup = %s\n",DVADescsDup);

												AOM_ask_value_logical(DVA_document_tags[d],"t5_DFQApplicablility",&DFQApplicablility);

												printf("\n DFQApplicablility [%d] ",DFQApplicablility);

												if(DFQApplicablility == 1)
												{
													tc_strdup("Yes",&DFQApplicablilityDup);
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilityDup);fflush(stdout);
												}
												else
												{
													tc_strdup("No",&DFQApplicablilityDup);
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilityDup);fflush(stdout);
												}

												ITK_CALL(AOM_ask_value_string(DVA_document_tags[d],"t5_DFQComment",&DFQComment));
												tc_strdup(DFQComment,&DFQCommentDup);

												STRNG_replace_str(DFQCommentDup,","," ",&DFQCommentDup);
												STRNG_replace_str(DFQCommentDup,"\n"," ",&DFQCommentDup);

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tags[d],"T5_DFQ_PDF",&nFoundpdf,&refobjpdf));
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tags[d],"T5_DFQ_EXCEL",&nFoundexcel,&refobjexcel));

												printf("*n Foundpdf --- %d* \n",nFoundpdf);fflush(stdout);
												printf("*n Foundexcel --- %d* \n",nFoundexcel);fflush(stdout);

												if (nFoundpdf == 0)
												{
													tc_strdup("No",&Foundpdf);
												}else{
													tc_strdup("Yes",&Foundpdf);
												}

												if (nFoundexcel == 0)
												{
													tc_strdup("No",&Foundexcel);
												}else{
													tc_strdup("Yes",&Foundexcel);
												}

												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQDesNom",&Designnominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DNDefTarget",&Definedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQAchNom",&Achievednominal));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_ANDefTarget",&Achievedtarget));
												ITK_CALL(AOM_ask_value_double(DVA_document_tags[d],"t5_DFQCpkVal",&CpkDup));

												ITK_CALL(AOM_ask_value_string(DVA_document_tags[d],"t5_DFQMeetExp",&Meetexpectations));
												tc_strdup(Meetexpectations,&MeetexpectationsDup);

												if(tc_strcmp(MeetexpectationsDup,"N")==0)
												{

                                                     tc_strdup("No",&MeetexpectationDupMMM);
												}
												if(tc_strcmp(MeetexpectationsDup,"Y")==0)
												{
                                                      tc_strdup("Yes",&MeetexpectationDupMMM);
												}
												if(tc_strcmp(MeetexpectationsDup,"NA")==0)
												{
                                                      tc_strdup("NA",&MeetexpectationDupMMM);
												}

												//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

												ITK_CALL(AOM_ask_value_date(DVA_document_tags[d],"last_mod_date",&Lastmoddate));
												ITK_CALL(DATE_date_to_string(Lastmoddate,"%d/%m/%Y",&LastmoddateDup));

												printf("\n DVALine7092 DFQUIDDup [%s] DVADescsDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",DFQUIDDup,DVADescsDup,DFQApplicablilityDup,DFQCommentDup,DFQdocnoDup,Foundpdf,Foundexcel,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationsDup,LastmoddateDup);fflush(stdout);
												fprintf(fsuccess,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDDup,DVADescsDup,DFQApplicablilityDup,DFQCommentDup,DFQdocnoDup,Foundpdf,Foundexcel,Designnominal,Definedtarget,Achievednominal,Achievedtarget,CpkDup,MeetexpectationDupMMM,LastmoddateDup);
											}
										}
										fclose(fsuccess);
									}
									else if ((tc_strcmp(part_typeDup,"V")==0) && (tc_strcmp(DmlRelTypeDup,"TODR")==0) && (tc_strcmp(type,"V")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{
										printf("\n DVALine 7099 TODR WIP Third condition conditin part_type [%s] DmlRelStatDup [%s] PartNum [%s] \n",part_typeDup,DmlRelTypeDup,PartNum);fflush(stdout);
										char *VPrtModNum=NULL;
	                                    char *VPrtModNumType=NULL;
                                        tag_t	bom_wnd				=	NULLTAG;
                                        tag_t	rule				=	NULLTAG;
                                        tag_t	top_lne				=	NULLTAG;
										//int		n_count			=	0;
                                        int count=0;
										int		ichld			=	0;
										tag_t	*ArchNodeLines		=	NULLTAG;

	                                    tag_t	*ColIndChilds		=	NULLTAG;
	                                    tag_t	Childobject			=	NULLTAG;
										char* Owners	= NULL;
								     Owners = (char *)MEM_alloc(50);
                                         char *PartNums=NULL;
										 char *PartNumsDup=NULL;
										 char *PartNumstypDup=NULL;
										 char*PartNumstyp=NULL;
                                         char *descp=NULL;
										 char *descpDup=NULL;
                                         char *PartRevs=NULL;
										 char *PartRevsDup=NULL;
										 char *ModuleAddressp=NULL;
										 char *ModuleAddresspDup=NULL;
                                         char *partst=NULL;
										 char *partstDup=NULL;
										 char *PartRelStats=NULL;
										 char* CurRevs		 = NULL;
										char* CurSeqs		 = NULL;
										char *CurRe=NULL;
										char*CurSe=NULL;
										char*VPrtdesc=NULL;
										char*PsProgScale=NULL;
										int i=0;
										tag_t relTypeTags = NULLTAG;
										tag_t ItemTypeTag=NULLTAG;
										tag_t* DVA_document_tag = NULLTAG;
										int DVA_result_counts=0;
                                         int resultCount=0;
										 logical DFQApplicablilitycheck1= 0;
										 logical DFQApplicablilitys=0;
										 // int trueflagg=0;
										 // int falseflagg=0;
                                          int d=0;
                                       char* DFQdocnos				= NULL;
										char* DFQdocnosDup			= NULL;
										char* DFQUIDs				= NULL;
										char* DFQUIDsDup				= NULL;
										char* DVADescs				= NULL;
										char* DVADescsDup			= NULL;
										char* DFQComments			= NULL;
										char* DFQCommentsDup			= NULL;
										char* Meetexpectation		= NULL;
										char* MeetexpectationDup	= NULL;
										char* Foundpdfs				= NULL;
										char* Foundexcels			= NULL;
										date_t Lastmoddates;
										char* LastmoddatesDup		= NULL;
                                        char* DFQApplicablilitysDup=NULL;
										char*ItemType=NULL;
										int nFoundpdfs= 0;
										int nFoundexcels= 0;

										tag_t* refobjpdfs  = NULLTAG;
										tag_t* refobjexcels  = NULLTAG;

										double Designnominals;
										double Definedtargets;
										double Achievednominals;
										double Achievedtargets;
										double CpkDups;
                                        tag_t* dfq_use_case_tags = NULLTAG;
										char* ProjdescDup = NULL;
                                        char*Projname=NULL;
                                        char*MeetexpectationDupMM=NULL;
										char			Data[100]					= "";
										tag_t GCI_relation=NULLTAG;
										tag_t*GciObj=NULLTAG;
										int GCI=0;
										int Demerit_rating=0;
										int Demerit=0;
										double GCIind;
										int gc=0;
										tag_t GCItag=NULLTAG;
									
                                  time_t 	now;
	                              struct 	tm when;

								  PIE_scope_t scope;
	                              scope=PIE_TEAMCENTER;
								  int rulefound= 0;
								  tag_t *closurerule = NULLTAG;
								  tag_t close_tag = NULLTAG;
								  tag_t bom_variant_rule = NULLTAG;
								  tag_t objTypeTag=NULLTAG;
								  char type_name[TCTYPE_name_size_c+1];
								  tag_t e_block		= NULLTAG;
								  char **rulename = NULL;
	                              char **rulevalue = NULL;
								 // char *VPrtdescdup = NULL;
								  char *VPrtdescdup = NULL;
								  char *VPrtdescdup1 = NULL;
								  char *VPrtdescdup22 = NULL;
								  char *DVADescsDup22 = NULL;
								  char *DVADescsDup23 = NULL;
								  VPrtdescdup = (char *)MEM_alloc(100);
								  VPrtdescdup1 = (char *)MEM_alloc(100);
								  VPrtdescdup22 = (char *)MEM_alloc(100);
								  DVADescsDup22 = (char *)MEM_alloc(100);
								  DVADescsDup23 = (char *)MEM_alloc(100);
								  DVADescsDup = (char *)MEM_alloc(100);

	                             time(&now);
	                            when = *localtime(&now);
                               strftime(Data,100,"%Y/%b/%d-%H_%M_%S",&when);


										ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&VPrtModNum));
	                                    ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&VPrtModNumType));
                                     printf("\nV number is [%s]",VPrtModNum); fflush(stdout);
									 CurRe = strtok(VPrtModNumType,";");
										CurSe = strtok(NULL,";");

										ITK_CALL(AOM_ask_value_string(PartTag,"object_desc",&VPrtdesc));
										printf("\n desc before dup3 [%s]",VPrtdesc); fflush(stdout);
										tc_strdup(VPrtdesc,&VPrtdescdup);


										 STRNG_replace_str(VPrtdescdup,"."," ",&VPrtdescdup1);
										 STRNG_replace_str(VPrtdescdup1,","," ",&VPrtdescdup22);

										 printf("\n desc before VPrtdescdup1 [%s]",VPrtdescdup1); fflush(stdout);
										 printf("\n desc before VPrtdescdup22 [%s]",VPrtdescdup22); fflush(stdout);
										  
										   
										    

										ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_ProgramScale",&PsProgScale));
										printf("\nV program scale is [%s]",PsProgScale); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(getBusinessUnitFun(PartTag, &ProjdescDup,&Projname));
										printf("\n Project Descp :[%s]\n",ProjdescDup);   fflush(stdout);

										//ITK_CALL(getBusinessUnit(PartTag, &Projname));
										printf("\n Project Name :[%s]\n",Projname);   fflush(stdout);

										ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

										ITK_CALL(GRM_list_secondary_objects_only(PartTag,GCI_relation,&GCI,&GciObj));

										if(GCI>0)
										{
											for(gc=0;gc<GCI;gc++)
													{
														printf("\n inside for loop gc count****.\n");fflush(stdout);

														GCItag=GciObj[gc];

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&Demerit));
														printf("\n Demerit :[%d]\n",Demerit);fflush(stdout);
                                                       
														
														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_rating_S1",&Demerit_rating));
														printf("\n Demerit_rating :[%d]\n",Demerit_rating);fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCItag,"t5_geometry_conf_index_a1",&GCIind));
														printf("\n GCIind:[%lf]\n",GCIind);fflush(stdout);
                                                    }
										}
										  


                         //tc_strcat(fsuccess_nam,"/user/cvprod/MIS_Client_Code_CV/Reports/");
                        //sprintf(fsuccess_nam,"/user/cvprod/MIS_Client_Code_CV/Reports/MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname);
                        sprintf(fsuccess_nam,"MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VPrtModNum,CurRe,CurSe,ProjbussDup,Projname);
	                    file = fopen(fsuccess_nam,"w");

                     fprintf(file,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
					 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
					 fprintf(file,",,,Description,%s,,Program Scale,%s,,,\n",VPrtdescdup22,PsProgScale);
					 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
                     fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
                     fprintf(file,",,,Last Updated,,,,,,,\n");
                     fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
					 fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
                     if(Demerit)
					 {
                        fprintf(file,",,,Demerit Score(V),%d,,,,,,\n",Demerit);                                  
					 }
					 else{
						 fprintf(file,",,,Demerit Score(V),%s,,,,,,\n","Nil");
					 }
					 if(Demerit_rating)
					{
                      fprintf(file,",,,Demerit Score Rating(S),%d,,,,,,\n",Demerit_rating);
					}
					 else
					{	
					 fprintf(file,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
					}
					if(GCIind)
					{
                      fprintf(file,",,,Geometry conformance Index(A),%lf,,,,,,\n",GCIind);
					}
					else{

					 fprintf(file,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
					}
                     fprintf(file,"\n\n");

fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update\n");





										if(PartTag!=NULLTAG)
	                                  {
										    ITKCALL(BOM_create_window(&bom_wnd ));      //set new bom window
											ITK_CALL ( BOM_set_window_top_line( bom_wnd, NULLTAG, PartTag, NULLTAG, &top_lne ));
											ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE)); 
		                                    ITKCALL(CFM_find("ERC release and above", &rule));  //find the revision rule
											ITKCALL(BOM_set_window_config_rule(bom_wnd, rule));  // set revision rule for window

											//ITK_CALL( PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
											ITK_CALL( PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));

					                        printf ("vc_rule count %d \n",rulefound);fflush(stdout);
					                        
					                        if (rulefound > 0)
					                        {
					                        	close_tag = closurerule[0];
					                        	printf (" vc closure rule found \n");fflush(stdout);
					                        	// MEM_free(tags_found);
					                        }

											ITK_CALL(BOM_window_set_closure_rule( bom_wnd,close_tag, 0, rulename,rulevalue ));

					                       
					                       
                                            if(top_lne!=NULLTAG)
										  {  
                                             printf (" vc top found \n");fflush(stdout);
										  }
					                        printf( " vc_After BOM_set_window_top_line..\n");fflush(stdout);

//											ITK_CALL (  BOM_window_ask_variant_rules( bom_wnd,&bomcoutn,&bom_variant_rule ));
//					                        printf( " vc_release  BOM_window_ask_variant_rules..\n");fflush(stdout);
//											if(bom_variant_rule!=NULLTAG)
//										  {  
//                                             printf (" bom_variant_rule found \n");fflush(stdout);
//										  }
//
//											ITK_CALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
//					                        ITK_CALL( TCTYPE_ask_name2(objTypeTag,&type_name));
//											if(objTypeTag!=NULLTAG)
//										  {  
//                                             printf (" objTypeTag found \n");fflush(stdout);
//										  }

											ITK_CALL ( ITEM_ask_rev_variants ( PartTag, &e_block ));
					                        printf(" vc_ITEM_ask_rev_variants..\n");fflush(stdout);
											if(e_block!=NULLTAG)
										  {  
                                             printf (" e_block found \n");fflush(stdout);
										  }
					                        
											
                                           // ITKCALL(BOM_set_window_top_line( bom_wnd, NULLTAG, PartTag, NULLTAG, &top_lne ));



											if(top_lne!=NULLTAG)
		                                   {
			                                // ITKCALL(BOM_line_ask_child_lines(top_lne, &n_count, &ArchNodeLines));
			                               //  printf("\n n_count --------> : %d\n", n_count);

										   ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
//										   if(ColIndChilds!=NULLTAG)
//										  {  
//                                             printf (" ColIndChilds found \n");fflush(stdout);
//										  }

										   ITK_CALL(BOM_window_hide_unconfigured(bom_wnd))   ;
						                   ITK_CALL(BOM_window_show_variants(bom_wnd))   ;

										   printf("\n vc_release After inside bom_window-----\n"); fflush(stdout);
						                   ITK_CALL(BOM_window_apply_variant_configuration(bom_wnd,1,&PartTag))   ;
						                   printf("\n vc_release After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
										    if(PartTag!=NULLTAG)
										  {  
                                             printf (" PartTag found \n");fflush(stdout);
										  }


                                           ITK_CALL(BOM_window_hide_variants(bom_wnd))   ;

						                  ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
//										   if(ColIndChilds!=NULLTAG)
//										  {  
//                                             printf (" ColIndChilds1 found \n");fflush(stdout);
//										  }

						                  printf("\n vcBom_count --------> : [%d]  ",count); fflush(stdout);
			                                 //ITKCALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
			                                // printf("\n count --------> : %d\n", count); fflush(stdout);//Find Architecture Node

			                                 if (count >0)
			                                 {
				                              for (ichld=0;ichld<count ;ichld++ )
				                               {
					                            //if(Childobject) Childobject=NULLTAG;
					                                 Childobject=ColIndChilds[ichld];


									ITK_CALL(AOM_ask_value_string(Childobject,"bl_item_item_id",&PartNums));
									tc_strdup(PartNums,&PartNumsDup);
									printf("\nPart number is 6 [%s]",PartNumsDup); fflush(stdout);

                                    ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartType",&PartNumstyp));
									tc_strdup(PartNumstyp,&PartNumstypDup);
									printf("\nPart type is [%s]",PartNumstypDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_Design Revision_t5_CategoryName",&descp));
									tc_strdup(descp,&descpDup);
									STRNG_replace_str(descpDup,","," ",&descpDup);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_rev_item_revision_id",&PartRevs));
									tc_strdup(PartRevs,&PartRevsDup);
									printf("\nPart number revision [%s]",PartRevsDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddressp));
									tc_strdup(ModuleAddressp,&ModuleAddresspDup);

									ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartStatus",&partst));
									tc_strdup(partst,&partstDup);


									ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_rev_release_status_list",&PartRelStats));
                                     printf("\nPart release is [%s]",PartRelStats); fflush(stdout);
									if(tc_strstr(PartRelStats,"ERC Review")!=NULL)
									{
										printf("\nPart [%s] Release Status [%s]",PartNums,PartRelStats); fflush(stdout);
										tc_strcpy(Owners,"WIP Vault");
									}

									    CurRevs = strtok(PartRevsDup,";");
										CurSeqs = strtok(NULL,";");

										printf("\n Current Revision is %s",CurRevs);fflush(stdout);
										printf("\n Current Sequence is %s",CurSeqs);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);
										if(tc_strcmp(PartNumstypDup,"M")==0)
							          {

                                        ITK_CALL(getBusinessUnitFunct(Childobject, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(GetDVAUseCaseFromLibraryt(Childobject, ProjbussDup, &resultCount, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										tag_t itemTag = NULLTAG;
										tag_t itemRevTag = NULLTAG;

										tag_t	itemRevTagm2	=	NULLTAG;
										ITEM_find_item(PartNums, &itemTag);


										ITEM_find_revision(itemTag,PartRevs,&itemRevTagm2);




										//ITEM_ask_latest_rev(itemTag,&itemRevTag);
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);

										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm2, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										printf("\n No of Attached DFQ Documetns are** :: %d\n",DVA_result_counts);fflush(stdout);

										int trueflagg=0;
										int falseflagg=0;

                                        if (DVA_result_counts >0)
										{
											for (i=0;i<DVA_result_counts; i++ )
											{
												AOM_ask_value_logical(DVA_document_tag[i],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												if(DFQApplicablilitycheck1 == 1)
												{
													trueflagg++;
												}
												else
												{
													falseflagg++;
												}
											}
										}

										printf("\n DVALine 7508 PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,PrerevDRstat,ProjbussDup,descpDup,Owners);fflush(stdout);
										fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,ProjbussDup,descpDup,Owners,resultCount,falseflagg,trueflagg);

										if (DVA_result_counts >0)
																	{
																		for (d=0;d<DVA_result_counts; d++ )
																		{
																			AOM_ask_value_string(DVA_document_tag[d],"current_name",&DFQdocnos);
																			tc_strdup(DFQdocnos,&DFQdocnosDup);

																			AOM_ask_value_string(DVA_document_tag[d],"t5_DFQUID",&DFQUIDs);
																			tc_strdup(DFQUIDs,&DFQUIDsDup);

																			tc_strcpy(DVADescsDup,"");
																			ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[d],"object_desc",&DVADescs));
																			//des=tc_strlen(DVADescs);

																			int an=0;
																			DVADescsDup = (char*)MEM_alloc(1000);
                                                                            
// Testing 

                                                                            int ax=0; 
                                                                            printf(" Value of desc found = %s \n",DVADescs);
                                                                            printf(" Value of DFQdocnos found = %s \n",DFQdocnos);

																			for(ax=0;DVADescs[ax]!='\0';ax++)
																			{
                                                                                printf("\n char found = %c , ascii found = %d \n",DVADescs[ax],DVADescs[ax]);

																				//if(DVADescs[ax]==13)
																				if((DVADescs[ax]==13) || (DVADescs[ax]==10))
																				{
                                                                                    DVADescsDup[an]='\0';
																				}
																				else
																				{
                                                                                     DVADescsDup[an]=DVADescs[ax];
																					 an++;
																				}

																			} 

																			printf(" Length of DVADescs = %d ",tc_strlen(DVADescs));
																			printf(" Length of DVADescsDup = %d ",tc_strlen(DVADescsDup));

																			printf(" DVADescs = %s\n",DVADescs);
																			printf(" DVADescsDup = %s\n",DVADescsDup);







// Testing









//																			des=tc_strlen(DVADescs);
//																			DVADescsDup = (char *)MEM_alloc(des);
//																			//qry_values1[2] = (char *)MEM_alloc( strlen( todate ) + 1);
//																			//STRNG_replace_str(DVADescsDup3,","," ",&DVADescsDup4);
//																			//STRNG_replace_str(DVADescs,"\n",";",&DVADescsDup);
//
//																			tc_strcpy(DVADescsDup,"");
//																			tc_strcat(DVADescsDup,DVADescs);
//																			tc_strcat(DVADescsDup,"");
//																			
//																			x=0;
//																			for(z=0;z<des;z++)
//																			{
//																			
//																			if(DVADescsDup[z]!='\n')
//																			{
//																				printf("\n Inside assif loop\n");
//																			
//																			DVADescsDup[x++]=DVADescsDup[z];
//																			
//																			
//																			}
//																			
//																			
//																			}
//																			DVADescsDup[x]='\0';
//
//
//																			printf("After remove New Line \n %s",DVADescsDup);
//   



																			

//
//
//																			
//																			
//																			printf("\n des len 4 [%d] ",des);
//																			printf("\n DVADescs value is [%s] ",DVADescs);fflush(stdout);
//																			printf("\n DVADescs current_name is [%s] ",DFQdocnos);fflush(stdout);
//																			tc_strcpy(DVADescsDup3,"");
//																			tc_strcpy(DVADescsDup3,DVADescs);
//													    					//tc_strdup(DVADescs,&DVADescsDup3);


//

//																			printf("\n DVADescsDup3 value is 2[%s] ",DVADescsDup3);fflush(stdout);
//
//																			
																			//STRNG_replace_str(DVADescsDupJ5,")"," ",&DVADescsDup);
																			printf("\n DVADescsDup value is 2[%s] ",DVADescsDup);fflush(stdout);

																			STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup23);

																			AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitys);

																			printf("\n DFQApplicablility [%d] ",DFQApplicablilitys);

																			if(DFQApplicablilitys == 1)
																			{
																				tc_strcpy(DFQApplicablilitysDup,"");
																				tc_strdup("Yes",&DFQApplicablilitysDup);
																				printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
																			}
																			else
																			{
																				tc_strcpy(DFQApplicablilitysDup,"");
																				tc_strdup("No",&DFQApplicablilitysDup);
																				printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
																			}
//																			STRNG_replace_str(DFQApplicablilitysDup,"\n",",",&DFQApplicablilitysDup1);
//																			printf("\n DFQApplicablilityDup [%s]  DVA name DFQdocnos[%s]",DFQApplicablilitysDup1,DFQdocnos);fflush(stdout);


																			ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQComment",&DFQComments));
																			tc_strdup(DFQComments,&DFQCommentsDup);

																			STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
																			STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

																			ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
																			ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

																			printf("*n Foundpdf --- %d* \n",nFoundpdfs);fflush(stdout);
																			printf("*n Foundexcel --- %d* \n",nFoundexcels);fflush(stdout);

																			if (nFoundpdfs == 0)
																			{
																				tc_strdup("No",&Foundpdfs);
																			}else{
																				tc_strdup("Yes",&Foundpdfs);
																			}

																			if (nFoundexcels == 0)
																			{
																				tc_strdup("No",&Foundexcels);
																			}else{
																				tc_strdup("Yes",&Foundexcels);
																			}

																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQDesNom",&Designnominals));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DNDefTarget",&Definedtargets));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQAchNom",&Achievednominals));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_ANDefTarget",&Achievedtargets));
																			ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQCpkVal",&CpkDups));

																			ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQMeetExp",&Meetexpectation));
																			tc_strdup(Meetexpectation,&MeetexpectationDup);

																			if(tc_strcmp(MeetexpectationDup,"N")==0)
																			{

														                         tc_strdup("No",&MeetexpectationDupMM);
																			}
																			if(tc_strcmp(MeetexpectationDup,"Y")==0)
																			{
														                          tc_strdup("Yes",&MeetexpectationDupMM);
																			}
																			if(tc_strcmp(MeetexpectationDup,"NA")==0)
																			{
														                          tc_strdup("NA",&MeetexpectationDupMM);
																			}

																			//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

																			ITK_CALL(AOM_ask_value_date(DVA_document_tag[d],"last_mod_date",&Lastmoddates));
																			ITK_CALL(DATE_date_to_string(Lastmoddates,"%d/%m/%Y",&LastmoddatesDup));

																			printf("\n DVALine 7703 DFQUIDDup* [%s] DVADescsDup23* [%s] DFQApplicablilityDup*  [%s] DFQCommentDup* [%s] DFQdocnoDup* [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",ProjbussDup,DVADescsDup23,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDup,LastmoddatesDup);fflush(stdout);
																			fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup23,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDupMM,LastmoddatesDup);
											}
										 }

											   }
											   }
											 }
											
										   }
									  }
									  fclose(file);
								   }
								   else if (((tc_strcmp(part_typeDup,"CCVC")==0) || (tc_strcmp(part_typeDup,"CVC")==0)) && (tc_strcmp(DmlRelTypeDup,"TODR")==0) && (tc_strcmp(type,"VC")==0) && (tc_strcmp(PartColIndDup,"C")!=0))
									{
									   printf("\n TODR WIP Fourth condition conditin part_type [%s] DmlRelStatDup [%s] PartNum [%s] \n",part_typeDup,DmlRelTypeDup,PartNum);fflush(stdout);

                                        char *VCPrtModNum=NULL;
	                                    char *VCPrtModNumType=NULL;
										char *CurReC=NULL;
										char*CurSeC=NULL;
										char*PartNums1=NULL;
										char*PartNums1Dup=NULL;
										char*ModuleName=NULL;
										char*ModuleNameDup=NULL;
										char*ModuleNumstyp=NULL;
										char*ModuleNumstypDup=NULL;
										char*Moduledescp=NULL;
										char*ModuledescpDup=NULL;
										char*ModulePartRevs=NULL;
										char*ModulePartRevsDup=NULL;
										char*ModuleAddre=NULL;
										char*ModuleAddreDup=NULL;
										char*Modulepartst=NULL;
										char*ModulepartstDup=NULL;
										char*ModulePartRelStats=NULL;
										char*ModuleOwners=NULL;
										char*MCurRevs=NULL;
										char*MCurSeqs=NULL;


										tag_t ChildMobject= NULLTAG;
                                        tag_t Snapshot_tag = NULLTAG;
		                                tag_t snapshotObjTypeTag = NULLTAG;
										tag_t *snapshotObjSet = NULLTAG;
										// char snapshotObjtype_name[TCTYPE_name_size_c+1];
		                                 char *ObjName = NULL;
		                                 char *snapshotObjtype_name = NULL;
										 int snapshotCount=0;
										 tag_t item_rev_tags	= NULLTAG;
		                                 char* SSTopLineRev	= NULL;
										 tag_t window		= NULLTAG;
										 int		rulefound		=	0;
	                                     tag_t	*closurerule	=	NULLTAG;
										 PIE_scope_t scope;
	                                     scope=PIE_TEAMCENTER;
										 tag_t	close_tag		=	NULLTAG;
	                                     char	**rulename		=	NULL;
	                                     char	**rulevalue		=	NULL;
										 char *Item_ID_str	= NULL;
										 tag_t top_line		= NULLTAG;
										  int Item_ID=0;
										  tag_t	*ColIndChilds		=	NULLTAG;
									      tag_t	*Modulechilds=NULLTAG;
                                    int count=0;
									int ichld=0;
									int count1=0;
									int chld=0;

									
	                                    tag_t	Childobject1			=	NULLTAG;

										tag_t* DVA_document_tag = NULLTAG;
										int DVA_result_counts=0;
                                         
										 logical DFQApplicablilitys1= 0;
										 logical DFQApplicablilitys=0;
										 
                                          int d=0;
										  int j=0;
                                       char* DFQdocnos				= NULL;
										char* DFQdocnosDup			= NULL;
										char* DFQUIDs				= NULL;
										char* DFQUIDsDup				= NULL;
										char* DVADescs				= NULL;
										char* DVADescsDup			= NULL;
										char* DFQComments			= NULL;
										char* DFQCommentsDup			= NULL;
										char* Meetexpectation		= NULL;
										char* MeetexpectationDup	= NULL;
										char*MeetexpectationDupM=NULL;
										char* Foundpdfs				= NULL;
										char* Foundexcels			= NULL;
										date_t Lastmoddates;
										char* LastmoddatesDup		= NULL;
                                        char* DFQApplicablilitysDup=NULL;
										char*ItemType=NULL;
										int nFoundpdfs= 0;
										int nFoundexcels= 0;

										tag_t* refobjpdfs  = NULLTAG;
										tag_t* refobjexcels  = NULLTAG;

										double Designnominals;
										double Definedtargets;
										double Achievednominals;
										double Achievedtargets;
										double CpkDups;
                                        tag_t* dfq_use_case_tags = NULLTAG;
										tag_t relTypeTags = NULLTAG;
										char* ProjdescDup = NULL;
                                        char*Projname=NULL;
										Projname = (char *)MEM_alloc(50);
										char*VPrtdescM=NULL;
										char*PsProgScaleCC=NULL;
										tag_t GCI_relation=NULLTAG;
										tag_t*GciObj=NULLTAG;
										int GCI=0;
										int Demerit_rating=0;
										int Demerit=0;
										double GCIind;
										int gc=0;
										int bomvalue=1;
										tag_t GCItag=NULLTAG;

										char			Data[100]					= "";
                                  time_t 	now;
	                              struct 	tm when;
								  char *VPrtdescMdup = NULL;
								  char *VPrtdescMdup1 = NULL;
								  char *VPrtdescMdup2 = NULL;
								  char *DVADescsDup24 = NULL;
								  char *DVADescsDup25 = NULL;
								        VPrtdescMdup = (char *)MEM_alloc(100);
								        VPrtdescMdup1 = (char *)MEM_alloc(100);
								        VPrtdescMdup2 = (char *)MEM_alloc(100);
								        DVADescsDup25 = (char *)MEM_alloc(100);
								        DVADescsDup24 = (char *)MEM_alloc(100);
								        DVADescsDup = (char *)MEM_alloc(100);

	                             time(&now);
	                            when = *localtime(&now);
                               strftime(Data,100,"%Y/%b/%d-%H_%M_%S",&when);
										

									   ITK_CALL(AOM_ask_value_string(PartTag,"item_id",&VCPrtModNum));
	                                    ITK_CALL(AOM_ask_value_string(PartTag,"item_revision_id",&VCPrtModNumType));
                                     printf("\nVC number is [%s]",VCPrtModNum); fflush(stdout);
									 CurReC = strtok(VCPrtModNumType,";");
										CurSeC = strtok(NULL,";");
										 printf("\nVC number rev and seq is [%s],[%s]",CurReC,CurSeC); fflush(stdout);

										 ITK_CALL(AOM_ask_value_string(PartTag,"object_desc",&VPrtdescM));
										 printf("\n desc befor dup4 [%s]",VPrtdescM); fflush(stdout);

										 tc_strdup(VPrtdescM,&VPrtdescMdup);
										  STRNG_replace_str(VPrtdescMdup,"."," ",&VPrtdescMdup1);
										  STRNG_replace_str(VPrtdescMdup1,","," ",&VPrtdescMdup2);
										   
										    printf("\ndes after VPrtdescMdup1 [%s]",VPrtdescMdup1); fflush(stdout);
										    printf("\ndes after VPrtdescMdup2 [%s]",VPrtdescMdup2); fflush(stdout);

										 ITK_CALL(AOM_UIF_ask_value(PartTag,"t5_ProgramScale",&PsProgScaleCC));
										printf("\nCCVC program scale is [%s]",PsProgScaleCC); fflush(stdout);

										ITK_CALL(getBusinessUnitFunc(PartTag, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(getBusinessUnitFun(PartTag, &ProjdescDup,&Projname));
										printf("\n Project Descp :[%s]\n",ProjdescDup);   fflush(stdout);

										//ITK_CALL(getBusinessUnit(PartTag, &Projname));
										printf("\n Project Name :[%s]\n",Projname);   fflush(stdout);

										ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

										ITK_CALL(GRM_list_secondary_objects_only(PartTag,GCI_relation,&GCI,&GciObj));

										if(GCI>0)
										{
											for(gc=0;gc<GCI;gc++)
													{
														printf("\n inside for loop gc count****.\n");fflush(stdout);

														GCItag=GciObj[gc];

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&Demerit));
														printf("\n Demerit :[%d]\n",Demerit);fflush(stdout);

														ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_rating_S1",&Demerit_rating));
														printf("\n Demerit_rating :[%d]\n",Demerit_rating);fflush(stdout);

														ITK_CALL(AOM_ask_value_double(GCItag,"t5_geometry_conf_index_a1",&GCIind));
														printf("\n GCIind:[%lf]\n",GCIind);fflush(stdout);
                                                    }
										}

                              printf("\n GCIind******\n");fflush(stdout);
                        //tc_strcat(fsuccess_na,"/user/cvprod/MIS_Client_Code_CV/Reports/");
                       // sprintf(fsuccess_na,"/user/cvprod/MIS_Client_Code_CV/Reports/MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VCPrtModNum,CurReC,CurSeC,ProjbussDup,Projname);
                        sprintf(fsuccess_na,"MIS_DFQ_VC_%s_%s_%s_%s_%s.csv",VCPrtModNum,CurReC,CurSeC,ProjbussDup,Projname);
	                    fptr = fopen(fsuccess_na,"w");



                     fprintf(fptr,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
					 fprintf(fptr,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VCPrtModNum,CurReC,CurSeC);
					 fprintf(fptr,",,,Description,%s,,Program Scale,%s,,,\n",VPrtdescMdup2,PsProgScaleCC);
					 fprintf(fptr,",,,VC Status,%s,,,,,,\n",partstsDup);
                     fprintf(fptr,",,,Owner,%s,,,,,,\n",Owner);
                     fprintf(fptr,",,,Last Updated,,,,,,,\n");
                     fprintf(fptr,",,,Project Name,%s,,,,,,\n",prjcodeDup);
					 fprintf(fptr,",,,Project Description,%s,,,,,,\n",ProjdescDup);
					  printf("\n ****GCIind******\n");fflush(stdout);
					 if(Demerit)
					 {
                        fprintf(fptr,",,,Demerit Score(V),%d,,,,,,\n",Demerit);                                  
					 }
					 else
					 {
						 fprintf(fptr,",,,Demerit Score(V),%s,,,,,,\n","Nil");
					 }
					 if(Demerit_rating)
					{
                      fprintf(fptr,",,,Demerit Score Rating(S),%d,,,,,,\n",Demerit_rating);
					}
					 else
					{	
					 fprintf(fptr,",,,Demerit Score Rating(S),%s,,,,,,\n","Nil");
					}
					if(GCIind)
					{
                      fprintf(fptr,",,,Geometry conformance Index(A),%lf,,,,,,\n",GCIind);
					}
					else{

					 fprintf(fptr,",,,Geometry conformance Index(A),%s,,,,,,\n","Nil");
					}
                     fprintf(fptr,"\n\n");

fprintf(fptr,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update\n");





										 if(AOM_ask_value_tags(PartTag,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet)!= ITK_ok);
		                                 printf("\n WTRoll::snapshotCount ::  %d ", snapshotCount);fflush(stdout);

		                                if(snapshotCount>0)
		                                   {
											 printf("inside the snapshotCount**\n");fflush(stdout);
				                             Snapshot_tag = NULLTAG;
				                             snapshotObjTypeTag = NULLTAG;
				                             Snapshot_tag = snapshotObjSet[0];
                                               //printf(" the snapshotCount**\n");fflush(stdout);
				                             ITK_CALL(TCTYPE_ask_object_type(Snapshot_tag,&snapshotObjTypeTag));
				                             ITK_CALL( TCTYPE_ask_name2(snapshotObjTypeTag,&snapshotObjtype_name));
				                             printf("\n CCVC snapshotObjtype_name := %s\n", snapshotObjtype_name);fflush(stdout);
				                              
				                             ITK_CALL(AOM_ask_value_string(Snapshot_tag,"object_name",&ObjName));
				                             printf(" ObjName***: [%s] \n", ObjName);fflush(stdout);
				                              
				                             //if (AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev) != ITK_ok);
			                                  // if (AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags) != ITK_ok);
                                                //printf(" the snapshotCount topline**\n");fflush(stdout);
				                             ITK_CALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
				                             ITK_CALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));
                                              printf(" Snapshot tag is***: [%s] \n", SSTopLineRev);fflush(stdout);
				                              
                                                // printf(" the snapshotCount topline1**\n");fflush(stdout);
                                             ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));
				                             ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
				                             ITKCALL(BOM_set_window_pack_all (window, FALSE));
                                               //printf("after top line**\n");fflush(stdout);
					
					

				                             ITK_CALL( PIE_find_closure_rules2( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
				                              printf ("\n rule count %d \n",rulefound);fflush(stdout);
				                              if (rulefound > 0)
				                              {
				                             	close_tag = closurerule[0];
				                             	//printf ("closure rule found \n"); fflush(stdout);
				                              }
				                              ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
				                              printf ("closure rule found applied \n"); fflush(stdout);
				                             // ITKCALL(BOM_set_window_pack_all (window, FALSE));
				                              //ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
		                                     ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));
		                                     
		                                     //ITKCALL( TCTYPE_ask_property_by_name (top_line,"bl_item_item_id",&Item_ID));
		                                    // ITKCALL( AOM_ask_displayable_values(top_line, Item_ID,&bomvalue &Item_ID_str));
											// printf(" BOm line string is***: [%s] \n", Item_ID_str);fflush(stdout);
											 ITKCALL(BOM_line_ask_child_lines(top_line, &count, &ColIndChilds));
											 printf(" BOm line count is***: [%d] \n", count);fflush(stdout);

											 if (count >0)
			                                 {
				                              for (ichld=0;ichld<count ;ichld++ )
				                               {
					                           // if(Childobject1) Childobject1=NULLTAG;
					                                 Childobject1=ColIndChilds[ichld];
                                                
												ITK_CALL(AOM_ask_value_string(Childobject1,"bl_item_item_id",&PartNums1));
									            tc_strdup(PartNums1,&PartNums1Dup);
									            printf("\nPart number is in module*** [%s]",PartNums1Dup); fflush(stdout);

												
												ITKCALL(BOM_line_ask_child_lines(Childobject1, &count1, &Modulechilds));
												 printf("\n module line count is***: [%d]", count1);fflush(stdout);

                                                if (count1 >0)
			                                   {
                                               printf("\n module line****************** count is****\n");fflush(stdout);
				                              
												for (chld=0;chld<count1 ;chld++ )
				                               {
					                            if(ChildMobject) ChildMobject=NULLTAG;
					                                 ChildMobject=Modulechilds[chld];
                                    int resultCount1=0;
                                   
									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_item_item_id",&ModuleName));
									tc_strdup(ModuleName,&ModuleNameDup);
									printf("\n module number is [%s]",ModuleNameDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartType",&ModuleNumstyp));
									tc_strdup(ModuleNumstyp,&ModuleNumstypDup);
									printf("\nPart type is [%s]",ModuleNumstypDup); fflush(stdout);

									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_Design Revision_t5_CategoryName",&Moduledescp));
									tc_strdup(Moduledescp,&ModuledescpDup);
									STRNG_replace_str(ModuledescpDup,","," ",&ModuledescpDup);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_rev_item_revision_id",&ModulePartRevs));
									tc_strdup(ModulePartRevs,&ModulePartRevsDup);
									printf("\nPart number revision [%s]",ModulePartRevsDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddre));
									tc_strdup(ModuleAddre,&ModuleAddreDup);
                                    printf("\nPart number address [%s]",ModuleAddreDup); fflush(stdout);


									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartStatus",&Modulepartst));
									tc_strdup(Modulepartst,&ModulepartstDup);
									 printf("\nPart number status [%s]",ModulepartstDup); fflush(stdout);



									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_rev_release_status_list",&ModulePartRelStats));
                                     printf("\nPart release is [%s]",ModulePartRelStats); fflush(stdout);
									if(tc_strstr(ModulePartRelStats,"ERC Review")!=NULL)
									{
										printf("\nPart [%s] Release Status [%s]",ModuleNameDup,ModulePartRelStats); fflush(stdout);
										//tc_strcpy(ModuleOwners,"Release Vault");
										tc_strdup("WIP Vault",&ModuleOwners);
                                          printf("\nPart release is** [%s]",ModuleOwners); fflush(stdout);
									}

									    MCurRevs = strtok(ModulePartRevsDup,";");
										MCurSeqs = strtok(NULL,";");

										printf("\n Current Revision is %s",MCurRevs);fflush(stdout);
										printf("\n Current Sequence is %s",MCurSeqs);fflush(stdout);

										printf("\n type is  [%s] Wise ",type); fflush(stdout);

										if(tc_strcmp(ModuleNumstypDup,"M")==0)
							           {


										ITK_CALL(getBusinessUnitFunct(ChildMobject, &ProjbussDup));
										printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

										ITK_CALL(GetDVAUseCaseFromLibraryt(ChildMobject, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										printf("\n No of Use cases Mapped :[%d]\n",resultCount1);   fflush(stdout);

										//Get DFQ Document Relation Class Type
										tag_t itemTagm = NULLTAG;
										tag_t itemRevTagm = NULLTAG;
										ITEM_find_item(ModuleName, &itemTagm);
										//ITEM_ask_latest_rev(itemTagm,&itemRevTagm);
										printf("\n checking :[%s],[%s]\n",ModuleName,ModulePartRevs);   fflush(stdout);
									    ITEM_find_revision(itemTagm,ModulePartRevs,&itemRevTagm);
										/*if(itemRevTagm==NULLTAG)
												   {
                                                    printf("inside the NULLTAG\n");fflush(stdout);
                                                    exit(0);
												   }
												   else
												   {

                                                      printf("\nTag found");fflush(stdout);
												   }*/
										GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);
                                   
										//Get Attached DFQ Documents
										ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										printf("\n No of Attached DFQ Documetns are**m :: %d\n",DVA_result_counts);fflush(stdout);

										  int trueflaggg=0;
									     int falseflaggg=0;

                                        if (DVA_result_counts >0)
										{
											
											for (j=0;j<DVA_result_counts; j++ )
											{
												AOM_ask_value_logical(DVA_document_tag[j],"t5_DFQApplicablility",&DFQApplicablilitys1);

												printf("\n DFQApplicablility [%d] ",DFQApplicablilitys1);

												if(DFQApplicablilitys1 == 1)
												{
													//tc_strdup("Yes",&DFQApplicablilitysDup);
                                                    trueflaggg++;
													//printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													//tc_strdup("No",&DFQApplicablilitysDup);
													falseflaggg++;
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}

											}
										}

										printf("\n DVALine 8129 PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",ModuleNameDup,MCurRevs,MCurSeqs,ModulepartstDup,ModuleAddreDup,PrerevDRstat,ProjbussDup,ModuledescpDup,ModuleOwners);fflush(stdout);
										fprintf(fptr,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",ModuleNameDup,MCurRevs,MCurSeqs,ModulepartstDup,ModuleAddreDup,ProjbussDup,ModuledescpDup,ModuleOwners,resultCount1,falseflaggg,trueflaggg);

										if (DVA_result_counts >0)
										{
										printf("in there-------------------------------------------------------------------------------------------------------");;fflush(stdout);

											for (d=0;d<DVA_result_counts; d++ )
											{
												AOM_ask_value_string(DVA_document_tag[d],"current_name",&DFQdocnos);
												tc_strdup(DFQdocnos,&DFQdocnosDup);

												AOM_ask_value_string(DVA_document_tag[d],"t5_DFQUID",&DFQUIDs);
												tc_strdup(DFQUIDs,&DFQUIDsDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[d],"object_desc",&DVADescs));
//												tc_strdup(DVADescs,&DVADescsDup24);
//
//												STRNG_replace_str(DVADescsDup24,","," ",&DVADescsDup25);
//												STRNG_replace_str(DVADescsDup25,"@"," ",&DVADescsDup);

                                                 int an=0;
												int ax=0; 
												printf(" Value of desc found = %s \n",DVADescs);
												printf(" Value of DFQdocnos found = %s \n",DFQdocnos);

												for(ax=0;DVADescs[ax]!='\0';ax++)
												{
													printf("\n char found10 = %c , ascii found = %d \n",DVADescs[ax],DVADescs[ax]);

													//if(DVADescs[ax]==13)
													if((DVADescs[ax]==13) || (DVADescs[ax]==10))
													{
														DVADescsDup[an]='\0';
													}
													else
													{
														 DVADescsDup[an]=DVADescs[ax];
														 an++;
													}

												} 

												printf(" Length of DVADescs = %d ",tc_strlen(DVADescs));
												printf(" Length of DVADescsDup = %d ",tc_strlen(DVADescsDup));

												printf(" DVADescs = %s\n",DVADescs);
												printf(" DVADescsDup = %s\n",DVADescsDup);

												AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitys);

												printf("\n DFQApplicablility [%d] ",DFQApplicablilitys);

												if(DFQApplicablilitys == 1)
												{
													tc_strdup("Yes",&DFQApplicablilitysDup);
                                                   
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													tc_strdup("No",&DFQApplicablilitysDup);
													
													printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQComment",&DFQComments));
												tc_strdup(DFQComments,&DFQCommentsDup);

												STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
												STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
												ITK_CALL(AE_ask_all_dataset_named_refs2(DVA_document_tag[d],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

												printf("*n Foundpdf --- %d* \n",nFoundpdfs);fflush(stdout);
												printf("*n Foundexcel --- %d* \n",nFoundexcels);fflush(stdout);

												if (nFoundpdfs == 0)
												{
													tc_strdup("No",&Foundpdfs);
												}else{
													tc_strdup("Yes",&Foundpdfs);
												}

												if (nFoundexcels == 0)
												{
													tc_strdup("No",&Foundexcels);
												}else{
													tc_strdup("Yes",&Foundexcels);
												}

												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQDesNom",&Designnominals));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DNDefTarget",&Definedtargets));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQAchNom",&Achievednominals));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_ANDefTarget",&Achievedtargets));
												ITK_CALL(AOM_ask_value_double(DVA_document_tag[d],"t5_DFQCpkVal",&CpkDups));

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[d],"t5_DFQMeetExp",&Meetexpectation));
												tc_strdup(Meetexpectation,&MeetexpectationDup);
												printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

												if(tc_strcmp(MeetexpectationDup,"N")==0)
												{

                                                     tc_strdup("No",&MeetexpectationDupM);
												}
												if(tc_strcmp(MeetexpectationDup,"Y")==0)
												{
                                                      tc_strdup("Yes",&MeetexpectationDupM);
												}
												if(tc_strcmp(MeetexpectationDup,"NA")==0)
												{
                                                      tc_strdup("NA",&MeetexpectationDupM);
												}


												//Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Design Nominal,DVA Defined Target (+/-),DVA Achieved Nominal,DVA Achieved Target(+/-),DVA Cpk Value,DVA Meet the Expectations (Yes/No),Last Update

												ITK_CALL(AOM_ask_value_date(DVA_document_tag[d],"last_mod_date",&Lastmoddates));
												ITK_CALL(DATE_date_to_string(Lastmoddates,"%d/%m/%Y",&LastmoddatesDup));

												printf("\n DVALine8250 DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] Designnominal [%f] Definedtarget [%f] Achievednominal [%f] Achievedtarget [%f] CpkDup [%f] MeetexpectationsDup [%s] LastmoddateDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDup,LastmoddatesDup);fflush(stdout);
												fprintf(fptr,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%f,%f,%f,%f,%f,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,Designnominals,Definedtargets,Achievednominals,Achievedtargets,CpkDups,MeetexpectationDupM,LastmoddatesDup);
											}
										 }





									            }
                                               }

											 }

                                         }

										}

                                      }
									 
                                            


                                         fclose(fptr);
									}
									else
									{
										printf("\nPart : %s  having Part type : %s is NON Valide",PartNumDup,part_typeDup);fflush(stdout);
									}
																		
									
									 
									 

								}

							}
						}
					}

				
				
				
				}

			}
		}
	}

    printf("\n END of MIS code\n"); fflush(stdout);
	CLEANUP:
	ITK_CALL(POM_logout(false));
	return status;
	printf("\nCLEANUP...\n"); fflush(stdout);
}
