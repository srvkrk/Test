//gsoap ns service name:				 DML_Release_Date
//gsoap ns service style:				 rpc
//gsoap ns service namespace:			 urn:DML_Release_Date
//gsoap ns service location:			 http://172.22.99.106:9080/cgi/DML_Release_Date.cgi
//gsoap ns service encoding:			 encoded
//gsoap ns schema namespace:			 urn:DML_Release_Date
//gsoap ns service method-documentation: Tests the Simple Web service



int ns__getDMLReleaseDate(char *DMLnumber,char *Drgate,char **Response);
