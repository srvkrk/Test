/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: autologin.c
* Description	: This Utility Mainly Used For Part Implosion to VC
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change
* 13/03/2024   	   Lokendra Aporiya		          Part Implosion to VC

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001
#define MAX_LINE_LEN 1024

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
		  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
}

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

FILE  *output = NULL;

int x=0;
int PartSearStat = 0;
int temp2 =0;
int SrNo =0;
int Counter =0;
int RecursiveFun(tag_t itemrev, char* PartentItem, char** PartArray)
{
		
		int	n_tskfund	=	0;
		int task = 0;		
		int k = 0;
		int *levelsaa;
		char	**relations	=  NULL;
		tag_t	*referencers = NULLTAG;
		tag_t objTypeRefTag=NULLTAG;
		
		//char* type_name_ref = NULL;
		char* PartType = NULL;
		char* PartID = NULL;
		char* PartRevSeq = NULL;
		char* Owner = NULL;
		int iFail = 0;
		char* ObjectName = NULL;
		tag_t itemrev1 = NULLTAG;
		char *temp = NULL;
		int *levels	= 0;
		tag_t *parents = NULLTAG;
		char* UnitOfMeasureS = NULL;
		char* DesignGrp = NULL;
		char* ProjectCode = NULL;
		char* Aggregate = NULL;
		char* AggregateGroup = NULL;
		char* Module_Group = NULL;
		char* ModuleAddress = NULL;
		char* Module = NULL;
		char* CategoryName = NULL;
		char* DsgnOwn = NULL;
		char* LcsState = NULL;
		char* DateRelease = NULL;
		char* ObjDescription = NULL;
		char* CS = NULL;
		char* DrawingNo = NULL;
		char* JsrMakeBuyIndicator = NULL;
		char* PunMakeBuyIndicator = NULL;
		char* SndMakeBuyIndicator = NULL;
		char* LkoMakeBuyIndicator = NULL;
		char* DwdMakeBuyIndicator = NULL;
		
		
		if(temp2==0)
		{
			temp++;
			char type_name_ref1[TCTYPE_name_size_c+1];
			ITK_CALL(TCTYPE_ask_object_type(itemrev,&objTypeRefTag));
			ITK_CALL(TCTYPE_ask_name(objTypeRefTag,&type_name_ref1));
			ITK_CALL(AOM_UIF_ask_value(itemrev,"object_name",&ObjectName));
			printf("\n type_name_ref,%s,%s",type_name_ref1,ObjectName);
			
			ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&PartID));
			ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&PartRevSeq));
			ITK_CALL(AOM_UIF_ask_value(itemrev,"owning_user",&Owner));
			ITK_CALL(AOM_ask_value_string(itemrev1,"t5_uom",&UnitOfMeasureS));

			if (strcmp(type_name_ref1,"Design Revision")==0 || strcmp(type_name_ref1,"ItemRevision")==0)
			{
								
				temp = (char *)MEM_alloc(250);
				tc_strcpy(temp, "");
				tc_strcat(temp,PartID);
				tc_strcat(temp,PartRevSeq);
				
				
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_DesignGrp",&DesignGrp));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_ProjectCode",&ProjectCode));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_Aggregate",&Aggregate));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_AggregateGroup",&AggregateGroup));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_Module_Group",&Module_Group));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_ModuleAddress",&ModuleAddress));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_Module",&Module));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_CategoryName",&CategoryName));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_DsgnOwn",&DsgnOwn));
				//ITK_CALL(AOM_ask_value_string(itemrev,"release_status_list",&LcsState));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"date_released",&DateRelease));
				ITK_CALL(AOM_ask_value_string(itemrev,"object_desc",&ObjDescription));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"t5_JsrMakeBuyIndicator",&JsrMakeBuyIndicator));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"t5_PunMakeBuyIndicator",&PunMakeBuyIndicator));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"t5_SndMakeBuyIndicator",&SndMakeBuyIndicator));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"t5_LkoMakeBuyIndicator",&LkoMakeBuyIndicator));
				ITK_CALL(AOM_UIF_ask_value(itemrev,"t5_DwdMakeBuyIndicator",&DwdMakeBuyIndicator));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_DrawingNo",&DrawingNo));				
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_PartType",&PartType));

				if (strcmp(PartType,"V")==0 || strcmp(PartType,"VCCR")==0 )
				{
					//fprintf(output, "%s,%s,%s,%s,%s,%s,%s\n",PartID,PartRevSeq,Owner,DateRelease,ObjDescription,CS,DrawingNo);fflush(output);
					write2xml(output,"<DesignRevision>\n");
					write2xml(output,"<field key =\"Part_ID\">");
					write2xml(output,PartID);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"rev_seq\">");
					write2xml(output,PartRevSeq);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"OwnerName\">");
					write2xml(output,Owner);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"DateRelease\">");
					write2xml(output,DateRelease);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"Description\">");
					write2xml(output,ObjDescription);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"Component_Part\">");
					write2xml(output,PartentItem);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"UnitOfMeasureS\">");
					write2xml(output,UnitOfMeasureS);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"JsrMakeBuyIndicator\">");
					write2xml(output,JsrMakeBuyIndicator);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"PunMakeBuyIndicator\">");
					write2xml(output,PunMakeBuyIndicator);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"SndMakeBuyIndicator\">");
					write2xml(output,SndMakeBuyIndicator);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"LkoMakeBuyIndicator\">");
					write2xml(output,LkoMakeBuyIndicator);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"DwdMakeBuyIndicator\">");
					write2xml(output,DwdMakeBuyIndicator);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"DrawingNo\">");
					write2xml(output,DrawingNo);
					write2xml(output,"</field>\n");
					write2xml(output,"</DesignRevision>\n");
				}
			}
		}
		

		//ITK_CALL(WSOM_where_referenced(itemrev,1,&n_tskfund,&levelsaa,&referencers,&relations));
		ITK_CALL(PS_where_used_all(itemrev,1,&n_tskfund,&levels,&parents));
		printf("\n No of Reference Found Inside RecursiveFun: %d",n_tskfund);fflush(stdout);

	if(n_tskfund > 0)
	{
		for(task=0;task<n_tskfund;task++)
		{
			itemrev1=parents[task];
			char type_name_ref1[TCTYPE_name_size_c+1];
			ITK_CALL(TCTYPE_ask_object_type(itemrev1,&objTypeRefTag));
			ITK_CALL(TCTYPE_ask_name(objTypeRefTag,&type_name_ref1));
			ITK_CALL(AOM_UIF_ask_value(itemrev1,"object_name",&ObjectName));
			printf("\n type_name_ref,%s,%s",type_name_ref1,ObjectName);
			
			ITK_CALL(AOM_ask_value_string(itemrev1,"item_id",&PartID));
			ITK_CALL(AOM_ask_value_string(itemrev1,"item_revision_id",&PartRevSeq));
			ITK_CALL(AOM_UIF_ask_value(itemrev1,"owning_user",&Owner));
			ITK_CALL(AOM_ask_value_string(itemrev1,"t5_uom",&UnitOfMeasureS));

			if (strcmp(type_name_ref1,"Design Revision")==0 || strcmp(type_name_ref1,"ItemRevision")==0)
			{
								
				temp = (char *)MEM_alloc(250);
				tc_strcpy(temp, "");
				tc_strcat(temp,PartID);
				tc_strcat(temp,PartRevSeq);
				
				
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_DesignGrp",&DesignGrp));
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_ProjectCode",&ProjectCode));
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_Aggregate",&Aggregate));
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_AggregateGroup",&AggregateGroup));
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_Module_Group",&Module_Group));
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_ModuleAddress",&ModuleAddress));
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_Module",&Module));
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_CategoryName",&CategoryName));
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_DsgnOwn",&DsgnOwn));
				//ITK_CALL(AOM_ask_value_string(itemrev1,"release_status_list",&LcsState));
				ITK_CALL(AOM_UIF_ask_value(itemrev1,"date_released",&DateRelease));
				ITK_CALL(AOM_ask_value_string(itemrev1,"object_desc",&ObjDescription));
				ITK_CALL(AOM_UIF_ask_value(itemrev1,"t5_JsrMakeBuyIndicator",&JsrMakeBuyIndicator));
				ITK_CALL(AOM_UIF_ask_value(itemrev1,"t5_PunMakeBuyIndicator",&PunMakeBuyIndicator));
				ITK_CALL(AOM_UIF_ask_value(itemrev1,"t5_SndMakeBuyIndicator",&SndMakeBuyIndicator));
				ITK_CALL(AOM_UIF_ask_value(itemrev1,"t5_LkoMakeBuyIndicator",&LkoMakeBuyIndicator));
				ITK_CALL(AOM_UIF_ask_value(itemrev1,"t5_DwdMakeBuyIndicator",&DwdMakeBuyIndicator));
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_DrawingNo",&DrawingNo));				
				ITK_CALL(AOM_ask_value_string(itemrev1,"t5_PartType",&PartType));

				if (strcmp(PartType,"V")==0 || strcmp(PartType,"VCCR")==0 )
				{
					//fprintf(output, "%s,%s,%s,%s,%s,%s,%s\n",PartID,PartRevSeq,Owner,DateRelease,ObjDescription,CS,DrawingNo);fflush(output);
					write2xml(output,"<DesignRevision>\n");					
					write2xml(output,"<field key =\"Part_ID\">");
					write2xml(output,PartID);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"rev_seq\">");
					write2xml(output,PartRevSeq);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"OwnerName\">");
					write2xml(output,Owner);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"DateRelease\">");
					write2xml(output,DateRelease);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"Description\">");
					write2xml(output,ObjDescription);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"Component_Part\">");
					write2xml(output,PartentItem);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"UnitOfMeasureS\">");
					write2xml(output,UnitOfMeasureS);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"JsrMakeBuyIndicator\">");
					write2xml(output,JsrMakeBuyIndicator);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"PunMakeBuyIndicator\">");
					write2xml(output,PunMakeBuyIndicator);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"SndMakeBuyIndicator\">");
					write2xml(output,SndMakeBuyIndicator);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"LkoMakeBuyIndicator\">");
					write2xml(output,LkoMakeBuyIndicator);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"DwdMakeBuyIndicator\">");
					write2xml(output,DwdMakeBuyIndicator);
					write2xml(output,"</field>\n");
					write2xml(output,"<field key =\"DrawingNo\">");
					write2xml(output,DrawingNo);
					write2xml(output,"</field>\n");
					write2xml(output,"</DesignRevision>\n");
				}
																									

			}
			if (strcmp(type_name_ref1,"Design")==0 || strcmp(type_name_ref1,"BOMView Revision")==0 || strcmp(type_name_ref1,"Design Revision")==0 || strcmp(type_name_ref1,"ItemRevision")==0)
			{				
					int memArr = 0;
					int l=0;
					PartSearStat =0;
														
	/* 				for(memArr = 0; memArr < x; memArr++)
					{						
						if(tc_strcmp(PartArray[memArr],temp)==0)
						{
							printf("\n PartArray----------> :%s,%s\n",PartArray[memArr],temp);fflush(stdout);
							PartSearStat = 1;
							break;
						}
					}
				
					if(PartSearStat == 1)
					{
						return iFail;
					}
					else
					{
						PartArray[x] = temp;						
						x++;
						RecursiveFun(itemrev1,PartentItem,PartArray);
					} */	
					
					if(Counter==1000)
					{
						break;
					}
					else
					{
						Counter++;
						RecursiveFun(itemrev1,PartentItem,PartArray);
					}




					
			}											
		}
	}
	
	return iFail;
		
}




int ITK_user_main(int argc, char* argv[])
{
	    int iFail = 0;
	    char* cError = NULL;
		char* username = NULL;
		tag_t tuser = NULLTAG;
		iFail = ITK_auto_login();
		printf("\nReturn Value is : %d", iFail);fflush(stdout);
		
		int n_entries = 2;
		int i,k,flag;
		tag_t tItemobj1 = NULLTAG;
		tag_t tItemobj = NULLTAG;
		tag_t itemtag  = NULLTAG;
		int n_itemobj_found = 0;
		tag_t* titemobj_results = NULLTAG;
		int n_itemobj_found1 = 0;
		tag_t* titemobj_results1 = NULLTAG;

		char *PartID = NULL;
		char *PartSequenceID = NULL;
		char *part_type = NULL;
		char *Description = NULL;
		char *object_type = NULL;
		char *Part_ProjID = NULL;
		char *Part_DesgnGrp = NULL;
		char *Revision = NULL;
		tag_t DataSet = NULLTAG;
		char *inputfile=NULL;
		char *PartRevSeqID =NULL;
		char *ItemDesc = NULL;
		char *partType	= NULL;
		char *rev_id 	= NULL;
		tag_t LatestRev = NULLTAG;
		int 	n_values_bvr=0;
		tag_t	*bvr_assy_part= NULLTAG;
		char *ProjectCode = NULL;
		char* DesignGroup = NULL;
		int status_count = 0;
		int j = 0;
		char* ReleaseStatus = NULL;
		tag_t* status_list = NULLTAG;
		tag_t reva = NULL;
		char* UserId = NULL;
		int *levels	= 0;
		tag_t *parents = NULLTAG;
		
		
		tag_t itemrev = NULLTAG;
		int Part_Stat_Cnt = 0;
		tag_t *Part_Stat_Lst = NULLTAG;
		char *Part_Rlz_Stat = NULL;
		char *temp= NULL;
		temp = (char *)MEM_alloc(250);
		
		tag_t itemrev1 = NULLTAG;
		tag_t objTypeRefTag=NULLTAG;
		char* ObjectName = NULL;
		char* ObjectName1 = NULL;
		tag_t	*referencers = NULLTAG;
		int ReqFdrSize=0;
		tag_t folder_type = NULLTAG;
		tag_t  reln_type_tag = NULLTAG;
		int Parts =0;
		tag_t* PartsObj = NULLTAG;
		char *Default_Group = NULL;
		char *UserName1 = NULL;
		char *HomeFolder = NULL;
		char *object_type1 = NULL;		
		char* ds_object_type = NULL;
		char  *refname = NULL;
		AE_reference_type_t     reftype;
		tag_t	refobject = NULL;
		char* orig_name = NULL;
		char *fileLoc = NULL;		
		int n_entries1 =3;
		char *cEntries1[3]  = {"Owning User","Type","Name"};
		char **cValues1 = (char **) MEM_alloc(50 * sizeof(char *));
		//char	outputFile[200]	= "PartRefrenced.csv";
				
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		char Data[100] = "";
		char outputFile[200] = "";
		strftime(Data,100,"%d_%m_%Y_%H_%M",&when);
		//sprintf(outputFile,"/tmp/PartRefrenced_%s.xml",Data);
		
		UserId = ITK_ask_cli_argument("-user=");
		char *cEntries[2]  = {"Item ID","Revision"};
		char *inputline = NULL;		
		char **cValues = (char **) MEM_alloc(50 * sizeof(char *));		
		output = fopen("/tmp/PartRefrenced.xml","w");
		write2xml(output,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		write2xml(output,"\n<PLMXML date=\"");
		write2xml(output,Data);
		write2xml(output,"\" >\n");
	
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		//fprintf(output, "Part_ID,Rev/Seq,OwnerName,DateRelease,Description,CS,DrawingNo\n");fflush(output);
				
		if (iFail == ITK_ok)
		{
			printf("\nTeamcenter Login Success...");fflush(stdout);
			POM_get_user(&username, &tuser);
			printf("\nUsername = %s\n", username);fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(iFail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		if (cError)
		{
			MEM_free(cError);
		}
		if (username)
		{
			MEM_free(username);
		}
		

			cValues1[0] =UserId;
			cValues1[1] = "Folder";
			cValues1[2] = "Implosion_Consolidated_for_VC_Input";
			
			printf("\n UserId is:   %s\n",UserId);fflush(stdout);
			ITK_CALL(QRY_find("General...",&tItemobj1));			
			ITK_CALL(QRY_execute(tItemobj1, n_entries1, cEntries1, cValues1, &n_itemobj_found1, &titemobj_results1));	
			printf("n_itemobj_found------------> :%d\n",n_itemobj_found1);fflush(stdout);	
		  
		    if(n_itemobj_found1 > 0)
			{
				itemrev1=titemobj_results1[0];
				char type_name_ref1[TCTYPE_name_size_c+1];
				ITK_CALL(TCTYPE_ask_object_type(itemrev1,&objTypeRefTag));
				ITK_CALL(TCTYPE_ask_name(objTypeRefTag,&type_name_ref1));
				printf("\n type_name_ref,%s",type_name_ref1);
				
				ITK_CALL(AOM_UIF_ask_value(itemrev1,"object_name",&ObjectName));
				printf("\n type_name_ref,%s,%s",type_name_ref1,ObjectName);
									
				ITK_CALL(AOM_ask_value_string(itemrev1,"object_type",&object_type1));
				printf("object_type: %s",object_type1);
				ITK_CALL(AOM_ask_value_tags(itemrev1,"contents", &Parts, &PartsObj));			
				if (PartsObj != NULLTAG)
				{
					printf("contents\n");
					
				}			
				printf("\n  Main : No of contents are : %d \n",Parts); fflush(stdout);
				
				if(Parts > 0)
				{
					for(j=0;j<Parts;j++)
					{
						ITK_CALL(AOM_ask_value_string(PartsObj[j],"object_type",&object_type));
						printf("object_type: %s",object_type);						
						if(tc_strcmp(object_type,"Text")==0)
						{
							iFail = AE_find_dataset_named_ref2(PartsObj[j],0,&refname, &reftype,&refobject);
							if(refobject != NULLTAG)
							{
								iFail = IMF_ask_original_file_name2(refobject , &orig_name);								
								fileLoc = (char *) MEM_alloc( 500 * sizeof(char) );
								tc_strcpy(fileLoc,"/tmp/");
								tc_strcat(fileLoc,orig_name);
								remove( fileLoc );								
								iFail = IMF_export_file( refobject , fileLoc );	
								FILE * fp=NULL;														
								fp = fopen(fileLoc, "r");								
								if(fp==NULL)
								{
									printf("\nCould not open the file %s. Kindly check.\n",fileLoc);fflush(stdout);
								}
								else
								{
									char buffer[MAX_LINE_LEN] ="";
									int x =0;
									char* PartNo = NULL;
									char* PartRev = NULL;
									char* PartSeq = NULL;
												
									while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
									{
										PartNo = strtok(buffer,",");
										PartRev = strtok(NULL,",");
										PartSeq = strtok(NULL,",");
										char * PartRevSeq = NULL;
										PartRevSeq = (char *) MEM_alloc( 100 * sizeof(char) );
										
										tc_strcpy(PartRevSeq,"");
										tc_strcat(PartRevSeq,PartRev);
										tc_strcat(PartRevSeq,";");
									//	tc_strcat(PartRevSeq,PartSeq);	
										tc_strcat(PartRevSeq,PartSeq);										
										printf("\n PartNo PartRev PartSeq PartRevSeq%s %s %s %s",PartNo,PartRev,PartSeq,PartRevSeq);fflush(stdout);										
										cValues[0] = PartNo;
										cValues[1] = PartRevSeq;
										
										ITK_CALL(QRY_find2("Item Revision...",&tItemobj));						
										ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));	
										printf("n_itemobj_found-----------> :%d\n",n_itemobj_found);fflush(stdout);						
										
										int iGMDMLFnd	=	0;
										int	n_tskfund	=	0;
										int task = 0;
										int dmlcnt = 0;
										int k = 0;
										int *levelsaa;
										char	**relations	=  NULL;
										tag_t	tsk_dml_rel_type	=	NULLTAG;
										tag_t	*DMLRev	=	NULLTAG;
										tag_t	*referencers = NULLTAG;
										char* dmlNo = NULL;
										char* DmlType = NULL;
										tag_t objTypeRefTag=NULLTAG;
										char type_name_ref[TCTYPE_name_size_c+1];
										char **PartArray = (char **) MEM_alloc(1000 * sizeof(char *));
										PartSearStat = 0;
										x=0;
										char* ObjectName = NULL;
																					
										if(n_itemobj_found>0)							
										{			
											for(i=0;i<n_itemobj_found;i++)
											{
												reva =titemobj_results[i];
												ITK_CALL(AOM_ask_value_string(reva,"item_id",&PartID));
												ITK_CALL(AOM_ask_value_string(reva,"item_revision_id",&PartRevSeq));
												ITK_CALL(AOM_ask_value_string(reva,"t5_ProjectCode",&ProjectCode));
												ITK_CALL(AOM_ask_value_string(reva,"t5_DesignGrp",&DesignGroup));												
												printf(" \n PartID,PartRevSeq-----------> :%s,%s\n",PartID,PartRevSeq);fflush(stdout);												
												//ITK_CALL(WSOM_where_referenced(reva,1,&n_tskfund,&levelsaa,&referencers,&relations));
												ITK_CALL(PS_where_used_all(reva,1,&n_tskfund,&levels,&parents));
												printf("\n No of Reference Found : %d",n_tskfund);fflush(stdout);
												
												if(n_tskfund>0)
												{
													for(task=0;task<n_tskfund;task++)
													{
														itemrev=parents[task];
														ITK_CALL(TCTYPE_ask_object_type(itemrev,&objTypeRefTag));
														ITK_CALL(TCTYPE_ask_name(objTypeRefTag,&type_name_ref));
														ITK_CALL(AOM_ask_value_string(itemrev,"object_name",&ObjectName));
														printf("\n type_name_ref,%s,%s",type_name_ref,ObjectName);
														//printf("\n ----Inside For Loop------");
														
														if (strcmp(type_name_ref,"Design")==0 || strcmp(type_name_ref,"Design Revision")==0 || strcmp(type_name_ref,"BOMView Revision")==0 || strcmp(type_name_ref,"ItemRevision")==0 )
														{
															Counter=0;
															printf("\n ----Calling RecursiveFun  ------%s",type_name_ref);
															RecursiveFun(itemrev,PartID,PartArray);									       
														} 					
													}														
												}																																														
											}								
										}
										else
										{
											printf("Part Rev Seq----------->Not Found in CVPROD");fflush(stdout);
										}	
									}																				
									if(fp!=NULL)
									{
										fclose(fp); 
									}															
								}																	
							}				
						}
	
					}
				}		
			}
			else
			{
				write2xml(output,"<DesignRevision>\n");
				write2xml(output,"<field key =\"Part_ID\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"rev_seq\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"OwnerName\">");
				write2xml(output,"Status: OK");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"DateRelease\">");
				write2xml(output,"Input Part Not Found");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"Description\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"Component_Part\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"UnitOfMeasureS\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"JsrMakeBuyIndicator\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"PunMakeBuyIndicator\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"SndMakeBuyIndicator\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"LkoMakeBuyIndicator\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"DwdMakeBuyIndicator\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"<field key =\"DrawingNo\">");
				write2xml(output,"---");
				write2xml(output,"</field>\n");
				write2xml(output,"</DesignRevision>\n");
			}
		
		write2xml(output,"</PLMXML>\n");
		iFail = ITK_exit_module(TRUE);
		printf("\nReturn Value is : %d", iFail);
		if (iFail == ITK_ok)
		{
			printf("\nTeamcenter Logout Success...");fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(iFail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		
	fclose(output);
	return ITK_ok;
}

