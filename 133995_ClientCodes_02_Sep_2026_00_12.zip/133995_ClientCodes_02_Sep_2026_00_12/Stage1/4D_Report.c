/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Mohammad Asif
*  Module       :   4D 
*  Description  :   File the 4D Cration report between specific date
*  File Name    :   4D.c
*  Created on   :   04-03-2024
*  
*
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#include <pom/enq/enq.h>
#define ITK_err 910001


int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf);
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
    int i;
    char *retStringf;
    //printf("\n count found %s ",mainStringf);fflush(stdout);
    retStringf = (char*) MEM_alloc(200);
    for(i=0; i < toCharf; i++ )
    *(retStringf+i) = *(mainStringf+i+fromCharf);
    *(retStringf+i) = '\0';
    //printf("\n return string found %s ",retStringf);fflush(stdout);
    return retStringf;
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(PrintErrorStack): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
} 

//char *trimwhitespace(char *str)
//{
//  char *end;
//
//  while(isspace((unsigned char)*str)) str++;
//
//  if(*str == 0)  
//    return str;
//
//  end = str + strlen(str) - 1;
//  while(end > str && isspace((unsigned char)*end)) end--;
//
//  end[1] = '\0';
//
//  return str;
//}


int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	int k=0, m= 0, l=0;
	char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	char temp[10000];
	char env_subject[10000] = {'\0'};
    char env_body[10000]= {'\0'};
	tag_t envelope	= NULLTAG;
	tag_t* recievers = NULLTAG;
	int countenvelop = 0;
	time_t	temptime;
	char GenDate[20];
	struct tm *timeptr;
	int ch;
	char* RptFile= (char *) malloc(400*sizeof(char));
	FILE* fpOutput_file;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	char* cPCode = NULL;
	char* cDGrp = NULL;
	char* cRlsst = NULL;
	char* cFrmdt = NULL;
	char* cTodt = NULL;
	char* responseString = NULL;
	char* fromdatedup = NULL;
	char* todatedup = NULL;
	char* itemIdValue = NULL;
	char* revitemId = NULL;
	char* itemIdValue1 = NULL;
	char* itemRevIdValue1 = NULL;
	char* itemobjectNameValue = NULL;
	char* itemobjectNameValue1 = NULL;
	char* lastModUser = NULL;
	char* lastModUser1 = NULL;
	char* lastModDt = NULL;
	char* lastModDt1 = NULL;
	char* code = NULL;
	char* grp = NULL;
	char* creaDt = NULL;
	char* creaDt1 = NULL;
    char* dadrevsq=NULL;
	dadrevsq=(char *) MEM_alloc(50);
	char* dmlrevseq=NULL;
	dmlrevseq=(char *) MEM_alloc(50);
	char* dmlrev   =NULL;
    dmlrev=(char *) MEM_alloc(50);
	char* dmlseq   =NULL;
    dmlseq=(char *) MEM_alloc(50);
    char* projectname  =NULL;
	char* creatorname  =NULL;
	char* creationdate =NULL;
	char* currentdes   =NULL;  		  
	char* Dmlcreationdate=NULL;
    char* partrevsec     =NULL;
    partrevsec=(char *) MEM_alloc(50);
    char* partrevse1     =NULL;
    partrevse1=(char *) MEM_alloc(50);
    char* partrev	     =NULL;
    partrev=(char *) MEM_alloc(50);
    char* partseq	     =NULL;
    partseq=(char *) MEM_alloc(50);
    char* partdescrip    =NULL;
	char* File=NULL; 
    int id=0;
	//printf("\n Generating Curernt Time Stamp");fflush(stdout);
	//temptime = time(NULL);
	//tc_strcpy(GenDate,"");
//	timeptr = (struct tm *)localtime(&temptime);
	//ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y_%H_%M",timeptr);
	//ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y",timeptr);
	//printf("\n Current Time --------> %s", GenDate);fflush(stdout);
	//tc_strcpy(RptFile,"4DReportTill");
	//tc_strcat(RptFile,"_");
	//tc_strcat(RptFile,GenDate);
	//tc_strcat(RptFile,".csv");
	
	//printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);

			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			cUSERID = ITK_ask_cli_argument("-u=");
			cPASS = ITK_ask_cli_argument("-pf=");
			cGroup = ITK_ask_cli_argument("-g=");
			//cPCode = ITK_ask_cli_argument("-pc=");
			//cDGrp = ITK_ask_cli_argument ("-dg=");
			//cRlsst = ITK_ask_cli_argument("-rls=");
			cFrmdt = ITK_ask_cli_argument("-Frmdt=");
			cTodt = ITK_ask_cli_argument("-Todt=");
			RptFile=ITK_ask_cli_argument("-file="); 
			int	 iStatus = 0;
			iStatus = ITK_auto_login();
			fromdatedup= (char *)MEM_alloc(20);
			tc_strcpy(fromdatedup,"");
			tc_strcpy(fromdatedup,cFrmdt);
            tc_strcat(fromdatedup," 00:00:00");    
			todatedup= (char *)MEM_alloc(20);
			tc_strcpy(todatedup,"");
			tc_strcpy(todatedup,cTodt);
			tc_strcat(todatedup," 23:59:59");  
            printf(" From date -----------%s",fromdatedup);
            printf(" Todate date -----------%s",todatedup);
			printf("\nUsername --------> %s", cUSERID);fflush(stdout);
			printf("\nPassword --------> %s", cPASS);fflush(stdout);
			printf("\nGroup --------> %s", cGroup);fflush(stdout);
			printf("\nProject Code --------> %s", cPCode);fflush(stdout);
			printf("\nDesign Group --------> %s", cDGrp);fflush(stdout);
			ITK_CALL(ITK_init_module(cUSERID, cPASS, cGroup));
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			printf("\n Output File Name --------> %s", RptFile);fflush(stdout);
		    printf("\nReturn Value From Login API --------> %d", iFail);fflush(stdout); 
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");fflush(stdout);
				POM_get_user(&username, &tuser);
				printf("\nLogged in Username --------> %s", username);fflush(stdout);
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			

			fpOutput_file = fopen(RptFile, "w");
            fprintf(fpOutput_file,"DML No, DML Creator, Part No, Part Revision, Part Sequence, Part Desc. , 4D Doc Name, 4D Doc Rev., 4D Doc Seq., 4D Doc Project, 4D Creator, 4D Dec., 4D Owner, 4D Creation Date,  \n " );fflush(fpOutput_file); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Output File on Server --------> %s",RptFile);fflush(stdout);
				return iFail;
	        }
			//printf("\n Input Project Code: -------> %s", cPCode);fflush(stdout);
			//printf("\n Input Design Group: -------> %s", cDGrp);fflush(stdout);
//			if((cPCode != NULL) && (tc_strcmp(cPCode,"")!=0) && (cDGrp != NULL) && (tc_strcmp(cDGrp,"")!=0))
//			{
					int		QryCount 				=  0;
					int     countrel                =  0;
					int     n_levels                =  1;
					int     n1_levels                =  1;
					int     n2_levels                =  1;
					int     number_of_refrence      =	0;
					int     number_of_refrence1      =	0;
					int     number_of_refrence2      =	0;
                    int		*level					 =  0;
                    int		*level1					 =  0;
                    int		*level2					 =  0;
					//tag_t	Obj4D					= NULLTAG;
					tag_t	eachreftag					= NULLTAG;
					tag_t	eachreftag1					= NULLTAG;
					tag_t	eachreftag2					= NULLTAG;
					tag_t	*refencestag					= NULLTAG;
					tag_t	*refencestag1					= NULLTAG;
					tag_t	*refencestag2					= NULLTAG;
					tag_t	dmltasktag					= NULLTAG;

					tag_t	parttag1				= NULLTAG;
					tag_t	 *Obj4D1				= NULLTAG;
					tag_t	 *parttag				= NULLTAG;
					tag_t	 *dmltaskarray			= NULLTAG;
					tag_t	 *dmlrevisionarray		= NULLTAG;
					tag_t	ProQry4DObj				= NULLTAG;
					tag_t	Obj4D				= NULLTAG;
					tag_t	latestRlzRevTag			= NULLTAG;
					tag_t	latestrev			    = NULLTAG;
					tag_t	dmlrevisionatag			    = NULLTAG;
					tag_t Rel4D=NULLTAG;
					tag_t DMLTASK=NULLTAG;
					tag_t dmlrevision=NULLTAG; 
					
					//tag_t	releasesatus			= NULLTAG;
					tag_t  *tags_found4   = NULL;
					tag_t  *DesigRevisiontagArray   = NULLTAG;
					tag_t  DesigRevisiontag   = NULL;
					tag_t  *rel_status_lst   = NULL;
					char * Chld_Rel_Stus1 =NULL;
					char * itemRevIdValue =NULL;
					char * releasesatus =NULL;
					char *  DesRevitemId =NULL;
					char* checkedOut = NULL;
					char* dsgnRevPrjCode = NULL;
					char* dsgnRevDsgnGrp = NULL;
					char** relation=NULL;
					char** relation1=NULL;
					char** relation2=NULL;
					int		n_tags_found4 = 0;
					int		rev_count = 0;
					int		latestRlzRevFlag = 0;
					int		A = 0;
					int		B = 0;
					//int     k = 0;
					int		relcount = 0;
					int		rel_status_cunt = 0;
					int		dmltaskcount = 0;
					int		dmlrevisioncount = 0;

					int		flag			= 0;
					int		n_Input					= 3;
					//int		n_Input					= 1;
					char buffer[50];

					char *eachrefname = NULL;
					char *eachrefname1 = NULL;
					char *eachrefname2 = NULL;

					char *obj_type = NULL;
					char *obj_type1 = NULL;
					char *obj_type2 = NULL;
					char *obj_type3 = NULL;
					
					

					obj_type  = (char *)MEM_alloc(100);
					obj_type1 = (char *)MEM_alloc(100);
					obj_type2 = (char *)MEM_alloc(100);
					obj_type3 = (char *)MEM_alloc(100); 

					char *qry_Input[3] = {"Type","Created After","Created Before"};
					//char  *qry_Input[1] = {"Name"};
					char **values = (char **) MEM_alloc(100 * sizeof(char *));
					//char *values[5];

					printf("\n nwRev:::::::: = ");fflush(stdout);
//					values[0] =	cPCode;			//cDGrp;
//					values[1] =	cDGrp;			//;
//					values[2] =	"T5_LcsReview";	//cRlsst;ERC Review
//					values[3] =	cFrmdt;			//cFrmdt;"01-Jan-2022"
//					values[4] =	cTodt;			//cTodt;"01-Jan-2023"

					//values[0] =	"DFM_546869100131_C_2_01";			//cFrmdt;"01-Jan-2022"  DFA_5468E1A0354002_NR_1_01
					values[0] =	"DAD Doc Revision";			//cFrmdt;"01-Jan-2022"
					values[1] =	fromdatedup;			//cTodt;"01-Jan-2023"
					values[2] =	todatedup;			//cTodt;"01-Jan-2023"

					if(QRY_find2("Item Revision...", &ProQry4DObj));
					if(ProQry4DObj!=NULLTAG)
					{
						  // printf("\n qUERY for 4D count***== %d", Count4D);fflush(stdout);

						 if(QRY_execute(ProQry4DObj, n_Input, qry_Input, values, &QryCount, &Obj4D1));
						 printf("\n qUERY for check in count== %d\n", QryCount);fflush(stdout);

						// if(ITEM_find_items_by_key_attributes(1,qry_Input, values, &QryCount, &Obj4D1)!=ITK_ok)PrintErrorStack();
						// printf("\n n_tags_found: [%d]",QryCount);fflush(stdout);


						for(i=0;i<QryCount;i++)      
						{	
						  Obj4D=Obj4D1[i];
						 //if(ITEM_find_item("DFA_5442E2A0654002_A_2_01",&Obj4D));
                         //ITK_CALL(ITEM_ask_latest_rev(Obj4D,&Obj4D));
						 if(AOM_UIF_ask_value(Obj4D,"release_status_list",&releasesatus));  
                         printf("\n---------->Release status of 4D document is %s",releasesatus);
						  if(AOM_UIF_ask_value(Obj4D,"item_id",&obj_type1));

							 printf("\n\n\n--->%s",obj_type1);
						  if(tc_strstr(releasesatus,"ERC Released")!=0)   
						 {
							 //if(AOM_UIF_ask_value(Obj4D,"release_status_list",&releasesatus));
							
						 	//if(AOM_UIF_ask_value(Obj4D,"item_id",&itemIdValue));
						 	//if(AOM_UIF_ask_value(Obj4D,"object_name",&itemobjectNameValue));
						 	//if(AOM_UIF_ask_value(Obj4D,"last_mod_user",&lastModUser));
						 	//if(AOM_UIF_ask_value(Obj4D,"last_mod_date",&lastModDt));
						 //	if(AOM_UIF_ask_value(Obj4D,"creation_date",&creaDt));
						 //	printf("\n Object id found == %s,%s\n", itemIdValue,itemobjectNameValue);fflush(stdout);
						 
						 	///ITK_CALL(ITEM_ask_item_of_rev(Obj4D,&Obj4D));   //Item of revision
                             ITK_CALL(GRM_find_relation_type("T5_PartHas4D", &Rel4D));
							 ITK_CALL(GRM_list_primary_objects_only(Obj4D,Rel4D,&rev_count,&DesigRevisiontagArray)); 
							 printf("\n\n\n Design revision count--->%d",rev_count); 
							 if(rev_count>0)
							{
							 for(k=0;k<rev_count;k++)
							{
							 
							 DesigRevisiontag=DesigRevisiontagArray[k];
							 if(AOM_UIF_ask_value(DesigRevisiontag,"item_id",&obj_type1));
							 printf("\n\n\n--->%s",obj_type1);


                               ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&DMLTASK));
							   ITK_CALL(GRM_list_primary_objects_only(DesigRevisiontag,DMLTASK,&dmltaskcount,&dmltaskarray));
							    printf("\n\n\n DML Task Count--->%d",dmltaskcount);
							   if(dmltaskcount>0)
								{ 
								for(l=0;l<dmltaskcount;l++)
								{
								
								dmltasktag=dmltaskarray[l];
								if(AOM_UIF_ask_value(dmltasktag,"object_type",&obj_type2));
							     printf("\n\n\n--->%s",obj_type2);
								 if(tc_strcmp(obj_type2,"ERC Task Revision")==0)
									
									{
								if(AOM_UIF_ask_value(dmltasktag,"item_id",&DesRevitemId));
                                printf("\n\n\n--->%s",DesRevitemId);
                                
                                  ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&dmlrevision));
                                   if(dmlrevision!=NULLTAG)
								{
							   
							    printf("\n\n\n\n..............DML Task  Null..............\n\n\n");
							    }
								  ITK_CALL(GRM_list_primary_objects_only(dmltasktag,dmlrevision,&dmlrevisioncount,&dmlrevisionarray));
								   printf("\n\n\n DML Revision Count--->%d",dmlrevisioncount); 
                                 if(dmlrevisioncount>0) 
									{
								  for(m=0;m<dmlrevisioncount;m++)
									{ 
								 
								  dmlrevisionatag=dmlrevisionarray[m];
								  if(AOM_UIF_ask_value(Obj4D,"item_id",&itemIdValue));
								  if(AOM_UIF_ask_value(dmlrevisionatag,"object_type",&obj_type3)); 
							       printf("\n\n\n--->%s",obj_type3);
								   if(tc_strcmp(obj_type3,"ERC DML Revision")==0)
										{
                                       if(AOM_UIF_ask_value(DesigRevisiontag,"item_id",&obj_type1));
									   if(AOM_UIF_ask_value(DesigRevisiontag,"item_revision_id",&partrevsec)); 
											//partrevsec=strtok(partrevsec,NULL);
											partrev=strtok(partrevsec,";");
											partseq=strtok(NULL," ");
											
											if(AOM_UIF_ask_value(DesigRevisiontag,"object_desc",&partdescrip));
											id = 0;
								           while(partdescrip[id]!='\0')
								           {				 
								           	if(partdescrip[id]==',' || partdescrip[id]=='\n')
								           	{
								           		partdescrip[id]=' ';
								           	}
								           	id++;
								           }
											if(AOM_UIF_ask_value(dmlrevisionatag,"item_id",&DesRevitemId));
                                           if(AOM_UIF_ask_value(dmlrevisionatag,"owning_user",&Dmlcreationdate)); 
											if(AOM_UIF_ask_value(Obj4D,"item_id",&itemIdValue));
                                            printf("\n 4D Doc Number is : %s",itemIdValue);
														if(AOM_UIF_ask_value(Obj4D,"current_revision_id",&dadrevsq));
                                                         printf("\n 4D Doc rev and seq is : %s",dadrevsq);
														//dmlrevseq=strtok(dadrevsq,NULL);
														dmlrev=strtok(dadrevsq,";");
														dmlseq=strtok(NULL," ");
														printf("\n DML rev is : %s",dmlrev);
														printf("\n DML seq is : %s",dmlseq);
														if(AOM_UIF_ask_value(DesigRevisiontag,"t5_ProjectCode",&projectname));
														if(AOM_UIF_ask_value(Obj4D,"owning_user",&creatorname)); 
														if(AOM_UIF_ask_value(Obj4D,"creation_date",&creationdate));
														if(AOM_UIF_ask_value(Obj4D,"current_desc",&currentdes));
								
                                                       if(fpOutput_file) fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, \n",DesRevitemId,Dmlcreationdate,obj_type1,partrev,partseq,partdescrip,itemIdValue,dmlrev,dmlseq,projectname,creatorname,currentdes,"ERC Released",creationdate);
                                   

                                          break;                
								   //if(AOM_UIF_ask_value(dmlrevisionatag,"item_id",&Dmlcreationdate)); 
							      // printf("\n\n\n--->%s",Dmlcreationdate);
									   } 
									   
									  
								    } 
									} 




								
								}
								
								
								}
							}
							

							 }
						}

						//	 if(rev_count>0)
						//	{
						//	 if(AOM_UIF_ask_value(allrev_list[0],"object_type",&obj_type1));
						//	 printf("\n\n\n\nCount Found\n\n\n\n %s",obj_type1);  
						//	 printf("\n%d\n",rev_count);
						//
						//	 
						//	}

						


							// ITK_CALL(ITEM_ask_latest_rev(Obj4D,&Obj4D));


						 	//ITK_CALL(ITEM_list_all_revs(Obj4D,&rev_count,&allrev_list));
						 	//printf("\n  rev_count is %d\n", rev_count);fflush(stdout);
						 	//if(AOM_ask_value_string(Obj4D,"release_status_list ",&releasesatus));
						 	//
						 	//
						 	////if(ITEM_ask_latest_rev(Obj4D,&latestrev));
						 	////if(rev_count>0)
							//if(tc_strstr(releasesatus,"ERC Released")==0)
						 	//{
							//
							//
                            //  
                            //    
							//	
							//	//ITK_CALL(WSOM_where_referenced(Obj4D,n_levels,&number_of_refrence,&level,&refencestag,&relation));
							//	if(WSOM_where_referenced(Obj4D,n_levels,&number_of_refrence,&level,&refencestag,&relation)!=ITK_ok)PrintErrorStack();
							//	printf("\n\t WSOM_where_referenced levels--> %d referencers--> %d relationsRef--> %s ",n_levels,number_of_refrence,&relation); fflush(stdout);
							//	//printf("\n No of refrence == %d",number_of_refrence);
							//
							//	for (k=0;k<number_of_refrence ;k++ )//2
							//	{
							//		
							//		 eachreftag = refencestag[k];
							//
		                    //         ITK_CALL(WSOM_ask_name2(eachreftag,&eachrefname));
							//
							//		 printf("\n  name of [%d] ref name is : %s", k ,eachrefname);
							//
							//		 ITK_CALL(WSOM_ask_object_type2(eachreftag,&obj_type));
							//
							//		  printf("\n obj_type : %s ",obj_type);fflush(stdout);
							//
		    				//		  if (tc_strcmp(obj_type,"Design Revision")==0)
							//		  {
							//			printf("\n inside Design Revision condition...");
							//
							//			if(AOM_UIF_ask_value(eachreftag,"item_id",&revitemId));
							//
							//			printf("\n  name of ref design rev name : %s",revitemId); 
							//
							//			flag++; //flag=1
							//
							//			if(flag > 0)
							//			{
							//				if(WSOM_where_referenced(eachreftag,n1_levels,&number_of_refrence1,&level1,&refencestag1,&relation1)!=ITK_ok)PrintErrorStack();
							//
							//				printf("\n\t WSOM_where_referenced levels1 --> %d referencers1--> %d relationsRef1--> %s ",n1_levels,number_of_refrence1,&relation1); fflush(stdout);
							//
							//					for (l=0;l<number_of_refrence1 ;l++ )
							//					{
							//		
							//						eachreftag1 = refencestag1[l];
							//
							//						ITK_CALL(WSOM_ask_name2(eachreftag1,&eachrefname1));
							//
							//						///ITK_CALL(WSOM_ask_object_type2(eachreftag1,&obj_type1));
							//
							//						if(AOM_UIF_ask_value(eachreftag1,"object_type",&obj_type1));
							//
							//						printf("\n obj_type1 : %s ",obj_type1);fflush(stdout);
							//
							//						if (tc_strcmp(obj_type1,"ERC Task Revision")==0) //ERC Task Revision//7//
							//						{
							//							printf("\n inside ERC/APL Task Revision condition...");
							//
							//							printf("\n name of ref task name1 is : %s",eachrefname1);
							//
							//							if(WSOM_where_referenced(eachreftag1,n2_levels,&number_of_refrence2,&level2,&refencestag2,&relation2)!=ITK_ok)PrintErrorStack();
							//
							//							printf("\n\t WSOM_where_referenced levels2 --> %d referencers2--> %d relationsRef2--> %s ",n2_levels,number_of_refrence2,&relation2); fflush(stdout);
							//
							//
							//							for (m=0;m<number_of_refrence2;m++ )
							//							{ 
							//								eachreftag2 = refencestag2[m];
							//
							//								ITK_CALL(WSOM_ask_name2(eachreftag2,&eachrefname2));
							//
							//								///ITK_CALL(WSOM_ask_object_type2(eachreftag2,&obj_type2));
							//
							//								if(AOM_UIF_ask_value(eachreftag2,"object_type",&obj_type2));
							//								printf("\n obj_type2 : %s ",obj_type2);fflush(stdout);
							//
							//								if(tc_strcmp(obj_type2,"ERC DML Revision")==0)//ERC DML Revision 
							//								
							//							    {
							//
							//								if(AOM_UIF_ask_value(eachreftag2,"item_id",&DesRevitemId));
							//								if(AOM_UIF_ask_value(Obj4D,"item_id",&itemIdValue));
                            //                                printf("\n 4D Doc Number is : %s",itemIdValue);
							//								if(AOM_UIF_ask_value(Obj4D,"current_revision_id",&dadrevsq));
                            //                                printf("\n 4D Doc rev and seq is : %s",dadrevsq);
							//								//dmlrevseq=strtok(dadrevsq,NULL);
							//								dmlrev=strtok(dadrevsq,";");
							//								dmlseq=strtok(NULL," ");
							//								printf("\n DML rev is : %s",dmlrev);
							//								printf("\n DML seq is : %s",dmlseq);
							//								if(AOM_UIF_ask_value(Obj4D,"t5projectname",&projectname));
							//								if(AOM_UIF_ask_value(Obj4D,"owning_user",&creatorname));
							//								if(AOM_UIF_ask_value(Obj4D,"creation_date",&creationdate));
							//								if(AOM_UIF_ask_value(Obj4D,"current_desc",&currentdes));
							//
							//
							//
							//								
							//									printf("\n inside ERC/APL DML Revision condition...");
							//
							//									printf("\n  name of ref DML revision is : { %s }",eachrefname2);
                            //                                    if(AOM_UIF_ask_value(eachreftag2,"item_id",&DesRevitemId));
                            //                                    if(AOM_UIF_ask_value(eachreftag2,"requestor_user_id",&Dmlcreationdate));
							//									if(AOM_UIF_ask_value(eachreftag,"item_id",&obj_type1));
							//									if(AOM_UIF_ask_value(eachreftag,"item_revision_id",&partrevsec)); 
							//									//partrevsec=strtok(partrevsec,NULL);
							//									partrev=strtok(partrevsec,";");
							//									partseq=strtok(NULL," ");
							//									
							//									if(AOM_UIF_ask_value(eachreftag,"object_desc",&partdescrip));
							//									id = 0;
							//		                            while(partdescrip[id]!='\0')
							//		                            {				 
							//		                            	if(partdescrip[id]==',' || partdescrip[id]=='\n')
							//		                            	{
							//		                            		partdescrip[id]=' ';
							//		                            	}
							//		                            	id++;
							//		                            }
							//
							//
							//
							//
                            //                                    
							//									 
							//									//fprintf(fpOutput_file," %s - %s - %s \n ",eachrefname2, revitemId, DesRevitemId );
							//
							//									if(fpOutput_file) fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, \n",DesRevitemId,Dmlcreationdate,obj_type1,partrev,partseq,partdescrip,itemIdValue,dmlrev,dmlseq,projectname,creatorname,currentdes,"ERC Released",creationdate);
							//
							//								 
							//							
							//
							//
							//								MEM_free(obj_type2);  
							//								break;
							//							}
							//							}
							//
							//						}
							//
							//						MEM_free(obj_type1);
							//					}
							//
							//			  }
							//
							//			}
							//			
							//			MEM_free(obj_type);
						 	//} 
						 //}
					  //}
						}
						else
							{
						
						     printf("\n\n\n4D Document is not release vault\n\n\n");
						    }
					}
					}

 
                    if (fpOutput_file)
                    {
						fclose(fpOutput_file) ; 
                        fpOutput_file=NULL;
                    }
		
					         
					printf("\n Report File Closed Successfully\n");fflush(stdout);
					
	return 0;
} 