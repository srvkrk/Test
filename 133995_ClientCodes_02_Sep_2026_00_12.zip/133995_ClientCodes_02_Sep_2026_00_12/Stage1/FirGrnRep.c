
	/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Saurabh Singh
*  Module       :   Updating release date of design revison and effectvity as per effectivity text
*  Code         :   UpdRelDate.c
*  Created on   :   May 23rd, 2018
*  Usage		:	dataset_CMI2_correct -u=<user> -p=<password> -g=<group> -inputfile=<File with Item,Rev>
*
* Modification History :
* S.No    Date                  CR No     Modified By            Modification Notes
***************************************************************************/




#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tcinit/tcinit.h>
#include <qry/qry.h>
#include <tc/tc_startup.h>
#include <tccore/workspaceobject.h>
#include <ae/dataset.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
//#include <tc/iman.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>

#include <unidefs.h>

#include <bom/bom.h>
#include <cfm/cfm.h>

#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>

#define ITK_err 910001
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
		
    }
	return return_code;
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}


void printHelp()
{
	printf("\n-----------------------------------\n");
	printf("\t\tHELP\n");
	printf("\t\tdataset_CMI2_correct -u=<user> -p=<password> -g=<group> -inputfile=<File with Item>\n");
	printf("\n-----------------------------------\n");
}


char* RMDVDetails(char *TstPNTNo, char *TstReqNo, char *TstGRNReportNos, char *TstGRNReportNames,char *TstGRNReportLinks, char *TstFIRReportNos, char *TstFIRReportNames, char *TstFIRReportLinks);


int ITK_user_main(int argc, char* argv[])
{



    int ifail = 0;
//	char* user=NULL;
//	char* passwdfile=NULL;
//	char* group=NULL;
	char* input1=NULL;
	char* input2=NULL;
;
	char  *LcsState =NULL;


	// ./FirGrnRep -u=ercpsup -p=ERCpsup2019 -d1=13-Mar-2019 -d2=13-Mar-2021
	// ./FirGrnRep -u=ercpsup -p=ERCpsup2019 -d1=05-Sep-2021 -d2=06-Sep-2021

	// ./FirGrnRep -u=ercpsup -p=ERCpsup2019 -d1=2021/09/05 -d2=2021/09/06
	// ./FirGrnRep -u=ercpsup -p=ERCpsup2019 -d1=05/09/2021 -d2=06/09/2021

	//./FirGrnRep -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -d1=03/01/2022  -d2=04/01/2022
	//./FirGrnRep -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -d1=03-Jan-2022 -d2=04-Jan-2022

//	user=ITK_ask_cli_argument("-u=");
//	passwdfile=ITK_ask_cli_argument("-pf=");
//	group=ITK_ask_cli_argument("-g=");

	input1=ITK_ask_cli_argument("-d1=");
	input2=ITK_ask_cli_argument("-d2=");
	//LcsState=ITK_ask_cli_argument("-LCS=");

	char			*entry0						= "Name";
	char			*entry1						= "Date Released";
	//char			*LcsState						= "ERC Released";
	
	tag_t			query_tag					= NULLTAG;
	tag_t			attachRelationType					= NULLTAG;
	tag_t			attachRelationType1					= NULLTAG;
	tag_t			TDM_rev_tag					= NULLTAG;
	tag_t			*DATASET_attch					= NULL;
	tag_t			*DATASET_attchFIR					= NULL;
	int				results						= 0;
	tag_t			*object_tag					= NULLTAG;
	char			*Item_proj					= NULLTAG;
	char		*Item_RelTyp				= NULL;
	char		*Item_DateRel				= NULL;
	char		*Item_name				= NULL;
	//char   refname[AE_reference_size_c + 1];
    char* refname = NULL;
	AE_reference_type_t     reftypeAttach;
	tag_t refobjectAttach = NULLTAG;
	//char   orig_nameAttach[IMF_filename_size_c + 1];
	char* orig_nameAttach = NULL;
	//char 	relative_path[SS_MAXPATHLEN] ;
	char* relative_path = NULL;

	char *ProjectList="5442,5445,5447";
	char *DmlType="MR,TODR,CP";
	date_t			from_date1;
	int i=0,tt=0,AttCnt=0,SpecCnt=0,iA=0,refnumfnd_A=0,jA=0;
	int iAA=0;
	int jAA=0;
	int AttCnt1=0;
	int refnumfnd_A1=0;
	char *Firobjs =NULL;
	char *Grnobjs =NULL;

	int FIRflag =0;
	int GRNflag =0;
	int n_entries =4;

	char* text = NULL;

    int 	num_to_sort			=	1;
	char	*keys			=	{"creation_date"};
	int		orders				=	{1};

    tag_t dataset = NULLTAG;
	//const char *seq = (const char *) MEM_alloc(10 * sizeof(char *));
	//
	//tc_strcpy(seq,"");
	//tc_strcat(seq,"A;1");
	//
	//printf("seq : %s",seq);
	//FILE *inFptr;

	char **values = (char **) MEM_alloc(40 * sizeof(char *));
	
	values[0]  = (char*) MEM_alloc (sizeof(char) * (tc_strlen(LcsState) + 20));
	values[1]  = (char*) MEM_alloc (sizeof(char) * (tc_strlen(input1) + 20));
	values[2]  = (char*) MEM_alloc (sizeof(char) * (tc_strlen(input2) + 20));
	values[3]  = (char*) MEM_alloc (sizeof(char) * (20));
	//values[4]  = (char*) MEM_alloc (sizeof(char) * (20));
	//values[1]  = (char*) MEM_alloc (sizeof(char) * (10));
	//values[2]  = (char*) MEM_alloc (sizeof(char) * (20));

	tag_t TR_FIR_rel_type = NULLTAG;
	tag_t TR_GRN_rel_type = NULLTAG;
	//char *entries[5] = {"Release Status","Date Released From","Date Released To","Ref DVP No","Request Domain"};
	//char **entries  = (char **) MEM_alloc(4 * sizeof(char *));
	char* entries[4] = {"Release Status","Date Released From","Date Released To","Description"};
	//entries[0] = "Release Status";
	//entries[1] = "Date Released From";
	//entries[2] = "Date Released To";
	//entries[3] = "Description";

	

	//char *entries[3] = {"Release Status","Ref DVP No","Request Domain"};

	//RMDVDetails("TEST123456789","Test","GRN11","NA","NA","NA","NA","NA");

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	
	ifail = ITK_auto_login( );

//	ifail =TC_init_module(user,passwdfile,group);


	if(ifail == 0)
	{
		printf("\n Login successful......");
	}
	else 
	{
		printf("\n Login is not successful......");
	}

	ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Input Values %s <%s>\n",input2,input1);
	//values[0] = "*Close*" ;
	values[0] = "Close FIR/Test request";
	values[1] = input1;
	values[2] = input2;
	values[3] = "RMDV";
	//values[4] = "Testing-Indoor";
	//values[1] = "RMDV2";
	//values[2] = "Testing-Indoor";
	//inFptr=fopen(inputFile,"w");
	

	ITK_CALL(QRY_ignore_case_on_search(TRUE));
	//ITK_CALL(QRY_find2("Test_Request_RMDV", &query_tag));

	ITK_CALL(QRY_find2("Test Request Query", &query_tag));

	if(query_tag == NULLTAG)
	{
	   printf("\nQuery Not Found in Teamcenter....!!\n");
	   return 0;
	}
	else
	{
		printf("\nQuery Found....!!\n"); fflush ( stdout) ;
		//ifail = QRY_execute_with_sort (query_tag, n_entries, entries, values, num_to_sort,&keys,&orders,&results, &object_tag);
  
		 ifail = QRY_execute(query_tag,n_entries, entries, values, &results, &object_tag);PrintErrorStack();
		//ifail = QRY_execute_with_sort	(query_tag,n_entries,entries,values,1,&keys,&orders,&results,&object_tag);PrintErrorStack();	
		
		printf("\nTotal %d objects found\n", results); fflush ( stdout) ;

		//ifail = ITEM_find_item_revs_by_key_attributes(n_entries,entries,values,seq,&results,&object_tag);

		//ITK_CALL(EMH_get_error_string(NULLTAG,ifail,&text));
   
		
		if(ifail != 0)
		{
		  printf("\n error : %s \n",text);
		}
		
		printf("\nTotal %d objects found\n", results); fflush ( stdout) ;
		if (results>0)
		{
			int Cnt=0;
			int Icnt=0;

			ITK_CALL(GRM_find_relation_type("T5_TR_FIR_REL", &TR_FIR_rel_type));
			ITK_CALL(GRM_find_relation_type("T5_TR_GR_REL", &TR_GRN_rel_type));
			for (tt=0;tt<results;tt++)
			{
				char* TestReqRefNos=NULL;
				char* TestReqNos=NULL;
				char* FirObjNos=NULL;
				char* GrnObjNos=NULL;
				ITK_CALL(AOM_ask_value_string(object_tag[tt],"item_id",&TestReqNos));
				printf("\n TestReqNos <%s>\n",TestReqNos);
				ITK_CALL(AOM_ask_value_string(object_tag[tt],"t5_TstReqRef",&TestReqRefNos));
				printf("\n Part nos task Values <%s>\n",TestReqRefNos);

				char		*FilenamePathFIR				= NULL;
				char		*FilenameFIR				= NULL;
				if (TR_FIR_rel_type!=NULLTAG)
				{
					int FirCnt=0;
					tag_t *FIR=NULL;
					Firobjs= (char *) MEM_alloc(20);
					
					
					ITK_CALL(GRM_list_secondary_objects_only(object_tag[tt],TR_FIR_rel_type,&FirCnt,&FIR));
					printf("\n TR FIR: %d",FirCnt);fflush(stdout);	

					sprintf(Firobjs,"%d",FirCnt);//NEW
					printf("\n Firobjs = [%s]\n",Firobjs);fflush(stdout);//NEW


					for (Icnt=0;Icnt<FirCnt ;Icnt++ )
					{	
					
						ITK_CALL(AOM_ask_value_string(FIR[Icnt],"item_id",&FirObjNos));
						printf("\n FIR Values <%s>\n",FirObjNos);

						ITK_CALL(GRM_find_relation_type("TC_Attaches",&attachRelationType));
						//
						//ITK_CALL(GRM_list_secondary_objects_only(FIR[Cnt],attachRelationType,&AttCnt,&DATASET_attchFIR));
						ITK_CALL(GRM_list_secondary_objects_only(FIR[Icnt],attachRelationType,&AttCnt,&DATASET_attchFIR));
						

						printf("\n Inside merging Report.....!!  %d  \n\n",AttCnt);fflush(stdout);


						FilenameFIR = (char*) MEM_alloc (sizeof(char) * (200));
						FilenamePathFIR = (char*) MEM_alloc (sizeof(char) * (500));
						tc_strcpy(FilenameFIR,"");
						tc_strcpy(FilenamePathFIR,"");


						
						for (iA=0;iA<AttCnt;iA++)
						{
							ITK_CALL(AE_ask_dataset_ref_count(DATASET_attchFIR[iA],&refnumfnd_A));
							printf("\n NMRef found......%d",refnumfnd_A);fflush(stdout);
							for(jA=0;jA<refnumfnd_A;jA++)
							{
								ITK_CALL(AE_find_dataset_named_ref2(DATASET_attchFIR[iA],jA,&refname,&reftypeAttach,&refobjectAttach));
								ITK_CALL( IMF_ask_original_file_name2(refobjectAttach,&orig_nameAttach));
								printf("\n NMRef found str 111111......%s",orig_nameAttach);fflush(stdout);

								tc_strcat(FilenameFIR,orig_nameAttach);
								//tc_strcat(FilenameFIR,"^");

								IMF_ask_file_pathname2(refobjectAttach,SS_UNIX_MACHINE,&relative_path);
								printf("\n relative_path=%s\n",relative_path);

								tc_strcat(FilenamePathFIR,relative_path);

								FIRflag=1;
								//tc_strcat(FilenamePathFIR,"^");
							}
							
						}

					}
				}

						char		*FilenamePath				= NULL;
						char		*Filename				= NULL;
		
				if (TR_GRN_rel_type!=NULLTAG)
				{
					int Grncnt=0;
					tag_t *Grnrep=NULL;
					Grnobjs= (char *) MEM_alloc(20);
					
					ITK_CALL(GRM_list_secondary_objects_only(object_tag[tt],TR_GRN_rel_type,&Grncnt,&Grnrep));
					printf("\n XXXXXXXXXX TR Grncnt: %d",Grncnt);fflush(stdout);	

					sprintf(Grnobjs,"%d",Grncnt);//NEW
					printf("\n Grnobjs = [%s]\n",Grnobjs);fflush(stdout);//NEW

					for (Cnt=0;Cnt<Grncnt ;Cnt++ )
					{	
					

						ITK_CALL(AOM_ask_value_string(Grnrep[Cnt],"item_id",&GrnObjNos));
						printf("\n GrnObjNos Values <%s>\n",GrnObjNos);
						
					 // ITK_CALL(GRM_find_relation_type("TC_Attaches",&attachRelationType));
						ITK_CALL(GRM_find_relation_type("TC_Attaches",&attachRelationType1));//new
						
						//ITK_CALL(GRM_list_secondary_objects_only(Grnrep[Cnt],attachRelationType,&AttCnt,&DATASET_attch));
						ITK_CALL(GRM_list_secondary_objects_only(Grnrep[Cnt],attachRelationType1,&AttCnt1,&DATASET_attch));//new
						

						printf("\n Inside merging Report.....!!  %d  %d \n\n",AttCnt1,SpecCnt);fflush(stdout);


						Filename = (char*) MEM_alloc (sizeof(char) * (200));
						FilenamePath = (char*) MEM_alloc (sizeof(char) * (500));
						tc_strcpy(Filename,"");
						tc_strcpy(FilenamePath,"");


						
						//for (iA=0;iA<AttCnt;iA++)
						for (iAA=0;iAA<AttCnt1;iAA++)
						{
							dataset = DATASET_attch[iAA];
							//ITK_CALL(AE_ask_dataset_ref_count(DATASET_attch[iAA],&refnumfnd_A));
							ITK_CALL(AE_ask_dataset_ref_count(dataset,&refnumfnd_A1));//new
							printf("\n GRN  NMRef found......%d \n ",refnumfnd_A1);fflush(stdout);
							//for(jA=0;jAA<refnumfnd_A;jA++)
							for(jAA=0;jAA<refnumfnd_A1;jAA++)//new
							{
								//TK_CALL(AE_find_dataset_named_ref(DATASET_attch[iA],jA,refname,&reftypeAttach,&refobjectAttach));
								ITK_CALL(AE_find_dataset_named_ref2(dataset,jAA,&refname,&reftypeAttach,&refobjectAttach));//new
								ITK_CALL(IMF_ask_original_file_name2(refobjectAttach,&orig_nameAttach));

								
							
								//printf("\n original_file_name......%s \n ",orig_nameAttach);fflush(stdout);
								printf("\t orig_name: ------------- [%s]\n",orig_nameAttach); fflush(stdout);

								tc_strcat(Filename,orig_nameAttach);
								//tc_strcat(Filename,"^");

								IMF_ask_file_pathname2(refobjectAttach,SS_UNIX_MACHINE,&relative_path);
								printf("\n relative_path=%s\n",relative_path);

								tc_strcat(FilenamePath,relative_path);
								//tc_strcat(FilenamePath,"^");

								GRNflag=1;
							}
							
						}
					}
				}
				printf("\n XXXXXX  Filename,FilenamePath=%s    %s\n",FilenamePath,Filename);
				//RMDVDetails(TestReqRefNos,TestReqNos,GrnObjNos,Filename,FilenamePath,FirObjNos,FilenameFIR,FilenamePathFIR);

				if(FIRflag == 1)
				{
					RMDVDetails(TestReqRefNos,TestReqNos,Grnobjs,"NA","NA",Firobjs,FilenameFIR,FilenamePathFIR);
					printf("Fir Reports of %s is sent",TestReqNos);
				}
				else if(GRNflag ==1)
				{
					RMDVDetails(TestReqRefNos,TestReqNos,Grnobjs,Filename,FilenamePath,Firobjs,"NA","NA");
                    printf("Green Reports of %s is sent",TestReqNos);
				}
			}
			

		}
		else
		{
			printf(  "\n\n\nNO FIR/Green Report released \n");
		}
	}
	//fclose(inFptr);

	ITK_exit_module(true);
	return ITK_ok;
}

	

