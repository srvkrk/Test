/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* Author		  : Priyanka Panda
* Created on	  : Jul 02, 2023
*  Module		 :  MBOM /APL 
*  Code			 :  gm_dml_status_update.c
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <tc/folder.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/tc_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <epm/epm_task_template_itk.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <pie/pie.h>
#include <cfm/cfm.h>
#include <qry/qry.h>
#define Debug TRUE
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); Debug("line %d (ifail %d)\n", __LINE__, ifail);}



char* subString_mbom1 (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

int	gm_dml_DR_Update(tag_t DMLTag)
{
	char			*type_name		 = NULL;
	char			*type_Tsk_name		 = NULL;
	int				error_code		 = ITK_ok;
	int             ifail			 = 0;		
	//char    type_name[TCTYPE_name_size_c+1];
	char	*item_id				= NULL;
	char	*DML_no					= NULL;
	char	*ecntypeVal				= NULL;
	char	*DMLFrmToDR				= NULL;
	char	*ToPlnt					= NULL;
	char	*FromPlnt				= NULL;
	char	*Part_no				= NULL;
	char	*Tsk_id					= NULL;
	
	int		TaskCnt					=	0;
	int		count					=	0;
	int		CMRefcount				=	0;
	int		Mstr					=	0;
	
	
	tag_t   APLTaskRevT         = NULLTAG;
	tag_t   objTypeTag			= NULLTAG;
	tag_t   objTypeTskTag			= NULLTAG;
	tag_t 	relation_type       = NULLTAG;
	tag_t 	tsk_Sol_rel_type    = NULLTAG;
	tag_t 	tsk_CMR_rel_type    = NULLTAG;
	tag_t	*TaskRevision		= NULLTAG;
	tag_t	*TaskCMRef			= NULLTAG;
	tag_t	Assytag				= NULLTAG;
	tag_t	AssyCmRtag				= NULLTAG;

	printf("\n **************inside priyanka apl_dml_DR_Update***************\n ");fflush(stdout);
	if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	printf("\n type_name : %s",type_name);fflush(stdout);
	ITKCALL(AOM_ask_value_string( DMLTag,"item_id", &item_id));
	printf("\n item_id : %s",item_id);fflush(stdout);

	if(((strcmp(type_name,"T5_MBOMDMLRevision")==0) && (tc_strstr(item_id,"MM")!=NULL)) || (strcmp(type_name,"T5_APLDMLRevision")==0))
	{
		   
			 printf("\n inside class T5_MBOMDMLRevision/T5_APLDMLRevision......\n");fflush(stdout);

			if (strcmp(type_name,"T5_MBOMDMLRevision")==0)
			{
			ITKCALL(AOM_ask_value_string( DMLTag, "t5_MBOMRlzType", &ecntypeVal));
			}

			if (strcmp(type_name,"T5_APLDMLRevision")==0)
			{
			ITKCALL(AOM_ask_value_string( DMLTag, "t5_EcnType", &ecntypeVal));
			}
			
			printf("\n inside class T5_MBOMDMLRevision......ecntypeVal : %s\n",ecntypeVal);fflush(stdout);

			if (tc_strcmp(ecntypeVal,"GM_MMDML")==0 || (tc_strcmp(ecntypeVal,"TODRAPL")==0))
				{
					ITKCALL(AOM_ask_value_string(DMLTag,"t5_PlntToPlnt",&DMLFrmToDR));
					printf("\n\t DMLFrmToDR is :%s",DMLFrmToDR); fflush(stdout);

							if(DMLFrmToDR!=NULL)
							{
								
								FromPlnt=subString_mbom1(DMLFrmToDR, 0, 3);
								if (tc_strstr(DMLFrmToDR,"3P")!=NULL)
								{
									ToPlnt=subString_mbom1(DMLFrmToDR, 7, 4);
								}
								else
								{
									ToPlnt=subString_mbom1(DMLFrmToDR, 7, 3);
								}
							}
							printf("\n GM000: FromDR:[%s] ToDR:[%s]\n",FromPlnt,ToPlnt);fflush(stdout);
							ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&relation_type));
							if (relation_type != NULLTAG)
							{
							printf("\n\t rELATION FOUND "); fflush(stdout);
							ITKCALL(GRM_list_secondary_objects_only(DMLTag,relation_type,&count,&TaskRevision));
							printf("\n\n\t\t APL DML Create to Task11111111 : %d",count);fflush(stdout);
								
									for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
									{
										APLTaskRevT = TaskRevision[TaskCnt];

										ITKCALL(TCTYPE_ask_object_type(APLTaskRevT,&objTypeTskTag));
										ITKCALL(TCTYPE_ask_name2(objTypeTskTag,&type_Tsk_name));

										ITKCALL(AOM_ask_value_string( APLTaskRevT,"item_id", &Tsk_id));
										ITKCALL(GRM_find_relation_type("CMHasSolutionItem", &tsk_Sol_rel_type)); 
										if (tsk_Sol_rel_type != NULLTAG)
										{

											ITKCALL(GRM_list_secondary_objects_only(APLTaskRevT,tsk_Sol_rel_type,&CMRefcount,&TaskCMRef));
											printf("\n APL GM DML: part in Solution: %d",CMRefcount);fflush(stdout);
											if(CMRefcount > 0)
											{
												Mstr	=	0;
												for(Mstr=0;Mstr<CMRefcount;Mstr++)
												{
													char* Part_dr	= NULL;
													AssyCmRtag = NULLTAG;
													AssyCmRtag=TaskCMRef[Mstr];
													ifail = AOM_ask_value_string(AssyCmRtag,"item_id",&Part_no);
													ifail = AOM_ask_value_string(AssyCmRtag,"t5_PartStatus",&Part_dr);
													printf("\n GM:CMRPart no:%s AND %s",Part_no,Part_dr);fflush(stdout);

													ITKCALL(AOM_lock(AssyCmRtag));
													printf("\n GM:CMRPart no33333swq:%s",Part_no);fflush(stdout);

													ITKCALL(AOM_UIF_set_value(AssyCmRtag,"t5_PartStatus",ToPlnt));
													printf("\n GM:CMRPart status:%s",ToPlnt);fflush(stdout);
													//ITKCALL( AOM_save(AssyCmRtag) );
													ITKCALL( AOM_save_without_extensions(AssyCmRtag) );
													printf("\n GM:CMRPart no:%s",ToPlnt);fflush(stdout);
													ITKCALL( AOM_unlock(AssyCmRtag) );
													//printf("\n GM:Part no33333000:%s",ToPlnt);fflush(stdout);
													

												}
											}
										}

										//venkat
										// confirmation Required if part DR Status already higer the DML as of now code irrespective of DR status considered
										ITKCALL(GRM_find_relation_type("CMReferences", &tsk_CMR_rel_type)); 
										if (tsk_CMR_rel_type != NULLTAG)
										{	
											CMRefcount = 0;
											TaskCMRef	= NULLTAG;

											ITKCALL(GRM_list_secondary_objects_only(APLTaskRevT,tsk_CMR_rel_type,&CMRefcount,&TaskCMRef));
											printf("\n APL GM DML: part in CMReferences: %d",CMRefcount);fflush(stdout);
											if(CMRefcount > 0)
											{
												Mstr	=	0;
												for(Mstr=0;Mstr<CMRefcount;Mstr++)
												{
													char* Part_dr	= NULL;
													Assytag=TaskCMRef[Mstr];
													ifail = AOM_ask_value_string(Assytag,"item_id",&Part_no);
													ifail = AOM_ask_value_string(Assytag,"t5_PartStatus",&Part_dr);
													printf("\n GM:Part no:%s AND %s",Part_no,Part_dr);fflush(stdout);

													ITKCALL(AOM_lock(Assytag));
													printf("\n GM:Part no33333swq:%s",Part_no);fflush(stdout);

													ITKCALL(AOM_UIF_set_value(Assytag,"t5_PartStatus",ToPlnt));
													printf("\n GM:Part no updated1111111111:%s",ToPlnt);fflush(stdout);
													//ITKCALL( AOM_save(Assytag) );
													ITKCALL( AOM_save_without_extensions(Assytag) );
													printf("\n GM:Part no33333090:%s",ToPlnt);fflush(stdout);
													ITKCALL( AOM_unlock(Assytag) );
													printf("\n GM:Part no33333000:%s",ToPlnt);fflush(stdout);
													//ITKCALL(AOM_refresh(Assytag,0));
													
													
													//printf("\n GM:Part Status updated:%s,%s",Part_no,ToPlnt);fflush(stdout);

												}
											}
										}

										//second method
										printf("\n\n\t\t APL DML Create to Task_Second method : %d",count);fflush(stdout);

										char *Fld_Des_tsk=NULL;
										Fld_Des_tsk=(char *) MEM_alloc(50);
										
										
										tc_strcpy(Fld_Des_tsk,"");
										tc_strcat(Fld_Des_tsk,"*");
										tc_strcat(Fld_Des_tsk,Tsk_id);
										tc_strcat(Fld_Des_tsk,"*");
										printf("\n folderTASK description %s",Fld_Des_tsk);fflush(stdout);
										WSO_search_criteria_t  	criteria;
										int Flder_found=0;
										tag_t *list_of_WSO_tags=NULLTAG;
										int fldF=0;
										tag_t FoldertagItem = NULLTAG;
										int n_refs=0;
										int *levels;
										tag_t *referencers;
										char **relations=NULL;
										int cnt=0;
										tag_t objTypeRefTag=NULLTAG;
										char type_name_ref[TCTYPE_name_size_c+1];
										
										WSOM_clear_search_criteria(&criteria);
										strcpy(criteria.name,"Parts For Gate Maturation");
										strcpy(criteria.desc,Fld_Des_tsk);
										ITKCALL( WSOM_search(criteria, &Flder_found, &list_of_WSO_tags));
										printf("\nNumber of Parts For Gate Maturation folders found are %d\n",Flder_found);fflush(stdout);
										if (Flder_found>0)
										{
											
											char			*FldrName					=	NULL;
											tag_t			*FolderObj_tagF				=	NULLTAG;
											int				FlderSize					=	0;
											int				FlderObjCountF				=	0;
											int				fld							=	0;
											
											ITKCALL(FL_ask_references(list_of_WSO_tags[0],FL_fsc_by_date_modified ,&FlderObjCountF,&FolderObj_tagF));
											printf("\n GMD:FlderObjCountF is..:   %d\n",FlderObjCountF);fflush(stdout);
										
										
											
											for (fldF=0;fldF<FlderObjCountF;fldF++)
											{
												char	*PartMstr_noF		=	NULL;
												char	*Prtrev_iddF			=	NULL;
												char	*fPrtDRstF			=	NULL;
												char	*fPrtDRstF1			=	NULL;
												char	*fPrtTypeF			=	NULL;
												
												ITKCALL(AOM_ask_value_string(FolderObj_tagF[fldF],"item_id",&PartMstr_noF));
												ITKCALL(AOM_UIF_ask_value(FolderObj_tagF[fldF], "item_revision_id", &Prtrev_iddF));
												ITKCALL(AOM_ask_value_string(FolderObj_tagF[fldF],"t5_PartStatus",&fPrtDRstF));
												ITKCALL(AOM_ask_value_string(FolderObj_tagF[fldF],"t5_PartType",&fPrtTypeF));
												printf("\n GMD:PartMstr_noF %s Prtrev_iddF:%s fPrtDRstF : %s fPrtTypeF : %s", PartMstr_noF,Prtrev_iddF,fPrtDRstF,fPrtTypeF);fflush(stdout);

												ITKCALL(AOM_lock(FolderObj_tagF[fldF]));
												
												ITKCALL(AOM_UIF_set_value(FolderObj_tagF[fldF],"t5_PartStatus",ToPlnt));
												printf("\n folder GM:Part no33333:%s",ToPlnt);fflush(stdout);
												//ITKCALL( AOM_save(FolderObj_tagF[fldF]) );
												ITKCALL( AOM_save_without_extensions(FolderObj_tagF[fldF]) );
												
												printf("\nfolder GM:Part no33333090:%s",ToPlnt);fflush(stdout);
												ITKCALL( AOM_unlock(FolderObj_tagF[fldF]) );
												printf("\n folder GM:Part :%s",ToPlnt);fflush(stdout);
														
											}
										}
										else
										{
											printf("\nFolder Not Available~");fflush(stdout);
										}

									}
							
				}
				}else{
					printf("\n No GMDML......\n");fflush(stdout);
					
	}

				
	}else{
					printf("\n No proper class T5_MBOMDMLRevision......\n");fflush(stdout);
					
	}

}



extern int ITK_user_main (int argc, char ** argv )
{
	tag_t	dml_tag					=	NULLTAG;
	tag_t	dml_rev_tag				=	NULLTAG;
	

	char	*req_item		=	NULL;
	char	*cUserName		=	NULL;
	char	*cPassWord		=	NULL;
	char	*cUserGrp		=	NULL;

	
	cUserName		=	ITK_ask_cli_argument("-u=");
	cPassWord		=	ITK_ask_cli_argument("-p=");
	cUserGrp		=	ITK_ask_cli_argument("-g=");
	req_item	    =   ITK_ask_cli_argument("-i=");

	

	 ITKCALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	 ITKCALL(ITK_set_journalling( TRUE ));
	 ITKCALL(ITK_init_module(cUserName,cPassWord,cUserGrp));
	 ITKCALL(ITEM_find_item( req_item, &dml_tag ));

	if (dml_tag != NULLTAG)
	{
		ITKCALL(ITEM_ask_latest_rev(dml_tag,&dml_rev_tag)) ;
		gm_dml_DR_Update(dml_rev_tag);
	}
	else
	{
		printf("\nNo DML found, please enter valid DML Number");fflush(stdout);
	}
	return 0;
}
;