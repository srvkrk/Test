#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
//#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>

int cnt = 0;
int cntFlag = 0;
int cntSVRFlag = 0;

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}


char* subStringCKD (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

static int t5UpdateLifecycleStateCKD(tag_t object_tag, char* lifecycleStateName,char* lcstoremove)
{
	int n_values_checkin	= 0;
	int cunt1				= 0;
	int flag				= 0;
	int	ifail				= 0;
	int st_count1			= 0;
	int	st_count_1			= 0;
	int	DMLFlag				= 0;

	date_t*	start_end_date	= NULL;
	
	date_t	test_date_1;
	date_t	test_date_2;
	
    char*	value					=NULL;
	char	cNextDate[20]={0};

	char*	class_name		= NULL;
	char*	Release_Status	= NULL;
	char*	WSO_Name		= NULL;

	tag_t		class_id					= NULLTAG;
	tag_t		tReleaseStatusList_checkin	= NULLTAG;
	tag_t*		attr_tags_checkin			= NULLTAG;
	tag_t		status_rel					= NULLTAG;
	tag_t*		status_list1				= NULLTAG;
	tag_t    	propEff_tag				    = NULLTAG;
	tag_t		eff_d						= NULLTAG;
	tag_t*		status_list_1				= NULLTAG;

	logical		*is_it_null_checkin		=   NULL;
	logical		*is_it_empty_checkin	=   NULL;
	logical		log1;
	logical		checkout1;
	logical		retain							= 0;
	logical		stat;

	printf("\n Ketan Inside t5UpdateLifecycleStateCKD => [%s] || lcstoremove => [%s]\n",lifecycleStateName,lcstoremove);fflush(stdout);

	ITK_CALL(POM_class_of_instance(object_tag,&class_id));
	ITK_CALL(POM_name_of_class(class_id,&class_name));
	printf("\n class_name is :%s\n",class_name);fflush(stdout);

	ITKCALL(WSOM_ask_release_status_list(object_tag,&st_count_1,&status_list_1));
	printf("\n st_count1 :%d is\n",st_count_1);fflush(stdout);
	
	if(st_count_1>0)
	{
		for (cnt=0;cnt< st_count_1;cnt++ )
		{
			WSO_Name=NULL;
			ITKCALL(AOM_ask_name(status_list_1[cnt],&WSO_Name));
			printf("\n ppWSO_Name is :%s\n",WSO_Name);fflush(stdout);
			if(tc_strcmp(WSO_Name,"")!=0)
			{
				if (tc_strcmp(WSO_Name,lifecycleStateName)==0)
				{
					printf("\n Test 0 \n");fflush(stdout);
					DMLFlag = 1;
				}
			}
		}
	}

	//if(DMLFlag == 0)
	if((strcmp(lcstoremove,"NA")==0 && DMLFlag == 0))
	{
		printf("\n Test 1 \n");fflush(stdout);
		if (RELSTAT_create_release_status(lifecycleStateName,&status_rel));
		if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
	}
	else
	{
		printf("\n Test 2 \n");fflush(stdout);
		ITK_CALL(POM_class_of_instance(object_tag,&class_id));
		ITK_CALL(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList_checkin));fflush(stdout);
		ITK_CALL(WSOM_ask_release_status_list(object_tag,&st_count1,&status_list1));
		printf("\n st_count1 :%d is\n",st_count1);fflush(stdout);

		ITK_CALL(POM_unload_instances (1,&object_tag));
		ITK_CALL(POM_load_instances(1,&object_tag,class_id,1));
		ITK_CALL(POM_is_loaded(object_tag,&log1));

		if(log1 == 1)
		{
			printf(" Load Success\n " );
		}
		else
		{
			printf("Load Failure\n"  );
		}

		ITK_CALL( POM_length_of_attr(object_tag, tReleaseStatusList_checkin, &n_values_checkin) );
		printf("\n n_values is :%d\n",n_values_checkin);fflush(stdout);

		if(n_values_checkin>0)
		{
			ITK_CALL( POM_ask_attr_tags(object_tag, tReleaseStatusList_checkin, 0, n_values_checkin, &attr_tags_checkin, &is_it_null_checkin, &is_it_empty_checkin ));
			printf("\n n_values11 is :%d\n",n_values_checkin);fflush(stdout);
			flag = 0;
			for (cunt1 =  0; cunt1 < n_values_checkin; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);
				if(AOM_ask_name(attr_tags_checkin[cunt1], &Release_Status));
			    printf("\n Release_Status changes done: for workspaceobject => [%s]\n", Release_Status);fflush(stdout);
			    printf("\n lifecycleStateName => [%s]\n", lifecycleStateName);fflush(stdout);

				if( (tc_strstr(lifecycleStateName,"T5_LcsStd")!=NULL) && (tc_strstr(lifecycleStateName,"Rlzd")!=NULL) )
		        {
					printf("\n Inside test 1 \n");fflush(stdout);
					if( (tc_strcmp(Release_Status,lcstoremove)==0))
					{
						printf("\n Inside Remove \n");fflush(stdout);
						ITK_CALL(POM_unload_instances (1,&object_tag));
						ITK_CALL(POM_load_instances(1,&object_tag,class_id,1));
						ITK_CALL(POM_is_loaded(object_tag,&log1));

						ITK_CALL(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
						printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

						ITK_CALL(POM_save_instances(1,&object_tag,1));

						ITK_CALL(POM_refresh_instances(1,&object_tag,class_id,2));

						ITK_CALL(AOM_lock(object_tag));

						ITK_CALL(AOM_save_without_extensions(object_tag));
						ITK_CALL(AOM_refresh(object_tag,1));
						ITK_CALL(AOM_unlock(object_tag));
						//PlantLCSFlag = "CAR";
					}
				}
			    
				if( (tc_strcmp(Release_Status,lifecycleStateName)==0))
				{
					printf("\n Test 3 \n");fflush(stdout);
					ITK_CALL(POM_unload_instances (1,&object_tag));
					ITK_CALL(POM_load_instances(1,&object_tag,class_id,1));
					ITK_CALL(POM_is_loaded(object_tag,&log1));

					//ITK_CALL(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,flag,1));
					ITK_CALL(POM_remove_from_attr(1,&object_tag,tReleaseStatusList_checkin,cunt1,1));
					printf("\n cunt 1 == 0 removedd is :%d\n",cunt1);fflush(stdout);

					ITK_CALL(POM_save_instances(1,&object_tag,1));

					ITK_CALL(POM_refresh_instances(1,&object_tag,class_id,2));

					ITK_CALL(AOM_lock(object_tag));

					ITK_CALL(AOM_save_without_extensions(object_tag));
					ITK_CALL(AOM_refresh(object_tag,1));
					ITK_CALL(AOM_unlock(object_tag));
					 //PlantLCSFlag = "CAR";
				}


			}

		}
		if (DMLFlag == 0)
		{
			printf("\n Test 4 \n");fflush(stdout);
			if(RELSTAT_create_release_status(lifecycleStateName,&status_rel));
			if(RELSTAT_add_release_status(status_rel,1,&object_tag,retain));
		}
	}

	// if(RELSTAT_create_release_status(lifecycleStateName, &status_rel));
    // if(RELSTAT_add_release_status(status_rel, 1, &object_tag, retain));

	
	/*
	char*	PreRevOnly			= NULL;
	char*	RevOnly				= NULL;
	char*	Part_Rev			= NULL;
	char*	Part_Rev_copy		= NULL;
	char*	Part_rev_Id			= NULL;
	char*	PlantLCSFlag		= NULL;
	char*	Part_clr_ind		= NULL;
	char*	Part_no				= NULL;
	char*	old_to_date			= NULL;
	char*	WSO_Name			= NULL;
	char cCurrentAccessDate[20]={0};

	const char *qry_entries[2];	// Multiple Item Queried Error
	const char *qry_values[2];	// Multiple Item Queried Error

	tag_t*	itemclassp			= NULLTAG;
	tag_t	item				= NULLTAG;
	tag_t*	rev_list			= NULL;
	tag_t	Leff_d				= NULLTAG;
	tag_t*	effectivities_tag	= NULL;
	tag_t*  status_list;
	
	int		Item_count      = 0;
	int     ii				= 0;
	int     RevFlag			= 0;
	int     PreRevFlag		= 0;
	int     st_count		= 0;
	int     iLCS			= 0;
	int     cntLcs			= 0;
	int		n_tags_found	= 0;
	int		jj 				= 0;
	int		n_effectivities = 0;
	int		n_dates		 	= 0;
    
	date_t	Ltest_date_1;
	date_t	Ltest_date_2;
	date_t*	Rel_start_end_values	= NULL;
	date_t*	Lstart_end_date			= NULL;

	logical date_is_valid;

	WSOM_open_ended_status_t  	open_ended_or_stock_out;

	//if ((tc_strcmp(class_name,"T5_APLDMLRevision")!=0) && (tc_strcmp(class_name,"T5_APLTaskRevision")!=0) && (tc_strcmp(class_name,"T5_EPARevision")!=0) && (tc_strcmp(class_name,"T5_EPATaskRevision")!=0))
	if (tc_strcmp(class_name,"Design_0_Revision_alt")==0 || tc_strcmp(class_name,"Design Revision")==0 || tc_strcmp(class_name,"T5_ClrPartRevision")==0 )
	{
		
		ITK_CALL(WSOM_ask_effectivity_mode(&stat));

		//	getCurrentDateTime(cCurrentAccessDate);
		ITK_CALL(PROP_ask_property_by_name(status_rel,"effectivity_text",&propEff_tag));
		ITK_CALL(PROP_ask_value_string(propEff_tag,&value));

		getNextDate(cNextDate);
		printf("\n cNextDate:%s",cNextDate);

		ITK_CALL(ITK_string_to_date(cNextDate, &test_date_1 ));
		ITK_CALL(ITK_string_to_date("31-Dec-9999 00:00", &test_date_2 ));

		start_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);

		printf( "\n Setting release date effectivity [to date - 12-Jun-2014 00:00 and from date - 12-Jun-2014 00:00]on ReleaseStatus object  \n");

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		ITK_CALL(WSOM_status_clear_effectivities (status_rel));
		ITK_CALL(WSOM_effectivity_create_with_dates(status_rel, NULLTAG, 2,start_end_date, EFFECTIVITY_closed, &eff_d ));
		ITK_CALL(AOM_save_without_extensions(eff_d));
		ITK_CALL(AOM_save_without_extensions(status_rel));
		ITK_CALL(AOM_refresh(status_rel,0));

         // Start Privious Rev and stamp the close date
		 ITK_CALL(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev));
		 ITK_CALL(AOM_ask_value_string(object_tag,"item_revision_id",&Part_Rev_copy));
		 printf("\n Part_Rev: %s", Part_Rev);fflush(stdout);
		 printf("\n Part_Rev_copy: %s", Part_Rev_copy);fflush(stdout);

		ITK_CALL(AOM_ask_value_string(object_tag,"item_id",&Part_no));
		printf("\n\n\t\t Part_no  is :%s",Part_no);	fflush(stdout);
		Part_clr_ind	=	NULL;
		ITK_CALL(AOM_ask_value_string(object_tag,"t5_ColourInd",&Part_clr_ind));
		printf("\n\n\t\t Part_clr_ind  is :%s",Part_clr_ind);	fflush(stdout);

		qry_entries[0] ="item_id";
		qry_entries[1] ="object_type";//Multiple Item Queried Error
		qry_values[0] = Part_no;
		if (tc_strcmp(Part_clr_ind,"C")==0)
		{
			qry_values[1] = "T5_ClrPart";//Multiple Item Queried Error Hemal
		}
		else
		{
			//qry_values[1] = "Design";//Multiple Item Queried Error Hemal
			//Handle the different design child class.
			char	*designBORev		=	NULL;
			char	*designBO			=	NULL;
			tag_t	AssyTag			=	NULLTAG;
			//AssyTag=PartTags[k];
			printf("\nBefore getDesignType");fflush(stdout);
			getDesignType(object_tag, &designBORev,&designBO);
			printf("\nAfter getDesignType : %s",designBO);fflush(stdout);
			qry_values[1] = designBO;

		}//Multiple Item Queried Error
		//ITEM_find_items_by_key_attributes(1, qry_entries, qry_values,&n_tags_found, &itemclassp);
		ITEM_find_items_by_key_attributes(2, qry_entries, qry_values,&n_tags_found, &itemclassp);//Multiple Item Queried Error
		//ITKCALL(ITEM_find_item(Part_no,&itemclassp));
		item = itemclassp[0];

		ITK_CALL(ITEM_list_all_revs (item, &Item_count, &rev_list));
		printf("\n Eff:Total rev found: %d.", Item_count);fflush(stdout);
			if(Item_count > 0)
			{
				RevFlag = 0;
				PreRevFlag = 0;
				for(ii=Item_count-1;ii>=0;ii--)
				{
				   RevOnly = NULL;
				   PreRevOnly = NULL;
				   ITK_CALL(AOM_ask_value_string(rev_list[ii],"item_revision_id",&Part_rev_Id));
					printf("\n Part_Rev: %s\n",Part_Rev);fflush(stdout);
					printf("\n Part_rev_Id: %s\n",Part_rev_Id);fflush(stdout);
					if(tc_strcmp(Part_Rev,Part_rev_Id)==0)
					{
						RevFlag = 1;
					}
					printf("\n RevFlag : %d.", RevFlag);fflush(stdout);
					if(RevFlag == 1)
					{
					   RevOnly= strtok( Part_Rev_copy, ";" );
					   PreRevOnly= strtok( Part_rev_Id, ";" );
					   printf("\n RevOnly: %s\n",RevOnly);fflush(stdout);
					   printf("\n PreRevOnly: %s\n",PreRevOnly);fflush(stdout);
					   if(tc_strcmp(RevOnly,PreRevOnly)!=0)
						{
						  PreRevFlag = 1;
						}
					}
					printf("\n PreRevFlag : %d.", PreRevFlag);fflush(stdout);
					if(PreRevFlag == 1)
					{
						ITK_CALL(WSOM_ask_release_status_list(rev_list[ii],&st_count,&status_list));
						if(st_count == 0)
						{
						printf("\n NO LCS Found for part : %d\n",st_count);fflush(stdout);
						break;
						}
						else
						{
							for (iLCS=0;iLCS<st_count ;iLCS++ )
							{
									ITK_CALL(AOM_ask_value_string(status_list[iLCS],"object_name",&class_name));
									printf("\n class_name: %s\n",class_name);fflush(stdout);
									//if(tc_strcmp(PlantLCSFlag,"CAR")==0)
									//{
									if(tc_strcmp(class_name,lifecycleStateName)==0)
									{
										getCurrentDateTime(cCurrentAccessDate);
										printf("\n Eff:cCurrentAccessDate is..:[%s]",cCurrentAccessDate);fflush(stdout);
										if(ITK_ok != (ifail = ITK_string_to_date(cCurrentAccessDate, &Ltest_date_2 )))
										{
											return ifail;
										}
										if(ITK_ok != (ifail = WSOM_status_ask_effectivities (status_list[iLCS],&n_effectivities, &effectivities_tag) )) return ifail;
										printf("\n Eff:n_effectivities count:[%d] \n",n_effectivities);fflush(stdout);
										if(n_effectivities > 0)
										{
											for(jj=0;jj<n_effectivities;jj++)
											{
												if(ITK_ok != (ifail = WSOM_effectivity_ask_dates(effectivities_tag[jj],&n_dates,&Rel_start_end_values,&open_ended_or_stock_out )))return ifail;
												printf("\n Eff:no of Rel_start_end_value:%d\n", n_dates);fflush(stdout);
												if(n_dates > 0)
												{
													if(ITK_ok != (ifail = DATE_date_to_string(Rel_start_end_values[0],"%d-%b-%Y %H:%M", &old_to_date )))
													{
														return ifail;
													}
													printf("\n Eff:old_to_date:[%s] ",old_to_date);fflush(stdout);
													if(ITK_ok != (ifail = DATE_string_to_date_t(old_to_date, &date_is_valid,&Ltest_date_1 )))
													{
														return ifail;
													}
													printf(" and  DATE_string_to_date_t..\n");fflush(stdout);
													if(date_is_valid != true)
													{
														printf("\n EFF1:date_is_valid is not true .....");fflush(stdout);
													}
													else
													{
														printf("\n EFF1:date_is_valid is  true .....");fflush(stdout);
													}
												}
												else
												{
													printf("\n EFF1:NO Eff date available, so setting closure date....");fflush(stdout);
												}
											}
											
											// //
											// printf("\n KEtan update Value\n");fflush(stdout);
											// 
											// ITK_CALL(ITK_string_to_date("25-Jul-2023 00:00", &Ltest_date_1 ));
											// ITK_CALL(ITK_string_to_date("28-Jul-2023 00:00", &Ltest_date_2 ));
											// 
											// //
											Lstart_end_date = (date_t *)MEM_alloc(sizeof(date_t)*2);
											Lstart_end_date[0] = Ltest_date_1;
											Lstart_end_date[1] = Ltest_date_2;

											printf("\n ERCReview--EFF:Clearing effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = WSOM_status_clear_effectivities (status_list[iLCS])))
											{
												return ifail;
											}

											printf("\n ERCReview--EFF:Creating effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = WSOM_effectivity_create_with_dates(status_list[iLCS], NULLTAG, 2,Lstart_end_date, EFFECTIVITY_closed, &Leff_d )))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Saving effectivities...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_save_without_extensions(Leff_d)))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Saving Revision...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_save_without_extensions(status_list[iLCS])))
											{
												return ifail;
											}
											printf("\n ERCReview--EFF:Refreshing Revision...");fflush(stdout);
											if(ITK_ok != (ifail = AOM_refresh( status_list[iLCS], 0 )))
											{
												return ifail;
											}
										}
										
										break;

									}
							}
						printf("\n cntLcs inside : %d\n",cntLcs);fflush(stdout);
						break;
						}
					}  /// End Prev Rev  Flag Loop
				}
			} /// End Prev Rev

	}*/



	return 0;
}

void autoresizestrAdd_CKD(char **src,char* dest)
{
	// char * src = src1  ? src1  : " ";          /* allow NULL input(s) to be */
	char * desc = dest ? dest : "NA";
	//printf("\n autoresizestrAdd_CKD src len==%d",strlen(*src));
	//printf("\n autoresizestrAdd_CKD desc len==%d",strlen(desc));
	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
	// src = MEM_realloc(src, size_ab);
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
	tc_strcat(*src , desc);
}

void  get_CtrlVal_STDStateInf( char * Plt_Code ,char  APlRevwLC[40],char  AplWrkngLC[40],char  AplRlzdLC[40],char  StdWrkngLC[40],char  StdRlzdLC[40], char PlantLCFlag[40], char StdPlant[40], char StdRevRule[40], char StdCLosRule[40],char StdView[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *APlRevw 			= NULL;
	 char *AplWrkng			= NULL;
	 char *AplRlzd			= NULL;
	 char *StdWrkng			= NULL;
	 char *StdRlzd			= NULL;
	 char *Plant			= NULL;
	 char *stdCode			= NULL;
	 char *RevRule		= NULL;
	 char *stdClsRule		= NULL;
	 char *stdBvr			= NULL;
	 char *PlantOneChar		= NULL;
	 char *APLPlantName		= NULL;

	 char* viewtocpy		= NULL;
	 int max_char_size = 80;
	 viewtocpy = (char *)MEM_alloc(max_char_size * sizeof(char));

	printf("\n Plt_Code:%s",Plt_Code);fflush(stdout);
	PlantOneChar=subStringCKD(Plt_Code,3,1);
	printf("\n PlantOneChar:%s",PlantOneChar);fflush(stdout);
	tc_strcpy(viewtocpy,"");
	tc_strcat(viewtocpy,"STD");
	tc_strcat(viewtocpy,PlantOneChar);
	tc_strcat(viewtocpy," View");
	printf("\n View to copy:%s",viewtocpy);fflush(stdout);

		
	 char    *qry_entryCntrl2[3]  = {"SYSCD","Information-7","Delete Indicator"};	
	 char	**qry_valuesCntrl2= (char **) MEM_alloc(5 * sizeof(char *));	
	 int cntrlcnt2=0;
	 int  control_number_found2=0;
	 
	 tag_t *list_of_WSO_cntrl_tags2=NULLTAG;
	 //tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl2    = 3;	 

	 if(QRY_find2("Control Objects...", &qryTagCntrl1));

	 if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl2[0]="APLStateInf";
				qry_valuesCntrl2[1]=Plt_Code;
				qry_valuesCntrl2[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl2, qry_entryCntrl2, qry_valuesCntrl2, &control_number_found2, &list_of_WSO_cntrl_tags2));
			}
			else
			{
				printf("\n Control Object Query not Found  \n");fflush(stdout);
			}	
			
			printf("\n control_number_found2 is : %d\n",control_number_found2);fflush(stdout);

			if(control_number_found2>0)
			{
				
						AOM_ask_value_string( list_of_WSO_cntrl_tags2[0], "t5_SubSyscd", &APLPlantName);
						printf("\n APLPlantName: %s\n",APLPlantName);fflush(stdout);
			}
	 

	 
	 
	 //if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (APLPlantName)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLStateInf";
				qry_valuesCntrl1[1]=APLPlantName;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &APlRevw);
				printf("\n APlRevw: %s\n",APlRevw);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &AplWrkng);
				printf("\n AplWrkng: %s\n",AplWrkng);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &AplRlzd);
				printf("\n AplRlzd: %s\n",AplRlzd);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &StdWrkng);
				printf("\n StdWrkng: %s\n",StdWrkng);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo5", &StdRlzd);
				printf("\n StdRlzd: %s\n",StdRlzd);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo6", &Plant);
				printf("\n Plant: %s\n",Plant);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo7", &stdCode);
				printf("\n stdCode: %s\n",stdCode);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &RevRule);
				printf("\n RevRule: %s\n",RevRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo9", &stdClsRule);
				printf("\n stdClsRule: %s\n",stdClsRule);fflush(stdout);

				//AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo10", &stdBvr);
				//printf("\n stdBvr: %s\n",stdBvr);fflush(stdout);

							
				if(tc_strlen(APlRevw)>0) 
				{ 
					tc_strcpy(APlRevwLC,APlRevw);
				}
				if(tc_strlen(AplWrkng)>0) 
				{ 
					tc_strcpy(AplWrkngLC,AplWrkng);
				}
				if(tc_strlen(AplRlzd)>0) 				
				{
					tc_strcpy(AplRlzdLC,AplRlzd);
				}
				if(tc_strlen(StdWrkng)>0) 
				{
					tc_strcpy(StdWrkngLC,StdWrkng);
				}
				if(tc_strlen(StdRlzd)>0) 
				{
					tc_strcpy(StdRlzdLC,StdRlzd);
				}
				if(tc_strlen(Plant)>0) 
				{
					tc_strcpy(PlantLCFlag,Plant);
				}
				if(tc_strlen(stdCode)>0) 
				{
					tc_strcpy(StdPlant,stdCode);
				}
				if(tc_strlen(RevRule)>0) 
				{
					tc_strcpy(StdRevRule,RevRule);
				}
				if(tc_strlen(stdClsRule)>0) 
				{
					tc_strcpy(StdCLosRule,stdClsRule);
				}
				if(tc_strlen(viewtocpy)>0) 
				{
					tc_strcpy(StdView,viewtocpy);
				}
			}
			else
			{
				tc_strcpy(APlRevwLC,"T5_LcsAplReview");
				tc_strcpy(AplWrkngLC,"T5_LcsAPLWrkg");
				tc_strcpy(AplRlzdLC,"T5_LcsAplRlzd");
				tc_strcpy(StdWrkngLC,"T5_LcsSTDWrkg");
				tc_strcpy(StdRlzdLC,"T5_LcsStdRlzd");		
				tc_strcpy(PlantLCFlag,"CAR");
				tc_strcpy(StdPlant,"STDC");
				tc_strcpy(StdRevRule,"APLC Release and above");
				tc_strcpy(StdCLosRule,"BOMViewClosureRuleSTDC");
				tc_strcpy(StdView,viewtocpy);
			}
}

int ITK_user_main(int argc, char* argv[])
{

        int status = 0;
        int i;
        //int count;
		char*	inputuser			= NULL;
		char*	inputpwd			= NULL;
		char*	inputgrp			= NULL;
		char*	s					= NULL;
        char*	Input_CKD_DML       = NULL;
		char*	Input_PlantName     = NULL;

		tag_t	CKD_DMLNo					= NULLTAG;
		tag_t	CKD_DMLrev					= NULLTAG;
		
		printf("\n Inside Ketan Main Function for CKD DML Stamping\n");fflush(stdout);

		//inputuser	   = ITK_ask_cli_argument("-u=");
		//inputpwd	   = ITK_ask_cli_argument("-p=");
		//inputgrp	   = ITK_ask_cli_argument("-g=");
		//
		////ITK_CALL( ITK_init_module("infodba","APLinfo2020" ,"dba"));
		//
		//if (ITK_init_module(inputuser,inputpwd,inputgrp) == ITK_ok )
		//{

			ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
			ITK_CALL(ITK_auto_login());
			ITK_set_bypass(true);

			ITK_CALL(ITK_set_journalling(TRUE));
			if (status == 0 )
			{
				printf("\n loader login to Teamcenter successful");fflush(stdout);
			}
			else
			{
			  printf("\n Error code:%d",status);fflush(stdout);
			  EMH_ask_error_text(status,&s);
			  printf("\n Error message:%s",s);fflush(stdout);
			}

			Input_CKD_DML   = (char *) MEM_alloc(1 * sizeof(char *));
			Input_PlantName	= (char *) MEM_alloc(1 * sizeof(char *));

			autoresizestrAdd_CKD(&Input_CKD_DML,argv[3]);
			autoresizestrAdd_CKD(&Input_PlantName,argv[4]);

			printf("\n Input_CKD_DML :: %s ",Input_CKD_DML);fflush(stdout);
			printf("\n Input_PlantName :: %s ",Input_PlantName);fflush(stdout);

			printf("\n Test 2 \n");fflush(stdout);
			ITK_CALL(ITEM_find_item(Input_CKD_DML,&CKD_DMLNo));
			ITK_CALL(ITEM_ask_latest_rev(CKD_DMLNo,&CKD_DMLrev));

			tag_t	objTypeTag				= NULLTAG;
			tag_t	relation_type			= NULLTAG;
			tag_t*	TaskRevision			= NULLTAG;
			tag_t	TaskRevTag				= NULLTAG;
			tag_t*	PartTags				= NULLTAG;
			tag_t	tsk_part_sol_rel_type	= NULLTAG;
			tag_t	AssyTag					= NULLTAG;
			
			char*	type_name			= NULL;
			char*	object_type			= NULL;
			char*	TaskName			= NULL;
			char*	Part_no				= NULL;
			char*	lcsToset			= NULL;
			char*	lcsToremove			= NULL;
			
			int		count				= 0;
			int		TaskCnt				= 0;
			int		PartCnt				= 0;
			int		k					= 0;

			lcsToset	=(char *) MEM_alloc(20 * sizeof(char *));
			lcsToremove =(char *) MEM_alloc(20 * sizeof(char *));

			if(TCTYPE_ask_object_type(CKD_DMLrev,&objTypeTag));
			if(TCTYPE_ask_name2(objTypeTag,&type_name));
			printf("\n type_name changes done: for workspaceobject %s\n", type_name);fflush(stdout);

			if(strcmp(type_name,"T5_CkdDmlRevision")==0)
			{
					printf("\n inside class T5_CkdDmlRevision ......\n");fflush(stdout);
					
					char AplRvwLC[40];
					char AplWrkngLC[40];
					char AplRlzd[40];
					char Stdwrknglc[40];
					char Stdrlzdlc[40];
					char PltLcs[40];
					char StdPlant[40];
					char StdRevRule[40];
					char StdCLosRule[40];
					char StdView[40];

					get_CtrlVal_STDStateInf(Input_PlantName,AplRvwLC,AplWrkngLC,AplRlzd,Stdwrknglc,Stdrlzdlc,PltLcs,StdPlant,StdRevRule,StdCLosRule,StdView);//TZ1.46//Priti
					
					printf("\n Stdrlzdlc => %s \n",Stdrlzdlc);fflush(stdout);
					printf("\n Stdwrknglc => %s \n",Stdwrknglc);fflush(stdout);
					
					strcpy(lcsToset,Stdrlzdlc);
					strcpy(lcsToremove,Stdwrknglc);

					if (CKD_DMLrev != NULLTAG)
					{
						GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);

						GRM_list_secondary_objects_only(CKD_DMLrev,relation_type,&count,&TaskRevision);
						printf("\n CKD DML to Task : %d",count);fflush(stdout);

						for (TaskCnt=0;TaskCnt<count ;TaskCnt++ )
						{
							TaskRevTag = TaskRevision[TaskCnt];

							AOM_ask_value_string(TaskRevTag,"object_type",&object_type);
							printf("\n object_type is :%s",object_type);fflush(stdout);

							AOM_ask_value_string(TaskRevTag,"item_id",&TaskName);//TZ1.43
							printf("\n TaskName is :%s",TaskName);fflush(stdout);//TZ1.43


							if((strcmp(object_type,"T5_CKDTaskRevision")==0))
							{
								PartCnt=0;

								printf("\n CKD Task Stamping \n");fflush(stdout);
								status = t5UpdateLifecycleStateCKD(TaskRevTag, lcsToset, lcsToremove);

								AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&PartCnt,&PartTags);
								printf("\n CKD DML Task PartCnt: %d",PartCnt);fflush(stdout);

								if (PartCnt>0)
								{
									GRM_find_relation_type("CMHasSolutionItem",&tsk_part_sol_rel_type);
									for (k=0;k<PartCnt ;k++ )
									{
										printf("\n Part Count k =:%d",k);fflush(stdout);
										AssyTag=PartTags[k];

										AOM_ask_value_string(AssyTag,"item_id",&Part_no);
										printf("\n Part_no is :%s",Part_no);fflush(stdout);

										printf("\n Part Stamping \n");fflush(stdout);
										status = t5UpdateLifecycleStateCKD(AssyTag, lcsToset, lcsToremove);
									}
								}
							}
						}	 /// Solution Item end
						
					printf("\n CKD DML Stamping \n");fflush(stdout);
					status = t5UpdateLifecycleStateCKD(CKD_DMLrev, lcsToset, lcsToremove); 
				}
			}
			else
			{
			  	printf("\n No proper class class T5_CkdDmlRevision......\n");fflush(stdout);
			}
		
		printf("\n Ketan CKD DML Stamped Successfully \n");fflush(stdout);

		return 0;
    }
