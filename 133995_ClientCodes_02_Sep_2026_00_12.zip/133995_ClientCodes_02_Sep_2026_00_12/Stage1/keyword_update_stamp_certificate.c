//#include <string.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <string.h>


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

int			ifail 				= ITK_ok;

int read_value_from_file(char*,char*);
int Get_Qry_Execute(char*, char*, char*, char*, char*, char*,FILE*);


int ITK_user_main(int argc, char *argv[])
{

	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;
	char			* filename1					= NULL;

	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-f=");
	filename1       = ITK_ask_cli_argument("-f1=");
	
	
	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	ifail = read_value_from_file(Filename,filename1);



	    printf("\n*********************\n");
	    printf("\nEnd of program.....!!\n");
	    printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
int read_value_from_file(char* Filename,char* filename1)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;
	char 			*design_grp					= NULL;
	char 			*key_descp					= NULL;
    char *input_1	= NULL;
	char *input_2	= NULL;
	char *input_3	= NULL;
	char *input_4	= NULL;
	char 			temp[500];

input_1=(char *) MEM_alloc(100);
input_2=(char *) MEM_alloc(100);
input_3=(char *) MEM_alloc(100);
input_4=(char *) MEM_alloc(100);
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	FILE* fp1 = NULL;
	
	          fp1 = fopen(filename1,"a+");
	          fprintf(fp1,"Design group,keyword Description,ex_2\n");
	if (fp != NULL)
	{
		while (fgets(temp, 500, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				design_grp = strtok(temp,"^");
				printf("\nDesign_group:%s",design_grp);

                input_1 = strtok(NULL,"^");
				printf("\ninput_1:%s",input_1);

				input_2 = strtok(NULL,"^");
				printf("\ninput_2:%s",input_2);

                input_3 = strtok(NULL,"^");
				printf("\ninput_3:%s",input_3);

				input_4 = strtok(NULL,"^");
				printf("\ninput_4:%s",input_4);

				key_descp = strtok(NULL,"^");
				printf("\nKeyword description:%s",key_descp);
								
				ifail = Get_Qry_Execute(design_grp, key_descp,input_1,input_2,input_3,input_4,fp1);
              
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	

	      /*  if(input_1)  MEM_free(input_1);
			if(input_2)  MEM_free(input_2);
			if(input_3)  MEM_free(input_3);
			if(input_4)  MEM_free(input_4);
			*/
             fclose(fp1);
			 fclose(fp);
	return ifail;
}

int Get_Qry_Execute(char* design_grp, char* key_descp,char *input_1,char *input_2,char *input_3,char *input_4,FILE* fp1)
{
		int ifail           = ITK_ok;
		tag_t KWDescQry     = NULLTAG;
	    tag_t *moduleTags   = NULL;
		char *sModuleInfo	= NULL;
		char *sModuleInfo_2	= NULL;
	    char *tok_value1	= NULL;
	    char *tok_value2	= NULL;
	    char *tok_value3	= NULL;
	    char *tok_value4	= NULL;
		int modCount=0;
		int Entry_count=2;
		


char *Entries[2] = {"Name","ext_1"};
char **Values = (char **) MEM_alloc(50 * sizeof(char *));
sModuleInfo=(char *) MEM_alloc(100);
sModuleInfo_2=(char *) MEM_alloc(100);
tok_value1=(char *) MEM_alloc(100);
tok_value2=(char *) MEM_alloc(100);
tok_value3=(char *) MEM_alloc(100);
tok_value4=(char *) MEM_alloc(100);
Values[0] = key_descp;
Values[1] = design_grp;

                printf("\nvalue_0:%s",key_descp);
                printf("\nvalue_1:%s",design_grp);
   ifail=QRY_find("QryKyWrd_iDsgGrp_oClsfObj", &KWDescQry);

	    
		if (KWDescQry)
		{ QRY_execute(KWDescQry, Entry_count, Entries, Values, &modCount, &moduleTags);}

		        printf("\nModule Object Found : %d", modCount);fflush(stdout);

		if(modCount>0)
		{
			AOM_ask_value_string(moduleTags[0],"ext_2",&sModuleInfo);

			tok_value1 = tc_strtok(sModuleInfo,",");

			printf("\ntok_value1 : %s",tok_value1);fflush(stdout);

			tok_value2 = tc_strtok(NULL,",");

			printf("\ntok_value2 : %s",tok_value2);fflush(stdout);

			tok_value3 = tc_strtok(NULL,",");
                     
			printf("\ntok_value3 : %s",tok_value3);fflush(stdout);

			tok_value4 = tc_strtok(NULL,",");

			printf("\ntok_value4 : %s",tok_value4);fflush(stdout);
             
  if( tc_strcmp(stripBlanks(tok_value1), NULL) ==0||tc_strcmp(stripBlanks(tok_value1), "") ==0||tc_strcmp(stripBlanks(tok_value1), "-") ==0)
			{
                tok_value1=(char *) MEM_alloc(100);
                
                tc_strcpy(tok_value1,input_1);

			}

        if( tc_strcmp(stripBlanks(tok_value2), NULL) ==0||tc_strcmp(stripBlanks(tok_value2), "") ==0||tc_strcmp(stripBlanks(tok_value2), "-") ==0)
			{

               
                tok_value2=(char *) MEM_alloc(100);
                
                tc_strcpy(tok_value2,input_2);

			}

		if( tc_strcmp(stripBlanks(tok_value3), NULL) ==0||tc_strcmp(stripBlanks(tok_value3), "") ==0||tc_strcmp(stripBlanks(tok_value3), "-") ==0)
			{

                tok_value3=(char *) MEM_alloc(100);
                
                tc_strcpy(tok_value3,input_3);
                         
			}
             
		if((tc_strcmp(stripBlanks(tok_value4), NULL) ==0)||(tc_strcmp(stripBlanks(tok_value4), "") ==0)||( tc_strcmp(stripBlanks(tok_value4), "NA") ==0)||( tc_strcmp(stripBlanks(tok_value4), "-") ==0) )
			{
			
			    tok_value4=(char *) MEM_alloc(100);
                                    
			    tc_strcpy(tok_value4,input_4);

			}
		                       
			    tc_strcpy(sModuleInfo_2,stripBlanks(tok_value1));
			    tc_strcat(sModuleInfo_2,",");
			    tc_strcat(sModuleInfo_2,stripBlanks(tok_value2));
			    tc_strcat(sModuleInfo_2,",");
			    tc_strcat(sModuleInfo_2,stripBlanks(tok_value3));
			    tc_strcat(sModuleInfo_2,",");
			    tc_strcat(sModuleInfo_2,stripBlanks(tok_value4));

				printf("\nModuleInfo_2 : %s \n",sModuleInfo_2);fflush(stdout);

		
			  ifail = AOM_refresh (moduleTags[0], 1);

	            ifail = AOM_UIF_set_value (moduleTags[0], "ext_2", sModuleInfo_2);
	
	            ifail = AOM_save (moduleTags[0]);

	            ifail = AOM_refresh (moduleTags[0], 0);
				
				ifail=AOM_ask_value_string(moduleTags[0],"ext_2",&sModuleInfo);
			 
				
			   //printf("\nModuleInfo : %s \n",sModuleInfo);fflush(stdout);
			   
			   fprintf(fp1,"%s,%s,%s\n",design_grp,key_descp,sModuleInfo_2);
	            
	    }
		else
			{
                 
				 printf("\nModule not found with given input\n");fflush(stdout);
				 
			}

		 if(sModuleInfo) { MEM_free(sModuleInfo); }
       

       /* 
	    if(tok_value1) { free(tok_value1);}
		if(tok_value2) { MEM_free(tok_value2); } 
        if(tok_value3) { MEM_free(tok_value3); }
        if(tok_value4) { MEM_free(tok_value4); }
        
		 if(sModuleInfo_2) { MEM_free(sModuleInfo_2); }*/
		
       
			
              return ifail;
			  
}

