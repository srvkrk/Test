/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
* *------------------------------------------------------------------------------
** Filename		:cvbumatrixrep.c
*
* Description		: > This Utility is to do unit testing of functions .
* Module  		        
* Since		    :    

* ENVIRONMENT		:    C++, ITK

*
* History

*------------------------------------------------------------------------------
* Date         	 Name						Description of Change
* 05/03/2021   	Sanjoy Mondal			    Initial Code
* 23/10/2024	Sanjoy Mondal				Change according to 14.3
* 09/06/2025	Sanjoy Mondal				Remove the Obsolete Vehicle from the list
* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
//#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
//#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
//#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>        //Added by Vishal to expand BOM
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
//#include <tccore/libtccore_exports.h>
#include <tccore/aom_prop.h>
#include <ics/ics.h>
#define MAX_LINE_LEN 1024

#define ITK_err 910001
/*
#define ITKCALL( argument )                                             \
{                                                                       \
    int retcode = argument;                                             \
    if ( retcode != ITK_ok ) {                                          \
        char* s;                                                        \
        printf( " "#argument "\n" );                                    \
        printf( "  returns [%d]\n", retcode );                          \
        EMH_ask_error_text (retcode, &s);                               \
        printf( "  Teamcenter ERROR: [%s]\n", s);           \
        printf( "  in file ["__FILE__"], line [%d]\n\n", __LINE__ );    \
        if (s != 0) MEM_free (s);                                       \
    }                                                                   \
}*/
#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}



//Function start
void setAddTagObj(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}


void t5AddTagObjToSet(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddTagObj1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		//printf("\n ****setAddTagObj2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

/* Function to add string into a set of string */
void t5AddStrToSet(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}

void t5FindStrInSet(char **str_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(str_list[k],str)==0)
		{
			*found=1;
			break;
		}

	}
}

///CODE START HERE
int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3, &n_tags_foundd3, &tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		//printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		//printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;	
}

int getItemRevObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Item ID";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("Item Revision...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:tm_createCedCoatedParts: getItemRevObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}



int getGeneralObject(char *partNumber, char *object_type, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObj = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	//printf("\n\n object_type ===> [%s]\n",object_type);fflush(stdout);
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Name";
	
	qry_values[0] = object_type;
	qry_values[1] = partNumber;
		
	CALLAPI(QRY_find2("General...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObj));
	printf("\n SAN:tm_createCedCoatedParts: getGeneralObject: count==>%d\n", count);fflush(stdout);

	if(count>0)
	{
		*tcPart = itemObj[count-1];
	}
	
	return ifail;
}


void setAddInt(int *count,int **objlist,int obj )
{

	*count=*count+1;
	if(*count==1)
	{
		//printf("\n ****setAddInt1");fflush(stdout);
		(*objlist) = (int *)malloc((*count ) * sizeof(int ));
	}
	else
	{
		//printf("\n **setAddInt2");fflush(stdout);
		(*objlist) = (int *)realloc((*objlist),(*count ) * sizeof(int ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));


}


void setFindInt(int *int_list,int count,int in,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(int_list[k]== in)
		{
			*found=1;
			break;
		}

	}
}


void setFindTagInSet(tag_t *objlist,tag_t obj,int count,int *found)
{
	int k=0;
	*found=-1;
	for(k=0;k<count;k++)
	{		
		if(objlist[k]==obj)
		{
			*found=k;
			break;
		}
	}
}




void  getcurentMonth( int m ,char cMonth[30])
{
      if(m==1)
	  {
		tc_strcpy(cMonth,"Jan");
	  }
	  else if(m==2)
	  {
		tc_strcpy(cMonth,"Feb");
	  }
	  else if(m==3)
	  {
		tc_strcpy(cMonth,"Mar");
	  }
	  else if(m==4)
	  {
		tc_strcpy(cMonth,"Apr");
	  }
	  else if(m==5)
	  {
		tc_strcpy(cMonth,"May");
	  }
	  else if(m==6)
	  {
		tc_strcpy(cMonth,"Jun");
	  }
	  else if(m==7)
	  {
		tc_strcpy(cMonth,"Jul");
	  }
	  else if(m==8)
	  {
		tc_strcpy(cMonth,"Aug");
	  }
	  else if(m==9)
	  {
		tc_strcpy(cMonth,"Sep");
	  }
	  else if(m==10)
	  {
		tc_strcpy(cMonth,"Oct");
	  }
	  else if(m==11)
	  {
		tc_strcpy(cMonth,"Nov");
	  }
	  else if(m==12)
	  {
		tc_strcpy(cMonth,"Dec");
	  }
}

int tdays( int m, int y )
{
       if ( m < 1 || m > 12 ) return 0;
       switch ( m ) {
       case 1: return 31;
       case 2: return 28 + ( (y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0) );
       }
   return ( m*153 + 156 ) / 5 - ( m*153 + 3 ) / 5;
}

void NextDate(char cnextAccessDate[30])
{
	int day, month, year, nd, nm, ny, ndays;
	int		ch1;
	int		ch;
	time_t	temp;
    date_t DayTommorow ;
 	struct tm *timeptr;
	struct tm *timeptr1;
	char pAccessDate[20];
	char pAccessDate1[20];

	char	strDay[20];
	char	strMon[20];
	char	strYear[20];
	char	DateS[20];
	char cMonth[30];
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);

	day=timeptr->tm_mday;
	month=(timeptr->tm_mon)+1;
	year=(timeptr->tm_year+1900);
	ndays= tdays( month, year );//calling tdays function
	ny= year;
    nm= month;
    nd= day;
	if( ++nd > ndays )
	{
	   nd= 1;
	   if ( ++nm > 12 )
	   {
		 nm= 1;
		 ++ny;
		}
	}
    printf( "Given date is %d:%d:%d\n", day, month, year );
    printf( "Next days date is %d:%d:%d\n", nd, nm, ny );
	getcurentMonth(nm,cMonth);
	printf( "cMonth:%s\n", cMonth);
	sprintf(strDay,"%d",nd);

	sprintf(strMon,"%d",nm);
	sprintf(strYear,"%d",ny);

	tc_strcpy(cnextAccessDate,strDay);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,cMonth);
	tc_strcat(cnextAccessDate,"-");
	tc_strcat(cnextAccessDate,strYear);
	tc_strcat(cnextAccessDate," ");
	tc_strcat(cnextAccessDate,"00:00");
	printf("\n cnextAccessDate:%s\n",cnextAccessDate);
}

void CurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	//printf("\n CurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	//printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	//printf("Date:%d\n",(timeptr->tm_mday));
	//printf("Month:%d\n",(timeptr->tm_mon)+1);
	//printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}



int cmpstr(const void* a, const void* b)
{
    const char* aa = *(const char**)a;
    const char* bb = *(const char**)b;
    return tc_strcmp(aa,bb);
}
//End San



int tm_Compare(const void* a, const void* b)
{
 
    // setting up rules for comparison
    return strcmp(*(const char**)a, *(const char**)b);
}

// Function to sort the array
void tm_sort(char* arr[], int n)
{
    // calling qsort function to sort the array
    // with the help of Comparator
    qsort(arr, n, sizeof(const char*), tm_Compare);
}

/**************************End New Logic **************************************/

/********************************Module Matrix logic start **********************************/



int getlatestReleasedItem(char *partNumber, tag_t *tcPart)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	tag_t itemMaster = NULLTAG;
	
	qry_entries[0] = "Item ID";
	
	qry_values[0] = partNumber;
	
		
	CALLAPI(QRY_find2("Item...", &query));
	CALLAPI(QRY_execute(query, 1, qry_entries, qry_values, &count, &itemObjs));
	//printf("\n Item Master count==>%d", count);fflush(stdout);

	if(count>0)
	{
		itemMaster = itemObjs[0];
		int Item_count = 0;
		tag_t* rev_list = NULLTAG;
		int k = 0;
		char* rel_status = NULL;
		char* partNo = NULL;
		char* partRev = NULL;
		char* creDate = NULL;
		char* lastModDate = NULL;			
		
		ifail = ITEM_list_all_revs(itemMaster, &Item_count, &rev_list);
		//printf("\n Item Revisions count==>%d", count);fflush(stdout);
		for(k=Item_count-1;k>=0;k--)
		{
			
			date_t creation_dt = NULLDATE;
			CALLAPI(AOM_ask_value_string(rev_list[k], "item_id", &partNo))
			CALLAPI(AOM_ask_value_string(rev_list[k], "item_revision_id", &partRev))
			CALLAPI(AOM_UIF_ask_value(rev_list[k], "creation_date", &creDate))
			CALLAPI(AOM_UIF_ask_value(rev_list[k], "last_mod_date", &lastModDate))
			CALLAPI(AOM_UIF_ask_value(rev_list[k], "release_status_list", &rel_status))
			//printf("\n [%d]. Part No:[%s;%s], Creation Date:[%s],Last Modified Date: [%s], release_status_list:[%s]", k+1, partNo, partRev,creDate,lastModDate,rel_status);fflush(stdout);
			
			if((tc_strstr(rel_status,"Released")!=NULL)||(tc_strstr(rel_status,"ERC Released")!=NULL))
			{
				*tcPart = rev_list[k];
				break;
			}
			
			
		}

		if(*tcPart!=NULLTAG)
		{
			char* partNo = NULL;
			char* partRev = NULL;
			CALLAPI(AOM_ask_value_string(*tcPart, "item_id", &partNo))
			CALLAPI(AOM_ask_value_string(*tcPart, "item_revision_id", &partRev))
			//printf("\n Latest Released Part [%s;%s]\n", partNo, partRev);fflush(stdout);
		}
		else
		{
			//printf("\n No Released Part Found with id [%s]\n",partNumber);fflush(stdout);
		}		
		
		
	}
	
	
	
	
	return ifail;
}

char* subStringMR(char* mainStringf,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(toCharf+1);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


typedef struct VehModuleRelDet_
{
	char vehicleNo[50];
	char vehRev[15];
	char vehDes[300];
	char vehDrStatus[10];
	char vehPlatForm[50];
	char vehProgram[80];
	char vehRelStat[50];
	char** moduleIDList;	
	char** moduleAddList;
	int moduleCnt;
}VehModuleRelDet;

void setAddVehModuleRelDetSet(int *count,VehModuleRelDet **objlist,VehModuleRelDet obj )
{

	*count=*count+1;
	if(*count==1)
	{
		(*objlist) = (VehModuleRelDet *)malloc((*count ) * sizeof(VehModuleRelDet ));
	}
	else
	{
		(*objlist) = (VehModuleRelDet *)realloc((*objlist),(*count) * sizeof(VehModuleRelDet ));
	}

	(*objlist)[*count-1] = obj;
}

void t5FindVehNodeInVehModuleRelDetSet(VehModuleRelDet *vehnode_list,int count,char *str,int *found)
{

	int k=0;
	*found=0;
	for(k=0;k<count;k++)
	{

		//printf("\n[%d]tc_strcmp(%s,%s)",k,str_list[k],str);fflush(stdout);
		if(tc_strcmp(vehnode_list[k].vehicleNo,str)==0)
		{
			*found=1;
			break;
		}

	}
}


int getRDEVehicleID1(int *vehCount, char ***vehNos)
{
	int ifail = ITK_ok;
	const char * select_attrs[]={"puid"};

	//const char * partType = "V";
	int n_rows = 0;
	int n_cols = 0;
	void ***values = NULL;
	int i = 0;
	int vcCount = 0;
	char** soVCNo = NULLTAG;
	
	char **partType = (char **) MEM_alloc(20 * sizeof(char *));
	partType[0]="V";
	partType[1]="VCCR";
	
	
	
	ifail = POM_enquiry_create ("find_veh_objs" );
	
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_add_select_attrs ("find_veh_objs","Design Revision",1,select_attrs);
	}
	
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_string_value ("find_veh_objs","part_type",2,(const char**)partType,POM_enquiry_bind_value);
	}
	
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_attr_expr ("find_veh_objs","part_type_expr","Design Revision","t5_PartType",POM_enquiry_in,"part_type");
	}
	
	
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_set_where_expr ("find_veh_objs", "part_type_expr");
	}
	
	if(ifail == ITK_ok)
	{
		//ifail = POM_enquiry_add_order_attr ("find_veh_objs","Design Revision", "item_id", POM_enquiry_asc_order);
		ifail = POM_enquiry_add_order_attr ("find_veh_objs","Design Revision", "creation_date", POM_enquiry_asc_order);
	}
	
	if(ifail == ITK_ok)
	{
		ifail = POM_enquiry_execute ("find_veh_objs", &n_rows, &n_cols,&values);	
	}
	
	ifail = POM_enquiry_delete("find_veh_objs");
	
	printf("\n No of Vehicle Rev Tags==>%d\n",n_rows);fflush(stdout);
	
	
	for (i = 0; i < n_rows; i++ )
	{
		tag_t vehTag = NULLTAG;
		char* vcNoStr = NULL;
		int found = 0;
		vehTag  = *(tag_t*)(values[i][0]);
		
		ifail = AOM_ask_value_string(vehTag,"item_id",&vcNoStr);
		
		t5FindStrInSet(soVCNo,vcCount,vcNoStr,&found);
		
		if(found == 0)
		{
			t5AddStrToSet(&vcCount,&soVCNo,vcNoStr );
		}
		
	}
	
	*vehNos = soVCNo;
	*vehCount = vcCount;
	
	return ifail;
}



int getRDEVehicleID(int *vehCount, char ***vehNos)
{
	int ifail = ITK_ok;
	int  count 	= 0;
	tag_t *itemObjs = NULLTAG;	
	char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t query = NULLTAG;
	int vcCount = 0;
	char** soVCNo = NULLTAG;
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Part Type";
	
	qry_values[0] = "Design";
	qry_values[1] = "V";
		
	CALLAPI(QRY_find2("Latest Design Objets", &query));
	//CALLAPI(QRY_find2("Latest Design Revisions...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	//printf("\n Item Master count==>%d", count);fflush(stdout);
	
	printf("\n No of Vehicle Master Tags==>%d\n",count);fflush(stdout);
	
	int i =0;
	for (i = 0; i < count; i++ )
	{
		tag_t vehTag = NULLTAG;
		char* vcNoStr = NULL;
		
		int found = 0;
		vehTag  = itemObjs[i];
		
		ifail = AOM_ask_value_string(vehTag,"item_id",&vcNoStr);
		
		char* vcNoStrDup = NULL;
		tc_strdup(vcNoStr,&vcNoStrDup);
		
		if(vcNoStrDup != NULL)
		{
			if(tc_strlen(vcNoStrDup) > 5)
			{
				char* projCode = NULL;
				projCode = subStringMR(vcNoStrDup,0,4);
				
				if(tc_strcmp(projCode,"2999")==0)
				{
					printf("\n2999 project vehicle[%s] is skipped\n",vcNoStrDup);fflush(stdout);
					continue;
				}
			}
		}
		
		t5FindStrInSet(soVCNo,vcCount,vcNoStr,&found);
		
		if(found == 0)
		{
			t5AddStrToSet(&vcCount,&soVCNo,vcNoStr );
		}
		
	}
	
	
	//For VCCR
	
	qry_entries[0] = "Type";
	qry_entries[1] = "Part Type";
	
	qry_values[0] = "Design";
	qry_values[1] = "VCCR";
		
	CALLAPI(QRY_find2("Latest Design Objets", &query));
	//CALLAPI(QRY_find2("Latest Design Revisions...", &query));
	CALLAPI(QRY_execute(query, 2, qry_entries, qry_values, &count, &itemObjs));
	//printf("\n Item Master count==>%d", count);fflush(stdout);
	
	printf("\n No of CR Vehicle Master Tags==>%d\n",count);fflush(stdout);
	
	for (i = 0; i < count; i++ )
	{
		tag_t vehTag = NULLTAG;
		char* vcNoStr = NULL;
		int found = 0;
		vehTag  = itemObjs[i];
		
		ifail = AOM_ask_value_string(vehTag,"item_id",&vcNoStr);
		
		char* vcNoStrDup = NULL;
		tc_strdup(vcNoStr,&vcNoStrDup);
		
		if(vcNoStrDup != NULL)
		{
			if(tc_strlen(vcNoStrDup) > 5)
			{
				char* projCode = NULL;
				projCode = subStringMR(vcNoStrDup,0,4);
				
				if(tc_strcmp(projCode,"2999")==0)
				{
					printf("\n2999 project vehicle[%s] is skipped\n",vcNoStrDup);fflush(stdout);
					continue;
				}
			}
		}
		
		t5FindStrInSet(soVCNo,vcCount,vcNoStr,&found);
		
		if(found == 0)
		{
			t5AddStrToSet(&vcCount,&soVCNo,vcNoStr );
		}
		
	}	
	
	
	*vehNos = soVCNo;
	*vehCount = vcCount;
	
	return ifail;
}


void remove_multi_new_line(char* string)
{
  size_t length = strlen(string);
  while((length>0) && (string[length-1] == '\n'))
  {
      --length;
      string[length] ='\0';
  }
}


int getVehProgram(char* vcNo, char** vehProg)
{
	int ifail = ITK_ok;
	
	char* vehNo = (char*)MEM_alloc(30*sizeof(char*));
	char* projCode = NULL;
	tc_strcpy(vehNo,vcNo);
	
	printf("\nCopied vehicle No:[%s]\n",vehNo);fflush(stdout);
	
	projCode = subStringMR(vehNo,0,4);
	
	printf("Project Code :[%s]\n",projCode);fflush(stdout);
	tag_t query = NULLTAG;
	char **qry_entries = (char **) MEM_alloc(30 * sizeof(char *));
	char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
	int count = 0;
	tag_t* itemObjs = NULLTAG;
	tag_t projTag = NULLTAG;
	
	qry_entries[0] = "Name";
	
	qry_values[0] = projCode;
		
	CALLAPI(QRY_find2("Qury_Project", &query));
	CALLAPI(QRY_execute(query, 1, qry_entries, qry_values, &count, &itemObjs));
	
	if(count > 0)
	{
		char* progStr = NULL;
		projTag = itemObjs[0];
		
		if(projTag != NULLTAG)
		{
			ifail = AOM_ask_value_string(projTag,"t5_Program", &progStr);		
			*vehProg = progStr;
		}
		
	}
	else
	{
		*vehProg = "NA";
	}
	
	
	
	
		
	return ITK_ok;
}

int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	printf("\n *********** Start Of  Main function ************* \n");fflush(stdout);
	
	
	ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	

	if(ITK_auto_login() == ITK_ok)	
	{
		tag_t user_tag = NULLTAG;
		char* username = NULL;
		char* ModuleAddFile = NULL;
		FILE *fp1 = NULL;
		char** ModuleAddList = NULL;
		int ModuleAddListCnt = 0;
		char* ModuleAddStr = NULL;
		int i =0;
		char *repmode = ITK_ask_cli_argument("-repmode=");
				
		ifail = ITK_set_journalling( TRUE );
		printf("\nLogin successfull.\n");fflush(stdout);		
		
		POM_get_user(&username,&user_tag);
		printf("\nSession User Name[%s]\n",username);fflush(stdout);
		
		ModuleAddFile = ITK_ask_cli_argument( "-f=");
		
		printf("\nModuleAddFile[%s], repmode: [%s]\n",ModuleAddFile,repmode);fflush(stdout);
		
		
		
		
		fp1 = fopen(ModuleAddFile, "r");
		if(fp1==NULL)
		{
			printf("\nCould not open the file %s. Kindly check.",ModuleAddFile);fflush(stdout);
			return ifail;
		}
		else
		{
			char buffer1[MAX_LINE_LEN] ="";
			
			while(fgets(buffer1, MAX_LINE_LEN,fp1)!= NULL)
			{
				//printf("\nbuffer.........>%s",buffer);fflush(stdout); 
				ModuleAddStr = strtok(buffer1,",");
	
				if(ModuleAddStr != NULL)
				{
					int found =0;
					t5FindStrInSet(ModuleAddList,ModuleAddListCnt,ModuleAddStr,&found);
					if(found==0)
					{
						t5AddStrToSet(&ModuleAddListCnt, &ModuleAddList,ModuleAddStr);
					}
					
				}
				

			}			
		}
		
		if(fp1)fclose(fp1);
		
		printf("\n ModuleAddListCnt ==> %d ",ModuleAddListCnt);fflush(stdout);
		
		//printf("\n Before Sorting.....\n");fflush(stdout);
		
		/*
		for(i=0;i<ModuleAddListCnt;i++)
		{
			printf("\n %s",ModuleAddList[i]);fflush(stdout);
		}*/
		
		
		//printf("\n After Sorting.....\n");fflush(stdout);
		
		tm_sort(ModuleAddList, ModuleAddListCnt);
		/*
		for(i=0;i<ModuleAddListCnt;i++)
		{
			printf("\n %s",ModuleAddList[i]);fflush(stdout);
		}*/
		
		/* Start of logic to get IFD module address from control object */
		
		//To be implemented.
		char** ifdModuleAddSet = NULL;
		int ifdModuleAddSetCnt = 0;
	   
	   	/* End of logic to get IFD module address from control object */
		
		
		//Get the RDE vehicle from control obj.
		
		char** unqVcList = NULL;
		int unqVcListCnt = 0;
		
		getRDEVehicleID(&unqVcListCnt,&unqVcList); //sanjoy comment
		
		
		/*t5AddStrToSet(&unqVcListCnt,&unqVcList,"51620968R" );
		t5AddStrToSet(&unqVcListCnt,&unqVcList,"51480434R" );
		t5AddStrToSet(&unqVcListCnt,&unqVcList,"27503955100L" );
		t5AddStrToSet(&unqVcListCnt,&unqVcList,"52151172100R" );
		t5AddStrToSet(&unqVcListCnt,&unqVcList,"55530220R" );
		
*/
		



		
		printf("\n VC List count: [%d]",unqVcListCnt);fflush(stdout);
		
		//return ifail;
		
		char* vcNo = NULL;
		tag_t releasedVCTag = NULLTAG;
		int vcCount = 0;
		tag_t* soVCObject = NULL;
		
		VehModuleRelDet * vehModuleRelList = NULL;
		int vehModuleRelListCnt = 0;
		
		
		for(i=0;i<unqVcListCnt;i++)
		{
			vcNo = unqVcList[i];
			releasedVCTag = NULLTAG;
			//Get the VC Tag
			ifail = getlatestReleasedItem(vcNo,&releasedVCTag);
			
			if(releasedVCTag != NULLTAG)
			{
				//printf("\n %s - Released Vehicle \n",vcNo);fflush(stdout);
				
				//skip the obsolete vehicle.
				char* relzStatus = NULL;
				ifail = AOM_UIF_ask_value(releasedVCTag,"release_status_list",&relzStatus);
				//printf("\nrelzStatus:[%s]",relzStatus);fflush(stdout);
				if(tc_strstr(relzStatus,"Obsolete")!=NULL)
				{
					printf("\nSkip the obsolete vehicle[%s]\n",vcNo);fflush(stdout);
					//continue;
				}
				else
				{
					t5AddTagObjToSet(&vcCount,&soVCObject,releasedVCTag );
				}
							
			}
			else
			{
				//printf("\n %s Not Released Vehicle\n",vcNo);fflush(stdout);
			}
		}
		
		printf("\n Final unique released VC count ===> %d \n", vcCount);fflush(stdout);
		
		tag_t rule = NULLTAG;
		int rulefound = 0;
		tag_t* ClosureRuleTags = NULL;
		tag_t ClosureRuleTag = NULLTAG;
		
		ifail = CFM_find( "ERC release and above", &rule );
		if(rule == NULLTAG)
		{
			printf("\n Revision Rule- ERC release and above Not found, Applying Default Rule\n");fflush(stdout);
			ifail = CFM_find( "Latest Working", &rule );
		}
		else
		{
			printf("\n Revision Rule- ERC release and above found\n");fflush(stdout);
		}
		
		ifail = PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound,&ClosureRuleTags);
		//ifail = PIE_find_closure_rules("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound,&ClosureRuleTags);
		
		printf ("\nClosure Rule count %d \n",rulefound);fflush(stdout);
		if (rulefound > 0)
		{
			ClosureRuleTag = ClosureRuleTags[0];
			printf ("\nClosure rule found \n");fflush(stdout);
		
		}
		
		//vcCount=10;//test
		for(i=0;i<vcCount;i++)
		{
			
			tag_t vcRevTag = NULLTAG;
			tag_t vcItemTag = NULLTAG;
			tag_t* bvs = NULL;
			int bv_count = 0;
			tag_t* bvrs = NULL;
			int bvr_count = 0;
			tag_t bv = NULLTAG;
			tag_t bvr = NULLTAG;
			
			char* vcNoStr = NULL;
			char* vcRevStr = NULL;
			char* vcDescStr = NULL;
			char* vcDrStatusStr = NULL;
			char* vcPlatformStr = NULL;
			char* vcRelStatStr = NULL;
			
			int relStatCnt = 0;
			tag_t* relStatTags = NULL;
			
			vcRevTag = soVCObject[i];
			
			ifail = AOM_ask_value_string(vcRevTag,"item_id",&vcNoStr);
			ifail = AOM_ask_value_string(vcRevTag,"item_revision_id",&vcRevStr);
			printf("\n [%d]. Vehicle No: [%s;%s] ",i+1,vcNoStr,vcRevStr);fflush(stdout);
			
			
			ifail = AOM_ask_value_string(vcRevTag,"object_desc",&vcDescStr);
			remove_multi_new_line(vcDescStr);
			STRNG_replace_str(vcDescStr,"\"","",&vcDescStr);
			STRNG_replace_str(vcDescStr,","," ",&vcDescStr);
			
			ifail = AOM_ask_value_string(vcRevTag,"t5_PartStatus",&vcDrStatusStr);
			ifail = AOM_ask_value_string(vcRevTag,"t5_Platform",&vcPlatformStr);
			
			//Get Vehicle Program
			char* vcProgramStr = NULL;
			ifail = getVehProgram(vcNoStr,&vcProgramStr);
			
			remove_multi_new_line(vcProgramStr);
			STRNG_replace_str(vcProgramStr,"\"","",&vcProgramStr);
			STRNG_replace_str(vcProgramStr,","," ",&vcProgramStr);
			
			printf("\nvcProgramStr[%s]\n", vcProgramStr);fflush(stdout);;
			
			//Get ERC Released Date
			ifail = WSOM_ask_release_status_list(vcRevTag,&relStatCnt,&relStatTags);
			
			if(relStatCnt > 0)
			{
				int r = 0;
				for(r = 0; r<relStatCnt;r++)
				{
					char* date_rel=NULL;
					
					//char  name[WSO_name_size_c+1]    = {'\0'};
					char* name = NULL;
					tag_t release_status = relStatTags[r];
					//ifail = CR_ask_release_status_type(release_status,name);
					ifail = RELSTAT_ask_release_status_type(release_status,&name);
					//printf("\nRelease Status Name obtained=%s\n",name);fflush(stdout);
					if(tc_strcmp(name,"T5_LcsErcRlzd")==0 || tc_strcmp(name,"ERC Released")==0)
					{
						ifail = AOM_UIF_ask_value(release_status,"date_released",&vcRelStatStr);
						//printf("ERC Released Date=%s\n",vcRelStatStr);fflush(stdout);
						break;
					}
					
								
				}
			}
			
			printf("ERC Released Date=%s\n",vcRelStatStr);fflush(stdout);
			
			if(vcRelStatStr == NULL)
			{
				vcRelStatStr = "NA";
			}
			
			
			ifail = ITEM_ask_item_of_rev(vcRevTag, &vcItemTag);

			ifail = ITEM_list_bom_views(vcItemTag, &bv_count, &bvs );

			//printf("\n BV Count: %d\n",bv_count);fflush(stdout);
			
			
			
			if(bv_count)
			{
				bv = bvs[0];
				MEM_free(bvs);
			}
			else
			{
				printf("\n No BV... exit....\n");fflush(stdout);
				//continue;
			}
			
			ifail = ITEM_rev_list_bom_view_revs(vcRevTag,&bvr_count, &bvrs);
	
			//printf("\n BVR Count: %d\n",bvr_count);fflush(stdout);
			
			if(bvr_count)
			{	
				bvr = bvrs[0];
				MEM_free(bvrs);		
			}
			else
			{
				printf("\n No BVR ..exit....\n");fflush(stdout);
				//continue;
			}
			
			
			if ( bv != NULLTAG )
			{
				ifail = AOM_unload( bv );					
					
			}
			
			if(bvr != NULLTAG)
			{
				tag_t window = NULLTAG;
				
				tag_t top_line = NULLTAG;
				tag_t* child_lines = NULL;
				int nChld = 0;
				char** tplNoSet = NULL;
				int tplNoSetCnt = 0;
				int tplModAddSetCnt = 0;
				char** tplModAddSet = NULL;
				char **rulename = NULL;
				char **rulevalue = NULL;

				ifail = BOM_create_window (&window);
				
				
				ifail = BOM_set_window_config_rule( window, rule );
				ifail = BOM_window_set_closure_rule( window,ClosureRuleTag, 0, rulename,rulevalue );
				ifail = BOM_set_window_pack_all (window, true);
				ifail = BOM_set_window_top_line (window, NULLTAG,vcRevTag, NULLTAG, &top_line);
				if(top_line != NULLTAG)
				{
					int j =0;
					//int childId = 0;
					//int childRevSeq = 0;
					char* child_id = NULL;
					char* child_rev_seq = NULL;
					//int occuid = 0;
					char* ChildUID = NULL;
					char* tempModuleAdd = NULL;
					VehModuleRelDet vehModRDet;
					//int ruleConfigByID 	 =0;
					char* rules_configured_by = NULL;
					
					//int relStatID = 0;
					char* releaseStatusStr = NULL;
					
					
					
					//ifail = BOM_line_look_up_attribute("bl_item_item_id",&childId);
					//ifail = BOM_line_look_up_attribute("bl_rev_item_revision_id",&childRevSeq);
					//ifail = BOM_line_look_up_attribute ("bl_occurrence_uid",&occuid);					
					ifail = BOM_line_ask_child_lines (top_line, &nChld, &child_lines);
					//printf("\nNo of child objects of Vehicle Rev are : %d",nChld);fflush(stdout);

	
					//ifail = BOM_line_look_up_attribute("bl_config_string", &ruleConfigByID);
					//ifail = BOM_line_look_up_attribute("bl_rev_release_status_list", &relStatID);					
					
					if(nChld > 0)
					{
						for(j=0;j<nChld;j++)
						{

							ifail = AOM_ask_value_string(child_lines[j],"bl_item_item_id",&child_id);
							ifail = AOM_ask_value_string(child_lines[j],"bl_rev_item_revision_id",&child_rev_seq);
							ifail = AOM_ask_value_string(child_lines[j], "bl_occurrence_uid", &ChildUID);
							
							ifail = AOM_ask_value_string(child_lines[j], "bl_config_string", &rules_configured_by);
							
							if(tc_strcmp(rules_configured_by, "No configured Revision") == 0 )
							{
								//skip the unconigured child part.
								continue;
							}
							
							//Skip Non ERC Released Part.
							ifail = AOM_ask_value_string(child_lines[j], "bl_rev_release_status_list", &releaseStatusStr);
							//printf("\nreleaseStatusStr[%s]",releaseStatusStr);fflush(stdout);
							if(tc_strstr(releaseStatusStr,"ERC Released")!= NULL || tc_strstr(releaseStatusStr,"T5_LcsErcRlzd")!= NULL)
							{
								//ERC Part
							}
							else
							{
								printf("\n Skip APL part:%s/%s\n",child_id,child_rev_seq);fflush(stdout);
								continue;
							}
							
							//printf("\n [%d] Child Part No: [%s;%s] , UID:[%s]",j+1,child_id,child_rev_seq,ChildUID);fflush(stdout);
							
							if(tc_strlen(child_id)==14)
							{
								char* moduleNoStr = (char*)MEM_alloc(50*sizeof(char*));
								tc_strcpy(moduleNoStr,child_id);
								tc_strcat(moduleNoStr,"/");
								tc_strcat(moduleNoStr,child_rev_seq);
								tempModuleAdd=subStringMR(child_id,4,5);
								//printf(" Module Address:[%s] \n",tempModuleAdd);fflush(stdout);
								
								//t5AddStrToSet(&tplNoSetCnt, &tplNoSet,child_id);
								t5AddStrToSet(&tplNoSetCnt, &tplNoSet,moduleNoStr);
								
								t5AddStrToSet(&tplModAddSetCnt, &tplModAddSet,tempModuleAdd);
								
								MEM_free(moduleNoStr);
							}
							
							
							
						}
						
						//logic for ECU Module
						//T5_CCVCHasECUModule
						tag_t HasECURelType = NULLTAG;
						
						
						ifail = GRM_find_relation_type("T5_CCVCHasECUModule", &HasECURelType);
						if(HasECURelType != NULLTAG)
						{
							tag_t* EcuMstrTags = NULL;
							int EcuCnt = 0;
							ifail = GRM_list_secondary_objects_only(vcRevTag,HasECURelType,&EcuCnt,&EcuMstrTags);
							
							if(EcuCnt > 0)
							{
								tag_t EcuMstrTag = NULLTAG;
								tag_t EcuLatestRevTag = NULLTAG;
								char* ECUPartNo = NULL;
								char* Ecu_rev = NULL;
								EcuMstrTag = EcuMstrTags[0];
								
								//ifail = ITEM_ask_latest_rev(EcuMstrTag, &EcuLatestRevTag);
								
								ifail = AOM_ask_value_string(EcuMstrTag,"item_id",&ECUPartNo);
								
								ifail = getlatestReleasedItem(ECUPartNo,&EcuLatestRevTag);
								if(EcuLatestRevTag != NULLTAG)
								{
									//printf("\n Got the latest ECU Released Part\n");fflush(stdout);
									ifail = AOM_ask_value_string(EcuLatestRevTag,"item_revision_id",&Ecu_rev);
									printf("\nSAN:Latest Released ECU:ECU Module No:%s",ECUPartNo);fflush(stdout);
									if(tc_strlen(ECUPartNo)==14 && Ecu_rev != NULL)
									{
										char* EcuModuleNoStr = (char*)MEM_alloc(50*sizeof(char*));
										tc_strcpy(EcuModuleNoStr,ECUPartNo);
										tc_strcat(EcuModuleNoStr,"/");
										tc_strcat(EcuModuleNoStr,Ecu_rev);
										tempModuleAdd=subStringMR(ECUPartNo,4,5);
										//printf(" Module Address:[%s] \n",tempModuleAdd);fflush(stdout);
										
										//t5AddStrToSet(&tplNoSetCnt, &tplNoSet,ECUPartNo);
										t5AddStrToSet(&tplNoSetCnt, &tplNoSet,EcuModuleNoStr);
										
										t5AddStrToSet(&tplModAddSetCnt, &tplModAddSet,tempModuleAdd);
										
										MEM_free(EcuModuleNoStr);
									}
								}
								else
								{
									printf("\n Get WIP part of ECU\n");fflush(stdout);
									ifail = ITEM_ask_latest_rev(EcuMstrTag, &EcuLatestRevTag);
									if(EcuLatestRevTag != NULLTAG)
									{
										//printf("\n Got the latest ECU Part\n");fflush(stdout);
										ifail = AOM_ask_value_string(EcuLatestRevTag,"item_revision_id",&Ecu_rev);
										printf("\nSAN:WIP ECU:ECU Module No:%s",ECUPartNo);fflush(stdout);
										if(tc_strlen(ECUPartNo)==14 && Ecu_rev != NULL)
										{
											char* EcuModuleNoStr = (char*)MEM_alloc(50*sizeof(char*));
											tc_strcpy(EcuModuleNoStr,ECUPartNo);
											tc_strcat(EcuModuleNoStr,"/");
											tc_strcat(EcuModuleNoStr,Ecu_rev);
											tempModuleAdd=subStringMR(ECUPartNo,4,5);
											//printf(" Module Address:[%s] \n",tempModuleAdd);fflush(stdout);
											
											//t5AddStrToSet(&tplNoSetCnt, &tplNoSet,ECUPartNo);
											t5AddStrToSet(&tplNoSetCnt, &tplNoSet,EcuModuleNoStr);
											
											t5AddStrToSet(&tplModAddSetCnt, &tplModAddSet,tempModuleAdd);
											
											MEM_free(EcuModuleNoStr);
										}
									}									
								}

								
							}
						}
						
						
						tc_strcpy(vehModRDet.vehicleNo,vcNoStr);
						tc_strcpy(vehModRDet.vehRev,vcRevStr);
						tc_strcpy(vehModRDet.vehDes,vcDescStr);
						tc_strcpy(vehModRDet.vehDrStatus,vcDrStatusStr);
						tc_strcpy(vehModRDet.vehRelStat,vcRelStatStr);
						
						
						tc_strcpy(vehModRDet.vehPlatForm,vcPlatformStr);
						tc_strcpy(vehModRDet.vehProgram,vcProgramStr);
						vehModRDet.moduleIDList = tplNoSet;
						vehModRDet.moduleAddList = tplModAddSet;
						vehModRDet.moduleCnt = tplNoSetCnt;
						
						
						setAddVehModuleRelDetSet(&vehModuleRelListCnt, &vehModuleRelList,vehModRDet);
						
					}
					else
					{
						printf("\nVehicle:[%s/%s] has no child....\n",vcNoStr,vcRevStr);fflush(stdout);
						tc_strcpy(vehModRDet.vehicleNo,vcNoStr);
						tc_strcpy(vehModRDet.vehRev,vcRevStr);
						tc_strcpy(vehModRDet.vehDes,vcDescStr);
						tc_strcpy(vehModRDet.vehDrStatus,vcDrStatusStr);
						tc_strcpy(vehModRDet.vehRelStat,vcRelStatStr);
						
						
						tc_strcpy(vehModRDet.vehPlatForm,vcPlatformStr);
						tc_strcpy(vehModRDet.vehProgram,vcProgramStr);
						
						vehModRDet.moduleIDList = NULL;
						vehModRDet.moduleAddList = NULL;
						vehModRDet.moduleCnt = 0;
						setAddVehModuleRelDetSet(&vehModuleRelListCnt, &vehModuleRelList,vehModRDet);
						
					}
					
				}
				
				
				
				
				ifail = BOM_close_window(window);
				
				
				//printf("\ntplNoSetCnt[%d], tplModAddSetCnt[%d]\n",tplNoSetCnt,tplModAddSetCnt);fflush(stdout);
			}
			else
			{
				VehModuleRelDet vehModRDet;
				
				printf("\nVehicle:[%s/%s] has no bv or BVR....\n",vcNoStr,vcRevStr);fflush(stdout);
				tc_strcpy(vehModRDet.vehicleNo,vcNoStr);
				tc_strcpy(vehModRDet.vehRev,vcRevStr);
				tc_strcpy(vehModRDet.vehDes,vcDescStr);
				tc_strcpy(vehModRDet.vehDrStatus,vcDrStatusStr);
				tc_strcpy(vehModRDet.vehRelStat,vcRelStatStr);
				
				
				tc_strcpy(vehModRDet.vehPlatForm,vcPlatformStr);
				tc_strcpy(vehModRDet.vehProgram,vcProgramStr);
				
				vehModRDet.moduleIDList = NULL;
				vehModRDet.moduleAddList = NULL;
				vehModRDet.moduleCnt = 0;
				setAddVehModuleRelDetSet(&vehModuleRelListCnt, &vehModuleRelList,vehModRDet);
			}
			//San test
			//if(i>10) break;
			
		}
		
		printf("\nvehModuleRelListCnt [%d]",vehModuleRelListCnt);fflush(stdout);
		
		

		
		time_t now;
		struct tm* now_tm;
		char CurrDateTime_str[26] = {'\0'};
		int k =0;
		
		char reportFileLoc[250];
		
		
		
		time(&now);
		now_tm = localtime(&now);
		strftime (CurrDateTime_str, 26, "%d%m%y%H%M%S", now_tm);
		//printf("\n CurrDateTime_str is===>[%s]",CurrDateTime_str);fflush(stdout);
		
		tc_strcpy(reportFileLoc,"");
		tc_strcat(reportFileLoc,"/tmp/TCUA_CVBU_Modular_VCs_and_Submodules_variety_matrix_dashboard");
		//tc_strcat(reportFileLoc,"TCUA_CVBU_Modular_VCs_and_Submodules_variety_matrix_dashboard");
		tc_strcat(reportFileLoc,"_");
		tc_strcat(reportFileLoc,CurrDateTime_str);
		tc_strcat(reportFileLoc,".csv");
		printf("\n reportFileLoc==> %s",reportFileLoc);fflush(stdout);
		
		
		
		if(tc_strcmp(repmode,"AWC")==0)
		{
			FILE * fpXml = NULL;
			fpXml = fopen("/tmp/cvbumodulerep.xml", "w");
			fprintf(fpXml,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"<CVBUModuleMigRep>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"<CVBURepHeader>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"<SrNo>Sr.No</SrNo>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"<vcno>VC Number</vcno>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"<rev>Rev</rev>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"<Desc>Desc</Desc>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"<drStat>DR Stat</drStat>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"<platform>Platform</platform>");fflush(fpXml);
			fprintf(fpXml,"<relDate>ERC Release Date</relDate>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			
			printf("\nSr.No,VC Number");fflush(stdout);
			//fprintf(vcMdlRep,"Sr.No,VC Number,Revision,Desc,DR Status,Platform,");
			
			
			int d = 0;
			int l = 0;
			char* mdlAddr = NULL;
			char** moduleNoSet = NULL;
			char** moduleAddSet = NULL;
			int moduleNoSetCnt = 0;
			
			fprintf(fpXml,"<ModuleAdd>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			for(d=0;d<ModuleAddListCnt;d++)
			{
				char moduleAdd[100];
				//fprintf(vcMdlRep,"M%s,",ModuleAddList[d]);
				tc_strcpy(moduleAdd,"<MD modulename=");
				tc_strcat(moduleAdd,"\"M");
				tc_strcat(moduleAdd,ModuleAddList[d]);
				tc_strcat(moduleAdd,"\">");
				tc_strcat(moduleAdd,"</MD>\n");
				
				fprintf(fpXml,moduleAdd);fflush(fpXml);
			}
			fprintf(fpXml,"</ModuleAdd>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"</CVBURepHeader>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"<CVBURepData>");fflush(fpXml);
			for(k=0;k<vehModuleRelListCnt;k++)
			{
				//char * srno = NULL;
				//srno = MEM_alloc(50);
				fprintf(fpXml,"\n");fflush(fpXml);
				fprintf(fpXml,"<ReportData>");fflush(fpXml);
				fprintf(fpXml,"\n");fflush(fpXml);
				
				//sprintf(srno,"%d",k+));
				fprintf(fpXml,"<SrNo>");fflush(fpXml);
				fprintf(fpXml,"%d",k+1);fflush(fpXml);
				fprintf(fpXml,"</SrNo>");fflush(fpXml);
				
				fprintf(fpXml,"<VehNo>");fflush(fpXml);
				fprintf(fpXml,"%s",vehModuleRelList[k].vehicleNo);fflush(fpXml);
				fprintf(fpXml,"</VehNo>");fflush(fpXml);
				
				//fprintf(vcMdlRep,"%s,%s,%s,%s,",vehModuleRelList[k].vehRev,vehModuleRelList[k].vehDes,vehModuleRelList[k].vehDrStatus,vehModuleRelList[k].vehPlatForm);
				
				fprintf(fpXml,"<VehRev>");fflush(fpXml);
				fprintf(fpXml,"%s",vehModuleRelList[k].vehRev);fflush(fpXml);
				fprintf(fpXml,"</VehRev>");fflush(fpXml);
		
				fprintf(fpXml,"<VehDesc>");fflush(fpXml);
				fprintf(fpXml,"%s",vehModuleRelList[k].vehDes);fflush(fpXml);
				fprintf(fpXml,"</VehDesc>");fflush(fpXml);

				fprintf(fpXml,"<VehDrStat>");fflush(fpXml);
				fprintf(fpXml,"%s",vehModuleRelList[k].vehDrStatus);fflush(fpXml);
				fprintf(fpXml,"</VehDrStat>");fflush(fpXml);

				fprintf(fpXml,"<VehPlatform>");fflush(fpXml);
				fprintf(fpXml,"%s",vehModuleRelList[k].vehPlatForm);fflush(fpXml);
				fprintf(fpXml,"</VehPlatform>");fflush(fpXml);
				
				fprintf(fpXml,"<VehRelDate>");fflush(fpXml);
				fprintf(fpXml,"%s",vehModuleRelList[k].vehRelStat);fflush(fpXml);
				fprintf(fpXml,"</VehRelDate>");fflush(fpXml);

				
				moduleNoSet = vehModuleRelList[k].moduleIDList;
				moduleAddSet = vehModuleRelList[k].moduleAddList;
				moduleNoSetCnt = vehModuleRelList[k].moduleCnt;
				
				printf("\nmoduleNoSetCnt:[%d]",moduleNoSetCnt);fflush(stdout);
				
				for(d=0;d<ModuleAddListCnt;d++)
				{
					int tplStrSetCnt =0;
					char** tplStrSet = NULL;
					mdlAddr = ModuleAddList[d];
					
					//printf("\nmdlAddr:[%s]",mdlAddr);fflush(stdout);
					for(l=0;l<moduleNoSetCnt;l++)
					{

						//printf("\nmoduleAddSet[%d]:[%s]",l,moduleAddSet[l]);fflush(stdout);
						if(tc_strcmp(mdlAddr,moduleAddSet[l])==0)
						{
							//printf("\nMatched!!!!...Adding %s to tplStrSet",moduleNoSet[l]);fflush(stdout);
							t5AddStrToSet(&tplStrSetCnt,&tplStrSet,moduleNoSet[l]);
						}
					}
					if(tplStrSetCnt > 0)
					{
						int t=0;

						char * 	tempObjstring 	= NULL;
						char* tplNoStr = NULL;
						int sz =0; 
						sz = tplStrSetCnt;
						tempObjstring = MEM_alloc(sz*100);
						tc_strcpy(tempObjstring,"");
						for(t=0;t<sz;t++)
						{
							
							tplNoStr = tplStrSet[t];
							
							
							tc_strcat(tempObjstring,tplNoStr);
							if(sz>1) 
							{
								//printf("\n more than one tpl\n");fflush(stdout);
								if(t!=(sz-1)) tc_strcat(tempObjstring,"  ");
							}
							

						}
						//printf("%s,",tempObjstring);fflush(stdout);
						//fprintf(vcMdlRep,"%s,",tempObjstring);
						
						fprintf(fpXml,"<ModuleNo modulenum=\"%s\">",tempObjstring);fflush(fpXml);
						//fprintf(fpXml,tempObjstring);fflush(fpXml);
						fprintf(fpXml,"</ModuleNo>");fflush(fpXml);					
						
						MEM_free(tempObjstring);						
					}
					else
					{
						//fprintf(vcMdlRep,"NA,");
						
						fprintf(fpXml,"<ModuleNo modulenum=\"NA\">");fflush(fpXml);
						//fprintf(fpXml,"NA");fflush(fpXml);
						fprintf(fpXml,"</ModuleNo>");fflush(fpXml);	
					}
				
					
				}
			
				fprintf(fpXml,"\n");fflush(fpXml);
				fprintf(fpXml,"</ReportData>");fflush(fpXml);
			}
			
			//Variety count logic
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"<VarietyCount>");fflush(fpXml);
			
			////Logic for Module Variant
			//fprintf(vcMdlRep,"\nSub Module Variety Count,,,,,,");
			//printf("\nMODULE VARIANT ModuleAddListCnt: %d",ModuleAddListCnt);fflush(stdout);
			
			int t=0;
			for(t=0;t<ModuleAddListCnt;t++)
			{
				int kk =0;
				char* mdlAddr1 = NULL;
				mdlAddr1 = ModuleAddList[t];
				char** moduleNoList = NULL;
				int moduleNoListCnt = 0;
				
				for(kk=0;kk<vehModuleRelListCnt;kk++)
				{
					moduleNoSet = vehModuleRelList[kk].moduleIDList;
					moduleAddSet = vehModuleRelList[kk].moduleAddList;
					moduleNoSetCnt = vehModuleRelList[kk].moduleCnt;
					int jj =0;
					for(jj=0;jj<moduleNoSetCnt;jj++)
					{
						if(tc_strcmp(mdlAddr1,moduleAddSet[jj])==0)
						{
							int fnd =0;
							t5FindStrInSet(moduleNoList,moduleNoListCnt,moduleNoSet[jj],&fnd);
							if(fnd==0)
							{
								t5AddStrToSet(&moduleNoListCnt, &moduleNoList,moduleNoSet[jj]);
							}
						}
					}
					
					
				}
				fprintf(fpXml,"<ModuleCount mcnt=\"%d\">",moduleNoListCnt);fflush(fpXml);
				//fprintf(fpXml,tempObjstring);fflush(fpXml);
				fprintf(fpXml,"</ModuleCount>");fflush(fpXml);	
				//fprintf(vcMdlRep,"%d,",moduleNoListCnt);
			}			
			
			fprintf(fpXml,"</VarietyCount>");fflush(fpXml);
			
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"</CVBURepData>");fflush(fpXml);
			fprintf(fpXml,"\n");fflush(fpXml);
			
			
			fprintf(fpXml,"\n");fflush(fpXml);
			fprintf(fpXml,"</CVBUModuleMigRep>");fflush(fpXml);
			
			
			if(fpXml) fclose(fpXml);
			
			
		}
		else if(tc_strcmp(repmode,"MAIL")==0)
		{
			FILE *vcMdlRep;
			vcMdlRep = fopen(reportFileLoc, "w");

			
			printf("\nSr.No,VC Number");fflush(stdout);
			//fprintf(vcMdlRep,"Sr.No,VC Number,Revision,Desc,DR Status,Platform,ERC Release Date,");
			fprintf(vcMdlRep,"Sr.No,VC Number,Revision,Sequence,Desc,DR Status,Platform,Program,ERC Release Date,");fflush(vcMdlRep);
			
			
			int d = 0;
			int l = 0;
			char* mdlAddr = NULL;
			char** moduleNoSet = NULL;
			char** moduleAddSet = NULL;
			int moduleNoSetCnt = 0;
			

			for(d=0;d<ModuleAddListCnt;d++)
			{
				fprintf(vcMdlRep,"M%s,",ModuleAddList[d]);fflush(vcMdlRep);
			}

			for(k=0;k<vehModuleRelListCnt;k++)
			{
				moduleNoSetCnt = 0;
				fprintf(vcMdlRep,"\n%d,%s,",k+1,vehModuleRelList[k].vehicleNo);fflush(vcMdlRep);
				//fprintf(vcMdlRep,"%s,%s,%s,%s,%s,",vehModuleRelList[k].vehRev,vehModuleRelList[k].vehDes,vehModuleRelList[k].vehDrStatus,vehModuleRelList[k].vehPlatForm,vehModuleRelList[k].vehRelStat);
				
				char* revStr = NULL;
				char* seqStr = NULL;
				char* vehRevStr = NULL;
				
				tc_strdup(vehModuleRelList[k].vehRev,&vehRevStr);
				if(tc_strstr(vehRevStr,";") != NULL)
				{
					revStr = tc_strtok ( vehRevStr,";") ;
					seqStr = tc_strtok ( NULL,";") ;	
				}
				
				fprintf(vcMdlRep,"%s,%s,%s,%s,%s,%s,%s,",revStr,seqStr,vehModuleRelList[k].vehDes,vehModuleRelList[k].vehDrStatus,vehModuleRelList[k].vehPlatForm,vehModuleRelList[k].vehProgram,vehModuleRelList[k].vehRelStat);fflush(vcMdlRep);
				
				
				moduleNoSet = vehModuleRelList[k].moduleIDList;
				moduleAddSet = vehModuleRelList[k].moduleAddList;
				moduleNoSetCnt = vehModuleRelList[k].moduleCnt;
				
				printf("\nvehicleNo:[%s/%s;%s]",vehModuleRelList[k].vehicleNo,revStr,seqStr);fflush(stdout);
				
				printf("\nmoduleNoSetCnt:[%d]",moduleNoSetCnt);fflush(stdout);
				
				for(d=0;d<ModuleAddListCnt;d++)
				{
					int tplStrSetCnt =0;
					char** tplStrSet = NULL;
					mdlAddr = ModuleAddList[d];
					
					//printf("\nmdlAddr:[%s]",mdlAddr);fflush(stdout);
					for(l=0;l<moduleNoSetCnt;l++)
					{

						//printf("\nmoduleAddSet[%d]:[%s]",l,moduleAddSet[l]);fflush(stdout);
						if(tc_strcmp(mdlAddr,moduleAddSet[l])==0)
						{
							//printf("\nMatched!!!!...Adding %s to tplStrSet",moduleNoSet[l]);fflush(stdout);
							t5AddStrToSet(&tplStrSetCnt,&tplStrSet,moduleNoSet[l]);
						}
					}
					if(tplStrSetCnt > 0)
					{
						int t=0;

						char * 	tempObjstring 	= NULL;
						char* tplNoStr = NULL;
						int sz =0; 
						sz = tplStrSetCnt;
						tempObjstring = MEM_alloc(sz*100);
						tc_strcpy(tempObjstring,"");
						for(t=0;t<sz;t++)
						{
							
							tplNoStr = tplStrSet[t];
							
							
							tc_strcat(tempObjstring,tplNoStr);
							if(sz>1) 
							{
								//printf("\n more than one tpl\n");fflush(stdout);
								if(t!=(sz-1)) tc_strcat(tempObjstring,"  ");
							}
							

						}
						//printf("%s,",tempObjstring);fflush(stdout);
						fprintf(vcMdlRep,"%s,",tempObjstring);fflush(vcMdlRep);
				
						
						MEM_free(tempObjstring);						
					}
					else
					{
						fprintf(vcMdlRep,"NA,");fflush(vcMdlRep);
						
					}
				
					
				}
				


			}
			
			
			////Logic for Module Variant
			//fprintf(vcMdlRep,"\nSub Module Variety Count,,,,,,,");
			fprintf(vcMdlRep,"\nSub Module Variety Count,,,,,,,,,");fflush(vcMdlRep);
			//printf("\nMODULE VARIANT ModuleAddListCnt: %d",ModuleAddListCnt);fflush(stdout);
			char** UniqModuleNoList = NULL;
			int UniqModuleNoListCnt = 0;
			int t=0;
			for(t=0;t<ModuleAddListCnt;t++)
			{
				int kk =0;
				char* mdlAddr1 = NULL;
				mdlAddr1 = ModuleAddList[t];
				char** moduleNoList = NULL;
				int moduleNoListCnt = 0;
				
				for(kk=0;kk<vehModuleRelListCnt;kk++)
				{
					moduleNoSet = vehModuleRelList[kk].moduleIDList;
					moduleAddSet = vehModuleRelList[kk].moduleAddList;
					moduleNoSetCnt = vehModuleRelList[kk].moduleCnt;
					int jj =0;
					for(jj=0;jj<moduleNoSetCnt;jj++)
					{
						if(tc_strcmp(mdlAddr1,moduleAddSet[jj])==0)
						{
							int fnd =0;
							t5FindStrInSet(moduleNoList,moduleNoListCnt,moduleNoSet[jj],&fnd);
							if(fnd==0)
							{
								t5AddStrToSet(&moduleNoListCnt, &moduleNoList,moduleNoSet[jj]);
								t5AddStrToSet(&UniqModuleNoListCnt, &UniqModuleNoList,moduleNoSet[jj]);
							}
						}
					}
					
					
				}
				
				fprintf(vcMdlRep,"%d,",moduleNoListCnt);fflush(vcMdlRep);
			}
				
			
			if(vcMdlRep) fclose(vcMdlRep);
			
			//Logic for uninque Module List
			printf("\n Total no unique Module: [%d]\n",UniqModuleNoListCnt);fflush(stdout);
			
			char reportFileLoc1[250];
			tc_strcpy(reportFileLoc1,"");
			tc_strcat(reportFileLoc1,"/tmp/TCUA_CVBU_Modular_Total_Unique_SubmoduleList");
			tc_strcat(reportFileLoc1,"_");
			tc_strcat(reportFileLoc1,CurrDateTime_str);
			tc_strcat(reportFileLoc1,".csv");
			printf("\n Unique Module List Report reportFileLoc1==> %s",reportFileLoc1);fflush(stdout);
			
			FILE *MdlRep;
			MdlRep = fopen(reportFileLoc1, "w");
			fprintf(MdlRep,"Sr.No,SubModule No,Rev,Seq,");fflush(MdlRep);
			
			int u =0;
			for(u=0;u<UniqModuleNoListCnt;u++)
			{
				char* mdlnum = NULL;
				char* mdlNumb = NULL;
				char* mdlNumbDup = NULL;
				char* rev = NULL;
				char* seq = NULL;
				
				mdlnum = UniqModuleNoList[u];
				tc_strdup(mdlnum,&mdlNumbDup);
				//printf("\n[%s]",mdlNumbDup);fflush(stdout);
				mdlNumb = strtok(mdlNumbDup,"/");
				rev = strtok(NULL,";");
				seq = strtok(NULL,";");
				//printf("\n%d,%s,%s,%s,",u+1,mdlNumb,rev,seq);fflush(stdout);
				fprintf(MdlRep,"\n%d,%s,%s,%s,",u+1,mdlNumb,rev,seq);fflush(MdlRep);
				
			}
			
			if(MdlRep)fclose(MdlRep);

			//Send report mail
			
			char*	sysCommand	=	NULL;
			int sysreturn = 0;
			sysCommand=(char *) MEM_alloc(500);
			tc_strcpy(sysCommand,"/user/cvprod/sanjoy/modulematrixreport/cronrep/cvbumatrixrepMail.sh ");
			//tc_strcpy(sysCommand,"/user/cvprod/sanjoy/code/sanjoy/clientcodes/CVBUReport/cvbumatrixrepMail.sh ");
			tc_strcat(sysCommand,reportFileLoc);
			printf("\n Command cvburep: [%s]\n", sysCommand);fflush(stdout);
			sysreturn = system(sysCommand);
			if(sysreturn!=0)
			{
				printf("\nsysSystem: Call failed for sending cvbu module matrix report\n");fflush(stdout);
				//return ifail;
			}
			
			MEM_free(sysCommand);
			sysreturn = -1;
			
			
			
			//Send the unique mail
			char*	sysCmnd	=	NULL;
			int ret = 0;
			sysCmnd=(char *) MEM_alloc(400);
			tc_strcpy(sysCmnd,"/user/cvprod/sanjoy/modulematrixreport/cronrep/uniqListMail.sh ");
			tc_strcat(sysCmnd,reportFileLoc1);
			printf("\n Command: [%s]\n", sysCmnd);fflush(stdout);
			ret = system(sysCmnd);
			if(ret!=0)
			{
				printf("\nsysSystem: Call failed for sending unique report\n");fflush(stdout);
				//return ifail;
			}
			
			MEM_free(sysCmnd);
			
		}
		
		
		
		
		
	
	}

	printf("\n*********** End Of Main function ************* \n");fflush(stdout);	
	return ifail;
}
