int AutoSelect_Lifecycle( METHOD_message_t *msg, va_list  args )
{
	tag_t DMLTag = va_arg(args, const tag_t);
	
	
	tag_t objTypeTag=NULLTAG;
	tag_t template_tag=NULLTAG;
	tag_t test_job_a = NULLTAG;
	tag_t   *MdmCtrObj      = NULLTAG;
	
    int attachment_types = 1;
	int	n_entriesMdm = 2;
	int n_foundMdm = 0;
	
	char* type_name=NULL;
	char* DMLrlstype=NULL;
	
	char *qry_entriesMdm[2] = {"SYSCD", "SUBSYSCD"};
	char *qry_valuesMdm[2]  = {"AutoSelect_Lifecycle", "AutoSelect_Lifecycle"};

if(QRY_find2("ControlObjQry", &TagMdmControlEMR));

if(QRY_execute(TagMdmControlEMR, n_entriesMdm, qry_entriesMdm, qry_valuesMdm, &n_foundMdm, &MdmCtrObj));
printf("\n Control Object found for MDM EMR DML == %d \n", n_foundMdm);fflush(stdout); 

if(n_foundMdm==1)
{
	if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
	if(TCTYPE_ask_name2(objTypeTag,&type_name));
	
	if(strcmp(type_name,"ChangeRequestRevision")==0)
	{
		AOM_ask_value_string( DMLTag, "t5_rlstype", &DMLrlstype);
		
    }
	else
	{
		printf ("\n Created DML is not ERC DML\n");fflush(stdout);
	}
   if(DMLrlstype!=NULL)
   {
	if(
       (tc_strcmp(DMLrlstype,"Module Release")==0) || (tc_strcmp(DMLrlstype,"MR")==0)
       ||(tc_strcmp(DMLrlstype,"Gate Maturation")==0)||(tc_strcmp(DMLrlstype,"TODR")==0)
       ||(tc_strcmp(DMLrlstype,"ECU Parts Release")==0)||(tc_strcmp(DMLrlstype,"EP")==0)
       ||(tc_strcmp(DMLrlstype,"Kit and Spare Part Release")==0)||(tc_strcmp(DMLrlstype,"KSP")==0)
       ||(tc_strcmp(DMLrlstype,"Module with Spare Kit Release")==0)||(tc_strcmp(DMLrlstype,"TSKR")==0)
       ||(tc_strcmp(DMLrlstype,"Update Variant Formula")==0)||(tc_strcmp(DMLrlstype,"UVF")==0)
       ||(tc_strcmp(DMLrlstype,"Delete Module")==0)||(tc_strcmp(DMLrlstype,"DM")==0)
       ||(tc_strcmp(DMLrlstype,"Released BOM Quantity Update")==0)||(tc_strcmp(DMLrlstype,"RBQU")==0)
       )
	   
	  {
		   ITK_CALL(EPM_find_template2("Change Request Life Cycle",0,&template_tag));
		   ITK_CALL(EPM_create_process("Change Request Life Cycle","",template_tag,1, &DMLTag,&attachment_types,&test_job_a));
	  }
	  else if((tc_strcmp(DMLrlstype,"Vehicle Release")==0) || (tc_strcmp(DMLrlstype,"Veh")==0))
	  {
		   ITK_CALL(EPM_find_template2("VC/CCV Release Workflow",0,&template_tag));
		   ITK_CALL(EPM_create_process("VC/CCV Release Workflow","",template_tag,1, &DMLTag,&attachment_types,&test_job_a));
	  }
	  else if((tc_strcmp(DMLrlstype,"Module Master Data Management Request")==0) || (tc_strcmp(DMLrlstype,"MMDMR")==0))
	  {
		   ITK_CALL(EPM_find_template2("ECU MDM Attribute",0,&template_tag));
		   ITK_CALL(EPM_create_process("ECU MDM Attribute","",template_tag,1, &DMLTag,&attachment_types,&test_job_a));
	  }
	  else if((tc_strcmp(DMLrlstype,"VCID Update")==0) || (tc_strcmp(DMLrlstype,"CCU")==0))
	  {
		   ITK_CALL(EPM_find_template2("CCID Update",0,&template_tag));
		   ITK_CALL(EPM_create_process("CCID Update","",template_tag,1, &DMLTag,&attachment_types,&test_job_a));
	  }
	  else if((tc_strcmp(DMLrlstype,"Spare Indicator Update")==0) || (tc_strcmp(DMLrlstype,"SPIUP")==0))
	  {
		   ITK_CALL(EPM_find_template2("Spare indicator updation Task WF",0,&template_tag));
		   ITK_CALL(EPM_create_process("Spare indicator updation Task WF","",template_tag,1, &DMLTag,&attachment_types,&test_job_a));
	  }
	  else if((tc_strcmp(DMLrlstype,"VC/Module Master Data Update")==0) || (tc_strcmp(DMLrlstype,"VCMDU")==0))
	  {
		   ITK_CALL(EPM_find_template2("VC_Module Master Data Update",0,&template_tag));
		   ITK_CALL(EPM_create_process("VC_Module Master Data Update","",template_tag,1, &DMLTag,&attachment_types,&test_job_a));
	  }
	
   }


if(DMLrlstype)
{
	MEM_free(DMLrlstype);
}
}
	return 0;
}
//DCR task creation logic End.
