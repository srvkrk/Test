/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: CorrectDMLRlzst.c
**
** Functions:- 	This utility takes DML No and DR_status as input from file and updates the value of DR_status attribute for latest revision of
				DML found from input and writes appropriate information into output file.
**
**
**	Date							Author							Modification
**	6-Dec-2025						Mohan Tayade					ERC_Released_Status_staming
**
** command to run:
	/user/cvprod/TC_ROOT14/tcldPatch/tcPatchExecutable CorrectDMLRlzst
** ./CorrectDMLRlzst -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -file=<Filename>
	nohup ./CorrectDMLRlzst -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -fromdate=10-Oct-2024 -todate=15-Oct-2024 > datecorrect_14.txt &
**
***********************************************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#define PROP_UIF_set_value_msg		"PROP_UIF_set_value"
#include <tccore/aom.h>
#include <res/res_itk.h>
//#include <bom/bom.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <tccore/releasestatus.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <tcinit/tcinit.h>
#include <tccore/aom_prop.h>
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define PROP_UIF_set_value_msg		"PROP_UIF_set_value"

FILE 		*output 			= NULL;
char		*sep				= ",";
int read_value_from_file(char*);
int DML_LC_Correct_fun(char*);
int write_info(char*, char*, char*);
int GetLastSevDayRelDML1();
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -pf=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<filename> (required)\n"
        );
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
					It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* Filename					= NULL;
	char			* sObjno					= NULL;
	char			* sProperty					= NULL;
	char			* sValue					= NULL;
	char			Data[100]					= "";
	char* fromdate     = NULL;
	char* todate       = NULL;
	char* fromDateUpdate  =   NULL;
	char* toDateUpdated   =   NULL;

	char 			*test						= (char*)MEM_alloc(sizeof(char) * 500);
	char			outputFile[200]				= "";

	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");
	//fromdate        = ITK_ask_cli_argument("-fromdate=");
	//todate          = ITK_ask_cli_argument("-todate=");
	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);


	ifail = ITK_auto_login();
	
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");	
		if(tc_strcmp(Filename,NULL)!=0)
		{
			printf("\n Inside read_value_from_file call \n\n");
			ifail = read_value_from_file(Filename);
		}
		else
		{
			printf("\n Inside  GetLastSevDayRelDML1 call \n\n");
			GetLastSevDayRelDML1();
		}
	}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

//	output = fopen(outputFile,"a+");
//	if (output == NULL)
//	{
//		printf("ERROR: Cannot open File\n");
//		return -1;
//	}
//	else
//		{
//			printf("File opened successfully...!!\n");
//		}
//
//		tc_strcpy(test, "");
//		tc_strcpy(test,"DML_No");
//		tc_strcat(test,sep);
//		tc_strcat(test,"Property");
//		tc_strcat(test,sep);
//		tc_strcat(test,"Value");
//
//		fprintf(output,"%s\n",test);
//		MEM_free(test);
	
		
		

	printf("\nEnd of program.....!!\n\n");
	printf("\n*****************************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}
int GetLastSevDayRelDML1()
{
	int j = 0;
	int n_entries = 3;
	int resultCount = 0;
	char *DMLno = NULL;
	char *DMLname = NULL;
	char **qry_values     =  (char **) MEM_alloc(50 * sizeof(char *));
	tag_t queryTag = NULLTAG;
	tag_t DMLReleaseTag = NULLTAG;
	tag_t *ReleasedDML = NULLTAG;
	//char *qry_entries[3] = {"Created After","Created Before","Type"};
	char *qry_entries[3] = {"Released After","Released Before","Type"};
			printf("Insied the GetLastSevDayRelDML1 0000!!");fflush(stdout);

	time_t now;
    struct tm *local_time;
    now = time(NULL);
    local_time = localtime(&now);

    // Get today's date
    char today[12];
    strftime(today, sizeof(today), "%d-%b-%Y", local_time);
    printf("Today's date: [%s]\n", today);
	printf("Insied the GetLastSevDayRelDML 000022222");fflush(stdout);

    // Get the date of 7 days ago
    time_t seven_days_ago = now - (7 * 24 * 3600); // Subtract 7 days in seconds
    struct tm *seven_days_ago_tm = localtime(&seven_days_ago);
    char seven_days_ago_str[12];
    strftime(seven_days_ago_str, sizeof(seven_days_ago_str), "%d-%b-%Y", seven_days_ago_tm);
    printf("7 days ago:[%s]\n", seven_days_ago_str);

	
	if(QRY_find2("General...", &queryTag));
	printf("\n\t General... : QRY_find");fflush(stdout);
	if (queryTag != NULLTAG)
	{
		
		qry_values[0] = seven_days_ago_str;
		qry_values[1] = today;
		qry_values[2] = "ERC DML Revision";
		printf("\n\t ERCDMLReleased-Found Query");fflush(stdout);
		if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &ReleasedDML));
		printf("\n\t ERCDMLReleased--resultCount : %d\n", resultCount); fflush(stdout);

		for (j=0;j<resultCount;j++ )
		{
			DMLReleaseTag = ReleasedDML[j];
			if(AOM_ask_value_string(DMLReleaseTag,"object_name",&DMLname));
			if(AOM_ask_value_string(DMLReleaseTag,"item_id",&DMLno));
			printf("\n\t Input DML :%s",DMLno); fflush(stdout);   //Drive, Fuel is a Name if Option family
			DML_LC_Correct_fun(DMLno);
		}
	}
	else
	{
		printf("\n\tDML_Release_Btwn_Dates--Not Found Query");fflush(stdout);
	}
	return 0;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;

	char 			*itemid					= NULL;
	char 			*property				= NULL;
	char 			*value					= NULL;
	char 			temp[200];
	char			outputFile[200]				= "";
	char			Data[100]					= "";
	char 			*test						= (char*)MEM_alloc(sizeof(char) * 500);
	sprintf(outputFile,"%s_output.txt",Data);
	//sprintf(outputFile,"%s_output.txt",Data);

	output = fopen(outputFile,"a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully...!!\n");
		}

		tc_strcpy(test, "");
		tc_strcpy(test,"DML_No");
		tc_strcat(test,sep);
		tc_strcat(test,"Property");
		tc_strcat(test,sep);
		tc_strcat(test,"Value");

		fprintf(output,"%s\n",test);
		MEM_free(test);

	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	printf("\n Inside Input.txt Found"); fflush(stdout);

	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, ",");
				//if(itemid)nlsStrTrimTrailWhiteSpace(itemid);
				printf("\nInput Item_id:%s",itemid); fflush(stdout);

				/*property = strtok(NULL, ",");
				//if(property)nlsStrTrimTrailWhiteSpace(property);
				printf("\nInput rev_id:%s",property); fflush(stdout);

				value = strtok(NULL, ",");
				//if(value)nlsStrTrimTrailWhiteSpace(value);
				printf("\nInput value:%s\n",value);fflush(stdout);*/

				ifail = DML_LC_Correct_fun(itemid);
			}
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");fflush(stdout);
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       update_dr_status
    Description:    This function takes the item_id and attr_value as input and stamps the
					attr_value on specific attribute of all revisions of perticular item.
********************************************************************************************/

int DML_LC_Correct_fun(char* item_id)
{
	int				ifail 						= ITK_ok;
	int				r_count 					= 0;
	int				i		 					= 0;

	tag_t			DML_tag						= NULLTAG;
	tag_t			rev_tag						= NULLTAG;

	char 			*dr_status_new				= NULL;
	char 			*updvalue					= NULL;
	
	int count = 0;
	tag_t parttag = NULLTAG;
	tag_t prtrevtag = NULLTAG;
	tag_t attr_tag = NULLTAG;
	tag_t* status_list = NULLTAG;
	tag_t* status_listt = NULLTAG;
	tag_t	tsk_dml_rel_type	= NULLTAG;
	tag_t	*Task = NULLTAG;
	date_t set_date;
	char* DMLno = NULL;
	char* objType = NULL;
	char* status_name = NULL;
	char* task_id = NULL;
	//char* item_id = NULL;
	tag_t objTypTag			=NULLTAG;
	char* revid1 = NULL;

		int k,k1,x,k2 = 0;
	int num = 0;
	int loc = 1;
	int delStat = 0;
	int count2 = 0;
	int FoundRel = 0;
	int status = 0;
	int n_entries = 1;
	int status_count = 0;
	int RelStusFnd = 0;
	int resultCount1 = 0;
	int FlagRelStat = 0;
	int FlagReltoget = 0;
	int status_countt = 0;

	char *sNOPOFldr = NULL;
	char *DMLNo = NULL;
	char *s_objtype = NULL;
	char **UpdRlzStatus = NULL;
	char *latest_rev_Rel_Stus1 = NULL;
	char *latest_rev_Rel_Stus = NULL;
	char *latest_rev_Rel_Stus2= NULL;
	char *obj_type = NULL;
	//tag_t objTypTag = NULLTAG;
	
	tag_t DMLTag = NULLTAG;
	//tag_t rev_tag = NULLTAG;
	tag_t *ERCDMLRlz = NULLTAG;
	tag_t *secondary_objects = NULLTAG;
	tag_t *relStatus_list = NULLTAG;
	tag_t *chkrelStatus_list = NULLTAG;
	tag_t attRelStatus = NULLTAG;
	tag_t s_relation_type = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t old_form_relation = NULLTAG;
	
	ifail = ITEM_find_item (item_id, &DML_tag);
	ifail = ITEM_ask_latest_rev (DML_tag, &rev_tag);
	if(ifail != ITK_ok)
	{
		printf("Object not found in Teamcenter...!!\n");fflush(stdout);
		return 0;
	}
	else
	{
		printf("\nObject found in Teamcenter........!!\n");fflush(stdout);
		ITKCALL(TCTYPE_ask_object_type(rev_tag,&objTypTag));
		if(objTypTag==NULLTAG)
		{
			printf("\n DML:BBBBB.\n");fflush(stdout);
		}
		ITKCALL(TCTYPE_ask_name2(objTypTag,&objType));
		printf("\n  object_type is %s\n", objType);fflush(stdout);

		if(tc_strcmp(objType,"ChangeRequestRevision")==0)
		{
			//ITKCALL(ITEM_find_revision(parttag,revid1,&rev_tag));
			printf("\n Getting DML no.. ");fflush(stdout);
			// ITKCALL(ITK_string_to_date(inputDate, &set_date));
			if(AOM_ask_value_string(rev_tag,"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
			 printf(" DMLNo : [%s]",DMLNo);fflush(stdout);
			ifail = WSOM_ask_release_status_list(rev_tag, &status_countt, &relStatus_list);
			printf("\n WSOM_ask_release_status_list count is :[%d]",status_countt);fflush(stdout);
			if (status_countt > 0)
			{
				RelStusFnd=0;
				int InDesgLCFlag=0;
				for (k1=0;k1 < status_countt; k1++)
				{
					ifail = AOM_ask_value_string(relStatus_list[k1],"object_name",&latest_rev_Rel_Stus1);
					printf("\n CHECK: Release status is: [%d] : [%s]",k1,latest_rev_Rel_Stus1);fflush(stdout);
					if ((tc_strcmp(latest_rev_Rel_Stus1,"T5_LcsErcRlzd") == 0) ||(tc_strcmp(latest_rev_Rel_Stus1,"ERC Released")==0))
					{
						printf("\n CHECK: ERC Release status found for the DML: [%s]",DMLNo);fflush(stdout);
						RelStusFnd = 1;
						printf("  RelStusFnd: [%d]",RelStusFnd);fflush(stdout);
						//break;
					}
					else if ((tc_strcmp(latest_rev_Rel_Stus1,"T5_LcsReview") == 0) || (tc_strcmp(latest_rev_Rel_Stus1,"ERC Review")==0)|| (tc_strcmp(latest_rev_Rel_Stus1,"In Designer Working")==0)|| (tc_strcmp(latest_rev_Rel_Stus1,"T5_LcsDesignerWorking")==0)|| (tc_strcmp(latest_rev_Rel_Stus1,"In Manager Review")==0))
					{
						printf("\n CHECK: ERC Release status found for the DML: [%s]",DMLNo);fflush(stdout);
						InDesgLCFlag = 1;
						printf("  InDesgLCFlag: [%d]",InDesgLCFlag);fflush(stdout);
						//break;
					}
				}
				//DML: ERC REview/In Des/InMan/      ERC Rel/APL Rel
				if ((RelStusFnd==0)&& (InDesgLCFlag==0))
				{
					printf("\n ERROR:***************** Not Valid case for DML: [%s]",DMLNo);fflush(stdout);
				}
				else if ((RelStusFnd >0)&& (InDesgLCFlag==0))
				{
					printf("\n PASS:***************** Valid case for DML, NO CHANGE: [%s]",DMLNo);fflush(stdout);
				}
				else if ((RelStusFnd >0)&& (InDesgLCFlag >0))
				{
					printf("\n PASS: ERC Rel and In Designer, BOTH LC found...: [%s]",DMLNo);fflush(stdout);
					printf(" and status_countt: [%d]",status_countt);fflush(stdout);
					for (k=0;k < status_countt; k++)
					{
						printf("\n REMOVE: RelStusFnd > 1 ");fflush(stdout);
						ifail = AOM_ask_value_string(relStatus_list[k],"object_name",&latest_rev_Rel_Stus);
						printf("\n REMOVE: Release status: [%d]: [%s]",k,latest_rev_Rel_Stus);fflush(stdout);
					
						if((delStat != 1) &&((tc_strcmp(latest_rev_Rel_Stus,"T5_LcsReview") == 0) || (tc_strcmp(latest_rev_Rel_Stus,"ERC Review")==0)|| (tc_strcmp(latest_rev_Rel_Stus,"In Designer Working")==0)|| (tc_strcmp(latest_rev_Rel_Stus,"T5_LcsDesignerWorking")==0)|| (tc_strcmp(latest_rev_Rel_Stus,"In Manager Review")==0)))
						{
							delStat = 1;

							printf("\n REMOVE: Found release status is : %s\n",latest_rev_Rel_Stus);fflush(stdout);
							(AOM_refresh(rev_tag,1));
							CHECK_FAIL(ITK_set_bypass(true));
							CHECK_FAIL(POM_attr_id_of_attr("release_status_list","ChangeRequestRevision",&attRelStatus));
							CHECK_FAIL(POM_refresh_instances_any_class(1,&rev_tag, POM_modify_lock));
							CHECK_FAIL(POM_clear_attr(1,&rev_tag,attRelStatus));
							CHECK_FAIL(POM_save_instances(1,&rev_tag,true));
							CHECK_FAIL(POM_refresh_instances_any_class(1,relStatus_list,POM_delete_lock));
							CHECK_FAIL(POM_delete_instances(1,relStatus_list));
							(AOM_refresh(rev_tag,0));

							ifail = WSOM_ask_release_status_list(rev_tag, &num, &chkrelStatus_list);
							printf("\n REMOVE: After Update release status of [%s] count is : [%d]\n",DMLNo,num);fflush(stdout);
							break;
						}
						else
						{
							if(delStat == 0)
							{
								printf("\nSKIP: Skipping Release status from Delete [%s]",latest_rev_Rel_Stus);fflush(stdout);
							}
							else
							{
								printf("\nSKIP: DelStat is set to 1, no deletion loop");fflush(stdout);
							}
						}
					}
					//Adding LC to DML
					FoundRel = 0;
					if (delStat == 1)
					{
						int k3 =1;
						printf("\nADD:Inside the delStat ...k3:%d",k3);fflush(stdout);
						//DML: ERC REview/In Des/InMan/      ERC Rel/APL Rel
						for(k2 = 0; k2 < status_countt; k2++)
						{
							ifail = AOM_ask_value_string(relStatus_list[k2],"object_name",&latest_rev_Rel_Stus2);
							printf("\nADD:Inside to set the old release status  [%s]",latest_rev_Rel_Stus2);fflush(stdout);
							if((tc_strcmp(latest_rev_Rel_Stus2,"T5_LcsReview") != 0) && (tc_strcmp(latest_rev_Rel_Stus2,"ERC Review")!=0)&& (tc_strcmp(latest_rev_Rel_Stus2,"In Designer Working")!=0)&& (tc_strcmp(latest_rev_Rel_Stus2,"T5_LcsDesignerWorking")!=0)&& (tc_strcmp(latest_rev_Rel_Stus2,"In Manager Review")!=0))
							{
								printf("\n ADD:ERC Rel or above LC found. for position: [%d].",k3);fflush(stdout);
								if((FoundRel == 0)&&((tc_strcmp(latest_rev_Rel_Stus2,"T5_LcsErcRlzd") == 0)|| (tc_strcmp(latest_rev_Rel_Stus2,"ERC Released")==0)))
								{
									//printf("\ninside222 loop");fflush(stdout);
									ifail = AOM_refresh(rev_tag,1);
									//ifail = RELSTAT_add_release_status(relStatus_list[k2],1,&rev_tag,false);
									ifail = RELSTAT_add_release_status(relStatus_list[k2],1,&rev_tag,false);
									ifail = AOM_save_without_extensions(rev_tag);
									ifail = AOM_refresh(rev_tag,0);
									printf("\nADD:Added Release status [%s] at posiotion [%d]",latest_rev_Rel_Stus2,k3);fflush(stdout);
									k3 ++;
								}
								if((tc_strcmp(latest_rev_Rel_Stus2,"T5_LcsErcRlzd") == 0) || (tc_strcmp(latest_rev_Rel_Stus2,"ERC Released")==0))
								{
									printf("\ninside333 loop");fflush(stdout);
									FoundRel = 1;
								}
								//loc++;
							}
						}
					}
				}
				else if ((RelStusFnd ==0)&& (InDesgLCFlag >0))
				{
					printf("\n Only InDesigner LC for DML: [%s] checking eligibility..",DMLNo);fflush(stdout);
					//Seting task Status to DML
					if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
					if(GRM_list_secondary_objects_only(rev_tag,tsk_dml_rel_type,&count,&Task)!=ITK_ok)PrintErrorStack();
					printf("\n Task_count = %d  \n",count);fflush(stdout);
					int ii =0;
					int i =0;
					int jj =0;
					int j =0;
					int status_counte =0;
					int InDesgRelTaskFlag=0;
					//Checking eligible DML..
					printf("\n CHECK2: if task is release...");fflush(stdout);
					for(ii =0 ; ii < count; ii++)
					{
						if(AOM_ask_value_string(Task[ii],"item_id",&task_id)!=ITK_ok)PrintErrorStack();
						printf("\n CHECK2:Task ID Name is = %s  \n",task_id);fflush(stdout);
						if (tc_strlen(task_id) == 13)
						{
							ITKCALL( WSOM_ask_release_status_list(Task[ii],&status_counte,&status_listt));
							for(jj =0 ; jj < status_counte; jj++)
							{
								ITKCALL(AOM_ask_value_string(status_listt[jj], "object_name", &status_name));
								printf("\nCHECK2:Status Name is = %s  \n",status_name);fflush(stdout);
								if ((tc_strcmp(status_name,"T5_LcsErcRlzd") == 0) ||(tc_strcmp(status_name,"ERC Released")==0))
								{
									InDesgRelTaskFlag=1;
									printf("\n CHECK2:Task status: [%s]  InDesgRelTaskFlag= [%d]",status_name,InDesgRelTaskFlag);fflush(stdout);
									break;
								}
							}
							break;
						}
					}
					if(InDesgRelTaskFlag >0)
					{
						printf("\n\n REMOVE2: Going to set DML LC count: [%d]",status_countt);fflush(stdout);
						for (k=0;k < status_countt; k++)
						{
							printf("\n REMOVE2: RelStusFnd > 1 ");fflush(stdout);
							ifail = AOM_ask_value_string(relStatus_list[k],"object_name",&latest_rev_Rel_Stus);
							printf("\n REMOVE2: Release status: [%d]: [%s]",k,latest_rev_Rel_Stus);fflush(stdout);
						
							if((delStat != 1) &&((tc_strcmp(latest_rev_Rel_Stus,"T5_LcsReview") == 0) || (tc_strcmp(latest_rev_Rel_Stus,"ERC Review")==0)|| (tc_strcmp(latest_rev_Rel_Stus,"In Designer Working")==0)|| (tc_strcmp(latest_rev_Rel_Stus,"T5_LcsDesignerWorking")==0)|| (tc_strcmp(latest_rev_Rel_Stus,"In Manager Review")==0)))
							{
								delStat = 1;

								printf("\n REMOVE2: Found release status is : %s\n",latest_rev_Rel_Stus);fflush(stdout);
								(AOM_refresh(rev_tag,1));
								CHECK_FAIL(ITK_set_bypass(true));
								CHECK_FAIL(POM_attr_id_of_attr("release_status_list","ChangeRequestRevision",&attRelStatus));
								CHECK_FAIL(POM_refresh_instances_any_class(1,&rev_tag, POM_modify_lock));
								CHECK_FAIL(POM_clear_attr(1,&rev_tag,attRelStatus));
								CHECK_FAIL(POM_save_instances(1,&rev_tag,true));
								CHECK_FAIL(POM_refresh_instances_any_class(1,relStatus_list,POM_delete_lock));
								CHECK_FAIL(POM_delete_instances(1,relStatus_list));
								(AOM_refresh(rev_tag,0));

								ifail = WSOM_ask_release_status_list(rev_tag, &num, &chkrelStatus_list);
								printf("\n REMOVE2: After Update release status of [%s] count is : [%d]\n",DMLNo,num);fflush(stdout);
								break;
							}
							else
							{
								if(delStat == 0)
								{
									printf("\nSKIP2: Skipping Release status from Delete [%s]",latest_rev_Rel_Stus);fflush(stdout);
								}
								else
								{
									printf("\nSKIP2: DelStat is set to 1, no deletion loop");fflush(stdout);
								}
							}
						}
						//Adding LC status from task...
						printf("\n ADD2: As task is release...");fflush(stdout);
						for(i =0 ; i < count; i++)
						{
						   //24CU111222_00
							if(AOM_ask_value_string(Task[i],"item_id",&task_id)!=ITK_ok)PrintErrorStack();
							printf("\n ADD2:Task ID Name is = %s  \n",task_id);fflush(stdout);
							if (tc_strlen(task_id) == 13)
							{
								ITKCALL( WSOM_ask_release_status_list(Task[i],&status_count,&status_list));
								for(j =0 ; j < status_count; j++)
								{
									ITKCALL(AOM_ask_value_string(status_list[j], "object_name", &status_name));
									printf("\n ADD2:Status Name is = %s  \n",status_name);fflush(stdout);
									if ((tc_strcmp(status_name,"T5_LcsErcRlzd") == 0) ||(tc_strcmp(status_name,"ERC Released")==0))
									{
										printf("\n ADD2:GOing to add Release status [%s]  j= [%d]",status_name,j);fflush(stdout);
										ifail = AOM_refresh(rev_tag,1);
										ifail = RELSTAT_add_release_status(status_list[j],1,&rev_tag,false);
										ifail = AOM_save_without_extensions(rev_tag);
										ifail = AOM_refresh(rev_tag,0);
										printf("\n ADD2:Added Release status [%s]  j= [%d]",status_name,j);fflush(stdout);
										break;
									}
								}
								break;
							}
						}
					}
					else
					{
						printf("\n PASS:***************** WIP DML, NO CHANGE: [%s]",DMLNo);fflush(stdout);
					}
				}
			}
			else
			{
				printf("\n NULL_LC:DML NULL_LC: STATUS CASE....\n");fflush(stdout);
				//Seting task Status to DML
				if(GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type)!=ITK_ok)PrintErrorStack();
				if(GRM_list_secondary_objects_only(rev_tag,tsk_dml_rel_type,&count,&Task)!=ITK_ok)PrintErrorStack();
				printf("\n NULL_LC:Task_count = %d  \n",count);fflush(stdout);
				int i =0;
				int j =0;
				int status_count =0;
				for(i =0 ; i < count; i++)
				{
				   //24CU111222_00
					if(AOM_ask_value_string(Task[i],"item_id",&task_id)!=ITK_ok)PrintErrorStack();
					printf("\n NULL_LC:Task ID Name is = %s  \n",task_id);fflush(stdout);
					if (tc_strlen(task_id) == 13)
					{
						ITKCALL( WSOM_ask_release_status_list(Task[i],&status_count,&status_list));
						printf("\nNULL_LC:status_count = %d  \n",status_count);fflush(stdout);
						for(j =0 ; j < status_count; j++)
						{
							ITKCALL(AOM_ask_value_string(status_list[j], "object_name", &status_name));
							printf("\nNULL_LC:Status Name is = %s  \n",status_name);fflush(stdout);
							if ((tc_strcmp(status_name,"T5_LcsErcRlzd") == 0) ||(tc_strcmp(status_name,"ERC Released")==0))
							{
								printf("\n NULL_LC:GOing to add Release status [%s]  j= [%d]",status_name,j);fflush(stdout);
								//erc relesed stamp
								//CALLAPI( RELSTAT_create_release_status(lcsToset, &status2));
								// CALLAPI(AOM_ask_name(status2, &ReleaseStatus));
								// printf("\n ******************* ReleaseStatus: %s\n", ReleaseStatus)fflush(stdout);

								//CALLAPI(RELSTAT_add_release_status(status2, 1, &DMLTag, retain));

								//printf("\n Released Status matched \n");fflush(stdout);

								ifail = AOM_refresh(rev_tag,1);
								ifail = RELSTAT_add_release_status(status_list[j],1,&rev_tag,false);
								ifail = AOM_save_without_extensions(rev_tag);
								ifail = AOM_refresh(rev_tag,0);
								printf("\nNULL_LC:Added Release status [%s]  j= [%d]",status_name,j);fflush(stdout);

								//ITKCALL(POM_attr_id_of_attr("date_released", "ItemRevision", &attr_tag)); //date_released
								//ITKCALL(POM_refresh_instances_any_class(1, &status_list, POM_modify_lock));
								//ITKCALL(POM_set_attr_date(1, &status_list, attr_tag, set_date));  
								//ITKCALL(POM_save_instances(1, &status_list, true));
								//printf("\n Released status Date Stamped \n");fflush(stdout);
								break;
							}
						}
						break;
					}
				}
			}
		}
		
		printf("\n**********Done*************\n");fflush(stdout);
	}
	MEM_free(dr_status_new);

	return ifail;
}
