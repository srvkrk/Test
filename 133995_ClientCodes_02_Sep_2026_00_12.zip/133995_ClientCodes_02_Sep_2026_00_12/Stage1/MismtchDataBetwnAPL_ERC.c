#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;


FILE		*output 			= NULL;

char		*sep				= "^";

int read_value_from_file(char*);
int add_design_group(char*);
int find_apl_dml(tag_t);

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"design_grp_task_update -u=<username> -pf=<password file path> -g=<group> -file=<file_name>\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}


/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int status;
	int				ifail 						= ITK_ok;
	//char			* userid 					= NULL;
	//char			* password					= NULL;
	//char			* group						= NULL;
	char			* Filename					= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	char          *dml_no                      =NULL;
	char			*sTaskGrp					= NULL;
	char			*task_id					    = NULL;
	char			*release_status					    = NULL;
	char			*ERC_release_date					    = NULL;

    
	Filename = (char *) MEM_alloc( 50 * sizeof(char) );
	tc_strcpy(Filename,"");
	tc_strcat(Filename,"//user//uaprod//Priya//mismatchTaskData//input.txt");
	
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.xls",Data);

ITK_CALL(ITK_set_journalling( TRUE ));
ITK_CALL(ITK_initialize_text_services (0));
printf("\n\n\t Attempting Logging\n ");

ifail=ITK_CALL(ITK_auto_login());
if(ifail!=ITK_ok)
  {
	  printf("\n\n\t OMG Login Not Successfull\n ");
  }
  else
	{
	  printf("\n\n\t Login Successfull\n ");
	}
	
	output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully.\n");
			fprintf(output,"%-10s\t  %-10s\t    %-15s\t  %-10s\t  %-10s\t  ","ERC DML","Design Group","ERC Task","Release Type","Release Date");fflush(output);
			//fprintf(output,"\n %-10s\t  %-10s\t    %-15s\t  %-10s\t  %-10s\t ","APL DML","Design Group","APL Task","Release Type","Release Date");fflush(output);
				
		}
		
		ifail = read_value_from_file(Filename);
		//CHECK_FAIL;
		
	printf("\n*********************");
	printf("\nEnd of program.....!!");
	printf("\n*********************\n");
	ifail = ITK_exit_module(true);
	
	return ifail;
}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;
	
	char 			*itemid					= NULL;
	char 			*design_group			= NULL;
	char 			*dr_status				= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "");
				printf("\nInput Item_id:%s",itemid);	
				
				
				ifail = add_design_group(itemid);
			}			
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	fclose(output);
	return ifail;
}

/**********************************************************************************************
    Function:       add_design_group
    Description:    This function queries the dml in teamcenter and checks for closure date,
					if found null then stamps released date on closure date of dml revision.
**********************************************************************************************/
int add_design_group(char* dml_no)
{
	int				ifail 						= ITK_ok;
	int				i	 						= 0;
	int				m	 						= 0;
	int				k	 						= 0;
	int				count	 				= 0;
	int				task_count			= 0;
	char			*entry0						= "Name";
	char			*entry1						= "Type";
	char			*obj_name					= "*";
	char			*obj_type					= "ERC DML";
	char			*closure_date1				= NULL;
	char			*release_date1				= NULL;
	char			*sTask1Grp					= NULL;
	char			*sTaskGrp					= NULL;
	char			*task_id					    = NULL;
	char			*release_status					    = NULL;
	char			*ERC_release_date					    = NULL;
	char			**design_grp_list			= NULL;
	char 		    *Type					        = NULL;
	char           ERCTask_ID[5]={'\0'};
	date_t			closure_date				= NULLDATE;
	date_t			release_date				= NULLDATE;
	tag_t			relation					= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	tag_t			dml_tag						= NULLTAG;
	tag_t			attr_id						= NULLTAG;
	tag_t			*task_tag					= NULLTAG;
	tag_t	       objTypeTag				=	NULLTAG;
	tag_t	         TaskRevTag				=	NULLTAG;	

   

	ifail = ITEM_find_item(dml_no, &dml_tag);
	printf("\n DML input find....");
	if(ifail != ITK_ok)
	{
		printf("Object not found in Teamcenter...!!\n");fflush(stdout);
		return 0;
	}
	ifail = ITEM_ask_latest_rev(dml_tag, &rev_tag);
	printf("\n DML input find222222....");
	
  //****************Traversing from DML to task********************//

	ifail = GRM_find_relation_type("T5_DMLTaskRelation", &relation);
	CHECK_FAIL;
	ifail = GRM_list_secondary_objects_only(rev_tag, relation, &task_count, &task_tag);
	printf("\n Task_count:%d", task_count);fflush(stdout);
    
	if(task_count > 0)
		{
			m=0;
			for(k=0;k<task_count;k++)
			{
			TaskRevTag = task_tag[k];
			
			ifail = AOM_ask_value_string(TaskRevTag, "object_type", &Type);  
			printf("\n Type : %s",Type);fflush(stdout);
			
			if (tc_strcmp(Type,"T5_APLDMLRevision") == 0)
			{
				ifail = find_apl_dml(TaskRevTag);
			}
			else
			{
				printf("\n A1 m:%d k:%d", m,k);fflush(stdout);
				ifail = AOM_UIF_ask_value(TaskRevTag, "item_id", &task_id);
				if (tc_strcmp(Type,"T5_ChangeTaskRevision") == 0)
				{
					printf("\nERC Task Id:%s", task_id);fflush(stdout);
				}
				ifail = AOM_UIF_ask_value(TaskRevTag, "release_status_list", &release_status);
				printf("\nrelease_status:%s", release_status);fflush(stdout);
				ifail = AOM_UIF_ask_value(TaskRevTag, "date_released", &ERC_release_date);
				printf("\nERC_release_date:%s", ERC_release_date);fflush(stdout);
	 
				if(strlen(task_id) > 13)
				{
					printf("\n A2 m:%d k:%d", m,k);fflush(stdout);
					
				}
				else
				{
					printf("\n A3 m:%d  k:%d", m,k);fflush(stdout);
					
					tc_strcpy(ERCTask_ID,task_id);
				    printf("\n ERCTask_ID : %s\n",ERCTask_ID );fflush(stdout);
					sTask1Grp		= NULL;
					sTaskGrp		= NULL;
					sTask1Grp		= strtok(ERCTask_ID, "_" );
					sTaskGrp		= strtok( NULL, " " );
	
					printf("\n\tTaskGrp:[%s]",sTaskGrp);fflush(stdout);
		 
					/*printf("\n A5 m:%d  k:%d\n ", m,k);fflush(stdout);
					//ifail = AOM_refresh(rev_tag, 1);
					//ifail = AOM_set_value_string_at(rev_tag, "t5_crdesigngroup", count, sTaskGrp);
					ifail = AOM_set_value_string_at(rev_tag, "t5_crdesigngroup", m, sTaskGrp);
					//ifail = AOM_save(rev_tag);
					//ifail = AOM_refresh(rev_tag, 0);
					m++;
					printf("\n A6 m:%d  k:%d\n", m,k);fflush(stdout);*/
	
					}
			}
		}
			/*else
			{
				printf("\nTask not found of DML...!!\n");
				return 0;
			}*/
	}

	              if (tc_strcmp(sTaskGrp,"NULL")==0)
					{
					 sTaskGrp="-";
					 }
					 if (tc_strcmp(task_id,"NULL")==0)
				    {
					 task_id="-";
					 }
					 if (tc_strcmp(release_status,"NULL")==0)
				    {
					 release_status="-";
					 }
					  if (tc_strcmp(ERC_release_date,"NULL")==0)
				    {
					 ERC_release_date="-";
					 }
	                
	               ifail = AOM_UIF_ask_values(rev_tag, "t5_crdesigngroup", &count, &design_grp_list);
					printf("\nTotal design_group of ERC DML found : [%d]\n",count);fflush(stdout);

			fprintf(output,"\n %-10s\t  %-10s\t    %-15s\t  %-10s\t  %-10s\t ",dml_no,sTaskGrp,task_id,release_status,ERC_release_date);fflush(output);
	

	return ifail;
}


/**********************************************************************************************
    Function:       find_apl_dml
    Description:    This function find the APL dml through ERC DML.
**********************************************************************************************/
int find_apl_dml(tag_t TaskRevTag)
{
	int				ifail 						= ITK_ok;
	int				Atask_count			= 0;
	int				A1task_count		= 0;
	int                    i                    =0;
	int                 count1                   =0;

	tag_t			*Atask_tag					= NULLTAG;
	tag_t			*A1task_tag					= NULLTAG;
	tag_t			relation					        = NULLTAG;
	//tag_t			relation1					        = NULLTAG;

	char			*task_id1					= NULL;
	char			*release_status1		= NULL;
	char			*APL_release_date	= NULL;
	char			**design_grp_list1	= NULL;
	char			*APLTask1Grp			= NULL;
	char			*APLDML			    = NULL;
	char          *APLDMLTask        =NULL;
	char			*APLTaskGrp			= NULL;
	char			*dml_no			        = NULL;
	char           Task_ID[5]={'\0'};
	//char          *Task_ID_tokenized	 =NULL;
	//char		    *DsgNO                   =NULL;
										char         *PltNm   =NULL;
	//tag_t			*task_tag					= NULL;

 fprintf(output,"\n %-10s\t  %-10s\t    %-15s\t  %-10s\t  %-10s\t ","APL DML","Design Group","APL Task","Release Type","Release Date");fflush(output);

  ifail = GRM_find_relation_type("T5_DMLTaskRelation", &relation);
  CHECK_FAIL;
  ifail = GRM_list_secondary_objects_only(TaskRevTag, relation, &Atask_count, &Atask_tag);
  printf("\n APL Task_count:%d", Atask_count);fflush(stdout);
  if(Atask_count > 0)
	{
	     i=0;
		for(i=0;i<Atask_count;i++)
		{
			printf("\n A2  i:%d",i);fflush(stdout);

			ifail = AOM_UIF_ask_value(Atask_tag[i], "item_id", &task_id1);
			printf("\n APL Task Id:%s", task_id1);fflush(stdout);
			ifail = AOM_UIF_ask_value(Atask_tag[i], "release_status_list", &release_status1);
			printf("\n APL Task release_status:%s", release_status1);fflush(stdout);
			ifail = AOM_UIF_ask_value(Atask_tag[i], "date_released", &APL_release_date);
			printf("\n APL_release_date:%s", APL_release_date);fflush(stdout);
		}
		         // fprintf(output,"\n APL Task:%s\t",task_id1);fflush(output);
		            tc_strcpy(Task_ID,task_id1);
				    printf("\n Task_ID : %s\n",Task_ID );fflush(stdout);
		            APLTask1Grp		= NULL;
					APLTaskGrp		= NULL;
					APLTask1Grp		= strtok(Task_ID, "_" );
					APLTaskGrp		= strtok( NULL, "_" );
					APLTaskGrp		= strtok( APLTaskGrp, "_" );
                    printf("\n\t APL TaskGrp:[%s]",APLTaskGrp);fflush(stdout);

					//APLDML    =NULL;
					//APLDML		= strtok(Task_ID, "_" );
					//printf("\n\t APL DML NO.:[%s]",APLDML);fflush(stdout);

                  /*tc_strcpy(Task_ID,task_id1);
				    printf("\n Task_ID : %s\n",Task_ID );fflush(stdout);
					
				   //Finding APL DML
					Task_ID_tokenized=strtok(task_id1,"_");
					printf("Tokenized DML Number Obtained=%s\n",Task_ID_tokenized);fflush(stdout);
					DsgNO=strtok(NULL,"_");
					printf("\n DsgNO : %s",DsgNO); fflush(stdout);
					//tc_strcat(Task_ID_tokenized,APLDMLNO);
					PltNm=strtok(NULL," ");
					printf("\n PltNm : %s\n",PltNm); fflush(stdout);

					if (tc_strcmp(APLDMLTask,"NULL")==0) MEM_free(APLDMLTask);
				    APLDMLTask = (char *) MEM_alloc( 100 * sizeof(char) );
					tc_strcpy(APLDMLTask,"");
					tc_strcat(APLDMLTask,task_id1);
					tc_strcat(APLDMLTask,"_");
					tc_strcat(APLDMLTask,DsgNO);
					tc_strcat(APLDMLTask,"_");
					tc_strcat(APLDMLTask,PltNm);
					printf("\n APLDMLTask : %s\n",APLDMLTask); fflush(stdout);*/
                     
					 
		ifail = AOM_UIF_ask_value(TaskRevTag, "item_id", &APLDML);
		printf("\n APLDML:%s", APLDML);fflush(stdout);

		ifail = AOM_UIF_ask_values(TaskRevTag, "t5_crdesigngroup", &count1, &design_grp_list1);
		printf("\nTotal design_group of APL DML found : [%d]\n",count1);fflush(stdout);
	}

	
	fprintf(output,"\n %-10s\t  %-10s\t    %-15s\t  %-10s\t  %-10s\t ",APLDML,APLTaskGrp,task_id1,release_status1,APL_release_date);fflush(output);
	

return ifail;
}
   
   