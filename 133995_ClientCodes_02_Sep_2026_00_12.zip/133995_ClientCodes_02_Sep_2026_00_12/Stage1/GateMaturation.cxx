/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: GateMaturation.c hello
**
** Functions:- This utility takes item_id and attribute_value as input from file and updates the value of specific attribute of latest revision of perticular
			   item found from input item_id and writes appropriate information into output file.
**
**
**	Date							Author								Modification
**	16-November-2017				Kalpesh Gondhali					Code creation
**	17-November-2017				Kalpesh Gondhali					Modify(Creation of output_log file)
**  27-March-2018					Kalpesh Gondhali					DR Status Updation
**
** command to run:
** GateMaturation -u=<username> -p=<password> -g=<group> -file=<Filename>
***********************************************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include<ae/ae.h>
#include<ae/ae_types.h>
#include<ae/dataset.h>
#include<ae/dataset_msg.h>
#include<ae/datasettype.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
//#include <tccore/imantype.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <vector>
#include <tccore/project.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <cfm/cfm.h>
#include <qry/qry.h>
#include <pie/pie.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <stdlib.h>
#include <epm/epm.h>
//#include <itk/mem.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <sa/tcfile.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <string.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <sa/imanfile.h>
//#include <tc/iman.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>

#define PROP_UIF_set_value_msg		"PROP_UIF_set_value"
#define PROP_set_value_tag_msg		"PROP_set_value_tag"
#define PROP_set_value_string_msg   "PROP_set_value_string"
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

using namespace std;
int error_code	= ITK_ok;
FILE 		*output 			= NULL;
char		*sep				= ",";

int read_value_from_file(char*);
//int getChildren(tag_t chlidlineTag , vector<tag_t> &vChildlines );
int getChildren(tag_t chlidlineTag , vector<tag_t> &vChildlines,vector<tag_t> &vCol,int ECUPart);
int getChildrenCol(tag_t chlidlineTag , vector<tag_t> &vChildlines,vector<tag_t> &vCol);
int getChildrenColSnapShot(tag_t chlidlineTag , vector<tag_t> &vChildlines,vector<tag_t> &vCol);
int t5GetItemRevison(char* InputPart);
int CreateRelFun(tag_t objTag, char* Toplnt, char*  PrtDRst, char*  PrtMLst,tag_t rev_tag, char * ProjInfo);
//int CreateRelFun(tag_t objTag, char* Toplnt, char*  PrtDRst, char*  PrtMLst,tag_t rev_tag);
//int CreateRelFunMLStatus(tag_t objTag, char* Toplnt, char*  PrtDRst, char*  PrtMLst,tag_t rev_tag, char * ProjInfo,int PartMSStatusFlagDup);
int CreateRelFunMLStatus(tag_t objTag, char* Toplnt, char*  PrtDRst, char*  PrtMLst,tag_t rev_tag, char * ProjInfo);
//int CreateRelFunMLStatus(tag_t objTag, char* Toplnt, char*  PrtDRst, char*  PrtMLst,tag_t rev_tag);
int tm_ChkFLChldDRstatus(tag_t TaskTag,char* part_no,char* DmlNumb,char* DmlFromDR,char* DmlToDR);
int FolderEmpty(tag_t FlTag);
//int GateMaturation(char*, char*);
int GateMaturation(char*);
int write_info(char*, char*, char*);
int iLevel = 1;
void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<filename> (required)\n"
        );fflush(stdout);
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	//char *retStringf;
	//retStringf = (char*) malloc(200);
	  char *retStringf = (char *) MEM_alloc(20 * sizeof(char));
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
int CheckNonColDRStatus(tag_t ColPrtrev_tag, char* Toplnt)
{
	int		ifail 			= ITK_ok;
	int		CreatAllowNONCLPrt = 0;
	int     VehNONColcount      =  0;
	tag_t	*VehNONColPart_tag		= NULL;
	ifail = AOM_ask_value_tags(ColPrtrev_tag,"TC_Is_Represented_By",&VehNONColcount,&VehNONColPart_tag);
	 printf(" VehNONColcount %d\n",VehNONColcount);fflush(stdout);
	if(VehNONColcount>0)
	{
		
		int NonclrprtCount=0;		
		for (NonclrprtCount=0;NonclrprtCount<VehNONColcount;NonclrprtCount++ )
				{
					CreatAllowNONCLPrt = 0;
					tag_t   VehNONColPart_tagObj     = NULLTAG;
					
					char*	 NonColPartNo = NULL;
					char*	 NonColPartRev = NULL;
					char*	 NonColPartPrtType = NULL;
					char*	 NonColPrtDRStatus = NULL;
					
					


					VehNONColPart_tagObj=VehNONColPart_tag[NonclrprtCount];
					AOM_ask_value_string(VehNONColPart_tagObj,"item_id",&NonColPartNo);
					AOM_ask_value_string(VehNONColPart_tagObj,"item_revision_id",&NonColPartRev);
					AOM_ask_value_string(VehNONColPart_tagObj,"t5_PartType",&NonColPartPrtType);
					AOM_ask_value_string(VehNONColPart_tagObj,"t5_PartStatus",&NonColPrtDRStatus);
					
					printf("\n NonColour part Number:%s ",NonColPartNo);fflush(stdout);
					printf("\n NonColour part rev:%s ",NonColPartRev);fflush(stdout);
					printf("\n NonColour part Type:%s ",NonColPartPrtType);fflush(stdout);
					printf("\n NonColour part DR Status:%s ",NonColPrtDRStatus);fflush(stdout);
					
					printf("\n CheckNonColDRStatus : Toplnt:[%s] NonColPrtDRStatus:[%s]", Toplnt,NonColPrtDRStatus);fflush(stdout);
					if((tc_strcmp(NonColPrtDRStatus,"")==0) || (tc_strcmp(NonColPrtDRStatus,"NA")==0))
					{
						CreatAllowNONCLPrt=2;
						printf("NAcase:Flag is [%d]\n",CreatAllowNONCLPrt);fflush(stdout);
					}
					//Parts For Gate Maturation
					else if(((tc_strcmp(Toplnt,"DR5")==0)|| (tc_strcmp(Toplnt,"AR5")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR4")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR4")==0)))
					{
						CreatAllowNONCLPrt=1;
						printf("1CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					//Immaturated DR Status Parts
					else if(((tc_strcmp(Toplnt,"DR5")==0)|| (tc_strcmp(Toplnt,"AR5")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR3")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR3")==0)|| (tc_strcmp(NonColPrtDRStatus,"DR2")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR2")==0)|| (tc_strcmp(NonColPrtDRStatus,"DR1")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR1")==0)|| (tc_strcmp(NonColPrtDRStatus,"DR0")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR0")==0)|| (tc_strcmp(NonColPrtDRStatus,"DR3P")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR3P")==0)))
					{
						CreatAllowNONCLPrt=2;
						printf("2CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					//Parts For Gate Maturation
					else if(((tc_strcmp(Toplnt,"DR4")==0)|| (tc_strcmp(Toplnt,"AR4")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR3P")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR3P")==0)|| (tc_strcmp(NonColPrtDRStatus,"DR3")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR3")==0)))
					{
						CreatAllowNONCLPrt=1;
						printf("3CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					//Immaturated DR Status Parts
					else if(((tc_strcmp(Toplnt,"DR4")==0)|| (tc_strcmp(Toplnt,"AR4")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR2")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR2")==0)|| (tc_strcmp(NonColPrtDRStatus,"DR1")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR1")==0)|| (tc_strcmp(NonColPrtDRStatus,"DR0")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR0")==0)))
					{
						CreatAllowNONCLPrt=2;
						printf("4CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					//Parts For Gate Maturation
					else if(((tc_strcmp(Toplnt,"DR3P")==0)|| (tc_strcmp(Toplnt,"AR3P")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR3")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR3")==0)))
					{
						CreatAllowNONCLPrt=1;
						printf("5CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					//Immaturated DR Status Parts
					else if(((tc_strcmp(Toplnt,"DR3P")==0)|| (tc_strcmp(Toplnt,"AR3P")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR2")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR2")==0)|| (tc_strcmp(NonColPrtDRStatus,"DR1")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR1")==0)|| (tc_strcmp(NonColPrtDRStatus,"DR0")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR0")==0)))
					{
						CreatAllowNONCLPrt=2;
						printf("6CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					//Parts For Gate Maturation
					else if(((tc_strcmp(Toplnt,"DR3")==0)|| (tc_strcmp(Toplnt,"AR3")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR2")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR2")==0)))
					{
						CreatAllowNONCLPrt=1;
						printf("7CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					//Immaturated DR Status Parts
					else if(((tc_strcmp(Toplnt,"DR3")==0)|| (tc_strcmp(Toplnt,"AR3")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR1")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR1")==0)|| (tc_strcmp(NonColPrtDRStatus,"DR0")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR0")==0)))
					{
						CreatAllowNONCLPrt=2;
						printf("8CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					//Parts For Gate Maturation
					else if(((tc_strcmp(Toplnt,"DR2")==0)|| (tc_strcmp(Toplnt,"AR2")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR1")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR1")==0)))
					{
						CreatAllowNONCLPrt=1;
						printf("9CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					//Immaturated DR Status Parts
					else if(((tc_strcmp(Toplnt,"DR2")==0)|| (tc_strcmp(Toplnt,"AR2")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR0")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR0")==0)))
					{
						CreatAllowNONCLPrt=2;
						printf("10CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					//Parts For Gate Maturation
					else if(((tc_strcmp(Toplnt,"DR1")==0)|| (tc_strcmp(Toplnt,"AR1")==0)) && ((tc_strcmp(NonColPrtDRStatus,"DR0")==0)|| (tc_strcmp(NonColPrtDRStatus,"AR0")==0)))
					{
						CreatAllowNONCLPrt=1;
						printf("11CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
					}
					else
					{
						printf("TO Plant Value[%s],Non-ColourPart DR Status[%s],\n",Toplnt,NonColPrtDRStatus);fflush(stdout);
						printf("12CheckNonColDRStatus Flag is [%d] ToPlant[%s],NonColorPart DR Status[%s]",CreatAllowNONCLPrt,Toplnt,NonColPrtDRStatus);fflush(stdout);
						CreatAllowNONCLPrt=0;
						break;
					}
					
					
					printf("in function CheckNonColDRStatus Final CreatAllow [%d] ",CreatAllowNONCLPrt);fflush(stdout);
				}
	}
	
	
		if (CreatAllowNONCLPrt >0)
		{
			printf("\n function CheckNonColDRStatus--Part Add to Folder  \n");fflush(stdout);
			return 1;
		}
		else
		{
			printf("\n function CheckNonColDRStatus--Part NOT Add to Folder  \n");fflush(stdout);
			return 0;
		}
}
int CheckMilestoneLive(char* sProject)
{
	int     Milston_rsltCount    = 0;
	int     Milston_n_entry    = 1;
	tag_t     *MilstonCntrlObjectTag                = NULLTAG;
	tag_t     MilestoneqryTag                              = NULLTAG;
	char    *Milston_qry_entry[1]  = {"SYSCD"};
	char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char*     Milstoninfo1 = NULL;
	char*     Milstoninfo2 = NULL;

	printf("\n P: CheckMilestoneLive for project: %s \n", sProject);fflush(stdout);
	//GETTING mileston obj.
	if(QRY_find2("ControlObjects", &MilestoneqryTag));
	if (MilestoneqryTag)
	{
		printf("\n P1:Found Query MilestoneqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n P2:Not Found Query MilestoneqryTag \n");fflush(stdout);
	}

	Milston_qry_values2[0] = "Milston";
	if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
	printf(" \n P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
	if(Milston_rsltCount > 0)
	{
		if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo1",&Milstoninfo1)!=ITK_ok)   PrintErrorStack();
		printf("\n P4:Milstoninfo1 is : [%s]\n", Milstoninfo1);fflush(stdout);

		if (AOM_ask_value_string(MilstonCntrlObjectTag[0],"t5_Userinfo2",&Milstoninfo2)!=ITK_ok)   PrintErrorStack();
		printf("\n P4:Milstoninfo2 is : [%s]\n", Milstoninfo2);fflush(stdout);

		if((tc_strstr(Milstoninfo1,sProject)!=NULL)|| (tc_strstr(Milstoninfo2,sProject)!=NULL))
		{
			printf("\n P: It is MilestoneLive project: %s \n", sProject);fflush(stdout);
			return 1;
		}
		else
		{
			printf("\n P: It is not MilestoneLive project: %s \n", sProject);fflush(stdout);
		return 0;
		}
	

		return 0;               
	}
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
					It checks for the proper dbUsr name and password.
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	int				ifail 						= ITK_ok;
	char			* userid 					= NULL;
	char			* password					= NULL;
	char			* group						= NULL;
	char			* dmlnob						= NULL;
	char			* Filename					= NULL;
	char			Data[100]					= "";

	char 			*test						= (char*)MEM_alloc(sizeof(char) * 50);
	char			outputFile1[200]				= "";
	char			outputFile[200]				= "";

	//userid			= ITK_ask_cli_argument("-u=");
	//password 		= ITK_ask_cli_argument("-pf=");
	//group 			= ITK_ask_cli_argument("-g=");
	//Filename		= ITK_ask_cli_argument("-file=");
	dmlnob 		= ITK_ask_cli_argument("-dmlno=");


	

	//if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
//	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0)
//	{
	//	print_requirement();
//		return -1;
//	}
	ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	printf("\n Auto login ");fflush(stdout);
	ifail = ITK_auto_login( );
    ifail = ITK_set_journalling( TRUE);
	printf("\n Auto login .......\n");fflush(stdout);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");fflush(stdout);
			printf("\nWelcome to Teamcenter.....!!\n");fflush(stdout);
		}
	// ifail = ITK_set_bypass(true);
    // if (ifail != ITK_ok)
	// {
		// printf("\nUser is not Privileged Admin User \n\n");
		// return -1;
	// }
	//ifail = read_value_from_file(Filename);
	
	tag_t			DML_tag 					= NULLTAG;
	tag_t	DMLTag	= NULLTAG;
	char			* dmlNum						= NULL;
	ifail = ITEM_find_item (dmlnob, &DML_tag);
	printf(" DML number peresent \n");fflush(stdout);
	if(DML_tag==NULLTAG)
	{
		printf("\n DML No not found in Teamcenter...!!\n");fflush(stdout);
		return 0;
	}
	else
	{
		ifail = ITEM_ask_latest_rev (DML_tag, &DMLTag);
		if (DMLTag==NULLTAG)
		{
			printf("\n P5aaaaaaaaaaaaaaaaaaater...!!\n");fflush(stdout);
		}
		else
		{
			
			ifail = AOM_UIF_ask_value(DMLTag,"item_id",&dmlNum);fflush(stdout);
			printf("\n dmlNum item id %s",dmlNum);fflush(stdout);
			
			char* dmlReleaseType = NULL;
			
			AOM_ask_value_string(DMLTag,"t5_rlstype",&dmlReleaseType);
			
			if(tc_strcmp(dmlReleaseType,"TODR")==0)
			{
				tag_t dmlTaskTag = NULLTAG;
				int taskCnt = 0;
				tag_t *dmlTaskTagObjects = NULL;

				AOM_ask_value_tags(DMLTag,"T5_DMLTaskRelation",&taskCnt,&dmlTaskTagObjects);
				if(taskCnt>0)
				{
					int j=0;
					char* object_type	=	NULL;
					for(j=0;j<taskCnt;j++)
					{
						dmlTaskTag = dmlTaskTagObjects[j];
						AOM_ask_value_string(dmlTaskTag,"object_type",&object_type);
						if(tc_strcmp(object_type,"T5_ChangeTaskRevision")==0)
						{
							char *TaskNo=NULL;
							char *Fld_Des_tsk=NULL;
							Fld_Des_tsk=(char *) MEM_alloc(50);
							
							ifail = AOM_UIF_ask_value(dmlTaskTag,"item_id",&TaskNo);fflush(stdout);
							tc_strcpy(Fld_Des_tsk,"");
							tc_strcat(Fld_Des_tsk,"Task-");
							tc_strcat(Fld_Des_tsk,TaskNo);
							printf("\n folderTASK description1 %s",Fld_Des_tsk);fflush(stdout);
							
							int i,number_found,number_found1,fldEmpty=0,check=0;
							WSO_search_criteria_t  	criteria;
							tag_t *list_of_WSO_tags=NULLTAG;
							tag_t item_type_tag	= NULLTAG;
							tag_t FL_create_input_tag= NULLTAG;
							tag_t pfolder_tag= NULLTAG;
							tag_t	Ref_Rel	= NULLTAG;
							tag_t relation1= NULLTAG;
							
							WSOM_clear_search_criteria(&criteria);
							strcpy(criteria.name,"Parts For Gate Maturation");
							strcpy(criteria.desc,Fld_Des_tsk);
							ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);
							printf("\nNumber of Parts For Gate Maturation folders found are %d\n",number_found);fflush(stdout);
							
							if (number_found>0)
							{
								printf("\n folder is alredy present[%s] ",Fld_Des_tsk);fflush(stdout);
							}
							else
							{
								if(TCTYPE_find_type("Folder", "", &item_type_tag)!=ITK_ok)PrintErrorStack();
								if(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag)!=ITK_ok)PrintErrorStack();
								if(AOM_set_value_string(FL_create_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
								if(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des_tsk)!=ITK_ok)PrintErrorStack();
								if(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();
								
								if (pfolder_tag!=NULLTAG)
								{
									printf("\n Parts For Gate Maturation created");fflush(stdout);
									ifail = AOM_save_with_extensions(pfolder_tag);
									ifail =AOM_refresh(pfolder_tag,TRUE);
									ifail = AOM_lock(dmlTaskTag);
									
									ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
									
									if (Ref_Rel!=NULLTAG)
									{
										ifail = GRM_create_relation(dmlTaskTag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
										if (relation1!=NULLTAG)
										{
											ifail =AOM_refresh(relation1,TRUE);
											ifail = GRM_save_relation(relation1);
											ifail = AOM_unlock(dmlTaskTag);
											printf("\n Parts For Gate Maturation  folder created and relation created with change reference");fflush(stdout);
										}
									}
								}
							}
						}
					}
				}
			}
			
		}
	}
	ifail = GateMaturation(dmlnob);
	
	
	
	
	DML_tag 					= NULLTAG;
	DMLTag	= NULLTAG;
	dmlNum	= NULL;
	ifail = ITEM_find_item (dmlnob, &DML_tag);
	printf(" DML number peresent \n");fflush(stdout);
	if(DML_tag==NULLTAG)
	{
		printf("\n DML No not found in Teamcenter...!!\n");fflush(stdout);
		return 0;
	}
	else
	{
		ifail = ITEM_ask_latest_rev (DML_tag, &DMLTag);
		if (DMLTag==NULLTAG)
		{
			printf("\n P5aaaaaaaaaaaaaaaaaaater...!!\n");fflush(stdout);
		}
		else
		{
			
			ifail = AOM_UIF_ask_value(DMLTag,"item_id",&dmlNum);fflush(stdout);
			printf("\n dmlNum item id %s",dmlNum);fflush(stdout);
			
		}
	}
	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"/tmp/%s_%s_GMDReport.txt",dmlnob,Data);
	sprintf(outputFile1,"%s_%s_GMDReport.txt",dmlnob,Data);
	printf("\n File Name [%s]",outputFile);
	
	FILE *GMDRpt = NULL;
	//fsuccess = fopen(fsuccess_name,"a");
	GMDRpt=fopen(outputFile,"w");
	
	if (GMDRpt == NULL)
		{
						printf("ERROR: Cannot open File\n");
						return -1;
		}
		else
		{
					printf("File opened successfully.\n");
		}
	
	char *Fname=NULL;
	char *Fld_DesF=NULL;
	Fld_DesF=(char *) MEM_alloc(50);
	
	tc_strcpy(Fld_DesF,"");
	tc_strcat(Fld_DesF,"*");
	tc_strcat(Fld_DesF,dmlNum);
	tc_strcat(Fld_DesF,"*");

	printf("\n folder description1 %s",Fld_DesF);fflush(stdout);
	
	WSO_search_criteria_t  	criteriaF;
	tag_t *list_of_WSO_tagsF=NULLTAG;
	int number_foundF=0;
	WSOM_clear_search_criteria(&criteriaF);
	strcpy(criteriaF.desc,Fld_DesF);
	strcpy(criteriaF.class_name,"Folder");
	ifail = WSOM_search(criteriaF, &number_foundF, &list_of_WSO_tagsF);
	printf("\nNumber of folders found are %d\n",number_foundF);fflush(stdout);
	tag_t FlTag = NULLTAG;
	int fcount=0;
	int checkFolderEmpty=0;
	fprintf(GMDRpt,"\n GMD Report for DML:[%s]		Date[%s]",dmlNum,Data);fflush(GMDRpt);
	if(number_foundF>0)
	{
		for (fcount=0;fcount<number_foundF;fcount++ )
		{
			//Immaturated MS Status Parts
			//Immaturated CarryOver Parts
			//Immaturated DR Status Parts
			
			FlTag = list_of_WSO_tagsF[fcount];
			ifail = AOM_ask_value_string(FlTag,"current_name",&Fname);
			printf("\n Folder Name is: [%s]",Fname);fflush(stdout);
			
			
			
			fprintf(GMDRpt,"\n Part in Folder :[%s]",Fname);fflush(GMDRpt);
			
			if((tc_strcmp(Fname,"Parts For Gate Maturation")==0) || (tc_strcmp(Fname,"CarryOver Parts")==0)|| (tc_strcmp(Fname,"Immaturated MS Status Parts")==0)|| (tc_strcmp(Fname,"Immaturated CarryOver Parts")==0)|| (tc_strcmp(Fname,"Immaturated DR Status Parts")==0))
			{
				printf("\n Going to remove parts attached to folder[%s]",Fname);fflush(stdout);
				int floEmp=0,ReqFdrSize=0,FldObjCount=0,jrr;
				tag_t *FoldObj_tag=NULLTAG;
				char	*sPrtName 	= NULL;
				char	*Fname 	= NULL;
				char	*PrtType 	= NULL;
				char	*PrtRevSeq 	= NULL;
				char	*PrtDrStatus 	= NULL;
				
				if(AOM_ask_value_string(FlTag,"current_name",&Fname)!=ITK_ok)PrintErrorStack();
				printf("\n GMDRpt for GMD Folder Name is: [%s]",Fname);fflush(stdout);		
				
				if(FL_ask_size(FlTag,&ReqFdrSize));
				printf("\n :ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
				if(FL_ask_references(FlTag,FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
				printf("\n :FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
				
				if(FldObjCount>0)
				{
					jrr=0;
					for (jrr=0;jrr<FldObjCount;jrr++ )
					{
						if(AOM_ask_value_string(FoldObj_tag[jrr],"item_id",&sPrtName)!=ITK_ok)PrintErrorStack();
						printf("\n Part : [%s]--Folder Name is:[%s]", sPrtName,Fname);fflush(stdout);
						
						if(AOM_ask_value_string(FoldObj_tag[jrr],"item_revision_id",&PrtRevSeq)!=ITK_ok)PrintErrorStack();
						printf("\n Part  rev Seq: [%s]", PrtRevSeq);fflush(stdout);
						
						if(AOM_ask_value_string(FoldObj_tag[jrr],"t5_PartStatus",&PrtDrStatus)!=ITK_ok)PrintErrorStack();
						printf("\n PrtDrStatus : [%s]", PrtDrStatus);fflush(stdout);
						
						if(AOM_ask_value_string(FoldObj_tag[jrr],"t5_PartType",&PrtType)!=ITK_ok)PrintErrorStack();
						printf("\n PrtType : [%s]",PrtType);fflush(stdout);
						
						fprintf(GMDRpt,"\n  [%s]			[%s]		[%s]		[%s]",sPrtName,PrtRevSeq,PrtDrStatus,PrtType);fflush(GMDRpt);
					}			
				}
				else
				{
					printf("\n Folder[%s] already NULL.\n",Fname);fflush(stdout);
					
					fprintf(GMDRpt,"\n 	Folder[%s] is Empty ",Fname);fflush(GMDRpt);
				}
			}
			else
			{
				printf("\n Folder Name is: [%s] not related to GMD DML",Fname);fflush(stdout);
			}
			
			
			
		
		}
	}
	else
	{
		printf("\n Folders are not available");fflush(stdout);
		fprintf(GMDRpt,"\n GMD Releated Folders is not available");fflush(GMDRpt);
	}
	fclose(GMDRpt);
	tag_t		msWordType				= NULLTAG;
		tag_t		wordDataset				= NULLTAG;
		tag_t		wordLatestDat_t			= NULLTAG;
		//char				* DataSetName1		= NULL;
		//DataSetName1=(char *) MEM_alloc(100);
		
		tag_t relation_type = NULLTAG;
		tag_t relation = NULLTAG;
			
		ifail=AE_find_datasettype2("Text",&msWordType);
		//tc_strcpy(DataSetName1,"");
		//tc_strcat(DataSetName1,dml);
		//tc_strcat(DataSetName1,"_");				
		//tc_strcat(DataSetName1,Data);

		ITKCALL(AE_create_dataset_with_id(msWordType,outputFile1,"GMD Report","","",&wordDataset));		
		ITKCALL(AE_save_myself(wordDataset));
		ITKCALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
		ITKCALL(AOM_refresh(wordLatestDat_t,TRUE));
		ITKCALL(AE_import_named_ref(wordLatestDat_t,"Text",outputFile,NULL,SS_TEXT));
		AOM_save_with_extensions(wordLatestDat_t);
		AOM_refresh(wordLatestDat_t, FALSE);
		AOM_unload(wordLatestDat_t);
		if(GRM_find_relation_type("IMAN_reference", &relation_type)!=ITK_ok)PrintErrorStack();
		 GRM_create_relation(DMLTag, wordLatestDat_t, relation_type, NULLTAG, &relation);
		 GRM_save_relation(relation);
		 AOM_unload(DMLTag);
		 AOM_refresh(DMLTag, TRUE);

	printf("\nEnd of program.....!!\n\n");fflush(stdout);
	printf("\n*****************************\n");fflush(stdout);
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;

	char 			*itemid					= NULL;
	char 			*attr_value				= NULL;
	char 			temp[200];

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, "^");
				printf("\nInput Item_id:%s\n",itemid);fflush(stdout);


				//attr_value = strtok(NULL, ",");
				//printf("\nInput attr_value:%s\n",attr_value);

				ifail = GateMaturation(itemid);
			}
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");fflush(stdout);
	}
	fclose(fp);
	fclose(output);
	return ifail;
}
static tag_t ask_item_revision_from_bom_line_SnapShot(tag_t bom_line)
{
    tag_t item_revision = NULLTAG;
    char *item_id = NULL, *rev_id = NULL;
    
    ITKCALL(AOM_ask_value_string(bom_line, "bl_item_item_id", &item_id ));
    ITKCALL(AOM_ask_value_string(bom_line, "bl_rev_item_revision_id", &rev_id));
    ITKCALL(ITEM_find_rev(item_id, rev_id, &item_revision));
    
    if (item_id) MEM_free(item_id);
    if (rev_id) MEM_free(rev_id);
    return item_revision;
}
int getAllReleasedPartDML1(char *partNumber,tag_t *latestPart)
  {
				 			  
	int ifail = ITK_ok;
	int  count            = 0;
	tag_t *itemrevs = NULLTAG;        
	char *relstat="T5_LcsErcRlzd";

	char *qry_entries[] ={"Item ID","Release Status"};
	char *qry_values[] = {partNumber,relstat};
	int            num_to_sort=1;
	char*         keys[]={"creation_date"};
	int orders[]={1};
 
	tag_t query = NULLTAG;

	ifail ==QRY_find2("Item Revision...", &query);
	ifail = QRY_execute_with_sort(query, 2, qry_entries, qry_values,num_to_sort,keys,orders, &count, &itemrevs);
	int x=0;
	char *dispstr;
	char *dt;
	 for(x=0;x<count;x++)
	 {
	 
		 *latestPart=itemrevs[x];
		 AOM_UIF_ask_value(*latestPart,"object_string", &dispstr);
		 AOM_UIF_ask_value(*latestPart,"creation_date", &dt);
		 printf("\n [%d] [%s] [%s]",x,dispstr,dt);fflush(stdout);
		//fprintf(fsuccess,"\n [%d] [%s] [%s]",x,dispstr,dt);fflush(fsuccess);
	 }
	//fprintf(fsuccess,"\n Sending latest ERC Release Part Object [%d] [%s] [%s]",x,dispstr,dt);fflush(fsuccess);
	printf("\n Sending latest ERC Release Part Object [%d] [%s] [%s]",x,dispstr,dt);fflush(stdout);
	 return ifail;
  }

/********************************************************************************************
    Function:       GateMaturation
    Description:    This function takes the item_id and attr_value as input and stamps the
					attr_value on specific attribute of all revisions of perticular item.
********************************************************************************************/

int GateMaturation(char* item_id)
{
	int		ifail 		= ITK_ok;
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	tag_t	dmltag			=  NULLTAG;
	int      no_attach      =  0;
	char	*PlntToPlnt1		=  NULL;
	char	*PlntToPlnt		=  NULL;
	char	*class_name1	=  NULL;
	char	*TaskProj		=  NULL;
	char	*PartMstr_no	=  NULL;
	char	*DMLProj		=  NULL;
	char	*TskNm			=  NULL;
	char	*LiveProjInfo			=  NULL;
	char	*TaskDesg		=  NULL;
	char	*DMLNo			=  NULL;
	char	*FromPlnt		=  NULL;
	char	*rev_idd		=  NULL;
	char	*ToPlnt			=  NULL;
	char	*Obj_PrtTyp1			=  NULL;
	char	*DMLtype		=  NULL;
	char	*TaskDsgGrp		=  NULL;
	char	*rel_status		=  NULL;
	char	*parttypes		=  NULL;
	char	*PartMstrNm		=  NULL;
	char	*PartMLStaus		=  NULL;
	char	*PartDRStaus		=  NULL;
	char	*PartDgrp		=  NULL;
	char	*VCStr		=  NULL;
	tag_t	objTypTag		= NULLTAG;
	tag_t	*DMLRev		= NULLTAG;
	tag_t   *ERCCntrlObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	char   *ObjTyp =NULL;
	int     count,j		=  0,DR_rsltCount;
	int	ii	=  0;
	int	Mstr	= 0;
	int	Item_count	= 0;
	int	CMRefcount	= 0;
	tag_t DMLRevTag = NULLTAG;
	tag_t class_id1=NULLTAG;
	tag_t	*TaskCMRef = NULLTAG;
	tag_t	*rev_list = NULLTAG;
	tag_t	*referencers = NULLTAG;
	tag_t	*DMLRevision = NULLTAG;
	tag_t	*tashtag = NULLTAG;
	//GRM_relation_t	*tashtag;
	tag_t	PartTag	= NULLTAG;
	tag_t	DMLTag	= NULLTAG;
	tag_t	AssyMstrtag	= NULLTAG;
	tag_t	ClPartTagg	= NULLTAG;
	tag_t	All_item_tag	= NULLTAG;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t	tsk_dml_rel_type	= NULLTAG;
	//char   relation_name[TCTYPE_name_size_c+1];
	char   *relation_name =NULL;
	logical is_latest;
	logical is_lat;
	tag_t			item_tag 					= NULLTAG;
	vector<tag_t> pVec;
	vector<tag_t> col_vec;
	tag_t			t_BomLineWindow= NULLTAG;
	tag_t  t_TopLine = NULLTAG;
	tag_t  bl_chils_rev_tg = NULLTAG;
	tag_t  t_Rule = NULLTAG;
	char	*Obj_PrtTyp		=  NULL;
	char	*PrtDRstus		=  NULL;
	char	*PrtMLstus		=  NULL;
	char	*rel_stats		=  NULL;
	char	*PrtProj		=  NULL;
	char	*Ptq		=  NULL;
	char	*ChildRevID 	= NULL;
	char	*nrevID 	= NULL;
	char	*numId 	= NULL;
	char	*Prtqt 	= NULL;
	char	*ChildPrtDGrp 	= NULL;
	char	*rell_status	=  NULL;
	char	*clrell_status	=  NULL;
	char	*Clrel_status1	=  NULL;
	char	*Clrel_Dr	=  NULL;
	char	*Clrel_MLStatus	=  NULL;
	char	*rev_cl	=  NULL;
	char	*Child_SeqId	=  NULL;
	char	**relations	=  NULL;
	char	*rev_idt	=  NULL;
	tag_t   DRqryTag     = NULLTAG;
	char    **DR_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	tag_t 	PartTagg 			= NULLTAG;
	tag_t 	*rev_listt 			= NULL;
	tag_t 	*rev_listt11 			= NULL;
	tag_t			*t_PartChildren								= NULLTAG;
	tag_t			*t_PartChildrenCol								= NULLTAG;
	char    *DR_qry_entry[1]= {"SYSCD"};
	int iItemType,iItemId,iPrTyp,rel,iPrtSta,iPrtMLSta,iPrTyp1,iItemTyp1e,iItemfId,iQty,iPrtDGrp,iPrjCd,iItemRevCh,iQy,iij,Item_cunt,i_ChildCount,iChldPrts;
	int     DR_n_entry    = 1,n_tskfund=0,im=0,jj=0,cnt=0,GMDMLFound=0,cnttt=0;//,Prtqt=0;
	int *levelsaa;
	int AttchCnt=0,Item_cunt1,cl,foundDR3p=0;
	int ECUPart=0;

	/***************/

	printf("##....Startinggggggggggggggggggggggg...!!\n");fflush(stdout);

	//item_tag= t5GetItemRevison(item_id);

	ifail = ITEM_find_item (item_id, &item_tag);
	printf("##....Startinugujgffdhgdfgfdgdggg...!!\n");fflush(stdout);
	if(item_tag==NULLTAG)
	{
		printf("\n P5:Object not found in Teamcenter...!!\n");fflush(stdout);
		return 0;
	}
	else
	{
		ifail = ITEM_ask_latest_rev (item_tag, &dmltag);
		if (dmltag==NULLTAG)
		{
			printf("\n P5aaaaaaaaaaaaaaaaaaater...!!\n");fflush(stdout);
		}
		else
		{
			char* DMLtypeF = NULL;
			char* DMLProjF = NULL;
			char* PlntToPlntF = NULL;
			char*  dmlNameF = NULL;
	
			ifail = AOM_ask_value_string(dmltag,"t5_rlstype",&DMLtypeF);
			ifail = AOM_ask_value_string(dmltag,"t5_cprojectcode",&DMLProjF);
			ifail = AOM_ask_value_string(dmltag,"t5_PlntToPlnt",&PlntToPlntF);
			ifail = AOM_UIF_ask_value(dmltag,"item_id",&dmlNameF);fflush(stdout);
			printf("\n dmlNameF item id %s",dmlNameF);fflush(stdout);
			printf("\n DML Type [%s]",DMLtypeF);fflush(stdout);
			
			if(tc_strcmp(DMLtypeF,"TODR")==0) 
			{
			
			
				char *Fname=NULL;
				char *Fld_DesF=NULL;
				Fld_DesF=(char *) MEM_alloc(50);
				
				tc_strcpy(Fld_DesF,"");
				tc_strcat(Fld_DesF,"*");
				tc_strcat(Fld_DesF,dmlNameF);
				tc_strcat(Fld_DesF,"*");

				printf("\n folder description1 %s",Fld_DesF);fflush(stdout);
				
				WSO_search_criteria_t  	criteriaF;
				tag_t *list_of_WSO_tagsF=NULLTAG;
				int number_foundF=0;
				WSOM_clear_search_criteria(&criteriaF);
				strcpy(criteriaF.desc,Fld_DesF);
				strcpy(criteriaF.class_name,"Folder");
				ifail = WSOM_search(criteriaF, &number_foundF, &list_of_WSO_tagsF);
				printf("\nNumber of folders found are %d\n",number_foundF);fflush(stdout);
				tag_t FlTag = NULLTAG;
				int fcount=0;
				int checkFolderEmpty=0;
				if(number_foundF>0)
				{
					for (fcount=0;fcount<number_foundF;fcount++ )
					{
						//Immaturated MS Status Parts
						//Immaturated CarryOver Parts
						//Immaturated DR Status Parts
						
						FlTag = list_of_WSO_tagsF[fcount];
						ifail = AOM_ask_value_string(FlTag,"current_name",&Fname);
						printf("\n Folder Name is: [%s]",Fname);fflush(stdout);
						
						if((tc_strcmp(Fname,"Parts For Gate Maturation")==0) || (tc_strcmp(Fname,"CarryOver Parts")==0)|| (tc_strcmp(Fname,"Immaturated MS Status Parts")==0)|| (tc_strcmp(Fname,"Immaturated CarryOver Parts")==0)|| (tc_strcmp(Fname,"Immaturated DR Status Parts")==0))
						{
							printf("\n Going to remove parts attached to folder[%s]",Fname);fflush(stdout);
							checkFolderEmpty = FolderEmpty(FlTag);
							if (checkFolderEmpty>0)
							{
								printf("\n folder references are removed.");fflush(stdout);
								
							}
						}
						else
						{
							printf("\n Folder Name is: [%s].not related zto GMD DML",Fname);fflush(stdout);
						}
					
					}
				}
				else
				{
					printf("\n Folders are not available");fflush(stdout);
				}

			}
			else
			{
				printf("\n DML Type [%s].Not GMD DML",DMLtype);fflush(stdout);
			}
			
			printf("\n ffffffffffffffffff...!!\n");fflush(stdout);
			ifail = GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);
			printf("##..34234242343g...!!\n");fflush(stdout);
			ifail =(GRM_list_secondary_objects_only(dmltag,tsk_dml_rel_type, &cnttt, &tashtag));
			if (tashtag==NULL)
			{
				printf("##..task array is empty..!!\n");fflush(stdout);
				
			}
			else
			{
				if(cnttt>0)
				{
					
					for (AttchCnt= 0; AttchCnt < cnttt; AttchCnt++)
					{
						//pVec.clear();
						//col_vec.clear();
						objTag=tashtag[AttchCnt];
						if (objTag!=NULLTAG)
						{
							printf("Object Found...!!\n");fflush(stdout);
							if(AOM_ask_value_string(objTag,"object_type",&ObjTyp)!=ITK_ok)PrintErrorStack();
							printf("\n ObjTyp is :%s\n",ObjTyp);fflush(stdout);
							printf("\n GM: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

							if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
							{
								ifail = GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);
								if (tsk_dml_rel_type!=NULLTAG)
								{
									ifail = GRM_list_primary_objects_only(objTag,tsk_dml_rel_type,&count,&DMLRevision);
									printf("\n GM: DML Revision from Task: %d.",count);fflush(stdout);
									for (j=0;j<count ;j++ )
									{
										ifail = ITEM_rev_sequence_is_latest(DMLRevision[j],&is_latest);
										printf("\n GM: is_latest value: %d.",is_latest);fflush(stdout);

										if(is_latest != true)
										{
											printf("\n GM: is_latest is not true.");fflush(stdout);
										}
										else
										{
											DMLRevTag = DMLRevision[j];
											ifail = POM_class_of_instance(DMLRevTag,&class_id1);
											ifail = POM_name_of_class(class_id1,&class_name1);
											printf("\n GM: class_name found1 MR :%s.",class_name1);fflush(stdout);
											ifail = AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DMLtype);
											ifail = AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DMLProj);
											ifail = AOM_ask_value_string(DMLRevTag,"t5_PlntToPlnt",&PlntToPlnt);
											ifail = AOM_UIF_ask_value(DMLRevTag,"t5_PlntToPlnt",&PlntToPlnt1);
											printf("\n GM: DMLtype:[%s] DMLProj:[%s] PlntToPlnt:[%s].[%s]",DMLtype,DMLProj,PlntToPlnt,PlntToPlnt1);fflush(stdout);

											if(tc_strcmp(DMLtype,"TODR")==0)
											{
												if(PlntToPlnt!=NULL)
												{
													if (tc_strcmp(PlntToPlnt,"DR3 to DR3P")==0 || tc_strcmp(PlntToPlnt,"AR3 to AR3P")==0)
													{
														FromPlnt=subString(PlntToPlnt, 0, 3);
														ToPlnt=subString(PlntToPlnt, 7, 4);
														printf("\n Inside1111..%s",ToPlnt); fflush(stdout);
														foundDR3p=1;
													}
													if (foundDR3p==0)
													{
														if (tc_strcmp(PlntToPlnt,"DR3P to DR4")==0 || tc_strcmp(PlntToPlnt,"AR3P to AR4")==0)
														{
															FromPlnt=subString(PlntToPlnt, 0, 4);
															ToPlnt=subString(PlntToPlnt, 8, 3);
															printf("\n Inside2222..%s",ToPlnt); fflush(stdout);
														}
														else
														{
															printf("\n Inside333.."); fflush(stdout);
															FromPlnt=subString(PlntToPlnt, 0, 3);
															ToPlnt=subString(PlntToPlnt, 7, 3);
														}
													}
													
													ifail = AOM_UIF_ask_value(objTag,"item_id",&TskNm);
													TaskDsgGrp=subString(TskNm,11,2);
													printf("\n GM: Task: [%s] TaskDsgGrp:[%s] FromPlnt:[%s] ToPlnt:[%s]\n",TskNm,TaskDsgGrp,FromPlnt,ToPlnt);fflush(stdout);
													if(tc_strstr(TskNm,"CO")==NULL)
													{
														/******************Live Project Check*****************************/
														printf("\n Inside Control Table for Assign Analyst/Manager..."); fflush(stdout);
														if(QRY_find2("ControlObjects", &qryTag));
														if (qryTag)
														{
														printf("\n PROASM:Found Query ControlObjects \n");fflush(stdout);
														}
														else
														{
														printf("\n PROASM:Not Found Query ControlObjects \n");fflush(stdout);
														}

														if(QRY_find2("ControlObjects", &DRqryTag));
														if (DRqryTag)
														{
														printf("\n ERCLive:Found Query ControlObjects \n");fflush(stdout);
														}
														else
														{
														printf("\n ERCLive:Not Found Query ControlObjects \n");fflush(stdout);
														}

														DR_qry_values2[0] = "ERCLive";
														if(QRY_execute(DRqryTag, DR_n_entry, DR_qry_entry, DR_qry_values2, &DR_rsltCount, &ERCCntrlObjectTag));
														printf(" \n ERCLive:DR_rsltCount :%d:", DR_rsltCount); fflush(stdout);
														char	*ERCInf1		=  NULL;
														char	*ERCInf2		=  NULL;
														char	*ERCInf3		=  NULL;
														char	*ERCInf4		=  NULL;
														char	*ERCInf5		=  NULL;
														char	*ERCInf6		=  NULL;
														char	*ERCInf7		=  NULL;
														char	*ERCInf8		=  NULL;
														char	*ERCInf9		=  NULL;
														char	*ERCInf10	    =  NULL;
														LiveProjInfo = (char *) MEM_alloc(900000 * sizeof(char));
														tc_strcpy(LiveProjInfo,"");
														if(DR_rsltCount > 0)
														{
															
															if (AOM_ask_value_string(ERCCntrlObjectTag[0],"t5_Userinfo1",&ERCInf1)!=ITK_ok)   PrintErrorStack();
															if (AOM_ask_value_string(ERCCntrlObjectTag[0],"t5_Userinfo2",&ERCInf2)!=ITK_ok)   PrintErrorStack();
															if (AOM_ask_value_string(ERCCntrlObjectTag[0],"t5_Userinfo3",&ERCInf3)!=ITK_ok)   PrintErrorStack();
															if (AOM_ask_value_string(ERCCntrlObjectTag[0],"t5_Userinfo4",&ERCInf4)!=ITK_ok)   PrintErrorStack();
															if (AOM_ask_value_string(ERCCntrlObjectTag[0],"t5_Userinfo5",&ERCInf5)!=ITK_ok)   PrintErrorStack();
															if (AOM_ask_value_string(ERCCntrlObjectTag[0],"t5_Userinfo6",&ERCInf6)!=ITK_ok)   PrintErrorStack();
															if (AOM_ask_value_string(ERCCntrlObjectTag[0],"t5_Userinfo7",&ERCInf7)!=ITK_ok)   PrintErrorStack();
															if (AOM_ask_value_string(ERCCntrlObjectTag[0],"t5_Userinfo8",&ERCInf8)!=ITK_ok)   PrintErrorStack();
															if (AOM_ask_value_string(ERCCntrlObjectTag[0],"t5_Userinfo9",&ERCInf9)!=ITK_ok)   PrintErrorStack();
															if (AOM_ask_value_string(ERCCntrlObjectTag[0],"t5_userinfo10",&ERCInf10)!=ITK_ok)   PrintErrorStack();
															printf("\n ERCInf1: %s ERCInf2:%s\n", ERCInf1,ERCInf2);fflush(stdout);
															tc_strcat(LiveProjInfo,ERCInf1);
															tc_strcat(LiveProjInfo,ERCInf2);
															tc_strcat(LiveProjInfo,ERCInf3);
															tc_strcat(LiveProjInfo,ERCInf4);
															tc_strcat(LiveProjInfo,ERCInf5);
															tc_strcat(LiveProjInfo,ERCInf6);
															tc_strcat(LiveProjInfo,ERCInf7);
															tc_strcat(LiveProjInfo,ERCInf8);
															tc_strcat(LiveProjInfo,ERCInf9);
															tc_strcat(LiveProjInfo,ERCInf10);
															
															printf("\n Final String list [%s]", LiveProjInfo);fflush(stdout);
														}

														/******************Live Project Check*****************************/
														ifail = GRM_find_relation_type("CMReferences", &tsk_CMRef_type);
														if (tsk_CMRef_type!=NULLTAG)
														{
															ifail = GRM_list_secondary_objects_only(objTag,tsk_CMRef_type,&CMRefcount,&TaskCMRef);
															printf("\n GM: Task CMRefcount: %d",CMRefcount);fflush(stdout);
															if(CMRefcount > 0)
															{
																Mstr=0;
																for (Mstr=0;Mstr<CMRefcount ;Mstr++)
																{
																	pVec.clear();
																	col_vec.clear();
																	printf("\n GM:main loop task to part Design Mstr:[%d]",Mstr);fflush(stdout);
																	AssyMstrtag=TaskCMRef[Mstr];
																	ifail = AOM_ask_value_string(AssyMstrtag,"item_id",&PartMstr_no);
																	printf("\n GM:main loop task to part Design Mstr Part Number:[%s]",PartMstr_no);	fflush(stdout);

																	if(ITEM_find_item(PartMstr_no,&All_item_tag)!=ITK_ok)PrintErrorStack();
																	//All_item_tag= t5GetItemRevison(PartMstr_no);
		if(All_item_tag!=NULLTAG)
		{
			ifail = ITEM_list_all_revs(All_item_tag, &Item_count, &rev_list);
			printf("\n GM:Total rev found: %d.", Item_count);fflush(stdout);
			if(Item_count > 0)
			{
				ii=0;
				for(ii=Item_count-1;ii>=0;ii--)
				{
					ECUPart=0;
					PartDgrp		=  NULL;
					PartTag = rev_list[ii];
					ifail = AOM_UIF_ask_value(PartTag, "item_revision_id", &rev_idd);
					ifail = AOM_UIF_ask_value(PartTag, "release_status_list", &rel_status);
					ifail = AOM_UIF_ask_value(PartTag, "t5_PartType", &parttypes);
					ifail = AOM_ask_value_string(PartTag,"item_id",&PartMstrNm);
					ifail = AOM_ask_value_string(PartTag,"t5_DesignMilestoneStatus",&PartMLStaus);
					ifail = AOM_ask_value_string(PartTag,"t5_PartStatus",&PartDRStaus);
					ifail = AOM_ask_value_string(PartTag,"t5_DesignGrp",&PartDgrp);
					printf("\n GM: Part %s rev:%s and REl Status:%s partype is %s part miles Stone status %s",PartMstrNm,rev_idd,rel_status,parttypes,PartMLStaus);fflush(stdout);
					
					// tag_t objTypTagEE = NULLTAG;
					// char ObjTypEE[TCTYPE_name_size_c + 1];
					// printf("\n wwwwwwwwww");fflush(stdout);
					// if(TCTYPE_ask_object_type(PartTag,&objTypTagEE));
					// printf("\n 1111111111111111");fflush(stdout);
					// if(TCTYPE_ask_name(objTypTagEE,ObjTypEE));
					// printf("\n 22222222222222");fflush(stdout);
					// printf("\n Class of part in solution item  for crash review -->[%s]\n", ObjTypEE);fflush(stdout);
					char   *ObjTypEE =NULL;
					if(AOM_ask_value_string(PartTag,"object_type",&ObjTypEE)!=ITK_ok)PrintErrorStack();
					printf("\n ObjTypEE is :%s\n",ObjTypEE);fflush(stdout);
					printf("\n GM: Workfow obj type: [%s]\n", ObjTypEE);fflush(stdout);
					
					if(tc_strstr(rel_status, "ERC Released") !=NULL && tc_strcmp(parttypes,"Vehicle")!=0 && tc_strcmp(parttypes,"ECU Module")!=0 && tc_strcmp(parttypes,"V")!=0 && tc_strcmp(parttypes,"Vehicle Combination")!=0 && tc_strcmp(parttypes,"VC")!=0 && tc_strcmp(parttypes,"CCVC")!=0 && tc_strcmp(parttypes,"Configurable VC")!=0 && tc_strcmp(parttypes,"Information Fitment Drawing")!=0 && tc_strcmp(parttypes,"IFD Module")!=0 && tc_strcmp(parttypes,"Dummy")!=0 && tc_strcmp(parttypes,"Dummy Component")!=0 && tc_strcmp(parttypes,"Dummy Assembly")!=0 && tc_strcmp(parttypes,"Vehicle Combination CR")!=0 && tc_strcmp(parttypes,"VCCR")!=0)
					{
						ECUPart=0;
						printf("\n GM: Latest released rev:%s and Rel Status:%s", rev_idd,rel_status);fflush(stdout);
						/****************** New Logic Anant********************/
						if((objTag!=NULLTAG))
						{
							printf("\nobjTag NULLLLLLLLLLLLL");fflush(stdout);
						}
						if((PartTag!=NULLTAG))
						{
							printf("\nPartTag NULLLLLLLLLLLLL");fflush(stdout);
						}
						//printf("inside");fflush(stdout);
						//needs to comment as it is there in change reference folder
						//ifail = CreateRelFun( objTag,ToPlnt,PartDRStaus,PartMLStaus,PartTag,LiveProjInfo);
						ifail = BOM_create_window (&t_BomLineWindow);
						//ifail = CFM_find("Latest Working", &t_Rule );
						ifail = CFM_find("ERC release and above", &t_Rule );
						ifail = BOM_set_window_config_rule( t_BomLineWindow, t_Rule );
						tag_t *GMDclosureruleXO1 = NULLTAG;
						tag_t GMDclose_tagXO1 = NULLTAG;
						int rulefoundXO1=0;
						char **GMDrulenameXO1 = NULL;
						char **GMDrulevalueXO1 = NULL;
						//PIE_scope_t scope;
						//scope=PIE_TEAMCENTER;
						//if(PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefoundXO1, &GMDclosureruleXO1 )!=ITK_ok)   PrintErrorStack();
						if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &rulefoundXO1, &GMDclosureruleXO1 )!=ITK_ok)   PrintErrorStack();
						//if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &rulefoundXO1, &GMDclosureruleXO1 )!=ITK_ok)   PrintErrorStack();
						//ifail =PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",scope,&rulefoundXO,&GMDclosureruleXO);
								if (rulefoundXO1 > 0)
								{
									GMDclose_tagXO1 = GMDclosureruleXO1[0];
								}
						if(BOM_window_set_closure_rule( t_BomLineWindow,GMDclose_tagXO1, 0, GMDrulenameXO1,GMDrulevalueXO1 )!=ITK_ok)   PrintErrorStack();
						ifail = BOM_set_window_pack_all (t_BomLineWindow, true);
						ifail = BOM_window_show_suppressed ( t_BomLineWindow );
						ifail = BOM_set_window_top_line (t_BomLineWindow,NULLTAG,PartTag, null_tag, &t_TopLine);
						ifail = BOM_line_ask_child_lines (t_TopLine, &i_ChildCount, &t_PartChildren);
						printf("\n Total Child Parts Found in BomLine are [%d]\n",i_ChildCount);fflush(stdout);
						if (i_ChildCount>0)
						{
							for (iChldPrts = 0; iChldPrts < i_ChildCount; iChldPrts++)
							{
							
								/*if(t_Childobject) t_Childobject=NULLTAG;
								t_Childobject=t_PartChildren[iChldPrts];*/
								//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&iPrTyp1));                            
								//if(BOM_line_ask_attribute_string(t_PartChildren[iChldPrts], iPrTyp1, &Obj_PrtTyp1));
								//printf("\n calling expansion for %s.",Obj_PrtTyp1);fflush(stdout);
								
								
								AOM_UIF_ask_value(t_PartChildren[iChldPrts], "bl_Design Revision_t5_PartType", &Obj_PrtTyp1);
								
								printf("\n Obj_PrtTyp1 [%s]",Obj_PrtTyp1);fflush(stdout);
								
								//if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItemTyp1e));
								//if(BOM_line_ask_attribute_string(t_PartChildren[iChldPrts], iItemTyp1e, &nrevID));
								
								AOM_UIF_ask_value(t_PartChildren[iChldPrts], "bl_rev_item_revision_id", &nrevID);
								
								printf("\n nrevID [%s]",nrevID);fflush(stdout);
								
								//if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemfId));                            
								//if(BOM_line_ask_attribute_string(t_PartChildren[iChldPrts], iItemfId, &numId));
								
								AOM_UIF_ask_value(t_PartChildren[iChldPrts], "bl_item_item_id", &numId);
								
								printf("\n numId [%s]",numId);fflush(stdout);
								
								//if( BOM_line_look_up_attribute ("bl_quantity",&iQty));                            
								//if(BOM_line_ask_attribute_string(t_PartChildren[iChldPrts], iQty, &Prtqt)); 
								
								AOM_UIF_ask_value(t_PartChildren[iChldPrts], "bl_quantity", &Prtqt);
								printf("\n quantity is [%s]",Prtqt);fflush(stdout);
								
								//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_DesignGrp",&iPrtDGrp));                            
								//if(BOM_line_ask_attribute_string(t_PartChildren[iChldPrts], iPrtDGrp, &ChildPrtDGrp)); 
								AOM_UIF_ask_value(t_PartChildren[iChldPrts], "bl_Design Revision_t5_DesignGrp", &ChildPrtDGrp);
								printf("\n design group is [%s]",ChildPrtDGrp);fflush(stdout);

								if ((tc_strcmp(Prtqt,"0")!=0))
								{
									if((tc_strcmp(Obj_PrtTyp1,"Information Fitment Drawing")==0) || (tc_strcmp(Obj_PrtTyp1,"IFD Module")==0) || (tc_strcmp(Obj_PrtTyp1,"Dummy")==0)|| (tc_strcmp(Obj_PrtTyp1,"Dummy Component")==0)|| (tc_strcmp(Obj_PrtTyp1,"Dummy Assembly")==0))
									{
										printf("\n skippinf for [%s][%s][%s].",numId,nrevID,Obj_PrtTyp1);fflush(stdout);
									}
									else
									{
										printf("\n first level parent child is %s %s %s",numId,nrevID,Obj_PrtTyp1);fflush(stdout);
										
										printf("\n NON ECUPart [%d]",ECUPart);fflush(stdout);
										
										ifail = getChildren(t_PartChildren[iChldPrts],pVec,col_vec,ECUPart);
									}
								}
								//if ((tc_strcmp(ChildPrtDGrp,"16")==0))
								//{
									//printf("\n 1first level parent child is [%s] [%s] [%s] ChildPrtDGrp[%s]",numId,nrevID,Obj_PrtTyp1,ChildPrtDGrp);fflush(stdout);
										
									//ifail = getChildren(t_PartChildren[iChldPrts],pVec,col_vec);
								//}
								
							}
								
						
						}
						break;
					}
					//else if ((tc_strcmp(PartDgrp,"16") ==0))
					if ((tc_strcmp(ObjTypEE, "T5_EE_PartRevision") == 0) || (tc_strcmp(ObjTypEE, "EE Part Revision") == 0)|| (tc_strcmp(parttypes, "ECU Module") == 0))
					{
					ECUPart=1;
					printf("\n ObjTypEE[%s]GM: Latest released rev:%s and Rel Status:%s PartDgrp[%s]",ObjTypEE, rev_idd,rel_status,PartDgrp);fflush(stdout);
						/****************** New Logic Anant********************/
						if((objTag!=NULLTAG))
						{
							printf("\nobjTag NULLLLLLLLLLLLL");fflush(stdout);
						}
						if((PartTag!=NULLTAG))
						{
							printf("\nPartTag NULLLLLLLLLLLLL");fflush(stdout);
						}
						//printf("inside");fflush(stdout);
						//needs to comment as it is there in change reference folder
						//ifail = CreateRelFun( objTag,ToPlnt,PartDRStaus,PartMLStaus,PartTag,LiveProjInfo);
						ifail = BOM_create_window (&t_BomLineWindow);
						//ifail = CFM_find("Latest Working", &t_Rule );
						ifail = CFM_find("ERC release and above", &t_Rule );
						ifail = BOM_set_window_config_rule( t_BomLineWindow, t_Rule );
						tag_t *GMDclosureruleXO1 = NULLTAG;
						tag_t GMDclose_tagXO1 = NULLTAG;
						int rulefoundXO1=0;
						char **GMDrulenameXO1 = NULL;
						char **GMDrulevalueXO1 = NULL;
						//PIE_scope_t scope;
						//scope=PIE_TEAMCENTER;
						//if(PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefoundXO1, &GMDclosureruleXO1 )!=ITK_ok)   PrintErrorStack();
						if(PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefoundXO1, &GMDclosureruleXO1 )!=ITK_ok)   PrintErrorStack();
						//if(PIE_find_closure_rules2("TMLBOMExpandByQty",PIE_TEAMCENTER, &rulefoundXO1, &GMDclosureruleXO1 )!=ITK_ok)   PrintErrorStack();
						//ifail =PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",scope,&rulefoundXO,&GMDclosureruleXO);
								if (rulefoundXO1 > 0)
								{
									GMDclose_tagXO1 = GMDclosureruleXO1[0];
								}
						if(BOM_window_set_closure_rule( t_BomLineWindow,GMDclose_tagXO1, 0, GMDrulenameXO1,GMDrulevalueXO1 )!=ITK_ok)   PrintErrorStack();
						ifail = BOM_set_window_pack_all (t_BomLineWindow, true);
						ifail = BOM_window_show_suppressed ( t_BomLineWindow );
						ifail = BOM_set_window_top_line (t_BomLineWindow,NULLTAG,PartTag, null_tag, &t_TopLine);
						ifail = BOM_line_ask_child_lines (t_TopLine, &i_ChildCount, &t_PartChildren);
						printf("\n Total Child Parts Found in BomLine are ECU Module [%d]\n",i_ChildCount);fflush(stdout);
						if (i_ChildCount>0)
						{
							for (iChldPrts = 0; iChldPrts < i_ChildCount; iChldPrts++)
							{
							
								/*if(t_Childobject) t_Childobject=NULLTAG;
								t_Childobject=t_PartChildren[iChldPrts];*/
								//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&iPrTyp1));                            
								//if(BOM_line_ask_attribute_string(t_PartChildren[iChldPrts], iPrTyp1, &Obj_PrtTyp1));
								
								AOM_UIF_ask_value(t_PartChildren[iChldPrts], "bl_Design Revision_t5_PartType", &Obj_PrtTyp1);
								printf("\n Obj_PrtTyp1 [%s]",Obj_PrtTyp1);fflush(stdout);
								
								//printf("\n calling expansion for %s.",Obj_PrtTyp1);fflush(stdout);
								//if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItemTyp1e));
								//if(BOM_line_ask_attribute_string(t_PartChildren[iChldPrts], iItemTyp1e, &nrevID));
								
								AOM_UIF_ask_value(t_PartChildren[iChldPrts], "bl_rev_item_revision_id", &nrevID);
								printf("\n nrevID [%s]",nrevID);fflush(stdout);
								
								//if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemfId));                            
								//if(BOM_line_ask_attribute_string(t_PartChildren[iChldPrts], iItemfId, &numId));
								
								AOM_UIF_ask_value(t_PartChildren[iChldPrts], "bl_item_item_id", &numId);
								printf("\n numId [%s]",numId);fflush(stdout);
								
								//if( BOM_line_look_up_attribute ("bl_quantity",&iQty));                            
								//if(BOM_line_ask_attribute_string(t_PartChildren[iChldPrts], iQty, &Prtqt)); 
								
								AOM_UIF_ask_value(t_PartChildren[iChldPrts], "bl_quantity", &Prtqt);
								printf("\n quantity is [%s]",Prtqt);fflush(stdout);
								
								//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_DesignGrp",&iPrtDGrp));                            
								//if(BOM_line_ask_attribute_string(t_PartChildren[iChldPrts], iPrtDGrp, &ChildPrtDGrp)); 
								
								AOM_UIF_ask_value(t_PartChildren[iChldPrts], "bl_Design Revision_t5_DesignGrp", &ChildPrtDGrp);
								printf("\n design group is [%s] [%s]",numId,ChildPrtDGrp);fflush(stdout);

									
								printf("\n first level parent child is [%s] [%s] [%s] ChildPrtDGrp[%s]",numId,nrevID,Obj_PrtTyp1,ChildPrtDGrp);fflush(stdout);
								printf("\n for ECUPart [%d]",ECUPart);fflush(stdout);
								ifail = getChildren(t_PartChildren[iChldPrts],pVec,col_vec,ECUPart);
								
								
							}
								
						
						}
						break;
					}
					else
					{
						printf("\n final print Latest released rev:%s and Rel Status:%s PartDgrp[%s]", rev_idd,rel_status,PartDgrp);fflush(stdout);
					}
					if(tc_strstr(rel_status, "ERC Released") !=NULL )
					{
					//if (tc_strcmp(parttypes,"Vehicle")==0)
					//if ((tc_strcmp(parttypes,"Vehicle")==0)||(tc_strcmp(parttypes,"V")==0)||(tc_strcmp(parttypes,"VC")==0)||(tc_strcmp(parttypes,"Vehicle Combination")==0)||(tc_strcmp(parttypes,"VCCR")==0))
					if ((tc_strcmp(parttypes,"Vehicle")==0)||(tc_strcmp(parttypes,"V")==0)||(tc_strcmp(parttypes,"VC")==0)||(tc_strcmp(parttypes,"Vehicle Combination")==0))
					{
						
								//to add vehicle colour Part
								int     VehColcount      =  0;
								tag_t	*VehColPart_tag		= NULL;
					
								ifail = AOM_ask_value_tags(PartTag,"representation_for",&VehColcount,&VehColPart_tag);

								printf("\nNumber of colour part number : %d",VehColcount);fflush(stdout);
								
								
								if(VehColcount>0)
								{
									tag_t *ColPrtUniqTags = NULLTAG;
									ColPrtUniqTags = (tag_t *) MEM_alloc(10000 * sizeof(tag_t));
									char *ClrAssySet=NULL;
									ClrAssySet = (char *) MEM_alloc(10000 * sizeof(char));
									tc_strcpy(ClrAssySet,"");
									int colPrtCnt=0;
									int clrprtCount=0;
									for (clrprtCount=0;clrprtCount<VehColcount;clrprtCount++ )
									{
										tag_t   UColPartObjm     = NULLTAG;
										
										char*	 ColPartNo = NULL;
										char*	 ColPartRev = NULL;
										char*	 ColPartPrtType = NULL;
										tag_t ColLatestRevTag = NULLTAG;

										UColPartObjm=VehColPart_tag[clrprtCount];
										
										AOM_ask_value_string(UColPartObjm,"item_id",&ColPartNo);
										AOM_ask_value_string(UColPartObjm,"item_revision_id",&ColPartRev);
										AOM_ask_value_string(UColPartObjm,"t5_PartType",&ColPartPrtType);
										
										printf("\n Colour part Number:%s ",ColPartNo);fflush(stdout);
										printf("\n Colour part rev:%s ",ColPartRev);fflush(stdout);
										printf("\n Colour part Type:%s ",ColPartPrtType);fflush(stdout);

										getAllReleasedPartDML1(ColPartNo,&ColLatestRevTag);
										if (ColLatestRevTag!=NULLTAG)
										{
											
											if (strlen(ClrAssySet)==0)
											{
												tc_strcpy(ClrAssySet,ColPartNo);
												tc_strcat(ClrAssySet,",");
									
												ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
												colPrtCnt=colPrtCnt+1;
											}
											else if (tc_strstr(ClrAssySet,ColPartNo)==NULL)
											{
												tc_strcat(ClrAssySet,ColPartNo);
												tc_strcat(ClrAssySet,",");
									
												ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
												colPrtCnt=colPrtCnt+1;
											}

										}
									}
									if(colPrtCnt>0)
									{
									int VCClrPrt=0;
									for (VCClrPrt=0;VCClrPrt<colPrtCnt;VCClrPrt++ )
									{
										
										tag_t   ColPartObjm     = NULLTAG;
										char*	 UColPartNo = NULL;
										char*	 UColPartRev = NULL;
										char*	 UColPartPrtType = NULL;
										
										ColPartObjm=ColPrtUniqTags[VCClrPrt];
										
										AOM_ask_value_string(ColPartObjm,"item_id",&UColPartNo);
										AOM_ask_value_string(ColPartObjm,"item_revision_id",&UColPartRev);
										AOM_ask_value_string(ColPartObjm,"t5_PartType",&UColPartPrtType);
										printf("\n Colour part Number:%s ",UColPartNo);fflush(stdout);
										printf("\n Colour part rev:%s ",UColPartRev);fflush(stdout);
										printf("\n Colour part Type:%s ",UColPartPrtType);fflush(stdout);
										
								char *Fld_Des=NULL;
								Fld_Des=(char *) MEM_alloc(50);
								
								char *Fld_Des_tsk=NULL;
								Fld_Des_tsk=(char *) MEM_alloc(50);
								
								char*	 dmlNo = NULL;
								char*	 TaskNo = NULL;
								
								ifail = AOM_UIF_ask_value(DMLRevTag,"item_id",&dmlNo);fflush(stdout);
								
								printf("\n dmlNo item id %s",dmlNo);fflush(stdout);
								
								ifail = AOM_UIF_ask_value(objTag,"item_id",&TaskNo);fflush(stdout);
								
								printf("\n Task item id %s",TaskNo);fflush(stdout);
								
								tc_strcpy(Fld_Des_tsk,"");
								tc_strcat(Fld_Des_tsk,"Task-");
								tc_strcat(Fld_Des_tsk,TaskNo);
								printf("\n folderTASK description1 %s",Fld_Des_tsk);fflush(stdout);

								
								tc_strcpy(Fld_Des,"");
								tc_strcat(Fld_Des,"DML-");
								tc_strcat(Fld_Des,dmlNo);

								printf("\n folder description1 %s",Fld_Des);fflush(stdout);
								
								WSO_search_criteria_t  	criteria;
								int i,number_found,number_found1,fldEmpty=0,check=0;
								tag_t *list_of_WSO_tags=NULLTAG;
								tag_t item_type_tag	= NULLTAG;
								tag_t FL_create_input_tag= NULLTAG;
								tag_t pfolder_tag= NULLTAG;
								tag_t	Ref_Rel	= NULLTAG;
								tag_t relation= NULLTAG;
								tag_t relation1= NULLTAG;
								char * PartN = NULL;

										
										WSOM_clear_search_criteria(&criteria);
										strcpy(criteria.name,"Parts For Gate Maturation");
										strcpy(criteria.desc,Fld_Des_tsk);
										ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);
										printf("\nNumber of Parts For Gate Maturation folders found are %d\n",number_found);fflush(stdout);

										if (number_found>0)
										{
											i=i++;
											ifail = AOM_UIF_ask_value(ColPartObjm,"item_id",&PartN);
											printf("\n folder insert33 %s",PartN);fflush(stdout);
											ifail = AOM_lock(list_of_WSO_tags[0]);
											ifail = FL_insert(list_of_WSO_tags[0],ColPartObjm,i);
											ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
											ifail = AOM_unlock(list_of_WSO_tags[0]);
											ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
										}
										else
										{
											printf("\n folder description is1 %s",Fld_Des_tsk);fflush(stdout);

											//ifail = FL_create("Parts For Gate Maturation",Fld_Des_tsk,&pfolder_tag);

											if(TCTYPE_find_type("Folder", "", &item_type_tag)!=ITK_ok)PrintErrorStack();
											if(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag)!=ITK_ok)PrintErrorStack();
											if(AOM_set_value_string(FL_create_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
											if(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des_tsk)!=ITK_ok)PrintErrorStack();
											if(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();

											if (pfolder_tag!=NULLTAG)
											{
												printf("\n inside folder Parts For Gate Maturation save");fflush(stdout);
												ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
												ifail = AOM_save_with_extensions(pfolder_tag);
												ifail =AOM_refresh(pfolder_tag,TRUE);
												ifail = AOM_lock(objTag);
												if (Ref_Rel!=NULLTAG)
												{
													ifail = GRM_create_relation(objTag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
													printf("\n folder save1");fflush(stdout);
													if (relation1!=NULLTAG)
													{
														printf("\n save1");fflush(stdout);
														ifail =AOM_refresh(relation1,TRUE);
														ifail = GRM_save_relation(relation1);
														ifail = AOM_unlock(objTag);
														printf("\n relation Parts For Gate Maturation  unlock");fflush(stdout);
														printf("\n folder Parts For Gate Maturation unlock");fflush(stdout);
													}
												}
											}
											
												//printf("\n folder tag not found");
												i=i++;
												printf("\n folder Parts For Gate Maturation insert");fflush(stdout);
												ifail = AOM_UIF_ask_value(ColPartObjm,"item_id",&PartN);fflush(stdout);
												printf("\n folder PFG1  %s",PartN);fflush(stdout);
												ifail = AOM_lock(pfolder_tag);
												ifail = FL_insert(pfolder_tag,ColPartObjm,i);
												ifail = AOM_save_with_extensions(pfolder_tag);
												ifail = AOM_unlock(pfolder_tag);
												ifail =AOM_refresh(pfolder_tag,TRUE);
										}

									}
								}
						}
						
						int		n_parents = 0;
						int		jd = 0;
						int *levels = 0;
						tag_t *parents = NULLTAG;
						tag_t ParentVCTag = NULLTAG;
						ITKCALL(PS_where_used_all(PartTag,1,&n_parents,&levels,&parents));
						printf("\n\t Total Parent Part : %d",n_parents); fflush(stdout); 
						if(n_parents>0)
						{
							for (jd=0;jd<n_parents;jd++ )
							{
								
								
								char*	 VCPartNumber = NULL;
								char*	 VCPartNumberRevId = NULL;
								char*	 dmlNo = NULL;
								char*	 TaskNo = NULL;
						
								ParentVCTag=parents[jd];
								
								ifail = AOM_ask_value_string(ParentVCTag,"item_id",&VCPartNumber);
								printf("\nVCPartNumber : %s",VCPartNumber);fflush(stdout);
								AOM_ask_value_string(ParentVCTag,"item_revision_id",&VCPartNumberRevId);
								printf("\nVCPartNumberRevId : %s",VCPartNumberRevId);fflush(stdout);
								
								char *Fld_Des=NULL;
								Fld_Des=(char *) MEM_alloc(50);
								
								char *Fld_Des_tsk=NULL;
								Fld_Des_tsk=(char *) MEM_alloc(50);
								
								ifail = AOM_UIF_ask_value(DMLRevTag,"item_id",&dmlNo);fflush(stdout);
								
								printf("\n dmlNo item id %s",dmlNo);fflush(stdout);
								
								ifail = AOM_UIF_ask_value(objTag,"item_id",&TaskNo);fflush(stdout);
								
								printf("\n Task item id %s",TaskNo);fflush(stdout);
								
								tc_strcpy(Fld_Des_tsk,"");
								tc_strcat(Fld_Des_tsk,"Task-");
								tc_strcat(Fld_Des_tsk,TaskNo);
								printf("\n folderTASK description1 %s",Fld_Des_tsk);fflush(stdout);

								
								tc_strcpy(Fld_Des,"");
								tc_strcat(Fld_Des,"DML-");
								tc_strcat(Fld_Des,dmlNo);

								printf("\n folder description1 %s",Fld_Des);fflush(stdout);
								
								WSO_search_criteria_t  	criteria;
								int i,number_found,number_found1,fldEmpty=0,check=0;
								tag_t *list_of_WSO_tags=NULLTAG;
								tag_t item_type_tag	= NULLTAG;
								tag_t FL_create_input_tag= NULLTAG;
								tag_t pfolder_tag= NULLTAG;
								tag_t	Ref_Rel	= NULLTAG;
								tag_t relation= NULLTAG;
								tag_t relation1= NULLTAG;
								char * PartN = NULL;
								
								WSOM_clear_search_criteria(&criteria);
								strcpy(criteria.name,"Parts For Gate Maturation");
								strcpy(criteria.desc,Fld_Des_tsk);
								ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);
								printf("\nNumber of Parts For Gate Maturation folders found are %d\n",number_found);fflush(stdout);

								if (number_found>0)
								{
									i=i++;
									ifail = AOM_UIF_ask_value(ParentVCTag,"item_id",&PartN);
									printf("\n folder insert33 %s",PartN);fflush(stdout);
									ifail = AOM_lock(list_of_WSO_tags[0]);
									ifail = FL_insert(list_of_WSO_tags[0],ParentVCTag,i);
									ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
									ifail = AOM_unlock(list_of_WSO_tags[0]);
									ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
								}
								else
								{
									printf("\n folder description is1 %s",Fld_Des_tsk);fflush(stdout);

									//ifail = FL_create("Parts For Gate Maturation",Fld_Des_tsk,&pfolder_tag);

									if(TCTYPE_find_type("Folder", "", &item_type_tag)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag)!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_create_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des_tsk)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();

									if (pfolder_tag!=NULLTAG)
									{
										printf("\n inside folder Parts For Gate Maturation save");fflush(stdout);
										ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
										ifail = AOM_save_with_extensions(pfolder_tag);
										ifail =AOM_refresh(pfolder_tag,TRUE);
										ifail = AOM_lock(objTag);
										if (Ref_Rel!=NULLTAG)
										{
											ifail = GRM_create_relation(objTag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
											printf("\n folder save1");fflush(stdout);
											if (relation1!=NULLTAG)
											{
												printf("\n save1");fflush(stdout);
												ifail =AOM_refresh(relation1,TRUE);
												ifail = GRM_save_relation(relation1);
												ifail = AOM_unlock(objTag);
												printf("\n relation Parts For Gate Maturation  unlock");fflush(stdout);
												printf("\n folder Parts For Gate Maturation unlock");fflush(stdout);
											}
										}
									}
									
										//printf("\n folder tag not found");
										i=i++;
										printf("\n folder Parts For Gate Maturation insert");fflush(stdout);
										ifail = AOM_UIF_ask_value(ParentVCTag,"item_id",&PartN);fflush(stdout);
										printf("\n folder PFG1  %s",PartN);fflush(stdout);
										ifail = AOM_lock(pfolder_tag);
										ifail = FL_insert(pfolder_tag,ParentVCTag,i);
										ifail = AOM_save_with_extensions(pfolder_tag);
										ifail = AOM_unlock(pfolder_tag);
										ifail =AOM_refresh(pfolder_tag,TRUE);
								}
								
								int     Colcount      =  0;
								tag_t	*ColPart_tag		= NULL;
					
								ifail = AOM_ask_value_tags(ParentVCTag,"representation_for",&Colcount,&ColPart_tag);

								printf("\nNumber of colour part number : %d",Colcount);fflush(stdout);
								
								tag_t *ColPrtUniqTags = NULLTAG;
								ColPrtUniqTags = (tag_t *) MEM_alloc(10000 * sizeof(tag_t));
								char *ClrAssySet=NULL;
								ClrAssySet = (char *) MEM_alloc(10000 * sizeof(char));
								tc_strcpy(ClrAssySet,"");
								int colPrtCnt=0;
								if(Colcount>0)
								{
									int clrprtCount=0;
									for (clrprtCount=0;clrprtCount<Colcount;clrprtCount++ )
									{
										tag_t   UColPartObjm     = NULLTAG;
										
										char*	 ColPartNo = NULL;
										char*	 ColPartRev = NULL;
										char*	 ColPartPrtType = NULL;
										tag_t ColLatestRevTag = NULLTAG;

										UColPartObjm=ColPart_tag[clrprtCount];
										
										AOM_ask_value_string(UColPartObjm,"item_id",&ColPartNo);
										AOM_ask_value_string(UColPartObjm,"item_revision_id",&ColPartRev);
										AOM_ask_value_string(UColPartObjm,"t5_PartType",&ColPartPrtType);
										
										printf("\n Colour part Number:%s ",ColPartNo);fflush(stdout);
										printf("\n Colour part rev:%s ",ColPartRev);fflush(stdout);
										printf("\n Colour part Type:%s ",ColPartPrtType);fflush(stdout);

										getAllReleasedPartDML1(ColPartNo,&ColLatestRevTag);
										if (ColLatestRevTag!=NULLTAG)
										{
											
											if (strlen(ClrAssySet)==0)
											{
												tc_strcpy(ClrAssySet,ColPartNo);
												tc_strcat(ClrAssySet,",");
									
												ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
												colPrtCnt=colPrtCnt+1;
											}
											else if (tc_strstr(ClrAssySet,ColPartNo)==NULL)
											{
												tc_strcat(ClrAssySet,ColPartNo);
												tc_strcat(ClrAssySet,",");
									
												ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
												colPrtCnt=colPrtCnt+1;
											}

										}
									}
									if(colPrtCnt>0)
									{
									int VCClrPrt=0;
									for (VCClrPrt=0;VCClrPrt<colPrtCnt;VCClrPrt++ )
									{
										
										tag_t   ColPartObjm     = NULLTAG;
										char*	 UColPartNo = NULL;
										char*	 UColPartRev = NULL;
										char*	 UColPartPrtType = NULL;
										
										ColPartObjm=ColPrtUniqTags[VCClrPrt];
										
										AOM_ask_value_string(ColPartObjm,"item_id",&UColPartNo);
										AOM_ask_value_string(ColPartObjm,"item_revision_id",&UColPartRev);
										AOM_ask_value_string(ColPartObjm,"t5_PartType",&UColPartPrtType);
										printf("\n Colour part Number:%s ",UColPartNo);fflush(stdout);
										printf("\n Colour part rev:%s ",UColPartRev);fflush(stdout);
										printf("\n Colour part Type:%s ",UColPartPrtType);fflush(stdout);
										
										char * PartN = NULL;
										
										WSOM_clear_search_criteria(&criteria);
										strcpy(criteria.name,"Parts For Gate Maturation");
										strcpy(criteria.desc,Fld_Des_tsk);
										ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);
										printf("\nNumber of Parts For Gate Maturation folders found are %d\n",number_found);fflush(stdout);

										if (number_found>0)
										{
											i=i++;
											ifail = AOM_UIF_ask_value(ColPartObjm,"item_id",&PartN);
											printf("\n folder insert33 %s",PartN);fflush(stdout);
											ifail = AOM_lock(list_of_WSO_tags[0]);
											ifail = FL_insert(list_of_WSO_tags[0],ColPartObjm,i);
											ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
											ifail = AOM_unlock(list_of_WSO_tags[0]);
											ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
										}
										else
										{
											printf("\n folder description is1 %s",Fld_Des_tsk);fflush(stdout);

											//ifail = FL_create("Parts For Gate Maturation",Fld_Des_tsk,&pfolder_tag);

											if(TCTYPE_find_type("Folder", "", &item_type_tag)!=ITK_ok)PrintErrorStack();
											if(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag)!=ITK_ok)PrintErrorStack();
											if(AOM_set_value_string(FL_create_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
											if(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des_tsk)!=ITK_ok)PrintErrorStack();
											if(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();

											if (pfolder_tag!=NULLTAG)
											{
												printf("\n inside folder Parts For Gate Maturation save");fflush(stdout);
												ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
												ifail = AOM_save_with_extensions(pfolder_tag);
												ifail =AOM_refresh(pfolder_tag,TRUE);
												ifail = AOM_lock(objTag);
												if (Ref_Rel!=NULLTAG)
												{
													ifail = GRM_create_relation(objTag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
													printf("\n folder save1");fflush(stdout);
													if (relation1!=NULLTAG)
													{
														printf("\n save1");fflush(stdout);
														ifail =AOM_refresh(relation1,TRUE);
														ifail = GRM_save_relation(relation1);
														ifail = AOM_unlock(objTag);
														printf("\n relation Parts For Gate Maturation  unlock");fflush(stdout);
														printf("\n folder Parts For Gate Maturation unlock");fflush(stdout);
													}
												}
											}
											
												//printf("\n folder tag not found");
												i=i++;
												printf("\n folder Parts For Gate Maturation insert");fflush(stdout);
												ifail = AOM_UIF_ask_value(ColPartObjm,"item_id",&PartN);fflush(stdout);
												printf("\n folder PFG1  %s",PartN);fflush(stdout);
												ifail = AOM_lock(pfolder_tag);
												ifail = FL_insert(pfolder_tag,ColPartObjm,i);
												ifail = AOM_save_with_extensions(pfolder_tag);
												ifail = AOM_unlock(pfolder_tag);
												ifail =AOM_refresh(pfolder_tag,TRUE);
										}

									}
								}
								}
							}
						}
						
					}
					else if ((tc_strcmp(parttypes,"CCVC")==0) ||((tc_strcmp(parttypes,"Configurable VC")==0)))
					{
						//ifail = AOM_UIF_ask_value(PartTag, "t5_PartType", &parttypes);
								
								char*	 ccvcPartNumber = NULL;
								char*	 ccvcPartNumberRevId = NULL;
								char*	 dmlNo = NULL;
								char*	 TaskNo = NULL;
								
								ifail = AOM_ask_value_string(PartTag,"item_id",&ccvcPartNumber);
								printf("\nVCPartNumber : %s",ccvcPartNumber);fflush(stdout);
								AOM_ask_value_string(PartTag,"item_revision_id",&ccvcPartNumberRevId);
								printf("\nVCPartNumberRevId : %s",ccvcPartNumberRevId);fflush(stdout);
								
								char *Fld_Des=NULL;
								Fld_Des=(char *) MEM_alloc(50);
								
								char *Fld_Des_tsk=NULL;
								Fld_Des_tsk=(char *) MEM_alloc(50);
								
								ifail = AOM_UIF_ask_value(DMLRevTag,"item_id",&dmlNo);fflush(stdout);
								
								printf("\n dmlNo item id %s",dmlNo);fflush(stdout);
								
								ifail = AOM_UIF_ask_value(objTag,"item_id",&TaskNo);fflush(stdout);
								
								printf("\n Task item id %s",TaskNo);fflush(stdout);
								
								tc_strcpy(Fld_Des_tsk,"");
								tc_strcat(Fld_Des_tsk,"Task-");
								tc_strcat(Fld_Des_tsk,TaskNo);
								printf("\n folderTASK description1 %s",Fld_Des_tsk);fflush(stdout);

								
								tc_strcpy(Fld_Des,"");
								tc_strcat(Fld_Des,"DML-");
								tc_strcat(Fld_Des,dmlNo);

								printf("\n folder description1 %s",Fld_Des);fflush(stdout);
								
								WSO_search_criteria_t  	criteria;
								int i,number_found,number_found1,fldEmpty=0,check=0;
								tag_t *list_of_WSO_tags=NULLTAG;
								tag_t item_type_tag	= NULLTAG;
								tag_t FL_create_input_tag= NULLTAG;
								tag_t pfolder_tag= NULLTAG;
								tag_t	Ref_Rel	= NULLTAG;
								tag_t relation= NULLTAG;
								tag_t relation1= NULLTAG;
								char * PartN = NULL;
								
								// WSOM_clear_search_criteria(&criteria);
								// strcpy(criteria.name,"Parts For Gate Maturation");
								// strcpy(criteria.desc,Fld_Des_tsk);
								// ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);
								// printf("\nNumber of Parts For Gate Maturation folders found are %d\n",number_found);fflush(stdout);

								// if (number_found>0)
								// {
									// i=i++;
									// ifail = AOM_UIF_ask_value(PartTag,"item_id",&PartN);
									// printf("\n folder insert33 %s",PartN);fflush(stdout);
									// ifail = AOM_lock(list_of_WSO_tags[0]);
									// ifail = FL_insert(list_of_WSO_tags[0],PartTag,i);
									// ifail = AOM_save(list_of_WSO_tags[0]);
									// ifail = AOM_unlock(list_of_WSO_tags[0]);
									// ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
								// }
								// else
								// {
									// printf("\n folder description is1 %s",Fld_Des_tsk);fflush(stdout);

									// //ifail = FL_create("Parts For Gate Maturation",Fld_Des_tsk,&pfolder_tag);

									// if(TCTYPE_find_type("Folder", "", &item_type_tag)!=ITK_ok)PrintErrorStack();
									// if(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag)!=ITK_ok)PrintErrorStack();
									// if(AOM_set_value_string(FL_create_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
									// if(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des_tsk)!=ITK_ok)PrintErrorStack();
									// if(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();

									// if (pfolder_tag!=NULLTAG)
									// {
										// printf("\n inside folder Parts For Gate Maturation save");fflush(stdout);
										// ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
										// ifail = AOM_save(pfolder_tag);
										// ifail =AOM_refresh(pfolder_tag,TRUE);
										// ifail = AOM_lock(objTag);
										// if (Ref_Rel!=NULLTAG)
										// {
											// ifail = GRM_create_relation(objTag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
											// printf("\n folder save1");fflush(stdout);
											// if (relation1!=NULLTAG)
											// {
												// printf("\n save1");fflush(stdout);
												// ifail =AOM_refresh(relation1,TRUE);
												// ifail = GRM_save_relation(relation1);
												// ifail = AOM_unlock(objTag);
												// printf("\n relation Parts For Gate Maturation  unlock");fflush(stdout);
												// printf("\n folder Parts For Gate Maturation unlock");fflush(stdout);
											// }
										// }
									// }
									
										// //printf("\n folder tag not found");
										// i=i++;
										// printf("\n folder Parts For Gate Maturation insert");fflush(stdout);
										// ifail = AOM_UIF_ask_value(PartTag,"item_id",&PartN);fflush(stdout);
										// printf("\n folder PFG1  %s",PartN);fflush(stdout);
										// ifail = AOM_lock(pfolder_tag);
										// ifail = FL_insert(pfolder_tag,PartTag,i);
										// ifail = AOM_save(pfolder_tag);
										// ifail = AOM_unlock(pfolder_tag);
										// ifail =AOM_refresh(pfolder_tag,TRUE);
								// }
									
								int     Colcount      =  0;
								tag_t	*ColPart_tag		= NULL;
						
								ifail = AOM_ask_value_tags(PartTag,"representation_for",&Colcount,&ColPart_tag);

								printf("\nNumber of colour part number : %d",Colcount);fflush(stdout);
								
								tag_t *ColPrtUniqTags = NULLTAG;
								ColPrtUniqTags = (tag_t *) MEM_alloc(10000 * sizeof(tag_t));
								char *ClrAssySet=NULL;
								ClrAssySet = (char *) MEM_alloc(10000 * sizeof(char));
								tc_strcpy(ClrAssySet,"");
								int colPrtCnt=0;
								if(Colcount>0)
								{
									int clrprtCount=0;
									for (clrprtCount=0;clrprtCount<Colcount;clrprtCount++ )
									{
										tag_t   UColPartObjm     = NULLTAG;
										
										char*	 ColPartNo = NULL;
										char*	 ColPartRev = NULL;
										char*	 ColPartPrtType = NULL;
										tag_t ColLatestRevTag = NULLTAG;

										UColPartObjm=ColPart_tag[clrprtCount];
										
										AOM_ask_value_string(UColPartObjm,"item_id",&ColPartNo);
										AOM_ask_value_string(UColPartObjm,"item_revision_id",&ColPartRev);
										AOM_ask_value_string(UColPartObjm,"t5_PartType",&ColPartPrtType);
										
										printf("\n Colour part Number:%s ",ColPartNo);fflush(stdout);
										printf("\n Colour part rev:%s ",ColPartRev);fflush(stdout);
										printf("\n Colour part Type:%s ",ColPartPrtType);fflush(stdout);

										getAllReleasedPartDML1(ColPartNo,&ColLatestRevTag);
										if (ColLatestRevTag!=NULLTAG)
										{
											
											if (strlen(ClrAssySet)==0)
											{
												tc_strcpy(ClrAssySet,ColPartNo);
												tc_strcat(ClrAssySet,",");
									
												ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
												colPrtCnt=colPrtCnt+1;
											}
											else if (tc_strstr(ClrAssySet,ColPartNo)==NULL)
											{
												tc_strcat(ClrAssySet,ColPartNo);
												tc_strcat(ClrAssySet,",");
									
												ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
												colPrtCnt=colPrtCnt+1;
											}

										}
									}
									if(colPrtCnt>0)
									{
									int VCClrPrt=0;
									for (VCClrPrt=0;VCClrPrt<colPrtCnt;VCClrPrt++ )
									{
										
										tag_t   ColPartObjm     = NULLTAG;
										char*	 UColPartNo = NULL;
										char*	 UColPartRev = NULL;
										char*	 UColPartPrtType = NULL;
										
										ColPartObjm=ColPrtUniqTags[VCClrPrt];
										
										AOM_ask_value_string(ColPartObjm,"item_id",&UColPartNo);
										AOM_ask_value_string(ColPartObjm,"item_revision_id",&UColPartRev);
										AOM_ask_value_string(ColPartObjm,"t5_PartType",&UColPartPrtType);
										printf("\n Colour part Number:%s ",UColPartNo);fflush(stdout);
										printf("\n Colour part rev:%s ",UColPartRev);fflush(stdout);
										printf("\n Colour part Type:%s ",UColPartPrtType);fflush(stdout);
										
										char * PartN = NULL;
										
										WSOM_clear_search_criteria(&criteria);
										strcpy(criteria.name,"Parts For Gate Maturation");
										strcpy(criteria.desc,Fld_Des_tsk);
										ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);
										printf("\nNumber of Parts For Gate Maturation folders found are %d\n",number_found);fflush(stdout);

										if (number_found>0)
										{
											i=i++;
											ifail = AOM_UIF_ask_value(ColPartObjm,"item_id",&PartN);
											printf("\n folder insert33 %s",PartN);fflush(stdout);
											ifail = AOM_lock(list_of_WSO_tags[0]);
											ifail = FL_insert(list_of_WSO_tags[0],ColPartObjm,i);
											ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
											ifail = AOM_unlock(list_of_WSO_tags[0]);
											ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
										}
										else
										{
											printf("\n folder description is1 %s",Fld_Des_tsk);fflush(stdout);

											//ifail = FL_create("Parts For Gate Maturation",Fld_Des_tsk,&pfolder_tag);

											if(TCTYPE_find_type("Folder", "", &item_type_tag)!=ITK_ok)PrintErrorStack();
											if(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag)!=ITK_ok)PrintErrorStack();
											if(AOM_set_value_string(FL_create_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
											if(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des_tsk)!=ITK_ok)PrintErrorStack();
											if(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();

											if (pfolder_tag!=NULLTAG)
											{
												printf("\n inside folder Parts For Gate Maturation save");fflush(stdout);
												ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
												ifail = AOM_save_with_extensions(pfolder_tag);
												ifail =AOM_refresh(pfolder_tag,TRUE);
												ifail = AOM_lock(objTag);
												if (Ref_Rel!=NULLTAG)
												{
													ifail = GRM_create_relation(objTag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
													printf("\n folder save1");fflush(stdout);
													if (relation1!=NULLTAG)
													{
														printf("\n save1");fflush(stdout);
														ifail =AOM_refresh(relation1,TRUE);
														ifail = GRM_save_relation(relation1);
														ifail = AOM_unlock(objTag);
														printf("\n relation Parts For Gate Maturation  unlock");fflush(stdout);
														printf("\n folder Parts For Gate Maturation unlock");fflush(stdout);
													}
												}
											}
											
												//printf("\n folder tag not found");
												i=i++;
												printf("\n folder Parts For Gate Maturation insert");fflush(stdout);
												ifail = AOM_UIF_ask_value(ColPartObjm,"item_id",&PartN);fflush(stdout);
												printf("\n folder PFG1  %s",PartN);fflush(stdout);
												ifail = AOM_lock(pfolder_tag);
												ifail = FL_insert(pfolder_tag,ColPartObjm,i);
												ifail = AOM_save_with_extensions(pfolder_tag);
												ifail = AOM_unlock(pfolder_tag);
												ifail =AOM_refresh(pfolder_tag,TRUE);
										}


									}//colour part for loop
								}//colour_part_size
							}
					}
					else
					{
						printf("\n Parttype %s",parttypes);fflush(stdout);
					}
					break;
				}
				else
				{
					printf("\n rel_status %s",rel_status);fflush(stdout);
				}
																				
			}
	for(int inx = 0; inx < pVec.size() ; inx++)
	{
		GMDMLFound=0;
		ifail = WSOM_where_referenced2(pVec[inx],1,&n_tskfund,&levelsaa,&referencers,&relations);
		if (n_tskfund>0)
		{
			for (im=0;im<n_tskfund;im++ )
			{
				ifail = GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);
				ifail = GRM_list_primary_objects_only(referencers[im],tsk_dml_rel_type,&cnt,&DMLRev);
				printf("\n GM: DML Revision from part attached %d.",cnt);fflush(stdout);
				for (jj=0;jj<cnt ;jj++ )
				{
					ifail = ITEM_rev_sequence_is_latest(DMLRev[jj],&is_lat);
					printf("\n GM: is_lat value: %d.",is_lat);fflush(stdout);

					if(is_lat != true)
					{
						printf("\n GM: is_lat is not true.");fflush(stdout);
					}
					else
					{
						DMLTag = DMLRev[jj];
						ifail = AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLtype);
						if(tc_strcmp(DMLtype,"TODR")==0)
						{
							printf("\n Part is already attached to GM DML task. %s %s %s ",ChildRevID,Child_SeqId);
							GMDMLFound=1;
						}
						
					}
				}
			}
		}
																				//else if (GMDMLFound==0)
if (GMDMLFound==0)
{
	//if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItemType));
	//if(BOM_line_ask_attribute_string(pVec[inx], iItemType, &ChildRevID));
	
	AOM_UIF_ask_value(pVec[inx], "bl_rev_item_revision_id", &ChildRevID);
	printf("\n ChildRevID -------------------------------=[%s]",ChildRevID);fflush(stdout);
	
	//if( BOM_line_look_up_attribute ("bl_item_item_id",&iItemId));                            
	//if(BOM_line_ask_attribute_string(pVec[inx], iItemId, &Child_SeqId));
	
	AOM_UIF_ask_value(pVec[inx], "bl_item_item_id", &Child_SeqId);
	printf("\n Child_SeqId -------------------------------=[%s]",Child_SeqId);fflush(stdout);

	//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&iPrTyp));                            
	//if(BOM_line_ask_attribute_string(pVec[inx], iPrTyp, &Obj_PrtTyp));
	
	AOM_UIF_ask_value(pVec[inx], "bl_Design Revision_t5_PartType", &Obj_PrtTyp);
	printf("\n Obj_PrtTyp -------------------------------=[%s]",Obj_PrtTyp);fflush(stdout);
	char			*ChildPrtDGrpnew						= NULL;
	char			*ChildPrtObjType						= NULL;
	
	AOM_UIF_ask_value(pVec[inx], "bl_Design Revision_t5_DesignGrp", &ChildPrtDGrpnew);
	printf("\n ChildPrtDGrpnew -------------------------------=[%s]",ChildPrtDGrpnew);fflush(stdout);
	AOM_UIF_ask_value(pVec[inx], "fnd0bl_line_object_type", &ChildPrtObjType);
	printf("\n ChildPrtObjType -------------------------------=[%s]",ChildPrtObjType);fflush(stdout);
	
	//if( BOM_line_look_up_attribute ("bl_rev_release_status_list",&rel));                            
	//if(BOM_line_ask_attribute_string(pVec[inx], rel, &rel_stats));
	
	AOM_UIF_ask_value(pVec[inx], "bl_rev_release_status_list", &rel_stats);
	printf("\n rel_stats -------------------------------=[%s]",rel_stats);fflush(stdout);

	//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_PartStatus",&iPrtSta));                            
	//if(BOM_line_ask_attribute_string(pVec[inx], iPrtSta, &PrtDRstus));
	
	AOM_UIF_ask_value(pVec[inx], "bl_Design Revision_t5_PartStatus", &PrtDRstus);
	printf("\n PrtDRstus -------------------------------=[%s]",PrtDRstus);fflush(stdout);
	
	//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_DesignMilestoneStatus",&iPrtMLSta));                            
	//if(BOM_line_ask_attribute_string(pVec[inx], iPrtMLSta, &PrtMLstus));
	
	AOM_UIF_ask_value(pVec[inx], "bl_Design Revision_t5_DesignMilestoneStatus", &PrtMLstus);
	printf("\n PrtMLstus -------------------------------=[%s]",PrtMLstus);fflush(stdout);

	
	//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_ProjectCode",&iPrjCd));                            
	//if(BOM_line_ask_attribute_string(pVec[inx], iPrjCd, &PrtProj));
	
	AOM_UIF_ask_value(pVec[inx], "bl_Design Revision_t5_ProjectCode", &PrtProj);
	printf("\n PrtProj -------------------------------=[%s]",PrtProj);fflush(stdout);
	printf("\n PrtProj ckeck1111111111");fflush(stdout);
	
	AOM_UIF_ask_value(pVec[inx], "bl_quantity", &Ptq);
	printf("\n Ptq -------------------------------=[%s]",Ptq);fflush(stdout);																					
	printf("\n quantitya is  %s %s",Ptq,Child_SeqId);fflush(stdout);
	

	//if( BOM_line_look_up_attribute ("bl_line_object",&iItemRevCh)); 
	//if(BOM_line_ask_attribute_tag(pVec[inx],iItemRevCh, &bl_chils_rev_tg));
	
	AOM_ask_value_tag(pVec[inx], "bl_line_object", &bl_chils_rev_tg);
	//printf("\n bl_chils_rev_tg -------------------------------=[%s]",bl_chils_rev_tg);fflush(stdout);
	
	//if( BOM_line_look_up_attribute ("bl_quantity",&iQy));                            
	//if(BOM_line_ask_attribute_string(pVec[inx],iQy,&Ptq));

	
	
	printf("\n [%d] PartNumber is [%s] revision is [%s] PartType is [%s] DRStatus is [%s] MilestoneStatus is [%s] ProjectCode [%s] ReleaseStatus [%s] ",iChldPrts,ChildRevID,Child_SeqId,Obj_PrtTyp,PrtDRstus,PrtMLstus,PrtProj,rel_stats);fflush(stdout);

		//Information Fitment Drawing												
	//if((tc_strcmp(PrtProj,"1111")==0) || (tc_strcmp(Obj_PrtTyp,"D")==0))
	if ((tc_strcmp(Ptq,"0")!=0))
	{
		if((tc_strcmp(PrtProj,"1111")==0) || (tc_strcmp(Obj_PrtTyp,"Dummy")==0) || (tc_strcmp(Obj_PrtTyp,"Dummy Component")==0)|| (tc_strcmp(Obj_PrtTyp,"Dummy Assembly")==0)|| (tc_strcmp(Obj_PrtTyp,"Information Fitment Drawing")==0)
		|| (tc_strcmp(Obj_PrtTyp,"IFD Module")==0))
		{
			printf("\n GM: Dummy or STD part....");fflush(stdout);
		}
		else if (tc_strstr(rel_stats,"ERC Released")!=NULL)
		{
				ifail = CreateRelFun( objTag,ToPlnt,PrtDRstus,PrtMLstus,bl_chils_rev_tg,LiveProjInfo);
		}
		else
		{
			//if(ITEM_find_item(PatM_no,&All_item_t)!=ITK_ok)PrintErrorStack();
			ifail = ITEM_list_all_revs(bl_chils_rev_tg, &Item_cunt, &rev_listt);
			printf("\n GM:Total rev rev_listt: %d.", Item_cunt);fflush(stdout);
			if(Item_cunt > 0)
			{
				iij=0;
				for(iij=Item_cunt-1;iij>=0;iij--)
				{
					PartTagg = rev_listt[iij];
					ifail = AOM_UIF_ask_value(PartTagg, "item_revision_id", &rev_idt);
					ifail = AOM_UIF_ask_value(PartTagg, "release_status_list", &rell_status);
					printf("\n GM: Latest rev_idt:%s and rell_status:%s", rev_idt,rell_status);fflush(stdout);
					if(tc_strstr(rell_status, "ERC Released") !=NULL)
					{
						ifail = CreateRelFun(objTag,ToPlnt,PrtDRstus,PrtMLstus,bl_chils_rev_tg,LiveProjInfo);
						break;
					}
				}
			}
		}
	}
	//if ((tc_strcmp(Ptq,"0")==0))
	//{
	if ((tc_strcmp(ChildPrtObjType, "T5_EE_PartRevision") == 0) || (tc_strcmp(ChildPrtObjType, "EE Part Revision") == 0)|| (tc_strcmp(Obj_PrtTyp, "ECU Module") == 0))
	{
		//if ((tc_strcmp(ChildPrtDGrpnew,"16")==0))
		//{
			if (tc_strstr(rel_stats,"ERC Released")!=NULL)
			{
					ifail = CreateRelFun( objTag,ToPlnt,PrtDRstus,PrtMLstus,bl_chils_rev_tg,LiveProjInfo);
			}
			else
			{
				//if(ITEM_find_item(PatM_no,&All_item_t)!=ITK_ok)PrintErrorStack();
				ifail = ITEM_list_all_revs(bl_chils_rev_tg, &Item_cunt, &rev_listt);
				printf("\n GM:Total rev rev_listt: %d.", Item_cunt);fflush(stdout);
				if(Item_cunt > 0)
				{
					iij=0;
					for(iij=Item_cunt-1;iij>=0;iij--)
					{
						PartTagg = rev_listt[iij];
						ifail = AOM_UIF_ask_value(PartTagg, "item_revision_id", &rev_idt);
						ifail = AOM_UIF_ask_value(PartTagg, "release_status_list", &rell_status);
						printf("\n GM: Latest rev_idt:%s and rell_status:%s", rev_idt,rell_status);fflush(stdout);
						if(tc_strstr(rell_status, "ERC Released") !=NULL)
						{
							ifail = CreateRelFun(objTag,ToPlnt,PrtDRstus,PrtMLstus,bl_chils_rev_tg,LiveProjInfo);
							break;
						}
					}
				}
			}
		//}
		
	}
	//}
}
}
//checking color parts loop
for(int cx = 0; cx < col_vec.size() ; cx++)
{
	ifail = AOM_UIF_ask_value(col_vec[cx], "release_status_list", &Clrel_status1);
	ifail = AOM_UIF_ask_value(col_vec[cx], "t5_PartStatus", &Clrel_Dr);
	ifail = AOM_UIF_ask_value(col_vec[cx], "t5_DesignMilestoneStatus", &Clrel_MLStatus);
   if (tc_strstr(Clrel_status1,"ERC Released")!=NULL)
	{
			ifail = CreateRelFun(objTag,ToPlnt,Clrel_Dr,Clrel_MLStatus,col_vec[cx],LiveProjInfo);
	}
	else
	{
		//if(ITEM_find_item(PatM_no,&All_item_t)!=ITK_ok)PrintErrorStack();
		ifail = ITEM_list_all_revs(col_vec[cx], &Item_cunt1, &rev_listt11);
		printf("\n color list11t: %d.", Item_cunt1);fflush(stdout);
		if(Item_cunt1 > 0)
		{
				cl=0;
			for(cl=Item_cunt1-1;cl>=0;cl--)
			{
				ClPartTagg = rev_listt11[cl];
				ifail = AOM_UIF_ask_value(ClPartTagg, "item_revision_id", &rev_cl);
				ifail = AOM_UIF_ask_value(ClPartTagg, "release_status_list", &clrell_status);
				printf("\n GM: Latest rev_idt:%s and rell_status:%s", rev_cl,clrell_status);fflush(stdout);
				if(tc_strstr(clrell_status, "ERC Released") !=NULL)
				{
					ifail = CreateRelFun(objTag,ToPlnt,Clrel_Dr,Clrel_MLStatus,ClPartTagg,LiveProjInfo);
					break;
				}
			}
		}
	}
}
						}
					}
				}
				//}
			}
		}
	}
		else
		{
			printf("\n GM: No Expanssion for CO task.");fflush(stdout);
		}
	}
	
}
else
{
	printf("\n GM: Other than GM DML.");fflush(stdout);
}
}
}
}
}
}
}
}
}
}
}//input DML Dag
return ifail;
}

int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;
	
	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	//MT end
	printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2, &n_tags_found2, &tags_found2)!=ITK_ok)PrintErrorStack();
	printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		printf("\n FUN:Inside Find for part no:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2, &n_tags_foundd2, &tags_foundd2)!=ITK_ok)PrintErrorStack();
		printf("\n FUN:count n_tags_foundd2 :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
	}
	else
	{
		printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
	}
	/*if(attrs2) MEM_free(attrs2);
	if(attrss2) MEM_free(attrss2);
	if(values2) MEM_free(values2);
	if(valuess2) MEM_free(valuess2);*/

	return OutPutTag;	
}

int getChildren(tag_t chlidlineTag , vector<tag_t> &vChildlines,vector<tag_t> &vCol,int ECUPart)
{
	int ifail = ITK_ok;
	int numchildLines = 0;
	char *Obj_Prt=NULL;
	char *revId=NULL;
	char *ChrevID=NULL;
	char *Clrev_id=NULL;
	char *ClPartNm=NULL;
	char *colIndPrt=NULL;
	char *Piqun=NULL;
	char *ChildprtDGrp=NULL;
	char *ChnumId=NULL;
	char *revnum=NULL;
	tag_t	tRelationFind		= NULLTAG;
	tag_t	chils_rev_tg		= NULLTAG;
	int iPrT = 0,iqun=0,iPrTCol=0,iIte=0,iId=0,iItTye=0,iItId=0,iItemRevCh=0,M,Clcount=0,iprtDGrp=0;
	tag_t *CLlist = NULL;
	tag_t *childlines = NULL;
	iLevel++;

	vChildlines.push_back(chlidlineTag);

	//printf("Inside getChildnes function");
	ifail = BOM_line_ask_all_child_lines(chlidlineTag , &numchildLines , &childlines);
	//if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItTye));
	//if(BOM_line_ask_attribute_string(chlidlineTag, iItTye, &ChrevID));
	
	AOM_UIF_ask_value(chlidlineTag, "bl_rev_item_revision_id", &ChrevID);
	printf("\n ChrevID -------------------------------=[%s]",ChrevID);fflush(stdout);
	
	//if( BOM_line_look_up_attribute ("bl_item_item_id",&iItId));                            
	//if(BOM_line_ask_attribute_string(chlidlineTag, iItId, &ChnumId));
	
	AOM_UIF_ask_value(chlidlineTag, "bl_item_item_id", &ChnumId);
	printf("\n ChnumId -------------------------------=[%s]",ChnumId);fflush(stdout);
	
	//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_ColourInd",&iPrTCol));                            
	//if(BOM_line_ask_attribute_string(chlidlineTag, iPrTCol,&colIndPrt));
	
	AOM_UIF_ask_value(chlidlineTag, "bl_Design Revision_t5_ColourInd", &colIndPrt);
	printf("\n colIndPrt -------------------------------=[%s]",colIndPrt);fflush(stdout);
	
	printf("\n 11Child at level color indicator is  %d %s %s %s \n ", iLevel, ChnumId,ChrevID,colIndPrt);fflush(stdout);
	if (tc_strcmp(colIndPrt,"Y")==0)
	{
		ifail = GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind);
		if (tRelationFind!=NULLTAG)
		{
			//if( BOM_line_look_up_attribute ("bl_line_object",&iItemRevCh)); 
			//if(BOM_line_ask_attribute_tag(chlidlineTag,iItemRevCh, &chils_rev_tg));
			
			AOM_ask_value_tag(chlidlineTag, "bl_line_object", &chils_rev_tg);
			//printf("\n chils_rev_tg -------------------------------=[%s]",chils_rev_tg);fflush(stdout);

			ifail = GRM_list_primary_objects_only(chils_rev_tg,tRelationFind,&Clcount,&CLlist);
			if (Clcount>0)
			{
				for (M=0;M<Clcount ;M++)
				{
					ifail = AOM_UIF_ask_value(CLlist[M], "item_revision_id", &Clrev_id);
					//ifail = AOM_UIF_ask_value(CLlist[M], "release_status_list", &Clrel_status);
					//ifail = AOM_ask_value_string(CLlist[M],"t5_PartStatus",&PartDR1);
					ifail = AOM_ask_value_string(CLlist[M],"item_id",&ClPartNm);
					printf("\n for  [%s %s ] color is %s %s ",ChnumId,ChrevID,ClPartNm,Clrev_id);fflush(stdout);
					vCol.push_back(CLlist[M]);
				}
			}
		}
		else
		{
			printf("\n for [%s %s] color_ind is %s but color parts are not found ",ChnumId,ChrevID,colIndPrt);fflush(stdout);
		}
	}
	printf("\n numchildLines [%d]",numchildLines);fflush(stdout);
	if(numchildLines > 0)
	{
		for(int i = 0 ; i< numchildLines ; i++)
		{
			//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&iPrT));                            
			//if(BOM_line_ask_attribute_string(childlines[i], iPrT, &Obj_Prt));
			
			AOM_UIF_ask_value(childlines[i], "bl_Design Revision_t5_PartType", &Obj_Prt);
			printf("\n Obj_Prt -------------------------------=[%s]",Obj_Prt);fflush(stdout);
			
			//printf("\n calling expansion for in  %s.",Obj_Prt);fflush(stdout);
			//if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iIte));
			//if(BOM_line_ask_attribute_string(childlines[i], iIte, &revId));
			
			AOM_UIF_ask_value(childlines[i], "bl_rev_item_revision_id", &revId);
			printf("\n revId -------------------------------=[%s]",revId);fflush(stdout);
			
			//if( BOM_line_look_up_attribute ("bl_item_item_id",&iId));                            
			//if(BOM_line_ask_attribute_string(childlines[i], iId, &revnum));
			
			AOM_UIF_ask_value(childlines[i], "bl_item_item_id", &revnum);
			printf("\n revnum -------------------------------=[%s]",revnum);fflush(stdout);

								
			//if( BOM_line_look_up_attribute ("bl_quantity",&iqun));                            
			//if(BOM_line_ask_attribute_string(childlines[i],iqun,&Piqun)); 
			
			AOM_UIF_ask_value(childlines[i], "bl_quantity", &Piqun);
			printf("\n Piqun -------------------------------=[%s]",Piqun);fflush(stdout);
			
			printf("\n quantitya is %s %s",revnum,Piqun);fflush(stdout);
			
			//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_DesignGrp",&iprtDGrp));                            
			//if(BOM_line_ask_attribute_string(childlines[i], iprtDGrp, &ChildprtDGrp)); 
			
			AOM_UIF_ask_value(childlines[i], "bl_Design Revision_t5_DesignGrp", &ChildprtDGrp);
			printf("\n ChildprtDGrp -------------------------------=[%s]",ChildprtDGrp);fflush(stdout);
			
			printf("\n design group is %s %s",revnum,ChildprtDGrp);fflush(stdout);
			printf("\n ECUPart [%d] ",ECUPart);fflush(stdout);
			if(ECUPart==0)
			{
				if (tc_strcmp(Piqun,"0")!=0)
				{
					if((tc_strcmp(Obj_Prt,"Information Fitment Drawing")==0) || (tc_strcmp(Obj_Prt,"IFD Module")==0) || (tc_strcmp(Obj_Prt,"Dummy")==0)|| (tc_strcmp(Obj_Prt,"Dummy Component")==0)|| (tc_strcmp(Obj_Prt,"Dummy Assembly")==0))
					{
						printf("\n skippinfcc for %s %s %s.",revnum,revId,Obj_Prt);fflush(stdout);
					}
					else
					{
						//printf("\n 3rd level %s %s.",revnum,revId);fflush(stdout);
						getChildren( childlines[i] ,vChildlines,vCol,ECUPart);
					}
				}
			}
			if(ECUPart>0)
			{
				if (tc_strcmp(ChildprtDGrp,"16")==0)
				{
					printf("\n I am in ECUPart [%d]",ECUPart);fflush(stdout);
					printf("\n ECU parts design group is %s %s",revnum,ChildprtDGrp);fflush(stdout);
					getChildren( childlines[i] ,vChildlines,vCol,ECUPart);
				}
			}
			else
			{
				printf("\n skippinfcc for %s %s %s.",revnum,revId,Obj_Prt);fflush(stdout);
			}
			
		}
	}
	if(childlines != NULL )
	{
		MEM_free(childlines);
	}


	return ifail;

}
int getChildrenColSnapShot(tag_t chlidlineTag , vector<tag_t> &vChildlines,vector<tag_t> &vCol )
{
	int ifail = ITK_ok;
	int numchildLines = 0;
	char *Obj_Prt=NULL;
	char *revId=NULL;
	char *ChrevID=NULL;
	char *Clrev_id=NULL;
	char *ClPartNm=NULL;
	char *colIndPrt=NULL;
	char *colIndPrt1=NULL;
	char *Piqun=NULL;
	char *ChnumId=NULL;
	char *revnum=NULL;
	tag_t	tRelationFind		= NULLTAG;
	tag_t	chils_rev_tg		= NULLTAG;
	int iPrT = 0,iqun,iPrTCol,iIte,iId,iItTye,iItId,iItemRevCh,M,Clcount;
	tag_t *CLlist = NULL;
	tag_t *childlines = NULL;
	iLevel++;

	vChildlines.push_back(chlidlineTag);

	//printf("Inside getChildnes function");
	ifail = BOM_line_ask_all_child_lines(chlidlineTag , &numchildLines , &childlines);
	//if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItTye));
	//if(BOM_line_ask_attribute_string(chlidlineTag, iItTye, &ChrevID));
	
	AOM_UIF_ask_value(chlidlineTag, "bl_rev_item_revision_id", &ChrevID);
	printf("\n ChrevID -------------------------------=[%s]",ChrevID);fflush(stdout);
			
	//if( BOM_line_look_up_attribute ("bl_item_item_id",&iItId));                            
	//if(BOM_line_ask_attribute_string(chlidlineTag, iItId, &ChnumId));
	
	AOM_UIF_ask_value(chlidlineTag, "bl_item_item_id", &ChnumId);
	printf("\n ChnumId -------------------------------=[%s]",ChnumId);fflush(stdout);
	
	//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_ColourInd",&iPrTCol));                            
	//if(BOM_line_ask_attribute_string(chlidlineTag, iPrTCol,&colIndPrt));
	
	AOM_UIF_ask_value(chlidlineTag, "bl_Design Revision_t5_ColourInd", &colIndPrt);
	printf("\n colIndPrt -------------------------------=[%s]",colIndPrt);fflush(stdout);
	
	printf("\n Child at level color indicator is  %d %s %s %s \n ", iLevel, ChnumId,ChrevID,colIndPrt);fflush(stdout);
	// if (tc_strcmp(colIndPrt,"Y")==0)
	// {
		// ifail = GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind);
		// if (tRelationFind!=NULLTAG)
		// {
			// if( BOM_line_look_up_attribute ("bl_line_object",&iItemRevCh)); 
			// if(BOM_line_ask_attribute_tag(chlidlineTag,iItemRevCh, &chils_rev_tg));

			// ifail = GRM_list_primary_objects_only(chils_rev_tg,tRelationFind,&Clcount,&CLlist);
			// if (Clcount>0)
			// {
				// for (M=0;M<Clcount ;M++)
				// {
					// ifail = AOM_UIF_ask_value(CLlist[M], "item_revision_id", &Clrev_id);
					// //ifail = AOM_UIF_ask_value(CLlist[M], "release_status_list", &Clrel_status);
					// //ifail = AOM_ask_value_string(CLlist[M],"t5_PartStatus",&PartDR1);
					// ifail = AOM_ask_value_string(CLlist[M],"item_id",&ClPartNm);
					// printf("\n for  [%s %s ] color is %s %s ",ChnumId,ChrevID,ClPartNm,Clrev_id);fflush(stdout);
					// vCol.push_back(CLlist[M]);
				// }
			// }
		// }
		// else
		// {
			// printf("\n for [%s %s] color_ind is %s but color parts are not found ",ChnumId,ChrevID,colIndPrt);fflush(stdout);
		// }
	// }
	if(numchildLines > 0)
	{
		for(int i = 0 ; i< numchildLines ; i++)
		{
			//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&iPrT));                            
			//if(BOM_line_ask_attribute_string(childlines[i], iPrT, &Obj_Prt));
			
			AOM_UIF_ask_value(childlines[i], "bl_Design Revision_t5_PartType", &Obj_Prt);
			printf("\n Obj_Prt -------------------------------=[%s]",Obj_Prt);fflush(stdout);
			//printf("\n calling expansion for in  %s.",Obj_Prt);fflush(stdout);
			//if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iIte));
			//if(BOM_line_ask_attribute_string(childlines[i], iIte, &revId));
			
			AOM_UIF_ask_value(childlines[i], "bl_rev_item_revision_id", &revId);
			printf("\n revId -------------------------------=[%s]",revId);fflush(stdout);
			
			//if( BOM_line_look_up_attribute ("bl_item_item_id",&iId));                            
			//if(BOM_line_ask_attribute_string(childlines[i], iId, &revnum));
			
			AOM_UIF_ask_value(childlines[i], "bl_item_item_id", &revnum);
			printf("\n revnum -------------------------------=[%s]",revnum);fflush(stdout);

								
			//if( BOM_line_look_up_attribute ("bl_quantity",&iqun));                            
			//if(BOM_line_ask_attribute_string(childlines[i],iqun,&Piqun)); 
			
			AOM_UIF_ask_value(childlines[i], "bl_quantity", &Piqun);
			printf("\n Piqun -------------------------------=[%s]",Piqun);fflush(stdout);
	
			printf("\n quantitya is %s %s",revnum,Piqun);fflush(stdout);
			int iPrTCol1 = 0;
			char *PcolIndPrt=NULL;
			
			int iPrTDgrp1 = 0;
			char *PPrtDgrp=NULL;

			//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_ColourInd",&iPrTCol1));                            
			//if(BOM_line_ask_attribute_string(childlines[i], iPrTCol1,&PcolIndPrt));
			
			AOM_UIF_ask_value(childlines[i], "bl_Design Revision_t5_ColourInd", &PcolIndPrt);
			printf("\n PcolIndPrt -------------------------------=[%s]",PcolIndPrt);fflush(stdout);
			
			printf("\n ColourInd is %s %s",revnum,PcolIndPrt);fflush(stdout);
			
			//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_DesignGrp",&iPrTDgrp1));                            
			//if(BOM_line_ask_attribute_string(childlines[i], iPrTDgrp1,&PPrtDgrp));
			
			AOM_UIF_ask_value(childlines[i], "bl_Design Revision_t5_DesignGrp", &PPrtDgrp);
			printf("\n PPrtDgrp -------------------------------=[%s]",PPrtDgrp);fflush(stdout);
			
			printf("\n Design Group is [%s] [%s]",revnum,PPrtDgrp);fflush(stdout);
			
			if (tc_strcmp(Piqun,"0")!=0)
			{
				if ((tc_strcmp(PcolIndPrt,"C")==0))
				{
					if((tc_strcmp(Obj_Prt,"Information Fitment Drawing")==0) || (tc_strcmp(Obj_Prt,"IFD Module")==0) || (tc_strcmp(Obj_Prt,"Dummy")==0)|| (tc_strcmp(Obj_Prt,"Dummy Component")==0)|| (tc_strcmp(Obj_Prt,"Dummy Assembly")==0))
					{
						printf("\n skippinfcc for %s %s %s.",revnum,revId,Obj_Prt);fflush(stdout);
					}
					else
					{
						//printf("\n 3rd level %s %s.",revnum,revId);fflush(stdout);
						getChildrenColSnapShot( childlines[i] ,vChildlines,vCol);
					}
				}
			}
			else if (tc_strcmp(PPrtDgrp,"16")==0)
			{
				printf("\n 1Design Group is [%s] [%s]",revnum,PPrtDgrp);fflush(stdout);
				getChildrenColSnapShot( childlines[i] ,vChildlines,vCol);
			}
			else
			{
				printf("\n Design Group is [%s] [%s]",revnum,PPrtDgrp);fflush(stdout);
			}
			
		}
	}
	if(childlines != NULL )
	{
		MEM_free(childlines);
	}


	return ifail;

}
int getChildrenCol(tag_t chlidlineTag , vector<tag_t> &vChildlines,vector<tag_t> &vCol )
{
	int ifail = ITK_ok;
	int numchildLines = 0;
	char *Obj_Prt=NULL;
	char *revId=NULL;
	char *ChrevID=NULL;
	char *Clrev_id=NULL;
	char *ClPartNm=NULL;
	char *colIndPrt=NULL;
	char *Piqun=NULL;
	char *ChnumId=NULL;
	char *revnum=NULL;
	tag_t	tRelationFind		= NULLTAG;
	tag_t	chils_rev_tg		= NULLTAG;
	int iPrT = 0,iqun,iPrTCol,iIte,iId,iItTye,iItId,iItemRevCh,M,Clcount;
	tag_t *CLlist = NULL;
	tag_t *childlines = NULL;
	iLevel++;

	vChildlines.push_back(chlidlineTag);

	//printf("Inside getChildnes function");
	ifail = BOM_line_ask_all_child_lines(chlidlineTag , &numchildLines , &childlines);
	//if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iItTye));
	//if(BOM_line_ask_attribute_string(chlidlineTag, iItTye, &ChrevID));
	
	AOM_UIF_ask_value(chlidlineTag, "bl_rev_item_revision_id", &ChrevID);
	printf("\n ChrevID -------------------------------=[%s]",ChrevID);fflush(stdout);
			
	//if( BOM_line_look_up_attribute ("bl_item_item_id",&iItId));                            
	//if(BOM_line_ask_attribute_string(chlidlineTag, iItId, &ChnumId));
	
	AOM_UIF_ask_value(chlidlineTag, "bl_item_item_id", &ChnumId);
	printf("\n ChnumId -------------------------------=[%s]",ChnumId);fflush(stdout);
	
	
	//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_ColourInd",&iPrTCol));                            
	//if(BOM_line_ask_attribute_string(chlidlineTag, iPrTCol,&colIndPrt));
	
	AOM_UIF_ask_value(chlidlineTag, "bl_Design Revision_t5_ColourInd", &colIndPrt);
	printf("\n colIndPrt -------------------------------=[%s]",colIndPrt);fflush(stdout);
	
	
	printf("\n Child at level color indicator is  %d %s %s %s \n ", iLevel, ChnumId,ChrevID,colIndPrt);fflush(stdout);
	// if (tc_strcmp(colIndPrt,"Y")==0)
	// {
		// ifail = GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind);
		// if (tRelationFind!=NULLTAG)
		// {
			// if( BOM_line_look_up_attribute ("bl_line_object",&iItemRevCh)); 
			// if(BOM_line_ask_attribute_tag(chlidlineTag,iItemRevCh, &chils_rev_tg));

			// ifail = GRM_list_primary_objects_only(chils_rev_tg,tRelationFind,&Clcount,&CLlist);
			// if (Clcount>0)
			// {
				// for (M=0;M<Clcount ;M++)
				// {
					// ifail = AOM_UIF_ask_value(CLlist[M], "item_revision_id", &Clrev_id);
					// //ifail = AOM_UIF_ask_value(CLlist[M], "release_status_list", &Clrel_status);
					// //ifail = AOM_ask_value_string(CLlist[M],"t5_PartStatus",&PartDR1);
					// ifail = AOM_ask_value_string(CLlist[M],"item_id",&ClPartNm);
					// printf("\n for  [%s %s ] color is %s %s ",ChnumId,ChrevID,ClPartNm,Clrev_id);fflush(stdout);
					// vCol.push_back(CLlist[M]);
				// }
			// }
		// }
		// else
		// {
			// printf("\n for [%s %s] color_ind is %s but color parts are not found ",ChnumId,ChrevID,colIndPrt);fflush(stdout);
		// }
	// }
	if(numchildLines > 0)
	{
		for(int i = 0 ; i< numchildLines ; i++)
		{
			//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_PartType",&iPrT));                            
			//if(BOM_line_ask_attribute_string(childlines[i], iPrT, &Obj_Prt));
			
			AOM_UIF_ask_value(childlines[i], "bl_Design Revision_t5_PartType", &Obj_Prt);
			printf("\n Obj_Prt -------------------------------=[%s]",Obj_Prt);fflush(stdout);
	
			//printf("\n calling expansion for in  %s.",Obj_Prt);fflush(stdout);
			//if( BOM_line_look_up_attribute ("bl_rev_item_revision_id",&iIte));
			//if(BOM_line_ask_attribute_string(childlines[i], iIte, &revId));
			
			AOM_UIF_ask_value(childlines[i], "bl_rev_item_revision_id", &revId);
			printf("\n revId -------------------------------=[%s]",revId);fflush(stdout);
			
			//if( BOM_line_look_up_attribute ("bl_item_item_id",&iId));                            
			//if(BOM_line_ask_attribute_string(childlines[i], iId, &revnum));
			
			AOM_UIF_ask_value(childlines[i], "bl_item_item_id", &revnum);
			printf("\n revnum -------------------------------=[%s]",revnum);fflush(stdout);

								
			//if( BOM_line_look_up_attribute ("bl_quantity",&iqun));                            
			//if(BOM_line_ask_attribute_string(childlines[i],iqun,&Piqun)); 
			
			AOM_UIF_ask_value(childlines[i], "bl_quantity", &Piqun);
			printf("\n Piqun -------------------------------=[%s]",Piqun);fflush(stdout);
			
			printf("\n quantitya is %s %s",revnum,Piqun);fflush(stdout);
			
			int iPrtDgrp=0;
			char *PiPrtDgrp=NULL;
			//if( BOM_line_look_up_attribute ("bl_Design Revision_t5_DesignGrp",&iPrtDgrp));                            
			//if(BOM_line_ask_attribute_string(childlines[i],iPrtDgrp,&PiPrtDgrp)); 
			
			AOM_UIF_ask_value(childlines[i], "bl_Design Revision_t5_DesignGrp", &PiPrtDgrp);
			printf("\n PiPrtDgrp -------------------------------=[%s]",PiPrtDgrp);fflush(stdout);
			
			printf("\n Part Design Group is %s %s",revnum,PiPrtDgrp);fflush(stdout);
			
			
			if (tc_strcmp(Piqun,"0")!=0)
			{
				if ((tc_strcmp(colIndPrt,"C")==0))
				{
					if((tc_strcmp(Obj_Prt,"Information Fitment Drawing")==0) || (tc_strcmp(Obj_Prt,"IFD Module")==0) || (tc_strcmp(Obj_Prt,"Dummy")==0)|| (tc_strcmp(Obj_Prt,"Dummy Component")==0)|| (tc_strcmp(Obj_Prt,"Dummy Assembly")==0))
					{
						printf("\n skippinfcc for %s %s %s.",revnum,revId,Obj_Prt);fflush(stdout);
					}
					else
					{
						//printf("\n 3rd level %s %s.",revnum,revId);fflush(stdout);
						getChildrenCol( childlines[i] ,vChildlines,vCol);
					}
				}
			}
			else if (tc_strcmp(PiPrtDgrp,"16")==0)
			{
				printf("\n Part Design Group is %s %s",revnum,PiPrtDgrp);fflush(stdout);
				getChildrenCol( childlines[i] ,vChildlines,vCol);
			}
			else
			{
				printf("\n 1Part Design Group is %s %s",revnum,PiPrtDgrp);fflush(stdout);
				getChildrenCol( childlines[i] ,vChildlines,vCol);
			}
			
		}
	}
	if(childlines != NULL )
	{
		MEM_free(childlines);
	}


	return ifail;

}

// int FolderEmpty(tag_t FlTag)
// {
	// int floEmp=0,ReqFdrSize=0,FldObjCount=0,jrr;
	// tag_t *FoldObj_tag=NULLTAG;
	// char	*sPrtName 	= NULL;

	// printf("\n Folder already available. Remove earlier parts available.\n");fflush(stdout);
	// if(FL_ask_size(FlTag,&ReqFdrSize));
	// printf("\n :ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
	// if(FL_ask_references(FlTag,FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
	// printf("\n :FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
	
	// if(FldObjCount>0)
	// {
		// jrr=0;
		// for (jrr=0;jrr<FldObjCount;jrr++ )
		// {
			// if(AOM_ask_value_string(FoldObj_tag[jrr],"item_id",&sPrtName)!=ITK_ok)PrintErrorStack();
			// printf("\n CarryOver Parts:removing part from folder: %s.", sPrtName);fflush(stdout);
			// if(AOM_lock( FlTag)!=ITK_ok)PrintErrorStack();
			// if(FL_remove(FlTag,FoldObj_tag[jrr])!=ITK_ok)PrintErrorStack();
			// if(AOM_save (FlTag)!=ITK_ok)PrintErrorStack();
			// if(AOM_unlock(FlTag)!=ITK_ok)PrintErrorStack();
			// if(AOM_refresh(FlTag,TRUE)!=ITK_ok)PrintErrorStack();
		// }
		// if(AOM_save (FlTag)!=ITK_ok)PrintErrorStack();
		// if(AOM_unlock(FlTag)!=ITK_ok)PrintErrorStack();
		// if(AOM_refresh(FlTag,TRUE)!=ITK_ok)PrintErrorStack();
		// floEmp=1;
		
	// }
	// else
	// {
		// printf("\n jFolder already NULL.\n");fflush(stdout);
		// floEmp=1;
	// }



	// if (floEmp >0)
	// {
		// printf("\n Folder references are removed.  \n");fflush(stdout);
		// return 1;
	// }
	// else
	// {
		// printf("\n Folder references are not removed.  \n");fflush(stdout);
		// return 0;
	// }

	// return 0;	
	
// }

int FolderEmpty(tag_t FlTag)
{
	int floEmp=0,ReqFdrSize=0,FldObjCount=0,jrr;
	tag_t *FoldObj_tag=NULLTAG;
	char	*sPrtName 	= NULL;
	char	*Fname 	= NULL;
	
	if(AOM_ask_value_string(FlTag,"current_name",&Fname)!=ITK_ok)PrintErrorStack();
	printf("\n In function FolderEmpty Folder Name is: [%s]",Fname);fflush(stdout);		
	printf("\n Folder already available. Remove earlier parts available.\n");fflush(stdout);
	
	if(FL_ask_size(FlTag,&ReqFdrSize));
	printf("\n :ReqFdrSize is:   %d\n",ReqFdrSize);fflush(stdout);
	if(FL_ask_references(FlTag,FL_fsc_by_date_modified ,&FldObjCount,&FoldObj_tag));
	printf("\n :FldObjCount is..:   %d\n",FldObjCount);fflush(stdout);
	
	if(FldObjCount>0)
	{
		jrr=0;
		for (jrr=0;jrr<FldObjCount;jrr++ )
		{
			if(AOM_ask_value_string(FoldObj_tag[jrr],"item_id",&sPrtName)!=ITK_ok)PrintErrorStack();
			printf("\n Removing part from folder: [%s]--Folder Name is:[%s]", sPrtName,Fname);fflush(stdout);
			
			if(AOM_lock( FlTag)!=ITK_ok)PrintErrorStack();
			if(FL_remove(FlTag,FoldObj_tag[jrr])!=ITK_ok)PrintErrorStack();
			if(AOM_save_with_extensions (FlTag)!=ITK_ok)PrintErrorStack();
			if(AOM_unlock(FlTag)!=ITK_ok)PrintErrorStack();
			if(AOM_refresh(FlTag,TRUE)!=ITK_ok)PrintErrorStack();
		}
		if(AOM_save_with_extensions (FlTag)!=ITK_ok)PrintErrorStack();
		if(AOM_unlock(FlTag)!=ITK_ok)PrintErrorStack();
		if(AOM_refresh(FlTag,TRUE)!=ITK_ok)PrintErrorStack();
		floEmp=1;
		
	}
	else
	{
		printf("\n Folder[%s] already NULL.\n",Fname);fflush(stdout);
		floEmp=1;
	}



	if (floEmp >0)
	{
		printf("\n Folder references are removed.  \n");fflush(stdout);
		return 1;
	}
	else
	{
		printf("\n Folder references are not removed.  \n");fflush(stdout);
		return 0;
	}

	return 0;	
	
}
int tm_CheckDRPreRevAvalabilityCol(tag_t PartObj,char *Toplnt)
{
	
	char			* Child_rev_idd				= NULL;
	char			* DRnew				= NULL;
	//char			* PrtMLstnew				= NULL;
	char			* prt_idd				= NULL;
	char			* Chld_Rel_Stus			= NULL;

	int crr=0,ii=0,n_fl_fnd=0,Itm_found=0,Chld_Rel_Stus_Cunt=0;
	int CarryOverRemove=0;
	int rev_count=0;
	tag_t	*Grevsn_list = NULLTAG;
	tag_t	*Child_status_lst		= NULLTAG;
	
	int		ifail 			= ITK_ok;
	int		CreatAllowNONCLPrt = 0;
	int     VehNONColcount      =  0;
	tag_t	*VehNONColPart_tag		= NULL;
	
	printf(" i am in tm_CheckDRPreRevAvalabilityCol \n");fflush(stdout);
	ifail = AOM_ask_value_tags(PartObj,"TC_Is_Represented_By",&VehNONColcount,&VehNONColPart_tag);
	 printf(" VehNONColcount %d\n",VehNONColcount);fflush(stdout);
	if(VehNONColcount>0)
	{
		int NonclrprtCount=0;		
		for (NonclrprtCount=0;NonclrprtCount<VehNONColcount;NonclrprtCount++ )
				{
					CreatAllowNONCLPrt = 0;
					tag_t   VehNONColPart_tagObj     = NULLTAG;
					
					char*	 NonColPartNo = NULL;
					char*	 NonColPartRev = NULL;
					char*	 NonColPartPrtType = NULL;
					char*	 NonColPrtDRStatus = NULL;
					VehNONColPart_tagObj=VehNONColPart_tag[NonclrprtCount];
					
					VehNONColPart_tagObj=VehNONColPart_tag[NonclrprtCount];
					AOM_ask_value_string(VehNONColPart_tagObj,"item_id",&NonColPartNo);
					AOM_ask_value_string(VehNONColPart_tagObj,"item_revision_id",&NonColPartRev);
					AOM_ask_value_string(VehNONColPart_tagObj,"t5_PartType",&NonColPartPrtType);
					AOM_ask_value_string(VehNONColPart_tagObj,"t5_PartStatus",&NonColPrtDRStatus);
					
					printf("\n NonColour part Number1:%s ",NonColPartNo);fflush(stdout);
					printf("\n NonColour part rev1:%s ",NonColPartRev);fflush(stdout);
					printf("\n NonColour part Type1:%s ",NonColPartPrtType);fflush(stdout);
					printf("\n NonColour part DR Status1:%s ",NonColPrtDRStatus);fflush(stdout);
					
					printf("\n CheckNonColDRStatus1 : Toplnt:[%s] NonColPrtDRStatus:[%s]", Toplnt,NonColPrtDRStatus);fflush(stdout);

	if(ITEM_list_all_revs (VehNONColPart_tagObj, &rev_count, &Grevsn_list)!=ITK_ok)PrintErrorStack();
	if(rev_count > 0)
	{
		for(ii=rev_count-1;ii>=0;ii--)
		{
			if(AOM_UIF_ask_value (Grevsn_list[ii], "current_id", &prt_idd)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "item_revision_id", &Child_rev_idd)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "t5_PartStatus", &DRnew)!=ITK_ok)PrintErrorStack();
			//if(AOM_UIF_ask_value (Grevsn_list[ii], "t5_DesignMilestoneStatus", &PrtMLstnew)!=ITK_ok)PrintErrorStack();
			//printf("\n  rev is:%s DR :%s", Child_rev_idd,DRnew);fflush(stdout);
			printf("\n in function tm_CheckDRPreRevAvalabilityCols Part Numbr[%s] rev is:[%s] DR :[%s]", prt_idd,Child_rev_idd,DRnew);fflush(stdout);
			if(WSOM_ask_release_status_list (Grevsn_list[ii], &Chld_Rel_Stus_Cunt, &Child_status_lst)!=ITK_ok)PrintErrorStack();
			//printf("\n PO:Chld_Rel_Stus_Cunt is:%d.", Chld_Rel_Stus_Cunt);fflush(stdout);
			if(Chld_Rel_Stus_Cunt > 0)
			{
				crr=0;
				for(crr=0;crr<Chld_Rel_Stus_Cunt;crr++)
				{	CarryOverRemove=0;
					//Checking PO availability on any revision.
					if(AOM_ask_value_string (Child_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
					if(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL || tc_strstr(Chld_Rel_Stus,"ERC Released")!=NULL )
					{
						printf("\n:Chld_Rel_Stus:%s", Chld_Rel_Stus);fflush(stdout);
						
						if((tc_strcmp(Toplnt,"DR3P")==0 || tc_strcmp(Toplnt,"AR3P")==0) &&(tc_strcmp(DRnew,"DR4")==0|| tc_strcmp(DRnew,"AR4")==0 || tc_strcmp(DRnew,"AR3P")==0 ||tc_strcmp(DRnew,"DR3P")==0|| tc_strcmp(DRnew,"AR5")==0 || tc_strcmp(DRnew,"DR5")==0))
						{
						   printf("\n PartN1is %s %s %s  %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus);fflush(stdout);
						   CarryOverRemove=1;
						   break;
						}
						else if ((tc_strcmp(Toplnt,"DR4")==0 || tc_strcmp(Toplnt,"AR4")==0) &&(tc_strcmp(DRnew,"DR4")==0|| tc_strcmp(DRnew,"AR4")==0 || tc_strcmp(DRnew,"AR5")==0 || tc_strcmp(DRnew,"DR5")==0))
						{
							printf("\n PartN2 is %s %s:%s %s\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus);
							CarryOverRemove=1;
							break;
						}
						else if ((tc_strcmp(Toplnt,"DR5")==0 || tc_strcmp(Toplnt,"AR5")==0) && (tc_strcmp(DRnew,"DR5")==0|| tc_strcmp(DRnew,"AR5")==0))
						{
							printf("\n PartN3 is  %s %s %s %s: \n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						else if ((tc_strcmp(Toplnt,"DR3")==0 || tc_strcmp(Toplnt,"AR3")==0) && (tc_strcmp(DRnew,"DR4")==0|| tc_strcmp(DRnew,"AR4")==0 || tc_strcmp(DRnew,"AR3P")==0 || tc_strcmp(DRnew,"DR3P")==0|| tc_strcmp(DRnew,"AR5")==0 || tc_strcmp(DRnew,"DR5")==0))
						{
							printf("\n PartN4 is %s %s %s %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
					}
				}
				
			}	

			if (CarryOverRemove==1)
			{
				break;
			}
			
		}
	}
	}
}
	if (CarryOverRemove >0)
	{
		printf("\n PreRev:DR check PASSED for part.  \n");fflush(stdout);
		return 1;
	}
	else
	{
		printf("\n PreRev:DR check FAILED for part.  \n");fflush(stdout);
		return 0;
	}

	return 0;	
}

int tm_CheckDRPreRevAvalability(tag_t PartObj,char *Toplnt)
{
	
	char			* Child_rev_idd				= NULL;
	char			* DRnew				= NULL;
	char			* PrtMLstnew				= NULL;
	char			* prt_idd				= NULL;
	char			* Chld_Rel_Stus			= NULL;

	int crr=0,ii=0,n_fl_fnd=0,Itm_found=0,Chld_Rel_Stus_Cunt=0;
	int CarryOverRemove=0;
	int rev_count=0;
	tag_t	*Grevsn_list = NULLTAG;
	tag_t	*Child_status_lst		= NULLTAG;


	if(ITEM_list_all_revs (PartObj, &rev_count, &Grevsn_list)!=ITK_ok)PrintErrorStack();
	if(rev_count > 0)
	{
		for(ii=rev_count-1;ii>=0;ii--)
		{
			if(AOM_UIF_ask_value (Grevsn_list[ii], "current_id", &prt_idd)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "item_revision_id", &Child_rev_idd)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "t5_PartStatus", &DRnew)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "t5_DesignMilestoneStatus", &PrtMLstnew)!=ITK_ok)PrintErrorStack();
			//printf("\n  rev is:%s DR :%s", Child_rev_idd,DRnew);fflush(stdout);
			printf("\n in function tm_CheckDRPreRevAvalability Part Numbr[%s] rev is:[%s] DR :[%s] Ms Status[%s]", prt_idd,Child_rev_idd,DRnew,PrtMLstnew);fflush(stdout);
			if(WSOM_ask_release_status_list (Grevsn_list[ii], &Chld_Rel_Stus_Cunt, &Child_status_lst)!=ITK_ok)PrintErrorStack();
			//printf("\n PO:Chld_Rel_Stus_Cunt is:%d.", Chld_Rel_Stus_Cunt);fflush(stdout);
			if(Chld_Rel_Stus_Cunt > 0)
			{
				crr=0;
				for(crr=0;crr<Chld_Rel_Stus_Cunt;crr++)
				{	CarryOverRemove=0;
					//Checking PO availability on any revision.
					if(AOM_ask_value_string (Child_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
					if(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL || tc_strstr(Chld_Rel_Stus,"ERC Released")!=NULL )
					{
						printf("\n:Chld_Rel_Stus:%s", Chld_Rel_Stus);fflush(stdout);
						
						if((tc_strcmp(Toplnt,"DR3P")==0 || tc_strcmp(Toplnt,"AR3P")==0) &&(tc_strcmp(DRnew,"DR4")==0|| tc_strcmp(DRnew,"AR4")==0 || tc_strcmp(DRnew,"AR3P")==0 ||tc_strcmp(DRnew,"DR3P")==0|| tc_strcmp(DRnew,"AR5")==0 || tc_strcmp(DRnew,"DR5")==0))
						{
						   printf("\n PartN1is %s %s %s  %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus);fflush(stdout);
						   CarryOverRemove=1;
						   break;
						}
						else if ((tc_strcmp(Toplnt,"DR4")==0 || tc_strcmp(Toplnt,"AR4")==0) &&(tc_strcmp(DRnew,"DR4")==0|| tc_strcmp(DRnew,"AR4")==0 || tc_strcmp(DRnew,"AR5")==0 || tc_strcmp(DRnew,"DR5")==0))
						{
							printf("\n PartN2 is %s %s:%s %s\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus);
							CarryOverRemove=1;
							break;
						}
						else if ((tc_strcmp(Toplnt,"DR5")==0 || tc_strcmp(Toplnt,"AR5")==0) && (tc_strcmp(DRnew,"DR5")==0|| tc_strcmp(DRnew,"AR5")==0))
						{
							printf("\n PartN3 is  %s %s %s %s: \n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						else if ((tc_strcmp(Toplnt,"DR3")==0 || tc_strcmp(Toplnt,"AR3")==0) && (tc_strcmp(DRnew,"DR4")==0|| tc_strcmp(DRnew,"AR4")==0 || tc_strcmp(DRnew,"AR3P")==0 || tc_strcmp(DRnew,"DR3P")==0|| tc_strcmp(DRnew,"AR5")==0 || tc_strcmp(DRnew,"DR5")==0))
						{
							printf("\n PartN4 is %s %s %s %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
					}
				}
				
			}	

			if (CarryOverRemove==1)
			{
				break;
			}
			
		}
	}
	if (CarryOverRemove >0)
	{
		printf("\n PreRev:DR check PASSED for part.  \n");fflush(stdout);
		return 1;
	}
	else
	{
		printf("\n PreRev:DR check FAILED for part.  \n");fflush(stdout);
		return 0;
	}

	return 0;	
}

int tm_CheckMileStonePreRevAvalability(tag_t PartObj,char *Toplnt)
{
	
	char			* Child_rev_idd				= NULL;
	char			* DRnew				= NULL;
	char			* PrtMLstnew				= NULL;
	char			* prt_idd				= NULL;
	char			* Chld_Rel_Stus			= NULL;

	int crr=0,ii=0,n_fl_fnd=0,Itm_found=0,Chld_Rel_Stus_Cunt=0;
	int CarryOverRemove=0;
	int rev_count=0;
	tag_t	*Grevsn_list = NULLTAG;
	tag_t	*Child_status_lst		= NULLTAG;

	printf("\n:tm_CheckMileStonePreRevAvalability for imtured parts");fflush(stdout);
	if(ITEM_list_all_revs (PartObj, &rev_count, &Grevsn_list)!=ITK_ok)PrintErrorStack();
	if(rev_count > 0)
	{
		for(ii=rev_count-1;ii>=0;ii--)
		{
			if(AOM_UIF_ask_value (Grevsn_list[ii], "current_id", &prt_idd)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "item_revision_id", &Child_rev_idd)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "t5_PartStatus", &DRnew)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "t5_DesignMilestoneStatus", &PrtMLstnew)!=ITK_ok)PrintErrorStack();
			//printf("\n  rev is:%s DR :%s", Child_rev_idd,DRnew);fflush(stdout);
			printf("\n in function tm_CheckMileStonePreRevAvalability Part Numbr[%s] rev is:[%s] DR :[%s] Ms Status[%s]", prt_idd,Child_rev_idd,DRnew,PrtMLstnew);fflush(stdout);
			if(WSOM_ask_release_status_list (Grevsn_list[ii], &Chld_Rel_Stus_Cunt, &Child_status_lst)!=ITK_ok)PrintErrorStack();
			//printf("\n PO:Chld_Rel_Stus_Cunt is:%d.", Chld_Rel_Stus_Cunt);fflush(stdout);
			if(Chld_Rel_Stus_Cunt > 0)
			{
				crr=0;
				for(crr=0;crr<Chld_Rel_Stus_Cunt;crr++)
				{	CarryOverRemove=0;
					//Checking PO availability on any revision.
					if(AOM_ask_value_string (Child_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
					if(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL || tc_strstr(Chld_Rel_Stus,"ERC Released")!=NULL )
					{
						printf("\n:Chld_Rel_Stus:%s", Chld_Rel_Stus);fflush(stdout);
						
						if((tc_strcmp(Toplnt,"UNV1")==0) &&(tc_strcmp(PrtMLstnew,"UNV0")==0|| tc_strcmp(PrtMLstnew,"UNV1")==0|| tc_strcmp(PrtMLstnew,"UNV2")==0|| tc_strcmp(PrtMLstnew,"UNV3")==0 || tc_strcmp(PrtMLstnew,"Pre-UPV0")==0 || tc_strcmp(PrtMLstnew,"UPV0")==0 || tc_strcmp(PrtMLstnew,"UPV1")==0 || tc_strcmp(PrtMLstnew,"UPV2")==0|| tc_strcmp(PrtMLstnew,"UPV3")==0))
						{
						   printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
						   CarryOverRemove=1;
						   break;
						}
						else if ((tc_strcmp(Toplnt,"UNV2")==0) &&(tc_strcmp(PrtMLstnew,"UNV1")==0 || tc_strcmp(PrtMLstnew,"UNV2")==0 || tc_strcmp(PrtMLstnew,"UNV3")==0 || tc_strcmp(PrtMLstnew,"Pre-UPV0")==0|| tc_strcmp(PrtMLstnew,"UPV0")==0 || tc_strcmp(PrtMLstnew,"UPV1")==0 || tc_strcmp(PrtMLstnew,"UPV2")==0|| tc_strcmp(PrtMLstnew,"UPV3")==0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						else if ((tc_strcmp(Toplnt,"UPV0")==0) && (tc_strcmp(PrtMLstnew,"Pre-UPV0")==0 || tc_strcmp(PrtMLstnew,"UPV0")==0 ||tc_strcmp(PrtMLstnew,"UPV1")==0 || tc_strcmp(PrtMLstnew,"UPV2")==0|| tc_strcmp(PrtMLstnew,"UPV3")==0 || tc_strcmp(PrtMLstnew,"UNV1")==0 || tc_strcmp(PrtMLstnew,"UNV2")==0 || tc_strcmp(PrtMLstnew,"UNV3")==0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						else if ((tc_strcmp(Toplnt,"UNV3")==0) &&(tc_strcmp(PrtMLstnew,"UNV2")==0 ||tc_strcmp(PrtMLstnew,"UNV3")==0)||tc_strcmp(PrtMLstnew,"UPV0")==0 ||tc_strcmp(PrtMLstnew,"UPV1")==0||tc_strcmp(PrtMLstnew,"UPV2")==0||tc_strcmp(PrtMLstnew,"UPV3")==0)
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						else if((tc_strcmp(Toplnt,"UPV1")==0) &&(tc_strcmp(PrtMLstnew,"UNV2")==0 ||tc_strcmp(PrtMLstnew,"UNV3")==0)||tc_strcmp(PrtMLstnew,"UPV0")==0 ||tc_strcmp(PrtMLstnew,"UPV1")==0||tc_strcmp(PrtMLstnew,"UPV2")==0||tc_strcmp(PrtMLstnew,"UPV3")==0)
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						else if((tc_strcmp(Toplnt,"DR3")==0) &&(tc_strcmp(PrtMLstnew,"UNV3")==0|| tc_strcmp(PrtMLstnew,"UPV2")==0|| tc_strcmp(PrtMLstnew,"UPV3")==0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						else if((tc_strcmp(Toplnt,"UPV2")==0) &&(tc_strcmp(PrtMLstnew,"UPV1")==0 || tc_strcmp(PrtMLstnew,"UPV2")==0 || tc_strcmp(PrtMLstnew,"UPV3")==0 ))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						else if((tc_strcmp(Toplnt,"UPV2")==0) &&(tc_strcmp(PrtMLstnew,"UNV3")==0 ))
						{
							if(tc_strcmp(DRnew,"DR2")!=0)
							{
								CarryOverRemove=1;
								break;
							}
						}
						else if ((tc_strcmp(Toplnt,"UPV3")==0) &&(tc_strcmp(PrtMLstnew,"UPV3")==0 || tc_strcmp(PrtMLstnew,"UPV2")==0 || tc_strcmp(PrtMLstnew,"UNV3")==0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;

							break;
						}
					}
				}
				
			}	

			if (CarryOverRemove==1)
			{
				break;
			}
			
		}
	}
	if (CarryOverRemove >0)
	{
		printf("\n PreRev:Miles Stone status check PASSED for part.  \n");fflush(stdout);
		return 1;
	}
	else
	{
		printf("\n PreRev:Miles Stone status check FAILED for part.  \n");fflush(stdout);
		return 0;
	}

	return 0;	
}
int tm_CheckMileStoneOnDRPreRevAvalability(tag_t PartObj,char *Toplnt)
{
	
	char			* Child_rev_idd				= NULL;
	char			* DRnew				= NULL;
	char			* PrtPrj				= NULL;
	char			* PrtMLstnew				= NULL;
	char			* prt_idd				= NULL;
	char			* Chld_Rel_Stus			= NULL;

	int crr=0,ii=0,n_fl_fnd=0,Itm_found=0,Chld_Rel_Stus_Cunt=0;
	int CarryOverRemove=0;
	int rev_count=0;
	tag_t	*Grevsn_list = NULLTAG;
	tag_t	*Child_status_lst		= NULLTAG;

	printf("\n:tm_CheckMileStoneOnDRPreRevAvalability for imtured parts");fflush(stdout);
	if(ITEM_list_all_revs (PartObj, &rev_count, &Grevsn_list)!=ITK_ok)PrintErrorStack();
	if(rev_count > 0)
	{
		for(ii=rev_count-1;ii>=0;ii--)
		{
			if(AOM_UIF_ask_value (Grevsn_list[ii], "current_id", &prt_idd)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "item_revision_id", &Child_rev_idd)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "t5_PartStatus", &DRnew)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "t5_DesignMilestoneStatus", &PrtMLstnew)!=ITK_ok)PrintErrorStack();
			if(AOM_UIF_ask_value (Grevsn_list[ii], "t5_ProjectCode", &PrtPrj)!=ITK_ok)PrintErrorStack();
			
			printf("\n Project is live for miles stone t5_PartStatus %s  \n",DRnew);fflush(stdout);
			printf("\n Project is live for miles stone t5_DesignMilestoneStatus %s  \n",PrtMLstnew);fflush(stdout);
			printf("\n Project is live for miles stone t5_ProjectCode %s  \n",PrtPrj);fflush(stdout);
			
			//printf("\n  rev is:%s DR :%s", Child_rev_idd,DRnew);fflush(stdout);
			if(WSOM_ask_release_status_list (Grevsn_list[ii], &Chld_Rel_Stus_Cunt, &Child_status_lst)!=ITK_ok)PrintErrorStack();
			//printf("\n PO:Chld_Rel_Stus_Cunt is:%d.", Chld_Rel_Stus_Cunt);fflush(stdout);
			if(Chld_Rel_Stus_Cunt > 0)
			{
				crr=0;
				for(crr=0;crr<Chld_Rel_Stus_Cunt;crr++)
				{	CarryOverRemove=0;
					//Checking PO availability on any revision.
					if(AOM_ask_value_string (Child_status_lst[crr], "object_name", &Chld_Rel_Stus)!=ITK_ok)PrintErrorStack();
					if(tc_strstr(Chld_Rel_Stus,"T5_LcsErcRlzd")!=NULL || tc_strstr(Chld_Rel_Stus,"ERC Released")!=NULL )
					{
						printf("\n:Chld_Rel_Stus:%s", Chld_Rel_Stus);fflush(stdout);
			
						printf("\n Project is not live for miles stone  \n");fflush(stdout);
						// if((tc_strcmp(Toplnt,"UNV1")==0) &&(tc_strcmp(DRnew,"DR1")==0 || tc_strcmp(DRnew,"DR2")==0 || tc_strcmp(DRnew,"DR3")==0 || tc_strcmp(DRnew,"DR4")==0))
						// {
						   // printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
						   // CarryOverRemove=1;
						   // break;
						// }
					
						//if((tc_strcmp(Toplnt,"UNV2")==0) &&(tc_strcmp(DRnew,"DR1")==0 || tc_strcmp(DRnew,"DR2")==0 || tc_strcmp(DRnew,"DR3")==0 || tc_strcmp(DRnew,"DR4")==0))
						if((tc_strcmp(Toplnt,"UNV2")==0) &&(tc_strcmp(DRnew,"DR0")!=0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						//else if((tc_strcmp(Toplnt,"UPV0")==0) &&(tc_strcmp(DRnew,"DR1")==0 || tc_strcmp(DRnew,"DR2")==0 || tc_strcmp(DRnew,"DR3")==0 || tc_strcmp(DRnew,"DR4")==0))
						if((tc_strcmp(Toplnt,"UPV0")==0) &&(tc_strcmp(DRnew,"DR0")!=0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						//else if((tc_strcmp(Toplnt,"UNV3")==0) &&(tc_strcmp(DRnew,"DR1")==0 || tc_strcmp(DRnew,"DR2")==0 || tc_strcmp(DRnew,"DR3")==0 || tc_strcmp(DRnew,"DR4")==0))
						if((tc_strcmp(Toplnt,"UNV3")==0) &&(tc_strcmp(DRnew,"DR0")!=0 || tc_strcmp(DRnew,"DR1")!=0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						//else if((tc_strcmp(Toplnt,"UPV1")==0) &&(tc_strcmp(DRnew,"DR1")==0 || tc_strcmp(DRnew,"DR2")==0 || tc_strcmp(DRnew,"DR3")==0 || tc_strcmp(DRnew,"DR4")==0))
						if((tc_strcmp(Toplnt,"UPV1")==0) &&(tc_strcmp(DRnew,"DR0")!=0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						//else if((tc_strcmp(Toplnt,"DR3")==0) &&(tc_strcmp(DRnew,"DR2")==0 || tc_strcmp(DRnew,"DR3")==0 || tc_strcmp(DRnew,"DR4")==0))
						if((tc_strcmp(Toplnt,"DR3")==0) &&(tc_strcmp(DRnew,"DR0")!=0 || tc_strcmp(DRnew,"DR1")!=0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						//else if((tc_strcmp(Toplnt,"UPV2")==0) &&(tc_strcmp(DRnew,"DR1")==0 || tc_strcmp(DRnew,"DR2")==0 || tc_strcmp(DRnew,"DR3")==0 || tc_strcmp(DRnew,"DR4")==0))
						if((tc_strcmp(Toplnt,"UPV2")==0) &&(tc_strcmp(DRnew,"DR0")!=0 || tc_strcmp(DRnew,"DR1")!=0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
						//else if((tc_strcmp(Toplnt,"UPV3")==0) &&(tc_strcmp(DRnew,"DR2")==0 || tc_strcmp(DRnew,"DR3")==0 || tc_strcmp(DRnew,"DR4")==0))
					   if((tc_strcmp(Toplnt,"UPV3")==0) &&(tc_strcmp(DRnew,"DR0")!=0|| tc_strcmp(DRnew,"DR1")!=0))
						{
							 printf("\n PartN1is %s %s %s  %s Miles Stone status %s:\n",prt_idd,DRnew,Child_rev_idd,Chld_Rel_Stus,PrtMLstnew);fflush(stdout);
							CarryOverRemove=1;
							break;
						}
					}
				}
				
			}	

			if (CarryOverRemove==1)
			{
				break;
			}
			
		}
	}
	if (CarryOverRemove >0)
	{
		printf("\n Miles Stone status check PASSED for Part not live project  \n");fflush(stdout);
		return 1;
	}
	else
	{
		printf("\n PreRev:Miles Stone status check FAILED for Part not live project \n");fflush(stdout);
		return 0;
	}

	return 0;	
}
int CreateRelFun(tag_t objTag, char* Toplnt, char*  PrtDRst, char*  PrtMLst,tag_t rev_tag, char * ProjInfo)
{
	int		ifail 		= ITK_ok;
	int		CreatAllow = 0;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t	tsk_dml_rel_type	= NULLTAG;
	tag_t	*DMLRevision = NULLTAG;
	tag_t	Ref_Rel	= NULLTAG;
	tag_t relation= NULLTAG;
	tag_t relation1= NULLTAG;
	tag_t pfolder_tag= NULLTAG;
	tag_t item_type_tag	= NULLTAG;
	tag_t item_type_tag1 = NULLTAG;
	tag_t FL_create_input_tag= NULLTAG;
	tag_t FL_co_input_tag= NULLTAG;
	tag_t projTag= NULLTAG;
	tag_t GrpTag= NULLTAG;
	tag_t item_tag1	= NULLTAG;
	tag_t *itemRev_tag1=NULLTAG;

	char			* DsgGrp						= NULL;
	char			* TaskAnlyst						= NULL;
	char			* TskNm1						= NULL;
	char			* projectCode						= NULL;
	char			* GrpMembName						= NULL;
	char			* DRnewRev						= NULL;
	char			* DRnew						= NULL;
	char			* clrell_status						= NULL;
	char			* dmlNo						= NULL;
	char			* dNo						= NULL;
	char			* TaskNo						= NULL;
	char			* PartN						= NULL;
	char			* Ipart						= NULL;
	char			* Fld_Des						= NULL;
	int i,number_found,number_found1,fldEmpty=0,check=0;
	int	AccesFound=0,FlCreated=0,count,count1;
	WSO_search_criteria_t  	criteria;
	tag_t *list_of_WSO_tags=NULLTAG;

	int	jkl=0;
	int	addToCarryOver=0;
	int	jk=0;
	int	Itm_found=0;
	int	Gmcnt1=0;
	int	Gmcnt2=0;
	int	Gmcnt3=0;
	tag_t	*GmFound1 = NULLTAG;
	tag_t	*GmFound2 = NULLTAG;
	tag_t	*GmFound3 = NULLTAG;
	tag_t	*Itm_tagS = NULLTAG;
	tag_t	part_tg		= NULLTAG;
	char   UserAccess[1000];
	char   UserAccess2[1000];

	//if (objTag==NULLTAG || tc_strcmp(Toplnt,"")==0 ||tc_strlen(Toplnt)==0|| Toplnt==NULL || tc_strcmp(PrtDRst,"")==0 || PrtDRst==NULL || tc_strlen(PrtDRst)==0 || rev_tag==NULLTAG || tc_strcmp(ProjInfo,"")==0 || ProjInfo==NULL || tc_strlen(ProjInfo)==0)
	if (objTag==NULLTAG || tc_strcmp(Toplnt,"")==0 ||tc_strlen(Toplnt)==0|| Toplnt==NULL || rev_tag==NULLTAG)
	{
		printf("\n Input arguments are NULL or Blank for CreateRelFun");fflush(stdout);
		return 0;
	}
	if (objTag==NULLTAG )
	{
		printf("\n objTag NULL CreateRelFun");fflush(stdout);
	}
	if (rev_tag==NULLTAG )
	{
		printf("\n rev_tag NULLL CreateRelFun");fflush(stdout);
	}
	
	printf("\n Inside CreateRelFun: Toplnt:%s PrtDRst:%s PrtMLst:%s", Toplnt,PrtDRst,PrtMLst);fflush(stdout);
	//ifail = AOM_UIF_ask_value(objTag,"item_id",&TskNm);
	ifail = AOM_UIF_ask_value(objTag,"analyst_user_id",&TaskAnlyst);fflush(stdout);
	ifail = AOM_UIF_ask_value(objTag,"item_id",&TskNm1);fflush(stdout);
	ifail = AOM_UIF_ask_value(rev_tag,"t5_DesignGrp",&DsgGrp);fflush(stdout);
	ifail = AOM_UIF_ask_value(rev_tag,"t5_ProjectCode",&projectCode);fflush(stdout);

	printf("\n task number[%s] task analyst [%s], Design Group[%s], ProjectCode is [%s]",TskNm1,TaskAnlyst,DsgGrp,projectCode);fflush(stdout);


	char			* prtColInd						= NULL;
	char			* PrtNum						= NULL;
	char			* PrtNumRevSeq						= NULL;
	ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PrtNum);fflush(stdout);
	ifail = AOM_UIF_ask_value(rev_tag,"item_revision_id",&PrtNumRevSeq);fflush(stdout);
	printf("\n In function CreateRelFun Part Number [%s][%s]",PrtNum,PrtNumRevSeq);fflush(stdout);
	
	ifail = AOM_UIF_ask_value(rev_tag,"t5_ColourInd",&prtColInd);fflush(stdout);
	
	printf("\n Part[%s],Rev[%s] ConInd[%s]",PrtNum,PrtNumRevSeq,prtColInd);fflush(stdout);
	
	// if ((tc_strcmp(prtColInd,"C")==0))
	// {
		
		// int FlagNONCoPrtDRStatus1=0;
		
		// printf("\n Callin tm_CheckDRPreRevAvalabilityCol  (CreateRelFun)  \n");fflush(stdout);
		// FlagNONCoPrtDRStatus1 = tm_CheckDRPreRevAvalabilityCol(rev_tag,Toplnt);
		// printf("\n call end tm_CheckDRPreRevAvalabilityCol  (CreateRelFun)  \n");fflush(stdout);
		// printf(" Flag return from FlagNONCoPrtDRStatus1 [%d]\n",FlagNONCoPrtDRStatus1);fflush(stdout);
		// if (FlagNONCoPrtDRStatus1 >0)
			// {
				// printf("\n call normal this function");fflush(stdout);
			// }
			// else
			// {
				// printf("\n Not add in folder (CreateRelFun)  \n");fflush(stdout);
				// return 0;
			// }
	// }

	tc_strcpy(UserAccess,"");
	tc_strcat(UserAccess,DsgGrp);
	tc_strcat(UserAccess,"_Designers/");

	tc_strcpy(UserAccess2,"");
	tc_strcat(UserAccess2,DsgGrp);
	tc_strcat(UserAccess2,"_Managers/");
	
	printf("\n USerAccess1 %s...\n",UserAccess);fflush(stdout);
	printf("\n USerAccess2 %s...\n",UserAccess2);fflush(stdout);

	ifail =PROJ_find(projectCode,&projTag);
	if(projTag !=NULLTAG)
	{
		Gmcnt1=0;
		Gmcnt2=0;
		Gmcnt3=0;
		GmFound1 =NULLTAG;
		GmFound2 =NULLTAG;
		GmFound3 =NULLTAG;
		//printf("\n DML:Getting Project Team...\n");fflush(stdout);
		if (PROJ_ask_team(projTag,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();
		printf("\n DML:Gmcnt1 %d \n",Gmcnt1);fflush(stdout);
		for(jkl=0;jkl<Gmcnt1;jkl++)
		{
			AccesFound=0;
			GrpMembName=NULL;
			GrpTag = GmFound1[jkl];
			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
			//printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
			if(GrpMembName)
			{
				if((tc_strstr(GrpMembName,"ERC_Designers_Group")!=NULL)&&(tc_strstr(GrpMembName,TaskAnlyst)!=NULL) &&(tc_strstr(GrpMembName,UserAccess2)!=NULL || tc_strstr(GrpMembName,UserAccess)!=NULL))
				{
					printf("\n Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
					printf("\n DML:BIW_COC_Reviewer access avail...\n");fflush(stdout);
					AccesFound=1;
					break;
				}
				else
				{
					int DsgGrpInt = atoi(DsgGrp);
					
					if(DsgGrpInt>=60)
					{
						//if((tc_strstr(GrpMembName,"CAB_Designer")))
						if((tc_strstr(GrpMembName,"CAB_Designers")!=NULL)&&(tc_strstr(GrpMembName,TaskAnlyst)!=NULL))
				
						{
							printf("\n CreateRelFun --Actual Group Member in else :[%s]\n", GrpMembName);fflush(stdout);
							AccesFound=1;
							break;
						}
					}
				}
				//else
				//{
					//printf("\n NoMatch :[%s]\n", GrpMembName);fflush(stdout);
				//}
			}
			else
			{
				printf("\n access not foundActual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
			}
		}
		printf("\n Finally access[%d] task analyst %s, Design Group %s, ProjectCode is %s",AccesFound,TaskAnlyst,DsgGrp,projectCode);fflush(stdout);
	}
	printf("\n RelFun: Toplnt:[%s] PrtDRst:[%s]", Toplnt,PrtDRst);fflush(stdout);
	if((tc_strcmp(PrtDRst,"")==0) || (tc_strcmp(PrtDRst,"NA")==0))
	{
		CreatAllow=2;
		printf("\n NAcase:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Parts For Gate Maturation
	else if(((tc_strcmp(Toplnt,"DR5")==0)|| (tc_strcmp(Toplnt,"AR5")==0)) && ((tc_strcmp(PrtDRst,"DR4")==0)|| (tc_strcmp(PrtDRst,"AR4")==0)))
	{
		CreatAllow=1;
		printf("\n R5:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Immaturated DR Status Parts
	else if(((tc_strcmp(Toplnt,"DR5")==0)|| (tc_strcmp(Toplnt,"AR5")==0)) && ((tc_strcmp(PrtDRst,"DR3")==0)|| (tc_strcmp(PrtDRst,"AR3")==0)|| (tc_strcmp(PrtDRst,"DR2")==0)|| (tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)|| (tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)|| (tc_strcmp(PrtDRst,"AR0")==0)|| (tc_strcmp(PrtDRst,"DR3P")==0)|| (tc_strcmp(PrtDRst,"AR3P")==0)))
	{
		CreatAllow=2;
		printf("\n R5:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Parts For Gate Maturation
	else if(((tc_strcmp(Toplnt,"DR4")==0)|| (tc_strcmp(Toplnt,"AR4")==0)) && ((tc_strcmp(PrtDRst,"DR3P")==0)|| (tc_strcmp(PrtDRst,"AR3P")==0)|| (tc_strcmp(PrtDRst,"DR3")==0)|| (tc_strcmp(PrtDRst,"AR3")==0)))
	{
		CreatAllow=1;
		printf("\n R4:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Immaturated DR Status Parts
	else if(((tc_strcmp(Toplnt,"DR4")==0)|| (tc_strcmp(Toplnt,"AR4")==0)) && ((tc_strcmp(PrtDRst,"DR2")==0)|| (tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)|| (tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)|| (tc_strcmp(PrtDRst,"AR0")==0)))
	{
		CreatAllow=2;
		printf("\n R4P:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Parts For Gate Maturation
	else if(((tc_strcmp(Toplnt,"DR3P")==0)|| (tc_strcmp(Toplnt,"AR3P")==0)) && ((tc_strcmp(PrtDRst,"DR3")==0)|| (tc_strcmp(PrtDRst,"AR3")==0)))
	{
		CreatAllow=1;
		printf("\n R3P:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Immaturated DR Status Parts
	else if(((tc_strcmp(Toplnt,"DR3P")==0)|| (tc_strcmp(Toplnt,"AR3P")==0)) && ((tc_strcmp(PrtDRst,"DR2")==0)|| (tc_strcmp(PrtDRst,"AR2")==0)|| (tc_strcmp(PrtDRst,"DR1")==0)|| (tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)|| (tc_strcmp(PrtDRst,"AR0")==0)))
	{
		CreatAllow=2;
		printf("\n R3P:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Parts For Gate Maturation
	else if(((tc_strcmp(Toplnt,"DR3")==0)|| (tc_strcmp(Toplnt,"AR3")==0)) && ((tc_strcmp(PrtDRst,"DR2")==0)|| (tc_strcmp(PrtDRst,"AR2")==0)))
	{
		CreatAllow=1;
		printf("\n R3:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Immaturated DR Status Parts
	else if(((tc_strcmp(Toplnt,"DR3")==0)|| (tc_strcmp(Toplnt,"AR3")==0)) && ((tc_strcmp(PrtDRst,"DR1")==0)|| (tc_strcmp(PrtDRst,"AR1")==0)|| (tc_strcmp(PrtDRst,"DR0")==0)|| (tc_strcmp(PrtDRst,"AR0")==0)))
	{
		CreatAllow=2;
		printf("\n R3:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Parts For Gate Maturation
	else if(((tc_strcmp(Toplnt,"DR2")==0)|| (tc_strcmp(Toplnt,"AR2")==0)) && ((tc_strcmp(PrtDRst,"DR1")==0)|| (tc_strcmp(PrtDRst,"AR1")==0)))
	{
		CreatAllow=1;
		printf("\n R2:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Immaturated DR Status Parts
	else if(((tc_strcmp(Toplnt,"DR2")==0)|| (tc_strcmp(Toplnt,"AR2")==0)) && ((tc_strcmp(PrtDRst,"DR0")==0)|| (tc_strcmp(PrtDRst,"AR0")==0)))
	{
		CreatAllow=2;
		printf("\n R2:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	//Parts For Gate Maturation
	else if(((tc_strcmp(Toplnt,"DR1")==0)|| (tc_strcmp(Toplnt,"AR1")==0)) && ((tc_strcmp(PrtDRst,"DR0")==0)|| (tc_strcmp(PrtDRst,"AR0")==0)))
	{
		CreatAllow=1;
		printf("\n R1:Flag is [%d]\n",CreatAllow);fflush(stdout);
	}
	else
	{
		printf("\n TO Plant Value[%s]Part DR Status[%s],\n",Toplnt,PrtDRst);fflush(stdout);
	}
	
	printf("\n Final CreatAllow [%d] ",CreatAllow);fflush(stdout);
	
	int PartMSStatusFlag=0;
	//if (CreatAllow ==1)
	if((tc_strcmp(Toplnt,"DR1")==0) || (tc_strcmp(Toplnt,"DR2")==0)|| (tc_strcmp(Toplnt,"DR3")==0))
	{
		printf("\n calling function CreateRelFunMLStatus");fflush(stdout);
		printf("\n calling function CreateRelFunMLStatus for To Plant[%s]",Toplnt);fflush(stdout);
		PartMSStatusFlag =  CreateRelFunMLStatus(objTag, Toplnt,PrtDRst,PrtMLst,rev_tag,ProjInfo);
		printf("\n  function CreateRelFunMLStatus called");fflush(stdout);
		printf("\n  value of PartMSStatusFlag[%d]",PartMSStatusFlag);fflush(stdout);
		printf("\n after CreateRelFunMLStatus Part Number [%s][%s]",PrtNum,PrtNumRevSeq);fflush(stdout);
	}
	if (PartMSStatusFlag ==0)
	{
	if (CreatAllow ==1)
	{
		printf("\n after CreateRelFunMLStatus function call PartMSStatusFlag [%d] Part Number [%s][%s]",PartMSStatusFlag,PrtNum,PrtNumRevSeq);fflush(stdout);
		printf("\n DR Folder -Parts For Gate Maturation as CreatAllow[%d] ",CreatAllow);fflush(stdout);
		//create relation with task.
		//check for Access
		//if access available, then create relation
		//if part eligible but no access then create relation with CO task.
		ifail = GRM_find_relation_type("CMReferences", &tsk_CMRef_type);
		if (tsk_CMRef_type!=NULLTAG)
		{
			printf("\n relation CMReferences1");fflush(stdout);
			
			if ((rev_tag!=NULLTAG) || (objTag!=NULLTAG) )
			{
					//folder description
					ifail =GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);fflush(stdout);
					
					if (tsk_dml_rel_type!=NULLTAG)
					{
						
						ifail = GRM_list_primary_objects_only(objTag,tsk_dml_rel_type,&count,&DMLRevision);
						ifail = AOM_UIF_ask_value(DMLRevision[0],"item_id",&dmlNo);fflush(stdout);
						ifail = AOM_UIF_ask_value(rev_tag,"item_id",&dNo);fflush(stdout);
						printf("\n DML number1 %s Part Number1%s",dmlNo,dNo);fflush(stdout);
					}
					else
					{
						printf("relation is not found for task and dml1");fflush(stdout);
					}
					char *Fld_Des=NULL;
					Fld_Des=(char *) MEM_alloc(50);
					
					char *Fld_Des_tsk=NULL;
					Fld_Des_tsk=(char *) MEM_alloc(50);
					
					ifail = AOM_UIF_ask_value(objTag,"item_id",&TaskNo);fflush(stdout);
					tc_strcpy(Fld_Des_tsk,"");
					tc_strcat(Fld_Des_tsk,"Task-");
					tc_strcat(Fld_Des_tsk,TaskNo);
					printf("\n folderTASK description1 %s",Fld_Des_tsk);fflush(stdout);

					
					tc_strcpy(Fld_Des,"");
					tc_strcat(Fld_Des,"DML-");
					tc_strcat(Fld_Des,dmlNo);

					printf("\n folder description1 %s",Fld_Des);fflush(stdout);
					//folder description

					//if((tc_strstr(ProjInfo,projectCode) != NULL) && (AccesFound==1))
					if(AccesFound==1)
					{ 
						printf("DR Folder -Parts For Gate Maturation for access project ");fflush(stdout);
						//adding parts in 'Parts For Gate Maturation' folder
						//printf("\n ERROR: NOT LIVE.\n"); fflush(stdout);
						WSOM_clear_search_criteria(&criteria);
						strcpy(criteria.name,"Parts For Gate Maturation");
						strcpy(criteria.desc,Fld_Des_tsk);
						ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);
						printf("\nNumber of Parts For Gate Maturation folders found are %d\n",number_found);fflush(stdout);

						if (number_found>0)
						{
							i=i++;
							ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
							printf("\n folder insert33 %s",PartN);fflush(stdout);
							ifail = AOM_lock(list_of_WSO_tags[0]);
							ifail = FL_insert(list_of_WSO_tags[0],rev_tag,i);
							ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
							ifail = AOM_unlock(list_of_WSO_tags[0]);
							ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
						}
						else
						{
							printf("\n folder description is1 %s",Fld_Des_tsk);fflush(stdout);

							//ifail = FL_create("Parts For Gate Maturation",Fld_Des_tsk,&pfolder_tag);

							if(TCTYPE_find_type("Folder", "", &item_type_tag)!=ITK_ok)PrintErrorStack();
							if(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag)!=ITK_ok)PrintErrorStack();
							if(AOM_set_value_string(FL_create_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
							if(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des_tsk)!=ITK_ok)PrintErrorStack();
							if(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();

							if (pfolder_tag!=NULLTAG)
							{
								printf("\n inside folder Parts For Gate Maturation save");fflush(stdout);
								ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
								ifail = AOM_save_with_extensions(pfolder_tag);
								ifail =AOM_refresh(pfolder_tag,TRUE);
								ifail = AOM_lock(objTag);
								if (Ref_Rel!=NULLTAG)
								{
									ifail = GRM_create_relation(objTag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
									printf("\n folder save1");fflush(stdout);
									if (relation1!=NULLTAG)
									{
										printf("\n save1");fflush(stdout);
										ifail =AOM_refresh(relation1,TRUE);
										ifail = GRM_save_relation(relation1);
										ifail = AOM_unlock(objTag);
										printf("\n relation Parts For Gate Maturation  unlock");fflush(stdout);
										printf("\n folder Parts For Gate Maturation unlock");fflush(stdout);
									}
								}
							}
							
								//printf("\n folder tag not found");
								i=i++;
								printf("\n folder Parts For Gate Maturation insert");fflush(stdout);
								ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);fflush(stdout);
								printf("\n folder PFG1  %s",PartN);fflush(stdout);
								ifail = AOM_lock(pfolder_tag);
								ifail = FL_insert(pfolder_tag,rev_tag,i);
								ifail = AOM_save_with_extensions(pfolder_tag);
								ifail = AOM_unlock(pfolder_tag);
								ifail =AOM_refresh(pfolder_tag,TRUE);
						}
					
					}
					else
					{
						printf("DR Folder - CarryOver Parts NONaccess project ");fflush(stdout);
					 
						ifail = AOM_ask_value_string(rev_tag,"item_id",&Ipart);fflush(stdout);
						
						ifail =ITEM_find_item (Ipart,&item_tag1);fflush(stdout);
						ifail =ITEM_list_all_revs(item_tag1, &count1, &itemRev_tag1);fflush(stdout);
						

						jk=0;
						addToCarryOver=0;
						if (addToCarryOver==0)
						{
							//check previous revision for higher gate
							if(AOM_ask_value_tags(rev_tag,"items_tag",&Itm_found,&Itm_tagS)!=ITK_ok)PrintErrorStack();
							part_tg= Itm_tagS[0];
							char			* prtColInd						= NULL;
							ifail = AOM_UIF_ask_value(rev_tag,"t5_ColourInd",&prtColInd);fflush(stdout);
	
							//printf("\n Part[%s],Rev[%s] ConInd[%s]",PrtNum,PrtNumRevSeq,prtColInd);fflush(stdout);
							printf("\n ConInd[%s]",prtColInd);fflush(stdout);
							
							if ((tc_strcmp(prtColInd,"C")==0))
								{
									
									int FlagNONCoPrtDRStatus1=0;
									
									printf("\n Callin tm_CheckDRPreRevAvalabilityCol  (CreateRelFun)  \n");fflush(stdout);
									FlagNONCoPrtDRStatus1 = tm_CheckDRPreRevAvalabilityCol(rev_tag,Toplnt);
									printf("\n call end tm_CheckDRPreRevAvalabilityCol  (CreateRelFun)  \n");fflush(stdout);
									printf(" Flag return from FlagNONCoPrtDRStatus1 [%d]\n",FlagNONCoPrtDRStatus1);fflush(stdout);
									if (FlagNONCoPrtDRStatus1 >0)
										{
											printf("\n call normal this function");fflush(stdout);
																		
								//adding parts in carry over folder
								WSOM_clear_search_criteria(&criteria);
								//strcpy(criteria.name,"CarryOver Parts");
								strcpy(criteria.name,"Parts For Gate Maturation");
								strcpy(criteria.desc,Fld_Des);
								ifail = WSOM_search(criteria, &number_found1, &list_of_WSO_tags);
								printf("\nNumber of CarryOver Parts folders found are %d\n",number_found1);fflush(stdout);
								
								if (number_found1>0)
								{
									
									/*if (fldEmpty==0)
									{	check=0;
										check=FolderEmpty(list_of_WSO_tags[0])
										if (check>0)
										{
											printf("\n folder references are removed.");
											fldEmpty=1;
										}
									}*/

									i=i++;
									printf("\n folder insert2");fflush(stdout);
									ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
									printf("\n folder CarryOver Parts insert %s",PartN);fflush(stdout);
									ifail = AOM_lock(list_of_WSO_tags[0]);
									ifail = FL_insert(list_of_WSO_tags[0],rev_tag,i);
									ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
									ifail = AOM_unlock(list_of_WSO_tags[0]);
									ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
								}
								else
								{
									printf("\n folder description is 2 %s",Fld_Des);fflush(stdout);

									//ifail = FL_create("CarryOver Parts",Fld_Des,&pfolder_tag);

									if(TCTYPE_find_type("Folder", "", &item_type_tag1)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_construct_create_input(item_type_tag1, &FL_co_input_tag)!=ITK_ok)PrintErrorStack();
									//if(AOM_set_value_string(FL_co_input_tag, "object_name", "CarryOver Parts")!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_co_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_co_input_tag, "object_desc", Fld_Des)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_create_object (FL_co_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();
									if (pfolder_tag!=NULLTAG)
									{
										int COTaskFind=0;
										char *CoTask=NULL;
										CoTask=(char *) MEM_alloc(50);
										tag_t			CoTask_tag 					= NULLTAG;
										tag_t	CoTasktag			=  NULLTAG;
										
										tc_strcpy(CoTask,"");
										tc_strcat(CoTask,dmlNo);
										tc_strcat(CoTask,"_CO");
										
										ifail = ITEM_find_item (CoTask, &CoTask_tag);
										if(CoTask_tag==NULLTAG)
											{
												printf("\n CO Task Not Found...!!\n");fflush(stdout);
											}
											else
											{
												printf("\n CO Task Found...!!\n");fflush(stdout);
												COTaskFind=1;
												ifail = ITEM_ask_latest_rev (CoTask_tag, &CoTasktag);
												if (CoTasktag==NULLTAG)
												{
													COTaskFind=0;
													printf("\n P5aaaaaaaaaaaaaaaaaaater...!!\n");fflush(stdout);
												}
												else
												{
													COTaskFind=1;
												}
											}
										if(COTaskFind==0)
										{
											printf("\n indoiedsfolder save CarryOver Parts");fflush(stdout);
											ifail = GRM_find_relation_type("T5_CmHasNOPoDetails", &Ref_Rel);
											ifail = AOM_save_with_extensions(pfolder_tag);
											ifail =AOM_refresh(pfolder_tag,TRUE);
											ifail = AOM_lock(DMLRevision[0]);
											if (Ref_Rel!=NULLTAG)
											{
												ifail = GRM_create_relation(DMLRevision[0],pfolder_tag,Ref_Rel,NULLTAG,&relation1);
												printf("\n folder save CarryOver Parts");fflush(stdout);
												if (relation1!=NULLTAG)
												{
													ifail =AOM_refresh(relation1,TRUE);
													ifail = GRM_save_relation(relation1);
													ifail = AOM_unlock(DMLRevision[0]);
													printf("\n relation unlock2");fflush(stdout);
													printf("\n folder unlock2");fflush(stdout);
												}
												else
												{
													printf("relation111 is not found for task and dml2");fflush(stdout);
												}
											}
											else
											{
												printf("fRef_Rel not present created2");fflush(stdout);
											}
										}
										else
											{
												
												printf("\n inside folder Immaturated DR Status Parts save");fflush(stdout);
												ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
												ifail = AOM_save_with_extensions(pfolder_tag);
												ifail =AOM_refresh(pfolder_tag,TRUE);
												ifail = AOM_lock(CoTasktag);
												if (Ref_Rel!=NULLTAG)
												{
													ifail = GRM_create_relation(CoTasktag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
													printf("\n folder save1");fflush(stdout);
													if (relation1!=NULLTAG)
													{
														printf("\n save1");fflush(stdout);
														ifail =AOM_refresh(relation1,TRUE);
														ifail = GRM_save_relation(relation1);
														ifail = AOM_unlock(CoTasktag);
														printf("\n relation Parts For Gate Maturation  unlock");fflush(stdout);
														printf("\n folder Parts For Gate Maturation unlock");fflush(stdout);
													}
												}
											}
										
									}
									else
									{
										printf("folder nmot created2");fflush(stdout);
									}
									i=i++;
									printf("\n folder insert2");fflush(stdout);
									ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
									printf("\n folderddddd 2 %s",PartN);fflush(stdout);
									ifail = AOM_lock(pfolder_tag);
									ifail = FL_insert(pfolder_tag,rev_tag,i);
									ifail = AOM_save_with_extensions(pfolder_tag);
									ifail = AOM_unlock(pfolder_tag);
									ifail =AOM_refresh(pfolder_tag,TRUE);
								}
										}
										else
										{
											printf("\n Not add in folder (CreateRelFun)  \n");fflush(stdout);
										}
								}
								
							else
							{
	
							if (tm_CheckDRPreRevAvalability(part_tg,Toplnt))
							{
								printf("\n folder Parts For Gate Maturation insert1");fflush(stdout);
								printf("DR Folder - CarryOver Parts NONaccess project--folder ");fflush(stdout);
							}
							else 
							{
								//adding parts in carry over folder
								WSOM_clear_search_criteria(&criteria);
								//strcpy(criteria.name,"CarryOver Parts");
								strcpy(criteria.name,"Parts For Gate Maturation");
								strcpy(criteria.desc,Fld_Des);
								ifail = WSOM_search(criteria, &number_found1, &list_of_WSO_tags);
								printf("\nNumber of CarryOver Parts folders found are %d\n",number_found1);fflush(stdout);
								
								if (number_found1>0)
								{
									
									/*if (fldEmpty==0)
									{	check=0;
										check=FolderEmpty(list_of_WSO_tags[0])
										if (check>0)
										{
											printf("\n folder references are removed.");
											fldEmpty=1;
										}
									}*/

									i=i++;
									printf("\n folder insert2");fflush(stdout);
									ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
									printf("\n folder CarryOver Parts insert %s",PartN);fflush(stdout);
									ifail = AOM_lock(list_of_WSO_tags[0]);
									ifail = FL_insert(list_of_WSO_tags[0],rev_tag,i);
									ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
									ifail = AOM_unlock(list_of_WSO_tags[0]);
									ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
								}
								else
								{
									printf("\n folder description is 2 %s",Fld_Des);fflush(stdout);

									//ifail = FL_create("CarryOver Parts",Fld_Des,&pfolder_tag);

									if(TCTYPE_find_type("Folder", "", &item_type_tag1)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_construct_create_input(item_type_tag1, &FL_co_input_tag)!=ITK_ok)PrintErrorStack();
									//if(AOM_set_value_string(FL_co_input_tag, "object_name", "CarryOver Parts")!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_co_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_co_input_tag, "object_desc", Fld_Des)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_create_object (FL_co_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();
									if (pfolder_tag!=NULLTAG)
									{
										
										int COTaskFind=0;
										char *CoTask=NULL;
										CoTask=(char *) MEM_alloc(50);
										tag_t			CoTask_tag 					= NULLTAG;
										tag_t	CoTasktag			=  NULLTAG;
										
										tc_strcpy(CoTask,"");
										tc_strcat(CoTask,dmlNo);
										tc_strcat(CoTask,"_CO");
										
										printf("\n CO Task[%s]...",CoTask);fflush(stdout);
										
										ifail = ITEM_find_item (CoTask, &CoTask_tag);
										if(CoTask_tag==NULLTAG)
											{
												printf("\n CO Task Not Found...!!\n");fflush(stdout);
											}
											else
											{
												printf("\n CO Task Found...!!\n");fflush(stdout);
												COTaskFind=1;
												ifail = ITEM_ask_latest_rev (CoTask_tag, &CoTasktag);
												if (CoTasktag==NULLTAG)
												{
													COTaskFind=0;
													printf("\n CO Task revision Not Found!!\n");fflush(stdout);
												}
												else
												{
													COTaskFind=1;
												}
											}
										if(COTaskFind==0)
										{
											printf("\n indoiedsfolder save CarryOver Parts");fflush(stdout);
											ifail = GRM_find_relation_type("T5_CmHasNOPoDetails", &Ref_Rel);
											ifail = AOM_save_with_extensions(pfolder_tag);
											ifail =AOM_refresh(pfolder_tag,TRUE);
											ifail = AOM_lock(DMLRevision[0]);
											if (Ref_Rel!=NULLTAG)
											{
												ifail = GRM_create_relation(DMLRevision[0],pfolder_tag,Ref_Rel,NULLTAG,&relation1);
												printf("\n folder save CarryOver Parts");fflush(stdout);
												if (relation1!=NULLTAG)
												{
													ifail =AOM_refresh(relation1,TRUE);
													ifail = GRM_save_relation(relation1);
													ifail = AOM_unlock(DMLRevision[0]);
													printf("\n relation unlock2");fflush(stdout);
													printf("\n folder unlock2");fflush(stdout);
												}
												else
												{
													printf("relation111 is not found for task and dml2");fflush(stdout);
												}
											}
											else
											{
												printf("fRef_Rel not present created2");fflush(stdout);
											}
										}
										else
										{
											printf("\n inside folder Immaturated DR Status Parts save");fflush(stdout);
											ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
											ifail = AOM_save_with_extensions(pfolder_tag);
											ifail =AOM_refresh(pfolder_tag,TRUE);
											ifail = AOM_lock(CoTasktag);
											if (Ref_Rel!=NULLTAG)
											{
												ifail = GRM_create_relation(CoTasktag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
												printf("\n folder save1");fflush(stdout);
												if (relation1!=NULLTAG)
												{
													printf("\n save1");fflush(stdout);
													ifail =AOM_refresh(relation1,TRUE);
													ifail = GRM_save_relation(relation1);
													ifail = AOM_unlock(CoTasktag);
													printf("\n 2relation unlock2");fflush(stdout);
													printf("\n 2folder unlock2");fflush(stdout);
												}
											}
										}
										
									}
									else
									{
										printf("folder nmot created2");fflush(stdout);
									}
									i=i++;
									printf("\n folder insert2");fflush(stdout);
									ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
									printf("\n folderddddd 2 %s",PartN);fflush(stdout);
									ifail = AOM_lock(pfolder_tag);
									ifail = FL_insert(pfolder_tag,rev_tag,i);
									ifail = AOM_save_with_extensions(pfolder_tag);
									ifail = AOM_unlock(pfolder_tag);
									ifail =AOM_refresh(pfolder_tag,TRUE);
								}
							}
						}
							

						}
						
					}

			}
			else
			{
				printf("\n tag not found2");fflush(stdout);

			}
			
		}
	}
	else if (CreatAllow ==2)
	{
		printf("DR Folder-Immaturated DR Status Parts asCreatAllow[%d] ",CreatAllow);fflush(stdout);
		//create relation with task.
		//check for Access
		//if access available, then create relation
		//if part eligible but no access then create relation with CO task.
		ifail = GRM_find_relation_type("CMReferences", &tsk_CMRef_type);
		if (tsk_CMRef_type!=NULLTAG)
		{
			printf("\n relation CMReferences Immaturated DR Status Parts");fflush(stdout);
			
			if ((rev_tag!=NULLTAG) || (objTag!=NULLTAG) )
			{
					//folder description
					ifail =GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);
					
					if (tsk_dml_rel_type!=NULLTAG)
					{
						
						ifail = GRM_list_primary_objects_only(objTag,tsk_dml_rel_type,&count,&DMLRevision);
						ifail = AOM_UIF_ask_value(DMLRevision[0],"item_id",&dmlNo);fflush(stdout);
						ifail = AOM_UIF_ask_value(rev_tag,"item_id",&dNo);fflush(stdout);
						printf("\n DML number3 %s Part Number3 %s",dmlNo,dNo);fflush(stdout);
					}
					else
					{
						printf("relation is not found for task and dml3");fflush(stdout);
					}
					char *Fld_Des=NULL;
					Fld_Des=(char *) MEM_alloc(50);
					
					char *Fld_Des_tsk=NULL;
					Fld_Des_tsk=(char *) MEM_alloc(50);
					
					ifail = AOM_UIF_ask_value(objTag,"item_id",&TaskNo);fflush(stdout);
					tc_strcpy(Fld_Des_tsk,"");
					tc_strcat(Fld_Des_tsk,"Task-");
					tc_strcat(Fld_Des_tsk,TaskNo);
					printf("\n folderTASK description3 %s",Fld_Des_tsk);fflush(stdout);

					
					tc_strcpy(Fld_Des,"");
					tc_strcat(Fld_Des,"DML-");
					tc_strcat(Fld_Des,dmlNo);

					printf("\n folder description3 %s",Fld_Des);fflush(stdout);
					//folder description

					//if((tc_strstr(ProjInfo,projectCode) != NULL) && (AccesFound==1))
					if(AccesFound==1)
					{
						//adding parts in 'Immaturated DR Status Parts' folder for acess project
						//printf("\n ERROR: NOT LIVE.\n"); fflush(stdout);
						WSOM_clear_search_criteria(&criteria);
						strcpy(criteria.name,"Immaturated DR Status Parts");
						strcpy(criteria.desc,Fld_Des);
						ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);fflush(stdout);
						printf("\nNumber of Parts For Immaturated DR Status Parts found are %d\n",number_found);fflush(stdout);

						if (number_found>0)
						{
							i=i++;
							ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
							printf("\n folder insert3 %s",PartN);fflush(stdout);
							ifail = AOM_lock(list_of_WSO_tags[0]);
							ifail = FL_insert(list_of_WSO_tags[0],rev_tag,i);
							ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
							ifail = AOM_unlock(list_of_WSO_tags[0]);
							ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
						}
						else
						{
							printf("\n folder descriptionis 3 %s",Fld_Des);fflush(stdout);

							//ifail = FL_create("Parts For Gate Maturation",Fld_Des,&pfolder_tag);

							if(TCTYPE_find_type("Folder", "", &item_type_tag)!=ITK_ok)PrintErrorStack();
							if(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag)!=ITK_ok)PrintErrorStack();
							if(AOM_set_value_string(FL_create_input_tag, "object_name", "Immaturated DR Status Parts")!=ITK_ok)PrintErrorStack();
							if(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des)!=ITK_ok)PrintErrorStack();
							if(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();
							relation1= NULLTAG;
							if (pfolder_tag!=NULLTAG)
							{
								printf("\n inside folder Immaturated DR Status Parts save");fflush(stdout);
								ifail = GRM_find_relation_type("T5_CmHasNOPoDetails", &Ref_Rel);
								ifail = AOM_save_with_extensions(pfolder_tag);
								ifail =AOM_refresh(pfolder_tag,TRUE);
								ifail = AOM_lock(DMLRevision[0]);
								if (Ref_Rel!=NULLTAG)
								{
									ifail = GRM_create_relation(DMLRevision[0],pfolder_tag,Ref_Rel,NULLTAG,&relation1);
									printf("\n folder save3");fflush(stdout);
									if (relation1!=NULLTAG)
									{
										printf("\n save3");fflush(stdout);
										ifail =AOM_refresh(relation1,TRUE);
										ifail = GRM_save_relation(relation1);
										ifail = AOM_unlock(DMLRevision[0]);
										printf("\n relation Immaturated DR Status Parts  unlock");fflush(stdout);
										printf("\n folder Immaturated DR Status Parts unlock");fflush(stdout);
									}
								}
							}
							
								//printf("\n folder tag not found");
								i=i++;
								printf("\n folder Immaturated DR Status Parts insert");fflush(stdout);
								ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
								printf("\n folder PFG3  %s",PartN);fflush(stdout);
								ifail = AOM_lock(pfolder_tag);
								ifail = FL_insert(pfolder_tag,rev_tag,i);
								ifail = AOM_save_with_extensions(pfolder_tag);
								ifail = AOM_unlock(pfolder_tag);
								ifail =AOM_refresh(pfolder_tag,TRUE);
						}
					
					}
					else
					{
						
					 
						ifail = AOM_ask_value_string(rev_tag,"item_id",&Ipart);fflush(stdout);
						
						ifail =ITEM_find_item (Ipart,&item_tag1);fflush(stdout);
						ifail =ITEM_list_all_revs(item_tag1, &count1, &itemRev_tag1);fflush(stdout);
						

						jk=0;
						addToCarryOver=0;
						if (addToCarryOver==0)
						{
							//check previous revision for higher gate
							if(AOM_ask_value_tags(rev_tag,"items_tag",&Itm_found,&Itm_tagS)!=ITK_ok)PrintErrorStack();
							part_tg= Itm_tagS[0];
							if (tm_CheckDRPreRevAvalability(part_tg,Toplnt))
							{
								printf("\n folder Immaturated DR Status Parts insert");fflush(stdout);
							}
							else 
							{
								//adding parts in carry over folder
								printf("DR Folder-Immaturated CarryOver Parts asCreatAllow[%d] ",CreatAllow);fflush(stdout);
								WSOM_clear_search_criteria(&criteria);
								strcpy(criteria.name,"Immaturated CarryOver Parts");
								strcpy(criteria.desc,Fld_Des);
								ifail = WSOM_search(criteria, &number_found1, &list_of_WSO_tags);
								printf("\nNumber of Immaturated CarryOver Parts found are %d\n",number_found1);fflush(stdout);
								
								if (number_found1>0)
								{
									
									/*if (fldEmpty==0)
									{	check=0;
										check=FolderEmpty(list_of_WSO_tags[0])
										if (check>0)
										{
											printf("\n folder references are removed.");
											fldEmpty=1;
										}
									}*/

									i=i++;
									printf("\n folder insert4");fflush(stdout);
									ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
									printf("\n folder Immaturated CarryOver Parts insert %s",PartN);fflush(stdout);
									ifail = AOM_lock(list_of_WSO_tags[0]);
									ifail = FL_insert(list_of_WSO_tags[0],rev_tag,i);
									ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
									ifail = AOM_unlock(list_of_WSO_tags[0]);
									ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
								}
								else
								{
									printf("\n folder description4 %s",Fld_Des);fflush(stdout);

									//ifail = FL_create("CarryOver Parts",Fld_Des,&pfolder_tag);

									if(TCTYPE_find_type("Folder", "", &item_type_tag1)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_construct_create_input(item_type_tag1, &FL_co_input_tag)!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_co_input_tag, "object_name", "Immaturated CarryOver Parts")!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_co_input_tag, "object_desc", Fld_Des)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_create_object (FL_co_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();
									if (pfolder_tag!=NULLTAG)
									{
										printf("\n indoiedsfolder save Immaturated CarryOver Parts");fflush(stdout);
										ifail = GRM_find_relation_type("T5_CmHasNOPoDetails", &Ref_Rel);
										ifail = AOM_save_with_extensions(pfolder_tag);
										ifail =AOM_refresh(pfolder_tag,TRUE);
										ifail = AOM_lock(DMLRevision[0]);
										if (Ref_Rel!=NULLTAG)
										{
											ifail = GRM_create_relation(DMLRevision[0],pfolder_tag,Ref_Rel,NULLTAG,&relation1);
											printf("\n folder save Immaturated CarryOver Parts");fflush(stdout);
											if (relation1!=NULLTAG)
											{
												ifail =AOM_refresh(relation1,TRUE);
												ifail = GRM_save_relation(relation1);
												ifail = AOM_unlock(DMLRevision[0]);
												printf("\n Immaturated CarryOver Parts unlock4");fflush(stdout);
												printf("\n Immaturated CarryOver Parts unlock4");fflush(stdout);
											}
											else
											{
												printf("relation111 is not found for task and dml4");fflush(stdout);
											}
										}
										else
										{
											printf("fRef_Rel not present created4");fflush(stdout);
										}
									}
									else
									{
										printf("folder nmot created4");fflush(stdout);
									}
									i=i++;
									printf("\n folder insert4");fflush(stdout);
									ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
									printf("\n folderddddd 4 %s",PartN);fflush(stdout);
									ifail = AOM_lock(pfolder_tag);
									ifail = FL_insert(pfolder_tag,rev_tag,i);
									ifail = AOM_save_with_extensions(pfolder_tag);
									ifail = AOM_unlock(pfolder_tag);
									ifail =AOM_refresh(pfolder_tag,TRUE);
								}
							}
							

						}
						
					}

			}
			else
			{
				printf("\n tag not found4");fflush(stdout);

			}
			
		}
	}

else
{
	
	printf("\n create allow %d",CreatAllow);fflush(stdout);
}
}
	
	else
	{
		printf("\n In function CreateRelFunMLStatusPart Number [%s][%s]",PrtNum,PrtNumRevSeq);fflush(stdout);
		printf("\n Part added in Ms Folder %d",CreatAllow);fflush(stdout);
	}

	return 0;
}

//int CreateRelFunMLStatus(tag_t objTag, char* Toplnt, char*  PrtDRst, char*  PrtMSst,tag_t rev_tag, char * ProjInfo,int PartMSStatusFlagDup)
int CreateRelFunMLStatus(tag_t objTag, char* Toplnt, char*  PrtDRst, char*  PrtMSst,tag_t rev_tag, char * ProjInfo)
{
	int		ifail 		= ITK_ok;
	int		CreatAllowML = 0;
	tag_t	tsk_CMRef_type	= NULLTAG;
	tag_t	tsk_dml_rel_type	= NULLTAG;
	tag_t	*DMLRevision = NULLTAG;
	tag_t	Ref_Rel	= NULLTAG;
	tag_t relation= NULLTAG;
	tag_t relation1= NULLTAG;
	tag_t pfolder_tag= NULLTAG;
	tag_t item_type_tag	= NULLTAG;
	tag_t item_type_tag1 = NULLTAG;
	tag_t FL_create_input_tag= NULLTAG;
	tag_t FL_co_input_tag= NULLTAG;
	tag_t projTag= NULLTAG;
	tag_t GrpTag= NULLTAG;
	tag_t item_tag1	= NULLTAG;
	tag_t *itemRev_tag1=NULLTAG;

	char			* PrtDRStatus						= NULL;
	char			* DsgGrp						= NULL;
	char			* TaskAnlyst						= NULL;
	char			* projectCode						= NULL;
	char			* GrpMembName						= NULL;
	char			* DRnewRev						= NULL;
	char			* DRnew						= NULL;
	char			* clrell_status						= NULL;
	char			* dmlNo						= NULL;
	char			* dNo						= NULL;
	char			* TaskNo						= NULL;
	char			* PartN						= NULL;
	char			* Ipart						= NULL;
	char			* Fld_Des						= NULL;
	int i,number_found,number_found1,fldEmpty=0,check=0;
	int	AccesFound=0,FlCreated=0,count,count1;
	WSO_search_criteria_t  	criteria;
	tag_t *list_of_WSO_tags=NULLTAG;

	int	jkl=0;
	int	addToCarryOver=0;
	int	jk=0;
	int	Itm_found=0;
	int	Gmcnt1=0;
	int	Gmcnt2=0;
	int	Gmcnt3=0;
	tag_t	*GmFound1 = NULLTAG;
	tag_t	*GmFound2 = NULLTAG;
	tag_t	*GmFound3 = NULLTAG;
	tag_t	*Itm_tagS = NULLTAG;
	tag_t	part_tg		= NULLTAG;
	char   UserAccess[1000];
	char   UserAccess2[1000];

	//if (objTag==NULLTAG || tc_strcmp(Toplnt,"")==0 ||tc_strlen(Toplnt)==0|| Toplnt==NULL || tc_strcmp(PrtDRst,"")==0 || PrtDRst==NULL || tc_strlen(PrtDRst)==0 || rev_tag==NULLTAG || tc_strcmp(ProjInfo,"")==0 || ProjInfo==NULL || tc_strlen(ProjInfo)==0)
	if (objTag==NULLTAG || tc_strcmp(Toplnt,"")==0 ||tc_strlen(Toplnt)==0|| Toplnt==NULL || rev_tag==NULLTAG)
	{
		printf("\n Input arguments are NULL or Blank for CreateRelFunMLStatus");fflush(stdout);
		return 0;
	}

	printf("\n Inside CreateRelFunMLStatus: Toplnt:%s PrtDRst:%s PrtMSst:%s", Toplnt,PrtDRst,PrtMSst);fflush(stdout);

	ifail = AOM_UIF_ask_value(objTag,"analyst_user_id",&TaskAnlyst);fflush(stdout);
	ifail = AOM_UIF_ask_value(rev_tag,"t5_DesignGrp",&DsgGrp);fflush(stdout);
	ifail = AOM_UIF_ask_value(rev_tag,"t5_ProjectCode",&projectCode);fflush(stdout);
	ifail = AOM_UIF_ask_value(rev_tag,"t5_PartStatus",&PrtDRStatus);fflush(stdout);
	printf("\n task analyst %s, Design Group %s, ProjectCode is %s",TaskAnlyst,DsgGrp,projectCode);fflush(stdout);
	
	char			* PrtNum						= NULL;
	char			* PrtNumRevSeq						= NULL;
	ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PrtNum);fflush(stdout);
	ifail = AOM_UIF_ask_value(rev_tag,"item_revision_id",&PrtNumRevSeq);fflush(stdout);
	printf("\n In function CreateRelFunMLStatusPart Number [%s][%s]",PrtNum,PrtNumRevSeq);fflush(stdout);


	tc_strcpy(UserAccess,"");
	tc_strcat(UserAccess,DsgGrp);
	tc_strcat(UserAccess,"_Designers/");

	tc_strcpy(UserAccess2,"");
	tc_strcat(UserAccess2,DsgGrp);
	tc_strcat(UserAccess2,"_Managers/");
	
	printf("\n USerAccess1 %s...\n",UserAccess);fflush(stdout);
	printf("\n USerAccess2 %s...\n",UserAccess2);fflush(stdout);

	ifail =PROJ_find(projectCode,&projTag);
	if(projTag !=NULLTAG)
	{
		Gmcnt1=0;
		Gmcnt2=0;
		Gmcnt3=0;
		GmFound1 =NULLTAG;
		GmFound2 =NULLTAG;
		GmFound3 =NULLTAG;
		//printf("\n DML:Getting Project Team...\n");fflush(stdout);
		if (PROJ_ask_team(projTag,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();
		printf("\n DML:Gmcnt1 %d \n",Gmcnt1);fflush(stdout);
		for(jkl=0;jkl<Gmcnt1;jkl++)
		{
			AccesFound=0;
			GrpMembName=NULL;
			GrpTag = GmFound1[jkl];
			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
			//	printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
			if(GrpMembName)
			{
				if((tc_strstr(GrpMembName,"ERC_Designers_Group")!=NULL)&&(tc_strstr(GrpMembName,TaskAnlyst)!=NULL) &&(tc_strstr(GrpMembName,UserAccess2)!=NULL || tc_strstr(GrpMembName,UserAccess)!=NULL))
				{
					printf("\n Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
					printf("\n DML:BIW_COC_Reviewer access avail...\n");fflush(stdout);
					AccesFound=1;
					break;
				}
				else
				{
					int DsgGrpInt = atoi(DsgGrp);
					
					if(DsgGrpInt>=60)
					{
						//if((tc_strstr(GrpMembName,"CAB_Designer")))
						if((tc_strstr(GrpMembName,"CAB_Designers")!=NULL)&&(tc_strstr(GrpMembName,TaskAnlyst)!=NULL))
						{
						printf("\n Actual Group Member in else :[%s]\n", GrpMembName);fflush(stdout);
						AccesFound=1;
						break;
						}
					}
				}
				//else
				//{
					//printf("\n NoMatch :[%s]\n", GrpMembName);fflush(stdout);
				//}
			}
		}
	}
	printf("\n Miles Stone RelFun: Toplnt:[%s] PrtMSst:[%s]", Toplnt,PrtMSst);fflush(stdout);
	int IsMilestoneLiveFlag=0;
	IsMilestoneLiveFlag = CheckMilestoneLive(projectCode);
	if (IsMilestoneLiveFlag >0)
	{
		printf("\n Project is live for miles stone  \n");fflush(stdout);
	
	if((tc_strcmp(PrtMSst,"")==0) || (tc_strcmp(PrtMSst,"NA")==0))
	{
		CreatAllowML=2;
		printf(" Miles Stone1 NAcase:Flag is [%d]\n",CreatAllowML);fflush(stdout);
	}
	//Parts For Gate Maturation
	else if(((tc_strcmp(Toplnt,"DR1")==0)|| (tc_strcmp(Toplnt,"AR1")==0)) && ((tc_strcmp(PrtMSst,"Pre-UNVO")==0)|| (tc_strcmp(PrtMSst,"Pre-UNV0")==0)|| (tc_strcmp(PrtMSst,"Pre-UPVO")==0) || (tc_strcmp(PrtMSst,"Pre-UPV0")==0)))
	{
		CreatAllowML=1;
		printf("R1:Flag is [%d]\n",CreatAllowML);fflush(stdout);
	}
	//Parts For Gate Maturation
	else if(((tc_strcmp(Toplnt,"DR2")==0)|| (tc_strcmp(Toplnt,"AR2")==0)) && ((tc_strcmp(PrtMSst,"UNV3")==0)|| (tc_strcmp(PrtMSst,"UPV0")==0)))
	{
		CreatAllowML=1;
		printf("R1:Flag is [%d]\n",CreatAllowML);fflush(stdout);
	}
	//Immaturated MS Status Parts
	else if(((tc_strcmp(Toplnt,"DR2")==0)|| (tc_strcmp(Toplnt,"AR2")==0)) && ((tc_strcmp(PrtMSst,"UNV0")==0)|| (tc_strcmp(PrtMSst,"UNV1")==0)|| (tc_strcmp(PrtMSst,"UNV2")==0)))
	{
		CreatAllowML=2;
		printf("R1:Flag is [%d]\n",CreatAllowML);fflush(stdout);
	}
	//Parts For Gate Maturation
	else if(((tc_strcmp(Toplnt,"DR3")==0)|| (tc_strcmp(Toplnt,"AR3")==0)) && ((tc_strcmp(PrtMSst,"UNV3")==0)|| (tc_strcmp(PrtMSst,"UPV3")==0)))
	{
		CreatAllowML=1;
		printf("R1:Flag is [%d]\n",CreatAllowML);fflush(stdout);
	}
	//Immaturated MS Status Parts
	else if(((tc_strcmp(Toplnt,"DR3")==0)|| (tc_strcmp(Toplnt,"AR3")==0)) && ((tc_strcmp(PrtMSst,"UNV0")==0)|| (tc_strcmp(PrtMSst,"UPV1")==0)|| (tc_strcmp(PrtMSst,"UPV2")==0)))
	{
		CreatAllowML=2;
		printf("R1:Flag is [%d]\n",CreatAllowML);fflush(stdout);
	}
	//Parts For Gate Maturation
	// else if(((tc_strcmp(Toplnt,"DR3P")==0)|| (tc_strcmp(Toplnt,"AR3P")==0)) && ((tc_strcmp(PrtMSst,"UNV3")==0)|| (tc_strcmp(PrtMSst,"UPV3")==0)))
	// {
		// CreatAllowML=1;
		// printf("R1:Flag is [%d]\n",CreatAllowML);fflush(stdout);
	// }
	// //Immaturated MS Status Parts
	// else if(((tc_strcmp(Toplnt,"DR3P")==0)|| (tc_strcmp(Toplnt,"AR3P")==0)) && ((tc_strcmp(PrtMSst,"UNV0")==0)|| (tc_strcmp(PrtMSst,"UNV1")==0)|| (tc_strcmp(PrtMSst,"UNV2")==0)|| (tc_strcmp(PrtMSst,"UNV3")==0)|| (tc_strcmp(PrtMSst,"Pre-UPV0")==0)|| (tc_strcmp(PrtMSst,"UPV1")==0)|| (tc_strcmp(PrtMSst,"UPV2")==0)))
	// {
		// CreatAllowML=2;
		// printf("R1:Flag is [%d]\n",CreatAllowML);fflush(stdout);
	// }
	// //Parts For Gate Maturation
	// else if(((tc_strcmp(Toplnt,"DR4")==0)|| (tc_strcmp(Toplnt,"AR4")==0)) && ((tc_strcmp(PrtMSst,"UNV3")==0)|| (tc_strcmp(PrtMSst,"UPV3")==0)))
	// {
		// CreatAllowML=1;
		// printf("R1:Flag is [%d]\n",CreatAllowML);fflush(stdout);
	// }
	// //Immaturated MS Status Parts
	// else if(((tc_strcmp(Toplnt,"DR4")==0)|| (tc_strcmp(Toplnt,"AR4")==0)) && ((tc_strcmp(PrtMSst,"UNV0")==0)|| (tc_strcmp(PrtMSst,"UNV1")==0)|| (tc_strcmp(PrtMSst,"UNV2")==0)|| (tc_strcmp(PrtMSst,"UNV3")==0)|| (tc_strcmp(PrtMSst,"Pre-UPV0")==0)|| (tc_strcmp(PrtMSst,"UPV1")==0)|| (tc_strcmp(PrtMSst,"UPV2")==0)))
	// {
		// CreatAllowML=2;
		// printf("R1:Flag is [%d]\n",CreatAllowML);fflush(stdout);
	// }
	printf(" CreatAllowML Part Milestone-------%d",CreatAllowML);fflush(stdout);
	
	//create allow==1
	//Parts For Gate Maturation
	//carry over
	
	//create allow==0
	//imputure
	//carry over
	// if(CreatAllowML==0)
	// {
		// printf("Part Not eligible for MS Folder");fflush(stdout);
		// PartMSStatusFlagDup=0;
		// printf("Part eligible for MS Folder [%d]",PartMSStatusFlagDup);fflush(stdout);
	// }
	// else
	// {
		// printf("Part eligible for MS Folder");fflush(stdout);
		// PartMSStatusFlagDup=1;
		// printf("Part eligible for MS Folder [%d]",PartMSStatusFlagDup);fflush(stdout);
	// }
	if (CreatAllowML ==1)
	{
		printf("Mileston Function -Parts For Gate Maturation as CreatAllowML[%d] ",CreatAllowML);fflush(stdout);
		//create relation with task.
		//check for Access
		//if access available, then create relation
		//if part eligible but no access then create relation with CO task.
		ifail = GRM_find_relation_type("CMReferences", &tsk_CMRef_type);
		if (tsk_CMRef_type!=NULLTAG)
		{
			printf("\n relation lock for CreatAllowML");fflush(stdout);
			
			if ((rev_tag!=NULLTAG) || (objTag!=NULLTAG))
			{
					//folder description
					ifail =GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);
					
					if (tsk_dml_rel_type!=NULLTAG)
					{
						
						ifail = GRM_list_primary_objects_only(objTag,tsk_dml_rel_type,&count,&DMLRevision);
						ifail = AOM_UIF_ask_value(DMLRevision[0],"item_id",&dmlNo);fflush(stdout);
						ifail = AOM_UIF_ask_value(rev_tag,"item_id",&dNo);fflush(stdout);
						printf("\n ML DML number1 %s %s",dmlNo,dNo);fflush(stdout);
					}
					else
					{
						printf("ML relation is not found for task and dml1");fflush(stdout);
					}
					char *Fld_Des=NULL;
					Fld_Des=(char *) MEM_alloc(50);
					
					char *Fld_Des_tsk=NULL;
					Fld_Des_tsk=(char *) MEM_alloc(50);
					
					ifail = AOM_UIF_ask_value(objTag,"item_id",&TaskNo);fflush(stdout);
					tc_strcpy(Fld_Des_tsk,"");
					tc_strcat(Fld_Des_tsk,"Task-");
					tc_strcat(Fld_Des_tsk,TaskNo);
					printf("\n ML folderTASK description1 %s",Fld_Des_tsk);fflush(stdout);

					
					tc_strcpy(Fld_Des,"");
					tc_strcat(Fld_Des,"DML-");
					tc_strcat(Fld_Des,dmlNo);

					printf("\n ML folder description1 %s",Fld_Des);fflush(stdout);
					//folder description
					
					ifail = AOM_ask_value_string(rev_tag,"item_id",&Ipart);fflush(stdout);
						
					ifail =ITEM_find_item (Ipart,&item_tag1);fflush(stdout);
					ifail =ITEM_list_all_revs(item_tag1, &count1, &itemRev_tag1);fflush(stdout);
					
					if(AOM_ask_value_tags(rev_tag,"items_tag",&Itm_found,&Itm_tagS)!=ITK_ok)PrintErrorStack();
					part_tg= Itm_tagS[0];

					//if((tc_strstr(ProjInfo,projectCode) != NULL) && (AccesFound==1))
					if(AccesFound==1)
					{
						//adding parts in 'Parts For Gate Maturation' folder
						//printf("\n ERROR: NOT LIVE.\n"); fflush(stdout);
						WSOM_clear_search_criteria(&criteria);
						strcpy(criteria.name,"Parts For Gate Maturation");
						strcpy(criteria.desc,Fld_Des_tsk);
						ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);
						printf("\n for miles stone Number of Parts For Parts For Gate Maturation are %d\n",number_found);fflush(stdout);

						if (number_found >0)
						{
							i=i++;
							ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
							printf("\n ML folder insert1 %s",PartN);fflush(stdout);
							ifail = AOM_lock(list_of_WSO_tags[0]);
							ifail = FL_insert(list_of_WSO_tags[0],rev_tag,i);
							ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
							ifail = AOM_unlock(list_of_WSO_tags[0]);
							ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
						}
						else
						{
							printf("\n ML folder description1 %s",Fld_Des_tsk);fflush(stdout);

							//ifail = FL_create("Parts For Gate Maturation",Fld_Des_tsk,&pfolder_tag);

							if(TCTYPE_find_type("Folder", "", &item_type_tag)!=ITK_ok)PrintErrorStack();
							if(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag)!=ITK_ok)PrintErrorStack();
							if(AOM_set_value_string(FL_create_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
							if(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des_tsk)!=ITK_ok)PrintErrorStack();
							if(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();
							printf("\n for miles stone folder created Parts For Gate Maturation");fflush(stdout);
							if (pfolder_tag!=NULLTAG)
							{
								printf("\n for miles stone inside folder maturated MS Status Parts save");fflush(stdout);
								ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
								ifail = AOM_save_with_extensions(pfolder_tag);
								ifail =AOM_refresh(pfolder_tag,TRUE);
								ifail = AOM_lock(objTag);
								if (Ref_Rel!=NULLTAG)
								{
									ifail = GRM_create_relation(objTag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
									printf("\n ML for miles stone folder save1");fflush(stdout);
									if (relation1!=NULLTAG)
									{
										printf("\n 41 save");fflush(stdout);
										ifail =AOM_refresh(relation1,TRUE);
										ifail = GRM_save_relation(relation1);
										ifail = AOM_unlock(objTag);
										printf("\n for miles stone relation Parts For maturated MS Status Parts  unlock");fflush(stdout);
										printf("\n for miles stone folder Parts For maturated MS Status Parts unlock");fflush(stdout);
									}
								}
							}
							
							printf("\n for miles stone folder created Parts For maturated MS Status Parts1");fflush(stdout);
							
								//printf("\n folder tag not found");
								i=i++;
								printf("\n for miles stone folder Parts For maturated MS Status Parts insert");fflush(stdout);
								ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
								printf("\n for miles stone folder PFG1  %s",PartN);fflush(stdout);
								ifail = AOM_lock(pfolder_tag);
								ifail = FL_insert(pfolder_tag,rev_tag,i);
								ifail = AOM_save_with_extensions(pfolder_tag);
								ifail = AOM_unlock(pfolder_tag);
								ifail =AOM_refresh(pfolder_tag,TRUE);
						}
					
					}
					else
					{
						jk=0;
						addToCarryOver=0;
						if (addToCarryOver==0)
						{
							if (tm_CheckDRPreRevAvalability(part_tg,Toplnt))
							{
								printf("\n for miles stonefolder Parts For Immaturated MS Status Parts insert2");fflush(stdout);
							}
							else 
							{
								//adding parts in carry over folder
								WSOM_clear_search_criteria(&criteria);
								//strcpy(criteria.name,"CarryOver Parts");
								strcpy(criteria.name,"Parts For Gate Maturation");
								strcpy(criteria.desc,Fld_Des);
								ifail = WSOM_search(criteria, &number_found1, &list_of_WSO_tags);
								printf("\nfor miles stoneNumber of CarryOver Parts folders found are1 %d\n",number_found1);fflush(stdout);
								
								if (number_found1>0)
								{
									
									/*if (fldEmpty==0)
									{	check=0;
										check=FolderEmpty(list_of_WSO_tags[0])
										if (check>0)
										{
											printf("\n folder references are removed.");
											fldEmpty=1;
										}
									}*/

									i=i++;
									printf("\n for miles stonefolder insert22");fflush(stdout);
									ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
									printf("\n folder CarryOver Parts insert %s",PartN);fflush(stdout);
									ifail = AOM_lock(list_of_WSO_tags[0]);
									ifail = FL_insert(list_of_WSO_tags[0],rev_tag,i);
									ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
									ifail = AOM_unlock(list_of_WSO_tags[0]);
									ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
								}
								else
								{
									printf("\n for miles stone folder description222 %s",Fld_Des);fflush(stdout);

									//ifail = FL_create("CarryOver Parts",Fld_Des,&pfolder_tag);

									if(TCTYPE_find_type("Folder", "", &item_type_tag1)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_construct_create_input(item_type_tag1, &FL_co_input_tag)!=ITK_ok)PrintErrorStack();
									//if(AOM_set_value_string(FL_co_input_tag, "object_name", "CarryOver Parts")!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_co_input_tag, "object_name", "Parts For Gate Maturation")!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_co_input_tag, "object_desc", Fld_Des)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_create_object (FL_co_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();
									if (pfolder_tag!=NULLTAG)
									{
										int COTaskFind=0;
										char *CoTask=NULL;
										CoTask=(char *) MEM_alloc(50);
										tag_t			CoTask_tag 					= NULLTAG;
										tag_t	CoTasktag			=  NULLTAG;
										
										tc_strcpy(CoTask,"");
										tc_strcat(CoTask,dmlNo);
										tc_strcat(CoTask,"_CO");
										
										printf("\n CO Task[%s]...",CoTask);fflush(stdout);
										
										ifail = ITEM_find_item (CoTask, &CoTask_tag);
										if(CoTask_tag==NULLTAG)
											{
												printf("\n CO Task Not Found...!!\n");fflush(stdout);
											}
											else
											{
												printf("\n CO Task Found...!!\n");fflush(stdout);
												COTaskFind=1;
												ifail = ITEM_ask_latest_rev (CoTask_tag, &CoTasktag);
												if (CoTasktag==NULLTAG)
												{
													COTaskFind=0;
													printf("\n CO Task revision Not Found!!\n");fflush(stdout);
												}
												else
												{
													COTaskFind=1;
												}
											}
										if(COTaskFind==0)
										{
											printf("\n for miles stone inside sfolder save CarryOver Parts222");fflush(stdout);
											ifail = GRM_find_relation_type("T5_CmHasNOPoDetails", &Ref_Rel);
											ifail = AOM_save_with_extensions(pfolder_tag);
											ifail =AOM_refresh(pfolder_tag,TRUE);
											ifail = AOM_lock(DMLRevision[0]);
											if (Ref_Rel!=NULLTAG)
											{
												ifail = GRM_create_relation(DMLRevision[0],pfolder_tag,Ref_Rel,NULLTAG,&relation1);
												printf("\n for miles stone folder save CarryOver Parts22");fflush(stdout);
												if (relation1!=NULLTAG)
												{
													ifail =AOM_refresh(relation1,TRUE);
													ifail = GRM_save_relation(relation1);
													ifail = AOM_unlock(DMLRevision[0]);
													printf("\n for miles stone relation unlock22");fflush(stdout);
													printf("\n for miles stone folder unlock22");fflush(stdout);
												}
												else
												{
													printf("for miles stone relation22 is not found for task and dml");
												}
											}
											else
											{
												printf("for miles stone fRef_Rel not present created22");fflush(stdout);
											}
										}
										else
										{
											
											printf("\n inside folder Immaturated DR Status Parts save");fflush(stdout);
											ifail = GRM_find_relation_type("CMReferences", &Ref_Rel);
											ifail = AOM_save_with_extensions(pfolder_tag);
											ifail =AOM_refresh(pfolder_tag,TRUE);
											ifail = AOM_lock(CoTasktag);
											if (Ref_Rel!=NULLTAG)
											{
												ifail = GRM_create_relation(CoTasktag,pfolder_tag,Ref_Rel,NULLTAG,&relation1);
												printf("\n folder save1");fflush(stdout);
												if (relation1!=NULLTAG)
												{
													printf("\n save1");fflush(stdout);
													ifail =AOM_refresh(relation1,TRUE);
													ifail = GRM_save_relation(relation1);
													ifail = AOM_unlock(CoTasktag);
													printf("\n relation Parts For Gate Maturation  unlock");fflush(stdout);
													printf("\n folder Parts For Gate Maturation unlock");fflush(stdout);
												}
											}
										}
										
									}
									else
									{
										printf(" for miles stonefolder nmot created22");fflush(stdout);
									}
									i=i++;
									printf("\n for miles stonefolder insert22");fflush(stdout);
									ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
									printf("\n folderddddd 22 %s",PartN);fflush(stdout);
									ifail = AOM_lock(pfolder_tag);
									ifail = FL_insert(pfolder_tag,rev_tag,i);
									ifail = AOM_save_with_extensions(pfolder_tag);
									ifail = AOM_unlock(pfolder_tag);
									ifail =AOM_refresh(pfolder_tag,TRUE);
								}
							}
							

						}
						
					}

			}
			else
			{
				printf("\n for miles stone tag not found1");fflush(stdout);

			}
			
		}
	}
	else if (CreatAllowML ==2)
	{
		printf("Mileston Function -Immaturated MS Status Parts folder CreatAllowML[%d] ",CreatAllowML);fflush(stdout);
		//create relation with task.
		//check for Access
		//if access available, then create relation
		//if part eligible but no access then create relation with CO task.
		ifail = GRM_find_relation_type("CMReferences", &tsk_CMRef_type);
		if (tsk_CMRef_type!=NULLTAG)
		{
			printf("\n relation lock for miles stone CreatAllowML");fflush(stdout);
			
			if ((rev_tag!=NULLTAG) || (objTag!=NULLTAG) )
			{
					//folder description
					ifail =GRM_find_relation_type("T5_DMLTaskRelation", &tsk_dml_rel_type);
					
					if (tsk_dml_rel_type!=NULLTAG)
					{
						
						ifail = GRM_list_primary_objects_only(objTag,tsk_dml_rel_type,&count,&DMLRevision);
						ifail = AOM_UIF_ask_value(DMLRevision[0],"item_id",&dmlNo);fflush(stdout);
						ifail = AOM_UIF_ask_value(rev_tag,"item_id",&dNo);fflush(stdout);
						printf("\n DML number2 %s %s",dmlNo,dNo);fflush(stdout);
					}
					else
					{
						printf("relation is not found for task and dml2");fflush(stdout);
					}
					char *Fld_Des=NULL;
					Fld_Des=(char *) MEM_alloc(50);
					
					char *Fld_Des_tsk=NULL;
					Fld_Des_tsk=(char *) MEM_alloc(50);
					
					ifail = AOM_UIF_ask_value(objTag,"item_id",&TaskNo);fflush(stdout);
					tc_strcpy(Fld_Des_tsk,"");
					tc_strcat(Fld_Des_tsk,"Task-");
					tc_strcat(Fld_Des_tsk,TaskNo);
					printf("\n folderTASK description2 %s",Fld_Des_tsk);fflush(stdout);

					
					tc_strcpy(Fld_Des,"");
					tc_strcat(Fld_Des,"DML-");
					tc_strcat(Fld_Des,dmlNo);

					printf("\n folder descriptionImmature Milestone Parts2 %s",Fld_Des);fflush(stdout);
					//folder description
					
					ifail = AOM_ask_value_string(rev_tag,"item_id",&Ipart);fflush(stdout);
						
					ifail =ITEM_find_item (Ipart,&item_tag1);fflush(stdout);
					ifail =ITEM_list_all_revs(item_tag1, &count1, &itemRev_tag1);fflush(stdout);
					
					if(AOM_ask_value_tags(rev_tag,"items_tag",&Itm_found,&Itm_tagS)!=ITK_ok)PrintErrorStack();
					part_tg= Itm_tagS[0];

					//if((tc_strstr(ProjInfo,projectCode) != NULL) && (AccesFound==1))
					if(AccesFound==1)
					{
						//adding parts in 'Parts For Gate Maturation' folder
						//printf("\n ERROR: NOT LIVE.\n"); fflush(stdout);
						WSOM_clear_search_criteria(&criteria);
						strcpy(criteria.name,"Immaturated MS Status Parts");
						strcpy(criteria.desc,Fld_Des);
						ifail = WSOM_search(criteria, &number_found, &list_of_WSO_tags);
						printf("\n for miles stone Number of Parts For Immaturated MS Status Parts found are %d\n",number_found);fflush(stdout);

						if (number_found >0)
						{
							i=i++;
							ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
							printf("\n ML folder insert1 %s",PartN);fflush(stdout);
							ifail = AOM_lock(list_of_WSO_tags[0]);
							ifail = FL_insert(list_of_WSO_tags[0],rev_tag,i);
							ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
							ifail = AOM_unlock(list_of_WSO_tags[0]);
							ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
						}
						else
						{
							printf("\n ML folder description1 %s",Fld_Des);fflush(stdout);

							//ifail = FL_create("Parts For Gate Maturation",Fld_Des,&pfolder_tag);

							if(TCTYPE_find_type("Folder", "", &item_type_tag)!=ITK_ok)PrintErrorStack();
							if(TCTYPE_construct_create_input(item_type_tag, &FL_create_input_tag)!=ITK_ok)PrintErrorStack();
							if(AOM_set_value_string(FL_create_input_tag, "object_name", "Immaturated MS Status Parts")!=ITK_ok)PrintErrorStack();
							if(AOM_set_value_string(FL_create_input_tag, "object_desc", Fld_Des)!=ITK_ok)PrintErrorStack();
							if(TCTYPE_create_object (FL_create_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();
							printf("\n for miles stone folder created Immaturated MS Status Parts");fflush(stdout);
							if (pfolder_tag!=NULLTAG)
							{
								printf("\n for miles stone inside folder Immaturated MS Status Parts save");fflush(stdout);
								ifail = GRM_find_relation_type("T5_CmHasNOPoDetails", &Ref_Rel);
								ifail = AOM_save_with_extensions(pfolder_tag);
								ifail =AOM_refresh(pfolder_tag,TRUE);
								ifail = AOM_lock(DMLRevision[0]);
								if (Ref_Rel!=NULLTAG)
								{
									ifail = GRM_create_relation(DMLRevision[0],pfolder_tag,Ref_Rel,NULLTAG,&relation1);
									printf("\n ML for miles stone folder save1");fflush(stdout);
									if (relation1!=NULLTAG)
									{
										printf("\n 41 save");fflush(stdout);
										ifail =AOM_refresh(relation1,TRUE);
										ifail = GRM_save_relation(relation1);
										ifail = AOM_unlock(DMLRevision[0]);
										printf("\n for miles stone relation Parts For Immaturated MS Status Parts  unlock");fflush(stdout);
										printf("\n for miles stone folder Parts For Immaturated MS Status Parts unlock");fflush(stdout);
									}
								}
							}
							
							printf("\n for miles stone folder created Parts For Immaturated MS Status Parts1");fflush(stdout);
							
								//printf("\n folder tag not found");
								i=i++;
								printf("\n for miles stone folder Parts For Immaturated MS Status Parts insert");fflush(stdout);
								ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
								printf("\n for miles stone folder PFG1  %s",PartN);fflush(stdout);
								ifail = AOM_lock(pfolder_tag);
								ifail = FL_insert(pfolder_tag,rev_tag,i);
								ifail = AOM_save_with_extensions(pfolder_tag);
								ifail = AOM_unlock(pfolder_tag);
								ifail =AOM_refresh(pfolder_tag,TRUE);
						}
					
					}
					else
					{
						jk=0;
						addToCarryOver=0;
						if (addToCarryOver==0)
						{
							if (tm_CheckDRPreRevAvalability(part_tg,Toplnt))
							{
								printf("\n for miles stonefolder Parts For Immaturated MS Status Parts insert2");fflush(stdout);
							}
							else 
							{
								printf("Mileston Function -Immaturated CarryOver Parts folder for not access project CreatAllowML[%d] ",CreatAllowML);fflush(stdout);
								//adding parts in carry over folder
								WSOM_clear_search_criteria(&criteria);
								strcpy(criteria.name,"Immaturated CarryOver Parts");
								strcpy(criteria.desc,Fld_Des);
								ifail = WSOM_search(criteria, &number_found1, &list_of_WSO_tags);
								printf("\nfor miles stoneNumber of CarryOver Parts folders found are1 %d\n",number_found1);fflush(stdout);
								
								if (number_found1>0)
								{
									
									/*if (fldEmpty==0)
									{	check=0;
										check=FolderEmpty(list_of_WSO_tags[0])
										if (check>0)
										{
											printf("\n folder references are removed.");
											fldEmpty=1;
										}
									}*/

									i=i++;
									printf("\n for miles stonefolder insert22");fflush(stdout);
									ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
									printf("\n folder Immaturated MS Status Parts insert %s",PartN);fflush(stdout);
									ifail = AOM_lock(list_of_WSO_tags[0]);
									ifail = FL_insert(list_of_WSO_tags[0],rev_tag,i);
									ifail = AOM_save_with_extensions(list_of_WSO_tags[0]);
									ifail = AOM_unlock(list_of_WSO_tags[0]);
									ifail =AOM_refresh(list_of_WSO_tags[0],TRUE);
								}
								else
								{
									printf("\n for miles stone folder description222 %s",Fld_Des);fflush(stdout);

									//ifail = FL_create("CarryOver Parts",Fld_Des,&pfolder_tag);

									if(TCTYPE_find_type("Folder", "", &item_type_tag1)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_construct_create_input(item_type_tag1, &FL_co_input_tag)!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_co_input_tag, "object_name", "Immaturated CarryOver Parts")!=ITK_ok)PrintErrorStack();
									if(AOM_set_value_string(FL_co_input_tag, "object_desc", Fld_Des)!=ITK_ok)PrintErrorStack();
									if(TCTYPE_create_object (FL_co_input_tag, &pfolder_tag)!=ITK_ok)PrintErrorStack();
									if (pfolder_tag!=NULLTAG)
									{
										printf("\n for miles stone inside sfolder save CarryOver Parts222");fflush(stdout);
										ifail = GRM_find_relation_type("T5_CmHasNOPoDetails", &Ref_Rel);
										ifail = AOM_save_with_extensions(pfolder_tag);
										ifail =AOM_refresh(pfolder_tag,TRUE);
										ifail = AOM_lock(DMLRevision[0]);
										if (Ref_Rel!=NULLTAG)
										{
											ifail = GRM_create_relation(DMLRevision[0],pfolder_tag,Ref_Rel,NULLTAG,&relation1);
											printf("\n for miles stone folder save CarryOver Parts22");fflush(stdout);
											if (relation1!=NULLTAG)
											{
												ifail =AOM_refresh(relation1,TRUE);
												ifail = GRM_save_relation(relation1);
												ifail = AOM_unlock(DMLRevision[0]);
												printf("\n for miles stone relation unlock22");fflush(stdout);
												printf("\n for miles stone folder unlock22");fflush(stdout);
											}
											else
											{
												printf("for miles stone relation22 is not found for task and dml");
											}
										}
										else
										{
											printf("for miles stone fRef_Rel not present created22");fflush(stdout);
										}
									}
									else
									{
										printf(" for miles stonefolder nmot created22");fflush(stdout);
									}
									i=i++;
									printf("\n for miles stonefolder insert22");fflush(stdout);
									ifail = AOM_UIF_ask_value(rev_tag,"item_id",&PartN);
									printf("\n folderddddd 22 %s",PartN);fflush(stdout);
									ifail = AOM_lock(pfolder_tag);
									ifail = FL_insert(pfolder_tag,rev_tag,i);
									ifail = AOM_save_with_extensions(pfolder_tag);
									ifail = AOM_unlock(pfolder_tag);
									ifail =AOM_refresh(pfolder_tag,TRUE);
								}
							}
							

						}
						
					}

			}
			else
			{
				printf("\n for miles stone tag not found22");fflush(stdout);

			}
			
		}
	}
	else
	{
		printf("\n for miles stone To plant: %s, Part MilesStone Status: %s\n",Toplnt,PrtMSst);fflush(stdout);
		printf("\n for miles stone CreatAllowML Part Milestone-------%d",CreatAllowML);fflush(stdout);
		printf("\n Part Number [%s][%s]",PrtNum,PrtNumRevSeq);
		printf("\n NOT elgible for MS folder CreatAllowML-------[%d]",CreatAllowML);fflush(stdout);
		//return 1;
	}
}
else
{
	//PartMSStatusFlagDup=0;
	printf("\n project not live for miles stone22");fflush(stdout);
	printf("\n CreatAllowML[%d]",CreatAllowML);fflush(stdout);
	//return 1;
}

	if (CreatAllowML >0)
	{
		printf("\n PreRev:DR check PASSED for part.  \n");fflush(stdout);
		return 1;
	}
	else
	{
		printf("\n PreRev:DR check FAILED for part.  \n");fflush(stdout);
		return 0;
	}
	

return 0;

}