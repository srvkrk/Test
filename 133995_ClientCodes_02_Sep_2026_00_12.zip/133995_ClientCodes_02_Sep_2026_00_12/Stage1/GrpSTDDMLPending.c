/***************************************************************************************************
* 
* Copyright (c) 2018 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File			  :	  GrpSTDDMLPending.c
* Created By      :   Manoj Kumar
* Created On      :   18/07/2018
* Project         :   TATA MOTORS.
* Description     :   This client code is generic, used for finding all the Apl dml's pending with
                      Planner and reviewer according to their group in STDS1.
Report Format is Like:

											   GROUP WISE STD DML PENDING REPORT                                                                                                                                                                                                          
                                            Report Date :  Fri_Sep__9_08_45_30_2018                                                                                                                                            
						                --------------------------------------------------                                                                                                                                                                                  
                                                                                                                                                                                                             
														Summary(Plannerwise)                                                                                                                                                                                                                      
						           -----------------------------------------------------------------                                                                                                                                                                        
                                                                                                                                                                                                                                 
														Summary(Reviewerwise)                                                                                                                                                                                                                     
						           -----------------------------------------------------------------                                                                                                                                                                        
                                                                                                                                                                                                                                               
														Consolidated Summary                                                                                                                                                                                                                      
						           -----------------------------------------------------------------                                                                                                                                                                        
												Total number of pending DMLS      :                                                                                                                                      
												DML Pending with Planner          :                                                                                                                                        
												DML pending with Reviewer         :                                                                                                                                        
						           ----------------------------------------------------------------- 

PlannerId:			PLANNER NAME:				PLANNER Group:	
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
SR No		TASK				PROJECT		ERC Date(dd/mm/yy)	Status			DMLDescription
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


ReviewerId:			REVIEWER NAME:				REVIEWER Group:	
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
SR No		TASK				PROJECT		ERC Date(dd/mm/yy)	Status			DMLDescription
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Check-in With SCO No. #314
**************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>

#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

static void initialize( void );

static void initialize(void)
{
    int  ifail;
	printf("\n I am in initialize");fflush(stdout);   
    ifail = ITK_auto_login ();	
	printf("\n I am in initialize %d",ifail);fflush(stdout);
}
void dousage()
{
printf("\n USAGE: template -u=user -p=password -g=\"\" \n");
return;
}

void setFindStr(char **view_list,int count,char *str,int *found)
{
	printf("\n **setFindStr");fflush(stdout);
	int k=0;
	*found=0;
		for(k=0;k<count;k++)
		{

		printf("\n[%d]tc_strcmp(%s,%s)",k,view_list[k],str);fflush(stdout);
			if(tc_strcmp(view_list[k],str)==0)
			{


			*found=1;
			break;

			}

		}
	printf("\n **setFindStr found= %d",*found);fflush(stdout);
}



void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	printf("\n setAddStr1 %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	//printf("\n Added in Set ===%s",(*strset)[*count-1]);fflush(stdout);
}
	
	
int ITK_user_main(int argc, char* argv[])
{
	int status;
	int				ifail 						= ITK_ok;
	printf("\n I am in main program");fflush(stdout);
	
	char			*Plant 					= NULL;
	char			*uname 					= NULL;
	char			*passwd					= NULL;
	uname = ITK_ask_cli_argument("-u=");
	
	if(tc_strlen(stripBlanks(uname)) == 0)
	{
		printf("\n Please enter login user Name in argument 1 -u=");fflush(stdout);
		return -1;
	}
	
	passwd = ITK_ask_cli_argument("-p=");
	
	if(tc_strlen(stripBlanks(passwd)) == 0)
	{
		printf("\n Please enter login user password in argument 2 -p=");fflush(stdout);
		return -1;
	}
	
	Plant = ITK_ask_cli_argument("-d=");
	
	if(tc_strlen(stripBlanks(Plant)) == 0)
	{
		printf("\n Please enter plant in argument 3 -d= e.g. -p=APLJ");fflush(stdout);
		return -1;
	}
	
	
	/* Login Start*/
	char* usr={uname};
	char* upw={passwd};
	char* ugp={"dba"};
	char *s;
	status = ITK_init_module( usr,upw,ugp);
	if ( status != ITK_ok)
	{
	EMH_ask_error_text( status, &s);
	printf("Error with ITK_init_module: %s \n",s);fflush(stdout);
	MEM_free(s);
	return status;
	}
	else printf("Logon to succesful as %s.\n", usr);fflush(stdout);	
	printf("\n Logged in to main program");fflush(stdout);
	/* Login End*/
		
	/* Program Logic Starts*/
	char*			PLT_CodeS			= NULL;
	char*			PLT_STDPF			= NULL;
	char*			STD_Ana_Grp			= NULL;
	char*			UsrDetails			= NULL;
	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;
	logical			flgRoleFnd			= false;
	int				num_of_roles,i		= 0;
	int				num_of_members,j,k	= 0;
	char			rolename[SA_name_size_c+1];
	char			userid[SA_user_size_c+1];
	char			username[SA_user_size_c+1];
	char 			**AnaUserSet		= NULL;
	char 			**RevUserSet		= NULL;
	int  			AnaUserSet_cnt		= 0;
	int  			RevUserSet_cnt		= 0;
	int  			TotPendingDMLs		= 0;
	int  			TotPendingwdPlnr	= 0;
	int  			TotPendingwdRev		= 0;
	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	PLT_STDPF=(char *) MEM_alloc(100 * sizeof(char *));
	UsrDetails=(char *) MEM_alloc(100 * sizeof(char *));
	
	printf("\n Usernae= %s password= %s PlantDML = %s",uname,passwd,Plant);fflush(stdout);
	
	if(tc_strcmp(Plant,"APLP")==0)
    {
		tc_strcpy(PLT_CodeS,"PPUNE");
		tc_strcpy(PLT_STDPF,"STDP");
	}
	else if(tc_strcmp(Plant,"APLD")==0)
	{
		tc_strcpy(PLT_CodeS,"DWD");
		tc_strcpy(PLT_STDPF,"STDD");
	}
	else if(tc_strcmp(Plant,"APLC")==0)
	{
		tc_strcpy(PLT_CodeS,"CAR");
		tc_strcpy(PLT_STDPF,"STDC");
	}
	else if(tc_strcmp(Plant,"APLJ")==0)
	{
		tc_strcpy(PLT_CodeS,"JSR");
		tc_strcpy(PLT_STDPF,"STDJ");
	}
	else if(tc_strcmp(Plant,"APLL")==0)
	{
		tc_strcpy(PLT_CodeS,"LKO");
		tc_strcpy(PLT_STDPF,"STDL");
	}
	else if(tc_strcmp(Plant,"APLA")==0)
	{
		tc_strcpy(PLT_CodeS,"AHD");
		tc_strcpy(PLT_STDPF,"STDA");
	}
	else if(tc_strcmp(Plant,"APLU")==0)
	{
		tc_strcpy(PLT_CodeS,"UTK");
		tc_strcpy(PLT_STDPF,"STDU");
	}
	else if(tc_strcmp(Plant,"APLT")==0)
	{
		tc_strcpy(PLT_CodeS,"JDL");
		tc_strcpy(PLT_STDPF,"STDT");
	}
	else
	{
		printf("\n Plant not matched hence considering pune by default");fflush(stdout);
		tc_strcpy(PLT_CodeS,"PPUNE");
		tc_strcpy(PLT_STDPF,"STDP");
	}
	
	STD_Ana_Grp=(char *) MEM_alloc(100 * sizeof(char *));
	tc_strcpy(STD_Ana_Grp,"STD");
	tc_strcat(STD_Ana_Grp,PLT_CodeS);
	printf("\n Test 0 ..STD Analyst Group Name:[%s]\n",STD_Ana_Grp);
	
	CALLAPI(SA_find_group(STD_Ana_Grp,&group_tag));
	if (group_tag != NULLTAG)
	{
		/* Output File Creation Start*/
		FILE 	*output 			= NULL;
		char 	Data[100]			= "";
		char	OutputFile[200]		= "";
		time_t 	now;
		struct 	tm	when;
		
		time(&now);
		when = *localtime(&now);
		
		strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
		sprintf(OutputFile,"%s_GroupwiseSTDPendingList_%s.txt",Plant,Data);
		
		output = fopen(OutputFile,"a+");
		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		else
		{
			printf("File opened successfully.\n");
		}	
		/* Output File Creation End*/
		
		CALLAPI(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));
		printf("\nNo of Role found in Group are :%d\n",num_of_roles);
		flgRoleFnd=false;
		if(num_of_roles>0)
		{
			for (i=0;i<num_of_roles ;i++ )
			{
				CALLAPI(SA_ask_role_name(role_tags[i],rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);
				if(strstr(rolename,PLT_STDPF) && strstr(rolename,"_Analyst"))
				{
					printf("\n Match Found for Analyst\n");
					flgRoleFnd=true;
					if (flgRoleFnd==true)
					{
						CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
						if(num_of_members>0)
						{						
							for (j=0;j<num_of_members ;j++)
							{
								int toadd=0;
								CALLAPI(SA_ask_groupmember_user(member_tags[j],&user_tag));
								CALLAPI(SA_ask_user_identifier(user_tag,userid));
								CALLAPI(SA_ask_user_person_name(user_tag,username)); 
								printf("\n User ID ==> [%s] Name ==> [%s] Group ==>  :\n",userid,username);		
								tc_strcpy(UsrDetails,"");
								tc_strcpy(UsrDetails,userid);
								tc_strcat(UsrDetails,"#");
								tc_strcat(UsrDetails,username);	
								setFindStr(AnaUserSet,AnaUserSet_cnt,UsrDetails,&toadd);
								if(toadd==0)
								{
									setAddStr(&AnaUserSet_cnt,&AnaUserSet,UsrDetails);
								}
							}
						}
						else
						{
							printf("\n No STDS Analyst Found...\n");
							// Mail in TCE Logic
						}
					}
				}
				
				if(strstr(rolename,PLT_STDPF) && strstr(rolename,"_Reviewer"))
				{
					printf("\n Match Found for Reviewer\n");
					flgRoleFnd=true;
					if (flgRoleFnd==true)
					{
						CALLAPI(SA_find_groupmember_by_role(role_tags[i],group_tag,&num_of_members,&member_tags));
						printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_roles);
						if(num_of_members>0)
						{						
							for (k=0;k<num_of_members ;k++)
							{
								int toadd=0;
								CALLAPI(SA_ask_groupmember_user(member_tags[k],&user_tag));
								CALLAPI(SA_ask_user_identifier(user_tag,userid));				
								CALLAPI(SA_ask_user_person_name(user_tag,username)); 
								printf("\n User ID ==> [%s] Name ==> [%s] Group ==>  :\n",userid,username);		
								tc_strcpy(UsrDetails,"");
								tc_strcpy(UsrDetails,userid);
								tc_strcat(UsrDetails,"#");
								tc_strcat(UsrDetails,username);	
								setFindStr(RevUserSet,RevUserSet_cnt,UsrDetails,&toadd);
								if(toadd==0)
								{
									setAddStr(&RevUserSet_cnt,&RevUserSet,UsrDetails);
								}						
							}
						}
						else
						{
							printf("\n No STDS Reviewer Found...\n");
							// Mail in TCE Logic
						}
					}
				}
				
			}			
		}
		
		// Logic for printing in report
		fprintf(output,"\n																						 GROUP WISE STD DML PENDING REPORT												");fflush(output);
		fprintf(output,"\n																						 Report Date : %s												",Data);fflush(output);
		fprintf(output,"\n																				 --------------------------------------------------											");fflush(output);
		
		fprintf(output,"\n\n																						        Summary(Plannerwise)												");fflush(output);
		fprintf(output,"\n																				 --------------------------------------------------											");fflush(output);
		// Plnners Details Here
		char *AnaUsrSumm = NULL;
		char *AnaUsrSummDup = NULL;
		AnaUsrSumm=(char *) MEM_alloc(100 * sizeof(char *));
		int count =0;
		for (i=0;i<AnaUserSet_cnt ;i++)
		{
			char 		*UsrIdSm 				= NULL;
			char 		*UsrNamSm	 			= NULL;
			char 		*JobNameWFSm 			= NULL;
			char 		*respPartySm 			= NULL;
			char		*ArgName2[4];
			char		*ArgVal2[4];
			tag_t		qryTagAPLWFSM			= NULLTAG;
			int 		resultsQryWFActSM		= 0;
			tag_t 		*ObjsWFActSM			= NULLTAG;
			AnaUsrSummDup = AnaUserSet[i];
			tc_strcpy(AnaUsrSumm,AnaUsrSummDup);
			UsrIdSm = strtok( AnaUsrSumm, "#" );
			UsrNamSm = strtok ( NULL, "#" );
			
			JobNameWFSm=(char *) MEM_alloc(100 * sizeof(char *));
			respPartySm=(char *) MEM_alloc(100 * sizeof(char *));
			
			tc_strcpy(JobNameWFSm,"");
			tc_strcpy(JobNameWFSm,"*");
			tc_strcat(JobNameWFSm,Plant);
			tc_strcat(JobNameWFSm,"*");	
			
			tc_strcpy(respPartySm,"");
			tc_strcpy(respPartySm,"*");
			tc_strcat(respPartySm,UsrIdSm);
			tc_strcat(respPartySm,"*");
			
			if(QRY_find("EPMTask_APLTaskQry", &qryTagAPLWFSM));
			if (qryTagAPLWFSM)
			{
				printf("\n Here:Found Query EPMTask_APLTaskQry in Summary(Plannerwise)	... \n");fflush(stdout);
			}
			else
			{
				printf("\n Here:Not Found Query EPMTask_APLTaskQry in Summary(Plannerwise)	... \n");fflush(stdout);
			}
			
			ArgName2[0] = "TASK ID";
			ArgVal2[0]  = JobNameWFSm;	
			ArgName2[1] = "WFStepName";
			ArgVal2[1]  = "Create EPA";	
			ArgName2[2] = "StepStatus";
			ArgVal2[2]  = "4";		
			ArgName2[3] = "WFSignOffUser";
			ArgVal2[3]  = respPartySm;				
			
			
			if(QRY_execute(qryTagAPLWFSM, 4, ArgName2, ArgVal2, &resultsQryWFActSM, &ObjsWFActSM));
			if(resultsQryWFActSM>0)
			{
				printf("\n record found in Summary(Plannerwise)... \n");fflush(stdout);
				fprintf(output,"\n\n																				 %d		%5s      %10s      : %5d											",count+1,UsrIdSm,UsrNamSm,resultsQryWFActSM);fflush(output);			
				TotPendingwdPlnr= TotPendingwdPlnr+resultsQryWFActSM;
				count++;
			}
		}
		fprintf(output,"\n\n																						        Summary(Reviewerwise)												");fflush(output);
		fprintf(output,"\n																				 --------------------------------------------------											");fflush(output);
		// Reviewers Details Here
		count =0;
		for (i=0;i<RevUserSet_cnt ;i++)
		{
			char 		*UsrIdSm 				= NULL;
			char 		*UsrNamSm	 			= NULL;
			char 		*JobNameWFSm 			= NULL;
			char 		*respPartySm 			= NULL;
			char		*ArgName2[4];
			char		*ArgVal2[4];
			tag_t		qryTagAPLWFSM			= NULLTAG;
			int 		resultsQryWFActSM		= 0;
			tag_t 		*ObjsWFActSM			= NULLTAG;
			AnaUsrSummDup = RevUserSet[i];
			tc_strcpy(AnaUsrSumm,AnaUsrSummDup);
			UsrIdSm = strtok( AnaUsrSumm, "#" );
			UsrNamSm = strtok ( NULL, "#" );
			
			JobNameWFSm=(char *) MEM_alloc(100 * sizeof(char *));
			respPartySm=(char *) MEM_alloc(100 * sizeof(char *));
			
			tc_strcpy(JobNameWFSm,"");
			tc_strcpy(JobNameWFSm,"*");
			tc_strcat(JobNameWFSm,Plant);
			tc_strcat(JobNameWFSm,"*");	
			
			tc_strcpy(respPartySm,"");
			tc_strcpy(respPartySm,"*");
			tc_strcat(respPartySm,UsrIdSm);
			tc_strcat(respPartySm,"*");
			
			if(QRY_find("EPMTask_APLTaskQry", &qryTagAPLWFSM));
			if (qryTagAPLWFSM)
			{
				printf("\n Here:Found Query EPMTask_APLTaskQry Summary(reviewerwise)	... \n");fflush(stdout);
			}
			else
			{
				printf("\n Here:Not Found EPMTask_APLTaskQry Summary(reviewerwise)... \n");fflush(stdout);
			}
			
			ArgName2[0] = "TASK ID";
			ArgVal2[0]  = JobNameWFSm;	
			ArgName2[1] = "WFStepName";
			ArgVal2[1]  = "Review the Changes";	
			ArgName2[2] = "StepStatus";
			ArgVal2[2]  = "4";		
			ArgName2[3] = "WFSignOffUser";
			ArgVal2[3]  = respPartySm;		
			
			if(QRY_execute(qryTagAPLWFSM, 4, ArgName2, ArgVal2, &resultsQryWFActSM, &ObjsWFActSM));
			if(resultsQryWFActSM>0)
			{
				printf("\n record found in Summary(reviewer)... \n");fflush(stdout);
				fprintf(output,"\n\n																				 %d		%5s      %10s      : %5d											",count+1,UsrIdSm,UsrNamSm,resultsQryWFActSM);fflush(output);			
				TotPendingwdRev=TotPendingwdRev+resultsQryWFActSM;
				count++;
			}
		}
		TotPendingDMLs	= TotPendingwdPlnr+TotPendingwdRev;
		fprintf(output,"\n\n																						        Consolidated Summary												");fflush(output);
		fprintf(output,"\n\n																				 --------------------------------------------------											");fflush(output);
		fprintf(output,"\n\n																				   Total number of pending DMLS      :  		%d						",TotPendingDMLs);fflush(output);
		fprintf(output,"\n\n																				   DML Pending with Planner          :  		%d						",TotPendingwdPlnr);fflush(output);
		fprintf(output,"\n\n																				   DML pending with Reviewer         :  		%d						",TotPendingwdRev);fflush(output);
		// Consolidated Summary Here
		
		fprintf(output,"\n\n\n=============================================================   DML PENDING WITH PLANNER    =====================================================================================================================  ");fflush(output);
		char *AnaUsr = NULL;
		int	 taskFoundAna = 0;
		int	 taskFoundRev = 0;
		AnaUsr=(char *) MEM_alloc(100 * sizeof(char *));
		for (i=0;i<AnaUserSet_cnt ;i++)
		{
			char 		*UsrId				= NULL;
			char 		*UsrNam 			= NULL;
			char 		*JobNameWF 			= NULL;
			char 		*respParty 			= NULL;
			tag_t		qryTagAPLWF			= NULLTAG;
			int 		resultsQry			= 0;
			char		*ArgName2[4];
			char		*ArgVal2[4];
			int 		resultsQryWFAct		= 0;
			tag_t 		*ObjsWFAct			= NULLTAG;
			JobNameWF=(char *) MEM_alloc(100 * sizeof(char *));
			respParty=(char *) MEM_alloc(100 * sizeof(char *));
			printf("\n AnaString (%d,%s)",i,AnaUserSet[i]);fflush(stdout);
			AnaUsr = AnaUserSet[i];
			UsrId = strtok( AnaUsr, "#" );
			UsrNam = strtok ( NULL, "#" );
			
			tc_strcpy(JobNameWF,"");
			tc_strcpy(JobNameWF,"*");
			tc_strcat(JobNameWF,Plant);
			tc_strcat(JobNameWF,"*");	
			
			tc_strcpy(respParty,"");
			tc_strcpy(respParty,"*");
			tc_strcat(respParty,UsrId);
			tc_strcat(respParty,"*");
			
			// Logic
			if(QRY_find("EPMTask_APLTaskQry", &qryTagAPLWF));
			if (qryTagAPLWF)
			{
				printf("\n Here:Found Query EPMTask_APLTaskQry detail Planner Wise... \n");fflush(stdout);
			}
			else
			{
				printf("\n Here:Not Found Query EPMTask_APLTaskQry detail Planner Wise... \n");fflush(stdout);
			}

			ArgName2[0] = "TASK ID";
			ArgVal2[0]  = JobNameWF;	
			ArgName2[1] = "WFStepName";
			ArgVal2[1]  = "Create EPA";	
			ArgName2[2] = "StepStatus";
			ArgVal2[2]  = "4";		
			ArgName2[3] = "WFSignOffUser";
			ArgVal2[3]  = respParty;				
			
			printf("\n Here:AFTER BUILDING QUERY JobNameWF %s and User %s... ",JobNameWF,respParty);fflush(stdout);
			
			if(QRY_execute(qryTagAPLWF, 4, ArgName2, ArgVal2, &resultsQryWFAct, &ObjsWFAct));

			printf(" Sig History For Work On DML count:%d \n\t",resultsQryWFAct); fflush(stdout);
			if(resultsQryWFAct>0)
			{
				printf(" Sig object found...resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
				//printf("\n Tok Id and Name (%s,%s)",UsrId,UsrNam);fflush(stdout);
				fprintf(output,"\n\nPlanner Id :     %s              Planner Name :   %s                      Planner Group :           ",UsrId,UsrNam);fflush(output);
				fprintf(output,"\n\n-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------   ",UsrId,UsrNam);fflush(output);
				fprintf(output,"\n\nSR No          TASK                    PROJECT        ERC Date     Planner Assg       Status       DML Description                    ",UsrId,UsrNam);fflush(output);
				fprintf(output,"\n                                                   (dd-mmm-yyyy)  (dd-mmm-yyyy)                                                                                                                                                                                    ",UsrId,UsrNam);fflush(output);
				fprintf(output,"\n\n-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------   ",UsrId,UsrNam);fflush(output);
						
				int j = 0;
				int	RlzWithIn15Days	= 0;
				int	PendingWithIn15Days	= 0;
				int	PendingAfter15Days	= 0;
				int	RlzAfterIn15Days	= 0;
				for (j=0;j<resultsQryWFAct;j++ )
				{
					tag_t 		Optfmly_tag 	= 	NULLTAG;
					char 		*jobName		= 	NULL;
					char 		*DMLTaksk			= 	NULL;
					char 		*DMLAPL			= 	NULL;
					char 		*timeInDup		= 	NULL;
					int			ActDuration		= 	0;
					char 		*DMLRevNum		= 	NULL;
					char 		*rlzDateDup		= 	NULL;
					char 		*FinalDMLTaksk	= 	NULL;
					tag_t		*ReleaseStat	=	NULLTAG;				
					int 		st_count		=	0;			
					Optfmly_tag = ObjsWFAct[j];					
					CALLAPI(AOM_ask_value_string(Optfmly_tag,"job_name",&jobName));
					printf("\n Job Name  :: %s\n",jobName);fflush(stdout);
					CALLAPI(AOM_UIF_ask_value(Optfmly_tag,"fnd0StartDate",&timeInDup));					
					printf("\n\t fnd0StartDate:: [%s]\n\t",timeInDup);
					strtok(timeInDup," ");
					DMLTaksk = strtok (jobName,"/");
					FinalDMLTaksk = (char *) MEM_alloc( 5000 * sizeof(char) );
					tc_strcpy(FinalDMLTaksk,DMLTaksk);
					tc_strcat(FinalDMLTaksk,"*");
					
					
					
					printf("\n APL DML %s",FinalDMLTaksk);fflush(stdout);		
					tag_t		qryAPLTag	= NULLTAG;
					char		*ArgName3[1];
					char		*ArgVal3[1];
					int			resultsQryAPL = 0;
					int			resultsQryAPLD = 0;
					tag_t		*revAPL	= NULLTAG;
					tag_t		*revAPLD	= NULLTAG;
					char* 		c_st_class_name	=	NULL;
					if(QRY_find("Item ID", &qryAPLTag));
					if (qryAPLTag)
					{
						printf("\n Here:Found Query APL DML... \n");fflush(stdout);
					}
					else
					{
						printf("\n Here:Not Found Query APL DML... \n");fflush(stdout);
					}
					
					ArgName3[0] = "Item ID";
					ArgVal3[0]  = FinalDMLTaksk;
					
					if(QRY_execute(qryAPLTag, 1, ArgName3, ArgVal3, &resultsQryAPL, &revAPL));
					
					
					printf(" resultsQry count:%d \n\t",resultsQryAPL); fflush(stdout);
					if(resultsQryAPL>0)
					{
						printf("Item Revision exists in UA....resultsQry:%d \n\t",resultsQryAPL); fflush(stdout);
						int k = 0;
						for (k=0;k<resultsQryAPL;k++ )
						{
							tag_t 		APLMstr_tag 	= 	NULLTAG;
							char 		*DMLNum			= 	NULL;
							char 		*DMLDesc		= 	NULL;
							char 		*ProjectCd		= 	NULL;
							char 		*AplDMLNum		= 	NULL;
							char 		*AplDML			= 	NULL;
							char 		*DMLProjectCode	= 	NULL;
							char 		*AplDMLDesc		= 	NULL;
							char 		*DMLNameDup		= 	NULL;
							tag_t 		revDML			=	NULLTAG;				
							tag_t 		revDMLER		=	NULLTAG;				
							APLMstr_tag = revAPL[k];
							CALLAPI(AOM_ask_value_string(APLMstr_tag,"item_id",&DMLNum));
							printf("\n APL Task Found  :: %s\n",DMLNum);fflush(stdout);	
							//CALLAPI(AOM_ask_value_string(APLMstr_tag,"t5_cprojectcode",&ProjectCd));
							//printf("\n APL Task Proj Code  :: %s\n",ProjectCd);fflush(stdout);	
							printf("\n APL Task Found  :: %s\n",DMLNum);fflush(stdout);
							
							DMLAPL = strtok (jobName,"_");
							tc_strcpy(FinalDMLTaksk,"");
							tc_strcpy(FinalDMLTaksk,DMLAPL);
							tc_strcat(FinalDMLTaksk,"_");
							tc_strcat(FinalDMLTaksk,Plant);
							//tc_strcat(FinalDMLTaksk,"*");
							
							
							//APLJ DML Query and process for release Date
							ArgName3[0] = "Item ID";
							ArgVal3[0]  = FinalDMLTaksk;				
							if(QRY_execute(qryAPLTag, 1, ArgName3, ArgVal3, &resultsQryAPLD, &revAPLD));
							tag_t 		APLDMstr_tag = 	NULLTAG;
							APLDMstr_tag = revAPLD[0];	
							ITEM_ask_latest_rev(APLDMstr_tag,&revDMLER);
							CALLAPI(AOM_ask_value_string(revDMLER,"item_id",&AplDML));
							printf("\n APL DML Found  :: %s\n",AplDML);fflush(stdout);
							CALLAPI(AOM_ask_value_string(revDMLER,"t5_cprojectcode",&DMLProjectCode));
							printf("\n APL DML DMLProjectCode  :: %s\n",DMLProjectCode);fflush(stdout);
							CALLAPI(AOM_ask_value_string(revDMLER,"object_desc",&DMLDesc));
							printf("\n APL DML DMLDesc  :: %s\n",DMLDesc);fflush(stdout);
							
							//ERC DML Query and process for release Date
							strtok (DMLAPL,"_");
							tc_strcpy(FinalDMLTaksk,"");
							tc_strcpy(FinalDMLTaksk,DMLAPL);
							
							printf("\n befor going to item id query FinalDMLTaksk :: %s\n",FinalDMLTaksk);fflush(stdout);
							
							ArgName3[0] = "Item ID";
							ArgVal3[0]  = FinalDMLTaksk;	
							char 		*ReleaseDt		= 	NULL;
							if(QRY_execute(qryAPLTag, 1, ArgName3, ArgVal3, &resultsQryAPLD, &revAPLD));
							if(resultsQryAPLD!=0)
							{
								printf("\n Zero Object found for item id:: %d %s\n",resultsQryAPLD,FinalDMLTaksk);fflush(stdout);
								APLDMstr_tag = 	NULLTAG;
								APLDMstr_tag = revAPLD[0];									
								ITEM_ask_latest_rev(APLDMstr_tag,&revDMLER);
								CALLAPI(AOM_ask_value_string(revDMLER,"item_id",&AplDMLNum));
								printf("\n ERC DML Found  :: %s\n",AplDMLNum);fflush(stdout);
								CALLAPI(AOM_UIF_ask_value(revDMLER,"date_released",&ReleaseDt));											
								printf("\n\n\t\t ERC Release Date  is :%s",ReleaseDt);	fflush(stdout);								
								strtok(ReleaseDt," ");
							}
							else
							{
								tc_strcpy(ReleaseDt," ");
							}
						
							ITEM_ask_latest_rev(APLDMstr_tag,&revDML);	
							if(revDML != NULLTAG)
							{	
								CALLAPI(AOM_ask_value_string(revDML,"item_id",&DMLRevNum));
								printf("\n ERC DML Revision Found  :: %s\n",DMLRevNum);fflush(stdout);	
								CALLAPI(WSOM_ask_release_status_list(revDML,&st_count,&ReleaseStat));
								printf("\n\n\t\t Release Status Count  is :%d",st_count);	fflush(stdout);							
								
							}							
							if(tc_strcmp(c_st_class_name,"T5_LcsStdWrkg"))
							{	
								printf("\n Lifecyclestate equal and STDS Working"); fflush(stdout);			
								fprintf(output,"\n\n%d          %s           %s       %s     %s       Claimed       %s",j+1,DMLNum,DMLProjectCode,ReleaseDt,timeInDup,DMLDesc);fflush(output);	
								taskFoundAna++;		
							}
							else
							{			
								printf("\n Lifecyclestate is not APL Working"); fflush(stdout);						
							}
						}
					}
					else
					{
						printf(" Item Revision Does not exists in UA....resultsQry:%d \n\t",resultsQry); fflush(stdout);
					}			
				}				
				fprintf(output,"\n\n=================================================================================================================================================================================================================     \n\n",UsrId,UsrNam);fflush(output);
			}
			else
			{
				printf(" Sig object Does not exists....resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
			}
		}
		if(taskFoundAna==0)
		{
			fprintf(output,"\n\nNo Working %s DML pending with any mapped planner",Plant);fflush(output);	
		}
		fprintf(output,"\n\n\n\n\n=============================================================   DML PENDING WITH REVIEWER    ====================================================================================================================  ");fflush(output);
		for (i=0;i<RevUserSet_cnt ;i++)
		{
			char 		*UsrId 				= NULL;
			char 		*UsrNam 			= NULL;
			char 		*JobNameWF 			= NULL;
			char 		*respParty 			= NULL;
			tag_t		qryTagAPLWF			= NULLTAG;
			int 		resultsQry			= 0;
			char		*ArgName2[4];
			char		*ArgVal2[4];
			int 		resultsQryWFAct		= 0;
			tag_t 		*ObjsWFAct			= NULLTAG;
			JobNameWF=(char *) MEM_alloc(100 * sizeof(char *));
			respParty=(char *) MEM_alloc(100 * sizeof(char *));
			//printf("\n AnaString (%d,%s)",i,AnaUserSet[i]);fflush(stdout);
			AnaUsr = RevUserSet[i];
			UsrId = strtok( AnaUsr, "#" );
			UsrNam = strtok ( NULL, "#" );
			
			tc_strcpy(JobNameWF,"");
			tc_strcpy(JobNameWF,"*");
			tc_strcat(JobNameWF,Plant);
			tc_strcat(JobNameWF,"*");	
			
			tc_strcpy(respParty,"");
			tc_strcpy(respParty,"*");
			tc_strcat(respParty,UsrId);
			tc_strcat(respParty,"*");
			
			// Logic
			if(QRY_find("EPMTask_APLTaskQry", &qryTagAPLWF));
			if (qryTagAPLWF)
			{
				printf("\n Here:Found Query EPMTask_APLTaskQry detail reviewer Wise... \n");fflush(stdout);
			}
			else
			{
				printf("\n Here:Not Found Query EPMTask_APLTaskQry detail reviewer Wise... \n");fflush(stdout);
			}

			ArgName2[0] = "TASK ID";
			ArgVal2[0]  = JobNameWF;	
			ArgName2[1] = "WFStepName";
			ArgVal2[1]  = "Review the Changes";	
			ArgName2[2] = "StepStatus";
			ArgVal2[2]  = "4";		
			ArgName2[3] = "WFSignOffUser";
			ArgVal2[3]  = respParty;		
			
			printf("\n Here:AFTER BUILDING QUERY JobNameWF %s and User %s... ",JobNameWF,respParty);fflush(stdout);
			
			if(QRY_execute(qryTagAPLWF, 4, ArgName2, ArgVal2, &resultsQryWFAct, &ObjsWFAct));

			printf(" Sig History For Work On DML count:%d \n\t",resultsQryWFAct); fflush(stdout);
			if(resultsQryWFAct>0)
			{
				printf(" Sig object found...resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
				//printf("\n Tok Id and Name (%s,%s)",UsrId,UsrNam);fflush(stdout);
				fprintf(output,"\n\nReviewer Id :     %s              Reviewer Name :   %s                      Reviewer Group :           ",UsrId,UsrNam);fflush(output);
				fprintf(output,"\n\n-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------   ",UsrId,UsrNam);fflush(output);
				fprintf(output,"\n\nSR No          TASK                    PROJECT        ERC Date     Reviewer Assg       Status       DML Description                    ",UsrId,UsrNam);fflush(output);
				fprintf(output,"\n                                                   (dd-mmm-yyyy)  (dd-mmm-yyyy)                                                                                                                                                                                    ",UsrId,UsrNam);fflush(output);
				fprintf(output,"\n\n-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------   ",UsrId,UsrNam);fflush(output);
						
				int j = 0;
				int	RlzWithIn15Days	= 0;
				int	PendingWithIn15Days	= 0;
				int	PendingAfter15Days	= 0;
				int	RlzAfterIn15Days	= 0;
				for (j=0;j<resultsQryWFAct;j++ )
				{
					tag_t 		Optfmly_tag 	= 	NULLTAG;
					char 		*jobName		= 	NULL;
					char 		*DMLTaksk			= 	NULL;
					char 		*DMLAPL			= 	NULL;
					char 		*timeInDup		= 	NULL;
					int			ActDuration		= 	0;
					char 		*DMLRevNum		= 	NULL;
					char 		*rlzDateDup		= 	NULL;
					char 		*FinalDMLTaksk	= 	NULL;
					tag_t		*ReleaseStat	=	NULLTAG;				
					int 		st_count		=	0;			
					Optfmly_tag = ObjsWFAct[j];
					CALLAPI(AOM_ask_value_int(Optfmly_tag,"fnd0ActualDuration",&ActDuration));
					printf("\n Duration in Minute  :: %d\n",ActDuration);fflush(stdout);
					CALLAPI(AOM_ask_value_string(Optfmly_tag,"job_name",&jobName));
					printf("\n Job Name  :: %s\n",jobName);fflush(stdout);
					CALLAPI(AOM_UIF_ask_value(Optfmly_tag,"fnd0StartDate",&timeInDup));					
					printf("\n\t fnd0StartDate:: [%s]\n\t",timeInDup);
					strtok(timeInDup," ");
					DMLTaksk = strtok (jobName,"/");
					FinalDMLTaksk = (char *) MEM_alloc( 5000 * sizeof(char) );
					tc_strcpy(FinalDMLTaksk,DMLTaksk);
					tc_strcat(FinalDMLTaksk,"*");
					
					
					
					printf("\n APL DML %s",FinalDMLTaksk);fflush(stdout);		
					tag_t		qryAPLTag	= NULLTAG;
					char		*ArgName3[1];
					char		*ArgVal3[1];
					int			resultsQryAPL = 0;
					int			resultsQryAPLD = 0;
					tag_t		*revAPL	= NULLTAG;
					tag_t		*revAPLD	= NULLTAG;
					char* 		c_st_class_name	=	NULL;
					if(QRY_find("Item ID", &qryAPLTag));
					if (qryAPLTag)
					{
						printf("\n Here:Found Query APL DML... \n");fflush(stdout);
					}
					else
					{
						printf("\n Here:Not Found Query APL DML... \n");fflush(stdout);
					}
					
					ArgName3[0] = "Item ID";
					ArgVal3[0]  = FinalDMLTaksk;
					
					if(QRY_execute(qryAPLTag, 1, ArgName3, ArgVal3, &resultsQryAPL, &revAPL));
					
					
					printf(" resultsQry count:%d \n\t",resultsQryAPL); fflush(stdout);
					if(resultsQryAPL>0)
					{
						printf("Item Revision exists in UA....resultsQry:%d \n\t",resultsQryAPL); fflush(stdout);
						int k = 0;
						for (k=0;k<resultsQryAPL;k++ )
						{
							tag_t 		APLMstr_tag 	= 	NULLTAG;
							char 		*DMLNum			= 	NULL;
							char 		*DMLDesc		= 	NULL;
							char 		*ProjectCd		= 	NULL;
							char 		*AplDMLNum		= 	NULL;
							char 		*AplDML			= 	NULL;
							char 		*DMLProjectCode	= 	NULL;
							char 		*AplDMLDesc		= 	NULL;
							char 		*DMLNameDup		= 	NULL;
							tag_t 		revDML			=	NULLTAG;				
							tag_t 		revDMLER		=	NULLTAG;				
							APLMstr_tag = revAPL[k];
							CALLAPI(AOM_ask_value_string(APLMstr_tag,"item_id",&DMLNum));
							printf("\n APL Task Found  :: %s\n",DMLNum);fflush(stdout);	
							//CALLAPI(AOM_ask_value_string(APLMstr_tag,"t5_cprojectcode",&ProjectCd));
							//printf("\n APL Task Proj Code  :: %s\n",ProjectCd);fflush(stdout);	
							printf("\n APL Task Found  :: %s\n",DMLNum);fflush(stdout);
							
							DMLAPL = strtok (jobName,"_");
							tc_strcpy(FinalDMLTaksk,"");
							tc_strcpy(FinalDMLTaksk,DMLAPL);
							tc_strcat(FinalDMLTaksk,"_");
							tc_strcat(FinalDMLTaksk,Plant);
							//tc_strcat(FinalDMLTaksk,"*");
							
							
							//APLJ DML Query and process for release Date
							ArgName3[0] = "Item ID";
							ArgVal3[0]  = FinalDMLTaksk;				
							if(QRY_execute(qryAPLTag, 1, ArgName3, ArgVal3, &resultsQryAPLD, &revAPLD));
							tag_t 		APLDMstr_tag = 	NULLTAG;
							APLDMstr_tag = revAPLD[0];	
							ITEM_ask_latest_rev(APLDMstr_tag,&revDMLER);
							CALLAPI(AOM_ask_value_string(revDMLER,"item_id",&AplDML));
							printf("\n APL DML Found  :: %s\n",AplDML);fflush(stdout);
							CALLAPI(AOM_ask_value_string(revDMLER,"t5_cprojectcode",&DMLProjectCode));
							printf("\n APL DML DMLProjectCode  :: %s\n",DMLProjectCode);fflush(stdout);
							CALLAPI(AOM_ask_value_string(revDMLER,"object_desc",&DMLDesc));
							printf("\n APL DML DMLDesc  :: %s\n",DMLDesc);fflush(stdout);
							
							//ERC DML Query and process for release Date
							strtok (DMLAPL,"_");
							tc_strcpy(FinalDMLTaksk,"");
							tc_strcpy(FinalDMLTaksk,DMLAPL);
			
							ArgName3[0] = "Item ID";
							ArgVal3[0]  = FinalDMLTaksk;	
							char 		*ReleaseDt		= 	NULL;
							if(QRY_execute(qryAPLTag, 1, ArgName3, ArgVal3, &resultsQryAPLD, &revAPLD));
							if(resultsQryAPLD!=0)
							{
								printf("\n Zero Object found for item id:: %d %s\n",resultsQryAPLD,FinalDMLTaksk);fflush(stdout);
								APLDMstr_tag = 	NULLTAG;
								APLDMstr_tag = revAPLD[0];									
								ITEM_ask_latest_rev(APLDMstr_tag,&revDMLER);
								CALLAPI(AOM_ask_value_string(revDMLER,"item_id",&AplDMLNum));
								printf("\n ERC DML Found  :: %s\n",AplDMLNum);fflush(stdout);
								CALLAPI(AOM_UIF_ask_value(revDMLER,"date_released",&ReleaseDt));											
								printf("\n\n\t\t ERC Release Date  is :%s",ReleaseDt);	fflush(stdout);								
								strtok(ReleaseDt," ");
							}
							else
							{
								tc_strcpy(ReleaseDt," ");
							}
						
							ITEM_ask_latest_rev(APLDMstr_tag,&revDML);	
							if(revDML != NULLTAG)
							{	
								CALLAPI(AOM_ask_value_string(revDML,"item_id",&DMLRevNum));
								printf("\n ERC DML Revision Found  :: %s\n",DMLRevNum);fflush(stdout);	
								CALLAPI(WSOM_ask_release_status_list(revDML,&st_count,&ReleaseStat));
								printf("\n\n\t\t Release Status Count  is :%d",st_count);	fflush(stdout);							
								
							}							
							if(tc_strcmp(c_st_class_name,"T5_LcsStdWrkg"))
							{	
								printf("\n Lifecyclestate equal and STDS Working"); fflush(stdout);			
								fprintf(output,"\n\n%d          %s           %s       %s     %s       Claimed       %s",j+1,DMLNum,DMLProjectCode,ReleaseDt,timeInDup,DMLDesc);fflush(output);	
								taskFoundRev++;	
							}
							else
							{			
								printf("\n Lifecyclestate is not APL Working"); fflush(stdout);						
							}
						}
					}
					else
					{
						printf(" Item Revision Does not exists in UA....resultsQry:%d \n\t",resultsQry); fflush(stdout);
					}			
				}
				fprintf(output,"\n\n=================================================================================================================================================================================================================     \n\n",UsrId,UsrNam);fflush(output);
			}
			else
			{
				printf(" Sig object Does not exists....resultsQryWFAct:%d \n\t",resultsQryWFAct); fflush(stdout);
			}
		}
		if(taskFoundRev==0)
		{
			fprintf(output,"\n\nNo Working %s DML pending with any mapped reviewer",Plant);fflush(output);	
		}
	}
	else
	{
		printf("\n STD Analyst Group/Role Name:[%s] Not found in the System hence report will not generated for this.\n",STD_Ana_Grp);
		return ifail;
	}
	
	
	
	printf("\nEnd of program.....!!\n\n");
	ifail = ITK_exit_module(true);
	return ifail;
	/* Program Logic End*/
}
