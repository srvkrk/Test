#include <stdio.h>                                                //5442 Code Logic
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include "unidefs.h"
#define TE_MAXLINELEN
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
//#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <pie/pie.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <unidefs.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define ITK_err (EMH_USER_error_base + 2)

FILE *fp;
int		z					= 0;
int		Flag				= 0;
char	*VC					= NULL;

int VCExpandfunction(char*,char*);
int VCExpandfunctionRecursiveCall(tag_t,char*);

   
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		//printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
	}
	return return_code;
}

int ITK_user_main(int argc, char *argv[])
{
       
	int		z			= 0;
   
	char	*plantName	= NULL;
	char	*outFile	= NULL;


	VC				= ITK_ask_cli_argument("-VC=");
	plantName		= ITK_ask_cli_argument("-PlantName=");
	outFile			= ITK_ask_cli_argument("-outFile=");

	/*******************Actual code started**************/

	printf("\n VC : %s and plantName : %s \n", VC,plantName); fflush(stdout);

    z = ITK_auto_login();
    if(z == ITK_ok)
    {
        printf("\n Login Successfull \n"); fflush(stdout);
       
    }
    else
    {
        printf("\n Login Not Successfull \n"); fflush(stdout);
    }

	fp=fopen(outFile,"w");
	fprintf(fp,"VC||Lvl||Child Part||Rev||Seq||Desc||Qty||Bulk_Mat||Base_Unit_of_Measure||Plant Code||Usage_probability||Alternate_Group_Code||DR_Status||Overall_Status||Procurement_Type||Part_Family||Keyword_Description||Material_Class");fflush(fp);

	char test1[25];
	strcpy(test1,VC);
	size_t length = strlen(test1);

	printf("\n VC length is [%d]",length);

	if ((int)length>4)
	{
		if(test1[0]=='5' && test1[1] == '4' && test1[2] =='4' && test1[3] =='2')
		{
			VCExpandfunction(VC,plantName);
		}
		else
		{
			printf("\n Value not match to 5442");
		}
	}
	else
	{
		printf("\n VC length is not greater than 4");
	}
	fclose(fp);
}


int VCExpandfunction(char* part,char* plantName)
{
	tag_t	plat				= NULLTAG;
	tag_t	item_rev_tag		= NULLTAG;
	
	
	tag_t	close_tag			= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	*childlines			= NULLTAG;
	tag_t	childPartT			= NULLTAG;
	tag_t	childPartT1			= NULLTAG;
	tag_t	*childlines2		= NULLTAG;
	tag_t	bom_window			= NULLTAG;
	tag_t	rule				= NULLTAG;
	tag_t	*closurerule		= NULLTAG;

	char	*item_TopLine_Id	= NULL;
	char	*Lvl				= NULL;
	char	*Lvl1				= NULL;
	char	*ChildItem			= NULL;
	char	*ChildItem1			= NULL;
	char	*PartType			= NULL;
	char	*PartType1			= NULL;

	char **rulename = NULL;
	char **rulevalue = NULL;
	
	int		rulefound			= 0;
	int		n_lines1			= 0;
	int		n_lines2			= 0;
	int		i					= 0;
	int		jj					= 0;
	
	printf ("\n\n Inside VCExpandfunction.");fflush(stdout);
	
	ITK_CALL(ITEM_find_item(part, &plat));
	ITK_CALL(ITEM_ask_latest_rev(plat, &item_rev_tag));

	ITK_CALL(BOM_create_window(&bom_window));
	ITK_CALL(CFM_find("ERC release and above", &rule ));
	ITK_CALL(BOM_set_window_config_rule(bom_window, rule ));  

	ITK_CALL(PIE_find_closure_rules2("BOMCorrClosureRule",PIE_TEAMCENTER, &rulefound, &closurerule)); 
	if (rulefound > 0)
	{
	    close_tag = closurerule[0];
	    printf ("\n closure rule found");fflush(stdout);
	}
	ITK_CALL(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));
	ITK_CALL(BOM_set_window_pack_all(bom_window, TRUE));
	
    ITK_CALL(BOM_set_window_top_line(bom_window , NULLTAG, item_rev_tag, NULLTAG, &top_line )); 
	
	ITK_CALL(AOM_UIF_ask_value(top_line,"bl_item_item_id",&item_TopLine_Id));
	printf("\n ToplIne Item Id : [%s]", item_TopLine_Id);

	if(top_line != NULLTAG)
    {
		VCExpandfunctionRecursiveCall(top_line,plantName);
	}
	
	return 0;
}

int VCExpandfunctionRecursiveCall(tag_t childBomline, char* plantName)
{
	tag_t	plat				= NULLTAG;
	tag_t	item_rev_tag		= NULLTAG;
	
	tag_t	*childlines			= NULLTAG;
	tag_t	childPartT			= NULLTAG;
	tag_t	childPartT1			= NULLTAG;
	tag_t	*childlines2		= NULLTAG;
	tag_t	bom_window			= NULLTAG;
	tag_t	rule				= NULLTAG;
	tag_t	*closurerule		= NULLTAG;
	tag_t	findItemTag			= NULLTAG;
	tag_t	*rev_list			= NULLTAG;
	tag_t	revfound			= NULLTAG;

	char	*item_TopLine_Id	= NULL;
	char	*Lvl				= NULL;
	char	*Lvl1				= NULL;
	char	*ChildItem			= NULL;
	char	*ChildItem1			= NULL;
	char	*PartType			= NULL;
	char	*PartType1			= NULL;
	char	*Rev_Seq			= NULL;
	char	*Seq_ID				= NULL;
	char	*Rev				= NULL;
	char	*Description		= NULL;
	char	*Qty				= NULL;
	char	*UnitOfMeasure		= NULL;
	char	*UOM		   		= NULL;
	char	*ProcurementType    = NULL;
	char	*PlantCode			= NULL;
	char	*DRStatus			= NULL;
	char	*relstatus			= NULL;
	char	*OverallStatus		= NULL;
	char	*rev_id				= NULL;
	char	*afterrelstatus		= NULL;
	char	*PreviouseRevDRStatus = NULL;
	char	*Material_Class			= NULL;
	char	*Keyword_Description	= NULL;
	char	*Part_Family			= NULL;	
	char	*projectcode			= NULL;	

	
	int		rulefound			= 0;
	int		n_lines1			= 0;
	int		n_lines2			= 0;
	int		i					= 0;
	int		jj					= 0;
	int		APLFLAG				= 0;
	int		count				= 0;
	
	printf ("\n\n Inside VCExpandfunctionRecursiveCall.....");fflush(stdout);
	
	if(childBomline != NULLTAG)
    {
        ITK_CALL(BOM_line_ask_child_lines(childBomline, &n_lines1, &childlines));
        printf("\n Child part count : [%d]", n_lines1);
		for (i=0 ; i < n_lines1 ; i++)
		{
			 childPartT = NULLTAG;
             childPartT = childlines[i];
			 ChildItem	= NULL;
			 Lvl	= NULL;
			 PartType = NULL;
			 Description = NULL;
			 Rev = NULL;
			 Qty = NULL;
			 UnitOfMeasure = NULL;
			 UOM = NULL;
			 PlantCode = NULL;
			 DRStatus = NULL;
			 relstatus = NULL;
			 OverallStatus = NULL;
			 rev_id = NULL;
			 Material_Class	= NULL;	
			 Keyword_Description = NULL;
			 Part_Family	= NULL;
			 projectcode	= NULL;

			 ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_level_starting_0",&Lvl));
			 printf("\n Level: [%s] ",Lvl);fflush(stdout);

			 ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_item_item_id",&ChildItem));
			 printf("\n child_item: [%s]",ChildItem);fflush(stdout);

			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_Design Revision_t5_PartType",&PartType));          
			printf("\n PartType: [%s]",PartType); fflush(stdout);

			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_rev_item_revision_id",&Rev));
			printf("\n Revision: [%s]",Rev);fflush(stdout);
			Rev_Seq = strtok(Rev,";"); 
			printf("\n Revision is : [%s] ",Rev_Seq); fflush(stdout); 
			Seq_ID= strtok(NULL,"");
			printf("\n Seq_ID is : [%s]",Seq_ID); fflush(stdout);
	
			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_rev_object_desc",&Description));
			printf("\n Description is : [%s]",Description); fflush(stdout);

			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_quantity",&Qty));
			printf("\n Quantity: [%s]",Qty);fflush(stdout);

			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_uom",&UnitOfMeasure));
			printf("\n UnitOfMeasure: [%s]",UnitOfMeasure);fflush(stdout);
                                    
			if(tc_strcmp("each", UnitOfMeasure) == 0)
			{
			  UOM = "Nos";
			}
			else if(tc_strcmp("1-Mtr", UnitOfMeasure) == 0)
			{
			  UOM = "Mtr";
			}
			else if(tc_strcmp("2-Kg", UnitOfMeasure) == 0)
			{
			  UOM = "Kg";
			}
			else if(tc_strcmp("3-Ltr", UnitOfMeasure) == 0)
			{
			  UOM = "Ltr";
			}
			else if(tc_strcmp("4-Nos", UnitOfMeasure) == 0 || tc_strcmp("PsmEa", UnitOfMeasure))
			{
			  UOM = "Nos";
			}
			else if(tc_strcmp("5-Sq.Mtr", UnitOfMeasure) == 0)
			{
			  UOM = "Sq.Mtr";
			}
			else if(tc_strcmp("6-Sets", UnitOfMeasure) == 0)
			{
			  UOM = "Sets";
			}
			else if(tc_strcmp("7-Tonne", UnitOfMeasure) == 0)
			{
			  UOM = "Tonne";
			}
			else if(tc_strcmp("8-Cu.Mtr", UnitOfMeasure) == 0)
			{
			  UOM = "Cu.Mtr";
			}
			else if(tc_strcmp("9-Thsnds", UnitOfMeasure) == 0)
			{
			  UOM = "Thousands";
			}
			printf("\n plantName = [%s]",plantName);fflush(stdout);

			if (tc_strcmp("CAR",plantName) == 0)
			{
					ProcurementType=NULL;
					AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_CarMakeBuyIndicator",&ProcurementType); 
					ProcurementType = strtok(ProcurementType, "(");
					printf("\n ProcurementType = [%s]",ProcurementType);fflush(stdout);
					PlantCode = "1100";
					printf("\n PlantCode = [%s]",PlantCode);fflush(stdout);
			}
			else if (tc_strcmp("CVBU JSR",plantName)==0)
			{
					ProcurementType=NULL;
					AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_JsrMakeBuyIndicator",&ProcurementType); 
					ProcurementType = strtok(ProcurementType, "(");
					printf("\n ProcurementType = [%s]",ProcurementType);fflush(stdout);
					PlantCode = "2001";
					
			}
			else if (tc_strcmp("CVBU LKO",plantName) || tc_strcmp("",plantName)== 0)
			{
					ProcurementType=NULL;
					AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_LkoMakeBuyIndicator",&ProcurementType); 
					ProcurementType = strtok(ProcurementType, "(");
					printf("\n ProcurementType = [%s]",ProcurementType);fflush(stdout);
					PlantCode = "3001";
				
			}
			else if (tc_strcmp("CVBU PNR",plantName)==0)
			{
					ProcurementType=NULL;
					AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_PnrMakeBuyIndicator",&ProcurementType); 
					ProcurementType = strtok(ProcurementType, "(");
					printf("\n ProcurementType = [%s]",ProcurementType);fflush(stdout);
					PlantCode = "3100";
					
			}
			else if (tc_strcmp("CVBU PUNE",plantName)==0)
			{
					ProcurementType=NULL;
					AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_PunMakeBuyIndicator",&ProcurementType); 
					ProcurementType = strtok(ProcurementType, "(");
					printf("\n ProcurementType = [%s]",ProcurementType);fflush(stdout);
					PlantCode = "1001";
					
			}
			else if (tc_strcmp("PCBU",plantName)==0)
			{
					ProcurementType=NULL;
					AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_PunPCBUMakeBuyIndicator",&ProcurementType); 
					ProcurementType = strtok(ProcurementType, "(");
					printf("\n ProcurementType = [%s]",ProcurementType);fflush(stdout);
					PlantCode = "1100";
					
			}	
			else if (tc_strcmp("SMALLCAR AHD",plantName)==0)
			{
				
					ProcurementType=NULL;
					AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_AhdMakeBuyIndicator",&ProcurementType); 
					ProcurementType = strtok(ProcurementType, "(");
					printf("\n ProcurementType = [%s]",ProcurementType);fflush(stdout);
					PlantCode = "7501";
					
			}
			else if (tc_strcmp("SMALLCAR PNR",plantName) || tc_strcmp("CVBU UTK",plantName)==0)
			{
					ProcurementType=NULL;
					AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_PnrMakeBuyIndicator",&ProcurementType); 
					ProcurementType = strtok(ProcurementType, "(");
					printf("\n ProcurementType = [%s]",ProcurementType);fflush(stdout);
					PlantCode = "3100";
					
			}	
			else if (tc_strcmp("DHARWAD",plantName)==0)
			{
					ProcurementType=NULL;
					AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_DwdMakeBuyIndicator",&ProcurementType);
					ProcurementType = strtok(ProcurementType, "(");
					printf("\n ProcurementType = [%s]",ProcurementType);fflush(stdout);
					PlantCode = "1500";

			}
			else if (tc_strcmp("PUVBU",plantName)==0)
			{
					ProcurementType=NULL;
					AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_PunUVMakeBuyIndicator",&ProcurementType); 
					ProcurementType = strtok(ProcurementType, "(");
					printf("\n ProcurementType = [%s]",ProcurementType);fflush(stdout);
					PlantCode = "1140";
			}

			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_Design Revision_t5_ProjectCode",&projectcode));

			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_Design Revision_t5_PartStatus",&DRStatus));      
			printf("\n DRStatus: [%s]",DRStatus); fflush(stdout); 

			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_rev_release_status_list",&relstatus));
			printf("\n Release status is : [%s]",relstatus);fflush(stdout);
			APLFLAG=0;
			if(tc_strstr(relstatus,"ERC Released") != NULL)
			{
				printf("\n Released status is:%s",relstatus);fflush(stdout); 

				if (tc_strcmp("DR3P", DRStatus) ==0|| tc_strcmp("DR4", DRStatus) ==0|| tc_strcmp("DR5", DRStatus) ==0|| tc_strcmp("AR3P", DRStatus) ==0||tc_strcmp("AR4", DRStatus)==0||tc_strcmp("AR5", DRStatus)== 0)
	            {	
	                 OverallStatus = "okay";
		             printf("\n Okay condition the Status: [%s]",OverallStatus);fflush(stdout);
				}
				else 
			    {
					ITK_CALL(ITEM_find_item(ChildItem,&findItemTag));
	                ITEM_list_all_revs(findItemTag, &count, &rev_list);
					printf("\n count :%d",count);fflush(stdout);
					if (count > 1)
					{	
						AOM_UIF_ask_value(rev_list[count -2 ], "item_revision_id", &rev_id);
						printf("\n item rev is :%s ",rev_id);fflush(stdout);
						ITEM_find_revision(findItemTag,rev_id,&revfound);
						printf("\n after revfound");fflush(stdout);
						ITK_CALL(AOM_UIF_ask_value(revfound,"release_status_list",&afterrelstatus));
						printf("\n afterrelstatus status is: %s",afterrelstatus);fflush(stdout);

                        ITK_CALL(AOM_UIF_ask_value(revfound,"t5_PartStatus",&PreviouseRevDRStatus));       
                        printf("\n PreviouseRevDRStatus: %s",PreviouseRevDRStatus); fflush(stdout); 
                           
						if( tc_strcmp("ERC Released", afterrelstatus) == 0 && tc_strcmp("", PreviouseRevDRStatus) ==0|| tc_strcmp("DR4", PreviouseRevDRStatus) ==0|| tc_strcmp("DR5", PreviouseRevDRStatus) ==0|| tc_strcmp("AR3P", PreviouseRevDRStatus) ==0||tc_strcmp("AR4", PreviouseRevDRStatus)==0||tc_strcmp("AR5", PreviouseRevDRStatus)== 0)  
                        {
							OverallStatus = "partial";
							printf("\n Partial OveralDR3PlStatus: %s",OverallStatus);fflush(stdout);
						}
						else
						{
                            OverallStatus = "cost not released";
							printf("\n OverallStatus: %s",OverallStatus);fflush(stdout);
						}

					}
					else
					{
						if (tc_strcmp( DRStatus,"DR3P") !=0|| tc_strcmp(DRStatus,"DR4") !=0|| tc_strcmp( DRStatus,"DR5") !=0|| tc_strcmp( DRStatus,"AR3P") !=0||tc_strcmp( DRStatus,"AR4")!=0||tc_strcmp( DRStatus,"AR5")!= 0)                             {
						{
							OverallStatus = "partial";
							printf("\n Partial OveralDR3PlStatus:%s ",OverallStatus);fflush(stdout);
						}
					}
					}
				}
				if(tc_strcmp(projectcode,"1111")==0)
				{
					 OverallStatus = "NO DR";
				}
				
			
			}
			else
			{
				APLFLAG=1;
				printf("\n not released part this OverallStatus:%s and APLFLAG:%d ",OverallStatus,APLFLAG);fflush(stdout);
			}

			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_Design Revision_t5_MatlClass",&Material_Class));
			printf("\n Material_Class:%s",Material_Class);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_Design Revision_t5_CategoryName",&Keyword_Description));
			printf("\n Keyword_Description:%s",Keyword_Description);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(childPartT,"bl_T5_ClrPartRevision_t5_EngineType",&Part_Family));
			printf("\n Part_Family:%s",Part_Family);fflush(stdout);

			if((tc_strcmp(PartType,"") !=0 ) && (tc_strcmp(PartType,"Dummy") !=0 ) && (tc_strcmp(PartType,"Dummy Component")!=0) && (tc_strcmp(PartType,"Dummy Assembly")!=0) &&
				(tc_strcmp(PartType,"D") !=0 ) && (tc_strcmp(PartType,"Info Fitment Drw") !=0 ) && (tc_strcmp(PartType,"IFD") !=0 ) && (tc_strcmp(PartType,"IM") !=0 ) && (tc_strcmp(PartType,"IFD Module") !=0 )
				&& (tc_strcmp(PartType,"Table Drawing") !=0 ) && (tc_strcmp(PartType,"TD") !=0 ) && (tc_strcmp(PartType,"Stage Part") !=0 ) && (tc_strcmp(PartType,"SP") !=0 ) && (tc_strcmp(PartType,"Stage Assembly") !=0 ) && (tc_strcmp(PartType,"SA") !=0 ))
			{
				printf("\n Printing in Report :- %s||%s||%s||%s||%s||%s|||%.0f|| ||%s||%s|| || ||%s||%s||%s||||%s||%s||%s",VC,Lvl,ChildItem,Rev,Seq_ID,Description,strtof(Qty,NULL)*100,UOM,PlantCode,DRStatus,OverallStatus,ProcurementType,Part_Family,Keyword_Description,Material_Class); fflush(stdout);
				fprintf(fp,"\n%s||%s||%s||%s||%s||%s|||%.0f|| ||%s||%s|| || ||%s||%s||%s||||%s||%s||%s",VC,Lvl,ChildItem,Rev,Seq_ID,Description,strtof(Qty,NULL)*100,UOM,PlantCode,DRStatus,OverallStatus,ProcurementType,Part_Family,Keyword_Description,Material_Class);fflush(fp);

				VCExpandfunctionRecursiveCall(childPartT,plantName);
			}
		}
	}

	return 0;
}