#include <tcinit/tcinit.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <tccore/tctype.h>
#include <ae/dataset.h>
#include <tccore/libtccore_exports.h>
extern TCCORE_API int TCTYPE_ask_type(
        const char      *type_name,
        tag_t           *type_tag);
#include <tccore/libtccore_undef.h>
//#define TCTYPE_name_size_c 100
#define TCTYPE_name_size_c1 100
//#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
//#define IFERR_RETURN(X) if (IFERR_REPORT(X)) return
#define PROP_UIF_set_value_msg   "PROP_UIF_set_value"

#define PROP_set_value_int_msg   "PROP_set_value_int"

static void handle_ifail(char *file, int line);
static void MultiExplosion (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,int reqLevel,int level);
static void MultiExplosionLinkInfo (tag_t line, char *Plant, tag_t line1, int depth,FILE *fd,char *Uidd,int reqLevel,int level);
#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;
	
int ITK_user_main(int argc,char* argv[])
{
int z;
int status;

                //tag_t dml_type_tag                            = NULLTAG;
               // tag_t object_create_input_tag                 = NULLTAG;
                //tag_t new_object                              = NULLTAG;
                tag_t rev_tag                           		= NULLTAG;
				tag_t NoOfWeld_tag                              = NULLTAG;
				tag_t IsWeld_tag                                = NULLTAG;
                
				FILE* fptr = NULL;
				//int POM_bypass_attr_update=0;
				
//	char *inputfile = NULL;	
	char *inputline = NULL;
	
	
	//char	*itemId	= NULL;

	char	*item_id		= NULL;
	char	*value		= NULL;
	char	*rev_id		= NULL;
	
//inputfile = ITK_ask_cli_argument("-i=");
ITK_CALL(ITK_set_journalling( TRUE ));
ITK_CALL(ITK_initialize_text_services (0));
printf("\n\n\t Attempting Logging\n ");

z=ITK_CALL(ITK_auto_login());
if(z!=ITK_ok)
  {
	  printf("\n\n\t OMG Login Not Successfull\n ");
  }
  else
	{
	  printf("\n\n\t Login Successfull\n ");
	}

	
printf("\n\n\t Login Successfull\n ");

//fptr=fopen("D:\\TCUA_NewInstall_InstallDir\\input.txt","r");
//fptr=fopen("C:\\Users\\pkk93803\\Desktop\\ITK\\dhanashri\\input_weld.txt","r");
fptr=fopen("//user//uaprod//Priya//input.txt","r");
	printf("\n file read .......");fflush(stdout);
	

                if(fptr!=NULL)
                {
                    inputline=(char *) MEM_alloc(1000);
                    while(fgets(inputline,1000,fptr)!=NULL)
                    {
						
					printf("\n inputline .......%s",inputline);fflush(stdout);
                    fputs(inputline,stdout);
                    
                    item_id=tc_strtok(inputline,"^");
					rev_id=tc_strtok(NULL,"^");
					value=tc_strtok(NULL,"^");
					printf("\nInput item:%s\tRev:%s\tValue:%s",item_id, rev_id, value);
					
					int a = atoi(value);
					
					ITK_CALL(ITEM_find_rev(item_id, rev_id, &rev_tag));
				
				
				if(rev_tag != NULLTAG)
				{
					printf("\nRev found...!!");
										
	                ITK_CALL(POM_attr_id_of_attr("t5_NoOfWeldSpots","Design_0_Revision_alt",&NoOfWeld_tag));
					  printf("\n NoOfWeld tag found..!!");
                    ITK_CALL(POM_attr_id_of_attr("t5_IsWeldSpot","Design_0_Revision_alt",&IsWeld_tag));
					  printf("\n IsWeldSpot tag found..!!");
                    ITK_CALL(AOM_refresh(rev_tag,TRUE));
					  printf("\n Refresh1..!!");
                    ITK_CALL(POM_set_env_info(POM_bypass_access_check,TRUE,0,0,NULLTAG,NULL));
                    ITK_CALL(POM_set_attr_int(1,&rev_tag,NoOfWeld_tag,a));
					  printf("\n print the value for NoOfWeldSpots..!!");
					ITK_CALL(POM_set_attr_string(1,&rev_tag,IsWeld_tag,"TRUE"));
					  printf("\n set the value for IsWeldSpot..!!");
                    ITK_CALL(AOM_save(rev_tag));
					  printf("\nSave...!!");
                    ITK_CALL(AOM_refresh(rev_tag,TRUE));
					  printf("\n Refresh2..!!");

				}
				else
				{
					printf("\nRev. not found..!!");
					return 0;
				}
			   	
				}
		}
CLEANUP:
	ITK_exit_module(TRUE);
	return status;
}


