#define _CLMAIN_DEFNS
#define _CLMAIN_DEFNS
#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
#include <tel.h>
#include <msgomf.h>
#include <Mtimsg.h>
#include <ui.h>
#include <msgpro.h>
#include <proerr.h>
//----------------------------------------------------------

void write2xml(FILE * , char*);
int ctr=0;

 int a=0;
FILE *Report; 
FILE *Report1;
FILE *Report2;

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}
status t5SetDBScope(int *mfail)
{
  char		*mod_name     = "t5SetDBScope";
  status	dstat         = OKAY; 
  string    usrDept       = NULL;
  string    usrLocation   = NULL;
  string    usrAgency     = NULL;
  string    strDBScope    = NULL; 
  SqlPtr    sqlPtr        = NULL;
  
  ObjectPtr myPref		  = NULL;

  SetOfObjects myPrefSet  =NULL;
  //printf("\nInside t5SetDBScope \n");fflush(stdout);

 usrDept		 = nlsStrAlloc(30);
 usrLocation	 = nlsStrAlloc(8);
 usrAgency        = nlsStrAlloc(10); 
	  
	  
 usrDept       =  nlsStrCpy(usrDept,"");
 usrLocation   =  nlsStrCpy(usrLocation,"");
 usrAgency     =  nlsStrCpy(usrAgency,"");

printf("\n Inside my function\n");fflush(stdout);
//if (dstat = getUsrDetails(usrDept,usrLocation,usrAgency,mfail)) goto EXIT;

printf("\n   USER LOCATION IS --> %s\n",usrLocation);fflush(stdout);
printf("\n   USER AGENCY IS   --> %s\n",usrAgency);fflush(stdout);

if(!nlsStrCmp(usrLocation,"JSR"))
	{
	 printf("\n 1 ] IF   MY LOCATION ==JSR ");fflush(stdout);
	  strDBScope = NULL;
	  strDBScope = "JSR_DB_SCope";
	}
else if(!nlsStrCmp(usrLocation,"PUNE") || !nlsStrCmp(usrAgency,"APL")|| !nlsStrCmp(usrAgency,"ERC"))
	{
	  printf("\n 2 ] IF   MY LOCATION  ==PUNE\n");fflush(stdout);
	  strDBScope = NULL;
	  strDBScope = "HNJ & SU DB SCope";
	}
else if(!nlsStrCmp(usrLocation,"LKO"))
	{
	  printf("\n 3 ] IF   MY LOCATION ==LKO");fflush(stdout);
	  strDBScope = NULL;
	  strDBScope = "LKO_DB_SCope";
	}



 if(!nlsIsStrNull(strDBScope))
	{

		 //printf("\nInside to Set DB Scope for : %s \n",strDBScope);fflush(stdout);
		 t5CheckMfail(oiSqlCreateSelect(&sqlPtr));
		 t5CheckMfail(oiSqlWhereEQ(sqlPtr,BrowserWindowNameAttr,strDBScope));
		 t5CheckMfail(QueryDbObject(SavDbPClass,sqlPtr,1,TRUE,SC_SCOPE_OF_SESSION,&myPrefSet,mfail));
		  
		 //printf("\nNo of Pref are :%d\n",setSize(myPrefSet));fflush(stdout);
		 if(setSize(myPrefSet) > 0)	myPref = setGet(myPrefSet,0);
		
		 if(myPref) 
			{
				if(dstat =Open(myPref,mfail));
				if(*mfail) goto CLEANUP;
			}
	   if(sqlPtr) oiSqlDispose(sqlPtr);
	}

CLEANUP:
	  //printf("\nInside CLEANUP for t5SetDBScope \n" );fflush(stdout);
	  //t5FreeObjectPtr(myPref);
	  //if(myPrefSet) objDisposeAll(myPrefSet); myPrefSet = NULL;
	  if(!nlsIsStrNull(usrDept)) nlsStrFree(usrDept); usrDept = NULL;
	  if(!nlsIsStrNull(usrLocation)) nlsStrFree(usrLocation); usrLocation = NULL;
	  if(!nlsIsStrNull(usrAgency)) nlsStrFree(usrAgency); usrAgency = NULL;
EXIT:
	//printf("\nInside EXIT for t5SetDBScope \n" );fflush(stdout);
     if(dstat != OKAY)
	 uiShowFatalError(dstat, WHERE);
	 return (dstat);
}
;

//----------------------------------------------------------------------------------------------
;
//*****************************************    MAIN METHOD     ****************************************************** //
int main(int argc, char *argv[ ])
{

	string			Username			    =	"super user" ;
	string			Password			    =	"abc123" ;
	string			userDup				=NULL;	
	string			user				=NULL;	
	//string			sFileDate			=NULL;
	//string			sFilename			=NULL;
	//string			StrFileName			=NULL;
	//string			StrFileNameDup		=NULL;
	//string			sDateCreated		=NULL;
	//string			sDateCreatedDup		=NULL;
	//string			sDateCreatedDup1	=NULL;
	//string			timestamp			=NULL;
	//string			timestampDup		=NULL;
	string			sWorkLocationName   =NULL;
	string			stmpFileWrite		=NULL;
	//SetOfObjects    soTestReqObj	       =NULL;
	SetOfObjects    indObjs              =NULL;	
	SetOfObjects    FIRREQReportSo       =NULL;	
	
	//ObjectPtr       WorkLocFileObj		 =NULL; 
	//ObjectPtr	    WorklocObjP          =NULL ;

	int				stat				 =OKAY;
	int				i				 =0;
	SetOfObjects	SCHHasVCObjs		= NULL;
	//int             k=0;
	integer        resultIx ;
	string			OutFile			= NULL;
   
	

	//FILE		*AllDataFP			=NULL;
	FILE  *fp  =  NULL; 
	FILE  *fp1  =  NULL; 
	FILE  *file  =  NULL; 
	//FILE  *file1  =  NULL; 
	
  	t5MethodInitWMD("ObjectDeatilsForUA.c"); 

	Username=nlsStrAlloc(20);
	Password=nlsStrAlloc(20);
	OutFile=nlsStrAlloc(30);
	stmpFileWrite=nlsStrAlloc(200);
	sWorkLocationName=nlsStrAlloc(100);

	string			InpFileDup		= NULL;
	string			InpFile1		= NULL;
	
	

	
	
	if (dstat = clInitMB2 (argc, &argv, NULL)) goto CLEANUP;
	if (dstat = clTestNetwork ()) goto CLEANUP;
	if (dstat = clInitialize2 (FALSE)) goto CLEANUP;
	if (dstat = clLogin2(Username,Password,&stat)) goto CLEANUP;	
	if (stat != OKAY)
	{
		printf("\nInvalid User Name or Password !!!!!!!!!!!!\n");
	}

	printf("\nInside client_code and calling set db scope function\n");fflush(stdout); 

	if (dstat = smGetSessionUsrName(&user)) goto EXIT;
	if (user) userDup=nlsStrDup(user);

	printf("\n LOGGED IN USER IS --> %s\n",userDup);fflush(stdout);
	t5CheckMfail(t5SetDBScope(mfail));

	/*printf("Inside loop for read Input file........\n");fflush(stdout);
	fp=fopen(InpFile,"r");
	if(fp==NULL)
	{
		printf("unable  open  File.\n ");fflush(stdout);
		goto  CLEANUP;
	}*/
//	fp1=fopen("Outputfile.csv","w");
//	if(fp1==NULL)
//	{
//		printf("unable to create File.\n ");fflush(stdout);
//		goto  CLEANUP;
//	}

/*	if(InpFile)InpFileDup = nlsStrDup(InpFile);

	strtok(InpFileDup,"/");
	InpFile1 = strtok(NULL,".");
	nlsStrCpy(OutFile,"");
	nlsStrCpy(OutFile,"Info_");
	nlsStrCat(OutFile,InpFile1);
	nlsStrCat(OutFile,".csv");
	printf("InpFile1	%s OutFile %s.\n ",InpFile1,OutFile);fflush(stdout);
	file=fopen(OutFile,"w");
	if(file==NULL)
	{
		printf("unable to create File.\n ");fflush(stdout);
		goto  CLEANUP;
	}*/
//	file1=fopen("DrwDoc.txt","w");
//	if(file1==NULL)
//	{
//		printf("unable to create File.\n ");fflush(stdout);
//		goto  CLEANUP; 
//	}

	//string 			LineReadDup			= NULL;
	string 			LineRead			= NULL;//LineRead
	//string 			PartNoDup			= NULL;
	//SetOfObjects    extraObj			= NULL;
	SetOfObjects    SoPartAlt			= NULL;
	SqlPtr          sqlPtr				= NULL;
	//string		ExtObjs1				= NULL;
	SetOfObjects	ExtObjs1				= NULL;
	SetOfObjects	ExtObjs				= NULL;
//	SetOfObjects	ExtObjs1				= NULL;
	//ObjectPtr		DiaObj1				= NULL;
	//SetOfObjects	DiaObj1				= NULL;
	//ObjectPtr		DocOPtr				= NULL;
//	ObjectPtr		ExtStrs1				= NULL;
	//SetOfStrings	ExtStrs1				= NULL;
	//SetOfStrings	ExtStrs				= NULL;
	//ObjectPtr		ValTab				= NULL;
	string			FrameName			= NULL;
	string			sOwnerName			= NULL;
	string			PDFFileNameDup		= NULL;
	string			VehPartNo			= NULL;
	string			VehPartNoDup		= NULL;
	string			FIRReqNo			= NULL;
	string			FIRReqNoDup			= NULL;
	string			Year				= NULL;
	string			YearDup				= NULL;
	string			ProjectCode			= NULL;
	string			ProjectCodeDup		= NULL;
	string			FIRRelDate			= NULL;
	string			FIRRelDateDup		= NULL;
	string			CompDesc			= NULL; 
	string			CompDescDup			= NULL;
	string			Owner				= NULL;
	string			OwnerDup			= NULL;
	string			RelTypeFIR			= NULL;
	string			RelTypeFIRDup		= NULL;
	string			Subject				= NULL;
	string			SubjectDup			= NULL;
	string			Conclusion			= NULL;
	string			ConclusionDup		= NULL;
	string			ActionSuggested		= NULL;
	string			ActionSuggestedDup	= NULL;
	string			Recommend			= NULL;
	string			RecommendDup		= NULL;
	string			LessLearn			= NULL;
	string			LessLearnDup			= NULL;
	string			TestItemNo			= NULL;
	string			TestItemNoDup			= NULL;
	string			LegacyFIRNo			= NULL;
	string			LegacyFIRNoDup			= NULL;
	string			PATName				= NULL;
	string			PATNameDup				= NULL;
	string			sPrgName			= NULL;
	string			sPrgNameDup			= NULL;
	string			sPrtDesc			= NULL;
	string			sPrtDescDup			= NULL;
	string    schemename= NULL;
		string			sPrtNum			= NULL;
		string			sPrtNumDup		= NULL;
		string			sPrtNum1			= NULL;
		string			sPrtNumDup1		= NULL;
	string			clrscmname			=	NULL;
	//string			sRev			= NULL;
	string			sRevDup		= NULL;
	//string			sSeq			= NULL;
	string			sSeqDup				= NULL;
	string			PDFReportFileNameDup= NULL;
	string			PDFReportFileName	= NULL;
	ObjectPtr		MCTDRepObj			= NULL;
	ObjectPtr	MCTDRegReportObj		= NULL;
	boolean        ans ;
	//ObjectPtr	reqObj					= NULL;
	//ObjectPtr       newObj				= NULL;
	//ObjectPtr		newDialog			= NULL;
	//ObjectPtr		FIRObj				= NULL;
	ObjectPtr		nullPtr				= NULL;
	ObjectPtr		nullPtr1				= NULL;
	ObjectPtr		relObj1				= NULL;
	ObjectPtr		nuassocObj			= NULL;
	ObjectPtr		EpaPic4Rel			= NULL;
	//int *mfail=0;
	//char      *FrameName = NULL;

	//PROE

	SetOfObjects DocumentSO = NULL;
	SetOfObjects DocumentRelSO = NULL;
	SetOfObjects DataItemJtSO = NULL;
	SetOfObjects ProDeOnJtSO = NULL;
	SetOfObjects depdiDocSet = NULL;
	SetOfObjects depdiDocSet1 = NULL;
	string			PartNo			= NULL;
	string			docClass			= NULL;
	string			docClass1			= NULL;
	string			docClass2			= NULL;
	string			ProDocuments		= NULL;
	string			sRelativePath		= NULL;
	string			sAppOwn		= NULL;
	string			sAppOwnDup		= NULL;
	string			sDisName		= NULL;
	string			sDisNameDup		= NULL;
	string			sBusItmDisName		= NULL;
	string			sBusItmDisName1		= NULL;
	string			sBusItmDisNameDup		= NULL;
	string			sBusItmDisName1Dup		= NULL;
	string			sRelativePathDup		= NULL;
	string			sLifeCycleSt		= NULL;
	string			sLifeCycleStDup		= NULL;
	string			sDisNm		= NULL;
	string			sDisNmDup	= NULL;
	string			sSeq		= NULL;
	string			sRev		= NULL;
	string			sLifCylSt		= NULL;
	string			sDrwInd		= NULL;
	string			sDrwIndDup		= NULL;
	SetOfObjects	PartSO		= NULL;
	int noOfDocs =0;
	int noOfDocs1 =0;
	int noOfDocs2 =0;
	int nparts =0;
	int countDepDi =0;
	ObjectPtr		DocOPtr				= NULL;
	ObjectPtr		DocOPtr1			= NULL;
	ObjectPtr		DocOPtr2			= NULL;
	ObjectPtr		InfoPtr			= NULL;


	string			t5Coated			= NULL;
	string			t5CoatedDup				= NULL;	

	string			t5ClSrl			= NULL;
	string			t5ClSrlDup				= NULL;

	string			t5VehClass			= NULL;
	string			t5VehClassDup				= NULL; 

	string			t5SchmPlant			= NULL;
	string			t5SchmPlantDup				= NULL; 

	string			t5SchmCompPlatForm			= NULL;
	string			t5SchmCompPlatFormDup				= NULL;

	string			creationdate			= NULL;
	string			creationdateDup				= NULL;

	string result;

	int p=0;
	int TabSize=0;
	string			InternalSchm			= NULL;
	string			PartCatCode			= NULL;
	string   Srl   =   NULL;
	string category = NULL;
	string ColorSerial	=NULL;
	string             FileName = NULL;
	FileName=nlsStrAlloc(1000);

	string             FileName1 = NULL;
	FileName1=nlsStrAlloc(1000);
	
	string             FileName2 = NULL;
	FileName2=nlsStrAlloc(1000);
	SetOfObjects    filestr				= NULL;
	string			PDFFileName			= NULL;


		char c = "/"; 
	    char d = "_";


	//PROE

	PDFReportFileName		=	nlsStrAlloc(300);
	PDFReportFileNameDup	=	nlsStrAlloc(300);
	OwnerDup				=	nlsStrAlloc(100);
	ProDocuments			=	nlsStrAlloc(200);
	//char fileRead[500];	

				/*			if ((dstat = oiSqlCreateSelect(&Sql_ptr)) ||
					//(dstat = oiSqlWhereBegParen(Sql_ptr)) ||
					(dstat = oiSqlWhereEQ(Sql_ptr,"PartNumber",PartNo)) ||
					//(dstat = oiSqlWhereAND(Sql_ptr))||
					//(dstat = oiSqlWhereEQ(Sql_ptr,"Superseded","-")) ||
					//(dstat = oiSqlWhereEndParen(Sql_ptr)) ||
					(dstat = QueryWhere("Part",Sql_ptr,&PartSO,mfail)) ) goto CLEANUP; 

					printf("\n After setting all DBScopes....PartSO objects:%d",setSize(PartSO));fflush(stdout);
*/

					//	Report=fopen("/user/omfprod/devgroups/Ashish_w/Report.txt","w");
		// www

	//string			InpFile			= NULL;
//	PDFFileName=argv[1];
//	printf("\n Arg1:[%s]",PDFFileName);


//				printf(" \nColor Scheme Name = %s \n ",PDFFileName);
//				www
//			if (dstat = oiSqlCreateSelect(&sqlPtr));	
//			t5CheckDstat(oiSqlWhereEQ(sqlPtr, "Nomenclature",PDFFileName));	
//			t5CheckDstat(oiSqlWhereAND(sqlPtr));
//	//		t5CheckDstat(oiSqlWhereEQ(sqlPtr, "creationdate","2020/01/01-01:07:00:937"));
//			t5CheckDstat(oiSqlWhereAND(sqlPtr));
//			t5CheckDstat(oiSqlWhereLike(sqlPtr, "OwnerName","%Release Vault"));
//			if(dstat = QueryDbObject("t5ClSchm", sqlPtr, 0, TRUE, SC_SCOPE_OF_SESSION, &PartSO, mfail)) goto CLEANUP;

				if(dstat = oiSqlCreateSelect(&sqlPtr)) goto EXIT ;                          
				if(dstat = oiSqlWhereBegParen(sqlPtr)) goto EXIT ;                 
	//			if(dstat = oiSqlWhereEQ(sqlPtr,"Nomenclature",PDFFileName)) goto EXIT ;
	//			if(dstat = oiSqlWhereAND(sqlPtr)) goto EXIT;
				if(dstat = oiSqlWhereEQ(sqlPtr,"t5SchmPlant","X451")) goto EXIT ;
				if(dstat = oiSqlWhereAND(sqlPtr)) goto EXIT;
				if(dstat = oiSqlWhereGE(sqlPtr,CreationDateAttr,"2020/01/01")) goto EXIT ;	
				if(dstat = oiSqlWhereAND(sqlPtr)) goto EXIT;
				if(dstat = oiSqlWhereEQ(sqlPtr,"OwnerName","Release Vault")) goto EXIT;	
				if(dstat = oiSqlWhereEndParen(sqlPtr)) goto EXIT ; 
				if(dstat = QueryWhere("t5ClSchm", sqlPtr, &PartSO, mfail)) goto CLEANUP;
				printf("setSize(PartSO) -----------> %d",setSize(PartSO));
				
					if(setSize(PartSO)>0) 
					{
					printf(" \nTotal Color Scheme  = %d \n ",setSize(PartSO));
					for(nparts = 0; nparts<setSize(PartSO); nparts++)						
						{			
						nullPtr=setGet(PartSO,nparts);
						
						if (dstat = objGetAttribute(nullPtr,NomenclatureAttr,&sPrtNum)) goto CLEANUP;
						if(sPrtNum)sPrtNumDup = nlsStrDup(sPrtNum);
						clrscmname=strssra(sPrtNumDup, "/", "-");//replace all '/' in description by '-'

						nlsStrCpy(FileName1,"/user/omfprod/devgroups/Ashish_w/color_scheme_details/");
						nlsStrCat(FileName1,"COLOR_scheme_details_");
						nlsStrCat(FileName1,clrscmname);
						nlsStrCat(FileName1,".txt");


					Report=fopen(FileName1,"a+");
						fprintf(Report,"%s^",sPrtNum);

					   if (dstat = objGetAttribute(nullPtr,RevisionAttr,&sRev)) goto CLEANUP;
						if(sRev)sRevDup = nlsStrDup(sRev);
						fprintf(Report,"%s^",sRevDup);

						if (dstat = objGetAttribute(nullPtr,SequenceAttr,&sSeq)) goto CLEANUP;
						if(sSeq)sSeqDup = nlsStrDup(sSeq);
						fprintf(Report,"%s^",sSeqDup);			

						if (dstat = objGetAttribute(nullPtr,t5ClSchmDescAttr,&sPrtDesc)) goto CLEANUP;
						if(sPrtDesc)sPrtDescDup = nlsStrDup(sPrtDesc);
						fprintf(Report," %s^",sPrtDescDup);
						
						if (dstat = objGetAttribute(nullPtr,t5CoatedAttr,&t5Coated)) goto CLEANUP;
						if(t5Coated)t5CoatedDup = nlsStrDup(t5Coated);
						fprintf(Report,"%s^",t5CoatedDup);

						if (dstat = objGetAttribute(nullPtr,t5ClSrlAttr,&t5ClSrl)) goto CLEANUP;
						if(t5ClSrl)t5ClSrlDup = nlsStrDup(t5ClSrl);
						fprintf(Report,"%s^",t5ClSrlDup);

						if (dstat = objGetAttribute(nullPtr,t5VehClassAttr,&t5VehClass)) goto CLEANUP;
						if(t5VehClass)t5VehClassDup = nlsStrDup(t5VehClass);
						fprintf(Report,"%s^",t5VehClassDup);

						if (dstat = objGetAttribute(nullPtr,t5SchmPlantAttr,&t5SchmPlant)) goto CLEANUP;
						if(t5SchmPlant)t5SchmPlantDup = nlsStrDup(t5SchmPlant);
						fprintf(Report,"%s^",t5SchmPlantDup);

						if (dstat = objGetAttribute(nullPtr,t5SchmCompPlatFormAttr,&t5SchmCompPlatForm)) goto CLEANUP;
						if(t5SchmCompPlatForm)t5SchmCompPlatFormDup = nlsStrDup(t5SchmCompPlatForm);
						fprintf(Report,"%s^",t5SchmCompPlatFormDup);
						
						// Date
						if (dstat = objGetAttribute(nullPtr,CreationDateAttr,&creationdate)) goto CLEANUP;
						if(creationdate)creationdateDup = nlsStrDup(creationdate);
						fprintf(Report,"%s^\n",creationdateDup);
						
					nlsStrCpy(FileName,"/user/omfprod/devgroups/Ashish_w/color_scheme_details/");
					nlsStrCat(FileName,"COLOR_DATA_OF_");
					nlsStrCat(FileName,clrscmname);
					nlsStrCat(FileName,"__");
					nlsStrCat(FileName,sRevDup);
					nlsStrCat(FileName,".txt");
		
					if(dstat =objGetTableSize(nullPtr,t5SchFullTabAttr,&TabSize)) goto EXIT;
					printf(" \n TabSize %d \n ",TabSize);fflush(stdout);
					
					Report1=fopen(FileName,"w");
					for (p=0;p<TabSize;p++)
							{
								if(dstat = objGetTableAttribute(nullPtr,t5SchFullTabAttr,p,t5SrlAttr,&Srl)) goto CLEANUP;

								if(dstat = objGetTableAttribute(nullPtr,t5SchFullTabAttr,p,t5SchmCategoryAttr,&category)) goto CLEANUP;

								if(dstat = objGetTableAttribute(nullPtr,t5SchFullTabAttr,p,t5PrtCatCodeAttr,&PartCatCode)) goto EXIT;
									
								if(dstat = objGetTableAttribute(nullPtr,t5SchFullTabAttr,p,t5InternalSchmAttr,&InternalSchm)) goto EXIT; 

								if(dstat = objGetTableAttribute(nullPtr,t5SchFullTabAttr,p,t5ClSrlAttr,&ColorSerial)) goto EXIT;
								if((nlsStrLen(PartCatCode)>0)&&(nlsStrLen(InternalSchm)>0)&&(nlsStrLen(ColorSerial)>0))
								{
								fprintf(Report1,"%s^%s^%s^%s^%s^\n",Srl,category,PartCatCode,InternalSchm,ColorSerial);
								}

							}

						fclose(Report1);
						fclose(Report);

						 if(dstat=ExpandObject4(t5ClCfgIClass,nullPtr,"t5ClShAppForCfgI",&SCHHasVCObjs,&mfail)) goto EXIT;
						 printf("\n SetSize SCHHasVCObjs: %d \n ",setSize(SCHHasVCObjs));fflush(stdout);
			
			if (setSize(SCHHasVCObjs)>0)
			{
					nlsStrCpy(FileName2,"/user/omfprod/devgroups/Ashish_w/color_scheme_details/");
					nlsStrCat(FileName2,clrscmname);
					nlsStrCat(FileName2,"_Has_applicable_VC");
				//  nlsStrCat(FileName2,"__");
				//	nlsStrCat(FileName2,sRevDup);
					nlsStrCat(FileName2,".txt");

					Report2=fopen(FileName2,"w");
					for (i=0;i<setSize(SCHHasVCObjs);i++)
				{
					nullPtr1=setGet(SCHHasVCObjs,i);
					if (dstat = objGetAttribute(nullPtr1,PartNumberAttr,&sPrtNum1)) goto CLEANUP;
						if(sPrtNum1)sPrtNumDup1 = nlsStrDup(sPrtNum1);
						 fprintf(Report2,"%s*^\n",sPrtNumDup1);
				}
				fclose(Report2);
			}
						 }
					}
					if(sqlPtr) oiSqlDispose(sqlPtr);	sqlPtr = NULL;
					if(PartSO)  objDisposeAll(PartSO);  PartSO = NULL;
					if(sPrtNum)sPrtNum=NULL;
					if(sRevDup)sRevDup=NULL;
					if(sSeqDup)sSeqDup=NULL;
				//	if(Sql_ptr) oiSqlDispose(Sql_ptr); Sql_ptr = NULL;
					//www
		// }
					
CLEANUP :
		t5FreeSetOfObjects(indObjs);
		t5FreeSetOfObjects(FIRREQReportSo);
EXIT:
		if (dstat != OKAY) dlow_return_trace(mod_name, dstat);
	     return (dstat);
		 


/*
	// www
					
	
			if (dstat = oiSqlCreateSelect(&sqlPtr));
		//	t5CheckDstat(oiSqlWhereEQ(sqlPtr, "Nomenclature","CLRSCM-CAR/17/3520"));	
		//	t5CheckDstat(oiSqlWhereEQ(sqlPtr, "Nomenclature","CLRSCM-CAR/18/3641"));	
			t5CheckDstat(oiSqlWhereEQ(sqlPtr, "Nomenclature","CLRSCM-CAR/18/3680"));	
			t5CheckDstat(oiSqlWhereAND(sqlPtr));

			t5CheckDstat(oiSqlWhereLike(sqlPtr, "OwnerName","%Release Vault"));
			if(dstat = QueryDbObject("t5ClSchm", sqlPtr, 0, TRUE, SC_SCOPE_OF_SESSION, &PartSO, mfail)) goto CLEANUP;
					if(setSize(PartSO)>0)
					{
					printf(" \nTotal Color Scheme  = %d \n ",setSize(PartSO));
					for(nparts = 0; nparts<setSize(PartSO); nparts++)						
						{			
						nullPtr=setGet(PartSO,nparts);
						
						if (dstat = objGetAttribute(nullPtr,NomenclatureAttr,&sPrtNum)) goto CLEANUP;
						if(sPrtNum)sPrtNumDup = nlsStrDup(sPrtNum);
						clrscmname=strssra(sPrtNumDup, "/", "-");//replace all '/' in description by '-'

						nlsStrCpy(FileName1,"/user/omfprod/devgroups/Ashish_w/color_scheme_details/");
						nlsStrCat(FileName1,"COLOR_scheme_details_");
						nlsStrCat(FileName1,clrscmname);
						nlsStrCat(FileName1,".txt");


					Report=fopen(FileName1,"a+");
						fprintf(Report,"%s^",sPrtNum);

					   if (dstat = objGetAttribute(nullPtr,RevisionAttr,&sRev)) goto CLEANUP;
						if(sRev)sRevDup = nlsStrDup(sRev);
						fprintf(Report,"%s^",sRevDup);

						if (dstat = objGetAttribute(nullPtr,SequenceAttr,&sSeq)) goto CLEANUP;
						if(sSeq)sSeqDup = nlsStrDup(sSeq);
						fprintf(Report,"%s^",sSeqDup);			

						if (dstat = objGetAttribute(nullPtr,t5ClSchmDescAttr,&sPrtDesc)) goto CLEANUP;
						if(sPrtDesc)sPrtDescDup = nlsStrDup(sPrtDesc);
						fprintf(Report," %s^",sPrtDescDup);
						
						if (dstat = objGetAttribute(nullPtr,t5CoatedAttr,&t5Coated)) goto CLEANUP;
						if(t5Coated)t5CoatedDup = nlsStrDup(t5Coated);
						fprintf(Report,"%s^",t5CoatedDup);

						if (dstat = objGetAttribute(nullPtr,t5ClSrlAttr,&t5ClSrl)) goto CLEANUP;
						if(t5ClSrl)t5ClSrlDup = nlsStrDup(t5ClSrl);
						fprintf(Report,"%s^",t5ClSrlDup);

						if (dstat = objGetAttribute(nullPtr,t5VehClassAttr,&t5VehClass)) goto CLEANUP;
						if(t5VehClass)t5VehClassDup = nlsStrDup(t5VehClass);
						fprintf(Report,"%s^",t5VehClassDup);

						if (dstat = objGetAttribute(nullPtr,t5SchmPlantAttr,&t5SchmPlant)) goto CLEANUP;
						if(t5SchmPlant)t5SchmPlantDup = nlsStrDup(t5SchmPlant);
						fprintf(Report,"%s^",t5SchmPlantDup);

						if (dstat = objGetAttribute(nullPtr,t5SchmCompPlatFormAttr,&t5SchmCompPlatForm)) goto CLEANUP;
						if(t5SchmCompPlatForm)t5SchmCompPlatFormDup = nlsStrDup(t5SchmCompPlatForm);
						fprintf(Report,"%s^",t5SchmCompPlatFormDup);
						
						// Date
						if (dstat = objGetAttribute(nullPtr,CreationDateAttr,&creationdate)) goto CLEANUP;
						if(creationdate)creationdateDup = nlsStrDup(creationdate);
						fprintf(Report,"%s^\n",creationdateDup);
						
					nlsStrCpy(FileName,"/user/omfprod/devgroups/Ashish_w/color_scheme_details/");
					nlsStrCat(FileName,"COLOR_DATA_OF_");
					nlsStrCat(FileName,clrscmname);
					nlsStrCat(FileName,"__");
					nlsStrCat(FileName,sRevDup);
					nlsStrCat(FileName,".txt");
		
					if(dstat =objGetTableSize(nullPtr,t5SchFullTabAttr,&TabSize)) goto EXIT;
					printf(" \n TabSize %d \n ",TabSize);fflush(stdout);
					
					Report1=fopen(FileName,"w");
					for (p=0;p<TabSize;p++)
							{
								if(dstat = objGetTableAttribute(nullPtr,t5SchFullTabAttr,p,t5SrlAttr,&Srl)) goto CLEANUP;

								if(dstat = objGetTableAttribute(nullPtr,t5SchFullTabAttr,p,t5SchmCategoryAttr,&category)) goto CLEANUP;

								if(dstat = objGetTableAttribute(nullPtr,t5SchFullTabAttr,p,t5PrtCatCodeAttr,&PartCatCode)) goto EXIT;
									
								if(dstat = objGetTableAttribute(nullPtr,t5SchFullTabAttr,p,t5InternalSchmAttr,&InternalSchm)) goto EXIT; 

								if(dstat = objGetTableAttribute(nullPtr,t5SchFullTabAttr,p,t5ClSrlAttr,&ColorSerial)) goto EXIT;
								if((nlsStrLen(PartCatCode)>0)&&(nlsStrLen(InternalSchm)>0)&&(nlsStrLen(ColorSerial)>0))
								{
								fprintf(Report1,"%s^%s^%s^%s^%s^\n",Srl,category,PartCatCode,InternalSchm,ColorSerial);
								}

							}

						fclose(Report1);
						fclose(Report);

						 if(dstat=ExpandObject4(t5ClCfgIClass,nullPtr,"t5ClShAppForCfgI",&SCHHasVCObjs,&mfail)) goto EXIT;
						 printf("\n SetSize SCHHasVCObjs: %d \n ",setSize(SCHHasVCObjs));fflush(stdout);
			
			if (setSize(SCHHasVCObjs)>0)
			{
					nlsStrCpy(FileName2,"/user/omfprod/devgroups/Ashish_w/color_scheme_details/");
					nlsStrCat(FileName2,clrscmname);
					nlsStrCat(FileName2,"_Has_applicable_VC");
				//  nlsStrCat(FileName2,"__");
				//	nlsStrCat(FileName2,sRevDup);
					nlsStrCat(FileName2,".txt");

					Report2=fopen(FileName2,"w");
					for (i=0;i<setSize(SCHHasVCObjs);i++)
				{
					nullPtr1=setGet(SCHHasVCObjs,i);
					if (dstat = objGetAttribute(nullPtr1,PartNumberAttr,&sPrtNum1)) goto CLEANUP;
						if(sPrtNum1)sPrtNumDup1 = nlsStrDup(sPrtNum1);
						 fprintf(Report2,"%s*^\n",sPrtNumDup1);
				}
				fclose(Report2);
			}
						 }
					}
					if(sqlPtr) oiSqlDispose(sqlPtr);
					if(sPrtNum)sPrtNum=NULL;
					if(sRevDup)sRevDup=NULL;
					if(sSeqDup)sSeqDup=NULL;
					
CLEANUP :
		t5FreeSetOfObjects(indObjs);
		t5FreeSetOfObjects(FIRREQReportSo);
EXIT:
		if (dstat != OKAY) dlow_return_trace(mod_name, dstat);
	     return (dstat);
*/
}