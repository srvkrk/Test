/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2023  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: ModuleInfoReport.c
* Description	: This Utility Mainly Used For AutoLogin in Teamcenter
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change
* 28/04/2023   	   Alokesh Ghosh	          		Module Info Report

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>

#define MAX_LINE_LEN 10024
#define IFERR_ABORT(X)  (report_error( __FILE__, __LINE__, #X, X, TRUE))
#define IFERR_REPORT(X) (report_error( __FILE__, __LINE__, #X, X, FALSE))
FILE *Report = NULL;
int ctr=0;

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

static int report_error(char *file, int line, char *call, int status,
    logical exit_on_error)
{
    if (status != ITK_ok)
    {
        int
            n_errors = 0;
        const int
            *severities = NULL,
            *statuses = NULL;
        const char
            **messages;

        EMH_ask_errors(&n_errors, &severities, &statuses, &messages);
        if (n_errors > 0)
        {
            ECHO("\n%s\n", messages[n_errors-1]);
            EMH_clear_errors();
        }
        else
        {
            char *error_message_string;
            EMH_get_error_string (NULLTAG, status, &error_message_string);
            ECHO("\n%s\n", error_message_string);
        }

        ECHO("error %d at line %d in %s\n", status, line, file);
        ECHO("%s\n", call);
        if (exit_on_error)
        {
            ECHO("%s", "Exiting program!\n");
            exit (status);
        }
    }
    return status;
}


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;
    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

// Function to check if a character is printable
int isPrintable(char ch) {
    return ch >= 32 && ch <= 126;
}

// Function to remove non-ASCII, non-printable, and special characters from string
void removeNonAsciiChars(char *str) {
    int i = 0;
    char ch;
    while ((ch = str[i]) != '\0') {
        if (!isPrintable(ch))
        {
            str[i] = ' ';
        }
        i++;
    }
}

int ITK_user_main(int argc, char* argv[])
{
    char* cError = NULL;
	int ifail = ITK_ok;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	if(ITK_auto_login() == ITK_ok)	
	{
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		char Data[100] = "";

		Report=fopen("/tmp/ModuleInfReport.xml","w");
		if (Report == NULL)
		{
			printf("ERROR: XML Cannot open File\n");
			return -1;
		}
		else
		{
			printf("XML File opened successfully.\n");
		}

		strftime(Data,100,"%d-%m-%Y %H:%M:%S",&when);
		write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
		write2xml(Report,"\n<PLMXML date=\"");
		write2xml(Report,Data);
		write2xml(Report,"\" >\n");

		tag_t itemrev = NULLTAG;
		int  rows = 0, i = 0;
		tag_t* itemobj_results = NULLTAG;
		int FieldCount = 2;
		tag_t ItemObjs = NULLTAG;
		char *FieldList[2]  = {"Part Type","Type"};
		char **FieldVaule = (char **) MEM_alloc(50 * sizeof(char *));

		if(QRY_find("Query_for_Module_Info_Report", &ItemObjs));
		if (ItemObjs)
		{
			printf("\nFound Query_for_Module_Info_Report\n");fflush(stdout);
		}
		else
		{
			printf("\n-----------Not Found Query_for_Module_Info_Report\n");fflush(stdout);
		}

		FieldVaule[0] = "M";
		FieldVaule[1] = "Design Revision";
		printf("Before Query Execute"); fflush(stdout);
		if (QRY_execute(ItemObjs, FieldCount, FieldList, FieldVaule, &rows, &itemobj_results) != ITK_ok) PrintErrorStack();
		if (rows != 0)
		{
			printf("Total Module : %d",rows); fflush(stdout);
			for(i=0;i<rows;i++)
			{
				itemrev=itemobj_results[i];

				char* item_id = NULL;
				char* item_revision_id = NULL;
				char* t5_DesignGrp = NULL;
				char* current_desc = NULL;
				char* t5_SimVal = NULL;
				char* t5_VerCreator = NULL;
				char* t5_PartStatus = NULL;
				char* t5_ProjectCode = NULL;
				char* t5_Platform = NULL;
				char* t5_AggregateGroup = NULL;
				char* t5_Aggregate = NULL;
				char* t5_Module = NULL;
				char* t5_ModuleAddress = NULL;
				char* t5_Module_Group = NULL;
				char* t5_ModuleName = NULL;
				char* t5_ModuleType = NULL;
				char* t5_PartType = NULL;
				char* t5_DrawingInd = NULL;
				char* t5_PunMakeBuyIndicator = NULL;
				char* t5_JsrMakeBuyIndicator = NULL;
				char* t5_LkoMakeBuyIndicator = NULL;
				char* t5_PnrMakeBuyIndicator = NULL;
				char* t5_AhdMakeBuyIndicator = NULL;
				char* t5_CarMakeBuyIndicator = NULL;
				char* t5_PunPCBUMakeBuyIndicator = NULL;
				char* t5_DwdMakeBuyIndicator = NULL;
				char* creation_date = NULL;
				char* last_mod_date = NULL;
				char* owning_user = NULL;
				char* release_status_list = NULL;

				ITK_CALL(AOM_ask_value_string(itemrev,"item_id",&item_id));
				ITK_CALL(AOM_ask_value_string(itemrev,"item_revision_id",&item_revision_id));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_DesignGrp",&t5_DesignGrp));
				ITK_CALL(AOM_ask_value_string(itemrev,"current_desc",&current_desc));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_SimVal",&t5_SimVal));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_VerCreator",&t5_VerCreator));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_PartStatus",&t5_PartStatus));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_ProjectCode",&t5_ProjectCode));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_Platform",&t5_Platform));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_AggregateGroup",&t5_AggregateGroup));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_Aggregate",&t5_Aggregate));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_Module",&t5_Module));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_ModuleAddress",&t5_ModuleAddress));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_Module_Group",&t5_Module_Group));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_ModuleName",&t5_ModuleName));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_ModuleType",&t5_ModuleType));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_PartType",&t5_PartType));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_DrawingInd",&t5_DrawingInd));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_PunMakeBuyIndicator",&t5_PunMakeBuyIndicator));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_JsrMakeBuyIndicator",&t5_JsrMakeBuyIndicator));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_LkoMakeBuyIndicator",&t5_LkoMakeBuyIndicator));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_PnrMakeBuyIndicator",&t5_PnrMakeBuyIndicator));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_AhdMakeBuyIndicator",&t5_AhdMakeBuyIndicator));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_CarMakeBuyIndicator",&t5_CarMakeBuyIndicator));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_PunPCBUMakeBuyIndicator",&t5_PunPCBUMakeBuyIndicator));
				ITK_CALL(AOM_ask_value_string(itemrev,"t5_DwdMakeBuyIndicator",&t5_DwdMakeBuyIndicator));

				ITK_CALL(AOM_UIF_ask_value (itemrev, "creation_date", &creation_date));
				ITK_CALL(AOM_UIF_ask_value (itemrev, "last_mod_date", &last_mod_date));
				ITK_CALL(AOM_UIF_ask_value (itemrev, "owning_user", &owning_user));
				ITK_CALL(AOM_UIF_ask_value (itemrev, "release_status_list", &release_status_list));
				//STRNG_replace_str(release_status_list,","," ",&release_status_list);

				STRNG_replace_str(current_desc,"\\n"," ",&current_desc);
				STRNG_replace_str(t5_SimVal,"\\n"," ",&t5_SimVal);
				STRNG_replace_str(t5_Platform,"\\n"," ",&t5_Platform);
				STRNG_replace_str(t5_AggregateGroup,"\\n"," ",&t5_AggregateGroup);
				STRNG_replace_str(t5_Aggregate,"\\n"," ",&t5_Aggregate);
				STRNG_replace_str(t5_Module,"\\n"," ",&t5_Module);
				STRNG_replace_str(t5_ModuleAddress,"\\n"," ",&t5_ModuleAddress);
				STRNG_replace_str(t5_Module_Group,"\\n"," ",&t5_Module_Group);
				STRNG_replace_str(t5_ModuleName,"\\n"," ",&t5_ModuleName);
				STRNG_replace_str(t5_ModuleType,"\\n"," ",&t5_ModuleType);

				STRNG_replace_str(current_desc,"<","(",&current_desc);
				STRNG_replace_str(t5_SimVal,"<","(",&t5_SimVal);
				STRNG_replace_str(t5_Platform,"<","(",&t5_Platform);
				STRNG_replace_str(t5_AggregateGroup,"<","(",&t5_AggregateGroup);
				STRNG_replace_str(t5_Aggregate,"<","(",&t5_Aggregate);
				STRNG_replace_str(t5_Module,"<","(",&t5_Module);
				STRNG_replace_str(t5_ModuleAddress,"<","(",&t5_ModuleAddress);
				STRNG_replace_str(t5_Module_Group,"<","(",&t5_Module_Group);
				STRNG_replace_str(t5_ModuleName,"<","(",&t5_ModuleName);
				STRNG_replace_str(t5_ModuleType,"<","(",&t5_ModuleType);

				STRNG_replace_str(current_desc,">",")",&current_desc);
				STRNG_replace_str(t5_SimVal,">",")",&t5_SimVal);
				STRNG_replace_str(t5_Platform,">",")",&t5_Platform);
				STRNG_replace_str(t5_AggregateGroup,">",")",&t5_AggregateGroup);
				STRNG_replace_str(t5_Aggregate,">",")",&t5_Aggregate);
				STRNG_replace_str(t5_Module,">",")",&t5_Module);
				STRNG_replace_str(t5_ModuleAddress,">",")",&t5_ModuleAddress);
				STRNG_replace_str(t5_Module_Group,">",")",&t5_Module_Group);
				STRNG_replace_str(t5_ModuleName,">",")",&t5_ModuleName);
				STRNG_replace_str(t5_ModuleType,">",")",&t5_ModuleType);

				removeNonAsciiChars(current_desc);
				removeNonAsciiChars(t5_SimVal);
				removeNonAsciiChars(t5_Platform);
				removeNonAsciiChars(t5_AggregateGroup);
				removeNonAsciiChars(t5_Aggregate);
				removeNonAsciiChars(t5_Module);
				removeNonAsciiChars(t5_ModuleAddress);
				removeNonAsciiChars(t5_Module_Group);
				removeNonAsciiChars(t5_ModuleName);
				removeNonAsciiChars(t5_ModuleType);

				char *Module_Group = NULL;
				char *AggregateGroup = NULL;
				char *current_desc2 = NULL;
				char *t5_SimVal2 = NULL;
				char *t5_Aggregate2 = NULL;
				char *t5_ModuleName2 = NULL;
				char *t5_ModuleType2 = NULL;
				char *t5_Module2 = NULL;
				if(t5_Module_Group != NULL) STRNG_replace_str(t5_Module_Group,"&","&amp;",&Module_Group);
				if(t5_AggregateGroup != NULL) STRNG_replace_str(t5_AggregateGroup,"&","&amp;",&AggregateGroup);
				if(current_desc != NULL) STRNG_replace_str(current_desc,"&","&amp;",&current_desc2);
				if(t5_SimVal != NULL) STRNG_replace_str(t5_SimVal,"&","&amp;",&t5_SimVal2);
				if(t5_Aggregate != NULL) STRNG_replace_str(t5_Aggregate,"&","&amp;",&t5_Aggregate2);
				if(t5_ModuleName != NULL) STRNG_replace_str(t5_ModuleName,"&","&amp;",&t5_ModuleName2);
				if(t5_ModuleType != NULL) STRNG_replace_str(t5_ModuleType,"&","&amp;",&t5_ModuleType2);
				if(t5_Module != NULL) STRNG_replace_str(t5_Module,"&","&amp;",&t5_Module2);

				//Organization_ID
				char *Organization_ID=(char *) MEM_alloc(200);
				char *owning_group = NULL;
				tc_strcpy(Organization_ID,"");
				if (tc_strcmp(owning_user,"loader (loader)") == 0)
				{
					tc_strcpy(Organization_ID,"ERC");
				}
				else if(tc_strcmp(owning_user,"aplloader (aplloader)") == 0)
				{
					tc_strcpy(Organization_ID,"APL");
				}
				else
				{
					ITK_CALL(AOM_UIF_ask_value (itemrev, "owning_group", &owning_group));
					if(owning_group != NULL)
					{
						if(tc_strstr(owning_group, "ERC") != NULL)
						{
							tc_strcpy(Organization_ID,"ERC");
						}
						else
						{
							tc_strcpy(Organization_ID,"APL");
						}
					}
				}

				char *slNo=(char *) MEM_alloc(200);
				sprintf(slNo,"%d",(i+1));

				write2xml(Report,"<DesignRevision>\n");
				write2xml(Report,"<field key =\"slNo\">");
				write2xml(Report,slNo);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"item_id\">");
				write2xml(Report,item_id);
				write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"item_revision_id\">"); write2xml(Report,item_revision_id); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_DesignGrp\">"); if(t5_DesignGrp != NULL) write2xml(Report,t5_DesignGrp); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"current_desc\">"); if(current_desc2 != NULL) write2xml(Report,current_desc2); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_SimVal\">"); if(t5_SimVal2 != NULL) write2xml(Report,t5_SimVal2); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"owning_user\">"); if(owning_user != NULL) write2xml(Report,owning_user); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_VerCreator\">"); if(t5_VerCreator != NULL) write2xml(Report,t5_VerCreator); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"creation_date\">"); if(creation_date != NULL) write2xml(Report,creation_date); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"last_mod_date\">"); if(last_mod_date != NULL) write2xml(Report,last_mod_date); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"Organization_ID\">"); if(Organization_ID != NULL) write2xml(Report,Organization_ID); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"release_status_list\">"); if(release_status_list != NULL) write2xml(Report,release_status_list); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_PartStatus\">"); if(t5_PartStatus != NULL) write2xml(Report,t5_PartStatus); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_ProjectCode\">"); if(t5_ProjectCode != NULL) write2xml(Report,t5_ProjectCode); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_Platform\">"); if(t5_Platform != NULL) write2xml(Report,t5_Platform); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_AggregateGroup\">"); if(AggregateGroup != NULL) write2xml(Report,AggregateGroup); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_Aggregate\">"); if(t5_Aggregate2 != NULL) write2xml(Report,t5_Aggregate2); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_Module\">"); if(t5_Module2 != NULL) write2xml(Report,t5_Module2); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_ModuleAddress\">"); if(t5_ModuleAddress != NULL) write2xml(Report,t5_ModuleAddress); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_Module_Group\">"); if(Module_Group != NULL) write2xml(Report,Module_Group); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_ModuleName\">"); if(t5_ModuleName2 != NULL) write2xml(Report,t5_ModuleName2); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_ModuleType\">"); if(t5_ModuleType2 != NULL) write2xml(Report,t5_ModuleType2); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_PartType\">"); if(t5_PartType != NULL) write2xml(Report,t5_PartType); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_DrawingInd\">"); if(t5_DrawingInd != NULL) write2xml(Report,t5_DrawingInd); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_PunMakeBuyIndicator\">"); if(t5_PunMakeBuyIndicator != NULL) write2xml(Report,t5_PunMakeBuyIndicator); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_JsrMakeBuyIndicator\">"); if(t5_JsrMakeBuyIndicator != NULL) write2xml(Report,t5_JsrMakeBuyIndicator); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_LkoMakeBuyIndicator\">"); if(t5_LkoMakeBuyIndicator != NULL) write2xml(Report,t5_LkoMakeBuyIndicator); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_PnrMakeBuyIndicator\">"); if(t5_PnrMakeBuyIndicator != NULL) write2xml(Report,t5_PnrMakeBuyIndicator); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_AhdMakeBuyIndicator\">"); if(t5_AhdMakeBuyIndicator != NULL) write2xml(Report,t5_AhdMakeBuyIndicator); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_CarMakeBuyIndicator\">"); if(t5_CarMakeBuyIndicator != NULL) write2xml(Report,t5_CarMakeBuyIndicator); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_PunPCBUMakeBuyIndicator\">"); if(t5_PunPCBUMakeBuyIndicator != NULL) write2xml(Report,t5_PunPCBUMakeBuyIndicator); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"<field key =\"t5_DwdMakeBuyIndicator\">"); if(t5_DwdMakeBuyIndicator != NULL) write2xml(Report,t5_DwdMakeBuyIndicator); else write2xml(Report,""); write2xml(Report,"</field>\n");
				write2xml(Report,"</DesignRevision>\n");
			}
		}
		write2xml(Report,"</PLMXML>\n");
		fclose(Report);

		ifail = ITK_exit_module(TRUE);
		if (ifail == ITK_ok)
		{
			printf("\nTeamcenter Logout Success...");fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(ifail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
	}
	return ITK_ok;
}


