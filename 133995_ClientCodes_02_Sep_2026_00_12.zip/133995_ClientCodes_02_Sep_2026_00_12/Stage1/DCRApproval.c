#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <ae/dataset.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/iman.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <epm/epm.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#define ITK_err 910001
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
		
    }
	return return_code;
}

void printHelp()
{
	printf("\n-----------------------------------\n");
	printf("\t\tHELP\n");
	printf("\t\tdataset_CMI2_correct -u=<user> -p=<password> -g=<group> -inputfile=<File with Item>\n");
	printf("\n-----------------------------------\n");
}



int ITK_user_main(int argc, char* argv[])
{
	int specObjCount=0,primObjCount=0,revCount=0;
	int attachmentCount=0;
	int rvwSubTaskCnt=0;
	int i=0,j=0,k=0,PdfUpd=0,tskcount=0,m=0;
	int h=0, CMIPartFlag=0, CMIProd3ExistFlag=0, CMIPart3ExistFlag=0;
	int CMI2Prod1NmRefCnt=0, CMI2Prod2NmRefCnt=0, CMI2Part1NmRefCnt=0, CMI2Part2NmRefCnt=0;

	char* user=NULL;
	char* passwd=NULL;
	char* group=NULL;
	char* input=NULL;
	char* revId=NULL;
	char* itemId=NULL;
	char* datsName=NULL;
	char* object_type=NULL;
	char* objType=NULL;
	char* datsType=NULL;
	char* CMI2ProdName1=NULL;
	char* CMI2ProdName2=NULL;
	char* Item_RevSeq=NULL;
	char* Item_name=NULL;
	char* Item_Owner=NULL;

	char fLine[200];
	char tmlRevId[5];

	
	tag_t itemRev_t=NULLTAG;
	tag_t item_t=NULLTAG;
	tag_t specifications_t=NULLTAG, delspecification_t=NULLTAG,specifications_R=NULLTAG;
	tag_t *specObjs=NULLTAG;
	tag_t namedRef_t=NULLTAG;
	tag_t CMI2Prod1=NULLTAG, CMI2Prod2=NULLTAG, CMI2Part1=NULLTAG, CMI2Part2=NULLTAG;

	AE_reference_type_t reftype;
	
	char* DmlIdS= NULL;
	char* decs= NULL;
	char* mailid= NULL;

	ITK_CALL(ITK_initialize_text_services(ITK_BATCH_TEXT_MODE));

	user=ITK_ask_cli_argument("-u=");
	passwd=ITK_ask_cli_argument("-p=");
	group=ITK_ask_cli_argument("-g=");
	DmlIdS=ITK_ask_cli_argument("-i=");
	decs=ITK_ask_cli_argument("-j=");
	mailid=ITK_ask_cli_argument("-k=");

	char			*entry0						= "ID";
	char			*entry1						= "Drawing Indicator";

	
	char			*ID						= "544230000003";
	char			*DrwInd						= "D";

	tag_t			query_tag					= NULLTAG;
	
	char**  		entries						= (char**) MEM_alloc (sizeof(char*) * 2);
	char**  		values						= (char**) MEM_alloc (sizeof(char*) * 2);
	int				results						= 0;
	tag_t			*object_tag					= NULLTAG;
	tag_t			releaseDateId					= NULLTAG;
	tag_t			releaseStatusListId					= NULLTAG;
	date_t			from_date1;
	date_t			Actual_Rel_date;
	tag_t*    status_list=NULLTAG;
	tag_t    release_status=NULLTAG;
	tag_t    Usr_Tag=NULLTAG;
	tag_t    job_Tag=NULLTAG;
	tag_t    jobtype_Tag=NULLTAG;
	tag_t    dml_rev_tag=NULLTAG;
	tag_t    dml_tag=NULLTAG;
	tag_t*    Grp_Member=NULLTAG;
	tag_t*    subtask=NULLTAG;
	tag_t*    taskAttachments=NULLTAG;
	tag_t*    reviewSubTasks=NULLTAG;
	char   dRftSpectype_name[TCTYPE_name_size_c+1];

	char    *Milston_qry_entry[1]  = {"E-Mail Address"};
	char    **Milston_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));

	int  count=0;
	char *parent_name =NULL;
	char *WSO_Name = NULL;
	char* effectivityStrFinal= NULL;
	char* effectivityStr= NULL;
	char *taskTempLT = NULL;
	char *taskType = NULL;
	char *Assignee = NULL;
	char	*EIDLinfo1		=  NULL;
	tag_t rootTask			= NULLTAG;
	//EPM_state_e state;

	int     Milston_rsltCount    = 0;
	int     Milston_n_entry    = 1;
	tag_t	*MilstonCntrlObjectTag		= NULLTAG;
	tag_t	MilestoneqryTag		= NULLTAG;
	
	char*	 Milstoninfo1 = NULL;
	//char*	 Milstoninfo2 = NULL;
	
	

	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;

	const char 	user_1[SA_user_size_c+1]="uaprod";
	int num=0;
	char rejectComment[500];
	char ApproveComment[500];
	CR_signoff_decision_t apprDecision_e=CR_approve_decision;
	CR_signoff_decision_t rejectDecision_e=CR_reject_decision ;

	entries[0] = (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry0) + 10));
	values[0]  = (char*) MEM_alloc (sizeof(char) * (tc_strlen(input) + 10));
	effectivityStrFinal = ( char * ) MEM_alloc(30);

//	entries[0] = (char*) MEM_alloc (sizeof(char) * (tc_strlen(entry1) + 10));
//	values[0]  = (char*) MEM_alloc (sizeof(char) * (tc_strlen(DrwInd) + 10));

	tc_strcpy(entries[0], "");	tc_strcpy(entries[0], entry0);
	tc_strcpy(values[0], "");	tc_strcpy(values[0], input);
	
//	tc_strcpy(entries[0], "");	tc_strcpy(entries[0], entry1);
//	tc_strcpy(values[0], "");	tc_strcpy(values[0], DrwInd);



	if(TC_init_module(user,passwd,group)==ITK_ok)
	{

		if(QRY_find("PersonFromEmailID", &MilestoneqryTag));
	if (MilestoneqryTag)
	{
		printf("\n P1:Found Query MilestoneqryTag \n");fflush(stdout);
	}
	else
	{
		printf("\n P2:Not Found Query MilestoneqryTag \n");fflush(stdout);
	}

	Milston_qry_values2[0] = mailid;
	if(QRY_execute(MilestoneqryTag, Milston_n_entry, Milston_qry_entry, Milston_qry_values2, &Milston_rsltCount, &MilstonCntrlObjectTag));
	printf(" \n P3:DR_rsltCount :%d:", Milston_rsltCount); fflush(stdout);
	if(Milston_rsltCount > 0)
	{
		ITK_CALL (AOM_ask_value_string(MilstonCntrlObjectTag[0],"user_name",&Milstoninfo1)!=ITK_ok);
		printf("\n P4:Milstoninfo1 is : [%s]\n", Milstoninfo1);fflush(stdout);

	}
	
    tc_strcpy(rejectComment,"");
	tc_strcat(rejectComment,"Task rejected by ");
	tc_strcat(rejectComment,Milstoninfo1);
	tc_strcat(rejectComment," through email facility");

	  tc_strcpy(ApproveComment,"");
	tc_strcat(ApproveComment,"Task Approved by ");
	tc_strcat(ApproveComment,Milstoninfo1);
	tc_strcat(ApproveComment," through email facility");

		SA_find_user(user_1,&Usr_Tag);
		SA_find_groupmember_by_user(Usr_Tag,&num,&Grp_Member);
		printf("\n num of group member----><%d>\n",num);

		ITK_CALL(AOM_ask_value_string(Grp_Member[0],"object_name",&Item_name));
		printf("\n Group_name----><%s>\n",Item_name);

		ITEM_find_item( DmlIdS, &dml_tag );

		ITK_CALL(ITEM_find_revision(dml_tag,"NR",&dml_rev_tag)) ;

		if (dml_rev_tag  != NULLTAG)
		{
			printf("\n DmlIdS [%s] \n",DmlIdS);  fflush(stdout);
			int BomCompleteAddPartFlag=0;
			//ITK_CALL(AOM_lock(dml_rev_tag));
			//ITK_CALL(AOM_set_value_string(dml_rev_tag,"Requestor","ERC_Designers_Group/Functional_Head_Grp/Sourabh Singh (sks08539)"));
			// ITK_CALL(AOM_assign_tag(dml_rev_tag,"Requestor",Grp_Member[0]));	
			// ITK_CALL(AOM_save(dml_rev_tag));
			// ITK_CALL(AOM_refresh(dml_rev_tag , 0 ));
			// ITK_CALL(AOM_unlock(dml_rev_tag));


			  ITK_CALL(AOM_UIF_ask_value(dml_rev_tag,"fnd0ActuatedInteractiveTsks",&taskTempLT));
						 printf("\n primary taskTempLT is .. Add Part: %s\n",taskTempLT);fflush(stdout);

						 //if (tc_strstr(taskTempLT,"Run BOM completeness check")!=NULL)
						 if (tc_strstr(taskTempLT,"VLD Review")!=NULL )
						 {
							printf("\n Inside  %s\n",taskTempLT);fflush(stdout);
							char *last = strrchr(taskTempLT, ',');
							if (last != NULL)
							{
								printf("Last token: '%s'\n", last+1);fflush(stdout);
								//if (tc_strstr(last+1,"Run BOM completeness check")!=NULL)
								if (tc_strstr(last+1,"VLD Review")!=NULL )
								{
									BomCompleteAddPartFlag=1;
								}
								else
								{
									BomCompleteAddPartFlag=0;
								}
							}

						 }

						//if (BomCompleteAddPartFlag==0)
						//{
                          ITK_CALL(EPM_get_current_job(dml_rev_tag,&job_Tag,&jobtype_Tag));
						  ITK_CALL(TCTYPE_ask_name(jobtype_Tag,dRftSpectype_name));
						  ITK_CALL(AOM_ask_value_string(job_Tag,"object_name",&EIDLinfo1)) ;
						  printf("\n Inside  %s %s \n",dRftSpectype_name,EIDLinfo1);fflush(stdout);

						  ITK_CALL(EPM_ask_root_task(job_Tag,&rootTask));
						  ITK_CALL(EPM_ask_sub_tasks(rootTask,&tskcount,&subtask));
						  ITK_CALL(AOM_ask_value_string(rootTask,"object_name",&parent_name));
							printf("\n Parent Name: %s",parent_name);fflush(stdout);
							printf("No of subtasks = %d\n",tskcount);fflush(stdout);

							for (k=0;k<tskcount;k++)
							{
								ITK_CALL(AOM_ask_value_string (subtask[k],"task_type",&taskType));
								printf("task type = %s\n",taskType);fflush(stdout);
								//ITK_CALL(EPM_ask_state (subtask[k],	&state));
								if(tc_strcmp(taskType,"EPMReviewTask")==0)
								{
									{
										ITK_CALL(EPM_ask_sub_tasks(subtask[k],&rvwSubTaskCnt,&reviewSubTasks));
										TC_write_syslog("No of subtask = %d\n",rvwSubTaskCnt);
										for (m=0;m < rvwSubTaskCnt ; m++ )
										{
											ITK_CALL(AOM_ask_value_string (reviewSubTasks[m],"task_type",&taskType));
											if(tc_strcmp(taskType,"EPMPerformSignoffTask")==0)
											{

									ITK_CALL(EPM_ask_attachments(reviewSubTasks[m],EPM_signoff_attachment,&attachmentCount,&taskAttachments));
									//ITK_CALL(AOM_ask_value_string (reviewSubTasks[m],"fnd0Assignee",&Assignee));
									printf("No of signoff attachments in sibling = %d\n",attachmentCount);
									if(attachmentCount>0)		//Assuming only one approval is sufficient for SignOff task to complete.
									{
										for (h=0;h < attachmentCount ; h++ )
										
										{
											ITK_CALL(AOM_UIF_ask_value (taskAttachments[h],"fnd0Assignee",&Assignee));
											printf("Assignee are= %s\n",Assignee);fflush(stdout);
										if(tc_strstr(Assignee,"uaprod") != NULL)
										{
											printf("Assignee ar eee= %s\n",Assignee);fflush(stdout);
										//ITK_CALL(EPM_delegate_signoff(taskAttachments[0],Grp_Member[0],true));	//This changes the Participant value of DML Task. Needs to reassign the previous user, Remedy :  ITEM_rev_ask_participant
										ITK_CALL(EPM_refresh_entire_job(job_Tag));
										//ITK_CALL(EPM_refresh_job(subtask[k]));
										if(tc_strcmp(decs,"APPROVE")==0)
										{
										ITK_CALL(EPM_set_task_decision2(reviewSubTasks[m],taskAttachments[h],apprDecision_e,ApproveComment));
										}

										if(tc_strcmp(decs,"REJECT")==0)
										{
										ITK_CALL(EPM_set_task_decision2(reviewSubTasks[m],taskAttachments[h],rejectDecision_e,rejectComment));
										}
										/*ITK_CALL(AOM_refresh(dmlTaskAttchs[0],true));
										ITK_CALL(ITEM_rev_ask_participants (dmlTaskAttchs[0], peerPrticType, &remPeerRevwrsCnt, &remPeerReviewers_t));
										for (q=0;q< remPeerRevwrsCnt;q++ )
										{
											ITK_CALL(ITEM_rev_remove_participant(dmlTaskAttchs[0],remPeerReviewers_t[q]));
										}
										ITK_CALL(ITEM_rev_set_participants(dmlTaskAttchs[0],peerReviewersCnt,peerReviewers_t));*/
										}
										}
									}
											}
										}
								}
							}

					//	} 
			
		}

		}

	}
	else
	{
		printf("Failed to login\n");
		
	}
	ITK_exit_module(true);
	return ITK_ok;

}
