/*   */
#include "soapH.h"								/* get the gSOAP-generated definitions */
#include "DMLPartValid.nsmap"		 /* get the gSOAP-generated namespace bindings */
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/aom_prop.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tc/folder.h>//new
#include <string.h>
#include <epm/cr_effectivity.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tccore/project.h>
#include <cfm/cfm.h>
#include <qry/qry.h>
#include <tc/preferences.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/iman_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>

#define NUM_ENTRIES 1
#define NUM_ENTRIES1 2
#define MAX_SIZE 100
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); Debug("line %d (ifail %d)\n", __LINE__, ifail);}




FILE	*DMLPartValidLog;

char 		szHMCL_file_log[250] 			= "";
char 		szHMCL_file_err[250]			= "";
char 		szHMCL_file_output[250] 		= "";
static void vLog(char* givenFormat, va_list givenArgs, char* fileName)
{
	char			* logFile 			= NULL;
	FILE			* logFp;
	time_t 			now;
	struct 			tm when;
	char 			date_str[50];
	long 			size;
	logical 		check_size 			= false;
	logFile 							= fileName;
	if (logFile)
	{
		logFp = fopen(logFile, "a+");
		if(!logFp)
		{
			fprintf(stderr, "ERROR: Cannot open '%s'\n", logFile);
			perror(logFile);
			logFp = stderr;
		}
		else{
			fseek(logFp, 0, SEEK_END);
			size = ftell(logFp);
			if(size > 3000000 && check_size)
			{	fclose (logFp);
				logFp = fopen(logFile, "w");
			}
			  }
	}
	else
	{	logFp = stderr;
	}
	if (tc_strcmp(logFile, szHMCL_file_output) == 0)
	{
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp,"\n");
		if (logFp != stderr)
		{			fclose(logFp);
		}
	}
	else
	{
		time(&now);
		when = *localtime(&now);
		strftime(date_str, 50, "%d-%m-%Y %H:%M:%S",&when);
		fprintf(logFp, "%s --- ", date_str);
		vfprintf(logFp, givenFormat, givenArgs);
		fprintf(logFp, "\n");
		if (logFp != stderr)
		{	fclose(logFp);
		}
	}
}
void Debug(char* givenFormat, ...)
{
	va_list   functArgs;
	va_start(functArgs, givenFormat);
	vLog(givenFormat, functArgs, szHMCL_file_log);
	va_end(functArgs);
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "CopyTemplates Error(s): \n");
	printf("CopyTemplates Error(s): \n");fflush(stdout);
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);fflush(stdout);
    }
    return ITK_ok;
}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
 if (return_code != ITK_ok)
	{
	char *error_msg_string;

	EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
	printf("ERROR1: %d ERROR MSG: %s.\n", return_code, error_msg_string);fflush(stdout);
	TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);fflush(stdout);
	TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
	if(error_msg_string) MEM_free(error_msg_string);

	}
	return return_code;
}


extern int ITK_user_main(int argc, char *argv[])
{
	return soap_serve(soap_new());										/* call the request dispatcher */
};



int ns__getDMLPartValid(struct soap* soap,char *DMLnumber,char *partnumber,char **Response)
{
	FILE *fp1;
	int ifail =0;
	int i= 0;
    int StrctInt = 0;
    int flg_grp = 0;
	int length = 0;
	int cnt				= 0;
	char *infoVal0 = NULL;
	char *infoVal1 = NULL;
	char *infoVal2 = NULL;
	char *infoVal3 = NULL;
	char *infoVal4 = NULL;
	char *infoVal5 = NULL;
	char *infoVal6 = NULL;
	char *infoVal7 = NULL;
	char *infoVal8 = NULL;

    char *input   =NULL;
    char *inputfile   =NULL;
	char *input1 =	NULL;
	char *partrevtyp =	NULL;
	char *ExeLogFile =	NULL;
	char *loggedInUser = NULL;
    tag_t queryPart   =NULLTAG;

	//tag_t *result=NULLTAG;
	tag_t relatnType_tag  = NULLTAG;
	tag_t rev_tag =NULLTAG;
	tag_t itemRev_tag =NULLTAG;
	tag_t rev_tag1 =NULLTAG;
	tag_t prev_rev_tag =NULLTAG;
	tag_t partfnd = NULLTAG;
	tag_t task_rev_tag = NULLTAG;
	tag_t part_rev_tag = NULLTAG;
	tag_t partRelatn_Type_tag = NULLTAG;
	tag_t* part_obj_tag = NULLTAG;
	tag_t *task_obj_tag = NULLTAG;
	tag_t *referencers = NULLTAG;
	int  n_tasksFnd    = 0;
	int  n_referencers    = 0;
	int t=0;
	
	char *Rev =NULL;
	char *new_rev =NULL;
	char *TaskID =NULL;
	char **relations =NULL;
	int  	n_parents=0;
	int * 	levels=0;
	int * 	lvls=0;
	tag_t * 	parents	 =NULLTAG;
//

	ExeLogFile = (char	*)MEM_alloc(100);
	tc_strcpy(ExeLogFile,"");
	tc_strcpy(ExeLogFile,"/tmp/");
	tc_strcat(ExeLogFile,partnumber);
	tc_strcat(ExeLogFile,"_ALTMAT.log");
	DMLPartValidLog = fopen(ExeLogFile,"w");
	//freopen(ExeLogFile, "w",DMLPartValidLog);
	fprintf(DMLPartValidLog,"\n Part Execution Log file is :: %s\n",ExeLogFile);


	fpos_t pos;
	fgetpos(stdout, &pos);
	int fd = dup(fileno(stdout));
	freopen("/tmp/ALTMAT.txt", "a", stdout);  


        CALLAPI(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
		CALLAPI(ITK_auto_login());
		CALLAPI(ITK_set_journalling( TRUE ));
//        ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
//        ITK_auto_login();
//        ITK_set_journalling( TRUE );

		fprintf(DMLPartValidLog," Auto Login Successfull..!!\n");fflush(DMLPartValidLog);
		POM_get_user_id(&loggedInUser);
		fprintf(DMLPartValidLog," Logged in User: [%s]\n",loggedInUser);fflush(DMLPartValidLog);

        tag_t	queryDML	=	NULLTAG;
		tag_t*  result	=	NULLTAG;

        int		n_entries	=	1;
        int		l	=	2;
		int    	num_to_sort =	1;
		int  	orders[]  	=	{2};
		int		count=	0;
		char 	*keys[] 	= 	{"creation_date"};
		char 	*qry_DML_entries[1] = {"Item ID"};
		char 	*qry_DML_values[1] = {DMLnumber};
		*Response = (char *) malloc( (50) * sizeof(char));
        
		CALLAPI(QRY_find("Item ID", &queryPart));
		CALLAPI(QRY_execute_with_sort(queryPart, n_entries, qry_DML_entries, qry_DML_values, num_to_sort, keys, orders, &count, &result));
	
        
		fprintf(DMLPartValidLog,"\nNumber of rev   [%s]found : [%d]\n",DMLnumber,count);fflush(DMLPartValidLog);

		if (count>0)
		{
			int j = 0;
			int k = 0;
			
			tag_t itemMstr = NULL;
			char *itemId = NULL;
			char *TaskType = NULL;
		
           
			 fprintf(DMLPartValidLog,"\n Number of design rev found :%d \n",count);fflush(DMLPartValidLog);
			 rev_tag=result[j];
			 if(rev_tag==NULLTAG)
			  {
				  fprintf(DMLPartValidLog,"\n NULLTAG \n");fflush(DMLPartValidLog);
			   }
			 else
			  {
			  	  fprintf(DMLPartValidLog,"\n Not in NULLTAG \n");fflush(DMLPartValidLog);
			  }
			 CALLAPI(ITEM_ask_latest_rev(rev_tag,&itemRev_tag))

			if(itemRev_tag==NULLTAG)
			  {
				  fprintf(DMLPartValidLog,"\nitemRev_tag NULLTAG \n");fflush(DMLPartValidLog);
			   }
			 else
			  {
			  	  fprintf(DMLPartValidLog,"\n itemRev_tag Not  NULLTAG \n");fflush(DMLPartValidLog);
			  }
			 CALLAPI(AOM_ask_value_string(itemRev_tag,"item_id",&itemId))
			 fprintf(DMLPartValidLog,"\nitemRev_ id %s \n",itemId);fflush(DMLPartValidLog);
			 fprintf(DMLPartValidLog,"\nitemRev_ id is   %s \n",itemId);fflush(DMLPartValidLog);
		                    
            CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation",&relatnType_tag));
			 fprintf(DMLPartValidLog,"\n......1 \n");fflush(DMLPartValidLog);
               if(relatnType_tag==NULLTAG)
			     {
				    fprintf(DMLPartValidLog,"\n......2 \n");fflush(DMLPartValidLog);
					fprintf(DMLPartValidLog,"\n relatnType_tag nulltag : \n"); fflush(DMLPartValidLog);
			     }
				  fprintf(DMLPartValidLog,"\n......3 \n");fflush(DMLPartValidLog);
		   if(relatnType_tag!=NULLTAG)
               {
			    fprintf(DMLPartValidLog,"\n......4 \n");fflush(DMLPartValidLog);
               	if(AOM_ask_value_tags(itemRev_tag, "T5_DMLTaskRelation", &n_tasksFnd, &task_obj_tag ))
				 fprintf(DMLPartValidLog,"\n  tasksFnd: %d \n",n_tasksFnd); fflush(DMLPartValidLog);
				{
					 fprintf(DMLPartValidLog,"\n......5 \n");fflush(DMLPartValidLog);
			      fprintf(DMLPartValidLog,"\n  tasksFnd: %d \n",n_tasksFnd); fflush(DMLPartValidLog);
               		if(n_tasksFnd>0)
               		{
               
                       for (i=0;i<n_tasksFnd ;i++ )
               		{
               			task_rev_tag = NULLTAG;
               			task_rev_tag=task_obj_tag[i];
               			
               			if(task_rev_tag!=NULLTAG)
               			{
               					CALLAPI(AOM_ask_value_string(task_rev_tag,"object_type",&TaskType));
               					fprintf(DMLPartValidLog,"\n Task Type: %s \n",TaskType); fflush(DMLPartValidLog);
               					CALLAPI(AOM_ask_value_string(task_rev_tag,"item_id",&TaskID));
               					fprintf(DMLPartValidLog,"\n Task TaskID: %s \n",TaskID); fflush(DMLPartValidLog);
               					
               					if((tc_strcmp(TaskType,"T5_ChangeTaskRevision")==0)|| (tc_strcmp(TaskType,"T5_MBOMTASKRevision")==0) || (tc_strcmp(TaskType,"T5_APLTaskRevision")==0) || (tc_strcmp(TaskType,"T5_SMDMLTaskRevision")==0) || (tc_strcmp(TaskType,"T5_EPATaskRevision")==0))
               					{
               						// Expand the Task-Revision using CMHasSolutionItem to get the TC Part.
               						tag_t partRelatn_Type_tag = NULLTAG;
               						tag_t* part_obj_tag = NULLTAG;
               						int n_parts = 0;
               						CALLAPI(GRM_find_relation_type("CMHasSolutionItem",&partRelatn_Type_tag));
               						if (partRelatn_Type_tag!=NULLTAG)
               						{
               							if(GRM_list_secondary_objects_only( task_rev_tag,partRelatn_Type_tag,&n_parts, &part_obj_tag ))
               							{
               								return ifail;
               							}
               							fprintf(DMLPartValidLog,"\n  No of TC Parts attached to the Task are : %d \n",n_parts); fflush(DMLPartValidLog);
               			
               							tag_t part_rev_tag = NULLTAG;
               							char *PartitemID = NULL;
               					
               							if(n_parts>0)
               							{
               								int j=0;
               								int k =0;
               								for(j=0;j<n_parts ;j++ )
               								{
               									part_rev_tag = part_obj_tag[j];
               									 if(part_rev_tag!=NULLTAG)
               			                           {
               			                             if(AOM_ask_value_string(part_rev_tag,"item_id",&PartitemID))
               			                              fprintf(DMLPartValidLog,"\t\t\t\t Part %s : checking in DML is :  %s\n",PartitemID,partnumber);fflush(DMLPartValidLog);
               			                             if(tc_strcmp(PartitemID,partnumber)==0)
               			                               {
               			                                 fprintf(DMLPartValidLog,"\t %s : found for DML is :  %s\n",PartitemID,partnumber);fflush(DMLPartValidLog);
                                                            flg_grp = 1; 
               			                          	 
               			                                 tc_strcpy(*Response,"1");
                                                            break;
               			                               }  
               			                           }
               									
               								}
               							
               							}	
               							
               							
               							
               						}
               						
               					}
               
               
               			}
               				
               			
               		}
               

               
               		}
               	}
               }


				 fprintf(DMLPartValidLog,"\n***** flg_grp : %d\n",flg_grp);fflush(DMLPartValidLog);
			
				  if(flg_grp == 0)
					{
					
				         tc_strcpy(*Response,"-1");
					}
			
		}
		else
	    {
			fprintf(DMLPartValidLog,"\n***** DML NOT found in TCUA , need to check in TCE : as %d\n",flg_grp);fflush(DMLPartValidLog);
			char* report_ip = NULL;
			report_ip=(char *)MEM_alloc(200);
			tc_strcpy(report_ip,"");
			tc_strcat(report_ip,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_Almat_Part/CV_TCEAltmat_DMLEPA.sh");
			tc_strcat(report_ip," ");
			tc_strcat(report_ip,DMLnumber);
			tc_strcat(report_ip," ");
			tc_strcat(report_ip,partnumber);
			system(report_ip);
			fprintf(DMLPartValidLog,"\nreport_ip path : %s",report_ip);fflush(DMLPartValidLog);



			    inputfile = (char *)MEM_alloc(500);
				tc_strcpy(inputfile,"");
				tc_strcat(inputfile,"/proj/PLMLoading/UAFiles/TCUA/Non_ERC/UA_Almat_Part");
				tc_strcat(inputfile,"/");
				tc_strcat(inputfile,partnumber);
				tc_strcat(inputfile,"_Altmat_TCE");
				tc_strcat(inputfile,".txt");
				fprintf(DMLPartValidLog,"\nFilename : %s",inputfile);fflush(DMLPartValidLog);

				fp1=fopen(inputfile,"r");

				if(fp1!=NULL)
				{
					fprintf(DMLPartValidLog,"\n fp1 open and not null : ");fflush(DMLPartValidLog);
					char *Response1 =NULL;

					if(fgets(inputfile,5000,fp1)!=NULL)
					{
						fprintf(DMLPartValidLog,"\n fgets open and fp1 not null :");fflush(DMLPartValidLog);
						fputs(inputfile,stdout);
		                Response1=NULL;

					Response1=tc_strtok(inputfile,","); //2

					fprintf(DMLPartValidLog,"\n Response1 is : %s",Response1);fflush(DMLPartValidLog);

			      	if(tc_strcmp(Response1,"1")==0)
			      	{
			      	  tc_strcpy(*Response,"1");
			      	  fprintf(DMLPartValidLog,"\n Sent Response as : %s",*Response);fflush(DMLPartValidLog);
			      	}
                    else if (tc_strcmp(Response1,"0")==0)
                    {
			      	   tc_strcpy(*Response,"0");
					   fprintf(DMLPartValidLog,"\n Sent Response as : %s",*Response);fflush(DMLPartValidLog);
                    }
				    else
					{
					 	tc_strcpy(*Response,"-1");
						fprintf(DMLPartValidLog,"\n Sent Response as : %s",*Response);fflush(DMLPartValidLog);
				    }


					}

					/*fclose(DMLPartValidLog);
                    fflush(stdout);
                    dup2(fd, fileno(stdout));
                    close(fd);
                    clearerr(stdout);
                    fsetpos(stdout, &pos);
                    
                    return SOAP_OK; */
				}
				fclose(fp1);


		}
	fclose(DMLPartValidLog);
	fflush(stdout);
	dup2(fd, fileno(stdout));
	close(fd);
	clearerr(stdout);
	fsetpos(stdout, &pos);

	return SOAP_OK;

//	CLEANUP :
//
//		return SOAP_OK;
//
//	EXIT:
//		return SOAP_OK;
}
;

