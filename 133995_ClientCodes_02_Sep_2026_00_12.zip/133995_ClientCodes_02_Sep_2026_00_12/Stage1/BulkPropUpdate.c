/*Objective - Bulk property updation */
///home/cmitest/TC_ROOT12/tcldPatch/tcPatchExecutable
/*Required headers */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tccore/item.h>
#include <tcinit/tcinit.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/tc_startup.h>
#include <tc/emh.h>
#include <res/res_itk.h>
#include <ctype.h>
#include <pom/pom/pom.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <time.h>

/*File pointer declarations */

int itkApiCallStatus = -1;

/*Custom API error handling function */

int ITK_APICALL(int x,FILE *Flogfile)
{      
	    int status=x;
        if(status!=ITK_ok)
        {
            int index = 0;                      
            int n_ifails = 0;           
            const int*  severities = 0;         
            const int*  ifails = 0;                 
            const char** texts = NULL;           
            EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               
            for( index=0; index<n_ifails; index++)                                     
                {                                                                          
                    fprintf(Flogfile,"Error code - %d Error message - %s\n",ifails[index],texts[index]);					
                } 
           EMH_clear_errors();
        }
        return status;
}
/*Main function implementation */ 
    
int ITK_user_main (int argc, char ** argv)
{
    /*Varible declarations */
	
	char filedata[500];	
	char *loggedInUser  =   NULL; 
	char *mainItemId    =   NULL; 
	char *propValue     =   NULL; 			
	char *itemId              =   NULL;                 
	char *itemRevId           =   NULL;             
	char *upritemRevId        =   NULL;                      
	char *itemRevSequence     =   NULL;               
	char *upritemRevSequence  =   NULL;                      
	char *trgObjName          =   NULL;	                     
	char *trgObjStr           =   NULL;                      
	char *trgRevId            =   NULL;                      
	char *revId	              =   NULL;                      
	char *blItemId            =   NULL;                      
	char *blObjectName        =   NULL;                      
	char *tempId              =   NULL;                      
	char *tempObjName         =   NULL;                      
	char *rlsStsName          =   NULL;         
    char *secObjType          =   NULL;	
	char *tPropValue          =   NULL;
	char * userid 	          = NULL;
	char * password			  = NULL;
	char * group						= NULL;
	  
															 
	int bomChildCount   = 0;                                 
	int tempSequenceId  = 0; 		                         
	int revCount = 0;                                        
	int i=0;                                                 
	int t=0;                                                 
	int j=0;  
    int k=0;	
	int temp=0;                                              
	int revFound = 0;                                        
	int sequenceId   =  0;	                                 
	int tsequenceId  =  0;                                   
	int h1=0;                                                
	int h2=0;                                                
	int h3=0;                                                
	int h4=0;                                                
	int h5=0;                                                
	int	rlsStsCount = 0;                                     
	int rlsStsFound = 0;	                                 
	int tItr=0;                  
    int secObjectCount =0; 
	
															 
	tag_t loggedInUserTag   =  NULLTAG;                      
	tag_t itemTag           =  NULLTAG;                      
	tag_t *revTags          =  NULLTAG;                      
	tag_t windowTag         =  NULLTAG;                      
	tag_t topBomLineTag     =  NULLTAG;                      
	tag_t revRule           =  NULLTAG;                      
	tag_t *bomChildTags     =  NULLTAG;                      
	tag_t *rlsStsList       =  NULLTAG;                      
	tag_t latestRevTag      =  NULLTAG;               
    tag_t *secObjTags	    =  NULLTAG;

	
   // FILE *fptr=fopen("pobulk.txt","r");	   
    FILE *fptr=fopen("input.txt","r");	   
	FILE *flogPtr=fopen("BulkPropUpdateLog.txt","w+");
	
	
	userid			= ITK_ask_cli_argument("-u=");
	password 		= ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	
    ITK_APICALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ),flogPtr);
    itkApiCallStatus=ITK_APICALL(ITK_auto_login(),flogPtr); 
    ITK_APICALL(ITK_set_journalling(TRUE),flogPtr);	
	//itkApiCallStatus=ITK_APICALL(ITK_init_module(userid,password,group),flogPtr); 
	
	
	fprintf(flogPtr,__DATE__);
	fprintf(flogPtr,"\n");
	fprintf(flogPtr,__TIME__);
    fprintf(flogPtr,"\n itkApiCallStatus = %d ",itkApiCallStatus);	
	if(itkApiCallStatus==ITK_ok)
	{
		printf("Login successful to teamcenter \n");	
        fprintf(flogPtr,"\n Login Successfull to TC \n");	
        itkApiCallStatus=ITK_APICALL(POM_get_user(&loggedInUser,&loggedInUserTag),flogPtr);
	    if(itkApiCallStatus==ITK_ok)
		{
		    fprintf(flogPtr,"\nName of the logged in user = %s \n",loggedInUser);	
			if(fptr!=NULL)
			{
				fprintf(flogPtr,"\nFile found and successfully opened ... \n");
				
				while(fgets(filedata, 500, fptr) != NULL) 
			    {
					fprintf(flogPtr,"\n \n File line found = %s \n",filedata);
					mainItemId   = strtok(filedata,",");
					propValue    = strtok(NULL,",");
					
					fprintf(flogPtr,"mainItemId - %s \n", mainItemId);
					fprintf(flogPtr,"propValue  - %s\n", propValue); 
					
					itkApiCallStatus=ITK_APICALL(ITEM_find_item(mainItemId,&itemTag),flogPtr);                                                
                    fprintf(flogPtr," API Status for ITEM_find_item = %d \n",itkApiCallStatus);                                           
                    if(itkApiCallStatus==0&&itemTag!=NULLTAG)                                                                             
                    {												                                                                      
	                    fprintf(flogPtr," Item with %s mainItemId found  .... \n",mainItemId);                                                 
	                    itkApiCallStatus=ITK_APICALL(ITEM_list_all_revs(itemTag,&revCount,&revTags),flogPtr);                          
	                    fprintf(flogPtr," API Status for ITEM_list_all_revs = %d \n",itkApiCallStatus);                                
	                    fprintf(flogPtr,"Total RevCount =  %d \n",revCount);                                                           
	                    if(revCount > 0)                                                                                               
	                    {                                                                                                              
	                    	fprintf(flogPtr,"Executing condition where Rev Count > 0 \n");                                             
	                    	for(i=revCount-1;i>=0;i--)                                                                                 
	                    	{                                                                                                          
	                    		rlsStsFound=0;                                                                                         
	                    		revFound=0;                                                                                            
	                    		ITK_APICALL(AOM_ask_value_string(revTags[i],"object_name",&trgObjName),flogPtr);                       
                                ITK_APICALL(AOM_ask_value_string(revTags[i],"object_string",&trgObjStr),flogPtr);                      
	                            ITK_APICALL(AOM_ask_value_string(revTags[i],"item_revision_id",&trgRevId),flogPtr);                    
	                            ITK_APICALL(AOM_ask_value_int(revTags[i],"sequence_id",&sequenceId),flogPtr);                          
	                    		ITK_APICALL(AOM_ask_value_tags(revTags[i],"release_status_list",&rlsStsCount,&rlsStsList),flogPtr);    
	                    		                                                                                                       
	                    		fprintf(flogPtr,"-trgObjName = %s\n",trgObjName);                                                      
	                            fprintf(flogPtr,"-trgObjStr = %s\n",trgObjStr);                                                        
	                            fprintf(flogPtr,"-trgRevId = %s\n",trgRevId);                                                          
	                            fprintf(flogPtr,"-sequenceId = %d\n",sequenceId);                                                      
	                    		fprintf(flogPtr,"-rlsStsCount = %d\n",rlsStsCount);										               
	                    		                                                                                                       
	                    		if(rlsStsCount > 0)                                                                                    
	                    		{                                                                                                      
	                    			fprintf(flogPtr,"Executing condition where rlsStsCount Count > 0 \n");                             
	                    		    for(j=0;j<rlsStsCount;j++)                                                                         
	                    	        {                                                                                                  
	                    			    ITK_APICALL(AOM_ask_value_string(rlsStsList[j],"object_name",&rlsStsName),flogPtr);            
	                    			    fprintf(flogPtr," - ***** rlsStsName = %s \n",rlsStsName);                                     
	                    				if(tc_strcmp(rlsStsName,"ERC Released")==0||tc_strcmp(rlsStsName,"T5_LcsErcRlzd")==0)          
	                    				{                                                                                              
	                    					rlsStsFound=1;                                                                             
	                    					revFound=1;                                                                                
	                    					break;                                                                                     
	                    				}                                                                                              
	                    				                                                                                               
	                    		    }                                                                                                  
	                    			if(rlsStsFound==1)                                                                                 
	                    			{
										itkApiCallStatus=ITK_APICALL(GRM_list_secondary_objects_only(revTags[i], NULLTAG, &secObjectCount, &secObjTags),flogPtr);
	                                    fprintf(flogPtr," API Status for GRM_list_secondary_objects_only = %d \n",itkApiCallStatus);
	                                    fprintf(flogPtr,"Total secObjectCount = %d \n",secObjectCount);
										for(k=0;k<secObjectCount;k++)
										{
											ITK_APICALL(AOM_ask_value_string(secObjTags[k],"object_type",&secObjType),flogPtr);  											
											if(tc_strcmp(secObjType,"Design Revision Master")==0)
											{
												fprintf(flogPtr,"Design Master Revision found ! \n");
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial1",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial1 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial2",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial2 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial3",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial3 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial4",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial4 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial5",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial5 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial6",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial6 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial7",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial7 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial8",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial8 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial9",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial9 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial10",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial10 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial11",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial11 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial12",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial12 | Current value = %s \n",tPropValue);
												
												// Setting value as per the give input in the file.
												
												ITK_APICALL(AOM_refresh(secObjTags[k],1),flogPtr);
												ITK_APICALL(AOM_lock(secObjTags[k])!=NULLTAG,flogPtr);
												ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial1",propValue),flogPtr);
                                                ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial2",propValue),flogPtr);
         										ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial3",propValue),flogPtr); 
												ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial4",propValue),flogPtr); 
												ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial5",propValue),flogPtr); 
												ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial6",propValue),flogPtr); 
												ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial7",propValue),flogPtr); 
												ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial8",propValue),flogPtr); 
												ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial9",propValue),flogPtr); 
												ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial10",propValue),flogPtr); 
												ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial11",propValue),flogPtr); 
												ITK_APICALL(AOM_UIF_set_value(secObjTags[k],"t5_BulkMaterial12",propValue),flogPtr); 
												
												ITK_APICALL(AOM_save(secObjTags[k]),flogPtr);
												ITK_APICALL(AOM_unlock(secObjTags[k])!=NULLTAG,flogPtr);
												ITK_APICALL(AOM_refresh(secObjTags[k],0),flogPtr);
												
												// Getting update value
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial1",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial1 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial2",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial2 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial3",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial3 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial4",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial4 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial5",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial5 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial6",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial6 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial7",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial7 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial8",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial8 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial9",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial9 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial10",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial10 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial11",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial11 | Current value = %s \n",tPropValue);
												
												ITK_APICALL(AOM_ask_value_string(secObjTags[k],"t5_BulkMaterial12",&tPropValue),flogPtr);  
												fprintf(flogPtr,"PropName = t5_BulkMaterial12 | Current value = %s \n",tPropValue);
												
												
											}
										}									
									}
                                    else
									{
										fprintf(flogPtr,"Executing condition where rlsStsFound == 0 or releaseStatus not found !!!! \n");
									}											
                                }
								else
								{
									fprintf(flogPtr,"Executing condition where rlsStsCount Count == 0 \n ");
								}						

                            }
							if(revFound==1)
							{
								fprintf(flogPtr,"PartRevision found with ERC released status execution completed ...\n ");									
							}
                            else
							{
								fprintf(flogPtr,"PartRevision not found with ERC released status execution incompleted ...\n ");								
     						}		

                        }
                    
                    }
					else
					{
						fprintf(flogPtr," Item with %s item not found \n ",mainItemId);	
					}
			    }
		
    		}
			else
			{
				fprintf(flogPtr,"\n File not found or File not opened ... \n");
			}
		}
		else
		{
			fprintf(flogPtr,"\n Loggedin user not found \n");
		}
	}
    else
	{
		  printf("\n***************************Login failed in TC \n");	
		  fprintf(flogPtr,"\n********************Login failed in TC \n");
	}
	return(ITK_ok);
}