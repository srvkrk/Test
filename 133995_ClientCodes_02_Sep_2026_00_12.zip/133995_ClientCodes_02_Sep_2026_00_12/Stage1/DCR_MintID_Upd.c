#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unidefs.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <cfm/cfm.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <pie/pie.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#include <sa/sa.h>
#define Debug TRUE
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); fflush(stdout); exit (0);}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );

    for ( i = 0; i < iNumErrs; i++ )
    {

		printf("Error(PrintErrorStack): \n"); fflush(stdout);
        printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
    }
    return ITK_ok;
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	{
		printf("Login fail !!: Error code = %d \n\n",ifail); fflush(stdout);
		fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
		CHECK_FAIL;
	}
	else
	{
		printf("Login successful !! \n"); fflush(stdout);
	}
}
extern int ITK_user_main (int argc, char ** argv )
{
	int ifail;
	int status;
	int count=1;
	int num;
	int position = 0;
	int num_values;


	(void)argc;
	(void)argv;

	tag_t TagClassId = NULLTAG;
	tag_t designgrouplov = NULLTAG;
	tag_t value = NULLTAG;
	char *ObjClassName=NULL;
	char **DesignGroupList=NULL;

	char *dcr_no  = NULL;
    char *design_group = NULL;
	dcr_no  = ITK_ask_cli_argument("-dcr=");
    design_group  = ITK_ask_cli_argument("-mid=");

	if(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	initialise();
	if(ITK_set_journalling( TRUE ));

	printf("Entering fun");

	if (dcr_no !=NULL)
    {
		logical retain_released_date =TRUE;
		tag_t DCRTag = NULLTAG;
		tag_t DCRREVTag = NULLTAG;


		char **designgroup=NULL;

		if(ITEM_find_item(dcr_no ,&DCRTag)!=ITK_ok)PrintErrorStack();
		if (DCRTag)
		{
			printf("\ntag found\n");
		
		}
		if(ITEM_ask_latest_rev(DCRTag, &DCRREVTag)!=ITK_ok)PrintErrorStack();

        if (DCRREVTag)
		{
			printf("\nDCRREVTag found\n");
		}
		if (DCRREVTag!=NULLTAG)
		{
			if(POM_class_of_instance(DCRREVTag,&TagClassId));
			if(POM_name_of_class(TagClassId,&ObjClassName));
			printf("\n ObjClassName: %s",ObjClassName);

			if(AOM_ask_displayable_values(DCRREVTag,"t5_MinrefNo",&num_values,&designgroup)!=ITK_ok);
			//if(AOM_ask_lov(DCRREVTag,"t5_DcrDesgGrp", &designgrouplov)!=ITK_ok);


			//if(AOM_ask_value_tag(DCRREVTag,"t5_DcrDesgGrp",&value));

			printf("\n values count for less than value 1: %d",num_values);

			printf("\n designgroup is :%s\n",designgroup);fflush(stdout);
           if (num_values>0)
           {
			   //num_values++;
				
				position = 0;
				printf("\n Position is ::  %d",position);
				//tc_strcpy(design_group_upd,"");
				//tc_strcpy(design_group_upd,designgroup);
				//tc_strcat(design_group_upd,design_group);
				printf("\n values count: %d",num_values);

				if (tc_strcmp(ObjClassName,"T5_GenDcrChngRepRevision")==0)
				{
					ITK_CALL(AOM_lock(DCRREVTag));

					printf("\n object ready to set value ");fflush(stdout);

					//ITK_CALL(AOM_set_value_string_at(DCRREVTag,"t5_MinrefNo",position,design_group));
					//ITK_CALL(AOM_set_value_string_at(DCRREVTag,"t5_DcrDesgGrp",position,design_group));
					ITK_CALL(AOM_set_value_string_at(DCRREVTag,"t5_MinrefNo",2,design_group));

					ITK_CALL(AOM_save_without_extensions(DCRREVTag));

					ITK_CALL(AOM_refresh(DCRREVTag,0));

					ITK_CALL(AOM_ask_value_strings(DCRREVTag,"t5_MinrefNo",&num,&DesignGroupList));

					printf("\n Replaced value of  designgroup is : %s\n", DesignGroupList);
				}
			}
			MEM_free(designgroup);
		}
	}
	else
	{
		printf("\n DCRREVTag NOT found------>");fflush(stdout);
	}

	printf("\n ");
	ITK_CALL(POM_logout(false));
	return status;
}
