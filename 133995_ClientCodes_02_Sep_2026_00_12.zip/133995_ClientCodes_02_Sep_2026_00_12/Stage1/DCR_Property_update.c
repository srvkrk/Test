#include <stdlib.h>
#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <vm/vms.h>
#include <tc/emh.h>
#include <pom/pom/pom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <fclasses/tc_string.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/tctype.h>
#include <form/form.h>
#include <epm/cr.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <tccore/idcxt.h>
#include <tccore/idfr.h>
#include <tccore/idcxt_errors.h>
#include <tccore/part.h>
#include <tccore/tctype.h>

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#include <tcinit/tcinit.h>
#include <ae/ae.h>
#include <sa/tcfile_cache.h>
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
int ifail = ITK_ok;
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
        printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
    }
    return ITK_ok;
}
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{
	*count=*count+1;
	if(*count==1)
	{
	(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	}
	else
	{
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));

}
int ITK_user_main(int argc, char *argv[])
{
	
	
	char *dcr_no  = NULL;
	char *username = NULL;
	char *password = NULL;
	char *group = NULL;
	int status              = ITK_ok;


	ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
	ifail = ITK_auto_login( );

	if(ifail==0)
	{
		printf("\nLogin Successfully to Teamcenter!!!!!!!!\n");
	}
	ifail = ITK_set_journalling(TRUE);

	username      = ITK_ask_cli_argument("-u=");
	password      = ITK_ask_cli_argument("-pf=");
	group 			= ITK_ask_cli_argument("-g=");
	Filename		= ITK_ask_cli_argument("-file=");
	//sObjno		= ITK_ask_cli_argument("-number=");
	//sProperty		= ITK_ask_cli_argument("-property=");
	//sValue		= ITK_ask_cli_argument("-value=");

	time_t 	now;
	struct 	tm when;

	time(&now);
	when = *localtime(&now);

	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);

	if(tc_strlen(stripBlanks(userid)) == 0  || tc_strlen(stripBlanks(password)) == 0  || tc_strlen(stripBlanks(group)) == 0 || tc_strlen(stripBlanks(Filename)) == 0)
	{
		print_requirement();
		return -1;
	}

	ifail = ITK_auto_login();
	//ifail = ITK_init_module(userid, password, group);
	if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
		{
			printf("\nLogin Successfull.....!!\n");
			printf("\nWelcome to Teamcenter.....!!\n");
		}
	ifail = ITK_set_bypass(true);
    if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}

	output = fopen(outputFile,"a+");
	if (output == NULL)
	{
		printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
		{
			printf("File opened successfully...!!\n");
		}

		tc_strcpy(test, "");
		tc_strcpy(test,"DML_No");
		tc_strcat(test,sep);
		tc_strcat(test,"Property");
		tc_strcat(test,sep);
		tc_strcat(test,"Value");

		fprintf(output,"%s\n",test);
		MEM_free(test);

		ifail = read_value_from_file(Filename);
		//ifail = read_value_from_file(sObjno,sProperty,sValue);

	printf("\nEnd of program.....!!\n\n");
	printf("\n*****************************\n");
	ifail = ITK_exit_module(true);
	return ifail;
}


/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.
**********************************************************************************************/
int read_value_from_file(char* Filename)
{
	int				ifail 					= ITK_ok;
	int				count	 				= 0;

	char 			*itemid					= NULL;
	char 			*property				= NULL;
	char 			*value					= NULL;
	char 			temp[20000];

	FILE* fp = NULL;
	fp = fopen(Filename, "r");

	if (fp != NULL)
	{
		while (fgets(temp, 20000, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				itemid = strtok(temp, ",");
				//if(itemid)nlsStrTrimTrailWhiteSpace(itemid);
				printf("\nInput Item_id:%s",itemid); fflush(stdout);

				property = strtok(NULL, ",");
				//if(property)nlsStrTrimTrailWhiteSpace(property);
				printf("\nInput rev_id:%s",property); fflush(stdout);

				value = strtok(NULL, ",");
				//if(value)nlsStrTrimTrailWhiteSpace(value);
				printf("\nInput value:%s\n",value);fflush(stdout);

				ifail = DML_property_upd(itemid,property,value);
			}
			tc_strcpy(temp, "");
		}
	}
	else
	{
		printf("File Unable to Open...!!");fflush(stdout);
	}
	fclose(fp);
	fclose(output);
	return ifail;
}


/********************************************************************************************
    Function:       property update
    Description:    This function takes the item_id and attr_value as input and stamps the
					attr_value on specific attribute of all revisions of perticular item.
********************************************************************************************/

int DML_property_upd(char* item_id, char* property ,char* value)
{
	int				ifail 						= ITK_ok;
	int				r_count 					= 0;
	int				i		 					= 0;
	tag_t			DML_tag						= NULLTAG;
	tag_t			rev_tag						= NULLTAG;
	char 			*updvalue					= NULL;

	
	ifail = ITEM_find_item (item_id, &DML_tag);
	ifail = ITEM_ask_latest_rev (DML_tag, &rev_tag);
	if(ifail != ITK_ok)
	{
		printf("Object not found in Teamcenter...!!\n");fflush(stdout);
		return 0;
	}
	else
	{
		if(AOM_refresh (rev_tag, 1)!=ITK_ok)PrintErrorStack();
		if(AOM_lock( rev_tag)!=ITK_ok)PrintErrorStack();
		if(AOM_UIF_set_value (rev_tag,property,updvalue)!=ITK_ok)PrintErrorStack();
		if(AOM_save_without_extensions (rev_tag)!=ITK_ok)PrintErrorStack();
		if(AOM_unlock(rev_tag)!=ITK_ok)PrintErrorStack();
		if(AOM_refresh (rev_tag, 0)!=ITK_ok)PrintErrorStack();
		ifail = AOM_UIF_ask_value (rev_tag,property,&updvalue);
		printf("\n[%s] stamped with [%s] on Latest Rev:....!!",property,updvalue);fflush(stdout);
		//ifail = write_info(item_id, dr_status_new);
		printf("\n***********************\n");fflush(stdout);
	}
	return ifail;
}
