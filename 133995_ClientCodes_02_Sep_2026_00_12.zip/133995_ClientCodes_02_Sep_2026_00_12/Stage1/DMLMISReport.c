/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Abineshwar Bisoi
*  Module		 :   Intial code for DML MIS report
*  Code			 :   DMLMISReport.c
*  Created on	 :   08 July 2024
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
*  1.     08/07/2024              Sandeep/Abineshwar    Intial code for DML MIS report 
***************************************************************************/

#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <pom/enq/enq.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/pom/pom.h>
#include <epm/epm.h>
#include <user_exits/libuser_exits_exports.h>
#include <user_exits/libuser_exits_undef.h>
#include <time.h>
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#define MAX_LINE_LEN 1024



#define Debug TRUE

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_get_error_string (NULLTAG, stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}


char* RptTimestamp = NULL;
char *FromDate = NULL;
char *ToDate = NULL;
char *Agency = NULL;
char *Plant = NULL;
char *GroupNm = NULL;
char *CsvName = NULL;
char *ReportFileName = NULL;
char *mailIDList = NULL;

signed long daysInSecond(signed int day)
{
    return day*24*60*60;
}

 long timeInSec(time_t time1) 
 {
	return (long)time1;
 }

time_t longTotime_t(long timeInSec)
{
    return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day)
{
    return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

void setAdd_QryWLUser(int *count, char ***strset, char *str)
{

    *count = *count + 1;
    if (*count == 1)
    {
        (*strset) = (char **)malloc((*count) * sizeof(char *));
    }
    else
    {
        (*strset) = (char **)realloc((*strset), (*count) * sizeof(char *));
    }
    (*strset)[*count - 1] = malloc((strlen(str) + 1) * sizeof(char));
    tc_strcpy((*strset)[*count - 1], str);
}

void setFindStr_QryWLUser(int count, char **view_list, char *str, int *found)
{
    
    int k = 0;
    *found = -1;
    for (k = 0; k < count; k++)
    {
        if (tc_strcmp(view_list[k], str) == 0)
        {
            *found = k;
            break;
        }
    }
}

void GetReportTimeStamp()
{
	char        *timestamp            =   NULL;
	time_t t;
	time(&t);
    timestamp = ctime(&t);
    printf("\n Start Time..Of Report Generation..%s",timestamp);fflush(stdout);
	
	char 	*tempTimestamp1 = NULL;
	char 	*tempTimestamp2 = NULL;
	
	tempTimestamp1 = (char *) MEM_alloc(100 * sizeof(char *));
	tempTimestamp2 = (char *) MEM_alloc(100 * sizeof(char *));
	RptTimestamp = (char *) MEM_alloc(100 * sizeof(char *));

	STRNG_replace_str(timestamp," ","_",&tempTimestamp1);
	STRNG_replace_str(tempTimestamp1,":","_",&tempTimestamp2);
	STRNG_replace_str(tempTimestamp2,"\n","",&RptTimestamp);
}

char *removeJunk(char *in)
{
    // printf("\n Test Inside Function removeChar \n");fflush(stdout);
    int i, j;
    char *tmp;
    tmp = (char *)malloc(strlen(in) + 2);
    i = 0;
    j = 0;
    while (in[j])
    {
        // if (in[j] != '\x01' && in[j] != '\x02')
        if (in[j] != '\n' && in[j] != '\r' && in[j] != '#' && in[j] != '$' && in[j] != ',')
        {
            tmp[i] = in[j];
            i++;
        }
        j++;
    }
    tmp[i] = '\0';
    return tmp;
}

char *subString_DMLBWDate(char *mainStringf, int fromCharf, int toCharf)
{
    int i;
    char *retStringf;
    retStringf = (char *)malloc(200);
    for (i = 0; i < toCharf; i++)
            *(retStringf + i) = *(mainStringf + i + fromCharf);
    *(retStringf + i) = '\0';
    return retStringf;
}

void setofTagList(int *count,tag_t **objlist,tag_t obj )
{
	*count=*count+1;
	if(*count==1)
	{
		printf("\n Malloc Started");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
		printf("\n Malloc End");fflush(stdout);
	}
	else
	{
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	//printf("\n Number Count : [%d]",*count);fflush(stdout);
	(*objlist)[*count-1] = obj; 
}


char* GetERCDMLRlzDate(char* DMLERC)
{
        tag_t           qryERCTag       = NULLTAG;
        char*       Ercrlzdate  = NULL;
        int                     resultsQryERC = 0;
        tag_t           *revERC = NULLTAG;
        char *ArgERCNum1[] = {"Item ID","Type"},
             *ArgERCVal1[] = {DMLERC,"ERC DML Revision"};
        Ercrlzdate = (char *)MEM_alloc(100 * sizeof(char *));
        tc_strcpy(Ercrlzdate,"");
        if(QRY_find2("Item Revision...", &qryERCTag));

        if(QRY_execute(qryERCTag, 1, ArgERCNum1, ArgERCVal1, &resultsQryERC, &revERC));

        if (resultsQryERC>0)
        {
            tag_t           ERCDML_tag =    NULLTAG;
            char* ERCDMLNum = NULL;
            ERCDML_tag = revERC[0];
            AOM_ask_value_string(ERCDML_tag,"item_id",&ERCDMLNum);
            AOM_UIF_ask_value(ERCDML_tag,"date_released",&Ercrlzdate);
        }
        return Ercrlzdate;
}


void GetEPAInformation(tag_t TaskObjPtr,char* RptEPANumber,char* RptEPARlzStatus,char* RptEPATryOutDate,char* RptEPARlzDate,char* RptEPACurrentStatus,char* RptEPAMBPANum)
{
	tag_t      PartRelation           = NULLTAG;
	int        NoOfParts              = 0;
	tag_t*     PartSet                = NULLTAG;
	
	ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&PartRelation));
	ITK_CALL(GRM_list_secondary_objects_only(TaskObjPtr,PartRelation,&NoOfParts,&PartSet));
	//printf("Number of parts found under task is = %d\n",NoOfParts);fflush(stdout);
	if(NoOfParts > 0)
	{
		int    PartItr   = 0;
		int EPAFoundForPlant = 0;
        for(PartItr = 0; PartItr < NoOfParts;PartItr++)
		{
			tag_t     PartItem           = NULLTAG;
            char      *Prt_object_type   = NULL;
            char      *PartRevSeq        = NULL;
            char      *PartNo            = NULL;
            char      *Releasestate1     = NULL;
            char      *PartDesc          = NULL;
            char      *PartDescV         = NULL;
            char      *PartType          = NULL;
            char      **RlzStsList       = NULL;
            int        NoofLC            = 0;


            PartItem = PartSet[PartItr];
            ITK_CALL(AOM_ask_value_string(PartItem,"object_type",&Prt_object_type));
            //printf("\n Prt_object_type is... = %s",Prt_object_type);fflush(stdout);

            if(strcmp(Prt_object_type,"Design Revision")!=0)
            {
                continue;
            }
			tag_t *RefRnce;
		    int NoRefs;
		    int *Levels;
		    char **Relatins=NULL;
		    ITKCALL(WSOM_where_referenced(PartItem, 1,&NoRefs,&Levels,&RefRnce,&Relatins));
		    //printf("\n Here I am ");fflush(stdout);
		        
		    int RefCounter = 0;
		    for(RefCounter = 0; RefCounter < NoRefs; RefCounter++)
		    {
				int GetDMLStatus = 0;
		        tag_t ObjTypeRefTag = NULLTAG;
		        char*  TypeNameRef = NULL;
		        ITKCALL(TCTYPE_ask_object_type(RefRnce[RefCounter],&ObjTypeRefTag));
		        ITKCALL(TCTYPE_ask_name2(ObjTypeRefTag,&TypeNameRef));
		        //printf("\n TypeNameRef= %s\n", TypeNameRef);fflush(stdout);
		        if (strcmp(TypeNameRef,"T5_EPATaskRevision")==0)
				{
					char* EPATaskName = NULL;
					if( AOM_ask_value_string(RefRnce[RefCounter],"item_id",&EPATaskName)!=ITK_ok);
					//printf("\n EPATaskName = %s",EPATaskName);fflush(stdout);
					
					int cntRefPrimaryObj = 0;
					tag_t* EPAObjectS = NULLTAG;
					GRM_list_primary_objects_only(RefRnce[RefCounter],NULLTAG,&cntRefPrimaryObj,&EPAObjectS);
					
					int ItrEPA = 0;
					
					for(ItrEPA = 0;ItrEPA<cntRefPrimaryObj;ItrEPA++)
					{
						tag_t ObjEPA = NULLTAG;
						char*  ObjEPATypeNameRef = NULL;
						ITKCALL(TCTYPE_ask_object_type(EPAObjectS[ItrEPA],&ObjEPA));
						ITKCALL(TCTYPE_ask_name2(ObjEPA,&ObjEPATypeNameRef));
						//printf("\n ObjEPATypeNameRef = %s",ObjEPATypeNameRef);fflush(stdout);
						
						if(strcmp(ObjEPATypeNameRef,"T5_EPARevision") == 0)
						{
							if(EPAFoundForPlant == 1)
							{
								break;
							}
							
							if(strcmp(Plant,"JSR")==0)
	                        {
								char* EPAName = NULL;
								EPAFoundForPlant = 1;
								if( AOM_ask_value_string(EPAObjectS[ItrEPA],"item_id",&EPAName)!=ITK_ok);
								//printf("\n EPAName = %s",EPAName);fflush(stdout);
	                        	if((strstr(EPAName,"JM") != NULL) || (strstr(EPAName,"JR") != NULL))
	                        	{
	                        	    if( AOM_ask_value_string(EPAObjectS[ItrEPA],"item_id",&EPAName)!=ITK_ok);
									
									int StCnt = 0;
									tag_t* EPARlzStatList = NULLTAG; 
									ITKCALL(WSOM_ask_release_status_list(EPAObjectS[ItrEPA],&StCnt,&EPARlzStatList));
									
									if(StCnt>0)
			                        {
										int cnt = 0;
			                        	for (cnt=0;cnt< StCnt;cnt++ )
			                        	{
			                        		char* TempRlzStatusName = NULL;
			                        		char* TempEPARLZDate    = NULL;
			                        		char* TempEPATryOutDate = NULL;
											char* TempRlzStatus     = NULL;
											TempRlzStatus = (char *)MEM_alloc(100 * sizeof(char *));
											TempRlzStatusName = (char *)MEM_alloc(100 * sizeof(char *));
											TempEPARLZDate = (char *)MEM_alloc(100 * sizeof(char *));
											TempEPATryOutDate = (char *)MEM_alloc(100 * sizeof(char *));
			                        		AOM_ask_value_string(EPARlzStatList[cnt],"object_name", &TempRlzStatusName);
			                        		//printf("\n TempRlzStatusName is :%s\n",TempRlzStatusName);fflush(stdout);
			                        		if(tc_strcmp(TempRlzStatusName,"")!=0)
			                        		{
			                        			if (tc_strcmp(TempRlzStatusName,"T5_LcsStdjRlzd")==0)
			                        			{
			                        				AOM_UIF_ask_value(EPAObjectS[ItrEPA],"date_released", &TempEPARLZDate);
													AOM_UIF_ask_value(EPAObjectS[ItrEPA],"t5_TryoutDate", &TempEPATryOutDate);
													tc_strcpy(TempRlzStatus,"STDSIJ Released");
													tc_strcpy(RptEPANumber,EPAName);
													tc_strcpy(RptEPARlzStatus,TempRlzStatus);
													tc_strcpy(RptEPATryOutDate,TempEPATryOutDate);
													tc_strcpy(RptEPARlzDate,TempEPARLZDate);
													tc_strcpy(RptEPACurrentStatus,"");
													tc_strcpy(RptEPAMBPANum,"");
													continue;
			                        			}
												else
												{
													tc_strcpy(TempEPARLZDate,"");
													tc_strcpy(TempEPATryOutDate,"");
													tc_strcpy(TempRlzStatus,"STDSIJ Working");
													
													tc_strcpy(RptEPANumber,EPAName);
													tc_strcpy(RptEPARlzStatus,TempRlzStatus);
													tc_strcpy(RptEPATryOutDate,TempEPATryOutDate);
													tc_strcpy(RptEPARlzDate,TempEPARLZDate);
													tc_strcpy(RptEPACurrentStatus,"");
													tc_strcpy(RptEPAMBPANum,"");
												}
			                        		}
			                        	}
			                        }
	                        	}
	                        }
							if(strcmp(Plant,"PUNE")==0)
	                        {
								char* EPAName = NULL;
								EPAFoundForPlant = 1;
								if( AOM_ask_value_string(EPAObjectS[ItrEPA],"item_id",&EPAName)!=ITK_ok);
								//printf("\n EPAName = %s",EPAName);fflush(stdout);
	                        	if((strstr(EPAName,"CM") != NULL) || (strstr(EPAName,"CR") != NULL))
	                        	{
	                        	    if( AOM_ask_value_string(EPAObjectS[ItrEPA],"item_id",&EPAName)!=ITK_ok);
									
									int StCnt = 0;
									tag_t* EPARlzStatList = NULLTAG; 
									ITKCALL(WSOM_ask_release_status_list(EPAObjectS[ItrEPA],&StCnt,&EPARlzStatList));
									
									if(StCnt>0)
			                        {
										int cnt = 0;
			                        	for (cnt=0;cnt< StCnt;cnt++ )
			                        	{
			                        		char* TempRlzStatusName = NULL;
			                        		char* TempEPARLZDate    = NULL;
			                        		char* TempEPATryOutDate = NULL;
											char* TempRlzStatus     = NULL;
											TempRlzStatus = (char *)MEM_alloc(100 * sizeof(char *));
											TempRlzStatusName = (char *)MEM_alloc(100 * sizeof(char *));
											TempEPARLZDate = (char *)MEM_alloc(100 * sizeof(char *));
											TempEPATryOutDate = (char *)MEM_alloc(100 * sizeof(char *));
			                        		AOM_ask_value_string(EPARlzStatList[cnt],"object_name", &TempRlzStatusName);
			                        		//printf("\n TempRlzStatusName is :%s\n",TempRlzStatusName);fflush(stdout);
			                        		if(tc_strcmp(TempRlzStatusName,"")!=0)
			                        		{
			                        			if (tc_strcmp(TempRlzStatusName,"T5_LcsStdpRlzd")==0)
			                        			{
			                        				AOM_UIF_ask_value(EPAObjectS[ItrEPA],"date_released", &TempEPARLZDate);
													AOM_UIF_ask_value(EPAObjectS[ItrEPA],"t5_TryoutDate", &TempEPATryOutDate);
													tc_strcpy(TempRlzStatus,"STDSIP Released");
													tc_strcpy(RptEPANumber,EPAName);
													tc_strcpy(RptEPARlzStatus,TempRlzStatus);
													tc_strcpy(RptEPATryOutDate,TempEPATryOutDate);
													tc_strcpy(RptEPARlzDate,TempEPARLZDate);
													tc_strcpy(RptEPACurrentStatus,"");
													tc_strcpy(RptEPAMBPANum,"");
													continue;
			                        			}
												else
												{
													tc_strcpy(TempEPARLZDate,"");
													tc_strcpy(TempEPATryOutDate,"");
													tc_strcpy(TempRlzStatus,"STDSIP Working");
													
													tc_strcpy(RptEPANumber,EPAName);
													tc_strcpy(RptEPARlzStatus,TempRlzStatus);
													tc_strcpy(RptEPATryOutDate,TempEPATryOutDate);
													tc_strcpy(RptEPARlzDate,TempEPARLZDate);
													tc_strcpy(RptEPACurrentStatus,"");
													tc_strcpy(RptEPAMBPANum,"");
												}
			                        		}
			                        	}
			                        }
	                        	}
	                        }
							if(strcmp(Plant,"LKO")==0)
	                        {
								char* EPAName = NULL;
								EPAFoundForPlant = 1;
								if( AOM_ask_value_string(EPAObjectS[ItrEPA],"item_id",&EPAName)!=ITK_ok);
								//printf("\n EPAName = %s",EPAName);fflush(stdout);
	                        	if((strstr(EPAName,"IB") != NULL) )
	                        	{
	                        	    if( AOM_ask_value_string(EPAObjectS[ItrEPA],"item_id",&EPAName)!=ITK_ok);
									
									int StCnt = 0;
									tag_t* EPARlzStatList = NULLTAG; 
									ITKCALL(WSOM_ask_release_status_list(EPAObjectS[ItrEPA],&StCnt,&EPARlzStatList));
									
									if(StCnt>0)
			                        {
										int cnt = 0;
			                        	for (cnt=0;cnt< StCnt;cnt++ )
			                        	{
			                        		char* TempRlzStatusName = NULL;
			                        		char* TempEPARLZDate    = NULL;
			                        		char* TempEPATryOutDate = NULL;
											char* TempRlzStatus     = NULL;
											TempRlzStatus = (char *)MEM_alloc(100 * sizeof(char *));
											TempRlzStatusName = (char *)MEM_alloc(100 * sizeof(char *));
											TempEPARLZDate = (char *)MEM_alloc(100 * sizeof(char *));
											TempEPATryOutDate = (char *)MEM_alloc(100 * sizeof(char *));
			                        		AOM_ask_value_string(EPARlzStatList[cnt],"object_name", &TempRlzStatusName);
			                        		//printf("\n TempRlzStatusName is :%s\n",TempRlzStatusName);fflush(stdout);
			                        		if(tc_strcmp(TempRlzStatusName,"")!=0)
			                        		{
			                        			if (tc_strcmp(TempRlzStatusName,"T5_LcsStdlRlzd")==0)
			                        			{
			                        				AOM_UIF_ask_value(EPAObjectS[ItrEPA],"date_released", &TempEPARLZDate);
													AOM_UIF_ask_value(EPAObjectS[ItrEPA],"t5_TryoutDate", &TempEPATryOutDate);
													tc_strcpy(TempRlzStatus,"STDSIL Released");
													tc_strcpy(RptEPANumber,EPAName);
													tc_strcpy(RptEPARlzStatus,TempRlzStatus);
													tc_strcpy(RptEPATryOutDate,TempEPATryOutDate);
													tc_strcpy(RptEPARlzDate,TempEPARLZDate);
													tc_strcpy(RptEPACurrentStatus,"");
													tc_strcpy(RptEPAMBPANum,"");
													continue;
			                        			}
												else
												{
													tc_strcpy(TempEPARLZDate,"");
													tc_strcpy(TempEPATryOutDate,"");
													tc_strcpy(TempRlzStatus,"STDSIL Working");
													
													tc_strcpy(RptEPANumber,EPAName);
													tc_strcpy(RptEPARlzStatus,TempRlzStatus);
													tc_strcpy(RptEPATryOutDate,TempEPATryOutDate);
													tc_strcpy(RptEPARlzDate,TempEPARLZDate);
													tc_strcpy(RptEPACurrentStatus,"");
													tc_strcpy(RptEPAMBPANum,"");
												}
			                        		}
			                        	}
			                        }
	                        	}
	                        }
							if(strcmp(Plant,"DWD")==0)
	                        {
								char* EPAName = NULL;
								EPAFoundForPlant = 1;
								if( AOM_ask_value_string(EPAObjectS[ItrEPA],"item_id",&EPAName)!=ITK_ok);
								//printf("\n EPAName = %s",EPAName);fflush(stdout);
	                        	if((strstr(EPAName,"DM") != NULL) || (strstr(EPAName,"DR") != NULL))
	                        	{
	                        	    if( AOM_ask_value_string(EPAObjectS[ItrEPA],"item_id",&EPAName)!=ITK_ok);
									
									int StCnt = 0;
									tag_t* EPARlzStatList = NULLTAG; 
									ITKCALL(WSOM_ask_release_status_list(EPAObjectS[ItrEPA],&StCnt,&EPARlzStatList));
									
									if(StCnt>0)
			                        {
										int cnt = 0;
			                        	for (cnt=0;cnt< StCnt;cnt++ )
			                        	{
			                        		char* TempRlzStatusName = NULL;
			                        		char* TempEPARLZDate    = NULL;
			                        		char* TempEPATryOutDate = NULL;
											char* TempRlzStatus     = NULL;
											TempRlzStatus = (char *)MEM_alloc(100 * sizeof(char *));
											TempRlzStatusName = (char *)MEM_alloc(100 * sizeof(char *));
											TempEPARLZDate = (char *)MEM_alloc(100 * sizeof(char *));
											TempEPATryOutDate = (char *)MEM_alloc(100 * sizeof(char *));
			                        		AOM_ask_value_string(EPARlzStatList[cnt],"object_name", &TempRlzStatusName);
			                        		//printf("\n TempRlzStatusName is :%s\n",TempRlzStatusName);fflush(stdout);
			                        		if(tc_strcmp(TempRlzStatusName,"")!=0)
			                        		{
			                        			if (tc_strcmp(TempRlzStatusName,"T5_LcsStddRlzd")==0)
			                        			{
			                        				AOM_UIF_ask_value(EPAObjectS[ItrEPA],"date_released", &TempEPARLZDate);
													AOM_UIF_ask_value(EPAObjectS[ItrEPA],"t5_TryoutDate", &TempEPATryOutDate);
													tc_strcpy(TempRlzStatus,"STDSID Released");
													tc_strcpy(RptEPANumber,EPAName);
													tc_strcpy(RptEPARlzStatus,TempRlzStatus);
													tc_strcpy(RptEPATryOutDate,TempEPATryOutDate);
													tc_strcpy(RptEPARlzDate,TempEPARLZDate);
													tc_strcpy(RptEPACurrentStatus,"");
													tc_strcpy(RptEPAMBPANum,"");
													continue;
			                        			}
												else
												{
													tc_strcpy(TempEPARLZDate,"");
													tc_strcpy(TempEPATryOutDate,"");
													tc_strcpy(TempRlzStatus,"STDSID Working");
													
													tc_strcpy(RptEPANumber,EPAName);
													tc_strcpy(RptEPARlzStatus,TempRlzStatus);
													tc_strcpy(RptEPATryOutDate,TempEPATryOutDate);
													tc_strcpy(RptEPARlzDate,TempEPARLZDate);
													tc_strcpy(RptEPACurrentStatus,"");
													tc_strcpy(RptEPAMBPANum,"");
												}
			                        		}
			                        	}
			                        }
	                        	}
	                        }
							if(strcmp(Plant,"UTK")==0)
	                        {
								char* EPAName = NULL;
								EPAFoundForPlant = 1;
								if( AOM_ask_value_string(EPAObjectS[ItrEPA],"item_id",&EPAName)!=ITK_ok);
								//printf("\n EPAName = %s",EPAName);fflush(stdout);
	                        	if((strstr(EPAName,"BM") != NULL))
	                        	{
	                        	    if( AOM_ask_value_string(EPAObjectS[ItrEPA],"item_id",&EPAName)!=ITK_ok);
									
									int StCnt = 0;
									tag_t* EPARlzStatList = NULLTAG; 
									ITKCALL(WSOM_ask_release_status_list(EPAObjectS[ItrEPA],&StCnt,&EPARlzStatList));
									
									if(StCnt>0)
			                        {
										int cnt = 0;
			                        	for (cnt=0;cnt< StCnt;cnt++ )
			                        	{
			                        		char* TempRlzStatusName = NULL;
			                        		char* TempEPARLZDate    = NULL;
			                        		char* TempEPATryOutDate = NULL;
											char* TempRlzStatus     = NULL;
											TempRlzStatus = (char *)MEM_alloc(100 * sizeof(char *));
											TempRlzStatusName = (char *)MEM_alloc(100 * sizeof(char *));
											TempEPARLZDate = (char *)MEM_alloc(100 * sizeof(char *));
											TempEPATryOutDate = (char *)MEM_alloc(100 * sizeof(char *));
			                        		AOM_ask_value_string(EPARlzStatList[cnt],"object_name", &TempRlzStatusName);
			                        		//printf("\n TempRlzStatusName is :%s\n",TempRlzStatusName);fflush(stdout);
			                        		if(tc_strcmp(TempRlzStatusName,"")!=0)
			                        		{
			                        			if (tc_strcmp(TempRlzStatusName,"T5_LcsStduRlzd")==0)
			                        			{
			                        				AOM_UIF_ask_value(EPAObjectS[ItrEPA],"date_released", &TempEPARLZDate);
													AOM_UIF_ask_value(EPAObjectS[ItrEPA],"t5_TryoutDate", &TempEPATryOutDate);
													tc_strcpy(TempRlzStatus,"STDSIU Released");
													tc_strcpy(RptEPANumber,EPAName);
													tc_strcpy(RptEPARlzStatus,TempRlzStatus);
													tc_strcpy(RptEPATryOutDate,TempEPATryOutDate);
													tc_strcpy(RptEPARlzDate,TempEPARLZDate);
													tc_strcpy(RptEPACurrentStatus,"");
													tc_strcpy(RptEPAMBPANum,"");
													continue;
			                        			}
												else
												{
													tc_strcpy(TempEPARLZDate,"");
													tc_strcpy(TempEPATryOutDate,"");
													tc_strcpy(TempRlzStatus,"STDSIU Working");
													
													tc_strcpy(RptEPANumber,EPAName);
													tc_strcpy(RptEPARlzStatus,TempRlzStatus);
													tc_strcpy(RptEPATryOutDate,TempEPATryOutDate);
													tc_strcpy(RptEPARlzDate,TempEPARLZDate);
													tc_strcpy(RptEPACurrentStatus,"");
													tc_strcpy(RptEPAMBPANum,"");
												}
			                        		}
			                        	}
			                        }
	                        	}
	                        }
						}
					}
				}
				if (EPAFoundForPlant ==1)
				{
					break;
				}
			}
			if(EPAFoundForPlant == 1)
			{
				break;
			}
			
		}
	}
}

void GetTaskDetails(tag_t* SetOfTasks,int TaskIndex,char *WFname, char *DoTask, char *RevTask, char *ReleaseAttr, char *AckTask, char *AmbienceUsr,FILE* Report)
{
	int ItrTsk = 0;
	int CounterTaskObjct = 0;
	fprintf(Report,"Form date:,%s",FromDate);fflush(stdout);
	fprintf(Report,"\nTo date:,%s",ToDate);fflush(stdout);
	fprintf(Report,"\nAgency:,%s",Agency);fflush(stdout);
	fprintf(Report,"\nPlant:,%s",Plant);fflush(stdout);
	fprintf(Report,"\n\nSL No,Task Number,ERC Release Date,Assigned Analyst,TASK Released / Parked,Current Analyst,STDS Planner Assign Date,STDS Planner Clearance date,APL/STDS Remarks,STDS Task Decision,STDS Closure Comment,EPA NO,EPA Release status,EPA Trial date,EPA Release date,EPA Current status,MBPA NO");fflush(stdout);
	for(ItrTsk = 0;ItrTsk< TaskIndex;ItrTsk++)
	{
		tag_t TaskTagObject = NULLTAG;
		TaskTagObject = SetOfTasks[ItrTsk];
		
		char* RptTaskName = NULL;
		char* RptAnalyst = NULL;
		char* RptAssignedAnalyst = NULL;
		char* RptAnaReceivedDate = NULL;
		char* TaskNameDup = NULL;
		char* RptAnaEndDate = NULL;
		char* RptERCDMLRlzDate = NULL;
		char* RptTaskReleaseStat = NULL;
		char* RptTskAplStdRemrks = NULL;
		char* RptTskStdDecision = NULL;
		char* RptTskClosureComments = NULL;
		char* RptCounterTaskObj = NULL;
		
		TaskNameDup = (char *)MEM_alloc(100 * sizeof(char *));
		RptAnalyst  = (char *)MEM_alloc(100 * sizeof(char *));
		RptAssignedAnalyst  = (char *)MEM_alloc(100 * sizeof(char *));
		RptAnaReceivedDate  = (char *)MEM_alloc(100 * sizeof(char *));
		RptAnaEndDate  = (char *)MEM_alloc(100 * sizeof(char *));
		RptTaskReleaseStat  = (char *)MEM_alloc(100 * sizeof(char *));
		RptTskAplStdRemrks  = (char *)MEM_alloc(100 * sizeof(char *));
		RptTskStdDecision  = (char *)MEM_alloc(100 * sizeof(char *));
		RptTskClosureComments  = (char *)MEM_alloc(100 * sizeof(char *));
		RptCounterTaskObj =    (char *) MEM_alloc(5);
		
		ITK_CALL(AOM_ask_value_string(TaskTagObject,"item_id",&RptTaskName));
		tc_strcpy(TaskNameDup,RptTaskName);
		//printf("\n RptTaskName = %s",RptTaskName);fflush(stdout);
		
		sprintf(RptCounterTaskObj,"%d",(CounterTaskObjct+1));
		
		char* ERCDMLDtl = NULL;
        char* ERCDMLRlzDateDup = NULL;
        RptERCDMLRlzDate = (char *)MEM_alloc(100 * sizeof(char *));
        ERCDMLRlzDateDup = (char *)MEM_alloc(100 * sizeof(char *));
        ERCDMLDtl = strtok(TaskNameDup,"_");
        ERCDMLRlzDateDup =  GetERCDMLRlzDate(ERCDMLDtl);
        if(tc_strcmp(ERCDMLRlzDateDup,"") != 0)
        {
            tc_strcpy(RptERCDMLRlzDate,ERCDMLRlzDateDup);
        }
        else
        {
            tc_strcpy(RptERCDMLRlzDate,"");
        }
		
		char* taskRelStat = NULL;
		ITK_CALL(AOM_UIF_ask_value(TaskTagObject, "release_status_list", &taskRelStat));
        STRNG_replace_str(taskRelStat, ",", ";", &RptTaskReleaseStat);
		
		ITK_CALL(AOM_ask_value_string(TaskTagObject,"t5_AplStdRemrks",&RptTskAplStdRemrks));
        ITK_CALL(AOM_ask_value_string(TaskTagObject,"t5_StdTaskDecision",&RptTskStdDecision));
        ITK_CALL(AOM_ask_value_string(TaskTagObject,"CMClosureComments",&RptTskClosureComments));
		
		int cntWF = 0;
		tag_t *WFTag = NULLTAG;
		ITK_CALL(AOM_ask_value_tags(TaskTagObject, "fnd0AllWorkflows", &cntWF, &WFTag));
		int ItrWF = 0;
		for (ItrWF = 0; ItrWF < cntWF; ItrWF++)
		{
			char *WFObj = NULL;
			char *reviewAPI = NULL;
			reviewAPI = (char *)MEM_alloc(50 * sizeof(char *));
			
			ITK_CALL(AOM_UIF_ask_value(WFTag[ItrWF], "object_name", &WFObj));
			printf("\n WF Object Name = %s", WFObj);
			if ((tc_strcmp(WFObj, WFname) == 0) || (tc_strcmp(WFObj, "Partial Task Lifecycle") == 0))
            {
				char *WFStatus = NULL;
                ITK_CALL(AOM_UIF_ask_value(WFTag[ItrWF], "fnd0Status", &WFStatus));
                printf("WFStatus = %s\n", WFStatus);
                if (tc_strcmp(WFStatus, "Completed") == 0)
                {
                    tc_strcpy(reviewAPI,"fnd0Performer");
                }
                else
				{
                    tc_strcpy(reviewAPI,"awp0Reviewers");
				}

                printf("reviewer API - %s",reviewAPI);
				
				int cntTsk = 0;
				tag_t* tskTag = NULLTAG;
                ITK_CALL(AOM_ask_value_tags(WFTag[ItrWF], "fnd0ActuatedInteractiveTsks", &cntTsk, &tskTag));
                int doTskFlg = 0;
				int j = 0;
                for ( j = 0; j < cntTsk; j++)
                {
					char* tskObj = NULL;
                    ITK_CALL(AOM_UIF_ask_value(tskTag[j], "object_name", &tskObj));
                    printf("\n Child Task Object  = %s", tskObj);
					char* taskType = NULL;
                    ITK_CALL(AOM_UIF_ask_value(tskTag[j], "object_type", &taskType));
                    printf("\n Child Task Type  = = %s", taskType);
                    if (tc_strcmp(taskType, "Do Task") == 0 || tc_strcmp(taskType, "Review Task") == 0 || tc_strcmp(taskType, "Acknowledge Task") == 0)
                    {
						char* anaReceivedDate = NULL;
                        if (tc_strcmp(tskObj, AckTask) == 0)
                        {
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0StartDate", &anaReceivedDate));
                            printf("anaReceivedDate = %s\n", anaReceivedDate);
							tc_strcpy(RptAnaReceivedDate,anaReceivedDate);
							
							char* AssignedAnalyst = NULL;
							ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0Performer", &AssignedAnalyst));
                            printf("\n AssignedAnalyst = %s", AssignedAnalyst);
							tc_strcpy(RptAssignedAnalyst,AssignedAnalyst);
							
                        }

                        printf("DoTask = %s\n", DoTask);

                        if (tc_strcmp(tskObj, DoTask) == 0)
                        {
                            printf("Inside do task compare\n");
                            doTskFlg++;
							char* analyst = NULL;
							char* anaEndDate = NULL;
							char* anaCom = NULL;
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0Performer", &analyst));
                            printf("\n analyst = %s", analyst);
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0EndDate", &anaEndDate));
                            printf("\n anaEndDate = %s", anaEndDate);
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "comments", &anaCom));
                            printf("\n anaCom = %s", anaCom);
							tc_strcpy(RptAnalyst,analyst);
							tc_strcpy(RptAnaEndDate,anaEndDate);
							
							if(tc_strstr(RptTaskName,"PR") !=NULL)
							{
								ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0StartDate", &anaReceivedDate));
								printf("anaReceivedDate = %s\n", anaReceivedDate);
								tc_strcpy(RptAnaReceivedDate,anaReceivedDate);
							}
                            
                        }
                    }
                }

                for ( j = 0; j < cntTsk; j++)
                {
					char* taskType = NULL;
                    ITK_CALL(AOM_UIF_ask_value(tskTag[j], "object_type", &taskType));

                    if (tc_strcmp(taskType, "Do Task") == 0 || tc_strcmp(taskType, "Review Task") == 0 || tc_strcmp(taskType, "Acknowledge Task") == 0)
                    {
                        if (doTskFlg > 0)
                        {
							char* tskObj = NULL;
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "object_name", &tskObj));
                            printf("tskObj = %s\n", tskObj);
                            if (tc_strcmp(tskObj, RevTask) == 0)
                            {
								char* reviewers = NULL;
								char* reviewer = NULL;
								char* revReceiveDate = NULL;
								char* revEndDate = NULL;
								char* revCom = NULL;
								reviewer = (char *)MEM_alloc(50 * sizeof(char *));
                                ITK_CALL(AOM_UIF_ask_value(tskTag[j], reviewAPI, &reviewers));
                                STRNG_replace_str(reviewers, ",", ";", &reviewer);
                                printf("reviewer = %s\n", reviewer);

                                ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0StartDate", &revReceiveDate));
                                printf("revReceiveDate = %s\n", revReceiveDate);
                                ITK_CALL(AOM_UIF_ask_value(tskTag[j], "fnd0EndDate", &revEndDate));
                                printf("revEndDate = %s\n", revEndDate);
                                ITK_CALL(AOM_UIF_ask_value(tskTag[j], "comments", &revCom));
                                printf("revCom = %s\n", revCom);
                            }
                        }
                        else
                        {
                            char* tskObj = NULL;
                            ITK_CALL(AOM_UIF_ask_value(tskTag[j], "object_name", &tskObj));
                            if (tc_strcmp(tskObj, AckTask) == 0)
                            {
								char* analysts = NULL;
								char* analyst = NULL;
								analyst = (char *)MEM_alloc(100 * sizeof(char *));
                                ITK_CALL(AOM_UIF_ask_value(tskTag[j], "awp0Acknowledgers", &analysts));
                                STRNG_replace_str(analysts, ",", ";", &analyst);
                                printf("analyst = %s\n", analyst);
								tc_strcpy(RptAnalyst,analyst);
                            }
                        }
                    }
                }
            }
		}
		
		
		printf("\n RptTaskName:%s========>RptAnalyst: %s========>RptAnaReceivedDate: %s========>RptAnaEndDate: %s",RptTaskName,RptAnalyst,RptAnaReceivedDate,RptAnaEndDate);fflush(stdout);
		char*      RptEPANumber           = NULL;
	    char*      RptEPARlzStatus        = NULL;
	    char*      RptEPATryOutDate       = NULL;
	    char*      RptEPARlzDate          = NULL;
	    char*      RptEPACurrentStatus    = NULL;
	    char*      RptEPAMBPANum          = NULL;
		
		if(tc_strstr(RptTaskName,"PR")!=NULL)
		{
			AOM_UIF_ask_value(TaskTagObject,"owning_user",&RptAssignedAnalyst);
			printf("\n PR RptAssignedAnalyst =%s",RptAssignedAnalyst);fflush(stdout);
		}
	    
	    RptEPANumber = (char *) MEM_alloc(100);
	    RptEPARlzStatus = (char *) MEM_alloc(100);
	    RptEPATryOutDate = (char *) MEM_alloc(100);
	    RptEPARlzDate = (char *) MEM_alloc(100);
	    RptEPACurrentStatus = (char *) MEM_alloc(100);
	    RptEPAMBPANum = (char *) MEM_alloc(100);
		GetEPAInformation(TaskTagObject,RptEPANumber,RptEPARlzStatus,RptEPATryOutDate,RptEPARlzDate,RptEPACurrentStatus,RptEPAMBPANum);
		printf("\n RptEPANumber:%s========>RptEPARlzStatus: %s========>RptEPATryOutDate: %s========>RptEPARlzDate: %s========>RptEPACurrentStatus: %s=======>RptEPAMBPANum: %s",RptEPANumber,RptEPARlzStatus,RptEPATryOutDate,RptEPARlzDate,RptEPACurrentStatus,RptEPAMBPANum);fflush(stdout);
		fprintf(Report,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,",
		RptCounterTaskObj,
		RptTaskName,
		RptERCDMLRlzDate,
		RptAssignedAnalyst,
		RptTaskReleaseStat,
		RptAnalyst,
		RptAnaReceivedDate,
		RptAnaEndDate,
		RptTskAplStdRemrks,
		RptTskStdDecision,
		RptTskClosureComments,
		RptEPANumber,
		RptEPARlzStatus,
		RptEPATryOutDate,
		RptEPARlzDate,
		RptEPACurrentStatus,
		RptEPAMBPANum);fflush(stdout);
	}
	fprintf(Report,"\n\n\n Report Completed");fflush(stdout);
	fclose(Report);
}

void GenrateDMLMISReport()
{
	
	char *FromdateDup = NULL;
	char *FromdateDup1 = NULL;
	char *ToDateDup = NULL;
	char *ToDateDup1 = NULL;
	FILE *Report = NULL;
	
	ReportFileName=(char*) MEM_alloc(200);
	FromdateDup1=(char*) MEM_alloc(10);
	ToDateDup1=(char*) MEM_alloc(10);
	
	
	struct tm *timeinfo;
    time_t t3;
    time_t t1;
    char buffer[256];   
    t1 = time(NULL);
    t3 = shiftDate(t1,0);
    timeinfo = localtime(&t3);
	char 	*RptTimestamp = NULL;
	RptTimestamp = (char *) MEM_alloc(100 * sizeof(char *));
	RptTimestamp = asctime(timeinfo);
	printf("\n%s",RptTimestamp);fflush(stdout);
	
	char * txt1 = NULL;
	char * MonthVal = NULL;
	char * DateVal = NULL;
	char * txt4 = NULL;
	char * YearVal = NULL;
	char * YearVal1 = NULL;
	char * txt6 = NULL;
	txt1 = strtok(RptTimestamp," ");
	MonthVal = strtok(NULL," ");
	DateVal = strtok(NULL," ");
	txt4 = strtok(NULL," ");
	YearVal = strtok(NULL,"");
	YearVal1 = (char *) MEM_alloc(100 * sizeof(char *));
	
	STRNG_replace_str(YearVal,"\n","",&YearVal1);
    printf("\n Start Time..Of Report Generation..%s",MonthVal);fflush(stdout);
    printf("\n Start Time..Of Report Generation..%s",DateVal);fflush(stdout);
    printf("\n Start Time..Of Report Generation..%s",YearVal1);fflush(stdout);
    
	char* StartDate = NULL;
	char* EndDate = NULL;
	StartDate = (char *) MEM_alloc(100 * sizeof(char *));
	EndDate = (char *) MEM_alloc(100 * sizeof(char *));
	
	strcpy(EndDate,DateVal);
	strcat(EndDate,"-");
	strcat(EndDate,MonthVal);
	strcat(EndDate,"-");
	strcat(EndDate,YearVal1);
	strcpy(EndDate,ToDate);
	strcpy(StartDate,FromDate);
	
	
	FromdateDup = strdup(StartDate);
	ToDateDup = strdup(EndDate);
	
	STRNG_replace_str(FromdateDup,"-","_",&FromdateDup1);
	STRNG_replace_str(ToDateDup,"-","_",&ToDateDup1);
	tc_strcpy(ReportFileName,"");
	tc_strcat(ReportFileName,Plant);
	tc_strcat(ReportFileName,"_");
	tc_strcat(ReportFileName,"DML_MIS_REPORT_From_");
	tc_strcat(ReportFileName,FromdateDup1);
	tc_strcat(ReportFileName,"_To_");
	tc_strcat(ReportFileName,ToDateDup1);
	tc_strcat(ReportFileName,".csv");
	Report = fopen(ReportFileName,"w");
	
	
	
	
	
	
	
	
	
	
	
	
	
	char *WFname, *DoTask, *RevTask, *ReleaseAttr, *AckTask;
    char *OwningGrp = (char*)MEM_alloc(10);
    char *APLTsk = (char *)MEM_alloc(10);
    char *STDTsk = (char *)MEM_alloc(10);
    char *TskName;
    char *Analyst;
    char *AmbienceUsr;
	int TaskIndex = 0;
    tag_t*      SetOfTasks = NULLTAG;
		
	tc_strcpy(APLTsk,"APL");
    tc_strcpy(STDTsk,"STD");
    printf("\n APL Name %s",APLTsk);
    tc_strcat(STDTsk,OwningGrp);
    printf("\n STDSI Name %s",STDTsk);
	tc_strcpy(OwningGrp,subString_DMLBWDate(Plant,0,1));
	tc_strcat(APLTsk,OwningGrp);
	printf("\n OwningGrp = %s",OwningGrp);
	printf("\n APLTsk = %s",APLTsk);
	
	char *FileName = (char *)MEM_alloc(100 * sizeof(char *));
    char reportFireDate[100] = "";

    time_t now;
    struct tm when;
    time(&now);
    when = *localtime(&now);
    strftime(reportFireDate, 100, "%d_%b_%Y_%H_%M_%S", &when);
	FILE *OutputFile;
	
	printf("\n FromDate = %s\n", FromDate);fflush(stdout);
    printf("\n ToDate   = %s\n", ToDate);fflush(stdout);
    printf("\n Agency   = %s\n", Agency);fflush(stdout);
    printf("\n Report Fire Date = %s\n", reportFireDate);
    fflush(stdout);
    printf("File name = %s\n", FileName);
	
	char *qryAgencyInfo[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char *qryAgencyValues[3] = {"DMLBWRPT", Agency, "0"};

    tag_t qryTagAgency = NULLTAG;
    int   qryCountA = 0;
    tag_t *qryResultA = NULLTAG;
	ITKCALL(QRY_find2("Control Objects...", &qryTagAgency));
	if (qryTagAgency)
    {
        printf("\n Control Object Query Found \n ");
        fflush(stdout);
        ITKCALL(QRY_execute(qryTagAgency, 3, qryAgencyInfo, qryAgencyValues, &qryCountA, &qryResultA));

        if (qryCountA > 0)
        {
            AOM_ask_value_string(qryResultA[0], "t5_Userinfo1", &WFname);      // STDSI Task BreakDown
            AOM_ask_value_string(qryResultA[0], "t5_Userinfo2", &DoTask);      // Create EPA
            AOM_ask_value_string(qryResultA[0], "t5_Userinfo3", &RevTask);     // Review the Changes
            AOM_ask_value_string(qryResultA[0], "t5_Userinfo4", &ReleaseAttr); // date_released
            AOM_ask_value_string(qryResultA[0], "t5_Userinfo5", &AckTask);     // Acknowledge Task
        }
    }
	printf("\n WFname =%s",WFname);fflush(stdout);
	printf("\n DoTask =%s",DoTask);fflush(stdout);
	printf("\n RevTask =%s",RevTask);fflush(stdout);
	printf("\n ReleaseAttr =%s",ReleaseAttr);fflush(stdout);
	printf("\n AckTask =%s",AckTask);fflush(stdout);
	
	
	// Control Object for all ambience users
    char *qryAmbienceInfo[4] = {"Name","SYSCD", "SUBSYSCD","Delete Indicator"};
    char *qryAmbienceValues[4] = {"DMLBWRPT",Agency,Plant, "0"};
    int   qryCountAmb = 0;
    tag_t *qryResultAmb = NULLTAG;

    ITKCALL(QRY_find2("Control Objects...", &qryTagAgency));
    if (qryTagAgency)
    {
        printf("\n Control Object Query Found \n ");
        fflush(stdout);
        ITKCALL(QRY_execute(qryTagAgency, 4, qryAmbienceInfo, qryAmbienceValues, &qryCountAmb, &qryResultAmb));

        if (qryCountAmb > 0)
        {
            AOM_ask_value_string(qryResultAmb[0], "t5_Userinfo1", &AmbienceUsr); //Ambience User
            printf("\n AmbienceUsr - %s\n",AmbienceUsr);
        }
    }
    // Control Object for all ambience users
	
	
	
	if (qryCountA > 0)
    {
        char **qry_entries = (char **)MEM_alloc(10 * sizeof(char *));
        char **qry_values = (char **)MEM_alloc(10 * sizeof(char *));
        tag_t queryTag = NULLTAG;
        qry_entries[0] = "WF_name";
        qry_entries[1] = "Created After";
        qry_entries[2] = "Created Before";

        qry_values[0] = WFname;
        qry_values[1] = FromDate;
        qry_values[2] = ToDate;

        char *keys[1] = {(char *)"fnd0StartDate"};
        int orders[1] = {2};

        int countWF;
        tag_t *resultWF;

        ITK_CALL(QRY_find2("EPMTaskWF", &queryTag));
        ITK_CALL(QRY_execute_with_sort(queryTag, 3, qry_entries, qry_values, 1, keys, orders, &countWF, &resultWF));

        char *TaskObj, *taskType;
        tag_t WFTag;
        int cntTask;
        tag_t *taskTag;

        
        if (countWF > 0)
        {
			int Itr = 0;
            for (Itr = 0; Itr < countWF; Itr++)
            {

                WFTag = resultWF[Itr];
                ITK_CALL(AOM_UIF_ask_value(WFTag, "task_type", &taskType));
                if (tc_strcmp(taskType, "EPMDoTask") == 0 || tc_strcmp(taskType, "EPMPerformSignoffTask") == 0 || tc_strcmp(taskType, "EPMAcknowledgeTask") == 0)
                {
                    ITK_CALL(AOM_UIF_ask_value(WFTag, "object_name", &TaskObj));
					printf("\n TaskObj = %s",TaskObj);fflush(stdout);
                    if (tc_strcmp(TaskObj, DoTask) == 0 || tc_strcmp(TaskObj, RevTask) == 0)
                    {
                        ITK_CALL(AOM_UIF_ask_value(WFTag, "root_target_attachments", &TskName));
                        ITK_CALL(AOM_UIF_ask_value(WFTag, "fnd0Performer", &Analyst));
                        printf("\n Analyst = %s\n", Analyst);

                        if(tc_strstr(TskName,APLTsk) != NULL)
                        {
                            
                            ITK_CALL(AOM_ask_value_tags(WFTag, "root_target_attachments", &cntTask, &taskTag));
							tag_t TaskTagPtr = NULLTAG;
							TaskTagPtr = taskTag[0];
							setofTagList(&TaskIndex,&SetOfTasks,TaskTagPtr);
                        }

                        if(tc_strcmp(Agency,"STDSI") == 0)
                        {

                            if(tc_strstr(TskName,STDTsk) != NULL)
                            {
                                ITK_CALL(AOM_ask_value_tags(WFTag, "root_target_attachments", &cntTask, &taskTag));
                                tag_t TaskTagPtr = NULLTAG;
								TaskTagPtr = taskTag[0];
								setofTagList(&TaskIndex,&SetOfTasks,TaskTagPtr);
                            }
                        }
                    }
                }
            }
        }
        else
		{
            printf("\n No Workflow Available");fflush(stdout);
		}
    }
    else
	{
        printf("\n Agency information not available");fflush(stdout);
	}
	
	/*PR Task Query*/
	char **qry_entries_PR = (char **)MEM_alloc(10 * sizeof(char *));
    char **qry_values_PR = (char **)MEM_alloc(10 * sizeof(char *));
    tag_t queryTag = NULLTAG;
    qry_entries_PR[0] = "WF_name";
    qry_entries_PR[1] = "Created After";
    qry_entries_PR[2] = "Created Before";

    qry_values_PR[0] = "Partial Task Lifecycle";
    qry_values_PR[1] = FromDate;
    qry_values_PR[2] = ToDate;

    char *keysPR[1] = {(char *)"fnd0StartDate"};
    int ordersPR[1] = {2};

    int countWFPR;
    tag_t *resultWFPR;

    ITK_CALL(QRY_find2("EPMTaskWF", &queryTag));
    ITK_CALL(QRY_execute_with_sort(queryTag, 3, qry_entries_PR, qry_values_PR, 1, keysPR, ordersPR, &countWFPR, &resultWFPR));

    char *PRTaskObj, *PRtaskType;
    tag_t PRWFTag;
    int prcntTask;
    tag_t *prtaskTag;
	
	if (countWFPR > 0)
	{
    	int Itr = 0;
        for (Itr = 0; Itr < countWFPR; Itr++)
        {

            PRWFTag = resultWFPR[Itr];
            ITK_CALL(AOM_UIF_ask_value(PRWFTag, "task_type", &PRtaskType));
            if (tc_strcmp(PRtaskType, "EPMDoTask") == 0 || tc_strcmp(PRtaskType, "EPMPerformSignoffTask") == 0 || tc_strcmp(PRtaskType, "EPMAcknowledgeTask") == 0)
            {
                ITK_CALL(AOM_UIF_ask_value(PRWFTag, "object_name", &PRTaskObj));			
				printf("\n PRTaskObj = %s",PRTaskObj);fflush(stdout);
				char* PRTskName = NULL;
				char* PRAnalyst = NULL;
                ITK_CALL(AOM_UIF_ask_value(PRWFTag, "root_target_attachments", &PRTskName));
                ITK_CALL(AOM_UIF_ask_value(PRWFTag, "fnd0Performer", &PRAnalyst));
                printf("\n PRAnalyst = %s\n", PRAnalyst);
                printf("\n PRTskName = %s\n", PRTskName);

                if(tc_strstr(PRTskName,APLTsk) != NULL)
                {
                    ITK_CALL(AOM_ask_value_tags(PRWFTag, "root_target_attachments", &prcntTask, &prtaskTag));				
					tag_t TaskTagPtr = NULLTAG;					
					TaskTagPtr = prtaskTag[0]	;
					printf("\n PR Task Added Into Set");
					setofTagList(&TaskIndex,&SetOfTasks,TaskTagPtr);
                }
               
            }
        }
    }
	
	GetTaskDetails(SetOfTasks,TaskIndex,WFname,DoTask,RevTask,ReleaseAttr,AckTask,AmbienceUsr,Report);
}


void MailReportToUser()
{
	char* ReportMail = NULL;
    ReportMail = (char *) MEM_alloc(1000);

    char* MailSubject = NULL;
    MailSubject = (char *) MEM_alloc(100);
    tc_strcpy(MailSubject,"DML MIS Report between ");
    tc_strcat(MailSubject,FromDate);
    tc_strcat(MailSubject," to ");
    tc_strcat(MailSubject,ToDate);


    sprintf(ReportMail,"(cat content )| Mail -s  \"%s\" -a %s -c `cat CC` %s",MailSubject,ReportFileName,mailIDList);
    //sprintf(ReportMail,"(cat content )| Mail -s  \"DML%s \" -a %s -c `cat CC` `cat TO` ",MailSubject,ReportFileName);
	//sprintf(DMLAgeReportMail,"(cat content.txt )| Mail -s  \"DML Age Analysis Report from 01-Jan-2024 to %s\" -a %s -c `cat cc.txt` `cat to.txt` ",EndDate,ReportFileName);
	//sprintf(UPLMBOMReportMail,"(cat content )| Mail -s  \"UPL/MBOM Report fired for the attached VC \" -a %s -c `cat CC` `cat TO` ",ReportFileName);
	
	
	
	printf("\n %s",ReportMail);fflush(stdout);
    int SysReturn = 0;
	printf("\n %s",ReportMail);fflush(stdout);
    SysReturn = system(ReportMail);
}

void GetMailIDList()
{
	
	
	char *AnalystRole = (char *)MEM_alloc(50 * sizeof(char));
	char *ReviewerRole = (char *)MEM_alloc(50 * sizeof(char));
	if(tc_strcmp(Plant,"JSR") == 0)
	{
		AnalystRole = tc_strcpy(AnalystRole, "*");
		AnalystRole = tc_strcat(AnalystRole, "STDJ_Analyst");
		AnalystRole = tc_strcat(AnalystRole, "*");
		
		ReviewerRole = tc_strcpy(ReviewerRole, "*");
		ReviewerRole = tc_strcat(ReviewerRole, "STDJ_Reviewer");
		ReviewerRole = tc_strcat(ReviewerRole, "*");
	}
	if(tc_strcmp(Plant,"LKO") == 0)
	{
		AnalystRole = tc_strcpy(AnalystRole, "*");
		AnalystRole = tc_strcat(AnalystRole, "STDL_Analyst");
		AnalystRole = tc_strcat(AnalystRole, "*");
		
		ReviewerRole = tc_strcpy(ReviewerRole, "*");
		ReviewerRole = tc_strcat(ReviewerRole, "STDL_Reviewer");
		ReviewerRole = tc_strcat(ReviewerRole, "*");
	}
	if(tc_strcmp(Plant,"PUNE") == 0)
	{
		AnalystRole = tc_strcpy(AnalystRole, "*");
		AnalystRole = tc_strcat(AnalystRole, "STDP_Analyst");
		AnalystRole = tc_strcat(AnalystRole, "*");
		
		ReviewerRole = tc_strcpy(ReviewerRole, "*");
		ReviewerRole = tc_strcat(ReviewerRole, "STDP_Reviewer");
		ReviewerRole = tc_strcat(ReviewerRole, "*");
	}
	if(tc_strcmp(Plant,"DWD") == 0)
	{
		AnalystRole = tc_strcpy(AnalystRole, "*");
		AnalystRole = tc_strcat(AnalystRole, "STDD_Analyst");
		AnalystRole = tc_strcat(AnalystRole, "*");
		
		ReviewerRole = tc_strcpy(ReviewerRole, "*");
		ReviewerRole = tc_strcat(ReviewerRole, "STDD_Reviewer");
		ReviewerRole = tc_strcat(ReviewerRole, "*");
	}
	if(tc_strcmp(Plant,"UTK") == 0)
	{
		AnalystRole = tc_strcpy(AnalystRole, "*");
		AnalystRole = tc_strcat(AnalystRole, "STDU_Analyst");
		AnalystRole = tc_strcat(AnalystRole, "*");
		
		ReviewerRole = tc_strcpy(ReviewerRole, "*");
		ReviewerRole = tc_strcat(ReviewerRole, "STDU_Reviewer");
		ReviewerRole = tc_strcat(ReviewerRole, "*");
	}
	
	int userNumberFound;
    tag_t *membersFound;
    tag_t *groupsFound;
    tag_t *rolesFound;
    tag_t *usersFound;
	char *usersFoundString;
    char *usersFoundName;
    char *usersFoundMail;
	int Itr= 0;
	int MaxItr = 2;
	for(Itr =0;Itr<MaxItr;Itr++)
	{
		if (Itr == 0)
		{
			SA_find_group_members(GroupNm, AnalystRole, NULL, NULL, FALSE, FALSE, &userNumberFound, &membersFound, &groupsFound, &rolesFound, &usersFound);
		}
		if (Itr == 1)
		{
			SA_find_group_members(GroupNm, ReviewerRole, NULL, NULL, FALSE, FALSE, &userNumberFound, &membersFound, &groupsFound, &rolesFound, &usersFound);
		}
		int UserCnt = 0;
	    int countUserSet = 0;
        char **userList = NULL;
	    
        int countUserNameSet = 0;
        char **userNameList = NULL;
	    int countPerson;
        tag_t *resultPerson;
	    for (UserCnt = 0; UserCnt < userNumberFound; UserCnt++)
	    {
	    	int found;
            ITK_CALL(AOM_ask_value_string(usersFound[UserCnt], "user_id", &usersFoundString));
            ITK_CALL(AOM_ask_value_string(usersFound[UserCnt], "user_name", &usersFoundName));
	    	printf("\n usersFoundString =%s",usersFoundString);fflush(stdout);
	    	printf("\n usersFoundName =%s",usersFoundName);fflush(stdout);
            setFindStr_QryWLUser(countUserSet, userList, usersFoundString, &found);
            if (found == -1)
            {
                setAdd_QryWLUser(&countUserSet, &userList, usersFoundString);
                setAdd_QryWLUser(&countUserNameSet, &userNameList, usersFoundName);
	    
                ITK_CALL(AOM_ask_value_tags(usersFound[UserCnt], "person", &countPerson, &resultPerson));
                ITK_CALL(AOM_ask_value_string(resultPerson[0], "PA9", &usersFoundMail));
	    
                if (mailIDList == NULL)
                {
                    mailIDList = (char *)MEM_alloc(5000 * sizeof(char));
                    tc_strcpy(mailIDList, usersFoundMail);
                }
                else
                {
                    tc_strcat(mailIDList, ",");
                    tc_strcat(mailIDList, usersFoundMail);
                }
            }
	    }
	}
	printf("\n mailIDList =%s",mailIDList);fflush(stdout);
	tc_strcpy(mailIDList,"ab922284.ttl@tatamotors.com");
}

/*******MAIN FUNCTION************/

extern int ITK_user_main (int argc, char* argv[])
{
	int		    status;
    char        *InputList      = NULL;
	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login ());
	
	GetReportTimeStamp();
	
	FromDate = ITK_ask_cli_argument("-fd="); 
    ToDate = ITK_ask_cli_argument("-td="); 
    Agency = ITK_ask_cli_argument("-agen=");
    Plant = ITK_ask_cli_argument("-plant="); 
    GroupNm = ITK_ask_cli_argument("-Grp="); 
	printf("\n FromDate = %s",FromDate);fflush(stdout);
	printf("\n ToDate = %s",ToDate);fflush(stdout);
	printf("\n Agency = %s",Agency);fflush(stdout);
	printf("\n Plant = %s",Plant);fflush(stdout);
	printf("\n GroupNm = %s",GroupNm);fflush(stdout);
	
	
	GenrateDMLMISReport();
	GetMailIDList();
	MailReportToUser();
	return status;
}