/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  File				:   GetESData.c
*  Author			:   Dhanashri Shirsath
*  Module			:   TCUA Downloader.
*  Purpose			:   To get Estimate Sheet for migration to TCUA
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#include <cl.h>
#include <usc.h>
#include <pdmroot.h>
#include <pdmsessn.h>
#include <relation.h>
#include <pdmc.h>
#include <msglcm.h>
#include <msgapc.h>
#include <msgtel.h>
#include <status.h>
#include <sc.h>
#include <ft.h>
//#include <ReadFile.h>
#include <tel.h>
#include <Mtimsgh.h>
#define NUMBER 5000

char* ChangeDateFormat(char*,  char*,  char*, char *, char *);
char* subString(char* ,int ,int);

status GetESOprInfo(ObjectPtr TCPartObjP,FILE* fp,integer* mfail )
{
	string t5PartNumber=NULL;
	string t5PartNumberDup=NULL;
	string t5PartNumberRev=NULL;
	string t5PartNumberRevDup=NULL;
	string t5PartNumberSeq=NULL;
	string t5PartNumberSeqDup=NULL;

	int i=0;

	SetOfObjects	EstOperationObjs = NULL;

	ObjectPtr		OprtnObj		= NULL;

	t5MethodInit("GetESOprInfo");

	if(dstat=objGetAttribute(TCPartObjP,"t5PEPartNumber",&t5PartNumber))goto EXIT;
	if(!nlsIsStrNull(t5PartNumber))t5PartNumberDup=nlsStrDup(t5PartNumber);
	printf("\n t5PartNumberDup :%s",t5PartNumberDup);fflush(stdout);
	if(!nlsIsStrNull(t5PartNumberDup))
					{
						nlsStrTrimTrailWhiteSpace(t5PartNumberDup);
						if(nlsStrStr(t5PartNumberDup,"\n")!= NULL)
						{
							if(nlsStrStr(t5PartNumberDup,"\n")!= NULL) low_strrpl(t5PartNumberDup,'\n',';');
							printf("\n After Remove t5PartNumberDup==>[%s]\n",t5PartNumberDup);fflush(stdout);
						}
					}

	if(dstat=objGetAttribute(TCPartObjP,"Revision",&t5PartNumberRev))goto EXIT;
	if(!nlsIsStrNull(t5PartNumberRev))t5PartNumberRevDup=nlsStrDup(t5PartNumberRev);
	printf("\n t5PartNumberRevDup :%s",t5PartNumberRevDup);fflush(stdout);
	if(!nlsIsStrNull(t5PartNumberRevDup))
					{
						nlsStrTrimTrailWhiteSpace(t5PartNumberRevDup);
						if(nlsStrStr(t5PartNumberRevDup,"\n")!= NULL)
						{
							if(nlsStrStr(t5PartNumberRevDup,"\n")!= NULL) low_strrpl(t5PartNumberRevDup,'\n',';');
							printf("\n After Remove t5PartNumberRevDup==>[%s]\n",t5PartNumberRevDup);fflush(stdout);
						}
					}


	if(dstat=objGetAttribute(TCPartObjP,"Sequence",&t5PartNumberSeq))goto EXIT;
	if(!nlsIsStrNull(t5PartNumberSeq))t5PartNumberSeqDup=nlsStrDup(t5PartNumberSeq);
	printf("\n t5PartNumberSeqDup :%s",t5PartNumberSeqDup);fflush(stdout);
		if(!nlsIsStrNull(t5PartNumberSeqDup))
					{
						nlsStrTrimTrailWhiteSpace(t5PartNumberSeqDup);
						if(nlsStrStr(t5PartNumberSeqDup,"\n")!= NULL)
						{
							if(nlsStrStr(t5PartNumberSeqDup,"\n")!= NULL) low_strrpl(t5PartNumberSeqDup,'\n',';');
							printf("\n After Remove t5PartNumberSeqDup==>[%s]\n",t5PartNumberSeqDup);fflush(stdout);
						}
					}


    string ESShopDup=NULL;
	string ESShop=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5EstShop",&ESShop))goto EXIT;
	if(!nlsIsStrNull(ESShop)) ESShopDup=nlsStrDup(ESShop);
	printf("\n ESShopDup :%s",ESShopDup);fflush(stdout);
			if(!nlsIsStrNull(ESShopDup))
					{
						nlsStrTrimTrailWhiteSpace(ESShopDup);
						if(nlsStrStr(ESShopDup,"\n")!= NULL)
						{
							if(nlsStrStr(ESShopDup,"\n")!= NULL) low_strrpl(ESShopDup,'\n',';');
							printf("\n After Remove ESShopDup==>[%s]\n",ESShopDup);fflush(stdout);
						}
					}


	string EstPltNmDup=NULL;
	string EstPltNm=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEPlantName",&EstPltNm))goto EXIT;
	if(!nlsIsStrNull(EstPltNm)) EstPltNmDup=nlsStrDup(EstPltNm);
	printf("\n EstPltNmDup :%s",EstPltNmDup);fflush(stdout);
				if(!nlsIsStrNull(EstPltNmDup))
					{
						nlsStrTrimTrailWhiteSpace(EstPltNmDup);
						if(nlsStrStr(EstPltNmDup,"\n")!= NULL)
						{
							if(nlsStrStr(EstPltNmDup,"\n")!= NULL) low_strrpl(EstPltNmDup,'\n',';');
							printf("\n After Remove EstPltNmDup==>[%s]\n",EstPltNmDup);fflush(stdout);
						}
					}



	string EstEdnNoDup=NULL;
	string EstEdnNo=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEProcessEDNNo",&EstEdnNo))goto EXIT;
	if(!nlsIsStrNull(EstEdnNo)) EstEdnNoDup=nlsStrDup(EstEdnNo);
	printf("\n EstEdnNoDup :%s",EstEdnNoDup);fflush(stdout);
				if(!nlsIsStrNull(EstEdnNoDup))
					{
						nlsStrTrimTrailWhiteSpace(EstEdnNoDup);
						if(nlsStrStr(EstEdnNoDup,"\n")!= NULL)
						{
							if(nlsStrStr(EstEdnNoDup,"\n")!= NULL) low_strrpl(EstEdnNoDup,'\n',';');
							printf("\n After Remove EstEdnNoDup==>[%s]\n",EstEdnNoDup);fflush(stdout);
						}
					}



	//if(dstat = ExpandObject("t5PrEEE",TCPartObjP,"EshEl",&AllOprSO,&AllOprRelSO,mfail)) goto CLEANUP;
	if(dstat=ExpandObject5("t5PrEEE",TCPartObjP,"EshEl",SC_SCOPE_OF_SESSION,&EstOperationObjs,mfail)) goto EXIT; 
	if(*mfail) goto CLEANUP;
	printf("\n No of Estimate Operation : %d\n",setSize(EstOperationObjs)); fflush(stdout);

	if(setSize(EstOperationObjs)>0)
	{
		for(i=0;i<setSize(EstOperationObjs);i++)
			{

					if(!nlsIsStrNull(t5PartNumberDup))
					{
						fprintf(fp,"%s",t5PartNumberDup);			//PARTNUMBER;								
						fprintf(fp,"^");
					}
					else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5PartNumberRevDup))
					{
						fprintf(fp,"%s",t5PartNumberRevDup);			//PARTNUMBER;								
						fprintf(fp,"^");
					}
					else
					{
						fprintf(fp," ^");
					}


					if(!nlsIsStrNull(t5PartNumberSeqDup))
					{
						fprintf(fp,"%s",t5PartNumberSeqDup);			//PARTNUMBER;								
						fprintf(fp,"^");
					}
					else
					{
						fprintf(fp," ^");
					}

					if(!nlsIsStrNull(ESShopDup))		
						{
							fprintf(fp,"%s",ESShopDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

					if(!nlsIsStrNull(EstPltNmDup))		
						{
							fprintf(fp,"%s",EstPltNmDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

					if(!nlsIsStrNull(EstEdnNoDup))		
						{
							fprintf(fp,"%s",EstEdnNoDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				OprtnObj=NULL;
				OprtnObj=setGet(EstOperationObjs,i);

				string CDDup=NULL;
				string CD=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"EPOCHCostDriver",&CD))goto EXIT;
				if(!nlsIsStrNull(CD)) CDDup=nlsStrDup(CD);
				printf("\n CDDup :%s",CDDup);fflush(stdout);
					if(!nlsIsStrNull(CDDup))
					{
						nlsStrTrimTrailWhiteSpace(CDDup);
						if(nlsStrStr(CDDup,"\n")!= NULL)
						{
							if(nlsStrStr(CDDup,"\n")!= NULL) low_strrpl(CDDup,'\n',';');
							printf("\n After Remove CDDup==>[%s]\n",CDDup);fflush(stdout);
						}
					}

				if(!nlsIsStrNull(CDDup))		
						{
							fprintf(fp,"%s",CDDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string NoCoats=NULL;
				string NoCoatsDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"EPOCHNoOfCoats",&NoCoats))goto EXIT;
				if(!nlsIsStrNull(NoCoats)) NoCoatsDup=nlsStrDup(NoCoats);
				printf("\n NoCoatsDup :%s",NoCoatsDup);fflush(stdout);
					if(!nlsIsStrNull(NoCoatsDup))
					{
						nlsStrTrimTrailWhiteSpace(NoCoatsDup);
						if(nlsStrStr(NoCoatsDup,"\n")!= NULL)
						{
							if(nlsStrStr(NoCoatsDup,"\n")!= NULL) low_strrpl(NoCoatsDup,'\n',';');
							printf("\n After Remove NoCoatsDup==>[%s]\n",NoCoatsDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(NoCoatsDup))		
						{
							fprintf(fp,"%s",NoCoatsDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string WC=NULL;
				string WCDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"EPOCHPEBCNo",&WC))goto EXIT;
				if(!nlsIsStrNull(WC)) WCDup=nlsStrDup(WC);
				printf("\n WCDup :%s",WCDup);fflush(stdout);
				if(!nlsIsStrNull(WCDup))
					{
						nlsStrTrimTrailWhiteSpace(WCDup);
						if(nlsStrStr(WCDup,"\n")!= NULL)
						{
							if(nlsStrStr(WCDup,"\n")!= NULL) low_strrpl(WCDup,'\n',';');
							printf("\n After Remove WCDup==>[%s]\n",WCDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(WCDup))		
						{
							fprintf(fp,"%s",WCDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string EpchQty=NULL;
				string EpchQtyDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"EPOCHQty",&EpchQty))goto EXIT;
				if(!nlsIsStrNull(EpchQty)) EpchQtyDup=nlsStrDup(EpchQty);
				printf("\n EpchQtyDup :%s",EpchQtyDup);fflush(stdout);

				if(!nlsIsStrNull(EpchQtyDup))
					{
						nlsStrTrimTrailWhiteSpace(EpchQtyDup);
						if(nlsStrStr(EpchQtyDup,"\n")!= NULL)
						{
							if(nlsStrStr(EpchQtyDup,"\n")!= NULL) low_strrpl(EpchQtyDup,'\n',' ');
							printf("\n After Remove EpchQtyDup==>[%s]\n",EpchQtyDup);fflush(stdout);
						}
					}

				if(!nlsIsStrNull(EpchQtyDup))		
						{
							fprintf(fp,"%s",EpchQtyDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string UOM=NULL;
				string UOMDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"EPOCHUom",&UOM))goto EXIT;
				if(!nlsIsStrNull(UOM)) UOMDup=nlsStrDup(UOM);
				printf("\n UOMDup :%s",UOMDup);fflush(stdout);
				if(!nlsIsStrNull(UOMDup))
					{
						nlsStrTrimTrailWhiteSpace(UOMDup);
						if(nlsStrStr(UOMDup,"\n")!= NULL)
						{
							if(nlsStrStr(UOMDup,"\n")!= NULL) low_strrpl(UOMDup,'\n',';');
							printf("\n After Remove UOMDup==>[%s]\n",UOMDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(UOMDup))		
						{
							fprintf(fp,"%s",UOMDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string Val=NULL;
				string ValDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"EPOCHValue",&Val))goto EXIT;
				if(!nlsIsStrNull(Val)) ValDup=nlsStrDup(Val);
				printf("\n ValDup :%s",ValDup);fflush(stdout);
				if(!nlsIsStrNull(ValDup))
					{
						nlsStrTrimTrailWhiteSpace(ValDup);
						if(nlsStrStr(ValDup,"\n")!= NULL)
						{
							if(nlsStrStr(ValDup,"\n")!= NULL) low_strrpl(ValDup,'\n',';');
							printf("\n After Remove ValDup==>[%s]\n",ValDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(ValDup))		
						{
							fprintf(fp,"%s",ValDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string AplCalTm=NULL;
				string AplCalTmDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5APLCalTime",&AplCalTm))goto EXIT;
				if(!nlsIsStrNull(AplCalTm)) AplCalTmDup=nlsStrDup(AplCalTm);
				printf("\n AplCalTmDup :%s",AplCalTmDup);fflush(stdout);
				if(!nlsIsStrNull(AplCalTmDup))
					{
						nlsStrTrimTrailWhiteSpace(AplCalTmDup);
						if(nlsStrStr(AplCalTmDup,"\n")!= NULL)
						{
							if(nlsStrStr(AplCalTmDup,"\n")!= NULL) low_strrpl(AplCalTmDup,'\n',';');
							printf("\n After Remove AplCalTmDup==>[%s]\n",AplCalTmDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(AplCalTmDup))		
						{
							fprintf(fp,"%s",AplCalTmDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string AplMcDesc=NULL;
				string AplMcDescDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5APLMCDesc",&AplMcDesc))goto EXIT;
				if(!nlsIsStrNull(AplMcDesc)) AplMcDescDup=nlsStrDup(AplMcDesc);
				printf("\n AplMcDescDup :%s",AplMcDescDup);fflush(stdout);

				if(!nlsIsStrNull(AplMcDescDup))
					{
						nlsStrTrimTrailWhiteSpace(AplMcDescDup);
						if(nlsStrStr(AplMcDescDup,"\n")!= NULL)
						{
							if(nlsStrStr(AplMcDescDup,"\n")!= NULL) low_strrpl(AplMcDescDup,'\n',';');
							printf("\n After Remove AplMcDescDup==>[%s]\n",AplMcDescDup);fflush(stdout);
						}
					}


				if(!nlsIsStrNull(AplMcDescDup))		
						{
							fprintf(fp,"%s",AplMcDescDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string BCDesc=NULL;
				string BCDescDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5BCOpnDesc",&BCDesc))goto EXIT;
				if(!nlsIsStrNull(BCDesc)) BCDescDup=nlsStrDup(BCDesc);
				printf("\n BCDescDup :%s",BCDescDup);fflush(stdout);
				if(!nlsIsStrNull(BCDescDup))
					{
						nlsStrTrimTrailWhiteSpace(BCDescDup);
						if(nlsStrStr(BCDescDup,"\n")!= NULL)
						{
							if(nlsStrStr(BCDescDup,"\n")!= NULL) low_strrpl(BCDescDup,'\n',';');
							printf("\n After Remove BCDescDup==>[%s]\n",BCDescDup);fflush(stdout);
						}
					}

				if(!nlsIsStrNull(BCDescDup))		
						{
							fprintf(fp,"%s",BCDescDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string CpStat=NULL;
				string CpStatDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5CpStatus",&CpStat))goto EXIT;
				if(!nlsIsStrNull(CpStat)) CpStatDup=nlsStrDup(CpStat);
				printf("\n CpStatDup :%s",CpStatDup);fflush(stdout);
				if(!nlsIsStrNull(CpStatDup))
					{
						nlsStrTrimTrailWhiteSpace(CpStatDup);
						if(nlsStrStr(CpStatDup,"\n")!= NULL)
						{
							if(nlsStrStr(CpStatDup,"\n")!= NULL) low_strrpl(CpStatDup,'\n',';');
							printf("\n After Remove CpStatDup==>[%s]\n",CpStatDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(CpStatDup))		
						{
							fprintf(fp,"%s",CpStatDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string EqpmntDtl=NULL;
				string EqpmntDtlDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5EqpDtl",&EqpmntDtl))goto EXIT;
				if(!nlsIsStrNull(EqpmntDtl)) EqpmntDtlDup=nlsStrDup(EqpmntDtl);
				printf("\n EqpmntDtlDup :%s",EqpmntDtlDup);fflush(stdout);

				if(!nlsIsStrNull(EqpmntDtlDup))
					{
						nlsStrTrimTrailWhiteSpace(EqpmntDtlDup);
						if(nlsStrStr(EqpmntDtlDup,"\n")!= NULL)
						{
							if(nlsStrStr(EqpmntDtlDup,"\n")!= NULL) low_strrpl(EqpmntDtlDup,'\n',';');
							printf("\n After Remove EqpmntDtlDup==>[%s]\n",EqpmntDtlDup);fflush(stdout);
						}
					}


				if(!nlsIsStrNull(EqpmntDtlDup))		
						{
							fprintf(fp,"%s",EqpmntDtlDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string EstLn=NULL;
				string EstLnDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5EstLine",&EstLn))goto EXIT;
				if(!nlsIsStrNull(EstLn)) EstLnDup=nlsStrDup(EstLn);
				printf("\n EstLnDup :%s",EstLnDup);fflush(stdout);
				if(!nlsIsStrNull(EstLnDup))
					{
						nlsStrTrimTrailWhiteSpace(EstLnDup);
						if(nlsStrStr(EstLnDup,"\n")!= NULL)
						{
							if(nlsStrStr(EstLnDup,"\n")!= NULL) low_strrpl(EstLnDup,'\n',';');
							printf("\n After Remove EstLnDup==>[%s]\n",EstLnDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(EstLnDup))		
						{
							fprintf(fp,"%s",EstLnDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}



				string PFMEAReqd=NULL;
				string PFMEAReqdDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5EstPFMEAReqd",&PFMEAReqd))goto EXIT;
				if(!nlsIsStrNull(PFMEAReqd)) PFMEAReqdDup=nlsStrDup(PFMEAReqd);
				printf("\n PFMEAReqdDup :%s",PFMEAReqdDup);fflush(stdout);
				if(!nlsIsStrNull(PFMEAReqdDup))
					{
						nlsStrTrimTrailWhiteSpace(PFMEAReqdDup);
						if(nlsStrStr(PFMEAReqdDup,"\n")!= NULL)
						{
							if(nlsStrStr(PFMEAReqdDup,"\n")!= NULL) low_strrpl(PFMEAReqdDup,'\n',';');
							printf("\n After Remove PFMEAReqdDup==>[%s]\n",PFMEAReqdDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PFMEAReqdDup))		
						{
							fprintf(fp,"%s",PFMEAReqdDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string EstStn=NULL;
				string EstStnDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5EstStation",&EstStn))goto EXIT;
				if(!nlsIsStrNull(EstStn)) EstStnDup=nlsStrDup(EstStn);
				printf("\n EstStnDup :%s",EstStnDup);fflush(stdout);
				if(!nlsIsStrNull(EstStnDup))
					{
						nlsStrTrimTrailWhiteSpace(EstStnDup);
						if(nlsStrStr(EstStnDup,"\n")!= NULL)
						{
							if(nlsStrStr(EstStnDup,"\n")!= NULL) low_strrpl(EstStnDup,'\n',';');
							printf("\n After Remove EstStnDup==>[%s]\n",EstStnDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(EstStnDup))		
						{
							fprintf(fp,"%s",EstStnDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string EstCntrlReq=NULL;
				string EstCntrlReqDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5EstcntrlReqd",&EstCntrlReq))goto EXIT;
				if(!nlsIsStrNull(EstCntrlReq)) EstCntrlReqDup=nlsStrDup(EstCntrlReq);
				printf("\n EstCntrlReqDup :%s",EstCntrlReqDup);fflush(stdout);
				if(!nlsIsStrNull(EstCntrlReqDup))
					{
						nlsStrTrimTrailWhiteSpace(EstCntrlReqDup);
						if(nlsStrStr(EstCntrlReqDup,"\n")!= NULL)
						{
							if(nlsStrStr(EstCntrlReqDup,"\n")!= NULL) low_strrpl(EstCntrlReqDup,'\n',';');
							printf("\n After Remove EstCntrlReqDup==>[%s]\n",EstCntrlReqDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(EstCntrlReqDup))		
						{
							fprintf(fp,"%s",EstCntrlReqDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string OprnCylTm=NULL;
				string OprnCylTmDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5OpnCylTm",&OprnCylTm))goto EXIT;
				if(!nlsIsStrNull(OprnCylTm)) OprnCylTmDup=nlsStrDup(OprnCylTm);
				printf("\n OprnCylTmDup :%s",OprnCylTmDup);fflush(stdout);
				if(!nlsIsStrNull(OprnCylTmDup))
					{
						nlsStrTrimTrailWhiteSpace(OprnCylTmDup);
						if(nlsStrStr(OprnCylTmDup,"\n")!= NULL)
						{
							if(nlsStrStr(OprnCylTmDup,"\n")!= NULL) low_strrpl(OprnCylTmDup,'\n',';');
							printf("\n After Remove OprnCylTmDup==>[%s]\n",OprnCylTmDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(OprnCylTmDup))		
						{
							fprintf(fp,"%s",OprnCylTmDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string OprnRmrk=NULL;
				string OprnRmrkDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5OpnRemark",&OprnRmrk))goto EXIT;
				if(!nlsIsStrNull(OprnRmrk)) OprnRmrkDup=nlsStrDup(OprnRmrk);
				printf("\n OprnRmrkDup :%s",OprnRmrkDup);fflush(stdout);
				if(!nlsIsStrNull(OprnRmrkDup))
					{
						nlsStrTrimTrailWhiteSpace(OprnRmrkDup);
						if(nlsStrStr(OprnRmrkDup,"\n")!= NULL)
						{
							if(nlsStrStr(OprnRmrkDup,"\n")!= NULL) low_strrpl(OprnRmrkDup,'\n',';');
							printf("\n After Remove OprnRmrkDup==>[%s]\n",OprnRmrkDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(OprnRmrkDup))		
						{
							fprintf(fp,"%s",OprnRmrkDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PEAllowanceOne=NULL;
				string PEAllowanceOneDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEAllowanceOne",&PEAllowanceOne))goto EXIT;
				if(!nlsIsStrNull(PEAllowanceOne)) PEAllowanceOneDup=nlsStrDup(PEAllowanceOne);
				printf("\n PEAllowanceOneDup :%s",PEAllowanceOneDup);fflush(stdout);
				if(!nlsIsStrNull(PEAllowanceOneDup))
					{
						nlsStrTrimTrailWhiteSpace(PEAllowanceOneDup);
						if(nlsStrStr(PEAllowanceOneDup,"\n")!= NULL)
						{
							if(nlsStrStr(PEAllowanceOneDup,"\n")!= NULL) low_strrpl(PEAllowanceOneDup,'\n',';');
							printf("\n After Remove PEAllowanceOneDup==>[%s]\n",PEAllowanceOneDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PEAllowanceOneDup))		
						{
							fprintf(fp,"%s",PEAllowanceOneDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}



				string PEAllowanceTwo=NULL;
				string PEAllowanceTwoDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEAllowanceTwo",&PEAllowanceTwo))goto EXIT;
				if(!nlsIsStrNull(PEAllowanceTwo)) PEAllowanceTwoDup=nlsStrDup(PEAllowanceTwo);
				printf("\n PEAllowanceTwoDup :%s",PEAllowanceTwoDup);fflush(stdout);
				if(!nlsIsStrNull(PEAllowanceTwoDup))
					{
						nlsStrTrimTrailWhiteSpace(PEAllowanceTwoDup);
						if(nlsStrStr(PEAllowanceTwoDup,"\n")!= NULL)
						{
							if(nlsStrStr(PEAllowanceTwoDup,"\n")!= NULL) low_strrpl(PEAllowanceTwoDup,'\n',';');
							printf("\n After Remove PEAllowanceTwoDup==>[%s]\n",PEAllowanceTwoDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PEAllowanceTwoDup))		
						{
							fprintf(fp,"%s",PEAllowanceTwoDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PEAltRoute=NULL;
				string PEAltRouteDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEAltRoute",&PEAltRoute))goto EXIT;
				if(!nlsIsStrNull(PEAltRoute)) PEAltRouteDup=nlsStrDup(PEAltRoute);
				printf("\n PEAltRouteDup :%s",PEAltRouteDup);fflush(stdout);
				if(!nlsIsStrNull(PEAltRouteDup))
					{
						nlsStrTrimTrailWhiteSpace(PEAltRouteDup);
						if(nlsStrStr(PEAltRouteDup,"\n")!= NULL)
						{
							if(nlsStrStr(PEAltRouteDup,"\n")!= NULL) low_strrpl(PEAltRouteDup,'\n',';');
							printf("\n After Remove PEAltRouteDup==>[%s]\n",PEAltRouteDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PEAltRouteDup))		
						{
							fprintf(fp,"%s",PEAltRouteDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}



				string AplGangSize=NULL;
				string AplGangSizeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEAplGangSize",&AplGangSize))goto EXIT;
				if(!nlsIsStrNull(AplGangSize)) AplGangSizeDup=nlsStrDup(AplGangSize);
				printf("\n AplGangSizeDup :%s",AplGangSizeDup);fflush(stdout);
				if(!nlsIsStrNull(AplGangSizeDup))
					{
						nlsStrTrimTrailWhiteSpace(AplGangSizeDup);
						if(nlsStrStr(AplGangSizeDup,"\n")!= NULL)
						{
							if(nlsStrStr(AplGangSizeDup,"\n")!= NULL) low_strrpl(AplGangSizeDup,'\n',';');
							printf("\n After Remove AplGangSizeDup==>[%s]\n",AplGangSizeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(AplGangSizeDup))		
						{
							fprintf(fp,"%s",AplGangSizeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string AplMcNo=NULL;
				string AplMcNoDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEAplMcNo",&AplMcNo))goto EXIT;
				if(!nlsIsStrNull(AplMcNo)) AplMcNoDup=nlsStrDup(AplMcNo);
				printf("\n AplMcNoDup :%s",AplMcNoDup);fflush(stdout);
				if(!nlsIsStrNull(AplMcNoDup))
					{
						nlsStrTrimTrailWhiteSpace(AplMcNoDup);
						if(nlsStrStr(AplMcNoDup,"\n")!= NULL)
						{
							if(nlsStrStr(AplMcNoDup,"\n")!= NULL) low_strrpl(AplMcNoDup,'\n',';');
							printf("\n After Remove AplMcNoDup==>[%s]\n",AplMcNoDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(AplMcNoDup))		
						{
							fprintf(fp,"%s",AplMcNoDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string AplTimeType=NULL;
				string AplTimeTypeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEAplTimeType",&AplTimeType))goto EXIT;
				if(!nlsIsStrNull(AplTimeType)) AplTimeTypeDup=nlsStrDup(AplTimeType);
				printf("\n AplTimeTypeDup :%s",AplTimeTypeDup);fflush(stdout);
				if(!nlsIsStrNull(AplTimeTypeDup))
					{
						nlsStrTrimTrailWhiteSpace(AplTimeTypeDup);
						if(nlsStrStr(AplTimeTypeDup,"\n")!= NULL)
						{
							if(nlsStrStr(AplTimeTypeDup,"\n")!= NULL) low_strrpl(AplTimeTypeDup,'\n',';');
							printf("\n After Remove AplTimeTypeDup==>[%s]\n",AplTimeTypeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(AplTimeTypeDup))		
						{
							fprintf(fp,"%s",AplTimeTypeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string BCNo=NULL;
				string BCNoDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEBCNo",&BCNo))goto EXIT;
				if(!nlsIsStrNull(BCNo)) BCNoDup=nlsStrDup(BCNo);
				printf("\n BCNoDup :%s",BCNoDup);fflush(stdout);
				if(!nlsIsStrNull(BCNoDup))
					{
						nlsStrTrimTrailWhiteSpace(BCNoDup);
						if(nlsStrStr(BCNoDup,"\n")!= NULL)
						{
							if(nlsStrStr(BCNoDup,"\n")!= NULL) low_strrpl(BCNoDup,'\n',';');
							printf("\n After Remove BCNoDup==>[%s]\n",BCNoDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(BCNoDup))		
						{
							fprintf(fp,"%s",BCNoDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PEDPECT=NULL;
				string PEDPECTDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEDPECT",&PEDPECT))goto EXIT;
				if(!nlsIsStrNull(PEDPECT)) PEDPECTDup=nlsStrDup(PEDPECT);
				printf("\n PEDPECTDup :%s",PEDPECTDup);fflush(stdout);
				if(!nlsIsStrNull(PEDPECTDup))
					{
						nlsStrTrimTrailWhiteSpace(PEDPECTDup);
						if(nlsStrStr(PEDPECTDup,"\n")!= NULL)
						{
							if(nlsStrStr(PEDPECTDup,"\n")!= NULL) low_strrpl(PEDPECTDup,'\n',';');
							printf("\n After Remove PEDPECTDup==>[%s]\n",PEDPECTDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PEDPECTDup))		
						{
							fprintf(fp,"%s",PEDPECTDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PEDPECW=NULL;
				string PEDPECWDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEDPECW",&PEDPECW))goto EXIT;
				if(!nlsIsStrNull(PEDPECW)) PEDPECWDup=nlsStrDup(PEDPECW);
				printf("\n PEDPECWDup :%s",PEDPECWDup);fflush(stdout);
				if(!nlsIsStrNull(PEDPECWDup))
					{
						nlsStrTrimTrailWhiteSpace(PEDPECWDup);
						if(nlsStrStr(PEDPECWDup,"\n")!= NULL)
						{
							if(nlsStrStr(PEDPECWDup,"\n")!= NULL) low_strrpl(PEDPECWDup,'\n',';');
							printf("\n After Remove PEDPECWDup==>[%s]\n",PEDPECWDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PEDPECWDup))		
						{
							fprintf(fp,"%s",PEDPECWDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PEFrequency=NULL;
				string PEFrequencyDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEFrequency",&PEFrequency))goto EXIT;
				if(!nlsIsStrNull(PEFrequency)) PEFrequencyDup=nlsStrDup(PEFrequency);
				printf("\n PEFrequencyDup :%s",PEFrequencyDup);fflush(stdout);
				if(!nlsIsStrNull(PEFrequencyDup))
					{
						nlsStrTrimTrailWhiteSpace(PEFrequencyDup);
						if(nlsStrStr(PEFrequencyDup,"\n")!= NULL)
						{
							if(nlsStrStr(PEFrequencyDup,"\n")!= NULL) low_strrpl(PEFrequencyDup,'\n',';');
							printf("\n After Remove PEFrequencyDup==>[%s]\n",PEFrequencyDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PEFrequencyDup))		
						{
							fprintf(fp,"%s",PEFrequencyDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string GangSize=NULL;
				string GangSizeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEGangSize",&GangSize))goto EXIT;
				if(!nlsIsStrNull(GangSize)) GangSizeDup=nlsStrDup(GangSize);
				printf("\n GangSizeDup :%s",GangSizeDup);fflush(stdout);
				if(!nlsIsStrNull(GangSizeDup))
					{
						nlsStrTrimTrailWhiteSpace(GangSizeDup);
						if(nlsStrStr(GangSizeDup,"\n")!= NULL)
						{
							if(nlsStrStr(GangSizeDup,"\n")!= NULL) low_strrpl(GangSizeDup,'\n',';');
							printf("\n After Remove GangSizeDup==>[%s]\n",GangSizeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(GangSizeDup))		
						{
							fprintf(fp,"%s",GangSizeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string HandlingTime=NULL;
				string HandlingTimeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEHandlingTime",&HandlingTime))goto EXIT;
				if(!nlsIsStrNull(HandlingTime)) HandlingTimeDup=nlsStrDup(HandlingTime);
				printf("\n HandlingTimeDup :%s",HandlingTimeDup);fflush(stdout);
				if(!nlsIsStrNull(HandlingTimeDup))
					{
						nlsStrTrimTrailWhiteSpace(HandlingTimeDup);
						if(nlsStrStr(HandlingTimeDup,"\n")!= NULL)
						{
							if(nlsStrStr(HandlingTimeDup,"\n")!= NULL) low_strrpl(HandlingTimeDup,'\n',';');
							printf("\n After Remove HandlingTimeDup==>[%s]\n",HandlingTimeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(HandlingTimeDup))		
						{
							fprintf(fp,"%s",HandlingTimeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string InternalLabTime=NULL;
				string InternalLabTimeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEInternalLabTime",&InternalLabTime))goto EXIT;
				if(!nlsIsStrNull(InternalLabTime)) InternalLabTimeDup=nlsStrDup(InternalLabTime);
				printf("\n InternalLabTimeDup :%s",InternalLabTimeDup);fflush(stdout);
				if(!nlsIsStrNull(InternalLabTimeDup))
					{
						nlsStrTrimTrailWhiteSpace(InternalLabTimeDup);
						if(nlsStrStr(InternalLabTimeDup,"\n")!= NULL)
						{
							if(nlsStrStr(InternalLabTimeDup,"\n")!= NULL) low_strrpl(InternalLabTimeDup,'\n',';');
							printf("\n After Remove InternalLabTimeDup==>[%s]\n",InternalLabTimeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(InternalLabTimeDup))		
						{
							fprintf(fp,"%s",InternalLabTimeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}



				string PEMMAInd=NULL;
				string PEMMAIndDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEMMAInd",&PEMMAInd))goto EXIT;
				if(!nlsIsStrNull(PEMMAInd)) PEMMAIndDup=nlsStrDup(PEMMAInd);
				printf("\n PEMMAIndDup :%s",PEMMAIndDup);fflush(stdout);
				if(!nlsIsStrNull(PEMMAIndDup))
					{
						nlsStrTrimTrailWhiteSpace(PEMMAIndDup);
						if(nlsStrStr(PEMMAIndDup,"\n")!= NULL)
						{
							if(nlsStrStr(PEMMAIndDup,"\n")!= NULL) low_strrpl(PEMMAIndDup,'\n',';');
							printf("\n After Remove PEMMAIndDup==>[%s]\n",PEMMAIndDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PEMMAIndDup))		
						{
							fprintf(fp,"%s",PEMMAIndDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string MachiningTime=NULL;
				string MachiningTimeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEMachiningTime",&MachiningTime))goto EXIT;
				if(!nlsIsStrNull(MachiningTime)) MachiningTimeDup=nlsStrDup(MachiningTime);
				printf("\n MachiningTimeDup :%s",MachiningTimeDup);fflush(stdout);
				if(!nlsIsStrNull(MachiningTimeDup))
					{
						nlsStrTrimTrailWhiteSpace(MachiningTimeDup);
						if(nlsStrStr(MachiningTimeDup,"\n")!= NULL)
						{
							if(nlsStrStr(MachiningTimeDup,"\n")!= NULL) low_strrpl(MachiningTimeDup,'\n',';');
							printf("\n After Remove MachiningTimeDup==>[%s]\n",MachiningTimeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(MachiningTimeDup))		
						{
							fprintf(fp,"%s",MachiningTimeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string Mostflag=NULL;
				string MostflagDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEMostflag",&Mostflag))goto EXIT;
				if(!nlsIsStrNull(Mostflag)) MostflagDup=nlsStrDup(Mostflag);
				printf("\n MostflagDup :%s",MostflagDup);fflush(stdout);
				if(!nlsIsStrNull(MostflagDup))
					{
						nlsStrTrimTrailWhiteSpace(MostflagDup);
						if(nlsStrStr(MostflagDup,"\n")!= NULL)
						{
							if(nlsStrStr(MostflagDup,"\n")!= NULL) low_strrpl(MostflagDup,'\n',';');
							printf("\n After Remove MostflagDup==>[%s]\n",MostflagDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(MostflagDup))		
						{
							fprintf(fp,"%s",MostflagDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string MstDivision=NULL;
				string MstDivisionDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEMstDivision",&MstDivision))goto EXIT;
				if(!nlsIsStrNull(MstDivision)) MstDivisionDup=nlsStrDup(MstDivision);
				printf("\n MstDivisionDup :%s",MstDivisionDup);fflush(stdout);
				if(!nlsIsStrNull(MstDivisionDup))
					{
						nlsStrTrimTrailWhiteSpace(MstDivisionDup);
						if(nlsStrStr(MstDivisionDup,"\n")!= NULL)
						{
							if(nlsStrStr(MstDivisionDup,"\n")!= NULL) low_strrpl(MstDivisionDup,'\n',';');
							printf("\n After Remove MstDivisionDup==>[%s]\n",MstDivisionDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(MstDivisionDup))		
						{
							fprintf(fp,"%s",MstDivisionDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string MstFrequency=NULL;
				string MstFrequencyDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEMstFrequency",&MstFrequency))goto EXIT;
				if(!nlsIsStrNull(MstFrequency)) MstFrequencyDup=nlsStrDup(MstFrequency);
				printf("\n MstFrequencyDup :%s",MstFrequencyDup);fflush(stdout);
				if(!nlsIsStrNull(MstFrequencyDup))
					{
						nlsStrTrimTrailWhiteSpace(MstFrequencyDup);
						if(nlsStrStr(MstFrequencyDup,"\n")!= NULL)
						{
							if(nlsStrStr(MstFrequencyDup,"\n")!= NULL) low_strrpl(MstFrequencyDup,'\n',';');
							printf("\n After Remove MstFrequencyDup==>[%s]\n",MstFrequencyDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(MstFrequencyDup))		
						{
							fprintf(fp,"%s",MstFrequencyDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string MstMen=NULL;
				string MstMenDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEMstMen",&MstMen))goto EXIT;
				if(!nlsIsStrNull(MstMen)) MstMenDup=nlsStrDup(MstMen);
				printf("\n MstMenDup :%s",MstMenDup);fflush(stdout);
				if(!nlsIsStrNull(MstMenDup))
					{
						nlsStrTrimTrailWhiteSpace(MstMenDup);
						if(nlsStrStr(MstMenDup,"\n")!= NULL)
						{
							if(nlsStrStr(MstMenDup,"\n")!= NULL) low_strrpl(MstMenDup,'\n',';');
							printf("\n After Remove MstMenDup==>[%s]\n",MstMenDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(MstMenDup))		
						{
							fprintf(fp,"%s",MstMenDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string Mstonoff=NULL;
				string MstonoffDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEMstonoff",&Mstonoff))goto EXIT;
				if(!nlsIsStrNull(Mstonoff)) MstonoffDup=nlsStrDup(Mstonoff);
				printf("\n MstonoffDup :%s",MstonoffDup);fflush(stdout);
				if(!nlsIsStrNull(MstonoffDup))
					{
						nlsStrTrimTrailWhiteSpace(MstonoffDup);
						if(nlsStrStr(MstonoffDup,"\n")!= NULL)
						{
							if(nlsStrStr(MstonoffDup,"\n")!= NULL) low_strrpl(MstonoffDup,'\n',';');
							printf("\n After Remove MstonoffDup==>[%s]\n",MstonoffDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(MstonoffDup))		
						{
							fprintf(fp,"%s",MstonoffDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string OpnDesc=NULL;
				string OpnDescDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEOpnDesc",&OpnDesc))goto EXIT;
				if(!nlsIsStrNull(OpnDesc)) OpnDescDup=nlsStrDup(OpnDesc);
				printf("\n OpnDescDup :%s",OpnDescDup);fflush(stdout);

				if(!nlsIsStrNull(OpnDescDup))
					{
						nlsStrTrimTrailWhiteSpace(OpnDescDup);
						if(nlsStrStr(OpnDescDup,"\n")!= NULL)
						{
							if(nlsStrStr(OpnDescDup,"\n")!= NULL) low_strrpl(OpnDescDup,'\n',';');
							printf("\n After Remove OpnDescDup==>[%s]\n",OpnDescDup);fflush(stdout);
						}
					}

				if(!nlsIsStrNull(OpnDescDup))		
						{
							fprintf(fp,"%s",OpnDescDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string OpnDrgNo=NULL;
				string OpnDrgNoDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEOpnDrgNo",&OpnDrgNo))goto EXIT;
				if(!nlsIsStrNull(OpnDrgNo)) OpnDrgNoDup=nlsStrDup(OpnDrgNo);
				printf("\n OpnDrgNoDup :%s",OpnDrgNoDup);fflush(stdout);
				if(!nlsIsStrNull(OpnDrgNoDup))
					{
						nlsStrTrimTrailWhiteSpace(OpnDrgNoDup);
						if(nlsStrStr(OpnDrgNoDup,"\n")!= NULL)
						{
							if(nlsStrStr(OpnDrgNoDup,"\n")!= NULL) low_strrpl(OpnDrgNoDup,'\n',';');
							printf("\n After Remove OpnDrgNoDup==>[%s]\n",OpnDrgNoDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(OpnDrgNoDup))		
						{
							fprintf(fp,"%s",OpnDrgNoDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string OpnDrgStatus=NULL;
				string OpnDrgStatusDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEOpnDrgStatus",&OpnDrgStatus))goto EXIT;
				if(!nlsIsStrNull(OpnDrgStatus)) OpnDrgStatusDup=nlsStrDup(OpnDrgStatus);
				printf("\n OpnDrgStatusDup :%s",OpnDrgStatusDup);fflush(stdout);
				if(!nlsIsStrNull(OpnDrgStatusDup))
					{
						nlsStrTrimTrailWhiteSpace(OpnDrgStatusDup);
						if(nlsStrStr(OpnDrgStatusDup,"\n")!= NULL)
						{
							if(nlsStrStr(OpnDrgStatusDup,"\n")!= NULL) low_strrpl(OpnDrgStatusDup,'\n',';');
							printf("\n After Remove OpnDrgStatusDup==>[%s]\n",OpnDrgStatusDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(OpnDrgStatusDup))		
						{
							fprintf(fp,"%s",OpnDrgStatusDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string OpnLDesc=NULL;
				string OpnLDescDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEOpnLDesc",&OpnLDesc))goto EXIT;
				if(!nlsIsStrNull(OpnLDesc)) OpnLDescDup=nlsStrDup(OpnLDesc);
				printf("\n OpnLDescDup :%s",OpnLDescDup);fflush(stdout);
					if(!nlsIsStrNull(OpnLDescDup))
					{
						nlsStrTrimTrailWhiteSpace(OpnLDescDup);
						if(nlsStrStr(OpnLDescDup,"\n")!= NULL)
						{
							if(nlsStrStr(OpnLDescDup,"\n")!= NULL) low_strrpl(OpnLDescDup,'\n',';');
							printf("\n After Remove OpnLDescDup==>[%s]\n",OpnLDescDup);fflush(stdout);
						}
					}

				if(!nlsIsStrNull(OpnLDescDup))		
						{
							fprintf(fp,"%s",OpnLDescDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string OpnNumber=NULL;
				string OpnNumberDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEOpnNumber",&OpnNumber))goto EXIT;
				if(!nlsIsStrNull(OpnNumber)) OpnNumberDup=nlsStrDup(OpnNumber);
				printf("\n OpnNumberDup :%s",OpnNumberDup);fflush(stdout);
				if(!nlsIsStrNull(OpnNumberDup))
					{
						nlsStrTrimTrailWhiteSpace(OpnNumberDup);
						if(nlsStrStr(OpnNumberDup,"\n")!= NULL)
						{
							if(nlsStrStr(OpnNumberDup,"\n")!= NULL) low_strrpl(OpnNumberDup,'\n',';');
							printf("\n After Remove OpnNumberDup==>[%s]\n",OpnNumberDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(OpnNumberDup))		
						{
							fprintf(fp,"%s",OpnNumberDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PFMEADate=NULL;
				string PFMEADateDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEPFMEADate",&PFMEADate))goto EXIT;
				if(!nlsIsStrNull(PFMEADate)) PFMEADateDup=nlsStrDup(PFMEADate);
				printf("\n PFMEADateDup :%s",PFMEADateDup);fflush(stdout);
				if(!nlsIsStrNull(PFMEADateDup))
					{
						nlsStrTrimTrailWhiteSpace(PFMEADateDup);
						if(nlsStrStr(PFMEADateDup,"\n")!= NULL)
						{
							if(nlsStrStr(PFMEADateDup,"\n")!= NULL) low_strrpl(PFMEADateDup,'\n',';');
							printf("\n After Remove PFMEADateDup==>[%s]\n",PFMEADateDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PFMEADateDup))		
						{
							fprintf(fp,"%s",PFMEADateDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PFMEANO=NULL;
				string PFMEANODup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEPFMEANO",&PFMEANO))goto EXIT;
				if(!nlsIsStrNull(PFMEANO)) PFMEANODup=nlsStrDup(PFMEANO);
				printf("\n PFMEANODup :%s",PFMEANODup);fflush(stdout);
				if(!nlsIsStrNull(PFMEANODup))
					{
						nlsStrTrimTrailWhiteSpace(PFMEANODup);
						if(nlsStrStr(PFMEANODup,"\n")!= NULL)
						{
							if(nlsStrStr(PFMEANODup,"\n")!= NULL) low_strrpl(PFMEANODup,'\n',';');
							printf("\n After Remove PFMEANODup==>[%s]\n",PFMEANODup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PFMEANODup))		
						{
							fprintf(fp,"%s",PFMEANODup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string PFMEARev=NULL;
				string PFMEARevDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEPFMEARev",&PFMEARev))goto EXIT;
				if(!nlsIsStrNull(PFMEARev)) PFMEARevDup=nlsStrDup(PFMEARev);
				printf("\n PFMEARevDup :%s",PFMEARevDup);fflush(stdout);
				if(!nlsIsStrNull(PFMEARevDup))
					{
						nlsStrTrimTrailWhiteSpace(PFMEARevDup);
						if(nlsStrStr(PFMEARevDup,"\n")!= NULL)
						{
							if(nlsStrStr(PFMEARevDup,"\n")!= NULL) low_strrpl(PFMEARevDup,'\n',';');
							printf("\n After Remove PFMEARevDup==>[%s]\n",PFMEARevDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PFMEARevDup))		
						{
							fprintf(fp,"%s",PFMEARevDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string PartDesc=NULL;
				string PartDescDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEPartDesc",&PartDesc))goto EXIT;
				if(!nlsIsStrNull(PartDesc)) PartDescDup=nlsStrDup(PartDesc);
				printf("\n PartDescDup :%s",PartDescDup);fflush(stdout);
				if(!nlsIsStrNull(PartDescDup))
					{
						nlsStrTrimTrailWhiteSpace(PartDescDup);
						if(nlsStrStr(PartDescDup,"\n")!= NULL)
						{
							if(nlsStrStr(PartDescDup,"\n")!= NULL) low_strrpl(PartDescDup,'\n',';');
							printf("\n After Remove PartDescDup==>[%s]\n",PartDescDup);fflush(stdout);
						}
					}

				if(!nlsIsStrNull(PartDescDup))		
						{
							fprintf(fp,"%s",PartDescDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PEPartNumber=NULL;
				string PEPartNumberDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEPartNumber",&PEPartNumber))goto EXIT;
				if(!nlsIsStrNull(PEPartNumber)) PEPartNumberDup=nlsStrDup(PEPartNumber);
				printf("\n PEPartNumberDup :%s",PEPartNumberDup);fflush(stdout);
				if(!nlsIsStrNull(PEPartNumberDup))
					{
						nlsStrTrimTrailWhiteSpace(PEPartNumberDup);
						if(nlsStrStr(PEPartNumberDup,"\n")!= NULL)
						{
							if(nlsStrStr(PEPartNumberDup,"\n")!= NULL) low_strrpl(PEPartNumberDup,'\n',';');
							printf("\n After Remove PEPartNumberDup==>[%s]\n",PEPartNumberDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PEPartNumberDup))		
						{
							fprintf(fp,"%s",PEPartNumberDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PartPerCycle=NULL;
				string PartPerCycleDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEPartPerCycle",&PartPerCycle))goto EXIT;
				if(!nlsIsStrNull(PartPerCycle)) PartPerCycleDup=nlsStrDup(PartPerCycle);
				printf("\n PartPerCycleDup :%s",PartPerCycleDup);fflush(stdout);
				if(!nlsIsStrNull(PartPerCycleDup))
					{
						nlsStrTrimTrailWhiteSpace(PartPerCycleDup);
						if(nlsStrStr(PartPerCycleDup,"\n")!= NULL)
						{
							if(nlsStrStr(PartPerCycleDup,"\n")!= NULL) low_strrpl(PartPerCycleDup,'\n',';');
							printf("\n After Remove PartPerCycleDup==>[%s]\n",PartPerCycleDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PartPerCycleDup))		
						{
							fprintf(fp,"%s",PartPerCycleDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string PlantCode=NULL;
				string PlantCodeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEPlantCode",&PlantCode))goto EXIT;
				if(!nlsIsStrNull(PlantCode)) PlantCodeDup=nlsStrDup(PlantCode);
				printf("\n PlantCodeDup :%s",PlantCodeDup);fflush(stdout);
				if(!nlsIsStrNull(PlantCodeDup))
					{
						nlsStrTrimTrailWhiteSpace(PlantCodeDup);
						if(nlsStrStr(PlantCodeDup,"\n")!= NULL)
						{
							if(nlsStrStr(PlantCodeDup,"\n")!= NULL) low_strrpl(PlantCodeDup,'\n',';');
							printf("\n After Remove PlantCodeDup==>[%s]\n",PlantCodeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PlantCodeDup))		
						{
							fprintf(fp,"%s",PlantCodeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string PlantDesc=NULL;
				string PlantDescDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEPlantDesc",&PlantDesc))goto EXIT;
				if(!nlsIsStrNull(PlantDesc)) PlantDescDup=nlsStrDup(PlantDesc);
				printf("\n PlantDescDup :%s",PlantDescDup);fflush(stdout);
					if(!nlsIsStrNull(PlantDescDup))
					{
						nlsStrTrimTrailWhiteSpace(PlantDescDup);
						if(nlsStrStr(PlantDescDup,"\n")!= NULL)
						{
							if(nlsStrStr(PlantDescDup,"\n")!= NULL) low_strrpl(PlantDescDup,'\n',';');
							printf("\n After Remove PlantDescDup==>[%s]\n",PlantDescDup);fflush(stdout);
						}
					}

				if(!nlsIsStrNull(PlantDescDup))		
						{
							fprintf(fp,"%s",PlantDescDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string ProcessEDNNo=NULL;
				string ProcessEDNNoDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEProcessEDNNo",&ProcessEDNNo))goto EXIT;
				if(!nlsIsStrNull(ProcessEDNNo)) ProcessEDNNoDup=nlsStrDup(ProcessEDNNo);
				printf("\n ProcessEDNNoDup :%s",ProcessEDNNoDup);fflush(stdout);
				if(!nlsIsStrNull(ProcessEDNNoDup))
					{
						nlsStrTrimTrailWhiteSpace(ProcessEDNNoDup);
						if(nlsStrStr(ProcessEDNNoDup,"\n")!= NULL)
						{
							if(nlsStrStr(ProcessEDNNoDup,"\n")!= NULL) low_strrpl(ProcessEDNNoDup,'\n',';');
							printf("\n After Remove ProcessEDNNoDup==>[%s]\n",ProcessEDNNoDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(ProcessEDNNoDup))		
						{
							fprintf(fp,"%s",ProcessEDNNoDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string Prosheet=NULL;
				string ProsheetDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PEProsheet",&Prosheet))goto EXIT;
				if(!nlsIsStrNull(Prosheet)) ProsheetDup=nlsStrDup(Prosheet);
				printf("\n ProsheetDup :%s",ProsheetDup);fflush(stdout);
				if(!nlsIsStrNull(ProsheetDup))
					{
						nlsStrTrimTrailWhiteSpace(ProsheetDup);
						if(nlsStrStr(ProsheetDup,"\n")!= NULL)
						{
							if(nlsStrStr(ProsheetDup,"\n")!= NULL) low_strrpl(ProsheetDup,'\n',';');
							printf("\n After Remove ProsheetDup==>[%s]\n",ProsheetDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(ProsheetDup))		
						{
							fprintf(fp,"%s",ProsheetDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string SUBOpnNo=NULL;
				string SUBOpnNoDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PESUBOpnNo",&SUBOpnNo))goto EXIT;
				if(!nlsIsStrNull(SUBOpnNo)) SUBOpnNoDup=nlsStrDup(SUBOpnNo);
				printf("\n SUBOpnNoDup :%s",SUBOpnNoDup);fflush(stdout);
				if(!nlsIsStrNull(SUBOpnNoDup))
					{
						nlsStrTrimTrailWhiteSpace(SUBOpnNoDup);
						if(nlsStrStr(SUBOpnNoDup,"\n")!= NULL)
						{
							if(nlsStrStr(SUBOpnNoDup,"\n")!= NULL) low_strrpl(SUBOpnNoDup,'\n',';');
							printf("\n After Remove SUBOpnNoDup==>[%s]\n",SUBOpnNoDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(SUBOpnNoDup))		
						{
							fprintf(fp,"%s",SUBOpnNoDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string SetUpTime=NULL;
				string SetUpTimeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PESetUpTime",&SetUpTime))goto EXIT;
				if(!nlsIsStrNull(SetUpTime)) SetUpTimeDup=nlsStrDup(SetUpTime);
				printf("\n SetUpTimeDup :%s",SetUpTimeDup);fflush(stdout);
				if(!nlsIsStrNull(SetUpTimeDup))
					{
						nlsStrTrimTrailWhiteSpace(SetUpTimeDup);
						if(nlsStrStr(SetUpTimeDup,"\n")!= NULL)
						{
							if(nlsStrStr(SetUpTimeDup,"\n")!= NULL) low_strrpl(SetUpTimeDup,'\n',';');
							printf("\n After Remove SetUpTimeDup==>[%s]\n",SetUpTimeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(SetUpTimeDup))		
						{
							fprintf(fp,"%s",SetUpTimeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string TactTime=NULL;
				string TactTimeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PETactTime",&TactTime))goto EXIT;
				if(!nlsIsStrNull(TactTime)) TactTimeDup=nlsStrDup(TactTime);
				printf("\n TactTimeDup :%s",TactTimeDup);fflush(stdout);
				if(!nlsIsStrNull(TactTimeDup))
					{
						nlsStrTrimTrailWhiteSpace(TactTimeDup);
						if(nlsStrStr(TactTimeDup,"\n")!= NULL)
						{
							if(nlsStrStr(TactTimeDup,"\n")!= NULL) low_strrpl(TactTimeDup,'\n',';');
							printf("\n After Remove TactTimeDup==>[%s]\n",TactTimeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(TactTimeDup))		
						{
							fprintf(fp,"%s",TactTimeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string TimeOpnApl=NULL;
				string TimeOpnAplDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PETimeOpnApl",&TimeOpnApl))goto EXIT;
				if(!nlsIsStrNull(TimeOpnApl)) TimeOpnAplDup=nlsStrDup(TimeOpnApl);
				printf("\n TimeOpnAplDup :%s",TimeOpnAplDup);fflush(stdout);
				if(!nlsIsStrNull(TimeOpnAplDup))
					{
						nlsStrTrimTrailWhiteSpace(TimeOpnAplDup);
						if(nlsStrStr(TimeOpnAplDup,"\n")!= NULL)
						{
							if(nlsStrStr(TimeOpnAplDup,"\n")!= NULL) low_strrpl(TimeOpnAplDup,'\n',';');
							printf("\n After Remove TimeOpnAplDup==>[%s]\n",TimeOpnAplDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(TimeOpnAplDup))		
						{
							fprintf(fp,"%s",TimeOpnAplDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string TimeOpnPsd=NULL;
				string TimeOpnPsdDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PETimeOpnPsd",&TimeOpnPsd))goto EXIT;
				if(!nlsIsStrNull(TimeOpnPsd)) TimeOpnPsdDup=nlsStrDup(TimeOpnPsd);
				printf("\n TimeOpnPsdDup :%s",TimeOpnPsdDup);fflush(stdout);
				if(!nlsIsStrNull(TimeOpnPsdDup))
					{
						nlsStrTrimTrailWhiteSpace(TimeOpnPsdDup);
						if(nlsStrStr(TimeOpnPsdDup,"\n")!= NULL)
						{
							if(nlsStrStr(TimeOpnPsdDup,"\n")!= NULL) low_strrpl(TimeOpnPsdDup,'\n',';');
							printf("\n After Remove TimeOpnPsdDup==>[%s]\n",TimeOpnPsdDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(TimeOpnPsdDup))		
						{
							fprintf(fp,"%s",TimeOpnPsdDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string TradeCode=NULL;
				string TradeCodeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PETradeCode",&TradeCode))goto EXIT;
				if(!nlsIsStrNull(TradeCode)) TradeCodeDup=nlsStrDup(TradeCode);
				printf("\n TradeCodeDup :%s",TradeCodeDup);fflush(stdout);
				if(!nlsIsStrNull(TradeCodeDup))
					{
						nlsStrTrimTrailWhiteSpace(TradeCodeDup);
						if(nlsStrStr(TradeCodeDup,"\n")!= NULL)
						{
							if(nlsStrStr(TradeCodeDup,"\n")!= NULL) low_strrpl(TradeCodeDup,'\n',';');
							printf("\n After Remove TradeCodeDup==>[%s]\n",TradeCodeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(TradeCodeDup))		
						{
							fprintf(fp,"%s",TradeCodeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string ApprovBy=NULL;
				string ApprovByDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSApprovBy",&ApprovBy))goto EXIT;
				if(!nlsIsStrNull(ApprovBy)) ApprovByDup=nlsStrDup(ApprovBy);
				printf("\n ApprovByDup :%s",ApprovByDup);fflush(stdout);
				if(!nlsIsStrNull(ApprovByDup))
					{
						nlsStrTrimTrailWhiteSpace(ApprovByDup);
						if(nlsStrStr(ApprovByDup,"\n")!= NULL)
						{
							if(nlsStrStr(ApprovByDup,"\n")!= NULL) low_strrpl(ApprovByDup,'\n',';');
							printf("\n After Remove ApprovByDup==>[%s]\n",ApprovByDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(ApprovByDup))		
						{
							fprintf(fp,"%s",ApprovByDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PSDCalTime=NULL;
				string PSDCalTimeDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSDCalTime",&PSDCalTime))goto EXIT;
				if(!nlsIsStrNull(PSDCalTime)) PSDCalTimeDup=nlsStrDup(PSDCalTime);
				printf("\n PSDCalTimeDup :%s",PSDCalTimeDup);fflush(stdout);
				if(!nlsIsStrNull(PSDCalTimeDup))
					{
						nlsStrTrimTrailWhiteSpace(PSDCalTimeDup);
						if(nlsStrStr(PSDCalTimeDup,"\n")!= NULL)
						{
							if(nlsStrStr(PSDCalTimeDup,"\n")!= NULL) low_strrpl(PSDCalTimeDup,'\n',';');
							printf("\n After Remove PSDCalTimeDup==>[%s]\n",PSDCalTimeDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PSDCalTimeDup))		
						{
							fprintf(fp,"%s",PSDCalTimeDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string PSDocNo=NULL;
				string PSDocNoDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSDocNo",&PSDocNo))goto EXIT;
				if(!nlsIsStrNull(PSDocNo)) PSDocNoDup=nlsStrDup(PSDocNo);
				printf("\n PSDocNoDup :%s",PSDocNoDup);fflush(stdout);
				if(!nlsIsStrNull(PSDocNoDup))
					{
						nlsStrTrimTrailWhiteSpace(PSDocNoDup);
						if(nlsStrStr(PSDocNoDup,"\n")!= NULL)
						{
							if(nlsStrStr(PSDocNoDup,"\n")!= NULL) low_strrpl(PSDocNoDup,'\n',';');
							printf("\n After Remove PSDocNoDup==>[%s]\n",PSDocNoDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PSDocNoDup))		
						{
							fprintf(fp,"%s",PSDocNoDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string Dont=NULL;
				string DontDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSDont",&Dont))goto EXIT;
				if(!nlsIsStrNull(Dont)) DontDup=nlsStrDup(Dont);
				printf("\n DontDup :%s",DontDup);fflush(stdout);
				if(!nlsIsStrNull(DontDup))
					{
						nlsStrTrimTrailWhiteSpace(DontDup);
						if(nlsStrStr(DontDup,"\n")!= NULL)
						{
							if(nlsStrStr(DontDup,"\n")!= NULL) low_strrpl(DontDup,'\n',';');
							printf("\n After Remove DontDup==>[%s]\n",DontDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(DontDup))		
						{
							fprintf(fp,"%s",DontDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string Dos=NULL;
				string DosDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSDos",&Dos))goto EXIT;
				if(!nlsIsStrNull(Dos)) DosDup=nlsStrDup(Dos);
				printf("\n DosDup :%s",DosDup);fflush(stdout);
				if(!nlsIsStrNull(DosDup))
					{
						nlsStrTrimTrailWhiteSpace(DosDup);
						if(nlsStrStr(DosDup,"\n")!= NULL)
						{
							if(nlsStrStr(DosDup,"\n")!= NULL) low_strrpl(DosDup,'\n',';');
							printf("\n After Remove DosDup==>[%s]\n",DosDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(DosDup))		
						{
							fprintf(fp,"%s",DosDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string IssuDate=NULL;
				string IssuDateDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSIssuDate",&IssuDate))goto EXIT;
				if(!nlsIsStrNull(IssuDate)) IssuDateDup=nlsStrDup(IssuDate);
				printf("\n IssuDateDup :%s",IssuDateDup);fflush(stdout);
				if(!nlsIsStrNull(IssuDateDup))
					{
						nlsStrTrimTrailWhiteSpace(IssuDateDup);
						if(nlsStrStr(IssuDateDup,"\n")!= NULL)
						{
							if(nlsStrStr(IssuDateDup,"\n")!= NULL) low_strrpl(IssuDateDup,'\n',';');
							printf("\n After Remove IssuDateDup==>[%s]\n",IssuDateDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(IssuDateDup))		
						{
							fprintf(fp,"%s",IssuDateDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PSModel=NULL;
				string PSModelDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSModel",&PSModel))goto EXIT;
				if(!nlsIsStrNull(PSModel)) PSModelDup=nlsStrDup(PSModel);
				printf("\n PSModelDup :%s",PSModelDup);fflush(stdout);
				if(!nlsIsStrNull(PSModelDup))
					{
						nlsStrTrimTrailWhiteSpace(PSModelDup);
						if(nlsStrStr(PSModelDup,"\n")!= NULL)
						{
							if(nlsStrStr(PSModelDup,"\n")!= NULL) low_strrpl(PSModelDup,'\n',';');
							printf("\n After Remove PSModelDup==>[%s]\n",PSModelDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PSModelDup))		
						{
							fprintf(fp,"%s",PSModelDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string PrepBy=NULL;
				string PrepByDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSPrepBy",&PrepBy))goto EXIT;
				if(!nlsIsStrNull(PrepBy)) PrepByDup=nlsStrDup(PrepBy);
				printf("\n PrepByDup :%s",PrepByDup);fflush(stdout);
				if(!nlsIsStrNull(PrepByDup))
					{
						nlsStrTrimTrailWhiteSpace(PrepByDup);
						if(nlsStrStr(PrepByDup,"\n")!= NULL)
						{
							if(nlsStrStr(PrepByDup,"\n")!= NULL) low_strrpl(PrepByDup,'\n',';');
							printf("\n After Remove PrepByDup==>[%s]\n",PrepByDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PrepByDup))		
						{
							fprintf(fp,"%s",PrepByDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string ProdDate=NULL;
				string ProdDateDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSProdDate",&ProdDate))goto EXIT;
				if(!nlsIsStrNull(ProdDate)) ProdDateDup=nlsStrDup(ProdDate);
				printf("\n ProdDateDup :%s",ProdDateDup);fflush(stdout);
				if(!nlsIsStrNull(ProdDateDup))
					{
						nlsStrTrimTrailWhiteSpace(ProdDateDup);
						if(nlsStrStr(ProdDateDup,"\n")!= NULL)
						{
							if(nlsStrStr(ProdDateDup,"\n")!= NULL) low_strrpl(ProdDateDup,'\n',';');
							printf("\n After Remove ProdDateDup==>[%s]\n",ProdDateDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(ProdDateDup))		
						{
							fprintf(fp,"%s",ProdDateDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PSRevDate=NULL;
				string PSRevDateDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSRevDate",&PSRevDate))goto EXIT;
				if(!nlsIsStrNull(PSRevDate)) PSRevDateDup=nlsStrDup(PSRevDate);
				printf("\n PSRevDateDup :%s",PSRevDateDup);fflush(stdout);
				if(!nlsIsStrNull(PSRevDateDup))
					{
						nlsStrTrimTrailWhiteSpace(PSRevDateDup);
						if(nlsStrStr(PSRevDateDup,"\n")!= NULL)
						{
							if(nlsStrStr(PSRevDateDup,"\n")!= NULL) low_strrpl(PSRevDateDup,'\n',';');
							printf("\n After Remove PSRevDateDup==>[%s]\n",PSRevDateDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PSRevDateDup))		
						{
							fprintf(fp,"%s",PSRevDateDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string PSRevNo=NULL;
				string PSRevNoDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSRevNo",&PSRevNo))goto EXIT;
				if(!nlsIsStrNull(PSRevNo)) PSRevNoDup=nlsStrDup(PSRevNo);
				printf("\n PSRevNoDup :%s",PSRevNoDup);fflush(stdout);
				if(!nlsIsStrNull(PSRevNoDup))
					{
						nlsStrTrimTrailWhiteSpace(PSRevNoDup);
						if(nlsStrStr(PSRevNoDup,"\n")!= NULL)
						{
							if(nlsStrStr(PSRevNoDup,"\n")!= NULL) low_strrpl(PSRevNoDup,'\n',';');
							printf("\n After Remove PSRevNoDup==>[%s]\n",PSRevNoDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PSRevNoDup))		
						{
							fprintf(fp,"%s",PSRevNoDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string PSReviewBy=NULL;
				string PSReviewByDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PSReviewBy",&PSReviewBy))goto EXIT;
				if(!nlsIsStrNull(PSReviewBy)) PSReviewByDup=nlsStrDup(PSReviewBy);
				printf("\n PSReviewByDup :%s",PSReviewByDup);fflush(stdout);
				if(!nlsIsStrNull(PSReviewByDup))
					{
						nlsStrTrimTrailWhiteSpace(PSReviewByDup);
						if(nlsStrStr(PSReviewByDup,"\n")!= NULL)
						{
							if(nlsStrStr(PSReviewByDup,"\n")!= NULL) low_strrpl(PSReviewByDup,'\n',';');
							printf("\n After Remove PSReviewByDup==>[%s]\n",PSReviewByDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PSReviewByDup))		
						{
							fprintf(fp,"%s",PSReviewByDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string PfmeaStatus=NULL;
				string PfmeaStatusDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5PfmeaStatus",&PfmeaStatus))goto EXIT;
				if(!nlsIsStrNull(PfmeaStatus)) PfmeaStatusDup=nlsStrDup(PfmeaStatus);
				printf("\n PfmeaStatusDup :%s",PfmeaStatusDup);fflush(stdout);
				if(!nlsIsStrNull(PfmeaStatusDup))
					{
						nlsStrTrimTrailWhiteSpace(PfmeaStatusDup);
						if(nlsStrStr(PfmeaStatusDup,"\n")!= NULL)
						{
							if(nlsStrStr(PfmeaStatusDup,"\n")!= NULL) low_strrpl(PfmeaStatusDup,'\n',';');
							printf("\n After Remove PfmeaStatusDup==>[%s]\n",PfmeaStatusDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(PfmeaStatusDup))		
						{
							fprintf(fp,"%s",PfmeaStatusDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string QAApprovBy=NULL;
				string QAApprovByDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5QAApprovBy",&QAApprovBy))goto EXIT;
				if(!nlsIsStrNull(QAApprovBy)) QAApprovByDup=nlsStrDup(QAApprovBy);
				printf("\n QAApprovByDup :%s",QAApprovByDup);fflush(stdout);
				if(!nlsIsStrNull(QAApprovByDup))
					{
						nlsStrTrimTrailWhiteSpace(QAApprovByDup);
						if(nlsStrStr(QAApprovByDup,"\n")!= NULL)
						{
							if(nlsStrStr(QAApprovByDup,"\n")!= NULL) low_strrpl(QAApprovByDup,'\n',';');
							printf("\n After Remove QAApprovByDup==>[%s]\n",QAApprovByDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(QAApprovByDup))		
						{
							fprintf(fp,"%s",QAApprovByDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string QADate=NULL;
				string QADateDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5QADate",&QADate))goto EXIT;
				if(!nlsIsStrNull(QADate)) QADateDup=nlsStrDup(QADate);
				printf("\n QADateDup :%s",QADateDup);fflush(stdout);
				if(!nlsIsStrNull(QADateDup))
					{
						nlsStrTrimTrailWhiteSpace(QADateDup);
						if(nlsStrStr(QADateDup,"\n")!= NULL)
						{
							if(nlsStrStr(QADateDup,"\n")!= NULL) low_strrpl(QADateDup,'\n',';');
							printf("\n After Remove QADateDup==>[%s]\n",QADateDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(QADateDup))		
						{
							fprintf(fp,"%s",QADateDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string QAPrepBy=NULL;
				string QAPrepByDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5QAPrepBy",&QAPrepBy))goto EXIT;
				if(!nlsIsStrNull(QAPrepBy)) QAPrepByDup=nlsStrDup(QAPrepBy);
				printf("\n QAPrepByDup :%s",QAPrepByDup);fflush(stdout);
				if(!nlsIsStrNull(QAPrepByDup))
					{
						nlsStrTrimTrailWhiteSpace(QAPrepByDup);
						if(nlsStrStr(QAPrepByDup,"\n")!= NULL)
						{
							if(nlsStrStr(QAPrepByDup,"\n")!= NULL) low_strrpl(QAPrepByDup,'\n',';');
							printf("\n After Remove QAPrepByDup==>[%s]\n",QAPrepByDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(QAPrepByDup))		
						{
							fprintf(fp,"%s",QAPrepByDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string QAReviewBy=NULL;
				string QAReviewByDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5QAReviewBy",&QAReviewBy))goto EXIT;
				if(!nlsIsStrNull(QAReviewBy)) QAReviewByDup=nlsStrDup(QAReviewBy);
				printf("\n QAReviewByDup :%s",QAReviewByDup);fflush(stdout);
				if(!nlsIsStrNull(QAReviewByDup))
					{
						nlsStrTrimTrailWhiteSpace(QAReviewByDup);
						if(nlsStrStr(QAReviewByDup,"\n")!= NULL)
						{
							if(nlsStrStr(QAReviewByDup,"\n")!= NULL) low_strrpl(QAReviewByDup,'\n',';');
							printf("\n After Remove QAReviewByDup==>[%s]\n",QAReviewByDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(QAReviewByDup))		
						{
							fprintf(fp,"%s",QAReviewByDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string RawParts=NULL;
				string RawPartsDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5RawParts",&RawParts))goto EXIT;
				if(!nlsIsStrNull(RawParts)) RawPartsDup=nlsStrDup(RawParts);
				printf("\n RawPartsDup :%s",RawPartsDup);fflush(stdout);
				if(!nlsIsStrNull(RawPartsDup))
					{
						nlsStrTrimTrailWhiteSpace(RawPartsDup);
						if(nlsStrStr(RawPartsDup,"\n")!= NULL)
						{
							if(nlsStrStr(RawPartsDup,"\n")!= NULL) low_strrpl(RawPartsDup,'\n',';');
							printf("\n After Remove RawPartsDup==>[%s]\n",RawPartsDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(RawPartsDup))		
						{
							fprintf(fp,"%s",RawPartsDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string SftParam=NULL;
				string SftParamDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5SftParam",&SftParam))goto EXIT;
				if(!nlsIsStrNull(SftParam)) SftParamDup=nlsStrDup(SftParam);
				printf("\n SftParamDup :%s",SftParamDup);fflush(stdout);
				if(!nlsIsStrNull(SftParamDup))
					{
						nlsStrTrimTrailWhiteSpace(SftParamDup);
						if(nlsStrStr(SftParamDup,"\n")!= NULL)
						{
							if(nlsStrStr(SftParamDup,"\n")!= NULL) low_strrpl(SftParamDup,'\n',';');
							printf("\n After Remove SftParamDup==>[%s]\n",SftParamDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(SftParamDup))		
						{
							fprintf(fp,"%s",SftParamDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}


				string Spotplan=NULL;
				string SpotplanDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5Spotplan",&Spotplan))goto EXIT;
				if(!nlsIsStrNull(Spotplan)) SpotplanDup=nlsStrDup(Spotplan);
				printf("\n SpotplanDup :%s",SpotplanDup);fflush(stdout);
				if(!nlsIsStrNull(SpotplanDup))
					{
						nlsStrTrimTrailWhiteSpace(SpotplanDup);
						if(nlsStrStr(SpotplanDup,"\n")!= NULL)
						{
							if(nlsStrStr(SpotplanDup,"\n")!= NULL) low_strrpl(SpotplanDup,'\n',';');
							printf("\n After Remove SpotplanDup==>[%s]\n",SpotplanDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(SpotplanDup))		
						{
							fprintf(fp,"%s",SpotplanDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

				string EstProcessReqd=NULL;
				string EstProcessReqdDup=NULL;	
				if(dstat=objGetAttribute(OprtnObj,"t5EstProcessReqd",&EstProcessReqd))goto EXIT;
				if(!nlsIsStrNull(EstProcessReqd)) EstProcessReqdDup=nlsStrDup(EstProcessReqd);
				printf("\n EstProcessReqdDup :%s",EstProcessReqdDup);fflush(stdout);
				if(!nlsIsStrNull(EstProcessReqdDup))
					{
						nlsStrTrimTrailWhiteSpace(EstProcessReqdDup);
						if(nlsStrStr(EstProcessReqdDup,"\n")!= NULL)
						{
							if(nlsStrStr(EstProcessReqdDup,"\n")!= NULL) low_strrpl(EstProcessReqdDup,'\n',';');
							printf("\n After Remove EstProcessReqdDup==>[%s]\n",EstProcessReqdDup);fflush(stdout);
						}
					}
				if(!nlsIsStrNull(EstProcessReqdDup))		
						{
							fprintf(fp,"%s",EstProcessReqdDup);
							fprintf(fp,"^");
						}
						else
						{
							fprintf(fp," ^");
						}

		


	string CreDateDup=NULL;
	string CreDate=NULL;	
	string CreDatestr=NULL;	
	if(dstat=objGetAttribute(OprtnObj,"CreationDate",&CreDate))goto EXIT;
	if(!nlsIsStrNull(CreDate)) CreDateDup=nlsStrDup(CreDate);
	printf("\n CreDateDup :%s",CreDateDup);fflush(stdout);

	if(!nlsIsStrNull(CreDateDup))
	{
		CreDatestr = subString(CreDateDup,0,10);
		nlsStrTrimTrailWhiteSpace(CreDatestr);
		if(nlsStrStr(CreDatestr,"\n")!= NULL)
		{
			if(nlsStrStr(CreDatestr,"\n")!= NULL) low_strrpl(CreDatestr,'\n',';');
			printf("\n After Remove CreDatestr==>[%s]\n",CreDatestr);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(CreDatestr))		
			{
				fprintf(fp,"%s",CreDatestr);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}

	string LstUpdDup=NULL;
	string LstUpd=NULL;	
	string LstUpdstr=NULL;	
	if(dstat=objGetAttribute(OprtnObj,"LastUpdate",&LstUpd))goto EXIT;
	if(!nlsIsStrNull(LstUpd)) LstUpdDup=nlsStrDup(LstUpd);
	printf("\n LstUpdDup :%s",LstUpdDup);fflush(stdout);
	if(!nlsIsStrNull(LstUpdDup))
	{
		LstUpdstr = subString(LstUpdDup,0,10);
		nlsStrTrimTrailWhiteSpace(LstUpdstr);
		if(nlsStrStr(LstUpdstr,"\n")!= NULL)
		{
			if(nlsStrStr(LstUpdstr,"\n")!= NULL) low_strrpl(LstUpdstr,'\n',';');
			printf("\n After Remove LstUpdstr==>[%s]\n",LstUpdstr);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(LstUpdstr))		
			{
				fprintf(fp,"%s",LstUpdstr);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string CrtrDup=NULL;
	string Crtr=NULL;	
	if(dstat=objGetAttribute(OprtnObj,"Creator",&Crtr))goto EXIT;
	if(!nlsIsStrNull(Crtr)) CrtrDup=nlsStrDup(Crtr);
	printf("\n CrtrDup :%s",CrtrDup);fflush(stdout);
	if(!nlsIsStrNull(CrtrDup))
	{
		nlsStrTrimTrailWhiteSpace(CrtrDup);
		if(nlsStrStr(CrtrDup,"\n")!= NULL)
		{
			if(nlsStrStr(CrtrDup,"\n")!= NULL) low_strrpl(CrtrDup,'\n',';');
			printf("\n After Remove CrtrDup==>[%s]\n",CrtrDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(CrtrDup))		
			{
				fprintf(fp,"%s",CrtrDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string ESLstModByDup=NULL;
	string ESLstModBy=NULL;	
	if(dstat=objGetAttribute(OprtnObj,"t5LastModBy",&ESLstModBy))goto EXIT;
	if(!nlsIsStrNull(ESLstModBy)) ESLstModByDup=nlsStrDup(ESLstModBy);
	printf("\n ESLstModByDup :%s",ESLstModByDup);fflush(stdout);
	if(!nlsIsStrNull(ESLstModByDup))
	{
		nlsStrTrimTrailWhiteSpace(ESLstModByDup);
		if(nlsStrStr(ESLstModByDup,"\n")!= NULL)
		{
			if(nlsStrStr(ESLstModByDup,"\n")!= NULL) low_strrpl(ESLstModByDup,'\n',';');
			printf("\n After Remove ESLstModByDup==>[%s]\n",ESLstModByDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ESLstModByDup))		
			{
				fprintf(fp,"%s",ESLstModByDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


			fprintf(fp,"\n");

		}
	}


	CLEANUP:

			t5PrintCleanUpModName;

	EXIT:
			t5CheckDstatAndReturn;
}


status GetESInfo(ObjectPtr TCPartObjP,FILE* fp,integer* mfail )
{
	string t5PartNumber=NULL;
	string t5PartNumberDup=NULL;
	string t5PartNumberRev=NULL;
	string t5PartNumberRevDup=NULL;
	string t5PartNumberSeq=NULL;
	string t5PartNumberSeqDup=NULL;
	string ClosrTmStmpDup=NULL;
	string ClosrTmStmp=NULL;
	string DmlNo=NULL;
	string DmlNoDup=NULL;
	string APLCalTm=NULL;
	string APLCalTmDup=NULL;
	string EpchFlgDup=NULL;
	string EpchFlg=NULL;
	string ClosureTmsmpDt=NULL;
	
	//ObjectPtr		genContextObj	= NULL;
	
	//SetOfObjects	aplExpObj		= NULL;

	t5MethodInit("GetESInfo");

	printf("\n Calling GetESInfo......");fflush(stdout);

	if(dstat=objGetAttribute(TCPartObjP,"t5PEPartNumber",&t5PartNumber))goto EXIT;
	if(!nlsIsStrNull(t5PartNumber))t5PartNumberDup=nlsStrDup(t5PartNumber);
	printf("\n t5PartNumberDup :%s",t5PartNumberDup);fflush(stdout);
	if(!nlsIsStrNull(t5PartNumberDup))
	{
		nlsStrTrimTrailWhiteSpace(t5PartNumberDup);
		if(nlsStrStr(t5PartNumberDup,"\n")!= NULL)
		{
			if(nlsStrStr(t5PartNumberDup,"\n")!= NULL) low_strrpl(t5PartNumberDup,'\n',';');
			printf("\n After Remove t5PartNumberDup==>[%s]\n",t5PartNumberDup);fflush(stdout);
		}
	}

	if(dstat=objGetAttribute(TCPartObjP,"Revision",&t5PartNumberRev))goto EXIT;
	if(!nlsIsStrNull(t5PartNumberRev))t5PartNumberRevDup=nlsStrDup(t5PartNumberRev);
	printf("\n t5PartNumberRevDup :%s",t5PartNumberRevDup);fflush(stdout);
	if(!nlsIsStrNull(t5PartNumberRevDup))
	{
		nlsStrTrimTrailWhiteSpace(t5PartNumberRevDup);
		if(nlsStrStr(t5PartNumberRevDup,"\n")!= NULL)
		{
			if(nlsStrStr(t5PartNumberRevDup,"\n")!= NULL) low_strrpl(t5PartNumberRevDup,'\n',';');
			printf("\n After Remove t5PartNumberRevDup==>[%s]\n",t5PartNumberRevDup);fflush(stdout);
		}
	}

	if(dstat=objGetAttribute(TCPartObjP,"Sequence",&t5PartNumberSeq))goto EXIT;
	if(!nlsIsStrNull(t5PartNumberSeq))t5PartNumberSeqDup=nlsStrDup(t5PartNumberSeq);
	printf("\n t5PartNumberSeqDup :%s",t5PartNumberSeqDup);fflush(stdout);
	if(!nlsIsStrNull(t5PartNumberSeqDup))
	{
		nlsStrTrimTrailWhiteSpace(t5PartNumberSeqDup);
		if(nlsStrStr(t5PartNumberSeqDup,"\n")!= NULL)
		{
			if(nlsStrStr(t5PartNumberSeqDup,"\n")!= NULL) low_strrpl(t5PartNumberSeqDup,'\n',';');
			printf("\n After Remove t5PartNumberSeqDup==>[%s]\n",t5PartNumberSeqDup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(t5PartNumberDup))
		{
			fprintf(fp,"%s",t5PartNumberDup);			//PARTNUMBER;								
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


		if(!nlsIsStrNull(t5PartNumberRevDup))
		{
			fprintf(fp,"%s",t5PartNumberRevDup);			//PARTNUMBER;								
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


		if(!nlsIsStrNull(t5PartNumberSeqDup))
		{
			fprintf(fp,"%s",t5PartNumberSeqDup);			//PARTNUMBER;								
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}

	if(dstat=objGetAttribute(TCPartObjP,"ClosureTimeStamp",&ClosrTmStmp))goto EXIT;
	if(!nlsIsStrNull(ClosrTmStmp)) ClosrTmStmpDup=nlsStrDup(ClosrTmStmp);
	printf("\n ClosrTmStmpDup :%s",ClosrTmStmpDup);fflush(stdout);

	if(!nlsIsStrNull(ClosrTmStmpDup))
	{
		ClosureTmsmpDt = subString(ClosrTmStmpDup,0,10);
		nlsStrTrimTrailWhiteSpace(ClosureTmsmpDt);
		if(nlsStrStr(ClosureTmsmpDt,"\n")!= NULL)
		{
			if(nlsStrStr(ClosureTmsmpDt,"\n")!= NULL) low_strrpl(ClosureTmsmpDt,'\n',';');
			printf("\n After Remove ClosureTmsmpDt==>[%s]\n",ClosureTmsmpDt);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(ClosureTmsmpDt))		
		{
			fprintf(fp,"%s",ClosureTmsmpDt);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}

	if(dstat=objGetAttribute(TCPartObjP,"WbsID",&DmlNo))goto EXIT;
	if(!nlsIsStrNull(DmlNo)) DmlNoDup=nlsStrDup(DmlNo);	
	printf("\n DmlNoDup :%s",DmlNoDup);fflush(stdout);
	if(!nlsIsStrNull(DmlNoDup))
	{
		nlsStrTrimTrailWhiteSpace(DmlNoDup);
		if(nlsStrStr(DmlNoDup,"\n")!= NULL)
		{
			if(nlsStrStr(DmlNoDup,"\n")!= NULL) low_strrpl(DmlNoDup,'\n',';');
			printf("\n After Remove DmlNoDup==>[%s]\n",DmlNoDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(DmlNoDup))		
		{
			fprintf(fp,"%s",DmlNoDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}

	if(dstat=objGetAttribute(TCPartObjP,"t5APLCalTime",&APLCalTm))goto EXIT;
	if(!nlsIsStrNull(APLCalTm))APLCalTmDup=nlsStrDup(APLCalTm);
	printf("\n APLCalTmDup :%s",APLCalTmDup);fflush(stdout);
	if(!nlsIsStrNull(APLCalTmDup))
	{
		nlsStrTrimTrailWhiteSpace(APLCalTmDup);
		if(nlsStrStr(APLCalTmDup,"\n")!= NULL)
		{
			if(nlsStrStr(APLCalTmDup,"\n")!= NULL) low_strrpl(APLCalTmDup,'\n',';');
			printf("\n After Remove APLCalTmDup==>[%s]\n",APLCalTmDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(APLCalTmDup))		
		{
			fprintf(fp,"%s",APLCalTmDup);
			fprintf(fp,"^");
		}
		else
		{
			fprintf(fp," ^");
		}


	if(dstat=objGetAttribute(TCPartObjP,"t5EPCOHFlg",&EpchFlg))goto EXIT;
	if(!nlsIsStrNull(EpchFlg))EpchFlgDup=nlsStrDup(EpchFlg);
	printf("\n EpchFlgDup :%s",EpchFlgDup);fflush(stdout);
	if(!nlsIsStrNull(EpchFlgDup))
	{
		nlsStrTrimTrailWhiteSpace(EpchFlgDup);
		if(nlsStrStr(EpchFlgDup,"\n")!= NULL)
		{
			if(nlsStrStr(EpchFlgDup,"\n")!= NULL) low_strrpl(EpchFlgDup,'\n',';');
			printf("\n After Remove EpchFlgDup==>[%s]\n",EpchFlgDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EpchFlgDup))		
			{
				fprintf(fp,"%s",EpchFlgDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string ESActrDup=NULL;
	string ESActr=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5EstActor",&ESActr))goto EXIT;
	if(!nlsIsStrNull(ESActr)) ESActrDup=nlsStrDup(ESActr);
	printf("\n ESActrDup :%s",ESActrDup);fflush(stdout);
	if(!nlsIsStrNull(ESActrDup))
	{
		nlsStrTrimTrailWhiteSpace(ESActrDup);
		if(nlsStrStr(ESActrDup,"\n")!= NULL)
		{
			if(nlsStrStr(ESActrDup,"\n")!= NULL) low_strrpl(ESActrDup,'\n',';');
			printf("\n After Remove ESActrDup==>[%s]\n",ESActrDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ESActrDup))		
			{
				fprintf(fp,"%s",ESActrDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}



	string ESAPrvrDup=NULL;
	string ESAPrvr=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5EstApprover",&ESAPrvr))goto EXIT;
	if(!nlsIsStrNull(ESAPrvr)) ESAPrvrDup=nlsStrDup(ESAPrvr);
	printf("\n ESAPrvrDup :%s",ESAPrvrDup);fflush(stdout);
	if(!nlsIsStrNull(ESAPrvrDup))
	{
		nlsStrTrimTrailWhiteSpace(ESAPrvrDup);
		if(nlsStrStr(ESAPrvrDup,"\n")!= NULL)
		{
			if(nlsStrStr(ESAPrvrDup,"\n")!= NULL) low_strrpl(ESAPrvrDup,'\n',';');
			printf("\n After Remove ESAPrvrDup==>[%s]\n",ESAPrvrDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ESAPrvrDup))		
			{
				fprintf(fp,"%s",ESAPrvrDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string ESShopDup=NULL;
	string ESShop=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5EstShop",&ESShop))goto EXIT;
	if(!nlsIsStrNull(ESShop)) ESShopDup=nlsStrDup(ESShop);
	printf("\n ESShopDup :%s",ESShopDup);fflush(stdout);
	if(!nlsIsStrNull(ESShopDup))
	{
		nlsStrTrimTrailWhiteSpace(ESShopDup);
		if(nlsStrStr(ESShopDup,"\n")!= NULL)
		{
			if(nlsStrStr(ESShopDup,"\n")!= NULL) low_strrpl(ESShopDup,'\n',';');
			printf("\n After Remove ESShopDup==>[%s]\n",ESShopDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ESShopDup))		
			{
				fprintf(fp,"%s",ESShopDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}



	string ESLstModByDup=NULL;
	string ESLstModBy=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5LastModBy",&ESLstModBy))goto EXIT;
	if(!nlsIsStrNull(ESLstModBy)) ESLstModByDup=nlsStrDup(ESLstModBy);
	printf("\n ESLstModByDup :%s",ESLstModByDup);fflush(stdout);
	if(!nlsIsStrNull(ESLstModByDup))
	{
		nlsStrTrimTrailWhiteSpace(ESLstModByDup);
		if(nlsStrStr(ESLstModByDup,"\n")!= NULL)
		{
			if(nlsStrStr(ESLstModByDup,"\n")!= NULL) low_strrpl(ESLstModByDup,'\n',';');
			printf("\n After Remove ESLstModByDup==>[%s]\n",ESLstModByDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ESLstModByDup))		
			{
				fprintf(fp,"%s",ESLstModByDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string ESLPeAgncyDup=NULL;
	string ESLPeAgncy=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEAgency",&ESLPeAgncy))goto EXIT;
	if(!nlsIsStrNull(ESLPeAgncy)) ESLPeAgncyDup=nlsStrDup(ESLPeAgncy);
	printf("\n ESLPeAgncyDup :%s",ESLPeAgncyDup);fflush(stdout);
	if(!nlsIsStrNull(ESLPeAgncyDup))
	{
		nlsStrTrimTrailWhiteSpace(ESLPeAgncyDup);
		if(nlsStrStr(ESLPeAgncyDup,"\n")!= NULL)
		{
			if(nlsStrStr(ESLPeAgncyDup,"\n")!= NULL) low_strrpl(ESLPeAgncyDup,'\n',';');
			printf("\n After Remove ESLPeAgncyDup==>[%s]\n",ESLPeAgncyDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ESLPeAgncyDup))		
			{
				fprintf(fp,"%s",ESLPeAgncyDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string ESCpyMstDup=NULL;
	string ESCpyMst=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PECopyFrmMost",&ESCpyMst))goto EXIT;
	if(!nlsIsStrNull(ESCpyMst)) ESCpyMstDup=nlsStrDup(ESCpyMst);
	printf("\n ESCpyMstDup :%s",ESCpyMstDup);fflush(stdout);
	if(!nlsIsStrNull(ESCpyMstDup))
	{
		nlsStrTrimTrailWhiteSpace(ESCpyMstDup);
		if(nlsStrStr(ESCpyMstDup,"\n")!= NULL)
		{
			if(nlsStrStr(ESCpyMstDup,"\n")!= NULL) low_strrpl(ESCpyMstDup,'\n',';');
			printf("\n After Remove ESCpyMstDup==>[%s]\n",ESCpyMstDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ESCpyMstDup))		
			{
				fprintf(fp,"%s",ESCpyMstDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}

	string ESCpyPrtDup=NULL;
	string ESCpyPrt=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PECopyFrmPart",&ESCpyPrt))goto EXIT;
	if(!nlsIsStrNull(ESCpyPrt)) ESCpyPrtDup=nlsStrDup(ESCpyPrt);
	printf("\n ESCpyPrtDup :%s",ESCpyPrtDup);fflush(stdout);
	if(!nlsIsStrNull(ESCpyPrtDup))
	{
		nlsStrTrimTrailWhiteSpace(ESCpyPrtDup);
		if(nlsStrStr(ESCpyPrtDup,"\n")!= NULL)
		{
			if(nlsStrStr(ESCpyPrtDup,"\n")!= NULL) low_strrpl(ESCpyPrtDup,'\n',';');
			printf("\n After Remove ESCpyPrtDup==>[%s]\n",ESCpyPrtDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(ESCpyPrtDup))		
			{
				fprintf(fp,"%s",ESCpyPrtDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EdnRmrkDup=NULL;
	string EdnRmrk=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEEDNRemark",&EdnRmrk))goto EXIT;
	if(!nlsIsStrNull(EdnRmrk)) EdnRmrkDup=nlsStrDup(EdnRmrk);
	printf("\n EdnRmrkDup :%s",EdnRmrkDup);fflush(stdout);
	if(!nlsIsStrNull(EdnRmrkDup))
	{
		nlsStrTrimTrailWhiteSpace(EdnRmrkDup);
		if(nlsStrStr(EdnRmrkDup,"\n")!= NULL)
		{
			if(nlsStrStr(EdnRmrkDup,"\n")!= NULL) low_strrpl(EdnRmrkDup,'\n',';');
			printf("\n After Remove EdnRmrkDup==>[%s]\n",EdnRmrkDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EdnRmrkDup))		
			{
				fprintf(fp,"%s",EdnRmrkDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}



	string EsCtTypeDup=NULL;
	string EsCtType=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEEstCTType",&EsCtType))goto EXIT;
	if(!nlsIsStrNull(EsCtType)) EsCtTypeDup=nlsStrDup(EsCtType);
	printf("\n EsCtTypeDup :%s",EsCtTypeDup);fflush(stdout);
	if(!nlsIsStrNull(EsCtTypeDup))
	{
		nlsStrTrimTrailWhiteSpace(EsCtTypeDup);
		if(nlsStrStr(EsCtTypeDup,"\n")!= NULL)
		{
			if(nlsStrStr(EsCtTypeDup,"\n")!= NULL) low_strrpl(EsCtTypeDup,'\n',';');
			printf("\n After Remove EsCtTypeDup==>[%s]\n",EsCtTypeDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EsCtTypeDup))		
			{
				fprintf(fp,"%s",EsCtTypeDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EsCwTypeDup=NULL;
	string EsCwType=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEEstCWType",&EsCwType))goto EXIT;
	if(!nlsIsStrNull(EsCwType)) EsCwTypeDup=nlsStrDup(EsCwType);
	printf("\n EsCwTypeDup :%s",EsCwTypeDup);fflush(stdout);
	if(!nlsIsStrNull(EsCwTypeDup))
	{
		nlsStrTrimTrailWhiteSpace(EsCwTypeDup);
		if(nlsStrStr(EsCwTypeDup,"\n")!= NULL)
		{
			if(nlsStrStr(EsCwTypeDup,"\n")!= NULL) low_strrpl(EsCwTypeDup,'\n',';');
			printf("\n After Remove EsCwTypeDup==>[%s]\n",EsCwTypeDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EsCwTypeDup))		
			{
				fprintf(fp,"%s",EsCwTypeDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstTypeDup=NULL;
	string EstType=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEEstShtType",&EstType))goto EXIT;
	if(!nlsIsStrNull(EstType)) EstTypeDup=nlsStrDup(EstType);
	printf("\n EstTypeDup :%s",EstTypeDup);fflush(stdout);
	if(!nlsIsStrNull(EstTypeDup))
	{
		nlsStrTrimTrailWhiteSpace(EstTypeDup);
		if(nlsStrStr(EstTypeDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstTypeDup,"\n")!= NULL) low_strrpl(EstTypeDup,'\n',';');
			printf("\n After Remove EstTypeDup==>[%s]\n",EstTypeDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstTypeDup))		
			{
				fprintf(fp,"%s",EstTypeDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}




	string EstModfRsnDup=NULL;
	string EstModfRsn=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEModfReason",&EstModfRsn))goto EXIT;
	if(!nlsIsStrNull(EstModfRsn)) EstModfRsnDup=nlsStrDup(EstModfRsn);
	printf("\n EstModfRsnDup :%s",EstModfRsnDup);fflush(stdout);
	if(!nlsIsStrNull(EstModfRsnDup))
	{
		nlsStrTrimTrailWhiteSpace(EstModfRsnDup);
		if(nlsStrStr(EstModfRsnDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstModfRsnDup,"\n")!= NULL) low_strrpl(EstModfRsnDup,'\n',';');
			printf("\n After Remove EstModfRsnDup==>[%s]\n",EstModfRsnDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstModfRsnDup))		
			{
				fprintf(fp,"%s",EstModfRsnDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstModRefDup=NULL;
	string EstModRef=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEModfRff",&EstModRef))goto EXIT;
	if(!nlsIsStrNull(EstModRef)) EstModRefDup=nlsStrDup(EstModRef);
	printf("\n EstModRefDup :%s",EstModRefDup);fflush(stdout);
	if(!nlsIsStrNull(EstModRefDup))
	{
		nlsStrTrimTrailWhiteSpace(EstModRefDup);
		if(nlsStrStr(EstModRefDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstModRefDup,"\n")!= NULL) low_strrpl(EstModRefDup,'\n',';');
			printf("\n After Remove EstModRefDup==>[%s]\n",EstModRefDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstModRefDup))		
			{
				fprintf(fp,"%s",EstModRefDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstMstFlgDup=NULL;
	string EstMstFlg=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEMostflag",&EstMstFlg))goto EXIT;
	if(!nlsIsStrNull(EstMstFlg)) EstMstFlgDup=nlsStrDup(EstMstFlg);
	printf("\n EstMstFlgDup :%s",EstMstFlgDup);fflush(stdout);
	if(!nlsIsStrNull(EstMstFlgDup))
	{
		nlsStrTrimTrailWhiteSpace(EstMstFlgDup);
		if(nlsStrStr(EstMstFlgDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstMstFlgDup,"\n")!= NULL) low_strrpl(EstMstFlgDup,'\n',';');
			printf("\n After Remove EstMstFlgDup==>[%s]\n",EstMstFlgDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstMstFlgDup))		
			{
				fprintf(fp,"%s",EstMstFlgDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstMstPrepByDup=NULL;
	string EstMstPrepBy=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEMstPreparedBy",&EstMstPrepBy))goto EXIT;
	if(!nlsIsStrNull(EstMstPrepBy)) EstMstPrepByDup=nlsStrDup(EstMstPrepBy);
	printf("\n EstMstPrepByDup :%s",EstMstPrepByDup);fflush(stdout);
	if(!nlsIsStrNull(EstMstPrepByDup))
	{
		nlsStrTrimTrailWhiteSpace(EstMstPrepByDup);
		if(nlsStrStr(EstMstPrepByDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstMstPrepByDup,"\n")!= NULL) low_strrpl(EstMstPrepByDup,'\n',';');
			printf("\n After Remove EstMstPrepByDup==>[%s]\n",EstMstPrepByDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstMstPrepByDup))		
			{
				fprintf(fp,"%s",EstMstPrepByDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}



	string EstPrtDescDup=NULL;
	string EstPrtDesc=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEPartDesc",&EstPrtDesc))goto EXIT;
	if(!nlsIsStrNull(EstPrtDesc)) EstPrtDescDup=nlsStrDup(EstPrtDesc);
	printf("\n EstPrtDescDup :%s",EstPrtDescDup);fflush(stdout);

	if(!nlsIsStrNull(EstPrtDescDup))
	{
		nlsStrTrimTrailWhiteSpace(EstPrtDescDup);
		if(nlsStrStr(EstPrtDescDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstPrtDescDup,"\n")!= NULL) low_strrpl(EstPrtDescDup,'\n',';');
			printf("\n After Remove EstPrtDescDup==>[%s]\n",EstPrtDescDup);fflush(stdout);
		}
	}


	if(!nlsIsStrNull(EstPrtDescDup))		
			{
				fprintf(fp,"%s",EstPrtDescDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstPlnByDup=NULL;
	string EstPlnBy=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEPlannedBy",&EstPlnBy))goto EXIT;
	if(!nlsIsStrNull(EstPlnBy)) EstPlnByDup=nlsStrDup(EstPlnBy);
	printf("\n EstPlnByDup :%s",EstPlnByDup);fflush(stdout);
	if(!nlsIsStrNull(EstPlnByDup))
	{
		nlsStrTrimTrailWhiteSpace(EstPlnByDup);
		if(nlsStrStr(EstPlnByDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstPlnByDup,"\n")!= NULL) low_strrpl(EstPlnByDup,'\n',';');
			printf("\n After Remove EstPlnByDup==>[%s]\n",EstPlnByDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstPlnByDup))		
			{
				fprintf(fp,"%s",EstPlnByDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstPltNmDup=NULL;
	string EstPltNm=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEPlantName",&EstPltNm))goto EXIT;
	if(!nlsIsStrNull(EstPltNm)) EstPltNmDup=nlsStrDup(EstPltNm);
	printf("\n EstPltNmDup :%s",EstPltNmDup);fflush(stdout);
	if(!nlsIsStrNull(EstPltNmDup))
	{
		nlsStrTrimTrailWhiteSpace(EstPltNmDup);
		if(nlsStrStr(EstPltNmDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstPltNmDup,"\n")!= NULL) low_strrpl(EstPltNmDup,'\n',';');
			printf("\n After Remove EstPltNmDup==>[%s]\n",EstPltNmDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstPltNmDup))		
			{
				fprintf(fp,"%s",EstPltNmDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstPrcAprByDup=NULL;
	string EstPrcAprBy=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEProcessApproveBy",&EstPrcAprBy))goto EXIT;
	if(!nlsIsStrNull(EstPrcAprBy)) EstPrcAprByDup=nlsStrDup(EstPrcAprBy);
	printf("\n EstPrcAprByDup :%s",EstPrcAprByDup);fflush(stdout);
	if(!nlsIsStrNull(EstPrcAprByDup))
	{
		nlsStrTrimTrailWhiteSpace(EstPrcAprByDup);
		if(nlsStrStr(EstPrcAprByDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstPrcAprByDup,"\n")!= NULL) low_strrpl(EstPrcAprByDup,'\n',';');
			printf("\n After Remove EstPrcAprByDup==>[%s]\n",EstPrcAprByDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstPrcAprByDup))		
			{
				fprintf(fp,"%s",EstPrcAprByDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}



	string EstEdnNoDup=NULL;
	string EstEdnNo=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEProcessEDNNo",&EstEdnNo))goto EXIT;
	if(!nlsIsStrNull(EstEdnNo)) EstEdnNoDup=nlsStrDup(EstEdnNo);
	printf("\n EstEdnNoDup :%s",EstEdnNoDup);fflush(stdout);
	if(!nlsIsStrNull(EstEdnNoDup))
	{
		nlsStrTrimTrailWhiteSpace(EstEdnNoDup);
		if(nlsStrStr(EstEdnNoDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstEdnNoDup,"\n")!= NULL) low_strrpl(EstEdnNoDup,'\n',';');
			printf("\n After Remove EstEdnNoDup==>[%s]\n",EstEdnNoDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstEdnNoDup))		
			{
				fprintf(fp,"%s",EstEdnNoDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstEdnTpDup=NULL;
	string EstEdnTp=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEProcessEDNType",&EstEdnTp))goto EXIT;
	if(!nlsIsStrNull(EstEdnTp)) EstEdnTpDup=nlsStrDup(EstEdnTp);
	printf("\n EstEdnTpDup :%s",EstEdnTpDup);fflush(stdout);
	if(!nlsIsStrNull(EstEdnTpDup))
	{
		nlsStrTrimTrailWhiteSpace(EstEdnTpDup);
		if(nlsStrStr(EstEdnTpDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstEdnTpDup,"\n")!= NULL) low_strrpl(EstEdnTpDup,'\n',';');
			printf("\n After Remove EstEdnTpDup==>[%s]\n",EstEdnTpDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstEdnTpDup))		
			{
				fprintf(fp,"%s",EstEdnTpDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstShpNmDup=NULL;
	string EstShpNm=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEShopName",&EstShpNm))goto EXIT;
	if(!nlsIsStrNull(EstShpNm)) EstShpNmDup=nlsStrDup(EstShpNm);
	printf("\n EstShpNmDup :%s",EstShpNmDup);fflush(stdout);
	if(!nlsIsStrNull(EstShpNmDup))
	{
		nlsStrTrimTrailWhiteSpace(EstShpNmDup);
		if(nlsStrStr(EstShpNmDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstShpNmDup,"\n")!= NULL) low_strrpl(EstShpNmDup,'\n',';');
			printf("\n After Remove EstShpNmDup==>[%s]\n",EstShpNmDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstShpNmDup))		
			{
				fprintf(fp,"%s",EstShpNmDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}



	string EstAplTmDup=NULL;
	string EstAplTm=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PETimeOpnApl",&EstAplTm))goto EXIT;
	if(!nlsIsStrNull(EstAplTm)) EstAplTmDup=nlsStrDup(EstAplTm);
	printf("\n EstAplTmDup :%s",EstAplTmDup);fflush(stdout);
	if(!nlsIsStrNull(EstAplTmDup))
	{
		nlsStrTrimTrailWhiteSpace(EstAplTmDup);
		if(nlsStrStr(EstAplTmDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstAplTmDup,"\n")!= NULL) low_strrpl(EstAplTmDup,'\n',';');
			printf("\n After Remove EstAplTmDup==>[%s]\n",EstAplTmDup);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(EstAplTmDup))		
			{
				fprintf(fp,"%s",EstAplTmDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}



	string EstPsdTmDup=NULL;
	string EstPsdTm=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PETimeOpnPsd",&EstPsdTm))goto EXIT;
	if(!nlsIsStrNull(EstPsdTm)) EstPsdTmDup=nlsStrDup(EstPsdTm);
	printf("\n EstPsdTmDup :%s",EstPsdTmDup);fflush(stdout);
	if(!nlsIsStrNull(EstPsdTmDup))
	{
		nlsStrTrimTrailWhiteSpace(EstPsdTmDup);
		if(nlsStrStr(EstPsdTmDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstPsdTmDup,"\n")!= NULL) low_strrpl(EstPsdTmDup,'\n',';');
			printf("\n After Remove EstPsdTmDup==>[%s]\n",EstPsdTmDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstPsdTmDup))		
			{
				fprintf(fp,"%s",EstPsdTmDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstVehIdDup=NULL;
	string EstVehId=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PEVehicleID",&EstVehId))goto EXIT;
	if(!nlsIsStrNull(EstVehId)) EstVehIdDup=nlsStrDup(EstVehId);
	printf("\n EstVehIdDup :%s",EstVehIdDup);fflush(stdout);
	if(!nlsIsStrNull(EstVehIdDup))
	{
		nlsStrTrimTrailWhiteSpace(EstVehIdDup);
		if(nlsStrStr(EstVehIdDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstVehIdDup,"\n")!= NULL) low_strrpl(EstVehIdDup,'\n',';');
			printf("\n After Remove EstVehIdDup==>[%s]\n",EstVehIdDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstVehIdDup))		
			{
				fprintf(fp,"%s",EstVehIdDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}



	string EstPsdCalTmDup=NULL;
	string EstPsdCalTm=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PSDCalTime",&EstPsdCalTm))goto EXIT;
	if(!nlsIsStrNull(EstPsdCalTm)) EstPsdCalTmDup=nlsStrDup(EstPsdCalTm);
	printf("\n EstPsdCalTmDup :%s",EstPsdCalTmDup);fflush(stdout);
	if(!nlsIsStrNull(EstPsdCalTmDup))
	{
		nlsStrTrimTrailWhiteSpace(EstPsdCalTmDup);
		if(nlsStrStr(EstPsdCalTmDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstPsdCalTmDup,"\n")!= NULL) low_strrpl(EstPsdCalTmDup,'\n',';');
			printf("\n After Remove EstPsdCalTmDup==>[%s]\n",EstPsdCalTmDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstPsdCalTmDup))		
			{
				fprintf(fp,"%s",EstPsdCalTmDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string EstPfdStatDup=NULL;
	string EstPfdStat=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"t5PfdStatus",&EstPfdStat))goto EXIT;
	if(!nlsIsStrNull(EstPfdStat)) EstPfdStatDup=nlsStrDup(EstPfdStat);
	printf("\n EstPfdStatDup :%s",EstPfdStatDup);fflush(stdout);
	if(!nlsIsStrNull(EstPfdStatDup))
	{
		nlsStrTrimTrailWhiteSpace(EstPfdStatDup);
		if(nlsStrStr(EstPfdStatDup,"\n")!= NULL)
		{
			if(nlsStrStr(EstPfdStatDup,"\n")!= NULL) low_strrpl(EstPfdStatDup,'\n',';');
			printf("\n After Remove EstPfdStatDup==>[%s]\n",EstPfdStatDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(EstPfdStatDup))		
			{
				fprintf(fp,"%s",EstPfdStatDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}

	string CreDateDup=NULL;
	string CreDate=NULL;	
	string CreDatestr=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"CreationDate",&CreDate))goto EXIT;
	if(!nlsIsStrNull(CreDate)) CreDateDup=nlsStrDup(CreDate);
	printf("\n CreDateDup :%s",CreDateDup);fflush(stdout);

	if(!nlsIsStrNull(CreDateDup))
	{
		CreDatestr = subString(CreDateDup,0,10);
		nlsStrTrimTrailWhiteSpace(CreDatestr);
		if(nlsStrStr(CreDatestr,"\n")!= NULL)
		{
			if(nlsStrStr(CreDatestr,"\n")!= NULL) low_strrpl(CreDatestr,'\n',';');
			printf("\n After Remove CreDatestr==>[%s]\n",CreDatestr);fflush(stdout);
		}
	}

	if(!nlsIsStrNull(CreDatestr))		
			{
				fprintf(fp,"%s",CreDatestr);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}

	string LstUpdDup=NULL;
	string LstUpd=NULL;	
	string LstUpdstr=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"LastUpdate",&LstUpd))goto EXIT;
	if(!nlsIsStrNull(LstUpd)) LstUpdDup=nlsStrDup(LstUpd);
	printf("\n LstUpdDup :%s",LstUpdDup);fflush(stdout);
	if(!nlsIsStrNull(LstUpdDup))
	{
		LstUpdstr = subString(LstUpdDup,0,10);
		nlsStrTrimTrailWhiteSpace(LstUpdstr);
		if(nlsStrStr(LstUpdstr,"\n")!= NULL)
		{
			if(nlsStrStr(LstUpdstr,"\n")!= NULL) low_strrpl(LstUpdstr,'\n',';');
			printf("\n After Remove LstUpdstr==>[%s]\n",LstUpdstr);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(LstUpdstr))		
			{
				fprintf(fp,"%s",LstUpdstr);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}


	string CrtrDup=NULL;
	string Crtr=NULL;	
	if(dstat=objGetAttribute(TCPartObjP,"Creator",&Crtr))goto EXIT;
	if(!nlsIsStrNull(Crtr)) CrtrDup=nlsStrDup(Crtr);
	printf("\n CrtrDup :%s",CrtrDup);fflush(stdout);
	if(!nlsIsStrNull(CrtrDup))
	{
		nlsStrTrimTrailWhiteSpace(CrtrDup);
		if(nlsStrStr(CrtrDup,"\n")!= NULL)
		{
			if(nlsStrStr(CrtrDup,"\n")!= NULL) low_strrpl(CrtrDup,'\n',';');
			printf("\n After Remove CrtrDup==>[%s]\n",CrtrDup);fflush(stdout);
		}
	}
	if(!nlsIsStrNull(CrtrDup))		
			{
				fprintf(fp,"%s",CrtrDup);
				fprintf(fp,"^");
			}
			else
			{
				fprintf(fp," ^");
			}




		fprintf(fp,"\n");
	
	
	CLEANUP:

			t5PrintCleanUpModName;

	EXIT:
			t5CheckDstatAndReturn;
}


int main(int argc, char *argv[])
{
	int stat=0;
	string  LoginS=NULL;
	string  PasswordS=NULL;
	//string  OutFileNamePART=NULL;
	string  ProjectCode=NULL;
	string  Plant=NULL;
	string  EpochFlg=NULL;
	string  FiledownloadPath=NULL;
	string  Flag=NULL;
	string  FromDate=NULL;
	string  ToDate=NULL;
	string PartNumberVal=NULL;
	string PartNumberValDup=NULL;
	string PartNumberRev=NULL;
	string PartNumberRevDup=NULL;
	string PartNumberSeq=NULL;
	string PartNumberSeqDup=NULL;
	string		docobjst	=	NULL;
	string		EstNumber	=	NULL;
	string CurrentDate=NULL;
	string FileName=NULL;
	string FileName1=NULL;
	string FilePath=NULL;
	string FilePath1=NULL;
	string SysDate   = NULL;
	string SysPrevDate   = NULL;
	

	SetOfObjects  setOfAssmblyObjs = NULL ;

	ObjectPtr	TCPartObjP = NULL ;

	SqlPtr	PrtQrysql = NULL ;

	FILE	*fp	= NULL;
	FILE	*fp1	= NULL;

	int partCnt =0;
	int ii =0;

		SetOfStrings      dbScp	=          NULL;


	
	t5MethodInitWMD("GetESData");

	printf("\n Executing... GetESData.c ... \n");fflush(stdout);


	LoginS=nlsStrAlloc(200);
	PasswordS=nlsStrAlloc(200);
	ProjectCode=nlsStrAlloc(200);
	Plant=nlsStrAlloc(200);
	EpochFlg=nlsStrAlloc(200);
	FiledownloadPath=nlsStrAlloc(200);
	Flag=nlsStrAlloc(200);
	FromDate=nlsStrAlloc(200);
	ToDate=nlsStrAlloc(200);
	//OutFileNamePART=nlsStrAlloc(200);
	EstNumber=nlsStrAlloc(200);

	LoginS=argv[1];
	PasswordS=argv[2];
	ProjectCode=argv[3];
	Plant=argv[4];
	EpochFlg=argv[5];
	FiledownloadPath=argv[6];
	Flag=argv[7]; //0=one time 1=Incremental (with/without fromdate todate)
	FromDate=argv[8];
	ToDate=argv[9];

	nlsStrCpy(EstNumber,"");
	nlsStrCat(EstNumber,ProjectCode);
	nlsStrCat(EstNumber,"%");

	printf("\n ProjectCode :%s \n",ProjectCode);fflush(stdout);
	printf("\n Plant :%s \n",Plant);fflush(stdout);
	printf("\n EpochFlg :%s \n",EpochFlg);fflush(stdout);
	printf("\n FiledownloadPath :%s \n",FiledownloadPath);fflush(stdout);
	printf("\n Flag :%s \n",Flag);fflush(stdout);
	printf("\n FromDate :%s \n",FromDate);fflush(stdout);
	printf("\n ToDate :%s \n",ToDate);fflush(stdout);
	//printf("\n OutFileNamePART :%s \n",OutFileNamePART);fflush(stdout);
	printf("\n EstNumber :%s \n",EstNumber);fflush(stdout);

	CurrentDate=sysGetCTime();
	low_strrpl(CurrentDate,' ','_');
	low_strrpl(CurrentDate,':','_');
	printf("\n\n CurrentDate is %s ",CurrentDate);fflush(stdout);

	SysDate = sysGetDate2();
	printf("\n System Date = [%s]\n",SysDate); fflush(stdout);	
	
	SysPrevDate  = sysGetOffsetDate (SysDate,0,-1,0);
	printf("System Previous Date = [%s]\n",SysPrevDate);  fflush(stdout);


	FileName=nlsStrAlloc(500);
	nlsStrCpy(FileName,"ES");
	//nlsStrCat(FileName,ProjectCode);
	//nlsStrCat(FileName,"_");
	//nlsStrCat(FileName,CurrentDate);
	nlsStrCat(FileName,".txt");

	FileName1=nlsStrAlloc(500);
	nlsStrCpy(FileName1,"ES_OPR");
	//nlsStrCat(FileName1,ProjectCode);
	//nlsStrCat(FileName1,"_");
	//nlsStrCat(FileName1,CurrentDate);
	nlsStrCat(FileName1,".txt");


	FilePath=nlsStrAlloc(500);
	//nlsStrCpy(FilePath,"/user/omfprod/devgroups/dss/ES_TCE_TCUA_Migration/");
	nlsStrCpy(FilePath,FiledownloadPath);
	nlsStrCat(FilePath,"/");
	nlsStrCat(FilePath,FileName);
	printf("\n FilePath :%s \n",FilePath);fflush(stdout);

	FilePath1=nlsStrAlloc(500);
	//nlsStrCpy(FilePath1,"/user/omfprod/devgroups/dss/ES_TCE_TCUA_Migration/");
	nlsStrCpy(FilePath1,FiledownloadPath);
	nlsStrCat(FilePath1,"/");
	nlsStrCat(FilePath1,FileName1);
	printf("\n FilePath1 :%s \n",FilePath1);fflush(stdout);

	/* enable multibyte features of Metaphase */
	t5CheckDstat(clInitMB2 (argc, &argv, NULL));

	/* Check to see if the Metaphase network is available. If not, set dstat.*/
	t5CheckDstat(clTestNetwork ());

	/*  Initialize the command line session.    */
	t5CheckDstat(clInitialize2 (FALSE));

	t5CheckDstat(clLogin2 (LoginS,PasswordS,&stat));

	if (stat!=OKAY)
	{
		printf("\n Invalid User Name or PasswordS : %s,%s \n", LoginS, PasswordS);  fflush(stdout);
		goto EXIT;
	}

	t5CheckDstat(GetDatabaseScope(PdmSessnClass,&dbScp,mfail));
	for (ii=0;ii<setSize(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check before... :%s\n",docobjst);fflush(stdout);
	}

	low_set_add_str(dbScp, "supprod");
	low_set_add_str(dbScp, "suhprod");

	t5CheckDstat(SetDatabaseScope(PdmSessnClass,dbScp,mfail));
	for (ii=0;ii<low_set_size(dbScp) ; ii++)
	{
			docobjst=low_set_get(dbScp,ii);
			printf("\n DB pref check -after... :%s\n",docobjst);fflush(stdout);
	}

	
	fp=fopen(FilePath,"a+");
	if(fp==NULL)
	{
				printf("\n%s:fp file is not created...!!!!\n",FilePath);fflush(stdout);
	}
	fflush(fp);

	fp1=fopen(FilePath1,"a+");
	if(fp1==NULL)
	{
				printf("\n%s:fp1 file is not created...!!!!\n",FilePath1);fflush(stdout);
	}
	fflush(fp1);

	if(nlsStrCmp(Flag,"1")==0)
	{
		printf("\n Flag =1");fflush(stdout);
		setOfAssmblyObjs=NULL;
		if(PrtQrysql) oiSqlDispose(PrtQrysql); PrtQrysql = NULL; 
		if (dstat = oiSqlCreateSelect(&PrtQrysql)) goto EXIT;
		if(dstat=(oiSqlWhereBegParen(PrtQrysql)));
		if(dstat = oiSqlWhereEQ(PrtQrysql,"t5PEProcessEDNType","PF")) goto EXIT;
		if(dstat = oiSqlWhereAND(PrtQrysql)) goto EXIT;
		if(dstat = oiSqlWhereEQ(PrtQrysql,"t5PEPlantName",Plant)) goto EXIT;
		if(dstat = oiSqlWhereAND(PrtQrysql)) goto EXIT;
		if(dstat = oiSqlWhereEQ(PrtQrysql,"t5EPCOHFlg",EpochFlg)) goto EXIT;
		if(dstat = oiSqlWhereAND(PrtQrysql)) goto EXIT;
		if(dstat = oiSqlWhereLike(PrtQrysql,"t5PEPartNumber",EstNumber)) goto EXIT;
		if(dstat = oiSqlWhereAND(PrtQrysql)) goto EXIT;

		if( !nlsIsStrNull(FromDate) && !nlsIsStrNull(ToDate) )
		{
		  if(dstat=(oiSqlWhereGE(PrtQrysql,ClosureTimeStampAttr,FromDate))) goto EXIT;
		  if(dstat=(oiSqlWhereAND(PrtQrysql))) goto EXIT;
		  if(dstat=(oiSqlWhereLE(PrtQrysql,ClosureTimeStampAttr,ToDate))) goto EXIT;
		}
		else
		{
		  if(dstat=(oiSqlWhereGE(PrtQrysql,ClosureTimeStampAttr,SysPrevDate))) goto EXIT;
		  if(dstat=(oiSqlWhereAND(PrtQrysql))) goto EXIT;
		  if(dstat=(oiSqlWhereLE(PrtQrysql,ClosureTimeStampAttr,SysDate))) goto EXIT;
		}

		if(dstat=(oiSqlWhereEndParen(PrtQrysql))) goto EXIT;
		if(dstat = QueryDbObject(t5PeEstClass,PrtQrysql,0,TRUE,SC_SCOPE_OF_SESSION,&setOfAssmblyObjs,mfail)) goto EXIT;
		if(dstat=oiSqlPrint(PrtQrysql))goto EXIT;


	}
	else
	{
		printf("\n Flag =0");fflush(stdout);
		setOfAssmblyObjs=NULL;
		if(PrtQrysql) oiSqlDispose(PrtQrysql); PrtQrysql = NULL; 
		if (dstat = oiSqlCreateSelect(&PrtQrysql)) goto EXIT;
		if(dstat=(oiSqlWhereBegParen(PrtQrysql)));
		if(dstat = oiSqlWhereEQ(PrtQrysql,"t5PEProcessEDNType","PF")) goto EXIT;
		if(dstat = oiSqlWhereAND(PrtQrysql)) goto EXIT;
		if(dstat = oiSqlWhereEQ(PrtQrysql,"t5PEPlantName",Plant)) goto EXIT;
		if(dstat = oiSqlWhereAND(PrtQrysql)) goto EXIT;
		if(dstat = oiSqlWhereEQ(PrtQrysql,"t5EPCOHFlg",EpochFlg)) goto EXIT;
		if(dstat = oiSqlWhereAND(PrtQrysql)) goto EXIT;
		if(dstat = oiSqlWhereLike(PrtQrysql,"t5PEPartNumber",EstNumber)) goto EXIT;
		if(dstat=(oiSqlWhereEndParen(PrtQrysql))) goto EXIT;
		if(dstat = QueryDbObject(t5PeEstClass,PrtQrysql,0,TRUE,SC_SCOPE_OF_SESSION,&setOfAssmblyObjs,mfail)) goto EXIT;
		if(dstat=oiSqlPrint(PrtQrysql))goto EXIT;
	}
	
	printf("\n setSize(setOfAssmblyObjs) : %d \n",setSize(setOfAssmblyObjs));fflush(stdout);
	
	if(setSize(setOfAssmblyObjs)>0)
	{
		for(partCnt=0;partCnt<setSize(setOfAssmblyObjs);partCnt++)
		{
			TCPartObjP=NULL;
			TCPartObjP=setGet(setOfAssmblyObjs,partCnt);

			PartNumberVal=NULL;
			PartNumberValDup=NULL;

			if(dstat = objGetAttribute(TCPartObjP,"t5PEPartNumber",&PartNumberVal))goto EXIT;
			if(!nlsIsStrNull(PartNumberVal)) PartNumberValDup=nlsStrDup(PartNumberVal);
			printf("\n  ES Part Number:%s \n",PartNumberValDup); fflush(stdout);

			PartNumberRev=NULL;
			PartNumberRevDup=NULL;
			if(dstat = objGetAttribute(TCPartObjP,RevisionAttr,&PartNumberRev))goto EXIT;
			if(!nlsIsStrNull(PartNumberRev))PartNumberRevDup=nlsStrDup(PartNumberRev);
			printf("\n  ES Part Revision:%s \n",PartNumberRevDup); fflush(stdout);
			
			PartNumberSeq=NULL;
			PartNumberSeqDup=NULL;
			if(dstat = objGetAttribute(TCPartObjP,SequenceAttr,&PartNumberSeq))goto EXIT;
			if(!nlsIsStrNull(PartNumberSeq))PartNumberSeqDup=nlsStrDup(PartNumberSeq);
			printf("\n ES Part Sequence:%s \n",PartNumberSeqDup); fflush(stdout);

			t5CheckMfail(GetESInfo(TCPartObjP,fp,mfail));
			t5CheckMfail(GetESOprInfo(TCPartObjP,fp1,mfail));

		}
	
	}
				
	if(fp) fclose(fp); fp=NULL;
	if(fp1) fclose(fp1); fp1=NULL;


CLEANUP:
		t5PrintCleanUpModName;


EXIT:
		t5CheckDstatAndReturn;
}
;



// GetESData Loader 123loader 9957 CAR + /user/omfprod/devgroups/dss/ES_TCE_TCUA_Migration/9957_ES.txt
// GetESData Loader 123loader 9957 CAR +

// Creator ....
//released status
