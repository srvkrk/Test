	#define TE_MAXLINELEN  128
	#include <ae/dataset.h>
	#include <ae/datasettype.h>
	#include <ae/dataset_msg.h>
	#include <bom/bom.h>
	#include <bom/bom_attr.h>
	#include <cfm/cfm.h>
	#include <ctype.h>
	#include <time.h>
	#include <fclasses/tc_string.h>
	#include <pom/pom/pom.h>
	#include <ps/ps.h>
	#include <ps/ps_errors.h>
	#include <rdv/arch.h>
	#include <res/res_itk.h>
	#include <sa/sa.h>
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <tc/emh.h>
	#include <tc/folder.h>
	#include <tccore/aom.h>
	#include <tccore/project.h>
	#include <tccore/aom_prop.h>
	#include <tccore/grm.h>
	#include <tccore/grmtype.h>
	#include <tccore/item.h>
	#include <tccore/item_errors.h>
	//#include <tccore/imantype.h>
	#include <tccore/tctype.h>
	#include <tccore/releasestatus.h>
	#include <tccore/uom.h>
	#include <tccore/workspaceobject.h>
	#include <tcinit/tcinit.h>
	#include <textsrv/textserver.h>
	#include <unidefs.h>
	#include <user_exits/user_exits.h>
	#include <sys/stat.h>
	#include <pie/pie.h>			
	#include <ai/sample_err.h>
	#include <bom/bom_attr.h>
	//#include <epm/cr_effectivity.h>
	#include <epm/epm.h>
	//#include <epm/releasestatus.h>		
	#include <ict/ict_userservice.h>
	//#include <itk/mem.h>
	#include <lov/lov.h>
	#include <lov/lov_msg.h>		
	#include <property/prop.h>
	#include <res/reservation.h>
	//#include <sa/imanfile.h>
	#include <sa/tcfile.h>
	#include <sa/user.h>
	#include <ss/ss_errors.h>
	#include <stdarg.h>
	#include <tc/emh.h>
	//#include <tc/iman.h>
	#include <tc/preferences.h>
	//#include <tc/tc.h>
	#include <tc/tc_macros.h>
	#include <tc/tc_startup.h> 		
	#include <tccore/custom.h>			
	#include <tccore/grm_msg.h>
	//#include <tccore/iman_msg.h>
	#define Debug TRUE
	#define ONE "1-Mtr"
	#define TWO "2-Kg"
	#define THREE "3-Ltr"
	#define FOUR "4-Nos"
	#define FIVE "5-Sq.Mtr"
	#define SIX "6-Sets"
	#define SEVEN "7-Tonne"
	#define EIGHT "8-Cu.Mtr"
	#define NINE "9-Thsnds"
	#define EIGHT "8-Cu.Mtr"
	#define MAX_LINE_SIZE         256 /* The maximum size of the strings   */
	#define ITK_CALL(X) 							\
			if(Debug)								\
			{										\
				printf(#X);							\
			}										\
			fflush(NULL);							\
			status=X; 								\
			if (status != ITK_ok ) 					\
			{										\
				int				index = 0;			\
				int				n_ifails = 0;		\
				const int*		severities = 0;		\
				const int*		ifails = 0;			\
				const char**	texts = NULL;		\
													\
				EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
				printf("\t%3d error(s)\n", n_ifails);							\
				for( index=0; index<n_ifails; index++)							\
				{																\
					printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
				}																\
				return status;													\
			}																	\
			else									\
			{										\
				if(Debug)							\
				printf("\tSUCCESS\n");				\
			}										\

	/* this sequence is so common */
	#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

	static int PrintErrorStack( void )
	/*
	*
	* PURPOSE : Function to dump the ITK error stack
	*
	* RETURN : causes program termination. If you made it here
	*          you're not coming back modified for cust.c to not call exit()
	*          but to just print the error stack
	*
	* NOTES : This version will always return ITK_ok, which is quite strange
	*           actually. But if the error reporting was "OK" then that makes
	*           sense
	*
	*/
	{
		int iNumErrs = 0;
		const int *pSevLst;
		const int *pErrCdeLst;
		const char **pMsgLst;
		register int i = 0;

		EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
		//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
		for ( i = 0; i < iNumErrs; i++ )
		{
			//fprintf(stderr, "Error(PrintErrorStack): \n"); fflush(stderr);
			//fprintf(stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stderr);
			printf("Error(PrintErrorStack): \n"); fflush(stdout);
			printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
		}
		return ITK_ok;
	}

	static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute , qunt_attribute , refjt_attribute;
	//static void initialise (void);
	//static void initialise_attribute (char *name,  int *attribute);
	//static int my_compare_function (tag_t line_1, tag_t line_2, void *client_data);

	tag_t SchmWithCmpcdRelMultlvl = NULLTAG;
	tag_t window = NULLTAG;
	tag_t *rev_rule = NULLTAG;
	FILE* fp=NULL;
	FILE* fplog=NULL;
	tag_t ParentBomLine = NULLTAG;
	int Parentlevel = 0;
	int ParentFlag = 0;
	int expansionLevel = 0;
	tag_t relation_typeCreoGen = NULLTAG;
	tag_t relation_typeSpec = NULLTAG;
	tag_t relation_typeRender = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t VariqueryTag = NULLTAG;
	char  *ClrSchmToVf	= NULL;
	char  *ClrRevSeq = "NR;1";
	char *SchDataToGov = NULL;
	int item_revision_id_int =1;
	tag_t ColSchmRevTag=NULLTAG;
	tag_t taskRevTag = NULLTAG;
	double qty = 0.00;
	int qty1 = 1;
	tag_t user_tag = NULLTAG;
	tag_t group = NULLTAG;
	//FILE		*output 			= NULL;
	char *DMLNo	= NULL;
	char *Platform = NULL;
	char *SVRruleIP = NULL;
	//char *FileDown = NULL;
	char *FileOp = NULL;
	char *Filelog = NULL;
	char *SVRrule = NULL;
	tag_t			VcMstr      = NULLTAG;
	static char *VOO_prog = (char *)"generate_variant_overlay_option_constraints";

	char* subString (char* mainStringf ,int fromCharf,int toCharf)
	{
		int i;
		char *retStringf;
		retStringf = (char*) malloc(200);
		for(i=0; i < toCharf; i++ )
				  *(retStringf+i) = *(mainStringf+i+fromCharf);
		*(retStringf+i) = '\0';
		return retStringf;
	}

	static char* default_empty_to_A(char *s)
	{
		return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
	}

	static char *VOO_time_stamp()
	{
		time_t now;
		static char time_stamp[512];

		time( &now );
		sprintf( time_stamp, "%s", ctime( &now ) );
		time_stamp[tc_strlen(time_stamp)-1] = '\0'; /* strip off new line */
		return time_stamp;
	}
	static int VOO_show_wso ( tag_t wso ) {
		int                  stat=ITK_ok;
		tag_t                instance_class=NULLTAG;
		static tag_t         wso_class=NULLTAG;
		static tag_t         ve_class=NULLTAG;
		static int           not_initialized=TRUE;
		logical              is_wso=FALSE;
		int status;

		// fprintf( stderr, "inside function VOO_show_wso");

		if ( not_initialized ) {
			ITK_CALL ( POM_class_id_of_class ( "WorkspaceObject", &wso_class ) )
			ITK_CALL ( POM_class_id_of_class ( "VariantExpression", &ve_class ) )
			not_initialized = FALSE;
		}

		if ( NULLTAG == wso ) {
			fprintf( stderr, "VOO_show_wso: Can't show info for a NULLTAG\n" );
			return stat;
		}

		ITK_CALL ( POM_class_of_instance ( wso, &instance_class ) )
		ITK_CALL ( POM_is_descendant ( wso_class, instance_class, &is_wso ) )
		if ( ! is_wso ) {
			logical is_ve=FALSE;

			ITK_CALL ( POM_is_descendant ( ve_class, instance_class, &is_ve ) )
			if ( is_wso ) {
				char *t=NULL;

				ITK_CALL ( BOM_variant_expression_as_text( wso, &t ) )
				fprintf( stderr, "%s %s: VariantExpression: %s: ", VOO_prog, VOO_time_stamp(), (NULL==t?"null":t) );
				MEM_free( t );
			}
			else
			{
				char    *class_name=NULL;

				ITK_CALL ( POM_name_of_class ( instance_class, &class_name ) )
				fprintf( stderr, "%s", (NULL==class_name?"null":class_name) );
			}
		}
		else
		{
			char              *obj_id=NULL;
			WSO_description_t  wso_desc;

			ITK_CALL ( WSOM_describe ( wso, &wso_desc ) )
			ITK_CALL ( WSOM_ask_object_id_string ( wso, &obj_id ) )
			if ( stat == ITK_ok ) {
				fprintf( stderr, "obj_id=%s", (NULL==obj_id?"null":obj_id) );
				MEM_free( obj_id );
	/*            fprintf( stderr, ", name=%s", wso_desc.object_name );                             */
	/*            fprintf( stderr, ", description=%s", wso_desc.description );                      */
				fprintf( stderr, ", type=%s", wso_desc.object_type );
	/*            fprintf( stderr, ", owner=%s", wso_desc.owners_name );                            */
	/*            fprintf( stderr, ", owning_group=%s", wso_desc.owning_group_name );               */
	/*            fprintf( stderr, ", appl=%s", wso_desc.application );                             */
	/*            fprintf( stderr, ", created=%s", wso_desc.date_created );                         */
	/*            fprintf( stderr, ", modified=%s", wso_desc.date_modified );                       */
	/*            fprintf( stderr, ", last_modifying_user=%s", wso_desc.last_modifying_user_name ); */
	/*            fprintf( stderr, ", release_date=%s", wso_desc.date_released );                   */
	/*            fprintf( stderr, ", release_status=%s", wso_desc.released_for );                  */
	/*            fprintf( stderr, ", id=%s", wso_desc.id_string );                                 */
	/*            fprintf( stderr, ", revision=%d", wso_desc.revision_number );                     */
	/*            fprintf( stderr, ", revision_limit=%d", wso_desc.revision_limit );                */
	/*            fprintf( stderr, ", archive_date=%s", wso_desc.archive_date );                    */
	/*            fprintf( stderr, ", backup_date=%s", wso_desc.backup_date );                      */
	/*            fprintf( stderr, ", is_frozen=%d", wso_desc.is_frozen );                          */
	/*            fprintf( stderr, ", is_reserved=%d", wso_desc.is_reserved );                      */
	/*            fprintf( stderr, ", revision_id=%s", wso_desc.revision_id );                      */
	/*            fprintf( stderr, ", owning_site=%s", wso_desc.owning_site_name );                 */
			}
		}
		fprintf( stderr, "\n" );
		return stat;
	}
	int CheckRefRelation(tag_t  Clrrev)//Nilesh
	{
		int n_referencers = 0;
		int m = 0;
		int cntr = 0;
		int    *levels;

		tag_t *	referencers = NULLTAG;
		tag_t objTypeTag1;

		char **relationsRef;
		char *FLName=NULL;
		char *DPartStat=NULL;
		char *Breakdownobj=NULL;
		char *objTypeTagName=NULL;

		if(WSOM_where_referenced2(Clrrev,1,&n_referencers,&levels,&referencers,&relationsRef)!=ITK_ok)PrintErrorStack();
		printf("\n  Found....n_referencers..............:%d\n",n_referencers);
		fprintf(fplog,"\n Found....n_referencers..............:%d",n_referencers);
		if (n_referencers>0)
		{
			for(m=0;m<n_referencers;m++)
			{
					//printf("\n relationsRef :[%s]",relationsRef[m]);
					if(TCTYPE_ask_object_type(referencers[m],&objTypeTag1)!=ITK_ok)PrintErrorStack();
					if(TCTYPE_ask_name2(objTypeTag1,&objTypeTagName)!=ITK_ok)PrintErrorStack();
					
					if(WSOM_ask_name2(referencers[m],&FLName)!=ITK_ok)PrintErrorStack();
					printf("\n FLName :[%s]",FLName);
					fprintf(fplog,"\n FLName :[%s]",FLName);
					if(AOM_ask_value_string(referencers[m],"item_id",&Breakdownobj)!=ITK_ok)PrintErrorStack();
					printf("\n represented by oject Parts found = %s \n",Breakdownobj); 

					if(AOM_ask_value_string(referencers[m],"object_type",&DPartStat)!=ITK_ok)PrintErrorStack();
					printf("\n  Object type is : [%s]\n", DPartStat); 
					fprintf(fplog,"\nObject type is : [%s]",DPartStat);
					if(tc_strcmp(DPartStat,"T5_ChangeTaskRevision")==0 && (tc_strstr(Breakdownobj,"_CL")!=NULL))
					{
						printf("\n Attached to CL task = %s \n",Breakdownobj);
						fprintf(fplog,"\n Attached to CL task = %s",Breakdownobj);

						cntr=1;
						break;

					}else
					{
						cntr=0;
					}
			}
		}

		return cntr;
	}

	int setAttributesOnDesign(tag_t* item,char * item_id,char* desc,char* UnitOfMeasureS)
	{
		int status;
		char* ent_uom=NULL;
		tag_t unit_of_measure=NULLTAG;
		ent_uom=(char *) MEM_alloc(10 * sizeof(char *));
		if(strcmp(UnitOfMeasureS,"1")==0){strcpy(ent_uom,ONE);}
		else if(strcmp(UnitOfMeasureS,"2")==0){strcpy(ent_uom,TWO);}
		else if(strcmp(UnitOfMeasureS,"3")==0){strcpy(ent_uom,THREE);}
		else if(strcmp(UnitOfMeasureS,"4")==0){strcpy(ent_uom,FOUR);}
		else if(strcmp(UnitOfMeasureS,"5")==0){strcpy(ent_uom,FIVE);}
		else if(strcmp(UnitOfMeasureS,"6")==0){strcpy(ent_uom,SIX);}
		else if(strcmp(UnitOfMeasureS,"7")==0){strcpy(ent_uom,SEVEN);}
		else if(strcmp(UnitOfMeasureS,"8")==0){strcpy(ent_uom,EIGHT);}
		else {strcpy(ent_uom,"");}
		printf("\n ent_uom ... [%s]",ent_uom);
		
		printf("\n item_id--------->%s",item_id);
		printf("\n object_name------------>%s",item_id);
		printf("\n object_desc:%s",desc);
		printf("\n UnitOfMeasureS:%s",UnitOfMeasureS);	
		fprintf(fplog,"\n ent_uom ... [%s], tem_id--------->%s ,object_name------------>%s, object_desc:%s , UnitOfMeasureS:%s",ent_uom,item_id,item_id,desc,UnitOfMeasureS);
		ITK_CALL(AOM_lock(*item));
		if(strcmp(UnitOfMeasureS,"4")!=0)
		{
			ITK_CALL(UOM_find_by_symbol(ent_uom,&unit_of_measure));
			ITK_CALL(ITEM_set_unit_of_measure(*item, unit_of_measure));
		}
		ITK_CALL(AOM_set_value_string(*item,"item_id",item_id));
		ITK_CALL(AOM_set_value_string(*item,"object_name",item_id));
		ITK_CALL(AOM_set_value_string(*item,"object_desc",desc));
		ITK_CALL(AOM_save_without_extensions(*item));
		ITK_CALL(AOM_unlock(*item));	
	}

	int setAliasOnClrVC(tag_t* itemRev, char* ClMstrAlias, char* ColourIDSchm, char* NCobject_desc)
	{
		int status;
		char	*Part_desc	= NULL;
		char	*AliasN	= NULL;
		char	*PDesc	= NULL;
		char *AliasDesc=NULL;
		AliasDesc=(char *) MEM_alloc(100);
		
		printf ( "\n ClMstrAlias is -------> %s",ClMstrAlias);fflush(stdout);
		fprintf(fplog,"\nClMstrAlias is -------> %s",ClMstrAlias);
		ITK_CALL(AOM_lock(*itemRev));
		ITK_CALL(AOM_ask_value_string(*itemRev,"object_desc",&Part_desc));
		printf ( "\n Part_desc is -------> %s",Part_desc);fflush(stdout);
		printf ( "\n NCobject_desc -------> [%s]",NCobject_desc);fflush(stdout);
		fprintf(fplog,"\n NCobject_desc & Part_desc is ------>%s=%s",NCobject_desc,Part_desc);
		
		//if(strcmp(Part_desc,"-")==0)	// commented on 24.08.2021
		if(tc_strstr(Part_desc,"-")!=NULL)	//Added and under observation added by RRR on 24.08.2021
		{
			AliasN =  strtok(Part_desc,"-");
			PDesc  =  strtok(NULL,"-");
			printf ( "\n AliasN &  PDesc is -------> %s=%s",AliasN,PDesc);fflush(stdout);
			fprintf(fplog,"\n if  AliasN &  PDesc is ------->%s=%s",AliasN,PDesc);
			strcpy(AliasDesc,"");
			strcat(AliasDesc,ClMstrAlias);
			strcat(AliasDesc,"-");
			strcat(AliasDesc,PDesc);
			fprintf(fplog,"\n  AliasN &  PDesc is ------->%s",AliasDesc);
		}else
		{
			printf ( "\n In else of Alias  ");fflush(stdout);
			fprintf(fplog,"\n  In else of Alias");
			strcpy(AliasDesc,"");
			strcat(AliasDesc,ClMstrAlias);
			strcat(AliasDesc,"-");
			strcat(AliasDesc,Part_desc);
			fprintf(fplog,"\n  In else of Alias......%s",AliasDesc);
		}
		
		printf ( "\n ClMstrAlias & AliasDesc is ------->%s=%s==[%s]",ClMstrAlias,AliasDesc,ColourIDSchm);fflush(stdout);
		fprintf(fplog,"\n ClMstrAlias & AliasDesc is ------->%s=%s==[%s]",ClMstrAlias,AliasDesc,ColourIDSchm);
		ITK_CALL(AOM_set_value_string(*itemRev,"t5_ColourID",ColourIDSchm));
		ITK_CALL(AOM_set_value_string(*itemRev,"object_desc",AliasDesc));
		ITK_CALL(AOM_save_without_extensions(*itemRev));
		ITK_CALL(AOM_unlock(*itemRev));	

		return ITK_ok;
	}

	int setAttributesOnDesignRev(tag_t* rev,char* item_id,int sequence_id,char* desc,char* ColourIndS,char* t5PrtCatCodeS,char* t5ColourIDS,char* t5CoatedS,char* t5PartStatusS,char* designgroup,char* projectcode,char* mod_desc,char* DrawingIndS,char * PartTypeS,char * t5PartCodeS,char * t5AhdMakeBuyIndS,char * t5PunPCBUMakeBuyIndS,char * t5PunMakeBuyIndS,char * t5DwdMakeBuyIndS,char * NonColorPart)
	{
		int status;
		double dweight=0;
		tag_t  projobj=NULLTAG;
		char *sColourId =NULL;
		printf ( "\n Global SchDataToGov is -------> %s=%s",SchDataToGov,t5ColourIDS);fflush(stdout);
		fprintf(fplog,"\n Global SchDataToGov is -------> %s=%s",SchDataToGov,t5ColourIDS);
		ITK_CALL(AOM_lock(*rev));	
		ITK_CALL(AOM_set_value_string(*rev,"object_desc",desc));
		ITK_CALL(AOM_set_value_string(*rev,"t5_ColourInd","C"));
		ITK_CALL(AOM_set_value_string(*rev,"t5_PrtCatCode",t5PrtCatCodeS));
		ITK_CALL(AOM_set_value_string(*rev,"t5_ColourID",t5ColourIDS));
		ITK_CALL(AOM_set_value_string(*rev,"t5_Coated","N"));
		ITK_CALL(AOM_set_value_string(*rev,"t5_NcPartNo",NonColorPart));
		ITK_CALL(AOM_set_value_string(*rev,"t5_PartStatus",t5PartStatusS));
		ITK_CALL(AOM_set_value_string(*rev,"t5_DRStatus",t5PartStatusS));
		ITK_CALL(AOM_set_value_string(*rev,"t5_DesignGrp",designgroup));
		ITK_CALL(AOM_set_value_string(*rev,"t5_ProjectCode",projectcode));
		ITK_CALL(AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc));
		ITK_CALL(AOM_set_value_string(*rev,"gov_classification",SchDataToGov));

		ITK_CALL(AOM_set_value_string(*rev,"t5_DrawingInd",DrawingIndS));
		if (strstr(PartTypeS,"D")!=NULL) { ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","D")); }
		if (strstr(PartTypeS,"A")!=NULL) { ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","A")); }
		if (strstr(PartTypeS,"C")!=NULL) { ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","C")); }
		if (strstr(PartTypeS,"VC")!=NULL) { ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","VC")); }
		if (strstr(PartTypeS,"V")!=NULL) { ITK_CALL ( AOM_set_value_string(*rev,"t5_PartType","V")); }

		ITK_CALL(AOM_set_value_string(*rev,"t5_PartCode",t5PartCodeS));
		if(tc_strcmp(t5AhdMakeBuyIndS,"-")==0) { ITK_CALL(AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator","")); }else
		{
			ITK_CALL(AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator",t5AhdMakeBuyIndS));
		}

		if(tc_strcmp(t5PunPCBUMakeBuyIndS,"-")==0) { ITK_CALL(AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator",""));
		}else
		{
			ITK_CALL(AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator",t5PunPCBUMakeBuyIndS));
		}

		if(tc_strcmp(t5PunMakeBuyIndS,"-")==0) { ITK_CALL(AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",""));
		}else
		{
			ITK_CALL(AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",t5PunMakeBuyIndS));
		}
		
		if(tc_strcmp(t5DwdMakeBuyIndS,"-")==0) { ITK_CALL(AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator",""));
		}else
		{
			ITK_CALL(AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator",t5DwdMakeBuyIndS));
		}	
			
		ITK_CALL(AOM_save_without_extensions(*rev));
		ITK_CALL(AOM_unlock(*rev));
		ITK_CALL(AOM_ask_value_string(*rev,"t5_ColourID",&sColourId));
		printf ( "\n Reset t5_ColourID is -------> %s",sColourId);fflush(stdout);
		fprintf(fplog,"\n Reset t5_ColourID is -------> %s",sColourId);
		ITK_CALL(AOM_lock(*rev));
		if (sColourId!=NULL)
		{
			ITK_CALL(AOM_set_value_string(*rev,"t5_ColourID",t5ColourIDS));

		}
		else
		{
			printf ( "\n Alredy Set t5_ColourID is -------> ");fflush(stdout);
			fprintf(fplog,"\n Alredy Set t5_ColourID is -------> ");
		}
		  
		ITK_CALL(AOM_save_without_extensions(*rev));
		ITK_CALL(AOM_unlock(*rev));
	}

	int CreateReleasestatus(tag_t ColourRev)
	{
			tag_t   release_status =NULLTAG;
			char   *ReleaseStatus=NULL;
			char* ReviewStatus=NULL;
			int status;
			int		ifail	=0;
			int	   status_count=0;
			tag_t* status_list = NULLTAG;
			logical  retain_released_date =false;

			ReviewStatus =(char *) MEM_alloc(20 * sizeof(char *));
			tc_strcpy(ReviewStatus,"T5_LcsReview");
			printf("\n ReviewStatus --> %s",ReviewStatus);

			if((strcmp(ReviewStatus,"T5_LcsReview")==0))
			{
				if(ITK_ok != (ifail = WSOM_ask_release_status_list(ColourRev,&status_count,&status_list)))
				{
				   return ifail;
				}

				printf("\n REV status_count: %d",status_count);fflush(stdout);

				if (status_count == 0)
				{
					printf("\n No Status, so the Item is not yet Released ");
					printf("\n *********Stamping Releasing item*******......");
					fprintf(fplog,"\n *********Stamping Releasing item*******......");

					if(ITK_ok != (ifail =  RELSTAT_create_release_status(ReviewStatus,&release_status)))	 return ifail;

					if(ITK_ok != (ifail = AOM_ask_name(release_status, &ReleaseStatus))) return ifail;
					printf("\n ******************* ReleaseStatus: %s",ReleaseStatus);fflush(stdout);
					fprintf(fplog,"\n******************* ReleaseStatus: %s",ReleaseStatus);

					//printf("\n release_status ");
					ITK_CALL(RELSTAT_add_release_status(release_status,1,&ColourRev,retain_released_date));
				}
			}
	  return status;
	}

	int AssignProject(tag_t  itemRev,char* projectcode)
	{
		int status;
		tag_t  projobj=NULLTAG;
		char* username=NULL;
		tag_t user_tag=NULLTAG;

		printf("\n projectcode [%s]",projectcode);fflush(stdout);
		fprintf(fplog,"\n projectcode [%s]\n",projectcode);
		ITK_CALL (PROJ_find(projectcode,&projobj));
		//printf("\n Assigned to Project111");fflush(stdout);

		if(projobj !=NULLTAG)
		{
			ITK_CALL (PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev));
			printf("\n Assigned to Project");fflush(stdout);
		}
		else
		{
			printf("\n Project not found \n");fflush(stdout);
		}
	  return status;
	}

	int NonClrOccursetToClrBvr(tag_t  clrbvr, tag_t	NonClrChildRev1, int NClrQty3,tag_t NClrparents)
	{	
		int          stat                = ITK_ok;
		int			 status;
		int			 ifail				 = ITK_ok;
		int n_occs;
		tag_t *occsal;
		int ChildOccNon,iy,i=0,aj=0;
		tag_t	ChildItem		= NULLTAG;
		tag_t	bvrchild		= NULLTAG;
		char	*occ_item_id	= NULL;
		char	*UsesPartNo	= NULL;
		char	*Uses_revision_id	= NULL;
		char	*Uses_bvrName	= NULL;
		tag_t  *occs=NULL;
		int NonClrparents_cnt = 0;
		int NonClrn_levels = 0;
		tag_t *NonClroccparents = NULLTAG;
		tag_t NonClrsglPrntTag = NULLTAG;
		char *NonClrParentPartNumber =NULL;
		
		ITK_CALL(AOM_ask_value_string(NonClrChildRev1, "item_id", &UsesPartNo));
		printf("\n\n UsesPartNo for Part is --> : %s",UsesPartNo); fflush(stdout);
		fprintf(fplog,"\n\tUsesPartNo for Part is --> : %s\n",UsesPartNo);
		ITK_CALL(AOM_ask_value_string(NonClrChildRev1, "item_revision_id", &Uses_revision_id));
		printf("\n Uses_revision_id for Part is --> : %s",Uses_revision_id); fflush(stdout);
		fprintf(fplog,"\n\tUses_revision_id for Part is --> : %s\n",Uses_revision_id);

		ITK_CALL(AOM_ask_value_string(clrbvr, "current_name", &Uses_bvrName));
		printf("\n Uses_bvrName for Part is --> : %s",Uses_bvrName); fflush(stdout);
		fprintf(fplog,"\n\t Uses_bvrName for Part is --> : %s\n",Uses_bvrName);

		ITK_CALL(PS_list_occurrences_of_bvr(clrbvr, &n_occs, &occsal));
		printf("\n InMain  no:of:occurances are --->%d",n_occs); fflush(stdout);
		fprintf(fplog,"\n\t InMain  no:of:occurances are --->%d \n",n_occs);
		ChildOccNon=0;

		if(n_occs > 0)
		{	
			 for (iy = 0; iy<n_occs; iy++)
			 {
				 ITK_CALL(PS_ask_occurrence_child(clrbvr,occsal[iy], &ChildItem, &bvrchild));
				 ITK_CALL(AOM_ask_value_string(ChildItem, "item_id", &occ_item_id));
				 if(tc_strcmp(occ_item_id,UsesPartNo)==0)
				 {
					printf("\n occ_item_id & child_item_id  :%s=%s ---Matched ",occ_item_id,UsesPartNo);fflush(stdout);
					ChildOccNon=1;
					break;
				 }								 
			 }
		}
		
		printf("\n ChildOccNon values is----------------->%d",ChildOccNon); fflush(stdout);
		printf("\n NClrQty3----------------->%d \n",NClrQty3); fflush(stdout);
		 fprintf(fplog,"\n\t NClrQty3----------------->%d \n",NClrQty3);
		if(ChildOccNon==0)
		{
			
		 // ITK_CALL(PS_where_used_all(NonClrChildRev1,1,&NonClrparents_cnt,&NonClrn_levels,&NonClroccparents));  //added by Gajanan for BOM Mistmatch
		 // printf("\n\t where_used count of objects are fo create ps structure : %d",NonClrparents_cnt); fflush(stdout);
		// if (NonClrparents_cnt > 0)
		// {
		//	 for (aj =0 ;aj<NonClrparents_cnt ;aj++)bl_item_item_id 

	   //   {
			 //  NonClrsglPrntTag =NonClroccparents[aj];
				ITK_CALL(AOM_UIF_ask_value(NClrparents,"bl_item_item_id",&NonClrParentPartNumber));
			  printf("\n Non-Clr parent part number printed is  ..............%s \n",NonClrParentPartNumber);fflush(stdout);
			  fprintf(fplog,"\n\tNon-Clr parent part number printed is  ..............%s \n",NonClrParentPartNumber);

				if (tc_strstr(Uses_bvrName,NonClrParentPartNumber)!= NULL)
				{
				  
					if(NClrQty3>0)
					{
						for (i=0; i<NClrQty3; i++)
						{	
							ITK_CALL(PS_create_occurrences(clrbvr, NonClrChildRev1, NULLTAG,1, &occs ));   //need to compare parent id with child
							printf("\n PS_create_occurrences successfully in PSE------->");
						}
					}else if (NClrQty3==0)
					{
						ITK_CALL(PS_create_occurrences(clrbvr, NonClrChildRev1, NULLTAG,1, &occs ));
						printf("\n PS_create_occurrences successfully in PSE------->");
					}
					ITK_CALL(AOM_save_without_extensions(clrbvr))
					ITK_CALL(AOM_refresh(clrbvr,0));

				}
		//  }
		// }
		  
		  
			
		}	
		else
		{
			printf("\n Already available in BOM------------>"); fflush(stdout);	
		}
		return ITK_ok;
	}

	int CurrentViewMaskCClrtag(tag_t ClrRevTag, tag_t	NonClrChildRev2, int NClrQty3, char* CurrentViewMaskC)
	{	
		int          stat                = ITK_ok;
		int			 status;
		int			 ifail				 = ITK_ok;
		int		aplFlag_attribute	=	0;
		int		nClhd_nonClrPrt	=	0;
		int		nonCnt1	=	0;
		tag_t	window_nonClrPrt								= NULLTAG;
		tag_t	rule_nonClrPrt								= NULLTAG;
		tag_t	top_line_nonClrPrt							= NULLTAG;
		tag_t   bvr_tag_nonClrPrt     = NULLTAG;
		tag_t  *children_nonClrPrt;
		tag_t Bomline_tag_newColorPrtBm = NULLTAG;
		int iChildItemTag_newColorPrtBm;
		tag_t   t_ChildItemRev_newColorPrtBm;
		char *value_itemid_newColorPrtBm=NULL;
		char *value_itemRevID_newColorPrtBm=NULL;
		char *value_itemRev_newColorPrtBm=NULL;
		char *NonClrPartNo=NULL;
	   // char *sClrQty3 =NULL;
	   
		
		char *sItem_id_grp=NULL;
		char *sItem_id_rev_grp= NULL;
	    tag_t t_itemTag_grp=NULLTAG;
		
		ITK_CALL(AOM_ask_value_string(NonClrChildRev2, "item_id", &NonClrPartNo));
		printf("\n NonClrPartNo*****************************>%s",NonClrPartNo);
		fprintf(fplog,"\n\t NonClrPartNo*****************************>%s \n",NonClrPartNo);
		printf("\n NClrQty3*******************************> [%d] ",NClrQty3);
		printf("\n CurrentViewMaskC***********************> [%s] \n",CurrentViewMaskC);
		int length = snprintf( NULL, 0, "%d",NClrQty3 );
		printf("\n length***********************> [%d] \n",length);
		char* sClrQty3 = malloc( length + 1 );
		snprintf( sClrQty3, length + 1, "%d", NClrQty3);
	     	//sprintf(sClrQty3,"%d",NClrQty3);
			// itoa (NClrQty3,NClrQty3,10);
			printf("\n sClrQty3*******************************> [%s] ",sClrQty3);
			fprintf(fplog,"\n\tsClrQty3*******************************> [%s] \n",sClrQty3);
		if (tc_strcmp(CurrentViewMaskC,"")!=0 || tc_strcmp(sClrQty3,"0")==0 )
		{
			if(ClrRevTag!=NULLTAG)
			{
				ITK_CALL(BOM_create_window (&window_nonClrPrt));
				ITK_CALL(CFM_find("ERC Review And Above", &rule_nonClrPrt));
				ITK_CALL(BOM_set_window_config_rule( window_nonClrPrt, rule_nonClrPrt ));
				ITK_CALL(BOM_set_window_top_line(window_nonClrPrt, null_tag, ClrRevTag, bvr_tag_nonClrPrt, &top_line_nonClrPrt));
				
				if (top_line_nonClrPrt != NULLTAG)
				{
					ITK_CALL(BOM_line_ask_child_lines (top_line_nonClrPrt, &nClhd_nonClrPrt, &children_nonClrPrt));
				}
				printf("\n nClhd_nonClrPrt :: %d \n",nClhd_nonClrPrt);fflush(stdout);

				if(nClhd_nonClrPrt > 0)
				{
					for (nonCnt1 = 0; nonCnt1 < nClhd_nonClrPrt; nonCnt1++)				//New colour part BOM
					{
								t_ChildItemRev_newColorPrtBm=NULLTAG;
								sItem_id_grp=NULL;
								sItem_id_rev_grp=NULL;
						//ITK_CALL(BOM_line_unpack (children_nonClrPrt[nonCnt1]));
						//ITK_CALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag_newColorPrtBm));
						//ITK_CALL(BOM_line_ask_attribute_tag(children_nonClrPrt[nonCnt1], iChildItemTag_newColorPrtBm, &t_ChildItemRev_newColorPrtBm));

						 ITKCALL(AOM_ask_value_string(children_nonClrPrt[nonCnt1], "bl_item_item_id", &sItem_id_grp));
						 ITKCALL(AOM_ask_value_string(children_nonClrPrt[nonCnt1], "bl_rev_item_revision_id", &sItem_id_rev_grp));
						 printf("\n TCUA 14.3 sItem_id_rev_grp---------------->%s ,%s\n",sItem_id_grp,sItem_id_rev_grp); fflush(stdout);
						 fprintf(fplog,"\n\t TCUA 14.3 sItem_id_rev_grp---------------->%s ,%s\n",sItem_id_grp,sItem_id_rev_grp);
											  
						 ITKCALL(ITEM_find_item(sItem_id_grp,&t_itemTag_grp));
						 ITKCALL(ITEM_find_revision(t_itemTag_grp,sItem_id_rev_grp,&t_ChildItemRev_newColorPrtBm));
						if(t_ChildItemRev_newColorPrtBm!=NULLTAG)
						{
							ITK_CALL(AOM_ask_value_string(t_ChildItemRev_newColorPrtBm,"item_id",&value_itemid_newColorPrtBm))
							printf("\n Arc Node child value_itemid_newColorPrtBm:%s:[%s] ..............",value_itemid_newColorPrtBm,CurrentViewMaskC);fflush(stdout);
							printf("\n NonClrPartNo ::  %s\n",NonClrPartNo);fflush(stdout);
							fprintf(fplog,"\n\t NonClrPartNo ::  %s\n",NonClrPartNo);

							ITK_CALL(AOM_ask_value_string(t_ChildItemRev_newColorPrtBm,"item_revision_id",&value_itemRevID_newColorPrtBm))
							//printf("\n D.child value_itemRevID_newColorPrtBm:%s ..............",value_itemRevID_newColorPrtBm);fflush(stdout);

							ITK_CALL(AOM_ask_value_string(t_ChildItemRev_newColorPrtBm,"t5_ColourInd",&value_itemRev_newColorPrtBm))
							//printf("\n D.child value_itemRev_newColorPrtBm:%s ..............",value_itemRev_newColorPrtBm);fflush(stdout);
							
							Bomline_tag_newColorPrtBm = children_nonClrPrt[nonCnt1];
							//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CurrentViewMaskC",&aplFlag_attribute));
							//printf("\n InMain  aplFlag_attribute2--->%d",aplFlag_attribute); fflush(stdout);									
						if (tc_strcmp(CurrentViewMaskC,"")!=0)
						{
							if(tc_strstr(value_itemid_newColorPrtBm,NonClrPartNo)!=NULL) 
							{

								printf("\n CurrentViewMaskC----------------->[%s]",CurrentViewMaskC);
								//ITK_CALL(BOM_line_set_attribute_string(Bomline_tag_newColorPrtBm, aplFlag_attribute, CurrentViewMaskC));
								ITK_CALL(AOM_UIF_set_value(Bomline_tag_newColorPrtBm, "bl_occ_t5_CurrentViewMaskC",CurrentViewMaskC));
								printf("\n CurrentViewMaskC successfully in PSE2------->%s",CurrentViewMaskC);
								fprintf(fplog,"\n\tCurrentViewMaskC successfully in PSE2------->[%s]\n",CurrentViewMaskC);
							}
						}
						if (tc_strcmp(sClrQty3,"0")==0)
						{
							if(tc_strstr(value_itemid_newColorPrtBm,NonClrPartNo)!=NULL) 
							{
								//ITK_CALL(BOM_line_look_up_attribute("bl_quantity", &QuantityAttrId));
								printf("\n sClrQty3----------------->[%s]",sClrQty3);
								fprintf(fplog,"\n\tsClrQty3----------------->[%s]\n",sClrQty3);
								AOM_UIF_set_value(Bomline_tag_newColorPrtBm, "bl_quantity",sClrQty3);
								//ITK_CALL(BOM_line_set_attribute_value(Bomline_tag_newColorPrtBm, QuantityAttrId, sClrQty3));
								printf("\n sClrQty3 successfully in PSE2------->%s",sClrQty3);
							}

						}	

							
						}
					}		
				}
			}
		}
		return ITK_ok;
	}

	int CarOptionalCSSet(tag_t ChildClrRev, char *UniqeOptionalCS, char *OptionalCSAttr)
	{
		int status;
		char* ClrItemID=NULL;
		tag_t   window1=NULLTAG;
		tag_t   window=NULLTAG;
		tag_t   rule1	=NULLTAG;
		tag_t   rule	=NULLTAG;
		tag_t   top_line1=NULLTAG;
		tag_t   top_line=NULLTAG;
		int n_parents,jd =0;
		int *levels = 0;
		tag_t *parents = NULLTAG;
		tag_t ParentAssyTag = NULLTAG;
		char*	 ParentPartNum			= NULL;
		char*	 NClrItem_id			= NULL;
		int n_count,bl_occCarOptionalCS =0;
		tag_t   *line = NULL;

		ITK_CALL(BOM_create_window (&window1));		
		ITK_CALL(CFM_find("Latest Working", &rule1));	
		ITK_CALL(BOM_set_window_config_rule(window1, rule1));	
		ITK_CALL(BOM_set_window_pack_all(window1, true));
		ITK_CALL(BOM_set_window_top_line(window1, NULLTAG, ChildClrRev, NULLTAG, &top_line1));
		ITK_CALL(AOM_ask_value_string(top_line1, "bl_item_item_id", &ClrItemID));
		printf("\n ClrItemID-------------> : %s ",ClrItemID);fflush(stdout);
		printf("\n UniqeOptionalCS-------------> : %s ",UniqeOptionalCS);fflush(stdout);
		printf("\n OptionalCSAttr-------------> : %s ",OptionalCSAttr);fflush(stdout);
		
		ITK_CALL(PS_where_used_all(ChildClrRev,1,&n_parents,&levels,&parents));
		printf("\n\t where_used count of objects are : %d",n_parents); fflush(stdout);
		fprintf(fplog,"\n where_used count of objects are : %d",n_parents);
		if(n_parents>0)
		{
			ParentAssyTag=parents[0];
			ITK_CALL(BOM_create_window (&window));		
			ITK_CALL(CFM_find("Latest Working", &rule));	
			ITK_CALL(BOM_set_window_config_rule(window, rule));	
			ITK_CALL(BOM_set_window_pack_all(window, true));
			ITK_CALL(BOM_set_window_top_line(window, NULLTAG, ParentAssyTag, NULLTAG, &top_line));
			ITK_CALL(BOM_line_ask_child_lines(top_line, &n_count, &line));
			printf("\nn_lines-----> %d\n",n_count);
			fprintf(fplog,"\nn_lines-----> %d\n",n_count);
			if(n_count > 0)
			{
				for (jd=0;jd<n_count ;jd++ )
				{
					ITK_CALL(AOM_ask_value_string(line[jd], "bl_item_item_id", &NClrItem_id));
					printf("\n NClrItem_id is--> : %s\n",NClrItem_id); fflush(stdout);
					if(tc_strcmp(ClrItemID,NClrItem_id)==0)
					{	
							if(tc_strcmp(OptionalCSAttr,"bl_occ_t5_CarOptionalCS")==0)
							{
								if(tc_strcmp(UniqeOptionalCS,"E99 (In-house production-Back Flush Items)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","E99"));
								}else if(tc_strcmp(UniqeOptionalCS,"E50 (In-house production-Phantom Assembly)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","E50"));
								}else if(tc_strcmp(UniqeOptionalCS,"E98 (In-house production-SPD items - Ph)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","E98"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F30 (External procurement - Subcontracting)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","F30"));
								}else if(tc_strcmp(UniqeOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","F18"));
								}else if(tc_strcmp(UniqeOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","F19"));
								}else if(tc_strcmp(UniqeOptionalCS,"F35 (Interplant stock transfer using 301 movement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","F35"));
								}else if(tc_strcmp(UniqeOptionalCS,"F40 (Interplant stock Transfer using STSA)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","F40"));
								}else if(tc_strcmp(UniqeOptionalCS,"E (GroupID CS)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_CarOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_CarOptionalCS","E"));
								}else
								{
									printf("\n UniqeOptionalCS---------------> : %s\n",UniqeOptionalCS); fflush(stdout);
								}
							}

							if(tc_strcmp(OptionalCSAttr,"bl_occ_t5_DwdOptionalCS")==0)
							{
								if(tc_strcmp(UniqeOptionalCS,"E99 (In-house production-Back Flush Items)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","E99"));
								}else if(tc_strcmp(UniqeOptionalCS,"E50 (In-house production-Phantom Assembly)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","E50"));
								}else if(tc_strcmp(UniqeOptionalCS,"E98 (In-house production-SPD items - Ph)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","E98"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F30 (External procurement - Subcontracting)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","F30"));
								}else if(tc_strcmp(UniqeOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","F18"));
								}else if(tc_strcmp(UniqeOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","F19"));
								}else if(tc_strcmp(UniqeOptionalCS,"F35 (Interplant stock transfer using 301 movement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","F35"));
								}else if(tc_strcmp(UniqeOptionalCS,"F40 (Interplant stock Transfer using STSA)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","F40"));
								}else if(tc_strcmp(UniqeOptionalCS,"E (GroupID CS)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_DwdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_DwdOptionalCS","E"));
								}else
								{
									printf("\n UniqeOptionalCS---------------> : %s\n",UniqeOptionalCS); fflush(stdout);
								}
							}

							if(tc_strcmp(OptionalCSAttr,"bl_occ_t5_PunOptionalCS")==0)
							{
								if(tc_strcmp(UniqeOptionalCS,"E99 (In-house production-Back Flush Items)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","E99"));
								}else if(tc_strcmp(UniqeOptionalCS,"E50 (In-house production-Phantom Assembly)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","E50"));
								}else if(tc_strcmp(UniqeOptionalCS,"E98 (In-house production-SPD items - Ph)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","E98"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F30 (External procurement - Subcontracting)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","F30"));
								}else if(tc_strcmp(UniqeOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","F18"));
								}else if(tc_strcmp(UniqeOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","F19"));
								}else if(tc_strcmp(UniqeOptionalCS,"F35 (Interplant stock transfer using 301 movement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","F35"));
								}else if(tc_strcmp(UniqeOptionalCS,"F40 (Interplant stock Transfer using STSA)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","F40"));
								}else if(tc_strcmp(UniqeOptionalCS,"E (GroupID CS)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunOptionalCS","E"));
								}else
								{
									printf("\n UniqeOptionalCS---------------> : %s\n",UniqeOptionalCS); fflush(stdout);
								}
							}

							if(tc_strcmp(OptionalCSAttr,"bl_occ_t5_PunUVOptionalCS")==0)
							{
								if(tc_strcmp(UniqeOptionalCS,"E99 (In-house production-Back Flush Items)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","E99"));
								}else if(tc_strcmp(UniqeOptionalCS,"E50 (In-house production-Phantom Assembly)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","E50"));
								}else if(tc_strcmp(UniqeOptionalCS,"E98 (In-house production-SPD items - Ph)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","E98"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F30 (External procurement - Subcontracting)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","F30"));
								}else if(tc_strcmp(UniqeOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","F18"));
								}else if(tc_strcmp(UniqeOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","F19"));
								}else if(tc_strcmp(UniqeOptionalCS,"F35 (Interplant stock transfer using 301 movement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","F35"));
								}else if(tc_strcmp(UniqeOptionalCS,"F40 (Interplant stock Transfer using STSA)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","F40"));
								}else if(tc_strcmp(UniqeOptionalCS,"E (GroupID CS)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PunUVOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PunUVOptionalCS","E"));
								}else
								{
									printf("\n UniqeOptionalCS---------------> : %s\n",UniqeOptionalCS); fflush(stdout);
								}
							}

							if(tc_strcmp(OptionalCSAttr,"bl_occ_t5_JsrOptionalCS")==0)
							{
								if(tc_strcmp(UniqeOptionalCS,"E99 (In-house production-Back Flush Items)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","E99"));
								}else if(tc_strcmp(UniqeOptionalCS,"E50 (In-house production-Phantom Assembly)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","E50"));
								}else if(tc_strcmp(UniqeOptionalCS,"E98 (In-house production-SPD items - Ph)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","E98"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F30 (External procurement - Subcontracting)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","F30"));
								}else if(tc_strcmp(UniqeOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","F18"));
								}else if(tc_strcmp(UniqeOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","F19"));
								}else if(tc_strcmp(UniqeOptionalCS,"F35 (Interplant stock transfer using 301 movement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","F35"));
								}else if(tc_strcmp(UniqeOptionalCS,"F40 (Interplant stock Transfer using STSA)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","F40"));
								}else if(tc_strcmp(UniqeOptionalCS,"E (GroupID CS)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JsrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JsrOptionalCS","E"));
								}else
								{
									printf("\n UniqeOptionalCS---------------> : %s\n",UniqeOptionalCS); fflush(stdout);
								}
							}

							if(tc_strcmp(OptionalCSAttr,"bl_occ_t5_LkoOptionalCS")==0)
							{
								if(tc_strcmp(UniqeOptionalCS,"E99 (In-house production-Back Flush Items)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","E99"));
								}else if(tc_strcmp(UniqeOptionalCS,"E50 (In-house production-Phantom Assembly)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","E50"));
								}else if(tc_strcmp(UniqeOptionalCS,"E98 (In-house production-SPD items - Ph)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","E98"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F30 (External procurement - Subcontracting)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","F30"));
								}else if(tc_strcmp(UniqeOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","F18"));
								}else if(tc_strcmp(UniqeOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","F19"));
								}else if(tc_strcmp(UniqeOptionalCS,"F35 (Interplant stock transfer using 301 movement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","F35"));
								}else if(tc_strcmp(UniqeOptionalCS,"F40 (Interplant stock Transfer using STSA)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","F40"));
								}else if(tc_strcmp(UniqeOptionalCS,"E (GroupID CS)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_LkoOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_LkoOptionalCS","E"));
								}else
								{
									printf("\n UniqeOptionalCS---------------> : %s\n",UniqeOptionalCS); fflush(stdout);
								}
							}

							if(tc_strcmp(OptionalCSAttr,"bl_occ_t5_PnrOptionalCS")==0)
							{
								if(tc_strcmp(UniqeOptionalCS,"E99 (In-house production-Back Flush Items)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","E99"));
								}else if(tc_strcmp(UniqeOptionalCS,"E50 (In-house production-Phantom Assembly)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","E50"));
								}else if(tc_strcmp(UniqeOptionalCS,"E98 (In-house production-SPD items - Ph)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","E98"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F30 (External procurement - Subcontracting)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","F30"));
								}else if(tc_strcmp(UniqeOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","F18"));
								}else if(tc_strcmp(UniqeOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","F19"));
								}else if(tc_strcmp(UniqeOptionalCS,"F35 (Interplant stock transfer using 301 movement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","F35"));
								}else if(tc_strcmp(UniqeOptionalCS,"F40 (Interplant stock Transfer using STSA)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","F40"));
								}else if(tc_strcmp(UniqeOptionalCS,"E (GroupID CS)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_PnrOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_PnrOptionalCS","E"));
								}else
								{
									printf("\n UniqeOptionalCS---------------> : %s\n",UniqeOptionalCS); fflush(stdout);
								}
							}

							if(tc_strcmp(OptionalCSAttr,"bl_occ_t5_JdlOptionalCS")==0)
							{
								if(tc_strcmp(UniqeOptionalCS,"E99 (In-house production-Back Flush Items)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","E99"));
								}else if(tc_strcmp(UniqeOptionalCS,"E50 (In-house production-Phantom Assembly)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","E50"));
								}else if(tc_strcmp(UniqeOptionalCS,"E98 (In-house production-SPD items - Ph)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","E98"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F30 (External procurement - Subcontracting)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","F30"));
								}else if(tc_strcmp(UniqeOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","F18"));
								}else if(tc_strcmp(UniqeOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","F19"));
								}else if(tc_strcmp(UniqeOptionalCS,"F35 (Interplant stock transfer using 301 movement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","F35"));
								}else if(tc_strcmp(UniqeOptionalCS,"F40 (Interplant stock Transfer using STSA)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","F40"));
								}else if(tc_strcmp(UniqeOptionalCS,"E (GroupID CS)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_JdlOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_JdlOptionalCS","E"));
								}else
								{
									printf("\n UniqeOptionalCS---------------> : %s\n",UniqeOptionalCS); fflush(stdout);
								}
							}

							if(tc_strcmp(OptionalCSAttr,"bl_occ_t5_AhdOptionalCS")==0)
							{
								if(tc_strcmp(UniqeOptionalCS,"E99 (In-house production-Back Flush Items)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","E99"));
								}else if(tc_strcmp(UniqeOptionalCS,"E50 (In-house production-Phantom Assembly)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","E50"));
								}else if(tc_strcmp(UniqeOptionalCS,"E98 (In-house production-SPD items - Ph)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","E98"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F (External procurement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","F"));
								}else if(tc_strcmp(UniqeOptionalCS,"F30 (External procurement - Subcontracting)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","F30"));
								}else if(tc_strcmp(UniqeOptionalCS,"F18 (External procurement-Assy/Comp recd in assembled condition with Party's matl)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","F18"));
								}else if(tc_strcmp(UniqeOptionalCS,"F19 (External procurement-In-house machining of Assy/Comp(recd from outside party W/o TML Matl))")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","F19"));
								}else if(tc_strcmp(UniqeOptionalCS,"F35 (Interplant stock transfer using 301 movement)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","F35"));
								}else if(tc_strcmp(UniqeOptionalCS,"F40 (Interplant stock Transfer using STSA)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","F40"));
								}else if(tc_strcmp(UniqeOptionalCS,"E (GroupID CS)")==0)
								{
									//ITK_CALL(BOM_line_look_up_attribute ("bl_occ_t5_AhdOptionalCS",&bl_occCarOptionalCS));
									ITK_CALL(AOM_UIF_set_value(line[jd], "bl_occ_t5_AhdOptionalCS","E"));
								}else
								{
									printf("\n UniqeOptionalCS---------------> : %s\n",UniqeOptionalCS); fflush(stdout);
								}
							}
					}
				}			
			}	  
		}
	}

	int OccurSetTopLineClr(tag_t  clrbvr, char* UsesPartNo, int occ_qty,tag_t NClrParents,int ColRlzRevFlag)
	{

		int          stat                = ITK_ok;
		int			 status;
		int			 ifail				 = ITK_ok;
		tag_t        UseMaster           = NULLTAG;
		tag_t        Nrev                = NULLTAG;
		tag_t        Occ_Child;
		char		*PartNumber			 = NULL;
		char		*bvrCurrentName			 = NULL;
		char		*occ_item_id			 = NULL;
		tag_t       objNameType=NULLTAG;
		char   type_name[TCTYPE_name_size_c+1];
		tag_t  *occs=NULL;
		tag_t	ChildItem		= NULLTAG;
		tag_t	bvrchild		= NULLTAG;
		int n_occs;
		tag_t *occsal;
		int ChildOccNon,iy,i =0;
		int parents_cnt,jd =0;
		int *n_levels = 0;
		int ai =0;
		tag_t *occparents = NULLTAG;
		tag_t sglPrntTag = NULLTAG;
		char *ParentPartNumber =NULL;
		printf("\n Uses Part Number is ------> %s",UsesPartNo);
		
		ITK_CALL(ITEM_find_item(UsesPartNo,&UseMaster))
		printf("\n UseMaster found------>");
		
		ITK_CALL(ITEM_ask_latest_rev(UseMaster, &Nrev));
		printf("\n Childrev found------>");
		
		ITK_CALL(AOM_UIF_ask_value(Nrev,"item_id",&PartNumber));
		ITK_CALL(AOM_UIF_ask_value(clrbvr,"current_name",&bvrCurrentName));
		printf("\n PartNumber : %s = bvrName :%s ..............",PartNumber,bvrCurrentName);fflush(stdout);
		printf("\n InExpansion PS_ask_occurrence_qty--->%d",occ_qty); fflush(stdout);

		ITK_CALL(PS_list_occurrences_of_bvr(clrbvr, &n_occs, &occsal));
		printf("\n InMain  no:of:occurances are --->%d",n_occs); fflush(stdout);
		fprintf(fplog,"\n\t InMain  no:of:occurances are --->%d",n_occs);
		ChildOccNon=0;

		if(n_occs > 0)
		{	
			 for (iy = 0; iy<n_occs; iy++)
			 {
				 ITK_CALL(PS_ask_occurrence_child(clrbvr,occsal[iy], &ChildItem, &bvrchild));
				 ITK_CALL(AOM_ask_value_string(ChildItem, "item_id", &occ_item_id));
				 if(tc_strcmp(occ_item_id,UsesPartNo)==0)
				 {
					printf("\n occ_item_id & child_item_id  :%s=%s ---Matched ",occ_item_id,UsesPartNo);fflush(stdout);
					fprintf(fplog,"\n\tocc_item_id & child_item_id  :%s=%s ---Matched ",occ_item_id,UsesPartNo);
					ChildOccNon=1;
					break;
				 }								 
			 }
		}
   if (ChildOccNon==0)
   {
   		//ITK_CALL(PS_where_used_all(Nrev,1,&parents_cnt,&n_levels,&occparents));   //added by Gajanan for BOM Mistmatch
		//printf("\n\t where_used Clr count of objects are fo create ps structure : %d",parents_cnt); fflush(stdout);
		//if(parents_cnt>0)
		//{
		 // 	for (ai=0;ai<parents_cnt;ai++)
		//	{ 
				
			//	sglPrntTag=occparents[0];
				ITK_CALL(AOM_UIF_ask_value(NClrParents,"bl_item_item_id",&ParentPartNumber));
				printf("\n parent part number printed is  ..............%s ",ParentPartNumber);fflush(stdout);
				fprintf(fplog,"\n parent part number printed is  ..............%s=%s ",bvrCurrentName,ParentPartNumber);
				if (tc_strstr(bvrCurrentName,ParentPartNumber)!=NULL)
				{

					if(occ_qty > 0)
					{
						for (i = 0; i < occ_qty; i++)
						{	
							
							ITK_CALL(PS_create_occurrences(clrbvr, Nrev, NULLTAG,1, &occs ))   // TBD
							printf("\n PS_create_occurrences successfully in PSE------->");
							fprintf(fplog,"\n PS_create_occurrences successfully in PSE------->");
						}
					}
				}
			//}
			
	   // }
		
		

		ITK_CALL(AOM_save_without_extensions(clrbvr) )
		ITK_CALL(AOM_refresh(clrbvr,0));

	}
	else
	{
		printf("\n Already available in BOM------------>"); fflush(stdout);
		fprintf(fplog,"\n  Already available in BOM------------>");
	}
		return ITK_ok;
	}

	int OccurSetTopLineToClr(tag_t  clrbvr, char* UsesPartNo, int occ_qty)  // TBD
	{
		int          stat                = ITK_ok;
		int			 status;
		int			 ifail				 = ITK_ok;
		tag_t        UseMaster           = NULLTAG;
		tag_t        Nrev                = NULLTAG;
		tag_t        Occ_Child;
		char		*PartNumber			 = NULL;
		char		*bvrCurrentName			 = NULL;
		char		*occ_item_id			 = NULL;
		tag_t       objNameType=NULLTAG;
		char   type_name[TCTYPE_name_size_c+1];
		tag_t  *occs=NULL;
		tag_t	ChildItem		= NULLTAG;
		tag_t	bvrchild		= NULLTAG;
		int n_occs;
		tag_t *occsal;
		int iy,i =0;

		printf("\n Uses Part Number is ------> %s",UsesPartNo);
		ITK_CALL(ITEM_find_item(UsesPartNo,&UseMaster))
		ITK_CALL(ITEM_ask_latest_rev(UseMaster, &Nrev));	
			ITK_CALL(AOM_UIF_ask_value(Nrev,"item_id",&PartNumber));
		ITK_CALL(AOM_UIF_ask_value(clrbvr,"current_name",&bvrCurrentName));
		printf("\n PartNumber : %s = current_nameBVR : %s ------------->",PartNumber, bvrCurrentName); fflush(stdout);
		printf("\n InExpansion PS_ask_occurrence_qty--->%d",occ_qty); fflush(stdout);
		if(occ_qty > 0)
		{
			for (i = 0; i < occ_qty; i++)
			{	
				ITK_CALL(PS_create_occurrences(clrbvr, Nrev, NULLTAG,1, &occs ))
				printf("\n PS_create_occurrences successfully in PSE------->");
			}
		}
		ITK_CALL(AOM_save_without_extensions(clrbvr) )
		ITK_CALL(AOM_refresh(clrbvr,0));
		return ITK_ok;
	}

	int ValColAndNonColBomAttrForRevise(tag_t NonClrRev,tag_t Clrrev,int ColRevRlzStatus, tag_t ColSchmRevTag)
	{
		int ifail = ITK_ok;
		int no_bom_linesN, jnc=0;
		int no_bom_linesC, jc=0;
		int FlagchildPresentInBom=0;
		int FlagBomDiff=0;
		int Cmpcount2, k2, CompCodeMatchFlag=0;

		tag_t windowNC=NULLTAG;
		tag_t windowClr=NULLTAG;
		tag_t rule = NULLTAG;
		tag_t ruleClr = NULLTAG;
		tag_t top_lineNC = NULLTAG;
		tag_t top_lineClr = NULLTAG;
		tag_t CmpCodeObj2 = NULLTAG;

		tag_t *child_bom_linesNC = NULLTAG;
		tag_t *child_bom_linesC = NULLTAG;
		tag_t *CmpCodeOfClrScheme2 = NULLTAG;

		char *child_item_idN = NULL;
		char *child_item_idN2 = NULL;
		char *ChildRevSeqN = NULL;
		char *ChildColIndN = NULL;
		char *child_item_idC = NULL;
		char *ChildRevSeqC = NULL;
		char *ChildColIndC = NULL;
		char *CmpCodeCmp2 = NULL;
		char *t5ClSrl = NULL;
		char *Suffix = NULL;
		char *ColourID = NULL;
		char *ChildNCCompCode = NULL;
		int rulefound= 0;
		tag_t *closurerule = NULL;
		tag_t close_tag;
		char **rulename = NULL;
		char **rulevalue = NULL;
        char *sClrItem_id = NULL;
		char *sNClrItem_id = NULL;
		child_item_idN2=(char *) MEM_alloc(50);
		
		ifail = BOM_create_window (&windowNC);
		ifail = BOM_create_window (&windowClr);


		ifail = AOM_ask_value_string(Clrrev, "item_id", &sClrItem_id);
		ifail = AOM_ask_value_string(NonClrRev, "item_id", &sNClrItem_id);
		fprintf(fplog,"\n\t Colour item_id: %s  NonColour item_id: %s",sClrItem_id,sNClrItem_id);
		ifail = CFM_find( "ERC release and above", &rule );	//Non-colour
		ifail = BOM_set_window_config_rule( windowNC, rule );	//Non-colour
		//PIE_find_closure_rules("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule);  // uncoment by Gajanan 15/05/23 for bom mistmatch
		PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule);  // uncoment by Gajanan 15/05/23 for bom mistmatch
		if (rulefound > 0)
			{
				close_tag = closurerule[0];
				printf ("closure rule found \n");fflush(stdout);
			}
		ifail=BOM_window_set_closure_rule(windowNC,close_tag, 0, rulename,rulevalue);

		ifail = BOM_set_window_top_line (windowNC, null_tag, NonClrRev, null_tag, &top_lineNC);
		ifail = BOM_window_show_suppressed ( windowNC );
		ifail = BOM_line_ask_child_lines (top_lineNC, &no_bom_linesN, &child_bom_linesNC);

		//colour
		if (ColRevRlzStatus==1)
		{
			//ifail = CFM_find( "Color ERC release and above", &ruleClr );//colour
			ifail = CFM_find( "ERC release and above", &ruleClr );//colour
		}
		else
		{
			ifail = CFM_find( "ERC Review And Above", &ruleClr );//colour
		}
		ifail = BOM_set_window_config_rule( windowClr, ruleClr ); 
		ifail = BOM_window_set_closure_rule(windowClr,close_tag, 0, rulename,rulevalue);
		ifail = BOM_set_window_top_line (windowClr, null_tag, Clrrev, null_tag, &top_lineClr);
		ifail = BOM_window_show_suppressed ( windowClr );
		ifail = BOM_line_ask_child_lines (top_lineClr, &no_bom_linesC, &child_bom_linesC);
		
		printf("\n\t no_bom_linesN: %d   no_bom_linesC: %d",no_bom_linesN,no_bom_linesC);fflush(stdout);
		fprintf(fplog,"\n\t no_bom_linesN: %d   no_bom_linesC: %d",no_bom_linesN,no_bom_linesC);

		FlagBomDiff=0;
		ifail = GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRelMultlvl, &Cmpcount2, &CmpCodeOfClrScheme2);
		printf("\n\t\t MultilevelExpantion Comp Code count from Color Scheme is : %d",Cmpcount2); fflush(stdout);
		fprintf(fplog,"\n\tMultilevelExpantion Comp Code count from Color Scheme is : %d",Cmpcount2);

		for (jnc = 0; jnc < no_bom_linesN; jnc++) //Non-Colour Bom loop
		{
			ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_item_item_id",&child_item_idN);
			if (strstr(child_item_idN,"_")!=NULL)
			{
				continue;
			}
			if (strcmp(subString(child_item_idN,0,1),"G")==0)
			{
				continue;
			}

			ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_rev_item_revision_id",&ChildRevSeqN);
			//ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndN);
			ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_Design Revision_t5_ColourInd",&ChildColIndN);

			printf("\n\n\t A--jnc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jnc,child_item_idN,ChildRevSeqN,ChildColIndN);fflush(stdout);

			strcpy(child_item_idN2,"");
			tc_strcpy(child_item_idN2,child_item_idN);
			CompCodeMatchFlag==0;
			if (strcmp(ChildColIndN,"Y")==0)
			{
				ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_PrtCatCode",&ChildNCCompCode);
				if (SchmWithCmpcdRelMultlvl != NULLTAG)
				{
					if(Cmpcount2 > 0)
					{
						for (k2=0;k2<Cmpcount2 ;k2++ )
						{
							if(CmpCodeObj2) CmpCodeObj2=NULLTAG;
							CmpCodeObj2=CmpCodeOfClrScheme2[k2];
							ifail = AOM_ask_value_string(CmpCodeObj2, "t5_PrtCatCode", &CmpCodeCmp2 );
							
							if(tc_strcmp(ChildNCCompCode,CmpCodeCmp2)==0)
							{
								printf("\n\t\t CmpCodeCmp2 & ChildNCCompCode status--> : [%s]==[%s]",CmpCodeCmp2,ChildNCCompCode); fflush(stdout);
								fprintf(fplog,"\n\t---Matching CmpCodeCmp2 & ChildNCCompCode status--> : [%s]==[%s]",CmpCodeCmp2,ChildNCCompCode);
								
								CompCodeMatchFlag=1;
								ifail = AOM_ask_value_string(CmpCodeObj2, "t5_ClSrl", &t5ClSrl );
								Suffix =  strtok(t5ClSrl,";");
								ColourID  =  strtok(NULL,";");
								
								tc_strcat(child_item_idN2,Suffix);

								break;
							}
							else
							{
								printf("\n\t\t unable to Mach comp code  CmpCodeCmp2 & ChildNCCompCode status--> : [%s]==[%s]",CmpCodeCmp2,ChildNCCompCode); fflush(stdout);
								//fprintf(fplog,"\n\t---unable to Match comp code  CmpCodeCmp2 & ChildNCCompCode status--> : [%s]==[%s]",CmpCodeCmp2,ChildNCCompCode);
							}
						}
					}
				}
			}
			FlagchildPresentInBom=0;
			for (jc = 0; jc < no_bom_linesC; jc++)
			{
				//ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndC);
				ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_Design Revision_t5_ColourInd",&ChildColIndC);

				//if ((strcmp(ChildColIndC,"Y")==0)||(strcmp(ChildColIndC,"C")==0))
				//{
					ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_item_item_id",&child_item_idC);
					if (strstr(child_item_idC,"_")!=NULL)
					{
						continue;
					}
					if (strcmp(subString(child_item_idC,0,1),"G")==0)
					{
						continue;
					}

					ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_rev_item_revision_id",&ChildRevSeqC);

					if (strstr(child_item_idC,child_item_idN)!=NULL)
					{
						printf("\n\t A--jc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jc,child_item_idC,ChildRevSeqC,ChildColIndC);fflush(stdout);
						printf("\n\t   child_item_idC: %s  child_item_idN: %s   child_item_idN2: %s  ",child_item_idC,child_item_idN,child_item_idN2);fflush(stdout);
						fprintf(fplog,"\n\t A--jc: child_item_idC: %s  child_item_idN: %s   child_item_idN2: %s  ",child_item_idC,child_item_idN,child_item_idN2);
						if (strcmp(child_item_idC,child_item_idN2)==0)
						{
							FlagchildPresentInBom=1;
							break;
						}
						else
						{
							fprintf(fplog,"\n\t -----Unable to Match........... ");
						}
					}
				//}
			}
			if (FlagchildPresentInBom==0)
			{
				FlagBomDiff++;
			}
			printf(" -- FlagchildPresentInBom: %d  FlagBomDiff: %d",FlagchildPresentInBom,FlagBomDiff); fflush(stdout);
			fprintf(fplog,"\n\t  -- FlagchildPresentInBom: %d  FlagBomDiff: %d",FlagchildPresentInBom,FlagBomDiff);
			//}
		}
		printf("\n\t A--FlagBomDiff: %d",FlagBomDiff);fflush(stdout);
		fprintf(fplog,"\n\t  A--FlagBomDiff: %d",FlagBomDiff);
		if (FlagBomDiff==0)
		{
			for (jc = 0; jc < no_bom_linesC; jc++) //Colour Bom loop
			{
				ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndC);
				ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_item_item_id",&child_item_idC);
				if (strstr(child_item_idC,"_")!=NULL)
				{
					continue;
				}
				if (strcmp(subString(child_item_idC,0,1),"G")==0)
				{
					continue;
				}

				ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_rev_item_revision_id",&ChildRevSeqC);
				printf("\n\n\t B--jc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jc,child_item_idC,ChildRevSeqC,ChildColIndC);fflush(stdout);
				fprintf(fplog,"\n\t  B--jc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jc,child_item_idC,ChildRevSeqC,ChildColIndC);
				
				FlagchildPresentInBom=0;
				for (jnc = 0; jnc < no_bom_linesN; jnc++)
				{
					ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_item_item_id",&child_item_idN);
					if (strstr(child_item_idN,"_")!=NULL)
					{
						continue;
					}
					if (strcmp(subString(child_item_idN,0,1),"G")==0)
					{
						continue;
					}

					ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_rev_item_revision_id",&ChildRevSeqN);
					ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndN);

					if (strstr(child_item_idC,child_item_idN)!=NULL)
					{
						printf("\n\t B--jnc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jnc,child_item_idN,ChildRevSeqN,ChildColIndN);fflush(stdout);
						fprintf(fplog,"\n\tB--jnc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jnc,child_item_idN,ChildRevSeqN,ChildColIndN);
						FlagchildPresentInBom=1;
						break;
					}
				}
				if (FlagchildPresentInBom==0)
				{
					FlagBomDiff++;
				}
			}
		}
		printf("\n\t In ValColAndNonColBomAttrForRevise function,  FlagBomDiff: %d",FlagBomDiff);fflush(stdout);
		fprintf(fplog,"\n\tIn ValColAndNonColBomAttrForRevise function,  FlagBomDiff: %d",FlagBomDiff);
		return FlagBomDiff;
	}

	int MultilevelExpantion(tag_t Clritem, tag_t NonClrRev, tag_t ColSchmRevTag, int NonClrPartlevel,tag_t taskRevTag, tag_t user_tag, tag_t group)
	{
		int		result	= 0;
		int		n_count	= 0;
		int ifail;
		tag_t   window=NULLTAG;
		tag_t   rule	=NULLTAG;	
		tag_t   top_line=NULLTAG;
		tag_t   line=NULLTAG;
		tag_t *Nlines = NULL;
		tag_t   Childobject=NULLTAG;
		tag_t	ItemTag	= NULLTAG;
		int status;
		int    bv_clrcount=0;
		int    clr_bvrcnt=0;
		int    bvrNClr=0;
		tag_t *clr_bvs=NULL;
		tag_t *clrbvrs=NULL;
		tag_t *bvrNonClr=NULL;
		tag_t  clrbv    = NULLTAG;
		tag_t  clrbvr    = NULLTAG;
		tag_t	Clrrev		= NULLTAG;
		char	*child_item_id	 = NULL;
		char	*child_owning_group	 = NULL;
		char	*ChildColInd	 = NULL;
		tag_t	NonClrChildRev		= NULLTAG;
		char	*t5PrtCatCd	 = NULL;
		char	*t5itemid	 = NULL;
		char	*t5NonCPrt	 = NULL;
		char	*t5item_revision_id	 = NULL;
		char	*t5revision_id	 = NULL;
		char	*t5object_desc	 = NULL;
		char	*t5_ColourInd	 = NULL;
		char	*t5_PartStatus	 = NULL;
		char	*t5_DesignGrp	 = NULL;
		char	*t5_ProjectCode	 = NULL;
		char	*t5_DocRemarks	 = NULL;
		char	*t5_DrawingInd	 = NULL;
		char	*t5_PartType	 = NULL;
		char	*t5_PartCode	 = NULL;
		char	*t5_AhdMakeBuyIndicator	 = NULL;
		char	*t5_PunPCBUMakeBuyIndicator	 = NULL;
		char	*t5_PunMakeBuyIndicator	 = NULL;
		char	*t5_DwdMakeBuyIndicator	 = NULL;
		char	*CmpCodeCmp	 = NULL;
		tag_t CmpCodeObj=NULLTAG;
		int Cmpcount,p1,k1 = 0;
		tag_t *CmpCodeOfClrScheme = NULLTAG;
		char*	t5ClSrl=NULL;
		char*	ColourID=NULL;
		char*	itemRevSeq=NULL;
		char *ClrRevSeq = "NR;1";
		char*	t5CoatedS="C";
		int item_revision_id_int =1;
		tag_t ChildClrRev=NULLTAG;
		tag_t ChildClrItem=NULLTAG;
		tag_t tRelationFind;
		tag_t gRelationFind;
		char*	Suffix=NULL;
		tag_t  *occs=NULL;
		tag_t  	   tRelationExist = NULLTAG;
		tag_t 	   Rel_task	= NULLTAG;
		tag_t	ClrPartRev		= NULLTAG;
		char*	Varformula=NULL;
		tag_t RelSolutionItem = NULLTAG;
		tag_t SolutionItemExist = NULLTAG;
		tag_t 	   reltask	= NULLTAG;
		int n_tags_found2 = 0;
		tag_t *tags_found2 = NULLTAG;
		char	*Mitem_Rev_Seq	 = NULL;
		char	*MItem_Rev	 = NULL;
		char	*MItem_Seq	 = NULL;
		char	*itemRevSeq1	 = NULL;
		int rulefound =0;
		tag_t *closurerule = NULL;
		char* Response = NULL ;	
		tag_t close_tag;
		char **rulename = NULL;
		char **rulevalue = NULL;
		tag_t   queryds = NULLTAG;
		int ds_tags_found=0;
		tag_t	*itemrevdsclass	= NULLTAG;
		tag_t ItemTag2	= NULLTAG;
		tag_t ClrPartTag = NULLTAG;
		char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));
		int n_entriesC = 1;
		char *qry_entries[1] = {"ID"};
		char *qry_entriesds[2] = {"Revision","ID"};
		char **qry_valuesds = (char **) MEM_alloc(50 * sizeof(char *));
		int n_entries = 2;	
		char* ResponseStr = NULL ;
		int TskCntMul=0;
		tag_t *TskSOMul=NULLTAG;
		int n_occs;
		tag_t *occsal;
		int iy =0;
		tag_t	ChildItem		= NULLTAG;
		tag_t	bvrchild		= NULLTAG;
		char	*occ_item_id	= NULL;
		int ChildOccNon = 0;
		int ChildOccClr = 0;
		tag_t        ReviseClrPrt           = NULLTAG;
		tag_t        ReviseClrPrtRev        = NULLTAG;

		int g_attchs,g_attchs11,h =0;
		tag_t *secondary_gobjects = NULLTAG;
		tag_t *secondary_gobjects11 = NULLTAG;
		char* Object_id		= NULL;
		int ClrGrpPartPresentFlag=0;
		int flg2 =0;

		int ColStatus_count=0;
		int ColRlzRevFlag=0;
		int cr=0;
		char *ColPrtRelSt=NULL;
		char *NewColPartRevSeq=NULL;
		char *Revise_id=NULL;
		tag_t *Col_relStatus_list = NULLTAG;
		tag_t NewColorRevTag=NULLTAG;
		int noccs,iz =0;
		tag_t *noccsal;
		tag_t	nChildItem		= NULLTAG;
		tag_t	nbvrchild		= NULLTAG;
		char	*nocc_item_id	= NULL;
		char	*clrColourID	= NULL;
		char	*Clrrev_id	= NULL;
		char	*NClrrev_id	= NULL;
		char	*Clrrevision_id	= NULL;
		char	*ClrPartType	= NULL;
		char	*NClrrevision_id	= NULL;
		
		char	*CarOptionalCS		= NULL;
		char	*DwdOptionalCS		= NULL;
		char	*PunOptionalCS		= NULL;
		char	*PunUVOptionalCS	= NULL;
		char	*JsrOptionalCS		= NULL;
		char	*LkoOptionalCS		= NULL;
		char	*PnrOptionalCS		= NULL;
		char	*JdlOptionalCS		= NULL;
		char	*AhdOptionalCS		= NULL;
		char	*CurrentViewMaskC		= NULL;

		tag_t	view_type_tag	=	NULLTAG;
		char	*bs_view_type_name					=	NULL;

		char	*CAROpCs	= NULL;
		tag_t TskCRBTag = NULLTAG;
		tag_t ObjTypTskCRB=NULLTAG;
		int hp=0;
		char   type_name8[TCTYPE_name_size_c+1];
		int QuantityAttrId=0;
		char   *Quantity3=NULL;
		int NClrQty3=0;
		int     bvrcnt=0;
		tag_t   *bvr=NULL;
		tag_t   bvrTag  = NULLTAG;
		int Revoccs,zz =0;
		tag_t *Revccsal;
		char* OptionalCSAttr	=	NULL;	
		int ClrReviseFlag=0;
		
		tag_t ItemTag1 = NULLTAG;
		tag_t UOM_Tag = NULLTAG;
		char  *itemUOM		= NULL;
		char  *UnitOfMeasureS		= NULL;
		int k3=0;
		char* g_ColourID	=	NULL;
		char* ReviseClr_id	=	NULL;
		tag_t ColorID_G=NULLTAG;

		tag_t itemtag1 = NULLTAG;
		int n_rev= 0;
		tag_t *rev1 = NULL;

		printf("\n\n Inside MultilevelExpantion------------------------------->\n");fflush(stdout);
		//ITK_CALL(BOM_line_look_up_attribute("bl_quantity", &QuantityAttrId));
		NonClrPartlevel++;

		if(Clritem !=NULLTAG)
		{
			ifail = ITEM_ask_latest_rev(Clritem,&Clrrev);
			ifail = AOM_ask_value_string(Clrrev, "item_id", &Clrrev_id);
			ifail = AOM_ask_value_string(Clrrev, "item_revision_id", &Clrrevision_id);
			ifail = AOM_ask_value_string(Clrrev, "t5_PartType", &ClrPartType);

			if(tc_strcmp(ClrPartType,"M")==0)
			{
				printf("\n Module---------------------------------------------------------------------------------[%s]=[%s]=[%s]",Clrrev_id,Clrrevision_id,ClrPartType);fflush(stdout);
			}

			printf("\n Clrrev_id & Clrrevision_id: [%s]===[%s]===[%s] ",Clrrev_id,Clrrevision_id,ClrPartType);fflush(stdout);

			ifail = AOM_ask_value_string(NonClrRev, "item_id", &NClrrev_id);
			ifail = AOM_ask_value_string(NonClrRev, "item_revision_id", &NClrrevision_id);
			printf("\n NClrrev_id & NClrrevision_id: [%s]===[%s] ",NClrrev_id,NClrrevision_id);fflush(stdout);
			fprintf(fplog,"\n\t NClrrev_id & NClrrevision_id: [%s]===[%s] : Clrrev_id & Clrrevision_id: [%s]===[%s]",NClrrev_id,NClrrevision_id,Clrrev_id,Clrrevision_id);

			ifail = AOM_UIF_ask_value(NonClrRev,"owning_group",&child_owning_group);
			printf("\n bl_rev_owning_group is--> : %s ",child_owning_group); fflush(stdout);

			if (Clrrev!=NULLTAG)
			{
				ifail = WSOM_ask_release_status_list(Clrrev, &ColStatus_count, &Col_relStatus_list);
				
				if(ColStatus_count > 0)
				{
					ColRlzRevFlag=0;
					for(cr = 0; cr < ColStatus_count; cr++)
					{
						if(AOM_ask_name(Col_relStatus_list[cr], &ColPrtRelSt)==ITK_ok)
						printf("\t ColPrtRelSt: %s ", ColPrtRelSt);fflush(stdout);
                        fprintf(fplog,"\n\t ColPrtRelSt: %s ", ColPrtRelSt);

						if ((tc_strstr(ColPrtRelSt,"T5_LcsErcRlzd")!=NULL) || (tc_strstr(ColPrtRelSt,"ERC Released")!=NULL) )
						{
							//printf("\n\t inside if revision :%d  ",ColRlzRevFlag);fflush(stdout);
                              
							ColRlzRevFlag=1;
							break;
						}
					}
				}
				fprintf(fplog,"\n\tColRlzRevFlag:%d ",ColRlzRevFlag);
				int ReviseStatus = ValColAndNonColBomAttrForRevise(NonClrRev,Clrrev,ColRlzRevFlag,ColSchmRevTag);
				printf("\n\t ColRlzRevFlag:%d  ReviseStatus: %d ",ColRlzRevFlag, ReviseStatus);fflush(stdout);
				fprintf(fplog,"\n\tColRlzRevFlag:%d  ReviseStatus: %d ",ColRlzRevFlag, ReviseStatus);

				ClrReviseFlag=0;
				if ((ColRlzRevFlag==1) && (ReviseStatus>0) )
				{
					tag_t prdProjTag = NULLTAG;
					char **valuesPrj = (char **) MEM_alloc(1 * sizeof(char *));
					int n_entriesPrj = 1;
					char *qry_entriesPrj[1] = {"Name"};
					int n_tags_Prj = 0;
					tag_t *tags_Prj = NULL;	
					char *sProj_Code = NULL;
					sProj_Code=subString(Clrrev_id, 0, 4);
					printf("\n\t Project code count %s = %d ",sProj_Code,n_tags_Prj);fflush(stdout);
					valuesPrj[0] = sProj_Code;
                 if(QRY_find2("Prd_Project", &prdProjTag));
				 if(QRY_execute(prdProjTag, n_entriesPrj, qry_entriesPrj, valuesPrj, &n_tags_Prj, &tags_Prj));
				 printf("\n\t Project code count %s = %d ",sProj_Code,n_tags_Prj);fflush(stdout);
                 if (n_tags_Prj > 0)
                  {
					printf("\t ---Revising....");fflush(stdout);
					fprintf(fplog,"\n\t---colour part Revising....");
					ifail = ITEM_copy_rev(Clrrev,NULL,&NewColorRevTag);
					if (NewColorRevTag!=NULLTAG)
					{
						ClrReviseFlag=1;
						ifail = AOM_ask_value_string(NewColorRevTag,"item_id",&Revise_id);
						ifail = AOM_ask_value_string(NewColorRevTag,"current_revision_id",&ReviseClr_id);
						printf("\n\t Revise Color Part ID------> %s",ReviseClr_id);fflush(stdout);
						fprintf(fplog,"\n\t Revise Color Part ID------> %s",ReviseClr_id);
					
						Clrrev=NULLTAG;
						Clrrev=NewColorRevTag;		
						
						if(Revise_id!=NULL)
						{
							ifail = ITEM_find_item(Revise_id,&ReviseClrPrt);
							//printf("\n ReviseClrPrt found------>");fflush(stdout);
							
							ifail = ITEM_ask_latest_rev(ReviseClrPrt, &ReviseClrPrtRev);
							//printf("\n ReviseClrPrtRev found------>");fflush(stdout);
							 
							 printf ( "\n Global SchDataToGov is -------> %s",SchDataToGov);fflush(stdout);
							 fprintf(fplog,"\n\t--->Global SchDataToGov is -------> %s",SchDataToGov);
							ifail = AOM_lock(ReviseClrPrtRev);
							ifail = AOM_set_value_string(ReviseClrPrtRev,"gov_classification","");
							ifail = AOM_save_without_extensions(ReviseClrPrtRev);
							ifail = AOM_unlock(ReviseClrPrtRev);

							//REVISE PART ATTACHED TO THE DML TASK
							ifail = GRM_find_relation_type("CMHasSolutionItem",&RelSolutionItem);
							if (RelSolutionItem!=NULLTAG)
							{
								printf("\n\tGoing to create revise Color Part relation to DML task------------>");fflush(stdout);
								fprintf(fplog,"\n\tGoing to create revise Color Part relation to DML task------------>");
								ifail = GRM_create_relation(taskRevTag,Clrrev,RelSolutionItem,NULLTAG,&reltask);
								ifail = GRM_save_relation(reltask); 
								ifail = AOM_refresh(reltask,0);
							}

							//REVISE PART CREATE RELATION WITH NON-COLOR PART				
							ifail = GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind);
							if (tRelationFind!=NULLTAG)
							{	
								printf("\n\tGoing to create revise Color Part relation with non color------------>");fflush(stdout); //30/09/2019
								fprintf(fplog,"\n\tGoing to create revise Color Part relation with non color------------>");
								ifail = GRM_create_relation(Clrrev,NonClrRev,tRelationFind,NULLTAG,&Rel_task);
								ifail = GRM_save_relation(Rel_task);
								ifail = AOM_load(Rel_task);
								ifail = AOM_refresh(Rel_task,0);
								printf("\nRelation Created Successfully ..");fflush(stdout);	
								fprintf(fplog,"\n\tRelation Created Successfully ..");
							}
							
							printf ( "\n Global SchDataToGov is -------> %s",SchDataToGov);fflush(stdout);
							fprintf(fplog,"\n\tGlobal SchDataToGov is -------> %s",SchDataToGov);
							ifail = AOM_lock(ReviseClrPrtRev);
							ifail = AOM_set_value_string(ReviseClrPrtRev,"gov_classification",SchDataToGov);
							ifail = AOM_save_without_extensions(ReviseClrPrtRev);
							ifail = AOM_unlock(ReviseClrPrtRev);
						}

						//NEED TO DELETE STRUCTURE FOR REVISE PART
						if(Clrrev!=NULLTAG)
						{
							ifail = ITEM_rev_list_bom_view_revs(Clrrev,&bvrcnt, &bvr);
							printf("\n bvrcnt------->%d",bvrcnt);fflush(stdout);
							if (bvrcnt)
							{
								bvrTag = bvr[0];
								MEM_free(bvr);
							}

							if(bvrTag!=NULLTAG)
							{
								ifail = PS_list_occurrences_of_bvr(bvrTag, &Revoccs, &Revccsal);
								printf("\n Revoccs------->%d",Revoccs);fflush(stdout);

								printf("\n Going to Call PS_delete_occurrence for Revise Part------->"); fflush(stdout);
								fprintf(fplog,"\n\tGoing to Call PS_delete_occurrence for Revise Part------->");
								ifail = AOM_lock(bvrTag);
								for (zz = 0; zz<Revoccs; zz++)
								{
									ifail = PS_delete_occurrence(bvrTag, Revccsal[zz]);
								}
								ifail = AOM_save_without_extensions(bvrTag);
								ifail = AOM_unlock(bvrTag);
							}						
						}
					}	
				}
				else
					{
						printf("\t ---Clr Part not live on TCUA....");fflush(stdout);
					}
				}else
				{
					fprintf(fplog,"\n\t---No Need to Revise....\n");
					printf("\t ---No Need to Revise....");fflush(stdout);
				}
			}

			if(tc_strcmp(child_owning_group,"APLCAR")==0)
			{	
				//This need to be handle for Multiple plant as per APL Logic
				ifail=PS_find_view_type("T5_APLCView",&view_type_tag);
				ifail=PS_ask_view_type_name(view_type_tag,&bs_view_type_name);
				printf("\n bs_view_type_name %s ",bs_view_type_name);fflush(stdout);

				if(view_type_tag!=NULLTAG)
				{
					ifail =ITEM_list_bom_views(Clritem,&bv_clrcount, &clr_bvs);
					printf("\n bv_clrcnt :%d..",bv_clrcount);fflush(stdout);
					if (bv_clrcount)
					{
						clrbv = clr_bvs[0];
						MEM_free(clr_bvs);
					}else{
						ifail = PS_create_bom_view(view_type_tag, "", "", Clritem,&clrbv );
						ifail = AOM_save_without_extensions( clrbv );
						ifail = AOM_save_without_extensions( Clritem );
						ifail = AOM_unlock( Clritem );
						printf("\n inside PS_create_bom_view..");fflush(stdout);
					}
					if (Clrrev!=NULLTAG)
					{
						ifail = ITEM_rev_list_bom_view_revs(Clrrev,&clr_bvrcnt, &clrbvrs);
						printf("\n clr_bvrcnt :%d..",clr_bvrcnt);fflush(stdout);
						if (clr_bvrcnt)
						{
							clrbvr = clrbvrs[0];
							MEM_free(clrbvrs);
						}else{
							ifail = PS_create_bvr( clrbv, "", "", false, Clrrev,&clrbvr);
							if(clrbvr !=NULLTAG)
							{								
								ifail = AOM_save_without_extensions( clrbvr);
								ifail = AOM_save_without_extensions( Clrrev );
								ifail = AOM_unlock( Clrrev );
								printf("\n inside  PS_create_bvr..");fflush(stdout);
							}
						}
					} 
				}		
			}else
			{
				ifail =ITEM_list_bom_views(Clritem,&bv_clrcount, &clr_bvs);
				printf("\n bv_clrcnt :%d..",bv_clrcount);fflush(stdout);
				fprintf(fplog,"\n\t   bv_clrcnt :%d..",bv_clrcount);
				if (bv_clrcount)
				{
					clrbv = clr_bvs[0];
					MEM_free(clr_bvs);
				}else{
					ifail = PS_create_bom_view( NULLTAG, "", "", Clritem,&clrbv );
					ifail = AOM_save_without_extensions( clrbv );
					ifail = AOM_save_without_extensions( Clritem );
					ifail = AOM_unlock( Clritem );
					printf("\n inside PS_create_bom_view..");fflush(stdout);
					fprintf(fplog,"\n\t  inside PS_create_bom_view..");
				}

				if (Clrrev!=NULLTAG)
				{
					ifail = ITEM_rev_list_bom_view_revs(Clrrev,&clr_bvrcnt, &clrbvrs);
					printf("\n clr_bvrcnt :%d..",clr_bvrcnt);fflush(stdout);
					fprintf(fplog,"\n\t clr_bvrcnt :%d..",clr_bvrcnt);
					if (clr_bvrcnt)
					{
						clrbvr = clrbvrs[0];
						MEM_free(clrbvrs);
					}else{
						ifail = PS_create_bvr( clrbv, "", "", false, Clrrev,&clrbvr);
						if(clrbvr !=NULLTAG)
						{								
							ifail = AOM_save_without_extensions( clrbvr);
							ifail = AOM_save_without_extensions( Clrrev );
							ifail = AOM_unlock( Clrrev );
							printf("\n inside  PS_create_bvr..");fflush(stdout);
							fprintf(fplog,"\n\t nside  PS_create_bvr..");
						}
					}
				}
			}
		}
		
		ifail = AOM_ask_value_string(NonClrRev, "item_id", &t5NonCPrt);
		printf("\n t5NonCPrt for Part is --> : %s",t5NonCPrt); fflush(stdout);
		fprintf(fplog,"\n\t  t5NonCPrt for Part is --> : %s",t5NonCPrt);

		ifail = AOM_ask_value_string(NonClrRev, "item_revision_id", &t5item_revision_id);
		printf("\n t5item_revision_id for Part is --> : %s",t5item_revision_id); fflush(stdout);
		fprintf(fplog,"\n\t t5item_revision_id for Part is --> : %s",t5item_revision_id);

		if(NonClrRev !=NULLTAG)
		{
			ifail = BOM_create_window(&window);
			//ifail = CFM_find("APLC Release and above", &rule); //APLC Release and above //comented by GR 06/02/23
			ifail = CFM_find("ERC release and above", &rule); //APLC Release and above & ERC release and above
			ifail = BOM_set_window_config_rule(window, rule);
			//PIE_find_closure_rules("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule);
			PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule);
			if (rulefound > 0)
				{
					close_tag = closurerule[0];
					printf ("closure rule found \n");fflush(stdout);
				}
			BOM_window_set_closure_rule(window,close_tag, 0, rulename,rulevalue);

			ifail = BOM_set_window_pack_all(window, TRUE);
			ifail = BOM_set_window_top_line(window , NULLTAG, NonClrRev, NULLTAG, &top_line);
			ifail = BOM_window_show_suppressed (window);

			if(top_line!=NULLTAG)
			{
				ifail = BOM_line_ask_child_lines(top_line, &n_count, &Nlines);
				printf("\n n_lines-----> %d",n_count);fflush(stdout);
				fprintf(fplog,"\n\t  n_lines-----> %d",n_count);
							
				if (n_count >0)
				{
					for (p1=0;p1<n_count ;p1++ )
					{	
						int flagNonClr=0;
						ChildOccClr=0;
						if(Childobject) Childobject=NULLTAG;
						Childobject=Nlines[p1];
						ifail = AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id);					
						ifail = AOM_ask_value_string(Childobject, "bl_Design Revision_t5_ColourInd", &ChildColInd);
						ifail = AOM_ask_value_string(Childobject, "bl_rev_item_revision_id", &Mitem_Rev_Seq);
						printf("\n\n child_item_id/Mitem_Rev_Seq & ChildColInd-------> %s/%s=>[%s]",child_item_id,Mitem_Rev_Seq,ChildColInd); fflush(stdout);
						fprintf(fplog,"\n\t child_item_id/Mitem_Rev_Seq & ChildColInd-------> %s/%s=>[%s]",child_item_id,Mitem_Rev_Seq,ChildColInd);
						//if(strcmp(child_item_id,"5465T2B0188003")==0 ||strcmp(child_item_id,"546588600108")==0 ||strcmp(child_item_id,"546588600111")==0)
						{
						ifail = AOM_UIF_ask_value(Childobject, "bl_occ_t5_CarOptionalCS", &CarOptionalCS);
						ifail = AOM_UIF_ask_value(Childobject, "bl_occ_t5_DwdOptionalCS", &DwdOptionalCS);
						ifail = AOM_UIF_ask_value(Childobject, "bl_occ_t5_PunOptionalCS", &PunOptionalCS);
						ifail = AOM_UIF_ask_value(Childobject, "bl_occ_t5_PunUVOptionalCS", &PunUVOptionalCS);
						ifail = AOM_UIF_ask_value(Childobject, "bl_occ_t5_JsrOptionalCS", &JsrOptionalCS);
						ifail = AOM_UIF_ask_value(Childobject, "bl_occ_t5_LkoOptionalCS", &LkoOptionalCS);
						ifail = AOM_UIF_ask_value(Childobject, "bl_occ_t5_PnrOptionalCS", &PnrOptionalCS);
						ifail = AOM_UIF_ask_value(Childobject, "bl_occ_t5_JdlOptionalCS", &JdlOptionalCS);
						ifail = AOM_UIF_ask_value(Childobject, "bl_occ_t5_AhdOptionalCS", &AhdOptionalCS);

						ifail = AOM_UIF_ask_value(Childobject, "bl_occ_t5_CurrentViewMaskC", &CurrentViewMaskC);
						printf("\n child_item_id & its CurrentViewMaskC is==> %s==%s",child_item_id,CurrentViewMaskC);
						fprintf(fplog,"\n\t child_item_id & its CurrentViewMaskC is==> %s==%s",child_item_id,CurrentViewMaskC);

						//ifail = BOM_line_ask_attribute_string(Childobject,QuantityAttrId, &Quantity3);
						ifail = AOM_UIF_ask_value(Childobject, "bl_quantity", &Quantity3);
						NClrQty3=atoi(Quantity3);
						printf("\n NClrQty3 is--> : %d",NClrQty3); fflush(stdout);
						fprintf(fplog,"\n\t  NClrQty3 is--> : %d",NClrQty3);

						if (child_item_id && Mitem_Rev_Seq)
						{
							ITK_CALL(ITEM_find_item(child_item_id,&itemtag1));
							ifail = ITEM_find_revisions(itemtag1,Mitem_Rev_Seq,&n_rev,&rev1);
							printf("\n n_rev: %d ", n_rev); fflush(stdout);

							if(n_rev > 0)
							{							
								NonClrChildRev=NULLTAG;
								NonClrChildRev=rev1[0];
							}
						}					

						if(tc_strcmp(ChildColInd,"N")==0)
						{
							printf("\n child_item_id & its CurrentViewMaskC is----------> %s=%s",child_item_id,CurrentViewMaskC);
							fprintf(fplog,"\n\t child_item_id & its CurrentViewMaskC is----------> %s=%s",child_item_id,CurrentViewMaskC);
								//add here to check the latest release and attached to dml or not   rev tag Clrrev //Nilesh Patil
									
								int CLAttchStat;
								CLAttchStat = CheckRefRelation(Clrrev);
								printf("\nTCLAttchStat [%d]",CLAttchStat);  fflush(stdout);
								if (CLAttchStat==1)
								{
									printf("\nColour part has been attached to CL task hence skipping ");  fflush(stdout);
									fprintf(fplog,"\n\t Colour part has been attached to CL task hence skipping ");

								}
								else
								{
									printf("\nColour part is not attached to CL task ");  fflush(stdout);
									ifail = NonClrOccursetToClrBvr(clrbvr,NonClrChildRev,NClrQty3,top_line);

								}
							
							ifail = CurrentViewMaskCClrtag(Clrrev,NonClrChildRev,NClrQty3,CurrentViewMaskC);
							ifail = BOM_set_window_pack_all(window, true);
						}else if(tc_strcmp(ChildColInd,"Y")==0)
						{
							printf("\n Color Indicator for Non-Color is------------------------>%s",ChildColInd); fflush(stdout);
							fprintf(fplog,"\n\t Color Indicator for Non-Color is------------------------>%s",ChildColInd);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_PrtCatCode", &t5PrtCatCd);
							ifail = AOM_ask_value_string(NonClrChildRev, "item_id", &t5itemid);
							ifail = AOM_ask_value_string(NonClrChildRev, "current_revision_id", &t5revision_id);
							ifail = AOM_ask_value_string(NonClrChildRev, "object_desc", &t5object_desc);						
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_ColourInd", &t5_ColourInd);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_PartStatus", &t5_PartStatus);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_DesignGrp", &t5_DesignGrp);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_ProjectCode", &t5_ProjectCode);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_DocRemarks", &t5_DocRemarks);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_DrawingInd", &t5_DrawingInd);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_PartType", &t5_PartType);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_PartCode", &t5_PartCode);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_AhdMakeBuyIndicator", &t5_AhdMakeBuyIndicator);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_PunPCBUMakeBuyIndicator", &t5_PunPCBUMakeBuyIndicator);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_PunMakeBuyIndicator", &t5_PunMakeBuyIndicator);
							ifail = AOM_ask_value_string(NonClrChildRev, "t5_DwdMakeBuyIndicator", &t5_DwdMakeBuyIndicator);

							itemUOM = NULL;
							itemUOM=(char *) MEM_alloc(50);
							ifail = ITEM_find_item(t5itemid,&ItemTag1);
							ifail = ITEM_ask_unit_of_measure(ItemTag1, &UOM_Tag);
							tc_strcpy(itemUOM,"");

							if(UOM_Tag==NULLTAG)
							{
								tc_strcat(itemUOM,"4");								
							}else
							{
								ifail = UOM_ask_symbol(UOM_Tag, &UnitOfMeasureS);
								if(tc_strcmp(UnitOfMeasureS,"each")==0 || tc_strcmp(UnitOfMeasureS,"")==0)
								{
									tc_strcat(itemUOM,"4");
								}else
								{
									itemUOM=subString(UnitOfMeasureS, 0, 1);
								}
							}
							printf("\n final UOM Values from MULTILEVEL FUNCTION--> : %s",itemUOM); fflush(stdout);
							fprintf(fplog,"\n\tfinal UOM Values from MULTILEVEL FUNCTION--> : %s\n",itemUOM);
							
							if (SchmWithCmpcdRelMultlvl != NULLTAG)
							{
								ifail = GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRelMultlvl, &Cmpcount, &CmpCodeOfClrScheme);
								printf("\n\t\t MultilevelExpantion Comp Code count from Color Scheme is : %d\n",Cmpcount); fflush(stdout);
								fprintf(fplog,"\n\t MultilevelExpantion Comp Code count from Color Scheme is : %d\n",Cmpcount);

								if(Cmpcount > 0)
								{
									for (k1=0;k1<Cmpcount ;k1++ )
									{
										if(CmpCodeObj) CmpCodeObj=NULLTAG;
										CmpCodeObj=CmpCodeOfClrScheme[k1];
										ifail = AOM_ask_value_string(CmpCodeObj, "t5_PrtCatCode", &CmpCodeCmp );

										if(tc_strcmp(t5PrtCatCd,CmpCodeCmp)==0)
										{
											printf("\n CmpCodeCmp & t5PrtCatCd status--> : %s-%s",CmpCodeCmp,t5PrtCatCd); fflush(stdout);
											flagNonClr=1;
											ClrGrpPartPresentFlag=0;
											ifail = AOM_ask_value_string(CmpCodeObj, "t5_ClSrl", &t5ClSrl );
											Suffix =  strtok(t5ClSrl,";");
											ColourID  =  strtok(NULL,";");
											printf("\n t5itemid --> : %s",t5itemid); fflush(stdout);
											printf("\n t5ClSrl --> : %s",t5ClSrl); fflush(stdout);
											printf("\n Suffix --> : %s",Suffix); fflush(stdout);
											printf("\n ColourID --> : %s",ColourID); fflush(stdout);
											printf("\n t5_PartType --> : %s",t5_PartType); fflush(stdout);

											if(tc_strcmp(t5_PartType,"G")==0)
											{
												ifail = GRM_find_relation_type("TC_Is_Represented_By",&gRelationFind);
												if(gRelationFind!=NULLTAG)
												{
													ifail = GRM_list_primary_objects_only(NonClrChildRev,gRelationFind,&g_attchs,&secondary_gobjects);
													printf("\n\n\t\t No of DI : %d",g_attchs);fflush(stdout);

													if(g_attchs>0)
													{		
														//Need To Check Group ID logic as per priviosly created color GROUP ID
														for (k3=0;k3<g_attchs ;k3++ )
														{
															if(ColorID_G) ColorID_G=NULLTAG;
															ColorID_G=secondary_gobjects[k3];

															ifail = AOM_ask_value_string(ColorID_G,"t5_ColourID",&g_ColourID);
															printf("\n\n\t\t g_ColourID is :%s",g_ColourID);fflush(stdout);
															printf("\n ColourID from Scheme & from Color GroupID --> : %s = ",ColourID,g_ColourID); fflush(stdout);
															fprintf(fplog,"\n\t ColourID from Scheme & from Color GroupID --> : %s = ",ColourID,g_ColourID);
															
															if(tc_strcmp(ColourID,g_ColourID)==0)
															{
																ifail = AOM_ask_value_string(ColorID_G,"item_id",&Object_id);
																printf("\n\n\t\t Object_id is :%s",Object_id);fflush(stdout);
																ClrGrpPartPresentFlag=1;														
															}else {
																printf("\n\n\t\t g_ColourID is :%s",g_ColourID);fflush(stdout);
															}
														}													
														
														printf("\n Going to Check Color Part in DB============================> %s",Object_id);fflush(stdout);
														n_tags_found2=0;
														if(Object_id!=NULL)
														{
															if(QRY_find2("ClrPart", &ClrPartTag));
															if (ClrPartTag) { printf("\nFound Query ClrPartTag MultilevelExpantion "); fflush(stdout); 
															}else { printf("\nNot Found Query ClrPartTag"); fflush(stdout); }
															valuesClrPrt[0] = Object_id;
															if(QRY_execute(ClrPartTag, n_entriesC, qry_entries, valuesClrPrt, &n_tags_found2, &tags_found2));
															printf("\n\n\n ClrPart count is MultilevelExpantion -------->  : %d",n_tags_found2);fflush(stdout);
														}

														if(n_tags_found2 > 0)
														{		
																ClrGrpPartPresentFlag=1;
																ItemTag2 = tags_found2[0];
																itemRevSeq=Object_id;
																printf("\n Group ID Color Part status in DB============================> %s",itemRevSeq);fflush(stdout);

																//Add already exiting Group ID to Color BOM

																ifail = OccurSetTopLineClr(clrbvr,itemRevSeq ,NClrQty3,top_line,ColRlzRevFlag);
																ifail = BOM_set_window_pack_all(window, true);
														}													
													}

													/////////////////////////////NewUniqGroupIDNum/////////////////////////////////////////////
													printf("\n  ClrGrpPartPresentFlag-------------------------------------->%d",ClrGrpPartPresentFlag); fflush(stdout);
													if(ClrGrpPartPresentFlag==0)
													{
														printf("\n  before NewUniqGroupIDNum\n"); fflush(stdout);
														ResponseStr = NewUniqGroupIDNum();
														printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
														itemRevSeq = NULL;
														itemRevSeq=(char *) MEM_alloc(32);														
														strcpy(itemRevSeq,"");
														strcat(itemRevSeq,ResponseStr);
														printf("\n Colour Part for Group ID---->%s = %s\n",itemRevSeq,ClrRevSeq);
													}
												}
											}else
											{
												tag_t ClrId_tag =NULLTAG;
												tag_t ClrIdRev_tag =NULLTAG;
												char* sClrItem_id=NULL;
												char* sClrItemRev_id=NULL;
												itemRevSeq = NULL;
												itemRevSeq=(char *) MEM_alloc(32);														
												strcpy(itemRevSeq,"");
												strcat(itemRevSeq,t5itemid);
												strcat(itemRevSeq,Suffix);														
												printf("\n Colour Part for Creation MultilevelExpantion ---->%s ",itemRevSeq);
												fprintf(fplog,"\n\t Colour Part for Creation MultilevelExpantion ---->%s",itemRevSeq);
												ITK_CALL(ITEM_find_item(itemRevSeq, &ClrId_tag));
                                                 printf("\n Colour Part for Creation MultilevelExpantion ----> 2222");
												if (ClrId_tag!=NULLTAG)
												{
													ifail = ITEM_ask_latest_rev(ClrId_tag,&ClrIdRev_tag);
													ifail = AOM_ask_value_string(ClrIdRev_tag, "item_id", &sClrItem_id);
													ifail = AOM_ask_value_string(ClrIdRev_tag, "item_revision_id", &sClrItemRev_id);
													 fprintf(fplog,"\n New  Clr item_id =%s &item_revision_id  :%s\n",sClrItem_id,sClrItemRev_id);
													 printf("\n New  Clr item_id =%s &item_revision_id  :%s\n",sClrItem_id,sClrItemRev_id);

												}

										       printf("\n Colour Part for Creation MultilevelExpantion ---->New  ");
												if(clrbvr!=NULLTAG)
												{
													ifail = PS_list_occurrences_of_bvr(clrbvr, &noccs, &noccsal);
													printf("\n Hanuman-----Clrrev_id: %s---no:of:occurances are --->%d",Clrrev_id,noccs); fflush(stdout);
													
													if(noccs > 0)
													{
														 ifail = AOM_lock(clrbvr);
														 for (iz = 0; iz<noccs; iz++)
														 {
															 ifail = PS_ask_occurrence_child(clrbvr,noccsal[iz], &nChildItem, &nbvrchild);
															 ifail = AOM_ask_value_string(nChildItem, "item_id", &nocc_item_id);

															 if((tc_strstr(nocc_item_id,child_item_id)!=NULL) && (tc_strstr(itemRevSeq,child_item_id)!=NULL)) //Non-Color Compared with Exiting Color ZZ with Same/ZS New Color Part
															 {
																 printf("\n nocc_item_id & child_item_id  :%s=%s New Color is : %s\n",nocc_item_id,child_item_id,itemRevSeq);fflush(stdout);
																 fprintf(fplog,"\nnocc_item_id & child_item_id  :%s=%s New Color is : %s\n",nocc_item_id,child_item_id,itemRevSeq);

																 ifail = PS_ask_occurrence_qty(clrbvr,noccsal[iz], &qty);
																 printf("\n InExpansion PS_ask_occurrence_qty --->%g",qty); fflush(stdout);

																 if(tc_strcmp(nocc_item_id,itemRevSeq)!=0)
																 {
																	 ifail = PS_delete_occurrence(clrbvr, noccsal[iz]);
																	 printf("\n non-color where Color Indicator Y has been removed--->%s",child_item_id); fflush(stdout);
																	 fprintf(fplog,"\nnon-color where Color Indicator Y has been removed--->%s",child_item_id);
																 }else
																 {
																	 printf("\n BOMLine Color Childs Match found  ==> %s=%s\n",nocc_item_id,itemRevSeq);fflush(stdout);
																	 fprintf(fplog,"\n BOMLine Color Childs Match found  ==> %s=%s\n",nocc_item_id,itemRevSeq);
																 }
															 }
														 }
														 ifail = AOM_save_without_extensions( clrbvr );
														 ifail = AOM_unlock( clrbvr );
													}
												}
											}

											printf("\n Going to Check Color Part in DB============================> %s\n",itemRevSeq);fflush(stdout);
											fprintf(fplog,"\n  Going to Check Color Part in DB============================> %s\n",itemRevSeq);
											n_tags_found2=0;
											if(itemRevSeq!=NULL)
											{
												if(QRY_find2("ClrPart", &ClrPartTag));
												if (ClrPartTag) { printf("\nFound Query ClrPartTag MultilevelExpantion "); fflush(stdout); 
												fprintf(fplog,"\n Found Query ClrPartTag MultilevelExpantion ");
												}else { printf("\nNot Found Query ClrPartTag"); fflush(stdout); }
												valuesClrPrt[0] = itemRevSeq;
												if(QRY_execute(ClrPartTag, n_entriesC, qry_entries, valuesClrPrt, &n_tags_found2, &tags_found2));
												printf("\n\n\n ClrPart count is MultilevelExpantion -------->  : %d",n_tags_found2);fflush(stdout);
												fprintf(fplog,"\n ClrPart count is MultilevelExpantion -------->  : %d",n_tags_found2);
											}

											if(n_tags_found2 > 0)
											{
												ItemTag2 = tags_found2[0];
                                                  tag_t sClrrev=NULLTAG;
												  char *sClrrev_id=NULL;
												  char *sClrrevision_id=NULL;
												  char *sClrPartType=NULL;
												ifail = ITEM_ask_latest_rev(ItemTag2,&sClrrev);
												ifail = AOM_ask_value_string(sClrrev, "item_id", &sClrrev_id);
												ifail = AOM_ask_value_string(sClrrev, "item_revision_id", &sClrrevision_id);
												ifail = AOM_ask_value_string(sClrrev, "t5_PartType", &sClrPartType);

                                                fprintf(fplog,"\n Clr item_id =%s &item_revision_id  :%s=%s\n",sClrrev_id,sClrrevision_id,sClrPartType);
												ifail = PS_list_occurrences_of_bvr(clrbvr, &n_occs, &occsal);
												printf("\n InMain  no:of:occurances are --->%d",n_occs); fflush(stdout);
												fprintf(fplog,"\n InMain  no:of:occurances are --->%d",n_occs);
												ClrGrpPartPresentFlag=1;

												if(n_occs > 0)
												{
													 for (iy = 0; iy<n_occs; iy++)
													 {
														 ifail = PS_ask_occurrence_child(clrbvr,occsal[iy], &ChildItem, &bvrchild);
														 ifail = AOM_ask_value_string(ChildItem, "item_id", &occ_item_id);
														 printf("\n occ_item_id & PartNumber is  :%s=%s\n",occ_item_id,itemRevSeq);fflush(stdout);
														 fprintf(fplog,"\nocc_item_id & PartNumber is  :%s=%s\n",occ_item_id,itemRevSeq);
														 if(tc_strcmp(occ_item_id,itemRevSeq)==0)
														 {
															ChildOccClr=1;
															break;
														 }
													 }												
												}
												
												if(ChildOccClr==0)
												{
													//add here to check the latest release and attached to dml or not   rev tag Clrrev //Nilesh Patil	
													int CLAttchStat;
													CLAttchStat = CheckRefRelation(Clrrev);
													printf("\nTCLAttchStat [%d]",CLAttchStat);  fflush(stdout);
													if (CLAttchStat==1)
													{
														printf("\nColour part has been attached to CL task hence skipping ");  fflush(stdout);
														fprintf(fplog,"\n Colour part has been attached to CL task hence skipping");

													}
													else
													{
														printf("\n Colour part is not attached to CL task ");  fflush(stdout);
														fprintf(fplog,"\n Colour part is not attached to CL task");
														ifail = OccurSetTopLineClr(clrbvr,itemRevSeq ,NClrQty3,top_line,ColRlzRevFlag);

													}
													
													ifail = BOM_set_window_pack_all(window, true);

													if(tc_strcmp(t5_PartType,"M")==0)
													{
														printf("\n Clr--Before CurrentViewMask ...");fflush(stdout);
														fprintf(fplog,"\nClr--Before CurrentViewMask ...");
														ifail = CurrentViewMaskCClrtag(Clrrev,NonClrChildRev,NClrQty3,CurrentViewMaskC);
													}
												}
											
												if(ItemTag2!=NULLTAG)
												{
													printf("\n A--flg2=MultilevelExpantion Color Part in DB-------------->\n");fflush(stdout);
													fprintf(fplog,"\nA--flg2=MultilevelExpantion Color Part in DB-------------->\n");
													flg2=0;
													flg2=MultilevelExpantion(ItemTag2,NonClrChildRev,ColSchmRevTag,NonClrPartlevel,taskRevTag,user_tag,group);
													printf("\n A--flg2=> [%d]",flg2);fflush(stdout);
													if (flg2==-1)
													{
														return flg2;
													}
												}
											}

											/////////////////////////////WebSerFunForClrPart/////////////////////////////////////////////
											printf("\n ClrGrpPartPresentFlag---------->%d",ClrGrpPartPresentFlag); fflush(stdout);
											fprintf(fplog,"\n ClrGrpPartPresentFlag---------->%d",ClrGrpPartPresentFlag);
											if(ClrGrpPartPresentFlag==0)
											{	
												printf("\n Color Part is Checking in TCE---------->%s",itemRevSeq); fflush(stdout);
												fprintf(fplog,"\n Color Part is Checking in TCE---------->%s",itemRevSeq);
												Response = WebSerFunForClrPart(itemRevSeq);
												printf("Color Part checking in TCE :: [%s]",Response);fflush(stdout);

												if(tc_strcmp(Response,"NA")==0)  
												{											
													ifail = ITEM_create_item(itemRevSeq,itemRevSeq,"T5_ClrPart",default_empty_to_A(ClrRevSeq),&ChildClrItem,&ChildClrRev);
													setAttributesOnDesign(&ChildClrItem,itemRevSeq,t5object_desc,itemUOM);					
													setAttributesOnDesignRev(&ChildClrRev,itemRevSeq,item_revision_id_int,t5object_desc,t5_ColourInd,t5PrtCatCd,ColourID,t5CoatedS,t5_PartStatus,t5_DesignGrp,t5_ProjectCode,t5_DocRemarks,t5_DrawingInd,t5_PartType,t5_PartCode,t5_AhdMakeBuyIndicator,t5_PunPCBUMakeBuyIndicator,t5_PunMakeBuyIndicator,t5_DwdMakeBuyIndicator,child_item_id);
												
													//Going to update UserOwner Name
													ifail = AOM_set_ownership(ChildClrRev,user_tag ,group);
													printf("\n  AOM_set_ownership...!!");fflush(stdout);

													ifail = CreateReleasestatus(ChildClrRev);
													ifail = AssignProject(ChildClrRev,t5_ProjectCode);												
													if (taskRevTag!=NULLTAG)
													{
														ifail = GRM_find_relation_type("CMHasSolutionItem",&RelSolutionItem);
														if(RelSolutionItem!=NULLTAG)
														{	
															ifail = GRM_create_relation(taskRevTag,ChildClrRev,RelSolutionItem,NULLTAG,&reltask);
															ifail = GRM_save_relation(reltask); 
															ifail = AOM_refresh(reltask,0);
															printf("\nRelation Created Successfully MultilevelExpantion");fflush(stdout);	
															fprintf(fplog,"Relation Created Successfully MultilevelExpantion");
														}
													}

													ifail = GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind);
													if (tRelationFind!=NULLTAG)
													{													
														ifail = GRM_create_relation(ChildClrRev,NonClrChildRev,tRelationFind,NULLTAG,&Rel_task);
														ifail = GRM_save_relation(Rel_task); 
														ifail = AOM_load(Rel_task);
														ifail = OccurSetTopLineToClr(clrbvr,itemRevSeq, NClrQty3);													
													}
													
													 //Uncommented below two lines for handling body_shell current view mask stamping by RRR on 24.08.2021
													printf("\n Y--Calling function CurrentViewMaskCClrtag------>%s",CurrentViewMaskC);fflush(stdout);	
													ifail = CurrentViewMaskCClrtag(Clrrev,NonClrChildRev,NClrQty3,CurrentViewMaskC);
													
													//CS UPDATED IN COLOR PARTS AS PER NON-COLOR IN BOM GENERATION PROCESS													
													if(CarOptionalCS!=NULL)
													{
														OptionalCSAttr = NULL;
														OptionalCSAttr=(char *) MEM_alloc(50);
														tc_strcpy(OptionalCSAttr,"bl_occ_t5_CarOptionalCS");
														printf("\n CarOptionalCS--------->%s",OptionalCSAttr);
														ifail = CarOptionalCSSet(ChildClrRev, CarOptionalCS,OptionalCSAttr);
														printf("\n CarOptionalCS on T5_ClrPartsRevision--------->%d",ifail);
													}

													if(DwdOptionalCS!=NULL)
													{
														OptionalCSAttr = NULL;
														OptionalCSAttr=(char *) MEM_alloc(50);
														tc_strcpy(OptionalCSAttr,"bl_occ_t5_DwdOptionalCS");
														printf("\n DwdOptionalCS--------->%s",OptionalCSAttr);
														ifail = CarOptionalCSSet(ChildClrRev, DwdOptionalCS,OptionalCSAttr);
														printf("\n DwdOptionalCS on T5_ClrPartsRevision--------->%d",ifail);
													}

													if(PunOptionalCS!=NULL)
													{
														OptionalCSAttr = NULL;
														OptionalCSAttr=(char *) MEM_alloc(50);
														tc_strcpy(OptionalCSAttr,"bl_occ_t5_PunOptionalCS");
														printf("\n PunOptionalCS--------->%s",OptionalCSAttr);
														ifail = CarOptionalCSSet(ChildClrRev, PunOptionalCS,OptionalCSAttr);
														printf("\n PunOptionalCS on T5_ClrPartsRevision--------->%d",ifail);
													}

													if(PunUVOptionalCS!=NULL)
													{
														OptionalCSAttr = NULL;
														OptionalCSAttr=(char *) MEM_alloc(50);
														tc_strcpy(OptionalCSAttr,"bl_occ_t5_PunUVOptionalCS");
														printf("\n PunUVOptionalCS--------->%s",OptionalCSAttr);
														ifail = CarOptionalCSSet(ChildClrRev, PunUVOptionalCS,OptionalCSAttr);
														printf("\n PunUVOptionalCS on T5_ClrPartsRevision--------->%d",ifail);
													}

													if(JsrOptionalCS!=NULL)
													{
														OptionalCSAttr = NULL;
														OptionalCSAttr=(char *) MEM_alloc(50);
														tc_strcpy(OptionalCSAttr,"bl_occ_t5_JsrOptionalCS");
														printf("\n JsrOptionalCS--------->%s",OptionalCSAttr);
														ifail = CarOptionalCSSet(ChildClrRev, JsrOptionalCS,OptionalCSAttr);
														printf("\n JsrOptionalCS on T5_ClrPartsRevision--------->%d",ifail);
													}

													if(LkoOptionalCS!=NULL)
													{
														OptionalCSAttr = NULL;
														OptionalCSAttr=(char *) MEM_alloc(50);
														tc_strcpy(OptionalCSAttr,"bl_occ_t5_LkoOptionalCS");
														printf("\n LkoOptionalCS--------->%s",OptionalCSAttr);
														ifail = CarOptionalCSSet(ChildClrRev, LkoOptionalCS,OptionalCSAttr);
														printf("\n LkoOptionalCS on T5_ClrPartsRevision--------->%d",ifail);
													}

													if(PnrOptionalCS!=NULL)
													{
														OptionalCSAttr = NULL;
														OptionalCSAttr=(char *) MEM_alloc(50);
														tc_strcpy(OptionalCSAttr,"bl_occ_t5_PnrOptionalCS");
														printf("\n PnrOptionalCS--------->%s",OptionalCSAttr);
														ifail = CarOptionalCSSet(ChildClrRev, PnrOptionalCS,OptionalCSAttr);
														printf("\n PnrOptionalCS on T5_ClrPartsRevision--------->%d",ifail);
													}

													if(JdlOptionalCS!=NULL)
													{
														OptionalCSAttr = NULL;
														OptionalCSAttr=(char *) MEM_alloc(50);
														tc_strcpy(OptionalCSAttr,"bl_occ_t5_JdlOptionalCS");
														printf("\n JdlOptionalCS--------->%s",OptionalCSAttr);
														ifail = CarOptionalCSSet(ChildClrRev, JdlOptionalCS,OptionalCSAttr);
														printf("\n JdlOptionalCS on T5_ClrPartsRevision--------->%d",ifail);
													}

													if(AhdOptionalCS!=NULL)
													{
														OptionalCSAttr = NULL;
														OptionalCSAttr=(char *) MEM_alloc(50);
														tc_strcpy(OptionalCSAttr,"bl_occ_t5_AhdOptionalCS");
														printf("\n AhdOptionalCS--------->%s",OptionalCSAttr);
														ifail = CarOptionalCSSet(ChildClrRev, AhdOptionalCS,OptionalCSAttr);
														printf("\n AhdOptionalCS on T5_ClrPartsRevision--------->%d",ifail);
													}
											  }else
											  {
												 // fprintf(output,"%s\n",itemRevSeq);
												  return -1;
											  }										 
										  }
											
										  if(ChildClrItem!=NULLTAG)    //GR
										  {
											printf("\n B--flg2=MultilevelExpantion Color Part in DB-------------->\n");fflush(stdout);
											fprintf(fplog,"\n\tB--flg2=MultilevelExpantion Color Part in DB-------------->\n");
											flg2=0;
											flg2=MultilevelExpantion(ChildClrItem,NonClrChildRev,ColSchmRevTag,NonClrPartlevel,taskRevTag,user_tag,group);
											printf("\n B--flg2=> [%d]",flg2);fflush(stdout);
											fprintf(fplog,"\n B--flg2=> [%d]",flg2);
											if(flg2==-1)
											{
												return flg2;
											}
										  }
										  }
										}
									}
								}
								
								printf("\n\n\n flagNonClr-------->  : %d",flagNonClr);fflush(stdout);
								if(flagNonClr==0)
								{
									ifail = NonClrOccursetToClrBvr(clrbvr,NonClrChildRev,NClrQty3,top_line);
									printf("\n If Comp code for non-color is not matched in Scheme then add as it is to BOMLine..........>");fflush(stdout);
								}else {
									printf("\n\n\n flagNonClr else loop-------->");fflush(stdout);
								}
							}else
							printf("\n Color Indicator for Non-Color is other than N/Y-------------->%s",ChildColInd); fflush(stdout);
							fprintf(fplog,"Color Indicator for Non-Color is other than N/Y-------------->%s",ChildColInd);
							
					}   //TBD
						}
					}
				}
			}
		return 0;
	}
	int createDataset(FILE* fp)
	{
				int status;
				 fclose(fp);
				 printf ("\n================================================\n");
				tag_t		msWordType				= NULLTAG;
				tag_t		wordDataset				= NULLTAG;
				tag_t		dataset_tag				= NULLTAG;
				tag_t		wordLatestDat_t			= NULLTAG;
				tag_t		qryTag					= NULLTAG;
				tag_t		*CntrolObjectTag		= NULLTAG;
				char				*DataSetName		= NULL;
				char				*qry_entry[1]		= {"Name"};
				char				**qry_values2		= (char **) MEM_alloc(10 * sizeof(char *));
				int					n_entry				= 1;
				int					rsltCount			= 0;
				char				* DataSet_Id		= NULL;	
					

					ITK_CALL(AE_find_datasettype2("Text",&msWordType));
					printf ("\n Platfrom : %s  And DMLno: %s: SVR_Rev: %s  ",Platform,DMLNo,SVRrule);
					DataSetName=(char *) MEM_alloc(100 * sizeof(char ));
					tc_strcpy(DataSetName,"");
					tc_strcat(DataSetName,Platform);
					tc_strcat(DataSetName,"_");
					tc_strcat(DataSetName,DMLNo);
					tc_strcat(DataSetName,"_");
					tc_strcat(DataSetName,SVRruleIP);
					tc_strcat(DataSetName,"_ClrUnitBOMError");

					printf ("\n Dataset Name is .....%s \n",DataSetName);
					ITK_CALL(AE_find_dataset2(DataSetName,&dataset_tag));       
					printf ("\n Dataset Name is ....3.%s \n",DataSetName);
					if (dataset_tag !=NULLTAG)
					{                 
					   if(AOM_ask_value_string(dataset_tag, "object_name", &DataSet_Id)!=ITK_ok);
					   if (tc_strcmp(DataSet_Id,DataSetName)==0)
					   {
						   ITK_CALL(AE_delete_all_dataset_revs(dataset_tag));	
							printf ("\n Dataset is  Deleted : ");
					   }
					   else
						{
						   printf ("\n Dataset not present in TC Need to create%s \n",DataSetName);
						}
					   
					}
					else
					{
					  printf ("\n Dataset not present \n");
					}
					printf ("\n Dataset Name is .....1111%s=%s \n",DataSetName,FileOp);
					ITK_CALL(AE_create_dataset_with_id(msWordType,DataSetName,"ClrUnitBOMError","","",&wordDataset));		
					ITK_CALL(AE_save_myself(wordDataset));
					ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
					ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
					ITK_CALL(AE_import_named_ref(wordLatestDat_t,"Text",FileOp,NULL,SS_TEXT));
					AOM_save_without_extensions(wordLatestDat_t);
					AOM_refresh(wordLatestDat_t, FALSE);
					AOM_unload(wordLatestDat_t);
					printf ("\n ClrUnitBOMError Dataset Create Suggessfully \n");


					if(QRY_find2("folder custom", &qryTag));
					if (qryTag)
					{
						qry_values2[0] = "ClrUnitBOMErr";
						if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrolObjectTag));
						printf("\n\t  Folder Count :%d: \n", rsltCount); fflush(stdout);
						if(rsltCount > 0)
						{

							if(AOM_lock(CntrolObjectTag[0]))PrintErrorStack();
							FL_insert(CntrolObjectTag[0],wordLatestDat_t,999);						
							if(AOM_save_without_extensions(CntrolObjectTag[0]))PrintErrorStack();
							if(AOM_unlock(CntrolObjectTag[0]));PrintErrorStack();
							if(AOM_refresh(CntrolObjectTag[0],1))PrintErrorStack();
							printf(  "\n\t ClrUnitBOMErr  \n"); fflush(stdout);
						}
					}
		
		return 0;
	}
	extern int ITK_user_main (int argc, char ** argv )
	{
		int ifail;
		int status;
		int h=0;
		int org_seq_id_int = 0;
		int currseq=0;
		int kk=0;
		int numBVRs = 0;
		int ii=0;
		Platform = NULL;
		char *ColPlatform = NULL;
		char *platformRev = NULL;
		char *platformSeq = NULL;
			 SVRrule = NULL;
			 SVRruleIP = NULL;
		
		char *ColSVRCotxt = NULL;
		char *expansionLvl = NULL;
		char *context = NULL;
		char* username = NULL;
		char* inputfile=NULL;
		char* child_item_id=NULL;
		char* ChildId=NULL;
		char* ChildColInd=NULL;
		char* Col_child_item_id=NULL;
		tag_t *ParentBom=NULLTAG;
		tag_t item_rev_tag = NULLTAG;
		tag_t ColItem_rev_tag = NULLTAG;
		tag_t vol=NULLTAG;
		tag_t ParentBomLineTag = NULLTAG;
		tag_t bom_view = NULLTAG;
		tag_t rule, item_tag = null_tag, topline_tag;
		tag_t itemCol_tag = null_tag;
		char refname[AE_reference_size_c + 1];
		char pathnamee[SS_MAXPATHLEN + 1];
		char orig_name[IMF_filename_size_c + 1];
		tag_t refobject = NULLTAG;
		AE_reference_type_t reftype;
		tag_t* bvr_tags = NULL;
		tag_t *tags_found = NULL;
		tag_t *tags_foundC = NULL;
		tag_t *rev1 = NULL;
		tag_t *secondary_objects = NULLTAG;
		tag_t *secondary_objects1 = NULLTAG;
		tag_t *lines = NULL;
		tag_t *lines2 = NULL;
		tag_t *ColChildLines = NULL;
		tag_t *bom_variant_config=NULL;
		tag_t *bom_variant_config_Col=NULL;
		tag_t *outputVNCol_tags=NULLTAG;
		tag_t *outputVCol_tags=NULLTAG;
		tag_t primary=NULLTAG;
		tag_t primary1=NULLTAG;
		tag_t objTypeTagDi=NULLTAG;
		tag_t objTypeTagDi1=NULLTAG;
		tag_t bom_window=NULLTAG;
		tag_t bom_windowCol=NULLTAG;
		tag_t top_line=NULLTAG;
		tag_t top_lineCol=NULLTAG;
		tag_t VarientRuletag = NULLTAG;
		tag_t VarientRuleColtag = NULLTAG;
		tag_t Childobject=NULLTAG;
		tag_t Childobject2=NULLTAG;
		tag_t ColChildobject=NULLTAG;
		int n_tags_found,n_tags_foundC,n_rev,k,k1,countV,countV1,countDep1= 0;
		int n_lines,n_lines1,n_lines2,n_lines3 = 0;
		int n_entriesV = 1;
		int resultCountVNCol = 0;
		int resultCountVCol = 0;
		int p1,p2,p3 = 0;
		char *Context_Str=NULL;
		char type_name1[TCTYPE_name_size_c+1];
		char type_name2[TCTYPE_name_size_c+1];
		char *Clrscheme	= NULL;
		DMLNo	= NULL;
		tag_t ERCDMLTag = NULLTAG;
		int n_entriesDML = 1;
		char *qry_entries5[1] = {"ID"};
		int resultColSchm,resultDMLNo = 0;
		tag_t *DMLNotags=NULLTAG;
		tag_t ERCDMLObjtag = NULLTAG;
		tag_t VehicleRlzRev = NULLTAG;
		tag_t VcRlzRev = NULLTAG;
		tag_t ERCDMLTypeTag=NULLTAG;
		char  *ERCDML_name=NULL;
		tag_t relation_type;
		int   n_attchs,l = 0;
		char* object_type		= NULL;
		char* Object_id		= NULL;
		char* Itemid		= NULL;	
		tag_t SchmqueryTag = NULLTAG;
		char  *CpyClrscheme	= NULL;
		int n_entriesSchm = 1;
		char *qry_entries4[1] = {"ID"};
		tag_t *ColSchme_tags=NULLTAG;
		tag_t ColSchmTypeTag=NULLTAG;
		char* t5objectStr = NULL;
		int status_count=0, sc=0, SchmRevCnt=0, AppliSvrCnt=0, s2=0;
		tag_t* SchmRevsTag= NULLTAG;
		tag_t* AppliSvrsTags= NULLTAG;
		tag_t* relStatus_list= NULLTAG;
		tag_t* RlzStus_list= NULLTAG;
		int RlzRevFlag,rs=0;
		char *ProObjRelSt = NULL;		
		char *RelStatusmatch = NULL;
		char *VcRelStatusmatch = NULL;
		char *ClSrlName = NULL;
		char *ClSuffix=NULL;
		tag_t ColorSchemetag = NULLTAG;	
		char *SuffixCpy= NULL;	
		SuffixCpy=MEM_alloc(50);
		char *SuffixCpy1= NULL;	
		SuffixCpy1=MEM_alloc(50);
		char *ColorVC1= NULL;	
		//ColorVC1=MEM_alloc(100);
		char *clrVCs1= NULL;
		
		char *Vehicle= NULL;	
		Vehicle=MEM_alloc(100);
		char *CCVItem = NULL;
		char *NonColor = NULL;
		tag_t VCItemTag = NULLTAG;
		tag_t *VCtags_found=NULLTAG;
		int n_VCtag =0;
		char **valuesCCV = (char **) MEM_alloc(1 * sizeof(char *));
		int n_entriesCCV = 1;
		char *CCV_entries[1] = {"ID"};
		tag_t CCVItemExist = NULLTAG;	
		tag_t CCVMaster = NULLTAG;	
		tag_t CCVrev = NULLTAG;	
		tag_t CCVSolutionItem;
		tag_t CCVreltask	= NULLTAG;
		tag_t X4Item = NULLTAG;
		tag_t X4ItemRevision = NULLTAG;
		char *word=NULL;
		char *name, *sequence_no;
		int iChildItemTag;
		tag_t t_ChildItemRev=NULLTAG;
		tag_t objTypeTag=NULLTAG;
		char  typeName[TCTYPE_name_size_c+1];
		int no_bom_lines =0;
		tag_t *child_bom_lines;
		int    bv_count, bvr_count;
		tag_t *bvs, *bvrs;
		tag_t  bv,bvr = NULLTAG;
		tag_t  archObjTag = NULLTAG;
		
		char *Veh_RevSeq = NULL;	
		char *Vc_RevSeq  =NULL;
		char *Arcbl_Item_id = NULL;	
		char *Item_ID_str= NULL;
		int Revformula;	

		char *bl_Item_id = NULL;
		char *item_Rev_Seq = NULL;
		char *Item_Rev = NULL;
		char *Item_Seq = NULL;
		int NonClrPartlevel = 0;
		char *t5ColourInd = NULL;
		char *t5_PrtCatCd = NULL;

		tag_t queryds = NULLTAG;
		char *qry_entriesds[2] = {"Revision","ID"};
		char **qry_valuesds = (char **) MEM_alloc(50 * sizeof(char *));
		int n_entries = 2;	
		char *itemRevSeq2=NULL;
		int ds_tags_found=0;
		tag_t	*itemrevdsclass	= NULLTAG;
		tag_t	latestrev		= NULLTAG;
		int returnV =0;

		char *t5PrtCatCd = NULL;
		char *t5itemid = NULL;
		char *t5revision_id = NULL;
		char *t5object_desc = NULL;
		char *t5_ColourInd = NULL;
		char *t5_PartStatus = NULL;
		char *t5_DesignGrp = NULL;
		char *t5_ProjectCode = NULL;
		char *t5_DocRemarks = NULL;
		char *t5_DrawingInd = NULL;
		char *t5_PartType = NULL;
		char *t5_PartCode = NULL;
		char *t5_AhdMakeBuyIndicator = NULL;
		char *t5_PunPCBUMakeBuyIndicator = NULL;
		char *t5_PunMakeBuyIndicator = NULL;
		char *t5_DwdMakeBuyIndicator = NULL;
		tag_t SchmWithCmpcdRel;
		tag_t SchmWithCmpcdRel_VC;
		logical	checkout = 0;
		int Cmpcount =0;
		int CmpVcCnt =0;
		tag_t *CmpCodeOfClrScheme = NULLTAG;
		tag_t *CmpCodeOfClrSchemeVC = NULLTAG;
		tag_t CmpCodeObj=NULLTAG;
		tag_t VCCmpCodeObj=NULLTAG;
		int g1,g2 =0;
		char *CmpCodeCmp = NULL;
		char*	t5ClSrl=NULL;
		char*	t5CoatedS="C";
		char*	Suffix=NULL;
		char*	ColourIDSchm=NULL;
		char*	ColourID=NULL;
		char *ColorVCDesc=NULL;
		char *itemRevSeq = NULL;
		tag_t	ItemTag1	= NULLTAG;
		tag_t	item	= NULLTAG;
		tag_t	rev	= NULLTAG;
		tag_t ClrPartTag = NULLTAG;
		char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));
		int n_entriesC = 1;
		char *qry_entries[1] = {"ID"};
		int n_tags_found1 = 0;
		tag_t *tags_found1 = NULL;	
		
		char *SVRName = NULL;
		char *SVRAssociatInfo = NULL;
		char *bl_ArchModule = NULL;
		char *item_rev = NULL;
		int item_revision_id_int =1;
		tag_t	occsal_tag	= NULLTAG;
		tag_t RelSolutionItem = NULLTAG;
		tag_t tRelationFind = NULLTAG;
		tag_t SolutionItemExist = NULLTAG;
		tag_t tRelationExist = NULLTAG;
		tag_t 	   reltask	= NULLTAG;
		tag_t 	   Rel_task	= NULLTAG;
		tag_t 	   CCVObject	= NULLTAG;
		tag_t  clrbv    = NULLTAG;
		tag_t  clrbvr    = NULLTAG;
		tag_t	Clrrev1		= NULLTAG;
		tag_t	ColorRev		= NULLTAG;
		tag_t  *occs=NULL;
		tag_t  *occs1=NULL;
		int n_parents,jd =0;
		int *levels = 0;
		tag_t *parents = NULL;
		tag_t archTypeTag=NULLTAG;
		tag_t VCtag=NULLTAG;
		tag_t VCItemRev=NULLTAG;
		char  archTypename[TCTYPE_name_size_c+1];	
		
		char *user_name_string = NULL;
		char *UserId = NULL;
		char *SchTok = NULL;
		
		int rulefound= 0;
		tag_t *closurerule = NULL;
		tag_t close_tag;
		char **rulename = NULL;
		char **rulevalue = NULL;
		tag_t			VeHMstr      = NULLTAG;
				        VcMstr      = NULLTAG;
		tag_t			latest_rev_tag				= NULLTAG;
		tag_t CCVRelationFind;	
		tag_t NonClrBOMLine=NULLTAG;
		char *ColorVC= NULL;	
		ColorVC=MEM_alloc(100);
		tag_t NVCtag=NULLTAG;
		tag_t NVCItemRev=NULLTAG;
		int Child_VCRev_count,hd,VCRevCnt,CRevCnt,hs,ht =0;
		tag_t*	Child_VCrev_list = NULLTAG;
		tag_t* RlzStus_VC_list;
		tag_t* RlzStus_CVC_list;
		char *VCRelStatusM = NULL;
		char *CRelStatusM = NULL;
		
		tag_t NVCRlzRev = NULLTAG;
		int NVCRlzRevFlag=0;
		int    bv_clrcount=0;
		int    clr_bvrcnt=0;
		tag_t *clr_bvs=NULL;
		tag_t *clrbvrs=NULL;
		tag_t  VCclrbv    = NULLTAG;
		tag_t  VCclrbvr    = NULLTAG;
		tag_t IMANReferences_type;
		//tag_t Rel_References	= NULLTAG;

		int n_occs;
		tag_t *occsal;
		int iy =0;
		tag_t	ChildItem		= NULLTAG;
		tag_t	bvrchild		= NULLTAG;
		char	*occ_item_id		= NULL;	
		tag_t ClrVariqueryTag = NULLTAG;
		tag_t CMRefExist = NULLTAG;
		char	*sClrSerSuf			=	NULL;
		int n_entriesV1 = 1;
		int ClrCnt =0;
		tag_t *ColVRule_tags=NULLTAG;
		tag_t variantule=NULLTAG;
		tag_t References_type;
		tag_t Rel_References	= NULLTAG;
		tag_t ReferencesRelExist = NULLTAG;
		char *qry_entriesClrSvr[1] = {"Name"};
		char	*UsrName		= NULL;
		char	*gov_classif		= NULL;
		char	*clrVCs		= NULL;
		char	*VCSuffix = NULL;
		char	*clrVCSuffix = NULL;
		char	*NclrVCSuffix = NULL;
		char	*CharSr		= NULL;
		tag_t *ClrSVRName = NULLTAG;
		int VariantCnt =0;
		int first_char;
		int TskCntClr=0;
		tag_t *TskSOClr=NULLTAG;
		char	*sClrVCName			=	NULL;
		char	*sClrVCNo			=	NULL;
		tag_t	ItemTag	= NULLTAG;
		tag_t	objTypTag	= NULLTAG;
		tag_t	SVRTag	= NULLTAG;
        tag_t NewVCRevTag=NULLTAG;
		int flg1 =0;
		char* Response = NULL ;		
		char **valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));	
		char  ColSchm_name[TCTYPE_name_size_c+1];
		char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
		char **valuesERCDML = (char **) MEM_alloc(1 * sizeof(char *));
		char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
		char **values = (char **) MEM_alloc(1 * sizeof(char *));
		char **ValNcolPlatform = (char **) MEM_alloc(1 * sizeof(char *));
		char **valuesColSvr = (char **) MEM_alloc(1 * sizeof(char *));
		char *qry_entries3[1] = {"Name"}, *qry_values3[1]	= {"*"};
		char		*user_id			= NULL;
		char *ofileLoc = NULL;
		logical modB=FALSE;
		logical modBCol=FALSE;
		
		//FileDown=(char *) MEM_alloc(100 * sizeof(char ));
	   
		FileOp=(char *) MEM_alloc(300 * sizeof(char ));
        Filelog=(char *) MEM_alloc(300 * sizeof(char ));
		SVRruleIP=MEM_alloc(20);

		(void)argc;
		(void)argv;


		char		*DataSet_Id			= NULL;
		char		*delDataset			= NULL;
		char *siteName	= NULL;;
		int site_id ;
		//tag_t  home_site_tag=NULLTAG;
		//tag_t  *user_tag=NULLTAG;
		tag_t		deldataset_tag	= NULLTAG;
		Platform     = ITK_ask_cli_argument("-i=");   
		SVRrule      = ITK_ask_cli_argument("-s=");
		Clrscheme    = ITK_ask_cli_argument("-shm=");
		DMLNo        = ITK_ask_cli_argument("-dml=");
		sClrSerSuf   = ITK_ask_cli_argument("-as=");
		sClrVCName   = ITK_ask_cli_argument("-cvc=");
		user_name_string    = ITK_ask_cli_argument("-Usr=");
		ofileLoc = ITK_ask_cli_argument("-outF=");
		
		ifail = ITK_initialize_text_services( ITK_BATCH_TEXT_MODE );
		ifail = ITK_auto_login();
		ifail = ITK_set_journalling( TRUE );
		
		printf("\n Platform-------->  : %s",Platform); fflush(stdout);
		printf("\n SVRrule-------->  : %s",SVRrule); fflush(stdout);
		printf("\n Clrscheme-------->  : %s",Clrscheme); fflush(stdout);
		printf("\n DMLNo-------->  : %s",DMLNo); fflush(stdout);
		printf("\n sClrSerSuf-------->  : %s",sClrSerSuf); fflush(stdout);
		printf("\n sClrVCName-------->  : %s",sClrVCName); fflush(stdout);
		printf("\n user_name_string-------->  : %s\n",user_name_string);fflush(stdout);

		ITK_CALL(SA_find_user2(user_name_string, &user_tag));
       //ITK_CALL(SA_find_group("PLM_Support_Group", &group));
	    ITK_CALL(SA_find_group("ERC_Designers_Group", &group));
        //ITK_CALL(SA_ask_user_home_site(user_tag,&home_site_tag));
		//ITK_CALL(SA_ask_site_info2(home_site_tag,&siteName,&site_id));
		//printf("\n home_site_string-------->  : %s\n",siteName);fflush(stdout);
		//tc_strcpy(FileDown,"");
		//tc_strcat(FileDown,"/plmpv16/reports");
		////tc_strcat(FileDown,ofileLoc);
		//tc_strcat(FileDown,"/");
		//tc_strcat(FileDown,Platform);
		//tc_strcat(FileDown,"_");
		//tc_strcat(FileDown,DMLNo);
		//tc_strcat(FileDown,"_");
		//tc_strcat(FileDown,SVRrule);
		//tc_strcat(FileDown,"_ClrUnitBOM.txt");
		//printf("\n FileDown---------> %s",FileDown);fflush(stdout);
		//output = fopen(FileDown, "a+");


		tc_strcpy(FileOp,"");
		//tc_strcat(FileOp,"/user/testcmi/Gajanan/SuffixSelection");
		tc_strcat(FileOp,"/plmpv16/reports");
		//tc_strcat(FileOp,ofileLoc);
		tc_strcat(FileOp,"/");
		tc_strcat(FileOp,Platform);
		tc_strcat(FileOp,"_");
		tc_strcat(FileOp,DMLNo);
		tc_strcat(FileOp,"_");
		tc_strcat(FileOp,SVRrule);
		tc_strcat(FileOp,"_ClrUnitBOMError.txt");
		printf("\n FileOp---------> %s",FileOp);fflush(stdout);


		tc_strcpy(Filelog,"");
		//tc_strcat(Filelog,"/user/testcmi/Gajanan/SuffixSelection");
		tc_strcat(Filelog,"/plmpv16/reports/BOMGEN_LOG");
		//tc_strcat(Filelog,ofileLoc);
		tc_strcat(Filelog,"/");
		tc_strcat(Filelog,DMLNo);
		tc_strcat(Filelog,"_");
		tc_strcat(Filelog,SVRrule);
		tc_strcat(Filelog,"_");
		tc_strcat(Filelog,"_ClrBOMGen.log");
		printf("\n Filelog---------> %s",Filelog);fflush(stdout);

        fplog = fopen(Filelog, "w");



				   printf ("\n Platfrom : %s  And DMLno: %s: ",Platform,DMLNo);
				   fprintf(fplog,"\n Platfrom : %s  And DMLno: %s: ",Platform,DMLNo);
					delDataset=(char *) MEM_alloc(300 * sizeof(char ));
					tc_strcpy(delDataset,"");
					tc_strcat(delDataset,Platform);
					tc_strcat(delDataset,"_");
					tc_strcat(delDataset,DMLNo);
					tc_strcat(delDataset,"_");
					tc_strcat(delDataset,SVRrule);
					tc_strcat(delDataset,"_ClrUnitBOMError");
					printf ("\n Dataset Name is .....%s \n",delDataset);

				tag_t		DelqryTag				= NULLTAG;
				tag_t		*DelCntrolObjectTag		= NULLTAG;
				tag_t		*attachments			= NULLTAG;
				tag_t		foldert_tag				= NULLTAG;


				char *Delqry_entry[1]		= {"Name"};
				char **Delqry_values2		= (char **) MEM_alloc(10 * sizeof(char *));
				int	 n_Delentry				= 1;
				int	 DelrsltCount			= 0;
				int	 i2						= 0;
				int	 cnt				    = 0;
			   // tag_t		datasetTag					= NULLTAG;
		   

				ITK_CALL(ITK_set_bypass(true));
				if(QRY_find2("folder custom", &DelqryTag));
				if (DelqryTag != NULLTAG)
				{
					printf ("\n Inside query ....1\n");
					Delqry_values2[0] = "ClrUnitBOMErr";
					if(QRY_execute(DelqryTag, n_Delentry, Delqry_entry, Delqry_values2, &DelrsltCount, &DelCntrolObjectTag));
					 foldert_tag=DelCntrolObjectTag[0];
			
			
				}
				ITK_CALL(AE_find_dataset2(delDataset,&deldataset_tag));       
				printf ("\n Dataset Name is ....3.%s \n",delDataset);
				if (deldataset_tag !=NULLTAG)
				{                 
						   if(AOM_ask_value_string(deldataset_tag, "object_name", &DataSet_Id)!=ITK_ok);
						   if (tc_strcmp(DataSet_Id,delDataset)==0)
						   {
													    
									 ITK_CALL(FL_remove(foldert_tag,deldataset_tag));
									 ITK_CALL(AOM_save_without_extensions(foldert_tag));
									 ITK_CALL(AOM_refresh(foldert_tag,0));									
						             ITK_CALL(AOM_delete(deldataset_tag));
						             printf ("\n Dataset Deleletd Successfull \n");
								
							 }
							 else
								{
									 printf ("\n Dataset not present in TC Need to create%s \n",delDataset);
								}
				   
				}
				else
				{
				  printf ("\n Dataset not present \n");
				}

		fp = fopen(FileOp, "w");
		int Child_Rev_count,ChildVc_Rev_count,dd,ddd,RevCnt,VcRevCnt,hp,hpp =0;
		tag_t*	Child_rev_list	= NULLTAG;
		tag_t*	ChildVc_rev_list	= NULLTAG;

		ifail = GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRelMultlvl);
		NVCRlzRevFlag=0;
		if( Platform )
		{		
			//QUERY VARIANT RULE
			if(QRY_find2("VariantRule", &VariqueryTag));
			if (VariqueryTag) {
				printf("\n Found Query VariantRule------>"); fflush(stdout);
				 fprintf(fplog,"\n Found Query VariantRule------>");
			}else {
				ifail = POM_logout(false);
				return status;
			}

			printf("\n SVR/ VC length---------->%d\n\t",tc_strlen(SVRrule)); fflush(stdout);
			fprintf(fplog,"\n SVR/ VC length---------->%d\n\t",tc_strlen(SVRrule));
			tc_strcpy(SVRruleIP,SVRrule);
			if (tc_strlen(SVRrule)>12)
			{
			valuesNonColSvr[0] = SVRrule;
			if(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));
			printf("\n resultCount---------->%d\n\t",resultCountVNCol); fflush(stdout);
			fprintf(fplog,"\n resultCount---------->%d\n\t",resultCountVNCol);
			
			if (resultCountVNCol > 0)
			{
				SVRTag=outputVNCol_tags[0];

				NonColor=tc_strtok(SVRrule,"_");
				printf ( "\n NonColor is -------> %s",NonColor);fflush(stdout);
				fprintf(fplog,"\n NonColor is -------> %s",NonColor);
			
				Item_Rev = tc_strtok(NULL,"_");
				printf("\n Item_Rev --> : %s \n",Item_Rev); fflush(stdout);	
				fprintf(fplog,"\n Item_Rev --> : %s \n",Item_Rev);
				Vehicle = MEM_alloc(10);
				//ITK_CALL(STRNG_replace_str(NonColor,"000R","R",&Vehicle));
				        tc_strcpy(Vehicle,"");
                        tc_strcpy(Vehicle,subString(NonColor,0,8));
						tc_strcat(Vehicle,subString(NonColor,11,1));
				printf ( "\n Vehicle is -------> %s \n",Vehicle);fflush(stdout);
                fprintf(fplog,"\n Vehicle is -------> %s \n",Vehicle);
				ITK_CALL(ITEM_find_item(Vehicle, &VeHMstr));
				printf("\n VeHMstr is ------->");fflush(stdout);

				if(VeHMstr)
				{		
					ifail = ITEM_list_all_revs (VeHMstr, &Child_Rev_count, &Child_rev_list);
					printf("\n Child_rev_list---------------> : %d", Child_Rev_count);fflush(stdout);
					if(Child_Rev_count > 0)
					{
						for(dd=Child_Rev_count-1;dd>=0;dd--)
						{
							ITK_CALL(AOM_UIF_ask_value (Child_rev_list[dd], "release_status_list", &RelStatusmatch));
							if((tc_strstr(RelStatusmatch,"ERC Released")!=NULL)||(tc_strstr(RelStatusmatch,"T5_LcsErcRlzd")!=NULL))
							//if((tc_strstr(RelStatusmatch,"APLC Released")!=NULL)||(tc_strstr(RelStatusmatch,"T5_LcsAplRlzd")!=NULL))
							{
								VehicleRlzRev=Child_rev_list[dd];

								ITK_CALL(AOM_ask_value_string(VehicleRlzRev, "item_revision_id", &Veh_RevSeq));

								printf("\n Veh_RevSeq==>: %s", Veh_RevSeq);fflush(stdout);
								break;
							}							
						}
					}				
				}
			}
			else
			{
				printf("\n Input SVR is not found and queried, skipping ...\n\n"); fflush(stdout);
				fprintf(fp,"Input SVR is not found and queried, skipping ...");
				fprintf(fplog,"\n Input SVR is not found and queried, skipping ...");
				createDataset(fp);
				exit (0);
			}
		
			}
			else
			{
				NonColor=(char *) MEM_alloc(12 * sizeof(char *));
				strcpy(NonColor,SVRrule);
				//NonColor=tc_strtok(SVRrule,"_");
				printf ( "\n NonColor is -------> %s",NonColor);fflush(stdout);
				fprintf(fplog,"\n NonColor is -------> %s",NonColor);
			
				Item_Rev = tc_strtok(NULL,"_");
				printf("\n Item_Rev --> : %s \n",Item_Rev); fflush(stdout);
				fprintf(fplog,"\n Item_Rev --> : %s \n",Item_Rev);
				Vehicle = MEM_alloc(10);
				//ITK_CALL(STRNG_replace_str(NonColor,"000R","R",&Vehicle));
				        tc_strcpy(Vehicle,"");
                        tc_strcpy(Vehicle,subString(NonColor,0,8));
						tc_strcat(Vehicle,subString(NonColor,11,1));
				printf ( "\n Vehicle is -------> %s \n",Vehicle);fflush(stdout);
				fprintf(fplog,"\n Vehicle is -------> %s \n",Vehicle);
                ITK_CALL(ITEM_find_item(NonColor, &VcMstr));

			if(VcMstr)
				{		
					ifail = ITEM_list_all_revs (VcMstr, &ChildVc_Rev_count, &ChildVc_rev_list);
					printf("\n Child_rev_list---------------> : %d", ChildVc_Rev_count);fflush(stdout);
					fprintf(fplog,"\n Child_rev_list---------------> : %d\n",ChildVc_Rev_count);
					if(ChildVc_Rev_count > 0)
					{
						for(ddd=ChildVc_Rev_count-1;ddd>=0;ddd--)
						{
							ITK_CALL(AOM_UIF_ask_value (ChildVc_rev_list[ddd], "release_status_list", &VcRelStatusmatch));
							if((tc_strstr(VcRelStatusmatch,"ERC Released")!=NULL)||(tc_strstr(VcRelStatusmatch,"T5_LcsErcRlzd")!=NULL))
							//if((tc_strstr(VcRelStatusmatch,"APLC Released")!=NULL)||(tc_strstr(VcRelStatusmatch,"T5_LcsAplRlzd")!=NULL))
							{
								VcRlzRev=ChildVc_rev_list[ddd];

								ITK_CALL(AOM_ask_value_string(VcRlzRev, "item_revision_id", &Vc_RevSeq));

								printf("\n Vc_RevSeq==>: %s", Vc_RevSeq);fflush(stdout);
								fprintf(fplog,"\n Vc_RevSeq==>: %s\n",Vc_RevSeq);
								break;
							}							
						}
					}				
				}
				else
				{
					printf("\n Unable to find VC in TC  -------> %s", NonColor);fflush(stdout);
					fprintf(fplog,"\n Unable to find VC in TC  -------> %s \n",NonColor);
				}
            
			

				ITK_CALL(ITEM_find_item(Vehicle, &VeHMstr));
				printf("\n VeHMstr is ------->");fflush(stdout);
				fprintf(fplog,"\n VeHMstr is -------> \n");

				if(VeHMstr)
				{		
					ifail = ITEM_list_all_revs (VeHMstr, &Child_Rev_count, &Child_rev_list);
					printf("\n Child_rev_list---------------> : %d", Child_Rev_count);fflush(stdout);
					fprintf(fplog,"\n Child_rev_list---------------> : %d", Child_Rev_count);
					if(Child_Rev_count > 0)
					{
						for(dd=Child_Rev_count-1;dd>=0;dd--)
						{
							ITK_CALL(AOM_UIF_ask_value (Child_rev_list[dd], "release_status_list", &RelStatusmatch));
							if((tc_strstr(RelStatusmatch,"ERC Released")!=NULL)||(tc_strstr(RelStatusmatch,"T5_LcsErcRlzd")!=NULL))
							//if((tc_strstr(RelStatusmatch,"APLC Released")!=NULL)||(tc_strstr(RelStatusmatch,"T5_LcsAplRlzd")!=NULL))
							{
								VehicleRlzRev=Child_rev_list[dd];

								ITK_CALL(AOM_ask_value_string(VehicleRlzRev, "item_revision_id", &Veh_RevSeq));

								printf("\n Veh_RevSeq==>: %s", Veh_RevSeq);fflush(stdout);
								fprintf(fplog,"\n Veh_RevSeq==>: %s", Veh_RevSeq);
								break;
							}							
						}
					}				
				}
            }

			//QUERY ERC DML
			if(QRY_find2("ERC DML", &ERCDMLTag));
			if (ERCDMLTag) { 
				printf("\n Found Query ERCDMLTag"); fflush(stdout);
				fprintf(fplog,"\n Found Query ERCDMLTag");
			}else {
				ifail = POM_logout(false);
				return status;
			}			
			valuesERCDML[0] = DMLNo ;
			if(QRY_execute(ERCDMLTag, n_entriesDML, qry_entries5, valuesERCDML, &resultDMLNo, &DMLNotags));
			printf("\n resultDMLNo count is-------->  : %d \n",resultDMLNo);fflush(stdout);
			fprintf(fplog,"\n resultDMLNo count is-------->  : %d \n",resultDMLNo);

			if (resultDMLNo > 0)
			{
				ERCDMLObjtag = DMLNotags[0];
			}else 
				{
				fprintf(fp,"Please check DML.....");
				fprintf(fplog,"Please check DML.....");
				createDataset(fp);
				exit (0);
				}

			ITK_CALL(TCTYPE_ask_object_type(ERCDMLObjtag,&ERCDMLTypeTag));
			ITK_CALL(TCTYPE_ask_name2(ERCDMLTypeTag,&ERCDML_name));
			printf("\n ERCDML_Typename------> %s",ERCDML_name);fflush(stdout);
			if(strcmp(ERCDML_name,"ChangeRequestRevision")==0)
			{
				ifail = GRM_find_relation_type("T5_DMLTaskRelation", &relation_type);
				if (relation_type!=NULLTAG)
				{
					ifail = GRM_list_secondary_objects_only(ERCDMLObjtag,relation_type,&n_attchs,&secondary_objects);
					printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);
					fprintf(fplog,"\n\n\t\t No of DI : %d",n_attchs);

					if(n_attchs>0)
					{
						for (l=0;l<n_attchs ;l++ )
						{					
							ifail = AOM_ask_value_string(secondary_objects[l],"item_id",&Object_id);
							printf("\n\n\t\t Object_id is :%s",Object_id);fflush(stdout);
							fprintf(fplog,"\n\n\t\t Object_id is :%s",Object_id);
							if(tc_strstr(Object_id,"_00")!=NULL)
							{	
								if(taskRevTag) taskRevTag=NULLTAG;
								taskRevTag=secondary_objects[l];
							}
						}
					}
				}
			}
			
			//QUERY COLOUR SCHEME
			if(QRY_find2("ClrScheme", &SchmqueryTag));
			if (SchmqueryTag) {
				printf("\n\n Found Query SchmqueryTag"); fflush(stdout);
				fprintf(fplog,"\n\n Found Query SchmqueryTag");
			}else {
				ifail = POM_logout(false);
				return status;
			}
			
			CpyClrscheme =  strtok(Clrscheme,",");
			printf ("\n CpyClrscheme --> [%s]", CpyClrscheme); fflush(stdout);
			fprintf(fplog,"\n CpyClrscheme --> [%s]", CpyClrscheme);
			valuesColSchm[0] = CpyClrscheme ;
			if(QRY_execute(SchmqueryTag, n_entriesSchm, qry_entries4, valuesColSchm, &resultColSchm, &ColSchme_tags));
			printf("\n resultColSchm count is-------->  : %d \n",resultColSchm);fflush(stdout);
			fprintf(fplog,"\n resultColSchm count is-------->  : %d \n",resultColSchm);
			if (resultColSchm > 0)
			{
				ColSchmRevTag=NULLTAG;

				ColorSchemetag = ColSchme_tags[0];			
			
				//ITK_CALL(ITEM_ask_latest_rev(ColorSchemetag, &ColSchmRevTag));
				ITK_CALL(ITEM_list_all_revs(ColorSchemetag, &SchmRevCnt, &SchmRevsTag));
				printf("\n resultColSchm SchmRevCnt-------->  : %d \n",SchmRevCnt);fflush(stdout);
				fprintf(fplog,"\n resultColSchm SchmRevCnt-------->  : %d \n",SchmRevCnt);

				for(sc=SchmRevCnt-1;sc>=0;sc--)
				{
					ITK_CALL(WSOM_ask_release_status_list(SchmRevsTag[sc], &status_count, &relStatus_list));
					printf("\n status_count is --> : %d  ",status_count); fflush(stdout);
					fprintf(fplog,"\n status_count is --> : %d  ",status_count);
					if(status_count > 0)
					{
						RlzRevFlag=0;
						for(rs = 0; rs < status_count; rs++)
						{
							if(AOM_ask_name(relStatus_list[rs], &ProObjRelSt)==ITK_ok)
							printf("\t ColSchm Release status is:=>%s", ProObjRelSt); fflush(stdout);
							fprintf(fplog,"\t ColSchm Release status is:=>%s", ProObjRelSt);
							if (tc_strstr(ProObjRelSt,"T5_LcsErcRlzd")!=NULL|| tc_strstr(ProObjRelSt,"ERC Released")!=NULL)
							{
								RlzRevFlag=1;
								break;
							}
						}
					}
					printf("\t RlzRevFlag: %d \n",RlzRevFlag); fflush(stdout);
					fprintf(fplog,"\t RlzRevFlag: %d \n",RlzRevFlag);
					if (RlzRevFlag==1)
					{
						ColSchmRevTag=SchmRevsTag[sc];

						break;
					}
				}

				if (ColSchmRevTag==NULLTAG)
				{
					printf("\n Scheme ERC released Tag is not found, skipping ...\n\n"); fflush(stdout);
					fprintf(fp,"Scheme ERC released Tag is not found, skipping ...");
					fprintf(fplog,"Scheme ERC released Tag is not found, skipping ...");
					createDataset(fp);
					exit (0);
				}

				ITK_CALL(AOM_ask_value_string(ColSchmRevTag, "object_string", &t5objectStr));
				printf("\n t5objectStr is --> : %s\n",t5objectStr); fflush(stdout);
				fprintf(fplog,"\n t5objectStr is --> : %s\n",t5objectStr);
				
				SchTok=strtok(t5objectStr,";");
				printf ("\n Color Scheme is : %s \n", SchTok);fflush(stdout);
				fprintf(fplog,"\n Color Scheme is : %s \n", SchTok);

				ITK_CALL(STRNG_replace_str(SchTok,",","#",&SchDataToGov));
				printf ( "\n SchDataToGov is -------> %s \n",SchDataToGov);fflush(stdout);
				fprintf(fplog,"\n SchDataToGov is -------> %s \n",SchDataToGov);

				ITK_CALL(AOM_ask_value_string(ColSchmRevTag, "t5_ClSrl", &t5ClSrl));

			}else { 
				fprintf(fp,"resultColSchm count is-------->: %d ",resultColSchm);
				fprintf(fplog,"resultColSchm count is-------->: %d ",resultColSchm);
				createDataset(fp);
				exit(0);
				}		

			ITK_CALL(GRM_find_relation_type("IMAN_reference", &IMANReferences_type));	//References folder		
			if(IMANReferences_type!=NULLTAG)
			{	
				ITK_CALL(GRM_find_relation(ERCDMLObjtag,ColSchmRevTag,IMANReferences_type,&CMRefExist));
				if(CMRefExist==NULLTAG)
				{
					ITK_CALL(GRM_create_relation(ERCDMLObjtag,ColSchmRevTag,IMANReferences_type, NULLTAG, &Rel_References));
					ITK_CALL(AOM_load(Rel_References)); 
					ITK_CALL(GRM_save_relation(Rel_References)); 
					ITK_CALL(AOM_refresh(Rel_References,0));
				}else
				printf("\n Input Scheme is already attached to DML Refernce folder-------------------->>>>");fflush(stdout);
				fprintf(fplog,"\n Input Scheme is already attached to DML Refernce folder-------------------->>>>");
			}
			
			printf ("\n NonColor is -------> %s",NonColor);fflush(stdout);
			fprintf(fplog,"\n NonColor is -------> %s",NonColor);
			printf("\n t5ClSrl is --> : %s\n",t5ClSrl); fflush(stdout);
			fprintf(fplog,"\n t5ClSrl is --> : %s\n",t5ClSrl);
			if(tc_strstr(t5ClSrl,";")!=NULL)
			{															
				Suffix =  strtok(t5ClSrl,";");
				printf("\n Suffix --> : %s",Suffix); fflush(stdout);

				ColourIDSchm  =  strtok(NULL,";");
				printf("\n ColourIDSchm --> : %s \n",ColourIDSchm); fflush(stdout);
				fprintf(fplog,"\n ColourIDSchm --> : %s \n",ColourIDSchm);
			}
			
			ITK_CALL(ITEM_find_item(NonColor,&NVCtag))
			if(NVCtag)
			{				
				ITK_CALL(ITEM_list_all_revs (NVCtag, &Child_VCRev_count, &Child_VCrev_list));
				printf("\n Child_VCRev_count---------------> : %d \n", Child_VCRev_count);fflush(stdout);
				fprintf(fplog,"\n Child_VCRev_count---------------> : %d \n", Child_VCRev_count);

				for(hd = 0; hd < Child_VCRev_count; hd++) //Need to confirm looping hd++ or hd--
				{
					ITK_CALL(WSOM_ask_release_status_list(Child_VCrev_list[hd], &VCRevCnt, &RlzStus_VC_list));
					printf("\n VCRevCnt is --> : %d\n",VCRevCnt); fflush(stdout);
					fprintf(fplog,"\n VCRevCnt is --> : %d\n",VCRevCnt);

					if(VCRevCnt > 0)
					{
						for(hs = 0; hs < VCRevCnt; hs++)
						{
							if(AOM_ask_name(RlzStus_VC_list[hs], &VCRelStatusM)==ITK_ok)
							printf("\t Release status is:=>%s\n", VCRelStatusM); fflush(stdout);
							fprintf(fplog,"\t Release status is:=>%s\n", VCRelStatusM);

							if (tc_strstr(VCRelStatusM,"T5_LcsErcRlzd")!=NULL || tc_strstr(VCRelStatusM,"ERC Released")!=NULL)
							{
								NVCRlzRev = Child_VCrev_list[hd];
								NVCRlzRevFlag=1;

								if(AOM_ask_value_string(NVCRlzRev, "item_id", &t5itemid)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "current_revision_id", &t5revision_id)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "object_desc", &t5object_desc)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_ColourInd", &t5_ColourInd)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_PartStatus", &t5_PartStatus)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_DesignGrp", &t5_DesignGrp)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_ProjectCode", &t5_ProjectCode)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_DocRemarks", &t5_DocRemarks)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_DrawingInd", &t5_DrawingInd)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_PartType", &t5_PartType)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_PartCode", &t5_PartCode)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_AhdMakeBuyIndicator", &t5_AhdMakeBuyIndicator)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_PunPCBUMakeBuyIndicator", &t5_PunPCBUMakeBuyIndicator)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_PunMakeBuyIndicator", &t5_PunMakeBuyIndicator)!=ITK_ok);
								if(AOM_ask_value_string(NVCRlzRev, "t5_DwdMakeBuyIndicator", &t5_DwdMakeBuyIndicator)!=ITK_ok);

								if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel_VC)!=ITK_ok);
								if(GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel_VC, &CmpVcCnt, &CmpCodeOfClrSchemeVC)!=ITK_ok);

								printf("\n Comp Code CmpVcCnt for Color Scheme : %d\n",CmpVcCnt); fflush(stdout);
								fprintf(fplog,"\n Comp Code CmpVcCnt for Color Scheme : %d\n",CmpVcCnt);

								printf("\t t5_ColourInd is:=>%s", t5_ColourInd); fflush(stdout);
								fprintf(fplog,"\t t5_ColourInd is:=>%s", t5_ColourInd);
								printf("\t t5_PartType is:=>%s", t5_PartType); fflush(stdout);
								fprintf(fplog,"\t t5_PartType is:=>%s", t5_PartType);
								printf("\t t5PrtCatCd is:=>%s ", t5PrtCatCd); fflush(stdout);
								fprintf(fplog,"\t t5PrtCatCd is:=>%s ", t5PrtCatCd);
								
								if(tc_strcmp(t5_ColourInd,"Y")!=0)
								{
									printf("\n Color indicator is  N====> %s\n",t5itemid);fflush(stdout);
									fprintf(fp,"Color indicator is  N====>  %s",t5itemid );fflush(stdout);
									fprintf(fplog,"Color indicator is  N====>  %s",t5itemid);
									createDataset(fp);
								   goto END;
								}

								if(tc_strcmp(t5_PartType,"VC")!=0&&tc_strcmp(t5_PartType,"CCVC")!=0)
								{
									fprintf(fp,"part type not correct====>  %s",t5itemid );fflush(stdout);
									fprintf(fplog,"part type not correct====>  %s",t5itemid );
									createDataset(fp);
									goto END;
								}

								if(tc_strcmp(t5PrtCatCd,"VC")!=0)
								{
									fprintf(fp,"comp code not correct====>  %s",t5itemid );fflush(stdout);
									fprintf(fplog,"comp code not correct====>  %s",t5itemid );
									createDataset(fp);
									goto END;							
								}

								if(CmpVcCnt > 0)
								{
									for(g2=0;g2<CmpVcCnt;g2++ )
									{													
										if(VCCmpCodeObj) VCCmpCodeObj=NULLTAG;
										VCCmpCodeObj=CmpCodeOfClrSchemeVC[g2];
										ITK_CALL(AOM_ask_value_string(VCCmpCodeObj, "t5_PrtCatCode", &CmpCodeCmp));
										if(tc_strcmp(t5PrtCatCd,CmpCodeCmp)==0)
										{	
											printf("\n CmpCodeCmp & t5PrtCatCd is --> : %s = %s\n",CmpCodeCmp,t5PrtCatCd); fflush(stdout);
											fprintf(fplog,"\n CmpCodeCmp & t5PrtCatCd is --> : %s = %s\n",CmpCodeCmp,t5PrtCatCd);
											ITK_CALL(AOM_ask_value_string(VCCmpCodeObj, "t5_ClSrl", &t5ClSrl ));
											fprintf(fplog,"\n t5ClSrl --> : %s",t5ClSrl);
											printf("\n t5ClSrl --> : %s",t5ClSrl); fflush(stdout);
											if(tc_strstr(t5ClSrl,";")!=NULL)
											{															
												Suffix =  strtok(t5ClSrl,";");
												ColourID  =  strtok(NULL,";");
												printf("\n Suffix & ColourID --> : %s=%s",Suffix,ColourID); fflush(stdout);
												fprintf(fplog,"\n Suffix & ColourID --> : %s=%s",Suffix,ColourID);
											}
											break;
										}
									}
								}
							}
							else
							{
								printf("\n Release status :...%d",hs); fflush(stdout);
							}
						}
					} 			
				}
			}
			
			if (tc_strlen(Suffix)>2)
			{
				printf("\n Color Suffix Wrong it not more than 2 Char====> %d\n",tc_strlen(ClSuffix) );fflush(stdout);
				fprintf(fp,"Color Suffix Wrong it not more than 2 Char====> %d",tc_strlen(ClSuffix) );
				fprintf(fplog,"Color Suffix Wrong it not more than 2 Char====> %d",tc_strlen(ClSuffix));
				createDataset(fp);
				exit(0);		
			}

			printf("\n\n\n NVCRlzRevFlag is------------------------------------>%d", NVCRlzRevFlag); fflush(stdout);
			fprintf(fplog,"\n\n\n NVCRlzRevFlag is------------------------------------>%d", NVCRlzRevFlag);
			if(NVCRlzRevFlag==1)
			{
				tag_t RelType = NULLTAG;
				char ObjTyp[TCTYPE_name_size_c+1];
				tag_t AppliSvrsRelTags= NULLTAG;
				printf("\n SVR/ VC length---------->........%d\n\t",tc_strlen(SVRruleIP)); fflush(stdout);
				fprintf(fplog,"\n SVR/ VC length---------->........%d\n\t",tc_strlen(SVRruleIP));
                if (tc_strlen(SVRruleIP)>12)
                {
					printf("\n\n\n For SVR------------------------------------>"); fflush(stdout);
                    fprintf(fplog,"\n\n\n For SVR------------------------------------>");
					if (GRM_find_relation_type("T5_Applicable_SVR", &RelType)!=ITK_ok);
					if (GRM_find_relation(ColSchmRevTag,SVRTag,RelType,&AppliSvrsRelTags)!=ITK_ok);
                }
				else
				{
					printf("\n\n\n For VC------------------------------------>"); fflush(stdout);
					if (GRM_find_relation_type("T5_Applicable_SVR", &RelType)!=ITK_ok);
					if (GRM_find_relation(ColSchmRevTag,VcRlzRev,RelType,&AppliSvrsRelTags)!=ITK_ok);
				}
				

				printf("\n sClrVCName => %s ",sClrVCName );fflush(stdout);
				fprintf(fplog,"\n sClrVCName => %s ",sClrVCName);
				if(strcmp(sClrVCName,"NO")==0)
				{
					strcpy(SuffixCpy1,"");
					//tc_strcat(SuffixCpy1,"A");	
					tc_strcat(SuffixCpy1,"*");	
					if(tc_strstr(t5ClSrl,";")!=NULL)
					{
						tc_strcat(SuffixCpy1,Suffix);
					}else {
						tc_strcat(SuffixCpy1,t5ClSrl);
					}
					 // ColorVC1=MEM_alloc(20);
					  clrVCs1=MEM_alloc(20);
					//ITK_CALL(STRNG_replace_str(NonColor,"000",SuffixCpy1,&ColorVC1));
					    //NclrVCSuffix=subString(NonColor,0,8);
                        tc_strcpy(clrVCs1,"");
                        tc_strcpy(clrVCs1,subString(NonColor,0,8));
						tc_strcat(clrVCs1,SuffixCpy1);
						tc_strcat(clrVCs1,subString(NonColor,11,1));

					 printf("\n\t SuffixCpy1: [%s] ",clrVCs1);
					 fprintf(fplog,"\n\t SuffixCpy1: [%s] ",clrVCs1);

					if(QRY_find2("ClrPart", &VCItemTag));
					valuesCCV[0] = clrVCs1;
					if(QRY_execute(VCItemTag, n_entriesCCV, CCV_entries, valuesCCV, &n_VCtag, &VCtags_found));
					printf("\n n_VCtag count is-------->  : %d \n",n_VCtag);fflush(stdout);
					fprintf(fplog,"\n n_VCtag count is-------->  : %d \n",n_VCtag);

             	if(n_VCtag > 0)
					{
						
						for (ii=0;ii<n_VCtag ;ii++)
						{
						
						//ItemTag = VCtags_found[0];  // make changes here for ---Sort by creation date Item Master and then select latest object tag
						ItemTag = VCtags_found[ii];  // make changes here for ---Sort by creation date Item Master and then select latest object tag
						if(ItemTag!=NULLTAG)
						{
							ITK_CALL(ITEM_ask_latest_rev(ItemTag, &VCItemRev));
							ITK_CALL(AOM_ask_value_string(VCItemRev, "item_id", &ColorVC1));
							printf("\n clrVCs found-------->[%s]",ColorVC1);fflush(stdout);
							fprintf(fplog,"\n clrVCs found-------->[%s]",ColorVC1);

							ITK_CALL(AOM_ask_value_string(VCItemRev,"gov_classification", &gov_classif));
							printf("\n Input_scheme --> : %s",Clrscheme); fflush(stdout);
							fprintf(fplog,"\n Input_scheme --> : %s",Clrscheme);
							printf("\n gov_classif --> : %s",gov_classif); fflush(stdout);
							fprintf(fplog,"\n gov_classif --> : %s",gov_classif);

							if (strstr(gov_classif,Clrscheme)!=NULL)
							{
								printf("\n Need to revise cause Input Scheme & Color VC created with Scheme is same------->[%s]\n",ColorVC1);fflush(stdout);
								fprintf(fp,"Need to revise cause Input Scheme & Color VC created with Scheme is same------->[%s]",ColorVC1);
								fprintf(fplog,"Need to revise cause Input Scheme & Color VC created with Scheme is same------->[%s]",ColorVC1);
                               
							   break ;
							}

						}
						}

					}
					else
					{
						strcpy(SuffixCpy1,"");
						tc_strcat(SuffixCpy1,"A");	
						if(tc_strstr(t5ClSrl,";")!=NULL)
						{
							tc_strcat(SuffixCpy1,Suffix);
						}else {
							tc_strcat(SuffixCpy1,t5ClSrl);
						}
						  ColorVC1=MEM_alloc(20);
						  //clrVCs1=MEM_alloc(20);
						//ITK_CALL(STRNG_replace_str(NonColor,"000",SuffixCpy1,&ColorVC1));
						    //NclrVCSuffix=subString(NonColor,0,8);
						    tc_strcpy(ColorVC1,"");
						    tc_strcpy(ColorVC1,subString(NonColor,0,8));
							tc_strcat(ColorVC1,SuffixCpy1);
							tc_strcat(ColorVC1,subString(NonColor,11,1));

					}

					 printf("\n\t SuffixCpy1: [%s] ",ColorVC1);
					 fprintf(fplog,"\n\t SuffixCpy1: [%s] ",ColorVC1);

					//1. Query Applicable VC SVR from input Scheme , if input SVR is not found in relation goto exit and print error message relation between svr and colour scheme not exist
					//2. Get Colour VC from relation property 'bhm0associationinfo' of scheme and SVR.
					//3. then subString 9th digit to get series A/B/..etc
					
					if (AppliSvrsRelTags != NULLTAG)
					{
						
						//ITK_CALL(AOM_lock(AppliSvrsRelTags));
						//ITK_CALL(AOM_set_value_string(AppliSvrsRelTags,"bhm0associationinfo",ColorVC1));
						//ITK_CALL(AOM_save_without_extensions(AppliSvrsRelTags));
						//ITK_CALL(AOM_unlock(AppliSvrsRelTags));
						
						//ITK_CALL(AOM_UIF_ask_value(AppliSvrsRelTags,"bhm0associationinfo",&SVRAssociatInfo));

						//printf("\n\t SVRAssociatInfo--bhm0associationinfo: [%s] ",SVRAssociatInfo);

						//if (strcmp(SVRAssociatInfo,"NULL")!=0 && strcmp(SVRAssociatInfo,"")!=0)
						if (strcmp(ColorVC1,"NULL")!=0 && strcmp(ColorVC1,"")!=0)
						{
							//VCSuffix=subString(SVRAssociatInfo,8,1);
							VCSuffix=subString(ColorVC1,8,1);

							printf("\t VCSuffix: [%s] ",VCSuffix); fflush(stdout);
							fprintf(fplog,"\t VCSuffix: [%s] ",VCSuffix);

							strcpy(SuffixCpy,"");
							tc_strcat(SuffixCpy,VCSuffix);	
							if(tc_strstr(t5ClSrl,";")!=NULL)
							{
								tc_strcat(SuffixCpy,Suffix);
							}else {
								tc_strcat(SuffixCpy,t5ClSrl);
							}
						}
						else
						{
							printf("\n Applicable SVR's or VC property 'bhm0associationinfo'= [%s] is null, skipping \n\n",SVRAssociatInfo);fflush(stdout);
							fprintf(fp,"Applicable SVR's property 'bhm0associationinfo'= [%s] is null, skipping",SVRAssociatInfo);
							fprintf(fplog,"Applicable SVR's property 'bhm0associationinfo'= [%s] is null, skipping",SVRAssociatInfo);
							createDataset(fp);
							exit(0);
						}
					}
					else
					{
						printf("\n Applicable SVR or VC is not attached to Scheme [%s], skipping \n\n",CpyClrscheme);fflush(stdout);
						fprintf(fp,"Applicable SVR or VC  is not attached to Scheme [%s], skipping",CpyClrscheme);
						fprintf(fplog,"Applicable SVR or VC  is not attached to Scheme [%s], skipping",CpyClrscheme);

						createDataset(fp);
						exit(0);
					}
				}else
				{
					strcpy(SuffixCpy,"");
					tc_strcat(SuffixCpy,"*");
					if(tc_strstr(t5ClSrl,";")!=NULL)
					{
						tc_strcat(SuffixCpy,Suffix);
					}else {
						tc_strcat(SuffixCpy,t5ClSrl);
					}

					printf("\n SuffixCpy => %s \n",SuffixCpy );fflush(stdout);
					fprintf(fplog,"\n SuffixCpy => %s \n",SuffixCpy);
					//ITK_CALL(STRNG_replace_str(NonColor,"000",SuffixCpy,&ColorVC));
					ColorVC=MEM_alloc(20);
					 tc_strcpy(ColorVC,"");
					 tc_strcpy(ColorVC,subString(NonColor,0,8));
					 tc_strcat(ColorVC,SuffixCpy);
					 tc_strcat(ColorVC,subString(NonColor,11,1));
					printf("\n ColorVC is -------> %s",ColorVC);fflush(stdout);
					fprintf(fplog,"\n ColorVC is -------> %s",ColorVC);

					if(QRY_find2("ClrPart", &VCItemTag));
					valuesCCV[0] = ColorVC;
					if(QRY_execute(VCItemTag, n_entriesCCV, CCV_entries, valuesCCV, &n_VCtag, &VCtags_found));
					printf("\n n_VCtag count is-------->  : %d \n",n_VCtag);fflush(stdout);
					fprintf(fplog,"\n n_VCtag count is-------->  : %d \n",n_VCtag);

					if(n_VCtag > 0)
					{
						//ItemTag = VCtags_found[0];  // make changes here for ---Sort by creation date Item Master and then select latest object tag
						ItemTag = VCtags_found[n_VCtag-1];  // make changes here for ---Sort by creation date Item Master and then select latest object tag
						if(ItemTag!=NULLTAG)
						{
							ITK_CALL(ITEM_ask_latest_rev(ItemTag, &VCItemRev));
							ITK_CALL(AOM_ask_value_string(VCItemRev, "item_id", &clrVCs));
							printf("\n clrVCs found-------->[%s]",clrVCs);fflush(stdout);
							fprintf(fplog,"\n clrVCs found-------->[%s]",clrVCs);

							ITK_CALL(AOM_ask_value_string(VCItemRev,"gov_classification", &gov_classif));
							printf("\n Input_scheme --> : %s",Clrscheme); fflush(stdout);
							fprintf(fplog,"\n Input_scheme --> : %s",Clrscheme);
							printf("\n gov_classif --> : %s",gov_classif); fflush(stdout);
							fprintf(fplog,"\n gov_classif --> : %s",gov_classif);

							if (strstr(gov_classif,Clrscheme)!=NULL)
							{
								printf("\n Need to revise cause Input Scheme & Color VC created with Scheme is same------->[%s]\n",clrVCs);fflush(stdout);
								fprintf(fp,"Need to revise cause Input Scheme & Color VC created with Scheme is same------->[%s]",clrVCs);
								fprintf(fplog,"Need to revise cause Input Scheme & Color VC created with Scheme is same------->[%s]",clrVCs);
								createDataset(fp);
								exit(0);
							}else
							{
								clrVCSuffix=subString(clrVCs,8,1);
								printf("\n clrVCSuffix is-------->[%s]",clrVCSuffix);fflush(stdout);
								fprintf(fplog,"\n clrVCSuffix is-------->[%s]",clrVCSuffix);


								first_char = clrVCSuffix[0];
								printf("\n ASCII of Ist CHAR is 1111=> %c = %d ",clrVCSuffix,first_char);
								fprintf(fplog,"\n ASCII of Ist CHAR is 1111=> %c = %d ",clrVCSuffix,first_char);

								first_char = first_char + 1; 
								printf("\n ASCII of Ist CHAR is %d ",first_char);	//66
								fprintf(fplog,"\n ASCII of Ist CHAR is %d ",first_char);

								char c = first_char;
								printf("\n t5NxtSrl ALPHABETS CHECK11 ===> %c ",c);fflush(stdout); //B
								fprintf(fplog,"\n t5NxtSrl ALPHABETS CHECK11 ===> %c ",c);

								char str1[2] = {c , '\0'};							
								printf("\n t5NxtSrl ALPHABETS CHECK22 ===> %s ",str1);fflush(stdout);
								fprintf(fplog,"\n t5NxtSrl ALPHABETS CHECK22 ===> %s ",str1);

								strcpy(SuffixCpy,"");
								tc_strcat(SuffixCpy,str1);
								if(tc_strstr(t5ClSrl,";")!=NULL)
								{
									tc_strcat(SuffixCpy,Suffix);
								}else {
									tc_strcat(SuffixCpy,t5ClSrl);
								}													
							}
						}
					}	
					else
					{
						strcpy(SuffixCpy,"");
						tc_strcat(SuffixCpy,"B");
						if(tc_strstr(t5ClSrl,";")!=NULL)
						{
							tc_strcat(SuffixCpy,Suffix);
						}else {
							tc_strcat(SuffixCpy,t5ClSrl);
						}
					}
				}			
				
				printf("\n new SuffixCpy => %s",SuffixCpy );fflush(stdout);
				fprintf(fplog,"\n new SuffixCpy => %s",SuffixCpy);
				//ITK_CALL(STRNG_replace_str(NonColor,"000",SuffixCpy,&ColorVC));
				ColorVC=MEM_alloc(20);
				tc_strcpy(ColorVC,"");
				tc_strcpy(ColorVC,subString(NonColor,0,8));
				tc_strcat(ColorVC,SuffixCpy);
				tc_strcat(ColorVC,subString(NonColor,11,1));
				printf("\n new ColorVC is -------> %s",ColorVC);fflush(stdout);
				fprintf(fplog,"\n new ColorVC is -------> %s",ColorVC);
							
				if(QRY_find2("ClrPart", &VCItemTag));
				valuesCCV[0] = ColorVC;
				if(QRY_execute(VCItemTag, n_entriesCCV, CCV_entries, valuesCCV, &n_VCtag, &VCtags_found));
				printf("\n new n_VCtag count is-------->: %d \n",n_VCtag);fflush(stdout);
				fprintf(fplog,"\n new n_VCtag count is-------->: %d \n",n_VCtag);
				
				if(n_VCtag > 0)
				{
					ITK_CALL(ITEM_find_item(ColorVC,&VCtag))
					ITK_CALL(ITEM_ask_latest_rev(VCtag, &VCItemRev));
					
					ITK_CALL(WSOM_ask_release_status_list(VCItemRev, &CRevCnt, &RlzStus_CVC_list));
					printf("\n CRevCnt is --> : %d\n",CRevCnt); fflush(stdout);
					fprintf(fplog,"\n CRevCnt is --> : %d\n",CRevCnt);
					if(CRevCnt > 0)
					{
						for(ht = 0; ht < CRevCnt; ht++)
						{
							if(AOM_ask_value_string (RlzStus_CVC_list[ht], "object_name", &CRelStatusM)==ITK_ok)
							printf("\t Release status is:=>%s\n",CRelStatusM); fflush(stdout);
							if (tc_strstr(CRelStatusM,"T5_LcsErcRlzd")!=NULL|| tc_strstr(CRelStatusM,"ERC Released")!=NULL)
							{
								ITEM_copy_rev(VCItemRev,NULL,&NewVCRevTag);

								 VCItemRev=NULLTAG;
						         VCItemRev=NewVCRevTag;
								printf("\t Color VCs :[%s] is already in Release [NEED TO REVISE]:=>%s\n",ColorVC,CRelStatusM); fflush(stdout);
								fprintf(fp,"Color VCs :[%s] is already in Release [NEED TO REVISE]:=>%s",ColorVC,CRelStatusM);
								fprintf(fplog,"Color VCs :[%s] is already in Release [NEED TO REVISE]:=>%s",ColorVC,CRelStatusM);
								//createDataset(fp);
								//exit(0);
							}
						}
					}

					//CREATE BOMView & BVR IF NOT AVAILABLE
					ifail =ITEM_list_bom_views(VCtag,&bv_clrcount, &clr_bvs);
					printf("\n bv_clrcnt :%d..",bv_clrcount);fflush(stdout);
					fprintf(fplog,"\n bv_clrcnt :%d..",bv_clrcount);
					if (bv_clrcount)
					{
						VCclrbv = clr_bvs[0];
						MEM_free(clr_bvs);
					}else{
						ifail = PS_create_bom_view( NULLTAG, "", "", VCtag,&VCclrbv );
						ifail = AOM_save_without_extensions( VCclrbv );
						ifail = AOM_save_without_extensions( VCtag );
						ifail = AOM_unlock( VCtag );
						printf("\n inside PS_create_bom_view..");fflush(stdout);
						fprintf(fplog,"\n inside PS_create_bom_view..");
					}

					if (VCItemRev!=NULLTAG)
					{
						ifail = ITEM_rev_list_bom_view_revs(VCItemRev,&clr_bvrcnt, &clrbvrs);
						printf("\n clr_bvrcnt :%d..",clr_bvrcnt);fflush(stdout);
						if (clr_bvrcnt)
						{
							VCclrbvr = clrbvrs[0];
							MEM_free(clrbvrs);
						}else{
							ifail = PS_create_bvr( VCclrbv, "", "", false, VCItemRev,&VCclrbvr);
							if(VCclrbvr !=NULLTAG)
							{								
								ifail = AOM_save_without_extensions( VCclrbvr);
								ifail = AOM_save_without_extensions( VCItemRev );
								ifail = AOM_unlock( VCItemRev );
								printf("\n inside  PS_create_bvr..");fflush(stdout);
								fprintf(fplog,"\n inside  PS_create_bvr..");
							}
						}
					}
					
					printf("\n Color VC is Created------------------------------------>\n\n"); fflush(stdout);
					fprintf(fplog,"\n Color VC is Created------------------------------------>\n\n");
					ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&CCVSolutionItem));
					if (CCVSolutionItem!=NULLTAG)
					{
						ITK_CALL(AOM_set_value_string(VCItemRev,"gov_classification",""));
						ITK_CALL(AOM_set_value_string(VCItemRev,"gov_classification",SchDataToGov));
						ITK_CALL(GRM_find_relation(taskRevTag,VCItemRev,CCVSolutionItem,&CCVItemExist));					
						if (CCVItemExist==NULLTAG)
						{
							ITK_CALL(GRM_create_relation(taskRevTag,VCItemRev,CCVSolutionItem,NULLTAG,&CCVreltask));
							ITK_CALL(GRM_save_relation(CCVreltask)); 
							ITK_CALL(AOM_load(CCVreltask));
							ITK_CALL(AOM_refresh(CCVreltask,0));
						}else
						printf("\n Color VC already present with DML.......\n");fflush(stdout);
						fprintf(fplog,"\n Color VC already present with DML.......\n");
					}
				}else
				{	
					//CREATE COLOR PART IF IS NOT AVAILABLE IN TCE
					printf("\n CREATE COLOR PART IF IS NOT AVAILABLE IN TC:\n"); fflush(stdout);
					fprintf(fplog,"\n CREATE COLOR PART IF IS NOT AVAILABLE IN TC:\n");
					ColorVCDesc=MEM_alloc(50);
					//ColorVC=MEM_alloc(20);
					strcpy(ColorVCDesc,"");
					strcat(ColorVCDesc,ColourIDSchm);
					strcat(ColorVCDesc,"-");
					strcat(ColorVCDesc,t5object_desc);
					printf("\n Description for colour VC   : %s\n",ColorVCDesc); fflush(stdout);
					fprintf(fplog,"\n Description for colour VC   : %s\n",ColorVCDesc);

					ITK_CALL(ITEM_create_item(ColorVC,ColorVC,"T5_ClrPart",default_empty_to_A(ClrRevSeq),&item,&rev));
					setAttributesOnDesign(&item,ColorVC,ColorVCDesc,"4");					
					setAttributesOnDesignRev(&rev,ColorVC,item_revision_id_int,ColorVCDesc,t5_ColourInd,t5PrtCatCd,ColourID,t5CoatedS,t5_PartStatus,t5_DesignGrp,t5_ProjectCode,t5_DocRemarks,t5_DrawingInd,t5_PartType,t5_PartCode,t5_AhdMakeBuyIndicator,t5_PunPCBUMakeBuyIndicator,t5_PunMakeBuyIndicator,t5_DwdMakeBuyIndicator,t5itemid);
					ITK_CALL(CreateReleasestatus(rev));
					ITK_CALL(AssignProject(rev,t5_ProjectCode));
					printf("\n sClrSerSuf AliasOnClrVC------->  : %s\n",sClrSerSuf); fflush(stdout);
					fprintf(fplog,"\n sClrSerSuf AliasOnClrVC------->  : %s\n",sClrSerSuf);
					if((tc_strcmp(sClrSerSuf,"NULL")!=0))
					{
						ITK_CALL(setAliasOnClrVC(&rev,sClrSerSuf,ColourIDSchm,t5object_desc));
						printf("\n setAliasOnClrVC function calling--------------->%s::%s",sClrSerSuf,ColourIDSchm);fflush(stdout);
						fprintf(fplog,"\n setAliasOnClrVC function calling--------------->%s::%s",sClrSerSuf,ColourIDSchm);
					}
					
					ITK_CALL(AOM_set_ownership(rev,user_tag,group));
					ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&CCVSolutionItem));
					if (CCVSolutionItem!=NULLTAG)
					{
						ITK_CALL(GRM_find_relation(taskRevTag,rev,CCVSolutionItem,&CCVItemExist));					
						if (CCVItemExist==NULLTAG)
						{
							ITK_CALL(GRM_create_relation(taskRevTag,rev,CCVSolutionItem,NULLTAG,&CCVreltask));
							ITK_CALL(GRM_save_relation(CCVreltask)); 
							ITK_CALL(AOM_load(CCVreltask));
							ITK_CALL(AOM_refresh(CCVreltask,0));
						}
					}

					ITK_CALL(GRM_find_relation_type("TC_Is_Represented_By",&CCVRelationFind));
					if (CCVRelationFind!=NULLTAG)
					{	
						ITK_CALL(GRM_create_relation(rev,NVCRlzRev,CCVRelationFind,NULLTAG,&CCVObject));
						ITK_CALL(GRM_save_relation(CCVObject)); 
						ITK_CALL(AOM_load(CCVObject));
						ITK_CALL(AOM_refresh(CCVObject,0));
						printf("\nRelation Created Successfully");fflush(stdout);	
						fprintf(fplog,"\nRelation Created Successfully");
					}

					ifail =ITEM_list_bom_views(item,&bv_clrcount, &clr_bvs);
					printf("\n bv_clrcnt :%d..",bv_clrcount);fflush(stdout);
					fprintf(fplog,"\n bv_clrcnt :%d..",bv_clrcount);
					if (bv_clrcount)
					{
						VCclrbv = clr_bvs[0];
						MEM_free(clr_bvs);
					}else{
						ifail = PS_create_bom_view( NULLTAG, "", "", item,&VCclrbv );
						ifail = AOM_save_without_extensions( VCclrbv );
						ifail = AOM_save_without_extensions( item );
						ifail = AOM_unlock( item );
						printf("\n inside PS_create_bom_view..");fflush(stdout);
						fprintf(fplog,"\n inside PS_create_bom_view..");
					}

					if (rev!=NULLTAG)
					{
						ifail = ITEM_rev_list_bom_view_revs(rev,&clr_bvrcnt, &clrbvrs);
						printf("\n clr_bvrcnt :%d..",clr_bvrcnt);fflush(stdout);
						fprintf(fplog,"\n clr_bvrcnt :%d..",clr_bvrcnt);
						if (clr_bvrcnt)
						{
							VCclrbvr = clrbvrs[0];
							MEM_free(clrbvrs);
						}else{
							ifail = PS_create_bvr( VCclrbv, "", "", false, rev,&VCclrbvr);
							if(VCclrbvr !=NULLTAG)
							{								
								ifail = AOM_save_without_extensions( VCclrbvr);
								ifail = AOM_save_without_extensions( rev );
								ifail = AOM_unlock( rev );
								printf("\n inside  PS_create_bvr..");fflush(stdout);
								fprintf(fplog,"\n inside  PS_create_bvr..");
							}
						}
					}
				}
			}else
			{
				fprintf(fp,"Please check Release status is:  " );fflush(stdout);
				fprintf(fplog,"Please check Release status is:  ");
				createDataset(fp);
				goto END;
			}		
			
			printf("\n\t Colour Scheme Release Status------->%d\n", RlzRevFlag); fflush(stdout);
			fprintf(fplog,"\n\t Colour Scheme Release Status------->%d\n", RlzRevFlag);
			if((RlzRevFlag > 0) && (VehicleRlzRev!=NULLTAG))
			{
				ITK_CALL(BOM_create_window(&bom_window));
				//ITK_CALL(CFM_find("APLC Release and above", &rule)); //comented BY GR 060223
				ITK_CALL(CFM_find("ERC release and above", &rule));
				ITK_CALL(BOM_set_window_config_rule(bom_window, rule ));
				//PIE_find_closure_rules("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule);
				PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER, &rulefound, &closurerule);
				if (rulefound > 0)
				{
					close_tag = closurerule[0];
					printf ("closure rule found \n");fflush(stdout);
				}
				BOM_window_set_closure_rule(window,close_tag, 0, rulename,rulevalue);

				ITK_CALL(BOM_set_window_pack_all(bom_window, TRUE));
				ITK_CALL(BOM_set_window_top_line(bom_window , NULLTAG, VehicleRlzRev, NULLTAG, &top_line));
				ITK_CALL(BOM_window_show_suppressed (bom_window));
				
				if(top_line!=NULLTAG)
				{
					ITK_CALL(AOM_ask_value_string(top_line, "bl_item_item_id", &bl_Item_id));
					printf("\n Item_id of First level Modules is---------------->%s \n",bl_Item_id); fflush(stdout);
					fprintf(fplog,"\n Item_id of First level Modules is---------------->%s \n",bl_Item_id);
					ITK_CALL(AOM_ask_value_string(top_line, "bl_rev_item_revision_id", &item_Rev_Seq));
					Item_Rev =  tc_strtok(item_Rev_Seq,";");
					Item_Seq = tc_strtok(NULL,";");
					ITK_CALL(AOM_ask_value_int(top_line, "bl_level_starting_0", &NonClrPartlevel ));
					ITK_CALL(AOM_ask_value_string(top_line, "bl_T5_ClrPartRevision_t5_PrtCatCode", &t5_PrtCatCd ));
					printf("\n NonColor Module Compcode is--> : %s \n",t5_PrtCatCd); fflush(stdout);
					fprintf(fplog,"\n NonColor Module Compcode is--> : %s \n",t5_PrtCatCd);
					ITK_CALL(AOM_ask_value_string(top_line, "bl_T5_ClrPartRevision_t5_ColourInd", &t5ColourInd ));
					printf("\n NonColor Module ColourInd is--> : %s \n",t5ColourInd); fflush(stdout);
					fprintf(fplog,"\n NonColor Module ColourInd is--> : %s \n",t5ColourInd);
					if((strlen(t5_PrtCatCd)>0) && (tc_strcmp(t5ColourInd,"Y")==0))
					{	
						ITK_CALL(QRY_find2("DesignRevision Sequence", &queryds));
						itemRevSeq2 = NULL;
						itemRevSeq2=(char *) MEM_alloc(32);
						tc_strcpy(itemRevSeq2,Item_Rev);
						tc_strcat(itemRevSeq2,"?");
						tc_strcat(itemRevSeq2,Item_Seq);
						printf("\n itemRevSeq2 ===> %s",itemRevSeq2);fflush(stdout);
						fprintf(fplog,"\n itemRevSeq2 ===> %s",itemRevSeq2);

						qry_valuesds[0] = itemRevSeq2;
						qry_valuesds[1] = bl_Item_id;									
						ITK_CALL(QRY_execute(queryds, n_entries, qry_entriesds, qry_valuesds, &ds_tags_found, &itemrevdsclass));
						printf("\n Non-Color found in DB is :: %d", ds_tags_found);fflush(stdout);
						fprintf(fplog,"\n Non-Color found in DB is :: %d", ds_tags_found);

						if(ds_tags_found > 0)
						{
							latestrev=NULLTAG;
							latestrev=itemrevdsclass[0];

							if(AOM_ask_value_string(latestrev, "item_id", &t5itemid)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "current_revision_id", &t5revision_id)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "object_desc", &t5object_desc)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_ColourInd", &t5_ColourInd)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_PartStatus", &t5_PartStatus)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_DesignGrp", &t5_DesignGrp)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_ProjectCode", &t5_ProjectCode)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_DocRemarks", &t5_DocRemarks)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_DrawingInd", &t5_DrawingInd)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_PartType", &t5_PartType)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_PartCode", &t5_PartCode)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_AhdMakeBuyIndicator", &t5_AhdMakeBuyIndicator)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_PunPCBUMakeBuyIndicator", &t5_PunPCBUMakeBuyIndicator)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_PunMakeBuyIndicator", &t5_PunMakeBuyIndicator)!=ITK_ok);
							if(AOM_ask_value_string(latestrev, "t5_DwdMakeBuyIndicator", &t5_DwdMakeBuyIndicator)!=ITK_ok);
							if(RES_is_checked_out(latestrev,&checkout)!=ITK_ok);

							printf("\n t5itemid/t5revision_id & t5PrtCatCd: %s/%s %s\n",t5itemid,t5revision_id,t5PrtCatCd); fflush(stdout);
							fprintf(fplog,"\n t5itemid/t5revision_id & t5PrtCatCd: %s/%s %s\n",t5itemid,t5revision_id,t5PrtCatCd);
							printf("\n Module Checked-out Status :=> [%d]",checkout);fflush(stdout);
							fprintf(fplog,"\n Module Checked-out Status :=> [%d]",checkout);

							if(checkout==0)
							{	
								if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel)!=ITK_ok);
								if (SchmWithCmpcdRel!=NULLTAG)
								{
									if(GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok);
									printf("\n Comp Code Cmpcount for Color Scheme : %d\n",Cmpcount); fflush(stdout);
									fprintf(fplog,"\n Comp Code Cmpcount for Color Scheme : %d\n",Cmpcount);
									if(Cmpcount > 0)
									{
										for(g1=0;g1<Cmpcount;g1++ )
										{													
											if(CmpCodeObj) CmpCodeObj=NULLTAG;
											CmpCodeObj=CmpCodeOfClrScheme[g1];
											if(AOM_ask_value_string(CmpCodeObj, "t5_PrtCatCode", &CmpCodeCmp)!=ITK_ok);
											if(tc_strcmp(t5PrtCatCd,CmpCodeCmp)==0)
											{
												printf("\n CmpCodeCmp & t5PrtCatCd is --> : %s = %s ---Matched ",CmpCodeCmp,t5PrtCatCd); fflush(stdout);
												fprintf(fplog,"\n CmpCodeCmp & t5PrtCatCd is --> : %s = %s ---Matched ",CmpCodeCmp,t5PrtCatCd);
												if(AOM_ask_value_string(CmpCodeObj, "t5_ClSrl", &t5ClSrl )!=ITK_ok);
												printf("\n t5ClSrl --> : %s",t5ClSrl); fflush(stdout);
												fprintf(fplog,"\n t5ClSrl --> : %s",t5ClSrl);
												if(tc_strstr(t5ClSrl,";")!=NULL)
												{															
													Suffix =  strtok(t5ClSrl,";");
													printf("\n Suffix --> : %s",Suffix); fflush(stdout);
												    fprintf(fplog,"\n Suffix --> : %s",Suffix);
													ColourID  =  strtok(NULL,";");
													printf("\n ColourID --> : %s",ColourID); fflush(stdout);
													fprintf(fplog,"\n ColourID --> : %s",ColourID);
												}else{
													Suffix =  strtok(t5ClSrl,",");
													printf("\n Suffix --> : %s",Suffix); fflush(stdout);
													fprintf(fplog,"\n Suffix --> : %s",Suffix);
													ColourID  =  strtok(NULL,",");
													printf("\n ColourID --> : %s \n",ColourID); fflush(stdout);
													fprintf(fplog,"\n ColourID --> : %s \n",ColourID);
												}

												itemRevSeq = NULL;
												itemRevSeq=(char *) MEM_alloc(32);														
												strcpy(itemRevSeq,"");
												strcat(itemRevSeq,t5itemid);
												strcat(itemRevSeq,Suffix);														
												printf("\n Colour Part for Creation---->%s = %s",itemRevSeq,ClrRevSeq);
												fprintf(fplog,"\n Colour Part for Creation---->%s = %s",itemRevSeq,ClrRevSeq);

												if(QRY_find2("ClrPart", &ClrPartTag));
												valuesClrPrt[0] = itemRevSeq;
												if(QRY_execute(ClrPartTag, n_entriesC, qry_entries, valuesClrPrt, &n_tags_found1, &tags_found1));
												printf("\n\n\n ClrPart count is-------->  : %d",n_tags_found1);fflush(stdout);
												fprintf(fplog,"\n\n\n ClrPart count is-------->  : %d",n_tags_found1);

												if(ItemTag1) ItemTag1=NULLTAG;
												if(item) item=NULLTAG;
												if(rev) rev=NULLTAG;

												if(n_tags_found1 > 0)
												{														
													ItemTag1 = tags_found1[0];
													printf("\n\t available in DB---->%s\n",itemRevSeq);fflush(stdout);	
													fprintf(fplog,"\n\t available in DB---->%s\n",itemRevSeq);
													if(ItemTag1!=NULLTAG)
													{
														flg1=0;
														flg1=MultilevelExpantion(ItemTag1,latestrev,ColSchmRevTag,NonClrPartlevel,taskRevTag,user_tag,group);
														if (flg1==-1) {
															goto END;
														}
													}
													
												}else
												{
													/////////////////////////////WebSerFunForClrPart/////////////////////////////////////////////
													printf("\n Color Part is Checking in TCE---------->%s\n",itemRevSeq); fflush(stdout);
													fprintf(fplog,"\n Color Part is Checking in TCE---------->%s\n",itemRevSeq);
													Response = WebSerFunForClrPart(itemRevSeq);
													printf("Color Part checking in TCE :: [%s]",Response);fflush(stdout);
													fprintf(fplog,"Color Part checking in TCE :: [%s]",Response);

													if(tc_strcmp(Response,"NA")!=0)   
													{
														//fprintf(output,"%s\n",itemRevSeq);
														printf("Color Part not found  in TCUA , Please migrate it..%s",itemRevSeq);fflush(stdout);
														fprintf(fp,"Color Part not found  in TCUA , Please migrate it..%s\n", itemRevSeq);
														fprintf(fplog,"Color Part not found  in TCUA , Please migrate it..%s\n", itemRevSeq);
														createDataset(fp);
														goto END;
													}

													if(tc_strstr(itemRevSeq,"##")!=NULL)
													{
														//fprintf(output,"%s\n",itemRevSeq);
														printf("Color Part not found  in TCUA , Please migrate it..%s",itemRevSeq);fflush(stdout);
														fprintf(fp,"Color Part not found  in TCUA , Please migrate it..%s\n", itemRevSeq);
														fprintf(fplog,"Color Part not found  in TCUA , Please migrate it..%s\n", itemRevSeq);
														createDataset(fp);
														goto END;
													}

													//CREATE COLOR PART IF IS NOT AVAILABLE IN TCE
													ITK_CALL(ITEM_create_item(itemRevSeq,itemRevSeq,"T5_ClrPart",default_empty_to_A(ClrRevSeq),&item,&rev));
													setAttributesOnDesign(&item,itemRevSeq,t5object_desc,"4");					
													setAttributesOnDesignRev(&rev,itemRevSeq,item_revision_id_int,t5object_desc,t5_ColourInd,t5PrtCatCd,ColourID,t5CoatedS,t5_PartStatus,t5_DesignGrp,t5_ProjectCode,t5_DocRemarks,t5_DrawingInd,t5_PartType,t5_PartCode,t5_AhdMakeBuyIndicator,t5_PunPCBUMakeBuyIndicator,t5_PunMakeBuyIndicator,t5_DwdMakeBuyIndicator,bl_Item_id);
													ITK_CALL(CreateReleasestatus(rev));
													ITK_CALL(AssignProject(rev,t5_ProjectCode));
													ITK_CALL(AOM_set_ownership(rev,user_tag,group));
													printf("\nproperty Value set...!!");fflush(stdout);
													fprintf(fplog,"\nproperty Value set...!!");

													//FIND BVR for COLOR PART REVISION
													if(item!=NULLTAG)
													{
														ITK_CALL(PS_create_bom_view(NULLTAG, "", "", item,&clrbv));
														ITK_CALL(AOM_save_without_extensions(clrbv));
														ITK_CALL(AOM_save_without_extensions(item));
														ITK_CALL(AOM_unlock(item));
														ITK_CALL(ITEM_ask_latest_rev(item,&Clrrev1));
														ITK_CALL(PS_create_bvr(clrbv, "", "", false, Clrrev1,&clrbvr));
														if(clrbvr !=NULLTAG)
														{								
															ITK_CALL(AOM_save_without_extensions(clrbvr));
															ITK_CALL(AOM_save_without_extensions(Clrrev1 ));
															ITK_CALL(AOM_unlock(Clrrev1 ));
															printf( "\n inside  PS_create_bvr..");fflush(stdout);
															fprintf(fplog,"\n inside  PS_create_bvr..");
														}														
													}

													//ATTACHED COLOR PART TO THE DML 00 TASK
													ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&RelSolutionItem));
													if (RelSolutionItem!=NULLTAG)
													{
														ITK_CALL(GRM_list_primary_objects_only(rev,RelSolutionItem,&TskCntClr,&TskSOClr));
														if(TskCntClr > 0) {
															printf("\n Color Part is already attached to other task---------->%s",itemRevSeq); fflush(stdout);																		
														}else
														{
															ITK_CALL(GRM_create_relation(taskRevTag,rev,RelSolutionItem,NULLTAG,&reltask));
															ITK_CALL(GRM_save_relation(reltask));
															ITK_CALL(AOM_load(reltask));
															ITK_CALL(AOM_refresh(reltask,0));
															printf("\nRelation Created Successfully with CMHasSolutionItem\n");fflush(stdout);																
														    fprintf(fplog,"\nRelation Created Successfully with CMHasSolutionItem\n");
														}
													}
															
													//CREATE COLOR & NON-COLOR RELATION & ATTACHED COLOR PART TO TOP SVR LINE
													ITK_CALL(GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind));
													if (tRelationFind!=NULLTAG)
													{
														ITK_CALL(GRM_find_relation(rev,latestrev,tRelationFind,&tRelationExist));					
														if (tRelationExist==NULLTAG)
														{
															ITK_CALL(GRM_create_relation(rev,latestrev,tRelationFind,NULLTAG,&Rel_task));
															ITK_CALL(GRM_save_relation(Rel_task)); 
															ITK_CALL(AOM_load(Rel_task));
															ITK_CALL(AOM_refresh(Rel_task,0));
															printf("\nRelation Created Successfully\n");fflush(stdout);
															fprintf(fplog,"\nRelation Created Successfully\n");
														}
													}
													
													if(VCclrbvr!=NULLTAG)
													{
														ITK_CALL(AOM_lock(VCclrbvr));	
														ITK_CALL(PS_create_occurrences(VCclrbvr, rev, NULLTAG,1, &occs ));
														ITK_CALL(AOM_save_without_extensions(VCclrbvr));
														ITK_CALL(AOM_unlock(VCclrbvr));
														ITK_CALL(AOM_refresh(VCclrbvr,0));
														printf("\n Color Vehicle is attached to bvr of Color VC--------------->\n");fflush(stdout);											
													    fprintf(fplog,"\n Color Vehicle is attached to bvr of Color VC--------------->\n");
													}
													
													//CALL MULTILEVEL EXPANSION FUNCTION
													if(item!=NULLTAG)
													{
														flg1=0;
														flg1=MultilevelExpantion(item,latestrev,ColSchmRevTag,NonClrPartlevel,taskRevTag,user_tag,group);
														if (flg1==-1) {
															goto END;
														}
													}
												}
												break;
											}
										}
									}
								}
							}
						}
					}
				}		
			}else
			{	
				printf("\n Colour Scheme OR Vehicle is not Release-------------------->"); fflush(stdout);
				fprintf(fp,"Colour Scheme OR Vehicle is not Release-------------------->");	
				fprintf(fplog,"Colour Scheme OR Vehicle is not Release-------------------->");
				createDataset(fp);
				exit(0);
			}

		}else { 
			printf("\n PLATFROM IS INVALID-------->"); fflush(stdout); 
			fprintf(fplog,"\n PLATFROM IS INVALID-------->");
		}

		
	END:
		printf("\n NON-COLOR VC Problem-------->\n"); fflush(stdout);
	   fprintf(fplog,"\n NON-COLOR VC Problem-------->\n");

	  char *update = NULL;
			   //ITK_CALL(AOM_set_value_string(ColSchmRevTag,"t5_ColBomGen","Y"));
			   //ITK_CALL(AOM_save_without_extensions(ColSchmRevTag));
			  // ITK_CALL(AOM_unlock(ColSchmRevTag));
			  // AOM_ask_value_string(ColSchmRevTag,"gov_classification",&update);
			printf("Colour BOM has been generated successfully :");
			fprintf(fplog,"Colour BOM has been generated successfully :");
         fclose(fplog);
		//if(output)
		//{
		//	fclose(output); output=NULL;
		//}
		printf("\n -------->\n"); fflush(stdout);
		ITK_exit_module(true);
		
		return status;
	}


	//static int my_compare_function (tag_t line_1, tag_t line_2, void * client_data)
	//{
	//	/* returns strcmp style -1/0/+1 according to whether line_1 and line_2 sort <, = or > */
	//	char *seq1, *seq2;
	//	int ifail, result;
	//	(void)client_data;
	//	ifail = BOM_line_ask_attribute_string (line_1, seqno_attribute, &seq1);
	//	CHECK_FAIL;
	//	ifail = BOM_line_ask_attribute_string (line_2, seqno_attribute, &seq2);
	//	CHECK_FAIL;
	//	if (seq1 == NULL || seq2 == NULL)
	//	result = 0;
	//	else
	//	result = strcmp (seq2, seq1);  /* we are being silly and doing a reverse sort */
	//	/* note:  the default sort function compares Item names if the sequence numbers sort equal
	//	but this is just an example for fun,  so we won't bother with that bit
	//	*/
	//	MEM_free (seq1);
	//	MEM_free (seq2);
	//	return result;
	//}

	//static void initialise (void)
	//{
	//	int ifail;
	//	printf("\nAuto Login--\n",ifail);
	//	/* <kc> pr#397778 July2595 exit if autologin() fail */
	//	if ((ifail = ITK_auto_login()) != ITK_ok)
	//	fprintf(stderr,"Login fail !!: Error code = %d \n",ifail);
	//	CHECK_FAIL;
   //
	//	/* these tokens come from bom_attr.h */
	//	initialise_attribute (bomAttr_lineName, &name_attribute);
	//	initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
	//	//initialise_attribute (bomAttr_occQty, &qunt_attribute);
	//	//initialise_attribute (bomAttr_JTDatasetTag , &refjt_attribute);
	//	ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
	//	CHECK_FAIL;
	//	ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
	//	CHECK_FAIL;
	//	ifail = BOM_line_look_up_attribute (bomAttr_JTDatasetTag, &refjt_attribute);
	//	CHECK_FAIL;
	//}
   //
	//static void initialise_attribute (char *name,  int *attribute)
	//{
	//	int ifail, mode;
	//
	//	ifail = BOM_line_look_up_attribute (name, attribute);
	//	CHECK_FAIL;
	//	ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
	//	CHECK_FAIL;
	//	if (mode != BOM_attribute_mode_string)
	//	  { printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode);
	//		fprintf(fp,"Help,  attribute %s has mode %d,  I want a string\n", name, mode);
	//
	//		exit(0);
	//	  }
	//}
