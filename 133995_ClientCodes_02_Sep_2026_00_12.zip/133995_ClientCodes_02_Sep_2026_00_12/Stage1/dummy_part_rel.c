/******************************************************************************
* CVS: $Id
*
* COPYRIGHT 2008  MNM.  ALL RIGHTS RESERVED
*
*
*------------------------------------------------------------------------------
* Filename		: 
* Description	: 
* Module       	:	        
* Since		    :    
* ENVIRONMENT	: C++, ITK
* History       :
*------------------------------------------------------------------------------
*    Date         	   Name						Description of Change 	   		          

* -----------------------------------------------------------------------------
*
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001
#define MAX_LINE_LEN 1024

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
		  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
}

int ITK_CALL(int Ifail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);fflush(stdout);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

FILE  *output = NULL;

int x=0;
int PartSearStat = 0;
int temp2 =0;
int count =0;
int Counter =0;

int CreateEffctivity(tag_t itemrev, char *FromDate, char *ToDate, char *lifeCycleS)
{
	printf("\n------Processing to create effectivity------- \n");

	tag_t release_status = NULLTAG;
	char *ReleaseStatus = NULL;
	logical retain_released_date = false;
	logical is_v7;
	char FrmNextDate[20] = {0};
	char ToNextDate[20] = {0};
	date_t test_date_1;
	date_t DayTommorow;
	date_t test_date_2;
	date_t *start_end_date = NULL;
	tag_t eff_d = NULLTAG;

	int ifail = 0;
	char *lcsToset = "T5_LcsErcRlzd";
	tag_t class_id = NULLTAG;
	char *class_name = NULL;

	int status_count = 0;
	int status_countnew = 0;
	int ss = 0;
	int StatusFlg = 0;
	tag_t *status_list = NULLTAG;
	tag_t *status_list_Neww = NULLTAG;
	tag_t status_list_One = NULLTAG;

	lcsToset = (char *)MEM_alloc(20 * sizeof(char *));

	
	if (tc_strcmp(lifeCycleS, "T5_LcsErcRlzd") == 0)
	{
		
			strcpy(lcsToset, "T5_LcsErcRlzd");
		
		WSOM_ask_release_status_list(itemrev, &status_count, &status_list);
		printf("Existing Status_count: %d\n", status_count);
		if (status_count == 0) /* No Status, so the Item is not yet Released */
		{
			printf("No Existing Status, so the Item is not yet Released \n");
		}
		else
		{
			for (ss = 0; ss < status_count; ss++)
			{
				ITK_CALL(AOM_ask_value_string(status_list[ss], "object_name", &class_name));
				printf("\n Existing Status : %s\n", class_name);
				if (strcmp(class_name, lcsToset) == 0)
				{
					printf("\nstatus flag is greater than 0 and ERC Released \n");
					StatusFlg++;
				}
			}
		}

		printf("Out from loop\n");
		// if(StatusFlg != 0) return ITK_ok;
		printf("Stamping Releasing Item\n");
		printf("FromDate : [%s]\n", FromDate);
		printf("ToDate : [%s]\n", ToDate);
		if ((strcmp(FromDate, "-") == 0) || (strcmp(ToDate, "-") == 0))
			return 0;

		WSOM_ask_effectivity_mode(&is_v7);
		printf("v7 Effectivity is:%d\n", is_v7);

		ITK_string_to_date(FromDate, &test_date_1);
		printf("\n222222222222222222222");fflush(stdout);
		ITK_string_to_date(ToDate, &test_date_2);
		printf("\n333333333333333333333");fflush(stdout);

		WSOM_ask_release_status_list(itemrev, &status_countnew, &status_list_Neww);
		// ITK_CALL(WSOM_ask_release_status_list(itemrev,&status_count,&status_list));
		printf("Existing status_countnew New: %d\n", status_countnew);
		status_list_One = status_list_Neww[0];

		printf("test after conversion ----------\n");
		start_end_date = (date_t *)MEM_alloc(sizeof(date_t) * 2);

		start_end_date[0] = test_date_1;
		start_end_date[1] = test_date_2;

		WSOM_status_clear_effectivities(status_list_One);
		WSOM_effectivity_create_with_dates(status_list_One, NULLTAG, 2, start_end_date, EFFECTIVITY_closed, &eff_d);
		AOM_save(eff_d);
		AOM_save(status_list_One);
		AOM_refresh(status_list_One, 0);
		printf("Effectivity Stamping Completed : %s\n", FrmNextDate);
		
	}

	return ifail;
}

void getCurrentDateTime(char CurrentAccessDate[20])
{
	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(CurrentAccessDate,pAccessDate);
	printf("\n CurrentAccessDate:%s\n",CurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

int update_release_date(tag_t obj_tag, date_t date_rel)
{
	printf("\n Function(update_release_date) Start..!!\n");
	int ifail = ITK_ok;
	tag_t attr_id1 = NULLTAG;
	char *dateReleasedtest = NULL;

	printf("\n ~~~~~~~~ U P D A T I O N   S T A R T ~~~~~~~~\n");
	fflush(stdout);
	ITK_CALL(AOM_refresh(obj_tag, POM_modify_lock));
	printf("\n Lock..!!\n");
	fflush(stdout);
	ITK_CALL(POM_attr_id_of_attr("date_released", "ReleaseStatus", &attr_id1));
	printf("\n Attr_Id:  [%d]", attr_id1);
	fflush(stdout);
	printf("\n Property Name Tag Found..!!\n");
	fflush(stdout);
	ITK_CALL(POM_set_attr_date(1, &obj_tag, attr_id1, date_rel));
	printf("\n Set Property Value..!!\n");
	fflush(stdout);
	ITK_CALL(POM_save_instances(1, &obj_tag, true));
	printf("\n Save...!!\n");
	fflush(stdout);
	ITK_CALL(AOM_refresh(obj_tag, POM_no_lock));
	printf("\n Unlock..!!\n");
	fflush(stdout);

	ITK_CALL(AOM_UIF_ask_value(obj_tag, "date_released", &dateReleasedtest));
	printf("\n  ******dateReleased test is..[%s]\n", dateReleasedtest);
	fflush(stdout);
	printf("\n ~~~~~~~~ U P D A T I O N   E N D ~~~~~~~~\n");
	fflush(stdout);

	if (ifail == ITK_ok)
	{
		printf("\n Date Release Updated.....!!");
		fflush(stdout);
	}
	printf("\n Function(update_release_date) End..!!\n");

	return ifail;
}

int t5removeAllReleaseStatus(tag_t RevisionTag)
{

	int status_count;
	tag_t *status_list;
	int st_relList_count = 0;
	int Rel_cnt = 0;
	tag_t *relstatus_list = NULLTAG;
	char *WSO_Name_RelVal = NULL;
	tag_t tReleaseStatusList = NULLTAG;
	int n_values = 0;
	int cunt1 = 0;
	tag_t *attr_tags = NULLTAG;
	logical *is_it_null = NULL;
	logical *is_it_empty = NULL;
	tag_t class_id = NULLTAG;
	char *class_name = NULL;
	logical log1;
	int ifail = 0;

	ITK_CALL(WSOM_ask_release_status_list(RevisionTag, &status_count, &status_list));

	printf("No of Status == %d\n", status_count);
	if (status_count > 0)
	{
		ITK_CALL(POM_class_of_instance(RevisionTag, &class_id));
		ITK_CALL(POM_name_of_class(class_id, &class_name));
		ITK_CALL(POM_attr_id_of_attr("release_status_list", class_name, &tReleaseStatusList));
		ITK_CALL(POM_unload_instances(1, &RevisionTag));
		ITK_CALL(POM_load_instances(1, &RevisionTag, class_id, 1));
		ITK_CALL(POM_is_loaded(RevisionTag, &log1));
		if (log1 == 1)
		{
			printf("Load Success\n");
		}
		else
			printf("Load Failure\n");

		ITK_CALL(POM_length_of_attr(RevisionTag, tReleaseStatusList, &n_values));
		if (n_values > 0)
		{
			ITK_CALL(POM_ask_attr_tags(RevisionTag, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty));
			for (cunt1 = 0; cunt1 < n_values; cunt1++)
			{
				printf("Status removal started\n");
				ITK_CALL(POM_remove_from_attr(1, &RevisionTag, tReleaseStatusList, 0, 1));
				ITK_CALL(POM_save_instances(1, &RevisionTag, 1));
				ITK_CALL(POM_refresh_instances(1, &RevisionTag, class_id, 2));
				ITK_CALL(AOM_lock(RevisionTag));
				/* if(ifail!=ITK_ok)
				{
						printf("The Item Revision cannot be locked. Status Removal failed\n");
						break;
				} */
				ITK_CALL(AOM_save(RevisionTag));
				ITK_CALL(AOM_refresh(RevisionTag, 1));
				printf("Status removal completed\n");

				ITK_CALL(POM_length_of_attr(RevisionTag, tReleaseStatusList, &n_values));
				printf("Updated Status Count is :%d\n", n_values);
				// ITK_CALL( POM_ask_attr_tags(RevisionTag, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
				cunt1 = cunt1 - 1;
			}
			ITK_CALL(AOM_unlock(RevisionTag));
		}

		printf("All Statuses removed\n");
		;
		fflush(stdout);
	}
	return ifail;
}


int ITK_user_main(int argc, char* argv[])
{
	    int iFail = 0;
	    char* cError = NULL;
		char* username = NULL;
		tag_t tuser = NULLTAG;
		
		const char* u = NULL;
		const char* pf = NULL;
		const char* g = NULL;
		char *creationDate = NULL;
		tag_t release_status = NULLTAG;
		char* dateReleased =NULL;
		tag_t Stat_tag = NULLTAG;
		char *latest_rev_Rel_StatusDup = NULL;
		int new_status_count = 0;
		tag_t *new_relStatus_list = NULLTAG;
		date_t Ltest_date_2;
		
		iFail = ITK_auto_login();
		printf("\nReturn Value is : %d", iFail);fflush(stdout);
		
		int n_entries = 2;
		int i,k,flag;
		tag_t tItemobj1 = NULLTAG;
		tag_t tItemobj = NULLTAG;
		tag_t itemtag  = NULLTAG;
		int n_itemobj_found = 0;
		tag_t* titemobj_results = NULLTAG;
		int n_itemobj_found1 = 0;
		tag_t* titemobj_results1 = NULLTAG;

		char *PartID = NULL;
		char *PartSequenceID = NULL;
		char *part_type = NULL;
		char *Description = NULL;
		char *object_type = NULL;
		char *Part_ProjID = NULL;
		char *Part_DesgnGrp = NULL;
		char *Revision = NULL;
		tag_t DataSet = NULLTAG;
		char *inputfile=NULL;
		char *PartRevSeqID =NULL;
		char *ItemDesc = NULL;
		char *partType	= NULL;
		char *rev_id 	= NULL;
		tag_t LatestRev = NULLTAG;
		int 	n_values_bvr=0;
		tag_t	*bvr_assy_part= NULLTAG;
		char *ProjectCode = NULL;
		char* DesignGroup = NULL;
		int status_count = 0;
		int j = 0;
		char* ReleaseStatus = NULL;
		tag_t* status_list = NULLTAG;
		tag_t reva = NULL;
		char* UserId = NULL;
		int *levels	= 0;
		tag_t *parents = NULLTAG;
		
		
		
		tag_t itemrev = NULLTAG;
		tag_t RevisionTag = NULLTAG;
		int Part_Stat_Cnt = 0;
		tag_t *Part_Stat_Lst = NULLTAG;
		char *Part_Rlz_Stat = NULL;
		char *temp= NULL;
		temp = (char *)MEM_alloc(250);
		
		tag_t itemrev1 = NULLTAG;
		tag_t objTypeRefTag=NULLTAG;
		char* ObjectName = NULL;
		char* ObjectName1 = NULL;
		tag_t	*referencers = NULLTAG;
		int ReqFdrSize=0;
		tag_t folder_type = NULLTAG;
		tag_t  reln_type_tag = NULLTAG;
		int Parts =0;
		tag_t* PartsObj = NULLTAG;
		char *Default_Group = NULL;
		char *UserName1 = NULL;
		char *HomeFolder = NULL;
		char *object_type1 = NULL;		
		char* ds_object_type = NULL;
		char* PartPlantName = NULL;
		char* ContextType = NULL;
		char* ViewClosureRule = NULL;
		char  *refname = NULL;
		AE_reference_type_t     reftype;
		tag_t	refobject = NULL;
		char* orig_name = NULL;
		char *fileLoc = NULL;		
		tag_t RevRuleObjTag = NULLTAG;
		int n_entries1 =3;
		char *cEntries1[3]  = {"Owning User","Type","Name"};
		char **cValues1 = (char **) MEM_alloc(50 * sizeof(char *));
		//char	outputFile[200]	= "PartImplosiontoVC.csv";
		
		PIE_scope_t scope;
		int 	n_closure_tags;
		tag_t * 	closure_tags;
		tag_t  	closure_tag;
		char* FirstPart = NULL;
        int FirstPartCount =0;	
		FirstPart = (char *) MEM_alloc( 100 * sizeof(char) );

		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		char Date[100] = "";
		char outputFile[200] = "";
		strftime(Date,100,"%d_%m_%Y_%H_%M",&when);
		sprintf(outputFile,"/tmp/DummyPartRelease_%s.csv",Date);
		
		output = fopen(outputFile,"w");
		
		
		u = ITK_ask_cli_argument( "-u=");
		pf = ITK_ask_cli_argument( "-pf=");
		g = ITK_ask_cli_argument( "-g=");
		char CurrentAccessDate[20]={0};
		
		UserId = ITK_ask_cli_argument("-UserId=");

	//	char *cEntries[2]  = {"Item ID","Revision"};
		char *inputline = NULL;		
	//	char **cValues = (char **) MEM_alloc(50 * sizeof(char *));	
	
		if (ITK_init_module(u,pf,g) == ITK_ok )
		{
			printf("\nTeamcenter Login Success...");fflush(stdout);
		}
		
		printf(" \n UserId  ------------> :%s\n",UserId);fflush(stdout);

		if (output == NULL)
		{
			printf("ERROR: Cannot open File\n");
			return -1;
		}
		

	/*	if (iFail == ITK_ok)
		{
			printf("\nTeamcenter Login Success...");fflush(stdout);
			POM_get_user(&username, &tuser);
			printf("\nUsername = %s\n", username);fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(iFail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		if (cError)
		{
			MEM_free(cError);
		}
		if (username)
		{
			MEM_free(username);
		}*/
		
			cValues1[0] =UserId;
			cValues1[1] = "Folder";
			cValues1[2] = "Dummy_to_release_for_Input";
			
			
			QRY_find("General...",&tItemobj1);			
			QRY_execute(tItemobj1, n_entries1, cEntries1, cValues1, &n_itemobj_found1, &titemobj_results1);	
			printf("n_itemobj_found1------------> :%d\n",n_itemobj_found1);fflush(stdout);
			
		  
		    if(n_itemobj_found1 > 0)
			{
				itemrev1=titemobj_results1[0];
				char type_name_ref1[TCTYPE_name_size_c+1];
				TCTYPE_ask_object_type(itemrev1,&objTypeRefTag);
				TCTYPE_ask_name(objTypeRefTag,&type_name_ref1);
				printf("\n type_name_ref,%s",type_name_ref1);
				
				AOM_UIF_ask_value(itemrev1,"object_name",&ObjectName);
				printf("\n type_name_ref,%s,%s",type_name_ref1,ObjectName);
									
				AOM_ask_value_string(itemrev1,"object_type",&object_type1);
				printf("object_type: %s",object_type1);
				AOM_ask_value_tags(itemrev1,"contents", &Parts, &PartsObj);			
				if (PartsObj != NULLTAG)
				{
					printf("contents\n");
					
				}			
				printf("\n  Main : No of contents are : %d \n",Parts); fflush(stdout);
				
				if(Parts > 0)
				{
					for(j=0;j<Parts;j++)
					{
						AOM_ask_value_string(PartsObj[j],"object_type",&object_type);
						printf("object_type: %s",object_type);						
						if(tc_strcmp(object_type,"Text")==0)
						{
							AE_find_dataset_named_ref2(PartsObj[j],0,&refname, &reftype,&refobject);
							if(refobject != NULLTAG)
							{
								iFail = IMF_ask_original_file_name2(refobject , &orig_name);								
								fileLoc = (char *) MEM_alloc( 500 * sizeof(char) );
								tc_strcpy(fileLoc,"/tmp/");
								tc_strcat(fileLoc,orig_name);
								remove( fileLoc );								
								IMF_export_file( refobject , fileLoc );	
								FILE *fp=NULL;														
								fp = fopen(fileLoc, "r");								
								if(fp==NULL)
								{
									printf("\nCould not open the file %s. Kindly check.\n",fileLoc);fflush(stdout);
								}
								else
								{
									char buffer[MAX_LINE_LEN] ="";
									int x =0;
									char* PartNo = NULL;
									char* PartRevSeq = NULL;
									char* PartRevSeq_dup = NULL;
									char* Diff_date = NULL;
									char* cItem_Rev = NULL;
									char* cItem_Seq = NULL;
									int Diff_date_num = 0;
												
									while(fgets(buffer, MAX_LINE_LEN,fp)!= NULL)
									{
										PartNo = strtok(buffer,",");
										PartRevSeq = strtok(NULL,",");
										Diff_date  = strtok(NULL,",");
										
										printf("\n PartNo is %s ",PartNo);fflush(stdout);
										printf("\n PartRevSeq is %s ",PartRevSeq);fflush(stdout);
										
										PartRevSeq_dup = (char *) MEM_alloc( 100 * sizeof(char) );
										
										cItem_Rev=strtok(PartRevSeq,";");
										cItem_Seq=strtok(NULL,";");
										printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
										printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
										
										tc_strcpy(PartRevSeq_dup,cItem_Rev);
										tc_strcat(PartRevSeq_dup,"*");
										tc_strcat(PartRevSeq_dup,cItem_Seq);
										
					
										int Diff_date_num = atoi(Diff_date);
										printf("\n the value of Diff_date_num is %d",Diff_date_num);

										
										char *cEntries[2] = {"Revision", "ID"};
										char *cValues[2] = {PartRevSeq_dup, PartNo};
										
										//if(Diff_date_num > 0)
										//{
											QRY_find2("DesignRevision Sequence",&tItemobj);						
											QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results);	
											printf("\n n_itemobj_found-----------> :%d\n",n_itemobj_found);fflush(stdout);	
										
											if (n_itemobj_found > 0)
											{
												for(i=0;i<n_itemobj_found;i++)
												{
												
													RevisionTag =titemobj_results[i];
													
													AOM_UIF_ask_value(RevisionTag, "creation_date", &creationDate);
													printf(" Creation date found on current rev is [%s]\n", creationDate);
													
													// Removing old status Flag
													printf("\n Function[remove Status] Call Start..!!");fflush(stdout);
													t5removeAllReleaseStatus(RevisionTag);
													printf("\n Function[remove Status] Call End..!!");fflush(stdout);
					
													AOM_refresh(RevisionTag, POM_modify_lock);
													printf("\n Lock..!!\n");
													
													printf(" \n ******Now Stamping Release Status********** \n");
													
													RELSTAT_create_release_status("T5_LcsErcRlzd",&release_status);
													
													
													AOM_ask_name(release_status,&ReleaseStatus);
													printf("\n ReleaseStatus :%s\n",ReleaseStatus); fflush(stdout);
													
													RELSTAT_add_release_status(release_status,1,&RevisionTag,false);
													printf("\n\t Release status is updated ----------->\n"); fflush(stdout);
													
													getCurrentDateTime(CurrentAccessDate);
													printf("\n CurrentAccessDate : %s",CurrentAccessDate);
													
													ITK_string_to_date(CurrentAccessDate,&Ltest_date_2);
													printf("\n11111111111111111111");fflush(stdout);
													
	
													WSOM_ask_release_status_list(RevisionTag, &new_status_count, &new_relStatus_list);
													printf("\n No of Release Status Found: -----> <%d> \n", new_status_count);fflush(stdout);
													
													if (new_status_count > 0)
													{
														int u = 0;
														for (u = 0; u < new_status_count; u++)
														{
															AOM_ask_value_string(new_relStatus_list[u], "object_name", &latest_rev_Rel_StatusDup);
															printf("\n Latest_Rev_Rel_Status [After release status  Stamping]: ------> <%s> \n", latest_rev_Rel_StatusDup);
															fflush(stdout);
															
															if ((tc_strcmp(latest_rev_Rel_StatusDup, "T5_LcsRlzd") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup, "T5_LcsErcRlzd") == 0))
															{
																printf(" Inside 2nd time Release status check\n");fflush(stdout);
																Stat_tag = new_relStatus_list[u];
																printf("\n Function[update_release_date - ] Call Start..!!");fflush(stdout);
																update_release_date(Stat_tag, Ltest_date_2);
																printf("\n Function[update_release_date -] Call End..!!");fflush(stdout);
																
																ITK_CALL(AOM_UIF_ask_value(new_relStatus_list[u], "date_released", &dateReleased));
																printf("\n  ******Updated_release_date is..[%s]\n", dateReleased);fflush(stdout);
																
																printf("\n Function[******Create Effectivity Status******] Call Start..!!");fflush(stdout);
																
																CreateEffctivity(RevisionTag, creationDate, "31-Dec-9999 00:00", "T5_LcsErcRlzd");
																printf("\n Function[*****Create Effectivity Status*****] Call End..!!");fflush(stdout);
																
															}
															
															else
															{
																printf(" Not found ERC Released Status \n");fflush(stdout);
															}
														
														}
													}													
													else
													{
														printf(" After Stamping >>> not found status count[new_status_count=0] \n");fflush(stdout);
													}	
													
													
													fprintf(output,"\n%s,%s,%s,%s,",PartNo,PartRevSeq,"Dummy","ERC Released");fflush(output);
												}
											
											}
											
										
										//}
											
									}																				
									if(fp!=NULL)
									{
										fclose(fp); 
									}															
								}																	
							}				
						}
	
					}
				}	

				
				
				printf("\n Report File Attach To Users Home Folder Start..!!\n");fflush(stdout);
				char *Filename = NULL;
				char *FileLoc = NULL;
				char *dataSetName = NULL;
				IMF_file_t	fileDescriptor;
				tag_t	datasettype = NULLTAG;
				tag_t	tool 		= NULLTAG;
				tag_t	Newdataset 	= NULLTAG;
				tag_t	filetag 	= NULLTAG;
				tag_t tUser = NULLTAG;
				tag_t tHomeFolder = NULLTAG;
				
				dataSetName = (char *) MEM_alloc( 70 * sizeof(char) );
				//tc_strcpy(dataSetName,"PartImplosiontoVC-RPT-");
				sprintf(dataSetName,"DummyPartRelease-RPT-%s",FirstPart);
				printf(" Dataset Name: [%s]\n", dataSetName);fflush(stdout);
				
				Filename = (char *) MEM_alloc( 50 * sizeof(char) );
				FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
				sprintf(Filename,"/tmp/DummyPartRelease_%s.csv",Date);
				printf(" File Name: [%s]\n", Filename);fflush(stdout);
				
				
				//char *exepathdup = NULL;
				//exepathdup = (char *)MEM_alloc(1000);
				//tc_strcpy(exepathdup,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/Lokendra/PartImplosiontoVCTesting/Unique.sh");
				//tc_strcat(exepathdup," ");
				//tc_strcat(exepathdup,Filename);
				//tc_strcat(exepathdup," ");
				//tc_strcat(exepathdup,Date);
				//tc_strcat(exepathdup," ");
				//tc_strcat(exepathdup,UserId);				
				//system(exepathdup);

				//tc_strcpy(FileLoc,"/tmp/");
				//tc_strcat(FileLoc,Filename);
				tc_strcpy(FileLoc,Filename);
				printf(" File Location: [%s]\n", FileLoc);fflush(stdout);
			
				ITK_CALL(AE_find_datasettype2("MSExcel",&datasettype));
				ITK_CALL(AE_find_tool2("MSExcel", &tool));
				ITK_CALL(AE_create_dataset_with_id(datasettype,dataSetName,"",NULL,NULL,&Newdataset));
				ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
				ITK_CALL(AE_set_dataset_format2(Newdataset,"BINARY_REF"));
				ITK_CALL(AOM_save(Newdataset));	
				ITK_CALL(IMF_fmsfile_import(FileLoc,Filename,SS_BINARY,&filetag,&fileDescriptor));
				if(filetag == NULLTAG)
				{
					printf(" File Tag Not Found..!!\n");fflush(stdout);
				}
				ITK_CALL(AOM_refresh(Newdataset,TRUE));
				ITK_CALL(AE_add_dataset_named_ref2(Newdataset, "excel", AE_PART_OF, filetag));
				ITK_CALL(AOM_save(Newdataset));
				ITK_CALL(AOM_refresh(Newdataset,FALSE));
				
				ITK_CALL(SA_find_user2(UserId,&tUser));
				ITK_CALL(SA_ask_user_home_folder(tUser,&tHomeFolder));
				ITK_CALL(AOM_lock(tHomeFolder));
				ITK_CALL(FL_insert(tHomeFolder,Newdataset,999));
				ITK_CALL(AOM_save(tHomeFolder));
				ITK_CALL(AOM_unlock(tHomeFolder));
				printf("\n Report File Attach To Users Home Folder End..!!\n");fflush(stdout);
			
		
			}
			else
			{
				fprintf(output, "Part no found \n");fflush(output);
			}
		
		//write2xml(output,"</PLMXML>\n");
		iFail = ITK_exit_module(TRUE);
		printf("\nReturn Value is : %d", iFail);
		if (iFail == ITK_ok)
		{
			printf("\nTeamcenter Logout Success...");fflush(stdout);
		}
		else
		{
			EMH_ask_error_text(iFail, &cError);
			printf("\nError is : %s", cError);fflush(stdout);
		}
		
	fclose(output);
	return ITK_ok;
}

