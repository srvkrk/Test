#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <pom/enq/enq.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/pom/pom.h>
#include <epm/epm.h>
#include <user_exits/libuser_exits_exports.h>
#include <user_exits/libuser_exits_undef.h>
#include <time.h>
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <tc/tc.h>
#include <pie/pie.h>
#include <bom/bom.h>
#include <tccore/aom_prop.h>
#include <stdio.h>
#include <string.h>






#define Debug TRUE

#define ITK_CALL(x) {           \
        int stat;                     \
        char *err_string;             \
        if( (stat = (x)) != ITK_ok)   \
        {                             \
        EMH_ask_error_text (stat, &err_string);                 \
        printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
        if(err_string) MEM_free(err_string);                                \
        exit (EXIT_FAILURE);                                                   \
        }                                                                    \
}

char* StartDate = NULL;
char* EndDate = NULL;
char* ReportFileName =NULL;
int RptERCDMLAge = 0;
int RptMBOMDMLAge = 0;
int RptAPLDMLAge = 0;

signed long daysInSecond(signed int day)
{
	return day*24*60*60;
}

long timeInSec(time_t time1)
{
	return (long)time1;
}

time_t longTotime_t(long timeInSec)
{
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day)
{
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

struct UDate
{ 
    int d, m, y; 
}; 
  
// To store number of days in  
// all months from January to Dec. 
const int monthDays[12] 
    = { 31, 28, 31, 30, 31, 30,  
       31, 31, 30, 31, 30, 31 }; 
  
// This function counts number of  
// leap years before the given date 
int countLeapYears(struct UDate d) 
{ 
    int years = d.y; 
  
    // Check if the current year needs to be 
    //  considered for the count of leap years 
    // or not 
    if (d.m <= 2) 
        years--; 
  
    // An year is a leap year if it  
    // is a multiple of 4, 
    // multiple of 400 and not a  
     // multiple of 100. 
    return years / 4  
           - years / 100 
           + years / 400; 
} 
  

int getDifference(struct UDate dt1, struct UDate dt2) 
{ 
    // COUNT TOTAL NUMBER OF DAYS 
    // BEFORE FIRST DATE 'dt1' 
  
    // initialize count using years and day 
    long int n1 = dt1.y * 365 + dt1.d; 
  
    // Add days for months in given date 
	int i = 0;
    for ( i = 0; i < dt1.m - 1; i++) 
        n1 += monthDays[i]; 
  
    // Since every leap year is of 366 days, 
    // Add a day for every leap year 
    n1 += countLeapYears(dt1); 
  
    // SIMILARLY, COUNT TOTAL NUMBER OF 
    // DAYS BEFORE 'dt2' 
  
    long int n2 = dt2.y * 365 + dt2.d; 
	
    for ( i = 0; i < dt2.m - 1; i++) 
        n2 += monthDays[i]; 
    n2 += countLeapYears(dt2); 
  
    // return difference between two counts 
    return (n2 - n1); 
} 


int  getMonth(char cMonth[30])
{
	int mon = 0;
	if(strcmp(cMonth,"Jan") == 0)
	{
		mon = 1;
	}
	if(strcmp(cMonth,"Feb") == 0)
	{
		mon = 2;
	}
	if(strcmp(cMonth,"Mar") == 0)
	{
		mon = 3;
	}
	if(strcmp(cMonth,"Apr") == 0)
	{
		mon = 4;
	}
	if(strcmp(cMonth,"May") == 0)
	{
		mon = 5;
	}
	if(strcmp(cMonth,"Jun") == 0)
	{
		mon = 6;
	}
	if(strcmp(cMonth,"Jul") == 0)
	{
		mon = 7;
	}
	if(strcmp(cMonth,"Aug") == 0)
	{
		mon = 8;
	}
	if(strcmp(cMonth,"Sep") == 0)
	{
		mon = 9;
	}
	if(strcmp(cMonth,"Oct") == 0)
	{
		mon = 10;
	}
	if(strcmp(cMonth,"Nov") == 0)
	{
		mon = 11;
	}
	if(strcmp(cMonth,"Dec") == 0)
	{
		mon = 12;
	}
    return mon;
}

struct UDate GetDateInUdateFormat(char* strDate)
{
	int Month;
    int Year;
    int day;
	
    char *strYear = NULL;
    char *strMonth = NULL;
    char *strDay = NULL;



    strYear = (char*) malloc(10 * sizeof(char));
    strMonth = (char*) malloc(10 * sizeof(char));
    strDay = (char*) malloc(10 * sizeof(char));

    
    strDay   =  strtok(strDate,"-");
    strMonth  =  strtok(NULL,"-");
    strYear    =  strtok(NULL," ");
      
      
    printf("strDay = %s",strDay); 
    printf("strMonth = %s",strMonth); 
    printf("strYear = %s",strYear); 
    
    
    Month =  getMonth(strMonth);
    Year =  atoi(strYear);
    day =  atoi(strDay);
	
	printf("Month =%d",Month);
	printf("Year =%d",Year);
	printf("day =%d",day);
        
        
    struct UDate dt1 = { day, Month, Year }; 
	
	return dt1;
}

struct UDate GetCurrentInUdateFormat()
{
	time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    int dd = tm.tm_mday;
    int mm = tm.tm_mon+1;
    int yy = tm.tm_year + 1900;
    
    struct UDate dt1 = { dd, mm, yy }; 
	
    return dt1;
}

char* GetApplicableMBOMDesignGroup()
{
	char*   MBOMDesignGrpList = NULL;
	tag_t   CtrlObjQryTag	= NULLTAG;
	char    *QryEntries[2]  = {"SYSCD","SUBSYSCD"};
	char	*QryValues[2]   = {"MBOMAplDsgGrp1","MBOMAplDsgGrp1"};
	
	
	ITK_CALL(QRY_find2("Control Objects...",&CtrlObjQryTag));
	if (CtrlObjQryTag !=NULLTAG)
	{
		int          NoOfQryObj         =    0;
		tag_t       *CtrlObjectsTag     =    NULLTAG;
		ITK_CALL(QRY_execute(CtrlObjQryTag,2, QryEntries, QryValues, &NoOfQryObj, &CtrlObjectsTag));
		
		if (NoOfQryObj > 0)
		{
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo1",&MBOMDesignGrpList);
		}
	}
	return MBOMDesignGrpList;
}

char* GetReleaseTypeNotApplicableForMBOM()
{
	char*   ListRlzTypeNtApliMBOM = NULL;
	tag_t   CtrlObjQryTag	= NULLTAG;
	char    *QryEntries[2]  = {"SYSCD","SUBSYSCD"};
	char	*QryValues[2]   = {"MBOMAplDsgGrp1","MBOMAplDsgGrp1"};
	ListRlzTypeNtApliMBOM = (char *) MEM_alloc(1000);
	tc_strcpy(ListRlzTypeNtApliMBOM,"");
	
	/*ITK_CALL(QRY_find("Control Objects...",&CtrlObjQryTag));
	if (CtrlObjQryTag !=NULLTAG)
	{
		int          NoOfQryObj         =    0;
		tag_t       *CtrlObjectsTag     =    NULLTAG;
		ITK_CALL(QRY_execute(CtrlObjQryTag,2, QryEntries, QryValues, &NoOfQryObj, &CtrlObjectsTag));
		char* RlzType = NULL;
		
		if (NoOfQryObj > 0)
		{
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo1",&RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,"#&");
			
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo2",&RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,"#&");
			
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo3",&RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,"#&");
			
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo4",&RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,"#&");
			
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo5",&RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,"#&");
			
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo6",&RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,"#&");
			
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo7",&RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,"#&");
			
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo8",&RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,"#&");
			
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo9",&RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,"#&");
			
			AOM_ask_value_string(CtrlObjectsTag[0],"t5_Userinfo10",&RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,RlzType);
			tc_strcat(ListRlzTypeNtApliMBOM,"#&");
		}
	}*/
	tc_strcat(ListRlzTypeNtApliMBOM,"Kit and Spare Part Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Prototype Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"ECU Parts Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Workshop Tools Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Reference Drawing Linkage");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"VC/TPL Master Data Update");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Dummy TPL Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Positional Dummy Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Spare Indicator Update");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"VC/Module Master Data Update");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Vehicle Offer Drawing");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Comp Code and Colour Indicator update");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"ECU Master Data Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"DVP MDM Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Backward Compatible VCID Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"VCID Update");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Info Fitment Drawing Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Vehicle Offer/Pass off norms Drawing");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Standard Part Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"Tech Spec Release");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	tc_strcat(ListRlzTypeNtApliMBOM,"DM DML for 4D/DFQ Document attachment");
	tc_strcat(ListRlzTypeNtApliMBOM,"#&");
	
	
	
	return ListRlzTypeNtApliMBOM;
}

char* GetReleaseTypeNotApplicableForAPL()
{
	char*   ListRlzTypeNtApliAPL = NULL;
	ListRlzTypeNtApliAPL = (char *) MEM_alloc(1000);
	
	tc_strcat(ListRlzTypeNtApliAPL,"Vehicle Offer/Pass off norms Drawing");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"Standard Part Release");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"Tech Spec Release");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"Comp Code and Colour Indicator update");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"ECU Master Data Release");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"DVP MDM Release");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"Backward Compatible VCID Release");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"VCID Update");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"Spare Indicator Update");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"Info Fitment Drawing Release");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"Parked Vehicle");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"Unparked Vehicle");
	tc_strcat(ListRlzTypeNtApliAPL,"#&");
	tc_strcat(ListRlzTypeNtApliAPL,"MDM DML for 4D/DFQ Document attachment");	
	
	return ListRlzTypeNtApliAPL;
}



char* GetReleaseTypeNotApplicableForSTD()
{
	char*   ListRlzTypeNtApliSTD = NULL;
	ListRlzTypeNtApliSTD = (char *) MEM_alloc(1000);
	
	tc_strcat(ListRlzTypeNtApliSTD,"Vehicle Offer/Pass off norms Drawing");
	tc_strcat(ListRlzTypeNtApliSTD,"#&");
	tc_strcat(ListRlzTypeNtApliSTD,"Standard Part Release");
	tc_strcat(ListRlzTypeNtApliSTD,"#&");
	tc_strcat(ListRlzTypeNtApliSTD,"Tech Spec Release");
	tc_strcat(ListRlzTypeNtApliSTD,"#&");
	tc_strcat(ListRlzTypeNtApliSTD,"Comp Code and Colour Indicator update");
	tc_strcat(ListRlzTypeNtApliSTD,"#&");
	tc_strcat(ListRlzTypeNtApliSTD,"ECU Master Data Release");
	tc_strcat(ListRlzTypeNtApliSTD,"#&");
	tc_strcat(ListRlzTypeNtApliSTD,"DVP MDM Release");
	tc_strcat(ListRlzTypeNtApliSTD,"#&");
	tc_strcat(ListRlzTypeNtApliSTD,"Backward Compatible VCID Release");
	tc_strcat(ListRlzTypeNtApliSTD,"#&");
	tc_strcat(ListRlzTypeNtApliSTD,"VCID Update");
	tc_strcat(ListRlzTypeNtApliSTD,"#&");
	tc_strcat(ListRlzTypeNtApliSTD,"Spare Indicator Update");
	tc_strcat(ListRlzTypeNtApliSTD,"#&");
	tc_strcat(ListRlzTypeNtApliSTD,"Info Fitment Drawing Release");
	tc_strcat(ListRlzTypeNtApliSTD,"#&");
	tc_strcat(ListRlzTypeNtApliSTD,"MDM DML for 4D/DFQ Document attachment");	
	
	return ListRlzTypeNtApliSTD;
}


int DesignGroupListContainInMBOMDesignGrpList(char** DesignGroupList,int NumOfDesGrp,char* MBOMDesignGrpList)
{
    int i =0;
	int flag = 0;
	for(i=0;i<NumOfDesGrp;i++)
	{
		if (tc_strstr(MBOMDesignGrpList,DesignGroupList[i]) != NULL )
		{
			printf("\n %s",MBOMDesignGrpList);
			printf("\n %s",DesignGroupList[i]);
			flag = 1;
			break;
		}
	}
  return flag;
}

tag_t GetApplicableMBOMDMLTag(tag_t ERCDMLTag)
{
	int NumDmlTskRln = 0;
	tag_t* TaskNdDMLTag = NULLTAG;
	tag_t MBOMDMLTag = NULLTAG;
	AOM_ask_value_tags(ERCDMLTag,"T5_DMLTaskRelation",&NumDmlTskRln,&TaskNdDMLTag);
	if (NumDmlTskRln>0)
	{
		int Counter = 0;
		for (Counter = 0; Counter<NumDmlTskRln; Counter++)
		{
			char* DMLObjType = NULL;
			AOM_ask_value_string(TaskNdDMLTag[Counter],"object_type",&DMLObjType);
			printf("\n DMLObjType =%s",DMLObjType);fflush(stdout);
			if(tc_strcmp(DMLObjType,"T5_MBOMDMLRevision") == 0)
			{
				MBOMDMLTag = TaskNdDMLTag[Counter];
				break;
			}
		}
	}
	return MBOMDMLTag;
}

tag_t GetApplicableAPLDMLTag(tag_t MBOMDMLTag,char* DMLSubStr)
{
	int NumDmlTskRln = 0;
	tag_t* TaskNdDMLTag = NULLTAG;
	tag_t APLDMLTag = NULLTAG;
	AOM_ask_value_tags(MBOMDMLTag,"T5_DMLTaskRelation",&NumDmlTskRln,&TaskNdDMLTag);
	if (NumDmlTskRln>0)
	{
		int Counter = 0;
		for (Counter = 0; Counter<NumDmlTskRln; Counter++)
		{
			char* DMLObjType = NULL;
			char* DMLObjName = NULL;
			AOM_ask_value_string(TaskNdDMLTag[Counter],"object_type",&DMLObjType);
			AOM_ask_value_string(TaskNdDMLTag[Counter],"item_id",&DMLObjName);
			printf("\n DMLObjType =%s",DMLObjType);fflush(stdout);
			printf("\n DMLObjName =%s",DMLObjName);fflush(stdout);
			if(tc_strcmp(DMLObjType,"T5_APLDMLRevision") == 0)
			{
				if(tc_strstr(DMLObjName,DMLSubStr)!=NULL)
				{
					APLDMLTag = TaskNdDMLTag[Counter];
					break;
				}
			}
		}
	}
	printf("\n Exit From GetApplicableAPLDMLTag");fflush(stdout);
	return APLDMLTag;
}

void GetCreationDateOfDML(tag_t DMLTag,char* DMLCreationdate)
{
	char* TempDMLCreationDate = NULL;
	TempDMLCreationDate = (char *) MEM_alloc(100);
	AOM_UIF_ask_value(DMLTag,"creation_date",&TempDMLCreationDate);
	strcpy(DMLCreationdate,TempDMLCreationDate);
	printf("DMLCreationdate = %s",DMLCreationdate);fflush(stdout);
}



void GetReleaseDateOfDML(tag_t DMLTag,int Option,char* RlzStatusName,char* DMLReleasedDate)
{
	//Option 0 ERC
	//Option 1 MBOM
	//Option 2 APLJ //Option 3 APLP //Option 4 APLL//Option 5 APLD// Option 6 APLU
	//Option 7 STDJ //Option 8 STDP //Option 9 STDL//Option 10 STDD// Option 11 STDU
	//DMLReleasedDate = (char *) MEM_alloc(100);
	//RlzStatusName = (char *) MEM_alloc(100);
	
	tag_t* ReleasedList = NULLTAG;
	int NoRlz = 0;
	WSOM_ask_release_status_list(DMLTag,&NoRlz,&ReleasedList);
	int Cnt = 0;
	char* TempRlzStatusName = NULL;
	char* TempDMLReleasedDate = NULL;
	for(Cnt=0;Cnt<NoRlz;Cnt++)
	{
		if ( Option == 0)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsErcRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsWorking")!=NULL)||(tc_strstr(TempRlzStatusName,"T5_LcsReview")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 1)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			printf("\n TempRlzStatusName = %s",TempRlzStatusName);fflush(stdout);
			if(tc_strstr(TempRlzStatusName,"T5_MBOMReleased")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				printf("\n TempDMLReleasedDate = %s",TempDMLReleasedDate);fflush(stdout);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_MBOMWorking")!=NULL)|| (tc_strstr(TempRlzStatusName,"T5_MBOMReview")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
		}
		else if (Option == 2)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsApljRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsAPLjWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		
		else if (Option == 3)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsAplpRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsAPLpWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 4)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsApllRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsAPLlWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 5)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsApldRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsAPLdWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 6)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsApluRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsAPLuWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 7)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsStdjRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsSTDjWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 8)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsStdpRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsSTDpWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 9)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsStdlRlzd")!=NULL) 
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsSTDlWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 10)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsStddRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsSTDdWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 11)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsStduRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsSTDuWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 12)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsStdjRestructured")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if (tc_strstr(TempRlzStatusName,"T5_LcsStdjRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsSTDjWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 13)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsStdpRestructured")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if (tc_strstr(TempRlzStatusName,"T5_LcsStdpRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsSTDpWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 14)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsStdlRestructured")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if (tc_strstr(TempRlzStatusName,"T5_LcsStdlRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsSTDlWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 15)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsStddRestructured")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if (tc_strstr(TempRlzStatusName,"T5_LcsStddRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsSTDdWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		else if (Option == 16)
		{
			AOM_ask_value_string(ReleasedList[Cnt],"object_name", &TempRlzStatusName);
			if(tc_strstr(TempRlzStatusName,"T5_LcsStduRestructured")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if (tc_strstr(TempRlzStatusName,"T5_LcsStduRlzd")!=NULL)
			{
				AOM_UIF_ask_value(ReleasedList[Cnt],"date_released", &TempDMLReleasedDate);
				strcpy(RlzStatusName,TempRlzStatusName);
				strcpy(DMLReleasedDate,TempDMLReleasedDate);
				break;
			}
			else if ((tc_strstr(TempRlzStatusName,"T5_LcsSTDuWrkg")!=NULL))
			{
				strcpy(RlzStatusName,TempRlzStatusName);
			}
			
		}
		
		
	}
}

int APLLiveForPlant(char* ProjectCode,char* PlantName)
{
	
	tag_t   CtrlObjQryTag	= NULLTAG;
	char    *QryEntries[4]  = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};
	char	*QryValues[4]   = {"PlantDML",ProjectCode,"False",PlantName};
	int isAPLLive = 0;
	printf("\n ProjectCode = %s",ProjectCode);fflush(stdout);
	printf("\n PlantName = %s",PlantName);fflush(stdout);
	ITK_CALL(QRY_find2("Control Objects...",&CtrlObjQryTag));
	if (CtrlObjQryTag !=NULLTAG)
	{
		int          NoOfQryObj         =    0;
		tag_t       *CtrlObjectsTag     =    NULLTAG;
		ITK_CALL(QRY_execute(CtrlObjQryTag,4, QryEntries, QryValues, &NoOfQryObj, &CtrlObjectsTag));
		char* DeleInd = NULL;
		if (NoOfQryObj>=1)
		{
			isAPLLive = 1;
		}
	}
	return isAPLLive;
}


int STDLiveForPlant(char* ProjectCode,char* PlantName,char* UsrInfo3)
{
	
	tag_t   CtrlObjQryTag	= NULLTAG;
	char    *QryEntries[5]  = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1","Information-3"};
	char	*QryValues[5]   = {"PlantDML",ProjectCode,"False",PlantName,UsrInfo3};
	int isSTDLive = 0;
	printf("\n ProjectCode = %s",ProjectCode);fflush(stdout);
	ITK_CALL(QRY_find2("Control Objects...",&CtrlObjQryTag));
	if (CtrlObjQryTag !=NULLTAG)
	{
		int          NoOfQryObj         =    0;
		tag_t       *CtrlObjectsTag     =    NULLTAG;
		ITK_CALL(QRY_execute(CtrlObjQryTag,5, QryEntries, QryValues, &NoOfQryObj, &CtrlObjectsTag));
		char* DeleInd = NULL;
		if (NoOfQryObj>=1)
		{
			isSTDLive = 1;
		}
	}
	return isSTDLive;
}

int GetDMLAge(char* DMLCreationdate,char* DMLReleasedDate, int option)
{
	struct UDate dt1 = GetDateInUdateFormat(DMLCreationdate);
	
	int diff;
	if (option == 0)
	{
		struct UDate dt2 = GetDateInUdateFormat(DMLReleasedDate);
		diff = getDifference(dt1,dt2);
	}
	else
	{
		struct UDate dt3 =  GetCurrentInUdateFormat();
		diff = getDifference(dt1,dt3);
	}
	printf("\n diff = %d",diff);fflush(stdout);
	return diff;
}

void GetAPLDMLInfo(tag_t APLDMLTag, char* DMLPlantName,char* MBOMDMLProjectCode,char* APLInfo)
{
	printf("\n Enter into GetAPLDMLInfo1");fflush(stdout);
	char* DfltAPLRlzStats = NULL;
	char* DfltAPLRlzStatsName = NULL;
	char* DfltAPLWorkStats = NULL;
	char* DfltAPLWorkStatsName = NULL;
	char* DfltSTDRlzStats = NULL;
	char* DfltSTDRlzStatsName = NULL;
	char* DfltSTDWorkStats = NULL;
	char* DfltSTDWorkStatsName = NULL;
	char* STDLiveStr = NULL;
	DfltAPLRlzStats = (char *) MEM_alloc(20);
	DfltAPLRlzStatsName = (char *) MEM_alloc(20);
	DfltAPLWorkStats = (char *) MEM_alloc(20);
	DfltAPLWorkStatsName = (char *) MEM_alloc(20);
	DfltSTDRlzStats = (char *) MEM_alloc(20);
	DfltSTDRlzStatsName = (char *) MEM_alloc(20);
	DfltSTDRlzStats = (char *) MEM_alloc(20);
	DfltSTDWorkStats = (char *) MEM_alloc(20);
	DfltSTDWorkStatsName = (char *) MEM_alloc(20);
	STDLiveStr = (char *) MEM_alloc(10);
	int APLOption = 0;
	int STDOption = 0;
	if (strcmp(DMLPlantName,"JSR") == 0)
	{
		strcpy(DfltAPLRlzStats,"T5_LcsApljRlzd");
		strcpy(DfltAPLWorkStats,"T5_LcsAPLjWrkg");
		strcpy(DfltSTDWorkStats,"T5_LcsSTDjWrkg");
		strcpy(DfltSTDRlzStats,"T5_LcsStdjRlzd");
		
		strcpy(DfltAPLRlzStatsName,"APLJ Released");
		strcpy(DfltAPLWorkStatsName,"APLJ Working");
		strcpy(DfltSTDWorkStatsName,"STDJ Working");
		strcpy(DfltSTDRlzStatsName,"STDJ Released");
		strcpy(STDLiveStr,"STDJ");
		APLOption = 2;
		STDOption = 7;
	}
	else if (strcmp(DMLPlantName,"PCVBU") == 0)
	{
		printf("\n Enter into GetAPLDMLInfo2");fflush(stdout);
		strcpy(DfltAPLRlzStats,"T5_LcsAplpRlzd");
		strcpy(DfltAPLWorkStats,"T5_LcsAPLpWrkg");
		
		strcpy(DfltSTDWorkStats,"T5_LcsSTDpWrkg");
		strcpy(DfltSTDRlzStats,"T5_LcsStdpRlzd");
		
		strcpy(DfltAPLRlzStatsName,"APLP Released");
		strcpy(DfltAPLWorkStatsName,"APLP Working");
		strcpy(DfltSTDWorkStatsName,"STDP Working");
		strcpy(DfltSTDRlzStatsName,"STDP Released");
		strcpy(STDLiveStr,"STD");
		APLOption = 3;
		STDOption = 8;
	}
	else if (strcmp(DMLPlantName,"LKO") == 0)
	{
		strcpy(DfltAPLRlzStats,"T5_LcsApllRlzd");
		strcpy(DfltAPLWorkStats,"T5_LcsAPLlWrkg");
		
		strcpy(DfltSTDWorkStats,"T5_LcsSTDlWrkg");
		strcpy(DfltSTDRlzStats,"T5_LcsStdlRlzd");
		
		strcpy(DfltAPLRlzStatsName,"APLL Released");
		strcpy(DfltAPLWorkStatsName,"APLL Working");
		strcpy(DfltSTDWorkStatsName,"STDL Working");
		strcpy(DfltSTDRlzStatsName,"STDL Released");
		strcpy(STDLiveStr,"STDL");
		APLOption = 4;
		STDOption = 9;
	}
	else if (strcmp(DMLPlantName,"DWD") == 0)
	{
		strcpy(DfltAPLRlzStats,"T5_LcsApldRlzd");
		strcpy(DfltAPLWorkStats,"T5_LcsAPLdWrkg");
		
		strcpy(DfltSTDWorkStats,"T5_LcsSTDdWrkg");
		strcpy(DfltSTDRlzStats,"T5_LcsStddRlzd");
		
		strcpy(DfltAPLRlzStatsName,"APLD Released");
		strcpy(DfltAPLWorkStatsName,"APLD Working");
		strcpy(DfltSTDWorkStatsName,"STDD Working");
		strcpy(DfltSTDRlzStatsName,"STDD Released");
		strcpy(STDLiveStr,"STDD");
		APLOption = 5;
		
		STDOption = 10;
	}
	else if (strcmp(DMLPlantName,"PNR") == 0)
	{
		strcpy(DfltAPLRlzStats,"T5_LcsApluRlzd");
		strcpy(DfltAPLWorkStats,"T5_LcsAPLuWrkg");
		
		strcpy(DfltSTDWorkStats,"T5_LcsSTDuWrkg");
		strcpy(DfltSTDRlzStats,"T5_LcsStduRlzd");
		
		strcpy(DfltAPLRlzStatsName,"APLU Released");
		strcpy(DfltAPLWorkStatsName,"APLU Working");
		strcpy(DfltSTDWorkStatsName,"STDU Working");
		strcpy(DfltSTDRlzStatsName,"STDU Released");
		strcpy(STDLiveStr,"STDU");
		APLOption = 6;
		STDOption = 11;
	}
	
	if (APLDMLTag != NULLTAG)
	{
		char* APLRlzStatusName = NULL;
		char* APLDMLReleasedDate = NULL;
		char* APLDMLCreationdate = NULL;
		char* APLDMLReleasedDateDup = NULL;
		char* APLDMLCreationdateDup = NULL;
		char* APLDMLDRStatus = NULL;
		char* APLDMLNum = NULL;
		printf("\n Enter into GetAPLDMLInfo3");fflush(stdout);
		AOM_ask_value_string(APLDMLTag,"item_id",&APLDMLNum);
		printf("\n Enter into GetAPLDMLInfo4");fflush(stdout);
		AOM_ask_value_string(APLDMLTag,"t5_cDRstatus",&APLDMLDRStatus);
		APLRlzStatusName = (char *) MEM_alloc(100);
		APLDMLReleasedDate = (char *) MEM_alloc(100);
		APLDMLCreationdate = (char *) MEM_alloc(100);
		GetReleaseDateOfDML(APLDMLTag,APLOption,APLRlzStatusName,APLDMLReleasedDate);
		GetCreationDateOfDML(APLDMLTag,APLDMLCreationdate);
		APLDMLReleasedDateDup = strdup(APLDMLReleasedDate);
		APLDMLCreationdateDup = strdup(APLDMLCreationdate);
		printf("\n APLRlzStatusName = %s",APLRlzStatusName);fflush(stdout);
		printf("\n APLDMLReleasedDate = %s",APLDMLReleasedDate);fflush(stdout);
		if(tc_strcmp(APLRlzStatusName,DfltAPLRlzStats) == 0)
		{
			int APLDMLAge = GetDMLAge(APLDMLCreationdate,APLDMLReleasedDate,0);
			char* StrAPLDMLAge = NULL;
			StrAPLDMLAge =    (char *) MEM_alloc(5);
			sprintf(StrAPLDMLAge,"%d",APLDMLAge);
			RptAPLDMLAge = APLDMLAge;
			
			strcat(APLInfo,APLDMLNum);
			strcat(APLInfo,",");
			strcat(APLInfo,APLDMLCreationdateDup);
			strcat(APLInfo,",");
			strcat(APLInfo,APLDMLReleasedDateDup);
			strcat(APLInfo,",");
			strcat(APLInfo,StrAPLDMLAge);
			strcat(APLInfo,",");
			strcat(APLInfo,DfltAPLRlzStatsName);
			strcat(APLInfo,",");
			
			char* STDDMLCreationdate = NULL;
			char* STDDMLCreationdateDup = NULL;
			char* STDRlzStatusName = NULL;
			char* STDDMLReleasedDate = NULL;
			char* STDDMLReleasedDateDup = NULL;
			STDDMLCreationdate = (char *) MEM_alloc(100);
			STDRlzStatusName = (char *) MEM_alloc(100);
			STDDMLReleasedDate = (char *) MEM_alloc(100);
			int activeSTD = STDLiveForPlant(MBOMDMLProjectCode,DMLPlantName,STDLiveStr);
			if (activeSTD == 1)
			{
				if((tc_strcmp(APLDMLDRStatus,"DR3P")== 0) ||(tc_strcmp(APLDMLDRStatus,"AR3P")== 0)|| 
					(tc_strcmp(APLDMLDRStatus,"DR4")== 0) || (tc_strcmp(APLDMLDRStatus,"AR4")== 0)||
					(tc_strcmp(APLDMLDRStatus,"DR5")== 0) ||(tc_strcmp(APLDMLDRStatus,"AR5")== 0))
				{
					/*tag_t taskjob =NULLTAG;
					tag_t task_job_type =NULLTAG;
													
					EPM_get_current_job(APLDMLTag,&taskjob,&task_job_type);
					if(taskjob!=NULLTAG)
					{
						char* nameoftaskjob = NULL;
						tag_t roottask =NULLTAG;
						char *nameofroot =NULL;
													
						AOM_UIF_ask_value(taskjob,"object_name",&nameoftaskjob);
						printf("\n nameoftaskjob:- %s\n ",nameoftaskjob);
						EPM_ask_root_task(taskjob,&roottask);
						AOM_UIF_ask_value(roottask,"object_name",&nameofroot);
						printf("\n nameofroot:- %s\n ",nameofroot);
						if (tc_strcmp(nameofroot,"STDSI DML WorkFlow") == 0)
						{
							AOM_UIF_ask_value(roottask,"creation_date",&STDDMLCreationdate);
							printf("\n STDDMLCreationdate =%s",STDDMLCreationdate);fflush(stdout);
						}
					}*/
					int n_refs=0,cntRefAPLRln=0;
					int *levels;
					tag_t *referencers;
					char **relations=NULL;
					tag_t objTypeRefTag=NULLTAG;
					char type_name_ref[TCTYPE_name_size_c+1];
					char *nameofroot =NULL;
					int STDFlowFlag = 0;
					
					WSOM_where_referenced2(APLDMLTag, 1,&n_refs,&levels,&referencers,&relations);
					printf("\n\t WSOM_where_referenced levels:%d n_refs: %d ",levels,n_refs); fflush(stdout);
					if (n_refs>0)
					{
						for (cntRefAPLRln=0;cntRefAPLRln<n_refs ;cntRefAPLRln++ )
						{
							//TCTYPE_ask_object_type(referencers[cntRefAPLRln],&objTypeRefTag);
							//TCTYPE_ask_name(objTypeRefTag,type_name_ref);
							//AOM_ask_value_string(referencers[cntRefAPLRln],"object_name",&nameofroot);
							ITK_CALL(WSOM_ask_object_id_string(referencers[cntRefAPLRln],&nameofroot));
							printf("\n nameofroot:- %s\n ",nameofroot);
							
							
							if (tc_strcmp(nameofroot,"STDSI DML WorkFlow") == 0)
							{
								AOM_UIF_ask_value(referencers[cntRefAPLRln],"creation_date",&STDDMLCreationdate);
								printf("\n STDDMLCreationdate =%s",STDDMLCreationdate);fflush(stdout);
								STDFlowFlag = 1;
								break;
							}
						}
					}
					
					STDDMLCreationdateDup = strdup(STDDMLCreationdate);
					if (STDFlowFlag == 1)
					{
						GetReleaseDateOfDML(APLDMLTag,STDOption,STDRlzStatusName,STDDMLReleasedDate);
						printf("\n STDRlzStatusName =%s",STDRlzStatusName);fflush(stdout);
						printf("\n STDDMLReleasedDate =%s",STDDMLReleasedDate);fflush(stdout);
					}
					if(tc_strcmp(STDRlzStatusName,DfltSTDRlzStats) == 0)
					{
						//GetReleaseDateOfDML(APLDMLTag,STDOption,STDRlzStatusName,STDDMLReleasedDate);
						STDDMLReleasedDateDup = strdup(STDDMLReleasedDate);
						int STDDMLAge = GetDMLAge(STDDMLCreationdate,STDDMLReleasedDate,0);
						RptAPLDMLAge = RptAPLDMLAge+ STDDMLAge;
						char* StrSTDDMLAge = NULL;
						StrSTDDMLAge =    (char *) MEM_alloc(5);
						sprintf(StrSTDDMLAge,"%d",STDDMLAge);
						strcat(APLInfo,APLDMLNum);
						strcat(APLInfo,",");
						strcat(APLInfo,STDDMLCreationdateDup);
						strcat(APLInfo,",");
						strcat(APLInfo,STDDMLReleasedDateDup);
						strcat(APLInfo,",");
						strcat(APLInfo,StrSTDDMLAge);
						strcat(APLInfo,",");
						strcat(APLInfo,DfltSTDRlzStatsName);
						strcat(APLInfo,",");
					}
					else if (tc_strcmp(STDDMLCreationdateDup,"") == 0)
					{
						strcat(APLInfo,",");
						strcat(APLInfo,",");
						strcat(APLInfo,",");
						strcat(APLInfo,",");
						strcat(APLInfo,",");
						
					}
					else 
					{
						int STDDMLAge = GetDMLAge(STDDMLCreationdate,STDDMLReleasedDate,1);
						RptAPLDMLAge = RptAPLDMLAge+ STDDMLAge;
						char* StrSTDDMLAge = NULL;
						StrSTDDMLAge =    (char *) MEM_alloc(5);
						sprintf(StrSTDDMLAge,"%d",STDDMLAge);
						strcat(APLInfo,APLDMLNum);
						strcat(APLInfo,",");
						strcat(APLInfo,STDDMLCreationdateDup);
						strcat(APLInfo,",");
						strcat(APLInfo,"");
						strcat(APLInfo,",");
						strcat(APLInfo,StrSTDDMLAge);
						strcat(APLInfo,",");
						strcat(APLInfo,DfltSTDWorkStatsName);
						strcat(APLInfo,",");
					}
				}
				else
				{
					strcat(APLInfo,",");
					strcat(APLInfo,",");
					strcat(APLInfo,",");
					strcat(APLInfo,",");
					strcat(APLInfo,",");
				}
			}
			else
			{
				strcat(APLInfo,",");
				strcat(APLInfo,",");
				strcat(APLInfo,",");
				strcat(APLInfo,",");
				strcat(APLInfo,",");
			}
		}
		else
		{
			int APLDMLAge = GetDMLAge(APLDMLCreationdate,APLDMLReleasedDate,1);
			char* StrAPLDMLAge = NULL;
			StrAPLDMLAge =    (char *) MEM_alloc(5);
			sprintf(StrAPLDMLAge,"%d",APLDMLAge);
			RptAPLDMLAge = APLDMLAge;
			
			tc_strcat(APLInfo,APLDMLNum);
			tc_strcat(APLInfo,",");
			tc_strcat(APLInfo,APLDMLCreationdateDup);
			tc_strcat(APLInfo,",");
			tc_strcat(APLInfo,"");
			tc_strcat(APLInfo,",");
			tc_strcat(APLInfo,StrAPLDMLAge);
			tc_strcat(APLInfo,",");
			tc_strcat(APLInfo,DfltAPLWorkStatsName);
			tc_strcat(APLInfo,",");
			tc_strcat(APLInfo,",");
			tc_strcat(APLInfo,",");
			tc_strcat(APLInfo,",");
			tc_strcat(APLInfo,",");
			tc_strcat(APLInfo,",");
		}
		RptAPLDMLAge = RptAPLDMLAge + RptERCDMLAge + RptMBOMDMLAge;
		char* StrRptAPLDMLAge = NULL;
		StrRptAPLDMLAge =    (char *) MEM_alloc(5);
		sprintf(StrRptAPLDMLAge,"%d",RptAPLDMLAge);
		RptAPLDMLAge = 0;
		tc_strcat(APLInfo,StrRptAPLDMLAge);
		tc_strcat(APLInfo,",");
	}
	else
	{
		tc_strcat(APLInfo,",");
		tc_strcat(APLInfo,",");
		tc_strcat(APLInfo,",");
		tc_strcat(APLInfo,",");
		tc_strcat(APLInfo,",");
		tc_strcat(APLInfo,",");
		tc_strcat(APLInfo,",");
		tc_strcat(APLInfo,",");
		tc_strcat(APLInfo,",");
		tc_strcat(APLInfo,",");
		tc_strcat(APLInfo,",");
	}
	
	
}



void MailReportToUser()
{
	char* DMLAgeReportMail = NULL;
    DMLAgeReportMail = (char *) MEM_alloc(1000);

    char* MailSubject = NULL;
    MailSubject = (char *) MEM_alloc(100);
    tc_strcpy(MailSubject,"DML Age Analysis Report from 01-Jan-2024 to ");
    tc_strcat(MailSubject,EndDate);


    sprintf(DMLAgeReportMail,"(cat content.txt )| Mail -s  \"DML Age Analysis Report from 01-Jan-2024 to %s\" -a %s -c `cat cc.txt` `cat to.txt` ",EndDate,ReportFileName);
	
	printf("\n %s",DMLAgeReportMail);fflush(stdout);
    int SysReturn = 0;
    SysReturn = system(DMLAgeReportMail);
}



void GenerateSMDMLAgeAnalysis(FILE* Report,int* ERCFlownObjectCnt)
{
	
	char* Fromdate = NULL;
	Fromdate = (char *) MEM_alloc(100);
	char* Todate = NULL;
	Todate = (char *) MEM_alloc(100);
	char* TmpStrBld       = NULL;
	TmpStrBld = (char *) MEM_alloc(5000 * sizeof(char *));
	
	
	tc_strcpy(Fromdate,"");
	tc_strcpy(Fromdate,StartDate);
	tc_strcat(Fromdate," 00:00");
	
	tc_strcpy(Todate,"");
	tc_strcpy(Todate,EndDate);
	tc_strcat(Todate," 23:59");
	
	char    	*Qryentry[4]	= {"Item ID","Type","Created After","Created Before"};
	char        *QryValues[4]   = {"**","T5_SMDMLRevision",Fromdate,Todate};
	
	
	tag_t        Qrytag	        = NULLTAG;
	ITK_CALL(QRY_find2("Item Revision...",&Qrytag));
	
	if(Qrytag != NULLTAG)
	{
		int          TotalObjCnt    = 0;
		tag_t       *ObjectsTag     =    NULLTAG;
	
		if(QRY_execute(Qrytag, 4, Qryentry, QryValues, &TotalObjCnt, &ObjectsTag));
		printf("\n No of STD DML Object Found = %d",TotalObjCnt);fflush(stdout);
		int CounterSTDDMLObj = 0;
		for (CounterSTDDMLObj = 0;CounterSTDDMLObj<TotalObjCnt;CounterSTDDMLObj++)
		{
			char* SMDMLNum = NULL;
			AOM_ask_value_string(ObjectsTag[CounterSTDDMLObj],"item_id",&SMDMLNum);
			
			if(tc_strstr(SMDMLNum,"SM")!=NULL)
			{
				char* DMLPlantName = NULL;
				DMLPlantName = (char *) MEM_alloc(10);
				*ERCFlownObjectCnt = *ERCFlownObjectCnt + 1;
				char* StrERCFlownObjectCnt = NULL;
				StrERCFlownObjectCnt =    (char *) MEM_alloc(5);
				sprintf(StrERCFlownObjectCnt,"%d",*ERCFlownObjectCnt);
			
				tc_strcpy(TmpStrBld,"");
				tc_strcat(TmpStrBld,StrERCFlownObjectCnt);
				tc_strcat(TmpStrBld,",");
				
				char* DfltSTDWorkStats = NULL;
				DfltSTDWorkStats =    (char *) MEM_alloc(25);
				
				char* DfltSTDRlzStats = NULL;
				DfltSTDRlzStats =    (char *) MEM_alloc(25);
				
				char* DfltSTDRlzStats1 = NULL;
				DfltSTDRlzStats1 =    (char *) MEM_alloc(25);
				
				char* DfltSTDWorkStatsName = NULL;
				DfltSTDWorkStatsName =    (char *) MEM_alloc(25);
				
				char* DfltSTDRlzStatsName = NULL;
				DfltSTDRlzStatsName =    (char *) MEM_alloc(25);
				
				char* DfltSTDRlzStatsName1 = NULL;
				DfltSTDRlzStatsName1 =    (char *) MEM_alloc(25);
				
				char* SMDMLCreationDate = NULL;
				SMDMLCreationDate =    (char *) MEM_alloc(25);
				
				char* SMDMLCreationDateDup = NULL;
				SMDMLCreationDateDup =    (char *) MEM_alloc(25);
				
				char* SmRlzStatusName = NULL;
				SmRlzStatusName =    (char *) MEM_alloc(25);
				
				char* SMTaskRlzDate = NULL;
				SMTaskRlzDate =    (char *) MEM_alloc(25);
				
				char* SMTaskRlzDateDup = NULL;
				SMTaskRlzDateDup =    (char *) MEM_alloc(25);
				
				GetCreationDateOfDML(ObjectsTag[CounterSTDDMLObj],SMDMLCreationDate);
				SMDMLCreationDateDup = strdup(SMDMLCreationDate);
				
				if(tc_strstr(SMDMLNum,"STDJ")!=NULL)
				{
					strcpy(DMLPlantName,"JSR");
					tc_strcat(TmpStrBld,"STDJ SM DML");
					tc_strcat(TmpStrBld,",");
					strcpy(DfltSTDWorkStatsName,"STDJ Working");
					strcpy(DfltSTDRlzStatsName,"STDJ Restructured");
					strcpy(DfltSTDRlzStatsName1,"STDJ Released");
					strcpy(DfltSTDWorkStats,"T5_LcsSTDjWrkg");
					strcpy(DfltSTDRlzStats,"T5_LcsStdjRestructured");
					strcpy(DfltSTDRlzStats1,"T5_LcsStdjRlzd");
					GetReleaseDateOfDML(ObjectsTag[CounterSTDDMLObj],12,SmRlzStatusName,SMTaskRlzDate);
					SMTaskRlzDateDup = strdup(SMTaskRlzDate);
				}
				if(tc_strstr(SMDMLNum,"STDP")!=NULL)
				{
					strcpy(DMLPlantName,"PCVBU");
					tc_strcat(TmpStrBld,"STDP SM DML");
					tc_strcat(TmpStrBld,",");
					strcpy(DfltSTDWorkStatsName,"STDP Working");
					strcpy(DfltSTDRlzStatsName,"STDP Restructured");
					strcpy(DfltSTDRlzStatsName1,"STDP Released");
					strcpy(DfltSTDWorkStats,"T5_LcsSTDpWrkg");
					strcpy(DfltSTDRlzStats,"T5_LcsStdpRestructured");
					strcpy(DfltSTDRlzStats1,"T5_LcsStdpRlzd");
					GetReleaseDateOfDML(ObjectsTag[CounterSTDDMLObj],13,SmRlzStatusName,SMTaskRlzDate);
					SMTaskRlzDateDup = strdup(SMTaskRlzDate);
				}
				if(tc_strstr(SMDMLNum,"STDL")!=NULL)
				{
					strcpy(DMLPlantName,"LKO");
					tc_strcat(TmpStrBld,"STDL SM DML");
					tc_strcat(TmpStrBld,",");
					strcpy(DfltSTDWorkStatsName,"STDL Working");
					strcpy(DfltSTDRlzStatsName,"STDL Restructured");
					strcpy(DfltSTDRlzStatsName1,"STDL Released");
					strcpy(DfltSTDWorkStats,"T5_LcsSTDlWrkg");
					strcpy(DfltSTDRlzStats,"T5_LcsStdlRestructured");
					strcpy(DfltSTDRlzStats1,"T5_LcsStdlRlzd");
					GetReleaseDateOfDML(ObjectsTag[CounterSTDDMLObj],14,SmRlzStatusName,SMTaskRlzDate);
					SMTaskRlzDateDup = strdup(SMTaskRlzDate);
				}
				if(tc_strstr(SMDMLNum,"STDD")!=NULL)
				{
					strcpy(DMLPlantName,"DWD");
					tc_strcat(TmpStrBld,"STDD SM DML");
					tc_strcat(TmpStrBld,",");
					strcpy(DfltSTDWorkStatsName,"STDD Working");
					strcpy(DfltSTDRlzStatsName,"STDD Restructured");
					strcpy(DfltSTDRlzStatsName1,"STDD Released");
					strcpy(DfltSTDWorkStats,"T5_LcsSTDdWrkg");
					strcpy(DfltSTDRlzStats,"T5_LcsStddRestructured");
					strcpy(DfltSTDRlzStats1,"T5_LcsStddRlzd");
					GetReleaseDateOfDML(ObjectsTag[CounterSTDDMLObj],15,SmRlzStatusName,SMTaskRlzDate);
					SMTaskRlzDateDup = strdup(SMTaskRlzDate);
				}
				if(tc_strstr(SMDMLNum,"STDU")!=NULL)
				{
					strcpy(DMLPlantName,"PNR");
					tc_strcat(TmpStrBld,"STDU SM DML");
					tc_strcat(TmpStrBld,",");
					strcpy(DfltSTDWorkStatsName,"STDU Working");
					strcpy(DfltSTDRlzStatsName,"STDU Restructured");
					strcpy(DfltSTDRlzStatsName1,"STDU Released");
					strcpy(DfltSTDWorkStats,"T5_LcsSTDuWrkg");
					strcpy(DfltSTDRlzStats,"T5_LcsStduRestructured");
					strcpy(DfltSTDRlzStats1,"T5_LcsStduRlzd");
					GetReleaseDateOfDML(ObjectsTag[CounterSTDDMLObj],16,SmRlzStatusName,SMTaskRlzDate);
					SMTaskRlzDateDup = strdup(SMTaskRlzDate);
				}
				
				
				printf("\n SMDMLNum = %s",SMDMLNum);fflush(stdout);
				*ERCFlownObjectCnt = *ERCFlownObjectCnt +1; 
				
				char* STDPRInfomn = NULL;
				STDPRInfomn = (char *) MEM_alloc(200);
				
				strcpy(STDPRInfomn,"");
				
				if(tc_strcmp(DfltSTDRlzStats,SmRlzStatusName) == 0)
				{
					int TaskAge = 0;
					TaskAge = GetDMLAge(SMDMLCreationDate,SMTaskRlzDate,0);
					char* StrRptTaskAge = NULL;
					StrRptTaskAge =    (char *) MEM_alloc(5);
					sprintf(StrRptTaskAge,"%d",TaskAge);
					
					strcpy(STDPRInfomn,SMDMLNum);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,SMDMLCreationDateDup);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,SMTaskRlzDateDup);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,StrRptTaskAge);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,DfltSTDRlzStatsName);
					strcat(STDPRInfomn,",");
					
					strcat(STDPRInfomn,StrRptTaskAge);
					strcat(STDPRInfomn,",");
				}
				else if (tc_strcmp(DfltSTDRlzStats1,SmRlzStatusName) == 0)
				{
					int TaskAge = 0;
					TaskAge = GetDMLAge(SMDMLCreationDate,SMTaskRlzDate,0);
					char* StrRptTaskAge = NULL;
					StrRptTaskAge =    (char *) MEM_alloc(5);
					sprintf(StrRptTaskAge,"%d",TaskAge);
					
					strcpy(STDPRInfomn,SMDMLNum);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,SMDMLCreationDateDup);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,SMTaskRlzDateDup);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,StrRptTaskAge);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,DfltSTDRlzStatsName1);
					strcat(STDPRInfomn,",");
					
					strcat(STDPRInfomn,StrRptTaskAge);
					strcat(STDPRInfomn,",");
				}
				else
				{
					int TaskAge = 0;
					TaskAge = GetDMLAge(SMDMLCreationDate,SMTaskRlzDate,1);
					char* StrRptTaskAge = NULL;
					StrRptTaskAge =    (char *) MEM_alloc(5);
					sprintf(StrRptTaskAge,"%d",TaskAge);
					
					strcpy(STDPRInfomn,SMDMLNum);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,SMDMLCreationDateDup);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,StrRptTaskAge);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,DfltSTDWorkStatsName);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,StrRptTaskAge);
				}
				
				if(tc_strcmp(DMLPlantName,"JSR") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,STDPRInfomn);
					
				}
				if(tc_strcmp(DMLPlantName,"PCVBU") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,STDPRInfomn);
					
				}
				if(tc_strcmp(DMLPlantName,"LKO") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,STDPRInfomn);
					
				}
				if(tc_strcmp(DMLPlantName,"DWD") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,STDPRInfomn);
					
				}
				if(tc_strcmp(DMLPlantName,"PNR") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,STDPRInfomn);
					
				}
				fprintf(Report,"\n %s",TmpStrBld);fflush(Report);
			}
			
			
		}
	}
}





void GeneratePRTaskDMLAgeAnalysis(FILE* Report,int* ERCFlownObjectCnt)
{
	
	char* Fromdate = NULL;
	Fromdate = (char *) MEM_alloc(100);
	char* Todate = NULL;
	Todate = (char *) MEM_alloc(100);
	char* TmpStrBld       = NULL;
	TmpStrBld = (char *) MEM_alloc(5000 * sizeof(char *));
	
	
	tc_strcpy(Fromdate,"");
	tc_strcpy(Fromdate,StartDate);
	tc_strcat(Fromdate," 00:00");
	
	tc_strcpy(Todate,"");
	tc_strcpy(Todate,EndDate);
	tc_strcat(Todate," 23:59");
	
	char    	*Qryentry[4]	= {"Item ID","Type","Created After","Created Before"};
	char        *QryValues[4]   = {"*PR*APL*","T5_APLTaskRevision",Fromdate,Todate};
	
	
	tag_t        Qrytag	        = NULLTAG;
	ITK_CALL(QRY_find2("Item Revision...",&Qrytag));
	
	if(Qrytag != NULLTAG)
	{
		int          TotalObjCnt    = 0;
		tag_t       *ObjectsTag     =    NULLTAG;
	
		if(QRY_execute(Qrytag, 4, Qryentry, QryValues, &TotalObjCnt, &ObjectsTag));
		printf("\n No of STD PR Task Object Found = %d",TotalObjCnt);fflush(stdout);
		int CounterPRTskObj = 0;
		for (CounterPRTskObj = 0;CounterPRTskObj<TotalObjCnt;CounterPRTskObj++)
		{
			char* PRNumber = NULL;
			AOM_ask_value_string(ObjectsTag[CounterPRTskObj],"item_id",&PRNumber);
			
			if(tc_strstr(PRNumber,"PR")!=NULL)
			{
				char* DMLPlantName = NULL;
				DMLPlantName = (char *) MEM_alloc(10);
				*ERCFlownObjectCnt = *ERCFlownObjectCnt + 1;
				char* StrERCFlownObjectCnt = NULL;
				StrERCFlownObjectCnt =    (char *) MEM_alloc(5);
				sprintf(StrERCFlownObjectCnt,"%d",*ERCFlownObjectCnt);
			
				tc_strcpy(TmpStrBld,"");
				tc_strcat(TmpStrBld,StrERCFlownObjectCnt);
				tc_strcat(TmpStrBld,",");
				
				char* DfltSTDWorkStats = NULL;
				DfltSTDWorkStats =    (char *) MEM_alloc(25);
				
				char* DfltSTDRlzStats = NULL;
				DfltSTDRlzStats =    (char *) MEM_alloc(25);
				
				char* DfltSTDWorkStatsName = NULL;
				DfltSTDWorkStatsName =    (char *) MEM_alloc(25);
				
				char* DfltSTDRlzStatsName = NULL;
				DfltSTDRlzStatsName =    (char *) MEM_alloc(25);
				
				char* PRTaskCreationDate = NULL;
				PRTaskCreationDate =    (char *) MEM_alloc(25);
				
				char* PRTaskCreationDateDup = NULL;
				PRTaskCreationDateDup =    (char *) MEM_alloc(25);
				
				char* PRRlzStatusName = NULL;
				PRRlzStatusName =    (char *) MEM_alloc(25);
				
				char* PRTaskRlzDate = NULL;
				PRTaskRlzDate =    (char *) MEM_alloc(25);
				
				char* PRTaskRlzDateDup = NULL;
				PRTaskRlzDateDup =    (char *) MEM_alloc(25);
				
				GetCreationDateOfDML(ObjectsTag[CounterPRTskObj],PRTaskCreationDate);
				PRTaskCreationDateDup = strdup(PRTaskCreationDate);
				
				if(tc_strstr(PRNumber,"APLJ")!=NULL)
				{
					strcpy(DMLPlantName,"JSR");
					tc_strcat(TmpStrBld,"STDJ PR Task");
					tc_strcat(TmpStrBld,",");
					strcpy(DfltSTDWorkStatsName,"STDJ Working");
					strcpy(DfltSTDRlzStatsName,"STDJ Released");
					strcpy(DfltSTDWorkStats,"T5_LcsSTDjWrkg");
					strcpy(DfltSTDRlzStats,"T5_LcsStdjRlzd");
					GetReleaseDateOfDML(ObjectsTag[CounterPRTskObj],7,PRRlzStatusName,PRTaskRlzDate);
					PRTaskRlzDateDup = strdup(PRTaskRlzDate);
				}
				else if(tc_strstr(PRNumber,"APLP")!=NULL)
				{
					strcpy(DMLPlantName,"PCVBU");
					tc_strcat(TmpStrBld,"STDP PR Task");
					tc_strcat(TmpStrBld,",");
					
					strcpy(DfltSTDWorkStatsName,"STDP Working");
					strcpy(DfltSTDRlzStatsName,"STDP Released");
					strcpy(DfltSTDWorkStats,"T5_LcsSTDpWrkg");
					strcpy(DfltSTDRlzStats,"T5_LcsStdpRlzd");
					GetReleaseDateOfDML(ObjectsTag[CounterPRTskObj],8,PRRlzStatusName,PRTaskRlzDate);
					PRTaskRlzDateDup = strdup(PRTaskRlzDate);
				}
				else if(tc_strstr(PRNumber,"APLL")!=NULL)
				{
					strcpy(DMLPlantName,"LKO");
					tc_strcat(TmpStrBld,"STDL PR Task");
					tc_strcat(TmpStrBld,",");
					strcpy(DfltSTDWorkStatsName,"STDL Working");
					strcpy(DfltSTDRlzStatsName,"STDL Released");
					strcpy(DfltSTDWorkStats,"T5_LcsSTDlWrkg");
					strcpy(DfltSTDRlzStats,"T5_LcsStdjRlzd");
					GetReleaseDateOfDML(ObjectsTag[CounterPRTskObj],9,PRRlzStatusName,PRTaskRlzDate);
					PRTaskRlzDateDup = strdup(PRTaskRlzDate);
				}
				else if(tc_strstr(PRNumber,"APLD")!=NULL)
				{
					strcpy(DMLPlantName,"DWD");
					tc_strcat(TmpStrBld,"STDD PR Task");
					tc_strcat(TmpStrBld,",");
					strcpy(DfltSTDWorkStatsName,"STDD Working");
					strcpy(DfltSTDRlzStatsName,"STDD Released");
					strcpy(DfltSTDWorkStats,"T5_LcsSTDdWrkg");
					strcpy(DfltSTDRlzStats,"T5_LcsStddRlzd");
					GetReleaseDateOfDML(ObjectsTag[CounterPRTskObj],10,PRRlzStatusName,PRTaskRlzDate);
					PRTaskRlzDateDup = strdup(PRTaskRlzDate);
				}
				else if(tc_strstr(PRNumber,"APLU")!=NULL)
				{
					strcpy(DMLPlantName,"PNR");
					tc_strcat(TmpStrBld,"STDU PR Task");
					tc_strcat(TmpStrBld,",");
					strcpy(DfltSTDWorkStatsName,"STDU Working");
					strcpy(DfltSTDRlzStatsName,"STDU Released");
					strcpy(DfltSTDWorkStats,"T5_LcsSTDuWrkg");
					strcpy(DfltSTDRlzStats,"T5_LcsStduRlzd");
					GetReleaseDateOfDML(ObjectsTag[CounterPRTskObj],7,PRRlzStatusName,PRTaskRlzDate);
					PRTaskRlzDateDup = strdup(PRTaskRlzDate);
				}
				
				
				printf("\n PRNumber = %s",PRNumber);fflush(stdout);
				*ERCFlownObjectCnt = *ERCFlownObjectCnt +1; 
				
				char* STDPRInfomn = NULL;
				STDPRInfomn = (char *) MEM_alloc(200);
				
				strcpy(STDPRInfomn,"");
				
				if(tc_strcmp(DfltSTDRlzStats,PRRlzStatusName) == 0)
				{
					int TaskAge = 0;
					TaskAge = GetDMLAge(PRTaskCreationDate,PRTaskRlzDate,0);
					char* StrRptTaskAge = NULL;
					StrRptTaskAge =    (char *) MEM_alloc(5);
					sprintf(StrRptTaskAge,"%d",TaskAge);
					
					strcpy(STDPRInfomn,PRNumber);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,PRTaskCreationDateDup);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,PRTaskRlzDateDup);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,StrRptTaskAge);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,DfltSTDRlzStatsName);
					strcat(STDPRInfomn,",");
					
					strcat(STDPRInfomn,StrRptTaskAge);
					strcat(STDPRInfomn,",");
				}
				else
				{
					int TaskAge = 0;
					TaskAge = GetDMLAge(PRTaskCreationDate,PRTaskRlzDate,1);
					char* StrRptTaskAge = NULL;
					StrRptTaskAge =    (char *) MEM_alloc(5);
					sprintf(StrRptTaskAge,"%d",TaskAge);
					
					strcpy(STDPRInfomn,PRNumber);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,PRTaskCreationDateDup);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,StrRptTaskAge);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,DfltSTDWorkStatsName);
					strcat(STDPRInfomn,",");
					strcat(STDPRInfomn,StrRptTaskAge);
				}
				
				if(tc_strcmp(DMLPlantName,"JSR") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,STDPRInfomn);
					
				}
				if(tc_strcmp(DMLPlantName,"PCVBU") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,STDPRInfomn);
					
				}
				if(tc_strcmp(DMLPlantName,"LKO") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,STDPRInfomn);
					
				}
				if(tc_strcmp(DMLPlantName,"DWD") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,STDPRInfomn);
					
				}
				if(tc_strcmp(DMLPlantName,"PNR") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,STDPRInfomn);
					
				}
				fprintf(Report,"\n %s",TmpStrBld);fflush(Report);
			}
			
			
		}
	}
}





void GenerateAMDMLAgeAnalysis(FILE* Report,int* ERCFlownObjectCnt)
{
	
	char* Fromdate = NULL;
	Fromdate = (char *) MEM_alloc(100);
	char* Todate = NULL;
	Todate = (char *) MEM_alloc(100);
	char* TmpStrBld       = NULL;
	TmpStrBld = (char *) MEM_alloc(5000 * sizeof(char *));
	
	
	tc_strcpy(Fromdate,"");
	tc_strcpy(Fromdate,StartDate);
	tc_strcat(Fromdate," 00:00");
	
	tc_strcpy(Todate,"");
	tc_strcpy(Todate,EndDate);
	tc_strcat(Todate," 23:59");
	
	char    	*Qryentry[4]	= {"Name","Type","Created After","Created Before"};
	char        *QryValues[4]   = {"*AM*","T5_APLDMLRevision",Fromdate,Todate};
	
	
	tag_t        Qrytag	        = NULLTAG;
	ITK_CALL(QRY_find2("General...",&Qrytag));
	
	if(Qrytag != NULLTAG)
	{
		int          TotalObjCnt    = 0;
		tag_t       *ObjectsTag     =    NULLTAG;
	
		if(QRY_execute(Qrytag, 4, Qryentry, QryValues, &TotalObjCnt, &ObjectsTag));
		printf("\n No of MBOM DML Object Found = %d",TotalObjCnt);fflush(stdout);
		int CounterAMDMLObj = 0;
		for (CounterAMDMLObj = 0;CounterAMDMLObj<TotalObjCnt;CounterAMDMLObj++)
		{
			char* AMDMLNumber = NULL;
			AOM_ask_value_string(ObjectsTag[CounterAMDMLObj],"item_id",&AMDMLNumber);
			
			if(tc_strstr(AMDMLNumber,"AM")!=NULL)
			{
				char* DMLPlantName = NULL;
				DMLPlantName = (char *) MEM_alloc(10);
				*ERCFlownObjectCnt = *ERCFlownObjectCnt + 1;
				char* StrERCFlownObjectCnt = NULL;
				StrERCFlownObjectCnt =    (char *) MEM_alloc(5);
				sprintf(StrERCFlownObjectCnt,"%d",*ERCFlownObjectCnt);
			
				tc_strcpy(TmpStrBld,"");
				tc_strcat(TmpStrBld,StrERCFlownObjectCnt);
				tc_strcat(TmpStrBld,",");
				
				if(tc_strstr(AMDMLNumber,"APLJ")!=NULL)
				{
					strcpy(DMLPlantName,"JSR");
					tc_strcat(TmpStrBld,"APLJ DML");
					tc_strcat(TmpStrBld,",");
				}
				else if(tc_strstr(AMDMLNumber,"APLP")!=NULL)
				{
					strcpy(DMLPlantName,"PCVBU");
					tc_strcat(TmpStrBld,"APLP DML");
					tc_strcat(TmpStrBld,",");
				}
				else if(tc_strstr(AMDMLNumber,"APLL")!=NULL)
				{
					strcpy(DMLPlantName,"LKO");
					tc_strcat(TmpStrBld,"APLL DML");
					tc_strcat(TmpStrBld,",");
				}
				else if(tc_strstr(AMDMLNumber,"APLD")!=NULL)
				{
					strcpy(DMLPlantName,"DWD");
					tc_strcat(TmpStrBld,"APLD DML");
					tc_strcat(TmpStrBld,",");
				}
				else if(tc_strstr(AMDMLNumber,"APLU")!=NULL)
				{
					strcpy(DMLPlantName,"PNR");
					tc_strcat(TmpStrBld,"APLU DML");
					tc_strcat(TmpStrBld,",");
				}
				
				
				printf("\n AMDMLNumber = %s",AMDMLNumber);fflush(stdout);
				*ERCFlownObjectCnt = *ERCFlownObjectCnt +1; 
				char* APLDMLProjectCode = NULL;
				char* APLDMLInfomn = NULL;
				APLDMLInfomn = (char *) MEM_alloc(200);
				
				AOM_ask_value_string(ObjectsTag[CounterAMDMLObj],"t5_cprojectcode",&APLDMLProjectCode);
				GetAPLDMLInfo(ObjectsTag[CounterAMDMLObj],DMLPlantName,APLDMLProjectCode,APLDMLInfomn);
				if(tc_strcmp(DMLPlantName,"JSR") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,APLDMLInfomn);
				}
				if(tc_strcmp(DMLPlantName,"PCVBU") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,APLDMLInfomn);
				}
				if(tc_strcmp(DMLPlantName,"LKO") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,APLDMLInfomn);
				}
				if(tc_strcmp(DMLPlantName,"DWD") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,APLDMLInfomn);
				}
				if(tc_strcmp(DMLPlantName,"PNR") == 0)
				{
					tc_strcat(TmpStrBld,",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
					tc_strcat(TmpStrBld,APLDMLInfomn);
				}
				fprintf(Report,"\n %s",TmpStrBld);fflush(Report);
			}
			
			
		}
	}
}



void GenerateMBOMDMLAgeAnalysis(FILE* Report,int* ERCFlownObjectCnt)
{
	
	char* Fromdate = NULL;
	Fromdate = (char *) MEM_alloc(100);
	char* Todate = NULL;
	Todate = (char *) MEM_alloc(100);
	char* TmpStrBld       = NULL;
	TmpStrBld = (char *) MEM_alloc(5000 * sizeof(char *));
	
	
	tc_strcpy(Fromdate,"");
	tc_strcpy(Fromdate,StartDate);
	tc_strcat(Fromdate," 00:00");
	
	tc_strcpy(Todate,"");
	tc_strcpy(Todate,EndDate);
	tc_strcat(Todate," 23:59");
	
	char    	*Qryentry[4]	= {"Name","Type","Created After","Created Before"};
	char        *QryValues[4]   = {"*MM*","T5_MBOMDMLRevision",Fromdate,Todate};
	tag_t        Qrytag	        = NULLTAG;
	ITK_CALL(QRY_find2("General...",&Qrytag));
	
	if(Qrytag != NULLTAG)
	{
		int          TotalObjCnt    = 0;
		tag_t       *ObjectsTag     =    NULLTAG;
	
		if(QRY_execute(Qrytag, 4, Qryentry, QryValues, &TotalObjCnt, &ObjectsTag));
		printf("\n No of MBOM DML Object Found = %d",TotalObjCnt);fflush(stdout);
		int CounterMBOMDMLObj = 0;
		for (CounterMBOMDMLObj = 0;CounterMBOMDMLObj<TotalObjCnt;CounterMBOMDMLObj++)
		{
			strcpy(TmpStrBld,"");
			
			*ERCFlownObjectCnt = *ERCFlownObjectCnt + 1;
			char* StrERCFlownObjectCnt = NULL;
			StrERCFlownObjectCnt =    (char *) MEM_alloc(5);
			sprintf(StrERCFlownObjectCnt,"%d",*ERCFlownObjectCnt);
			
			tc_strcat(TmpStrBld,StrERCFlownObjectCnt);
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,"MBOM DML");
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,",");
			tc_strcat(TmpStrBld,",");
			
			char* MBOMDMLNumber = NULL;
			char* MBOMDMLProjectCode = NULL;
			AOM_ask_value_string(ObjectsTag[CounterMBOMDMLObj],"item_id",&MBOMDMLNumber);
			AOM_ask_value_string(ObjectsTag[CounterMBOMDMLObj],"t5_cprojectcode",&MBOMDMLProjectCode);
			printf("\n MBOMDMLNumber = %s",MBOMDMLNumber);fflush(stdout);
			
			char* RlzStatusName = NULL;
			char* DMLReleasedDate = NULL;
			char* DMLCreationdate = NULL;
			char* DMLReleasedDateDup = NULL;
			char* DMLCreationdateDup = NULL;
			RlzStatusName = (char *) MEM_alloc(100);
			DMLReleasedDate = (char *) MEM_alloc(100);
			DMLCreationdate = (char *) MEM_alloc(100);
			GetReleaseDateOfDML(ObjectsTag[CounterMBOMDMLObj],1,RlzStatusName,DMLReleasedDate);
			GetCreationDateOfDML(ObjectsTag[CounterMBOMDMLObj],DMLCreationdate);
			DMLReleasedDateDup = strdup(DMLReleasedDate);
			DMLCreationdateDup = strdup(DMLCreationdate);
			
			
			if(tc_strcmp(RlzStatusName,"T5_MBOMReleased") == 0)
			{
				char* StrMBOMDMLAge = NULL;
				StrMBOMDMLAge =    (char *) MEM_alloc(5);
				int MBOMDMLAge = GetDMLAge(DMLCreationdate,DMLReleasedDate,0);
				sprintf(StrMBOMDMLAge,"%d",MBOMDMLAge);
				
				tc_strcat(TmpStrBld,MBOMDMLNumber);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,DMLCreationdateDup);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,DMLReleasedDateDup);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,StrMBOMDMLAge);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,"MBOM Released");
				tc_strcat(TmpStrBld,",");
				
				int activeAPLJ = APLLiveForPlant(MBOMDMLProjectCode,"JSR");
				tag_t APLDMLTag = NULLTAG;
				char* DMLSubStr = NULL;
				DMLSubStr = (char *) MEM_alloc(100);
				APLDMLTag = NULLTAG;
				tc_strcpy(DMLSubStr,"APLJ");
				APLDMLTag = GetApplicableAPLDMLTag(ObjectsTag[CounterMBOMDMLObj],DMLSubStr);
				if (activeAPLJ == 1 || APLDMLTag != NULLTAG)
				{
					
					char* DMLPlantName = NULL;
					char* APLDMLInfomn = NULL;
					char* APLJDMLNum = NULL;
					
					APLDMLInfomn = (char *) MEM_alloc(200);
					DMLPlantName = (char *) MEM_alloc(10);
					
					tc_strcpy(DMLPlantName,"JSR");
					
					
					
					strcpy(APLDMLInfomn,"");
					GetAPLDMLInfo(APLDMLTag,DMLPlantName,MBOMDMLProjectCode,APLDMLInfomn);
					if (activeAPLJ ==1)
					{
						tc_strcat(TmpStrBld,"Y");
						tc_strcat(TmpStrBld,",");
					}
					else
					{
						tc_strcat(TmpStrBld,"N");
						tc_strcat(TmpStrBld,",");
					}
					tc_strcat(TmpStrBld,APLDMLInfomn);
				}
				else
				{
					tc_strcat(TmpStrBld,"N");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
					
				}
				
				int activeAPLP = APLLiveForPlant(MBOMDMLProjectCode,"PCVBU");
				DMLSubStr = (char *) MEM_alloc(100);
				APLDMLTag = NULLTAG;
				tc_strcpy(DMLSubStr,"APLP");
				APLDMLTag = GetApplicableAPLDMLTag(ObjectsTag[CounterMBOMDMLObj],DMLSubStr);
				if (activeAPLP == 1  || APLDMLTag != NULLTAG)
				{
					
					char* DMLPlantName = NULL;
					char* APLDMLInfomn = NULL;
					char* APLJDMLNum = NULL;
					
					APLDMLInfomn = (char *) MEM_alloc(200);
					DMLPlantName = (char *) MEM_alloc(10);
					
					tc_strcpy(DMLPlantName,"PCVBU");
					
					
					
					strcpy(APLDMLInfomn,"");
					GetAPLDMLInfo(APLDMLTag,DMLPlantName,MBOMDMLProjectCode,APLDMLInfomn);
					if (activeAPLP ==1)
					{
						tc_strcat(TmpStrBld,"Y");
						tc_strcat(TmpStrBld,",");
					}
					else
					{
						tc_strcat(TmpStrBld,"N");
						tc_strcat(TmpStrBld,",");
					}
					tc_strcat(TmpStrBld,APLDMLInfomn);
				}
				else
				{
					tc_strcat(TmpStrBld,"N");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				
				int activeAPLL = APLLiveForPlant(MBOMDMLProjectCode,"LKO");
				DMLSubStr = (char *) MEM_alloc(100);
				APLDMLTag = NULLTAG;
				tc_strcpy(DMLSubStr,"APLL");
				APLDMLTag = GetApplicableAPLDMLTag(ObjectsTag[CounterMBOMDMLObj],DMLSubStr);
				if (activeAPLL == 1 || APLDMLTag !=NULLTAG)
				{
					
					char* DMLPlantName = NULL;
					char* APLDMLInfomn = NULL;
					char* APLJDMLNum = NULL;
					
					APLDMLInfomn = (char *) MEM_alloc(200);
					DMLPlantName = (char *) MEM_alloc(10);
					
					tc_strcpy(DMLPlantName,"LKO");
					
					
					
					strcpy(APLDMLInfomn,"");
					GetAPLDMLInfo(APLDMLTag,DMLPlantName,MBOMDMLProjectCode,APLDMLInfomn);
					if (activeAPLL ==1)
					{
						tc_strcat(TmpStrBld,"Y");
						tc_strcat(TmpStrBld,",");
					}
					else
					{
						tc_strcat(TmpStrBld,"N");
						tc_strcat(TmpStrBld,",");
					}
					tc_strcat(TmpStrBld,APLDMLInfomn);
				}
				else
				{
					tc_strcat(TmpStrBld,"N");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				int activeAPLD = APLLiveForPlant(MBOMDMLProjectCode,"DWD");
				DMLSubStr = (char *) MEM_alloc(100);
				APLDMLTag = NULLTAG;
				tc_strcpy(DMLSubStr,"APLD");
				APLDMLTag = GetApplicableAPLDMLTag(ObjectsTag[CounterMBOMDMLObj],DMLSubStr);
				if (activeAPLD == 1 || APLDMLTag !=NULLTAG)
				{
					
					char* DMLPlantName = NULL;
					char* APLDMLInfomn = NULL;
					char* APLJDMLNum = NULL;
					
					APLDMLInfomn = (char *) MEM_alloc(200);
					DMLPlantName = (char *) MEM_alloc(10);
					
					tc_strcpy(DMLPlantName,"DWD");
					
					
					
					strcpy(APLDMLInfomn,"");
					GetAPLDMLInfo(APLDMLTag,DMLPlantName,MBOMDMLProjectCode,APLDMLInfomn);
					if (activeAPLD ==1)
					{
						tc_strcat(TmpStrBld,"Y");
						tc_strcat(TmpStrBld,",");
					}
					else
					{
						tc_strcat(TmpStrBld,"N");
						tc_strcat(TmpStrBld,",");
					}
					tc_strcat(TmpStrBld,APLDMLInfomn);
				}
				else
				{
					tc_strcat(TmpStrBld,"N");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				
				int activeAPLU = APLLiveForPlant(MBOMDMLProjectCode,"PNR");
				DMLSubStr = (char *) MEM_alloc(100);
				APLDMLTag = NULLTAG;
				tc_strcpy(DMLSubStr,"APLU");
				APLDMLTag = GetApplicableAPLDMLTag(ObjectsTag[CounterMBOMDMLObj],DMLSubStr);
				if (activeAPLU == 1 ||APLDMLTag !=NULLTAG ) 
				{
					
					char* DMLPlantName = NULL;
					char* APLDMLInfomn = NULL;
					char* APLJDMLNum = NULL;
					
					APLDMLInfomn = (char *) MEM_alloc(200);
					DMLPlantName = (char *) MEM_alloc(10);
					
					tc_strcpy(DMLPlantName,"PNR");
				
					
					strcpy(APLDMLInfomn,"");
					GetAPLDMLInfo(APLDMLTag,DMLPlantName,MBOMDMLProjectCode,APLDMLInfomn);
					if (activeAPLU ==1)
					{
						tc_strcat(TmpStrBld,"Y");
						tc_strcat(TmpStrBld,",");
					}
					else
					{
						tc_strcat(TmpStrBld,"N");
						tc_strcat(TmpStrBld,",");
					}
					tc_strcat(TmpStrBld,APLDMLInfomn);
				}
				else
				{
					tc_strcat(TmpStrBld,"N");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
			}
			else
			{
				int MBOMDMLAge = GetDMLAge(DMLCreationdate,DMLReleasedDate,1);
				char* StrMBOMDMLAge = NULL;
				StrMBOMDMLAge =    (char *) MEM_alloc(5);
				sprintf(StrMBOMDMLAge,"%d",MBOMDMLAge);
				
				tc_strcat(TmpStrBld,MBOMDMLNumber);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,DMLCreationdateDup);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,"");
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,StrMBOMDMLAge);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,"MBOM Working");
				tc_strcat(TmpStrBld,",");
				
				
				int activeAPLJ = APLLiveForPlant(MBOMDMLProjectCode,"JSR");
				int activeAPLP = APLLiveForPlant(MBOMDMLProjectCode,"PCVBU");
				int activeAPLL = APLLiveForPlant(MBOMDMLProjectCode,"LKO");
				int activeAPLD = APLLiveForPlant(MBOMDMLProjectCode,"DWD");
				int activeAPLU = APLLiveForPlant(MBOMDMLProjectCode,"PNR");
				if (activeAPLJ == 1)
				{
					tc_strcat(TmpStrBld,"Y");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				else
				{
					tc_strcat(TmpStrBld,"N");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				if (activeAPLP == 1)
				{
					tc_strcat(TmpStrBld,"Y");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				else
				{
					tc_strcat(TmpStrBld,"N");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				if (activeAPLL == 1)
				{
					tc_strcat(TmpStrBld,"Y");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				else
				{
					tc_strcat(TmpStrBld,"N");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				if (activeAPLD == 1)
				{
					tc_strcat(TmpStrBld,"Y");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				else
				{
					tc_strcat(TmpStrBld,"N");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				if (activeAPLU == 1)
				{
					tc_strcat(TmpStrBld,"Y");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
				else
				{
					tc_strcat(TmpStrBld,"N");
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
				}
			}
			fprintf(Report,"\n %s",TmpStrBld);fflush(Report);
		}
	}
}

void GenerateDMLAgeAnalysisReport()
{
	printf("\n GenerateDMLAgeAnalysisReport Started");fflush(stdout);
	
	int ERCFlownObjectCnt = 0;
	char *FromdateDup = NULL;
	char *FromdateDup1 = NULL;
	char *ToDateDup = NULL;
	char *ToDateDup1 = NULL;
	FILE *Report = NULL;
	
	ReportFileName=(char*) MEM_alloc(1000);
	FromdateDup1=(char*) MEM_alloc(10);
	ToDateDup1=(char*) MEM_alloc(10);
	
	
	struct tm *timeinfo;
    time_t t3;
    time_t t1;
    char buffer[256];   
    t1 = time(NULL);
    t3 = shiftDate(t1,0);
    timeinfo = localtime(&t3);
	char 	*RptTimestamp = NULL;
	RptTimestamp = (char *) MEM_alloc(100 * sizeof(char *));
	RptTimestamp = asctime(timeinfo);
	printf("\n%s",RptTimestamp);fflush(stdout);
	
	char * txt1 = NULL;
	char * MonthVal = NULL;
	char * DateVal = NULL;
	char * txt4 = NULL;
	char * YearVal = NULL;
	char * YearVal1 = NULL;
	char * txt6 = NULL;
	txt1 = strtok(RptTimestamp," ");
	MonthVal = strtok(NULL," ");
	DateVal = strtok(NULL," ");
	txt4 = strtok(NULL," ");
	YearVal = strtok(NULL,"");
	YearVal1 = (char *) MEM_alloc(100 * sizeof(char *));
	
	STRNG_replace_str(YearVal,"\n","",&YearVal1);
    printf("\n Start Time..Of Report Generation..%s",MonthVal);fflush(stdout);
    printf("\n Start Time..Of Report Generation..%s",DateVal);fflush(stdout);
    printf("\n Start Time..Of Report Generation..%s",YearVal1);fflush(stdout);
    
	strcpy(EndDate,DateVal);
	strcat(EndDate,"-");
	strcat(EndDate,MonthVal);
	strcat(EndDate,"-");
	strcat(EndDate,YearVal1);
	strcpy(StartDate,"01-Jan-2024");
	//strcpy(StartDate,"01-Mar-2024");
	//strcpy(StartDate,"01-Aug-2023");
	//strcpy(StartDate,"17-Apr-2024");
	//strcpy(EndDate,"26-Feb-2024");
	
	
	FromdateDup = strdup(StartDate);
	ToDateDup = strdup(EndDate);
	
	STRNG_replace_str(FromdateDup,"-","_",&FromdateDup1);
	STRNG_replace_str(ToDateDup,"-","_",&ToDateDup1);
	tc_strcpy(ReportFileName,"");
	tc_strcat(ReportFileName,"DML_Age_Analysis_REPORT_From_");
	tc_strcat(ReportFileName,FromdateDup1);
	tc_strcat(ReportFileName,"_To_");
	tc_strcat(ReportFileName,ToDateDup1);
	tc_strcat(ReportFileName,".csv");
	Report = fopen(ReportFileName,"w");
	
	fprintf(Report,"SL No,DML Initition,ERC DML,ERC Description,ERC DR,ERC Project Code,ERC Design Group,ERC In Date,ERC Out Date,Age Analysis,ERC Release Status,IS MBOM,MBOM DML,MBOM In Date,MBOM Out Date,Age Analysis,Release Status,IS APLJ,APLJ DML,APLJ In Date,APLJ OUT Date,Age Analysis,Release Status,STDJ DML,STDJ In Date,STDJ OUT Date,Age Analysis,Release Status,JSR Age,IS APLP,APLP DML,APLP In Date,APLP OUT Date,Age Analysis,Release Status,STDP DML,STDP In Date,STDP OUT Date,Age Analysis,Release Status,PUNE Age,IS APLL,APLL DML,APLL In Date,APLL OUT Date,Age Analysis,Release Status,STDL DML,STDL In Date,STDL OUT Date,Age Analysis,Release Status,LKO Age,IS APLD,APLD DML,APLD In Date,APLD OUT Date,Age Analysis,Release Status,STDD DML,STDD In Date,STDD OUT Date,Age Analysis,Release Status,DWD Age,IS APLU,APLU DML,APLU In Date,APLU OUT Date,Age Analysis,Release Status,STDU DML,STDU In Date,STDU OUT Date,Age Analysis,Release Status,PNR Age,");fflush(Report);
	

	
	char* Fromdate = NULL;
	Fromdate = (char *) MEM_alloc(100);
	char* Todate = NULL;
	Todate = (char *) MEM_alloc(100);
	
	tc_strcpy(Fromdate,"");
	tc_strcpy(Fromdate,StartDate);
	tc_strcat(Fromdate," 00:00");
	
	tc_strcpy(Todate,"");
	tc_strcpy(Todate,EndDate);
	tc_strcat(Todate," 23:59");
	
    char*   MBOMDesignGrpList = NULL;
	MBOMDesignGrpList = (char *) MEM_alloc(200);
	strcpy(MBOMDesignGrpList,GetApplicableMBOMDesignGroup());
	printf("\n MBOMDesignGrpList =%s",MBOMDesignGrpList);fflush(stdout);
	
	char*   ListRlzTypeNtApliMBOM = NULL;
	ListRlzTypeNtApliMBOM = (char *) MEM_alloc(1000);
	strcpy(ListRlzTypeNtApliMBOM,GetReleaseTypeNotApplicableForMBOM());
	printf("\n ListRlzTypeNtApliMBOM =%s",ListRlzTypeNtApliMBOM);fflush(stdout);
	
	char*   ListRlzTypeNtApliAPL = NULL;
	ListRlzTypeNtApliAPL = (char *) MEM_alloc(1000);
	strcpy(ListRlzTypeNtApliAPL,GetReleaseTypeNotApplicableForAPL());
	printf("\n ListRlzTypeNtApliAPL =%s",ListRlzTypeNtApliAPL);fflush(stdout);
	
	char*   ListRlzTypeNtApliSTD = NULL;
	ListRlzTypeNtApliSTD = (char *) MEM_alloc(1000);
	strcpy(ListRlzTypeNtApliSTD,GetReleaseTypeNotApplicableForSTD());
	printf("\n ListRlzTypeNtApliSTD =%s",ListRlzTypeNtApliSTD);fflush(stdout);
	
	char    	*Qryentry[4]	= {"Name","Type","Created After","Created Before"};
	char        *QryValues[4]   = {"*","ChangeRequestRevision",Fromdate,Todate};
	tag_t        Qrytag	        = NULLTAG;
	ITK_CALL(QRY_find2("General...",&Qrytag));
	if(Qrytag != NULLTAG)
	{
		int          TotalObjCnt    = 0;
		tag_t       *ObjectsTag     =    NULLTAG;
	
		if(QRY_execute(Qrytag, 4, Qryentry, QryValues, &TotalObjCnt, &ObjectsTag));
		printf("\n No of ERC DML Object Found = %d",TotalObjCnt);fflush(stdout);
		
		ERCFlownObjectCnt = TotalObjCnt;
		if(TotalObjCnt > 0)
		{
			int CounterERCDMLObj = 0;
			char* TmpStrBld       = NULL;
			TmpStrBld = (char *) MEM_alloc(5000 * sizeof(char *));
			strcpy(TmpStrBld,"");
			for (CounterERCDMLObj = 0;CounterERCDMLObj<TotalObjCnt;CounterERCDMLObj++)
			{
				printf("\n **********************************************");fflush(stdout);
				char* StrCounterERCDMLObj = NULL;
				char* ERCDMLNum = NULL;
				char* ERCDMLRev = NULL;
				char* ERCDMLProjectCode = NULL;
				char* ERCDMLObjRlzType = NULL;
				char* ERCDMLDRStatus = NULL;
				char* ERCDMLDesc = NULL;
				char** DesignGroupList;
				char* DesignGroupListStr = NULL;
				char* DesignGroupListStrDup = NULL;
				int NumOfDesGrp = 0;
				char* ERCRlzStatusName = NULL;
				char* ERCDMLReleasedDate = NULL;
				char* ERCDMLCreationdate = NULL;
				char* ERCDMLReleasedDateDup = NULL;
				char* ERCDMLCreationdateDup = NULL;
				StrCounterERCDMLObj =    (char *) MEM_alloc(5);
				tc_strcpy(TmpStrBld,"");
				
				
				
				AOM_UIF_ask_value(ObjectsTag[CounterERCDMLObj],"current_desc",&ERCDMLDesc);
				printf("\n ERCDMLDesc = %s",ERCDMLDesc);fflush(stdout);
				char 	*tempPartDesc1               =	NULL;
				char 	*tempPartDesc2               =	NULL;
				tempPartDesc1 = (char *) MEM_alloc(100 * sizeof(char *));
				tempPartDesc2 = (char *) MEM_alloc(100 * sizeof(char *));
				char 	*ERCDMLDescDup             =	NULL;
				ERCDMLDescDup = (char *) MEM_alloc(100 * sizeof(char *));
				STRNG_clean_up_string(ERCDMLDesc);
				
				printf("\n ERCDMLDescDup = %s",ERCDMLDescDup);fflush(stdout);
				AOM_ask_value_string(ObjectsTag[CounterERCDMLObj],"item_id",&ERCDMLNum);
				AOM_ask_value_string(ObjectsTag[CounterERCDMLObj],"current_revision_id",&ERCDMLRev);
				AOM_ask_value_string(ObjectsTag[CounterERCDMLObj],"t5_cprojectcode",&ERCDMLProjectCode);
				AOM_UIF_ask_value(ObjectsTag[CounterERCDMLObj],"t5_rlstype",&ERCDMLObjRlzType);
				AOM_UIF_ask_value(ObjectsTag[CounterERCDMLObj],"t5_cDRstatus",&ERCDMLDRStatus);
				AOM_UIF_ask_value(ObjectsTag[CounterERCDMLObj],"t5_crdesigngroup",&DesignGroupListStr);
				AOM_ask_value_strings(ObjectsTag[CounterERCDMLObj],"t5_crdesigngroup",&NumOfDesGrp,&DesignGroupList);
				
				char 	*ERCDesignGrpTemp            =	NULL;
				ERCDesignGrpTemp = (char *) MEM_alloc(50 * sizeof(char *));
				STRNG_replace_str(DesignGroupListStr,","," ",&DesignGroupListStrDup);
				
				sprintf(StrCounterERCDMLObj,"%d",(CounterERCDMLObj+1));
				tc_strcat(TmpStrBld,StrCounterERCDMLObj);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,"ERC DML");
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,ERCDMLNum);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,ERCDMLDesc);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,ERCDMLDRStatus);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,ERCDMLProjectCode);
				tc_strcat(TmpStrBld,",");
				tc_strcat(TmpStrBld,DesignGroupListStrDup);
				tc_strcat(TmpStrBld,",");
				
				ERCRlzStatusName = (char *) MEM_alloc(100);
				ERCDMLReleasedDate = (char *) MEM_alloc(100);
				ERCDMLCreationdate = (char *) MEM_alloc(100);
				GetReleaseDateOfDML(ObjectsTag[CounterERCDMLObj],0,ERCRlzStatusName,ERCDMLReleasedDate);
				GetCreationDateOfDML(ObjectsTag[CounterERCDMLObj],ERCDMLCreationdate);
				ERCDMLReleasedDateDup = strdup(ERCDMLReleasedDate);
				ERCDMLCreationdateDup = strdup(ERCDMLCreationdate);
				tc_strcat(TmpStrBld,ERCDMLCreationdateDup);
				tc_strcat(TmpStrBld,",");
				
				
				printf("\n ERCDMLNum = %s",ERCDMLNum);fflush(stdout);
				printf("\n ERCDMLRev = %s",ERCDMLRev);fflush(stdout);
				printf("\n ERCRlzStatusName = %s",ERCRlzStatusName);fflush(stdout);
				printf("\n ERCDMLReleasedDateDup = %s",ERCDMLReleasedDateDup);fflush(stdout);
				printf("\n ERCDMLCreationdateDup = %s",ERCDMLCreationdateDup);fflush(stdout);
				printf("\n ERCDMLObjRlzType = %s",ERCDMLObjRlzType);fflush(stdout);
				printf("\n ERCDMLProjectCode = %s",ERCDMLProjectCode);fflush(stdout);
				if ((tc_strstr(ERCRlzStatusName,"T5_LcsErcRlzd")!=NULL))
				{
					
					char* StrERCDMLAge = NULL;
					StrERCDMLAge =    (char *) MEM_alloc(5);
					int ERCDMLAge = GetDMLAge(ERCDMLCreationdate,ERCDMLReleasedDate,0);
					RptERCDMLAge = ERCDMLAge;
					sprintf(StrERCDMLAge,"%d",ERCDMLAge);
					
					tc_strcat(TmpStrBld,ERCDMLReleasedDateDup);
					tc_strcat(TmpStrBld,",");
					tc_strcat(TmpStrBld,StrERCDMLAge);
					tc_strcat(TmpStrBld,",");
					tc_strcat(TmpStrBld,"ERC Released");
					tc_strcat(TmpStrBld,",");
				}
				else
				{
					char* StrERCDMLAge = NULL;
					StrERCDMLAge =    (char *) MEM_alloc(5);
					int ERCDMLAge = GetDMLAge(ERCDMLCreationdate,ERCDMLReleasedDate,1);
					sprintf(StrERCDMLAge,"%d",ERCDMLAge);
					
					tc_strcat(TmpStrBld,"");
					tc_strcat(TmpStrBld,",");
					tc_strcat(TmpStrBld,StrERCDMLAge);
					tc_strcat(TmpStrBld,",");
					tc_strcat(TmpStrBld,"ERC Working");
					tc_strcat(TmpStrBld,",");
					
				}
				
				
				if(tc_strstr(ListRlzTypeNtApliMBOM,ERCDMLObjRlzType)!=NULL)
				{
					tc_strcat(TmpStrBld,"N"); //MBOM
					tc_strcat(TmpStrBld,",,,,,,"); //
					tc_strcat(TmpStrBld,"N"); //APLJ
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
					tc_strcat(TmpStrBld,"N"); //APLP
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
					tc_strcat(TmpStrBld,"N"); //APLL
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
					tc_strcat(TmpStrBld,"N"); //APLD
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
					tc_strcat(TmpStrBld,"N"); //APLU
					tc_strcat(TmpStrBld,",,,,,,,,,,,,");
					fprintf(Report,"\n %s",TmpStrBld);fflush(Report);
					continue;
				}
				else
				{
					int IsApplFrMBOM = 0;
					int IsApplFrAPLJ = 0;
					if ((tc_strstr(ListRlzTypeNtApliMBOM,ERCDMLObjRlzType)==NULL))
					{
					    IsApplFrMBOM = DesignGroupListContainInMBOMDesignGrpList(DesignGroupList,NumOfDesGrp,MBOMDesignGrpList);
					}
					printf("\n IsApplFrMBOM = %d",IsApplFrMBOM);fflush(stdout);
					if (IsApplFrMBOM == 1)
					{
						tag_t MBOMDMLTag = NULLTAG;
						MBOMDMLTag = GetApplicableMBOMDMLTag(ObjectsTag[CounterERCDMLObj]);
						if (MBOMDMLTag != NULLTAG)
						{
							char* RlzStatusName = NULL;
							char* DMLReleasedDate = NULL;
							char* DMLCreationdate = NULL;
							char* DMLReleasedDateDup = NULL;
							char* DMLCreationdateDup = NULL;
							char* MBOMDMLNum = NULL;
							RlzStatusName = (char *) MEM_alloc(100);
							DMLReleasedDate = (char *) MEM_alloc(100);
							DMLCreationdate = (char *) MEM_alloc(100);
							AOM_ask_value_string(MBOMDMLTag,"item_id",&MBOMDMLNum);
							GetReleaseDateOfDML(MBOMDMLTag,1,RlzStatusName,DMLReleasedDate);
							GetCreationDateOfDML(MBOMDMLTag,DMLCreationdate);
							DMLReleasedDateDup = strdup(DMLReleasedDate);
							DMLCreationdateDup = strdup(DMLCreationdate);
							printf("\n MBOMDMLNum = %s",MBOMDMLNum);fflush(stdout);
							if(tc_strcmp(RlzStatusName,"T5_MBOMReleased") == 0)
							{
								char* StrMBOMDMLAge = NULL;
								StrMBOMDMLAge =    (char *) MEM_alloc(5);
								int MBOMDMLAge = GetDMLAge(DMLCreationdate,DMLReleasedDate,0);
								RptMBOMDMLAge = MBOMDMLAge;
								sprintf(StrMBOMDMLAge,"%d",MBOMDMLAge);
								
								tc_strcat(TmpStrBld,"Y");
								tc_strcat(TmpStrBld,",");
								tc_strcat(TmpStrBld,MBOMDMLNum);
								tc_strcat(TmpStrBld,",");
								tc_strcat(TmpStrBld,DMLCreationdateDup);
								tc_strcat(TmpStrBld,",");
								tc_strcat(TmpStrBld,DMLReleasedDateDup);
								tc_strcat(TmpStrBld,",");
								tc_strcat(TmpStrBld,StrMBOMDMLAge);
								tc_strcat(TmpStrBld,",");
								tc_strcat(TmpStrBld,"MBOM Released");
								tc_strcat(TmpStrBld,",");
								
								if ((tc_strstr(ListRlzTypeNtApliAPL,ERCDMLObjRlzType)!=NULL))
								{
									tc_strcat(TmpStrBld,"N"); //APLJ
					                tc_strcat(TmpStrBld,",,,,,,,,,,,");
					                tc_strcat(TmpStrBld,"N"); //APLP
					                tc_strcat(TmpStrBld,",,,,,,,,,,,");
					                tc_strcat(TmpStrBld,"N"); //APLL
					                tc_strcat(TmpStrBld,",,,,,,,,,,,");
					                tc_strcat(TmpStrBld,"N"); //APLD
					                tc_strcat(TmpStrBld,",,,,,,,,,,,");
					                tc_strcat(TmpStrBld,"N"); //APLU
					                tc_strcat(TmpStrBld,",,,,,,,,,,,");
									fprintf(Report,"\n %s",TmpStrBld);fflush(Report);
									continue;
								}
								
								
								
								int activeAPLJ = APLLiveForPlant(ERCDMLProjectCode,"JSR");
								printf("\n activeAPLJ = %d",activeAPLJ);fflush(stdout);
								tag_t APLDMLTag = NULLTAG;
								char* DMLSubStr = NULL;
								DMLSubStr = (char *) MEM_alloc(100);
								APLDMLTag = NULLTAG;
								tc_strcpy(DMLSubStr,"APLJ");
								APLDMLTag = GetApplicableAPLDMLTag(MBOMDMLTag,DMLSubStr);
								
								if (activeAPLJ == 1||APLDMLTag!=NULLTAG)
								{
									
									char* DMLPlantName = NULL;
									char* APLDMLInfomn = NULL;
									char* APLJDMLNum = NULL;
									
									APLDMLInfomn = (char *) MEM_alloc(200);
									DMLPlantName = (char *) MEM_alloc(10);
									tc_strcpy(DMLPlantName,"JSR");
									
					
									strcpy(APLDMLInfomn,"");
									GetAPLDMLInfo(APLDMLTag,DMLPlantName,ERCDMLProjectCode,APLDMLInfomn);
									if (activeAPLJ == 1)
									{
										tc_strcat(TmpStrBld,"Y");
										tc_strcat(TmpStrBld,",");
									}
									else
									{
										tc_strcat(TmpStrBld,"N");
										tc_strcat(TmpStrBld,",");
									}
									tc_strcat(TmpStrBld,APLDMLInfomn);
								}
								else
								{
					               tc_strcat(TmpStrBld,"N,,,,,,,,,,,,");
								}
								
								
								int activeAPLP = APLLiveForPlant(ERCDMLProjectCode,"PCVBU");
								APLDMLTag = NULLTAG;
								tc_strcpy(DMLSubStr,"APLP");
								APLDMLTag = GetApplicableAPLDMLTag(MBOMDMLTag,DMLSubStr);
				                if (activeAPLP == 1 || APLDMLTag !=NULLTAG)
				                {
				                	
				                	char* DMLPlantName = NULL;
				                	char* APLDMLInfomn = NULL;
				                	char* APLJDMLNum = NULL;
				                	
				                	APLDMLInfomn = (char *) MEM_alloc(200);
				                	DMLPlantName = (char *) MEM_alloc(10);
				                	
				                	tc_strcpy(DMLPlantName,"PCVBU");
				                	
				                	strcpy(APLDMLInfomn,"");
				                	GetAPLDMLInfo(APLDMLTag,DMLPlantName,ERCDMLProjectCode,APLDMLInfomn);
									if (activeAPLP == 1)
									{
										tc_strcat(TmpStrBld,"Y");
										tc_strcat(TmpStrBld,",");
									}
									else
									{
										tc_strcat(TmpStrBld,"N");
										tc_strcat(TmpStrBld,",");
									}
				                	tc_strcat(TmpStrBld,APLDMLInfomn);
				                }
				                else
				                {
				                	tc_strcat(TmpStrBld,"N,,,,,,,,,,,,");
				                }
								
								
								int activeAPLL = APLLiveForPlant(ERCDMLProjectCode,"LKO");
								APLDMLTag = NULLTAG;
								tc_strcpy(DMLSubStr,"APLL");
								APLDMLTag = GetApplicableAPLDMLTag(MBOMDMLTag,DMLSubStr);
				                if (activeAPLL == 1||APLDMLTag!=NULLTAG)
				                {
				                	
				                	char* DMLPlantName = NULL;
				                	char* APLDMLInfomn = NULL;
				                	char* APLJDMLNum = NULL;
				                	
				                	APLDMLInfomn = (char *) MEM_alloc(200);
				                	DMLPlantName = (char *) MEM_alloc(10);
				                	
				                	tc_strcpy(DMLPlantName,"LKO");
				                	
				                	
				                	strcpy(APLDMLInfomn,"");
				                	GetAPLDMLInfo(APLDMLTag,DMLPlantName,ERCDMLProjectCode,APLDMLInfomn);
									if (activeAPLL == 1)
									{
										tc_strcat(TmpStrBld,"Y");
										tc_strcat(TmpStrBld,",");
									}
									else
									{
										tc_strcat(TmpStrBld,"N");
										tc_strcat(TmpStrBld,",");
									}
				                	tc_strcat(TmpStrBld,APLDMLInfomn);
				                }
				                else
				                {
				                	tc_strcat(TmpStrBld,"N,,,,,,,,,,,,");
				                }
								
								
								int activeAPLD = APLLiveForPlant(ERCDMLProjectCode,"DWD");
								APLDMLTag = NULLTAG;
								tc_strcpy(DMLSubStr,"APLD");
								APLDMLTag = GetApplicableAPLDMLTag(MBOMDMLTag,DMLSubStr);
				                if (activeAPLD == 1||APLDMLTag !=NULLTAG)
				                {
				                	
				                	char* DMLPlantName = NULL;
				                	char* APLDMLInfomn = NULL;
				                	char* APLJDMLNum = NULL;
				                	
				                	APLDMLInfomn = (char *) MEM_alloc(200);
				                	DMLPlantName = (char *) MEM_alloc(10);
				                	
				                	tc_strcpy(DMLPlantName,"DWD");
				                	
				                	strcpy(APLDMLInfomn,"");
				                	GetAPLDMLInfo(APLDMLTag,DMLPlantName,ERCDMLProjectCode,APLDMLInfomn);
									if (activeAPLD == 1)
									{
										tc_strcat(TmpStrBld,"Y");
										tc_strcat(TmpStrBld,",");
									}
									else
									{
										tc_strcat(TmpStrBld,"N");
										tc_strcat(TmpStrBld,",");
									}
				                	tc_strcat(TmpStrBld,APLDMLInfomn);
				                }
				                else
				                {
				                	tc_strcat(TmpStrBld,"N,,,,,,,,,,,,");
				                }
								
								
								
								int activeAPLU = APLLiveForPlant(ERCDMLProjectCode,"PNR");
								APLDMLTag = NULLTAG;
								tc_strcpy(DMLSubStr,"APLU");
								APLDMLTag = GetApplicableAPLDMLTag(MBOMDMLTag,DMLSubStr);
				                if (activeAPLU == 1||APLDMLTag !=NULLTAG)
				                {
				                	
				                	char* DMLPlantName = NULL;
				                	char* APLDMLInfomn = NULL;
				                	char* APLJDMLNum = NULL;
				                	
				                	APLDMLInfomn = (char *) MEM_alloc(200);
				                	DMLPlantName = (char *) MEM_alloc(10);
				                	
				                	tc_strcpy(DMLPlantName,"PNR");
				                	
				                	
				                	strcpy(APLDMLInfomn,"");
				                	GetAPLDMLInfo(APLDMLTag,DMLPlantName,ERCDMLProjectCode,APLDMLInfomn);
									if (activeAPLU == 1)
									{
										tc_strcat(TmpStrBld,"Y");
										tc_strcat(TmpStrBld,",");
									}
									else
									{
										tc_strcat(TmpStrBld,"N");
										tc_strcat(TmpStrBld,",");
									}
				                	tc_strcat(TmpStrBld,APLDMLInfomn);
				                }
				                else
				                {
				                	tc_strcat(TmpStrBld,"N,,,,,,,,,,,,");
				                }
								
							}
							else 
							{
								int MBOMDMLAge = GetDMLAge(DMLCreationdate,DMLReleasedDate,1);
								char* StrMBOMDMLAge = NULL;
								StrMBOMDMLAge =    (char *) MEM_alloc(5);
								sprintf(StrMBOMDMLAge,"%d",MBOMDMLAge);
								tc_strcat(TmpStrBld,"Y");
								tc_strcat(TmpStrBld,",");
								tc_strcat(TmpStrBld,MBOMDMLNum);
								tc_strcat(TmpStrBld,",");
								tc_strcat(TmpStrBld,DMLCreationdateDup);
								tc_strcat(TmpStrBld,",");
								tc_strcat(TmpStrBld,"");
								tc_strcat(TmpStrBld,",");
								tc_strcat(TmpStrBld,StrMBOMDMLAge);
								tc_strcat(TmpStrBld,",");
								tc_strcat(TmpStrBld,"MBOM Working");
								tc_strcat(TmpStrBld,",");
								
								int activeAPLJ = APLLiveForPlant(ERCDMLProjectCode,"JSR");
								int activeAPLP = APLLiveForPlant(ERCDMLProjectCode,"PCVBU");
								int activeAPLL = APLLiveForPlant(ERCDMLProjectCode,"LKO");
								int activeAPLD = APLLiveForPlant(ERCDMLProjectCode,"DWD");
								int activeAPLU = APLLiveForPlant(ERCDMLProjectCode,"PNR");
								if (activeAPLJ == 1)
								{
									tc_strcat(TmpStrBld,"Y");
									tc_strcat(TmpStrBld,",,,,,,,,,,,,");
								}
								else
								{
									tc_strcat(TmpStrBld,"N");
									tc_strcat(TmpStrBld,",,,,,,,,,,,,");
								}
								if (activeAPLP == 1)
								{
									tc_strcat(TmpStrBld,"Y");
									tc_strcat(TmpStrBld,",,,,,,,,,,,,");
								}
								else
								{
									tc_strcat(TmpStrBld,"N");
									tc_strcat(TmpStrBld,",,,,,,,,,,,,");
								}
								if (activeAPLL == 1)
								{
									tc_strcat(TmpStrBld,"Y");
									tc_strcat(TmpStrBld,",,,,,,,,,,,,");
								}
								else
								{
									tc_strcat(TmpStrBld,"N");
									tc_strcat(TmpStrBld,",,,,,,,,,,,,");
								}
								if (activeAPLD == 1)
								{
									tc_strcat(TmpStrBld,"Y");
									tc_strcat(TmpStrBld,",,,,,,,,,,,,");
								}
								else
								{
									tc_strcat(TmpStrBld,"N");
									tc_strcat(TmpStrBld,",,,,,,,,,,,,");
								}
								if (activeAPLU == 1)
								{
									tc_strcat(TmpStrBld,"Y");
									tc_strcat(TmpStrBld,",,,,,,,,,,,,");
								}
								else
								{
									tc_strcat(TmpStrBld,"N");
									tc_strcat(TmpStrBld,",,,,,,,,,,,,");
								}
								
							}
							
							
							
						}
						else
						{
							tc_strcat(TmpStrBld,"Y"); //MBOM
							tc_strcat(TmpStrBld,",,,,,,"); //
							int activeAPLJ = APLLiveForPlant(ERCDMLProjectCode,"JSR");
							int activeAPLP = APLLiveForPlant(ERCDMLProjectCode,"PCVBU");
							int activeAPLL = APLLiveForPlant(ERCDMLProjectCode,"LKO");
							int activeAPLD = APLLiveForPlant(ERCDMLProjectCode,"DWD");
							int activeAPLU = APLLiveForPlant(ERCDMLProjectCode,"PNR");
							if (activeAPLJ == 1)
							{
								tc_strcat(TmpStrBld,"Y");
								tc_strcat(TmpStrBld,",,,,,,,,,,,,");
							}
							else
							{
								tc_strcat(TmpStrBld,"N");
								tc_strcat(TmpStrBld,",,,,,,,,,,,,");
							}
							if (activeAPLP == 1)
							{
								tc_strcat(TmpStrBld,"Y");
								tc_strcat(TmpStrBld,",,,,,,,,,,,,");
							}
							else
							{
								tc_strcat(TmpStrBld,"N");
								tc_strcat(TmpStrBld,",,,,,,,,,,,,");
							}
							if (activeAPLL == 1)
							{
								tc_strcat(TmpStrBld,"Y");
								tc_strcat(TmpStrBld,",,,,,,,,,,,,");
							}
							else
							{
								tc_strcat(TmpStrBld,"N");
								tc_strcat(TmpStrBld,",,,,,,,,,,,,");
							}
							if (activeAPLD == 1)
							{
								tc_strcat(TmpStrBld,"Y");
								tc_strcat(TmpStrBld,",,,,,,,,,,,,");
							}
							else
							{
								tc_strcat(TmpStrBld,"N");
								tc_strcat(TmpStrBld,",,,,,,,,,,,,");
							}
							if (activeAPLU == 1)
							{
								tc_strcat(TmpStrBld,"Y");
								tc_strcat(TmpStrBld,",,,,,,,,,,,,");
							}
							else
							{
								tc_strcat(TmpStrBld,"N");
								tc_strcat(TmpStrBld,",,,,,,,,,,,,");
							}
							
						}
					}
					if (IsApplFrMBOM == 0)
					{
						
						
						tc_strcat(TmpStrBld,"N,");	
						tc_strcat(TmpStrBld,",");	
						tc_strcat(TmpStrBld,",");	
						tc_strcat(TmpStrBld,",");	
						tc_strcat(TmpStrBld,",");	
						tc_strcat(TmpStrBld,",");	
						if ((tc_strstr(ListRlzTypeNtApliAPL,ERCDMLObjRlzType)==NULL))
						{
							
							
							int activeAPLJ = APLLiveForPlant(ERCDMLProjectCode,"JSR");
							printf("\n activeAPLJ = %d",activeAPLJ);fflush(stdout);
							tag_t APLDMLTag = NULLTAG;
							char* DMLSubStr = NULL;
							DMLSubStr = (char *) MEM_alloc(100);
							APLDMLTag = NULLTAG;
							tc_strcpy(DMLSubStr,"APLJ");
							APLDMLTag = GetApplicableAPLDMLTag(ObjectsTag[CounterERCDMLObj],DMLSubStr);
								
							if (activeAPLJ == 1 ||APLDMLTag !=NULLTAG)
							{
								
								char* DMLPlantName = NULL;
								char* APLDMLInfomn = NULL;
								char* APLJDMLNum = NULL;
								
								APLDMLInfomn = (char *) MEM_alloc(200);
								DMLPlantName = (char *) MEM_alloc(10);
								tc_strcpy(DMLPlantName,"JSR");
								
					
								strcpy(APLDMLInfomn,"");
								GetAPLDMLInfo(APLDMLTag,DMLPlantName,ERCDMLProjectCode,APLDMLInfomn);
								if (activeAPLJ == 1)
								{
									tc_strcat(TmpStrBld,"Y");
									tc_strcat(TmpStrBld,",");
								}
								else
								{
									tc_strcat(TmpStrBld,"N");
									tc_strcat(TmpStrBld,",");
								}
								tc_strcat(TmpStrBld,APLDMLInfomn);
							}
							else
							{
					            tc_strcat(TmpStrBld,"N,,,,,,,,,,,,");
							}
								
							
							
							int activeAPLP = APLLiveForPlant(ERCDMLProjectCode,"PCVBU");
							APLDMLTag = NULLTAG;
							tc_strcpy(DMLSubStr,"APLP");
							APLDMLTag = GetApplicableAPLDMLTag(ObjectsTag[CounterERCDMLObj],DMLSubStr);
				            if (activeAPLP == 1 || APLDMLTag !=NULLTAG)
				            {
				            	
				            	char* DMLPlantName = NULL;
				            	char* APLDMLInfomn = NULL;
				            	char* APLJDMLNum = NULL;
				            	
				            	APLDMLInfomn = (char *) MEM_alloc(200);
				            	DMLPlantName = (char *) MEM_alloc(10);
				            	
				            	tc_strcpy(DMLPlantName,"PCVBU");
				            	
				            	
				            	strcpy(APLDMLInfomn,"");
				            	GetAPLDMLInfo(APLDMLTag,DMLPlantName,ERCDMLProjectCode,APLDMLInfomn);
								if (activeAPLP == 1)
								{
									tc_strcat(TmpStrBld,"Y");
									tc_strcat(TmpStrBld,",");
								}
								else
								{
									tc_strcat(TmpStrBld,"N");
									tc_strcat(TmpStrBld,",");
								}
				            	tc_strcat(TmpStrBld,APLDMLInfomn);
				            }
				            else
				            {
				            	tc_strcat(TmpStrBld,"N,,,,,,,,,,,,");
				            }
								
							
							int activeAPLL = APLLiveForPlant(ERCDMLProjectCode,"LKO");
							APLDMLTag = NULLTAG;
							tc_strcpy(DMLSubStr,"APLL");
							APLDMLTag = GetApplicableAPLDMLTag(ObjectsTag[CounterERCDMLObj],DMLSubStr);
				            if (activeAPLL == 1 || APLDMLTag!=NULLTAG)
				            {
				            	
				            	char* DMLPlantName = NULL;
				            	char* APLDMLInfomn = NULL;
				            	char* APLJDMLNum = NULL;
				            	
				            	APLDMLInfomn = (char *) MEM_alloc(200);
				            	DMLPlantName = (char *) MEM_alloc(10);
				            	
				            	tc_strcpy(DMLPlantName,"LKO");
				            	
				            	
				            	strcpy(APLDMLInfomn,"");
				            	GetAPLDMLInfo(APLDMLTag,DMLPlantName,ERCDMLProjectCode,APLDMLInfomn);
								if (activeAPLL == 1)
								{
									tc_strcat(TmpStrBld,"Y");
									tc_strcat(TmpStrBld,",");
								}
								else
								{
									tc_strcat(TmpStrBld,"N");
									tc_strcat(TmpStrBld,",");
								}
				            	tc_strcat(TmpStrBld,APLDMLInfomn);
				            }
				            else
				            {
				            	tc_strcat(TmpStrBld,"N,,,,,,,,,,,,");
				            }
								
							
							
							int activeAPLD = APLLiveForPlant(ERCDMLProjectCode,"DWD");
							APLDMLTag = NULLTAG;
							tc_strcpy(DMLSubStr,"APLD");
							APLDMLTag = GetApplicableAPLDMLTag(ObjectsTag[CounterERCDMLObj],DMLSubStr);
				            if (activeAPLD == 1 ||APLDMLTag !=NULLTAG)
				            {
				            	
				            	char* DMLPlantName = NULL;
				            	char* APLDMLInfomn = NULL;
				            	char* APLJDMLNum = NULL;
				            	
				            	APLDMLInfomn = (char *) MEM_alloc(200);
				            	DMLPlantName = (char *) MEM_alloc(10);
				            	
				            	tc_strcpy(DMLPlantName,"DWD");
				            	
				            	
				            	strcpy(APLDMLInfomn,"");
				            	GetAPLDMLInfo(APLDMLTag,DMLPlantName,ERCDMLProjectCode,APLDMLInfomn);
								if (activeAPLD == 1)
								{
									tc_strcat(TmpStrBld,"Y");
									tc_strcat(TmpStrBld,",");
								}
								else
								{
									tc_strcat(TmpStrBld,"N");
									tc_strcat(TmpStrBld,",");
								}
				            	tc_strcat(TmpStrBld,APLDMLInfomn);
				            }
				            else
				            {
				            	tc_strcat(TmpStrBld,"N,,,,,,,,,,,,");
				            }
							
								
								
						    int activeAPLU = APLLiveForPlant(ERCDMLProjectCode,"PNR");
							APLDMLTag = NULLTAG;
							tc_strcpy(DMLSubStr,"APLU");
							APLDMLTag = GetApplicableAPLDMLTag(ObjectsTag[CounterERCDMLObj],DMLSubStr);
				            if (activeAPLU == 1 ||APLDMLTag !=NULLTAG)
				            {
				                
				                char* DMLPlantName = NULL;
				                char* APLDMLInfomn = NULL;
				                char* APLJDMLNum = NULL;
				                
				                APLDMLInfomn = (char *) MEM_alloc(200);
				                DMLPlantName = (char *) MEM_alloc(10);
				                
				                tc_strcpy(DMLPlantName,"PNR");
				                
				                
				                strcpy(APLDMLInfomn,"");
				                GetAPLDMLInfo(APLDMLTag,DMLPlantName,ERCDMLProjectCode,APLDMLInfomn);
								if (activeAPLU == 1)
								{
									tc_strcat(TmpStrBld,"Y");
									tc_strcat(TmpStrBld,",");
								}
								else
								{
									tc_strcat(TmpStrBld,"N");
									tc_strcat(TmpStrBld,",");
								}
				                tc_strcat(TmpStrBld,APLDMLInfomn);
				            }
				            else
				            {
								tc_strcat(TmpStrBld,"N,,,,,,,,,,,,");
				            }
								
							
							
							
							
							
							
							
						}
						else
						{
							tc_strcat(TmpStrBld,"N"); //APLJ
					        tc_strcat(TmpStrBld,",,,,,,,,,,,,");
					        tc_strcat(TmpStrBld,"N"); //APLP
					        tc_strcat(TmpStrBld,",,,,,,,,,,,,");
					        tc_strcat(TmpStrBld,"N"); //APLL
					        tc_strcat(TmpStrBld,",,,,,,,,,,,,");
					        tc_strcat(TmpStrBld,"N"); //APLD
					        tc_strcat(TmpStrBld,",,,,,,,,,,,,");
					        tc_strcat(TmpStrBld,"N"); //APLU
					        tc_strcat(TmpStrBld,",,,,,,,,,,,,");
						}
					}
					
				}
				
				
				
				
				
				printf("\n **********************************************");fflush(stdout);
				fprintf(Report,"\n %s",TmpStrBld);fflush(Report);
				RptERCDMLAge = 0;
				RptMBOMDMLAge = 0;
			}
		}
		else
		{
			printf("\n TotalObjCnt Is 0");fflush(stdout);
		}
		
	}
	else
	{
		printf("\n NULL Qry Tag Found");fflush(stdout);
	}
	GenerateMBOMDMLAgeAnalysis(Report,&ERCFlownObjectCnt);
	GenerateAMDMLAgeAnalysis(Report,&ERCFlownObjectCnt);
	GeneratePRTaskDMLAgeAnalysis(Report,&ERCFlownObjectCnt);
	GenerateSMDMLAgeAnalysis(Report,&ERCFlownObjectCnt);
	printf("\n GenerateDMLAgeAnalysisReport Ended");fflush(stdout);
	
	
	MailReportToUser();
	
}



/*******MAIN FUNCTION************/

extern int ITK_user_main (int argc, char* argv[] )
{
	int                 status;
    StartDate  = (char *) MEM_alloc(100 * sizeof(char *));
    EndDate = (char *) MEM_alloc(32);

    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
    ITK_CALL(ITK_set_journalling( TRUE ));
    ITK_CALL(ITK_auto_login ());
    //StartDate = ITK_ask_cli_argument("-StartDate=");
    //EndDate = ITK_ask_cli_argument("-EndDate=");
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
    printf("\n Auto login ");fflush(stdout);

    
   
	
    GenerateDMLAgeAnalysisReport();
	
	return status;
}

