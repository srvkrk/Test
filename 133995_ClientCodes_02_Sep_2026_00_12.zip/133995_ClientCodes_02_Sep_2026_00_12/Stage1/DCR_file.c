/****************************************************************************************************************************
*  Author               :   Mohan Tayade
*  Module               :   Print DCR properties in txt. file format
*  Code                 :   PartToFolder.c
*  Command				:	./DCR_Report -dcr_no=
*  Created on			:   09/09/2021
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*****************************************************************************************************************************/

#include <time.h>
#include <stdio.h>
#include <ae/dataset.h>
#include <epm/epm_toolkit_tc_utils.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <epm/epm.h>
#include <ae/datasettype.h>
#include <ae/dataset.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <pie/pie.h>
#include <sa/user.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#define ITK_err 919002
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
//#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))


char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	//printf("\n count found %s ",mainStringf);fflush(stdout);
	retStringf = (char*) MEM_alloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';

	return retStringf;
} 
static int report_error( char *file, int line, char *function, int return_code)
{
  if (return_code != ITK_ok)
  {
      char *error_msg_string;

      EMH_ask_error_text (return_code, &error_msg_string);
      printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
      TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
      printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
      TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
      if(error_msg_string) MEM_free(error_msg_string);

  }
	return return_code;
}

void print_requirement()
{
	printf(
	"\nHELP:\n"
	"DCR_Report -dcr_no=\n"
	"------------------------------------------------------------------------------------------\n\n"
	);
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );

    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


void strrpl(char * a)
{
	int i = 0;
	//while(a[i]!='\0')
	for (i = 0; a[i] != '\0'; i++)
    {
        if(a[i]==',')
        {
            a[i]=';';
        }
		if(a[i]=='\n')
        {
            a[i]=' ';
        }
    }
}

int ITK_user_main(int argc, char *argv[])
{
	int i=0;
	int propcnt=0;
	int j=0;
	int revcnt=0,mintcnt =0,Dcrpsccnt=0,processcnt=0;
	int workflowtaskcnt=0;
	int desggroup=0;
	int releasecnt=0;
	int n,cnt,tskprtcount,ref_count=0,projcnt=0;
	int status=ITK_ok;
	int attachmentCount=0, transfermodeCnt=0;
	int     DCR_n_entry     = 1;
	int     DCR_rsltCount   = 0;
	IMF_file_t fileDescriptor;
	tag_t           rootTask_t              = NULLTAG;
	tag_t	rev_tag				=  NULLTAG;
	tag_t	dcr_Ref_Rel			=  NULLTAG;
	tag_t	msWordType			=  NULLTAG;
	tag_t	TextType			=  NULLTAG;
	tag_t	RefRelation			=  NULLTAG;
	tag_t	TextLatestDat_t		=  NULLTAG;
	tag_t	TextDataset		=  NULLTAG;
	tag_t	RefRel_t		=  NULLTAG;
	tag_t	filetag		=  NULLTAG;
	tag_t	tool		=  NULLTAG;
	char **ref_list;
	char	*dcrStatus			=  NULL;
	char	*dcrName			=  NULL;
	char	*dcrRevision		=  NULL;
	char	*AffectedDGrp	=  NULL;
	char	*AffectedItem		=  NULL;
	char	*Aggrigte			=  NULL;
	char	*ApproverTD			=  NULL;
	char	*Capt				=  NULL;
	char	*AsyConfRel			=  NULL;
	char	*CatOfChange		=  NULL;
	char	*Cnh_issu_desc		=  NULL;
	char	*Cre_Date			=  NULL;
	char	*DnDInMonths		=  NULL;
	char	*dcrNumber		=  NULL;
	char	*Dt_pro_Amodifi		=  NULL;
	char	*Dt_relea			=  NULL;
	char	*Desig_grp			=  NULL;
	char	*Dets_cat_chg		=  NULL;
	char	*DCRRPTinfo3		=  NULL;
	char	*DCRRPTinfo4		=  NULL;
	char	*DCRRPTinfo5		=  NULL;
	char	*DCRRPTinfo6		=  NULL;
	int SignStatus			=  0;
	char	*Disposit			=  NULL;
	char	*EnvDimensions		=  NULL;
	char	*Failure_Info		=  NULL;
	char	*leadCOC			=  NULL;
	char            *emailCC                    = NULL;
	char            *eMailTo                    = NULL;
	char            *emailBody	                = NULL;
	char            *emailSub	                = NULL;
	char            *emailSub1	                = NULL;
	char	*dcr_loct			=  NULL;
	char	*dcr_matr				=  NULL;
	char	*matur				=  NULL;
	logical  may_chkOtBy;
	char	*mint_ref_no			=  NULL;
	char	*mul_k_info			=  NULL;
	char	*objects_			=  NULL;
	char	*OC_Prop			=  NULL;
	char	*workflow_task			=  NULL;
	char	*owng_user			=  NULL;
	char	*owng_pro			=  NULL;
	char	*pnsc_cat			=  NULL;
	char	*particip			=  NULL;
	char	*particip_disp			=  NULL;
	char	*plans_			=  NULL;
	char	*probms			=  NULL;
	logical probs_modif	;
	char	*me_proc			=  NULL;
	char	*proce_stg			=  NULL;
	char	*proce_stg_lst			=  NULL;
	char	*Pro_appli			=  NULL;
	char	*proj_code			=  NULL;
	char	*proj_id			=  NULL;
	char	*proj_ids			=  NULL;
	char	*pro_nm			=  NULL;
	char	*pro_nmDup			=  NULL;
	char	*proj_obj			=  NULL;
	char	*projID_			=  NULL;
	char	*projects_			=  NULL;
	//char	*proposalE			=  NULL;
	//char	*prop_resp_prty			=  NULL;
	//char	*prop_revever			=  NULL;
	char	*prop_soln			=  NULL;
	char	*protn			=  NULL;
	//char	*publish_by			=  NULL;
	//char	*ratgs			=  NULL;
	char	*Rison			=  NULL;
	char	*ref_itm			=  NULL;
	char	*refrncs			=  NULL;
	logical ref_modifabl		;
	//char	*regul_nmb			=  NULL;
	char	*regl_nmb			=  NULL;
	//char	*reltd_fmea			=  NULL;
	char	*rel_Aprop			=  NULL;
	//char	*rendrng			=  NULL;
	//char	*reprntFr			=  NULL;
	char	*Req_agcy			=  NULL;
	char	*requstr			=  NULL;
	char	*requstr_			=  NULL;
	char	*req_id_			=  NULL;
	char	*revignsID			=  NULL;
	char	*rtcuana			=  NULL;
	int sq_id			=  0;
	int sq_lmt			=  0;
	char	*stgOfPr			=  NULL;
	char	*strWFtsk			=  NULL;
	char	*SubAggr			=  NULL;
	char	*Sun_cata			=  NULL;
	char	*usd_potns			=  NULL;
	char	*capexLk			=  NULL;
	char	*DMC_inR			=  NULL;
	char	*Obje_Typ			=  NULL;
	logical usr_cn_unma	;
	char	*usr_rat_val			=  NULL;
	char	*VC_numb			=  NULL;
	char	*veh_calsifi			=  NULL;
	char	*vehic_for			=  NULL;
	int versi_ltd			=  0;
	char	*weitimp			=  NULL;
	char	*vpg_rem			=  NULL;
	char	*aq_rem			=  NULL;
	char	*cs_rem			=  NULL;
	char	*tvm_rem			=  NULL;
	char	*qa_rem			=  NULL;
	char	*ts_rem			=  NULL;
	char	*vem_rem			=  NULL;
	char	*CE_app			=  NULL;
	char	*PM_app			=  NULL;
	char	*cab1_inp			=  NULL;
	char	*cab2_inp			=  NULL;
	char	*Asuppchange			=  NULL;
	char	*username			=  NULL;
	char	*password			=  NULL;
	char	*dcr_no			=  NULL;
	char	*Chingmt			=  NULL;
	char	*Chmfgpro			=  NULL;
	char	*CurrMatthikness			=  NULL;
	char	*CurrRawMatV			=  NULL;
	char	*Currentsupp			=  NULL;
	char	*Currentwt			=  NULL;
	char	*DcrCPVs			=  NULL;
	char	*DcrComdityAffs			=  NULL;
	char	*DcrEstPrtDevTimes			=  NULL;
	char	*DcrExSvrcCosts			=  NULL;
	char	*DcrExSvrcTimes			=  NULL;
	char	*DcrGrnRptFIRAvails			=  NULL;
	char	*DcrIPTVs			=  NULL;
	char	*DcrInterImpacts			=  NULL;
	char	*DcrMfgTimes			=  NULL;
	char	*DcrNVPs			=  NULL;
	char	*DcrPreValues			=  NULL;
	char	*DcrQltyImpcts			=  NULL;
	char	*DcrServicImpcts			=  NULL;
	char	*DcrTrgIncrCosts			=  NULL;
	char	*DcrTrgIncrImpcts			=  NULL;
	char	*Deschpro			=  NULL;
	char		*emailID					=NULL;
	char * aq_per = NULL;
	char * cs_per = NULL;
	char * qa_per = NULL;
	char * tvm_per = NULL;
	char * ts_per = NULL;
	char * vem_per = NULL;
	char * vpg_per = NULL;
	char * AssignmentName = NULL;
	char * buff = NULL;
	char	*Prt_DR				= NULL;  
	char	*partdesc			= NULL;  
	char	*partID				= NULL;  
	char	*partNo				= NULL;  
	char	*ObjTyp2				= NULL;  
	//char    partNo     =  (char **) MEM_alloc(30 * sizeof(char *));
	int size = 10;
	int DsgnGrp = 0;

	eMailTo=(char *) MEM_alloc(1000 * sizeof(char *));
	emailCC=(char *) MEM_alloc(1000 * sizeof(char *));
	emailBody = (char *) MEM_alloc( 10000 * sizeof(char) );
	emailSub = (char *) MEM_alloc( 500 * sizeof(char) );
	emailSub1 = (char *) MEM_alloc( 500 * sizeof(char) );
	buff=(char *) MEM_alloc(5000 * sizeof(char *));
	partNo = (char *)malloc((size + 1) * sizeof(char));
	char	**design_grp_list	= NULL;
	tag_t	objTypTag			= NULLTAG;
	tag_t	objTag			= NULLTAG;
	tag_t	objTypTag2			= NULLTAG;
	tag_t *taskAttachments=NULLTAG;
	tag_t	relation_type			= NULLTAG;
	tag_t	*dcr_task			= NULLTAG;
	tag_t	relationtype			= NULLTAG;
	tag_t	relationofpart			= NULLTAG;
	tag_t	*dcrprts			= NULLTAG;
	tag_t	*TaskTags			= NULLTAG;
	tag_t job = NULLTAG;
	tag_t	user		= NULLTAG;
	tag_t job_type = NULLTAG;
	tag_t dcr_tag = NULLTAG;
	tag_t roottask = NULLTAG;
	tag_t	person_tagg			= NULLTAG;
	tag_t wftask = NULLTAG;
	tag_t Tasktag = NULLTAG;
	tag_t *subtasks = NULLTAG;
	tag_t *DCRForms = NULLTAG;
	tag_t queryTag = NULLTAG;
	tag_t DCRObjects = NULLTAG;
	int taskcount = 0;
	int TaskCount = 0;
	char *nameofroot =  NULL;
	char *person_namee			= NULL;
	char *wftaskname =  NULL;
	char *cab1per =  NULL;
	char *cab2per =  NULL;
	char *CAB1comt =  NULL;
	char *CAB2comt =  NULL;
	char *fndObjTyp =  NULL;
	char * wtchng = NULL;
	char * cocrmk = NULL;
	char * DFMSever = NULL;
	char * PrtPrcub = NULL;
	char * ValImpt = NULL;
	char *CarMakeby = NULL;
	char *revision_id = NULL;
	char *ReqUserId = NULL;
	char	*moddetails			= NULL;
	char	*objectname			= NULL;
	char	*ObjTyp				= NULL;
	char	* FileDown			= NULL;
	char	* attachname		= NULL;
	char	*cError				= NULL;

	FILE *fd= NULL;

	time_t 	now;
	struct 	tm when;
	tag_t	        *participant_list	    = NULLTAG;
	tag_t           *DCRCntrlObjectTag      = NULLTAG;
	tag_t	         DCRqryTag		        = NULLTAG;
	char            **DCR_qry_values2       =  (char **) MEM_alloc(10 * sizeof(char *));
	char            *DCR_qry_entry[1]       = {"SYSCD"};

	printf("\n CM_DCR_Printrpt Function started...");fflush(stdout);
	
	username      = ITK_ask_cli_argument("-u=");
	password      = ITK_ask_cli_argument("-pf=");
	dcr_no 		= ITK_ask_cli_argument("-dcr_no=");

	time(&now);
	when = *localtime(&now);
	//IMF_file_t fileDescriptor;

	if(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	if(ITK_auto_login( ));
    if(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......\n");fflush(stdout);
	printf("\nLogin Successfull.....!!\n");
	printf("\nWelcome to Teamcenter.....!!\n");

	ITEM_find_item(dcr_no, &dcr_tag);
	if (dcr_tag != NULLTAG)
	{
		printf("\nDCR Number %s found in data base \n",dcr_no);fflush(stdout);
		ITEM_ask_latest_rev(dcr_tag, &rev_tag);
		if (rev_tag != NULLTAG)
		{
			printf("\nDCR Latest Revision for %s is found in data base \n",dcr_no);fflush(stdout);
			FileDown = (char *) MEM_alloc (sizeof (char) * 128);
			attachname = (char *) MEM_alloc (sizeof (char) * 128);

			printf("\nFileDown completed sucessfully \n");fflush(stdout);

			TCTYPE_ask_object_type(rev_tag,&objTypTag);
			if (objTypTag != NULLTAG)
			{
				printf("\nObject Type Tag found sucessfully \n");fflush(stdout);
				TCTYPE_ask_name2(objTypTag,&ObjTyp);
				if (ObjTyp != NULL)
				{
					printf("\n Found Object Type for DCR : \n");fflush(stdout);
					if(tc_strcmp(ObjTyp,"T5_GenDcrChngRepRevision")==0)
					{
						if(QRY_find2("ControlObjects", &DCRqryTag));
						if (DCRqryTag != NULLTAG)
						{
							printf("\n CM_DCR_Printrpt-->-->DCRVali:Found Query ControlObjects \n");fflush(stdout);
							
							DCR_qry_values2[0] = "DCRprintRpt";

							if(QRY_execute(DCRqryTag, DCR_n_entry, DCR_qry_entry, DCR_qry_values2, &DCR_rsltCount, &DCRCntrlObjectTag));
						}
						else
						{
							printf("\n CM_DCR_Printrpt-->-->DCRVali:Not Found Query ControlObjects \n");fflush(stdout);
						}

						printf(" \n CM_DCR_Printrpt-->-->DCRVali:DCR_rsltCount :%d:", DCR_rsltCount); fflush(stdout);
						if(DCR_rsltCount > 0)
						{
							if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo3",&DCRRPTinfo3)!=ITK_ok)   PrintErrorStack();
							printf("\n CM_DCR_Printrpt-->-->DCRRPTinfo3: %s ", DCRRPTinfo3);fflush(stdout);
							if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo4",&DCRRPTinfo4)!=ITK_ok)   PrintErrorStack();
							printf("\n CM_DCR_Printrpt-->-->DCRRPTinfo4: %s ", DCRRPTinfo4);fflush(stdout);
							if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo5",&DCRRPTinfo5)!=ITK_ok)   PrintErrorStack();
							printf("\n CM_DCR_Printrpt-->-->DCRRPTinfo5: %s ", DCRRPTinfo5);fflush(stdout);
							if (AOM_ask_value_string(DCRCntrlObjectTag[0],"t5_Userinfo6",&DCRRPTinfo6)!=ITK_ok)   PrintErrorStack();
							printf("\n CM_DCR_Printrpt-->-->DCRRPTinfo6: %s ", DCRRPTinfo6);fflush(stdout);
						}
						if(AOM_ask_value_string(rev_tag,"item_id",&dcrNumber)!=ITK_ok)PrintErrorStack();
						//if(AOM_ask_value_string(rev_tag,"release_status_list",&dcrStatus)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"object_name",&dcrName)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"item_revision_id",&dcrRevision)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrDesgGrp",&AffectedDGrp)!=ITK_ok)PrintErrorStack();
						printf("\n Size of Affected Design group are %d\n",DsgnGrp);
						

						if(AOM_UIF_ask_value(rev_tag,"EC_affected_item_rel",&AffectedItem)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrAggregate",&Aggrigte)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrAppNam",&ApproverTD)!=ITK_ok)PrintErrorStack();						
						if(AOM_ask_value_string(rev_tag,"t5_DcrCreCatChng",&CatOfChange)!=ITK_ok)PrintErrorStack();						
						if(AOM_ask_value_string(rev_tag,"t5_DcrDesc",&Cnh_issu_desc)!=ITK_ok)PrintErrorStack();
						strrpl(Cnh_issu_desc);						
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrDesgGrp",&Desig_grp)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrG3Subch",&Dets_cat_chg)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_int(rev_tag,"fnd0DSState",&SignStatus)!=ITK_ok)PrintErrorStack();						
						if(AOM_ask_value_string(rev_tag,"CMDisposition",&Disposit)!=ITK_ok)PrintErrorStack();						
						if(AOM_ask_value_string(rev_tag,"t5_EnvDimension",&EnvDimensions)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrCreFI",&Failure_Info)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrMaterial",&dcr_matr)!=ITK_ok)PrintErrorStack();						
						if(AOM_ask_value_string(rev_tag,"CMMaturity",&matur)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_logical(rev_tag,"fnd0IsCheckoutable",&may_chkOtBy)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_MinrefNo",&mint_ref_no)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"fnd0mfkinfo",&mul_k_info)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"fnd0MyWorkflowTasks",&workflow_task)!=ITK_ok)PrintErrorStack();	
						if(AOM_ask_value_string(rev_tag,"object_string",&objects_)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"owning_user",&owng_user)!=ITK_ok)PrintErrorStack();						
						if(AOM_UIF_ask_value(rev_tag,"requestor_user_id",&ReqUserId)!=ITK_ok)PrintErrorStack();						
						if(AOM_UIF_ask_value(rev_tag,"owning_project",&owng_pro)!=ITK_ok)PrintErrorStack();					
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrPSCCategory",&pnsc_cat)!=ITK_ok)PrintErrorStack();		
						if(AOM_UIF_ask_value(rev_tag,"HasParticipant",&particip)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"CMHasWorkBreakdown",&plans_)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"CMHasProblemItem",&probms)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_logical(rev_tag,"cm0IsProblemsModifiable",&probs_modif)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"MEProcess",&me_proc)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"process_stage",&proce_stg)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"process_stage_list",&proce_stg_lst)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrGProg",&Pro_appli)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrProCode",&proj_code)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"project_ids",&proj_ids)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"object_desc",&pro_nm)!=ITK_ok)PrintErrorStack();
						strrpl(pro_nm);
						if(AOM_ask_value_string(rev_tag,"projects_list",&proj_obj)!=ITK_ok)PrintErrorStack();
						//if(AOM_ask_value_string(rev_tag,"t5project",&projID_)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"project_list",&projects_)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrCreProSol",&prop_soln)!=ITK_ok)PrintErrorStack();
						strrpl(prop_soln);
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrLeadCoc",&leadCOC)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrCreRC",&Rison)!=ITK_ok)PrintErrorStack();
						strrpl(Rison);
						if(AOM_UIF_ask_value(rev_tag,"EC_reference_item_rel",&ref_itm)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"IMAN_reference",&refrncs)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_logical(rev_tag,"cm0IsReferencesModifiable",&ref_modifabl)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrRegNo",&regl_nmb)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"cm0RelationsToPropagate",&rel_Aprop)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"release_status_list",&dcrStatus)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrCreAge",&Req_agcy)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"Requestor",&requstr)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"cm0Requestor",&requstr_)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"requestor_user_id",&req_id_)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"revision_list",&revignsID)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrRootCausAnalysis",&rtcuana)!=ITK_ok)PrintErrorStack();
						strrpl(rtcuana);
						if(AOM_ask_value_int(rev_tag,"sequence_id",&sq_id)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_int(rev_tag,"sequence_limit",&sq_lmt)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrCreSP",&stgOfPr)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"fnd0StartedWorkflowTasks",&strWFtsk)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrSubAggregate",&SubAggr)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrCreSubCat",&Sun_cata)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_Dcrtcpxinl",&capexLk)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrtoImDMC",&DMC_inR)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"object_type",&Obje_Typ)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_logical(rev_tag,"user_can_unmanage",&usr_cn_unma)!=ITK_ok)PrintErrorStack();
						//if(AOM_ask_value_string(rev_tag,"s2clUserRatingValue",&usr_rat_val)!=ITK_ok)PrintErrorStack();						
						if(AOM_ask_value_string(rev_tag,"t5_DcrVCNo",&VC_numb)!=ITK_ok)PrintErrorStack();						
						if(AOM_ask_value_string(rev_tag,"t5_DcrVehFor",&vehic_for)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_int(rev_tag,"revision_limit",&versi_ltd)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_DcrWtImpact",&weitimp)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_Asuppchange",&Asuppchange)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_Chingmt",&Chingmt)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_Chmfgpro",&Chmfgpro)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_CurrMatthikness",&CurrMatthikness)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_CurrRawMatV",&CurrRawMatV)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_Currentsupp",&Currentsupp)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_Currentwt",&Currentwt)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrCPVs",&DcrCPVs)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrComdityAffs",&DcrComdityAffs)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrEstPrtDevTimes",&DcrEstPrtDevTimes)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrExSvrcCosts",&DcrExSvrcCosts)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrExSvrcTimes",&DcrExSvrcTimes)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrGrnRptFIRAvails",&DcrGrnRptFIRAvails)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrIPTVs",&DcrIPTVs)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrInterImpacts",&DcrInterImpacts)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrMfgTimes",&DcrMfgTimes)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrNVPs",&DcrNVPs)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrPreValues",&DcrPreValues)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrQltyImpcts",&DcrQltyImpcts)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrServicImpcts",&DcrServicImpcts)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrTrgIncrCosts",&DcrTrgIncrCosts)!=ITK_ok)PrintErrorStack();
						if(AOM_UIF_ask_value(rev_tag,"t5_DcrTrgIncrImpcts",&DcrTrgIncrImpcts)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(rev_tag,"t5_Deschpro",&Deschpro)!=ITK_ok)PrintErrorStack();

						printf("\n MT:DCR Number: [%s]", dcrNumber);fflush(stdout);
						printf("\n MT:DCR Revision: [%s]", dcrRevision);fflush(stdout);
						printf("\n MT:DCR Name: [%s]", dcrName);fflush(stdout);
						//printf("\n MT:DCR Rlease Status: [%s]", dcrStatus);fflush(stdout);
						if(SA_find_user2(ReqUserId, &user)!=ITK_ok)PrintErrorStack();
						if(AOM_load(user)!=ITK_ok)PrintErrorStack();
						if(SA_ask_user_person_name2(user, &person_namee)!=ITK_ok)PrintErrorStack();
						if(SA_find_person2 ( person_namee, &person_tagg)!=ITK_ok)PrintErrorStack();
						if(SA_ask_person_email_address ( person_tagg, &emailID )!=ITK_ok)PrintErrorStack();
						printf("\n MT:DCR emailID is : [%s]", emailID);fflush(stdout);

						//tc_strcpy(FileDown,"/user/uaprodtrl/Program_Shells/DML_Support/Ritesh/");
						//tc_strcpy(FileDown,"/user/testcmi/Dev/devgroups/Prasads/DCR/DCR_Pro_Report/");
						tc_strcpy(FileDown,"");
						tc_strcpy(FileDown,"/tmp/");
						printf("\nFolder creater for the file \n");fflush(stdout);
						tc_strcat(FileDown,dcrNumber);
						tc_strcat(FileDown,"_Details.csv");
						
						tc_strcpy(attachname,"");
						//tc_strcat(attachname,"/tmp/");
						tc_strcat(attachname,dcrNumber);
						tc_strcat(attachname,"_Details.csv");
						printf("\nText file name created [%s]\n",attachname);fflush(stdout);
						TC_write_syslog("Main File = %s\n",FileDown);
						printf("\nFile created at with name [%s] \n",FileDown);fflush(stdout);
						printf("\nWrite report\nDCR Number	%s",dcrNumber);fflush(stdout);
						
						fd = fopen(FileDown,"w");
						
						if(fd==NULL)
						{
							printf("\nError in opening the file \n");fflush(stdout);
							return 1;
						}

						fprintf(fd,",-- DCR Print Report --\n\n"); fflush(fd);
						fprintf(fd,"\n,--DCR (Design Change Request--)");
						fprintf(fd,"\n\nSr NO., ATTRIBUTES				,VALUES");

						fprintf(fd,"\n%d,Project Name/Desc				,%s",n++,pro_nm);fflush(fd);
						fprintf(fd,"\n%d,DCR Number					,%s",n++,dcrNumber);fflush(fd);
						fprintf(fd,"\n%d,Mint Refernce No				,%s",n++,mint_ref_no);fflush(fd);
						fprintf(fd,"\n%d,Project Code					,%s",n++,proj_code);fflush(fd);
						fprintf(fd,"\n%d,Creation Date				,%s",n++,Cre_Date);
						fprintf(fd,"\n%d,Creator							,%s",n++,owng_user);fflush(fd);
						fprintf(fd,"\n%d,Stage of Program				,%s",n++,stgOfPr);fflush(fd);
						fprintf(fd,"\n%d,Requesting Agency				,%s",n++,Req_agcy); fflush(fd);
						fprintf(fd,"\n%d,Reason						,%s",n++,Rison);fflush(fd);
						fprintf(fd,"\n%d,Failure Information				,%s",n++,Failure_Info);fflush(fd);
						fprintf(fd,"\n%d,Affected Design Groups		,%s",n++,AffectedDGrp); fflush(fd);
						fprintf(fd,"\n%d,Lead CoC					,%s",n++,leadCOC);fflush(fd);
						fprintf(fd,"\n%d,Aggregate						,%s",n++,Aggrigte);fflush(fd);
						fprintf(fd,"\n%d,Change/Issue Description			,%s",n++,Cnh_issu_desc);fflush(fd);
						fprintf(fd,"\n%d,Proposed Solution				,%s",n++,prop_soln);fflush(fd);
						fprintf(fd,"\n%d,Root Cause Analysis				,%s",n++,rtcuana);fflush(fd);

						fprintf(fd,"\n\n,--DCR Cost| Time | Quality Impact Summary Approved by CAB--\n");fflush(fd);

						fprintf(fd,"\n%d,CPV (Rs)					,%s",n++,DcrCPVs);fflush(fd);
						fprintf(fd,"\n%d,Targeted Incremental DMC Impact (Rs)			,%s",n++,DcrTrgIncrImpcts);fflush(fd);
						fprintf(fd,"\n%d,IPTV (Rs)					,%s",n++,DcrIPTVs);fflush(fd);
						fprintf(fd,"\n%d,Estimated part development time including tooling development(Months)			,%s",n++,DcrEstPrtDevTimes);fflush(fd);
						fprintf(fd,"\n%d,QUALITY IMPACT for the Change			,%s",n++,DcrQltyImpcts);fflush(fd);
						fprintf(fd,"\n%d,NPV (In Lakhs)					,%s",n++,DcrNVPs);fflush(fd);
						fprintf(fd,"\n%d,Commodity Affected				,%s",n++,DcrComdityAffs);fflush(fd);
						fprintf(fd,"\n%d,Targeted Incremental Capex including tooling cost (In Lakhs)				,%s ",n++,DcrTrgIncrCosts);fflush(fd);
						fprintf(fd,"\n%d,Perceived Value (Rs)				,%s",n++,DcrPreValues); fflush(fd);
						fprintf(fd,"\n%d,Is there any geometry	change in part?			,%s",n++,Chingmt); fflush(fd);
						fprintf(fd,"\n%d,Current material thickness	,%s",n++,CurrMatthikness);fflush(fd);
						fprintf(fd,"\n%d,Current raw material			,%s",n++,CurrRawMatV);fflush(fd);
						fprintf(fd,"\n%d,Current weight of part		,%s",n++,Currentwt);fflush(fd);
						fprintf(fd,"\n%d,Any change in Supplier?				,%s",n++,Asuppchange); fflush(fd);fflush(fd);
						fprintf(fd,"\n%d,Current supplier				,%s",n++,Currentsupp);fflush(fd);
						fprintf(fd,"\n%d,Any change in part manufacturing process? ,%s",n++,Chmfgpro);fflush(fd);
						fprintf(fd,"\n%d,Describe the changes in process				,%s",n++,Deschpro);fflush(fd);
						fprintf(fd,"\n%d,Total Impact (Capex) in Lakhs.			,%s",n++,capexLk);fflush(fd);	
						fprintf(fd,"\n%d,Extra Service Cost (Rs)				,%s",n++,DcrExSvrcCosts);fflush(fd);
						fprintf(fd,"\n%d,Extra Service Time (Single Man Hour)				,%s ",n++,DcrExSvrcTimes); fflush(fd);
						fprintf(fd,"\n%d,Interchangeability Impact			,%s",n++,DcrInterImpacts);fflush(fd);
						fprintf(fd,"\n%d,Serviceability Impact				,%s",n++,DcrServicImpcts); fflush(fd);

						fprintf(fd,"\n\n,--IMPACT ANALYSIS--\n");

						int p = 0;
						fprintf(fd,"\nSr No,Part No,Part Descriptio, Add/Del/Mod ,Weight increase/decrease(gm),COC Remark,DFMEA severity , Is part procurable?, Validation Impact,Car Make Buy ");
						GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
						GRM_list_secondary_objects_only(rev_tag,relation_type,&cnt,&dcr_task);
						printf("\n Task found impacted items : %d\n",cnt);fflush(stdout);
						for(i= 0; i< cnt; i++)
						{
							if(AOM_ask_value_string(dcr_task[i],"object_name",&objectname));
							printf("\n DCR Task name is : %s\n",objectname);fflush(stdout);
							

							GRM_find_relation_type("T5_DcrTskPrt",&relationtype);
							GRM_list_secondary_objects_only(dcr_task[i],relationtype,&tskprtcount,&dcrprts);
							printf("\n [%d] parts are there in DCR Task : %s\n",tskprtcount,objectname);fflush(stdout);
							
							if(tskprtcount > 0)
							{
								fprintf(fd,"\n,--%s--",objectname);
								printf("\n parts in DCR Task : [%s]\n",objectname);fflush(stdout);
								for(j=0; j < tskprtcount; j++)
								{
									p++;

									AOM_ask_value_string(dcrprts[j],"item_id",&partID);
									AOM_UIF_ask_value(dcrprts[j],"item_revision_id",&revision_id);
									printf("\n %d> part [%s] in DCR Task : [%s]\n",p,partID,objectname);fflush(stdout);
									//AOM_ask_value_string(dcrprts[j],"IMAN_master_form_rev",&partNo);
									tc_strcpy(partNo,partID);
									tc_strcat(partNo,"/");
									tc_strcat(partNo,revision_id);
									AOM_ask_value_string(dcrprts[j],"current_desc",&partdesc);
									strrpl(partdesc);

									AOM_UIF_ask_value(dcrprts[j],"t5_CarMakeBuyIndicator",&CarMakeby);

									GRM_find_relation(dcr_task[i],dcrprts[j],relationtype,&relationofpart);
									if(relationofpart != NULLTAG)
									{
										AOM_UIF_ask_value(relationofpart,"t5_ModDetails",&moddetails);
										AOM_UIF_ask_value(relationofpart,"t5_DcrCapImp",&wtchng);
										AOM_UIF_ask_value(relationofpart,"t5_CocRem",&cocrmk);
										strrpl(cocrmk);
										AOM_UIF_ask_value(relationofpart,"t5_DFMSev",&DFMSever);
										AOM_UIF_ask_value(relationofpart,"t5_DcrPrcuPrt",&PrtPrcub);
										AOM_UIF_ask_value(relationofpart,"t5_ValImpact",&ValImpt);
										
										fprintf(fd,"\n%d,%s,%s,%s,%s,%s,%s,%s,%s,%s",p,partNo,partdesc,moddetails,wtchng,cocrmk,DFMSever,PrtPrcub,ValImpt,CarMakeby);
									}
									else
									{
										printf("\n Part to DCR task relation properties not found for: %s & task : %s \n",partID,objectname);fflush(stdout);
									}
								}

							}

						}
						if(EPM_get_current_job(rev_tag,&job,&job_type));
						printf("\n after job\n"); fflush(stdout);							

						if (job != NULLTAG)
						{
							if(EPM_ask_root_task(job,&roottask));
							if(EPM_ask_sub_tasks(roottask,&taskcount,&subtasks));

							if(AOM_UIF_ask_value(roottask,"object_name",&nameofroot));
							printf("\n inside %s \n",nameofroot);

							if(tc_strcmp(nameofroot,"DCR Workflow Template")==0)
							{
								if (taskcount>0)
								{
									for(j=0;j<taskcount;j++)
									{
										wftask = subtasks[j]; 
										if(AOM_UIF_ask_value(wftask,"object_name",&wftaskname));
										printf("\nDCR task name", wftaskname);fflush(stdout);

									
										if (tc_strcmp(wftaskname,"Input AQ Values") == 0)
										{
											printf("\n Inside the 'Input AQ Values' task of DCR [%s]", dcrNumber);fflush(stdout);
											if(AOM_UIF_ask_value(wftask,"fnd0Performer",&aq_per));
											if(AOM_UIF_ask_value(wftask,"comments",&aq_rem));
											strrpl(aq_rem);
											printf("\n AQ Comment: [%s] performer [%s]", aq_rem,aq_per);fflush(stdout);
										}
										else if (tc_strcmp(wftaskname,"Input CS Values") == 0)
										{
											printf("\n Inside the 'Input CS Values' task of DCR [%s]", dcrNumber);fflush(stdout);
											if(AOM_UIF_ask_value(wftask,"comments",&cs_rem));
											ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&cs_per));
											strrpl(cs_rem);
											printf("\n CS Comment: [%s] performer [%s]", cs_rem,cs_per);fflush(stdout);
										}
										else if (tc_strcmp(wftaskname,"Input QA/FMQ Values") == 0)
										{
											printf("\n Inside the 'Input QA/FMQ Values' task of DCR [%s]", dcrNumber);fflush(stdout);
											ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&qa_rem));
											ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&qa_per));
											strrpl(qa_rem);
											printf("\n QA/FMQ Comment: [%s] performer [%s]", qa_rem,qa_per);fflush(stdout);
										}
										else if (tc_strcmp(wftaskname,"Input TVM Values") == 0)
										{
											printf("\n Inside the 'Input TVM Values' task of DCR [%s]", dcrNumber);fflush(stdout);
											ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&tvm_rem));
											ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&tvm_per));
											strrpl(tvm_rem);
											printf("\n TVM Comment: [%s] performer [%s]", tvm_rem, tvm_per);fflush(stdout);
										}
										else if (tc_strcmp(wftaskname,"Input TS Values") == 0)
										{
											printf("\n Inside the 'Input TS Values' task of DCR [%s]", dcrNumber);fflush(stdout);
											ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&ts_rem));
											ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&ts_per));
											strrpl(ts_rem);
											printf("\n TS Comment: [%s] performer [%s]", ts_rem,ts_per);fflush(stdout);
										}
										else if (tc_strcmp(wftaskname,"Input VEM Values") == 0)
										{
											printf("\n Inside the 'Input VEM Values' task of DCR [%s]", dcrNumber);fflush(stdout);
											ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&vem_rem));
											ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&vem_per));
											strrpl(vem_rem);
											printf("\n VEM Comment: [%s] performer [%s]", vem_rem, vem_per);fflush(stdout);
										}
										else if (tc_strcmp(wftaskname,"Input VPG Values") == 0)
										{
											printf("\n Inside the 'Input VPG Values' task of DCR [%s]", dcrNumber);fflush(stdout);
											ITK_CALL(AOM_UIF_ask_value(wftask,"comments",&vpg_rem));
											ITK_CALL(AOM_UIF_ask_value(wftask,"fnd0Performer",&vpg_per));
											strrpl(vpg_rem);
											printf("\n VPG Comment: [%s] performer [%s]", vpg_rem, vpg_per);fflush(stdout);
										}
									}
								}
								ITK_CALL(AOM_ask_value_tags(rev_tag,"fnd0ActuatedInteractiveTsks",&TaskCount,&TaskTags));		
								for(i=0;i<TaskCount;i++)
								{
									Tasktag=TaskTags[i];
									ITK_CALL(AOM_UIF_ask_value(Tasktag,"fnd0AliasTaskName",&AssignmentName));
									ITK_CALL(TCTYPE_ask_object_type(Tasktag, &objTypTag2));
									ITK_CALL(TCTYPE_ask_name2(objTypTag2, &ObjTyp2));
									if((strcmp(ObjTyp2,"Signoff")==0) && (strstr(AssignmentName,"DCR CAB L1 Review")!=NULL))
									{
										ITK_CALL(AOM_UIF_ask_value(Tasktag,"comments",&CAB1comt));
										ITK_CALL(AOM_UIF_ask_value(Tasktag,"fnd0Performer",&cab1per));
										printf("\n CAB1 reviewer :[%s]Comment: [%s]", cab1per,CAB1comt);fflush(stdout);
									}
									if((strcmp(ObjTyp2,"Signoff")==0) && (strstr(AssignmentName,"DCR CAB L2 Review")!=NULL))
									{
										ITK_CALL(AOM_UIF_ask_value(Tasktag,"comments",&CAB2comt));
										ITK_CALL(AOM_UIF_ask_value(Tasktag,"fnd0Performer",&cab2per));
										printf("\n CAB2 reviewer :[%s]Comment: [%s]", cab2per,CAB2comt);fflush(stdout);
									}
								}
							} 
						}
						fprintf(fd,"\n\n,--Affected Agencies feedback: (As Applicable)--\n");
						fprintf(fd,"\n%d,TS Reviewer					,%s",n++,ts_per);fflush(fd);
						fprintf(fd,"\n%d,TS Remarks					,%s",n++,ts_rem);fflush(fd);
						fprintf(fd,"\n%d,AQ Reviewer					,%s",n++,aq_per);fflush(fd);
						fprintf(fd,"\n%d,AQ Remarks					,%s",n++,aq_rem);fflush(fd);
						fprintf(fd,"\n%d,TVM Reviewer					,%s",n++,tvm_per);fflush(fd);
						fprintf(fd,"\n%d,TVM Remarks					,%s",n++,tvm_rem);fflush(fd);
						fprintf(fd,"\n%d,CS Reviewer					,%s",n++,cs_per);fflush(fd);
						fprintf(fd,"\n%d,CS Remarks					,%s",n++,cs_rem);fflush(fd);
						fprintf(fd,"\n%d,QA/FMQ Reviewer				,%s",n++,qa_per);fflush(fd);
						fprintf(fd,"\n%d,QA/FMQ Remarks				,%s",n++,qa_rem);fflush(fd);
						fprintf(fd,"\n%d,VEM Reviewer					,%s",n++,vem_per);fflush(fd);
						fprintf(fd,"\n%d,VEM Remarks					,%s",n++,vem_rem);fflush(fd);
						fprintf(fd,"\n%d,VPG Reviewer					,%s",n++,vpg_per);fflush(fd);
						fprintf(fd,"\n%d,VPG Remarks					,%s",n++,vpg_rem);fflush(fd);
						fprintf(fd,"\n%d,Chief Engineer					,%s",n++,cab1per);fflush(fd);
						fprintf(fd,"\n%d,Program Manager					,%s",n++,cab2per);fflush(fd);
						fprintf(fd,"\n%d,Input from CAB1					,%s",n++,CAB1comt);fflush(fd);
						fprintf(fd,"\n%d,Input from CAB2					,%s",n++,CAB2comt);fflush(fd);
						printf("\nData copied in file....\n"); fflush(stdout);
					}
				}									
			}
		}
	}
	fclose(fd);
	printf("\n*********************");fflush(stdout);
	printf("\nEnd of program.....!!");fflush(stdout);
	printf("\n*********************\n");fflush(stdout);
		
	return ITK_ok;
}
