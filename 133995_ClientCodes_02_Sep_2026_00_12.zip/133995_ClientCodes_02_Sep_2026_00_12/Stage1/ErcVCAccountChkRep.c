/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Akhilesh Kumar
*  Module       :   TCUA/Non-ERC
*  Description  :   Latest ERC Released VC and its child part module address Accountability Check Report
*  File Name    :   tm_ErcRlzVCBOMModAddRep.c
*  Created on   :   Sep 30th, 2024
*  Usage        :   tm_ErcRlzVCBOMModAddRep
*
****************************************************************************/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h> 
#include <pie/pie.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <ug_va_copy.h>
#include <user_exits/user_exits.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

int status =0;

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}


signed long daysInSecond(signed int day){
	return day*24*60*60;
}

long timeInSec(time_t time1) {
	return (long)time1;
}

time_t longTotime_t(long timeInSec){
	return (time_t)timeInSec;
}

time_t shiftDate(time_t idate,signed int day){
	return longTotime_t(timeInSec(idate)+daysInSecond(day));
}

void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y-%H-%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_PartDesc(char* PSrch,char* PRevSeqSrch)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}


void setofTagList(int *count,tag_t **objlist,tag_t obj )
{
	char* childItemName =NULL;
	*count=*count+1;
	if(*count==1)
	{
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	}
	else
	{
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	printf("\n Number Count : [%d]",*count);fflush(stdout);
	(*objlist)[*count-1] = obj; 
	ITKCALL(AOM_ask_value_string((*objlist)[*count-1],"bl_item_item_id",&childItemName));
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	char *RptFile1 = (char *) malloc(400*sizeof(char));
	//FILE *fpOutput_file = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 5;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	
	tag_t DesRev_tag = NULLTAG;
	tag_t ChildDesRev_tag,ChildPT_tag = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *Newitem_revseq_strDup = (char *) malloc(20*sizeof(char));
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	
	char *aggrgrp_desc = NULL;
	char *aggrgrp_desc1 = NULL;
	char *aggrgrp_descdup = NULL;
	char *aggr_DRAR = NULL;
	char *aggr_DRARdup = NULL;
	char *verticle = NULL;
	char *verticledup = NULL;
	
	char Buffer[MAX_LINE_LENGTH];
	char *item_mod_address = NULL;
	char *inp_item_id_Str = NULL;
	char *inp_item_id_StrDup = NULL;
	char*   From_date = NULL;
	char*   To_date = NULL;
	char   				*aggr_DRARrlzstatus     		    = NULL;
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	tag_t** bomLineprtType = NULLTAG;
	tag_t PartMasterTag	= NULLTAG;
	tag_t top_item = NULLTAG;
	char* cItem_Id = NULL;
	char* cItem_RevSeq = NULL;
	char* cItem_Rev = NULL;
	char* cItem_Seq = NULL;
	char* cItem_Desc = NULL;
	char* cModAddress = NULL;
	char* cPartType = NULL;
	char* cPartTypeDup = NULL;
	char* cQuantity = NULL;
	char* cQuantityDup = NULL;
	char* cPTQuantity = NULL;
	tag_t PrtMstrTag = NULLTAG;
	char *MstrUOMTag = NULL;
	char *MstrUOMTagDup = NULL;
	char   				*vc_rlzstatus     		    = NULL;
	int j =0;
	int iNumber_SubChild = 0;
	tag_t tChild = NULLTAG;
	tag_t* tSubChild = NULLTAG;
	int yescount = 0;
	int nocount = 0;
	int maxdrpasscount = 0;
	int maxdrfailcount = 0;
	int compliance = 0;
	int *prtCount = 0; 
	int totalcount = 0;
	int prtcounter     = 0;
	double finalcompliance;
	char total[10];
	int slno = 1;
	char finalslno[10];
	char DTStamp[100] = "";
   
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	char CurrentDate[20]={0};
	getCurrentDateTime(CurrentDate);
	printf("\n\n Current Date is [%s] \n\n",CurrentDate);fflush(stdout);
	struct tm *timeinfo;
	time_t t1;
	time_t t3;
	char buffer[256];
	
	t1 = time(NULL);
    t3 = shiftDate(t1,-1);
	timeinfo = localtime(&t3);
	//timeinfo = localtime(&t1);
	strftime (buffer, 20, "%d-%b-%Y",timeinfo);
	printf("\n Previous Day Date :%s\n",buffer);
	
	From_date = (char *) MEM_alloc(100);
	To_date = (char *) MEM_alloc(100);
	tc_strcpy(From_date,"");
	tc_strcpy(From_date,buffer);
	tc_strcat(From_date," 00:00");
	tc_strcpy(To_date,"");
	tc_strcpy(To_date,buffer);
	tc_strcat(To_date," 23:59");
	printf("\n\n\n\n\nFrom date %s \n",From_date);fflush(stdout);
	printf("\n\n\n\n\nTo date %s \n",To_date);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	
	tc_strcpy(RptFile,"ErcVCRlz_Account_Chk_Rep");
	tc_strcat(RptFile,CurrentDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	
	tc_strcpy(RptFile1,"ErcVC_test");
	tc_strcat(RptFile1,CurrentDate);
	tc_strcat(RptFile1,".csv");
	printf("\n Report File Name: [%s]", RptFile1);fflush(stdout);
	//FILE* fpOutput_file1 = fopen(RptFile1, "w");
	
	printf("\n Report File Generated..!!");fflush(stdout);
	
    FILE* fpOutput_file = fopen(RptFile, "w");
    
	fprintf(fpOutput_file, ",,,Previous Day ERC VC Release Accountability Report Dated %s \n",buffer);fflush(fpOutput_file);
	fprintf(fpOutput_file, ",,,===========================================================\n");fflush(fpOutput_file);
	
    //fprintf(fpOutput_file,"\nVC_Number,Rev,Seq,Desc,DR_Status,F5A15 - QTY - 2,H1A01 - QTY - 1,F3C03 - QTY - 1,H2A01 - QTY - 1,H2A02 - QTY - 1,H2C02 - QTY - 1,F1E05 - QTY - 1,F4A03 - QTY - 1,F4A05 - Present Under VC & CP Module,Part Type - IFD - QTY - 0,Part Type - IFD Module - QTY - 0,Part Type - CAD Module - QTY - 0,Part Type - Dummy - QTY - 0,H1A02 - QTY - 0,H1A03 - QTY - 0,H1A04 - QTY - 0,H1A05 - QTY - 0,H1A06 - QTY - 0,H1A07 - QTY - 0,H1A08 - QTY - 0,H1A09 - QTY - 0,H1A10 - QTY - 0,H1A11 - QTY - 0,H1A12 - QTY - 0,H1A13 - QTY - 0,H2D03 - Y - F5A04 - N/0 \n");fflush(fpOutput_file); 
    //fprintf(fpOutput_file,"\nS No,VC_Number,Rev,Seq,Desc,Vertical,DR_Status,F5A15 - QTY - 2,H1A01 - QTY - 1,F3C03 - QTY - 1,H2A01 - QTY - 1,H2A02 - QTY - 1,H2C02 - QTY - 1,F1E05 - QTY - 1,F4A03 - QTY - 1,Part Type - IFD - QTY - 0,Part Type - IFD Module - QTY - 0,Part Type - CAD Module - QTY - 0,Part Type - Dummy - QTY - 0,H2D03 - Y - F5A04 - N/0 \n");fflush(fpOutput_file); 
    fprintf(fpOutput_file,"\nS No,VC_Number,Rev,Seq,Desc,Vertical,DR_Status,H1A01 - QTY - 1,F3C03 - QTY - 1,H2A01 - QTY - 1,H2A02 - QTY - 1,H2C02 - QTY - 1,F1E05 - QTY - 1,F4A03 - QTY - 1,G1C04 - QTY - 0,G1C05 - QTY - 0,Part Type - IFD - QTY - 0,Part Type - IFD Module - QTY - 0,Part Type - CAD Module - QTY - 0,Part Type - Dummy - QTY - 0,H2D03 - Y - F5A04 - N/0 \n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	printf("\n Finding Query[Latest Released Design Revision for ERC]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("ErcVCAccountChkRep1",&tItemobj));
    if(tItemobj != NULLTAG)
	{
				printf("\n Query Latest Released Design Revision for ERC Tag Found Successfully..!!\n");fflush(stdout);
				char *cEntries[5]  = {"ID","LifeCycleState","Released After","Released Before","Part Type"};
				//char *cValues[5]  = {"*","T5_LcsErcRlzd","15-Nov-2024 00:00","18-Nov-2024 00:00","V"};
				char *cValues[5]  = {"*","T5_LcsErcRlzd",From_date,To_date,"V"};
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
				printf("\n Latest ERC Released Total Vehicle Found: [%d]\n",n_itemobj_found);fflush(stdout);
				printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
				int vccount = 0;
				if(n_itemobj_found > 0)
				{
					//for(vccount = 0; vccount < 3; vccount++)
					for(vccount = 0; vccount < n_itemobj_found; vccount++)
					{
						printf("\n value of vccount[%d]",vccount);fflush(stdout);
					
						DesRev_tag = titemobj_results[vccount];
						
						ITK_CALL(AOM_UIF_ask_value(DesRev_tag,"release_status_list",&vc_rlzstatus));
						printf("\n VC Released status := [%s]",vc_rlzstatus);fflush(stdout);
						
						if(tc_strstr(vc_rlzstatus,"ERC Released")!= NULL ||(tc_strstr(vc_rlzstatus,"T5_LcsErcRlzd")!=NULL))   //vc_rlzstatus contains "ERC Released,MBOM Released"
						{
							prtcounter++;					
							ITK_CALL(AOM_ask_value_string(DesRev_tag,"item_id",&item_id_str));
							
							ITK_CALL(AOM_ask_value_string(DesRev_tag,"item_revision_id",&item_revseq_str));
							if(tc_strlen(item_revseq_str)>0)
							{
								tc_strdup(item_revseq_str,&item_revseq_strDup);
								trimwhitespace(item_revseq_strDup);
							}
							else
							{
								tc_strdup("--",&item_revseq_strDup);
								printf("\n Vehicle Revision Sequence Value is NULL..!!");fflush(stdout);
							}
							
							tc_strcpy(Newitem_revseq_strDup,"");
							tc_strcpy(Newitem_revseq_strDup,item_revseq_strDup);
							
							
							item_rev_strDup=strtok(Newitem_revseq_strDup,";");
							item_seq_strDup=strtok(NULL,";");
							
							ITK_CALL(AOM_ask_value_string(DesRev_tag,"object_desc",&aggrgrp_desc));
							//trimwhitespace(aggrgrp_desc);
							ITK_CALL(STRNG_replace_str(aggrgrp_desc,","," ",&aggrgrp_desc1));
							if(aggrgrp_desc1!=NULL)tc_strdup(aggrgrp_desc1,&aggrgrp_descdup);
							
							ITK_CALL(AOM_ask_value_string(DesRev_tag,"t5_PartStatus",&aggr_DRAR));
							trimwhitespace(aggr_DRAR);
							if(aggr_DRAR!=NULL)tc_strdup(aggr_DRAR,&aggr_DRARdup);
							
							ITK_CALL(AOM_ask_value_string(DesRev_tag,"t5_Platform",&verticle));
							trimwhitespace(verticle);
							if(verticle!=NULL)tc_strdup(verticle,&verticledup);
							
							fprintf(fpOutput_file,"\n%d,%s,%s,%s,%s,%s,%s,",prtcounter,item_id_str,item_rev_strDup,item_seq_strDup,aggrgrp_descdup,verticledup,aggr_DRARdup);fflush(fpOutput_file);
							
							ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
							ITK_CALL(CFM_find("ERC release and above", &topsubrule));
							ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
							ITK_CALL(PIE_find_closure_rules("BOMViewClosureRuleERC",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
							if (subrulefound > 0)
							{
								sub_close_tag = subclosurerule[0];
							}
							
							ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
							ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
							ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, DesRev_tag, NULLTAG, &t_top_Sub_Child));
							ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
							printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
							int VCChildCount,prttypeCnt=0;
							if(itopSubNumber_Child>0)
							{
								//int F5A15_Qty=0;
								int H1A01_Qty=0;
								int F3C03_Qty=0;
								int H2A01_Qty=0;
								int H2A02_Qty=0;
								int H2C02_Qty=0;
								int F1E05_Qty=0;
								int F4A03_Qty=0;
								int G1C04_Qty=0;
								int G1C05_Qty=0;
								int H2D03_Qty=0;
								int F5A04_Qty=0;
								int H1A04_Qty=0;
								
								//int F5A15_Mod=0;
								int H1A01_Mod=0;
								int F3C03_Mod=0;
								int H2A01_Mod=0;
								int H2A02_Mod=0;
								int H2C02_Mod=0;
								int F1E05_Mod=0;
								int F4A03_Mod=0;
								int G1C04_Mod=0;
								int G1C05_Mod=0;
								int H2D03_Mod=0;
								int F5A04_Mod=0;
								int H1A04_Mod=0;
								int DummyMod_Mod=0;
								int DummyMod_Qty=0;
								int CADMod_Qty=0;
								int CADMod_Mod=0;
								int IFDMod_Qty=0;
								int IFDMod_Mod=0;
								int IFD_Qty=0;
								int IFD_Mod=0;
								int AllCPMod=0;
								int FewCPMod=0;
								
								for(VCChildCount = 0; VCChildCount < itopSubNumber_Child; VCChildCount++)
								{
									printf("\n value of VCChildCount[%d]",VCChildCount);fflush(stdout);
									ChildDesRev_tag = NULLTAG;
									ChildDesRev_tag = ttop_BOM_Children[VCChildCount];
									
									ITK_CALL(AOM_UIF_ask_value(ChildDesRev_tag, "bl_item_item_id", &cItem_Id));
									trimwhitespace(cItem_Id);
									printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
									
									cModAddress = NULL;
									cModAddress = subString(cItem_Id, 4, 5);
									trimwhitespace(cModAddress);
									printf("\n Part Module Address Value: [%s]", cModAddress);fflush(stdout);
									
									cQuantityDup = NULL;
									cQuantity = NULL;
									ITK_CALL(AOM_UIF_ask_value(ChildDesRev_tag, "bl_quantity", &cQuantity));
									if(tc_strlen(cQuantity)>0)
									{
										tc_strdup(cQuantity,&cQuantityDup);
									}
									else
									{
										tc_strcpy(cQuantity,"0");
										tc_strdup(cQuantity,&cQuantityDup);
									}
									
									printf(" Akki Akhilesh in bom_sub_child\n");fflush(stdout);
									trimwhitespace(cQuantityDup);
									printf("\n Part Quantity Value After Dup & Trim: [%s]", cQuantityDup);fflush(stdout);

									int intcQuantityDup=0;
									intcQuantityDup = atoi (cQuantityDup);								
									
									ITK_CALL(AOM_UIF_ask_value(ChildDesRev_tag, "bl_Design Revision_t5_PartType", &cPartType));
									
									trimwhitespace(cPartType);
									printf("\n Part Type Value After Dup & Trim: [%s]", cPartType);fflush(stdout);
									
									//fprintf(fpOutput_file1,"%s,",cPartType);fflush(fpOutput_file1);	
									
										// if(tc_strcmp(cModAddress,"F5A15")==0)
										// {
											// F5A15_Mod++;
											// F5A15_Qty = intcQuantityDup + F5A15_Qty;
										// }
										if(tc_strcmp(cModAddress,"H1A01")==0)
										{
											H1A01_Mod++;
											H1A01_Qty = intcQuantityDup + H1A01_Qty;
										}
										if(tc_strcmp(cModAddress,"F3C03")==0)
										{
											F3C03_Mod++;
											F3C03_Qty = intcQuantityDup + F3C03_Qty;
										}
										if(tc_strcmp(cModAddress,"H2A01")==0)
										{
											H2A01_Mod++;
											H2A01_Qty = intcQuantityDup + H2A01_Qty;
										}
										if(tc_strcmp(cModAddress,"H2A02")==0)
										{
											H2A02_Mod++;
											H2A02_Qty = intcQuantityDup + H2A02_Qty;
										}
										if(tc_strcmp(cModAddress,"H2C02")==0)
										{
											H2C02_Mod++;
											H2C02_Qty = intcQuantityDup + H2C02_Qty;
										}
										if(tc_strcmp(cModAddress,"F1E05")==0)
										{
											F1E05_Mod++;
											F1E05_Qty = intcQuantityDup+F1E05_Qty;
										}
										if(tc_strcmp(cModAddress,"F4A03")==0)
										{
											F4A03_Mod++;
											F4A03_Qty = intcQuantityDup + F4A03_Qty;
										}
									
										if(tc_strcmp(cModAddress,"H2D03")==0)
										{
											H2D03_Mod++;
											H2D03_Qty = intcQuantityDup + H2D03_Qty;
										}
										if(tc_strcmp(cModAddress,"F5A04")==0)
										{
											F5A04_Mod++;
											F5A04_Qty = intcQuantityDup + F5A04_Qty;
										}
										/*********************************************/
										if(tc_strcmp(cModAddress,"G1C04")==0)
										{
											G1C04_Mod++;
											G1C04_Qty = intcQuantityDup + G1C04_Qty;
										}
										if(tc_strcmp(cModAddress,"G1C05")==0)
										{
											G1C05_Mod++;
											G1C05_Qty = intcQuantityDup + G1C05_Qty;
										}
										
										/*********************************************/
										if(tc_strcmp(cPartType,"IFD")==0)
										{
											IFD_Mod++;
											IFD_Qty = intcQuantityDup + IFD_Qty;
										}
										if(tc_strcmp(cPartType,"IFD Module")==0)
										{
											IFDMod_Mod++;
											IFDMod_Qty = intcQuantityDup + IFDMod_Qty;
										}
										if(tc_strcmp(cPartType,"CAD Module")==0)
										{
											CADMod_Mod++;
											CADMod_Qty = intcQuantityDup + CADMod_Qty;
										}
										if(tc_strcmp(cPartType,"Dummy")==0)
										{
											DummyMod_Mod++;
											DummyMod_Qty = intcQuantityDup + DummyMod_Qty;
										}
									
								}
								// if(F5A15_Mod>0)
								// {
									// if(F5A15_Qty==2)
									// {
										// fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									// }
									// else
									// {
										// fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									// }
								// }
								// else
								// {
									// fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								// }
								
								if(H1A01_Mod>0)
								{
									if(H1A01_Qty==1)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								
								if(F3C03_Mod>0)
								{
									if(F3C03_Qty==1)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								
								if(H2A01_Mod>0)
								{
									if(H2A01_Qty==1)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								
								if(H2A02_Mod>0)
								{
									if(H2A02_Qty==1)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								
								if(H2C02_Mod>0)
								{
									if(H2C02_Qty==1)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								
								if(F1E05_Mod>0)
								{
									if(F1E05_Qty==1)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								if(F4A03_Mod>0)
								{
									if(F4A03_Qty==1)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								/**************************************************/
								
								if(G1C04_Mod>0)
								{
									if(G1C04_Qty==0)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								if(G1C05_Mod>0)
								{
									if(G1C05_Qty==0)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								
								/**************************************************/
								
								if(IFD_Mod>0)
								{
									if(IFD_Qty==0)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								if(IFDMod_Mod>0)
								{
									if(IFDMod_Qty==0)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								
								if(CADMod_Mod>0)
								{
									if(CADMod_Qty==0)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
								if(DummyMod_Mod>0)
								{
									if(DummyMod_Qty==0)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"NA,");fflush(fpOutput_file);
								}
							
								if(H2D03_Mod>0)
								{
									if(F5A04_Qty==0)
									{
										fprintf(fpOutput_file,"Pass,");fflush(fpOutput_file);
									}
									else
									{
										fprintf(fpOutput_file,"Fail,");fflush(fpOutput_file);
									}
								}
								else
								{
									fprintf(fpOutput_file,"PASS,");fflush(fpOutput_file);
								}
									
							}
						}
					}			
				}
				else
				{
					printf(" Vehicle Found Zero[0] on Latest Released Design Revision for ERC..!!\n");fflush(stdout);
					fprintf(fpOutput_file,"\nNo Vehicle Release from ERC today");fflush(fpOutput_file);
				}
			
			
		
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
		
	}
	fprintf(fpOutput_file,"\n\n------------------------------");fflush(fpOutput_file);
	fprintf(fpOutput_file,"\nE N D - O F    R E P O R T \n");fflush(fpOutput_file);
	//fprintf(fpOutput_file,"\n\nS1-F5A15 total qty should be released with-2\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n\nS1-H1A01(Engine Assy) should be released with qty-1\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S2-F3C03(Powertrain Side Engine Mount Bracket) should be released with qty-1\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S3-H2A01(330 Dia. Multistage Clutch) should be released with qty-1\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S4-H2A02(Clutch Release System) should be released with qty-1\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S5- H2C02( Gear Shift System) should be Released with qty-1\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S6-F1E05(WH Battery Compartment) Should be released with qty-1\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S7- F4A03(Spring to Axle Attaches And Bump Stopper) should be released with qty-1\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S8- G1C04 should be released with zero qty\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S9- G1C05 should be released with zero qty\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S10-Part Type 'IFD' should be released with zero qty\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S11- Part Type 'IFD Module' should be released with zero qty\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S12-Part Type 'CAD Module' should be released with zero qty\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S13-Part Type 'Dummy' should be released with zero qty\n");fflush(fpOutput_file);
	fprintf(fpOutput_file,"S14- If H2D03 is present then F5A04 should not be present or present with zero qty & Viceversa\n");fflush(fpOutput_file);
	
	fclose(fpOutput_file);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_LatestRlzdDesRev.c
* // ./linkitk -o tm_LatestRlzdDesRev tm_LatestRlzdDesRev.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LatestRlzdDesRev/tm_LatestRlzdDesRev .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LatestRlzdDesRev/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LatestRlzdDesRev/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/LatestRlzdDesRev/SendEmail.sh .
* // ./tm_LatestRlzdDesRev -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_LatestRlzdDesRev -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/