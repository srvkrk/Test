#!/bin/bash
. /user/omfprod/parallel/6650/parallel_pdmsetup.sh

today=`date '+%Y_%m_%d_%H_%M_%S'`;
echo $today
Filename="SAP_PO_DETAILS_""$today"".txt"
#FilenameOut="OUT_PO_DETAILS_""$today"".txt"
FilenameMod="MOD_PO_DETAILS_""$today"".txt"
File_Tosync="MOD_Grep_""$today"".txt"
File_Log="IN_SED_""$today"".txt"
File_NA="INPUT_NA_""$today"".txt"
File_NA2="INPUT_NA2_""$today"".txt"
File_NA3="INPUT_NA3_""$today"".txt"
File_Input="INPUT_""$today"".txt"

echo $Filename
#echo $FilenameOut
echo $FilenameMod
echo $File_Tosync
echo $File_Log
echo $File_NA
echo $File_NA2
echo $File_NA3
echo $File_Input

sqlplus -s plminq/plminq << !
set linesize 100
set pagesize 0
set pages 0
set head off
set verify off
set term off
set echo off
set feedback off
set termout off
set showmode off
spool /user/omfprod/devgroups/abhilash/PO_Sync/New_sync/$Filename
select x
from
(select a.MATERIAL||','||a.PLANT||','||a.PO||','||a.PODATE||','||a.POPARTREV||','||a.NETPRICE||','||a.VENDORID||','||b.BULK_MATERAIL||','||c.STOCK||','||d.TRASACTION as x
from SAPMATPO a
FULL OUTER JOIN SAPMATBULK b
ON a.MATERIAL=b.MATERIAL
AND a.PLANT=b.PLANT
FULL OUTER JOIN SAPMATSTOCK c
ON a.MATERIAL=c.MATERIAL
AND a.PLANT=c.PLANT
FULL OUTER JOIN SAPMATTRASN d
ON a.MATERIAL=d.MATERIAL
AND a.PLANT=d.PLANT
where LENGTH (a.PLANT) = 4);
--where LENGTH (a.MATERIAL) = 12 and LENGTH (a.PLANT) = 4);
spool off
!
echo $Filename
sleep 5

#while read line; do grep ^$line $Filename >> $FilenameOut; done < UApart.txt
#echo $FilenameOut

awk -F, -v OFS=, '{$4=$4"-00:00:00"; gsub(" ","NR", $5) ; gsub("1100", "t5_Plant1:CAR", $2) ; gsub("1140", "t5_Plant11:PUVBU", $2) ; gsub("1001", "t5_Plant2:CVBU Pune", $2) ; gsub("7501", "t5_Plant3:SMALLCAR AHD", $2) ; gsub("3100", "t5_Plant5:CVBU PNR", $2) ; gsub("1500", "t5_Plant6:DHARWAD", $2) ; gsub("2001", "t5_Plant8:CVBU JSR", $2) ; gsub("3001", "t5_Plant9:CVBU LKO", $2) ; print }'  "$Filename" > "$FilenameMod"
echo $FilenameMod

sleep 5

grep  t5_Plant $FilenameMod > $File_Tosync
echo $File_Tosync

sleep 5

sed 's/[ \t]\+$//' $File_Tosync > $File_Log
echo $File_Log

sleep 5

sed 's/$/,/' $File_Log > $File_NA
echo $File_NA

#awk -F, -v OFS=, '{gsub(",,",",NA,", $8); gsub(",,",",NA,", $9); gsub(",,",",NA,", $10) ; print}' $File_NA > $File_Input

sed 's/\,,/,NA,/g' $File_NA > $File_NA2
sleep 1

sed 's/\,,/,NA,/g' $File_NA2 > $File_NA3
sed 's/\, ,/,NA,/g' $File_NA3 > $File_Input

sleep 5
rm -f $Filename
sleep 1
#rm -f $FilenameOut
sleep 1
rm -f $FilenameMod
sleep 1
rm -f $File_Tosync
sleep 1
rm -f $File_Log
sleep 1
rm -f $File_NA
sleep 1
rm -f $File_NA2

rm -f $File_NA3

#scp -rp $File_Input bsd05818@172.22.97.12:/user/bsd05818/abhilash/PO_stamp/TC12_compiled/.
scp -rp $File_Input uaprodtrl@172.22.97.18:/user/uaprodtrl/PO_TCUA/.

sleep 2
