/******************************************************************************
*Owner: Rudresh Marde
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <ecm/ecm.h>
#include <qry/qry.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  /* for dataset id and rev */
#include <setjmp.h>
#include <ae/ae_errors.h>           /* for dataset id and rev */
#include <ae/ae_types.h>            /* for dataset id and rev */
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <pie/pie.h>
#include <tccore/aom_prop.h>


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define ITEM_CHECKED_OUT  EMH_USER_error_base + 5
#define JT_PDF_NOT_FOUND  EMH_USER_error_base + 8
#define Not_Item_Revision  EMH_USER_error_base + 6
static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}

/* Function to add Tag into a set of Tag */	
void setAddTAG(int *count,tag_t **objlist,tag_t obj )
{

	*count=*count+1;
	if(*count==1)
	{
		printf("\n ****setAddTAG1");fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));

	}
	else
	{
		printf("\n ****setAddTAG2");fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}

	(*objlist)[*count-1] = obj; //malloc((strlen(view_id)+1) * sizeof(char));
}

void  GetProjectUserAccessDetails( char  *Projj , char  *UsrId ,int *Gmcnt ,tag_t	**GmFound)
{
	int		n_entries = 2;
	int		countt=0;

	char	*qry_entries[2] = {"Project ID","Id"};
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t	queryTag   = NULLTAG;

	 char *Object_Name  =  NULL;



	printf( "Projj:%s\n", Projj);fflush(stdout);
	printf( "UsrId:%s\n", UsrId);fflush(stdout);
	 

				if(QRY_find2("ProjectUserAccessDet", &queryTag));
				printf("\n MT:After Prd_Project: QRY_find");fflush(stdout);
				if (queryTag)
				{
					printf("\n MT:Found Query");fflush(stdout);
				}
				else
				{
					printf("\n MT:Not Found Query");fflush(stdout);
				}

				qry_values[0] = Projj;
				qry_values[1] = UsrId;

				if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, Gmcnt, GmFound));
				printf("\n MT: Gmcnt : %d\n", *Gmcnt); fflush(stdout);

//                for(countt==0;countt<*Gmcnt;countt++)
//				{
//						Object_Name  =  NULL;
//						ITKCALL(AOM_UIF_ask_value(GmFound[countt],"object_string", &Object_Name));	
//						printf("\n %s",Object_Name);fflush(stdout);
//				}

}
int ITK_user_main(int argc, char* argv[])
{
	int		error_code				=	ITK_ok;
	int		ifail 			= ITK_ok;
	char 	*user			= NULL;
	char 	*pass			= NULL;
	char 	*group			= NULL;
	char	*partNumber		=NULL;
	int		design_rev_cnt			=	0;
	int		dataset_cnt,i			=	0;
	int		result					=   0;
//	int		result,count			=   0;
	tag_t	objTypeTag				=	NULLTAG;

	tag_t	select_itemrev			=   NULLTAG;
	tag_t	dataset_relation_type	=   NULLTAG;
	tag_t	obj_type				=   NULLTAG;
	tag_t	relation				=   NULLTAG;

	tag_t	*design_rev_tag			=	NULLTAG;
	tag_t	*DatasetList			=	NULLTAG;
//	tag_t	*secondary_list			=	NULLTAG;
	
	char	*designrev				=	NULL;
	char	*chkout_val				=   NULL;
	char	*IndentCategory			=   NULL;
	char	*dataset_typeName		=   NULL;
	char	*data_set_Project		= NULL;
	char	*DesRevProj		= NULL;
	char	*ERCIndQtyset		= NULL;
	char	*ERCIndReqQtyset		= NULL;
	//char ** strngSet = NULL;
	tag_t 	latestReleasedPart = NULLTAG;
	tag_t 	prevOffPart = NULLTAG;
	tag_t latestPart = NULLTAG;
	tag_t partMasterObj = NULLTAG;
	tag_t Attachrelation_type=NULLTAG;
	int cnt1=0;
	tag_t *attachments1;


				char  Projj[40]={"0"};
				int Gmcnt1=0;
				int ProjectAccessFound=0;
				int FlaggAssignPlanner=0;
				int countt=0;
				int b=0;
				int z=0;
				tag_t	*GmFound1 = NULLTAG;
				char *Object_Name  =  NULL;
				const char 
		*attrs[1] = {"item_id"},
		*values[1] = {"*"};
	
	printf("\n *********** Start Of Utility Execution ************* \n");fflush(stdout);
	if(ITK_auto_login() == ITK_ok)
	{
		printf("Login successfull. user[%s], group[%s]\n", user,group);fflush(stdout);	

	char* DesignRev = ITK_ask_cli_argument("-DesignRev=");
	char* PrtRevSeq = ITK_ask_cli_argument("-PrtRevSeq=");
	char* TaskNum = ITK_ask_cli_argument("-IndNum=");	

	printf("\n DesignRev=[%s]",DesignRev);
	printf("\n PrtRevSeq=[%s]",PrtRevSeq);
	printf("\n DML Number=[%s]",TaskNum);	
	
	tag_t TagQryContObj = NULLTAG,*Des_objects = NULL;
	tag_t TagQryIndeNum = NULLTAG,*ERCTaskNum_objects = NULL;
	
	int	n_entries = 1;
	int n_found = 0;
	
	char *qry_entries[1]={"Item ID"};
	char *qry_values[1]={DesignRev};
	
	int	n_entriesInd = 1;
	int n_foundInd = 0;
	
	//char *qry_entriesInd[1]={"t5RefNo"};
	char *qry_entriesInd[1]={"Item ID"};
	char *qry_valuesInd[1]={TaskNum};
	
	printf("\n CurrentTask:\n");
	
	if(QRY_find2("Item Revision...", &TagQryContObj));
	printf("\n CurrentTask:\n");
	
	

	if (TagQryContObj)
		{
			printf("\nFound Query Part  \n");fflush(stdout);
		}
		else
		{
			printf("\nNotFound Query Part");fflush(stdout);
		}
			
	if(QRY_execute(TagQryContObj, n_entries, qry_entries, qry_values, &n_found, &Des_objects));
	printf("\n Objects for Query Design rev == %d", n_found);fflush(stdout);
	
	//tag_t	prtObjTag				=	NULLTAG;
	//prtObjTag = Des_objects[0];
	
	
	
	
	//if(QRY_find("ERC Indent", &TagQryIndeNum));
	if(QRY_find2("Item Revision...", &TagQryIndeNum));
	printf("\n CurrentTask:\n");
	

	if (TagQryIndeNum)
		{
			printf("\nFound Query Part  \n");fflush(stdout);
		}
		else
		{
			printf("\nNotFound Query Part");fflush(stdout);
		}
			
	if(QRY_execute(TagQryIndeNum, n_entriesInd, qry_entriesInd, qry_valuesInd, &n_foundInd, &ERCTaskNum_objects));
	printf("\n Objects for Query Indent == %d", n_foundInd);fflush(stdout);
	
	tag_t	ERCTaskObjTag				=	NULLTAG;
	ERCTaskObjTag = ERCTaskNum_objects[0];
	
	tag_t PartIndrel = NULLTAG;
	tag_t newPartIndrel = NULLTAG;
	tag_t SLtag = NULLTAG;
	tag_t relation1 = NULLTAG;
	char *IndentName = NULL;
	char *designrevName = NULL;
	char *type_name2 =	NULL;
	char *type_name1 =	NULL;
	char *designrevNameObjstr =	NULL;
	
	char   type_name[TCTYPE_name_size_c+1];
	//char   type_name1[TCTYPE_name_size_c+1];
	
	tag_t	priObjTypeTag			=	NULLTAG;
	if (TCTYPE_ask_object_type(ERCTaskObjTag,&priObjTypeTag)!=ITK_ok);
	//if (TCTYPE_ask_name(priObjTypeTag,type_name1)!=ITK_ok);
	if(TCTYPE_ask_name2(priObjTypeTag,&type_name1)!=ITK_ok)PrintErrorStack();
	TC_write_syslog("primary obj type_name ::  %s\n", type_name1);
	
	AOM_ask_value_string(ERCTaskObjTag,"item_id",&IndentName);
	
	printf(" Indent number %s\n",IndentName);fflush(stdout);
	
	GRM_find_relation_type("CMHasSolutionItem", &PartIndrel);
	printf(" find relation CMHasSolutionItem \n");fflush(stdout);

	if(PartIndrel != NULLTAG)
	{
		printf(" ChangeReferencesnot null \n");fflush(stdout);
		int ia=0;
		for (ia=0;ia<n_found;ia++ )
		{
			printf(" in for loop of numbber of parts [%d] \n",n_found);fflush(stdout);
			tag_t	prtObjTag				=	NULLTAG;
			prtObjTag = Des_objects[ia];
			
			//char   type_name2[TCTYPE_name_size_c+1];

			tag_t	secObjTypeTag			=	NULLTAG;
			
			printf(" loop number [%d] \n",ia);fflush(stdout);
			if (TCTYPE_ask_object_type(prtObjTag,&secObjTypeTag)!=ITK_ok);
			if (TCTYPE_ask_name2(secObjTypeTag,&type_name2)!=ITK_ok);
			//TC_write_syslog("sec obj type_name ::  %s\n", type_name2);
			
			AOM_ask_value_string(prtObjTag,"item_id",&designrevName);
			printf(" designrevName %s\n",designrevName);fflush(stdout);

			AOM_ask_value_string(prtObjTag,"object_string",&designrevNameObjstr);
			printf(" designrevNameObjstr %s\n",designrevNameObjstr);fflush(stdout);

			 AOM_ask_value_string(prtObjTag,"item_revision_id",&designrev);
			 //TC_write_syslog("designrev ::  %s\n", designrev);
			 printf(" designrev %s\n",designrev);fflush(stdout);
			  printf(" input PrtRevSeq %s\n",PrtRevSeq);fflush(stdout);
		//DesignRev
			if((strcmp(DesignRev,designrevName)==0)&&(strcmp(PrtRevSeq,designrev)==0))
			{
				if (prtObjTag != NULLTAG && ERCTaskObjTag != NULLTAG)
				{
					if(GRM_find_relation_type("CMHasSolutionItem",&SLtag)!=ITK_ok)PrintErrorStack();
					if(GRM_find_relation(ERCTaskObjTag,prtObjTag,SLtag,&relation1)!=ITK_ok)PrintErrorStack();
					if(GRM_delete_relation(relation1)!=ITK_ok)PrintErrorStack();
					if(GRM_save_relation(relation1)!=ITK_ok)PrintErrorStack();
					/*GRM_create_relation(ERCTaskObjTag,prtObjTag,PartIndrel,NULLTAG,&newPartIndrel);
					if(newPartIndrel != NULLTAG)
					{
						GRM_save_relation(newPartIndrel);
						printf("\n relation created %s",designrevName);fflush(stdout);
						break;
					}*/
					//printf(" relation created");fflush(stdout);
				}
				else
				{
					printf(" Indent number or design rev is null");fflush(stdout);
				}
			}
			else
			{
				printf(" input rev seq[%s]",PrtRevSeq,designrev);fflush(stdout);
			}
		}
	}
	
	// printf(" EXIT Indent_Design_relation..in save relation...\n");fflush(stdout);
	

	}
	
	MEM_free(DatasetList);
	return error_code;
	
}


