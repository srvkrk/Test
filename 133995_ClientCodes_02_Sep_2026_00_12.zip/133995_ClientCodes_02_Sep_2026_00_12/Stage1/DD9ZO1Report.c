/***************************************************************************
*  File				:   DD9ZO1Report.c
*  Created By		: 	Sai D. Raypalwar.
*  Created On		:   27-Dec-2025
*  Project			:   TML
*  Purpose			:  Duplicate D9Z01 Report TCUA using report Builder.
*  //./DD9ZO1Report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -RS=T5_LcsErcRlzd -F=01-Jan-2024 -T=31-Dec-2024 -PT=V -Email=sr922335.ttl@tatamotors.com
*****************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <ps/ps.h>
#include <pie/pie.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tccore/aom_prop.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
#include <tc/folder.h>
//#include "tm_apl_std_common_function.c"
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;
FILE *Report1 = NULL;
int ctr=0;
char* cnt =NULL;

void write2xml(FILE *Report1 , char* str)
{
	fprintf(Report1,str);
	ctr++;
}
char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}
void getCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n getCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%m-%Y",timeptr);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%m-%Y-%H-%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d_%m_%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);
	printf("\n cCurrentAccessDate:%s\n",cCurrentAccessDate);

	//sprintf(DateS,"%d",(timeptr->tm_year+1900));
	printf("Date:%d\n",(timeptr->tm_mday));
	printf("Month:%d\n",(timeptr->tm_mon)+1);
	printf("Year:%d\n",(timeptr->tm_year+1900));
	fflush(stdout);
}
int ITK_user_main(int argc,char *argv[])
{
	int iFail     = 0;
	int status     = 0;
	
	//*******************************AUTO Login **************** 
	ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	ITKCALL(ITK_auto_login());
	ITK_set_bypass(true);
	ITKCALL(ITK_set_journalling(TRUE));
	
	printf("\n Login Sucessful\n");fflush(stdout);
	
	//**************************END*********************************
	//From To Parttpe
	char *LCS = NULL;
	char *From = NULL;
	char *To = NULL;
	char *Parttype = NULL;
	char *LCSDup = NULL;
	char *FromDup = NULL;
	char *ToDup = NULL;
	char *ParttypeDup = NULL;
	char *item_email_str = NULL;
	char *item_email_strDup = NULL;
	
	LCS				= ITK_ask_cli_argument("-RS=");
	From 			= ITK_ask_cli_argument("-F=");
	To 				= ITK_ask_cli_argument("-T=");
	Parttype		= ITK_ask_cli_argument("-PT=");
	item_email_str	= ITK_ask_cli_argument("-Email=");
	
	trimwhitespace(LCS);
	trimwhitespace(From);
	trimwhitespace(To);
	trimwhitespace(Parttype);
	trimwhitespace(item_email_str);
	if(LCS!=NULL)tc_strdup(LCS,&LCSDup);
	if(From!=NULL)tc_strdup(From,&FromDup);
	if(To!=NULL)tc_strdup(To,&ToDup);
	if(Parttype!=NULL)tc_strdup(Parttype,&ParttypeDup);
	if(item_email_str!=NULL)tc_strdup(item_email_str,&item_email_strDup);
	
	printf("Input Email(LCSDup): [%s]\n",LCSDup);
	printf("Input Email(FromDup): [%s]\n",FromDup);
	printf("Input Email(ToDup): [%s]\n",ToDup);
	printf("Input Email(item_email_strDup): [%s]\n",item_email_strDup);
	FILE *Report = NULL;
	
	char CurrentDate[20]={0};
	getCurrentDateTime(CurrentDate);
	printf("\n\n Current Date is [%s] \n\n",CurrentDate);fflush(stdout);
	
	char* filename =NULL;
	filename=(char*) MEM_alloc(100);
	cnt=(char*) MEM_alloc(100);
	tc_strcpy(filename,"");
	tc_strcat(filename,"DD9ZO1Report_");
	tc_strcat(filename,CurrentDate);
	tc_strcat(filename,".csv");
	printf("\n File Name %s \n",filename);fflush(stdout);
	
	//********************************** FILE print *********************************
	
	Report = fopen(filename,"w");
	fprintf(Report,"\n ,,Duplicate D9Z01 Reprt,,,,");fflush(Report);
	
	fprintf(Report,"\n VC ,Rev/Seq,AR/DR Status ,Release Type,counter,D9Z01,qty,CVM_MBOM,CVM_PUNE,CVM_JSR,CVM_LKO,CVM_DWD,CVM_UTK\n");fflush(Report);
	Report1=fopen("/tmp/DD9ZO1Report.xml","w");
	if (Report1 == NULL)
	{
		printf("ERROR: XML Cannot open File\n");
		return -1;
	}
	else
	{
		printf("XML File opened successfully.\n");
	}
	write2xml(Report1,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	write2xml(Report1,"<DEZO1Rpt>\n");
	write2xml(Report1,"<PLMXMLdate>\n");
	write2xml(Report1,"<ReportDate>"); write2xml(Report1,CurrentDate); write2xml(Report1,"</ReportDate>\n");
	write2xml(Report1,"</PLMXMLdate>\n");
	//************************************************************************************
	int Obj_Count = 0;
	tag_t*  VechicleTag 	= NULLTAG;
	tag_t   querytag	= NULLTAG;
	tag_t   querytag1	= NULLTAG;
	char* RevSeqno =NULL;
	char* DRstatus =NULL;
	
	//ITKCALL(QRY_find("All_Parts",&querytag));
	ITKCALL(QRY_find2("ERC_Part_QueryCSA",&querytag));
	if(querytag != NULLTAG)
	{
		char* PTarr[2]={"Vehicle","Vehicle Combination CR"};
		//printf("\n PTarr size is %d\n",setsize(PTarr));
		int p ;
		for(p=0;p<2;p++)
		{
			 printf("\n input is :%s \n",PTarr[p]);
			char *varible ;
		    varible=PTarr[p];
			printf("\n\n Inside Query Execute ");fflush(stdout);
			//char    *QryEntries[3]  = {"ID","Part Type","Life Cycle State"};
			char    *QryEntries[5]  = {"ID","Life Cycle State","Date_Released From","Date_Released To","Part Type"};
			char	**QryValues= (char **) MEM_alloc(5 * sizeof(char *));
			QryValues[0]="*"; 
			//QryValues[1]=varible;
			//QryValues[2]="T5_LcsErcRlzd";
			QryValues[1]=LCSDup; 
			QryValues[2]=FromDup;
			QryValues[3]=ToDup;
			QryValues[4]=ParttypeDup;
			ITKCALL(QRY_execute(querytag,5, QryEntries, QryValues, &Obj_Count, &VechicleTag));
			printf("\n VechicleTag count :%d \n",Obj_Count);
			
			char*  VcNO =NULL;
			char*  parttype =NULL;
			char*  FINALSTATUSNAME =NULL;
			char*  bmomRLZdDate =NULL;
			tag_t*  listRLZ =NULLTAG;
			if(Obj_Count>0)
			{
				int i =0;
				int q =0;
				int CCRLZ=0;
				int count1=0;
				tag_t vechileM = NULLTAG;
				tag_t *  rev_list = NULLTAG;
				//for(i=0;i<Obj_Count; i++) 
				for(i=0;i<50; i++) 
				{ 
					ITKCALL(AOM_ask_value_string(VechicleTag[i],"item_id",&VcNO));
					printf("\n Vechicle Number :%s \n",VcNO);
													
					ITKCALL(AOM_ask_value_string(VechicleTag[i],"item_revision_id",&RevSeqno));
					printf("\n RevSeqno  :%s \n",RevSeqno);
					
					ITKCALL(AOM_ask_value_string(VechicleTag[i],"t5_PartStatus",&DRstatus));
					printf("\n RevSeqno  :%s \n",RevSeqno);
					
					tag_t       window         		= NULLTAG;
					tag_t       top_bom_line1    	= NULLTAG;
					tag_t       *Partchildttag				= NULLTAG;
					char	    *childPartitmID				= NULL;	
					char	    *CVMDwd				= NULL;	
					char	    *qty				= NULL;	
					char	    *CVMJsr				= NULL;	
					char	    *CVMLko				= NULL;	
					char	    *CVMMbom				= NULL;	
					char	    *CVMPune				= NULL;	
					char	    *CVMUTK				= NULL;	
					int         Partchildcount       		= 0;
					int         CRule_found       			= 0;
					int t =0;
					int counter =0;
					
					WSOM_ask_release_status_list(VechicleTag[i],&CCRLZ,&listRLZ);
					for(q=0;q<CCRLZ;q++)
					{
						AOM_ask_value_string(listRLZ[q],"object_name", &FINALSTATUSNAME);
						printf("\n\t\t\t\t==============Release Status APLJ %s\n\n",FINALSTATUSNAME);
						
						AOM_UIF_ask_value(listRLZ[q],"date_released", &bmomRLZdDate);
						printf("\n\t\t\t\t==============Release Date %s\n\n",bmomRLZdDate);
					
						if(tc_strstr(FINALSTATUSNAME,"T5_LcsErcRlzd")!=NULL)
						{
							printf ("\n \n BOM View Expansion ........ \n");fflush(stdout);
							ITKCALL(BOM_create_window(&window));
							
							printf ("UNSET closure rule...\n");fflush(stdout);
							
							ITKCALL(BOM_set_window_top_line(window, NULLTAG, VechicleTag[i], NULLTAG, &top_bom_line1));
							ITKCALL(BOM_line_ask_all_child_lines(top_bom_line1, &Partchildcount, &Partchildttag));
							printf("\n\n Number of child  Part found in APLJ  : %d\n",Partchildcount);fflush(stdout);
							counter =0;
							for(t = 0; t < Partchildcount; t++)
							{
								
								ITKCALL(AOM_ask_value_string(Partchildttag[t],"bl_item_item_id",&childPartitmID));
								
								if(tc_strstr(childPartitmID,"D9Z01")!=NULL)
								{ 
									
									printf("\n\n Child Part item id : %s",childPartitmID);fflush(stdout);
									++counter;
									ITKCALL(AOM_ask_value_string(Partchildttag[t],"bl_quantity",&qty));
									ITKCALL(AOM_ask_value_string(Partchildttag[t],"bl_occ_t5_CurrentViewMaskD",&CVMDwd));
									ITKCALL(AOM_ask_value_string(Partchildttag[t],"bl_occ_t5_CurrentViewMaskJ",&CVMJsr));
									ITKCALL(AOM_ask_value_string(Partchildttag[t],"bl_occ_t5_CurrentViewMaskL",&CVMLko));
									ITKCALL(AOM_ask_value_string(Partchildttag[t],"bl_occ_t5_CurrentViewMaskM",&CVMMbom));
									ITKCALL(AOM_ask_value_string(Partchildttag[t],"bl_occ_t5_CurrentViewMaskP",&CVMPune));
									ITKCALL(AOM_ask_value_string(Partchildttag[t],"bl_occ_t5_CurrentViewMaskU",&CVMUTK));
									fprintf(Report,"\n %s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s",VcNO,RevSeqno,DRstatus,FINALSTATUSNAME,counter,childPartitmID,qty,CVMMbom,CVMPune,CVMJsr,CVMLko,CVMDwd,CVMUTK);fflush(stdout);
									sprintf(cnt, "%d", counter);
									write2xml(Report1,"<DEZO1Detail>\n");
									write2xml(Report1,"<VcNumber>"); if(tc_strlen(VcNO)>0) write2xml(Report1,VcNO); else write2xml(Report1,"NA"); write2xml(Report1,"</VcNumber>\n");
									write2xml(Report1,"<RevSeq>"); if(tc_strlen(RevSeqno)>0) write2xml(Report1,RevSeqno); else write2xml(Report1,"NA"); write2xml(Report1,"</RevSeq>\n");
									write2xml(Report1,"<DRstatuss>"); if(tc_strlen(DRstatus)>0) write2xml(Report1,DRstatus); else write2xml(Report1,"NA"); write2xml(Report1,"</DRstatuss>\n");
									write2xml(Report1,"<ReleaseType>"); if(tc_strlen(FINALSTATUSNAME)>0) write2xml(Report1,FINALSTATUSNAME); else write2xml(Report1,"NA"); write2xml(Report1,"</ReleaseType>\n");
									write2xml(Report1,"<Count>"); if(tc_strlen(cnt)>0) write2xml(Report1,cnt); else write2xml(Report1,"NA"); write2xml(Report1,"</Count>\n");
									write2xml(Report1,"<PartD9z01>"); if(tc_strlen(childPartitmID)>0) write2xml(Report1,childPartitmID); else write2xml(Report1,"NA"); write2xml(Report1,"</PartD9z01>\n");
									write2xml(Report1,"<Qty1>"); if(tc_strlen(qty)>0) write2xml(Report1,qty); else write2xml(Report1,"NA"); write2xml(Report1,"</Qty1>\n");
									write2xml(Report1,"<CVMMbom1>"); if(tc_strlen(CVMMbom)>0) write2xml(Report1,CVMMbom); else write2xml(Report1,"NA"); write2xml(Report1,"</CVMMbom1>\n");
									write2xml(Report1,"<CVMPune1>"); if(tc_strlen(CVMPune)>0) write2xml(Report1,CVMPune); else write2xml(Report1,"NA"); write2xml(Report1,"</CVMPune1>\n");
									write2xml(Report1,"<CVMJsr1>"); if(tc_strlen(CVMJsr)>0) write2xml(Report1,CVMJsr); else write2xml(Report1,"NA"); write2xml(Report1,"</CVMJsr1>\n");
									write2xml(Report1,"<CVMLko1>"); if(tc_strlen(CVMLko)>0) write2xml(Report1,CVMLko); else write2xml(Report1,"NA"); write2xml(Report1,"</CVMLko1>\n");
									write2xml(Report1,"<CVMDwd1>"); if(tc_strlen(CVMDwd)>0) write2xml(Report1,CVMDwd); else write2xml(Report1,"NA"); write2xml(Report1,"</CVMDwd1>\n");
									write2xml(Report1,"<CVMUTK1>"); if(tc_strlen(CVMUTK)>0) write2xml(Report1,CVMUTK); else write2xml(Report1,"NA"); write2xml(Report1,"</CVMUTK1>\n");
									write2xml(Report1,"</DEZO1Detail>\n");
									
								}
								else
								{
									continue;
								}
							} 
								
						}
					}  
				}
			}
		}
	}
	fprintf(Report,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(Report);
	write2xml(Report1,"</DEZO1Rpt>\n");
	fclose(Report);
	char* RptShellCommandLine = NULL;
	RptShellCommandLine = (char *) MEM_alloc(100*sizeof(char ));
	
	printf("\n Email Shell Call Started...");fflush(stdout);
	//tc_strcpy(RptShellCommandLine,"/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_VehicleLinkStatus/SendEmail.sh");
	tc_strcpy(RptShellCommandLine,"/user/infodba08/sai/reportbuilder/Modified/SendEmail.sh");
	tc_strcat(RptShellCommandLine," ");
	tc_strcat(RptShellCommandLine,filename);
	tc_strcat(RptShellCommandLine," ");
	tc_strcat(RptShellCommandLine,item_email_strDup);
	printf("\n CommandLine: -------> [%s]",RptShellCommandLine);fflush(stdout);
	system(RptShellCommandLine); 
	printf("\n Email Shell Call Ended...");		
					
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
	
	return 0;
	
}
