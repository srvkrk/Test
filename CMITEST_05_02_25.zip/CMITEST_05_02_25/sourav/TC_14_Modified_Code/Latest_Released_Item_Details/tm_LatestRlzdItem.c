/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query Latest ERC Released Design Revision Details & Print its Properties on Reports  
*  File Name    :   tm_LatestRlzdItem.c
*  Created on   :   Oct 23rd, 2024
*  Usage        :   tm_LatestRlzdItem
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     23/10/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *inp_parttype_str = NULL;
	char *inp_parttype_strDup = NULL;
	char *RptFile = (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	tag_t DesRev_tag = NULLTAG;
	char *item_id_str = NULL;
	char *item_id_strDup = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	char *item_mod_address = NULL;
	char *inp_item_id_Str = NULL;
	char *inp_item_id_StrDup = NULL;
	char *cItem_Desc = NULL;
	char *cItem_DescDup = NULL;
	char *Platform = NULL;
	char *PlatformDup = NULL;
	char *PCode = NULL;
	char *PCodeDup = NULL;
	char *DesGrp = NULL;
	char *DesGrpDup = NULL;
	char *ARDRStatus = NULL;
	char *ARDRStatusDup = NULL;
	char *Owner = NULL;
	char *OwnerDup = NULL;
	char *inp_id_str = NULL;
	char *inp_id_strDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull..!!\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	inp_parttype_str = ITK_ask_cli_argument("-PT=");
	if(inp_parttype_str!=NULL)tc_strdup(inp_parttype_str,&inp_parttype_strDup);
	if(inp_parttype_strDup!=NULL)trimwhitespace(inp_parttype_strDup);
	printf("\n Input Part Type: [%s]", inp_parttype_strDup);fflush(stdout);
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	fpPart_List = fopen("PartList.txt","r");
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"latest_released_item_details");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);
	
    fpOutput_file = fopen(RptFile, "w");
    fprintf(fpOutput_file,"PART_NO, REVISION, SEQUENCE, DESCRIPTION, PLATFORM, PROJECT_CODE, DESIGN_GROUP, AR/DR_STATUS, OWNER\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			inp_id_str=strtok(Buffer,"^");
			if(inp_id_str!=NULL)tc_strdup(inp_id_str,&inp_id_strDup);
			if(inp_id_strDup!=NULL)trimwhitespace(inp_id_strDup);
	
			printf("\n Finding Query[Latest Released Design Revision for ERC]..!!\n");fflush(stdout);
			ITK_CALL(QRY_find2("Latest Released Design Revision for ERC",&tItemobj));
			if(tItemobj != NULLTAG)
			{
				printf("\n Query Latest Released Design Revision for ERC Tag Found Successfully..!!\n");fflush(stdout);
				char *cEntries[3]  = {"Item ID","Type","Part Type"};
				char *cValues[3]  = {inp_id_strDup,"Design Revision","M"};
				ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
				printf("\n Latest ERC Released Total Object Found: [%d]\n",n_itemobj_found);fflush(stdout);
				printf("\n >>>>>>>>>>-------------------------------<<<<<<<<<<<\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					for(i = 0; i < n_itemobj_found; i++)
					{
						DesRev_tag = titemobj_results[i];
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&item_id_str));
						if(tc_strlen(item_id_str)>0)
						{
							tc_strdup(item_id_str,&item_id_strDup);
							trimwhitespace(item_id_strDup);
						}
						else
						{
							tc_strdup("--",&item_id_strDup);
							printf("\n Part Number Value is NULL..!!");fflush(stdout);
						}
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_revision_id",&item_revseq_str));
						if(tc_strlen(item_revseq_str)>0)
						{
							tc_strdup(item_revseq_str,&item_revseq_strDup);
							item_rev_strDup=strtok(item_revseq_strDup,";");
							item_seq_strDup=strtok(NULL,";");
							printf("\n Part Rev Value After Token: [%s]\n", item_rev_strDup);fflush(stdout);
							printf("\n Part Seq Value After Token: [%s]\n", item_seq_strDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&item_revseq_strDup);
							tc_strdup("--",&item_rev_strDup);
							tc_strdup("--",&item_seq_strDup);
							printf("\n Part Revision Sequence Value is NULL..!!");fflush(stdout);
						}
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"object_desc",&cItem_Desc));
						printf("\n Item Description Before Dup & Trim: ---> <%s> \n",cItem_Desc);fflush(stdout);
						if(tc_strlen(cItem_Desc)>0)
						{
							tc_strdup(cItem_Desc,&cItem_DescDup);
						}
						else
						{
							tc_strdup("--",&cItem_DescDup);
							printf("\n Item Description Value is NULL..!!");fflush(stdout);
						}
						trimwhitespace(cItem_DescDup);
						printf("\n Item Description Value After Dup & Trim: --------> <%s>", cItem_DescDup);fflush(stdout);
						STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
						STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
						STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
						STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
						printf("\n Item Description Final Value: --------> [%s]\n", cItem_DescDup);fflush(stdout);
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Platform",&Platform));
						if(tc_strlen(Platform)>0)
						{
							tc_strdup(Platform,&PlatformDup);
						}
						else
						{
							tc_strdup("--",&PlatformDup);
							printf("\n Platform Value is NULL..!!");fflush(stdout);
						}
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ProjectCode",&PCode));
						if(tc_strlen(PCode)>0)
						{
							tc_strdup(PCode,&PCodeDup);
						}
						else
						{
							tc_strdup("--",&PCodeDup);
							printf("\n Project Code Value is NULL..!!");fflush(stdout);
						}
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_DesignGrp",&DesGrp));
						if(tc_strlen(DesGrp)>0)
						{
							tc_strdup(DesGrp,&DesGrpDup);
						}
						else
						{
							tc_strdup("--",&DesGrpDup);
							printf("\n Design Group Value is NULL..!!");fflush(stdout);
						}
						
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartStatus",&ARDRStatus));
						if(tc_strlen(ARDRStatus)>0)
						{
							tc_strdup(ARDRStatus,&ARDRStatusDup);
						}
						else
						{
							tc_strdup("--",&ARDRStatusDup);
							printf("\n AR/DR Status Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"owning_user",&Owner));
						if(tc_strlen(Owner)>0)
						{
							tc_strdup(Owner,&OwnerDup);
							trimwhitespace(OwnerDup);
							printf("\n Owning_User Value After Dup & Trim: --------> <%s>", OwnerDup);fflush(stdout);
							STRNG_replace_str(OwnerDup,","," ",&OwnerDup);
							STRNG_replace_str(OwnerDup,";"," ",&OwnerDup);
							STRNG_replace_str(OwnerDup,"\n"," ",&OwnerDup);
							STRNG_replace_str(OwnerDup,"'"," ",&OwnerDup);
							printf("\n Owning_User Final Value: --------> [%s]\n", OwnerDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&OwnerDup);
							printf("\n Owning_User Value is NULL..!!");fflush(stdout);
						}
						printf("\n >>>>>>>>>>>>>>> Item Details Start <<<<<<<<<<<<<<<<\n");fflush(stdout);
						printf("[1] Part_No: [%s]\n",item_id_strDup);fflush(stdout);
						printf("[2] Revision: [%s]\n",item_rev_strDup);fflush(stdout);
						printf("[3] Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
						printf("[4] Description: [%s]\n",cItem_DescDup);fflush(stdout);
						printf("[5] Platform: [%s]\n",PlatformDup);fflush(stdout);
						printf("[6] Project_Code: [%s]\n",PCodeDup);fflush(stdout);
						printf("[7] Design_Group: [%s]\n",DesGrpDup);fflush(stdout);
						printf("[8] AR/DR_Status: [%s]\n",ARDRStatusDup);fflush(stdout);
						printf("[9] Owner: [%s]\n",OwnerDup);fflush(stdout);
						printf("\n >>>>>>>>>>>>>>> Item Details End <<<<<<<<<<<<<<<<\n");fflush(stdout);
						
						fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s\n",item_id_strDup,item_rev_strDup,item_seq_strDup,cItem_DescDup,PlatformDup,PCodeDup,DesGrpDup,ARDRStatusDup,OwnerDup);fflush(fpOutput_file);
					}			
				}
				else
				{
					printf(" Item Found Zero[0] on Latest Released Design Revision for ERC..!!\n");fflush(stdout);
				}
			}
			else
			{
				printf(" Latest Released Design Revision for ERC Query Tag Not Found..!!\n");fflush(stdout);
			}
		}
	}
		
	fprintf(fpOutput_file,"\n ,,,, E N D - O F    R E P O R T ,,,,\n");fflush(fpOutput_file);
	fclose(fpOutput_file);
	fclose(fpPart_List);
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_LatestRlzdItem.c
* // ./linkitk -o tm_LatestRlzdItem tm_LatestRlzdItem.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Latest_Released_Item_Details/tm_LatestRlzdItem .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Latest_Released_Item_Details/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Latest_Released_Item_Details/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Latest_Released_Item_Details/SendEmail.sh .
* // ./tm_LatestRlzdItem -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_LatestRlzdItem -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
*
***************************************************************************/