########################################################################################################
##
## Date : 01-May-2025
## Creators : Ujjawal Kumar and Sourav Karak
## Desc : This program generates a Report for given Submodule-Address (say A1A02).
## Submodules Comparison first-level and print Submodules-matrix with Modularity-Matching score.
########################################################################################################
echo "Start time:";date
StartTime=`date`

TodayDate=`date --date="today" +%d_%m_%Y`
echo "TodayDate Date is : " $TodayDate

echo "Input Module Address: $1"
echo "Creating directory as MCC_DATA_$1"

cd /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/SCRDetailsReport/MCC_DATA_$1
echo "Started executing Program for Module Adress $1"

cp ALL_SUBMOUDLES_$1.txt COLUMNS_ALL_SUBMOUDLES_$1.txt
cp ALL_SUBMOUDLES_$1.txt ROWS_ALL_SUBMOUDLES_$1.txt

echo "Query program completed...going for Report generation processing..."

StrForSubModCount=`wc -l "ALL_SUBMOUDLES_"$1".txt"`
echo $StrForSubModCount

TotalLineCountALLSubMod=`echo $StrForSubModCount |cut -d\  -f1`

echo "TotalLineCountALLSubMod -------------------------> :"$TotalLineCountALLSubMod

if [[ $TotalLineCountALLSubMod -le 300 ]]
	then
		echo "TotalLineCountALLSubMod is less-than-equal-to $TotalLineCountALLSubMod .. Can Go ahead for Processing..."
		echo "Started processing for SCR Report Matrix comparison....Output-line will take some time...pls be patient."
		
		echo "$1,$StartTime,$TotalLineCountALLSubMod" >> ../PROCESSED_AllList.data
		
		#exit
		
		rm -rf $1"_PROCESSED_MODULES_MATRIX_COMBO.txt"
		rm -rf $1"_MATRIX_MODULARITY_SCORE_FILE.txt"

		ROWS_SubModLineCount=0
		while read ROWS_SubModLine
		do
			ROWS_SubModLineCount=$(( $ROWS_SubModLineCount + 1 ))
			ROWS_SubMod_PartNumber=`echo $ROWS_SubModLine |cut -d "^"  -f2`
			ROWS_SubMod_PartRev=`echo $ROWS_SubModLine |cut -d "^"  -f3`
			ROWS_SubMod_PartSeq=`echo $ROWS_SubModLine |cut -d "^"  -f4`	
			ROWS_FormatttedSubModNum=$ROWS_SubMod_PartNumber"_"$ROWS_SubMod_PartRev"_"$ROWS_SubMod_PartSeq
			
			#echo "[ $ROWS_SubModLineCount ] ROWS_FormatttedSubModNum : $ROWS_FormatttedSubModNum"
			#echo "Started comparing for $AllData_SubModLineCount $AllData_FormatttedSubModNum ...."	
			
			COLUMNS_SubModLineCount=0
			while read COLUMNS_SubModLine
			do
				COLUMNS_SubModLineCount=$(( $COLUMNS_SubModLineCount + 1 ))
				COLUMNS_SubMod_PartNumber=`echo $COLUMNS_SubModLine |cut -d "^"  -f2`
				COLUMNS_SubMod_PartRev=`echo $COLUMNS_SubModLine |cut -d "^"  -f3`
				COLUMNS_SubMod_PartSeq=`echo $COLUMNS_SubModLine |cut -d "^"  -f4`	
				COLUMNS_FormatttedSubModNum=$COLUMNS_SubMod_PartNumber"_"$COLUMNS_SubMod_PartRev"_"$COLUMNS_SubMod_PartSeq
					
				#echo "[R$ROWS_SubModLineCount C$COLUMNS_SubModLineCount] CHECKING->ROW $ROWS_SubModLineCount~$ROWS_FormatttedSubModNum with COLUMN $COLUMNS_SubModLineCount~$COLUMNS_FormatttedSubModNum"
				
				#Date : 30_05_2025 (Logic to check re-process)
				
				grep -q $COLUMNS_FormatttedSubModNum"^"$ROWS_FormatttedSubModNum $1"_PROCESSED_MODULES_MATRIX_COMBO.txt"
				if [ $? == 0 ] #found
				then
					
					echo "Skiping [R$ROWS_SubModLineCount C$COLUMNS_SubModLineCount]................";
					
				else				
					
					echo "$ROWS_FormatttedSubModNum^$COLUMNS_FormatttedSubModNum" >> $1"_PROCESSED_MODULES_MATRIX_COMBO.txt"	
					
					ROWS_SubModChildLineCount=0	
					ROWS_SubModChildTotalCount=0		
					
					TotalNoOfColChild=`wc -l $COLUMNS_FormatttedSubModNum".txt"|cut -d " " -f1`
					#echo "TotalNoOfColChild in file $COLUMNS_FormatttedSubModNum.txt = $TotalNoOfColChild"
					
					TotalMatched=0
					#TotalNotMatched=0
					
					while read ROWS_SubModLine_Child
					do
						#ROWS_SubModChildLineCount=$(( $ROWS_SubModChildLineCount + 1 ))
						ROWS_SubModChildTotalCount=$(( $ROWS_SubModChildTotalCount + 1 ))
							
						ROWS_SubMod_ChildPartNumber=`echo $ROWS_SubModLine_Child |cut -d "^"  -f5`
						ROWS_SubMod_ChildPartRev=`echo $ROWS_SubModLine_Child |cut -d "^"  -f6`
						ROWS_SubMod_ChildPartSeq=`echo $ROWS_SubModLine_Child |cut -d "^"  -f7`		
						ROWS_FormatttedSubChildModNum=$ROWS_SubMod_ChildPartNumber"_"$ROWS_SubMod_ChildPartRev"_"$ROWS_SubMod_ChildPartSeq
							
						#echo "CHECKING---->$ROWS_SubModLineCount~$ROWS_FormatttedSubModNum~CHILD[$ROWS_SubModChildLineCount]~$ROWS_FormatttedSubChildModNum with $COLUMNS_SubModLineCount~$COLUMNS_FormatttedSubModNum"
						
						COLUMNS_SubModChildLineCount=0							
						
						#echo "Checking Match for...grep ["$ROWS_SubModLineCount"]"$ROWS_FormatttedSubModNum"~CHILD["$ROWS_SubModChildTotalCount"] "$ROWS_SubMod_ChildPartNumber" in Column-SubModule file "$COLUMNS_FormatttedSubModNum".txt"
						
						grep -q $ROWS_SubMod_ChildPartNumber $COLUMNS_FormatttedSubModNum".txt"
						
						if [ $? == 0 ] #child found in columns-submodule.
						then	
							#echo "Its a MATCH...."
								
							TotalMatched=$(( $TotalMatched + 1 ))
							
							#echo "    CHECKING-------->$ROWS_SubModLineCount~$ROWS_FormatttedSubModNum~CHILD[$ROWS_SubModChildLineCount]~$ROWS_FormatttedSubChildModNum with $COLUMNS_SubModLineCount~$COLUMNS_FormatttedSubModNum ----> MATCHED YYYYYYYYYY"
							
							continue
						else
							dummy=0
							#echo "    CHECKING-------->$ROWS_SubModLineCount~$ROWS_FormatttedSubModNum~CHILD[$ROWS_SubModChildLineCount]~$ROWS_FormatttedSubChildModNum with $COLUMNS_SubModLineCount~$COLUMNS_FormatttedSubModNum ----> NOT-MATCHED XXXXXXXXXX"
						fi
					
						#echo "--------------->Total number of Child for $ROWS_FormatttedSubModNum is $ROWS_SubModChildTotalCount"						
						#echo "ROWS_SubModLine [$ROWS_SubModLineCount]: $ROWS_FormatttedSubModNum, ROWS_SubModLine_Child [$ROWS_SubModChildLineCount]: $ROWS_FormatttedSubChildModNum"
					done < $ROWS_FormatttedSubModNum".txt"
					
					
					if [[ $ROWS_SubModChildTotalCount -ne 0 ]]
					then
						ModularityScorePercent=`echo "scale=6; ($TotalMatched / $ROWS_SubModChildTotalCount)*100" | bc | cut -c 1-5`			
						#echo "ModularityScorePercent :"$ModularityScorePercent"%"
					else
						ModularityScorePercent=`echo "scale=6; 0" | bc | cut -c 1-5`
					fi
					
					#echo "-------------------------------------------------------------------------------------------------------------------------------------"
					#echo "--------------->Total number of ROW-Child TOTAL for       ROW $ROWS_FormatttedSubModNum is $ROWS_SubModChildTotalCount"	
					#echo "--------------->Total number of ROW-Child MATCHED for     ROW $ROWS_FormatttedSubModNum with $COLUMNS_FormatttedSubModNum is $TotalMatched"
					#echo "--------------->Modularity Score % for $ROWS_FormatttedSubModNum with $COLUMNS_FormatttedSubModNum is $ModularityScorePercent%"
					#echo "--------------->Total number of COL-Child for COL-Submodule $COLUMNS_FormatttedSubModNum is : $TotalNoOfColChild"
					#echo "-------------------------------------------------------------------------------------------------------------------------------------"	
					
					
					
					#[R44 C6] 5163A1A0287003_A_3 with 2647A1A0287001_B_3 0/1 0%
					#[R44 C7] 5163A1A0287003_A_3 with 5164A1A0287010_B_4 0/1 0%

					#echo "R$ROWS_SubModLineCount,C$COLUMNS_SubModLineCount,$ROWS_FormatttedSubModNum,$COLUMNS_FormatttedSubModNum,$TotalMatched,$ROWS_SubModChildTotalCount,$ModularityScorePercent" >> $1"_MATRIX_MODULARITY_SCORE_FILE.txt"
				
					echo "[R$ROWS_SubModLineCount C$COLUMNS_SubModLineCount] ROW $ROWS_SubModLineCount~$ROWS_FormatttedSubModNum with COLUMN $COLUMNS_SubModLineCount~$COLUMNS_FormatttedSubModNum : $ModularityScorePercent % [$TotalMatched / $ROWS_SubModChildTotalCount ($TotalNoOfColChild)]"
					
					echo "R$ROWS_SubModLineCount,C$COLUMNS_SubModLineCount,$ROWS_FormatttedSubModNum,$COLUMNS_FormatttedSubModNum,$TotalMatched,$ROWS_SubModChildTotalCount,$TotalNoOfColChild,$ModularityScorePercent" >> $1"_MATRIX_MODULARITY_SCORE_FILE.txt"
					
				fi

			done < "COLUMNS_ALL_SUBMOUDLES_"$1".txt"	

			#sleep 1

		done < "ROWS_ALL_SUBMOUDLES_"$1".txt"	

	else
		echo "TotalLineCountALLSubMod is higher than $TotalLineCountALLSubMod .. CANNOT go ahead for processing.."
		echo "$1,$StartTime,$TotalLineCountALLSubMod" >> ../SKIPPED_AllList.data
fi		

echo "Completed....."
echo "Start Time: $StartTime"
EndTime=`date`
echo "End Time: $EndTime"
