####################################################
##
## This shell is used to send Mail for generated SCRR
## Ujjawal Kumar, Sourav Karak
## Date : 09-June-2025.
##
#################################################
echo "Input argument 1 (Module Address) : $1"
echo "Input argument 2 (User login ID)  : $2"
echo "Input argument 3 (User email ID)  : $3"

cd /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/SCRDetailsReport/MCC_DATA_$1

ls -lrt MCC_SUBMODULE_COMPLEXITY_REDUCTION_REPORT_$1*.xlsx 
cp MCC_SUBMODULE_COMPLEXITY_REDUCTION_REPORT_$1*.xlsx  MCC_SUBMODULE_COMPLEXITY_REDUCTION_REPORT_$1"_For_Mail.xlsx" 

ls -lrt

cd /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/SCRDetailsReport/

echo "Sending Mail for SCC Report for Module $1..."
cat MailBody_SCR.txt|Mail -s "SCR Report for "$1 -a "/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/SCRDetailsReport/MCC_DATA_"$1"/MCC_SUBMODULE_COMPLEXITY_REDUCTION_REPORT_"$1"_For_Mail.xlsx" $3 anup.barik@tatamotors.com souravk.ttl@tatamotors.com ujjawalk.ttl@tatamotors.com

sleep 2

echo "Mail sent successfully..."
