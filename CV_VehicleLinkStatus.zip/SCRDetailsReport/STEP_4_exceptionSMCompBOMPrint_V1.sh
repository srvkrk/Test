
#######################################################################################################
## Section to process Qty Analyis for Exception parts in QTY_ANALYIS_SUBMODULES_LIST_MODADDR.txt file.
#######################################################################################################
cd /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/SCRDetailsReport/MCC_DATA_$1
echo "Started BOM compare analysis for Exception Modules.. for $1"
pwd
ls -lrt "QTY_ANALYIS_SUBMODULES_LIST_"$1".txt"
#ls -lrt


# while read ExceptionSMLine
	#ExceptionSM_ROWCellNum=`echo $ExceptionSMLine |cut -d ","  -f1`
	#ExceptionSM_COLCellNum=`echo $ExceptionSMLine |cut -d ","  -f2`
	#ExceptionSM_ROW=`echo $ExceptionSMLine |cut -d ","  -f3`
	#ExceptionSM_COL=`echo $ExceptionSMLine |cut -d ","  -f4`
	
	# echo "ExceptionSM_ROW : $ExceptionSM_ROW"
	# echo "ExceptionSM_COL : $ExceptionSM_COL"
	
# done < "QTY_ANALYIS_SUBMODULES_LIST_"$1".txt" 


rm -rf BOM_COMPARE_REPORT_$1.csv
#ls -lrt
#sleep 5
echo "ROW#,COL#,ROW_PARENT,ROW_CHILD,ROW_CHILD_DESC,QTY,COL_PARENT,COL_CHILD,COL_CHILD_DESC,QTY,COMPARISON_REMARKS" >> "BOM_COMPARE_REPORT_"$1".csv"

while read ExceptionSMLine
do
	#COLUMNS_SubModLineCount=$(( $COLUMNS_SubModLineCount + 1 ))
	ExceptionSM_ROWCellNum=`echo $ExceptionSMLine |cut -d ","  -f1`
	ExceptionSM_COLCellNum=`echo $ExceptionSMLine |cut -d ","  -f2`
	ExceptionSM_ROW=`echo $ExceptionSMLine |cut -d ","  -f3`
	ExceptionSM_COL=`echo $ExceptionSMLine |cut -d ","  -f4`

	echo "ExceptionSM_ROWCellNum,ExceptionSM_COLCellNum  : $ExceptionSM_ROWCellNum,$ExceptionSM_COLCellNum"
	echo "ExceptionSM_COL : $ExceptionSM_COL"
	echo "ExceptionSM_ROW : $ExceptionSM_ROW"
	echo "ExceptionSM_COL : $ExceptionSM_COL"

	ROWS_SubModLineCount=0
	
	while read ROWS_SubModLine
	do
		ROWS_SubModLineCount=$(( $ROWS_SubModLineCount + 1 ))
		ROWS_SubMod_Parent_PartNumber=`echo $ROWS_SubModLine |cut -d "^"  -f1`
		ROWS_SubMod_Parent_PartRev=`echo $ROWS_SubModLine |cut -d "^"  -f2`
		ROWS_SubMod_Parent_PartSeq=`echo $ROWS_SubModLine |cut -d "^"  -f3`
		ROWS_SubMod_Child_PartNumber=`echo $ROWS_SubModLine |cut -d "^"  -f5`
		ROWS_SubMod_Child_PartRev=`echo $ROWS_SubModLine |cut -d "^"  -f6`
		ROWS_SubMod_Child_PartSeq=`echo $ROWS_SubModLine |cut -d "^"  -f7`
		ROWS_SubMod_Child_Desc=`echo $ROWS_SubModLine |cut -d "^"  -f8`
		ROWS_SubMod_Child_Qty=`echo $ROWS_SubModLine |cut -d "^"  -f9`		
		ROWS_FormatttedChildPart=$ROWS_SubMod_Child_PartNumber"_"$ROWS_SubMod_Child_PartRev"_"$ROWS_SubMod_Child_PartSeq	
				
		GrepString=$ROWS_SubMod_Child_PartNumber
		#ColStr=`grep  $GrepString $1_MATRIX_MODULARITY_SCORE_FILE.txt|cut -d ","  -f4`
				
		grep $ROWS_SubMod_Child_PartNumber $ExceptionSM_COL".txt"
		#ssh sapjsr@172.31.9.80 -n "ls -lrt /interface/foundrypp/denis/carwar/$TodayFileName"
		if [ $? == 0 ] #child found in columns-submodule.
		then	
			#echo "Its a MATCH...."
			
			COLChildGrepStr=`grep  $ROWS_SubMod_Child_PartNumber $ExceptionSM_COL.txt`
			COLChilPart=`echo  $COLChildGrepStr|cut -d "^"  -f5`
			COLChilRev=`echo  $COLChildGrepStr|cut -d "^"  -f6`
			COLChilSeq=`echo  $COLChildGrepStr|cut -d "^"  -f7`
			COL_FormatttedChildPart=$COLChilPart"_"$COLChilRev"_"$COLChilSeq
			
			COLChilDesc=`echo  $COLChildGrepStr|cut -d "^"  -f8`			
			COLChildQty=`echo  $COLChildGrepStr|cut -d "^"  -f9`
			
			if [ "$ROWS_SubMod_Child_Qty" = "$COLChildQty" ]; then			 				
				echo "Pirnt Matching child rows.. like R,P1,1,C,P1,1,QTY_SAME"
				echo "$ExceptionSM_ROWCellNum,$ExceptionSM_COLCellNum,$ExceptionSM_ROW,$ROWS_FormatttedChildPart,$ROWS_SubMod_Child_Desc,$ROWS_SubMod_Child_Qty,$ExceptionSM_COL,$COL_FormatttedChildPart,$COLChilDesc,$COLChildQty,QTY_SAME" >> "BOM_COMPARE_REPORT_"$1".csv"
			else
				echo "Pirnt Matching child rows.. like R,P1,1,C,P1,1,QTY_DIFF"
				echo "$ExceptionSM_ROWCellNum,$ExceptionSM_COLCellNum,$ExceptionSM_ROW,$ROWS_FormatttedChildPart,$ROWS_SubMod_Child_Desc,$ROWS_SubMod_Child_Qty,$ExceptionSM_COL,$COL_FormatttedChildPart,$COLChilDesc,$COLChildQty,QTY_DIFF" >> "BOM_COMPARE_REPORT_"$1".csv"
			fi
			
		else
			dummy=0
			echo "Pirnt child rows..not found in C.. like R,P1,1,,,,ROW-Child not found in COL"
			echo "$ExceptionSM_ROWCellNum,$ExceptionSM_COLCellNum,$ExceptionSM_ROW,$ROWS_FormatttedChildPart,$ROWS_SubMod_Child_Desc,$ROWS_SubMod_Child_Qty,,,,,CHILD_NOT_IN_COL_SUBMODULE" >> "BOM_COMPARE_REPORT_"$1".csv"
		fi	

	done < $ExceptionSM_ROW".txt"
	
	## Do Col to Row search to check the parts presents in COL Submodule but not in ROW Submodule.
	
	COLS_SubModLineCount=0
	
	while read COLS_SubModLine
	do
		COLS_SubModLineCount=$(( $COLS_SubModLineCount + 1 ))
		COLS_SubMod_Parent_PartNumber=`echo $COLS_SubModLine |cut -d "^"  -f1`
		COLS_SubMod_Parent_PartRev=`echo $COLS_SubModLine |cut -d "^"  -f2`
		COLS_SubMod_Parent_PartSeq=`echo $COLS_SubModLine |cut -d "^"  -f3`
		COLS_SubMod_Child_PartNumber=`echo $COLS_SubModLine |cut -d "^"  -f5`
		COLS_SubMod_Child_PartRev=`echo $COLS_SubModLine |cut -d "^"  -f6`
		COLS_SubMod_Child_PartSeq=`echo $COLS_SubModLine |cut -d "^"  -f7`
		COLS_SubMod_Child_Desc=`echo $COLS_SubModLine |cut -d "^"  -f8`
		COLS_SubMod_Child_Qty=`echo $COLS_SubModLine |cut -d "^"  -f9`		
		COLS_FormatttedChildPart=$COLS_SubMod_Child_PartNumber"_"$COLS_SubMod_Child_PartRev"_"$COLS_SubMod_Child_PartSeq	
				
		GrepString=$COLS_SubMod_Child_PartNumber
		#ColStr=`grep  $GrepString $1_MATRIX_MODULARITY_SCORE_FILE.txt|cut -d ","  -f4`
				
		grep $COLS_SubMod_Child_PartNumber $ExceptionSM_ROW".txt"
		#ssh sapjsr@172.31.9.80 -n "ls -lrt /interface/foundrypp/denis/carwar/$TodayFileName"
		
		if [ $? == 0 ] #child found in columns-submodule.
		then	
			dummy=0
			#echo "Its a MATCH...."	
		else
		
			COLChildGrepStr=`grep  $COLS_SubMod_Child_PartNumber $ExceptionSM_COL.txt`
			COLChilPart=`echo  $COLChildGrepStr|cut -d "^"  -f5`
			COLChilRev=`echo  $COLChildGrepStr|cut -d "^"  -f6`
			COLChilSeq=`echo  $COLChildGrepStr|cut -d "^"  -f7`
			COL_FormatttedChildPart=$COLChilPart"_"$COLChilRev"_"$COLChilSeq
			
			COLChilDesc=`echo  $COLChildGrepStr|cut -d "^"  -f8`			
			COLChildQty=`echo  $COLChildGrepStr|cut -d "^"  -f9`
			
			echo "$ExceptionSM_ROWCellNum,$ExceptionSM_COLCellNum,,,,,$ExceptionSM_COL,$COL_FormatttedChildPart,$COLChilDesc,$COLChildQty,CHILD_NOT_IN_ROW_SUBMODULE" >> "BOM_COMPARE_REPORT_"$1".csv"
			
			echo "Child found which is not present in ROW Submodule, but present in COL Submodule.."
			echo "$ExceptionSM_ROWCellNum,$ExceptionSM_COLCellNum,,,,,$ExceptionSM_COL,$COL_FormatttedChildPart,$COLChilDesc,$COLChildQty,CHILD_NOT_IN_ROW_SUBMODULE"
			
			#sleep 2
		fi	

	done < $ExceptionSM_COL".txt"
		
	echo ",,,,,,,,,," >> "BOM_COMPARE_REPORT_"$1".csv"
	

done < "QTY_ANALYIS_SUBMODULES_LIST_"$1".txt"


cat BOM_COMPARE_REPORT_$1.csv

echo "========================================================================"
echo "Converting to XLS Format now.............."

java -jar ../MCC_FormatMCCCMRToXls.jar $1

sleep 2
ls -lrt

echo "Completed.."
