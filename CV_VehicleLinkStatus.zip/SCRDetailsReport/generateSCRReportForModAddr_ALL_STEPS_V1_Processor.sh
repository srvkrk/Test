############################################################
## To generate SCR Report
##############################################################
#Get ModuleAddres Name
#
StartTime=`date`

cd /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/SCRDetailsReport 

ModAddrName=`grep $1 "/proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/SCRDetailsReport/ModuleAddres_Name_Mapping.config"`

echo "ModAddrName : $ModAddrName"
echo "Started generation SCR Report for Input-ModAddres : $1 ModAddrName: $ModAddrName"

echo "$StartTime,$2,$3,$1,$ModAddrName" >> SCR_Report_Generation_History_Tracking.lst

#exit

echo "Calling STEP_1"
./STEP_1_getSubModulesDataForModAddr_V1.sh $1 > $1_STEP_1.log

sleep 5

echo "Calling STEP_2"
./STEP_2_executeForModArrAndGenerateCompReport_V1.sh $1 > $1_STEP_2.log

sleep 5

echo "Calling STEP_3"
./STEP_3_prepareModuleMatrixCompReport_V1.sh $1 > $1_STEP_3.log

sleep 5

echo "Calling STEP_4"
./STEP_4_exceptionSMCompBOMPrint_V1.sh $1 > $1_STEP_4.log

sleep 5

echo "Calling STEP_5"
./STEP_5_sendMailForGeneratedSCRR_V1.sh $1 $2 $3 > $1_STEP_5.log


echo "Completed.......!"
