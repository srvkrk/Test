############################################################
## To generate SCR Report
##############################################################
#Get ModuleAddres Name
#
StartTime=`date`

cd /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/SCRDetailsReport

nohup ./generateSCRReportForModAddr_ALL_STEPS_V1_Processor.sh $1 $2 $3 > $1_STEP_0_Processor.log&


echo "Completed.......!"
