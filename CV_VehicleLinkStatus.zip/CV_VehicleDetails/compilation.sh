./compile tm_VehicleDetailsRpt.c
./linkitk -o tm_VehicleDetailsRpt tm_VehicleDetailsRpt.o
chmod 777 tm_VehicleDetailsRpt*
