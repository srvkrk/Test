######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : MARCH-2024
#
#######################################################################################

echo -e "\n~~~~~~~~~~ S H E L L   S T A R T E D ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "Input List[First]: -----> "$1

echo "Pre Master File: -----> "$2

echo "Master File: -----> "$3

echo "Report File: -----> "$4

echo "User Email: -----> "$5

echo "Input File: -----> "$6

echo "Report Date: -----> "$7
echo -e "\nIn Shell Argument Print Ended...."
sort -u $2 -o $3

rrule="ERC release and above"
clrule="GenTPLBOMViewClosureRuleERC"
ENDTIME=`date +"%d_%b_%Y_%H_%M_%S"`

echo -e "\nMain Shell Execution Started...."
echo "@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@" >> $4
echo ",,,Input List: " $1 >> $4
echo ",,,Revision Rule: " $rrule >> $4
echo ",,,Closure Rule: " $clrule >> $4
echo ",,,Report Start Date & Time: " $7 >> $4
echo ",,,Report End Date & Time: " $ENDTIME >> $4
echo "@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@,@@@@@@" >> $4
frtLine=`echo PartNo,Rev,Seq,Description,AR/DR,Design Group,Part Type,Spare Indicator,LC State,Quantity`
while read input_line
do
vcno=`echo $input_line |awk -F'_' '{print $1}'`
vcrev=`echo $input_line |awk -F'_' '{print $2}'`
vcseq=`echo $input_line |awk -F'_' '{print $3}'`
FVC_Name="$vcno"_"$vcrev"_"$vcseq"
frtLine+=","
frtLine+=$FVC_Name

done < $6

echo $frtLine >> $4

while read l_line
do
a=`echo $l_line |awk -F',' '{print $1}'`
b=`echo $l_line |awk -F',' '{print $2}'`
c=`echo $l_line |awk -F',' '{print $3}'`
d=`echo $l_line |awk -F',' '{print $4}'`
e=`echo $l_line |awk -F',' '{print $5}'`
f=`echo $l_line |awk -F',' '{print $6}'`
g=`echo $l_line |awk -F',' '{print $7}'`
h=`echo $l_line |awk -F',' '{print $8}'`
i=`echo $l_line |awk -F',' '{print $9}'`
j=`echo $l_line |awk -F',' '{print $10}'`
MainLine="$a","$b","$c","$d","$e","$f","$g","$h","$i","$j"
tempStr=`echo ,`
Module=`echo $l_line |awk -F',' '{print $1}'`
        while read input_line
        do

          vcno=`echo $input_line |awk -F'_' '{print $1}'`
          vcrev=`echo $input_line |awk -F'_' '{print $2}'`
		  vcseq=`echo $input_line |awk -F'_' '{print $3}'`
          File_Name=/tmp/"$vcno"_"$vcrev"_"$vcseq".csv
          FindModule=`echo $(grep -n $Module $File_Name | cut -d : -f 1| tail -n 1)`
          #FindModule=`echo $(grep -n $Module /tmp/"$vcno"_"$vcrev".csv | cut -d : -f 1)`
        if [ -z $FindModule ]
        then
                tempStr+="NO,"
        else
                tempStr+="YES,"
        fi

        done < $6

echo $MainLine
echo $tempStr
fLine=$MainLine$tempStr
echo $fLine
echo $fLine >> $4

done < $3
sed '2d' $4

echo "@@@@@@,@@@@@@,@@@@@@,@@@@@@,E N D   O F   R E P O R T,@@@@@@,@@@@@@,@@@@@@,@@@@@@" >> $4
echo -e "\nMain Shell Execution Ended...."
echo -e "\nReport Send To User Email Started...."
ls -lrt $4
if [ $? == 0 ]
      then
        echo "File Successfully Found on Server"
        echo "Sending Unit BOM Report To User Email"
        echo -e "Dear All, \n\n                Please Check Attached Unit BOM Report.\n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply. For any issues, Raise TMS on PLM." |Mail -s "SUCCESS : Unit BOM Report" -a $4 $5 souravk.ttl@tatamotors.com
      else
        echo "File NOT Foud on server"
        echo "Sending Part Applicability Matrix Repor To Developer Email"
        echo -e "Dear Team, \n\n                There is Some Issue in Unit BOM Report Generation.\n                Please Check Log & Support User.\n\nRegards,\nPLM Team.\n\n*Note : This mail is system genereated. Please do not reply." |Mail -s "FAILED : Unit BOM Report" souravk.ttl@tatamotors.com
fi
echo -e "\nReport Send To User Email Ended...."
echo -e "\n~~~~~~~~~~ S H E L L   E N D E D ~~~~~~~~~~~~"
