<?xml version="1.0" encoding="utf-8"?> 
<xsl:stylesheet version="1.0"  xmlns:xsl="http://www.w3.org/1999/XSL/Transform" > 
<xsl:output method="html"/> 
<xsl:template match="/"> 
<!-- 
*****************************************************************************************************************
Author : Ujjawal Kumar
Date   : August-2024 
Purpose : For MCC Dashboard AWC page.

Change History:
2024-08-01 : Initial Creation by Ujjawal Kumar.

2025-03-19
Modification in NPR section. Added Agreed, Dropped Percentage in Section 6.1
Added DEFENCE Columns in Section 6.3, 6.4

Pls do not copy this code. Copyright@2024.
*****************************************************************************************************************
-->
<html> 
  <head> 
		 <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
		 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
		
		 <link rel = "stylesheet" href = "//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css"></link>
		 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" />
		 					
		<!-- <script type = "text/javascript"      src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>-->
				
		<script type = "text/javascript" src = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
		
		
	  <style>
    /* Tab menu styles */
    .tab {
      overflow: hidden;
      border-bottom: 1px solid #ccc;
    }

    .tab button {
      background-color: inherit;
      float: left;
      border: none;
      outline: none;
      padding: 10px 20px;
      cursor: pointer;
      transition: 0.3s;
    }

    .tab button:hover {
      background-color: #ddd;
    }

    .tab button.active {
      background-color: #ccc;
    }

    /* Tab content styles */
    .tabcontent {
      display: none;
      padding: 15px;
      border: 1px solid #ccc;
      border-top: none;
    }
  </style>
	  
	<style>
	
	body {

    <!-- background-color: #F2F3F4; -->
	background-color: white;
	color: #636363;
	font-size: 11px;
	font-family: Tahoma, Geneva, sans-serif;
   
	}
	
	  h2   {color: blue;}
	  h6   {
		color: #004465;
		<!-- color: #006699; -->
		font-size: 12px;
		font-family: Tahoma, Geneva, sans-serif;
		font-weight: bold;
	  }
	  
	  h6_NPR   {
		color: #e67e22;
		<!-- color: #006699; -->
		font-size: 12px;
		font-family: Tahoma, Geneva, sans-serif;
		font-weight: bold;
	  }
	  
	  h4 {
	  font-family: Tahoma, Geneva, sans-serif;
	  }
	  
	  p {
		color: #006699;
		font-family: Tahoma, Geneva, sans-serif;
		text-align: center;
		}
	  
	  td {
		  border: 0.25px solid #dddfe1;
		  border-collapse: collapse;
		  color: #636363;
		  font-size: 10px;
		  font-family: Tahoma, Geneva, sans-serif;
		  padding: 3px;
		  text-align: center;
		  <!-- white-space: nowrap; -->	  
	  }
	  
	  th{
		  border: 0.25px solid #dddfe1;
		  background-color: #AED6F1;
		  white-space: nowrap;
		  <!-- color: #636363; -->
		  color: #006699;
		  padding: 3px;
		  text-align: center;
		  font-size: 11px;
		  font-family: Tahoma, Geneva, sans-serif;
		  
		  writing-mode: vertical-rl;
		  transform: scale(-1);
		  <!-- writing-mode: vertical-lr;
		  transform: scale(-1); -->
	  }
	  
	  th_awc{
		  border: 0.25px solid #dddfe1;
		  background-color: #006699;
		  white-space: nowrap;
		  color: white;
		  padding: 3px;
		  text-align: center;
		  font-size: 12px;
		  font-family: Tahoma, Geneva, sans-serif;
		  <!-- writing-mode: vertical-lr;
		  transform: scale(-1); -->
	  }
	  
	  tr:nth-child(even) {
		background-color: #f9fafb;
	  
	  }
	  
	  <!-- tr:hover {background-color: #ffff99;} -->
	  
	  <!-- tr:hover td {background:#ffff99; color:#006699; font-weight:bold;} -->
	  tr:hover td {background:#ffff99; color:#006699;}

<!-- 	 .row > div {
		  
		  border: 1px solid grey;
		} -->
		
		
	.td_header {
		  border: 0.25px solid #dddfe1;
		  border-collapse: collapse;
		  color: white;
		  font-size: 12px;
		  font-family: Tahoma, Geneva, sans-serif;
		  padding: 3px;
		  text-align: center;
		  pointer-events: none;
		  <!-- white-space: nowrap; -->	  
	  }
	  
	.tr_nohover{
	  pointer-events: none;
	  }
	  
	.col-md-12 {
		font-size: 16px;
		<!-- font-weight: bold; -->
		background-color: #006699;
		white-space: nowrap;
		color: white;
		text-align: center;
		vertical-align: middle;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	.col-md-6 {
		font-size: 16px;
		font-weight: bold;
		background-color: #006699;
		white-space: nowrap;
		color: white;
		text-align: center;
		vertical-align: middle;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	
	.col-md-1 {
		font-size: 16px;
		font-weight: bold;
		background-color: #EBEDEF;
		white-space: nowrap;
		color: white;
		text-align: center;
		vertical-align: middle;
		padding-top: 5px;
		padding-bottom: 5px;
	}
	
	div.wrap {
	  word-wrap: break-word;
	}
	  
	  
	.label {
	  color: white;
	  padding: 20px;
	}

	.success {background-color: #04AA6D;} /* Green */
	.info {background-color: #2196F3;} /* Blue */
	.warning {background-color: #ff9800;} /* Orange */
	.danger {background-color: #f44336;} /* Red */
	.other {background-color: #e7e7e7; color: black;} /* Gray */
	
.cardInAggGrpPage {
  /* Add shadows to create the "card" effect */
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  background-color: #04AA6D;
  transition: 0.3s;
  font-size: 12px;
  border-radius: 10px; /* 5px rounded corners */
}
		
.card {
  /* Add shadows to create the "card" effect */
<!--   height: 100px;
  width: 300px; -->
  <!-- box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2); -->
  transition: 0.3s;
  border-radius: 10px; /* 5px rounded corners */
}

/* On mouse-over, add a deeper shadow */
.card:hover { 
  box-shadow: 0 2px 10px 0 #006699;
}
<!-- .card_container:hover {
  color : #ffff99; 
} -->

/* Add some padding inside the card container */
.card_container {
  padding: 4px 16px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  color: #626567;
  font-size: 11px;
}

/* Add some padding inside the card container */
.card_container_top {
  padding: 40px 16px;
  height: 250px;
  background-color: #154360;
  color: white;
  vertical-align: middle;
  font-size: 11px;
}
	  
	div.wrap {
	  word-wrap: break-word;
	}  	

.label_alert{
  <!-- display: flex;   -->
  <!-- background-color: #dddfe1; -->
  <!-- background-color: #ffff99; -->
  background-color: #f0fbff;
  <!-- background-color: #ffe2a9; -->
  <!-- background-color: white; ffffc5 ffd071-->
  <!-- color: #636363;  -->
  <!-- color: #004465; -->
  color: #641e16;
  <!-- font-weight: bold; -->
  <!-- text-shadow: 0 0 5px #00ff00, 0 0 5px #00ff00, 0 0 5px #00ff00; -->
  padding: 5px;
  margin-bottom: 5px;  
  <!-- font-size: 13px; -->
  border: 1.25px solid #dddfe1;
  <!-- font-weight: bold; -->
  <!-- box-shadow: 0 0 5px 0 #006699; -->
}

/* On mouse-over, add a deeper shadow */
.label_alert:hover { 
  background-color: #ffff99;
  <!-- font-weight: bold; -->
  box-shadow: 0 0 3px 0 #006699;
}

.label_NPR{
  display: flex;  
  <!-- background-color: #fffcbf; -->
  <!-- background-color: #dddfe1; -->
  <!-- background-color: #f5cba7; -->
  <!-- background-color: #1a5276; -->
    background-color: #fad7a0;
  <!-- background-color: #005078; -->
  <!-- background-color: #fcf3cf; -->
  
  <!-- color: #ffff99;   -->
  color: #7e5109;  
  <!-- color: #fffcbf;   -->
  font-size: 12px;
  font-weight: bold;
  padding: 2px;
  <!-- border: 0.25px solid #abb2b9; -->

  font-family: Tahoma, Geneva, sans-serif;
  
  <!-- font-weight: bold; -->
}

.label_MCC{
  display: flex;  
  <!-- background-color: #fffcbf; -->
  <!-- background-color: #dddfe1; -->
  background-color: #006699;
  <!-- background-color: white; -->
  <!-- background-color: #005078; -->
  <!-- background-color: #fcf3cf; -->
  
  <!-- color: #636363;  -->
  color: white;   
  <!-- color: #004465;   -->
  <!-- color: #fffcbf;   -->
  font-size: 12px;
  font-weight: bold;
  padding: 2px;
  <!-- border: 0.25px solid #abb2b9; -->

  font-family: Tahoma, Geneva, sans-serif;
  
  <!-- font-weight: bold; -->
}

.label1{
  <!-- display: flex;   -->
  <!-- background-color: #fffcbf; -->
  <!-- background-color: #dddfe1; -->
  background-color: white;
  <!-- background-color: white; -->
  <!-- background-color: #005078; -->
  <!-- background-color: #fcf3cf; -->
  
  color: #636363;
  text-align: left;  
  <!-- color: #004465;   -->
  <!-- color: #fffcbf;   -->
  font-size: 12px;
  <!-- font-weight: bold; -->
  padding: 20px;
  border: 1.25px solid #abb2b9;
  <!-- font-weight: bold; -->
}

.label_blue_help{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: left;
  align-content: space-evenly;
  background-color: #AED6F1;
  color: #006699;
  font-weight: bold;
  padding: 5px;
  margin-top: 2px;
  font-size: 15px;
  <!-- border: 1px solid; -->
  <!-- font-weight: bold; -->
}

.label2{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: center;
  align-content: space-evenly;
  background-color: #006699;
  color: white;
  font-weight: bold;
  padding: 5px;
  margin-top: 2px;
  <!-- font-weight: bold; -->
}

.label_info{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: left;
  align-content: space-evenly;
  <!-- background-color: #f0fbff; -->
  <!-- background-color: #AED6F1;   -->
  <!-- background-color: #f0fbff;   -->
  background-color: #f0fbff;  
  <!-- color: #006699; -->
  color: #004465;  
  <!-- font-weight: bold; -->
  padding: 5px;
  margin-bottom: 5px;
  border: 1.25px solid #dddfe1;
  <!-- font-weight: bold; -->
}

.label_info:hover { 
  background-color: #ffff99;
  <!-- font-weight: bold; -->
  box-shadow: 0 0 3px 0 #006699;
}

.label_info_header{
  <!-- display: flex;   -->
  <!-- text-align: center; -->
  text-align: left;
  align-content: space-evenly;
  <!-- background-color: #f0fbff; -->
  background-color: #ffff99;  
  <!-- background-color: #ffff99;   -->
  <!-- color: #006699; -->
  color: #641e16;
  <!-- font-weight: bold; -->
  padding: 2px;
  margin-bottom: 1px;
  border: 1.25px solid #f9e79f;
  <!-- font-weight: bold; -->
}

.ToggleText{  
  text-align: center;  
}

.grid-container {
  display: grid;
  grid-template-columns: auto auto auto;
  gap: 5px;
  <!-- background-color: #F2F3F4; -->
  <!-- background-color: white; -->
  padding: 1px;
  <!-- border: 5.25px solid #FEEBE7; -->
  
}

.grid-container > div {
  <!-- background-color: rgba(255, 255, 255, 0.8); -->
  <!-- text-align: center; -->
  padding: 5px 5px;
  font-size: 11px;
  <!-- border: 1.25px solid #006699; -->
  border-radius: 5px;    

 }
 
 .grid-container > div:hover { 
  box-shadow: 0 2px 10px 0 #006699;
}

.grid-container-2 {
  display: grid;
  grid-template-columns: auto auto auto auto auto auto auto;
  gap: 5px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  padding: 5px;
   border: 1.25px solid #dddfe1;
  
}

.grid_sm_usage_freq {
  display: grid;
  grid-template-columns: 200px auto;
  gap: 5px;
  <!-- background-color: #F2F3F4; -->
  background-color: white;
  padding: 5px;
   border: 1.25px solid #dddfe1;
  
}

.grid-container-2 > div {
  <!-- background-color: white; -->
  <!-- text-align: center; -->
  padding: 10px 10px;
  <!-- font-size: 11px; -->
  border: 2.25px solid #dddfe1;
  border-radius: 5px;
  <!-- border-radius: 10px;     -->

 }
 
 .grid-container-2 > div:hover { 
  box-shadow: 0 2px 10px 0 #006699;
}

.item1 {
  grid-row-start: 1;
  grid-row-end: 3;
  align-content: space-evenly; 
  background-color: #AED6F1;
  <!-- color: white;   -->
}

.item2 {
  grid-row-start: 1;
  grid-row-end: 3;
  align-content: space-evenly;
  background-color: #f9e79f;
  <!-- color: white;   -->
}

.item_red {
  grid-row-start: 1;
  grid-row-end: 1;
  align-content: space-evenly;
  background-color: #FEEBE7;
  color: #C82909;  
  border: 1px solid grey;
  <!-- color: white;   -->
}

.item_yellow {
  grid-row-start: 1;
  grid-row-end: 1;
  align-content: space-evenly;
  background-color: #FEFCE8;
  color: #98670B;  
  border: 1px solid grey;
  <!-- color: white;   -->
}

.item_green {
  grid-row-start: 1;
  grid-row-end: 1;
  align-content: space-evenly;
  background-color: #F0FDF4;
  color: #1ABC4A;  
  border: 1px solid grey;
  <!-- color: white;   -->
}


.itemg2cell {
  align-content: space-evenly;
  background-color: #fff8de;  
}

.itemg2cell_lb {
  align-content: space-evenly;
  background-color: #e0f3ff;  
}

.item21 { 
  text-align: center;
  align-content: space-evenly;
  background-color: #006699;
  color: white;
  font-size: 14px;  
}

.itemUF1 { 
  text-align: center;
  align-content: space-evenly;
  background-color: #006699;
  color: white; 
  vertical-align: middle;
  border-radius: 50px;  
}

.itemg1_1 { 
  text-align: left;
  background-color: #F2F3F4;
  <!-- color: white;   -->
}

.item27{
  text-align: center;
  background-color: #f0fbff;
  font-size: 12px;
  font-weight: bold;
  border: 0.25px solid #dddfe1;
  align-content: space-evenly;
}

.scrollable_div {
	border: 0.5px solid #ccc;
	height: 600px; /* Fixed height */
	overflow-y: auto; /* Show scrollbar only when needed */
	<!-- padding: 5px; -->
}

</style>
	
	
	
<script>

	$(document).ready(function(){
	 <!--  $("#linebtn").click(function(){
		$("#myChart1").toggle();
	  });
	  $("#barbtn").click(function(){
		$("#myChart2").toggle();
	  }); -->


	$("#myInput1AT").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableALTROZTrend tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1HT").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableHARRIERTrend tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
		  
	$("#myInput1AR").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableAPPENGGReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1HR").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableCHASSISReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1PR").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableCABReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1SR").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableEEReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1AT").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTablePOWERTRAINReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });
	$("#myInput1HT").on("keyup", function() {
		var value = $(this).val().toLowerCase();
		$("#myTableVEHICLEReport tr").filter(function() {
		  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		});
	  });

	$("#tabs").tabs();	  
	  
	});
	
	
	</script>

  <script type="text/javascript">
          <![CDATA[
            
  function openTab(evt, tabName) {
    // Hide all tab contents
    var tabcontent = document.getElementsByClassName("tabcontent");
    for (let i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }

    // Remove active class from all buttons
    var tablinks = document.getElementsByClassName("tablinks");
    for (let i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the clicked tab and add active class
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
  }

  // Optional: Open the first tab by default
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelector(".tablinks").click();
  });
		  
          ]]>
  </script>	
  
	<script type="text/javascript">
		<![CDATA[
		document.addEventListener('DOMContentLoaded', function () {
					document.querySelectorAll('.modal_link_section').forEach(function (link) {
					  link.addEventListener('click', function (e) {
						e.preventDefault();
						const itemId = this.getAttribute('data-id');
						//alert('Pls proceed to show data for Product-line : ' + itemId);
						const content = document.getElementById('item-' + itemId);
						<!-- alert(111); -->
						//alert(content.innerHTML);
						if (content) {
						  document.getElementById('myCollapse').innerHTML = content.innerHTML;							  
						} else {
						  document.getElementById('myCollapse').innerHTML = "<p>Item not found.</p>";
						}
					  });
					});
				  });		  
		]]>
	</script>
	
<script type="text/javascript">
          <![CDATA[
          function toggleRow() {
		  
            //var row_1 = document.getElementById('TableHeaderToToggle_1');
            //if (row_1.style.display === 'none') {
            //  row_1.style.display = '';
            //} else {
           //   row_1.style.display = 'none';
            //}
			
			//var row_2 = document.getElementById('TableHeaderToToggle_2');
            //if (row_2.style.display === 'none') {
            //  row_2.style.display = '';
            //} else {
            //  row_2.style.display = 'none';
            //}
			
			var row_3 = document.getElementById('TableHeaderToToggle_3');
            if (row_3.style.display === 'none') {
              row_3.style.display = '';
            } else {
              row_3.style.display = 'none';
            }
          }
		  
		  
		function toggleColumn_NODE_1() {
			const table = document.getElementById('NPRTable');
			const rows = table.rows;
		  
			  //alert("Row Length" + rows.length);
			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[1];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[2];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[3];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[4];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[5];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
		}
		
		function toggleColumn_NODE_2() {
			const table = document.getElementById('NPRTable');
			const rows = table.rows;
		  
			  //alert("Row Length" + rows.length);
			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[6];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[7];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[8];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[9];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[10];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
		}
		
		function toggleColumn_NODE_3() {
			const table = document.getElementById('NPRTable');
			const rows = table.rows;
		  
			  //alert("Row Length" + rows.length);
			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[11];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[12];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[13];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[14];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[15];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
		}
		
		function toggleColumn_NODE_4() {
			const table = document.getElementById('NPRTable');
			const rows = table.rows;
		  
			  //alert("Row Length" + rows.length);
			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[1];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[2];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[3];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[4];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[5];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
		}
		
		function toggleColumn_NODE_5() {
			const table = document.getElementById('NPRTable');
			const rows = table.rows;
		  
			  //alert("Row Length" + rows.length);
			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[6];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[7];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[8];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[9];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[10];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
		}
		
		function toggleColumn_NODE_6() {
			const table = document.getElementById('NPRTable');
			const rows = table.rows;
		  
			  //alert("Row Length" + rows.length);
			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[11];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[12];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[13];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[14];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }			  
			  for (let i = 0; i < rows.length; i++) {
				const cell = rows[i].cells[15];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
		}
		
		
		function toggleColumn_Show_All() {
			const table = document.getElementById('NPRTable');
			const rows = table.rows;
		  
			  //alert("Row Length" + rows.length);
			  
			  for (let i = 0; i < rows.length; i++) {			    
										
				for (let j = 0; j < 15; j++){				
					const cell = rows[i].cells[j];					
					  cell.style.display = '';					
				}
			  }		  
			  
		}	
		
		function toggleAggregateRows() {
			const table = document.getElementById('NPRTable');
			const rows = table.rows;		  
			 
			for (let i = 0; i < 16; i++) {
				const cell = rows[8].cells[i];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
			  
			for (let i = 0; i < 16; i++) {
				const cell = rows[9].cells[i];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
			  
			for (let i = 0; i < 16; i++) {
				const cell = rows[10].cells[i];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
			  
			for (let i = 0; i < 16; i++) {
				const cell = rows[11].cells[i];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
			  
			for (let i = 0; i < 16; i++) {
				const cell = rows[12].cells[i];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
			  
			for (let i = 0; i < 16; i++) {
				const cell = rows[13].cells[i];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
			  
			for (let i = 0; i < 16; i++) {
				const cell = rows[14].cells[i];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
			  
			for (let i = 0; i < 16; i++) {
				const cell = rows[15].cells[i];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
			  
			for (let i = 0; i < 16; i++) {
				const cell = rows[16].cells[i];
				if (cell.style.display === 'none') {
				  cell.style.display = '';
				} else {
				  cell.style.display = 'none';
				}
			  }
			  
		}
		

          ]]>
        </script>
</head> 

<body> 
    <!--<canvas id="myChart" style="width:100%;max-width:600px"></canvas> -->

<!-- Tab headers -->
<div class="tab">
  <button class="tablinks" onclick="openTab(event, 'Tab1')">NPR Status DASHBOARD</button>
  <!-- <button class="tablinks" onclick="openTab(event, 'Tab2')">NPR Status Detail Report</button> -->
  <button class="tablinks" onclick="openTab(event, 'Tab3')">Help</button>
</div>

<div id="Tab2" class="tabcontent">
  <h3>NPR Status Detail Report</h3>
  <p>Content for Report.</p>
</div>

<div id="Tab3" class="tabcontent">
<div class="container">
  <center>
  <h4>Help Page</h4>
   
  <div class="label_blue_help">
  Columns of NPR Dashboard.
  </div>
  <div class="label1">	
  
Product_Line
Aggregate_Group	
<br></br><br></br>
<b>[1] NPR Raiser (New)</b><br></br>
Raised Total<br></br>	

Signoff Complete<br></br>	

Avg. Completion Age (In Days)<br></br>	

Signoff Pending	<br></br>

Avg. Pending Age (In Days)	<br></br>
<br></br>
<br></br>
<b>[2] Module Review</b><br></br>
Raised Total	<br></br>

Signoff Complete<br></br>	

Avg. Completion Age(In Days)<br></br>	

Signoff Pending	<br></br>

Avg. Pending Age(In Days)<br></br>
<br></br>
<br></br>	
<b>[3] COC PE Review</b><br></br>
Raised Total	<br></br>

Signoff Complete	<br></br>

Avg. Completion Age(In Days)	

Signoff Pending	<br></br>

Avg. Pending Age(In Days)<br></br>
<br></br>
<br></br>	
<b>[4] MCC Review</b><br></br>
Raised Total	<br></br>

Signoff Complete<br></br>	

Avg. Completion Age(In Days)	<br></br>

Signoff Pending	<br></br>

Avg. Pending Age(In Days)<br></br>
<br></br>
<br></br>	
<b>[5] COC Head-PE Review</b><br></br>
Raised Total	<br></br>

Signoff Complete	<br></br>

Avg. Completion Age(In Days)<br></br>	

Signoff Pending	<br></br>

Avg. Pending Age(In Days)<br></br>
<br></br>
<br></br>	
<b>[6] NPR Raiser (Ack Stage)</b><br></br>
Raised Total	<br></br>

Signoff Complete	<br></br>

Avg. Completion Age(In Days)<br></br>	

Signoff Pending	<br></br>

Avg. Pending Age(In Days)<br></br>
	
  </div>
  <br></br>
  
  <div class="label_blue_help">
  Other/Remarks
  </div>
  <div class="label1">
	For any further queries/support, please get in touch with :-
	<br></br>
	TML : Ravindra Patil, Machhindra Kamthe, Aditya Dole
	<br></br>
	TTL : Ujjawal Kumar, Sudhir Srivastava, Sourav Karak, Manisha Joshi
  </div>
  <br></br>
    			
  </center>
  </div>
</div>

<!-- Tab content -->
<div id="Tab1" class="tabcontent">

	<div class="container">	
	
	<!-- <div id = "tabs"> -->
			<!-- <ul>
				<li><a href = "#tabs-1"><font size="2px">MCC<br></br><b>Main DASHBOARD</b></font></a></li>
				<li><a href = "#tabs-2"><font size="2px">MCC Dashboard<br></br>Vehicle Compliance Reports</font></a></li> -->
				<!-- <li><a href = "#tabs-8">Report<br></br>PUNCH</a></li> -->
				<!-- <li><a href = "#tabs-9">Report<br></br>SAFARI</a></li> -->
	<!--        <li><a href = "#tabs-3">NA Module Count(Bar Chart)</a></li>
				<li><a href = "#tabs-4">Trend Report</a></li> -->
			<!-- </ul> -->

		<!-- tabs-1 Dashboard. -->	
		
		

		<!-- <div id = "tabs-1">	 -->

			<!-- <div class="row m-3"> 
				<div class="col-sm-12">
					<center><h5><b>Modularity and Configuration Cell (MCC)</b></h5></center>					
				</div>
			</div> -->
						
			
			
						
			<!-- <center><h5><b>[MCC] NPR STATUS DASHBOARD</b></h5></center>			 -->
			<!-- <center><h7><b>Below Stages [1 -6] are as per New Part Request (NPR) Workflow in TCUA-PLM</b></h7></center> -->
						
			<div class="row"> 
				<!-- <div class="col-sm-1"></div> -->
				<div class="col-sm-12">
				
					<div class="label_info_header" style="font-size: 11px; text-align: center">
					<!-- As per data last updated on date : 10 Oct, 2024 (Thursday) @ 22:35 hrs. -->
					
						<xsl:for-each select="MCCMainDashboardRpt/DataRefreshDate">						
							Below Dashboard data is as per last updated on date : <xsl:value-of select="LastDate"/>							
						</xsl:for-each>		
					
					</div>
				
					<!-- <br></br> -->
					<div class="ToggleText">
						Click links to SHOW/HIDE : 						
						<!-- <a href="#" onclick="toggleColumn_NODE_1(); return false;">[[1] NPR Raiser (New)]</a> -->
						<!-- <xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text>		 -->
						<!-- <a href="#" onclick="toggleColumn_NODE_2(); return false;">[[2] Module Review]</a> -->
						<!-- <xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text> -->
						<!-- <a href="#" onclick="toggleColumn_NODE_3(); return false;">[[3] COC PE Review]</a> -->
						<!-- <xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text> -->
						<a href="#" onclick="toggleColumn_NODE_4(); return false;">[[4] MCC Review]</a>
						<xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text>
						<a href="#" onclick="toggleColumn_NODE_5(); return false;">[[5] COC Head-PE Review]</a>
						<xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text>
						<a href="#" onclick="toggleColumn_NODE_6(); return false;">[[6] NPR Raiser (Ack Stage)]</a>
						<xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text>
						<a href="#" onclick="toggleRow(); return false;">[Table Header]</a>
						<xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text>
						<a href="#" onclick="toggleColumn_Show_All(); return false;">[Show All Columns]</a>	
						
						
						<xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text><xsl:text>&#160;</xsl:text>
						<a href="#" onclick="toggleAggregateRows(); return false;">[Show Aggregate-Wise Dashboard]</a>	
					</div>
						
						<center>
						
						<table width="100%">
						
						<tr class="tr_nohover">					        
								<!-- <td colspan="31" bgcolor="#006699" style="font-size: 15px;"> -->
								<td colspan="16" bgcolor="#006699" style="font-size: 15px;">
									<font color="white"><b>[MCC] NPR STATUS DASHBOARD</b></font>
								</td>
									   <!-- <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td> -->								
							</tr>
							
							
							<!-- 
							<tr class="tr_nohover" id="TableHeaderToToggle_1">	
																
								<td bgcolor="#006699" style="width: 150px;">
								<font color="white">
									<b>Color Legend:</b>
								</font>
								</td>
							  
								<td bgcolor="#21618c" style="width: 150px;">	
									<font color="white">
										<b>[1] NPR Raiser (New)</b>
									</font>
								</td>	
								<td bgcolor="#873600" style="width: 150px;">	
									<font color="white">
										<b>[2] Module Review</b>
									</font>
								</td>
								<td bgcolor="#797d7f" style="width: 150px;">	
									<font color="white">
										<b>[3] COC Principal Eng. Review</b>
									</font>
								</td>
								<td bgcolor="#9a7d0a" style="width: 150px;">	
									<font color="white">
										<b>[4] MCC Review</b>
									</font>
								</td>
								<td bgcolor="#633974" style="width: 150px;">	
									<font color="white">
										<b>[5] COC Head Platform Eng. Review</b>
									</font>
								</td>
								<td bgcolor="#117864" style="width: 150px;">	
									<font color="white">
										<b>[6] NPR Raiser (Ack Stage)</b>
									</font>
								</td>				  						  
							</tr>
							
							 -->
							
							
						</table>
						</center>					
							
						<table width="100%" id="NPRTable">								
							
							<tr class="tr_nohover" id="TableHeaderToToggle_3">	
								<!-- <td bgcolor="#006699" align="center"><font color="white"> -->
								<td bgcolor="#006699" style="width: 80px; white-space: nowrap;">
									<font color="white">
										<b>Product_Line
										<br></br>
										Aggregate_Group
										</b>
									</font>							
									</td>
			
													
								
								
								
								<td bgcolor="#b7950b">	
								<font color="white">
									<b>[4] MCC Review</b>
									<br></br>
									Raised Total									
								</font>
								</td>			  
						
								<td bgcolor="#b7950b">
									<font color="white">										
									<b>[4] MCC Review</b>
									<br></br>
									Signoff Complete									
									</font>
								</td>
								<td bgcolor="#b7950b" style="width: 150px;">
									<font color="white">										
									<b>[4] MCC Review</b>
									<br></br>
									Avg. Completion Age(In Days)
									</font>
								</td>								
								<td bgcolor="#b7950b">
									<font color="white">										
									<b>[4] MCC Review</b>
									<br></br>
									Signoff Pending
									</font>
								</td>					
								<td bgcolor="#b7950b" style="width: 150px;">
									<font color="white">										
									<b>[4] MCC Review</b>
									<br></br>
									Avg. Pending Age(In Days)
									</font>
								</td>
								
								<td bgcolor="#884ea0">	
								<font color="white">
									<b>[5] COC Head-PE Review</b>
									<br></br>
									Raised Total									
								</font>
								</td>			  
						
								<td bgcolor="#884ea0">
									<font color="white">										
									<b>[5] COC Head-PE Review</b>
									<br></br>
									Signoff Complete									
									</font>
								</td>
								<td bgcolor="#884ea0" style="width: 150px;">
									<font color="white">										
									<b>[5] COC Head-PE Review</b>
									<br></br>
									Avg. Completion Age(In Days)
									</font>
								</td>								
								<td bgcolor="#884ea0">
									<font color="white">										
									<b>[5] COC Head-PE Review</b>
									<br></br>
									Signoff Pending
									</font>
								</td>					
								<td bgcolor="#884ea0" style="width: 150px;">
									<font color="white">										
									<b>[5] COC Head-PE Review</b>
									<br></br>
									Avg. Pending Age(In Days)
									</font>
								</td>
								
								<td bgcolor="#17a589">	
								<font color="white">
									<b>[6] NPR Raiser (Ack Stage)</b>
									<br></br>
									Raised Total									
								</font>
								</td>			  
						
								<td bgcolor="#17a589">
									<font color="white">										
									<b>[6] NPR Raiser (Ack Stage)</b>
									<br></br>
									Signoff Complete									
									</font>
								</td>	
								<td bgcolor="#17a589" style="width: 150px;">
									<font color="white">										
									<b>[6] NPR Raiser (Ack Stage)</b>
									<br></br>
									Avg. Completion Age(In Days)
									</font>
								</td>
								<td bgcolor="#17a589">
									<font color="white">										
									<b>[6] NPR Raiser (Ack Stage)</b>
									<br></br>
									Signoff Pending
									</font>
								</td>					
								<td bgcolor="#17a589" style="width: 150px;">
									<font color="white">										
									<b>[6] NPR Raiser (Ack Stage)</b>
									<br></br>
									Avg. Pending Age(In Days)
									</font>
								</td>			
								
													  						  
							</tr>
							
							<!-- <tr>
									   <td colspan="25" bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>									   
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
									   <td bgcolor="#006699"></td>
							</tr> -->
							
						<!-- tr:hover {background-color: #ffff99;} -->
																	
									<tr>								   								    
									   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
									   
									   <td style="text-align: left;">											
											<b>[1] BUS</b>
									   </td>			   


										<xsl:for-each select="MCCMainDashboardRpt/PL_BUS">
										
												
												
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>										
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">																							
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="BUS" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>											
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
										
									</tr>
									
									
									<tr>								   								    
										 <td style="text-align: left;">											
											<b>[2] HCV</b>
									   </td>	

											<xsl:for-each select="MCCMainDashboardRpt/PL_HCV">
										
												
												
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>											
												</td>																						   
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="HCV" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
									   									   
									</tr>
									
									
									<tr>								   								    
									   
										 <td style="text-align: left;">											
											<b>[3] ILMCV</b>
									   </td>
										
										<xsl:for-each select="MCCMainDashboardRpt/PL_ILMCV">
										
												
												
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>											
												</td>																						   
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="ILMCV" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
										
									</tr>
									<tr>								   								    
									   
										 <td style="text-align: left;">											
											<b>[4] SCV</b>
									   </td>
									   
										<xsl:for-each select="MCCMainDashboardRpt/PL_SCV">
										
												
												
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>										
												</td>																						   
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="SCV" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
									   									   
									</tr>
									
									<tr>								   								    
									   
									    <td style="text-align: left; white-space: nowrap;">											
											<b>[5] AGGR-BUSINESS</b>
									    </td>
									   
										<xsl:for-each select="MCCMainDashboardRpt/PL_AGGRBUSINESS">
										
												
												
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>											
												</td>																						   
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="AGGREGATE" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
									   									   
									</tr>
									
									<tr>								   								    
									   
										<td style="text-align: left; white-space: nowrap;">											
											<b>[6] DEFENCE</b>
									    </td>
										
											<xsl:for-each select="MCCMainDashboardRpt/PL_DEFENCE">
										
												
												
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>										
												</td>																						   
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="Defence" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
									   								   
									</tr>
									
									
									
									
									
									<tr class="tr_nohover">								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->										   
										 
										<td bgcolor="#006699" style="text-align: right">
											<font color="white"><b>Product_Line TOTAL</b></font>
										</td>	
												<xsl:for-each select="MCCMainDashboardRpt/PL_TOTAL_ROW">
																										
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b></font>										
													</td>
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></b></font>									
													</td>
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white">
														<b>(Avg: <xsl:value-of select="Stage4_MCCReview_AvgCompletionAge"/> Days)</b>
														</font>										
													</td>													
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white">
														<b>(Avg: <xsl:value-of select="Stage4_MCCReview_AvgPendingAge"/> Days)</b>
														</font>									
													</td>																						   
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/></b></font>									
													</td>
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/></b></font>									
													</td><td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/></b></font>									
													</td>
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/></b></font>									
													</td>																						   
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/></b></font>								
													</td>																			
													
													
											</xsl:for-each>	
											
								</tr>
									
								<!-- ########################################### -->
								<!-- STARTING AGGREGATE-WISE SECTION. -->
								<!-- ########################################### -->
								
								<tr>								   								    
									   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->
									   
									   <td style="text-align: left; white-space: nowrap;">											
											<b>[1] D-CAB</b>
									    </td>			   


										<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_D-CAB">
										
												
												
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>										
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>												
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="D-CAB" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>											
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
										
									</tr>
									
									
									<tr>								   								    
										<td style="text-align: left; white-space: nowrap;">											
											<b>[2] F-CHASSIS</b>
									    </td>

											<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_F-CHASSIS">
										
												
												
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>										
												</td>																						   
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="F-CHASSIS" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
									   									   
									</tr>
									
									
									<tr>								   								    
									   
										<td style="text-align: left; white-space: nowrap;">											
											<b>[3] G-E_AND_E</b>
									    </td>
										
										<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_G-E_AND_E">
												
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>										
												</td>																						   
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="G-E_AND_E" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
										
									</tr>
									<tr>								   								    
									   
										<td style="text-align: left; white-space: nowrap;">											
											<b>[4] H-POWERTRAIN</b>
									    </td>
									   
										<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_H-POWERTRAIN">
										
												
												
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>										
												</td>																						   
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="H-POWERTRAIN" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
									   									   
									</tr>
									
									<tr>								   								    
									   
										<td style="text-align: left; white-space: nowrap;">											
											<b>[5] A-APPLICATION_ENGINEERING</b>
									    </td>
									   
										<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_A-APPLICATION_ENGINEERING">
																						
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>										
												</td>																						   
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="A-APPLICATION_ENGINEERING" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
									   									   
									</tr>
									
									<tr>								   								    
									   
										<td style="text-align: left; white-space: nowrap;">											
											<b>[6] K-VEHICLE</b>
									    </td>
										
											<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_K-VEHICLE">
										
																								
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b>											
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<font color="#2AA63E"><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></font>										
												</td>																						   
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgCompletionAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Completion_Total_Days/Completed_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#2AA63E">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																								
												</td>														
												<td bgcolor="#fef9e7" style="text-align: right;">
													<a href="#" style="color: #FB2C36;" class="modal_link_section" data-id="K-VEHICLE" data-bs-toggle="scrollable_div" data-bs-target="#myCollapse">
													<xsl:value-of select="Stage4_MCCReview_SignOffPending"/></a>													
												</td>
												<td bgcolor="#fef9e7" style="text-align: right;">											
													<xsl:variable name="input" select="Stage4_MCCReview_AvgPendingAge" />
													<xsl:variable name="AvgDaysVal" select="substring-before($input, ' ')" />
													<xsl:variable name="span_text" select="substring-after($input, ' ')" />
													<span title="Pending_Total_Days/Pending_NPR_Count : {$span_text} : {$AvgDaysVal} Days">
														<font color="#FB2C36">
															(Avg: <xsl:value-of select="substring-before($input, ' ')" /> Days)
														</font>
													</span>																						
												</td>
												
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/>											
												</td>																						   
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/>											
												</td>														
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/>												
												</td>
												<td bgcolor="#f4ecf7">											
													<xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/>												
												</td>
												
												<td bgcolor="#e8f8f5">											
													<xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/>													
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/>													
												</td>																						   
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/>							
												</td>														
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/>								
												</td>
												<td bgcolor="#e8f8f5">													
													<xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/>								
												</td>
												
										</xsl:for-each>	
									   								   
									</tr>
									
									
									<tr class="tr_nohover">								   								    
										   <!-- <th rowspan="6">NPR Status<br></br>PL-Wise</th> -->										   
										 
										<td bgcolor="#006699" style="text-align: right">
											<font color="white"><b>Aggregate_Group TOTAL</b></font>
										</td>	
												<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_TOTAL_ROW">
																										
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage4_MCCReview_RaisedTotal"/></b></font>										
													</td>
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage4_MCCReview_SignOffComplete"/></b></font>									
													</td>
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white">
														<b>(Avg: <xsl:value-of select="Stage4_MCCReview_AvgCompletionAge"/> Days)</b>
														</font>										
													</td>													
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white">
														<b>(Avg: <xsl:value-of select="Stage4_MCCReview_AvgPendingAge"/> Days)</b>
														</font>									
													</td>																						   
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage5_COCHPEReview_RaisedTotal"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage5_COCHPEReview_SignOffComplete"/></b></font>									
													</td>
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage5_COCHPEReview_AvgCompletionAge"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage5_COCHPEReview_SignOffPending"/></b></font>									
													</td><td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage5_COCHPEReview_AvgPendingAge"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage6_NPRRaiserAckn_RaisedTotal"/></b></font>									
													</td>
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage6_NPRRaiserAckn_SignOffComplete"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage6_NPRRaiserAckn_AvgCompletionAge"/></b></font>									
													</td>																						   
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage6_NPRRaiserAckn_SignOffPending"/></b></font>									
													</td>														
													<td bgcolor="#006699" style="text-align: right;">											
														<font color="white"><b><xsl:value-of select="Stage6_NPRRaiserAckn_AvgPendingAge"/></b></font>								
													</td>																			
													
													
											</xsl:for-each>	
											
								</tr>
							
									
						</table>
				
					<!-- <div class="label_info"> -->
					<!-- This section shows table with Product-Line/Aggregate-Group wise data of NPR data at different stages as per NPR Workflow. -->
					<!-- </div>	 -->
				</div>
				<!-- <div class="col-sm-1"></div>  -->
							
			 </div>	

						<!-- ############### -->
			
			
									
			<div class="scrollable_div" id="myCollapse">
			  <center>						  
				Section to show data based on above click link.
				<br></br>
				Pls click on links in 'Total Obsolescence Pending' Column.
			  </center>
			</div>


			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_BUS" style="display: none;">	
				 <div id="item-BUS">
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Product_Line : <u>BUS</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/PL_BUS">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'BUS'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'BUS'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'BUS'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>							  
				</div>
			</div>
			
			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_HCV" style="display: none;">	
				<div id="item-HCV">
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Product_Line : <u>HCV</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/PL_HCV">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'HCV'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'HCV'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'HCV'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
				</div>
			</div>
			
			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_ILMCV" style="display: none;">	
				<div id="item-ILMCV">
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Product_Line : <u>ILMCV</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/PL_ILMCV">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'ILMCV'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'ILMCV'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'ILMCV'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
				 
				</div>
			</div>
			
			
			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_SCV" style="display: none;">	
				<div id="item-SCV">
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Product_Line : <u>SCV</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/PL_SCV">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'SCV'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'SCV'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'SCV'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
											  
				</div>
			</div>
			
			
			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_AGGREGATE" style="display: none;">	
				<div id="item-AGGREGATE">
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Product_Line : <u>AGGREGATE</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/PL_AGGRBUSINESS">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'AGGREGATE'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'AGGREGATE'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'AGGREGATE'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
				 
				</div>
			</div>
			
			
						<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_Defence" style="display: none;">	
				<div id="item-Defence">				 
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Product_Line : <u>DEFENCE</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/PL_DEFENCE">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'Defence'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'Defence'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Product_Line = 'Defence'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><b><xsl:value-of select="Product_Line"/></b></td>	   
													<td><xsl:value-of select="Aggregate_Group"/></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
								
				</div>
			</div>
			
			<!-- ############################################################################################################################33 -->
			<!-- AGGREGATE-WISE SECTION STARTS -->
			<!-- ############################################################################################################################33 -->
			
			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_D-CAB" style="display: none;">	
				<div id="item-D-CAB">				 
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Aggregate Group : <u>D-CAB</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_D-CAB">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'D-CAB'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'D-CAB'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'D-CAB'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
								
				</div>
			</div>
			
			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_F-CHASSIS" style="display: none;">	
				<div id="item-F-CHASSIS">				 
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Aggregate Group : <u>F-CHASSIS</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_F-CHASSIS">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'F-CHASSIS'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'F-CHASSIS'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'F-CHASSIS'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
								
				</div>
			</div>
			
			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_G-E_AND_E" style="display: none;">	
				<div id="item-G-E_AND_E">				 
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Aggregate Group : <u>G-E_AND_E</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_G-E_AND_E">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'G-E_AND_E'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'G-E_AND_E'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'G-E_AND_E'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
								
				</div>
			</div>
			
			
			
			
			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_H-POWERTRAIN" style="display: none;">	
				<div id="item-H-POWERTRAIN">				 
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Aggregate Group : <u>H-POWERTRAIN</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_H-POWERTRAIN">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'H-POWERTRAIN'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'H-POWERTRAIN'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'H-POWERTRAIN'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
								
				</div>
			</div>
			
			
			
			
			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_A-APPLICATION_ENGINEERING" style="display: none;">	
				<div id="item-A-APPLICATION_ENGINEERING">				 
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Aggregate Group : <u>A-APPLICATION_ENGINEERING</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_A-APPLICATION_ENGINEERING">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'A-APPLICATION_ENGINEERING'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'A-APPLICATION_ENGINEERING'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'A-APPLICATION_ENGINEERING'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
								
				</div>
			</div>
			
			
			
			<!-- Hidden divs for each item's modal content -->
			<div id="SectionNPRPendingData_K-VEHICLE" style="display: none;">	
				<div id="item-K-VEHICLE">				 
					<div class="container-fluid">							
						<div class="row">									
							<div class="col-sm-12">	
								<center>																		
								<!-- Search HCV Data : <input id="myInputSearchID" type="text" placeholder="Search in below table.."></input> -->
								<!-- <br></br> -->
								<center><h6>Pending NPR for Aggregate Group : <u>K-VEHICLE</u></h6></center>	
								<xsl:for-each select="MCCMainDashboardRpt/AGGRGRP_K-VEHICLE">
								
									<div class="grid-container">
									  <div class="item_red">
									  NPRs pending more than 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_MoreThan2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_yellow">
									  NPRs pending between 1 and 2 Weeks : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_Between1And2Weeks"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									  <div class="item_green">
									  NPRs pending less than 1 Week : 
									  <b><xsl:value-of select="Stage4_MCCReview_AvgPendingAge_LessThan1Week"/> of <xsl:value-of select="Stage4_MCCReview_SignOffPending"/></b>
													  
									  </div>
									</div>
								</xsl:for-each>
								<br></br>								
																						
								<!-- More than 2 Weeks -->
								<table width="100%">	
									
									<tr bgcolor="#006699" class="tr_nohover">	
							
										<!-- <td><font color="white"><b>SRL</b></font></td> -->
										<td bgcolor="#006699"><font color="white"><b>NPR_NUMBER</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>PRODUCT_LINE</b></font></td>															
										<td bgcolor="#006699"><font color="white"><b>AGGREGATE_GROUP</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>MCC_REVIEWER_NAME</b></font></td>						  
										<td bgcolor="#006699"><font color="white"><b>START_DATE_TIME</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>END_DATE_TIME</b></font></td>													
										<td bgcolor="#006699"><font color="white"><b>AGEING (Days)</b></font></td>										
										<td bgcolor="#006699"><font color="white"><b>MCC REVIEW STATUS</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>AGEING_CATEGORY</b></font></td>
										<td bgcolor="#006699"><font color="white"><b>TML_PART_NUMBER</b></font></td>
									</tr>
														
									<tbody id="myInputSearchBody">
									
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'K-VEHICLE'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">														
											  </xsl:when>
											  <xsl:otherwise>														
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEEBE7"><font color="#C82909"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>	
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'K-VEHICLE'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <!-- <xsl:when test="Ageing &gt; 14"> -->	
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
												<tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#FEFCE8"><font color="#98670B"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									<xsl:for-each select="MCCMainDashboardRpt/NODE_4_MCC_REVIEW_STAGE_DATA/MCC_REVIEW_STAGE_ROW">										
										<xsl:if test="Aggregate_Group = 'K-VEHICLE'">							
											<xsl:choose>
											 <xsl:when test="Ageing &lt; 7">
											  <tr>															  
													<!-- <td bgcolor="#FFE2E2"><b><xsl:value-of select="Serial"/></b></td> -->
													<td align="center"><xsl:value-of select="NPR_Number"/></td>
													<td align="center"><xsl:value-of select="Product_Line"/></td>	   
													<td><b><xsl:value-of select="Aggregate_Group"/></b></td>
													<td><xsl:value-of select="MCC_Reviewer_Name"/></td>		
													<td style="text-align: right;"><xsl:value-of select="Start"/></td>		
													<td></td>		
													<td style="text-align: right;">
														<xsl:value-of select="Ageing"/> Days
													</td>																
													<td align="center"><font color="red"><xsl:value-of select="Status"/></font></td>
													<td bgcolor="#F0FDF4"><font color="#1ABC4A"><xsl:value-of select="Ageing_Category"/></font></td>														
													<td><xsl:value-of select="TML_Part_Number"/></td>
												</tr>
											  </xsl:when>
											  <xsl:when test="Ageing &gt; 7 and Ageing &lt; 15">
													<!-- Do nothing. -->
											  </xsl:when>
											  <xsl:otherwise>												
													<!-- Do nothing. -->
											  </xsl:otherwise>
											</xsl:choose>
										</xsl:if>
									</xsl:for-each>
									
									</tbody>
								</table>								
								</center>
							</div>
						</div>  
						<center>
						<font size="1px">Copyright@2025 PLM Team</font>
						</center>									
					</div>
								
				</div>
			</div>
	
		
        <!-- ####################################################	 -->
		<br></br>
		<hr style="height:5px;border-width:0;color:gray;background-color:gray"></hr>

		<center>
		<font size="2px">Copyright@2025 (PLM ERC Team)</font>
		</center>
					 

				

			
	<!-- </div> -->
			

	<!-- </div> -->
		
		 
</div>

</div>

	
  </body> 
</html> 

</xsl:template>
</xsl:stylesheet> 