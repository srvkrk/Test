echo "Going to update NPR Status Dashboard XSL file..."

$TC_ROOT/bin/import_file -u=infodba -pf=/user/cvprod/shells/Admin/infodbapasswdfile.pwf -g=dba -f=mcc_npr_status_dashboard.xsl -type=CrfHtmlStylesheet -d=mcc_npr_status_dashboard -ref=XSL -de=r

sleep 3

echo "Updated .xsl file mcc_npr_status_dashboard.xsl"

ls -lrt
