########################################################################################################
## Date : 21-June-2025
## Creators : Ujjawal Kumar
## Desc : For MCC VC Obsolesence Dashboard on AWC
########################################################################################################
echo "Start time:";date
StartTime=`date`

TodayDate=`date --date="today" +%d_%m_%Y`
echo "TodayDate Date is : " $TodayDate

echo "Input Argument as Date    : $1"

cd /user/cvprod/Ujjawal/MCC_SUBMODULES_OBSOLESCENCE_DASHBOARD
echo "Started executing Program for "

rm -rf "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".txt"
rm -rf "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
rm -rf "MCC_TOTAL_SM_OBS_Dashboard_PRODUCT_LINE_Sum_"$1".txt"

./STEP_1_prepareFilesForSubModObsSINGLEPlatform.sh HCV $1
./STEP_1_prepareFilesForSubModObsSINGLEPlatform.sh ILMCV $1
./STEP_1_prepareFilesForSubModObsSINGLEPlatform.sh SCV $1
./STEP_1_prepareFilesForSubModObsSINGLEPlatform.sh BUS $1

cat "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".txt"

sleep 1
echo "Starting Total Calculations....."; sleep 5

Approved_Dashboard_Line_Count=0

Approved_Total_Raised_DML_Count_Sum=0
Approved_Total_Released_DML_Count_Sum=0
Approved_Total_DML_Pending_Count_Sum=0
Approved_Total_DMLRow_SM_Obsoleted_Sum=0
Approved_Total_DMLRow_SM_Obsoleted_Pending_Sum=0
Approved_Total_DMLRow_ERC_DML_Pending_Sum=0
Approved_Total_DMLRow_MBOM_DML_Pending_Sum=0
Approved_Total_DMLRow_APL_DML_Pending_Sum=0
Approved_Total_DMLRow_STDS_DML_Pending_Sum=0
Approved_Total_DMLRow_SAP_Archived_Sum=0
Approved_Total_DMLRow_SAP_Not_Archived_Sum=0

Approved_Total_Raised_SM_Count_Sum=0
Approved_Total_Released_SM_Count_Sum=0
Approved_Total_DML_Pending_SM_Count_Sum=0
Approved_Total_SMRow_SM_Obsoleted_Sum=0
Approved_Total_SMRow_SM_Obsoleted_Pending_Sum=0
Approved_Total_SMRow_ERC_DML_Pending_Sum=0
Approved_Total_SMRow_MBOM_DML_Pending_Sum=0
Approved_Total_SMRow_APL_DML_Pending_Sum=0
Approved_Total_SMRow_STDS_DML_Pending_Sum=0
Approved_Total_SMRow_SAP_Archived_Sum=0
Approved_Total_SMRow_SAP_Not_Archived_Sum=0

while read Approved_Dashboard_Line
do

	# 1 Product_Line
	# 2 Row_Name
	# 3 Total Raised	
	# 4 Total Released (Any CV APL)	
	# 5 Total Pending	
	# 6 Total Obsoleted	
	# 7 Total Obsolescence Pending	
	# 8 DML ERC Pending	
	# 9 DML MBOM Pending	
	# 10 Total APL Pending	
	# 11 Total STDS Pending	
	# 12 Total Archived	
	# 13 Total Archive Pending
	
	Approved_Dashboard_Line_Count=$(( $Approved_Dashboard_Line_Count + 1 ))
	
	
# HCV,DML_Count,25,5,20,--,--,5,0,0,0,--,--
# HCV,SM_Count,138,--,--,71,67,--,--,--,TBD,TBD
# ILMCV,DML_Count,9,0,9,--,--,5,0,0,0,--,--
# ILMCV,SM_Count,20,--,--,0,20,--,--,--,TBD,TBD
# SCV,DML_Count,21,3,18,--,--,2,2,0,0,--,--
# SCV,SM_Count,86,--,--,42,44,--,--,--,TBD,TBD
# BUS,DML_Count,10,3,7,--,--,0,0,0,0,--,--
# BUS,SM_Count,53,--,--,21,32,--,--,--,TBD,TBD

	
	
	Platform_Approved_Dashboard_Line=`echo $Approved_Dashboard_Line |cut -d ","  -f1`
	Row_Type_Approved_Dashboard_Line=`echo $Approved_Dashboard_Line |cut -d ","  -f2`	
	Total_Raised_Approved_Dashboard_Line=`echo $Approved_Dashboard_Line |cut -d ","  -f3`
	Total_Released_Approved_Dashboard_Line=`echo $Approved_Dashboard_Line |cut -d ","  -f4`
	Total_DML_Pending=`echo $Approved_Dashboard_Line |cut -d ","  -f5`
	Total_SM_Obsoleted=`echo $Approved_Dashboard_Line |cut -d ","  -f6`
	Total_SM_Obsoleted_Pending=`echo $Approved_Dashboard_Line |cut -d ","  -f7`
	Total_ERC_DML_Pending=`echo $Approved_Dashboard_Line |cut -d ","  -f8`
	Total_MBOM_DML_Pending=`echo $Approved_Dashboard_Line |cut -d ","  -f9`
	Total_APL_DML_Pending=`echo $Approved_Dashboard_Line |cut -d ","  -f10`
	Total_STDS_DML_Pending=`echo $Approved_Dashboard_Line |cut -d ","  -f11`	
	Total_SM_SAP_Archived=`echo $Approved_Dashboard_Line |cut -d ","  -f12`
	Total_SM_SAP_Not_Archived=`echo $Approved_Dashboard_Line |cut -d ","  -f13`
	
	#integer=$(printf "%d" "$string")
	
	#Int_Total_Raised_Approved_Dashboard_Line = $(printf "%d" "$Total_Raised_Approved_Dashboard_Line")
	
	#result=$((num1 + num2))
	
	echo "$Approved_Dashboard_Line"	
	
	##Total Raised Sum
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_Raised_Approved_Dashboard_Line" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_Raised_DML_Count_Sum += $Total_Raised_Approved_Dashboard_Line))
		else
			DoNothing=0
		fi	
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_Raised_Approved_Dashboard_Line" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_Raised_SM_Count_Sum += $Total_Raised_Approved_Dashboard_Line))
			else
				DoNothing=0
			fi				
		fi		
	fi
	
	#Summation of Total Released for All PL.
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_Released_Approved_Dashboard_Line" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_Released_DML_Count_Sum += $Total_Released_Approved_Dashboard_Line))
		else
			DoNothing=0
		fi		
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_Released_Approved_Dashboard_Line" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_Released_SM_Count_Sum += $Total_Released_Approved_Dashboard_Line))
			else
				DoNothing=0
			fi
			
		fi		
	fi


	#Summation Total Pending DMLs
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_DML_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_DML_Pending_Count_Sum += $Total_DML_Pending))
		else
			DoNothing=0
		fi	
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_DML_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_DML_Pending_SM_Count_Sum += $Total_DML_Pending))
			else
				DoNothing=0
			fi				
		fi		
	fi
	
	
	#Summation Total_SM_Obsoleted
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_SM_Obsoleted" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_DMLRow_SM_Obsoleted_Sum += $Total_SM_Obsoleted))
		else
			DoNothing=0
		fi	
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_SM_Obsoleted" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_SMRow_SM_Obsoleted_Sum += $Total_SM_Obsoleted))
			else
				DoNothing=0
			fi				
		fi		
	fi


	#Summation Total_SM_Obsoleted_Pending
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_SM_Obsoleted_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_DMLRow_SM_Obsoleted_Pending_Sum += $Total_SM_Obsoleted_Pending))
		else
			DoNothing=0
		fi	
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_SM_Obsoleted_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_SMRow_SM_Obsoleted_Pending_Sum += $Total_SM_Obsoleted_Pending))
			else
				DoNothing=0
			fi				
		fi		
	fi
	
		
	#Summation Total_ERC_DML_Pending
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_ERC_DML_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_DMLRow_ERC_DML_Pending_Sum += $Total_ERC_DML_Pending))
		else
			DoNothing=0
		fi	
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_ERC_DML_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_SMRow_ERC_DML_Pending_Sum += $Total_ERC_DML_Pending))
			else
				DoNothing=0
			fi				
		fi		
	fi
	
	#Summation Total_MBOM_DML_Pending
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_MBOM_DML_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_DMLRow_MBOM_DML_Pending_Sum += $Total_MBOM_DML_Pending))
		else
			DoNothing=0
		fi	
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_MBOM_DML_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_SMRow_MBOM_DML_Pending_Sum += $Total_MBOM_DML_Pending))
			else
				DoNothing=0
			fi				
		fi		
	fi
	
	#Summation Total_APL_DML_Pending
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_APL_DML_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_DMLRow_APL_DML_Pending_Sum += $Total_APL_DML_Pending))
		else
			DoNothing=0
		fi	
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_APL_DML_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_SMRow_APL_DML_Pending_Sum += $Total_APL_DML_Pending))
			else
				DoNothing=0
			fi				
		fi		
	fi
	
	#Summation Total_STDS_DML_Pending
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_STDS_DML_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_DMLRow_STDS_DML_Pending_Sum += $Total_STDS_DML_Pending))
		else
			DoNothing=0
		fi	
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_STDS_DML_Pending" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_SMRow_STDS_DML_Pending_Sum += $Total_STDS_DML_Pending))
			else
				DoNothing=0
			fi				
		fi		
	fi
	
	#Summation Total_SM_SAP_Archived
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_SM_SAP_Archived" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_DMLRow_SAP_Archived_Sum += $Total_SM_SAP_Archived))
		else
			DoNothing=0
		fi	
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_SM_SAP_Archived" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_SMRow_SAP_Archived_Sum += $Total_SM_SAP_Archived))
			else
				DoNothing=0
			fi				
		fi		
	fi
	
	#Summation Total_SM_SAP_Not_Archived
	if [ "$Row_Type_Approved_Dashboard_Line" = "DML_Count" ]; then	
		
		if [[ "$Total_SM_SAP_Not_Archived" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_DMLRow_SAP_Not_Archived_Sum += $Total_SM_SAP_Not_Archived))
		else
			DoNothing=0
		fi	
	else 
		if [ "$Row_Type_Approved_Dashboard_Line" = "SM_Count" ]; then	
		
			if [[ "$Total_SM_SAP_Not_Archived" =~ ^-?[0-9]+$ ]]; then
			((Approved_Total_SMRow_SAP_Not_Archived_Sum += $Total_SM_SAP_Not_Archived))
			else
				DoNothing=0
			fi				
		fi		
	fi

done < "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".txt"

echo "Approved_Total_Raised_DML_Count_Sum $Approved_Total_Raised_DML_Count_Sum"
echo "Approved_Total_Released_DML_Count_Sum $Approved_Total_Released_DML_Count_Sum"
echo "Approved_Total_DML_Pending_Count_Sum $Approved_Total_DML_Pending_Count_Sum"
echo "Approved_Total_DMLRow_SM_Obsoleted_Sum $Approved_Total_DMLRow_SM_Obsoleted_Sum"
echo "Approved_Total_DMLRow_SM_Obsoleted_Pending_Sum $Approved_Total_DMLRow_SM_Obsoleted_Pending_Sum"
echo "Approved_Total_DMLRow_ERC_DML_Pending_Sum $Approved_Total_DMLRow_ERC_DML_Pending_Sum"
echo "Approved_Total_DMLRow_MBOM_DML_Pending_Sum $Approved_Total_DMLRow_MBOM_DML_Pending_Sum"
echo "Approved_Total_DMLRow_APL_DML_Pending_Sum $Approved_Total_DMLRow_APL_DML_Pending_Sum"
echo "Approved_Total_DMLRow_STDS_DML_Pending_Sum $Approved_Total_DMLRow_STDS_DML_Pending_Sum"
echo "Approved_Total_DMLRow_SAP_Archived_Sum $Approved_Total_DMLRow_SAP_Archived_Sum"
echo "Approved_Total_DMLRow_SAP_Not_Archived_Sum $Approved_Total_DMLRow_SAP_Not_Archived_Sum"
echo " "
echo "Approved_Total_Raised_SM_Count_Sum $Approved_Total_Raised_SM_Count_Sum"
echo "Approved_Total_Released_SM_Count_Sum $Approved_Total_Released_SM_Count_Sum"
echo "Approved_Total_DML_Pending_SM_Count_Sum $Approved_Total_DML_Pending_SM_Count_Sum"
echo "Approved_Total_SMRow_SM_Obsoleted_Sum $Approved_Total_SMRow_SM_Obsoleted_Sum"
echo "Approved_Total_SMRow_SM_Obsoleted_Pending_Sum $Approved_Total_SMRow_SM_Obsoleted_Pending_Sum"
echo "Approved_Total_SMRow_ERC_DML_Pending_Sum $Approved_Total_SMRow_ERC_DML_Pending_Sum"
echo "Approved_Total_SMRow_MBOM_DML_Pending_Sum $Approved_Total_SMRow_MBOM_DML_Pending_Sum"
echo "Approved_Total_SMRow_APL_DML_Pending_Sum $Approved_Total_SMRow_APL_DML_Pending_Sum"
echo "Approved_Total_SMRow_STDS_DML_Pending_Sum $Approved_Total_SMRow_STDS_DML_Pending_Sum"
echo "Approved_Total_SMRow_SAP_Archived_Sum $Approved_Total_SMRow_SAP_Archived_Sum"
echo "Approved_Total_SMRow_SAP_Not_Archived_Sum $Approved_Total_SMRow_SAP_Not_Archived_Sum"

echo "TOTAL,TOTAL_DML_Count,$Approved_Total_Raised_DML_Count_Sum,$Approved_Total_Released_DML_Count_Sum,$Approved_Total_DML_Pending_Count_Sum,$Approved_Total_DMLRow_SM_Obsoleted_Sum,$Approved_Total_DMLRow_SM_Obsoleted_Pending_Sum,$Approved_Total_DMLRow_ERC_DML_Pending_Sum,$Approved_Total_DMLRow_MBOM_DML_Pending_Sum,$Approved_Total_DMLRow_APL_DML_Pending_Sum,$Approved_Total_DMLRow_STDS_DML_Pending_Sum,$Approved_Total_DMLRow_SAP_Archived_Sum,$Approved_Total_DMLRow_SAP_Not_Archived_Sum" >> "MCC_TOTAL_SM_OBS_Dashboard_PRODUCT_LINE_Sum_"$1".txt"
echo "TOTAL,TOTAL_SM_Count,$Approved_Total_Raised_SM_Count_Sum,$Approved_Total_Released_SM_Count_Sum,$Approved_Total_DML_Pending_SM_Count_Sum,$Approved_Total_SMRow_SM_Obsoleted_Sum,$Approved_Total_SMRow_SM_Obsoleted_Pending_Sum,$Approved_Total_SMRow_ERC_DML_Pending_Sum,$Approved_Total_SMRow_MBOM_DML_Pending_Sum,$Approved_Total_SMRow_APL_DML_Pending_Sum,$Approved_Total_SMRow_STDS_DML_Pending_Sum,$Approved_Total_SMRow_SAP_Archived_Sum,$Approved_Total_SMRow_SAP_Not_Archived_Sum" >> "MCC_TOTAL_SM_OBS_Dashboard_PRODUCT_LINE_Sum_"$1".txt"

echo "-------------------------------APPROVED Total Numbers --------------------------------------"
cat "MCC_TOTAL_SM_OBS_Dashboard_PRODUCT_LINE_Sum_"$1".txt"
echo "--------------------------------------------------------------------------------------------"

echo "<PL_TOTAL>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<ProductLine>PROD_LINE_TOTAL</ProductLine>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalDMLRaised>$Approved_Total_Raised_DML_Count_Sum</DMLCount_TotalDMLRaised>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalDMLReleased>$Approved_Total_Released_DML_Count_Sum</DMLCount_TotalDMLReleased>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalDMLPending>$Approved_Total_DML_Pending_Count_Sum</DMLCount_TotalDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalSMObsoleted>$Approved_Total_DMLRow_SM_Obsoleted_Sum</DMLCount_TotalSMObsoleted>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalSMObsPending>$Approved_Total_DMLRow_SM_Obsoleted_Pending_Sum</DMLCount_TotalSMObsPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalERCDMLPending>$Approved_Total_DMLRow_ERC_DML_Pending_Sum</DMLCount_TotalERCDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalMBOMDMLPending>$Approved_Total_DMLRow_MBOM_DML_Pending_Sum</DMLCount_TotalMBOMDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalAPLDMLPending>$Approved_Total_DMLRow_APL_DML_Pending_Sum</DMLCount_TotalAPLDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalSTDSDMLPending>$Approved_Total_DMLRow_STDS_DML_Pending_Sum</DMLCount_TotalSTDSDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalSAPArchived>$Approved_Total_DMLRow_SAP_Archived_Sum</DMLCount_TotalSAPArchived>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<DMLCount_TotalSAPArchivedPending>$Approved_Total_DMLRow_SAP_Not_Archived_Sum</DMLCount_TotalSAPArchivedPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"

echo "<SMCount_TotalSMRaised>$Approved_Total_Raised_SM_Count_Sum</SMCount_TotalSMRaised>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<SMCount_TotalDMLReleased>$Approved_Total_Released_SM_Count_Sum</SMCount_TotalDMLReleased>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<SMCount_TotalDMLPending>$Approved_Total_DML_Pending_SM_Count_Sum</SMCount_TotalDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<SMCount_TotalSMObsoleted>$Approved_Total_SMRow_SM_Obsoleted_Sum</SMCount_TotalSMObsoleted>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<SMCount_TotalSMObsPending>$Approved_Total_SMRow_SM_Obsoleted_Pending_Sum</SMCount_TotalSMObsPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<SMCount_TotalERCDMLPending>$Approved_Total_SMRow_ERC_DML_Pending_Sum</SMCount_TotalERCDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<SMCount_TotalMBOMDMLPending>$Approved_Total_SMRow_MBOM_DML_Pending_Sum</SMCount_TotalMBOMDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<SMCount_TotalAPLDMLPending>$Approved_Total_SMRow_APL_DML_Pending_Sum</SMCount_TotalAPLDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<SMCount_TotalSTDSDMLPending>$Approved_Total_SMRow_STDS_DML_Pending_Sum</SMCount_TotalSTDSDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<SMCount_TotalSAPArchived>$Approved_Total_SMRow_SAP_Archived_Sum</SMCount_TotalSAPArchived>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "<SMCount_TotalSAPArchivedPending>$Approved_Total_SMRow_SAP_Not_Archived_Sum</SMCount_TotalSAPArchivedPending>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"
echo "</PL_TOTAL>" >> "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"

cat "MCC_SM_Obsolescence_Dashboard_PRODUCT_LINE_Data_"$1".xml"


echo "Finished... :)"