/******************************************************************************
* Developed By : Ujjawal Kumar
* Date : 21-06-2024
* Purpose : Program to generate VC Obsolesnce report for MCC VC Obs Dashboard.
*****************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>            
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h>        
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/aom_prop.h>
#include <ics/ics2.h>
#include <ics/ics.h>


#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	 EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static void handle_itk_error
    ( int stat,                               /* <I> */
      int source_code_line,                   /* <I> */
      const char *source_code_file_name       /* <I> */
    );

#define ITK(x)                                                             \
{                                                                          \
    if ( stat == ITK_ok )                                                  \
    {                                                                      \
        if ( (stat = (x)) != ITK_ok )                                      \
        {                                                                  \
            handle_itk_error( stat, __LINE__, __FILE__ );                  \
        }                                                                  \
    }                                                                      \
}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );



    fprintf( stderr, "Reivse Error(s): \n");
	Write_To_Log("Revise Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
    return ITK_ok;
}



char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}


char *t5TrimString(char *str){
    char *src=str;  /* save the original pointer */
    char *dst=str;  /* result */
    char c;
    int is_space=0;
    int in_word=0;  /* word boundary logical check */
    int index=0;    /* index of the last non-space char*/

    /* validate input */
    if (!str)
        return str;

    while ((c=*src)){
        is_space=0;

        if (c=='\t' || c=='\v' || c=='\f' || c=='\n' || c=='\r' || c==' ')
            is_space=1;

        if(is_space == 0){
         /* Found a word */
            in_word = 1;
            *dst++ = *src++;  /* make the assignment first
                               * then increment
                               */
        } else if (is_space==1 && in_word==0) {
         /* Already going through a series of white-spaces */
            in_word=0;
            ++src;
        } else if (is_space==1 && in_word==1) {
         /* End of a word, dont mind copy white spaces here */
            in_word=0;
            *dst++ = *src++;
            index = (dst-str)-1; /* location of the last char */
        }
    }

    /* terminate the string */
    *(str+index)='\0';

    return str;
}

void remove_multi_new_line(char* string)
{
  size_t length = strlen(string);
  while((length>0) && (string[length-1] == '\n'))
  {
      --length;
      string[length] ='\0';
  }
}

void t5GetCurrentDateTime(char cCurrentAccessDate[20])
{

	int ch;
	time_t temp;
	struct tm *timeptr;
	char pAccessDate[20];
	char	DateS[4];
	printf("\n t5GetCurrentDateTime calling..........\n");
	temp = time(NULL);
	tc_strcpy(pAccessDate,"");
	timeptr = (struct tm *)localtime(&temp);
	ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
	//ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d/%m/%Y",timeptr);
	tc_strcpy(cCurrentAccessDate,pAccessDate);

	fflush(stdout);
}

int ITK_user_main(int argc, char* argv[])
{
	
	int ifail = ITK_ok;
	int Tskcnt=0;
	int tsk=0;
	int k=0;
	int partcnt=0;
	int SrlNoCount=0;
	tag_t		*Dml_tasks	= NULLTAG;
	tag_t		*PartsTg	= NULLTAG;
	tag_t 		AssyTg 		= NULLTAG;
	char *tsknm =NULL;
	char *Tsk_object_type =NULL;
	
	char *Part_no =NULL;
	char *Part_nobr =NULL;
	char *Prtobj_type =NULL;
	char *FldrName =NULL;
	char *sSystPrtName =NULL;
	char *Part_DR =NULL;
	char *Part_type =NULL;
	char *Part_Descr =NULL;
	char *Part_modiDescr =NULL;
	char *Part_Rev =NULL;
	char *Part_RelStatus =NULL;
	char *Part_Proj =NULL;
	char *ncRel_status =NULL;
	char *Part_Desg =NULL;
	char *DMLwbs =NULL;
	char *DMLRel_status =NULL;
	char *DMLCreDate =NULL;
	char *DMLClsuDate =NULL;
	char *DMFrmTODR =NULL;
	char *DMLwbsDesc =NULL;
	
	
	printf("\n *********** Start Of  Main function ************* \n");fflush(stdout);
	
	if(ITK_auto_login() == ITK_ok)	
	{
		tag_t user_tag = NULLTAG;
		char* username = NULL;	
		
		char cCurrentAccessDate[20]={0};
		char cCurrentAccessDateTo[20]={0};
		char* cCurrentAccessDateTo1 = NULL;
		//char* busUnit = NULL;		
		
		char * DatefromStr = ITK_ask_cli_argument( "-FromDate=");		
		char * DateToStr = ITK_ask_cli_argument( "-ToDate=");
		char * email_id_strDup = ITK_ask_cli_argument( "-Email=");
		//char* xmlFileLoc1 = ITK_ask_cli_argument( "-xmlFile=");
		//busUnit = ITK_ask_cli_argument( "-bu=");
		
		ifail = ITK_set_journalling( TRUE );
		printf("\n\nLogin successfull.\n");fflush(stdout);		
		printf("\n argc==>%d\n",argc);		
		POM_get_user(&username,&user_tag);
		printf("\nFDJtm_FdjStatusReport: Session User Name[%s]\n",username);fflush(stdout);
		
		t5GetCurrentDateTime(cCurrentAccessDate);

		printf("\n Eff:Current date  is..:[%s]\n",cCurrentAccessDate);fflush(stdout);
		
		cCurrentAccessDateTo1 = subString(cCurrentAccessDate,0,11);
		
		tc_strcpy(cCurrentAccessDateTo, cCurrentAccessDateTo1);
		tc_strcat(cCurrentAccessDateTo," 59:59");
		
		printf("\n Eff:Current date TO  is..:[%s]\n",cCurrentAccessDateTo);fflush(stdout);
				
		int buff_cnt=0;
		char** bufferedXmlStrOut = NULL;;
		
		char* DatefromStrDup = NULL;
		char* DateToStrDup = NULL;
		
		if(DatefromStr!=NULL)
			tc_strdup(DatefromStr,&DatefromStrDup);
		if(DateToStr!=NULL)
			tc_strdup(DateToStr,&DateToStrDup);
			
		printf("\n From Date  is..:[%s]\n",DatefromStrDup);fflush(stdout);
		printf("\n TO date is..:[%s]\n",DateToStrDup);fflush(stdout);
			
		FILE *fsuccessRpt;
		FILE *fPtrSMObsoletedXML;
		FILE *fileSMNotObsoletedXML;
		
		time_t 	now;
		struct 	tm when;
		time(&now);
		when = *localtime(&now);
		char Data[100] = "";
		char fsuccess_name[200];
		char outputRptFile[200] = "";
		char outputXMLObsoletedSM[200] = "";
		char outputXMLNotObsoletedSM[200] = "";
		//strftime(Data,100,"%d_%m_%Y_%H_%M_%S",&when);
		
		strftime(Data,100,"%d_%m_%Y",&when);
		

		sprintf(outputRptFile,"/user/cvprod/Ujjawal/MCC_SUBMODULES_OBSOLESCENCE_DASHBOARD/SubModObsolecenceReport_%s.csv",Data);
		sprintf(outputXMLObsoletedSM,"/user/cvprod/Ujjawal/MCC_SUBMODULES_OBSOLESCENCE_DASHBOARD/SubModObs_Obsoleted_%s.xml",Data);
		sprintf(outputXMLNotObsoletedSM,"/user/cvprod/Ujjawal/MCC_SUBMODULES_OBSOLESCENCE_DASHBOARD/SubModObs_Not_Obsoleted_%s.xml",Data);
		
		fsuccessRpt=fopen(outputRptFile,"w");
		fPtrSMObsoletedXML=fopen(outputXMLObsoletedSM,"w");
		fileSMNotObsoletedXML=fopen(outputXMLNotObsoletedSM,"w");
		
		if(fsuccessRpt == NULL)
		printf("\nUnable To open Or Create Log  file");fflush(stdout);		
		if(fPtrSMObsoletedXML == NULL)
		printf("\nUnable To open Or Create Log  file");fflush(stdout);
		if(fileSMNotObsoletedXML == NULL)
		printf("\nUnable To open Or Create Log  file");fflush(stdout);
		
		strftime(Data,100,"%d-%m-%Y %H:%M:%S",&when);
		
		int n_entries = 2;
		int n_itemobj_found = 0;
		tag_t* DMLRevNewobj_results = NULLTAG;
	
		tag_t VCObsQRYobj = NULLTAG;
		//ERC DML Revision New
		
		if(QRY_find2("ERC DML Revision New",&VCObsQRYobj));
		
		printf("\n From Date  is..:[%s]\n",DatefromStrDup);fflush(stdout);
		printf("\n TO date is..:[%s]\n",DateToStrDup);fflush(stdout);
		
		//char *cEntries[3]  = {"SYSCD","creation_date1","creation_date2",};
		
		char *cEntries[2]  = {"Release Type","Type"};
		//char *cEntries[1]  = {"t5_rlstype"};
		//t5_rlstype		
		char *cValues[2]  = {"WT","ERC DML Revision"};
		//char *cValues[1]  = {"WT"};
				
		fprintf(fsuccessRpt,"SR_NO,ERC_DML_NO,DML_PRODUCT,PART_SRL,PART_NO,REV_SEQ,PART_TYPE,PART_PRODUCT,PART_AGGREGATE_GROUP,PART_AGGREGATE,PART_MODULE_GROUP,PART_MODULE,PART_MODULE_ADDR,PART_DR_STAT,PART_RELEASE_STATUS,ERC_DML_NO,DML_RELEASE_STATUS\n");fflush(fsuccessRpt);

		int DMLPendingAgency =0;
		int WTDMLFlag =0;
		int MBOMDMLFlag =0;
		int APLDMLStatus=0;
		//if(QRY_execute(DMLRevNewobj, n_entries, cEntries, cValues, &n_itemobj_found, &DMLRevNewobj_results));
		if(QRY_execute(VCObsQRYobj, n_entries, cEntries, cValues, &n_itemobj_found, &DMLRevNewobj_results));
		printf("\n : UJJ: Query excuted. \n");fflush(stdout);	
		tag_t DMLRevNewobj = NULLTAG;
		int j=0;
		if(n_itemobj_found>0)
		{
			printf("\n : UJJ: n_itemobj_found is > 0. \n");fflush(stdout);	
			
			for(j=0;j<n_itemobj_found;j++)
			{
				//if (j == 30)
				//{
				//	 break;
				//}
				
				DMLPendingAgency =0;
				WTDMLFlag =0;
				MBOMDMLFlag =0;
				APLDMLStatus=0;
				DMLRevNewobj = DMLRevNewobj_results[j];
				
				char* DMLRevNumber = NULL;
				char* DMLRevRelType = NULL;
				char* info7 = NULL;
				char* Partnum = NULL;
				tag_t PartTag= NULLTAG;	
				char* DMLRlzStatus = NULL;
				char* DMLRevProductLine = NULL;
				char* ERCRlzDate = NULL;
				char* MBOM_DMLRlzStatus = NULL;
				char* MBOM_RlzDate = NULL;
				char* APL_DMLRlzStatus = NULL;
				char* APL_RlzDate = NULL;
				
				char* Part_t5_ModuleName = NULL;
				char* Part_t5_AggregateGroup = NULL;
				char* Part_t5_Aggregate = NULL;
				char* Part_t5_ModuleAddress = NULL;
				char* Part_t5_Module_Group = NULL;
				char* Part_t5_Module = NULL;
				char* Part_t5_PartStatus = NULL;
				char* Part_t5_Product = NULL;

				char* Part_t5_PartType = NULL;
				char* Part_t5_Platform = NULL;
				
				char *DMLString= (char *) malloc(300*sizeof(char));
				//tc_strcpy(DMLString,"DML_INFO: ");

				
				//item_id
				
				CALLAPI(AOM_ask_value_string(DMLRevNewobj,"item_id",&DMLRevNumber));
				CALLAPI(AOM_ask_value_string(DMLRevNewobj,"t5_rlstype",&DMLRevRelType));
				CALLAPI(AOM_ask_value_string(DMLRevNewobj,"t5_ProductLine",&DMLRevProductLine));
				
				CALLAPI(AOM_UIF_ask_value(DMLRevNewobj, "release_status_list",&DMLRlzStatus));
				
				if(tc_strlen(DMLRlzStatus)>0)
				{
					
					if (tc_strstr(DMLRlzStatus,"ERC Released")!=NULL)
					{
						AOM_UIF_ask_value(DMLRevNewobj, "date_released",&ERCRlzDate);
						printf("\n ERCRlzDate [%s].....",ERCRlzDate);
						//DMLPendingAgency=1;
					}
					else
					{
						ERCRlzDate="";
					}
					if(tc_strlen(DMLRlzStatus)>0)
					{
						STRNG_replace_str(DMLRlzStatus,","," ",&DMLRlzStatus);
					}
					
				}

				tc_strcpy(DMLString,"DML_INFO: ");
				tc_strcat(DMLString,DMLRevNumber);
				tc_strcat(DMLString,"; ");
				tc_strcat(DMLString,DMLRlzStatus);
				tc_strcat(DMLString,"; ");
				tc_strcat(DMLString,ERCRlzDate);
				tc_strcat(DMLString," | ");

				
				//printf("\n : UJJ: %s %s %s %s \n", srNoBuf,DMLRevNumber,DMLRevRelType,DMLRlzStatus );fflush(stdout);	
				
				//fprintf(fsuccessRpt,"\n");fflush(fsuccessRpt);
				

				if(AOM_ask_value_tags(DMLRevNewobj,"T5_DMLTaskRelation",&Tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
				printf("\n Now Tskcnt:%d\n",Tskcnt);fflush(stdout);
				if (Tskcnt>0)
				{
					
					
					for (tsk=0;tsk<Tskcnt ;tsk++ )
					{
						
						if(AOM_ask_value_string(Dml_tasks[tsk],"item_id",&tsknm)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();						
						printf("\n Task:%s ObjType :%s\n",tsknm,Tsk_object_type);fflush(stdout);					
						
						if(strcmp(Tsk_object_type,"T5_MBOMDMLRevision")==0)
						{							
							CALLAPI(AOM_UIF_ask_value(Dml_tasks[tsk], "release_status_list",&MBOM_DMLRlzStatus));				
							if(tc_strlen(MBOM_DMLRlzStatus)>0)
							{								
								if (tc_strstr(MBOM_DMLRlzStatus,"MBOM Released")!=NULL)
								{
									AOM_UIF_ask_value(Dml_tasks[tsk], "date_released",&MBOM_RlzDate);
									printf("\n MBOM_RlzDate [%s].....",MBOM_RlzDate);
									//DMLPendingAgency=1;								

								}
								else
								{
									MBOM_RlzDate="";
								}
								if(tc_strlen(MBOM_DMLRlzStatus)>0)
								{
									STRNG_replace_str(MBOM_DMLRlzStatus,","," ",&MBOM_DMLRlzStatus);
								}
																
								tc_strcat(DMLString,tsknm);
								tc_strcat(DMLString,"; ");
								tc_strcat(DMLString,MBOM_DMLRlzStatus);
								tc_strcat(DMLString,"; ");
								tc_strcat(DMLString,MBOM_RlzDate);
								tc_strcat(DMLString," | ");
								
							}							
						}
						
						if(strcmp(Tsk_object_type,"T5_APLDMLRevision")==0)
						{							
							CALLAPI(AOM_UIF_ask_value(Dml_tasks[tsk], "release_status_list",&APL_DMLRlzStatus));				
							if(tc_strlen(APL_DMLRlzStatus)>0)
							{								
								if (tc_strstr(APL_DMLRlzStatus,"APL")!=NULL)
								{
									AOM_UIF_ask_value(Dml_tasks[tsk], "date_released",&APL_RlzDate);
									printf("\n APL_RlzDate [%s].....",APL_RlzDate);
									
								}
								else
								{
									APL_RlzDate="";
								}
								if(tc_strlen(APL_DMLRlzStatus)>0)
								{
									STRNG_replace_str(APL_DMLRlzStatus,","," ",&APL_DMLRlzStatus);
								}								
							}
							
							tc_strcat(DMLString,tsknm);
							tc_strcat(DMLString,"; ");
							tc_strcat(DMLString,APL_DMLRlzStatus);
							tc_strcat(DMLString,"; ");
							tc_strcat(DMLString,APL_RlzDate);
							tc_strcat(DMLString," | ");
							
						}
						
						
					}
					
					
					printf("\n DMLSTRING: %s",DMLString);
					
					
					
					//creation set of parts atached to task for updation.
					for (tsk=0;tsk<Tskcnt ;tsk++ )
					{
						if(AOM_ask_value_string(Dml_tasks[tsk],"item_id",&tsknm)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(Dml_tasks[tsk],"object_type",&Tsk_object_type)!=ITK_ok)PrintErrorStack();						
						printf("\n Task:%s ObjType :%s\n",tsknm,Tsk_object_type);fflush(stdout);						
		
						if(strcmp(Tsk_object_type,"T5_ChangeTaskRevision")==0)
						{
							
							if(AOM_ask_value_tags(Dml_tasks[tsk],"CMHasSolutionItem",&partcnt,&PartsTg)!=ITK_ok)   PrintErrorStack();
							//printf("\n PO: Now partcnt:%d",partcnt);fflush(stdout);
							if (partcnt>0)
							{
								for (k=0;k<partcnt ;k++ )
								{
									//Part no,Rev, DR-status,Part type,Part Project,Design Group,LC status,Part Desc,");
									AssyTg=PartsTg[k];
									if(AOM_ask_value_string(AssyTg,"item_id",&Part_no)!=ITK_ok)   PrintErrorStack();
									if(AOM_ask_value_string(AssyTg,"item_revision_id",&Part_Rev)!=ITK_ok)   PrintErrorStack();	

									if(AOM_ask_value_string(AssyTg,"t5_PartType",&Part_t5_PartType)!=ITK_ok)   PrintErrorStack();
									
									if((strcmp(Part_t5_PartType,"M")==0) || (strcmp(Part_t5_PartType,"CM")==0))
									{							
														
										SrlNoCount = SrlNoCount+1;
																
										if(AOM_ask_value_string(AssyTg,"t5_Platform",&Part_t5_Platform)!=ITK_ok)   PrintErrorStack();	
										
										// Module Name t5_ModuleName FRAME ASSY
										if(AOM_UIF_ask_value (AssyTg, "t5_ModuleName", &Part_t5_ModuleName)!=ITK_ok)PrintErrorStack();
											STRNG_replace_str(Part_t5_ModuleName,">","-",&Part_t5_ModuleName);
											STRNG_replace_str(Part_t5_ModuleName,"&","_AND_",&Part_t5_ModuleName);
											STRNG_replace_str(Part_t5_ModuleName,"/","-",&Part_t5_ModuleName);
											STRNG_replace_str(Part_t5_ModuleName,"<","-",&Part_t5_ModuleName);
											STRNG_replace_str(Part_t5_ModuleName,">","-",&Part_t5_ModuleName);										
										
										// Aggregate Group t5_AggregateGroup F-CHASSIS
										if(AOM_UIF_ask_value (AssyTg, "t5_AggregateGroup", &Part_t5_AggregateGroup)!=ITK_ok)PrintErrorStack();
											STRNG_replace_str(Part_t5_AggregateGroup," ","_",&Part_t5_AggregateGroup);
											STRNG_replace_str(Part_t5_AggregateGroup,"&","_AND_",&Part_t5_AggregateGroup);
											STRNG_replace_str(Part_t5_AggregateGroup,"/","-",&Part_t5_AggregateGroup);
											STRNG_replace_str(Part_t5_AggregateGroup,"<","-",&Part_t5_AggregateGroup);
											STRNG_replace_str(Part_t5_AggregateGroup,">","-",&Part_t5_AggregateGroup);										
										
										// Aggregate t5_Aggregate 1-CHASSIS INTEGRATION AGGREGATES
										if(AOM_UIF_ask_value (AssyTg, "t5_Aggregate", &Part_t5_Aggregate)!=ITK_ok)PrintErrorStack();
											STRNG_replace_str(Part_t5_Aggregate,"&","_AND_",&Part_t5_Aggregate);
											STRNG_replace_str(Part_t5_Aggregate,"/","-",&Part_t5_Aggregate);
											STRNG_replace_str(Part_t5_Aggregate,"<","-",&Part_t5_Aggregate);
											STRNG_replace_str(Part_t5_Aggregate,">","-",&Part_t5_Aggregate);	

										//Module Group t5_Module_Group A-CHASSIS FRAME											
										if(AOM_UIF_ask_value (AssyTg, "t5_Module_Group", &Part_t5_Module_Group)!=ITK_ok)PrintErrorStack();
											STRNG_replace_str(Part_t5_Module_Group,",",";",&Part_t5_Module_Group);
											STRNG_replace_str(Part_t5_Module_Group,"&","_AND_",&Part_t5_Module_Group);
											STRNG_replace_str(Part_t5_Module_Group,"/","-",&Part_t5_Module_Group);
											STRNG_replace_str(Part_t5_Module_Group,"<","-",&Part_t5_Module_Group);
											STRNG_replace_str(Part_t5_Module_Group,">","-",&Part_t5_Module_Group);
										
										// Module t5_Module 01-FRAME ASSY
										if(AOM_UIF_ask_value (AssyTg, "t5_Module", &Part_t5_Module)!=ITK_ok)PrintErrorStack();
											STRNG_replace_str(Part_t5_Module,",",";",&Part_t5_Module);
											STRNG_replace_str(Part_t5_Module,"&","_AND_",&Part_t5_Module);
											STRNG_replace_str(Part_t5_Module,"/","-",&Part_t5_Module);
											STRNG_replace_str(Part_t5_Module,"<","-",&Part_t5_Module);
											STRNG_replace_str(Part_t5_Module,">","-",&Part_t5_Module);

										// Module Address t5_ModuleAddress MF1A01
										if(AOM_UIF_ask_value (AssyTg, "t5_ModuleAddress", &Part_t5_ModuleAddress)!=ITK_ok)PrintErrorStack();
											STRNG_replace_str(Part_t5_ModuleAddress,"&","_AND_",&Part_t5_ModuleAddress);
											STRNG_replace_str(Part_t5_ModuleAddress,"/","-",&Part_t5_ModuleAddress);
											STRNG_replace_str(Part_t5_ModuleAddress,"<","-",&Part_t5_ModuleAddress);
											STRNG_replace_str(Part_t5_ModuleAddress,">","-",&Part_t5_ModuleAddress);
										
										
										// AR/DR Status t5_PartStatus DR0
										if(AOM_UIF_ask_value (AssyTg, "t5_PartStatus", &Part_t5_PartStatus)!=ITK_ok)PrintErrorStack();
											STRNG_replace_str(Part_t5_PartStatus,"&","_AND_",&Part_t5_PartStatus);
											STRNG_replace_str(Part_t5_PartStatus,"/","-",&Part_t5_PartStatus);
											STRNG_replace_str(Part_t5_PartStatus,"<","-",&Part_t5_PartStatus);
											STRNG_replace_str(Part_t5_PartStatus,">","-",&Part_t5_PartStatus);
											
										// Product t5_Product HCV
										if(AOM_UIF_ask_value (AssyTg, "t5_Product", &Part_t5_Product)!=ITK_ok)PrintErrorStack();
											STRNG_replace_str(Part_t5_Product,"&","_AND_",&Part_t5_Product);
											STRNG_replace_str(Part_t5_Product,"/","-",&Part_t5_Product);
											STRNG_replace_str(Part_t5_Product,"<","-",&Part_t5_Product);
											STRNG_replace_str(Part_t5_Product,">","-",&Part_t5_Product);	
										
										if(AOM_UIF_ask_value (AssyTg, "release_status_list", &Part_RelStatus)!=ITK_ok)PrintErrorStack();
											STRNG_replace_str(Part_RelStatus,",",";",&Part_RelStatus);
											STRNG_replace_str(Part_RelStatus,"&","_AND_",&Part_RelStatus);
											STRNG_replace_str(Part_RelStatus,"/","-",&Part_RelStatus);
											STRNG_replace_str(Part_RelStatus,"<","-",&Part_RelStatus);
											STRNG_replace_str(Part_RelStatus,">","-",&Part_RelStatus);							
										
										char* srNoBuf =  (char *)MEM_alloc(20 * sizeof(char));
										sprintf(srNoBuf,"%d",j+1);
																		
										printf("UJJOUTLINE: %s,%s,%s,[%d],%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s \n", 
										        srNoBuf,DMLRevNumber,DMLRevProductLine,k+1,Part_no,Part_Rev,Part_t5_PartType,Part_t5_Product,Part_t5_AggregateGroup,Part_t5_Aggregate,Part_t5_Module_Group,Part_t5_Module,Part_t5_ModuleAddress,Part_t5_PartStatus,Part_RelStatus,DMLRevNumber,DMLString);fflush(stdout);
													 
										//printf("\n ------> Part [%d] %s %s\n",k,Part_no,Part_Rev);fflush(stdout);
										
										//fprintf(fsuccessRpt,"%s,%s,%s,%s,%s,[%d],%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s \n", 
										//        srNoBuf,DMLRevNumber,DMLRevProductLine,DMLRlzStatus,ERCRlzDate,k+1,Part_no,Part_Rev,Part_t5_PartType,Part_t5_Platform,Part_t5_ModuleName,Part_t5_AggregateGroup,Part_t5_Aggregate,Part_t5_ModuleAddress,Part_t5_Module,Part_t5_PartStatus,Part_t5_Product,Part_RelStatus);fflush(fsuccessRpt);

										//fprintf(fsuccessRpt,"%d,%s,%s,%s,%s,[%d],%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s \n", 
										//        SrlNoCount,DMLRevNumber,DMLRevProductLine,DMLRlzStatus,ERCRlzDate,k+1,Part_no,Part_Rev,Part_t5_PartType,Part_t5_Platform,Part_t5_ModuleName,Part_t5_AggregateGroup,Part_t5_Aggregate,Part_t5_Module_Group,Part_t5_Module,Part_t5_ModuleAddress,Part_t5_PartStatus,Part_t5_Product,Part_RelStatus);fflush(fsuccessRpt);

										if (tc_strstr(Part_RelStatus,"Obsolete") != NULL)
										{
											//Approved Submodules for Obsolescence.
											
											fprintf(fPtrSMObsoletedXML,"<ObsoletedSubModRow>\n");fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<SR_NO>%d</SR_NO>\n",SrlNoCount);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<ERC_DML_NO>%s</ERC_DML_NO>\n",DMLRevNumber);fflush(fPtrSMObsoletedXML);	
											fprintf(fPtrSMObsoletedXML,"<PART_SRL>%d</PART_SRL>\n",k+1);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<PART_NO>%s</PART_NO>\n",Part_no);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<PART_REV_SEQ>%s</PART_REV_SEQ>\n",Part_Rev);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<PART_TYPE>%s</PART_TYPE>\n",Part_t5_PartType);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<PART_PRODUCT>%s</PART_PRODUCT>\n",Part_t5_Product);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<PART_AGGREGATE_GROUP>%s</PART_AGGREGATE_GROUP>\n",Part_t5_AggregateGroup);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<PART_AGGREGATE>%s</PART_AGGREGATE>\n",Part_t5_Aggregate);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<PART_MODULE_GROUP>%s</PART_MODULE_GROUP>\n",Part_t5_Module_Group);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<PART_MODULE>%s</PART_MODULE>\n",Part_t5_Module);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<PART_MODULE_ADDR>%s</PART_MODULE_ADDR>\n",Part_t5_ModuleAddress);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<PART_DR_STAT>%s</PART_DR_STAT>\n",Part_t5_PartStatus);fflush(fPtrSMObsoletedXML);							
											fprintf(fPtrSMObsoletedXML,"<PART_RELEASE_STATUS>%s</PART_RELEASE_STATUS>\n",Part_RelStatus);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<ERC_DML_NO>%s</ERC_DML_NO>\n",DMLRevNumber);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"<DML_RELEASE_STATUS_STRING>%s</DML_RELEASE_STATUS_STRING>\n",DMLString);fflush(fPtrSMObsoletedXML);
											fprintf(fPtrSMObsoletedXML,"</ObsoletedSubModRow>\n");fflush(fPtrSMObsoletedXML);

											//Added DMLString at end.
											fprintf(fsuccessRpt,"%d,%s,%s,[%d],%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s \n", 
										        SrlNoCount,DMLRevNumber,DMLRevProductLine,k+1,Part_no,Part_Rev,Part_t5_PartType,Part_t5_Product,Part_t5_AggregateGroup,Part_t5_Aggregate,Part_t5_Module_Group,Part_t5_Module,Part_t5_ModuleAddress,Part_t5_PartStatus,Part_RelStatus,DMLRevNumber,DMLString);fflush(fsuccessRpt);

										}
										else
										{
											//Pending Submodules for Obsolescence.											

											fprintf(fileSMNotObsoletedXML,"<NotObsoletedSubModRow>\n");fflush(fileSMNotObsoletedXML);
										    fprintf(fileSMNotObsoletedXML,"<SR_NO>%d</SR_NO>\n",SrlNoCount);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<ERC_DML_NO>%s</ERC_DML_NO>\n",DMLRevNumber);fflush(fileSMNotObsoletedXML);	
											fprintf(fileSMNotObsoletedXML,"<PART_SRL>%d</PART_SRL>\n",k+1);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_NO>%s</PART_NO>\n",Part_no);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_REV_SEQ>%s</PART_REV_SEQ>\n",Part_Rev);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_TYPE>%s</PART_TYPE>\n",Part_t5_PartType);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_PRODUCT>%s</PART_PRODUCT>\n",Part_t5_Product);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_AGGREGATE_GROUP>%s</PART_AGGREGATE_GROUP>\n",Part_t5_AggregateGroup);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_AGGREGATE>%s</PART_AGGREGATE>\n",Part_t5_Aggregate);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_MODULE_GROUP>%s</PART_MODULE_GROUP>\n",Part_t5_Module_Group);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_MODULE>%s</PART_MODULE>\n",Part_t5_Module);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_MODULE_ADDR>%s</PART_MODULE_ADDR>\n",Part_t5_ModuleAddress);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_DR_STAT>%s</PART_DR_STAT>\n",Part_t5_PartStatus);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<PART_RELEASE_STATUS>%s</PART_RELEASE_STATUS>\n",Part_RelStatus);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<ERC_DML_NO>%s</ERC_DML_NO>\n",DMLRevNumber);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"<DML_RELEASE_STATUS_STRING>%s</DML_RELEASE_STATUS_STRING>\n",DMLString);fflush(fileSMNotObsoletedXML);
											fprintf(fileSMNotObsoletedXML,"</NotObsoletedSubModRow>\n");fflush(fileSMNotObsoletedXML);

											//Added DMLString at end.
											fprintf(fsuccessRpt,"%d,%s,%s,[%d],%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s \n", 
										        SrlNoCount,DMLRevNumber,DMLRevProductLine,k+1,Part_no,Part_Rev,Part_t5_PartType,Part_t5_Product,Part_t5_AggregateGroup,Part_t5_Aggregate,Part_t5_Module_Group,Part_t5_Module,Part_t5_ModuleAddress,Part_t5_PartStatus,Part_RelStatus,DMLRevNumber,DMLString);fflush(fsuccessRpt);


											int 	n_TskCnt=0;
											tag_t 	part_tsk_rel_typ = NULLTAG;
											tag_t 	*TskObjSO = NULLTAG;
											char*	Tasknum = NULL;

											//Expand Design-Rev to get its Task Objects.
											ITKCALL(GRM_find_relation_type("CMHasSolutionItem",&part_tsk_rel_typ));
											ITKCALL( GRM_list_primary_objects_only(AssyTg,part_tsk_rel_typ,&n_TskCnt,&TskObjSO));
											//printf("\n n_TskCnt : %d",n_TskCnt);fflush(stdout);

											int j=0;
											int k=0;
											tag_t TaskTypeTag = NULLTAG;
											char *TaskTypeName= NULL;
											//tc_strcpy(finalDMLName,"");
											//tc_strcpy(finalTaskName,"");
											if (n_TskCnt > 0)
											{
												for (j=0;j<n_TskCnt;j++ )
												{
													if( AOM_ask_value_string(TskObjSO[j],"item_id",&Tasknum)==ITK_ok)
													//printf("\n UJJJJJ : DmlNumb and Task name [%s]",Tasknum); fflush(stdout);
													
													
													ITKCALL(TCTYPE_ask_object_type(TskObjSO[j],&TaskTypeTag));
													ITKCALL(TCTYPE_ask_name2(TaskTypeTag,&TaskTypeName));
													
													//printf("\n UJJJJJ : TaskTypeName [%s]",TaskTypeName); fflush(stdout);
												}
											}
										}
									}
									else
									{

										int PartIsAModule_Flag =0;
										//printf("\n ------> Skipping processing and printing as Part-type is Not-Module, its ..  %s\n",Part_t5_PartType);fflush(stdout);

									}
								}

																		

							}
							
						}
					}		
						
				}
	
			}	
		}
		else
		{
			printf("\n : UJJ: n_itemobj_found is 0. Pls check. \n");fflush(stdout);	
		}
		
	}	
	
	printf("\n : *********** End Of Main function MCCSubModule Obsolescence Dashboard  Ujjawal ************* \n");fflush(stdout);	
	return ifail;
}



