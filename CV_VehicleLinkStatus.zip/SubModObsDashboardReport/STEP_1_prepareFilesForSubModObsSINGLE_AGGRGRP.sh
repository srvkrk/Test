########################################################################################################
## Date : 21-June-2025
## Creators : Ujjawal Kumar
## Desc : For MCC SM Obsolesence Dashboard on AWC
########################################################################################################
echo "Start time:";date
StartTime=`date`

TodayDate=`date --date="today" +%d_%m_%Y`
echo "TodayDate Date is : " $TodayDate

echo "Input Argument 1 as Platform: $1"
echo "Input Argument 2 as Date    : $2"
echo "Processing for Platform $1 and Date $2 .... Pls wait..."

cd /user/cvprod/Ujjawal/MCC_SUBMODULES_OBSOLESCENCE_DASHBOARD

rm -rf $1"_"$2"_File.txt"		

ROWS_DML_Submod_Obs_Line=0

while read DML_Submod_Obs_Line
do

	#1 Sr.No	
	#2 Request ID	
	#3 Request System	
	#4 Vertical	
	#5 Requested SM/Module	
	#6 Request Pending with	
	#7 Obs Request Status	
	#8 ERC DML	
	#9 ERC DML Status	
	#10 ERC Release Date		
	#11 MBOM DML	
	#12 MBOM Status	
	#13 MBOM Release Date	
	#14 APL DML	
	#15 APL Status	
	#16 APL Release Date	
	#17 STD Status	
	#18 STD Release Date	
	#19 DML Pending with	
	#20 SM/Module Number	
	#21 Revision	
	#22 Sequence	
	#23 Item Revision Status	
	#24 SAP AR Marking Status
	
	#1 SR_NO,
	#2 ERC_DML_NO,
	#3 DML_PRODUCT,
	#4 PART_SRL,
	#5 PART_NO,
	#6 REV_SEQ,
	#7 PART_TYPE,
	#8 PART_PRODUCT,
	#9 PART_AGGREGATE_GROUP,
	#10 PART_AGGREGATE,
	#11 PART_MODULE_GROUP,
	#12 PART_MODULE,
	#13 PART_MODULE_ADDR,
	#14 PART_DR_STAT,
	#15 PART_RELEASE_STATUS,
	#16 ERC_DML_NO,
	#17 DML_RELEASE_STATUS
	
	ROWS_DML_Submod_Obs_Line=$(( $ROWS_DML_Submod_Obs_Line + 1 ))
		
	ROWS_Srl_No=`echo $DML_Submod_Obs_Line |cut -d ","  -f1`
	ROWS_ERCDML=`echo $DML_Submod_Obs_Line |cut -d ","  -f2`
	#ROWS_ReqID=`echo $DML_Submod_Obs_Line |cut -d ","  -f2`
	#ROWS_ReqSystem=`echo $DML_Submod_Obs_Line |cut -d ","  -f3`
	## Changing this for AGGREGATE_GROUP (9th argument), Keeping rest all same.
	ROWS_Aggr_Grp=`echo $DML_Submod_Obs_Line |cut -d ","  -f9`
	ROWS_SubmodNum=`echo $DML_Submod_Obs_Line |cut -d ","  -f5`
	#ROWS_ReqPendingWith=`echo $DML_Submod_Obs_Line |cut -d ","  -f6`	
	#ROWS_ObsReqStatus=`echo $DML_Submod_Obs_Line |cut -d ","  -f7`
	#ROWS_ERCDML=`echo $DML_Submod_Obs_Line |cut -d ","  -f2`
	#ROWS_ERCDMLStatus=`echo $DML_Submod_Obs_Line |cut -d ","  -f9`	
	#ROWS_DML_REL_STATUS=`echo $DML_Submod_Obs_Line |cut -d ","  -f10`
	ROWS_DML_REL_STATUS=`echo $DML_Submod_Obs_Line |cut -d ","  -f17`
	
	#echo "$ROWS_DML_Submod_Obs_Line $ROWS_Aggr_Grp $ROWS_SubmodNum" 

	if [ "$ROWS_Aggr_Grp" = "$1" ]; then
		#RowString=$RowString",Check R"$COLUMNS_SubModLineCount"_C"$ROWS_SubModLineCount
		echo "$DML_Submod_Obs_Line,$ROWS_DML_REL_STATUS" >> $1"_"$2"_File.txt"			
	else
		doNothing=0		
	fi	

done < "SubModObsolecenceReport_"$2".csv"

#rm -rf $1"_"$2"_ALL_ReqID_File.txt" 
rm -rf $1"_"$2"_ALL_Submod_File.txt"
#rm -rf $1"_"$2"_ALL_ReqID_File_UNIQUE.txt" 
rm -rf $1"_"$2"_ALL_Submod_File_UNIQUE.txt"
rm -rf $1"_"$2"_DML_File.txt" 
rm -rf $1"_"$2"_DML_File_UNIQUE.txt"

ROWS_PLATFORM_Line_Count=0

TotalMBOMReleasedCount=0
TotalAPLAnyPlantReleasedCount=0
TotalSTDSAnyPlantReleasedCount=0
Total_ObsoleteCount=0

Total_SM_MBOMPendingCount=0
Total_SM_APLAnyPlantPendingCount=0
Total_SM_STDSAnyPlantPendingCount=0
Total_SM_ObsoletePendingCount=0

Total_SM_TakenInDML_Count=0
Total_SM_RaisedByDML_Count=0
Total_DML_Count=0
Total_DML_NotFound_Count=0
Total_DML_MBOMReleasedCount=0
Total_DML_APLAnyPlantReleasedCount=0
Total_DML_STDSAnyPlantReleasedCount=0

Total_DML_ERCPendingCount=0
Total_DML_MBOMPendingCount=0
Total_DML_APLAnyPlantPendingCount=0
Total_DML_STDSAnyPlantPendingCount=0

while read ROW_PLATFORM_Line
do

	ROWS_PLATFORM_Line_Count=$(( $ROWS_PLATFORM_Line_Count + 1 ))
		
	#ROWS_Srl_No=`echo $ROW_PLATFORM_Line |cut -d ","  -f1`
	#ROWS_ReqID=`echo $ROW_PLATFORM_Line |cut -d ","  -f2`
	ROWS_DML_Number=`echo $ROW_PLATFORM_Line |cut -d ","  -f2`
	#ROWS_ReqSystem=`echo $ROW_PLATFORM_Line |cut -d ","  -f3`
	ROWS_Aggr_Grp=`echo $ROW_PLATFORM_Line |cut -d ","  -f9`
	ROWS_SubmodNum=`echo $ROW_PLATFORM_Line |cut -d ","  -f5`
	#ROWS_ERCDML=`echo $ROW_PLATFORM_Line |cut -d ","  -f2`	
	
	#ROWS_MBOMReleaseDate=`echo $ROW_PLATFORM_Line |cut -d ","  -f13`
	#ROWS_APLReleaseDate=`echo $ROW_PLATFORM_Line |cut -d ","  -f16`
	#ROWS_STDSReleaseDate=`echo $ROW_PLATFORM_Line |cut -d ","  -f18`
	ROWS_ItemRevisionStatus=`echo $ROW_PLATFORM_Line |cut -d ","  -f15`	
	ROWS_DMLRelStatus=`echo $ROW_PLATFORM_Line |cut -d ","  -f17`
	
	#echo "$ROWS_DML_Submod_Obs_Line $ROWS_Aggr_Grp $ROWS_SubmodNum" 

	#echo $ROWS_ReqID >> $1"_"$2"_ALL_ReqID_File.txt"
	echo "$ROWS_SubmodNum,$ROWS_ItemRevisionStatus" >> $1"_"$2"_ALL_Submod_File.txt"		

			
	if [[ "$ROWS_SubmodNum" ]]; 
	then			
		Total_SM_TakenInDML_Count=$(( $Total_SM_TakenInDML_Count + 1 ))		
	else
		doNothing=0		
	fi
			

	if [[ "$ROWS_ItemRevisionStatus" =~ "Obsolete" ]]
	then				
		Total_ObsoleteCount=$(( $Total_ObsoleteCount + 1 ))		
	else
		#doNothing=0
		Total_SM_ObsoletePendingCount=$(( $Total_SM_ObsoletePendingCount + 1 ))	
	fi	
	
	
	#ROWS_DML_MBOMStatus=`echo $ROW_PLATFORM_Line |cut -d ","  -f12`
	#ROWS_DML_APLStatus=`echo $ROW_PLATFORM_Line |cut -d ","  -f15`
	#ROWS_DML_STDStatus=`echo $ROW_PLATFORM_Line |cut -d ","  -f17`	
	
	## For DML Counting
	
	if [[ "$ROWS_DML_Number" != "" ]]
	then				
		#Total_DML_Count=$(( $Total_DML_Count + 1 ))	
		
		#echo "$ROWS_DML_Number,$ROWS_DML_MBOMStatus,$ROWS_DML_APLStatus,$ROWS_DML_STDStatus" >> $1"_"$2"_DML_File.txt"
		echo "$ROWS_DML_Number,$ROWS_DMLRelStatus" >> $1"_"$2"_DML_File.txt"
		
	else
		doNothing=0		
		Total_DML_NotFound_Count=$(( $Total_DML_NotFound_Count + 1 ))	
	fi
	
done < $1"_"$2"_File.txt"

#sort $1"_"$2"_ALL_ReqID_File.txt"  | uniq > $1"_"$2"_ALL_ReqID_File_UNIQUE.txt"
sort $1"_"$2"_ALL_Submod_File.txt"  | uniq > $1"_"$2"_ALL_Submod_File_UNIQUE.txt"
sort $1"_"$2"_DML_File.txt"  | uniq > $1"_"$2"_DML_File_UNIQUE.txt"

#PLTotalRaisedCount=`wc -l $1"_"$2"_ALL_ReqID_File_UNIQUE.txt"|cut -d " " -f1`
PLTotalSMCount=`wc -l $1"_"$2"_ALL_Submod_File_UNIQUE.txt"|cut -d " " -f1`
PLTotalDMLCount=`wc -l $1"_"$2"_DML_File_UNIQUE.txt"|cut -d " " -f1`

ROWS_DML_Line_Count=0
Total_DML_APLReleased_Count=0
Total_DML_PendingForAPLReleased_Count=0


while read ROW_DML_Line
do

	ROWS_DML_Line_Count=$(( $ROWS_DML_Line_Count + 1 ))
	
	ROWS_DML_Number=`echo $ROW_DML_Line |cut -d ","  -f1`
	ROWS_DMLRelStatus=`echo $ROW_DML_Line |cut -d ","  -f2`
	
	echo "$ROWS_DML_Number,$ROWS_DMLRelStatus" 
	
	#ROWS_MBOMReleaseDate=`echo $ROW_DML_Line |cut -d ","  -f13`
	#ROWS_APLReleaseDate=`echo $ROW_DML_Line |cut -d ","  -f16`
	#ROWS_STDSReleaseDate=`echo $ROW_DML_Line |cut -d ","  -f18`
	
	#ROWS_DML_MBOMStatus=`echo $ROW_DML_Line |cut -d ","  -f2`
	#ROWS_DML_APLStatus=`echo $ROW_DML_Line |cut -d ","  -f3`
	#ROWS_DML_STDStatus=`echo $ROW_DML_Line |cut -d ","  -f4`	
	
	if [[ "$ROWS_DMLRelStatus" =~ "APLP Released" || "$ROWS_DMLRelStatus" =~ "APLJ Released" || "$ROWS_DMLRelStatus" =~ "APLL Released" || "$ROWS_DMLRelStatus" =~ "APLD Released" || "$ROWS_DMLRelStatus" =~ "APLU Released" ]]
	then				
		Total_DML_APLReleased_Count=$(( $Total_DML_APLReleased_Count + 1 ))		
	else
		#doNothing=0
		Total_DML_PendingForAPLReleased_Count=$(( $Total_DML_PendingForAPLReleased_Count + 1 ))	
	fi	
	
	#DML_INFO: 23JU001176; In Designer Working;  |
	if [[ "$ROWS_DMLRelStatus" =~ "In Designer Working" ]]
	then				
		Total_DML_ERCPendingCount=$(( $Total_DML_ERCPendingCount + 1 ))		
	else
		doNothing=0		
	fi
	
	#DML_INFO: 23JU458004; ERC Released; 23-Nov-2022 00:00 | 23JU458004_MBOM; MBOM Working;  |  
	if [[ "$ROWS_DMLRelStatus" =~ "MBOM Working" ]]
	then				
		Total_DML_MBOMPendingCount=$(( $Total_DML_MBOMPendingCount + 1 ))		
	else
		doNothing=0		
	fi
	
	if [[ "$ROWS_DMLRelStatus" =~ "APL Working" ]]
	then				
		Total_DML_APLAnyPlantPendingCount=$(( $Total_DML_APLAnyPlantPendingCount + 1 ))		
	else
		doNothing=0		
	fi
	
	if [[ "$ROWS_DMLRelStatus" =~ "STDS Working" ]]
	then				
		Total_DML_STDSAnyPlantPendingCount=$(( $Total_DML_STDSAnyPlantPendingCount + 1 ))		
	else
		doNothing=0		
	fi

	
done < $1"_"$2"_DML_File_UNIQUE.txt"

echo "==================== APPROVAL Report for $1 $2 ============================================"
echo "SM OBS Dashboard data for Platform : $1 and Date: $2"
echo "-------------------------------------------------------------------------------------------"
echo "DML Count Details for $1 and $2"
echo " "
echo "DML Total Raised Count                    : $PLTotalDMLCount"
echo "DML Total APL* Released Count             : $Total_DML_APLReleased_Count"
echo "DML Total Not APL* Released Raised Count  : $Total_DML_PendingForAPLReleased_Count"
echo "Pending DML ERC In Designer Working Count : $Total_DML_ERCPendingCount"	
echo "Pendign DML MBOM Working Count            : $Total_DML_MBOMPendingCount"
echo "Pending DML APL Working Count             : $Total_DML_APLAnyPlantPendingCount"
echo "Pending DML STDS Working Count            : $Total_DML_STDSAnyPlantPendingCount"	
echo "-------------------------------------------------------------------------------------------"
echo "SM Count Details for $1 and $2"
echo " "
echo "SM Total Raised Count                     : $PLTotalSMCount"
echo "SM Obsolete Approved Count                : $Total_ObsoleteCount"
echo "SM Obsolete Pending Count                 : $Total_SM_ObsoletePendingCount"							 
echo "-------------------------------------------------------------------------------------------"

sleep 1

#Product Line	Type of Count	Total Raised	"Total Released (Any CV APL)"	"Total Pending"	"Total Obsoleted"	"Total Obsolescence Pending"	"DML ERC Pending"	"DML MBOM Pending"	"DML APL Pending"	"DML STDS Pending"	"Total Archived"	"Total Archive Pending"

#HCV	DML Count   :	25	5	20	--	--		10	10	10	--	--
#Submodule Count    :	138	--	--	71	67		--	--	--	TBD	TBD


# ==================== APPROVAL Report for SCV 25_09_2025 ============================================
# SM OBS Dashboard data for Platform : SCV and Date: 25_09_2025
# -------------------------------------------------------------------------------------------
# DML Count Details for SCV and 25_09_2025

# DML Total Raised Count                    : 21
# DML Total APL* Released Count             : 3
# DML Total Not APL* Released Raised Count  : 18
# Pending DML ERC In Designer Working Count : 2
# Pendign DML MBOM Working Count            : 2
# Pending DML APL Working Count             : 0
# Pending DML STDS Working Count            : 0
# -------------------------------------------------------------------------------------------
# SM Count Details for SCV and 25_09_2025

# SM Total Raised Count                     : 86
# SM Obsolete Approved Count                : 42
# SM Obsolete Pending Count                 : 44
# -------------------------------------------------------------------------------------------



#echo "PLATFORM,Request-SM-Count,TotalRaised,TotalSMCount,TotalMBOMReleased,TotalAPLAnyPlantReleased,TotalSTDSAnyPlantReleased,TotalObsolete"
echo "==================== Submodule Obsolescence Dashboard Report Printing... for $1 $2 ============================================"
echo "$1,DML_Count,$PLTotalDMLCount,$Total_DML_APLReleased_Count,$Total_DML_PendingForAPLReleased_Count,--,--,$Total_DML_ERCPendingCount,$Total_DML_MBOMPendingCount,$Total_DML_APLAnyPlantPendingCount,$Total_DML_STDSAnyPlantPendingCount,--,--" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".txt"
echo "$1,SM_Count,$PLTotalSMCount,--,--,$Total_ObsoleteCount,$Total_SM_ObsoletePendingCount,--,--,--,--,TBD,TBD" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".txt"


cat "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".txt"

echo "<AG_$1>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<ProductLine>$1</ProductLine>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalDMLRaised>$PLTotalDMLCount</DMLCount_TotalDMLRaised>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalDMLReleased>$Total_DML_APLReleased_Count</DMLCount_TotalDMLReleased>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalDMLPending>$Total_DML_PendingForAPLReleased_Count</DMLCount_TotalDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalSMObsoleted>--</DMLCount_TotalSMObsoleted>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalSMObsPending>--</DMLCount_TotalSMObsPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalERCDMLPending>$Total_DML_ERCPendingCount</DMLCount_TotalERCDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalMBOMDMLPending>$Total_DML_MBOMPendingCount</DMLCount_TotalMBOMDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalAPLDMLPending>$Total_DML_APLAnyPlantPendingCount</DMLCount_TotalAPLDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalSTDSDMLPending>$Total_DML_STDSAnyPlantPendingCount</DMLCount_TotalSTDSDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalSAPArchived>--</DMLCount_TotalSAPArchived>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<DMLCount_TotalSAPArchivedPending>--</DMLCount_TotalSAPArchivedPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"

echo "<SMCount_TotalSMRaised>$PLTotalSMCount</SMCount_TotalSMRaised>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<SMCount_TotalDMLReleased>--</SMCount_TotalDMLReleased>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<SMCount_TotalDMLPending>--</SMCount_TotalDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<SMCount_TotalSMObsoleted>$Total_ObsoleteCount</SMCount_TotalSMObsoleted>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<SMCount_TotalSMObsPending>$Total_SM_ObsoletePendingCount</SMCount_TotalSMObsPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<SMCount_TotalERCDMLPending>--</SMCount_TotalERCDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<SMCount_TotalMBOMDMLPending>--</SMCount_TotalMBOMDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<SMCount_TotalAPLDMLPending>--</SMCount_TotalAPLDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<SMCount_TotalSTDSDMLPending>--</SMCount_TotalSTDSDMLPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<SMCount_TotalSAPArchived>TBD</SMCount_TotalSAPArchived>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "<SMCount_TotalSAPArchivedPending>TBD</SMCount_TotalSAPArchivedPending>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"
echo "</AG_$1>" >> "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"

cat "MCC_SM_Obsolescence_Dashboard_AGGR_GRP_Data_"$2".xml"


echo "End.....Completed.."