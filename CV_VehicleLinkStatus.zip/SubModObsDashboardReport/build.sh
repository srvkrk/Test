./compile MCCSUBMODObsDashboardReport.c
./linkitk -o MCCSUBMODObsDashboardReport MCCSUBMODObsDashboardReport.o
/user/cvprod/TC_ROOT14/tcldPatch/tcPatchExecutable MCCSUBMODObsDashboardReport

echo "Finished..."
