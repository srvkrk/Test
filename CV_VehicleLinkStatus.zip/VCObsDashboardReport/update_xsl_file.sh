echo "Going to update Stylesheet : vc_obs_dashboard_rpt.xsl"
ls -lrt
echo "Going ahead...It will take some time"
sleep 5

$TC_ROOT/bin/import_file -u=infodba -pf=/user/cvprod/shells/Admin/infodbapasswdfile.pwf -g=dba -f=vc_obs_dashboard_rpt.xsl -type=CrfHtmlStylesheet -d=vc_obs_dashboard_rpt -ref=XSL -de=r

echo "Completed..."
sleep 5
exit
