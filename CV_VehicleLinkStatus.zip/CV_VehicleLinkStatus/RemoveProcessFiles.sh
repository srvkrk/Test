cd /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_VehicleLinkStatus
rm -rf $1
rm -rf $2
rm -rf $3
rm -rf $4

mv $5 /tmp/VehicleLinkStatusReport.xml
