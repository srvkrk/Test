######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : JUNE-2024
#
#######################################################################################

echo -e "\nIn Calling Shell Started...."

echo -e "\nRedirection(SSH:vztcua11srv3[172.22.99.106]) MCC Library Details Report Execution Shell Started...."
#ssh cvprod@172.22.99.106 -n "sh /user/cvprod/sourav/ReportBuilderPartAppRpt/ExecuteShell.sh $1 $2 $3"
#/user/infodba04/sourav/Submodlibrpt/ExecuteShell.sh
#GENDATETIME=`date +"%d_%b_%Y_%H_%M_%S"`
#START="SubModuleVarReport_MCC_TABS"
#END=".xml"
#BKPFILENAME="${START}${END}"
#echo "Backup File Name: " $BKPFILENAME
cp /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_SubModuleDashboardDetails/SubModuleDashboardDetailsReport.xml /tmp/SubModuleDashboardDetailsReport.xml
echo -e "\nRedirection(SSH:vztcua11srv3[172.22.99.106]) MCC Library Details Report Execution Shell Ended...."

echo -e "\nIn Calling Shell Ended...."

