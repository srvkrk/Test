cd /proj/PLMLoading/UAFiles/ProE_Downloading/CVPROD/CV_VehicleCompare
rm -rf $1
rm -rf $2
rm -rf $3
rm -rf $4
echo "File Name: " $5

mv $5 /tmp/VehicleCompareReport.xml
