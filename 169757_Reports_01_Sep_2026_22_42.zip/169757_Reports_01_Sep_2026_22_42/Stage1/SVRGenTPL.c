/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: SVRGenTPL.c
**
** Functions:- 	This utility queries DML into teamcenter and get it's revision's closure date, if found null then stamps released date as a closure date 
				on DML Revision and it's associated tasks and writes required information into the file.
** 
**
**	Date							Author								Modification
**	02-Aug-2018						Bhaskar Dimble					Code creation
**
** command to run:
** DML_GenTPL_Report fileNameIntput
***********************************************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <epm/cr_effectivity.h>
#include <epm/epm.h>
#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <property/prop.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tc/iman.h>
#include <tc/preferences.h>
#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/iman_msg.h>
#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <unidefs.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
		
    }
	return return_code;
}

FILE		*output 			= NULL;
int			ifail 				= ITK_ok;
char		*sep				= "^";
int read_value_from_file(char*);
int DML_GenTPL_Report(char*);

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -u=<teamcenter dbUsr id> (required)\n"
        " -p=<teamcenter password> (required)\n"
        " -g=<teamcenter group> (required)\n"
        " -file=<file name> (required)\n"
        );	
}


static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}


/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
					It checks for the proper dbUsr name and password.	
*******************************************************************************/
int ITK_user_main(int argc, char *argv[])
{
	//char			* userid 					= NULL;
	//char			* password					= NULL;
	//char			* group						= NULL;
	char			* Platform						= NULL;
	char			* SVR						= NULL;
	char			* WithoutZeroQty						= NULL;
	char			* Plant						= NULL;
	char			* RevisionRule						= NULL;
	char			Data[100]					= "";
	char			outputFile[200]				= "";
	char			*test						= (char*)MEM_alloc(sizeof (char) * 200);

	//userid			= ITK_ask_cli_argument("-u=");
	//password 		= ITK_ask_cli_argument("-pf=");
	//group 			= ITK_ask_cli_argument("-g=");
	Platform 		= ITK_ask_cli_argument("-Platform=");
	SVR 			= ITK_ask_cli_argument("-SVR=");
	RevisionRule 	= ITK_ask_cli_argument("-RevisionRule=");
	WithoutZeroQty 	= ITK_ask_cli_argument("-WithoutZeroQty=");
	Plant 	= ITK_ask_cli_argument("-Plant=");
	
	time_t 	now;
	struct 	tm when;
	
	time(&now);
	when = *localtime(&now);
	//for output file with date.
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
	sprintf(outputFile,"%s_output.txt",Data);

	//to remove extra sapce.
	if( tc_strlen(stripBlanks(Platform)) == 0 || tc_strlen(stripBlanks(SVR)) == 0 || tc_strlen(stripBlanks(RevisionRule)) == 0 || tc_strlen(stripBlanks(WithoutZeroQty)) == 0)
	{
		print_requirement();
		return -1;
	}
	
	//Auto login
	//ITK_CALL(ITK_auto_login());
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	//ITK_CALL(ITK_init_module( userid, password, group ));
	ITK_CALL(ITK_init_module("ercpsup" ,"XYT1ESA","dba")) ;
	/*if (ifail != ITK_ok)
	{
		printf("Error in Login to Teamcenter\n");
		return ifail;
	}
	else
	{
		printf("\nLogin Successfull.....!!\n");
		printf("\nWelcome to Teamcenter.....!!\n");
	}*/
	//provide access.
	ITK_CALL(ITK_set_bypass(true));
	//ifail=ITK_set_bypass(true);
   /* if (ifail != ITK_ok)
	{
		printf("\nUser is not Privileged Admin User \n\n");
		return -1;
	}	*/
	//File open here
	output = fopen(outputFile, "a+");
	if (output == NULL)
	{
		//printf("ERROR: Cannot open File\n");
		return -1;
	}
	else
	{
		//printf("File opened successfully.\n");
	}
	
	
			
		//ifail = read_value_from_file(file);
		ITK_CALL(Platform_SVR(Platform,SVR,RevisionRule,WithoutZeroQty,Plant));
		CHECK_FAIL;
	fclose(output);
	//printf("\n*********************");
	//printf("\nEnd of program.....!!");
	//printf("\n*********************\n");
	//ifail =  ITK_exit_module(true);
	return ifail;
}

/*********************************************************************************************
    Function:       read_value_from_file
    Description:    This function reads input value from file and performs action accordingly.	
**********************************************************************************************/
/*int read_value_from_file(char* Filename)
{
	int				count	 	= 0;
	char 			*dml_no		= NULL;
	char 			temp[200];
	
	FILE* fp = NULL;
	fp = fopen(Filename, "r");
	if (fp != NULL)
	{
		while (fgets(temp, 200, fp)!= NULL)
		{
			tc_strcpy(temp,stripBlanks(temp));

			if (tc_strlen(temp) > 0 && tc_strcmp(temp, NULL) != 0)
			{
				dml_no = strtok(temp, " ");
				printf("\nInput dml_no:%s\n",dml_no);fflush(stdout);
				ifail =  Platform_SVR(dml_no);
			}
			tc_strcpy(temp, "");
		}
	}
	else 
	{
		printf("File Unable to Open...!!");
	}
	fclose(fp);
	return ifail;
}*/


/**********************************************************************************************
    Function:       Platform_SVR
    Description:    This function queries the dml into teamcenter and expand it through task 
					and it's parts and then checks for release status and effectivity date.
**********************************************************************************************/
int Platform_SVR(char* Platform,char* SVR,char* RevisionRule,char* WithoutZeroQty,char* Plant)
{
	FILE 			*InputFile;


	int		transfermode1Cnt	= 0;
	int		transfermodeCnt	= 0;
	int		eff_count		= 0;
	int		task_count		= 0;
	int		part_count		= 0;

	char	*task_id		= NULL;
	char	*part_id		= NULL;
	char	*RevTyp			= NULL;
	char	*status_name	= NULL;
	char	*PrtRevTyp			= NULL;
	char	*prt_id			= NULL;
	char	*revId			= NULL;
	char	*part_Rev			= NULL;
	char	*dmlNumber		= NULL;
	char	output[500];
	char	Doutput[500];
	char	DoutputExl[500];
	char	mainFile1[50];
	char	mainFile[50];
	char	command[512];
	char	docFile[50];

	tag_t	dml_task_rel	= NULLTAG;
	tag_t 	tagRule 			= NULLTAG;
	tag_t	task_part_rel	= NULLTAG;
	tag_t	Prev_tag			= NULLTAG;
	tag_t	rev_tag			= NULLTAG;
	tag_t	part_t			= NULLTAG;
	tag_t	dml_tag			= NULLTAG;
	tag_t	*task_tag		= NULL;
	tag_t	*part_tag		= NULL;

	tag_t	*effectivities	= NULL;
	tag_t	*transfermodes1	= NULLTAG;
	tag_t	*transfermodes	= NULLTAG;
	tag_t	RevPrtTypTag		= NULLTAG;
	tag_t	RevTypTag		= NULLTAG;
	tag_t	PLMSession		= NULLTAG;
	tag_t	PLMSession1		= NULLTAG;
	tag_t	msWordType=NULLTAG;
	tag_t	wordDataset=NULLTAG;
	tag_t	wordLatestDat_t=NULLTAG;
	tag_t specRelationType_t=NULLTAG;
	tag_t specificationRel_t=NULLTAG;

	 char        *ItemId                 = NULL;
    char        *RevId                  = NULL;
	char        *VCItemId                 = NULL;
	char        *SVRType                  = NULL;

    tag_t        rev                    = NULLTAG;
    tag_t        rev1                    = NULLTAG;
	tag_t		 view_type				= NULLTAG;

	int    n_bom_views=0;
	int    j=0;
	tag_t *bom_views=NULL;
	tag_t  bom_view_type=NULLTAG;
	int    bom_view_index=0;
	int    noAttachment=0;
	tag_t  item=NULLTAG;
	tag_t        bom_view                = NULLTAG;
	tag_t			*attachments			=NULLTAG;
	tag_t			*attachments12			=NULLTAG;

	tag_t   e_block=NULLTAG;
	tag_t DMLTag = NULLTAG;
	tag_t   bom_window=NULLTAG;
	tag_t   window2=NULLTAG;
	tag_t   top_line=NULLTAG;
	tag_t   top_line1=NULLTAG;
	tag_t   rule	=NULLTAG;
	tag_t   Childobject=NULLTAG;
	tag_t   Childobject1=NULLTAG;
	tag_t   Childobject3=NULLTAG;
	tag_t   Childobject4=NULLTAG;
	tag_t   Childobject33=NULLTAG;
	tag_t			dataset									= NULLTAG;
	int     n_saved_variant_rules=0;
	tag_t  *saved_variant_rules=NULLTAG;
	tag_t   bom_variant_rule=NULLTAG;
	logical list_changed=FALSE;
	int     n_options=0;
	int     errorflag=0;
	int     errorflag4=0;
	int     errorflag1=0;
	int     errorflag2=0;
	int     errorflag34=0;
	tag_t  *options=NULL;
	char   *v2_text=NULL;
	//tag_t  *option_revs=NULL;
	int     option_value_index=-1;
	tag_t   option1=NULLTAG;
	tag_t  *option1_rev=NULL;
	int    *option1_value_index=NULL;
	tag_t   option2=NULLTAG;
	tag_t  *option2_rev=NULL;
	int    *option2_value_index=NULL;
	int     inx, jnx, knx;
	int     n_option_data=0,p1=0;
	tag_t topline = NULLTAG;
	void  **option_data=NULL;

	logical invalid_option_value_combination=TRUE;
	logical soft_abort=FALSE;
	logical option_excl=FALSE;
	int     n_ves_2_save=0;
	int     n_lines2=0;
	int     n_lines3=0;
	int     n_lines4=0;
	int     p2=0;
	int     ss=0;
	int     p36=0;
	
	int     p4=0;
	tag_t  *ves_2_save=NULL;
	tag_t   toggle_ve=NULLTAG;
	int n_lines,n_lines1,Item_ID = 0;
	tag_t *lines = NULL;
	tag_t *lines2 = NULL;
	tag_t *lines3 = NULL;
	tag_t *lines4 = NULL;
	tag_t *Newlines = NULL;
	char *Item_ID_str=NULL;
	tag_t			relation_type							= NULLTAG;
	tag_t			relation_type1							= NULLTAG;
	char			relation_name[TCTYPE_name_size_c+1];
	char *child_item_id=NULL;
	char *child_item_id1=NULL;
	char *child_item_id15=NULL;
	char *child_item_revision_id=NULL;
	char *child_item_id_new=NULL;
	char *child_bl_formula=NULL;
	char *child_bl_formula23=NULL;
	char *objecttype=NULL;
	char *objectname=NULL;
	logical modB=FALSE;
	char *tempmat=NULL;
	char MulModule[1900] = { 0 };
	char MulChild[1900] = { 0 };
	//char *MulModule= NULL;
	char Fresh[1900];
	char NoModule[1900];
	char RevMisMatch[900];

	
	
	//int ifail = ITK_ok;
	int cnt = 0;

	int cnt33 = 0;
	int ko = 0;
	int p3 = 0;
	int i = 0;
	int status_count = 0;
	tag_t  v1=NULLTAG;
	tag_t  primary=NULLTAG;
	tag_t  VarientRuletag=NULLTAG;
	tag_t	tRelationExist	= NULLTAG;
	//const tag_t * 	primary1;
	int ix=0;
	char *option_item_s     =NULL;
	char *option_s          =NULL;
	char *option_eq_s       =NULL;
	char *option_val_s      =NULL;
	tag_t  item1=NULLTAG;
    tag_t			rootTask				=NULLTAG;
	char *tempmat1=NULL;
	tag_t option;
	tag_t option_rev;

tag_t VariqueryTag = NULLTAG;
char **valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));
int n_entriesV = 1;
		int resultCountVNCol = 0;
			char *qry_entries3[1] = {"Name"},
			 *qry_values3[1]	= {"*"};

	
	tag_t  objTypeTagDi=NULLTAG;
	tag_t  objTypeTagDi1=NULLTAG;
	tag_t  opt_tag=NULLTAG;
	tag_t  master_tag=NULLTAG;
	tag_t  Itemmaster_tag=NULLTAG;
	tag_t  *opts=NULLTAG;
	tag_t  *rootLine=NULL;
	tag_t * 	bom_variant_config=NULL;
	tag_t  *opt_revs=NULLTAG;
	tag_t  *secondaries=NULL;
	tag_t  *occs=NULL;
	tag_t  relation_dep	= NULLTAG;
	tag_t *occsal;
	tag_t  *secondary_objects	= NULLTAG;
	tag_t  *secondary_objects1	= NULLTAG;
	GRM_relation_t *primary_list_Dep	= NULLTAG;
	tag_t   *status_list          = NULLTAG;
	double mat[4][4];
	//double * mat1;
	double divInt=1000;
	int imat=0;
	int jmat=0;
	int IntAtr5=0;
	int n_occs=0;
	int iy=0;
	int p34=0;
	int countConfigCtx = 0;
	tag_t  *ConfigCtxSecObject	= NULLTAG;
	tag_t  ConfigCtx=NULLTAG;
	tag_t  ConfigCtxObjTypeTag=NULLTAG;
	char   Config_CtxType[TCTYPE_name_size_c+1];
	char*	 SmVCContext			= NULL;
	char*	 SmCrIDContext			= NULL;
	char*	 itemId12			= NULL;
	char*	 itemId123			= NULL;
	char*	 itemId1234			= NULL;
	char*	 itemId12345			= NULL;
	 tag_t	queryTag	= NULLTAG;
	int n_entries = 1;
	char *qry_entries[1] = {"ID"};
	int resultCount=0;
	
	tag_t Optfmly_tag = NULLTAG;
	char*	 ContextobjName			= NULL;
	int    opcode=-1;
	tag_t  v2=NULLTAG;
	char  *str=NULL;
	char  *object_type=NULL;
	char  *find_option_name_p=NULL;
    char  *find_option_desc_p=NULL;
	char  *Context_Str=NULL;
	char *toggle_value=NULL;
     tag_t toggle_option=NULLTAG;
     tag_t *toggle_option_rev=NULLTAG;
     int   toggle_value_index=-1;
	tag_t *ves=NULL;
	int *ind=NULL;
	int *ind1=NULL;
	int int_qunt=0;
	int cnt12 = 0;
	int    n_ves,n_opts,k=0,k1=0,Opt1=0,n_values1=0,n_secondaries=0,countDep,countDep1=0;
	tag_t owning_item = NULLTAG;
	tag_t			*attachments1							= NULLTAG;
	char *name = NULL;
	char   type_name2[TCTYPE_name_size_c+1];
	char   type_name[TCTYPE_name_size_c+1];
	char   type_name1[TCTYPE_name_size_c+1];
	char*			username				=NULL;
	 char **rulename = NULL;
    char **rulevalue = NULL;
	char *desc = NULL;
	char *varrul = NULL;
	int xform_matrix1 = 0;
	int blqu = 0;
	char *blqu_str = NULL;
	char *xform_matrix_str = NULL;
	char ***ite = NULL;
	char ***opt = NULL;
	char ***descr = NULL;
	char ***value = NULL;
	 tag_t  *OptionValue=NULL;
        tag_t  *option_revs=NULL;
	char *CurrentRelStatus = NULL;
	int  count=0;
	char   *TempVal			=NULL;
	char   *VehName			=NULL;
	char   *DMLDRstatus			=NULL;
	tag_t  	VCrev;
	tag_t  	NewVC;
	tag_t  	NewVCRev;
	tag_t  	objTypeTag=NULLTAG;
	tag_t  	Itemrev;
	tag_t ItemRev = NULLTAG;
	tag_t ItemRev1 = NULLTAG;
	tag_t	Rel_task		= NULLTAG;
	tag_t RevNewSeqTag = NULLTAG;
	tag_t        parent_master           = NULLTAG;
	tag_t        parent_master1           = NULLTAG;
	tag_t rev_create_input_tag = NULLTAG;                              
	tag_t item_type_tag = NULLTAG;
	tag_t *closurerule = NULL;
	int n_entry = 1;
	int rsltCount = 0;
	tag_t qryTag = NULLTAG;
	tag_t *CntrolObjectTag = NULLTAG;
	char *qry_entry[1] = {"Name"};
	char **qry_values2 = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t item_create_input_tag = NULLTAG;
	 logical retain=false;
	 tag_t   status2=NULLTAG;
	 tag_t   status3=NULLTAG;
	 tag_t   status4=NULLTAG;
	 tag_t   plat=NULLTAG;
	tag_t rev_type_tag = NULLTAG;
		tag_t tsk_dml_rel_type;
		tag_t DMLRevTag = NULLTAG;
		char *class_name1;
		char* DMLtype		= NULL;	
		tag_t *outputVNCol_tags=NULLTAG;
		
		char PartNum[300];
		int Childstrcnt		= 0;	
	int p=0;
	int ju=0;
	int jy=0;
	int v_entr=0;
	tag_t class_id1=NULLTAG;
	tag_t *DMLRevision = NULLTAG;
	tag_t *bvs, *bvrs;
    int    bv_count, bvr_count;
	tag_t        bv,bvr,parentBvr,bv1,bvr1       = NULLTAG;
	tag_t        Childrev                = NULLTAG;
	tag_t			user_tag				=NULLTAG;
	int rulefound= 0;
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	tag_t cond_ve;
	tag_t loadif_ve;
	int structcount=0;
	tag_t veb;
	logical is_latest;
	tag_t close_tag;
	tag_t ** 	variant_rule_list= NULLTAG;
	tag_t top_bomline;
	tag_t clause_list = NULLTAG; 
	TempVal=(char *) MEM_alloc(1000);
		

ITK_CALL(ITEM_find_item(Platform, &plat));
	
	ITK_CALL(ITEM_ask_latest_rev(plat, &rev));

	if(TCTYPE_ask_object_type(rev, &RevTypTag));
	if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
	printf("\n MT: RevTyp type: [%s]\n", RevTyp);fflush(stdout);

	if(QRY_find("VariantRule", &VariqueryTag));
		printf("\n\t After IFERR_REPORT : QRY_find .... "); fflush(stdout);

		if (VariqueryTag)
		{
			printf("Found Query 'VariantRule' \n\t"); fflush(stdout);
		}
		else
		{
			printf("Not Found Query 'VariantRule' \n\t"); fflush(stdout);

			//ITK_CALL(POM_logout(false));
			//return status;
		}

		valuesNonColSvr[0] = SVR ;

		if(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));

		printf("   n_entriesV:%d   resultCount:%d \n\t",n_entriesV,resultCountVNCol); fflush(stdout);

		if (resultCountVNCol > 0)
		{
			VarientRuletag = outputVNCol_tags[0];
		}
		else
		{
			printf ("\n NonColour-SVR-VarientRule not present  [%s]\n", SVR); fflush(stdout);
			exit (0);
		}


	//ITK_CALL(ITEM_find_item(SVR, &vrntrule));
	/*if(ifail != ITK_ok)
	{
		//printf("\nDML not found...!!");fflush(stdout);
		TC_write_syslog("\nDML not found in TC...!!\n");fflush(stdout);
	}*/
	//ITK_CALL(ITEM_ask_latest_rev(vrntrule, &primary1));

	//if(TCTYPE_ask_object_type(primary1, &RevTypTag1));
	//if(TCTYPE_ask_name2(RevTypTag1,&RevTyp1));
	//printf("\n MT: RevTyp type: [%s]\n", RevTyp1);fflush(stdout);

	if(AOM_ask_value_string(VarientRuletag,"object_type",&objecttype));

	//TC_write_syslog("\n\n\n\n\n Rev Type ChangeRequestRevision........  \n\n\n\n\n");

	if (tc_strcmp(RevTyp,"T5_PlatformRevision")==0)
	{

		if ( rev !=NULLTAG )
			{
				CALLAPI ( PS_find_view_type( "view", &view_type ));
				printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

				if ( view_type != NULLTAG )
				{
					CALLAPI ( ITEM_ask_item_of_rev( rev, &item ));
					CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

					bom_view = bom_views[0];
				}
				else
				printf("\nView not found check.......\n"); fflush(stdout);
			}


						 if ( bom_view != NULLTAG )
				{
					printf(" before BOM_create_window..\n");	fflush(stdout);	
					CALLAPI ( BOM_create_window( &bom_window ));
					//CALLAPI(CFM_find( "ERC release and above", &rule ))
					CALLAPI(CFM_find( RevisionRule, &rule ));
					CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
					
					
					CALLAPI(PIE_find_closure_rules( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
					
					printf ("rule count %d \n",rulefound);fflush(stdout);
					 if (rulefound > 0)
					 {
									close_tag = closurerule[0];
									printf ("closure rule found \n");fflush(stdout);
								   // MEM_free(tags_found);
					 }
					 CALLAPI(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));
					
					CALLAPI(BOM_set_window_pack_all(bom_window, FALSE));
					CALLAPI ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
					printf( " After BOM_set_window_top_line..\n");fflush(stdout);
					
					CALLAPI ( BOM_window_ask_variant_rule( bom_window, &bom_variant_rule ));
					printf( " BOM_window_ask_variant_rule..\n");fflush(stdout);

					//ITK ( ITEM_ask_rev_variants ( rev, &e_block ) )
                    
					CALLAPI(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
				 CALLAPI(TCTYPE_ask_name(objTypeTag,type_name));	


				//	CALLAPI(AOM_UIF_ask_value(primary1,"expression_block",&rulename));
				//	fprintf( stderr, " BOM_window_ask_variant_rule..%s\n",rulename);

					CALLAPI ( ITEM_ask_rev_variants ( rev, &e_block ));
					printf(  " ITEM_ask_rev_variants..\n");fflush(stdout);
					
					if(top_line!=NULLTAG)
					{
						CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines, &lines));
						printf("\n Before setting option n_lines: %d and Item_ID_str :%s\n", n_lines,Item_ID_str);
						CALLAPI(BOM_window_hide_unconfigured(bom_window))   ;
										CALLAPI(BOM_window_show_variants(bom_window))   ;
										//if(BOM_create_window_variant_config(bom_window,1,&bom_variant_config))   ;
										//if(BOM_variant_config_apply (bom_variant_config))   ;

										//if(BOM_variant_rule_apply(primary1))   ;	
										printf("\n After inside bom_window-----\n"); fflush(stdout);			
										CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
										printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

										//if(BOM_window_apply_overlay_variant_rules(bom_window,1,primary1, "SVRACTION_OVERLAY_ADD_RULE", &count, &variant_rule_list))   ;
										CALLAPI(BOM_window_hide_variants(bom_window))   ;

										CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));

										 CALLAPI( BOM_line_look_up_attribute ("bl_quantity",&blqu));
								 xform_matrix1=0;
								// CALLAPI( BOM_line_look_up_attribute ("bl_abs_xform_matrix",&xform_matrix1));
								 CALLAPI( BOM_line_look_up_attribute ("bl_plmxml_abs_xform",&xform_matrix1));
									CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
									printf("\n LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);


									// for deleting structure of existing Dummy node

									CALLAPI(ITEM_find_item("DummyRev", &parent_master));
							printf( "\n parent_master found...........\n"); fflush(stdout);

							if(parent_master !=NULLTAG)
							{
								//CALLAPI ( ITEM_copy_item( parent_master, &VCrev ));
								//CALLAPI(ITEM_list_bom_views(parent_master,&bv_count, &bvs))
								//printf( "\n bv_count :%d..\n",bv_count); fflush(stdout);
								CALLAPI ( ITEM_ask_latest_rev( parent_master, &VCrev ));
								CALLAPI(AOM_lock( VCrev ));
								CALLAPI(AOM_lock( parent_master ));
								if(AOM_refresh(VCrev,1));
								CALLAPI ( ITEM_copy_item( VCrev, "","NR;1", &NewVC, &NewVCRev ));
								CALLAPI(AOM_save( NewVC ))
								CALLAPI( AOM_save( NewVCRev ))
								CALLAPI( AOM_unlock( NewVC ))
								CALLAPI( AOM_unlock( NewVCRev ))
								CALLAPI(ITEM_list_bom_views(NewVC,&bv_count, &bvs))

										if (bv_count)
														{
															bv = bvs[0];
															MEM_free(bvs);
														}else
														{
															CALLAPI( PS_create_bom_view( NULLTAG, "", "", NewVC,&bv ));
															CALLAPI(AOM_save( bv ))
															CALLAPI( AOM_save( NewVC ))
															CALLAPI( AOM_unlock( NewVC ))
															printf(  "\n inside PS_create_bom_view..\n"); fflush(stdout);				
														}

									 CALLAPI(ITEM_rev_list_bom_view_revs(NewVCRev,&bvr_count, &bvrs));
															  //t5removeAllReleaseStatus (VCrev);
                                                         //CALLAPI(UpdateAllowForm(VCrev,"Y"));
														//CALLAPI(AssignProject(VCrev,itemId1234));
															 //CALLAPI (CR_create_release_status("T5_LcsWorking",&status2));
															//		printf("\n release status find.");fflush(stdout);
															//		CALLAPI(EPM_add_release_status(status2,1,&VCrev,retain));
														printf( "\n bvr_count of Rev :%d..\n",bvr_count); fflush(stdout);
														if (bvr_count)

														{
															bvr = bvrs[0];
															 CALLAPI(AOM_lock( bvr ));


															CALLAPI(PS_list_occurrences_of_bvr( bvr,&n_occs, &occsal ));

															 for (iy = 0; iy<n_occs; iy++)
															{
																
																CALLAPI(PS_delete_occurrence( bvr, occsal[iy] ));
															}
//															
															MEM_free(bvrs);
														}else
														{
															CALLAPI(PS_create_bvr( bv, "", "", false, NewVCRev,&bvr) );
															if(bvr !=NULLTAG)
															{							
																CALLAPI( AOM_save( bvr) );
																CALLAPI (AOM_save( NewVCRev ));
																CALLAPI( AOM_unlock( NewVCRev ));
																printf(  "\n inside  PS_create_bvr..\n"); fflush(stdout);
															}
														}
							}

                                  // structure deletion ends

									//if(n_lines1 == n_lines)
									//{
										if (n_lines1 >0)
										{
											for (p1=0;p1<n_lines1 ;p1++ )
											{
												if(Childobject4) Childobject4=NULLTAG;
												Childobject4=lines[p1];
												//CALLAPI(BOM_line_unpack(Childobject4));

												CALLAPI(BOM_line_ask_child_lines(Childobject4, &n_lines4, &lines4));

												if (n_lines4 >0)
													{
														for (p4=0;p4<n_lines4 ;p4++ )
														{
															if(Childobject3) Childobject3=NULLTAG;
															Childobject3=lines4[p4];

															

															CALLAPI(TCTYPE_ask_object_type(Childobject3,&objTypeTagDi));
															CALLAPI(TCTYPE_ask_name(objTypeTagDi,type_name2));	  
								
															CALLAPI(AOM_ask_value_string(Childobject3, "bl_item_item_id", &child_item_id ));
															fprintf( stderr, " Last child_item_id ..:%s and type_name2 :%s\n",child_item_id,type_name2);

															CALLAPI(AOM_ask_value_string(Childobject3, "bl_rev_item_revision_id", &child_item_revision_id ));
															fprintf( stderr, " bl_rev_item_revision_id--------------> %s\n",child_item_revision_id);

															CALLAPI(AOM_ask_value_string(Childobject3, "bl_formula", &child_bl_formula ));
															fprintf( stderr, " child_bl_formula 2--------------> %s\n",child_bl_formula);

															printf("\n***********xform_matrix1:%d\n",xform_matrix1);
															CALLAPI(BOM_line_ask_attribute_string(Childobject3, xform_matrix1, &xform_matrix_str));
															printf( " child xform matrix 11--------------> %s\n",xform_matrix_str);fflush(stdout);

															tempmat1=tc_strtok(xform_matrix_str," ");

													for(imat=0;imat<4;imat++)
													{
														for(jmat=0;jmat<4;jmat++)
														{
															if(imat==0 && jmat==0)
															{
																printf("\n inside if"); fflush(stdout);
																mat[imat][jmat]=strtod(tempmat1,NULL);
															}else
															{
																printf("\n inside else"); fflush(stdout);
																tempmat=tc_strtok(NULL," ");
																mat[imat][jmat]=strtod(tempmat,NULL);
															}
														}
													}

															
															CALLAPI(BOM_line_ask_attribute_string(Childobject3, blqu, &blqu_str));

															fprintf( stderr, " child quantity matrix--------------> %s\n",blqu_str);

															int_qunt=atoi(blqu_str);

															fprintf( stderr, " child quantity int-------------> %d\n",int_qunt);


															CALLAPI ( ITEM_find_rev( child_item_id, child_item_revision_id, &Childrev ) );
															if(Childrev!=NULLTAG)
															{
																//CALLAPI ( VOO_show_wso( Childrev ) )
																CALLAPI(AOM_lock( bvr ));
																CALLAPI(PS_create_occurrences( bvr, Childrev, NULLTAG,1, &occs ));
																CALLAPI(PS_set_occurrence_qty(bvr, occs[0], int_qunt));

                                                                int_qunt = 0;

//															for(imat=0;imat<3;imat++)
//															{
//																mat[3][imat]=(double)(mat[3][imat]/divInt);
//															}

															for(imat=0;imat<4;imat++)
																{
																	for(jmat=0;jmat<4;jmat++)
																	{
																		printf("%10lf,",mat[imat][jmat]);
																	}
																	printf("\n");
																}

																CALLAPI(PS_set_plmxml_transform(bvr, occs[0], *mat));

																//	CALLAPI(AOM_lock(bvr));
														
																CALLAPI(AOM_save( bvr) );
																	CALLAPI(AOM_refresh(bvr,1));
																CALLAPI(AOM_unlock(bvr));
															}
														}
												}
											}
										}
										
										 CALLAPI(BOM_save_window(bom_window));
							 CALLAPI(BOM_close_window(bom_window));

						
					}
		
									}
									else
									{
										fprintf( stderr, "\n no bom window found here \n");
									}

									//break;					
							}

		//DML XML FILE CREATION.................



		//DML DATA EXPORT to XML...............
	
		
		        	tc_strcpy(mainFile,"");
				tc_strcpy(mainFile,"/tmp/");
				tc_strcat(mainFile,SVR);
				tc_strcat(mainFile,".xml");

						tc_strcpy(Doutput,"");
						tc_strcpy(Doutput,"/tmp/");
						tc_strcat(Doutput,SVR);
						tc_strcat(Doutput,"_GenTPL");
						tc_strcat(Doutput,".xml");
						TC_write_syslog("\n MT:Doutput.: [%s]", Doutput);fflush(stdout);
						tc_strcpy(DoutputExl,"");
						tc_strcpy(DoutputExl,"/tmp/");
						tc_strcat(DoutputExl,SVR);
						tc_strcat(DoutputExl,"_GenTPL");
						tc_strcat(DoutputExl,".xls");
						TC_write_syslog("\n MT:DoutputExl.: [%s]", DoutputExl);fflush(stdout);
			

				//PART GENTPL DATA EXPORT.............
				ITK_CALL(PIE_create_session(&PLMSession));
				ITK_CALL( CFM_find(RevisionRule, &tagRule));
                if (tc_strcmp(WithoutZeroQty,"No")==0)
				{
							ITK_CALL(PIE_find_transfer_mode2("T5_STRUCTURECONTEXT_TM","DEFAULT_PIE_CONTEXT_STRING",&transfermode1Cnt,&transfermodes1));
							TC_write_syslog("\n\n\n\n\n INside regular GenTPL........  \n\n\n\n\n");
				}
				else
				{
                            ITK_CALL(PIE_find_transfer_mode2("T5_GENTPL_Without_Zero_Qty_TM","DEFAULT_PIE_CONTEXT_STRING",&transfermode1Cnt,&transfermodes1));
							TC_write_syslog("\n\n\n\n\n INside w/o zero quantity GenTPL........  \n\n\n\n\n");
				}
				//printf("\n GENTPL TrasnferModes = %d\n",transfermode1Cnt);fflush(stdout);
				ITK_CALL(PIE_session_set_transfer_mode(PLMSession,transfermodes1[0]));
				ITK_CALL(PIE_session_set_revision_rule(PLMSession,tagRule));
				ITK_CALL(PIE_session_set_file(PLMSession,mainFile));
				ITK_CALL(PIE_session_export_objects(PLMSession,1,&NewVCRev));
				TC_write_syslog("\n\n\n\n\n PIE_session_export_objects........  \n\n\n\n\n");

		
				 if (tc_strcmp(Plant,"CAR")==0)
				{
				sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/Gentpl.sh  %s %s",mainFile,DoutputExl);
				TC_write_syslog("Command = %s\n",command);
				//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
				system(command);
				}
				else if (tc_strcmp(Plant,"CVBU LKO")==0)
					{
					sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/GentplCVBULKO.sh  %s %s",mainFile,DoutputExl);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					} 

					else if (tc_strcmp(Plant,"PUVBU")==0)
					{
					sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/GentplPUVBU.sh  %s %s",mainFile,DoutputExl);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					} 

					else if (tc_strcmp(Plant,"CVBU Pune")==0)
					{
					sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/GentplCVBUP.sh  %s %s",mainFile,DoutputExl);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					} 

					else if (tc_strcmp(Plant,"SMALLCAR AHD")==0)
					{
					sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/GentplAHD.sh  %s %s",mainFile,DoutputExl);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					} 

					else if (tc_strcmp(Plant,"SMALLCAR PNR")==0)
					{
					sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/GentplPNRCAR.sh  %s %s",mainFile,DoutputExl);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					} 

					else if (tc_strcmp(Plant,"CVBU PNR")==0)
					{
					sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/GentplCVBUPNR.sh  %s %s",mainFile,DoutputExl);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					} 

					else if (tc_strcmp(Plant,"DHARWAD")==0)
					{
					sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/GentplDWD.sh  %s %s",mainFile,DoutputExl);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					} 

					else if (tc_strcmp(Plant,"PCBU")==0)
					{
					sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/GentplPCBU.sh  %s %s",mainFile,DoutputExl);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					} 

					else if (tc_strcmp(Plant,"CVBU JSR")==0)
					{
					sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/GentplCVBUJSR.sh  %s %s",mainFile,DoutputExl);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					} 

	
					else 
					{
					sprintf(command,"/user/uaprod/TC_ROOT_10/bin/tml_tools/GentplPCBULKO.sh  %s %s",mainFile,DoutputExl);
					TC_write_syslog("Command = %s\n",command);
					//system("java -cp \".;/home/uadevTC_ROOT/bin/tml_tools\" org.apache.xalan.xslt.Process -IN %s -OUT /tmp/%s_dml_print_report -XSL /home/uadevTC_ROOT/bin/tml_tools/DML_print_report_template.xsl",mainFile,dmlNumber);
					system(command);
					} 
		

				// create dataset for output excel

			
				TC_write_syslog("Doc file created successfully\n");
				ITK_CALL(GRM_find_relation_type("IMAN_reference",&specRelationType_t));
				ITK_CALL(AE_find_datasettype2("MSExcel",&msWordType));
/*				if(msWordType == NULLTAG)
				{
					TC_write_syslog("Could not find Dataset Type MSExcel. Please check data model\n");
					
				}	*/			

				ITK_CALL(GRM_list_secondary_objects_only(NewVCRev,specRelationType_t,&cnt12,&attachments12));

//				for (jy=0; jy <= cnt12 ; jy++ )
//				{
//					ITK_CALL(GRM_find_relation(VCrev,attachments12[jy],specRelationType_t,&tRelationExist));  
//					ITK_CALL(GRM_delete_relation(tRelationExist));
//
//				}
				ITK_CALL(AE_create_dataset_with_id(msWordType,SVR,"GenTPLWithSVR","","",&wordDataset));
				ITK_CALL(AE_save_myself(wordDataset));
				


				ITK_CALL(GRM_create_relation(NewVCRev,wordDataset,specRelationType_t,NULLTAG,&specificationRel_t));
				ITK_CALL(AOM_load(specificationRel_t));
				ITK_CALL(GRM_save_relation(specificationRel_t));
				ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
				ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
				ITK_CALL(AE_import_named_ref(wordLatestDat_t,"excel",DoutputExl,NULL,SS_BINARY));
				ITK_CALL(AE_save_myself(wordLatestDat_t));
				//remove(DoutputExl);



				

				if(QRY_find("folder custom", &qryTag));
				if (qryTag)
				{
					//printf("\n ERCVali:Found Query ControlObjects \n");fflush(stdout);
					qry_values2[0] = "SVRGenTPL";
					if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrolObjectTag));
					printf("\t  rsltCount :%d:", rsltCount); fflush(stdout);
					if(rsltCount > 0)
					{

						if(AOM_lock(CntrolObjectTag[0]))PrintErrorStack();
					FL_insert(CntrolObjectTag[0],wordLatestDat_t,999);
					if(AOM_save(CntrolObjectTag[0]))PrintErrorStack();
					if(AOM_unlock(CntrolObjectTag[0]));PrintErrorStack();
					if(AOM_refresh(CntrolObjectTag[0],1))PrintErrorStack();
						

					}
				}

ITK_CALL(ITEM_delete_item(NewVC));
				
				



	

	MEM_free(part_tag);
	MEM_free(task_tag);
	
	
	//return ifail;	
	return ITK_ok;	
}

