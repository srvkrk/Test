<?xml version="1.0"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
           xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
                 xmlns:crf="http://ExternalFunction.setFile">

  <xsl:output method="html" indent="yes"/>
  <!--
  <xsl:key name="User" match="/plm:PLMXML/plm:User" use="@id"/>
  <xsl:key name="Organisation" match="/plm:PLMXML/plm:Organisation" use="@id"/>
  <xsl:key name="ReleaseStatus" match="/plm:PLMXML/plm:ReleaseStatus" use="@id"/>
  -->
  <xsl:variable name="No_of_row_fnd_cnt"/>
  <xsl:param name="criteria_count"/>
  <xsl:param name="search_criteria"/>

  <xsl:template match="/">
    <html>
      <head>
        <title>Target Cost Template</title>

		
        <script type="text/javascript">

          <![CDATA[
			
		//function 1 start
		function mywtmrk() {
			var textWatermark = 'TATA MOTORS LTD Confidential&#169;';
			var fullTextWatermark = '';
			var n = 1000;
			var wi = 0;
			for ( wi = 0; wi < n; wi++) {
			 fullTextWatermark+= ' ' + textWatermark;
			}
			document.getElementById('watermark').innerHTML = fullTextWatermark
		}
		window.onload = mywtmrk;
		//function 2 start
		var asc = true;
		function sortCells(i) {
			var column = document.all.sorttable.rows[0].cells.length;
			var row = document.all.sorttable.rows.length;
			var Ar = new Array(row - 1);
			for (idx = 0; idx < row - 1; idx++) {
				Ar[idx] = new Array(column);
			}
			for (idx = 1; idx < row; idx++) {
				for (idy = 0; idy < column; idy++) {
					Ar[idx - 1][idy] = document.all.sorttable.rows[idx].cells[idy].innerHTML;
				}
			}
			if (asc) {
				Ar.sort(function (a, b) { return a[i].localeCompare(b[i]) });
			}
			else {
				Ar.sort(function (a, b) { return b[i].localeCompare(a[i]) });
			}

			for (idx = 1; idx < row; idx++) {
				for (idy = 0; idy < column; idy++) {
					document.all.sorttable.rows[idx].cells[idy].innerHTML = Ar[idx - 1][idy];
				}
			}
			asc = !asc;
		}
		//function 3 start
		window.addEventListener("load", () => {
			// (A) TARGET THIS SECTION ONLY
			var target = document.getElementById("no-copy");

			// (B) PREVENT CONTEXT MENU FROM OPENING
			target.addEventListener("contextmenu", (evt) => {
				evt.preventDefault();
			}, false);

			// (C) PREVENT CLIPBOARD COPYING
			target.addEventListener("copy", (evt) => {
				// (C1) CHANGE THE COPIED TEXT IF YOU WANT
				evt.clipboardData.setData("text/plain", "TML Copying is not allowed on this webpage");

				// (C2) PREVENT THE DEFAULT COPY ACTION
				evt.preventDefault();
			}, false);
		});
		//funtion 3 start
        ]]>
        </script>
		
        <xsl:call-template name="printStyles"/>
      </head>
      <xsl:call-template name="printHeader"/>
      <div class="reportTitle">
        <center>Target Cost VMT Report</center>
      </div>
		

      <body id="no-copy">
		<style type="text/css">

			
		
		<!-- watermark -->
			@media print {
				#watermark_print {
				position:absolute;
				bottom:0;
				width:100%;
				height:60px;
				background:#6cf;
				display: block;
				position: fixed;
				right: 0;
				z-index: 5;
				color: #B81C1C;
				font-size: 25pt;
				height: 50%;
				margin: 0;
				top:350px;
				left:125px;
				margin: auto;
				margin-right: auto;
				margin-left: auto;
				webkit-transform: rotate(-40deg);
				moz-transform: rotate(-40deg);
				o-transform: rotate(-40deg);
				ms-transform:rotate(-40deg);
				transform: rotate(-40deg);
				filter: progid:DXImageTransform.Microsoft.
				BasicImage(rotation=3);
				ms-filter: "progid:DXImageTransform.Microsoft.
				BasicImage(rotation=3)";
				text-align: center;
				}
			}
			#watermark{
				width:100%;
				height:60px;
				bottom: 0;
				right: 0;
				font-size: 50px;
				font-weight: 250px;
				opacity: 0.2;
				color: #0d745e;
				user-select: none;
				ms-user-select: none;
				moz-user-select: none;
				khtml-user-select: none;
				webkit-touch-callout: none;
				webkit-user-select: none;
				
			}
			
			#no-copy{ 
				user-select: none; 
			}
			#no-copy::selection { 
				background: none; 
			}
			#no-copy::-moz-selection{ 
				background: none; 
			}
		</style>
		<div id="watermark" align="center">
			<p>mywtmrk()</p>
		</div>
		
		<!-- watermark -->
		<!--disable cut copy paste -->
		
		<!--disable cut copy paste -->
		<!-- 1st table -->
		<p>
		<table border="1">
        <tr bgcolor="#96D4D4">
			 <th style="text-align:left">UserID</th>
			 <th style="text-align:left">Role Name</th>
			 <th style="text-align:left">ItemID</th>
			 <th style="text-align:left">Object Name</th>
			 <th style="text-align:left">Platform</th>
			 <th style="text-align:left">Project Code</th>
			 <th style="text-align:left">Project Description</th>
		</tr>
			<xsl:for-each select ="plm:PLMXML/plm:Product/plm:UserData">
				<xsl:call-template name="creCLext_tct_item">
					<xsl:with-param name="occele_tct_item" select="current()"/>
				</xsl:call-template>
			</xsl:for-each>
		</table>
		

		<!-- 1st table -->
		<pr>
		<xsl:value-of select="plm:PLMXML/plm:Product[@productId]/@value"/>
		</pr>
		
		<table id="sorttable" class="maintable" >
		<tr>
			<!-- 2nd table -->
			<th onclick="sortCells(0)" title="clich here to sort">Level</th>
			<th onclick="sortCells(1)" title="clich here to sort">ModuleAddress</th>
			<th onclick="sortCells(2)" title="clich here to sort">Module</th>
			<th onclick="sortCells(3)" title="clich here to sort">Applicability</th>
			<th onclick="sortCells(4)" title="clich here to sort">PMXU</th>
			<th onclick="sortCells(5)" title="clich here to sort">ModuleNumber</th>
			<th onclick="sortCells(6)" title="clich here to sort">ChangeRemark</th>
			<th onclick="sortCells(7)" title="clich here to sort">TargetDMC</th>
			<th onclick="sortCells(8)" title="clich here to sort">TrgtToolCpx</th>
			<th onclick="sortCells(9)" title="clich here to sort">CstMgrRemark</th>
			<th onclick="sortCells(10)" title="clich here to sort">TargetCost</th>
			
			<th onclick="sortCells(11)" title="clich here to sort">Target Tooling Capex in Lakh (rolled up)</th>
			<th onclick="sortCells(12)" title="clich here to sort">Core benchmark target DMC cost in Rs.</th>
            <th onclick="sortCells(13)" title="clich here to sort">Core benchmark target Tooling cost in Lakh.</th>
            <th onclick="sortCells(14)" title="clich here to sort">Adjacent benchmark target DMC cost in Rs.</th>
            <th onclick="sortCells(15)" title="clich here to sort">Adjacent benchmark target Tooling cost in Lakh.</th>
		</tr>
		<xsl:for-each select ="plm:PLMXML/plm:ProductRevision/plm:TableRow">
			<xsl:call-template name="creCLext1">
				<xsl:with-param name="occele" select="current()"/>
			</xsl:call-template>
		</xsl:for-each>

        </table>
		</p>
		 <xsl:call-template name="printSearchCriteria"/>


      </body>
    </html>
	<div id="watermark_print" align="center">
		<p>TATA MOTORS LTD Confidential&#169;</p>
	</div>

  </xsl:template>
<!--print product info i.e. T5_DFC_TCT object/>-->
<xsl:template name="creCLext_tct_item">
    <xsl:param name="occele_tct_item"/>
   <tr>
		<td><xsl:value-of select="$occele_tct_item/plm:UserValue[@title='user_id']/@value"/>					</td>
		<td><xsl:value-of select="$occele_tct_item/plm:UserValue[@title='rolename']/@value"/>	</td>
		<td><xsl:value-of select="$occele_tct_item/plm:UserValue[@title='item_id']/@value"/>				</td>
		<td><xsl:value-of select="$occele_tct_item/plm:UserValue[@title='object_name']/@value"/>	</td>
		<td><xsl:value-of select="$occele_tct_item/plm:UserValue[@title='t5_Platform']/@value"/>					</td>
		<td><xsl:value-of select="$occele_tct_item/plm:UserValue[@title='t5_ProjectCode']/@value"/>	</td>
		<td><xsl:value-of select="$occele_tct_item/plm:UserValue[@title='t5_ProjectDescription']/@value"/>	</td>
	</tr>

	<!--Variable (user_id): <xsl:value-of select="$occele_tct_item/plm:UserValue[@title='user_id']/@value" />-->
  </xsl:template>

<!--print product info i.e. T5_DFC_TCTRevision object/>-->
  <xsl:template name="creCLext1">
    <xsl:param name="occele"/>
    <!--<xsl:variable name="occele" select="/plm:PLMXML/plm:ProductRevision[@id=$occid]"/>-->
	<tr>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_Level']/@value"/>					</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_ModuleAddress']/@value"/>	</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_Module']/@value"/>				</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_Applicability']/@value"/>	</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_PMXU']/@value"/>					</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_ModuleNumber']/@value"/>	</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_ChangeRemark']/@value"/>	</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_TargetDMC']/@value"/>			</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_TrgtToolCpx']/@value"/>		</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_CstMgrRemark']/@value"/>	</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_TargetCost']/@value"/>		</td>
		
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_TrgtToolCpxRolledup']/@value"/>		</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_Core_target_dmc']/@value"/>		</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_Core_target_tool_cst']/@value"/>		</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_adj_bnchmrk_trgt_dmc']/@value"/>		</td>
		<td><xsl:value-of select="$occele/plm:TableColumn[@title='t5_adj_bnchmrk_tool_cst']/@value"/>		</td>
	</tr>
  </xsl:template>

  <xsl:template name="printlogo">
    <div align="Center">
      <img  src= "data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAIBAQIBAQICAgICAgICAwUDAwMDAwYEBAMFBwYHBwcGBwcICQsJCAgKCAcHCg0KCgsMDAwMBwkODw0MDgsMDAz/2wBDAQICAgMDAwYDAwYMCAcIDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAgATIDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9tPjv+0X4Z/Z68J3GueJ9St9L0y1co0zAvLJLjiOKMAl3I7AdOa+cfCX/AAW++DPiDxMumSHxNpUMhCm+uLBDbKWbCsdkjSbSe5TA7kHAOV/wWX/Z28XfFrwT4V1vwppt1r1t4avprzU9LhBdiJEj2zGNcu4Ty2UhAW/e5xgEjivBP7R37Ov7Z/wvX4b+LdJj+G+syCKKJns7eB7O4QjHk3JR0jb73yygNhjxzXuYfB0Pq6qSV9dbdD8nz3ijNaebTwNOpCikvd502pvtzdD7V+I/x/0PwF8G9Q8fSXDX3h3T9MbVXntCsguoRHuQRZYKWc4CgsMkjBqt+y1+0fov7VHwvtfF/h6z1ix0m6lmghGoxxxTP5b7GYBJJBt3A87vwr5p/bK1Vv8AgnX+wRp/h3wXqV9etDqcdhp9xq8dvesI3LzsDGYhGyjYFA2A8jDVH8W/21tY/ZG/Zk+F2k22l2fiL4q+M9Mt54LSC2W0s1lcIXna3gIHzSSBQq4JJJ/hIrGOXuUEofaeh61Ti+eExDWYzUVSpRlNRV/flslLqn23PuSQL8rHjac8d6jgdARl1BJIxn3x+favzx+JP7T37Rn7Eg8P+L/iJqXhPxZ4X1i7W01DT7K1WB9OYozY80IpYkZxlmGUIJJIz13/AAU3/bc8TfArSfAT/DrVhZ6t40Y3gItIrq4lttqCNVSQFV3tIBngnBweDWccvq8yhfcp+ImWRoVcTUjO9K14cq5rT2dr2t+J9ygp2aPao655Ge9MaRYo1ZX3LjqOc1+b37U/7Zn7RH7KXinwVr/ia48Gw6R4kdpV8MWcBlZEi8otHLI6M/msJAAYm2q4GeOr/wBq79sL9or9nJPCfjDVJvCOjaH4nmdLbwrHbfariJIwJAtxM4DGRlYB2RsKQOOprZZXUclFNO+3mYS8SMBT541KU4Sp25rxukpNWe/mtNz9Ilk3Dcf4eORzTlZWTcvTpXxZ+19+3x4g8A+LfBvgX4f6Pbap8RvGkUM6W96S9voySKpHmBWAZhudgRuAVDkc5rjNd/au+OH7FXxk8G2fxb1Xwr428L+MpxatPptqLWXS23BW2lY0B2l1bJzwCfesP7Nq2bR2YrxAyuhWlTbbjGUYylbROWzep+gbXMZhVt3ytgKdw+bJAGPqSPzpqshUFmAIIxlua+Fv+ClH7Z/jr4BfGvwH4T+H94f7R8QFrq9thbpNNqO6VIYYkLKwjztZSRgjOc8GuQ/ab/a7/aL/AGRvHHg7WvEl14JfR/FEsiL4csIPMeGOIpmF5iC7yKsh+dW2ZB45FOnltRpa6vVGWO8Qstw9atSlGco0pRjKSjeKctm+tj9GlaNxxgYPPbmnh1JJGPTr1r47/wCCjf7b2vfst2XhPTvDttpq6v4uDeVcaoH+xaZCuxDuwRkqZFY5yAFOR0xzHgbxp+1R4N8b+GbpdU8D/GXwpq0o+2SaI1tbRWEefmw4Cc4yQTkEjHWso5fNU1Js6sRxvhaeNngoUpzlFxUnFK3vbPe9vRM+6fPUx5XrzgD2ryP9qz9sHQf2RPB0XiPxNDqV3ptxepYwx6bFHNM0jRvJnDyINoVDkgk5K8c5HqVq261VtrK0iZCsMMvHQjpkd8V+bH/BcD4jWt34p+HPhee4mhtPNudZvvKXeRGXWGJgg5bhXAA65NPLsJ9YrqnPVHRxxn9TKMoq4zDtKaajFy1Sbtuj1Nf+C7nwhuZBC2k+OlDHaxWwtyUHU5C3O7jjgAnnpX0P4Y/as8IeN/gHcfEfQ7+PUvC1lZT3lxLsHnQLEm542RiDv6fKSP5Z+MP2mf8Agot8AdY+AGseH/CvhuHWtW1LT2s7GI6F9jjjkZcCbzJEHKllYdyVwOtcjpOg65+y/wD8EbfER1j7RY3nxA1hUtLd4/KkSGVo1LlOq+ZFA7EHsRXqSyyi+Vxg03K2r6eh+c4LjzH0K9SNStDEU4UXJyhFx5ZdE3fXU+/P2R/2qNF/a9+HVx4m8P2esWen299JYH+0YEhkd0Cliiq7/L8wHJzkdK6z4wfFOz+EHgrUvEWpbhp2j2cl9eBVDOY0HRQWUbiSOpxXk3/BLv4dt8MP2IvBFu8Xl3WqWx1O4+XBZ53Lg/8AfO2uM/4LGfElvBn7G/iO2jbbca/c2+kxndglS/nOB/wCJh+NebHCqrilQj3sfoH9tYnCcNf2li3+8jS5n6yWn6HRfsof8FKvAX7YPxDl8K6Bp/iqw1GPT31Jv7TtoIYzEjqjKDHIx3BnXII6Z5qT9pr/AIKP+Bf2TPFen6L4jh1q/wBS1SIXa2+lxpO0EJbaGfdIgGeccknBwDg4+Ov+Cf8Aolj+zl+2xp8eoOlpZL8Nf7S1CWT5QnnxwXUm4n7u0dSem2vEv2kvE13+0Hb+OPjBqULiPxP4ij8P+HLcqVxDEhfzOem2OOJCo/imbvXsU8qoPENJfu7aep+W1PEvOKWRRleCxbm01bRU1az/ABP2I+APxj0/9ov4R6P4y0e31Oz0nXIPtFrHfIsdwBuZcsoJxnGRyeKtfFT4l6J8IvCt9rmvapb6XpOlxiW6vJ3KrACQAPlBYsSQAo5OeKr/ALM/gdfhl8B/B3h4JsbSNGtbZuNoZxEobj/eUn8a8Q/4Kx/ATxR8f/2X5rLwbDJqWpWOpW+pT2cDkSXkCRTRsihc7j+8Dbe+31FeHSo05Yr2e0b9T9exmOxlHIni6dN1ayhzWWl3p2OTT/gtn8F/+EqGmtH4sCibyvtZ0pBC/ON3l+a02M46xhvavq/4X/ErQ/it4K0/xF4d1K31bR9UQy2tzAxdZFBwevIIbIIPIIr89/2e/wBqX4F+M/g2vwe+J3gyL4f6hHpw0qea602KOIN9xZt7KZIZt5VsyLjdg17Nrt14P/4JQ/sm3V1oOr6/4qtdSvBdaTbXt5C7ahdPDuwssUcapGFQSOy8EZAJLYPfisFTuoUYtN9Xqn6WPjuHeK8dUUsbja9KdCMG5ct4yptfZcXq/wDM+xJZMBWVl6gYJ5Y1U1XVTaQbmh/iCgE4JJ4GD2OTXwFp3xd/a08QfB2b4uW+peB9P0CG0Orp4YOntvnsgofIfZ5nzLvYKZQw+XI549E8NftYeLv2pv2EtS+IXgfUtF8I+LNA3pqrX0RntbVbVBNcCMYYAvGy7WYNgOfrXFUy6ora9bHvUeOsFWfLGFSP7t1IXh8cVvbXf1tobnxK/wCCrvw3+GfxWu/Cc0HivXNS0uc2t9caLpomtbaXzBE0ZdnDEq52sQCA3B5xXvFn8XfD7eNNP8PtqFvB4i1K1+2Q6a7j7YYe8kkeMqAeDz1+nH5h/wDBOX4T/GLx9YeNPiJ4O8UeGdDTUrqez1S41ex+0NdTJE8xZP3ZwqvLlgNgYdsgVpf8ExfD/wATvjX+0d4w+JNj4l02Nobj7Lr9zNaCd9TSbdI0duNmxCDFGxII+UoPWvWxGV0FeVOWsVr69j47KfELNK06U8TS93ESbgoxsowju73u2fqnDdqEXzB827azA/xZwB+OakaZiqsm1o2GRjvmvhX9kH/goFrutfso/Erxf8RtUTUdQ8E6g0aoIobRrn90BDDsjUjMko28/wB4n+Gs39gj/goN4p+Ivwh+LXiL4oavb31r4Is7W/jSK0jtMLKs+VzGBnzHjUAk/wAX4jzHltZrmT0R9jR48yudWlRlJ3qRclpso73XyPvj7UzKCu3BAIPqD0pEu5PT2r4x/Y5/aI+NXxa/Zu8afErXLdvFDXLSR+FPD1vbw2hmVCfMYvsRmUsQgy5BERPU5rzD4q/tK/tPfBb4YJ8RPEPij4f6Jbm4WH/hD/s0Ul3almA8s4ZmcgEFtsoIGSRgHDo5ZVqS5EzLE+IWAw+FhjpUqjhKLknZJKK01V/uP0ckm3ljIvyqMk5+77n8jUrJBEnKhfc9BXyD+0T+2nrnh3/gnponxT0Ty9E8TeKI7JLGFts0dtNM+Z2CMNrDy0ldc7mPY4Jrzv4RftV/Hzxx4Q8K/EDWP7M8OfDDRrNNR1/Wbm1g+1+II0QSMYoSmQrnEKMmM/KwJ7zTy2q6ftb9bHRieOMDQxP1OTlKXJGpfl0UZa627I/QJIo7ZRna3OCT9cY/OpLZI3k2nymx2/iH1/I/lX55+Af2g/2kv2yNC1bxz8PZvCvgnwjptxLFplreW6z3WqKhy8e943IY4ZWfIUswwRg19Af8E2P2x779sH4Yalea5p9npviXw3ef2fqEdsu2GXI3JIgJJXd8wZSeCmcAGqxGBqU4cz+ZtlPHGX5lilh6XMnUXNByjZTit3F36dmfS2wD+FaKdRXmn2R8FfH/AP4KH/ED9kL9q640nx1oIu/hVdRtLYXOnab/AKQIii7cyyS7HKyBwUwpwynPAB+c/wBu/wDaR8E/t9634f0v4XeCdXvPHf2wq+rGwFvM0ZjYCIhGd2AyH3Njb5XHBOP1l8QeD9P8U6e1rqNha39m3BguLdZIyP8AdYH8qoeEvhV4f8Ds39iaFpOjl/vmysYrfeffavNethMfQpRvCDUl56H5fm3BOaY7mwtXFKdCTv70U5JXvZPofnN/wUm0m/13xV+zf8F7y9jutbjhs472R5d/mzP9ntt5HU/dlfJ7ZPSrH/BYX4NNpHx3+HnjDVtN1K5+HtvYW+k6g1jgSWASd2bHyN5eY2yGABzFgHrX6L6j8OdF1TxFaatcaNpc+pWZUQXclmrTxbTlcOfmGKuX3hm31Swa1uYIby3m+SaO4iEiSrySCDwRz0NVRzZwlBqOyd/mPH+HcMTRxMZ1nepKDjpeygtFbzPyi0r4W/syfEn4r+G/C3gyb4wePrjWSA9xpmosiaYSwAaTzkQ8BmLNyoA55Irvvj5o1j8Vf+Ctvwt8B2axy6P4Ds7KLyXYN8tuj3cgYf3sKgP4V+hnhb4ZaH4EilXRdF0/SI5id6WNqkAz0zhNv8iaW1+Gei23ip9cj0XSIdYkZvNvo7GNbiUMApzJt3nKjGCcdPaq/tJOTl5P8TKPh/OVCNGpKEG6kZScY7qGqje99fPQ+AP28Z4vjv8A8FTPhL4DZkmtNGW3kvbckEKXka5l4940iH5eop3/AAU8kj+OH7ePwZ+GEMo8mOa2mvIEYboxPdKZOOvEELH6V+gEfwy0T/hLP7e/sTSf7a27W1H7Gguz8u3/AFn3iNuBg8flTbz4Y6He+K4dek0PSJNYhChb5rFPtSgAgASfe45H406eaKm6bj9iLj95rjOB62IhiOaqv39WM3ZbRi17i9T8z/8AgpR8HtN8Jft+WXib4gQ65B8L/EkFtb3Gp6c5RrVo4DHy21tu1txKDkgg9qj+FXwU/Zw+L/7Rul+FfBMPxc8ZQqI7t9Vtbwpp9qw+8ZVaOPYowuTjklR35/UK98MWviTTDbahZ2t1bSZWaGeESJIvoQRz+ORVXw38OtH8D2v2bRdJ0/SoWbLR2dnHArN6nYgHt0/GojnCdKCad0miJeHDWPqVoyg4TnztOF3p9lO9rdbtH5+RPH8ev+C3MnzLfab4DswxikIb/UWyqGwPu4ubgEHoSp9Kd+3qzfHL/gpv8Hvh7n7RZ6GtveXkRPBMk5uXDr1w0dvGD9TX3/YfC7QtG8RXGsWGiaTZ6peDbc3UFmkdxOMgkNIoVmyQDgkjIHHFB+Ffh1vGH9v/ANg6T/bjgRnUPsMX2oAcKPMxuwBx170RzJKcZW1jFxXzOifAtaeFq0XVV6tVVJO26j9k+K/+CgPx38Fy/HfT/hz8Z/h3JF4BYfaLPxWksoZCI1w6GL5lAkLIy8/wkjivAf2adFsfBv7fPhXS/wBnjxV4q8T+FfMF1rj3UckdtFbnHnK+5VUqECBWZQ3mMoB55/VrxD4I0vxjpf2PVtMsdSswf+Pe6tknh/75dSKb4R+G2i+BIfs+i6Ppekwt8zJZ2sduhPb5UUD9amjmUadFwfUyzDgGrisyWMdRcqlGSai41IqP2VJNKUX5ovXIYWEzKv75VYDapAzjj9MdOM5r83/Gmg6b+1P/AMFooNBvre01jQ/BNgkVxZzos0LpDAWO5CrAqZrhRzgbhjOeD+lVwDtwFLc8+n8jWHpXwz0LQvE82s2eh6PaardhknvIbKOO4mBIJ3SBQxHA4J649K5cHilQ52t5I+n4m4flmsKFGUlGnCcZyTV+a3Q5jw1+yl8NfAupx3eh/D7wTpF1GSEnstFt4JF6dNqD0B544r4f/wCC7vxHWPSfAPhF5vJa6vLrVZ1ICsI4wsMRI3KOPMb9T71+kXl/LhQ3y5ByOtc54m+EPhnxzexTa34b0TV5oV2xSXunxTtGpP3QWBOKrC4z2VZVa7cl0RjxNwvHH5XVy7BctHnttFa7PWx8d+Dv+C1HwQ8FeDtL0e1t/GS2el2cNjCf7NiwiIqxjrJnsvb1ryr/AIKofG2z/ak0H4J6L4b+2W1j48uJNXihu4vKuNszpbW7Mm49Q8hHHIGQetfoLJ+zf4BjPy+BvCKvn5GGi2/yn1Py1oN8FvDF1dafPJ4b0F5NJRVsmbTYd1oqksixnb8gVskY6E11RxWFp1vbRg7+vkeBi+GM+xmAnl+MxcJQfIrRg07Jpu7v2Vj8r/8AgqlomqeG/wBukeH/AAo0kF54i8Nabo0FtDnddJK7RGEY5w3lIpx0DV0X7UnwesfC3x4/Zz+A+mzRyW+iiC5v2B5uLi5ulkndh1/5YuQT0Dkdq/TXVfhfoPiPxJba1feH9Ju9Wt9ojvJrKKS4i2nKYkZdwwSSMdDT5vhtod54qh1ybQ9Jk1mBdkd+9mjXMYHQCTaGwMtx71Uc6fsqcbapO/r0Z5lbwudXEYmrGskq04yVl8MItNx+djSTd5Hl4KndtTGV2gYA6A9/0Jr47/bb/bR+JH7Gvx+8OvcaPY6l8K9SjQXFymnzSXqS/OZEE3m7Ax4ZQyjIVueDX2cEw4O1tvPGP1qC90e31mzlhureO5hkUo0c0QcMp6gg8Ee1ebQqwp1OeaumfoWe5bXx2E9jhKzoyummuy6PyZ+WH7fP7cXwr/bN+HVvonhHwTr2q+PLi5iFjfTaZHFPCN2WjVo2Z5NwBXbjA3Fv4a1v2yf2UPH2h/8ABNj4U299bXWqXvgeaS51a0KmdreK43mIMDyywBkQkdOvQGv0Y8K/BDwr4H1RrzRfDOhaTPIpV5LOwit3bJBOSqZPIHftXSXGniZSpj+VuTkAK/bBGc/nx+lel/a6pqFOitIu58NHw6xGMlicRmVaPtasOROCtHdNNrq7rU/Pv42/8FQ/Afi79klfDvgSfVNS8aeJ9HGiW+jWlhKJbGSSMRSSMNu1vLXO1VyT6c1l3fw41T9h3/gjl4m03W4/7J8QeMJS01qX/wCPU3TJGIQ3dvs8WWHUFiO1fe2k/B/wzoOuS6hYeG9DsdRclpLmDT4kkkJIOS+3dn8a0vFvgrS/Gej/AGTWNLsdYtQ4m+zXtslxGXUHadrAgH36isZY6K5YU1ZXuztXBmNryli8ZiIuqqTpQ5Y2jG+7a6tnxf8As3aHefAr/gjvqeradbXE2sXmg6lqqrBEXkklmLqjqBzwgTn+6c9Kzv8Agh3478JxfBHVvDGn6pHN4wuL2XVr63EUrFbZfJgiJkI2YKqvAOSXOOhr7psfDFrpulR6dZ2drZ2MKeVHDDGqxxJ02qu3bjHbpWb4X+E3h3wVfzXWk6Do+l3N0AbiazsY4JJwCCNxRQWwR06VVXMlUjUVvjfN9x24Tg2eGxmExFOolGhTdNxto77uPZn5AeHvhjq/xK/bI8VfArT5Gt/Dmq+O59T1dI+CllbTSglj/CpiY7c8Fmj9RV34z+ANa179uvx/8FfCDR6bp/jjxNpyTRwfdgtrWHzFbaP4EEzyEdCUUd6/XSw+GOh6T4huNWt9F0u31S6DGa+hskjuJtxBIaQfMw4GQepA9Kba/C/QrTxO2troulJrD5D6gtkgu3LAKT5gG4jbgHPpXUs7fN8PQ+Rl4Tc9NwlVd3Pm5k7NR1vTT7O58N/8FabLXP2c/wBk/wCH/hHwU+oaF4JtZf7M1OSwLK3kpCESKRxgbXUyE7sh2wD3I+R/2s9O+BOmfDnwrp/wnj1fWL68lxqHiHUnuAkY+YfZlL7Y2YMxZgikIEUA4Jr9qNX8PWviPSZrHUrOG9tpsCSGeASxOB0ypHPY49qyZ/gn4VutHh0248LeHZtOtnMkVqNMi8lHI5ZU2lQTnr161lhc4jQipNa3/M9TPvDmpj68506ijTlCEYxcW3BR6LWyT72ufnt/wVZtV034efAP4L2MwWSdoVMcbBSSiRW0T7RzyXlOfQN6Gvqz9tL4D3vjD9hPxB4H8J2cRuLbRoIbKyRRtZbaSN9g6dVTGB3Ir2fUvhVoOtapa3l9oej3l9Y8W9zNYxNJAAdwCNtyAG54raitmDE/N8pzznr3IH+e9YVMw0go/Zdz28HwUqdbFyr1U/bQjCNlqoxVj8Xfg3pn7O2j/Au6k+IOqfEbS/iFoayQ3GgWl08LXjoxaMRL5OxCylQdxHzAg5r9Ff8AgmJ8EfB/w1+DE2teENF8YaDa+KpUnkt/EckTXLeWCqsoj+XaQTz1Ne36h8JfDepeJYtVuPD+izamp3Levp0T3KN6iUjINdFaxbJhwflGMkUYvMJVoWfU5+F+B/7LxCqzcJciaTjCz16ybe/poXKKN1FeWfoh/9k="/>
    </div>
  </xsl:template>

  <xsl:template name="printHeader">
    <div align="right">
      <a  href="#Search Criteria Used" class="criteriaLink">
        <xsl:value-of select="$criteria_count"/> Search Criteria Used
      </a>
    </div>
  </xsl:template>

  <xsl:template name="printSearchCriteria">
    <l class="sectionHeading">
      <b>
        <a name="Search Criteria Used"></a>
        <xsl:value-of select="$criteria_count"/> Search Criteria Used
      </b>
    </l>
    <xsl:call-template name="SearchCriteria">
      <xsl:with-param name="occStr" select="$search_criteria"/>
    </xsl:call-template>
    <P>
      <a href="#Top" class="criteriaLink">Go to top of page</a>
    </P>
  </xsl:template>

  <xsl:template name="SearchCriteria">
    <xsl:param name="occStr"/>
    <xsl:if test="$occStr!=''">
      <xsl:choose>
        <xsl:when test="contains($occStr,'#')">
          <xsl:variable name="occid" select="substring-before($occStr,'#')"/>
          <xsl:variable name="newid" select="substring-after($occStr,'#')"/>

          <xsl:call-template name="SearchCriteria">
            <xsl:with-param name="occStr" select="$occid"/>
          </xsl:call-template>

          <xsl:call-template name="SearchCriteria">
            <xsl:with-param name="occStr" select="$newid"/>
          </xsl:call-template>
        </xsl:when>
        <xsl:otherwise>
          <li class="propertyValue">
            <xsl:value-of select="$occStr" />
          </li>
        </xsl:otherwise>
      </xsl:choose>
    </xsl:if>
  </xsl:template>

  <xsl:template name="printStyles">
    <xsl:variable name="renderStyle" select="crf:getRenderStyle()"/>
    <xsl:if test="$renderStyle!=''">
      <style>
        <xsl:value-of select="$renderStyle"/>
      </style>
    </xsl:if>
  </xsl:template>
</xsl:stylesheet>
