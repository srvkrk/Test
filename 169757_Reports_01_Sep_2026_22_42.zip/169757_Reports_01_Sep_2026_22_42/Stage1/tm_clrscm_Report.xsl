<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40" >
    
    <xsl:output method="xml" version="1.0" indent="yes" />
    <xsl:strip-space elements="*"/>
    
    <xsl:key name="ercIndentRev" match="plm:ProductRevision[@subType='T5_clschmRevision']" use="@id"/>
    <xsl:key name="designRev" match="plm:ProductRevision[@subType='T5_ClrShmDataRevision']" use="@id"/>
    
    <xsl:param name="indentRootId" select="substring-after(/plm:PLMXML/plm:Header/@traverseRootRefs,'#')"></xsl:param>
    <xsl:param name="indentNode" select="key('ercIndentRev',$indentRootId)"></xsl:param>
    
    <xsl:key name="releasestatus"       match="plm:ReleaseStatus"   use="@id"/>
    
    
    <xsl:template match="/">
        <xsl:call-template name="ReportHeader"></xsl:call-template>        
    </xsl:template>
    
    <xsl:template name="ReportHeader">
        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">
            
            
            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="11" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <!--<Alignment ss:Horizontal="Right"/>-->
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="PropertyNameCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                </Style>                
            </Styles>
            
            <Worksheet ss:Name="Sheet1">
                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="30"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="180"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/><!--Column 5-->
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="120"/>
                    <Column ss:AutoFitWidth="0" ss:Width="120" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="110" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/><!--Column 10-->
                    <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
                    
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s21" ss:MergeAcross='3'>
                            <Data ss:Type='String'>TATA MOTORS PUNE</Data>
                        </Cell>                        
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>                       
                        <Cell ss:StyleID="s21" ss:MergeAcross='3'>
                            <Data ss:Type='String'>Engineering Research Center</Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>       
                        <Cell ss:StyleID="s22" ss:MergeAcross='3'>
                            <Data ss:Type='String'>COLOUR SCHEME REPORT</Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Report Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String'><xsl:call-template name="sortReportDate"><xsl:with-param name="inRepDate" select="plm:PLMXML/@date"></xsl:with-param></xsl:call-template></Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row></Row>
                    <Row>
                        <Cell></Cell>
                        <!--<Cell>
                            <Data ss:Type='String'>Indent Name:</Data>
                        </Cell>
                        <Cell>
                            <Data ss:Type='String'><xsl:value-of select="$indentNode/@name"/></Data>
                        </Cell>-->
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>SCHEME</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String'><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='object_string']/@value"/></Data>
                        </Cell>
                        <Cell></Cell>
                        <Cell></Cell>   
                        <Cell></Cell> 
                        <!--<Cell></Cell>--> 
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>SCHEME DESC</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String'><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5_ClSchmDesc']/@value"/></Data>
                        </Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                               <Data ss:Type='String' >Creation Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='creation_date']/@value"/></Data>
                        </Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell> 
                        <!--<Cell></Cell>-->
                        <Cell ss:StyleID="s26">
                                <Data ss:Type='String'>Last Modified Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='last_mod_date']/@value"/></Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                               <Data ss:Type='String' >Vehicle Number</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5_VehNO']/@value"/></Data>
                        </Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell> 
                        <!--<Cell></Cell>-->
                        <Cell ss:StyleID="s26">
                                <Data ss:Type='String'>Release Status</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <!--Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='release_status_list']/@value"/></Data-->
							<Data ss:Type="String"><xsl:call-template name="getReleaseStatus"><xsl:with-param name="releaseList" select="$indentNode/plm:UserData/plm:UserValue[@title='release_status_list']/plm:UserList/plm:Item"/><xsl:with-param name="separator" select="';'"></xsl:with-param></xsl:call-template></Data>
                        </Cell>
                    </Row>
					<Row>
                        <Cell></Cell>
                        <Cell ss:StyleID="s26">
                               <Data ss:Type='String' >Color Serial</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5_ClSrl']/@value"/></Data>
                        </Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell> 
                        <!--<Cell></Cell>-->
                        <Cell ss:StyleID="s26">
                                <Data ss:Type='String'>Platform Of Scheme</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String' ><xsl:value-of select="$indentNode/plm:UserData/plm:UserValue[@title='t5_SchmPlant']/@value"/></Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row></Row>
                    <Row></Row>
                    <Row>
                        <Cell></Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Sr. No.</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>COMP CODE</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Color Serial</Data>
                        </Cell>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Category</Data>
                        </Cell> 
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Internal Scheme</Data>
                        </Cell>
                    </Row>
                    <xsl:call-template name="generateIndentPartsList"></xsl:call-template>
                    <Row></Row>
                    <Row></Row>
                    <Row>
                        <Cell></Cell>
						<Cell></Cell>
						<Cell></Cell>
						<Cell></Cell>
						<Cell></Cell>
                        <Cell 
                            ss:StyleID="s24" ss:MergeAcross='1'>
                            <Data ss:Type='String'>Thank You</Data>
                        </Cell>
                     </Row>
                    <Row></Row>
                    
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    
    <xsl:template name="generateIndentPartsList">
        <xsl:for-each select="/plm:PLMXML/plm:GeneralRelation">
            <xsl:variable name="indentPartRef" select="substring-after(@relatedRefs,' ')"/>
            <xsl:variable name="DesignPartNode" select="key('designRev',substring-after($indentPartRef,'#'))"/>
            <Row>
                <Cell></Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='Number'><xsl:number value="position()" format="01"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="$DesignPartNode/plm:UserData/plm:UserValue[@title='object_string']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="$DesignPartNode/plm:UserData/plm:UserValue[@title='t5_ClSrl']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="$DesignPartNode/plm:UserData/plm:UserValue[@title='t5_SchmCategory']/@value"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="$DesignPartNode/plm:UserData/plm:UserValue[@title='t5_InternalSchm']/@value"/></Data>
                </Cell>
            </Row>
        </xsl:for-each>
    </xsl:template>
    
    <xsl:template name="replaceText">
        <xsl:param name="actualString" />
        <xsl:param name="findString" />
        <xsl:param name="replaceString" />
        <xsl:choose>
            <xsl:when test="contains($actualString, $findString)">
                <xsl:value-of select="substring-before($actualString, $findString)" />
                <xsl:value-of select="$replaceString" disable-output-escaping="yes" />
                <xsl:call-template name="replaceText">
                    <xsl:with-param name="actualString" select="substring-after($actualString, $findString)" />
                    <xsl:with-param name="findString" select="$findString" />
                    <xsl:with-param name="replaceString" select="$replaceString" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$actualString" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    
    <xsl:template name="sortDate">
        <xsl:param name="inDate" />
        <xsl:if test="string-length($inDate)&gt;1">
            <xsl:variable name="datebit1" select="substring-before($inDate,'T')"/>
            <xsl:variable name="datebit2" select="substring-after($datebit1,'-')"/>
            <xsl:variable name="yearbit" select="substring-before($datebit1,'-')"/>
            <xsl:variable name="monthbit" select="substring-before($datebit2,'-')"/>
            <xsl:variable name="daybit" select="substring-after($datebit2,'-')"/>
            <xsl:variable name="timebit1" select="substring-after($inDate,'T')"/>
            <xsl:variable name="timebit2" select="substring-after($timebit1,':')"/>
            <xsl:variable name="hourbit" select="substring-before($timebit1,':')"/>
            <xsl:variable name="minbit" select="substring-before($timebit2,':')"/>
            <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit,'  ')"/>
        </xsl:if>
    </xsl:template>
    
    <xsl:template name="sortReportDate">
        <xsl:param name="inRepDate"/>
        <!--<xsl:variable name="inRepDate" select="plm:PLMXML/@date"/>-->
        <xsl:variable name="datebit1" select="substring-after($inRepDate,'-')"/>
        <xsl:variable name="yearbit" select="substring-before($inRepDate,'-')"/>
        <xsl:variable name="monthbit" select="substring-before($datebit1,'-')"/>
        <xsl:variable name="daybit" select="substring-after($datebit1,'-')"/>
        <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit)"/>
    </xsl:template>
	
	<xsl:template name="getReleaseStatus">
        <xsl:param name="releaseList"/>
        <xsl:param name="separator"/>        
        <xsl:for-each select="$releaseList">
            <xsl:variable name="statusElement" select="key('releasestatus',@value)"/>
            <xsl:choose>
                <xsl:when test="$statusElement/@name='T5_LcsErcRlzd'"><xsl:value-of select="'ERC Released'"/></xsl:when>
                <xsl:when test="$statusElement/@name='T5_LcsReview'"><xsl:value-of select="'ERC Review'"/></xsl:when>
                <xsl:when test="$statusElement/@name='T5_LcsWorking'"><xsl:value-of select="'ERC Working'"/></xsl:when>
                <xsl:otherwise><xsl:value-of select="$statusElement/@name"/></xsl:otherwise>
            </xsl:choose>            
            <xsl:if test="position()!=last()">
                <xsl:value-of select="$separator"/>
            </xsl:if>
        </xsl:for-each>
    </xsl:template>
    
</xsl:stylesheet>