#include<stdio.h>
#include<tc/tc_startup.h>
#include<tcinit/tcinit.h>
#include<tccore/item.h>
#include<tccore/aom_prop.h>
#include<tccore/tctype.h>
#include<sa/user.h>
#include<sa/role.h>
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
int i_row_cnt = 0;
static int report_error(char* file, int line, char* function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int* severities = 0;
		const int* ifails = 0;
		const char** texts = NULL;

		EMH_ask_errors(&n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for (index = 0; index < n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

void OUTI(const char* text, const unsigned pos, const unsigned len, int i_str)
{
	printf("%*.0s",pos,text); printf("%-*s : [%d]\n",len,text,i_str);fflush(stdout);
	TC_write_syslog("%*.0s", pos, text); TC_write_syslog("%-*s : [%d]\n", len, text, i_str); fflush(stdout);
	return;
}
void OUTF(const char* text, const unsigned pos, const unsigned len, float f_str)
{
	printf("%*.0s",pos,text); printf("%-*s : [%f]\n",len,text,f_str);fflush(stdout);
	TC_write_syslog("%*.0s", pos, text); TC_write_syslog("%-*s : [%f]\n", len, text, f_str); fflush(stdout);
	return;
}

void OUTS(const char* text, const unsigned pos, const unsigned len, char* str)
{
	printf("%*.0s",pos,text); printf("%-*s : [%s]\n",len,text,str);fflush(stdout);
	TC_write_syslog("%*.0s", pos, text); TC_write_syslog("%-*s : [%s]\n", len, text, str); fflush(stdout);
	return;
}
int get_current_user_Details()
{
	tag_t role_tag = NULLTAG;
	char* rolename = NULL;
	char* user_id_string = NULL;
	tag_t user_tag = NULLTAG;
	printf("\nget_current_user_Details");
	POM_get_user_id(&user_id_string);
	OUTS("user_id_string", 10, 30, user_id_string);
	POM_get_user(&user_id_string, &user_tag);

	SA_ask_current_role(&role_tag);
	SA_ask_role_name2(role_tag, &rolename);
	OUTS("rolename",10,30, rolename);
	return 0;
}
int dfc_tct_report(char *dfc_tct_item_id)
{
	tag_t dfc_tct_item_tag = NULLTAG;
	tag_t dfc_tct_item_tag_type = NULLTAG;
	char* dfc_tct_item_tag_type_name = NULL;
	const char* Query_name = "tm_TCT_Table_row_qry1";
	tag_t table_row_qry_tag = NULLTAG;
	tag_t *result_tbl_row_objects = NULL;
	int n_tbl_row_entries = 2;
	//const char** tbl_row_entries = { "ID","Module Address"};
	//const char** tbl_row_values = {"TCT-5445-000220","B*"};
	char** tbl_row_entries = NULL;
	char** tbl_row_values = NULL;
	int n_tbl_row_found = 0;
	int i_row_counter = 0;

	tag_t dfc_tct_table_row_Tag = NULLTAG;
	int i_t5_Level = 0;
	char* s_t5_Module = NULL;
	char* s_t5_ModuleAddress = NULL;
	char* s_t5_Applicability = NULL;
	char* s_t5_PMXU = NULL;
	char* s_t5_ModuleNumber = NULL;
	char* s_t5_ChangeRemark = NULL;
	double d_t5_TargetDMC = 0.000f;
	double d_t5_TrgtToolCpx = 0.000f;
	char* s_t5_CstMgrRemark = NULL;
	double d_t5_TargetCost = 0.000f;
	char* dfc_tct_item_id_q = NULL;

	double d_t5_TrgtToolCpxRolledup = 0.000f;
	double d_t5_Core_target_dmc = 0.000f; 
	double d_t5_Core_target_tool_cst = 0.000f;
	double d_t5_adj_bnchmrk_trgt_dmc = 0.000f;
	double d_t5_adj_bnchmrk_tool_cst = 0.000f;

	char* dfc_tct_object_name = NULL;
	char* dfc_tct_t5_Platform = NULL;
	char* dfc_tct_t5_ProjectCode = NULL;
	char* dfc_tct_t5_ProjectDescription = NULL;
	char* row_uid = NULL;
	char* dfc_tct_uid = NULL;
	tag_t dfc_tct_item_tag_rev = NULLTAG;
	char* dfc_tct_rev_uid = NULL;

	//char File_path[300] = { "C:\\Siemens\\TCUA12_2Tier\\codes\\custom_report\\DFC_TCT\\TC_CUSTOM_RPT\\TC_CUSTOM_RPT.xml" } ;
	char File_path[300] = { "/tmp/TC_CUSTOM_RPT.xml" } ;
	FILE* fp = fopen(File_path,"w");


	tag_t role_tag = NULLTAG;
	char* rolename = NULL;
	char* session_user_id_string = NULL;
	char* user_id_string = NULL;
	tag_t user_tag = NULLTAG;
	printf("\nget_current_user_Details\n");
	POM_get_user_id(&session_user_id_string);
	OUTS("user_id_string", 10, 30, user_id_string);
	POM_get_user(&user_id_string, &user_tag);

	printf("\nuser_id_string 1: [%s]", user_id_string);
	printf("\nsession_user_id_string 2: [%s]", session_user_id_string);
	printf("\nusession_user_id_string 3: [%s]", session_user_id_string);

	SA_ask_current_role(&role_tag);
	SA_ask_role_name2(role_tag, &rolename);
	OUTS("rolename", 10, 30, rolename);

	//get_current_user_Details();
	//--------------------------------------------------------------------------------
	printf("\nquerying : [%s]", dfc_tct_item_id);
	ITEM_find_item(dfc_tct_item_id, &dfc_tct_item_tag);

	AOM_ask_value_string(dfc_tct_item_tag, "item_id", &dfc_tct_item_id_q);
	printf("\ndfc_tct_item_id_q : [%s]", dfc_tct_item_id_q);


	AOM_ask_value_string(dfc_tct_item_tag, "object_name", &dfc_tct_object_name);
	printf("\ndfc_tct_object_name : [%s]", dfc_tct_object_name);

	AOM_ask_value_string(dfc_tct_item_tag, "t5_Platform", &dfc_tct_t5_Platform);
	printf("\ndfc_tct_t5_Platform : [%s]", dfc_tct_t5_Platform);


	AOM_ask_value_string(dfc_tct_item_tag, "t5_ProjectCode", &dfc_tct_t5_ProjectCode);
	printf("\ndfc_tct_t5_ProjectCode : [%s]", dfc_tct_t5_ProjectCode);


	AOM_ask_value_string(dfc_tct_item_tag, "t5_ProjectDescription", &dfc_tct_t5_ProjectDescription);
	printf("\ndfc_tct_t5_ProjectDescription : [%s]", dfc_tct_t5_ProjectDescription);


	//Qry_DFC_Uname_Role
	char* VMT_role_name = NULL;
	tag_t uname_role_qry_tag = NULLTAG;
	int n_entries_role = 2;
	char** entries_role = NULL;
	char** values_role = NULL;
	int n_found_role = 0;
	tag_t* roll_result_values = NULL;

	entries_role = (char**)MEM_alloc(n_entries_role * sizeof(char*));
	values_role = (char**)MEM_alloc(n_entries_role * sizeof(char*));
	//--
	entries_role[0] = (char*)MEM_alloc(strlen("role_name1") + 1);
	entries_role[1] = (char*)MEM_alloc(strlen("Id") + 1);

	tc_strcpy(entries_role[0], "role_name1");
	tc_strcpy(entries_role[1], "Id");

	printf("\nEntry Role 0 : [%s]", entries_role[0]);
	printf("\nEntry Role 1 : [%s]", entries_role[1]);
	//--
	values_role[0] = (char*)MEM_alloc(100);
	values_role[1] = (char*)MEM_alloc(100);

	tc_strcpy(values_role[0], dfc_tct_t5_Platform);
	tc_strcat(values_role[0], "_*_Role");
	//tc_strcpy(values_role[1], user_id_string); //old query has user name input fails when tow or more user with same name
	tc_strcpy(values_role[1], session_user_id_string);

	printf("\nValue Role 0 : [%s]", values_role[0]);
	printf("\nValue Role 1 : [%s]", values_role[1]);
	//-
	VMT_role_name = (char*)MEM_alloc(100 * sizeof(char));
	//tc_strcpy(VMT_role_name, "QryKyWrd_iUnme_oRole");//old query
	tc_strcpy(VMT_role_name, "Qry_DFC_Uname_Role");
	QRY_find2(VMT_role_name, &uname_role_qry_tag);
	if (uname_role_qry_tag == NULLTAG)
	{
		printf("\nQry_DFC_Uname_Role not found");
		return 1;
	}
	QRY_execute(uname_role_qry_tag, n_entries_role, entries_role, values_role, &n_found_role, &roll_result_values);
	printf("\nRoles found : [%d]", n_found_role);
	if (n_found_role <= 0)
	{
		printf("\nUser not found in VMT group hence exit");
		return 1;
	}
	int role_index = 0;
	char* vmt_role_Name = NULL;
	tag_t tRole_name = NULLTAG;
	//char** Role_module_address = NULL;
	char* tok_mod_addr = NULL;
	char* all_module_address = NULL;
	printf("\n");
	//Role_module_address = (char**)MEM_alloc(n_found_role * sizeof(char*));


	all_module_address = (char*)MEM_alloc(200 * sizeof(char));
	tc_strcpy(all_module_address, "");
	for (role_index = 0; role_index < n_found_role; role_index++)
	{
		//Role_module_address[role_index] = (char*)MEM_alloc(50 * sizeof(char));
		SA_ask_groupmember_role(roll_result_values[role_index], &tRole_name);
		SA_ask_role_name2(tRole_name, &vmt_role_Name);
		//AOM_ask_value_string(roll_result_values[role_index], "role", &vmt_role_Name);
		OUTS("vmt_role_Name", 10, 30, vmt_role_Name);

		tok_mod_addr = strtok(vmt_role_Name, "_");
		tc_strcat(all_module_address, strtok(NULL, "_"));
		tc_strcat(all_module_address, "*;");

		//strcpy(Role_module_address[role_index], strtok(NULL, "_"));

		
	}
	OUTS("TOKENIZED Module address from Role", 10, 30, all_module_address);
	//--------------------------------------------------------------------------------

	//-

	TCTYPE_ask_object_type(dfc_tct_item_tag, &dfc_tct_item_tag_type);
	TCTYPE_ask_name2(dfc_tct_item_tag_type, &dfc_tct_item_tag_type_name);
	printf("\ndfc_tct_item_tag_type_name : [%s]", dfc_tct_item_tag_type_name);


	tbl_row_entries = (char**)MEM_alloc(n_tbl_row_entries * sizeof(char*));
	
	size_t id_len = 0;
	id_len = tc_strlen("ID");
	tbl_row_entries[0] = (char*)MEM_alloc(id_len * (sizeof(char *)));
	tbl_row_entries[1] = (char*)MEM_alloc(strlen("Module Address") + 1);
		
	tc_strcpy(tbl_row_entries[0], "ID");
	tc_strcpy(tbl_row_entries[1], "Module Address");

	printf("\nEntry 0 : [%s]", tbl_row_entries[0]);
	printf("\nEntry 1 : [%s]", tbl_row_entries[1]);


	tbl_row_values = (char**)MEM_alloc(n_tbl_row_entries * sizeof(char*));

	tbl_row_values[0] = (char*)MEM_alloc(strlen(dfc_tct_item_id) + 1);
	tbl_row_values[1] = (char*)MEM_alloc(100 * sizeof(char));

	tc_strcpy(tbl_row_values[0], dfc_tct_item_id);
	//tc_strcpy(tbl_row_values[0], "TCT-5445-000220");
	//tc_strcpy(tbl_row_values[1], "B1*"); 
	tc_strcpy(tbl_row_values[1], all_module_address);
	
	printf("\nvalue 0 : [%s]", tbl_row_values[0]);
	printf("\nvalue 0 : [%s]", tbl_row_values[1]);

	TC_write_syslog("\nvalue 0 : [%s]", tbl_row_values[0]);
	TC_write_syslog("\nvalue 0 : [%s]", tbl_row_values[1]);

	//--




	printf("\nfind : [%s]", Query_name);
	QRY_find2(Query_name, &table_row_qry_tag);

	printf("\nReport generated at File_path : [%s]", File_path);
	//fprintf(fp,"\n<th>Level</th> <th>Module</th> <th>ModuleAddress</th> <th>Applicability</th> <th>PMXU</th> <th>ModuleNumber</th> <th>ChangeRemark</th> <th>TargetDMC</th> <th>TrgtToolCpx</th> <th>CstMgrRemark</th> <th>TargetCost</th>");
	fprintf(fp, "<?xml version=\"1.0\" encoding=\"utf-8\"?>");
	fprintf(fp, "\n<!-- GENERATED BY: PLM XML SDK 7.0.8.041 -->");
	//username session user
	//date	YYYY-MM-DD
	//time  TT:MI:SS
	//fprintf(fp, "\n<PLMXML xmlns=\"http://www.plmxml.org/Schemas/PLMXMLSchema\" language=\"en-us\" time=\"18:46:28\" schemaVersion=\"6\" author=\"Teamcenter V12000.2.7.70_20200304.00 - infodba@IMC--1777531652(-1777531652)\" date=\"2022-02-10\" languages=\"en-us\">");

	fprintf(fp, "\n<PLMXML xmlns=\"http://www.plmxml.org/Schemas/PLMXMLSchema\" \
	language=\"en-us\" time=\"18:46:28\" schemaVersion=\"6\" author=\"Teamcenter V12000.2.7.70_20200304.00 - infodba@IMC--1777531652(-1777531652)\" date=\"2022-02-10\" languages=\"en-us\">");
	fprintf(fp, "\n<Header id=\"id1\" traverseRootRefs=\"#id2\" transferContext=\"RUNTIME_TRANSFER_MODE\"></Header>");

	//T5_DFC_TCT
	fprintf(fp, "\n<Product id=\"id514\" name=\"%s\" subType=\"%s\" accessRefs=\"#id511\" productId=\"%s\">", dfc_tct_item_id_q, dfc_tct_item_tag_type_name, dfc_tct_item_id_q);

	fprintf(fp, "\n<Description>%s</Description>", dfc_tct_t5_ProjectDescription);

	ITK__convert_tag_to_uid(dfc_tct_item_tag, &dfc_tct_uid);
	fprintf(fp, "\n<ApplicationRef application=\"Teamcenter\" label=\"%s\" version=\"%s\"></ApplicationRef>", dfc_tct_uid, dfc_tct_uid);


	fprintf(fp, "\n<UserData id=\"id515\">");

	
	fprintf(fp, "\n<UserValue title=\"user_id\" value=\"%s\"></UserValue>", session_user_id_string);
	fprintf(fp, "\n<UserValue title=\"rolename\" value=\"%s\"></UserValue>", rolename);

	fprintf(fp, "\n<UserValue title=\"item_id\" value=\"%s\"></UserValue>", dfc_tct_item_id_q);

	fprintf(fp, "\n<UserValue title=\"object_name\" value=\"%s\"></UserValue>", dfc_tct_object_name);

	fprintf(fp, "\n<UserValue title=\"t5_Platform\" value=\"%s\"></UserValue>", dfc_tct_t5_Platform);

	fprintf(fp, "\n<UserValue title=\"t5_ProjectCode\" value=\"%s\"></UserValue>", dfc_tct_t5_ProjectCode);

	fprintf(fp, "\n<UserValue title=\"t5_ProjectDescription\" value=\"%s\"></UserValue>", dfc_tct_t5_ProjectDescription);

	fprintf(fp, "</UserData>");

	fprintf(fp, "</Product>");

	
	ITEM_ask_latest_rev(dfc_tct_item_tag, &dfc_tct_item_tag_rev);
	ITK__convert_tag_to_uid(dfc_tct_item_tag_rev, &dfc_tct_rev_uid);

	//T5_DFC_TCTRevision
	//id=000220
	//revision=A
	fprintf(fp, "\n<ProductRevision id=\"id2\" name=\"000220\" subType=\"T5_DFC_TCTRevision\" accessRefs=\"#id511\" masterRef=\"#id514\" revision=\"A\">");
	fprintf(fp, "\n<ApplicationRef application=\"Teamcenter\" label=\"%s\" version=\"%s\"></ApplicationRef>", dfc_tct_uid, dfc_tct_rev_uid);

	int	num_to_sort = 1;
	char** keys = NULL;
	int	orders[] = { 1 };

	keys = (char**)MEM_alloc(1 * sizeof(char*));
	keys[0] = (char*)MEM_alloc(100);
	tc_strcpy(keys[0], "t5_ModuleAddress");


	if (table_row_qry_tag != NULLTAG)
	{
		//QRY_execute(table_row_qry_tag, n_tbl_row_entries, tbl_row_entries, tbl_row_values, &n_tbl_row_found, &result_tbl_row_objects);
		QRY_execute_with_sort(table_row_qry_tag, n_tbl_row_entries, tbl_row_entries, tbl_row_values, num_to_sort, keys, orders, &n_tbl_row_found, &result_tbl_row_objects);
		printf("\nNof of row found : [%d]", n_tbl_row_found);
		if (n_tbl_row_found > 0)
		{
			printf("\nDisplaying row");
			//i_row_counter
			for (i_row_counter = 0; i_row_counter < n_tbl_row_found; i_row_counter++)
			{
				AOM_ask_value_int(result_tbl_row_objects[i_row_counter], "t5_Level", &i_t5_Level);
				AOM_ask_value_string(result_tbl_row_objects[i_row_counter], "t5_ModuleAddress", &s_t5_ModuleAddress);
				AOM_ask_value_string(result_tbl_row_objects[i_row_counter], "t5_Module", &s_t5_Module);
				AOM_ask_value_string(result_tbl_row_objects[i_row_counter], "t5_Applicability", &s_t5_Applicability);
				AOM_ask_value_string(result_tbl_row_objects[i_row_counter], "t5_PMXU", &s_t5_PMXU);
				AOM_ask_value_string(result_tbl_row_objects[i_row_counter], "t5_ModuleNumber", &s_t5_ModuleNumber);
				AOM_ask_value_string(result_tbl_row_objects[i_row_counter], "t5_ChangeRemark", &s_t5_ChangeRemark);
				AOM_ask_value_double(result_tbl_row_objects[i_row_counter], "t5_TargetDMC", &d_t5_TargetDMC);
				AOM_ask_value_double(result_tbl_row_objects[i_row_counter], "t5_TrgtToolCpx", &d_t5_TrgtToolCpx);
				AOM_ask_value_string(result_tbl_row_objects[i_row_counter], "t5_CstMgrRemark", &s_t5_CstMgrRemark);
				AOM_ask_value_double(result_tbl_row_objects[i_row_counter], "t5_TargetCost", &d_t5_TargetCost);
				
				//newly added
				AOM_ask_value_double(result_tbl_row_objects[i_row_counter], "t5_TrgtToolCpxRolledup", &d_t5_TrgtToolCpxRolledup);
				AOM_ask_value_double(result_tbl_row_objects[i_row_counter], "t5_Core_target_dmc", &d_t5_Core_target_dmc);
				AOM_ask_value_double(result_tbl_row_objects[i_row_counter], "t5_Core_target_tool_cst", &d_t5_Core_target_tool_cst);
				AOM_ask_value_double(result_tbl_row_objects[i_row_counter], "t5_adj_bnchmrk_trgt_dmc", &d_t5_adj_bnchmrk_trgt_dmc);
				AOM_ask_value_double(result_tbl_row_objects[i_row_counter], "t5_adj_bnchmrk_tool_cst", &d_t5_adj_bnchmrk_tool_cst);

				



				//printf("\n%4d %40s %25s %2s %2s %30s %-30s %-3.3f %-3.3f %-30s %-3.3f", i_t5_Level, s_t5_Module, s_t5_ModuleAddress, s_t5_Applicability, s_t5_PMXU, s_t5_ModuleNumber, s_t5_ChangeRemark, d_t5_TargetDMC, d_t5_TrgtToolCpx, s_t5_CstMgrRemark, d_t5_TargetCost);
				char* d_t5_Module = NULL;
				s_t5_Module = stripBlanks(s_t5_Module);
				d_t5_Module = (char*) MEM_alloc(200);
				STRNG_replace_str(s_t5_Module, "&", "&amp;", &d_t5_Module);
				ITK__convert_tag_to_uid(result_tbl_row_objects[i_row_counter], &row_uid);

				fprintf(fp, "\n<TableRow id=\"id%d\" index=\"%d\" tablePropertyName=\"%s\" subType=\"T5_TCT_Table_Row\">", i_row_counter, i_row_counter, dfc_tct_item_tag_type_name);
				fprintf(fp, "\n<ApplicationRef application=\"Teamcenter\" label=\"%s\" version=\"%s\"></ApplicationRef>", row_uid, row_uid);
				fprintf(fp, "\n<TableColumn title=\"t5_Level\" value=\"%d\" type=\"int\"></TableColumn>", i_t5_Level);
				fprintf(fp, "\n<TableColumn title=\"t5_ModuleAddress\" value=\"%s\"></TableColumn>", s_t5_ModuleAddress);
				fprintf(fp, "\n<TableColumn title=\"t5_Module\" value=\"%s\"></TableColumn>", d_t5_Module);
				fprintf(fp, "\n<TableColumn title=\"t5_Applicability\" value=\"%s\"></TableColumn>", s_t5_Applicability);
				fprintf(fp, "\n<TableColumn title=\"t5_PMXU\" value=\"%s\"></TableColumn>", s_t5_PMXU);
				fprintf(fp, "\n<TableColumn title=\"t5_ModuleNumber\" value=\"%s\"></TableColumn>", s_t5_ModuleNumber);
				fprintf(fp, "\n<TableColumn title=\"t5_ChangeRemark\" value=\"%s\"></TableColumn>", s_t5_ChangeRemark);
				if (d_t5_TargetDMC == 0.000000)
				{
					fprintf(fp, "\n<TableColumn title=\"t5_TargetDMC\" value=\"\" type = \"real\"></TableColumn>");
				}
				else
				{
					fprintf(fp, "\n<TableColumn title=\"t5_TargetDMC\" value=\"%.3f\" type = \"real\"></TableColumn>", d_t5_TargetDMC);
				}
				if (d_t5_TrgtToolCpx == 0.000000)
				{
					fprintf(fp, "\n<TableColumn title=\"t5_TrgtToolCpx\" value=\"\" type = \"real\"></TableColumn>" );
				}
				else
				{
					fprintf(fp, "\n<TableColumn title=\"t5_TrgtToolCpx\" value=\"%.3f\" type = \"real\"></TableColumn>", d_t5_TrgtToolCpx);
				}
				
				fprintf(fp, "\n<TableColumn title=\"t5_CstMgrRemark\" value=\"%s\"></TableColumn>", s_t5_CstMgrRemark);

				if (d_t5_TargetCost == 0.000000)
				{
					fprintf(fp, "\n<TableColumn title=\"t5_TargetCost\" value=\"\" type=\"real\"></TableColumn>" );
				}
				else
				{
					fprintf(fp, "\n<TableColumn title=\"t5_TargetCost\" value=\"%.3f\" type=\"real\"></TableColumn>", d_t5_TargetCost);
				}
				//--- added new fields 
				if (d_t5_TrgtToolCpxRolledup == 0.000000)
				{
					fprintf(fp, "\n<TableColumn title=\"t5_TrgtToolCpxRolledup\" value=\"\" type=\"real\"></TableColumn>");
				}
				else
				{
					fprintf(fp, "\n<TableColumn title=\"t5_TrgtToolCpxRolledup\" value=\"%.3f\" type=\"real\"></TableColumn>", d_t5_TrgtToolCpxRolledup);
				}

				if (d_t5_Core_target_dmc == 0.000000)
				{
					fprintf(fp, "\n<TableColumn title=\"t5_Core_target_dmc\" value=\"\" type=\"real\"></TableColumn>");
				}
				else
				{
					fprintf(fp, "\n<TableColumn title=\"t5_Core_target_dmc\" value=\"%.3f\" type=\"real\"></TableColumn>", d_t5_Core_target_dmc);
				}

				if (d_t5_Core_target_tool_cst == 0.000000)
				{
					fprintf(fp, "\n<TableColumn title=\"t5_Core_target_tool_cst\" value=\"\" type=\"real\"></TableColumn>");
				}
				else
				{
					fprintf(fp, "\n<TableColumn title=\"t5_Core_target_tool_cst\" value=\"%.3f\" type=\"real\"></TableColumn>", d_t5_Core_target_tool_cst);
				}

				if (d_t5_adj_bnchmrk_trgt_dmc == 0.000000)
				{
					fprintf(fp, "\n<TableColumn title=\"t5_adj_bnchmrk_trgt_dmc\" value=\"\" type=\"real\"></TableColumn>");
				}
				else
				{
					fprintf(fp, "\n<TableColumn title=\"t5_adj_bnchmrk_trgt_dmc\" value=\"%.3f\" type=\"real\"></TableColumn>", d_t5_adj_bnchmrk_trgt_dmc);
				}

				if (d_t5_adj_bnchmrk_tool_cst == 0.000000)
				{
					fprintf(fp, "\n<TableColumn title=\"t5_adj_bnchmrk_tool_cst\" value=\"\" type=\"real\"></TableColumn>");
				}
				else
				{
					fprintf(fp, "\n<TableColumn title=\"t5_adj_bnchmrk_tool_cst\" value=\"%.3f\" type=\"real\"></TableColumn>", d_t5_adj_bnchmrk_tool_cst);
				}

				fprintf(fp, "</TableRow>");

				TC_write_syslog("\nAdded table row 29.04.2022");

				MEM_free(d_t5_Module);
			}
		}
	}
	fprintf(fp, "\n</ProductRevision>");
	fprintf(fp, "\n</PLMXML>");
	fclose(fp);
	return 0;
}
int ITK_user_main(int argc, char** argv)
{
	char* userid = NULL;
	char* password = NULL;
	char* group = NULL;
	char* dfc_tct_item_id = NULL;
	int fn_ret_stat = 0;

	userid = ITK_ask_cli_argument("-u=");
	password = ITK_ask_cli_argument("-p=");
	//group = ITK_ask_cli_argument("-g=");
	dfc_tct_item_id = ITK_ask_cli_argument("-i=");


	ITK_initialize_text_services(ITK_BATCH_TEXT_MODE);
	ITK_auto_login();
	//ITK_init_module(userid, password, "");
	ITK_set_journalling(TRUE);
	printf("\nConnected to teamcenter UA");
	TC_write_syslog("\nConnected to teamcenter UA");

	//printf("\nuserid : [%s]", userid);
	//printf("\npassword : [%s]", password);
	printf("\ndfc_tct_item_id : [%s]", dfc_tct_item_id);
	if (dfc_tct_item_id != NULL)
	{
		TC_write_syslog("\ndbk generating report function dfc_tct_report");
		fn_ret_stat = dfc_tct_report(dfc_tct_item_id);
	}
	else
	{
		printf("\ndfc_tct_item_id is NULL");
	}
	printf("\nPOM_logout\n\n");
	TC_write_syslog("\nPOM_logout\n\n");
	
	POM_logout(FALSE);
	return ITK_ok;
}
