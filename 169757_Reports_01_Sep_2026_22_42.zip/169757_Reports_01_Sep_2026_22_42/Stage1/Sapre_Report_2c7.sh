. /user/uaprodtrl/.bash_profile
echo "Spare_kit running on 2c7"
echo "In Shell Spare_kit 2c7  ...'"$1"'  '"$2"' '"$3"'  '"$4"' '"$5"' '"$6"' "
/user/uaprodtrl/Program_Shells/Reports/Spare_kit/Spare_kit_report -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -g=dba -VC="$1" -Revision="$2" -Sequence="$3" -RRForVC="$4" -ClosureVForVC="$5" -UserID="$6"
echo "END OF SPARE-KIT REPORT GENERATION"
