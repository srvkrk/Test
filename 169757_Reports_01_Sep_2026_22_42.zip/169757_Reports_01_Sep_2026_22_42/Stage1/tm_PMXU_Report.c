/****************************************************************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author               :   Rupali Rane
*  Module               :
*  Code                 :   tm_PMXU_Report.c
*  Command				:	tm_PMXU_Report -Partnumber=Part -SVR=SVR -TargetPlant=Plant -RevisionRule="ERC release and above"
*
*   S.No      Date         CR No		Modified By			            Modification Notes
*	 1.		16/05/2023				    Anup Sonawane		 Added Vahicle validation to generate report.
*
*  Created on			:   25/04/2021
*	Modification History :
*	S.No    Date         CR No		Modified By			Modification Notes
*	1.
*
* /user/uaprod/shells/ColorModule/tm_IFD_STD_Part_report
* /tmp/Report.xml
* -Expansion_with_STD_Parts	NO
*
*****************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <property/prop.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
#include <tc/preferences.h>
//#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <qry/qry.h>
#include <time.h>
#include <unidefs.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define Debug TRUE
#define ITK_CALL(X)                                                     \
                if(Debug)                                                               \
                {                                                                               \
                        printf(#X);                                                     \
                }                                                                               \
                fflush(NULL);                                                   \
                status=X;                                                               \
                if (status != ITK_ok )                                  \
                {                                                                               \
                        int                             index = 0;                      \
                        int                             n_ifails = 0;           \
                        const int*              severities = 0;         \
                        const int*              ifails = 0;                     \
                        const char**    texts = NULL;           \
                                                                                                \
                        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                        printf("\t%3d error(s)\n", n_ifails);                                                   \
                        for( index=0; index<n_ifails; index++)                                                  \
                        {                                                                                                                               \
                                printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                        }                                                                                                                               \
                        return status;                                                                                                  \
                }                                                                                                                                       \
                else                                                                    \
                {                                                                               \
                        if(Debug)                                                       \
                        printf("\tSUCCESS\n");                          \
                }                                                                               \

char *Timestamp11 = NULL;
char **childPartFour      = NULL;
char **childPartthree      = NULL;
int tt = 0;
int inct=1;
static int PrintErrorStackA1( void )
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStackA1 iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		//fprintf( stderr, "Error(PrintErrorStackA1): \n");
		//fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStackA1): \n"); fflush(stdout);
		printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
	}
	return ITK_ok;
}

void write2xmlA1(FILE * , char*);
int ctr=0;
int a=0;
int cronjobReportFlag = 0;
int tt3 =0;
//int tt4 =0;

FILE *Report = NULL;
//FILE *Reportcsv = NULL;

void write2xmlA1(FILE *Report , char* str)
{
	fprintf(Report,str); fflush(Report);
	ctr++;
}

char *replaceWordA1(const char *s, const char *oldW, const char *newW)
{
    char *result;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);

    // Counting the number of times old word
    // occur in the string
    for (i = 0; s[i] != '\0'; i++)
    {
        if (strstr(&s[i], oldW) == &s[i])
        {
            cnt++;

            // Jumping to index after the old word.
            i += oldWlen - 1;
        }
    }

    // Making new string of enough length
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;
    while (*s)
    {
        // compare the subStringA1 with the result
        if (strstr(s, oldW) == s)
        {
            strcpy(&result[i], newW);
            i += newWlen;
            s += oldWlen;
        }
        else
            result[i++] = *s++;
    }

    result[i] = '\0';
    return result;
}

//*********************AS*************************************

/*char *replaceWord1(const char *s, const char *oldW,
                                 const char *newW)
{
    char *resultLCS;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);

    // Counting the number of times old word
    // occur in the string
    for (i = 0; s[i] != '\0'; i++)
    {
        if (strstr(&s[i], oldW) == &s[i])
        {
            cnt++;

            // Jumping to index after the old word.
            i += oldWlen - 1;
        }
    }

    // Making new string of enough length
    resultLCS = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;
    while (*s)
    {
        // compare the subStringA1 with the resultLCS
        if (strstr(s, oldW) == s)
        {
            strcpy(&resultLCS[i], newW);
            i += newWlen;
            s += oldWlen;
        }
        else
            resultLCS[i++] = *s++;
    }

    resultLCS[i] = '\0';
    return resultLCS;
}*/
//*********************AS*************************************

char* subStringA1 (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
void clearChildPartThreeA1(int *counttwo, char ***strsettwo) {
	int i = 0;
	printf("inside clearChildPartThreeA1 function\n");fflush(stdout);
    if (*strsettwo) {
        // Free each string in strsettwo and then free strsettwo itself
        for (i = 0; i < *counttwo; ++i) {
		if ((*strsettwo)[i]) 
			{
                free((*strsettwo)[i]); // Use free for standard memory deallocation
            }
        }
		printf("inside clearChildPartThreeA1 function--after\n");fflush(stdout);
        //free(*strsettwo);
        *strsettwo = NULL;  // Set strsettwo to NULL after freeing
    }
    *counttwo = 0;  // Reset counttwo to 0 or any initial value
}
int setFindStrA1(int *count,char ***strset,char* str)
	{
		int j   =0;

		//tmp = sizeof(*strset);

		for(j=0;j<*count;j++)
		{
			printf("\n inside setFindStrA1 %d \n",*count);fflush(stdout);
			//printf("\n setFindStrA1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
			printf("\n setFindStrA1 value is ===%s",(*strset)[j]);fflush(stdout);

			//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
			if(tc_strcmp((*strset)[j],str)==0) //check this
			//if(tc_strcmp(*strset[j],str)==0)

			return j;

		}
		return -1;
	}
void setAddStrFourA1(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrFourA1===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
			  *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;
//void setAddStrFourA1(int *counttwo,char ***strsettwo,char* strtwo)
//{
//	*counttwo=*counttwo+1;
//	//printf("\n setAddStr %d",*count);fflush(stdout);
//	if(*counttwo==1)
//	{
//		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
//	}
//	else
//	{
//		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
//	}
//	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
//	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
//	 printf("\n setAddStrFourA1===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);
//
//
//}
//;
//void setAddStrFourA1(int *counttwo, char ***strsettwo, char* strtwo) {
//    *counttwo = *counttwo + 1;
//    if (*counttwo == 1) {
//        (*strsettwo) = (char **)malloc((*counttwo) * sizeof(char *));
//    } else {
//        (*strsettwo) = (char **)realloc((*strsettwo), (*counttwo) * sizeof(char *));
//    }
//    if (*strsettwo) {
//        (*strsettwo)[*counttwo - 1] = malloc((strlen(strtwo) + 1) * sizeof(char));
//        if ((*strsettwo)[*counttwo - 1]) {
//            strcpy((*strsettwo)[*counttwo - 1], strtwo);
//            printf("\n setAddStrFourA1 === %s", (*strsettwo)[*counttwo - 1]);
//            fflush(stdout);
//        } else {
//            fprintf(stderr, "Allocation failed for (*strsettwo)[%d]\n", *counttwo - 1);
//        }
//    } else {
//        fprintf(stderr, "Allocation failed for *strsettwo\n");
//    }
//}
;
void print_requirement()
{
     printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -Part_Number=<Item ID> (required)\n"
        " -Only_SpareKit_Assembly=<Yes or No>(case sensetive) (required)\n"
        ); fflush(stdout);
}
static void initialise (void)
{
	int ifail;

	if ((ifail = ITK_auto_login()) != ITK_ok)
	fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
	CHECK_FAIL;
}

/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here.
*******************************************************************************/

int ITK_user_main(int argc, char *argv[])
{
	int status = 0;
	int n_lines=0;
	int n_entriesV				 = 1;
	int resultCountVNCol		 = 0;
	int ifail = ITK_ok;

	char *Part_Number = NULL;
	char *RevisionRule = NULL;
	char *TargetPlant = NULL;
	char *SVR = NULL;
	char *userName = NULL;
	char *userPass = NULL;
	char *userGroup = NULL;
	char *TargetPlantStr = NULL;
	char *TargetPlantMakeBuyNm = NULL;
	char *TargetPlantBomLineCS = NULL;
	char *PartDesgnGrp = NULL;
	char *VehicleFile = NULL;
	char *FinalVehicleFile = NULL;
	char *datesetNam = NULL;
	char *datesetNamTemp = NULL;
	char *Timestamp = NULL;
	char *ID = NULL;
	char *obj_type  =NULL;
	char str1[100];
	char str2[100];
	char str3[100];
	char str4[100];
	char str5[100];
	char str6[100];

	tag_t	plat=NULLTAG;
	tag_t	rev=NULLTAG;
	tag_t	bom_window=NULLTAG;
	tag_t	top_line=NULLTAG;
	tag_t VariqueryTag			 = NULLTAG;
	tag_t   rule				 =NULLTAG;
	tag_t   VarientRuletag		 =NULLTAG;

	tag_t	*lines=NULLTAG;
	tag_t * outputVNCol_tags		 =NULLTAG;

	time_t t = time(NULL);

	struct tm tm = *localtime(&t);

	char **valuesNonColSvr		 = (char **) MEM_alloc(1 * sizeof(char *));
	char *qry_entries3[1]		 = {"Name"};

	tag_t   queryTagK = NULLTAG;
	int resultCountK =0;
	tag_t *DMLset=NULLTAG;
	char *rlzStatusList=NULL;
	char *ChngNum=NULL;
	char *DMLno="21PP750052";

	char *rel_stat=NULL;
	char *TaskName=NULL;
	char *TaskRev=NULL;
	char *UserID=NULL;
	tag_t DML=NULLTAG;
	char *PartType=NULL;
	char *Revision_sequence=NULL;
	char *PartNm=NULL;
	char *sUserName=NULL;
	char *sPassword=NULL;
	char *sgrp=NULL;

	char *DR_Status=NULL;
	char *Design_object=NULL;
	char *object_type1=NULL;
	tag_t PartRevTag=NULLTAG;
	tag_t DMLsolution1=NULLTAG;
	//tag_t *DMLChangeReferences=NULLTAG;
	tag_t *DMLSolution=NULLTAG;
	tag_t Report_Relation=NULLTAG;
	tag_t *TaskSVRRevision=NULLTAG;

	//tag_t *solution=NULLTAG;
	tag_t *change_Reference_obj=NULLTAG;
	tag_t change_Reference_obj1=NULLTAG;

	tag_t relation_type=NULLTAG;
	tag_t *DMLsolution=NULLTAG;
	tag_t TaskDMLRelTag=NULLTAG;
	tag_t t_DerivedSVR=NULLTAG;
	tag_t TaskDMLRelTag1=NULLTAG;
	tag_t *DMLBreak=NULLTAG;
	tag_t *DMLBreak1=NULLTAG;
	//tag_t CMReferencesTag=NULLTAG;
	tag_t CMSolutions=NULLTAG;

	//tag_t CMSolutionTag=NULLTAG;
	tag_t Change_Reference=NULLTAG;
	tag_t msExcelType=NULLTAG;
	tag_t ExcelDataset=NULLTAG;
	tag_t latestDataset=NULLTAG;
	int DML_count = 0;
	int DML_count1 = 0;
	int DML_References_count = 0;
	//int Change_reference_count = 0;
	int CMSolutions_folder_count = 0;

	int countSVR = 0;
	//int DML_solution_count = 0;
	int DML_Reference_count = 0;
	char * Fromdate = NULL;
	char *Fromdate1 = NULL;
	char * todate = NULL;
	char *todate1 = NULL;
	int z=0;
	int p=0;
	int u=0;
	int x=0;
	int y=0;
	int ref_count;
	char **ref_list;
	int a=0;
	int result=0;
	char *Release_Status1 = NULL;
	char *userSpareinfo1 = NULL;
	char *Design_Revision1 = NULL;
	char *Name1=NULL;
	char *part_type=NULL;
	char *Design_object2=NULL;
	//char *qry_entriesK[3]=NULL;
	char    **qry_values        =   NULL;
	//char*       FullPath          = NULL;
	char *Name =   NULL;
	char *TempFileNameStr = NULL;

	FILE *ReportVehicle= NULL;


	//printf("\n\n\t AUTO LOGIN SUCCESSFUL1");fflush(stdout);

	TargetPlantStr = (char *) MEM_alloc(20);
	TargetPlantMakeBuyNm = (char *) MEM_alloc(20);
	TargetPlantBomLineCS = (char *) MEM_alloc(50);
	Fromdate1 =(char *)MEM_alloc(20);
	todate1 = (char *)MEM_alloc(20);
	TempFileNameStr = (char *)MEM_alloc(100);

	VehicleFile = (char *) MEM_alloc (sizeof (char) * 128);
	FinalVehicleFile = (char *) MEM_alloc (sizeof (char) * 128);
	datesetNam = (char *) MEM_alloc (sizeof (char) * 128);
	datesetNamTemp = (char *) MEM_alloc (sizeof (char) * 128);
	Timestamp = (char *) MEM_alloc (sizeof (char) * 128);
	childPartFour = (char**)MEM_alloc( 1000 * sizeof *childPartFour );  //added for string set
	childPartthree = (char**)MEM_alloc( 1000 * sizeof *childPartthree );
	//Timestamp11 = (char *) MEM_alloc (sizeof (char) * 128);
	Timestamp11 =(char *) MEM_alloc(200000);
	initialise();

	printf("\n\t AUTO LOGIN SUCCESSFUL--2");fflush(stdout);
	tc_strcpy(Timestamp11, "");
	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	sgrp = ITK_ask_cli_argument("-g=");
	Part_Number = ITK_ask_cli_argument("-PlatformOrVehicle=");
	SVR = ITK_ask_cli_argument("-SVR=");
	RevisionRule = ITK_ask_cli_argument("-RevisionRule=");
	TargetPlant = ITK_ask_cli_argument("-TargetPlant=");
	Fromdate = ITK_ask_cli_argument("-Fromdate=");
	todate = ITK_ask_cli_argument("-todate=");
	UserID = ITK_ask_cli_argument("-UserID=");

	printf("\n Fromdate--> [%s]   todate --> [%s] \n",Fromdate,todate);fflush(stdout);

	sprintf(str1, "%d", tm.tm_mday);
	sprintf(str2, "%d", tm.tm_mon + 1);
	sprintf(str3, "%d", tm.tm_year + 1900);
	sprintf(str4, "%d", tm.tm_hour);
	sprintf(str5, "%d", tm.tm_min);
	sprintf(str6, "%d", tm.tm_sec);

	tc_strcpy(Timestamp, str1);
	tc_strcat(Timestamp, "_");
	tc_strcat(Timestamp, str2);
	tc_strcat(Timestamp, "_");
	tc_strcat(Timestamp, str3);
	tc_strcat(Timestamp, "_");
	tc_strcat(Timestamp, str4);
	tc_strcat(Timestamp, "_");
	tc_strcat(Timestamp, str5);
	tc_strcat(Timestamp, "_");
	tc_strcat(Timestamp, str6);

	cronjobReportFlag = 0;
	int rulefound= 0  ;
	int rulefoundVeh= 0  ;
	int rulefoundTODR= 0  ;
	tag_t *closurerule = NULLTAG;
	tag_t *closureruleVeh = NULLTAG;
	tag_t *closureruleTODR = NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t close_tag_veh = NULLTAG;
	tag_t close_tag_TODR = NULLTAG;
	char **rulename = NULL;
	char **rulenameVeh = NULL;
	char **rulenameTODR = NULL;
	char **rulevalue = NULL;
	char **rulevalueVeh = NULL;
	char **rulevalueTODR = NULL;
	char                 command[200];

	/**Added BY Aadarsh kumar for control object **/
	int n_entry    = 1;
	int rsltCount    = 1;
	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char* userPMXUinfo1 = NULL;
	char* userPMXUinfo2 = NULL;
	tag_t CntrlObjectObj = NULLTAG;
	printf("\n\t INSIDE PMXU_Report_shell_redirect \n");fflush(stdout);
	printf("\n PMXU_Report_Report_shell_redirect-->Printing before Control object executing\n");fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag));
	if (qryTag)
	{
		printf("\n PMXU_Report_Report_shell_redirect-->Output location:Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n PMXU_Report_Report_shell_redirect-->Output location:Not Found Query ControlObjects \n");fflush(stdout);
	}
	
	qry_values2[0] = "PMXU_Report_Report_shell_redirect";

	if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
	printf(" \n PMXU_Report_Report_shell_redirect-->Output value:rsltCount 11:%d:", rsltCount); fflush(stdout);
	if(rsltCount > 0)
	{
		CntrlObjectObj = CntrlObjectTag[0];
		if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo1",&userSpareinfo1)!=ITK_ok)PrintErrorStackA1();
		//if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo2",&userSpareinfo2)!=ITK_ok)   PrintErrorStack();
		printf(" \n PMXU_Report_Report_shell_redirect-->userSpareinfo1= [%s]",userSpareinfo1); fflush(stdout);
	}
	else
	{
		printf(" \n PMXU_Report_Report_shell_redirect-->PMXU_Report_Report control object not found hence exit from code...\n"); fflush(stdout);
		return 1;
	}
	if (tc_strcmp(userSpareinfo1,"ERCDEV")==0)
	{
		printf(" \n Calling shell for ERCDEV\n"); fflush(stdout);
		sprintf(command,"/home/ercdev/devgroups/Aadarsh/PMXURptAttchFromFE/plmtvap01.sh \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" ",sUserName,sPassword,sgrp,Part_Number,RevisionRule,TargetPlant,UserID);

	}
	else if (tc_strcmp(userSpareinfo1,"CVPROD")==0)
	{
		printf(" \n Calling shell for CVPROD\n"); fflush(stdout);
		//sprintf(command,"/user/cvprod/shells/Report/PMXU_Report/Adddeletion_2C9.sh \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" ",Assym1,Rev1,Seq1,RRForNewVC,ClosureVForNewVC,Assym2,Rev2,Seq2,RRForRefVC,ClosureVForRefVC,Plant,WithoutZeroQty,expansionLvl,Without_underscore,Stop_AT_F,UserID);
		sprintf(command,"/user/cvprod/Aadarsh/PMXU_Report/PMXU_2C9.sh \"%s\" \"%s\" \"%s\" \"%s\" ",Part_Number,RevisionRule,TargetPlant,UserID);

	}
	else if (tc_strcmp(userSpareinfo1,"UAPROD")==0)
	{
		printf(" \n Calling shell for UAPROD\n"); fflush(stdout);
		sprintf(command,"/user/uaprod/shells/Report/PMXU_Report/PMXU_2c4.sh \"%s\" \"%s\" \"%s\" \"%s\" ",Part_Number,RevisionRule,TargetPlant,UserID);
	}
	else if (tc_strcmp(userSpareinfo1,"CMITEST")==0)
	{
		printf(" \n Calling shell for CMITEST\n"); fflush(stdout);
		sprintf(command,"/home/cmitest/shells/PMXU_Report/PMXUCMITEST.sh \"%s\" \"%s\" \"%s\" \"%s\" ",Part_Number,RevisionRule,TargetPlant,UserID);
	TC_write_syslog("Command = %s\n",command);
	system(command);				
	return ifail;
	}
}

