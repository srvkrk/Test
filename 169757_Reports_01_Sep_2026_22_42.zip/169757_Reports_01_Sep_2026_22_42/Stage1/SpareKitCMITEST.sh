echo "Spare_kit running on cmitest shell"
echo "In cmitest shell Spare_kit cmitest.sh  ...'"$1"'  '"$2"' '"$3"'  '"$4"' '"$5"' '"$6"'"
/user/cmitest/Program_Shells/Spare_kit/Spare_kit_report -VC="$1" -Revision="$2" -Sequence="$3" -RRForVC="$4" -ClosureVForVC="$5" -UserID="$6"
echo "Spare_kit report end at cmitest"
