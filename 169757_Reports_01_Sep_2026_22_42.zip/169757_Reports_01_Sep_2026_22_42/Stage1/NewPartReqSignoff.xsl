<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40" >
    
    <xsl:output method="xml" version="1.0" indent="yes" />
    <xsl:strip-space elements="*"/>
    
    <xsl:template match="/">
        <xsl:call-template name="ReportHeader"></xsl:call-template>
    </xsl:template>
    
    <xsl:template name="ReportHeader">
        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">
            
            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="11" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <!--<Alignment ss:Horizontal="Right"/>-->
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="PropertyNameCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                </Style>                
            </Styles>
            
            <Worksheet ss:Name="Sheet1">
                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    
                   
                    
                    <Row>
                        <Cell ss:StyleID="s26" ss:MergeAcross='22'>
						<Data ss:Type='String'>New Part Request WorkFlow Details</Data>
						
						</Cell>
					</Row>	
					<Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>New Part Request Number</Data>
                        </Cell>
                        <Cell ss:StyleID="s26" ss:MergeAcross='4'>
                            <Data ss:Type='String'>MCCReviewer</Data>
                        </Cell>      
                        <Cell ss:StyleID="s26" ss:MergeAcross='4'>
                            <Data ss:Type='String'>COC Head Plantform Engineer Review</Data>
                        </Cell>
						 <Cell ss:StyleID="s26" ss:MergeAcross='4'>
                            <Data ss:Type='String'>COC Principal Engineer Review</Data>
                        </Cell>
						<Cell ss:StyleID="s26" ss:MergeAcross='4'>
                            <Data ss:Type='String'>Module TeamLeader Review</Data>
                        </Cell>
						<Cell ss:StyleID="s26" ss:MergeAcross='4'>
                            <Data ss:Type='String'>Assign Reviewer Assignemnt</Data>
                        </Cell>
						<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>New Part Request Number</Data>
                        </Cell>
                    </Row>
                    <Row>
					<Cell></Cell>
					
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>MCCReviewerName</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Start Date</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>End Date</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Status</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>COC HeadReviewerName</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Start Date</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>End Date</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Status</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>COCPrincipalReviewerName</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Start Date</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>End Date</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Status</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Module ReviewerName</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Start Date</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>End Date</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Status</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>SignOffUserName</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Start Date</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>End Date</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Status</Data>
					</Cell>
					<Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Assigned TML Part Number</Data>
					</Cell>

					</Row>
                    <xsl:call-template name="generateDesignRevPartsList"></xsl:call-template>
                    <Row></Row>
                    <Row></Row>
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    
    <xsl:template name="generateDesignRevPartsList">
        <xsl:for-each select="PLMXML/NewPartRequestNumber">
			<Row>
            <!--    <Cell ss:StyleID="s24">
                    <Data ss:Type='Number'><xsl:number value="position()" format="01"/></Data>
                </Cell> -->
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='item_id']"/></Data>
				</Cell>
			     <Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='MCC_process_Performer']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='MCC_processSt_Date']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='MCC_processEnd_Date']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='MCC_process_Result']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='COCH_process_Performer']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
					<Data ss:Type='String'><xsl:value-of select="field[@key='COCH_process_StDate']"/></Data>
				</Cell>
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String' ><xsl:value-of select="field[@key='COCH_process_EndDate']"/></Data>
				</Cell> 
				<Cell ss:StyleID="s24">
                    <Data ss:Type='String' ><xsl:value-of select="field[@key='COCH_process_Result']"/></Data>
				</Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='COCP_process_Performer']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='COCP_process_StDate']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='COCP_process_EndDate']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='COCP_process_Result']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='Module_Revprocess_Performer']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='Module_Revprocess_StDate']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='Module_Revprocess_EndDate']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='Module_Revprocess_Result']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='Assign_process_Performer']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='Assign_process_StDate']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='Assign_process_EndDate']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='Assign_process_Result']"/></Data>
                </Cell>
                <Cell ss:StyleID="s24">
                    <Data ss:Type='String'><xsl:value-of select="field[@key='Assigned_TCUATml_PartNumber']"/></Data>
                </Cell>
                
			</Row>
        </xsl:for-each>
    </xsl:template>
    
</xsl:stylesheet>