/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : CLTask.c
* Created By                   : Aadarsh kumar
* Created On                   : 14/02/2022
* Project                      :
* Methods Defined              :
* Description                  : Generate Estimate sheet
* Specific Notes               : ./CL_Task -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -Fromdate=01-Feb-2023 -Todate=03-Feb-2023
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <cfm/cfm.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}



#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

FILE		*fp 			= NULL;
FILE		*fpC 			= NULL;
FILE		*Report 			= NULL;

void write2xml(FILE * , char*);
int ctr=0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
int i;
char *retStringf;
retStringf = (char*) malloc(200);
for(i=0; i < toCharf; i++ )
		  *(retStringf+i) = *(mainStringf+i+fromCharf);
*(retStringf+i) = '\0';
return retStringf;
}
int cntflag = 0;
int Qtyflag = 0;
int DrStatusflag = 0;
char *Qtypart	= NULL;
char *partdiff	= NULL;
char *RevstatusN	= NULL;
char *RevstatusC	= NULL;

static int PrintErrorStack( void )
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		//fprintf( stderr, "Error(PrintErrorStack): \n");
		//fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
		printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
	}
	return ITK_ok;
}
//static int report_wso_object_string_and_owning_user(tag_t object)
//{
//    char *object_string = NULL;
//    char *owning_user = NULL;
//    char *item_id = NULL;
//    char *date_released = NULL;
//    //ITK_CALL(WSOM_ask_object_id_string(object, &object_string));
//    //ITK_CALL(AOM_UIF_ask_value(object, "owning_user", &owning_user));
//    ITK_CALL(AOM_UIF_ask_value(object, "item_id", &item_id));
//    ITK_CALL(AOM_UIF_ask_value(object, "date_released", &date_released));
//    //printf("       %s - %s \n", object_string, owning_user);
//    printf("%s %s\n", item_id,date_released);
//    //MEM_free(object_string);
//    //MEM_free(owning_user);
//	MEM_free(item_id);
//	MEM_free(date_released);
//	return ITK_ok;
//}

/************BOMExpantionfunction function*******************/

/************main function*******************/
int ITK_user_main(int argc, char* argv[])
{
				char				* u			= NULL;
				char				* p			= NULL;
				char				* g			= NULL;
				char				* Assym1			= NULL;
				char				* Assem_Rev			= NULL;
				char				* Assem_Seq			= NULL;
				char				* UserID			= NULL;
				char				* Rev1		= NULL;
				char				* Seq1		= NULL;
				char				* RRForNewVC		= NULL;
				char				* ClosureViewNewVC	= NULL;
				char				* UserID			= NULL;
				int					 ifail   = ITK_ok;
				char                 command[200];

//				u = ITK_ask_cli_argument("-u=");
//				p = ITK_ask_cli_argument("-p=");
//				g = ITK_ask_cli_argument("-g=");
				Assym1 = ITK_ask_cli_argument("-VC=");
				Assem_Rev = ITK_ask_cli_argument("-VC_Rev=");
				Assem_Seq = ITK_ask_cli_argument("-VC_Seq=");
				UserID = ITK_ask_cli_argument("-UserID=");

				//char quotedRRForNewVC[1024];
				//snprintf(quotedRRForNewVC, sizeof(quotedRRForNewVC), "\\\"%s\\\"", RRForNewVC);
//				printf("\n\t INSIDE Cortona_object_Finder \n");fflush(stdout);
//				ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
//				ITK_auto_login();
//				ITK_CALL(ITK_set_bypass(true));
				ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
				//	ITK_CALL(ITK_auto_login( ));
				if(ITK_init_module("aka.ttl","Echkr5$zEchkr6$zASD","PLM_Support_Group")==ITK_ok)
				{	

				printf("Login Successfull to TCUA \n");

				}
				else
				{		

				printf("\n\n\t\t Login does not exist invalid userid or password ");fflush(stdout);

				}
				/**Added BY Aadarsh kumar for control object for shell re-direct**/
				int n_entry    = 1;
				int rsltCount    = 1;
				tag_t   qryTag     = NULLTAG;
				tag_t   *CntrlObjectTag      = NULLTAG;
				char   *qry_entry[1]  = {"SYSCD"};
				char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
				char* userSpareinfo1 = NULL;
				char* userSpareinfo2 = NULL;
				tag_t CntrlObjectObj = NULLTAG;
				printf("\n Cortona_object_Finder_shell_redirect-->Printing before Control object executing\n");fflush(stdout);
				if(QRY_find2("ControlObjects", &qryTag));
				if (qryTag)
				{
					printf("\n Cortona_object_Finder_shell_redirect-->Output location:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n Cortona_object_Finder_shell_redirect-->Output location:Not Found Query ControlObjects \n");fflush(stdout);
				}

				qry_values2[0] = "Cortona_object_Finder_shell_redirect";

				if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
				printf(" \n Cortona_object_Finder_shell_redirect-->Output value:rsltCount 11:%d:", rsltCount); fflush(stdout);
				if(rsltCount > 0)
				{
					CntrlObjectObj = CntrlObjectTag[0];
					if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo1",&userSpareinfo1)!=ITK_ok)   PrintErrorStack();
					//if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo2",&userSpareinfo2)!=ITK_ok)   PrintErrorStack();
					printf(" \n Cortona_object_Finder_shell_redirect-->userSpareinfo1= [%s]",userSpareinfo1); fflush(stdout);
				}
				else
				{
					printf(" \n Cortona_object_Finder_Report-->Cortona_object_Finder control object not found hence exit from code...\n"); fflush(stdout);
					return 1;
				}
				if (tc_strcmp(userSpareinfo1,"ERCDEV")==0)
				{
					printf(" \n Calling shell for ERCDEV\n"); fflush(stdout);
					sprintf(command,"/home/ercdev/devgroups/Aadarsh/Cortona_object/plmtvap01.sh %s %s %s %s %s",u,p,g,Assym1,Assem_Rev,Assem_Seq,UserID);

				}
				else if (tc_strcmp(userSpareinfo1,"CVPROD")==0)
				{
					printf(" \n Calling shell for CVPROD\n"); fflush(stdout);
					sprintf(command,"/user/cvprod/shells/Report/Cortona_object/Cortona_object_2C9.sh %s %s",Assym1,Assem_Rev,Assem_Seq,UserID);
				}
				else if (tc_strcmp(userSpareinfo1,"UAPROD")==0)
				{
					printf(" \n Calling shell for UAPROD\n"); fflush(stdout);
					sprintf(command,"/user/uaprod/shells/Report/Cortona_object/Cortona_object_2c4.sh %s %s",Assym1,Assem_Rev,Assem_Seq,UserID);
				}
				else if (tc_strcmp(userSpareinfo1,"CMITEST")==0)
				{
					printf(" \n Calling shell for CMITEST\n"); fflush(stdout);
					sprintf(command,"/home/cmitest/shells/Cortona_object/Cortona_objectCMITEST.sh %s %s",Assym1,Assem_Rev,Assem_Seq,UserID);
				}
				//sprintf(command,"/user/cvprod/Aadarsh/spare_kit_report/Sapre_Report_2C9.sh %s %s %s %s %s %s",Assym1,Rev1,Seq1,RRForNewVC,ClosureViewNewVC,UserID);
				TC_write_syslog("Command = %s\n",command);
				system(command);				
				
				return ifail;
}