. /user/uaprod/.bash_profile
echo "PDSR_Report running on 2c4"
echo "In Shell PDSR_Report 2c4  ...'"$1"'  '"$2"' "
ssh uaprodtrl@172.22.97.18 "/user/uaprodtrl/Program_Shells/Reports/PDSR_Summary_Report/PDSR_Report_2c7.sh '"$1"'  '"$2"' "
echo "PDSR_Report report end at 2c4"
