. /user/cvprod/.bash_profile
echo "Spare_kit running on 106"
echo "In Shell Spare_kit 106  ...'"$1"'  '"$2"' '"$3"'  '"$4"' '"$5"' '"$6"' "
/user/cvprod/Program_Shells/Spare_kit/Spare_kit_report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -VC="$1" -Revision="$2" -Sequence="$3" -RRForVC="ERC release and above" -ClosureVForVC="ERC" -UserID="$6"
echo "Spare_kit report end at 106"