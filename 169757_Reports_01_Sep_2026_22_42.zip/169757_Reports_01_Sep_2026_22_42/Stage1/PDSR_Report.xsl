<xsl:stylesheet 
  version="1.0" 
  xmlns="urn:schemas-microsoft-com:office:spreadsheet" 
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform" 
  xmlns:msxsl="urn:schemas-microsoft-com:xslt" 
  xmlns:user="urn:my-scripts" 
  xmlns:o="urn:schemas-microsoft-com:office:office" 
  xmlns:x="urn:schemas-microsoft-com:office:excel" 
  xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"> 
  
  <xsl:output method="xml" encoding="utf-8" indent="yes" /> 

  <xsl:template match="/"> 
    <Workbook 
      xmlns="urn:schemas-microsoft-com:office:spreadsheet" 
      xmlns:o="urn:schemas-microsoft-com:office:office" 
      xmlns:x="urn:schemas-microsoft-com:office:excel" 
      xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet" 
      xmlns:html="http://www.w3.org/TR/REC-html40">
	  <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
				   <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
				   <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
					<Interior ss:Color="#ffff66" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
				<Style ss:ID="s32" ss:Name="DataCell2">
					<Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>           
					<Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#BBFF99" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s25" ss:Name="DataCell1">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s26" ss:Name="DataCell9">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                   
                </Style>
            </Styles>
      <xsl:apply-templates select="Top"/> 
    </Workbook> 
  </xsl:template> 

  <xsl:key name="k" match="logo/field" use="@key"/> 
  
  <xsl:variable name="cols" select="/Top/logo/field[generate-id()= generate-id(key('k',@key)[1])]"/> 

  <xsl:template match="Top"> 

    <Worksheet ss:Name="{local-name()}"> 

      <Table> 
					<Column ss:AutoFitWidth="0" ss:Width="60" AutoFitWidth="1"/>
				    <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="143" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="120" AutoFitWidth="1"/><!--Column : 5-->
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="250" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="180" AutoFitWidth="1"/>

					<Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s21" ss:MergeAcross="3"><Data ss:Type="String">PDSR Report</Data></Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String">Report Date</Data></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String"> <xsl:for-each select="/"><xsl:value-of select="Top/Date"/></xsl:for-each></Data></Cell>
                    </Row>
                    <Row></Row>
                    <Row></Row>
					
					

   <Row> 
       <xsl:for-each select= "$cols"> 
               <Cell ss:StyleID="s22"> 
                 <Data ss:Type="String"> 
                   <xsl:value-of select="@key"/> 
                 </Data> 
               </Cell> 
           </xsl:for-each> 
   </Row> 
            <xsl:apply-templates select="logo"/> 
       
      </Table> 
    </Worksheet> 
  </xsl:template> 

  <xsl:template match="logo"> 
    <xsl:variable name="logo" select="."/> 
    <Row> 
      <xsl:for-each select="$cols"> 
        <Cell ss:StyleID="s26"> 
          <Data ss:Type="String"> 
            <xsl:value-of select="$logo/field[@key = current()/@key]"/> 
          </Data> 
        </Cell> 
      </xsl:for-each> 
    </Row> 
  </xsl:template> 
</xsl:stylesheet> 
														