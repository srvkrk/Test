
			#define _CRT_SECURE_NO_DEPRECATE
			#define NUM_ENTRIES 1
			#define TE_MAXLINELEN  128 
			#include <ae/dataset.h>
			#include <ae/dataset_msg.h>
			#include <ai/sample_err.h>
			#include <bom/bom.h>
			#include <bom/bom_attr.h>
			//#include <epm/cr_effectivity.h>
			#include <epm/epm.h>
			//#include <epm/releasestatus.h>
			#include <fclasses/tc_string.h>
			#include <ict/ict_userservice.h>
			//#include <itk/mem.h>
			#include <lov/lov.h>
			#include <lov/lov_msg.h>
			#include <pie/pie.h>
			#include <pom/pom/pom.h>
			#include <property/prop.h>
			#include <ps/ps.h>
			#include <ps/ps_errors.h>
			#include <res/reservation.h>
			//#include <sa/imanfile.h>
			#include <sa/sa.h>
			#include <sa/tcfile.h>
			#include <sa/user.h>
			#include <ss/ss_errors.h>
			#include <stdarg.h>
			#include <stdio.h>
			#include <stdlib.h>
			#include <string.h>
			#include <sys/stat.h>
			#include <tc/emh.h>
			#include <tc/folder.h>
			//#include <tc/iman.h>
			#include <tc/preferences.h>
			//#include <tc/tc.h>
			#include <tc/tc_macros.h>
			#include <tc/tc_startup.h> 
			#include <tccore/aom.h>
			#include <tccore/aom_prop.h>
			#include <tccore/custom.h>
			#include <tccore/grm.h>
			#include <tccore/grm_msg.h>
			//#include <tccore/iman_msg.h>
			//#include <tccore/imantype.h>
			#include <tccore/item.h>
			#include <tccore/item_errors.h>
			#include <tccore/tctype.h>
			#include <tccore/workspaceobject.h>
			#include <tcinit/tcinit.h>
			#include <textsrv/textserver.h>
			#include <time.h>
			#include <unidefs.h>
			#include <user_exits/epm_toolkit_utils.h>
			#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
            #define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
            #define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
            #define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
            #define ITK_err (EMH_USER_error_base + 2)





			static int report_error( char *file, int line, char *function, int return_code)
			{
				if (return_code != ITK_ok)
				{
					char *error_msg_string;

					EMH_ask_error_text(return_code, &error_msg_string);
					printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
					TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
					printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
					TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
					if(error_msg_string) MEM_free(error_msg_string);
											
				}
							return return_code;
			}






static int PrintErrorStack( void )

			{
				int iNumErrs = 0;
				const int *pSevLst;
				const int *pErrCdeLst;
				const char **pMsgLst;
				register int i = 0;

				EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
						   
				for ( i = 0; i < iNumErrs; i++ )
				{
					fprintf( stderr, "Error(PrintErrorStack): \n");
					fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
				}
				return ITK_ok;
			}


			int ITK_user_main(int argc, char *argv[])
			{
				 char * userName	= NULL;
				 char * userPass	= NULL;
				 char * userGrp     = NULL;
				 //char * todate = NULL;
				 char * Fromdate = NULL;
				 userName			= ITK_ask_cli_argument("-u=");
				 userPass			= ITK_ask_cli_argument("-pf=");
				 userGrp			= ITK_ask_cli_argument("-g=");
				 Fromdate           = ITK_ask_cli_argument("-Fromdate=");
				 //todate             = ITK_ask_cli_argument("-todate=");

			     tag_t queryTag     = NULLTAG;
			     tag_t item_tag     = NULLTAG;
			     tag_t rev_tag     = NULLTAG;
				 int   n_entries    = 3;
				 int count          = 0;
				 tag_t *result      = NULLTAG;
				 int status			= 0;
				 int i              = 0;
				 char *partno       = NULL;
				 char *partrev       = NULL;
				 char *dr_status       = NULL;
				 char *p_type       = NULL;
				 char *obj_ID       = NULL;
				 char *rev_ID       = NULL;
				 int  ifail         = ITK_ok;
				 char **qry_entries = (char **) MEM_alloc(10 * sizeof(char *));
				 char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
				 qry_entries[0]     = "Event Type Name";
				 qry_entries[1]     = "fnd0LoggedDate_after";
				 //qry_entries[2]     = "fnd0LoggedDate_before";
				 qry_entries[2]     = "Type";
				 qry_values[0]      = "__Check_In";
				 qry_values[1]      = Fromdate;
				 //qry_values[2]      = todate;
				 qry_values[2]      = "Design Revision";
				 FILE  *fptr=NULL;
			     char sBuffer[1024] = { '\0' };
			     
			     ITK_auto_login();
			     ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
			     ITK_CALL(ITK_set_bypass(true));
			     
			     
			     
			     if(QRY_find2("Check_In_Between_Dates", &queryTag));
			     	
			     
			     if (queryTag!=NULLTAG)
			     {
			     		printf("Found Query 'Check_In_Between_Dates' \n\t"); fflush(stdout);
			     }
			     else
			     {
			     		printf("Not Found Query 'Check_In_Between_Dates' \n\t"); fflush(stdout);
			     
			     		ITK_CALL(POM_logout(false));
			     		return status;
			     }
			
				 if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &count, &result));
				 printf("Count:[%d] \n\t",count); fflush(stdout);
				 printf("Query executed \n\t"); fflush(stdout);
				 for(i=0;i<count;i++)
				 {
					 if (AOM_ask_value_string(result[i],"fnd0PrimaryObjectID",&obj_ID)!=ITK_ok);
					 if (AOM_ask_value_string(result[i],"fnd0PrimaryObjectRevID",&rev_ID)!=ITK_ok);
					// printf("\n\t  Obj_ID,Rev_ID==> [%s][%s]",obj_ID,rev_ID); fflush(stdout);
					 if(ITEM_find_item(obj_ID,&item_tag)!=ITK_ok);
					 if(ITEM_find_revision(item_tag,rev_ID,&rev_tag)!=ITK_ok);
					 if (AOM_ask_value_string(rev_tag,"t5_PartType",&p_type)!=ITK_ok);
					// printf("\n\t  p_type==> [%s]",p_type); fflush(stdout);
					
					 if( tc_strcmp(p_type,"V")==0 )
					 {
					   if (AOM_ask_value_string(rev_tag,"item_id",&partno)!=ITK_ok);
					   if (AOM_ask_value_string(rev_tag,"item_revision_id",&partrev)!=ITK_ok);
					   if (AOM_ask_value_string(rev_tag,"t5_PartStatus",&dr_status)!=ITK_ok);
					   printf("\n\t  Vehicle Item ID and rev==> [%s][%s]\n",partno,partrev); fflush(stdout);
					   printf("\n\t  Vehicle DR status ==> [%s]\n",dr_status); fflush(stdout);
					   
						
					   if( (tc_strcmp(dr_status,"DR0")==0) || (tc_strcmp(dr_status,"DR1")==0) )
						 {
							 printf("Report not required \n\t"); fflush(stdout);
							
					     }
						 else
						 {
							    fptr=fopen("/user/cvprod/Program_Shells/BOM_Corr/Vehicle_list.txt","a+");
							    if (fptr == NULL)
							{
							    printf("Could not open file\n");	fflush(stdout);
							    return 0;
							}
							if (fptr != NULL)
								{
										//printf("File opened\n");	fflush(stdout);
										char* rev	= tc_strtok(partrev, ";");
										char* seq	= tc_strtok(NULL, ";");
										printf("%s,%s",rev,seq);fflush(stdout);
										fprintf(fptr,"%s,%s,%s,\n",partno,rev,seq);
							
						        }
	
						 }

		
					 }
					 else
					 {
						//printf("Part type is not vehicle \n\t"); fflush(stdout);
					 }
				 
				 }
			
				return ifail;
				}