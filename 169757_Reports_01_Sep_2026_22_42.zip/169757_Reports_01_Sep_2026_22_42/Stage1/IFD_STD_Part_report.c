/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME		:	IFD&STD_Part_report.c
**
** Author				:	AWW917697 
**
** Date					:	14/9/2019                                                                                                                                                                                                             
**																																	                                                              
** command to run		:
**
**************************************************************************************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
//#include <epm/cr_effectivity.h>
#include <epm/epm.h>
//#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
//#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <property/prop.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
//#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
//#include <tc/iman.h>
#include <tc/preferences.h>
//#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <unidefs.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

char    * UserdID		= NULL;
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


void write2xml(FILE * , char*);
int ctr=0;

 int a=0;

FILE *Report; 
FILE *ReportVehicle;


void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}

char *replaceWord(const char *s, const char *oldW, 
                                 const char *newW) 
{ 
    char *result; 
    int i, cnt = 0; 
    int newWlen = strlen(newW); 
    int oldWlen = strlen(oldW); 
  
    // Counting the number of times old word 
    // occur in the string 
    for (i = 0; s[i] != '\0'; i++) 
    { 
        if (strstr(&s[i], oldW) == &s[i]) 
        { 
            cnt++; 
  
            // Jumping to index after the old word. 
            i += oldWlen - 1; 
        } 
    } 
  
    // Making new string of enough length 
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1); 
  
    i = 0; 
    while (*s) 
    { 
        // compare the substring with the result 
        if (strstr(s, oldW) == s) 
        { 
            strcpy(&result[i], newW); 
            i += newWlen; 
            s += oldWlen; 
        } 
        else
            result[i++] = *s++; 
    } 
  
    result[i] = '\0'; 
    return result; 
} 

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

void print_requirement()
{
     printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -Part_Number=<Item ID> (required)\n"
        " -Only_SpareKit_Assembly=<Yes or No>(case sensetive) (required)\n"
        );    
}

int addexcelinfolder(char* DatasetNaam, tag_t IFD_FOLDER_tag , char* File_path)
{
		
		tag_t msExcelType	= NULLTAG;
		tag_t ExcelDataset	= NULLTAG;		
		tag_t filetag =  NULLTAG;
		tag_t tool =  NULLTAG;
		int ref_count =0;
		char** ref_list;
		PREF_preference_type_t tagRefType =  1;
		
		IMF_file_t fileDescriptor;
		
		printf("\n\t ~~~~Inside Create Dataset~~~~~");
		
		ITK_CALL(AE_find_datasettype2("MSExcel",&msExcelType));		
		ITK_CALL(AE_create_dataset_with_id(msExcelType,DatasetNaam,"IFD Report","","",&ExcelDataset));
		ITK_CALL(AE_save_myself(ExcelDataset));		
		if(FL_insert(IFD_FOLDER_tag,ExcelDataset,0));
		if(AOM_save_without_extensions(IFD_FOLDER_tag));

		ITK_CALL(IMF_import_file(File_path,NULL, SS_BINARY, &filetag, &fileDescriptor));
		ITK_CALL(AOM_save_without_extensions(filetag)!=ITK_ok);

		ITK_CALL(AE_ask_datasettype_refs(msExcelType, &ref_count, &ref_list));
		ITK_CALL(AE_add_dataset_named_ref2(ExcelDataset,ref_list[0],tagRefType,filetag));
		ITK_CALL(AE_set_dataset_tool(ExcelDataset,tool));
		ITK_CALL(AOM_save_without_extensions(ExcelDataset)); 
	return 0;
	
}
char    * VC_Number			= NULL;
int ITK_user_main(int argc, char *argv[])
{ 
		char    * Part_Number		= NULL;
		char    * VC_Number			= NULL;
		char	* Standard_parts	= NULL;
		char	* RevisionRule		= NULL;
		char	* SVR				= NULL;
		char	* VC				= NULL;
		char    * userName		= NULL;
		char    * userPass		= NULL;
		char    * userGroup		= NULL;
		tag_t	plat=NULLTAG;
		tag_t	rev=NULLTAG;
		tag_t	bom_window=NULLTAG;
		tag_t	top_line=NULLTAG;
		int		n_lines=0;
		tag_t	*lines=NULL;
		time_t t = time(NULL);
		struct tm tm = *localtime(&t);

		
		tag_t VariqueryTag			 = NULLTAG;
		char **valuesNonColSvr		 = (char **) MEM_alloc(1 * sizeof(char *));
		int n_entriesV				 = 1;
		int resultCountVNCol		 = 0;
		char *qry_entries3[1]		 = {"Name"};
		tag_t * outputVNCol_tags	 = NULLTAG;

		tag_t   rule				 = NULLTAG;
		tag_t   VarientRuletag		 = NULLTAG;
				int foldcount= 0;
		tag_t userdetail= NULLTAG;
		tag_t userhome= NULLTAG;
		tag_t *foldnames= NULLTAG;
		char *foldername= NULL;
		char *folderowner= NULL;
		char *FolderNaaam= NULL;
		int Folderavailflag =0;
		tag_t IFD_FLDR= NULLTAG;
		tag_t foldertypetag= NULLTAG;
		tag_t createfoldertag= NULLTAG;
		tag_t FLTG= NULLTAG;
		
		//Part_Number		= ITK_ask_cli_argument("-Platform=");
		VC_Number		= ITK_ask_cli_argument("-VC=");
		//SVR             = ITK_ask_cli_argument("-SVR=");
		RevisionRule	= ITK_ask_cli_argument("-RevisionRule=");
		Standard_parts	= ITK_ask_cli_argument("-Expansion_with_STD_Parts=");
		userName		= ITK_ask_cli_argument("-u=");
		userPass		= ITK_ask_cli_argument("-pf=");
		userGroup		= ITK_ask_cli_argument("-g=");
		UserdID = ITK_ask_cli_argument("-UID=");


	 printf("\n\t before auto login \n "); fflush(stdout);

						
	 ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ) ;
   //ITK_init_module("ercpsup","password","Engineering");
	 ITK_auto_login();
	 ITK_set_bypass(true);


	 ReportVehicle=fopen("/tmp/IFD_Report.csv","w");
	 if (ReportVehicle == NULL)
	  {
	 	printf(" TODR--ERROR: XML ReportVehicle Cannot open File\n"); fflush(stdout);
	 	return -1;
	  }
	 else
	 {
	 	printf(" TODR--XML ReportVehicle File opened successfully for CSV.\n"); fflush(stdout);
	 }
	 if (tc_strlen(VC_Number) == 0)
			{
				printf("\n Vehicle not found\n"); fflush(stdout);

							
			}


		else
			{
								ITEM_find_item(VC_Number, &plat);

								ITEM_ask_latest_rev(plat, &rev);



								fprintf(ReportVehicle,"VC_Number: %s\n",VC_Number); fflush(ReportVehicle);
								fprintf(ReportVehicle,"RevisionRule: %s\n",RevisionRule); fflush(ReportVehicle);
								fprintf(ReportVehicle,"Standard_parts: %s\n",Standard_parts); fflush(ReportVehicle);
								fprintf(ReportVehicle,"SR.NO,Drawing Number,current_revision_id,PartType,owning_user,release_status_list,Description,DML\n"); fflush(ReportVehicle);


								//Report=fopen("/tmp_plmpapp2c9/Report.xml","w");
								Report=fopen("/tmp/IFD_Report.xml","w");
															if (Report == NULL)
														{
																		
																		printf("ERROR: XML Cannot open File_IFD\n");
																		printf("IFD_XML_ERROR\n");
																		return -1;
														}
														else
														{
																		printf("XML File opened successfully._IFD\n");
														}
														write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
														write2xml(Report,"\n<Top>\n");

														//write2xml(Report,"<Item_ID>");
														//write2xml(Report,Part_Number);
														//write2xml(Report,"</Item_ID>");

														printf("Date: %d-%d-%d\n", tm.tm_year + 1900, tm.tm_mon + 1,tm.tm_mday);
														write2xml(Report,"\n<Date>");
														fprintf(Report,"%d-%d-%d",tm.tm_mday, tm.tm_mon + 1,  tm.tm_year + 1900);
														write2xml(Report,"</Date>\n");

														//write2xml(Report,"<SVR>");
														//write2xml(Report,SVR);
														//write2xml(Report,"</SVR>");
														write2xml(Report,"<VC_Number>");
														write2xml(Report,VC_Number);
														write2xml(Report,"</VC_Number>");


									printf(" before BOM_create_window.._IFD\n"); fflush(stdout);   
									BOM_create_window( &bom_window );

									CFM_find(RevisionRule, &rule );
									BOM_set_window_config_rule( bom_window, rule );

									BOM_set_window_pack_all(bom_window, FALSE);
									BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line );

									BOM_line_ask_child_lines(top_line, &n_lines, &lines);
										 
									printf("\n After BOM_window_apply_variant_configuration-----_IFD\n"); fflush(stdout);
									getchilds(n_lines,lines,Standard_parts,ReportVehicle);		
															write2xml(Report,"</Top>\n");	
															fclose(Report);
															if (ReportVehicle!=NULL)
															{
																fclose(ReportVehicle);
															}
											
			}
		char *csvname = NULL;
		csvname = (char *) MEM_alloc (sizeof (char) * 128);
		char *csvpath = NULL;
		csvpath = (char *) MEM_alloc (sizeof (char) * 128);

		char str1[100];
		char str2[100];
		char str3[100];
		char str4[100];
		char str5[100];
		char str6[100];
		char *Timestamp = NULL;
		Timestamp = (char *) MEM_alloc (sizeof (char) * 128);
		//time_t t = time(NULL);
		//struct tm tm = *localtime(&t);
		sprintf(str1, "%d", tm.tm_mday);
		sprintf(str2, "%d", tm.tm_mon + 1);
		sprintf(str3, "%d", tm.tm_year + 1900);
		sprintf(str4, "%d", tm.tm_hour);
		sprintf(str5, "%d", tm.tm_min);
		sprintf(str6, "%d", tm.tm_sec);
		tc_strcpy(Timestamp, str1);
		tc_strcat(Timestamp, "_");
		tc_strcat(Timestamp, str2);
		tc_strcat(Timestamp, "_");
		tc_strcat(Timestamp, str3);
		tc_strcat(Timestamp, "_");
		tc_strcat(Timestamp, str4);
		tc_strcat(Timestamp, "_");
		tc_strcat(Timestamp, str5);
		tc_strcat(Timestamp, "_");
		tc_strcat(Timestamp, str6);
		tc_strcpy(csvname,"");
		tc_strcat(csvname,"IFD_report");
		tc_strcat(csvname,"_");
		tc_strcat(csvname,VC_Number);
		tc_strcat(csvname,"_");
		tc_strcat(csvname,Timestamp);
		tc_strcpy(csvpath, "/tmp/");
		tc_strcat(csvpath, "IFD_Report.csv");


//IFD report in User home folder.
		if(SA_find_user2(UserdID, &userdetail));
		printf("\n\t userID: %s ",UserdID);fflush(stdout);
		if(SA_ask_user_home_folder(userdetail, &userhome));
		if(userhome != NULLTAG)
		{
			if(FL_ask_references(userhome, FL_fsc_by_object ,&foldcount,&foldnames)); // Check weather folder is already preset in home folder?
			printf("\n\t No. Of folders in User home Directory = %d ",foldcount);fflush(stdout);
			int k= NULL;
			int ifail = NULL;
			char *errrr = NULL;

			for ( k = 0 ; k < foldcount ; k++)
			{
				ifail= AOM_ask_value_string(foldnames[k],"object_name",&foldername);
				if (ifail != ITK_ok)
					{
						EMH_ask_error_text(ifail, &errrr);
						printf("\n\t Error = %s ", errrr);
					}
	
				
				if(tc_strcmp(foldername,"IFD_Reports")!=0)
					{
						printf("\n\t ------------>IFD_Reports named folder not found hence creating a new folder");
						Folderavailflag = 1;
					}
				else
					{
						ifail = AOM_UIF_ask_value(foldnames[k],"owning_user",&folderowner);
						printf("\n\t ------------>Folderavailflag = 2 ");
						IFD_FLDR =  foldnames[k] ;
						Folderavailflag = 2;	
						break;				
					}
				
			}
			if (Folderavailflag == 1)    // Folder is not available Hence Creating a Folder named "IFD_Reports"
			{
                if(TCTYPE_find_type( "Folder", NULL, &foldertypetag) );
                if(foldertypetag != NULLTAG)
                printf("\n\t foldertypetag != NULLTAG");
                if(TCTYPE_construct_create_input( foldertypetag,&createfoldertag)) ;
                ifail = AOM_UIF_set_value(createfoldertag,"object_name","IFD_Reports");
                if (ifail != ITK_ok)
                {
                    EMH_ask_error_text(ifail, &errrr);
                    printf("\n\t Error (AOM_UIF_set_value) = %s ", errrr);
                }
                ifail = TCTYPE_create_object( createfoldertag,&FLTG) ;
                if (ifail != ITK_ok)
                {
                    EMH_ask_error_text(ifail, &errrr);
                    printf("\n\t Error (TCTYPE_create_object) = %s ", errrr);
                }
                if(FLTG != NULLTAG)
                {
					ifail = POM_set_owning_user(FLTG, userdetail);
					ifail = AOM_save_without_extensions(FLTG) ;
				
                	if (ifail != ITK_ok)
						{
							EMH_ask_error_text(ifail, &errrr);
							printf("\n\t Error = %s ", errrr);
						}
				}
                
                if(FL_insert(userhome,FLTG,999));
                if(AOM_save_without_extensions(userhome));
				//Folderavailflag = 2;

				addexcelinfolder(csvname, FLTG , csvpath);
				            
			}
			if (Folderavailflag == 2)	// Folder is available>> attach the report into the dataset
			{
				ifail= AOM_ask_value_string(IFD_FLDR,"object_name",&FolderNaaam);
				printf("\n\t  Folder =[%s] FOUND user Home Folder and owning user = %s",FolderNaaam,folderowner);

				addexcelinfolder(csvname, IFD_FLDR , csvpath);
			
				
			}
		}
				
		return 0;
}




int getchilds(int n_lines,tag_t *lines,char *Standard_parts,FILE *ReportVehicle)
{
		char *name=NULL;
		int count1=0;
		tag_t *sub_childs=NULL;
		int i=0;
		char *value=NULL;
		char *project=NULL;
		char *dsgngrp=NULL;
		char *prttype=NULL;
		char *desc=NULL;
		char *item_id=NULL;
		char *myid=NULL;
		char *rev_Id=NULL;
		char *Part_type=NULL;
		char *owner=NULL;
		char *lifecycle=NULL;
		char *descp=NULL;
		tag_t child_item=NULLTAG;
		tag_t child_rev=NULLTAG;
		int count=0;
		int *obj_lvl=0;
		GRM_relation_t *sec_obj=NULLTAG;
		char **relation=NULL;
		int j=0;
		char *sec_obj_type=NULL;
		char *DML_Id=NULL;
		char *myDMLid=NULL;
		tag_t relType;
		tag_t primary_object;
		char c[] = "&"; 
	    char d[] = "&#38;";
		char *result = NULL;
		

			printf("\n Inside getchilds function _IFD\n");
			printf("\n IFD STD_PART %s",Standard_parts);
			if( tc_strcmp ( Standard_parts , "YES" ) == 0 )
			{

				for(i=0;i<n_lines;i++)
				{
				AOM_UIF_ask_value(lines[i],"bl_line_name",&name);
				printf("\n Childs Name %s",name);

				AOM_UIF_ask_value(lines[i],"bl_item_item_id",&item_id);
				printf("\n Childs ID %s",item_id);
				
					ITEM_find_item(item_id, &child_item);
						ITEM_ask_latest_rev(child_item, &child_rev);
						AOM_UIF_ask_value(child_rev,"t5_ProjectCode",&project);
						AOM_UIF_ask_value(child_rev,"t5_DesignGrp",&dsgngrp);
						AOM_UIF_ask_value(child_rev,"t5_PartType",&prttype);

						myid=subString(item_id,8,2);

					if((tc_strcmp(project,"1111")==0) && (tc_strcmp(dsgngrp, "11") == 0))
						{	
							printf("\n a=%d",a);
							a++;
							write2xml(Report,"<logo>\n");

									printf("\nWriting to XML_IFD");
				
									fprintf(Report,"<field key =\"SR.NO\">");
									fprintf(Report,"%d",a);
									fprintf(Report,"</field>\n");

									write2xml(Report,"<field key =\"Drawing Number\">");
									printf("\n Item_ID ID_IFD %s",item_id);
									write2xml(Report,item_id);
									write2xml(Report,"</field>\n");

									AOM_UIF_ask_value(child_rev,"current_revision_id",&rev_Id);
									write2xml(Report,"<field key =\"Revision Seq\">");
									write2xml(Report,rev_Id);
									write2xml(Report,"</field>\n");	

									AOM_UIF_ask_value(child_rev,"t5_PartType",&Part_type);
									write2xml(Report,"<field key =\"Part Type\">");
									write2xml(Report,Part_type);
									write2xml(Report,"</field>\n");

									AOM_UIF_ask_value(child_rev,"owning_user",&owner);
									write2xml(Report,"<field key =\"Owner\">");
									write2xml(Report,owner);
									write2xml(Report,"</field>\n");	

									AOM_UIF_ask_value(child_rev,"release_status_list",&lifecycle);
									write2xml(Report,"<field key =\"Lifecycle State\">");
									write2xml(Report,lifecycle);
									write2xml(Report,"</field>\n");

									AOM_UIF_ask_value(child_rev,"object_desc",&descp);
									result = replaceWord(descp, c, d);
									write2xml(Report,"<field key =\"Description\">");
									write2xml(Report,result);
									write2xml(Report,"</field>\n");

									write2xml(Report,"<field key =\"DML Number\">");
							
									GRM_find_relation_type("CMHasSolutionItem",&relType);
									if(relType != NULLTAG)
									{
										GRM_list_primary_objects(child_rev , relType,&count, &sec_obj);
										for (j=0;j<count ;j++ )
									{ 
											primary_object = sec_obj[j].primary;
										AOM_UIF_ask_value(primary_object,"object_type",&sec_obj_type);
										printf("\n object_type=%s",sec_obj_type);
										if((tc_strcmp(sec_obj_type,"ERC Task Revision")==0)		||	(tc_strcmp(sec_obj_type, "APL Task Revision") == 0) )
										{   
											AOM_UIF_ask_value(primary_object,"current_id",&DML_Id);
											if (tc_strlen(DML_Id) > 0)
											{								
												myDMLid=subString(DML_Id,0,10);

												write2xml(Report,myDMLid);
												write2xml(Report,"    ");
											}
										}
									}
										
									} 
									write2xml(Report,"</field>\n");

									MEM_free(obj_lvl);
									MEM_free(sec_obj);
									MEM_free(relation);

							write2xml(Report,"</logo>\n");
						}
					

				BOM_line_ask_all_child_lines(lines[i],&count1,&sub_childs);

				if(count1>0)
					{
					getchilds(count1,sub_childs,Standard_parts,ReportVehicle);
					
					}
				}
								if(lines)
									MEM_free(lines);
			}
			else if( strcmp ( Standard_parts , "NO" ) == 0 )
			{
					printf("\n Inside STDPARTS NO logic _IFD\n");
					printf("\n Number of n_lines: %d \n",n_lines);

					for(i=0;i<n_lines;i++)
				{
				AOM_UIF_ask_value(lines[i],"bl_line_name",&name);
				printf("\n IFD Childs Name %s",name);

				printf("\n Inside n_lines \n");

				AOM_UIF_ask_value(lines[i],"bl_item_item_id",&item_id);
				printf("\n IFD Childs ID %s",item_id);
				
					ITEM_find_item(item_id, &child_item);
						ITEM_ask_latest_rev(child_item, &child_rev);
					AOM_UIF_ask_value(child_rev,"owning_project",&project);
						AOM_UIF_ask_value(child_rev,"t5_DesignGrp",&dsgngrp);
						AOM_UIF_ask_value(child_rev,"t5_PartType",&prttype);
						//AOM_UIF_ask_value(child_rev,"object_desc",&desc);

						myid=subString(item_id,8,2);

					if(((tc_strcmp(myid, "00") == 0) && (tc_strcmp(prttype, "Dummy") == 0) )	||	  (tc_strcmp(prttype, "Information Fitment Drawing") == 0) || (tc_strcmp(prttype, "Dummy Assembly") == 0) )
						{		
						printf("\n MY ID %s",myid);
							printf("\n a=%d",a);
							a++;
							write2xml(Report,"<logo>\n");

									printf("\nWriting to XML");

									fprintf(Report,"<field key =\"SR.NO\">");
									fprintf(Report,"%d",a);
									fprintf(Report,"</field>\n");

									write2xml(Report,"<field key =\"Drawing Number\">");
									printf("\n Item_ID ID %s",item_id);
									write2xml(Report,item_id);
									write2xml(Report,"</field>\n");

									AOM_UIF_ask_value(child_rev,"current_revision_id",&rev_Id);
									write2xml(Report,"<field key =\"Revision Seq\">");
									write2xml(Report,rev_Id);
									write2xml(Report,"</field>\n");	

									AOM_UIF_ask_value(child_rev,"t5_PartType",&Part_type);
									write2xml(Report,"<field key =\"Part Type\">");
									write2xml(Report,Part_type);
									write2xml(Report,"</field>\n");

									AOM_UIF_ask_value(child_rev,"owning_user",&owner);
									write2xml(Report,"<field key =\"Owner\">");
									write2xml(Report,owner);
									write2xml(Report,"</field>\n");	

									AOM_UIF_ask_value(child_rev,"release_status_list",&lifecycle);
									write2xml(Report,"<field key =\"Lifecycle State\">");
									write2xml(Report,lifecycle);
									write2xml(Report,"</field>\n");
									STRNG_replace_str(lifecycle,",","-",&lifecycle);

									AOM_UIF_ask_value(child_rev,"object_desc",&descp);
									result = replaceWord(descp, c, d);
									STRNG_replace_str(result,",","-",&result);

									printf("\n Desc =====> %s",result);
									write2xml(Report,"<field key =\"Description\">");
									write2xml(Report,result);
									write2xml(Report,"</field>\n");

									write2xml(Report,"<field key =\"DML Number\">");
							
									GRM_find_relation_type("CMHasSolutionItem",&relType);
									if(relType != NULLTAG)
									{
										GRM_list_primary_objects(child_rev , relType,&count, &sec_obj);
										for (j=0;j<count ;j++ )
									{ 
											primary_object = sec_obj[j].primary;
										AOM_UIF_ask_value(primary_object,"object_type",&sec_obj_type);
										printf("\n object_type=%s",sec_obj_type);
										if((tc_strcmp(sec_obj_type,"ERC Task Revision")==0)		||	(tc_strcmp(sec_obj_type, "APL Task Revision") == 0) )
										{   
											AOM_UIF_ask_value(primary_object,"current_id",&DML_Id);
											if (tc_strlen(DML_Id) > 0)
											{
											myDMLid=subString(DML_Id,0,10);	
											write2xml(Report,myDMLid);
											write2xml(Report,"    ");
											}
										}
									}
										
									} 
									write2xml(Report,"</field>\n");

									MEM_free(obj_lvl);
									MEM_free(sec_obj);
									MEM_free(relation);
							fprintf(ReportVehicle,"%d,%s,%s,%s,%s,%s,%s,%s\n",a,item_id,rev_Id,Part_type,owner,lifecycle,result,DML_Id); fflush(ReportVehicle);
							write2xml(Report,"</logo>\n");
						}
					

				BOM_line_ask_all_child_lines(lines[i],&count1,&sub_childs);

				if(count1>0)
					{
					
					getchilds(count1,sub_childs,Standard_parts,ReportVehicle);
					
					}
				}
								if(lines)
									MEM_free(lines);

			}	

		
}
		
