<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
           xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
           xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
           xmlns="urn:schemas-microsoft-com:office:spreadsheet"
           xmlns:o="urn:schemas-microsoft-com:office:office"
           xmlns:x="urn:schemas-microsoft-com:office:excel"
           xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
           xmlns:html="http://www.w3.org/TR/REC-html40" >

  <xsl:output method="xml" version="1.0" indent="yes" />
  <xsl:strip-space elements="*"/>
  
  <xsl:key name="dmlElement" match="plm:Product" use="@id"/>
  <xsl:key name="projectElement" match="plm:Project" use="@id"/>
  <xsl:key name="releasestatus" match="plm:ReleaseStatus" use="@id"/>

 <!--<!-\- <xsl:variable name="trvrootref" select="/plm:PLMXML/plm:Header/@traverseRootRefs"/>
  <xsl:variable name="roid" select="substring-after($trvrootref,'#')"/>\->  
 <!-\- <xsl:variable name="dml_rev" select="/plm:PLMXML/plm:ProductRevision[@id='id2']"/>
  <xsl:variable name="dml_rev_name" select="$dml_rev/plm:UserData/plm:UserValue[@title='object_name']/@value"/>
  <xsl:variable name="dml_rev_id" select="$dml_rev/@revision"/>
  <xsl:variable name="dml_ref" select="substring-after($dml_rev/@masterRef,'#')"/>-\->    
  <!-\-<xsl:variable name="dml_item" select="/plm:PLMXML/plm:Product[@id=$dml_ref]"/>
  <xsl:variable name="dml_item_id" select="$dml_item/plm:UserData/plm:UserValue[@title='item_id']/@value"/>-->

  <xsl:template match="/">

   <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
    <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
      xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:x="urn:schemas-microsoft-com:office:excel"
      xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
      xmlns:html="http://www.w3.org/TR/REC-html40">

	  <Styles>
        <Style ss:ID="s22">
          <Interior ss:Color="#C0C0C0" ss:Pattern="Solid"/>
          <Borders>
            <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
            <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
            <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
            <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
          </Borders>
          <Alignment ss:Horizontal="Center"/>	
        </Style>
		 <Style ss:ID="s21" ss:Name="ReportHeader">
		   <Interior ss:Color="#696969" ss:Pattern="Solid"/>
			<Borders >
				<Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
				<Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
				<Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
				<Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
			</Borders>
		  <Alignment ss:Horizontal="Center"/>		  
		  <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
     </Style>
	   <Style ss:ID="s23">
	      <Font ss:Color="#FF0000"/>
	   </Style>
	    <!-- fix me: may be use different color -->
	    <Style ss:ID="s24" ss:Name="DataCell">
	      <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
	      <Borders>
	        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
	        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
	        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
	        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
	      </Borders>
	      <!--<Alignment ss:Horizontal="Right"/>-->
	    </Style>
	    <Style ss:ID="s01">
	      <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
	      <Borders>
	        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
	        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
	        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
	        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
	      </Borders>
	      <Alignment ss:Horizontal="Center"/>
	    </Style>
      </Styles>

      <Worksheet ss:Name="Sheet1">

         <Table>
           <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="50" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="175" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="250" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="120" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="50" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="60" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
           <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
          <Row>
            <Cell></Cell>
            <Cell></Cell>
            <Cell></Cell>
            <Cell></Cell>			
            <Cell ss:StyleID="s21" ss:MergeAcross="3">
              <Data ss:Type="String">Report - DML Released between dates at ERC</Data>
            </Cell>
          </Row>
		  <Row>
			<Cell>
				<Data ss:Type="String">Report Date:</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="/plm:PLMXML/@date"/>
				</Data>
			</Cell>
		  </Row>
		  <!--<Row>
			<Cell>
				<Data ss:Type="String">From Date:</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				   <xsl:value-of select="/plm:PLMXML/plm:date_released_after/@date"/>
				</Data>
			</Cell>
		  </Row>-->
		 <!-- <Row>
			<Cell>
				<Data ss:Type="String">To Date:</Data>
			</Cell>
			<Cell>
				<Data ss:Type="String">
				  <xsl:value-of select="/plm:PLMXML/plm:date_released_before/@name"/>
				</Data>
			</Cell>
		  </Row>-->
		  <Row></Row>
          <Row>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">Sr. No.</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">Project ID</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">Project Description</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">Design Group</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">DML Number</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">DML Revision</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">DML Description</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">Reason Code</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">DR Status</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">DCR Status</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">Reason Description</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">ERC Released Date</Data>
            </Cell>
            <Cell ss:StyleID="s22">
              <Data ss:Type="String">Life Cycle Status</Data>
            </Cell>
          </Row>
		  
		  <xsl:call-template name="DMLDetails"/>
		 </Table>
		 <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
          <Selected/>
          <ProtectObjects>False</ProtectObjects>
          <ProtectScenarios>False</ProtectScenarios>
        </WorksheetOptions>
      </Worksheet>
	 </Workbook>

  </xsl:template>

	<xsl:template name="DMLDetails">
	  <xsl:for-each select="/plm:PLMXML/plm:ProductRevision[@subType='ChangeRequestRevision']">	    
	    <xsl:variable name="dmlElement" select="key('dmlElement',substring-after(@masterRef,'#'))"/>
	    <xsl:variable name="dmlProjElement" select="key('projectElement',substring-after(./plm:UserData/plm:UserValue[@title='owning_project']/@dataRef,'#'))"/>
	    <Row>		  
	      <Cell ss:StyleID="s01">
	        <Data ss:Type="Number"><xsl:number count="/plm:PLMXML/plm:ProductRevision[@subType='ChangeRequestRevision']"/></Data>
	      </Cell>
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:value-of select="$dmlProjElement/@projectId"/></Data>
	      </Cell>
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:value-of select="$dmlProjElement/plm:Description"/></Data>
	      </Cell>
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:value-of select="./plm:UserData/plm:UserValue[@title='t5designgroup']/@value"/></Data>
	      </Cell> 
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:value-of select="$dmlElement/plm:UserData/plm:UserValue[@title='item_id']/@value"/></Data>
	      </Cell>
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:value-of select="./plm:UserData/plm:UserValue[@title='item_revision_id']/@value"/></Data>			  
	      </Cell>
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:value-of select="./plm:UserData/plm:UserValue[@title='object_name']/@value"/></Data>
	      </Cell>
	      <xsl:variable name="reason" select="./plm:UserData/plm:UserValue[@title='t5_reason']/@value"/>
	      <!--<xsl:value-of select="key('t5_reasondisname',$reason)/@value"/>--><!--<xsl:value-of select="$reason"/>-->
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:call-template name="t5_reasonName"><xsl:with-param name="reason" select="$reason"></xsl:with-param></xsl:call-template></Data>
	      </Cell>
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:value-of select="./plm:UserData/plm:UserValue[@title='t5_cDRstatus']/@value"/></Data>
	      </Cell>
	      <Cell ss:StyleID="s24"></Cell>
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:value-of select="./plm:UserData/plm:UserValue[@title='t5_reasondesc']/@value"/></Data>
	      </Cell>
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:value-of select="substring-before(./plm:UserData/plm:UserValue[@title='date_released']/@value,'T')"/></Data>
	      </Cell>
	      <Cell ss:StyleID="s24">
	        <Data ss:Type="String"><xsl:call-template name="getReleaseStatus"><xsl:with-param name="releaseList" select="./plm:UserData/plm:UserValue[@title='release_status_list']/plm:UserList/plm:Item"/><xsl:with-param name="separator" select="'; '"></xsl:with-param></xsl:call-template></Data>
	      </Cell>
		</Row>
	  </xsl:for-each>
	</xsl:template>
  
  <xsl:template name="t5_reasonName">
    <xsl:param name="reason"/>
    <xsl:choose>
      <xsl:when test="$reason='NR'">
        <xsl:value-of select="'NEW REQUIREMENTS (NEW VC, NEW AGGREGATE)'"/>
      </xsl:when>
      <xsl:when test="$reason='AD'">
        <xsl:value-of select="'ALTERNATE SOURCE DEVELOPMENT'"/>
      </xsl:when>
      <xsl:when test="$reason='CFL'">
        <xsl:value-of select="'CHANGE IN FEATURE LIST'"/>
      </xsl:when>
      <xsl:when test="$reason='CMR'">
        <xsl:value-of select="'COMMONIZATION / STANDARDIZATION / COMPLEXITY REDUCTION'"/>
      </xsl:when>
      <xsl:when test="$reason='CR'">
        <xsl:value-of select="'COST REDUCTION'"/>
      </xsl:when>
      <xsl:when test="$reason='DR'">
        <xsl:value-of select="'DRAFTING ERROR CORRECTION / BOM-CAD QUALITY IMPROVEMENT'"/>
      </xsl:when>
      <xsl:when test="$reason='CM'">
        <xsl:value-of select="'END CUSTOMER / FIELD COMPLAINTS AND SERVICE FEEDBACK / CCT'"/>
      </xsl:when>
      <xsl:when test="$reason='PQ'">
        <xsl:value-of select="'IMPROVEMENT IN JD POWER INITIAL QUALITY SCORE'"/>
      </xsl:when>
      <xsl:when test="$reason='ICR'">
        <xsl:value-of select="'INTEGRATED COST REDUCTION'"/>
      </xsl:when>
      <xsl:when test="$reason='QR'">
        <xsl:value-of select="'QUALITY AND RELIABILITY IMPROVEMENT'"/>
      </xsl:when>
      <xsl:when test="$reason='RR'">
        <xsl:value-of select="'REGULATORY REQUIREMENT'"/>
      </xsl:when>
      <xsl:when test="$reason='SR'">
        <xsl:value-of select="'SAFETY REQUIREMENT'"/>
      </xsl:when>
      <xsl:when test="$reason='FM'">
        <xsl:value-of select="'TO FACILITATE MANUFACTURING'"/>
      </xsl:when>
      <xsl:when test="$reason='WCR'">
        <xsl:value-of select="'WARRANTY COST REDUCTION'"/>
      </xsl:when>
      <xsl:when test="$reason='WR'">
        <xsl:value-of select="'WEIGHT REDUCTION'"/>
      </xsl:when>
      
    </xsl:choose>
  </xsl:template>
  
  <xsl:template name="getReleaseStatus">
    <xsl:param name="releaseList"/>
    <xsl:param name="separator"/>
    <xsl:for-each select="$releaseList">
      <xsl:variable name="statusElement" select="key('releasestatus',@value)"/>
      <xsl:value-of select="$statusElement/@name"/>
      <!--<xsl:value-of select="@value"/>-->
      <xsl:if test="position()!=last()">
        <xsl:value-of select="$separator"/>
      </xsl:if>
    </xsl:for-each>
    
  </xsl:template>



</xsl:stylesheet>
