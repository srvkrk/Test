/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : CLTask.c
* Created By                   : Aadarsh kumar
* Created On                   : 14/02/2022
* Project                      :
* Methods Defined              :
* Description                  : Generate Estimate sheet
* Specific Notes               : ./CL_Task -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -Fromdate=01-Feb-2023 -Todate=03-Feb-2023
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <time.h>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pie/pie.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))


static int PrintErrorStack( void )
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		//fprintf( stderr, "Error(PrintErrorStack): \n");
		//fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
		printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
	}
	return ITK_ok;
}

FILE		*fp 			= NULL;
//FILE *Report;
FILE		*fp1 			= NULL;
FILE		*Report 			= NULL;
int expansionLevel = 0;
int cntflag = 0;
int Qtyflag = 0;
int ia = 0;
int times =0;
int f1 = 0;
int f2 = 0;
int f3 = 0;
int f4 = 0;
int printflag=0;
int DrStatusflag = 0;
char *Qtypart	= NULL;
char *partdiff	= NULL;
char *RevstatusN	= NULL;
char *RevstatusC	= NULL;
char *Plant	= NULL;
char **LatChildSet = NULL;
char *tempbom = NULL;
//char *symbole = "#";
char *charPtr = NULL; //my
char **childPart      = NULL;
char **childParttwo      = NULL;
char **childPartRep1      = NULL;
char **childPartRep2      = NULL;
char **childPartthree      = NULL;
char **childPartFour      = NULL;
char **childPartFive      = NULL;
char **childPartSix      = NULL;

int tt=0;
int tt1=0;
int tt2=0;
int tt3=0;
int tt4=0;
int tt5=0;
int tt6=0;
int tt7=0;
int uniquecountfirst = 0;
int uniquecounttwo = 0;
int commancountinboth = 0;
char *Value1 = NULL;
char *Value2 = NULL;
char *Value3 = NULL;

////here is the declaration of child part for add
//
//char *parent_item_idforadd = NULL;
//char *parentrev_foradd = NULL;
//char *Parentqty_foradd = NULL;
//char *parent_item_idmodadd = NULL;
//char *Parent_item_idmodName = NULL;

//time_t t = time(NULL);
//struct tm tm = *localtime(&t);
//tag_t IteamprintTagx	= NULL;
//tag_t IteamprintTagTwox	= NULL;
//char *Setofstring = NULL;
//char ***strset =  NULLTAG
//sFinalDataSet = (char **) MEM_alloc(1000 * sizeof(char *));
//LatChildSet = (char**)MEM_alloc( 1 * sizeof *LatChildSet );
void write2xml(FILE * , char*);
int ctr=0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}
static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
int i;
char *retStringf;
retStringf = (char*) malloc(200);
for(i=0; i < toCharf; i++ )
		  *(retStringf+i) = *(mainStringf+i+fromCharf);
*(retStringf+i) = '\0';
return retStringf;
}

void setAddStr(int *count,char ***strset,char* str)
{
	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);


}
;
int setFindStr1(int *count,char ***strset,char* str)
	{
		int j   =0;

		//tmp = sizeof(*strset);

		for(j=0;j<*count;j++)
		{
			printf("\n inside setFindStr1 %d \n",*count);fflush(stdout);
			//printf("\n setFindStr1 value is ===%s",(*strset)[*count-1]);fflush(stdout);
			printf("\n setFindStr1 value is ===%s",(*strset)[j]);fflush(stdout);

			//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
			if(tc_strcmp((*strset)[j],str)==0) //check this
			//if(tc_strcmp(*strset[j],str)==0)

			return j;

		}
		return -1;
	 }

void setAddStrTwo(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrtwo===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
void setAddStrThree(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrthree===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
void setAddStrFour(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrFour===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
void setAddStrFive(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrFive===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
void setAddStrSix(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrSix===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;

void setAddStrRep(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrRep1===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
void setAddStrRep2(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrRep1===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;

//	void printstrset(int count,char **strset){
//
//				for (ia =0;ia<count;ia++)
//				{
//					printf("%shere is the string set value one by one\n",strset[ia]);
//				}
//
//	}
//void addstring(int count,char* charPrt, char* str){
//					count = count+1;
//					tc_strcpy(charPrt,str);
//
//			}

//void autoresizestrAdd(char **src,char* dest)
//{
//	char * desc = dest ? dest : "NA";
//	printf("\n autoresizestrAdd desc len==%d",strlen(desc));
//	printf("this is the value of src before concadinating %s",src);
//	const size_t a = strlen(*src);
//	const size_t b = strlen(desc);
//	const size_t size_ab = a + b + 2;
//	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
//	tc_strcat(*src , desc);
//	printf("this is the value of src After concadinating %s",src);
//}

//void autoresizestrAdd2(char **src,char* dest)
//{
//	char * desc = dest ? dest : "NA";
//	//printf("\n autoresizestrAdd desc len==%d",strlen(desc));
//	const size_t a = strlen(*src);
//	const size_t b = strlen(desc);
//	const size_t size_ab = a + b + 2;
//	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
//	tc_strcat(*src , desc);
//}
//static int report_wso_object_string_and_owning_user(tag_t object)
//{
//    char *object_string = NULL;
//    char *owning_user = NULL;
//    char *item_id = NULL;
//    char *date_released = NULL;
//    //ITK_CALL(WSOM_ask_object_id_string(object, &object_string));
//    //ITK_CALL(AOM_UIF_ask_value(object, "owning_user", &owning_user));
//    ITK_CALL(AOM_UIF_ask_value(object, "item_id", &item_id));
//    ITK_CALL(AOM_UIF_ask_value(object, "date_released", &date_released));
//    //printf("       %s - %s \n", object_string, owning_user);
//    printf("%s %s\n", item_id,date_released);
//    //MEM_free(object_string);
//    //MEM_free(owning_user);
//	MEM_free(item_id);
//	MEM_free(date_released);
//	return ITK_ok;
//}
/************main function*******************/
int ITK_user_main (int argc, char ** argv )
{
	FILE *fp;
	FILE *fp1;
	int ifail = ITK_ok;
	int	n_rev_entries = 2;
	int	n_rev_entriestwo = 2;
	int status = 0;
	int n_tags_found1 = 0;
	int n_tags_found2 = 0;
	int Count = 0;
	int ij = 0;
	int ik = 0;
	int It = 0;
	int Itt = 0;
	int pCnt = 0;
	int pCnt1 = 0;
	int rev_cnt = 0;
	int rev_cnttwo = 0;
	int n_attchsNON1 = 0;
	int n_attchsNON2 = 0;
	int RCnt = 0;
	int revCnt = 0;
	int PartCnt = 0;
	int PartCnt1 = 0;
	int num_to_sort = 1;
	int one_entry = 1;
	int QryOPCount = 0;
	int sort_order[1]  ={2};
	int no_bom_linesO=0;
	int no_bom_linesT=0;
	//int tt = 0;
	int m =0;
	int m1 =0;
	int m2 =0;
	int b =0;
	int rulefound = 0;
	int transfermode1Cnt = 0;
	int depthExpandVC1 = 0;
	int depthExpandVC2 = 0;
	int depthforfind1 = 0;
	int depthforfind2 = 0;
	int depthforfind3 = 0;
	int depthforprint1 = 0;
	int depthforprint2 = 0;
	int depthforprint3 = 0;
	int rulefoundqty = 0;
	int ctr = 0;
	int rulefoundtwo = 0;
	//int ifail;
	char *qry_entries[2] = {"Item ID","Revision"};
	char *qry_entriesTwo[2] = {"Item ID","Revision"};
	//char *qry_entries[1] = {"ID"};
	char *sUserName		=   NULL;
	char *sPassword		=   NULL;
	char *sgrp		=   NULL;
	char *IteamNumberone		=	NULL;
	char *IteamNumberTwo		=	NULL;
	char *PartNumC	=	NULL;
	char *PartNumCDup	=	NULL;
	char *DmlprojectcodeDup	=	NULL;
	char *RelStat		=	NULL;
	char *RelStatDup		=	NULL;
	char *RevSeq		=	NULL;
	char *partClrInd		=	NULL;
	char *partClrIndDup		=	NULL;
	char **valuesone             = NULL;
	char **valuesTwo             = NULL;
	char **rulename				 = NULL;
	char **rulevalue			 = NULL;
	char *itemid	    =   NULL;
	char *itemidDup	    =   NULL;
	char	*PrtNoone			= NULL;
	char	*PrtNoTwo			= NULL;
	//char *ReferStd_cnt	    =   NULL;
	char *Fromdate	    =   NULL;
	char *Todate	    =   NULL;
	char* CLName;
	char lineRead[500];
	char* CLNum = NULL;
	char* CLNump = NULL;
	char* PartName = NULL;
	char    *Assym1			= NULL;
	char    *Rev1			= NULL;
	char    *Seq1			= NULL;
	char    *Assym2			= NULL;
	char    *Rev2			= NULL;
	char    *Seq2			= NULL;
	char	*PrtNooneRevId		= NULL;
	char	*PrtNoTwoRevId		= NULL;
	char	*PrtNoOneSeqId		= NULL;
	char	*PrtNoTwoSeqId		= NULL;
	char* Dmlprojectcode = NULL;
	char* NonColorPar1 = NULL;
	char* NonColorPar2 = NULL;
	char* PartName1 = NULL;
	char* NonColorPart = NULL;
	char* objtype = NULL;
	char* objtypep = NULL;
	char* objtyperev = NULL;
	//char* ChPartTags = NULL;
	char* CLNumDup = NULL;
	char* CLNumpDup = NULL;
	char* DMLStr = NULL;
	char* PartNameDup = NULL;
	char* PartNameDup1 = NULL;
	char* NonColorPartDup1 = NULL;
	char* NonColorPartDup2 = NULL;
	char* objtypeDup = NULL;
	char* objtypepDup = NULL;
	char* objtyperevDup = NULL;
	char *keysAttr[1]		    =  {"creation_date"};
	char *RevisionRule	    = NULL;
	char *ClosureView	    = NULL;
	char *Date	    = NULL;
	char *WithoutZeroQty	    = NULL;
	char *RRForNewVC	    = NULL;
	char *RRForRefVC	    = NULL;
	char *ClosureVForNewVC	    = NULL;
	char *ClosureVForRefVC	    = NULL;
	//char *Plant	    = NULL;
	char* DmlRelType	= NULL;
	char* PrtNooneDup1 = NULL;
	char* IteamNumberoneDup = NULL;
	char* IteamNumberTwoDup = NULL;
	char* PrtNoTwoDup2 = NULL;
	char* PrtNoTwoRevIdDup2 = NULL;
	char* PrtNoTwoSeqIdDup2 = NULL;
	char* RevSeqCat1 = NULL;
	char* RevSeqCat2 = NULL;
	char *expansionLvl = NULL;
	char *Without_underscore = NULL;
	char *Stop_AT_F = NULL;
	char *tokenX = NULL;
	char *tokenX2 = NULL;
	char *tokenX3 = NULL;
	char *IteamNumberonecompare = NULL;
	char *ChildRevSeqTwo = NULL;
	char *ChildDescTwo = NULL;
	char *UserID = NULL;
	//char			fpFile[200]				= "";
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesTwo = (char **) MEM_alloc(10 * sizeof(char *));
	childPart = (char**)MEM_alloc( 1000 * sizeof *childPart );
	childParttwo = (char**)MEM_alloc( 1000 * sizeof *childParttwo );
	childPartthree = (char**)MEM_alloc( 1000 * sizeof *childPartthree );
	childPartFour = (char**)MEM_alloc( 1000 * sizeof *childPartFour );
	childPartFive = (char**)MEM_alloc( 1000 * sizeof *childPartFive );
	childPartSix = (char**)MEM_alloc( 1000 * sizeof *childPartSix );
	childPartRep1 = (char**)MEM_alloc( 1000 * sizeof *childPartRep1 );
	childPartRep2 = (char**)MEM_alloc( 1000 * sizeof *childPartRep2 );
	tag_t   Query_Tag    = NULLTAG;
	tag_t	PartTag		      = NULLTAG;
	tag_t	PartTagC		      = NULLTAG;
    tag_t *items              = NULL;
    tag_t *ColPartTags              = NULL;
	tag_t   CL_TASK_Query    = NULLTAG;
	tag_t	CLTag		      = NULLTAG;
	tag_t	tRelationFindOne	  = NULLTAG;
	tag_t	tRelationFindTwo	  = NULLTAG;
	tag_t		AssemoneQuery			= NULLTAG;
	tag_t		AssemTwoQuery			= NULLTAG;
	tag_t		CLprintTag			= NULLTAG;
	tag_t		PartTag1			= NULLTAG;
	tag_t		PartTag2			= NULLTAG;
	tag_t		PartTag3			= NULLTAG;
	tag_t		PartTag4			= NULLTAG;
	tag_t		PartTag5			= NULLTAG;
	tag_t		ERCDMLTag			= NULLTAG;
	tag_t		ERCDMLQry			= NULLTAG;
	tag_t		*ChPartTags			= NULLTAG;
	tag_t		*allRevTag			= NULLTAG;
	tag_t		*ChPartTags1			= NULLTAG;
	tag_t		*secondary_objects1			= NULLTAG;
	tag_t		*secondary_objects2		= NULLTAG;
	tag_t		*ERCDMLTags				= NULLTAG;
	tag_t		*closureruletwo			= NULL;
	tag_t		*rev_list_set		= NULLTAG;
	tag_t		*rev_list_settwo		= NULLTAG;
	tag_t		 Obj_tagone				= NULLTAG;
	tag_t		 Obj_tagtwo				=	NULLTAG;
	tag_t		 Rev_tone				= NULLTAG;
	tag_t		 Rev_tTwo				= NULLTAG;
	tag_t		*t_allrevdocs              = NULL;
	tag_t		*t_allrevdocsTwo              = NULL;
	tag_t		*child_bom_linesOne		= NULLTAG;
	tag_t		*child_bom_linesTwo		= NULLTAG;
	tag_t		*closurerule			= NULL;
	tag_t		*transfermodes1			= NULLTAG;
	tag_t		*Partclosurerule			= NULLTAG;
	tag_t		IteamprintTag			= NULLTAG;
	tag_t		Bomlinetagone			= NULLTAG;
	tag_t		windowVCO				= NULLTAG;
	tag_t		windowVCT				= NULLTAG;
	tag_t		ruleone					= NULLTAG;
	tag_t		ruleTwo					= NULLTAG;
	tag_t		top_lineVCO				= NULLTAG;
	tag_t		top_lineVCT				= NULLTAG;
	tag_t		IteamprintTagTwo		= NULLTAG;
	tag_t		Bomlinetagonex		= NULLTAG;
	tag_t		Partclose_tag		= NULLTAG;
	tag_t		close_tag;
	tag_t		close_tagtwo;
	char **Partrulenamee = NULL;
	char **Partrulevaluee = NULL;
	char                 command[200];
//	char **LatChildSet = NULL;
//	//sFinalDataSet = (char **) MEM_alloc(1000 * sizeof(char *));
//	LatChildSet = (char**)MEM_alloc( 1 * sizeof *LatChildSet );

//	time_t 	now;
//	struct 	tm when;
//	time(&now);
//	when = *localtime(&now);
//	oFile = (char *) MEM_alloc(100 * sizeof(char));
//	strftime(Data,100,"%d_%m_%Y",&when);
//	tc_strcpy(oFile,"");
//	tc_strcat(oFile,mode);
//	tc_strcat(oFile,"_BOMDiff_");
//	tc_strcat(oFile,Data);
//	tc_strcat(oFile,".txt");
//	sprintf(fpFile,oFile);
//	sprintf(fpFileClr,"ForClrInputList_%s.txt",Data);

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));
	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	sgrp = ITK_ask_cli_argument("-g=");
	Assym1 = ITK_ask_cli_argument("-New_VC=");
	Rev1 = ITK_ask_cli_argument("-Revision1=");
	Seq1 = ITK_ask_cli_argument("-Sequence1=");
	RRForNewVC = ITK_ask_cli_argument("-RRForNewVC=");
	ClosureVForNewVC = ITK_ask_cli_argument("-ClosureVForNewVC=");
	Assym2 = ITK_ask_cli_argument("-Ref_VC=");
	Rev2 = ITK_ask_cli_argument("-Revision2=");
	Seq2 = ITK_ask_cli_argument("-Sequence2=");
	//ViewS = ITK_ask_cli_argument("-ViewS=");
	RRForRefVC = ITK_ask_cli_argument("-RRForRefVC=");
	ClosureVForRefVC = ITK_ask_cli_argument("-ClosureVForRefVC=");
	Plant = ITK_ask_cli_argument("-Plant=");
	WithoutZeroQty = ITK_ask_cli_argument("-WithoutZeroQty=");
	expansionLvl = ITK_ask_cli_argument("-level=");
	Without_underscore = ITK_ask_cli_argument("-Without_underscore=");
	Stop_AT_F = ITK_ask_cli_argument("-Stop_AT_F=");
	UserID = ITK_ask_cli_argument("-UserID=");
	//char quotedRRForNewVC[1024];
	//snprintf(quotedRRForNewVC, sizeof(quotedRRForNewVC), "\\\"%s\\\"", RRForNewVC);
	printf("\n\t INSIDE Add_delete_Report_shell_redirect shell 2c9 \n");fflush(stdout);
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_auto_login();
	ITK_CALL(ITK_set_bypass(true));
	/**Added BY Aadarsh kumar for control object for shell re-direct**/
	int n_entry    = 1;
	int rsltCount    = 1;
	tag_t   qryTag     = NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	char   *qry_entry[1]  = {"SYSCD"};
	char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char* userSpareinfo1 = NULL;
	char* userSpareinfo2 = NULL;
	tag_t CntrlObjectObj = NULLTAG;
	printf("\n Add_delete_Report_shell_redirect-->Printing before Control object executing\n");fflush(stdout);
	if(QRY_find2("ControlObjects", &qryTag));
	if (qryTag)
	{
		printf("\n Add_delete_Report_shell_redirect-->Output location:Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n Add_delete_Report_shell_redirect-->Output location:Not Found Query ControlObjects \n");fflush(stdout);
	}
	
	qry_values2[0] = "Add_delete_Report_shell_redirect";

	if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
	printf(" \n Add_delete_Report_shell_redirect-->Output value:rsltCount 11:%d:", rsltCount); fflush(stdout);
	if(rsltCount > 0)
	{
		CntrlObjectObj = CntrlObjectTag[0];
		if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo1",&userSpareinfo1)!=ITK_ok)PrintErrorStack();
		//if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo2",&userSpareinfo2)!=ITK_ok)   PrintErrorStack();
		printf(" \n Add_delete_Report_shell_redirect-->userSpareinfo1= [%s]",userSpareinfo1); fflush(stdout);
	}
	else
	{
		printf(" \n Add_delete_Report_shell_redirect-->Spare_kit_Report control object not found hence exit from code...\n"); fflush(stdout);
		return 1;
	}
	if (tc_strcmp(userSpareinfo1,"ERCDEV")==0)
	{
		printf(" \n Calling shell for ERCDEV\n"); fflush(stdout);
		sprintf(command,"/home/ercdev/devgroups/Aadarsh/Add_Delete_report_User_attachment/plmtvap01.sh \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" ",sUserName,sPassword,sgrp,Assym1,Rev1,Seq1,RRForNewVC,ClosureVForNewVC,Assym2,Rev2,Seq2,RRForRefVC,ClosureVForRefVC,Plant,WithoutZeroQty,expansionLvl,Without_underscore,Stop_AT_F,UserID);

	}
	else if (tc_strcmp(userSpareinfo1,"CVPROD")==0)
	{
		printf(" \n Calling shell for CVPROD\n"); fflush(stdout);
		//sprintf(command,"/user/cvprod/shells/Report/Add_delete/Adddeletion_2C9.sh \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" ",Assym1,Rev1,Seq1,RRForNewVC,ClosureVForNewVC,Assym2,Rev2,Seq2,RRForRefVC,ClosureVForRefVC,Plant,WithoutZeroQty,expansionLvl,Without_underscore,Stop_AT_F,UserID);
		sprintf(command,"/user/cvprod/Aadarsh/Add_delete_Replace/Adddeletion_2C9.sh \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" ",Assym1,Rev1,Seq1,RRForNewVC,ClosureVForNewVC,Assym2,Rev2,Seq2,RRForRefVC,ClosureVForRefVC,Plant,WithoutZeroQty,expansionLvl,Without_underscore,Stop_AT_F,UserID);

	}
	else if (tc_strcmp(userSpareinfo1,"UAPROD")==0)
	{
		printf(" \n Calling shell for UAPROD\n"); fflush(stdout);
		sprintf(command,"/user/uaprod/shells/Report/Add_delete/Adddeletion_2c4.sh \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" ",Assym1,Rev1,Seq1,RRForNewVC,ClosureVForNewVC,Assym2,Rev2,Seq2,RRForRefVC,ClosureVForRefVC,Plant,WithoutZeroQty,expansionLvl,Without_underscore,Stop_AT_F,UserID);
	}
	else if (tc_strcmp(userSpareinfo1,"CMITEST")==0)
	{
		printf(" \n Calling shell for CMITEST\n"); fflush(stdout);
		sprintf(command,"/home/cmitest/shells/Add_delete/AdddeletionCMITEST.sh \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" ",Assym1,Rev1,Seq1,RRForNewVC,ClosureVForNewVC,Assym2,Rev2,Seq2,RRForRefVC,ClosureVForRefVC,Plant,WithoutZeroQty,expansionLvl,Without_underscore,Stop_AT_F,UserID);
	}
	//sprintf(command,"/user/cvprod/Aadarsh/spare_kit_report/Sapre_Report_2C9.sh %s %s %s %s %s %s",Assym1,Rev1,Seq1,RRForNewVC,ClosureViewNewVC,UserID);
	TC_write_syslog("Command = %s\n",command);
	system(command);				
	
	return ifail;
}