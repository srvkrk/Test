#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include <unidefs.h>
//#include <itk/mem.h>
#include <tcinit/tcinit.h>
//#include <sa/imanfile.h>
#include <sa/tcfile.h>
#include <fclasses/tc_string.h>
//#include <tc/tc.h>
#include <tccore/item_errors.h>
#include <tccore/aom.h>
#include <sa/tcfile.h>
#include <tccore/aom_prop.h>
#define _DEBUG
#include <tccore/grm.h>
#include <ae/dataset.h>
#include <tccore/item.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <sa/sa.h>
int ltst_Veh_CL();
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
	char *refname[AE_reference_size_c + 1];
	AE_reference_type_t reftype;
int		status				= 0;

#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"



#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
		}																	\
	;
static int PrintErrorStack( void )
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
	for ( i = 0; i < iNumErrs; i++ )
	{
		//fprintf( stderr, "Error(PrintErrorStack): \n");
		//fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
		printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
	}
	return ITK_ok;
}
int ITK_user_main(int argc, char* argv[])
{
				char				* u			= NULL;
				char				* p			= NULL;
				char				* g			= NULL;
				char				* Assym1			= NULL;
				char				* Rev			= NULL;
				char				* Date			= NULL;
				char				* Rev1		= NULL;
				char				* Seq1		= NULL;
				char				* RRForNewVC		= NULL;
				char				* ClosureViewNewVC	= NULL;
				char				* UserID			= NULL;
				int					 ifail   = ITK_ok;
				char                 command[200];

//				u = ITK_ask_cli_argument("-u=");
//				p = ITK_ask_cli_argument("-pf=");
//				g = ITK_ask_cli_argument("-g=");
				Assym1 = ITK_ask_cli_argument("-VC=");
				Rev = ITK_ask_cli_argument("-Rev=");
				Date = ITK_ask_cli_argument("-Date=");
				UserID = ITK_ask_cli_argument("-UserID=");

				//char quotedRRForNewVC[1024];
				//snprintf(quotedRRForNewVC, sizeof(quotedRRForNewVC), "\\\"%s\\\"", RRForNewVC);
				//status=ITK_init_module(u, p, g);
				printf("\n\t INSIDE PDSR_Summary_Report shell \n");fflush(stdout);
				ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
				ITK_auto_login();
				//status=ITK_init_module(u, p, g);
				ITK_CALL(ITK_set_bypass(true));
				//status=ITK_init_module(u, p, g);
				/**Added BY Aadarsh kumar for control object for shell re-direct**/
				int n_entry    = 1;
				int rsltCount    = 1;
				tag_t   qryTag     = NULLTAG;
				tag_t   *CntrlObjectTag      = NULLTAG;
				char   *qry_entry[1]  = {"SYSCD"};
				char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
				char* userSpareinfo1 = NULL;
				char* userSpareinfo2 = NULL;
				tag_t CntrlObjectObj = NULLTAG;
				printf("\n PDSR_Summary_Report_shell_redirect-->Printing before Control object executing\n");fflush(stdout);
				if(QRY_find2("ControlObjects", &qryTag));
				if (qryTag)
				{
					printf("\n PDSR_Summary_Report_shell_redirect-->Output location:Found Query ControlObjects \n");fflush(stdout);
				}
				else
				{
					printf("\n PDSR_Summary_Report_shell_redirect-->Output location:Not Found Query ControlObjects \n");fflush(stdout);
				}

				qry_values2[0] = "PDSR_Report_shell_redirect";

				if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
				printf(" \n PDSR_Summary_Report_shell_redirect-->Output value:rsltCount 11:%d:", rsltCount); fflush(stdout);
				if(rsltCount > 0)
				{
					CntrlObjectObj = CntrlObjectTag[0];
					if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo1",&userSpareinfo1)!=ITK_ok)   PrintErrorStack();
					//if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo2",&userSpareinfo2)!=ITK_ok)   PrintErrorStack();
					printf(" \n PDSR_Summary_Report_shell_redirect-->userSpareinfo1= [%s]",userSpareinfo1); fflush(stdout);
				}
				else
				{
					printf(" \n PDSR_Summary_Report_Report-->PDSR_Summary_Report control object not found hence exit from code...\n"); fflush(stdout);
					return 1;
				}
				if (tc_strcmp(userSpareinfo1,"ERCDEV")==0)
				{
					printf(" \n Calling shell for ERCDEV\n"); fflush(stdout);
					//sprintf(command,"/home/ercdev/devgroups/Aadarsh/PDSR_Summary_Report/plmtvap01.sh %s %s %s %s %s",u,p,g,Assym1,Rev,Date,UserID);
					//sprintf(command,"/home/ercdev/devgroups/Aadarsh/PDSR_Summary_Report_Extansion/plmtvap01.sh %s %s %s %s %s %s %s",u,p,g,Assym1,Rev,Date,UserID);
					sprintf(command,"/home/ercdev/devgroups/Aadarsh/PDSR_Summary_Report_Extansion/plmtvap01.sh \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\"",u, p, g, Assym1, Rev, Date, UserID);

				}
				else if (tc_strcmp(userSpareinfo1,"CVPROD")==0)
				{
					printf(" \n Calling shell for CVPROD\n"); fflush(stdout);
					//sprintf(command,"/user/cvprod/shells/Report/PDSR_Summary_Report/PDSR_Report_2C9.sh %s %s %s %s",Assym1,Rev,Date,UserID);
					sprintf(command,"/user/cvprod/shells/Report/PDSR_Summary_Report/PDSR_Report_2C9.sh \"%s\" \"%s\" \"%s\" \"%s\"",Assym1,Rev,Date,UserID);
				}
				else if (tc_strcmp(userSpareinfo1,"UAPROD")==0)
				{
					printf(" \n Calling shell for UAPROD\n"); fflush(stdout);
					sprintf(command,"/user/uaprod/shells/Report/PDSR_Summary_Report/PDSR_Report_2c4.sh \"%s\" \"%s\" \"%s\" \"%s\"",Assym1,Rev,Date,UserID);
				}
				else if (tc_strcmp(userSpareinfo1,"CMITEST")==0)
				{
					printf(" \n Calling shell for CMITEST\n"); fflush(stdout);
					sprintf(command,"/home/cmitest/shells/PDSR_Summary_Report/PDSR_ReportCMITEST.sh \"%s\" \"%s\" \"%s\" \"%s\"",Assym1,Rev,Date,UserID);
				}
				//sprintf(command,"/user/cvprod/Aadarsh/spare_kit_report/Sapre_Report_2C9.sh %s %s %s %s %s %s",Assym1,Rev1,Seq1,RRForNewVC,ClosureViewNewVC,UserID);
				TC_write_syslog("Command = %s\n",command);
				system(command);				
				
				return ifail;
}


					


