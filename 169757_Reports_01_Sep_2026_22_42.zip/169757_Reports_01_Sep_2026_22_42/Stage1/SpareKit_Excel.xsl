<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet  version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xd="http://www.oxygenxml.com/ns/doc/xsl"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40"
    xmlns:tml="urn:tata-plmxml-schema"
   exclude-result-prefixes="xd">

    <xd:doc scope="stylesheet">
        <xd:desc>
            <xd:p><xd:b>Created on:</xd:b> Sept 04, 2019</xd:p>
            <xd:p><xd:b>Author:</xd:b>aww917697</xd:p>
            <xd:p></xd:p>
        </xd:desc>
    </xd:doc>

    <xsl:output method="xml" version="1.0" indent="yes"/>

    <xsl:strip-space elements="*"/>

    <!-- Define global parameters -->
    <xsl:param name="primaryOccRef" select="/plm:PLMXML/plm:ProductView/@primaryOccurrenceRef"/>
    <xsl:param name="rootProductID" select="substring-after(/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$primaryOccRef]/@instancedRef,'#')"/>

    <!-- Define key functions -->
    <xsl:key name="designrev"           match="plm:DesignRevision"  use="@id"/>
    <xsl:key name="productrev"          match="plm:ProductRevision" use="@id"/>
	<xsl:key name="sparekitrev"           match="plm:DesignRevision[@subType='T5_SparKitRevision']" use="@id"/>
    <xsl:key name="changerev"           match="plm:ProductRevision[@subType='ChangeRequestRevision']" use="@id"/>
    <xsl:key name="changetaskrev"       match="plm:ProductRevision[@subType='T5_ChangeTaskRevision']" use="@id"/>
    <xsl:key name="dataset"             match="plm:DataSet"         use="@id"/>
    <xsl:key name="occurrence"          match="plm:Occurrence"      use="@id"/>
    <xsl:key name="design"              match="plm:Design"          use="@id"/>
    <xsl:key name="product"             match="plm:Product"         use="@id"/>
    <xsl:key name="releasestatus"       match="plm:ReleaseStatus"   use="@id"/>
    <xsl:key name="user"                match="plm:User"            use="@id"/>
    <xsl:key name="uom"                 match="plm:Unit"            use="@id"/>
    
    <xsl:template match="/">
        <xsl:variable name="topDesign" select="key('designrev',$rootProductID)"/>
        <xsl:variable name="topProduct" select="key('productrev',$rootProductID)"/>
     
        <xsl:call-template name="BOMReportHeader">
            <xsl:with-param name="currentElement" select="$topDesign"/>
            <xsl:with-param name="parentOccurrenceID" select="$primaryOccRef"/>
        </xsl:call-template>
        
    </xsl:template>

    <xsl:template name="BOMReportHeader">
        <xsl:param name="currentElement"/>
        <xsl:param name="parentOccurrenceID"/>

        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">

            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
				   <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
				   <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
				<Style ss:ID="s32" ss:Name="TOPDataCell">
					<Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>           
					<Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#BBFF99" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s25" ss:Name="ChildDataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s26" ss:Name="SpareKITDataCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#ffff66" ss:Pattern="Solid"/>
                </Style>
            </Styles>

            <Worksheet ss:Name="Sheet1">

                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="30" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="120" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="50" AutoFitWidth="1"/><!--Column : 5-->
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="60" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/><!--Column : 10-->
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/> 
                    <Column ss:AutoFitWidth="0" ss:Width="120" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/><!--Column : 15-->
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/> 
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
   
                    
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s21" ss:MergeAcross="3"><Data ss:Type="String">SpareKit Report</Data></Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String">Report Date</Data></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String"><xsl:call-template name="sortReportDate"></xsl:call-template></Data></Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String">Part Number</Data></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String"><xsl:value-of select="$currentElement/plm:UserData/plm:UserValue[@title='item_id']/@value"/></Data></Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String">Revision Rule</Data></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:RevisionRule/@name"/></Data></Cell>
                    </Row>
                    <Row></Row>
                    <Row></Row>
                    <Row>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Level</Data></Cell>
						<Cell ss:StyleID="s22"><Data ss:Type="String">Class</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Part No</Data></Cell>						
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Description</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Quantity</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Revision Seq</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Project Code</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Design Group</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Weight</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Spare Indicator</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Part Catogory</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Party Part Number</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Owner</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">DML</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Release Date</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Release Type</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Lifecycle State</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Envelope Dimensions</Data></Cell>
                    </Row>
                    <xsl:call-template name="generateReportData">
                        <xsl:with-param name="currentElement" select="$currentElement"/>
                        <xsl:with-param name="parentOccuranceId" select="$parentOccurrenceID"/>
                    </xsl:call-template>
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    
    <xsl:template name="generateReportData">
        <xsl:param name="currentElement"/>
        <xsl:param name="parentOccuranceId"/>
        <xsl:call-template name="generateTopProductData">
            <xsl:with-param name="desgrevElement" select="$currentElement"/>
            <xsl:with-param name="parentOccurenceID" select="$parentOccuranceId"/>

        </xsl:call-template>

        <xsl:call-template name="generateChildProductData">
            <xsl:with-param name="desgrevElement" select="$currentElement"/>
            <xsl:with-param name="parentOccurenceID" select="$parentOccuranceId"/>
        </xsl:call-template>
    </xsl:template>

    <xsl:template name="generateTopProductData">
        <xsl:param name="desgrevElement"/>
        <xsl:param name="parentOccurenceID"/>		

        <Row>
            <Cell ss:StyleID="s32"><Data ss:Type="Number">0</Data></Cell>
			 <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_PartType']/@value"/></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='item_id']/@value"/></Data></Cell>        
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:Description"/></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData[2]/plm:UserValue[@title='Quantity']/@value"/></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='current_revision_id']/@value"/></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_ProjectCode']/@value"/></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_DesignGrp']/@value"/></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_Weight']/@value"/></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_SpareInd']/@value"/></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_SpareCriteria']/@value"/></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_RefPartNumber']/@value"/></Data></Cell>
			<Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:call-template name="getUserID">
            <xsl:with-param name="userRefId" select="substring-after($desgrevElement/plm:UserData/plm:UserValue[@title='owning_user']/@dataRef,'#')"></xsl:with-param>
            </xsl:call-template></Data></Cell>
			<Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:call-template name="getDMLProperty"><xsl:with-param name="currentRevID" select="$desgrevElement/@id"/><xsl:with-param name="propName" select="'item_id'"></xsl:with-param></xsl:call-template></Data></Cell>
			<Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:call-template name="sortDate"><xsl:with-param name="inDate" select="$desgrevElement/plm:UserData/plm:UserValue[@title='date_released']/@value"></xsl:with-param></xsl:call-template></Data></Cell>
			<Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:call-template name="getDMLProperty"><xsl:with-param name="currentRevID" select="$desgrevElement/@id"/><xsl:with-param name="propName" select="'t5_rlstype'"></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:call-template name="getReleaseStatus"><xsl:with-param name="releaseList" select="$desgrevElement/plm:UserData/plm:UserValue[@title='release_status_list']/plm:UserList/plm:Item"/><xsl:with-param name="separator" select="';'"></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell ss:StyleID="s32"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_EnvelopeDimensions']/@value"/></Data></Cell>
        </Row>

					<xsl:call-template name="getSparekitDetails">
							 <xsl:with-param name="currentRevID" select="$desgrevElement/@id"/>
                    </xsl:call-template>

    </xsl:template>

    <xsl:template name="generateChildProductData">
        <xsl:param name="desgrevElement"/>
        <xsl:param name="parentOccurenceID"/>

        <xsl:variable name="occRefs" select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$parentOccurenceID]/@occurrenceRefs"/>
        <xsl:variable name="parentRefID" select="substring-after(/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$parentOccurenceID]/@instancedRef,'#')"/>

        <xsl:call-template name="CreateCL">
            <xsl:with-param name="occStr" select="$occRefs"/>
            <xsl:with-param name="levelID">1</xsl:with-param>
            <xsl:with-param name="parentRefID" select="$parentRefID"/>
        </xsl:call-template>

    </xsl:template>

    <xsl:template name="CreateCL">
        <xsl:param name="occStr"/>
        <xsl:param name="levelID"/>
        <xsl:param name="parentRefID"/>

        <xsl:if test="$occStr!=''">
            <xsl:choose>
                <xsl:when test="contains($occStr,' ')">
                    <xsl:variable name="occid" select="substring-before($occStr,' ')"/>
                    <xsl:call-template name="CreateCL">
                        <xsl:with-param name="occStr" select="$occid"/>
                        <xsl:with-param name="levelID" select="$levelID"/>
                        <xsl:with-param name="parentRefID" select="$parentRefID"/>
                    </xsl:call-template>

                    <xsl:call-template name="CreateCL">
                        <xsl:with-param name="occStr" select="substring-after($occStr,' ')"/>
                        <xsl:with-param name="levelID" select="$levelID"/>
                        <xsl:with-param name="parentRefID" select="$parentRefID"/>
                    </xsl:call-template>

                </xsl:when>

                <xsl:otherwise>
                    <xsl:call-template name="creCLextSort">
                        <xsl:with-param name="occID" select="$occStr"/>
                        <xsl:with-param name="levelID" select="$levelID"/>
                        <xsl:with-param name="parentRefID" select="$parentRefID"/>
                    </xsl:call-template>

                </xsl:otherwise>
            </xsl:choose>
        </xsl:if>
    </xsl:template>

    <xsl:template name="creCLextSort">
        <xsl:param name="occID"/>
        <xsl:param name="levelID"/>
        <xsl:param name="parentRefID"/>

        <xsl:variable name="occurenceElement" select="key('occurrence',$occID)"/>
        <xsl:variable name="occRefs" select="$occurenceElement/@occurrenceRefs"/>
        <xsl:variable name="revRef" select="substring-after($occurenceElement/@instancedRef,'#')"/>

        <xsl:variable name="designRevElement" select="key('designrev',$revRef)"/>
        <xsl:variable name="productRevElement" select="key('productrev',$revRef)"/>

        <xsl:choose>
            <xsl:when test="$designRevElement != ''">
                <xsl:call-template name="creCLext">
                    <xsl:with-param name="currentRevElement" select="$designRevElement"/>
                    <xsl:with-param name="levelID" select="$levelID"/>
                    <xsl:with-param name="parentElementID" select="$parentRefID"/>
                    <xsl:with-param name="occRefs" select="$occRefs"/>
                    <xsl:with-param name="occurencElement" select="$occurenceElement"/>
                </xsl:call-template>
            </xsl:when>
            <xsl:when test="$productRevElement !=''">
                <xsl:call-template name="creCLext">
                    <xsl:with-param name="currentRevElement" select="$productRevElement"/>
                    <xsl:with-param name="levelID" select="$levelID"/>
                    <xsl:with-param name="parentElementID" select="$parentRefID"/>
                    <xsl:with-param name="occRefs" select="$occRefs"/>
                    <xsl:with-param name="occurencElement" select="$occurenceElement"/>
                </xsl:call-template>
            </xsl:when>
        </xsl:choose>

    </xsl:template>

    <xsl:template name="creCLext">
        <xsl:param name="currentRevElement"/>
        <xsl:param name="levelID"/>
        <xsl:param name="parentElementID"/>
        <xsl:param name="occRefs"/>
        <xsl:param name="occurencElement"/>

        <xsl:variable name="parentDesElement" select="key('designrev',$parentElementID)"/>
        <xsl:variable name="parentProdElement" select="key('productrev',$parentElementID)"/>        
        <xsl:variable name="currentDesElement" select="key('design',substring-after($currentRevElement/@masterRef,'#'))"/>


        <Row>
			
			<Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="Number"><xsl:value-of select="$levelID"/></Data></Cell>
			
			 <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getT5_PartType"><xsl:with-param name="value" select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_PartType']/@value"></xsl:with-param></xsl:call-template></Data></Cell>	

            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='item_id']/@value"/></Data></Cell>
			
				
             <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:Description"/></Data></Cell>

			<Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$occurencElement/plm:UserData[2]/plm:UserValue[@title='Quantity']/@value"/></Data></Cell>
				
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='current_revision_id']/@value"/></Data></Cell>
				

            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_ProjectCode']/@value"/></Data></Cell>
				
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_DesignGrp']/@value"/></Data></Cell>
				

            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_Weight']/@value"/></Data></Cell> 
				

            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_SpareInd']/@value"/></Data></Cell>
				

            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_SpareCriteria']/@value"/></Data></Cell>
				

            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_RefPartNumber']/@value"/></Data></Cell>
				
			<Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getUserID"><xsl:with-param name="userRefId" select="substring-after($currentRevElement/plm:UserData/plm:UserValue[@title='owning_user']/@dataRef,'#')"></xsl:with-param></xsl:call-template></Data></Cell>
	
			 <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
				<Data ss:Type="String"><xsl:call-template name="getDMLProperty"><xsl:with-param name="currentRevID" select="$currentRevElement/@id"/><xsl:with-param name="propName" select="'item_id'"></xsl:with-param></xsl:call-template></Data></Cell>
				
			<Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
				<Data ss:Type="String"><xsl:call-template name="sortDate"><xsl:with-param name="inDate" select="$currentRevElement/plm:UserData/plm:UserValue[@title='date_released']/@value"></xsl:with-param></xsl:call-template></Data></Cell>


			 <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
				<Data ss:Type="String"><xsl:call-template name="getDMLProperty"><xsl:with-param name="currentRevID" select="$currentRevElement/@id"/><xsl:with-param name="propName" select="'t5_rlstype'"></xsl:with-param></xsl:call-template></Data></Cell>
			

			<Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getReleaseStatus"><xsl:with-param name="releaseList" select="$currentRevElement/plm:UserData/plm:UserValue[@title='release_status_list']/plm:UserList/plm:Item"/><xsl:with-param name="separator" select="';'"></xsl:with-param></xsl:call-template></Data></Cell>
				

            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='Design Revision'">s25</xsl:when><xsl:otherwise>s25</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_EnvelopeDimensions']/@value"/></Data></Cell>
				
        </Row>

		<xsl:call-template name="getSparekitDetails">
                        <xsl:with-param name="currentRevID" select="$currentRevElement/@id"/>
                    </xsl:call-template>

        <xsl:choose>
            <xsl:when test="$occRefs!=''">
                <xsl:call-template name="CreateCL">
                    <xsl:with-param name="occStr" select="$occRefs"/>
                    <xsl:with-param name="levelID" select="$levelID+1"/>
                    <xsl:with-param name="parentRefID" select="$currentRevElement/@id"></xsl:with-param>
                </xsl:call-template>
            </xsl:when>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="replaceText">
        <xsl:param name="actualString" />
        <xsl:param name="findString" />
        <xsl:param name="replaceString" />
        <xsl:choose>
            <xsl:when test="contains($actualString, $findString)">
                <xsl:value-of select="substring-before($actualString, $findString)" />
                <xsl:value-of select="$replaceString" disable-output-escaping="yes" />
                <xsl:call-template name="replaceText">
                    <xsl:with-param name="actualString" select="substring-after($actualString, $findString)" />
                    <xsl:with-param name="findString" select="$findString" />
                    <xsl:with-param name="replaceString" select="$replaceString" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$actualString" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="sortReportDate">
        <xsl:variable name="inRepDate" select="plm:PLMXML/@date"/>
        <xsl:variable name="datebit1" select="substring-after($inRepDate,'-')"/>
        <xsl:variable name="yearbit" select="substring-before($inRepDate,'-')"/>
        <xsl:variable name="monthbit" select="substring-before($datebit1,'-')"/>
        <xsl:variable name="daybit" select="substring-after($datebit1,'-')"/>
        <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit)"/>
    </xsl:template>

   <xsl:template name="getUserID">
        <xsl:param name="userRefId"/>
        <xsl:variable name="userElement" select="key('user',$userRefId)"/>
        <xsl:value-of select="$userElement/@userId"/>
    </xsl:template>

    
    <xsl:template name="getUOM">
        <xsl:param name="uomRef"/>
        <xsl:variable name="uomElement" select="key('uom',$uomRef)"/>
        <xsl:value-of select="substring-after($uomElement/plm:UserData/plm:UserValue/@value,'-')"/>
    </xsl:template>
    

	 <xsl:template name="getT5_PartType">
        <xsl:param name="value"/>
        <xsl:choose>
            <xsl:when test="$value='M'">     <xsl:value-of select="'Module'"/></xsl:when>
            <xsl:when test="$value='C'">     <xsl:value-of select="'Component'"/></xsl:when>
            <xsl:when test="$value='A'">     <xsl:value-of select="'Assembly'"/></xsl:when>
            <xsl:when test="$value='D'">     <xsl:value-of select="'Dummy Part'"/></xsl:when>
            <xsl:when test="$value='V'">     <xsl:value-of select="'Vehicle'"/></xsl:when>
            <xsl:when test="$value='T'">     <xsl:value-of select="'Technical Part List'"/></xsl:when>
            <xsl:when test="$value='VC'">    <xsl:value-of select="'Vehicle Combination'"/></xsl:when>
            <xsl:when test="$value='VCCR'">  <xsl:value-of select="'Vehicle Combination CR'"/></xsl:when>
            <xsl:when test="$value='G'">     <xsl:value-of select="'Group Id'"/></xsl:when>
            <xsl:when test="$value='R'">     <xsl:value-of select="'Raw Part'"/></xsl:when>
            <xsl:when test="$value='SA'">    <xsl:value-of select="'Stage Assembly'"/></xsl:when>
            <xsl:when test="$value='SP'">    <xsl:value-of select="'Stage Part'"/></xsl:when>
            <xsl:when test="$value='PE'">    <xsl:value-of select="'Production Engg Part'"/></xsl:when>
            <xsl:when test="$value='P'">     <xsl:value-of select="'Process'"/></xsl:when>
            <xsl:otherwise><xsl:value-of select="$value"/></xsl:otherwise>
        </xsl:choose>
    </xsl:template>

	<xsl:template name="sortDate">
        <xsl:param name="inDate" />
        <xsl:if test="string-length($inDate)&gt;1">
        <xsl:variable name="datebit1" select="substring-before($inDate,'T')"/>
        <xsl:variable name="datebit2" select="substring-after($datebit1,'-')"/>
        <xsl:variable name="yearbit" select="substring-before($datebit1,'-')"/>
        <xsl:variable name="monthbit" select="substring-before($datebit2,'-')"/>
        <xsl:variable name="daybit" select="substring-after($datebit2,'-')"/>
        <xsl:variable name="timebit1" select="substring-after($inDate,'T')"/>
        <xsl:variable name="timebit2" select="substring-after($timebit1,':')"/>
        <xsl:variable name="hourbit" select="substring-before($timebit1,':')"/>
        <xsl:variable name="minbit" select="substring-before($timebit2,':')"/>
        <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit,'  ')"/>
        </xsl:if>
    </xsl:template>

	<xsl:template name="getReleaseStatus">
        <xsl:param name="releaseList"/>
        <xsl:param name="separator"/>        
        <xsl:for-each select="$releaseList">
            <xsl:variable name="statusElement" select="key('releasestatus',@value)"/>
            <xsl:choose>
                <xsl:when test="$statusElement/@name='T5_LcsErcRlzd'"><xsl:value-of select="'ERC Released'"/></xsl:when>
                <xsl:when test="$statusElement/@name='T5_LcsReview'"><xsl:value-of select="'ERC Review'"/></xsl:when>
                <xsl:when test="$statusElement/@name='T5_LcsWorking'"><xsl:value-of select="'ERC Working'"/></xsl:when>
                <xsl:otherwise><xsl:value-of select="$statusElement/@name"/></xsl:otherwise>
            </xsl:choose>            
            <xsl:if test="position()!=last()">
                <xsl:value-of select="$separator"/>
            </xsl:if>
        </xsl:for-each>
    </xsl:template>
    

	   <xsl:template name="getDMLProperty">
        <xsl:param name="currentRevID"/>
        <xsl:param name="propName"/>
        <xsl:variable name="CMHasSolutionItemNodes" select="/plm:PLMXML/plm:GeneralRelation[@subType='CMHasSolutionItem']"/>
        <xsl:for-each select="$CMHasSolutionItemNodes">
            <xsl:variable name="primObjID1"><xsl:call-template name="replaceText"><xsl:with-param name="actualString" select="substring-before(./@relatedRefs,' ')"/><xsl:with-param name="findString" select="'#'"/><xsl:with-param name="replaceString" select="''"/></xsl:call-template></xsl:variable>
            <xsl:variable name="secObjID1"><xsl:call-template name="replaceText"><xsl:with-param name="actualString" select="substring-after(./@relatedRefs,' ')"/><xsl:with-param name="findString" select="'#'"/><xsl:with-param name="replaceString" select="''"/></xsl:call-template></xsl:variable>
            <xsl:variable name="taskID" select="substring-before(./@relatedRefs,' ')"/>
            <xsl:choose>
                <xsl:when test="$currentRevID = $secObjID1">
                    <!--<xsl:value-of select="$taskID"/>-->
                    <xsl:variable name="T5_DMLTaskRelationNodes" select="/plm:PLMXML/plm:GeneralRelation[@subType='T5_DMLTaskRelation'][contains(@relatedRefs,$taskID)]"/>
                    <xsl:variable name="dmlId"><xsl:call-template name="replaceText"><xsl:with-param name="actualString" select="substring-before($T5_DMLTaskRelationNodes[1]/@relatedRefs,' ')"/><xsl:with-param name="findString" select="'#'"/><xsl:with-param name="replaceString" select="''"/></xsl:call-template></xsl:variable>
                    <xsl:variable name="dmlNode" select="key('changerev',$dmlId)"/>
                    <!--<xsl:value-of select="count($dmlNode)"/>-->
                    <xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title=$propName]/@value"/>
                </xsl:when>
                
            </xsl:choose>
        </xsl:for-each>
    </xsl:template>


	<xsl:template name="getSparekitDetails">
        <xsl:param name="currentRevID"/>
        <xsl:variable name="Hassparekit" select="/plm:PLMXML/plm:GeneralRelation[@subType='T5_HasSpareKit']"/>	
       <xsl:for-each select="$Hassparekit">

            <xsl:variable name="primObjID1"><xsl:call-template name="replaceText"><xsl:with-param name="actualString" select="substring-after(./@relatedRefs,' ')"/><xsl:with-param name="findString" select="'#'"/><xsl:with-param name="replaceString" select="''"/></xsl:call-template></xsl:variable>

            <xsl:variable name="secObjID1"><xsl:call-template name="replaceText"><xsl:with-param name="actualString" select="substring-before(./@relatedRefs,' ')"/><xsl:with-param name="findString" select="'#'"/><xsl:with-param name="replaceString" select="''"/></xsl:call-template></xsl:variable>

            <xsl:variable name="taskID" select="substring-after(./@relatedRefs,' ')"/>
            <xsl:choose>
                  <xsl:when test="$currentRevID = $secObjID1">
                    <xsl:variable name="T5_HasSpareKitNodes" select="/plm:PLMXML/plm:GeneralRelation[@subType='T5_HasSpareKit'][contains(@relatedRefs,$taskID)]"/>
                    <xsl:variable name="dmlId"><xsl:call-template name="replaceText"><xsl:with-param name="actualString" select="substring-after($T5_HasSpareKitNodes[1]/@relatedRefs,' ')"/><xsl:with-param name="findString" select="'#'"/><xsl:with-param name="replaceString" select="''"/></xsl:call-template></xsl:variable>
                    <xsl:variable name="dmlNode" select="key('sparekitrev',$dmlId)"/>

				<Row>
						<Cell ss:StyleID="s26"><Data ss:Type="String"> </Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String">SpareKit Revision</Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title='item_id']/@value"/></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:Description"/></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title='bl_quantity']/@value"/></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title='current_revision_id']/@value"/></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title='t5_ProjectCode']/@value"/></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title='t5_DesignGrp']/@value"/></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title='t5_Weight']/@value"/></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title='t5_SpareInd']/@value"/></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title='t5_SpareCriteria']/@value"/></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title='t5_RefPartNumber']/@value"/></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:call-template name="getUserID">
						<xsl:with-param name="userRefId" select="substring-after($dmlNode/plm:UserData/plm:UserValue[@title='owning_user']/@dataRef,'#')"></xsl:with-param>
						</xsl:call-template></Data></Cell>	
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:call-template name="getDMLProperty"><xsl:with-param name="currentRevID" select="$dmlNode/@id"/><xsl:with-param name="propName" select="'item_id'"></xsl:with-param></xsl:call-template></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:call-template name="sortDate"><xsl:with-param name="inDate"
						select="$dmlNode/plm:UserData/plm:UserValue[@title='date_released']/@value"></xsl:with-param></xsl:call-template></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:call-template name="getDMLProperty"><xsl:with-param name="currentRevID" select="$dmlNode/@id"/><xsl:with-param name="propName" select="'t5_rlstype'"></xsl:with-param></xsl:call-template></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:call-template name="getReleaseStatus"><xsl:with-param name="releaseList" select="$dmlNode/plm:UserData/plm:UserValue[@title='release_status_list']/plm:UserList/plm:Item"/><xsl:with-param name="separator" select="';'"></xsl:with-param></xsl:call-template></Data></Cell>
						<Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title='t5_EnvelopeDimensions']/@value"/></Data></Cell>
				</Row>
               </xsl:when>
                
          </xsl:choose>
        </xsl:for-each>
    </xsl:template>
    
    
</xsl:stylesheet>  
