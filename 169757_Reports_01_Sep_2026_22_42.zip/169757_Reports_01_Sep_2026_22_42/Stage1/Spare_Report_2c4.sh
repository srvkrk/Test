. /user/uaprod/.bash_profile
echo "Spare_kit running on 2c4"
echo "In Shell Spare_kit 2c4  ...'"$1"'  '"$2"' '"$3"'  '"$4"' '"$5"' '"$6"' "
ssh uaprodtrl@172.22.97.18 "/user/uaprodtrl/Program_Shells/Reports/Spare_kit/Spare_Report_2c7.sh '"$1"'  '"$2"' '"$3"'  '"$4"' '"$5"' '"$6"' "
echo "Spare_kit report end at 2c4"
