<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet  version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:xd="http://www.oxygenxml.com/ns/doc/xsl"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40"
    xmlns:tml="urn:tata-plmxml-schema"
    exclude-result-prefixes="xd">

    <xd:doc scope="stylesheet">
        <xd:desc>
            <xd:p><xd:b>Created on:</xd:b> Dec 04, 2017</xd:p>
            <xd:p><xd:b>Author:</xd:b> sbb914605</xd:p>
            <xd:p></xd:p>
        </xd:desc>
    </xd:doc>
    
    <!--<tml:t5_reasons>
        <t5_reason key='NR'     value='NEW REQUIREMENTS (NEW VC, NEW AGGREGATE)'/>
        <t5_reason key='AD'     value='ALTERNATE SOURCE DEVELOPMENT'/>
        <t5_reason key='CFL'    value='CHANGE IN FEATURE LIST'/>
        <t5_reason key='CMR'    value='COMMONIZATION / STANDARDIZATION / COMPLEXITY REDUCTION'/>
        <t5_reason key='CR'     value='COST REDUCTION'/>
        <t5_reason key='DR'     value='DRAFTING ERROR CORRECTION / BOM-CAD QUALITY IMPROVEMENT'/>
        <t5_reason key='CM'     value='END CUSTOMER / FIELD COMPLAINTS AND SERVICE FEEDBACK / CCT'/>
        <t5_reason key='PQ'     value='IMPROVEMENT IN JD POWER INITIAL QUALITY SCORE'/>
        <t5_reason key='ICR'    value='INTEGRATED COST REDUCTION'/>
        <t5_reason key='QR'     value='QUALITY AND RELIABILITY IMPROVEMENT'/>
        <t5_reason key='RR'     value='REGULATORY REQUIREMENT'/>
        <t5_reason key='SR'     value='SAFETY REQUIREMENT'/>
        <t5_reason key='FM'     value='TO FACILITATE MANUFACTURING'/>
        <t5_reason key='WCR'    value='WARRANTY COST REDUCTION'/>
        <t5_reason key='WR'     value='WEIGHT REDUCTION'/>
    </tml:t5_reasons>
    <tml:t5_PartTypes>
        <t5_PartType key='M'    value='Module'/>
        <t5_PartType key='C'    value='Component'/>
        <t5_PartType key='A'    value='Assembly'/>
        <t5_PartType key='D'    value='Dummy Part'/>
        <t5_PartType key='V'    value='Vehicle'/>
        <t5_PartType key='T'    value='Technical Part List'/>
        <t5_PartType key='VC'   value='Vehicle Combination'/>
        <t5_PartType key='VCCR' value='Vehicle Combination CR'/>
        <t5_PartType key='G'    value='Group Id'/>
        <t5_PartType key='R'    value='Raw Part'/>
        <t5_PartType key='SA'   value='Stage Assembly'/>
        <t5_PartType key='SP'   value='Stage Part'/>
        <t5_PartType key='PE'   value='Production Engg Part'/>
        <t5_PartType key='P'    value='Process'/>
    </tml:t5_PartTypes>-->

    <xsl:output method="xml" version="1.0" indent="yes"/>

    <xsl:strip-space elements="*"/>

    <!-- Define global parameters -->
    <xsl:param name="primaryOccRef" select="/plm:PLMXML/plm:ProductView/@primaryOccurrenceRef"/>
    <xsl:param name="rootProductID" select="substring-after(/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$primaryOccRef]/@instancedRef,'#')"/>

    <!-- Define key functions -->
    <xsl:key name="designrev"           match="plm:DesignRevision"  use="@id"/>
    <xsl:key name="productrev"          match="plm:ProductRevision" use="@id"/>
    <xsl:key name="changerev"           match="plm:ProductRevision[@subType='ChangeRequestRevision']" use="@id"/>
    <xsl:key name="changetaskrev"       match="plm:ProductRevision[@subType='T5_ChangeTaskRevision']" use="@id"/>
	<xsl:key name="designrevmaster"     match="plm:Form[@subType='Design Revision Master']" use="@id"/>
    <xsl:key name="dataset"             match="plm:DataSet"         use="@id"/>
    <xsl:key name="occurrence"          match="plm:Occurrence"      use="@id"/>
    <xsl:key name="design"              match="plm:Design"          use="@id"/>
    <xsl:key name="product"             match="plm:Product"         use="@id"/>
    <xsl:key name="releasestatus"       match="plm:ReleaseStatus"   use="@id"/>
    <xsl:key name="user"                match="plm:User"            use="@id"/>
    <xsl:key name="uom"                 match="plm:Unit"            use="@id"/>
    
    <xsl:template match="/">
        <xsl:variable name="topDesign" select="key('designrev',$rootProductID)"/>
        <xsl:variable name="topProduct" select="key('productrev',$rootProductID)"/>
        <!--<xsl:choose>            
            <xsl:when test="$topProduct != ''">
                <xsl:call-template name="BOMReportHeader">
                    <xsl:with-param name="currentElement" select="$topProduct"/>
                    <xsl:with-param name="parentOccurrenceID" select="$primaryOccRef"/>
                </xsl:call-template>
            </xsl:when>
            <xsl:when test="$topDesign != ''">
                <xsl:call-template name="BOMReportHeader">
                    <xsl:with-param name="currentElement" select="$topDesign"/>
                    <xsl:with-param name="parentOccurrenceID" select="$primaryOccRef"/>
                </xsl:call-template>
            </xsl:when>
        </xsl:choose>-->
        <xsl:call-template name="BOMReportHeader">
            <xsl:with-param name="currentElement" select="$topDesign"/><!-- For Design Revision reports, replace $topProduct with $topDesign -->
            <xsl:with-param name="parentOccurrenceID" select="$primaryOccRef"/>
        </xsl:call-template>
        
    </xsl:template>

    <xsl:template name="BOMReportHeader">
        <xsl:param name="currentElement"/>
        <xsl:param name="parentOccurrenceID"/>

        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">

            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="11" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <!--<Alignment ss:Horizontal="Right"/>-->
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="FirstDataCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#BBFF99" ss:Pattern="Solid"/>
                </Style>
            </Styles>

            <Worksheet ss:Name="Sheet1">

                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="30" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="1" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="50" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/><!--Column : 5-->
                    <Column ss:AutoFitWidth="0" ss:Width="120" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/><!--Column : 10-->
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/> 
                    <Column ss:AutoFitWidth="0" ss:Width="50" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="50" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/><!--Column : 15-->
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/> 
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="50" AutoFitWidth="1"/><!--Column : 20-->
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/> 
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="60" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/><!--Column : 25-->
                    <Column ss:AutoFitWidth="0" ss:Width="60" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="110" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="120" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="85" AutoFitWidth="1"/><!--Column : 30-->
                    <Column ss:AutoFitWidth="0" ss:Width="60" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="50" AutoFitWidth="1"/><!--Column : 35-->
                    <Column ss:AutoFitWidth="0" ss:Width="50" AutoFitWidth="1"/> 
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/><!--Column : 40-->
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="75" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="140" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="120" AutoFitWidth="1"/><!--Column : 45-->
                    
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s21" ss:MergeAcross="3"><Data ss:Type="String">Colour GENTPL Report</Data></Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String">Report Date</Data></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String"><xsl:call-template name="sortReportDate"></xsl:call-template></Data></Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String">Revision Rule</Data></Cell>
                        <Cell ss:StyleID="s23" ss:MergeAcross="1"><Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:RevisionRule/@name"/></Data></Cell>
                    </Row>
                    <Row></Row>
                    <Row></Row>
                    <Row>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Level</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Assembly Part No</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Component Part No</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Revision</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Description</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Modification Description</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">AddOn Description</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Keyword Description</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Project Code</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Design Group</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Owner Design Unit</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Part Type</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Part Code</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Part Category</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Part DR Status</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">DML DR Status</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Drawing Indicator</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Drawing No</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Part Material</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Weight</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Rolled Up Weight</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Material Thickness</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Material Class</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Coated</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Colour Indicator</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Comp Code</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Envelope Dimensions</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Application Owner</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Samples to be Approved</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Validation Status</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Spare Part</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Spare Indicator</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Homologation Reqd</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">CMVR Cert Reqd</Data></Cell>                        
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Quantity</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Unit</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Owner</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Creation Date</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Last Modifying User</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Last Modified Date</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Release Status</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">DML Number</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">DML Closure Date</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">CS</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Variant Formula</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">PO</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">PO Date</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Stock</Data></Cell>
                        <Cell ss:StyleID="s22"><Data ss:Type="String">Vendor ID</Data></Cell>
                    </Row>
                    <xsl:call-template name="generateReportData">
                        <xsl:with-param name="currentElement" select="$currentElement"/>
                        <xsl:with-param name="parentOccuranceId" select="$parentOccurrenceID"/>
                    </xsl:call-template>
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    
    <xsl:template name="generateReportData">
        <xsl:param name="currentElement"/>
        <xsl:param name="parentOccuranceId"/>
        <xsl:call-template name="generateTopProductData">
            <xsl:with-param name="desgrevElement" select="$currentElement"/>
            <xsl:with-param name="parentOccurenceID" select="$parentOccuranceId"/>
        </xsl:call-template>

        <xsl:call-template name="generateChildProductData">
            <xsl:with-param name="desgrevElement" select="$currentElement"/>
            <xsl:with-param name="parentOccurenceID" select="$parentOccuranceId"/>
        </xsl:call-template>
    </xsl:template>

    <xsl:template name="generateTopProductData">
        <xsl:param name="desgrevElement"/>
        <xsl:param name="parentOccurenceID"/>

        <!--Row>
            <Cell ss:StyleID="s26"><Data ss:Type="Number">0</Data></Cell>
            <Cell ss:StyleID="s26"></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='item_id']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='item_revision_id']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:Description"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_DocRemarks']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_SimVal']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_CategoryName']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_ProjectCode']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_DesignGrp']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_DsgnOwn']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_PartType']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_PartCode']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_SpareCriteria']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_PartStatus']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_DrawingInd']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_DrawingNo']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_Material']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="Number"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_Weight']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_RolledupWt']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_MThickness']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_MatlClass']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_Coated']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_ColourInd']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_PrtCatCode']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_EnvelopeDimensions']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_ApplicationOwner']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_SamplesToAppr']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_PrtValiStatus']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_SPDisposalInstr']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_SpareInd']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_HomologationReqd']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="$desgrevElement/plm:UserData/plm:UserValue[@title='t5_CMVRCertificationReqd']/@value"/></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:call-template name="getUserID">
                <xsl:with-param name="userRefId" select="substring-after($desgrevElement/plm:UserData/plm:UserValue[@title='owning_user']/@dataRef,'#')"></xsl:with-param>
            </xsl:call-template></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:call-template name="sortDate"><xsl:with-param name="inDate" select="$desgrevElement/plm:UserData/plm:UserValue[@title='creation_date']/@value"></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:call-template name="getUserID">
                <xsl:with-param name="userRefId" select="substring-after($desgrevElement/plm:UserData/plm:UserValue[@title='last_mod_user']/@dataRef,'#')"></xsl:with-param>
            </xsl:call-template></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:call-template name="sortDate"><xsl:with-param name="inDate" select="$desgrevElement/plm:UserData/plm:UserValue[@title='last_mod_date']/@value"></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:call-template name="getReleaseStatus"><xsl:with-param name="releaseList" select="$desgrevElement/plm:UserData/plm:UserValue[@title='release_status_list']/plm:UserList/plm:Item"/><xsl:with-param name="separator" select="';'"></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"></Data></Cell>
            <Cell ss:StyleID="s26"><Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$parentOccurenceID]/plm:UserData/plm:UserValue[@title='bl_formula']/@value"/></Data></Cell>
        </Row-->

    </xsl:template>

    <xsl:template name="generateChildProductData">
        <xsl:param name="desgrevElement"/>
        <xsl:param name="parentOccurenceID"/>

        <xsl:variable name="occRefs" select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$parentOccurenceID]/@occurrenceRefs"/>
        <xsl:variable name="parentRefID" select="substring-after(/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$parentOccurenceID]/@instancedRef,'#')"/>

        <xsl:call-template name="CreateCL">
            <xsl:with-param name="occStr" select="$occRefs"/>
            <xsl:with-param name="levelID">1</xsl:with-param>
            <xsl:with-param name="parentRefID" select="$parentRefID"/>
        </xsl:call-template>

    </xsl:template>

    <xsl:template name="CreateCL">
        <xsl:param name="occStr"/>
        <xsl:param name="levelID"/>
        <xsl:param name="parentRefID"/>

        <xsl:if test="$occStr!=''">
            <xsl:choose>
                <xsl:when test="contains($occStr,' ')">
                    <xsl:variable name="occid" select="substring-before($occStr,' ')"/>
                    <xsl:call-template name="CreateCL">
                        <xsl:with-param name="occStr" select="$occid"/>
                        <xsl:with-param name="levelID" select="$levelID"/>
                        <xsl:with-param name="parentRefID" select="$parentRefID"/>
                    </xsl:call-template>

                    <xsl:call-template name="CreateCL">
                        <xsl:with-param name="occStr" select="substring-after($occStr,' ')"/>
                        <xsl:with-param name="levelID" select="$levelID"/>
                        <xsl:with-param name="parentRefID" select="$parentRefID"/>
                    </xsl:call-template>

                </xsl:when>

                <xsl:otherwise>
                    <xsl:call-template name="creCLextSort">
                        <xsl:with-param name="occID" select="$occStr"/>
                        <xsl:with-param name="levelID" select="$levelID"/>
                        <xsl:with-param name="parentRefID" select="$parentRefID"/>
                    </xsl:call-template>

                </xsl:otherwise>
            </xsl:choose>
        </xsl:if>
    </xsl:template>

    <xsl:template name="creCLextSort">
        <xsl:param name="occID"/>
        <xsl:param name="levelID"/>
        <xsl:param name="parentRefID"/>

        <xsl:variable name="occurenceElement" select="key('occurrence',$occID)"/>
        <xsl:variable name="occRefs" select="$occurenceElement/@occurrenceRefs"/>
        <xsl:variable name="revRef" select="substring-after($occurenceElement/@instancedRef,'#')"/>

        <xsl:variable name="designRevElement" select="key('designrev',$revRef)"/>
        <xsl:variable name="productRevElement" select="key('productrev',$revRef)"/>

        <xsl:choose>
            <xsl:when test="$designRevElement != ''">
                <xsl:call-template name="creCLext">
                    <xsl:with-param name="currentRevElement" select="$designRevElement"/>
                    <xsl:with-param name="levelID" select="$levelID"/>
                    <xsl:with-param name="parentElementID" select="$parentRefID"/>
                    <xsl:with-param name="occRefs" select="$occRefs"/>
                    <xsl:with-param name="occurencElement" select="$occurenceElement"/>
                </xsl:call-template>
            </xsl:when>
            <xsl:when test="$productRevElement !=''">
                <xsl:call-template name="creCLext">
                    <xsl:with-param name="currentRevElement" select="$productRevElement"/>
                    <xsl:with-param name="levelID" select="$levelID"/>
                    <xsl:with-param name="parentElementID" select="$parentRefID"/>
                    <xsl:with-param name="occRefs" select="$occRefs"/>
                    <xsl:with-param name="occurencElement" select="$occurenceElement"/>
                </xsl:call-template>
            </xsl:when>
        </xsl:choose>

    </xsl:template>

    <xsl:template name="creCLext">
        <xsl:param name="currentRevElement"/>
        <xsl:param name="levelID"/>
        <xsl:param name="parentElementID"/>
        <xsl:param name="occRefs"/>
        <xsl:param name="occurencElement"/>

        <xsl:variable name="parentDesElement" select="key('designrev',$parentElementID)"/>
        <xsl:variable name="parentProdElement" select="key('productrev',$parentElementID)"/>        
        <xsl:variable name="currentDesElement" select="key('design',substring-after($currentRevElement/@masterRef,'#'))"/>

		<xsl:variable name="MasterDesElement" select="key('designrevmaster',substring-after($currentRevElement/plm:AssociatedForm/@formRef,'#'))"/>


        <Row>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="Number"><xsl:value-of select="$levelID"/></Data></Cell>
            <xsl:choose>
                <xsl:when test="$parentProdElement/plm:UserData/plm:UserValue[@title='item_id']/@value!=''">
                    <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                        <Data ss:Type="String"><xsl:value-of select="$parentProdElement/plm:UserData/plm:UserValue[@title='item_id']/@value"/> </Data></Cell>
                </xsl:when>
                <xsl:otherwise>
                    <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                        <Data ss:Type="String"><xsl:value-of select="$parentDesElement/plm:UserData/plm:UserValue[@title='item_id']/@value"/> </Data></Cell>
                </xsl:otherwise>
            </xsl:choose>

            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='item_id']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='item_revision_id']/@value"/></Data></Cell>
             <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:Description"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_DocRemarks']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_SimVal']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_CategoryName']/@value"/></Data></Cell>
            <xsl:choose>
                <xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">
                    <Cell ss:StyleID="s25"><Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_ArchProjectCode']/@value"/></Data></Cell>
                </xsl:when>
                <xsl:otherwise>
                    <Cell ss:StyleID="s24"><Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_ProjectCode']/@value"/></Data></Cell>
                </xsl:otherwise>
            </xsl:choose>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_DesignGrp']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_DsgnOwn']/@value"/></Data></Cell>            
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getT5_PartType"><xsl:with-param name="value" select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_PartType']/@value"></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_PartCode']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_SpareCriteria']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_PartStatus']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getDMLProperty"><xsl:with-param name="currentRevID" select="$currentRevElement/@id"/><xsl:with-param name="propName" select="'t5_cDRstatus'"/></xsl:call-template></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_DrawingInd']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_DrawingNo']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_Material']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="Number"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_Weight']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_RolledupWt']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_MThickness']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_MatlClass']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_Coated']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_ColourInd']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_PrtCatCode']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_EnvelopeDimensions']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_ApplicationOwner']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_SamplesToAppr']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_PrtValiStatus']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_SPDisposalInstr']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_SpareInd']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_HomologationReqd']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$currentRevElement/plm:UserData/plm:UserValue[@title='t5_CMVRCertificationReqd']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$occurencElement/plm:UserData[2]/plm:UserValue[@title='Quantity']/@value"/></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getUOM"><xsl:with-param name="uomRef" select="substring-after($currentDesElement/plm:UserData/plm:UserValue[@title='uom_tag']/@dataRef,'#')"></xsl:with-param></xsl:call-template></Data></Cell>            
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getUserID">
                <xsl:with-param name="userRefId" select="substring-after($currentRevElement/plm:UserData/plm:UserValue[@title='owning_user']/@dataRef,'#')"></xsl:with-param>
            </xsl:call-template></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="sortDate"><xsl:with-param name="inDate" select="$currentRevElement/plm:UserData/plm:UserValue[@title='creation_date']/@value"></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getUserID">
                <xsl:with-param name="userRefId" select="substring-after($currentRevElement/plm:UserData/plm:UserValue[@title='last_mod_user']/@dataRef,'#')"></xsl:with-param>
            </xsl:call-template></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="sortDate"><xsl:with-param name="inDate" select="$currentRevElement/plm:UserData/plm:UserValue[@title='last_mod_date']/@value"></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getReleaseStatus"><xsl:with-param name="releaseList" select="$currentRevElement/plm:UserData/plm:UserValue[@title='release_status_list']/plm:UserList/plm:Item"/><xsl:with-param name="separator" select="';'"></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getDMLProperty"><xsl:with-param name="currentRevID" select="$currentRevElement/@id"/><xsl:with-param name="propName" select="'item_id'"></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="sortDate"><xsl:with-param name="inDate"><xsl:call-template name="getDMLProperty"><xsl:with-param name="currentRevID" select="$currentRevElement/@id"/><xsl:with-param name="propName" select="'date_released'"/></xsl:call-template></xsl:with-param></xsl:call-template></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="getCSValues"><xsl:with-param name="revUserDataNode" select="$currentRevElement/plm:UserData"/></xsl:call-template></Data></Cell>
            <Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:call-template name="replaceText"><xsl:with-param name="actualString" select="$occurencElement/plm:UserData/plm:UserValue[@title='bl_formula']/@value"/><xsl:with-param name="findString" select="'[Teamcenter]'"/><xsl:with-param name="replaceString" select="''"/></xsl:call-template></Data></Cell>
			<Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
                <Data ss:Type="String"><xsl:value-of select="$MasterDesElement/plm:UserData/plm:UserValue[@title='t5_PO6']/@value"/></Data></Cell>
			<Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
							<Data ss:Type="String"><xsl:value-of select="$MasterDesElement/plm:UserData/plm:UserValue[@title='t5_PODate6']/@value"/></Data></Cell>
			<Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
							<Data ss:Type="String"><xsl:value-of select="$MasterDesElement/plm:UserData/plm:UserValue[@title='t5_Stock6']/@value"/></Data></Cell>
			<Cell><xsl:attribute name="ss:StyleID"><xsl:choose><xsl:when test="$currentRevElement/@subType='T5_ArchModuleRevision'">s25</xsl:when><xsl:otherwise>s24</xsl:otherwise></xsl:choose></xsl:attribute>
							<Data ss:Type="String"><xsl:value-of select="$MasterDesElement/plm:UserData/plm:UserValue[@title='t5_VendorID6']/@value"/></Data></Cell>
        </Row>

        <xsl:choose>
            <xsl:when test="$occRefs!=''">
                <xsl:call-template name="CreateCL">
                    <xsl:with-param name="occStr" select="$occRefs"/>
                    <xsl:with-param name="levelID" select="$levelID+1"/>
                    <xsl:with-param name="parentRefID" select="$currentRevElement/@id"></xsl:with-param>
                </xsl:call-template>
            </xsl:when>
        </xsl:choose>

    </xsl:template>

    <xsl:template name="replaceText">
        <xsl:param name="actualString" />
        <xsl:param name="findString" />
        <xsl:param name="replaceString" />
        <xsl:choose>
            <xsl:when test="contains($actualString, $findString)">
                <xsl:value-of select="substring-before($actualString, $findString)" />
                <xsl:value-of select="$replaceString" disable-output-escaping="yes" />
                <xsl:call-template name="replaceText">
                    <xsl:with-param name="actualString" select="substring-after($actualString, $findString)" />
                    <xsl:with-param name="findString" select="$findString" />
                    <xsl:with-param name="replaceString" select="$replaceString" />
                </xsl:call-template>
            </xsl:when>
            <xsl:otherwise>
                <xsl:value-of select="$actualString" />
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>

    <xsl:template name="sortDate">
        <xsl:param name="inDate" />
        <xsl:if test="string-length($inDate)&gt;1">
        <xsl:variable name="datebit1" select="substring-before($inDate,'T')"/>
        <xsl:variable name="datebit2" select="substring-after($datebit1,'-')"/>
        <xsl:variable name="yearbit" select="substring-before($datebit1,'-')"/>
        <xsl:variable name="monthbit" select="substring-before($datebit2,'-')"/>
        <xsl:variable name="daybit" select="substring-after($datebit2,'-')"/>
        <xsl:variable name="timebit1" select="substring-after($inDate,'T')"/>
        <xsl:variable name="timebit2" select="substring-after($timebit1,':')"/>
        <xsl:variable name="hourbit" select="substring-before($timebit1,':')"/>
        <xsl:variable name="minbit" select="substring-before($timebit2,':')"/>
        <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit,'  ')"/>
        </xsl:if>
    </xsl:template>
    <xsl:template name="sortReportDate">
        <xsl:variable name="inRepDate" select="plm:PLMXML/@date"/>
        <xsl:variable name="datebit1" select="substring-after($inRepDate,'-')"/>
        <xsl:variable name="yearbit" select="substring-before($inRepDate,'-')"/>
        <xsl:variable name="monthbit" select="substring-before($datebit1,'-')"/>
        <xsl:variable name="daybit" select="substring-after($datebit1,'-')"/>
        <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit)"/>
    </xsl:template>

    <xsl:template name="getUserID">
        <xsl:param name="userRefId"/>
        <xsl:variable name="userElement" select="key('user',$userRefId)"/>
        <xsl:value-of select="$userElement/@userId"/>
    </xsl:template>

    <xsl:template name="getReleaseStatus">
        <xsl:param name="releaseList"/>
        <xsl:param name="separator"/>        
        <xsl:for-each select="$releaseList">
            <xsl:variable name="statusElement" select="key('releasestatus',@value)"/>
            <xsl:choose>
                <xsl:when test="$statusElement/@name='T5_LcsErcRlzd'"><xsl:value-of select="'ERC Released'"/></xsl:when>
                <xsl:when test="$statusElement/@name='T5_LcsReview'"><xsl:value-of select="'ERC Review'"/></xsl:when>
                <xsl:when test="$statusElement/@name='T5_LcsWorking'"><xsl:value-of select="'ERC Working'"/></xsl:when>
                <xsl:otherwise><xsl:value-of select="$statusElement/@name"/></xsl:otherwise>
            </xsl:choose>            
            <xsl:if test="position()!=last()">
                <xsl:value-of select="$separator"/>
            </xsl:if>
        </xsl:for-each>
    </xsl:template>
    
    <xsl:template name="getT5_PartType">
        <xsl:param name="value"/>
        <xsl:choose>
            <xsl:when test="$value='M'">     <xsl:value-of select="'Module'"/></xsl:when>
            <xsl:when test="$value='C'">     <xsl:value-of select="'Component'"/></xsl:when>
            <xsl:when test="$value='A'">     <xsl:value-of select="'Assembly'"/></xsl:when>
            <xsl:when test="$value='D'">     <xsl:value-of select="'Dummy Part'"/></xsl:when>
            <xsl:when test="$value='V'">     <xsl:value-of select="'Vehicle'"/></xsl:when>
            <xsl:when test="$value='T'">     <xsl:value-of select="'Technical Part List'"/></xsl:when>
            <xsl:when test="$value='VC'">    <xsl:value-of select="'Vehicle Combination'"/></xsl:when>
            <xsl:when test="$value='VCCR'">  <xsl:value-of select="'Vehicle Combination CR'"/></xsl:when>
            <xsl:when test="$value='G'">     <xsl:value-of select="'Group Id'"/></xsl:when>
            <xsl:when test="$value='R'">     <xsl:value-of select="'Raw Part'"/></xsl:when>
            <xsl:when test="$value='SA'">    <xsl:value-of select="'Stage Assembly'"/></xsl:when>
            <xsl:when test="$value='SP'">    <xsl:value-of select="'Stage Part'"/></xsl:when>
            <xsl:when test="$value='PE'">    <xsl:value-of select="'Production Engg Part'"/></xsl:when>
            <xsl:when test="$value='P'">     <xsl:value-of select="'Process'"/></xsl:when>
            <xsl:otherwise><xsl:value-of select="$value"/></xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    
    <xsl:template name="getUOM">
        <xsl:param name="uomRef"/>
        <xsl:variable name="uomElement" select="key('uom',$uomRef)"/>
        <xsl:value-of select="substring-after($uomElement/plm:UserData/plm:UserValue/@value,'-')"/>
    </xsl:template>
    
    <xsl:template name="getDMLProperty">
        <xsl:param name="currentRevID"/>
        <xsl:param name="propName"/>
        <xsl:variable name="CMHasSolutionItemNodes" select="/plm:PLMXML/plm:GeneralRelation[@subType='CMHasSolutionItem']"/>
        <xsl:for-each select="$CMHasSolutionItemNodes">
            <xsl:variable name="primObjID1"><xsl:call-template name="replaceText"><xsl:with-param name="actualString" select="substring-before(./@relatedRefs,' ')"/><xsl:with-param name="findString" select="'#'"/><xsl:with-param name="replaceString" select="''"/></xsl:call-template></xsl:variable>
            <xsl:variable name="secObjID1"><xsl:call-template name="replaceText"><xsl:with-param name="actualString" select="substring-after(./@relatedRefs,' ')"/><xsl:with-param name="findString" select="'#'"/><xsl:with-param name="replaceString" select="''"/></xsl:call-template></xsl:variable>
            <xsl:variable name="taskID" select="substring-before(./@relatedRefs,' ')"/>
            <xsl:choose>
                <xsl:when test="$currentRevID = $secObjID1">
                    <!--<xsl:value-of select="$taskID"/>-->
                    <xsl:variable name="T5_DMLTaskRelationNodes" select="/plm:PLMXML/plm:GeneralRelation[@subType='T5_DMLTaskRelation'][contains(@relatedRefs,$taskID)]"/>
                    <xsl:variable name="dmlId"><xsl:call-template name="replaceText"><xsl:with-param name="actualString" select="substring-before($T5_DMLTaskRelationNodes[1]/@relatedRefs,' ')"/><xsl:with-param name="findString" select="'#'"/><xsl:with-param name="replaceString" select="''"/></xsl:call-template></xsl:variable>
                    <xsl:variable name="dmlNode" select="key('changerev',$dmlId)"/>
                    <!--<xsl:value-of select="count($dmlNode)"/>-->
                    <xsl:value-of select="$dmlNode/plm:UserData/plm:UserValue[@title=$propName]/@value"/>
                </xsl:when>
                
            </xsl:choose>
        </xsl:for-each>
    </xsl:template>
    
    <xsl:template name="getCSValues">
        <xsl:param name="revUserDataNode"/>
        <xsl:variable name="UserValueNodes" select="$revUserDataNode/plm:UserValue"/>
        <xsl:for-each select="$UserValueNodes">
            <xsl:if test="@title='t5_AhdMakeBuyIndicator' and string-length(@value)&gt;0">
                <xsl:value-of select="'AHD - '"/><xsl:value-of select="@value"/><xsl:if test="position()!=last()"><xsl:value-of select="', '"/></xsl:if>
            </xsl:if>
            <xsl:if test="@title='t5_CarMakeBuyIndicator' and string-length(@value)&gt;0">
                <xsl:value-of select="'CAR - '"/><xsl:value-of select="@value"/><xsl:if test="position()!=last()"><xsl:value-of select="', '"/></xsl:if>
            </xsl:if>
            <xsl:if test="@title='t5_DwdMakeBuyIndicator' and string-length(@value)&gt;0">
                <xsl:value-of select="'DWD - '"/><xsl:value-of select="@value"/><xsl:if test="position()!=last()"><xsl:value-of select="', '"/></xsl:if>
            </xsl:if>
            <xsl:if test="@title='t5_JsrMakeBuyIndicator' and string-length(@value)&gt;0">
                <xsl:value-of select="'JSR - '"/><xsl:value-of select="@value"/><xsl:if test="position()!=last()"><xsl:value-of select="', '"/></xsl:if>
            </xsl:if>
            <xsl:if test="@title='t5_JdlMakeBuyIndicator' and string-length(@value)&gt;0">
                <xsl:value-of select="'JSR TMLDL - '"/><xsl:value-of select="@value"/><xsl:if test="position()!=last()"><xsl:value-of select="', '"/></xsl:if>
            </xsl:if>
            <xsl:if test="@title='t5_LkoMakeBuyIndicator' and string-length(@value)&gt;0">
                <xsl:value-of select="'LKO - '"/><xsl:value-of select="@value"/><xsl:if test="position()!=last()"><xsl:value-of select="', '"/></xsl:if>
            </xsl:if>
            <xsl:if test="@title='t5_PNRMakeBuyIndicator' and string-length(@value)&gt;0">
                <xsl:value-of select="'JSR - '"/><xsl:value-of select="@value"/><xsl:if test="position()!=last()"><xsl:value-of select="', '"/></xsl:if>
            </xsl:if>
            <xsl:if test="@title='t5_PunPCBUMakeBuyIndicator' and string-length(@value)&gt;0">
                <xsl:value-of select="'PuPCBU - '"/><xsl:value-of select="@value"/><xsl:if test="position()!=last()"><xsl:value-of select="', '"/></xsl:if>
            </xsl:if>
            <xsl:if test="@title='t5_PunMakeBuyIndicator' and string-length(@value)&gt;0">
                <xsl:value-of select="'PUN - '"/><xsl:value-of select="@value"/><xsl:if test="position()!=last()"><xsl:value-of select="', '"/></xsl:if>
            </xsl:if>
            <xsl:if test="@title='t5_SgrMakeBuyIndicator' and string-length(@value)&gt;0">
                <xsl:value-of select="'SGR - '"/><xsl:value-of select="@value"/><xsl:if test="position()!=last()"><xsl:value-of select="', '"/></xsl:if>
            </xsl:if>
        </xsl:for-each>       
    </xsl:template>
    
    
</xsl:stylesheet>