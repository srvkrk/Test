<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:template match="/">
 <html>
	<head>
		<style>
			body {background-color: #FBFFDE;}
			h2   {color: blue;}
			p    {color: red;}
			table, th, td {
			  border: 1px solid black;
			  border-collapse: collapse;
			  white-space: nowrap;
			}
			th{
			  background-color: #69C7F0;
			  white-space: nowrap;
			}
			tr:nth-child(even) {
			  background-color: #D6EEEE;
			}
			tr:hover {background-color: #BCFA9B;}		
		</style>
  </head>
 <body>
  <h2 align="center">New Part Request WorkFlow Details</h2>
   <table border="3" align="center" >
    <tr bgcolor="#FFBB33">
	<th>New Part Request Number</th>
	<th colspan="4">MCCReviewer</th>
	<th colspan="4">COC Head Plantform Engineer Review</th>
	<th colspan="4">COC Principal Engineer Review</th>
	<th colspan="4">Module TeamLeader Review</th>
	<th colspan="4">Assign Reviewer Assignemnt</th>
	</tr>
	<tr>
	<th></th>
	 <th>MCCReviewerName</th>
	 <th>Start Date</th>
	 <th>End Date</th>
	 <th>Status</th>
	 <th>COC HeadReviewerName</th>
	 <th>Start Date</th>
	 <th>End Date</th>
	 <th>Status</th>
	 <th>COCPrincipalReviewerName</th>
	 <th>Start Date</th>
	 <th>End Date</th>
	 <th>Status</th>
	 <th>Module ReviewerName</th>
	 <th>Start Date</th>
	 <th>End Date</th>
	 <th>Status</th>
	 <th>SignOffUserName</th>
	 <th>Start Date</th>
	 <th>End Date</th>
	 <th>Status</th>
	 <th>Assigned TML Part Number</th>
      
   </tr>
    <xsl:for-each select="PLMXML/NewPartRequestNumber">
   <tr>
	<td><xsl:value-of select="field[@key='item_id']"/></td>
	
	<td><xsl:value-of select="field[@key='MCC_process_Performer']"/></td>	
	<td><xsl:value-of select="field[@key='MCC_processSt_Date']"/></td>	
	<td><xsl:value-of select="field[@key='MCC_processEnd_Date']"/></td>
	<td><xsl:value-of select="field[@key='MCC_process_Result']"/></td>
	
	<td><xsl:value-of select="field[@key='COCH_process_Performer']"/></td>	
	<td><xsl:value-of select="field[@key='COCH_process_StDate']"/></td>
	<td><xsl:value-of select="field[@key='COCH_process_EndDate']"/></td>
	<td><xsl:value-of select="field[@key='COCH_process_Result']"/></td>
	
	<td><xsl:value-of select="field[@key='COCP_process_Performer']"/></td>
	<td><xsl:value-of select="field[@key='COCP_process_StDate']"/></td>
	<td><xsl:value-of select="field[@key='COCP_process_EndDate']"/></td>
	<td><xsl:value-of select="field[@key='COCP_process_Result']"/></td>

	<td><xsl:value-of select="field[@key='Module_Revprocess_Performer']"/></td>
	<td><xsl:value-of select="field[@key='Module_Revprocess_StDate']"/></td>
	<td><xsl:value-of select="field[@key='Module_Revprocess_EndDate']"/></td>
	<td><xsl:value-of select="field[@key='Module_Revprocess_Result']"/></td>

	<td><xsl:value-of select="field[@key='Assign_process_Performer']"/></td>
	<td><xsl:value-of select="field[@key='Assign_process_StDate']"/></td>
	<td><xsl:value-of select="field[@key='Assign_process_EndDate']"/></td>
	<td><xsl:value-of select="field[@key='Assign_process_Result']"/></td>

	<td><xsl:value-of select="field[@key='Assigned_TCUATml_PartNumber']"/></td>
	

   
   </tr>
    </xsl:for-each>
  </table>
  </body>
  </html>
</xsl:template>

</xsl:stylesheet>