. /user/cvprod/.bash_profile
echo "==========================================================================================================================================================="
echo " "
echo "Now Call_GenTPL_Colour_106.sh is runing on 106 And Calling exe tm_Colour_GENTPL"
echo "Item_ID=[$1] | Revision=[$2] | Seq=[$3] | Rev_Rule=[$4] | User_ID=[$5]"
/user/cvprod/Program_Shells/Reports/tm_Colour_GENTPL -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Item_ID="$1" -Revision="$2" -Seq="$3" -RevisionRule="$4" -UserID="$5" 
echo " "
echo "=======================================================  Colour GENTPL report execution is FINISHED at 106 ======================================================================="
