. /user/uaprodtrl/.bash_profile
echo "=========================================================================================================================================================================================================="
echo " "
echo "Now Call_GenTPL_Colour_exe_18.sh is running on 18 which is calling exe tm_Colour_GENTPL"
echo "Item_ID=[$1] | Revision=[$2] | Seq=[$3] | Rev_Rule=[$4] | User_ID=[$5]"
/user/uaprodtrl/Program_Shells/Reports/tm_Colour_GENTPL -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -Item_ID="$1" -Revision="$2" -Seq="$3" -RevisionRule="$4" -UserID="$5" 
echo " "
echo "=======================================================  Colour GENTPL report execution is FINISHED at UAPROD 18 ================================================================================="