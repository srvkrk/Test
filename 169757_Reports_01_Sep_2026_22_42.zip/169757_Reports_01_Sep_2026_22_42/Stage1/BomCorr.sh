. /user/cvprod/.bash_profile
echo "In ShellBomCorr.sh start_cvprod...$1  "$2" "$3" "$4""
while read line
do
echo $line
part=`echo $line | cut -d',' -f1`
rev=`echo $line | cut -d',' -f2`
seq=`echo $line | cut -d',' -f3`
echo "calling exe"
./BomCorrModuleRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -VC/Module="$part" -InputRevision="$rev" -InputSequence="$seq" -RevisionRule="ERC release and above" -Update_BOM_COMPLETENESS?="Y"
done < /user/cvprod/Vinayak/Bomcorr/Cron_Testing/sample.txt