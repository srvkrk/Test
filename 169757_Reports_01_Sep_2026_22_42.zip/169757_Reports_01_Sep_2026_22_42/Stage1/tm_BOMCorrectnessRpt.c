/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: tm_BOMCorrectnessRpt.c
**
** Functions:-    This utility applies SVR and Revision Rule on input Platform to create it BOM structure which is furter use to create BOM completeness and correctness report.
**
**           Date                                                                                                      Author                               
**           16-July-2019                                                                                      Madhusudan Bachhav                            
**
***********************************************************************************************************************************************************/
#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <bom/bom_attr.h>
#include <epm/cr_effectivity.h>
#include <epm/epm.h>
#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pie/pie.h>
#include <pom/pom/pom.h>
#include <property/prop.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tc/iman.h>
#include <tc/preferences.h>
#include <tc/tc.h>
#include <tc/tc_macros.h>
#include <tc/tc_startup.h> 
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/iman_msg.h>
#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <unidefs.h>
#include <user_exits/epm_toolkit_utils.h>
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
#define ITK_err (EMH_USER_error_base + 2)




char* subString (char* mainStringf ,int fromCharf,int toCharf);

static int report_error( char *file, int line, char *function, int return_code)
{
    if (return_code != ITK_ok)
    {
        char *error_msg_string;

        EMH_get_error_string (NULLTAG, return_code, &error_msg_string);
        printf("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        TC_write_syslog("ERROR: %d ERROR MSG: %s.\n", return_code, error_msg_string);
        printf ("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);    
        TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
        if(error_msg_string) MEM_free(error_msg_string);
                                
    }
                return return_code;
}




char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
                int i;
                char *retStringf;
                //printf("\n count found %s ",mainStringf);fflush(stdout);
                retStringf = (char*) MEM_alloc(200);
                for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
                *(retStringf+i) = '\0';
                //printf("\n return string found %s ",retStringf);fflush(stdout);
                return retStringf;
}

FILE  *output   = NULL;
int    ifail   = ITK_ok;
char   *sep      = "^";
int read_value_from_file(char*);
int DML_GenTPL_Report(char*);

int	TotalPrtCount			= 0;
int	ENVP_Diam_Check			= 0;
int	Weight_Check			= 0;
int	MaterialCls_Check		= 0;
int	UOM_Check				= 0;
int	PartCategoryDup_Check	= 0;
int	MatrInDrwDup_Check		= 0;
int	Qty_Check				= 0;
int	CMVR_Check				= 0;
int	CADBOM_Check			= 0;
int	CADBOM_Check_Err		= 0;



int	ENVP_Diam_Check2		= 0;
int	Weight_Check2			= 0;
int	UOM_Check2				= 0;
int	PartCategoryDup_Check2	= 0;
int	Qty_Check2				= 0;
int	CMVR_Check2				= 0;




void print_requirement()
{
     printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        " -Platform=<Platform is required>\n"
        " -SVR=<SVN no is required>\n"
        " -RevisionRule=<RevisionRule is required>\n"
        " -Update_BOM_COMPLETENESS?=<Either 'Y' or 'N' is valid>\n"
        );    
}


static int PrintErrorStack( void )

{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
               
    for ( i = 0; i < iNumErrs; i++ )
    {
                                fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	//printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}


/*******************************************************************************
    Function:       ITK_user_main
    Description:    This is ITK main function. The program starts from here. 
                                                                                It checks for the proper dbUsr name and password.         
*******************************************************************************/

int ia =0;
char **sFinalDataSet;
tag_t *tagSET;

int ITK_user_main(int argc, char *argv[])
{
	ia =0;
	tagSET = (tag_t *) MEM_alloc(30000 * sizeof(tag_t));
	sFinalDataSet = (char **) MEM_alloc(1 * sizeof(char *));

	int					n_entry				= 1;
	int					rsltCount			= 0;

	char				* Platform			= NULL;
	char				* SVR				= NULL;
	char				* RevisionRule		= NULL;
	char				* COMPLETENESS_d	= NULL;
	char				* DataSetName1		= NULL;
	char				* DataSetName2		= NULL;
	char				* DataSetName3		= NULL;
	char				* DR_objNo			= NULL;
	char				* DR_Item_id		= NULL;
	char				* VehId				= NULL;
	char				Data[100]			= "";
	char				outputFile[200]		= "";
	char				outputFile2[200]	= "";
	char				outputFile3[200]	= "";
	char				*test				= (char*)MEM_alloc(sizeof (char) * 200);
	char				*Percentage				= (char*)MEM_alloc(sizeof (char) * 100);

	DataSetName1=(char *) MEM_alloc(100);
	DataSetName2=(char *) MEM_alloc(100);
	DataSetName3=(char *) MEM_alloc(100);

	char				*qry_entry[1]		= {"Name"};
	char				**qry_values2		= (char **) MEM_alloc(10 * sizeof(char *));

	tag_t		qryTag					= NULLTAG;
	tag_t		msWordType				= NULLTAG;
	tag_t		wordDataset				= NULLTAG;
	tag_t		wordDataset2			= NULLTAG;
	tag_t		wordDataset3			= NULLTAG;
	tag_t		wordLatestDat_t			= NULLTAG;
	tag_t		wordLatestDat_t2		= NULLTAG;
	tag_t		wordLatestDat_t3		= NULLTAG;
	tag_t		D_tag					= NULLTAG;
	tag_t		DR_tag					= NULLTAG;
	tag_t		*CntrolObjectTag		= NULLTAG;	
	tag_t		Veh_tag					= NULLTAG;
	tag_t		VehR_tag				= NULLTAG;

	double dErrEnvDmPrcnt		= 0;
	double dErrWghtPrcnt		= 0;
	double dErrMtClsPrcnt		= 0;
	double dErrUoMPrcnt			= 0;
	double dErrQtyPrcnt			= 0;
	double dErrPrtCtPrcnt		= 0;
	double dErrMatDrPrcnt		= 0;
	double dErrCMVRPrcnt		= 0;
	double dErrCBMPrcnt			= 0;

	double dCntrEnvDm			= 0;
	double dCntrWght			= 0;
	double dCntrMtCls			= 0;
	double dCntrUoM				= 0;
	double dCntrQty				= 0;
	double dCntrPrtCt			= 0;
	double dCntrMatDr			= 0;
	double dCntrCMVR			= 0;
	double dCntrCBM				= 0;

	double dSumAttr				= 0;
	double dBomAccuracy			= 0;


	double dErrEnvDmPrcnt2	    = 0;
	double dErrWghtPrcnt2		= 0;
	double dErrUoMPrcnt2		= 0;
	double dErrQtyPrcnt2		= 0;
	double dErrPrtCtPrcnt2		= 0;
	double dErrCMVRPrcnt2		= 0;

	double dCntrEnvDm2			= 0;
	double dCntrWght2			= 0;
	double dCntrUoM2			= 0;
	double dCntrQty2			= 0;
	double dCntrPrtCt2			= 0;
	double dCntrCMVR2			= 0;

	double dSumAttr2			= 0;
	double dBomAccuracy2		= 0;



	Platform				= ITK_ask_cli_argument("-Platform=");
	SVR						= ITK_ask_cli_argument("-SVR=");
	RevisionRule			= ITK_ask_cli_argument("-RevisionRule=");
	COMPLETENESS_d			= ITK_ask_cli_argument("-Update_BOM_COMPLETENESS?=");

	FILE  *fp_Write   = NULL;
	FILE  *fp_Write2   = NULL;
	//FILE  *txtfile   = NULL;
	
	time_t				now;
	struct				tm when;
	
	time(&now);
	when = *localtime(&now);
	//for output file with date.
	strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);

//	sprintf(outputFile,"/user/bsd05818/madhu/Color/BOMCorrectnessRptClCode/%s_Data_Dump_%s.csv",SVR,Data);
//	sprintf(outputFile2,"/user/bsd05818/madhu/Color/BOMCorrectnessRptClCode/%s_BOM_COMPLETENESS_REPORT_%s.csv",SVR,Data);
//	sprintf(outputFile3,"/user/bsd05818/madhu/Color/BOMCorrectnessRptClCode/%s_BOM_CORRECTNESS_REPORT_%s.csv",SVR,Data);

	sprintf(outputFile,"/tmp/%s_Data_Dump_%s.csv",SVR,Data);	
	sprintf(outputFile2,"/tmp/%s_BOM_COMPLETENESS_REPORT_%s.csv",SVR,Data);	
	sprintf(outputFile3,"/tmp/%s_BOM_CORRECTNESS_REPORT_%s.csv",SVR,Data);


	//to remove extra sapce.
	if( tc_strlen(stripBlanks(Platform)) == 0 || tc_strlen(stripBlanks(SVR)) == 0 || tc_strlen(stripBlanks(RevisionRule)) == 0 || tc_strlen(stripBlanks(COMPLETENESS_d)) == 0)
	{
					print_requirement();
					return -1;
	}

//	if( tc_strcmp(COMPLETENESS_d,"Y")!=0 || tc_strcmp(COMPLETENESS_d,"N")!=0 )
//	{
//		//EMH_store_error_s1(EMH_severity_error,ITK_err,"Value for Update_BOM_COMPLETENESS? should be either 'Y' or 'N'.");
//		//return ITK_err;
//
//		print_requirement();
//		return -1;
//	}

	if( tc_strcmp(COMPLETENESS_d,"Y")==0 )
	{
	}
	else if( tc_strcmp(COMPLETENESS_d,"N")==0 )
	{
	}
	else
	{
		print_requirement();
		return -1;
	}


	printf("\n\t INSIDE MAIN FUN \n");fflush(stdout);
	

	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_init_module("ercpsup","ERCpsup2019","Engineering")) ;
	
	//provide access.
	ITK_CALL(ITK_set_bypass(true));

	printf("File Location: [%s] \n",outputFile);

	//File open here
	output = fopen(outputFile, "w");
	if (output == NULL)
	{
					printf("ERROR: Cannot open File\n");
					return -1;
	}
	else
	{
				printf("File opened successfully.\n");
	}	
	fprintf(output," ,Part Number,Revision,Desc,Envelope Dimension,Weight,Mat class,Unit of Measure,Qty,Part Category,Material in Drawing,CMVR Indicator,Homologation Req,CAD BOM Mismatch,COMPLETENESS Error,CORRECTNESS Error\n");
	fprintf(output,"\n");
									
	//ifail = read_value_from_file(file);
	//ITK_CALL(Platform_SVR(Platform,SVR,RevisionRule,WithoutZeroQty));
	ITK_CALL(BOMCorrect(Platform,SVR,RevisionRule));
	//ITK_CALL(BOMCorrect("X4","54455424AK9R_E","Color ERC Review and above"));

	
	printf("\n\t TotalPrtCount %d \n",TotalPrtCount);fflush(stdout);
	printf("\n\t ENVP_Diam_Check %d \n",ENVP_Diam_Check);fflush(stdout);
	printf("\n\t Weight_Check %d \n",Weight_Check);fflush(stdout);
	printf("\n\t MaterialCls_Check %d \n",MaterialCls_Check);fflush(stdout);
	printf("\n\t UOM_Check %d \n",UOM_Check);fflush(stdout);
	printf("\n\t PartCategoryDup_Check %d \n",PartCategoryDup_Check);fflush(stdout);
	printf("\n\t MatrInDrwDup_Check %d \n",MatrInDrwDup_Check);fflush(stdout);

	
	printf("\n\t ENVP_Diam_Check2 %d \n",ENVP_Diam_Check2);fflush(stdout);
	printf("\n\t Weight_Check2 %d \n",Weight_Check2);fflush(stdout);
	printf("\n\t UOM_Check2 %d \n",UOM_Check2);fflush(stdout);
	printf("\n\t PartCategoryDup_Check2 %d \n",PartCategoryDup_Check2);fflush(stdout);

	

	
	
	if(TotalPrtCount != 0)
	{
		dErrEnvDmPrcnt		= (double)ENVP_Diam_Check / TotalPrtCount * 100;
		dErrWghtPrcnt		= (double)Weight_Check / TotalPrtCount * 100;
		dErrMtClsPrcnt		= (double)MaterialCls_Check / TotalPrtCount * 100;
		dErrUoMPrcnt		= (double)UOM_Check / TotalPrtCount * 100;
		dErrQtyPrcnt		= (double)Qty_Check / TotalPrtCount * 100;
		dErrPrtCtPrcnt		= (double)PartCategoryDup_Check / TotalPrtCount * 100;
		dErrMatDrPrcnt		= (double)MatrInDrwDup_Check / TotalPrtCount * 100;
		dErrCMVRPrcnt		= (double)CMVR_Check / TotalPrtCount * 100;
		dErrCBMPrcnt		= (double)0 / CADBOM_Check * 100;		
	}

	dCntrEnvDm	= dErrEnvDmPrcnt * 5 / 100;
	dCntrWght	= dErrWghtPrcnt * 20 / 100;
	dCntrMtCls	= dErrMtClsPrcnt * 5 / 100;
	dCntrUoM	= dErrUoMPrcnt * 5 / 100;
	dCntrQty	= dErrQtyPrcnt * 20 / 100;
	dCntrPrtCt	= dErrPrtCtPrcnt * 10 / 100;
	dCntrMatDr	= dErrMatDrPrcnt * 5 / 100;
	dCntrCMVR	= dErrCMVRPrcnt * 15 / 100;
	dCntrCBM	= dErrCBMPrcnt * 15 / 100;

	dSumAttr = dCntrEnvDm + dCntrWght + dCntrMtCls + dCntrUoM + dCntrQty + dCntrPrtCt + dCntrMatDr + dCntrCMVR + dCntrCBM;

	dBomAccuracy = 100 - dSumAttr;

	printf("BOM Completeness (in percent) = %lf \n",dBomAccuracy);

	if(TotalPrtCount != 0)
	{
		dErrEnvDmPrcnt2		= (double)ENVP_Diam_Check2 / TotalPrtCount * 100;
		dErrWghtPrcnt2		= (double)Weight_Check2 / TotalPrtCount * 100;
		dErrUoMPrcnt2		= (double)UOM_Check2 / TotalPrtCount * 100;
		dErrQtyPrcnt2		= (double)Qty_Check2 / TotalPrtCount * 100;
		dErrPrtCtPrcnt2		= (double)PartCategoryDup_Check2 / TotalPrtCount * 100;
		dErrCMVRPrcnt2		= (double)CMVR_Check2 / TotalPrtCount * 100;
	}

	dCntrEnvDm2	= dErrEnvDmPrcnt2 * 5 / 100;
	dCntrWght2	= dErrWghtPrcnt2 * 20 / 100;
	dCntrUoM2	= dErrUoMPrcnt2 * 5 / 100;
	dCntrQty2	= dErrQtyPrcnt2 * 20 / 100;
	dCntrPrtCt2	= dErrPrtCtPrcnt2 * 10 / 100;
	dCntrCMVR2	= dErrCMVRPrcnt2 * 15 / 100;

	dSumAttr2 = dCntrEnvDm2 + dCntrWght2 + dCntrMtCls + dCntrUoM2 + dCntrQty2 + dCntrPrtCt2 + dCntrMatDr + dCntrCMVR2 + dCntrCBM;

	dBomAccuracy2 = 100 - dSumAttr2;

	printf("BOM Completeness (in percent) = %lf \n",dBomAccuracy);


	fp_Write = fopen(outputFile2,"w");
	if (fp_Write == NULL)
	{
					printf("ERROR: Cannot open File\n");
					return -1;
	}
	else
	{
				printf("File opened successfully.\n");
	}

	fprintf(fp_Write,",,,,REPORT,\n");
	if(fp_Write) fprintf(fp_Write,"Platform,,%s,\n",Platform);
	if(fp_Write) fprintf(fp_Write,"SVR,,%s,\n",SVR);
	if(fp_Write) fprintf(fp_Write,"Revision Rule,,%s,\n",RevisionRule);
	
	
	if(fp_Write) fprintf(fp_Write,"\nSI No.,Attributes,Total Parts,Occurence of errors,Error (percent),Severity,Contribution of Attribute\n");
	if(fp_Write) fprintf(fp_Write,"1,Envelop Dimension,%d,%d,%lf,5,%lf\n",TotalPrtCount,ENVP_Diam_Check,dErrEnvDmPrcnt,dCntrEnvDm);
	if(fp_Write) fprintf(fp_Write,"2,Weight (Component),%d,%d,%lf,20,%lf\n",TotalPrtCount,Weight_Check,dErrWghtPrcnt,dCntrWght);
	if(fp_Write) fprintf(fp_Write,"3,Material Class,%d,%d,%lf,5,%lf\n",TotalPrtCount,MaterialCls_Check,dErrMtClsPrcnt,dCntrMtCls);
	if(fp_Write) fprintf(fp_Write,"4,Unit of measure,%d,%d,%lf,5,%lf\n",TotalPrtCount,UOM_Check,dErrUoMPrcnt,dCntrUoM);
	if(fp_Write) fprintf(fp_Write,"5,Quantity,%d,%d,%lf,20,%lf\n",TotalPrtCount,Qty_Check,dErrQtyPrcnt,dCntrQty);
	if(fp_Write) fprintf(fp_Write,"6,Part Category,%d,%d,%lf,10,%lf\n",TotalPrtCount,PartCategoryDup_Check,dErrPrtCtPrcnt,dCntrPrtCt);
	if(fp_Write) fprintf(fp_Write,"7,Material in Drawing,%d,%d,%lf,5,%lf\n",TotalPrtCount,MatrInDrwDup_Check,dErrMatDrPrcnt,dCntrMatDr);
	if(fp_Write) fprintf(fp_Write,"8,CMVR Indicator,%d,%d,%lf,15,%lf\n",TotalPrtCount,CMVR_Check,dErrCMVRPrcnt,dCntrCMVR);
	if(fp_Write) fprintf(fp_Write,"9,CAD BOM Mismatch,%d,%d,%lf,15,%lf\n",CADBOM_Check,CADBOM_Check_Err,dErrCBMPrcnt,dCntrCBM);
	
	if(fp_Write) fprintf(fp_Write,",,,,Sum of 'Contribution of Attribute',%lf\n",dSumAttr);
	if(fp_Write) fprintf(fp_Write,",,,,BOM Completeness (in percent),%lf\n",dBomAccuracy);



	fp_Write2 = fopen(outputFile3,"w");
	if (fp_Write2 == NULL)
	{
					printf("ERROR: Cannot open File\n");
					return -1;
	}
	else
	{
				printf("File opened successfully.\n");
	}

	fprintf(fp_Write2,",,,,REPORT,\n");
	if(fp_Write2) fprintf(fp_Write2,"Platform,,%s,\n",Platform);
	if(fp_Write2) fprintf(fp_Write2,"SVR,,%s,\n",SVR);
	if(fp_Write2) fprintf(fp_Write2,"Revision Rule,,%s,\n",RevisionRule);
	
	
	if(fp_Write2) fprintf(fp_Write2,"\nSI No.,Attributes,Total Parts,Occurence of errors,Error (percent),Severity,Contribution of Attribute\n");
	if(fp_Write2) fprintf(fp_Write2,"1,Envelop Dimension,%d,%d,%lf,5,%lf\n",TotalPrtCount,ENVP_Diam_Check2,dErrEnvDmPrcnt2,dCntrEnvDm2);
	if(fp_Write2) fprintf(fp_Write2,"2,Weight (Component),%d,%d,%lf,20,%lf\n",TotalPrtCount,Weight_Check2,dErrWghtPrcnt2,dCntrWght2);
	if(fp_Write2) fprintf(fp_Write2,"3,Material Class,%d,%d,%lf,5,%lf\n",TotalPrtCount,MaterialCls_Check,dErrMtClsPrcnt,dCntrMtCls);
	if(fp_Write2) fprintf(fp_Write2,"4,Unit of measure,%d,%d,%lf,5,%lf\n",TotalPrtCount,UOM_Check2,dErrUoMPrcnt2,dCntrUoM2);
	if(fp_Write2) fprintf(fp_Write2,"5,Quantity,%d,%d,%lf,20,%lf\n",TotalPrtCount,Qty_Check2,dErrQtyPrcnt2,dCntrQty2);
	if(fp_Write2) fprintf(fp_Write2,"6,Part Category,%d,%d,%lf,10,%lf\n",TotalPrtCount,PartCategoryDup_Check2,dErrPrtCtPrcnt2,dCntrPrtCt2);
	if(fp_Write2) fprintf(fp_Write2,"7,Material in Drawing,%d,%d,%lf,5,%lf\n",TotalPrtCount,MatrInDrwDup_Check,dErrMatDrPrcnt,dCntrMatDr);
	if(fp_Write2) fprintf(fp_Write2,"8,CMVR Indicator,%d,%d,%lf,15,%lf\n",TotalPrtCount,CMVR_Check2,dErrCMVRPrcnt2,dCntrCMVR2);
	if(fp_Write2) fprintf(fp_Write2,"9,CAD BOM Mismatch,%d,%d,%lf,15,%lf\n",CADBOM_Check,CADBOM_Check_Err,dErrCBMPrcnt,dCntrCBM);
	
	if(fp_Write2) fprintf(fp_Write2,",,,,Sum of 'Contribution of Attribute',%lf\n",dSumAttr2);
	if(fp_Write2) fprintf(fp_Write2,",,,,BOM Correctness (in percent),%lf\n",dBomAccuracy2);


	fclose(fp_Write2);
	fclose(fp_Write);
	fclose(output);


	

	ITK_CALL(AE_find_datasettype2("MSExcel",&msWordType));
	
	tc_strcpy(DataSetName1,"");
	tc_strcat(DataSetName1,SVR);
	tc_strcat(DataSetName1,"_COMPLETENESS_");
	tc_strcat(DataSetName1,Data);

	ITK_CALL(AE_create_dataset_with_id(msWordType,DataSetName1,"BOMCmpRp","","",&wordDataset));		
	ITK_CALL(AE_save_myself(wordDataset));
	ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
	ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
	ITK_CALL(AE_import_named_ref(wordLatestDat_t,"excel",outputFile2,NULL,SS_BINARY));

	AOM_save(wordLatestDat_t);
	AOM_refresh(wordLatestDat_t, FALSE);
	AOM_unload(wordLatestDat_t);


	tc_strcpy(DataSetName2,"");
	tc_strcat(DataSetName2,SVR);
	tc_strcat(DataSetName2,"_Dump_");
	tc_strcat(DataSetName2,Data);

	ITK_CALL(AE_create_dataset_with_id(msWordType,DataSetName2,"BOMCmpCrrRpDump","","",&wordDataset2));
	ITK_CALL(AE_save_myself(wordDataset2));	
	ITK_CALL(AE_ask_dataset_latest_rev(wordDataset2,&wordLatestDat_t2));
	ITK_CALL(AOM_refresh(wordLatestDat_t2,TRUE));
	ITK_CALL(AE_import_named_ref(wordLatestDat_t2,"excel",outputFile,NULL,SS_BINARY));

	AOM_save(wordLatestDat_t2);
	AOM_refresh(wordLatestDat_t2, FALSE);
	AOM_unload(wordLatestDat_t2);


	tc_strcpy(DataSetName3,"");
	tc_strcat(DataSetName3,SVR);
	tc_strcat(DataSetName3,"_CORRECTNESS_");
	tc_strcat(DataSetName3,Data);

	ITK_CALL(AE_create_dataset_with_id(msWordType,DataSetName3,"BOMCrrRpDump","","",&wordDataset3));
	ITK_CALL(AE_save_myself(wordDataset3));	
	ITK_CALL(AE_ask_dataset_latest_rev(wordDataset3,&wordLatestDat_t3));
	ITK_CALL(AOM_refresh(wordLatestDat_t3,TRUE));
	ITK_CALL(AE_import_named_ref(wordLatestDat_t3,"excel",outputFile3,NULL,SS_BINARY));

	AOM_save(wordLatestDat_t3);
	AOM_refresh(wordLatestDat_t3, FALSE);
	AOM_unload(wordLatestDat_t3);


	//remove(outputFile);



	if(QRY_find("folder custom", &qryTag));
	if (qryTag)
	{
		qry_values2[0] = "BOMCmpCrrRp";
		if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrolObjectTag));
		printf("\n\t  Folder Count :%d: \n", rsltCount); fflush(stdout);
		if(rsltCount > 0)
		{

			if(AOM_lock(CntrolObjectTag[0]))PrintErrorStack();
			FL_insert(CntrolObjectTag[0],wordLatestDat_t2,999);
			FL_insert(CntrolObjectTag[0],wordLatestDat_t,999);			
			FL_insert(CntrolObjectTag[0],wordLatestDat_t3,999);
			if(AOM_save(CntrolObjectTag[0]))PrintErrorStack();
			if(AOM_unlock(CntrolObjectTag[0]));PrintErrorStack();
			if(AOM_refresh(CntrolObjectTag[0],1))PrintErrorStack();
			printf(  "\n\t BOMCmpCrrRp  \n"); fflush(stdout);
		}
	}


	if( tc_strcmp(COMPLETENESS_d,"Y")==0 )
	{
		printf(  "\n\t COMPLETENESS_d = Y  \n"); fflush(stdout);

		DR_objNo=tc_strtok(SVR,"_");
		printf(  "\n\t Design Revision no = %s  \n",DR_objNo); fflush(stdout);

		// CCV object stamping.

		ITK_CALL(ITEM_find_item(DR_objNo, &D_tag));
		ITK_CALL(ITEM_ask_latest_rev(D_tag, &DR_tag));

		ITK_CALL(AOM_ask_value_string(DR_tag,"item_id", &DR_Item_id ));
		printf(  "\n\t Design Revision Item Id = %s  \n",DR_Item_id); fflush(stdout);

		printf(  "\n\t dBomAccuracy = %lf  \n",dBomAccuracy); fflush(stdout);
		sprintf(Percentage,"%lf",dBomAccuracy);
		printf(  "\n\t Percentage = %s  \n",Percentage); fflush(stdout);

		AOM_lock(DR_tag);
		AOM_set_value_string(DR_tag,"t5_BOMCmpl",Percentage);
		AOM_save(DR_tag);
		AOM_refresh(DR_tag, TRUE);

		printf(  "\n\t t5_BOMCmpl Value assigned to CCV  \n"); fflush(stdout);


		// VC Object stamping.

		VehId=subString(SVR,0,8);
		tc_strcat(VehId,"R");
		printf("\t\n val2 =%s",VehId);

		ITK_CALL(ITEM_find_item(VehId, &Veh_tag));		
		ITK_CALL(ITEM_ask_latest_rev(Veh_tag, &VehR_tag));

		AOM_lock(VehR_tag);
		AOM_set_value_string(VehR_tag,"t5_BOMCmpl",Percentage);
		AOM_save(VehR_tag);
		AOM_refresh(VehR_tag, TRUE);

		printf(  "\n\t t5_BOMCmpl Value assigned to Vehicle  \n"); fflush(stdout);
		
		
	}

	
	printf("\n\t At End of MAIN FUN ****** \n");fflush(stdout);
	
	return ifail;
}


int BOMCorrect(char* Platform,char* SVR,char* RevisionRule)
{

	int			transfermode1Cnt		= 0;
	int			n_entriesV				= 1;
	int			resultCountVNCol		= 0;
	int			n_bom_views				= 0;
	int			rulefound				= 0;
	int			n_lines1				= 0;
	int			p1						= 0;
	int			n_lines2				= 0;
	int			p2						= 0;
	int			Level					= 0;

	char		*RevTyp					= NULL;

	char		**rulename				= NULL;
	char		**rulevalue				= NULL;

	tag_t		plat					= NULLTAG;
	tag_t		rev						= NULLTAG;
	tag_t		RevTypTag				= NULLTAG;
	tag_t		VariqueryTag			= NULLTAG;
	tag_t		VarientRuletag			= NULLTAG;
	tag_t		item					= NULLTAG;
	tag_t		bom_view				= NULLTAG;
	tag_t		bom_window				= NULLTAG;
	tag_t		rule					= NULLTAG;
	tag_t		close_tag				= NULLTAG;
	tag_t		top_line				= NULLTAG;
	tag_t		ArchiTNode				= NULLTAG;
	tag_t		ModuleLine				= NULLTAG;

	tag_t		*outputVNCol_tags		=NULLTAG;
	tag_t		*bom_views				=NULLTAG;
	tag_t		*closurerule			=NULLTAG;
	tag_t		*lines1					=NULLTAG;
	tag_t		*lines2					=NULLTAG;
	tag_t		view_type				= NULLTAG;

	char		*qry_entries3[1]		= {"Name"};

	char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));

	printf("\n\t ********************INSIDE BOMCorrect FUN*****************8 \n");fflush(stdout);
	printf("\n\t RevisionRule %s \n",RevisionRule);fflush(stdout);

	ITK_CALL(ITEM_find_item(Platform, &plat));
	ITK_CALL(ITEM_ask_latest_rev(plat, &rev));

	if(TCTYPE_ask_object_type(rev, &RevTypTag));
	if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
	printf("\n\t MT: RevTyp type: [%s]\n", RevTyp);fflush(stdout);

	if (tc_strcmp(RevTyp,"T5_PlatformRevision")==0)
	{

		if(QRY_find("VariantRule", &VariqueryTag));
		printf("\n\t After IFERR_REPORT : QRY_find .... "); fflush(stdout);


		valuesNonColSvr[0] = SVR ;
		if(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));
		printf("   n_entriesV:%d   resultCount:%d \n\t",n_entriesV,resultCountVNCol); fflush(stdout);

		if (resultCountVNCol > 0)
		{
			VarientRuletag = outputVNCol_tags[0];
		}
		else
		{
			printf ("\n NonColour-SVR-VarientRule not present  [%s]\n", SVR); fflush(stdout);
			exit (0);
		}	

		if ( rev !=NULLTAG )
		{
			CALLAPI ( PS_find_view_type( "view", &view_type ));
			printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

			if ( view_type != NULLTAG )
			{
				CALLAPI ( ITEM_ask_item_of_rev( rev, &item ));
				CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

				bom_view = bom_views[0];
			}
			else
			printf("\nView not found check.......\n"); fflush(stdout);
		}


        if ( bom_view != NULLTAG )
        {
			printf(" before BOM_create_window..\n");          fflush(stdout);   
			CALLAPI ( BOM_create_window( &bom_window ));
			CALLAPI(CFM_find( RevisionRule, &rule ));
			CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
			
			
			CALLAPI(PIE_find_closure_rules( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
			
			printf ("rule count %d \n",rulefound);fflush(stdout);
			if (rulefound > 0)
			{
				close_tag = closurerule[0];
				printf ("closure rule found \n");fflush(stdout);
			}

			//CALLAPI(BOM_window_set_closure_rule( bom_window,close_tag, 0, rulename,rulevalue ));			
			CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));
			CALLAPI ( BOM_set_window_top_line( bom_window, NULLTAG, rev, NULLTAG, &top_line ));
			printf( " After BOM_set_window_top_line..\n");fflush(stdout);		
		  
			
			if(top_line!=NULLTAG)
			{
				CALLAPI(BOM_window_hide_unconfigured(bom_window));
				CALLAPI(BOM_window_show_variants(bom_window));
				     
				printf("\n After inside bom_window-----\n"); fflush(stdout);                                    
				CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
				printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);

				CALLAPI(BOM_window_hide_variants(bom_window));				
				CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines1));
				printf("\n Clr_LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);

				if (n_lines1 >0)
				{
					for (p1=0;p1<n_lines1 ;p1++ )
					{
						if(ArchiTNode) ArchiTNode=NULLTAG;
						ArchiTNode=lines1[p1];

						CALLAPI(BOM_line_ask_child_lines(ArchiTNode, &n_lines2, &lines2));

						//printf(  "\n 2nd level child count %d \n",n_lines2); fflush(stdout); 

						if (n_lines2 >0)
						{
							for (p2=0;p2<n_lines2 ;p2++ )
							{
								if(ModuleLine) ModuleLine=NULLTAG;
								ModuleLine=lines2[p2];

								Level = 1;

								//ITK_CALL(BOMCorrectRcsn(ModuleLine,Level));
								ITK_CALL(BOMSetCreate(ModuleLine));
							}
						}
					}
					printf(  "\n Total Count %d \n",ia); fflush(stdout); 

					int jkl =0;

					for (jkl=0;jkl<ia ;jkl++ )
					{
						ITK_CALL(BOMCorrectRcsn(tagSET[jkl]));
					}
				}

				CALLAPI(BOM_save_window(bom_window));
				CALLAPI(BOM_close_window(bom_window));
			}

		}
		else
		{
			printf(  "\n\t no bom window found here \n"); fflush(stdout); 
		}
	}
	return ITK_ok;
}

int BOMSetCreate(tag_t Topline)
{
	int LineCnt =0;
	int ii =0;
	int jj =0;
	int Flag =0;
	
	char *RevId	=NULL;
	char *RevId2=NULL;
	tag_t *Lines	=NULLTAG;
	tag_t ChildLine	=NULLTAG;

	ITK_CALL(AOM_ask_value_string(Topline, "bl_item_item_id", &RevId));

	for (jj=0;jj<ia ;jj++ )
	{
		tc_strcpy(RevId2,"");
		ITK_CALL(AOM_ask_value_string(tagSET[jj], "bl_item_item_id", &RevId2 ));
		printf(  "\n\t 1} =%s and 2}= %s \n",RevId,RevId2); fflush(stdout); 
		if (tc_strcmp(RevId,RevId2)==0)
		{
			Flag=1;
		}
	}
	if (Flag==0)
	{
		tagSET[ia]=Topline;
		setAddStr(&ia,&sFinalDataSet,RevId);
	}	

	//printf(  "\n ***********************Total Count %d \n",ia); fflush(stdout); 

	CALLAPI(BOM_line_ask_child_lines(Topline, &LineCnt, &Lines));
	//printf("\n\t child count=> %d \n",LineCnt);fflush(stdout);

	if (LineCnt >0)
	{
		for (ii=0;ii<LineCnt ;ii++ )
		{
			if(ChildLine) ChildLine=NULLTAG;
			ChildLine=Lines[ii];

			ITK_CALL(BOMSetCreate(ChildLine));
		}
	}
	return ITK_ok;
}

int ENVErrorFn (char *ENVP_Diam)
{
	int Flag = 0;

	char    *Tok1				= NULL;	
	char    *Tok2				= NULL;	
	char    *Tok3				= NULL;	

	printf("\n\t Env Dia is [%s] \n",ENVP_Diam);
	if (tc_strcmp(ENVP_Diam,"0X0X0")==0 || tc_strcmp(ENVP_Diam,"0x0x0")==0 )
	{
		Flag =1;
		//printf("\n\t 0X0X0 found  \n");
	}

	if (tc_strstr(ENVP_Diam,"x")!=NULL)
	{
		//printf("\n\t inside if lower case  \n");

		Tok1=tc_strtok(ENVP_Diam,"x");
		Tok2=tc_strtok(NULL,"x");
		Tok3=tc_strtok(NULL,"x");		
	}
	else
	{
		//printf("\n\t inside else upper case  \n");

		Tok1=tc_strtok(ENVP_Diam,"X");
		Tok2=tc_strtok(NULL,"X");
		Tok3=tc_strtok(NULL,"X");
	}	

	//printf("\n\t Tok1 = [%s] \t Tok2 = [%s] Tok3 = [%s] \n",Tok1,Tok2,Tok3);	

	if( tc_strcmp(Tok1,"")==0 || tc_strcmp(Tok2,"")==0 || tc_strcmp(Tok3,"")==0 || tc_strcmp(Tok1,NULL)==0 || tc_strcmp(Tok2,NULL)==0 || tc_strcmp(Tok3,NULL)==0 )
	{
		Flag =1;

		//printf("\n\t TOK is NULL  \n");
	}
		
	printf("\n\t Flag = %d  \n",Flag);

	return Flag;
}

int BOMCorrectRcsn(tag_t TopLine)
{
	int			ii						= 0;
	int			LineCnt					= 0;
	int			blqnt					= 0;
	int			int_qnt					= 0;
	int			nEnvDmLen				= 0;
	int			InLevel 				= 0;
	int			DatasetCnt				= 0;
	int			DatasetFlag				= 0;
	int			di						= 0;

	char		*blqnt_str				= NULL;
	char		*Item_id				= NULL;
	char		*Item_RevId				= NULL;
	char		*ENVP_Diam				= NULL;
	char		*Weight					= NULL;
	char		*UOM					= NULL;
	char		*MaterialCls			= NULL;
	char		*CMVRReq				= NULL;
	char		*RevDesc				= NULL;
	char		*HomoLgtReq				= NULL;
	char		*PartCategory			= NULL;
	char		*MatrInDrw				= NULL;
	char		*RevDescDup1			= NULL;
	char		*RevDescDup				= NULL;
	char		*MatrInDrwDup1			= NULL;
	char		*MatrInDrwDup			= NULL;
	char		*PartCategoryDup1		= NULL;
	char		*PartCategoryDup		= NULL;
	char		*PartType				= NULL;
	char		*ProjectCode			= NULL;
	char		*First2Digit			= NULL;
	char		*D_typeName				= NULL;

	tag_t		ChildLine				= NULLTAG;
	tag_t		Rev_Tag					= NULLTAG;
	tag_t		*Lines					= NULLTAG;
	tag_t		RelType					= NULLTAG;
	tag_t		DatasetTypeTag			= NULLTAG;
	tag_t		*DatasetList			= NULLTAG;

	int n_entries =2;
	int n_found =2;
	int PartCatFlag =0;
	int i =0;
	int EnvFlag = 0;
	char *Classi_class =NULL;
	tag_t query = NULLTAG;
	tag_t *cntr_objects = NULLTAG;
	char *qry_entries[2] = {"SYSCD","SUBSYSCD"};

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));

	//InLevel= Level +1;

	printf("\n\t INSIDE BOMCorrectRcsn FUN \n");fflush(stdout);
	printf("\n\t Level => %d \n",InLevel);fflush(stdout);

	CALLAPI( BOM_line_look_up_attribute ("bl_quantity",&blqnt));

	CALLAPI(BOM_line_ask_attribute_string(TopLine, blqnt, &blqnt_str));
	int_qnt=atoi(blqnt_str);
	//printf(  "\n\t child quantity int-------------> %d \n",int_qnt); fflush(stdout);

	TotalPrtCount = TotalPrtCount + 1;

	CALLAPI(AOM_ask_value_string(TopLine, "bl_item_item_id", &Item_id ));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_rev_item_revision_id", &Item_RevId ));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_rev_object_desc", &RevDesc));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_Design Revision_t5_EnvelopeDimensions", &ENVP_Diam ));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_Design Revision_t5_Weight", &Weight ));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_Design Revision_t5_uom", &UOM ));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_Design Revision_t5_MatlClass", &MaterialCls ));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_Design Revision_t5_CMVRCertificationReqd", &CMVRReq ));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_Design Revision_t5_HomologationReqd", &HomoLgtReq ));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_Design Revision_t5_SpareCriteria", &PartCategory ));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_Design Revision_t5_Material", &MatrInDrw ));

	STRNG_replace_str(RevDesc,"\n"," ",&RevDescDup1);
	STRNG_replace_str(RevDescDup1,","," ",&RevDescDup);

	STRNG_replace_str(MatrInDrw,"\n"," ",&MatrInDrwDup1);
	STRNG_replace_str(MatrInDrwDup1,","," ",&MatrInDrwDup);

	STRNG_replace_str(PartCategory,"\n"," ",&PartCategoryDup1);
	STRNG_replace_str(PartCategoryDup1,","," ",&PartCategoryDup);



	//printf(  "\n\n\t{ [%s %s]   [%s]   [%d]  [%s]  [%s]  [%s]  [%s]  [%s] [%s] [%s] [%s]}\n",Item_id,Item_RevId,RevDesc,int_qnt,ENVP_Diam,Weight,UOM,MaterialCls,CMVRReq,HomoLgtReq,PartCategory,MatrInDrw); fflush(stdout);

	fprintf(output,",");
	fprintf(output,"'%s",Item_id);
	fprintf(output,",");
	fprintf(output,"%s",Item_RevId);
	fprintf(output,",");
	fprintf(output,"%s",RevDescDup);
	fprintf(output,",");
	fprintf(output,"%s",ENVP_Diam);
	fprintf(output,",");
	fprintf(output,"%s",Weight);
	fprintf(output,",");
	fprintf(output,"%s",MaterialCls);
	fprintf(output,",");
	fprintf(output,"%s",UOM);
	fprintf(output,",");
	fprintf(output,"%d",int_qnt);
	fprintf(output,",");
	fprintf(output,"%s",PartCategoryDup);
	fprintf(output,",");
	fprintf(output,"%s",MatrInDrwDup);
	fprintf(output,",");
	fprintf(output,"%s",CMVRReq);
	fprintf(output,",");
	fprintf(output,"%s",HomoLgtReq);
	fprintf(output,",");

	

	CALLAPI(ITEM_find_rev(Item_id,Item_RevId,&Rev_Tag));

	CALLAPI(GRM_find_relation_type("IMAN_specification",&RelType));
	CALLAPI(GRM_list_secondary_objects_only(Rev_Tag,RelType,&DatasetCnt,&DatasetList));

	if (DatasetCnt>0)
	{
		for(di=0;di<DatasetCnt;di++)
		{
			CALLAPI(TCTYPE_ask_object_type(DatasetList[di],&DatasetTypeTag));
			CALLAPI(TCTYPE_ask_name2(DatasetTypeTag,&D_typeName));	
			
			if(tc_strcmp(D_typeName,"CMI2Drawing")==0 || tc_strcmp(D_typeName,"CMI2Part")==0 || tc_strcmp(D_typeName,"CMI2Product")==0 || tc_strcmp(D_typeName,"ProPrt")==0 || tc_strcmp(D_typeName,"ProAsm")==0 || tc_strcmp(D_typeName,"ProDrw")==0 )
			{
				DatasetFlag=1;
				break;	
			}
		}
	}
	if (DatasetFlag ==1)
	{
		CADBOM_Check = CADBOM_Check + 1;
		fprintf(output,"CAD Available");
	}
	else
	{
		fprintf(output,"NA");
	}
	
	fprintf(output,",");	
	

	CALLAPI(AOM_ask_value_string(TopLine, "bl_Design Revision_t5_PartType", &PartType ));
	CALLAPI(AOM_ask_value_string(TopLine, "bl_Design Revision_t5_ProjectCode", &ProjectCode ));

	if (tc_strcmp(PartType,"D")!=0) //ByPass to Dummy Part type
	{

		if (tc_strstr(PartCategoryDup,"BTS")==0)
		{	
			EnvFlag = 0;

			EnvFlag = ENVErrorFn(ENVP_Diam);

			if (EnvFlag ==1)
			{
				ENVP_Diam_Check = ENVP_Diam_Check + 1;
				fprintf(output,"ENV~");
			}	
		}

		if((tc_strcmp(Weight,"0")==0 || tc_strcmp(Weight,"")==0) && tc_strcmp(PartType,"C")==0)
		{
			Weight_Check = Weight_Check + 1;
			//nlsStrCat(sErrColmn,"WGHT~");
			fprintf(output,"WGHT~");
		}

		if((tc_strcmp(MaterialCls,"")==0 || tc_strcmp(MaterialCls,NULL)==0) && tc_strcmp(PartType,"C")==0)
		{
			if (tc_strcmp(ProjectCode,"1111")!=0)
			{
				MaterialCls_Check = MaterialCls_Check + 1;
				//nlsStrCat(sErrColmn,"MTCLS~");
				fprintf(output,"MTCLS~");
			}
		}

		if(tc_strcmp(UOM,"")==0 || tc_strcmp(UOM,NULL)==0)
		{
			UOM_Check = UOM_Check + 1;
			fprintf(output,"UoM~");
		}

		if (tc_strcmp(ProjectCode,"1111")!=0)
		{
			if(tc_strcmp(PartCategoryDup,"")==0 || tc_strcmp(PartCategoryDup,NULL)==0)
			{
				PartCategoryDup_Check = PartCategoryDup_Check + 1;
				fprintf(output,"PCAT~");
			}
			else
			{	

				CALLAPI(QRY_find("Control Objects...",&query));

				qry_values[0] = "PRTCAT" ;
				qry_values[1] = "PRTCAT" ;

				CALLAPI(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
				//printf("\n\t Part Category Ctr Obj Cnt  :%d", n_found);fflush(stdout);


				if(n_found>0)
				{
					PartCatFlag =0;
					for (i = 0; i < n_found; i++)
					{
						CALLAPI(AOM_ask_value_string(cntr_objects[i],"object_name",&Classi_class));
						//printf("\ncurrent name -------> %s ",Classi_class);fflush(stdout);

						if (tc_strstr(PartCategoryDup,Classi_class)==0 || tc_strcmp(PartCategoryDup,Classi_class)==0 )
						{
							PartCatFlag=1;
						}
					}
				}
				if (PartCatFlag ==0)
				{
					PartCategoryDup_Check = PartCategoryDup_Check + 1;
					fprintf(output,"PCAT~");
				}		
			}
		}

		if((tc_strcmp(MatrInDrwDup,"")==0 || tc_strcmp(MatrInDrwDup,NULL)==0) && tc_strcmp(PartType,"C")==0)
		{
			if (tc_strcmp(ProjectCode,"1111")!=0)
			{
				MatrInDrwDup_Check = MatrInDrwDup_Check + 1;
				fprintf(output,"MTDR~");
			}
		}


		

		
	}
	fprintf(output,",");

	//BOMCorrectness Values.

	if (tc_strcmp(PartType,"D")!=0)
	{
		if (tc_strstr(PartCategoryDup,"BTS")==0) //ByPass for BTS
		{
			

			if (EnvFlag ==1)
			{
				ENVP_Diam_Check2 = ENVP_Diam_Check2 + 1;
				fprintf(output,"ENV~");
			}			
		}

		if((tc_strcmp(Weight,"0")==0 || tc_strcmp(Weight,"")==0) && tc_strcmp(PartType,"C")==0)
		{
			Weight_Check2 = Weight_Check2 + 1;
			//nlsStrCat(sErrColmn,"WGHT~");
			fprintf(output,"WGHT~");
		}

		if((tc_strcmp(MaterialCls,"")==0 || tc_strcmp(MaterialCls,NULL)==0) && tc_strcmp(PartType,"C")==0)
		{
			if (tc_strcmp(ProjectCode,"1111")!=0)
			{
				//MaterialCls_Check = MaterialCls_Check + 1;
				//nlsStrCat(sErrColmn,"MTCLS~");
				fprintf(output,"MTCLS~");
			}
		}

		First2Digit = subString(Item_id,0,2);
		printf("\n\t First2Digit -------> %s ",First2Digit);fflush(stdout);

		if (tc_strlen(Item_id)==11)
		{
			if(tc_strcmp(UOM,"")==0 || tc_strcmp(UOM,NULL)==0)
			{
				UOM_Check2 = UOM_Check2 + 1;
				fprintf(output,"UoM~");
			}
			else if ((tc_strcmp(First2Digit,"11")==0 || tc_strcmp(First2Digit,"12")==0 || tc_strcmp(First2Digit,"13")==0 || tc_strcmp(First2Digit,"14")==0 || tc_strcmp(First2Digit,"15")==0
				|| tc_strcmp(First2Digit,"16")==0 || tc_strcmp(First2Digit,"17")==0 || tc_strcmp(First2Digit,"18")==0 || tc_strcmp(First2Digit,"35")==0 || tc_strcmp(First2Digit,"41")==0 
				|| tc_strcmp(First2Digit,"43")==0 ) && tc_strcmp(UOM,"4")!=0)
			{
				UOM_Check2 = UOM_Check2 + 1;
				fprintf(output,"UoM~");
			}
			else if ((tc_strcmp(First2Digit,"50")==0 || tc_strcmp(First2Digit,"51")==0 || tc_strcmp(First2Digit,"59")==0 ) && tc_strcmp(UOM,"2")!=0)
			{
				UOM_Check2 = UOM_Check2 + 1;
				fprintf(output,"UoM~");
			}
			else if ((tc_strcmp(First2Digit,"56")==0 ) && ( tc_strcmp(UOM,"2")!=0 || tc_strcmp(UOM,"3")!=0 ))
			{
				UOM_Check2 = UOM_Check2 + 1;
				fprintf(output,"UoM~");
			}
			else if ((tc_strcmp(First2Digit,"55")==0 ) && ( tc_strcmp(UOM,"3")!=0))
			{
				UOM_Check2 = UOM_Check2 + 1;
				fprintf(output,"UoM~");
			}
			else if ((tc_strcmp(First2Digit,"51")==0 || tc_strcmp(First2Digit,"59")==0 ) && tc_strcmp(UOM,"1")!=0)
			{
				UOM_Check2 = UOM_Check2 + 1;
				fprintf(output,"UoM~");
			}
			else if ((tc_strcmp(First2Digit,"62")==0 ) && ( tc_strcmp(UOM,"4")!=0 || tc_strcmp(UOM,"1")!=0))
			{
				UOM_Check2 = UOM_Check2 + 1;
				fprintf(output,"UoM~");
			}
		}

		

		if (tc_strcmp(ProjectCode,"1111")!=0)
		{
			if(tc_strcmp(PartCategoryDup,"")==0 || tc_strcmp(PartCategoryDup,NULL)==0)
			{
				PartCategoryDup_Check2 = PartCategoryDup_Check2 + 1;
				fprintf(output,"PCAT~");
			}
			else
			{	

				if (tc_strcmp(PartType,"G")==0)
				{
					if (tc_strstr(PartCategoryDup,"BTS")!=0)
					{
						PartCategoryDup_Check2 = PartCategoryDup_Check2 + 1;
						fprintf(output,"PCAT~");

					}
				}
				else
				{
					CALLAPI(QRY_find("Control Objects...",&query));

					qry_values[0] = "PRTCAT" ;
					qry_values[1] = "PRTCAT" ;

					CALLAPI(QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects));
					//printf("\n\t Part Category Ctr Obj Cnt  :%d", n_found);fflush(stdout);


					if(n_found>0)
					{
						PartCatFlag =0;
						for (i = 0; i < n_found; i++)
						{
							CALLAPI(AOM_ask_value_string(cntr_objects[i],"object_name",&Classi_class));
							//printf("\ncurrent name -------> %s ",Classi_class);fflush(stdout);

							if (tc_strstr(Classi_class,PartCategoryDup)==0 || tc_strcmp(PartCategoryDup,Classi_class)==0 )
							{
								PartCatFlag=1;
							}
						}
					}
					if (PartCatFlag ==0)
					{
						PartCategoryDup_Check2 = PartCategoryDup_Check2 + 1;
						fprintf(output,"PCAT~");
					}
				}						
			}
		}

		if((tc_strcmp(MatrInDrwDup,"")==0 || tc_strcmp(MatrInDrwDup,NULL)==0) && tc_strcmp(PartType,"C")==0)
		{
			if (tc_strcmp(ProjectCode,"1111")!=0)
			{
				//MatrInDrwDup_Check = MatrInDrwDup_Check + 1;
				fprintf(output,"MTDR~");
			}
		}		
	}

	fprintf(output,",");
	fprintf(output,"\n");

//	CALLAPI(BOM_line_ask_child_lines(TopLine, &LineCnt, &Lines));
//
//	printf("\n\t child of module %s;%s => %d \n",Item_id,Item_RevId,LineCnt);fflush(stdout);
//
//	if (LineCnt >0)
//	{
//		for (ii=0;ii<LineCnt ;ii++ )
//		{
//			if(ChildLine) ChildLine=NULLTAG;
//			ChildLine=Lines[ii];
//
//			ITK_CALL(BOMCorrectRcsn(ChildLine,InLevel));
//		}
//	}

	return ITK_ok;
}
