<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:plm="http://www.plmxml.org/Schemas/PLMXMLSchema"
    xmlns="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:o="urn:schemas-microsoft-com:office:office"
    xmlns:x="urn:schemas-microsoft-com:office:excel"
    xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
    xmlns:html="http://www.w3.org/TR/REC-html40" >
    
    <xsl:output method="xml" version="1.0" indent="yes" />
    <xsl:strip-space elements="*"/>
    
    <xsl:key name="occurrence"          match="plm:Occurrence"      use="@id"/>
    <xsl:param name="PlatformRootId" select="substring-after(/plm:PLMXML/plm:Header/@traverseRootRefs,'#')"></xsl:param>
    
    
    <xsl:template name="GetOptionFamilyValue">
        <xsl:param name="occStr"/>
        <xsl:param name="VrFormula"/>
        
        <xsl:if test="$VrFormula!=''">
            <xsl:choose>
                <xsl:when test="contains($VrFormula,'&amp;')">
                   <!-- <Cell> <Data ss:Type="String"><xsl:value-of select="substring-before($VrFormula,'&amp;')"/></Data></Cell>
                    <Cell> <Data ss:Type="String"><xsl:value-of select="substring-after($VrFormula,'&amp;')"/></Data></Cell>-->
                    
                    
         
                    <xsl:call-template name="GetOptionFamilyValue">
                        <xsl:with-param name="occStr" select="$occStr"/>
                        <xsl:with-param name="VrFormula" select="substring-before($VrFormula,'&amp;')"/>
                    </xsl:call-template>
                    
                    <xsl:call-template name="GetOptionFamilyValue">
                        <xsl:with-param name="occStr" select="$occStr"/>
                        <xsl:with-param name="VrFormula" select="substring-after($VrFormula,'&amp;')"/> 
                    </xsl:call-template> 
                    
                </xsl:when>
                <xsl:otherwise>
                    
                    <xsl:variable name="occurenceElement" select="key('occurrence',$occStr)"/>
                    <xsl:variable name="revRef" select="substring-after($occurenceElement/@parentRef,'#')"/>
                    
                    <Row>
                        <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occStr]/plm:UserData/plm:UserValue[@title='bl_Design Revision_t5_ModuleName']/@value"/></Data></Cell>
                        <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occStr]/plm:UserData/plm:UserValue[@title='bl_Design Revision_t5_ModuleAddress']/@value"/></Data></Cell> 
                        <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occStr]/plm:UserData/plm:UserValue[@title='bl_item_item_id']/@value"/></Data></Cell> 
                        <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$revRef]/plm:UserData/plm:UserValue[@title='bl_item_Smc0HasVariantConfigContext']/@value"/></Data></Cell> 

                    <xsl:choose>
                        <xsl:when test="contains($VrFormula,'[Teamcenter]')">
                            <xsl:variable name="VrFormulaFinal" select="substring-after($VrFormula,'[Teamcenter]')"/>
                            <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="substring-before($VrFormulaFinal,'=')"/></Data></Cell>
                            <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="substring-after($VrFormulaFinal,'=')"/></Data></Cell>
                           
                            
                            
                        </xsl:when>
                        <xsl:otherwise>
                            
                            <xsl:variable name="VrFormulaFinal" select="$VrFormula"/>
                            <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="substring-before($VrFormulaFinal,'=')"/></Data></Cell>
                            <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="substring-after($VrFormulaFinal,'=')"/></Data></Cell>
                           
                            
                        </xsl:otherwise>
                    </xsl:choose>
                    </Row>
                    
                </xsl:otherwise>
            </xsl:choose>
        </xsl:if>
        <xsl:if test="$VrFormula=''">
            <xsl:variable name="occurenceElement" select="key('occurrence',$occStr)"/>
            <xsl:variable name="revRef" select="substring-after($occurenceElement/@parentRef,'#')"/>
            <Row>
                <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occStr]/plm:UserData/plm:UserValue[@title='bl_Design Revision_t5_ModuleName']/@value"/></Data></Cell>
                <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occStr]/plm:UserData/plm:UserValue[@title='bl_Design Revision_t5_ModuleAddress']/@value"/></Data></Cell> 
                <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occStr]/plm:UserData/plm:UserValue[@title='bl_item_item_id']/@value"/></Data></Cell> 
                <Cell ss:StyleID="s24"> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$revRef]/plm:UserData/plm:UserValue[@title='bl_item_Smc0HasVariantConfigContext']/@value"/></Data></Cell>
                <Cell ss:StyleID="s24"> </Cell>
                <Cell ss:StyleID="s24"> </Cell>
            </Row>
        </xsl:if>
    </xsl:template>
    
    
    <xsl:template name="CreateCL">
        <xsl:param name="occStr"/>
        <xsl:param name="levelID"/>
        
        <xsl:if test="$occStr!=''">
            <xsl:choose>
                <xsl:when test="contains($occStr,' ')">
                    <xsl:variable name="occid" select="substring-before($occStr,' ')"/>

                    <xsl:call-template name="CreateCL">
                        <xsl:with-param name="occStr" select="$occid"/>
                        <xsl:with-param name="levelID" select="$levelID"/>

                    </xsl:call-template>
                    
                    <xsl:call-template name="CreateCL">
                        <xsl:with-param name="occStr" select="substring-after($occStr,' ')"/>
                        <xsl:with-param name="levelID" select="$levelID"/>
                    </xsl:call-template>
                    
                </xsl:when>
                
                <xsl:otherwise>
                    <xsl:call-template name="creCLextSort">
                        <xsl:with-param name="occID" select="$occStr"/>
                        <xsl:with-param name="levelID" select="$levelID"/>

                    </xsl:call-template>
                    
                </xsl:otherwise>
            </xsl:choose>
        </xsl:if>
    </xsl:template>
    
    
    <xsl:template name="creCLextSort">
       
        <xsl:param name="occID"/>
        <xsl:param name="levelID"/>
        <xsl:if test="$levelID=1">
        <xsl:variable name="occurenceElement" select="key('occurrence',$occID)"/>   
        
        <xsl:variable name="occRefs" select="$occurenceElement/@occurrenceRefs"/>
            <xsl:choose>
                <xsl:when test="contains($occRefs,' ')">
                    <xsl:variable name="occid" select="substring-before($occRefs,' ')"/>
                    
                    <xsl:call-template name="CreateCL">
                        <xsl:with-param name="occStr" select="$occid"/>
                        <xsl:with-param name="levelID" select="$levelID+1"/>
                        
                    </xsl:call-template>
                    
                    <xsl:call-template name="CreateCL">
                        <xsl:with-param name="occStr" select="substring-after($occRefs,' ')"/>
                        <xsl:with-param name="levelID" select="$levelID+1"/>
                    </xsl:call-template>
                    
                </xsl:when>
                
                <xsl:otherwise>
                    <xsl:call-template name="creCLextSort">
                        <xsl:with-param name="occID" select="$occRefs"/>
                        <xsl:with-param name="levelID" select="$levelID+1"/>
                        
                    </xsl:call-template>
                    
                </xsl:otherwise>
            </xsl:choose>
           
        </xsl:if>
        <xsl:if test="$levelID=2">
           <!-- <xsl:choose>
                <xsl:when test="contains($occID,' ')">
                    <xsl:variable name="occid" select="substring-before($occID,' ')"/>
                    
                    <xsl:call-template name="CreateCL">
                        <xsl:with-param name="occStr" select="$occid"/>
                        <xsl:with-param name="levelID" select="$levelID"/>
                        
                    </xsl:call-template>
                    
                    <xsl:call-template name="CreateCL">
                        <xsl:with-param name="occStr" select="substring-after($occID,' ')"/>
                        <xsl:with-param name="levelID" select="$levelID"/>
                    </xsl:call-template>
                    
                </xsl:when>

                <xsl:otherwise>
                    <xsl:call-template name="creCLextSort">
                        <xsl:with-param name="occID" select="$occID"/>
                        <xsl:with-param name="levelID" select="$levelID"/>
                        
                    </xsl:call-template>
                    
                </xsl:otherwise>
            </xsl:choose>-->
           
           <!-- <Cell> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occID]/plm:UserData/plm:UserValue[@title='bl_Design Revision_t5_ModuleName']/@value"/></Data></Cell>
                <Cell> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occID]/plm:UserData/plm:UserValue[@title='bl_Design Revision_t5_ModuleAddress']/@value"/></Data></Cell> 
                <Cell> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occID]/plm:UserData/plm:UserValue[@title='bl_item_item_id']/@value"/></Data></Cell> 
                <Cell> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occID]/plm:UserData/plm:UserValue[@title='bl_item_Smc0HasVariantConfigContext']/@value"/></Data></Cell> 
                <Cell> <Data ss:Type="String"><xsl:value-of select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occID]/plm:UserData/plm:UserValue[@title='bl_formula']/@value"/></Data></Cell>
         -->
            <xsl:call-template name="GetOptionFamilyValue">
                <xsl:with-param name="occStr" select="$occID"/>
                    <xsl:with-param name="VrFormula" select="/plm:PLMXML/plm:ProductView/plm:Occurrence[@id=$occID]/plm:UserData/plm:UserValue[@title='bl_formula']/@value"/>
                </xsl:call-template>
            
            
            
        </xsl:if> 

    </xsl:template>
    
    
    
    
    
    <xsl:template match="/">
        <xsl:call-template name="ReportHeader"></xsl:call-template>        
    </xsl:template>
     <xsl:template name="ReportHeader">
        <xsl:processing-instruction name="mso-application">progid="Excel.Sheet"</xsl:processing-instruction>
        <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:o="urn:schemas-microsoft-com:office:office"
            xmlns:x="urn:schemas-microsoft-com:office:excel"
            xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
            xmlns:html="http://www.w3.org/TR/REC-html40">
            
            
            <Styles>
                <Style ss:ID="s21" ss:Name="ReportHeader">
                    <Interior ss:Color="#696969" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Alignment ss:Horizontal="Center"/>
                    <Font ss:Color="#FFFFFF" ss:Bold="1" ss:FontName="Cambria" ss:Size="18"/>
                </Style>
                <Style ss:ID="s22" ss:Name="PropertyCell">
                    <Interior ss:Color="#98CAFF" ss:Pattern="Solid"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="2.5"/>
                    </Borders>
                    <Font ss:Color="#000000" ss:Bold="1" ss:Size="16" ss:FontName="Calibri"/>
                    <Alignment ss:Horizontal="Center"/>
                </Style>
                <Style ss:ID="s23" ss:Name="ReportInputs">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Cambria" ss:Size="12"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                </Style>
                <Style ss:ID="s24" ss:Name="DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <!--<Alignment ss:Horizontal="Right"/>-->
                </Style>
                <Style ss:ID="s25" ss:Name="L1DataCell">
                    <Font ss:Color="#000000" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFD1B3" ss:Pattern="Solid"/>
                </Style>
                <Style ss:ID="s26" ss:Name="PropertyNameCell">
                    <Font ss:Color="#000000" ss:Bold="1" ss:FontName="Calibri" ss:Size="11"/>
                    <Borders>
                        <Border ss:Position="Left" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Top" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Right" ss:LineStyle="Continuous" ss:Weight="1"/>
                        <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1"/>
                    </Borders>
                    <Interior ss:Color="#FFFFFF" ss:Pattern="Solid"/>
                </Style>                
            </Styles>
            
            <Worksheet ss:Name="Sheet1">
                <Table>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="80" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="150"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="100" AutoFitWidth="1"/><!--Column 5-->
                    <Column ss:AutoFitWidth="0" ss:Width="60" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="120"/>
                    <Column ss:AutoFitWidth="0" ss:Width="120" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="110" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="60" AutoFitWidth="1"/><!--Column 10-->
                    <Column ss:AutoFitWidth="0" ss:Width="150" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="90" AutoFitWidth="1"/>
                    <Column ss:AutoFitWidth="0" ss:Width="70" AutoFitWidth="1"/>
                    
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell ss:StyleID="s21" ss:MergeAcross='3'>
                            <Data ss:Type='String'>TATA MOTORS PUNE</Data>
                        </Cell>                        
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>                       
                        <Cell ss:StyleID="s21" ss:MergeAcross='3'>
                            <Data ss:Type='String'>Engineering Research Center</Data>
                        </Cell>
                    </Row>
                    <Row>
                        <Cell></Cell>
                        <Cell></Cell>
                        <Cell></Cell>       
                        <Cell ss:StyleID="s22" ss:MergeAcross='3'>
                            <Data ss:Type='String'>Platform Report</Data>
                        </Cell>
                    </Row>
                    <Row>
             
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Report Date</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String'><xsl:call-template name="sortReportDate"><xsl:with-param name="inRepDate" select="plm:PLMXML/@date"></xsl:with-param></xsl:call-template></Data>
                        </Cell>
                    </Row>
                    <xsl:variable name="occurenceElement" select="key('occurrence',$PlatformRootId)"/>
                    <xsl:variable name="occRefs" select="$occurenceElement/@occurrenceRefs"/>
                    <Row>
                        <Cell ss:StyleID="s26">
                            <Data ss:Type='String'>Platform Name</Data>
                        </Cell>
                        <Cell ss:StyleID="s24">
                            <Data ss:Type='String'><xsl:value-of select="$occurenceElement/plm:UserData/plm:UserValue[@title='bl_item_item_id']/@value"/></Data>
                        </Cell>
                    </Row>
                    <Row></Row>
                    <Row>
                        <Cell ss:StyleID="s26"><Data ss:Type='String'>Module</Data></Cell>
                        <Cell ss:StyleID="s26"><Data ss:Type='String'>Module Address</Data></Cell>
                        <Cell ss:StyleID="s26"><Data ss:Type='String'>Module Part</Data></Cell>
                        <Cell ss:StyleID="s26"><Data ss:Type='String'>Configurator Context</Data></Cell>
                      
                        <Cell ss:StyleID="s26"><Data ss:Type='String'>Option</Data></Cell>
                        <Cell ss:StyleID="s26"><Data ss:Type='String'>Option Value</Data></Cell>
                    </Row>  

                    

     
                    
                        <!--<Cell><Data ss:Type='String'><xsl:value-of select="$PlatformRootId"/></Data></Cell>
                        <Cell><Data ss:Type='String'><xsl:value-of select="$occRefs"/></Data></Cell>-->
                        <xsl:call-template name="CreateCL">
                            <xsl:with-param name="occStr" select="$occRefs"/>
                            <xsl:with-param name="levelID">1</xsl:with-param>
                        </xsl:call-template>

                   
                    
                </Table>
            </Worksheet>
        </Workbook>
    </xsl:template>
    <xsl:template name="sortReportDate">
        <xsl:param name="inRepDate"/>
        <!--<xsl:variable name="inRepDate" select="plm:PLMXML/@date"/>-->
        <xsl:variable name="datebit1" select="substring-after($inRepDate,'-')"/>
        <xsl:variable name="yearbit" select="substring-before($inRepDate,'-')"/>
        <xsl:variable name="monthbit" select="substring-before($datebit1,'-')"/>
        <xsl:variable name="daybit" select="substring-after($datebit1,'-')"/>
        <xsl:value-of select="concat($daybit,'-',$monthbit,'-',$yearbit)"/>
    </xsl:template>
</xsl:stylesheet>