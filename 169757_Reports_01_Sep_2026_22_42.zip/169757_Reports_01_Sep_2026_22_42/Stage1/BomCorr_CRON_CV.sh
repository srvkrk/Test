#!/bin/ksh
. /user/cvprod/.bash_profile
echo "Start==>Calling BomCorrectness report from cvprod---------->"
dtStr=`date -d "1 day ago" '+%d-%b-%Y'`
echo "Date to be processed dtStr= $dtStr"
./Cron_BomCorrModuleRpt -Fromdate=$dtStr -todate=$dtStr -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba

firstout="/user/cvprod/Program_Shells/BOM_Corr/Vehicle_list.txt"

while read -r line
do
    Partnumber=$(echo "$line" | awk -F, '{print $1}' | xargs)  
    Revision=$(echo "$line" | awk -F, '{print $2}' | xargs)     
    Sequence=$(echo "$line" | awk -F, '{print $3}' | xargs)

./BomCorrModuleRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -VC/Module="$Partnumber" -InputRevision="$Revision" -InputSequence="$Sequence" -RevisionRule="ERC release and above" -Update_BOM_COMPLETENESS?="Y"
done < "$firstout"
message="Dear Team,\n\nPlease find the Vehicle_List in the attachment for which BomCorrectness Report has been generated\n\n Thanks and Regards,\nVinayak Bisirotti"
echo -e "$message" | mail -s "Vehicle List for BomCorrectness Report" -a $firstout vb922918.ttl@tatamotors.com
echo "End==>BomCorrectness_Report from cvprod---------->"
