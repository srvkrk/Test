. /user/cvprod/.bash_profile
echo "In Shell PDSR_Report 2C9  ...'"$1"'  '"$2"' "
ssh cvprod@172.22.99.106 "/user/cvprod/Program_Shells/PDSR_Summary_Report/PDSR_Report_106.sh '"$1"'  '"$2"' "
echo "PDSR_Report report end 2C9 shell end"
