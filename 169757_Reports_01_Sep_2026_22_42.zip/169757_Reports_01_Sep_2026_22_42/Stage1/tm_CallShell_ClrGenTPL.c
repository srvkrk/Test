#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include <unidefs.h>
#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <sa/imanfile.h>
#include <sa/tcfile.h>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <tccore/item_errors.h>
#include <tccore/aom.h>
#include <sa/tcfile.h>
#include <tccore/aom_prop.h>
#define _DEBUG
#include <tccore/grm.h>
#include <ae/dataset.h>
#include <tccore/item.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <sa/sa.h>


int iFail = ITK_ok;


#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}

int ITK_user_main(int argc, char* argv[])
{
    
	
			char* LoginID  = ITK_ask_cli_argument("-u=");
            char* Pass    = ITK_ask_cli_argument("-pf=");
			char* Grp     = ITK_ask_cli_argument("-g=");
			 
			char* Item_ID 		= ITK_ask_cli_argument("-Item_ID=");
			char* Revision 	     = ITK_ask_cli_argument("-Revision=");
			char* Seq 	        = ITK_ask_cli_argument("-Seq=");
			char* RevisionRule 	= ITK_ask_cli_argument("-RevisionRule="); 
			char* UserID 		= ITK_ask_cli_argument("-UserID="); 
			
			char *cError = NULL;
			char command[200];
			
			int status_system = 0;
			
			//Control Obj variable block
			
			tag_t 	tCntrlObj					= NULLTAG;
			tag_t	*tQryResult			=NULLTAG;
			int		iEntryCount				    =1;
			int		iResultFound				=0;
			char    *cQryEntry[1]		    = {"SYSCD"};
			char    **cEntryValue			=  (char **) MEM_alloc(100 * sizeof(char *));
			char *c_userInfo1 = NULL;    //Control Obj variable block END
			
			
			
			
			printf("\n\t INSIDE ITK Calling Shell To Generate Colour GENTPL Rpt \n");fflush(stdout);
			
			iFail = ITK_auto_login();
			
			if (iFail != ITK_ok)
			{
				EMH_ask_error_text(iFail, &cError);
				printf ("\n --xxxxxxxxxxxxx----Login Error---xxxxxxxx-----\n %s \n --xxxxxxxxxxxxx----Login Error---xxxxxxxx-----", cError);fflush(stdout);
				return iFail;
			}
			else
			{
				printf ("\n ====================LOGIN SUCCESSFUL==================== LOGIN SUCCESSFUL====================LOGIN SUCCESSFUL==================== \n");	fflush(stdout);
			}
			
		ITK_CALL(QRY_find2("ControlObjQry", &tCntrlObj));
		cEntryValue[0] = "Colour_Env";
		ITK_CALL(QRY_execute(tCntrlObj, iEntryCount, cQryEntry, cEntryValue, &iResultFound, &tQryResult));
		printf("\n ========== Checking control Object ==> Colour_Env ");fflush(stdout);
			
				
		if (iResultFound > 0)   // If control object count of "Colour_Env" found more than one
		{
			printf("\n\t +++ CONTROL OBJECT ====> Colour_Env ============FOUND ");fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tQryResult[0],"t5_Userinfo1",&c_userInfo1));
			printf("\n--------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
			printf("\n\t CONTROL OBJECT = Colour_Env  >>>>>>>>  ENVIRONMENT = %s",c_userInfo1);fflush(stdout);
			printf("\n--------------------------------------------------------------------------------------------------------------------------");fflush(stdout);
			//Call_cvprod_GenTPL_Colour_2c9.sh
			if(tc_strcmp(c_userInfo1,"CVBU")==0)
			{
				//tc_strcpy(Filepath,"/user/cvprod/shells/Report/Call_GenTPL_Colour_cvprod_2c9.sh");
				printf("\n Passing below command line argumes \n\t Item_ID =%s | Revision=%s | Seq=%s | RevisionRule=%s | UserID=%s ",Item_ID,Revision,Seq,RevisionRule,UserID);fflush(stdout);
				sprintf(command,"/user/cvprod/shells/Report/Call_cvprod_GenTPL_Colour_2c9.sh %s %s %s \"%s\" %s",Item_ID,Revision,Seq,RevisionRule,UserID);  // This file path is at 2c4 server
			}
			else if(tc_strcmp(c_userInfo1,"PVBU")==0)
			{
				printf("\n Passing below command line argumes \n\t Item_ID =%s | Revision=%s | Seq=%s | RevisionRule=%s | UserID=%s ",Item_ID,Revision,Seq,RevisionRule,UserID);fflush(stdout);
				sprintf(command,"/user/uaprod/shells/Report/Call_GenTPL_Colour_uaprod_2c4.sh %s %s %s \"%s\" %s",Item_ID,Revision,Seq,RevisionRule,UserID);  // This file path is at 2c9 server		
			}
			else if(tc_strcmp(c_userInfo1,"CMITEST")==0)
			{
				printf("\n Passing below command line argumes \n\t Item_ID =%s | Revision=%s | Seq=%s | RevisionRule=%s | UserID=%s ",Item_ID,Revision,Seq,RevisionRule,UserID);fflush(stdout);
				sprintf(command,"/user/testcmi/shells/ColourGenTPL/Call_Colour_GenTPL_testcmi.sh %s %s %s \"%s\" %s",Item_ID,Revision,Seq,RevisionRule,UserID);  // This file path is at testcmi server
			}
			
			TC_write_syslog("Command = %s\n",command);
			
			 status_system = system(command);
			 if(status_system == -1)
			 {
				printf("\n --xx---Failed to execute the command < shell Call_GenTPL_Colour.. >.--xx---\n");fflush(stdout);
			 }
			 
		}
		else
		{
			printf("\n\t --xx--Control Object NOT FOUND --xx-->> SYSCD = Colour_Env ");fflush(stdout);
		} 
	
	return iFail;

} // END OF MAIN 
