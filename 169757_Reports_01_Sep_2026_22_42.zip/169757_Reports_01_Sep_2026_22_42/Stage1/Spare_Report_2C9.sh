. /user/cvprod/.bash_profile
echo "In Shell Spare kit 2C9  ...'"$1"'  '"$2"' '"$3"'  '"$4"' '"$5"' '"$6"' "
ssh cvprod@172.22.99.106 "/user/cvprod/Program_Shells/Spare_kit/Spare_Report_106.sh '"$1"'  '"$2"' '"$3"'  '"$4"' '"$5"' '"$6"' "
echo "Spare kit report end 2C9 shell end"
