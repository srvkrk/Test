 /***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : Adddeletionbcp.c
* Created By                   : Aadarsh kumar
* Created On                   : 06/11/DATE_date_to_string
* Project                      :
* Methods Defined              :
* Description                  : Generate Estimate sheet
* Specific Notes               : ./CL_Task -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -Fromdate=01-Feb-2023 -Todate=03-Feb-2023
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <time.h>
//#include <tr1/unordered_set>
#include <stdio.h>
//#include <tc/tc.h>
#include <tc/emh.h>
#include <stdbool.h>
#include <ae/dataset.h>
#include <bom/bom.h>
#include <qry/qry.h>
#include <cfm/cfm.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/tctype.h>
#include <tccore/item.h>
#include <ae/datasettype.h>
#include <sa/user.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pie/pie.h>
#define TABLE_SIZE 100003 // Large prime number for better hash distribution
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}   

FILE		*fp 			= NULL;
//FILE *Report;
FILE		*fp1 			= NULL;
FILE		*Report 			= NULL;
int expansionLevel = 0;
int cntflag = 0;
int Qtyflag = 0;
int start =0;
int ia = 0;
int times =0;
int f1 = 0;
int f2 = 0;
int f3 = 0;
int f4 = 0;
int SerialNo=0;
int DrStatusflag = 0;
char *Qtypart	= NULL;
char *partdiff	= NULL;
char *RevstatusN	= NULL;
char *RevstatusC	= NULL;
char *Plant	= NULL;
char **LatChildSet = NULL;
char *tempbom = NULL;
char *objType = NULL;
//char *symbole = "#";
char *charPtr = NULL; //my
char **childPart      = NULL;
char **childParttwo      = NULL;
char **childPartRep1      = NULL;
char **childPartRep2      = NULL;
char **childPartthree      = NULL;
char **childPartFour      = NULL;
char **childPartFive      = NULL;
char **childPartSix      = NULL;

int tt=0;
int tt1=0;
int tt2=0;
int tt3=0;
int tt4=0;
int tt5=0;
int tt6=0;
int tt7=0;
int uniquecountfirst = 0;
int uniquecounttwo = 0;
int commancountinboth = 0;
char *Value1 = NULL;
char *Value2 = NULL;
char *Value3 = NULL;
void write2xml(FILE * , char*);
int ctr=0;
void write2xml(FILE *Report , char* str)
{
	fprintf(Report,str);
	ctr++;
}
static int PrintErrorStack( void )
{
	int iNumErrs = 0;
	const int *pSevLst;
	const int *pErrCdeLst;
	const char **pMsgLst;
	register int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	for ( i = 0; i < iNumErrs; i++ )
	{
		printf("Error(PrintErrorStack): \n"); fflush(stdout);
		printf("\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] ); fflush(stdout);
	}
	return ITK_ok;
}
typedef struct Node {
    char* key;
    struct Node* next;
} Node;
 
Node* hashTable[TABLE_SIZE];
unsigned long hashFunction(const char* str) {
    unsigned long hash = 5381;
    int c;
	printf("\n---------hashFunction----------");fflush(stdout);
    while ((c = *str++))
        hash = ((hash << 5) + hash) + c;
    return hash % TABLE_SIZE;
}
int insert(char* str) {
    unsigned long index = hashFunction(str);
    Node* current = hashTable[index];
	printf("\n---------insert----------");fflush(stdout);
 
    while (current) {
        if (strcmp(current->key, str) == 0)
            return 0;
        current = current->next;
    }
 
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->key = strdup(str);
    newNode->next = hashTable[index];
    hashTable[index] = newNode;
 
    return 1; 
}
 
// Free hash table memory
void freeHashTable() {
    for (int i = 0; i < TABLE_SIZE; i++) {
        Node* current = hashTable[i];
        while (current) {
            Node* temp = current;
            current = current->next;
            free(temp->key);
            free(temp);
        }
    }
}
//static int report_error( char *file, int line, char *function, int return_code)
//{
//	if (return_code != ITK_ok)
//	{
//		int				index = 0;
//		int				n_ifails = 0;
//		const int*		severities = 0;
//		const int*		ifails = 0;
//		const char**	texts = NULL;
//
//		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
//		printf("%3d error(s)\n", n_ifails);fflush(stdout);
//		for( index=0; index<n_ifails; index++)
//		{
//			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
//			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
//			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
//			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
//		}
//		EMH_clear_errors();
//
//	}
//	return return_code;
//}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
int i;
char *retStringf;
retStringf = (char*) malloc(200);
for(i=0; i < toCharf; i++ )
		  *(retStringf+i) = *(mainStringf+i+fromCharf);
*(retStringf+i) = '\0';
return retStringf;
}
;
char* intToString(int value) {
    // Determine the length of the resulting string
    int length = snprintf(NULL, 0, "%d", value);
    
    // Allocate memory for the string (+1 for null-terminator)
    char* str = (char*)malloc((length + 1) * sizeof(char));
    if (str == NULL) {
        // Failed to allocate memory
        return NULL;
    }

    // Convert the integer to a string
    sprintf(str, "%d", value);

    return str;
}
int setFindStr(int *count,char ***strset,char* str)
	{
		int j   =0;

		//tmp = sizeof(*strset);

		for(j=0;j<*count;j++)
		{
			printf("\n inside setFindStr %d \n",*count);fflush(stdout);
			printf("\n setFindStr value is ===%s",(*strset)[*count-1]);fflush(stdout);
			printf("\n setFindStr value is ===%s",(*strset)[j]);fflush(stdout);

			//if(tc_strcmp((*strset)[*count-1],str)==0) //check this
			if(tc_strcmp((*strset)[j],str)==0)
			{//check this
			//if(tc_strcmp(*strset[j],str)==0)
			printf("\n Value of J is [%d]",j);fflush(stdout);

			return j;
			}

		}
		return -1;
	 }

void setAddStr(int *counttwo,char ***strsettwo,char* strtwo)
{
	*counttwo=*counttwo+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*counttwo==1)
	{
		(*strsettwo) = (char **)malloc((*counttwo ) * sizeof(char *));
	}
	else
	{
		(*strsettwo) = (char **)realloc((*strsettwo),(*counttwo ) * sizeof(char *));
	}
	(*strsettwo)[*counttwo-1] = malloc((strlen(strtwo)+1) * sizeof(char));
	 tc_strcpy((*strsettwo)[*counttwo-1],strtwo);
	 printf("\n setAddStrtwo===%s",(*strsettwo)[*counttwo-1]);fflush(stdout);


}
;
int PrintAttribuites(char* Partnumber, char *Partrevseq,char* level,char* qty,FILE* fp,char* TargetPlantCS)
{
	printf("\n inside function PrintAttribuites\n");fflush(stdout);
	int ifail = ITK_ok;
	tag_t AssemoneQuery = NULLTAG;
	tag_t t_allrevdocs_tag = NULLTAG;
	tag_t SpKitPartTag = NULLTAG;
	tag_t *t_allrevdocs = NULLTAG;
	tag_t *SpKitPartTags = NULLTAG;
	tag_t *referencers = NULLTAG;
	tag_t   dml_tag					= NULLTAG;
	tag_t   part_Dml_rel_type_t					= NULLTAG;
	tag_t   task_tag					= NULLTAG;
	tag_t   dml_tsk_rel_type					= NULLTAG;
	tag_t objTypTag			   = NULLTAG;
	tag_t Prevrev_tag			   = NULLTAG;
	tag_t *part_task_t         = NULLTAG;
	tag_t *ERCDmlRevision      = NULLTAG;
	int	n_rev_entries = 2;
	int	n_tags_found1 = 2;
	int	Itt = 0;
	int	cnt1 = 0;
	int	jj = 0;
	int	Tskcount = 0;
	int	j = 0;
	int r = 0;
	int ii = 0;
	int	ss = 0;
	int	POFound = 0;
	int	sec_count2 = 0;
	int	Part_task_c = 0;
	int	*levels = 0;
	char *ChPO1 = NULL;
	char *ChPODt1 = NULL;
	int	chRevCnt = 0;
	int	n_referencers = 0;
	char **valuesone = NULL;
	char *qry_entries[2] = {"Item ID","Revision"};
	char* Rev1 = NULL;
	char* Seq1 = NULL;
	char* spkPrtTasknum = NULL;
	char* spkPrtTaskRev = NULL;
	char* spkPrtobj = NULL;
	char* RevSeqCat1 = NULL;
	char* IteamNumberTwo = NULL;
	char* Desc = NULL;
	char* classtype = NULL;
	char* levstr = NULL;
	char* rev_seq = NULL;
	char* Projcode = NULL;
	char* desgn_grp = NULL;
	char* Weight = NULL;
	char* Spare_Indicator = NULL;
	char* Part_Catogory = NULL;
	char* Party_Part_Number = NULL;
	char* Owner = NULL;
	char* Datereleased = NULL;
	char* Relstatus_list = NULL;
	char* Envelope_Dimensions = NULL;
	char	** relationsRef;
	char *	DMLTag				= NULL;
	char*   MPartNo				 = NULL;
	char*   DMLOrgPartNo				 = NULL;
	char*   DMLNo				 = NULL;
	char*   Reltype				 = NULL;
	char*   dmlno				 = NULL;
	char*   CSVALUE				 = NULL;
	char*   sec_obj_type				 = NULL;
	tag_t ChildRevMstrTag=NULLTAG;
	tag_t *secObjs2 = NULLTAG;
	tag_t *chRevTags=NULLTAG;
	//char 	objType[TCTYPE_name_size_c+1]; 
	char*   Dml_No				 = NULL;
	char*   ADD_ON_Des				 = NULL;
	tag_t   dml_latest_rev			= NULLTAG;
	//tag_t   objType			= NULLTAG;
	char *type_name=NULL;
	tag_t   ercDml			= NULLTAG;
	levstr = (char *)MEM_alloc(50);
	ChPO1 = (char *)MEM_alloc(50);
	ChPODt1 = (char *)MEM_alloc(50);
	printf("\nvalue of RevSeqCat1 [%s]\n",Partrevseq);fflush(stdout);
	printf("\nvalue of TargetPlantCS [%s]\n",TargetPlantCS);fflush(stdout);
	Rev1 = strtok(Partrevseq,";");
	Seq1 = strtok(NULL,";");
	printf("\nvalue of Rev1 [%s] and Seq1 is [%s]\n",Rev1,Seq1);fflush(stdout);
	valuesone = (char **) MEM_alloc(n_rev_entries * sizeof(char *));
	valuesone[0] = (char *)MEM_alloc( strlen( Partnumber ) + 1);
	tc_strcpy(valuesone[0], Partnumber);			
	RevSeqCat1 = (char *)MEM_alloc(50);
	tc_strcpy(RevSeqCat1, Rev1);
	tc_strcat(RevSeqCat1, "*");
	tc_strcat(RevSeqCat1, Seq1);
	printf("\nvalue of RevSeqCat1 [%s]\n",RevSeqCat1);fflush(stdout);
	valuesone[1] = (char *)MEM_alloc( strlen( RevSeqCat1 ) + 1);
	tc_strcpy(valuesone[1], RevSeqCat1);
	printf("\nthe Revision sequence of the part 1 is %s\n",RevSeqCat1);fflush(stdout);
	QRY_find2("Item Revision...", &AssemoneQuery);
	if (AssemoneQuery!=NULLTAG)
		{
			if (QRY_execute(AssemoneQuery, n_rev_entries, qry_entries, valuesone, &n_tags_found1, &t_allrevdocs));
			printf("\nInside PrintAttribuites func  n_tags_found1: [%d] \n",n_tags_found1);fflush(stdout);
			if (n_tags_found1>0)
				{
					printf("\n  print----pppppppp is");fflush(stdout);
					for (Itt=0;Itt<n_tags_found1;Itt++)
						{
							printf("\n  print----TTTTTT is");fflush(stdout);
							t_allrevdocs_tag=t_allrevdocs[0];
							printf("\n  print----TTTTTTUUUUUUUUU is");fflush(stdout);
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"object_type",&classtype));
							printf("\n  print----TTTTTOOOOOOOOOO is");fflush(stdout);
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"current_id",&IteamNumberTwo));
							printf("\n  print----TTTTQQQQQQQQQ is");fflush(stdout);
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"t5_SpareInd",&Spare_Indicator));
							if (tc_strcmp(Spare_Indicator,"True")==0)
							{
								// Write CS logic
								if (strlen(TargetPlantCS)>0)
								{
									ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,TargetPlantCS,&CSVALUE));
								}
								else
								{
									CSVALUE = (char *)MEM_alloc(50);
									tc_strcpy(CSVALUE, " ");
								}
								STRNG_replace_str(CSVALUE,",",";",&CSVALUE);
								STRNG_replace_str(CSVALUE,"\n","-",&CSVALUE);
								STRNG_replace_str(CSVALUE,"&","and",&CSVALUE);
								printf("\n  print----12 is");fflush(stdout);
								// Write PO logic
								ITK_CALL(ITEM_find_item(IteamNumberTwo, &Prevrev_tag ));
								ITK_CALL(ITEM_list_all_revs(Prevrev_tag,&chRevCnt,&chRevTags));
								printf(" chRevCnt: %d  ",chRevCnt);fflush(stdout);
								if (chRevCnt>0)
								{
									tag_t ChildRev2Tag=NULLTAG;
									for(ii=chRevCnt-1;ii>=0;ii--)
									{
										ChildRev2Tag=chRevTags[ii];
										if(ChildRev2Tag != NULLTAG)
										{
											if(GRM_list_secondary_objects_only(ChildRev2Tag, NULLTAG, &sec_count2, &secObjs2)!=ITK_ok);
											for(jj=0; jj<sec_count2; jj++)
											{
												if(ChildRevMstrTag) ChildRevMstrTag=NULLTAG;
												ChildRevMstrTag=secObjs2[jj];
												if(AOM_UIF_ask_value(ChildRevMstrTag, "object_type", &sec_obj_type)!=ITK_ok);
												if((tc_strcmp(sec_obj_type,"Design Revision Master") == 0)||(tc_strcmp(sec_obj_type, "T5_SparKitRevisionMaster")== 0))
												{
													char *po1=NULL,*po2=NULL,*po3=NULL,*po4=NULL,*po5=NULL,*po6=NULL,*po7=NULL,*po8=NULL,*po9=NULL,*po10=NULL,*po11=NULL,*po12=NULL;
													char *poD1=NULL,*poD2=NULL,*poD3=NULL,*poD4=NULL,*poD5=NULL,*poD6=NULL,*poD7=NULL,*poD8=NULL,*poD9=NULL,*poD10=NULL,*poD11=NULL,*poD12=NULL;
													date_t D1;
													date_t D2;
													date_t D3;
													date_t D4;
													date_t D5;
													date_t D6;
													date_t D7;
													date_t D8;
													date_t D9;
													date_t D10;
													date_t D11;
													date_t D12;
													int temp[12]={0};
													int lpITR=0; int x1=0;
													printf("\n\t Spare-kit--sec_obj_type.:%s", sec_obj_type);fflush(stdout);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO1",&po1)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO2",&po2)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO3",&po3)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO4",&po4)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO5",&po5)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO6",&po6)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO7",&po7)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO8",&po8)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO9",&po9)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO10",&po10)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO11",&po11)!=ITK_ok);
													if(AOM_ask_value_string(ChildRevMstrTag,"t5_PO12",&po12)!=ITK_ok);

													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate1",&D1)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D1,"%d-%b-%Y %H:%M:%S", &poD1));
													ITK_date_to_string(D1,&poD1);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate2",&D2)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D2,"%d-%b-%Y %H:%M:%S", &poD2));
													ITK_date_to_string(D2,&poD2);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate3",&D3)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D3,"%d-%b-%Y %H:%M:%S", &poD3));
													ITK_date_to_string(D3,&poD3);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate4",&D4)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D4,"%d-%b-%Y %H:%M:%S", &poD4));
													ITK_date_to_string(D4,&poD4);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate5",&D5)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D5,"%d-%b-%Y %H:%M:%S", &poD5));
													ITK_date_to_string(D5,&poD5);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate6",&D6)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D6,"%d-%b-%Y %H:%M:%S", &poD6));
													ITK_date_to_string(D6,&poD6);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate7",&D7)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D7,"%d-%b-%Y %H:%M:%S", &poD7));
													ITK_date_to_string(D7,&poD7);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate8",&D8)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D8,"%d-%b-%Y %H:%M:%S", &poD8));
													ITK_date_to_string(D8,&poD8);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate9",&D9)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D9,"%d-%b-%Y %H:%M:%S", &poD9));
													ITK_date_to_string(D9,&poD9);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate10",&D10)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D10,"%d-%b-%Y %H:%M:%S", &poD10));
													ITK_date_to_string(D10,&poD10);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate11",&D11)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D11,"%d-%b-%Y %H:%M:%S", &po11));
													ITK_date_to_string(D11,&poD11);
													if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate12",&D12)!=ITK_ok);
													//ITK_CALL(DATE_date_to_string(D12,"%d-%b-%Y %H:%M:%S", &po12));
													ITK_date_to_string(D12,&poD12);
													temp[0]=tc_strlen(po1);
													temp[1]=tc_strlen(po2);
													temp[2]=tc_strlen(po3);
													temp[3]=tc_strlen(po4);
													temp[4]=tc_strlen(po5);
													temp[5]=tc_strlen(po6);
													temp[6]=tc_strlen(po7);
													temp[7]=tc_strlen(po8);
													temp[8]=tc_strlen(po9);
													temp[9]=tc_strlen(po10);
													temp[10]=tc_strlen(po11);
													temp[11]=tc_strlen(po12);
													for(lpITR=0;lpITR<12;lpITR++)
													{
														if(temp[lpITR]>0)														
														{
															x1=lpITR;
															break;
														}
													}
													printf(" X1 variable final value = %d \n",x1);
													if(x1==0)
													{
														tc_strcpy(ChPO1,po1);
													}
													if(x1==1)
													{
														tc_strcpy(ChPO1,po2);
													}
													if(x1==2)
													{
														tc_strcpy(ChPO1,po3);
													}
													if(x1==3)
													{
														tc_strcpy(ChPO1,po4);
													}
													if(x1==4)
													{
														tc_strcpy(ChPO1,po5);
													}
													if(x1==5)
													{
														tc_strcpy(ChPO1,po6);
													}
													if(x1==6)
													{
														tc_strcpy(ChPO1,po7);
													}
													if(x1==7)
													{
														tc_strcpy(ChPO1,po8);
													}
													if(x1==8)
													{
														tc_strcpy(ChPO1,po9);
													}
													if(x1==9)
													{
														tc_strcpy(ChPO1,po10);
													}
													if(x1==10)
													{
														tc_strcpy(ChPO1,po11);
													}
													if(x1==11)
													{
														tc_strcpy(ChPO1,po12);
													}
													temp[0]=tc_strlen(poD1);
													temp[1]=tc_strlen(poD2);
													temp[2]=tc_strlen(poD3);
													temp[3]=tc_strlen(poD4);
													temp[4]=tc_strlen(poD5);
													temp[5]=tc_strlen(poD6);
													temp[6]=tc_strlen(poD7);
													temp[7]=tc_strlen(poD8);
													temp[8]=tc_strlen(poD9);
													temp[9]=tc_strlen(poD10);
													temp[10]=tc_strlen(poD11);
													temp[11]=tc_strlen(poD12);
													
													for(lpITR=0;lpITR<12;lpITR++)
													{
														if(temp[lpITR]>0)														
														{
															x1=lpITR;
															break;
														}
													}
													printf(" X1 variable final value = %d \n",x1);
													if(x1==0)
													{
														tc_strcpy(ChPODt1,poD1);
													}
													if(x1==1)
													{
														tc_strcpy(ChPODt1,poD2);
													}
													if(x1==2)
													{
														tc_strcpy(ChPODt1,poD3);
													}
													if(x1==3)
													{
														tc_strcpy(ChPODt1,poD4);
													}
													if(x1==4)
													{
														tc_strcpy(ChPODt1,poD5);
													}
													if(x1==5)
													{
														tc_strcpy(ChPODt1,poD6);
													}
													if(x1==6)
													{
														tc_strcpy(ChPODt1,poD7);
													}
													if(x1==7)
													{
														tc_strcpy(ChPODt1,poD8);
													}
													if(x1==8)
													{
														tc_strcpy(ChPODt1,poD9);
													}
													if(x1==9)
													{
														tc_strcpy(ChPODt1,poD10);
													}
													if(x1==10)
													{
														tc_strcpy(ChPODt1,poD11);
													}
													if(x1==11)
													{
														tc_strcpy(ChPODt1,poD12);
													}					

													//if(AOM_ask_value_date(ChildRevMstrTag,"t5_PODate1",&ChPODt1)!=ITK_ok);
													//ITK_date_to_string(ChPODt1,&ChPODt1Str);
													printf("\t ChPO1: [%s]  ChPODt1: [%s] ",ChPO1,ChPODt1);fflush(stdout);
													if (tc_strlen(ChPO1)>1)
													{
														printf("\n\t   Spare-kit-Report--   ChPO1: [%s]  ChPODt1: [%s] ",ChPO1,ChPODt1); fflush(stdout);
														POFound=1;
													}
													break;
												}
											}
										}
										if (POFound==1)
										{
											break;
										}

									}
									if (POFound==0)
									{
										ChPO1 =(char *) MEM_alloc(50);
										tc_strcpy(ChPO1,"PO not available");
										ChPODt1 =(char *) MEM_alloc(50);
										tc_strcpy(ChPODt1,"PO Date not available");
									}

								}
							}
							else
							{
								ChPO1 =(char *) MEM_alloc(50);
								tc_strcpy(ChPO1,"");
								ChPODt1 =(char *) MEM_alloc(50);
								tc_strcpy(ChPODt1,"");
							}
							ifail = GRM_find_relation_type("CMHasSolutionItem" ,&part_Dml_rel_type_t);
							printf("\n  print----RRRRRRRRRRRRRRR is");fflush(stdout);
							ifail = GRM_list_primary_objects_only(t_allrevdocs_tag,part_Dml_rel_type_t,&Part_task_c,&part_task_t);
							printf("\n DR: Part_task_c:%d", Part_task_c);fflush(stdout);
							if (Part_task_c>0)
							{
								for (r=0;r<Part_task_c;r++)
									{
										task_tag = part_task_t[r];
										if (task_tag != NULLTAG)
										{
											 printf("\n  print----0 is");fflush(stdout);
											 ifail = TCTYPE_ask_object_type(task_tag,&objTypTag);
											 printf("\n  print----1 is");fflush(stdout);
											 //ITK_CALL(TCTYPE_ask_object_type(objTypTag,&objType));
											 //if(TCTYPE_ask_name2(objType,&type_name));
											 if(TCTYPE_ask_name2(objTypTag,&objType));
											 printf("\n  print----2 is");fflush(stdout);
											 printf("\n  object_type is %s\n", objType);fflush(stdout);
											 printf("\nT5_ChangeTaskRevision>>>>>>>> : [%s]\n",objType); fflush(stdout);	
											 if(tc_strcmp(objType,"T5_ChangeTaskRevision")==0)
											 {
												printf("\n  print----3 is");fflush(stdout);
											   ifail = GRM_find_relation_type ( "T5_DMLTaskRelation", &dml_tsk_rel_type ) ;
											   printf("\n  print----4 is");fflush(stdout);
											   ifail = GRM_list_primary_objects_only ( task_tag, dml_tsk_rel_type, &Tskcount, &ERCDmlRevision ) ;//task to dml rev traversal
											   printf("\n  print----5 is");fflush(stdout);
											   if (Tskcount>0)
											   {
												   ercDml = ERCDmlRevision[0];											   
												   ITK_CALL(AOM_UIF_ask_value(ercDml, "item_id" ,&DMLNo));
												   ITK_CALL(AOM_UIF_ask_value(ercDml, "t5_rlstype" ,&Reltype));
												   printf("\nDml_No>>>>>>>> : [%s]\n",Dml_No); fflush(stdout);	
											   }
											 }
										}
								}
							}
							printf("\n  print----9 is");fflush(stdout);
							if (DMLNo==NULL)
							{
								DMLNo = (char *)MEM_alloc(50);
								tc_strcpy(DMLNo, " ");
							}
							printf("\n  print----10 is");fflush(stdout);
							if (Reltype==NULL)
							{
								Reltype = (char *)MEM_alloc(50);
								tc_strcpy(Reltype, " ");
							}
							printf("\n  print----11 is");fflush(stdout);
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"current_desc",&Desc));
							printf("\n  print----11-------A is");fflush(stdout);
							STRNG_replace_str(Desc,",","-",&Desc);
						    STRNG_replace_str(Desc,"\n","-",&Desc);
						    STRNG_replace_str(Desc,"&","and",&Desc);
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"t5_SimVal",&ADD_ON_Des));
							STRNG_replace_str(ADD_ON_Des,",",";",&ADD_ON_Des);
						    STRNG_replace_str(ADD_ON_Des,"\n","-",&ADD_ON_Des);
						    STRNG_replace_str(ADD_ON_Des,"&","and",&ADD_ON_Des);
							printf("\n  print----11-------B is");fflush(stdout);
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"current_revision_id",&rev_seq));
							STRNG_replace_str(rev_seq,",",";",&rev_seq);
						    STRNG_replace_str(rev_seq,"\n","-",&rev_seq);
							printf("\n  print----11-------C is");fflush(stdout);
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"t5_ProjectCode",&Projcode));
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"t5_DesignGrp",&desgn_grp));
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"t5_Weight",&Weight));
							if (tc_strlen(CSVALUE)==0)
							{
								CSVALUE =(char *) MEM_alloc(1);
								tc_strcpy(CSVALUE,"");
							}
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"t5_SpareCriteria",&Part_Catogory));
							STRNG_replace_str(Part_Catogory,",","-",&Part_Catogory);
						    STRNG_replace_str(Part_Catogory,"\n","-",&Part_Catogory);
						    STRNG_replace_str(Part_Catogory,"&","and",&Part_Catogory);
							printf("\n  print----11-------D is");fflush(stdout);
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"t5_RefPartNumber",&Party_Part_Number));
							STRNG_replace_str(Party_Part_Number,",","-",&Party_Part_Number);
						    STRNG_replace_str(Party_Part_Number,"\n","-",&Party_Part_Number);
						    STRNG_replace_str(Party_Part_Number,"&","and",&Party_Part_Number);
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"owning_user",&Owner));
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"date_released",&Datereleased));
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"release_status_list",&Relstatus_list));
							STRNG_replace_str(Relstatus_list,",",";",&Relstatus_list);
						    STRNG_replace_str(Relstatus_list,"\n","-",&Relstatus_list);
						    STRNG_replace_str(Relstatus_list,"&","and",&Relstatus_list);
							ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"t5_EnvelopeDimensions",&Envelope_Dimensions));
							write2xml(Report,"<logo>\n");
							//XML code start
							write2xml(Report,"<field key =\"Level\">");
							write2xml(Report,level);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Class\">");
							write2xml(Report,classtype);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Part No\">");
							write2xml(Report,IteamNumberTwo);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Description\">");
							write2xml(Report,Desc);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"AddOn Description\">");
							write2xml(Report,ADD_ON_Des);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Quantity\">");
							write2xml(Report,qty);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Revision Seq\">");
							write2xml(Report,rev_seq);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Project Code\">");
							write2xml(Report,Projcode);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Design Group\">");
							write2xml(Report,desgn_grp);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Weight\">");
							write2xml(Report,Weight);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Spare Indicator\">");
							write2xml(Report,Spare_Indicator);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Plant CS\">");
							write2xml(Report,CSVALUE);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"PO_NO\">");
							write2xml(Report,ChPO1);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"PO_Date\">");
							write2xml(Report,ChPODt1);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Part Catogory\">");
							write2xml(Report,Part_Catogory);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Party Part Number\">");
							write2xml(Report,Party_Part_Number);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Owner\">");
							write2xml(Report,Owner);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"DML\">");
							write2xml(Report,DMLNo);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Release Date\">");
							write2xml(Report,Datereleased);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Release Type\">");
							write2xml(Report,Reltype);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Lifecycle State\">");
							write2xml(Report,Relstatus_list);
							write2xml(Report,"</field>\n");
							write2xml(Report,"<field key =\"Envelope Dimensions\">");
							write2xml(Report,Envelope_Dimensions);
							write2xml(Report,"</field>\n");
							write2xml(Report,"</logo>\n");
							fprintf(fp,"\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",level,classtype,IteamNumberTwo,Desc,ADD_ON_Des,qty,rev_seq,Projcode,desgn_grp,Weight,Spare_Indicator,CSVALUE,ChPO1,ChPODt1,Part_Catogory,Party_Part_Number,Owner,DMLNo,Datereleased,Reltype,Relstatus_list,Envelope_Dimensions);fflush(fp);
							printf("\nvalue of sttributes is %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s",level,classtype,IteamNumberTwo,Desc,ADD_ON_Des,qty,rev_seq,Projcode,desgn_grp,Weight,Spare_Indicator,CSVALUE,ChPO1,ChPODt1,Part_Catogory,Party_Part_Number,Owner,DMLNo,Datereleased,Reltype,Relstatus_list,Envelope_Dimensions);fflush(stdout);
						}
				}
		}
		return 0;
}
int findsparekitpart(char* subchild_item_id, char *subchild_item_idRev,FILE* fp,char* TargetPlantCS)
{
	printf("\n inside function findsparekitpart\n");fflush(stdout);
	int ifail = ITK_ok;
	tag_t AssemoneQuery = NULLTAG;
	tag_t t_allrevdocs_tag = NULLTAG;
	tag_t SpKitPartTag = NULLTAG;
	tag_t *t_allrevdocs = NULLTAG;
	tag_t *SpKitPartTags = NULLTAG;
	int	n_rev_entries = 2;
	int	n_tags_found1 = 2;
	int	Itt = 2;
	int	cnt1 = 2;
	int	j = 2;
	//int	level = 0;
	char **valuesone             = NULL;
	char *qry_entries[2] = {"Item ID","Revision"};
	char* Rev1 = NULL;
	char* Seq1 = NULL;
	char* spkPrtTasknum = NULL;
	char* spkPrtTaskRev = NULL;
	char* spkPrtobj = NULL;
	char* RevSeqCat1 = NULL;
	char* level = NULL;
	level = (char *)MEM_alloc(50);
	tc_strcpy(level, " ");
	char* qty = NULL;
	qty = (char *)MEM_alloc(50);
	tc_strcpy(qty, " ");
	char* IteamNumberTwo = NULL;
	//char* level = NULL;
	Rev1 = strtok(subchild_item_idRev,";");
	Seq1 = strtok(NULL,";");
	valuesone = (char **) MEM_alloc(n_rev_entries * sizeof(char *));
	valuesone[0] = (char *)MEM_alloc( strlen( subchild_item_id ) + 1);
	tc_strcpy(valuesone[0], subchild_item_id);			
	RevSeqCat1 = (char *)MEM_alloc(50);
	tc_strcpy(RevSeqCat1, Rev1);
	tc_strcat(RevSeqCat1, "*");
	tc_strcat(RevSeqCat1, Seq1);
	valuesone[1] = (char *)MEM_alloc( strlen( RevSeqCat1 ) + 1);
	tc_strcpy(valuesone[1], RevSeqCat1);
	printf("\nthe Revision sequence of the part 1 is %s\n",RevSeqCat1);fflush(stdout);
	QRY_find2("Item Revision...", &AssemoneQuery);
	if (AssemoneQuery!=NULLTAG)
	{
		if (QRY_execute(AssemoneQuery, n_rev_entries, qry_entries, valuesone, &n_tags_found1, &t_allrevdocs));
		printf("\nInside findsparekitpart func  n_tags_found1: [%d] \n",n_tags_found1);fflush(stdout);
		if (n_tags_found1>0)
			{
				for (Itt=0;Itt<n_tags_found1;Itt++)
					{
						t_allrevdocs_tag=t_allrevdocs[0];
						ITK_CALL(AOM_UIF_ask_value(t_allrevdocs_tag,"object_string",&IteamNumberTwo));
						ifail = AOM_ask_value_tags(t_allrevdocs_tag,"T5_HasSpareKit",&cnt1,&SpKitPartTags);
						printf("\n Has spare Kit [%d]",cnt1);fflush(stdout);
						if (cnt1>0)
							{
								for (j=0;j<cnt1;j++)
								{
									SpKitPartTag=SpKitPartTags[j];
									if( AOM_ask_value_string(SpKitPartTag,"item_id",&spkPrtTasknum)==ITK_ok)
									if( AOM_ask_value_string(SpKitPartTag,"item_revision_id",&spkPrtTaskRev)==ITK_ok)
									if( AOM_ask_value_string(SpKitPartTag,"object_type",&spkPrtobj)==ITK_ok)
									printf("\n spkPrtTasknum [%s] and spkPrtobj is [%s]",spkPrtTasknum,spkPrtobj);fflush(stdout);
									if((tc_strcmp(spkPrtobj,"Spare Kit Revision")==0) || (tc_strcmp(spkPrtobj,"T5_SparKitRevision")==0))
									{
										printf("\n spare-kit-report--PartNumber [%s] and [%s] and spkPrtobj is [%s] \n",spkPrtTasknum,spkPrtTaskRev,spkPrtobj);fflush(stdout);
										PrintAttribuites(spkPrtTasknum,spkPrtTaskRev,level,qty,fp,TargetPlantCS);
									}
								}
							}				
					}
			}
	}
	return 0;
}
//BOM Expansioncode
int BOMExpansionforcommon(tag_t Child_bom_linesone,FILE *fp, char* TargetPlantCS)
{
	int ifail = ITK_ok;
	int i1;
	int i2;
	//int SerialNocommon=0;
	int level0=0;
	int CSFoundFlag=0;
	int F18CSFoundFlag=0;
	int m1=0;
	int cnt1=0;
	int n_spkPrtTskCnt=0;
	int j=0;
	int subchildno_bom_linesx;
	int subchildno_bom_linesonex;
	tag_t subchilditeam = NULLTAG;
	tag_t subchilditeamone = NULLTAG;
	char *subchild_item_idtwo = NULL;
	char *subchild_item_idone = NULL;
	//char *subchild_bom_linesonex = NULL;
	char *subchild_item_idquantity = NULL;
	char *subchild_item_idmodadd = NULL;
	char *subchild_item_idmodName = NULL;
	char *subchild_item_idTwoRev = NULL;
	char *subchild_item_idOneRev = NULL;
	char *subchild_item_idquantityref = NULL;
	char *subchild_item_idquantityNew = NULL;
	char *methodplant = NULL;
	char *tokenX2 = NULL;
	char *catry = NULL;
	char *SrNOP = NULL;
	char *spkPrtTasknum = NULL;
	char *spkPrtobj = NULL;
	char *classtype = NULL;
	int   level_int = 0;
	tag_t *subchild_bom_linesx = NULLTAG;
	tag_t *subchild_bom_linesonex = NULLTAG;
	tag_t tRelationFind = NULLTAG;
	tag_t SpKitPartTag = NULLTAG;
	tag_t* SpKitPartTags = NULLTAG;
	char *level = NULL;
	char *subchild_item_idTwoRevDup = NULL;
	char *qty = NULL;
	char *Desc = NULL;
	char *PrtType = NULL;
	char *ADD_on_Dec = NULL;
	char *subchild_itemTest = NULL;
	subchild_itemTest = (char *) MEM_alloc (sizeof (char) * 128);

	printf("\n spare-kit-report-Common--please wait BOMExpansionforcommon running\n");fflush(stdout);
	ifail = BOM_line_ask_child_lines(Child_bom_linesone, &subchildno_bom_linesx, &subchild_bom_linesx);
	printf("\n spare-kit-report- VC BOM is %d \n",subchildno_bom_linesx);fflush(stdout);
	if(subchildno_bom_linesx>0)
	{
		for (i1=0; i1<subchildno_bom_linesx; i1++)
		{
			printf("\ninside for loop");fflush(stdout);
			subchild_item_idtwo=NULL;
			subchild_item_idTwoRev=NULL;

			subchilditeam=subchild_bom_linesx[i1];

			ifail = AOM_ask_value_string(subchilditeam,"bl_item_item_id",&subchild_item_idtwo);
			ifail = AOM_ask_value_string(subchilditeam,"bl_rev_item_revision_id",&subchild_item_idTwoRev);
			ifail = AOM_ask_value_string(subchilditeam,"bl_quantity",&qty);
			ifail = AOM_ask_value_string(subchilditeam,"bl_item_object_desc",&Desc);
			ifail = AOM_ask_value_string(subchilditeam,"bl_Design Revision_t5_PartType",&PrtType);
			tc_strdup(subchild_item_idTwoRev,&subchild_item_idTwoRevDup);
			ifail = AOM_UIF_ask_value(subchilditeam,"bl_level_starting_0",&level);
			ifail = AOM_UIF_ask_value(subchilditeam,"bl_Design Revision_t5_SimVal",&ADD_on_Dec);
			printf("\nbefore level set");fflush(stdout);
			printf("\n spare-kit-report--subchild part of vc [%s] [%s] [%s] [%s] [%s] \n",subchild_item_idtwo,subchild_item_idTwoRev,level,Desc,ADD_on_Dec);fflush(stdout);
			if ((strstr(Desc,"INFO")!=NULL) && (strstr(Desc,"FIT")!=NULL))
			{
				continue;
			}
			if (strstr(subchild_item_idtwo,"_")!=NULL)
			{
				continue;
			}
			tc_strcpy(subchild_itemTest," ");
			tc_strcat(subchild_itemTest,subchild_item_idtwo);
			tc_strcat(subchild_itemTest,"#");
			tc_strcat(subchild_itemTest,subchild_item_idTwoRev);
//			if(setFindStr(&tt2,&childPartthree,subchild_itemTest)==-1)
//			{
//				setAddStr(&tt2,&childPartthree,subchild_itemTest);
//				printf("\n Set of add element into New part [%s] added directly \n",subchild_itemTest);fflush(stdout);
//				PrintAttribuites(subchild_item_idtwo,subchild_item_idTwoRev,level,qty,fp,TargetPlantCS);
//				findsparekitpart(subchild_item_idtwo,subchild_item_idTwoRevDup,fp,TargetPlantCS);
//				BOMExpansionforcommon(subchilditeam,fp,TargetPlantCS);fflush(stdout);
//			}
        if (insert(subchild_itemTest)) 
		{
			printf("\n Set of add element into New part [%s] added directly \n",subchild_itemTest);fflush(stdout);
			PrintAttribuites(subchild_item_idtwo,subchild_item_idTwoRev,level,qty,fp,TargetPlantCS);
			findsparekitpart(subchild_item_idtwo,subchild_item_idTwoRevDup,fp,TargetPlantCS);
			BOMExpansionforcommon(subchilditeam,fp,TargetPlantCS);fflush(stdout);
        }
		}
	}
	return 0;
}
int CreateDataset(char* DsetName, tag_t t_SpkTPL_FL , char* File_path)
{
		
		tag_t msExcelType	= NULLTAG;
		tag_t ExcelDataset	= NULLTAG;
		tag_t dml_Ref_Rel_t	= NULLTAG;
		tag_t ExlLatestDat_t	= NULLTAG;
		tag_t dml_Ref_Rel	= NULLTAG;
		
		char *c_FolderName1 = NULL;
		char *token1 = NULL;
		char *token2 = NULL;
		char *token3 = NULL;
		
		
		tag_t filetag =  NULLTAG;
		tag_t tool =  NULLTAG;
		int ref_count =0;
		char** ref_list;
		//AE_reference_type_t tagRefType =  1;
		PREF_preference_type_t tagRefType =  1;
		
		IMF_file_t fileDescriptor;
		
		
	//		const char *input = "/tmp/S_report_5709H1A0100039_4_3_2025_9_44_35.csv";
	//		const char *filename = strrchr(input, '/');
	//		if (filename != NULL)
	//		{
	//			filename++; // Move past the '/'
	//		}
	//        printf("Filename: %s\n", filename);		
		printf("\n\t ~~~~Inside Create Dataset~~~~~");
		printf("\n\t Going to create Dataset with ID = [%s]",DsetName);
		
		ITK_CALL(AE_find_datasettype2("MSExcel",&msExcelType));
		if(msExcelType == NULLTAG)
		{
			printf("\n Could not find Dataset\n");fflush(stdout);
		}
		else 
		printf("\n\t --MSExcel Dataset found--");fflush(stdout);
		printf("\n\t ::::::Dataset Creation in process:::::::");fflush(stdout);
		
		ITK_CALL(AE_create_dataset_with_id(msExcelType,DsetName,"SpareKit REPORT","","",&ExcelDataset));
		
		
		ITK_CALL(AE_save_myself(ExcelDataset));
		printf("\n\t Dataset is Succesfully Created & saved in Database");fflush(stdout);
		 
		printf("\n\t ------Going to create relation Folder and Excel Dataset ------\n");fflush(stdout);
		
		// ITK_CALL(AOM_ask_value_string(t_SpkTPL_FL,"object_name",&c_FolderName1));
		// printf("\n\t  FOLDER NAME = %s ",c_FolderName1);
		
		if(FL_insert(t_SpkTPL_FL,ExcelDataset,0));
		
		if(AOM_save_without_extensions(t_SpkTPL_FL));
		printf("\n\t ------Dataset insterted into The Spare kit Folder successfully---- ");
		
		
		printf("\n\t  || Importing File [%s] || Into Dataset [%s] ",File_path ,DsetName);
		
		ITK_CALL(IMF_import_file(File_path,NULL, SS_BINARY, &filetag, &fileDescriptor));
					
		//printf("\n\n\t 7777777777777777 \n\n");fflush(stdout);
		ITK_CALL(AOM_save_without_extensions(filetag)!=ITK_ok);
		//printf("\n\n\t 1111111111111111111 \n\n");fflush(stdout);
		
		ITK_CALL(AE_ask_datasettype_refs(msExcelType, &ref_count, &ref_list));
		ITK_CALL(AE_add_dataset_named_ref2(ExcelDataset,ref_list[0],tagRefType,filetag));
		ITK_CALL(AE_set_dataset_tool(ExcelDataset,tool));
		ITK_CALL(AOM_save_without_extensions(ExcelDataset));
		
		printf("\n\t ---#####---Imported csv file into Excel Dataset----######----");fflush(stdout);
		 
	
	return 0;	
}

int CreateDatasetDML(char* DsetName , char* File_path,tag_t seldmlobjrev)
{
		
		tag_t msExcelType	= NULLTAG;
		tag_t ExcelDataset	= NULLTAG;
		tag_t dml_Ref_Rel_t	= NULLTAG;
		tag_t ExlLatestDat_t	= NULLTAG;
		tag_t dml_Ref_Rel	= NULLTAG;
		
		char *c_FolderName1 = NULL;
		char *token1 = NULL;
		char *token2 = NULL;
		char *token3 = NULL;
		char * relation_type_name = NULL;
		
		tag_t   relation    = NULLTAG;
		tag_t filetag =  NULLTAG;
		tag_t relation_type =  NULLTAG;
		tag_t tool =  NULLTAG;
		int ref_count =0;
		char** ref_list;
		//AE_reference_type_t tagRefType =  1;
		PREF_preference_type_t tagRefType =  1;
		
		IMF_file_t fileDescriptor;
		
		
	//		const char *input = "/tmp/S_report_5709H1A0100039_4_3_2025_9_44_35.csv";
	//		const char *filename = strrchr(input, '/');
	//		if (filename != NULL)
	//		{
	//			filename++; // Move past the '/'
	//		}
	//        printf("Filename: %s\n", filename);		
		printf("\n\t ~~~~Inside Create Dataset~~~~~");
		printf("\n\t Going to create Dataset with ID = [%s]",DsetName);
		
		ITK_CALL(AE_find_datasettype2("MSExcel",&msExcelType));
		if(msExcelType == NULLTAG)
		{
			printf("\n Could not find Dataset\n");fflush(stdout);
		}
		else 
		printf("\n\t --MSExcel Dataset found--");fflush(stdout);
		printf("\n\t ::::::Dataset Creation in process:::::::");fflush(stdout);
		
		ITK_CALL(AE_create_dataset_with_id(msExcelType,DsetName,"SpareKit REPORT","","",&ExcelDataset));
		
		
		ITK_CALL(AE_save_myself(ExcelDataset));
		printf("\n\t Dataset is Succesfully Created & saved in Database");fflush(stdout);
		 
		printf("\n\t ------Going to create relation Folder and Excel Dataset ------\n");fflush(stdout);
		
		// ITK_CALL(AOM_ask_value_string(t_SpkTPL_FL,"object_name",&c_FolderName1));
		// printf("\n\t  FOLDER NAME = %s ",c_FolderName1);
		
		//if(FL_insert(t_SpkTPL_FL,ExcelDataset,0));
		
		//if(AOM_save_without_extensions(t_SpkTPL_FL));
		//printf("\n\t ------Dataset insterted into The Spare kit Folder successfully---- ");
		
		
		printf("\n\t  || Importing File [%s] || Into Dataset [%s] ",File_path ,DsetName);
		
		ITK_CALL(IMF_import_file(File_path,NULL, SS_BINARY, &filetag, &fileDescriptor));
					
		//printf("\n\n\t 7777777777777777 \n\n");fflush(stdout);
		ITK_CALL(AOM_save_without_extensions(filetag)!=ITK_ok);
		//printf("\n\n\t 1111111111111111111 \n\n");fflush(stdout);
		
		ITK_CALL(AE_ask_datasettype_refs(msExcelType, &ref_count, &ref_list));
		ITK_CALL(AE_add_dataset_named_ref2(ExcelDataset,ref_list[0],tagRefType,filetag));
		ITK_CALL(AE_set_dataset_tool(ExcelDataset,tool));
		ITK_CALL(AOM_save_without_extensions(ExcelDataset));
		
		printf("\n\t ---#####---Imported csv file into Excel Dataset----######----");fflush(stdout);

		relation_type_name = (char*)MEM_alloc(70*sizeof(char));
        sprintf ( relation_type_name, "%s","IMAN_reference" );

        ITK_CALL(GRM_find_relation_type(relation_type_name,&relation_type));
        if(relation_type != NULLTAG)
        {
                ITK_CALL(GRM_create_relation(seldmlobjrev,ExcelDataset,relation_type, NULLTAG, &relation));
                if(relation != NULLTAG)
                {
                        printf("\nThe dataset is attached to the Reference folder of DML");fflush(stdout);
                }
                else
                {
                        printf("\nThe dataset is not attached to the Reference folder of DML. Please check");fflush(stdout);
                }
                ITK_CALL(GRM_save_relation(relation));
        }


        printf("\nCompleted....");fflush(stdout);
		 
	
	return 0;	
}
int t5GetItemRevison(char* InputPart)
{
	//MT start
	tag_t   OutPutTag     = NULLTAG;
	int n_tags_found2=0;
	tag_t *tags_found2 = NULL;

	//char **attrs2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **values2 = (char **) MEM_alloc(200 * sizeof(char *));
	int n_tags_foundd2=0;
	int n_tags_foundd3=0;
	tag_t *tags_foundd3 = NULL;
	tag_t *tags_foundd2 = NULL;
	//char **attrss2 = (char **) MEM_alloc(200 * sizeof(char *));
	//char **valuess2 = (char **) MEM_alloc(200 * sizeof(char *));
	const char *attrss2[2];
	const char *valuess2[2];
	const char *attrss3[2];
	const char *valuess3[2];
	//MT end
	//printf("\n FUN:part no :%s.", InputPart);fflush(stdout);
	TC_write_syslog("\n t5GetItemRevison:part1:[%s].", InputPart);
	//GETTING RELEASED REVISION
	const char *attrs2[2];
	const char *values2[2];
	attrs2[0] ="item_id";
	attrs2[1] ="object_type";
	values2[0] = (char *)InputPart;
	values2[1] = "Design";
	if(ITEM_find_items_by_key_attributes(2,attrs2, values2,&n_tags_found2,&tags_found2)!=ITK_ok)PrintErrorStack();
	//printf("\n FUN:count n_tags_found2 :%d.", n_tags_found2);fflush(stdout);

	if (n_tags_found2>0)
	{
		OutPutTag= tags_found2[0];
	}
	else
	{
		///printf("\n FUN:Inside T5_EE_Part:%s.", InputPart);fflush(stdout);
		attrss2[0] ="item_id";
		attrss2[1] ="object_type";
		valuess2[0] = (char *)InputPart;
		valuess2[1] = "T5_EE_Part";
		if(ITEM_find_items_by_key_attributes(2,attrss2, valuess2,&n_tags_foundd2,&tags_foundd2)!=ITK_ok)PrintErrorStack();
		//printf("\n FUN:EE part count :%d.", n_tags_foundd2);fflush(stdout);
		if (n_tags_foundd2>0)
		{
			OutPutTag= tags_foundd2[0];
		}
		else
		{
			//printf("\n FUN:Inside T5_ClrPart:%s.", InputPart);fflush(stdout);
			attrss3[0] ="item_id";
			attrss3[1] ="object_type";
			valuess3[0] = (char *)InputPart;
			valuess3[1] = "T5_ClrPart";
			if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3,&n_tags_foundd3,&tags_foundd3)!=ITK_ok)PrintErrorStack();
			//printf("\n FUN:T5_ClrPart part count :%d.", n_tags_foundd3);fflush(stdout);
			if (n_tags_foundd3>0)
			{
				OutPutTag= tags_foundd3[0];
			}
			else
			{
				//printf("\n FUN:Inside T5_ArchModule:%s.", InputPart);fflush(stdout);
				attrss3[0] ="item_id";
				attrss3[1] ="object_type";
				valuess3[0] = (char *)InputPart;
				valuess3[1] = "T5_ArchModule";
				if(ITEM_find_items_by_key_attributes(2,attrss3, valuess3,&n_tags_foundd3,&tags_foundd3)!=ITK_ok)PrintErrorStack();
				//printf("\n FUN:T5_ArchModule part count :%d.", n_tags_foundd3);fflush(stdout);
				if (n_tags_foundd3>0)
				{
					OutPutTag= tags_foundd3[0];
				}
			}
		}
	}
	if(OutPutTag==NULLTAG)
	{
		printf("\n FUN: NULL tag for part no:%s.", InputPart);fflush(stdout);
		TC_write_syslog("\n FUN: NULL tag for part no:%s.", InputPart);
	}
	else
	{
		printf("\n FUN: tag found for part no:%s.", InputPart);fflush(stdout);
		TC_write_syslog("\n FUN: tag found for part no:%s.", InputPart);
	}
	return OutPutTag;
}

/************main function*******************/
int ITK_user_main (int argc, char ** argv )
{
	FILE *ReportVehicle;
	int ifail = ITK_ok;
	int	n_rev_entries = 2;
	int	n_rev_entriestwo = 2;
	int status = 0;
	int n_tags_found1 = 0;
	int n_tags_found2 = 0;
	int Count = 0;
	int ij = 0;
	int ik = 0;
	int It = 0;
	int Itt = 0;
	int pCnt = 0;
	int pCnt1 = 0;
	int rev_cnt = 0;
	int rev_cnttwo = 0;
	int n_attchsNON1 = 0;
	int n_attchsNON2 = 0;
	int RCnt = 0;
	int revCnt = 0;
	int PartCnt = 0;
	int PartCnt1 = 0;
	int num_to_sort = 1;
	int one_entry = 1;
	int QryOPCount = 0;
	int sort_order[1]  ={2};
	int no_bom_linesO=0;
	int no_bom_linesT=0;
	//int tt = 0;
	int m =0;
	int m1 =0;
	int m2 =0;
	int b =0;
	int rulefound = 0;
	int rulefoundtwo = 0;
	int transfermode1Cnt = 0;
	int depthExpandVC1 = 0;
	int depthExpandVC2 = 0;
	int depthforfind1 = 0;
	int depthforfind2 = 0;
	int depthforfind3 = 0;
	int depthforprint1 = 0;
	int depthforprint2 = 0;
	int depthforprint3 = 0;
	int rulefoundqty = 0;
	int ctr = 0;
	int cnt = 0;
	//int ifail;
	char *qry_entries[2] = {"Item ID","Revision"};
	char *qry_entriesTwo[2] = {"Item ID","Revision"};
	//char *qry_entries[1] = {"ID"};
	char *sUserName		=   NULL;
	char *sPassword		=   NULL;
	char *sgrp		=   NULL;
	char *IteamNumberone		=	NULL;
	char *IteamNumberTwo		=	NULL;
	char *PartNumC	=	NULL;
	char *PartNumCDup	=	NULL;
	char *DmlprojectcodeDup	=	NULL;
	char *RelStat		=	NULL;
	char *RelStatDup		=	NULL;
	char *RevSeq		=	NULL;
	char *partClrInd		=	NULL;
	char *partClrIndDup		=	NULL;
	char **valuesone             = NULL;
	char **valuesTwo             = NULL;
	char **rulename				 = NULL;
	char **rulevalue			 = NULL;
	char *itemid	    =   NULL;
	char *itemidDup	    =   NULL;
	char	*PrtNoone			= NULL;
	char	*PrtNoTwo			= NULL;
	//char *ReferStd_cnt	    =   NULL;
	char *Fromdate	    =   NULL;
	char *Todate	    =   NULL;
	char* CLName;
	char lineRead[500];
	char* CLNum = NULL;
	char* CLNump = NULL;
	char* PartName = NULL;
	char    *Assym1			= NULL;
	char    *Rev1			= NULL;
	char    *Seq1			= NULL;
	char    *Assym2			= NULL;
	char    *Rev2			= NULL;
	char    *Seq2			= NULL;
	char	*PrtNooneRevId		= NULL;
	char	*PrtNoTwoRevId		= NULL;
	char	*PrtNoOneSeqId		= NULL;
	char	*PrtNoTwoSeqId		= NULL;
	char* Dmlprojectcode = NULL;
	char* NonColorPar1 = NULL;
	char* NonColorPar2 = NULL;
	char* PartName1 = NULL;
	char* NonColorPart = NULL;
	char* objtype = NULL;
	char* objtypep = NULL;
	char* objtyperev = NULL;
	//char* ChPartTags = NULL;
	char* CLNumDup = NULL;
	char* CLNumpDup = NULL;
	char* DMLStr = NULL;
	char* PartNameDup = NULL;
	char* PartNameDup1 = NULL;
	char* NonColorPartDup1 = NULL;
	char* NonColorPartDup2 = NULL;
	char* objtypeDup = NULL;
	char* objtypepDup = NULL;
	char* objtyperevDup = NULL;
	char *keysAttr[1]		    =  {"creation_date"};
	//char *RevisionRule	    = NULL;
	char *RRForNewVC	    = NULL;
	char *RRForRefVC	    = NULL;
	//char *ClosureView	    = NULL;
	//char *ClosureVForNewVC	    = NULL;
	char *ClosureViewNewVC	    = NULL;
	//char *ClosureVForRefVC	    = NULL;
	char *ClosureViewRefVC	    = NULL;
	char *Date	    = NULL;
	char *WithoutZeroQty	    = NULL;
	char *Plant	    = NULL;
	char* DmlRelType	= NULL;
	char* PrtNooneDup1 = NULL;
	char* IteamNumberoneDup = NULL;
	char* IteamNumberTwoDup = NULL;
	char* PrtNoTwoDup2 = NULL;
	char* PrtNoTwoRevIdDup2 = NULL;
	char* PrtNoTwoSeqIdDup2 = NULL;
	char* RevSeqCat1 = NULL;
	char* RevSeqCat2 = NULL;
	char *expansionLvl = NULL;
	char *Without_underscore = NULL;
	char *Stop_AT_F = NULL;
	char *tokenX = NULL;
	char *tokenX2 = NULL;
	char *tokenX3 = NULL;
	char *IteamNumberonecompare = NULL;
	char *ChildRevSeqTwo = NULL;
	char *ChildDescTwo = NULL;
	//char			fpFile[200]				= "";
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **qry_valuesTwo = (char **) MEM_alloc(10 * sizeof(char *));
	childPart = (char**)MEM_alloc( 1000 * sizeof *childPart );
	childParttwo = (char**)MEM_alloc( 1000 * sizeof *childParttwo );
	childPartthree = (char**)MEM_alloc( 1000 * sizeof *childPartthree );
	childPartFour = (char**)MEM_alloc( 1000 * sizeof *childPartFour );
	childPartFive = (char**)MEM_alloc( 1000 * sizeof *childPartFive );
	childPartSix = (char**)MEM_alloc( 1000 * sizeof *childPartSix );
	childPartRep1 = (char**)MEM_alloc( 1000 * sizeof *childPartRep1 );
	childPartRep2 = (char**)MEM_alloc( 1000 * sizeof *childPartRep2 );
	tag_t   Query_Tag    = NULLTAG;
	tag_t	PartTag		      = NULLTAG;
	tag_t	PartTagC		      = NULLTAG;
	tag_t *items              = NULL;
	tag_t *ColPartTags              = NULL;
	tag_t   CL_TASK_Query    = NULLTAG;
	tag_t	CLTag		      = NULLTAG;
	tag_t	tRelationFindOne	  = NULLTAG;
	tag_t	tRelationFindTwo	  = NULLTAG;
	tag_t		AssemoneQuery			= NULLTAG;
	tag_t		AssemTwoQuery			= NULLTAG;
	tag_t		CLprintTag			= NULLTAG;
	tag_t		PartTag1			= NULLTAG;
	tag_t		PartTag2			= NULLTAG;
	tag_t		PartTag3			= NULLTAG;
	tag_t		PartTag4			= NULLTAG;
	tag_t		PartTag5			= NULLTAG;
	tag_t		ERCDMLTag			= NULLTAG;
	tag_t		ERCDMLQry			= NULLTAG;
	tag_t		*ChPartTags			= NULLTAG;
	tag_t		*allRevTag			= NULLTAG;
	tag_t		*ChPartTags1			= NULLTAG;
	tag_t		*secondary_objects1			= NULLTAG;
	tag_t		*secondary_objects2		= NULLTAG;
	tag_t		*ERCDMLTags				= NULLTAG;
	tag_t		*rev_list_set		= NULLTAG;
	tag_t		*rev_list_settwo		= NULLTAG;
	tag_t		 Obj_tagone				= NULLTAG;
	tag_t		 Obj_tagtwo				=	NULLTAG;
	tag_t		 Rev_tone				= NULLTAG;
	tag_t		 Rev_tTwo				= NULLTAG;
	tag_t		*t_allrevdocs              = NULL;
	tag_t		*t_allrevdocsTwo              = NULL;
	tag_t		*child_bom_linesOne		= NULLTAG;
	tag_t		*child_bom_linesTwo		= NULLTAG;
	tag_t		*closurerule			= NULL;
	tag_t		*closureruletwo			= NULL;
	tag_t		*transfermodes1			= NULLTAG;
	tag_t		*Partclosurerule			= NULLTAG;
	tag_t		*Dml_tasks			= NULLTAG;
	tag_t		*PartsTags			= NULLTAG;
	tag_t		IteamprintTag			= NULLTAG;
	tag_t		Bomlinetagone			= NULLTAG;
	tag_t		windowVCO				= NULLTAG;
	tag_t		windowVCT				= NULLTAG;
	tag_t		ruleone					= NULLTAG;
	tag_t		ruleTwo					= NULLTAG;
	tag_t		top_lineVCO				= NULLTAG;
	tag_t		top_lineVCT				= NULLTAG;
	tag_t		IteamprintTagTwo		= NULLTAG;
	tag_t		Bomlinetagonex		= NULLTAG;
	tag_t		Partclose_tag		= NULLTAG;
	tag_t		Dml_task		= NULLTAG;
	tag_t		close_tag;
	tag_t		close_tagtwo;
	char *TempFileNameStr = NULL;
	TempFileNameStr = (char *)MEM_alloc(100);
	time_t t = time(NULL);
	char *VehicleFile = NULL;
	char *Timestamp = NULL;
	VehicleFile = (char *) MEM_alloc (sizeof (char) * 128);
	char *FinalVehicleFile = NULL;
	FinalVehicleFile = (char *) MEM_alloc (sizeof (char) * 128);
	Timestamp = (char *) MEM_alloc (sizeof (char) * 128);
	struct tm tm = *localtime(&t);
	char **Partrulenamee = NULL;
	char **Partrulevaluee = NULL;
	char *VCORParrtnumRev = NULL;
	char *VCORParrtnum = NULL;
	char *classtype = NULL;
	char *VCORParrtRev = NULL;
	char *VCORParrtRevDup = NULL;
	char *level = NULL;
	char *Qty = NULL;
	char *UserID = NULL;
	char *userPMXUinfo1 = NULL;
	char *userPMXUinfo2 = NULL;
	char *Taskobject_type = NULL;
	char str1[100];
	char str2[100];
	char str3[100];
	char str4[100];
	char str5[100];
	char str6[100];
	int subchildno_bom_linesx = 0;
	int i1 = 0;
	int taskcnt = 0;
	int Totalpartcnt = 0;
	int Prtcnt = 0;
	//int status = 0;
	tag_t		*subchild_bom_linesx			= NULLTAG;
	tag_t		subchilditeam			= NULLTAG;
	level = (char *)MEM_alloc(50);
	tc_strcpy(level, "0");
	Qty = (char *)MEM_alloc(50);
	tc_strcpy(Qty, " ");

	tag_t	t_user 		= 	NULLTAG;
	tag_t	t_userHomeFl 		= 	NULLTAG;
	int i_CountOfRef = 0;
	tag_t	*t_RefList	=	NULLTAG;
	int k=0;
	char			* c_RefNAME						= NULL;
	int z = ITK_ok;
	char * cError = NULL;
	tag_t	t_SPKT_FL 		= 	NULLTAG;
	int SpareKitFlag =0;
	char * c_OwningUser = NULL;
	char * c_FolderName = NULL;
	tag_t	t_FolderType 		= 	NULLTAG;
	tag_t	t_CreateIpFl 		= 	NULLTAG;
	tag_t	t_NewFL 		= 	NULLTAG;
	char*   c_FL_name  			= NULL;
	char *Filepath = NULL;
	char * filename = NULL;
	Filepath =(char *) MEM_alloc(200);
	filename =(char *) MEM_alloc(200);

	//Get DML value

	tag_t   part_Dml_rel_type_t	= NULLTAG;
	tag_t   task_tag	= NULLTAG;
	int Part_task_c = 0;
	int r = 0;
	int Tskcount=0;
	int DmlDRFlag_rsltCount=0;
	tag_t *part_task_t         = NULLTAG;
	tag_t objTypTag			   = NULLTAG;
	tag_t   dml_tsk_rel_type					= NULLTAG;
	char *objType = NULL;
	char *DMLNo = NULL;
	char *Reltype = NULL;
	char *Part_num_prnt = NULL;
	tag_t *ERCDmlRevision      = NULLTAG;
	tag_t ercDml      = NULLTAG;
	char * TargetPlant = NULL;
	char * ClosurePnt= NULL;
	char * TargetPlantBomLineCS = NULL;
	char * rlstype = NULL;
	char * itemname = NULL;
	char * DmlDRFlagUserinfo2 = NULL;
	char * DmlDRFlagUserinfo1 = NULL;
	char * Rev = NULL;
	char * parttype = NULL;
	TargetPlantBomLineCS = (char *) MEM_alloc(50);
	Part_num_prnt = (char *) MEM_alloc(30);
	ClosurePnt = (char *) MEM_alloc(30);
	tag_t	All_item_tag	= NULLTAG;
	tag_t	DMLTag	= NULLTAG;
	tag_t	DMLRevTag	= NULLTAG;
	tag_t	PPrttsk_dml_rel_type	= NULLTAG;
	tag_t	Prt_tag	= NULLTAG;
	tag_t	contag	= NULLTAG;
	tag_t	*DmlDRFlagCntrlObjectTag	= NULLTAG;

	char    **DmlDRFlag_qry_values     =  (char **) MEM_alloc(100 * sizeof(char *));


	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	status=ITK_auto_login( );
	ITK_CALL(ITK_set_journalling( TRUE ));
	

//	sUserName = ITK_ask_cli_argument("-u=");
//	sPassword = ITK_ask_cli_argument("-pf=");
//	sgrp = ITK_ask_cli_argument("-g=");
	Assym1 = ITK_ask_cli_argument("-VC=");
	Rev1 = ITK_ask_cli_argument("-Revision=");
	Seq1 = ITK_ask_cli_argument("-Sequence=");
	RRForNewVC = ITK_ask_cli_argument("-RRForVC=");
	ClosureViewNewVC = ITK_ask_cli_argument("-ClosureVForVC=");
	UserID = ITK_ask_cli_argument("-UserID=");
	//status=ITK_init_module(sUserName, sPassword, sgrp);

	if (status == 0)
	{
		printf("Login succesfully...........");fflush(stdout);
		//CHecking for DML or VC
		All_item_tag= t5GetItemRevison(Assym1);
		if(All_item_tag==NULLTAG)
		{
			printf("\n Wt:ERROR:All_item_tag is NULL. It is DML case.\n");fflush(stdout);
			//return 0;
			//Check Revision/Seq is NA
			//query DML
			//DML type: Veh and TODR
			//party type vehicle 9 digit only..
			//get all input details
			//RRForNewVC=
			//ClosureViewNewVC=
			//if ((strlen(Rev1==0)) && (strlen(Rev1==0))&&(strlen(UserID==0)))
			if(tc_strcmp(Rev1,"NA")==0)
			{
				if(ITEM_find_item(Assym1,&DMLTag)!=ITK_ok)PrintErrorStack();
				if(ITEM_ask_latest_rev(DMLTag,&DMLRevTag)!=ITK_ok)PrintErrorStack();

				ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"object_string",&itemname));
				ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"item_id",&itemid));
				ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"t5_rlstype",&rlstype));
				printf("\n itemname is-->[%s] itemid : %s rlstype is %s\n",itemname,itemid,rlstype);fflush(stdout);
				if((tc_strcmp(rlstype,"Veh")==0)||(tc_strcmp(rlstype,"TODR")==0)||(tc_strcmp(rlstype,"Gate Maturation")==0)||(tc_strcmp(rlstype,"Vehicle Release")==0))
				{
					ITKCALL(GRM_find_relation_type("T5_DMLTaskRelation",&PPrttsk_dml_rel_type));
					ITKCALL(GRM_list_secondary_objects_only(DMLRevTag,PPrttsk_dml_rel_type,&cnt,&Dml_tasks));

					for(taskcnt=0;taskcnt<cnt;taskcnt++)
					{
						Dml_task = Dml_tasks[taskcnt];

						ITK_CALL(AOM_ask_value_string(Dml_task,"object_type",&Taskobject_type));
						printf("\n Taskobject_type is-->[%s]\n",Taskobject_type);fflush(stdout);

						if(tc_strcmp(Taskobject_type,"T5_ChangeTaskRevision")==0)
						{
							if ((tc_strcmp(rlstype,"Veh")==0)||(tc_strcmp(rlstype,"Vehicle Release")==0))
							{
								ITK_CALL(AOM_ask_value_tags(Dml_task,"CMHasSolutionItem",&Totalpartcnt,&PartsTags));
								printf("\n Totalpartcnt-->[%d] ",Totalpartcnt);fflush(stdout);
							}
							else if ((tc_strcmp(rlstype,"Gate Maturation")==0) || (tc_strcmp(rlstype,"TODR")==0))
							{
								ITK_CALL(AOM_ask_value_tags(Dml_task,"CMReferences",&Totalpartcnt,&PartsTags));
								printf("\n Totalpartcnt-->[%d] ",Totalpartcnt);fflush(stdout);
							}
							else
							{
								printf("\n not eligible DML");fflush(stdout);
							}
							if (Totalpartcnt >0)
							{
								for(Prtcnt=0;Prtcnt<Totalpartcnt;Prtcnt++)
								{
									Assym1				 = NULL;
									Rev1				= NULL;
									Seq1				= NULL;
									RRForNewVC			= NULL;
									ClosureViewNewVC	= NULL;

									Prt_tag = PartsTags[Prtcnt];
									ITK_CALL(AOM_UIF_ask_value(Prt_tag,"item_id",&Assym1));
									ITK_CALL(AOM_UIF_ask_value(Prt_tag,"item_revision_id",&Rev));
									ITK_CALL(AOM_UIF_ask_value(Prt_tag,"sequence_id",&Seq1));
									ITK_CALL(AOM_UIF_ask_value(Prt_tag,"t5_PartType",&parttype));


									Rev1 = tc_strtok (Rev,";");
									printf("\n Rev1 is----> [%s]\n",Rev1);fflush(stdout);

									if(QRY_find2("Control Objects...",&contag));
									if(contag)
									{
										printf("\n contag:Found Query ControlObjects \n");fflush(stdout);
									}
									else
									{
										printf("\n contag:Not Found Query ControlObjects \n");fflush(stdout);
									}
									if(contag!=NULLTAG)
									{
										//printf("\n contag::DMLReason :[%s]:", DMLReason); fflush(stdout);

										char    *DmlDRFlag_qry_entry[1]		= {"SYSCD"};
										DmlDRFlag_qry_values[0] = "RULEENTRY";
										
										if(QRY_execute(contag, 1, DmlDRFlag_qry_entry, DmlDRFlag_qry_values,&DmlDRFlag_rsltCount,&DmlDRFlagCntrlObjectTag));
										printf("\n DmlDRFlag_rsltCount :%d:", DmlDRFlag_rsltCount); fflush(stdout);
										if(DmlDRFlag_rsltCount>0)
										{
											ITK_CALL(AOM_ask_value_string(DmlDRFlagCntrlObjectTag[0],"t5_Userinfo1",&DmlDRFlagUserinfo1));
											ITK_CALL(AOM_ask_value_string(DmlDRFlagCntrlObjectTag[0],"t5_Userinfo2",&DmlDRFlagUserinfo2));
										}
									}
									RRForNewVC = (char *) MEM_alloc(50);
									ClosureViewNewVC = (char *) MEM_alloc(50);

									tc_strcpy(RRForNewVC,"");
									tc_strcat(RRForNewVC,DmlDRFlagUserinfo1);

									tc_strcpy(ClosureViewNewVC,"");
									tc_strcat(ClosureViewNewVC,DmlDRFlagUserinfo2);

									printf("\n RRForNewVC :%s: ClosureViewNewVC is %s parttype is %s", RRForNewVC,ClosureViewNewVC,parttype); fflush(stdout);
									if ((tc_strcmp(parttype,"Vehicle")==0)||(tc_strcmp(parttype,"V")==0))
									{
										sprintf(str1, "%d", tm.tm_mday);
										sprintf(str2, "%d", tm.tm_mon + 1);
										sprintf(str3, "%d", tm.tm_year + 1900);
										sprintf(str4, "%d", tm.tm_hour);
										sprintf(str5, "%d", tm.tm_min);
										sprintf(str6, "%d", tm.tm_sec);
										tc_strcpy(Timestamp, str1);
										tc_strcat(Timestamp, "_");
										tc_strcat(Timestamp, str2);
										tc_strcat(Timestamp, "_");
										tc_strcat(Timestamp, str3);
										tc_strcat(Timestamp, "_");
										tc_strcat(Timestamp, str4);
										tc_strcat(Timestamp, "_");
										tc_strcat(Timestamp, str5);
										tc_strcat(Timestamp, "_");
										tc_strcat(Timestamp, str6);
										tc_strcpy(VehicleFile,"");
										tc_strcat(VehicleFile,"Spare_kit_report");
										tc_strcat(VehicleFile,"_");
										tc_strcat(VehicleFile,Assym1);
										tc_strcat(VehicleFile,"_");
										tc_strcat(VehicleFile,Timestamp);
										tc_strcat(VehicleFile,".csv");
										tc_strcpy(FinalVehicleFile,"/tmp/");
										tc_strcat(FinalVehicleFile,VehicleFile);
										if(STRNG_replace_str(FinalVehicleFile, ";", "_", &FinalVehicleFile)!=ITK_ok)PrintErrorStack();
										printf("\n Veh--A----sparekitreport--FinalVehicleFile: [%s] ",FinalVehicleFile); fflush(stdout);
										ReportVehicle=fopen(FinalVehicleFile,"w");
										if (ReportVehicle == NULL)
										{
											printf(" Veh--ERROR: XML ReportVehicle Cannot open File\n"); fflush(stdout);
											return -1;
										}
										else
										{
											printf(" Veh--XML ReportVehicle File opened successfully.\n"); fflush(stdout);
										}
										/**Added BY Aadarsh kumar for control object **/
										int n_entry    = 1;
										int rsltCount    = 1;
										tag_t   qryTag     = NULLTAG;
										tag_t   *CntrlObjectTag      = NULLTAG;
										char   *qry_entry[1]  = {"SYSCD"};
										char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
										char* userSpareinfo1 = NULL;
										char* userSpareinfo2 = NULL;
										tag_t CntrlObjectObj = NULLTAG;
										printf("\n Spare_kit_Report-->Printing before Control object executing\n");fflush(stdout);
										if(QRY_find2("ControlObjects", &qryTag));
										if (qryTag)
										{
											printf("\n Spare_kit_Report-->Output location:Found Query ControlObjects \n");fflush(stdout);
										}
										else
										{
											printf("\n Spare_kit_Report-->Output location:Not Found Query ControlObjects \n");fflush(stdout);
										}

										qry_values2[0] = "Spare_kit_Report";

										if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
										printf(" \n Spare_kit_Report-->Output value:rsltCount 11:%d:", rsltCount); fflush(stdout);
										if(rsltCount > 0)
										{
											printf(" \n Spare_kit_Report-->Output value:rsltCount 11:1111111"); fflush(stdout);
											CntrlObjectObj = CntrlObjectTag[0];
											printf(" \n Spare_kit_Report-->Output value:rsltCount 11222222222222"); fflush(stdout);
											if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo1",&userSpareinfo1)!=ITK_ok)   PrintErrorStack();
											if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo2",&userSpareinfo2)!=ITK_ok)   PrintErrorStack();
											printf(" \n Spare_kit_Report-->Output value:rsltCount 113333333333333"); fflush(stdout);
											printf(" \n Spare_kit_Report-->userSpareinfo1= [%s] userSpareinfo2= [%s]", userSpareinfo1,userSpareinfo2); fflush(stdout);
											printf(" \n Spare_kit_Report-->Output value:rsltCount 114444444444444444"); fflush(stdout);
										}
										else
										{
											printf(" \n Spare_kit_Report-->Spare_kit_Report control object not found hence exit from code...\n"); fflush(stdout);
											return 1;
										}
										if (userSpareinfo1!= NULL)
										{
											tc_strcpy(TempFileNameStr,"");
											tc_strcpy(TempFileNameStr,userSpareinfo1);
											tc_strcat(TempFileNameStr,userSpareinfo2);
											tc_strcat(TempFileNameStr,".xml");

											Report=fopen(TempFileNameStr,"w");

											printf("\n PMXU_Report-->2.TempFileNameStr: [%s]",TempFileNameStr); fflush(stdout);

											//Control object end
											//Report=fopen("/tmp/pmxuReport.xml","w");
											//Report=fopen("/plmpv16/reports/pmxuReport.xml","w"); //mapped folder directory
											if (Report == NULL)
											{
												printf("\t-->2.ERROR: XML Cannot open File\n"); fflush(stdout);
												return -1;
											}
											else
											{
												printf("\t-->2.XML File opened successfully.\n"); fflush(stdout);
											}
										}
										else
										{
											printf("\n Spare_kit_Report-->2.userSpareinfo1 in Spare_kit_RPT control object not found hence exit from code...\n"); fflush(stdout);
											return -1;
										}
										write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
										write2xml(Report,"\n<Top>\n");
										write2xml(Report,"\n<VC>");
										write2xml(Report,Assym1);
										write2xml(Report,"</VC>");  printf("\n\t --2-- ");

										printf("Date: %d-%d-%d\n", tm.tm_year + 1900, tm.tm_mon + 1,tm.tm_mday); fflush(stdout);
										write2xml(Report,"\n<Date>");
										fprintf(Report,"%d-%d-%d",tm.tm_mday, tm.tm_mon + 1,  tm.tm_year + 1900); fflush(Report);
										write2xml(Report,"</Date>\n");

										write2xml(Report,"\n<Revision>");
										write2xml(Report,Rev1);
										write2xml(Report,"</Revision>\n");

										write2xml(Report,"\n<Sequence>");
										write2xml(Report,Seq1);
										write2xml(Report,"</Sequence>\n");
										printf("Login succesfully");
										valuesone = (char **) MEM_alloc(n_rev_entries * sizeof(char *));
										valuesone[0] = (char *)MEM_alloc( strlen( Assym1 ) + 1);

										tc_strcpy(valuesone[0], Assym1);
										
										RevSeqCat1 = (char *)MEM_alloc(50);
										tc_strcpy(RevSeqCat1, Rev1);
										tc_strcat(RevSeqCat1, "*");
										tc_strcat(RevSeqCat1, Seq1);
										valuesone[1] = (char *)MEM_alloc( strlen( RevSeqCat1 ) + 1);
										tc_strcpy(valuesone[1], RevSeqCat1);
										printf("\nthe Revision sequence of the part 1 is %s\n",RevSeqCat1);
										QRY_find2("Item Revision...", &AssemoneQuery);
										printf("\nafter Iteam revision\n");fflush(stdout);
										ifail = BOM_create_window(&windowVCO);
										ifail = CFM_find(RRForNewVC, &ruleone);
										if (tc_strcmp(ClosureViewNewVC,"ERC")==0)
										{
											printf("inside ERC closure rule..\n");fflush(stdout);
											ifail = PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER,&rulefound,&closurerule);
											tc_strcpy(ClosurePnt, "");
											tc_strcat(ClosurePnt, "BOMViewClosureRuleERC");
										}
										else if (tc_strcmp(ClosureViewNewVC,"APLC")==0)
										{
											printf("inside APLC closure rule..\n");fflush(stdout);
											ifail = PIE_find_closure_rules2("BOMViewClosureRuleAPLC",PIE_TEAMCENTER,&rulefound,&closurerule);
											tc_strcpy(ClosurePnt, "");
											tc_strcat(ClosurePnt, "BOMViewClosureRuleAPLC");
										}
										else if (tc_strcmp(ClosureViewNewVC,"STDSI")==0)
										{
											printf("inside STDSI closure rule..\n");fflush(stdout);
											ifail = PIE_find_closure_rules2("BOMViewClosureRuleSTDC",PIE_TEAMCENTER,&rulefound,&closurerule);
											tc_strcpy(ClosurePnt, "");
											tc_strcat(ClosurePnt, "BOMViewClosureRuleSTDC");
										}
										printf ("rule count %d \n",rulefound);fflush(stdout);
										if (rulefound > 0)
										{
											close_tag = closurerule[0];
											printf ("closure rule found New VC \n");fflush(stdout);
										}
										if (tc_strlen(ClosurePnt)==0)
										{
											tc_strcpy(ClosurePnt, "");
										}
										tc_strcpy(Part_num_prnt, "");
										tc_strcat(Part_num_prnt, Assym1);
										tc_strcat(Part_num_prnt, ";");
										tc_strcat(Part_num_prnt, Rev1);
										tc_strcat(Part_num_prnt, ";");
										tc_strcat(Part_num_prnt, Seq1);
										fprintf(ReportVehicle,"Vehicle: %s\n",Part_num_prnt); fflush(ReportVehicle);
										fprintf(ReportVehicle,"view: %s\n",ClosureViewNewVC); fflush(ReportVehicle);
										fprintf(ReportVehicle,"Revision Rule: %s\n",RRForNewVC); fflush(ReportVehicle);
										fprintf(ReportVehicle,"Closure Rule: %s\n",ClosurePnt); fflush(ReportVehicle);
										fprintf(ReportVehicle,"Date: %d-%d-%d\n",tm.tm_mday, tm.tm_mon + 1,  tm.tm_year + 1900); fflush(ReportVehicle);
										printf("\nLevel,Class,Part No,Description,AddOn Description,Quantity,Revision Seq,Project Code,Design Group,Weight,Spare Indicator,Plant CS,PO_NO,PO_Date,Part Catogory,Party Part Number,Owner,DML,Release Date,Release Type,Lifecycle State,Envelope Dimensions");fflush(stdout);
										fprintf(ReportVehicle,"\nLevel,Class,Part No,Description,AddOn Description,Quantity,Revision Seq,Project Code,Design Group,Weight,Spare Indicator,Plant CS,PO_NO,PO_Date,Part Catogory,Party Part Number,Owner,DML,Release Date,Release Type,Lifecycle State,Envelope Dimensions,");fflush(ReportVehicle);
										if (AssemoneQuery!=NULLTAG)
										{
											if (QRY_execute(AssemoneQuery, n_rev_entries, qry_entries, valuesone, &n_tags_found1, &t_allrevdocs));
											printf("\nInside first part tag  n_tags_found1: [%d] \n",n_tags_found1);fflush(stdout);
											
											if (n_tags_found1>0)
											{
												for (It=0;It<n_tags_found1;It++)
													{
														IteamprintTag=t_allrevdocs[0];
														ITK_CALL(AOM_UIF_ask_value(IteamprintTag,"object_string",&IteamNumberone));
														ITK_CALL(AOM_UIF_ask_value(IteamprintTag,"item_id",&VCORParrtnum));
														ITK_CALL(AOM_UIF_ask_value(IteamprintTag,"current_revision_id",&VCORParrtRev));
														tc_strdup(VCORParrtRev,&VCORParrtRevDup);
														//getting DML
														ifail = GRM_find_relation_type("CMHasSolutionItem" ,&part_Dml_rel_type_t);
														ifail = GRM_list_primary_objects_only(IteamprintTag,part_Dml_rel_type_t,&Part_task_c,&part_task_t);
														printf("\n DR: DML GET Part_task_c:%d", Part_task_c);fflush(stdout);
														for (r=0;r<Part_task_c;r++)
															{
																task_tag = part_task_t[r];
																if (task_tag != NULLTAG)
																{
																	 ifail = TCTYPE_ask_object_type(task_tag,&objTypTag);
																	 if(TCTYPE_ask_name2(objTypTag,&objType));
																	 printf("\n  object_type is %s\n", objType);fflush(stdout);
																	 printf("\n FOR VC --- T5_ChangeTaskRevision>>>>>>>> : [%s]\n",objType); fflush(stdout);	
																	 if(tc_strcmp(objType,"T5_ChangeTaskRevision")==0)
																	 {
																		ifail = GRM_find_relation_type ( "T5_DMLTaskRelation", &dml_tsk_rel_type ) ;
																		ifail = GRM_list_primary_objects_only ( task_tag, dml_tsk_rel_type, &Tskcount, &ERCDmlRevision ) ;//task to dml rev traversal
																		ercDml = ERCDmlRevision[0];										   
																		ITK_CALL(AOM_UIF_ask_value(ercDml, "item_id" ,&DMLNo));
																		ITK_CALL(AOM_UIF_ask_value(ercDml, "t5_rlstype" ,&Reltype));
																		printf("\nDml_No>>>>>>>> : [%s]\n",DMLNo); fflush(stdout);
																		if(AOM_ask_value_string(ercDml,"t5_TargetPlant",&TargetPlant)!=ITK_ok)PrintErrorStack();  //TargetPlant from DML
																		printf(" \n\n TargetPlant: %s ",TargetPlant);fflush(stdout);
																		if ((tc_strcmp(TargetPlant,"PCVBU")==0) ||(tc_strcmp(TargetPlant,"PCVBU")==0))  //PCVBU
																		{
																			tc_strcpy(TargetPlantBomLineCS,"t5_PunMakeBuyIndicator");
																		}
																		else if ((tc_strcmp(TargetPlant,"CARPLT")==0)||(tc_strcmp(TargetPlant,"CARPLANT")==0)) //CARPLANT
																		{
																			tc_strcpy(TargetPlantBomLineCS,"t5_CarMakeBuyIndicator");
																		}
																		else if ((tc_strcmp(TargetPlant,"DWD")==0) ||(tc_strcmp(TargetPlant,"DHARWAD")==0)) //DHARWAD
																		{
																			tc_strcpy(TargetPlantBomLineCS,"t5_DwdMakeBuyIndicator");
																		}
																		else if ((tc_strcmp(TargetPlant,"PNR")==0) ||(tc_strcmp(TargetPlant,"PANTNAGAR")==0))  //PANTNAGAR
																		{
																			tc_strcpy(TargetPlantBomLineCS,"t5_PnrMakeBuyIndicator");
																		}
																		else if ((tc_strcmp(TargetPlant,"AHD")==0)  ||(tc_strcmp(TargetPlant,"AHMEDABAD")==0))  //AHMEDABAD
																		{
																			tc_strcpy(TargetPlantBomLineCS,"t5_AhdMakeBuyIndicator");
																		}
																		else if ((tc_strcmp(TargetPlant,"JSR")==0)||(tc_strcmp(TargetPlant,"JAMSHEDPUR")==0)) //JAMSHEDPUR
																		{
																			tc_strcpy(TargetPlantBomLineCS,"t5_JsrMakeBuyIndicator");
																		}
																		else if ((tc_strcmp(TargetPlant,"LKO")==0) || (tc_strcmp(TargetPlant,"LUCKNOW")==0)) //LUCKNOW
																		{
																			tc_strcpy(TargetPlantBomLineCS,"t5_LkoMakeBuyIndicator");
																		}
																		else if ((tc_strcmp(TargetPlant,"JDL")==0) || (tc_strcmp(TargetPlant,"JSR DRIVELINES")==0)) //JSR DRIVELINES
																		{
																			tc_strcpy(TargetPlantBomLineCS,"t5_JdlMakeBuyIndicator");
																		}
																		else if (tc_strcmp(TargetPlant,"UV Plant")==0)//UV Plant
																		{
																			tc_strcpy(TargetPlantBomLineCS,"t5_PunUVMakeBuyIndicator");
																		}
																		if (tc_strlen(TargetPlantBomLineCS)==0)
																		{
																			TargetPlantBomLineCS =(char *) MEM_alloc(2);
																			tc_strcpy(TargetPlantBomLineCS,"-");
																		}

																		printf(" TargetPlantBomLineCS:[%s]-----------------------------------",TargetPlantBomLineCS);fflush(stdout);
																	}
															  }
														}
														ITK_CALL(AOM_UIF_ask_value(IteamprintTag,"object_type",&classtype));
														printf("VCORParrtnum is [%s] and VCORParrtnumRev is [%s] and classtype is [%s]",VCORParrtnum,IteamNumberone,classtype);fflush(stdout);
														ITK_CALL(BOM_window_set_closure_rule(windowVCO,close_tag, 0,rulename,rulevalue));
														ITK_CALL(BOM_set_window_config_rule(windowVCO, ruleone));
														ITK_CALL(BOM_set_window_pack_all (windowVCO, true));
														ITK_CALL(BOM_set_window_top_line(windowVCO, NULLTAG, IteamprintTag, NULLTAG, &top_lineVCO));
														PrintAttribuites(VCORParrtnum,VCORParrtRev,level,Qty,ReportVehicle,TargetPlantBomLineCS);
														findsparekitpart(VCORParrtnum,VCORParrtRevDup,ReportVehicle,TargetPlantBomLineCS);
													}

											}
										}
										BOMExpansionforcommon(top_lineVCO,ReportVehicle,TargetPlantBomLineCS);  //Function call	
										printf("\n***********************************Now report Genration is completed***************************\n");fflush(stdout);
										fprintf(ReportVehicle,"\n\n\n\n*****************************************END OF REPORT***********************************\n");fflush(ReportVehicle);
										/*if(SA_find_user2(UserID, &t_user));		
										if(t_user == NULLTAG)
										{
											printf("\n\n\t Error : USER ID TAG IS NULL -->\t USER ID NOT FOUND "); fflush(stdout);
										}
										printf("\n About to find Home folder of user with ID = %s",UserID);fflush(stdout);
										if(SA_ask_user_home_folder(t_user, &t_userHomeFl));
										if(t_userHomeFl != NULLTAG)
										{
											if(FL_ask_references(t_userHomeFl, FL_fsc_by_object ,&i_CountOfRef,&t_RefList));
											printf("\n\t Home Folder References count = %d ",i_CountOfRef);fflush(stdout);
											printf("\n\t -----Inside User [%s] Home Folder-------",UserID);
											
											for (k = 0 ; k < i_CountOfRef ; k++)
											{
												//ITK_CALL(TCTYPE_ask_object_type(t_RefList[k],&objTypTag));
												//ITK_CALL(TCTYPE_ask_name(objTypTag,ObjType));
												//if(WSOM_ask_name(t_RefList[k],&c_RefNAME));
												z= AOM_ask_value_string(t_RefList[k],"object_name",&c_RefNAME);
												
												if (z != ITK_ok)
													{
														EMH_ask_error_text(z, &cError);
														printf("\n\t Error (AOM_ask_value_value) = %s ", cError);
													}
												//printf("\n %d. %s",k,c_RefNAME);
												
												if(tc_strcmp(c_RefNAME,"SpareKit")!=0)
												{
													printf("\n\t ------------> Setting SpareKitFlag = 1 ");
													//t_GenT_FL =  t_RefList[k] ;
													SpareKitFlag = 1;	  // Will create folder named GenTPL					
												}
												else
												{
													z = AOM_UIF_ask_value(t_RefList[k],"owning_user",&c_OwningUser);
													printf("\n\t ------------> Setting SpareKitFlag = 2 ");
													t_SPKT_FL =  t_RefList[k] ;
													SpareKitFlag = 2;	
													break;
													//break;					
												}
												
											}
											
											printf("\n\t -----Out of For Loop ----------");
											
											if (SpareKitFlag == 1)
											{
													printf("\n\t Inside --> SpareKitFlag == 1");
													z= AOM_ask_value_string(t_SPKT_FL,"object_name",&c_FolderName);
													
													if(TCTYPE_find_type( "Folder", NULL, &t_FolderType) );
													if(t_FolderType != NULLTAG)
													printf("\n\t t_FolderType != NULLTAG");
													if(TCTYPE_construct_create_input( t_FolderType,&t_CreateIpFl)) ;
												
													z = AOM_UIF_set_value(t_CreateIpFl,"object_name","SpareKit");
													if (z != ITK_ok)
													{
														EMH_ask_error_text(z, &cError);
														printf("\n\t Error (AOM_UIF_set_value) = %s ", cError);
													}
													//TCTYPE_set_create_display_value( t_CreateIpFl, "object_name", 1,(const char**)Obj_name1) ;
													z = TCTYPE_create_object( t_CreateIpFl,&t_NewFL) ;
													if (z != ITK_ok)
													{
														EMH_ask_error_text(z, &cError);
														printf("\n\t Error (TCTYPE_create_object) = %s ", cError);
													}
													if(t_NewFL != NULLTAG)
													z = POM_set_owning_user(t_NewFL, t_user);
													z = AOM_save_without_extensions(t_NewFL) ;
													if (z != ITK_ok)
													{
														EMH_ask_error_text(z, &cError);
														printf("\n\t Error (AOM_save_without_extensions) = %s ", cError);
													}
													if(AOM_ask_value_string(t_NewFL,"object_name",&c_FL_name));
													
													if(FL_insert(t_userHomeFl,t_NewFL,999));
													if(AOM_save_without_extensions(t_userHomeFl));
													printf("\n Folder created named %s",c_FL_name);
													
													CreateDataset(VehicleFile,t_NewFL, FinalVehicleFile);

													
											}
											
											
											if (SpareKitFlag == 2)
											{
												z= AOM_ask_value_string(t_SPKT_FL,"object_name",&c_FolderName);
												printf("\n\t  Folder =[%s] FOUND user Home Folder and owning user = %s",c_FolderName,c_OwningUser);
												CreateDataset(VehicleFile,t_SPKT_FL ,FinalVehicleFile);
												
												
											}

											
											//MEM_free(t_RefList);
										}*/
										CreateDatasetDML(VehicleFile ,FinalVehicleFile,DMLRevTag);

										printf("\n***********************************File is added***************************\n");fflush(stdout);
										write2xml(Report,"</Top>\n");
										if (Report!=NULL)
										{
											fclose(Report);
										}
										if (ReportVehicle!=NULL)
										{
											fclose(ReportVehicle);
										}
									}
								}
							}
						}
					}
				}
			}
			//////////////////
		}
		else
		{
			sprintf(str1, "%d", tm.tm_mday);
			sprintf(str2, "%d", tm.tm_mon + 1);
			sprintf(str3, "%d", tm.tm_year + 1900);
			sprintf(str4, "%d", tm.tm_hour);
			sprintf(str5, "%d", tm.tm_min);
			sprintf(str6, "%d", tm.tm_sec);
			tc_strcpy(Timestamp, str1);
			tc_strcat(Timestamp, "_");
			tc_strcat(Timestamp, str2);
			tc_strcat(Timestamp, "_");
			tc_strcat(Timestamp, str3);
			tc_strcat(Timestamp, "_");
			tc_strcat(Timestamp, str4);
			tc_strcat(Timestamp, "_");
			tc_strcat(Timestamp, str5);
			tc_strcat(Timestamp, "_");
			tc_strcat(Timestamp, str6);
			tc_strcpy(VehicleFile,"");
			tc_strcat(VehicleFile,"Spare_kit_report");
			tc_strcat(VehicleFile,"_");
			tc_strcat(VehicleFile,Assym1);
			tc_strcat(VehicleFile,"_");
			tc_strcat(VehicleFile,Timestamp);
			tc_strcat(VehicleFile,".csv");
			tc_strcpy(FinalVehicleFile,"/tmp/");
			tc_strcat(FinalVehicleFile,VehicleFile);
			if(STRNG_replace_str(FinalVehicleFile, ";", "_", &FinalVehicleFile)!=ITK_ok)PrintErrorStack();
			printf("\n Veh--A----sparekitreport--FinalVehicleFile: [%s] ",FinalVehicleFile); fflush(stdout);
			ReportVehicle=fopen(FinalVehicleFile,"w");
			if (ReportVehicle == NULL)
			{
				printf(" Veh--ERROR: XML ReportVehicle Cannot open File\n"); fflush(stdout);
				return -1;
			}
			else
			{
				printf(" Veh--XML ReportVehicle File opened successfully.\n"); fflush(stdout);
			}
			/**Added BY Aadarsh kumar for control object **/
			int n_entry    = 1;
			int rsltCount    = 1;
			tag_t   qryTag     = NULLTAG;
			tag_t   *CntrlObjectTag      = NULLTAG;
			char   *qry_entry[1]  = {"SYSCD"};
			char   **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
			char* userSpareinfo1 = NULL;
			char* userSpareinfo2 = NULL;
			tag_t CntrlObjectObj = NULLTAG;
			printf("\n Spare_kit_Report-->Printing before Control object executing\n");fflush(stdout);
			if(QRY_find2("ControlObjects", &qryTag));
			if (qryTag)
			{
				printf("\n Spare_kit_Report-->Output location:Found Query ControlObjects \n");fflush(stdout);
			}
			else
			{
				printf("\n Spare_kit_Report-->Output location:Not Found Query ControlObjects \n");fflush(stdout);
			}

			qry_values2[0] = "Spare_kit_Report";

			if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
			printf(" \n Spare_kit_Report-->Output value:rsltCount 11:%d:", rsltCount); fflush(stdout);
			if(rsltCount > 0)
			{
				printf(" \n Spare_kit_Report-->Output value:rsltCount 11:1111111"); fflush(stdout);
				CntrlObjectObj = CntrlObjectTag[0];
				printf(" \n Spare_kit_Report-->Output value:rsltCount 11222222222222"); fflush(stdout);
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo1",&userSpareinfo1)!=ITK_ok)   PrintErrorStack();
				if (AOM_ask_value_string(CntrlObjectObj,"t5_Userinfo2",&userSpareinfo2)!=ITK_ok)   PrintErrorStack();
				printf(" \n Spare_kit_Report-->Output value:rsltCount 113333333333333"); fflush(stdout);
				printf(" \n Spare_kit_Report-->userSpareinfo1= [%s] userSpareinfo2= [%s]", userSpareinfo1,userSpareinfo2); fflush(stdout);
				printf(" \n Spare_kit_Report-->Output value:rsltCount 114444444444444444"); fflush(stdout);
			}
			else
			{
				printf(" \n Spare_kit_Report-->Spare_kit_Report control object not found hence exit from code...\n"); fflush(stdout);
				return 1;
			}
			if (userSpareinfo1!= NULL)
			{
				tc_strcpy(TempFileNameStr,"");
				tc_strcpy(TempFileNameStr,userSpareinfo1);
				tc_strcat(TempFileNameStr,userSpareinfo2);
				tc_strcat(TempFileNameStr,".xml");

				Report=fopen(TempFileNameStr,"w");

				printf("\n PMXU_Report-->2.TempFileNameStr: [%s]",TempFileNameStr); fflush(stdout);

				//Control object end
				//Report=fopen("/tmp/pmxuReport.xml","w");
				//Report=fopen("/plmpv16/reports/pmxuReport.xml","w"); //mapped folder directory
				if (Report == NULL)
				{
					printf("\t-->2.ERROR: XML Cannot open File\n"); fflush(stdout);
					return -1;
				}
				else
				{
					printf("\t-->2.XML File opened successfully.\n"); fflush(stdout);
				}
			}
			else
			{
				printf("\n Spare_kit_Report-->2.userSpareinfo1 in Spare_kit_RPT control object not found hence exit from code...\n"); fflush(stdout);
				return -1;
			}
			write2xml(Report,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
			write2xml(Report,"\n<Top>\n");
			write2xml(Report,"\n<VC>");
			write2xml(Report,Assym1);
			write2xml(Report,"</VC>");  printf("\n\t --2-- ");

			printf("Date: %d-%d-%d\n", tm.tm_year + 1900, tm.tm_mon + 1,tm.tm_mday); fflush(stdout);
			write2xml(Report,"\n<Date>");
			fprintf(Report,"%d-%d-%d",tm.tm_mday, tm.tm_mon + 1,  tm.tm_year + 1900); fflush(Report);
			write2xml(Report,"</Date>\n");

			write2xml(Report,"\n<Revision>");
			write2xml(Report,Rev1);
			write2xml(Report,"</Revision>\n");

			write2xml(Report,"\n<Sequence>");
			write2xml(Report,Seq1);
			write2xml(Report,"</Sequence>\n");
			printf("Login succesfully");
			valuesone = (char **) MEM_alloc(n_rev_entries * sizeof(char *));
			valuesone[0] = (char *)MEM_alloc( strlen( Assym1 ) + 1);

			tc_strcpy(valuesone[0], Assym1);
			
			RevSeqCat1 = (char *)MEM_alloc(50);
			tc_strcpy(RevSeqCat1, Rev1);
			tc_strcat(RevSeqCat1, "*");
			tc_strcat(RevSeqCat1, Seq1);
			valuesone[1] = (char *)MEM_alloc( strlen( RevSeqCat1 ) + 1);
			tc_strcpy(valuesone[1], RevSeqCat1);
			printf("\nthe Revision sequence of the part 1 is %s\n",RevSeqCat1);
			QRY_find2("Item Revision...", &AssemoneQuery);
			printf("\nafter Iteam revision\n");fflush(stdout);
			ifail = BOM_create_window(&windowVCO);
			ifail = CFM_find(RRForNewVC, &ruleone);
			if (tc_strcmp(ClosureViewNewVC,"ERC")==0)
			{
				printf("inside ERC closure rule..\n");fflush(stdout);
				ifail = PIE_find_closure_rules2("BOMViewClosureRuleERC",PIE_TEAMCENTER,&rulefound,&closurerule);
				tc_strcpy(ClosurePnt, "");
				tc_strcat(ClosurePnt, "BOMViewClosureRuleERC");
			}
			else if (tc_strcmp(ClosureViewNewVC,"APLC")==0)
			{
				printf("inside APLC closure rule..\n");fflush(stdout);
				ifail = PIE_find_closure_rules2("BOMViewClosureRuleAPLC",PIE_TEAMCENTER,&rulefound,&closurerule);
				tc_strcpy(ClosurePnt, "");
				tc_strcat(ClosurePnt, "BOMViewClosureRuleAPLC");
			}
			else if (tc_strcmp(ClosureViewNewVC,"STDSI")==0)
			{
				printf("inside STDSI closure rule..\n");fflush(stdout);
				ifail = PIE_find_closure_rules2("BOMViewClosureRuleSTDC",PIE_TEAMCENTER,&rulefound,&closurerule);
				tc_strcpy(ClosurePnt, "");
				tc_strcat(ClosurePnt, "BOMViewClosureRuleSTDC");
			}
			printf ("rule count %d \n",rulefound);fflush(stdout);
			if (rulefound > 0)
			{
				close_tag = closurerule[0];
				printf ("closure rule found New VC \n");fflush(stdout);
			}
			if (tc_strlen(ClosurePnt)==0)
			{
				tc_strcpy(ClosurePnt, "");
			}
			tc_strcpy(Part_num_prnt, "");
			tc_strcat(Part_num_prnt, Assym1);
			tc_strcat(Part_num_prnt, ";");
			tc_strcat(Part_num_prnt, Rev1);
			tc_strcat(Part_num_prnt, ";");
			tc_strcat(Part_num_prnt, Seq1);
			fprintf(ReportVehicle,"Vehicle: %s\n",Part_num_prnt); fflush(ReportVehicle);
			fprintf(ReportVehicle,"view: %s\n",ClosureViewNewVC); fflush(ReportVehicle);
			fprintf(ReportVehicle,"Revision Rule: %s\n",RRForNewVC); fflush(ReportVehicle);
			fprintf(ReportVehicle,"Closure Rule: %s\n",ClosurePnt); fflush(ReportVehicle);
			fprintf(ReportVehicle,"Date: %d-%d-%d\n",tm.tm_mday, tm.tm_mon + 1,  tm.tm_year + 1900); fflush(ReportVehicle);
			printf("\nLevel,Class,Part No,Description,AddOn Description,Quantity,Revision Seq,Project Code,Design Group,Weight,Spare Indicator,Plant CS,PO_NO,PO_Date,Part Catogory,Party Part Number,Owner,DML,Release Date,Release Type,Lifecycle State,Envelope Dimensions");fflush(stdout);
			fprintf(ReportVehicle,"\nLevel,Class,Part No,Description,AddOn Description,Quantity,Revision Seq,Project Code,Design Group,Weight,Spare Indicator,Plant CS,PO_NO,PO_Date,Part Catogory,Party Part Number,Owner,DML,Release Date,Release Type,Lifecycle State,Envelope Dimensions,");fflush(ReportVehicle);
			if (AssemoneQuery!=NULLTAG)
			{
				if (QRY_execute(AssemoneQuery, n_rev_entries, qry_entries, valuesone, &n_tags_found1, &t_allrevdocs));
				printf("\nInside first part tag  n_tags_found1: [%d] \n",n_tags_found1);fflush(stdout);
				
				if (n_tags_found1>0)
				{
					for (It=0;It<n_tags_found1;It++)
						{
							IteamprintTag=t_allrevdocs[0];
							ITK_CALL(AOM_UIF_ask_value(IteamprintTag,"object_string",&IteamNumberone));
							ITK_CALL(AOM_UIF_ask_value(IteamprintTag,"item_id",&VCORParrtnum));
							ITK_CALL(AOM_UIF_ask_value(IteamprintTag,"current_revision_id",&VCORParrtRev));
							tc_strdup(VCORParrtRev,&VCORParrtRevDup);
							//getting DML
							ifail = GRM_find_relation_type("CMHasSolutionItem" ,&part_Dml_rel_type_t);
							ifail = GRM_list_primary_objects_only(IteamprintTag,part_Dml_rel_type_t,&Part_task_c,&part_task_t);
							printf("\n DR: DML GET Part_task_c:%d", Part_task_c);fflush(stdout);
							for (r=0;r<Part_task_c;r++)
								{
									task_tag = part_task_t[r];
									if (task_tag != NULLTAG)
									{
										 ifail = TCTYPE_ask_object_type(task_tag,&objTypTag);
										 if(TCTYPE_ask_name2(objTypTag,&objType));
										 printf("\n  object_type is %s\n", objType);fflush(stdout);
										 printf("\n FOR VC --- T5_ChangeTaskRevision>>>>>>>> : [%s]\n",objType); fflush(stdout);	
										 if(tc_strcmp(objType,"T5_ChangeTaskRevision")==0)
										 {
										    ifail = GRM_find_relation_type ( "T5_DMLTaskRelation", &dml_tsk_rel_type ) ;
										    ifail = GRM_list_primary_objects_only ( task_tag, dml_tsk_rel_type, &Tskcount, &ERCDmlRevision ) ;//task to dml rev traversal
										    ercDml = ERCDmlRevision[0];										   
											ITK_CALL(AOM_UIF_ask_value(ercDml, "item_id" ,&DMLNo));
											ITK_CALL(AOM_UIF_ask_value(ercDml, "t5_rlstype" ,&Reltype));
											printf("\nDml_No>>>>>>>> : [%s]\n",DMLNo); fflush(stdout);
											if(AOM_ask_value_string(ercDml,"t5_TargetPlant",&TargetPlant)!=ITK_ok)PrintErrorStack();  //TargetPlant from DML
											printf(" \n\n TargetPlant: %s ",TargetPlant);fflush(stdout);
											if ((tc_strcmp(TargetPlant,"PCVBU")==0) ||(tc_strcmp(TargetPlant,"PCVBU")==0))  //PCVBU
											{
												tc_strcpy(TargetPlantBomLineCS,"t5_PunMakeBuyIndicator");
											}
											else if ((tc_strcmp(TargetPlant,"CARPLT")==0)||(tc_strcmp(TargetPlant,"CARPLANT")==0)) //CARPLANT
											{
												tc_strcpy(TargetPlantBomLineCS,"t5_CarMakeBuyIndicator");
											}
											else if ((tc_strcmp(TargetPlant,"DWD")==0) ||(tc_strcmp(TargetPlant,"DHARWAD")==0)) //DHARWAD
											{
												tc_strcpy(TargetPlantBomLineCS,"t5_DwdMakeBuyIndicator");
											}
											else if ((tc_strcmp(TargetPlant,"PNR")==0) ||(tc_strcmp(TargetPlant,"PANTNAGAR")==0))  //PANTNAGAR
											{
												tc_strcpy(TargetPlantBomLineCS,"t5_PnrMakeBuyIndicator");
											}
											else if ((tc_strcmp(TargetPlant,"AHD")==0)  ||(tc_strcmp(TargetPlant,"AHMEDABAD")==0))  //AHMEDABAD
											{
												tc_strcpy(TargetPlantBomLineCS,"t5_AhdMakeBuyIndicator");
											}
											else if ((tc_strcmp(TargetPlant,"JSR")==0)||(tc_strcmp(TargetPlant,"JAMSHEDPUR")==0)) //JAMSHEDPUR
											{
												tc_strcpy(TargetPlantBomLineCS,"t5_JsrMakeBuyIndicator");
											}
											else if ((tc_strcmp(TargetPlant,"LKO")==0) || (tc_strcmp(TargetPlant,"LUCKNOW")==0)) //LUCKNOW
											{
												tc_strcpy(TargetPlantBomLineCS,"t5_LkoMakeBuyIndicator");
											}
											else if ((tc_strcmp(TargetPlant,"JDL")==0) || (tc_strcmp(TargetPlant,"JSR DRIVELINES")==0)) //JSR DRIVELINES
											{
												tc_strcpy(TargetPlantBomLineCS,"t5_JdlMakeBuyIndicator");
											}
											else if (tc_strcmp(TargetPlant,"UV Plant")==0)//UV Plant
											{
												tc_strcpy(TargetPlantBomLineCS,"t5_PunUVMakeBuyIndicator");
											}
											if (tc_strlen(TargetPlantBomLineCS)==0)
											{
												TargetPlantBomLineCS =(char *) MEM_alloc(2);
												tc_strcpy(TargetPlantBomLineCS,"-");
											}

											printf(" TargetPlantBomLineCS:[%s]-----------------------------------",TargetPlantBomLineCS);fflush(stdout);
										}
								  }
							}
							ITK_CALL(AOM_UIF_ask_value(IteamprintTag,"object_type",&classtype));
							printf("VCORParrtnum is [%s] and VCORParrtnumRev is [%s] and classtype is [%s]",VCORParrtnum,IteamNumberone,classtype);fflush(stdout);
							ITK_CALL(BOM_window_set_closure_rule(windowVCO,close_tag, 0,rulename,rulevalue));
							ITK_CALL(BOM_set_window_config_rule(windowVCO, ruleone));
							ITK_CALL(BOM_set_window_pack_all (windowVCO, true));
							ITK_CALL(BOM_set_window_top_line(windowVCO, NULLTAG, IteamprintTag, NULLTAG, &top_lineVCO));
							PrintAttribuites(VCORParrtnum,VCORParrtRev,level,Qty,ReportVehicle,TargetPlantBomLineCS);
							findsparekitpart(VCORParrtnum,VCORParrtRevDup,ReportVehicle,TargetPlantBomLineCS);
						}

				}
			}
			BOMExpansionforcommon(top_lineVCO,ReportVehicle,TargetPlantBomLineCS);  //Function call	
			printf("\n***********************************Now report Genration is completed***************************\n");fflush(stdout);
			fprintf(ReportVehicle,"\n\n\n\n*****************************************END OF REPORT***********************************\n");fflush(ReportVehicle);
			if(SA_find_user2(UserID, &t_user));		
			if(t_user == NULLTAG)
			{
				printf("\n\n\t Error : USER ID TAG IS NULL -->\t USER ID NOT FOUND "); fflush(stdout);
			}
			printf("\n About to find Home folder of user with ID = %s",UserID);fflush(stdout);
			if(SA_ask_user_home_folder(t_user, &t_userHomeFl));
			if(t_userHomeFl != NULLTAG)
			{
				if(FL_ask_references(t_userHomeFl, FL_fsc_by_object ,&i_CountOfRef,&t_RefList));
				printf("\n\t Home Folder References count = %d ",i_CountOfRef);fflush(stdout);
				printf("\n\t -----Inside User [%s] Home Folder-------",UserID);
				
				for (k = 0 ; k < i_CountOfRef ; k++)
				{
					//ITK_CALL(TCTYPE_ask_object_type(t_RefList[k],&objTypTag));
					//ITK_CALL(TCTYPE_ask_name(objTypTag,ObjType));
					//if(WSOM_ask_name(t_RefList[k],&c_RefNAME));
					z= AOM_ask_value_string(t_RefList[k],"object_name",&c_RefNAME);
					
					if (z != ITK_ok)
						{
							EMH_ask_error_text(z, &cError);
							printf("\n\t Error (AOM_ask_value_value) = %s ", cError);
						}
					//printf("\n %d. %s",k,c_RefNAME);
					
					if(tc_strcmp(c_RefNAME,"SpareKit")!=0)
					{
						printf("\n\t ------------> Setting SpareKitFlag = 1 ");
						//t_GenT_FL =  t_RefList[k] ;
						SpareKitFlag = 1;	  // Will create folder named GenTPL					
					}
					else
					{
						z = AOM_UIF_ask_value(t_RefList[k],"owning_user",&c_OwningUser);
						printf("\n\t ------------> Setting SpareKitFlag = 2 ");
						t_SPKT_FL =  t_RefList[k] ;
						SpareKitFlag = 2;	
						break;
						//break;					
					}
					
				}
				
				printf("\n\t -----Out of For Loop ----------");
				
				if (SpareKitFlag == 1)
				{
						printf("\n\t Inside --> SpareKitFlag == 1");
						z= AOM_ask_value_string(t_SPKT_FL,"object_name",&c_FolderName);
						
						if(TCTYPE_find_type( "Folder", NULL, &t_FolderType) );
						if(t_FolderType != NULLTAG)
						printf("\n\t t_FolderType != NULLTAG");
						if(TCTYPE_construct_create_input( t_FolderType,&t_CreateIpFl)) ;
					
						z = AOM_UIF_set_value(t_CreateIpFl,"object_name","SpareKit");
						if (z != ITK_ok)
						{
							EMH_ask_error_text(z, &cError);
							printf("\n\t Error (AOM_UIF_set_value) = %s ", cError);
						}
						//TCTYPE_set_create_display_value( t_CreateIpFl, "object_name", 1,(const char**)Obj_name1) ;
						z = TCTYPE_create_object( t_CreateIpFl,&t_NewFL) ;
						if (z != ITK_ok)
						{
							EMH_ask_error_text(z, &cError);
							printf("\n\t Error (TCTYPE_create_object) = %s ", cError);
						}
						if(t_NewFL != NULLTAG)
						z = POM_set_owning_user(t_NewFL, t_user);
						z = AOM_save_without_extensions(t_NewFL) ;
						if (z != ITK_ok)
						{
							EMH_ask_error_text(z, &cError);
							printf("\n\t Error (AOM_save_without_extensions) = %s ", cError);
						}
						if(AOM_ask_value_string(t_NewFL,"object_name",&c_FL_name));
						
						if(FL_insert(t_userHomeFl,t_NewFL,999));
						if(AOM_save_without_extensions(t_userHomeFl));
						printf("\n Folder created named %s",c_FL_name);
						
						CreateDataset(VehicleFile,t_NewFL, FinalVehicleFile);

						
				}
				
				
				if (SpareKitFlag == 2)
				{
					z= AOM_ask_value_string(t_SPKT_FL,"object_name",&c_FolderName);
					printf("\n\t  Folder =[%s] FOUND user Home Folder and owning user = %s",c_FolderName,c_OwningUser);
					CreateDataset(VehicleFile,t_SPKT_FL ,FinalVehicleFile);
					
					
				}

				
				//MEM_free(t_RefList);
			}
			printf("\n***********************************File is added***************************\n");fflush(stdout);
			write2xml(Report,"</Top>\n");
			if (Report!=NULL)
			{
				fclose(Report);
			}
			if (ReportVehicle!=NULL)
			{
				fclose(ReportVehicle);
			}
		}
	}
	else
	{
		printf("\nLogin failed ....."); fflush(stdout);
	}
	freeHashTable();
	printf("\n---------freeHashTable Done----------");fflush(stdout);
	printf("\nExiting...\n"); fflush(stdout);
	ITK_CALL(POM_logout(false));
	return ITK_ok;
}