/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Part Duplicacy Reports  
*  File Name    :   tm_PartUsageRpt.c
*  Created on   :   Mar 11th, 2024
*  Usage        :   tm_PartUsageRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     11/03/2024                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#include <ics/ics2.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_PartDesc(char* PSrch,char* PRevSeqSrch)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	tag_t tpQryobj = NULLTAG;
	int np_entries = 2;
	int np_Qryobj_found = 0;
	tag_t* tpQryobj_results = NULLTAG;
	char* cItem_Desc = NULL;
	char* cItem_DescDup = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value: [%s]\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpQryobj));
    if(tpQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartEntries[2]  = {"Revision","ID"};
		char *PartValues[2]  = {PRevSeqSrch,PSrch};
		ITK_CALL(QRY_execute(tpQryobj, np_entries, PartEntries, PartValues, &np_Qryobj_found, &tpQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",np_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(np_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < np_Qryobj_found; m++)
			{
				tag_t rev_tags_found = NULLTAG;
				rev_tags_found = tpQryobj_results[m];
				if(rev_tags_found != NULLTAG)
				{	
					AOM_ask_value_string(tpQryobj_results[m],"object_desc",&cItem_Desc);
					printf("\n Item Description Before Dup & Trim:  <%s> \n",cItem_Desc);fflush(stdout);
					if(tc_strlen(cItem_Desc)>0)
					{
						tc_strdup(cItem_Desc,&cItem_DescDup);
					}
					else
					{
						tc_strdup("--",&cItem_DescDup);
						printf("\n Item Description Value is NULL");fflush(stdout);
					}
					trimwhitespace(cItem_DescDup);
					printf("\n Item Description Value After Dup & Trim: [%s]", cItem_DescDup);fflush(stdout);
					STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
					STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
					printf("\n Item Description Final Value: [%s]", cItem_DescDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&cItem_DescDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&cItem_DescDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&cItem_DescDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return cItem_DescDup;	
}

char* TC_PartLCDetails(char* PNSrch,char* PNRevSeqSrch)
{
	
	trimwhitespace(PNSrch);
	trimwhitespace(PNRevSeqSrch);
	tag_t tpLCQryobj = NULLTAG;
	int nplc_entries = 2;
	int nplc_Qryobj_found = 0;
	tag_t* tpLCQryobj_results = NULLTAG;
	char *Item_revseq = NULL;
	int n = 0;
	char* sRelStatus = NULL;
	char* sRelStatusDup = NULL;
	
	printf("\n Searched Part Number Value: [%s]\n", PNSrch);fflush(stdout);
	printf("\n Searched Part Revision & Sequence Value: [%s]\n", PNRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tpLCQryobj));
    if(tpLCQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		char *PartLCEntries[2]  = {"Revision","ID"};
		char *PartLCValues[2]  = {PNRevSeqSrch,PNSrch};
		ITK_CALL(QRY_execute(tpLCQryobj, nplc_entries, PartLCEntries, PartLCValues, &nplc_Qryobj_found, &tpLCQryobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",nplc_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(nplc_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (n = 0; n < nplc_Qryobj_found; n++)
			{
				tag_t LC_rev_tags_found = NULLTAG;
				LC_rev_tags_found = tpLCQryobj_results[n];
				if(LC_rev_tags_found != NULLTAG)
				{	
					AOM_UIF_ask_value(tpLCQryobj_results[n],"release_status_list",&sRelStatus);
					printf("\n Item Release Status Before Dup & Trim:  <%s> \n",sRelStatus);fflush(stdout);
					if(tc_strlen(sRelStatus)>0)
					{
						tc_strdup(sRelStatus,&sRelStatusDup);
					}
					else
					{
						tc_strdup("--",&sRelStatusDup);
						printf("\n Item Release Status Value is NULL");fflush(stdout);
					}
					trimwhitespace(sRelStatusDup);
					printf("\n Item Release Status After Dup & Trim: [%s]", sRelStatusDup);fflush(stdout);
					STRNG_replace_str(sRelStatusDup,","," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,";"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"\n"," ",&sRelStatusDup);
					STRNG_replace_str(sRelStatusDup,"'"," ",&sRelStatusDup);
					printf("\n Item Release Status Final Value: [%s]", sRelStatusDup);fflush(stdout);
				}
				else
				{
					tc_strdup("--",&sRelStatusDup);
					printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
				}
			}
		}
		else
		{
			tc_strdup("--",&sRelStatusDup);
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
		tc_strdup("--",&sRelStatusDup);
		printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	
	return sRelStatusDup;	
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* FP_OutputReport)
{
	    char* cItem_Level = NULL;
		char* cItem_Id = NULL;
		char* cItem_RevSeq = NULL;
		char* cItem_Rev = NULL;
		char* cItem_Seq = NULL;
		char* cArDrStatus = NULL;
		char* cArDrStatusDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		char* cItem_LCDetails = NULL;
		char* cParentName = NULL;
		char* cParentNameDup = NULL;
		int j =0;
		int iFail = ITK_ok;
		int iNumber_SubChild = 0;
		tag_t tChild = NULLTAG;
		tag_t* tSubChild = NULLTAG;
		char* cItem_Desc = NULL;
		char* cQuantity = NULL;
		char* cQuantityDup = NULL;
		
		for(j = 0; j < iSubSubNumber_Child; j++)
		{
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j],"bl_level_starting_0",&cItem_Level));
			trimwhitespace(cItem_Level);
			printf("\n Part Level Value After Trim: [%s]\n", cItem_Level);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cItem_Id));
			trimwhitespace(cItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", cItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cItem_RevSeq));
			trimwhitespace(cItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", cItem_RevSeq);fflush(stdout);
			
			cItem_Desc = TC_PartDesc(cItem_Id,cItem_RevSeq);
			printf("\n Part Description Value: [%s]", cItem_Desc);fflush(stdout);
			
			cItem_LCDetails = TC_PartLCDetails(cItem_Id,cItem_RevSeq);
			printf("\n Part LC Status Value After Dup & Trim: [%s]", cItem_LCDetails);fflush(stdout);
			
			cItem_Rev=strtok(cItem_RevSeq,";");
			cItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", cItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", cItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartStatus", &cArDrStatus));
			if(tc_strlen(cArDrStatus)>0)
			{
				tc_strdup(cArDrStatus,&cArDrStatusDup);
			}
			else
			{
				tc_strdup("--",&cArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(cArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", cArDrStatusDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
			{
				tc_strdup(cPartType,&cPartTypeDup);
			}
			else
			{
				tc_strdup("--",&cPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(cPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", cPartTypeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_formatted_parent_name", &cParentName));
			if(tc_strlen(cParentName)>0)
			{
				tc_strdup(cParentName,&cParentNameDup);
			}
			else
			{
				tc_strdup("--",&cParentNameDup);
				printf("\n Parent Part Value is NULL");fflush(stdout);
			}
			trimwhitespace(cParentNameDup);
			STRNG_replace_str(cParentNameDup,","," ",&cParentNameDup);
			STRNG_replace_str(cParentNameDup,";"," ",&cParentNameDup);
			STRNG_replace_str(cParentNameDup,"\n"," ",&cParentNameDup);
			STRNG_replace_str(cParentNameDup,"'"," ",&cParentNameDup);
			printf("\n Parent Part Value After Dup & Trim: [%s]", cParentNameDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_quantity", &cQuantity));
			if(tc_strlen(cQuantity)>0)
			{
				tc_strdup(cQuantity,&cQuantityDup);
			}
			else
			{
				tc_strdup("--",&cQuantityDup);
				printf("\n Part Quantity Value is NULL");fflush(stdout);
			}
			trimwhitespace(cQuantityDup);
			printf("\n Part Quantity Value After Dup & Trim: [%s]", cQuantityDup);fflush(stdout);
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nChild_Level: [%s]", cItem_Level);
			printf("\nChild_Level Part No: [%s]", cItem_Id);
			printf("\nChild_Level Part Revision: [%s]", cItem_Rev);
			printf("\nChild_Level Part Sequence: [%s]", cItem_Seq);
			printf("\nChild_Level Part Description: [%s]", cItem_Desc);
			printf("\nChild_Level Part AR/DR Status: [%s]", cArDrStatusDup);
			printf("\nChild_Level Part Type: [%s]", cPartTypeDup);
			printf("\nChild_Level Part LC Details: [%s]", cItem_LCDetails);
			printf("\nChild_Level Part Parent: [%s]", cParentNameDup);
			printf("\nChild_Level Part Quantity: [%s]", cQuantityDup);
			
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(cPartTypeDup)>0)
		    {
				if(tc_strcmp(cPartTypeDup,"Module")==0 || tc_strcmp(cPartTypeDup,"Assembly")==0 || tc_strcmp(cPartTypeDup,"Component")==0 || tc_strcmp(cPartTypeDup,"Group Id")==0)
				{
				   fprintf(FP_OutputReport,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",cItem_Level,cItem_Id,cItem_Rev,cItem_Seq,cItem_Desc,cArDrStatusDup,cPartTypeDup,cItem_LCDetails,cParentNameDup,cQuantityDup);fflush(FP_OutputReport);
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found: [%d]\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport);
			}
		}
	return iFail;
}

int TC_VehChild_Details(char* Vehicle,char* VehicleRS,FILE* VehRpt)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	int subrulefound = 0;
	tag_t* subclosurerule = NULL;
	tag_t sub_close_tag = NULLTAG;
	char** subrulename = NULL;
    char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	char* ctopSubLevel = NULL;
	char* ctopSubMAddress = NULL;
	char* ctopSubMAddressDup = NULL;
	char* ctopSubMAdd = NULL;
	char* ctopSubItem_Id = NULL;
	char* ctopSubArDrStatus = NULL;
	char* ctopSubArDrStatusDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	char* ctopModAggr = NULL;
	char* ctopLowerVal = NULL;
	char* ctopSubItem_RevSeq = NULL;
	char* ctopSubItem_Rev = NULL;
	char* ctopSubItem_Seq = NULL;
	char* ctopSubItem_Desc = NULL;
	char* ctopSubParentName = NULL;
	char* ctopSubParentNameDup = NULL;
	char* ctopSubQuantity = NULL;
	char* ctopSubQuantityDup = NULL;
	char* ctopSubItem_LCDetails = NULL;
	char* ctopSubItem_Level = NULL;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(Vehicle, &top_item));
	printf("\n API[ITEM_find_item] Success..!!\n");fflush(stdout);
	tag_t topchildrev = NULLTAG;
	//ITK_CALL(ITEM_find_rev(top_child_item_id, child_item_revision_id, &Childrev));
	ITK_CALL(ITEM_find_revision(top_item, VehicleRS, &topchildrev));
	printf("\n API[ITEM_find_revision] Success..!!\n");fflush(stdout);
	if(topchildrev != NULLTAG)
    {
			
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n API[BOM_create_window] Success..!!\n");fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n API[CFM_find] Revision Rule Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
        printf("\n API[BOM_set_window_config_rule] Success..!!\n");fflush(stdout);		
		ITK_CALL(PIE_find_closure_rules("BOMViewClosureRuleERC",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n API[PIE_find_closure_rules] Closure Rule Find Success..!!\n");fflush(stdout);
		printf("\n No of Rule Found: [%d]\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(top_Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n API[BOM_window_set_closure_rule] Closure Rule Set Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n API[BOM_set_window_pack_all] BOM Window Pack Success..!!\n");fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n API[BOM_set_window_top_line] Top Line Set Success..!!\n");fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child,"bl_level_starting_0",&ctopSubItem_Level));
			trimwhitespace(ctopSubItem_Level);
			printf("\n Part Level Value After Trim: [%s]\n", ctopSubItem_Level);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			trimwhitespace(ctopSubItem_Id);
			printf("\n Part No Value After Trim: [%s]\n", ctopSubItem_Id);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubItem_RevSeq));
			trimwhitespace(ctopSubItem_RevSeq);
			printf("\n Part Rev-Seq Value After Trim: [%s]\n", ctopSubItem_RevSeq);fflush(stdout);
			
			ctopSubItem_Desc = TC_PartDesc(ctopSubItem_Id,ctopSubItem_RevSeq);
			printf("\n Part Description Value: [%s]", ctopSubItem_Desc);fflush(stdout);
			
			ctopSubItem_LCDetails = TC_PartLCDetails(ctopSubItem_Id,ctopSubItem_RevSeq);
			printf("\n Part LC Status Value After Dup & Trim: [%s]", ctopSubItem_LCDetails);fflush(stdout);
			
			ctopSubItem_Rev=strtok(ctopSubItem_RevSeq,";");
			ctopSubItem_Seq=strtok(NULL,";");
			printf("\n Part Rev Value After Token: [%s]\n", ctopSubItem_Rev);fflush(stdout);
			printf("\n Part Seq Value After Token: [%s]\n", ctopSubItem_Seq);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartStatus", &ctopSubArDrStatus));
			if(tc_strlen(ctopSubArDrStatus)>0)
			{
				tc_strdup(ctopSubArDrStatus,&ctopSubArDrStatusDup);
			}
			else
			{
				tc_strdup("--",&ctopSubArDrStatusDup);
				printf("\n Part AR/DR Status Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubArDrStatusDup);
			printf("\n Part AR/DR Status Value After Dup & Trim: [%s]\n", ctopSubArDrStatusDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("--",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim: [%s]", ctopSubPartTypeDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_formatted_parent_name", &ctopSubParentName));
			if(tc_strlen(ctopSubParentName)>0)
			{
				tc_strdup(ctopSubParentName,&ctopSubParentNameDup);
			}
			else
			{
				tc_strdup("--",&ctopSubParentNameDup);
				printf("\n Parent Part Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubParentNameDup);
			STRNG_replace_str(ctopSubParentNameDup,","," ",&ctopSubParentNameDup);
			STRNG_replace_str(ctopSubParentNameDup,";"," ",&ctopSubParentNameDup);
			STRNG_replace_str(ctopSubParentNameDup,"\n"," ",&ctopSubParentNameDup);
			STRNG_replace_str(ctopSubParentNameDup,"'"," ",&ctopSubParentNameDup);
			printf("\n Parent Part Value After Dup & Trim: [%s]", ctopSubParentNameDup);fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_quantity", &ctopSubQuantity));
			if(tc_strlen(ctopSubQuantity)>0)
			{
				tc_strdup(ctopSubQuantity,&ctopSubQuantityDup);
			}
			else
			{
				tc_strdup("--",&ctopSubQuantityDup);
				printf("\n Part Quantity Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubQuantityDup);
			printf("\n Part Quantity Value After Dup & Trim: [%s]", ctopSubQuantityDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nTop_Level: [%s]", ctopSubItem_Level);
			printf("\nTop_Level Part No: [%s]", ctopSubItem_Id);
			printf("\nTop_Level Rev: [%s]", ctopSubItem_Rev);
			printf("\nTop_Level Seq: [%s]", ctopSubItem_Seq);
			printf("\nTop_Level Description: [%s]", ctopSubItem_Desc);
			printf("\nTop_Level AR/DR: [%s]", ctopSubArDrStatusDup);
			printf("\nTop_Level Part Type: [%s]", ctopSubPartTypeDup);
			printf("\nTop_Level LC State: [%s]", ctopSubItem_LCDetails);
			printf("\nTop_Level Parent: [%s]", ctopSubParentNameDup);
			printf("\nTop_Level QTY: [%s]", ctopSubQuantityDup);
			printf("\n-------------------------------------------------------------------------\n");
			if(tc_strlen(ctopSubPartTypeDup)>0)
		    {
				if(tc_strcmp(ctopSubPartTypeDup,"Module")==0 || tc_strcmp(ctopSubPartTypeDup,"Assembly")==0 || tc_strcmp(ctopSubPartTypeDup,"Component")==0 || tc_strcmp(ctopSubPartTypeDup,"Group Id")==0)
				{
				   fprintf(VehRpt,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%s^\n",ctopSubItem_Level,ctopSubItem_Id,ctopSubItem_Rev,ctopSubItem_Seq,ctopSubItem_Desc,ctopSubArDrStatusDup,ctopSubPartTypeDup,ctopSubItem_LCDetails,ctopSubParentNameDup,ctopSubQuantityDup);fflush(VehRpt);
				}
			}
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n API[BOM_line_ask_all_child_lines] Child Find Success..!!\n");fflush(stdout);
			printf("\n No of Children Found: [%d]\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! C H I L D   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, VehRpt);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n API[BOM_close_window] BOM Window Close Success..!!\n");fflush(stdout);
	}
	return iFail;	
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	int i = 0;
	char *RptFile = (char *) malloc(100*sizeof(char));
	char *RptFile1 = (char *) malloc(100*sizeof(char));
	char *RptFile2 = (char *) malloc(100*sizeof(char));
	FILE *ExpOutput_file = NULL;
	char *item_revseq_str = NULL;
	char *item_revseq_strDup = NULL;
	char *item_revseq_strdup = (char *) malloc(20*sizeof(char));
	tag_t DesRev_tag = NULLTAG;
	char* user_id_str = NULL;
	char* user_id_strDup = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	item_id_str = ITK_ask_cli_argument("-Part=");
	item_rev_str = ITK_ask_cli_argument("-Rev=");
	item_seq_str = ITK_ask_cli_argument("-Seq=");
	user_id_str = ITK_ask_cli_argument("-User=");
	
	trimwhitespace(item_id_str);
	trimwhitespace(item_rev_str);
	trimwhitespace(item_seq_str);
	trimwhitespace(user_id_str);
	if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
	if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
	if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
	if(user_id_str!=NULL)tc_strdup(user_id_str,&user_id_strDup);
	printf(" [1]: Input Part No(item_id_strDup): [%s]\n",item_id_strDup);
	printf(" [2]: Input Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
	printf(" [3]: Input Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
	printf(" [4]: Input User ID(user_id_strDup): [%s]\n",user_id_strDup);
	
	tc_strcpy(item_revseq_strdup,item_rev_strDup);
	tc_strcat(item_revseq_strdup,";");
	tc_strcat(item_revseq_strdup,item_seq_strDup);
	printf(" Final: Part_Rev_Seq Value(item_revseq_strdup): [%s]\n",item_revseq_strdup);
	
	printf("\n Generating Final Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"Part_Consumption_Rpt");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Final Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Final Report File Generated..!!");fflush(stdout);
	
	printf("\n Generating Part Expansion Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile1,"Part_Expansion_Rpt");
	tc_strcat(RptFile1,"_");
	tc_strcat(RptFile1,GenDate);
	tc_strcat(RptFile1,".txt");
	printf("\n Part Expansion Report File Name: [%s]", RptFile1);fflush(stdout);
	printf("\n Part Expansion Report File Generated..!!");fflush(stdout);
	
	printf("\n Generating Intermediate Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile2,"Part_Intermediate_Rpt");
	tc_strcat(RptFile2,"_");
	tc_strcat(RptFile2,GenDate);
	tc_strcat(RptFile2,".txt");
	printf("\n Intermediate Report File Name: [%s]", RptFile2);fflush(stdout);
	printf("\n Intermediate Report File Generated..!!");fflush(stdout);
	
	printf("\n Finding Query[DesignRevision Sequence]..!!\n");fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
    if(tItemobj != NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully..!!\n");fflush(stdout);
		char *cEntries[2]  = {"Revision","ID"};
		char *cValues[2]  = {item_revseq_strdup,item_id_strDup};
		//char *cValues[2]  = {"A;2","51780353R"};
		ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n  No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				DesRev_tag = titemobj_results[i];
				ExpOutput_file = fopen(RptFile1, "w"); 
				if(ExpOutput_file == NULL)
				{
					printf("\n Unable to Create Part Expansion[99 Level] Report File: --------> [%s]",ExpOutput_file);fflush(stdout);
					return 0;
				}
				printf("\n Function1: Vehicle Child Details Find Start");fflush(stdout);
				TC_VehChild_Details(item_id_strDup,item_revseq_strdup,ExpOutput_file);
			    printf("\n Function1: Vehicle Child Details Find End\n");fflush(stdout);
				fclose(ExpOutput_file);
			}
		}
		else
        {
			printf(" Revision Found Zero[0] on DesignRevision Sequence Query..!!\n");fflush(stdout);
		}
	}
	else
    {
		printf(" DesignRevision Sequence Query Tag Not Found..!!\n");fflush(stdout);
    }
	
	printf(" Final Report Preparation Started..!!\n");fflush(stdout);
	FILE* fpIntermed = fopen(RptFile2, "w");
    if(fpIntermed == NULL)
    {
        printf(" Can't Open Intermediate Report File: --------> [%s]",fpIntermed);fflush(stdout);
        return 0;
    }
    FILE* fpinp = fopen(RptFile1, "r");
    if(fpinp == NULL)
    {
        printf(" Can't Open Part Expansion Report File: --------> [%s]",fpinp);fflush(stdout);
        return 0;
    }
    else 
    { 
        char buffer1[1024];
        while(fgets(buffer1,1024,fpinp)) 
        {
            char* ItemLvl = strtok(buffer1, "^");
			char* ItemNo = strtok(NULL, "^");
            char* ItemRev = strtok(NULL, "^");
            char* ItemSeq = strtok(NULL, "^");
			char* ItemDesc = strtok(NULL, "^");
			char* ItemArDr = strtok(NULL, "^");
            char* ItemType = strtok(NULL, "^");
			char* ItemLC = strtok(NULL, "^");
			char* ItemParent = strtok(NULL, "^");
            char* ItemQty = strtok(NULL, "^");
            int ItemQtyNew = atoi(ItemQty);
			/* printf("Item Level: [%s] \n", ItemLvl);fflush(stdout);
            printf("Item No: [%s] \n", ItemNo);fflush(stdout);
            printf("Item Rev: [%s] \n", ItemRev);fflush(stdout);
            printf("Item Seq: [%s] \n", ItemSeq);fflush(stdout);
			printf("Item Desc: [%s] \n", ItemDesc);fflush(stdout);
			printf("Item AR/DR: [%s] \n", ItemArDr);fflush(stdout);
			printf("Item Type: [%s] \n", ItemType);fflush(stdout);
			printf("Item LC: [%s] \n",  ItemLC);fflush(stdout);
            printf("Item Parent: [%s] \n", ItemParent);fflush(stdout);
            printf("Item Qty: [%d] \n", ItemQtyNew);fflush(stdout); */
            if(ItemQtyNew == 0)
            {
                fprintf(fpIntermed,"%s^%s^%s^%s^%s^%s^%s^%s^%s^%d^\n", ItemLvl, ItemNo, ItemRev, ItemSeq, ItemDesc, ItemArDr, ItemType, ItemLC, ItemParent, ItemQtyNew);fflush(fpIntermed);
            }
        }
    }
    fclose(fpIntermed);
    fclose(fpinp);
	
	FILE* fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, [CONSUMPTION QUANTITY DETAILS REPORT] ,,,,");fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, Part_No: [%s]",item_id_strDup);fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, Part_Rev: [%s]",item_rev_strDup);fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, Part_Seq: [%s]",item_seq_strDup);fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, Revision_Rule: [%s]","ERC release and above");fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, Closure_Rule: [%s]","BOMViewClosureRuleERC");fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n ,,,, Report_TimeStamp: [%s]",GenDate);fflush(fpOutput_file);
	fprintf(fpOutput_file,"\n @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(fpOutput_file);
    fprintf(fpOutput_file,"LEVEL, PART_NO, PART_REV, PART_SEQ, PART_DESCRIPTION, PART_AR/DR, PART_TYPE, LC_STATE, PARENT, QTY\n");fflush(fpOutput_file);
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
    FILE* fpFinalIntermed = fopen(RptFile2, "r");
    if(fpFinalIntermed == NULL)
    {
        printf("\n Unable to Open Final Intermediate File: --------> [%s]",RptFile2);fflush(stdout);
        return 0;
    }
    else 
    { 
        char buffer2[1024];
        while(fgets(buffer2,1024,fpFinalIntermed)) 
        {
            char* FIItemLvl = strtok(buffer2, "^");
			char* FIItemNo = strtok(NULL, "^");
            char* FIItemRev = strtok(NULL, "^");
            char* FIItemSeq = strtok(NULL, "^");
			char* FIItemDesc = strtok(NULL, "^");
			char* FIItemArDr = strtok(NULL, "^");
            char* FIItemType = strtok(NULL, "^");
			char* FIItemLC = strtok(NULL, "^");
			char* FIItemParent = strtok(NULL, "^");
            char* FIItemQty = strtok(NULL, "^");
            int FIItemQtyNew = atoi(FIItemQty);
			/* printf("Intermediate Item Level: [%s] \n", FIItemLvl);fflush(stdout);
            printf("Intermediate Item No: [%s] \n", FIItemNo);fflush(stdout);
            printf("Intermediate Item Rev: [%s] \n", FIItemRev);fflush(stdout);
            printf("Intermediate Item Seq: [%s] \n", FIItemSeq);fflush(stdout);
			printf("Intermediate Item Desc: [%s] \n", FIItemDesc);fflush(stdout);
			printf("Intermediate Item AR/DR: [%s] \n", FIItemArDr);fflush(stdout);
			printf("Intermediate Item Type: [%s] \n", FIItemType);fflush(stdout);
			printf("Intermediate Item LC: [%s] \n",  FIItemLC);fflush(stdout);
            printf("Intermediate Item Parent: [%s] \n", FIItemParent);fflush(stdout);
            printf("Intermediate Item Qty: [%d] \n", FIItemQtyNew);fflush(stdout); */
            fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d\n", FIItemLvl, FIItemNo, FIItemRev, FIItemSeq, FIItemDesc, FIItemArDr, FIItemType, FIItemLC, FIItemParent, FIItemQtyNew);fflush(fpOutput_file);
            FILE* fpinp1 = fopen(RptFile1, "r");
            if(fpinp1 == NULL)
			{
				printf("\n Can't Open Part Expansion Report File: --------> [%s]",RptFile1);fflush(stdout);
				return 0;
			}
            else 
            { 
                char buffer3[1024];
                while(fgets(buffer3,1024,fpinp1)) 
                {
                   char* FItemLvl = strtok(buffer3, "^");
				   char* FItemNo = strtok(NULL, "^");
				   char* FItemRev = strtok(NULL, "^");
				   char* FItemSeq = strtok(NULL, "^");
				   char* FItemDesc = strtok(NULL, "^");
				   char* FItemArDr = strtok(NULL, "^");
				   char* FItemType = strtok(NULL, "^");
				   char* FItemLC = strtok(NULL, "^");
				   char* FItemParent = strtok(NULL, "^");
				   char* FItemQty = strtok(NULL, "^");
				   int FItemQtyNew = atoi(FItemQty);
				   /* printf("Expansion Item Level: [%s] \n", FItemLvl);fflush(stdout);
				   printf("Expansion Item No: [%s] \n", FItemNo);fflush(stdout);
				   printf("Expansion Item Rev: [%s] \n", FItemRev);fflush(stdout);
				   printf("Expansion Item Seq: [%s] \n", FItemSeq);fflush(stdout);
				   printf("Expansion Item Desc: [%s] \n", FItemDesc);fflush(stdout);
				   printf("Expansion Item AR/DR: [%s] \n", FItemArDr);fflush(stdout);
				   printf("Expansion Item Type: [%s] \n", FItemType);fflush(stdout);
				   printf("Expansion Item LC: [%s] \n",  FItemLC);fflush(stdout);
				   printf("Expansion Item Parent: [%s] \n", FItemParent);fflush(stdout);
				   printf("Expansion Item Qty: [%d] \n", FItemQtyNew);fflush(stdout); */
                   if(tc_strcmp(FIItemNo,FItemNo) == 0)
                   {
                     if(FItemQtyNew > 0)
                     {
                        fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%d\n", FItemLvl, FItemNo, FItemRev, FItemSeq, FItemDesc, FItemArDr, FItemType, FItemLC, FItemParent, FItemQtyNew);fflush(fpOutput_file);
                     }
                   }
                }
            }
            fclose(fpinp1);
        }
    }
    fclose(fpFinalIntermed);
	fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
    fclose(fpOutput_file); 
	printf(" Final Report Preparation Ended..!!\n");fflush(stdout);

    printf("\n Report File Attach To Users Home Folder Start..!!\n");fflush(stdout);
	char *Filename = NULL;
	char *FileLoc = NULL;
	char *dataSetName = NULL;
	IMF_file_t	fileDescriptor;
	tag_t	datasettype = NULLTAG;
	tag_t	tool 		= NULLTAG;
	tag_t	Newdataset 	= NULLTAG;
	tag_t	filetag 	= NULLTAG;
	tag_t tUser = NULLTAG;
	tag_t tHomeFolder = NULLTAG;
	
    dataSetName = (char *) MEM_alloc( 70 * sizeof(char) );
	tc_strcpy(dataSetName,"PART-CONSUMPTION-RPT-");
	tc_strcat(dataSetName,GenDate);
	printf(" Dataset Name: [%s]\n", dataSetName);fflush(stdout);
	
	Filename = (char *) MEM_alloc( 50 * sizeof(char) );
	FileLoc = (char *) MEM_alloc( 100 * sizeof(char) );
	tc_strcpy(Filename,RptFile);
	printf(" File Name: [%s]\n", Filename);fflush(stdout);

	tc_strcpy(FileLoc,"/user/cvprod/sourav/Part_Usage_Report/");
	tc_strcat(FileLoc,Filename);
	printf(" File Location: [%s]\n", FileLoc);fflush(stdout);

	ITK_CALL(AE_find_datasettype2("MSExcel",&datasettype));
	ITK_CALL(AE_find_tool2("MSExcel", &tool));
	ITK_CALL(AE_create_dataset_with_id(datasettype,dataSetName,"",NULL,NULL,&Newdataset));
	ITK_CALL(AE_set_dataset_tool(Newdataset,tool));
	ITK_CALL(AE_set_dataset_format2(Newdataset,"BINARY_REF"));
	ITK_CALL(AOM_save(Newdataset));	
	ITK_CALL(IMF_fmsfile_import(FileLoc,Filename,SS_BINARY,&filetag,&fileDescriptor));
	if(filetag == NULLTAG)
	{
		printf(" File Tag Not Found..!!\n");fflush(stdout);
	}
	ITK_CALL(AOM_refresh(Newdataset,TRUE));
	ITK_CALL(AE_add_dataset_named_ref2(Newdataset, "excel", AE_PART_OF, filetag));
	ITK_CALL(AOM_save(Newdataset));
	ITK_CALL(AOM_refresh(Newdataset,FALSE));
	
	ITK_CALL(SA_find_user2(user_id_strDup,&tUser));
	ITK_CALL(SA_ask_user_home_folder(tUser,&tHomeFolder));
	ITK_CALL(AOM_lock(tHomeFolder));
	ITK_CALL(FL_insert(tHomeFolder,Newdataset,999));
    ITK_CALL(AOM_save(tHomeFolder));
	ITK_CALL(AOM_unlock(tHomeFolder));
	printf("\n Report File Attach To Users Home Folder End..!!\n");fflush(stdout);
		
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_PartUsageRpt.c
* // ./linkitk -o tm_PartUsageRpt tm_PartUsageRpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Usage_Report/tm_PartUsageRpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Usage_Report/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Usage_Report/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Part_Usage_Report/SendEmail.sh .
* // ./tm_PartUsageRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -Part="51780353R" -Rev=A -Seq=2 -User="skk919708"
* // ./tm_PartUsageRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Part="51780353R" -Rev=A -Seq=2 -User="souravk.ttl"
*
***************************************************************************/