/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   Test Request
*  Description  :   Query Test Request & Return It's Details As a Response via Web-Service 
*  File Name    :   tm_TestReqDetails.c
*  Created on   :   Dec 20th, 2023
*  Usage        :   tm_TestReqDetails
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     20/12/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	tag_t tItemobj = NULLTAG;
	int n_entries = 3;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *From_date_str = NULL;
	char *To_date_str = NULL;
	char *Rq_domain_str = NULL;
	char *From_date_strDup = NULL;
	char *To_date_strDup = NULL;
	char *Rq_domain_strDup = NULL;
	int i = 0;
	char *From_date_final_strDup = (char *) malloc(400*sizeof(char));
	char *To_date_final_strDup = (char *) malloc(400*sizeof(char));
	char *tr_itemid = NULL;
	char *tr_itemidDup = NULL;
	tag_t tr_tag = NULLTAG;
	tag_t tr_rev_tag = NULLTAG;
	char *task_template = NULL;

    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	From_date_str = ITK_ask_cli_argument("-FD=");
	To_date_str = ITK_ask_cli_argument("-TD=");
	Rq_domain_str = ITK_ask_cli_argument("-RD=");
	
	trimwhitespace(From_date_str);
	trimwhitespace(To_date_str);
	trimwhitespace(Rq_domain_str);
	if(From_date_str!=NULL)tc_strdup(From_date_str,&From_date_strDup);
	if(To_date_str!=NULL)tc_strdup(To_date_str,&To_date_strDup);
	if(Rq_domain_str!=NULL)tc_strdup(Rq_domain_str,&Rq_domain_strDup);
	printf(" [1]: Input From Date(From_date_strDup): [%s]\n",From_date_strDup);
	printf(" [2]: Input To Date(To_date_strDup): [%s]\n",To_date_strDup);
	printf(" [3]: Input Request Domain(Rq_domain_strDup): [%s]\n",Rq_domain_strDup);
	
	tc_strcpy(From_date_final_strDup,From_date_strDup);
	tc_strcat(From_date_final_strDup," 00:00");
	printf(" Final: From Date Value(From_date_final_strDup): [%s]\n",From_date_final_strDup);
	
	tc_strcpy(To_date_final_strDup,To_date_strDup);
	tc_strcat(To_date_final_strDup," 00:00");
	printf(" Final: To Date Value(To_date_final_strDup): [%s]\n",To_date_final_strDup);
	
	ITK_CALL(QRY_find2("Test Request Query",&tItemobj));
    if(tItemobj != NULLTAG)
    {
		printf("\n Test Request Query Found Successfully..!!\n");fflush(stdout);
		char *cEntries[3]  = {"Creation Date From","Creation Date To","Request Domain"};
		char *cValues[3]  = {From_date_final_strDup,To_date_final_strDup,Rq_domain_strDup};
		//char *cValues[3]  = {"20-Dec-2022 10:22","20-Dec-2023 10:22","Testing-Indoor"};
	    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Test-Request Found: [%d]\n",n_itemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_itemobj_found > 0)
		{
			printf(" Test Request Query Found..!!\n");fflush(stdout);
			for(i = 0; i < n_itemobj_found; i++)
			{
				ITK_CALL(AOM_ask_value_string(titemobj_results[i],"item_id",&tr_itemid));
				if(tc_strlen(tr_itemid)>0)
				{
					tc_strdup(tr_itemid,&tr_itemidDup);
				}
				else
				{
					tc_strdup("--",&tr_itemidDup);
					printf("\n Test Request No is NULL..!!");fflush(stdout);
				}
				if(tc_strlen(tr_itemidDup)>0)
				{
					printf("\n Test Request No Found..!!");fflush(stdout);
					ITK_CALL(ITEM_find_item(tr_itemidDup, &tr_tag));
                    ITK_CALL(ITEM_find_revision(tr_tag,"A;1",&tr_rev_tag)) ;
                    if(tr_rev_tag  != NULLTAG)
		            {
						char *tr_bunit = NULL;
						char *tr_bunitDup = NULL;
						char *tr_wbs = NULL;
						char *tr_wbsDup = NULL;
						char *tr_wbsdesc = NULL;
						char *tr_wbsdescDup = NULL;
						char *tr_aggr = NULL;
						char *tr_aggrDup = NULL;
						char *tr_descomp = NULL;
						char *tr_descompDup = NULL;
						char *tr_projcode = NULL;
						char *tr_projcodeDup = NULL;
						char *tr_program = NULL;
						char *tr_programDup = NULL;
						char *tr_subgrp = NULL;
						char *tr_subgrpDup = NULL;
						char *tr_testagenloc = NULL;
						char *tr_testagenlocDup = NULL;
						ITK_CALL(AOM_UIF_ask_value(tr_rev_tag,"fnd0ActuatedInteractiveTsks",&task_template));
						printf("\n Task Template: [%s]\n",task_template);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_BU",&tr_bunit));
						if(tc_strlen(tr_bunit)>0)
						{
							tc_strdup(tr_bunit,&tr_bunitDup);
						}
						else
						{
							tc_strdup("--",&tr_bunitDup);
							printf("\n Business Unit is NULL..!!\n");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_WBS",&tr_wbs));
						if(tc_strlen(tr_wbs)>0)
						{
							tc_strdup(tr_wbs,&tr_wbsDup);
						}
						else
						{
							tc_strdup("--",&tr_wbsDup);
							printf("\n WBS is NULL..!!\n");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_WbsDesc",&tr_wbsdesc));
						if(tc_strlen(tr_wbsdesc)>0)
						{
							tc_strdup(tr_wbsdesc,&tr_wbsdescDup);
						}
						else
						{
							tc_strdup("--",&tr_wbsdescDup);
							printf("\n WBS Description is NULL..!!\n");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqAggregate",&tr_aggr));
						if(tc_strlen(tr_aggr)>0)
						{
							tc_strdup(tr_aggr,&tr_aggrDup);
						}
						else
						{
							tc_strdup("--",&tr_aggrDup);
							printf("\n Aggregates is NULL..!!\n");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_DescComp",&tr_descomp));
						if(tc_strlen(tr_descomp)>0)
						{
							tc_strdup(tr_descomp,&tr_descompDup);
						}
						else
						{
							tc_strdup("--",&tr_descompDup);
							printf("\n Description Of Component is NULL..!!\n");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqProjCode",&tr_projcode));
						if(tc_strlen(tr_projcode)>0)
						{
							tc_strdup(tr_projcode,&tr_projcodeDup);
						}
						else
						{
							tc_strdup("--",&tr_projcodeDup);
							printf("\n Project Code is NULL..!!\n");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqProjDes",&tr_projdes));
						if(tc_strlen(tr_projdes)>0)
						{
							tc_strdup(tr_projdes,&tr_projdesDup);
						}
						else
						{
							tc_strdup("--",&tr_projdesDup);
							printf("\n Project Description is NULL..!!\n");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_RqProgram",&tr_program));
						if(tc_strlen(tr_program)>0)
						{
							tc_strdup(tr_program,&tr_programDup);
						}
						else
						{
							tc_strdup("--",&tr_programDup);
							printf("\n Program is NULL..!!\n");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_testSubGrp",&tr_subgrp));
						if(tc_strlen(tr_subgrp)>0)
						{
							tc_strdup(tr_subgrp,&tr_subgrpDup);
						}
						else
						{
							tc_strdup("--",&tr_subgrpDup);
							printf("\n Testing Sub-Group is NULL..!!\n");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(tr_rev_tag,"t5_Testing_Agency_Loc",&tr_testagenloc));
						if(tc_strlen(tr_testagenloc)>0)
						{
							tc_strdup(tr_testagenloc,&tr_testagenlocDup);
						}
						else
						{
							tc_strdup("--",&tr_testagenlocDup);
							printf("\n Testing Agency Location is NULL..!!\n");fflush(stdout);
						}
					}
					else
				    {
					   printf("\n Test Request Revision Tag is NULL..!!\n");fflush(stdout);
				    }
				}
				else
				{
					printf("\n Test Request No is NULL..!!\n");fflush(stdout);
				}
				printf(" Test Request_No(tr_itemidDup): [%s]\n",tr_itemidDup);
			}
		}
		else
		{
			printf("\n Test Request Not Found..!!");fflush(stdout);
		}
	}
	else
	{
		printf("\n Test Request Query Tag is NULL..!!");fflush(stdout);
	}
	
    if (titemobj_results)
	{
	  MEM_free(titemobj_results);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_TestReqDetails.c
* // ./linkitk -o tm_TestReqDetails tm_TestReqDetails.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_TestRequest/tm_TestReqDetails .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_TestRequest/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/Webservice_TestRequest/usage.txt .
* // ./tm_TestReqDetails -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -FD="20-Dec-2022" -TD="20-Dec-2023" -RD="tsi"
* // ./tm_TestReqDetails -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -FD="20-Dec-2022" -TD="20-Dec-2023" -RD="tsi"
*
***************************************************************************/