/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   DML
*  Description  :   Transfer ERC DML Released Part To CATIA V6
*  File Name    :   tm_dml_part_transfer.c
*  Created on   :   July 16th, 2023
*  Usage        :   tm_dml_part_transfer
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     16/07/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 910001
#define CALLAPI(expr)ITK_CALL(iFail = expr); if(iFail != ITK_ok) {  return iFail;}


int ITK_CALL(int IFail)
{
	char* cError = NULL;
	int iFail = 0;
	    if(iFail!=ITK_ok)
		{
		  EMH_ask_error_text(iFail, &cError);
		  printf("\n Error is : %s", cError);
		  exit(0);
		}

		return iFail;
}

char *trimwhitespace(char *str)
{
  char *end;

  while(isspace((unsigned char)*str)) str++;

  if(*str == 0)
    return str;

  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  end[1] = '\0';

  return str;
}

void trimLeading(char * str)
{
    int index, i, j;
    index = 0;
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }
    if(index != 0)
    {
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; 
    }
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

void print_requirement()
{
	printf(
        "\n Under Mentioned Arguments Are Mandatory"
        " USAGE:\n"
        " -u=<Teamcenter UserID> (Required)\n"
        " -p=<Teamcenter Password> (Required)\n"
        " -g=<Teamcenter Group> (Required)\n"
        " -dml=<DML Number> (Required)\n"
        );	
}

char* TC_PartRevSeqFormat(char* PartRS)
{
	char *FRevSeq = (char *) malloc(400*sizeof(char));
	char* Rev_Str = NULL;
	char* Seq_Str = NULL;
	char* Rev_StrDup = NULL;
	char* Seq_StrDup = NULL;
	Rev_Str=strtok(PartRS,";");
	Seq_Str=strtok(NULL,";");
	printf("\n Revision String --------> %s", Rev_Str);fflush(stdout);
	printf("\n Sequence String --------> %s", Seq_Str);fflush(stdout);
	/* if(tc_strlen(PartRS)>0)
	{
		tc_strdup(Rev_Str,&Rev_StrDup);
		tc_strdup(Seq_Str,&Seq_StrDup);
	}
	else
	{
		tc_strdup("",&Rev_StrDup);
		tc_strdup("",&Seq_StrDup);
		printf("\n Part Rev-Seq Value is NULL \n");fflush(stdout);
	}
	trimwhitespace(Rev_StrDup);
	trimwhitespace(Seq_StrDup); */
	//printf("\n Revision Value After Dup & Trim --------> %s\n", Rev_StrDup);fflush(stdout);
	//printf("\n Sequence Value After Dup & Trim --------> %s\n", Seq_StrDup);fflush(stdout);
	tc_strcpy(FRevSeq,Rev_Str);
	tc_strcat(FRevSeq,".");
	tc_strcat(FRevSeq,Seq_Str);
	printf("\n Final Revision & Sequence Value --------> %s", FRevSeq);fflush(stdout);
	return FRevSeq;
}

int Part_Release_Status(char* PSrch,char* PRevSeqSrch,FILE* RelStatRpt)
{
	
	trimwhitespace(PSrch);
	trimwhitespace(PRevSeqSrch);
	int iFail = 0;
	tag_t tQryobj = NULLTAG;
	int n_entries = 1;
	int n_Qryobj_found = 0;
	tag_t* tQryobj_results = NULLTAG;
	char* responseString1 = NULL;
	responseString1=(char *)MEM_alloc(200);
	char* responseString2 = NULL;
	responseString2=(char *)MEM_alloc(200);
	char* responseString3 = NULL;
	responseString3=(char *)MEM_alloc(200);
	char* responseString4 = NULL;
	responseString4=(char *)MEM_alloc(200);
	tag_t DesRev_tag = NULLTAG;
	char *Item_revseq = NULL;
	int m = 0;
	printf("\n Searched Part Number Value After Trim --------> %s\n", PSrch);fflush(stdout);
	printf("\n Searched Part Revision and Sequence Value After Trim --------> %s\n", PRevSeqSrch);fflush(stdout);
    ITK_CALL(QRY_find2("DesignRevision Sequence",&tQryobj));
	printf("\n Return Value From Dataset Name Query API is --------> %d", iFail);fflush(stdout);
    if(tQryobj!=NULLTAG)
	{
		printf("\n DesignRevision Sequence Query Found Successfully...");fflush(stdout);
		//char *cEntries[2]  = {"Revision","ID"};
		char *cEntries[1]  = {"ID"};
		char *cValues[1]  = {PSrch};
		ITK_CALL(QRY_execute(tQryobj, n_entries, cEntries, cValues, &n_Qryobj_found, &tQryobj_results));
		printf("\n Return Value From DesignRevision Sequence Query Execute API is --------> %d", iFail);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found --------> %d\n",n_Qryobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_Qryobj_found > 0)
		{
			printf(" Quiried Design Revision Found..!!\n");fflush(stdout);
			for (m = 0; m < n_Qryobj_found; m++)
			{
				DesRev_tag = tQryobj_results[m];
				ITK_CALL(AOM_ask_value_string(tQryobj_results[m],"item_revision_id",&Item_revseq));
				printf("\n Printing Rev & Seq: [%s]\n",Item_revseq);fflush(stdout);
				if(tc_strcmp(Item_revseq,PRevSeqSrch)==0)
				{
					tag_t rev_tags_found = NULLTAG;
					tag_t item_t = NULLTAG;
					size_t len;
					int	status_count = 0;
					tag_t* relStatus_list = NULLTAG;
					char* latest_rev_Rel_Status = NULL;
					char* latest_rev_Rel_StatusDup = NULL;
					char* latest_rev_Part_Type = NULL;
					char* PrtShellCommandLine = NULL;
					PrtShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
					char* dt_rlzd =	NULL;
					char* dt_rlzdDup = NULL;
					
					//item_t = tQryobj_results[0];
					//ITEM_ask_latest_rev(item_t, &rev_tags_found);
					rev_tags_found = tQryobj_results[m];
					if(rev_tags_found != NULLTAG)
					{	
						WSOM_ask_release_status_list(rev_tags_found, &status_count, &relStatus_list);
						printf("\n No of Release Status Found: -----> <%d> \n",status_count);fflush(stdout);
						if(status_count>0)
						{
							int k = 0;
							for(k = 0; k<status_count; k++)
							{
									  
								AOM_ask_value_string(relStatus_list[k],"object_name",&latest_rev_Rel_StatusDup);
								printf("\n Latest_Rev_Rel_Status: ------> <%s> \n",latest_rev_Rel_StatusDup);fflush(stdout);
										
								if((tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsReview") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsWrkg") == 0) || (tc_strcmp(latest_rev_Rel_StatusDup,"T5_LcsErcRlzd") == 0))
								{
									  
									ITK_CALL(AOM_UIF_ask_value(relStatus_list[k],"date_released",&dt_rlzd));
									printf(" \n Release Status Dtae Released String: ------> <%s>\n",dt_rlzd);fflush(stdout);
									if(tc_strlen(dt_rlzd)>0)
									{
										tc_strdup(dt_rlzd,&dt_rlzdDup);
										tc_strdup(latest_rev_Rel_StatusDup,&latest_rev_Rel_Status);
										printf("\n Date Released Value --------> %s\n", dt_rlzdDup);fflush(stdout);
										printf("\n Latest_Rev_Rel_Status Value --------> %s\n", latest_rev_Rel_Status);fflush(stdout);
									}
									else
									{
										tc_strdup("",&dt_rlzdDup);
										tc_strdup("",&latest_rev_Rel_Status);
										printf("\n Date Released Value is NULL \n");fflush(stdout);
										printf("\n Latest Rev Released Status Value is NULL \n");fflush(stdout);
									}
									trimLeading(dt_rlzdDup);
									trimLeading(latest_rev_Rel_Status);
									printf("\n Date Released Value After Trim --------> %s\n", dt_rlzdDup);fflush(stdout);
									printf("\n Latest Rev Released Status Value After Trim --------> %s\n", latest_rev_Rel_Status);fflush(stdout);
										   
								}
								else
								{
									continue;
								}
									  
							}
							
							printf("\n############################################\n");fflush(stdout);
							printf("\n Part Number: -----> <%s> \n",PSrch);fflush(stdout);
							printf("\n Part Revision & Sequence: -----> <%s> \n",PRevSeqSrch);fflush(stdout);
							printf("\n Latest ERC Date Released Value: ------> <%s> \n",dt_rlzdDup);fflush(stdout);
							printf("\n Latest Rev ERC Status Value: ------> <%s> \n",latest_rev_Rel_Status);fflush(stdout);
							printf("\n############################################\n");fflush(stdout);
							
							AOM_ask_value_string(rev_tags_found,"t5_PartType",&latest_rev_Part_Type);
							printf("\n Latest_Rev_Part_Type: ------> <%s> \n",latest_rev_Part_Type);fflush(stdout);
							
							tc_strcpy(responseString1,PSrch);
							printf("\n Part Revision & Sequence Format :Function Calling Start");fflush(stdout);
							responseString2 = TC_PartRevSeqFormat(PRevSeqSrch);
							printf("\n Part Revision & Sequence Format :Function Calling End");fflush(stdout);
									
							if(tc_strlen(latest_rev_Rel_Status)>0)
							{
								if((tc_strcmp(latest_rev_Rel_Status,"T5_LcsWrkg")==0) || (tc_strcmp(latest_rev_Rel_Status,"T5_LcsErcWrkg")==0))
								{
									tc_strcpy(responseString3,"IN_WORK");
								}
								else if((tc_strcmp(latest_rev_Rel_Status,"T5_LcsReview")==0) || (tc_strcmp(latest_rev_Rel_Status,"T5_LcsErcReview")==0))
								{
									tc_strcpy(responseString3,"FROZEN");
								}
								else if((tc_strcmp(latest_rev_Rel_Status,"T5_LcsRlzd")==0) || (tc_strcmp(latest_rev_Rel_Status,"T5_LcsErcRlzd")==0))
								{
									tc_strcpy(responseString3,"RELEASED");
								}
								else
								{
									tc_strcpy(responseString3,"NULL");
								}
							}
							else
							{
								tc_strcpy(responseString3,"NULL");
							}
							
							if(tc_strlen(latest_rev_Part_Type)>0)
							{
								/* if(tc_strcmp(latest_rev_Part_Type,"A")==0)
								{
									tc_strcpy(responseString4,"PhysicalProduct");
								}
								else if(tc_strcmp(latest_rev_Part_Type,"C")==0)
								{
									tc_strcpy(responseString4,"PhysicalProduct");
								}
								else
								{
									tc_strcpy(responseString4,"Drawing");
								} */
								tc_strcpy(responseString4,"PhysicalProduct");
							}
							else
							{
								tc_strcpy(responseString4,"NULL");
							}
									
							printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
							printf("\n Response String1:Part Number -----> <%s> \n",responseString1);fflush(stdout);
							printf("\n Response String2:Part Revision & Sequence -----> <%s> \n",responseString2);fflush(stdout);
							printf("\n Response String3:Release Status -----> <%s> \n",responseString3);fflush(stdout);
							printf("\n Response String4:Part Type -----> <%s> \n",responseString4);fflush(stdout);
							printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
								
							printf("\nData Print Start on Report File...");fflush(stdout);
							fprintf(RelStatRpt,"%s,%s,%s,%s\n",responseString1,responseString2,responseString3,responseString4);fflush(RelStatRpt);
							printf("\nData Print End on Report File...");fflush(stdout);
						}
						else
						{
							printf("\nSorry! ERC Release Status Not Found on Selected Revision...");fflush(stdout);
						}
					}
					else
					{
						printf("\nSorry! Revision Tag Not Found...");fflush(stdout);
					}
				}
			}
		}
		else
		{
			printf("\nSorry! Entered Revision Not Found...");fflush(stdout);
		}
		
	}
	else
	{
			printf("\nSorry! DesignRevision Sequence Query Tag Not Found...");fflush(stdout);
	}
	if (tQryobj_results)
    {
		MEM_free(tQryobj_results);
	}
	
    return iFail;	
}

int bom_sub_child(tag_t* tBOM_Sub_Children, int iSubSubNumber_Child, FILE* ChildReport)
{
	
		char* cSubItem_Id = NULL;
		char* cSubItem_IdDup = NULL;
		char* cPartType = NULL;
		char* cPartTypeDup = NULL;
		char* cRevision = NULL;
		char* cRevisionDup  = NULL;
		int j =0;
		int iFail = ITK_ok;
		//int iAttribute = 0;
		//int iNumber_SubChild = 0;
		//tag_t tChild = NULLTAG;
		//tag_t* tSubChild = NULLTAG;
		//char* cItemDes = NULL;
		for(j = 0; j < iSubSubNumber_Child; j++)
		{
			
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_item_item_id", &cSubItem_Id));
			if(tc_strlen(cSubItem_Id)>0)
		    {
			   tc_strdup(cSubItem_Id,&cSubItem_IdDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cSubItem_IdDup);
			   printf("\n Part No Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cSubItem_IdDup);
		    printf("\n Part No Value After Dup & Trim --------> %s", cSubItem_IdDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_rev_item_revision_id", &cRevision));
			if(tc_strlen(cRevision)>0)
		    {
			   tc_strdup(cRevision,&cRevisionDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cRevisionDup);
			   printf("\n Part Rev & Seq Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cRevisionDup);
		    printf("\n Part Rev & Seq Value After Dup --------> %s", cRevisionDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(tBOM_Sub_Children[j], "bl_Design Revision_t5_PartType", &cPartType));
			if(tc_strlen(cPartType)>0)
		    {
			   tc_strdup(cPartType,&cPartTypeDup);
		    }
		    else
		    {
			   tc_strdup("NULL",&cPartTypeDup);
			   printf("\n Part Type Value is NULL");fflush(stdout);
		    }
		    trimwhitespace(cPartTypeDup);
		    printf("\n Part Type Value After Dup & Trim --------> %s", cPartTypeDup);fflush(stdout);
			printf("\n----------- C H I L D    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nID: %s", cSubItem_IdDup);
			printf("\nRev & Seq: %s", cRevisionDup);
			printf("\nType: %s", cPartTypeDup);
			printf("\n-------------------------------------------------------------------------");
			if(tc_strlen(cSubItem_IdDup)>0)
		    {
				//fprintf(ChildReport,"%s,%s,\n",cSubItem_IdDup,cRevisionDup);fflush(ChildReport);
				printf("\n Function: Child Part Release Status & Part Type Print Start");fflush(stdout);
			    Part_Release_Status(cSubItem_IdDup,cRevisionDup,ChildReport);
			    printf("\n Function: Child Part Release Status & Part Type Print End");fflush(stdout);
			}
			/* ITK_CALL(BOM_line_ask_all_child_lines(tBOM_Sub_Children[j], &iNumber_SubChild, &tSubChild));
			printf("\n No of Sub Children Found --------> %d\n",iNumber_SubChild);fflush(stdout);
			if(iNumber_SubChild > 0)
			{
				bom_sub_child(tSubChild,iNumber_SubChild,FP_OutputReport);
			} */
		}
	return iFail;
}

int ERC_DML_Part_Child(char* TCPart,char* TCPartRS,FILE* TCReport)
{
	tag_t top_Sub_Child_bom_window = NULLTAG;
	tag_t topsubrule = NULLTAG;
	//int subrulefound = 0;
	//tag_t* subclosurerule = NULL;
	//tag_t sub_close_tag = NULLTAG;
	//char** subrulename = NULL;
    //char** subrulevalue = NULL;
	tag_t t_top_Sub_Child = NULLTAG;
	char* ctopSubItem_Id = NULL;
	char* ctopSubItem_IdDup = NULL;
	char* ctopSubRevision = NULL;
	char* ctopSubRevisionDup = NULL;
	char* ctopSubPartType = NULL;
	char* ctopSubPartTypeDup = NULL;
	int iFail = ITK_ok;
	int itopSubNumber_Child = 0;
	tag_t* ttop_BOM_Children = NULLTAG;
	
	
	tag_t top_item = NULLTAG;
	ITK_CALL(ITEM_find_item(TCPart, &top_item));
	printf("\n Return Value From Item Find Item API is --------> %d", iFail);fflush(stdout);
	tag_t topchildrev = NULLTAG;
	ITK_CALL(ITEM_find_revision(top_item, TCPartRS, &topchildrev));
	printf("\n Return Value From Item Find Revision API is --------> %d", iFail);fflush(stdout);
	if(topchildrev != NULLTAG)
    {
			
		ITK_CALL(BOM_create_window(&top_Sub_Child_bom_window));
		printf("\n Return Value From BOM Create Window API is --------> %d", iFail);fflush(stdout);
		ITK_CALL(CFM_find("ERC release and above", &topsubrule));
		//ITK_CALL(CFM_find(RevRule, &topsubrule));
		printf("\n Return Value From Revision Rule API is --------> %d", iFail);fflush(stdout);
		ITK_CALL(BOM_set_window_config_rule(top_Sub_Child_bom_window, topsubrule));
		printf("\n Return Value From BOM Window Config Rule API is --------> %d", iFail);fflush(stdout);		
		/* ITK_CALL(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &subrulefound, &subclosurerule));
		printf("\n No of Rule Found --------> %d\n",subrulefound);fflush(stdout);
		if (subrulefound > 0)
		{
			sub_close_tag = subclosurerule[0];
		}
		ITK_CALL(BOM_window_set_closure_rule(Sub_Child_bom_window,sub_close_tag,0,subrulename,subrulevalue));
		printf("\n Return Value From BOM Window Set Closure Rule API is --------> %d", iFail);fflush(stdout); */
		ITK_CALL(BOM_set_window_pack_all(top_Sub_Child_bom_window, TRUE));
		printf("\n Return Value From BOM Window Pack All API is --------> %d", iFail);fflush(stdout);
		ITK_CALL(BOM_set_window_top_line(top_Sub_Child_bom_window, NULLTAG, topchildrev, NULLTAG, &t_top_Sub_Child));
		printf("\n Return Value From BOM Set Window Top Line API is --------> %d", iFail);fflush(stdout);
	    if(t_top_Sub_Child != NULLTAG)
        {
			
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_item_item_id", &ctopSubItem_Id));
			if(tc_strlen(ctopSubItem_Id)>0)
			{
				tc_strdup(ctopSubItem_Id,&ctopSubItem_IdDup);
			}
			else
			{
				tc_strdup("NULL",&ctopSubItem_IdDup);
				printf("\n Part Number Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubItem_IdDup);
			printf("\n Part Number Value After Dup & Trim --------> %s", ctopSubItem_IdDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_rev_item_revision_id", &ctopSubRevision));
			if(tc_strlen(ctopSubRevision)>0)
			{
				tc_strdup(ctopSubRevision,&ctopSubRevisionDup);
			}
			else
			{
				tc_strdup("NULL",&ctopSubRevisionDup);
				printf("\n Part Rev & Seq Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubRevisionDup);
			printf("\n Part Rev & Seq Value After Dup & Trim --------> %s", ctopSubRevisionDup);fflush(stdout);
			ITK_CALL(AOM_UIF_ask_value(t_top_Sub_Child, "bl_Design Revision_t5_PartType", &ctopSubPartType));
			if(tc_strlen(ctopSubPartType)>0)
			{
				tc_strdup(ctopSubPartType,&ctopSubPartTypeDup);
			}
			else
			{
				tc_strdup("NULL",&ctopSubPartTypeDup);
				printf("\n Part Type Value is NULL");fflush(stdout);
			}
			trimwhitespace(ctopSubPartTypeDup);
			printf("\n Part Type Value After Dup & Trim --------> %s", ctopSubPartTypeDup);fflush(stdout);
			
			printf("\n----------- T O P    L E V E L    I T E M    D E T A I L S -------------");fflush(stdout);
			printf("\nItem ID: %s", ctopSubItem_IdDup);
			printf("\nItem Rev & Seq: %s", ctopSubRevisionDup);
			printf("\nItem Part Type: %s", ctopSubPartTypeDup);
			printf("\n-------------------------------------------------------------------------");
			//fprintf(TCReport,"%s,%s,%s\n",ctopSubItem_IdDup,ctopSubRevisionDup,ctopSubPartTypeDup);fflush(TCReport);
			printf("\n Function: TC Part Release Status & Part Type Print Start");fflush(stdout);
			Part_Release_Status(ctopSubItem_IdDup,ctopSubRevisionDup,TCReport);
			printf("\n Function: TC Part Release Status & Part Type Print End");fflush(stdout);	
			ITK_CALL(BOM_line_ask_all_child_lines(t_top_Sub_Child, &itopSubNumber_Child, &ttop_BOM_Children));
			printf("\n Return Value From Child Line API is --------> %d", iFail);fflush(stdout);
			printf("\n No of Children Found --------> %d\n",itopSubNumber_Child);fflush(stdout);
			if(itopSubNumber_Child>0)
			{
				printf("\n!!!!!!!!! N O   O F   P A R T S   F O U N D !!!!!!!!!!");fflush(stdout);
				bom_sub_child(ttop_BOM_Children, itopSubNumber_Child, TCReport);
			}
        }
	    ITK_CALL(BOM_close_window(top_Sub_Child_bom_window));
	    printf("\n Return Value From BOM Close Window API is --------> %d", iFail);fflush(stdout);
	}
	return iFail;	
}

int ERC_DML_Part_transfer(char* DmlNumber,FILE* FReport)
{
	
	int iFail = 0;
	tag_t dml_task_rel = NULLTAG;
	int	task_count = 0;
	tag_t *task_tag	= NULL;
    tag_t dml_tag = NULLTAG;
	tag_t rev_tag = NULLTAG;
    tag_t RevTypTag	= NULLTAG;
	char* RevTyp = NULL;
	char* item_type = NULL;
	ITK_CALL(ITEM_find_item(DmlNumber, &dml_tag));
	if (dml_tag != NULLTAG)
	{
		printf("\n !!!!!! DML Tag Found !!!!!!");fflush(stdout);
	}
	ITK_CALL(ITEM_ask_type2(dml_tag, &item_type));
	printf("\n DML Item_Types: [%s] \n",item_type);fflush(stdout);
	// Find the DML-Revision tag.
	//ITK_CALL(ITEM_find_revision(dml_tag,"NR",&dml_rev_tag)) ;
	ITK_CALL(ITEM_ask_latest_rev(dml_tag,&rev_tag)) ;
	if(rev_tag != NULLTAG)
	{
		printf("\n !!!!!! DML Revision Tag Found !!!!!!");fflush(stdout);
	}
	if(TCTYPE_ask_object_type(rev_tag, &RevTypTag));
	if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
	printf("\n Revision Type: [%s]\n", RevTyp);fflush(stdout);
	if(tc_strcmp(RevTyp,"ChangeRequestRevision")==0)
	{
		ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &dml_task_rel));
		ITK_CALL(GRM_list_secondary_objects_only(rev_tag, dml_task_rel, &task_count, &task_tag));
		printf("\n !!!!!! Secondary Objects Only !!!!!!");fflush(stdout);
		printf("\n Total Task Found: [%d]",task_count);fflush(stdout);
		int i = 0;
		char *task_id = NULL;
		tag_t task_part_rel = NULLTAG;
		int	part_count = 0;
		tag_t* part_tag	= NULL;
		int j = 0;
		int n_tags_found = 0;
		tag_t* tags_found = NULLTAG;
		tag_t item_t = NULLTAG;
		tag_t rev_tags_found = NULLTAG;
		int	status_count = 0;
		tag_t*	relStatus_list = NULLTAG;
		char* latest_rev_Rel_Status = NULL;
		char* latest_rev_Rel_StatusDup = NULL;
		char* latest_rev_Part_Type = NULL;
		char* PrtShellCommandLine = NULL;
		PrtShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
		char* dt_rlzd =	NULL;
		char* dt_rlzdDup = NULL;
		char* part_Rev = NULL;
		char* cItemID = NULL;
		if(task_count > 0)
		{
			for(i=0;i<task_count;i++)
			{
				
				printf("\n Inside Task: ---> [%d]", i);fflush(stdout);
				ITK_CALL(AOM_UIF_ask_value(task_tag[i], "item_id", &task_id));
				printf("\nTask ID: [%s]", task_id);fflush(stdout);
				if(tc_strstr(task_id,"APL") == NULL)
			    {
				
					printf("\n !!!!!! Task To Part !!!!!!");fflush(stdout);
					ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &task_part_rel));
					ITK_CALL(GRM_list_secondary_objects_only(task_tag[i], task_part_rel, &part_count, &part_tag));
					printf("\n >>>>>> Total Part Found: [%d] <<<<<<", part_count);fflush(stdout);
					if(part_count > 0)
					{	
						for(j=0;j<part_count;j++)
						{
							
							ITK_CALL(AOM_UIF_ask_value(part_tag[j], "item_id", &cItemID));
							ITK_CALL(AOM_UIF_ask_value(part_tag[j], "item_revision_id", &part_Rev));
							printf("\n Part Number: [%s]", cItemID);fflush(stdout);
							printf("\n Part Revision & Sequence: [%s]", part_Rev);fflush(stdout);
							rev_tags_found = part_tag[j];
							if((cItemID != NULL) && (tc_strcmp(cItemID,"")!=0))
							{
								printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
								printf("\n First String:Part Number -----> <%s> \n",cItemID);fflush(stdout);
								printf("\n Second String:Part Revision & Sequence -----> <%s> \n",part_Rev);fflush(stdout);
								printf("\n Third String:Task Number -----> <%s> \n",task_id);fflush(stdout);
								printf("\n Fourth String:DML Number -----> <%s> \n",DmlNumber);fflush(stdout);
								printf("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");fflush(stdout);
								
								printf("\n Function: First Level Child Details Find Start");fflush(stdout);
			                    ERC_DML_Part_Child(cItemID,part_Rev,FReport);
			                    printf("\n Function: First Level Child Details Find End");fflush(stdout);						
							}
							else
							{
								printf("\n Sorry!! Item ID is NULL");fflush(stdout);
							}						
						}
					}
					else
					{
						printf("\n Sorry!! No Parts Found");fflush(stdout);
					}
				}
				else
				{
					printf("\n SKIP: As APL Task Found");fflush(stdout);
				}
			}
	    }
		else
		{
			printf("\n Sorry!! No Tasks Found");fflush(stdout);
		}
	}
	else
	{
		printf("\n Sorry!! RevType is Not ChangeRequestRevision");fflush(stdout);
	}
	
	return ITK_ok;	
}	

int ITK_user_main(int argc, char* argv[])
{
	int iFail = 0;
	int i = 0;
	char* cError = NULL;
	char* username = NULL;
	tag_t tuser = NULLTAG;
	//time_t	temptime;
	//char GenDate[20];
	//char RptDate[20];
	//struct tm *timeptr;
	//int ch;
	//int ch1;
	char *FinalRptFile= (char *) malloc(400*sizeof(char));
	FILE *fpOutput_file = NULL;
	char* cUSERID = NULL;
	char* cPASS = NULL;
	char* cGroup = NULL;
	char* DmlNo = NULL;
	char* ShellCommandLine = NULL;
	ShellCommandLine = (char *) MEM_alloc(1000*sizeof(char ));
	tag_t tUserAgen;
	char* useragency = NULL;
	tag_t user_tag = NULLTAG;
	char* InpDMLProjCode = NULL;
	char* InpDMLDesGrp = "61";
	tag_t CurrentRoleTag = NULLTAG;
	//char roleName[SA_name_size_c+1];
	char* roleName = NULL;
    char *PlantName = NULL;
	char* FinalDesGrp = NULL;
	FinalDesGrp = (char *) MEM_alloc(50*sizeof(char ));
	
	/* printf("\n Generating Curernt Time Stamp");fflush(stdout);
	temptime = time(NULL);
	tc_strcpy(GenDate,"");
	timeptr = (struct tm *)localtime(&temptime);
	ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y_%H_%M",timeptr);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);
	printf("\n Curernt Time Stamp Generated");fflush(stdout);
	
	printf("\n Generating Report Time Stamp");fflush(stdout);
	tc_strcpy(RptDate,"");
	ch1 = strftime(RptDate,sizeof(RptDate)-1,"%d-%b-%Y-%H:%M",timeptr);
	printf("\n Report Time --------> %s", RptDate);fflush(stdout);
	printf("\n Report Time Stamp Generated");fflush(stdout); */
	
	printf("\n Generating New Time Stamp");fflush(stdout);
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Current Time --------> %s", GenDate);fflush(stdout);
	printf("\n New Time Stamp Generated");fflush(stdout);
	
	printf("\n Generating New Report Time Stamp");fflush(stdout);
	char RptDate[100] = "";
	strftime(RptDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf("\n Report Time --------> %s", RptDate);fflush(stdout);
	printf("\n New Report Time Stamp Generated");fflush(stdout);
	
	printf("\n Total Number of Argument Passed --------> %d", argc);fflush(stdout);
	if (argc == 5)
	{
			printf("\n Total Number of Passed Argument Matches with Required So Exucution Continues...");fflush(stdout);
			cUSERID = ITK_ask_cli_argument("-u=");
			cPASS = ITK_ask_cli_argument("-p=");
			cGroup = ITK_ask_cli_argument("-g=");
			DmlNo = ITK_ask_cli_argument("-dml=");
			printf("\nUsername --------> %s", cUSERID);fflush(stdout);
			printf("\nPassword --------> %s", cPASS);fflush(stdout);
			printf("\nGroup --------> %s", cGroup);fflush(stdout);
			printf("\nDML Number --------> %s", DmlNo);fflush(stdout);
			ITK_CALL(ITK_init_module(cUSERID, cPASS, cGroup));
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
		    printf("\nReturn Value From Login API --------> %d", iFail);fflush(stdout);
			if (iFail == ITK_ok)
			{
				printf("\nTeamcenter Login Success...");
				POM_get_user(&cUSERID, &tuser);
				printf("\nLogged in Username --------> %s", cUSERID);fflush(stdout);				
			}
			else
			{
				EMH_ask_error_text(iFail, &cError);
				printf("\nTeamcenter Login Error --------> %s", cError);fflush(stdout);
			}
			if (cError)
			{
				MEM_free(cError);
			}
			if(tc_strlen(stripBlanks(DmlNo)) == 0)
	        {
		        print_requirement();
		        return iFail;
	        }
			
			printf("\n Generating Report File Name");fflush(stdout);
	        /* tc_strcpy(FinalRptFile,"/tmp/");
			tc_strcat(FinalRptFile,DmlNo);
			tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,"CATIAV6_Part_Tranfer_Report");
			tc_strcat(FinalRptFile,"_");
	        tc_strcat(FinalRptFile,GenDate);
	        tc_strcat(FinalRptFile,".csv"); */
			tc_strcpy(FinalRptFile,"/tmp/");
			tc_strcat(FinalRptFile,DmlNo);
		    tc_strcat(FinalRptFile,"_");
			tc_strcat(FinalRptFile,"CATIAV6_Part_Tranfer_Report");
			tc_strcat(FinalRptFile,"_");
	        tc_strcat(FinalRptFile,GenDate);
	        tc_strcat(FinalRptFile,".txt");
	        printf("\n Report File Name --------> [%s", FinalRptFile);fflush(stdout);
	        printf("\n Report File Name Generated");fflush(stdout);
            
			fpOutput_file = fopen(FinalRptFile, "w"); 
	        if(fpOutput_file == NULL)
	        {
				printf("\n Unable to Create Report File on Server --------> %s",FinalRptFile);fflush(stdout);
				return iFail;
	        }
			else
	        {
		        printf("\n Report File Opened Successfully");fflush(stdout);
				tag_t Inpdmltag = NULLTAG;
	            tag_t Inprevtag = NULLTAG;
                tag_t InpRevTypTag	= NULLTAG;
	            char* InpRevTyp = NULL;
				char* Inpitemtype = NULL;
				//char* InpDMLProjCode = NULL;
				//char* InpDMLDesGrp = NULL;
				ITK_CALL(ITEM_find_item(DmlNo, &Inpdmltag));
	            if (Inpdmltag != NULLTAG)
	            {
		          printf("\n !!!!!! Input DML Tag Found !!!!!!");fflush(stdout);
	            }
	            ITK_CALL(ITEM_ask_type2(Inpdmltag, &Inpitemtype));
	            printf("\n Input DML Item_Types: [%s] \n",Inpitemtype);fflush(stdout);
	            // Find the DML-Revision tag.
	            //ITK_CALL(ITEM_find_revision(Inpdmltag,"NR",&dml_rev_tag)) ;
	            ITK_CALL(ITEM_ask_latest_rev(Inpdmltag,&Inprevtag)) ;
				if(Inprevtag != NULLTAG)
				{
					printf("\n !!!!!! Input DML Revision Tag Found !!!!!!");fflush(stdout);
				}
				AOM_ask_value_string(Inprevtag,"t5_cprojectcode",&InpDMLProjCode);
				printf("\n Input DML Project Code: ------> <%s> \n",InpDMLProjCode);fflush(stdout);
				//AOM_ask_value_string(Inprevtag,"t5_crdesigngroup",&InpDMLDesGrp);
				printf("\n Input DML Design Group: ------> <%s> \n",InpDMLDesGrp);fflush(stdout);
				//trimwhitespace(InpDMLProjCode);
	            //trimwhitespace(InpDMLDesGrp);
	            printf("\n Input DML Project Code After Trim --------> [%s]\n", InpDMLProjCode);fflush(stdout);
	            printf("\n Input DML Design Group After Trim --------> [%s]\n", InpDMLDesGrp);fflush(stdout);
				tc_strcpy(FinalDesGrp,"*");
			    tc_strcat(FinalDesGrp,InpDMLDesGrp);
			    tc_strcat(FinalDesGrp,"*");
			    printf("\n Final Design Group --------> [%s]", FinalDesGrp);fflush(stdout);
				if(TCTYPE_ask_object_type(Inprevtag, &InpRevTypTag));
				if(TCTYPE_ask_name2(InpRevTypTag,&InpRevTyp));
				printf("\n Revision Type: [%s]\n", InpRevTyp);fflush(stdout);
				if(tc_strcmp(InpRevTyp,"ChangeRequestRevision")==0)
				{
					tag_t tCtrlobj = NULLTAG;
	                tag_t* tctrlobj_results = NULLTAG;
					int n_entries = 4;
	                int n_ctrlobj_found = 0;
					ITK_CALL(QRY_find2("Control Objects...",&tCtrlobj));
			        printf("\n Return Value From Control Object Query API is --------> %d", iFail);fflush(stdout);
			        if(tCtrlobj!=NULLTAG)
			        {
					   printf("\n Control Object Query Found Successfully...");
					   char *cEntries[4]  = {"SYSCD","SUBSYSCD","Name","Delete Indicator"};
					   //char *cValues[4]  = {InpDMLProjCode,InpDMLDesGrp,"V6PartCreChkInOutVld","0"};
					   char *cValues[4]  = {InpDMLProjCode,FinalDesGrp,"V6PartCreChkInOutVld","0"};
			           ITK_CALL(QRY_execute(tCtrlobj, n_entries, cEntries, cValues, &n_ctrlobj_found, &tctrlobj_results));
			           printf("\n Return Value From Control Object Query Execute API is --------> %d", iFail);fflush(stdout);
			           printf("\n No of Control Object Found --------> %d\n",n_ctrlobj_found);fflush(stdout);
			           if(n_ctrlobj_found>0)
			            {
						   printf("\n Control Object Found Against Input DML Project Code & Design Group");fflush(stdout);
					       printf("\n Function: ERC DML Part Transfer Start");fflush(stdout);
					       ERC_DML_Part_transfer(DmlNo,fpOutput_file);
					       printf("\n Function: ERC DML Part Transfer End");fflush(stdout);
					    }
                        else
                        {
							printf("\n Sorry! No Control Object Found Against Input DML Project Code & Design Group");fflush(stdout);
						}
                    }
                    else
                    {
						printf("\n Sorry! Control Objects... Query Tag Not Found");fflush(stdout);
					}					
				}
				else
				{
					printf("\n Sorry! Input DML is Not ERC DML");fflush(stdout);
				}
	        }
			fclose(fpOutput_file);
			printf("\n Report File Closed Successfully");fflush(stdout);
			printf("\n Shell Calling STARTED...");fflush(stdout);
			//tc_strcpy(ShellCommandLine,"/user/uaprodtrl/Sourav/tm_dml_part_transfer/Execution_Shell.sh");
			//tc_strcpy(ShellCommandLine,"/user/omfprod/sourav/tm_dml_part_transfer/Execution_Shell.sh");
			tc_strcpy(ShellCommandLine,"/user/uaprodtrl/Sourav/CATIAV6_Part_Transfer/Execution_Shell.sh");
			tc_strcat(ShellCommandLine," ");
			tc_strcat(ShellCommandLine,DmlNo);
			tc_strcat(ShellCommandLine," ");
			tc_strcat(ShellCommandLine,RptDate);
			tc_strcat(ShellCommandLine," ");
	        tc_strcat(ShellCommandLine,FinalRptFile);
			tc_strcat(ShellCommandLine," ");
			tc_strcat(ShellCommandLine,InpDMLProjCode);
			tc_strcat(ShellCommandLine," ");
			tc_strcat(ShellCommandLine,InpDMLDesGrp);
	        printf("\n CommandLine: -------> %s",ShellCommandLine);fflush(stdout);
			//exit(0);
	        system(ShellCommandLine);
			printf("\n Shell Called Ended...");
			
			
			ITK_CALL(ITK_exit_module(TRUE));
			printf("\n Return Value From Teamcenter Logout API --------> %d", iFail);fflush(stdout);
			printf("\n Teamcenter Logout Success...\n");fflush(stdout);
			printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
			printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
			if (cError)
			{
				MEM_free(cError);
			}
		
	}
	else
	{
		printf("\n Sorry! No of Passed Arguments Are Not Matched\n");fflush(stdout);
	}
	return 0;
}



/***************************************************************************
*
* // ./compile tm_dml_part_transfer.c
* // ./linkitk -o tm_dml_part_transfer tm_dml_part_transfer.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_dml_part_transfer/tm_dml_part_transfer .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_dml_part_transfer/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_dml_part_transfer/usage.txt .
* // ./tm_dml_part_transfer -u="skk919708" -p="XYT1ESA" -g="PLM_Support_Group" -dml="22PU122124"
* // ./tm_dml_part_transfer -u=loader -p="loader123" -g=dba -dml="22PU122124"
*
***************************************************************************/