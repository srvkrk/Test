/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author       :   Sourav Karak
*  Module       :   WSOM
*  Description  :   Query SubModule & Print its Properties on Reports  
*  File Name    :   tm_SubModuleDetailsRpt.c
*  Created on   :   Oct 18th, 2023
*  Usage        :   tm_SubModuleDetailsRpt
*
* Modification History :
* S.No       Date         CR No      Modified By      Modification Notes
*  1.     18/10/2023                 Sourav Karak
***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/folder.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <rdv/arch.h>
#include <textsrv/textserver.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdio.h>
#include <tccore/item_msg.h>
#include <tccore/grm_msg.h>
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define ITK_errStore 91900002
#define MAX_LINE_LENGTH 1000
#define Debug TRUE
int status =0;
#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			/*return status;*/													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

char *trimwhitespace(char *str)
{
  char *end;

  // Trim leading space
  while(isspace((unsigned char)*str)) str++;

  if(*str == 0) 
    return str;

  // Trim trailing space
  end = str + strlen(str) - 1;
  while(end > str && isspace((unsigned char)*end)) end--;

  // Write new null terminator character
  end[1] = '\0';

  return str;
}

char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

char* TC_ERC_DTReleased(tag_t PartRev_tag)
{
	int	status = 0;
	tag_t *Stat_list = NULLTAG;
	tag_t Stat_tag = NULLTAG;
	int Stat_Cnt = 0;
	char *RlzStatusName = NULL;
	char *Dt_Rlzd = NULL;
	char *Dt_RlzdDup = NULL;
	int j = 0;
	
    ITK_CALL(WSOM_ask_release_status_list(PartRev_tag,&Stat_Cnt,&Stat_list));
    for(j=0;j<Stat_Cnt;j++)
	{
		Stat_tag = Stat_list[j];
		ITK_CALL(AOM_ask_name(Stat_tag, &RlzStatusName));
		printf("\n Part`s Release Status Name: [%s]\n",RlzStatusName);fflush(stdout);
        if ((tc_strcmp(RlzStatusName,"T5_LcsRlzd")==0) || (tc_strcmp(RlzStatusName,"T5_LcsErcRlzd")==0))
		{
			ITK_CALL(AOM_UIF_ask_value(Stat_tag,"date_released",&Dt_Rlzd));
			printf(" \n ERC-Release Status Date: [%s]\n",Dt_Rlzd);fflush(stdout);
             
		}
	}
	if(tc_strlen(Dt_Rlzd)>0)
	{
	   tc_strdup(Dt_Rlzd,&Dt_RlzdDup);
	}
	else
	{
	   tc_strdup("Not_ERC_Released",&Dt_RlzdDup);
	}
	return Dt_RlzdDup;
}

char* TC_NRRev_ERC_DTReleased(char* PNSrch)
{
	trimwhitespace(PNSrch);
	tag_t tDesItemobj = NULLTAG;
	int n_nrentries = 2;
	int n_nritemobj_found = 0;
	tag_t* tdesitemobj_results = NULLTAG;
	int m = 0;
	int n = 0;
	tag_t NRDesRev_tag = NULLTAG;
	int NRStat_Cnt = 0;
	tag_t *NRStat_list = NULLTAG;
	char *NRItem_revseq = NULL;
	char *nritem_rev = NULL;
	char *nritem_seq = NULL;
	tag_t NRStat_tag = NULLTAG;
	char *NRRlzStatusName = NULL;
	char *NRDt_Rlzd = NULL;
	char *NRDt_RlzdDup = NULL;
	
	
	ITK_CALL(QRY_find2("DesRev_ERC_Rlzd",&tDesItemobj));
    if(tDesItemobj != NULLTAG)
	{
		printf("\n DesRev_ERC_Rlzd Found Successfully..!!\n");fflush(stdout);
		char *cNREntries[2]  = {"Revision","ID"};
		char *cNRValues[2]  = {"NR;*",PNSrch};
		//char *cValues[2]  = {"NR;*","5137D1D0270001_WE"};
	    ITK_CALL(QRY_execute(tDesItemobj, n_nrentries, cNREntries, cNRValues, &n_nritemobj_found, &tdesitemobj_results));
		printf("\n -----------------------------------------------\n");fflush(stdout);
		printf("\n No of Revision Found: [%d]\n",n_nritemobj_found);fflush(stdout);
		printf("\n -----------------------------------------------\n");fflush(stdout);
		if(n_nritemobj_found > 0)
		{
			printf(" Quiried NR Design Revision & Sequence Found..!!\n");fflush(stdout);
			for (m = 0; m < n_nritemobj_found; m++)
			{
				NRDesRev_tag = tdesitemobj_results[m];
				ITK_CALL(AOM_ask_value_string(tdesitemobj_results[m],"item_revision_id",&NRItem_revseq));
				printf("\n Printing NR Rev & Seq: [%s]\n",NRItem_revseq);fflush(stdout);
				nritem_rev=strtok(NRItem_revseq,";");
			    nritem_seq=strtok(NULL,";");
				if (tc_strcmp(nritem_rev,"NR")==0)
				{
					ITK_CALL(WSOM_ask_release_status_list(NRDesRev_tag,&NRStat_Cnt,&NRStat_list));
					for(n = 0; n < NRStat_Cnt; n++)
					{
						NRStat_tag = NRStat_list[n];
						ITK_CALL(AOM_ask_name(NRStat_tag, &NRRlzStatusName));
						printf("\n NR Revision Release Status Name: [%s]\n",NRRlzStatusName);fflush(stdout);
						if ((tc_strcmp(NRRlzStatusName,"T5_LcsRlzd")==0) || (tc_strcmp(NRRlzStatusName,"T5_LcsErcRlzd")==0))
						{
							ITK_CALL(AOM_UIF_ask_value(NRStat_tag,"date_released",&NRDt_Rlzd));
							printf(" \n NR Revision ERC-Release Status Date: [%s]\n",NRDt_Rlzd);fflush(stdout);
							 
						}
					}
					if(tc_strlen(NRDt_Rlzd)>0)
					{
					   tc_strdup(NRDt_Rlzd,&NRDt_RlzdDup);
					}
					else
					{
					   tc_strdup("NR_Not_ERC_Released",&NRDt_RlzdDup);
					}					
				}
			}
		}
		else
		{
			tc_strdup("NR_Revision_Not_Found",&NRDt_RlzdDup);
		}
	}
	return NRDt_RlzdDup;
}

int ITK_user_main(int argc,char* argv[]) 
{
	char *message;
	char *loggedInUser = NULL;
	char *sr_no_str = NULL;
	char *item_id_str = NULL;
	char *item_rev_str = NULL;
	char *item_seq_str = NULL;
	char *sr_no_strDup = NULL;
	char *item_id_strDup = NULL;
	char *item_rev_strDup = NULL;
	char *item_seq_strDup = NULL;
	FILE *fpPart_List = NULL;
	char Buffer[MAX_LINE_LENGTH];
	tag_t tItemobj = NULLTAG;
	int n_entries = 2;
	int n_itemobj_found = 0;
	tag_t* titemobj_results = NULLTAG;
	char *Owner = NULL;
	char *OwnerDup = NULL;
	char *DRStatus = NULL;
	char *DRStatusDup = NULL;
	char *Platform = NULL;
	char *PlatformDup = NULL;
	char *JSRCS = NULL;
	char *JSRCSDup = NULL;
	char *LKNCS = NULL;
	char *LKNCSDup = NULL;
	char *DWDCS = NULL;
	char *DWDCSDup = NULL;
	char *SNDCS = NULL;
	char *SNDCSDup = NULL;
	char *PUNCS = NULL;
	char *PUNCSDup = NULL;
	char *PNRCS = NULL;
	char *PNRCSDup = NULL;
	char *PPCBUCS = NULL;
	char *PPCBUCSDup = NULL;
	char *PUVCS = NULL;
	char *PUVCSDup = NULL;
	char *CARCS = NULL;
	char *CARCSDup = NULL;
	char *AHDCS = NULL;
	char *AHDCSDup = NULL;
	char *RJVCS = NULL;
	char *RJVCSDup = NULL;
	char *SGRCS = NULL;
	char *SGRCSDup = NULL;
	char *cItem_Desc = NULL;
	char *cItem_DescDup = NULL;
	char *ModAddress = NULL;
	char *ModAddressDup = NULL;
	char *Aggregate = NULL;
	char *AggregateDup = NULL;
	char *AggregateGroup = NULL;
	char *AggregateGroupDup = NULL;
	char *Module = NULL;
	char *ModuleDup = NULL;
	char *ModuleName = NULL;
	char *ModuleNameDup = NULL;
	char *KeywordDes = NULL;
	char *KeywordDesDup = NULL;
	int i = 0;
	char *RptFile = (char *) malloc(400*sizeof(char));
	char *item_revseq_strDup = (char *) malloc(50*sizeof(char));
	char *ERCRlzdDt = NULL;
	FILE *fpOutput_file = NULL;
	tag_t DesRev_tag = NULLTAG;
	char *NRERCRlzdDt = NULL;
    
    printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);	
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_set_journalling( TRUE ));
    status = ITK_auto_login ();	
    if (status != ITK_ok ) 
	{
        EMH_ask_error_text(status, &message);
        printf(" Error with ITK_auto_login: \"%d\", \"%s\"\n", status, message);
        MEM_free(message);
        return status;
    }
	else
	{
		printf(" Auto Login Successfull\n");fflush(stdout);
		POM_get_user_id(&loggedInUser);
		printf(" Logged in User: [%s]\n",loggedInUser);fflush(stdout);
	}
	
	char GenDate[100] = "";
	time_t 	now;
	struct 	tm when;
	time(&now);
	when = *localtime(&now);
	strftime(GenDate,100,"%d_%b_%Y_%H_%M_%S",&when);
	printf(" Current TimeStamp: [%s]\n", GenDate);fflush(stdout);
	
	printf("\n Generating Report File Name..!!");fflush(stdout);
	tc_strcpy(RptFile,"SubModule_Details_Rpt_File");
	tc_strcat(RptFile,"_");
	tc_strcat(RptFile,GenDate);
	tc_strcat(RptFile,".csv");
	printf("\n Report File Name: [%s]", RptFile);fflush(stdout);
	printf("\n Report File Generated..!!");fflush(stdout);

	fpPart_List = fopen("PartList.txt","r");
	
    fpOutput_file = fopen(RptFile, "w");
	fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ S U B - M O D U L E   D E T A I L S   R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
    fprintf(fpOutput_file,"SR_NO, SUBMODULE_NO, REV, SEQ, OWNING_USER, NR_RELEASED_DATE, ERC_RELEASE_DATE, DR/AR_STATUS, PLATFORM, JSR_CS, LKN_CS, DWD_CS, SND_CS, PUN_CS, PNR_CS, PUNPCBU_CS, PUNUV_CS, CAR_CS, AHD_CS, RJV_CS, SGR_CS, DESCRIPTION, MODULE_ADDRESS, AGGREGATE, AGGREGATE_GROUP, MODULE, MODULE_NAME, KEYWORD_DESCRIPTION\n");fflush(fpOutput_file); 
	if(fpOutput_file == NULL)
	{
	    printf("\n Unable to Create Report File: --------> [%s]",RptFile);fflush(stdout);
		return 0;
	}
	if(fpPart_List != NULL)
	{
		printf(" Input_File Not Null..!!\n");fflush(stdout);
		while(fgets(Buffer,MAX_LINE_LENGTH,fpPart_List)!=NULL)
		{
			sr_no_str=strtok(Buffer,"^");
			item_id_str=strtok(NULL,"^");
			item_rev_str=strtok(NULL,"^");
			item_seq_str=strtok(NULL,"^");
			
			if(sr_no_str!=NULL)tc_strdup(sr_no_str,&sr_no_strDup);
			if(item_id_str!=NULL)tc_strdup(item_id_str,&item_id_strDup);
			if(item_rev_str!=NULL)tc_strdup(item_rev_str,&item_rev_strDup);
			if(item_seq_str!=NULL)tc_strdup(item_seq_str,&item_seq_strDup);
			
			if(sr_no_strDup!=NULL)trimwhitespace(sr_no_strDup);
			if(item_id_strDup!=NULL)trimwhitespace(item_id_strDup);
			if(item_rev_strDup!=NULL)trimwhitespace(item_rev_strDup);
			if(item_seq_strDup!=NULL)trimwhitespace(item_seq_strDup);
			
			tc_strcpy(item_revseq_strDup,item_rev_strDup);
			tc_strcat(item_revseq_strDup,";");
			tc_strcat(item_revseq_strDup,item_seq_strDup);
			
			printf("\n Sr. No(sr_no_strDup): [%s]\n",sr_no_strDup);
			printf("\n Part No(item_id_strDup): [%s]\n",item_id_strDup);
			printf("\n Part Rev(item_rev_strDup): [%s]\n",item_rev_strDup);
			printf("\n Part Seq(item_seq_strDup): [%s]\n",item_seq_strDup);
			printf("\n Part Rev&Seq(item_revseq_strDup): [%s]\n",item_revseq_strDup);
			ITK_CALL(QRY_find2("DesignRevision Sequence",&tItemobj));
            if(tItemobj != NULLTAG)
			{
				printf("\n DesignRevision Sequence Found Successfully..!!\n");fflush(stdout);
				char *cEntries[2]  = {"Revision","ID"};
				char *cValues[2]  = {item_revseq_strDup,item_id_strDup};
				//char *cValues[2]  = {"A;2","5137D1D0270001_WE"};
			    ITK_CALL(QRY_execute(tItemobj, n_entries, cEntries, cValues, &n_itemobj_found, &titemobj_results));
				printf("\n -----------------------------------------------\n");fflush(stdout);
				printf("\n No of Revision Found: [%d]\n",n_itemobj_found);fflush(stdout);
			    printf("\n -----------------------------------------------\n");fflush(stdout);
				if(n_itemobj_found > 0)
				{
					printf(" Quiried Design Revision & Sequence Found..!!\n");fflush(stdout);
					for (i = 0; i < n_itemobj_found; i++)
					{
						DesRev_tag = titemobj_results[i];
						ITK_CALL(AOM_UIF_ask_value(titemobj_results[i],"owning_user",&Owner));
						if(tc_strlen(Owner)>0)
						{
							tc_strdup(Owner,&OwnerDup);
							trimwhitespace(OwnerDup);
							printf("\n Owning_User Value After Dup & Trim: --------> <%s>", OwnerDup);fflush(stdout);
							STRNG_replace_str(OwnerDup,","," ",&OwnerDup);
							STRNG_replace_str(OwnerDup,";"," ",&OwnerDup);
							STRNG_replace_str(OwnerDup,"\n"," ",&OwnerDup);
							STRNG_replace_str(OwnerDup,"'"," ",&OwnerDup);
							printf("\n Owning_User Final Value: --------> [%s]\n", OwnerDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&OwnerDup);
							printf("\n Owning_User Value is NULL..!!");fflush(stdout);
						}
						printf("\n Function1: (NR Revision) ERC-Release Date Find Start");fflush(stdout);
						NRERCRlzdDt = TC_NRRev_ERC_DTReleased(item_id_strDup);
			            printf("\n Function1: (NR Revision) ERC-Release Date Find End\n");fflush(stdout);
						printf("\n Function2: ERC-Release Date Find Start");fflush(stdout);
						ERCRlzdDt = TC_ERC_DTReleased(DesRev_tag);
			            printf("\n Function2: ERC-Release Date Find End\n");fflush(stdout);
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PartStatus",&DRStatus));
						if(tc_strlen(DRStatus)>0)
						{
							tc_strdup(DRStatus,&DRStatusDup);
						}
						else
						{
							tc_strdup("--",&DRStatusDup);
							printf("\n DR Status Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Platform",&Platform));
						if(tc_strlen(Platform)>0)
						{
							tc_strdup(Platform,&PlatformDup);
						}
						else
						{
							tc_strdup("--",&PlatformDup);
							printf("\n Platform Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_JsrMakeBuyIndicator",&JSRCS));
						if(tc_strlen(JSRCS)>0)
						{
							tc_strdup(JSRCS,&JSRCSDup);
						}
						else
						{
							tc_strdup("--",&JSRCSDup);
							printf("\n JSR CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_LkoMakeBuyIndicator",&LKNCS));
						if(tc_strlen(LKNCS)>0)
						{
							tc_strdup(LKNCS,&LKNCSDup);
						}
						else
						{
							tc_strdup("--",&LKNCSDup);
							printf("\n LKN CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_DwdMakeBuyIndicator",&DWDCS));
						if(tc_strlen(DWDCS)>0)
						{
							tc_strdup(DWDCS,&DWDCSDup);
						}
						else
						{
							tc_strdup("--",&DWDCSDup);
							printf("\n DWD CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_SndMakeBuyIndicator",&SNDCS));
						if(tc_strlen(SNDCS)>0)
						{
							tc_strdup(SNDCS,&SNDCSDup);
						}
						else
						{
							tc_strdup("--",&SNDCSDup);
							printf("\n SND CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PunMakeBuyIndicator",&PUNCS));
						if(tc_strlen(PUNCS)>0)
						{
							tc_strdup(PUNCS,&PUNCSDup);
						}
						else
						{
							tc_strdup("--",&PUNCSDup);
							printf("\n PUN CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PnrMakeBuyIndicator",&PNRCS));
						if(tc_strlen(PNRCS)>0)
						{
							tc_strdup(PNRCS,&PNRCSDup);
						}
						else
						{
							tc_strdup("--",&PNRCSDup);
							printf("\n PNR CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PunPCBUMakeBuyIndicator",&PPCBUCS));
						if(tc_strlen(PPCBUCS)>0)
						{
							tc_strdup(PPCBUCS,&PPCBUCSDup);
						}
						else
						{
							tc_strdup("--",&PPCBUCSDup);
							printf("\n PPCBU CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_PunUVMakeBuyIndicator",&PUVCS));
						if(tc_strlen(PUVCS)>0)
						{
							tc_strdup(PUVCS,&PUVCSDup);
						}
						else
						{
							tc_strdup("--",&PUVCSDup);
							printf("\n PUV CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_CarMakeBuyIndicator",&CARCS));
						if(tc_strlen(CARCS)>0)
						{
							tc_strdup(CARCS,&CARCSDup);
						}
						else
						{
							tc_strdup("--",&CARCSDup);
							printf("\n CAR CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_AhdMakeBuyIndicator",&AHDCS));
						if(tc_strlen(AHDCS)>0)
						{
							tc_strdup(AHDCS,&AHDCSDup);
						}
						else
						{
							tc_strdup("--",&AHDCSDup);
							printf("\n AHD CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_RjvMakebuyInd",&RJVCS));
						if(tc_strlen(RJVCS)>0)
						{
							tc_strdup(RJVCS,&RJVCSDup);
						}
						else
						{
							tc_strdup("--",&RJVCSDup);
							printf("\n RJV CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_SgrMakeBuyIndicator",&SGRCS));
						if(tc_strlen(SGRCS)>0)
						{
							tc_strdup(SGRCS,&SGRCSDup);
						}
						else
						{
							tc_strdup("--",&SGRCSDup);
							printf("\n SGR CS Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"object_desc",&cItem_Desc));
						printf("\n Item Description Before Dup & Trim: ---> <%s> \n",cItem_Desc);fflush(stdout);
						if(tc_strlen(cItem_Desc)>0)
						{
							tc_strdup(cItem_Desc,&cItem_DescDup);
						}
						else
						{
							tc_strdup("--",&cItem_DescDup);
							printf("\n Item Description Value is NULL..!!");fflush(stdout);
						}
						trimwhitespace(cItem_DescDup);
						printf("\n Item Description Value After Dup & Trim: --------> <%s>", cItem_DescDup);fflush(stdout);
						STRNG_replace_str(cItem_DescDup,","," ",&cItem_DescDup);
						STRNG_replace_str(cItem_DescDup,";"," ",&cItem_DescDup);
						STRNG_replace_str(cItem_DescDup,"\n"," ",&cItem_DescDup);
						STRNG_replace_str(cItem_DescDup,"'"," ",&cItem_DescDup);
						printf("\n Item Description Final Value: --------> [%s]\n", cItem_DescDup);fflush(stdout);
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ModuleAddress",&ModAddress));
						if(tc_strlen(ModAddress)>0)
						{
							tc_strdup(ModAddress,&ModAddressDup);
						}
						else
						{
							tc_strdup("--",&ModAddressDup);
							printf("\n Module Address Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Aggregate",&Aggregate));
						if(tc_strlen(Aggregate)>0)
						{
							tc_strdup(Aggregate,&AggregateDup);
							trimwhitespace(AggregateDup);
							printf("\n Aggregate Value After Dup & Trim: --------> <%s>", AggregateDup);fflush(stdout);
							STRNG_replace_str(AggregateDup,","," ",&AggregateDup);
							STRNG_replace_str(AggregateDup,";"," ",&AggregateDup);
							STRNG_replace_str(AggregateDup,"\n"," ",&AggregateDup);
							STRNG_replace_str(AggregateDup,"'"," ",&AggregateDup);
							printf("\n Aggregate Final Value: --------> [%s]\n", AggregateDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&AggregateDup);
							printf("\n Aggregate Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_AggregateGroup",&AggregateGroup));
						if(tc_strlen(AggregateGroup)>0)
						{
							tc_strdup(AggregateGroup,&AggregateGroupDup);
							trimwhitespace(AggregateGroupDup);
							printf("\n Aggregate Group Value After Dup & Trim: --------> <%s>", AggregateGroupDup);fflush(stdout);
							STRNG_replace_str(AggregateGroupDup,","," ",&AggregateGroupDup);
							STRNG_replace_str(AggregateGroupDup,";"," ",&AggregateGroupDup);
							STRNG_replace_str(AggregateGroupDup,"\n"," ",&AggregateGroupDup);
							STRNG_replace_str(AggregateGroupDup,"'"," ",&AggregateGroupDup);
							printf("\n Aggregate Group Final Value: --------> [%s]\n", AggregateGroupDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&AggregateGroupDup);
							printf("\n Aggregate Group Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_Module",&Module));
						if(tc_strlen(Module)>0)
						{
							tc_strdup(Module,&ModuleDup);
							trimwhitespace(ModuleDup);
							printf("\n Module Value After Dup & Trim: --------> <%s>", ModuleDup);fflush(stdout);
							STRNG_replace_str(ModuleDup,","," ",&ModuleDup);
							STRNG_replace_str(ModuleDup,";"," ",&ModuleDup);
							STRNG_replace_str(ModuleDup,"\n"," ",&ModuleDup);
							STRNG_replace_str(ModuleDup,"'"," ",&ModuleDup);
							printf("\n Module Final Value: --------> [%s]\n", ModuleDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&ModuleDup);
							printf("\n Module Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_ModuleName",&ModuleName));
						if(tc_strlen(ModuleName)>0)
						{
							tc_strdup(ModuleName,&ModuleNameDup);
							trimwhitespace(ModuleNameDup);
							printf("\n Module Name Value After Dup & Trim: --------> <%s>", ModuleNameDup);fflush(stdout);
							STRNG_replace_str(ModuleNameDup,","," ",&ModuleNameDup);
							STRNG_replace_str(ModuleNameDup,";"," ",&ModuleNameDup);
							STRNG_replace_str(ModuleNameDup,"\n"," ",&ModuleNameDup);
							STRNG_replace_str(ModuleNameDup,"'"," ",&ModuleNameDup);
							printf("\n Module Name Final Value: --------> [%s]\n", ModuleNameDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&ModuleNameDup);
							printf("\n Module Name Value is NULL..!!");fflush(stdout);
						}
						ITK_CALL(AOM_ask_value_string(titemobj_results[i],"t5_CategoryName",&KeywordDes));
						if(tc_strlen(KeywordDes)>0)
						{
							tc_strdup(KeywordDes,&KeywordDesDup);
							trimwhitespace(KeywordDesDup);
							printf("\n Keyword Description Value After Dup & Trim: --------> <%s>", KeywordDesDup);fflush(stdout);
							STRNG_replace_str(KeywordDesDup,","," ",&KeywordDesDup);
							STRNG_replace_str(KeywordDesDup,";"," ",&KeywordDesDup);
							STRNG_replace_str(KeywordDesDup,"\n"," ",&KeywordDesDup);
							STRNG_replace_str(KeywordDesDup,"'"," ",&KeywordDesDup);
							printf("\n Keyword Description Final Value: --------> [%s]\n", KeywordDesDup);fflush(stdout);
						}
						else
						{
							tc_strdup("--",&KeywordDesDup);
							printf("\n Keyword Description Value is NULL..!!");fflush(stdout);
						}
						
						printf(" SubModule Details Start...!!\n");fflush(stdout);
						printf("[1] Sr_No: [%s]\n",sr_no_strDup);fflush(stdout);
						printf("[2] SubModule_No: [%s]\n",item_id_strDup);fflush(stdout);
						printf("[3] Revision: [%s]\n",item_rev_strDup);fflush(stdout);
						printf("[4] Sequence: [%s]\n",item_seq_strDup);fflush(stdout);
						printf("[4.1] Owning_User: [%s]\n",OwnerDup);fflush(stdout);
						printf("[4.2] (NR Revision) ERC-Release-Date: [%s]\n",NRERCRlzdDt);fflush(stdout);
						printf("[5] ERC-Release-Date: [%s]\n",ERCRlzdDt);fflush(stdout);
						printf("[6] DR/AR Status: [%s]\n",DRStatusDup);fflush(stdout);
						printf("[7] PlatForm: [%s]\n",PlatformDup);fflush(stdout);
						printf("[8] JSR CS: [%s]\n",JSRCSDup);fflush(stdout);
						printf("[9] LKN CS: [%s]\n",LKNCSDup);fflush(stdout);
						printf("[10] DWD CS: [%s]\n",DWDCSDup);fflush(stdout);
						printf("[11] SND CS: [%s]\n",SNDCSDup);fflush(stdout);
						printf("[12] PUN CS: [%s]\n",PUNCSDup);fflush(stdout);
						printf("[13] PNR CS: [%s]\n",PNRCSDup);fflush(stdout);
						printf("[14] PPCBU CS: [%s]\n",PPCBUCSDup);fflush(stdout);
						printf("[15] PUV CS: [%s]\n",PUVCSDup);fflush(stdout);
						printf("[16] CAR CS: [%s]\n",CARCSDup);fflush(stdout);
						printf("[17] AHD CS: [%s]\n",AHDCSDup);fflush(stdout);
						printf("[18] RJV CS: [%s]\n",RJVCSDup);fflush(stdout);
						printf("[19] SGR CS: [%s]\n",SGRCSDup);fflush(stdout);
						printf("[20] Description: [%s]\n",cItem_DescDup);fflush(stdout);
						printf("[21] Module_Address [%s]\n",ModAddressDup);fflush(stdout);
						printf("[22] Aggregate [%s]\n",AggregateDup);fflush(stdout);
						printf("[23] Aggregate_Group [%s]\n",AggregateGroupDup);fflush(stdout);
						printf("[24] Module [%s]\n",ModuleDup);fflush(stdout);
						printf("[25] Module_Name [%s]\n",ModuleNameDup);fflush(stdout);
						printf("[26] Keyword_Description [%s]\n",KeywordDesDup);fflush(stdout);
						printf(" SubModule Details End...!!\n");fflush(stdout);
						
						fprintf(fpOutput_file,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",sr_no_strDup,item_id_strDup,item_rev_strDup,item_seq_strDup,OwnerDup,NRERCRlzdDt,ERCRlzdDt,DRStatusDup,PlatformDup,JSRCSDup,LKNCSDup,DWDCSDup,SNDCSDup,PUNCSDup,PNRCSDup,PPCBUCSDup,PUVCSDup,CARCSDup,AHDCSDup,RJVCSDup,SGRCSDup,cItem_DescDup,ModAddressDup,AggregateDup,AggregateGroupDup,ModuleDup,ModuleNameDup,KeywordDesDup);fflush(fpOutput_file);
					}
				}
				else
                {
					printf(" DesignRevision Not Found..!!\n");fflush(stdout);
				}
			}
			else
            {
				printf(" DesignRevision Sequence Query Tag Not Found..!!\n");fflush(stdout);
		    }
			if(titemobj_results)
			{
				MEM_free(titemobj_results);
			}
		}
		fprintf(fpOutput_file,"\n ~~~~~~~~~~~~~~ E N D - O F    R E P O R T ~~~~~~~~~~~~~~~\n");fflush(fpOutput_file);
		fclose(fpOutput_file) ;           
		printf("\n All Part Written Successfully on the Output File....\n");fflush(stdout); 
	}
	else 
	{
		printf("\n Input_File is NULL..!!\n");fflush(stdout);
	}
	printf("\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");fflush(stdout);
	printf("\n ~~~~~~~~~~~~ L I V E      L O N G      &     P R O S P E R ~~~~~~~~~~~~~\n");fflush(stdout);
	
    CLEANUP:
	ITK_CALL(ITK_exit_module(TRUE));	
	return ITK_ok;
}


/***************************************************************************
*
* // ./compile tm_SubModuleDetailsRpt.c
* // ./linkitk -o tm_SubModuleDetailsRpt tm_SubModuleDetailsRpt.o
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_SubModuleDetailsRpt/tm_SubModuleDetailsRpt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_SubModuleDetailsRpt/exepatch.sh .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_SubModuleDetailsRpt/PartList.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_SubModuleDetailsRpt/usage.txt .
* // scp infodba04@172.27.128.199:/user/infodba04/sourav/tm_SubModuleDetailsRpt/SendEmail.sh .
* // ./tm_SubModuleDetailsRpt -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_SubModuleDetailsRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
* // ./tm_SubModuleDetailsRpt -u=loader -p=loader123 -g=dba
*
***************************************************************************/