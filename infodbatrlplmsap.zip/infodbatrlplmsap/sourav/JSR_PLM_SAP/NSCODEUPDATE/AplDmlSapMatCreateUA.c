/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : AplDmlSapMatCreateUA.c
* Created By                   : Amol Narke
* Created On                   : 11/05/2020
* Project                      : Tata Motors TCUA-SAP Interface
* Methods Defined              :
* Description                  : TCUA - SAP DML Wise Material Master Creation
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <tccore/tctype.h>
#include <tccore/aom.h>

//#include <librfc.a>
//#include <ProdSap_functions.a>
//#include "VrCre.h"
#include "wmhelpe.h"
//#include "ppe.h"
#include "bapi.h"


int FetchPlantSpecificData(char* DMLNumber,char* ProjCode);
void displaying_objects(void);
void cll_zbapi_material_savedata_mrp(void);
RFC_RC cll_ccap_ecn_create(RFC_HANDLE);
RFC_RC ccap_ecn_create(RFC_HANDLE hRfc,AENR_API01 *,CSDATA_XFELD *,CSDATA_XFELD *,CSDATA_XFELD *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AENV_API01 *,AEEF_API01 *,AENRB_AENNR *,ITAB_H,ITAB_H,ITAB_H,ITAB_H,ITAB_H,char *);
RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA *,BAPI_MARAX *,BAPI_MARC *,BAPI_MARCX *,BAPI_MPGD *,BAPI_MPGDX *,BAPI_MARD *,BAPI_MARDX *,BAPI_MBEW *,BAPI_MBEWX *,RMMG1_AENNR *,BAPIRET2 *,ITAB_H ,ITAB_H ,ITAB_H,ITAB_H ,ITAB_H ,char *);
RFC_RC zbapi_material_savedata_mrpCreate(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARA	*eBasicView,BAPI_MARAX	*eBasicViewx,BAPI_MARC	*eMrpView,BAPI_MARCX	*eMrpViewx,BAPI_MPGD	*eBapi_Mpgd,BAPI_MPGDX	*eBapi_Mpgdx,BAPI_MARD	*eBapi_Mard,BAPI_MARDX	*eBapi_Mardx,BAPI_MBEW	*eAccView,BAPI_MBEWX	*eAccViewx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,ITAB_H thBapi_Makt,ITAB_H thBapi_Marm,ITAB_H thBapi_Marmx,ITAB_H thBAPIE1PAREX3,ITAB_H thBAPIE1PAREXX3,char *xException);
RFC_RC BAPI_MATERIAL_MARD(RFC_HANDLE hRfc,BAPIMATHEAD *eBapiMatHead,BAPI_MARD *eBapi_Mard,BAPI_MARDX *eBapi_Mardx,RMMG1_AENNR *eRmmg1_Aennr,BAPIRET2 *eBapiret2,char *xException);
RFC_RC allocate_insp_type(void);
RFC_RC allocate_insp_type_vc(void);
RFC_RC cll_zrfc_insptype_alloc(RFC_HANDLE);
RFC_RC vc_zrfc_insptype_alloc(RFC_HANDLE );
int BapiRevcr(char sap_dml_no[13],char sap_part_no[15],char sap_rev_sheet_status[3]);
void cll_zrfc_ac_view_create(void);
void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);
RFC_RC BAPI_MATERIAL_UPDATEDATA(RFC_HANDLE hRfc,BAPIMATHEAD *, BAPI_MARA *, BAPI_MARAX *, BAPIRET2 *,char *);
//RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA	*,BAPI_MARAX	*,BAPIRET2	*,ITAB_H       ,ITAB_H       ,ITAB_H       ,char *);


int Part_CreateChangeFunction(tag_t LatestRev);

FILE* fsuccess;
FILE* fp=NULL;
FILE* finsp;
FILE* fval;

char fsuccess_name[200];
char fisa_name[200];
char fvac_name[200];

WERKS_D eWerks;
static MATNR eMatnr;

tag_t		*TaskRevision		= NULLTAG;
tag_t		TaskRevTag			= NULLTAG;
tag_t		*PartTags			= NULLTAG;

int tcount=0,pcount=0,TaskCnt=0,PartCnt=0;

int apl_dml_flag = 0;
int car_dml = 0;
int go_for_rfc = 0;
int flag_vc_v_tpl = 0;
int flag = 0;
int acc_flag = 0;

char *iSapServer = NULL;
char *part_noDupDes=NULL;
char *part_noDupDesx=NULL;
char *doc_no=NULL;
char *basic_division=NULL;
char *unit_wt=NULL;
char *volume=NULL;
char *vol_unit=NULL;
char *material_group=NULL;
char *doc_noDup=NULL;
char *dwg_typeDup=NULL;
char *tmpDrwNum1=NULL;
char *tmpDrwNum=NULL;
char *tmpDrwRev=NULL;
char *tmpDrwSeq=NULL;
char *dwg_revDup=NULL;
char *dwg_rev=NULL;
char *sizeDup=NULL;
char *sheet_noDup=NULL;
char *OldMatNoDup=NULL;
char *net_wt=NULL;
char *net_wtDup=NULL;
char *gross_wt=NULL;
char *part_noDup=NULL;
char *PartMakeBuyInd=NULL;
char *make_buy_indDup=NULL;
char *make_buy_ind=NULL;
char *mat_type=NULL;
char *store_loc=NULL;
char *store_locDup=NULL;
char *mrp_grp=NULL;
char *mrp_type=NULL;
char *abc_ind=NULL;
char *series=NULL;
char *odstatus=NULL;
char *num;
char *drstatus = NULL;
char *drstatusDup = NULL;
char *mm_pp_status = NULL;
char *partClrIndDup = NULL;
char *partClrInd = NULL;
char *reord_pt = NULL;
char *quota_arrangement_usage = NULL;
char *mrp_controller = NULL;
char *lot_size_key = NULL;
char *fixed_lot_size = NULL;
char *max_stlvl = NULL;
char *blk_ind = NULL;
char *sched_mar_key = NULL;
char *req_grp = NULL;
char *period_ind = NULL;
char *mixedmrp = NULL;
char *cs1_val = NULL;
char *alternativb = NULL;
char *avail_chk = NULL;
char *splan_mat = NULL;
char *splan_plant = NULL;
char *splan_conv_fact = NULL;
char *ind_collect = NULL;
char *rep_mfg_in = NULL;
char *rep_mfg = NULL;
char *stock_det_group = NULL;
char *uoissue = NULL;
char *qua_ins_ind = NULL;
char *doc_req = NULL;
char *grptime = NULL;
char *certificate_type = NULL;
char *qm_proc_ind = NULL;
char *control_key = NULL;
char *catalog_prof = NULL;
char *valuation_cat = NULL;
char *price_con = NULL;
char *std_price = NULL;
char *moving_avg_price = NULL;
char *val_class = NULL;
char *mat_origin = NULL;
char *cost_lot_size = NULL;
char *variance_key = NULL;
char *with_quantity_structure = NULL;
char *costing_split_valuation = NULL;
char *costing_val_class = NULL;
char *MatCrChFlag = NULL;
char *OrgIDDup = NULL;
char *plan_calendar = NULL;
char *profit_centre_sap = NULL;
char *overhd_grp = NULL;
char *myzeroDup3 = NULL;
char *myzeroDup1 = NULL;
char *myzeroDup2 = NULL;
char *myzeroDup4 = NULL;
char *sap_msg = NULL;
char *p;

char *DMLEcnType = NULL;
char *DMLRelStatus = NULL;
char *DMLNumDup = NULL;

char *plantcode=NULL;
char *Plant_MakeBuy=NULL;
char *Plant_StoreLoc=NULL;
char *profit_centre2=NULL;
char *plan_calendar2=NULL;
char *overhd_grp2=NULL;
char *origin_group2=NULL;
char *origin_group=NULL;
char *meas_unit=NULL;
char *desc=NULL;
char *descDup=NULL;
char *DMLDescription=NULL;
char *apl_release_date=NULL;
char *drg_ind=NULL;
char *drg_indDup=NULL;
char *docClass=NULL;
char *spl_proc_key=NULL;
char *PrtRev=NULL;
char *PrtRevDup=NULL;
char *OwnerNameDup=NULL;
char *OwnerName=NULL;
char *proc_type;

char *inputDml=NULL;
char *iPlantCode=NULL;


char *sap_proc_type=NULL;
char *sap_spproc_type=NULL;
char *SAPpstat=NULL;
char *MRPpstat=NULL;
char pstat;
char pstat_mrp;
char pstat_acc;
char proc_Key;
char spl_Key;
char group;

char dml_no_arg[14]={0};
char dml_numAP1[14]={0};

const char *attrs[2];
const char *values[2];

char *dml_no = NULL;
char *plant = NULL;
char *PartNumber = NULL;
char *PartRev = NULL;
char *PartSeq = NULL;
char *Parttype = NULL;
char *Error_message = NULL;
char *MATstatus = NULL;

//drwnum = (char *)malloc(500 * sizeof(char));


#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
void rfc_error(char *);
//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}

int Create_PLMSAP_audit_object ( char *iDmlTask, char *plant, char *PartNumber, char *PartRev, char *PartSeq,char *Parttype, char *Error_message, char *MATstatus);

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}


void getCurrentDateTime(char cCurrentAccessDate[20])
{
        int ch;
        time_t temp;
        struct tm *timeptr;
        char pAccessDate[20];
        char    DateS[4];
        printf("getCurrentDateTime calling..........\n");
        temp = time(NULL);
        tc_strcpy(pAccessDate,"");
        timeptr = (struct tm *)localtime(&temp);
        ch = strftime(pAccessDate,sizeof(pAccessDate)-1,"%d-%b-%Y %H:%M",timeptr);
        tc_strcpy(cCurrentAccessDate,pAccessDate);
        printf("cCurrentAccessDate:%s\n",cCurrentAccessDate);

        printf("Date:%d\n",(timeptr->tm_mday));
        printf("Month:%d\n",(timeptr->tm_mon)+1);
        printf("Year:%d\n",(timeptr->tm_year+1900));
        fflush(stdout);
}


char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

void displaying_objects(void)
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;

	hRfc = BapiLogon();
	printf("\ncalling the change no creation function");
	RfcRc = cll_ccap_ecn_create(hRfc);
	RfcClose(hRfc);
}

RFC_RC BAPI_MATERIAL_UPDATEDATA(RFC_HANDLE hRfc,
						BAPIMATHEAD *eBapiMatHead,
						BAPI_MARA	*eBasicView,
						BAPI_MARAX	*eBasicViewx,
						BAPIRET2	*eBapiret2,
						char *xException)
{
	RFC_PARAMETER Exporting[4];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[1];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	printf("bi");
	Exporting[0].name = "HEADDATA";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfBAPIMATHEAD;
	Exporting[0].leng = sizeof(BAPIMATHEAD);
	Exporting[0].addr = eBapiMatHead;

	Exporting[1].name = "CLIENTDATA";
	Exporting[1].nlen = 10;
	Exporting[1].type = handleOfBAPI_MARA;
	Exporting[1].leng = sizeof(BAPI_MARA);
	Exporting[1].addr = eBasicView;

	Exporting[2].name = "CLIENTDATAX";
	Exporting[2].nlen = 11;
	Exporting[2].type = handleOfBAPI_MARAX;
	Exporting[2].leng = sizeof(BAPI_MARAX);
	Exporting[2].addr = eBasicViewx;

	Exporting[3].name = NULL;

	Tables[0].name = NULL;

	/*Tables[0].name     = "MATERIALDESCRIPTION";
	Tables[0].nlen     = 19;
	Tables[0].type     = handleOfBAPI_MAKT;
	Tables[0].ithandle = thBapi_Makt;

	Tables[1].name = NULL;*/

	//RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);
	RfcRc = RfcCall(hRfc,"BAPI_MATERIAL_SAVEDATA",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK :
			 Importing[0].name = "RETURN";  /*RETURN */
			 Importing[0].nlen = 6;
			 Importing[0].type = TYPC;
			 Importing[0].leng = sizeof(BAPIRET2);
			 Importing[0].addr = eBapiret2;

			 Importing[1].name = NULL;
			 RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
			printf("\nRfcException:%s",RfcException);
			 switch (RfcRc)
			 {
				 case RFC_SYS_EXCEPTION :
					strcpy(xException,RfcException);
					break;
				 case RFC_EXCEPTION :
					strcpy(xException,RfcException);
					break;
				default: ;
			 }
			break;
			default :
				printf("\nNOT RFC OK");
	}

	return RfcRc;
}


int Create_PLMSAP_audit_object ( char *iDmlTask, char *plant, char *PartNumber, char *PartRev, char *PartSeq,char *Parttype, char *Error_message, char *MATstatus)
{
	char *object_name = NULL;
	char StdDate[11] = { 0  };
	char cCurrentAccessDate[20];
	tag_t tItemTypeTag = NULLTAG;
	tag_t tItemCreateInputTag = NULLTAG;
	tag_t tItemTag = NULLTAG;
	date_t transfer_date;

	plant = (char *) MEM_alloc(10 * sizeof(char ));

	if (tc_strstr(iDmlTask,"APLC")!=NULL)
	{
		tc_strcpy(plant,"1100");
	}
	else if (tc_strstr(iDmlTask,"APLA")!=NULL)
	{
		tc_strcpy(plant,"E201");
	}
	else if (tc_strstr(iDmlTask,"APLP")!=NULL)
	{
		tc_strcpy(plant,"1001");
	}
	else if (tc_strstr(iDmlTask,"APLD")!=NULL)
	{
		tc_strcpy(plant,"1500");
	}
	else if (tc_strstr(iDmlTask,"APLU")!=NULL)
	{
		tc_strcpy(plant,"3100");
	}

	printf("\ndml_no : [%s]\n", iDmlTask);
	printf("\nplant : [%s]\n", plant);
	printf("\nPartNumber : [%s]\n", PartNumber);
	printf("\nPartRev : [%s]\n", PartRev);
	printf("\nPartSeq : [%s]\n", PartSeq);
	printf("\nError_message : [%s]\n", Error_message);
	printf("\nBOM status : [%s]\n", MATstatus);
	getTodayDate(StdDate);
	object_name = MEM_alloc(50);
	sprintf(object_name,"%s_%s",iDmlTask,StdDate);
	printf("object_name : [%s]\n", object_name);

	getCurrentDateTime(cCurrentAccessDate);
	printf("cCurrentAccessDate:%s\n",cCurrentAccessDate);
	ITK_CALL(ITK_string_to_date(cCurrentAccessDate, &transfer_date ));



	ITK_CALL ( TCTYPE_find_type ( "T5_PLMSAP_AU_LOG", NULL, &tItemTypeTag ) ) ;
	ITK_CALL ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_name", object_name ) ) ;		
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Task_number", iDmlTask ) ) ;		
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Part_number", PartNumber ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Revision", PartRev ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Sequence", PartSeq ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Part_type", Parttype ) ) ;//VC/V/A/M/G
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Plant", plant ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Status", MATstatus ) ) ;//mismatch true false Y/N
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Transfer_type", "MAT" ) ) ;//BOM//Material
	//ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Error_message", "Creating BOM for material 585862600130" ) ) ;
	ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Error_message", Error_message ) ) ;
	//ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "t5_Error_message", "BOM for material 585862600130 changed" ) ) ;
	ITK_CALL ( AOM_set_value_date ( tItemCreateInputTag, "t5_Transfer_date", transfer_date ) ) ;
	ITK_CALL ( TCTYPE_create_object ( tItemCreateInputTag, &tItemTag ) ) ;
	ITK_CALL ( AOM_refresh ( tItemTag, 1 ) ) ;	
	ITK_CALL ( AOM_save_with_extensions ( tItemTag ) ) ;
	ITK_CALL ( AOM_unlock ( tItemTag ) ) ;

	return 0;
}


RFC_RC cll_ccap_ecn_create(RFC_HANDLE hRfc)
{
	static RFC_RC RfcRc;
	int status;
	int Cnt=0,pCnt=0;
	char *PartNumC=NULL;
	char *part_typeC=NULL;

	tag_t PartTag1 = NULLTAG;
	tag_t *ChPartTags	= NULLTAG;

	AENR_API01 eChangeHeader;
	CSDATA_XFELD eFlAle;
	CSDATA_XFELD eFlCommitAndWait;
	CSDATA_XFELD eFlNoCommitWork;
	AENV_API01 eObjectBom;
	AENV_API01 eObjectBomCus;
	AENV_API01 eObjectBomDoc;
	AENV_API01 eObjectBomEqui;
	AENV_API01 eObjectBomLoc;
	AENV_API01 eObjectBomMat;
	AENV_API01 eObjectBomPsp;
	AENV_API01 eObjectBomStd;
	AENV_API01 eObjectChar;
	AENV_API01 eObjectCls;
	AENV_API01 eObjectClsMaint;
	AENV_API01 eObjectConfProf;
	AENV_API01 eObjectDep;
	AENV_API01 eObjectDoc;
	AENV_API01 eObjectHazmat;
	AENV_API01 eObjectMat;
	AENV_API01 eObjectPhrase;
	AENV_API01 eObjectPvs;
	AENV_API01 eObjectPvsAlt;
	AENV_API01 eObjectPvsRel;
	AENV_API01 eObjectPvsVar;
	AENV_API01 eObjectSubstance;
	AENV_API01 eObjectTlist;
	AENV_API01 eObjectTlist2;
	AENV_API01 eObjectTlistA;
	AENV_API01 eObjectTlistE;
	AENV_API01 eObjectTlistM;
	AENV_API01 eObjectTlistN;
	AENV_API01 eObjectTlistQ;
	AENV_API01 eObjectTlistR;
	AENV_API01 eObjectTlistS;
	AENV_API01 eObjectTlistT;
	AENV_API01 eObjectValidMatvers;
	AENV_API01 eObjectVarTab;
	AEEF_API01 eValueAssign;
	AENRB_AENNR iChangeNo;
	ITAB_H thAltDates = ITAB_NULL;
	ITAB_H thEffectivity = ITAB_NULL;
	ITAB_H thObjmgrec = ITAB_NULL;
	ITAB_H thTextheader = ITAB_NULL;
	ITAB_H thTextlines = ITAB_NULL;
	char xException[256];

	AEOI_API01 *tObjmgrec;

	//tc_strdup("29.09.2018",&apl_release_date); //Temp Date

	printf("\nChangeNo : %s ",dml_no_arg);
	printf("\nDMLDescription : %s",DMLDescription);
	printf("\nERC_RELEASE_DATE : %s",apl_release_date);
	
	SETCHAR(eChangeHeader.ChangeNo,dml_no_arg);
	SETNUM(eChangeHeader.Status,"01");
	SETCHAR(eChangeHeader.AuthGroup,"");

	SETCHAR(eChangeHeader.ValidFrom,apl_release_date);
	SETCHAR(eChangeHeader.Descript,DMLDescription);
	SETCHAR(eChangeHeader.ReasonChg,"");
	SETCHAR(eChangeHeader.DeletionMark,"");
	SETCHAR(eChangeHeader.IndateRule,"");
	SETCHAR(eChangeHeader.OutdateRule,"");
	SETCHAR(eChangeHeader.Function,"");
	SETCHAR(eChangeHeader.ChangeLeader,"");
	SETCHAR(eChangeHeader.EffectivityType,"");
	SETCHAR(eChangeHeader.OverridingMark,"");
	SETNUM(eChangeHeader.Rank,"");
	SETNUM(eChangeHeader.ReleaseKey,"");
	SETCHAR(eChangeHeader.StatusProfile,"");
	SETCHAR(eChangeHeader.TechRel,"");
	SETCHAR(eChangeHeader.BasicChange,"");
	SETCHAR(eFlAle,"");
	SETCHAR(eFlCommitAndWait,"X");
	SETCHAR(eFlNoCommitWork,"");
	SETCHAR(eObjectBom.Active,"");
	SETCHAR(eObjectBom.Locked,"");
	SETCHAR(eObjectBom.ObjRequ,"");
	SETCHAR(eObjectBom.MgtrecGen,"");
	SETCHAR(eObjectBom.GenNew,"");
	SETCHAR(eObjectBom.GenDialog,"");
	SETCHAR(eObjectBomCus.Active,"");
	SETCHAR(eObjectBomCus.Locked,"");
	SETCHAR(eObjectBomCus.ObjRequ,"");
	SETCHAR(eObjectBomCus.MgtrecGen,"");
	SETCHAR(eObjectBomCus.GenNew,"");
	SETCHAR(eObjectBomCus.GenDialog,"");
	SETCHAR(eObjectBomDoc.Active,"");
	SETCHAR(eObjectBomDoc.Locked,"");
	SETCHAR(eObjectBomDoc.ObjRequ,"");
	SETCHAR(eObjectBomDoc.MgtrecGen,"");
	SETCHAR(eObjectBomDoc.GenNew,"");
	SETCHAR(eObjectBomDoc.GenDialog,"");
	SETCHAR(eObjectBomEqui.Active,"");
	SETCHAR(eObjectBomEqui.Locked,"");
	SETCHAR(eObjectBomEqui.ObjRequ,"");
	SETCHAR(eObjectBomEqui.MgtrecGen,"");
	SETCHAR(eObjectBomEqui.GenNew,"");
	SETCHAR(eObjectBomEqui.GenDialog,"");
	SETCHAR(eObjectBomLoc.Active,"");
	SETCHAR(eObjectBomLoc.Locked,"");
	SETCHAR(eObjectBomLoc.ObjRequ,"");
	SETCHAR(eObjectBomLoc.MgtrecGen,"");
	SETCHAR(eObjectBomLoc.GenNew,"");
	SETCHAR(eObjectBomLoc.GenDialog,"");
	SETCHAR(eObjectBomMat.Active,"X");
	SETCHAR(eObjectBomMat.Locked,"");
	SETCHAR(eObjectBomMat.ObjRequ,"X");
	SETCHAR(eObjectBomMat.MgtrecGen,"X");
	SETCHAR(eObjectBomMat.GenNew,"");
	SETCHAR(eObjectBomMat.GenDialog,"");
	SETCHAR(eObjectBomPsp.Active,"");
	SETCHAR(eObjectBomPsp.Locked,"");
	SETCHAR(eObjectBomPsp.ObjRequ,"");
	SETCHAR(eObjectBomPsp.MgtrecGen,"");
	SETCHAR(eObjectBomPsp.GenNew,"");
	SETCHAR(eObjectBomPsp.GenDialog,"");
	SETCHAR(eObjectBomStd.Active,"");
	SETCHAR(eObjectBomStd.Locked,"");
	SETCHAR(eObjectBomStd.ObjRequ,"");
	SETCHAR(eObjectBomStd.MgtrecGen,"");
	SETCHAR(eObjectBomStd.GenNew,"");
	SETCHAR(eObjectBomStd.GenDialog,"");
	SETCHAR(eObjectChar.Active,"");
	SETCHAR(eObjectChar.Locked,"");
	SETCHAR(eObjectChar.ObjRequ,"");
	SETCHAR(eObjectChar.MgtrecGen,"");
	SETCHAR(eObjectChar.GenNew,"");
	SETCHAR(eObjectChar.GenDialog,"");
	SETCHAR(eObjectCls.Active,"");
	SETCHAR(eObjectCls.Locked,"");
	SETCHAR(eObjectCls.ObjRequ,"");
	SETCHAR(eObjectCls.MgtrecGen,"");
	SETCHAR(eObjectCls.GenNew,"");
	SETCHAR(eObjectCls.GenDialog,"");
	SETCHAR(eObjectClsMaint.Active,"");
	SETCHAR(eObjectClsMaint.Locked,"");
	SETCHAR(eObjectClsMaint.ObjRequ,"");
	SETCHAR(eObjectClsMaint.MgtrecGen,"");
	SETCHAR(eObjectClsMaint.GenNew,"");
	SETCHAR(eObjectClsMaint.GenDialog,"");
	SETCHAR(eObjectConfProf.Active,"");
	SETCHAR(eObjectConfProf.Locked,"");
	SETCHAR(eObjectConfProf.ObjRequ,"");
	SETCHAR(eObjectConfProf.MgtrecGen,"");
	SETCHAR(eObjectConfProf.GenNew,"");
	SETCHAR(eObjectConfProf.GenDialog,"");
	SETCHAR(eObjectDep.Active,"");
	SETCHAR(eObjectDep.Locked,"");
	SETCHAR(eObjectDep.ObjRequ,"");
	SETCHAR(eObjectDep.MgtrecGen,"");
	SETCHAR(eObjectDep.GenNew,"");
	SETCHAR(eObjectDep.GenDialog,"");
	SETCHAR(eObjectDoc.Active,"X");
	SETCHAR(eObjectDoc.Locked,"");
	SETCHAR(eObjectDoc.ObjRequ,"X");
	SETCHAR(eObjectDoc.MgtrecGen,"X");
	SETCHAR(eObjectDoc.GenNew,"");
	SETCHAR(eObjectDoc.GenDialog,"");
	SETCHAR(eObjectHazmat.Active,"");
	SETCHAR(eObjectHazmat.Locked,"");
	SETCHAR(eObjectHazmat.ObjRequ,"");
	SETCHAR(eObjectHazmat.MgtrecGen,"");
	SETCHAR(eObjectHazmat.GenNew,"");
	SETCHAR(eObjectHazmat.GenDialog,"");
	SETCHAR(eObjectMat.Active,"X");
	SETCHAR(eObjectMat.Locked,"");
	SETCHAR(eObjectMat.ObjRequ,"X");
	SETCHAR(eObjectMat.MgtrecGen,"X");
	SETCHAR(eObjectMat.GenNew,"");
	SETCHAR(eObjectMat.GenDialog,"");
	SETCHAR(eObjectPhrase.Active,"");
	SETCHAR(eObjectPhrase.Locked,"");
	SETCHAR(eObjectPhrase.ObjRequ,"");
	SETCHAR(eObjectPhrase.MgtrecGen,"");
	SETCHAR(eObjectPhrase.GenNew,"");
	SETCHAR(eObjectPhrase.GenDialog,"");
	SETCHAR(eObjectPvs.Active,"");
	SETCHAR(eObjectPvs.Locked,"");
	SETCHAR(eObjectPvs.ObjRequ,"");
	SETCHAR(eObjectPvs.MgtrecGen,"");
	SETCHAR(eObjectPvs.GenNew,"");
	SETCHAR(eObjectPvs.GenDialog,"");
	SETCHAR(eObjectPvsAlt.Active,"");
	SETCHAR(eObjectPvsAlt.Locked,"");
	SETCHAR(eObjectPvsAlt.ObjRequ,"");
	SETCHAR(eObjectPvsAlt.MgtrecGen,"");
	SETCHAR(eObjectPvsAlt.GenNew,"");
	SETCHAR(eObjectPvsAlt.GenDialog,"");
	SETCHAR(eObjectPvsRel.Active,"");
	SETCHAR(eObjectPvsRel.Locked,"");
	SETCHAR(eObjectPvsRel.ObjRequ,"");
	SETCHAR(eObjectPvsRel.MgtrecGen,"");
	SETCHAR(eObjectPvsRel.GenNew,"");
	SETCHAR(eObjectPvsRel.GenDialog,"");
	SETCHAR(eObjectPvsVar.Active,"");
	SETCHAR(eObjectPvsVar.Locked,"");
	SETCHAR(eObjectPvsVar.ObjRequ,"");
	SETCHAR(eObjectPvsVar.MgtrecGen,"");
	SETCHAR(eObjectPvsVar.GenNew,"");
	SETCHAR(eObjectPvsVar.GenDialog,"");
	SETCHAR(eObjectSubstance.Active,"");
	SETCHAR(eObjectSubstance.Locked,"");
	SETCHAR(eObjectSubstance.ObjRequ,"");
	SETCHAR(eObjectSubstance.MgtrecGen,"");
	SETCHAR(eObjectSubstance.GenNew,"");
	SETCHAR(eObjectSubstance.GenDialog,"");
	SETCHAR(eObjectTlist.Active,"");
	SETCHAR(eObjectTlist.Locked,"");
	SETCHAR(eObjectTlist.ObjRequ,"");
	SETCHAR(eObjectTlist.MgtrecGen,"");
	SETCHAR(eObjectTlist.GenNew,"");
	SETCHAR(eObjectTlist.GenDialog,"");
	SETCHAR(eObjectTlist2.Active,"");
	SETCHAR(eObjectTlist2.Locked,"");
	SETCHAR(eObjectTlist2.ObjRequ,"");
	SETCHAR(eObjectTlist2.MgtrecGen,"");
	SETCHAR(eObjectTlist2.GenNew,"");
	SETCHAR(eObjectTlist2.GenDialog,"");
	SETCHAR(eObjectTlistA.Active,"");
	SETCHAR(eObjectTlistA.Locked,"");
	SETCHAR(eObjectTlistA.ObjRequ,"");
	SETCHAR(eObjectTlistA.MgtrecGen,"");
	SETCHAR(eObjectTlistA.GenNew,"");
	SETCHAR(eObjectTlistA.GenDialog,"");
	SETCHAR(eObjectTlistE.Active,"");
	SETCHAR(eObjectTlistE.Locked,"");
	SETCHAR(eObjectTlistE.ObjRequ,"");
	SETCHAR(eObjectTlistE.MgtrecGen,"");
	SETCHAR(eObjectTlistE.GenNew,"");
	SETCHAR(eObjectTlistE.GenDialog,"");
	SETCHAR(eObjectTlistM.Active,"");
	SETCHAR(eObjectTlistM.Locked,"");
	SETCHAR(eObjectTlistM.ObjRequ,"");
	SETCHAR(eObjectTlistM.MgtrecGen,"");
	SETCHAR(eObjectTlistM.GenNew,"");
	SETCHAR(eObjectTlistM.GenDialog,"");
	SETCHAR(eObjectTlistN.Active,"");
	SETCHAR(eObjectTlistN.Locked,"");
	SETCHAR(eObjectTlistN.ObjRequ,"");
	SETCHAR(eObjectTlistN.MgtrecGen,"");
	SETCHAR(eObjectTlistN.GenNew,"");
	SETCHAR(eObjectTlistN.GenDialog,"");
	SETCHAR(eObjectTlistQ.Active,"");
	SETCHAR(eObjectTlistQ.Locked,"");
	SETCHAR(eObjectTlistQ.ObjRequ,"");
	SETCHAR(eObjectTlistQ.MgtrecGen,"");
	SETCHAR(eObjectTlistQ.GenNew,"");
	SETCHAR(eObjectTlistQ.GenDialog,"");
	SETCHAR(eObjectTlistR.Active,"");
	SETCHAR(eObjectTlistR.Locked,"");
	SETCHAR(eObjectTlistR.ObjRequ,"");
	SETCHAR(eObjectTlistR.MgtrecGen,"");
	SETCHAR(eObjectTlistR.GenNew,"");
	SETCHAR(eObjectTlistR.GenDialog,"");
	SETCHAR(eObjectTlistS.Active,"");
	SETCHAR(eObjectTlistS.Locked,"");
	SETCHAR(eObjectTlistS.ObjRequ,"");
	SETCHAR(eObjectTlistS.MgtrecGen,"");
	SETCHAR(eObjectTlistS.GenNew,"");
	SETCHAR(eObjectTlistS.GenDialog,"");
	SETCHAR(eObjectTlistT.Active,"");
	SETCHAR(eObjectTlistT.Locked,"");
	SETCHAR(eObjectTlistT.ObjRequ,"");
	SETCHAR(eObjectTlistT.MgtrecGen,"");
	SETCHAR(eObjectTlistT.GenNew,"");
	SETCHAR(eObjectTlistT.GenDialog,"");
	SETCHAR(eObjectValidMatvers.Active,"");
	SETCHAR(eObjectValidMatvers.Locked,"");
	SETCHAR(eObjectValidMatvers.ObjRequ,"");
	SETCHAR(eObjectValidMatvers.MgtrecGen,"");
	SETCHAR(eObjectValidMatvers.GenNew,"");
	SETCHAR(eObjectValidMatvers.GenDialog,"");
	SETCHAR(eObjectVarTab.Active,"");
	SETCHAR(eObjectVarTab.Locked,"");
	SETCHAR(eObjectVarTab.ObjRequ,"");
	SETCHAR(eObjectVarTab.MgtrecGen,"");
	SETCHAR(eObjectVarTab.GenNew,"");
	SETCHAR(eObjectVarTab.GenDialog,"");
	SETCHAR(eValueAssign.ValidFrom,"");
	SETCHAR(eValueAssign.ValidTo,"");
	SETCHAR(eValueAssign.DateMark,"");
	SETCHAR(eValueAssign.Material,"");
	SETCHAR(eValueAssign.SerialnrLow,"");
	SETCHAR(eValueAssign.SerialnrHigh,"");
	SETCHAR(eValueAssign.Class,"");
	SETCHAR(eValueAssign.Classty,"");
	SETCHAR(eValueAssign.Startup,"");
	SETCHAR(eValueAssign.Plant,"");
	SETCHAR(eValueAssign.SernrOi,"");
	SETCHAR(eValueAssign.FlDelete,"");


    if (thAltDates==ITAB_NULL)
	{
		thAltDates = ItCreate("ALT_DATES", sizeof(AEDT_API01), 0, 0);
		if (thAltDates == ITAB_NULL)
			printf("\nItCreate ALT_DATES");
	}
    else if (ItFree(thAltDates) != 0)
		printf("\nItFree ALT_DATES");

    if (thEffectivity==ITAB_NULL)
	{
		thEffectivity = ItCreate("EFFECTIVITY", sizeof(AEEF_API01), 0, 0);
		if (thEffectivity == ITAB_NULL)
			printf("\nItCreate EFFECTIVITY");
	}
    else if (ItFree(thEffectivity) != 0)
		printf("\nItFree EFFECTIVITY");

	if (thObjmgrec==ITAB_NULL)
	{
		thObjmgrec = ItCreate("OBJMGREC", sizeof(AEOI_API01), 0, 0);
		if (thObjmgrec==ITAB_NULL)
			printf("\nItCreate OBJMGREC");
	}
    else if (ItFree(thObjmgrec) != 0)
		printf("\nItFree OBJMGREC");

    if (thTextheader==ITAB_NULL)
	{
		thTextheader = ItCreate("TEXTHEADER", sizeof(CCTHEAD), 0, 0);
		if (thTextheader==ITAB_NULL)
			printf("\nItCreate TEXTHEADER");
	}
    else if (ItFree(thTextheader) != 0)
		printf("\nItFree TEXTHEADER");

    if (thTextlines==ITAB_NULL)
	{
		thTextlines = ItCreate("TEXTLINES", sizeof(CCTLINE), 0, 0);
		if (thTextlines==ITAB_NULL)
			printf("\nItCreate TEXTLINES");
	}
    else if (ItFree(thTextlines) != 0)
		printf("\nItFree TEXTLINES");

	printf("\nTaskCnt in Displaying Object %d",tcount);
	//fprintf(fsuccess,"\nTaskCnt in Displaying Object %d",tcount);

	for (Cnt=0;Cnt<tcount ;Cnt++ )
	{
		TaskRevTag = TaskRevision[Cnt];
		pCnt=0;
		ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&pCnt,&ChPartTags));
		printf("\nTask To Part Count : %d",pCnt);fflush(stdout);
			
		if(pCnt>0)
		{
			for(PartCnt=0;PartCnt<pCnt;PartCnt++)
			{
				PartTag1=ChPartTags[PartCnt];
				ITK_CALL(AOM_ask_value_string(PartTag1,"item_id",&PartNumC));
				ITK_CALL(AOM_ask_value_string(PartTag1,"t5_PartType",&part_typeC));

				//Skipping Dummy,Dummy Assembly/Component,Info Fit Drw Parts
				if(	tc_strcmp(part_typeC,"D")==0 ||
					tc_strcmp(part_typeC,"DA")==0 ||
					tc_strcmp(part_typeC,"DC")==0 ||
					tc_strcmp(part_typeC,"CM")==0 ||//added 25.03.2023 Hrishikesh
					tc_strcmp(part_typeC,"IFD")==0 ||
					tc_strcmp(part_typeC,"IM")==0 ||
					tc_strcmp(part_typeC,"CP")==0)
				{	continue;	}

				printf("\nAdding partno As Part is %s %s", PartNumC,part_typeC);
				fprintf(fsuccess,"\nAdding partno As Part is %s %s", PartNumC,part_typeC);

				tObjmgrec = ItAppLine(thObjmgrec);
				if (tObjmgrec == NULL)
					printf("\nItAppLine OBJMGREC");

				SETCHAR(tObjmgrec->AltDate,"");
				SETNUM(tObjmgrec->ChgObjtyp,"");
				SETNUM(tObjmgrec->ChgObjtyp,"4");
				SETCHAR(tObjmgrec->BomCat,"");
				SETCHAR(tObjmgrec->BomStdObject,"");
				SETCHAR(tObjmgrec->BomUsage,"");
				SETNUM(tObjmgrec->Chgtypeobj,"");
				SETCHAR(tObjmgrec->DescrObj,"");
				SETCHAR(tObjmgrec->DocType,"");
				SETCHAR(tObjmgrec->DocNumber,"");
				SETCHAR(tObjmgrec->DocVers,"");
				SETCHAR(tObjmgrec->DocPart,"");
				SETCHAR(tObjmgrec->Equipment,"");
				SETCHAR(tObjmgrec->FuncLoc,"");
				SETCHAR(tObjmgrec->Material,PartNumC);
				SETCHAR(tObjmgrec->Plant,"");
				SETCHAR(tObjmgrec->PspElement,"");
				SETCHAR(tObjmgrec->PvsType,"");
				SETCHAR(tObjmgrec->PvsNode,"");
				SETCHAR(tObjmgrec->PvsClassNumber,"");
				SETCHAR(tObjmgrec->PvsClassType,"");
				SETCHAR(tObjmgrec->PvsVariant,"");
				SETCHAR(tObjmgrec->SdOrder,"");
				SETNUM(tObjmgrec->SdOrderI,"");
				SETNUM(tObjmgrec->Textkey,"");
				SETCHAR(tObjmgrec->TlistType,"");
				SETCHAR(tObjmgrec->TlistGrp,"");
				SETCHAR(tObjmgrec->ObjChglock,"");
				SETCHAR(tObjmgrec->StatusProfObj,"");
				SETCHAR(tObjmgrec->FlDelete,"");
			}
		}
	}
	RfcRc = ccap_ecn_create(hRfc,&eChangeHeader,&eFlAle,&eFlCommitAndWait,&eFlNoCommitWork,&eObjectBom,&eObjectBomCus,&eObjectBomDoc,&eObjectBomEqui,&eObjectBomLoc,&eObjectBomMat,&eObjectBomPsp,&eObjectBomStd,&eObjectChar,&eObjectCls,&eObjectClsMaint,&eObjectConfProf,&eObjectDep,&eObjectDoc,&eObjectHazmat,&eObjectMat,&eObjectPhrase,&eObjectPvs,&eObjectPvsAlt,&eObjectPvsRel,&eObjectPvsVar,&eObjectSubstance,&eObjectTlist,&eObjectTlist2,&eObjectTlistA,&eObjectTlistE,&eObjectTlistM,&eObjectTlistN,&eObjectTlistQ,&eObjectTlistR,&eObjectTlistS,&eObjectTlistT,&eObjectValidMatvers,&eObjectVarTab,&eValueAssign,&iChangeNo,thAltDates,thEffectivity,thObjmgrec,thTextheader,thTextlines,xException);
	switch (RfcRc)
	{
		case RFC_OK:
			printf("\necn create: %u",RFC_OK);
			fprintf(fsuccess,"\necn create: %u",RFC_OK);
		break;
		case RFC_EXCEPTION :
			printf("\nRFC Exception: %s",xException);
			fprintf(fsuccess,"\nRFC Exception: %s",xException);
		break;
		default:;
	}
	EXIT:
	printf("exit from bapi");
	return RfcRc;
}

FetchPlantSpecificData(char* DMLNumber,char* ProjCode)
{
	char	*DMLNo			= NULL;
	char	*PlantSuffix	= NULL;
	char	*SAPLivFlg		= NULL;
	
	int     n_entry			= 3;
	int     p_entry			= 2;
	int		ContObjCnt		= 0;

	tag_t   PlantCodeQryTag     = NULLTAG;
	tag_t   MakeBuyQryTag		= NULLTAG;
	tag_t   PlantDataQryTag     = NULLTAG;
	tag_t   *ContorlObjTag     = NULLTAG;

	char    *qry_entryApl[3]  = {"SYSCD","SUBSYSCD","Information-1"};
	char    *qry_entryStd[3]  = {"SYSCD","SUBSYSCD","Information-2"};

	char    *qry_entryMake[2] = {"SYSCD","SUBSYSCD"};

	DMLNo = strtok(DMLNumber, "_" );
	PlantSuffix  = strtok ( NULL, "_" );
	
	tc_strcpy(dml_no_arg,DMLNo);
	tc_strcpy(dml_numAP1,DMLNo);

	profit_centre_sap = (char *)malloc(100 * sizeof(char));

	printf("\nDMLNo [%s]	PlantSuffix [%s]	Project Code [%s]", DMLNo,PlantSuffix,ProjCode);

	char	*qry_value[3] = {"XFRDML",ProjCode,PlantSuffix};
	
	if(QRY_find2("Control Objects...", &PlantCodeQryTag));

	if(PlantCodeQryTag)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		if(QRY_execute(PlantCodeQryTag,n_entry,qry_entryApl,qry_value,&ContObjCnt,&ContorlObjTag));

		if (ContObjCnt==0)
		{
			if(QRY_execute(PlantCodeQryTag,n_entry,qry_entryStd,qry_value,&ContObjCnt,&ContorlObjTag));
		}

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&plantcode);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&SAPLivFlg);
			printf("\nPlantSuffix [%s]	Plant Code [%s]",PlantSuffix,plantcode);
		}
		else
		{
			printf("\nProjectCode [%s] do not have entry in Control Object PlantDML for Suffix [%s] hence exiting!",ProjCode,PlantSuffix); fflush(stdout);
			goto CLEANUP;
		}

		char    *qry_MakeValue[2]  = {"MAKEBUY",plantcode};
		
		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_MakeValue,&ContObjCnt,&ContorlObjTag));

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&Plant_StoreLoc);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&Plant_MakeBuy);
			printf("\nPlant Code [%s]	Plant_MakeBuy [%s]	Plant_StoreLoc [%s]",plantcode,Plant_MakeBuy,Plant_StoreLoc);
		}
		else
		{
			printf("\nPlantcode [%s] do not have entry in Control Object MAKEBUY hence exiting!",plantcode); fflush(stdout);
			goto CLEANUP;
		}



		char    *qry_PlantValue[2]  = {"PLANTDATA",plantcode};

		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_PlantValue,&ContObjCnt,&ContorlObjTag));
		
		printf("\nContObjCnt:%d",ContObjCnt);
		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&profit_centre2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&plan_calendar2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&overhd_grp2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&origin_group2);

			tc_strcpy(profit_centre_sap,"000");
			tc_strcat(profit_centre_sap,profit_centre2);
			tc_strdup(plan_calendar2,&plan_calendar);
			tc_strdup(overhd_grp2,&overhd_grp);
			tc_strdup(origin_group2,&origin_group);

			printf("\nplantcode      :[%s]",plantcode);
			printf("\nprofit_centre  :[%s]",profit_centre_sap);
			printf("\nplan_calendar  :[%s]",plan_calendar);
			printf("\noverhd_grp     :[%s]",overhd_grp);
			printf("\norigin_group   :[%s]",origin_group);
		}
		if(tc_strcmp(plantcode,"1100")==0)
		{
			//nlsStrCpy(plantcode,"1100");
			/*profit_centre2=(char *) MEM_alloc(15 * sizeof(char));
			plan_calendar2=(char *) MEM_alloc(15 * sizeof(char));
			overhd_grp2=(char *) MEM_alloc(15 * sizeof(char));
			origin_group2=(char *) MEM_alloc(15 * sizeof(char));
			tc_strcpy(profit_centre2,"2511200");

			tc_strcpy(profit_centre_sap,"000");
			tc_strcat(profit_centre_sap,profit_centre2);

			tc_strdup(plan_calendar2,"CAR");
			tc_strdup(overhd_grp2,"ZG110000");
			tc_strdup(origin_group2,"0005");*/

			plan_calendar = (char *)malloc(100 * sizeof(char));
			overhd_grp = (char *)malloc(100 * sizeof(char));
			origin_group = (char *)malloc(100 * sizeof(char));

			tc_strcpy(profit_centre_sap,"0002511200");
			tc_strcpy(plan_calendar,"CAR");
			tc_strcpy(overhd_grp,"ZG110000");
			tc_strcpy(origin_group,"0005");

			printf("\nplantcode 1     :[%s]",plantcode);
			printf("\nprofit_centre1  :[%s]",profit_centre_sap);
			printf("\nplan_calendar1  :[%s]",plan_calendar);
			printf("\noverhd_grp1     :[%s]",overhd_grp);
			printf("\norigin_group1   :[%s]",origin_group);

			ContObjCnt = 1;
		}

		
		if (tc_strlen(PlantSuffix)>3)
		{
			dml_no_arg[10] = PlantSuffix[3];
			dml_no_arg[11] = 'P';
			dml_no_arg[12] = '\0';

			dml_numAP1[10] = PlantSuffix[3];
			dml_numAP1[11] = 'P';
			dml_numAP1[12] = '\0';
		}
		else
		{
			tc_strcat(dml_no_arg,"AP");
			tc_strcat(dml_numAP1,"AP");
		}
	}

	CLEANUP:
	return ContObjCnt;
}

//RFC_RC allocate_insp_type(void)
//{
//	static RFC_HANDLE hRfc;
//	static RFC_RC RfcRc;
//
//	hRfc = BapiLogon();
//	printf("\nReturned value = %u", hRfc);
//	if (hRfc == RFC_HANDLE_NULL)
//		printf("\nRfcOpen");
//	if (hRfc == 0)
//	{
//		printf("\nRFC connection is not present.");
//	}
//	else
//		RfcRc = cll_zrfc_insptype_alloc(hRfc);
//	//fprintf(fsuccess,"\n******************************************************************");
//	RfcClose(hRfc);
//	printf("\nRFC connection is closed\n");
//	return RfcRc;
//}


//zrfc_insptype_alloc(RFC_HANDLE hRfc,MATNR *eMatnr,QPART *eQpart,WERKS_D *eWerks,MESSAGEINF *iMessg,SYST_SUBRC *iRetval,char *xException)
//{
//	RFC_PARAMETER Exporting[4];
//	RFC_PARAMETER Importing[3];
//	RFC_TABLE Tables[1];
//	RFC_RC RfcRc;
//	char *RfcException = NULL;
//
//	Exporting[0].name = "MATNR";
//	Exporting[0].nlen = 5;
//	Exporting[0].type = handleOfMATNR;
//	Exporting[0].leng = sizeof(MATNR);
//	Exporting[0].addr = eMatnr;
//
//	Exporting[1].name = "QPART";
//	Exporting[1].nlen = 5;
//	Exporting[1].type = handleOfQPART;
//	Exporting[1].leng = sizeof(QPART);
//	Exporting[1].addr = eQpart;
//
//	Exporting[2].name = "WERKS";
//	Exporting[2].nlen = 5;
//	Exporting[2].type = handleOfWERKS_D;
//	Exporting[2].leng = sizeof(WERKS_D);
//	Exporting[2].addr = eWerks;
//
//	Exporting[3].name = NULL;
//
//	Tables[0].name = NULL;
//
//	RfcRc = RfcCall(hRfc,"ZRFC_INSPTYPE_ALLOC",Exporting,Tables);
//
//	switch (RfcRc)
//	{
//	  	case RFC_OK :
//			Importing[0].name = "MESSG";
//			Importing[0].nlen = 5;
//			Importing[0].type = handleOfMESSAGEINF;
//			Importing[0].leng = sizeof(MESSAGEINF);
//			Importing[0].addr = iMessg;
//
//			Importing[1].name = "RETVAL";
//			Importing[1].nlen = 6;
//			Importing[1].type = TYPINT;
//			Importing[1].leng = sizeof(SYST_SUBRC);
//			Importing[1].addr = iRetval;
//
//			Importing[2].name = NULL;
//			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
//			switch (RfcRc)
//			{
//	  			case RFC_SYS_EXCEPTION:
//					strcpy(xException,RfcException);
//					break;
//				case RFC_EXCEPTION:
//					strcpy(xException,RfcException);
//					break;
//			}
//	}
//	return RfcRc;
//}

//void get_origingroup(void)
//{
//	char *dw;
//	int partlen;
//
//	partlen = strcspn(part_noDup, " ");
//	dw = subString(part_noDup,0,2);
//
//
//	if (tc_strcmp(make_buy_indDup, "F  ") == 0)
//	{
//		if (car_dml == 1)
//		{
//			strcpy(origin_group,origin_group2);
//		}
//		if (car_dml == 0)
//		{
//			strcpy(origin_group,origin_group2);
//
//		}
//		if ((partlen == 11) && tc_strcmp(dw, "55") == 0)
//		{
//			strcpy(origin_group,origin_group2);
//		}
//
//		if (tc_strcmp(mat_type, "ROH") == 0)
//		{
//			strcpy(origin_group,origin_group2);
//		}
//	}
//	else
//	{
//		strcpy(origin_group,origin_group2);
//	}
//}


RFC_RC export_CSpastat(RFC_HANDLE hRfc,MATNR *eMatnr,WERKS_D* eWerks,PLANTDATA* iMrpView, CLIENTDATA* iView, char *xException)
{
	RFC_RC RfcRc;
	RFC_PARAMETER Exporting[3];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[1];
	char *RfcException = NULL;

	Exporting[0].name = "MATERIAL";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfMATNR;
	Exporting[0].leng = sizeof(MATNR);
	Exporting[0].addr = eMatnr;

	Exporting[1].name = "PLANT";
	Exporting[1].nlen = 5;
	Exporting[1].type = handleOfWERKS_D;
	Exporting[1].leng = sizeof(WERKS_D);
	Exporting[1].addr = eWerks;

	Exporting[2].name = NULL;


	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"BAPI_MATERIAL_GETALL",Exporting,Tables);

	switch (RfcRc)
	{
	  	case RFC_OK :

			Importing[0].name = "CLIENTDATA";
			Importing[0].nlen = 10;
			Importing[0].type = handleOfCLIENTDATA;
			Importing[0].leng = sizeof(CLIENTDATA);
			Importing[0].addr = iView;

			Importing[1].name = "PLANTDATA";
			Importing[1].nlen = 9;
			Importing[1].type = handleOfPLANTDATA;
			Importing[1].leng = sizeof(PLANTDATA);
			Importing[1].addr = iMrpView;

			Importing[2].name = NULL;

			RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);

			switch (RfcRc)
			{
	  			case RFC_SYS_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				case RFC_EXCEPTION:
					strcpy(xException,RfcException);
					break;
				default: ;
			}
		default: ;
	}
	return RfcRc;
}

int GetCSPstat(/*char cMaterial[15]*/void)
{
char *xException=NULL;
RFC_HANDLE hRfc;
RFC_RC RfcRc;
MATNR eMatnr;
WERKS_D eWerks;
PLANTDATA iMrpView;
CLIENTDATA iView;

printf("\nProcessing GetCSPstat:[%s,%s]",part_noDup,plantcode);

hRfc = BapiLogon();

//strcpy(sap_proc_type,"");
//strcpy(sap_spproc_type,"");
strcpy(SAPpstat,"");
strcpy(MRPpstat,"");

//SETCHAR(eMatnr.Matnr,cMaterial);
SETCHAR(eMatnr.Matnr,part_noDup);
SETCHAR(eWerks.WerksD,plantcode);


RfcRc = export_CSpastat(hRfc
				,&eMatnr
				,&eWerks
				,&iMrpView
				,&iView
				,xException);

switch (RfcRc)
{
	case RFC_OK:
		//printf("\n In RFC_OK case...\n");	fflush(stdout);
		//GETCHAR(iMrpView.PROC_TYPE, proc_type1);		OUTS("PROC_TYPE",10,30,proc_type1);
		//GETCHAR(iMrpView.SPPROCTYPE, spproc_type);		OUTS("SPPROCTYPE",10,30,spproc_type);

		GETCHAR(iMrpView.PROC_TYPE, sap_proc_type);		//OUTS("PROC_TYPE",10,30,sap_proc_type);
		GETCHAR(iMrpView.SPPROCTYPE, sap_spproc_type);	//OUTS("SPPROCTYPE",10,30,sap_spproc_type);

		GETCHAR(iView.MAINT_STAT, SAPpstat);
		SAPpstat[14] = '\0';
		//OUTS("SAPpstat",10,30,SAPpstat);

		GETCHAR(iMrpView.MAINT_STAT, MRPpstat);
		MRPpstat[14] = '\0';
		//OUTS("MRPpstat",10,30,MRPpstat);

		//printf("\n...SAPpstat:[%s]\n\n",SAPpstat);
		//printf("\n...Material[%s]; proc_type1:[%s]; spproc_type:[%s]; SAPpstat:[%s]\n\n",cMaterial,proc_type1,spproc_type,SAPpstat);

	break;
	case RFC_EXCEPTION:
		printf("\nRFC Exception : %s",xException);
		exit(0);
	break;
	case RFC_SYS_EXCEPTION:
		printf("\nSystem Exception Raised!!!");
		exit(0);
	break;
	case RFC_FAILURE:
		printf("\nFailure!!!");
		exit(0);
	break;
	default:
		printf("\nOther Failure!");
		exit(0);
}

RfcClose(hRfc);
return 0;
}

int pstat_basicFun(void)
{
	//printf("\n In pstat_basicFun function..[%s]\n",sappstat); fflush(stdout);
	if(tc_strlen(tc_strstr(SAPpstat,"K"))>0)
	{
		pstat = 'K';
	}
	else
	{
		pstat = '0';
	}

	
   if(tc_strlen(tc_strstr(MRPpstat,"D"))>0)
	{
		pstat_mrp = 'D';
	}
	else
	{
		pstat_mrp = '0';
	}

	
  if(tc_strlen(tc_strstr(MRPpstat,"B"))>0)
	{
		pstat_acc = 'B';
	}
	else
	{
		pstat_acc = '0';
	}
	//printf("\n..%c:%c:%c..\n",pstat,pstat_mrp,pstat_acc); fflush(stdout);
	return 0;
}


//void mat_create()
//{
//	printf("\nmmat_create");
//	//cll_BAPI_MATERIAL_SAVEREPLICA();
//	UPD_BAPI_MATERIAL_SAVEDATA();
//	go_for_rfc = 1;
//	fprintf(fsuccess,"\n******************************************************************");
//	if (tc_strcmp(mat_type, "FERT") == 0 && apl_dml_flag == 2)
//	{
//		printf("\nmat_type = FERT and apl_dml_flag = 2");
//	}
//	else
//	{
//
//		go_for_rfc = 1;
//	}
//}


void UPD_BAPI_MATERIAL_SAVEDATA(void)
{
	static RFC_RC RfcRc;
	static RFC_HANDLE hRfc;
	char xException[256];

	BAPIMATHEAD eBapiMatHead;
	BAPI_MARA	eBasicView;
	BAPI_MARAX	eBasicViewx;
	BAPIRET2	eBapiret2;



	printf("\nInside Design Drawing Version update");
	fprintf(fsuccess,"\nInside Design Drawing Version update");

	hRfc = BapiLogon();
	SETCHAR(eBapiMatHead.Material,part_noDup);
	SETCHAR(eBapiMatHead.Ind_Sector,"M");
	SETCHAR(eBapiMatHead.Matl_Type,mat_type);
	SETCHAR(eBapiMatHead.Basic_View,"X");
	
	printf("\n before updation : Partno,  Material Group: [%s], [%s]", part_noDup,material_group);


	if (tc_strcmp(material_group, "ZZZZZZ") == 0)
	{
	SETCHAR(eBasicView.Matl_Group,"");
	SETCHAR(eBasicViewx.Matl_Group,"");
	printf("\n Not updated.....Partno,  Material Group: [%s], [%s]", part_noDup,material_group);
	}
	else
	{
	SETCHAR(eBasicView.Matl_Group,material_group);
	SETCHAR(eBasicViewx.Matl_Group,"X");
	printf("\n Updated......Partno,  Material Group: [%s], [%s]", part_noDup,material_group);
	}

	SETCHAR(eBasicView.Base_Uom,"");
	SETCHAR(eBasicViewx.Base_Uom,"");

	SETCHAR(eBasicView.Division,"");
	SETCHAR(eBasicViewx.Division,"");

	SETBCD(eBasicView.Net_Weight,myzeroDup3,3);
	SETCHAR(eBasicViewx.Net_Weight,"");

	SETCHAR(eBasicView.Unit_Of_Wt,"");
	SETCHAR(eBasicViewx.Unit_Of_Wt,"");
	SETCHAR(eBasicView.Unit_Of_Wt_Iso,"");
	SETCHAR(eBasicViewx.Unit_Of_Wt_Iso,"");

	SETCHAR(eBasicView.Size_Dim,"");
	SETCHAR(eBasicViewx.Size_Dim,"");

	SETNUM(eBasicView.No_Sheets,"");//000
	SETCHAR(eBasicViewx.No_Sheets,"");

	SETCHAR(eBapiMatHead.Account_View,"");
	SETCHAR(eBapiMatHead.Cost_View,"");
	SETCHAR(eBapiMatHead.Forecast_View,"");
	SETCHAR(eBapiMatHead.Inp_Fld_Check,"");
	SETCHAR(eBapiMatHead.MateriaL_Guid,"");
	SETCHAR(eBapiMatHead.Material_External,"");
	SETCHAR(eBapiMatHead.Material_Version,"");
	SETCHAR(eBapiMatHead.Prt_View,"");
	SETCHAR(eBapiMatHead.Purchase_View,"");
	SETCHAR(eBapiMatHead.Quality_View,"");	/*quality view*/
	SETCHAR(eBapiMatHead.Sales_View,"");
	SETCHAR(eBapiMatHead.Warehouse_View,"");
	SETCHAR(eBapiMatHead.Work_Sched_View,"");

	SETBCD(eBasicView.Allowed_Wt,myzeroDup3,3);
	SETBCD(eBasicView.Allwd_Vol,myzeroDup3,3);
	SETBCD(eBasicView.Fill_Level,"0",0);
	SETBCD(eBasicView.Minremlife,"0",0);

	SETBCD(eBasicView.Qty_Gr_Gi,myzeroDup3,3);
	SETBCD(eBasicView.Shelf_Life,"0",0);
	SETBCD(eBasicView.Stor_Pct,"0",0);
	SETBCD(eBasicView.Vol_Tol_Lt,myzeroDup1,1);
	SETBCD(eBasicView.Wt_Tol_Lt,myzeroDup1,1);
	SETCHAR(eBasicView.Appd_B_Rec,"");
	SETCHAR(eBasicView.Authoritygroup,"");

	SETCHAR(eBasicView.Base_Uom_Iso,"");
	SETCHAR(eBasicView.Basic_Matl,"");
	SETCHAR(eBasicView.Batch_Mgmt,"");
	SETCHAR(eBasicView.Cad_Id,"");
	SETCHAR(eBasicView.Catprofile,"");
	SETCHAR(eBasicView.Closed_Box,"");
	SETCHAR(eBasicView.Cm_Relevance_Flag,"");
	SETCHAR(eBasicView.Competitor,"");
	SETCHAR(eBasicView.Container,"");
	SETCHAR(eBasicView.Del_Flag,"");

	SETCHAR(eBasicView.Doc_Chg_No,"");
	SETCHAR(eBasicView.Doc_Format,"");
	SETCHAR(eBasicView.Doc_Type,"");
	SETCHAR(eBasicView.Doc_Vers,"");
	SETCHAR(eBasicView.Document,"");
	SETCHAR(eBasicView.Dsn_Office,"");
	SETCHAR(eBasicView.Envt_Rlvt,"");
	SETCHAR(eBasicView.Extmatlgrp,"");
	SETCHAR(eBasicView.Gtin_Variant,"");
	SETCHAR(eBasicView.Haz_Mat_No,"");
	SETCHAR(eBasicView.Haz_Mat_No_External,"");
	SETCHAR(eBasicView.Haz_Mat_No_Guid,"");
	SETCHAR(eBasicView.Haz_Mat_No_Version,"");
	SETCHAR(eBasicView.Hazmatprof,"");
	SETCHAR(eBasicView.High_Visc,"");
	SETCHAR(eBasicView.Inv_Mat_No,"");
	SETCHAR(eBasicView.Inv_Mat_No_External,"");
	SETCHAR(eBasicView.Inv_Mat_No_Guid,"");
	SETCHAR(eBasicView.Inv_Mat_No_Version,"");
	SETCHAR(eBasicView.Item_Cat,"");
	SETCHAR(eBasicView.Label_Form,"");
	SETCHAR(eBasicView.Label_Type,"");
	SETCHAR(eBasicView.Looseorliq,"");
	SETCHAR(eBasicView.Manu_Mat,"");
	SETCHAR(eBasicView.Manuf_Prof,"");
	SETCHAR(eBasicView.Mat_Grp_Sm,"");
	SETCHAR(eBasicView.Material_Fixed,"");

	SETCHAR(eBasicView.Mfr_No,"");
	//SETCHAR(eBasicView.Old_Mat_No,"855001");
	SETCHAR(eBasicView.Old_Mat_No,"");
	SETCHAR(eBasicView.Pack_Vo_Un,"");
	SETCHAR(eBasicView.Pack_Vo_Un_Iso,"");
	SETCHAR(eBasicView.Pack_Wt_Un,"");
	SETCHAR(eBasicView.Pack_Wt_Un_Iso,"");
	SETCHAR(eBasicView.Page_No,"");
	SETCHAR(eBasicView.Pageformat,"");
	SETCHAR(eBasicView.Par_Eff,"");
	SETCHAR(eBasicView.Period_Ind_Expiration_Date,"");
	SETCHAR(eBasicView.Pl_Ref_Mat,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_External,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_Guid,"");
	SETCHAR(eBasicView.Pl_Ref_Mat_Version,"");
	SETCHAR(eBasicView.Po_Unit,"");
	SETCHAR(eBasicView.Po_Unit_Iso,"");
	SETCHAR(eBasicView.Proc_Rule,"");
	SETCHAR(eBasicView.Prod_Alloc,"");
	SETCHAR(eBasicView.Prod_Composition_On_Packaging,"");
	SETCHAR(eBasicView.Prod_Hier,"");
	SETCHAR(eBasicView.Prod_Memo,"");
	SETCHAR(eBasicView.Pur_Status,"");
	SETCHAR(eBasicView.Pur_Valkey,"");
	SETCHAR(eBasicView.Qm_Procmnt,"");
	SETCHAR(eBasicView.Qual_Dik,"");
	SETCHAR(eBasicView.Round_Up_Rule_Expiration_Date,"");
	SETCHAR(eBasicView.Sal_Status,"");
	SETCHAR(eBasicView.Season,"");
	SETCHAR(eBasicView.Serialization_Level,"");
	SETCHAR(eBasicView.Sh_Mat_Typ,"");
	
	SETCHAR(eBasicView.Sled_Bbd,"");
	SETCHAR(eBasicView.Std_Descr,"");
	SETCHAR(eBasicView.Stor_Conds,"");
	SETCHAR(eBasicView.Sup_Source,"");
	SETCHAR(eBasicView.Temp_Conds,"");
	SETCHAR(eBasicView.Trans_Grp,"");
	SETCHAR(eBasicView.Uomusage,"");
	SETCHAR(eBasicView.Var_Ord_Un,"");
	SETDATE(eBasicView.Pvalidfrom,"");
	SETDATE(eBasicView.Svalidfrom,"");
	SETINT2(&eBasicView.Stack_Fact,"0");
	SETNUM(eBasicView.Matcmpllvl,"00");
	

	SETCHAR(eBasicViewx.Allowed_Wt,"");
	SETCHAR(eBasicViewx.Allwd_Vol,"");
	SETCHAR(eBasicViewx.Appd_B_Rec,"");
	SETCHAR(eBasicViewx.Authoritygroup,"");

	SETCHAR(eBasicViewx.Base_Uom_Iso,"");
	SETCHAR(eBasicViewx.Basic_Matl,"");
	SETCHAR(eBasicViewx.Batch_Mgmt,"");
	SETCHAR(eBasicViewx.Cad_Id,"");
	SETCHAR(eBasicViewx.Catprofile,"");
	SETCHAR(eBasicViewx.Closed_Box,"");
	SETCHAR(eBasicViewx.Cm_Relevance_Flag,"");
	SETCHAR(eBasicViewx.Competitor,"");
	SETCHAR(eBasicViewx.Container,"");
	SETCHAR(eBasicViewx.Del_Flag,"");

	SETCHAR(eBasicViewx.Doc_Chg_No,"");
	SETCHAR(eBasicViewx.Doc_Format,"");
	SETCHAR(eBasicViewx.Doc_Type,"");
	SETCHAR(eBasicViewx.Doc_Vers,"");
	SETCHAR(eBasicViewx.Document,"");
	SETCHAR(eBasicViewx.Dsn_Office,"");
	SETCHAR(eBasicViewx.Envt_Rlvt,"");
	SETCHAR(eBasicViewx.Extmatlgrp,"");
	SETCHAR(eBasicViewx.Fill_Level,"");
	SETCHAR(eBasicViewx.Gtin_Variant,"");
	SETCHAR(eBasicViewx.Haz_Mat_No,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_External,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_Guid,"");
	SETCHAR(eBasicViewx.Haz_Mat_No_Version,"");
	SETCHAR(eBasicViewx.Hazmatprof,"");
	SETCHAR(eBasicViewx.High_Visc,"");
	SETCHAR(eBasicViewx.Inv_Mat_No,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_External,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_Guid,"");
	SETCHAR(eBasicViewx.Inv_Mat_No_Version,"");
	SETCHAR(eBasicViewx.Item_Cat,"");
	SETCHAR(eBasicViewx.Label_Form,"");
	SETCHAR(eBasicViewx.Label_Type,"");
	SETCHAR(eBasicViewx.Looseorliq,"");
	SETCHAR(eBasicViewx.Manu_Mat,"");
	SETCHAR(eBasicViewx.Manuf_Prof,"");
	SETCHAR(eBasicViewx.Mat_Grp_Sm,"");
	SETCHAR(eBasicViewx.Matcmpllvl,"");
	SETCHAR(eBasicViewx.Material_Fixed,"");

	SETCHAR(eBasicViewx.Mfr_No,"");
	SETCHAR(eBasicViewx.Minremlife,"");

	
	SETCHAR(eBasicViewx.Old_Mat_No,"");
	SETCHAR(eBasicViewx.Pack_Vo_Un,"");
	SETCHAR(eBasicViewx.Pack_Vo_Un_Iso,"");
	SETCHAR(eBasicViewx.Pack_Wt_Un,"");
	SETCHAR(eBasicViewx.Pack_Wt_Un_Iso,"");
	SETCHAR(eBasicViewx.Page_No,"");
	SETCHAR(eBasicViewx.Pageformat,"");
	SETCHAR(eBasicViewx.Par_Eff,"");
	SETCHAR(eBasicViewx.Period_Ind_Expiration_Date,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_External,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_Guid,"");
	SETCHAR(eBasicViewx.Pl_Ref_Mat_Version,"");
	SETCHAR(eBasicViewx.Po_Unit,"");
	SETCHAR(eBasicViewx.Po_Unit_Iso,"");
	SETCHAR(eBasicViewx.Proc_Rule,"");
	SETCHAR(eBasicViewx.Prod_Alloc,"");
	SETCHAR(eBasicViewx.Prod_Composition_On_Packaging,"");
	SETCHAR(eBasicViewx.Prod_Hier,"");
	SETCHAR(eBasicViewx.Prod_Memo,"");
	SETCHAR(eBasicViewx.Pur_Status,"");
	SETCHAR(eBasicViewx.Pur_Valkey,"");
	SETCHAR(eBasicViewx.Pvalidfrom,"");
	SETCHAR(eBasicViewx.Qm_Procmnt,"");
	SETCHAR(eBasicViewx.Qty_Gr_Gi,"");
	SETCHAR(eBasicViewx.Qual_Dik,"");
	SETCHAR(eBasicViewx.Round_Up_Rule_Expiration_Date,"");
	SETCHAR(eBasicViewx.Sal_Status,"");
	SETCHAR(eBasicViewx.Season,"");
	SETCHAR(eBasicViewx.Serialization_Level,"");
	SETCHAR(eBasicViewx.Sh_Mat_Typ,"");
	SETCHAR(eBasicViewx.Shelf_Life,"");

	SETCHAR(eBasicViewx.Sled_Bbd,"");
	SETCHAR(eBasicViewx.Stack_Fact,"");
	SETCHAR(eBasicViewx.Std_Descr,"");
	SETCHAR(eBasicViewx.Stor_Conds,"");
	SETCHAR(eBasicViewx.Stor_Pct,"");
	SETCHAR(eBasicViewx.Sup_Source,"");
	SETCHAR(eBasicViewx.Svalidfrom,"");
	SETCHAR(eBasicViewx.Temp_Conds,"");
	SETCHAR(eBasicViewx.Trans_Grp,"");
	SETCHAR(eBasicViewx.Uomusage,"");
	SETCHAR(eBasicViewx.Var_Ord_Un,"");
	SETCHAR(eBasicViewx.Vol_Tol_Lt,"");
	SETCHAR(eBasicViewx.Wt_Tol_Lt,"");







	
	printf("\nhi");

	RfcRc = BAPI_MATERIAL_UPDATEDATA(hRfc
			,&eBapiMatHead
			,&eBasicView
			,&eBasicViewx
			,&eBapiret2
			/*,thBapi_Makt
			,thBapi_Marm
			,thBapi_Marmx*/
			,xException);

	switch (RfcRc)
	{
		case RFC_OK :
					printf("\nMessage for Basic Material Create:-%s",eBapiret2.Message);
					fflush(stdout);
					break;
		case RFC_EXCEPTION :
					printf("\nRFC EXCEPTION:-%s",xException);
					break;
		case RFC_SYS_EXCEPTION :
					printf("\nsystem exception raised");
					break;
		case RFC_FAILURE :
					printf("\nfailure");
					break;
		default :
					printf("\nother failure");
					break;
	}
	RfcClose(hRfc);
}



//CR/PC and CV/AUTO/17/0005


BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;

	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find2("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 0;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}


extern int ITK_user_main (int argc, char ** argv )
{
    int status;
	int d=0;
	int resultCount =0;
	int PartQryOutCount =0;
	int n_entries = 1; //no. of query input arg
	int two_entries = 2; //no. of query input arg

	int n_tags_found = 1;
	int ColCount = 0, cl = 0;

	char  type_name[TCTYPE_name_size_c+1];

	tag_t		queryTag			= NULLTAG;
	tag_t		PartQueryTag		= NULLTAG;
	tag_t		*outTag				= NULLTAG;
	tag_t		DMLTag				= NULLTAG;
	tag_t		objTypeTag			= NULLTAG;
	tag_t		*DesignTags			= NULLTAG;
	tag_t		resultOutputTag		= NULLTAG;
	tag_t		relation_type		= NULLTAG;
	tag_t		PartRevTag			= NULLTAG;


	BAPIMATHEAD eBapiMatHead;
	BAPI_MARA	eBasicView;
	BAPI_MARAX	eBasicViewx;
	BAPIRET2	eBapiret2;
	ITAB_H thBapi_Makt = ITAB_NULL;
	ITAB_H thBapi_Marm = ITAB_NULL;
	ITAB_H thBapi_Marmx = ITAB_NULL;

	char xException[256];
	char x[276];


	BAPI_MAKT		*tBapi_Makt;
	BAPI_MARM		*tBapi_Marm;
	BAPI_MARMX		*tBapi_Marmx;



	char* sUserName	= NULL;
	char* sPassword = NULL;

	char* DMLNum = NULL;
	char* DMLDesc = NULL;
	char* DMLProjCode = NULL;
	char* DMLProjCodeDup = NULL;
	char* DMLRelType = NULL;
	char* DML_Owner = NULL;
	char* object_type = NULL;
	char* taskId = NULL;
	char* DateStr = NULL;
	
	char	*AllColRevSet	= NULL;
	tag_t	*AllColPartTags = NULLTAG;
	tag_t	ColPartTag = NULLTAG;
	char	*ColPartRev = NULL;
	int		PStrCount = 0, i=0, j=0;
	int		num_to_sort = 1;
	int		sort_order[1]  ={2};
	char	*keysAttr[1] = {"creation_date"};

	char	*PartRelStatus = NULL;
	char	**ColPartList =NULL;
	char	*RelRevNumber =NULL;
	char	*Lcs = NULL;

	Lcs = (char *) MEM_alloc(15);
	//tc_strcpy(Lcs,"T5_LcsErcRlzd");
	//tc_strcpy(Lcs,"T5_LcsStdRlzd");
	tc_strcpy(Lcs,"T5_LcsAplRlzd");

	tag_t	*ColPTags = NULLTAG;
	tag_t	ColPTag = NULLTAG;

	date_t APLRelDate;
	date_t STDRelDate;

	char* APLRelDateStr = NULL;
	char* STDRelDateStr = NULL;

    plantcode=(char *) malloc (500 * sizeof(char));
	apl_release_date=(char *) MEM_alloc(40 * sizeof(char));
	DMLDescription=(char *) MEM_alloc(40 * sizeof(char));
	profit_centre2 = (char *)malloc(500 * sizeof(char));
	plan_calendar2 = (char *)malloc(500 * sizeof(char));
	overhd_grp2 = (char *)malloc(500 * sizeof(char));
	origin_group2 = (char *)malloc(500 * sizeof(char));
	origin_group = (char *)malloc(500 * sizeof(char));
	iPlantCode=(char *) malloc( 500 * sizeof(char));
	mat_type=(char *) malloc(500 * sizeof(char));
	meas_unit=(char *) malloc(500 * sizeof(char));

	tmpDrwNum = (char *)malloc(500 * sizeof(char));
	tmpDrwNum1 = (char *)malloc(500 * sizeof(char));
	tmpDrwRev = (char *)malloc(500 * sizeof(char));
	tmpDrwSeq = (char *)malloc(500 * sizeof(char));

	sap_proc_type = (char *)malloc(500 * sizeof(char));
	sap_spproc_type = (char *)malloc(500 * sizeof(char));
	SAPpstat = (char *)malloc(500 * sizeof(char));
	MRPpstat = (char *)malloc(500 * sizeof(char));
	myzeroDup1 = (char *)malloc(500 * sizeof(char));
	myzeroDup2 = (char *)malloc(500 * sizeof(char));
	myzeroDup3 = (char *)malloc(500 * sizeof(char));
	myzeroDup4 = (char *)malloc(500 * sizeof(char));
	std_price = (char *)malloc(500 * sizeof(char));
	moving_avg_price = (char *)malloc(500 * sizeof(char));
	cost_lot_size = (char *)malloc(500 * sizeof(char));
	mat_type = (char *)malloc(500 * sizeof(char));
	descDup = (char *)malloc(500 * sizeof(char));
	reord_pt = (char *)malloc(500 * sizeof(char));

	part_noDupDes = (char *)malloc(500 * sizeof(char));
	part_noDupDesx = (char *)malloc(500 * sizeof(char));

	AllColRevSet     =  (char *) MEM_alloc(100000 * sizeof(char));

	PartNumber	= (char *) MEM_alloc(50 * sizeof(char));
	PartRev	= (char *) MEM_alloc(50 * sizeof(char));
	PartSeq	= (char *) MEM_alloc(50 * sizeof(char));
	Error_message	= (char *) MEM_alloc(200 * sizeof(char));
	MATstatus	= (char *) MEM_alloc(10 * sizeof(char));
	Parttype	= (char *) MEM_alloc(30 * sizeof(char));
	dml_no	= (char *) MEM_alloc(30 * sizeof(char));

	//char *qry_entries[1] = {"Name"};
	//char *qry_entries[1] = {"item_id"};
	char *PartQry_entries[] = {"Item ID","Release Status"};

	char *qry_entries[1] = {"ID"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char **PartQry_values = (char **) MEM_alloc(20 * sizeof(char *));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	inputDml = ITK_ask_cli_argument("-d=");
	iSapServer = ITK_ask_cli_argument("-s=");

	if(tc_strcmp(sUserName,"")==0 || tc_strcmp(sPassword,"")==0 || tc_strcmp(inputDml,"")==0 || tc_strcmp(iSapServer,"")==0)
	{
		printf("\nAplDmlSapMatCreateUA -u=userid -p=password -d=inputDml -s=PVP/EVP/CVP\n");fflush(stdout);
		goto CLEANUP;
	}
    sprintf(fsuccess_name,"%s/PLMSAP/PLM_SAP_APL_LOG/APL_Sap_Mat_NSCODE_%s_%s.log",getenv("ONLREP"),inputDml,iSapServer);
   // sprintf(fsuccess_name,"/home/uadev/devgroups/hps/PLMSAP/liveXfr/APL_Sap_Mat_%s_%s.log",inputDml,iSapServer);
	//sprintf(fsuccess_name,"/user/uaprodtrl/PLMSAP/PLM_SAP_APL_LOG/APL_Sap_Mat_%s.log",inputDml);
	//sprintf(fsuccess_name,"APL_Sap_Mat_%s.log",inputDml);
	fsuccess = fopen(fsuccess_name,"a");

	//sprintf(fisa_name,"INSPECTION_ALLOC_%s.log",inputDml);
	//finsp = fopen(fisa_name,"a");

	//sprintf(fvac_name,"VALUATIONCR_%s.log",inputDml);
	//fval = fopen(fvac_name,"a");

	//added Hrishikesh 12.07.2023

	if ((tc_strstr(inputDml,"APLC")!=NULL) || (tc_strstr(inputDml,"STDC")!=NULL))
	{
		tc_strdup("1100",&iPlantCode);

	}
	if ((tc_strstr(inputDml,"APLP")!=NULL) || (tc_strstr(inputDml,"STDP")!=NULL))
	{
		tc_strdup("1001",&iPlantCode);

	}
	if ((tc_strstr(inputDml,"APLD")!=NULL) || (tc_strstr(inputDml,"STDD")!=NULL))
	{
		tc_strdup("1500",&iPlantCode);

	}
	if ((tc_strstr(inputDml,"APLU")!=NULL) || (tc_strstr(inputDml,"STDU")!=NULL))
	{
		tc_strdup("3100",&iPlantCode);

	}

	if ((tc_strstr(inputDml,"APLJ")!=NULL) || (tc_strstr(inputDml,"STDJ")!=NULL))
	{
		tc_strdup("2001",&iPlantCode);

	}

	if ((tc_strstr(inputDml,"APLA")!=NULL) || (tc_strstr(inputDml,"STDA")!=NULL))
	{
		tc_strdup("E201",&iPlantCode);

	}



	//end 12.07.2023

	printf("\ninputDml : [%s]",inputDml);
	printf("\niSapServer : [%s]",iSapServer);

		if (tc_strstr(inputDml,"APLC")!=NULL || 
			tc_strstr(inputDml,"STDC")!=NULL)
		{

			if 	(tc_strcmp(iSapServer,"EVP")==0 || 
				 tc_strcmp(iSapServer,"EVQ")==0 || 
				 tc_strcmp(iSapServer,"EVD")==0 || 
				 tc_strcmp(iSapServer,"CVP")==0 || 
				 tc_strcmp(iSapServer,"CVQ")==0 || 
				 tc_strcmp(iSapServer,"CVD")==0)
			{
			
					printf("\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
					fprintf(fsuccess,"\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
					goto CLEANUP;
			
			}//added Hrishikesh 07.02.2024
		}

		else if (tc_strstr(inputDml,"APLA")!=NULL || 
				 tc_strstr(inputDml,"STDA")!=NULL)
		{

			if 	(tc_strcmp(iSapServer,"PVP")==0 || 
				 tc_strcmp(iSapServer,"PVQ")==0 || 
				 tc_strcmp(iSapServer,"PVD")==0 || 
				 tc_strcmp(iSapServer,"CVP")==0 || 
				 tc_strcmp(iSapServer,"CVQ")==0 || 
				 tc_strcmp(iSapServer,"CVD")==0)
			{
			
					printf("\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
					fprintf(fsuccess,"\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
					goto CLEANUP;
			
			}//added Hrishikesh 07.02.2024
		}

		else if (tc_strstr(inputDml,"APLP")!=NULL || 
				 tc_strstr(inputDml,"APLU")!=NULL || 
				 tc_strstr(inputDml,"APLD")!=NULL || 
				 tc_strstr(inputDml,"STDP")!=NULL || 
				 tc_strstr(inputDml,"STDU")!=NULL || 
				 tc_strstr(inputDml,"STDD")!=NULL ) 
		{

			if (tc_strcmp(iSapServer,"PVP")==0 || 
				tc_strcmp(iSapServer,"PVD")==0 || 
				tc_strcmp(iSapServer,"PVQ")==0 || 
				tc_strcmp(iSapServer,"EVP")==0 || 
				tc_strcmp(iSapServer,"EVD")==0 || 
				tc_strcmp(iSapServer,"EVQ")==0)
			{	
					printf("\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
					fprintf(fsuccess,"\nDML %s Cannot Transfer to  %s\n",inputDml,iSapServer);
					goto CLEANUP;
			
			}//added Hrishikesh 07.02.2024
		}


	//if(QRY_find2("APLDML_Query", &queryTag));
	if(QRY_find2("Driver VC Query", &PartQueryTag));
	if(QRY_find2("APLDMLRevisionQry", &queryTag));
	if (queryTag)
	{
		printf("\nQuery Found : APLDMLRevisionQry\n");fflush(stdout);
	}
	else
	{
		printf("\nQuery NotFound : APLDMLRevisionQry\n");fflush(stdout);
		goto CLEANUP;
	}
	printf("\nAfter QRY_find2 : APLDMLRevisionQry\n");fflush(stdout);
    printf("\nInput APL DML : %s\n ", inputDml);fflush(stdout);

    qry_values[0] = inputDml;

	//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));
	ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &outTag));

    printf("\nResultCount :%d:\n", resultCount);fflush(stdout);

	if(resultCount>0)
	{
		for (d = 0;d < resultCount ; d++ )
		{
			DMLTag = outTag[d];
		
		if(TCTYPE_ask_object_type(DMLTag,&objTypeTag));
    	if(TCTYPE_ask_name(objTypeTag,type_name));
	    printf("\nInput APL DML Object Type : [%s]\n",type_name);fflush(stdout);
		printf("\nQuery Executed...\n");fflush(stdout);

		ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_id",&DMLNum));
		ITK_CALL(AOM_UIF_ask_value(DMLTag,"t5_cprojectcode",&DMLProjCode));
		ITK_CALL(AOM_ask_value_string(DMLTag,"t5_rlstype",&DMLRelType));
		ITK_CALL(AOM_UIF_ask_value(DMLTag,"current_desc",&DMLDesc));
		ITK_CALL(AOM_UIF_ask_value(DMLTag,"release_status_list",&DMLRelStatus));
		ITK_CALL(AOM_UIF_ask_value(DMLTag,"owning_user",&DML_Owner));
		ITK_CALL(AOM_ask_value_string(DMLTag,"t5_EcnType",&DMLEcnType));

		ITK_CALL(AOM_ask_value_date(DMLTag,"t5_APLReleaseDate",&APLRelDate));
		ITK_CALL(DATE_date_to_string(APLRelDate,"%d/%m/%Y",&APLRelDateStr));
		
		ITK_CALL(AOM_ask_value_date(DMLTag,"date_released",&STDRelDate));
		ITK_CALL(DATE_date_to_string(STDRelDate,"%d/%m/%Y",&STDRelDateStr));
		
		ITK_CALL(ITK_date_to_string(APLRelDate,&DateStr));
		tc_strcpy(dml_no,DMLNum);

		printf("\nDML Release Type ECN Type : [%s,%s]",DMLRelType,DMLEcnType);
		if(tc_strcmp(DMLRelType,"TODR")==0)
		{
			printf("\nSkipping DML from material creation change as DML [%s] Release Type [%s]\n",DMLNum,DMLRelType);
			goto CLEANUP;
		}
		
		printf("\nDMLRelStatus : [%s]",DMLRelStatus);

		//if(tc_strstr(DMLRelStatus,"APLC Released")!=NULL)
		//added Hrishikesh 12.07.2023
		if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(DMLRelStatus,"APLC Released")!=NULL)||
		   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(DMLRelStatus,"APLP Released")!=NULL)||
		   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(DMLRelStatus,"APLD Released")!=NULL)||
		   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(DMLRelStatus,"APLU Released")!=NULL)||
		   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(DMLRelStatus,"APLJ Released")!=NULL)||
		   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(DMLRelStatus,"APLA Released")!=NULL)) //added Hrishikesh 02.10.2023
		{
			if (tc_strlen(APLRelDateStr)!=10)
			{
				printf("\nDML Number [%s] APL Release Date is NULL..Exiting!\n",DMLNum,tc_strlen(DateStr));
				fprintf(fsuccess,"\nDML Number [%s] APL Release Date is NULL..Exiting!\n",DMLNum,tc_strlen(DateStr));
				tc_strcpy(MATstatus,"N");
				tc_strcpy(PartNumber,"NA");
				tc_strcpy(PartRev,"NA");
				tc_strcpy(PartSeq,"NA");
				tc_strcpy(Parttype,"NA");
				sprintf(Error_message,"DML Number [%s] APL Release Date is NULL..Exiting!",DMLNum,tc_strlen(DateStr));
				Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
				continue;
			}
		}

		//if [APLloader (aplloader)] skip DML transfer. - Check removed on 23-09-2020 as confirmed by APL/STD Team
		if(tc_strstr(DML_Owner,"APLloader")!=NULL || tc_strstr(DML_Owner,"aplloader")!=NULL)
		{
			printf("\nDML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
			fprintf(fsuccess,"\nDML [%s] as DML Owner [%s]",DMLNum,DML_Owner);
			//goto CLEANUP;
		}

		tc_strdup(DMLNum,&DMLNumDup);
		tc_strdup(DMLProjCode,&DMLProjCodeDup);

		printf("\nDML Number [%s] Release Status [%s] APLReleaseDate [%s]\n",DMLNum,DMLRelStatus,APLRelDateStr);fflush(stdout);
		fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] APLReleaseDate [%s]\n",DMLNum,DMLRelStatus,APLRelDateStr);fflush(stdout);

		//if(tc_strstr(DMLRelStatus,"STDSIC Released")==NULL)

		//added Hrishikesh 12.07.2023
		if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(DMLRelStatus,"STDSIC Released")==NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(DMLRelStatus,"STDSIP Released")==NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(DMLRelStatus,"STDSID Released")==NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(DMLRelStatus,"STDSIU Released")==NULL)|| //added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(DMLRelStatus,"STDSIJ Released")==NULL)|| //added Hrishikesh 20.09.2023
		   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(DMLRelStatus,"STDSIA Released")==NULL)) //added Hrishikesh 02.10.2023
		{
			//if(tc_strstr(DMLRelStatus,"APLC Released")!=NULL)

			if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(DMLRelStatus,"APLC Released")!=NULL)||//added Hrishikesh 12.07.2023
			   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(DMLRelStatus,"APLP Released")!=NULL)||//added Hrishikesh 12.07.2023
			   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(DMLRelStatus,"APLD Released")!=NULL)||//added Hrishikesh 12.07.2023
			   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(DMLRelStatus,"APLU Released")!=NULL)|| //added Hrishikesh 12.07.2023
			   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(DMLRelStatus,"APLJ Released")!=NULL)|| //added Hrishikesh 20.09.2023
			   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(DMLRelStatus,"APLA Released")!=NULL)) //added Hrishikesh 02.10.2023
			{
				printf("\nDML Number [%s] Release Type [%s] Project Code [%s]\n",DMLNum,DMLRelType,DMLProjCode);fflush(stdout);
				printf("\nRelease Status [%s] APLReleaseDate [%s] STD Released Date [%s]\n",DMLRelStatus,APLRelDateStr,STDRelDateStr);fflush(stdout);
				printf("\nDML Desc :%s\n",DMLDesc);fflush(stdout);
				printf("\nDMLNumDup :%s	DMLProjCodeDup : %s\n",DMLNumDup,DMLProjCodeDup);fflush(stdout);
			}
			else
			{
				printf("\nDML Number [%s] Release Status [%s] Not APL Released or Above...\n",DMLNum,DMLRelStatus);fflush(stdout);
				fprintf(fsuccess,"\nDML Number [%s] Release Status [%s] Not APL Released or Above...\n",DMLNum,DMLRelStatus);fflush(stdout);


				tc_strcpy(MATstatus,"N");
				tc_strcpy(PartNumber,"NA");
				tc_strcpy(PartRev,"NA");
				tc_strcpy(PartSeq,"NA");
				tc_strcpy(Parttype,"NA");
				sprintf(Error_message,"DML Number [%s] Release Status [%s] Not APL Released or Above...",DMLNum,DMLRelStatus);
				Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
				continue;
			}
		}

		//if(tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL)
		if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(DMLRelStatus,"STDSIC Released")!=NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(DMLRelStatus,"STDSIP Released")!=NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(DMLRelStatus,"STDSID Released")!=NULL)||//added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(DMLRelStatus,"STDSIU Released")!=NULL)|| //added Hrishikesh 12.07.2023
		   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(DMLRelStatus,"STDSIJ Released")!=NULL)|| //added Hrishikesh 20.09.2023
		   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(DMLRelStatus,"STDSIA Released")!=NULL)) //added Hrishikesh 02.10.2023
		{
			if (tc_strlen(STDRelDateStr)!=10)
			{
				printf("\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DMLNum);
				fprintf(fsuccess,"\nDML Number [%s] STD Release Date is NULL..Exiting!\n",DMLNum);

				tc_strcpy(MATstatus,"N");
				tc_strcpy(PartNumber,"NA");
				tc_strcpy(PartRev,"NA");
				tc_strcpy(PartSeq,"NA");
				tc_strcpy(Parttype,"NA");
				sprintf(Error_message,"DML Number [%s] STD Release Date is NULL..Exiting!",DMLNum);
				Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
				continue;
			}
			else
			{
				tc_strdup(STDRelDateStr,&APLRelDateStr);
				printf("\nDML Number [%s] STD Release Date [%s]\n",DMLNum,STDRelDateStr);
				fprintf(fsuccess,"\nDML Number [%s] STD Release Date [%s]\n",DMLNum,STDRelDateStr);
			}
		}

		if(FetchPlantSpecificData(DMLNumDup,DMLProjCodeDup)>0)
		{
			printf("\nPlant Specific Data Found...\n");fflush(stdout);
			fprintf(fsuccess,"\nPlant Specific Data Found...\n");fflush(stdout);
		}
		else
		{
			printf("\nError in Fetching Plant Specific Data...\n");fflush(stdout);
			fprintf(fsuccess,"\nError in Fetching Plant Specific Data...\n");fflush(stdout);

			tc_strcpy(MATstatus,"N");
			tc_strcpy(PartNumber,"NA");
			tc_strcpy(PartRev,"NA");
			tc_strcpy(PartSeq,"NA");
			tc_strcpy(Parttype,"NA");
			tc_strcpy(Error_message,"Error in Fetching Plant Specific Data...");
			Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
			goto CLEANUP;
		}
		
		if(tc_strcmp(iPlantCode,"")==0)
		{
			printf("\nPlant code is null hence exit"); fflush(stdout);
			fprintf(fsuccess,"\nPlant code is null hence exit"); fflush(fsuccess);
			goto CLEANUP;
		}

		strcpy(myzeroDup1,"0.0");
		strcpy(myzeroDup2,"0.00");
		strcpy(myzeroDup3,"0.000");
		strcpy(myzeroDup4,"0.0000");

		if(tc_strlen(DMLDesc)<=5)
		{
			tc_strcpy(DMLDescription,DMLNum);
		}
		else
		{
			tc_strncpy(DMLDescription,DMLDesc,80);
		}
		//tc_strdup(DMLDesc,&DMLDescription);

		//DmlReleasedDate [11/04/2018]
		strcpy(apl_release_date,"");
		strcpy(apl_release_date,strtok(APLRelDateStr,"/"));
		strcat(apl_release_date,".");
		strcat(apl_release_date,strtok(NULL,"/"));
		strcat(apl_release_date,".");
		strcat(apl_release_date,strtok(NULL,"/"));

		printf("\ndml_no_arg :%s",dml_no_arg);fflush(stdout);
		printf("\napl_release_date :%s",apl_release_date);fflush(stdout);
		printf("\nDMLDescription :%s",DMLDescription);fflush(stdout);

		/// Solution Item start
		GRM_find_relation_type("T5_DMLTaskRelation",&relation_type);
		ITK_CALL(GRM_list_secondary_objects_only(DMLTag,relation_type,&tcount,&TaskRevision));
		printf("\nAPL DML Revision to Task Count : %d",tcount);fflush(stdout);
		
		//change number creation
		if(tcount>0)
		{
			displaying_objects();
		}

		for (TaskCnt=0;TaskCnt<tcount ;TaskCnt++ )
		{
			TaskRevTag = TaskRevision[TaskCnt];
			ITK_CALL(AOM_ask_value_string(TaskRevTag,"object_type",&object_type));
			ITK_CALL(AOM_ask_value_string(TaskRevTag,"item_id",&taskId));
			printf("\nTask ID [%s]	object_type : %s",taskId,object_type);fflush(stdout);
			
			pcount=0;
			ITK_CALL(AOM_ask_value_tags(TaskRevTag,"CMHasSolutionItem",&pcount,&PartTags));
			printf("\nTask To Part Count : %d",pcount);fflush(stdout);

			for (PartCnt=0;PartCnt<pcount;PartCnt++)
			{
				PartRevTag=PartTags[PartCnt];
				Part_CreateChangeFunction(PartRevTag);
			}//Part Loop
			
		}//Task Loop

		break;
	 }
	}//DML Revision Found
	else
	{
		printf("\n\nDML [%s] Not Found in TCUA...Exiting!!",inputDml); fflush(stdout);
		fprintf(fsuccess,"\n\nDML [%s] Not Found in TCUA...Exiting!!",inputDml); fflush(fsuccess);		
	}

	ITK_CALL(POM_logout(false));
	return status;

	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);
}
;

int Part_CreateChangeFunction(tag_t LatestRev)
{

	int status;
	int len=0;
	int sflag=0;
	int doccount=0;
	int is=0;
	int Refcount=0;

    tag_t		docRelObjs			= NULLTAG;
    tag_t		*docObjs			= NULLTAG;
    tag_t		*refdocObjs			= NULLTAG;
    tag_t		doctag				= NULLTAG;
    tag_t		docRelObj			= NULLTAG;
    tag_t		refdocRelObj		= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;
	tag_t		docOPtr				= NULLTAG;

	char	*LatRevName=NULL;
	char	*part_type=NULL;
	char	*unit=NULL;
	char	*part_typeDup=NULL;
	char	*unitDup=NULL;
	char	*doc_no=NULL;
	char	*PartRelStatus = NULL;
	char	*PrtSeqDup = NULL;
	char	*designgrp = NULL;
	char	*moduleaddr = NULL;

	int Count = 0;
	tag_t	PartTagDup		= NULLTAG;
	tag_t	*NonColPartTags		= NULLTAG;

	static RFC_RC RfcRc;

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"object_string",&LatRevName));
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"owning_user",&OwnerName));
	tc_strdup(OwnerName,&OwnerNameDup);
	ITK_CALL(AOM_ask_value_string(LatestRev,"t5_PartType",&part_type));
	tc_strdup(part_type,&part_typeDup);

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_id",&part_noDup));
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"item_revision_id",&PrtRev));
	PrtRevDup=strtok(PrtRev,";");
	PrtSeqDup=strtok(NULL,";");
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_ColourInd",&partClrInd));

	if (tc_strcmp(partClrInd,"C")==0)
	{
		ITK_CALL(AOM_ask_value_tags(LatestRev,"TC_Is_Represented_By",&Count,&NonColPartTags));
		if (Count>0)
		{
			PartTagDup = NonColPartTags[0];
			ITK_CALL(AOM_ask_value_string(PartTagDup,"t5_ModuleAddress",&moduleaddr));

			printf("\nColour part [%s], going to non colour part to get module address \n",part_noDup);fflush(stdout);

			printf("\n>>>>>>>>>Module address: %s\n",moduleaddr);
		}
 
	}
	else
	{
		ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_ModuleAddress",&moduleaddr));
		printf("\n>>>>>>>>>>Module address: %s\n",moduleaddr);
	}



	ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_DesignGrp",&designgrp));
	//ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_ModuleAddress",&moduleaddr));

	printf("\nLatRevName:%s \n",LatRevName);fflush(stdout);
	printf("\nPart Type: %s\n",part_typeDup);
	printf("\npart_noDup: %s\n",part_noDup);
	printf("\nOwnerName: %s\n",OwnerNameDup);

	printf("\ndesigngrp: %s\n",designgrp);
	printf("\nModule address: %s\n",moduleaddr);

	tc_strcpy(PartNumber,part_noDup);
	tc_strcpy(PartRev,PrtRevDup);
	tc_strcpy(PartSeq,PrtSeqDup);
	tc_strcpy(Parttype,part_typeDup);

	if(	tc_strcmp(part_typeDup,"D")==0 ||
		tc_strcmp(part_typeDup,"DA")==0 ||
		tc_strcmp(part_typeDup,"DC")==0 ||
		tc_strcmp(part_typeDup,"CM")==0 ||//added 25.03.2023 Hrishikesh
		tc_strcmp(part_typeDup,"IFD")==0 ||
		tc_strcmp(part_typeDup,"IM")==0 ||
		tc_strcmp(part_typeDup,"CP")==0)
	{
		printf("\nSkipping from MM Creation as Part Type is %s : %s\n",part_type,part_noDup);
		fprintf(fsuccess,"\nSkipping from MM Creation as Part Type is %s : %s\n",part_type,part_noDup);

		tc_strcpy(MATstatus,"N");
		sprintf(Error_message,"Skipping from MM Creation as Part Type is %s : %s",part_type,part_noDup);
		Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);

		goto CLEANUP;
	}
	
	//CR-FY21-0218
	
	printf("\nPartRelStatus: %s\n",PartRelStatus);
	fprintf(fsuccess,"\nPartRelStatus: %s\n",PartRelStatus);

	//if(tc_strstr(PartRelStatus,"APLC Released")==NULL && tc_strstr(PartRelStatus,"STDSIC Released")==NULL)

	if((tc_strcmp(iPlantCode,"1100")==0 && tc_strstr(PartRelStatus,"APLC Released")==NULL && tc_strstr(PartRelStatus,"STDSIC Released")==NULL)||//added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"1001")==0 && tc_strstr(PartRelStatus,"APLP Released")==NULL && tc_strstr(PartRelStatus,"STDSIP Released")==NULL)||//added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"1500")==0 && tc_strstr(PartRelStatus,"APLD Released")==NULL && tc_strstr(PartRelStatus,"STDSID Released")==NULL)||//added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"3100")==0 && tc_strstr(PartRelStatus,"APLU Released")==NULL && tc_strstr(PartRelStatus,"STDSIU Released")==NULL)|| //added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"2001")==0 && tc_strstr(PartRelStatus,"APLJ Released")==NULL && tc_strstr(PartRelStatus,"STDSIJ Released")==NULL)|| //added Hrishikesh 12.07.2023
	   (tc_strcmp(iPlantCode,"E201")==0 && tc_strstr(PartRelStatus,"APLA Released")==NULL && tc_strstr(PartRelStatus,"STDSIA Released")==NULL)) //added Hrishikesh 12.07.2023

	{
		printf("\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
		fprintf(fsuccess,"\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);

		tc_strcpy(MATstatus,"N");
		sprintf(Error_message,"Part %s PartRelStatus: %s Part LCS not APL Released or Above...",LatRevName,PartRelStatus);
		Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
		goto CLEANUP;
	}

	len = tc_strlen(part_noDup);

	if(len>0)
	{
		if(tc_strstr(part_noDup,"98R"))
		{
			tc_strdup("T",&part_type);
			tc_strdup("T",&part_typeDup);
		}
		else if(*part_noDup == 'G')
		{
			 tc_strdup("C",&part_type);
			 tc_strdup("C",&part_typeDup);
		}

	}

	strcpy(part_noDupDes,part_noDup);
	
	strcpy(part_noDupDesx,part_noDup);


	tc_strcpy(mat_type,"");

	if (tc_strcmp(part_typeDup, "C") == 0 ||
		tc_strcmp(part_typeDup, "A") == 0 ||
		tc_strcmp(part_typeDup, "G") == 0 
		)
	{
		tc_strcpy(mat_type,"HALB");
	}
	else if (tc_strcmp(part_typeDup, "M") == 0)
	{
		tc_strcpy(mat_type,"HALB");
	}
	else if (tc_strcmp(part_typeDup, "V") == 0)
	{
			tc_strcpy(mat_type,"HALB");
	}
	else if((tc_strcmp(part_typeDup, "VC") == 0)	||
			(tc_strcmp(part_typeDup, "CKDVC") == 0) ||
			(tc_strcmp(part_typeDup, "SKDVC") == 0) ||
			(tc_strcmp(part_typeDup, "CCVC") == 0)	||
			(tc_strcmp(part_typeDup, "SVR") == 0)	||
			(tc_strcmp(part_typeDup, "VCCR") == 0)
			)
	{
		tc_strcpy(mat_type,"FERT");
	}
	else if (tc_strcmp(part_typeDup, "T") == 0)
	{
			tc_strcpy(mat_type,"HALB");
	}
	else if (tc_strcmp(part_typeDup,"DTPL")==0)
	{
		tc_strcpy(mat_type, "HALB");
	}
	else if (tc_strcmp(part_typeDup,"SA")==0)  // added on 17.03.2016 for 16 digit stage assembly of 60R TPL disintegration 
	{
		tc_strcpy(mat_type, "HALB");
	}
	else if (tc_strcmp(part_typeDup,"SP")==0)  // Stage Part
	{
		tc_strcpy(mat_type, "HALB");
	}
	else if (len == 12 || len == 14)
	{
			tc_strcpy(mat_type,"HALB");
	}
	else if (len == 10 || len == 11)
	{
			tc_strcpy(mat_type,"ROH");
	}
	else if (len == 14 || len == 16)	/*cabin kit logic by Ashish on 19.11.2013*/
	{
		if((*(part_noDup+10)=='C') && (*(part_noDup+11)=='K'))
		{
			tc_strcpy(mat_type,"HALB");
		}
	}

	printf("\nMaterial Type: %s", mat_type);
	fprintf(fsuccess,"\nMaterial Type: %s", mat_type);

	if(strcmp(mat_type,"")==0)
	{
		printf("\nNo Material Type Matching For Part : %s\n", part_noDup);
		fprintf(fsuccess,"\nNo Material Type Matching For Part : %s\n", part_noDup);
		goto CLEANUP;
	}

	
	ITK_CALL(AOM_ask_value_tag(LatestRev,"items_tag",&PartMasterTag));

	if ( tc_strcmp(partClrInd,"C") ==0)
	{
		//t5_uom is not found on colour part master/revision
		ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"uom_tag",&unit));
	}
	else
	{
		ITK_CALL(AOM_UIF_ask_value(PartMasterTag,"t5_uom",&unit));
	}
	
	printf("\nPLM Unit Of Masure : %s",unit);
	fprintf(fsuccess,"\nPLM Unit Of Masure : %s",unit);

	if(tc_strlen(unit)>0)
	{
		tc_strdup(unit,&unitDup);
		if (tc_strcmp(unitDup,"1-Mtr") == 0) tc_strcpy(meas_unit,"M");
		else if (tc_strcmp(unitDup,"2-Kg") == 0) tc_strcpy(meas_unit,"KG");
		else if (tc_strcmp(unitDup,"3-Ltr") == 0) tc_strcpy(meas_unit,"L");
		else if (tc_strcmp(unitDup,"4-Nos") == 0) tc_strcpy(meas_unit,"EA");
		else if (tc_strcmp(unitDup,"5-Sq.Mtr") == 0) tc_strcpy(meas_unit,"M2");
		else if (tc_strcmp(unitDup,"6-Sets") == 0) tc_strcpy(meas_unit,"EA");
		else if (tc_strcmp(unitDup,"7-Tonne") == 0) tc_strcpy(meas_unit,"TO");
		else if (tc_strcmp(unitDup,"8-Cu.Mtr") == 0) tc_strcpy(meas_unit,"M3");
		else if (tc_strcmp(unitDup,"9-Thsnds") == 0) tc_strcpy(meas_unit,"TS");
		else if (tc_strcmp(unitDup,"EA") == 0) tc_strcpy(meas_unit,"EA");
		else
		{
			tc_strdup("EA",&unitDup);
			tc_strcpy(meas_unit,"EA");
		}
	}
	else
	{
		tc_strdup("EA",&unitDup);
		tc_strcpy(meas_unit,"EA");
	}

	//As per CR-FY20-0181
	if (tc_strcmp(part_typeDup, "M") == 0)
	{
		tc_strdup("EA",&unitDup);
		tc_strcpy(meas_unit,"EA");
	}


	printf("\nSAP Unit Of Measure: %s", meas_unit);
	fprintf(fsuccess,"\nSAP Unit Of Measure: %s", meas_unit);

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"object_desc",&desc));

	/*Description = Nomenclature*/

	if(tc_strlen(desc)>0)
	{
		tc_strdup(desc,&descDup);
		printf("\nDescription: %s", descDup);
	}
	else printf("\nDescription is NULL!");

	/*if Drawing Indicator = D, only then go for Documents*/
	ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_DrawingInd",&drg_ind));
	
	if(tc_strlen(drg_ind)>0)
	{
		tc_strdup(drg_ind,&drg_indDup);
		printf("\nDrawing Indicator: %s\n", drg_indDup);
	}
	else
	{
		tc_strdup("",&drg_indDup);
		printf("\nDrawing Indicator is NULL!\n");
	}

	doc_noDup = NULL;
	dwg_typeDup = NULL;
	dwg_revDup = NULL;
	sheet_noDup = NULL;
	sizeDup = NULL;
	sflag=0;
	
	if(tc_strcmp(part_type,"D")!=0)
	{
		if(tc_strcmp(drg_indDup,"D")==0)
		{
			ITK_CALL(GRM_find_relation_type("IMAN_specification", &docRelObj));

			if(docRelObj)
			{
				ITK_CALL(GRM_list_secondary_objects_only(LatestRev,docRelObj,&doccount,&docObjs));
				printf("\n Speccount Value :  %d\n",doccount);fflush(stdout);

				for (is=0;is<doccount;is++ )
				{	
					doctag = docObjs[is];
					
					if(TCTYPE_ask_object_type(doctag,&docOPtr));
					if(TCTYPE_ask_name2(docOPtr,&docClass));
					printf("\nT5TaskToPartCreateVal RefDoc_tag  docClass :: %s\n", docClass);fflush(stdout);
				
					if(!strcmp(docClass,"ProDrw"))
					{
						printf("\n ProDrw \n");fflush(stdout);
						//intDrgCnt++;
						sflag=1;
						break;
					}
					else if(!strcmp(docClass,"CMI2Drawing"))
					{
						printf("\n CMI2Drawing \n");fflush(stdout);
						//intDrgCnt++;
						sflag=1;
						break;
					}
				}
			}
			else
			{
				ITK_CALL(GRM_find_relation_type("IMAN_reference", &refdocRelObj));
				if(refdocRelObj)
				{
					ITK_CALL(GRM_list_secondary_objects_only(LatestRev,refdocRelObj,&Refcount,&refdocObjs));
					printf("\n Refcount Value :-------------------->>>> Rajendra   %d\n",Refcount);fflush(stdout);

					for (is=0;is<Refcount;is++ )
					{	
						doctag = refdocObjs[is];
						if(TCTYPE_ask_object_type(doctag,&docOPtr));
						if(TCTYPE_ask_name(docOPtr,docClass));
						printf("\n RefDoc_tag  docClass :: %s\n", docClass);fflush(stdout);
					
						if(!strcmp(docClass,"ProDrw"))
						{
							printf("\n Ref ProDrw \n");fflush(stdout);
							//intDrgCnt++;
							sflag=1;
							break;
						}
						else if(!strcmp(docClass,"CMI2Drawing"))
						{
							printf("\n Ref CMI2Drawing \n");fflush(stdout);
							//intDrgCnt++;
							sflag=1;
							break;
						}
					}
				}
			}

			if(sflag>0)
			{
			  
				 printf("\n<Drawing Documents Found!>");fflush(stdout);

				 ITK_CALL(AOM_UIF_ask_value(doctag,"object_name",&doc_no));
				 tc_strdup(doc_no,&doc_noDup);

				printf("\nDocument Number: %s",doc_noDup);fflush(stdout);

				if(tc_strlen(docClass)>0)
				{
					 tc_strdup(docClass,&dwg_typeDup);
					printf("\nDocument Type: %s", dwg_typeDup);
				}
				else
					printf("\nDocument Type is NULL!");fflush(stdout);
		
				strcpy(tmpDrwNum,doc_noDup);
				tmpDrwNum1=strtok(tmpDrwNum,"/");
				tmpDrwRev=strtok(NULL,";");
				tmpDrwSeq=strtok(NULL,";");

				printf("\nDocument Number: %s",tmpDrwNum1);fflush(stdout);
				printf("\nDocument Rev: %s",tmpDrwRev);fflush(stdout);
				printf("\nDocument Seq: %s",tmpDrwSeq);fflush(stdout);

				if(tc_strlen(tmpDrwRev)>0)
				{
					tc_strdup(tmpDrwRev,&dwg_revDup);
					printf("\nDocument Version: %s", dwg_revDup);fflush(stdout);
					fprintf(fsuccess,"\nDocument Version: %s", dwg_revDup);
				}
				else
				{
					tc_strdup("NR",&dwg_revDup);
					printf("\nDocument Version: %s", dwg_revDup);fflush(stdout);
					fprintf(fsuccess,"\nDocument Version: %s", dwg_revDup);
				}

				tc_strdup("0",&sheet_noDup);// ZERO as no Sheet available in UA
			}
		}
		else
		{
			printf("Getting NR revision here");fflush(stdout);
			//tc_strdup("0",&sheet_noDup);
			doc_noDup = NULL;
			sizeDup = NULL;
			dwg_typeDup = NULL;
			dwg_revDup = NULL;
			sheet_noDup = NULL;
		}

		tc_strdup("",&OldMatNoDup);

		printf("\nOld Material No.: %s", OldMatNoDup);fflush(stdout);

		//if ((tc_strcmp(part_typeDup, "VC") == 0) || (tc_strcmp(part_typeDup, "VCCR") == 0)|| (tc_strcmp(part_typeDup, "CKDVC") == 0)|| (tc_strcmp(part_typeDup, "SKDVC") == 0))
		if (tc_strcmp(mat_type, "FERT") == 0)
		{
			printf("\nPlease Create Classification View for VC - %s",part_noDup);fflush(stdout);
			fprintf(fsuccess,"\nPlease Create Classification View for VC - %s",part_noDup);
			ITK_CALL(AOM_UIF_ask_value(LatestRev,"t5_Weight",&net_wt));
			
			if(tc_strlen(net_wt)>0)
			{
				tc_strdup(net_wt,&net_wtDup);
			}
			else
			{
				tc_strdup("0.000",&net_wtDup);
				
			}
		}
		else
		{
			tc_strdup("0.000",&net_wtDup);
		}


		tc_strdup("0.000",&gross_wt);
		printf("\nNet Weight: %s", net_wtDup);fflush(stdout);
		printf("\nGross Weight: %s", gross_wt);fflush(stdout);
	}

   
	 /*Weight Unit = KG*/
	tc_strdup("KG",&unit_wt);
	printf("\nWeight Unit: %s", unit_wt);

	/*Volume = 0.000*/
	tc_strdup("0.000",&volume);
	printf("\nVolume: %s", volume);

	/*Volume Unit = M3*/
	tc_strdup("M3",&vol_unit);
	printf("\nVolume Unit: %s", vol_unit);

	/*Page Format of Production Memo = ""*/
	printf("\nPage Format of Production Memo: ''");

	/*Material Group = ZZZZZZ*/
	//tc_strdup("ZZZZZZ",&material_group);
	//printf("\nMaterial Group: %s", material_group);

	/*Division = 01*/
	tc_strdup("01",&basic_division);
	printf("\nBasic Division: %s", basic_division);

	/********************** add logic for pstat and apl_dml_flag here *******************/
	//group = subString(part_noDup, 0, 1);
	group = *part_noDup;
	printf("\nGroup: %c", group);


	//Uncomment later to check APL DML

	printf("\ndml_noDup=%s",dml_numAP1);
	series = subString(dml_numAP1, 2, 2);
	printf("\nDML Series: %s", series);

	if ((tc_strcmp(series, "AM") == 0) || (tc_strcmp(series, "MC") == 0)) apl_dml_flag = 2;
	else apl_dml_flag = 0;
	printf("\nAPL_DML_FLAG: %d", apl_dml_flag);

	strcpy(sap_proc_type,"");
	strcpy(sap_spproc_type,"");
	strcpy(SAPpstat,"");
	strcpy(MRPpstat,"");

	GetCSPstat(/*part_noDup*/);

	pstat='0';
	pstat_mrp='0';
	pstat_acc='0';

	/*pstat = pstat_basic(part_noDup, plantcode, 1, group);
	pstat_mrp = pstat_basic(part_noDup, plantcode, 2, group);
	pstat_acc = pstat_basic(part_noDup, plantcode, 3, group);*/

	pstat_basicFun();

	printf("\n... pstat Values are :%c:%c:%c",pstat,pstat_mrp,pstat_acc);fflush(stdout);
	fprintf(fsuccess,"\n... pstat Values are :%c:%c:%c",pstat,pstat_mrp,pstat_acc);fflush(stdout);

	printf("\nPStat for Basic View: %c",pstat);
	printf("\nPStat for MRP View: %c",pstat_mrp);
	printf("\nPStat for Accounting View: %c",pstat_acc);

	fprintf(fsuccess,"\nPStat %c %c %c",pstat,pstat_mrp,pstat_acc);

	if (pstat == 'K')
	{
		apl_dml_flag = 0;
	}
	else
	{
		apl_dml_flag = 2;
	}
	printf("\nAPL_DML_FLAG after PStat :: %d", apl_dml_flag);
	printf("\nPlant Code Is :: %s",plantcode);

	ITK_CALL(AOM_ask_value_string(LatestRev,Plant_MakeBuy,&PartMakeBuyInd));
	ITK_CALL(AOM_ask_value_string(LatestRev,Plant_StoreLoc,&store_loc));
	printf("\nPart Make Buy Ind : %s",PartMakeBuyInd);
	if (tc_strlen(PartMakeBuyInd)==0)
	{
		printf("\nSkipping Part %s from MM Creation as Make Buy Ind is NULL!!",part_noDup);
		fprintf(fsuccess,"\nSkipping Part %s from MM Creation as Make Buy Ind is NULL!!",part_noDup);
		goto CLEANUP;
	}
	tc_strdup(PartMakeBuyInd,&make_buy_ind);
	
	printf("\nMake_buy_ind : %s		store_loc : %s ",make_buy_ind,store_loc);
	fprintf(fsuccess,"\nMake_buy_ind : %s		store_loc : %s ",make_buy_ind,store_loc);
	
	if (tc_strlen(store_loc)>0 && tc_strcmp(store_loc,"NA")!=0)
	{
		tc_strdup(store_loc,&store_locDup);
	}
	else
	{
		tc_strdup("",&store_locDup);
	}

	printf("\nMake_buy_ind : %s		store_locDup : %s ",make_buy_ind,store_locDup);
	fprintf(fsuccess,"\nMake_buy_ind : %s		store_locDup : %s ",make_buy_ind,store_locDup);

	if(tc_strcmp(make_buy_ind,"F19")==0)
	{
		strcpy(make_buy_ind,"F30");
	}

	if(tc_strcmp(make_buy_ind,"NA")==0)
	{
		printf("\nMakebuy indicator is NA hence can not create material for %s",part_noDup);
		fprintf(fsuccess,"\nMakebuy indicator is NA hence can not create material for %s",part_noDup);

		tc_strcpy(MATstatus,"N");
		sprintf(Error_message,"Makebuy indicator is NA hence can not create material for %s",part_noDup);
		Create_PLMSAP_audit_object (dml_no,plant,PartNumber, PartRev, PartSeq, Parttype, Error_message, MATstatus);
		goto CLEANUP;
	}


	//tc_strdup("ZZZZZZ",&material_group);

	if((tc_strcmp(make_buy_ind,"E99")==0) || (tc_strcmp(make_buy_ind,"F30")==0) || (tc_strcmp(make_buy_ind,"F40")==0))
	{
		//if(tc_strcmp(part_typeDup, "M") == 0)
		//{
			//if(tc_strstr(PartRelStatus,"MBOM Released")!=NULL)
			if((tc_strstr(PartRelStatus,"APLP Released")!=NULL) || (tc_strstr(PartRelStatus,"APLD Released")!=NULL) || (tc_strstr(PartRelStatus,"APLU Released")!=NULL) || (tc_strstr(PartRelStatus,"APLJ Released")!=NULL) || (tc_strstr(PartRelStatus,"APLL Released")!=NULL))
			//if((tc_strcmp(PartRelStatus, "APLP Released") == 0) || (tc_strcmp(PartRelStatus, "APLD Released") == 0) || (tc_strcmp(PartRelStatus, "APLU Released") == 0) || (tc_strcmp(PartRelStatus, "APLJ Released") == 0) || (tc_strcmp(PartRelStatus, "APLL Released") == 0))
			{
				printf("\n ........................PartRelStatus is : [%s] , it is valid ..........................", PartRelStatus);

//				if ((tc_strlen(part_noDup)==12) && (tc_strcmp(designgrp,"00")==0))
//				{
//					tc_strdup("NS2000",&material_group);
//				}
//				else if ((tc_strlen(part_noDup)==12) && (tc_strcmp(designgrp,"26")==0))
//				{
//					tc_strdup("NS2026",&material_group);
//				}
				//else if ((tc_strlen(part_noDup)==12) && (tc_strcmp(designgrp,"31")==0))
				//{
				//	tc_strdup("NS2031",&material_group);
				//}

				if ((tc_strlen(part_noDup)==14) && (tc_strcmp(designgrp,"31")==0))
				{
					tc_strdup("NS2031",&material_group);
				}

				else if ((tc_strcmp(moduleaddr,"MH9X01")==0) && (tc_strcmp(designgrp,"33")==0) && (tc_strcmp(part_typeDup, "M") == 0))
				{
					tc_strdup("NS2033",&material_group);
				}

				else if ((tc_strcmp(moduleaddr,"MH9X02")==0) && (tc_strcmp(designgrp,"33")==0) && (tc_strcmp(part_typeDup, "M") == 0))
				{
					tc_strdup("NS2033",&material_group);
				}

				else if ((tc_strcmp(moduleaddr,"MH9W02")==0) && (tc_strcmp(designgrp,"33")==0) && (tc_strcmp(part_typeDup, "M") == 0))
				{
					tc_strdup("NS2034",&material_group);
				}

				else if ((tc_strcmp(moduleaddr,"MH9W01")==0) && (tc_strcmp(designgrp,"35")==0) && (tc_strcmp(part_typeDup, "M") == 0))
				{
					tc_strdup("NS2035",&material_group);
				}

				else if ((tc_strcmp(moduleaddr,"MH2D03")==0) && (tc_strcmp(designgrp,"35")==0) && (tc_strcmp(part_typeDup, "M") == 0))
				{
					tc_strdup("NS2035",&material_group);
				}

				else if ((tc_strcmp(moduleaddr,"MH9W02")==0) && (tc_strcmp(designgrp,"39")==0) && (tc_strcmp(part_typeDup, "M") == 0))
				{
					tc_strdup("NS2036",&material_group);
				}

				else if ((tc_strcmp(moduleaddr,"MD9X01")==0) && (tc_strcmp(designgrp,"60")==0) && (tc_strcmp(part_typeDup, "M") == 0))
				{
					tc_strdup("NS2060",&material_group);
				}

				else if ((tc_strcmp(moduleaddr,"MD9Y01")==0) && (tc_strcmp(designgrp,"60")==0) && (tc_strcmp(part_typeDup, "M") == 0))
				{
					tc_strdup("NS2061",&material_group);
				}

				else if ((tc_strcmp(moduleaddr,"MD9Z01")==0) && (tc_strcmp(designgrp,"60")==0) && (tc_strcmp(part_typeDup, "M") == 0))
				{
					tc_strdup("NS2063",&material_group);
				}

				else if ((tc_strcmp(moduleaddr,"MA9Z01")==0) && (tc_strcmp(designgrp,"70")==0) && (tc_strcmp(part_typeDup, "M") == 0))
				{
					tc_strdup("NS2071",&material_group);
				}
				else
				{
					tc_strdup("ZZZZZZ",&material_group);
				}


				//printf("\n ........................Partno,  Material Group: [%s], [%s]............................", part_noDup,material_group);
				//fprintf(fsuccess,"\n........................Partno,  Material Group: [%s], [%s]............................",part_noDup,material_group);

				printf("\n ........................Partno: [%s], Module address : [%s], designgrp : [%s] , CS : [%s], Material Group: [%s]............................", part_noDup,moduleaddr,designgrp,make_buy_ind,material_group);
				fprintf(fsuccess,"\n........................Partno: [%s], Module address : [%s], designgrp : [%s] , CS : [%s], Material Group: [%s]............................",part_noDup,moduleaddr,designgrp,make_buy_ind,material_group);


			}
			else
			{
				printf("\n Module %s is not MBOM Released, not valid case for NSCODE.................",part_noDup);
				fprintf(fsuccess,"\nModule %s is not MBOM Released, not valid case for NSCODE.................",part_noDup);
				printf("\n ........................PartRelStatus: [%s] is not MBOM released...........................", PartRelStatus);
				tc_strdup("ZZZZZZ",&material_group);
				printf("\n ........................Partno: [%s], Module address : [%s], designgrp : [%s] , CS : [%s], Material Group: [%s]............................", part_noDup,moduleaddr,designgrp,make_buy_ind,material_group);
				fprintf(fsuccess,"\n........................Partno: [%s], Module address : [%s], designgrp : [%s] , CS : [%s], Material Group: [%s]............................",part_noDup,moduleaddr,designgrp,make_buy_ind,material_group);
			}
		//}
//		else
//		{
//		printf("\n part %s is not module, not valid case for NSCODE.................",part_noDup);
//		fprintf(fsuccess,"\n part %s is not module, not valid case for NSCODE.................",part_noDup);
//		tc_strdup("ZZZZZZ",&material_group);
//		}
	}
	else
	{
		printf("\n %s not valid case for NSCODE..1111.................",part_noDup);
		fprintf(fsuccess,"\n %s not valid case for NSCODE..111.................",part_noDup);
		tc_strdup("ZZZZZZ",&material_group);
	}



		



	//tc_strdup("ZZZZZZ",&material_group);
	printf("\n Partno,  Material Group: [%s], [%s]", part_noDup,material_group);
	fprintf(fsuccess,"\nPartno,  Material Group: [%s], [%s]",part_noDup,material_group);

	//SETCHAR(eBasicView.Matl_Group,material_group);
	//SETCHAR(eBasicViewx.Matl_Group,"X");



	UPD_BAPI_MATERIAL_SAVEDATA();






	/***********************************************************************************/

	
	CLEANUP:
	return 0;
}//End Of Function




