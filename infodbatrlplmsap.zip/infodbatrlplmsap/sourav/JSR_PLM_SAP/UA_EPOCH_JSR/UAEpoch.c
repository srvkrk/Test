/***************************************************************************
*  Copyright (c) 2020 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : UA_Epoch.c
* Created By                   : Hrishikesh Sutar
* Created On                   : 01/01/2019
* Project                      : Tata Motors TCUA-SAP Interface
* Methods Defined              :
* Description                  : Generate Estimate sheet
* Specific Notes               : ./UA_Epoch -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -a="54455424000R"
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <time.h>
#include <tccore/tctype.h>



#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}                                                                            \

//static int report_wso_object_string_and_owning_user(tag_t object)
//{
//    char *object_string = NULL;
//    char *owning_user = NULL;
//    char *item_id = NULL;
//    char *date_released = NULL;
//    //ITK_CALL(WSOM_ask_object_id_string(object, &object_string));
//    //ITK_CALL(AOM_UIF_ask_value(object, "owning_user", &owning_user));
//    ITK_CALL(AOM_UIF_ask_value(object, "item_id", &item_id));
//    ITK_CALL(AOM_UIF_ask_value(object, "date_released", &date_released));
//    //printf("       %s - %s \n", object_string, owning_user);
//    printf("%s %s\n", item_id,date_released);
//    //MEM_free(object_string);
//    //MEM_free(owning_user);
//	MEM_free(item_id);
//	MEM_free(date_released);
//	return ITK_ok;
//}

void trimLeading(char * str)
{
    int index, i, j;

    index = 0;

    /* Find last index of whitespace character */
    while(str[index] == ' ' || str[index] == '\t' || str[index] == '\n')
    {
        index++;
    }


    if(index != 0)
    {
        /* Shit all trailing characters to its left */
        i = 0;
        while(str[i + index] != '\0')
        {
            str[i] = str[i + index];
            i++;
        }
        str[i] = '\0'; // Make sure that string is NULL terminated
    }
}
;

void trimTrailing(char * str)
{
    int index, i;

    /* Set default index */
    index = -1;

    /* Find last index of non-white space character */
    i = 0;
    while(str[i] != '\0')
    {
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n')
        {
            index= i;
        }

        i++;
    }

    /* Mark next character to last non-white space character as NULL */
    str[index + 1] = '\0';
}
;


void trimcharacters(char * str)
{
    int index, i;
    int j = 0;
	//char *New_TSRefer_std = NULL;


	//printf("\nRefer Std value : %s", TSRefer_std);

	for(i = 2; str[i] != '\0'; i++)
	{


			str[j]=str[i]; 
			//printf("\nNew Refer Std value**** : [%s]", str);


				if(str[i] == ' ' && str[i+1] != ' ')
				{
					i++;
				}

			j++;
		

	}


str[j] = '\0';
	//printf("\nNew Refer Std value : [%s]", New_TSRefer_std);


 
}
;

void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);


}
;
char *replaceWord(const char *s, const char *oldW,
                                 const char *newW)
{
    char *result;
    int i, cnt = 0;
    int newWlen = strlen(newW);
    int oldWlen = strlen(oldW);

    // Counting the number of times old word
    // occur in the string
    for (i = 0; s[i] != '\0'; i++)
    {
        if (strstr(&s[i], oldW) == &s[i])
        {
            cnt++;

            // Jumping to index after the old word.
            i += oldWlen - 1;
        }
    }

    // Making new string of enough length
    result = (char *)malloc(i + cnt * (newWlen - oldWlen) + 1);

    i = 0;
    while (*s)
    {
        // compare the substring with the result
        if (strstr(s, oldW) == s)
        {
            strcpy(&result[i], newW);
            i += newWlen;
            s += oldWlen;
        }
        else
            result[i++] = *s++;
    }

    result[i] = '\0';
    return result;
}
void getTodayDate(char* StdDate)
{
	struct tm *Sys_T = NULL;
	int Month;
	int Day;
	int Year;
	int hour;
	int min;
	int sec;

	time_t Tval = 0;
	Tval = time(NULL);
	Sys_T = localtime(&Tval);
	Day=Sys_T->tm_mday;
	Month=Sys_T->tm_mon+1;
	Year=1900 + Sys_T->tm_year;
	hour = Sys_T->tm_hour;
	min = Sys_T->tm_min;
	sec = Sys_T->tm_sec;

	//sprintf(StdDate,"%02d%02d%02d",Month,Day,Year);
	sprintf(StdDate,"%02d%02d",Month,Day);
	printf("\nDate:[%s]",StdDate); fflush(stdout);
}

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);


static tag_t ask_item_revision_from_bom_line(tag_t bom_line)
{
    tag_t item_revision = NULLTAG;
    char *item_id = NULL, *rev_id = NULL;
    
    ITK_CALL(AOM_ask_value_string(bom_line, "bl_item_item_id", &item_id ));
    ITK_CALL(AOM_ask_value_string(bom_line, "bl_rev_item_revision_id", &rev_id));
    ITK_CALL(ITEM_find_rev(item_id, rev_id, &item_revision));
    
    if (item_id) MEM_free(item_id);
    if (rev_id) MEM_free(rev_id);
    return item_revision;
}
void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %s",len,text,str);fflush(stdout);
  //if (stdout!=NULL) fprintf(stdout,"=%s\n>%s\n",text,str);
  return;
}



/************main function*******************/
int ITK_user_main (int argc, char ** argv )
{

	int Count	 = 0;
	int status;
	FILE *fp = NULL;
	FILE *fp1 = NULL;
	int value_entries = 1;
	int n_items = 0;
	int cnt = 0;
	int i = 0;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	int n_attchs = 0;
	int iOpRange = 0;
	int flag	 = 0;
	int ii	 = 0;
	int j	 = 0;
	
	int p = 0;

	logical EPCOHFlg;


	char *sUserName			    = NULL;
	char *sPassword			    = NULL;
	char *PartNumC				= NULL;
	char *PartNumCDup			= NULL;
	char *PartNumCNm			= NULL;
	char* RevName				= NULL;
	char* partClrInd		    = NULL;
	char* partClrIndDup         = NULL;
	char *StdDate = NULL;
	char *keysAttr[1]		    =  {"creation_date"};
    char *entries[1]		    =  {"ID"};
	char *EstimateSheetNoNm	    =  NULL;
	char *PlantName			    =  NULL;
	char *EstimateSheetNo		=  NULL;
	char *LatRevName	        =  NULL;
	char *type_name			    =  NULL;
	char *EstSheetRelStat	    =  NULL;
	char *revseq			    =  NULL;
	char *EstSheetClsrTstm		=  NULL;
	char *Strs					=  NULL;
	char *PPEstimate			=  NULL;
	char *PEUserKey				=  NULL;
	char **UniqPart				=  NULL;
	char **UniqPartno				=  NULL;
	char **temp				=  NULL;
	char sOpRange[5];
	char* EstPEAgency			= NULL;
	double fEstPSDCalTime	    = 0.00f;
	double fEstEPOCHValue		= 0.00f;
	char sEstEPOCHValue[50]		= { 0 };
	char sEstPSDCalTime[50]	    = { 0 };
	char *sEstEPOCHPEBCNo		= NULL;
	char *sEstProEDNNo			= NULL;
	char* RpStr					= NULL;
	char* Plant					= NULL;
	char FileName[100]			= { 0 };
	date_t EstSheetClsrTstm_date;
	char *EstimateSheetNoO		= NULL;
	char *EstimateSheet			= NULL;
	char *EstPlantName			= NULL;
	char *EstProEDNNo			= NULL;
	char *EstProID				= NULL;
	char *EstEPOCHPEBCNo	    = NULL;
	char *EstPEPartPerCycle		= NULL;
	char *EstEPOCHValue			= NULL;
	char *EstPSDCalTime			= NULL;
	char *EstPEMMAInd			= NULL;
	char *EstPEMMAIndDup        = NULL;
	char *EstOpnNo				= NULL;
	char *EstPEOpnDesc			= NULL;
	char userfile[100]			= { 0 };
	char type_name_opr[TCTYPE_name_size_c+1];
	char **values               = NULL;

	char *User_ID				= NULL;
	char *person_name			= NULL;
	char *local_person_email	= NULL;
	int k = 0;
	char *Partno = NULL;
	char *UniqueColour = NULL;
	char *EPOCHUomStr = NULL;



	tag_t item_tag			    =  NULLTAG;
	tag_t LatestRev			    =  NULLTAG;
	tag_t* NonColPartTags		=  NULLTAG;
	tag_t* ColPartTags			=  NULLTAG;
	tag_t PartTagDup			=  NULLTAG;
	tag_t  Query_Tag			=  NULLTAG;
    tag_t *items				=  NULL;
	tag_t EpochItemRevTag		=  NULLTAG;
	tag_t objTypeTag			=  NULLTAG;
	tag_t reln_type				=  NULLTAG;
	tag_t* secondary_objects	=  NULL;
	tag_t primary				=  NULLTAG;
	tag_t objTypeTag_opr		=  NULLTAG;
	tag_t person_tag			= NULLTAG;
	tag_t user					= NULLTAG;





	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	EstimateSheetNo = ITK_ask_cli_argument("-a=");
	//User_ID = ITK_ask_cli_argument("-i=");
	//PartSeq = ITK_ask_cli_argument("-Seq=");
	//CATDrawingSS_TS = ITK_ask_cli_argument("-file=");
	values = (char **) MEM_alloc(value_entries * sizeof(char *));




	//trimTrailing(User_ID);
	//trimLeading(User_ID);
	//
	//
	//SA_find_user2(User_ID, &user);
	//AOM_load(user);
	//SA_ask_user_person_name2(user, &person_name);
	//SA_find_person2 ( person_name, &person_tag);
	//SA_ask_person_email_address ( person_tag, &local_person_email ); 

	//printf("\nUser ID : [%s]",User_ID);
	//printf("\nperson_name : [%s]",person_name);
	//printf("\nfun local_person_email : [%s]",local_person_email);


	//tc_strcpy(userfile,"/user/uaprodtrl/PLMSAP/UAEPOCH_User/EstimateSheet/");
	//tc_strcat(userfile,User_ID);
	//tc_strcat(userfile,".txt");
	//fp1 = fopen (userfile,"w");
	//fprintf(fp1,"%s",local_person_email);
	//fclose(fp1);



	printf("\nPart number : [%s]",EstimateSheetNo);


	//printf("\nEstimateSheetNoNm : [%s]",EstimateSheetNoNm);
	//printf("Estimate SheetNumber",10,15,EstimateSheetNoNm);



/***************Part Query***************/


	ITK_CALL(ITEM_find_item(EstimateSheetNo,&item_tag));

	//ITK_CALL(ITEM_find_revisions(item_tag, sPart_RevSeq, &n_revisions, &item_revisions));
	ITK_CALL(ITEM_ask_latest_rev(item_tag,&LatestRev));
	ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&RevName));
	printf("\nColor check  revisions:%s\n",RevName);
	   
	ITK_CALL(AOM_ask_value_string(LatestRev,"t5_ColourInd",&partClrInd));
	tc_strdup(partClrInd,&partClrIndDup);
	   
	printf("\nColor indicator for :%s is %s\n",EstimateSheetNo,partClrIndDup);


	if ( tc_strcmp( partClrIndDup,"C") == 0 )
	{
			ITK_CALL(AOM_ask_value_tags(LatestRev,"TC_Is_Represented_By",&Count,&NonColPartTags));

			if (Count > 0)
			{
	
				PartTagDup = NonColPartTags[0];
				//ITK_CALL(AOM_ask_value_string(PartTagDup,"t5_PartType",&partType));
				ITK_CALL(AOM_ask_value_string(PartTagDup,"item_id",&PartNumC));
				printf("Non Color Part of [%s] is : [%s]",EstimateSheetNo,PartNumC);

				
				EstimateSheetNoNm=(char *) MEM_alloc(50);
				tc_strcpy(EstimateSheetNoNm,PartNumC);
				tc_strcat(EstimateSheetNoNm,"*");

				printf("\nQuerying Estimate sheet No : [%s]",EstimateSheetNoNm);
				ITK_CALL(QRY_find2("EstimateSheetPlantWiseQry", &Query_Tag));

				if (Query_Tag)
				{

					printf("\nFound Query : EstimateSheetPlantWiseQry");fflush(stdout);

					values[0] = (char *)MEM_alloc( strlen( EstimateSheetNoNm ) + 1);
					tc_strcpy(values[0], EstimateSheetNoNm);


					if(QRY_execute(Query_Tag, value_entries, entries, values, &n_items, &items));
					ITK_CALL(QRY_execute_with_sort(Query_Tag, value_entries, entries, values,num_to_sort,keysAttr,sort_order, &n_items, &items));

					printf("\nResultCount :%d:\n",n_items);fflush(stdout);

					if( n_items > 0)
					{

						for (i=0 ; i < n_items ; i++ )
						{

							EpochItemRevTag = items[i];

							//ITK_CALL(TCTYPE_ask_object_type(EpochItemRevTag,&objTypeTag));
							//ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
							//OUTS("Type_name",10,15,type_name); 

							ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"object_string",&LatRevName));

							trimTrailing(LatRevName);
							trimLeading(LatRevName);

							//OUTS("Estimate sheet name",10,15,LatRevName);fflush(stdout);
							printf("\n\tEstimate sheet name : [%s]",LatRevName);


							ITK_CALL(AOM_ask_value_logical(EpochItemRevTag,"t5_EPCOHFlg",&EPCOHFlg));
							printf("\n\tEPCOHFlg name : [%d]",EPCOHFlg);fflush(stdout);
							ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"release_status_list",&EstSheetRelStat));
							//OUTS("EstSheetRelStat",10,15,EstSheetRelStat);//t5_ActualRelDate
							printf("\n\tEstSheetRelStat : [%s]",EstSheetRelStat);//t5_ActualRelDate
							ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"object_string",&revseq));
							//OUTS("EstSheetRelStat Revseq ",10,15,revseq);//t5_rev
							trimTrailing(revseq);
							trimLeading(revseq);
							printf("\n\tEstSheetRelStat Revseq : [%s]",revseq);//t5_rev
							
							ITK_CALL(AOM_ask_value_date(EpochItemRevTag,"t5_ActualRelDate",&EstSheetClsrTstm_date));
							ITK_CALL(DATE_date_to_string ( EstSheetClsrTstm_date, "%d-%b-%Y %H:%M:%S", &EstSheetClsrTstm ));
							//OUTS("EstSheetClsrTstm",10,15,EstSheetClsrTstm);
							printf("\n\tEstSheetClsrTstm : [%s]\n",EstSheetClsrTstm);
							printf("\t**************************************************");

							if ( EPCOHFlg == 1 )
							//if ( tc_strcmp(EPCOHFlg,"1" ) == 0)
							{
									
								if ( tc_strstr( EstSheetRelStat,"PSD Final Released") != NULL )
								{
									printf("\nfound ok revision : [%s]", LatRevName);
									if ( tc_strcmp(EstSheetClsrTstm,"" ) != 0)
									{

										ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"object_string",&revseq));
										//OUTS("EstSheetRelStat Revseq ",10,15,revseq);//t5_rev
										trimTrailing(revseq);
										trimLeading(revseq);
										printf("\n\tEstSheetRelStat Revseq : [%s]",revseq);//t5_rev
										if ( Strs != NULL)
										{
											MEM_free(Strs);
										}
										Strs = (char *) MEM_alloc ( 100000 * sizeof ( char ) );
										tc_strcpy ( Strs, "" );
										PPEstimate = MEM_alloc ( 10 );
										tc_strcpy ( PPEstimate, "PP03" );
										PEUserKey = MEM_alloc ( 10 );
										tc_strcpy ( PEUserKey, "CARKEY1" );
										//ITK_CALL(GRM_find_relation_type("T5_EstimateOprtnRevision", &reln_type));
										ITK_CALL(GRM_list_secondary_objects_only(EpochItemRevTag,reln_type,&n_attchs,&secondary_objects));
										printf("\nNo of operations found:%d",n_attchs);

										for ( i = 0; i < n_attchs; i++)
										{
											
											primary = secondary_objects[i];
											ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag_opr));
											ITK_CALL(TCTYPE_ask_name(objTypeTag_opr,type_name_opr));
											//printf("\ntype_name_opr:%s",type_name_opr);fflush(stdout);
											if ( tc_strcmp ( type_name_opr, "T5_EstimateOprtnRevision" ) == 0 )
											{
												if ( RpStr != NULL)
												{
													MEM_free(RpStr);
												}
												RpStr = MEM_alloc(2500);
												ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"item_id",&EstimateSheet));
												EstimateSheetNoO = strtok(EstimateSheet,"-");
												ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"t5_PEPlantName",&EstPlantName));
												ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"t5_PEAgency",&EstPEAgency));
												ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"t5_PEProcessEDNNo",&EstProEDNNo));
												sEstProEDNNo = MEM_alloc(10);
												tc_strcpy ( sEstProEDNNo, EstProEDNNo );
												tc_strcat ( sEstProEDNNo, "R" );
												ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"project_ids",&EstProID));
												//ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"op_range",&ItemRevSeq));//op range
												ITK_CALL(AOM_ask_value_string(primary,"t5_EPOCHPEBCNo",&EstEPOCHPEBCNo));
												ITK_CALL(AOM_ask_value_string(primary,"t5_PEPartPerCycle",&EstPEPartPerCycle));
												ITK_CALL(AOM_ask_value_string(primary,"t5_EPOCHValue",&EstEPOCHValue));
												if ( EstEPOCHValue == NULL )
												{
													EstEPOCHValue = MEM_alloc(10);
													tc_strcpy ( EstEPOCHValue, "0.00" ) ;
												}
												tc_strcpy(sEstEPOCHValue,"");
												fEstEPOCHValue = atof(EstEPOCHValue);
												
												//START CHANGES (FOR JSR APL CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE)
												ITK_CALL(AOM_ask_value_string(primary,"t5_EPOCHUom",&EPOCHUomStr));
												trimTrailing(EPOCHUomStr);							
												trimLeading(EPOCHUomStr);
												if((tc_strcmp(EPOCHUomStr,"Min") == 0) && (tc_strcmp(EstPlantName,"CVBU JSR") == 0))
												{
													printf("\n Converting EPOCHValue to Hours..dividing by 60");fflush(stdout);
													fEstEPOCHValue = fEstEPOCHValue / 60;
												}
												printf("\n APL Calculated Time: %.2f",fEstEPOCHValue);
												sprintf(sEstEPOCHValue,"%.2f",fEstEPOCHValue);
												//END CHANGES (FOR JSR APL CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE)

												ITK_CALL(AOM_ask_value_string(primary,"t5_PSDCalTime",&EstPSDCalTime));
												if ( EstPSDCalTime == NULL )
												{
													EstPSDCalTime = MEM_alloc(10);
													tc_strcpy ( EstPSDCalTime, "0.00" ) ;
												}
												tc_strcpy(sEstPSDCalTime,"");
												fEstPSDCalTime = atof(EstPSDCalTime);
												//START CHANGES (FOR JSR PSD CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE) 
												if(tc_strcmp(EstPlantName,"CVBU JSR") == 0)
												{
													fEstPSDCalTime = fEstPSDCalTime / 60;
												}
												printf("\n PSD Calculated Time: %.2f",fEstPSDCalTime);
												//END CHANGES (FOR JSR PSD CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE)
												
												sprintf(sEstPSDCalTime,"%.2f",fEstPSDCalTime);

												//"CARKEY1"
												ITK_CALL(AOM_ask_value_string(primary,"t5_PEMMAInd",&EstPEMMAInd));
												
												//CHANGES FOR NULL VALUE CHECK
												if(tc_strlen(EstPEMMAInd)>0)
												{
												   tc_strdup(EstPEMMAInd,&EstPEMMAIndDup);
												}
												else
												{
												   tc_strdup(" ",&EstPEMMAIndDup);
												}
                                                printf("\nEstPEMMAInd: [%s]",EstPEMMAIndDup);
                                                //CHANGES FOR NULL VALUE CHECK
												
												ITK_CALL(AOM_ask_value_string(primary,"item_id",&EstOpnNo));
												printf("\nEstOpnNo: [%s]",EstOpnNo);
												ITK_CALL(AOM_ask_value_string(primary,"t5_PEOpnDesc",&EstPEOpnDesc));

												EstPEOpnDesc = replaceWord(EstPEOpnDesc, "\n", " ");
												EstPEOpnDesc = replaceWord(EstPEOpnDesc, "\t", " ");
												EstPEOpnDesc = replaceWord(EstPEOpnDesc, "\r", " ");
												EstPEOpnDesc = replaceWord(EstPEOpnDesc, ",", ";");

												sEstEPOCHPEBCNo = MEM_alloc(10);
												
												if ( tc_strcmp(EstEPOCHPEBCNo, "3240" ) == 0 )
												{
													printf("\n%s Skipping %s",EstimateSheetNoO,EstEPOCHPEBCNo);
													continue;
												}
												if ( *EstEPOCHPEBCNo == '9' )
												{
													printf("\n%s Skipping %s",EstimateSheetNoO,EstEPOCHPEBCNo);
													continue;
												}
												tc_strcpy ( sEstEPOCHPEBCNo,EstEPOCHPEBCNo ) ;

												if (tc_strcmp(EstPlantName,"CAR")==0)
												{

													if ( ( tc_strcmp(EstEPOCHPEBCNo, "2872" ) == 0 ) || ( tc_strcmp(EstEPOCHPEBCNo, "2310" ) == 0 ) )
													{
														tc_strcat( sEstEPOCHPEBCNo, "0005" ) ;
													}
													else
													{
														tc_strcat( sEstEPOCHPEBCNo, "0002" ) ;
													}
												}
												
												if (tc_strcmp(EstPlantName,"CVBU JSR")==0)
												{
												 
												  //if ( ( tc_strcmp(EstEPOCHPEBCNo, "2872" ) == 0 ) || ( tc_strcmp(EstEPOCHPEBCNo, "2310" ) == 0 ) )
												  //{
												  //	tc_strcat( sEstEPOCHPEBCNo, "0005" ) ;
												  //}
												  //else
												  //{
													tc_strcat( sEstEPOCHPEBCNo, "0002" ) ;
												  //}
												}
											
												if (tc_strstr(EstEPOCHPEBCNo,"2026")!=NULL || tc_strstr(EstEPOCHPEBCNo,"2027")!=NULL || tc_strstr(EstEPOCHPEBCNo,"2028")!=NULL)
												{
													  flag = 3;
												}
												else if (tc_strcmp(EstPlantName,"CAR")==0)
												{
													 flag = 1;
												} else if(tc_strstr(EstProID,"2788")!=NULL || tc_strstr(EstProID,"2818")!=NULL || tc_strstr(EstProID,"2829")!=NULL || tc_strstr(EstProID,"2834")!=NULL || tc_strstr(EstProID,"2850")!=NULL || tc_strstr(EstProID,"2851")!=NULL || tc_strstr(EstProID,"2857")!=NULL || tc_strstr(EstProID,"2861")!=NULL || tc_strstr(EstProID,"2864")!=NULL || tc_strstr(EstProID,"5517")!=NULL || tc_strstr(EstProID,"5523")!=NULL || tc_strstr(EstProID,"5705")!=NULL || tc_strstr(EstProID,"5708")!=NULL || tc_strstr(EstProID,"5710")!=NULL || tc_strstr(EstProID,"5717")!=NULL || tc_strstr(EstProID,"5721")!=NULL || tc_strstr(EstProID,"5801")!=NULL || tc_strstr(EstProID,"5807")!=NULL || tc_strstr(EstProID,"5813")!=NULL || tc_strstr(EstProID,"5814")!=NULL)
												{
													 flag = 2;
												} else if (tc_strcmp(EstPlantName,"CVBU PUNE")==0)
												{ 
													flag = 4;
												}
												else if (tc_strcmp(EstPlantName,"PUVBU")==0)
												{ 
													flag = 5;
												}

												else if (tc_strcmp(EstPlantName,"SMALLCAR AHD")==0)
												{ 
													flag = 6;
												}

												else if (tc_strcmp(EstPlantName,"CVBU JSR")==0)
												{ 
													flag = 7;
												}

												Plant = MEM_alloc(50);
												if ( flag == 1 )
												{
												  tc_strcpy(Plant,"1100");
												} 
												else if ( flag == 2 )
												{
													tc_strcpy(Plant,"3100");
												} 
												else if ( flag == 3 )
												{
													tc_strcpy(Plant,"1020");
												} 
												else if ( flag == 4 )
												{ 
													tc_strcpy(Plant,"1001"); 
												}
												else if ( flag == 5 )
												{ 
													tc_strcpy(Plant,"1140"); 
												}
												else if ( flag == 6 )
												{ 
													tc_strcpy(Plant,"E201"); 
												}
												else if ( flag == 7 )
												{ 
													tc_strcpy(Plant,"2001"); 
												}
												tc_strcpy(sOpRange,"");
												iOpRange = iOpRange + 10;
												sprintf(sOpRange,"%04d",iOpRange);

												//printf("\n%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s \t \t \t\t%s\t%s\t%s\t%s",EstimateSheetNoO,Plant,EstPEAgency,sEstProEDNNo,sOpRange,sEstEPOCHPEBCNo,PPEstimate,EstPEPartPerCycle,sEstEPOCHValue,sEstPSDCalTime,PEUserKey,EstPEMMAInd,EstOpnNo,EstPEOpnDesc);
												//sprintf(RpStr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s \t \t \t\t%s\t%s\t%s\t%s\n",EstimateSheetNo,Plant,EstPEAgency,sEstProEDNNo,sOpRange,sEstEPOCHPEBCNo,PPEstimate,EstPEPartPerCycle,sEstEPOCHValue,sEstPSDCalTime,PEUserKey,EstPEMMAInd,EstOpnNo,EstPEOpnDesc);
												sprintf(RpStr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t \t \t \t%s\t%s\t%s\t%s\n",EstimateSheetNo,Plant,EstPEAgency,sEstProEDNNo,sOpRange,sEstEPOCHPEBCNo,PPEstimate,EstPEPartPerCycle,sEstEPOCHValue,sEstPSDCalTime,PEUserKey,EstPEMMAIndDup,EstOpnNo,EstPEOpnDesc);
												printf("\n%s",RpStr);
												tc_strcat ( Strs, RpStr );
											}
										}
										
										if ( tc_strcmp ( Plant, "1100" ) == 0 )
										{
											tc_strcpy ( FileName, "" );
											StdDate = MEM_alloc ( 9 );
											getTodayDate ( StdDate );
											//tc_strcpy ( FileName, "/user/uaprodtrl/PLMSAP/UAEPOCH_User/EstimateSheet/" );
											tc_strcpy ( FileName, "epochcarpsdua" );
											tc_strcat ( FileName, StdDate );
											//tc_strcat ( FileName, "/" );
											//tc_strcat ( FileName, EstimateSheetNo );
											tc_strcat ( FileName, ".txt" );
											fp = fopen ( FileName, "a" );
											fprintf ( fp, "%s" , Strs );
											if ( fp )
											{
												fclose ( fp );
											}
										}

										else if ( tc_strcmp ( Plant, "E201" ) == 0 )
										{
											tc_strcpy ( FileName, "" );
											StdDate = MEM_alloc ( 9 );
											getTodayDate ( StdDate );
											//tc_strcpy ( FileName, "/user/uaprodtrl/PLMSAP/UAEPOCH_User/EstimateSheet/" );
											tc_strcpy ( FileName, "epochsnd2psdua" );
											tc_strcat ( FileName, StdDate );
											//tc_strcat ( FileName, "/" );
											//tc_strcat ( FileName, EstimateSheetNo );
											tc_strcat ( FileName, ".txt" );
											fp = fopen ( FileName, "a" );
											fprintf ( fp, "%s" , Strs );
											if ( fp )
											{
												fclose ( fp );
											}
										}

										else if ( tc_strcmp ( Plant, "2001" ) == 0 )
										{
											tc_strcpy ( FileName, "" );
											StdDate = MEM_alloc ( 9 );
											getTodayDate ( StdDate );
											//tc_strcpy ( FileName, "/user/uaprodtrl/PLMSAP/UAEPOCH_User/EstimateSheet/" );
											tc_strcpy ( FileName, "epochjsrpsdua" );
											tc_strcat ( FileName, StdDate );
											//tc_strcat ( FileName, "/" );
											//tc_strcat ( FileName, EstimateSheetNo );
											tc_strcat ( FileName, ".txt" );
											fp = fopen ( FileName, "a" );
											fprintf ( fp, "%s" , Strs );
											if ( fp )
											{
												fclose ( fp );
											}
										}
								
								
								
									}
									break;
								}
								else
								{
									printf("\nskipping revision : [%s]",LatRevName);
								}

							}

						}

					}
					else
					{

						OUTS("Estimate SheetNumber not found in TCUA",10,15,EstimateSheetNo); 
						return 0;

	
					}




				}

	
			}
			else
			{
				printf("\nNon colour part relation not found.......");
			
			}




	}

	else
	{

		
			EstimateSheetNoNm=(char *) MEM_alloc(50);
			tc_strcpy(EstimateSheetNoNm,EstimateSheetNo);
			tc_strcat(EstimateSheetNoNm,"*");
			
			printf("\nQuerying Estimate sheet No : [%s]",EstimateSheetNoNm);
			ITK_CALL(QRY_find2("EstimateSheetPlantWiseQry", &Query_Tag));
			
			if (Query_Tag)
			{
			
				printf("\nFound Query : EstimateSheetPlantWiseQry");fflush(stdout);
			
				values[0] = (char *)MEM_alloc( strlen( EstimateSheetNoNm ) + 1);
				tc_strcpy(values[0], EstimateSheetNoNm);
			
			
				if(QRY_execute(Query_Tag, value_entries, entries, values, &n_items, &items));
				ITK_CALL(QRY_execute_with_sort(Query_Tag, value_entries, entries, values,num_to_sort,keysAttr,sort_order, &n_items, &items));
			
				printf("\nResultCount :%d:\n",n_items);fflush(stdout);
			
				if( n_items > 0)
				{
			
					for (i=0 ; i < n_items ; i++ )
					{
			
						EpochItemRevTag = items[i];
			
						//ITK_CALL(TCTYPE_ask_object_type(EpochItemRevTag,&objTypeTag));
						//ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
						//OUTS("Type_name",10,15,type_name); 
			
						ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"object_string",&LatRevName));
			
						trimTrailing(LatRevName);
						trimLeading(LatRevName);
			
						//OUTS("Estimate sheet name",10,15,LatRevName);fflush(stdout);
						printf("\n\tEstimate sheet name : [%s]",LatRevName);
			
			
						ITK_CALL(AOM_ask_value_logical(EpochItemRevTag,"t5_EPCOHFlg",&EPCOHFlg));
						printf("\n\tEPCOHFlg name : [%d]",EPCOHFlg);fflush(stdout);
						ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"release_status_list",&EstSheetRelStat));
						//OUTS("EstSheetRelStat",10,15,EstSheetRelStat);//t5_ActualRelDate
						printf("\n\tEstSheetRelStat : [%s]",EstSheetRelStat);//t5_ActualRelDate
						ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"object_string",&revseq));
						//OUTS("EstSheetRelStat Revseq ",10,15,revseq);//t5_rev
						trimTrailing(revseq);
						trimLeading(revseq);
						printf("\n\tEstSheetRelStat Revseq : [%s]",revseq);//t5_rev
						
						ITK_CALL(AOM_ask_value_date(EpochItemRevTag,"t5_ActualRelDate",&EstSheetClsrTstm_date));
						ITK_CALL(DATE_date_to_string ( EstSheetClsrTstm_date, "%d-%b-%Y %H:%M:%S", &EstSheetClsrTstm ));
						//OUTS("EstSheetClsrTstm",10,15,EstSheetClsrTstm);
						printf("\n\tEstSheetClsrTstm : [%s]\n",EstSheetClsrTstm);
						printf("\t**************************************************");
			
						if ( EPCOHFlg == 1 )
						//if ( tc_strcmp(EPCOHFlg,"1" ) == 0)
						{
								
							if ( tc_strstr( EstSheetRelStat,"PSD Final Released") != NULL )
							{
								if ( tc_strcmp(EstSheetClsrTstm,"" ) != 0)
								{
			
									ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"object_string",&revseq));
									//OUTS("EstSheetRelStat Revseq ",10,15,revseq);//t5_rev
									trimTrailing(revseq);
									trimLeading(revseq);
									printf("\n\tEstSheetRelStat Revseq : [%s]",revseq);//t5_rev
									if ( Strs != NULL)
									{
										MEM_free(Strs);
									}
									Strs = (char *) MEM_alloc ( 100000 * sizeof ( char ) );
									tc_strcpy ( Strs, "" );
									PPEstimate = MEM_alloc ( 10 );
									tc_strcpy ( PPEstimate, "PP03" );
									PEUserKey = MEM_alloc ( 10 );
									tc_strcpy ( PEUserKey, "CARKEY1" );
									//ITK_CALL(GRM_find_relation_type("T5_EstimateOprtnRevision", &reln_type));
									ITK_CALL(GRM_list_secondary_objects_only(EpochItemRevTag,reln_type,&n_attchs,&secondary_objects));
									printf("\nNo of operations found:%d",n_attchs);
			
									for ( i = 0; i < n_attchs; i++)
									{
										
										primary = secondary_objects[i];
										ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag_opr));
										ITK_CALL(TCTYPE_ask_name(objTypeTag_opr,type_name_opr));
										//printf("\ntype_name_opr:%s",type_name_opr);fflush(stdout);
										if ( tc_strcmp ( type_name_opr, "T5_EstimateOprtnRevision" ) == 0 )
										{
											if ( RpStr != NULL)
											{
												MEM_free(RpStr);
											}
											RpStr = MEM_alloc(2500);
											ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"item_id",&EstimateSheet));
											EstimateSheetNoO = strtok(EstimateSheet,"-");
											ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"t5_PEPlantName",&EstPlantName));
											ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"t5_PEAgency",&EstPEAgency));
											ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"t5_PEProcessEDNNo",&EstProEDNNo));
											sEstProEDNNo = MEM_alloc(10);
											tc_strcpy ( sEstProEDNNo, EstProEDNNo );
											tc_strcat ( sEstProEDNNo, "R" );
											ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"project_ids",&EstProID));
											//ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"op_range",&ItemRevSeq));//op range
											ITK_CALL(AOM_ask_value_string(primary,"t5_EPOCHPEBCNo",&EstEPOCHPEBCNo));
											ITK_CALL(AOM_ask_value_string(primary,"t5_PEPartPerCycle",&EstPEPartPerCycle));
											ITK_CALL(AOM_ask_value_string(primary,"t5_EPOCHValue",&EstEPOCHValue));
											if ( EstEPOCHValue == NULL )
											{
												EstEPOCHValue = MEM_alloc(10);
												tc_strcpy ( EstEPOCHValue, "0.00" ) ;
											}
											tc_strcpy(sEstEPOCHValue,"");
											fEstEPOCHValue = atof(EstEPOCHValue);
											
											//START CHANGES (FOR JSR APL CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE)
											ITK_CALL(AOM_ask_value_string(primary,"t5_EPOCHUom",&EPOCHUomStr));
											trimTrailing(EPOCHUomStr);							
											trimLeading(EPOCHUomStr);
											if((tc_strcmp(EPOCHUomStr,"Min") == 0) && (tc_strcmp(EstPlantName,"CVBU JSR") == 0))
											{
												printf("\n Converting EPOCHValue to Hours..dividing by 60");fflush(stdout);
												fEstEPOCHValue = fEstEPOCHValue / 60;
											}
											printf("\n APL Calculated Time: %.2f",fEstEPOCHValue);
											sprintf(sEstEPOCHValue,"%.2f",fEstEPOCHValue);
											//END CHANGES (FOR JSR APL CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE)
			
											ITK_CALL(AOM_ask_value_string(primary,"t5_PSDCalTime",&EstPSDCalTime));
											if ( EstPSDCalTime == NULL )
											{
												EstPSDCalTime = MEM_alloc(10);
												tc_strcpy ( EstPSDCalTime, "0.00" ) ;
											}
											tc_strcpy(sEstPSDCalTime,"");
											fEstPSDCalTime = atof(EstPSDCalTime);
											//START CHANGES (FOR JSR PSD CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE) 
											if(tc_strcmp(EstPlantName,"CVBU JSR") == 0)
											{
												fEstPSDCalTime = fEstPSDCalTime / 60;
											}
											printf("\n PSD Calculated Time: %.2f",fEstPSDCalTime);
											//END CHANGES (FOR JSR PSD CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE)
											
											sprintf(sEstPSDCalTime,"%.2f",fEstPSDCalTime);
			
											//"CARKEY1"
											ITK_CALL(AOM_ask_value_string(primary,"t5_PEMMAInd",&EstPEMMAInd));
											//CHANGES FOR NULL VALUE CHECK
											if(tc_strlen(EstPEMMAInd)>0)
											{
												tc_strdup(EstPEMMAInd,&EstPEMMAIndDup);
											}
											else
											{
												tc_strdup(" ",&EstPEMMAIndDup);
											}
                                            printf("\nEstPEMMAInd: [%s]",EstPEMMAIndDup);
                                            //CHANGES FOR NULL VALUE CHECK
											ITK_CALL(AOM_ask_value_string(primary,"item_id",&EstOpnNo));
											printf("\nEstOpnNo: [%s]",EstOpnNo);
											ITK_CALL(AOM_ask_value_string(primary,"t5_PEOpnDesc",&EstPEOpnDesc));
			
											EstPEOpnDesc = replaceWord(EstPEOpnDesc, "\n", " ");
											EstPEOpnDesc = replaceWord(EstPEOpnDesc, "\t", " ");
											EstPEOpnDesc = replaceWord(EstPEOpnDesc, "\r", " ");
											EstPEOpnDesc = replaceWord(EstPEOpnDesc, ",", ";");
			
											sEstEPOCHPEBCNo = MEM_alloc(10);
											
											if ( tc_strcmp(EstEPOCHPEBCNo, "3240" ) == 0 )
											{
												printf("\n%s Skipping %s",EstimateSheetNoO,EstEPOCHPEBCNo);
												continue;
											}
											if ( *EstEPOCHPEBCNo == '9' )
											{
												printf("\n%s Skipping %s",EstimateSheetNoO,EstEPOCHPEBCNo);
												continue;
											}
											tc_strcpy ( sEstEPOCHPEBCNo,EstEPOCHPEBCNo ) ;

											if (tc_strcmp(EstPlantName,"CAR")==0)
											{

												if ( ( tc_strcmp(EstEPOCHPEBCNo, "2872" ) == 0 ) || ( tc_strcmp(EstEPOCHPEBCNo, "2310" ) == 0 ) )
												{
													tc_strcat( sEstEPOCHPEBCNo, "0005" ) ;
												}
												else
												{
													tc_strcat( sEstEPOCHPEBCNo, "0002" ) ;
												}
											}
											
											if (tc_strcmp(EstPlantName,"CVBU JSR")==0)
											{
												 
												  //if ( ( tc_strcmp(EstEPOCHPEBCNo, "2872" ) == 0 ) || ( tc_strcmp(EstEPOCHPEBCNo, "2310" ) == 0 ) )
												  //{
												  //	tc_strcat( sEstEPOCHPEBCNo, "0005" ) ;
												  //}
												  //else
												  //{
													tc_strcat( sEstEPOCHPEBCNo, "0002" ) ;
												  //}
											}
											
											if (tc_strstr(EstEPOCHPEBCNo,"2026")!=NULL || tc_strstr(EstEPOCHPEBCNo,"2027")!=NULL || tc_strstr(EstEPOCHPEBCNo,"2028")!=NULL)
											{
												  flag = 3;
											}
											else if (tc_strcmp(EstPlantName,"CAR")==0)
											{
												 flag = 1;
											} else if(tc_strstr(EstProID,"2788")!=NULL || tc_strstr(EstProID,"2818")!=NULL || tc_strstr(EstProID,"2829")!=NULL || tc_strstr(EstProID,"2834")!=NULL || tc_strstr(EstProID,"2850")!=NULL || tc_strstr(EstProID,"2851")!=NULL || tc_strstr(EstProID,"2857")!=NULL || tc_strstr(EstProID,"2861")!=NULL || tc_strstr(EstProID,"2864")!=NULL || tc_strstr(EstProID,"5517")!=NULL || tc_strstr(EstProID,"5523")!=NULL || tc_strstr(EstProID,"5705")!=NULL || tc_strstr(EstProID,"5708")!=NULL || tc_strstr(EstProID,"5710")!=NULL || tc_strstr(EstProID,"5717")!=NULL || tc_strstr(EstProID,"5721")!=NULL || tc_strstr(EstProID,"5801")!=NULL || tc_strstr(EstProID,"5807")!=NULL || tc_strstr(EstProID,"5813")!=NULL || tc_strstr(EstProID,"5814")!=NULL)
											{
												 flag = 2;
											} else if (tc_strcmp(EstPlantName,"CVBU PUNE")==0)
											{ 
												flag = 4;
											}
											else if (tc_strcmp(EstPlantName,"PUVBU")==0)
											{ 
												flag = 5;
											}
											else if (tc_strcmp(EstPlantName,"SMALLCAR AHD")==0)
											{ 
												flag = 6;
											}

											else if (tc_strcmp(EstPlantName,"CVBU JSR")==0)
											{ 
												flag = 7;
											}


			
											Plant = MEM_alloc(50);
											if ( flag == 1 )
											{
											  tc_strcpy(Plant,"1100");
											} 
											else if ( flag == 2 )
											{
												tc_strcpy(Plant,"3100");
											} 
											else if ( flag == 3 )
											{
												tc_strcpy(Plant,"1020");
											} 
											else if ( flag == 4 )
											{ 
												tc_strcpy(Plant,"1001"); 
											}
											else if ( flag == 5 )
											{ 
												tc_strcpy(Plant,"1140"); 
											}
											else if ( flag == 6 )
											{ 
												tc_strcpy(Plant,"E201"); 
											}
											else if ( flag == 7 )
											{ 
												tc_strcpy(Plant,"2001"); 
											}

											tc_strcpy(sOpRange,"");
											iOpRange = iOpRange + 10;
											sprintf(sOpRange,"%04d",iOpRange);
			
											//printf("\n%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s \t \t \t\t%s\t%s\t%s\t%s",EstimateSheetNoO,Plant,EstPEAgency,sEstProEDNNo,sOpRange,sEstEPOCHPEBCNo,PPEstimate,EstPEPartPerCycle,sEstEPOCHValue,sEstPSDCalTime,PEUserKey,EstPEMMAInd,EstOpnNo,EstPEOpnDesc);
											//sprintf(RpStr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s \t \t \t\t%s\t%s\t%s\t%s\n",EstimateSheetNo,Plant,EstPEAgency,sEstProEDNNo,sOpRange,sEstEPOCHPEBCNo,PPEstimate,EstPEPartPerCycle,sEstEPOCHValue,sEstPSDCalTime,PEUserKey,EstPEMMAInd,EstOpnNo,EstPEOpnDesc);
											sprintf(RpStr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t \t \t \t%s\t%s\t%s\t%s\n",EstimateSheetNo,Plant,EstPEAgency,sEstProEDNNo,sOpRange,sEstEPOCHPEBCNo,PPEstimate,EstPEPartPerCycle,sEstEPOCHValue,sEstPSDCalTime,PEUserKey,EstPEMMAIndDup,EstOpnNo,EstPEOpnDesc);
											printf("\n%s",RpStr);
											tc_strcat ( Strs, RpStr );
										}
									}
									
									if ( tc_strcmp ( Plant, "1100" ) == 0 )
									{
										tc_strcpy ( FileName, "" );
										StdDate = MEM_alloc ( 9 );
										getTodayDate ( StdDate );
										//tc_strcpy ( FileName, "/user/uaprodtrl/PLMSAP/UAEPOCH_User/EstimateSheet/" );
										tc_strcpy ( FileName, "epochcarpsdua" );
										tc_strcat ( FileName, StdDate );
										//tc_strcat ( FileName, "/" );
										//tc_strcat ( FileName, EstimateSheetNo );
										tc_strcat ( FileName, ".txt" );
										fp = fopen ( FileName, "a" );
										fprintf ( fp, "%s" , Strs );
										if ( fp )
										{
											fclose ( fp );
										}

									}

									else if ( tc_strcmp ( Plant, "E201" ) == 0 )
									{
										tc_strcpy ( FileName, "" );
										StdDate = MEM_alloc ( 9 );
										getTodayDate ( StdDate );
										//tc_strcpy ( FileName, "/user/uaprodtrl/PLMSAP/UAEPOCH_User/EstimateSheet/" );
										tc_strcpy ( FileName, "epochsnd2psdua" );
										tc_strcat ( FileName, StdDate );
										//tc_strcat ( FileName, "/" );
										//tc_strcat ( FileName, EstimateSheetNo );
										tc_strcat ( FileName, ".txt" );
										fp = fopen ( FileName, "a" );
										fprintf ( fp, "%s" , Strs );
										if ( fp )
										{
											fclose ( fp );
										}
									}

									else if ( tc_strcmp ( Plant, "2001" ) == 0 )
									{
										tc_strcpy ( FileName, "" );
										StdDate = MEM_alloc ( 9 );
										getTodayDate ( StdDate );
										//tc_strcpy ( FileName, "/user/uaprodtrl/PLMSAP/UAEPOCH_User/EstimateSheet/" );
										tc_strcpy ( FileName, "epochjsrpsdua" );
										tc_strcat ( FileName, StdDate );
										//tc_strcat ( FileName, "/" );
										//tc_strcat ( FileName, EstimateSheetNo );
										tc_strcat ( FileName, ".txt" );
										fp = fopen ( FileName, "a" );
										fprintf ( fp, "%s" , Strs );
										if ( fp )
										{
											fclose ( fp );
										}
									}
							
							
								}
								break; //31.07.2023
			
							}
			
						}
					
			
					}
			
				}
				else
				{
			
					OUTS("Estimate SheetNumber not found in TCUA",10,15,EstimateSheetNo); 
					return 0;
			
			
				}
			
			}

	
			ITK_CALL(AOM_ask_value_tags(LatestRev,"representation_for",&Count,&ColPartTags));

			printf("\nColour Part count : [%d]",Count);
			//UniqPart = (char **) MEM_alloc(strlen(PartNumCDup) * sizeof(char *));
			UniqPart = (char**)MEM_alloc( 10000 * sizeof *UniqPart );
			temp = (char**)MEM_alloc( 10000 * sizeof *temp );
			UniqPartno = (char**)MEM_alloc( 10000 * sizeof *UniqPartno );

			if (Count > 0)
			{

				for ( ii = 0; ii < Count ; ii++ )
				//{
				{
				
						//PartNumC = NULL;
						//PartNumCDup = NULL;
					
						PartTagDup = ColPartTags[ii];

						//ITK_CALL(AOM_ask_value_string(PartTagDup,"t5_PartType",&partType));
						ITK_CALL(AOM_ask_value_string(PartTagDup,"item_id",&PartNumC));
						tc_strdup(PartNumC,&PartNumCDup);
						printf("\nColor Part of [%s] is : [%s]",EstimateSheetNo,PartNumCDup);
					//	printf("\nvalue of ii : [%d]",ii);
						//printf("\nvalue of j : [%d]",j);

						
						//UniqPartno = (char **) MEM_alloc(strlen(PartNumCDup) * sizeof(char *));

						//UniqPart[ii] = (char *)MEM_alloc( strlen(PartNumCDup) + 1);	
						UniqPartno[ii] = (char *)MEM_alloc( strlen(PartNumCDup) + 1);	
						//UniqPart[j] = (char *)MEM_alloc( strlen(PartNumCDup) + 1);	

																						
						//tc_strcpy(UniqPart[ii],PartNumCDup);

						//printf("\n 11111111111111 [%s]:",UniqPart[ii]);

						setAddStr(&p,&UniqPart,PartNumCDup);
						//printf("\n Value of p:[%d]",p);
				}
				//printf("\n Value of p:[%d]",p);
				int t = 0;
				int count = 0;

				for (i = 0 ; i< p ; i++ )
				{


							
						Partno = UniqPart[i];

						printf("\n11111111111111");
						
						//printf("\n[%s]",UniqPart[i]);
						//printf("\n[%s]",UniqPart[j]);

						int j;

						printf("\ncount : [%d]",count);
						printf("\nj : [%d]",j);

							for (j = 0; j < count; j++)
							{
									

									printf("\n22222222222222");
									//printf("\n[%s]",Partno);
									//printf("\n[%s]",UniqPart[j]);

								//if (tc_strcmp(Partno,UniqPart[j])==0)

								printf("\ntemp [%d]: [%s]",j,temp[j]);
								if(tc_strcmp(UniqPart[i],temp[j])==0)
								{

										printf("\n3333333333333");
										//t++;
										//printf("\nUniqPartno:[%s]",Partno);
										break;

										//setAddStr(&k,&UniqPartno,UniqPart[i]);
										//break;
									//setAddStr(&k,&UniqPartno,Partno);
									//break;

									
								}

							}
								if (j == count)
								{

									printf("\n********");
									temp[count]= (char *)MEM_alloc( strlen(Partno) + 1);	
									tc_strcpy(temp[count],Partno);
									printf("unique elements in an array is [%s]",Partno);
									setAddStr(&k,&UniqPartno,Partno);
									count++;


								}


								

							
							//if (t==0)
							//{
							//	setAddStr(&k,&UniqPartno,Partno);
							//
							//}


						
		
					
				}

				printf("\n Value of k:[%d]",k);

				//exit(0);
				int ik =0;

				for (ik = 0 ;ik < k ; ik++ )
				{

						UniqueColour = UniqPartno[ik];

						printf("\nUniqueColour[%d] : [%s]",ik,UniqPartno[ik]);
				
						EstimateSheetNoNm=(char *) MEM_alloc(50);
						tc_strcpy(EstimateSheetNoNm,EstimateSheetNo);
						tc_strcat(EstimateSheetNoNm,"*");
						
						printf("\nQuerying Estimate sheet No : [%s]",EstimateSheetNoNm);
						ITK_CALL(QRY_find2("EstimateSheetPlantWiseQry", &Query_Tag));

			
						
						if (Query_Tag)
						{
						
							printf("\nFound Query : EstimateSheetPlantWiseQry");fflush(stdout);
						
							values[0] = (char *)MEM_alloc( strlen( EstimateSheetNoNm ) + 1);
							tc_strcpy(values[0], EstimateSheetNoNm);
						
						
							if(QRY_execute(Query_Tag, value_entries, entries, values, &n_items, &items));
							ITK_CALL(QRY_execute_with_sort(Query_Tag, value_entries, entries, values,num_to_sort,keysAttr,sort_order, &n_items, &items));
						
							printf("\nResultCount :%d:\n",n_items);fflush(stdout);


						
							if( n_items > 0)
							{
						
								for (i=0 ; i < n_items ; i++ )
								{
						
									EpochItemRevTag = items[i];
						
									//ITK_CALL(TCTYPE_ask_object_type(EpochItemRevTag,&objTypeTag));
									//ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
									//OUTS("Type_name",10,15,type_name); 
						
									ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"object_string",&LatRevName));
						
									trimTrailing(LatRevName);
									trimLeading(LatRevName);
						
									//OUTS("Estimate sheet name",10,15,LatRevName);fflush(stdout);
									printf("\n\tEstimate sheet name : [%s]",LatRevName);
						
						
									ITK_CALL(AOM_ask_value_logical(EpochItemRevTag,"t5_EPCOHFlg",&EPCOHFlg));
									printf("\n\tEPCOHFlg name : [%d]",EPCOHFlg);fflush(stdout);
									ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"release_status_list",&EstSheetRelStat));
									//OUTS("EstSheetRelStat",10,15,EstSheetRelStat);//t5_ActualRelDate
									printf("\n\tEstSheetRelStat : [%s]",EstSheetRelStat);//t5_ActualRelDate
									ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"object_string",&revseq));
									//OUTS("EstSheetRelStat Revseq ",10,15,revseq);//t5_rev
									trimTrailing(revseq);
									trimLeading(revseq);
									printf("\n\tEstSheetRelStat Revseq : [%s]",revseq);//t5_rev
									
									ITK_CALL(AOM_ask_value_date(EpochItemRevTag,"t5_ActualRelDate",&EstSheetClsrTstm_date));
									ITK_CALL(DATE_date_to_string ( EstSheetClsrTstm_date, "%d-%b-%Y %H:%M:%S", &EstSheetClsrTstm ));
									//OUTS("EstSheetClsrTstm",10,15,EstSheetClsrTstm);
									printf("\n\tEstSheetClsrTstm : [%s]\n",EstSheetClsrTstm);
									printf("\t**************************************************");

						
									if ( EPCOHFlg == 1 )
									//if ( tc_strcmp(EPCOHFlg,"1" ) == 0)
									{
											
										if ( tc_strstr( EstSheetRelStat,"PSD Final Released") != NULL )
										{
											if ( tc_strcmp(EstSheetClsrTstm,"" ) != 0)
											{
						
												ITK_CALL(AOM_UIF_ask_value(EpochItemRevTag,"object_string",&revseq));
												//OUTS("EstSheetRelStat Revseq ",10,15,revseq);//t5_rev
												trimTrailing(revseq);
												trimLeading(revseq);
												printf("\n\tEstSheetRelStat Revseq : [%s]",revseq);//t5_rev
												if ( Strs != NULL)
												{
													MEM_free(Strs);
												}
												Strs = (char *) MEM_alloc ( 100000 * sizeof ( char ) );
												tc_strcpy ( Strs, "" );
												PPEstimate = MEM_alloc ( 10 );
												tc_strcpy ( PPEstimate, "PP03" );
												PEUserKey = MEM_alloc ( 10 );
												tc_strcpy ( PEUserKey, "CARKEY1" );
												//ITK_CALL(GRM_find_relation_type("T5_EstimateOprtnRevision", &reln_type));
												ITK_CALL(GRM_list_secondary_objects_only(EpochItemRevTag,reln_type,&n_attchs,&secondary_objects));
												printf("\nNo of operations found:%d",n_attchs);
						
												for ( i = 0; i < n_attchs; i++)
												{
													
													primary = secondary_objects[i];
													ITK_CALL(TCTYPE_ask_object_type(primary,&objTypeTag_opr));
													ITK_CALL(TCTYPE_ask_name(objTypeTag_opr,type_name_opr));
													//printf("\ntype_name_opr:%s",type_name_opr);fflush(stdout);
													if ( tc_strcmp ( type_name_opr, "T5_EstimateOprtnRevision" ) == 0 )
													{
														if ( RpStr != NULL)
														{
															MEM_free(RpStr);
														}
														RpStr = MEM_alloc(2500);
														ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"item_id",&EstimateSheet));
														EstimateSheetNoO = strtok(EstimateSheet,"-");
														ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"t5_PEPlantName",&EstPlantName));
														ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"t5_PEAgency",&EstPEAgency));
														ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"t5_PEProcessEDNNo",&EstProEDNNo));
														sEstProEDNNo = MEM_alloc(10);
														tc_strcpy ( sEstProEDNNo, EstProEDNNo );
														tc_strcat ( sEstProEDNNo, "R" );
														ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"project_ids",&EstProID));
														//ITK_CALL(AOM_ask_value_string(EpochItemRevTag,"op_range",&ItemRevSeq));//op range
														ITK_CALL(AOM_ask_value_string(primary,"t5_EPOCHPEBCNo",&EstEPOCHPEBCNo));
														ITK_CALL(AOM_ask_value_string(primary,"t5_PEPartPerCycle",&EstPEPartPerCycle));
														ITK_CALL(AOM_ask_value_string(primary,"t5_EPOCHValue",&EstEPOCHValue));
														if ( EstEPOCHValue == NULL )
														{
															EstEPOCHValue = MEM_alloc(10);
															tc_strcpy ( EstEPOCHValue, "0.00" ) ;
														}
														tc_strcpy(sEstEPOCHValue,"");
														fEstEPOCHValue = atof(EstEPOCHValue);
														
														//START CHANGES (FOR JSR APL CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE)
														ITK_CALL(AOM_ask_value_string(primary,"t5_EPOCHUom",&EPOCHUomStr));
														trimTrailing(EPOCHUomStr);							
														trimLeading(EPOCHUomStr);
														if((tc_strcmp(EPOCHUomStr,"Min") == 0) && (tc_strcmp(EstPlantName,"CVBU JSR") == 0))
														{
															printf("\n Converting EPOCHValue to Hours..dividing by 60");fflush(stdout);
															fEstEPOCHValue = fEstEPOCHValue / 60;
														}
														printf("\n APL Calculated Time: %.2f",fEstEPOCHValue);
														sprintf(sEstEPOCHValue,"%.2f",fEstEPOCHValue);
														//END CHANGES (FOR JSR APL CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE)
						
														ITK_CALL(AOM_ask_value_string(primary,"t5_PSDCalTime",&EstPSDCalTime));
														if ( EstPSDCalTime == NULL )
														{
															EstPSDCalTime = MEM_alloc(10);
															tc_strcpy ( EstPSDCalTime, "0.00" ) ;
														}
														tc_strcpy(sEstPSDCalTime,"");
														fEstPSDCalTime = atof(EstPSDCalTime);
														
														//START CHANGES (FOR JSR PSD CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE) 
														if(tc_strcmp(EstPlantName,"CVBU JSR") == 0)
														{
															fEstPSDCalTime = fEstPSDCalTime / 60;
														}
														printf("\n PSD Calculated Time: %.2f",fEstPSDCalTime);
														//END CHANGES (FOR JSR PSD CALCULATED TIME IN SAP IS HOUR & IN TCUA IS IN MINUTE)
														
														sprintf(sEstPSDCalTime,"%.2f",fEstPSDCalTime);
						                             
														//"CARKEY1"
														ITK_CALL(AOM_ask_value_string(primary,"t5_PEMMAInd",&EstPEMMAInd));
														//CHANGES FOR NULL VALUE CHECK
														if(tc_strlen(EstPEMMAInd)>0)
														{
														   tc_strdup(EstPEMMAInd,&EstPEMMAIndDup);
														}
														else
														{
														   tc_strdup(" ",&EstPEMMAIndDup);
														}
														printf("\nEstPEMMAInd: [%s]",EstPEMMAIndDup);
														//CHANGES FOR NULL VALUE CHECK
														
														ITK_CALL(AOM_ask_value_string(primary,"item_id",&EstOpnNo));
														printf("\nEstOpnNo: [%s]",EstOpnNo);
														ITK_CALL(AOM_ask_value_string(primary,"t5_PEOpnDesc",&EstPEOpnDesc));
						
														EstPEOpnDesc = replaceWord(EstPEOpnDesc, "\n", " ");
														EstPEOpnDesc = replaceWord(EstPEOpnDesc, "\t", " ");
														EstPEOpnDesc = replaceWord(EstPEOpnDesc, "\r", " ");
														EstPEOpnDesc = replaceWord(EstPEOpnDesc, ",", ";");
						
														sEstEPOCHPEBCNo = MEM_alloc(10);
														
														if ( tc_strcmp(EstEPOCHPEBCNo, "3240" ) == 0 )
														{
															printf("\n%s Skipping %s",EstimateSheetNoO,EstEPOCHPEBCNo);
															continue;
														}
														if ( *EstEPOCHPEBCNo == '9' )
														{
															printf("\n%s Skipping %s",EstimateSheetNoO,EstEPOCHPEBCNo);
															continue;
														}
														tc_strcpy ( sEstEPOCHPEBCNo,EstEPOCHPEBCNo ) ;

														if (tc_strcmp(EstPlantName,"CAR")==0)
														{

															if ( ( tc_strcmp(EstEPOCHPEBCNo, "2872" ) == 0 ) || ( tc_strcmp(EstEPOCHPEBCNo, "2310" ) == 0 ) )
															{
																tc_strcat( sEstEPOCHPEBCNo, "0005" ) ;
															}
															else
															{
																tc_strcat( sEstEPOCHPEBCNo, "0002" ) ;
															}
														}
														
														if (tc_strcmp(EstPlantName,"CVBU JSR")==0)
														{
														 
														  //if ( ( tc_strcmp(EstEPOCHPEBCNo, "2872" ) == 0 ) || ( tc_strcmp(EstEPOCHPEBCNo, "2310" ) == 0 ) )
														  //{
														  //	tc_strcat( sEstEPOCHPEBCNo, "0005" ) ;
														  //}
														  //else
														  //{
															tc_strcat( sEstEPOCHPEBCNo, "0002" ) ;
														  //}
														}
											
														if (tc_strstr(EstEPOCHPEBCNo,"2026")!=NULL || tc_strstr(EstEPOCHPEBCNo,"2027")!=NULL || tc_strstr(EstEPOCHPEBCNo,"2028")!=NULL)
														{
															  flag = 3;
														}
														else if (tc_strcmp(EstPlantName,"CAR")==0)
														{
															 flag = 1;
														} else if(tc_strstr(EstProID,"2788")!=NULL || tc_strstr(EstProID,"2818")!=NULL || tc_strstr(EstProID,"2829")!=NULL || tc_strstr(EstProID,"2834")!=NULL || tc_strstr(EstProID,"2850")!=NULL || tc_strstr(EstProID,"2851")!=NULL || tc_strstr(EstProID,"2857")!=NULL || tc_strstr(EstProID,"2861")!=NULL || tc_strstr(EstProID,"2864")!=NULL || tc_strstr(EstProID,"5517")!=NULL || tc_strstr(EstProID,"5523")!=NULL || tc_strstr(EstProID,"5705")!=NULL || tc_strstr(EstProID,"5708")!=NULL || tc_strstr(EstProID,"5710")!=NULL || tc_strstr(EstProID,"5717")!=NULL || tc_strstr(EstProID,"5721")!=NULL || tc_strstr(EstProID,"5801")!=NULL || tc_strstr(EstProID,"5807")!=NULL || tc_strstr(EstProID,"5813")!=NULL || tc_strstr(EstProID,"5814")!=NULL)
														{
															 flag = 2;
														} else if (tc_strcmp(EstPlantName,"CVBU PUNE")==0)
														{ 
															flag = 4;
														}
														else if (tc_strcmp(EstPlantName,"PUVBU")==0)
														{ 
															flag = 5;
														}
														else if (tc_strcmp(EstPlantName,"SMALLCAR AHD")==0)
														{ 
															flag = 6;
														}
														else if (tc_strcmp(EstPlantName,"CVBU JSR")==0)
														{ 
															flag = 7;
														}


						
														Plant = MEM_alloc(50);
														if ( flag == 1 )
														{
														  tc_strcpy(Plant,"1100");
														} 
														else if ( flag == 2 )
														{
															tc_strcpy(Plant,"3100");
														} 
														else if ( flag == 3 )
														{
															tc_strcpy(Plant,"1020");
														} 
														else if ( flag == 4 )
														{ 
															tc_strcpy(Plant,"1001"); 
														}
														else if ( flag == 5 )
														{ 
															tc_strcpy(Plant,"1140"); 
														}
														else if ( flag == 6 )
														{ 
															tc_strcpy(Plant,"E201"); 
														}
														else if ( flag == 7 )
														{ 
															tc_strcpy(Plant,"2001"); 
														}
														tc_strcpy(sOpRange,"");
														iOpRange = iOpRange + 10;
														sprintf(sOpRange,"%04d",iOpRange);
						
														//printf("\n%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s \t \t \t\t%s\t%s\t%s\t%s",EstimateSheetNoO,Plant,EstPEAgency,sEstProEDNNo,sOpRange,sEstEPOCHPEBCNo,PPEstimate,EstPEPartPerCycle,sEstEPOCHValue,sEstPSDCalTime,PEUserKey,EstPEMMAInd,EstOpnNo,EstPEOpnDesc);
														//sprintf(RpStr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s \t \t \t\t%s\t%s\t%s\t%s\n",UniqueColour,Plant,EstPEAgency,sEstProEDNNo,sOpRange,sEstEPOCHPEBCNo,PPEstimate,EstPEPartPerCycle,sEstEPOCHValue,sEstPSDCalTime,PEUserKey,EstPEMMAInd,EstOpnNo,EstPEOpnDesc);
														sprintf(RpStr,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t \t \t \t%s\t%s\t%s\t%s\n",UniqueColour,Plant,EstPEAgency,sEstProEDNNo,sOpRange,sEstEPOCHPEBCNo,PPEstimate,EstPEPartPerCycle,sEstEPOCHValue,sEstPSDCalTime,PEUserKey,EstPEMMAIndDup,EstOpnNo,EstPEOpnDesc);
														printf("\n%s",RpStr);
														tc_strcat ( Strs, RpStr );
													}
												}
												
												if ( tc_strcmp ( Plant, "1100" ) == 0 )
												{
													tc_strcpy ( FileName, "" );
													StdDate = MEM_alloc ( 9 );
													getTodayDate ( StdDate );
													//tc_strcpy ( FileName, "/user/uaprodtrl/PLMSAP/UAEPOCH_User/EstimateSheet/" );
													tc_strcpy ( FileName, "epochcarpsdua" );
													tc_strcat ( FileName, StdDate );
													//tc_strcat ( FileName, "/" );
													//tc_strcat ( FileName, EstimateSheetNo );
													tc_strcat ( FileName, ".txt" );
													fp = fopen ( FileName, "a" );
													fprintf ( fp, "%s" , Strs );
													if ( fp )
													{
														fclose ( fp );
													}
												}
												else if ( tc_strcmp ( Plant, "E201" ) == 0 )
												{
													tc_strcpy ( FileName, "" );
													StdDate = MEM_alloc ( 9 );
													getTodayDate ( StdDate );
													//tc_strcpy ( FileName, "/user/uaprodtrl/PLMSAP/UAEPOCH_User/EstimateSheet/" );
													tc_strcpy ( FileName, "epochsnd2psdua" );
													tc_strcat ( FileName, StdDate );
													//tc_strcat ( FileName, "/" );
													//tc_strcat ( FileName, EstimateSheetNo );
													tc_strcat ( FileName, ".txt" );
													fp = fopen ( FileName, "a" );
													fprintf ( fp, "%s" , Strs );
													if ( fp )
													{
														fclose ( fp );
													}
												}

												else if ( tc_strcmp ( Plant, "2001" ) == 0 )
												{
													tc_strcpy ( FileName, "" );
													StdDate = MEM_alloc ( 9 );
													getTodayDate ( StdDate );
													//tc_strcpy ( FileName, "/user/uaprodtrl/PLMSAP/UAEPOCH_User/EstimateSheet/" );
													tc_strcpy ( FileName, "epochjsrpsdua" );
													tc_strcat ( FileName, StdDate );
													//tc_strcat ( FileName, "/" );
													//tc_strcat ( FileName, EstimateSheetNo );
													tc_strcat ( FileName, ".txt" );
													fp = fopen ( FileName, "a" );
													fprintf ( fp, "%s" , Strs );
													if ( fp )
													{
														fclose ( fp );
													}
												}
								
										
											}
											break; //31.07.2023
						
										}
						
									}
						
								}
						
							}
							else
							{
						
								OUTS("Estimate SheetNumber not found in TCUA",10,15,EstimateSheetNo); 
								return 0;
						
						
							}
						
						}

			

				//}
				}

			}

			else
			{
					printf("\nColour part relation not found.....");
			}



	
	}

	if(values) MEM_free(values);
	CLEANUP:
		printf("\nCLEANUP..."); fflush(stdout);
		ITK_CALL(POM_logout(false));
		return status;

	EXIT:
		printf("\nExiting...\n");
		ITK_CALL(POM_logout(false));
		return status;
		return ITK_ok;
}












	
 
	






	
