#include "malloc.h"
#include "stdio.h"

#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <user_exits/user_exits.h>
#include <tc/envelope.h>

#include "wmhelpe.h"
#include "bapi.h"
#include "saprfc.h"
#include "sapitab.h"
#include "t.h"

#define PartCounterLimit 3000
static int PartCounter = 0;
static int PartbatchCounter = 0;
static int PartinspallocCounter = 0;

FILE * fsuccess;
FILE* fp=NULL;

char fsuccess_name[200];

WERKS_D eWerks;
static MATNR eMatnr;

int apl_dml_flag = 0;
int car_dml = 0;
int go_for_rfc = 0;
int flag_vc_v_tpl = 0;
int flag = 0;
int acc_flag = 0;

struct MaterialBatches
{
	char part_noDup[50];
	char mat_type[50];
	char splantcode[50];
	char dml_no_arg[50];
	char overhd_grp[50];
	char origin_group[50];
};

struct MaterialBatches batches[PartCounterLimit];

char *part_noDupDes=NULL;
char *part_noDupDesx=NULL;
char *OldMatNoDup=NULL;
char *doc_no=NULL;
char *basic_division=NULL;
char *unit_wt=NULL;
char *volume=NULL;
char *vol_unit=NULL;
char *material_group=NULL;
char *doc_noDup=NULL;
char *dwg_typeDup=NULL;
char *tmpDrwNum1=NULL;
char *tmpDrwNum=NULL;
char *tmpDrwRev=NULL;
char *tmpDrwSeq=NULL;
char *dwg_revDup=NULL;
char *dwg_rev=NULL;
char *sizeDup=NULL;
char *sheet_noDup=NULL;
char *old_mat_no=NULL;
char *net_wt=NULL;
char *net_wtDup=NULL;
char *gross_wt=NULL;
char *part_noDup=NULL;
char *Plant_MakeBuy=NULL;
char *Plant_StoreLoc=NULL;
char *make_buy_indDup=NULL;
char *make_buy_ind=NULL;
char *mat_type=NULL;
char *store_loc=NULL;
char *store_locDup=NULL;
char *mrp_grp=NULL;
char *mrp_type=NULL;
char *abc_ind=NULL;
char *odstatus=NULL;
char *num;
char *drstatus = NULL;
char *drstatusDup = NULL;
char *mm_pp_status = NULL;
char *partClrIndDup = NULL;
char *partClrInd = NULL;
char *reord_pt = NULL;
char *quota_arrangement_usage = NULL;
char *mrp_controller = NULL;
char *lot_size_key = NULL;
char *fixed_lot_size = NULL;
char *max_stlvl = NULL;
char *blk_ind = NULL;
char *sched_mar_key = NULL;
char *req_grp = NULL;
char *period_ind = NULL;
char *mixedmrp = NULL;
char *cs1_val = NULL;
char *alternativb = NULL;
char *avail_chk = NULL;
char *splan_mat = NULL;
char *splan_plant = NULL;
char *splan_conv_fact = NULL;
char *ind_collect = NULL;
char *rep_mfg_in = NULL;
char *rep_mfg = NULL;
char *stock_det_group = NULL;
char *uoissue = NULL;
char *qua_ins_ind = NULL;
char *doc_req = NULL;
char *grptime = NULL;
char *certificate_type = NULL;
char *qm_proc_ind = NULL;
char *control_key = NULL;
char *catalog_prof = NULL;
char *valuation_cat = NULL;
char *price_con = NULL;
char *std_price = NULL;
char *moving_avg_price = NULL;
char *val_class = NULL;
char *mat_origin = NULL;
char *cost_lot_size = NULL;
char *variance_key = NULL;
char *with_quantity_structure = NULL;
char *costing_split_valuation = NULL;
char *costing_val_class = NULL;
char *MatCrChFlag = NULL;
char *dml_numAP1 = NULL;
char *PrtRevDup = NULL;
char *OrgIDDup = NULL;
char *plan_calendar = NULL;
char *profit_centre_sap = NULL;
char *overhd_grp = NULL;
char *dml_no_arg = NULL;
char *myzeroDup3 = NULL;
char *myzeroDup1 = NULL;
char *myzeroDup2 = NULL;
char *myzeroDup4 = NULL;
char *sap_msg = NULL;
char *p;


char *plantcode=NULL;
char *profit_centre2=NULL;
char *plan_calendar2=NULL;
char *overhd_grp2=NULL;
char *origin_group2=NULL;
char *origin_group=NULL;
char *meas_unit=NULL;
char *desc=NULL;
char *descDup=NULL;
char *drg_ind=NULL;
char *drg_indDup=NULL;
char *docClass=NULL;
char *spl_proc_key=NULL;
char *OwnerNameDup=NULL;
char *OwnerName=NULL;
char *proc_type;

char *inputPart=NULL;
char *iPlantCode=NULL;
char *iSapServer=NULL;


char *sap_proc_type=NULL;
char *sap_spproc_type=NULL;
char *SAPpstat=NULL;
char *MRPpstat=NULL;
char pstat;
char pstat_mrp;
char pstat_acc;
char proc_Key;
char spl_Key;
char group;


//drwnum = (char *)malloc(500 * sizeof(char));


#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
void rfc_error(char *);

RFC_RC allocate_insp_type(void);
RFC_RC allocate_insp_type_vc(void);
RFC_RC cll_zrfc_insptype_alloc(RFC_HANDLE);
RFC_RC vc_zrfc_insptype_alloc(RFC_HANDLE );

void nbcd2str(char *str,unsigned char *bcd,size_t size,int decimals);
void str2nbcd(char *str,unsigned char *bcd,size_t size,int decimals);

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

int pstat_basicFun(void)
{
	//printf("\n In pstat_basicFun function..[%s]\n",sappstat); fflush(stdout);
	if(tc_strlen(tc_strstr(SAPpstat,"K"))>0)
	{
		pstat = 'K';
	}
	else
	{
		pstat = '0';
	}

	
   if(tc_strlen(tc_strstr(MRPpstat,"D"))>0)
	{
		pstat_mrp = 'D';
	}
	else
	{
		pstat_mrp = '0';
	}

	
  if(tc_strlen(tc_strstr(MRPpstat,"B"))>0)
	{
		pstat_acc = 'B';
	}
	else
	{
		pstat_acc = '0';
	}
	//printf("\n..%c:%c:%c..\n",pstat,pstat_mrp,pstat_acc); fflush(stdout);
	return 0;
}

FetchPlantSpecificData(char* plantcode)
{
	char	*DMLNo			= NULL;
	char	*PlantSuffix	= NULL;
	char	*SAPLivFlg		= NULL;
	
	int     n_entry			= 3;
	int     p_entry			= 2;
	int		ContObjCnt		= 0;

	tag_t   PlantCodeQryTag     = NULLTAG;
	tag_t   MakeBuyQryTag		= NULLTAG;
	tag_t   PlantDataQryTag     = NULLTAG;
	tag_t   *ContorlObjTag     = NULLTAG;

	char    *qry_entryApl[3]  = {"SYSCD","SUBSYSCD","Information-1"};
	char    *qry_entryStd[3]  = {"SYSCD","SUBSYSCD","Information-2"};

	char    *qry_entryMake[2] = {"SYSCD","SUBSYSCD"};

	PlantSuffix  = strtok ( NULL, "_" );
	
	//tc_strcpy(dml_no_arg,DMLNo);
	//tc_strcpy(dml_numAP1,DMLNo);

	//printf("\nDMLNo [%s]	PlantSuffix [%s]	Project Code [%s]", DMLNo,PlantSuffix,ProjCode);

	//char	*qry_value[3] = {"XFRDML",ProjCode,PlantSuffix};
	
	if(QRY_find("Control Objects...", &PlantCodeQryTag));

	if(PlantCodeQryTag)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		/*if(QRY_execute(PlantCodeQryTag,n_entry,qry_entryApl,qry_value,&ContObjCnt,&ContorlObjTag));

		if (ContObjCnt==0)
		{
			if(QRY_execute(PlantCodeQryTag,n_entry,qry_entryStd,qry_value,&ContObjCnt,&ContorlObjTag));
		}

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&plantcode);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&SAPLivFlg);
			printf("\nPlantSuffix [%s]	Plant Code [%s]",PlantSuffix,plantcode);
		}
		else
		{
			printf("\nProjectCode [%s] do not have entry in Control Object PlantDML for Suffix [%s] hence exiting!",ProjCode,PlantSuffix); fflush(stdout);
			goto CLEANUP;
		}*/

		char    *qry_MakeValue[2]  = {"MAKEBUY",plantcode};
		
		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_MakeValue,&ContObjCnt,&ContorlObjTag));

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&Plant_StoreLoc);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&Plant_MakeBuy);
			printf("\nPlant Code [%s]	Plant_MakeBuy [%s]	Plant_StoreLoc [%s]",plantcode,Plant_MakeBuy,Plant_StoreLoc);
		}
		else
		{
			printf("\nPlantcode [%s] do not have entry in Control Object MAKEBUY hence exiting!",plantcode); fflush(stdout);
			goto CLEANUP;
		}



		char    *qry_PlantValue[2]  = {"PLANTDATA",plantcode};

		if(QRY_execute(PlantCodeQryTag,p_entry,qry_entryMake,qry_PlantValue,&ContObjCnt,&ContorlObjTag));

		if(ContObjCnt >0)
		{
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo1",&profit_centre2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo2",&plan_calendar2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo3",&overhd_grp2);
			AOM_ask_value_string(ContorlObjTag[0],"t5_Userinfo4",&origin_group2);

			tc_strcpy(profit_centre_sap,"000");
			tc_strcat(profit_centre_sap,profit_centre2);
			tc_strdup(plan_calendar2,&plan_calendar);
			tc_strdup(overhd_grp2,&overhd_grp);
			tc_strdup(origin_group2,&origin_group);

			printf("\nplantcode      :[%s]",plantcode);
			printf("\nprofit_centre  :[%s]",profit_centre_sap);
			printf("\nplan_calendar  :[%s]",plan_calendar);
			printf("\noverhd_grp     :[%s]",overhd_grp);
			printf("\norigin_group   :[%s]",origin_group);
		}

	}

	CLEANUP:
	return ContObjCnt;
}

BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	tag_t	SapServerQry	= NULLTAG;
	tag_t	*SSQObjTags		= NULLTAG;

	int two_entry = 2;
	int SSQCount = 0;
	int nSysnr = 0;

	char *SSHostName	= NULL;
	char *SSUser		= NULL;
	char *SSPassword	= NULL;
	char *SSDestination	= NULL;
	char *SSClient		= NULL;
	char *SSGateway		= NULL;
	char *SSSysnr		= NULL;

	char    *two_fields[2] = {"SYSCD","SUBSYSCD"};

	if(QRY_find("Control Objects...", &SapServerQry));

	if(SapServerQry)
	{
		printf("\nFound Query : Control Objects...\n"); fflush(stdout);

		char    *two_value[2]  = {"SAPCON",iSapServer};
		
		if(QRY_execute(SapServerQry,two_entry,two_fields,two_value,&SSQCount,&SSQObjTags));

		if(SSQCount >0)
		{
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo1",&SSHostName);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo2",&SSUser);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo3",&SSPassword);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo4",&SSDestination);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo5",&SSGateway);
			AOM_ask_value_string(SSQObjTags[0],"t5_Userinfo6",&SSSysnr);
			AOM_ask_value_string(SSQObjTags[0],"t5_RecordType",&SSClient);
			
			nSysnr = atoi (SSSysnr);
			printf("\nConnecting to SAP Server %s",iSapServer); fflush(stdout);

			RfcOptions.destination =SSDestination;
			RfcOptions.client = SSClient;
			RfcOptions.user = SSUser;
			RfcOptions.language = "EN";
			RfcOptions.password = SSPassword;
			RfcOptions.trace = 1;
			RfcConnoptR3only.hostname=SSHostName;
			RfcConnoptR3only.gateway_host=SSHostName;
			RfcConnoptR3only.gateway_service=SSGateway;
			RfcConnoptR3only.sysnr=nSysnr;
			RfcOptions.connopt = &RfcConnoptR3only;
		}
		else
		{
			printf("\nSAP Server %s details not found; exiting!",iSapServer); fflush(stdout);
			exit(0);
		}

		printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
		hRfc = RfcOpen(&RfcOptions);
		if (hRfc == RFC_HANDLE_NULL)
		{
			printf("\nERROR RECEIVED CPIC-ERROR");
			exit(0);
		}
		else
		{
			printf("\nGot the connection!!!");
			RfcEnvironment(&RfcEnv);
		}

	}
	return hRfc;
}

RFC_RC allocate_insp_type(void)
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;

	hRfc = BapiLogon();
	printf("\nReturned value = %u", hRfc);
	if (hRfc == RFC_HANDLE_NULL)
		printf("\nRfcOpen");
	if (hRfc == 0)
	{
		printf("\nRFC connection is not present.");
	}
	else
		RfcRc = cll_zrfc_insptype_alloc(hRfc);
	//fprintf(fsuccess,"\n******************************************************************");
	RfcClose(hRfc);
	printf("\nRFC connection is closed");
	return RfcRc;
}

RFC_RC  cll_zrfc_insptype_alloc(RFC_HANDLE hRfc)
{
	int count = 0;
	static RFC_RC RfcRc;
	static QPART eQpart;
	MESSAGEINF iMessg;
	SYST_SUBRC iRetval;
	char xException[256];
	char xMessage[80]={0};
	WERKS_D eWerks;
	static  MATNR eMatnr;


	SETCHAR(eMatnr.Matnr,"");
	SETCHAR(eQpart.Qpart,"");
	SETCHAR(eWerks.WerksD,"");
	SETCHAR(eMatnr.Matnr,part_noDup);

	printf("\nInspection alloc %s %s",part_noDup,plantcode); fflush(stdout);

	SETCHAR(eWerks.WerksD,plantcode);

	for (count = 0; count < 4; count++)
	{
		SETCHAR(eQpart.Qpart,"");
		if (count == 0) SETCHAR(eQpart.Qpart,"01");
		if (count == 1) SETCHAR(eQpart.Qpart,"0101");
		if (count == 2) SETCHAR(eQpart.Qpart,"0102");
		if (count == 3) SETCHAR(eQpart.Qpart,"8901");

		RfcRc = zrfc_insptype_alloc(hRfc,&eMatnr,&eQpart,&eWerks,&iMessg,&iRetval,xException);

		switch (RfcRc)
		{
			case RFC_OK:
				strcpy(xMessage,"");
				tc_strncpy(xMessage,iMessg.Msgtx,60);
				xMessage[61]='\0';
				printf("\ninsptype_alloc[%s,%s] :[%s]",part_noDup,plantcode,xMessage); fflush(stdout);
				fprintf(fsuccess,"\ninsptype_alloc[%s,%s] :[%s]",part_noDup,plantcode,xMessage); fflush(fsuccess);

				if(tc_strstr(xMessage,"batch input data for screen SAPLMGMM 4000")!=NULL)
				{
				      fprintf(fsuccess,"%s,%s\n",part_noDup,plantcode);
                }
			break;
			case RFC_EXCEPTION:
				printf("\nRFC Exception : %s",xException); fflush(stdout);
			break;
			case RFC_SYS_EXCEPTION:
				printf("\nSystem Exception Raised!!!"); fflush(stdout);
			break;
			case RFC_FAILURE:
				printf("\nFailure!!!"); fflush(stdout);
			break;
			default:
				printf("\nOther Failure!"); fflush(stdout);
		}
		sleep(2);
	}
	return RfcRc;
}


RFC_RC allocate_insp_type_vc(void)
{
	static RFC_HANDLE hRfc;
	static RFC_RC RfcRc;

	hRfc = BapiLogon();
	printf("\nReturned value = %u", hRfc);
	if (hRfc == RFC_HANDLE_NULL)
		printf("\nRfcOpen");
	if (hRfc == 0)
	{
		printf("\nRFC connection is not present.");
	}
	else
		RfcRc = vc_zrfc_insptype_alloc(hRfc);
	//fprintf(fsuccess,"\n******************************************************************");
	RfcClose(hRfc);
	printf("\nRFC connection is closed");
	return RfcRc;
}

RFC_RC vc_zrfc_insptype_alloc(RFC_HANDLE hRfc)
{
	static RFC_RC RfcRc;
	static QPART eQpart;
	MESSAGEINF iMessg;
	SYST_SUBRC iRetval;
	char xException[256];

	printf("\nInspection Alloc for VC QM View %s %s",part_noDup,plantcode);

	/*SETCHAR(eMatnr.Matnr,"");
	SETCHAR(eQpart.Qpart,"");
	SETCHAR(eWerks.WerksD,"");*/
	
	SETCHAR(eMatnr.Matnr,part_noDup);/*rfc_partno*/
	SETCHAR(eWerks.WerksD,plantcode);
	SETCHAR(eQpart.Qpart,"08");

	RfcRc = zrfc_insptype_alloc(hRfc,&eMatnr,&eQpart,&eWerks,&iMessg,&iRetval,xException);

	switch (RfcRc)
	{
		case RFC_OK:
			/*printf("\nReturned value from zrfc_insptype_alloc = %u",RFC_OK);*/
			printf("\ninsptype_alloc = %s",iMessg.Msgty);
			//fprintf(fsuccess,"\ninsptype_alloc = %s",iMessg.Msgty);
			/*printf("\nMsgid = %s",iMessg.Msgid);
			printf("\nMsgno = %s",iMessg.Msgno);
			printf("\nMsspc = %s",iMessg.Msspc);
			printf("\nMsgtx = %s",iMessg.Msgtx);*/

			break;
		case RFC_EXCEPTION:
			printf("\nRFC Exception = %s",xException);
			break;
		case RFC_SYS_EXCEPTION:
			printf("\nSystem Exception Raised!!!");
			break;
		case RFC_FAILURE:
			printf("\nFailure!!!");
			break;
		default:
			printf("\nOther Failure!");
	}
	return RfcRc;
}

char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}




extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	int kk=0;
	int is=0;
	int sflag=0;
	int i=0;
	int doccount=0;
	int len=0;
	int Refcount=0;
	int resultCount =0;
	int n_entries = 2; //no. of query input arg
	int n_tags_found = 1;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};

	tag_t queryTag = NULLTAG;
	tag_t docOPtr = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t resultOutputTag = NULLTAG;
	tag_t LatestRev=NULLTAG;
    tag_t docRelObjs=NULLTAG;
    tag_t *docObjs=NULLTAG;
    tag_t *refdocObjs=NULLTAG;
    tag_t doctag=NULLTAG;
    tag_t docRelObj=NULLTAG;
    tag_t refdocRelObj=NULLTAG;
	tag_t		*DesignTags			= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;

	char* sUserName	= NULL;
	char* sPassword = NULL;
	char* iFileName = NULL;
	char *LatRevName=NULL;
	char *part_type=NULL;
	char *unit=NULL;
	char *part_typeDup=NULL;
	char *unitDup=NULL;
	char *doc_no=NULL;
	char *PrtRev=NULL;
	char* PartRelStatus = NULL;
	char *Lcs = NULL;

	static RFC_RC RfcRc;
	const char *attrs[2];
	const char *values[2];
	
	char text_line[500];
	FILE *InpFile = NULL;
	int lineCount = 1;

    plantcode=(char *) malloc (500 * sizeof(char));
	profit_centre2 = (char *)malloc(500 * sizeof(char));
	plan_calendar2 = (char *)malloc(500 * sizeof(char));
	overhd_grp2 = (char *)malloc(500 * sizeof(char));
	origin_group2 = (char *)malloc(500 * sizeof(char));
	origin_group = (char *)malloc(500 * sizeof(char));
	mat_type=(char *) malloc(500 * sizeof(char));
	meas_unit=(char *) malloc(500 * sizeof(char));

	sap_proc_type = (char *)malloc(500 * sizeof(char));
	sap_spproc_type = (char *)malloc(500 * sizeof(char));
	SAPpstat = (char *)malloc(500 * sizeof(char));
	MRPpstat = (char *)malloc(500 * sizeof(char));
	myzeroDup1 = (char *)malloc(500 * sizeof(char));
	myzeroDup2 = (char *)malloc(500 * sizeof(char));
	myzeroDup3 = (char *)malloc(500 * sizeof(char));
	myzeroDup4 = (char *)malloc(500 * sizeof(char));
	std_price = (char *)malloc(500 * sizeof(char));
	moving_avg_price = (char *)malloc(500 * sizeof(char));
	cost_lot_size = (char *)malloc(500 * sizeof(char));
	mat_type = (char *)malloc(500 * sizeof(char));
	descDup = (char *)malloc(500 * sizeof(char));
	reord_pt = (char *)malloc(500 * sizeof(char));
	profit_centre_sap = (char *)malloc(500 * sizeof(char));
	part_noDupDes = (char *)malloc(500 * sizeof(char));
	part_noDupDesx = (char *)malloc(500 * sizeof(char));


	//char *qry_entries[1] = {"Name"};
	char *qry_entries[] = {"Item ID","Release Status"};

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	iFileName = ITK_ask_cli_argument("-f=");
	//inputPart = ITK_ask_cli_argument("-i=");
	iPlantCode = ITK_ask_cli_argument("-j=");
	//MatCrChFlag = ITK_ask_cli_argument("-f=");
	iSapServer = ITK_ask_cli_argument("-s=");//uncomment 11.07.2023 Hrishikesh

	tc_strdup("CR",&MatCrChFlag);
	//tc_strdup("PVP",&iSapServer);


	InpFile = fopen(iFileName,"r");


	/*if(tc_strcmp(sUserName,"")==0 || tc_strcmp(sPassword,"")==0 || tc_strcmp(inputPart,"")==0 || tc_strcmp(iPlantCode,"")==0 || tc_strcmp(MatCrChFlag,"")==0 || tc_strcmp(dml_no_arg,"")==0 || tc_strcmp(iSapServer,"")==0)
	{
		printf("\nPartMatCreChangeUA -u=userid -p=password -i=inputPart -j=PlantCode -f=CRCHFlag -c=sap_change_no -s=PVP\n");fflush(stdout);
		goto CLEANUP;
	}*/

	//sprintf(fsuccess_name,"/user/uaprodtrl/PLMSAP/ONE_TIME_LOG/ValTypeCreate_.log");
	sprintf(fsuccess_name,"%s/PLMSAP/ONE_TIME_LOG/Inspectionalloc_%s_%s.log",getenv("ONLREP"),iPlantCode,iSapServer); //added Hrishikesh 11.07.2023
	//sprintf(fsuccess_name,"APL_Sap_Mat_%s.log",inputPart);
	fsuccess = fopen(fsuccess_name,"a");

	//if(QRY_find("QueryDesignRev", &queryTag));

	while (fscanf(InpFile, "%s", text_line)!=EOF)
	{

		printf("\nLine Number : %d\n",lineCount);
		printf("\n%s",text_line);

		tc_strdup(text_line,&inputPart);
		lineCount++;

		if(QRY_find("Driver VC Query", &queryTag));
		if (queryTag)
		{
			printf("\nFound Query QueryDesignRev\n");fflush(stdout);
		}
		else
		{
			printf("\nNotFound Query QueryDesignRev");fflush(stdout);
			goto CLEANUP;
		}
		
		printf("\nQueryig input Part %s\n ", inputPart);fflush(stdout);

		Lcs = (char *) MEM_alloc(1000);
		//tc_strcpy(Lcs,"APLC Released"); 
		//tc_strcpy(Lcs,"T5_LcsAplRlzd"); 

		//Added Hrishikesh 11.07.2023
		if (tc_strcmp(iPlantCode,"1100")==0)
		{
			tc_strcpy(Lcs,"T5_LcsAplRlzd"); 
		}
		
		if (tc_strcmp(iPlantCode,"1001")==0)
		{
			tc_strcpy(Lcs,"T5_LcsAplpRlzd"); 
		}

		if (tc_strcmp(iPlantCode,"3100")==0)
		{
			tc_strcpy(Lcs,"T5_LcsApluRlzd"); 
		}

		if (tc_strcmp(iPlantCode,"1500")==0)
		{
			tc_strcpy(Lcs,"T5_LcsApldRlzd"); 
		}

		if (tc_strcmp(iPlantCode,"E201")==0)
		{
			tc_strcpy(Lcs,"T5_LcsAplaRlzd"); 
		}

		qry_values[0] = inputPart;
		qry_values[1] = Lcs;

		//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));
		//1-Ascending 2- Descending
		ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &outTag));

		printf("\nPart Found Count %d", resultCount);fflush(stdout);

		if(resultCount>0)
		{
			LatestRev=outTag[0];
		}
		else
		{
			printf("\nPart %s Not found APLC Released in TCUA\n", inputPart);fflush(stdout);
			continue;
		}

		ITK_CALL(AOM_ask_value_string(LatestRev,"object_string",&LatRevName));
		printf("\nLatRevName:%s \n",LatRevName);fflush(stdout);


		ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));

		//if(tc_strstr(PartRelStatus,"APLC Released")!=NULL || tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)
		//added Hrishikesh 11.07.2023
		if(((tc_strcmp(iPlantCode,"1100")==0) && (tc_strstr(PartRelStatus,"APLC Released")!=NULL || tc_strstr(PartRelStatus,"STDSIC Released")!=NULL)) || //added Hrishikesh 10.07.2023
		   ((tc_strcmp(iPlantCode,"1001")==0) && (tc_strstr(PartRelStatus,"APLP Released")!=NULL || tc_strstr(PartRelStatus,"STDSIP Released")!=NULL)) || //added Hrishikesh 10.07.2023
		   ((tc_strcmp(iPlantCode,"1500")==0) && (tc_strstr(PartRelStatus,"APLD Released")!=NULL || tc_strstr(PartRelStatus,"STDSID Released")!=NULL)) || //added Hrishikesh 10.07.2023
		   ((tc_strcmp(iPlantCode,"3100")==0) && (tc_strstr(PartRelStatus,"APLU Released")!=NULL || tc_strstr(PartRelStatus,"STDSIU Released")!=NULL)) ||  //added Hrishikesh 10.07.2023
		   ((tc_strcmp(iPlantCode,"E201")==0) && (tc_strstr(PartRelStatus,"APLA Released")!=NULL || tc_strstr(PartRelStatus,"STDSIA Released")!=NULL)))   //Hrishikesh 01.03.2023

		{
			printf("\nPartRelStatus: %s\n",PartRelStatus);
		}
		else
		{
			printf("\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
			fprintf(fsuccess,"\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
			continue;
		}
			
		tc_strdup("ERC",&OrgIDDup);

		if(FetchPlantSpecificData(iPlantCode)>0)
		{
			printf("\nGot Plant Specific Data...\n");fflush(stdout);
		}
		else
		{
			printf("\nError in Fetching Plant Specific Data...\n");fflush(stdout);
			goto CLEANUP;
		}
		
		tc_strdup(iPlantCode,&plantcode);

		if(tc_strcmp(plantcode,"")==0)
		{
			printf("\nPlant code is null hence exit"); fflush(stdout);
			fprintf(fsuccess,"\nPlant code is null hence exit"); fflush(fsuccess);
			goto CLEANUP;
		}

		strcpy(myzeroDup1,"0.0");
		strcpy(myzeroDup2,"0.00");
		strcpy(myzeroDup3,"0.000");
		strcpy(myzeroDup4,"0.0000");

		printf("\nCosting Overhead Group: %s", origin_group);

		ITK_CALL(AOM_ask_value_string(LatestRev,"t5_PartType",&part_type));
		tc_strdup(part_type,&part_typeDup);

		ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&part_noDup));

		ITK_CALL(AOM_ask_value_string(LatestRev,Plant_MakeBuy,&make_buy_ind));

		if(tc_strcmp(make_buy_ind,"F19")==0)
		{
			strcpy(make_buy_ind,"F30");
		}

		if(tc_strcmp(make_buy_ind,"E50")==0)
		{
			tc_strdup("",&store_locDup);
		}

		if(tc_strcmp(make_buy_ind,"NA")==0)
		{
			printf("\nMakebuy indicator is NA hence can not create material");
			goto CLEANUP;
		}


		printf("\nMake Buy Indicator : %s",make_buy_ind);
		printf("\nStore_loc : %s",store_locDup);

		if(tc_strcmp(plantcode,"1100")==0 && (tc_strstr(dml_no_arg, "AM") != NULL))
		{
			if(tc_strcmp(sap_proc_type,"E")==0)
			{
				//strcpy(proc_Key,sap_proc_type);
				proc_Key = 'E';
			}
			else
			{
				//strcpy(proc_Key,"0");
				proc_Key = '0';
			}

			if(tc_strcmp(sap_spproc_type,"99")==0)
			{
				//strcpy(spl_Key,"Y");
				spl_Key = 'Y';
			}
			else
			{
				//strcpy(spl_Key,"0");
				spl_Key = '0';
			}

			printf("\nPlant 1100 proc_Key:[%c] spl_Key:[%c]",proc_Key,spl_Key) ; fflush(stdout);
			//fprintf(fsuccess,"\n Plant 1100...proc_Key:[%c] spl_Key:[%c]",proc_Key,spl_Key) ; fflush(stdout);
		}

			if(tc_strcmp(plantcode,"1100")==0)
	{
		if(tc_strlen(make_buy_ind)>0)
		{

			tc_strdup(make_buy_ind,&make_buy_indDup);
			printf("\nInSide GET CS Proc");
			fprintf(fsuccess,"\nInSide GET CS Proc");
			//proc_Key = GetCSSAP(part_noDup,1);
			//spl_Key = GetCSSAP(part_noDup,2);
			if(proc_Key == 'E' && spl_Key == 'Y')
			{
				printf("\nTaking Value from CS Proc");
				fprintf(fsuccess,"\nTaking Value from CS Proc");
				printf("\nPune Make/Buy Indicator in PLM:%s:", make_buy_indDup);
				fprintf(fsuccess,"\nPune Make/Buy Indicator in PLM:%s:", make_buy_indDup);
				tc_strdup("E",&proc_type);
				printf("\nProcurement Type: %s", proc_type);
				fprintf(fsuccess,"\nProcurement Type: %s", proc_type);
				tc_strdup("99",&spl_proc_key);
				
				printf("\nSpecial Procurement Key: %s", spl_proc_key);
				fprintf(fsuccess,"\nSpecial Procurement Key: %s", spl_proc_key);
			}
			else
			{
				printf("\nTaking Value from PLM");
				fprintf(fsuccess,"\nTaking Value from PLM");
				printf("\nPune Make/Buy Indicator:%s:", make_buy_indDup);
				proc_type = subString(make_buy_indDup, 0, 1);
				printf("\nProcurement Type: %s", proc_type);
				spl_proc_key = subString(make_buy_indDup, 1, 2);
				printf("\nSpecial Procurement Key: %s", spl_proc_key);
			}
		}
		else
		{
			printf("\nPune Make/Buy Indicator is NULL!");
			printf("\nProcurement Type is NULL!");
			printf("\nSpecial Procurement Key is NULL!");
			printf("\nPart %s is found in Release Vault with Life Cycle State as APL Released but CS is NULL",part_noDup);
			//fprintf(fsuccess,"\nMSG RCVD:Part %s is found in Release Vault with Life Cycle State as APL Released but CS is NULL",DispNameDup);
			//goto CLEANUP;
		}
	}
	else
	{
		if(tc_strlen(make_buy_ind)>0)
		{
			tc_strdup(make_buy_ind,&make_buy_indDup);

		
			printf("\nPune Make/Buy Indicator:%s:", make_buy_indDup);
			proc_type = subString(make_buy_indDup, 0, 1);
			printf("\nProcurement Type: %s", proc_type);
			spl_proc_key = subString(make_buy_indDup, 1, 2);
			printf("\nSpecial Procurement Key: %s", spl_proc_key);

		}
		else
		{
			printf("\nPune Make/Buy Indicator is NULL!");
			printf("\nProcurement Type is NULL!");
			printf("\nSpecial Procurement Key is NULL!");
			printf("\nPart %s is found in Release Vault with Life Cycle State as APL Released but CS is NULL",part_noDup);
			//fprintf(fsuccess,"\nMSG RCVD:Part %s is found in Release Vault with Life Cycle State as APL Released but CS is NULL",DispNameDup);
			goto CLEANUP;
		}


	}

		printf("\nPart Type: %s", part_typeDup);
		printf("\npart_noDup: %s\n", part_noDup);

		if(	tc_strcmp(part_typeDup,"D")==0 ||
			tc_strcmp(part_typeDup,"DA")==0 ||
			tc_strcmp(part_typeDup,"DC")==0 ||
			tc_strcmp(part_typeDup,"IFD")==0 ||
			tc_strcmp(part_typeDup,"IM")==0 ||
			tc_strcmp(part_typeDup,"CP")==0)
		{
			printf("\nPart %s Has Type %s ! AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
			fprintf(fsuccess,"\nPart %s Has Type %s ! AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
			continue;
		}
		
		//CR-FY21-0218
		if (tc_strlen(part_noDup)==12)
		{
			if(STRNG_find_last_char(part_noDup,'R')!=NULL || STRNG_find_last_char(part_noDup,'L')!=NULL)
			{
				if (
					tc_strcmp(part_typeDup,"VC")==0 ||
					tc_strcmp(part_typeDup,"CCVC")==0 ||
					tc_strcmp(part_typeDup,"VCCR")==0 ||
					tc_strcmp(part_typeDup,"CKDVC") == 0 ||
					tc_strcmp(part_typeDup,"SKDVC") == 0
				 )
				{
					printf("\nPart %s and PartType %s Found OK\n",part_noDup,part_type);
				}
				else
				{
					printf("\nPart %s and PartType %s Its PartType must be either of VC/CCVC/VCCR/CKDVC/SKDVC... NOT OK\n",part_noDup,part_type);
					fprintf(fsuccess,"\nPart %s and PartType %s Its PartType must be either of VC/CCVC/VCCR/CKDVC/SKDVC... NOT OK\n",part_noDup,part_type);
					goto CLEANUP;
				}
			}
			else
			{
				printf("\nPart %s and PartType %s Normal 12-Digit Part\n",part_noDup,part_type);
			}
		}


		printf("\nPart Number : [%s] Part Type : [%s]",part_noDup,part_typeDup);

		strcpy(part_noDupDes,part_noDup);
		strcpy(part_noDupDesx,part_noDup);

		if(tc_strlen(part_type)>0)
		{
			if (tc_strcmp(part_typeDup, "C") == 0 ||
				tc_strcmp(part_typeDup, "A") == 0 ||
				tc_strcmp(part_typeDup, "G") == 0 )
			{
				tc_strcpy(mat_type,"HALB");
			}
			else if (tc_strcmp(part_typeDup, "M") == 0)
			{
				tc_strcpy(mat_type,"HALB");
			}
			else if (tc_strcmp(part_typeDup, "V") == 0)
			{
					tc_strcpy(mat_type,"HALB");
			}
			else if (tc_strcmp(part_typeDup, "T") == 0)
			{
					tc_strcpy(mat_type,"HALB");
			}
			else if((tc_strcmp(part_typeDup, "VC") == 0)	||
					(tc_strcmp(part_typeDup, "CKDVC") == 0) ||
					(tc_strcmp(part_typeDup, "SKDVC") == 0) ||
					(tc_strcmp(part_typeDup, "CCVC") == 0)	||
					(tc_strcmp(part_typeDup, "VCCR") == 0)
					)
			{
				tc_strcpy(mat_type,"FERT");
			}
			else if (tc_strcmp(part_typeDup,"DTPL")==0)
			{
				tc_strcpy(mat_type, "HALB");
			}
			else if (tc_strcmp(part_typeDup,"SA")==0)  // added on 17.03.2016 for 16 digit stage assembly of 60R TPL disintegration 
			{
				tc_strcpy(mat_type, "HALB");
			}
			else if (len == 12 || len == 14)
			{
					tc_strcpy(mat_type,"HALB");
			}
			else if (len == 10 || len == 11)
			{
					tc_strcpy(mat_type,"ROH");
			}
			else if (len == 14 || len == 16)	/*cabin kit logic by Ashish on 19.11.2013*/
			{
				if((*(part_noDup+10)=='C') && (*(part_noDup+11)=='K'))
				{
					tc_strcpy(mat_type,"HALB");
				}
			}
			

			printf("\nMaterial Type: %s", mat_type); /*part_type = acr_ind*/
		}
		else
		{
			printf("\nPart Type for the part %s is NULL",part_noDup);
			fprintf(fsuccess,"\nMSG RCVD:Part Type for the part %s is NULL",part_noDup);
			continue;
		}



		if (tc_strcmp(mat_type,"FERT") == 0)	//Anuja,Swati Tendulkar Request for QM View for VC
		{
			allocate_insp_type_vc();
		}

		else
		{

			printf("\nPart is not VC");

			if((tc_strcmp(proc_type, "F") == 0) && (tc_strcmp(spl_proc_key, "40") != 0))
			{
				 allocate_insp_type();
			}
		}


	}//File Loop

	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);
}
