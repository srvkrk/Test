//GetSVRFromCCVC -u=apn08686 -p=XYT1ESA -f=iCCVCNum.txt

#include <stdio.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <fclasses/tc_string.h>
#include <pie/pie.h>
#include <tccore/tctype.h>

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();
		
	}
	return return_code;
}

extern int ITK_user_main(int argc, char ** argv )
{

	int resultCount =0;
	int one_entries = 1;
	int n_tags_found = 1;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};

	tag_t VarientQryTag = NULLTAG;
	tag_t *SVR_Tags		= NULLTAG;
	tag_t SVR_Rev_Tag	= NULLTAG;

	char* sUserName	= NULL;
	char* sPassword = NULL;
	char* LatRevName = NULL;
	char* PartRelStatus = NULL;
	char *inputPart = NULL;
	char *desc = NULL;
	
	char *inpFileName = NULL;
	FILE *InpFilePtr = NULL;
	char text_line[20];

	char *ccvc_num = (char *) MEM_alloc (sizeof (char) * 20);
	char *qry_entries[1] = {"Name"};
	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	//sUserName = ITK_ask_cli_argument("-u=");
	//sPassword = ITK_ask_cli_argument("-p=");
	//inputPart		= ITK_ask_cli_argument("-i=");
	inpFileName		= ITK_ask_cli_argument("-f=");


	if(QRY_find("VariantRule", &VarientQryTag));
	
	if (VarientQryTag)
	{
		printf("\nFound Query VariantRule\n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query VariantRule");fflush(stdout);
		goto CLEANUP;
	}

	InpFilePtr = fopen(inpFileName,"r");

	while (fscanf(InpFilePtr, "%s", text_line)!=EOF)
	{
		tc_strdup(text_line,&inputPart);

		printf("\nQueryig SVR for CCVC : %s\n ", inputPart);fflush(stdout);

		tc_strcpy(ccvc_num,inputPart);
		tc_strcat(ccvc_num,"*");
		qry_values[0] = ccvc_num;

		//1-Ascending 2- Descending
		ITK_CALL(QRY_execute_with_sort(VarientQryTag, one_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &SVR_Tags));

		printf("\nPart Found Count %d", resultCount);fflush(stdout);

		if(resultCount>0)
		{
			SVR_Rev_Tag=SVR_Tags[0];

			ITK_CALL(AOM_UIF_ask_value(SVR_Rev_Tag,"object_string",&LatRevName));
			ITK_CALL(AOM_UIF_ask_value(SVR_Rev_Tag,"release_status_list",&PartRelStatus));
			ITK_CALL(AOM_ask_value_string(SVR_Rev_Tag,"object_desc",&desc));

			printf("\nSVR_Number : %s,%s\n",LatRevName,PartRelStatus);fflush(stdout);
		}
		else
		{
			printf("\nPart %s Not found ERC Released and above in TCUA\n", inputPart);fflush(stdout);
			goto CLEANUP;
		}

		
	}

	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);

}