/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : ercOldMatUpdateUA.c
* Created By                   : Amol P Narke
* Created On                   : 30/09/2020
* Project                      : Tata Motors TCUA-SAP Interface
* Methods Defined              :
* Description                  : Basic View Old Material Number Update
* Specific Notes               :
*
* Modification History :
* S.No		Date					CR No        Modified By		Modification Notes
* Master-Action-administrative.actrion-update.system.attribute
***************************************************************************/
#define TE_MAXLINELEN  128
#define _CLMAIN_DEFNS
#include <ae/dataset.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ctype.h>
#include <fclasses/tc_string.h>
#include <itk/mem.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/libtccore_exports.h>
#include <tccore/libtccore_undef.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <unidefs.h>
#include <string.h>
#include <user_exits/user_exits.h>

#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"

int getChassisType(tag_t PartTag,char *part_type,char *part_ColorId);
void OldMatUpdateCall(char *Part_Num,char *OldMatNumber);

FILE *fsuccess;
char fsuccess_name[200];

char	*part_noDup		= NULL;
char	*OldMatNo		= NULL;
char	*OldMatNoDup	= NULL;
char	*mat_type		= NULL;
char	*meas_unit		= NULL;
char	*AllColRevSet	= NULL;


#define ITK_CALL(X) 							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("%3d error(s) with #X\n", n_ifails);						\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
	;

BapiLogon()
{
	static RFC_OPTIONS RfcOptions;

	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	/*RfcOptions.destination ="PP8";
	RfcOptions.client = "500";
	RfcOptions.user = "PPLMPROD";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINI1!";
	RfcOptions.trace = 0;
	RfcConnoptR3only.hostname="p690";
	RfcConnoptR3only.gateway_host="p690";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;*/

	/*RfcOptions.destination ="PD8";
	RfcOptions.client = "250";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 1;
	RfcConnoptR3only.hostname="6m252";
	RfcConnoptR3only.gateway_host="6m252";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;*/

	RfcOptions.destination ="PQ8";
	RfcOptions.client = "500";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 1;
	RfcConnoptR3only.hostname="172.24.29.12";
	RfcConnoptR3only.gateway_host="172.24.29.12";	//tmleccqa
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;

	/*	
	printf("\nDESTINATION    :%-50s",RfcOptions.destination);
	printf("\nCLIENT         :%-50s",RfcOptions.client);
	printf("\nUSER           :%-50s",RfcOptions.user);
	printf("\nPASSWORD       :%-50s",RfcOptions.password);
	printf("\nLAGUAGE        :%-50s",RfcOptions.language);
	printf("\nTRACE          :%-50d",RfcOptions.trace);
	printf("\nHOST NAME      :%-50s",RfcConnoptR3only.hostname);
	printf("\nGATEWAY HOST   :%-50s",RfcConnoptR3only.gateway_host);
	printf("\nGATEWAY SERVICE:%-50s",RfcConnoptR3only.gateway_service);
	printf("\nCONNOPT        :%-50u",RfcOptions.connopt);*/

	printf("\nConnecting to :%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);
	hRfc = RfcOpen(&RfcOptions);
	if (hRfc == RFC_HANDLE_NULL)
	{
		printf("\nERROR RECEIVED CPIC-ERROR");
		exit(0);
	}
	else
	{
		printf("\nGot the connection!!!");
		RfcEnvironment(&RfcEnv);
	}
	return hRfc;
}

RFC_RC BAPI_MATERIAL_SAVEDATA(RFC_HANDLE hRfc,
						BAPIMATHEAD *eBapiMatHead,
						BAPI_MARA	*eBasicView,
						BAPI_MARAX	*eBasicViewx,
						BAPIRET2	*eBapiret2,
						char *xException)
{


	RFC_PARAMETER Exporting[4];
	RFC_PARAMETER Importing[2];
	RFC_TABLE Tables[1];
	RFC_RC RfcRc;
	char *RfcException = NULL;

    printf("bi");
	Exporting[0].name = "HEADDATA";
	Exporting[0].nlen = 8;
	Exporting[0].type = handleOfBAPIMATHEAD;
	Exporting[0].leng = sizeof(BAPIMATHEAD);
	Exporting[0].addr = eBapiMatHead;

	Exporting[1].name = "CLIENTDATA";
	Exporting[1].nlen = 10;
	Exporting[1].type = handleOfBAPI_MARA;
	Exporting[1].leng = sizeof(BAPI_MARA);
	Exporting[1].addr = eBasicView;

	Exporting[2].name = "CLIENTDATAX";
	Exporting[2].nlen = 11;
	Exporting[2].type = handleOfBAPI_MARAX;
	Exporting[2].leng = sizeof(BAPI_MARAX);
	Exporting[2].addr = eBasicViewx;

	Exporting[3].name = NULL;

	Tables[0].name = NULL;

	/*Tables[0].name     = "MATERIALDESCRIPTION";
	Tables[0].nlen     = 19;
	Tables[0].type     = handleOfBAPI_MAKT;
	Tables[0].ithandle = thBapi_Makt;

	Tables[1].name = NULL;*/

	RfcRc = RfcCall(hRfc,"ZBAPI_MATERIAL_SAVEDATA",Exporting,Tables);

	switch (RfcRc)
	{

	case RFC_OK :
				Importing[0].name = "RETURN";  /*RETURN */
				Importing[0].nlen = 6;
				Importing[0].type = TYPC;
				Importing[0].leng = sizeof(BAPIRET2);
				Importing[0].addr = eBapiret2;

				Importing[1].name = NULL;
				RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
				//printf("\nRfcException:%s",RfcException);
				switch (RfcRc)
				{
					case RFC_SYS_EXCEPTION :
						strcpy(xException,RfcException);
					break;
					case RFC_EXCEPTION :
						strcpy(xException,RfcException);
					break;
				}

			break;
	default :
			printf("\nNOT RFC OK");
	}
  return RfcRc;
}

int getChassisType(tag_t PartTag,char *part_type,char *part_ColorId)
{
	int status;
	int Count = 0;
	tag_t	VehicleRevTag		= NULLTAG;
	tag_t	VehicleMstTag		= NULLTAG;
	tag_t	PartTagDup			= NULLTAG;
	tag_t	*NonColPartTags		= NULLTAG;
	tag_t	*VCChildTags		= NULLTAG;
	
	char *partType = NULL;

	tc_strdup(part_type,&partType);
	PartTagDup = PartTag;

	if (tc_strcmp(part_ColorId,"C")==0)
	{
		ITK_CALL(AOM_ask_value_tags(PartTag,"TC_Is_Represented_By",&Count,&NonColPartTags));
		PartTagDup = NonColPartTags[0];
		ITK_CALL(AOM_ask_value_string(PartTagDup,"t5_PartType",&partType));
	}

	if ((tc_strcmp(partType,"VC")==0 || tc_strcmp(partType,"CCVC")==0))
	{
		ITK_CALL(AOM_ask_value_tags(PartTagDup,"ps_children",&Count,&VCChildTags));
		VehicleRevTag = VCChildTags[0];

		ITK_CALL(AOM_ask_value_tag(VehicleRevTag,"items_tag",&VehicleMstTag));
		ITK_CALL(AOM_UIF_ask_value(VehicleMstTag,"T5_HasChassisTypeNo",&OldMatNo));
		tc_strdup(OldMatNo,&OldMatNoDup);
		printf("\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
		fprintf(fsuccess,"\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
	}

	if (tc_strcmp(partType,"V")==0)
	{
		ITK_CALL(AOM_ask_value_tag(PartTagDup,"items_tag",&VehicleMstTag));
		ITK_CALL(AOM_UIF_ask_value(VehicleMstTag,"T5_HasChassisTypeNo",&OldMatNo));
		tc_strdup(OldMatNo,&OldMatNoDup);
		printf("\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
		fprintf(fsuccess,"\nOLD MATERIAL NUMBER FOR VC : [%s]",OldMatNoDup);
	}

}

extern int ITK_user_main(int argc, char ** argv )
{
    int status;
	int kk=0;
	int is=0;
	int sflag=0;
	int i=0;
	int doccount=0;
	int len=0;
	int Refcount=0;
	int resultCount =0;
	int n_entries = 2; //no. of query input arg
	int n_tags_found = 1;
	int num_to_sort = 1;
	int sort_order[1]  ={2};
	char *keysAttr[1] = {"creation_date"};

	tag_t queryTag = NULLTAG;
	tag_t docOPtr = NULLTAG;
	tag_t *outTag = NULLTAG;
	tag_t resultOutputTag = NULLTAG;
	tag_t LatestRev=NULLTAG;
    tag_t docRelObjs=NULLTAG;
    tag_t *docObjs=NULLTAG;
    tag_t *refdocObjs=NULLTAG;
    tag_t doctag=NULLTAG;
    tag_t docRelObj=NULLTAG;
    tag_t refdocRelObj=NULLTAG;
	tag_t		*DesignTags			= NULLTAG;
	tag_t		PartMasterTag		= NULLTAG;

	char* sUserName	= NULL;
	char* sPassword = NULL;
	char *LatRevName=NULL;
	char *part_type=NULL;
	char *unit=NULL;
	char *part_typeDup=NULL;
	char *unitDup=NULL;
	char *doc_no=NULL;
	char *PrtRev=NULL;
	char* PartRelStatus = NULL;
	char *Lcs = NULL;

	static RFC_RC RfcRc;
	const char *attrs[2];
	const char *values[2];

	char *inputPart=NULL;
	char *dml_no_arg = NULL;
	char *PrtRevDup = NULL;
	char *part_noDup = NULL;
	char *desc = NULL;
	char *descDup = NULL;
	char *partClrIndDup = NULL;
	char *partClrInd = NULL;

	int ColCount = 0, cl = 0;
	tag_t *AllColPartTags = NULLTAG;
	tag_t ColPartTag = NULLTAG;
	char *ColPartRev = NULL;
	int PStrCount = 0, j=0;
	char **ColPartList =NULL;
	char *RelRevNumber =NULL;
	tag_t *ColPTags = NULLTAG;
	tag_t ColPTag = NULLTAG;

	static RFC_HANDLE hRfc;

	//char *qry_entries[1] = {"Name"};
	char *qry_entries[] = {"Item ID","Release Status"};

	char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	//ITK_CALL(ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;
	ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login( ));
	ITK_CALL(ITK_set_journalling( TRUE ));

	sUserName = ITK_ask_cli_argument("-u=");
	sPassword = ITK_ask_cli_argument("-p=");
	inputPart = ITK_ask_cli_argument("-i=");
	//dml_no_arg = ITK_ask_cli_argument("-c=");


	if(tc_strcmp(sUserName,"")==0 || tc_strcmp(sPassword,"")==0 || tc_strcmp(inputPart,"")==0 /*|| tc_strcmp(dml_no_arg,"")==0*/)
	{
		printf("\nPartDesUpateUA -u=userid -p=password -i=inputPart \n");fflush(stdout);
		goto CLEANUP;
	}

	//sprintf(fsuccess_name,"/user/plmsap/PLMSAP/ONE_TIME_LOG/PART_OLD_MAT_UPDATE_ONETIME_%s.log",inputPart);
	sprintf(fsuccess_name,"PART_OLD_MAT_UPDATE_ONETIME_%s.log",inputPart);
	fsuccess = fopen(fsuccess_name,"a");

	//if(QRY_find("QueryDesignRev", &queryTag));
	if(QRY_find("Driver VC Query", &queryTag));
	
	if (queryTag)
	{
		printf("\nFound Query QueryDesignRev\n");fflush(stdout);
	}
	else
	{
		printf("\nNotFound Query QueryDesignRev");fflush(stdout);
		goto CLEANUP;
	}
    
    printf("\nQueryig input Part %s\n ", inputPart);fflush(stdout);

	Lcs = (char *) MEM_alloc(1000);
	//tc_strcpy(Lcs,"T5_LcsAplRlzd");
	//tc_strcpy(Lcs,"T5_LcsErcRlzd");
	tc_strcpy(Lcs,"T5_LcsStdRlzd");

    qry_values[0] = inputPart;
    qry_values[1] = Lcs;

	//if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &outTag));
	//1-Ascending 2- Descending
	ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &outTag));

    printf("\nPart Found Count %d", resultCount);fflush(stdout);

	if(resultCount>0)
	{
		LatestRev=outTag[0];
	}
	else
	{
		printf("\nPart %s Not found ERC Released and above in TCUA\n", inputPart);fflush(stdout);
		goto CLEANUP;
	}

	ITK_CALL(AOM_ask_value_string(LatestRev,"object_string",&LatRevName));
	printf("\nLatRevName:%s \n",LatRevName);fflush(stdout);
	fprintf(fsuccess,"\nLatRevName:%s \n",LatRevName);fflush(stdout);

	ITK_CALL(AOM_ask_value_string(LatestRev,"item_id",&part_noDup));

	ITK_CALL(AOM_ask_value_string(LatestRev,"item_revision_id",&PrtRev));
	
	printf("\nPart [%s] Part Revision [%s]\n",part_noDup,PrtRev);fflush(stdout);
	fprintf(fsuccess,"\nPart [%s] Part Revision [%s]\n",part_noDup,PrtRev);fflush(stdout);

	ITK_CALL(AOM_UIF_ask_value(LatestRev,"release_status_list",&PartRelStatus));

	if(	
		tc_strstr(PartRelStatus,"STDSIC Released")!=NULL ||
		tc_strstr(PartRelStatus,"APLC Released")!=NULL ||
		tc_strstr(PartRelStatus,"ERC Released")!=NULL ||
		tc_strstr(PartRelStatus,"STDSIC Restructured")!=NULL
		)
	{
		printf("\nPartRelStatus: %s\n",PartRelStatus);
		fprintf(fsuccess,"\nPartRelStatus: %s\n",PartRelStatus);
		
	}
	else
	{
		printf("\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
		fprintf(fsuccess,"\nPart %s PartRelStatus: %s Part LCS not APL Released or Above...\n",LatRevName,PartRelStatus);
		goto CLEANUP;
	}
		
	
	ITK_CALL(AOM_ask_value_string(LatestRev,"t5_PartType",&part_type));
	tc_strdup(part_type,&part_typeDup);

	printf("\nPart Type: %s\n", part_typeDup);
	printf("\npart_noDup: %s\n", part_noDup);

	if(	tc_strcmp(part_typeDup,"D")==0 ||
		tc_strcmp(part_typeDup,"DA")==0 ||
		tc_strcmp(part_typeDup,"DC")==0 ||
		tc_strcmp(part_typeDup,"IFD")==0 ||
		tc_strcmp(part_typeDup,"IM")==0 ||
		tc_strcmp(part_typeDup,"CP")==0)
	{
		printf("\nPart %s Has Type %s ! AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
		fprintf(fsuccess,"\nPart %s Has Type %s ! AND HENCE CAN NOT CREATE MATERIAL IN SAP",part_noDup,part_typeDup);
		goto CLEANUP;
	}


	ITK_CALL(AOM_ask_value_string(LatestRev,"object_desc",&desc));

	if(tc_strlen(desc)>0)
	{
		tc_strdup(desc,&descDup);
		printf("\nDescription: %s", descDup);
	}
	else printf("\nDescription is NULL!");

	ITK_CALL(AOM_ask_value_string(LatestRev,"t5_ColourInd",&partClrInd));
	tc_strdup(partClrInd,&partClrIndDup);

	if (tc_strcmp(partClrIndDup,"Y")==0)
	{
		AllColRevSet     =  (char *) MEM_alloc(100000 * sizeof(char));

		printf("\nNon-Colour Part : %s", part_noDup);

		ITK_CALL(AOM_ask_value_tags(LatestRev,"representation_for",&ColCount,&AllColPartTags));
		for (cl=0 ; cl<ColCount ; cl++)
		{
			ColPartTag = AllColPartTags[cl];
			ITK_CALL(AOM_ask_value_string(ColPartTag,"item_id",&ColPartRev));
			//printf("\nColor Part : %s", ColPartRev);

			if(tc_strcmp(AllColRevSet,"")==0)
			{
				tc_strcpy (AllColRevSet,"" );
				tc_strcat (AllColRevSet,ColPartRev);
			}
			else
			{
				if(tc_strstr(AllColRevSet,ColPartRev)==NULL)
				{
					tc_strcat (AllColRevSet,"," );
					tc_strcat (AllColRevSet,ColPartRev);
					printf("\nPart added to AllColRevSet: %s",ColPartRev);	fflush(stdout);
				}
			}
		}
					
		//tc_strcpy(Lcs,"T5_LcsErcRlzd");
		tc_strcpy(Lcs,"T5_LcsStdRlzd");

		ITK_CALL(EPM__parse_string(AllColRevSet,",",&PStrCount,&ColPartList));
		
		for ( i=0;i<PStrCount ;i++ )
		{
			printf("\nChecking Part : %s",ColPartList[i]);	fflush(stdout);

			qry_values[0] = ColPartList[i];
			qry_values[1] = Lcs;

			//1-Ascending 2- Descending
			ITK_CALL(QRY_execute_with_sort(queryTag, n_entries, qry_entries, qry_values,num_to_sort,keysAttr,sort_order, &resultCount, &ColPTags));
			
			for (j=0;j< resultCount;j++ )
			{
				ColPTag=ColPTags[j];
				
				//ITK_CALL(AOM_ask_value_string(ColPTag,"item_revision_id",&RelRevNumber));

				ITK_CALL(AOM_UIF_ask_value(ColPTag,"release_status_list",&PartRelStatus));
				if(	
					tc_strstr(PartRelStatus,"STDSIC Released")!=NULL ||
					//tc_strstr(PartRelStatus,"APLC Released")!=NULL ||
					//tc_strstr(PartRelStatus,"ERC Released")!=NULL ||
					tc_strstr(PartRelStatus,"STDSIC Restructured")!=NULL
					)
				{
					ITK_CALL(AOM_ask_value_string(ColPTag,"object_string",&RelRevNumber));
					printf("\nLatest Colour Revision : %s\n",RelRevNumber);
					break;
				}
				else
				{
					continue;
				}
			}
		}
	}
	else
	{
		printf("\nNot Colorable Part : %s", part_noDup);
		goto CLEANUP;
	}

	
	CLEANUP:
	ITK_CALL(POM_logout(false));
	printf("\nCLEANUP..."); fflush(stdout);

}