#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "saprfc.h"
#include "sapitab.h"
#include "wmhelpe.h"
#include "bapi.h"

RFC_HANDLE BapiLogon(void);
RFC_RC  zrfc_ac_view_create(RFC_HANDLE hRfc,BKLAS *eBklas,BWTAR_D *eBwtar,MATNR *eMatnr,WERKS_D *eWerks,MESSAGEINF *iMessg,SYST_SUBRC *iRetval,char *xException);
/*
EXEC SQL BEGIN DECLARE SECTION ;
VARCHAR sPartNo[15];
VARCHAR desc[40];
VARCHAR sUq[3];
VARCHAR sAcrInd[3];
VARCHAR schas_type_no[15];
VARCHAR nc_part[14];
EXEC SQL END DECLARE SECTION ;

EXEC SQL INCLUDE SQLCA.H;
*/
char*	myzeroDup1 = NULL;
char*	myzeroDup2 = NULL;
char*	myzeroDup3 = NULL;
char*	myzeroDup4 = NULL;

char mat_type[5]={0};
FILE *fp4 ,*fp6 ,*fp5 ,*fp3,*fgen;
RFC_RC zbapi_material_savedata_mrp(RFC_HANDLE hRfc,BAPIMATHEAD *,BAPI_MARA	*,BAPI_MARAX	*,BAPIRET2	*,ITAB_H       ,ITAB_H       ,ITAB_H       ,char *);
/*void select_material_type()
{
	int len;

	len = strcspn(sPartNo.arr," ");

	printf("\nACR ind : %s",sAcrInd.arr);

	if (strcmp(sAcrInd.arr,"VC")== 0) strcpy(mat_type,"FERT");
	else if (strcmp(sAcrInd.arr,"V")== 0) strcpy(mat_type,"HALB");
	else if (strcmp(sAcrInd.arr,"T") == 0) strcpy(mat_type,"HALB");
	else if (len == 12 || len == 14) strcpy(mat_type,"HALB");
	else if (len == 10 || len == 11) strcpy(mat_type,"ROH");
	else printf("\nCheck the material");

	printf("\nMaterial type	: %s",mat_type);
}*/

RFC_HANDLE BapiLogon(void)
{
	static RFC_OPTIONS RfcOptions;
	static RFC_CONNOPT_R3ONLY RfcConnoptR3only;
	static RFC_ENV RfcEnv;
	static RFC_HANDLE hRfc;

	RfcOptions.destination ="TP8";
	RfcOptions.client = "500";
	RfcOptions.user = "PVPPLMPROD";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINI2!";
	RfcOptions.trace = 0;
	RfcConnoptR3only.hostname="TDCPVAPP03";
	RfcConnoptR3only.gateway_host="TDCPVAPP03";
	RfcConnoptR3only.gateway_service="sapgw02";
	RfcConnoptR3only.sysnr=2;
	RfcOptions.connopt = &RfcConnoptR3only;

	/*RfcOptions.destination ="PQ8";
	RfcOptions.client = "500";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 0;
	RfcConnoptR3only.hostname="tmleccqa";
	RfcConnoptR3only.gateway_host="tmleccqa";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;*/

	/*RfcOptions.destination ="PD8";
	RfcOptions.client = "250";
	RfcOptions.user = "DENIS";
	RfcOptions.language = "EN";
	RfcOptions.password = "CARINIT1";
	RfcOptions.trace = 0;
	RfcConnoptR3only.hostname="6m252";
	RfcConnoptR3only.gateway_host="6m252";
	RfcConnoptR3only.gateway_service="sapgw00";
	RfcOptions.connopt = &RfcConnoptR3only;*/

	/*printf("\nDESTINATION    :%-50s",RfcOptions.destination);
	printf("\nCLIENT         :%-50s",RfcOptions.client);
	printf("\nUSER           :%-50s",RfcOptions.user);
	printf("\nPASSWORD       :%-50s",RfcOptions.password);
	printf("\nLAGUAGE        :%-50s",RfcOptions.language);
	printf("\nTRACE          :%-50d",RfcOptions.trace);
	printf("\nHOST NAME      :%-50s",RfcConnoptR3only.hostname);
	printf("\nGATEWAY HOST   :%-50s",RfcConnoptR3only.gateway_host);
	printf("\nGATEWAY SERVICE:%-50s",RfcConnoptR3only.gateway_service);
	printf("\nCONNOPT        :%-50u",RfcOptions.connopt);*/

	printf("\nConnecting to...:%s %s %s",RfcOptions.destination,RfcOptions.client,RfcConnoptR3only.hostname);

	hRfc = RfcOpen(&RfcOptions);
	if(hRfc == RFC_HANDLE_NULL)
	{
		printf("\nERROR RECEIVED CPIC-ERROR");
		exit(0);
	}
	else
	{
		/*printf("\nCONNECTING TO :%-50s",RfcConnoptR3only.hostname);*/
		RfcEnvironment(&RfcEnv);
	}
	return hRfc;
}

extern int ITK_user_main (int argc, char ** argv )
{
	int count = 1;
	int call_function = 0;
	static RFC_RC RfcRc;
	/*RFC_HANDLE hRfc;*/
	static MATNR eMatnr;
	WERKS_D eWerks;
	BKLAS eBklas;
	BWTAR_D eBwtar;
	MESSAGEINF iMessg;
	SYST_SUBRC iRetval;
	char mat_part[18] = {0};
	char plant[5] = {0};
	char xException[256];
	static RFC_HANDLE hRfc;
	printf("usage : exename partno plant");
	if(argc!=3)
	{
		exit(0);
	}

	strcpy(mat_part,argv[1]);
	strcpy(plant,argv[2]);

	hRfc = BapiLogon();

	SETCHAR(eMatnr.Matnr,"");
	SETCHAR(eWerks.WerksD,"");
	SETCHAR(eMatnr.Matnr,mat_part);
	SETCHAR(eWerks.WerksD,plant);

	for ( count = 1 ; count < 6 ; count++ )
	{
		call_function = 0;
		if ( count == 1 )
		{
			SETCHAR(eBklas.Bklas,"");
			SETCHAR(eBwtar.BwtarD,"");
			SETCHAR(eBklas.Bklas,"0110");
			SETCHAR(eBwtar.BwtarD,"1");
			call_function = 1;
		}
		if ( count == 2 )
		{
			SETCHAR(eBklas.Bklas,"");
			SETCHAR(eBwtar.BwtarD,"");
			SETCHAR(eBklas.Bklas,"0120");
			SETCHAR(eBwtar.BwtarD,"2");
			call_function = 1;
		}
		if ( count == 3 )
		{
			SETCHAR(eBklas.Bklas,"");
			SETCHAR(eBwtar.BwtarD,"");
			SETCHAR(eBklas.Bklas,"0230");
			SETCHAR(eBwtar.BwtarD,"3");
			call_function = 1;
		}
		if ( count == 4 )
		{
			SETCHAR(eBklas.Bklas,"");
			SETCHAR(eBwtar.BwtarD,"");
			SETCHAR(eBklas.Bklas,"0240");
			SETCHAR(eBwtar.BwtarD,"4");
			call_function = 1;
		} 
		if ( count == 5 )
		{

			SETCHAR(eBklas.Bklas,"");
			SETCHAR(eBwtar.BwtarD,"");
			SETCHAR(eBklas.Bklas,"0250");
			SETCHAR(eBwtar.BwtarD,"5");
			call_function = 1;
		}
		/*printf("\ncall_functin=%d",call_function);*/
		if ( call_function == 1)
		{
			RfcRc = zrfc_ac_view_create(hRfc,&eBklas,&eBwtar,&eMatnr,&eWerks,&iMessg,&iRetval,xException);
			switch (RfcRc)
			{
			case RFC_OK :
					/*printf("\nReturned value from batches create = %u",RFC_OK);
					printf("\nMsgty = %s",iMessg.Msgty);
					printf("\nMsgid = %s",iMessg.Msgid);
					printf("\nMsgno = %s",iMessg.Msgno);
					printf("\nMsspc = %s",iMessg.Msspc);*/
					printf("\nMsgtx = %s",iMessg.Msgtx);
					
					break;
			case RFC_EXCEPTION :
					printf("\nRFC Exception = %s",xException);
					break;
			case RFC_SYS_EXCEPTION :
					printf("\nsystem exception raised");
			case RFC_FAILURE :
					printf("\nfailure");
			default :
					printf("\nother failure");
			}
			sleep(2);
		}
	}
	printf("\n\n");
	RfcClose(hRfc);
	return 0;
}

RFC_RC  zrfc_ac_view_create(RFC_HANDLE hRfc,BKLAS *eBklas,BWTAR_D *eBwtar,MATNR *eMatnr,WERKS_D *eWerks,MESSAGEINF *iMessg,SYST_SUBRC *iRetval,char *xException)
{
	RFC_PARAMETER Exporting[5];
	RFC_PARAMETER Importing[3];
	RFC_TABLE Tables[1];
	RFC_RC RfcRc;
	char *RfcException = NULL;

	Exporting[0].name = "BKLAS";
	Exporting[0].nlen = 5;
	Exporting[0].type = handleOfBKLAS;
	Exporting[0].leng = sizeof(BKLAS);
	Exporting[0].addr = eBklas;

	Exporting[1].name = "BWTAR";
	Exporting[1].nlen = 5;
	Exporting[1].type = handleOfBWTAR_D;
	Exporting[1].leng = sizeof(BWTAR_D);
	Exporting[1].addr = eBwtar;

	Exporting[2].name = "MATNR";
	Exporting[2].nlen = 5;
	Exporting[2].type = handleOfMATNR;
	Exporting[2].leng = sizeof(MATNR);
	Exporting[2].addr = eMatnr;

	Exporting[3].name = "WERKS";
	Exporting[3].nlen = 5;
	Exporting[3].type = handleOfWERKS_D;
	Exporting[3].leng = sizeof(WERKS_D);
	Exporting[3].addr = eWerks;

	Exporting[4].name = NULL;

	Tables[0].name = NULL;

	RfcRc = RfcCall(hRfc,"ZRFC_AC_VIEW_CREATE",Exporting,Tables);

	switch (RfcRc)
	{
		case RFC_OK :
    				Importing[0].name = "MESSG";
    				Importing[0].nlen = 5;
    				Importing[0].type = handleOfMESSAGEINF;
    				Importing[0].leng = sizeof(MESSAGEINF);
    				Importing[0].addr = iMessg;

    				Importing[1].name = "RETVAL";
    				Importing[1].nlen = 6;
    				Importing[1].type = TYPINT;
    				Importing[1].leng = sizeof(SYST_SUBRC);
    				Importing[1].addr = iRetval;

    				Importing[2].name = NULL;

    				RfcRc = RfcReceive(hRfc,Importing,Tables,&RfcException);
				/*	printf("\nRFC RECEIVE %s",RfcException);*/
	      			switch (RfcRc)
					{
		        			case RFC_SYS_EXCEPTION :
							strcpy(xException,RfcException);
							break;
						case RFC_EXCEPTION :
							strcpy(xException,RfcException);
							break;
						default : ;
					}
		default : ;
	}
	return RfcRc;
}
