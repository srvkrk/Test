. /user/uaprodtrl/.bash_profile
echo "Start==>Calling DML vcReviseFrmDml from uaprodtrl---------->"
echo "Shell--DMLNo=$1  Veh=$2"
/user/uaprodtrl/Program_Shells/DML_DCR/tm_VCRevisefrmDML -dmlno=$1 -veh=$2 -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -g=dba
echo "End==>DML tm_VCRevisefrmDML from uaprodtrl---------->"
