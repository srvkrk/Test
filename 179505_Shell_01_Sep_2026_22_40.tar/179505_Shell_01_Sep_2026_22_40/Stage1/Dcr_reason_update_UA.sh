/user/uaprodtrl/.bash_profile
echo "Start==>Calling tm_dcr_auto_approve_PV.sh from uaprodtrl---------->"
echo "Shell--input1.= " $1
echo "Shell--input2.= " $2
/user/uaprodtrl/Rudresh/DCR_Code/Dcr_reason_update -u=Loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -dcr_no=$1 -r="$2"
echo "End==>Calling tm_dcr_auto_approve_PV.sh from uaprodtrl---------->"