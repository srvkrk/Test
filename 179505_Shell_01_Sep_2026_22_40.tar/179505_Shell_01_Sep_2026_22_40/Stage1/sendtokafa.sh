echo $"inside sending data shell"
echo  $1
str1="'"
result="$str1$1$str1"
echo $result
cd /user/cvprod/NON_ERC_PUNE/kafka/IPMSIQMSTransfer/Producer/
java -jar SwamprabhaKafkaProducer.jar "$result"
