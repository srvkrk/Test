From_date=$(date -d "-1 day" '+%d-%m-%Y')
To_date=$(date +'%d-%m-%Y')
echo $From_date $To_date
/user/cvprod/Program_Shells/DML_DCR/To_Release_ERC_Review_Part -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$From_date -I2=$To_date
