. /user/omfprod/.bash_profile
echo "User ID as Argument"
echo "In Shell $1 "
echo "In Shell $2 "
echo "Argument Print Complete"
echo "Shell calling started"
echo "Shell Execution Started"
echo "User ID is $1"
echo "Part number is $2"

#chmod 777 "$1 $2"
/proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/sendMailToUser_PV $1 $2
echo "Shell execution Ended"
echo "Shell calling Ended"
