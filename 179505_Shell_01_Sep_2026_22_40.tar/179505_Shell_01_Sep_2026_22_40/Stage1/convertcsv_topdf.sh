#!/bin/sh
. /user/testcmi/.bash_profile
cd /user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter
# Check if CSV file argument is provided
#if [ $# -ne 1 ]; then
#    echo "Usage: $0 <csv_file>"
#    exit 1
#fi
#CSV_FILE="$1"
PDF="/user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter/output.pdf"
PATH="/user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter/TMKO_Document_1.csv"
# Define variables
IMAGE_FILE="/user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter/csv/tata_motors_white.png"
# Java command to execute
JAVA_CMD='/usr/java/jdk1.8.0_201/bin/java -cp ./:/user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter/convertCSV_To_PDF.jar tata.ConvertCSVToPDF.CreatePDFFromCSV "$PATH" "$IMAGE_FILE"'
# Execute the Java command and capture output
result=$(eval $JAVA_CMD)

/usr/bin/mv /user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter/output.pdf /user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter/TMKO.pdf
#echo |mail -s "" -a /user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter/output.pdf ab923373.ttl@tatamotors.com
echo | /usr/bin/mail -s "TMKO PDF" -a /user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter/TMKO.pdf ab923373.ttl@tatamotors.com
#echo |mail -s "ERC Released DML Summary Report" -a /user/testcmi/Dev/devgroups/Anvesh/TestingDVAexe/csv_pdf_converter/output.pdf ab923373.ttl@tatamotors.com
/usr/bin/chmod 777 "TMKO.pdf"

echo "Mail sent"
echo "result===$result==="
