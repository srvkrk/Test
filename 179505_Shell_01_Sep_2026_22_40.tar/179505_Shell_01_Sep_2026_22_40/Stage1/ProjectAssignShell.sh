echo "********************************************************** ProjectAssignShell Started *******************************************************"
echo $1
echo $2
cd /user/uaprod/shells/Admin
echo $(date) >> ProjectAssignShellLog.txt
echo $1 >> ProjectAssignShellLog.txt
echo $2 >> ProjectAssignShellLog.txt
./ProjAssign -u=infodba -pf=/home/uaprod/shells/Admin/infodbapawwdfile.pwf -g=dba -i=$2 > ConsoleLog.txt
echo "********************************************************** ProjectAssignShell Ended *********************************************************"
