#!/bin/bash
. /user/uaprodtrl/.bash_profile
echo **************In TMKO_Mail_Approval Shell_00******************
echo $1
echo $2
echo $3
echo $4
echo $3
echo $6
BASE_PATH=/user/uaprodtrl/Anvesh/TMKO_Shells

echo $BASE_PATH
cd $BASE_PATH
${BASE_PATH}/TMKOoutput -u=ab923373.ttl -p=XYT95ESA -g="" -DH_no=$1

#/user/uaprodtrl/Anvesh/TMKO_Shells/TMKOoutput -DH_no=$1
cd /tmp/

if [ -f "$1_output.txt" ]
then
        echo "*****$1_output.txt***** file found."
else
        echo "*****$1_output.txt*****, File not founds."
fi       
      

 while read line;do

 if [[ $line == *"CurrentId="* ]]; then
 CurrentId=$(echo $line| cut -d'=' -f 2)
 fi
 
 if [[ $line == *"DocHeader_id="* ]]; then
 DocHeader_id=$(echo $line| cut -d'=' -f 2)
 fi
 
 if [[ $line == *"ObjType="* ]]; then
 ObjType=$(echo $line| cut -d'=' -f 2)
 fi
 
 if [[ $line == *"LastModUsr="* ]]; then
 LastModUsr=$(echo $line| cut -d'=' -f 2)
 fi
 
 if [[ $line == *"creationdate="* ]]; then
 creationdate=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLCOC="* ]]; then
 PLCOC=$(echo $line| cut -d'=' -f 2)
 fi

  if [[ $line == *"ERCCOC="* ]]; then
 ERCCOC=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"person="* ]]; then
 person=$(echo $line| cut -d'=' -f 2)
 fi

  if [[ $line == *"DocHeader_Number="* ]]; then
 DocHeader_Number=$(echo $line| cut -d'=' -f 2)
 fi
   if [[ $line == *"AQsign="* ]]; then
 AQsign=$(echo $line| cut -d'=' -f 2)
 fi

  if [[ $line == *"PLEndDate="* ]]; then
 PLEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"ChiefEndDate="* ]]; then
 ChiefEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"CostEndDate="* ]]; then
 CostEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"TSEndDate="* ]]; then
 TSEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"AQEndDate="* ]]; then
 AQEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"FMQ_dateEndDate="* ]]; then
 FMQ_dateEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"enddateEP="* ]]; then
 enddateEP=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernameAQ="* ]]; then
 usernameAQ=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernameFMQ="* ]]; then
 usernameFMQ=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernameChief="* ]]; then
 usernameChief=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernameCost="* ]]; then
 usernameCost=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernameTS="* ]]; then
 usernameTS=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernamePLProceed="* ]]; then
 usernamePLProceed=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"usernameCoc="* ]]; then
 usernameCoc=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"PLCOCDecision="* ]]; then
 PLCOCDecision=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ChiefDecision="* ]]; then
 ChiefDecision=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"CostDecision="* ]]; then
 CostDecision=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"TSDecision="* ]]; then
 TSDecision=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQDecision="* ]]; then
 AQDecision=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"FMQDecision="* ]]; then
 FMQDecision=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"CoCdecision1="* ]]; then
 CoCdecision1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionComment="* ]]; then
 ConditionComment=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionStatus="* ]]; then
 ConditionStatus=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionreworkOwner="* ]]; then
 ConditionreworkOwner=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionSignoffDate="* ]]; then
 ConditionSignoffDate=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedComment="* ]]; then
 ProceedComment=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedSignoffDate="* ]]; then
 ProceedSignoffDate=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedStatus="* ]]; then
 ProceedStatus=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"Proceedreraise="* ]]; then
 Proceedreraise=$(echo $line| cut -d'=' -f 2)
 fi

     

done < $1_output.txt
echo $CurrentId
echo $DocHeader_id
echo $ObjType
echo $LastModUsr
echo $creationdate
echo $PLCOC
echo $ERCCOC
echo $person
echo $AQsign
echo $PLEndDate
echo $ChiefEndDate
echo $CostEndDate
echo $TSEndDate
echo $AQEndDate
echo $FMQ_dateEndDate
echo $enddateEP
echo $usernameAQ
echo $usernameFMQ
echo $usernameChief
echo $usernameCost
echo $usernameTS
echo $usernamePLProceed
echo $usernameCoc
echo $PLCOCDecision
echo $ChiefDecision
echo $CostDecision
echo $TSDecision
echo $AQDecision
echo $FMQDecision
echo $CoCdecision1

       
echo $ConditionComment    
echo $ConditionStatus     
echo $ConditionreworkOwner
echo $ConditionSignoffDate
echo $ProceedComment      
echo $ProceedSignoffDate  
echo $ProceedStatus       
echo $Proceedreraise      






(
echo 'Content-Type: multipart/mixed; boundary="-q1w2e3r4t3"'
echo "To:$4"
echo "CC:$6"
echo "SUBJECT:TMKO sign off report $3:$Request_Number."
echo "SUBJECT:TMKO sign off report $3:$WBS_details."
echo "Content-Type: text/html"
echo "Content-Disposition: inline"
echo "<html>"
    echo "<head></head>"
    echo "<body>"
        echo "<table width='900px' border='1px' style='border-color: #206fab;border-style: none;'>"
            echo "<table width='100%'>"
                echo "<tr style='background:#206fab;height:60px;'>"
                    echo "<td colspan='3'>"
                        echo "<strong>"
                            echo "<p style=' color: #FFF;text-align: center;font-size: 20px;text-transform: uppercase;'>TMKO sign-off report of $1"
                            echo "</p>"
                        echo "</strong>"
                    echo "</td>"
		    echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'>Hello,</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'></td>"
                echo "</tr>"

       
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>ERC COC Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameCoc"
                    echo "</td>"
		      echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CoCdecision1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'> ERC COC Comment</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ERCCOC"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$enddateEP"
                    echo "</td>"
		  
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>chief Engineer sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameChief"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ChiefDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>chief Engineer sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ObjType"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ChiefEndDate"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>AQ input and sign off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameAQ"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>AQ input and sign off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$AQsign"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQEndDate"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>TS input and sign-off Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameTS"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>TS input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$DocHeader_Number"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSEndDate"
                    echo "</td>"
                echo "</tr>"
	        echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Cost manager input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameCost"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Cost manager input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$LastModUsr"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostEndDate"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>FMQ input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameFMQ"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>FMQ input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$CurrentId"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQ_dateEndDate"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/re-raise with rework Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernamePLProceed"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLCOCDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/re-raise with rework Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$PLCOC"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLEndDate"
                    echo "</td>"
		    echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionreworkOwner"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionStatus"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionComment"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionSignoffDate"
                    echo "</td>"
		    echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/Rework(by PL) Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$Proceedreraise"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedStatus"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/Rework(by PL) Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ProceedComment"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedSignoffDate"
                    echo "</td>"
                echo "</tr>"	   

		    echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'>Regards,<br>Team PLM.</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'>"
                        echo "<hr>"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'></td>"
                echo "</tr>"
                echo "<tr style='background:#206fab;height:60px;'>"
                    echo "<td colspan='1'></td>"
                echo "</tr>"
                echo "</td></tr>"
            echo "</table>"
        echo "</table>"
    echo "</body>"
echo "</html>"
) | /usr/sbin/sendmail -f "ab923373.ttl@tatamotors.com" -t "ab923373.ttl@tatamotors.com"

