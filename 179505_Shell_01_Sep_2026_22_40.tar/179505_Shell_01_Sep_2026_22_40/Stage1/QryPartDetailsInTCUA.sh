. /user/uaprodtrl/.bash_profile
#!/bin/ksh
date
cd /proj/PLMLoading/PFIRST_TCE_TCUA_PART/
pwd
if [ -f "$1_TCUA_PARTDETAIL.txt" ]; then
touch "$1_TCUA_PARTDETAIL.txt_old"; chmod 777 "$1_TCUA_PARTDETAIL.txt_old";
cat "$1_TCUA_PARTDETAIL.txt" >> "$1_TCUA_PARTDETAIL.txt_old"
rm -rf "$1_TCUA_PARTDETAIL.txt"
fi
touch "$1_TCUA_PARTDETAIL.txt"
chmod 777 "$1_TCUA_PARTDETAIL.txt"
#/user/rrr05503/Programs/PFIRST_TCE_TCUA_PART/TCUAPart -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -prt="$1" -lcs="$2" -cs="$3"
/user/uaprodtrl/Program_Shells/TCUAPartQry_New -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -g=dba -prt="$1" -lcs="$2" -cs="$3"
if [ ! -s "$1_TCUA_PARTDETAIL.txt" ]; then
#    echo "File not found!"
    touch $1_TCUA_PARTDETAIL.txt
fi
echo "========="
cat $1_TCUA_PARTDETAIL.txt
echo "========="
