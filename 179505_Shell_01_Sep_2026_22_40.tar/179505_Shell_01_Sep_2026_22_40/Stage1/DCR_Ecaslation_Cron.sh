nohup ./tm_dcr_ProjWiseEscaln_mailCoCHoD  -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba > log.txt &
