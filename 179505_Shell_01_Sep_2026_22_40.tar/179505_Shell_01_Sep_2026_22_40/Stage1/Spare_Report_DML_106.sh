. /user/cvprod/.bash_profile
echo "Spare_kit running on DML"
echo "In Shell Spare_kit 106  ...'"$1"' "
nohup /user/cvprod/Program_Shells/DML_DCR/Spare_kit_report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -VC="$1" -Revision="NA" -Sequence="NA" -RRForVC="NA" -ClosureVForVC="NA" -UserID="NA" > /tmp/$1_Spare_Kit_Report.txt &
echo "Spare_kit report end at DML"
