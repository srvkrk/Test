echo "Startted tm_DMLNoStampOnDesRev_PV2.sh Shell"
echo "tm_DMLNoStampOnDesRev_PV2.sh 2C4  ...'"$1"' "
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Program_Shells/DML_DCR/tm_DMLNoStampOnDesRev_PV2.sh '"$1"' "
echo "tm_DMLNoStampOnDesRev_PV2.sh end 2C4 shell end"