echo "Startted Shell"
echo "In DML Abort 2C9  ...'"$1"' "
ssh cvprod@172.22.99.106 "/user/cvprod/Program_Shells/DML_DCR/tm_DMLAbortdup.sh '"$1"' "
echo "DML Abort end 2C9 shell end"
