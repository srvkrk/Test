. /user/cvprod/.bash_profile
/user/cvprod/TC_ROOT12/tcldPatch/tcPatchExecutable TaskReassignRev
echo "Start==>Calling Reassign Task CVPROD utility server---------->"
echo "Shell--Task Name= " $1
echo "Shell--User To and from= " $2
/user/cvprod/Program_Shells/DML_DCR/TaskReassignRev -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -obj=$1 -nu=$2
echo "End==>Calling Reassign Task CVPROD utility server ---------->"
