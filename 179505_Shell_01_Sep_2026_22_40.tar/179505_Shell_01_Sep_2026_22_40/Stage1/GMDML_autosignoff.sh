#!/bin/ksh
. /user/cvprod/.bash_profile
todateStr=$(date +"%m_%d_%y_%H_%M")
echo $todateStr
cd /user/cvprod/NON_ERC_PUNE/TEST_CC/sanket/GMDML_autoSignoff

./GMDML_autosignoff_APL -u=aplloader -pf=/user/cvprod/shells/Admin/aplloaderpasswdFile.pwf -plant="APLUTK" >>/user/cvprod/NON_ERC_PUNE/logs/GMDML_auto_signoff/GMDML_autoSignoff_APLUTK_$todateStr.log &
echo $"GMDML autosignoff for APLUTK successfull"
sleep 600

./GMDML_autosignoff_MBOM -u=aplloader -pf=/user/cvprod/shells/Admin/aplloaderpasswdFile.pwf >>/user/cvprod/NON_ERC_PUNE/logs/GMDML_auto_signoff/GMDML_autoSignoff_MBOM_$todateStr.log &
echo $"GMDML autosignoff for MBOM successfull"
sleep 600

./GMDML_autosignoff_APL -u=aplloader -pf=/user/cvprod/shells/Admin/aplloaderpasswdFile.pwf -plant="APLLKO" >>/user/cvprod/NON_ERC_PUNE/logs/GMDML_auto_signoff/GMDML_autoSignoff_APLLKO_$todateStr.log &
echo $"GMDML autosignoff for APLLKO successfull"
sleep 600

./GMDML_autosignoff_APL -u=aplloader -pf=/user/cvprod/shells/Admin/aplloaderpasswdFile.pwf -plant="APLPUNE" >>/user/cvprod/NON_ERC_PUNE/logs/GMDML_auto_signoff/GMDML_autoSignoff_APLPUNE_$todateStr.log &
echo $"GMDML autosignoff for APLPUNE successfull"
sleep 600

./GMDML_autosignoff_APL -u=aplloader -pf=/user/cvprod/shells/Admin/aplloaderpasswdFile.pwf -plant="APLDWD" >>/user/cvprod/NON_ERC_PUNE/logs/GMDML_auto_signoff/GMDML_autoSignoff_APLDWD_$todateStr.log &
echo $"GMDML autosignoff for APLDWD successfull"
sleep 600

./GMDML_autosignoff_APL -u=aplloader -pf=/user/cvprod/shells/Admin/aplloaderpasswdFile.pwf -plant="APLJSR" >>/user/cvprod/NON_ERC_PUNE/logs/GMDML_auto_signoff/GMDML_autoSignoff_APLJSR_$todateStr.log &
echo $"GMDML autosignoff for APLJSR successfull"

echo $"EXE Calling Successfull"
