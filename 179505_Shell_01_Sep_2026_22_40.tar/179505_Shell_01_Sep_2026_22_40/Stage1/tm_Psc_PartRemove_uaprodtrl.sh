. /user/uaprodtrl/.bash_profile
echo "Start==>Calling DML Psc_PartRemove from uaprodtrl---------->"
echo "Shell--DMLNo.=> " $1
/user/uaprodtrl/Program_Shells/DML_DCR/tm_Psc_PartRemove -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -DMLNum=$1
echo "End==>DML Psc_PartRemove from uaprodtrl---------->"
