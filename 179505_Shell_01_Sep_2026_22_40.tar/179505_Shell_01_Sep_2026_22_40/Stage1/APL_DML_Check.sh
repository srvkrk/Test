echo "Cronjob Shell Start APL DML Check for CVPROD >> DML_APL_Details"
frmdate0=`date +"%d-%m-%Y" --date="10 days ago"`
echo "$frmdate0"
tomdate0=`date +"%d-%m-%Y" --date="0 days ago"`
echo "$tomdate0"
nohup ./DML_APL_Details -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate0 -I2=$tomdate0 > Daily.log &
echo "Shell End APL DML Check Program for CVPROD"