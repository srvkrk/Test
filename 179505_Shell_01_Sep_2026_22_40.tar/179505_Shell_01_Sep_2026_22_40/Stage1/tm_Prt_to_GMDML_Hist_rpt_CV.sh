. /user/cvprod/.bash_profile
/user/cvprod/TC_ROOT12/tcldPatch/tcPatchExecutable tm_Part_to_GM_DML_FileName
echo "Start==>Calling NOPO part based report from CVPROD utility server---------->"
echo "Shell--partlist.= " $1
echo "Shell--username.= " $2
/user/cvprod/Program_Shells/DML_DCR/tm_Part_to_GM_DML_FileName -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$1 -I2=$2
echo "End==>NOPO NOPO part based report from CVPROD utility server---------->"
