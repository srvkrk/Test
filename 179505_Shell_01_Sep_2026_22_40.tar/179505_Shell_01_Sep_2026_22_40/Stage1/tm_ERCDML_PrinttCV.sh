. /user/cvprod/.bash_profile
echo "Start==>Calling DML tm_ERC_DML_Print_Report from cvprod---------->"
echo "Shell--DMLNo.= " $1
/user/cvprod/Program_Shells/DML_DCR/tm_ERC_DML_Print_Report -DML_No=$1 -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
echo "End==>DML tm_ERC_DML_Print_Report from cvprod---------->"
