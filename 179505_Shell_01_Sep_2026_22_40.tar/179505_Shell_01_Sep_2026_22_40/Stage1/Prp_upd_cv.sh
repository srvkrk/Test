. /user/cvprod/.bash_profile
echo "Shell--PAR Number.= " $1
echo "Shell--DML Number.= " $2
input1=\"$1\";
input2=\"$2\";
echo "Shell--input1.= " $input1
echo "Shell--input2.= " $input2
echo "DML Property Update Running on Server"
echo "Towards Connecting"
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/PO_TCUA/ANUP/Shell/Prpupd.sh $input1 $input2"
echo "--Complete Prpupd.sh from cvprod-- "