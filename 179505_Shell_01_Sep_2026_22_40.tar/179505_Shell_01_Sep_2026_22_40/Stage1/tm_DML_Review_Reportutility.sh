. /user/cvprod/.bash_profile
echo "Start==>Calling tm_DML_Review_Reportutility shell from CVPROD utility server---------->"
echo "Shell--dmlno.= " $1
cd /user/cvprod/Program_Shells/DML_DCR/
./tm_DML_Review_Report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -dmlno=$1 > exe.log
echo "End==>tm_DML_Review_Reportutility shell  from CVPROD utility server---------->"
