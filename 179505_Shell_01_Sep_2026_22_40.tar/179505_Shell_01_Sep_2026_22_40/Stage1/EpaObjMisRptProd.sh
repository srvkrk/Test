#!/bin/sh
. /user/cvprod/.bash_profile
cd /user/cvprod/shells/STD/

echo "Going to Call EpaObjMisRptSSH "

./EpaObjMisRptSSH.sh $1 $2 $3 $4&

echo "After Call EpaObjMisRptSSH "