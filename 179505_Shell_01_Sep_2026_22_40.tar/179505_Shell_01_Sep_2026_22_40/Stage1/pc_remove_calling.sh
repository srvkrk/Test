echo "Calling Shell From Production To Utility Server Start...!!"
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Profit_Center_Mapping/pc_remove_execute.sh $1 $2 $3"
echo "Calling Shell From Production To Utility Server End...!!"
