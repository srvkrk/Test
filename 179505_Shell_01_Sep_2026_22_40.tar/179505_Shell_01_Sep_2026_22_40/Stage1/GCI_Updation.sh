. /user/cvprod/.bash_profile
echo "Muktesh"
cd /user/cvprod/Anvesh/GCI_Updation
pwd
./GCI_Updation -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -Gci=$1
