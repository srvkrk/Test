#. /user/uaprod/.bash_profile
echo "Start==>Calling dmlinfo shell from UAPROD utility server---------->"
echo "Shell--dmlno.= " $1
#$TC_ROOT/tcldPatch/tcPatchExecutable dml_report
/user/uaprodtrl/Program_Shells/DML_DCR/dml_report -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -dmlno=$1
echo "End==>dml_report from uaprod utility server---------->"
