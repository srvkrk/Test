#!/bin/ksh
. /user/omfprod/.bash_profile
echo  "---- Calling TCUA ITK for Part WEB SERVICE ----" > /tmp/muktesh.txt
echo $*
echo "Before calling cvprod shell" > /tmp/muktesh1.txt
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Program_Shells/QryPartDetailsInTCUA_CV.sh $1 $2 $3"
echo "After calling cvprod shell" > /tmp/muktesh2.txt
if [ -s "/proj/PLMLoading/PFIRST_TCE_TCUA_PART/$1_TCUACV_PARTDETAIL.txt" ]; then
lineCnt=`cat "/proj/PLMLoading/PFIRST_TCE_TCUA_PART/$1_TCUACV_PARTDETAIL.txt" | wc -l`
if [ $lineCnt -gt 0 ]; then
mv /proj/PLMLoading/PFIRST_TCE_TCUA_PART/$1_TCUACV_PARTDETAIL.txt /plmuv_logs/omfprod/logs/PFIRST_TCE_TCUA_PART/.
ls -ltr /plmuv_logs/omfprod/logs/PFIRST_TCE_TCUA_PART/$1_TCUACV_PARTDETAIL.txt
fi
fi
