echo "Multiple Level expansion Started ..."
while read line
do
./MultilevelExpansionCMS -i=$line -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf  -g=dba
done < input.txt
