#!/bin/sh
. /user/cvprod/.bash_profile

echo "Shell excuting in CV_PROD"
/user/cvprod/Asif/UserIdDiff/UserInfo_CVPROD -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
echo "Moving File from CVPROD to OMFPROD"
scp  /user/cvprod/Asif/UserIdDiff/MoveFile/*.txt  omfprod@172.22.97.8:/user/omfprod/devgroups/Asif/IsInGrpUser/UserInfoUAPROD/MoveFiles/
#rm -rf /user/cvprod/Asif/UserIdDiff/MoveFile/*.txt
You have new mail in /var/mail/cvprod