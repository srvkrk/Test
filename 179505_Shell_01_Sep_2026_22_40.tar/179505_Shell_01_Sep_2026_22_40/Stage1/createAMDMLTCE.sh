. /user/tcuaadev/.bash_profile
echo "Project :$1"
echo "Plant : $2"
echo "Design group : $3"
/user/tcuaadev/TC_ROOT/bin/tml_nonerc_tool/createAMDML -UN=aplplanner -UP=XYT1ESA -UG=APLCAR -AP=$1 -AU=$2 -AD=$3 -AE=$4
