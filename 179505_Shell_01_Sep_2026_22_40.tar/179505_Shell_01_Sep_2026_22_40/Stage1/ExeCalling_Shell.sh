
. /user/omfprod/.bash_profile


echo "Exe Calling Shell Started"
echo "In Shell $1 $2 $3"

echo -e "\nRedirection(SSH:CVPROD) Shell Execution Started...."
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/suryansh/Bomline/Executing_Shell.sh $1 $2 $3"


echo "Exe Calling Shell Ended"
