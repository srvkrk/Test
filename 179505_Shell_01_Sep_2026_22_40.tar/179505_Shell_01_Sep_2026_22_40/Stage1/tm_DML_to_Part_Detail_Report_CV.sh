. /user/cvprod/.bash_profile
/user/cvprod/TC_ROOT12/tcldPatch/tcPatchExecutable tm_DML_to_Part_Detail_Report
echo "Start==>Calling tm_DML_to_Part_Detail_Report from CVPROD utility server---------->"
echo "Shell--From Date.= " $1
echo "Shell--To Date.= " $2
echo "Shell--UserName.= " $3
/user/cvprod/Program_Shells/DML_DCR/tm_DML_to_Part_Detail_Report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$1 -I2=$2 -I3=$3
echo "End==>tm_DML_to_Part_Detail_Report from CVPROD utility server---------->"

