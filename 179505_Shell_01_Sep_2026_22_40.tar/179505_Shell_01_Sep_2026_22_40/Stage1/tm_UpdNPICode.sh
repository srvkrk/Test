./user/cvprod/.bash_profile
echo "Shell--Veh_No.= " $1
echo "Shell--npicode.= " $2
input1=\"$1\";
input2=\"$2\";
echo "Shell--input1.= " $input1
echo "Shell--input2.= " $input2
echo "Shubham_Ghuge"
echo "Towards Connecting NPI code"
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Program_Shells/DML_DCR/tm_UpdNPICodeToClsnNewProc.sh $input1 $input2"
echo "--Complete tm_UpdNPICodeToClsnNewProc.sh from cvprod-- "
