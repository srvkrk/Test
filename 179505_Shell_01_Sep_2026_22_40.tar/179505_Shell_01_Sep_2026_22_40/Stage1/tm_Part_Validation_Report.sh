#. /user/cvprod/.bash_profile
#!/bin/sh
echo "Start of tm_Part_Validation_Report  from cvprod --> $1 "
ssh cvprod@172.22.99.106 -n "/user/cvprod/Program_Shells/DML_DCR/tm_Part_Validation_Report_cvprod.sh $1"
echo "---Expand tm_Part_Validation_Report Shell Completed on cvprod.---"