
#!/bin/sh

. /user/cvprod/.bash_profile

echo  $1
echo  $2
echo  $3

cd /user/cvprod/NON_ERC_SHELL/deleteDesignRevision/

./tm_ServiceToDeleteDesignRevision -u=aplloader -pf=/user/cvprod/shells/Admin/aplloaderpasswdFile.pwf -g=dba -id=$1 -rev=$2 -s=$3



echo $"EXE Calling Successfull"