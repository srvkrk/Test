. /user/uaprod/.bash_profile
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Program_Shells/DML_DCR/tm_NOPO_basedRpt_2c7.sh $1"
echo "--Complete tm_NOPO_basedRpt_2c4.sh  from uaprod-- "
