. /user/infodba/.bash_profile
cd $TC_ROOT/bin/tml_tools
todateStr=$(date +"%m_%d_%y_%H_%M")
echo $todateStr
./tm_createCedCoatedParts -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -d=$1 >>/tmp/tm_createCedCoatedParts_$1_$todateStr.log &

