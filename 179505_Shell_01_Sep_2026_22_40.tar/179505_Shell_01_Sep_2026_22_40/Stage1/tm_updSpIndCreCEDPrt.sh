. /user/infodba/.bash_profile
cd $TC_ROOT/bin/tml_tools
todateStr=$(date +"%m_%d_%y_%H_%M")
echo $todateStr
./tm_updSpIndCreCEDPrt -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -d=$1 >>/tmp/tm_updSpIndCreCEDPrt_$1_$todateStr.log &

#/user/infodba/mig/san12/ced/client/ut/tm_updSpIndCreCEDPrt -u=loader -p=123 -g=dba -d=$1
