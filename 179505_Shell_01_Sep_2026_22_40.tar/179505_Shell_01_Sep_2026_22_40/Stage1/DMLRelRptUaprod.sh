. /user/uaprod/.bash_profile
#!/bin/ksh
echo $JAVA_HOME > /tmp/wfoutsh.log
cd /tmp
java -classpath /user/uaprod/TC_ROOT12/bin/tml_tools/xalan.jar org.apache.xalan.xslt.Process -IN $1 -OUT $2 -XSL /home/mtt07979/DMLReport/tm_DML_Release_Report_Ori.xsl > /tmp/wfoutsh.log
