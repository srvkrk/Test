#!/bin/ksh
# BL_UA_UV_Transfer.sh 5445542400_01 'A;1'

Bsl=$1
Rev=$2
xfr_date=`date +"%Y/%m/%d-%H:%M:%S"`

echo "Calling exe... Baseline_Transfer $1 $2"
Baseline_Transfer -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=$1 -r=$2

while read Veh
do
#Veh=`cat /tmp/"$1"_VCCRList.csv`
echo "Vehicle is -------- $Veh"

Project=`cat /tmp/"$Veh"_ProjList.csv`
echo "Project is -------- $Project"


if [ ! -s /tmp/"$Veh"_VC.csv ];  then
echo "File size is 0"
else

fname=`printf "\n%s" /tmp/"$Veh"_*.csv`
echo "required .csv found -------- "
echo "fname is -------- $fname"

#scp -i ~/.ssh/id_rsa "$fname" plmpapp2c3:/tmp/'$fname' < /dev/null
#scp -i ~/.ssh/id_rsa "$fname" plmpapp2c3:'$fname' < /dev/null
scp -i ~/.ssh/id_rsa /tmp/"$Veh"_*.csv omfprod@plmpapp2c3:/tmp  < /dev/null
scp -i ~/.ssh/id_rsa /tmp/"$Bsl"_VCCRList.csv omfprod@plmpapp2c3:/tmp  < /dev/null

while read i
do
FileName=`echo $i|cut -d',' -f3`
echo "Copyinf FileName  -------- $FileName"
#scp -i ~/.ssh/id_rsa "$FileName" omfprod@plmpapp2c3:/tmp  < /dev/null
scp -i ~/.ssh/id_rsa "`echo "\"$FileName\""`" omfprod@plmpapp2c3:/tmp  < /dev/null

done < /tmp/"$Veh"_Files.csv

#uncomment below line before transfer
echo "Calling 2c3 shell"
ssh omfprod@plmpapp2c3 -n "sh /user/omfprod/Adi/BL_VC_TRANSFER/UA_VC_BL_Transfer.sh $Project $Bsl"


echo "end of shells-------- "
 fi

done < /tmp/"$1"_VCCRList.csv
