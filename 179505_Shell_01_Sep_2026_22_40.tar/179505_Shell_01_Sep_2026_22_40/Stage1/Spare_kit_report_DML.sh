#. /user/cvprod/.bash_profile
echo "In Shell Spare kit DML report 2C9  ...'"$1"' "
ssh cvprod@172.22.99.106 "/user/cvprod/Program_Shells/DML_DCR/Spare_Report_DML_106.sh '"$1"' "
echo "Spare kit report DML end 2C9 shell end"