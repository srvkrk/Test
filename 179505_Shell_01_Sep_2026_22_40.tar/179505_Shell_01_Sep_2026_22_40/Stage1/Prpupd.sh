. /user/cvprod/.bash_profile
echo " *****  Shell Started ...... "
echo $1
echo $2
echo "106_shell_DMLprp"
echo "106_shell_DMLprp_New_API_Modification"
cd /user/cvprod/Program_Shells/DML_DCR/DML_Property_Update
rm -f input.txt
touch input.txt
echo $2 >> input.txt
echo $(date) >> shellLog.txt
echo $1 >> shellLog.txt
echo $2 >> shellLog.txt
echo "topatch_DMLprp"
#/user/cvprod/TC_ROOT14/tcldPatch/tcPatchExecutable PrpUpdate
#/user/cvprod/TC_ROOT14/tcldPatch/tcPatchExecutable DmlPropertyUpdate.exe
echo " *****   patching of both done  EXE ...... "
subString=$1
subStr=${subString:0:3}
echo $subStr
if [[ "$subStr" == "PAR" ]];
then
    /user/cvprod/Program_Shells/DML_DCR/DML_Property_Update/DmlPropertyUpdate.exe -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -parno=$1 -itemid=$2 > ConsoleLog.txt	
else
	/user/cvprod/Program_Shells/DML_DCR/DML_Property_Update/tm_multiPartRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -LoggedUser=$1 -parno=$2 > tm_multiPartRpt.txt
fi	
echo " *****  after Run EXE ...... "
echo " *****  Shell Execution completed ...... "