. /user/uaprod/.bash_profile
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Program_Shells/DML_DCR/$1 $2 $3 $4 $5"
echo "--Complete GenericDml_2c4.sh  from uaprod-- "