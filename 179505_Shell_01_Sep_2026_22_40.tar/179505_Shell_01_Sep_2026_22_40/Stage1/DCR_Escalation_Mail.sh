#!/bin/bash
. /user/uaprodtrl/.bash_profile

echo "-----DCR_Escalation_Uaprodtrl.sh start-----"

if [ "$#" -ne 5 ]; then
    echo "Usage: $0 <User_name> <attachment_file> <recipient_email> <recipient_email_cc>"
    exit 1
fi

User_name="$1"
echo "user name is $User_name"
attachment_file="$2"
echo "Adding attachment: $attachment_file"
recipient="$3"
echo "Sending mail to $recipient"
recipient_email_cc="$4"
echo "Adding CC users: $recipient_email_cc"
Mailbody="$5"
echo "Mail Body taken from: $attachment_file"
subject="Escalation mail for pending DCRs"

chmod 777 "$attachment_file" "$recipient_email_cc"
ls -ltr "$attachment_file" "$recipient_email_cc"
if [ ! -f "$attachment_file" ]; then
    echo "Error: Attachment file '$attachment_file' not found."
    exit 1
fi

if [ ! -f "$recipient_email_cc" ]; then
    echo "Error: CC list file '$recipient_email_cc' not found."
    exit 1
fi

IFS=',' read -r -a data_array < "$Mailbody"


mail_content=$(cat <<HTML

<html>
    <head></head>
    <body>
        <table width='1200px' border='1px' style='border-color: #206fab;border-style: none;'>
            <table width='100%' ;>

                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;' colspan='3'></td>
                </tr>
                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;' colspan='3'>Dear $User_name,</td></tr>
                 <tr><td style='padding:3px;' colspan='3'>Kindly refer attached file containing details of DCRs that have exceeded their target date and are pending with you for clearance. Kindly take necessary action for prompt closure</td>
                </tr>
                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:5px;' colspan='3'></td>
                </tr>

                <tr style='background:#FFF;height:20px;'>

                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='15%''><strong style='color#206fab;'>Sr. No</strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='25%''><strong style='color#206fab;'>Project Desc.</strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='30%''><strong style='color#206fab;'>No of Pending DCR</strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='30%''><strong style='color#206fab;'>Average Days Pending</strong></td>
                </tr>


                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
                    ${data_array[0]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='25%''>
                    ${data_array[1]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[2]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[3]}
                    </td>
                </tr>

                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
                    ${data_array[4]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='25%''>
                    ${data_array[5]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[6]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[7]}
                    </td>
                </tr>

                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
                    ${data_array[8]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='25%''>
                    ${data_array[9]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[10]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[11]}
                    </td>
                </tr>

                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
                    ${data_array[12]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='25%''>
                    ${data_array[13]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[14]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[15]}
                    </td>
                </tr>

                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
                    ${data_array[16]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='25%''>
                    ${data_array[17]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[18]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[19]}
                    </td>
                </tr>

                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
                    ${data_array[20]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='25%''>
                    ${data_array[21]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[22]}
                    </td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='30%''>
                    ${data_array[23]}
                    </td>
                </tr>

                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px; text-align: left; width='100%''>Regards,</td>
                </tr>

                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px; text-align: left; width='100%''>PLM Team</td>
                </tr>
            </table>
        </table>
    </body>
</html>
HTML
)

{
echo "To: $recipient"
echo "Cc: $(cat "$recipient_email_cc")"
echo "Subject: $subject"
echo "MIME-Version: 1.0"
echo "Content-Type: multipart/mixed; boundary=\"boundary\""
echo ""
echo "--boundary"
echo "Content-Type: text/html; charset=\"us-ascii\""
echo ""
echo "$mail_content"
echo "--boundary"
echo "Content-Disposition: attachment; filename=\"$(basename "$attachment_file")\""
echo "Content-Type: application/octet-stream"
echo ""
cat "$attachment_file"
echo "--boundary--"
} | /usr/sbin/sendmail -t
echo "-----Mail Sent Sucessfully-----Sent Through EXE"
