. /user/cvprod/.bash_profile
frmdt=$(date +"%d-%b-%Y" --date="1 day ago")
echo "$frmdt"
/user/cvprod/Program_Shells/DML_DCR/CVBUDCR/DcrPdf/DCR_PDF -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -cd=$frmdt >/tmp/DCR_pdf.log
