#!/bin/sh
. /user/cvprod/.bash_profile

TIMEFORMAT=$'%R,%U,%S'
timestamp=`date +"%d-%m-%y_%T"`
echo  "Shell executed on date : $timestamp"
echo "Script executed from Path: ${PWD}"
echo "Current Path is : ${PWD}"

#p=5174D1B2581002

echo "Direct.part..$1"
echo "Direct.userID..$2"
p=$1
userId=$2
echo   "Part Number is : $p"
echo "Users Id is : $userId"


echo "User Id is : $userId"


cd /proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPROD
rm -rf $p
rm -rf InpCV.txt

mkdir /proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPROD/${p}
chmod 777 $p

echo "$p" >> InpCV.txt
echo "After redirect part number in text file InpCV.txt"
cat InpCV.txt

cd /proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CVPROD
chmod 777 InpCV.txt

scp -r ${p} omfprod@172.22.97.8:/user/omfprod/shells/TASL_Downloading/TMETC_LATEST/

scp -r InpCV.txt omfprod@172.22.97.8:/user/omfprod/shells/TASL_Downloading/TMETC_LATEST/
ssh omfprod@plmpapp2c3 -n "cd /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/; chmod 777 InpCV.txt"

#ssh omfprod@172.22.97.8 -n "chmod -R omfprod:plm /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/InpCV.txt"


#if [ $p -ge 0 ]
if [ -z != $p ]
then

#scp -r ${p} omfprod@172.22.97.8:/user/omfprod/shells/TASL_Downloading/TMETC_LATEST/


#ssh omfprod@plmpapp2c3 -n "cd /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/; /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/RACoptionMainDownUpd_CVPROD.sh ${userId} > $p.log&"
ssh omfprod@plmpapp2c3 -n "cd /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/; /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/RUN_CV_CATIA_ERC_SKIP_LOADED_LATESTREV_DOWN_UP_RAC.sh ${userId} $p > $p.log&"

else

 echo "The Part Number $p is incorrect "
fi

