. /user/cvprod/.bash_profile
echo "Start==>Calling tm_DMLNoStampOnDesRev from CVPROD utility server---------->"
echo "DML no= " $1
nohup /user/cvprod/Program_Shells/DML_DCR/tm_DMLNoStampOnDesRev -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -dmlno=$1 > /tmp/$1_stamp.txt &
echo "End==>tm_DMLNoStampOnDesRev from CVPROD utility server---------->"