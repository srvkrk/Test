#!/bin/bash
. /user/uaprodtrl/.bash_profile

echo "-----DCR_Escalation_Uaprodtrl.sh start-----"
if [ "$#" -ne 4 ]; then
    echo "Usage: $0 <attachment_file> <recipient_email> <recipient_email_cc> <DCR_Detailed_Attachment>"
    exit 1
fi

attachment_file="$1"
echo "Adding attachment: $attachment_file"
recipient="$2"
echo "Sending mail to $recipient"
recipient_email_cc="$3"
echo "Adding CC users: $recipient_email_cc"
DCR_Detailed_Attachment="$4"
echo "Adding CC users: $DCR_Detailed_Attachment"

subject="ALERT - DCRs pending - overall time exceeded 25 days."
chmod 777 "$attachment_file" "$recipient_email_cc" "$recipient"
if [ ! -f "$attachment_file" ]; then
    echo "Error: Attachment file '$attachment_file' not found."
    exit 1
fi

if [ ! -f "$recipient_email_cc" ]; then
    echo "Error: CC list file '$recipient_email_cc' not found."
    exit 1
fi

if [ ! -f "$recipient" ]; then
    echo "Error: TO list file '$recipient' not found."
    exit 1
fi

IFS=',' read -r -a data_array < "$attachment_file"

cc_list=$(<"$recipient_email_cc")
to_list=$(<"$recipient")
echo " Mail Recepent List: $to_list"
echo " Mail CC List: $cc_list"
 
mail_content=$(cat <<HTML

<html>
    <head></head>
    <body>
    <table border="1" cellspacing="0" cellpadding="4" style="border-collapse: collapse; width: 100%; font-size: 12px; text-align: center;">
  <thead style="background-color: rgb(221, 222, 222);">
    <tr>
      <th rowspan="2">Aggregate</th>
      <th rowspan="2">BIW</th>
      <th rowspan="2">Chassis</th>
      <th rowspan="2">E&amp;E</th>
      <th rowspan="2">Engines</th>
      <th rowspan="2">TA</th>
      <th rowspan="2">Trim</th>
      <th rowspan="2">Grand Total</th>
      <th colspan="3">Average Pending Age</th>
    </tr>
    <tr>
      <th>&lt; 7 Days</th>
      <th>7 To 14 Days</th>
      <th>&gt; 25 Days</th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td>No of DCR Target Exceeded</td>
      <td>${data_array[0]}</td>
      <td>${data_array[1]}</td>
      <td>${data_array[2]}</td>
      <td>${data_array[3]}</td>
      <td>${data_array[4]}</td>
      <td>${data_array[5]}</td>
      <td>${data_array[6]}</td>
      <td>${data_array[7]}</td>
      <td>${data_array[8]}</td>
      <td>${data_array[9]}</td>
    </tr>

    <tr><th colspan="11" style="text-align:center; background-color:#e0e0e0;">Summary of pending DCR at Agency for key nodes</th></tr>

    <tr><td>DMU</td><td>${data_array[10]}</td><td>${data_array[11]}</td><td>${data_array[12]}</td><td>${data_array[13]}</td><td>${data_array[14]}</td><td>${data_array[15]}</td><td>${data_array[16]}</td><td>${data_array[17]}</td><td>${data_array[18]}</td><td>${data_array[19]}</td></tr>
    <tr><td>COC BIW</td><td>${data_array[20]}</td><td>${data_array[21]}</td><td>${data_array[22]}</td><td>${data_array[23]}</td><td>${data_array[24]}</td><td>${data_array[25]}</td><td>${data_array[26]}</td><td>${data_array[27]}</td><td>${data_array[28]}</td><td>${data_array[29]}</td></tr>
    <tr><td>COC CHASSIS</td><td>${data_array[30]}</td><td>${data_array[31]}</td><td>${data_array[32]}</td><td>${data_array[33]}</td><td>${data_array[34]}</td><td>${data_array[35]}</td><td>${data_array[36]}</td><td>${data_array[37]}</td><td>${data_array[38]}</td><td>${data_array[39]}</td></tr>
    <tr><td>COC EE</td><td>${data_array[40]}</td><td>${data_array[41]}</td><td>${data_array[42]}</td><td>${data_array[43]}</td><td>${data_array[44]}</td><td>${data_array[45]}</td><td>${data_array[46]}</td><td>${data_array[47]}</td><td>${data_array[48]}</td><td>${data_array[49]}</td></tr>
    <tr><td>COC ENGINE/AE</td><td>${data_array[50]}</td><td>${data_array[51]}</td><td>${data_array[52]}</td><td>${data_array[53]}</td><td>${data_array[54]}</td><td>${data_array[55]}</td><td>${data_array[56]}</td><td>${data_array[57]}</td><td>${data_array[58]}</td><td>${data_array[59]}</td></tr>
    <tr><td>COC TA</td><td>${data_array[60]}</td><td>${data_array[61]}</td><td>${data_array[62]}</td><td>${data_array[63]}</td><td>${data_array[64]}</td><td>${data_array[65]}</td><td>${data_array[66]}</td><td>${data_array[67]}</td><td>${data_array[68]}</td><td>${data_array[69]}</td></tr>
    <tr><td>COC TRIM</td><td>${data_array[70]}</td><td>${data_array[71]}</td><td>${data_array[72]}</td><td>${data_array[73]}</td><td>${data_array[74]}</td><td>${data_array[75]}</td><td>${data_array[76]}</td><td>${data_array[77]}</td><td>${data_array[78]}</td><td>${data_array[79]}</td></tr>

    <tr><td>Matrix QA/FMQ</td><td>${data_array[80]}</td><td>${data_array[81]}</td><td>${data_array[82]}</td><td>${data_array[83]}</td><td>${data_array[84]}</td><td>${data_array[85]}</td><td>${data_array[86]}</td><td>${data_array[87]}</td><td>${data_array[88]}</td><td>${data_array[89]}</td></tr>
    <tr><td>Matrix VEM</td><td>${data_array[90]}</td><td>${data_array[91]}</td><td>${data_array[92]}</td><td>${data_array[93]}</td><td>${data_array[94]}</td><td>${data_array[95]}</td><td>${data_array[96]}</td><td>${data_array[97]}</td><td>${data_array[98]}</td><td>${data_array[99]}</td></tr>
    <tr><td>Matrix VPG</td><td>${data_array[100]}</td><td>${data_array[101]}</td><td>${data_array[102]}</td><td>${data_array[103]}</td><td>${data_array[104]}</td><td>${data_array[105]}</td><td>${data_array[106]}</td><td>${data_array[107]}</td><td>${data_array[108]}</td><td>${data_array[109]}</td></tr>
    <tr><td>Matrix AQ</td><td>${data_array[110]}</td><td>${data_array[111]}</td><td>${data_array[112]}</td><td>${data_array[113]}</td><td>${data_array[114]}</td><td>${data_array[115]}</td><td>${data_array[116]}</td><td>${data_array[117]}</td><td>${data_array[118]}</td><td>${data_array[119]}</td></tr>
    <tr><td>Matrix TVM</td><td>${data_array[120]}</td><td>${data_array[121]}</td><td>${data_array[122]}</td><td>${data_array[123]}</td><td>${data_array[124]}</td><td>${data_array[125]}</td><td>${data_array[126]}</td><td>${data_array[127]}</td><td>${data_array[128]}</td><td>${data_array[129]}</td></tr>
    <tr><td>Matrix TS</td><td>${data_array[130]}</td><td>${data_array[131]}</td><td>${data_array[132]}</td><td>${data_array[133]}</td><td>${data_array[134]}</td><td>${data_array[135]}</td><td>${data_array[136]}</td><td>${data_array[137]}</td><td>${data_array[138]}</td><td>${data_array[139]}</td></tr>
    <tr><td>Matrix CS</td><td>${data_array[140]}</td><td>${data_array[141]}</td><td>${data_array[142]}</td><td>${data_array[143]}</td><td>${data_array[144]}</td><td>${data_array[145]}</td><td>${data_array[146]}</td><td>${data_array[147]}</td><td>${data_array[148]}</td><td>${data_array[149]}</td></tr>
    <tr><td>CAB-1 Approval</td><td>${data_array[150]}</td><td>${data_array[151]}</td><td>${data_array[152]}</td><td>${data_array[153]}</td><td>${data_array[154]}</td><td>${data_array[155]}</td><td>${data_array[156]}</td><td>${data_array[157]}</td><td>${data_array[158]}</td><td>${data_array[159]}</td></tr>
    <tr><td>CAB-2 Approval</td><td>${data_array[160]}</td><td>${data_array[161]}</td><td>${data_array[162]}</td><td>${data_array[163]}</td><td>${data_array[164]}</td><td>${data_array[165]}</td><td>${data_array[166]}</td><td>${data_array[167]}</td><td>${data_array[168]}</td><td>${data_array[169]}</td></tr>
    <tr><td>VLD Approval</td><td>${data_array[170]}</td><td>${data_array[171]}</td><td>${data_array[172]}</td><td>${data_array[173]}</td><td>${data_array[174]}</td><td>${data_array[175]}</td><td>${data_array[176]}</td><td>${data_array[177]}</td><td>${data_array[178]}</td><td>${data_array[179]}</td></tr>
  </tbody>
</table>
</body>
</html> 
HTML
)

{
echo "To: $(cat "$recipient")"
echo "Cc: $(cat "$recipient_email_cc")"
echo "Subject: $subject"
echo "MIME-Version: 1.0"
echo "Content-Type: multipart/mixed; boundary=\"boundary\""
echo ""
echo "--boundary"
echo "Content-Type: text/html; charset=\"us-ascii\""
echo ""
echo "$mail_content"
echo "--boundary"
echo "Content-Disposition: attachment; filename=\"$(basename "$DCR_Detailed_Attachment")\""
echo "Content-Type: application/octet-stream"
echo ""
cat "$DCR_Detailed_Attachment"
echo "--boundary--"
} | /usr/sbin/sendmail -t 

echo "-----DCR_Escalation_Uaprodtrl.sh end-----"
