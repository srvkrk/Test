#!/bin/sh
. /user/uaprodtrl/.bash_profile
echo "In Shell RACoption2c7to2c3 at 2c7.."
echo "Script executed from Path: ${PWD}"
#cd /proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/.
#rm -rf partInp.txt
#cd /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/partInp.txt/.
rm -rf partInp.txt

echo "Testing Rajan"
echo "Direct...$1"
part=$1

echo "Direct...mail...$2"
userId=$2

echo "Part Variable..$part"
#touch partInp.txt
echo $part >> partInp.txt
touch partInp.txt
chmod 777 partInp.txt

echo "After redirect part number in text file partInp.txt"
cat partInp.txt



#mv /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/$part /proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/.
#mv /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/partInp.txt /proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/.
scp -r partInp.txt omfprod@172.22.97.8:/proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/
echo "Moved done..check.."


cd /proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/.
#echo "$part" > partInp.txt

#echo "After redirect part number in text file partInp.txt"
#cat partInp.txt

chmod 777 partInp.txt
#/proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/MainDownTrl.sh ${part}
#ssh omfprod@plmpapp2c3 -n "sh /proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/RACoptionMainDownUpd_UAPROD.sh partInp.txt"
ssh omfprod@plmpapp2c3 -n "cd /proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/; /proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/RACoptionMainDownUpd_UAPROD.sh ${userId}> $part.log&"

#ssh omfprod@plmpapp2c3 -n "cd /proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/; /proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/sendMail.sh mail part > $mail.log&"


#cd /proj/PLMLoading/UAFiles/CATIA_Downloading/Rajan_PV/PV_Catia_DataMigration/.
#rm -rf partInp.txt

