. /user/cvprod/.bash_profile
echo "Start==>Calling DML Psc_PartRemove from cvprodtrl---------->"
echo "Shell--DMLNo.=> " $1
/user/cvprod/Program_Shells/DML_DCR/Psc_PartRemove -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -DMLNum=$1
echo "End==>DML Psc_PartRemove from cvprodtrl---------->"
