echo "Shell--DCRNumber.= " $1
echo "Shell--Reason .= " $2
echo "DCR reason Update Running on Server"
echo "Towards Connecting"
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Rudresh/DCR_Code/Dcr_reason_update_UA.sh $1 $2"