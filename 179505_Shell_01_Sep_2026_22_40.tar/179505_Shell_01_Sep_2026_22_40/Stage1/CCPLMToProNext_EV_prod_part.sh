. /home/cmitest/.bash_profile
####################### This Shell in called from Main server #######################
echo $1
echo $2
echo $3
echo $4
echo $5
myFnameVar=$3
myFname=`echo $myFnameVar | sed 's/-i=//g'`
echo "fname is : $myFname" > /tmp/"$myFname"_quick_sor.log 
chmod 777 /tmp/"$myFname"_quick_sor.log
nohup /user/uaprodtrl/PLMSAP/liveXfr/CCPLMToProNext_EV_prod_part $1 "$2" $3 $4 $5 >> /tmp/"$myFname"_quick_sor.log &
