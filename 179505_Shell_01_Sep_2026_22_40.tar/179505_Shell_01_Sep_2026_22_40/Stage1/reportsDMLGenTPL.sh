. /user/uaprod/.bash_profile
#!/bin/ksh
echo $JAVA_HOME > /tmp/Testing_DMLGenTPL.log
chmod 777 /tmp/${1}_InputFile.txt
while read line
do
chmod 777 $line
done < /tmp/${1}_InputFile.txt
$JAVA_HOME/bin/java -jar /user/uaprod/TC_ROOT_10/bin/tml_tools/org.tml.teamcenter.reports.jar dml_gentpl_report -reportxml /tmp/${1}_DMLOutput.xml -inputfile /tmp/${1}_InputFile.txt >> /tmp/Testing_DMLGenTPL.log 2>&1
