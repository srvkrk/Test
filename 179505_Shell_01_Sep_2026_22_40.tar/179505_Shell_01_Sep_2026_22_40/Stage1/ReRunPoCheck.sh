. /user/uaprod/.bash_profile
echo "Start of ReRunPoCheck.sh from uaprod --> $1"
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Program_Shells/DML_DCR/tm_ReRunPoCheck_uaprodtrl.sh $1"
echo "---Expand ReRunPoCheck.sh Shell Completed on uaprod.---"