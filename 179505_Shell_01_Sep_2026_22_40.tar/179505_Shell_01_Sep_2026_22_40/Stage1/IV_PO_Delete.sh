echo "Cronjob Shell Start InValidPO PO Parts Delete for CVPROD >> IV_PO_Delete"
#/user/cvprod/TC_ROOT14/tcldPatch/tcPatchExecutable IV_PO_Delete
nohup ./IV_PO_Delete -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba > IV_PO_Deletecron.log &
echo "Shell End InValidPO PO Parts Delete for CVPROD"