. /user/aplstdgrp/.bash_profile
echo "Connecting uaprod...."
echo $1
pwd
cd /user/aplstdgrp/Nana/Engine_Data_migration/Engine_Inc_Data_migration/TCUA_ENG_STD_data_loading
pwd
tm_TCE_TCUA_PARTStampOneTime_STDSI -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=/proj/PLMLoading/UAFiles/APL_STD_TCE_TCUA_EngTA_Data_mig/STD_Data_Loading/$1/Engine_STD_CARPLT_PartListInfo.txt  > EngTAPartListInfo.log

wait
if [ $? != 0 ]
        then
                echo "Problem in Part stamping.."
                exit 1
        else
                echo "Part Stamping Executed Successfully ..So calling BOM Updation"
					tm_t5DMLTaskPartRel_STDSI -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=/proj/PLMLoading/UAFiles/APL_STD_TCE_TCUA_EngTA_Data_mig/STD_Data_Loading/$1/Engine_STD_CARPLT_DMLInfo.txt > EngTADMLInfo.log
					wait
					if [ $? != 0 ]
        				then
                				echo "Problem in DML Task stamping.."
                				exit 1
        				else
							echo "DML Task stamping successfully.."
					fi
					
fi

now="$(date +'%d_%m_%Y')"
echo "Start copying the log to folder"
mkdir $now
pwd
cp /user/aplstdgrp/Nana/Engine_Data_migration/Engine_Inc_Data_migration/TCUA_ENG_STD_data_loading/*.log . $now
rm -f *.log
cd $now
pwd
cp /proj/PLMLoading/UAFiles/APL_STD_TCE_TCUA_EngTA_Data_mig/STD_Data_Loading/$1/* .
if grep "Teamcenter ERROR" *.log
then
    echo "Error found"
	echo -e  "${RED}Dear All,\n\n Engine-TA Incremental Data Stamping from TCE to TCUA execution not exected successfully on $1 for STDSI Released DML. \n\n\n\nRegards,\nPLM SYSTEMS...${NC}" | nail -s "Engine-TA  Incremental Data Execution Status for STDSI Released DML" nana.keskar@tatatechnologies.com  

(
echo "To: awadhutn.ttl@tatamotors.com azmathp.ttl@tatamotors.com ac.ttl@tatamotors.com"
echo "Cc: nanak.ttl@tatamotors.com ankushj.ttl@tatamotors.com"
echo "Subject: STATUS OF Engine-TA INCREMENTAL DATA SYNC WITH PLM TCE-TCUA FOR STDSI RELEASED DML ON $1"
echo "Content-Type: text/html"
echo
echo "<html>
<head>
<title>Status of the jobs during the day</title>
<style>
table, th, td {
    border: 1px solid blue;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
</style>
</head>
<body>
<p><font   color="#ff0000">Dear All,</font></p>
<p><font   color="#ff0000">Engine-TA Incremental Data Stamping from TCE to TCUA execution not exected successfully for STDSI Released DML.Status of the Shells Execution during the day:</font></p>
<table style='width:100%'>
<tr bgcolor='#808080'>
    <th><center>Shell Name</center></th>
    <th><center>Server</center></th>
    <th><center>Status</center></th>
    <th><center>LOG PATH</center></th>
  </tr>
  <tr>
    <td><center>CronJobIncrementEngTADataDownLd_STDSI.sh</center></td>
    <td><center>plmpapp2c3</center></td>
    <td><center>CROSS VERIFY LOG ON SERVER FOLDER AS PER DATE</center></td>
    <td><center>plmpapp2c4:/user/aplstdgrp/Nana/Engine_Data_migration/Engine_Inc_Data_migration/TCUA_ENG_STD_data_loading/</center></td>
  </tr>  
 </table>
 <p><font  color="#ff0000">--</font></p>
 <p><font  color="#ff0000">Regards,</font></p>
 <p><font  color="#ff0000">PLM SYSTEM.....</font></p>
</body></html>"
echo
) | /usr/sbin/sendmail -t
echo "111 finished....."   


 else
	echo "Error not found"
	echo -e  "${RED}Dear All,\n\n Engine-TA Incremental Data Stamping from TCE to TCUA execution successfully completed on $1 for STDSI Released DML. \n\n\n\nRegards,\nPLM SYSTEMS...${NC}" | nail -s "Aquilla Incremental Data Execution Status for STDSI Released DML" Deepti.Meshram@tatatechnologies.com  

(
echo "To: awadhutn.ttl@tatamotors.com azmathp.ttl@tatamotors.com ac.ttl@tatamotors.com"
echo "Cc: nanak.ttl@tatamotors.com ankush.ttl@tatamotors.com"
echo "Subject: STATUS OF Engine-TA INCREMENTAL DATA SYNC WITH PLM TCE-TCUA ON $1 FOR STDSI RELEASED DML"
echo "Content-Type: text/html"
echo
echo "<html>
<head>
<title>Status of the jobs during the day</title>
<style>
table, th, td {
    border: 1px solid blue;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
</style>
</head>
<body>
<p><font   color="#ff0000">Dear All,</font></p>
<p><font   color="#ff0000">Engine-TA Incremental Data Stamping from TCE to TCUA execution successfully completed for STDSI Released DML.Status of the Shells Execution during the day:</font></p>
<table style='width:100%'>
<tr bgcolor='#808080'>
    <th><center>Shell Name</center></th>
    <th><center>Server</center></th>
    <th><center>Status</center></th>
    <th><center>LOG PATH</center></th>
  </tr>
  <tr>
    <td><center>CronJobIncrementEngTADataDownLd_STDSI.sh<</center></td>
    <td><center>plmpapp2c3</center></td>
    <td><center>CROSS VERIFY LOG ON SERVER FOLDER AS PER DATE</center></td>
    <td><center>plmpapp2c4:/user/aplstdgrp/Nana/Engine_Data_migration/Engine_Inc_Data_migration/TCUA_ENG_STD_data_loading/</center></td>
  </tr>  
 </table>
 <p><font  color="#ff0000">--</font></p>
 <p><font  color="#ff0000">Regards,</font></p>
 <p><font  color="#ff0000">PLM SYSTEM.....</font></p>
</body></html>"
echo
) | /usr/sbin/sendmail -t
echo "finished....." 
fi


