#!/bin/bash
. /user/uaprodtrl/.bash_profile
echo **************In TMKO_Mail_Approval Shell_4******************
echo $1
echo $2
echo $3
echo $4
echo $3
echo $6

BASE_PATH=/user/uaprodtrl/Anvesh/TMKO_Shells
echo $BASE_PATH
cd $BASE_PATH

${BASE_PATH}/TMKOoutput -u=ab923373.ttl -p=XYT95ESA -g="" -DH_no=$1

#/user/uaprodtrl/Anvesh/TMKO_Shells/TMKOoutput -DH_no=$1
cd /tmp/
if [ -f "$1_output.txt" ]
then
        echo "*****${2}_output.txt***** file found."
else
        echo "*****${2}_output.txt*****, File not found"
fi       
      

 while read line;do

 if [[ $line == *"CurrentId="* ]]; then
 CurrentId=$(echo $line| cut -d'=' -f 2)
 fi
 
 if [[ $line == *"DocHeader_id="* ]]; then
 DocHeader_id=$(echo $line| cut -d'=' -f 2)
 fi
 
 if [[ $line == *"ObjType="* ]]; then
 ObjType=$(echo $line| cut -d'=' -f 2)
 fi
 
 if [[ $line == *"LastModUsr="* ]]; then
 LastModUsr=$(echo $line| cut -d'=' -f 2)
 fi
 
 if [[ $line == *"creationdate="* ]]; then
 creationdate=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLCOC="* ]]; then
 PLCOC=$(echo $line| cut -d'=' -f 2)
 fi

  if [[ $line == *"ERCCOC="* ]]; then
 ERCCOC=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"person="* ]]; then
 person=$(echo $line| cut -d'=' -f 2)
 fi

  if [[ $line == *"DocHeader_Number="* ]]; then
 DocHeader_Number=$(echo $line| cut -d'=' -f 2)
 fi
   if [[ $line == *"AQsign="* ]]; then
 AQsign=$(echo $line| cut -d'=' -f 2)
 fi

  if [[ $line == *"PLEndDate="* ]]; then
 PLEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"ChiefEndDate="* ]]; then
 ChiefEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"CostEndDate="* ]]; then
 CostEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"TSEndDate="* ]]; then
 TSEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"AQEndDate="* ]]; then
 AQEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"FMQ_dateEndDate="* ]]; then
 FMQ_dateEndDate=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"enddateEP="* ]]; then
 enddateEP=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernameAQ="* ]]; then
 usernameAQ=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernameFMQ="* ]]; then
 usernameFMQ=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernameChief="* ]]; then
 usernameChief=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernameCost="* ]]; then
 usernameCost=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernameTS="* ]]; then
 usernameTS=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"usernamePLProceed="* ]]; then
 usernamePLProceed=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"usernameCoc="* ]]; then
 usernameCoc=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"PLCOCDecision="* ]]; then
 PLCOCDecision=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ChiefDecision="* ]]; then
 ChiefDecision=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"CostDecision="* ]]; then
 CostDecision=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"TSDecision="* ]]; then
 TSDecision=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQDecision="* ]]; then
 AQDecision=$(echo $line| cut -d'=' -f 2)
 fi
  if [[ $line == *"FMQDecision="* ]]; then
 FMQDecision=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"CoCdecision1="* ]]; then
 CoCdecision1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"ERCCOCComment1="* ]]; then
 ERCCOCComment1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCStatus1="* ]]; then  
 ERCCOCStatus1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCOwner1="* ]]; then
 ERCCOCOwner1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCSignoffDate1="* ]]; then
 ERCCOCSignoffDate1=$(echo $line| cut -d'=' -f 2)                            
 fi
 if [[ $line == *"chiefEngineerComment1="* ]]; then
 chiefEngineerComment1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineersignoff1="* ]]; then
 chiefEngineersignoff1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineerStatus1="* ]]; then
 chiefEngineerStatus1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineerSignoffDate1="* ]]; then
 chiefEngineerSignoffDate1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputandsignoff1="* ]]; then
 AQinputandsignoff1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputComment1="* ]]; then
 AQinputComment1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputSignoffDate1="* ]]; then
 AQinputSignoffDate1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputStatus1="* ]]; then
 AQinputStatus1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"TSinputandsignoff1="* ]]; then
 TSinputandsignoff1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"TSinputStatus1="* ]]; then
 TSinputStatus1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"TSinputComment1="* ]]; then
 TSinputComment1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"TSinputSignoffDate1="* ]]; then
 TSinputSignoffDate1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"CostmanagerComment1="* ]]; then
 CostmanagerComment1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"Costmanagerinput1="* ]]; then
 Costmanagerinput1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"CostmanagerSignoffDate1="* ]]; then
 CostmanagerSignoffDate1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"CostmanagerStatus1="* ]]; then
 CostmanagerStatus1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLreworkOwner1="* ]]; then
 PLreworkOwner1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLStatus1="* ]]; then
 PLStatus1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLComment1="* ]]; then
 PLComment1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLSignoffDate1="* ]]; then
 PLSignoffDate1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputandsignoff1="* ]]; then
 FMQinputandsignoff1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputStatus1="* ]]; then
 FMQinputStatus1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputComment1="* ]]; then
 FMQinputComment1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"FMQinputSignoffDate1="* ]]; then
 FMQinputSignoffDate1=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"ERCCOCComment2="* ]]; then
 ERCCOCComment2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCStatus2="* ]]; then  
 ERCCOCStatus2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCOwner2="* ]]; then
 ERCCOCOwner2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCSignoffDate2="* ]]; then
 ERCCOCSignoffDate2=$(echo $line| cut -d'=' -f 2)                            
 fi
 if [[ $line == *"chiefEngineerComment2="* ]]; then
 chiefEngineerComment2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineersignoff2="* ]]; then
 chiefEngineersignoff2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineerStatus2="* ]]; then
 chiefEngineerStatus2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineerSignoffDate2="* ]]; then
 chiefEngineerSignoffDate2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputandsignoff2="* ]]; then
 AQinputandsignoff2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputComment2="* ]]; then
 AQinputComment2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputSignoffDate2="* ]]; then
 AQinputSignoffDate2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputStatus2="* ]]; then
 AQinputStatus2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"TSinputandsignoff2="* ]]; then
 TSinputandsignoff2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"TSinputStatus2="* ]]; then
 TSinputStatus2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"TSinputComment2="* ]]; then
 TSinputComment2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"TSinputSignoffDate2="* ]]; then
 TSinputSignoffDate2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"CostmanagerComment2="* ]]; then
 CostmanagerComment2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"Costmanagerinput2="* ]]; then
 Costmanagerinput2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"CostmanagerSignoffDate2="* ]]; then
 CostmanagerSignoffDate2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"CostmanagerStatus2="* ]]; then
 CostmanagerStatus2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLreworkOwner2="* ]]; then
 PLreworkOwner2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLStatus2="* ]]; then
 PLStatus2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLComment2="* ]]; then
 PLComment2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLSignoffDate2="* ]]; then
 PLSignoffDate2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputandsignoff2="* ]]; then
 FMQinputandsignoff2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputStatus2="* ]]; then
 FMQinputStatus2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputComment2="* ]]; then
 FMQinputComment2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"FMQinputSignoffDate2="* ]]; then
 FMQinputSignoffDate2=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"ERCCOCComment3="* ]]; then
 ERCCOCComment3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCStatus3="* ]]; then  
 ERCCOCStatus3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCOwner3="* ]]; then
 ERCCOCOwner3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCSignoffDate3="* ]]; then
 ERCCOCSignoffDate3=$(echo $line| cut -d'=' -f 2)                            
 fi
 if [[ $line == *"chiefEngineerComment3="* ]]; then
 chiefEngineerComment3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineersignoff3="* ]]; then
 chiefEngineersignoff3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineerStatus3="* ]]; then
 chiefEngineerStatus3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineerSignoffDate3="* ]]; then
 chiefEngineerSignoffDate3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputandsignoff3="* ]]; then
 AQinputandsignoff3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputComment3="* ]]; then
 AQinputComment3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputSignoffDate3="* ]]; then
 AQinputSignoffDate3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputStatus3="* ]]; then
 AQinputStatus3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"TSinputandsignoff3="* ]]; then
 TSinputandsignoff3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"TSinputStatus3="* ]]; then
 TSinputStatus3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"TSinputComment3="* ]]; then
 TSinputComment3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"TSinputSignoffDate3="* ]]; then
 TSinputSignoffDate3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"CostmanagerComment3="* ]]; then
 CostmanagerComment3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"Costmanagerinput3="* ]]; then
 Costmanagerinput3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"CostmanagerSignoffDate3="* ]]; then
 CostmanagerSignoffDate3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"CostmanagerStatus3="* ]]; then
 CostmanagerStatus3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLreworkOwner3="* ]]; then
 PLreworkOwner3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLStatus3="* ]]; then
 PLStatus3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLComment3="* ]]; then
 PLComment3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLSignoffDate3="* ]]; then
 PLSignoffDate3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputandsignoff3="* ]]; then
 FMQinputandsignoff3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputStatus3="* ]]; then
 FMQinputStatus3=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputComment3="* ]]; then
 FMQinputComment3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"FMQinputSignoffDate3="* ]]; then
 FMQinputSignoffDate3=$(echo $line| cut -d'=' -f 2)
 fi

if [[ $line == *"ERCCOCComment4="* ]]; then
 ERCCOCComment4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCStatus4="* ]]; then  
 ERCCOCStatus4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCOwner4="* ]]; then
 ERCCOCOwner4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ERCCOCSignoffDate4="* ]]; then
 ERCCOCSignoffDate4=$(echo $line| cut -d'=' -f 2)                            
 fi
 if [[ $line == *"chiefEngineerComment4="* ]]; then
 chiefEngineerComment4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineersignoff4="* ]]; then
 chiefEngineersignoff4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineerStatus4="* ]]; then
 chiefEngineerStatus4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"chiefEngineerSignoffDate4="* ]]; then
 chiefEngineerSignoffDate4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputandsignoff4="* ]]; then
 AQinputandsignoff4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputComment4="* ]]; then
 AQinputComment4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputSignoffDate4="* ]]; then
 AQinputSignoffDate4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"AQinputStatus4="* ]]; then
 AQinputStatus4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"TSinputandsignoff4="* ]]; then
 TSinputandsignoff4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"TSinputStatus4="* ]]; then
 TSinputStatus4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"TSinputComment4="* ]]; then
 TSinputComment4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"TSinputSignoffDate4="* ]]; then
 TSinputSignoffDate4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"CostmanagerComment4="* ]]; then
 CostmanagerComment4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"Costmanagerinput4="* ]]; then
 Costmanagerinput4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"CostmanagerSignoffDate4="* ]]; then
 CostmanagerSignoffDate4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"CostmanagerStatus4="* ]]; then
 CostmanagerStatus4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLreworkOwner4="* ]]; then
 PLreworkOwner4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLStatus4="* ]]; then
 PLStatus4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLComment4="* ]]; then
 PLComment4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"PLSignoffDate4="* ]]; then
 PLSignoffDate4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputandsignoff4="* ]]; then
 FMQinputandsignoff4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputStatus4="* ]]; then
 FMQinputStatus4=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"FMQinputComment4="* ]]; then
 FMQinputComment4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"FMQinputSignoffDate4="* ]]; then
 FMQinputSignoffDate4=$(echo $line| cut -d'=' -f 2)
 fi

  if [[ $line == *"ConditionComment="* ]]; then
 ConditionComment=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionStatus="* ]]; then
 ConditionStatus=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionreworkOwner="* ]]; then
 ConditionreworkOwner=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionSignoffDate="* ]]; then
 ConditionSignoffDate=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedComment="* ]]; then
 ProceedComment=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedSignoffDate="* ]]; then
 ProceedSignoffDate=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedStatus="* ]]; then
 ProceedStatus=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"Proceedreraise="* ]]; then
 Proceedreraise=$(echo $line| cut -d'=' -f 2)
 fi

 if [[ $line == *"ConditionComment1="* ]]; then
 ConditionComment1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionStatus1="* ]]; then
 ConditionStatus1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionreworkOwner1="* ]]; then
 ConditionreworkOwner1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionSignoffDate1="* ]]; then
 ConditionSignoffDate1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedComment1="* ]]; then
 ProceedComment1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedSignoffDate1="* ]]; then
 ProceedSignoffDate1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedStatus1="* ]]; then
 ProceedStatus1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"Proceedreraise1="* ]]; then
 Proceedreraise1=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionComment2="* ]]; then
 ConditionComment2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionStatus2="* ]]; then
 ConditionStatus2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionreworkOwner2="* ]]; then
 ConditionreworkOwner2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionSignoffDate2="* ]]; then
 ConditionSignoffDate2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedComment2="* ]]; then
 ProceedComment2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedSignoffDate2="* ]]; then
 ProceedSignoffDate2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedStatus2="* ]]; then
 ProceedStatus2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"Proceedreraise2="* ]]; then
 Proceedreraise2=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionComment3="* ]]; then
 ConditionComment3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionStatus3="* ]]; then
 ConditionStatus3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionreworkOwner3="* ]]; then
 ConditionreworkOwner3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionSignoffDate3="* ]]; then
 ConditionSignoffDate3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedComment3="* ]]; then
 ProceedComment3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedSignoffDate3="* ]]; then
 ProceedSignoffDate3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedStatus3="* ]]; then
 ProceedStatus3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"Proceedreraise3="* ]]; then
 Proceedreraise3=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionComment4="* ]]; then
 ConditionComment4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionStatus4="* ]]; then
 ConditionStatus4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionreworkOwner4="* ]]; then
 ConditionreworkOwner4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ConditionSignoffDate4="* ]]; then
 ConditionSignoffDate4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedComment4="* ]]; then
 ProceedComment4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedSignoffDate4="* ]]; then
 ProceedSignoffDate4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"ProceedStatus4="* ]]; then
 ProceedStatus4=$(echo $line| cut -d'=' -f 2)
 fi
 if [[ $line == *"Proceedreraise4="* ]]; then
 Proceedreraise4=$(echo $line| cut -d'=' -f 2)
 fi

     

done < $1_output.txt
echo $CurrentId
echo $DocHeader_id
echo $ObjType
echo $LastModUsr
echo $creationdate
echo $PLCOC
echo $ERCCOC
echo $person
echo $AQsign
echo $PLEndDate
echo $ChiefEndDate
echo $CostEndDate
echo $TSEndDate
echo $AQEndDate
echo $FMQ_dateEndDate
echo $enddateEP
echo $usernameAQ
echo $usernameFMQ
echo $usernameChief
echo $usernameCost
echo $usernameTS
echo $usernamePLProceed
echo $usernameCoc
echo $PLCOCDecision
echo $ChiefDecision
echo $CostDecision
echo $TSDecision
echo $AQDecision
echo $FMQDecision
echo $CoCdecision1
echo $ConditionComment    
echo $ConditionStatus     
echo $ConditionreworkOwner
echo $ConditionSignoffDate
echo $ProceedComment      
echo $ProceedSignoffDate  
echo $ProceedStatus       
echo $Proceedreraise

echo $ERCCOCComment1
echo $ERCCOCStatus1
echo $ERCCOCOwner1
echo $ERCCOCSignoffDate1
echo $chiefEngineerComment1
echo $chiefEngineersignoff1
echo $chiefEngineerSignoffDate1
echo $chiefEngineerStatus1
echo $AQinputandsignoff1
echo $AQinputComment1
echo $AQinputSignoffDate1
echo $AQinputStatus1
echo $TSinputandsignoff1
echo $TSinputStatus1
echo $TSinputComment1
echo $TSinputSignoffDate1
echo $CostmanagerComment1
echo $Costmanagerinput1
echo $CostmanagerSignoffDate1
echo $CostmanagerStatus1
echo $PLreworkOwner1
echo $PLStatus1
echo $PLComment1
echo $PLSignoffDate1
echo $FMQinputandsignoff1
echo $FMQinputStatus1
echo $FMQinputComment1
echo $FMQinputSignoffDate1
echo $ConditionComment1    
echo $ConditionStatus1     
echo $ConditionreworkOwner1
echo $ConditionSignoffDate1
echo $ProceedComment1      
echo $ProceedSignoffDate1  
echo $ProceedStatus1       
echo $Proceedreraise1


echo $ERCCOCComment2
echo $ERCCOCStatus2
echo $ERCCOCOwner2
echo $ERCCOCSignoffDate2
echo $chiefEngineerComment2
echo $chiefEngineersignoff2
echo $chiefEngineerSignoffDate2
echo $chiefEngineerStatus2
echo $AQinputandsignoff2
echo $AQinputComment2
echo $AQinputSignoffDate2
echo $AQinputStatus2
echo $TSinputandsignoff2
echo $TSinputStatus2
echo $TSinputComment2
echo $TSinputSignoffDate2
echo $CostmanagerComment2
echo $Costmanagerinput2
echo $CostmanagerSignoffDate2
echo $CostmanagerStatus2
echo $PLreworkOwner2
echo $PLStatus2
echo $PLComment2
echo $PLSignoffDate2
echo $FMQinputandsignoff2
echo $FMQinputStatus2
echo $FMQinputComment2
echo $FMQinputSignoffDate2
echo $ConditionComment2    
echo $ConditionStatus2     
echo $ConditionreworkOwner2
echo $ConditionSignoffDate2
echo $ProceedComment2      
echo $ProceedSignoffDate2  
echo $ProceedStatus2       
echo $Proceedreraise2

echo $ERCCOCComment3
echo $ERCCOCStatus3
echo $ERCCOCOwner3
echo $ERCCOCSignoffDate3
echo $chiefEngineerComment3
echo $chiefEngineersignoff3
echo $chiefEngineerSignoffDate3
echo $chiefEngineerStatus3
echo $AQinputandsignoff3
echo $AQinputComment3
echo $AQinputSignoffDate3
echo $AQinputStatus3
echo $TSinputandsignoff3
echo $TSinputStatus3
echo $TSinputComment3
echo $TSinputSignoffDate3
echo $CostmanagerComment3
echo $Costmanagerinput3
echo $CostmanagerSignoffDate3
echo $CostmanagerStatus3
echo $PLreworkOwner3
echo $PLStatus3
echo $PLComment3
echo $PLSignoffDate3
echo $FMQinputandsignoff3
echo $FMQinputStatus3
echo $FMQinputComment3
echo $FMQinputSignoffDate3
echo $ConditionComment3    
echo $ConditionStatus3     
echo $ConditionreworkOwner3
echo $ConditionSignoffDate3
echo $ProceedComment3      
echo $ProceedSignoffDate3  
echo $ProceedStatus3       
echo $Proceedreraise3


echo $ERCCOCComment4
echo $ERCCOCStatus4
echo $ERCCOCOwner4
echo $ERCCOCSignoffDate4
echo $chiefEngineerComment4
echo $chiefEngineersignoff4
echo $chiefEngineerSignoffDate4
echo $chiefEngineerStatus4
echo $AQinputandsignoff4
echo $AQinputComment4
echo $AQinputSignoffDate4
echo $AQinputStatus4
echo $TSinputandsignoff4
echo $TSinputStatus4
echo $TSinputComment4
echo $TSinputSignoffDate4
echo $CostmanagerComment4
echo $Costmanagerinput4
echo $CostmanagerSignoffDate4
echo $CostmanagerStatus4
echo $PLreworkOwner4
echo $PLStatus4
echo $PLComment4
echo $PLSignoffDate4
echo $FMQinputandsignoff4
echo $FMQinputStatus4
echo $FMQinputComment4
echo $FMQinputSignoffDate4
echo $ConditionComment4    
echo $ConditionStatus4     
echo $ConditionreworkOwner4
echo $ConditionSignoffDate4
echo $ProceedComment4      
echo $ProceedSignoffDate4  
echo $ProceedStatus4       
echo $Proceedreraise4






(
echo 'Content-Type: multipart/mixed; boundary="-q1w2e3r4t3"'
echo "To:$4"
echo "CC:$6"
echo "SUBJECT:TMKO sign off report $3:$Request_Number."
echo "SUBJECT:TMKO sign off report $3:$WBS_details."
echo "Content-Type: text/html"
echo "Content-Disposition: inline"
echo "<html>"
    echo "<head></head>"
    echo "<body>"
        echo "<table width='900px' border='1px' style='border-color: #206fab;border-style: none;'>"
            echo "<table width='100%'>"
                echo "<tr style='background:#206fab;height:60px;'>"
                    echo "<td colspan='3'>"
                        echo "<strong>"
                            echo "<p style=' color: #FFF;text-align: center;font-size: 20px;text-transform: uppercase;'>TMKO sign-off report $1"
                            echo "</p>"
                        echo "</strong>"
                    echo "</td>"
		    echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'>Hello,</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'></td>"
                echo "</tr>"
		 echo "<tr style='background:#FFF;height:20px;'>"

		 echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>ERC COC Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ERCCOCOwner1"
                    echo "</td>"
		      echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ERCCOCStatus1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'> ERC COC Comment</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ERCCOCComment1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ERCCOCSignoffDate1"
                    echo "</td>"
		  
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>chief Engineer sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$chiefEngineersignoff1"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$chiefEngineerStatus1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>chief Engineer sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$chiefEngineerComment1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$chiefEngineerSignoffDate1"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>AQ input and sign off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$AQinputandsignoff1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQinputStatus1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>AQ input and sign off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$AQinputComment1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQinputSignoffDate1"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>TS input and sign-off Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$TSinputandsignoff1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSinputStatus1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>TS input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$TSinputComment1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSinputSignoffDate1"
                    echo "</td>"
                echo "</tr>"
	        echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Cost manager input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$Costmanagerinput1"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostmanagerStatus1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Cost manager input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$CostmanagerComment1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostmanagerSignoffDate1"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>FMQ input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$FMQinputandsignoff1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQinputStatus1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>FMQ input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$FMQinputComment1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQinputSignoffDate1"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/re-raise with rework Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$PLreworkOwner1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLStatus1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/re-raise with rework Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$PLComment1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLSignoffDate1"
                    echo "</td>"
		     echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionreworkOwner1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionStatus1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionComment1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionSignoffDate1"
                    echo "</td>"
		    echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/Rework(by PL) Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$Proceedreraise1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedStatus1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/Rework(by PL) Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ProceedComment1"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedSignoffDate1"
                    echo "</td>"
                echo "</tr>"

      
		    echo "<tr style='background:#FFF;height:20px;'>"
		 echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>ERC COC Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ERCCOCOwner2"
                    echo "</td>"
		      echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ERCCOCStatus2"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'> ERC COC Comment</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ERCCOCComment2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ERCCOCSignoffDate2"
                    echo "</td>"
		  
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>chief Engineer sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$chiefEngineersignoff2"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$chiefEngineerStatus2"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>chief Engineer sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$chiefEngineerComment2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$chiefEngineerSignoffDate2"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>AQ input and sign off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$AQinputandsignoff2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQinputStatus2"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>AQ input and sign off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$AQinputComment2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQinputSignoffDate2"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>TS input and sign-off Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$TSinputandsignoff2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSinputStatus2"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>TS input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$TSinputComment2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSinputSignoffDate2"
                    echo "</td>"
                echo "</tr>"
	        echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Cost manager input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$Costmanagerinput2"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostmanagerStatus2"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Cost manager input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$CostmanagerComment2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostmanagerSignoffDate2"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>FMQ input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$FMQinputandsignoff2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQinputStatus2"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>FMQ input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$FMQinputComment2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQinputSignoffDate2"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/re-raise with rework Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$PLreworkOwner2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLStatus2"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/re-raise with rework Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$PLComment2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLSignoffDate2"
                    echo "</td>"
		     echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionreworkOwner2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionStatus2"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionComment2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionSignoffDate2"
                    echo "</td>"
		    echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/Rework(by PL) Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$Proceedreraise2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedStatus2"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/Rework(by PL) Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ProceedComment2"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedSignoffDate2"
                    echo "</td>"
                echo "</tr>"
		    echo "<tr style='background:#FFF;height:20px;'>"
                   echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>ERC COC Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ERCCOCOwner3"
                    echo "</td>"
		      echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ERCCOCStatus3"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'> ERC COC Comment</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ERCCOCComment3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ERCCOCSignoffDate3"
                    echo "</td>"
		  
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>chief Engineer sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$chiefEngineersignoff3"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$chiefEngineerStatus3"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>chief Engineer sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$chiefEngineerComment3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$chiefEngineerSignoffDate3"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>AQ input and sign off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$AQinputandsignoff3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQinputStatus3"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>AQ input and sign off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$AQinputComment3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQinputSignoffDate3"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>TS input and sign-off Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$TSinputandsignoff3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSinputStatus3"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>TS input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$TSinputComment3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSinputSignoffDate3"
                    echo "</td>"
                echo "</tr>"
	        echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Cost manager input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$Costmanagerinput3"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostmanagerStatus3"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Cost manager input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$CostmanagerComment3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostmanagerSignoffDate3"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>FMQ input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$FMQinputandsignoff3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQinputStatus3"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>FMQ input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$FMQinputComment3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQinputSignoffDate3"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/re-raise with rework Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$PLreworkOwner3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLStatus3"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/re-raise with rework Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$PLComment3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLSignoffDate3"
                    echo "</td>"
		     echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionreworkOwner3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionStatus3"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionComment3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionSignoffDate3"
                    echo "</td>"
		    echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/Rework(by PL) Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$Proceedreraise3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedStatus3"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/Rework(by PL) Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ProceedComment3"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedSignoffDate3"
                    echo "</td>"
                echo "</tr>"
		    echo "<tr style='background:#FFF;height:20px;'>"

                   echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>ERC COC Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ERCCOCOwner4"
                    echo "</td>"
		      echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ERCCOCStatus4"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'> ERC COC Comment</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ERCCOCComment4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ERCCOCSignoffDate4"
                    echo "</td>"
		  
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>chief Engineer sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$chiefEngineersignoff4"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$chiefEngineerStatus4"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>chief Engineer sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$chiefEngineerComment4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$chiefEngineerSignoffDate4"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>AQ input and sign off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$AQinputandsignoff4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQinputStatus4"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>AQ input and sign off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$AQinputComment4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQinputSignoffDate4"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>TS input and sign-off Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$TSinputandsignoff4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSinputStatus4"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>TS input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$TSinputComment4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSinputSignoffDate4"
                    echo "</td>"
                echo "</tr>"
	        echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Cost manager input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$Costmanagerinput4"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostmanagerStatus4"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Cost manager input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$CostmanagerComment4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostmanagerSignoffDate4"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>FMQ input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$FMQinputandsignoff4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQinputStatus4"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>FMQ input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$FMQinputComment4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQinputSignoffDate4"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/re-raise with rework Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$PLreworkOwner4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLStatus4"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/re-raise with rework Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$PLComment4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLSignoffDate4"
                    echo "</td>"
		     echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionreworkOwner4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionStatus4"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionComment4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionSignoffDate4"
                    echo "</td>"
		    echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/Rework(by PL) Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$Proceedreraise4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedStatus4"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/Rework(by PL) Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ProceedComment4"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedSignoffDate4"
                    echo "</td>"
                echo "</tr>"

		    echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>ERC COC Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameCoc"
                    echo "</td>"
		      echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CoCdecision1"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'> ERC COC Comment</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ERCCOC"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$enddateEP"
                    echo "</td>"
		  
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>chief Engineer sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameChief"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ChiefDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>chief Engineer sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ObjType"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ChiefEndDate"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>AQ input and sign off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameAQ"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>AQ input and sign off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$AQsign"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$AQEndDate"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>TS input and sign-off Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameTS"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>TS input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$DocHeader_Number"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$TSEndDate"
                    echo "</td>"
                echo "</tr>"
	        echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Cost manager input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameCost"
                    echo "</td>"
		     echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Cost manager input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$LastModUsr"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$CostEndDate"
                    echo "</td>"
                echo "</tr>"
		echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>FMQ input and sign-off Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernameFMQ"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>FMQ input and sign-off Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$CurrentId"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
		    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$FMQ_dateEndDate"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/re-raise with rework Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$usernamePLProceed"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLCOCDecision"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/re-raise with rework Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$PLCOC"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$PLEndDate"
                    echo "</td>"
		     echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Owner</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionreworkOwner"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionStatus"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed /Re-raise with rework Decison Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ConditionComment"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ConditionSignoffDate"
                    echo "</td>"
		    echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='15%'><strong style='color#206fab;'>Proceed/Rework(by PL) Owner </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$Proceedreraise"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Status</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedStatus"
                    echo "</td>"
                    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='10%'><strong style='color#206fab;'>Proceed/Rework(by PL) Comment </strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:3px;font-size:12px;'>"
                        echo "$ProceedComment"
                    echo "</td>"
		    echo "<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);' width='5%'><strong style='color#206fab;'>Signoff Date</strong></td>"
                    echo "<td width='3%'>:</td>"
                    echo "<td style='padding:4px;font-size:12px;'>"
                        echo "$ProceedSignoffDate"
                    echo "</td>"
                echo "</tr>"	  
                 

		    echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'>Regards,<br>Team PLM.</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'>"
                        echo "<hr>"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:3px;' colspan='3'></td>"
                echo "</tr>"
                echo "<tr style='background:#206fab;height:60px;'>"
                    echo "<td colspan='1'></td>"
                echo "</tr>"
                echo "</td></tr>"
            echo "</table>"
        echo "</table>"
    echo "</body>"
echo "</html>"
) | /usr/sbin/sendmail -f "ab923373.ttl@tatamotors.com" -t "ab923373.ttl@tatamotors.com"

