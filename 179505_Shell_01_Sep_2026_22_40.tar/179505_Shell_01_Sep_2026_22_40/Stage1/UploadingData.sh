#copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author                : Bhaskar/Upendra (Modified by Mohammad Asif for DFQ/DVA Migration)
# Created on            :  April 2017
# Project               : Teamcenter 10.1 TML
# Modified by           : Kalpesh Gondhali(05-Dec-2019)
# Modified by           : Mohammad Asif(25-Mar-2023)
#######################################################################################
#!/bin/sh
. /user/cvprod/.bash_profile
while read i
do
         ShDocNumber=`echo "$i"|cut -d ',' -f 1`
          echo -e "TCDocNumber \t\t = $ShDocNumber"

           echo  "$ShDocNumber"
user=loader
pass=/user/cvprod/shells/Admin/loaderpasswdFile.pwf
folder=$ShDocNumber
echo $folder
pwd
cd /user/cvprod/Asif/DFQ_Loading/DFQ_Loading/$folder

splitfiles=`ls $folder.txt`
echo $splitfiles
for flist in $splitfiles
do
echo "Importing Data From TCE to CVPROD.............!! $flist"
/user/cvprod/Asif/DFQ_Loading/DFQ_Loading/uploader -i=$flist -u=$user -pf=$pass -g=dba >$folder.log
#if [ $? != 0 ]
#then
#       echo "Problem in uploader"
#        exit 1
#fi
wait
sleep 5
done
echo "Loading Finished...!!"
date
cd ..











done</user/cvprod/Asif/DFQ_Loading/DFQ_Loading/input.txt