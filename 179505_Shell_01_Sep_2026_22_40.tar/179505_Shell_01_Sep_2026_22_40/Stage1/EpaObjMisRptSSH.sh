#!/bin/sh
. /user/cvprod/.bash_profile

echo "Going to Call EpaObjMisRptTRL"

ssh cvprod@172.22.99.106 -n "cd /user/cvprod/shells/EpaObjMisRpt/Script; nohup sh ./EpaObjMisRptTRL.sh $1 $2 $3 $4 &"

echo "After Call EpaObjMisRptTRL"
