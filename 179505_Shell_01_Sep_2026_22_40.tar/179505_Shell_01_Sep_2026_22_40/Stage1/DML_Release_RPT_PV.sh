. /user/uaprodtrl/.bash_profile
$TC_ROOT/tcldPatch/tcPatchExecutable tm_DML_release_report
echo "Start==>Calling tm_DML_release_report from uaprod utility server---------->"
echo "Shell--DML_No= " $1
/user/uaprodtrl/Program_Shells/DML_DCR/tm_DML_release_report -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -DML_No=17PP092091
echo "End==>tm_DML_release_report from uaprod utility server---------->"

