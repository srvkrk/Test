#!/bin/ksh
. /user/omfprod/.bash_profile
echo  "---- Calling TCUA ITK for Part WEB SERVICE ----"
echo $*
#ssh bsd05818@172.22.97.12 -n "sh /user/rrr05503/Programs/PFIRST_TCE_TCUA_PART/QryPartDetailsInTCUA.sh $1 $2 $3"
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Program_Shells/QryPartDetailsInTCUA.sh $1 $2 $3"
if [ -s "/proj/PLMLoading/PFIRST_TCE_TCUA_PART/$1_TCUA_PARTDETAIL.txt" ]; then
lineCnt=`cat "/proj/PLMLoading/PFIRST_TCE_TCUA_PART/$1_TCUA_PARTDETAIL.txt" | wc -l`
if [ $lineCnt -gt 0 ]; then
mv /proj/PLMLoading/PFIRST_TCE_TCUA_PART/$1_TCUA_PARTDETAIL.txt /plmuv_logs/omfprod/logs/PFIRST_TCE_TCUA_PART/.
ls -ltr /plmuv_logs/omfprod/logs/PFIRST_TCE_TCUA_PART/$1_TCUA_PARTDETAIL.txt
fi
fi
