echo "-- Starting Task Reassign Shell-- "
echo "Shell--Task No= " $1
echo "Shell--User IDs= " $2
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Program_Shells/DML_DCR/ReassignTaskShell.sh $1 $2"
echo "--Complete Task Reassign Shell-- "
