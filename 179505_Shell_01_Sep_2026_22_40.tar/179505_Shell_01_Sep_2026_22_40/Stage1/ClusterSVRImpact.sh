. /user/uaprod/.bash_profile
#. /home/uadev/.bash_profile
b=`echo $1 | cut -d'_' -f1-2`
d=`grep 'Child SVR Name' $2 | cut -d'>' -f2`
grep $d $1 > /tmp/${d}.csv
chmod 755 /tmp/$d.csv
while read line
	do 
	sed -i "s/$line/^${line}/g" /tmp/$d.csv
done < $2
if [ ! -f ${b}_ImpactAnalysis.csv ]
	then 
	head -4 $1 > ${b}_ImpactAnalysis.csv
	cat /tmp/$d.csv >> ${b}_ImpactAnalysis.csv
	else
	cat /tmp/$d.csv >> ${b}_ImpactAnalysis.csv
fi

if [ $3 -eq $4 ]
 then
 g=`cat ${b}_ImpactAnalysis.csv | wc -l`
 h=3
 j=`expr $g - $h`
 head -3 ${b}_ImpactAnalysis.csv > /tmp/w.csv
 tail -${j} ${b}_ImpactAnalysis.csv > /tmp/v.csv
 awk '{for (i=1;i<=NF;i++)a[i,NR]=$i} END{for (i=1;i<=NF;i++) for (j=1;j<=NR;j++) printf "%s%s",a[i,j],(j==NR?ORS:OFS)}' /tmp/v.csv > /tmp/e.csv
 cat /tmp/w.csv /tmp/e.csv > /tmp/1.csv
 mv /tmp/1.csv ${b}_ImpactAnalysis.csv
 rm -f /tmp/1.csv /tmp/w.csv /tmp/e.csv /tmp/v.csv

 cp ${b}_ImpactAnalysis.csv ${b}_ImpactAnalysis.xlsx 
 java -jar Get_Cell_coloured.jar ${b}_ImpactAnalysis.xlsx
fi
