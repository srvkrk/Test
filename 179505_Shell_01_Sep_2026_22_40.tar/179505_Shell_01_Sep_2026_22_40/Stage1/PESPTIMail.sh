cat /tmp/PESPTIMail.cfg
/usr/sbin/sendmail -i -t </tmp/PESPTIMail.cfg
