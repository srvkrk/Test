/*=============================================================================
                Copyright (c) 2003-2005 UGS Corporation
                   Unpublished - All Rights Reserved
===============================================================================
File description:
    An example program to show listing a bill of materials using the BOM module
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <unidefs.h>
#include <itk/mem.h>
#include <tcinit/tcinit.h>
#include <tccore/item.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps_errors.h>
#include <tccore/item_errors.h>
#include <tc/emh.h>
#include <pie/pie.h>
#include <ae/dataset.h>
#include <tccore/tctype.h>
#define Debug TRUE
#define ITK_CALL(X)                                                     \
                if(Debug)                                                               \
                {                                                                               \
                        printf(#X);                                                     \
                }                                                                               \
                fflush(NULL);                                                   \
                status=X;                                                               \
                if (status != ITK_ok )                                  \
                {                                                                               \
                        int                             index = 0;                      \
                        int                             n_ifails = 0;           \
                        const int*              severities = 0;         \
                        const int*              ifails = 0;                     \
                        const char**    texts = NULL;           \
                                                                                                \
                        EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);               \
                        printf("\t%3d error(s)\n", n_ifails);                                                   \
                        for( index=0; index<n_ifails; index++)                                                  \
                        {                                                                                                                               \
                                printf("\tError #%d, %s\n", ifails[index], texts[index]);       \
                        }                                                                                                                               \
                        return status;                                                                                                  \
                }                                                                                                                                       \
                else                                                                    \
                {                                                                               \
                        if(Debug)                                                       \
                        printf("\tSUCCESS\n");                          \
                }

/* this sequence is so common */
#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}

static int name_attribute, seqno_attribute, parent_attribute, item_tag_attribute, qunt_attribute, refjt_attribute;

static void initialise (void);
static void initialise_attribute (char *name,  int *attribute);
static void print_bom (tag_t line, int depth);
static void print_average (tag_t top_line);
static void find_revision_count (tag_t line, int *count, int *total);
static void double_sequence_nos (tag_t line);
static int my_compare_function (tag_t line_1, tag_t line_2, void *client_data);

int total = 0;
/*-------------------------------------------------------------------------------*/


/* This program lists the bill under some given item (configuring it by latest+working).
   It then doubles all the sequence numbers,  and re-lists it by descending sequence number order.
   It then counts how many lines there are in the bill,  and the average number of revisions of
   the items in that bill.
   It never actually modifies the database.
   Run this program by:
    <program name> -u<user> -p<password>
*/

FILE *fpAssy=NULL;

extern int ITK_user_main (int argc, char ** argv )
  {
    int ifail;
    char *inputfile = NULL;
    char *req_item = NULL;
    char *req_key = NULL;
    char **rulename = NULL;
    char **rulevalue = NULL;
        int rulefound= 0;
   // char *closname = NULL;
    tag_t window, window2, rule, item_tag = null_tag, top_line,top_line1,close_tag ;
        tag_t *closurerule = NULL;
        //char   refname[AE_reference_size_c + 1];
                //char   pathname[SS_MAXPATHLEN + 1];
        //char   pathnamee[SS_MAXPATHLEN + 1];
        //char   orig_name[IMF_filename_size_c + 1];
    enum PIE_scope_e PIE_scope_t;
        logical shosup;
    (void)argc;
    (void)argv;

    initialise();

    req_item = ITK_ask_cli_argument("-i=");
    req_key = ITK_ask_cli_argument("-key=");

    if ( req_item && req_key )
    {
        printf("Cannot use both the \"-i\" and \"-key\" options on command line\n");
        exit(0);
    }
    else if ( !req_item && !req_key )
    {
        printf("Must supply the \"-i\" or \"-key\" option on command line\n");
        exit(0);
    }

        ifail = BOM_create_window (&window);
      //  CHECK_FAIL;
        ifail = CFM_find( "ERC Review And Above-CMS", &rule );
       // CHECK_FAIL;
        ifail = BOM_set_window_config_rule( window, rule );
       // CHECK_FAIL;
        //ifail = BOM_window_hide_suppressed( window);
        // CHECK_FAIL;
//      ifail = PIE_find_closure_rules( "BOMExpandSkipByPartSource",PIE_TEAMCENTER, &rulefound, &closurerule );
//      CHECK_FAIL;
//      printf ("rule count %d \n",rulefound);
//      if (rulefound > 0)
//      {
//              close_tag = closurerule[0];
//              printf ("closure rule found \n");
//              // MEM_free(tags_found);
//      }
//      ifail = BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue );
//      CHECK_FAIL;
//    ifail = BOM_set_window_pack_all (window, true);
//    CHECK_FAIL;

    if ( req_item )
    {
        tag_t *tags_found = NULL;
        int n_tags_found= 0;

        char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
        char **values = (char **) MEM_alloc(1 * sizeof(char *));

                //const char *attrs[2];
            //const char *values[2];

        attrs[0] ="item_id";
        values[0] = (char *)req_item;
        ifail = ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found);
        MEM_free(attrs);
        MEM_free(values);
        CHECK_FAIL;
        if (n_tags_found == 0)
        {
            printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", req_item);
            exit (0);
        }
        else if (n_tags_found > 1)
        {
            MEM_free(tags_found);
            EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
            printf ( "More than one items matched with id %s\n", req_item);
            exit (0);
        }
        item_tag = tags_found[0];

        MEM_free(tags_found);
    }

    else // req_key being used
    {
        {
            tag_t *tags_found = NULL;
            int n_tags_found = 0;
            ifail = ITEM_find_items_by_string(req_key, &n_tags_found, &tags_found);
            if (ifail == ITK_ok)
            {
                if (n_tags_found == 0)
                {
                    printf ("ITEM_find_items_by_string returns success,  but didn't find %s\n", req_key);
                    exit (0);
                }
                else if (n_tags_found > 1)
                {
                    MEM_free(tags_found);
                    EMH_store_initial_error(EMH_severity_error,ITEM_multiple_items_returned);
                    printf ( "More than one items matched with key %s\n", req_key);
                    exit (0);
                }
                else
                {
                    item_tag = tags_found[0];
                    MEM_free(tags_found);
                }
            }
        }
    }

    if (item_tag == null_tag)
    {
        printf ("ITEM_find_items_by_key_attributes returns success,  but didn't find %s\n", req_item);
        exit (0);
    }

    ifail = BOM_set_window_top_line (window, item_tag, null_tag, null_tag, &top_line);
    CHECK_FAIL;

        printf ("Before show suppressed. \n");
        ifail = BOM_window_show_suppressed ( window );
        CHECK_FAIL;
        printf ("After applying show suppressed. \n\n");

        inputfile =(char *) MEM_alloc(100);
        tc_strcpy(inputfile,req_item);
        tc_strcat(inputfile,"_");
        tc_strcat(inputfile,"AssemblyList.txt");
        fpAssy = fopen(inputfile,"w");
        if(fpAssy == NULL)
        {
                printf ("\n Could not open inputfile file : %s\n", inputfile); fflush(stdout);
                exit( EXIT_FAILURE );
        }

    print_bom (top_line, 0);

    double_sequence_nos (top_line);
    /* we won't go
        ifail = BOM_save_window (window);
       because that would modify the database,  and we are just playing here
    */

    /* now let's be silly and list the results sorted the other way */

    ifail = BOM_create_window (&window2);
    CHECK_FAIL;
    ifail = BOM_set_window_config_rule( window2, rule );
    CHECK_FAIL;

    ifail = BOM_set_window_pack_all (window2, false);    /* the default,  but let's be explicit */
    CHECK_FAIL;

    ifail = BOM_set_window_sort_compare_fn (window2, (void *)my_compare_function, NULL);
    CHECK_FAIL;

    ifail = BOM_set_window_top_line (window2, item_tag, null_tag, null_tag, &top_line1);
    CHECK_FAIL;

        ifail = BOM_window_show_suppressed ( window2 );
        CHECK_FAIL;
    printf ("\n================================================\n");
   // print_bom (top_line, 0);

    //print_average (top_line);

        printf ("lines in bill: %d \n\n",total);

        fclose(fpAssy);

    ITK_exit_module(true);

    return 0;
  }


/*-------------------------------------------------------------------------------*/


static void print_bom (tag_t line, int depth)
  {
    int ifail;
    char *name, *sequence_no, *quantity;
        tag_t item_tags;
        char *Item_id_par=NULL;
        char *Item_id_seq=NULL;
        char *Item_id_rev=NULL;
    tag_t *children;
        tag_t refjtname;
        int iChildItemTag;
    tag_t jtfile;
        int status;
    int cnt=0;
    int cnt1=0;
    int referencenumberfound=0;
    char *Item_id_par_des=NULL;
        char *vol_name=NULL;
        char *nod_name=NULL;
        char *word=NULL;
        char *refset_name=NULL;
    int i, n,j;
        int k = 0;
        logical  override;
        logical  override1 = false;
    tag_t item=NULLTAG;
        tag_t reva=NULLTAG;
        tag_t vol=NULLTAG;
        tag_t *tags_found = NULL;
        tag_t   t_ChildItemRev;
    int n_tags_found= 0;
        tag_t                   *attachments                                                            = NULLTAG;
        tag_t                   dataset                                                                         = NULLTAG;
        tag_t                   refobject                                                                               = NULLTAG;
        tag_t relation_type, relation;
        tag_t *         related_occs = NULLTAG;
        tag_t *         related_items =  NULLTAG;
    char **attrs = (char **) MEM_alloc(1 * sizeof(char *));
    char **values = (char **) MEM_alloc(1 * sizeof(char *));
        char   refname[AE_reference_size_c + 1];
        char   pathname[SS_MAXPATHLEN + 1];
        char   pathnamee[SS_MAXPATHLEN + 1];
        char   orig_name[IMF_filename_size_c + 1];
        AE_reference_type_t     reftype;

    depth ++;

        total ++;

    ifail = BOM_line_ask_attribute_string (line, name_attribute, &name);
    CHECK_FAIL;
    /* note that I know name is always defined,  but sometimes sequence number is unset.
       If that happens it returns NULL,  not an error.
    */
        ifail = BOM_line_ask_attribute_tag(line, item_tag_attribute,  &item_tags );
    CHECK_FAIL;

        //if( AOM_ask_value_string(refjtname,"item_id",&Item_id_par)!=ITK_ok);

    ifail = BOM_line_ask_attribute_string (line, seqno_attribute, &sequence_no);
    CHECK_FAIL;

          ifail = BOM_line_ask_attribute_string (line, qunt_attribute, &quantity);
    CHECK_FAIL;

         // ifail = BOM_line_ask_attribute_string (line, refjt_attribute, &refjtname);
    //CHECK_FAIL;

ifail = ITEM_ask_latest_rev(item_tags,&reva);
        CHECK_FAIL;
        if( AOM_ask_value_string(reva,"item_id",&Item_id_par)!=ITK_ok);
        if( AOM_ask_value_string(reva,"sequence_id",&Item_id_rev)!=ITK_ok);
        if( AOM_ask_value_string(reva,"item_revision_id",&Item_id_seq)!=ITK_ok);
        //printf("\n  Item ID is  ---->%s\n",Item_id_par);
        ifail = GRM_find_relation_type("IMAN_Rendering",&relation_type);
        CHECK_FAIL;
        if(relation_type != NULLTAG)
        {
                ifail = GRM_list_secondary_objects_only(reva,relation_type,&cnt,&attachments);
                CHECK_FAIL;
                //printf("\nTotal n attches =%d\n",cnt);
      if (cnt>0)
                {
                for(j=0;j<1;j++)
                {
                        //printf("\nin checkin for loop\n");fflush(stdout);
                        dataset = attachments[j];

                        if(AE_ask_dataset_ref_count(dataset,&referencenumberfound));
                        if( AOM_ask_value_string(dataset,"object_name",&word)!=ITK_ok);
                        for(k=0;k<referencenumberfound;k++)
                        {

                                ifail = AE_find_dataset_named_ref(dataset,k,refname,&reftype,&refobject);
                                CHECK_FAIL;
                                // printf("\n named ref. =%d\n",refname);

                                ifail =  IMF_ask_original_file_name(refobject,orig_name);
                            //    ifail =  IMF_ask_file_pathname(refobject,2,pathnamee);
                             //   ifail =  IMF_ask_volume(refobject,&vol);
                               // if( AOM_ask_value_string(vol,"volume_name",&vol_name)!=ITK_ok);
                              //  CHECK_FAIL;
                              ////  if( AOM_ask_value_string(vol,"node_name",&nod_name)!=ITK_ok);
                            //    CHECK_FAIL;

                        //      printf("\n orig_name is :%s\n",orig_name);
                        ////    printf("\n pathnamee is :%s\n",pathnamee);
                        //      printf("\n pathnamee is :%s\n",vol_name);
                                //fprintf(fdf,"%s,%s,%s,%s\n",orig_name,pathnamee,nod_name,vol_name);fflush(stdout);
                                 printf ("%3d", depth);
                                 for (i = 0; i < depth; i++)
                                 printf ("  ");
                                 printf ("%s/%s,%s,%s \n", Item_id_par,Item_id_seq,quantity,orig_name);
                                                                 cnt1 ++;

    //printf ("%-20s \n", name);
                        }
                }

                }
                                else
                        {
                                printf ("%3d", depth);
                                for (i = 0; i < depth; i++)
                printf ("  ");
                printf ("%s/%s,%s \n", Item_id_par,Item_id_seq,quantity);
                        }
        }
        //bhaskar ends
        else
          {
        //BOM_line_list_related_substitutes(line, &k, &related_occs, &related_items);
        //BOM_line_ask_absocc_relation ( line, NULLTAG, "IMAN_specification", TRUE, &k, &related_items);

        //printf("\nfdsadsfadsfsdfsadfsadf :%d\n",k);
        for(j=0;j<1;j++)
        {
                dataset = NULLTAG;
                //printf("\nin checkin for loop\n");fflush(stdout);
                //dataset = attachments[j];
                GRM_ask_secondary (related_items[j], &dataset);

                if(AE_ask_dataset_ref_count(dataset,&referencenumberfound));
                //printf("\nDataset Reference Count %d\n", referencenumberfound);
                for(k=0;k<referencenumberfound;k++)
                {
                        ifail = AE_find_dataset_named_ref(dataset,k,refname,&reftype,&refobject);
                        CHECK_FAIL;
                        // printf("\n named ref. =%d\n",refname);

                        ifail =  IMF_ask_original_file_name(refobject,orig_name);
                      //  ifail =  IMF_ask_file_pathname(refobject,2,pathnamee);
                      //  ifail =  IMF_ask_volume(refobject,&vol);
                      //  if( AOM_ask_value_string(vol,"volume_name",&vol_name)!=ITK_ok);
                     //   CHECK_FAIL;
                    //    if( AOM_ask_value_string(vol,"node_name",&nod_name)!=ITK_ok);
                    //    CHECK_FAIL;

                        //printf("\n 11..orig_name is :%s\n",orig_name);
                       // printf("\n 11..pathnamee is :%s\n",pathnamee);
                       // printf("\n 11..pathnamee is :%s\n",vol_name);
                        //fprintf(fdf,"%s,%s,%s,%s\n",orig_name,pathnamee,nod_name,vol_name);fflush(stdout);
                    printf ("%3d", depth);
                        for (i = 0; i < depth; i++)
                        printf ("  ");
        printf ("%s/%s,%s,%s \n", Item_id_par,Item_id_seq,quantity,orig_name);


        cnt1 ++;
                }
        }

          }

        //printf ("cnt is %d\n", cnt1);
     if(cnt1 == 0)
     {

         printf ("%3d", depth);
    for (i = 0; i < depth; i++)
                printf ("  ");
                printf ("%s/%s,%s \n", Item_id_par,Item_id_seq,quantity);
    }
     // printf ("%s \n",quantity);


                        fprintf(fpAssy,"%s\n",Item_id_par);
    ifail = BOM_line_ask_child_lines (line, &n, &children);
        printf ("\n BOM_line_ask_child_lines :::>> %d",n);
    CHECK_FAIL;

        if (n > 0)
        {
                //fprintf(fpAssy,"%s\n",Item_id_par);
                for (i = 0; i < n; i++)
                {
                        print_bom (children[i], depth);
                        //fprintf(fpAssy,"%d\n",i);
                }
        }


    MEM_free (children);
    MEM_free (name);
    MEM_free (sequence_no);
    MEM_free (quantity);
    //MEM_free (orig_name);
  }


/*-------------------------------------------------------------------------------*/

static void double_sequence_nos (tag_t line)
{
    /* just to demonstrate modifying the bill */

    int ifail;
    char *sequence_no;
    int i, n;
    tag_t *children;

    ifail = BOM_line_ask_attribute_string (line, seqno_attribute, &sequence_no);
    CHECK_FAIL;
    /* Top bom lines have no sequence number, and others may also not */
    if (sequence_no[0] != '\0')
    {
        char buffer[100];
        sprintf (buffer, "%d", 2 * atoi (sequence_no));
        ifail = BOM_line_set_attribute_string (line, seqno_attribute, buffer);
        if (ifail != ITK_ok)
        {
            char *child_name;
            ifail = BOM_line_ask_attribute_string (line, name_attribute, &child_name);
            CHECK_FAIL;
            printf ("==> No write access to %s\n", child_name);
            MEM_free (child_name);
        }
        else
        {
            CHECK_FAIL;
        }
        MEM_free (sequence_no);
    }

    ifail = BOM_line_ask_child_lines (line, &n, &children);
    CHECK_FAIL;
    for (i = 0; i < n; i++)
        double_sequence_nos (children[i]);

    MEM_free (children);
}


/*-------------------------------------------------------------------------------*/


static void print_average (tag_t top_line)
{
    int count = 0, total = 0;
    find_revision_count (top_line, &count, &total);
    if (count <= 0)
    {
        printf ("impossible error has happened!\n");
    }
    else
    {
        printf ("lines in bill : %d\naverage revisions of each item : %d\n", count, total / count);
    }
}


/*-------------------------------------------------------------------------------*/


static void find_revision_count (tag_t line, int *count, int *total)
{
    /* a function to demonstrate going from BOM tags to other IMAN classes                      */
    /* in this case we get the Item tag for the BOM line,  and then use it for an ITEM call     */
    /* for a complete list of standard attributes see bom_attr.h,  or use a BOM_list_attributes */
    /* call to find all current attributes (new note types define new attributes)               */

    int ifail;
    tag_t item_tag, *revisions, *children;
    int i, n, revision_count=0;
        char *name= NULL;

        ifail = BOM_line_ask_attribute_string (line, name_attribute, &name);
    CHECK_FAIL;

    ifail = BOM_line_ask_attribute_tag(line, item_tag_attribute,  &item_tag );
    CHECK_FAIL;
    /* the simplist example call I can think of:  count how many revisions of this Item there are */
    ifail = ITEM_list_all_revs (item_tag, &revision_count, &revisions);
    printf ("revision_count: %d    name: %s \n", revision_count,name);
        CHECK_FAIL;
    MEM_free (revisions);
    (*count)++;
    (*total) += revision_count;

    ifail = BOM_line_ask_child_lines (line, &n, &children);
    CHECK_FAIL;
    for (i = 0; i < n; i++)
    {
                find_revision_count (children[i], count, total);
        }

    MEM_free (children);
}


/*-------------------------------------------------------------------------------*/


static int my_compare_function (tag_t line_1, tag_t line_2, void * client_data)
  {
    /* returns strcmp style -1/0/+1 according to whether line_1 and line_2 sort <, = or > */
    char *seq1, *seq2;
    int ifail, result;
    (void)client_data;
    ifail = BOM_line_ask_attribute_string (line_1, seqno_attribute, &seq1);
    CHECK_FAIL;
    ifail = BOM_line_ask_attribute_string (line_2, seqno_attribute, &seq2);
    CHECK_FAIL;
    if (seq1 == NULL || seq2 == NULL)
      result = 0;
    else
      result = strcmp (seq2, seq1);  /* we are being silly and doing a reverse sort */
    /* note:  the default sort function compares Item names if the sequence numbers sort equal
       but this is just an example for fun,  so we won't bother with that bit
    */
    MEM_free (seq1);
    MEM_free (seq2);
    return result;
  }


/*-------------------------------------------------------------------------------*/


static void initialise (void)
  {
    int ifail;

    /* <kc> pr#397778 July2595 exit if autologin() fail */
    if ((ifail = ITK_auto_login()) != ITK_ok)
       fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);
    CHECK_FAIL;

    /* these tokens come from bom_attr.h */
    initialise_attribute (bomAttr_lineName, &name_attribute);
    initialise_attribute (bomAttr_occSeqNo, &seqno_attribute);
    initialise_attribute (bomAttr_occQty, &qunt_attribute);
    //initialise_attribute (bomAttr_JTDatasetTag , &refjt_attribute);
    ifail = BOM_line_look_up_attribute (bomAttr_lineParentTag, &parent_attribute);
    CHECK_FAIL;
    ifail = BOM_line_look_up_attribute (bomAttr_lineItemTag, &item_tag_attribute);
    CHECK_FAIL;
        ifail = BOM_line_look_up_attribute (bomAttr_JTDatasetTag, &refjt_attribute);
    CHECK_FAIL;
  }


/*-------------------------------------------------------------------------------*/


static void initialise_attribute (char *name,  int *attribute)
  {
    int ifail, mode;

    ifail = BOM_line_look_up_attribute (name, attribute);
    CHECK_FAIL;
    ifail = BOM_line_ask_attribute_mode (*attribute, &mode);
    CHECK_FAIL;
    if (mode != BOM_attribute_mode_string)
      { printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode);
        exit(0);
      }
  }

