. /user/cvprod/.bash_profile
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Program_Shells/DML_DCR/$1 $2 $3 $4 $5"
echo "--Complete GenericDml_2c9.sh from cvprod-- "

