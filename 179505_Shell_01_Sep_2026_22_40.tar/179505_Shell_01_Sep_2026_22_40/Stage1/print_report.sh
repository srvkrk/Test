. /user/cvprod/.bash_profile
echo "Shell Start for Print  letter report CVPROD"
echo $1
cd /user/cvprod/Program_Shells/DML_Support/Print_Report_Release_letter_report_cron/printRel
echo "To patch Print report exe"
# /home/cvprod/SLES15_patch/tcldPatch/tcPatchExecutable tm_ERC_DML_Print_Report
./tm_ERC_DML_Print_Report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -DML_No=$1
echo " *****  after Run Print report exe ...... "
echo " *****  Shell Execution completed ...... "