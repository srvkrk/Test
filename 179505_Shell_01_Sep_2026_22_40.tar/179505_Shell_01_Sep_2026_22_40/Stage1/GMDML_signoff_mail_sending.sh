#!/bin/ksh
. /user/cvprod/.bash_profile
echo "-----Start shell calling GMDML_signoff_mail_sending-----"

attachment_file="$1"
recipient="$2"
recipient_email_cc="$3"
subject="GMDML auto signoff status Report."
 
# Check if the attachment file exists
if [ ! -f "$1" ]; then
    echo "Error: Attachment file not found: $attachment_file"
    exit 1
fi
echo "Sending mail to: $2"
#echo "Adding CC users: $3"
#echo "$cat$3"
#cc_list="$cat$3"
#echo "1. Email sent to CC list: $cc_list"

# Send the email with attachment
mail -s "$subject" -a "$attachment_file" -c "$recipient_email_cc" "$recipient"<<EOF
Dear All,

      Kindly refer attached excel file for GMDML auto signoff Status Report.

Best regards,
PLM Team
EOF