#!/bin/bash

########## Changing directory to CATIAOWN #####
cd /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/ 

filenameProcessLog='CATIMigCVPROD_DownUpJob_RS_ModUpd.csv'
filenamePrtList='InpCV.txt'

if [ ! -f $filenamePrtList ]; then
        echo "Part List file not found"
        exit 1
fi

while read PartNmCnt; do
total_incount=$((total_incount+1))
echo "Part $total_incount : $PartNmCnt"
done < $filenamePrtList

echo "Total Count of input Parts : $total_incount"

line_no=1
while read PartNm; do
echo "Part No. $line_no : $PartNm"
start_time=$(date +%s)

if [ ${#PartNm} -lt 2 ]; then
        echo "Part Number Blank"
        continue
fi

#Old Data Delete Start
date
now="$(date +'%d/%m/%Y %H:%M:%S')"
Day=`echo  $now | cut -d\/ -f1`
Mon=`echo  $now | cut -d\/ -f2`
YearS=`echo  $now | cut -d\/ -f3`
Year=`echo  $YearS | cut -d' ' -f1`
timeSt=`echo  $now | cut -d' ' -f2`
hourS=`echo  $timeSt | cut -d':' -f1`
minS=`echo  $timeSt | cut -d':' -f2`
secS=`echo  $timeSt | cut -d':' -f3`
LogFileNm="$PartNm"_CV_DOWN_"$Year""$Mon""$Day"_"$hourS""$minS""$secS".log
echo "Log - $LogFileNm"

tmpLogWrt="$line_no","$PartNm","$Year"/"$Mon"/"$Day","$hourS":"$minS":"$secS"

#Download Start
DownLogFileNm=/user/omfprod/shells/TASL_Downloading/TMETC_LATEST/"$LogFileNm"
echo $DownLogFileNm

download_start_time=$(date)
echo "[$line_no/$total_incount] RAJAN: DOWNLOAD-START for Part : $PartNm Start-Time: $download_start_time"
echo "Calling Downloading Shell Starting"

/user/omfprod/shells/TASL_Downloading/TMETC_LATEST/MainCVProdInput_DOWNLOAD_RS_20220618.sh $PartNm > $DownLogFileNm


date
now="$(date +'%d/%m/%Y %H:%M:%S')"
Day=`echo  $now | cut -d\/ -f1`
Mon=`echo  $now | cut -d\/ -f2`
YearS=`echo  $now | cut -d\/ -f3`
Year=`echo  $YearS | cut -d' ' -f1`
timeSt=`echo  $now | cut -d' ' -f2`
hourS=`echo  $timeSt | cut -d':' -f1`
minS=`echo  $timeSt | cut -d':' -f2`
secS=`echo  $timeSt | cut -d':' -f3`

end_time_download=$(date +%s)
elapsed=$(( end_time_download - start_time ))
time_taken=`echo $(date -ud "@$elapsed" +'%H hr %M min %S sec')`
tmpLogWrt="$tmpLogWrt","$LogFileNm","$Year"/"$Mon"/"$Day","$hourS":"$minS":"$secS","$time_taken"

download_end_time=$(date)
echo "[$line_no/$total_incount] RAJAN: DOWNLOAD-END for Part : $PartNm End-Time: $download_end_time Time-Taken: $time_taken"

echo "Download completed, Sleeping for 5 secs...Pls wait !"
#sleep 2 
echo "Download shell execution finish for part no : $PartNm"
echo "Logfile Name : $LogFileNm"
echo "Moving all .log, .csv and .txt files to directory $PartNm_CV"

#if [ -d "$PartNm"_CV ]; then
#mv *$PartNm*log "$PartNm"_CV
#mv *$PartNm*csv "$PartNm"_CV
#mv *$PartNm*txt "$PartNm"_CV
#else
#echo "Downloaded directory not found, hence not moving all log,csv,txt files"
#fi

#Dowanlod End

#Upload Start
upload_start_time=$(date)

echo "[$line_no/$total_incount] RAJAN: UPLOAD-START for Part : $PartNm Start-Time: $upload_start_time"
echo "Upload Start for part no : $PartNm"
PartDirNm="$PartNm"_CV
LogFileNm="$PartNm"_CV_UP_"$Year""$Mon""$Day"_"$hourS""$minS""$secS".log
UploadLogFileNm=/user/omfprod/shells/TASL_Downloading/TMETC_LATEST/"$LogFileNm"
echo $UploadLogFileNm

#nohup /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/MainCVProdInput_UPLOAD_Ujj_New_1.sh  $PartNm > $UploadLogFileNm&
/user/omfprod/shells/TASL_Downloading/TMETC_LATEST/MainCVProdInput_UPLOAD_Ujj_New_RS.sh  $PartNm > $UploadLogFileNm

sleep 10 
echo "Upload End for part no : $PartNm"

date
now="$(date +'%d/%m/%Y %H:%M:%S')"
Day=`echo  $now | cut -d\/ -f1`
Mon=`echo  $now | cut -d\/ -f2`
YearS=`echo  $now | cut -d\/ -f3`
Year=`echo  $YearS | cut -d' ' -f1`
timeSt=`echo  $now | cut -d' ' -f2`
hourS=`echo  $timeSt | cut -d':' -f1`
minS=`echo  $timeSt | cut -d':' -f2`
secS=`echo  $timeSt | cut -d':' -f3`

end_time=$(date +%s)
elapsed=$(( end_time - end_time_download ))
time_taken=`echo $(date -ud "@$elapsed" +'%H hr %M min %S sec')`
tmpLogWrt="$tmpLogWrt","$LogFileNm","$Year"/"$Mon"/"$Day","$hourS":"$minS":"$secS","$time_taken"

elapsed=$(( end_time - start_time ))
time_taken=`echo $(date -ud "@$elapsed" +'%H hr %M min %S sec')`
tmpLogWrt="$tmpLogWrt","$time_taken"

echo $tmpLogWrt >> /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/$filenameProcessLog
sleep 2

upload_end_time=$(date)
echo "[$line_no/$total_incount] RAJAN: UPLOAD-END (In NOHUP) for Part : $PartNm End-Time: $upload_end_time Time-Taken: $time_taken"
echo "Upload completed, Pls wait !"
#Upload End

## Section to Update Module Details.
#ModUpdInFile=MOD_UPD_INFILE_"$Year""$Mon""$Day"_"$hourS""$minS""$secS".txt
#echo "$PartNm~" >> /proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/$ModUpdInFile
#cd /proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/
#down_upload.sh $ModUpdInFile
#echo "$PartNm~" >> /proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/CATIA_MOD_UPD_IN_FOR_AWC_TRK.txt
#rm -rf $ModUpdInFile
#echo "FINISHED Module-Update for $ModUpdInFile"


line_no=$((line_no+1))
done < $filenamePrtList


if [ $line_no -gt 1 ]; then
	filenamePrtListN="$filenamePrtList"_"$Year""$Mon""$Day"_"$hourS""$minS""$secS"
	mv /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/$filenamePrtList /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/$filenamePrtListN
	touch /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/$filenamePrtList
fi

echo "FINSHED..........SHELL PROCESSiNG....!!!"
