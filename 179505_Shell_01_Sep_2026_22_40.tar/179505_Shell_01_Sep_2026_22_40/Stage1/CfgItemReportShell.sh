echo "****************************** CFG ITEM REPORT SHELL STARTED ********************************* "
echo $1
echo $2
cd /user/testcmi/Dev/devgroups/Aditya_Khandelwal/CfgItemReports
echo $(date) >> CfgShellLogs.txt
echo $1 >> CfgShellLogs.txt
echo $2 >> CfgShellLogs.txt
subString=$2
subStr=${subString:0:3}
echo $subStr
$TC_ROOT/tcldPatch/tcPatchExecutable CfgItemReports.exe
if [[ "$subStr" == "RE1" ]];
then
	echo " ********************** Executing RE1**************************** "
	./CfgItemReports.exe -u="infodba" -pf="/home/cmitest/shells/Admin/infodbapawwdfile.pwf" -g="dba" -i=$1 -j=$2 > ConsoleLogExe1.txt
else
	./CfgCmpVariants.exe -u="infodba" -pf="/home/cmitest/shells/Admin/infodbapawwdfile.pwf" -g="dba" -i=$1 -j=$2 > ConsoleLogExe2.txt
	echo " ********************** Executing RE2**************************** "
fi    	
echo "****************************** CFG ITEM REPORTS SHELL ENDED  *********************************** "

