. /user/omfprod/.bash_profile

rm -f NewdownRAC.txt
echo "Direct...User Id...$1"
userId=$1

while read line
do
echo $line
sqlplus -s supprod/pcolour << !
set linesize 80
set pagesize 0
set head off
set verify off
set term off
spool DownloadRAC.txt
select partnumber||' '||revision||' '||sequence from assembly where partnumber='$line' and superseded='-' union
select partnumber||' '||revision||' '||sequence from cmponent where partnumber='$line' and superseded='-' union
select partnumber||' '||revision||' '||sequence from t5grpid where partnumber='$line' and superseded='-' union
select partnumber||' '||revision||' '||sequence from t5eeasm where partnumber='$line' and superseded='-' union
select partnumber||' '||revision||' '||sequence from assembly@suhprod where partnumber='$line' and superseded='-' union
select partnumber||' '||revision||' '||sequence from t5grpid@suhprod where partnumber='$line' and superseded='-' union
select partnumber||' '||revision||' '||sequence from cmponent@suhprod where partnumber='$line' and superseded='-' union
select partnumber||' '||revision||' '||sequence from t5eeasm@suhprod where partnumber='$line' and superseded='-';
!
cat DownloadRAC.txt >> downRAC.txt
done < partInp.txt
sort -u downRAC.txt > NewdownRAC.txt
awk '{$2=$2};1' NewdownRAC.txt > NewdownRAC.txt1
awk 'NF' NewdownRAC.txt1 > NewdownRAC.txt2
mv NewdownRAC.txt2 NewdownRAC.txt
rm -f downRAC.txt DownloadRAC.txt NewdownRAC.txt1
while read line
do
./directmap.sh $line
done < NewdownRAC.txt
while read line
do
SC=`echo $line | tr -dc '_' | wc -c`
a=`echo $line | cut -d' ' -f1`
b=`echo $line | cut -d' ' -f2`
c=`echo $line | cut -d' ' -f3`
if [ $SC == 0 ] ; then

./newfilecreationTrl.sh ${a}_${b}_${c} loader abc

scp -r ${a}_${b}_${c} uaprodtrl@172.22.97.18:/user/uaprodtrl/Rajan/Catia_Uaprod_Mig/
ssh root@172.22.97.18 -n "chown -R uaprodtrl:plm /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/${a}_${b}_${c}"
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/WithoutFilecretionTrl.sh ${a}_${b}_${c} loader /user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf"

elif [ $SC == 1 ] ; then
./newfilecreation.sh_withunderscore ${a}_${b}_${c} loader abc

mv ${a}_${b}_${c} /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/.

ssh root@172.22.97.18 -n "chown -R uaprodtrl:plm /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/${a}_${b}_${c}"
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/WithoutFilecretionforunderscore.sh ${a}_${b}_${c} loader /user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf"

else
./newfilecreation.sh_withunderscoret ${a}_${b}_${c} loader abc
mv ${a}_${b}_${c} /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/.

ssh root@172.22.97.18 -n "chown -R bsd05818:plm /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/${a}_${b}_${c}"
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/WithoutFilecretionforunderscoret.sh ${a}_${b}_${c} loader /user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf"

fi

#ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/UpdRelStatusEffDateFrmDR_1st/UpdRelStatusEffDateFrmDR -u=loader -pf=/user/uaprodtrl/shell    s/Admin/loaderpasswdFile.pwf -g=dba -i=${a}"

#ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/UpdRelStatusEffDateFrmDR_2nd/UpdRelStatusEffDateFrmDR -u=loader -pf=/user/uaprod/shell    s/Admin/loaderpasswdFile.pwf -g=dba -i=${a}"

echo "rm -rf ${a}_${b}_${c}" >> clean_catia_pv_data_FOR_RACdownload.sh

./sendMail.sh ${userId} ${a}

done < NewdownRAC.txt
echo "Testing RAJAN End"
echo "******************SHELL FINISHED**************FROM RAC OPTION*******************"
