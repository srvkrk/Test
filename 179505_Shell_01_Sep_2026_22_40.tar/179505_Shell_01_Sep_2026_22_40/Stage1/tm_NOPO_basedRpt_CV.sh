. /user/cvprod/.bash_profile
/user/cvprod/TC_ROOT12/tcldPatch/tcPatchExecutable tm_DML_Part_NOPOReport
echo "Start==>Calling NOPO part based report from CVPROD utility server---------->"
echo "Shell--DMLNo.= " $1
/user/cvprod/Program_Shells/DML_DCR/tm_DML_Part_NOPOReport -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$1 -I2=$2
echo "End==>NOPO NOPO part based report from CVPROD utility server---------->"
