echo  $1

ssh cvprod@172.22.99.106 "/user/cvprod/NON_ERC_PUNE/kafka/IPMSIQMSTransfer/kafka.sh '"$1"'"
 
echo "End kafka.sh"