. /user/uaprodtrl/.bash_profile
echo "Start==>Calling NOPO part based report from uaprodtrl---------->"
/user/uaprodtrl/Program_Shells/DML_DCR/tm_DML_Part_NOPOReport -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -g=dba -I1=$1 -I2=$2
echo "End==>NOPO part based report from uaprodtrl---------->"


