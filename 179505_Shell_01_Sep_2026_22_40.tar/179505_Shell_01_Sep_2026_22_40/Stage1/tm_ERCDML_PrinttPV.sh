. /user/uaprodtrl/.bash_profile
/user/uaprodtrl/TC_ROOT12/tcldPatch/tcPatchExecutable tm_ERC_DML_Print_Report
echo "Start==>Calling DML tm_ERC_DML_Print_Report from uaprodtrl---------->"
echo "Shell--DMLNo.= " $1
/user/uaprodtrl/Program_Shells/DML_DCR/tm_ERC_DML_Print_Report -DML_No=$1 -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -g=dba
echo "End==>DML tm_ERC_DML_Print_Report from uaprodtrl---------->"
