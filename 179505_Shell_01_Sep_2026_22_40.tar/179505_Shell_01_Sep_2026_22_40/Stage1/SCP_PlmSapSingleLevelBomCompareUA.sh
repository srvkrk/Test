. /user/cvprod/.bash_profile

cd /user/cvprod/shells/Akhilesh/PLMSAPBOMRpt/

echo "Connecting to cmitest for exe"
scp testcmi@172.22.97.28:/user/testcmi/Dev/devgroups/Akhilesh/PLMSAPBOMCompareCVProd/PlmSapSingleLevelBomCompareUA .

PROCESS_NUM=$(ps -ef | grep "PlmSapSingleLevelBomCompareUA" | grep -v sh|grep -v "grep" | wc -l)
echo \$PROCESS_NUM= $PROCESS_NUM
if [ $PROCESS_NUM -eq 0 ]; then

echo "All clear so we can proceed to run and here we go"

./PlmSapSingleLevelBomCompareUA

echo "Successfully executed the PLMSAP BOM Compare file"

