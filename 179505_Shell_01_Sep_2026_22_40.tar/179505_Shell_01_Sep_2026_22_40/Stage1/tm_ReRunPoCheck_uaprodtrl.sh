. /user/uaprodtrl/.bash_profile
echo "Start==>Calling DML tm_ReRunPoCheck from uaprodtrl------------>"
echo "Shell--DMLNo.=> " $1
/user/uaprodtrl/Program_Shells/DML_DCR/tm_POCheckReRun -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -taskno=$1
echo "End==>DML tm_ReRunPoCheck from uaprodtrl------------>"