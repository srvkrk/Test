. /user/uaprodtrl/.bash_profile
/user/uaprodtrl/TC_ROOT12/tcldPatch/tcPatchExecutable tm_Part_to_GM_DML_FileName
echo "Start==>Calling NOPO part based report from uaprod utility server---------->"
echo "Shell--partlist.= " $1
echo "Shell--username.= " $2
/user/uaprodtrl/Program_Shells/DML_DCR/tm_Part_to_GM_DML_FileName -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$1 -I2=$2
echo "End==>NOPO NOPO part based report from uaprod utility server---------->"


