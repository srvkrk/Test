
#!/bin/sh

#. /user/cvprod/.bash_profile

echo  $1

cd /home/cmitest/shells/APL/Prince/APLReleaseDate/

./updateDate -u=aplplanner -p=XYT1ESA -g=APL_Support_Group -dml=$1

echo $"EXE Calling Successfull"