#copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author                : Bhaskar/Upendra (Modified by Mohammad Asif for DFQ/DVA Migration)
# Created on            :  April 2017
# Project               : Teamcenter 10.1 TML
# Modified by           : Kalpesh Gondhali(05-Dec-2019)
# Modified by           : Mohammad Asif(25-Mar-2023)
#######################################################################################
#!/bin/sh
. /user/uaprodtrl/.bash_profile
while read i
do
	 ShDocNumber=`echo "$i"|cut -d ',' -f 1`
	  echo -e "TCDocNumber \t\t = $ShDocNumber"

	   echo  "$ShDocNumber"
user=loader
pass=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf
folder=$ShDocNumber
echo $folder
pwd
cd /user/uaprodtrl/Anvesh/DVA_Migration/$folder

splitfiles=`ls $folder.txt`
echo $splitfiles
for flist in $splitfiles
do
echo "Importing Data From TCE to UAPROD.............!! $flist"
/user/uaprodtrl/Anvesh/DVA_Migration/uploader -i=$flist -u=$user -pf=$pass -g=dba >$folder.log
#if [ $? != 0 ]
#then
#       echo "Problem in uploader"
#        exit 1
#fi
wait
sleep 5
done
echo "Loading Finished...!!"
date
cd ..











done</user/uaprodtrl/Anvesh/DVA_Migration/input.txt
