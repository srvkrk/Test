#!/bin/sh
##################################### This shell in on Main server called shells on utility server ##################################### 
. /user/cvprod/.bash_profile
echo "uaprod CCPLMToProNext_RFI_TRANS to call shell from cvprod"
echo ${1}
echo ${2}
echo ${3}
echo ${4}

ssh cvprod@172.22.99.106 -n "/user/cvprod/PLMSAP/liveXfr/CCPLMToProNext_RFI_TRANS.sh '$1' '$2' '$3' '$4'"
echo "---Completed RFI SOR transfer to Pronext.---"