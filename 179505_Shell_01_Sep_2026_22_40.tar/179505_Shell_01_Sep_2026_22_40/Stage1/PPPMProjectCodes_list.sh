#!/bin/sh
. /user/uaprod/.bash_profile
echo "uaprod pppmproject code to call shell from uaprodtrl"
echo ${1}
echo ${2}
echo ${3}
echo ${4}

ssh uaprodtrl@172.22.97.18 -n "/user/uaprodtrl/PLMSAP/liveXfr/PPPMProjectCodes_list.sh '$1' '$2' '$3' '$4'"
echo "---Completed.---"
