######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author		  : Dayanand Amdapure
# Created on	  : Dec 08, 2018
# Project         : TATA MOTORS PLM
#
#######################################################################################

Plant=$1
Project=$2
UnderScore='_';

echo "$Plant"
echo "$Project"
echo "$UnderScore"
echo $Plant$UnderScore$Project

echo "Create Directory"
mkdir  $Plant$UnderScore$Project
cp  EPADownload_TCE $Plant$UnderScore$Project
cd $Plant$UnderScore$Project

echo "Downloading EPA In TCE"
EPADownload_TCE $Plant $Project
if [ $? != 0 ]
then
	echo "Problem in EPADownload_TCE Download"
	exit 1
fi
rm -rf EPADownload_TCE
echo "EPA Ceration completed In TCUA"
