. /user/uaprodtrl/.bash_profile
nohup ./tm_dcr_weeklyEscaln_mail -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba > test.log &
echo "______________Report Fired Sucessfully________________"
