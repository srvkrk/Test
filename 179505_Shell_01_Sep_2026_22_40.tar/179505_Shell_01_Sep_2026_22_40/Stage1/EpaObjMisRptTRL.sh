#!/bin/sh
. /user/cvprod/.bash_profile
echo "Going to Call tm_EPAObjMisDetRepC Report"

cd /user/cvprod/shells/EpaObjMisRpt/EXE/

./tm_EPAObjMisDetRepC -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -f=$1 -t=$2 -pt=$3 -PlmId=$4 >tm_EPAObjMisDetRepC.log&

echo "After Call tm_EPAObjMisDetRepC Report"
