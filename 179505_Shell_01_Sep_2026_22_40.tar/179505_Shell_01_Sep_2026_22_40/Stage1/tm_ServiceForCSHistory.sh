echo  $1
echo  $2
echo  $3
echo  $4

cd /home/cmitest/shells/APL/CSHistoryService/

./ServiceForCSHistoryCC -u=aplplanner -p=XYT1ESA -g=dba $1 $2 $3 $4

echo $"EXE Calling Successfull"