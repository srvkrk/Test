. /user/cvprod/.bash_profile
echo "Start==>Calling tm_Part_Validation_Report_cvprod utility from cvprodtrl---------->"
echo "Shell--DMLNo.=> " $1
/user/cvprod/Program_Shells/DML_DCR/tm_Part_Validation_Report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -taskno=$1
echo "End==>DML tm_Part_Validation_Report_cvprod utility from cvprodtrl----------"
