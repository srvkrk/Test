#/user/testcmi/shells/RBQU_DML/tm_RBQU_DML_Function -u=ercpsup -p=XYT1ESA -d=$1
/user/uaprod/shells/RBQU_DML/tm_RBQU_DML_Function -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -d=$1
