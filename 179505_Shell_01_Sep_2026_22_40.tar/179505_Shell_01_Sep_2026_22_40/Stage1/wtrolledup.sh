. /user/bsd05818/.bash_profile
echo "In Shell wtrolledup.sh start ...$1  $2 $3"
/user/uaprod/shells/WEIGHT_ROLLEDUP/WeightRollUpITK -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="$1" -j="$2" -k="$3"
echo "END--Rolled-Up weight is successfully Updated for assembly  $1"
