#!/bin/sh
. /user/uaprodtrl/.bash_profile

/user/uaprodtrl/Asif/UserNotFound


scp /user/uaprodtrl/Asif/UserInformation.csv omfprod@172.22.97.8:/user/omfprod/devgroups/Asif/IsInGrpUser/DiffUser/UserExistInCV.csv