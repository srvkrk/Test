cat /tmp/PESPTIMail_ALL.cfg
/usr/sbin/sendmail -i -t </tmp/PESPTIMail_ALL.cfg