. /user/uaprod/.bash_profile
echo "In Shell downloadCompCodesFrmSVRAndPlatform.sh start ...$1 $2 $3 $4 $5 $6 $7"
#cd /user/uaprod/shells/ColorModule/
cd /tmp/
#/user/bsd05818/Ashish/GetCompCodeOfPltfrm/tm_GetCompCodesFrmSVRAndPlatform -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="$1" -j="$2" -k="$3" -s="$4" -lvl=50
/user/uaprod/shells/ColorModule/tm_GetCompCodesFrmSVRAndPlatform -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="$1" -j="$2" -k="$3" -s="$4" -lvl=50
#/user/cmitest/shells/ColorModule/tm_GetCompCodesFrmSVRAndPlatform -u=loader -pf=/user/cmitest/shells/Admin/loaderpwffile.pwf -g=dba -i="$1" -j="$2" -k="$3" -s="$4" -lvl=50
#/user/cmitest/shells/ColorModule/tm_GetCompCodesFrmSVRAndPlatform -u=ercpsup -p=XYT1ESA -g=dba -i="$1" -j="$2" -k="$3" -s="$4" -lvl=50
echo "Sorting ComCode File..."
sort -u "$1"_"$4"_CompCode.txt > "$1"_"$4"_CompCode.txt1
mv "$1"_"$4"_CompCode.txt1 "$1"_"$4"_CompCode.txt
#cp "$1"_"$4"_CompCode.txt /tmp/.
chmod 777 "$1"_"$4"_CompCode.txt

echo "Starting for Refresh Color."
echo "Sorting Refresh ComCode File..."
sort -u "$1"_"$4"_Refresh_CompCode.txt > "$1"_"$4"_Refresh_CompCode.txt1
mv "$1"_"$4"_Refresh_CompCode.txt1 "$1"_"$4"_Refresh_CompCode.txt
chmod 777 "$1"_"$4"_Refresh_CompCode.txt

echo "Starting for Suffix Selection."
echo "Sorting Suffix selection File..."
sort -u "$1"_"$4"_Suf_CompCode.txt > "$1"_"$4"_Suf_CompCode.txt1
mv "$1"_"$4"_Suf_CompCode.txt1 "$1"_"$4"_Suf_CompCode.txt
chmod 777 "$1"_"$4"_Suf_CompCode.txt

echo "Starting for Copy color."
echo "Sorting copy ComCode File..."
sort -u "$1"_"$4"_Copy_CompCode.txt > "$1"_"$4"_Copy_CompCode.txt1
mv "$1"_"$4"_Copy_CompCode.txt1 "$1"_"$4"_Copy_CompCode.txt
chmod 777 "$1"_"$4"_Copy_CompCode.txt

if [ "$5" == "Refresh" ];then
    echo "Code For Refresh"
 #/user/testcmi/devgroups/Ashish/GetCompCodeForColor/tm_GetCompCodesFrmSVRAndPlatform -u=loader -pf=/home/cmitest/shells/Admin/loaderpwffile.pwf -g=dba -i="$6"
 #/user/bsd05818/Ashish/refreshColorScheme/RefreshColorScheme -u=loader -pf=/home/cmitest/shells/Admin/loaderpwffile.pwf -g=dba -i="$6"
 /user/uaprod/shells/ColorModule/RefreshColorScheme -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="$6"
 echo "Shell downloadCompCodesFrmSVRAndPlatform.sh processing is completed for Refresh."
fi

if [ "$5" == "Copy" ];then
    echo "Code For Copy"
 #/user/testcmi/devgroups/Ashish/GetCompCodeForColor/tm_GetCompCodesFrmSVRAndPlatform -u=loader -pf=/home/cmitest/shells/Admin/loaderpwffile.pwf -g=dba -i="$6"
 #/user/bsd05818/Ashish/copycolorscheme/CopyColorScheme -u=loader -pf=/home/cmitest/shells/Admin/loaderpwffile.pwf -g=dba -i="$6"
 #/user/uaprod/shells/ColorModule/CopyColorScheme -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -old="$6" -nw="$7"
 /user/bsd05818/Ashish/copycolorscheme/CopyColorScheme -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -old="$6" -nw="$7"
 echo "Shell downloadCompCodesFrmSVRAndPlatform.sh processing is completed for Copy."
fi

echo "Shell downloadCompCodesFrmSVRAndPlatform.sh processing is completed."
