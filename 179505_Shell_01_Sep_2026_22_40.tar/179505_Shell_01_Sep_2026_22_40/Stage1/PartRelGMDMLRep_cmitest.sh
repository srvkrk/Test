#!/bin/sh
. /user/testcmi/.bash_profile
ssh cvprod@172.22.99.106 -n "cd /user/cvprod/shells/PartRelGMDMLRep; sh PartRelGMDMLRep1.sh $1 $2"