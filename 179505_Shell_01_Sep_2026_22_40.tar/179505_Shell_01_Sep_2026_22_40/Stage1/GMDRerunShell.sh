. /user/cvprod/.bash_profile
echo "Start==>Calling GMDRerun CVPROD utility server---------->"
echo "Shell--Task Name= " $1
/user/cvprod/Program_Shells/DML_DCR/GateMaturation -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -dmlno=$1
echo "End==>Calling GMDRerun CVPROD utility server ---------->"
/user/cvprod/Program_Shells/DML_DCR/tm_POCheckReRun -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -taskno=$1
echo "End==>Calling PO-Rerun CVPROD utility server ---------->"
