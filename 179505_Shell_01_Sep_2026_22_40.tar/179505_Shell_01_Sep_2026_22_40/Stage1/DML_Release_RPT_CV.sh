. /user/cvprod/.bash_profile
echo "Start==>Calling tm_DML_release_report from CVPROD utility server---------->"
echo "Shell--DML.= " $1
/user/cvprod/Program_Shells/DML_DCR/tm_DML_release_report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -DML_No=$1
echo "End==>tm_DML_release_report from CVPROD utility server---------->"

