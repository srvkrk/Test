#!/bin/sh
. /user/uaprod/.bash_profile

TIMEFORMAT=$'%R,%U,%S'
timestamp=`date +"%d-%m-%y_%T"`
echo  "Shell executed on date : $timestamp"
echo "Script executed from Path: ${PWD}"
echo "Current Path is : ${PWD}"

p=$1
user id = $2
echo "user id is : $2"
echo   "Part Number is : $p"
cd /proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/UAPROD
rm -rf $p
mkdir /proj/PLMLoading/UAFiles/CATIA_Downloading/Uploaders/TMETC_LATEST/UAPROD/${p}
chmod 777 $p
scp -r ${p} uaprodtrl@172.22.97.18:/user/uaprodtrl/Rajan/Catia_Uaprod_Mig/
if [ $p -ge 0 ]
then

scp -r ${p} uaprodtrl@172.22.97.18:/user/uaprodtrl/Rajan/Catia_Uaprod_Mig/



#ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/B.sh ${a}_${b}_${c} loader /user/uaprod/shells/Admin/loaderpasswdFile.pwf"

ssh uaprodtrl@172.22.97.18 -n "cd /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/; sh /user/uaprodtrl/Rajan/Catia_Uaprod_Mig/RACoption2c7to2c3_UAPROD.sh ${p} $2"


else 

 echo "The Part Number $p is incorrect "
 fi


