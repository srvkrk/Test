echo "VALUE FOR THE CTED DML NO -->$1"
cd /home/apldev/devgroups/Amol/CTED_releaseletter
./tm_cted_Report -u=aplplanner -p=XYT1ESA  -i="$1"
echo $"EXE Calling Successfull"
