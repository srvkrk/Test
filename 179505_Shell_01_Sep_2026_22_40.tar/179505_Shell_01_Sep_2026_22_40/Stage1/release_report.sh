. /user/cvprod/.bash_profile
echo "Shell Start for Release letter report CVPROD"
echo $1
cd /user/cvprod/Program_Shells/DML_Support/Print_Report_Release_letter_report_cron/printRel
echo "To patch Release letter report exe"
# /home/cvprod/SLES15_patch/tcldPatch/tcPatchExecutable tm_DML_release_report
./tm_DML_release_report -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -DML_No=$1
echo " *****  after Release letter report EXE ...... "
echo " *****  Shell Execution completed ...... "