. /user/cvprod/.bash_profile
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Program_Shells/DML_DCR/DML_ERCReview_CV.sh"