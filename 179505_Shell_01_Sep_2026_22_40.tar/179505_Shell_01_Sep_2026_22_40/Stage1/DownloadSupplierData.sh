/home/uadev/shell/Supplier_DataDownload/DownloadSupplierDataCC -u=infodba -p=infodba -d=$1 -h=$2
