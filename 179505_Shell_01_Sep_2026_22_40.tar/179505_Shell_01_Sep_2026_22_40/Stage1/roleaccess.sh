echo $1
cd /home/cmitest/muktesh/UserManagement
rm -f roleAccessInput.txt
touch roleAccessInput.txt
echo $1 >> roleAccessInput.txt
echo $(date) >> RoleAccessLog.txt
echo $1 >> RoleAccessLog.txt
./make_user -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -file=/home/cmitest/muktesh/UserManagement/roleAccessInput.txt