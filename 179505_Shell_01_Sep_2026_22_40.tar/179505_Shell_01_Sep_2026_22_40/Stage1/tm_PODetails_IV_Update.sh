echo "Cronjob Shell Start  InValidPO stamp for All Program for CVPROD >> tm_PODetails_IV_Update"
#/user/cvprod/TC_ROOT14/tcldPatch/tcPatchExecutable tm_PODetails_IV_Update
nohup ./tm_PODetails_IV_Update -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba > tm_PODetails_IV_Updatecron.log &
echo "Shell End InValidPO stamp for All Program for CVPROD"