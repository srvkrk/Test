#Shell created by Anu Nair on 24-09-2021 for WBS Loading

. /user/uaprod/.bash_profile

BASE_PATH=/user/bsd05818/Anu/WBS_LOADING/

if [ -s "${1}" ]; then

	"${BASE_PATH}/EXE/wbs_creation" -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -inpfile="${1}"
fi



