        ######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it
# only in accordance with the terms of the license agreement.
#
# Author          : Aniket Joshi
# Created on      : 09-Dec-2025
# Project         : Data transfer to Kafka server
#
#######################################################################################


echo "Shell file is called"

user="aplloader"
pass="/user/cvprod/shells/Admin/aplloaderpasswdFile.pwf"
group="dba"


arg="${1:-}"

# Validate input contains at least one space
if [[ "$arg" != *" "* ]]; then
  echo "Error: input must contain a space separating the two parts." >&2
  exit 1
fi

# First string: everything before the LAST space
first="${arg% *}"

# Second string: everything after the LAST space (the trailing token)
second="${arg##* }"

# Use the variables as needed
echo "First:  $first"
echo "Second: $second"


cd /user/cvprod/NON_ERC_PUNE/kafka/IPMSIQMSTransfer/
./tm_ipmsdatatransfercc -u=$user -pf=$pass -g=$group -b=$first -l=$second

echo "Finished..Aniket..."$""