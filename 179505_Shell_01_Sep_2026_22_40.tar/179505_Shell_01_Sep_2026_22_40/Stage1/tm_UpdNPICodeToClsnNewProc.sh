. /user/cvprod/.bash_profile
#cd $TC_ROOT/bin/tml_tools
todateStr=$(date +"%m_%d_%y_%H_%M")
echo $todateStr
cd /user/cvprod/Shubham_G
/user/cvprod/TC_ROOT12/tcldPatch/tcPatchExecutable tm_UpdNPICodeToClsnNew
/user/cvprod/Program_Shells/DML_DCR/tm_UpdNPICodeToClsnNew -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -veh=$1 -val=$2
echo "End of tm_UpdNPICodeToClsnNewProc shell execution"
