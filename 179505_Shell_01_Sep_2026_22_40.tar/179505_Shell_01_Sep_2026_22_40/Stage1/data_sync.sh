#!/bin/sh
. /user/uaprod/.bash_profile

echo $1
echo $2
echo $3
echo "$1/$2" >>/tmp/deleterev.txt
chmod 755 /tmp/deleterev.txt
cd $TC_ROOT/bin/
./data_sync -u=infodba -pf=/user/uaprod/shells/Admin/infodbapassfile.pwf -g=dba -site=$3 -f=verify -update -fn=/tmp/deleterev.txt -cof=ItemRevision
#./data_sync -u=infodba -pf=/user/uaprod/shells/Admin/infodbapassfile.pwf -g=dba -site=TRILIX-Production -f=verify -update -fn=/user/uaprod/shells/ReplicaDel/deleterev.txt -cof=ItemRevision
rm -f /tmp/deleterev.txt
