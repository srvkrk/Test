#cd /tmp/cmitest &&
cd /tmp/cmitest &&
grep $1 $(ls -rt cmitestmgrstart_19-Jan.log |tail -1)|  grep Server| awk -F "Server" '{print $2}'| awk -F"@" '{print $1}' |grep tcserver|
while read line ; do
        ps -ef|grep "$line@"|grep -v grep|awk '{print $2}'
done|
while read line1 ; do
        #kill -9 $line1
	echo $line1
	kill -9 $line1

done

