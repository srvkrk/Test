#!/bin/ksh
. /user/uaprodtrl/.bash_profile

FileLocation=/proj/PLMLoading/UAFiles/TR_RMDV/TCUA
echo "$FileLocation"

CopyFilesToLocation=/user/uaprodtrl/shells/RMDV
echo "$CopyFilesToLocation"

MoveFilesToLocation=/user/uaprodtrl/shells/RMDV/Moved_Files/
echo "$MoveFilesToLocation"

MoveFilesToLocationOrig=/user/uaprodtrl/shells/RMDV/Moved_Files/Moved_Files_Orig
echo "$MoveFilesToLocationOrig"

MoveCsvFilesToLocation=/user/uaprodtrl/shells/RMDV/Moved_CsvFiles

echo "Begin RDMV Data Upload shell UA"

cd /user/uaprodtrl/shells/RMDV
rm -f *.txt
rm -f *.txt.1
rm -f Final.txt
rm -f Fina1l.txt


echo "$i start copying files"
cp "$FileLocation"/*Input.txt $CopyFilesToLocation/

echo "Files copied to UA Shells folder"

#cd /user/uaprod/shells/RMDV

ls *Input* > Final1.txt
while read line
do
partno=`echo $line | cut -f1 -d','`
echo "$partno"

cat $partno | tr -d "\n" > $partno."1"
done </user/uaprodtrl/shells/RMDV/Final1.txt

ls *Input*1 > Final.txt
echo "Calling exe..."

while read j
do
echo $j
#${CopyFilesToLocation}/t5_TR_Loader -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i="$j"
/user/uaprodtrl/shells/RMDV/t5_TR_Loader -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba -i="$j"
done < /user/uaprodtrl/shells/RMDV/Final.txt
#mv $FileLocation/*_Input.txt $MoveFilesToLocation
mv $CopyFilesToLocation/*_Input.txt* $MoveFilesToLocation
mv $FileLocation/*_Input.txt $MoveFilesToLocationOrig
scp $CopyFilesToLocation/*.csv rmdvibm@172.22.99.91:/user/rmdvibm/Data_From_PLM
mv $CopyFilesToLocation/*.csv $MoveCsvFilesToLocation

