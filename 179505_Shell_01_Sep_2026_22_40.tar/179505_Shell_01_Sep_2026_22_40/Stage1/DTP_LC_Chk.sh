frmdate12=`date +"%d-%m-%Y" --date="12 months ago"`
echo "$frmdate12"
frmdate11=`date +"%d-%m-%Y" --date="11 months ago"`
echo "$frmdate11"
frmdate10=`date +"%d-%m-%Y" --date="10 months ago"`
echo "$frmdate10"
frmdate9=`date +"%d-%m-%Y" --date="9 months ago"`
echo "$frmdate9"
frmdate8=`date +"%d-%m-%Y" --date="8 months ago"`
echo "$frmdate8"
frmdate7=`date +"%d-%m-%Y" --date="7 months ago"`
echo "$frmdate7"
frmdate6=`date +"%d-%m-%Y" --date="6 months ago"`
echo "$frmdate6"
frmdate5=`date +"%d-%m-%Y" --date="5 months ago"`
echo "$frmdate5"
frmdate4=`date +"%d-%m-%Y" --date="4 months ago"`
echo "$frmdate4"
frmdate3=`date +"%d-%m-%Y" --date="3 months ago"`
echo "$frmdate3"
frmdate2=`date +"%d-%m-%Y" --date="2 months ago"`
echo "$frmdate2"
frmdate1=`date +"%d-%m-%Y" --date="1 months ago"`
echo "$frmdate1"
frmdate0=`date +"%d-%m-%Y" --date="1 days ago"`
echo "$frmdate0"
echo "for 12 month ago.. >> tm_CheckWIP_Status_RelDML"
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate12 -I2=$frmdate11 > Test12.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate11 -I2=$frmdate10 > Test11.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate10 -I2=$frmdate9 > Test10.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate9 -I2=$frmdate8 > Test9.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate8 -I2=$frmdate7 > Test8.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate7 -I2=$frmdate6 > Test7.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate6 -I2=$frmdate5 > Test6.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate5 -I2=$frmdate4 > Test5.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate4 -I2=$frmdate3 > Test4.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate3 -I2=$frmdate2 > Test3.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate2 -I2=$frmdate1 > Test2.log &
nohup ./tm_CheckWIP_Status_RelDML -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate1 -I2=$frmdate0 > Test1.log &
echo "Shell End Correect DML status CVPROD"
