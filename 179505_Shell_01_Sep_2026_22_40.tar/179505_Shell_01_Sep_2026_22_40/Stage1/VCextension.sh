/bin/bash

. /user/cmitest/.bash_profile

now="$(date +'%Y_%m_%d')"
echo "VC : "$1
echo "DML Number : "$2
echo "From_Plant : "$3
echo "To_Plant : "$4
echo "CopyCS : "$5

cd /home/cmitest/shells/APL/VCextension/
./tm_VC_Extension -u=aplloader -pf=/home/cmitest/shells/Admin/aplloader.pwf -g=dba -svr=cmitest -VC=$1 -DML=$2 -From_Plant=$3 -To_Plant=$4 -CopyCS=$5 


echo "VcExtension cc executed succesfuly...!!!!!!!!"
