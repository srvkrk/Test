#!/bin/ksh
. /user/omfprod/.bash_profile

. /user/omfprod/config/pdmsetup.sh
cd /user/omfprod/shells/PLMUVTRANSFER/ECU_BASELINE_SHELLS
#cd /user/omfprod/Adi/BL_VC_TRANSFER/
echo "Starting shell on 2c3"

echo "Aditya $2"

xfr_date=`date +"%Y/%m/%d-%H:%M:%S"`

Bsl_no=`echo "$2" | sed 's/_//g'`
echo "Bsl_no is $Bsl_no"

while read i
do
#Veh=`echo "$i" | sed 's/000R/R/g' | sed 's/000L/L/g'`
Veh=`echo "$i"`

echo "Transferring data for vehicle $Veh"

Project=$1
echo "1..Project is $Project"

if [  -z "$Project" -a "$Project"==" " ]; then
	echo "Project null"
	Project='NA'
fi

if [ ! -s /tmp/"$Veh"_VC.csv ];  then
echo "File size is 0"
else
		Mailid=`sqlplus -s deststpune/tiger@ELEC  <<!
		set feedback off
		set verify off
		set pause on pages 0
		set pau off
		select distinct EMAIL_ID from mailing_list where PROJECT_CODE='$Project';
!`
		out=`sed 's/ / /g' <<< $Mailid`
		echo $out
		echo "Mail id is $out"

		ch=`echo $out | grep -i error`
	
		if [  -z "$ch" -a "$ch"==" " ]; then
			if [ -e /tmp/"$Veh"_Struct.csv ] &&  [ -s /tmp/"$Veh"_Struct.csv ]; then
				if [ -e /tmp/"$Veh"_VC.csv ] &&  [ -s /tmp/"$Veh"_VC.csv ]; then
					echo "Trasnfer records to ECU Type "
					./VC_Report_bl.sh $Veh
					exit_stat01=$?
				fi

				if [[ (-e /tmp/"$Veh"_Struct.csv) && (-s /tmp/"$Veh"_Struct.csv) && ($exit_stat01 == 0) ]]; then
					echo "Insert into File_Master"
					./VC_Report_struct_bl.sh $Veh $Bsl_no
					exit_stat02=$?
				fi 

				if [[ (-e /tmp/"$Veh"_Para.csv) && (-s /tmp/"$Veh"_Para.csv) && ($exit_stat02 == 0) ]]; then
					echo "Insert into Para_Master"
					./VC_Report_para_bl.sh $Veh $Bsl_no
					exit_stat03=$?
				else 
					if [ ! -s /tmp/"$Veh"_Para.csv ];  then
						echo "Nothing to insert in Para_Master"
						exit_stat03=0
					fi
				fi
				if [[ (-e /tmp/"$Veh"_SuppMstr.csv) &&  (-s /tmp/"$Veh"_SuppMstr.csv) && ($exit_stat03 == 0) ]]; then
					echo "Insert into Supfile_Master"
					./VC_Report_Supp_bl.sh $Veh $Bsl_no
					exit_stat04=$?
				else 
					if [ ! -s /tmp/"$Veh"_SuppMstr.csv ];  then
						echo "Nothing to insert in Supfile_Master"
						exit_stat04=0
					fi
				fi
				if [[ (-e /tmp/"$Veh"_Files.csv) && (-s /tmp/"$Veh"_Files.csv) && ($exit_stat04 == 0) ]]; then
					echo "Copy Files to UV server"
					./Files_bl.sh $Veh
					#cat /tmp/"$Veh"_Files.csv >> /tmp/543_Files.csv
					exit_stat05=$?
				else 
					if [ ! -s /tmp/"$Veh"_Files.csv ];  then
						echo "No files to copy to UV"
						exit_stat05=0
					fi
				fi

				if [ $exit_stat05 == 0 ]; then
					#echo "Data Transferred to UV server ..Please visit http://tmpneglblecu01/NecMPLM" | nail -s "UV Data Trasnfer for $Veh" -a /tmp/"$Veh"_Summary.csv $out -c  ketankor.ttl@tatamotors.com harshadp.ttl@tatamotors.com adityaa.ttl@tatamotors.com prachiw.ttl@tatamotors.com shindeb.ttl@tatamotors.com
					
					echo "Positive Entry NOT added into PLM_UV_STAT for $1"		
				else
					echo "Problem in VC transfer."

					echo "Negative Entry NOT added into PLM_UV_STAT for $1"	
					echo | nail  -s "Transfer failed for vehicle $Veh" ketankor.ttl@tatamotors.com harshadp.ttl@tatamotors.com adityaa.ttl@tatamotors.com prachiw.ttl@tatamotors.com
				fi
			fi
		else
			echo "Problem in VC transfer."

			echo "Negative Entry NOT added into PLM_UV_STAT for $1"	
			echo | nail  -s "Transfer failed for vehicle: $Veh" ketankor.ttl@tatamotors.com harshadp.ttl@tatamotors.com adityaa.ttl@tatamotors.com prachiw.ttl@tatamotors.com
		fi
fi
done < /tmp/$2_VCCRList.csv
