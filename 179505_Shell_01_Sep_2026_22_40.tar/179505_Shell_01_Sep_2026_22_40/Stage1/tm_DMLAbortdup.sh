. /user/cvprod/.bash_profile
echo "Abort facility running on DML"
echo "In Shell tm_DMLAbortdup.sh 106  ...'"$1"' "
/user/cvprod/Program_Shells/DML_DCR/dmlabort -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -dmlno=$1
echo "tm_DMLAbortdup.sh end at DML"
