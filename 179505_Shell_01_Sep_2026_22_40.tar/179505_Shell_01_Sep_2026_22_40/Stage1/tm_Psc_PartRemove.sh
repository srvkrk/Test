#!/bin/sh
. /user/uaprod/.bash_profile
echo "Start of tm_Psc_PartRemove_uaprodtrl --> $1 "
ssh uaprodtrl@172.22.97.18 -n "/user/uaprodtrl/Program_Shells/DML_DCR/tm_Psc_PartRemove_uaprodtrl.sh $1"
echo "---Expand tm_Psc_PartRemove_uaprodtrl Shell Completed.---"