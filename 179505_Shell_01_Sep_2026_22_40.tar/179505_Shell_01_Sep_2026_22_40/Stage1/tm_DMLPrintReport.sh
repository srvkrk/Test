. /home/cmitest/.bash_profile
echo  $1
cd /home/cmitest/shells/APL/DMLPrintReport/
./tm_DMLPRINTREPORT -u=aplplanner -p=XYT1ESA -g=APL_Support_Group -i=$1

echo $"EXE Calling Successfull11111"