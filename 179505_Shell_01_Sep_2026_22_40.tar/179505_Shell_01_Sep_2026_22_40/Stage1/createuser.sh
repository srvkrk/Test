echo $1
cd /home/cmitest/muktesh/UserManagement
rm -f create_user.txt
touch create_user.txt
echo $1 >> create_user.txt
echo $(date) >> CreateUserLog.txt
echo $1 >> CreateUserLog.txt
./make_user -u=loader -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -file=/home/cmitest/muktesh/UserManagement/create_user.txt