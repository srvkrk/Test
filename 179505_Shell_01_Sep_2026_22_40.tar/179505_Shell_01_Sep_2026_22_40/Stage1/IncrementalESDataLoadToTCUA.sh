. /user/aplstdgrp/.bash_profile
echo "Connecting uaprod...."
echo $1
pwd
cd /user/aplstdgrp/Dhanashri/EstimateSheet_TCE_TCUA_Migration
mkdir $1
WrkgPath="/user/aplstdgrp/Dhanashri/EstimateSheet_TCE_TCUA_Migration/"
pwd
#CreateEstimateSheet  -u=aplloader -pf=/home/cmitest/shells/Admin/aplloader.pwf -g=dba -i=/uv19/UAFiles/EstimateSheet_TCE_TCUA_Migration/$1/ES.txt > $WrkgPath$1/ESLoaded.log
#CreateEstimateOperation  -u=aplloader -pf=/home/cmitest/shells/Admin/aplloader.pwf -g=dba -i=/uv19/UAFiles/EstimateSheet_TCE_TCUA_Migration/$1/ES_OPR.txt > $WrkgPath$1/ESOPRLoaded.log

CreateEstimateSheet  -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=/uv19/UAFiles/EstimateSheet_TCE_TCUA_Migration/$1/ES.txt > $WrkgPath$1/ESLoaded.log
CreateEstimateOperation  -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=/uv19/UAFiles/EstimateSheet_TCE_TCUA_Migration/$1/ES_OPR.txt > $WrkgPath$1/ESOPRLoaded.log

wait
if [ $? != 0 ]
        then
                echo "Problem in ES Loading.."
                exit 1
        else
                echo "ES and OPR Loaded succsesfully"

fi