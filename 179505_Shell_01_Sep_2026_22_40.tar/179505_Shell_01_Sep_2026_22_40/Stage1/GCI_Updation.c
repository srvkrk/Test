/*
./compile MIS_VC_DateWise_Rep.c
./linkitk -o MIS_VC_DateWise_Rep MIS_VC_DateWise_Rep.o
scp MIS_VC_DateWise_Rep tkr06466@172.22.97.12:/user/plmsap/PLMSAP/tkr/clientcode/MIS_VC_DateWise_Rep
nohup ./MIS_VC_DateWise_Rep -u=tkr06466 -p=XYT1ESA -fromdate="01-Mar-2022" -todate="20-Mar-2022" -type='M' >1.log &
*/
#define TE_MAXLINELEN  128

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sa/sa.h>
#include <unidefs.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <ps/ps.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <stdarg.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tccore/method.h>
#include <property/prop_msg.h>
#include <tccore/iman_msg.h>
#include <res/reservation.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <tccore/tctype_msg.h>
#include <ict/ict_userservice.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <pom/pom/pom_tokens.h>
#include <property/prop.h>
#include <property/propdesc.h>
#include <tccore/tc_msg.h>
#include <lov/liblov_exports.h>
#include <lov/liblov_undef.h>
#include <ug_va_copy.h>
#include <tccore/grm.h>
#include <pie/pie.h>
#include <tccore/uom.h>
#include <time.h>
#include <sa/am.h>
#define Debug TRUE
#define ITK_err 910001

int DFQApplCntflag=0;
int falseflagg=0;
int DFQpdfCount=0;
int DFQexcelsCount=0;
int MeetexpectationCnt=0;

#define GETCHAR(var,str) sprintf(str,"%.*s",(int)sizeof(var),var)
#define GETNUM(var,str) sprintf(str,"%.*s",sizeof(var),var);
#define SETDATE(var,str)memcpy(var,str,__min(strlen(str),sizeof(var)));if(sizeof(var)>strlen(str))memset(var+strlen(str),'0',sizeof(var)-strlen(str))
#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))



static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		//fprintf( stderr, "Error(PrintErrorStack): \n");
        //fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		//printf("%3d error(s)\n", n_ifails);fflush(stdout);
		for( index=0; index<n_ifails; index++)
		{
			//printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);fflush(stdout);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			//printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);fflush(stdout);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str);

void OUTS(const char *text,const unsigned pos,const unsigned len,char*str)
{
  printf("\n%*.0s",pos,text); printf("%-*s : %s",len,text,str);fflush(stdout);
  return;
}




void setAddStr(int *count,char ***strset,char* str)
{

	*count=*count+1;
	//printf("\n setAddStr %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 //printf("\n setAddStr===%s",(*strset)[*count-1]);fflush(stdout);

}



char* subString(char* mainStringf ,int fromCharf ,int toCharf)
{
      int i;
      char *retStringf;
      retStringf = (char*) malloc(toCharf+1);
      for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
      *(retStringf+i) = '\0';
      return retStringf;
}

char* DVACalulate()
{
	char* ptr = NULL;
	float percentage;

	ptr = (char *) MEM_alloc(sizeof(char)* 30);



	printf("\n\n DVACalulate--DFQApplcbltyCnt: [%d]  PDFAttachedCnt: [%d]  DFQMeetExpNoCnt: [%d] \n", DFQApplCntflag,DFQpdfCount,MeetexpectationCnt);fflush(stdout);


	if ((DFQApplCntflag != 0)&&(DFQpdfCount != 0))
	{

		percentage = (float)(MeetexpectationCnt) / DFQApplCntflag * 100.0;

		printf("\n  after calculation: Percentage = %.2f%%", percentage); fflush(stdout);
		sprintf(ptr,"%10lf",percentage);
		printf("\n  after conversion  to str: %s \n",ptr);fflush(stdout);

		return ptr;
	}
	else
	{
		return "0";
	}
}

char* GetDemeritScoreRating(char* DvloName , int DemeritScore)
{
	char* ptr = NULL;
	int dvr=0;


	ptr = (char *) MEM_alloc(sizeof(char)* 30);

      if (DvloName!=NULL)
	 {
		printf("\n  DvloName: %s   DemeritScore: %d",DvloName,DemeritScore);fflush(stdout);

		if (DemeritScore<=100)
		{
			dvr=100;
			printf("\n dvr value is 100*:%d",dvr);fflush(stdout);
		}
		else if( (DemeritScore<=130) && (DemeritScore>100))
		{
			dvr=80;
			printf("\n dvr value is 80*:%d",dvr);fflush(stdout);
		}
		else if (DemeritScore>130)
		{
			dvr=50;
			printf("\n dvr value is 50*:%d",dvr);fflush(stdout);
		}
		else
		{
			dvr=0;
			printf("\n dvr value is 0*:%d",dvr);fflush(stdout);
		}

		printf("\n dvr value is----:%d",dvr);fflush(stdout);
		sprintf(ptr,"%d",dvr);
		printf(" after conversion dvr: %s \n",ptr);fflush(stdout);

		return ptr;
	}
	else
	{
		return "0";
	}
}

int GetDVAUseCaseFromLibraryt(tag_t PartTag, char* t5_business_unit_type_mod, int* resultCount, tag_t **dfq_use_case_tags)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char* documentName;
	char* s;
	char* moduleAddressS;
	char ** qry_entries = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values1 = (char **) MEM_alloc(n_entries * sizeof(char *));
	tag_t queryTag = NULLTAG;
	tag_t *dfq_use_case_tags1 = NULLTAG;


	/*--------------------------------------------------------
		Get Applicable DFQ USE CASE
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"bl_Design Revision_t5_ModuleAddress",&moduleAddressS);
	printf("Module Address  :: %s\n",moduleAddressS);fflush(stdout);

	queryTag = NULLTAG;
	status = QRY_find("DFQ Use Case", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}
	else
	{
      printf("Tag found query\n");fflush(stdout);
	}

	if(tc_strcmp(t5_business_unit_type_mod,"CVBU") == 0) t5_business_unit_type_mod = "CV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU") == 0) t5_business_unit_type_mod = "PV";
	else if(tc_strcmp(t5_business_unit_type_mod,"PCBU and CVBU Both") == 0) t5_business_unit_type_mod = "PSE";
	else
	{
			EMH_ask_error_text( status, &s);
			MEM_free(s);
			return status;
	}

	//Query DFQ Use Case
	documentName = NULL;
	documentName = (char *)MEM_alloc(50);
	tc_strcpy(documentName, "DVA_");
	tc_strcat(documentName, t5_business_unit_type_mod);
	tc_strcat(documentName, "_");
	tc_strcat(documentName, moduleAddressS);
	tc_strcat(documentName, "*");

	qry_values1[0] = (char *)MEM_alloc(strlen(documentName ) + 1);
	tc_strcpy(qry_values1[0], documentName);

	//qry_values1[1] = (char *)MEM_alloc(10);
	//tc_strcpy(qry_values1[1], "DFQ Use Case");

    qry_entries[0] = (char *)MEM_alloc(10);
	strcpy(qry_entries[0], "Name");

	//qry_entries[1] = (char *)MEM_alloc(10);
	//strcpy(qry_entries[1], "Type");
	//strcpy(qry_entries[1], "object_type");



   printf("Name is  :: %s\n",qry_values1[0]);fflush(stdout);
  // printf("Type is  :: %s\n",qry_values1[1]);fflush(stdout);


	ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values1, &resultCount1, &dfq_use_case_tags1));
	printf("\nNo. of DFQ Use Case Document found are %d -- %s\n",resultCount1,documentName);fflush(stdout);

	if(resultCount1 > 0)
	{
		*dfq_use_case_tags = dfq_use_case_tags1;
		*resultCount = resultCount1;
	}

	return 0;
}

int getBusinessUnitFunct(tag_t PartTag, char** ProjbussDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"bl_Design Revision_t5_ProjectCode",&t5_projectc_code_string);

	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status = QRY_find("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}


int getBusinessUnitFunc(tag_t PartTag, char** ProjbussDup,char**ProjdescDup)
{
	int status = 0;
	int n_entries = 1;
	int resultCount1 = 0;
	char *s;
	char *t5_business_unit_type_mod;
	char *t5_ProjectDescp=NULL;
	char ** qry_entries2 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char **qry_values3 = (char **) MEM_alloc(n_entries * sizeof(char *));
	char* t5_projectc_code_string;
	tag_t queryTag = NULLTAG;
	tag_t* proj_tags = NULLTAG;
	/*--------------------------------------------------------
		Get Business Unit from Project Code"
	---------------------------------------------------------*/
	AOM_ask_value_string(PartTag,"t5_ProjectCode",&t5_projectc_code_string);
	printf("%s\n",t5_projectc_code_string);fflush(stdout);

	queryTag = NULLTAG;
	status = QRY_find("Project for DSRpt", &queryTag);
	if (status != ITK_ok)
	{
		  EMH_ask_error_text( status, &s);
		  printf("\n*** Error with Finding Query -- Project for DSRpt ***\n");fflush(stdout);
		  MEM_free(s);
		  return status;
	}

	qry_entries2[0] = (char *)MEM_alloc(15);
	strcpy(qry_entries2[0], "Project Number");

	qry_values3[0] = (char *)MEM_alloc(10);
	tc_strcpy(qry_values3[0], t5_projectc_code_string);

	QRY_set_name_mode(queryTag,false);
	//Execute Query
	status = QRY_execute(queryTag, n_entries, qry_entries2, qry_values3, &resultCount1, &proj_tags);

	if(resultCount1 == 0)
	{
			EMH_ask_error_text( status, &s);
			printf("\n*** No Project Found are  -- %s ***\n", t5_projectc_code_string);fflush(stdout);
			MEM_free(s);
			return status;
	}

	AOM_ask_value_string(proj_tags[0],"object_desc",&t5_ProjectDescp);
	printf("project desc -- %s\n",t5_ProjectDescp);fflush(stdout);

	*ProjdescDup = t5_ProjectDescp;

	AOM_ask_value_string(proj_tags[0],"t5_BussUnitType",&t5_business_unit_type_mod);
	printf("Business Unit -- %s\n",t5_business_unit_type_mod);fflush(stdout);

	*ProjbussDup = t5_business_unit_type_mod;

	return 0;
}

void SendVCdetailsForGCI( tag_t VechRevTag, tag_t GCItag)
{

     tag_t bom_wnd				=NULLTAG;
     tag_t rule					=NULLTAG;
     tag_t top_lne				=NULLTAG;
     tag_t	*ColIndChilds		=NULLTAG;
     tag_t	*dfq_use_case_tags	=NULLTAG;
     tag_t	*DVA_document_tag	=NULLTAG;
     tag_t	*refobjpdfs			=NULLTAG;
     tag_t	*refobjexcels		=NULLTAG;
     //tag_t	*GCIobj				=NULLTAG;
	 tag_t	Childobject			=NULLTAG;
	 tag_t	itemoduleTag		=NULLTAG;
	 tag_t	itemoduleTagLat		=NULLTAG;
	 tag_t	relTypeTags			=NULLTAG;
	 //tag_t	MSexcelDatatyp		=NULLTAG;

     char*VcNumber			=NULL;
     char*DFQdocnosDup		=NULL;
     char*DFQdocnos			=NULL;
     char*DFQUIDsDup		=NULL;
     char*DFQUIDs			=NULL;
     char*DVADescsDup		=NULL;
     char*DVADescs			=NULL;
	 char*VCtypeNam			=NULL;

	 char*PartRelStats		=NULL;
	 char*ProjbussDup		=NULL;
	 char*PartNumsDup		=NULL;
	 char*PartNums			=NULL;
	 char*PartNumstypDup	=NULL;
	 char*PartNumstyp		=NULL;
	 char*Meetexpectation	=NULL;
	 char*MeetexpectationDup=NULL;
	 char*PartRelProjcode=NULL;

	 int i=0;
	 int count=0;
	 int ichld=0;
	 int resultCount=0;
	 int DVA_result_counts=0;
	 int nFoundpdfs=0;
	 int nFoundexcels=0;
	 //int GCIcount=0;
	 logical DFQApplicablilitycheck1= 0;

	 char	Data[100]= "";
     time_t 	now;
	 struct 	tm when;

	 char *VPrtModNum=NULL;
	 char *VPrtModNumType=NULL;
	 char *CurRe=NULL;
	 char *CurSe=NULL;
	 char *VPrtdesc=NULL;
	 char *prjcode=NULL;
	 char *prjcodeDup=NULL;
	 char *partsts=NULL;
	 char *partstsDup=NULL;
	 char *ProjdescDup = NULL;
	 FILE* file=NULL;
	 char fsuccess_nam[200];
	 char *Owner	= NULL;
	 Owner = (char *)MEM_alloc(50);
	 char *PartRevs=NULL;
	 char *PartRevsDup=NULL;
	 char *CurRevs = NULL;
	 char *CurSeqs = NULL;
	 char *ModuleAddressp=NULL;
	 char *ModuleAddresspDup=NULL;
	 char *partst=NULL;
	 char *partstDup=NULL;
	 char *descp=NULL;
	 char *descpDup=NULL;
	 char *Csvpath=NULL;
	 char *GCIDocPath=NULL;
	 GCIDocPath = (char *)MEM_alloc(200);
	 Csvpath = (char *)MEM_alloc(200);
	 char* Owners	= NULL;
	 Owners = (char *)MEM_alloc(50);
	 
	 int d=0;
	 char* PrerevDRstat	 = NULL;
	 PrerevDRstat	=	(char	*)MEM_alloc(10);
	 char* DFQComments = NULL;
	 char* DFQCommentsDup	= NULL;
	 char* MeetexpectationDupMM	=NULL;
	 char* Foundpdfs		= NULL;
	 char* Foundexcels	= NULL;
	 char* DFQApplicablilitysDup=NULL;
	 //AE_reference_type_t MSrefType=1;
	 //tag_t file_tag1 = NULLTAG;
	 //IMF_file_t file_descriptor1;
	 //int j=0;
	 PIE_scope_t scope;
	 scope=PIE_TEAMCENTER;
	int rulefound= 0;
	tag_t *closurerule = NULLTAG;
	tag_t close_tag = NULLTAG;
	tag_t bom_variant_rule = NULLTAG;
	tag_t objTypeTag=NULLTAG;
	char type_name[TCTYPE_name_size_c+1];
	tag_t e_block		= NULLTAG;
	char **rulename = NULL;
	char **rulevalue = NULL;

	 time(&now);
	 when = *localtime(&now);
     strftime(Data,100,"%Y_%b_%d_%H_%M_%S",&when);


				AOM_ask_value_string(VechRevTag,"item_id",&VcNumber);
				printf("Item ID* :: %s\n",VcNumber);fflush(stdout);

				AOM_ask_value_string(VechRevTag,"t5_PartType",&VCtypeNam);
				printf("Item ID type* :: %s\n",VCtypeNam);fflush(stdout);

				ITK_CALL(AOM_ask_value_string(VechRevTag,"item_id",&VPrtModNum));

	            ITK_CALL(AOM_ask_value_string(VechRevTag,"item_revision_id",&VPrtModNumType));
				printf("\nV number is [%s]\n",VPrtModNum); fflush(stdout);

				CurRe = strtok(VPrtModNumType,";");
				CurSe = strtok(NULL,";");

				ITK_CALL(AOM_ask_value_string(VechRevTag,"object_desc",&VPrtdesc));

				ITK_CALL(AOM_ask_value_string(VechRevTag,"t5_ProjectCode",&prjcode));
				tc_strdup(prjcode,&prjcodeDup);
				
				ITK_CALL(AOM_ask_value_string(VechRevTag,"t5_PartStatus",&partsts));
				tc_strdup(partsts,&partstsDup);

				ITK_CALL(getBusinessUnitFunc(VechRevTag, &ProjbussDup,&ProjdescDup));
				printf("\n t5_BussUnitType :[%s] [%s]\n",ProjbussDup,ProjdescDup);   fflush(stdout);

				ITK_CALL(PREF_ask_char_value("T5_GCICSV_Destination_path_uaprodtrl",0,&GCIDocPath));
				printf("\n GCIDocPath :[%s]\n",GCIDocPath);   fflush(stdout);

			   if(tc_strcmp(VCtypeNam,"V")== 0)
			   {

                tc_strcpy(Csvpath,"");
                tc_strcpy(Csvpath,GCIDocPath);
                sprintf(fsuccess_nam,"%s_%s_%s_DVA_Matrix_%s.csv",VPrtModNum,CurRe,CurSe,Data);
				tc_strcat(Csvpath,fsuccess_nam);
                printf("\n file path is*** :[%s]\n",Csvpath);   fflush(stdout);
				file = fopen(Csvpath,"w");

				if(file!=NULL)
			    {
				printf("\n file is opening\n");   fflush(stdout);	
			    }
			    else
			    {
				   printf("\n file is not opening\n");   fflush(stdout);	
			    }

				fprintf(file,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
				fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
				fprintf(file,",,,Description,%s,,,,,,,\n",VPrtdesc);
				fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
				fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
				fprintf(file,",,,Last Updated,,,,,,,\n");
				fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
				fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
				fprintf(file,"\n\n");

				fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Meet the Expectations (Yes/No)\n");
                
			   	          if(VechRevTag!=NULLTAG)
				          {
						                    ITKCALL(BOM_create_window(&bom_wnd ));      //set new bom window
											ITK_CALL( BOM_set_window_top_line( bom_wnd, NULLTAG, VechRevTag, NULLTAG, &top_lne ));
											ITKCALL(BOM_set_window_pack_all(bom_wnd, FALSE)); 
		                                    ITKCALL(CFM_find("ERC release and above", &rule));  //find the revision rule
											ITKCALL(BOM_set_window_config_rule(bom_wnd, rule));  // set revision rule for window

											//ITK_CALL(PIE_find_closure_rules( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
											ITK_CALL(PIE_find_closure_rules( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));

					                        printf ("vc_rule count %d \n",rulefound);fflush(stdout);
					                        
					                        if (rulefound > 0)
					                        {
					                        	close_tag = closurerule[0];
					                        	printf (" vc closure rule found \n");fflush(stdout);
					                        	// MEM_free(tags_found);
					                        }

											ITK_CALL(BOM_window_set_closure_rule( bom_wnd,close_tag, 0, rulename,rulevalue ));

					                       
					                        printf( " vc_After BOM_set_window_top_line..\n");fflush(stdout);

											ITK_CALL ( BOM_window_ask_variant_rule( bom_wnd, &bom_variant_rule ));
					                        printf( " vc_release BOM_window_ask_variant_rule..\n");fflush(stdout);
											

											ITK_CALL(TCTYPE_ask_object_type(bom_variant_rule,&objTypeTag));
					                        ITK_CALL(TCTYPE_ask_name(objTypeTag,type_name));
											

											ITK_CALL ( ITEM_ask_rev_variants ( VechRevTag, &e_block ));
					                        printf(" vc_ITEM_ask_rev_variants..\n");fflush(stdout);
											
                                      if(top_lne!=NULLTAG)
					                  {

                                        ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
									  

									    ITK_CALL(BOM_window_hide_unconfigured(bom_wnd));
						                ITK_CALL(BOM_window_show_variants(bom_wnd));

									    printf("\n vc_release After inside bom_window-----\n"); fflush(stdout);
						                ITK_CALL(BOM_window_apply_variant_configuration(bom_wnd,1,&VechRevTag))   ;
						                printf("\n vc_release After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
									   

                                        ITK_CALL(BOM_window_hide_variants(bom_wnd));

						                ITK_CALL(BOM_line_ask_child_lines(top_lne, &count, &ColIndChilds));
									  

						               printf("\n vcBom_count --------> : [%d]  ",count); fflush(stdout);

						    if(count >0)
						    {

						    for (ichld=0;ichld<count ;ichld++ )
						    {

							if(Childobject)Childobject=NULLTAG;
							Childobject=ColIndChilds[ichld];

                            ITK_CALL(AOM_ask_value_string(Childobject,"bl_item_item_id",&PartNums));
							tc_strdup(PartNums,&PartNumsDup);
							printf("\nPart number is [%s]",PartNumsDup); fflush(stdout);

							ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartType",&PartNumstyp));
							tc_strdup(PartNumstyp,&PartNumstypDup);

							ITK_CALL(AOM_ask_value_string(Childobject,"bl_rev_item_revision_id",&PartRevs));
							tc_strdup(PartRevs,&PartRevsDup);
							printf("\nPart number revision [%s]",PartRevsDup); fflush(stdout);

							 CurRevs = strtok(PartRevsDup,";");
							 CurSeqs = strtok(NULL,";");

							ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddressp));
							tc_strdup(ModuleAddressp,&ModuleAddresspDup);

							ITK_CALL(AOM_ask_value_string(Childobject,"bl_Design Revision_t5_PartStatus",&partst));
							tc_strdup(partst,&partstDup);

							ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_Design Revision_t5_CategoryName",&descp));
							tc_strdup(descp,&descpDup);
							STRNG_replace_str(descpDup,","," ",&descpDup);


							ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_rev_release_status_list",&PartRelStats));
                            printf("\nPart release is [%s]",PartRelStats); fflush(stdout);

							ITK_CALL(AOM_UIF_ask_value(Childobject,"bl_Design Revision_t5_ProjectCode",&PartRelProjcode));
							printf("\nPart project code is [%s]",PartRelProjcode); fflush(stdout);


							if(tc_strstr(PartRelStats,"ERC Released")!=NULL)
							{
									printf("\nPart [%s] Release Status [%s]",PartNums,PartRelStats); fflush(stdout);
									tc_strcpy(Owners,"Release Vault");
							}

								if(tc_strcmp(PartNumstyp,"M")==0)
							    {

								ITK_CALL(getBusinessUnitFunct(Childobject, &ProjbussDup));            //getting business unit according to project code
								printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);   fflush(stdout);

								ITK_CALL(GetDVAUseCaseFromLibraryt(Childobject, ProjbussDup, &resultCount, &dfq_use_case_tags));//check no. of use cases for BUS unit
								printf("\n No of Use cases Mapped :[%d]\n",resultCount);   fflush(stdout);

								ITEM_find_item(PartNums, &itemoduleTag);
								ITEM_ask_latest_rev(itemoduleTag,&itemoduleTagLat);
								GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);

								//Get Attached DFQ Documents
								ITK_CALL(GRM_list_secondary_objects_only(itemoduleTagLat, relTypeTags, &DVA_result_counts,&DVA_document_tag));
								printf("\n No of Attached DFQ Documetns are** :: %d\n",DVA_result_counts);fflush(stdout);

								    int trueflagg=0;
									int falseflagg=0;
									

                                        if (DVA_result_counts >0)
										{
											for (d=0;d<DVA_result_counts; d++ )
											{
												AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

                                                 

												if(DFQApplicablilitycheck1 == 1)
												{
													trueflagg++;
												}
												else
												{
													falseflagg++;
												}
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,PrerevDRstat,ProjbussDup,descpDup,Owners);fflush(stdout);
										fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",PartNumsDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,ProjbussDup,descpDup,Owners,resultCount,falseflagg,trueflagg);


								if (DVA_result_counts >0)
								{
									for (i=0;i<DVA_result_counts; i++ )
									{
										AOM_ask_value_logical(DVA_document_tag[i],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

										printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

										AOM_ask_value_string(DVA_document_tag[i],"current_name",&DFQdocnos);
										tc_strdup(DFQdocnos,&DFQdocnosDup);

                                        if(tc_strcmp(prjcodeDup,PartRelProjcode)==0)
                                        {
											printf("\n project code is matching **************************************\n");fflush(stdout);
										AOM_ask_value_string(DVA_document_tag[i],"t5_DFQUID",&DFQUIDs);
										tc_strdup(DFQUIDs,&DFQUIDsDup);

										ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[i],"object_desc",&DVADescs));
										tc_strdup(DVADescs,&DVADescsDup);

										STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup);

										ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQComment",&DFQComments));
										tc_strdup(DFQComments,&DFQCommentsDup);

										STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
										STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);


										if(DFQApplicablilitycheck1 == 1)
										{
											DFQApplCntflag++;
											tc_strdup("Yes",&DFQApplicablilitysDup);
											printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
										}
										else
										{
											falseflagg++;
											tc_strdup("No",&DFQApplicablilitysDup);
											printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
										}

										ITK_CALL(AE_ask_all_dataset_named_refs(DVA_document_tag[i],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
										ITK_CALL(AE_ask_all_dataset_named_refs(DVA_document_tag[i],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

										ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
										tc_strdup(Meetexpectation,&MeetexpectationDup);
										printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

										if(tc_strcmp(MeetexpectationDup,"N")==0)
										{
                                               tc_strdup("No",&MeetexpectationDupMM);
										}
										if(tc_strcmp(MeetexpectationDup,"Y")==0)
										{
                                               tc_strdup("Yes",&MeetexpectationDupMM);
										}
										if(tc_strcmp(MeetexpectationDup,"NA")==0)
										{
                                               tc_strdup("NA",&MeetexpectationDupMM);
										}


                                        if(DFQApplicablilitycheck1 == 1)
										{
										if(nFoundpdfs >= 1)
										{
											DFQpdfCount++;

										if((tc_strcmp(MeetexpectationDup,"Y")==0) || (tc_strcmp(MeetexpectationDup," ")==0))
											{
                                                MeetexpectationCnt++;
											}

										}
										}
										if(nFoundexcels == 1)
										{
											DFQexcelsCount++;
										}

										if (nFoundpdfs == 0)
										{
											tc_strdup("No",&Foundpdfs);
										}else{
											tc_strdup("Yes",&Foundpdfs);
										}

										if (nFoundexcels == 0)
										{
											tc_strdup("No",&Foundexcels);
										}else{
											tc_strdup("Yes",&Foundexcels);
										}

										printf("\n DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] MeetexpectationsDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDup);fflush(stdout);
										fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDupMM);
									}
									  else if (tc_strstr(DFQdocnosDup,prjcodeDup)!=NULL)
									  {
										  printf("\n project code is not matching**************************************\n");fflush(stdout);
										  AOM_ask_value_string(DVA_document_tag[i],"t5_DFQUID",&DFQUIDs);
										tc_strdup(DFQUIDs,&DFQUIDsDup);

										ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[i],"object_desc",&DVADescs));
										tc_strdup(DVADescs,&DVADescsDup);

										STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup);

										ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQComment",&DFQComments));
										tc_strdup(DFQComments,&DFQCommentsDup);

										STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
										STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);


										if(DFQApplicablilitycheck1 == 1)
										{
											DFQApplCntflag++;
											tc_strdup("Yes",&DFQApplicablilitysDup);
											printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
										}
										else
										{
											falseflagg++;
											tc_strdup("No",&DFQApplicablilitysDup);
											printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
										}

										ITK_CALL(AE_ask_all_dataset_named_refs(DVA_document_tag[i],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
										ITK_CALL(AE_ask_all_dataset_named_refs(DVA_document_tag[i],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

										ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
										tc_strdup(Meetexpectation,&MeetexpectationDup);
										printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

										if(tc_strcmp(MeetexpectationDup,"N")==0)
										{
                                               tc_strdup("No",&MeetexpectationDupMM);
										}
										if(tc_strcmp(MeetexpectationDup,"Y")==0)
										{
                                               tc_strdup("Yes",&MeetexpectationDupMM);
										}
										if(tc_strcmp(MeetexpectationDup,"NA")==0)
										{
                                               tc_strdup("NA",&MeetexpectationDupMM);
										}


                                        if(DFQApplicablilitycheck1 == 1)
										{
										if(nFoundpdfs >= 1)
										{
											DFQpdfCount++;

										if((tc_strcmp(MeetexpectationDup,"Y")==0) || (tc_strcmp(MeetexpectationDup," ")==0))
											{
                                                MeetexpectationCnt++;
											}

										}
										}
										if(nFoundexcels == 1)
										{
											DFQexcelsCount++;
										}

										if (nFoundpdfs == 0)
										{
											tc_strdup("No",&Foundpdfs);
										}else{
											tc_strdup("Yes",&Foundpdfs);
										}

										if (nFoundexcels == 0)
										{
											tc_strdup("No",&Foundexcels);
										}else{
											tc_strdup("Yes",&Foundexcels);
										}

										printf("\n DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] MeetexpectationsDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDup);fflush(stdout);
										fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDupMM);

									  }
									
									 


									}
								}

								}

						   }

						 }
					   }
				  }
				 
            }
             else if(tc_strcmp(VCtypeNam, "CCVC")==0)
	        {

             tag_t	*snapshotObjSet		=NULLTAG;
			 tag_t Snapshot_tag			=NULLTAG;
			 tag_t snapshotObjTypeTag	=NULLTAG;
			 tag_t item_rev_tags		=NULLTAG;
			 tag_t window				=NULLTAG;
			 tag_t top_line				=NULLTAG;
			 tag_t Childobject1			=NULLTAG;
			 tag_t ChildMobject			=NULLTAG;
			 tag_t close_tag			=NULLTAG;
	         tag_t	*closurerule		=NULLTAG;
			 tag_t	*ColIndChilds		=NULLTAG;
			 tag_t	*Modulechilds		=NULLTAG;

			 //char*snapshotObjtype_name	=NULL;
			 char  snapshotObjtype_name[TCTYPE_name_size_c+1];
             char*ObjName				=NULL;
	         char**rulename				=NULL;
	         char**rulevalue			=NULL;
			 char*PartNums1Dup			=NULL;
			 char*PartNums1				=NULL;
			 char*PartRelCCProjcode=NULL;
			  
             char*Item_ID_str			=NULL;
             char*ModuleNameDup			=NULL;
             char*ModuleName			=NULL;
             char*ModuleNumstyp			=NULL;
			 char*ModuleNumstypDup		=NULL;
			 char*ModulePartRevsDup		=NULL;
			 char*ModulePartRevs		=NULL;
			 char*ModulePartRelStats	=NULL;
			 char*SSTopLineRev			=NULL;

			 PIE_scope_t scope;
			 scope=PIE_TEAMCENTER;

             int count1=0;
             int chld=0;
			 int snapshotCount=0;
			 int Item_ID=0;
			 int rulefound	=	0;
              //printf("inside the CCVC start**\n");fflush(stdout);
			 tc_strcpy(Csvpath,"");
             tc_strcpy(Csvpath,GCIDocPath);
			 sprintf(fsuccess_nam,"%s_%s_%s_DVA_Matrix_%s.csv",VPrtModNum,CurRe,CurSe,Data);
			 tc_strcat(Csvpath,fsuccess_nam);
			 file = fopen(Csvpath,"w");
			    
			 fprintf(file,",,,,DVA-DFQ MIS Report VC Wise,,date-%s,,,,,,\n",Data);
			 fprintf(file,",,,VC Number,%s,,Revision,%s,,Sequence,%s,,,\n",VPrtModNum,CurRe,CurSe);
			 fprintf(file,",,,Description,%s,,,,,,,\n",VPrtdesc);
			 fprintf(file,",,,VC Status,%s,,,,,,\n",partstsDup);
			 fprintf(file,",,,Owner,%s,,,,,,\n",Owner);
			 fprintf(file,",,,Last Updated,,,,,,,\n");
			 fprintf(file,",,,Project Name,%s,,,,,,\n",prjcodeDup);
			 fprintf(file,",,,Project Description,%s,,,,,,\n",ProjdescDup);
			 fprintf(file,"\n\n");
			    
			 fprintf(file,"Part Number,Revision,Sequence,DR/AR Status,Design Group/Module Address,Business Unit,Desc.,Owner,No of Use cases Mapped,Applicability Selected as 'NO',Use cases Applicability 'YES',DFQ UID,DVA Use case Description,Applicability,DVA Justification Comment,DFQ Documents Number,PDF,Xlsx,DVA Meet the Expectations (Yes/No)\n");

             //printf("inside the CCVC**\n");fflush(stdout);
		    ITK_CALL(AOM_ask_value_tags(VechRevTag,"T5_PartHasSnapShot",&snapshotCount,&snapshotObjSet));
			printf("\n WTRoll::snapshotCount \n::  %d ", snapshotCount);fflush(stdout);

				if(snapshotCount>0)
				   {
					printf("inside the snapshotCount**\n");fflush(stdout);
					 Snapshot_tag = NULLTAG;
					 snapshotObjTypeTag = NULLTAG;
					 Snapshot_tag = snapshotObjSet[0];
                     //printf(" the snapshotCount**\n");fflush(stdout);
					 ITK_CALL(TCTYPE_ask_object_type(Snapshot_tag,&snapshotObjTypeTag));
					 ITK_CALL(TCTYPE_ask_name(snapshotObjTypeTag,snapshotObjtype_name));
					 printf("\n CCVC snapshotObjtype_name := %s\n", snapshotObjtype_name);fflush(stdout);

					 ITK_CALL(AOM_ask_value_string(Snapshot_tag,"object_name",&ObjName));
					 printf(" ObjName***: [%s] \n", ObjName);fflush(stdout);

					 //if (AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev) != ITK_ok);
			        // if (AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags) != ITK_ok);
                      //printf(" the snapshotCount topline**\n");fflush(stdout);
					 ITK_CALL(AOM_UIF_ask_value(Snapshot_tag,"topLine",&SSTopLineRev));
					 ITK_CALL(AOM_ask_value_tag(Snapshot_tag,"topLine",&item_rev_tags));
                     printf(" Snapshot tag is***: [%s] \n", SSTopLineRev);fflush(stdout);

                      // printf(" the snapshotCount topline1**\n");fflush(stdout);
                     ITKCALL(BOM_create_window_from_snapshot(Snapshot_tag,&window));
					 ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
					 ITKCALL(BOM_set_window_pack_all (window, FALSE));
                     //printf("after top line**\n");fflush(stdout);
					
					

					ITK_CALL(PIE_find_closure_rules( "BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule ));
					 printf ("\nrule count %d \n",rulefound);fflush(stdout);
					 if (rulefound > 0)
					 {
						close_tag = closurerule[0];
						//printf ("closure rule found \n"); fflush(stdout);
					 }
					 ITKCALL(BOM_window_set_closure_rule( window,close_tag, 0, rulename,rulevalue ));
					 printf ("closure rule found applied \n"); fflush(stdout);
					// ITKCALL(BOM_set_window_pack_all (window, FALSE));
					 //ITKCALL(BOM_set_window_top_line (window,null_tag, item_rev_tags, null_tag, &top_line));
					 ITKCALL(BOM_window_set_absocc_edit_mode(window, TRUE));

					 ITKCALL(BOM_line_look_up_attribute ("bl_item_item_id",&Item_ID));
					 ITKCALL(BOM_line_ask_attribute_string(top_line, Item_ID, &Item_ID_str));
					 printf(" BOm line string is***: [%s] \n", Item_ID_str);fflush(stdout);
					 ITKCALL(BOM_line_ask_child_lines(top_line, &count, &ColIndChilds));
					 printf(" BOm line count is***: [%d] \n", count);fflush(stdout);

					 if (count >0)
					 {
					  for (ichld=0;ichld<count ;ichld++ )
					   {
							if(Childobject1) Childobject1=NULLTAG;
							Childobject1=ColIndChilds[ichld];

							ITK_CALL(AOM_ask_value_string(Childobject1,"bl_item_item_id",&PartNums1));
							tc_strdup(PartNums1,&PartNums1Dup);
							printf("\nPart number is in module*** [%s]",PartNums1Dup); fflush(stdout);


							ITKCALL(BOM_line_ask_child_lines(Childobject1, &count1, &Modulechilds));
							printf("\n module line count is***: [%d]", count1);fflush(stdout);

							if (count1 >0)
							{
							 printf("\n module line****************** count is****\n");fflush(stdout);

								for (chld=0;chld<count1 ;chld++ )
								{
									if(ChildMobject) ChildMobject=NULLTAG;
									ChildMobject=Modulechilds[chld];
									int resultCount1=0;

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_item_item_id",&ModuleName));
									tc_strdup(ModuleName,&ModuleNameDup);
									printf("\n module number is [%s]",ModuleNameDup); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartType",&ModuleNumstyp));
									tc_strdup(ModuleNumstyp,&ModuleNumstypDup);
									printf("\nPart type is [%s]",ModuleNumstypDup); fflush(stdout);

									
									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_rev_release_status_list",&ModulePartRelStats));
									printf("\nPart release is [%s]",ModulePartRelStats); fflush(stdout);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_rev_item_revision_id",&ModulePartRevs));
									tc_strdup(ModulePartRevs,&ModulePartRevsDup);
									printf("\nPart number revision [%s]",ModulePartRevsDup); fflush(stdout);

									 CurRevs = strtok(ModulePartRevsDup,";");
									 CurSeqs = strtok(NULL,";");

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_ModuleAddress",&ModuleAddressp));
									tc_strdup(ModuleAddressp,&ModuleAddresspDup);

									ITK_CALL(AOM_ask_value_string(ChildMobject,"bl_Design Revision_t5_PartStatus",&partst));
									tc_strdup(partst,&partstDup);

									ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_Design Revision_t5_CategoryName",&descp));
									tc_strdup(descp,&descpDup);
									STRNG_replace_str(descpDup,","," ",&descpDup);

									if(tc_strstr(ModulePartRelStats,"ERC Released")!=NULL)
							        {
									printf("\nPart [%s] Release Status [%s]",PartNums,PartRelStats); fflush(stdout);
									tc_strcpy(Owners,"Release Vault");
							        }

									if(tc_strcmp(ModuleNumstypDup,"M")==0)
									{
										  tag_t itemTagm	= NULLTAG;
										  tag_t itemRevTagm = NULLTAG;

										  ITK_CALL(getBusinessUnitFunct(ChildMobject, &ProjbussDup));
										  printf("\n t5_BussUnitType :[%s]\n",ProjbussDup);fflush(stdout);

										  ITK_CALL(AOM_UIF_ask_value(ChildMobject,"bl_Design Revision_t5_ProjectCode",&PartRelCCProjcode));
							              printf("\nPart project code is [%s]",PartRelCCProjcode); fflush(stdout);



										     
										  ITK_CALL(GetDVAUseCaseFromLibraryt(ChildMobject, ProjbussDup, &resultCount1, &dfq_use_case_tags));
										  printf("\n No of Use cases Mapped :[%d]\n",resultCount1);fflush(stdout);
										     
										  //Get DFQ Document Relation Class Type
										  
										  ITEM_find_item(ModuleName, &itemTagm);
										  //ITEM_ask_latest_rev(itemTagm,&itemRevTagm);
										  printf("\n checking :[%s],[%s]\n",ModuleName,ModulePartRevs);fflush(stdout);
										  ITEM_find_revision(itemTagm,ModulePartRevs,&itemRevTagm);
										     
										  GRM_find_relation_type("T5_DesignHasDVA",&relTypeTags);
										     
										  //Get Attached DFQ Documents
										  ITK_CALL(GRM_list_secondary_objects_only(itemRevTagm, relTypeTags, &DVA_result_counts,&DVA_document_tag));
										  printf("\n No of Attached DFQ Documetns are**m :: %d\n",DVA_result_counts);fflush(stdout);

										  int trueflagg=0;
									      int falseflagg=0;

                                        if (DVA_result_counts >0)
										{
											for (d=0;d<DVA_result_counts; d++ )
											{
												AOM_ask_value_logical(DVA_document_tag[d],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												if(DFQApplicablilitycheck1 == 1)
												{
													trueflagg++;
												}
												else
												{
													falseflagg++;
												}
											}
										}

										printf("\n PartNumDup [%s] CurRev [%s] CurSeq [%s]  partstsDup [%s] ModuleAddressDup [%s] ProjbussDup [%s] descDup[%s] Owner [%s] \n",ModuleNameDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,PrerevDRstat,ProjbussDup,descpDup,Owners);fflush(stdout);
										fprintf(file,"%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d \n",ModuleNameDup,CurRevs,CurSeqs,partstDup,ModuleAddresspDup,ProjbussDup,descpDup,Owners,resultCount1,falseflagg,trueflagg);


										  if (DVA_result_counts >0)
										  {
											  for (i=0;i<DVA_result_counts; i++ )
											  {
												AOM_ask_value_logical(DVA_document_tag[i],"t5_DFQApplicablility",&DFQApplicablilitycheck1);

												printf("\n DFQApplicablilitycheck [%d] ",DFQApplicablilitycheck1);

												AOM_ask_value_string(DVA_document_tag[i],"current_name",&DFQdocnos);
												tc_strdup(DFQdocnos,&DFQdocnosDup);

												 if(tc_strcmp(prjcodeDup,PartRelCCProjcode)==0)
                                                {

												AOM_ask_value_string(DVA_document_tag[i],"t5_DFQUID",&DFQUIDs);
												tc_strdup(DFQUIDs,&DFQUIDsDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[i],"object_desc",&DVADescs));
												tc_strdup(DVADescs,&DVADescsDup);

												STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup);

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQComment",&DFQComments));
										        tc_strdup(DFQComments,&DFQCommentsDup);

										        STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
										        STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

												if(DFQApplicablilitycheck1 == 1)
												{
													DFQApplCntflag++;
													tc_strdup("Yes",&DFQApplicablilitysDup);
											        printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													falseflagg++;
													tc_strdup("No",&DFQApplicablilitysDup);
											        printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);

												}

												ITK_CALL(AE_ask_all_dataset_named_refs(DVA_document_tag[i],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
												ITK_CALL(AE_ask_all_dataset_named_refs(DVA_document_tag[i],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
										        tc_strdup(Meetexpectation,&MeetexpectationDup);
										        printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);
										        
										        if(tc_strcmp(MeetexpectationDup,"N")==0)
										        {
                                                       tc_strdup("No",&MeetexpectationDupMM);
										        }
										        if(tc_strcmp(MeetexpectationDup,"Y")==0)
										        {
                                                       tc_strdup("Yes",&MeetexpectationDupMM);
										        }
										        if(tc_strcmp(MeetexpectationDup,"NA")==0)
										        {
                                                       tc_strdup("NA",&MeetexpectationDupMM);
										        }

												if(DFQApplicablilitycheck1 == 1)
												{
												if(nFoundpdfs >= 1)
												{
													DFQpdfCount++;

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
												tc_strdup(Meetexpectation,&MeetexpectationDup);
												printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

												if((tc_strcmp(MeetexpectationDup,"Y")==0) || (tc_strcmp(MeetexpectationDup," ")==0))
												{
													MeetexpectationCnt++;
												}

												}
												}
												if(nFoundexcels == 1)
												{
													DFQexcelsCount++;
												}

												if (nFoundpdfs == 0)
										        {
											     tc_strdup("No",&Foundpdfs);
										        }else{
											       tc_strdup("Yes",&Foundpdfs);
										        }

										       if (nFoundexcels == 0)
										      {
												tc_strdup("No",&Foundexcels);
										      }
											  else
											  {
												tc_strdup("Yes",&Foundexcels);
										      }

												printf("\n DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] MeetexpectationsDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDup);fflush(stdout);
												fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDupMM);
											}
											else if (tc_strstr(DFQdocnosDup,prjcodeDup)!=NULL)
												  {
												   AOM_ask_value_string(DVA_document_tag[i],"t5_DFQUID",&DFQUIDs);
												tc_strdup(DFQUIDs,&DFQUIDsDup);

												ITK_CALL(AOM_UIF_ask_value(DVA_document_tag[i],"object_desc",&DVADescs));
												tc_strdup(DVADescs,&DVADescsDup);

												STRNG_replace_str(DVADescsDup,","," ",&DVADescsDup);

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQComment",&DFQComments));
										        tc_strdup(DFQComments,&DFQCommentsDup);

										        STRNG_replace_str(DFQCommentsDup,","," ",&DFQCommentsDup);
										        STRNG_replace_str(DFQCommentsDup,"\n"," ",&DFQCommentsDup);

												if(DFQApplicablilitycheck1 == 1)
												{
													DFQApplCntflag++;
													tc_strdup("Yes",&DFQApplicablilitysDup);
											        printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);
												}
												else
												{
													falseflagg++;
													tc_strdup("No",&DFQApplicablilitysDup);
											        printf("\n DFQApplicablilityDup [%s] ",DFQApplicablilitysDup);fflush(stdout);

												}

												ITK_CALL(AE_ask_all_dataset_named_refs(DVA_document_tag[i],"T5_DFQ_PDF",&nFoundpdfs,&refobjpdfs));
												ITK_CALL(AE_ask_all_dataset_named_refs(DVA_document_tag[i],"T5_DFQ_EXCEL",&nFoundexcels,&refobjexcels));

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
										        tc_strdup(Meetexpectation,&MeetexpectationDup);
										        printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);
										        
										        if(tc_strcmp(MeetexpectationDup,"N")==0)
										        {
                                                       tc_strdup("No",&MeetexpectationDupMM);
										        }
										        if(tc_strcmp(MeetexpectationDup,"Y")==0)
										        {
                                                       tc_strdup("Yes",&MeetexpectationDupMM);
										        }
										        if(tc_strcmp(MeetexpectationDup,"NA")==0)
										        {
                                                       tc_strdup("NA",&MeetexpectationDupMM);
										        }

												if(DFQApplicablilitycheck1 == 1)
												{
												if(nFoundpdfs >= 1)
												{
													DFQpdfCount++;

												ITK_CALL(AOM_ask_value_string(DVA_document_tag[i],"t5_DFQMeetExp",&Meetexpectation));
												tc_strdup(Meetexpectation,&MeetexpectationDup);
												printf("\n MeetexpectationDup [%s] ",Meetexpectation);fflush(stdout);

												if((tc_strcmp(MeetexpectationDup,"Y")==0) || (tc_strcmp(MeetexpectationDup," ")==0))
												{
													MeetexpectationCnt++;
												}

												}
												}
												if(nFoundexcels == 1)
												{
													DFQexcelsCount++;
												}

												if (nFoundpdfs == 0)
										        {
											     tc_strdup("No",&Foundpdfs);
										        }else{
											       tc_strdup("Yes",&Foundpdfs);
										        }

										       if (nFoundexcels == 0)
										      {
												tc_strdup("No",&Foundexcels);
										      }
											  else
											  {
												tc_strdup("Yes",&Foundexcels);
										      }

												printf("\n DFQUIDDup [%s] DVADescDup [%s] DFQApplicablilityDup  [%s] DFQCommentDup [%s] DFQdocnoDup [%s] Foundpdf [%s] Foundexcel [%s] MeetexpectationsDup [%s]  \n",ProjbussDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDup);fflush(stdout);
												fprintf(file,",,,,,%s,,,,,,%s,%s,%s,%s,%s,%s,%s,%s\n",ProjbussDup,DFQUIDsDup,DVADescsDup,DFQApplicablilitysDup,DFQCommentsDup,DFQdocnosDup,Foundpdfs,Foundexcels,MeetexpectationDupMM);

												  }

												}
											}

									}
								}


							}

						}

					}

					}

			 }
			 else
	        {
                printf("\n this is not V/CCVC part \n");fflush(stdout);

	        }
			 fclose(file);
   
          if(Csvpath)
	      {
           
		   char*reference_nameGCI=NULL;
		   tag_t file_tag = NULLTAG;
	       IMF_file_t file_descriptor;
	       AE_reference_type_t tagRefTypeText = 1;

		     reference_nameGCI = (char *) MEM_alloc(10);

             printf("\n before named reference GCI %s",Csvpath); fflush(stdout);
		     tc_strcpy(reference_nameGCI,"T5_GCIDocRef");
			 printf("\n named reference GCI %s",reference_nameGCI); fflush(stdout);


            ITK_CALL(AOM_refresh(GCItag,TRUE));

            ITK_CALL(IMF_import_file(Csvpath,NULL, SS_BINARY, &file_tag, &file_descriptor));
			ITK_CALL(AOM_save(file_tag));
			
	        ITK_CALL(AE_add_dataset_named_ref2(GCItag,reference_nameGCI,tagRefTypeText,file_tag));
	        printf("\n after named reference GCI \n"); fflush(stdout);
			 
            ITK_CALL(AOM_save(GCItag));
	         //ITK_CALL(AOM_unload(file_tag));
			 ITK_CALL(AOM_refresh(GCItag,0));

             printf("\n Done named reference GCI \n"); fflush(stdout);
			
		  }

}







extern int ITK_user_main(int argc, char ** argv )
{
	int status				= ITK_ok;
     char*DvloNameStr=NULL;
     char*gcinam=NULL;
     char*VehicleNo=NULL;
	 char*VehicleRev=NULL;
     char*VehicleSeq=NULL;
     char*VehicleDR=NULL;
	 DvloNameStr	=(char *) MEM_alloc(sizeof(char)* 50);
	 VehicleNo	=(char *) MEM_alloc(sizeof(char)* 50);
	 VehicleSeq	=(char *) MEM_alloc(sizeof(char)* 50);
	 VehicleRev	=(char *) MEM_alloc(sizeof(char)* 50);
	 VehicleDR	=(char *) MEM_alloc(sizeof(char)* 50);
	 gcinam	=(char *) MEM_alloc(sizeof(char)* 50);
	  char*rev_id=NULL;
	 rev_id	=(char *) MEM_alloc(sizeof(char)* 50);
	 char*DvloName=NULL;
	 DvloName	=(char *) MEM_alloc(sizeof(char)* 50);


	 tag_t DitemTAG			 = NULLTAG;
	 tag_t VechRevTag		 = NULLTAG;
	 tag_t*GciObj=NULLTAG;
	 tag_t GCI_relation=NULLTAG;
	 tag_t Vechtag=NULLTAG;
	 tag_t GCItag=NULLTAG;
	 int gcicnt=0;
	 int gci=0;

	 
	char*	strDVA		=NULL;
	char*	strDSR		=NULL;
	char*	DVLODsetID	=NULL;
	char*	GCIStr		=NULL;

	int DemeritScore=0;
	int dsr=0;

	double GCI;
	double dVA;
	double dSR;
	double Strdsr;

	//cal
	//char*DvloName=NULL;
	//char*DScore=NULL;

	GCIStr= (char *) MEM_alloc(sizeof(char)* 10);

    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	ITK_CALL(ITK_auto_login());
	ITK_CALL(ITK_set_journalling( TRUE ));
	DvloNameStr = ITK_ask_cli_argument("-Gci=");

printf("\n DVLO--Input: [%s]  ",DvloNameStr);fflush(stdout);

if(DvloNameStr)
{

        gcinam = tc_strtok(DvloNameStr,"_");  
		VehicleNo = tc_strtok(NULL,"_");
		VehicleRev = tc_strtok(NULL,"_");
		VehicleSeq = tc_strtok(NULL,"_");
		VehicleDR = tc_strtok(NULL,"_");

		printf("vech,rev,seq,DR: %s,%s,%s,%s",VehicleNo,VehicleRev,VehicleSeq,VehicleDR);fflush(stdout);

        tc_strcpy(rev_id,"");
		tc_strcat(rev_id,VehicleRev);
		tc_strcat(rev_id,";");
		tc_strcat(rev_id,VehicleSeq);

        printf("\n Rev Input: [%s]  ",rev_id);fflush(stdout);


        ITEM_find_item(VehicleNo,&Vechtag);

		if(Vechtag != NULLTAG)
	    {
         ITEM_find_revision(Vechtag,rev_id,&VechRevTag);

         if(VechRevTag != NULLTAG)
		   {

           ITK_CALL(GRM_find_relation_type("T5_GCI_relation",&GCI_relation));

		   ITK_CALL(GRM_list_secondary_objects_only(VechRevTag,GCI_relation,&gcicnt,&GciObj));

		   for(gci=0;gci<gcicnt;gci++)
		  {
			printf("\n inside for loop\n");fflush(stdout);

			GCItag=GciObj[gci];

		  }
		   
		     printf("\n calling function SendVCdetailsForGCI\n");fflush(stdout);
		     SendVCdetailsForGCI(VechRevTag,GCItag);
			 printf("\n calling function SendVCdetailsForGCI end\n");fflush(stdout);


			 printf("\n\n DFQApplCntflag: [%d]  DFQpdfCount: [%d]  MeetexpectationCnt: [%d] \n", DFQApplCntflag,DFQpdfCount,MeetexpectationCnt);fflush(stdout);
	//tc_strdup(DVACalulate(),&strDVA);
	strDVA=DVACalulate();
	printf("\n strDVA= [%s] \n", strDVA);fflush(stdout);

	if(GCItag != NULLTAG)
	{

			//DemeritScore=((100*atoi(Pointer_100_Val)) + (40*atoi(Pointer_40_Val)) + (10*atoi(Pointer_10_Val)) + (20*atoi(Pointer_20_Val)) + (1*atoi(Pointer_1_Val)));
			ITK_CALL(AOM_ask_value_int(GCItag,"t5_demerit_score_v1",&DemeritScore));
			printf("\n Total DemeritScore: %d \n",DemeritScore);fflush(stdout);

			ITK_CALL(AOM_ask_value_string(GCItag,"t5_DVLO_Name1",&DvloName));
			printf("\n GCIName :[%s]\n",DvloName);fflush(stdout);

		  //tc_strdup(GetDemeritScoreRating(DvloName,DemeritScore),&strDSR);
			printf("calling GetDemeritScoreRating fun");fflush(stdout);
			strDSR=GetDemeritScoreRating(DvloName,DemeritScore);
			printf("  strDSR= [%s] ", strDSR);fflush(stdout);

		    if (strDVA!=NULL && strDSR!=NULL)
		    {
			 dVA=strtod(strDVA,NULL);
			 dSR=strtod(strDSR,NULL);
		    
			 printf("\n dVA: %lf   dSR: %lf ",dVA,dSR);fflush(stdout);
		    
			 GCI=((0.5*dSR) + (0.5*dVA));
		    
			 printf("\n  GCI-after calculation: %lf",GCI);fflush(stdout);
		    
			 sprintf(GCIStr,"%10lf",GCI);
			 printf("\n  after conversion  to GCIStr: %s \n",GCIStr);fflush(stdout);
		    
		    }

			if(DFQApplCntflag!=0)
			{
				dsr=atoi(strDSR);
				//ITK_CALL(AOM_lock(DVLONewDataset));
				ITK_CALL(AOM_refresh(GCItag,1));
					
				printf("\n before setting value GCI, strDSR, strDVA= %s,%s,%s\n",GCIStr,strDSR,strDVA);fflush(stdout);
					
				ITK_CALL(AOM_UIF_set_value(GCItag,"t5_DVA_value_d1",strDVA));						//double not supported		DVA value(D)
				ITK_CALL(AOM_set_value_int(GCItag,"t5_demerit_score_rating_S1",dsr));			//int not supported			DMU Demerit Score Rating(S)
				ITK_CALL(AOM_set_value_double(GCItag,"t5_geometry_conf_index_a1",GCI));		//double not supported		Geometry conformance Index(A)
				ITK_CALL(AOM_set_value_int(GCItag,"t5_demerit_score_v1",DemeritScore));			//int						DMU Demerit score(V)
					
				ITK_CALL(AOM_save(GCItag));
				printf("\n after saving GCI\n");fflush(stdout);
				ITK_CALL(AOM_refresh(GCItag,0));
			
			}
			else
			{
				dsr=atoi(strDSR);
				//ITK_CALL(AOM_lock(DVLONewDataset));  //check out dataset ---> ITK_CALL(AOM_refresh(DVLONewDataset,1));
				ITK_CALL(AOM_refresh(GCItag,1));
					
				printf("\n before setting value GCI, strDSR, strDVA1= %s,%s,%s\n",GCIStr,strDSR,strDVA);fflush(stdout);
					
				ITK_CALL(AOM_UIF_set_value(GCItag,"t5_DVA_value_d1",strDVA));					//double not supported		DVA value(D)
				ITK_CALL(AOM_set_value_int(GCItag,"t5_demerit_score_rating_S1",dsr));			//int not supported			DMU Demerit Score Rating(S)
					
				Strdsr=(double)dsr;
					
				printf("\n  GCI setting after type cast: %lf",Strdsr);fflush(stdout);
				ITK_CALL(AOM_set_value_double(GCItag,"t5_geometry_conf_index_a1",Strdsr));	//double not supported		Geometry conformance Index(A)
				ITK_CALL(AOM_set_value_int(GCItag,"t5_demerit_score_v1",DemeritScore));		//int						DMU Demerit score(V)
					
				ITK_CALL(AOM_save(GCItag));
				printf("\n after saving GCI*****\n");fflush(stdout);
				ITK_CALL(AOM_refresh(GCItag,0));												//checkin dataset
			
			}

	}

               


		  }
		 if(DFQApplCntflag>0)   
		{
			DFQApplCntflag=0; 
		}

		if(falseflagg>0)
		{
			falseflagg =0; 
		}

		if(DFQpdfCount>0)
		{
			DFQpdfCount=0;
		}

		if(DFQexcelsCount>0)
		{
			DFQexcelsCount=0; 
		}

		if(MeetexpectationCnt>0)
		{
			MeetexpectationCnt=0;
		}
	


	   }





}
       

	CLEANUP:
	ITK_CALL(POM_logout(false));
	return status;
	printf("\nCLEANUP...\n"); fflush(stdout);
}
