. /user/uaprodtrl/.bash_profile

/user/uaprodtrl/MIS/GCI_Updation -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -Gci=$1
echo "done"
