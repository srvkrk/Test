frmdate=$(date +"%d-%b-%Y" --date="100 days ago")
echo "$frmdate"
tomdate=$(date +"%d-%b-%Y" --date="0 Days ago")
echo "$tomdate"
echo "For 8 cronjob  >> Print_Release_ReportCheck"
nohup ./Print_Release_ReportCheck -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -fromdate=$frmdate -todate=$tomdate > cronjob2.log &