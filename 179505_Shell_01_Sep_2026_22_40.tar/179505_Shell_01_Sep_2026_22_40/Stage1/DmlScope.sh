. /user/cvprod/.bash_profile
#!/bin/bash
echo "In Shell DmlScope.sh start ..."
# DML_pdf_Dir=/user/testcmi/Dev/devgroups/vineet/Query/dump
DML_pdf_Dir=/tmp/dump
for i in `ls $DML_pdf_Dir`
do
ScopeDocument=`echo $i`
echo -e "Scope Document:\t\t:$ScopeDocument"
DMLNo=`echo "$i"| cut -c 6-15`
echo -e "DML NO:\t\t$DMLNo"
/user/cvprod/Program_Shells/DML_DCR/DMLScope/tm_ERC_DML_DMLScope -dmlno="$DMLNo"
echo "END"
done