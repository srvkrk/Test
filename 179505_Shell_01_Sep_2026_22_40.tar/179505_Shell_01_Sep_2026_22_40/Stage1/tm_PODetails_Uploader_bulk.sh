echo "Cronjob Shell Start Part PO details Uploader Program for CVPROD >> tm_PODetails_Uploader_bulk"
nohup ./tm_PODetails_Uploader_bulk -u="loader" -pf="/user/cvprod/shells/Admin/loaderpasswdFile.pwf" -g="dba" -i="list.txt" > list.log &
echo "Shell End Part PO details tm_PODetails_Uploader_bulk Program for CVPROD"