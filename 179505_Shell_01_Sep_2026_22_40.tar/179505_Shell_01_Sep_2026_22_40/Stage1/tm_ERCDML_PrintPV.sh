. /user/uaprod/.bash_profile
ssh uaprodtrl@172.22.97.18 -n "sh /user/uaprodtrl/Program_Shells/DML_DCR/tm_ERCDML_PrinttPV.sh $1"
echo "--Complete tm_ERCDML_PrintPV.sh from uaprod-- "
