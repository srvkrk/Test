#!/bin/ksh
. /user/cvprod/.bash_profile

#prod
pdfFileLocation=/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/PDFFiles
#movePdfToLocation=/user/uaprod/shells/4D
movePdfToLocation=/home/cvprod/CVPROD_4D_Shell
movePdfToLocationnew=/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/MovedFiles_TCUA


#BASE_PATH=/user/uaprod/shells/4D
BASE_PATH=/home/cvprod/CVPROD_4D_Shell
echo $BASE_PATH

cd $BASE_PATH
#for i in `ls -lt "$BASE_PATH"`
#echo "Begin PDF shell"
#do
rm -f shellInputfile.txt
rm -f ShellPdfFiles.txt
rm -f ShellWithoutClausesTxtFiles.txt
rm -f ShellClausesFiles.txt
rm -f ShellTxtFiles.txt

echo "Files removed"


echo $pdfFileLocation


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2999/' | cut -d'.' -f1`
do
echo "Begin processing for 2999 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2999 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2999/' | cut -d'.' -f1`
do
echo "Begin processing for 2999 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2999 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5713/' | cut -d'.' -f1`
do
echo "Begin processing for 5713 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5713 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5713/' | cut -d'.' -f1`
do
echo "Begin processing for 5713 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5713 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5195/' | cut -d'.' -f1`
do
echo "Begin processing for 5195 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5195 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5195/' | cut -d'.' -f1`
do
echo "Begin processing for 5195 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5195 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2747/' | cut -d'.' -f1`
do
echo "Begin processing for 2747 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2747 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2747/' | cut -d'.' -f1`
do
echo "Begin processing for 2747 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2747 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5218/' | cut -d'.' -f1`
do
echo "Begin processing for 5218 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5218 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5218/' | cut -d'.' -f1`
do
echo "Begin processing for 5218 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5218 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5710/' | cut -d'.' -f1`
do
echo "Begin processing for 5710 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5710 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5710/' | cut -d'.' -f1`
do
echo "Begin processing for 5710 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5710 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5550/' | cut -d'.' -f1`
do
echo "Begin processing for 5550 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5550 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5550/' | cut -d'.' -f1`
do
echo "Begin processing for 5550 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5550 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2073/' | cut -d'.' -f1`
do
echo "Begin processing for 2073 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2073 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2073/' | cut -d'.' -f1`
do
echo "Begin processing for 2073 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2073 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2075/' | cut -d'.' -f1`
do
echo "Begin processing for 2075 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2075 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2075/' | cut -d'.' -f1`
do
echo "Begin processing for 2075 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2075 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2084/' | cut -d'.' -f1`
do
echo "Begin processing for 2084 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2084 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2084/' | cut -d'.' -f1`
do
echo "Begin processing for 2084 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2084 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2099/' | cut -d'.' -f1`
do
echo "Begin processing for 2099 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2099 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2099/' | cut -d'.' -f1`
do
echo "Begin processing for 2099 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2099 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2152/' | cut -d'.' -f1`
do
echo "Begin processing for 2152 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2152 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2152/' | cut -d'.' -f1`
do
echo "Begin processing for 2152 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2152 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2163/' | cut -d'.' -f1`
do
echo "Begin processing for 2163 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2163 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2163/' | cut -d'.' -f1`
do
echo "Begin processing for 2163 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2163 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2165/' | cut -d'.' -f1`
do
echo "Begin processing for 2165 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2165 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2165/' | cut -d'.' -f1`
do
echo "Begin processing for 2165 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2165 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2171/' | cut -d'.' -f1`
do
echo "Begin processing for 2171 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2171 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2171/' | cut -d'.' -f1`
do
echo "Begin processing for 2171 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2171 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2202/' | cut -d'.' -f1`
do
echo "Begin processing for 2202 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2202 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2202/' | cut -d'.' -f1`
do
echo "Begin processing for 2202 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2202 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2240/' | cut -d'.' -f1`
do				
echo "Begin processing for 2240 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2240 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2240/' | cut -d'.' -f1`
do				
echo "Begin processing for 2240 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2240 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2574/' | cut -d'.' -f1`
do				
echo "Begin processing for 2574 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2574 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2574/' | cut -d'.' -f1`
do				
echo "Begin processing for 2574 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2574 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2591/' | cut -d'.' -f1`
do				
echo "Begin processing for 2591 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2591 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2591/' | cut -d'.' -f1`
do				
echo "Begin processing for 2591 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2591 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2592/' | cut -d'.' -f1`
do				
echo "Begin processing for 2592 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2592 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2592/' | cut -d'.' -f1`
do				
echo "Begin processing for 2592 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2592 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2600/' | cut -d'.' -f1`
do				
echo "Begin processing for 2600 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2600 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2600/' | cut -d'.' -f1`
do				
echo "Begin processing for 2600 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2600 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2610/' | cut -d'.' -f1`
do				
echo "Begin processing for 2610 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2610 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2610/' | cut -d'.' -f1`
do				
echo "Begin processing for 2610 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2610 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2641/' | cut -d'.' -f1`
do				
echo "Begin processing for 2641 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2641 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2641/' | cut -d'.' -f1`
do				
echo "Begin processing for 2641 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2641 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2642/' | cut -d'.' -f1`
do				
echo "Begin processing for 2642 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2642 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2642/' | cut -d'.' -f1`
do				
echo "Begin processing for 2642 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2642 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2647/' | cut -d'.' -f1`
do				
echo "Begin processing for 2647 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2647 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2647/' | cut -d'.' -f1`
do				
echo "Begin processing for 2647 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2647 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2651/' | cut -d'.' -f1`
do				
echo "Begin processing for 2651 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2651 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2651/' | cut -d'.' -f1`
do				
echo "Begin processing for 2651 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2651 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2652/' | cut -d'.' -f1`
do				
echo "Begin processing for 2652 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2652 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2652/' | cut -d'.' -f1`
do				
echo "Begin processing for 2652 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2652 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2654/' | cut -d'.' -f1`
do				
echo "Begin processing for 2654 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2654 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2654/' | cut -d'.' -f1`
do				
echo "Begin processing for 2654 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2654 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2673/' | cut -d'.' -f1`
do				
echo "Begin processing for 2673 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2673 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2673/' | cut -d'.' -f1`
do				
echo "Begin processing for 2673 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2673 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2674/' | cut -d'.' -f1`
do				
echo "Begin processing for 2674 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2674 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2674/' | cut -d'.' -f1`
do				
echo "Begin processing for 2674 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2674 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2679/' | cut -d'.' -f1`
do				
echo "Begin processing for 2679 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2679 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2679/' | cut -d'.' -f1`
do				
echo "Begin processing for 2679 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2679 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2680/' | cut -d'.' -f1`
do				
echo "Begin processing for 2680 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2680 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2680/' | cut -d'.' -f1`
do				
echo "Begin processing for 2680 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2680 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2705/' | cut -d'.' -f1`
do				
echo "Begin processing for 2705 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2705 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2705/' | cut -d'.' -f1`
do				
echo "Begin processing for 2705 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2705 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2742/' | cut -d'.' -f1`
do				
echo "Begin processing for 2742 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2742 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2742/' | cut -d'.' -f1`
do				
echo "Begin processing for 2742 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2742 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2745/' | cut -d'.' -f1`
do				
echo "Begin processing for 2745 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2745 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2745/' | cut -d'.' -f1`
do				
echo "Begin processing for 2745 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2745 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2751/' | cut -d'.' -f1`
do				
echo "Begin processing for 2751 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2751 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2751/' | cut -d'.' -f1`
do				
echo "Begin processing for 2751 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2751 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2753/' | cut -d'.' -f1`
do				
echo "Begin processing for 2753 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2753 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2753/' | cut -d'.' -f1`
do				
echo "Begin processing for 2753 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2753 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2754/' | cut -d'.' -f1`
do				
echo "Begin processing for 2754 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2754 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2754/' | cut -d'.' -f1`
do				
echo "Begin processing for 2754 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2754 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2770/' | cut -d'.' -f1`
do				
echo "Begin processing for 2770 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2770 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2770/' | cut -d'.' -f1`
do				
echo "Begin processing for 2770 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2770 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2776/' | cut -d'.' -f1`
do				
echo "Begin processing for 2776 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2776 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2776/' | cut -d'.' -f1`
do				
echo "Begin processing for 2776 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2776 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2815/' | cut -d'.' -f1`
do				
echo "Begin processing for 2815 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2815 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2815/' | cut -d'.' -f1`
do				
echo "Begin processing for 2815 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2815 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2816/' | cut -d'.' -f1`
do				
echo "Begin processing for 2816 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2816 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2816/' | cut -d'.' -f1`
do				
echo "Begin processing for 2816 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2816 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2818/' | cut -d'.' -f1`
do				
echo "Begin processing for 2818 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2818 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2818/' | cut -d'.' -f1`
do				
echo "Begin processing for 2818 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2818 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2821/' | cut -d'.' -f1`
do				
echo "Begin processing for 2821 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2821 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2821/' | cut -d'.' -f1`
do				
echo "Begin processing for 2821 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2821 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2829/' | cut -d'.' -f1`
do				
echo "Begin processing for 2829 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2829 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2829/' | cut -d'.' -f1`
do				
echo "Begin processing for 2829 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2829 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2832/' | cut -d'.' -f1`
do				
echo "Begin processing for 2832 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2832 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2832/' | cut -d'.' -f1`
do				
echo "Begin processing for 2832 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2832 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2841/' | cut -d'.' -f1`
do				
echo "Begin processing for 2841 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2841 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2841/' | cut -d'.' -f1`
do				
echo "Begin processing for 2841 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2841 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2845/' | cut -d'.' -f1`
do				
echo "Begin processing for 2845 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2845 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2845/' | cut -d'.' -f1`
do				
echo "Begin processing for 2845 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2845 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2885/' | cut -d'.' -f1`
do				
echo "Begin processing for 2885 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2885 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2885/' | cut -d'.' -f1`
do				
echo "Begin processing for 2885 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2885 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2894/' | cut -d'.' -f1`
do				
echo "Begin processing for 2894 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2894 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2894/' | cut -d'.' -f1`
do				
echo "Begin processing for 2894 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2894 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2896/' | cut -d'.' -f1`
do				
echo "Begin processing for 2896 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2896 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2896/' | cut -d'.' -f1`
do				
echo "Begin processing for 2896 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2896 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2897/' | cut -d'.' -f1`
do				
echo "Begin processing for 2897 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2897 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2897/' | cut -d'.' -f1`
do				
echo "Begin processing for 2897 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2897 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2898/' | cut -d'.' -f1`
do				
echo "Begin processing for 2898 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2898 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2898/' | cut -d'.' -f1`
do				
echo "Begin processing for 2898 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2898 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2900/' | cut -d'.' -f1`
do				
echo "Begin processing for 2900 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2900 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2900/' | cut -d'.' -f1`
do				
echo "Begin processing for 2900 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2900 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2910/' | cut -d'.' -f1`
do				
echo "Begin processing for 2910 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2910 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2910/' | cut -d'.' -f1`
do				
echo "Begin processing for 2910 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 2910 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_3505/' | cut -d'.' -f1`
do				
echo "Begin processing for 3505 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 3505 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_3505/' | cut -d'.' -f1`
do				
echo "Begin processing for 3505 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 3505 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_4103/' | cut -d'.' -f1`
do				
echo "Begin processing for 4103 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 4103 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_4103/' | cut -d'.' -f1`
do				
echo "Begin processing for 4103 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 4103 TXT "
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5017/' | cut -d'.' -f1`
do				
echo "Begin processing for 5017 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5017 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5017/' | cut -d'.' -f1`
do				
echo "Begin processing for 5017 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5017 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5020/' | cut -d'.' -f1`
do				
echo "Begin processing for 5020 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5020 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5020/' | cut -d'.' -f1`
do				
echo "Begin processing for 5020 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5020 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5021/' | cut -d'.' -f1`
do				
echo "Begin processing for 5021 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5021 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5021/' | cut -d'.' -f1`
do				
echo "Begin processing for 5021 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5021 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5023/' | cut -d'.' -f1`
do				
echo "Begin processing for 5023 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5023 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5023/' | cut -d'.' -f1`
do				
echo "Begin processing for 5023 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5023 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5024/' | cut -d'.' -f1`
do				
echo "Begin processing for 5024 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5024 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5024/' | cut -d'.' -f1`
do				
echo "Begin processing for 5024 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5024 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5027/' | cut -d'.' -f1`
do				
echo "Begin processing for 5027 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5027 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5027/' | cut -d'.' -f1`
do				
echo "Begin processing for 5027 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5027 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5032/' | cut -d'.' -f1`
do				
echo "Begin processing for 5032 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5032 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5032/' | cut -d'.' -f1`
do				
echo "Begin processing for 5032 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5032 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5034/' | cut -d'.' -f1`
do				
echo "Begin processing for 5034 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5034 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5034/' | cut -d'.' -f1`
do				
echo "Begin processing for 5034 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5034 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5039/' | cut -d'.' -f1`
do				
echo "Begin processing for 5039 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5039 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5039/' | cut -d'.' -f1`
do				
echo "Begin processing for 5039 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5039 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5040/' | cut -d'.' -f1`
do				
echo "Begin processing for 5040 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5040 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5040/' | cut -d'.' -f1`
do				
echo "Begin processing for 5040 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5040 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5062/' | cut -d'.' -f1`
do				
echo "Begin processing for 5062 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5062 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5062/' | cut -d'.' -f1`
do				
echo "Begin processing for 5062 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5062 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5084/' | cut -d'.' -f1`
do				
echo "Begin processing for 5084 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5084 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5084/' | cut -d'.' -f1`
do				
echo "Begin processing for 5084 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5084 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5089/' | cut -d'.' -f1`
do				
echo "Begin processing for 5089 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5089 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5089/' | cut -d'.' -f1`
do				
echo "Begin processing for 5089 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5089 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5117/' | cut -d'.' -f1`
do				
echo "Begin processing for 5117 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5117 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5117/' | cut -d'.' -f1`
do				
echo "Begin processing for 5117 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5117 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5118/' | cut -d'.' -f1`
do				
echo "Begin processing for 5118 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5118 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5118/' | cut -d'.' -f1`
do				
echo "Begin processing for 5118 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5118 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5119/' | cut -d'.' -f1`
do				
echo "Begin processing for 5119 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5119 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5119/' | cut -d'.' -f1`
do				
echo "Begin processing for 5119 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5119 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5120/' | cut -d'.' -f1`
do				
echo "Begin processing for 5120 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5120 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5120/' | cut -d'.' -f1`
do				
echo "Begin processing for 5120 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5120 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5126/' | cut -d'.' -f1`
do				
echo "Begin processing for 5126 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5126 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5126/' | cut -d'.' -f1`
do				
echo "Begin processing for 5126 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5126 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5127/' | cut -d'.' -f1`
do				
echo "Begin processing for 5127 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5127 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5127/' | cut -d'.' -f1`
do				
echo "Begin processing for 5127 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5127 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5137/' | cut -d'.' -f1`
do				
echo "Begin processing for 5137 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5137 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5137/' | cut -d'.' -f1`
do				
echo "Begin processing for 5137 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5137 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5147/' | cut -d'.' -f1`
do				
echo "Begin processing for 5147 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5147 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5147/' | cut -d'.' -f1`
do				
echo "Begin processing for 5147 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5147 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5148/' | cut -d'.' -f1`
do				
echo "Begin processing for 5148 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5148 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5148/' | cut -d'.' -f1`
do				
echo "Begin processing for 5148 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5148 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5150/' | cut -d'.' -f1`
do				
echo "Begin processing for 5150 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5150 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5150/' | cut -d'.' -f1`
do				
echo "Begin processing for 5150 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5150 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5152/' | cut -d'.' -f1`
do				
echo "Begin processing for 5152 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5152 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5152/' | cut -d'.' -f1`
do				
echo "Begin processing for 5152 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5152 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5153/' | cut -d'.' -f1`
do				
echo "Begin processing for 5153 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5153 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5153/' | cut -d'.' -f1`
do				
echo "Begin processing for 5153 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5153 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5154/' | cut -d'.' -f1`
do				
echo "Begin processing for 5154 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5154 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5154/' | cut -d'.' -f1`
do				
echo "Begin processing for 5154 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5154 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5155/' | cut -d'.' -f1`
do				
echo "Begin processing for 5155 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5155 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5155/' | cut -d'.' -f1`
do				
echo "Begin processing for 5155 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5155 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5156/' | cut -d'.' -f1`
do				
echo "Begin processing for 5156 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5156 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5156/' | cut -d'.' -f1`
do				
echo "Begin processing for 5156 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5156 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5157/' | cut -d'.' -f1`
do				
echo "Begin processing for 5157 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5157 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5157/' | cut -d'.' -f1`
do				
echo "Begin processing for 5157 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5157 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5158/' | cut -d'.' -f1`
do				
echo "Begin processing for 5158 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5158 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5158/' | cut -d'.' -f1`
do				
echo "Begin processing for 5158 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5158 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5159/' | cut -d'.' -f1`
do				
echo "Begin processing for 5159 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5159 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5159/' | cut -d'.' -f1`
do				
echo "Begin processing for 5159 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5159 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5160/' | cut -d'.' -f1`
do				
echo "Begin processing for 5160 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5160 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5160/' | cut -d'.' -f1`
do				
echo "Begin processing for 5160 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5160 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5161/' | cut -d'.' -f1`
do				
echo "Begin processing for 5161 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5161 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5161/' | cut -d'.' -f1`
do				
echo "Begin processing for 5161 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5161 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5162/' | cut -d'.' -f1`
do				
echo "Begin processing for 5162 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5162 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5162/' | cut -d'.' -f1`
do				
echo "Begin processing for 5162 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5162 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5163/' | cut -d'.' -f1`
do				
echo "Begin processing for 5163 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5163 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5163/' | cut -d'.' -f1`
do				
echo "Begin processing for 5163 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5163 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5164/' | cut -d'.' -f1`
do				
echo "Begin processing for 5164 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5164 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5164/' | cut -d'.' -f1`
do				
echo "Begin processing for 5164 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5164 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5165/' | cut -d'.' -f1`
do				
echo "Begin processing for 5165 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5165 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5165/' | cut -d'.' -f1`
do				
echo "Begin processing for 5165 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5165 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5166/' | cut -d'.' -f1`
do				
echo "Begin processing for 5166 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5166 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5166/' | cut -d'.' -f1`
do				
echo "Begin processing for 5166 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5166 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5167/' | cut -d'.' -f1`
do				
echo "Begin processing for 5167 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5167 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5167/' | cut -d'.' -f1`
do				
echo "Begin processing for 5167 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5167 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5168/' | cut -d'.' -f1`
do				
echo "Begin processing for 5168 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5168 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5168/' | cut -d'.' -f1`
do				
echo "Begin processing for 5168 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5168 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5169/' | cut -d'.' -f1`
do				
echo "Begin processing for 5169 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5169 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5169/' | cut -d'.' -f1`
do				
echo "Begin processing for 5169 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5169 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5170/' | cut -d'.' -f1`
do				
echo "Begin processing for 5170 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5170 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5170/' | cut -d'.' -f1`
do				
echo "Begin processing for 5170 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5170 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5171/' | cut -d'.' -f1`
do				
echo "Begin processing for 5171 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5171 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5171/' | cut -d'.' -f1`
do				
echo "Begin processing for 5171 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5171 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5172/' | cut -d'.' -f1`
do				
echo "Begin processing for 5172 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5172 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5172/' | cut -d'.' -f1`
do				
echo "Begin processing for 5172 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5172 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5174/' | cut -d'.' -f1`
do				
echo "Begin processing for 5174 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5174 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5174/' | cut -d'.' -f1`
do				
echo "Begin processing for 5174 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5174 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5175/' | cut -d'.' -f1`
do				
echo "Begin processing for 5175 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5175 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5175/' | cut -d'.' -f1`
do				
echo "Begin processing for 5175 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5175 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5176/' | cut -d'.' -f1`
do				
echo "Begin processing for 5176 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5176 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5176/' | cut -d'.' -f1`
do				
echo "Begin processing for 5176 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5176 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5177/' | cut -d'.' -f1`
do				
echo "Begin processing for 5177 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5177 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5177/' | cut -d'.' -f1`
do				
echo "Begin processing for 5177 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5177 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5178/' | cut -d'.' -f1`
do				
echo "Begin processing for 5178 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5178 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5178/' | cut -d'.' -f1`
do				
echo "Begin processing for 5178 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5178 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5179/' | cut -d'.' -f1`
do				
echo "Begin processing for 5179 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5179 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5179/' | cut -d'.' -f1`
do				
echo "Begin processing for 5179 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5179 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5180/' | cut -d'.' -f1`
do				
echo "Begin processing for 5180 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5180 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5180/' | cut -d'.' -f1`
do				
echo "Begin processing for 5180 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5180 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5181/' | cut -d'.' -f1`
do				
echo "Begin processing for 5181 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5181 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5181/' | cut -d'.' -f1`
do				
echo "Begin processing for 5181 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5181 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5182/' | cut -d'.' -f1`
do				
echo "Begin processing for 5182 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5182 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5182/' | cut -d'.' -f1`
do				
echo "Begin processing for 5182 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5182 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5183/' | cut -d'.' -f1`
do				
echo "Begin processing for 5183 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5183 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5183/' | cut -d'.' -f1`
do				
echo "Begin processing for 5183 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5183 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5184/' | cut -d'.' -f1`
do				
echo "Begin processing for 5184 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5184 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5184/' | cut -d'.' -f1`
do				
echo "Begin processing for 5184 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5184 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5185/' | cut -d'.' -f1`
do				
echo "Begin processing for 5185 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5185 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5185/' | cut -d'.' -f1`
do				
echo "Begin processing for 5185 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5185 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5187/' | cut -d'.' -f1`
do				
echo "Begin processing for 5187 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5187 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5187/' | cut -d'.' -f1`
do				
echo "Begin processing for 5187 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5187 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5192/' | cut -d'.' -f1`
do				
echo "Begin processing for 5192 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5192 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5192/' | cut -d'.' -f1`
do				
echo "Begin processing for 5192 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5192 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5193/' | cut -d'.' -f1`
do				
echo "Begin processing for 5193 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5193 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5193/' | cut -d'.' -f1`
do				
echo "Begin processing for 5193 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5193 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5201/' | cut -d'.' -f1`
do				
echo "Begin processing for 5201 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5201 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5201/' | cut -d'.' -f1`
do				
echo "Begin processing for 5201 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5201 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5202/' | cut -d'.' -f1`
do				
echo "Begin processing for 5202 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5202 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5202/' | cut -d'.' -f1`
do				
echo "Begin processing for 5202 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5202 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5203/' | cut -d'.' -f1`
do				
echo "Begin processing for 5203 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5203 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5203/' | cut -d'.' -f1`
do				
echo "Begin processing for 5203 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5203 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5204/' | cut -d'.' -f1`
do				
echo "Begin processing for 5204 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5204 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5204/' | cut -d'.' -f1`
do				
echo "Begin processing for 5204 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5204 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5206/' | cut -d'.' -f1`
do				
echo "Begin processing for 5206 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5206 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5206/' | cut -d'.' -f1`
do				
echo "Begin processing for 5206 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5206 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5207/' | cut -d'.' -f1`
do				
echo "Begin processing for 5207 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5207 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5207/' | cut -d'.' -f1`
do				
echo "Begin processing for 5207 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5207 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5208/' | cut -d'.' -f1`
do				
echo "Begin processing for 5208 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5208 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5208/' | cut -d'.' -f1`
do				
echo "Begin processing for 5208 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5208 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5209/' | cut -d'.' -f1`
do				
echo "Begin processing for 5209 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5209 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5209/' | cut -d'.' -f1`
do				
echo "Begin processing for 5209 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5209 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5709/' | cut -d'.' -f1`
do
echo "Begin processing for 5709 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5709 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5709/' | cut -d'.' -f1`
do
echo "Begin processing for 5709 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5709 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2534/' | cut -d'.' -f1`
do
echo "Begin processing for 2534 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2534 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2534/' | cut -d'.' -f1`
do
echo "Begin processing for 2534 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2534 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5080/' | cut -d'.' -f1`
do
echo "Begin processing for 5080 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5080 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5080/' | cut -d'.' -f1`
do
echo "Begin processing for 5080 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5080 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2527/' | cut -d'.' -f1`
do
echo "Begin processing for 2527 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2527 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2527/' | cut -d'.' -f1`
do
echo "Begin processing for 2527 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2527 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5706/' | cut -d'.' -f1`
do
echo "Begin processing for 5706 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5706 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5706/' | cut -d'.' -f1`
do
echo "Begin processing for 5706 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5706 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5701/' | cut -d'.' -f1`
do
echo "Begin processing for 5701 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5701 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5701/' | cut -d'.' -f1`
do
echo "Begin processing for 5701 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5701 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5020/' | cut -d'.' -f1`
do
echo "Begin processing for 5020 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5020 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5020/' | cut -d'.' -f1`
do
echo "Begin processing for 5020 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5020 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2789/' | cut -d'.' -f1`
do
echo "Begin processing for 2789 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2789 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2789/' | cut -d'.' -f1`
do
echo "Begin processing for 2789 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2789 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5735/' | cut -d'.' -f1`
do
echo "Begin processing for 5735 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5735 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5735/' | cut -d'.' -f1`
do
echo "Begin processing for 5735 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5735 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2724/' | cut -d'.' -f1`
do
echo "Begin processing for 2724 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2724 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2724/' | cut -d'.' -f1`
do
echo "Begin processing for 2724 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2724 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5737/' | cut -d'.' -f1`
do
echo "Begin processing for 5737 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5737 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5737/' | cut -d'.' -f1`
do
echo "Begin processing for 5737 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5737 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2525/' | cut -d'.' -f1`
do
echo "Begin processing for 2525 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2525 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2525/' | cut -d'.' -f1`
do
echo "Begin processing for 2525 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2525 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2726/' | cut -d'.' -f1`
do
echo "Begin processing for 2726 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2726 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2726/' | cut -d'.' -f1`
do
echo "Begin processing for 2726 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2726 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2851/' | cut -d'.' -f1`
do
echo "Begin processing for 2851 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2851 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2851/' | cut -d'.' -f1`
do
echo "Begin processing for 2851 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2851 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5736/' | cut -d'.' -f1`
do
echo "Begin processing for 5736 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5736 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5736/' | cut -d'.' -f1`
do
echo "Begin processing for 5736 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5736 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5810/' | cut -d'.' -f1`
do
echo "Begin processing for 5810 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5810 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5810/' | cut -d'.' -f1`
do
echo "Begin processing for 5810 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5810 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5803/' | cut -d'.' -f1`
do
echo "Begin processing for 5803 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5803 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5803/' | cut -d'.' -f1`
do
echo "Begin processing for 5803 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5803 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2661/' | cut -d'.' -f1`
do
echo "Begin processing for 2661 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2661 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2661/' | cut -d'.' -f1`
do
echo "Begin processing for 2661 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2661 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5830/' | cut -d'.' -f1`
do
echo "Begin processing for 5830 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5830 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5830/' | cut -d'.' -f1`
do
echo "Begin processing for 5830 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5830 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2715/' | cut -d'.' -f1`
do
echo "Begin processing for 2715 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2715 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2715/' | cut -d'.' -f1`
do
echo "Begin processing for 2715 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2715 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5841/' | cut -d'.' -f1`
do
echo "Begin processing for 5841 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5841 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5841/' | cut -d'.' -f1`
do
echo "Begin processing for 5841 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5841 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2850/' | cut -d'.' -f1`
do
echo "Begin processing for 2850 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2850 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2850/' | cut -d'.' -f1`
do
echo "Begin processing for 2850 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2850 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2855/' | cut -d'.' -f1`
do
echo "Begin processing for 2855 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2855 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2855/' | cut -d'.' -f1`
do
echo "Begin processing for 2855 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2855 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2732/' | cut -d'.' -f1`
do
echo "Begin processing for 2732 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2732 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2732/' | cut -d'.' -f1`
do
echo "Begin processing for 2732 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2732 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2691/' | cut -d'.' -f1`
do
echo "Begin processing for 2691 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2691 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2691/' | cut -d'.' -f1`
do
echo "Begin processing for 2691 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2691 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5817/' | cut -d'.' -f1`
do
echo "Begin processing for 5817 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5817 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5817/' | cut -d'.' -f1`
do
echo "Begin processing for 5817 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5817 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5805/' | cut -d'.' -f1`
do
echo "Begin processing for 5805 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5805 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5805/' | cut -d'.' -f1`
do
echo "Begin processing for 5805 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5805 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5857/' | cut -d'.' -f1`
do
echo "Begin processing for 5857 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5857 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5857/' | cut -d'.' -f1`
do
echo "Begin processing for 5857 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5857 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2663/' | cut -d'.' -f1`
do
echo "Begin processing for 2663 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2663 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2663/' | cut -d'.' -f1`
do
echo "Begin processing for 2663 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2663 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5829/' | cut -d'.' -f1`
do
echo "Begin processing for 5829 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5829 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5829/' | cut -d'.' -f1`
do
echo "Begin processing for 5829 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5829 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2665/' | cut -d'.' -f1`
do
echo "Begin processing for 2665 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2665 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2665/' | cut -d'.' -f1`
do
echo "Begin processing for 2665 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2665 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2736/' | cut -d'.' -f1`
do
echo "Begin processing for 2736 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2736 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2736/' | cut -d'.' -f1`
do
echo "Begin processing for 2736 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2736 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5836/' | cut -d'.' -f1`
do
echo "Begin processing for 5836 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5836 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5836/' | cut -d'.' -f1`
do
echo "Begin processing for 5836 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5836 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2668/' | cut -d'.' -f1`
do
echo "Begin processing for 2668 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2668 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2668/' | cut -d'.' -f1`
do
echo "Begin processing for 2668 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2668 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2684/' | cut -d'.' -f1`
do
echo "Begin processing for 2684 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2684 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2684/' | cut -d'.' -f1`
do
echo "Begin processing for 2684 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2684 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2730/' | cut -d'.' -f1`
do
echo "Begin processing for 2730 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2730 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2730/' | cut -d'.' -f1`
do
echo "Begin processing for 2730 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2730 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2739/' | cut -d'.' -f1`
do
echo "Begin processing for 2739 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2739 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2739/' | cut -d'.' -f1`
do
echo "Begin processing for 2739 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2739 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5845/' | cut -d'.' -f1`
do
echo "Begin processing for 5845 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5845 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5845/' | cut -d'.' -f1`
do
echo "Begin processing for 5845 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5845 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2687/' | cut -d'.' -f1`
do
echo "Begin processing for 2687 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2687 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2687/' | cut -d'.' -f1`
do
echo "Begin processing for 2687 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2687 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2854/' | cut -d'.' -f1`
do
echo "Begin processing for 2854 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2854 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2854/' | cut -d'.' -f1`
do
echo "Begin processing for 2854 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2854 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5843/' | cut -d'.' -f1`
do
echo "Begin processing for 5843 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5843 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5843/' | cut -d'.' -f1`
do
echo "Begin processing for 5843 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5843 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2727/' | cut -d'.' -f1`
do
echo "Begin processing for 2727 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2727 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2727/' | cut -d'.' -f1`
do
echo "Begin processing for 2727 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2727 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2069/' | cut -d'.' -f1`
do
echo "Begin processing for 2069 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2069 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2069/' | cut -d'.' -f1`
do
echo "Begin processing for 2069 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2069 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2076/' | cut -d'.' -f1`
do
echo "Begin processing for 2076 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2076 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2076/' | cut -d'.' -f1`
do
echo "Begin processing for 2076 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2076 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2786/' | cut -d'.' -f1`
do
echo "Begin processing for 2786 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2786 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2786/' | cut -d'.' -f1`
do
echo "Begin processing for 2786 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2786 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2863/' | cut -d'.' -f1`
do
echo "Begin processing for 2863 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2863 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2863/' | cut -d'.' -f1`
do
echo "Begin processing for 2863 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2863 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5716/' | cut -d'.' -f1`
do
echo "Begin processing for 5716 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5716 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5716/' | cut -d'.' -f1`
do
echo "Begin processing for 5716 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5716 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5719/' | cut -d'.' -f1`
do
echo "Begin processing for 5719 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5719 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5719/' | cut -d'.' -f1`
do
echo "Begin processing for 5719 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5719 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5821/' | cut -d'.' -f1`
do
echo "Begin processing for 5821 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5821 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5821/' | cut -d'.' -f1`
do
echo "Begin processing for 5821 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5821 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5723/' | cut -d'.' -f1`
do
echo "Begin processing for 5723 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5723 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5723/' | cut -d'.' -f1`
do
echo "Begin processing for 5723 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5723 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5826/' | cut -d'.' -f1`
do
echo "Begin processing for 5826 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5826 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5826/' | cut -d'.' -f1`
do
echo "Begin processing for 5826 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5826 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5827/' | cut -d'.' -f1`
do
echo "Begin processing for 5827 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5827 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5827/' | cut -d'.' -f1`
do
echo "Begin processing for 5827 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5827 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5846/' | cut -d'.' -f1`
do
echo "Begin processing for 5846 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5846 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5846/' | cut -d'.' -f1`
do
echo "Begin processing for 5846 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5846 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2865/' | cut -d'.' -f1`
do
echo "Begin processing for 2865 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2865 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2865/' | cut -d'.' -f1`
do
echo "Begin processing for 2865 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2865 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2520/' | cut -d'.' -f1`
do
echo "Begin processing for 2520 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2520 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2520/' | cut -d'.' -f1`
do
echo "Begin processing for 2520 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2520 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2521/' | cut -d'.' -f1`
do
echo "Begin processing for 2521 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2521 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2521/' | cut -d'.' -f1`
do
echo "Begin processing for 2521 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2521 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2523/' | cut -d'.' -f1`
do
echo "Begin processing for 2523 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2523 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2523/' | cut -d'.' -f1`
do
echo "Begin processing for 2523 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2523 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2524/' | cut -d'.' -f1`
do
echo "Begin processing for 2524 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2524 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2524/' | cut -d'.' -f1`
do
echo "Begin processing for 2524 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2524 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2533/' | cut -d'.' -f1`
do
echo "Begin processing for 2533 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2533 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2533/' | cut -d'.' -f1`
do
echo "Begin processing for 2533 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2533 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2667/' | cut -d'.' -f1`
do
echo "Begin processing for 2667 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2667 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2667/' | cut -d'.' -f1`
do
echo "Begin processing for 2667 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2667 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5210/' | cut -d'.' -f1`
do				
echo "Begin processing for 5210 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5210 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5210/' | cut -d'.' -f1`
do				
echo "Begin processing for 5210 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5210 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5211/' | cut -d'.' -f1`
do				
echo "Begin processing for 5211 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5211 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5211/' | cut -d'.' -f1`
do				
echo "Begin processing for 5211 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5211 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5501/' | cut -d'.' -f1`
do				
echo "Begin processing for 5501 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5501 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5501/' | cut -d'.' -f1`
do				
echo "Begin processing for 5501 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5501 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5502/' | cut -d'.' -f1`
do				
echo "Begin processing for 5502 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5502 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5502/' | cut -d'.' -f1`
do				
echo "Begin processing for 5502 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5502 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5503/' | cut -d'.' -f1`
do				
echo "Begin processing for 5503 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5503 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5503/' | cut -d'.' -f1`
do				
echo "Begin processing for 5503 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5503 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5506/' | cut -d'.' -f1`
do				
echo "Begin processing for 5506 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5506 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5506/' | cut -d'.' -f1`
do				
echo "Begin processing for 5506 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5506 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5507/' | cut -d'.' -f1`
do				
echo "Begin processing for 5507 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5507 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5507/' | cut -d'.' -f1`
do				
echo "Begin processing for 5507 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5507 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5508/' | cut -d'.' -f1`
do				
echo "Begin processing for 5508 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5508 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5508/' | cut -d'.' -f1`
do				
echo "Begin processing for 5508 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5508 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5512/' | cut -d'.' -f1`
do				
echo "Begin processing for 5512 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5512 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5512/' | cut -d'.' -f1`
do				
echo "Begin processing for 5512 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5512 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5513/' | cut -d'.' -f1`
do				
echo "Begin processing for 5513 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5513 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5513/' | cut -d'.' -f1`
do				
echo "Begin processing for 5513 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5513 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5515/' | cut -d'.' -f1`
do				
echo "Begin processing for 5515 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5515 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5515/' | cut -d'.' -f1`
do				
echo "Begin processing for 5515 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5515 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5523/' | cut -d'.' -f1`
do				
echo "Begin processing for 5523 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5523 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5523/' | cut -d'.' -f1`
do				
echo "Begin processing for 5523 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5523 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5527/' | cut -d'.' -f1`
do				
echo "Begin processing for 5527 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5527 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5527/' | cut -d'.' -f1`
do				
echo "Begin processing for 5527 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5527 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5528/' | cut -d'.' -f1`
do				
echo "Begin processing for 5528 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5528 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5528/' | cut -d'.' -f1`
do				
echo "Begin processing for 5528 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5528 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5529/' | cut -d'.' -f1`
do				
echo "Begin processing for 5529 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5529 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5529/' | cut -d'.' -f1`
do				
echo "Begin processing for 5529 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5529 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5530/' | cut -d'.' -f1`
do				
echo "Begin processing for 5530 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5530 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5530/' | cut -d'.' -f1`
do				
echo "Begin processing for 5530 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5530 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5532/' | cut -d'.' -f1`
do				
echo "Begin processing for 5532 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5532 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5532/' | cut -d'.' -f1`
do				
echo "Begin processing for 5532 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5532 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5533/' | cut -d'.' -f1`
do				
echo "Begin processing for 5533 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5533 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5533/' | cut -d'.' -f1`
do				
echo "Begin processing for 5533 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5533 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5537/' | cut -d'.' -f1`
do				
echo "Begin processing for 5537 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5537 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5537/' | cut -d'.' -f1`
do				
echo "Begin processing for 5537 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5537 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5541/' | cut -d'.' -f1`
do				
echo "Begin processing for 5541 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5541 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5541/' | cut -d'.' -f1`
do				
echo "Begin processing for 5541 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5541 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5545/' | cut -d'.' -f1`
do				
echo "Begin processing for 5545 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5545 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5545/' | cut -d'.' -f1`
do				
echo "Begin processing for 5545 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5545 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5546/' | cut -d'.' -f1`
do				
echo "Begin processing for 5546 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5546 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5546/' | cut -d'.' -f1`
do				
echo "Begin processing for 5546 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5546 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5547/' | cut -d'.' -f1`
do				
echo "Begin processing for 5547 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5547 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5547/' | cut -d'.' -f1`
do				
echo "Begin processing for 5547 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5547 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5549/' | cut -d'.' -f1`
do				
echo "Begin processing for 5549 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5549 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5549/' | cut -d'.' -f1`
do				
echo "Begin processing for 5549 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5549 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5553/' | cut -d'.' -f1`
do				
echo "Begin processing for 5553 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5553 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5553/' | cut -d'.' -f1`
do				
echo "Begin processing for 5553 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5553 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5554/' | cut -d'.' -f1`
do			
echo "Begin processing for 5554 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5554 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5554/' | cut -d'.' -f1`
do			
echo "Begin processing for 5554 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5554 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5555/' | cut -d'.' -f1`
do				
echo "Begin processing for 5555 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5555 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5555/' | cut -d'.' -f1`
do				
echo "Begin processing for 5555 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5555 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5556/' | cut -d'.' -f1`
do				
echo "Begin processing for 5556 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5556 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5556/' | cut -d'.' -f1`
do				
echo "Begin processing for 5556 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5556 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5557/' | cut -d'.' -f1`
do				
echo "Begin processing for 5557 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5557 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5557/' | cut -d'.' -f1`
do				
echo "Begin processing for 5557 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5557 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5558/' | cut -d'.' -f1`
do				
echo "Begin processing for 5558 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5558 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5558/' | cut -d'.' -f1`
do				
echo "Begin processing for 5558 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5558 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5559/' | cut -d'.' -f1`
do				
echo "Begin processing for 5559 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5559 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5559/' | cut -d'.' -f1`
do				
echo "Begin processing for 5559 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5559 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5560/' | cut -d'.' -f1`
do				
echo "Begin processing for 5560 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5560 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5560/' | cut -d'.' -f1`
do				
echo "Begin processing for 5560 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5560 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5562/' | cut -d'.' -f1`
do				
echo "Begin processing for 5562 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5562 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5562/' | cut -d'.' -f1`
do				
echo "Begin processing for 5562 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5562 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5564/' | cut -d'.' -f1`
do				
echo "Begin processing for 5564 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5564 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5564/' | cut -d'.' -f1`
do				
echo "Begin processing for 5564 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5564 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5567/' | cut -d'.' -f1`
do				
echo "Begin processing for 5567 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5567 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5567/' | cut -d'.' -f1`
do				
echo "Begin processing for 5567 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5567 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5568/' | cut -d'.' -f1`
do				
echo "Begin processing for 5568 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5568 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5568/' | cut -d'.' -f1`
do				
echo "Begin processing for 5568 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5568 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5569/' | cut -d'.' -f1`
do				
echo "Begin processing for 5569 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5569 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5569/' | cut -d'.' -f1`
do				
echo "Begin processing for 5569 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5569 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5855/' | cut -d'.' -f1`
do				
echo "Begin processing for 5855 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5855 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5855/' | cut -d'.' -f1`
do				
echo "Begin processing for 5855 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5855 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5858/' | cut -d'.' -f1`
do				
echo "Begin processing for 5858 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5858 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5858/' | cut -d'.' -f1`
do				
echo "Begin processing for 5858 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5858 TXT "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5724/' | cut -d'.' -f1`
do
echo "Begin processing for 5724 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5724 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5724/' | cut -d'.' -f1`
do
echo "Begin processing for 5724 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5724 TXT "
done
#done < Proj_List.csv
for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5008/' | cut -d'.' -f1`
do
echo "Begin processing for 5008 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5008 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5008/' | cut -d'.' -f1`
do
echo "Begin processing for 5008 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5008 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2750/' | cut -d'.' -f1`
do
echo "Begin processing for 2750 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2750 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2750/' | cut -d'.' -f1`
do
echo "Begin processing for 2750 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2750 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5714/' | cut -d'.' -f1`
do
echo "Begin processing for 5714 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5714 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5714/' | cut -d'.' -f1`
do
echo "Begin processing for 5714 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5714 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5081/' | cut -d'.' -f1`
do
echo "Begin processing for 5081 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5081 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5081/' | cut -d'.' -f1`
do
echo "Begin processing for 5081 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5081 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5069/' | cut -d'.' -f1`
do
echo "Begin processing for 5069 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5069 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5069/' | cut -d'.' -f1`
do
echo "Begin processing for 5069 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5069 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_4106/' | cut -d'.' -f1`
do
echo "Begin processing for 4106 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 4106 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_4106/' | cut -d'.' -f1`
do
echo "Begin processing for 4106 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 4106 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5087/' | cut -d'.' -f1`
do
echo "Begin processing for 5087 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5087 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5087/' | cut -d'.' -f1`
do
echo "Begin processing for 5087 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5087 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5872/' | cut -d'.' -f1`
do
echo "Begin processing for 5872 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5872 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5872/' | cut -d'.' -f1`
do
echo "Begin processing for 5872 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5872 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2880/' | cut -d'.' -f1`
do
echo "Begin processing for 2880 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2880 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2880/' | cut -d'.' -f1`
do
echo "Begin processing for 2880 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2880 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5007/' | cut -d'.' -f1`
do
echo "Begin processing for 5007 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5007 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5007/' | cut -d'.' -f1`
do
echo "Begin processing for 5007 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5007 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5740/' | cut -d'.' -f1`
do
echo "Begin processing for 5740 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5740 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5740/' | cut -d'.' -f1`
do
echo "Begin processing for 5740 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5740 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5873/' | cut -d'.' -f1`
do
echo "Begin processing for 5873 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5873 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5873/' | cut -d'.' -f1`
do
echo "Begin processing for 5873 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5873 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5006/' | cut -d'.' -f1`
do
echo "Begin processing for 5006 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5006 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5006/' | cut -d'.' -f1`
do
echo "Begin processing for 5006 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5006 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2505/' | cut -d'.' -f1`
do
echo "Begin processing for 2505 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2505 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2505/' | cut -d'.' -f1`
do
echo "Begin processing for 2505 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2505 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5004/' | cut -d'.' -f1`
do
echo "Begin processing for 5004 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5004 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5004/' | cut -d'.' -f1`
do
echo "Begin processing for 5004 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5004 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5151/' | cut -d'.' -f1`
do
echo "Begin processing for 5151 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5151 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5151/' | cut -d'.' -f1`
do
echo "Begin processing for 5151 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5151 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5875/' | cut -d'.' -f1`
do
echo "Begin processing for 5875 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5875 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5875/' | cut -d'.' -f1`
do
echo "Begin processing for 5875 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5875 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5063/' | cut -d'.' -f1`
do
echo "Begin processing for 5063 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5063 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5063/' | cut -d'.' -f1`
do
echo "Begin processing for 5063 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5063 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5215/' | cut -d'.' -f1`
do
echo "Begin processing for 5215 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5215 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5215/' | cut -d'.' -f1`
do
echo "Begin processing for 5215 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5215 TXT"
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5215/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5215/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5218/' | cut -d'.' -f1`
do
echo "Begin processing for 5218 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5218 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5218/' | cut -d'.' -f1`
do
echo "Begin processing for 5218 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5218 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5742/' | cut -d'.' -f1`
do
echo "Begin processing for 5742 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5742 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5742/' | cut -d'.' -f1`
do
echo "Begin processing for 5742 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5742 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5743/' | cut -d'.' -f1`
do
echo "Begin processing for 5743 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5743 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5743/' | cut -d'.' -f1`
do
echo "Begin processing for 5743 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5743 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5570/' | cut -d'.' -f1`
do
echo "Begin processing for 5570 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5570 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5570/' | cut -d'.' -f1`
do
echo "Begin processing for 5570 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5570 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5070/' | cut -d'.' -f1`
do
echo "Begin processing for 5070 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5070 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5070/' | cut -d'.' -f1`
do
echo "Begin processing for 5070 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5070 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5088/' | cut -d'.' -f1`
do
echo "Begin processing for 5088 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5088 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5088/' | cut -d'.' -f1`
do
echo "Begin processing for 5088 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5088 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5565/' | cut -d'.' -f1`
do
echo "Begin processing for 5565 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5565 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5565/' | cut -d'.' -f1`
do
echo "Begin processing for 5565 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5565 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5043/' | cut -d'.' -f1`
do
echo "Begin processing for 5043 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5043 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5043/' | cut -d'.' -f1`
do
echo "Begin processing for 5043 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5043 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2167/' | cut -d'.' -f1`
do
echo "Begin processing for 2167 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2167 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2167/' | cut -d'.' -f1`
do
echo "Begin processing for 2167 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2167 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2809/' | cut -d'.' -f1`
do
echo "Begin processing for 2809 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2809 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2809/' | cut -d'.' -f1`
do
echo "Begin processing for 2809 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2809 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2227/' | cut -d'.' -f1`
do
echo "Begin processing for 2227 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2227 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2227/' | cut -d'.' -f1`
do
echo "Begin processing for 2227 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2227 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5085/' | cut -d'.' -f1`
do
echo "Begin processing for 5085 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5085 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5085/' | cut -d'.' -f1`
do
echo "Begin processing for 5085 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5085 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2834/' | cut -d'.' -f1`
do
echo "Begin processing for 2834 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2834 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2834/' | cut -d'.' -f1`
do
echo "Begin processing for 2834 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2834 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2921/' | cut -d'.' -f1`
do
echo "Begin processing for 2921 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2921 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2921/' | cut -d'.' -f1`
do
echo "Begin processing for 2921 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2921 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5216/' | cut -d'.' -f1`
do
echo "Begin processing for 5216 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5216 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5216/' | cut -d'.' -f1`
do
echo "Begin processing for 5216 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5216 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2846/' | cut -d'.' -f1`
do
echo "Begin processing for 2846 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2846 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2846/' | cut -d'.' -f1`
do
echo "Begin processing for 2846 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2846 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5535/' | cut -d'.' -f1`
do
echo "Begin processing for 5535 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5535 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5535/' | cut -d'.' -f1`
do
echo "Begin processing for 5535 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5535 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_4105/' | cut -d'.' -f1`
do
echo "Begin processing for 4105 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 4105 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_4105/' | cut -d'.' -f1`
do
echo "Begin processing for 4105 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 4105 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2756/' | cut -d'.' -f1`
do
echo "Begin processing for 2756 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2756 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2756/' | cut -d'.' -f1`
do
echo "Begin processing for 2756 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2756 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5199/' | cut -d'.' -f1`
do
echo "Begin processing for 5199 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5199 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5199/' | cut -d'.' -f1`
do
echo "Begin processing for 5199 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5199 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5876/' | cut -d'.' -f1`
do
echo "Begin processing for 5876 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5876 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5876/' | cut -d'.' -f1`
do
echo "Begin processing for 5876 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5876 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5217/' | cut -d'.' -f1`
do
echo "Begin processing for 5217 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5217 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5217/' | cut -d'.' -f1`
do
echo "Begin processing for 5217 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5217 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5416/' | cut -d'.' -f1`
do
echo "Begin processing for 5416 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5416 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5416/' | cut -d'.' -f1`
do
echo "Begin processing for 5416 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5416 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5799/' | cut -d'.' -f1`
do
echo "Begin processing for 5799 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5799 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5799/' | cut -d'.' -f1`
do
echo "Begin processing for 5799 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5799 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5214/' | cut -d'.' -f1`
do
echo "Begin processing for 5214 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5214 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5214/' | cut -d'.' -f1`
do
echo "Begin processing for 5214 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5214 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5572/' | cut -d'.' -f1`
do
echo "Begin processing for 5572 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5572 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5572/' | cut -d'.' -f1`
do
echo "Begin processing for 5572 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5572 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5571/' | cut -d'.' -f1`
do
echo "Begin processing for 5571 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5571 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5571/' | cut -d'.' -f1`
do
echo "Begin processing for 5571 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5571 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5220/' | cut -d'.' -f1`
do
echo "Begin processing for 5220 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5220 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5220/' | cut -d'.' -f1`
do
echo "Begin processing for 5220 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5220 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2928/' | cut -d'.' -f1`
do
echo "Begin processing for 2928 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2928 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2928/' | cut -d'.' -f1`
do
echo "Begin processing for 2928 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2928 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_1111/' | cut -d'.' -f1`
do
echo "Begin processing for 1111 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 1111 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_1111/' | cut -d'.' -f1`
do
echo "Begin processing for 1111 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 1111 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2001/' | cut -d'.' -f1`
do
echo "Begin processing for 2001 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2001 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2001/' | cut -d'.' -f1`
do
echo "Begin processing for 2001 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2001 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2050/' | cut -d'.' -f1`
do
echo "Begin processing for 2050 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2050 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2050/' | cut -d'.' -f1`
do
echo "Begin processing for 2050 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2050 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2060/' | cut -d'.' -f1`
do
echo "Begin processing for 2060 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2060 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2060/' | cut -d'.' -f1`
do
echo "Begin processing for 2060 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2060 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2063/' | cut -d'.' -f1`
do
echo "Begin processing for 2063 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2063 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2063/' | cut -d'.' -f1`
do
echo "Begin processing for 2063 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2063 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2064/' | cut -d'.' -f1`
do
echo "Begin processing for 2064 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2064 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2064/' | cut -d'.' -f1`
do
echo "Begin processing for 2064 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2064 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2066/' | cut -d'.' -f1`
do
echo "Begin processing for 2066 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2066 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2066/' | cut -d'.' -f1`
do
echo "Begin processing for 2066 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2066 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2067/' | cut -d'.' -f1`
do
echo "Begin processing for 2067 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2067 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2067/' | cut -d'.' -f1`
do
echo "Begin processing for 2067 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2067 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2068/' | cut -d'.' -f1`
do
echo "Begin processing for 2068 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2068 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2068/' | cut -d'.' -f1`
do
echo "Begin processing for 2068 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2068 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2070/' | cut -d'.' -f1`
do
echo "Begin processing for 2070 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2070 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2070/' | cut -d'.' -f1`
do
echo "Begin processing for 2070 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2070 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2071/' | cut -d'.' -f1`
do
echo "Begin processing for 2071 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2071 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2071/' | cut -d'.' -f1`
do
echo "Begin processing for 2071 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2071 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2073/' | cut -d'.' -f1`
do
echo "Begin processing for 2073 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2073 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2073/' | cut -d'.' -f1`
do
echo "Begin processing for 2073 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2073 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2075/' | cut -d'.' -f1`
do
echo "Begin processing for 2075 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2075 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2075/' | cut -d'.' -f1`
do
echo "Begin processing for 2075 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2075 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2084/' | cut -d'.' -f1`
do
echo "Begin processing for 2084 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2084 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2084/' | cut -d'.' -f1`
do
echo "Begin processing for 2084 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2084 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2099/' | cut -d'.' -f1`
do
echo "Begin processing for 2099 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2099 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2099/' | cut -d'.' -f1`
do
echo "Begin processing for 2099 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2099 TXT"
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2099/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2099/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2152/' | cut -d'.' -f1`
do
echo "Begin processing for 2152 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2152 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2152/' | cut -d'.' -f1`
do
echo "Begin processing for 2152 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2152 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2163/' | cut -d'.' -f1`
do
echo "Begin processing for 2163 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2163 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2163/' | cut -d'.' -f1`
do
echo "Begin processing for 2163 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2163 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2165/' | cut -d'.' -f1`
do
echo "Begin processing for 2165 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2165 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2165/' | cut -d'.' -f1`
do
echo "Begin processing for 2165 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2165 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2171/' | cut -d'.' -f1`
do
echo "Begin processing for 2171 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2171 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2171/' | cut -d'.' -f1`
do
echo "Begin processing for 2171 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2171 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2196/' | cut -d'.' -f1`
do
echo "Begin processing for 2196 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2196 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2196/' | cut -d'.' -f1`
do
echo "Begin processing for 2196 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2196 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2202/' | cut -d'.' -f1`
do
echo "Begin processing for 2202 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2202 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2202/' | cut -d'.' -f1`
do
echo "Begin processing for 2202 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2202 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2240/' | cut -d'.' -f1`
do
echo "Begin processing for 2240 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2240 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2240/' | cut -d'.' -f1`
do
echo "Begin processing for 2240 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2240 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2574/' | cut -d'.' -f1`
do
echo "Begin processing for 2574 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2574 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2574/' | cut -d'.' -f1`
do
echo "Begin processing for 2574 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2574 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2591/' | cut -d'.' -f1`
do
echo "Begin processing for 2591 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2591 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2591/' | cut -d'.' -f1`
do
echo "Begin processing for 2591 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2591 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2592/' | cut -d'.' -f1`
do
echo "Begin processing for 2592 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2592 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2592/' | cut -d'.' -f1`
do
echo "Begin processing for 2592 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2592 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2600/' | cut -d'.' -f1`
do
echo "Begin processing for 2600 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2600 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2600/' | cut -d'.' -f1`
do
echo "Begin processing for 2600 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2600 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2610/' | cut -d'.' -f1`
do
echo "Begin processing for 2610 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2610 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2610/' | cut -d'.' -f1`
do
echo "Begin processing for 2610 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2610 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2641/' | cut -d'.' -f1`
do
echo "Begin processing for 2641 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2641 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2641/' | cut -d'.' -f1`
do
echo "Begin processing for 2641 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2641 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2642/' | cut -d'.' -f1`
do
echo "Begin processing for 2642 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2642 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2642/' | cut -d'.' -f1`
do
echo "Begin processing for 2642 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2642 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2647/' | cut -d'.' -f1`
do
echo "Begin processing for 2647 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2647 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2647/' | cut -d'.' -f1`
do
echo "Begin processing for 2647 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2647 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2651/' | cut -d'.' -f1`
do
echo "Begin processing for 2651 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2651 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2651/' | cut -d'.' -f1`
do
echo "Begin processing for 2651 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2651 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2652/' | cut -d'.' -f1`
do
echo "Begin processing for 2652 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2652 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2652/' | cut -d'.' -f1`
do
echo "Begin processing for 2652 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2652 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2654/' | cut -d'.' -f1`
do
echo "Begin processing for 2654 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2654 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2654/' | cut -d'.' -f1`
do
echo "Begin processing for 2654 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2654 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2673/' | cut -d'.' -f1`
do
echo "Begin processing for 2673 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2673 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2673/' | cut -d'.' -f1`
do
echo "Begin processing for 2673 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2673 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2674/' | cut -d'.' -f1`
do
echo "Begin processing for 2674 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2674 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2674/' | cut -d'.' -f1`
do
echo "Begin processing for 2674 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2674 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2679/' | cut -d'.' -f1`
do
echo "Begin processing for 2679 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2679 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2679/' | cut -d'.' -f1`
do
echo "Begin processing for 2679 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2679 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2680/' | cut -d'.' -f1`
do
echo "Begin processing for 2680 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2680 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2680/' | cut -d'.' -f1`
do
echo "Begin processing for 2680 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2680 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2705/' | cut -d'.' -f1`
do
echo "Begin processing for 2705 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2705 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2705/' | cut -d'.' -f1`
do
echo "Begin processing for 2705 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2705 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2742/' | cut -d'.' -f1`
do
echo "Begin processing for 2742 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2742 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2742/' | cut -d'.' -f1`
do
echo "Begin processing for 2742 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2742 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2745/' | cut -d'.' -f1`
do
echo "Begin processing for 2745 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2745 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2745/' | cut -d'.' -f1`
do
echo "Begin processing for 2745 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2745 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2751/' | cut -d'.' -f1`
do
echo "Begin processing for 2751 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2751 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2751/' | cut -d'.' -f1`
do
echo "Begin processing for 2751 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2751 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2753/' | cut -d'.' -f1`
do
echo "Begin processing for 2753 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2753 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2753/' | cut -d'.' -f1`
do
echo "Begin processing for 2753 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2753 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2754/' | cut -d'.' -f1`
do
echo "Begin processing for 2754 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2754 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2754/' | cut -d'.' -f1`
do
echo "Begin processing for 2754 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2754 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2770/' | cut -d'.' -f1`
do
echo "Begin processing for 2770 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2770 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2770/' | cut -d'.' -f1`
do
echo "Begin processing for 2770 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2770 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2776/' | cut -d'.' -f1`
do
echo "Begin processing for 2776 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2776 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2776/' | cut -d'.' -f1`
do
echo "Begin processing for 2776 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2776 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2815/' | cut -d'.' -f1`
do
echo "Begin processing for 2815 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2815 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2815/' | cut -d'.' -f1`
do
echo "Begin processing for 2815 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2815 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2816/' | cut -d'.' -f1`
do
echo "Begin processing for 2816 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2816 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2816/' | cut -d'.' -f1`
do
echo "Begin processing for 2816 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2816 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2818/' | cut -d'.' -f1`
do
echo "Begin processing for 2818 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2818 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2818/' | cut -d'.' -f1`
do
echo "Begin processing for 2818 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2818 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2821/' | cut -d'.' -f1`
do
echo "Begin processing for 2821 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2821 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2821/' | cut -d'.' -f1`
do
echo "Begin processing for 2821 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2821 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2829/' | cut -d'.' -f1`
do
echo "Begin processing for 2829 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2829 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2829/' | cut -d'.' -f1`
do
echo "Begin processing for 2829 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2829 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2832/' | cut -d'.' -f1`
do
echo "Begin processing for 2832 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2832 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2832/' | cut -d'.' -f1`
do
echo "Begin processing for 2832 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2832 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2841/' | cut -d'.' -f1`
do
echo "Begin processing for 2841 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2841 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2841/' | cut -d'.' -f1`
do
echo "Begin processing for 2841 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2841 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2845/' | cut -d'.' -f1`
do
echo "Begin processing for 2845 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2845 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2845/' | cut -d'.' -f1`
do
echo "Begin processing for 2845 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2845 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2885/' | cut -d'.' -f1`
do
echo "Begin processing for 2885 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2885 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2885/' | cut -d'.' -f1`
do
echo "Begin processing for 2885 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2885 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2894/' | cut -d'.' -f1`
do
echo "Begin processing for 2894 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2894 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2894/' | cut -d'.' -f1`
do
echo "Begin processing for 2894 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2894 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2896/' | cut -d'.' -f1`
do
echo "Begin processing for 2896 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2896 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2896/' | cut -d'.' -f1`
do
echo "Begin processing for 2896 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2896 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2897/' | cut -d'.' -f1`
do
echo "Begin processing for 2897 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2897 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2897/' | cut -d'.' -f1`
do
echo "Begin processing for 2897 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2897 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2898/' | cut -d'.' -f1`
do
echo "Begin processing for 2898 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2898 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2898/' | cut -d'.' -f1`
do
echo "Begin processing for 2898 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2898 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2900/' | cut -d'.' -f1`
do
echo "Begin processing for 2900 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2900 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2900/' | cut -d'.' -f1`
do
echo "Begin processing for 2900 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2900 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2910/' | cut -d'.' -f1`
do
echo "Begin processing for 2910 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2910 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2910/' | cut -d'.' -f1`
do
echo "Begin processing for 2910 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2910 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_3505/' | cut -d'.' -f1`
do
echo "Begin processing for 3505 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 3505 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_3505/' | cut -d'.' -f1`
do
echo "Begin processing for 3505 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 3505 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5197/' | cut -d'.' -f1`
do
echo "Begin processing for 5197 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5197 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5197/' | cut -d'.' -f1`
do
echo "Begin processing for 5197 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5197 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5741/' | cut -d'.' -f1`
do
echo "Begin processing for 5741 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5741 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5741/' | cut -d'.' -f1`
do
echo "Begin processing for 5741 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5741 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5724/' | cut -d'.' -f1`
do
echo "Begin processing for 5724 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5724 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5724/' | cut -d'.' -f1`
do
echo "Begin processing for 5724 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5724 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2750/' | cut -d'.' -f1`
do
echo "Begin processing for 2750 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2750 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2750/' | cut -d'.' -f1`
do
echo "Begin processing for 2750 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2750 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5714/' | cut -d'.' -f1`
do
echo "Begin processing for 5714 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5714 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5714/' | cut -d'.' -f1`
do
echo "Begin processing for 5714 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5714 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5081/' | cut -d'.' -f1`
do
echo "Begin processing for 5081 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5081 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5081/' | cut -d'.' -f1`
do
echo "Begin processing for 5081 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5081 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5069/' | cut -d'.' -f1`
do
echo "Begin processing for 5069 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5069 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5069/' | cut -d'.' -f1`
do
echo "Begin processing for 5069 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5069 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_4106/' | cut -d'.' -f1`
do
echo "Begin processing for 4106 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 4106 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_4106/' | cut -d'.' -f1`
do
echo "Begin processing for 4106 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 4106 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5087/' | cut -d'.' -f1`
do
echo "Begin processing for 5087 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5087 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5087/' | cut -d'.' -f1`
do
echo "Begin processing for 5087 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5087 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5872/' | cut -d'.' -f1`
do
echo "Begin processing for 5872 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5872 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5872/' | cut -d'.' -f1`
do
echo "Begin processing for 5872 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5872 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2880/' | cut -d'.' -f1`
do
echo "Begin processing for 2880 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2880 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2880/' | cut -d'.' -f1`
do
echo "Begin processing for 2880 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2880 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5007/' | cut -d'.' -f1`
do
echo "Begin processing for 5007 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5007 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5007/' | cut -d'.' -f1`
do
echo "Begin processing for 5007 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5007 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5740/' | cut -d'.' -f1`
do
echo "Begin processing for 5740 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5740 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5740/' | cut -d'.' -f1`
do
echo "Begin processing for 5740 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5740 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5873/' | cut -d'.' -f1`
do
echo "Begin processing for 5873 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5873 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5873/' | cut -d'.' -f1`
do
echo "Begin processing for 5873 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5873 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5006/' | cut -d'.' -f1`
do
echo "Begin processing for 5006 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5006 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5006/' | cut -d'.' -f1`
do
echo "Begin processing for 5006 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5006 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2505/' | cut -d'.' -f1`
do
echo "Begin processing for 2505 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2505 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2505/' | cut -d'.' -f1`
do
echo "Begin processing for 2505 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2505 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5004/' | cut -d'.' -f1`
do
echo "Begin processing for 5004 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5004 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5004/' | cut -d'.' -f1`
do
echo "Begin processing for 5004 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5004 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5151/' | cut -d'.' -f1`
do
echo "Begin processing for 5151 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5151 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5151/' | cut -d'.' -f1`
do
echo "Begin processing for 5151 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5151 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5875/' | cut -d'.' -f1`
do
echo "Begin processing for 5875 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5875 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5875/' | cut -d'.' -f1`
do
echo "Begin processing for 5875 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5875 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5063/' | cut -d'.' -f1`
do
echo "Begin processing for 5063 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5063 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5063/' | cut -d'.' -f1`
do
echo "Begin processing for 5063 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5063 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5215/' | cut -d'.' -f1`
do
echo "Begin processing for 5215 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5215 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5215/' | cut -d'.' -f1`
do
echo "Begin processing for 5215 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5215 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5218/' | cut -d'.' -f1`
do
echo "Begin processing for 5218 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5218 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5218/' | cut -d'.' -f1`
do
echo "Begin processing for 5218 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5218 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5742/' | cut -d'.' -f1`
do
echo "Begin processing for 5742 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5742 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5742/' | cut -d'.' -f1`
do
echo "Begin processing for 5742 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5742 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5743/' | cut -d'.' -f1`
do
echo "Begin processing for 5743 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5743 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5743/' | cut -d'.' -f1`
do
echo "Begin processing for 5743 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5743 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5570/' | cut -d'.' -f1`
do
echo "Begin processing for 5570 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5570 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5570/' | cut -d'.' -f1`
do
echo "Begin processing for 5570 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5570 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5070/' | cut -d'.' -f1`
do
echo "Begin processing for 5070 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5070 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5070/' | cut -d'.' -f1`
do
echo "Begin processing for 5070 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5070 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5080/' | cut -d'.' -f1`
do
echo "Begin processing for 5080 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5080 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5080/' | cut -d'.' -f1`
do
echo "Begin processing for 5080 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5080 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5088/' | cut -d'.' -f1`
do
echo "Begin processing for 5088 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5088 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5088/' | cut -d'.' -f1`
do
echo "Begin processing for 5088 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5088 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5565/' | cut -d'.' -f1`
do
echo "Begin processing for 5565 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5565 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5565/' | cut -d'.' -f1`
do
echo "Begin processing for 5565 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5565 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5043/' | cut -d'.' -f1`
do
echo "Begin processing for 5043 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5043 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5043/' | cut -d'.' -f1`
do
echo "Begin processing for 5043 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5043 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2167/' | cut -d'.' -f1`
do
echo "Begin processing for 2167 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2167 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2167/' | cut -d'.' -f1`
do
echo "Begin processing for 2167 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2167 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2809/' | cut -d'.' -f1`
do
echo "Begin processing for 2809 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2809 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2809/' | cut -d'.' -f1`
do
echo "Begin processing for 2809 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2809 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2227/' | cut -d'.' -f1`
do
echo "Begin processing for 2227 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2227 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2227/' | cut -d'.' -f1`
do
echo "Begin processing for 2227 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2227 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5085/' | cut -d'.' -f1`
do
echo "Begin processing for 5085 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5085 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5085/' | cut -d'.' -f1`
do
echo "Begin processing for 5085 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5085 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2834/' | cut -d'.' -f1`
do
echo "Begin processing for 2834 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2834 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2834/' | cut -d'.' -f1`
do
echo "Begin processing for 2834 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2834 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2921/' | cut -d'.' -f1`
do
echo "Begin processing for 2921 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2921 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2921/' | cut -d'.' -f1`
do
echo "Begin processing for 2921 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2921 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5216/' | cut -d'.' -f1`
do
echo "Begin processing for 5216 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5216 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5216/' | cut -d'.' -f1`
do
echo "Begin processing for 5216 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5216 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2846/' | cut -d'.' -f1`
do
echo "Begin processing for 2846 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2846 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2846/' | cut -d'.' -f1`
do
echo "Begin processing for 2846 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2846 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5535/' | cut -d'.' -f1`
do
echo "Begin processing for 5535 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5535 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5535/' | cut -d'.' -f1`
do
echo "Begin processing for 5535 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5535 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_4105/' | cut -d'.' -f1`
do
echo "Begin processing for 4105 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 4105 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_4105/' | cut -d'.' -f1`
do
echo "Begin processing for 4105 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 4105 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2756/' | cut -d'.' -f1`
do
echo "Begin processing for 2756 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2756 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2756/' | cut -d'.' -f1`
do
echo "Begin processing for 2756 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2756 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5199/' | cut -d'.' -f1`
do
echo "Begin processing for 5199 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5199 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5199/' | cut -d'.' -f1`
do
echo "Begin processing for 5199 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5199 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2747/' | cut -d'.' -f1`
do
echo "Begin processing for 2747 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2747 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2747/' | cut -d'.' -f1`
do
echo "Begin processing for 2747 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2747 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5876/' | cut -d'.' -f1`
do
echo "Begin processing for 5876 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5876 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5876/' | cut -d'.' -f1`
do
echo "Begin processing for 5876 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5876 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5217/' | cut -d'.' -f1`
do
echo "Begin processing for 5217 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5217 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5217/' | cut -d'.' -f1`
do
echo "Begin processing for 5217 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5217 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5416/' | cut -d'.' -f1`
do
echo "Begin processing for 5416 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5416 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5416/' | cut -d'.' -f1`
do
echo "Begin processing for 5416 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5416 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5799/' | cut -d'.' -f1`
do
echo "Begin processing for 5799 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5799 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5799/' | cut -d'.' -f1`
do
echo "Begin processing for 5799 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5799 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5214/' | cut -d'.' -f1`
do
echo "Begin processing for 5214 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5214 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5214/' | cut -d'.' -f1`
do
echo "Begin processing for 5214 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5214 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5572/' | cut -d'.' -f1`
do
echo "Begin processing for 5572 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5572 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5572/' | cut -d'.' -f1`
do
echo "Begin processing for 5572 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5572 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5571/' | cut -d'.' -f1`
do
echo "Begin processing for 5571 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5571 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5571/' | cut -d'.' -f1`
do
echo "Begin processing for 5571 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5571 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5220/' | cut -d'.' -f1`
do
echo "Begin processing for 5220 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5220 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5220/' | cut -d'.' -f1`
do
echo "Begin processing for 5220 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5220 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2928/' | cut -d'.' -f1`
do
echo "Begin processing for 2928 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2928 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2928/' | cut -d'.' -f1`
do
echo "Begin processing for 2928 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2928 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_1111/' | cut -d'.' -f1`
do
echo "Begin processing for 1111 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 1111 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_1111/' | cut -d'.' -f1`
do
echo "Begin processing for 1111 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 1111 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2001/' | cut -d'.' -f1`
do
echo "Begin processing for 2001 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2001 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2001/' | cut -d'.' -f1`
do
echo "Begin processing for 2001 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2001 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2050/' | cut -d'.' -f1`
do
echo "Begin processing for 2050 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2050 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2050/' | cut -d'.' -f1`
do
echo "Begin processing for 2050 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2050 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2060/' | cut -d'.' -f1`
do
echo "Begin processing for 2060 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2060 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2060/' | cut -d'.' -f1`
do
echo "Begin processing for 2060 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2060 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2063/' | cut -d'.' -f1`
do
echo "Begin processing for 2063 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2063 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2063/' | cut -d'.' -f1`
do
echo "Begin processing for 2063 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2063 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2064/' | cut -d'.' -f1`
do
echo "Begin processing for 2064 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2064 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2064/' | cut -d'.' -f1`
do
echo "Begin processing for 2064 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2064 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2066/' | cut -d'.' -f1`
do
echo "Begin processing for 2066 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2066 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2066/' | cut -d'.' -f1`
do
echo "Begin processing for 2066 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2066 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2067/' | cut -d'.' -f1`
do
echo "Begin processing for 2067 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2067 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2067/' | cut -d'.' -f1`
do
echo "Begin processing for 2067 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2067 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2068/' | cut -d'.' -f1`
do
echo "Begin processing for 2068 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2068 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2068/' | cut -d'.' -f1`
do
echo "Begin processing for 2068 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2068 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2070/' | cut -d'.' -f1`
do
echo "Begin processing for 2070 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2070 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2070/' | cut -d'.' -f1`
do
echo "Begin processing for 2070 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2070 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2071/' | cut -d'.' -f1`
do
echo "Begin processing for 2071 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2071 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2071/' | cut -d'.' -f1`
do
echo "Begin processing for 2071 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2071 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2074/' | cut -d'.' -f1`
do
echo "Begin processing for 2074 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2074 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2074/' | cut -d'.' -f1`
do
echo "Begin processing for 2074 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2074 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2077/' | cut -d'.' -f1`
do
echo "Begin processing for 2077 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2077 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2077/' | cut -d'.' -f1`
do
echo "Begin processing for 2077 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2077 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2078/' | cut -d'.' -f1`
do
echo "Begin processing for 2078 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2078 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2078/' | cut -d'.' -f1`
do
echo "Begin processing for 2078 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2078 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2080/' | cut -d'.' -f1`
do
echo "Begin processing for 2080 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2080 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2080/' | cut -d'.' -f1`
do
echo "Begin processing for 2080 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2080 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2081/' | cut -d'.' -f1`
do
echo "Begin processing for 2081 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2081 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2081/' | cut -d'.' -f1`
do
echo "Begin processing for 2081 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2081 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2082/' | cut -d'.' -f1`
do
echo "Begin processing for 2082 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2082 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2082/' | cut -d'.' -f1`
do
echo "Begin processing for 2082 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2082 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2085/' | cut -d'.' -f1`
do
echo "Begin processing for 2085 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2085 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2085/' | cut -d'.' -f1`
do
echo "Begin processing for 2085 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2085 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2087/' | cut -d'.' -f1`
do
echo "Begin processing for 2087 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2087 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2087/' | cut -d'.' -f1`
do
echo "Begin processing for 2087 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2087 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2088/' | cut -d'.' -f1`
do
echo "Begin processing for 2088 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2088 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2088/' | cut -d'.' -f1`
do
echo "Begin processing for 2088 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2088 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2089/' | cut -d'.' -f1`
do
echo "Begin processing for 2089 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2089 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2089/' | cut -d'.' -f1`
do
echo "Begin processing for 2089 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2089 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2091/' | cut -d'.' -f1`
do
echo "Begin processing for 2091 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2091 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2091/' | cut -d'.' -f1`
do
echo "Begin processing for 2091 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2091 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2093/' | cut -d'.' -f1`
do
echo "Begin processing for 2093 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2093 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2093/' | cut -d'.' -f1`
do
echo "Begin processing for 2093 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2093 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2096/' | cut -d'.' -f1`
do
echo "Begin processing for 2096 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2096 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2096/' | cut -d'.' -f1`
do
echo "Begin processing for 2096 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2096 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2097/' | cut -d'.' -f1`
do
echo "Begin processing for 2097 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2097 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2097/' | cut -d'.' -f1`
do
echo "Begin processing for 2097 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2097 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2101/' | cut -d'.' -f1`
do
echo "Begin processing for 2101 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2101 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2101/' | cut -d'.' -f1`
do
echo "Begin processing for 2101 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2101 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2103/' | cut -d'.' -f1`
do
echo "Begin processing for 2103 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2103 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2103/' | cut -d'.' -f1`
do
echo "Begin processing for 2103 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2103 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2109/' | cut -d'.' -f1`
do
echo "Begin processing for 2109 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2109 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2109/' | cut -d'.' -f1`
do
echo "Begin processing for 2109 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2109 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2150/' | cut -d'.' -f1`
do
echo "Begin processing for 2150 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2150 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2150/' | cut -d'.' -f1`
do
echo "Begin processing for 2150 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2150 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2153/' | cut -d'.' -f1`
do
echo "Begin processing for 2153 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2153 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2153/' | cut -d'.' -f1`
do
echo "Begin processing for 2153 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2153 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2154/' | cut -d'.' -f1`
do
echo "Begin processing for 2154 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2154 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2154/' | cut -d'.' -f1`
do
echo "Begin processing for 2154 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2154 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2157/' | cut -d'.' -f1`
do
echo "Begin processing for 2157 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2157 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2157/' | cut -d'.' -f1`
do
echo "Begin processing for 2157 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2157 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2158/' | cut -d'.' -f1`
do
echo "Begin processing for 2158 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2158 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2158/' | cut -d'.' -f1`
do
echo "Begin processing for 2158 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2158 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2159/' | cut -d'.' -f1`
do
echo "Begin processing for 2159 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2159 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2159/' | cut -d'.' -f1`
do
echo "Begin processing for 2159 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2159 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2160/' | cut -d'.' -f1`
do
echo "Begin processing for 2160 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2160 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2160/' | cut -d'.' -f1`
do
echo "Begin processing for 2160 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2160 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2161/' | cut -d'.' -f1`
do
echo "Begin processing for 2161 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2161 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2161/' | cut -d'.' -f1`
do
echo "Begin processing for 2161 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2161 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2162/' | cut -d'.' -f1`
do
echo "Begin processing for 2162 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2162 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2162/' | cut -d'.' -f1`
do
echo "Begin processing for 2162 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2162 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2177/' | cut -d'.' -f1`
do
echo "Begin processing for 2177 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2177 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2177/' | cut -d'.' -f1`
do
echo "Begin processing for 2177 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2177 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2178/' | cut -d'.' -f1`
do
echo "Begin processing for 2178 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2178 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2178/' | cut -d'.' -f1`
do
echo "Begin processing for 2178 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2178 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2179/' | cut -d'.' -f1`
do
echo "Begin processing for 2179 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2179 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2179/' | cut -d'.' -f1`
do
echo "Begin processing for 2179 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2179 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2182/' | cut -d'.' -f1`
do
echo "Begin processing for 2182 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2182 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2182/' | cut -d'.' -f1`
do
echo "Begin processing for 2182 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2182 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2185/' | cut -d'.' -f1`
do
echo "Begin processing for 2185 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2185 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2185/' | cut -d'.' -f1`
do
echo "Begin processing for 2185 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2185 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2186/' | cut -d'.' -f1`
do
echo "Begin processing for 2186 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2186 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2186/' | cut -d'.' -f1`
do
echo "Begin processing for 2186 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2186 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2187/' | cut -d'.' -f1`
do
echo "Begin processing for 2187 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2187 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2187/' | cut -d'.' -f1`
do
echo "Begin processing for 2187 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2187 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2189/' | cut -d'.' -f1`
do
echo "Begin processing for 2189 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2189 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2189/' | cut -d'.' -f1`
do
echo "Begin processing for 2189 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2189 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2190/' | cut -d'.' -f1`
do
echo "Begin processing for 2190 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2190 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2190/' | cut -d'.' -f1`
do
echo "Begin processing for 2190 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2190 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2191/' | cut -d'.' -f1`
do
echo "Begin processing for 2191 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2191 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2191/' | cut -d'.' -f1`
do
echo "Begin processing for 2191 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2191 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2192/' | cut -d'.' -f1`
do
echo "Begin processing for 2192 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2192 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2192/' | cut -d'.' -f1`
do
echo "Begin processing for 2192 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2192 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2193/' | cut -d'.' -f1`
do
echo "Begin processing for 2193 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2193 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2193/' | cut -d'.' -f1`
do
echo "Begin processing for 2193 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2193 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2194/' | cut -d'.' -f1`
do
echo "Begin processing for 2194 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2194 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2194/' | cut -d'.' -f1`
do
echo "Begin processing for 2194 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2194 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2195/' | cut -d'.' -f1`
do
echo "Begin processing for 2195 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2195 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2195/' | cut -d'.' -f1`
do
echo "Begin processing for 2195 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2195 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2197/' | cut -d'.' -f1`
do
echo "Begin processing for 2197 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2197 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2197/' | cut -d'.' -f1`
do
echo "Begin processing for 2197 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2197 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2198/' | cut -d'.' -f1`
do
echo "Begin processing for 2198 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2198 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2198/' | cut -d'.' -f1`
do
echo "Begin processing for 2198 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2198 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2206/' | cut -d'.' -f1`
do
echo "Begin processing for 2206 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2206 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2206/' | cut -d'.' -f1`
do
echo "Begin processing for 2206 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2206 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2207/' | cut -d'.' -f1`
do
echo "Begin processing for 2207 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2207 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2207/' | cut -d'.' -f1`
do
echo "Begin processing for 2207 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2207 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2212/' | cut -d'.' -f1`
do
echo "Begin processing for 2212 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2212 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2212/' | cut -d'.' -f1`
do
echo "Begin processing for 2212 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2212 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2213/' | cut -d'.' -f1`
do
echo "Begin processing for 2213 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2213 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2213/' | cut -d'.' -f1`
do
echo "Begin processing for 2213 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2213 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2214/' | cut -d'.' -f1`
do
echo "Begin processing for 2214 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2214 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2214/' | cut -d'.' -f1`
do
echo "Begin processing for 2214 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2214 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2215/' | cut -d'.' -f1`
do
echo "Begin processing for 2215 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2215 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2215/' | cut -d'.' -f1`
do
echo "Begin processing for 2215 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2215 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2217/' | cut -d'.' -f1`
do
echo "Begin processing for 2217 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2217 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2217/' | cut -d'.' -f1`
do
echo "Begin processing for 2217 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2217 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2219/' | cut -d'.' -f1`
do
echo "Begin processing for 2219 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2219 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2219/' | cut -d'.' -f1`
do
echo "Begin processing for 2219 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2219 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2220/' | cut -d'.' -f1`
do
echo "Begin processing for 2220 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2220 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2220/' | cut -d'.' -f1`
do
echo "Begin processing for 2220 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2220 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2221/' | cut -d'.' -f1`
do
echo "Begin processing for 2221 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2221 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2221/' | cut -d'.' -f1`
do
echo "Begin processing for 2221 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2221 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2222/' | cut -d'.' -f1`
do
echo "Begin processing for 2222 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2222 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2222/' | cut -d'.' -f1`
do
echo "Begin processing for 2222 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2222 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2225/' | cut -d'.' -f1`
do
echo "Begin processing for 2225 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2225 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2225/' | cut -d'.' -f1`
do
echo "Begin processing for 2225 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2225 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2226/' | cut -d'.' -f1`
do
echo "Begin processing for 2226 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2226 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2226/' | cut -d'.' -f1`
do
echo "Begin processing for 2226 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2226 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2228/' | cut -d'.' -f1`
do
echo "Begin processing for 2228 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2228 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2228/' | cut -d'.' -f1`
do
echo "Begin processing for 2228 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2228 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2229/' | cut -d'.' -f1`
do
echo "Begin processing for 2229 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2229 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2229/' | cut -d'.' -f1`
do
echo "Begin processing for 2229 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2229 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2231/' | cut -d'.' -f1`
do
echo "Begin processing for 2231 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2231 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2231/' | cut -d'.' -f1`
do
echo "Begin processing for 2231 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2231 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2233/' | cut -d'.' -f1`
do
echo "Begin processing for 2233 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2233 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2233/' | cut -d'.' -f1`
do
echo "Begin processing for 2233 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2233 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2234/' | cut -d'.' -f1`
do
echo "Begin processing for 2234 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2234 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2234/' | cut -d'.' -f1`
do
echo "Begin processing for 2234 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2234 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2235/' | cut -d'.' -f1`
do
echo "Begin processing for 2235 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2235 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2235/' | cut -d'.' -f1`
do
echo "Begin processing for 2235 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2235 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2239/' | cut -d'.' -f1`
do
echo "Begin processing for 2239 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2239 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2239/' | cut -d'.' -f1`
do
echo "Begin processing for 2239 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2239 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2241/' | cut -d'.' -f1`
do
echo "Begin processing for 2241 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2241 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2241/' | cut -d'.' -f1`
do
echo "Begin processing for 2241 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2241 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2242/' | cut -d'.' -f1`
do
echo "Begin processing for 2242 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2242 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2242/' | cut -d'.' -f1`
do
echo "Begin processing for 2242 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2242 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2506/' | cut -d'.' -f1`
do
echo "Begin processing for 2506 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2506 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2506/' | cut -d'.' -f1`
do
echo "Begin processing for 2506 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2506 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2507/' | cut -d'.' -f1`
do
echo "Begin processing for 2507 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2507 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2507/' | cut -d'.' -f1`
do
echo "Begin processing for 2507 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2507 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2508/' | cut -d'.' -f1`
do
echo "Begin processing for 2508 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2508 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2508/' | cut -d'.' -f1`
do
echo "Begin processing for 2508 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2508 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2510/' | cut -d'.' -f1`
do
echo "Begin processing for 2510 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2510 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2510/' | cut -d'.' -f1`
do
echo "Begin processing for 2510 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2510 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2515/' | cut -d'.' -f1`
do
echo "Begin processing for 2515 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2515 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2515/' | cut -d'.' -f1`
do
echo "Begin processing for 2515 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2515 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2516/' | cut -d'.' -f1`
do
echo "Begin processing for 2516 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2516 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2516/' | cut -d'.' -f1`
do
echo "Begin processing for 2516 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2516 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2518/' | cut -d'.' -f1`
do
echo "Begin processing for 2518 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2518 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2518/' | cut -d'.' -f1`
do
echo "Begin processing for 2518 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2518 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2519/' | cut -d'.' -f1`
do
echo "Begin processing for 2519 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2519 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2519/' | cut -d'.' -f1`
do
echo "Begin processing for 2519 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2519 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2522/' | cut -d'.' -f1`
do
echo "Begin processing for 2522 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2522 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2522/' | cut -d'.' -f1`
do
echo "Begin processing for 2522 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2522 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2529/' | cut -d'.' -f1`
do
echo "Begin processing for 2529 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2529 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2529/' | cut -d'.' -f1`
do
echo "Begin processing for 2529 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2529 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2530/' | cut -d'.' -f1`
do
echo "Begin processing for 2530 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2530 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2530/' | cut -d'.' -f1`
do
echo "Begin processing for 2530 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2530 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2536/' | cut -d'.' -f1`
do
echo "Begin processing for 2536 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2536 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2536/' | cut -d'.' -f1`
do
echo "Begin processing for 2536 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2536 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2540/' | cut -d'.' -f1`
do
echo "Begin processing for 2540 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2540 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2540/' | cut -d'.' -f1`
do
echo "Begin processing for 2540 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2540 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2541/' | cut -d'.' -f1`
do
echo "Begin processing for 2541 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2541 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2541/' | cut -d'.' -f1`
do
echo "Begin processing for 2541 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2541 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2543/' | cut -d'.' -f1`
do
echo "Begin processing for 2543 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2543 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2543/' | cut -d'.' -f1`
do
echo "Begin processing for 2543 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2543 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2547/' | cut -d'.' -f1`
do
echo "Begin processing for 2547 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2547 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2547/' | cut -d'.' -f1`
do
echo "Begin processing for 2547 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2547 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2548/' | cut -d'.' -f1`
do
echo "Begin processing for 2548 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2548 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2548/' | cut -d'.' -f1`
do
echo "Begin processing for 2548 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2548 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2549/' | cut -d'.' -f1`
do
echo "Begin processing for 2549 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2549 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2549/' | cut -d'.' -f1`
do
echo "Begin processing for 2549 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2549 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2571/' | cut -d'.' -f1`
do
echo "Begin processing for 2571 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2571 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2571/' | cut -d'.' -f1`
do
echo "Begin processing for 2571 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2571 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2572/' | cut -d'.' -f1`
do
echo "Begin processing for 2572 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2572 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2572/' | cut -d'.' -f1`
do
echo "Begin processing for 2572 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2572 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2573/' | cut -d'.' -f1`
do
echo "Begin processing for 2573 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2573 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2573/' | cut -d'.' -f1`
do
echo "Begin processing for 2573 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2573 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2575/' | cut -d'.' -f1`
do
echo "Begin processing for 2575 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2575 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2575/' | cut -d'.' -f1`
do
echo "Begin processing for 2575 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2575 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2576/' | cut -d'.' -f1`
do
echo "Begin processing for 2576 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2576 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2576/' | cut -d'.' -f1`
do
echo "Begin processing for 2576 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2576 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2587/' | cut -d'.' -f1`
do
echo "Begin processing for 2587 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2587 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2587/' | cut -d'.' -f1`
do
echo "Begin processing for 2587 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2587 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2588/' | cut -d'.' -f1`
do
echo "Begin processing for 2588 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2588 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2588/' | cut -d'.' -f1`
do
echo "Begin processing for 2588 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2588 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2594/' | cut -d'.' -f1`
do
echo "Begin processing for 2594 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2594 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2594/' | cut -d'.' -f1`
do
echo "Begin processing for 2594 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2594 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2596/' | cut -d'.' -f1`
do
echo "Begin processing for 2596 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2596 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2596/' | cut -d'.' -f1`
do
echo "Begin processing for 2596 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2596 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2599/' | cut -d'.' -f1`
do
echo "Begin processing for 2599 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2599 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2599/' | cut -d'.' -f1`
do
echo "Begin processing for 2599 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2599 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2601/' | cut -d'.' -f1`
do
echo "Begin processing for 2601 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2601 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2601/' | cut -d'.' -f1`
do
echo "Begin processing for 2601 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2601 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2604/' | cut -d'.' -f1`
do
echo "Begin processing for 2604 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2604 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2604/' | cut -d'.' -f1`
do
echo "Begin processing for 2604 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2604 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2608/' | cut -d'.' -f1`
do
echo "Begin processing for 2608 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2608 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2608/' | cut -d'.' -f1`
do
echo "Begin processing for 2608 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2608 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2612/' | cut -d'.' -f1`
do
echo "Begin processing for 2612 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2612 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2612/' | cut -d'.' -f1`
do
echo "Begin processing for 2612 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2612 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2614/' | cut -d'.' -f1`
do
echo "Begin processing for 2614 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2614 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2614/' | cut -d'.' -f1`
do
echo "Begin processing for 2614 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2614 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2617/' | cut -d'.' -f1`
do
echo "Begin processing for 2617 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2617 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2617/' | cut -d'.' -f1`
do
echo "Begin processing for 2617 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2617 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2618/' | cut -d'.' -f1`
do
echo "Begin processing for 2618 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2618 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2618/' | cut -d'.' -f1`
do
echo "Begin processing for 2618 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2618 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2621/' | cut -d'.' -f1`
do
echo "Begin processing for 2621 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2621 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2621/' | cut -d'.' -f1`
do
echo "Begin processing for 2621 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2621 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2625/' | cut -d'.' -f1`
do
echo "Begin processing for 2625 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2625 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2625/' | cut -d'.' -f1`
do
echo "Begin processing for 2625 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2625 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2628/' | cut -d'.' -f1`
do
echo "Begin processing for 2628 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2628 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2628/' | cut -d'.' -f1`
do
echo "Begin processing for 2628 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2628 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2630/' | cut -d'.' -f1`
do
echo "Begin processing for 2630 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2630 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2630/' | cut -d'.' -f1`
do
echo "Begin processing for 2630 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2630 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2631/' | cut -d'.' -f1`
do
echo "Begin processing for 2631 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2631 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2631/' | cut -d'.' -f1`
do
echo "Begin processing for 2631 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2631 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2632/' | cut -d'.' -f1`
do
echo "Begin processing for 2632 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2632 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2632/' | cut -d'.' -f1`
do
echo "Begin processing for 2632 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2632 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2636/' | cut -d'.' -f1`
do
echo "Begin processing for 2636 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2636 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2636/' | cut -d'.' -f1`
do
echo "Begin processing for 2636 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2636 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2640/' | cut -d'.' -f1`
do
echo "Begin processing for 2640 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2640 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2640/' | cut -d'.' -f1`
do
echo "Begin processing for 2640 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2640 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2643/' | cut -d'.' -f1`
do
echo "Begin processing for 2643 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2643 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2643/' | cut -d'.' -f1`
do
echo "Begin processing for 2643 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2643 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2644/' | cut -d'.' -f1`
do
echo "Begin processing for 2644 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2644 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2644/' | cut -d'.' -f1`
do
echo "Begin processing for 2644 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2644 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2645/' | cut -d'.' -f1`
do
echo "Begin processing for 2645 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2645 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2645/' | cut -d'.' -f1`
do
echo "Begin processing for 2645 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2645 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2653/' | cut -d'.' -f1`
do
echo "Begin processing for 2653 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2653 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2653/' | cut -d'.' -f1`
do
echo "Begin processing for 2653 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2653 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2657/' | cut -d'.' -f1`
do
echo "Begin processing for 2657 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2657 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2657/' | cut -d'.' -f1`
do
echo "Begin processing for 2657 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2657 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2658/' | cut -d'.' -f1`
do
echo "Begin processing for 2658 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2658 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2658/' | cut -d'.' -f1`
do
echo "Begin processing for 2658 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2658 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2659/' | cut -d'.' -f1`
do
echo "Begin processing for 2659 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2659 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2659/' | cut -d'.' -f1`
do
echo "Begin processing for 2659 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2659 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2660/' | cut -d'.' -f1`
do
echo "Begin processing for 2660 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2660 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2660/' | cut -d'.' -f1`
do
echo "Begin processing for 2660 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2660 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2662/' | cut -d'.' -f1`
do
echo "Begin processing for 2662 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2662 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2662/' | cut -d'.' -f1`
do
echo "Begin processing for 2662 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2662 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2664/' | cut -d'.' -f1`
do
echo "Begin processing for 2664 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2664 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2664/' | cut -d'.' -f1`
do
echo "Begin processing for 2664 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2664 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2669/' | cut -d'.' -f1`
do
echo "Begin processing for 2669 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2669 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2669/' | cut -d'.' -f1`
do
echo "Begin processing for 2669 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2669 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2678/' | cut -d'.' -f1`
do
echo "Begin processing for 2678 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2678 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2678/' | cut -d'.' -f1`
do
echo "Begin processing for 2678 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2678 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2682/' | cut -d'.' -f1`
do
echo "Begin processing for 2682 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2682 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2682/' | cut -d'.' -f1`
do
echo "Begin processing for 2682 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2682 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2688/' | cut -d'.' -f1`
do
echo "Begin processing for 2688 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2688 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2688/' | cut -d'.' -f1`
do
echo "Begin processing for 2688 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2688 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2689/' | cut -d'.' -f1`
do
echo "Begin processing for 2689 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2689 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2689/' | cut -d'.' -f1`
do
echo "Begin processing for 2689 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2689 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2690/' | cut -d'.' -f1`
do
echo "Begin processing for 2690 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2690 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2690/' | cut -d'.' -f1`
do
echo "Begin processing for 2690 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2690 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2692/' | cut -d'.' -f1`
do
echo "Begin processing for 2692 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2692 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2692/' | cut -d'.' -f1`
do
echo "Begin processing for 2692 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2692 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2695/' | cut -d'.' -f1`
do
echo "Begin processing for 2695 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2695 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2695/' | cut -d'.' -f1`
do
echo "Begin processing for 2695 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2695 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2696/' | cut -d'.' -f1`
do
echo "Begin processing for 2696 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2696 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2696/' | cut -d'.' -f1`
do
echo "Begin processing for 2696 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2696 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2698/' | cut -d'.' -f1`
do
echo "Begin processing for 2698 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2698 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2698/' | cut -d'.' -f1`
do
echo "Begin processing for 2698 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2698 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2699/' | cut -d'.' -f1`
do
echo "Begin processing for 2699 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2699 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2699/' | cut -d'.' -f1`
do
echo "Begin processing for 2699 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2699 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2700/' | cut -d'.' -f1`
do
echo "Begin processing for 2700 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2700 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2700/' | cut -d'.' -f1`
do
echo "Begin processing for 2700 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2700 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2701/' | cut -d'.' -f1`
do
echo "Begin processing for 2701 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2701 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2701/' | cut -d'.' -f1`
do
echo "Begin processing for 2701 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2701 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2702/' | cut -d'.' -f1`
do
echo "Begin processing for 2702 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2702 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2702/' | cut -d'.' -f1`
do
echo "Begin processing for 2702 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2702 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2704/' | cut -d'.' -f1`
do
echo "Begin processing for 2704 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2704 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2704/' | cut -d'.' -f1`
do
echo "Begin processing for 2704 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2704 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2706/' | cut -d'.' -f1`
do
echo "Begin processing for 2706 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2706 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2706/' | cut -d'.' -f1`
do
echo "Begin processing for 2706 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2706 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2707/' | cut -d'.' -f1`
do
echo "Begin processing for 2707 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2707 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2707/' | cut -d'.' -f1`
do
echo "Begin processing for 2707 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2707 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2708/' | cut -d'.' -f1`
do
echo "Begin processing for 2708 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2708 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2708/' | cut -d'.' -f1`
do
echo "Begin processing for 2708 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2708 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2711/' | cut -d'.' -f1`
do
echo "Begin processing for 2711 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2711 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2711/' | cut -d'.' -f1`
do
echo "Begin processing for 2711 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2711 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2719/' | cut -d'.' -f1`
do
echo "Begin processing for 2719 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2719 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2719/' | cut -d'.' -f1`
do
echo "Begin processing for 2719 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2719 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2721/' | cut -d'.' -f1`
do
echo "Begin processing for 2721 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2721 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2721/' | cut -d'.' -f1`
do
echo "Begin processing for 2721 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2721 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2722/' | cut -d'.' -f1`
do
echo "Begin processing for 2722 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2722 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2722/' | cut -d'.' -f1`
do
echo "Begin processing for 2722 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2722 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2729/' | cut -d'.' -f1`
do
echo "Begin processing for 2729 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2729 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2729/' | cut -d'.' -f1`
do
echo "Begin processing for 2729 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2729 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2731/' | cut -d'.' -f1`
do
echo "Begin processing for 2731 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2731 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2731/' | cut -d'.' -f1`
do
echo "Begin processing for 2731 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2731 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2733/' | cut -d'.' -f1`
do
echo "Begin processing for 2733 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2733 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2733/' | cut -d'.' -f1`
do
echo "Begin processing for 2733 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2733 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2737/' | cut -d'.' -f1`
do
echo "Begin processing for 2737 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2737 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2737/' | cut -d'.' -f1`
do
echo "Begin processing for 2737 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2737 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2741/' | cut -d'.' -f1`
do
echo "Begin processing for 2741 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2741 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2741/' | cut -d'.' -f1`
do
echo "Begin processing for 2741 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2741 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2752/' | cut -d'.' -f1`
do
echo "Begin processing for 2752 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2752 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2752/' | cut -d'.' -f1`
do
echo "Begin processing for 2752 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2752 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2755/' | cut -d'.' -f1`
do
echo "Begin processing for 2755 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2755 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2755/' | cut -d'.' -f1`
do
echo "Begin processing for 2755 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2755 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2757/' | cut -d'.' -f1`
do
echo "Begin processing for 2757 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2757 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2757/' | cut -d'.' -f1`
do
echo "Begin processing for 2757 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2757 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2760/' | cut -d'.' -f1`
do
echo "Begin processing for 2760 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2760 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2760/' | cut -d'.' -f1`
do
echo "Begin processing for 2760 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2760 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2763/' | cut -d'.' -f1`
do
echo "Begin processing for 2763 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2763 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2763/' | cut -d'.' -f1`
do
echo "Begin processing for 2763 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2763 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2767/' | cut -d'.' -f1`
do
echo "Begin processing for 2767 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2767 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2767/' | cut -d'.' -f1`
do
echo "Begin processing for 2767 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2767 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2768/' | cut -d'.' -f1`
do
echo "Begin processing for 2768 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2768 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2768/' | cut -d'.' -f1`
do
echo "Begin processing for 2768 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2768 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2771/' | cut -d'.' -f1`
do
echo "Begin processing for 2771 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2771 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2771/' | cut -d'.' -f1`
do
echo "Begin processing for 2771 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2771 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2774/' | cut -d'.' -f1`
do
echo "Begin processing for 2774 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2774 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2774/' | cut -d'.' -f1`
do
echo "Begin processing for 2774 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2774 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2775/' | cut -d'.' -f1`
do
echo "Begin processing for 2775 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2775 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2775/' | cut -d'.' -f1`
do
echo "Begin processing for 2775 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2775 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2777/' | cut -d'.' -f1`
do
echo "Begin processing for 2777 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2777 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2777/' | cut -d'.' -f1`
do
echo "Begin processing for 2777 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2777 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2778/' | cut -d'.' -f1`
do
echo "Begin processing for 2778 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2778 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2778/' | cut -d'.' -f1`
do
echo "Begin processing for 2778 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2778 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2779/' | cut -d'.' -f1`
do
echo "Begin processing for 2779 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2779 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2779/' | cut -d'.' -f1`
do
echo "Begin processing for 2779 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2779 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2780/' | cut -d'.' -f1`
do
echo "Begin processing for 2780 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2780 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2780/' | cut -d'.' -f1`
do
echo "Begin processing for 2780 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2780 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2781/' | cut -d'.' -f1`
do
echo "Begin processing for 2781 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2781 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2781/' | cut -d'.' -f1`
do
echo "Begin processing for 2781 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2781 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2782/' | cut -d'.' -f1`
do
echo "Begin processing for 2782 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2782 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2782/' | cut -d'.' -f1`
do
echo "Begin processing for 2782 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2782 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2783/' | cut -d'.' -f1`
do
echo "Begin processing for 2783 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2783 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2783/' | cut -d'.' -f1`
do
echo "Begin processing for 2783 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2783 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2784/' | cut -d'.' -f1`
do
echo "Begin processing for 2784 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2784 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2784/' | cut -d'.' -f1`
do
echo "Begin processing for 2784 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2784 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2785/' | cut -d'.' -f1`
do
echo "Begin processing for 2785 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2785 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2785/' | cut -d'.' -f1`
do
echo "Begin processing for 2785 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2785 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2787/' | cut -d'.' -f1`
do
echo "Begin processing for 2787 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2787 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2787/' | cut -d'.' -f1`
do
echo "Begin processing for 2787 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2787 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2788/' | cut -d'.' -f1`
do
echo "Begin processing for 2788 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2788 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2788/' | cut -d'.' -f1`
do
echo "Begin processing for 2788 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2788 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2790/' | cut -d'.' -f1`
do
echo "Begin processing for 2790 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2790 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2790/' | cut -d'.' -f1`
do
echo "Begin processing for 2790 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2790 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2791/' | cut -d'.' -f1`
do
echo "Begin processing for 2791 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2791 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2791/' | cut -d'.' -f1`
do
echo "Begin processing for 2791 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2791 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2792/' | cut -d'.' -f1`
do
echo "Begin processing for 2792 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2792 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2792/' | cut -d'.' -f1`
do
echo "Begin processing for 2792 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2792 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2797/' | cut -d'.' -f1`
do
echo "Begin processing for 2797 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2797 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2797/' | cut -d'.' -f1`
do
echo "Begin processing for 2797 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2797 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2798/' | cut -d'.' -f1`
do
echo "Begin processing for 2798 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2798 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2798/' | cut -d'.' -f1`
do
echo "Begin processing for 2798 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2798 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2799/' | cut -d'.' -f1`
do
echo "Begin processing for 2799 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2799 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2799/' | cut -d'.' -f1`
do
echo "Begin processing for 2799 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2799 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2801/' | cut -d'.' -f1`
do
echo "Begin processing for 2801 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2801 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2801/' | cut -d'.' -f1`
do
echo "Begin processing for 2801 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2801 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2802/' | cut -d'.' -f1`
do
echo "Begin processing for 2802 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2802 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2802/' | cut -d'.' -f1`
do
echo "Begin processing for 2802 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2802 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2803/' | cut -d'.' -f1`
do
echo "Begin processing for 2803 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2803 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2803/' | cut -d'.' -f1`
do
echo "Begin processing for 2803 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2803 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2805/' | cut -d'.' -f1`
do
echo "Begin processing for 2805 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2805 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2805/' | cut -d'.' -f1`
do
echo "Begin processing for 2805 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2805 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2806/' | cut -d'.' -f1`
do
echo "Begin processing for 2806 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2806 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2806/' | cut -d'.' -f1`
do
echo "Begin processing for 2806 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2806 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2807/' | cut -d'.' -f1`
do
echo "Begin processing for 2807 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2807 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2807/' | cut -d'.' -f1`
do
echo "Begin processing for 2807 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2807 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2808/' | cut -d'.' -f1`
do
echo "Begin processing for 2808 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2808 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2808/' | cut -d'.' -f1`
do
echo "Begin processing for 2808 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2808 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2819/' | cut -d'.' -f1`
do
echo "Begin processing for 2819 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2819 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2819/' | cut -d'.' -f1`
do
echo "Begin processing for 2819 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2819 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2820/' | cut -d'.' -f1`
do
echo "Begin processing for 2820 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2820 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2820/' | cut -d'.' -f1`
do
echo "Begin processing for 2820 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2820 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2822/' | cut -d'.' -f1`
do
echo "Begin processing for 2822 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2822 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2822/' | cut -d'.' -f1`
do
echo "Begin processing for 2822 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2822 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2823/' | cut -d'.' -f1`
do
echo "Begin processing for 2823 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2823 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2823/' | cut -d'.' -f1`
do
echo "Begin processing for 2823 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2823 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2825/' | cut -d'.' -f1`
do
echo "Begin processing for 2825 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2825 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2825/' | cut -d'.' -f1`
do
echo "Begin processing for 2825 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2825 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2826/' | cut -d'.' -f1`
do
echo "Begin processing for 2826 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2826 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2826/' | cut -d'.' -f1`
do
echo "Begin processing for 2826 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2826 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2827/' | cut -d'.' -f1`
do
echo "Begin processing for 2827 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2827 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2827/' | cut -d'.' -f1`
do
echo "Begin processing for 2827 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2827 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2828/' | cut -d'.' -f1`
do
echo "Begin processing for 2828 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2828 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2828/' | cut -d'.' -f1`
do
echo "Begin processing for 2828 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2828 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2830/' | cut -d'.' -f1`
do
echo "Begin processing for 2830 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2830 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2830/' | cut -d'.' -f1`
do
echo "Begin processing for 2830 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2830 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2833/' | cut -d'.' -f1`
do
echo "Begin processing for 2833 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2833 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2833/' | cut -d'.' -f1`
do
echo "Begin processing for 2833 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2833 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2838/' | cut -d'.' -f1`
do
echo "Begin processing for 2838 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2838 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2838/' | cut -d'.' -f1`
do
echo "Begin processing for 2838 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2838 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2839/' | cut -d'.' -f1`
do
echo "Begin processing for 2839 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2839 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2839/' | cut -d'.' -f1`
do
echo "Begin processing for 2839 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2839 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2840/' | cut -d'.' -f1`
do
echo "Begin processing for 2840 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2840 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2840/' | cut -d'.' -f1`
do
echo "Begin processing for 2840 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2840 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2842/' | cut -d'.' -f1`
do
echo "Begin processing for 2842 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2842 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2842/' | cut -d'.' -f1`
do
echo "Begin processing for 2842 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2842 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2843/' | cut -d'.' -f1`
do
echo "Begin processing for 2843 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2843 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2843/' | cut -d'.' -f1`
do
echo "Begin processing for 2843 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2843 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2849/' | cut -d'.' -f1`
do
echo "Begin processing for 2849 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2849 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2849/' | cut -d'.' -f1`
do
echo "Begin processing for 2849 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2849 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2852/' | cut -d'.' -f1`
do
echo "Begin processing for 2852 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2852 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2852/' | cut -d'.' -f1`
do
echo "Begin processing for 2852 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2852 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2853/' | cut -d'.' -f1`
do
echo "Begin processing for 2853 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2853 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2853/' | cut -d'.' -f1`
do
echo "Begin processing for 2853 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2853 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2856/' | cut -d'.' -f1`
do
echo "Begin processing for 2856 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2856 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2856/' | cut -d'.' -f1`
do
echo "Begin processing for 2856 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2856 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2857/' | cut -d'.' -f1`
do
echo "Begin processing for 2857 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2857 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2857/' | cut -d'.' -f1`
do
echo "Begin processing for 2857 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2857 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2858/' | cut -d'.' -f1`
do
echo "Begin processing for 2858 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2858 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2858/' | cut -d'.' -f1`
do
echo "Begin processing for 2858 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2858 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2859/' | cut -d'.' -f1`
do
echo "Begin processing for 2859 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2859 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2859/' | cut -d'.' -f1`
do
echo "Begin processing for 2859 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2859 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2862/' | cut -d'.' -f1`
do
echo "Begin processing for 2862 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2862 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2862/' | cut -d'.' -f1`
do
echo "Begin processing for 2862 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2862 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2864/' | cut -d'.' -f1`
do
echo "Begin processing for 2864 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2864 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2864/' | cut -d'.' -f1`
do
echo "Begin processing for 2864 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2864 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2866/' | cut -d'.' -f1`
do
echo "Begin processing for 2866 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2866 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2866/' | cut -d'.' -f1`
do
echo "Begin processing for 2866 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2866 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2867/' | cut -d'.' -f1`
do
echo "Begin processing for 2867 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2867 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2867/' | cut -d'.' -f1`
do
echo "Begin processing for 2867 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2867 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2868/' | cut -d'.' -f1`
do
echo "Begin processing for 2868 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2868 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2868/' | cut -d'.' -f1`
do
echo "Begin processing for 2868 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2868 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2869/' | cut -d'.' -f1`
do
echo "Begin processing for 2869 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2869 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2869/' | cut -d'.' -f1`
do
echo "Begin processing for 2869 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2869 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2870/' | cut -d'.' -f1`
do
echo "Begin processing for 2870 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2870 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2870/' | cut -d'.' -f1`
do
echo "Begin processing for 2870 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2870 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2871/' | cut -d'.' -f1`
do
echo "Begin processing for 2871 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2871 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2871/' | cut -d'.' -f1`
do
echo "Begin processing for 2871 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2871 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2872/' | cut -d'.' -f1`
do
echo "Begin processing for 2872 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2872 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2872/' | cut -d'.' -f1`
do
echo "Begin processing for 2872 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2872 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2873/' | cut -d'.' -f1`
do
echo "Begin processing for 2873 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2873 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2873/' | cut -d'.' -f1`
do
echo "Begin processing for 2873 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2873 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2874/' | cut -d'.' -f1`
do
echo "Begin processing for 2874 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2874 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2874/' | cut -d'.' -f1`
do
echo "Begin processing for 2874 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2874 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2876/' | cut -d'.' -f1`
do
echo "Begin processing for 2876 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2876 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2876/' | cut -d'.' -f1`
do
echo "Begin processing for 2876 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2876 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2879/' | cut -d'.' -f1`
do
echo "Begin processing for 2879 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2879 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2879/' | cut -d'.' -f1`
do
echo "Begin processing for 2879 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2879 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2881/' | cut -d'.' -f1`
do
echo "Begin processing for 2881 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2881 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2881/' | cut -d'.' -f1`
do
echo "Begin processing for 2881 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2881 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2882/' | cut -d'.' -f1`
do
echo "Begin processing for 2882 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2882 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2882/' | cut -d'.' -f1`
do
echo "Begin processing for 2882 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2882 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2883/' | cut -d'.' -f1`
do
echo "Begin processing for 2883 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2883 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2883/' | cut -d'.' -f1`
do
echo "Begin processing for 2883 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2883 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2884/' | cut -d'.' -f1`
do
echo "Begin processing for 2884 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2884 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2884/' | cut -d'.' -f1`
do
echo "Begin processing for 2884 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2884 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2886/' | cut -d'.' -f1`
do
echo "Begin processing for 2886 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2886 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2886/' | cut -d'.' -f1`
do
echo "Begin processing for 2886 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2886 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2887/' | cut -d'.' -f1`
do
echo "Begin processing for 2887 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2887 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2887/' | cut -d'.' -f1`
do
echo "Begin processing for 2887 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2887 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2888/' | cut -d'.' -f1`
do
echo "Begin processing for 2888 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2888 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2888/' | cut -d'.' -f1`
do
echo "Begin processing for 2888 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2888 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2889/' | cut -d'.' -f1`
do
echo "Begin processing for 2889 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2889 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2889/' | cut -d'.' -f1`
do
echo "Begin processing for 2889 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2889 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2892/' | cut -d'.' -f1`
do
echo "Begin processing for 2892 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2892 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2892/' | cut -d'.' -f1`
do
echo "Begin processing for 2892 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2892 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2895/' | cut -d'.' -f1`
do
echo "Begin processing for 2895 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2895 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2895/' | cut -d'.' -f1`
do
echo "Begin processing for 2895 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2895 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2912/' | cut -d'.' -f1`
do
echo "Begin processing for 2912 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2912 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2912/' | cut -d'.' -f1`
do
echo "Begin processing for 2912 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2912 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2913/' | cut -d'.' -f1`
do
echo "Begin processing for 2913 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2913 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2913/' | cut -d'.' -f1`
do
echo "Begin processing for 2913 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2913 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2916/' | cut -d'.' -f1`
do
echo "Begin processing for 2916 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2916 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2916/' | cut -d'.' -f1`
do
echo "Begin processing for 2916 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2916 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2917/' | cut -d'.' -f1`
do
echo "Begin processing for 2917 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2917 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2917/' | cut -d'.' -f1`
do
echo "Begin processing for 2917 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2917 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2999/' | cut -d'.' -f1`
do
echo "Begin processing for 2999 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2999 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2999/' | cut -d'.' -f1`
do
echo "Begin processing for 2999 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2999 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_3501/' | cut -d'.' -f1`
do
echo "Begin processing for 3501 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 3501 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_3501/' | cut -d'.' -f1`
do
echo "Begin processing for 3501 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 3501 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_3502/' | cut -d'.' -f1`
do
echo "Begin processing for 3502 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 3502 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_3502/' | cut -d'.' -f1`
do
echo "Begin processing for 3502 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 3502 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_4101/' | cut -d'.' -f1`
do
echo "Begin processing for 4101 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 4101 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_4101/' | cut -d'.' -f1`
do
echo "Begin processing for 4101 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 4101 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_4102/' | cut -d'.' -f1`
do
echo "Begin processing for 4102 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 4102 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_4102/' | cut -d'.' -f1`
do
echo "Begin processing for 4102 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 4102 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_4104/' | cut -d'.' -f1`
do
echo "Begin processing for 4104 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 4104 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_4104/' | cut -d'.' -f1`
do
echo "Begin processing for 4104 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 4104 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_4181/' | cut -d'.' -f1`
do
echo "Begin processing for 4181 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 4181 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_4181/' | cut -d'.' -f1`
do
echo "Begin processing for 4181 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 4181 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_4183/' | cut -d'.' -f1`
do
echo "Begin processing for 4183 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 4183 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_4183/' | cut -d'.' -f1`
do
echo "Begin processing for 4183 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 4183 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5003/' | cut -d'.' -f1`
do
echo "Begin processing for 5003 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5003 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5003/' | cut -d'.' -f1`
do
echo "Begin processing for 5003 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5003 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5005/' | cut -d'.' -f1`
do
echo "Begin processing for 5005 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5005 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5005/' | cut -d'.' -f1`
do
echo "Begin processing for 5005 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5005 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5009/' | cut -d'.' -f1`
do
echo "Begin processing for 5009 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5009 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5009/' | cut -d'.' -f1`
do
echo "Begin processing for 5009 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5009 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5010/' | cut -d'.' -f1`
do
echo "Begin processing for 5010 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5010 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5010/' | cut -d'.' -f1`
do
echo "Begin processing for 5010 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5010 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5011/' | cut -d'.' -f1`
do
echo "Begin processing for 5011 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5011 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5011/' | cut -d'.' -f1`
do
echo "Begin processing for 5011 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5011 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5012/' | cut -d'.' -f1`
do
echo "Begin processing for 5012 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5012 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5012/' | cut -d'.' -f1`
do
echo "Begin processing for 5012 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5012 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5013/' | cut -d'.' -f1`
do
echo "Begin processing for 5013 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5013 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5013/' | cut -d'.' -f1`
do
echo "Begin processing for 5013 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5013 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5014/' | cut -d'.' -f1`
do
echo "Begin processing for 5014 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5014 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5014/' | cut -d'.' -f1`
do
echo "Begin processing for 5014 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5014 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5016/' | cut -d'.' -f1`
do
echo "Begin processing for 5016 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5016 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5016/' | cut -d'.' -f1`
do
echo "Begin processing for 5016 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5016 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5018/' | cut -d'.' -f1`
do
echo "Begin processing for 5018 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5018 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5018/' | cut -d'.' -f1`
do
echo "Begin processing for 5018 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5018 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5019/' | cut -d'.' -f1`
do
echo "Begin processing for 5019 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5019 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5019/' | cut -d'.' -f1`
do
echo "Begin processing for 5019 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5019 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5022/' | cut -d'.' -f1`
do
echo "Begin processing for 5022 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5022 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5022/' | cut -d'.' -f1`
do
echo "Begin processing for 5022 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5022 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5026/' | cut -d'.' -f1`
do
echo "Begin processing for 5026 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5026 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5026/' | cut -d'.' -f1`
do
echo "Begin processing for 5026 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5026 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5028/' | cut -d'.' -f1`
do
echo "Begin processing for 5028 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5028 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5028/' | cut -d'.' -f1`
do
echo "Begin processing for 5028 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5028 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5030/' | cut -d'.' -f1`
do
echo "Begin processing for 5030 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5030 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5030/' | cut -d'.' -f1`
do
echo "Begin processing for 5030 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5030 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5031/' | cut -d'.' -f1`
do
echo "Begin processing for 5031 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5031 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5031/' | cut -d'.' -f1`
do
echo "Begin processing for 5031 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5031 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5033/' | cut -d'.' -f1`
do
echo "Begin processing for 5033 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5033 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5033/' | cut -d'.' -f1`
do
echo "Begin processing for 5033 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5033 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5036/' | cut -d'.' -f1`
do
echo "Begin processing for 5036 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5036 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5036/' | cut -d'.' -f1`
do
echo "Begin processing for 5036 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5036 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5037/' | cut -d'.' -f1`
do
echo "Begin processing for 5037 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5037 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5037/' | cut -d'.' -f1`
do
echo "Begin processing for 5037 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5037 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5041/' | cut -d'.' -f1`
do
echo "Begin processing for 5041 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5041 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5041/' | cut -d'.' -f1`
do
echo "Begin processing for 5041 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5041 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5042/' | cut -d'.' -f1`
do
echo "Begin processing for 5042 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5042 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5042/' | cut -d'.' -f1`
do
echo "Begin processing for 5042 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5042 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5044/' | cut -d'.' -f1`
do
echo "Begin processing for 5044 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5044 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5044/' | cut -d'.' -f1`
do
echo "Begin processing for 5044 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5044 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5045/' | cut -d'.' -f1`
do
echo "Begin processing for 5045 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5045 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5045/' | cut -d'.' -f1`
do
echo "Begin processing for 5045 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5045 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5046/' | cut -d'.' -f1`
do
echo "Begin processing for 5046 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5046 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5046/' | cut -d'.' -f1`
do
echo "Begin processing for 5046 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5046 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5048/' | cut -d'.' -f1`
do
echo "Begin processing for 5048 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5048 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5048/' | cut -d'.' -f1`
do
echo "Begin processing for 5048 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5048 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5049/' | cut -d'.' -f1`
do
echo "Begin processing for 5049 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5049 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5049/' | cut -d'.' -f1`
do
echo "Begin processing for 5049 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5049 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5050/' | cut -d'.' -f1`
do
echo "Begin processing for 5050 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5050 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5050/' | cut -d'.' -f1`
do
echo "Begin processing for 5050 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5050 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5053/' | cut -d'.' -f1`
do
echo "Begin processing for 5053 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5053 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5053/' | cut -d'.' -f1`
do
echo "Begin processing for 5053 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5053 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5055/' | cut -d'.' -f1`
do
echo "Begin processing for 5055 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5055 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5055/' | cut -d'.' -f1`
do
echo "Begin processing for 5055 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5055 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5056/' | cut -d'.' -f1`
do
echo "Begin processing for 5056 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5056 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5056/' | cut -d'.' -f1`
do
echo "Begin processing for 5056 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5056 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5057/' | cut -d'.' -f1`
do
echo "Begin processing for 5057 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5057 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5057/' | cut -d'.' -f1`
do
echo "Begin processing for 5057 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5057 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5058/' | cut -d'.' -f1`
do
echo "Begin processing for 5058 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5058 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5058/' | cut -d'.' -f1`
do
echo "Begin processing for 5058 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5058 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5059/' | cut -d'.' -f1`
do
echo "Begin processing for 5059 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5059 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5059/' | cut -d'.' -f1`
do
echo "Begin processing for 5059 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5059 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5060/' | cut -d'.' -f1`
do
echo "Begin processing for 5060 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5060 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5060/' | cut -d'.' -f1`
do
echo "Begin processing for 5060 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5060 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5064/' | cut -d'.' -f1`
do
echo "Begin processing for 5064 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5064 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5064/' | cut -d'.' -f1`
do
echo "Begin processing for 5064 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5064 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5066/' | cut -d'.' -f1`
do
echo "Begin processing for 5066 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5066 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5066/' | cut -d'.' -f1`
do
echo "Begin processing for 5066 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5066 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5068/' | cut -d'.' -f1`
do
echo "Begin processing for 5068 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5068 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5068/' | cut -d'.' -f1`
do
echo "Begin processing for 5068 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5068 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5071/' | cut -d'.' -f1`
do
echo "Begin processing for 5071 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5071 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5071/' | cut -d'.' -f1`
do
echo "Begin processing for 5071 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5071 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5072/' | cut -d'.' -f1`
do
echo "Begin processing for 5072 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5072 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5072/' | cut -d'.' -f1`
do
echo "Begin processing for 5072 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5072 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5073/' | cut -d'.' -f1`
do
echo "Begin processing for 5073 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5073 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5073/' | cut -d'.' -f1`
do
echo "Begin processing for 5073 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5073 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5074/' | cut -d'.' -f1`
do
echo "Begin processing for 5074 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5074 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5074/' | cut -d'.' -f1`
do
echo "Begin processing for 5074 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5074 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5075/' | cut -d'.' -f1`
do
echo "Begin processing for 5075 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5075 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5075/' | cut -d'.' -f1`
do
echo "Begin processing for 5075 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5075 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5076/' | cut -d'.' -f1`
do
echo "Begin processing for 5076 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5076 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5076/' | cut -d'.' -f1`
do
echo "Begin processing for 5076 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5076 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5077/' | cut -d'.' -f1`
do
echo "Begin processing for 5077 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5077 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5077/' | cut -d'.' -f1`
do
echo "Begin processing for 5077 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5077 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5079/' | cut -d'.' -f1`
do
echo "Begin processing for 5079 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5079 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5079/' | cut -d'.' -f1`
do
echo "Begin processing for 5079 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5079 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5086/' | cut -d'.' -f1`
do
echo "Begin processing for 5086 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5086 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5086/' | cut -d'.' -f1`
do
echo "Begin processing for 5086 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5086 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5090/' | cut -d'.' -f1`
do
echo "Begin processing for 5090 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5090 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5090/' | cut -d'.' -f1`
do
echo "Begin processing for 5090 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5090 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5091/' | cut -d'.' -f1`
do
echo "Begin processing for 5091 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5091 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5091/' | cut -d'.' -f1`
do
echo "Begin processing for 5091 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5091 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5096/' | cut -d'.' -f1`
do
echo "Begin processing for 5096 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5096 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5096/' | cut -d'.' -f1`
do
echo "Begin processing for 5096 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5096 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5101/' | cut -d'.' -f1`
do
echo "Begin processing for 5101 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5101 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5101/' | cut -d'.' -f1`
do
echo "Begin processing for 5101 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5101 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5102/' | cut -d'.' -f1`
do
echo "Begin processing for 5102 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5102 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5102/' | cut -d'.' -f1`
do
echo "Begin processing for 5102 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5102 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5103/' | cut -d'.' -f1`
do
echo "Begin processing for 5103 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5103 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5103/' | cut -d'.' -f1`
do
echo "Begin processing for 5103 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5103 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5105/' | cut -d'.' -f1`
do
echo "Begin processing for 5105 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5105 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5105/' | cut -d'.' -f1`
do
echo "Begin processing for 5105 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5105 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5106/' | cut -d'.' -f1`
do
echo "Begin processing for 5106 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5106 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5106/' | cut -d'.' -f1`
do
echo "Begin processing for 5106 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5106 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5107/' | cut -d'.' -f1`
do
echo "Begin processing for 5107 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5107 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5107/' | cut -d'.' -f1`
do
echo "Begin processing for 5107 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5107 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5109/' | cut -d'.' -f1`
do
echo "Begin processing for 5109 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5109 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5109/' | cut -d'.' -f1`
do
echo "Begin processing for 5109 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5109 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5121/' | cut -d'.' -f1`
do
echo "Begin processing for 5121 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5121 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5121/' | cut -d'.' -f1`
do
echo "Begin processing for 5121 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5121 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5122/' | cut -d'.' -f1`
do
echo "Begin processing for 5122 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5122 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5122/' | cut -d'.' -f1`
do
echo "Begin processing for 5122 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5122 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5123/' | cut -d'.' -f1`
do
echo "Begin processing for 5123 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5123 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5123/' | cut -d'.' -f1`
do
echo "Begin processing for 5123 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5123 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5124/' | cut -d'.' -f1`
do
echo "Begin processing for 5124 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5124 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5124/' | cut -d'.' -f1`
do
echo "Begin processing for 5124 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5124 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5125/' | cut -d'.' -f1`
do
echo "Begin processing for 5125 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5125 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5125/' | cut -d'.' -f1`
do
echo "Begin processing for 5125 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5125 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5128/' | cut -d'.' -f1`
do
echo "Begin processing for 5128 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5128 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5128/' | cut -d'.' -f1`
do
echo "Begin processing for 5128 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5128 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5129/' | cut -d'.' -f1`
do
echo "Begin processing for 5129 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5129 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5129/' | cut -d'.' -f1`
do
echo "Begin processing for 5129 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5129 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5131/' | cut -d'.' -f1`
do
echo "Begin processing for 5131 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5131 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5131/' | cut -d'.' -f1`
do
echo "Begin processing for 5131 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5131 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5132/' | cut -d'.' -f1`
do
echo "Begin processing for 5132 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5132 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5132/' | cut -d'.' -f1`
do
echo "Begin processing for 5132 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5132 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5135/' | cut -d'.' -f1`
do
echo "Begin processing for 5135 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5135 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5135/' | cut -d'.' -f1`
do
echo "Begin processing for 5135 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5135 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5136/' | cut -d'.' -f1`
do
echo "Begin processing for 5136 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5136 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5136/' | cut -d'.' -f1`
do
echo "Begin processing for 5136 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5136 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5141/' | cut -d'.' -f1`
do
echo "Begin processing for 5141 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5141 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5141/' | cut -d'.' -f1`
do
echo "Begin processing for 5141 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5141 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5143/' | cut -d'.' -f1`
do
echo "Begin processing for 5143 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5143 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5143/' | cut -d'.' -f1`
do
echo "Begin processing for 5143 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5143 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5149/' | cut -d'.' -f1`
do
echo "Begin processing for 5149 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5149 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5149/' | cut -d'.' -f1`
do
echo "Begin processing for 5149 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5149 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5194/' | cut -d'.' -f1`
do
echo "Begin processing for 5194 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5194 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5194/' | cut -d'.' -f1`
do
echo "Begin processing for 5194 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5194 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5505/' | cut -d'.' -f1`
do
echo "Begin processing for 5505 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5505 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5505/' | cut -d'.' -f1`
do
echo "Begin processing for 5505 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5505 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5511/' | cut -d'.' -f1`
do
echo "Begin processing for 5511 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5511 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5511/' | cut -d'.' -f1`
do
echo "Begin processing for 5511 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5511 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5516/' | cut -d'.' -f1`
do
echo "Begin processing for 5516 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5516 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5516/' | cut -d'.' -f1`
do
echo "Begin processing for 5516 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5516 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5517/' | cut -d'.' -f1`
do
echo "Begin processing for 5517 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5517 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5517/' | cut -d'.' -f1`
do
echo "Begin processing for 5517 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5517 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5519/' | cut -d'.' -f1`
do
echo "Begin processing for 5519 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5519 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5519/' | cut -d'.' -f1`
do
echo "Begin processing for 5519 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5519 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5520/' | cut -d'.' -f1`
do
echo "Begin processing for 5520 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5520 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5520/' | cut -d'.' -f1`
do
echo "Begin processing for 5520 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5520 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5524/' | cut -d'.' -f1`
do
echo "Begin processing for 5524 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5524 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5524/' | cut -d'.' -f1`
do
echo "Begin processing for 5524 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5524 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5526/' | cut -d'.' -f1`
do
echo "Begin processing for 5526 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5526 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5526/' | cut -d'.' -f1`
do
echo "Begin processing for 5526 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5526 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5538/' | cut -d'.' -f1`
do
echo "Begin processing for 5538 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5538 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5538/' | cut -d'.' -f1`
do
echo "Begin processing for 5538 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5538 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5539/' | cut -d'.' -f1`
do
echo "Begin processing for 5539 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5539 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5539/' | cut -d'.' -f1`
do
echo "Begin processing for 5539 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5539 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5552/' | cut -d'.' -f1`
do
echo "Begin processing for 5552 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5552 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5552/' | cut -d'.' -f1`
do
echo "Begin processing for 5552 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5552 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5702/' | cut -d'.' -f1`
do
echo "Begin processing for 5702 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5702 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5702/' | cut -d'.' -f1`
do
echo "Begin processing for 5702 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5702 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5703/' | cut -d'.' -f1`
do
echo "Begin processing for 5703 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5703 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5703/' | cut -d'.' -f1`
do
echo "Begin processing for 5703 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5703 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5705/' | cut -d'.' -f1`
do
echo "Begin processing for 5705 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5705 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5705/' | cut -d'.' -f1`
do
echo "Begin processing for 5705 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5705 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5707/' | cut -d'.' -f1`
do
echo "Begin processing for 5707 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5707 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5707/' | cut -d'.' -f1`
do
echo "Begin processing for 5707 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5707 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5708/' | cut -d'.' -f1`
do
echo "Begin processing for 5708 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5708 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5708/' | cut -d'.' -f1`
do
echo "Begin processing for 5708 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5708 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5715/' | cut -d'.' -f1`
do
echo "Begin processing for 5715 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5715 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5715/' | cut -d'.' -f1`
do
echo "Begin processing for 5715 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5715 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5717/' | cut -d'.' -f1`
do
echo "Begin processing for 5717 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5717 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5717/' | cut -d'.' -f1`
do
echo "Begin processing for 5717 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5717 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5718/' | cut -d'.' -f1`
do
echo "Begin processing for 5718 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5718 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5718/' | cut -d'.' -f1`
do
echo "Begin processing for 5718 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5718 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5734/' | cut -d'.' -f1`
do
echo "Begin processing for 5734 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5734 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5734/' | cut -d'.' -f1`
do
echo "Begin processing for 5734 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5734 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5739/' | cut -d'.' -f1`
do
echo "Begin processing for 5739 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5739 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5739/' | cut -d'.' -f1`
do
echo "Begin processing for 5739 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5739 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5801/' | cut -d'.' -f1`
do
echo "Begin processing for 5801 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5801 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5801/' | cut -d'.' -f1`
do
echo "Begin processing for 5801 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5801 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5802/' | cut -d'.' -f1`
do
echo "Begin processing for 5802 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5802 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5802/' | cut -d'.' -f1`
do
echo "Begin processing for 5802 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5802 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5806/' | cut -d'.' -f1`
do
echo "Begin processing for 5806 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5806 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5806/' | cut -d'.' -f1`
do
echo "Begin processing for 5806 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5806 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5807/' | cut -d'.' -f1`
do
echo "Begin processing for 5807 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5807 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5807/' | cut -d'.' -f1`
do
echo "Begin processing for 5807 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5807 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5809/' | cut -d'.' -f1`
do
echo "Begin processing for 5809 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5809 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5809/' | cut -d'.' -f1`
do
echo "Begin processing for 5809 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5809 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5811/' | cut -d'.' -f1`
do
echo "Begin processing for 5811 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5811 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5811/' | cut -d'.' -f1`
do
echo "Begin processing for 5811 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5811 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5812/' | cut -d'.' -f1`
do
echo "Begin processing for 5812 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5812 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5812/' | cut -d'.' -f1`
do
echo "Begin processing for 5812 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5812 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5813/' | cut -d'.' -f1`
do
echo "Begin processing for 5813 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5813 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5813/' | cut -d'.' -f1`
do
echo "Begin processing for 5813 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5813 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5814/' | cut -d'.' -f1`
do
echo "Begin processing for 5814 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5814 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5814/' | cut -d'.' -f1`
do
echo "Begin processing for 5814 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5814 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5816/' | cut -d'.' -f1`
do
echo "Begin processing for 5816 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5816 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5816/' | cut -d'.' -f1`
do
echo "Begin processing for 5816 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5816 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5819/' | cut -d'.' -f1`
do
echo "Begin processing for 5819 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5819 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5819/' | cut -d'.' -f1`
do
echo "Begin processing for 5819 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5819 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5820/' | cut -d'.' -f1`
do
echo "Begin processing for 5820 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5820 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5820/' | cut -d'.' -f1`
do
echo "Begin processing for 5820 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5820 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5823/' | cut -d'.' -f1`
do
echo "Begin processing for 5823 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5823 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5823/' | cut -d'.' -f1`
do
echo "Begin processing for 5823 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5823 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5825/' | cut -d'.' -f1`
do
echo "Begin processing for 5825 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5825 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5825/' | cut -d'.' -f1`
do
echo "Begin processing for 5825 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5825 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5828/' | cut -d'.' -f1`
do
echo "Begin processing for 5828 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5828 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5828/' | cut -d'.' -f1`
do
echo "Begin processing for 5828 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5828 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5832/' | cut -d'.' -f1`
do
echo "Begin processing for 5832 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5832 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5832/' | cut -d'.' -f1`
do
echo "Begin processing for 5832 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5832 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5842/' | cut -d'.' -f1`
do
echo "Begin processing for 5842 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5842 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5842/' | cut -d'.' -f1`
do
echo "Begin processing for 5842 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5842 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_7700/' | cut -d'.' -f1`
do
echo "Begin processing for 7700 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 7700 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_7700/' | cut -d'.' -f1`
do
echo "Begin processing for 7700 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 7700 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_7703/' | cut -d'.' -f1`
do
echo "Begin processing for 7703 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 7703 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_7703/' | cut -d'.' -f1`
do
echo "Begin processing for 7703 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 7703 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_7704/' | cut -d'.' -f1`
do
echo "Begin processing for 7704 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 7704 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_7704/' | cut -d'.' -f1`
do
echo "Begin processing for 7704 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 7704 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5219/' | cut -d'.' -f1`
do
echo "Begin processing for 5219 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5219 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5219/' | cut -d'.' -f1`
do
echo "Begin processing for 5219 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5219 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5221/' | cut -d'.' -f1`
do
echo "Begin processing for 5221 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5221 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5221/' | cut -d'.' -f1`
do
echo "Begin processing for 5221 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5221 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5222/' | cut -d'.' -f1`
do
echo "Begin processing for 5222 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5222 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5222/' | cut -d'.' -f1`
do
echo "Begin processing for 5222 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5222 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5572/' | cut -d'.' -f1`
do
echo "Begin processing for 5572 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5572 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5572/' | cut -d'.' -f1`
do
echo "Begin processing for 5572 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5572 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5573/' | cut -d'.' -f1`
do
echo "Begin processing for 5573 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5573 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5573/' | cut -d'.' -f1`
do
echo "Begin processing for 5573 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5573 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5575/' | cut -d'.' -f1`
do
echo "Begin processing for 5575 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5575 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5575/' | cut -d'.' -f1`
do
echo "Begin processing for 5575 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5575 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5576/' | cut -d'.' -f1`
do
echo "Begin processing for 5576 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5576 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5576/' | cut -d'.' -f1`
do
echo "Begin processing for 5576 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5576 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5577/' | cut -d'.' -f1`
do
echo "Begin processing for 5577 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5577 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5577/' | cut -d'.' -f1`
do
echo "Begin processing for 5577 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5577 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5880/' | cut -d'.' -f1`
do
echo "Begin processing for 5880 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5880 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5880/' | cut -d'.' -f1`
do
echo "Begin processing for 5880 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5880 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5881/' | cut -d'.' -f1`
do
echo "Begin processing for 5881 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5881 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5881/' | cut -d'.' -f1`
do
echo "Begin processing for 5881 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5881 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5882/' | cut -d'.' -f1`
do
echo "Begin processing for 5882 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5882 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5882/' | cut -d'.' -f1`
do
echo "Begin processing for 5882 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5882 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5220/' | cut -d'.' -f1`
do
echo "Begin processing for 5220 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5220 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5220/' | cut -d'.' -f1`
do
echo "Begin processing for 5220 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5220 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5223/' | cut -d'.' -f1`
do
echo "Begin processing for 5223 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5223 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5223/' | cut -d'.' -f1`
do
echo "Begin processing for 5223 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5223 TXT "
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5878/' | cut -d'.' -f1`
do
echo "Begin processing for 5878 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5878 PDF "
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5878/' | cut -d'.' -f1`
do
echo "Begin processing for 5878 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "DONE FOR 5878 TXT "
done

echo "Calling exe..."


#PROD
grep -i pdf ${BASE_PATH}/shellInputfile.txt >${BASE_PATH}/ShellPdfFiles.txt
#${BASE_PATH}/PDF_DFMEA4D_Attachment -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=${BASE_PATH}/shellInputfile.txt
${BASE_PATH}/PDF_DFMEA4D_AttachmentCVPROD -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=${BASE_PATH}/ShellPdfFiles.txt
echo "PDF_DFMEA4D_Attachment cc done"

grep -i clauses ${BASE_PATH}/shellInputfile.txt >${BASE_PATH}/ShellClausesFiles.txt
${BASE_PATH}/TXT_DFMEA4D_ClausesCVPROD -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=${BASE_PATH}/ShellClausesFiles.txt
echo "TXT_DFMEA4D_Clauses cc done"

grep -i .txt shellInputfile.txt >ShellTxtFiles.txt
grep -v clauses ${BASE_PATH}/ShellTxtFiles.txt >${BASE_PATH}/ShellWithoutClausesTxtFiles.txt
${BASE_PATH}/TXT_DFMEA4D_AttachmentCVPROD -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=${BASE_PATH}/ShellWithoutClausesTxtFiles.txt
echo "TXT_DFMEA4D_Attachment cc done"


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2999/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2999/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5724/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5724/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5218/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5218/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5710/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5710/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5550/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5550/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2073/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2073/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2075/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2075/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2084/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2084/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2099/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2099/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2152/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2152/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2163/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2163/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2165/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2165/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2171/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2171/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5195/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5195/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2202/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2202/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2240/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2240/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2574/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2574/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2747/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2747/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5080/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5080/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2591/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2591/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2592/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2592/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2600/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2600/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2610/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2610/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2641/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2641/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2642/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2642/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2647/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2647/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2651/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2651/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2652/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2652/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2654/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2654/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5709/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5709/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2534/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2534/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2527/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2527/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5706/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5706/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5701/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5701/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5020/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5020/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2789/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2789/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5735/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5735/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2724/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2724/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5737/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5737/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2525/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2525/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2726/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2726/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2851/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2851/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5736/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5736/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5810/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5810/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5803/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5803/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2661/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2661/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5830/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5830/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2715/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2715/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5841/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5841/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2850/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2850/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5713/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5713/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2855/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2855/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2732/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2732/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5878/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5878/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5223/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5223/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5220/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5220/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5882/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5882/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5881/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5881/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5880/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5880/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5577/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5577/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5576/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5576/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5575/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5575/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5573/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5573/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5572/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5572/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5222/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5222/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5221/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5221/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5219/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5219/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2691/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2691/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5817/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5817/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5805/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5805/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5857/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5857/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2663/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2663/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5829/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5829/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2665/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2665/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2736/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2736/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5836/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5836/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2668/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2668/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2684/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2684/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2730/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2730/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2739/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2739/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5845/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5845/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2687/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2687/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2854/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2854/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5843/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5843/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2727/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2727/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2069/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2069/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2076/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2076/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2786/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2786/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2863/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2863/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5716/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5716/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5719/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5719/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5821/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5821/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5723/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5723/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5826/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5826/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5827/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5827/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5846/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5846/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2865/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2865/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2520/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2520/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2521/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2521/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2523/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2523/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2524/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2524/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2533/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2533/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2667/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2667/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2673/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2673/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2674/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2674/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2679/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2679/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2680/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2680/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2705/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2705/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2742/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2742/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2745/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2745/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2751/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2751/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2753/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2753/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2754/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2754/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2770/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2770/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2776/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2776/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2815/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2815/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2816/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2816/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2818/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2818/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2821/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2821/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2829/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2829/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2832/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2832/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2841/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2841/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2845/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2845/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2885/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2885/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2894/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2894/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2896/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2896/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2897/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2897/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2898/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2898/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2900/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2900/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2910/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2910/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_3505/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_3505/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_4103/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_4103/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5017/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5017/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5020/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5020/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5021/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5021/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5023/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5023/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5024/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5024/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5027/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5027/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5032/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5032/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5034/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5034/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5039/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5039/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5040/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5040/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5062/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5062/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5084/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5084/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5089/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5089/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5117/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5117/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5118/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5118/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5119/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5119/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5120/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5120/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5126/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5126/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5127/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5127/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5137/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5137/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5147/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5147/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5148/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5148/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5150/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5150/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5152/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5152/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5153/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5153/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5154/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5154/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5155/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5155/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5156/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5156/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5157/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5157/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5158/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5158/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5159/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5159/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5160/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5160/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5161/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5161/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5162/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5162/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5163/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5163/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5164/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5164/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5165/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5165/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5166/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5166/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5167/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5167/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5168/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5168/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5169/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5169/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5170/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5170/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5171/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5171/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5172/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5172/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5174/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5174/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5175/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5175/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5176/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5176/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5177/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5177/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5178/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5178/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5179/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5179/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5180/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5180/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5181/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5181/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5182/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5182/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5183/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5183/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5184/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5184/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5185/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5185/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5187/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5187/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5192/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5192/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5193/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5193/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5201/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5201/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5202/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5202/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5203/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5203/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5204/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5204/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5206/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5206/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5207/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5207/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5208/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5208/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5209/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5209/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5210/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5210/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5211/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5211/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5501/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5501/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5502/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5502/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5503/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5503/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5506/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5506/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5507/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5507/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5508/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5508/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5512/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5512/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5513/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5513/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5515/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5515/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5523/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5523/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5527/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5527/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5528/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5528/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5529/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5529/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5530/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5530/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5532/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5532/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5533/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5533/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5537/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5537/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5541/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5541/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5545/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5545/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5546/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5546/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5547/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5547/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5549/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5549/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5553/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5553/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5554/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5554/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5555/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5555/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5556/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5556/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5557/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5557/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5558/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5558/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5559/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5559/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5560/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5560/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5562/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5562/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5564/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5564/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5567/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5567/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5568/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5568/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5569/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5569/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5855/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5855/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5858/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5858/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2614/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2614/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2612/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2612/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2608/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2608/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2604/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2604/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2601/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2601/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2599/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2599/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2596/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2596/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2594/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2594/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2588/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2588/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2587/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2587/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2576/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2576/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2575/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2575/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2573/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2573/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2572/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2572/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2571/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2571/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2549/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2549/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2548/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2548/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2547/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2547/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2543/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2543/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2541/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2541/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2540/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2540/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2536/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2536/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2530/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2530/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2529/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2529/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2522/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2522/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2519/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2519/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2518/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2518/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2516/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2516/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2515/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2515/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2510/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2510/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2508/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2508/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2507/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2507/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2506/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2506/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2242/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2242/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2241/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2241/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2239/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2239/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2235/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2235/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2234/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2234/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2233/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2233/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2231/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2231/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2229/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2229/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2228/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2228/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2226/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2226/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2225/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2225/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2222/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2222/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2221/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2221/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2220/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2220/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2219/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2219/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2217/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2217/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2215/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2215/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2214/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2214/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2213/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2213/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2212/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2212/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2207/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2207/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2206/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2206/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2198/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2198/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2197/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2197/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2195/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2195/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2194/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2194/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2193/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2193/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2192/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2192/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2191/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2191/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2190/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2190/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2189/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2189/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2187/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2187/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2186/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2186/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2185/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2185/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2182/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2182/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2179/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2179/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2178/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2178/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2177/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2177/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2162/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2162/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2161/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2161/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2160/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2160/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2159/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2159/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2158/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2158/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2157/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2157/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2154/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2154/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2153/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2153/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2150/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2150/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2109/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2109/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2103/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2103/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2101/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2101/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2097/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2097/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2096/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2096/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2093/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2093/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2091/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2091/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2089/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2089/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2088/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2088/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2087/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2087/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2085/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2085/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2082/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2082/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2081/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2081/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2080/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2080/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2078/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2078/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2077/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2077/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2074/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2074/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2071/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2071/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2070/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2070/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2068/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2068/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2067/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2067/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2066/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2066/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2064/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2064/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2063/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2063/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2060/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2060/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2050/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2050/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2001/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2001/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_1111/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_1111/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2928/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2928/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5220/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5220/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5571/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5571/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5572/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5572/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5214/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5214/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5799/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5799/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5416/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5416/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5217/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5217/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5876/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5876/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2747/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2747/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5199/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5199/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2756/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2756/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_4105/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_4105/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5535/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5535/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2846/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2846/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5216/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5216/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2921/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2921/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2834/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2834/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5085/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5085/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2227/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2227/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2809/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2809/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2167/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2167/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5043/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5043/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5565/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5565/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5088/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5088/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5080/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5080/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5070/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5070/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5570/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5570/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5743/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5743/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5742/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5742/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5218/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5218/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5215/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5215/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5063/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5063/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5875/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5875/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5151/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5151/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5004/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5004/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2505/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2505/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5006/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5006/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5873/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5873/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5740/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5740/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5007/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5007/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2880/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2880/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5872/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5872/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5087/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5087/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_4106/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_4106/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5069/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5069/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5081/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5081/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5714/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5714/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2750/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2750/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5724/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5724/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5741/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5741/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5197/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5197/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_3505/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_3505/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2910/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2910/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2900/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2900/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2898/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2898/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2897/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2897/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2896/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2896/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2894/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2894/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2885/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2885/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2845/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2845/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2841/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2841/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2832/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2832/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2829/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2829/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2821/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2821/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2818/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2818/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2816/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2816/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2815/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2815/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2776/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2776/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2770/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2770/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2754/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2754/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2753/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2753/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2751/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2751/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2745/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2745/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2742/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2742/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2705/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2705/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2680/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2680/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2679/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2679/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2674/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2674/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2673/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2673/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2654/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2654/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2652/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2652/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2651/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2651/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2647/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2647/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2642/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2642/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2641/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2641/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2610/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2610/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2600/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2600/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2592/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2592/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2591/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2591/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2574/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2574/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2240/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2240/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2202/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2202/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2196/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2196/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2171/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2171/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2165/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2165/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2163/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2163/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2152/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2152/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2084/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2084/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2075/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2075/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2073/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2073/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2071/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2071/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2070/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2070/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2068/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2068/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2067/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2067/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2066/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2066/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2064/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2064/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2063/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2063/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2060/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2060/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2050/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2050/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2001/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2001/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_1111/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_1111/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2928/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2928/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5220/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5220/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5571/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5571/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5572/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5572/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5214/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5214/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5799/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5799/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5416/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5416/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5217/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5217/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5876/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5876/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5199/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5199/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2756/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2756/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_4105/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_4105/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5535/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5535/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2846/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2846/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5216/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5216/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2921/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2921/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2834/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2834/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5085/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5085/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2227/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2227/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2809/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2809/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2167/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2167/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5043/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5043/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5565/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5565/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5088/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5088/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5070/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5070/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5570/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5570/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5743/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5743/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5742/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5742/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5218/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5218/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5063/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5063/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5875/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5875/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5151/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5151/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5004/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5004/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2505/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2505/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5006/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5006/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5873/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5873/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5740/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5740/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5007/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5007/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2880/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2880/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5872/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5872/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5087/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5087/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done


for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_4106/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_4106/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5069/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5069/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5081/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5081/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5714/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5714/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2750/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2750/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5008/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5008/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_7704/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_7704/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_7703/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_7703/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_7700/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_7700/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5842/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5842/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5832/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5832/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5828/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5828/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5825/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5825/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5823/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5823/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5820/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5820/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5819/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5819/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5816/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5816/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5814/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5814/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5813/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5813/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5812/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5812/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5811/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5811/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5809/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5809/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5807/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5807/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5806/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5806/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5802/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5802/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5801/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5801/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5739/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5739/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5734/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5734/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5718/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5718/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5717/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5717/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5715/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5715/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5708/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5708/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5707/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5707/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5705/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5705/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5703/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5703/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5702/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5702/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5552/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5552/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5539/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5539/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5538/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5538/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5526/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5526/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5524/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5524/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5520/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5520/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5519/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5519/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5517/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5517/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5516/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5516/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5511/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5511/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5505/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5505/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5194/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5194/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5149/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5149/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5143/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5143/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5141/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5141/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5136/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5136/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5135/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5135/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5132/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5132/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5131/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5131/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5129/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5129/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5128/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5128/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5125/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5125/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5124/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5124/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5123/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5123/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5122/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5122/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5121/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5121/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5109/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5109/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5107/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5107/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5106/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5106/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5105/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5105/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5103/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5103/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5102/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5102/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5101/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5101/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5096/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5096/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5091/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5091/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5090/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5090/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5086/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5086/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5079/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5079/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5077/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5077/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5076/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5076/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5075/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5075/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5074/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5074/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5073/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5073/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5072/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5072/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5071/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5071/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5068/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5068/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5066/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5066/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5064/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5064/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5060/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5060/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5059/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5059/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5058/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5058/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5057/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5057/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5056/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5056/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5055/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5055/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5053/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5053/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5050/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5050/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5049/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5049/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5048/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5048/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5046/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5046/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5045/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5045/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5044/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5044/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5042/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5042/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5041/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5041/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5037/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5037/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5036/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5036/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5033/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5033/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5031/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5031/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5030/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5030/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5028/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5028/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5026/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5026/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5022/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5022/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5019/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5019/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5018/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5018/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5016/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5016/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5014/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5014/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5013/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5013/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5012/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5012/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5011/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5011/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5010/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5010/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5009/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5009/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5005/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5005/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5003/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5003/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_4183/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_4183/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_4181/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_4181/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_4104/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_4104/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_4102/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_4102/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_4101/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_4101/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_3502/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_3502/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_3501/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_3501/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2999/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2999/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2917/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2917/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2916/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2916/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2913/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2913/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2912/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2912/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2895/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2895/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2892/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2892/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2889/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2889/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2888/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2888/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2887/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2887/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2886/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2886/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2884/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2884/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2883/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2883/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2882/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2882/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2881/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2881/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2879/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2879/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2876/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2876/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2874/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2874/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2873/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2873/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2872/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2872/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2871/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2871/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2870/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2870/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2869/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2869/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2868/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2868/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2867/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2867/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2866/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2866/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2864/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2864/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2862/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2862/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2859/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2859/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2858/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2858/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2857/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2857/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2856/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2856/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2853/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2853/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2852/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2852/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2849/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2849/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2843/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2843/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2842/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2842/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2840/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2840/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2839/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2839/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2838/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2838/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2833/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2833/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2830/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2830/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2828/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2828/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2827/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2827/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2826/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2826/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2825/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2825/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2823/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2823/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2822/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2822/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2820/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2820/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2819/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2819/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2808/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2808/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2807/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2807/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2806/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2806/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2805/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2805/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2803/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2803/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2802/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2802/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2801/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2801/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2799/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2799/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2798/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2798/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2797/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2797/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2792/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2792/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2791/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2791/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2790/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2790/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2788/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2788/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2787/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2787/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2785/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2785/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2784/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2784/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2783/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2783/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2782/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2782/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2781/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2781/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2780/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2780/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2779/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2779/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2778/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2778/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2777/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2777/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2775/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2775/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2774/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2774/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2771/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2771/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2768/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2768/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2767/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2767/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2763/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2763/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2760/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2760/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2757/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2757/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2755/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2755/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2752/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2752/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2741/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2741/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2737/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2737/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2733/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2733/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2731/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2731/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2729/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2729/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2722/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2722/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2721/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2721/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2719/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2719/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2711/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2711/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2708/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2708/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2707/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2707/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2706/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2706/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2704/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2704/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2702/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2702/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2701/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2701/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2700/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2700/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2699/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2699/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2698/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2698/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2696/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2696/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2695/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2695/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2692/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2692/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2690/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2690/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2689/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2689/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2688/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2688/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2682/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2682/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2678/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2678/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2669/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2669/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2664/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2664/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2662/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2662/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2660/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2660/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2659/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2659/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2658/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2658/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2657/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2657/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2653/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2653/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2645/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2645/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2644/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2644/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2643/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2643/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2640/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2640/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2636/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2636/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2632/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2632/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2631/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2631/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2630/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2630/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2628/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2628/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2625/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2625/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2621/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2621/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2618/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2618/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2617/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2617/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

echo "files moved"

