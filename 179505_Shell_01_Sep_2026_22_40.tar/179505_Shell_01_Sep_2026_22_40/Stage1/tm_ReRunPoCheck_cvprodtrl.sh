. /user/cvprod/.bash_profile
echo "Start==>Calling DML tm_ReRunPoCheck from cvprodtrl---------->"
echo "Shell--DMLNo.=> " $1
/user/cvprod/Program_Shells/DML_DCR/tm_POCheckReRun -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -taskno=$1
echo "End==>DML tm_ReRunPoCheck from cvprodtrl---------->"
You have new mail in /var/spool/mail/cvprod