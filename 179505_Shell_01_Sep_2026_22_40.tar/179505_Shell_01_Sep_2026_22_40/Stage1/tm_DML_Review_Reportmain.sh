. /user/cvprod/.bash_profile
echo "Shell--DML_No.= " $1
input1=\"$1\";
echo "Shell--input1.= " $input1
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Program_Shells/DML_DCR/dmlinfo_utility.sh $input1"
echo "--Complete dmlinfo_utility.sh from cvprod-- "