. /user/omfprod/.bash_profile
echo "User ID as Argument"
echo "In Shell User ID is : $1 "
echo "In Shell Part no is : $2 "
echo "Argument Print Complete"
echo "Shell calling started"
echo "Shell Execution Started"
echo "user id $1"
echo "part no $2"

#chmod 777 "$1 $2"

/user/omfprod/shells/TASL_Downloading/TMETC_LATEST/sendMailToCV $1 $2
echo "Shell execution Ended"
echo "Shell calling Ended"
