echo $1
cd /home/cmitest/muktesh/UserManagement
rm -f projAssignInput.txt
touch projAssignInput.txt
echo $1 >> projAssignInput.txt
echo $(date) >> ProjAssignInputLog.txt
echo $1 >> ProjAssignInputLog.txt
#./ProjAssign -u=loahg.ttler -pf=/home/cmitest/shells/Admin/loaderpasswdFile.pwf -g=dba -i=/home/cmitest/muktesh/UserManagement/projAssignInput.txt
./ProjAssign -u=infodba -pf=/home/cmitest/shells/Admin/infodbapawwdfile.pwf -g=dba -i=/home/cmitest/muktesh/UserManagement/projAssignInput.txt
#
