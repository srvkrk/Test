rm -f /tmp/Newmaster.txt /tmp/NewList.txt /tmp/aa.txt /tmp/Filecount.txt /tmp/aa.txt1 /tmp/${1}_InputFile_1.txt

while read line
 do
  cp $line ${line}_1
  echo ${line}_1 >> /tmp/${1}_InputFile_1.txt
 done < /tmp/${1}_InputFile.txt


tail -n +2 /tmp/${1}_InputFile_1.txt > /tmp/NewList.txt

while read line

 do

  sr=`basename $line`
  echo $sr >> /tmp/aa.txt
echo "inside loop1"
 done < /tmp/NewList.txt

tr -d "\015"</tmp/aa.txt>/tmp/aa.txt1
mv /tmp/aa.txt1 /tmp/aa.txt

while read line

 do
 cd /tmp
  v=`awk '$0=$2' FS=id RS='"' $line | cut -d' ' -f1 | sort -n | tail -1`
  echo $v >> /tmp/Filecount.txt
  echo "inside loop2"

done < /tmp/aa.txt

s=`sort -n /tmp/Filecount.txt | tail -1`

head -$s /tmp/master.txt > /tmp/Newmaster.txt

while read line

   do
cd /tmp
 value=`echo $line| cut -d~ -f1`
 value1=`echo $line| cut -d~ -f2`
        echo "inside loop3"

   counter=0

    while read filename

      do
       cd /tmp
       counter=$((counter+1))
       sed -i "s/$value\"/$value1$counter\"/g; s/$value /$value1$counter /g" $filename

    done < /tmp/aa.txt

done < /tmp/Newmaster.txt

  country=0
  while read filename

      do
       cd /tmp

       #sed -i 's/T5_GENTPL_TM/T5_GENTPL_TM$country/g; s/primaryOccurrenceRef/primaryOccurrenceRef$country/g' $filename
      sed -i "s/T5_GENTPL_TM\"/T5_GENTPL_TM$country\"/g; s/primaryOccurrenceRef/primaryOccurrenceRef$country/g" $filename
       country=$((country+1))

    done < /tmp/aa.txt

while read line
 do
  b=`echo $line | cut -d'_' -f1`
   cp $line $b
 done < /tmp/${1}_InputFile_1.txt
 
