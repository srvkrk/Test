#!/bin/sh
. /user/uaprod/.bash_profile

echo $1
echo $2
#cd /user/uaprod/TC_ROOT_10/bin/
#./delete_replica -u=infodba -pf=/user/uaprod/shells/Admin/infodbapassfile.pwf -g=dba -f=delete -delete_exportrecords -verbose -item_id=$1 -rev=$2
/user/uaprod/shells/ReplicaDel/deleteReplicaObj -u=infodba -pf=/user/uaprod/shells/Admin/infodbapassfile.pwf -g=dba -item_id=$1 -rev=$2
echo "$1/$2" >> deleterev.txt
cd /user/uaprod/TC_ROOT_10/bin/
./data_sync -u=infodba -pf=/user/uaprod/shells/Admin/infodbapassfile.pwf -g=dba -site=TMETC-Production -f=verify -update -fn=deleterev.txt -cof=ItemRevision
./data_sync -u=infodba -pf=/user/uaprod/shells/Admin/infodbapassfile.pwf -g=dba -site=TRILIX-Production -f=verify -update -fn=deleterev.txt -cof=ItemRevision
rm -f /user/uaprod/shells/ReplicaDel/deleterev.txt
