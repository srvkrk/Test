. /user/cvprod/.bash_profile
echo "Start==>Vehicle varient report for cvprod---------->"
cd /user/cvprod/Program_Shells/DML_Support/tm_veh_DML_varient
echo "available at path.... "
frmdate=`date +"%d-%m-%Y" --date="08 Days ago"`
echo "$frmdate"
tomdate=`date +"%d-%m-%Y" --date="07 Days ago"`
echo "$tomdate"
echo "For 8 Days >> tm_veh_DML_varient"
echo "Calling exe tm_veh_DML_varient... "
/user/cvprod/Program_Shells/DML_Support/tm_veh_DML_varient/tm_veh_DML_varient -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -I1=$frmdate -I2=$tomdate
echo "\n Vehicle File Copy To Path Start..!!"
cd /tmp/
scp Vehicle_Varient_Report.csv sapmaster@172.22.99.133:PLM_DATA/PROD/1402/DR_GATE_WISE_ESTIMATED_ACTUAL_TIMELINE_DATA
echo "Success Report Send To Email End..!!"
echo "\n~~~~~~~~~~ C R O N  S H E L L   E N D E D ~~~~~~~~~~~~"
echo "End==>Vehicle varient report for cvprod---------->"
