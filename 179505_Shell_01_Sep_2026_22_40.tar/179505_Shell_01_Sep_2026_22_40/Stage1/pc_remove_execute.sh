######################################################################################
# Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights Reserved.
#
# This software is the confidential and proprietary information of TTL.
# You shall not disclose such confidential information and shall use it.
# only in accordance with the terms of the license agreement.
#
# Author          : SOURAV KARAK
# Created on      : Feb-2026
#
#######################################################################################

#!/bin/bash
. /user/cvprod/.bash_profile

echo -e "\n~~~~~~~~~~ EXECUTE SHELL STARTED ~~~~~~~~~~~~"

echo -e "\nIn Shell Argument Print Started...."

echo "Input Part: -----> "$1

echo "Input Plant Code: -----> "$2

echo "Input Change No: -----> "$3

echo -e "\nIn Shell Argument Print Ended...."
echo -e "\nEXE Execution Started...."
/user/cvprod/Profit_Center_Mapping/tm_PC_Remove -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -part=$1 -plant=$2 -chno=$3
echo -e "\nEXE Execution Ended...."

echo -e "\n~~~~~~~~~~ EXECUTE SHELL ENDED ~~~~~~~~~~~~"
