. /user/cvprod/.bash_profile
echo "Start==>Calling VC creation from cvprod---------->"
echo "Shell--DMLNo.=> " $1
/user/cvprod/Program_Shells/DML_DCR/VC_Creation/tm_VC_Creation -dmlno=$1 -taskno=$2 -partno=$3 -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba
echo "End==>VC creation from cvprod---------->"
