. /user/uaprodtrl/.bash_profile
rm -f *_DCR_Escalation.csv
rm -f *_SendmailCC.txt
nohup ./tm_dcr_ProjWiseEscaln_mailEPMHandlertry -u=loader -pf=/user/uaprodtrl/shells/Admin/loaderpasswdFile.pwf -g=dba > test.log &
echo "______________Report Fired Sucessfully________________"
