. /user/aplstdgrp/.bash_profile
echo "Connecting uaprod...."
echo $1
pwd
cd /user/aplstdgrp/Deepti/TCE_TCUA_Data_Migration/TCE_TCUA_INCREMENT_DATALOAD
pwd
tm_TCE_TCUA_PARTStampOneTime -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=/proj/PLMLoading/UAFiles/APL_STDSI_TCE_TCUA_Data_Mig/IncrementalDataUpload_APL/$1/5442_CARPLT_PartListInfo.txt -plname=PlantName1 > PartListInfo.log

wait
if [ $? != 0 ]
        then
                echo "Problem in Part stamping.."
                exit 1
        else
                echo "Part Stamping Executed Successfully ..So calling BOM Updation"
                tm_ERCAPLPartBOMAPLRest -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=/proj/PLMLoading/UAFiles/APL_STDSI_TCE_TCUA_Data_Mig/IncrementalDataUpload_APL/$1/5442_CARPLT_BOMLIST.txt -plname=PlantName1 > BOMListInfo.log
		wait
			if [ $? != 0 ]
        		then
                		echo "Problem in BOM Updation stamping.."
                		exit 1
        		else
	 			echo "BOM Updation Executed Successfully ..So calling Optional CS"
				tm_TCE_TCUA_OPT_CS_UPD -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=/proj/PLMLoading/UAFiles/APL_STDSI_TCE_TCUA_Data_Mig/IncrementalDataUpload_APL/$1/5442_CARPLT_OptionalCSList.txt -plname=PlantName1 > OPT_CS_UPD.log
				wait
		 			if [ $? != 0 ]
        				then
                				echo "Problem in Optional CS stamping.."
                				exit 1
        				else
						echo "Optional CS Updation Executed Successfully ..So calling DML Task Loading.."
                				tm_t5DMLTaskPartRel -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=/proj/PLMLoading/UAFiles/APL_STDSI_TCE_TCUA_Data_Mig/IncrementalDataUpload_APL/$1/5442_CARPLT_DMLInfo.txt -plname=PlantName1 > DMLInfo.log
					wait
					fi
			fi
fi

tm_t5APLPartDataSetAttachement  -u=aplloader -pf=/user/uaprod/shells/Admin/aplpasswdfile.pwf -g=dba -i=/proj/PLMLoading/UAFiles/APL_STDSI_TCE_TCUA_Data_Mig/IncrementalDataUpload_APL/$1/5442_CARPLT_PartCADInfo.txt -plname=PlantName1 > CADInfo.log

wait
	if [ $? != 0 ]
        then
                echo "Problem in APL Part Data Set Attachment.."
                exit 1
        else
                echo "DataSet Attachment Executed Successfully ...."
	fi
now="$(date +'%d_%m_%Y')"
echo "Start copying the log to folder"
mkdir $now
pwd
cp /user/aplstdgrp/Deepti/TCE_TCUA_Data_Migration/TCE_TCUA_INCREMENT_DATALOAD/*.log . $now
rm -f *.log
cd $now
pwd
cp /proj/PLMLoading/UAFiles/APL_STDSI_TCE_TCUA_Data_Mig/IncrementalDataUpload_APL/$1/* .
if grep "Teamcenter ERROR" *.log
then
    echo "Error found"
	echo -e  "${RED}Dear All,\n\n Aquilla Incremental Data Stamping from TCE to TCUA execution not exected successfully on $1. \n\n\n\nRegards,\nPLM SYSTEMS...${NC}" | nail -s "Aquilla Incremental Data Execution Status" Deepti.Meshram@tatatechnologies.com  

(
echo "To: awadhutn.ttl@tatamotors.com azmathp.ttl@tatamotors.com ac.ttl@tatamotors.com"
echo "Cc: deeptim.ttl@tatamotors.com sagarb2.ttl@tatamotors.com"
echo "Subject: STATUS OF AQUILLA INCREMENTAL DATA SYNC WITH PLM TCE-TCUA ON $1"
echo "Content-Type: text/html"
echo
echo "<html>
<head>
<title>Status of the jobs during the day</title>
<style>
table, th, td {
    border: 1px solid blue;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
</style>
</head>
<body>
<p><font   color="#ff0000">Dear All,</font></p>
<p><font   color="#ff0000">Aquilla Incremental Data Stamping from TCE to TCUA execution not exected successfully.Status of the Shells Execution during the day:</font></p>
<table style='width:100%'>
<tr bgcolor='#808080'>
    <th><center>Shell Name</center></th>
    <th><center>Server</center></th>
    <th><center>Status</center></th>
    <th><center>LOG PATH</center></th>
  </tr>
  <tr>
    <td><center>CronJobIncrementDataDownLd.sh</center></td>
    <td><center>plmpapp2c3</center></td>
    <td><center>CROSS VERIFY LOG ON SERVER FOLDER AS PER DATE</center></td>
    <td><center>plmpapp2c4:/user/aplstdgrp/Deepti/TCE_TCUA_Data_Migration/TCE_TCUA_INCREMENT_DATALOAD/</center></td>
  </tr>  
 </table>
 <p><font  color="#ff0000">--</font></p>
 <p><font  color="#ff0000">Regards,</font></p>
 <p><font  color="#ff0000">PLM SYSTEM.....</font></p>
</body></html>"
echo
) | /usr/sbin/sendmail -t
echo "111 finished....."   


 else
	echo "Error not found"
	echo -e  "${RED}Dear All,\n\n Aquilla Incremental Data Stamping from TCE to TCUA execution successfully completed on $1. \n\n\n\nRegards,\nPLM SYSTEMS...${NC}" | nail -s "Aquilla Incremental Data Execution Status" Deepti.Meshram@tatatechnologies.com  

(
echo "To: awadhutn.ttl@tatamotors.com azmathp.ttl@tatamotors.com ac.ttl@tatamotors.com"
echo "Cc: deeptim.ttl@tatamotors.com sagarb2.ttl@tatamotors.com"
echo "Subject: STATUS OF AQUILLA INCREMENTAL DATA SYNC WITH PLM TCE-TCUA ON $1"
echo "Content-Type: text/html"
echo
echo "<html>
<head>
<title>Status of the jobs during the day</title>
<style>
table, th, td {
    border: 1px solid blue;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
}
</style>
</head>
<body>
<p><font   color="#ff0000">Dear All,</font></p>
<p><font   color="#ff0000">Aquilla Incremental Data Stamping from TCE to TCUA execution successfully completed.Status of the Shells Execution during the day:</font></p>
<table style='width:100%'>
<tr bgcolor='#808080'>
    <th><center>Shell Name</center></th>
    <th><center>Server</center></th>
    <th><center>Status</center></th>
    <th><center>LOG PATH</center></th>
  </tr>
  <tr>
    <td><center>CronJobIncrementDataDownLd.sh</center></td>
    <td><center>plmpapp2c3</center></td>
    <td><center>CROSS VERIFY LOG ON SERVER FOLDER AS PER DATE</center></td>
    <td><center>plmpapp2c4:/user/aplstdgrp/Deepti/TCE_TCUA_Data_Migration/TCE_TCUA_INCREMENT_DATALOAD/</center></td>
  </tr>  
 </table>
 <p><font  color="#ff0000">--</font></p>
 <p><font  color="#ff0000">Regards,</font></p>
 <p><font  color="#ff0000">PLM SYSTEM.....</font></p>
</body></html>"
echo
) | /usr/sbin/sendmail -t
echo "finished....." 
fi





