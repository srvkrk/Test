#!/bin/sh
. /user/cvprod/.bash_profile
echo "Start of VC creation for cvprod --> $1 "
ssh cvprod@172.22.99.106 -n "/user/cvprod/Program_Shells/DML_DCR/VC_Creation/tm_VC_Creation_cvprodtrl.sh $1 $2 $3"
echo "---Expand tm_VC_Creation_cvprodtrl Shell completed on cvprod.---"
