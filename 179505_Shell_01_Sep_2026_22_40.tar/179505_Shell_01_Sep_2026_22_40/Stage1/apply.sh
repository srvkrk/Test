. /user/uaprod/.bash_profile
#!/bin/ksh
echo $JAVA_HOME > /tmp/wfoutsh.log
java -classpath /user/uaprod/TC_ROOT_10/bin/tml_tools/xalan.jar org.apache.xalan.xslt.Process -IN $1 -OUT $2 -XSL /user/uaprod/TC_ROOT_10/bin/tml_tools/DML_Report.xsl > /tmp/wfoutsh.log
