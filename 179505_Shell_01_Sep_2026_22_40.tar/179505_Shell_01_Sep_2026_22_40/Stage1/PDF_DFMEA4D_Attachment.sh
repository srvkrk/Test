#!/bin/sh
. /user/uaprodtrl/.bash_profile

#prod
pdfFileLocation=/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/PDFFiles
#movePdfToLocation=/user/uaprod/shells/4D
movePdfToLocation=/user/uaprodtrl/4D_updation_shell
movePdfToLocationnew=/plmpv16/bulkdata/PLMLoading/CreDfmea4DAndRel/MovedFiles_TCUA


#BASE_PATH=/user/uaprod/shells/4D
BASE_PATH=/user/uaprodtrl/4D_updation_shell
echo $BASE_PATH

cd $BASE_PATH
#for i in `ls -lt "$BASE_PATH"`
#echo "Begin PDF shell"
#do
rm -f shellInputfile.txt
rm -f ShellPdfFiles.txt
rm -f ShellWithoutClausesTxtFiles.txt
rm -f ShellClausesFiles.txt
rm -f ShellTxtFiles.txt

echo "Files removed"


echo $pdfFileLocation

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2956/' | cut -d'.' -f1`
do
echo "Begin processing for 2956 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2956 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2956/' | cut -d'.' -f1`
do
echo "Begin processing for 2956 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2956 TXT"
done
for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5123/' | cut -d'.' -f1`
do
echo "Begin processing for 5123 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5123 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5123/' | cut -d'.' -f1`
do
echo "Begin processing for 5123 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5123 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5427/' | cut -d'.' -f1`
do
echo "Begin processing for 5427 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5427 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5427/' | cut -d'.' -f1`
do
echo "Begin processing for 5427 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5427 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5446/' | cut -d'.' -f1`
do
echo "Begin processing for 5446 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5446 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5446/' | cut -d'.' -f1`
do
echo "Begin processing for 5446 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5446 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5460/' | cut -d'.' -f1`
do
echo "Begin processing for 5460 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5460 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5460/' | cut -d'.' -f1`
do
echo "Begin processing for 5460 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5460 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5461/' | cut -d'.' -f1`
do
echo "Begin processing for 5461 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5461 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5461/' | cut -d'.' -f1`
do
echo "Begin processing for 5461 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5461 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5470/' | cut -d'.' -f1`
do
echo "Begin processing for 5470 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5470 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5470/' | cut -d'.' -f1`
do
echo "Begin processing for 5470 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5470 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5491/' | cut -d'.' -f1`
do
echo "Begin processing for 5491 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5491 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5491/' | cut -d'.' -f1`
do
echo "Begin processing for 5491 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5491 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5492/' | cut -d'.' -f1`
do
echo "Begin processing for 5492 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5492 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5492/' | cut -d'.' -f1`
do
echo "Begin processing for 5492 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5492 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5412/' | cut -d'.' -f1`
do
echo "Begin processing for 5412 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5412 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5412/' | cut -d'.' -f1`
do
echo "Begin processing for 5412 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5412 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5457/' | cut -d'.' -f1`
do
echo "Begin processing for 5457 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5457 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5457/' | cut -d'.' -f1`
do
echo "Begin processing for 5457 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5457 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5458/' | cut -d'.' -f1`
do
echo "Begin processing for 5458 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5458 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5458/' | cut -d'.' -f1`
do
echo "Begin processing for 5458 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5458 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5438/' | cut -d'.' -f1`
do
echo "Begin processing for 5438 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5438 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5438/' | cut -d'.' -f1`
do
echo "Begin processing for 5438 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5438 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5442/' | cut -d'.' -f1`
do
echo "Begin processing for 5442 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5442 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5442/' | cut -d'.' -f1`
do
echo "Begin processing for 5442 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5442 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5445/' | cut -d'.' -f1`
do
echo "Begin processing for 5445 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5445 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5445/' | cut -d'.' -f1`
do
echo "Begin processing for 5445 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5445 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5464/' | cut -d'.' -f1`
do
echo "Begin processing for 5464 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5464 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5464/' | cut -d'.' -f1`
do
echo "Begin processing for 5464 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5464 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5465/' | cut -d'.' -f1`
do
echo "Begin processing for 5465 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5465 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5465/' | cut -d'.' -f1`
do
echo "Begin processing for 5465 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5465 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5466/' | cut -d'.' -f1`
do
echo "Begin processing for 5466 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5466 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5466/' | cut -d'.' -f1`
do
echo "Begin processing for 5466 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5466 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5468/' | cut -d'.' -f1`
do
echo "Begin processing for 5468 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5468 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5468/' | cut -d'.' -f1`
do
echo "Begin processing for 5468 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5468 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5471/' | cut -d'.' -f1`
do
echo "Begin processing for 5471 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5471 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5471/' | cut -d'.' -f1`
do
echo "Begin processing for 5471 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5471 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5472/' | cut -d'.' -f1`
do
echo "Begin processing for 5472 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5472 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5472/' | cut -d'.' -f1`
do
echo "Begin processing for 5472 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5472 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5473/' | cut -d'.' -f1`
do
echo "Begin processing for 5473 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5473 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5473/' | cut -d'.' -f1`
do
echo "Begin processing for 5473 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5473 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5474/' | cut -d'.' -f1`
do
echo "Begin processing for 5474 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5474 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5474/' | cut -d'.' -f1`
do
echo "Begin processing for 5474 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5474 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5476/' | cut -d'.' -f1`
do
echo "Begin processing for 5476 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5476 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5476/' | cut -d'.' -f1`
do
echo "Begin processing for 5476 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5476 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5447/' | cut -d'.' -f1`
do
echo "Begin processing for 5447 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5447 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5447/' | cut -d'.' -f1`
do
echo "Begin processing for 5447 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5447 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5476/' | cut -d'.' -f1`
do
echo "Begin processing for 5476 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5476 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5476/' | cut -d'.' -f1`
do
echo "Begin processing for 5476 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5476 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5477/' | cut -d'.' -f1`
do
echo "Begin processing for 5477 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5477 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5477/' | cut -d'.' -f1`
do
echo "Begin processing for 5477 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5477 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5478/' | cut -d'.' -f1`
do
echo "Begin processing for 5478 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5478 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5478/' | cut -d'.' -f1`
do
echo "Begin processing for 5478 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5478 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5479/' | cut -d'.' -f1`
do
echo "Begin processing for 5479 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5479 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5479/' | cut -d'.' -f1`
do
echo "Begin processing for 5479 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5479 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5480/' | cut -d'.' -f1`
do
echo "Begin processing for 5480 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5480 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5480/' | cut -d'.' -f1`
do
echo "Begin processing for 5480 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5480 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5481/' | cut -d'.' -f1`
do
echo "Begin processing for 5481 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5481 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5481/' | cut -d'.' -f1`
do
echo "Begin processing for 5481 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5481 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5482/' | cut -d'.' -f1`
do
echo "Begin processing for 5482 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5482 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5482/' | cut -d'.' -f1`
do
echo "Begin processing for 5482 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5482 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5483/' | cut -d'.' -f1`
do
echo "Begin processing for 5483 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5483 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5483/' | cut -d'.' -f1`
do
echo "Begin processing for 5483 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5483 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5485/' | cut -d'.' -f1`
do
echo "Begin processing for 5485 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5485 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5485/' | cut -d'.' -f1`
do
echo "Begin processing for 5485 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5485 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5488/' | cut -d'.' -f1`
do
echo "Begin processing for 5488 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5488 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5488/' | cut -d'.' -f1`
do
echo "Begin processing for 5488 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5488 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5489/' | cut -d'.' -f1`
do
echo "Begin processing for 5489 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5489 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5489/' | cut -d'.' -f1`
do
echo "Begin processing for 5489 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5489 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5490/' | cut -d'.' -f1`
do
echo "Begin processing for 5490 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5490 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5490/' | cut -d'.' -f1`
do
echo "Begin processing for 5490 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5490 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5486/' | cut -d'.' -f1`
do
echo "Begin processing for 5486 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5486 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5486/' | cut -d'.' -f1`
do
echo "Begin processing for 5486 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5486 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5482/' | cut -d'.' -f1`
do
echo "Begin processing for 5482 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5482 PDF"
done
#done < Proj_List.csv

for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5482/' | cut -d'.' -f1`
do
echo "Begin processing for 5482 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5482 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5488/' | cut -d'.' -f1`
do
echo "Begin processing for 5488 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5488 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5488/' | cut -d'.' -f1`
do
echo "Begin processing for 5488 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5488 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_2956/' | cut -d'.' -f1`
do
echo "Begin processing for 2956 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 2956 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_2956/' | cut -d'.' -f1`
do
echo "Begin processing for 2956 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 2956 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5485/' | cut -d'.' -f1`
do
echo "Begin processing for 5485 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5485 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5485/' | cut -d'.' -f1`
do
echo "Begin processing for 5485 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5485 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5481/' | cut -d'.' -f1`
do
echo "Begin processing for 5481 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5481 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5481/' | cut -d'.' -f1`
do
echo "Begin processing for 5481 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5481 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5483/' | cut -d'.' -f1`
do
echo "Begin processing for 5483 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5483 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5483/' | cut -d'.' -f1`
do
echo "Begin processing for 5483 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5483 TXT"
done


for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5458/' | cut -d'.' -f1`
do
echo "Begin processing for 5458 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5458 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5458/' | cut -d'.' -f1`
do
echo "Begin processing for 5458 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5458 TXT"
done

for i in `ls -1t "$pdfFileLocation"| grep pdf | awk '/_5489/' | cut -d'.' -f1`
do
echo "Begin processing for 5489 PDF "
echo "$i Processing File"
echo "$i.pdf" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.pdf" ]; then
mv "$pdfFileLocation/$i.pdf" "${movePdfToLocation}/"
fi
echo "DONE FOR 5489 PDF"
done
#done < Proj_List.csv


for i in `ls -1t "$pdfFileLocation"| grep txt | awk '/_5489/' | cut -d'.' -f1`
do
echo "Begin processing for 5489 TXT "
echo "$i Processing File"
echo "$i.txt" >> shellInputfile.txt
if [ -f "$pdfFileLocation/$i.txt" ]; then
mv "$pdfFileLocation/$i.txt" "${movePdfToLocation}/"
fi
echo "--DONE FOR 5489 TXT"
done


#for i in `ls -1t "$pdfFileLocation"| grep xlsx | awk '/_5442/' | cut -d'.' -f1`
#do
#echo "Begin processing for 5442 XLSXXXXXXX "
#echo "$i Processing File"
#echo "$i.xlsx" >> shellInputfile.txt
#if [ -f "$pdfFileLocation/$i.xlsx" ]; then
#mv "$pdfFileLocation/$i.xlsx" "${movePdfToLocation}/"
#fi
#echo "--DONE FOR 5442 XLSXXXXXXX"
#done


#for i in `ls -1t "$pdfFileLocation"| grep xls | awk '/_5442/' | cut -d'.' -f1`
#do
#echo "Begin processing for 5442 XLS "
#echo "$i Processing File"
#echo "$i.xls" >> shellInputfile.txt
#if [ -f "$pdfFileLocation/$i.xls" ]; then
#mv "$pdfFileLocation/$i.xls" "${movePdfToLocation}/"
#fi
#echo "--DONE FOR 5442 XLS"
#done


echo "Calling exe..."



#PROD
grep -i pdf ${BASE_PATH}/shellInputfile.txt >${BASE_PATH}/ShellPdfFiles.txt
#${BASE_PATH}/PDF_DFMEA4D_Attachment -u=loader -pf=/user/uaprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=${BASE_PATH}/shellInputfile.txt
${BASE_PATH}/PDF_DFMEA4D_Attachment_TRL -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -g=dba -i=${BASE_PATH}/ShellPdfFiles.txt
echo "PDF_DFMEA4D_Attachment_TRL cc done"

grep -i clauses ${BASE_PATH}/shellInputfile.txt >${BASE_PATH}/ShellClausesFiles.txt
${BASE_PATH}/TXT_DFMEA4D_ClausesTRL -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -g=dba -i=${BASE_PATH}/ShellClausesFiles.txt
echo "TXT_DFMEA4D_ClausesTRL cc done"

grep -i .txt shellInputfile.txt >ShellTxtFiles.txt
grep -v clauses ${BASE_PATH}/ShellTxtFiles.txt >${BASE_PATH}/ShellWithoutClausesTxtFiles.txt
${BASE_PATH}/TXT_DFMEA4D_Attachment -u=loader -pf=/user/uaprodtrl/passwordfiles/loaderpasswdFile.pwf -g=dba -i=${BASE_PATH}/ShellWithoutClausesTxtFiles.txt
echo "TXT_DFMEA4D_AttachmentTRL cc done"



for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5442/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5442/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5412/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5412/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2956/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2956/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5445/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5445/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5464/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5464/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5465/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5465/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5466/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5466/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5468/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5468/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5471/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5471/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5472/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5472/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5473/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5473/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5474/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5474/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5447/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5447/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5476/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5476/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5477/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5477/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5478/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5478/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5479/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5479/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5480/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5480/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5481/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5481/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5482/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5482/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5483/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5483/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5485/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5485/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5492/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5492/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5491/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5491/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5470/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5470/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5461/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5461/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5460/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5460/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5446/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5446/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5427/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5427/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5123/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5123/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5457/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5457/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5458/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5458/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5488/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5488/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5489/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5489/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5490/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5490/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5486/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5486/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5482/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5482/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5488/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5488/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_2956/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_2956/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5485/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5485/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5481/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5481/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5483/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5483/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5458/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5458/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep pdf | awk '/_5489/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.pdf" ]; then
mv "$movePdfToLocation/$i.pdf" "${movePdfToLocationnew}/"
fi
done

for i in `ls -1t "$movePdfToLocation"| grep txt | awk '/_5489/' | cut -d'.' -f1`
do
if [ -f "$movePdfToLocation/$i.txt" ]; then
mv "$movePdfToLocation/$i.txt" "${movePdfToLocationnew}/"
fi
done
#for i in `ls -1t "$movePdfToLocation"| grep xlsx | awk '/_5442/' | cut -d'.' -f1`
#do
#if [ -f "$movePdfToLocation/$i.xlsx" ]; then
#mv "$movePdfToLocation/$i.xlsx" "${movePdfToLocationnew}/"
#fi
#done

#for i in `ls -1t "$movePdfToLocation"| grep xls | awk '/_5442/' | cut -d'.' -f1`
#do
#if [ -f "$movePdfToLocation/$i.xls" ]; then
#mv "$movePdfToLocation/$i.xls" "${movePdfToLocationnew}/"
#fi
#done


echo "files moved"

