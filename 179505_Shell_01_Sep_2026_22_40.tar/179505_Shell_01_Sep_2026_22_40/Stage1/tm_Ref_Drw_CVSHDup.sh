. /user/cvprod/.bash_profile
echo "Start RefDrw Code Update => " $1
/user/cvprod/Program_Shells/DML_DCR/Part_Check_Reference -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -dmlno=$1
echo "End of Refdrw Code Update"
