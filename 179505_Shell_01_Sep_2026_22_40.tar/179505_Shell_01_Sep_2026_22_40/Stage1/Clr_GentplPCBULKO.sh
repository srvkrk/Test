. /user/uaprod/.bash_profile
#!/bin/ksh
echo $JAVA_HOME > /tmp/wfoutsh11.log
java -classpath /user/uaprod/TC_ROOT_10/bin/tml_tools/xalan.jar org.apache.xalan.xslt.Process -IN $1 -OUT $2 -XSL /user/uaprod/TC_ROOT_10/bin/tml_tools/Clr_GenTPLPCBULKO.xsl > /tmp/Clr_genTPLSVR.log
