. /user/uaprodtrl/.bash_profile
echo "-----DCR_Escalation_Uaprodtrl.sh start-----"
if [ "$#" -ne 4 ]; then
    echo "Usage: $0 <attachment_file> <recipient_email> <recipient_email_cc> <DCR_Detailed_Attachment>"
    exit 1
fi

attachment_file="$1"
echo "Adding attachment: $attachment_file"
recipient="$2"
echo "Sending mail to $recipient"
recipient_email_cc="$3"
echo "Adding CC users: $recipient_email_cc"
DCR_Detailed_Attachment="$4"
echo "Adding CC users: $DCR_Detailed_Attachment"

subject="ALERT - DCRs pending - overall time exceeded 25 days."
chmod 777 "$attachment_file" "$recipient_email_cc"
if [ ! -f "$attachment_file" ]; then
    echo "Error: Attachment file '$attachment_file' not found."
    exit 1
fi

if [ ! -f "$recipient_email_cc" ]; then
    echo "Error: CC list file '$recipient_email_cc' not found."
    exit 1
fi

IFS=',' read -r -a data_array < "$attachment_file"

cc_list=$(<"$recipient_email_cc")
to_list=$(<"$recipient")
echo " Mail Recepent List: $to_list"
echo " Mail CC List: $cc_list"
 
mail_content=$(cat <<HTML

<html>
    <head></head>
    <body>
        <table width='1200px' border='1px' style='border-color: #206fab;border-style: none;'>
            <table width='100%' ;>
                
                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;' colspan='3'></td>
                </tr>
                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;' colspan='3'>Dear Participants,</td></tr>
		 <tr><td style='padding:3px;' colspan='3'>Please find status of Pending DCRs below. Request you to kindly take necessary action for prompt closure.</td>
                </tr>
                <tr style='background:#FFF;height:20px;'>
                    <td style='padding:5px;' colspan='3'></td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='15%''><strong style='color#206fab;'>Aggregate</strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='10%''><strong style='color#206fab;'> BIW  </strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='10%''><strong style='color#206fab;'>Chassis</strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='10%''><strong style='color#206fab;'>  E&E  </strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='10%''><strong style='color#206fab;'>Engines</strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='10%''><strong style='color#206fab;'>  TA  </strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='10%''><strong style='color#206fab;'> Trim </strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='10%''><strong style='color#206fab;'>Undefined</strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='10%''><strong style='color#206fab;'>Grand Total</strong></td>
                    <td style='padding:3px;font-size:12px;background-color: #206fab; text-align: center; width='15%''><strong style='color#206fab;'>Average pending age</strong></td>
                </tr>
		

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>No of Pending DCR</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[0]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[1]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[2]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[3]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[4]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[5]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[6]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[7]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[8]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;background-color:#206fab; font-size:12px; text-align: center; width='100%''><strong style='color#206fab;'>Stage-wise break-up of pending DCRs</strong></td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>ERC CoCs</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[9]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[10]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[11]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[12]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[13]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[14]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[15]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[16]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[17]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>AQ Review</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[18]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[19]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[20]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[21]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[22]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[23]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[24]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[25]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[26]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>CS Review</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[27]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[28]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[29]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[30]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[31]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[32]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222); text-align: center; width='10%''>
		    ${data_array[33]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[34]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[35]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>FMQ Review</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[36]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[37]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[38]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[39]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[40]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[41]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[42]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[43]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[44]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>TVM Review</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[45]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[46]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[47]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[48]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[49]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[50]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[51]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[52]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[53]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>TS Review</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[54]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[55]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[56]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[57]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[58]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[59]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[60]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[61]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[62]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>VEM Review</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[63]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[64]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[65]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[66]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[67]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[68]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[69]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[70]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[71]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>VPG Review</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[72]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[73]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[74]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[75]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[76]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[77]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[78]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[79]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[80]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
			<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>CAB Review</td>
			<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
			${data_array[81]}								        
			</td>										        
			<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
			${data_array[82]}								        
			</td>										        
			<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
			${data_array[83]}								        
			</td>										        
			<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
			${data_array[84]}								        
			</td>										        
			<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
			${data_array[85]}								        
			</td>										        
			<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
			${data_array[86]}								        
			</td>										        
			<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
			${data_array[87]}								        
			</td>										        
			<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
			${data_array[88]}								        
			</td>										        
			<td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
			${data_array[89]}
			</td>
		</tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>CheckList 1 & 2</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[90]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[91]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[92]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[93]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[94]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[95]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[96]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[97]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[98]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>Creator & COC/HOD</td>
                    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[99]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[100]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[101]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[102]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[103]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[104]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[105]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='10%''>
		    ${data_array[106]}									    
		    </td>										    
		    <td style='padding:3px;font-size:12px;background-color: rgb(221, 222, 222);text-align: center; width='15%''>
		    ${data_array[107]}
		    </td>
                </tr>

		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px; text-align: left; width='100%''>Regards,</td>
                </tr>
		
		<tr style='background:#FFF;height:20px;'>
                    <td style='padding:3px;font-size:12px; text-align: left; width='100%''>PLM Team</td>
                </tr>
            </table>
        </table>
    </body>
</html> 
HTML
)

(
echo "To: $3"
echo "Cc: $2"
echo "Subject: $subject"
echo "Content-Type: multipart/mixed; boundary=\"===============boundary==\""
echo "MIME-Version: 1.0"
echo ""
echo "--===============boundary=="
echo "Content-Type: text/html; charset=\"us-ascii\""
echo "MIME-Version: 1.0"
echo ""
echo "$mail_content"
echo "--===============boundary=="
echo "Content-Disposition: attachment; filename=\"$DCR_Detailed_Attachment\""
echo "Content-Type: application/octet-stream"
echo "MIME-Version: 1.0"
echo ""
cat "$DCR_Detailed_Attachment"
) | /usr/sbin/sendmail -t 

echo "-----DCR_Escalation_Uaprodtrl.sh end-----"
