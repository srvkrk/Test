frmdate=`date +"%d-%m-%Y" --date="01 Days ago"`
echo "$frmdate"
tomdate=`date +"%d-%m-%Y" --date="0 Days ago"`
echo "$tomdate"
echo "For 8 cronjob  >> tm_Spare_kit_report_DR2"
nohup ./tm_Spare_kit_report_DR2 -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -fromdate=$frmdate -todate=$tomdate > cronjob_sparekitrpt.log &
