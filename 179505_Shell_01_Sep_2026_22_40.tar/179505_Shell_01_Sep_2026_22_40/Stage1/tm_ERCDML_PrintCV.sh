. /user/cvprod/.bash_profile
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Program_Shells/DML_DCR/tm_ERCDML_PrinttCV.sh $1"
echo "--Complete tm_ERCDML_PrintPV.sh from cvprod-- "
