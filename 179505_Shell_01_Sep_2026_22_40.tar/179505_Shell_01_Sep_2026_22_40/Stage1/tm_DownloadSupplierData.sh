. /user/cvprod/.bash_profile
ssh cvprod@172.22.99.106 -n "/bin/sh /user/cvprod/PLMSAP/shell/Supplier_DataDownload/tm_DownloadSupplierData.sh '$1' $2 "
