. /user/cvprod/.bash_profile
ssh cvprod@172.22.99.106 -n "sh /user/cvprod/Program_Shells/DML_DCR/tm_NOPO_basedRpt_SRV3.sh $1"
echo "--Complete tm_NOPO_basedRpt_2c9.sh from cvprod-- "
