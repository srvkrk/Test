echo "Cronjob Shell Start Part PO details Uploader Program for CVPROD >> tm_PODetails_Uploader"
nohup ./tm_PODetails_Uploader -u="loader" -pf="/user/cvprod/shells/Admin/loaderpasswdFile.pwf" -g="dba" -i="INPUT_2025_09_19_14_39_39.csv" > INPUT_2025_09_19_14_39_39.log &
echo "Shell End Part PO details Uploader Program for CVPROD"