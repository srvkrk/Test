#!/bin/bash
. /user/omfprod/.bash_profile
########### Changing directory to CATIAOWN #####
cd /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/



date
now="$(date +'%d/%m/%Y %H:%M:%S')"
Day=`echo  $now | cut -d\/ -f1`
Mon=`echo  $now | cut -d\/ -f2`
YearS=`echo  $now | cut -d\/ -f3`
Year=`echo  $YearS | cut -d' ' -f1`
timeSt=`echo  $now | cut -d' ' -f2`
hourS=`echo  $timeSt | cut -d':' -f1`
minS=`echo  $timeSt | cut -d':' -f2`
secS=`echo  $timeSt | cut -d':' -f3`
LogFileNm=CATIA_MIG_CVPROD_DOWN_UP_SKIP_LOADED_LATESTREV_"$Year""$Mon""$Day"_"$hourS""$minS""$secS".log
echo "Log - $LogFileNm"

echo "Starting Dowload and Upload process";

#filenamePrtList=$1
filenamePrtList=InpCV.txt

echo "dollar 1 user id is $1"
echo "dollar 2 part number is $2"

echo "Direct...User Id...$1"
userId=$1
echo userId
echo "Input file is : $filenamePrtList"
	
if [ ! -f $filenamePrtList ]; then
		echo "Part List file not found"; exit 1
else

	while read PartNmCnt; do
		total_incount=$((total_incount+1))
		echo "Part $total_incount : $PartNmCnt"
	done < $filenamePrtList
	
	echo "Total Count of input Parts : $total_incount"
fi

line_no=1

while read PartNm; do
	echo "Part No. $line_no : $PartNm"
	echo "test part is $PartNm "
	start_time=$(date +%s)

	if [ ${#PartNm} -lt 2 ]; then
			echo "Part Number Blank"
			continue
	fi

	total_start_time=$(date +%s); download_start_datetime=$(date); 	download_start_time=$(date +%s)

	DownUpLogFileNm=/user/omfprod/shells/TASL_Downloading/TMETC_LATEST/"$LogFileNm"
	
	echo "[$line_no/$total_incount] DOWNLOAD-START : DOWNLOAD-SKIP-LOADED-LATESTREV SUMMARY: for Part : $PartNm Start-Time: $download_start_datetime"
	echo "Download-Upload  Log File : $LogFileNm"
	
	#######----> DOWNLOAD SHELL
	/user/omfprod/shells/TASL_Downloading/TMETC_LATEST/CATIA_MIG_CVPROD_DOWNLOAD_SKIP_LOADED_LATESTREV_UJJAWAL.sh -i $PartNm > $DownUpLogFileNm

	download_end_datetime=$(date); download_end_time=$(date +%s); download_elapsed=$(( download_end_time - download_start_time ))
	download_time_taken=`echo $(date -ud "@$download_elapsed" +'%H hr %M min %S sec')`
	
	echo "[$line_no/$total_incount] DOWNLOAD-END : DOWNLOAD-SKIP-LOADED-LATESTREV SUMMARY: for Part : $PartNm End-Time: $download_end_datetime Time-Taken: $download_time_taken"
	echo ""
	
	echo ""
	echo "#######--> Calling UPLOAD in NOHUP mode for $PartNm at  $download_end_datetime .. check loading time in logfile $LogFileNm"
	echo ""	
	nohup /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/CATIA_MIG_CVPROD_UPLOAD_SKIP_LOADED_UJJAWAL.sh -i $PartNm > $DownUpLogFileNm&
	
	sleep 2;

	#Download End in -f Mode
	line_no=$((line_no+1))
	
done < $filenamePrtList
echo " test end part is $2"	
if [ $line_no -gt 1 ]; then
filenamePrtListN="$filenamePrtList"_"$Year""$Mon""$Day"_"$hourS""$minS""$secS"
mv /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/$filenamePrtList /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/$filenamePrtListN
touch /user/omfprod/shells/TASL_Downloading/TMETC_LATEST/$filenamePrtList
fi
#./sendMail_CV.sh ${userId} $PartNm
./sendMail_CV.sh ${userId} $2
