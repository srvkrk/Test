. /home/uaprod/.bash_profile
cd /home/uaprod/TC_ROOT/bin/tml_tools
todateStr=$(date +"%m_%d_%y_%H_%M")
echo $todateStr
echo "UserName" $4 >/tmp/AMDMLGMDML_$1_$2_$todateStr.log
echo "UserRole" $5>>/tmp/AMDMLGMDML_$1_$2_$todateStr.log
echo "GMDML"    $1>>/tmp/AMDMLGMDML_$1_$2_$todateStr.log
echo "PartNumber"  $2>>/tmp/AMDMLGMDML_$1_$2_$todateStr.log
echo "Revision"    $3>>/tmp/AMDMLGMDML_$1_$2_$todateStr.log

./AmDmlCreatefrmGmDML -u='ercpsup' -p='XYT1ESA' -g='dba' -i=$1 -part=$2 -rev=$3 -User=$4 -role=$5 >>/tmp/AMDMLGMDML_$1_$2_$todateStr.log &