. /home/cmitest/.bash_profile
#!/bin/bash
echo **************In TDM_Mail_Approval Shell******************
echo $1
echo $2
echo $3
echo $4
echo $5
cd /user/testcmi/Dev/devgroups/mohan/Report/tm_DML_MailD
echo "step1"
/user/testcmi/Dev/devgroups/mohan/Report/tm_DML_MailD/tm_DML_Mail -dmlno=$1
echo "step2"
cd /user/testcmi/Dev/devgroups/mohan/Report/tm_DML_MailD
echo "step3"
while read line; 
do
	if [[ $line == *"DML Number="* ]]; then
	DML_Number=$(echo $line| cut -d'=' -f 2)
	fi
	if [[ $line == *"Business_Unit="* ]]; then
	Business_Unit=$(echo $line| cut -d'=' -f 2)
	fi
	if [[ $line == *"Release Type="* ]]; then
	Release_Type=$(echo $line| cut -d'=' -f 2)
	fi
	if [[ $line == *"DML Project="* ]]; then
	DML_Project=$(echo $line| cut -d'=' -f 2)
	fi
	if [[ $line == *"DML Creator="* ]]; then
	DML_Creator=$(echo $line| cut -d'=' -f 2)
	fi
	if [[ $line == *"DML DR status="* ]]; then
	DML_DR_status=$(echo $line| cut -d'=' -f 2)
	fi
	if [[ $line == *"DML Reason="* ]]; then
	DML_Reason=$(echo $line| cut -d'=' -f 2)
	fi
	if [[ $line == *"DML Vertical="* ]]; then
	DML_Vertical=$(echo $line| cut -d'=' -f 2)
	fi
	if [[ $line == *"DML Project="* ]]; then
	DML_Project=$(echo $line| cut -d'=' -f 2)
	fi
done < ${1}_mailoutput.txt
echo "step4"
echo $DML_Number
echo $Business_Unit
echo $Release_Type
echo $DML_Project
echo $DML_Creator
echo $DML_DR_status
echo $DML_Reason
echo $DML_Vertical
(
echo 'Content-Type: multipart/mixed; boundary="-q1w2e3r4t5"'
echo "To:$3"
echo "CC:$5"
echo "SUBJECT:DML details :$DML_Number."
echo "Content-Type: text/html"
echo "Content-Disposition: inline"
echo "<html>"
    echo "<head></head>"
    echo "<body>"
        echo "<table width='600px' border='1px' style='border-color: #256fab;border-style: none;'>"
            echo "<table width='100%'>"
                echo "<tr style='background:#256fab;height:60px;'>"
                    echo "<td colspan='3'>"
                        echo "<strong>"
                            echo "<p style=' color: #FFF;text-align: center;font-size: 20px;text-transform: uppercase;'>DML Released Details"
                            echo "</p>"
                        echo "</strong>"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'><strong>Dear Sir,</strong></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;' colspan='3'>Below DML has been released:</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;'></td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>DML Number</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$DML_Number"
                    echo "</td>"
                echo "</tr>"
                echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Business Unit</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Business_Unit"
                    echo "</td>"
		    echo "</tr>"
		 echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>Release Type</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$Release_Type"
                    echo "</td>"
		      echo "</tr>"
		 echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>DML Project</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$DML_Project"
                    echo "</td>"
		      echo "</tr>"
		 echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>DML Creator</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$DML_Creator"
                    echo "</td>"
		      echo "</tr>"
		 echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>DML DR-status</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$DML_DR_status"
                    echo "</td>"
		      echo "</tr>"
		 echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>DML Reason</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$DML_Reason"
                    echo "</td>"
		    echo "</tr>"
		 echo "<tr style='background:#FFF;height:20px;'>"
                    echo "<td style='padding:5px;font-size:12px;background-color: rgb(221, 222, 222);' width='30%'><strong style='color#256fab;'>DML Vertical</strong></td>"
                    echo "<td width='5%'>:</td>"
                    echo "<td style='padding:5px;font-size:12px;'>"
                        echo "$DML_Vertical"
                    echo "</td>"
                echo "</td></tr>"
            echo "</table>"
        echo "</table>"
    echo "</body>"
echo "</html>"
) | /usr/sbin/sendmail -f "$2" -t "$3"