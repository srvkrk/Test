. /user/cvprod/.bash_profile
DATE=`date +%Y/%m/%d -d yesterday`
DTE=`date +%d-%b-%Y -d yesterday`
FleDATE=`date +%d-%b-%Y -d yesterday`
#DATE=13-Mar-2019
#FleDATE=13_Mar_2019
echo $DATE
echo $FleDATE
Flename=/tmp/ERCDmlReleasedOn_"$FleDATE".csv
echo $Flename

/user/cvprod/TC_ROOT12/tcldPatch/tcPatchExecutable /user/cvprod/Akshay/ECU_Client_code/VehDmlRelRpt/VehDmlReleasedRpt
/user/cvprod/Akshay/ECU_Client_code/VehDmlRelRpt/VehDmlReleasedRpt -u=loader -pf=/user/cvprod/shells/Admin/loaderpasswdFile.pwf -g=dba -i=$FleDATE -f=$Flename

echo "The attached data, is the data of Vehicle DML Released on Yesterday.
Regards,
PLM Team" | mail -s "Vehicle DML Released Report"  -a $Flename devkantk.ttl@tatamotors.com manishaj.ttl@tatamotors.com amolsp.ttl@tatamotors.com kt.ttl@tatamotors.com at924736.ttl@tatamotors.com ketankor.ttl@tatamotors.com rg922962.ttl@tatamotors.com rr923236.ttl@tatamotors.com 
