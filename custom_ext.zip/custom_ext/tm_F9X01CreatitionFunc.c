#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/tc_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
//#include <tcinit/tcinit.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
//#include <bom/bom_attr.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <epm/epm_task_template_itk.h>
#include <sa/tcfile.h>
//#include <epm/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#include <tccore/item_msg.h>
#include <string.h>
//#include <epm/cr_effectivity.h>
#include <pie/pie.h>
#include <cfm/cfm.h>
#include <qry/qry.h>

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define Debug TRUE

#define ITK_CALL(x) {           \
	int stat;                     \
	char *err_string;             \
	if( (stat = (x)) != ITK_ok)   \
	{                             \
	EMH_ask_error_text (stat, &err_string);                 \
	printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	if(err_string) MEM_free(err_string);                                \
	exit (EXIT_FAILURE);                                                   \
	}                                                                    \
}
//GLOBAL VARIABLE
char*	ClosureRule	    =	NULL;
char*	ClosureRev      =	NULL;
tag_t 	F9X01UnderVeh	=	NULLTAG;

//define structure

struct BomChldStrut_F9X01
{
	tag_t child_objs;//CHild
	tag_t child_objs_bvr;//BVR
	int child_objs_lvl;//LVL
	char *PartNo;
 	char *Qty;
}*get_BomChldStrut_F9X01;

struct EMBomChldStrut
{
  tag_t child_objs;
  tag_t child_objs_bvr;//BVR
  char *PartNo;
  char *Qty;
}*get_EMBomChldStrut;

struct StructureF5B01
{
   tag_t child_objs;
   tag_t child_objs_bvr; 
   int Qty;
};

//function define
char* subString_F9X01 (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
};

void autoresizestrAdd_F9X01(char **src,char* dest)
{
        char * desc = dest ? dest : "NA";
        const size_t a = strlen(*src);
        const size_t b = strlen(desc);
        const size_t size_ab = a + b + 2;
        *src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));
        tc_strcat(*src , desc);
}

void get_Plant(char* taskInput, char** retPlant)
{
	printf("\n selectedTask : [%s]\n",taskInput);fflush(stdout);
	char* temp1 = NULL;
	char* temp2 = NULL;
	char* temp3 = NULL;
	tc_strcpy(*retPlant,"");
	temp1 = strtok(taskInput,"_");
	temp2 = strtok(NULL,"_");
	temp3 = strtok(NULL,"_");
	printf("\n temp3 :[%s]\n",temp3);fflush(stdout);
	autoresizestrAdd_F9X01(&*retPlant,temp3);
}

void GetBomClosureRule(char* view, char* plantName)
{
	int max_char_size = 80;
	ClosureRule = (char *)MEM_alloc(max_char_size * sizeof(char));
    ClosureRev = (char *)MEM_alloc(max_char_size * sizeof(char));

    tc_strcpy(ClosureRule,"");
    tc_strcpy(ClosureRev,"");
    if(tc_strcmp(view,"ERC")==0)
    {
        tc_strcpy(ClosureRule,"BOMViewClosureRuleERC");
        tc_strcpy(ClosureRev,"ERC1 Release and Above");
    }
	else if(tc_strcmp(view,"MBOM")==0)
    {
        tc_strcpy(ClosureRule,"BOMViewClosureRuleMBOM");
        tc_strcpy(ClosureRev,"MBOM Release and Above");
    }
	else if(tc_strcmp(view,"MBOM1")==0)
    {
        tc_strcpy(ClosureRule,"BOMViewClosureRuleMBOM");
        tc_strcpy(ClosureRev,"ERC1 Release and Above");
    }
    else if (tc_strcmp(view,"APL")==0)
    {
        if (tc_strcmp(plantName,"APLJ")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLJ");
            tc_strcpy(ClosureRev,"ERC1 Release and Above");
        }
        else if (tc_strcmp(plantName,"APLL")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLL");
            tc_strcpy(ClosureRev,"ERC1 Release and Above");
        }
        else if (tc_strcmp(plantName,"APLD")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLD");
            tc_strcpy(ClosureRev,"ERC1 Release and Above");
        }
        else if (tc_strcmp(plantName,"APLP")==0)
        {
            tc_strcpy(ClosureRule,"BOMViewClosureRuleAPLP");
            tc_strcpy(ClosureRev,"ERC1 Release and Above");
        }
    }
	else
	{
		printf("\n F9X01 is not live for input plant\n");fflush(stdout);
	}
    printf("\n ClosureRule = %s\n ",ClosureRule);fflush(stdout);
    printf("\n ClosureRev = %s\n ",ClosureRev);fflush(stdout);
}

void checkControlObjectLive_F9X01(char* t5_Syscd , char* t5_SubSyscd , char* t5_DelInd , int* coFlag , tag_t* coF9X01)
{
	printf("\n*******Inside checkControlObjectLive_F9X01********\n");fflush(stdout);
	tag_t 	query_tag = NULLTAG;
	tag_t* QuerySOB =NULLTAG;
	int     noOfArg    = 3;
	char    *qry_attrs[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};
	char	**qry_values= (char **) MEM_alloc(10 * sizeof(char *));
	int  QuerySOBCount=0;	
	if(QRY_find2("Control Objects...", &query_tag));
	if (query_tag)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_values[0] = t5_Syscd;
		qry_values[1] = t5_SubSyscd;
		if(tc_strcmp(t5_DelInd,"True")==0)
			qry_values[2] = "1";
		else if(tc_strcmp(t5_DelInd,"False")==0)
			qry_values[2] = "0";
		else
			qry_values[2] = "";
		printf("\n qry_values :[%s]:[%s]:[%s]",qry_values[0],qry_values[1],qry_values[2]);fflush(stdout);
		if(QRY_execute(query_tag, noOfArg, qry_attrs, qry_values, &QuerySOBCount, &QuerySOB));
		printf("\n QuerySOBCount :[%d]",QuerySOBCount);fflush(stdout);
		if(QuerySOBCount>0)
		{
			*coFlag = 1;
			*coF9X01 = QuerySOB[0];
		}
	}
}

void getControlObjectDetails_F9X01(tag_t coItem,char** clubbedInformation)
{
	printf("\n******* Inside getControlObjectDetails_F9X01 ********\n");fflush(stdout);
	char* info1 = NULL;
	info1 = (char *) MEM_alloc(200);
	tc_strcpy(*clubbedInformation,"");
	tc_strcpy(info1,"");
	ITK_CALL(AOM_ask_value_string(coItem,"t5_Userinfo1", &info1));
	printf("\n information 1 : [%s]",info1);fflush(stdout);
	autoresizestrAdd_F9X01(&*clubbedInformation,info1);
}

void getTaskOwningValue_F9X01(char* itemidtask, char* PLtaskvalue)   //vishal function
{

        char        *Task_no            = NULL;
        char        *Dsgn_No			= NULL;
        char		*PLT_name			= NULL;

        printf("********** Inside Function getTaskOwningValue_F9X01 *********");fflush(stdout);
        
        printf("\n DML TASK ID is = %s",itemidtask);fflush(stdout);
        
        Task_no=tc_strtok(itemidtask,"_");	
        printf("\n Task_no:%s\n",Task_no);fflush(stdout);
        Dsgn_No = tc_strtok(NULL,"_");
        printf("\n Dsgn_No:%s\n",Dsgn_No);fflush(stdout);
        PLT_name = tc_strtok(NULL,"_");
        printf("\n PLT_name:%s\n",PLT_name);fflush(stdout);

        if(tc_strcmp(PLT_name,"APLA")==0)
        {
            tc_strcpy(PLtaskvalue,"APLAHD");
        }
        else if (tc_strcmp(PLT_name,"APLD")==0)
        {
            tc_strcpy(PLtaskvalue,"APLDWD");
        }
        else if (tc_strcmp(PLT_name,"APLC")==0)
        {
            tc_strcpy(PLtaskvalue,"APLCAR");
        }
        else if (tc_strcmp(PLT_name,"APLV")==0)
        {
            tc_strcpy(PLtaskvalue,"APLUV");
        }
        else if (tc_strcmp(PLT_name,"APLP")==0)
        {
            tc_strcpy(PLtaskvalue,"APLPUNE");
        }
        else if (tc_strcmp(PLT_name,"APLU")==0)
        {
            tc_strcpy(PLtaskvalue,"APLPNR");
        }
        else if (tc_strcmp(PLT_name,"APLL")==0)
        {
            tc_strcpy(PLtaskvalue,"APLLKO");
        }
        else if (tc_strcmp(PLT_name,"APLJ")==0)
        {
            tc_strcpy(PLtaskvalue,"APLJSR");
        }
        else
        {
            tc_strcpy(PLtaskvalue,"APLPUNE");
        }
    
    printf("\n PLtaskvalue:%s\n",PLtaskvalue);fflush(stdout);

    printf("********** Exiting Function getTaskOwningValue_F9X01 *********");fflush(stdout);

}



void  get_CtrlVal_APLLcsInf_F9X01( char * Tsk_Own_Grp ,char  RevRuleInfo1[40],char  BVRInfo2[40],char  CurMskInfo3[40])
{
	 char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	 char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *RevRule 			= NULL;
	 char *viewfrmCtrl		= NULL;
	 char *CurVwMask		= NULL;
	 //char *Info4Ctrl		= NULL;
	 //char *Info5Ctrl		= NULL;
	// char *Info6Ctrl		= NULL;
	// char *Info7Ctrl		= NULL;
	// char *Info8Ctrl		= NULL;
	// char *Info9Ctrl		= NULL;

	 if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLLcsInf";
				qry_valuesCntrl1[1]=Tsk_Own_Grp;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &RevRule);
				printf("\n RevRule: %s\n",RevRule);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &viewfrmCtrl);
				printf("\n viewfrmCtrl: %s\n",viewfrmCtrl);fflush(stdout);

				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &CurVwMask);
				printf("\n CurVwMask: %s\n",CurVwMask);fflush(stdout);

				tc_strcpy(RevRuleInfo1,RevRule);
				tc_strcpy(BVRInfo2,viewfrmCtrl);
				tc_strcpy(CurMskInfo3,CurVwMask);
					
			}
			else
			{
				//tc_strcpy(RevRuleInfo1,"ERC release and above");
				tc_strcpy(RevRuleInfo1,"ERC release and above APLC");//Deepti TZ1.55
				tc_strcpy(BVRInfo2,"View");
				tc_strcpy(CurMskInfo3,"bl_occ_t5_CurrentViewMaskC");
			}
}

void Multi_Get_Part_BOM_Lvl_F9X01(tag_t inputPart,int reqLevel,int level,tag_t closure_tag,tag_t revRule,char ViewBVR[100],struct BomChldStrut_F9X01 BomChldStrut_F9X01[],int* StructChldCnt)
{
	int ifail;
    int iChildItemTag=0;
	char * ItemName ;
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t	window 				= NULLTAG;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t	top_line			= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;

	printf("\n Inside Multi_Get_Part_BOM_Lvl_F9X01[%d] ...\n",*StructChldCnt);

	ITK_CALL(AOM_ask_value_string(inputPart,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	printf("\n ViewBVR=>[%s] ...\n",ViewBVR);

	if( level >= reqLevel )
	{
		goto CLEANUP;
	}

	ITK_CALL(ITEM_rev_list_bom_view_revs(inputPart, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

	if(n_values_bvr==0)
	{
		flagBVR=0;
	}
	else if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITK_CALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name1 %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				//if(tc_strcmp(viewTok,ViewBVR)==0)
				if(tc_strstr(viewTok,"View")!=NULL)
				{
					flagBVR=1;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		if(flagBVR!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITK_CALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					if(tc_strstr(viewTok,"View")!=NULL)
					{
						flagBVR=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			}
		}

	}
	printf("\n flagBVR=>[%d] ",flagBVR);fflush(stdout);

	ITK_CALL(BOM_create_window (&window));
	ITK_CALL(BOM_set_window_config_rule(window,revRule));
	ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
	ITK_CALL(BOM_set_window_pack_all (window,true));
	if(flagBVR==1)
	{
		BOM_set_window_top_line(window, null_tag,inputPart ,bvr_tag, &top_line);
		ITK_CALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n\n\t\t No of child objects are n : %d\n",n);fflush(stdout);

		level = level + 1;
		for (k = 0; k < n; k++)
		{
			char *unconfigStat,*childQty;
            printf("\n inside unconfig ");
            ITK_CALL(AOM_UIF_ask_value(children[k],"bl_config_string",&unconfigStat));
            ITK_CALL(AOM_ask_value_string(children[k],"bl_quantity",&childQty));
            tag_t unconfiguredPart,unconfiguredPartLatest;
            if(tc_strcmp(unconfigStat,"No configured Revision")==0 && tc_strcmp(childQty,"0")!=0)
            {
                char* itemID;
                ITK_CALL(AOM_ask_value_string(children[k],"bl_item_item_id",&itemID));
                printf("bl_item_item_id - %s",itemID);
                ITK_CALL(ITEM_find_item(itemID,&unconfiguredPart));
                ITK_CALL(ITEM_ask_latest_rev(unconfiguredPart,&t_ChildItemRev));
            }
            else 
			{
				ITK_CALL(AOM_ask_value_tag (children[k],bomAttr_lineItemRevTag, &t_ChildItemRev));
			}
			if(t_ChildItemRev!=NULLTAG)
			{
				*StructChldCnt	=	*StructChldCnt+1;
				BomChldStrut_F9X01[*StructChldCnt].child_objs = t_ChildItemRev;
				BomChldStrut_F9X01[*StructChldCnt].child_objs_bvr=children[k];
				BomChldStrut_F9X01[*StructChldCnt].child_objs_lvl=level;

				Multi_Get_Part_BOM_Lvl_F9X01(t_ChildItemRev,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut_F9X01,StructChldCnt);
			}
		}
		level = level - 1;
	}

	MEM_free (childrenTag);

	CLEANUP:
	printf("\n Inside Multi_Get_Part_BOM_Lvl_F9X01 CLEANUP");fflush(stdout);
}

int Get_Part_BOM_Lvl_F9X01(tag_t VehicleObj,int reqLevel,char*  closureRuleName,char*  revRuleName,char* ViewBVR,struct BomChldStrut_F9X01 BomChldStrut_F9X01[] ,int* StructChldCnt)
{
	int   ifail				= 0;

	tag_t revRule 			= NULLTAG;
	char* vehicleNumber 	= NULL;
	int j					= 0;
	PIE_scope_t scope;
	int 	n_closure_tags;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int k1=0;
	int n=0;
	int 	n_values_bvr=0;
	tag_t			*bvr_assy_part= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	int level 				= 0;
	tag_t	window 				= NULLTAG;
	tag_t	top_line			= NULLTAG;
	tag_t	objChild			= NULLTAG;
	tag_t	objChild_bvr			= NULLTAG;
	int child_lvl=0;
	char	*c_Qty						=	NULL;
	tag_t  *children1=NULLTAG;
	int iChildItemTag=0;
	int assbvr=0;
	int bvrfound=0;
	int flagRevRule=0;
	int flagClosureRule=0;
	char *view_name=NULL;
	char*			partTok					=NULL;
	char*			viewTok					=NULL;
	tag_t   t_ChildItemRev;
	char * ItemName ;

	printf("\nInside Get_Part_BOM_Lvl_F9X01 ....\n");

	if(VehicleObj == NULLTAG)
	{
		printf("\n VehicleObj is NULLTAG\n");fflush(stdout);
		return ifail;
	}
	ITK_CALL(AOM_ask_value_string(VehicleObj,"item_id",&vehicleNumber));
	printf("\n Part number===>%s\n",vehicleNumber);fflush(stdout);

	printf("\nBefore Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	printf("\nBefore reqLevel==>%d\n",reqLevel);fflush(stdout);
	printf("\nBefore level==>%d\n",level);fflush(stdout);
	printf("\nclosureRuleName==>%s\n",closureRuleName);fflush(stdout);
	printf("\nrevRuleName==>%s\n",revRuleName);fflush(stdout);
	printf("\nViewBVR==>%s\n",ViewBVR);fflush(stdout);

	ITK_CALL(ITEM_rev_list_bom_view_revs(VehicleObj, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);
	if(n_values_bvr>0)
	{
		printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITK_CALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			printf("\n view_name4 %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{
				//if(tc_strcmp(viewTok,ViewBVR)==0)
				if(tc_strstr(viewTok,"View")!=NULL)
				{
					bvrfound++;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		//Added by Hemal, same need to check and add in common file also.
		if(bvrfound!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITK_CALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				printf("\n view_name3 %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					//if(tc_strcmp(viewTok,ViewBVR)==0)
					if(tc_strstr(viewTok,"View")!=NULL)
					{
						bvrfound=1;
						bvr_tag=bvr_assy_part[assbvr];
						break;
					}
				}
			}
		}
		//Ended by Hemal

	}

	printf("\n bvrfound=>[%d] ",bvrfound);fflush(stdout);
	if(bvrfound==0)
	{
		printf("\n**********BVR NOT Exist*********\n");fflush(stdout);
	}
	else
	{
		ITK_CALL(CFM_find(revRuleName, &revRule));
		if (revRule != NULLTAG)
		{
			printf("\nFind revRule\n");fflush(stdout);
			flagRevRule=1;
		}

		scope=PIE_TEAMCENTER;
		ITK_CALL(PIE_find_closure_rules2(closureRuleName,scope,&n_closure_tags,&closure_tags));
		printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
		if(n_closure_tags==1)
		{
			closure_tag=closure_tags[0];
			flagClosureRule=1;
		}
		printf("\n flagClosureRule=>[%d] ",flagClosureRule);fflush(stdout);
		printf("\n flagRevRule=>[%d] ",flagRevRule);fflush(stdout);
		if((flagClosureRule==1) && (flagRevRule==1))
		{

			Multi_Get_Part_BOM_Lvl_F9X01(VehicleObj,reqLevel,level,closure_tag,revRule,ViewBVR,BomChldStrut_F9X01,StructChldCnt);
		}
		else
		{
			printf("\n******Revision or Closure Rule Not Found******\n");fflush(stdout);
		}

	}
	printf("\nAfter Size of StructChldCnt==>%d\n",*StructChldCnt);fflush(stdout);
	return ifail;
}

void getChildOfF5B01(tag_t ChildTag,char* ChildQuantity,tag_t closure_rule,tag_t revision_rule,struct StructureF5B01 ChildStructure[],int* StructChldCnt)
{
    int ifail;
	char * ItemName =NULL;
	char * parttype =NULL;
	char * ItemQty =NULL;
	char * CQty =NULL;
	char * CItemName =NULL;
	char	conQtyString[20];
	int k=0;
    int n=0;
    int assbvr=0;
    int flagBVR=0;
    int ItemQtyInt=0;
    int CQtyInt=0;
    int cnt=0;
    int conQty=0;
    int FlagFound=0;
	int n_values_bvr=0;
	tag_t *bvr_assy_part= NULLTAG;
	tag_t bvr_tag= NULLTAG;
	tag_t   t_ChildItemRev;
	tag_t*	childrenTag	= NULLTAG;
	char *view_name=NULL;
	tag_t window = NULLTAG;
	char* partTok=NULL;
	char* viewTok =NULL;
	tag_t top_line= NULLTAG;
	int bvrfound=0;
	tag_t  *children=NULLTAG;
	char* partNumber 	= NULL;
	int ItemIDLength = 0;
    int ParentQuantityInt = 0;
    int ItemQtyTotal = 0;
	tag_t objChild		= NULLTAG;
    tag_t objChild_bvr	= NULLTAG;
	
	ItemQty = (char *)MEM_alloc(1 * sizeof(char *));


	printf("\n IgetChildOfF5B01 \n");

	ITK_CALL(AOM_ask_value_string(ChildTag,"item_id",&partNumber));
	printf("\n Part number===>%s\n",partNumber);fflush(stdout);

	ITK_CALL(ITEM_rev_list_bom_view_revs(ChildTag, &n_values_bvr, &bvr_assy_part));
	printf("\n n_values_bvr=>[%d] ",n_values_bvr);fflush(stdout);

	if(n_values_bvr==0)
	{
		flagBVR=0;
	}
	else if(n_values_bvr>0)
	{
		//printf("\n BVR found");fflush(stdout);
		for(assbvr=0;assbvr<n_values_bvr;assbvr++)
		{
			ITK_CALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
			//printf("\n view_name %s",view_name);fflush(stdout);
			partTok = strtok (view_name,"-");
			viewTok = strtok (NULL,"-");
			//printf("\n viewTok %s",viewTok);fflush(stdout);
			if(strlen(viewTok)>0)
			{				
				//if(tc_strcmp(viewTok,ViewBVR)==0)
				if(tc_strcmp(viewTok,"View")==0)
				{
					flagBVR=1;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
		if(flagBVR!=1)
		{
			for(assbvr=0;assbvr<n_values_bvr;assbvr++)
			{
				ITK_CALL(AOM_ask_value_string(bvr_assy_part[assbvr],"object_name",&view_name));
				//printf("\n view_name %s",view_name);fflush(stdout);
				partTok = strtok (view_name,"-");
				viewTok = strtok (NULL,"-");
				//printf("\n viewTok %s",viewTok);fflush(stdout);
				if(strlen(viewTok)>0)
				{
					flagBVR=1;
					bvr_tag=bvr_assy_part[assbvr];
					break;
				}
			}
		}
	}
	ITK_CALL(BOM_create_window (&window));
	ITK_CALL(BOM_set_window_config_rule(window,revision_rule));
	ITK_CALL(BOM_set_window_pack_all(window,true));
	ITK_CALL(BOM_window_set_closure_rule(window,closure_rule,0,NULL,NULL));
	if(flagBVR==1)
	{
		BOM_set_window_top_line(window, null_tag,ChildTag ,bvr_tag, &top_line);
		ITK_CALL(BOM_line_ask_child_lines (top_line, &n, &children));
		printf("\n\n\t\t **********************No of child objects are %d inside F5B01 : %s*********************\n",n,partNumber);fflush(stdout);
		int iItemIdInt = 0;
		for (k = 0; k < n; k++)
		{
			//BOM_line_unpack (children[k]);
			ITK_CALL(AOM_ask_value_tag (children[k],bomAttr_lineItemRevTag, &t_ChildItemRev));
			if(t_ChildItemRev!=NULLTAG)
			{
				ITK_CALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName));
				printf("\n\n\t\t child part name: %s \n",ItemName);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartType",&parttype));
				printf("\n\n\t\t child part type: %s \n",parttype);fflush(stdout);				
				ITK_CALL(AOM_ask_value_string(children[k],"bl_quantity",&ItemQty)); 
				printf("\n\n\t\t child part quantity: %s \n",ItemQty);fflush(stdout);
				printf("\n\n\t\t child part parent: %s \n",ChildQuantity);fflush(stdout);

				ItemQtyInt=0;
				ItemQtyInt=atoi(ItemQty);
				ParentQuantityInt = atoi(ChildQuantity);
				ItemQtyTotal =ItemQtyInt * ParentQuantityInt;
				printf("\n\n\t\t ItemQtyTotal: %d \n",ItemQtyTotal);fflush(stdout);
				conQty=0;
				FlagFound=0;
				if(*StructChldCnt>0)
                {
                    for (cnt=1;cnt<= *StructChldCnt;cnt++)
                    {
                        int Child_qty = 0;
                        objChild		= NULLTAG;
                        objChild_bvr	= NULLTAG;
                        CQty			= NULL;
                        CItemName		= NULL;
                        CQty = (char *)MEM_alloc(1 * sizeof(char *));
                        //CQtyInt=0;
        
                        //printf("\n Print Item ID to check for Already exist Item==>%d\n",cnt);fflush(stdout);
        
                        objChild=ChildStructure[cnt].child_objs;
                        objChild_bvr=ChildStructure[cnt].child_objs_bvr;
                        Child_qty=ChildStructure[cnt].Qty;
        
                        ITK_CALL(AOM_ask_value_string(objChild,"item_id",&CItemName));
                        if(tc_strcmp(ItemName,CItemName)==0)
                        {
                            printf("\n CItemName==>%s\n",CItemName);fflush(stdout);
                            printf("\n CItemQTy==>%d\n",Child_qty);fflush(stdout);
                            conQty=Child_qty+ItemQtyTotal;
                            printf("\n conQty==>%d",conQty);fflush(stdout);
                            FlagFound=1;
                            break;
                        }		
        
                    }
                    if(FlagFound==1)
                    {
                        ChildStructure[cnt].Qty=conQty;
                        printf("cnt === %d",cnt);
                    }
                    else
                    {
                        *StructChldCnt	=	*StructChldCnt+1;
                        
                        ChildStructure[*StructChldCnt].child_objs = t_ChildItemRev;
                        ChildStructure[*StructChldCnt].child_objs_bvr = children[k];
                        ChildStructure[*StructChldCnt].Qty=ItemQtyTotal;
                    
                    }
                }
                else
                {
                    *StructChldCnt	=	*StructChldCnt+1;
                    ChildStructure[*StructChldCnt].child_objs = t_ChildItemRev;
                    ChildStructure[*StructChldCnt].child_objs_bvr = children[k];
                    ChildStructure[*StructChldCnt].Qty=ItemQtyTotal;
                }				
			}
		}
	}
}

void autoresizeTagAdd_F9X01(int *count,tag_t **objlist,tag_t obj )
{
	printf("\n 1234 [%d]",*count);fflush(stdout);
	char* childItemName =NULL;
	*count=*count+1;
	if(*count==1)
	{
		printf("\n hajdbjashchjhd [%d]",*count);fflush(stdout);
		(*objlist) = (tag_t *)malloc((*count ) * sizeof(tag_t ));
	}
	else
	{
		printf("\n else [%d]",*count);fflush(stdout);
		(*objlist) = (tag_t *)realloc((*objlist),(*count ) * sizeof(tag_t ));
	}
	printf("\n 9999999999 : [%d]",*count);fflush(stdout);
	(*objlist)[*count-1] = obj; 
	ITK_CALL(AOM_ask_value_string((*objlist)[*count-1],"item_id",&childItemName));
}

void getF5B01ChildPartsFromStructure(struct StructureF5B01 ChldMBOMStrutBlt[],int ClrStructCntMBOM,int* F5CountFromStructure,tag_t** F5BomLineFromStructure)
{
	int q = 0;
	int count = 0;
	char* ChildNameFromStructure = NULL;
	int ChildQuantityFromStructure = 0;
	char* ChildQuantityFromStructureReturn = NULL;
	tag_t ChildTagFromStructure = NULLTAG;
	tag_t ChildBVRTagFromStructure = NULLTAG;
	//tag_t* F5BomLineFromStructureBVR = NULLTAG;
	for(q=1;q<=ClrStructCntMBOM;q++)
	{
		ChildNameFromStructure = NULLTAG;
		ChildQuantityFromStructure = 0;
		//ChildQuantityFromStructure = (char *)realloc(ChildQuantityFromStructure, 20 * sizeof(char));
		//ChildBVRTagFromStructure = NULLTAG;
		ChildTagFromStructure = ChldMBOMStrutBlt[q].child_objs;
		//ChildBVRTagFromStructure = ChldMBOMStrutBlt[q].child_objs_bvr;
		ChildQuantityFromStructure = ChldMBOMStrutBlt[q].Qty;
		ITK_CALL(AOM_ask_value_string(ChildTagFromStructure,"item_id",&ChildNameFromStructure));
		//ITK_CALL(AOM_ask_value_string(ChildBVRTagFromStructure,"bl_quantity",&ChildQuantityFromStructure));
		printf("\n Quantity of child [%s] in getF5B01ChildPartsFromStructure is :[%d]\n",ChildNameFromStructure,ChildQuantityFromStructure);fflush(stdout);
		autoresizeTagAdd_F9X01(F5CountFromStructure,&*F5BomLineFromStructure,ChildTagFromStructure);
	}
}

//Expand Vehicle in APL Plant and check  if F9X01 is present or not
void checkF9X01UnderVeh(tag_t itemRev,char* tmpPlant,int* flagF9X01UnderVeh)
{
	printf("\n ********* Check F9X01 under vehicle *******\n");fflush(stdout);
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	ITK_CALL(BOM_create_window (&window));
	//ITK_CALL(CFM_find(ClosureRev,&rule));  //prince
	//ITK_CALL(BOM_set_window_config_rule( window, rule ));
	ITK_CALL(BOM_set_window_pack_all(window, true));
	//ITK_CALL(PIE_find_closure_rules2( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));//prince
	printf ("rule count %d \n",rulefound);fflush(stdout);
	/*
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("closure rule ** found \n");fflush(stdout);
	}
	else
	{
		printf ("closure rule ** not found \n");fflush(stdout);
		exit;
	}
		*/
	//ITK_CALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITK_CALL(BOM_set_window_top_line(window,null_tag,itemRev,NULLTAG,&bom_line));
	ITK_CALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d,",count);fflush(stdout);
	
	for(childIterator = 0 ; childIterator <count;childIterator++)
	{
		char *childItemName = NULL;
		char *bl_item_id2 = NULL;
		ITK_CALL(BOM_line_unpack (child[childIterator]));
		ITK_CALL(AOM_ask_value_tag (child[childIterator],bomAttr_lineItemRevTag, &t_ChildItemRev));
		{
			ITK_CALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&childItemName));
			printf("\n %d.child ItemName:[%s]",childIterator,childItemName);fflush(stdout);
			
			if(tc_strstr(childItemName,"F9X01")!=NULL)
			{
				*flagF9X01UnderVeh = *flagF9X01UnderVeh+1;
				printf("\n F9X01 found :[%s]\n" ,childItemName );fflush(stdout);
				F9X01UnderVeh = t_ChildItemRev;
			}
		}
	}
	printf("\n---------------flagF9X01UnderVeh ----------------: [%d]",*flagF9X01UnderVeh);fflush(stdout);
}





void fromToBomCompare_New(struct StructureF5B01 ChldMBOMStrutBlt[],struct BomChldStrut_F9X01 F9X01MBOMStrutBlt[],int ClrStructCntMBOM,int * changeCount)
{
	printf("\n **********fromToBomCompare_New********");fflush(stdout);
	int iteratorBom1,iteratorBom2,a,b=0;
	int bomChkFlag =0;
	*changeCount = 0;
	char* ChildNameFromStructure = NULL;
	int ChildQuantityFromStructure = 0;
	int ChildQuantityFromF9X01int = 0;
	tag_t ChildTagFromStructure = NULLTAG;
	tag_t ChildBVRTagFromF9X01 = NULLTAG;
	char* ChildNameFromF9X01 = NULL;
	char* ChildQuantityFromF9X01 = NULL;
	tag_t ChildTagFromF9X01 = NULLTAG;
	printf("\n ******************inside BOM 1********************\n");fflush(stdout);
	for(iteratorBom1=1;iteratorBom1<=ClrStructCntMBOM;iteratorBom1++)
	{
		bomChkFlag = 0;
		ChildTagFromStructure = NULLTAG;
		ChildTagFromStructure = ChldMBOMStrutBlt[iteratorBom1].child_objs;
		ChildQuantityFromStructure = ChldMBOMStrutBlt[iteratorBom1].Qty;
		ITK_CALL(AOM_ask_value_string(ChildTagFromStructure,"item_id",&ChildNameFromStructure));
		printf("\n Quantity of child [%s] in BOM 1 is :[%d]\n",ChildNameFromStructure,ChildQuantityFromStructure);fflush(stdout);
		for(iteratorBom2=1;iteratorBom2<=ClrStructCntMBOM;iteratorBom2++)
		{
			ChildTagFromF9X01 = NULLTAG;
			ChildBVRTagFromF9X01 = NULLTAG;
			ChildTagFromF9X01 = F9X01MBOMStrutBlt[iteratorBom2].child_objs;
			ChildBVRTagFromF9X01 = F9X01MBOMStrutBlt[iteratorBom2].child_objs_bvr;
			ITK_CALL(AOM_ask_value_string(ChildTagFromF9X01,"item_id",&ChildNameFromF9X01));
			ITK_CALL(AOM_ask_value_string(ChildBVRTagFromF9X01,"bl_quantity",&ChildQuantityFromF9X01));
			printf("\n Quantity of child [%s] in BOM 2 is :[%s]\n",ChildNameFromF9X01,ChildQuantityFromF9X01);fflush(stdout);
			ChildQuantityFromF9X01int = atoi(ChildQuantityFromF9X01);
			printf("\n ChildNameFromStructure :[%s]\n",ChildNameFromStructure);fflush(stdout);
			printf("\n ChildNameFromF9X01:[%s]\n",ChildNameFromF9X01);fflush(stdout);
			printf("\n ChildQuantityFromStructure :[%d]\n",ChildQuantityFromStructure);fflush(stdout);
			printf("\nChildQuantityFromF9X01 :[%d]\n",ChildQuantityFromF9X01int);fflush(stdout);
			if((tc_strcmp(ChildNameFromStructure,ChildNameFromF9X01) ==0) && (ChildQuantityFromF9X01int == ChildQuantityFromStructure))
			{
				printf("\n Match Found\n");fflush(stdout);
				bomChkFlag =1;
				break;
			}
		}
		if(bomChkFlag ==0)
		{
			printf("\n partNumber:[%s] is not under common F9X01 \n",ChildNameFromStructure);fflush(stdout);
			*changeCount = *changeCount + 1;
			printf("\n changeCount[%d] **************\n",changeCount);fflush(stdout);
		}
	}
	printf("\n ******************inside BOM 2********************\n");fflush(stdout);
	for(iteratorBom1=1;iteratorBom1<=ClrStructCntMBOM;iteratorBom1++)
	{
		bomChkFlag = 0;
		ChildTagFromF9X01 = NULLTAG;
		ChildBVRTagFromF9X01 = NULLTAG;
		ChildTagFromF9X01 = F9X01MBOMStrutBlt[iteratorBom1].child_objs;
		ChildBVRTagFromF9X01 = F9X01MBOMStrutBlt[iteratorBom1].child_objs_bvr;
		//ChildQuantityFromF9X01 = F9X01MBOMStrutBlt[iteratorBom1].Qty;
		ITK_CALL(AOM_ask_value_string(ChildTagFromF9X01,"item_id",&ChildNameFromF9X01));
		ITK_CALL(AOM_ask_value_string(ChildBVRTagFromF9X01,"bl_quantity",&ChildQuantityFromF9X01));
		printf("\n Quantity of child [%s] in BOM 2 is :[%s]\n",ChildNameFromF9X01,ChildQuantityFromF9X01);fflush(stdout);
		ChildQuantityFromF9X01int = atoi(ChildQuantityFromF9X01);
		for(iteratorBom2=1;iteratorBom2<=ClrStructCntMBOM;iteratorBom2++)
		{
			ChildTagFromStructure = NULLTAG;
			ChildTagFromStructure = ChldMBOMStrutBlt[iteratorBom2].child_objs;
			ChildQuantityFromStructure = ChldMBOMStrutBlt[iteratorBom2].Qty;
			ITK_CALL(AOM_ask_value_string(ChildTagFromStructure,"item_id",&ChildNameFromStructure));
			printf("\n Quantity of child [%s] in BOM 1 is :[%d]\n",ChildNameFromStructure,ChildQuantityFromStructure);fflush(stdout);
			printf("\n 11ChildNameFromStructure :[%s]\n",ChildNameFromStructure);fflush(stdout);
			printf("\n 11ChildNameFromF9X01:[%s]\n",ChildNameFromF9X01);fflush(stdout);
			printf("\n 11ChildQuantityFromStructure :[%d]\n",ChildQuantityFromStructure);fflush(stdout);
			printf("\n 11ChildQuantityFromF9X01 :[%d]\n",ChildQuantityFromF9X01int);fflush(stdout);
			if((tc_strcmp(ChildNameFromStructure,ChildNameFromF9X01) ==0)&&(ChildQuantityFromF9X01int == ChildQuantityFromStructure))
			{
				printf("\n Match Found\n");fflush(stdout);
				bomChkFlag = 1;
				break;
			}
		}						
		if(bomChkFlag ==0)
		{
			printf("\n partNumber:[%s] is not present under APL view\n",ChildNameFromF9X01);fflush(stdout);
			*changeCount = *changeCount + 1;
			printf("\n changeCount[%d] **************\n",*changeCount);fflush(stdout);
		}
	}
}

char* getView_F9X01(char* plantName)
{
	char *retPlant;
	retPlant = (char*) MEM_alloc(4*sizeof(char*));
	 tc_strcpy(retPlant,"");
	if(tc_strcmp(plantName,"APLA")==0)
		tc_strcpy(retPlant,"T5_APLAView");
	else if(tc_strcmp(plantName,"APLC")==0)
		tc_strcpy(retPlant,"T5_APLCView");
	else if(tc_strcmp(plantName,"APLD")==0)
		tc_strcpy(retPlant,"T5_APLDView");
	else if(tc_strcmp(plantName,"APLJ")==0)
		tc_strcpy(retPlant,"T5_APLJView");
	else if(tc_strcmp(plantName,"APLL")==0)
		tc_strcpy(retPlant,"T5_APLLView");
	else if(tc_strcmp(plantName,"APLP")==0)
		tc_strcpy(retPlant,"T5_APLPView");
	else if(tc_strcmp(plantName,"APLS")==0)
		tc_strcpy(retPlant,"T5_APLSView");
	else if(tc_strcmp(plantName,"APLU")==0)
		tc_strcpy(retPlant,"T5_APLUView");
	else if(tc_strcmp(plantName,"APLV")==0)
		tc_strcpy(retPlant,"T5_APLVView");
	else if(tc_strcmp(plantName,"MBOM")==0)
		tc_strcpy(retPlant,"T5_MBOMView");
	printf("\n View is [%s]",retPlant);fflush(stdout);	
	return retPlant;
}

int t5CheckForCommonF9X01Obj_FromStructure(struct StructureF5B01 ChldMBOMStrutBlt[],int ClrStructCntMBOM,char* tmpPlant, char* taskProjectCode, tag_t* existingF9X01)
{
	struct BomChldStrut_F9X01 F9X01MBOMStrutBlt[5000];
	int F9X01StructCntMBOM = 0;
	char* cabView = getView_F9X01(tmpPlant);
	
	char* F9X01FinalPartNo = NULL;
	tag_t partTag = NULLTAG;
	F9X01FinalPartNo = (char*)MEM_alloc(1*sizeof(char*));
	tc_strcpy(F9X01FinalPartNo,"");
	autoresizestrAdd_F9X01(&F9X01FinalPartNo,taskProjectCode);
	autoresizestrAdd_F9X01(&F9X01FinalPartNo,"F9X0140*");
	printf("\n t5CheckForCommonF9X01Obj :  F9X01FinalPartNo ===> %s\n", F9X01FinalPartNo);fflush(stdout);
	if(QRY_find2("Item Revision...", &partTag));
	if(partTag != NULLTAG)
	{
		printf("\nFound Query partTag \n"); fflush(stdout);
		int 		n_entries			=	2;
		int 		Qry_Found 			;
		tag_t 		*setOfF9X01 	= 	NULLTAG;
		tag_t 		setOfF9X01Ptr 	= 	NULLTAG;
		char 		*qry_entries[2] 	= 	{"Item ID","Type"};
		char 		*qry_values[]		=	{F9X01FinalPartNo,"Design Revision"};
		ITK_CALL(QRY_execute(partTag,n_entries,qry_entries,qry_values,&Qry_Found,&setOfF9X01));
		printf("\n Total Parts found t5CheckForCommonF9X01Obj : %d",Qry_Found);fflush(stdout);
		//F9X01 found for similar project
		if(Qry_Found > 0)
		{
			int i=0, q=0;
			char* F9X01Number = NULL;
			tag_t* cabBomLineFromF9X01 = NULLTAG;
			tag_t* cabBomLineFromF9X01_unpack = NULLTAG;
			int fromF9X01Count	=	0;
			int fromF9X01Count_unpack = 0;
			tag_t* ToBeUpdatedInModule	=	NULLTAG;
			tag_t aplViewTag = NULLTAG;
			char *psmbomview = NULL;
			int		 ToBeUpdatedCount	=	0;
			int		 CommonFoundFlag	=	0;
			GetBomClosureRule("APL",tmpPlant);
			//Expand each F9X01 and check if its having same bom as per F9X01 Applicable bom
			for(i=0;i<Qry_Found;i++)
			{
				ToBeUpdatedCount = 0;
				setOfF9X01Ptr = setOfF9X01[i];
				ITK_CALL(PS_find_view_type(cabView,&aplViewTag))
				ITK_CALL(PS_ask_view_type_name(aplViewTag,&psmbomview));
				printf("\n Ps_view_type_name %s ",psmbomview);fflush(stdout);
				AOM_ask_value_string(setOfF9X01Ptr,"item_id",&F9X01Number);
				printf("\n (%d) F9X01Number : %s\n",i,F9X01Number);fflush(stdout);
				//tm_EBOM_MBOM_Get_Part_BOM_Lvl(setOfF9X01Ptr,1,ClosureRule,ClosureRev,"View",F9X01MBOMStrutBlt,&F9X01StructCntMBOM);
				F9X01StructCntMBOM = 0;
				Get_Part_BOM_Lvl_F9X01(setOfF9X01Ptr,1,ClosureRule,ClosureRev,psmbomview,F9X01MBOMStrutBlt,&F9X01StructCntMBOM);
				printf("\n ClrStructCntMBOM : %d\n",ClrStructCntMBOM);fflush(stdout);
				printf("\n F9X01StructCntMBOM : %d\n",F9X01StructCntMBOM);fflush(stdout);
				if((F9X01StructCntMBOM == ClrStructCntMBOM))
				{
					printf("\n inside compare the bom \n");fflush(stdout);
					fromToBomCompare_New(ChldMBOMStrutBlt,F9X01MBOMStrutBlt,ClrStructCntMBOM,&ToBeUpdatedCount);					
					printf("\n ToBeUpdatedCount %d\n",ToBeUpdatedCount);fflush(stdout);
				}
				else
				{
					printf("\n Not Comparing  ");fflush(stdout);
					ToBeUpdatedCount = 1;
				}	
				if(ToBeUpdatedCount == 0)
				{
					printf("\n Common F9X01 found : F9X01Number: %s\n" ,F9X01Number);fflush(stdout);
					*existingF9X01 = setOfF9X01Ptr;
					CommonFoundFlag = 1;
					break;
				}
			}
			if(CommonFoundFlag == 1)
				return 1;
			else
				return 0;
		}
		else
		return 0;
	}
}

int ChkPrtAlrdyAttachWithTask_F9X01(tag_t PartRev,char *TmpPlant)
{

	int   n_referencers				 = 0;
    int   *levels					 = 0;
    tag_t *	referencers;
	char ** relationsRef;
	int d=0;
	tag_t class_id = NULLTAG;
	char *class_name=NULL;
	char *ItemIDn =NULL;
	int CommonFoundFlag = 0;
	char *taskname = NULL;
    taskname = (char *)MEM_alloc(1 * sizeof(char *));

	printf("\n***** Inside ChkPrtAlrdyAttachWithTask_F9X01 Function ***** \n");fflush(stdout);

    autoresizestrAdd_F9X01(&taskname, "_40_");
    autoresizestrAdd_F9X01(&taskname, TmpPlant);
    printf("\n plant wise task name ...%s\n",taskname);


	ITK_CALL(WSOM_where_referenced2(PartRev,1,&n_referencers,&levels,&referencers,&relationsRef));
	printf("\n***** No of Parent objects are n_parents : %d\n",n_referencers);fflush(stdout);
	if (n_referencers>0)
	{
		for (d=0;d<n_referencers;d++)
		{
			 CommonFoundFlag =0;
			 POM_class_of_instance(referencers[d],&class_id);
			 POM_name_of_class(class_id,& class_name);
			 printf("\n Class name is : %s\n",class_name); fflush(stdout);
			 if(tc_strcmp(class_name,"T5_APLTaskRevision") == 0)
			 {
				 WSOM_ask_object_id_string(referencers[d],&ItemIDn);
			     printf("\n Item Id ==%s\n",ItemIDn);fflush(stdout);
				 if (tc_strstr(ItemIDn,taskname) != NULL)
				 {
					 printf("\n common task found.\n");fflush(stdout);
					 CommonFoundFlag =1;
					 break;

				 }

			 }
			 
		}
		if (CommonFoundFlag == 1)
		{
			return 1;
		}
	}

	return 0;
}

int GetAggregateBaseMapping_F9X01(char* Proj_Code)
{

	int k=0;
	int Flag=0;

	char* info2=NULL;
	char    *qry_entryCntrlformat[4]  = {"SYSCD","SUBSYSCD","Delete Indicator","Information-1"};	
	char	**qry_valuesCntrlformat= (char **) MEM_alloc(5 * sizeof(char *));
	tag_t   qryTagCntrlobj     = NULLTAG;
	int     n_entryCntrlobj    = 4;
	int controlObjfound=0;
	tag_t *list_of_cntrl_tags=NULLTAG;

	printf("\n\n\t\t inside GetAggregateBaseMapping_F9X01 func..[%s] ",Proj_Code);fflush(stdout);

			if(QRY_find2("Control Objects...", &qryTagCntrlobj));
			if (qryTagCntrlobj)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrlformat[0]="Aggregate";
				qry_valuesCntrlformat[1]="APLMapping";
				qry_valuesCntrlformat[2]="0";
				qry_valuesCntrlformat[3]="Live";
				
				if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	
			
			printf("\n controlObjfound is : %d\n",controlObjfound);fflush(stdout);

			if(controlObjfound>0)
			{
				for(k=0;k<controlObjfound;k++)
				{
					 AOM_ask_value_string( list_of_cntrl_tags[k], "t5_Userinfo2", &info2);
					 printf("\n info2: %s\n",info2);fflush(stdout);

					 if(strcmp(info2,Proj_Code)==0)
					{
						Flag=1;
						break;
					}
				}
			}

		
		printf("\n\n\t\t Flag =:[%d]",Flag);fflush(stdout);
			return Flag;

}

void  GetAggregateFromERCDML_F9X01( char * Task_no ,char  Aggregt[40])
{
    printf( "Task_no:%s\n", Task_no);fflush(stdout);

	char *item_idCpy =NULL;
	char *revStr =NULL;
	char *tmpStr =NULL;
	char *revStr1 =NULL;
	item_idCpy	=	(char *)MEM_alloc(50);

	tc_strcpy(item_idCpy,Task_no);

	printf( "item_idCpy:%s\n", item_idCpy);fflush(stdout);

	if(strlen(item_idCpy)>0)
	{
		char	*ERCDMLNo				=	NULL;
		ERCDMLNo	=	subString_F9X01(item_idCpy,0,10);
		printf( " \n ERCDMLNo :%s\n", ERCDMLNo);fflush(stdout);

			char  AllAggregate[500];
			char    *qry_entryCntrlformat[2]  = {"Type","Item ID"};	
			char	**qry_valuesCntrlformat= (char **) MEM_alloc(5 * sizeof(char *));
			tag_t   qryTagCntrlobj     = NULLTAG;
			int     n_entryCntrlobj    = 2;
			int controlObjfound=0;
			tag_t *list_of_cntrl_tags=NULLTAG;

			if(QRY_find2("Item Revision...", &qryTagCntrlobj));
			if (qryTagCntrlobj)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrlformat[0]="ERC DML Revision";
				qry_valuesCntrlformat[1]=ERCDMLNo;

				
				if(QRY_execute(qryTagCntrlobj, n_entryCntrlobj, qry_entryCntrlformat, qry_valuesCntrlformat, &controlObjfound, &list_of_cntrl_tags));
			}
			else
			{
				printf("\n Item Revision... Query not Found \n");fflush(stdout);
			}	
			
			printf("\n ERC Setsize is : %d\n",controlObjfound);fflush(stdout);


			if(controlObjfound>0)
			{
					char **AggregateList;
					int AggrCount=0;
					int i=0;
			
					tc_strcpy(AllAggregate,"");

					AOM_ask_value_strings(list_of_cntrl_tags[0],"t5_ERCAggregate",&AggrCount,&AggregateList);
					//AOM_ask_value_strings(list_of_cntrl_tags[0],"t5_crdesigngroup",&AggrCount,&AggregateList);

					for(i=0;i<AggrCount;i++)
					{
						printf("\n AggregateList[i] is : %s\n",AggregateList[i]);fflush(stdout);
					
						tc_strcat(AllAggregate,AggregateList[i]);
						tc_strcat(AllAggregate,",");
					}
			}

			printf("\n tc_strlen(AllAggregate) is : %d\n",tc_strlen(AllAggregate));fflush(stdout);
			printf("\n AllAggregate is : %s\n",AllAggregate);fflush(stdout);

			if(strstr(AllAggregate,",")!=NULL)
			{
					if(strcmp(AllAggregate,"BIW,")==0)
					{
						tc_strcpy(Aggregt,"BIW");
				
					}

					else if( strstr(AllAggregate,"BIW")!=NULL )
						{
							if(strstr(AllAggregate,"Mechanism")!=NULL || strstr(AllAggregate,"Trim")!=NULL || strstr(AllAggregate,"Chassis")!=NULL || strstr(AllAggregate,"E&E")!=NULL || strstr(AllAggregate,"PT")!=NULL  )
								{
									tc_strcpy(Aggregt,"BIWTCF");
								}
						}
			}
	}

}

void  GetProjectUserAccessDetails_F9X01( char  *Projj , char  *UsrId ,int *Gmcnt ,tag_t	**GmFound)
{
	int		n_entries = 2;
	int		countt=0;

	char	*qry_entries[2] = {"Project ID","Id"};
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	tag_t	queryTag   = NULLTAG;

	 char *Object_Name  =  NULL;



	printf( "Projj:%s\n", Projj);fflush(stdout);
	printf( "UsrId:%s\n", UsrId);fflush(stdout);
	 

				if(QRY_find2("ProjectUserAccessDet", &queryTag));
				printf("\n MT:After Prd_Project: QRY_find2");fflush(stdout);
				if (queryTag)
				{
					printf("\n MT:Found Query");fflush(stdout);
				}
				else
				{
					printf("\n MT:Not Found Query");fflush(stdout);
				}

				qry_values[0] = Projj;
				qry_values[1] = UsrId;

				if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, Gmcnt, GmFound));
				printf("\n MT: Gmcnt : %d\n", *Gmcnt); fflush(stdout);

		//                for(countt==0;countt<*Gmcnt;countt++)
		//				{
		//						Object_Name  =  NULL;
		//						ITK_CALL(AOM_UIF_ask_value(GmFound[countt],"object_string", &Object_Name));	
		//						printf("\n %s",Object_Name);fflush(stdout);
		//				}

}



int AssignAPLPlanner_F9X01(tag_t APLTaskRevT,char*	Proj_Code)
{
	char*			Task_no				= NULL;
	//char*			Dsgn_Grp			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	//char*			rolename			= NULL;
	char*			userid				= NULL;
	char*			rolename            = NULL;
	//char				userid[SA_user_size_c+1];
	int   ifail				= 0;
	char*			PLT_CodeS		= NULL;


	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;
	tag_t			role_tag		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;

	//logical			flgRoleFnd			= false;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	// Added by Dhanashri for Projectwise Mapping

				char  Projj[40];
				int Gmcnt1=0;
				int ProjectAccessFound=0;
				int FlaggAssignPlanner=0;
				int countt=0;
				int b=0;
				int z=0;
				tag_t	*GmFound1 = NULLTAG;
				char *Object_Name  =  NULL;

	// Added by Dhanashri for Projectwise Mapping

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;
	 char Aggregt[40];
	
	// Ketan Added
	char* Temp_Dsgn_No	= NULL;
	char* Temp_Task_no	= NULL;

	int max_char_size = 80;
	Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//
	
	printf("\n Inside AssignAPLPlanner_F9X01 \n");

	ITK_CALL(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	//ITK_CALL(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	//ITK_CALL(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignAPLPlanner_F9X01:Task_no  is :%s",Task_no);	fflush(stdout);
	//printf("\n\n\t\t APL DML Cre:AssignAPLPlanner_F9X01:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	tc_strcpy(Temp_Task_no,Task_no);
	printf("\n Ketan for APL Planner Temp_Task_no :%s",Temp_Task_no);	fflush(stdout);
	printf("\n\n\t\t APL DML Cre:AssignAPLPlanner_F9X01:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);fflush(stdout);
	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));

	// Ketan Added for MBOM 

	//if(tc_strstr(Temp_Task_no,"MB_")!=NULL)
	if((tc_strstr(Temp_Task_no,"MB_")!=NULL)||(tc_strstr(Temp_Task_no,"MM_")!=NULL))
	{
		printf("\n Inside MB_/MM_ Task for APL Planner\n");
		
		Temp_Dsgn_No=(char *) MEM_alloc(100 * sizeof(char *));

		printf("\n Before Dsgn_No ==> %s\n",Dsgn_No);
		tc_strcpy(Temp_Dsgn_No,Dsgn_No);
		
		Dsgn_No = subString_F9X01(Temp_Dsgn_No,0,2);
		printf("\n After Dsgn_No ==> %s\n",Dsgn_No);  
		
	}
	
	//**********************TZ1.46**********************************//
	if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLPltInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{				
				AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo8", &PltCodeFrmCntrl);
				printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
				tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);					
			}
			else
				{
				tc_strcpy(PLT_CodeS,"PUNE");
				}
				printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
	//****************************************************************************//

	
//	if(tc_strcmp(PLT_Code,"APLP")==0)
//    {
//	tc_strcpy(PLT_CodeS,"PUNE");
//	}else
//	if(tc_strcmp(PLT_Code,"APLV")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UV");
//	}else
//	if(tc_strcmp(PLT_Code,"APLD")==0)
//	{
//	tc_strcpy(PLT_CodeS,"DWD");
//	}else
//	if(tc_strcmp(PLT_Code,"APLC")==0)
//	{
//	tc_strcpy(PLT_CodeS,"CAR");
//	}else
//	if(tc_strcmp(PLT_Code,"APLJ")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JSR");
//	}else
//	if(tc_strcmp(PLT_Code,"APLL")==0)
//	{
//	tc_strcpy(PLT_CodeS,"LKO");
//	}else
//	if(tc_strcmp(PLT_Code,"APLA")==0)
//	{
//	tc_strcpy(PLT_CodeS,"AHD");
//	}else
//	if(tc_strcmp(PLT_Code,"APLU")==0)
//	{
//	tc_strcpy(PLT_CodeS,"UTK");
//	}else
//	if(tc_strcmp(PLT_Code,"APLS")==0)
//	{
//	tc_strcpy(PLT_CodeS,"JDL");
//	}else
//	{
//	tc_strcpy(PLT_CodeS,"PUNE");
//	}


// Added By Dhanashri for projectwise mapping// 

					APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
					tc_strcpy(APL_Plnr_Grp,"APL");
					tc_strcat(APL_Plnr_Grp,PLT_CodeS);


				tc_strcpy(Projj,Proj_Code);
				printf("\n Projj :[%s]\n",Projj);fflush(stdout);
				//Aggregate Base mapping
				int FlagAggregateBaseMapping=0;
				FlagAggregateBaseMapping=GetAggregateBaseMapping_F9X01(Proj_Code);
				printf("\n FlagAggregateBaseMapping :[%d]\n",FlagAggregateBaseMapping);fflush(stdout);
				if(FlagAggregateBaseMapping==1)
				{
					GetAggregateFromERCDML_F9X01(Task_no,Aggregt);
				}
			printf("\n Aggregt: %s \n",Aggregt);fflush(stdout);
			printf("\n length Aggregt: %d \n",strlen(Aggregt));fflush(stdout);
			//End Aggregate Base mapping

// End Of code Added By Dhanashri for projectwise mapping// 
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);


	ITK_CALL(SA_find_group(APL_Plnr_Grp,&group_tag));
	 if (group_tag != NULLTAG)
	ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
	//flgRoleFnd=false;
	if(num_of_roles>0)
	{
		FlaggAssignPlanner=0; // by dss for projectwise mapping.

		//Aggregate Base mapping
		if( FlagAggregateBaseMapping==1 && strstr(Aggregt,"BIW")!=NULL )
		{
				char RoleToassign[50];
				tc_strcpy(RoleToassign,Aggregt);
				tc_strcat(RoleToassign,"_");
				printf("\n RoleToassign : %s\n",RoleToassign);fflush(stdout);

				
				for (i=0;i<num_of_roles ;i++ )
				{
						ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
						printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
						//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
						printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);

						if(strstr(rolename,"APL") && strstr(rolename,RoleToassign) && strstr(rolename,"Planner") && strstr(rolename,"Default")==NULL ) 
						{
									printf("\nMatch Found\n");fflush(stdout);
									role_tag = role_tags[i];
									ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
									printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
									if(num_of_members>0)
									{
										for (j=0;j<num_of_members ;j++  )
										{
											ITK_CALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
											ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
											printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
										
											// Added by Dhanashri for projectwise mapping//
											ProjectAccessFound=0;
											Gmcnt1=0;
											GmFound1 = NULLTAG;
											GetProjectUserAccessDetails_F9X01(Projj,userid,&Gmcnt1,&GmFound1);
											printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
											
											countt=0;
											for(countt==0;countt<Gmcnt1;countt++)
											{
													Object_Name  =  NULL;
													ITK_CALL(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
													printf("\n after func :  %s",Object_Name);fflush(stdout);
												
													if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,RoleToassign) && strstr(Object_Name,"Planner") && strstr(Object_Name,"Default")==NULL) 
													{
														printf("\n Condition Satisfy... ");fflush(stdout);
														ProjectAccessFound=1;
														break;
													}
											}
											printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
											// Added by Dhanashri for projectwise mapping//
											
											if(ProjectAccessFound==1)
											{
												TCTYPE_find_type("Analyst", "Analyst", &participant_type);
												EPM_create_participant(member_tags[j], participant_type, &participant_tag);
												GRM_find_relation_type("HasParticipant", &relation_type);
												GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
												GRM_save_relation(relation);
												printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
												FlaggAssignPlanner=1;
												//break;
											}
										}
									}

							
							if(FlaggAssignPlanner==1)
							{
								break;
							}
						}// Role matches  
					}	
		}
		//End of aggregate mapping
printf("\n hi FlaggAssignPlanner : [%d]\n",FlaggAssignPlanner);fflush(stdout);
if(FlaggAssignPlanner==0)
	{
		for (i=0;i<num_of_roles ;i++ )
		{
				ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
				printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
				//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
				printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);

				//if(strstr(rolename,"APL") && strstr(rolename,Dsgn_Grp) && strstr(rolename,"Planner"))
				if(strstr(rolename,"APL") && strstr(rolename,Dsgn_No) && strstr(rolename,"Planner") && strstr(rolename,"Default")==NULL ) 
				{
							printf("\nMatch Found\n");fflush(stdout);
							role_tag = role_tags[i];
							ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
							printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
							if(num_of_members>0)
							{
								for (j=0;j<num_of_members ;j++  )
								{
									ITK_CALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
									ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
									printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);
								
									// Added by Dhanashri for projectwise mapping//
									ProjectAccessFound=0;
									Gmcnt1=0;
									GmFound1 = NULLTAG;
									GetProjectUserAccessDetails_F9X01(Projj,userid,&Gmcnt1,&GmFound1);
									printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
									
									countt=0;
									for(countt==0;countt<Gmcnt1;countt++)
									{
											Object_Name  =  NULL;
											ITK_CALL(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
											printf("\n after func :  %s",Object_Name);fflush(stdout);
										
											if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Planner") && strstr(Object_Name,"Default")==NULL) 
											{
												printf("\n Condition Satisfy... ");fflush(stdout);
												ProjectAccessFound=1;
												break;
											}
									}
									printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
									// Added by Dhanashri for projectwise mapping//
									
									if(ProjectAccessFound==1)
									{
										TCTYPE_find_type("Analyst", "Analyst", &participant_type);
										EPM_create_participant(member_tags[j], participant_type, &participant_tag);
										GRM_find_relation_type("HasParticipant", &relation_type);
										GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
										GRM_save_relation(relation);
										printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
										FlaggAssignPlanner=1;
										//break;
									}
								}
							}

					
					if(FlaggAssignPlanner==1)
					{
						break;
					}
				}// Role matches  
		}
	}
		printf("\n FlaggAssignPlanner: %d \n",FlaggAssignPlanner);fflush(stdout);

		if(FlaggAssignPlanner==0)
		{
			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"APL");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				ITK_CALL(SA_ask_role_name2(role_tags[z],&rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					ITK_CALL(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;
						for (b=0;b<num_of_members ;b++  )
						{
							ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
							ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("Analyst", "Analyst", &participant_type);
							EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n APL Planner Assigned..to : [%s]\n",userid);fflush(stdout);
							
						}
					}

				}


			}

		}        
	

	} // if(num_of_roles>0)

	return ITK_ok;
}


int AssignAPLReviewer_F9X01(tag_t APLTaskRevT,char*		Proj_Code)
{
	char*			Task_no				= NULL;
	//char*			Dsgn_Grp			= NULL;
//	char*			Proj_Code			= NULL;
	char*			Dsgn_No				= NULL;
	char*			PLT_Code			= NULL;
	char*			APL_Plnr_Grp		= NULL;
	//char*			rolename			= NULL;
	//char*			userid				= NULL;
	char*			rolename = NULL;
	char*				userid = NULL;
	int   ifail				= 0;
	char*			PLT_CodeS		= NULL;

	tag_t			group_tag			= NULLTAG;
	tag_t			user_tag			= NULLTAG;
	tag_t			relation			= NULLTAG;
	tag_t			participant_type	= NULLTAG;
	tag_t			participant_tag		= NULLTAG;
	tag_t			relation_type		= NULLTAG;

	tag_t*			role_tags			= NULLTAG;
	tag_t			role_tag			= NULLTAG;
	tag_t*			member_tags			= NULLTAG;

	int				num_of_roles		= 0;
	int				num_of_members		= 0;
	int				i					= 0;
	int				j					= 0;
	char Aggregt[40];
	//logical			flgRoleFnd			= false;

	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(5 * sizeof(char *));

	// Added by Dhanashri for Projectwise Mapping
				char  Projj[40];
				int Gmcnt1=0;
				int ProjectAccessFound=0;
				int FlaggAssignReviewer=0;
				int countt=0;
				int b=0;
				int z=0;
				tag_t	*GmFound1 = NULLTAG;
				char *Object_Name  =  NULL;

	// Added by Dhanashri for Projectwise Mapping

	 int cntrlcnt=0;
	 int  control_number_found1=0;

	 tag_t *list_of_WSO_cntrl_tags1=NULLTAG;

	 tag_t   qryTagCntrl1     = NULLTAG;
	 int     n_entryCntrl1    = 3;
	 char *PltCodeFrmCntrl 	  = NULL;

	// Ketan Added
	char* Temp_Dsgn_No		= NULL;
	char* Temp_Task_no		= NULL;

	int max_char_size = 80;
	Temp_Task_no = (char *)MEM_alloc(max_char_size * sizeof(char));
	//


	printf("\n Inside AssignAPLReviewer_F9X01  \n");fflush(stdout);

	ITK_CALL(AOM_ask_value_string(APLTaskRevT,"item_id",&Task_no));
	//ITK_CALL(AOM_ask_value_string(APLTaskRevT,"t5_crdesigngroup",&Dsgn_Grp));
	//ITK_CALL(AOM_ask_value_string(APLTaskRevT,"t5_cprojectcode",&Proj_Code));
	printf("\n\n\t\t APL DML Cre:AssignAPLReviewer_F9X01:Task_no  is :%s",Task_no);	fflush(stdout);

	tc_strcpy(Temp_Task_no,Task_no);
	printf("\n Ketan for APL Reviewer Temp_Task_no:%s",Temp_Task_no);	fflush(stdout);

	//printf("\n\n\t\t APL DML Cre:AssignAPLReviewer_F9X01:Dsgn_Grp  is :%s",Dsgn_Grp);	fflush(stdout);
	//printf("\n\n\t\t APL DML Cre:AssignAPLReviewer_F9X01:Proj_Code  is :%s",Proj_Code);	fflush(stdout);

	Dsgn_No=tc_strtok(Task_no,"_");
	printf("\nTest0.11..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	Dsgn_No = tc_strtok(NULL,"_");
	printf("\nTest0.12..Dsgn_No:[%s],[%s]\n",Dsgn_No,Task_no);fflush(stdout);
	PLT_Code = tc_strtok(NULL,"_");
	printf("\nTest0.13..PLT_Code:[%s],[%s]\n",PLT_Code,Task_no);fflush(stdout);

	PLT_CodeS=(char *) MEM_alloc(100 * sizeof(char *));
	//****************************TZ1.46****************************************//

	// Ketan Added for MBOM 

	//if(tc_strstr(Temp_Task_no,"MB_")!=NULL)
	if((tc_strstr(Temp_Task_no,"MB_")!=NULL)||(tc_strstr(Temp_Task_no,"MM_")!=NULL))
	{
		printf("\n Inside MB_/MM_ Task for APL Reviewer  \n");
		
		Temp_Dsgn_No=(char *) MEM_alloc(100 * sizeof(char *));

		printf("\n Before Dsgn_No ==> %s\n",Dsgn_No);
		tc_strcpy(Temp_Dsgn_No,Dsgn_No);
		
		Dsgn_No = subString_F9X01(Temp_Dsgn_No,0,2);
		printf("\n After Dsgn_No ==> %s\n",Dsgn_No);  
		
	}

			if(QRY_find2("Control Objects...", &qryTagCntrl1));
			if (qryTagCntrl1)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrl1[0]="APLPltInf";
				qry_valuesCntrl1[1]=PLT_Code;
				qry_valuesCntrl1[2]="0";
				
				if(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
			}
			else
			{
				printf("\n Control Object Query not Found for GM DML \n");fflush(stdout);
			}	
			
			printf("\n control_number_found1 is : %d\n",control_number_found1);fflush(stdout);

			if(control_number_found1>0)
			{
				for(cntrlcnt=0;cntrlcnt<control_number_found1;cntrlcnt++)
					{
						AOM_ask_value_string( list_of_WSO_cntrl_tags1[cntrlcnt], "t5_Userinfo8", &PltCodeFrmCntrl);
						printf("\n PltCodeFrmCntrl: %s\n",PltCodeFrmCntrl);fflush(stdout);
						tc_strcpy(PLT_CodeS,PltCodeFrmCntrl);
					}
			}
			else
				{
				tc_strcpy(PLT_CodeS,"PUNE");
				}
				printf("\n PLT_CodeS: %s\n",PLT_CodeS);fflush(stdout);
				//****************************************************************//
				//	if(tc_strcmp(PLT_Code,"APLP")==0)
				//    {
				//	tc_strcpy(PLT_CodeS,"PUNE");
				//	}else
				//	if(tc_strcmp(PLT_Code,"APLV")==0)
				//	{
				//	tc_strcpy(PLT_CodeS,"UV");
				//	}else
				//	if(tc_strcmp(PLT_Code,"APLD")==0)
				//	{
				//	tc_strcpy(PLT_CodeS,"DWD");
				//	}else
				//	if(tc_strcmp(PLT_Code,"APLC")==0)
				//	{
				//	tc_strcpy(PLT_CodeS,"CAR");
				//	}else
				//	if(tc_strcmp(PLT_Code,"APLJ")==0)
				//	{
				//	tc_strcpy(PLT_CodeS,"JSR");
				//	}else
				//	if(tc_strcmp(PLT_Code,"APLL")==0)
				//	{
				//	tc_strcpy(PLT_CodeS,"LKO");
				//	}else
				//	if(tc_strcmp(PLT_Code,"APLA")==0)
				//	{
				//	tc_strcpy(PLT_CodeS,"AHD");
				//	}else
				//	if(tc_strcmp(PLT_Code,"APLU")==0)
				//	{
				//	tc_strcpy(PLT_CodeS,"UTK");
				//	}else
				//	if(tc_strcmp(PLT_Code,"APLS")==0)
				//	{
				//	tc_strcpy(PLT_CodeS,"JDL");
				//	}else
				//	{
				//	tc_strcpy(PLT_CodeS,"PUNE");
				//	}

				// Added By Dhanashri for projectwise mapping// 

				APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
				tc_strcpy(APL_Plnr_Grp,"APL");
				tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			
				tc_strcpy(Projj,Proj_Code);
				printf("\n Projj :[%s]\n",Projj);fflush(stdout);
				//Aggregate Base mapping
				int FlagAggregateBaseMapping=0;
				FlagAggregateBaseMapping=GetAggregateBaseMapping_F9X01(Proj_Code);
				printf("\n FlagAggregateBaseMapping :[%d]\n",FlagAggregateBaseMapping);fflush(stdout);
				if(FlagAggregateBaseMapping==1)
				{
					GetAggregateFromERCDML_F9X01(Task_no,Aggregt);
				}
				printf("\n Aggregt: %s \n",Aggregt);fflush(stdout);
				printf("\n length Aggregt: %d \n",strlen(Aggregt));fflush(stdout);
				//End Aggregate Base mapping

// End Of code Added By Dhanashri for projectwise mapping// 
	printf("\nTest0.14..Planner Group Name:[%s]\n",APL_Plnr_Grp);fflush(stdout);


	ITK_CALL(SA_find_group(APL_Plnr_Grp,&group_tag));

	 if (group_tag != NULLTAG)
	ITK_CALL(SA_ask_roles_from_group(group_tag,&num_of_roles,&role_tags  ));

	printf("\nNo of Role found in Group are :%d\n",num_of_roles);fflush(stdout);
	//flgRoleFnd=false;
	if(num_of_roles>0)
	{
		FlaggAssignReviewer=0; // by dss for projectwise mapping.

		//Aggregate Base mapping
		if( FlagAggregateBaseMapping==1 && strstr(Aggregt,"BIW")!=NULL )
		{
				char RoleToassign[50];
				tc_strcpy(RoleToassign,Aggregt);
				tc_strcat(RoleToassign,"_");
				printf("\n RoleToassign : %s\n",RoleToassign);fflush(stdout);

				for (i=0;i<num_of_roles ;i++ )
				{
						ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
						printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
						//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
						 printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);
						
						if(strstr(rolename,"APL") && strstr(rolename,RoleToassign) && strstr(rolename,"Reviewer") && strstr(rolename,"Default")==NULL )
						{
							printf("\nMatch Found\n");fflush(stdout);

									role_tag = role_tags[i];
									ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
									printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
									if(num_of_members>0)
									{
										for (j=0;j<num_of_members ;j++  )
										{
											ITK_CALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
											ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
											printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);

											// Added by Dhanashri for projectwise mapping//
											ProjectAccessFound=0;
											Gmcnt1=0;
											GmFound1 = NULLTAG;
											GetProjectUserAccessDetails_F9X01(Projj,userid,&Gmcnt1,&GmFound1);
											printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
											
											countt=0;
											for(countt==0;countt<Gmcnt1;countt++)
											{
													Object_Name  =  NULL;
													ITK_CALL(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
													printf("\n after func :  %s",Object_Name);fflush(stdout);
												
													if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,RoleToassign) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) 
													{
														printf("\n Condition Satisfy... ");fflush(stdout);
														ProjectAccessFound=1;
														break;
													}
											}
											printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
											// Added by Dhanashri for projectwise mapping//

											if(ProjectAccessFound==1)
											{
												TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
												EPM_create_participant(member_tags[j], participant_type, &participant_tag);
												GRM_find_relation_type("HasParticipant", &relation_type);
												GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
												GRM_save_relation(relation);
												printf("\n APL Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);
												FlaggAssignReviewer=1;
											}

										}
									}
								
							if(FlaggAssignReviewer==1)
							{
								break;
							}
						}  // Roll matches
				}
		}
		//Aggregate Base mapping
printf("\n hi FlaggAssignReviewer : [%d]\n",FlaggAssignReviewer);fflush(stdout);

if(FlaggAssignReviewer==0)
{
	for (i=0;i<num_of_roles ;i++ )
	{
		ITK_CALL(SA_ask_role_name2(role_tags[i],&rolename));
		printf("\nRol Name :[%d][%s]\n",i,rolename);fflush(stdout);
		//printf("\n Dsgn_Grp [%s]\n",Dsgn_Grp);
			printf("\n Dsgn_No [%s]\n",Dsgn_No);fflush(stdout);
		//if(strstr(rolename,"APL") && strstr(rolename,Dsgn_Grp) && strstr(rolename,"Reviewer"))
		if(strstr(rolename,"APL") && strstr(rolename,Dsgn_No) && strstr(rolename,"Reviewer") && strstr(rolename,"Default")==NULL )
		{
			printf("\nMatch Found\n");fflush(stdout);

					role_tag = role_tags[i];
					ITK_CALL(SA_find_groupmember_by_role(role_tag,group_tag,&num_of_members,&member_tags));
					printf("\nNo of Group Members found in Group/Role are :%d\n",num_of_members);fflush(stdout);
					if(num_of_members>0)
					{
						for (j=0;j<num_of_members ;j++  )
						{
							ITK_CALL(SA_ask_groupmember_user(member_tags[j],&user_tag));
							ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
							printf("\nUser ID Name :[%s]\n",userid);fflush(stdout);

							// Added by Dhanashri for projectwise mapping//
							ProjectAccessFound=0;
							Gmcnt1=0;
							GmFound1 = NULLTAG;
							GetProjectUserAccessDetails_F9X01(Projj,userid,&Gmcnt1,&GmFound1);
							printf("\n Gmcnt1: %d \n",Gmcnt1);fflush(stdout);
							
							countt=0;
							for(countt==0;countt<Gmcnt1;countt++)
							{
									Object_Name  =  NULL;
									ITK_CALL(AOM_UIF_ask_value(GmFound1[countt],"object_string", &Object_Name));
									printf("\n after func :  %s",Object_Name);fflush(stdout);
								
									if(strstr(Object_Name,APL_Plnr_Grp) && strstr(Object_Name,Dsgn_No) && strstr(Object_Name,"Reviewer") && strstr(Object_Name,"Default")==NULL) 
									{
										printf("\n Condition Satisfy... ");fflush(stdout);
										ProjectAccessFound=1;
										break;
									}
							}
							printf("\n ProjectAccessFound:  %d",ProjectAccessFound);fflush(stdout);
							// Added by Dhanashri for projectwise mapping//

							if(ProjectAccessFound==1)
							{
								TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
								EPM_create_participant(member_tags[j], participant_type, &participant_tag);
								GRM_find_relation_type("HasParticipant", &relation_type);
								GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
								GRM_save_relation(relation);
								printf("\n APL Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);
								FlaggAssignReviewer=1;
							}

						}
					}
				
			if(FlaggAssignReviewer==1)
			{
				break;
			}
		}  // Roll matches
	}
}

		printf("\n FlaggAssignReviewer: %d \n",FlaggAssignReviewer);fflush(stdout);

		if(FlaggAssignReviewer==0)
		{
			APL_Plnr_Grp = NULL;
			APL_Plnr_Grp=(char *) MEM_alloc(100 * sizeof(char *));
			tc_strcpy(APL_Plnr_Grp,"APL");
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,PLT_CodeS);
			tc_strcat(APL_Plnr_Grp,"_");
			tc_strcat(APL_Plnr_Grp,"Default");
			printf("\n Test Planner Group Name:[%s]\n",APL_Plnr_Grp);
			z=0;
			for (z=0;z<num_of_roles ;z++ )
			{
				ITK_CALL(SA_ask_role_name2(role_tags[z],&rolename));
				printf("\nRol Name :[%d][%s]\n",z,rolename);
				if(strstr(rolename,APL_Plnr_Grp))
				{
					printf("\n Got Default Group");
					ITK_CALL(SA_find_groupmember_by_role(role_tags[z],group_tag,&num_of_members,&member_tags));
					printf("\n No of Group Members found in Group/Role are :%d\n",num_of_members);
					if(num_of_members>0)
					{
						b=0;	
						for (b=0;b<num_of_members ;b++)
						{
							ITK_CALL(SA_ask_groupmember_user(member_tags[b],&user_tag));
							ITK_CALL(SA_ask_user_identifier2(user_tag,&userid));
							printf("\nUser ID Name :[%s]\n",userid);
							TCTYPE_find_type("ChangeSpecialist1", "ChangeSpecialist1", &participant_type);
							EPM_create_participant(member_tags[b], participant_type, &participant_tag);
							GRM_find_relation_type("HasParticipant", &relation_type);
							GRM_create_relation(APLTaskRevT, participant_tag, relation_type,  NULLTAG, &relation);
							GRM_save_relation(relation);
							printf("\n APL Reviewer Assigned..to : [%s]\n",userid);fflush(stdout);
							
						}
					}

				}


			}

		}  



	}
	return ITK_ok;

	//printf("\n Inside AssignAPLReviewer_F9X01 \n");

	///return 0;
}


int createtask_attchedtoDML_F9X01(char* DML_ID,tag_t itemRev , char* tmpPlant,char* vehicleProject)
{
	printf("\n **********createtask_attchedtoDML_F9X01********");fflush(stdout);
	char* temp = NULL;
	temp = (char*)MEM_alloc(1*sizeof(char*));
	autoresizestrAdd_F9X01(&temp,DML_ID);
	autoresizestrAdd_F9X01(&temp,"_");
	autoresizestrAdd_F9X01(&temp,tmpPlant);
	printf("\n temp Found  : %d",temp);fflush(stdout);
	const char *attrs[1];
    const char *values[1];
	values[0] = temp;
	attrs[0] ="item_id";
	
	int 	 task_count		=0;
	int 	 part_count		=0;
	int      DML_count		=0; 
	int      Task_count		=0; 
	int 	 idml			=0;
	int 	 iTask			=0;
	
	//int    Task_rev_count		=0; 
	tag_t	 Tasktag				=NULLTAG;
	tag_t	 TaskRev				=NULLTAG;
	tag_t	 *taskItemTag			=NULLTAG;
	tag_t	 *parttag			=NULLTAG;
	tag_t  	 TasktoDMLrel			=NULLTAG;
	tag_t  	 PartRevTag			=NULLTAG;
	tag_t  	 TaskPartRel			=NULLTAG;
	tag_t	 *DMLTagt				=NULLTAG;
	tag_t	 *TaskTagt				=NULLTAG;
	tag_t	 TaskRevTagg			= NULLTAG;
	tag_t	 DMLRevTagg				= NULLTAG;
	tag_t	 DMLTypeTag				= NULLTAG;
	tag_t	 dmltaskRel				= NULLTAG;
	tag_t	 taskpartREL				= NULLTAG;
	tag_t	 taskpartRel				= NULLTAG;
	tag_t	 taskpartRelation				= NULLTAG;
	tag_t	 latestrev				= NULLTAG;
	tag_t	 isltstDML				= NULLTAG;
	
	char	*DMLNumberr				= NULL;
	char	*ftaskname					= NULL;
	ftaskname = (char*)MEM_alloc(1*sizeof(char*));
	
	//tag_t	*Task_rev_tag	=NULLTAG;
	
		ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs,values,&DML_count, &DMLTagt));
		printf("\n DMLTagt Found  : %d",DML_count);fflush(stdout);
		if(DML_count>0)
		{
			ITK_CALL(ITEM_ask_latest_rev(DMLTagt[0],&isltstDML));
			if(isltstDML !=NULLTAG)
			{
				printf("\n\t Latest DML rev is  Found .....\n");fflush(stdout);
			}
			ITK_CALL(AOM_ask_value_string(isltstDML, "item_id", &DMLNumberr));
			printf("\n Current DML id is : %s",DMLNumberr);fflush(stdout);
		}
 		tag_t	APLTTypeTag			= NULLTAG;
		tag_t	APLTCreInTag		= NULLTAG;
		tag_t	APLTRevTypeTag		= NULLTAG;
		tag_t	APLTRevCreInTag		= NULLTAG;
		tag_t	APLTaskTag			= NULLTAG;
		tag_t 	APLTaskRevTag	    = NULLTAG;
		int		n_strings			= 1;
		int		l_strings		  	= 500;
		int		index			  	= 0;
		char**	stringArrayAPLT	  	= NULL;
		char*	tempStringt1		= NULL;
		
		autoresizestrAdd_F9X01(&ftaskname,DML_ID);
		if(tc_strcmp(tmpPlant,"APLP")==0)
		{
			autoresizestrAdd_F9X01(&ftaskname,"_40_");
		}
		else 
		{
			autoresizestrAdd_F9X01(&ftaskname,"_40_");
		}
		autoresizestrAdd_F9X01(&ftaskname,tmpPlant);
		printf("\t setting Object Name object_name ...%s\n", ftaskname);fflush(stdout);
		const char *values2[1];
		values2[0] = ftaskname;
		ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs,values2,&Task_count, &TaskTagt));
		printf("\n Task_count Found  : %d",Task_count);fflush(stdout);
		if(Task_count ==0)
		{
			stringArrayAPLT = (char**)malloc( n_strings * sizeof *stringArrayAPLT );
			for( index=0; index<n_strings; index++ )
			{
				stringArrayAPLT[index] = (char*)malloc( l_strings + 1 );
			}
			
			ITK_CALL( TCTYPE_find_type("T5_APLTask", NULL, &APLTTypeTag) );//T5_APLTask
			ITK_CALL( TCTYPE_construct_create_input( APLTTypeTag, &APLTCreInTag) );

			ITK_CALL( TCTYPE_find_type("T5_APLTaskRevision", NULL, &APLTRevTypeTag) );//T5_APLTaskRevision
			ITK_CALL( TCTYPE_construct_create_input( APLTRevTypeTag, &APLTRevCreInTag) );
			tc_strcpy( stringArrayAPLT[0], ftaskname);
			ITK_CALL( TCTYPE_set_create_display_value( APLTCreInTag, "item_id", 1,(const char**)stringArrayAPLT) );

			tc_strcpy( stringArrayAPLT[0], ftaskname);
			printf("\t setting Object Name object_name ...%s\n", ftaskname);fflush(stdout);
			ITK_CALL( TCTYPE_set_create_display_value( APLTCreInTag, "object_name", 1,(const char**)stringArrayAPLT) );
			
			tc_strcpy( stringArrayAPLT[0], "F9X01 Task");
			ITK_CALL( TCTYPE_set_create_display_value( APLTCreInTag, "object_desc", 1,(const char**)stringArrayAPLT) );
			
			ITK_CALL( AOM_tag_to_string(APLTRevCreInTag, &tempStringt1) );
			tc_strcpy( stringArrayAPLT[0], tempStringt1);
			printf("\nTest..'%s'\n",stringArrayAPLT[0]);fflush(stdout);
			ITK_CALL( TCTYPE_set_create_display_value( APLTCreInTag, "revision", 1,(const char**) stringArrayAPLT) );
			tc_strcpy( stringArrayAPLT[0], "A");
			ITK_CALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "item_revision_id", 1,(const char**)stringArrayAPLT) );
			printf("\n Value to set in apl_task_number :%s\n",ftaskname);fflush(stdout);
			tc_strcpy( stringArrayAPLT[0], vehicleProject);
			printf("\t setting project code t5_cprojectcode ...%s\n", stringArrayAPLT[0]);fflush(stdout);
			ITK_CALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_cprojectcode", 1,(const char**)stringArrayAPLT) );
			
			if(tc_strcmp(tmpPlant,"APLP")==0)
			{
				tc_strcpy( stringArrayAPLT[0], "40");
			}
			else 
			{
				tc_strcpy( stringArrayAPLT[0], "40");
			}
			ITK_CALL( TCTYPE_set_create_display_value( APLTRevCreInTag, "t5_crdesigngroup", 1,(const char**)stringArrayAPLT) );
			ITK_CALL( TCTYPE_create_object( APLTCreInTag, &APLTaskTag) );
			ITK_CALL( AOM_save_without_extensions(APLTaskTag));
			ITK_CALL(ITEM_ask_latest_rev(APLTaskTag,&APLTaskRevTag));
			printf("\nSave APL TASK ITEM AND REV\n");fflush(stdout);
			AOM_save_without_extensions(APLTaskTag);
			AOM_save_without_extensions(APLTaskRevTag);
			if (APLTaskTag!=NULLTAG)
			{
				printf("\nTASK ITEM IS CREATED\n");fflush(stdout);
			}
			else
			{
				printf("\nTASK ITEM IS NOT CREATED\n");fflush(stdout);
			}
			if (APLTaskRevTag!=NULLTAG)
			{
				printf("\nTASK ITEM REV IS CREATED\n");fflush(stdout);
			}
			else
			{
				printf("\nTASK ITEM REV IS NOT CREATED\n");fflush(stdout);
			}
			//Create task relation with Dml
			ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&TasktoDMLrel));
			if (TasktoDMLrel!=NULLTAG)
			{
				ITK_CALL(GRM_create_relation(isltstDML,APLTaskRevTag,TasktoDMLrel,NULLTAG,&dmltaskRel));
				if(dmltaskRel==NULLTAG)
				{
					printf("\n dmltaskRel does not exist");fflush(stdout);
				}
				else
				{
					ITK_CALL(GRM_save_relation(dmltaskRel));
					printf("\n\t TAsk to Dml relation created");fflush(stdout);
				}
			}
		}
		else
		{
			ITK_CALL(ITEM_ask_latest_rev(TaskTagt[0],&APLTaskRevTag));
			if(APLTaskRevTag !=NULLTAG)
			{
				printf("\n\t Latest APLTaskRevTag rev is  Found .....\n");fflush(stdout);
			}
		}
		
		//attached part in task into solution 
		ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&TaskPartRel));
		ITK_CALL(GRM_create_relation(APLTaskRevTag,itemRev,TaskPartRel,NULLTAG,&taskpartRelation));
		if(taskpartRelation==NULLTAG)
		{
			printf("\n part task rel does not exist");fflush(stdout);
		}
		else
		{
			ITK_CALL(GRM_save_relation(taskpartRelation));
			printf("\n\t TAsk to part relation created");fflush(stdout);
		}
		
		if(Task_count ==0)
		{
			//create analyst and reviewer before submitting the task in WF
			AssignAPLPlanner_F9X01(APLTaskRevTag,vehicleProject);
			AssignAPLReviewer_F9X01(APLTaskRevTag,vehicleProject);
			
			printf("\n\n\n******************** INSIDE Workflow initiated on Created Task    *********************\n\n\n");fflush(stdout);
			/*tag_t process_temp;
			tag_t new_process;
			tag_t new_processDML;
			tag_t new_processPART;
			int attachment_type = 1;
			ITK_CALL(EPM_find_template2("APL Task BreakDown",0,&process_temp));
			if (process_temp != NULLTAG)
			{
				printf("\n\n\t process found successfully.........");fflush(stdout);
				ITK_CALL(EPM_create_process("Tyre Resstructuring Process","", process_temp, 1, &APLTaskRevTag, &attachment_type, &new_process));
				if (new_process != NULLTAG)
				{
					printf("\n\n\t process successfully initiated on task \n");fflush(stdout);
				} 	
			}
			else
			{
				printf("\n\n\t process NOT found ");fflush(stdout);
			}
			*/
			tag_t tSubProcessTag = NULLTAG;
			char* TaskTagRevName = NULL;
			int attachmentType[] = { EPM_target_attachment };
			tag_t tSubProcess = NULLTAG;
			tag_t tJob		 = NULLTAG;
			tag_t tSubRootTask = NULLTAG;

			int nCRItem=0;
			tag_t *CRitem_revs_tag = NULLTAG;
			int s=0;
			tag_t process_tag =NULLTAG;
			char *TaskTagRevName1 =NULL;
			tag_t job_tag =NULLTAG;

			ITK_CALL(AOM_ask_value_tags(isltstDML, "fnd0StartedWorkflowTasks", &nCRItem, &CRitem_revs_tag));
			printf("\nNo of CHild Item revisions : %d", nCRItem);fflush(stdout);
			for (s=0;s<nCRItem ;s++ )
			{
				process_tag =CRitem_revs_tag[s];
				ITK_CALL(AOM_ask_value_string(process_tag,"object_string",&TaskTagRevName1));
				printf("\n TaskTagRevName1 : %s", TaskTagRevName1);fflush(stdout);
				if (tc_strcmp(TaskTagRevName1, "APL Task BreakDown") == 0)
				{
					printf("\n WF Test 0\n");fflush(stdout);
					job_tag =CRitem_revs_tag[s];
				}
			}			
			printf("\n WF Test 1\n");fflush(stdout);
			ITK_CALL(EPM_find_process_template("APL Task BreakDown", &tSubProcessTag));
			
			printf("\n WF Test 2\n");fflush(stdout);
			ITK_CALL(AOM_ask_value_string(APLTaskRevTag,"object_string",&TaskTagRevName));
			ITK_CALL(EPM_create_process_deferred_start(TaskTagRevName, "APL Task BreakDown", tSubProcessTag, 1, &APLTaskRevTag, attachmentType, &tSubProcess));
			
			printf("\n WF Test 3\n");fflush(stdout);
			ITK_CALL(EPM_ask_job(job_tag, &tJob));

			ITK_CALL(EPM_attach_sub_processes(tJob, 1, &tSubProcess)); //attach sub-workflow with parent process
			printf("\n WF Test 4\n");fflush(stdout);
			
			//get the sub process root task 
			ITK_CALL(EPM_ask_root_task(tSubProcess, &tSubRootTask));
			printf("\n WF Test 5\n");fflush(stdout);

			int iSubTarget = EPM_interprocess_task_attachment;				
			ITK_CALL(EPM_add_attachments(job_tag, 1, &tSubRootTask, &iSubTarget));  //add attachment to sub-workflow root task
			ITK_CALL(EPM_trigger_action(tSubRootTask, EPM_complete_action, "sub-workflow")); // trigger the sub-workflow.				
			printf("\n 40 Design group task submission End... \n");fflush(stdout);
		}
		
	return ITK_ok;
}

tag_t createF9X01Part(tag_t vehicle ,char* partNumber , char* Rev, char* projectCode,char* vehicleDrAr)
{
	printf("\n*****createF9X01Part***********\n");fflush(stdout);
	tag_t item_type_tag = NULLTAG;
	tag_t itemRev_type_tag = NULLTAG;
	tag_t item_create_input_tag = NULLTAG;
	tag_t F9X01Mstr = NULLTAG;
	tag_t ItemRev1 = NULLTAG;
	tag_t itemRev_create_input_tag = NULLTAG;
	const char* irCreateInputTagUid[] = {0};
	ITK_CALL(TCTYPE_find_type("Design",  NULL, &item_type_tag));
	ITK_CALL(TCTYPE_find_type("Design Revision",NULL, &itemRev_type_tag));
	printf("\n partNumber :[%s]---Rev :[%s]",partNumber,Rev);fflush(stdout);
	ITK_CALL( TCTYPE_construct_create_input( item_type_tag, &item_create_input_tag) );
	ITK_CALL( TCTYPE_construct_create_input( itemRev_type_tag, &itemRev_create_input_tag) );
	//Set attributes of Design Master
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag, "object_name", partNumber));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag, "object_desc", "TYRE AND RIM ASSEMBLY- MFG"));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag, "item_revision_id", Rev));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag, "t5_ProjectCode", projectCode));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag, "t5_DesignGrp", "40"));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag,"t5_PartType","M"));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag,"t5_DocRemarks","NEW RELEASE"));
	//ITK_CALL( AOM_set_value_string(itemRev_create_input_tag,"t5_MThickness","NA"));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag,"t5_DsgnDept","Pune-Design"));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag,"t5_DsgnOwn","PROPUN"));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag,"t5_ColourInd","N"));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag,"t5_ModuleAddress","MF9X01"));
	//ITK_CALL( AOM_set_value_string(itemRev_create_input_tag,"t5_PrtCatCode","VEHICLE"));
	ITK_CALL( AOM_set_value_string(itemRev_create_input_tag,"t5_PartStatus",vehicleDrAr));
	
	ITK_CALL( AOM_set_value_string(item_create_input_tag, "item_id", partNumber));
	ITK_CALL( AOM_set_value_string(item_create_input_tag, "object_name", partNumber));
	ITK_CALL( AOM_set_value_string(item_create_input_tag, "object_desc", "TYRE AND RIM ASSEMBLY- MFG"));
	ITK_CALL( AOM_set_value_tag(item_create_input_tag, "revision",itemRev_create_input_tag));
	printf("\n Creating partNumber :[%s]---Rev :[%s]",partNumber,Rev);fflush(stdout);
	TCTYPE_create_object(item_create_input_tag, &F9X01Mstr);
	if(F9X01Mstr!=NULLTAG)
	{
		printf("\n Created partNumber :[%s]---Rev :[%s]",partNumber,Rev);fflush(stdout);

		AOM_save_without_extensions(F9X01Mstr);
	}
	//ITK_CALL ( ITEM_ask_latest_rev( F9X01Mstr, &ItemRev1 ));
	return F9X01Mstr;
	
	
}


char *CurrentViewMask_F9X01(char *plantName)
{
    char *retPlant;
    retPlant = (char *)MEM_alloc(20 * sizeof(char *));
    tc_strcpy(retPlant, "");
    if (tc_strcmp(plantName, "APLA") == 0)
        tc_strcpy(retPlant, "bl_occ_t5_CurrentViewMaskA");
    else if (tc_strcmp(plantName, "APLC") == 0)
        tc_strcpy(retPlant, "bl_occ_t5_CurrentViewMaskC");
    else if (tc_strcmp(plantName, "APLD") == 0)
        tc_strcpy(retPlant, "bl_occ_t5_CurrentViewMaskD");
    else if (tc_strcmp(plantName, "APLJ") == 0)
        tc_strcpy(retPlant, "bl_occ_t5_CurrentViewMaskJ");
    else if (tc_strcmp(plantName, "APLL") == 0)
        tc_strcpy(retPlant, "bl_occ_t5_CurrentViewMaskL");
    else if (tc_strcmp(plantName, "APLP") == 0)
        tc_strcpy(retPlant, "bl_occ_t5_CurrentViewMaskP");
    else if (tc_strcmp(plantName, "APLS") == 0)
        tc_strcpy(retPlant, "bl_occ_t5_CurrentViewMaskS");
    else if (tc_strcmp(plantName, "APLU") == 0)
        tc_strcpy(retPlant, "bl_occ_t5_CurrentViewMaskV");
    else if (tc_strcmp(plantName, "APLV") == 0)
        tc_strcpy(retPlant, "bl_occ_t5_CurrentViewMaskV");
    else if (tc_strcmp(plantName, "MBOM") == 0)
        tc_strcpy(retPlant, "bl_occ_t5_CurrentViewMaskM");
    printf("\n CurrentViewMask_F9X01 is [%s]", retPlant);
    fflush(stdout);
    return retPlant;
}

void updateCVMF9X01(tag_t itemRev)
{
	printf("\n **********updateCVMF9X01********");fflush(stdout);
	tag_t F9X01LivePlants = NULLTAG;
	int plantCount = 0;
	char* clubbedInformation = NULL;
	clubbedInformation = (char*)MEM_alloc(1*sizeof(char*));
	int plantIterator=0;
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	int len = 0;
	int length = 0;
	char* plant[10];
	char*    token                   = NULL;
	char* temp = NULL;
	ITK_CALL(AOM_ask_value_string(itemRev, "item_id", &temp));
	printf("\n updateCVMF9X01===> [%s]\n", temp);fflush(stdout);
	checkControlObjectLive_F9X01("F9X01Plants","F9X01Plants","False",&plantCount,&F9X01LivePlants);
	getControlObjectDetails_F9X01(F9X01LivePlants , &clubbedInformation);
	printf("\n*******clubbedInformation********    :[%s]\n",clubbedInformation);fflush(stdout);
	//Expand Vehicle to fetch BOM Line for CVM updation
	ITK_CALL(BOM_create_window (&window));
	ITK_CALL(CFM_find(ClosureRev,&rule));
	ITK_CALL(BOM_set_window_config_rule( window, rule ));
	ITK_CALL(BOM_set_window_pack_all(window, true));
	ITK_CALL(PIE_find_closure_rules2( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	printf ("\n rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("closure rule *** found \n");fflush(stdout);
	}
	else
	{
		printf ("closure rule *** not found \n");fflush(stdout);
		exit;
	}
	ITK_CALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITK_CALL(BOM_set_window_top_line(window,null_tag,itemRev,NULLTAG,&bom_line));
	ITK_CALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d",count);fflush(stdout);
	token=strtok(clubbedInformation,",");
	//for(plantIterator =0;plantIterator <= length;plantIterator++)
	while(token!=NULL)
	{
		printf("\n plant token- [%s]",token);fflush(stdout);
		//CVM = CurrentViewMask_F9X01(plant[plantIterator]);
		//tc_strcat(CVM,CurrentViewMask_F9X01(token));
		char*    CVM	= CurrentViewMask_F9X01(token);
		char*    childPartNum	= NULL;
		char*    childPartCVM	= NULL;
		printf("\n CVM - [%s]",CVM);fflush(stdout);
		for(childIterator=0;childIterator<count;childIterator++)
		{
			ITK_CALL(AOM_ask_value_string(child[childIterator],"bl_item_item_id",&childPartNum));
			printf("\n CVM F9X01 childPartNum ItemName:[%s]",childPartNum);fflush(stdout);
			ITK_CALL(AOM_ask_value_string(child[childIterator],CVM,&childPartCVM));
			printf("\n CVM F9X01 childPartCVM :[%s]",childPartCVM);fflush(stdout);
			ITK_CALL( AOM_set_value_string(child[childIterator],CVM,"-12"));
			printf("\n\n Value set as -12");fflush(stdout);
			
		}
		token=strtok(NULL,",");
	}
	ITK_CALL(BOM_save_window(window));
	ITK_CALL(BOM_close_window(window));
	
}

int createModifyBom_new(tag_t item ,struct StructureF5B01 ChldMBOMStrutBlt[], int childCount , char* tmpPlant)
{
	tag_t itemRev  = NULLTAG;
	char *newPartNumber = NULL;
	tag_t aplViewTag = NULLTAG;
	char *psmbomview = NULL;
	int viewcount = 0;
	tag_t *viewtag = NULLTAG;
	char* cabView = getView_F9X01(tmpPlant);
	tag_t *bvrviewtag = NULLTAG;
	tag_t bvrold = NULLTAG;
	int bvrviewcount = 0;
	tag_t Bomviewtag = NULLTAG;
	tag_t *occ_tag = NULLTAG;
	int occ_count = 0;
	tag_t BV = NULLTAG;
	int childIterator = 0;
	tag_t *occs = NULLTAG;
	char* clubbedInformation = NULL;
	char*    token                   = NULL;
	tag_t F9X01LivePlants = NULLTAG;
	int plantCount = 0;
	tag_t release_status_tag = NULLTAG;
	char *ReleaseStatus = NULL;
	logical	Retain_Released_Date = 0;
	int F5B01Count1 =0;
	int z = 0;
	tag_t ChildTag =NULLTAG;
	int ChildQuantity = 0;
	int ChildQuantityInt = 0;
	clubbedInformation = (char*)MEM_alloc(1*sizeof(char*));


	checkControlObjectLive_F9X01("F9X01Plants","F9X01Plants","False",&plantCount,&F9X01LivePlants);
	getControlObjectDetails_F9X01(F9X01LivePlants , &clubbedInformation);
	printf("\n*******clubbedInformation createModifyBom_F9X01********    :[%s]\n",clubbedInformation);fflush(stdout);
	printf("\n F9X01 is fired for ===> [%s]\n", cabView);fflush(stdout);
	printf("\n*****createModifyBom_F9X01***********\n");fflush(stdout);
	ITK_CALL(ITEM_ask_latest_rev(item,&itemRev));
	ITK_CALL(AOM_ask_value_string(itemRev, "item_id", &newPartNumber));
	printf("\n in BOM CREATION for newPartNumber F9X01===> [%s]\n", newPartNumber);fflush(stdout);

	//Add release Status
	ITK_CALL(RELSTAT_create_release_status("T5_LcsAPLpWrkg",&release_status_tag));
	ITK_CALL(AOM_ask_name(release_status_tag, &ReleaseStatus));
	printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
	ITK_CALL(RELSTAT_add_release_status(release_status_tag,1,&itemRev,Retain_Released_Date));
	
	ITK_CALL(RELSTAT_create_release_status("T5_LcsAPLjWrkg",&release_status_tag));
	ITK_CALL(AOM_ask_name(release_status_tag, &ReleaseStatus));
	printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
	ITK_CALL(RELSTAT_add_release_status(release_status_tag,1,&itemRev,Retain_Released_Date));
	
	ITK_CALL(RELSTAT_create_release_status("T5_LcsAPLdWrkg",&release_status_tag));
	ITK_CALL(AOM_ask_name(release_status_tag, &ReleaseStatus));
	printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
	ITK_CALL(RELSTAT_add_release_status(release_status_tag,1,&itemRev,Retain_Released_Date));
	
	ITK_CALL(RELSTAT_create_release_status("T5_LcsAPLlWrkg",&release_status_tag));
	ITK_CALL(AOM_ask_name(release_status_tag, &ReleaseStatus));
	printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
	ITK_CALL(RELSTAT_add_release_status(release_status_tag,1,&itemRev,Retain_Released_Date));
	//End of Add release status

	//Update CS
	ITK_CALL(AOM_lock(itemRev));
	ITK_CALL( AOM_set_value_string(itemRev,"t5_PunMakeBuyIndicator","E50"));
	ITK_CALL( AOM_set_value_string(itemRev,"t5_JsrMakeBuyIndicator","E50"));
	ITK_CALL( AOM_set_value_string(itemRev,"t5_DwdMakeBuyIndicator","E50"));
	ITK_CALL( AOM_set_value_string(itemRev,"t5_LkoMakeBuyIndicator","E50"));
	ITK_CALL(AOM_save_without_extensions(itemRev));
	ITK_CALL(AOM_unlock(itemRev));
	ITK_CALL(AOM_refresh(itemRev,0));

	ITK_CALL(PS_find_view_type(cabView,&aplViewTag))
	ITK_CALL(PS_ask_view_type_name(aplViewTag,&psmbomview));
	printf("\n Ps_view_type_name %s ",psmbomview);fflush(stdout);
	ITK_CALL(ITEM_list_bom_views(item,&viewcount, &viewtag)); 
	printf("\n Number of bom view [%d] \n",viewcount);fflush(stdout);
	if(viewcount !=0)
	{
		ITK_CALL(ITEM_rev_list_bom_view_revs(itemRev,&bvrviewcount,&bvrviewtag)); 
		printf("\n Number of bom view [%d] \n",bvrviewcount);fflush(stdout);
		bvrold=bvrviewtag[0];
		if(bvrold == NULLTAG)
		{
			Bomviewtag=viewtag[0];
			printf("\nBOM view Revision not available");fflush(stdout);
			ITK_CALL(AOM_lock(itemRev));
			ITK_CALL(PS_create_bvr(Bomviewtag,"","",false,itemRev,&bvrold));
			ITK_CALL(AOM_save_without_extensions(bvrold));
			ITK_CALL(AOM_save_without_extensions(itemRev));
			ITK_CALL(AOM_unlock(itemRev));
		}
		else 
		{
			int count =0;
			printf("\n Delete previous Occurances & Add new occurences");fflush(stdout);
			ITK_CALL(PS_list_occurrences_of_bvr(bvrold,&occ_count,&occ_tag));
			printf("\n Number of occurences in BVR  %d \n\n",occ_count); fflush(stdout);
			ITK_CALL(AOM_lock(bvrold));
			printf("\n Going to delete occurences \n\n"); fflush(stdout);
			for(count = 0; count < occ_count; count++)
			{
				
				ITK_CALL(PS_delete_occurrence(bvrold, occ_tag[count]));
			}
			ITK_CALL(AOM_save_without_extensions(bvrold));
			ITK_CALL(AOM_unlock(bvrold));
		}
	}
	else
	{
		printf("\nCreate BOM view ");fflush(stdout);
		ITK_CALL(AOM_lock(item));
		ITK_CALL(PS_create_bom_view(aplViewTag,"","",item,&BV));
		ITK_CALL(AOM_save_without_extensions(BV));
		ITK_CALL(AOM_save_without_extensions(item));
		ITK_CALL(AOM_unlock(item));
		if(BV!=NULLTAG) 
		{
			printf("\nInside BVR Creation");fflush(stdout);
			ITK_CALL(AOM_lock(itemRev));
			ITK_CALL(PS_create_bvr(BV,"","",false,itemRev,&bvrold));
			ITK_CALL(AOM_save_without_extensions(bvrold));
			ITK_CALL(AOM_save_without_extensions(itemRev));
			ITK_CALL(AOM_unlock(itemRev));
		}
	}
	printf("\n BVR Created no Going for BOM Creation ");fflush(stdout);
	ITK_CALL(AOM_lock(bvrold));
	printf("\n childCount %d ",childCount);fflush(stdout);
	for(childIterator = 1; childIterator<=childCount;childIterator++)
	{
		char* childName = NULL;
		char* F9X01Name = NULL;
		char* childType = NULL;
		ChildTag = NULLTAG;
		ChildTag = ChldMBOMStrutBlt[childIterator].child_objs;
		ChildQuantity = ChldMBOMStrutBlt[childIterator].Qty;
		ITK_CALL(AOM_ask_value_string(itemRev, "item_id", &F9X01Name));
		ITK_CALL(AOM_ask_value_string( ChildTag, "item_id", &childName));
		printf("\n Child quantity is  ==> [%d]\n",ChildQuantity);fflush(stdout);
		//ChildQuantityInt = atoi (ChildQuantity);
		//printf("\nChild quantity as int  ==> [%d]\n",ChildQuantityInt);fflush(stdout);
		/*
		ITK_CALL(AOM_ask_value_string( childSet[childIterator], "t5_PartType", &childType));
		printf("\n in Adding childName [%s] under F9X01===> [%s] of type ==> [%s]\n", childName,newPartNumber,childType);fflush(stdout);
		if(tc_strcmp(childType,"D")==0)
		{
			printf("\n child type is dummy so adding but qty is set to 0");fflush(stdout);
			ITK_CALL(PS_create_occurrences(bvrold, childSet[childIterator], NULLTAG,1, &occs));
			ITK_CALL(PS_set_occurrence_qty(bvrold, occs[0],0));
		}
		else{
			ITK_CALL(PS_create_occurrences(bvrold, childSet[childIterator], NULLTAG,1, &occs));
			ITK_CALL(PS_set_occurrence_qty(bvrold, occs[0],1));
		}*/	
		ITK_CALL(PS_create_occurrences(bvrold, ChildTag, NULLTAG,1, &occs));
		ITK_CALL(PS_set_occurrence_qty(bvrold, occs[0],ChildQuantity));
	}
	ITK_CALL(AOM_save_without_extensions(bvrold));
	ITK_CALL(AOM_unlock(bvrold)); 
	printf("\n Occurances Added Succesfully\n ");fflush(stdout);
	updateCVMF9X01(itemRev);
	
}

int CreateF9X01ObjAndBom_new(tag_t vehicle ,struct StructureF5B01 ChldMBOMStrutBlt[] , int BomLineCount,char* tmpPlant, char* taskProjectCode, char* vehicleDrAr, tag_t* NewF9X01,int delInd)
{
	printf("\n*****CreateF9X01ObjAndBom-new***********\n");fflush(stdout);
	char* F9X01FinalPartNo = NULL;
	char* F9X01CreatePartNo = NULL;
	tag_t partTag = NULLTAG;
	F9X01FinalPartNo = (char*)MEM_alloc(1*sizeof(char*));
	F9X01CreatePartNo = (char*)MEM_alloc(1*sizeof(char*));
	tc_strcpy(F9X01FinalPartNo,"");
	tc_strcpy(F9X01CreatePartNo,"");
	autoresizestrAdd_F9X01(&F9X01FinalPartNo,taskProjectCode);
	autoresizestrAdd_F9X01(&F9X01CreatePartNo,taskProjectCode);
	autoresizestrAdd_F9X01(&F9X01FinalPartNo,"F9X0140*");
	autoresizestrAdd_F9X01(&F9X01CreatePartNo,"F9X0140");//2898F9X0140001
	printf("\n Query Existing F9X01 so that new number can be generated :  To search ===> %s\n", F9X01FinalPartNo);fflush(stdout);
	if(QRY_find2("Item Revision...", &partTag));
	if(partTag != NULLTAG)
	{
		printf("\nFound Query partTag \n"); fflush(stdout);
		char* newPartNumber = NULL;
		int 		n_entries			=	2;
		int  num_to_sort = 1;
		int 		Qry_Found 			;
		tag_t 		*setOfF9X01 	= 	NULLTAG;
		tag_t 		setOfF9X01Ptr 	= 	NULLTAG;
		//char *keys[1] = {"object_name"};
		char *keys[1] = {"creation_date"};
		int  	 orders[1]  ={1};
		char 		*qry_entries[2] 	= 	{"Item ID","Type"};
		char 		*qry_values[]		=	{F9X01FinalPartNo,"Design Revision"};
		char* num = NULL;
		struct	BomChldStrut_F9X01	BomChldStrut_veh[5000];
		int StructChldCnt_veh=0;
		struct	BomChldStrut_F9X01	BomChldStrut_F9X01[5000];
		int StructChldCnt_F9X01=0;
		int VehCount = 0;
		char* view_name = NULL;
		int zz = 0;
		int abc =0;
		char* F9X01Nameptr = NULL;

		ITK_CALL(QRY_execute_with_sort(partTag, n_entries, qry_entries, qry_values, num_to_sort, keys, orders, &Qry_Found, &setOfF9X01));
		printf("\n Total F9X01FinalPartNo found : %d",Qry_Found);fflush(stdout);
		for(abc=0;abc<Qry_Found;abc++)
		{
			ITK_CALL(AOM_ask_value_string(setOfF9X01[abc], "item_id", &F9X01Nameptr));
			printf("\n No F9X01 [%d] [%s]\n",abc,F9X01Nameptr);fflush(stdout);
		}
		if(Qry_Found == 0)
		{
			printf("\n No F9X01 exists with [%s] hence fisrt F9X01 number \n",F9X01FinalPartNo);fflush(stdout);
			autoresizestrAdd_F9X01(&F9X01CreatePartNo,"001");
			printf("\n F9X01CreatePartNo [%s] hence firt F9X01 number",F9X01CreatePartNo);fflush(stdout);
			
		}
		else
		{
			char* cabSfx = NULL;
			char* cabFinal = (char*) MEM_alloc(15*sizeof(char*));
			cabSfx = (char*)MEM_alloc(1*sizeof(char*));
			tc_strcpy(cabSfx,"");
			printf("\n***F9X01 exists with [%s] so finding latest partnumber in sequence",F9X01FinalPartNo);fflush(stdout);
			ITK_CALL(AOM_ask_value_string(setOfF9X01[Qry_Found-1], "item_id", &num));
			printf("\n num Parts F9X01 : %s",num);fflush(stdout);
			autoresizestrAdd_F9X01(&cabSfx,subString_F9X01(num,11,3));
			printf("\n ****cabSfx : %s",cabSfx);fflush(stdout);
			sprintf(cabFinal,"%03d",(atoi(cabSfx)+1));
			printf("\n cabFinal after conversion===> %s\n", cabFinal);fflush(stdout);
			//nlsStrCat(r40PartNumFinal,"00");
			autoresizestrAdd_F9X01(&F9X01CreatePartNo,cabFinal);
			printf("\n F9X01CreatePartNo after conversion===> %s\n", F9X01CreatePartNo);fflush(stdout);
			
		}
		*NewF9X01 = createF9X01Part(vehicle,F9X01CreatePartNo ,"NR;1",taskProjectCode,vehicleDrAr);
		ITK_CALL(AOM_ask_value_string(*NewF9X01, "item_id", &newPartNumber));
		printf("\n newPartNumber Created===> %s\n\n ^^^^^^^^^Going To Create Bom for the same^^^^^^^^^\n", newPartNumber);fflush(stdout);
		createModifyBom_new(*NewF9X01 , ChldMBOMStrutBlt , BomLineCount , tmpPlant );
		//Attach Newly created F9X01 under Vehicle
		tag_t*	parentBvr= NULLTAG;
		tag_t	*occurrences	=	NULLTAG;
		int	parentBvrCount= 0;
		ITK_CALL(ITEM_rev_list_bom_view_revs( vehicle, &parentBvrCount, &parentBvr));
		printf("\n parentBvrCount : [%d] \n",parentBvrCount);fflush(stdout);
		if(parentBvrCount>0)
		{
			ITK_CALL(AOM_lock( parentBvr[0]));
			if(delInd==1)
			{	
				tag_t	*occurrences	=	NULLTAG;
				int noccs = 0;
				tag_t *noccsal = NULLTAG;
				char* existingF9X01 = NULL;
				char* nocc_item_id = NULL;
				int noccsItr=0;
				tag_t	nChildItem		= NULLTAG;
				tag_t	nbvrchild		= NULLTAG;
				ITK_CALL(AOM_ask_value_string(parentBvr[0],"object_name",&view_name));
				printf("\n view_name for del *** %s",view_name);fflush(stdout);
				ITK_CALL(AOM_ask_value_string(F9X01UnderVeh,"item_id",&existingF9X01));
				printf("\n existingF9X01 for del *** %s",existingF9X01);fflush(stdout);
				ITK_CALL(PS_list_occurrences_of_bvr(parentBvr[0], &noccs, &noccsal));
				printf("\n PS_list_occurrences_of_bvr noccs *** : [%d] \n",noccs);fflush(stdout);
				for(noccsItr=0;noccsItr<noccs;noccsItr++)
				{
					ITK_CALL(PS_ask_occurrence_child(parentBvr[0],noccsal[noccsItr], &nChildItem, &nbvrchild));
					ITK_CALL(AOM_ask_value_string(nChildItem, "item_id", &nocc_item_id));
					printf("\n nChildItem number ***- [%s]",nocc_item_id);fflush(stdout);
					if(tc_strcmp(existingF9X01,nocc_item_id)==0)
					{
						ITK_CALL(PS_delete_occurrence(parentBvr[0], noccsal[noccsItr]));
						printf("\n Deleting existing F9X01 *** i.e [%s]",existingF9X01);fflush(stdout);
						break;
					}
				}
			}
			ITK_CALL(PS_create_occurrences(parentBvr[0],*NewF9X01,NULLTAG,1,&occurrences));
			ITK_CALL(PS_set_occurrence_qty(parentBvr[0], occurrences[0],1));
			ITK_CALL(AOM_save_without_extensions(parentBvr[0]));
			ITK_CALL(AOM_refresh(parentBvr[0],1));
			ITK_CALL(AOM_refresh(vehicle,0));
			ITK_CALL(AOM_unlock(parentBvr[0]));
		}
		//updateCVM_F9X01(vehicle,F9X01ToBeBom,BomLineCount,tmpPlant,*NewF9X01);
	}
}

int createModifyBom_F9X01(tag_t item , tag_t* childSet , int childCount , char* tmpPlant)
{
	tag_t itemRev  = NULLTAG;
	char *newPartNumber = NULL;
	tag_t aplViewTag = NULLTAG;
	char *psmbomview = NULL;
	int viewcount = 0;
	tag_t *viewtag = NULLTAG;
	char* cabView = getView_F9X01(tmpPlant);
	tag_t *bvrviewtag = NULLTAG;
	tag_t bvrold = NULLTAG;
	int bvrviewcount = 0;
	tag_t Bomviewtag = NULLTAG;
	tag_t *occ_tag = NULLTAG;
	int occ_count = 0;
	tag_t BV = NULLTAG;
	int childIterator = 0;
	tag_t *occs = NULLTAG;
	char* clubbedInformation = NULL;
	char*    token                   = NULL;
	tag_t F9X01LivePlants = NULLTAG;
	int plantCount = 0;
	tag_t release_status_tag = NULLTAG;
	char *ReleaseStatus = NULL;
	logical	Retain_Released_Date = 0;
	int F5B01Count1 =0;
	int z = 0;
	tag_t* F5B01BomLine1 =NULLTAG;
	clubbedInformation = (char*)MEM_alloc(1*sizeof(char*));


	checkControlObjectLive_F9X01("F9X01Plants","F9X01Plants","False",&plantCount,&F9X01LivePlants);
	getControlObjectDetails_F9X01(F9X01LivePlants , &clubbedInformation);
	printf("\n*******clubbedInformation createModifyBom_F9X01********    :[%s]\n",clubbedInformation);fflush(stdout);
	printf("\n F9X01 is fired for ===> [%s]\n", cabView);fflush(stdout);
	printf("\n*****createModifyBom_F9X01***********\n");fflush(stdout);
	ITK_CALL(ITEM_ask_latest_rev(item,&itemRev));
	ITK_CALL(AOM_ask_value_string(itemRev, "item_id", &newPartNumber));
	printf("\n in BOM CREATION for newPartNumber F9X01===> [%s]\n", newPartNumber);fflush(stdout);

	//Add release Status
	ITK_CALL(RELSTAT_create_release_status("T5_LcsAPLpWrkg",&release_status_tag));
	ITK_CALL(AOM_ask_name(release_status_tag, &ReleaseStatus));
	printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
	ITK_CALL(RELSTAT_add_release_status(release_status_tag,1,&itemRev,Retain_Released_Date));
	
	ITK_CALL(RELSTAT_create_release_status("T5_LcsAPLjWrkg",&release_status_tag));
	ITK_CALL(AOM_ask_name(release_status_tag, &ReleaseStatus));
	printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
	ITK_CALL(RELSTAT_add_release_status(release_status_tag,1,&itemRev,Retain_Released_Date));
	
	ITK_CALL(RELSTAT_create_release_status("T5_LcsAPLdWrkg",&release_status_tag));
	ITK_CALL(AOM_ask_name(release_status_tag, &ReleaseStatus));
	printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
	ITK_CALL(RELSTAT_add_release_status(release_status_tag,1,&itemRev,Retain_Released_Date));
	
	ITK_CALL(RELSTAT_create_release_status("T5_LcsAPLlWrkg",&release_status_tag));
	ITK_CALL(AOM_ask_name(release_status_tag, &ReleaseStatus));
	printf("\n ******************* ReleaseStatus: %s\n",ReleaseStatus);fflush(stdout);
	ITK_CALL(RELSTAT_add_release_status(release_status_tag,1,&itemRev,Retain_Released_Date));
	//End of Add release status

	//Update CS
	ITK_CALL(AOM_lock(itemRev));
	ITK_CALL( AOM_set_value_string(itemRev,"t5_PunMakeBuyIndicator","E50"));
	ITK_CALL( AOM_set_value_string(itemRev,"t5_JsrMakeBuyIndicator","E50"));
	ITK_CALL( AOM_set_value_string(itemRev,"t5_DwdMakeBuyIndicator","E50"));
	ITK_CALL( AOM_set_value_string(itemRev,"t5_LkoMakeBuyIndicator","E50"));
	ITK_CALL(AOM_save_without_extensions(itemRev));
	ITK_CALL(AOM_unlock(itemRev));
	ITK_CALL(AOM_refresh(itemRev,0));

	ITK_CALL(PS_find_view_type(cabView,&aplViewTag))
	ITK_CALL(PS_ask_view_type_name(aplViewTag,&psmbomview));
	printf("\n Ps_view_type_name %s ",psmbomview);fflush(stdout);
	ITK_CALL(ITEM_list_bom_views(item,&viewcount, &viewtag)); 
	printf("\n Number of bom view [%d] \n",viewcount);fflush(stdout);
	if(viewcount !=0)
	{
		ITK_CALL(ITEM_rev_list_bom_view_revs(itemRev,&bvrviewcount,&bvrviewtag)); 
		printf("\n Number of bom view [%d] \n",bvrviewcount);fflush(stdout);
		bvrold=bvrviewtag[0];
		if(bvrold == NULLTAG)
		{
			Bomviewtag=viewtag[0];
			printf("\nBOM view Revision not available");fflush(stdout);
			ITK_CALL(AOM_lock(itemRev));
			ITK_CALL(PS_create_bvr(Bomviewtag,"","",false,itemRev,&bvrold));
			ITK_CALL(AOM_save_without_extensions(bvrold));
			ITK_CALL(AOM_save_without_extensions(itemRev));
			ITK_CALL(AOM_unlock(itemRev));
		}
		else 
		{
			int count =0;
			printf("\n Delete previous Occurances & Add new occurences");fflush(stdout);
			ITK_CALL(PS_list_occurrences_of_bvr(bvrold,&occ_count,&occ_tag));
			printf("\n Number of occurences in BVR  %d \n\n",occ_count); fflush(stdout);
			ITK_CALL(AOM_lock(bvrold));
			printf("\n Going to delete occurences \n\n"); fflush(stdout);
			for(count = 0; count < occ_count; count++)
			{
				
				ITK_CALL(PS_delete_occurrence(bvrold, occ_tag[count]));
			}
			ITK_CALL(AOM_save_without_extensions(bvrold));
			ITK_CALL(AOM_unlock(bvrold));
		}
	}
	else
	{
		printf("\nCreate BOM view ");fflush(stdout);
		ITK_CALL(AOM_lock(item));
		ITK_CALL(PS_create_bom_view(aplViewTag,"","",item,&BV));
		ITK_CALL(AOM_save_without_extensions(BV));
		ITK_CALL(AOM_save_without_extensions(item));
		ITK_CALL(AOM_unlock(item));
		if(BV!=NULLTAG) 
		{
			printf("\nInside BVR Creation");fflush(stdout);
			ITK_CALL(AOM_lock(itemRev));
			ITK_CALL(PS_create_bvr(BV,"","",false,itemRev,&bvrold));
			ITK_CALL(AOM_save_without_extensions(bvrold));
			ITK_CALL(AOM_save_without_extensions(itemRev));
			ITK_CALL(AOM_unlock(itemRev));
		}
	}
	printf("\n BVR Created no Going for BOM Creation ");fflush(stdout);
	ITK_CALL(AOM_lock(bvrold));
	printf("\n childCount %d ",childCount);fflush(stdout);
	for(childIterator = 0; childIterator<childCount;childIterator++)
	{
		char* childName = NULL;
		char* F9X01Name = NULL;
		char* childType = NULL;
		ITK_CALL(AOM_ask_value_string(itemRev, "item_id", &F9X01Name));
		ITK_CALL(AOM_ask_value_string( childSet[childIterator], "item_id", &childName));
		ITK_CALL(AOM_ask_value_string( childSet[childIterator], "t5_PartType", &childType));
		printf("\n in Adding childName [%s] under F9X01===> [%s] of type ==> [%s]\n", childName,newPartNumber,childType);fflush(stdout);
		if(tc_strcmp(childType,"D")==0)
		{
			printf("\n child type is dummy so adding but qty is set to 0");fflush(stdout);
			ITK_CALL(PS_create_occurrences(bvrold, childSet[childIterator], NULLTAG,1, &occs));
			ITK_CALL(PS_set_occurrence_qty(bvrold, occs[0],0));
		}
		else{
			ITK_CALL(PS_create_occurrences(bvrold, childSet[childIterator], NULLTAG,1, &occs));
			ITK_CALL(PS_set_occurrence_qty(bvrold, occs[0],1));
		}		
	}
	ITK_CALL(AOM_save_without_extensions(bvrold));
	ITK_CALL(AOM_unlock(bvrold)); 
	printf("\n Occurances Added Succesfully\n ");fflush(stdout);
	updateCVMF9X01(itemRev);
	
}

void updateCVM_F9X01(tag_t item_revision, tag_t* F9X01ToBeBom , int BomLineCount,char* tmpPlant, tag_t F9X01Part)
{
	printf("\n **********updateCVM_F9X01 Vehicle********");fflush(stdout);
	tag_t F9X01LivePlants = NULLTAG;
	int plantCount = 0;
	char* clubbedInformation = NULL;
	clubbedInformation = (char*)MEM_alloc(1*sizeof(char*));
	int plantIterator=0;
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	int len = 0;
	int length = 0;
	char* plant[10];
	char*    token                   = NULL;
	char* F9X01PartNumber = NULL;
	
	checkControlObjectLive_F9X01("F9X01Plants","F9X01Plants","False",&plantCount,&F9X01LivePlants);
	getControlObjectDetails_F9X01(F9X01LivePlants , &clubbedInformation);
	printf("\n*******clubbedInformation********    :[%s]\n",clubbedInformation);fflush(stdout);
	//Expand Vehicle to fetch BOM Line for CVM updation
	ITK_CALL(BOM_create_window (&window));
	ITK_CALL(CFM_find(ClosureRev,&rule));
	ITK_CALL(BOM_set_window_config_rule( window, rule ));
	ITK_CALL(BOM_set_window_pack_all(window, true));
	ITK_CALL(PIE_find_closure_rules2( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	printf ("\n rule count %d \n",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("closure rule *** found \n");fflush(stdout);
	}
	else
	{
		printf ("closure rule *** not found \n");fflush(stdout);
		exit;
	}
	ITK_CALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITK_CALL(BOM_set_window_top_line(window,null_tag,item_revision,NULLTAG,&bom_line));
	ITK_CALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d",count);fflush(stdout);
	token=strtok(clubbedInformation,",");
	if(F9X01Part!=NULLTAG)
	{
		ITK_CALL(AOM_ask_value_string(F9X01Part,"item_id",&F9X01PartNumber));
		printf("\n CVM F9X01PartNumber ItemName:[%s]",F9X01PartNumber);fflush(stdout);
	}
	while(token!=NULL)
	{
		printf("\n plant token- [%s]",token);fflush(stdout);
		char *CVM = CurrentViewMask_F9X01(token);
		char*    childPartNum	= NULL;
		char*    childPartCVM	= NULL;
		printf("\n CVM - [%s]",CVM);fflush(stdout);
		for(childIterator=0;childIterator<count;childIterator++)
		{
			int j=0;
			tag_t F9X01BomTag = NULLTAG;
			char* partNumber = NULL;
			ITK_CALL(AOM_ask_value_string(child[childIterator],"bl_item_item_id",&childPartNum));
			printf("\n CVM childPartNum ItemName:[%s]",childPartNum);fflush(stdout);
			ITK_CALL(AOM_ask_value_string(child[childIterator],CVM,&childPartCVM));
			printf("\n CVM childPartCVM :[%s]",childPartCVM);fflush(stdout);
			for(j=0;j<BomLineCount;j++)
			{
				F9X01BomTag = F9X01ToBeBom[j];
				ITK_CALL(AOM_ask_value_string(F9X01BomTag,"item_id",&partNumber));
				printf("\n CVM child ItemName:[%s]",partNumber);fflush(stdout);
				if(tc_strcmp(childPartNum,partNumber)==0)
				{
					printf("\n Parts Matched, Updating CVM");fflush(stdout);
					ITK_CALL( AOM_set_value_string(child[childIterator],CVM,"0--"));
					printf("\n\n Value set as 0-- for Vehicle");fflush(stdout);
				}

			}
			if(tc_strstr(childPartNum,F9X01PartNumber)!=0)
			{
				printf("\n Parts Matched, Updating CVM");fflush(stdout);
				ITK_CALL( AOM_set_value_string(child[childIterator],CVM,"-12"));
				printf("\n\n Value set as -12 for F9X01 and Vehicle");fflush(stdout);
			}
		}
		 token=strtok(NULL,",");
	}
	ITK_CALL(BOM_save_window(window)); 
	ITK_CALL(BOM_close_window(window));
	printf("\n **********updateCVM_F9X01 Vehicle End********");fflush(stdout);
	
}

//prince
void updateCVMplantWise(char* VehChildName, tag_t VehChildBVRTag, char *PlantName)
{
	printf("\n function call of updateCVMplantWise");fflush(stdout);
	tag_t qryTagCntrl1 = NULLTAG;
	char *qry_entryCntrl1[3] = {"SYSCD", "SUBSYSCD", "Delete Indicator"};
    char **qry_valuesCntrl1 = (char **)MEM_alloc(5 * sizeof(char *));
	int n_entryCntrl1 = 3;
	int control_number_found1 = 0;
	tag_t *list_of_WSO_cntrl_tags1 = NULLTAG;
    char *info1 = NULL;

	QRY_find2("Control Objects...", &qryTagCntrl1);
	if (qryTagCntrl1)
	{
		printf("\n Control Object Query Found For WT Validation\n");fflush(stdout);
		qry_valuesCntrl1[0] = "F9X01AutoPlant";
		qry_valuesCntrl1[1] = PlantName;
		qry_valuesCntrl1[2] = "0";
		ITKCALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));
		printf("\nNumber of control object found :%d", control_number_found1);fflush(stdout);
	}


	if(control_number_found1>0)
	{
		printf("\n input in function VehChildName %s ",VehChildName);fflush(stdout);
		printf("\n input in function PlantName %s ",PlantName);fflush(stdout);

		ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo1", &info1));
		
		

		if(tc_strstr(VehChildName,"F5B01")!=NULL)
		{
			printf("\n Going to update CVM for F5B01");fflush(stdout);
			ITK_CALL( AOM_set_value_string(VehChildBVRTag,info1,"0--"));
			//ITK_CALL( AOM_set_value_string(VehChildBVRTag,"bl_occ_t5_CurrentViewMaskP","0--"));
			//ITK_CALL( AOM_set_value_string(VehChildBVRTag,"bl_occ_t5_CurrentViewMaskD","0--"));
			//ITK_CALL( AOM_set_value_string(VehChildBVRTag,"bl_occ_t5_CurrentViewMaskJ","0--"));
			//ITK_CALL( AOM_set_value_string(VehChildBVRTag,"bl_occ_t5_CurrentViewMaskL","0--"));
		}
		if(tc_strstr(VehChildName,"F9X01")!=NULL)
		{
			printf("\n Going to update CVM for F9X01");fflush(stdout);
			ITK_CALL( AOM_set_value_string(VehChildBVRTag,info1,"-12"));

			char *info2 = NULL;
			char *value2 = NULL;
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo2", &info2));
			printf("\n F9X01AutoPlant --Information2 is: %s\n",info2);fflush(stdout);
			ITK_CALL( AOM_ask_value_string(VehChildBVRTag,info2,&value2));
			printf("\n vlaue 2 %s",value2);
			if(tc_strcmp(value2,"-12")==0)
			{
				printf("\n current view mask updated for value 2");
			}
			else
			{
				ITK_CALL( AOM_set_value_string(VehChildBVRTag,info2,"---"));
			}

			char *info3 = NULL;
			char *value3 = NULL;
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo3", &info3));
			printf("\n F9X01AutoPlant --Information3 is: %s\n",info3);fflush(stdout);
			ITK_CALL( AOM_ask_value_string(VehChildBVRTag,info3,&value3));
			printf("\n vlaue 3 %s",value3);
			if(tc_strcmp(value3,"-12")==0)
			{
				printf("\n current view mask updated for value 3");
			}
			else
			{
				ITK_CALL( AOM_set_value_string(VehChildBVRTag,info3,"---"));
			}

			char *info4 = NULL;
			char *value4 = NULL;
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tags1[0], "t5_Userinfo4", &info4));
			printf("\n F9X01AutoPlant --Information4 is: %s\n",info4);fflush(stdout);
			ITK_CALL( AOM_ask_value_string(VehChildBVRTag,info4,&value4));
			printf("\n vlaue 4 %s",value4);
			if(tc_strcmp(value4,"-12")==0)
			{
				printf("\n current view mask updated for value 4");
			}
			else
			{
				ITK_CALL( AOM_set_value_string(VehChildBVRTag,info4,"---"));
			}
			//ITK_CALL( AOM_set_value_string(VehChildBVRTag,"bl_occ_t5_CurrentViewMaskP","-12"));
			//ITK_CALL( AOM_set_value_string(VehChildBVRTag,"bl_occ_t5_CurrentViewMaskD","-12"));
			//ITK_CALL( AOM_set_value_string(VehChildBVRTag,"bl_occ_t5_CurrentViewMaskJ","-12"));
			//ITK_CALL( AOM_set_value_string(VehChildBVRTag,"bl_occ_t5_CurrentViewMaskL","-12"));
		}
	}

}

//Expand Vehicle without Rev and closure rule......... //prince
void checkF9X01F5B01UnderVeh(tag_t itemRev, char *plant)
{
	printf("\n ********* Check F9X01 under vehicle *******\n");fflush(stdout);
	tag_t window=NULLTAG;
	tag_t rule=NULLTAG;
	tag_t *tClosurerule = NULLTAG;
	int rulefound = 0;
	tag_t close_tag = NULLTAG;
	tag_t bom_line=NULLTAG;
	tag_t t_ChildItemRev=NULLTAG;
	int   count = 0;
    tag_t *child=NULLTAG;
	int childIterator = 0;
	int iChildItemTag=0;
	ITK_CALL(BOM_create_window (&window));
	ITK_CALL(BOM_set_window_pack_all(window, true));
	printf ("rule count %d \n",rulefound);fflush(stdout);
	ITK_CALL(BOM_set_window_top_line(window,null_tag,itemRev,NULLTAG,&bom_line));
	ITK_CALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
	printf("\n child count %d,",count);fflush(stdout);
	
	for(childIterator = 0 ; childIterator <count;childIterator++)
	{
		char *childItemName = NULL;
		char *bl_item_id2 = NULL;
		ITK_CALL(BOM_line_unpack (child[childIterator]));
		ITK_CALL(AOM_ask_value_tag (child[childIterator],bomAttr_lineItemRevTag, &t_ChildItemRev));
		{
			ITK_CALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&childItemName));
			printf("\n %d.child ItemName:[%s]",childIterator,childItemName);fflush(stdout);
			
			if(tc_strstr(childItemName,"F9X01")!=NULL || tc_strstr(childItemName,"F5B01")!=NULL)
			{
				printf("\n Function calling for CVM Update");
				updateCVMplantWise(childItemName,child[childIterator],plant);
			}
			else
			{
				printf("\n Function not  calling for CVM Update");
			}
		}
	}
}

//main function
void creationOfF9X01Fun(tag_t itemRev, tag_t taskItemTag, char *PlantName )
{
    // temRev is veh tag
    // apl taskItemTag task tag 00
    printf("/n creationOfF9X01Fun calling start /n");
    char* taskNumber1 = NULL;
    char* taskNumber11 = NULL;
    char* taskNumber = NULL;
    char * vehicleProject	=	NULL;
    char * vehicleDrAr	=	NULL;
    char* DMLNumberr = NULL;
	char* DMLNumberr1 = NULL;
	char* DMLGroup = NULL;
	char* DMLPlant = NULL;
	char* APLDMLNumber_ = NULL;
	char* APLDMLNumber = NULL;
    tag_t qryTag1=NULLTAG;
    char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));
	char *qry_entries1[2] = {"Item ID","Type"};
	int n_entryCntrl = 2;
    int found_count =0;
    tag_t *APLDMLNumbertag = NULLTAG;
	char* selectedVehicle = NULL;
    char* taskProjectCode = NULL;
	char* PLtaskvalue = NULL;
	char* F5B01ProjectCode = NULL;
	char* F5B01ARDRStatus = NULL;
	PLtaskvalue = (char *)MEM_alloc(1 * sizeof(char *));
	F5B01ProjectCode = (char *)MEM_alloc(1 * sizeof(char *));
	F5B01ARDRStatus = (char *)MEM_alloc(1 * sizeof(char *));

	ITK_CALL(AOM_ask_value_string(itemRev,"item_id",&selectedVehicle));
    ITK_CALL(AOM_ask_value_string(itemRev,"t5_ProjectCode",&vehicleProject));
	ITK_CALL(AOM_ask_value_string(itemRev,"t5_PartStatus",&vehicleDrAr));
	printf("\n vehicleProject :[%s]\n",vehicleProject);fflush(stdout);
	printf("\n vehicleDrAr :[%s]\n",vehicleDrAr);fflush(stdout);
	printf("\n selectedVehicle :[%s]\n",selectedVehicle);fflush(stdout);

    ITK_CALL(AOM_ask_value_string(taskItemTag,"item_id",&taskNumber));
	ITK_CALL(AOM_ask_value_string(taskItemTag,"item_id",&taskNumber1));
	printf("\n taskNumber :[%s]\n",taskNumber);fflush(stdout);

    DMLNumberr = strtok(taskNumber,"_");
	DMLGroup = strtok(NULL,"_");
	DMLPlant = strtok(NULL,"_");
    printf("\n DMLNumberr :[%s]\n",DMLNumberr);fflush(stdout);
    APLDMLNumber_ = strcat(DMLNumberr,"_");
    APLDMLNumber = strcat(APLDMLNumber_,DMLPlant);
    printf("\n APLDMLNumber :[%s]\n",APLDMLNumber);fflush(stdout);
    ITK_CALL(AOM_ask_value_string(taskItemTag,"item_id",&taskNumber11));
    DMLNumberr1 = strtok(taskNumber11,"_");

    ITK_CALL(QRY_find2("Item Revision...", &qryTag1));
    printf("\n Item Revision Query.......................\n");
    if (qryTag1)
    {
        qry_values1[0] = APLDMLNumber;
        qry_values1[1] = "APL DML Revision" ;
        ITK_CALL( QRY_execute(qryTag1,n_entryCntrl, qry_entries1, qry_values1, &found_count, &APLDMLNumbertag));
        printf(" Found APLDMLNumbertag :%d \n\t",found_count); fflush(stdout);
    }
    else
    {
        printf("\n Item Revision... Query tag not found... \n");fflush(stdout);
    }
    ITK_CALL(AOM_ask_value_string(APLDMLNumbertag[0],"t5_cprojectcode",&taskProjectCode));
    printf("\n DML Project code :[%s]\n",taskProjectCode);fflush(stdout);

    tag_t ProQuryTag = NULLTAG;
	tag_t *list_of_Proj_tags = NULLTAG;
	char **qry_valuesProjformat = (char **)MEM_alloc(5 * sizeof(char *));
	char *qry_entryProjformat[2] = {"Item ID","Type"};
	char* Program = NULL;
	char* ProgmCat = NULL;
	int n_entryProObj = 2;
	int ProjObjfound = 0;
	ITK_CALL(QRY_find2("Item...", &ProQuryTag));
	if (ProQuryTag != NULLTAG)
	{
		printf("\n Projects... Query Found ");
		fflush(stdout);
		qry_valuesProjformat[0] = taskProjectCode;
		qry_valuesProjformat[1] = "Project";

		ITK_CALL(QRY_execute(ProQuryTag, n_entryProObj, qry_entryProjformat, qry_valuesProjformat, &ProjObjfound, &list_of_Proj_tags));
		if (ProjObjfound > 0)
		{
			ITK_CALL(AOM_ask_value_string(list_of_Proj_tags[0], "t5_Program", &Program));
			printf("\n Program : %s", Program);
			fflush(stdout);
			if (tc_strcmp(ProgmCat, "NULL") != 0)
				MEM_free(ProgmCat);
			ProgmCat = (char *)MEM_alloc(50);

			tc_strcpy(ProgmCat, "");
			tc_strcpy(ProgmCat, ",");
			tc_strcat(ProgmCat, Program);
			tc_strcat(ProgmCat, ",");
			printf("\n ProgmCat.:%s", ProgmCat);
			fflush(stdout);
		}
	}

	if((tc_strstr(ProgmCat,"LCV")!=NULL) || (tc_strstr(ProgmCat,"Y1")!=NULL) || (tc_strstr(ProgmCat,"MHCV-T3")!=NULL) || (tc_strstr(ProgmCat,"MHCV-Buses")!=NULL) || (tc_strstr(ProgmCat,"World-Truck")!=NULL))
	{
        char* tmpPlant = NULL;
        char* clrule = NULL;
        char* clubbedInformation = NULL;
        char* VehChildName = NULL;
        char* VehChildQuantity = NULL;
        char* VehChildNameProjectCode = NULL;
        char* VehChildName_LV2 = NULL;
        char* VehChildName_pack = NULL;
        char* ChildUnderF9X01Name = NULL;
        char* ChildUnderF9X01Quantity = NULL;
        char RevRuleInfo1[40];
        char BVRInfo2[40];
        char Info3[40];
        int coF9X01Flag = 0;
        int F5B01Count = 0;
        int F5B01Count_unpack = 0;
        int F9Count1 = 0;
        int F5CountFromStructure = 0;
        int flagF9X01UnderVeh = 0;
        int F9Count = 0;
        int fromF9X01Count = 0;
        int fromF9X01Count_unpack = 0;
        int VehChildCount = 0;
        int VehChildCount_LV2 = 0;
        int	ToBeUpdatedCount = 0;
        int wrongF9X01Flag = 0 ;
        int commonFound = 0;
        int StructCnt=0;
        int viewcount = 0;
        int VehChildCount_pack = 0;
        int ClrStructCntMBOM=0;
        int F9X01StructCntMBOM = 0;
        int mm = 0;
        int F9X01CountUnderVehicle = 0;
        int StructCount =0;
        tag_t* BomLineFromF9X01 = NULLTAG;
        tag_t* BomLineFromF9X01_unpack = NULLTAG;
        tag_t* ToBeUpdatedInModule	= NULLTAG;
        tag_t *viewtag = NULLTAG;
        tag_t *bvrviewtag = NULLTAG;
        tag_t* F9BomLine = NULLTAG;
        tag_t* F5B01BomLine = NULLTAG;
        tag_t* F5B01BomLine_unpack = NULLTAG;
        tag_t* F5BomLineFromStructure = NULLTAG;
        tag_t* F9BomLine1 = NULLTAG;
        tag_t commonF9X01 = NULLTAG;
        tag_t childObjTag = NULLTAG;
        tag_t VehChildTag = NULLTAG;
        tag_t VehChildBVRTag = NULLTAG;
        tag_t VehChildTag_LV2 = NULLTAG;
        tag_t F9X01Rev = NULLTAG;
        tag_t childObjTag1 = NULLTAG;
        tag_t bvrold = NULLTAG;
        tag_t VehChildTag_pack = NULLTAG;
        tag_t TagChild = NULLTAG;
        tag_t coF9X01 = NULLTAG;
        tag_t ChildUnderF9X01Tag = NULLTAG;
        tag_t ChildUnderF9X01BVRTag = NULLTAG;
        struct	BomChldStrut_F9X01	ChldStrutBlt[5000];
        struct	EMBomChldStrut	ChldMBOMStrutBlt[5000];
        struct  StructureF5B01  ChildStructure[5000];
        struct	BomChldStrut_F9X01	F9X01MBOMStrutBlt[5000];
        tmpPlant = (char *) MEM_alloc(1 * sizeof(char *));
        clrule = (char *) MEM_alloc(1 * sizeof(char *));
        clubbedInformation = (char*)MEM_alloc(1*sizeof(char*));

        tc_strcpy(clrule,"APL");
        printf("\n clrule is [%s]",clrule);fflush(stdout);
        get_Plant(taskNumber1,&tmpPlant);
        printf("\n user is from [%s] Plant",tmpPlant);fflush(stdout);
        GetBomClosureRule(clrule,tmpPlant);
        checkControlObjectLive_F9X01("F9X01COL","F9X01COL","False",&coF9X01Flag,&coF9X01);
        printf("\n Control obj is live \n",tmpPlant);fflush(stdout);
        if(coF9X01==0)
        {
            printf("\n       Exit program with popup to user       \n");fflush(stdout);
        }
        else
        {
            printf("\n coF9X01 is Live hence proceed further\n");fflush(stdout);
            getControlObjectDetails_F9X01(coF9X01 , &clubbedInformation);
            printf("\n  *******    clubbedInformation   ********    :[%s]  \n",clubbedInformation);fflush(stdout);
        }

        getTaskOwningValue_F9X01(taskNumber1, PLtaskvalue); //vishal
        printf("\n  Plant name of Task is :%s ............../n",PLtaskvalue);fflush(stdout);
        get_CtrlVal_APLLcsInf_F9X01(PLtaskvalue, RevRuleInfo1, BVRInfo2, Info3);


        tag_t window1=NULLTAG;
        tag_t rule=NULLTAG;
        tag_t *tClosurerule = NULLTAG;
        int rulefound = 0;
        tag_t close_tag = NULLTAG;
        tag_t bom_line=NULLTAG;
        tag_t t_ChildItemRev=NULLTAG;
        int   count = 0;
        tag_t *child=NULLTAG;
        int childIterator = 0;
        int CommonTskFound = 0;

        ITK_CALL(BOM_create_window (&window1));
        printf("\n ClosureRule = %s \n ",ClosureRule);fflush(stdout);
        printf("\n ClosureRev = %s \n ",ClosureRev);fflush(stdout);
        ITK_CALL(CFM_find(ClosureRev,&rule));
        ITK_CALL(BOM_set_window_config_rule(window1,rule));
        ITK_CALL(BOM_set_window_pack_all(window1, true));
        ITK_CALL(PIE_find_closure_rules2( ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
        printf ("rule count %d \n",rulefound);fflush(stdout);
        if (rulefound > 0)
        {
            close_tag = tClosurerule[0];
            printf ("closure rule *** found \n");fflush(stdout);
        }
        else
        {
            printf ("closure rule *** not found \n");fflush(stdout);
            exit;
        }
        ITK_CALL(BOM_window_set_closure_rule(window1,close_tag,0,NULL,NULL));
        ITK_CALL(BOM_set_window_top_line(window1,null_tag,itemRev,NULLTAG,&bom_line));
        ITK_CALL(BOM_line_ask_all_child_lines(bom_line,&count,&child));
        printf("\n child count getBomLineMbomView %d,",count);fflush(stdout);
        for(childIterator = 0 ; childIterator <count;childIterator++)
        {
            ITK_CALL(AOM_ask_value_tag (child[childIterator],bomAttr_lineItemRevTag, &t_ChildItemRev));
            if(t_ChildItemRev!=NULLTAG)
            {
                char* childItemName = NULL;
                ITK_CALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&childItemName));
                if(tc_strstr(childItemName,"F5B01")!=NULL)
                {
                    ITK_CALL(AOM_ask_value_string(t_ChildItemRev,"t5_ProjectCode",&F5B01ProjectCode));
                    printf("\n F5B01ProjectCode for first child is %s,",F5B01ProjectCode);fflush(stdout);
                    ITK_CALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartStatus",&F5B01ARDRStatus));
                    printf("\n F5B01ARDRStatus for first child is %s,",F5B01ARDRStatus);fflush(stdout);				
                    break;
                }
            }
        }
        int F5B01CountFromVehicle = 0;
        Get_Part_BOM_Lvl_F9X01(itemRev,1,ClosureRule,ClosureRev,BVRInfo2,ChldStrutBlt,&StructCnt);
        for(VehChildCount = 1;VehChildCount<=StructCnt;VehChildCount++)
        {
            VehChildTag = NULLTAG;
            VehChildBVRTag = NULLTAG;
            VehChildTag	= ChldStrutBlt[VehChildCount].child_objs;
            VehChildBVRTag	= ChldStrutBlt[VehChildCount].child_objs_bvr;
            ITK_CALL(AOM_ask_value_string(VehChildTag,"item_id",&VehChildName));
            ITK_CALL(AOM_ask_value_string(VehChildBVRTag,"bl_quantity",&VehChildQuantity));	
            if(tc_strstr(VehChildName,"F5B01")!=NULL)
            {
                F5B01CountFromVehicle ++;
                printf("\n VehChildQuantity -------- : [%s] \n",VehChildQuantity);fflush(stdout);
                printf("\n before getF5B01ChildParts\n");fflush(stdout);
                getChildOfF5B01(VehChildTag,VehChildQuantity,close_tag,rule,ChildStructure,&StructCount);
            }
        }
        printf("\n F5B01CountFromVehicle = [%d]\n",F5B01CountFromVehicle);fflush(stdout);
        if ((F5B01CountFromVehicle==1) || (F5B01CountFromVehicle==0))
        {			
            printf("\n Vehicle is not applicable for creation of F9X01 \n");fflush(stdout);
        }
        else
        {
            getF5B01ChildPartsFromStructure(ChildStructure,StructCount,&F5CountFromStructure,&F5BomLineFromStructure);
            
            GetBomClosureRule("APL",tmpPlant);
            checkF9X01UnderVeh(itemRev,tmpPlant,&flagF9X01UnderVeh);
            if(flagF9X01UnderVeh ==1)
            {
                printf("\n F9X01 is present, Get F9X01 BomLine and if the same bom is present then no action is required\n");fflush(stdout);		
                GetBomClosureRule("APL",tmpPlant);
                
                Get_Part_BOM_Lvl_F9X01(F9X01UnderVeh,1,ClosureRule,ClosureRev,BVRInfo2,F9X01MBOMStrutBlt,&F9X01StructCntMBOM);
                for(F9X01CountUnderVehicle=1;F9X01CountUnderVehicle<F9X01StructCntMBOM;F9X01CountUnderVehicle++)
                {
                    ChildUnderF9X01Tag = NULLTAG;
                    ChildUnderF9X01BVRTag = NULLTAG;
                    ChildUnderF9X01Tag = F9X01MBOMStrutBlt[F9X01CountUnderVehicle].child_objs;
                    ChildUnderF9X01BVRTag = F9X01MBOMStrutBlt[F9X01CountUnderVehicle].child_objs_bvr;
                    ITK_CALL(AOM_ask_value_string(ChildUnderF9X01Tag,"item_id",&ChildUnderF9X01Name));
                    ITK_CALL(AOM_ask_value_string(ChildUnderF9X01BVRTag,"bl_quantity",&ChildUnderF9X01Quantity));
                    printf("\n ChildUnderF9X01Name = [%s] is present with quantity [%s]\n",ChildUnderF9X01Name,ChildUnderF9X01Quantity);fflush(stdout);
                }	
                
                if(F9X01StructCntMBOM != StructCount)
                {
                    printf("\n MBOM and APL Sets are different in qty\n");fflush(stdout);						
                    wrongF9X01Flag = 1;
                }
                else
                {
                    printf("\n bomCompare between MBOM and APL as sets are same in qty\n");fflush(stdout);
                    fromToBomCompare_New(ChildStructure,F9X01MBOMStrutBlt,F9X01StructCntMBOM,&ToBeUpdatedCount);
                    printf("\n ToBeUpdatedCount : [%d] \n",ToBeUpdatedCount);fflush(stdout);
                    if( ToBeUpdatedCount >0)
                        wrongF9X01Flag=1;
                }
                //check for revise
                if(wrongF9X01Flag == 1)
                {
                    int  	n_parents=0;
                    int * 	levels;
                    tag_t * 	parents	 =NULLTAG;
                    int parentIterator = 0;
                    int parentIteratorFlag = 0;
                    char* parentId = NULL;
                    char* UniqueParent	= (char *) MEM_alloc(1 * sizeof(char *));
                    tc_strcpy(UniqueParent,"");
                    printf("\n Checking for revise case\n");fflush(stdout);
                    ITK_CALL(PS_where_used_all(F9X01UnderVeh,1,&n_parents,&levels,&parents));
                    printf("\n***** No of Parent objects are n_parents : %d\n",n_parents);fflush(stdout);
                    for(parentIterator=0;parentIterator<n_parents;parentIterator++)
                    {
                        ITK_CALL(AOM_ask_value_string(parents[parentIterator],"item_id",&parentId));
                        printf("\n parent partnumber : [%s]\n",parentId);fflush(stdout);
                        if(tc_strstr(UniqueParent,parentId)==NULL)
                        {
                            parentIteratorFlag++;
                            autoresizestrAdd_F9X01(&UniqueParent,parentId);
                        }
                    }
                    printf("\n unique parents present: [%d]\n",parentIteratorFlag);fflush(stdout);
                    if(parentIteratorFlag > 1)
                    {
                        printf("\n Since existing F9X01 is applicable to multiple Vehicles, Hence searching for Common F9X01\n");fflush(stdout);							
                        commonFound = t5CheckForCommonF9X01Obj_FromStructure(ChildStructure,StructCount,tmpPlant, F5B01ProjectCode, &commonF9X01);							
                        if(commonFound == 1)
                        {
                            printf("\n Common F9X01 Exists\n");fflush(stdout);				
                            tag_t*	parentBvr= NULLTAG;
                            int	parentBvrCount= 0;
                            char* view_name = NULL;
                            tag_t	*occurrences	=	NULLTAG;
                            ITK_CALL(ITEM_rev_list_bom_view_revs( itemRev, &parentBvrCount, &parentBvr));
                            printf("\n parentBvrCount : [%d] \n",parentBvrCount);fflush(stdout);
                            if(parentBvrCount>0)
                            {
                                int noccs = 0;
                                tag_t *noccsal = NULLTAG;
                                char* existingF9X01 = NULL;
                                char* nocc_item_id = NULL;
                                int noccsItr=0;
                                tag_t	nChildItem		= NULLTAG;
                                tag_t	nbvrchild		= NULLTAG;
								//char *PlantName = NULL;//prince
                                printf("\n Inside for loop ..");fflush(stdout);
                                ITK_CALL(AOM_ask_value_string(parentBvr[0],"object_name",&view_name));
                                printf("\n view_name %s",view_name);fflush(stdout);
                                ITK_CALL(AOM_ask_value_string(F9X01UnderVeh,"item_id",&existingF9X01));
                                printf("\n existingF9X01 %s",existingF9X01);fflush(stdout);
                                printf("\n Delete old F9X01\n");fflush(stdout);
                                ITK_CALL(PS_list_occurrences_of_bvr(parentBvr[0], &noccs, &noccsal));
                                printf("\n PS_list_occurrences_of_bvr noccs : [%d] \n",noccs);fflush(stdout);
                                ITK_CALL(AOM_lock( parentBvr[0]));
                                for(noccsItr=0;noccsItr<noccs;noccsItr++)
                                {
                                    ITK_CALL(PS_ask_occurrence_child(parentBvr[0],noccsal[noccsItr], &nChildItem, &nbvrchild));
                                    ITK_CALL(AOM_ask_value_string(nChildItem, "item_id", &nocc_item_id));
                                    printf("\n nChildItem number- [%s]",nocc_item_id);fflush(stdout);
                                    if(tc_strcmp(existingF9X01,nocc_item_id)==0)
                                    {
                                        printf("\n Deleting existing F9X01 i.e [%s]",existingF9X01);fflush(stdout);
                                    }
                                }
                                ITK_CALL(PS_create_occurrences(parentBvr[0],commonF9X01,NULLTAG,1,&occurrences));
                                ITK_CALL(PS_set_occurrence_qty(parentBvr[0], occurrences[0],1));
                                ITK_CALL(AOM_save_without_extensions(parentBvr[0]));
                                ITK_CALL(AOM_refresh(parentBvr[0],1));
                                ITK_CALL(AOM_refresh(itemRev,0));
                                ITK_CALL(AOM_unlock(parentBvr[0]));
                                printf("\n F9X01 Added \n");fflush(stdout);
                                Get_Part_BOM_Lvl_F9X01(itemRev,1,ClosureRule,ClosureRev,BVRInfo2,ChldStrutBlt,&StructCnt);
                                for(VehChildCount = 1;VehChildCount<=StructCnt;VehChildCount++)
                                {
                                    VehChildTag = NULLTAG;
                                    VehChildBVRTag = NULLTAG;
                                    VehChildTag	= ChldStrutBlt[VehChildCount].child_objs;
                                    VehChildBVRTag = ChldStrutBlt[VehChildCount].child_objs_bvr;
                                    ITK_CALL(AOM_ask_value_string(VehChildTag,"item_id",&VehChildName));
                                    printf("\n VehChildName -------- : [%s] \n",VehChildName);fflush(stdout);
									
									//prince
									updateCVMplantWise(VehChildName,VehChildBVRTag,PlantName);
                                }
                                CommonTskFound = 0;
                                CommonTskFound =ChkPrtAlrdyAttachWithTask_F9X01(commonF9X01,tmpPlant);
                                if(CommonTskFound == 1)
                                {
                                    printf("\n Common F9X01 is already attached with Task, no need to create new task.\n");
                                }
                                else
                                {
                                    printf("\n Common F9X01 is Not attached with Task, need to create new task.\n");
                                    createtask_attchedtoDML_F9X01(DMLNumberr1 ,commonF9X01,tmpPlant,taskProjectCode);
                                }
                            }
                        }//End of if(commonFound == 1)
                        else
                        {
                            tag_t NewF9X01 = NULLTAG;
                            printf("\n No Common F9X01 Exists so going to create New F9X01\n");fflush(stdout);
                            CreateF9X01ObjAndBom_new(itemRev,ChildStructure,StructCount,tmpPlant, F5B01ProjectCode,F5B01ARDRStatus,&NewF9X01,1);
                            Get_Part_BOM_Lvl_F9X01(itemRev,1,ClosureRule,ClosureRev,BVRInfo2,ChldStrutBlt,&StructCnt);
                            for(VehChildCount = 1;VehChildCount<=StructCnt;VehChildCount++)
                            {
                                VehChildTag = NULLTAG;
                                VehChildBVRTag = NULLTAG;
                                VehChildTag	= ChldStrutBlt[VehChildCount].child_objs;
                                VehChildBVRTag = ChldStrutBlt[VehChildCount].child_objs_bvr;
                                ITK_CALL(AOM_ask_value_string(VehChildTag,"item_id",&VehChildName));
                                printf("\n VehChildName -------- : [%s] \n",VehChildName);fflush(stdout);

								//prince

								updateCVMplantWise(VehChildName,VehChildBVRTag,PlantName);

                            }
                            createtask_attchedtoDML_F9X01(DMLNumberr1 , NewF9X01,tmpPlant,taskProjectCode);
                        }
                    }
                    else
                    {
                        printf("\n F9X01 is applicable to single vehicle\n");fflush(stdout);
                        commonFound = t5CheckForCommonF9X01Obj_FromStructure(ChildStructure,StructCount,tmpPlant, F5B01ProjectCode, &commonF9X01);
                        //commonFound =2;
                        if(commonFound == 1)
                        {
                            printf("\n Common *** F9X01 Exists\n");fflush(stdout);
                            tag_t*	parentBvr= NULLTAG;
                            int	parentBvrCount= 0;
                            char* view_name = NULL;
                            tag_t	*occurrences	=	NULLTAG;
                            ITK_CALL(ITEM_rev_list_bom_view_revs( itemRev, &parentBvrCount, &parentBvr));
                            printf("\n parentBvrCount ** : [%d] \n",parentBvrCount);fflush(stdout);
                            if(parentBvrCount>0)
                            {
                                int noccs = 0;
                                tag_t *noccsal = NULLTAG;
                                char* existingF9X01 = NULL;
                                char* nocc_item_id = NULL;
                                int noccsItr=0;
                                tag_t	nChildItem		= NULLTAG;
                                tag_t	nbvrchild		= NULLTAG;
                                printf("\n Inside for loop ***");fflush(stdout);
                                ITK_CALL(AOM_ask_value_string(parentBvr[0],"object_name",&view_name));
                                printf("\n view_name *** %s",view_name);fflush(stdout);
                                ITK_CALL(AOM_ask_value_string(F9X01UnderVeh,"item_id",&existingF9X01));
                                printf("\n existingF9X01 *** %s",existingF9X01);fflush(stdout);
                                printf("\n Delete old F9X01 ***\n");fflush(stdout);
                                ITK_CALL(PS_list_occurrences_of_bvr(parentBvr[0], &noccs, &noccsal));
                                printf("\n PS_list_occurrences_of_bvr noccs *** : [%d] \n",noccs);fflush(stdout);
                                ITK_CALL(AOM_lock( parentBvr[0]));
                                for(noccsItr=0;noccsItr<noccs;noccsItr++)
                                {
                                    ITK_CALL(PS_ask_occurrence_child(parentBvr[0],noccsal[noccsItr], &nChildItem, &nbvrchild));
                                    ITK_CALL(AOM_ask_value_string(nChildItem, "item_id", &nocc_item_id));
                                    printf("\n nChildItem number ***- [%s]",nocc_item_id);fflush(stdout);
                                    if(tc_strcmp(existingF9X01,nocc_item_id)==0)
                                    {
                                        ITK_CALL(PS_delete_occurrence(parentBvr[0], noccsal[noccsItr]));
                                        printf("\n Deleting existing F9X01 *** i.e [%s]",existingF9X01);fflush(stdout);
                                    }
                                }
                                
                                ITK_CALL(PS_create_occurrences(parentBvr[0],commonF9X01,NULLTAG,1,&occurrences));
                                ITK_CALL(PS_set_occurrence_qty(parentBvr[0], occurrences[0],1));
                                ITK_CALL(AOM_save_without_extensions(parentBvr[0]));
                                ITK_CALL(AOM_refresh(parentBvr[0],1));
                                ITK_CALL(AOM_refresh(itemRev,0));
                                ITK_CALL(AOM_unlock(parentBvr[0]));
                                printf("\n F9X01 Added ***\n");fflush(stdout);
                                Get_Part_BOM_Lvl_F9X01(itemRev,1,ClosureRule,ClosureRev,BVRInfo2,ChldStrutBlt,&StructCnt);
                                for(VehChildCount = 1;VehChildCount<=StructCnt;VehChildCount++)
                                {
                                    VehChildTag = NULLTAG;
                                    VehChildBVRTag = NULLTAG;
                                    VehChildTag	= ChldStrutBlt[VehChildCount].child_objs;
                                    VehChildBVRTag = ChldStrutBlt[VehChildCount].child_objs_bvr;
                                    ITK_CALL(AOM_ask_value_string(VehChildTag,"item_id",&VehChildName));
                                    printf("\n VehChildName -------- : [%s] \n",VehChildName);fflush(stdout);
									//prince
									updateCVMplantWise(VehChildName,VehChildBVRTag,PlantName);
									
								
                                }
                                CommonTskFound = 0;
                                CommonTskFound =ChkPrtAlrdyAttachWithTask_F9X01(commonF9X01,tmpPlant);
                                if(CommonTskFound == 1)
                                {
                                    printf("\n Common F9X01 is already attached with Task, no need to create new task.\n");
                                }
                                else
                                {
                                    printf("\n Common F9X01 is Not attached with Task, need to create new task.\n");
                                    createtask_attchedtoDML_F9X01(DMLNumberr1 ,commonF9X01,tmpPlant,taskProjectCode);
                                }
                            }
                        }//End of if(commonFound == 1)
                        else
                        {
                            tag_t NewF9X01 = NULLTAG;
                            char* existingF9X01 = NULL;
                            int temp1234=0;
                            tag_t* NewF9X01Mstr = NULLTAG;
                            ITK_CALL(AOM_ask_value_string(F9X01UnderVeh,"item_id",&existingF9X01));
                            printf("\n No Common F9X01 Exists so going to Revise [%s]\n",existingF9X01);fflush(stdout);
                            
                            ITK_CALL(ITEM_copy_rev(F9X01UnderVeh,NULL,&NewF9X01));
                            ITK_CALL(AOM_refresh(F9X01UnderVeh,0));
                            ITK_CALL(AOM_refresh(NewF9X01,0));
                            ITK_CALL(ITEM_find(existingF9X01,&temp1234,&NewF9X01Mstr));
                            printf("\n temp1234 [%d]\n",temp1234);fflush(stdout);
                            ITK_CALL(AOM_ask_value_string(NewF9X01Mstr[0],"item_id",&existingF9X01));
                            printf("\n existingF9X01 [%s]\n",existingF9X01);fflush(stdout);
                            printf("\n F5B01Count [%d]\n",F5B01Count);fflush(stdout);
                            createModifyBom_F9X01(NewF9X01Mstr[0] ,F5B01BomLine , F5B01Count , tmpPlant );
							//comment function for CVM  not updated for all plant
                            //updateCVM_F9X01(itemRev,F5B01BomLine,F5B01Count,tmpPlant,NULLTAG);
                            Get_Part_BOM_Lvl_F9X01(itemRev,1,ClosureRule,ClosureRev,BVRInfo2,ChldStrutBlt,&StructCnt);
                            for(VehChildCount = 1;VehChildCount<=StructCnt;VehChildCount++)
                            {
                                VehChildTag = NULLTAG;
                                VehChildBVRTag = NULLTAG;
                                VehChildTag	= ChldStrutBlt[VehChildCount].child_objs;
                                VehChildBVRTag = ChldStrutBlt[VehChildCount].child_objs_bvr;
                                ITK_CALL(AOM_ask_value_string(VehChildTag,"item_id",&VehChildName));
                                printf("\n VehChildName -------- : [%s] \n",VehChildName);fflush(stdout);
								//prince
								updateCVMplantWise(VehChildName,VehChildBVRTag,PlantName);

								
                            }
                            createtask_attchedtoDML_F9X01(DMLNumberr1,NewF9X01,tmpPlant,taskProjectCode);
                        }
                    }
                }
                else
                {
					//prince

					checkF9X01F5B01UnderVeh(itemRev,PlantName);
                    printf("\n F9X01 Create task and attach Functionality \n");fflush(stdout);
                    createtask_attchedtoDML_F9X01(DMLNumberr1 , F9X01UnderVeh,tmpPlant,taskProjectCode);
                }
            }
            else if (flagF9X01UnderVeh == 0)
            {
                tag_t NewF9X01 = NULLTAG;
                printf("\n No F9X01 exists under vehicle [%s] \n",selectedVehicle);fflush(stdout);
                commonFound = t5CheckForCommonF9X01Obj_FromStructure(ChildStructure,StructCount,tmpPlant, F5B01ProjectCode, &commonF9X01);
                if(commonFound==0)
                {
                    printf("\n********No F9X01 exists under vehicle*******************\n*********************Creating a new F9X01*******************\n");fflush(stdout);
                    CreateF9X01ObjAndBom_new(itemRev,ChildStructure,StructCount,tmpPlant, F5B01ProjectCode,F5B01ARDRStatus,&NewF9X01,0);
                    Get_Part_BOM_Lvl_F9X01(itemRev,1,ClosureRule,ClosureRev,BVRInfo2,ChldStrutBlt,&StructCnt);
                    for(VehChildCount = 1;VehChildCount<=StructCnt;VehChildCount++)
                    {
                        VehChildTag = NULLTAG;
                        VehChildBVRTag = NULLTAG;
                        VehChildTag	= ChldStrutBlt[VehChildCount].child_objs;
                        VehChildBVRTag = ChldStrutBlt[VehChildCount].child_objs_bvr;
                        ITK_CALL(AOM_ask_value_string(VehChildTag,"item_id",&VehChildName));
                        printf("\n VehChildName -------- : [%s] \n",VehChildName);fflush(stdout);

						//prince
						updateCVMplantWise(VehChildName,VehChildBVRTag,PlantName);
						
                    }
                    createtask_attchedtoDML_F9X01(DMLNumberr1 , NewF9X01,tmpPlant,taskProjectCode);
                    
                }
                else
                {
                    printf("\n communization process [%s] \n",selectedVehicle);fflush(stdout);
                    tag_t*	parentBvr= NULLTAG;
                    int	parentBvrCount= 0;
                    char* view_name = NULL;
                    tag_t	*occurrences	=	NULLTAG;
                    ITK_CALL(ITEM_rev_list_bom_view_revs( itemRev, &parentBvrCount, &parentBvr));
                    printf("\n parentBvrCount : [%d] \n",parentBvrCount);fflush(stdout);
                    if(parentBvrCount>0)
                    {
                        int noccs = 0;
                        tag_t *noccsal = NULLTAG;
                        char* existingF9X01 = NULL;
                        char* nocc_item_id = NULL;
                        int noccsItr=0;
                        tag_t	nChildItem		= NULLTAG;
                        tag_t	nbvrchild		= NULLTAG;
                        printf("\n Inside for loop ..");fflush(stdout);
                        ITK_CALL(AOM_ask_value_string(parentBvr[0],"object_name",&view_name));
                        printf("\n view_name %s",view_name);fflush(stdout);
                        ITK_CALL(PS_list_occurrences_of_bvr(parentBvr[0], &noccs, &noccsal));
                        printf("\n 	noccs - [%d] \n",noccs);fflush(stdout);
                        ITK_CALL(AOM_lock( parentBvr[0]));
                        ITK_CALL(PS_create_occurrences(parentBvr[0],commonF9X01,NULLTAG,1,&occurrences));
                        ITK_CALL(PS_set_occurrence_qty(parentBvr[0], occurrences[0],1));
                        ITK_CALL(AOM_save_without_extensions(parentBvr[0]));
                        ITK_CALL(AOM_refresh(parentBvr[0],1));
                        ITK_CALL(AOM_refresh(itemRev,0));
                        ITK_CALL(AOM_unlock(parentBvr[0]));
                        printf("\n F9X01 Added before comment function \n");fflush(stdout);
						//comment function for CVM  not updated for all plant
                       // updateCVM_F9X01(itemRev,F5B01BomLine,F5B01Count,tmpPlant,commonF9X01);
                        Get_Part_BOM_Lvl_F9X01(itemRev,1,ClosureRule,ClosureRev,BVRInfo2,ChldStrutBlt,&StructCnt);
                        for(VehChildCount = 1;VehChildCount<=StructCnt;VehChildCount++)
                        {
                            VehChildTag = NULLTAG;
                            VehChildBVRTag = NULLTAG;
                            VehChildTag	= ChldStrutBlt[VehChildCount].child_objs;
                            VehChildBVRTag = ChldStrutBlt[VehChildCount].child_objs_bvr;
                            ITK_CALL(AOM_ask_value_string(VehChildTag,"item_id",&VehChildName));
                            printf("\n VehChildName -------- : [%s] \n",VehChildName);fflush(stdout);

							//prince
							updateCVMplantWise(VehChildName,VehChildBVRTag,PlantName);
							
                        }
                        CommonTskFound = 0;
                        CommonTskFound =ChkPrtAlrdyAttachWithTask_F9X01(commonF9X01,tmpPlant);
                        if(CommonTskFound == 1)
                        {
                            printf("\n Common F9X01 is already attached with Task, no need to create new task.\n");
                        }
                        else
                        {
                            printf("\n Common F9X01 is Not attached with Task, need to create new task.\n");
                            createtask_attchedtoDML_F9X01(DMLNumberr1 ,commonF9X01,tmpPlant,taskProjectCode);
                        }							
                    }
                }
            }
            else
            {
                printf("\n Something went wrong, please check once\n");fflush(stdout);		
            }
            printf("\n code end \n");fflush(stdout);
        }
		
	}
    else
    {
        printf("!!!!==============================Platform type is not matched, hence F9X01 will not create============================!!!!\n");
    }


}