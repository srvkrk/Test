/****************************************************************************************************
*  File            :   createpost_register_callbacks.c
*  Created By      :   Muktesh Girdhani
*  Created On      :   30-july-2011
*  Purpose         :   Assign the created object to Project depending on t5_ProjectCode attribute value.
*					   This is called at post action of creation.
******************************************************************************************************/
#include <ae/dataset.h>
#include <ai/sample_err.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <res/reservation.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/project.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <user_exits/user_exits.h>

//Commented depricated header files
//#include <bom/bom.h>
//#include <itk/mem.h>
//#include <sa/imanfile.h>
//#include <tc/iman.h>
//#include <tc/tc.h>
//#include <tccore/iman_msg.h>
//#include <tccore/imantype.h>

//Commented header files for TCUA 14.3
#include <tccore/releasestatus.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <tc/folder.h>


#define CONNECT_FAIL (EMH_USER_error_base + 2)
#define ITK_err 919002
#define ITK_errStore (EMH_USER_error_base + 4)

char* subString (char* mainStringf ,int fromCharf,int toCharf);
 char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(3);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

static void ECHO(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
//    vsprintf(msg, format, args);
    printf(msg);
    va_end(args);
    TC_write_syslog(msg);
}

static int PrintErrorStack( void )
{
    int iNumErrs = 0;
    const int *pSevLst = NULL;
    const int *pErrCdeLst = NULL;
    const char **pMsgLst = NULL;

    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
//Create Dataset and attach it to Design Revision
static int t5CreateDatasetOnDesignCre( tag_t DesignRevision, char* startPartName)
{
	char *item_id;
	char *object_types;
	tag_t qryDatasetTag = NULLTAG;
	tag_t datasetTag = NULLTAG;
	tag_t relationTag = NULLTAG;
 	tag_t relation = NULLTAG;
	int   	count = 0, i =0 , flag = 0;
	tag_t *secondary_objects	 ;

	printf("\n Inside Function t5CreateDatasetOnDesignCre in file createpost_register_callbacks.c\n");fflush(stdout);

	//Query GRM Relation Type
	if (GRM_find_relation_type("IMAN_specification", &relationTag)!=ITK_ok) PrintErrorStack();

	if(GRM_list_secondary_objects_only(DesignRevision, relationTag, &count, &secondary_objects)!=ITK_ok) PrintErrorStack();

	if(count > 0)
	{
		for (i=0; i< count; i++)
		{
			if (AOM_ask_value_string(secondary_objects[i],"object_type",&object_types)!=ITK_ok) PrintErrorStack();

			if(tc_strcmp(object_types,"Creo assembly") == 0 || tc_strcmp(object_types,"Creo part") == 0)
			{
				flag = 1;
				break;
			}
		}
	}

	printf("\n Inside Function t5CreateDatasetOnDesignCre flag == %d \n", flag);fflush(stdout);
	if(flag == 0)
	{

		if (AOM_ask_value_string(DesignRevision,"item_id",&item_id)!=ITK_ok) PrintErrorStack();
		printf("\n Design Revision ID  = [%s]\n", item_id);fflush(stdout);

		//Query Dataset With Start Part Name
		if (AE_find_dataset2(startPartName, &qryDatasetTag)!=ITK_ok) PrintErrorStack();

		if(qryDatasetTag)
		{
			//Copy the Dataset Tag with new name
			if (AE_copy_dataset_with_id(qryDatasetTag, item_id, NULL, NULL, &datasetTag)!=ITK_ok) PrintErrorStack();

			/*result = AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list);
                                                                printf("\n\t Got reference list--->%d",result); fflush(stdout);

                                                                result = IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor);
                                                                printf("\n\t File Imported--->%d",result); fflush(stdout);

                                                                if (result == 41178)
                                                                {
                                                                        ITK_CALL(IMF_import_file(fullPath,NULL, SS_BINARY, &filetag, &fileDescriptor));
                                                                }

                                                                result = AOM_save_without_extensions(filetag);
                                                                printf("\n\t File saved--->%d \n\t",result); fflush(stdout);

                                                                ITK_CALL(IMF_set_original_file_name(filetag,DataSetNmOrg));
                                                                result = AOM_save_without_extensions(filetag);
                                                                printf("\n\t File saved--->%d  [%s]",result,DataSetNmOrg); fflush(stdout);

                                                                result = AE_add_dataset_named_ref(Newdataset,ref_list[0],tagRefType,filetag);
                                                                printf("\n\t AE_add_dataset_named_ref--->%d",result); fflush(stdout);

                                                                AE_set_dataset_tool(Newdataset,tool);
                                                                printf("\n\t Tool set--->%d",result); fflush(stdout);

                                                                result = AOM_save_without_extensions(Newdataset);
                                                                printf("\n\t AOM_save_without_extensions--->%d",result); fflush(stdout);*/

			if(datasetTag)
			{
				printf("\n Dataset with Name [%s], created successfully. \n", item_id);fflush(stdout);

				//Saving the newly copied dataset
				if(AE_save_myself(datasetTag)!=ITK_ok) PrintErrorStack();

				if(relationTag)
				{
					//IMAN_SPECIFICATION relationship
					if (GRM_create_relation(DesignRevision, datasetTag, relationTag, NULLTAG, &relation)!=ITK_ok) PrintErrorStack();

					if(relation)
					{
						//Saving the Relationship
						if (GRM_save_relation 	(relation));
						printf("\n Relationship Create Between Design Revision and Dataset\n");fflush(stdout);
					}
					else
					{
						printf("\n *** Relationship creation failed between Design Reivion and Dataset" );fflush(stdout);
					}
				}
				else
				{
					printf("\n *** Relationship Tag for relation name IMAN_specification not found. ***\n", startPartName, item_id);fflush(stdout);
				}
			}
			else
			{
				printf("\n *** Copy Of Dataset [%s] with new name [%s] failed. ***\n", startPartName, item_id);fflush(stdout);
			}
		}
		else
		{
			printf("\n *** Dataset Not Found with name [%s] *** \n", startPartName);fflush(stdout);
		}
	}
	printf("\n Exiting Function t5CreateDatasetOnDesignCre in file createpost_register_callbacks.c\n");fflush(stdout);
    return ITK_ok;
}
extern DLLAPI int createpost_method_1(METHOD_message_t *m, va_list args)
{
	const char* item_id;
    const char* item_name;
    const char* type_name;
	//char		type_name2[TCTYPE_name_size_c+1];
    const char* rev_id;
    tag_t*      new_item_tag=NULLTAG;
    tag_t*      new_rev_tag=NULLTAG;
    tag_t*      secondary_objects=NULLTAG;
    tag_t       item_master_form_tag = NULLTAG;
    tag_t       item_rev_master_form_tag = NULLTAG;
    tag_t		reln_type = NULLTAG;
	char*		t5_StartPartProductS;
	char*		t5_DrawingIndS;

	tag_t		tagItem=NULLTAG;
	tag_t		tagItemRev=NULLTAG;
	tag_t		objTypeTag=NULLTAG;
	tag_t		objTag=NULLTAG;
	tag_t		projobj=NULLTAG;
	// tag_t	projobj1=NULLTAG;
	int i=0, notalpha =99,c_attchs=0,p=0;

	const char		*reason	= NULL;
	const char		*change_id	= NULL;
	const char		*dir_name = NULL;
	const char		*reason1	= NULL;
	const char		*change_id1	= NULL;
	const char		*dir_name1 = NULL;

	char	*ObjProject		=	NULL;
	char	*gov_class		=	NULL;
	char	*ObjProject1	=	NULL;
	char	* ProSubStr		=	NULL;
	char	*ItemIdV		=	NULL;
	char	*prid			=	NULL;
    char	*desid			=	NULL;
	char	*desrevid		=	NULL;
	int		IDlen;
	char	*projectcode	=	NULL;
    char	*desgngrp		=	NULL;
	char*	itemTagString	=	NULL;
	char*	itemRevTagString=	NULL;
	char*	type_name1=	NULL;
	char*	type_name2=	NULL;
	//char	type_name1[TCTYPE_name_size_c+1];
	logical	checkout		=	0;
	logical	checkoutp		=	0;
//	char	Ptype_name1[TCTYPE_name_size_c+1];
	tag_t	objTagMaster	=	va_arg(args, tag_t);
	tag_t	status_rel		=	NULLTAG;
	tag_t	primary			=	NULLTAG;
	tag_t	objTypeTagDi	=	NULLTAG;
	tag_t	attr_id ;

	//bhaskar
	int n_found				= 0;
	int status;
	tag_t boTag				= NULLTAG;
	tag_t creInputTag_r		= NULLTAG;
	tag_t boTypeTag			= NULLTAG;
	tag_t  relation_type1   = NULLTAG;
	tag_t  tRelationExist	= NULLTAG;
	tag_t  Rel_task			= NULLTAG;
	char *s;

  // bhaskar end

	logical		retain			=	0;
	char		*Desc_obj2		=	NULL;
	int			Procnt			=	0;
	int			ProEfound		=	0;
	tag_t		relation_type	=	NULLTAG;
	int			cnt				=	0;
	int			j=0,ij=0;
	tag_t	   *attachments		=	NULLTAG;
	char	   *ObjectClassType	=	NULL;
	char	   *ObjectName		=	NULL;
	char	   *sProjectCode	=	NULL;
	char*		oojname			=	NULL;
	int error_code = ITK_ok;
	//const char *cTemp="item_id";
	tag_t dataset =	NULLTAG;
	//tag_t *tags_found = NULL;
	//int n_tags_found= 0;
	/*
	item_id = va_arg(args, const char*);
	item_name = va_arg(args, const char*);
	type_name = va_arg(args, const char*);
	rev_id = va_arg(args, const char*);
	new_item_tag = va_arg(args, tag_t *);
	new_rev_tag = va_arg(args, tag_t *);
	item_master_form_tag = va_arg(args, tag_t);
	item_rev_master_form_tag= va_arg(args, tag_t);

	 tagItem=*new_item_tag;
	 tagItemRev=*new_rev_tag;
*/
	 // tag_t objTagMaster = va_arg(args, tag_t);
	// char	type_name_m[TCTYPE_name_size_c+1];
	char *type_name_m = NULL;
	tag_t objTypeTag_m = NULLTAG;

	if (TCTYPE_ask_object_type(objTagMaster,&objTypeTag_m)!=ITK_ok)PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag_m,&type_name_m)!=ITK_ok)PrintErrorStack();
	printf("\n createpost_method_1--type_name_m createpost_method_1 -----------> :%s ",type_name_m);fflush(stdout);

	ITEM_ask_latest_rev  (objTagMaster, &objTag) ;
	if (objTag)
	{
		if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
		if (TCTYPE_ask_name2(objTypeTag,&type_name1)!=ITK_ok)PrintErrorStack();
	}
	printf("\n type_name createpost_method_1 -----------> :[%s] ",type_name1);fflush(stdout);

	if(tc_strcmp(type_name1,"T5_PeDesignRevision")==0)
	{
		printf("\n createpost_method_1--IT IS PE PART OBJECT HENCE EXIT!!! ***createpost_method_1***");fflush(stdout);
		return error_code;
	}

	printf("\n In createpost_method_1 \n");fflush(stdout);
	if(tc_strcmp(type_name1,"Design Revision")==0 || (tc_strcmp(type_name1,"T5_EE_PartRevision") == 0) || (tc_strcmp(type_name1,"T5_SparKitRevision") == 0) || (tc_strcmp(type_name1,"T5_DuraFitPartRevision") == 0) || (tc_strcmp(type_name1,"T5_MatEnggPartRevision") == 0))
	{
		if(AOM_ask_value_string(objTag,"item_revision_id",&Desc_obj2)!=ITK_ok)   PrintErrorStack();
		printf("\n createpost_method_1--Desc_obj2  = [%s]", Desc_obj2);fflush(stdout);

		//if (AOM_get_value_string(objTag,"t5_ProjectCode",&ObjProject1)!=ITK_ok)PrintErrorStack();
		if(AOM_ask_value_string(objTag,"t5_ProjectCode",&ObjProject1)!=ITK_ok)   PrintErrorStack();
		printf("\n createpost_method_1--Project stamped is  : %s\n",ObjProject1);fflush(stdout);

		if(AOM_ask_value_string(objTag,"item_id",&ItemIdV)!=ITK_ok) PrintErrorStack();

		printf("\n createpost_method_1--ItemIdV is  : %s\n",ItemIdV);fflush(stdout);

		//ItemIdV = (char *)MEM_alloc (40 * sizeof(char));
		//if(ITEM_find_items_by_string(ItemIdV, &n_tags_found, &tags_found) !=ITK_ok)PrintErrorStack();
		//if(ITEM_find_items_by_key_attributes(1,&cTemp, &ItemIdV, &n_tags_found, &tags_found) !=ITK_ok)PrintErrorStack();
		//printf("\n n_tags_found is   = [%d]\n", n_tags_found);fflush(stdout);

		// Add here for TMETC and Trilix server.

		ProSubStr=subString(ItemIdV,0,4);
		char *sOutput=NULL;

		if( AOM_ask_value_string(objTag,"t5_ProjectCode",&sProjectCode)!=ITK_ok) PrintErrorStack();
		printf("\n createpost_method_1--sProjectCode==>[%s] ", sProjectCode);fflush(stdout);

		if ((strcmp(ObjProject1,"9001")==0) || (strcmp(ProSubStr,"9001")==0))
		{
			printf("\n createpost_method_1--Project 9001 is no longer available. Please use 9002 -  check removed in TZ1.46 as per CR-FY20-0028 \n");fflush(stdout);
			//EMH_store_error_s1(EMH_severity_error,ITK_err,"Project 9001 is no longer available. Please use 9002");
			//return ITK_err;
		}
		else
		{
			if((strcmp(Desc_obj2,"NR;1")==0)||(strcmp(Desc_obj2,"NR")==0))
			{
				if(RES_is_checked_out(objTag,&checkout)!=ITK_ok)PrintErrorStack();
				if (checkout==0)
				{
					//Create Pro/E Datasets
					if(GRM_list_secondary_objects_only(objTag,relation_type,&cnt,&attachments)!=ITK_ok) PrintErrorStack();
					printf("\n createpost_method_1--Attached Datasets2: %d ",cnt);fflush(stdout);

					for(ij=0;ij<cnt;ij++)
					{
						dataset = attachments[ij];
						if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok) PrintErrorStack();
						printf("\n createpost_method_1--Dataset ObjectClassType :%s ",ObjectClassType);fflush(stdout);

						if (strcmp(ObjectClassType,"Design Revision Master")==0 || strcmp(ObjectClassType,"T5_EE_PartRevisionMaster")==0 || strcmp(ObjectClassType,"T5_SparKitRevisionMaster")==0 || strcmp(ObjectClassType,"T5_DuraFitPartRevisionMaster")==0 || strcmp(ObjectClassType,"T5_MatEnggPartRevisionMaster")==0)
						{
							if( AOM_ask_value_string(dataset,"gov_classification",&gov_class)!=ITK_ok)PrintErrorStack();

							if (tc_strcmp(gov_class,"N") != 0 )
							{
								if( AOM_set_value_string(dataset,"gov_classification","Y")!=ITK_ok) PrintErrorStack();
								if(AOM_save_without_extensions(dataset))PrintErrorStack();
								if(AOM_unlock(dataset))PrintErrorStack();
							}

							if( AOM_ask_value_string(dataset,"gov_classification",&gov_class)!=ITK_ok) PrintErrorStack();
							printf("\n createpost_method_1--gov_class gov_class :%s\n",gov_class);fflush(stdout);
						}
					}

					//Get Start Part/Product Value
					if (AOM_ask_value_string(objTag,"t5_StartPartProduct",&t5_StartPartProductS)!=ITK_ok) PrintErrorStack();
					printf("\n createpost_method_1--t5_StartPartProduct  = [%s] ", t5_StartPartProductS);fflush(stdout);

					if(tc_strcmp(t5_StartPartProductS,"START PART PRO-E COMPONENT") == 0 || tc_strcmp(t5_StartPartProductS,"START PART PRO-E ASSEMBLY") == 0 || tc_strcmp(t5_StartPartProductS,"START PART PRO-E DRAWING") == 0)
					{
						//Create Component / Assembly Dataset
						if (t5CreateDatasetOnDesignCre( objTag, t5_StartPartProductS)!=ITK_ok) PrintErrorStack();

						//Get Drawing Indicator
						if (AOM_ask_value_string(objTag,"t5_DrawingInd",&t5_DrawingIndS)!=ITK_ok) PrintErrorStack();
						printf("\n createpost_method_1--t5_DrawingInd = [%s] ", t5_DrawingIndS);fflush(stdout);

						if(tc_strcmp(t5_DrawingIndS,"D") == 0 && tc_strcmp(t5_StartPartProductS,"START PART PRO-E DRAWING") != 0)
						{
							//Create Drawing Dataset
							if (t5CreateDatasetOnDesignCre( objTag, "START PART PRO-E DRAWING"))   PrintErrorStack();
						}
					}
					//End of Create Pro/E Datasets

					if (tc_strcmp(gov_class,"Y") == 0 )
					{
						printf("\n createpost_method_1--Insidde checkout in createpost \n");fflush(stdout);

						// Ketan Added 
						char*	ObjPartType = NULL;

						if( AOM_ask_value_string(objTag,"t5_PartType",&ObjPartType)!=ITK_ok) PrintErrorStack();

						if (tc_strcmp(ObjPartType,"CKDVC") == 0 )
						{
							printf("\n Checkout is skipping for CKDVC parttype \n");fflush(stdout);
						}
						else
						{
							printf("\n Inside Else \n");fflush(stdout);
							if (RES_checkout2(objTag,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
						}
					}

					printf("\n createpost_method_1--**********After Check Out DR in createpost***************\n");fflush(stdout);
					if(GRM_list_secondary_objects_only(objTag,reln_type,&c_attchs,&secondary_objects)!=ITK_ok) PrintErrorStack();
					printf("\n createpost_method_1--c_attchs :%d\n",c_attchs);fflush(stdout);
					
					if(c_attchs>0)
					{
						for (p= 0; p < c_attchs; p++)
						{
							primary=secondary_objects[p];
							if(TCTYPE_ask_object_type(primary,&objTypeTagDi)!=ITK_ok) PrintErrorStack();
							if(TCTYPE_ask_name2(objTypeTagDi,&type_name2)!=ITK_ok) PrintErrorStack();
							printf("\n createpost_method_1--Value of type_name2 : %s\n",type_name2);fflush(stdout);
							if(strcmp(type_name2,"ProPrt")==0 || strcmp(type_name2,"ProAsm")==0|| strcmp(type_name2,"ProDrw")==0)
							{
								if(RES_is_checked_out(primary,&checkoutp)!=ITK_ok) PrintErrorStack();
								if (checkoutp==0)
								{
									printf("\n createpost_method_1--**********Before Check Out Dataset in createpost***************\n");fflush(stdout);
									if (tc_strcmp(gov_class,"Y") == 0 )
									{
										if (RES_checkout2(primary,reason1,change_id1,dir_name1,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
									}
									printf("\n createpost_method_1--**********After Check Out Dataset in createpost***************\n");fflush(stdout);
								}
							}
						}
					}
					//if (AOM_lock(objTag)!=ITK_ok) PrintErrorStack();

					printf("\n createpost_method_1--############After lock\n");fflush(stdout);
				}
				if(GRM_list_secondary_objects_only(objTag,relation_type,&cnt,&attachments)!=ITK_ok) PrintErrorStack();
				printf("\n createpost_method_1--Attached Datasets2: %d\n",cnt);fflush(stdout);

				for(ij=0;ij<cnt;ij++)
				{
					dataset = attachments[ij];
					if (AOM_ask_value_string(dataset,"object_type",&ObjectClassType)!=ITK_ok) PrintErrorStack();
					printf("\n createpost_method_1--Dataset ObjectClassType :%s\n",ObjectClassType);fflush(stdout);

					if (strcmp(ObjectClassType,"Design Revision Master")==0 ||strcmp(ObjectClassType,"T5_SparKitRevisionMaster")==0 ||strcmp(ObjectClassType,"T5_DuraFitPartRevisionMaster")==0)
					{
						if( AOM_set_value_string(dataset,"gov_classification","N")!=ITK_ok) PrintErrorStack();
						if(AOM_save_without_extensions(dataset)!=ITK_ok) PrintErrorStack();
						if(AOM_unlock(dataset)!=ITK_ok) PrintErrorStack();

						if( AOM_ask_value_string(dataset,"gov_classification",&gov_class)!=ITK_ok) PrintErrorStack();
						printf("\n createpost_method_1--gov_class gov_class lastttt:%s\n",gov_class);fflush(stdout);
					}
				}

				// bhaskar start

				TCTYPE_find_type("T5_UpdForm", NULL, &boTypeTag);

				TCTYPE_construct_create_input (boTypeTag, &creInputTag_r);
				if(creInputTag_r)
				printf("\n createpost_method_1--Input Tag Created for item id. \n", n_found);fflush(stdout);
				boTypeTag = NULLTAG;

				if(AOM_set_value_string(creInputTag_r, "object_name", ItemIdV));
				if(AOM_set_value_string(creInputTag_r, "t5_IsUpdAllowed", "N"));

				status = TCTYPE_create_object (creInputTag_r, &boTag) ;
				if(status != ITK_ok)
				{
					EMH_ask_error_text( status, &s);
					printf("\n createpost_method_1--*** Error with ITK_init_module: %s ***\n",s);fflush(stdout);
					MEM_free(s);
					return status;
				}

				creInputTag_r = NULLTAG;
				if(boTag) printf("\n createpost_method_1--Update form created. \n");fflush(stdout);
				if(AOM_save_without_extensions(boTag));
				if(AOM_unlock(boTag));

				if(GRM_find_relation_type("T5_PartHasUpdForm",&relation_type1));
				if(GRM_find_relation(objTag,boTag,relation_type1,&tRelationExist));
				if (tRelationExist==NULLTAG)
				{
					//###  Creating Relation between DML and Task  ###

					printf("\n createpost_method_1--Now Creating Relation Between Design Revision and Update Form \n");fflush(stdout);
					if(GRM_create_relation(objTag,boTag,relation_type1,NULLTAG,&Rel_task));
					if(GRM_save_relation  (Rel_task));
					printf("\n createpost_method_1--Relation Created Successfully\n");fflush(stdout);
				}
				// bhaskar end
			}
			else
			{
				printf("\n createpost_method_1--in Else , part is not NR;1\n");fflush(stdout);
				if(GRM_list_secondary_objects_only(objTag,reln_type,&c_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
				printf("\n createpost_method_1--c_attchs :%d\n",c_attchs);fflush(stdout);
				if(c_attchs>0)
				{
					for (p= 0; p < c_attchs; p++)
					{
						primary=secondary_objects[p];
						if(TCTYPE_ask_object_type(primary,&objTypeTagDi)!=ITK_ok) PrintErrorStack();
						if(TCTYPE_ask_name2(objTypeTagDi,&type_name2)!=ITK_ok) PrintErrorStack();
						printf("\n createpost_method_1--Type of Dataset: %s\n",type_name2);fflush(stdout);

						//	if(strcmp(type_name2,"CMI2Part")==0 || strcmp(type_name2,"CMI2Product")==0|| strcmp(type_name2,"CMI2Drawing")==0 )
						//	{
						//		printf("\ninside CMI will show error\n");fflush(stdout);
						//		EMH_store_error_s1(EMH_severity_error,ITK_err,"Initial revision for TC parts should be 'NR' only. Pls check revision..");
						//		return ITK_err;
						//		break;
						//	}

						if(strcmp(type_name2,"ProPrt")==0 || strcmp(type_name2,"ProAsm")==0|| strcmp(type_name2,"ProDrw")==0 )
						{
							printf("\n createpost_method_1--inside ProPrt,ProAsm,ProDrw will break\n");fflush(stdout);
							ProEfound=1;
							break;

						}
						//else
						//	{
						//		printf("\ninside ELSE of ProPrt,ProAsm,ProDrw will show error\n");fflush(stdout);
						//		EMH_store_error_s1(EMH_severity_error,ITK_err,"Initial revision for TC parts should be 'NR' only. Pls check revision..");
						//		return ITK_err;
						//		break;
						//	}
					}

					/*
					if (ProEfound==0)
					{
					printf("\nnot PROE will show error\n");fflush(stdout);
					EMH_store_error_s1(EMH_severity_error,ITK_err,"Initial revision for TC parts should be 'NR' only. Pls check revision..");
					return ITK_err;
					}*/
				}

				/*
				else
				{
				printf("\ninside Elese when attaches = 0 . will show error\n");fflush(stdout);
				EMH_store_error_s1(EMH_severity_error,ITK_err,"Initial revision for TC parts should be 'NR' only. Pls check revision..");
				return ITK_err;
				}
				*/
			}
		}
	}
	printf("\n createpost_method_1--Returning from createpost\n");fflush(stdout);

	return ITK_ok;
}
//Vitthal START:CAE MODEL
int Transfer_CAE_Object_Into_FL(tag_t tag_Item,char *sProjectName,char *sReqDomain,char *sDRGate)
{
	int Status = ITK_ok;
	WSO_search_criteria_t criteria;
	tag_t *tag_Folder = NULLTAG;
	tag_t secObjLhTypeTag = NULLTAG;
	int n_items_f,iFolderCount;
	int iPostobeInsert=999;
	tag_t tagItem = NULLTAG;
	tag_t *tagItemTemp = NULLTAG;
	int *levels;
	int n_referencers,n_refs=0,cnt=0;
	tag_t *referencers;
	WSO_description_t desc;
	char **relations=NULL;
	tag_t objTypeRefTag=NULLTAG;
	//char type_name_ref[TCTYPE_name_size_c+1];
	char *type_name_ref	=	NULL;
	int iFlag = 0;

	WSOM_clear_search_criteria(&criteria);
	tc_strcpy(criteria.name,sDRGate);
	tc_strcpy(criteria.class_name,"Folder");
	WSOM_search(criteria,&n_items_f,&tag_Folder);
	printf("\n\t NO OF %s Folder in PLM :%d ",sDRGate,n_items_f); fflush(stdout);

	for(iFolderCount=0;iFolderCount<n_items_f;iFolderCount++)
	{
		iFlag=0;
		tagItem=tag_Folder[iFolderCount];

		if(WSOM_where_referenced2(tagItem, WSO_where_ref_any_depth,&n_refs,&levels,&referencers,&relations)!=ITK_ok)PrintErrorStack();
		printf("\n\t WSOM_where_referenced2 levels:%d n_refs: %d ",levels,n_refs); fflush(stdout);
		if (n_refs>2)
		{
			for (cnt=0;cnt<n_refs ;cnt++ )
			{
				if(TCTYPE_ask_object_type(referencers[cnt],&objTypeRefTag)!=ITK_ok) PrintErrorStack();
				if(TCTYPE_ask_name2(objTypeRefTag,&type_name_ref)!=ITK_ok) PrintErrorStack();
				if (strcmp(type_name_ref,"Folder")==0)
				{
					if (WSOM_describe(referencers[cnt], &desc) !=ITK_ok) PrintErrorStack();
					if(cnt==0 && (strcmp(desc.object_name,sReqDomain)==0))
					  iFlag++;
					if(cnt==1 && (strcmp(desc.object_name,"CAE")==0))
					  iFlag++;
					if(cnt==2 && (strcmp(desc.object_name,sProjectName)==0))
					  iFlag++;
				}
			}
			printf("\n\t Request Domain:%s \n iFlag:%d",sReqDomain,iFlag); fflush(stdout);
			if(iFlag==3)
			{
				if(AOM_lock(tagItem)!=ITK_ok) PrintErrorStack();
				FL_insert(tagItem,tag_Item,iPostobeInsert);
				if(AOM_save_without_extensions(tagItem)!=ITK_ok) PrintErrorStack();
				if(AOM_unlock(tagItem)!=ITK_ok) PrintErrorStack();
				if(AOM_refresh(tagItem,1)!=ITK_ok) PrintErrorStack();
			}
		}
		else
		{
			printf("CAE FOLDER STRUCTURE NOT FOUND :%d",n_refs);fflush(stdout);

		}
	}
	return 0;
}
char *Find_CAE_Model_Name(tag_t tag_ItemRev)
{
	int   Status			 = ITK_ok;
	int	  iArrSize=0,iAggr=0,iArrAttr=0;
	char* sItemId;
	char *sIteration;
	char *sDrGate;
	char *sProjectName;
	char *sReqDomain;
	char *sInterCAE;
	char *sProjectStage;
	char **sAgrValue;
	char *token;
	int max_char_size = 128;
	int count = 0;

	tag_t tsk_dml_rel_type;

	char *CAEItemID = NULL;
	CAEItemID=(char *) MEM_alloc(180);

	if( AOM_ask_value_string(tag_ItemRev,"item_id",&sItemId)!=ITK_ok) PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sIteration",&sIteration)!=ITK_ok) PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sIteration",&sIteration)!=ITK_ok) PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sProjectName",&sProjectName)!=ITK_ok) PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sReqDomain",&sReqDomain)!=ITK_ok) PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sDRGate",&sDrGate)!=ITK_ok) PrintErrorStack();

	//Madhusudan
	token=strtok(sProjectName,"_");
	printf("\n\n Values_of_token & Project Name are : %s and %s ------------ \n\n",token,sProjectName);fflush(stdout);

	tc_strcpy(CAEItemID,"");
	tc_strcat(CAEItemID,token);
	tc_strcat(CAEItemID,"_");
	tc_strcat(CAEItemID,sReqDomain);
	tc_strcat(CAEItemID,"_");
	tc_strcat(CAEItemID,sDrGate);
	tc_strcat(CAEItemID,"_");
	tc_strcat(CAEItemID,sIteration);
	printf("-------------->CAE ITEM NUMBER IS :%s",CAEItemID);fflush(stdout);

	for(iArrAttr=0 ; iArrAttr<3; iArrAttr++)
	{
		iAggr=0;
		iArrSize=0;
		tc_strcat(CAEItemID,"_");
		if(iArrAttr==0)
			if( AOM_ask_value_strings(tag_ItemRev,"t5_sArr_Aggregate",&iArrSize,&sAgrValue)!=ITK_ok) PrintErrorStack();
		if(iArrAttr==1)
			if( AOM_ask_value_strings(tag_ItemRev,"t5_sArr_AnalysisType",&iArrSize,&sAgrValue)!=ITK_ok) ;PrintErrorStack();
		if(iArrAttr==2)
			if( AOM_ask_value_strings(tag_ItemRev,"t5_sArr_LoadCase",&iArrSize,&sAgrValue)!=ITK_ok) PrintErrorStack();

		for(iAggr=0;iAggr<iArrSize;iAggr++)
		{
			tc_strcat(CAEItemID,sAgrValue[iAggr]);
		}

	}
	printf("CAE ITEM NUMBER IS :%s",CAEItemID);fflush(stdout);
	return CAEItemID;
}
int UpdatePost_CAEModel_Name(tag_t tag_Item,tag_t tag_ItemRev)
{
	int   Status			 = ITK_ok;
	char *sCAEName			 = NULL;
	char *sProjectName;
	char *sReqDomain;
	char *sDRGate;
	char *token;
	tag_t status_rel		 = NULLTAG;
	logical	retain 			 = 0;

	sCAEName=Find_CAE_Model_Name(tag_ItemRev);

	if(AOM_lock(tag_Item)!=ITK_ok) PrintErrorStack();
	if(AOM_set_value_string(tag_Item,"item_id",sCAEName)!=ITK_ok) PrintErrorStack();
	if(RELSTAT_create_release_status("T5_LcsReview",&status_rel)!=ITK_ok) PrintErrorStack();
	if(status_rel)
		if(RELSTAT_add_release_status(status_rel,1,&tag_ItemRev,retain)!=ITK_ok) PrintErrorStack();


	if(AOM_save_without_extensions(tag_Item)!=ITK_ok) PrintErrorStack();
	if(AOM_unlock(tag_Item)!=ITK_ok) PrintErrorStack();
	if(AOM_refresh(tag_Item,1)!=ITK_ok) PrintErrorStack();
	if(AOM_refresh(tag_ItemRev,1)!=ITK_ok) PrintErrorStack();

	if( AOM_ask_value_string(tag_ItemRev,"t5_sProjectName",&sProjectName)!=ITK_ok) PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sReqDomain",&sReqDomain)!=ITK_ok) PrintErrorStack();
	if( AOM_ask_value_string(tag_ItemRev,"t5_sDRGate",&sDRGate)!=ITK_ok) PrintErrorStack();

	token=strtok(sProjectName,"_");

	Transfer_CAE_Object_Into_FL(tag_Item,token,sReqDomain,sDRGate);
	return 0;
}
extern DLLAPI int Create_Post_Method_CAEModel(METHOD_message_t *m, va_list args)
{
	int   Status			 = ITK_ok;
	tag_t objTag;
	tag_t objTypeTag;
	tag_t objMTypeTag;
	 tag_t  projobj=NULLTAG;
	 int error_code = ITK_ok;
	//char   type_name[TCTYPE_name_size_c+1];
	//char   typeM_name[TCTYPE_name_size_c+1];
	char *typeM_name	=	NULL;
	char *type_name	=	NULL;
	char*  projectcode;

	printf("\nIn Create_Post_Method_CAEModel\n");fflush(stdout);

	tag_t objTagMaster = va_arg(args, tag_t);

	if (TCTYPE_ask_object_type(objTagMaster,&objMTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objMTypeTag,&typeM_name)!=ITK_ok) PrintErrorStack();
	printf("\n In Create_Post_Method_CAEModel -----------> :%s\n ",typeM_name);fflush(stdout);

	printf("\n Before ITEM_ask_latest_rev:%d\n ",error_code);fflush(stdout);
	error_code=ITEM_ask_latest_rev  (objTagMaster, &objTag)  ;
	printf("\n After ITEM_ask_latest_rev:%d\n ",error_code);fflush(stdout);
	if(error_code != ITK_ok) PrintErrorStack();


	if(objTag)
	{
	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	printf("\n In Create_Post_Method_CAEModel -----------> :%s\n ",type_name);fflush(stdout);

	if(tc_strcmp(type_name,"T5_TMCAEModelRevision")==0)
	{
		UpdatePost_CAEModel_Name(objTagMaster,objTag);
	}
	}
	else{
		printf("\nNull Revision Tag\n");fflush(stdout);
	}


	return ITK_ok;
}
//madhu



extern DLLAPI int Create_Post_Method_CAEModelRev(METHOD_message_t *m, va_list args)
{
	int   Status = ITK_ok;
	int z;
	tag_t  projobj=NULLTAG;
	char*  sReqDomain = NULL;
	char*  projectcode=NULL;
	char *itemid = NULL;
	char *Desc_obj = NULL;
	const char *reason = "";
	const char *change_id = "";
	const char *dir_name = "";
	logical	checkout = 0;
	tag_t rev = va_arg(args, tag_t);

	printf("\n Enter in CAERev Post Action \n");fflush(stdout);


	if(AOM_ask_value_string(rev,"item_id",&itemid)!=ITK_ok) PrintErrorStack();

	printf("\n cae item id :%s\n",itemid);
	if(AOM_ask_value_string(rev,"t5_sReqDomain",&sReqDomain)!=ITK_ok) PrintErrorStack();
	printf("\n cae domain:%s\n",sReqDomain);fflush(stdout);


	projectcode=(char *) MEM_alloc(60);

	tc_strcpy(projectcode,"CAE_");
	tc_strcat(projectcode,sReqDomain);

	printf("\n CAE_DUra is: %s\n",projectcode);fflush(stdout);

	  if(PROJ_find(projectcode,&projobj)!=ITK_ok)PrintErrorStack();
      printf("\n Assigned to Project111\n");fflush(stdout);

	  if(projobj !=NULLTAG)
		{
			if(PROJ_assign_objects(1 ,&projobj ,1 ,&rev)!=ITK_ok)PrintErrorStack();
			printf("\n Assigned to Project\n");fflush(stdout);
		}
		else
		{
			printf("\n Project not found\n");fflush(stdout);
		}
//CAE_Model_Check-out_code

	if (AOM_ask_value_string(rev,"item_revision_id",&Desc_obj)!=ITK_ok) PrintErrorStack();
	printf("\n Revision ID :%s\n",Desc_obj);fflush(stdout);

	if(tc_strcmp(Desc_obj,"NR;1")==0)
		{
			printf("\n Inside cmp \n");fflush(stdout);

			if(RES_is_checked_out(rev,&checkout)!=ITK_ok)PrintErrorStack();

			if (checkout==0)
			{
				printf("\n Inside cmp2 \n");fflush(stdout);
				if (RES_checkout2(rev,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
				printf("\n After Check_out \n");fflush(stdout);

			}
		}

	return ITK_ok;
}

extern DLLAPI int Create_Pre_Method_CAEModel(METHOD_message_t *m, va_list args)
{
	int   Status			 = ITK_ok;
 	const char *sCAEName			 = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	const char* item_id;
	const char* item_name;
	char *sItemRev		= NULL;

	const char* rev_id ;
    tag_t*      new_item_tag;
    tag_t*      new_rev_tag;
	//tag_t    tagItem=NULLTAG;
	//tag_t    tagItemRev=NULLTAG;
	tag_t  	 itemCAE= NULLTAG ;
	tag_t	 objTypeTag;
	tag_t    attr_id ;

	//char   typeM_name[TCTYPE_name_size_c+1];
	char *typeM_name	=	NULL;
	char *type_name	=	NULL;
	tag_t	 objMTypeTag;


	//tagItem=new_item_tag[0];
	//tagItemRev=new_rev_tag[0];

	printf("\n Inside Create_Pre_Method_CAEModel... \n");fflush(stdout);

	tag_t objTag = va_arg(args, tag_t);

	if (TCTYPE_ask_object_type(objTag,&objMTypeTag)!=ITK_ok)PrintErrorStack();
	if (TCTYPE_ask_name2(objMTypeTag,&typeM_name)!=ITK_ok)PrintErrorStack();
	printf("\n In Create_Pre_Method_CAEModel -----------> :%s\n ",typeM_name);fflush(stdout);

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
    if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
	printf("\n In Create_Pre_Method_CAEModel -----------> :%s\n ",type_name);fflush(stdout);

    if(tc_strcmp(type_name,"T5_TMCAEModelRevision")==0)
	{
		 sCAEName=Find_CAE_Model_Name(objTag);
		 printf("\n ITEM NAME :%s\n ",sCAEName);fflush(stdout);
		 ITEM_find_item(sCAEName,&itemCAE);
		 if(itemCAE==NULLTAG)
		 {
			 printf("\n ITEM NOT FOUND :%s\n ",sCAEName);fflush(stdout);
		 }
		 else
		 {
			 printf("\n ITEM FOUND :%s\n ",sCAEName);fflush(stdout);
			// EMH_store_error_s2(EMH_severity_error,ITK_err,"\n CAE Item with same nomenclature is Already Present in DB \n",sCAEName);
			// return ITK_errStore;
		 }

		if (AOM_ask_value_string(objTag,"item_revision_id",&sItemRev)!=ITK_ok) PrintErrorStack();
		printf("\n sItemRev  = [%s]\n", sItemRev);fflush(stdout);

		if(POM_attr_id_of_attr("item_revision_id", "T5_TMCAEModelRevision", &attr_id)!=ITK_ok) PrintErrorStack();
		printf("\n before NR check\n");fflush(stdout);

		if(tc_strcmp(sItemRev,"NR")==0 )
		{
			printf("\n inside NR check inside Create_Pre_Method_CAEModel\n");fflush(stdout);
			if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
			if(POM_set_attr_string(1,&objTag,attr_id,"NR;1")!=ITK_ok) PrintErrorStack();
			if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
			printf("\n  NR;1 updated\n");fflush(stdout);
		}
	}
	return ITK_ok;
}
//Vitthal:END:CAE MODEL

/**************** Adi CAE Analysis ***********************/

extern DLLAPI int Create_Pre_Method_CAEAnalysis(METHOD_message_t *m, va_list args)
{
	int   Status					 = ITK_ok;
 	const char *sCAEName			 = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
	char *type_name	=	NULL;
	const char* item_id;
	const char* item_name;
	char *sItemRev			= NULL;

	const char	*rev_id ;
    tag_t*      new_item_tag;
    tag_t*      new_rev_tag;
	tag_t		tagItem		=NULLTAG;
	tag_t		tagItemRev	=NULLTAG;
	tag_t  		itemCAE		=NULLTAG ;
	tag_t		objTypeTag;
	tag_t		attr_id ;
	char		*CAEPrtNum;
	tagItem					=new_item_tag[0];
	tagItemRev				=new_rev_tag[0];


	tag_t objTag = va_arg(args, tag_t);

	printf("\n I AM In Create pre Method_CAEAnalysis \n ");fflush(stdout);

	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok) PrintErrorStack();
    if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok) PrintErrorStack();
    if(tc_strcmp(type_name,"T5_TMCAEAnalysisRevision")==0)
	{

		 if( AOM_ask_value_string(objTag,"t5_CAEPrtNumber",&CAEPrtNum)!=ITK_ok) PrintErrorStack();
		 printf("\n ITEM NAME ANALYSIS ISSSS  :%s\n ",CAEPrtNum);fflush(stdout);

		 if (AOM_ask_value_string(objTag,"item_revision_id",&sItemRev)!=ITK_ok) PrintErrorStack();
		 printf("\n sItemRev  = [%s]\n", sItemRev);fflush(stdout);

		 if(POM_attr_id_of_attr("item_revision_id", "T5_TMCAEAnalysisRevision", &attr_id)!=ITK_ok) PrintErrorStack();
		 printf("\n before NR check\n");fflush(stdout);

		if(strcmp(sItemRev,"NR")==0 )
		{
			printf("\n inside NR check inside Create_Pre_Method_CAEAnalysis\n");fflush(stdout);
			if(AOM_lock(objTag)!=ITK_ok) PrintErrorStack();
			if(POM_set_attr_string(1,&objTag,attr_id,"NR;1")!=ITK_ok) PrintErrorStack();
			if(AOM_save_without_extensions(objTag)!=ITK_ok) PrintErrorStack();
			if(AOM_unlock(objTag)!=ITK_ok) PrintErrorStack();
			printf("\n  NR;1 updated for CAEAnalysis \n");fflush(stdout);
		}
	}
	return ITK_ok;

}

int UpdatePost_CAEAnalysis_Name(tag_t tag_Item,tag_t tag_ItemRev)
{
	int   Status			 = ITK_ok;
	char *CAEAnaName			 = NULL;

	tag_t status_rel		 = NULLTAG;
	logical	retain 			 = 0;


	printf("\n I AM In UpdatePost_CAEAnalysis_Name \n ");fflush(stdout);

	if( AOM_ask_value_string(tag_ItemRev,"t5_CAEPrtNumber",&CAEAnaName)!=ITK_ok) PrintErrorStack();

	if(AOM_lock(tag_Item))PrintErrorStack();
	if(AOM_set_value_string(tag_Item,"item_id",CAEAnaName)!=ITK_ok) PrintErrorStack();
	if(RELSTAT_create_release_status("T5_LcsWorking",&status_rel)!=ITK_ok) PrintErrorStack();
	if(status_rel)
		if(RELSTAT_add_release_status(status_rel,1,&tag_ItemRev,retain)!=ITK_ok) PrintErrorStack();


	if(AOM_save_without_extensions(tag_Item)!=ITK_ok) PrintErrorStack();
	if(AOM_unlock(tag_Item)!=ITK_ok) PrintErrorStack();
	if(AOM_refresh(tag_Item,1)!=ITK_ok) PrintErrorStack();
	if(AOM_refresh(tag_ItemRev,1)!=ITK_ok) PrintErrorStack();

	printf("\n After UpdatePost_CAEAnalysis_Name \n ");fflush(stdout);

	return 0;
}

extern DLLAPI int Create_Post_Method_CAEAnalysis(METHOD_message_t *m, va_list args)
{
	int   Status			 = ITK_ok;
	tag_t objTag;
	tag_t objTypeTag;
	char *CAEAnaName1 = NULL;
	char *type_name = NULL;
	//char   type_name[TCTYPE_name_size_c+1];
		tag_t		   CAE_relation_tag	= NULLTAG;
		tag_t		   Des_rev_tag	= NULLTAG;
		tag_t		   CAERel_tag	= NULLTAG;
		char *sDesRevNum = NULL;
		char *sRev = NULL;
		char *sSeq = NULL;
		char *sRevSeq = NULL;
		char *CAE_rev = NULL;

		//sRevSeq=malloc(50);


	const char		*reason	= NULL;
	const char		*change_id	= NULL;
	const char		*dir_name = NULL;

//	const char		*reason										= va_arg (args, const char*);
//	const char		*change_id									= va_arg (args, const char*);
//	const char		*dir_name									= va_arg (args, const char*);

	tag_t objTagMaster = va_arg(args, tag_t);

	printf("\n  In Create_Post_Method_CAEAnalysis \n ");fflush(stdout);

	ITEM_ask_latest_rev  (objTagMaster, &objTag)  ;
	if (TCTYPE_ask_object_type(objTag,&objTypeTag)!=ITK_ok)PrintErrorStack();
	if (TCTYPE_ask_name2(objTypeTag,&type_name)!=ITK_ok)PrintErrorStack();
	printf("\n type_name Create Post Method_CAEAnalysis -----------> :%s\n ",type_name);fflush(stdout);

	if(tc_strcmp(type_name,"T5_TMCAEAnalysisRevision")==0)
	{

		UpdatePost_CAEAnalysis_Name(objTagMaster,objTag);

		printf("\n BEFORE check out of CAERevision  \n ");fflush(stdout);

		if (AOM_ask_value_string(objTag,"item_revision_id",&CAE_rev)!=ITK_ok) PrintErrorStack();

		printf("\n CAE_rev  = [%s]\n", CAE_rev);fflush(stdout);

	    if(AOM_ask_value_string(objTag,"t5_CAEPrtNumber",&CAEAnaName1)!=ITK_ok) PrintErrorStack();

		printf("\n CAEAnaName1  = [%s]\n", CAEAnaName1);fflush(stdout);

		if(tc_strcmp(CAE_rev,"NR;1")==0)
		{
			printf("\n check out object XXX  \n ");fflush(stdout);
			if (RES_checkout2(objTag,reason,change_id,dir_name,RES_EXCLUSIVE_RESERVE)!=ITK_ok) PrintErrorStack();
		}
		printf("\n check for design revision to attach the CAE part  \n ");fflush(stdout);

		sRevSeq=(char *) MEM_alloc(60);

		sDesRevNum = tc_strtok (CAEAnaName1,"_");
		sRev = tc_strtok (NULL,"_");
		sSeq = tc_strtok (NULL,"_");

		tc_strcpy(sRevSeq,"");
		tc_strcat(sRevSeq,sRev);
		tc_strcat(sRevSeq,";");
		tc_strcat(sRevSeq,sSeq);

		printf("\n Design ID: [%s]  \n ",sDesRevNum);fflush(stdout);
		printf("\n Revision ID: [%s] \n ",sRevSeq);fflush(stdout);

		if (ITEM_find_rev(sDesRevNum,sRevSeq,&Des_rev_tag)!=ITK_ok)PrintErrorStack();
		printf("\n Des_rev_tag \n ");fflush(stdout);

		if(Des_rev_tag)
		{
			if (GRM_find_relation_type("T5_ERCPartHasCAEPart",&CAERel_tag)!=ITK_ok)PrintErrorStack();
			printf("\n GRM_find_relation_type ERChas CAE \n ");fflush(stdout);

			if (GRM_create_relation	(Des_rev_tag,objTag,CAERel_tag,NULLTAG,&CAE_relation_tag)!=ITK_ok)PrintErrorStack();
			printf("\n GRM_create_relation ERChas CAE \n ");fflush(stdout);

			if (GRM_save_relation(CAE_relation_tag)!=ITK_ok)PrintErrorStack();
			printf("\n After GRM_save_relation ERChas CAE \n ");fflush(stdout);

			if (AOM_save_without_extensions(Des_rev_tag)!=ITK_ok)PrintErrorStack();
			if (AOM_save_without_extensions(objTag)!=ITK_ok)PrintErrorStack();

			printf("\n After AOM_save_without_extensions ObjTag \n ");fflush(stdout);
		}
		else
		{
			printf("\n ERC part not found for CAE part \n ");fflush(stdout);

		}
	}

	return ITK_ok;
}


/**************** Adi CAE Analysis Ends  ***********************/
extern int createpost_register_method(int *decision, va_list args)
{
    METHOD_id_t  method;
	METHOD_id_t  method_TMCAEModelRev;
	METHOD_id_t  method_TMCAEModelRevPostAct;
    METHOD_id_t  method_TMCAEModel;
	METHOD_id_t  method_TMCAEAnalysis; //Adi
    METHOD_id_t  method_TMCAEAnalysisRev; //Adi


	  *decision = ALL_CUSTOMIZATIONS;

   if ( METHOD_find_method("Item", TC_save_msg, &method) !=ITK_ok)PrintErrorStack();
   if ( METHOD_find_method("T5_TMCAEModel", TC_save_msg, &method_TMCAEModel) !=ITK_ok)PrintErrorStack();
   if ( METHOD_find_method("T5_TMCAEModelRevision", TC_save_msg, &method_TMCAEModelRev) !=ITK_ok)PrintErrorStack();
   if ( METHOD_find_method("T5_TMCAEModelRevision", TC_save_msg, &method_TMCAEModelRevPostAct) !=ITK_ok)PrintErrorStack();
   if ( METHOD_find_method("T5_TMCAEAnalysis", TC_save_msg, &method_TMCAEAnalysis) !=ITK_ok)PrintErrorStack(); //Adi
   if ( METHOD_find_method("T5_TMCAEAnalysisRevision", TC_save_msg, &method_TMCAEAnalysisRev) !=ITK_ok)PrintErrorStack(); //Adi

    if (method.id)
    {
        if( METHOD_add_action(method, METHOD_post_action_type, (METHOD_function_t) createpost_method_1, NULL)!=ITK_ok) PrintErrorStack();
		printf("Registered as Post-Action for Creation\n");fflush(stdout);
    }
    else
	{
        printf("Method not found!\n");fflush(stdout); //
	}
	if (method_TMCAEModel.id)
    {
        if( METHOD_add_action(method_TMCAEModel, METHOD_post_action_type, (METHOD_function_t) Create_Post_Method_CAEModel, NULL)!=ITK_ok) PrintErrorStack();
		printf("Registered as Create_Post_Method_CAEModel for Creation\n");fflush(stdout);
    }
    else
	{
        printf("method_TMCAEModel not found!\n");fflush(stdout);
	}

 	if (method_TMCAEModelRev.id)
    {
        if( METHOD_add_action(method_TMCAEModelRev, METHOD_pre_action_type, (METHOD_function_t) Create_Pre_Method_CAEModel, NULL)!=ITK_ok) PrintErrorStack();

		printf("Registered as pre-Action for Creation method_TMCAEModelRev \n");fflush(stdout);
    }
    else
	{
        printf("method_TMCAEModelRev not found!\n");fflush(stdout); //
	}
//madhu
	if (method_TMCAEModelRevPostAct.id)
    {
        if( METHOD_add_action(method_TMCAEModelRevPostAct, METHOD_post_action_type, (METHOD_function_t) Create_Post_Method_CAEModelRev, NULL)!=ITK_ok) PrintErrorStack();

		printf("Registered as post-Action for Creation method_TMCAEModelRevPostAct \n");fflush(stdout);
    }
    else
	{
        printf("method_TMCAEModelRevPostAct not found!\n");fflush(stdout); //
	}



	/*******************Adi For CAE Analysis*************************/

	if (method_TMCAEAnalysis.id)
    {
        if( METHOD_add_action(method_TMCAEAnalysis, METHOD_post_action_type, (METHOD_function_t) Create_Post_Method_CAEAnalysis, NULL)!=ITK_ok) PrintErrorStack();

		printf("\n Create_Post_Method_CAEAnalysis for Creation\n");fflush(stdout);
    }
    else
	{
        printf("\n method_TMCAEAnalysis not found!\n");fflush(stdout);
	}

	if (method_TMCAEAnalysisRev.id)
    {
		if( METHOD_add_action(method_TMCAEAnalysisRev, METHOD_pre_action_type, (METHOD_function_t) Create_Pre_Method_CAEAnalysis, NULL)!=ITK_ok) PrintErrorStack();

		printf("\n Create_Pre_Method_CAEAnalysis for CREATION \n");fflush(stdout);
    }
    else
	{
        printf("\n method_TMCAEAnalysisRev not found!\n");fflush(stdout);
	}

	/*******************Adi For CAE Analysis*************************/
    return ITK_ok;
}

extern DLLAPI int tm_createpost_register_callbacks()
{
    printf("\n\n tm_createpost_register_callbacks changed -------------new printf addedff \n\n");fflush(stdout);


  //  if(CUSTOM_register_exit ( "createpost", "USER_init_module", (CUSTOM_EXIT_ftn_t)  createpost_register_method) !=ITK_ok)
    if(CUSTOM_register_exit ( "tm_createpost", "USER_gs_shell_init_module", (CUSTOM_EXIT_ftn_t)  createpost_register_method) !=ITK_ok) PrintErrorStack();

	printf("\n\n At end of tm_createpost_register_callbacks tm_createpost  ------------\n\n");fflush(stdout);

  return ( ITK_ok );
}
