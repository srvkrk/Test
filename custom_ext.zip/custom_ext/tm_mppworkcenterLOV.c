#define ITK_err 919002
#define TE_MAXLINELEN  128
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/aom_prop.h>
int ifail =0;

METHOD_id_t  mppmethodLOV;

#define ITK_errStore (EMH_USER_error_base + 3)


int mppaskworcenterLOV(METHOD_message_t *msg, va_list  args)
{

	printf("\n Inside the Work center LOV Drop down");

	tag_t lov_tag  = va_arg(args, const tag_t);
	int*  n_values = va_arg(args, int*);
	char  ***values = va_arg(args, char***);

	tag_t	query = NULLTAG;
	tag_t	query2 = NULLTAG;
	int n_entryCntrl =3;

	int n_entries = 1;
	int n_found = 0;
	tag_t CurrentRoleTag = NULLTAG;
	tag_t groupTag = NULLTAG;
	int ii=0;
	char *wk_item_id;
	char* RoleName = NULL;
	char* groupString = NULL;
	char* groupName = NULL;
	char	**qry_valuesCntrl = (char **) MEM_alloc(5 * sizeof(char *));
	char    *qry_entryCntrl[3] = {"SYSCD","SUBSYSCD","Delete Indicator"};
	qry_valuesCntrl[0]="workcenterplantwise";
	qry_valuesCntrl[1]="workcenterplantwise";
	qry_valuesCntrl[2]="0";
	int  	control_number_found		= 0;
	tag_t 	*cntr_objects				= NULLTAG;

	ifail = QRY_find2("Control Objects...", &query2);
	if (query2)
	{
		ifail = QRY_execute(query2, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &cntr_objects);
		if(control_number_found>0)
		{
			char *UserInfo1 = NULL;
            char *UserInfo2 = NULL;
            char *UserInfo3 = NULL;
            char *UserInfo4 = NULL;
            char *UserInfo5 = NULL;
			ifail = AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&UserInfo1);
			ifail = AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&UserInfo2);
			ifail = AOM_ask_value_string(cntr_objects[0],"t5_Userinfo3",&UserInfo3);
			ifail = AOM_ask_value_string(cntr_objects[0],"t5_Userinfo4",&UserInfo4);
			ifail = AOM_ask_value_string(cntr_objects[0],"t5_Userinfo5",&UserInfo5);

			printf("\n UserInfo1 is:- %s\n", UserInfo1);  //pBOP_APLPUNE
            printf("\n UserInfo2 is:- %s\n", UserInfo2);  //pBOP_APLPNR
            printf("\n UserInfo3 is:- %s\n", UserInfo3);  //pBOP_APLDWD
            printf("\n UserInfo4 is:- %s\n", UserInfo4);  //pBOP_APLJSR
            printf("\n UserInfo5 is:- %s\n", UserInfo5);  //pBOP_APLLKO

			ifail = QRY_find2("Workcenter_Plantwise", &query);
			if (query)
			{
				char *qry_entries[1] = {"PlantName"};
				char **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

				printf("\n Finding Current Group ");fflush(stdout);
				POM_ask_group(&groupString,&groupTag);
				SA_ask_group_name2(groupTag,&groupName);
				printf("\n groupName : %s ",groupName);fflush(stdout);
				
				if(tc_strstr(groupName,UserInfo1)!=NULL)
				{
					printf("\n In side PNE");fflush(stdout);
					qry_values[0] = "1001";
				}
				else if(tc_strstr(groupName,UserInfo2)!=NULL)
				{
					printf("\n In side UTK");fflush(stdout);
					qry_values[0] = "3100";
				}
				else if(tc_strstr(groupName,UserInfo3)!=NULL)
				{
					printf("\n In side DWD");fflush(stdout);
					qry_values[0] = "1500";
				}
				else if(tc_strstr(groupName,UserInfo4)!=NULL)
				{
					printf("\n In side JSR");fflush(stdout);
					qry_values[0] = "2001";
				}
				else if(tc_strstr(groupName,UserInfo5)!=NULL)
				{
					printf("\n In side JSR");fflush(stdout);
					qry_values[0] = "3001";
				}
				else
				{
					printf("\n GroupName is not valid for the query ");fflush(stdout);
				}

				printf("\n Executing Query");
				ifail=QRY_execute(query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects);
				printf("\n Workcenter object found %d", n_found);fflush(stdout);

				*n_values = n_found;
				printf("\n myAskLOVKeyWordValuesMethod--TCDC== %d\n", *n_values);fflush(stdout);

				*values = (char **)MEM_alloc (*n_values * sizeof(char*));
				memset( *values, 0,  *n_values * sizeof(char*));

				for (ii = 0; ii < n_found; ii++)
				{
					printf("\nInside For loop");
					ifail =  AOM_ask_value_string(cntr_objects[ii],"item_id",&wk_item_id);
					printf("\nWork center ID:-%s ",wk_item_id);

					(*values)[ii] = (char *) MEM_alloc (strlen(wk_item_id) + 1);
					strcpy((*values)[ii], wk_item_id);
				}

				if (cntr_objects)
				{
					MEM_free(cntr_objects);
					printf("\nMemory has been free");
				}
				if (wk_item_id)
				{
					MEM_free(wk_item_id);
				}
			}
			
		}
		else
		{
			printf("\n control pbject not fould");
		}

	}
	else
	{
		printf("\n Query not found");
	}
	return 0;
}

extern int mppworkcenterLOV(int *decision, va_list args)
{
    printf("\n Welcome to MPP Customization");
	if( ifail == ITK_ok )
	{
		printf("\n Before T5_KeyWordLOVType METHOD_register_method--");fflush(stdout);
		ifail = METHOD_register_method( "T5_MPPWorkcenter",LOV_ask_values_msg,&mppaskworcenterLOV,0,&mppmethodLOV);
		printf("\n After T5_KeyWordLOVType METHOD_register_method--");fflush(stdout);
	}
	return ifail;

}

DLLAPI int tm_mppworkcenterLOV_register_callbacks ()
{
	int ifail=0;

	printf("\n Begining of mppworkcenterLOV_callback------\n");fflush(stdout);

	if(CUSTOM_register_exit ( "tm_mppworkcenterLOV", "USER_init_module", (CUSTOM_EXIT_ftn_t)  mppworkcenterLOV) !=ITK_ok);

	printf("\n mppworkcenterLOV--processing is completed------\n\n");fflush(stdout);

	return ( ITK_ok );
}