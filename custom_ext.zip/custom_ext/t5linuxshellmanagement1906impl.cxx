/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <t5linuxshellmanagement1906impl.hxx>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<tc/tc.h>
#include<tc/preferences.h>
#include<tc/emh.h>
using namespace T5::Soa::tmShellExecution::_2019_06;
using namespace Teamcenter::Soa::Server;
using namespace std;

std::string T5LinuxShellManagementImpl::tmShellBatchCall ( const std::string shellpath, const std::string shellName, const std::string shellArg1, const std::string shellArg2 )
{
    // TODO implement operation
	char* ShellUsage = NULL;
	char* PrefShellEnvName = NULL;
	ShellUsage = (char *) malloc (sizeof(char) * 400);
	cout <<shellpath << shellpath;
	cout <<shellName << shellName;
	cout <<shellArg1 << shellArg1;
	cout <<shellArg2 << shellArg2;
	//ITK_CALL(PREF_ask_char_value("tm_SHELL_ENV", 0 , &PrefShellEnvName ));
	PREF_ask_char_value("tm_SHELL_ENV", 0 , &PrefShellEnvName );
	TC_write_syslog("\ntm_SHELL_ENV : [ %s ]",  PrefShellEnvName);
//	if (PrefShellEnvName == NULL )
//	{
//		PrefShellEnvName = ( char* ) "NULL";
//		
//		if (PrefShellEnvName)
//		{
//			MEM_free(PrefShellEnvName);
//		}
//		if (ShellUsage)
//		{
//			free(ShellUsage);
//		}
//		return "Can not call service preference tm_SHELL_ENV having blank value";
//	}
//	else if ( strcmp(PrefShellEnvName,"WINDOWS" ) == 0 )
//	{
//		strcpy(ShellUsage,shellpath.c_str());
//		strcat(ShellUsage,"\\");
//		strcat(ShellUsage,shellName.c_str());
//		strcat(ShellUsage," ");
//		strcat(ShellUsage,shellArg1.c_str());
//		strcat(ShellUsage," ");
//		strcat(ShellUsage,shellArg2.c_str());
//	}
////	else if ( strcmp(PrefShellEnvName,"LINUX" ) == 0 )
	if ( strcmp(PrefShellEnvName,"LINUX" ) == 0 )
	{
		strcpy(ShellUsage,shellpath.c_str());
		strcat(ShellUsage,"/");
		strcat(ShellUsage,shellName.c_str());
		strcat(ShellUsage," ");
		strcat(ShellUsage,shellArg1.c_str());
		strcat(ShellUsage," ");
		strcat(ShellUsage,shellArg2.c_str());
	}
	else
	{
		free(ShellUsage);
		TC_write_syslog("\nCan not call service No preference defined to find env or having blank value for tm_SHELL_ENV");
		cout << "Can not call service No preference defined to find env or having blank value for tm_SHELL_ENV";
		return "Can not call service No preference defined to find env or having blank value for tm_SHELL_ENV ";
	}

	
	TC_write_syslog("\nshellpath : [ %s ]",  shellpath.c_str());
	TC_write_syslog("\nshellName : [ %s ]",  shellName.c_str());
	TC_write_syslog("\nshellArg1 : [ %s ]",  shellArg1.c_str());
	TC_write_syslog("\nshellArg2 : [ %s ]",  shellArg2.c_str());

	
	TC_write_syslog("\nShellUsage : [ %s ].....",  ShellUsage);
	cout << ShellUsage << endl;
	//std::system ( ShellUsage );
	int ShellreturnCode = std::system ( ShellUsage );
	
    if (ShellreturnCode == 0) 
	{
        cout << "shell executed successfully" << endl;
		TC_write_syslog ( "\nshell executed successfully");
		if (PrefShellEnvName)
		{
			MEM_free(PrefShellEnvName);
		}
		if (ShellUsage)
		{
			free(ShellUsage);
		}
		TC_write_syslog("\nSuccessfully called service");
		return "shell executed successfully";
    }
    else 
	{
        cout << "shell execution failed" << ShellreturnCode << endl;
		TC_write_syslog ( "\nshell execution failed");
		if (PrefShellEnvName)
		{
			MEM_free(PrefShellEnvName);
		}
		if (ShellUsage)
		{
			free(ShellUsage);
		}
		TC_write_syslog("\nSuccessfully called service");
		return "shell execution failed";
    }
	//cout << "\nSuccessfully called service";
	//return "Successfully called service";
}



