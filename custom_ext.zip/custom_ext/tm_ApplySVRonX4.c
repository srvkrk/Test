		#define _CRT_SECURE_NO_DEPRECATE
		#define NUM_ENTRIES 1
		#define TE_MAXLINELEN  128 
		#include <epm/epm.h>
		#include <ae/dataset_msg.h>
		//#include <tccore/iman_msg.h>
		#include <ps/ps.h>
		#include <ae/datasettype.h>
		#include <ps/ps_errors.h>
		#include <unidefs.h>
		#include <time.h>
		#include <ai/sample_err.h>
		//#include <tc/tc.h>
		#include <tccore/grm_msg.h>
		#include <tccore/aom_prop.h>
		#include <tccore/workspaceobject.h>
		#include <bom/bom.h>
		#include <ae/dataset.h>
		#include <ps/ps_errors.h>
		#include <sa/sa.h>
		#include <stdarg.h>
		#include <stdio.h>
		#include <stdlib.h>
		#include <string.h>
		#include <sys/stat.h>
		#include <fclasses/tc_string.h>
		#include <tccore/item.h>
		#include <tccore/item_errors.h>
		#include <sa/tcfile.h>
		//#include <epm/releasestatus.h>
		#include <tcinit/tcinit.h>
		#include <tccore/tctype.h>
		#include <res/reservation.h>
		#include <tccore/aom.h>
		#include <tccore/custom.h>
		#include <tccore/project.h>
		#include <tc/emh.h>
		#include <cfm/cfm.h>
		#include <ict/ict_userservice.h>
		//#include <tc/iman.h>
		//#include <tccore/imantype.h>
		//#include <sa/imanfile.h>
		#include <lov/lov.h>
		#include <property/prop.h>
		#include <pie/pie.h>
		#include <lov/lov_msg.h>
		//#include <itk/mem.h>
		#include <ss/ss_errors.h>
		#include <sa/user.h>
		#include <tccore/grm.h>
		#include <textsrv/textserver.h>
		#include <string.h>
		//#include <epm/cr_effectivity.h>
		#include <tc/envelope.h>
		//#include <tc/emh_const.h>

		#define ITK_err 919002
		#define ITK_errStore (EMH_USER_error_base + 3)
		#define ITK_errStore1 (EMH_USER_error_base + 5)
		#define ITK_errStore2 (EMH_USER_error_base + 6)
		#define ITK_errErr1 (EMH_USER_error_base + 4)
		#define ITK_errErr (EMH_USER_error_base + 99)
		#define ITK_Prjerr (EMH_USER_error_base + 8)
		#define ITK_PLMError (EMH_USER_error_base + 21)
		#define CLTask_Err (EMH_USER_error_base + 21)
		#define CONNECT_FAIL (EMH_USER_error_base + 2)
		#define CALLAPI(expr)ITK_CALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
		#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))
		static int report_error( char *file, int line, char *function, int return_code)
		{
			if (return_code != ITK_ok)
			{
				int				index = 0;
				int				n_ifails = 0;
				const int*		severities = 0;
				const int*		ifails = 0;
				const char**	texts = NULL;

				EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
				printf("%3d error(s)\n", n_ifails);
				for( index=0; index<n_ifails; index++)
				{
					printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
					TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
					printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
					TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
				}
				EMH_clear_errors();
				
			}
			return return_code;
		}
		#define VOO_HASH_SIZE 4099
		#define MAX_INT_LENGTH 10      //maximum no of characters required to hold an integer
		#define ITK_errStore1 (EMH_USER_error_base + 5)
		#define PLM_error5 (EMH_USER_error_base+26)
		#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
		#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
			
			
			
			
typedef struct PartDetails {
	char partName[100];
	char Revision_ID[10];
	char Seq_ID[10];
	char description[400];
	char DRstatus[40];
	char Qty[40];
} PartDetails_ERC;			


PartDetails_ERC** PartDetailsArray;
int ERC_Index = 0;

void PushIntoArrayOfStructure(PartDetails_ERC* Details) {
    PartDetailsArray = (PartDetails_ERC**)realloc(PartDetailsArray, (ERC_Index + 1) * sizeof(PartDetails_ERC*));
    PartDetailsArray[ERC_Index] = Details;
    ERC_Index = ERC_Index + 1;
}
void setAddStrFuction(int *count,char ***strset,char* str)
{

	*count=*count+1;
	printf("\n setAddStrFuction %d",*count);fflush(stdout);
	if(*count==1)
	{
		(*strset) = (char **)malloc((*count ) * sizeof(char *));
	}
	else
	{
		(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
	}
	(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
	 tc_strcpy((*strset)[*count-1],str);
	 printf("\n setAddStrFuction===%s",(*strset)[*count-1]);fflush(stdout);

}	

typedef struct PartDetailsMulti {
    char partName[100];
    char Revision_ID[10];
    char Seq_ID[10];
    char description[400];
    char DRstatus[40];
    char Qty[40];
} PartDetails_APLMultiexpan;

PartDetails_APLMultiexpan** PartDetailsArrayAPLMul;
int APLMulti_Index = 0;

void PushIntoArrayOfStructureAPLMul(PartDetails_APLMultiexpan* Details) {
    // Allocate new memory for the array of structures
    PartDetailsArrayAPLMul = (PartDetails_APLMultiexpan**)realloc(PartDetailsArrayAPLMul, (APLMulti_Index + 1) * sizeof(PartDetails_APLMultiexpan*));

    // Allocate new memory for the current structure
    PartDetailsArrayAPLMul[APLMulti_Index] = (PartDetails_APLMultiexpan*)malloc(sizeof(PartDetails_APLMultiexpan));

    // Copy the data into the newly allocated structure
    memcpy(PartDetailsArrayAPLMul[APLMulti_Index], Details, sizeof(PartDetails_APLMultiexpan));

    APLMulti_Index = APLMulti_Index + 1;
}

int sizeA , sizeB ;

struct BOM_Compare {
	char partName[100];
	char Revision_ID[10]; 
	char description[400];
    //char sequence;
	char Qty[40];
};
struct BOM_Compare *ERCBOM = NULL;
struct BOM_Compare *APLBOM = NULL;


// Function to read BOM_Compare data
struct BOM_Compare BOM_Compare_Data(int index) 
{
    struct BOM_Compare bomstore;
    printf("Enter data for BOM_Compare %d (part_no,Revision,Sequence,description ETC...): ", index);
	//bomstore[childIterator].part_no;...
	
	bomstore.partName;
	bomstore.Revision_ID;
	bomstore.description;
	bomstore.Qty;
	    return bomstore;
}

tag_t SetOfParts[10000];
tag_t CsNulsetOfObj[10000];
int     PartIndex           =   0;

struct BOM_Compare *ERC_BOM_Compare = NULL;
struct BOM_Compare *APL_BOM_Compare = NULL;
int sizeA = 0, sizeB = 0;

void FreeArrayOfStructureAPLMul() {
	int i;
    for (i = 0; i < APLMulti_Index; ++i) 
	{
        printf("\n FreeArrayOfStructureAPLMul structure is now having free %d", i);
        free(PartDetailsArrayAPLMul[i]);
    }


    free(PartDetailsArrayAPLMul);
	printf("\n structure 12323");
    APLMulti_Index = 0; // Reset the index to zero after freeing the memory

    PartDetailsArrayAPLMul = NULL;
	
}

void FreeArrayOfStructureAPLMul2() {
	int i;
    for (i = 0; i < ERC_Index; ++i) 
	{
        printf("\n FreeArrayOfStructureAPLMul2 structure is now having free %d", i);
        free(PartDetailsArray[i]);
        
    }
	
    free(PartDetailsArray);
	
    ERC_Index = 0; // Reset the index to zero after freeing the memory

    PartDetailsArray = NULL;

}
		char* subString (char* mainStringf ,int fromCharf,int toCharf);


		int ifail = ITK_ok;
		int QuantityAttrId=0;
		char *ClrSchmToVf = NULL;
		char *NoColSchemeMatchPrts = NULL;
		tag_t tsk_HSI_rel_type = NULLTAG;
		tag_t tRelationFind = NULLTAG;
		tag_t windowClr = NULLTAG;
		tag_t ruleNC = NULLTAG;
		tag_t ClrPartQryTag = NULLTAG;
		tag_t qryCTOTag = NULLTAG;
		tag_t SchmqueryTag = NULLTAG;
		tag_t GeneralQryTag = NULLTAG;
		tag_t SchmWithCmpcdRel = NULLTAG;
		char *info7ClrSchmMsg=NULL;
		char *info2SchmCre=NULL;
		char *SchDataToGov = NULL;
		FILE* fpCLLog=NULL;
		FILE* fpCLErrLog=NULL;
		static int name_attribute;
		char *FullAdvString;
		char *CorrCmpBOMCnt;
		char *DiffCmpBOMCnt;
		char *NonClrBOMArr;
		char *ClrBOMArr;
		char *ClrBOMArrSVR;
		char *NClrBOMArrSVR;
		char *DiffCmpBOMCntSVR;
		char *CorrCmpBOMCntSVR;
		char *wFileClrBOMArr		= NULL;
		char *wFileNClrBOMArr		= NULL;
		int		n_Cnt;
		int		n_Cnt1;
		int		n_lines1;			
		int		n_lines2;
		int		n_lines1SVR;
		int		n_lines2SVR;
		tag_t *tagSET;
		int ia =0;
		char **sFinalDataSet;
		char **sFinalDataSetClr;

		tag_t *tagSETNClr;
		int iaNClr =0;
		char **sFinalDataSetNClr;

		tag_t	*tagSETClrSVR;
		int		iaClrSVR =0;
		char	**sFinalDataSetClrSVR;

		tag_t *tagSETNClrSVR;
		int iaNClrSVR =0;
		char **sFinalDataSetNClrSVR;
		char *SVRNClr =NULL;
		FILE  *output   = NULL;
		char  allItemArchNode[1900]     = { 0 };
		
		int tm_ProcessColourPartCL(int taskCnt, tag_t *Dml_tasks, tag_t Dml_task, int NCAssyChildFlag, tag_t NonClrPartTag, char *NewColourPart, char *DMLProject);
		int tmvp_ClrNonClrMismatchRpt(tag_t dmlTag, tag_t t_dml_Task);
		int ClrBOMExpansion(tag_t top_line);
		int NonClrBOMExpansion(tag_t NonClrRev_t );
		int CmpBomAndClrBOM(tag_t dmlRevTag);
		int BOMExpantion(char* Platform,char* SVR,char* RevisionRule,tag_t ColSchmRevTag);
		int CmpBomSVRAndClrBOMSVR(tag_t dmlRevTag);
		int DMLTaskRelation(tag_t dmlRevTag ,tag_t ColSchmRevTag);
		int  ClrSCM_BOMExpansion(tag_t	top_line ,tag_t ColSchmRevTag);
		int t5GetExpChildAPLSingle(tag_t itemRev, tag_t tNonClr_Rule);
		int t5GetExpChildERC(tag_t itemRev, tag_t tColourRule);
		int SVRCLRBOMExpantion(char* Platform,char* SVR,char* RevisionRule,tag_t ColSchmRevTag);
		int Check_ERCModPresent(tag_t TaskTag, int PartCnt, tag_t* PartTags,char	***SetChildRelAPLModErr,int *icount_aplModCheck);
		int Check_ERCModuleDuplicate(tag_t TaskTag, int PartCnt, tag_t* PartTags,char	***SetChildRelAPLModErr,int *icount_ebommbom_bom);
		int Check_ERCModuleQTY(tag_t TaskTag, int PartCnt,tag_t* PartTags,char	***SetChildRelAPLModErr,int *icount_ebommbom_bom);
		int Check_ERCModuleColourSuffix(tag_t TaskTag,int PartCnt, tag_t* PartTags,char ***SetChildRelAPLModErr,int *icount_ebommbom_bom);
		int Check_ERCModSuppress1(tag_t TaskTag, int PartCnt,char *signOffDept,tag_t* PartTags,char ***SetChildRelAPLModErr,int *icount_ebommSupp);
		int tm_setAttributesOnDesignRev2(tag_t* rev,char* desc,char* ColourIndS,char* t5PrtCatCodeS,char* t5ColourIDS,char* t5CoatedS,char* t5PartStatusS,char* designgroup,char* projectcode,char* mod_desc,char* DrawingIndS,char * PartTypeS,char * t5PartCodeS,char * t5AhdMakeBuyIndS,char * t5PunPCBUMakeBuyIndS,char * t5PunMakeBuyIndS,char * t5DwdMakeBuyIndS,char * NonColorPart);
		int tm_CreateReleasestatus(tag_t ColourRev);
		int tm_AssignProject(tag_t  itemRev,char* projectcode);
		int ValColAndNonColBomForRevise_CL(tag_t NonClrRev,tag_t Clrrev,int ColRevRlzStatus, tag_t ColSchmRevTag);
		int SVRNONCLRBOMExpantion(char* PlatformSVR,char* NCLRSVR,char* RevisionRuleClrSVR,tag_t ColSchmRevTag);
		tag_t GetLatestRevinSet(tag_t* SetofRev, int Count);

		static int PrintErrorStack( void )
		/*
		*
		* PURPOSE : Function to dump the ITK error stack
		*
		* RETURN : causes program termination. If you made it here
		*          you're not coming back modified for cust.c to not call exit()
		*          but to just print the error stack
		*
		* NOTES : This version will always return ITK_ok, which is quite strange
		*           actually. But if the error reporting was "OK" then that makes
		*           sense
		*
		*/
		{
		int iNumErrs = 0;
		const int *pSevLst;
		const int *pErrCdeLst;
		const char **pMsgLst;
		register int i = 0;

		EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
		//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
		for ( i = 0; i < iNumErrs; i++ )
		{
			fprintf( stderr, "Error(PrintErrorStack): \n");
			fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		}
		return ITK_ok;
		}
	//	static void initialise_attribute (char *name,  int *attribute) //TCUA14.3
	//	{
	//		int ifail, mode;
	//
	//if(BOM_line_look_up_attribute (name, attribute)!=ITK_ok)PrintErrorStack();
	//		if(BOM_line_ask_attribute_mode (*attribute, &mode)!=ITK_ok)PrintErrorStack();
	//
	//		if (mode != BOM_attribute_mode_string)
	//		  { printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode);
	//			exit(0);
	//		  }
	//	}

		struct BomChldStrut
		{
			tag_t child_objs;//CHild
			tag_t child_objs_bvr;//BVR
			int child_objs_lvl;//LVL
		}*get_BomChldStrut;

		int SendMailToUser(char* sTaskName)
		{
		 tag_t envelop_tag		= NULLTAG;
		 tag_t env_input_tag		= NULLTAG;
		 tag_t Envelop_object	= NULLTAG;
		 tag_t user_tag = NULLTAG;
		 
			char* user_email = NULL;
			char* mail_subject	= NULL;
			char* mail_body		= NULL;
			char* username		= NULL;
			tag_t person_tag		= NULLTAG;
		 
			mail_subject	= (char *) MEM_alloc(100 * sizeof(char ));
			mail_body		= (char *) MEM_alloc(250 * sizeof(char ));	
		 
			ITK_CALL(SA_find_user2("skk03433",&user_tag));
			if(user_tag != NULLTAG )
			{
				ITK_CALL(SA_ask_user_person_name2(user_tag,&username));
				ITK_CALL(SA_find_person2(username,&person_tag));
				ITK_CALL(SA_ask_person_email_address(person_tag,&user_email));	
			}
			printf("\nusername : %s user_email : %s",username,user_email);
		 
			printf("\n sTaskName : %s",sTaskName);	
			tc_strcpy(mail_subject,"CL Task is created.");
			tc_strcat(mail_body,sTaskName);
		 
			printf("\n mail_subject : %s",mail_subject);
			printf("\n mail_body : %s",mail_body);
		 
			ITK_CALL(TCTYPE_find_type("Envelope", NULL, &envelop_tag));   
			ITK_CALL(TCTYPE_construct_create_input(envelop_tag, &env_input_tag));
		 
			ITK_CALL(AOM_set_value_string(env_input_tag,"object_name",mail_subject));
			ITK_CALL(AOM_set_value_string(env_input_tag,"object_desc",mail_body));
			
			ITK_CALL(TCTYPE_create_object(env_input_tag, &Envelop_object));
		 
			if(Envelop_object)
			{
				printf("\nEnvelop_object : object created.");
				ITK_CALL(AOM_save_without_extensions(Envelop_object));
				ITK_CALL(AOM_refresh(Envelop_object,FALSE));
			}
		 
			ITK_CALL(AOM_refresh(Envelop_object,TRUE));
			ITK_CALL(MAIL_add_external_receiver(Envelop_object,MAIL_send_to,user_email));
			ITK_CALL(AOM_save_without_extensions(Envelop_object));
			ITK_CALL(AOM_refresh(Envelop_object,FALSE));
			//ITK_CALL(AOM_refresh(Envelop_object,0));
			ITK_CALL(MAIL_send_envelope(Envelop_object));
			printf("\nMAIL_send_envelope calling---------->");
		 
			return ITK_ok;
		 }
		 
		 typedef struct
		 {
			int     size;
			int     capacity;
			int     increment;
			void  **content;
		 } vector_t;
		 
		 struct modstruct
		  {  
			   //part details
		 
				char parent_part[100];
				int child;
		 
		  } childstr[10000];
		 
		 typedef vector_t *variant_rule_option_data_t[VOO_HASH_SIZE];
		 static vector_t *vector_new( int capacity, int increment );
		 static vector_t *vector_add( vector_t *v, void *element );
		 static vector_t *vector_add_n( vector_t *v, int n, void *elements[] );
		 static vector_t *vector_ensure_capacity( vector_t *v, int n );
		static vector_t *vector_free( vector_t *v );
		static vector_t *vector_insert( vector_t *in, void *element );
		static vector_t *vector_insert_n_at( vector_t *in, int n, void *elements[], int at );
		static void *vector_get( const vector_t *v, int index );
		static int vector_size( const vector_t *v );
		static int vector_rem_at( vector_t *in, int n );
		static int vector_rem_n_at( vector_t *in, int n, int at );
		static int       VOO_debug                     = FALSE;
		static char     *VOO_prog                      = (char *)"UnitBOM";

		char* subString (char* mainStringf ,int fromCharf,int toCharf)
		{
			int i;
			char *retStringf;
			retStringf = (char*) malloc(200);
			for(i=0; i < toCharf; i++ )
					  *(retStringf+i) = *(mainStringf+i+fromCharf);
			*(retStringf+i) = '\0';
			return retStringf;
		}

		static double token_to_double ( const char *str )
		{
			return strtod( str, NULL);
		}

		#define ITK(x)                                                             \
		{                                                                          \
			if ( stat == ITK_ok )                                                  \
			{                                                                      \
				if ( (stat = (x)) != ITK_ok )                                      \
				{                                                                  \
					handle_itk_error( stat, __LINE__, __FILE__ );                  \
				}                                                                  \
			}                                                                      \
					}

		void setAddStrInApplySVRonX4(int *count,char ***strset,char* str)
		{
			*count=*count+1;
			printf("\n setAddStrInApplySVRonX4 %d",*count);fflush(stdout);
			if(*count==1)
			{
				(*strset) = (char **)malloc((*count ) * sizeof(char *));
			}
			else
			{
				(*strset) = (char **)realloc((*strset),(*count ) * sizeof(char *));
			}
			(*strset)[*count-1] = malloc((strlen(str)+1) * sizeof(char));
			 tc_strcpy((*strset)[*count-1],str);
			 printf("\n setAddStrInApplySVRonX4===%s",(*strset)[*count-1]);fflush(stdout);
		}
		void setAddStr1(int *count1,char ***strset1,char* str1)
		{

			*count1=*count1+1;
			if(*count1==1)
			{
				(*strset1) = (char **)malloc((*count1 ) * sizeof(char *));
			}
			else
			{
				(*strset1) = (char **)realloc((*strset1),(*count1 ) * sizeof(char *));
			}
			(*strset1)[*count1-1] = malloc((strlen(str1)+1) * sizeof(char));
			 tc_strcpy((*strset1)[*count1-1],str1);

		}
int CompareColorToBase7(tag_t TaskTag,char *signOffDept ,int PartCnt, tag_t* PartTags,char ***SetChildRelAPLModErr,int *icount_ebommbom_bom)//Check Nilesh
{
	EPM_decision_t decision;
	tag_t			AssyTag				= NULLTAG;
	tag_t			parents_tag				= NULLTAG;
	char*			partType				= NULL;
	char*			partItemId				= NULL;
	char*			partItemId_rev				= NULL;
	char*			ParetnName				= NULL;
	char*			ParetnRevId				= NULL;
	char*			ParetnPrtType				= NULL;
	char*			colourVCSuffixVal				= NULL;
	tag_t   qryTagCntrlBiw     = NULLTAG;
	//char    *qry_entryCntrlBiw[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char    *qry_entryCntrlBiw[2]  = {"SYSCD","SUBSYSCD"};	
	char	**qry_valuesCntrlBiw= (char **) MEM_alloc(5 * sizeof(char *));
	int		*levels					=	0;

	int cntrlcnt=0;
	int  control_number_foundBiw=0;
	int		n_parents					=	0;
	int		ck					=	0;
	int		*levels_prnt					=	0;



	tag_t *list_of_WSO_cntrl_tagsBiw=NULLTAG;

	int     n_entryCntrlBiw    = 2;

	//char    *qry_entryCntrlPT[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char    *qry_entryCntrlPT[2]  = {"SYSCD","SUBSYSCD"};	
	char	**qry_valuesCntrlPT= (char **) MEM_alloc(5 * sizeof(char *));

	int  control_number_foundPT=0;

	tag_t *list_of_WSO_cntrl_tagsPT=NULLTAG;

	int     n_entryCntrlPT    = 2;

	char*		aplModule1	=	NULL;
	char*		aplModule2	=	NULL;
	char*		aplPTModule	=	NULL;
	char*		ercPTModule	=	NULL;
	char*		viewmask	=	NULL;
	char*		revisionRule	=	NULL;
	char*		revisionRuleSTD	=	NULL;
	char		*value_itemid=NULL;
	char		*value_itemRevID=NULL;
	char		*value_itemRevPartType=NULL;
	char		*colourAPLModSuffixVal=NULL;
	char*		Item_ID_Check	=	NULL;
	tag_t   window					=	NULLTAG;
	tag_t	rule								= NULLTAG;
	tag_t			bvr_tag= NULLTAG;
	tag_t	top_line							= NULLTAG;
	int		nClhd=0;
	tag_t  *children;
	tag_t Bomline_tag = NULLTAG;
	int k =0; 
	int jp=0; 
	tag_t	*parents				=	NULLTAG;

	int icountErr =0; 
	int iChildItemTag=0;
	int errFlag=0;
	tag_t   t_ChildItemRev = NULLTAG;
	char*		ErrString	=	NULL;
	char*		value_itemColInd	=	NULL;
	tag_t revRule 			= NULLTAG;


	printf("\n\n\t\t Nilesh: inside Bom Complte CHeck  fucntion:::%s",signOffDept);fflush(stdout);

	if( QRY_find2("Control Objects...", &qryTagCntrlBiw));
	if (qryTagCntrlBiw)
	{
		printf("\n Control Object Query Found Bom Complte CHeck  \n");fflush(stdout);
		qry_valuesCntrlBiw[0]="ERC_BOM_Complt_Chk";
		qry_valuesCntrlBiw[1]="ClrBomCmtCHk";
		//qry_valuesCntrlBiw[2]="0";

		if(QRY_execute(qryTagCntrlBiw, n_entryCntrlBiw, qry_entryCntrlBiw, qry_valuesCntrlBiw, &control_number_foundBiw, &list_of_WSO_cntrl_tagsBiw));

		
	}
	else
	{
		printf("\n Control Object Query not Found  Bom Complte CHeck  \n");fflush(stdout);
	}
	printf("\n NP control_number_foundBiw Bom Complte CHeck is : %d",control_number_foundBiw);fflush(stdout);
	if (qryTagCntrlBiw)
	{	
		qry_valuesCntrlPT[0]="ERC_BOMChk";
		qry_valuesCntrlPT[1]="SignOffValidationClrCL";
		//qry_valuesCntrlPT[2]="0";

		if(QRY_execute(qryTagCntrlBiw, n_entryCntrlPT, qry_entryCntrlPT, qry_valuesCntrlPT, &control_number_foundPT, &list_of_WSO_cntrl_tagsPT));
	}
	else
	{
		printf("\n NP Control Object Query not Found  Bom Complte CHeck  \n");fflush(stdout);
	}

	
	printf("\n control_number_foundPT [%d]\n",control_number_foundPT);fflush(stdout);

	if(control_number_foundBiw>0)
	{
		
		if(control_number_foundPT>0)
		{
		
			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo1", &aplModule1));
			printf("\n ERCModule1: %s\n",aplModule1);fflush(stdout);

			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo2", &aplModule2));
			printf("\n ERCModule2: %s\n",aplModule2);fflush(stdout);

			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo3", &viewmask));
			printf("\n viewmask: %s\n",viewmask);fflush(stdout);

			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo4", &revisionRule));
			printf("\n revisionRule: %s\n",revisionRule);fflush(stdout);

			ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo5", &revisionRuleSTD));
			printf("\n revisionRuleERC: %s\n",revisionRuleSTD);fflush(stdout);

			if(tc_strcmp(signOffDept,"ERC")==0)
			{
				ITKCALL(CFM_find(revisionRule, &revRule));
				if (revRule != NULLTAG)
				{
					printf("\nFind revRule\n");fflush(stdout);
				}
			}
			else if(tc_strcmp(signOffDept,"STD")==0)
			{
				ITKCALL(CFM_find(revisionRuleSTD, &revRule));
				if (revRule != NULLTAG)
				{
					printf("\nFind revRule\n");fflush(stdout);
				}
			}

		}


		for (k=0;k<PartCnt ;k++ )// colour part loop
		{

			printf("\n\n\t\t inside Check_ERCModuleDuplicate ERC DML Cre:for k_4 =:%d",k);fflush(stdout);
			AssyTag=NULLTAG;
			AssyTag=PartTags[k]; // PartTags tag of all colour part

			partType=NULL;
			partItemId=NULL;
			partItemId_rev=NULL;

			ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&partType));
			printf("\n partType:%s ..............",partType);fflush(stdout);

			ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&partItemId));
			printf("\n partItemId:%s ..............",partItemId);fflush(stdout);

			ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&partItemId_rev));
			printf("\n partItemId_rev:%s ..............",partItemId_rev);fflush(stdout);
				ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&partItemId_rev));
			printf("\n partItemId_rev:%s ..............",partItemId_rev);fflush(stdout);

			//if((tc_strcmp(partType,"V")==0))	
			
				printf("\n Inside PartType Check");fflush(stdout);

				ITKCALL(PS_where_used_configured(AssyTag,revRule,1,&n_parents,&levels_prnt,&parents));

				printf("\n\n\t\t No of Assy objects are n_parents : %d\n",n_parents);fflush(stdout);
				if(n_parents>0)
				{
					for(jp=0;jp<n_parents;jp++)
					{
						parents_tag=NULLTAG;
						parents_tag=parents[jp];
						
						if(parents_tag!=NULLTAG)
						{
							ParetnName=NULL;
							ParetnPrtType=NULL;
							colourVCSuffixVal=NULL;
							ParetnRevId=NULL;

							ITKCALL(AOM_ask_value_string(parents_tag,"item_id",&ParetnName));
							printf("\n Fparents %s",ParetnName);fflush(stdout);
							
							ITKCALL(AOM_ask_value_string(parents_tag,"item_revision_id",&ParetnRevId));
							printf("\n ParetnRevId %s",ParetnRevId);fflush(stdout);

							ITKCALL(AOM_ask_value_string(parents_tag,"t5_PartType",&ParetnPrtType));
							printf("\n ParetnPrtType:%s ..............",ParetnPrtType);fflush(stdout);
							if((tc_strcmp(ParetnPrtType,"VC")==0))	
							{
								colourVCSuffixVal=subString(ParetnName,tc_strlen(ParetnName)-3,2);	
								printf("\n colourVCSuffixVal:%s ..............",colourVCSuffixVal);fflush(stdout);
								break;
							
							}

						
						}
					}
                      int Cmpcount =0;
                      tag_t   ClrtBaseRel = NULLTAG;
                      tag_t   BasePArt_tag = NULLTAG;
					  tag_t	*BasePArts	=	NULLTAG;
				ITKCALL(GRM_find_relation_type("TC_Is_Represented_By",&ClrtBaseRel));
				ITKCALL(GRM_list_secondary_objects_only(AssyTag, ClrtBaseRel, &Cmpcount, &BasePArts));
				printf("\n Comp Code Cmpcount for Color Scheme : %d\n",Cmpcount); fflush(stdout);
				if (Cmpcount>0)
				{

					BasePArt_tag=BasePArts[0];//base part tag Nilesh continue

				}
				
					//Colour part BOM 
					ITKCALL(BOM_create_window (&window));
					printf("\n find occurence..window");fflush(stdout);
					//ITKCALL(CFM_find(revisionRule, &rule));
					//printf("\n find occurence..rule");fflush(stdout);
					ITKCALL(BOM_set_window_config_rule( window, revRule ));
					printf("\n configure occurence..rule");fflush(stdout);
					ITKCALL(BOM_set_window_top_line(window, null_tag,AssyTag , bvr_tag, &top_line));
					ITKCALL(BOM_line_ask_child_lines (top_line, &nClhd, &children));
					printf("\n nClhd %d,",nClhd);fflush(stdout);

					for (ck = 0; ck < nClhd; ck++)				//Vehicle BOM
					{
						//get the revision from bomline
						ITKCALL(BOM_line_pack (children[ck]));

						t_ChildItemRev=NULLTAG;

						//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag)); //API Change
						//ITKCALL(BOM_line_ask_attribute_tag(children[ck], iChildItemTag, &t_ChildItemRev)); //API Change
						ITKCALL(AOM_ask_value_tag(children[ck],bomAttr_lineItemRevTag, &t_ChildItemRev));
						if(t_ChildItemRev!=NULLTAG)
						{

							Bomline_tag=NULLTAG;
							Bomline_tag = children[ck];



							if(Bomline_tag!=NULLTAG)
							{
								value_itemid=NULL;
								value_itemRevID=NULL;
								value_itemRevPartType=NULL;
								value_itemColInd=NULL;
								Item_ID_Check=NULL;
								colourAPLModSuffixVal=NULL;
								value_itemid=(char *) MEM_alloc(200 * sizeof(char *));
								colourAPLModSuffixVal=(char *) MEM_alloc(200 * sizeof(char *));

								ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&value_itemid))
								printf("\n CompareColorToBase7 Arc Node child value_itemid:%s ..............",value_itemid);fflush(stdout);								

								ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&value_itemRevID))
								printf("\n CompareColorToBase7 value_itemRevID:%s ..............",value_itemRevID);fflush(stdout);

								ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartType",&value_itemRevPartType))
								printf("\n CompareColorToBase7 value_itemRevPartType:%s ..............",value_itemRevPartType);fflush(stdout);

								ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_ColourInd",&value_itemColInd))
								printf("\n CompareColorToBase7 value_itemColInd:%s ..............",value_itemColInd);fflush(stdout);

                 if(BasePArt_tag!=NULLTAG)
					{

	                char*		ParetnNameB	=	NULL;
	                char*		ParetnRevIdB	=	NULL;
	               char*		value_itemidB	=	NULL;
	               char*		value_itemid2	=	NULL;
	                tag_t   window2					=	NULLTAG;
					int nClhdB,ckB,iChildItemTagB =0;
						tag_t			bvr_tagB= NULLTAG;
	                    tag_t	     top_lineB	= NULLTAG;
	                    tag_t	     t_ChildItemRevB= NULLTAG;
	                    tag_t	     Bomline_tagB= NULLTAG;
						tag_t  *childrenB;

						value_itemid2=(char *) MEM_alloc(200 * sizeof(char *));


					 		ITKCALL(AOM_ask_value_string(BasePArt_tag,"item_id",&ParetnNameB));
							printf("\n CompareColorToBase7 ParetnNameB %s",ParetnNameB);fflush(stdout);
							
							ITKCALL(AOM_ask_value_string(BasePArt_tag,"item_revision_id",&ParetnRevIdB));
							printf("\n CompareColorToBase7 ParetnRevIdB %s",ParetnRevIdB);fflush(stdout);
									
					ITKCALL(BOM_create_window (&window2));
					printf("\n CompareColorToBase7 find occurence..window2");fflush(stdout);
					//ITKCALL(CFM_find(revisionRule, &rule));
					printf("\n CompareColorToBase7 find occurence..rule2");fflush(stdout);
					ITKCALL(BOM_set_window_config_rule( window2, revRule ));
					printf("\n CompareColorToBase7 configure occurence..rule2");fflush(stdout);
					ITKCALL(BOM_set_window_top_line(window2, null_tag,BasePArt_tag , bvr_tagB, &top_lineB));
					ITKCALL(BOM_line_ask_child_lines (top_lineB, &nClhdB, &childrenB));
					printf("\n CompareColorToBase7 nClhdB %d,",nClhdB);fflush(stdout);
					
					int childmatchflg=0;
					for (ckB = 0; ckB < nClhdB; ckB++)
						{
								

						ITKCALL(BOM_line_pack (childrenB[ckB]));

						t_ChildItemRevB=NULLTAG;

						//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTagB)); //API Change
						//ITKCALL(BOM_line_ask_attribute_tag(childrenB[ckB], iChildItemTagB, &t_ChildItemRevB)); //API Change
						ITKCALL(AOM_ask_value_tag(childrenB[ckB],bomAttr_lineItemRevTag, &t_ChildItemRevB));
						if(t_ChildItemRevB!=NULLTAG)
						{

							Bomline_tagB=NULLTAG;
							Bomline_tagB = childrenB[ckB];							
							value_itemidB=NULL;
							value_itemidB=(char *) MEM_alloc(200 * sizeof(char *));



							if(Bomline_tagB!=NULLTAG)
							{
							ITKCALL(AOM_ask_value_string(t_ChildItemRevB,"item_id",&value_itemidB))
								printf("\n CompareColorToBase7 111 Arc Node child value_itemidB:%s ..............",value_itemidB);fflush(stdout);

                        if (tc_strcmp(value_itemColInd,"C")==0)
								{
						       colourAPLModSuffixVal=subString(value_itemid,0,tc_strlen(value_itemid)-2);	
									printf("\n CompareColorToBase7 Base part is :%s ..............%s:",colourAPLModSuffixVal,colourVCSuffixVal);fflush(stdout);
									tc_strcpy(value_itemid2,colourAPLModSuffixVal);
									printf("\n CompareColorToBase7 CCC part No for Compare is=%s ..............",value_itemid2);fflush(stdout);
						        }
							if( (tc_strcmp(value_itemColInd,"N")==0)||(tc_strcmp(value_itemColInd,"Y")==0) )       //Added by vaibhav_CR-FY23-0211
								{
                                 tc_strcpy(value_itemid2,value_itemid);
								 printf("\n CompareColorToBase7 BBB part No for Compare is=%s ..............",value_itemid2);fflush(stdout);
								}

							if(tc_strcmp(value_itemid2,value_itemidB)==0)
							{
                              printf("\n CompareColorToBase7 Child Color= %s and  Child base= %s are matching hence going to next Child: ..............",value_itemid2,value_itemidB);fflush(stdout);
							  // add qty mismatch logic
							  childmatchflg=1;
							  goto NextChild;
							
							}
							

							}
						}
								}
								if (childmatchflg==0)
								{
										errFlag++;
										ErrString=NULL;
										ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemid)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+tc_strlen(ParetnNameB)+tc_strlen(ParetnRevIdB)+550);
										if(errFlag==1)
										{
											tc_strcpy(ErrString,"Colour BOM is not inline with Base BOM, Kindly raise ticket in TCUA Colour Module category in TMS:\n");
										}
										else
										{
											tc_strcpy(ErrString,"");	
										}
										
										tc_strcat(ErrString,value_itemid);
										tc_strcat(ErrString," in colour part ");
										tc_strcat(ErrString,partItemId);
										tc_strcat(ErrString,";");
										tc_strcat(ErrString,partItemId_rev);
										tc_strcat(ErrString,"is not present in Base Vehicle ");
										tc_strcat(ErrString,ParetnNameB);
										tc_strcat(ErrString,";");
										tc_strcat(ErrString,ParetnRevIdB);
										tc_strcat(ErrString,".\n");
										setAddStrFuction(icount_ebommbom_bom,SetChildRelAPLModErr,ErrString);


								}
					
			


							}
                      NextChild:;
				
							}
						}
					}
				}


			
		}// colour part loop
		int childmatchflg, basecnt, Bschldcnt,nClhd7, c7,ck7,z7 =0;
		int childmatchflg_qty =0;
		int iQty7 =0;
		int iQTY_b =0;
		tag_t ClrTag = NULLTAG;
		tag_t bvr_tag1 = NULLTAG;
		tag_t Bomline_tag7 = NULLTAG;
		tag_t top_line7 = NULLTAG;
		tag_t t_ChildItemRev7 = NULLTAG;
		tag_t window3 = NULLTAG;
		tag_t BvrTag = NULLTAG;
		tag_t window7 = NULLTAG;
		tag_t Bomline_tagB = NULLTAG;
		tag_t TopLineB = NULLTAG;
		tag_t ChildItemRevB7 = NULLTAG;
		tag_t Base_PartTag = NULLTAG;
		tag_t ClrtBaseRel1 = NULLTAG;
		tag_t *Repbprts = NULLTAG;
		tag_t *Bschldtags = NULLTAG;
		tag_t *children7 = NULLTAG;
		char* partItemId1 = NULL;
		char* value_itemid7=NULL;
		char* value_itemRevID7=NULL;
		char* value_itemRevPartType7=NULL;
		char* value_itemColInd7=NULL;
		char* ParetnRevIdB1 = NULL;
		char* ParetnNameB1 = NULL;
		char* colourAPLModSuffixVal7 = NULL;
		char* value_itemidB = NULL;
		char* QTY_b = NULL;
		char* Qty7 = NULL;
		char* partItemId_rev1 = NULL;
		char* value_itemid27 = NULL;
		value_itemid27=(char *) MEM_alloc(200 * sizeof(char *));
		
		//add base part logic
		printf("\n PartCnt %d \n",PartCnt); fflush(stdout);
		if (PartCnt>0)
		{
			for (c7=0;c7<PartCnt ;c7++ )// colour part loop
			{
				printf("\n CompareColorToBase7 checking colour part is present in base or not\n"); fflush(stdout);

				ClrTag=PartTags[c7]; // PartTags tag of all colour part
				ITKCALL(AOM_ask_value_string(ClrTag,"item_id",&partItemId1));
				printf("\n CompareColorToBase7 partItemId1:%s ..............",partItemId1);fflush(stdout);
				ITKCALL(AOM_ask_value_string(ClrTag,"item_revision_id",&partItemId_rev1));
				printf("\n CompareColorToBase7 partItemId_rev1:%s ..............",partItemId_rev1);fflush(stdout);
				ITKCALL(GRM_find_relation_type("TC_Is_Represented_By",&ClrtBaseRel1));
				ITKCALL(GRM_list_secondary_objects_only(ClrTag, ClrtBaseRel1, &basecnt, &Repbprts));
				printf("\n CompareColorToBase7 represented by part count : %d\n",basecnt); fflush(stdout);
				if (basecnt>0)
				{

					Base_PartTag=Repbprts[0];//base part tag Nilesh continue

				}
				if (Base_PartTag)
				{
					ITKCALL(AOM_ask_value_string(Base_PartTag,"item_id",&ParetnNameB1));
					printf("\n CompareColorToBase7 ParetnNameB1:%s ..............",ParetnNameB1);fflush(stdout);
					ITKCALL(AOM_ask_value_string(Base_PartTag,"item_revision_id",&ParetnRevIdB1));
					printf("\n CompareColorToBase7 ParetnRevIdB1:%s ..............",ParetnRevIdB1);fflush(stdout);
					ITKCALL(BOM_create_window (&window3));
					printf("\n CompareColorToBase7 find occurence..window3");fflush(stdout);
					//ITKCALL(CFM_find(revisionRule, &rule));
					printf("\n CompareColorToBase7 find occurence..rule2");fflush(stdout);
					ITKCALL(BOM_set_window_config_rule( window3, revRule ));
					printf("\n CompareColorToBase7 configure occurence..rule2");fflush(stdout);
					ITKCALL(BOM_set_window_top_line(window3, null_tag,Base_PartTag , BvrTag, &TopLineB));
					ITKCALL(BOM_line_ask_child_lines (TopLineB, &Bschldcnt, &Bschldtags));
					printf("\n Bschldcnt %d,",Bschldcnt);fflush(stdout);
					if (Bschldcnt>0)
					{
						for (z7=0;z7<Bschldcnt ;z7++ )
						{
							ITKCALL(BOM_line_pack (Bschldtags[z7]));
							ChildItemRevB7=NULLTAG;

							ITKCALL(AOM_ask_value_tag(Bschldtags[z7],bomAttr_lineItemRevTag, &ChildItemRevB7));
							if(ChildItemRevB7!=NULLTAG)
							{

								Bomline_tagB=NULLTAG;
								Bomline_tagB = Bschldtags[z7];							
								value_itemidB=NULL;
								value_itemidB=(char *) MEM_alloc(200 * sizeof(char *));



								if(Bomline_tagB!=NULLTAG)
								{
									ITKCALL(AOM_ask_value_string(ChildItemRevB7,"item_id",&value_itemidB))
										printf("\n CompareColorToBase7 111 Arc Node child value_itemidB:%s ..............",value_itemidB);fflush(stdout);

									ITKCALL(AOM_ask_value_string(Bomline_tagB,"bl_quantity",&QTY_b))//Base qty
										printf("\n CompareColorToBase7 111 Arc Node child QTY_b:%s ..............",QTY_b);fflush(stdout);
										iQTY_b=atoi(QTY_b);
										printf("\n CompareColorToBase7 111 Arc Node child iQTY_b:%d ..............",iQTY_b);fflush(stdout);

									//call colour structure
									//Colour part BOM 
									ITKCALL(BOM_create_window (&window7));
									printf("\n CompareColorToBase7 find occurence..window");fflush(stdout);
									//ITKCALL(CFM_find(revisionRule, &rule));
									//printf("\n find occurence..rule");fflush(stdout);
									ITKCALL(BOM_set_window_config_rule( window7, revRule ));
									printf("\n CompareColorToBase7 configure occurence..rule");fflush(stdout);
									ITKCALL(BOM_set_window_top_line(window7, null_tag,ClrTag , bvr_tag1, &top_line7));
									ITKCALL(BOM_line_ask_child_lines (top_line7, &nClhd7, &children7));
									printf("\n CompareColorToBase7 nClhd7 %d,",nClhd7);fflush(stdout);

									for (ck7 = 0; ck7 < nClhd7; ck7++)
									{
										ITKCALL(BOM_line_pack (children7[ck7]));

										t_ChildItemRev7=NULLTAG;

										//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag)); //API Change
										//ITKCALL(BOM_line_ask_attribute_tag(children[ck], iChildItemTag, &t_ChildItemRev)); //API Change
										ITKCALL(AOM_ask_value_tag(children7[ck7],bomAttr_lineItemRevTag, &t_ChildItemRev7));
										if(t_ChildItemRev7!=NULLTAG)
										{

											Bomline_tag7=NULLTAG;
											Bomline_tag7 = children7[ck7];




											if(Bomline_tag7!=NULLTAG)
											{
												value_itemid7=NULL;
												value_itemRevID7=NULL;
												value_itemRevPartType7=NULL;
												value_itemColInd7=NULL;
												Item_ID_Check=NULL;
												colourAPLModSuffixVal7=NULL;
												value_itemid7=(char *) MEM_alloc(200 * sizeof(char *));
												colourAPLModSuffixVal7=(char *) MEM_alloc(200 * sizeof(char *));

												ITKCALL(AOM_ask_value_string(t_ChildItemRev7,"item_id",&value_itemid7))
												printf("\n CompareColorToBase7 111 Arc Node child value_itemid7:%s ..............",value_itemid7);fflush(stdout);								

												ITKCALL(AOM_ask_value_string(t_ChildItemRev7,"item_revision_id",&value_itemRevID7))
												printf("\n CompareColorToBase7 111 value_itemRevID7:%s ..............",value_itemRevID7);fflush(stdout);

												ITKCALL(AOM_ask_value_string(t_ChildItemRev7,"t5_PartType",&value_itemRevPartType7))
												printf("\n CompareColorToBase7 111 value_itemRevPartType7:%s ..............",value_itemRevPartType7);fflush(stdout);

												ITKCALL(AOM_ask_value_string(t_ChildItemRev7,"t5_ColourInd",&value_itemColInd7))
												printf("\n CompareColorToBase7 111 value_itemColInd7:%s ..............",value_itemColInd7);fflush(stdout);

												ITKCALL(AOM_ask_value_string(Bomline_tag7,"bl_quantity",&Qty7))//clr qty
												printf("\n CompareColorToBase7 111 Arc Node child Qty7:%s ..............",Qty7);fflush(stdout);
												iQty7=atoi(Qty7);
												printf("\n CompareColorToBase7 111 Arc Node child iQty7:%d ..............",iQty7);fflush(stdout);
											}

													
										}
										
										if (tc_strcmp(value_itemColInd7,"C")==0)
										{
											colourAPLModSuffixVal7=subString(value_itemid7,0,tc_strlen(value_itemid7)-2);	
												printf("\n CompareColorToBase7 Base part is :%s ..............%s:",colourAPLModSuffixVal7,colourVCSuffixVal);fflush(stdout);
												tc_strcpy(value_itemid27,colourAPLModSuffixVal7);
												printf("\n CompareColorToBase7 CCC part No for Compare is=%s ..............",value_itemid27);fflush(stdout);
										}
										if( (tc_strcmp(value_itemColInd7,"N")==0)||(tc_strcmp(value_itemColInd7,"Y")==0) )       //Added by vaibhav_CR-FY23-0211
										{
										    tc_strcpy(value_itemid27,value_itemid7);
											 printf("\n CompareColorToBase7 BBB part No for Compare is=%s ..............",value_itemid27);fflush(stdout);
										}
										if(tc_strcmp(value_itemid27,value_itemidB)==0)
										{
										  printf("\n CCompareColorToBase7 Child Color= %s and  Child base= %s are matching hence going to next Child: ..............",value_itemid27,value_itemidB);fflush(stdout);
										  // add qty mismatch logic
										  childmatchflg=1;
										  //goto NextChild1;
										
										}
										if(tc_strcmp(value_itemid27,value_itemidB)==0 && iQty7==iQTY_b/*tc_strcmp(Qty7,QTY_b)==0*/) 
										{
											printf("\n CompareColorToBase7 Child Color= %s and  Child base= %s Qty7 [%s],QTY_b [%s] are matching hence going to next Child: ..............",value_itemid27,value_itemidB,Qty7,QTY_b);fflush(stdout);
											childmatchflg_qty=1;
											goto NextChild1;


										}
									}
									if (childmatchflg==0)
									{
											errFlag++;
											ErrString=NULL;
											ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemidB)+tc_strlen(partItemId1)+tc_strlen(partItemId_rev1)+tc_strlen(ParetnNameB1)+tc_strlen(ParetnRevIdB1)+550);
											if(errFlag==1)
											{
												tc_strcpy(ErrString,"Colour BOM is not inline with Base BOM, Kindly raise ticket in TCUA Colour Module category in TMS:\n");
											}
											else
											{
												tc_strcpy(ErrString,"");	
											}
											
											tc_strcat(ErrString,value_itemidB);
											tc_strcat(ErrString," is not present in colour part ");
											tc_strcat(ErrString,partItemId1);
											tc_strcat(ErrString,";");
											tc_strcat(ErrString,partItemId_rev1);
											tc_strcat(ErrString," available in base part ");
											tc_strcat(ErrString,ParetnNameB1);
											tc_strcat(ErrString,";");
											tc_strcat(ErrString,ParetnRevIdB1);
											tc_strcat(ErrString,".\n");
											setAddStrFuction(icount_ebommbom_bom,SetChildRelAPLModErr,ErrString);


									}
									
									//if (childmatchflg==1)
									//{
									
										if (childmatchflg_qty==0 && childmatchflg==1)
										{
												errFlag++;
												ErrString=NULL;
												ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemidB)+tc_strlen(partItemId1)+tc_strlen(partItemId_rev1)+tc_strlen(ParetnNameB1)+tc_strlen(ParetnRevIdB1)+550);
												if(errFlag==1)
												{
													tc_strcpy(ErrString,"Colour BOM is not inline with Base BOM, Kindly raise ticket in TCUA Colour Module category in TMS:\n");
												}
												else
												{
													tc_strcpy(ErrString,"");	
												}
												
												tc_strcat(ErrString,value_itemidB);
												tc_strcat(ErrString," in colour part ");
												tc_strcat(ErrString,partItemId1);
												tc_strcat(ErrString,";");
												tc_strcat(ErrString,partItemId_rev1);
												tc_strcat(ErrString," is having Quantity mismatch with base part ");
												tc_strcat(ErrString,ParetnNameB1);
												tc_strcat(ErrString,";");
												tc_strcat(ErrString,ParetnRevIdB1);
												tc_strcat(ErrString,".\n");
												setAddStrFuction(icount_ebommbom_bom,SetChildRelAPLModErr,ErrString);


										}
									//}

									
								

								}
							}

						}
					}
				}
				


			NextChild1:;
			}
		}

	}

}
extern EPM_decision_t DLLAPI CLTaskBOMMistmatchFun(EPM_rule_message_t msg)
{  
			
	tag_t			rootTask		=NULLTAG;
	tag_t		   *attachments	    =NULLTAG;
	tag_t			dmlTag			=NULLTAG;
	tag_t			objTypTag			=NULLTAG;
	tag_t			dmlRevTag		=NULLTAG;
	tag_t			user_tag		=NULLTAG;
	tag_t			DMLToTaskRel	=NULLTAG;
	tag_t		   *Dml_tasks		=NULLTAG;
	tag_t            DMLLcmTag = NULLTAG;
	
	
	char* username			= NULL;
	char* Dml_task			= NULL;
	char* DMLNo				= NULL;
	char* dmlItem_id			= NULL;
	char* c_Rls_Type			= NULL;
	char* c_DmlRev			= NULL;
	char* cRev_id			= NULL;
	
	
	char*  ObjTyp=NULL;
  
	int    n_Attach	= 0;
	int    i		= 0;
	int    s		= 0;
	int    sec_count		= 0;
	  
	tag_t   CP_CtrObjQryTag				= NULLTAG;
	tag_t   ALLCP_CtrObjQryTag				= NULLTAG;
	tag_t   tDMLTskReLation				= NULLTAG;
	tag_t   *tDMLTasksec				= NULLTAG;

	int		CpBomEtry				=1;
	int		CPBOMQryC				=0;
	tag_t	*CPBOMCtrObj			=NULLTAG;
	char    *CpBomQryEtry[1]		= {"SYSCD"};
	char    **CPBOMQryVal			=  (char **) MEM_alloc(100 * sizeof(char *));
	int		AllCpBomEtry				=1;
	int		AllCPBOMQryC				=0;
	tag_t	*AllCPBOMCtrObj			=NULLTAG;
	tag_t	t_dml_Task			=NULLTAG;
	char    *AllCpBomQryEtry[1]		= {"SYSCD"};
	char    **AllCPBOMQryVal			=  (char **) MEM_alloc(100 * sizeof(char *));
	char **SetChildRelAPLBomCmErr = NULL;
	
	// vp ccontrol object validation var declarations
	
	tag_t 	t_CntrlObj					= NULLTAG;
	tag_t	*t_QryResult			=NULLTAG;
	int		iEntryCount				=1;
	int		i_resultFound				=0;	
	char    **c_EntryValue			=  (char **) MEM_alloc(100 * sizeof(char *));
	SetChildRelAPLBomCmErr = (char **)MEM_alloc(1 * sizeof *SetChildRelAPLBomCmErr);
	int PartCntB, icount_Clr2basedf = 0;
	tag_t *PartTagsB = NULLTAG;
	int iLength = 0; 
	char	*tempErr				=	NULL;
	int status;
		
		// vp ccontrol object validation var declarations ends
		
	
    char* CLTaskBOMMistMatch(tag_t,int, tag_t*);
	
	//EPM_decision_t decision = EPM_go;8/6/2026
	
	
	printf("\n ---------------Starting CLTaskBOMMistmatchFun of CL Task--------------------------->");fflush(stdout);
	
	CALLAPI(POM_get_user(&username,&user_tag));
	printf("\n CLTaskBOMMistmatchFun-->> POM_get_user ------------------User Name===>  %s  ",username);fflush(stdout);
	
	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
	//printf("\n CLTaskBOMMistmatchFun-->> CLTaskBOMMistmatch erc_dml_assign for CL_Task..............."); fflush(stdout);
	
	ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&n_Attach,&attachments));	    
	printf("\n CLTaskBOMMistmatchFun-->> COUNT OF Target Attachment ====> [ %d ] ",n_Attach);fflush(stdout);
			
			
	if(n_Attach >0)       // If Attachments of root task are more than zero
	{
	  // ---------- Control Object Validation -----------------------------------
	  
	   CALLAPI(QRY_find2("ControlObjQry", &t_CntrlObj));
	   char    *c_QryEntry[1]		    = {"SYSCD"};
	   c_EntryValue[0] = "CLTaskBOMMistMatch_ON";
	   ITK_CALL(QRY_execute(t_CntrlObj, iEntryCount, c_QryEntry, c_EntryValue, &i_resultFound, &t_QryResult));
	   
	   printf("\n CLTaskBOMMistmatchFun-->> FINDING control Object ==============> CLTaskBOMMistMatch_ON ");fflush(stdout);

		if (i_resultFound > 0)   // If control object count of "ClrNClrBOM_comp_rpt_ON" found more than one
		{
			printf("\n CLTaskBOMMistmatchFun-->> +++ Control Object ====> CLTaskBOMMistMatch_ON ==>> FOUND");fflush(stdout);
			
			for (i=0; i<n_Attach; i++)
			{
				printf("\n CLTaskBOMMistmatchFun-->> ******* INSIDE TARGET ATTACHMENT LOOP  ********");fflush(stdout);
			    if(TCTYPE_ask_object_type(attachments[i],&objTypTag));
				if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
				printf("\n CLTaskBOMMistmatchFun-->>  TARGET ATTACHMENT OBJECT TYPE = [%s]", ObjTyp);fflush(stdout);
				
				
				
				if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
				{
					if(AOM_ask_value_string(attachments[i],"item_id",&c_DmlRev)!=ITK_ok)PrintErrorStack();
					printf("\n CLTaskBOMMistmatchFun-->>  Picked -> ERC DML REVISION(ChangeRequestRevision) FROM Attachments ATTACHMENT - Item ID = [ %s ] ",c_DmlRev); fflush(stdout);
					
					if(AOM_ask_value_string(attachments[i],"t5_rlstype",&c_Rls_Type)!=ITK_ok)PrintErrorStack();
					printf("\n [ %s ] --> RELEASE TYPE = [ %s ]",c_DmlRev,c_Rls_Type);
					
					ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &tDMLTskReLation));
					ITK_CALL(GRM_list_secondary_objects_only(attachments[i], tDMLTskReLation, &sec_count, &tDMLTasksec));
					if(sec_count > 0)
					
					for (s =0 ; s<sec_count ; s++)
					{	
						printf("\n\t  ----- INSIDE LOOP - Checking EACH TASK of dml revision  ----");fflush(stdout);
						
						ITK_CALL(AOM_ask_value_string (tDMLTasksec[s], "object_name", &cRev_id));
						if((tc_strstr(cRev_id,"_CL")!=NULL) || ((tc_strstr(cRev_id,"_00")!=NULL) && (tc_strcmp(c_Rls_Type,"CP") == 0)) )  // pick only CL tasks from DML Tasks
						{
								
								DMLNo = subString(cRev_id,0,10);
								ITKCALL(AOM_ask_value_tags(tDMLTasksec[s], "CMHasSolutionItem", &PartCntB, &PartTagsB));
								printf("\n CLTaskBOMMistmatchFun-->>  PICKED DML_TASK [ %s ] from dmlno ===> [%s] ",cRev_id,DMLNo); fflush(stdout);
								t_dml_Task = tDMLTasksec[s];
								if(ITEM_find_item(DMLNo, &dmlTag)!=ITK_ok)PrintErrorStack();
								
								if (dmlTag != NULLTAG)
								{
									printf("\n CLTaskBOMMistmatchFun-->> DML TAG FOUND SUCCESSFULLY (dmlTag != NULLTAG)");fflush(stdout);
									printf("\n CLTaskBOMMistmatchFun-->>  CALLING FUNCTION --->  tmvp_ClrNonClrMismatchRpt ");fflush(stdout);	
									printf("\n Nilesh_Patil CompareColorToBase7 ");fflush(stdout);	
									//tmvp_ClrNonClrMismatchRpt( dmlTag, t_dml_Task);  // -----vp--Calling ftn here------tmvp_ClrNonClrMismatchRpt(dmlTag);---- report required b4 validation--
									CompareColorToBase7(t_dml_Task, "ERC", PartCntB, PartTagsB, &SetChildRelAPLBomCmErr, &icount_Clr2basedf);// Modified by Nilesh
								
								}
								if (icount_Clr2basedf > 0)
								{
								    iLength = 0;
								    if (!tempErr)
								        MEM_free(tempErr);
								    i = 0;
								    for (i = 0; i < icount_Clr2basedf; i++)
								    {
								        tempErr = SetChildRelAPLBomCmErr[i];
								        iLength = iLength + tc_strlen(tempErr);
								    }
								    printf("Bom Comapre Check : %d", iLength);
								    fflush(stdout);
								    if (!tempErr)
								        MEM_free(tempErr);
								    tempErr = (char *)MEM_alloc(iLength + 60);
								    tc_strcpy(tempErr, "Task:-"); // task number added in error pop up.......
								    tc_strcat(tempErr, cRev_id);   // task number added in error pop up.......
								    tc_strcat(tempErr, "\n");     //
								    i = 0;
								    printf("\nBefore For loop Bom Comapre Check");
								    fflush(stdout);
								    for (i = 0; i < icount_Clr2basedf; i++)
								    {
								        // printf("\n 111 SetChildErr %s",SetChildRelAPLBomCmErr[i]);fflush(stdout);
								        /* if(i==0)
								            tc_strcpy(tempErr,SetChildRelAPLBomCmErr[i]);
								        else */
								        tc_strcat(tempErr, SetChildRelAPLBomCmErr[i]);
								    }
								    printf("\n Bom Comapre Check Printing Errors...!!!");
								    fflush(stdout);
								    printf("%s", tempErr);
								    fflush(stdout);
								    EMH_clear_errors();
								    status = EMH_store_error_s1(EMH_severity_error, ITK_Prjerr, tempErr);
								    //decision = EPM_nogo;
								    return EPM_nogo;
								   // return decision;
								}
						}
						else
						{
							printf("\n\t----------------------->>> SKIPPING TASK - [ %s ] ......since doesn't meet condition  CL Task or 00(Rel type=CP) Task",Dml_task);fflush(stdout);
							
						}
						
					} 	//for (s =0 ; s<sec_count ; s++)
	
					
				}
			}
		}
		else
		printf("\n\t ------->>>>> CLTaskBOMMistmatchFun ===XXXXX===Control Object -------- CLTaskBOMMistMatch_ON ----- NOT FOUND");fflush(stdout);
	
		// =================================VP code end=================================================================
	}
	
				
	return EPM_go;		

}



extern EPM_decision_t DLLAPI CLTASKCPBOMDML(EPM_rule_message_t msg)
		{  
			
		   tag_t			rootTask		=NULLTAG;
		   tag_t		   *attachments	    =NULLTAG;
		   tag_t			dmlTag			=NULLTAG;
		   tag_t			objTypTag			=NULLTAG;
		   tag_t			dmlRevTag		=NULLTAG;
		   tag_t			user_tag		=NULLTAG;
		   tag_t			DMLToTaskRel	=NULLTAG;
		   tag_t		   *Dml_tasks		=NULLTAG;
		   tag_t            DMLLcmTag = NULLTAG;
		   
		   char* username			= NULL;
		   char* Dml_task			= NULL;
		   char* DMLNo				= NULL;
		   char* dmlItem_id			= NULL;
		   char* dml_rlstype		= NULL;
		   char* Dml_DR				= NULL;
		   char* dml_project		= NULL;
		   char* tsk_object_type	= NULL;
		   char* tsk_object_name	= NULL;
		   char  *ObjTyp=NULL;
			  
		   int    n_Attach	= 0;
		   int    i		= 0;
		   int    tsk_cnt	= 0;

			tag_t   CP_CtrObjQryTag				= NULLTAG;
			tag_t   ALLCP_CtrObjQryTag				= NULLTAG;

			int		CpBomEtry				=1;
			int		CPBOMQryC				=0;
			tag_t	*CPBOMCtrObj			=NULLTAG;
			char    *CpBomQryEtry[1]		= {"SYSCD"};
			char	*ClrNonClrMisMatchStr	= NULL;
			char	*AlrozCtrlArchiNode		= NULL;
			char    **CPBOMQryVal			=  (char **) MEM_alloc(100 * sizeof(char *));
			int		AllCpBomEtry				=1;
			int		AllCPBOMQryC				=0;
			tag_t	*AllCPBOMCtrObj			=NULLTAG;
			char    *AllCpBomQryEtry[1]		= {"SYSCD"};
			char    **AllCPBOMQryVal			=  (char **) MEM_alloc(100 * sizeof(char *));
			if (tc_strcmp(ClrNonClrMisMatchStr,"NULL") !=0) MEM_free(ClrNonClrMisMatchStr);
			ClrNonClrMisMatchStr=(char *)MEM_alloc(3000);
			//tc_strcpy(ClrNonClrMisMatchStr," ");

		   EPM_decision_t decision = EPM_go;
			char* ClrNonClrBOMMisMatch(tag_t,int, tag_t*);
			char*  AlrozCtrlArchi(tag_t,char*,char*,char*);
			printf("\n Starting for CLTASKCPBOMDML of CL Task----------->\n");fflush(stdout);
			CALLAPI(POM_get_user(&username,&user_tag));
			printf("\n CLTASKCPBOMDML Starting for taskbreskdownnn of CL Task----------->%s\n",username);fflush(stdout);
			ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n CLTASKCPBOMDML erc_dml_assign for CL_Task............... \n"); fflush(stdout);
			ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&n_Attach,&attachments));	    
			printf("\n CLTASKCPBOMDML Target Attachment:%d\n",n_Attach);fflush(stdout);
			if(n_Attach >0)
			{
				CALLAPI(QRY_find2("ControlObjQry", &ALLCP_CtrObjQryTag));
				AllCPBOMQryVal[0] = "ALLCLTASKCPBOMDML";
				CALLAPI(QRY_execute(ALLCP_CtrObjQryTag, AllCpBomEtry, AllCpBomQryEtry, AllCPBOMQryVal, &AllCPBOMQryC, &AllCPBOMCtrObj));

			if (AllCPBOMQryC > 0)
			{
				
			  printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);
			for (i=0;i<n_Attach;i++)
			{
				
			  if(TCTYPE_ask_object_type(attachments[i],&objTypTag));
			  if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			  printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			 if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0 || tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			 {
			 
				   if(AOM_ask_value_string(attachments[i],"item_id",&Dml_task)!=ITK_ok)PrintErrorStack();
					printf("\n CLTASKCPBOMDML Dml_task----------->%s\n",Dml_task); fflush(stdout);
			 
					DMLNo = subString(Dml_task,0,10);
					printf("\n CLTASKCPBOMDML Dml_task----------->%s\n",DMLNo); fflush(stdout);
					
					if(ITEM_find_item(DMLNo, &dmlTag)!=ITK_ok)PrintErrorStack();
					ITK_CALL(AOM_ask_value_string(dmlTag,"item_id",&dmlItem_id));
					printf("\n CLTASKCPBOMDML DML dmlItem_id is : %s\n",dmlItem_id);fflush(stdout);	
			 
					if (dmlTag != NULLTAG)
					{
						if(ITEM_ask_latest_rev(dmlTag, &dmlRevTag)!=ITK_ok)PrintErrorStack();
						CALLAPI(AOM_ask_value_string(dmlRevTag,"t5_rlstype",&dml_rlstype));
						printf("\nCLTASKCPBOMDML dml_rlstype is : %s\n",dml_rlstype);fflush(stdout);
			 
						CALLAPI(AOM_ask_value_string(dmlRevTag,"t5_cDRstatus",&Dml_DR));
						printf("\n CLTASKCPBOMDML Dml_DR  is : %s\n",Dml_DR );fflush(stdout);
			 
						CALLAPI(AOM_ask_value_string(dmlRevTag,"t5_cprojectcode",&dml_project));
						printf("\n CLTASKCPBOMDML dml_project is : %s\n",dml_project);fflush(stdout);
						  
						if((strcmp(dml_rlstype,"Veh")==0) || (strcmp(dml_rlstype,"MR")==0) || (strcmp(dml_rlstype,"PR")==0))
						 {
							ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
							ITK_CALL(GRM_list_secondary_objects_only(dmlRevTag,DMLToTaskRel,&tsk_cnt,&Dml_tasks));
							printf("\n CLTASKCPBOMDML DML Task count is :%d\n",tsk_cnt);fflush(stdout);
							if (tsk_cnt>0)
							{
							   for (i=0;i<tsk_cnt;i++)
							   {   
								  
									DMLLcmTag = Dml_tasks[i]; 

									if(AOM_ask_value_string(DMLLcmTag,"object_type",&tsk_object_type)!=ITK_ok) PrintErrorStack();
									if(AOM_ask_value_string(DMLLcmTag,"object_name",&tsk_object_name)!=ITK_ok) PrintErrorStack();
									printf("\n CLTASKCPBOMDML CL=tsk_object_type: [%s]   tsk_object_name: [%s]",tsk_object_type,tsk_object_name);fflush(stdout);
									if((tc_strcmp(tsk_object_type,"T5_ChangeTaskRevision")==0) &&(tc_strstr(tsk_object_name,"_CL")!=NULL))
									{ 
										printf("\n inside if condition T5_ChangeTaskRevision ,tsk_object_name");fflush(stdout);
										CALLAPI(QRY_find2("ControlObjQry", &CP_CtrObjQryTag));   
										 CPBOMQryVal[0] = "CLTASKCPBOMDML";
										CALLAPI(QRY_execute(CP_CtrObjQryTag, CpBomEtry, CpBomQryEtry, CPBOMQryVal, &CPBOMQryC, &CPBOMCtrObj));
										printf("\n\t CPBOMQryC-Control object found = [%d] \n",CPBOMQryC);fflush(stdout);
									   if (CPBOMQryC > 0)
									   {
										  
											ClrNonClrMisMatchStr = ClrNonClrBOMMisMatch(DMLLcmTag, CPBOMQryC, CPBOMCtrObj);
											
									   }
										
										  
											 printf("\n CLTASKCPBOMDML ClrNonClrMisMatchStr  Functions are [%s] ",ClrNonClrMisMatchStr);fflush(stdout);

											if ((strlen(ClrNonClrMisMatchStr)==0)||(ClrNonClrMisMatchStr==NULL)||tc_strcmp(ClrNonClrMisMatchStr," ")==0)
												{
													 printf("\n CLTASKCPBOMDMLBOM Mismatch All Ok \n");fflush(stdout);
												}
												else
												{
													printf("\n CLTASKCPBOMDML At main function of Color BOM mismatch %s \n",ClrNonClrMisMatchStr);fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s1(EMH_severity_error,PLM_error5, ClrNonClrMisMatchStr);
													decision = EPM_nogo;
													return decision;
												}


										
									 }
								 }

							   
										
								
							}
						 }
						 else
							 printf("\nDML is not of Veh/MR/PR hence skipping from validatn...\n");fflush(stdout);
			 
					 }

				}
			}
			}
			else
			{
			   printf("\n ALLCLTASKCPBOMDML ControlObject Not Found\n");fflush(stdout);
			}
			}
				
					


			return decision;

		}
		extern EPM_decision_t DLLAPI validation_CTRLBase_ArchNode(EPM_rule_message_t msg)
		{  
		   tag_t			rootTask		=NULLTAG;
		   tag_t		   *attachments	    =NULLTAG;
		   tag_t			dmlTag			=NULLTAG;
		   tag_t			objTypTag			=NULLTAG;
		   tag_t			dmlRevTag		=NULLTAG;
		   tag_t			user_tag		=NULLTAG;
		   tag_t			DMLToTaskRel	=NULLTAG;
		   tag_t		   *Dml_tasks		=NULLTAG;
		   tag_t            DMLLcmTag = NULLTAG;
		   
		   char* username			= NULL;
		   char* Dml_task			= NULL;
		   char* DMLNo				= NULL;
		   char* dmlItem_id		= NULL;
		   char* dml_rlstype		= NULL;
		   char* Dml_DR			= NULL;
		   char* dml_project			= NULL;
		   char* tsk_object_type	= NULL;
		   char* tsk_object_name	= NULL;
		   char  *ObjTyp=NULL;
			  
		   int    n_Attach	= 0;
		   int    i		= 0;
		   int    ii		= 0;
		   int    tsk_cnt	= 0;

			tag_t   CP_CtrObjQryTag      = NULLTAG;
			int		CpBomEtry				=1;
			int		CPBOMQryC				=0;
			tag_t	*CPBOMCtrObj			=NULLTAG;
			char    *CpBomQryEtry[1]		= {"SYSCD"};
			char	*ClrNonClrMisMatchStr	= NULL ;
			char	*AlrozCtrlArchiNode = NULL;
			char    **CPBOMQryVal			=  (char **) MEM_alloc(100 * sizeof(char *));
			tag_t   ALLCP_CtrObjQryTag				= NULLTAG;
			int		AllCpBomEtry				=1;
			int		AllCPBOMQryC				=0;
			tag_t	*AllCPBOMCtrObj			=NULLTAG;
			char    *AllCpBomQryEtry[1]		= {"SYSCD"};
			char    **AllCPBOMQryVal			=  (char **) MEM_alloc(100 * sizeof(char *));
			ClrNonClrMisMatchStr=(char *)MEM_alloc(3000);
			AlrozCtrlArchiNode=(char *)MEM_alloc(3000);
			
		   EPM_decision_t decision = EPM_go;
			char* ClrNonClrBOMMisMatch(tag_t,int, tag_t*);
			char*  AlrozCtrlArchi(tag_t,char*,char*,char*);
			printf("\n Starting for validation_CTRLBase_ArchNode of CL Task----------->\n");fflush(stdout);
			CALLAPI(POM_get_user(&username,&user_tag));
			printf("\n validation_CTRLBase_ArchNode Starting for taskbreskdownnn of CL Task----------->%s\n",username);fflush(stdout);
			ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n validation_CTRLBase_ArchNode erc_dml_assign for CL_Task............... \n"); fflush(stdout);
			ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&n_Attach,&attachments));	    
			printf("\n validation_CTRLBase_ArchNode Target Attachment:%d\n",n_Attach);fflush(stdout);
			if(n_Attach >0)
			{
			   
				CALLAPI(QRY_find2("ControlObjQry", &ALLCP_CtrObjQryTag));
				AllCPBOMQryVal[0] = "ALLVEHRELBOMDML";
				CALLAPI(QRY_execute(ALLCP_CtrObjQryTag, AllCpBomEtry, AllCpBomQryEtry, AllCPBOMQryVal, &AllCPBOMQryC, &AllCPBOMCtrObj));

			if (AllCPBOMQryC > 0)
			{

			  printf("\n******* validation_CTRLBase_ArchNode INSIDE Attachments  ********\n");fflush(stdout);
			for (i=0;i<n_Attach;i++)
			{
				
			  if(TCTYPE_ask_object_type(attachments[i],&objTypTag));
			  if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
			  printf("\n ********** validation_CTRLBase_ArchNode Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

			 if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0 || tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			 {
			 
				   if(AOM_ask_value_string(attachments[i],"item_id",&Dml_task)!=ITK_ok)PrintErrorStack();
					printf("\n CTRLBase Dml_task----------->%s\n",Dml_task); fflush(stdout);
			 
					DMLNo = subString(Dml_task,0,10);
					printf("\n CTRLBase Dml_task----------->%s\n",DMLNo); fflush(stdout);
					
					if(ITEM_find_item(DMLNo, &dmlTag)!=ITK_ok)PrintErrorStack();
					ITK_CALL(AOM_ask_value_string(dmlTag,"item_id",&dmlItem_id));
					printf("\n CTRLBase DML dmlItem_id is : %s\n",dmlItem_id);fflush(stdout);	
			 
					if (dmlTag != NULLTAG)
					{
						if(ITEM_ask_latest_rev(dmlTag, &dmlRevTag)!=ITK_ok)PrintErrorStack();
						CALLAPI(AOM_ask_value_string(dmlRevTag,"t5_rlstype",&dml_rlstype));
						printf("\nCTRLBase dml_rlstype is : %s\n",dml_rlstype);fflush(stdout);
			 
						CALLAPI(AOM_ask_value_string(dmlRevTag,"t5_cDRstatus",&Dml_DR));
						printf("\n CTRLBase Dml_DR  is : %s\n",Dml_DR );fflush(stdout);
			 
						CALLAPI(AOM_ask_value_string(dmlRevTag,"t5_cprojectcode",&dml_project));
						printf("\n CTRLBase dml_project is : %s\n",dml_project);fflush(stdout);
						  
						if((strcmp(dml_rlstype,"Veh")==0) || (strcmp(dml_rlstype,"MR")==0) || (strcmp(dml_rlstype,"PR")==0))
						 {
							ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
							ITK_CALL(GRM_list_secondary_objects_only(dmlRevTag,DMLToTaskRel,&tsk_cnt,&Dml_tasks));
							printf("\nCTRLBase DML Task count is :%d\n",tsk_cnt);fflush(stdout);
							if (tsk_cnt>0)
							{
							   for (ii=0;ii<tsk_cnt;ii++)
							   {   
								  
									DMLLcmTag = Dml_tasks[ii]; 

									if(AOM_ask_value_string(DMLLcmTag,"object_type",&tsk_object_type)!=ITK_ok) PrintErrorStack();
									if(AOM_ask_value_string(DMLLcmTag,"object_name",&tsk_object_name)!=ITK_ok) PrintErrorStack();
									printf("\n CTRLBase CL=tsk_object_type: [%s]   tsk_object_name: [%s]",tsk_object_type,tsk_object_name);fflush(stdout);
									if((tc_strcmp(tsk_object_type,"T5_ChangeTaskRevision")==0) &&(tc_strstr(tsk_object_name,"_CL")!=NULL))
									{ 
										printf("\n inside if condition T5_ChangeTaskRevision ,tsk_object_name");fflush(stdout);
										CALLAPI(QRY_find2("ControlObjQry", &CP_CtrObjQryTag));   
										 CPBOMQryVal[0] = "VEHRELBOMDML";
										CALLAPI(QRY_execute(CP_CtrObjQryTag, CpBomEtry, CpBomQryEtry, CPBOMQryVal, &CPBOMQryC, &CPBOMCtrObj));
										printf("\n\t CPBOMQryC-Control object found = [%d] \n",CPBOMQryC);fflush(stdout);
									   if (CPBOMQryC > 0)
									   {
										 
											ClrNonClrMisMatchStr = ClrNonClrBOMMisMatch(DMLLcmTag, CPBOMQryC, CPBOMCtrObj);
											
										  // AlrozCtrlArchiNode = AlrozCtrlArchi(DMLLcmTag,Dml_DR,dml_project); // Altroz    

										   AlrozCtrlArchiNode = AlrozCtrlArchi(DMLLcmTag,Dml_DR,dml_project,DMLNo);
									   }
										 
											
										printf("\n After ClrNonClrMisMatchStr function and before AlrozCtrlArchiNode function \n");fflush(stdout);
										printf("\n ClrNonClrMisMatchStr and  AlrozCtrlArchiNode Functions are [%s] and [%s]\n",ClrNonClrMisMatchStr,AlrozCtrlArchiNode);fflush(stdout);

										
									if ((strlen(AlrozCtrlArchiNode)==0)||(AlrozCtrlArchiNode==NULL)||tc_strcmp(AlrozCtrlArchiNode," ")==0)
										{
											  printf("\n Modules in Vehicle are All Ok \n");fflush(stdout);

												if ((strlen(ClrNonClrMisMatchStr)==0)||(ClrNonClrMisMatchStr==NULL)||tc_strcmp(ClrNonClrMisMatchStr," ")==0)
												{
													printf("\n BOM Mismatch All Ok \n");fflush(stdout);
													
												}
												else
												{

													printf("\n At main function of Color BOM mismatch %s \n",ClrNonClrMisMatchStr);fflush(stdout);
													EMH_clear_errors();
													EMH_store_error_s1(EMH_severity_error,PLM_error5, ClrNonClrMisMatchStr);
													decision = EPM_nogo;
													return decision;
												
												}																	    									  
										  
										}
										else
										{
											printf("\n At main function of Altroz Validation %s \n",AlrozCtrlArchiNode);fflush(stdout);
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,PLM_error5, AlrozCtrlArchiNode);
											decision = EPM_nogo;
											return decision;
											
											
										}



										
									 }
								 }

										

								// if (tc_strcmp(AlrozCtrlArchiNode,"")==0)
								//	{
								//		printf("\n CTRLBase All Ok \n");fflush(stdout);
								//	}
								//	else
								//	{
										
								//		printf("\n %s \n",AlrozCtrlArchiNode);fflush(stdout);
								//		EMH_clear_errors();
								//		EMH_store_error_s1(EMH_severity_error,CLTask_Err, AlrozCtrlArchiNode);
								//		decision = EPM_nogo;
								//		return decision;
								//	}
							}
						 }
						 else
							 printf("\nDML is not of Veh/MR/PR hence skipping from validatn...\n");fflush(stdout);
			 
					 }

				}
			}
			}
			else
			{
				printf("\n AllVEHRELBOMDML Control Object not Found......\n");fflush(stdout);
			}
			}
		   
		   return decision;
		}

	char*  AlrozCtrlArchi(tag_t DMLLcmTag ,char *Dml_DR,char *dml_project,char *DMLItem_id)
			{

				//VARIABLE DECLARATION FOR DML DR STATUS & COLOR PART DR STATUS CHECK
				char    **CPgMQryEntryValue     =  (char **) MEM_alloc(100 * sizeof(char *));
				char    **ArchrNodeyEntryValue  =  (char **) MEM_alloc(100 * sizeof(char *));
				int     GMenry_Count            = 2;
				char    *CPGMQryEntry[2]        = {"SUBSYSCD","SYSCD"};
				int     ArchNodeQryC			= 0;
				int     SolnItemCnt             = 0;
				int     aar                     = 0;
				int     child_count	            = 0;
				int     ii                      = 0;
				int	    childline_ID            = 0;
				int     zeroflag				= 0;
				int     vcCount					= 0;
				char    *ClrPrtType			    = NULL;
				char    *ClrPrtRevId		    = NULL;
				char    *Clrrev_Id              = NULL;
				char    *ClrPrtNo			    = NULL;
				char	*ClrItemIDV			    = NULL;
				char	*ClrPrtRevIDVtag	    = NULL;
				char	*ClrPrtRevobjstring	    = NULL;
				char	*topline_item_id	    = NULL;
				char	*strinfo1			    = NULL;
				char	*strinfo2			    = NULL;
				char	*strinfo3			    = NULL;
				char	*strinfo4			    = NULL;
				char	*strinfo5			    = NULL;
				char	*strinfo55			    = NULL;
				char	*strinfo6			    = NULL;
				char	*strinfo1T3				= NULL;
				char	*strinfo2T3				= NULL;
				char * token                    = NULL;
				char * tokenT3                    = NULL;
				char	*VehMODErr				= NULL;
				char    *Object_id				= NULL;
				//char  allItemArchNode[1900]     = { 0 };
				char  CtrlObjArchNode[1900]     = { 0 };
				char CtrlObjArchNodeT3[1900]	= { 0 };
				char CtrlObjClrBypass[1900]		= { 0 };
				char  subArch[1900]				= { 0 };
				tag_t	*SolnItemSet			= NULLTAG;
				tag_t	ClrItemRev				= NULLTAG;
				tag_t   bom_window				= NULLTAG;
				tag_t	bom_rule				= NULLTAG;
				tag_t	bomtop_line				= NULLTAG;
				tag_t	*bomchild				= NULLTAG;
				tag_t	ClrPrtRevIDtag			= NULLTAG;
				tag_t	ClrItemtag1				= NULLTAG;
				tag_t	childpart				= NULLTAG;
				tag_t   CP_gMCtrObjQryTag		= NULLTAG;
				tag_t   *ArchNodeCtrObj			= NULLTAG;
				tag_t alt_CntrlOBJ	=	NULLTAG;
				int alt_entries = 1;
				int	alt_found	=	0;
				tag_t *CntrlObject_alt	=	NULLTAG;
				char *Arcbl_Item_id = NULL;  //4 declared globally
				char *subArchiNode  = NULL;
				char *qry_T3Z01[1] = {"SYSCD"};								
				char **qry_valuesT3Z01 = (char **) MEM_alloc(10 * sizeof(char *));								
				qry_valuesT3Z01[0] = "ColorT3Z01Alternate";
				int	T3Z01_found	=	0;
				tag_t *CntrlObject_T3Z01	=	NULLTAG;
				tag_t T3Z01_CntrlOBJ	=	NULLTAG;
				int T3Z01_entries = 1;
			 
				int ctrlobj_entries =2;
				int ResultCnt =0;
				char *userinfo1=NULL;
				char *userinfo2=NULL;
				tag_t	Cntl_obj_Qrytag	=	NULLTAG;
				tag_t	*qryctrlobj_cntrlobj	=	NULLTAG;
				char **qryctrlobj_values = (char **) MEM_alloc(50 * sizeof(char *));
				char *qryctrlobj_entries[2] = {"SYSCD","SUBSYSCD"};

				printf("\nInside Rohit function after declarations\n");	fflush(stdout);
		 

				if (tc_strcmp(VehMODErr,"NULL") !=0) MEM_free(VehMODErr);
					VehMODErr=(char *)MEM_alloc(3000);
							
					//ITKCALL(AOM_ask_value_string(DMLLcmTag,"item_id",&Object_id));
					//printf("\n\n\t\t Object_id is :%s",Object_id);fflush(stdout);

					if(QRY_find2("Control Objects...",&alt_CntrlOBJ));
					printf("\n\nFastCVBUCntrlObj Query Found\n\n");	fflush(stdout);

					char *qry_altcntrl[1] = {"SYSCD"};
					
					char **qry_valuesalt = (char **) MEM_alloc(10 * sizeof(char *));
					
					qry_valuesalt[0] = "altozntrlObj";
																	
					if(QRY_execute(alt_CntrlOBJ, alt_entries, qry_altcntrl, qry_valuesalt, &alt_found, &CntrlObject_alt));
					printf("\n\n  Fastener SYSCD :%d\n",alt_found);	fflush(stdout);
					if(alt_found>0)
					{

						ITKCALL(AOM_ask_value_tags(DMLLcmTag,"CMHasSolutionItem",&SolnItemCnt,&SolnItemSet));
						//printf("\nColor parts are not present in Solutions Item Folder\n"); fflush(stdout);
							
							tc_strcpy(VehMODErr,"");
							tc_strcat(VehMODErr,"MODULES IS NOT PRESENT UNDER VC:");


						for (aar =0 ; aar < SolnItemCnt ; aar++)
						{
							vcCount=0;
							ClrItemRev=SolnItemSet[aar];
							ITKCALL(AOM_ask_value_string(ClrItemRev,"t5_PartType",&ClrPrtType));
							ITKCALL(AOM_ask_value_string(ClrItemRev,"item_id",&ClrPrtNo));

							ITKCALL(AOM_ask_value_string(ClrItemRev,"item_revision_id",&ClrPrtRevId));
							if (strstr(ClrPrtRevId,";"))
							{
								Clrrev_Id = strtok(ClrPrtRevId, ";");
							}
							else
							{
							   Clrrev_Id=ClrPrtRevId;
							}
							
							printf("\n Color parts is :%s;%s with part type %s",ClrPrtNo,Clrrev_Id,ClrPrtType);fflush(stdout);
							   
							if (tc_strcmp(ClrPrtType,"V")==0)
							{ 
								tc_strcpy(CtrlObjClrBypass,"");
								tc_strcat(CtrlObjClrBypass,DMLItem_id);
								tc_strcat(CtrlObjClrBypass,"_");
								tc_strcat(CtrlObjClrBypass,ClrPrtNo);
								tc_strcat(CtrlObjClrBypass,"_");
								tc_strcat(CtrlObjClrBypass,Clrrev_Id);

								printf("\n Input For ByPass Vehicle of Signoff DML...............%s",CtrlObjClrBypass);fflush(stdout);

								if(QRY_find2("Control Objects...", &Cntl_obj_Qrytag));
								qryctrlobj_values[0] = "DML_Vehicle_Revision_ClrBypass" ;
								qryctrlobj_values[1] = CtrlObjClrBypass;
								if(QRY_execute(Cntl_obj_Qrytag, ctrlobj_entries, qryctrlobj_entries, qryctrlobj_values, &ResultCnt, &qryctrlobj_cntrlobj)!=ITK_ok);
							if (ResultCnt > 0)
							{
									 printf("\n  ByPass for Signoff...............");fflush(stdout);
							}else
							{
									//tc_strcat(VehMODErr,"[");
								printf("\nPart Type is Vehicle for Altroz/Nexon Validation"); fflush(stdout);										
								ITKCALL(AOM_ask_value_string(ClrItemRev,"item_id",&ClrItemIDV));
								printf("\n item_id Part Type Vehicle id is ...:%s",ClrItemIDV); fflush(stdout);
								ITKCALL(ITEM_find_item(ClrItemIDV,&ClrItemtag1)); //Item Tag
								ITKCALL(AOM_ask_value_string(ClrItemRev,"item_revision_id",&ClrPrtRevIDVtag));
								printf("\n Part Typeitem_revision_id Vehicle Revision id is ...:%s",ClrPrtRevIDVtag); fflush(stdout);
								ITKCALL(ITEM_find_revision(ClrItemtag1,ClrPrtRevIDVtag,&ClrPrtRevIDtag));
								ITKCALL(AOM_ask_value_string(ClrPrtRevIDtag,"object_string",&ClrPrtRevobjstring));
								printf("\n object_string Vehicle Revision id is ...:%s",ClrPrtRevobjstring); fflush(stdout);
								ITKCALL(BOM_create_window(&bom_window));										;
								ITKCALL(CFM_find( "Latest Working", &bom_rule ));										
								ITKCALL(BOM_set_window_config_rule(bom_window, bom_rule ));										
								ITKCALL(BOM_set_window_pack_all(bom_window, true));										
								ITKCALL(BOM_set_window_top_line(bom_window, null_tag,ClrPrtRevIDtag , null_tag, &bomtop_line));
								//if(bomtop_line > 0)
								//{
									ITKCALL(AOM_ask_value_string(bomtop_line, "bl_item_item_id", &topline_item_id));
									ITKCALL(BOM_line_ask_child_lines (bomtop_line, &child_count, &bomchild));
									
									tc_strcpy(allItemArchNode,"");
									tc_strcpy(CtrlObjArchNode,"");
									ITKCALL(QRY_find2("ControlObjQry", &CP_gMCtrObjQryTag));	                                                      
								   //printf("\n Start control Object for AltrozArchNode ----->\n"); fflush(stdout);
										ArchrNodeyEntryValue[0] = "AltrozArchNode";
										ArchrNodeyEntryValue[1] = "AltrozArchNode";
										ITKCALL(QRY_execute(CP_gMCtrObjQryTag, GMenry_Count, CPGMQryEntry, ArchrNodeyEntryValue, &ArchNodeQryC, &ArchNodeCtrObj));
										printf("\n Control Object AltrozArchNode count is  ----->%d\n",ArchNodeQryC); fflush(stdout);

										if(ArchNodeQryC>0)	
										{
											ITKCALL(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo1",&strinfo1));
											ITKCALL(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo2",&strinfo2));
											ITKCALL(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo3",&strinfo3));
											ITKCALL(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo4",&strinfo4));
											ITKCALL(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo5",&strinfo5));
											ITKCALL(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo6",&strinfo6));
											printf("\n t5_Userinfo5------> %s  , t5_Userinfo6 ----> %s \n",strinfo6,strinfo5); fflush(stdout);
											tc_strcat(CtrlObjArchNode,strinfo1);
											tc_strcat(CtrlObjArchNode,strinfo2);
											tc_strcat(CtrlObjArchNode,strinfo3);
											tc_strcat(CtrlObjArchNode,strinfo4);

										//printf("\nINSIDE TESTING before token WHILE LOOP token is [%s]\n", token);	fflush(stdout);
										token = strtok(CtrlObjArchNode, ",");
										//printf("\nINSIDE TESTING WHILE after token  LOOP token is [%s]\n", token);	fflush(stdout);
									 
									 for(ii = 0 ; ii < child_count ; ii++)
									{
										//char *Arcbl_Item_id = NULL;
										//char *subArchiNode  = NULL;
										
										childpart = bomchild[ii];
										ITKCALL(AOM_ask_value_string(childpart, "bl_item_item_id", &Arcbl_Item_id));
										tc_strcpy(subArch,"");
										subArchiNode = subString(Arcbl_Item_id,4,5);
										tc_strcat(subArch,"M");
										tc_strcat(subArch,subArchiNode);
										tc_strcat(allItemArchNode,subArch);
										tc_strcat(allItemArchNode,",");

									}
									 
									printf("\n allItemArchNode for Altroz/Nexon Validation------> %s \n",allItemArchNode); fflush(stdout);
									ITKCALL(AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo5",&strinfo55));
									 printf("\n outside  project code allItemArchNode------> %s,%s\n",dml_project,strinfo55); fflush(stdout);
									  if (tc_strstr(strinfo55,dml_project) == NULL)
									  {
										
										 if((tc_strstr(allItemArchNode,"T3Z01") != NULL)) //Rohit
											  {
											  printf("\nT3Z01 Module is present under vehicle\n\n"); fflush(stdout);
											  //printf("\n Value of token outside while loop first isssssssssssssssssss  [%s]\n",token); fflush(stdout);
											  while( token != NULL )
													{
														//printf("\n Value of token inside while loop first isssssssssssssssssss  [%s]\n",token); fflush(stdout);
													  printf( "Single ArchNode From control Object = %s,%s\n", token ,tc_strstr(allItemArchNode,token)); 
													  //printf( "Only token Single ArchNode From control Object = [%s]\n", token); 

													   if((tc_strstr(allItemArchNode,token) == NULL))
														{
															printf("\n Modules not present under Vehivles is...........>>%s\n",token); fflush(stdout);                                                          
															tc_strcat(VehMODErr,token);                                                           
															tc_strcat(VehMODErr,",");   
															vcCount = 1;
															zeroflag=zeroflag+1;                                                                     

									
														}
														
														token = strtok(NULL, ",");
														//printf("\n Value of token inside while loop isssssssssssssssssss  [%s]\n",token); fflush(stdout);

													}
											 }
											  else
											  {
												
												ITKCALL(QRY_find2("Control Objects...",&T3Z01_CntrlOBJ));										
												ITKCALL(QRY_execute(T3Z01_CntrlOBJ, T3Z01_entries, qry_T3Z01, qry_valuesT3Z01, &T3Z01_found, &CntrlObject_T3Z01));
												printf("\n\nT3Z01 Alternate Control Object found  :%d\n",T3Z01_found);	fflush(stdout);
												if(T3Z01_found > 0)
												{
													printf("\nInside T3Z01 Alternate Control Object as T3Z01 is not present under Vehicle\n");	fflush(stdout);
													ITKCALL(AOM_ask_value_string(CntrlObject_T3Z01[0],"t5_Userinfo1",&strinfo1T3));
													ITKCALL(AOM_ask_value_string(CntrlObject_T3Z01[0],"t5_Userinfo2",&strinfo2T3));
											
													tc_strcpy(CtrlObjArchNodeT3,"");
													tc_strcat(CtrlObjArchNodeT3,strinfo1T3);
													tc_strcat(CtrlObjArchNodeT3,strinfo2T3);
											
													printf("\n CtrlObjArchNodeT3 added by ROHIT  %s\n",CtrlObjArchNodeT3);
													
													tokenT3 = strtok(CtrlObjArchNodeT3, ",");
													while (tokenT3 != NULL) 
														{
																//printf("\n%s\n", tokenT3); //printing each tokenT3
											
																if((tc_strstr(allItemArchNode,tokenT3) == NULL))
																{
																	printf("\n Modules not present under Vehicle in absence of T3Z01 is...........>>%s\n",tokenT3); fflush(stdout);                                                          
																	tc_strcat(VehMODErr,tokenT3);                                                           
																	tc_strcat(VehMODErr,",");  
																	vcCount = 1;
																	zeroflag=zeroflag+1;                                                                          
												
												
																}
											
																tokenT3 = strtok(NULL, ",");
											
											
														}
												
												}
												
											}

										}
										else
										{
											printf("\n UNABLE TO MATCH PROJECT .......\n"); fflush(stdout);
										}
							}//Arch node query
									
						} //bypass else bracket
											
							}//Part Type Vehicle Loop
						} //Solution Item loop
					}//AltLoop
					printf("\n Printf for VehMODErr outside loop is %d and %s and error is [%s]\n",zeroflag,tc_strstr(strinfo6,Dml_DR),VehMODErr); fflush(stdout);
					if (zeroflag>0 && tc_strstr(strinfo6,Dml_DR) != NULL)
					{
						printf("\n Printf for VehMODErr %s\n",VehMODErr); fflush(stdout); //EMH_severity_error                                                
						return VehMODErr;
					  
					 }
					tc_strcpy(VehMODErr," ");
					return VehMODErr;
				}
		char* CLTaskBOMMistmatch(tag_t DMLLcmTag,int CPBOMQryC, tag_t *CPBOMCtrObj)
		{
			int		SolnItemCnt				=0;
			int		aaz						=0;
			int		sdk						=0;
			int		kk						=0;
			int		NonClr_count			=0;
			int     n_lines1				=0;
			int     n_lines2				=0;
			int     NonClrFlag				=0;
			int     BOMMisFlag				=0;
			int     PrtTypeFlag				=0;

			tag_t	ClrItemRev				=NULLTAG;
			tag_t	NonClr_Relation			=NULLTAG;
			tag_t	bom_window				=NULLTAG;
			tag_t	bom_window2				=NULLTAG;
			tag_t	rule					=NULLTAG;
			tag_t	rule2					=NULLTAG;
			tag_t	top_line				=NULLTAG;
			tag_t	top_line2				=NULLTAG;
			tag_t	*lines					=NULLTAG;
			tag_t	*lines2					=NULLTAG;

			tag_t	*SolnItemSet			=NULLTAG;
			tag_t	*NonClrSet				=NULLTAG;
			tag_t	NonClrRev_t				= NULLTAG;

			char    *ClrPrtType				= NULL;
			char	*ClrPrtNo				= NULL;
			char	*ClrPrtRevId			= NULL;
			char	*NonClrPrtNo			= NULL;
			char	*info1_value			= NULL;
			char	*BOMMisErr				= NULL;
			char	*BOMMisErr2				= NULL;
			char	*token					= NULL;
			char	*ProjectCode			= NULL;
			int ClrCnt = 0;
			int NonClrCnt = 0;

			int rulefound2= 0;         
			tag_t *closurerule2 = NULL;
			tag_t close_tag2;          
			char **rulename2 = NULL;   
			char **rulevalue2 = NULL;


			char *DiffCmpBOMCnt;
			char *DiffCmpBOMCntNClr;
			char *DiffCmpBOMCntCmb;
			char *DiffBomCnt;
			

			if (tc_strcmp(BOMMisErr,"NULL") !=0) MEM_free(BOMMisErr);
			BOMMisErr=(char *)MEM_alloc(3000);

			if (tc_strcmp(BOMMisErr2,"NULL") !=0) MEM_free(BOMMisErr2);
			BOMMisErr2=(char *)MEM_alloc(3000);



			printf("\n\t ****** Inside ClrNonClrBOMMisMatch Validation ****** \n");fflush(stdout);


			ITKCALL(AOM_ask_value_tags(DMLLcmTag,"CMHasSolutionItem",&SolnItemCnt,&SolnItemSet));

			tc_strcpy(BOMMisErr," ");
			tc_strcat(BOMMisErr,"Unable to find Base Part for respective Color Part [ ");

			tc_strcpy(BOMMisErr2," ");
			tc_strcat(BOMMisErr2,"Color BOM is not match with Non-Color BOM [ ");

			for (aaz =0 ; aaz < SolnItemCnt ; aaz++)
			{
				ClrItemRev	=NULLTAG;
				ClrCnt = 0;   
				NonClrCnt = 0;												
				DiffCmpBOMCnt	= (char *) MEM_alloc(10000);
				tc_strcat(DiffCmpBOMCnt," ");
				DiffCmpBOMCntNClr	= (char *) MEM_alloc(10000);
				tc_strcat(DiffCmpBOMCntNClr," ");

				ClrItemRev=SolnItemSet[aaz];
				ITKCALL(AOM_ask_value_string(ClrItemRev,"t5_PartType",&ClrPrtType));
				ITKCALL(AOM_ask_value_string(ClrItemRev,"item_id",&ClrPrtNo));

				ITKCALL(AOM_ask_value_string(ClrItemRev,"item_revision_id",&ClrPrtRevId));
				printf("\n Color parts is :%s;%s with part type %s \n",ClrPrtNo,ClrPrtRevId,ClrPrtType);fflush(stdout);

				ITKCALL(AOM_ask_value_string(ClrItemRev,"t5_ProjectCode",&ProjectCode));
				printf("\n\t Clr Project Code = [%s]\n\n",ProjectCode);  fflush(stdout);

				ITKCALL(GRM_find_relation_type("TC_Is_Represented_By", &NonClr_Relation));
				ITKCALL(GRM_list_secondary_objects_only(ClrItemRev,NonClr_Relation,&NonClr_count,&NonClrSet));

				printf("\n\t Non Clr Relation Found  count is = [%d] \n\n",NonClr_count);  fflush(stdout);

				if (NonClr_count>0)
				{
					NonClrRev_t	 = NULLTAG;

					if (NonClr_count ==1)
					{
						//printf("\n\t Non color count = 1 \n");
						NonClrRev_t=NonClrSet[0];
					}
					else
					{
						//printf("\n\t Non color count > 1 \n");
						NonClrRev_t=GetLatestRevinSet(NonClrSet,NonClr_count);
					}
				}
				   ClrCnt=ClrBOMExpansion(ClrItemRev);

				   NonClrCnt=NonClrBOMExpansion(NonClrRev_t);
					
					int jkl =0;
					int jk =0;
					tag_t  NClrBOMTag = NULLTAG;
					tag_t  ClrBOMTag = NULLTAG;
					char *NClrItemId = NULL;
					char *NClrquantity = NULL; 									
					char *Clrquantity = NULL;
					char *ClrDRStatus = NULL;
					char *NClrDRStatus = NULL;
					int ErrorFlag =0 ;
					int ErrorFlagNClr = 0;

					   printf("\n Color part and Non-color part count is :%d:%d.\n",ClrCnt,NonClrCnt);fflush(stdout);
					   if (ClrCnt == NonClrCnt || ClrCnt != NonClrCnt)
					   {
						 printf("\n All Clr Part number bl_item_item_id===>%s \n",ClrBOMArr);fflush(stdout);
					
						 printf("\n All Non-Clr Part number bl_item_item_id===>%s \n",NonClrBOMArr);fflush(stdout);

							
						 for (jk=0;jk<ia ;jk++ )
						{   
							
							ClrBOMTag = NULLTAG;
							char *ClrItemId = NULL;
							Clrquantity = NULL;
						
							  ClrBOMTag=tagSET[jk];
							  ITK_CALL(AOM_ask_value_string(ClrBOMTag, "bl_item_item_id", &ClrItemId ));
							 // printf("\n Clr Part number bl_item_item_id===>%s \n",ClrItemId);fflush(stdout);
						if (tc_strstr(DiffCmpBOMCntNClr,ClrItemId)==NULL)
						{
							
							if(tc_strstr(NonClrBOMArr,ClrItemId) != NULL)    // part compare
							{

								for (jkl=0;jkl<iaNClr ;jkl++ )
								{   
									NClrBOMTag = NULLTAG;
									NClrItemId = NULL;
									NClrquantity = NULL;
								
									NClrBOMTag=tagSETNClr[jkl];
									ITK_CALL(AOM_ask_value_string(NClrBOMTag, "bl_item_item_id", &NClrItemId ));
									//printf("\n Non-Clr Part number bl_item_item_id===>%s \n",NClrItemId);fflush(stdout);
									if (tc_strstr(DiffCmpBOMCnt,NClrItemId)==NULL)
									{
										 
									if(tc_strstr(ClrBOMArr,NClrItemId) == NULL)    // part compare
									{

										DiffBomCnt = (char *) MEM_alloc(5000);                                                                       
										tc_strcat(DiffBomCnt," "); 																	
										//tc_strcat(DiffBomCnt,"IN Color VC  : ");
										tc_strcat(DiffBomCnt,NClrItemId);
										tc_strcat(DiffCmpBOMCnt,DiffBomCnt);
										tc_strcat(DiffCmpBOMCnt,",");
										ErrorFlag = 1; 
																								
										}
										
								}
								}

							 }
							else
							{

								 DiffBomCnt = (char *) MEM_alloc(5000);                                                                       
								 tc_strcat(DiffBomCnt," "); 																	
								 //tc_strcat(DiffBomCnt,"IN Non Color VC  : ");
								 tc_strcat(DiffBomCnt,ClrItemId);
								 tc_strcat(DiffCmpBOMCntNClr,DiffBomCnt);
								 tc_strcat(DiffCmpBOMCntNClr,",");
								  ErrorFlagNClr =1; 
								
							}
						}
										
					
						}

					   }

                      if (ErrorFlag == 1)
                           {
								printf("\n Missing in Color VC  : %s ; %s \n",ClrPrtNo,DiffCmpBOMCnt );fflush(stdout);
								//fprintf(outputClr,"\n In Color VC   :%s; %s , %s , %s \n",prt,Veh_RevSeq,object_string,DiffCmpBOMCnt);
								
								 tc_strcat(DiffCmpBOMCntCmb,ClrPrtNo);
								 tc_strcat(DiffCmpBOMCntCmb,"Non-Clr Part Mis.. :");
					             tc_strcat(DiffCmpBOMCntCmb,DiffCmpBOMCnt);
								 tc_strcat(DiffCmpBOMCntCmb,",");
			  			  
                           }
						if (ErrorFlagNClr == 1)
                          {
								 printf("\n In Non Color VC :%s,%s \n",ClrPrtNo,DiffCmpBOMCntNClr );fflush(stdout);
								 //fprintf(outputNClr,"\n Missing in Non Color VC   :  %s , %s , %s \n",prt,object_string,DiffCmpBOMCntNClr );
								 tc_strcat(DiffCmpBOMCntCmb,ClrPrtNo);
								 tc_strcat(DiffCmpBOMCntCmb,"Remove From Clr VC:");
					             tc_strcat(DiffCmpBOMCntCmb,DiffCmpBOMCntNClr);
								 tc_strcat(DiffCmpBOMCntCmb,",");
						
                          }

			}

			return DiffCmpBOMCntCmb;
		}

		int ClrBOMExpansion(tag_t top_line)
		   {
				tag_t  *children				= NULLTAG;
				tag_t  *children1				= NULLTAG;
				tag_t	bl_Child_dv				= NULLTAG;

				n_Cnt					=0;
				n_Cnt1					=0;
				int     jcnt					=0;

				char * ChColourInd				= NULL;
				char * LatChildName				 = NULL;
				char * PartType1				= NULL;
				char * PartCompcode				= NULL;

				tag_t SchmWithCmpcdRel_VC	= NULLTAG;
				tag_t *CmpCodeOfClrScheme	= NULLTAG;
				tag_t CmpCodeObj			= NULLTAG;
				int Cmpcount = 0;
				int g1		 = 0;
				char *t5itemid2				= NULL;
				char *sColourInd			= NULL;
				char *t5PrtCatCd			= NULL;
				char *ClrPrtCmpCodeCmp		= NULL;
				char *sPartType				= NULL;
				char *sColourID				= NULL;
				char *SCMColorID			= NULL;
				char *ColourIDSchm			= NULL;
				char *Suffix				= NULL;
				char *tmpAdvString			= NULL;
				char *sTempItemID			= NULL;
				 
				ITK_CALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children)); //3 sept
				  printf("\n\n\t\t ****1st level VC contains child objects are :: %d \n", n_Cnt);fflush(stdout);

				if (n_Cnt>0)
				{
					printf("\n\n\t\t Inside DVP-VC No of child objects are :: %d \n", n_Cnt);fflush(stdout);
					for (jcnt=0;jcnt<n_Cnt;jcnt++)
					{
						char *RevId	=NULL;
						char *RevId2=NULL;
						int Flag =0;
						int jj = 0;
						char *sColourInd = NULL;
						char *RevId3Clr = NULL;

						 bl_Child_dv=children[jcnt];

						
						ITK_CALL(AOM_ask_value_string(bl_Child_dv, "bl_item_item_id", &RevId));
						ITK_CALL(AOM_ask_value_string(bl_Child_dv, "bl_Design Revision_t5_ColourInd", &sColourInd));
						tc_strcat(wFileClrBOMArr,RevId);
						tc_strcat(wFileClrBOMArr,",");
						//if(tc_strcmp(sColourInd,"N") == 0)
						{
						 
						for (jj=0;jj<ia ;jj++ )
						{
							tc_strcpy(RevId2,"");
							ITK_CALL(AOM_ask_value_string(tagSET[jj], "bl_item_item_id", &RevId2 ));
							if (tc_strcmp(RevId,RevId2)==0)
							{
								Flag=1;
							}
						}
						if (Flag==0)
						{
							 tagSET[ia]=bl_Child_dv;
							 ITK_CALL(AOM_ask_value_string(tagSET[ia], "bl_item_item_id", &RevId3Clr ));
							tc_strcat(ClrBOMArr," ");
							tc_strcat(ClrBOMArr,RevId3Clr);
							setAddStrInApplySVRonX4(&ia,&sFinalDataSet,RevId);
						}	
						}

								
					}
				}

			 return n_Cnt;

		   }

		   int NonClrBOMExpansion(tag_t NonClrRev_t )
			{

			int			transfermode1Cnt		= 0;
			int			n_entriesV				= 1;
			int			resultCountVNCol		= 0;
			int			n_bom_views				= 0;
			int			rulefound				= 0;
			n_lines1				= 0;
			n_lines2				= 0;
			int			p1						= 0;
			int			p2						= 0;
			int			Level					= 0;
			char		*RevTyp					= NULL;
			char		**rulename				= NULL;
			char		**rulevalue				= NULL;
			char		*AppSVR					= NULL;
			
			tag_t  *children				= NULLTAG;
			tag_t  *children1				= NULLTAG;
			tag_t	bl_Child_dv				= NULLTAG;

			n_Cnt					=0;
			n_Cnt1					=0;
			int     jcnt					=0;

			char * ChColourInd				= NULL;
			char * LatChildName				 = NULL;
			char * PartType1				= NULL;
			char * PartCompcode				= NULL;

			tag_t SchmWithCmpcdRel_VC	= NULLTAG;
			tag_t *CmpCodeOfClrScheme	= NULLTAG;
			tag_t CmpCodeObj			= NULLTAG;
			int Cmpcount = 0;
			int g1		 = 0;
			char *t5itemid2				= NULL;
			char *sColourInd			= NULL;
			char *t5PrtCatCd			= NULL;
			char *ClrPrtCmpCodeCmp		= NULL;
			char *sPartType				= NULL;
			char *sColourID				= NULL;
			char *SCMColorID			= NULL;
			char *ColourIDSchm			= NULL;
			char *Suffix				= NULL;
			char *tmpAdvString			= NULL;
			char *sTempItemID			= NULL;
			

			tag_t		plat					= NULLTAG;
			tag_t		rev						= NULLTAG;
			tag_t		RevTypTag				= NULLTAG;
			tag_t		VariqueryTag			= NULLTAG;
			tag_t		VarientRuletag			= NULLTAG;
			tag_t		item					= NULLTAG;
			tag_t		bom_view				= NULLTAG;
			tag_t		bom_window				= NULLTAG;
			tag_t		rule					= NULLTAG;
			tag_t		close_tag				= NULLTAG;
			tag_t		bl_Child_dv1			= NULLTAG;
			tag_t		ModuleLine				= NULLTAG;

			tag_t		*outputVNCol_tags		=NULLTAG;
			tag_t		*bom_views				=NULLTAG;
			tag_t		*closurerule			=NULLTAG;
			tag_t		*lines1					=NULLTAG;
			tag_t		*lines2					=NULLTAG;
			tag_t		view_type				= NULLTAG;

			tag_t		ItemSVRTag					= NULLTAG;
			tag_t		ItemRevSVRTag						= NULLTAG;
			int n_entries11 =2;
			tag_t	Cntl_obj_Qtag11	=	NULLTAG;
			tag_t	window1					= NULLTAG;
			tag_t	sn_rule1					= NULLTAG; 
			tag_t	top_line1				= NULLTAG;
							
				ITK_CALL(BOM_create_window (&window1));
				ITK_CALL(BOM_set_window_pack_all (window1, true));
				ITK_CALL(CFM_find("ERC Review And Above", &sn_rule1 ));
				ITK_CALL(BOM_set_window_config_rule( window1, sn_rule1));
				PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound, &closurerule);  // uncoment by Gajanan 15/05/23 for bom mistmatch
				if (rulefound > 0)
					{
						close_tag = closurerule[0];
						printf ("closure rule found \n");fflush(stdout);
					}
				ITK_CALL(BOM_window_set_closure_rule(window1,close_tag, 0, rulename,rulevalue));
				ITK_CALL(BOM_set_window_top_line (window1, null_tag,NonClrRev_t,null_tag, &top_line1));
				ITK_CALL(BOM_window_show_suppressed (window1));
				ITK_CALL(BOM_line_ask_child_lines(top_line1, &n_lines1, &lines1));
				printf("\n  Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);
				ITK_CALL(AOM_ask_value_string(top_line1, "bl_item_item_id", &t5itemid2));
				printf(  "\n Topline1 Item %s \n",t5itemid2); fflush(stdout); 
					
					if (n_lines1>0)
					{
						for (p1=0;p1<n_lines1;p1++ )
						{
							
							char *RevIdNClr	=NULL;
							char *RevId2NClr=NULL;
							char *RevId3NClr=NULL;
							int FlagNClr =0;
							int jj = 0;
							char *sColourInd = NULL;
							//printf("\n\n\t\t Inside for loop \n");fflush(stdout);

							bl_Child_dv1 = lines1[p1];

							ITK_CALL(AOM_ask_value_string(bl_Child_dv1, "bl_item_item_id", &RevIdNClr));
							ITK_CALL(AOM_ask_value_string(bl_Child_dv1, "bl_Design Revision_t5_ColourInd", &sColourInd));
							
							//if(tc_strcmp(sColourInd,"N") == 0)
							{

									tc_strcat(wFileNClrBOMArr,RevIdNClr);
									tc_strcat(wFileNClrBOMArr,",");
								for (jj=0;jj<iaNClr ;jj++ )
								{
									tc_strcpy(RevId2NClr,"");
									ITK_CALL(AOM_ask_value_string(tagSETNClr[jj], "bl_item_item_id", &RevId2NClr ));
									if (tc_strcmp(RevIdNClr,RevId2NClr)==0)
									{
										FlagNClr=1;
									}
								}
								if (FlagNClr==0)
								{
									tagSETNClr[iaNClr]=bl_Child_dv1;
									ITK_CALL(AOM_ask_value_string(tagSETNClr[iaNClr], "bl_item_item_id", &RevId3NClr ));
									tc_strcat(NonClrBOMArr," ");
									tc_strcat(NonClrBOMArr,RevId3NClr);
									setAddStrInApplySVRonX4(&iaNClr,&sFinalDataSetNClr,RevIdNClr);
								}	

							}
							
						
					}
						
						 
				}

					//CALLAPI(BOM_save_window(bom_window));
					//CALLAPI(BOM_close_window(bom_window));
				
				return n_lines1;
		}
tag_t GetLatestRevinSet(tag_t* SetofRev, int Count)
{
	int		i						=0;
	int		j						=0;
	int		flag					=0;
	tag_t	LatestRev				=NULLTAG;

	char	*RevId_1				= NULL;
	char	*TokRevId_1				= NULL;
	char	*RevId_2				= NULL;
	char	*TokRevId_2				= NULL;

	//printf("\n\t Inside GetLatestRevinSet ");  fflush(stdout);

	for (i=0; i<Count; i++ )
	{
		flag =0;
		if(AOM_ask_value_string(SetofRev[i],"item_revision_id",&RevId_1));
		TokRevId_1 = tc_strtok(RevId_1,";");
		//printf("\n\t TokRev1 %s \n",TokRevId_1);  fflush(stdout);

		if (tc_strcmp(TokRevId_1,"NR")!=0)
		{
			for (j=0; j<Count;j++ )
			{
				if(AOM_ask_value_string(SetofRev[j],"item_revision_id",&RevId_2));
				TokRevId_2 = tc_strtok(RevId_2,";");

				//printf("\n\t\t TokRev2 %s \n",TokRevId_2);  fflush(stdout);

				if (tc_strcmp(TokRevId_2,"NR")!=0)
				{
					if (tc_strcmp(TokRevId_1,TokRevId_2)<0)
					{
						flag=1;
					}

				}

			}
			if (flag ==0)
			{
				//printf("\n\t Latest Rev is %s \n",TokRevId_1);  fflush(stdout);
				//printf("\n\t At End GetLatestRevinSet \n\n\n");  fflush(stdout);
				return SetofRev[i];
			}
		}

	}
	printf("\n\t *** At End GetLatestRevinSet ");  fflush(stdout);
	printf ("\n--------------GetLatestRevinSet=Completed--------------------\n");fflush(stdout);

	return LatestRev;
}

		char* ClrNonClrBOMMisMatch(tag_t DMLLcmTag,int CPBOMQryC, tag_t *CPBOMCtrObj)
		{
			int		SolnItemCnt				=0;
			int		aaz						=0;
			int		sdk						=0;
			int		kk						=0;
			int		NonClr_count			=0;
			int     n_lines1				=0;
			int     n_lines2				=0;
			int     NonClrFlag				=0;
			int     BOMMisFlag				=0;
			int     PrtTypeFlag				=0;

			tag_t	ClrItemRev				=NULLTAG;
			tag_t	NonClr_Relation			=NULLTAG;
			tag_t	bom_window				=NULLTAG;
			tag_t	bom_window2				=NULLTAG;
			tag_t	rule					=NULLTAG;
			tag_t	rule2					=NULLTAG;
			tag_t	top_line				=NULLTAG;
			tag_t	top_line2				=NULLTAG;
			tag_t	*lines					=NULLTAG;
			tag_t	*lines2					=NULLTAG;

			tag_t	*SolnItemSet			=NULLTAG;
			tag_t	*NonClrSet				=NULLTAG;
			tag_t	NonClrRev_t				= NULLTAG;

			char    *ClrPrtType				= NULL;
			char	*ClrPrtNo				= NULL;
			char	*ClrPrtRevId			= NULL;
			char	*NonClrPrtNo			= NULL;
			char	*info1_value			= NULL;
			char	*BOMMisErr				= NULL;
			char	*BOMMisErr2				= NULL;
			char	*token					= NULL;
			char	*ProjectCode			= NULL;


			int rulefound2= 0;         
			tag_t *closurerule2 = NULL;
			tag_t close_tag2;          
			char **rulename2 = NULL;   
			char **rulevalue2 = NULL;

			if (tc_strcmp(BOMMisErr,"NULL") !=0) MEM_free(BOMMisErr);
			BOMMisErr=(char *)MEM_alloc(3000);

			if (tc_strcmp(BOMMisErr2,"NULL") !=0) MEM_free(BOMMisErr2);
			BOMMisErr2=(char *)MEM_alloc(3000);



			printf("\n\t ****** Inside ClrNonClrBOMMisMatch Validation ****** \n");fflush(stdout);


			ITKCALL(AOM_ask_value_tags(DMLLcmTag,"CMHasSolutionItem",&SolnItemCnt,&SolnItemSet));

			tc_strcpy(BOMMisErr," ");
			tc_strcat(BOMMisErr,"Unable to find Base Part for respective Color Part [ ");

			tc_strcpy(BOMMisErr2," ");
			tc_strcat(BOMMisErr2,"Color BOM is not match with Non-Color BOM [ ");

			for (aaz =0 ; aaz < SolnItemCnt ; aaz++)
			{
				ClrItemRev=SolnItemSet[aaz];
				ITKCALL(AOM_ask_value_string(ClrItemRev,"t5_PartType",&ClrPrtType));
				ITKCALL(AOM_ask_value_string(ClrItemRev,"item_id",&ClrPrtNo));

				ITKCALL(AOM_ask_value_string(ClrItemRev,"item_revision_id",&ClrPrtRevId));
				printf("\n Color parts is :%s;%s with part type %s \n",ClrPrtNo,ClrPrtRevId,ClrPrtType);fflush(stdout);

				ITKCALL(AOM_ask_value_string(ClrItemRev,"t5_ProjectCode",&ProjectCode));
				printf("\n\t Clr Project Code = [%s]\n\n",ProjectCode);  fflush(stdout);

				ITKCALL(GRM_find_relation_type("TC_Is_Represented_By", &NonClr_Relation));
				ITKCALL(GRM_list_secondary_objects_only(ClrItemRev,NonClr_Relation,&NonClr_count,&NonClrSet));


				printf("\n\t Non Clr Relation Found  count is = [%d] \n\n",NonClr_count);  fflush(stdout);



				if (NonClr_count>0)
				{
					NonClrRev_t	 = NULLTAG;

					if (NonClr_count ==1)
					{
						//printf("\n\t Non color count = 1 \n");
						NonClrRev_t=NonClrSet[0];
					}
					else
					{
						//printf("\n\t Non color count > 1 \n");
						NonClrRev_t=GetLatestRevinSet(NonClrSet,NonClr_count);
					}

					ITKCALL(AOM_ask_value_string(NonClrRev_t,"item_id",&NonClrPrtNo));
					printf("\n\t Non Clr Relation Found = [%s]\n\n",NonClrPrtNo);  fflush(stdout);

					kk=0;
					PrtTypeFlag=0;
					for (sdk=0; sdk < CPBOMQryC; sdk++)
					{
						printf("\n\t inside  sdk= [%d]\n", sdk);  fflush(stdout);
						ITKCALL(AOM_ask_value_string(CPBOMCtrObj[sdk],"t5_Userinfo1",&info1_value));

						token= tc_strtok(info1_value,";");
						while (token != NULL)
						{
							printf("\n\t  Patrt type's are %s\n", token);
							if(tc_strcmp(ClrPrtType,token)==0)
							{
								PrtTypeFlag=1;
								printf("\n\t  PrtTypeFlag updated to [%d]\n", PrtTypeFlag);
							}
							token = tc_strtok(NULL,";");
							kk++;
						}
					}

					printf("\n\t PrtTypeFlag  = %d \n",PrtTypeFlag);fflush(stdout);

					if(PrtTypeFlag==0)
					{
						ITKCALL ( BOM_create_window( &bom_window ));
						ITKCALL(CFM_find( "Color ERC Review and above", &rule ));
						ITKCALL(BOM_set_window_config_rule( bom_window, rule ));
						ITKCALL(BOM_set_window_pack_all(bom_window, TRUE));
						ITKCALL(BOM_set_window_top_line( bom_window , NULLTAG, ClrItemRev, NULLTAG, &top_line ));
						//printf( " BOM_set_window_top_line..\n");
						ITKCALL(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
						printf("\n\t Color Child_lines count: %d ", n_lines1);

						ITKCALL ( BOM_create_window( &bom_window2 ));

						int n_entries11 =2;
						tag_t	Cntl_obj_Qtag11	=	NULLTAG;
						char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
						char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
						int resultCount11=0;
						tag_t *qry_cntrlobj11= NULLTAG;
						char *userinfo2=NULL;

						if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));

							qry_values11[0] = "Project" ;
							qry_values11[1] = "AltrozWay" ;

						QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11);
						AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo2);

						printf("\n **************** User Info 1 ===> %s **************** \n",userinfo2);fflush(stdout);


						//if(tc_strstr(ProjectCode,userinfo2) != NULL)   // commented by Gajanan CR-FY23-0213
						//{
						//   ITKCALL(CFM_find("APLC Release and above", &rule2 ));
						//}
						//else
						//{
							ITKCALL(CFM_find("ERC release and above", &rule2 ));
						//}

						//ITKCALL(CFM_find( "APLC Release and above", &rule2 ));
						ITKCALL(BOM_set_window_config_rule( bom_window2, rule2 ));
						PIE_find_closure_rules2("BOMLineSkipZeroQtyMaskUnconfig",PIE_TEAMCENTER, &rulefound2, &closurerule2);
						if (rulefound2 > 0)
						{
							close_tag2 = closurerule2[0];
							printf ("closure rule found \n");fflush(stdout);
						}
						BOM_window_set_closure_rule(bom_window2,close_tag2, 0, rulename2,rulevalue2);
						ITKCALL(BOM_set_window_pack_all(bom_window2, TRUE));
						ITKCALL(BOM_set_window_top_line( bom_window2 , NULLTAG, NonClrRev_t, NULLTAG, &top_line2 ));
						//printf( " BOM_set_window_top_line..2\n");
						ITKCALL(BOM_line_ask_child_lines(top_line2, &n_lines2, &lines2));
						printf("\n\t NonClr Child_lines count: %d \n", n_lines2);

						if(n_lines1==n_lines2)
						{
							printf( "\n\t BOM child count match \n");
						}
						else
						{
							printf("\n\t Color-NonColor BOM mismatch found \n\n");  fflush(stdout);

							BOMMisFlag =1;

							tc_strcat(BOMMisErr2,ClrPrtNo);
							tc_strcat(BOMMisErr2,"/");
							tc_strcat(BOMMisErr2,ClrPrtRevId);
							tc_strcat(BOMMisErr2," ");
						}
					}
				}
				else
				{
					printf("\n\t Non Clr Relation Not Found   \n\n");  fflush(stdout);

					NonClrFlag = 1;

					tc_strcat(BOMMisErr,ClrPrtNo);
					tc_strcat(BOMMisErr,"/");
					tc_strcat(BOMMisErr,ClrPrtRevId);
					tc_strcat(BOMMisErr," ");
				}
			}

			tc_strcat(BOMMisErr,"]");
			tc_strcat(BOMMisErr2,"]");

			if (NonClrFlag == 1)
			{
				return BOMMisErr;
			}
			else if ( BOMMisFlag ==1)
			{
				return BOMMisErr2;
			}

			tc_strcpy(BOMMisErr," ");
			return BOMMisErr;
		}

		extern EPM_decision_t DLLAPI validateSVRCOl_vf_on_clrmodule(EPM_rule_message_t msg)
		{
			 
			  int resultCount11=0;
			  char *usr		= NULL;
				char *pass		= NULL;
				char *grp		= NULL;
				char *dml		= NULL;
				tag_t dmlTag			= NULLTAG ;
				tag_t dmlRevTag			= NULLTAG ;
				char *dmlItemId			= NULL;
				tag_t			user_tag				=NULLTAG;
				char* username=NULL;
				tag_t	Cntl_obj_Qtag11	=	NULLTAG;
			char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
			char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
			int    noAttachment=0;
				tag_t  objTypTag		= NULLTAG;
			char   *ObjTyp=NULL;
			char *Dml_taskNo = NULL;
			char *DMLNo = NULL;
			int	  PartCnt		= 0;
			tag_t*	PartTags	= NULLTAG;
			int		iLength	=	0;
			int icount_aplModCheck=0;
			tag_t *qry_cntrlobj11= NULLTAG;
			char	**SetChildRelAPLModErr = NULL;
			SetChildRelAPLModErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelAPLModErr);
			char	*tempErr	=	0;
			int icount_ebommbom_bom=0;
			int status,i=0;
			char *Arcbl_Item_id = NULL;
			char *dml_rlstype = NULL;
			char *DMLItem_id = NULL;
			char *ClrSvr_Name = NULL;
			char*	 dml_project = NULL;
			char *Svr_Project = NULL;
			char *Svr_Project1 = NULL;
			int no_bom_lines =0;
			tag_t *child_bom_lines;
			tag_t dml_tag1 = NULLTAG;
			tag_t DMLRevTag1 = NULLTAG;
			int n_entries11 =2;
			tag_t DMLTag = NULLTAG;
			tag_t			*attachments			=NULLTAG;
				tag_t			rootTask	=NULLTAG;
				EPM_decision_t decision = EPM_go;

				FullAdvString		= (char *) MEM_alloc(30000);
				tc_strcat(FullAdvString," ");
				CorrCmpBOMCnt	= (char *) MEM_alloc(10000);
				tc_strcat(CorrCmpBOMCnt," ");
				DiffCmpBOMCnt	= (char *) MEM_alloc(10000);
				tc_strcat(DiffCmpBOMCnt," ");
				NonClrBOMArr	= (char *) MEM_alloc(10000);
				tc_strcat(NonClrBOMArr," ");
				ClrBOMArr	= (char *) MEM_alloc(10000);
				tc_strcat(ClrBOMArr," ");
				ClrBOMArrSVR	= (char *) MEM_alloc(10000);
				tc_strcat(ClrBOMArrSVR," ");
				NClrBOMArrSVR	= (char *) MEM_alloc(10000);
				tc_strcat(NClrBOMArrSVR," ");
				CorrCmpBOMCntSVR	= (char *) MEM_alloc(10000);
				tc_strcat(CorrCmpBOMCntSVR," ");
				DiffCmpBOMCntSVR	= (char *) MEM_alloc(10000);
				tc_strcat(DiffCmpBOMCntSVR," ");
				ia =0;
				tagSET = (tag_t *) MEM_alloc(30000 * sizeof(tag_t));
				sFinalDataSet = (char **) MEM_alloc(1 * sizeof(char *));
				
				iaNClr =0;
				tagSETNClr = (tag_t *) MEM_alloc(30000 * sizeof(tag_t));
				sFinalDataSetClr = (char **) MEM_alloc(1 * sizeof(char *));
				sFinalDataSetNClr = (char **) MEM_alloc(1 * sizeof(char *));

				iaClrSVR =0;
				tagSETClrSVR = (tag_t *) MEM_alloc(30000 * sizeof(tag_t));
				sFinalDataSetClrSVR = (char **) MEM_alloc(1 * sizeof(char *));
				
				iaNClrSVR =0;
				tagSETNClrSVR = (tag_t *) MEM_alloc(30000 * sizeof(tag_t));
				sFinalDataSetNClrSVR = (char **) MEM_alloc(1 * sizeof(char *));
				
				tag_t		msWordType				= NULLTAG;
				tag_t		wordDataset				= NULLTAG;
				tag_t		wordLatestDat_t			= NULLTAG;
				char				* DataSetName1		= NULL;
				DataSetName1=(char *) MEM_alloc(100);
				int					n_entry				= 1;
				int					rsltCount			= 0;
				tag_t		qryTag					= NULLTAG;
				char	*qry_entry[1]		= {"Name"};
				char	**qry_values2		= (char **) MEM_alloc(10 * sizeof(char *));
				tag_t		*CntrolObjectTag		= NULLTAG;
				
				char				Data[100]			= "";
				char				outputFile[200]		= "";
				time_t				now;
				struct				tm when;
				time(&now);
				
				tag_t relation_type = NULLTAG;
				tag_t relation = NULLTAG;
				when = *localtime(&now);
				strftime(Data,100,"%d_%b_%Y_%H_%M_%S",&when);
				sprintf(outputFile,"/tmp/%s_ClrAndNonClrPart_%s.txt",dml,Data);
				printf("File Location: [%s] \n",outputFile);
				//File open here
				output = fopen(outputFile, "w");
				if (output == NULL)
				{
								printf("ERROR: Cannot open File\n");
								return -1;
				}
				else
				{
							printf("File opened successfully.\n");
				}	
			printf("\n\t Start validateSVRCOl_vf_on_clrmodule ");fflush(stdout);
			ITK_CALL(POM_get_user(&username,&user_tag));
			printf("\n Starting for taskbreskdownnn taskbreskdownnn:%s....\n",username);fflush(stdout);	
			
			ITK_CALL(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
			qry_values11[0] = "ClrSvrOnX4Chk288" ;
			qry_values11[1] = "ClrSvrOnX4Chk288" ;
			ITK_CALL(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
			printf("\n Control Object count for ClrSvrOnX4---------->%d\n",resultCount11);fflush(stdout);
			if (resultCount11 > 0)
			{
				ITK_CALL(EPM_ask_root_task(msg.task,&rootTask));
				printf("\n erc_dml_assignnnnnnnnnn \n"); fflush(stdout);

				ITK_CALL(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
				printf("\n Target Attachment:%d\n",noAttachment);fflush(stdout);

				if(noAttachment >0)
				{
					for(i=0;i<noAttachment;i++)
					{
						printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);
						if(TCTYPE_ask_object_type(attachments[i],&objTypTag));
						if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
						printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

						if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
						{
							if(AOM_ask_value_string(attachments[i],"item_id",&Dml_taskNo)!=ITK_ok)PrintErrorStack();
							printf("\n Dml_taskNo----------->%s\n",Dml_taskNo); fflush(stdout);

							DMLNo = subString(Dml_taskNo,0,10);
							printf("\n Dml_taskNo----------->%s\n",DMLNo); fflush(stdout);
							
							if(ITEM_find_item(DMLNo, &DMLTag)!=ITK_ok)PrintErrorStack();
							ITK_CALL(AOM_ask_value_string(DMLTag,"item_id",&DMLItem_id));
							printf("\n DML DMLItem_id is : %s\n",DMLItem_id);fflush(stdout);				
							
							if (DMLTag != NULLTAG)
							{
								if(ITEM_ask_latest_rev(DMLTag, &DMLRevTag1)!=ITK_ok)PrintErrorStack();
								ITK_CALL(AOM_ask_value_string(DMLRevTag1,"t5_rlstype",&dml_rlstype));
								printf("\n dml_rlstype is : %s\n",dml_rlstype);fflush(stdout);

								
								ITK_CALL(AOM_ask_value_string(DMLRevTag1,"t5_cprojectcode",&dml_project));
								printf("\n dml_project is : %s\n",dml_project);fflush(stdout);
								if((tc_strcmp(dml_rlstype,"CP")==0) )
								{
									//ITEM_find_item(dml, &dmlTag);
									ITEM_ask_latest_rev(DMLTag, &dmlRevTag);
									AOM_UIF_ask_value(dmlRevTag,"item_id",&dmlItemId);
									printf("\n\t CmpBomAndClrBOM DML item_id = %s ",dmlItemId);fflush(stdout);

									// Start Gajanan code 

									CmpBomAndClrBOM(dmlRevTag);

								printf("\n\t CmpBomAndClrBOM At Start MAIN FUN ****** \n");fflush(stdout);
									

							  if (tc_strcmp(DiffCmpBOMCnt,NULL) != 0 && tc_strcmp(DiffCmpBOMCnt," ") != 0 || (tc_strcmp(FullAdvString,NULL) != 0 && tc_strcmp(FullAdvString," ") != 0 ))
									{
										
										fprintf(output,"\n This is in Error File ");
										fclose(output);
										 
										ITK_CALL(AE_find_datasettype2("Text",&msWordType));
										tc_strcpy(DataSetName1,"");
										tc_strcat(DataSetName1,dml);
										tc_strcat(DataSetName1,"_");				
										tc_strcat(DataSetName1,Data);

										ITK_CALL(AE_create_dataset_with_id(msWordType,DataSetName1,"CompClrAndNonClr","","",&wordDataset));		
										ITK_CALL(AE_save_myself(wordDataset));
										ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
										ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
										ITK_CALL(AE_import_named_ref(wordLatestDat_t,"Text",outputFile,NULL,SS_TEXT));
										AOM_save_without_extensions(wordLatestDat_t);
										AOM_refresh(wordLatestDat_t, FALSE);
										AOM_unload(wordLatestDat_t);
											
										if(GRM_find_relation_type("TC_Attaches", &relation_type)!=ITK_ok)PrintErrorStack();;
										 GRM_create_relation(dmlRevTag, wordLatestDat_t, relation_type, NULLTAG, &relation);
										 GRM_save_relation(relation);
										 AOM_unload(dmlRevTag);
										 AOM_refresh(dmlRevTag, TRUE);
										printf("\n\t There is a mismatch observed in the base BoM and the colour BoM as solved by the colour SVR under release.\n Please refer the report attached to the DML task for details. \n Please contact PLM support team for further help. The release of colour SVR cannot go ahead with this mismatch. \n");fflush(stdout);
										printf("\n %s  ",DiffCmpBOMCnt); fflush(stdout);
										EMH_clear_errors();
										EMH_store_error_s1(EMH_severity_error,ITK_PLMError,"\n There is a mismatch observed in the base BoM and the colour BoM as solved by the colour SVR under release.\n Please refer the report attached to the DML task for details. \n Please contact PLM support team for further help. The release of colour SVR cannot go ahead with this mismatch.");
										decision = EPM_nogo;
										

									}
									else
									{
										printf("\n\t  Unable to Mismach Solution Part \n");fflush(stdout);
										decision = EPM_go;
									}

								 CmpBomSVRAndClrBOMSVR(dmlRevTag);

							if (tc_strcmp(DiffCmpBOMCntSVR,NULL) != 0 && tc_strcmp(DiffCmpBOMCntSVR," ") != 0)
							{
								 fprintf(output,"\n This is in Error File ");
								 fclose(output);
										 
								ITK_CALL(AE_find_datasettype2("Text",&msWordType));
								tc_strcpy(DataSetName1,"");
								tc_strcat(DataSetName1,dml);
								tc_strcat(DataSetName1,"_");				
								tc_strcat(DataSetName1,Data);

								ITK_CALL(AE_create_dataset_with_id(msWordType,DataSetName1,"CompClrAndNonClr","","",&wordDataset));		
								ITK_CALL(AE_save_myself(wordDataset));
								ITK_CALL(AE_ask_dataset_latest_rev(wordDataset,&wordLatestDat_t));
								ITK_CALL(AOM_refresh(wordLatestDat_t,TRUE));
								ITK_CALL(AE_import_named_ref(wordLatestDat_t,"Text",outputFile,NULL,SS_TEXT));
								AOM_save_without_extensions(wordLatestDat_t);
								AOM_refresh(wordLatestDat_t, FALSE);
								AOM_unload(wordLatestDat_t);
											
								GRM_find_relation_type("TC_Attaches", &relation_type);
								GRM_create_relation(dmlRevTag, wordLatestDat_t, relation_type, NULLTAG, &relation);
								GRM_save_relation(relation);
								AOM_unload(dmlRevTag);
								AOM_refresh(dmlRevTag, TRUE);
								
								printf("\n %s  ",DiffCmpBOMCntSVR); fflush(stdout);
								EMH_clear_errors();
								EMH_store_error_s1(EMH_severity_error,ITK_PLMError,"\n There is a mismatch observed in the base BoM and the colour BoM as solved by the colour SVR under release.\n Please refer the report attached to the DML task for details. \n Please contact PLM support team for further help. The release of colour SVR cannot go ahead with this mismatch.");
								decision = EPM_nogo;
								break;

							}
							else
							{
							  fprintf(output,"\n This is Correct File ");
							  fclose(output);
							  printf("\n\t  Unable to Mismach SVR Part \n");fflush(stdout);
							  decision = EPM_go;
							}


							printf("\n\t CmpBomAndClrBOM At End of MAIN FUN ****** \n");fflush(stdout);
									//return ITK_ok;
								}
							}
						}
					}
				}
			}
				
				return decision;
		}
		int CmpBomAndClrBOM(tag_t dmlRevTag)
			{
			   
				 tag_t dmlRelType			= NULLTAG ;
				 tag_t *clrScmTag			= NULLTAG ;
				 tag_t ColSchmRevTag		= NULLTAG ;
				 tag_t SVRRelType			= NULLTAG ;
				 tag_t *AppliSvrsRelTags		= NULLTAG ;
				 tag_t CmpCodeObj			= NULLTAG ;
				 tag_t cmRefRelType			= NULLTAG ;
				 tag_t *cmRefSVRTag			= NULLTAG ;
				 tag_t  NonClrSVR				= NULLTAG ;
				 
				 char *AppSVR				= NULL;
				 char *Platform				= NULL;
				 char *SVR					= NULL;
				 char *RevisionRule			= NULL;
				 char *RevisionRule1			= NULL;
				 char *RevisionRule3			= NULL;
				 int dmlCount				= 0;
				 int cmRefCount				= 0;
				 int svrCount				= 0;
				 int i						= 0;
			 
				 GRM_find_relation_type("IMAN_reference",&dmlRelType);
				 if(GRM_list_secondary_objects_only(dmlRevTag,dmlRelType,&dmlCount,&clrScmTag)!=ITK_ok);
				 if(dmlCount>0)
					{
					  if(ColSchmRevTag) ColSchmRevTag = NULLTAG;
					   ColSchmRevTag=clrScmTag[0];
						 AOM_UIF_ask_value(ColSchmRevTag,"t5_SchmPlant",&Platform);		
						printf("\n\t Platform = %s \n", Platform);fflush(stdout);
					   if(GRM_find_relation_type("T5_Applicable_SVR",&SVRRelType)!=ITK_ok);
						if(GRM_list_secondary_objects_only(ColSchmRevTag,SVRRelType,&svrCount,&AppliSvrsRelTags)!=ITK_ok);
						if(svrCount>0)
						{
							if(CmpCodeObj) CmpCodeObj=NULLTAG;
							CmpCodeObj=AppliSvrsRelTags[0];
				
						if (AOM_UIF_ask_value(CmpCodeObj,"object_string",&AppSVR)!=ITK_ok);
					
							
							DMLTaskRelation(dmlRevTag,ColSchmRevTag);
							//SVRBOMExpantion(Platform,AppSVR,RevisionRule,ColSchmRevTag);   
							//printf("\n Unable to Matches BOM as below... %s",DiffCmpBOMCnt);fflush(stdout);
				
				
						}
						else
						{
							printf("\n\t Applicable_SVR Not Found ");fflush(stdout);
						}
				
				
					}
					else
					{
						printf("\n\t Colour Scheme  Not Found ");fflush(stdout);
					}

					   
			   return ITK_ok;
		}

		int DMLTaskRelation(tag_t dmlRevTag ,tag_t ColSchmRevTag)
			{
				tag_t	DMLToTaskRel	        = NULLTAG; 
				tag_t	DesignrevTag			= NULLTAG;
				tag_t	*Tsk_objects			= NULLTAG;
				tag_t	part_tsk_rel			= NULLTAG;
				tag_t	*PartsTag				= NULLTAG;
				tag_t	window					= NULLTAG;
				tag_t	sn_rule					= NULLTAG; 

				tag_t   DML_tag					= NULLTAG;
				tag_t	top_line				= NULLTAG;
				tag_t	top_line1				= NULLTAG;
				tag_t	DesignMasterTag			= NULLTAG; 
				tag_t	govClrSchmTag			= NULLTAG;
				tag_t	NonCLrPrtRevTag			= NULLTAG;
				tag_t	ReptRelType				= NULLTAG;
				tag_t	*NonClrPrtTag			= NULLTAG;
				int		NonClrPrtcnt			= 0;
				int		Nprt					= 0;
				int     hasSolnFlag             = 0;
				int		tsk_cnt					= 0;
				int		partcnt					= 0;
				int		i						= 0;
				int		prt						= 0;
				char * PrtNo					= NULL;
				char * PartType					= NULL;
				char * clrRevTag				= NULL;
				char * PrtDR					= NULL;
				char * partNumber				= NULL;
				char *NonClrPartNo  			= NULL; 
				char *Govt_class_SchmRevTag  			= NULL; 
				int ClrCnt = 0;
				int NonClrCnt = 0;
				int wFileFlag = 0 ;				

					ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation", &DMLToTaskRel));
					ITK_CALL(GRM_list_secondary_objects_only(dmlRevTag,DMLToTaskRel,&tsk_cnt,&Tsk_objects));
					if (tsk_cnt>0)
					{
					   for (i=0;i<tsk_cnt ;i++ )
					   {
						
							ITK_CALL(GRM_find_relation_type("CMHasSolutionItem", &part_tsk_rel));
							if (part_tsk_rel!=NULLTAG)
								{
								  ITK_CALL(GRM_list_secondary_objects_only(Tsk_objects[i], part_tsk_rel, &partcnt, &PartsTag));
									printf("\n  partcnt.:%d\n",partcnt);fflush(stdout);

								if (partcnt>0)
								{
									for (prt=0;prt<partcnt ;prt++ )
									{
										 wFileFlag = 0 ;
										char *DiffCmpBOMCntqty1	= (char *) MEM_alloc(10000);
													tc_strcat(DiffCmpBOMCntqty1," ");

										wFileClrBOMArr	= (char *) MEM_alloc(10000);
										tc_strcat(wFileClrBOMArr," ");

										wFileNClrBOMArr	= (char *) MEM_alloc(10000);
										tc_strcat(wFileNClrBOMArr," ");
										PrtNo					= NULL;
										char *CorrBomCnt = NULL;
										char *DiffBomCnt;
										char *subColSchm = NULL;
										DesignrevTag=PartsTag[prt];

												ITK_CALL(AOM_ask_value_string(DesignrevTag,"item_id",&PrtNo));
											ITK_CALL(AOM_ask_value_string(DesignrevTag,"t5_PartType",&PartType));
											ITK_CALL(AOM_ask_value_string(DesignrevTag,"t5_PartStatus",&PrtDR));
											ITK_CALL(AOM_ask_value_string(DesignrevTag,"item_revision_id",&clrRevTag));
											ITK_CALL(AOM_ask_value_string(DesignrevTag,"gov_classification",&Govt_class_SchmRevTag));
											printf("\n Clr Part Number = %s , Part Type= %s, Revision = %s , Clr Scheme = %s \n",PrtNo,PartType,clrRevTag,Govt_class_SchmRevTag);fflush(stdout);												
											if ((tc_strcmp(PartType,"A")==0)||(tc_strcmp(PartType,"V")==0) || (tc_strcmp(PartType,"VC")==0) || (tc_strcmp(PartType,"Configurable VC")==0) || (tc_strcmp(PartType,"Vehicle")==0))
											{
												printf("\nSetting VC into Structure manager and checking Vehicle present or not \n");fflush(stdout);
												ITK_CALL(BOM_create_window (&window)); //3 sept	
												ITK_CALL(BOM_set_window_pack_all (window, true));//3 sept
												ITK_CALL(CFM_find("Color ERC Review and above", &sn_rule ));
												ITK_CALL(BOM_set_window_config_rule( window, sn_rule)); 
													
												ITK_CALL(BOM_set_window_top_line (window, null_tag,DesignrevTag,null_tag, &top_line));

												ITK_CALL(BOM_window_show_suppressed (window));

												printf("\n -------------------VC to Vehicle Expansion----- \n");fflush(stdout);

												ITK_CALL(AOM_ask_value_string(top_line,"bl_item_item_id",&partNumber));// 3 sept

												printf("\n DVP-VC Part number===>%s \n",partNumber);fflush(stdout);
											   
											   subColSchm=strtok(Govt_class_SchmRevTag,"#");
											   printf("\n Clr part Colour Scm ===>%s \n",subColSchm);fflush(stdout);
											   ITK_CALL(ITEM_find_item(subColSchm, &govClrSchmTag));
												ClrCnt=ClrSCM_BOMExpansion(top_line , govClrSchmTag);


											   ITK_CALL(GRM_find_relation_type("TC_Is_Represented_By", &ReptRelType));
											   ITK_CALL(GRM_list_secondary_objects_only(DesignrevTag, ReptRelType, &NonClrPrtcnt, &NonClrPrtTag));
											   if (NonClrPrtcnt>0)
												{
													for (Nprt=0;Nprt<NonClrPrtcnt ;Nprt++ )
													{
														NonCLrPrtRevTag=NonClrPrtTag[Nprt];
														 char *RevisionRule  ="ERC release and above";
														 char *Platform  ="X4";
														ITK_CALL(AOM_ask_value_string(NonCLrPrtRevTag,"item_id",&NonClrPartNo));
														printf("\n Non Clr Part number===>%s \n",NonClrPartNo);fflush(stdout);
														NonClrCnt = BOMExpantion(Platform,NonClrPartNo,RevisionRule,ColSchmRevTag);

													}
												}
											
											fprintf(output,"\n");
											fprintf(output,"\n Colour Part List : %s\n",PrtNo);
											fprintf(output,"'%s",wFileClrBOMArr);
											fprintf(output,"\n Non-Colour Part List : %s\n",NonClrPartNo);
											fprintf(output,"'%s",wFileNClrBOMArr);
											int jkl =0;
											int jk =0;
											tag_t  NClrBOMTag = NULLTAG;
											tag_t  ClrBOMTag = NULLTAG;
											char *NClrItemId = NULL;
											char *NClrquantity = NULL; 
											
											char *Clrquantity = NULL;
												
											if (ClrCnt == NonClrCnt )  // count  compare
											{    
											
											
											 printf("\n All Clr Part number bl_item_item_id===>%s \n",ClrBOMArr);fflush(stdout);
											
											 printf("\n All Non-Clr Part number bl_item_item_id===>%s \n",NonClrBOMArr);fflush(stdout);
											wFileFlag = 0 ;
												for (jk=0;jk<ia ;jk++ )
												{   
													
													ClrBOMTag = NULLTAG;
													char *ClrItemId = NULL;
													Clrquantity = NULL;
												
													  ClrBOMTag=tagSET[jk];
													  ITK_CALL(AOM_ask_value_string(ClrBOMTag, "bl_item_item_id", &ClrItemId ));
													 // printf("\n Clr Part number bl_item_item_id===>%s \n",ClrItemId);fflush(stdout);
													if(tc_strstr(NonClrBOMArr,ClrItemId) != NULL)    // part compare
													{

														 for (jkl=0;jkl<iaNClr ;jkl++ )
														{   
															NClrBOMTag = NULLTAG;
															NClrItemId = NULL;
															NClrquantity = NULL;
														
															NClrBOMTag=tagSETNClr[jkl];
															ITK_CALL(AOM_ask_value_string(NClrBOMTag, "bl_item_item_id", &NClrItemId ));
															//printf("\n Non-Clr Part number bl_item_item_id===>%s \n",NClrItemId);fflush(stdout);
															if(tc_strstr(ClrBOMArr,NClrItemId) != NULL)    // part compare
															{
																//printf("\n Non-Clr Part number bl_item_item_id inside if===>%s \n",NClrItemId);fflush(stdout);
																	if (tc_strcmp(NClrItemId,ClrItemId) == 0)
																	{
																		 ITK_CALL(AOM_ask_value_string(ClrBOMTag, "bl_quantity", &Clrquantity ));
																		ITK_CALL(AOM_ask_value_string(NClrBOMTag, "bl_quantity", &NClrquantity ));
																		if (tc_strcmp(Clrquantity,NClrquantity) != 0 )   // quntity compare
																		{
																			printf("\n Main clr part = %s   [Clr Part : %s=%s, ===> Non-Clr Part : %s=%s   ] \n",PrtNo,ClrItemId,Clrquantity,NClrItemId ,NClrquantity);fflush(stdout);
																			printf("\n Break Statement ..... \n");fflush(stdout);
																			DiffBomCnt = (char *) MEM_alloc(500);                                                                       
																			tc_strcat(DiffBomCnt," "); 
																			
																			tc_strcat(DiffBomCnt,"Quantity issue :");
																			tc_strcat(DiffBomCnt,ClrItemId);
																			tc_strcat(DiffCmpBOMCntqty1,DiffBomCnt);
																			tc_strcat(DiffCmpBOMCntqty1,",");
																			wFileFlag = 1;
																			
																			//break;
																		}
																	}

																}
																else 
																{
																	

																			DiffBomCnt = (char *) MEM_alloc(5000);                                                                       
																			tc_strcat(DiffBomCnt," "); 																	
																			tc_strcat(DiffBomCnt,"Color Part Missing  issue :");
																			tc_strcat(DiffBomCnt,NClrItemId);
																			tc_strcat(DiffCmpBOMCntqty1,DiffBomCnt);
																			tc_strcat(DiffCmpBOMCntqty1,",");
																			wFileFlag = 1;

																	
																}
														}

													 }
													else
													{

														 DiffBomCnt = (char *) MEM_alloc(5000);                                                                       
														 tc_strcat(DiffBomCnt," "); 																	
														 tc_strcat(DiffBomCnt,"Non Color Part Missing  issue :");
														 tc_strcat(DiffBomCnt,ClrItemId);
														 tc_strcat(DiffCmpBOMCntqty1,DiffBomCnt);
														 tc_strcat(DiffCmpBOMCntqty1,",");
														 wFileFlag = 1;
													
														
													}
																
											
												}
											}
											else
											{
												DiffBomCnt = (char *) MEM_alloc(5000);                                                                       
												tc_strcat(DiffBomCnt," "); 																	
												tc_strcat(DiffBomCnt,"Part Count Missing issue :");
												tc_strcat(DiffBomCnt,PrtNo);
												tc_strcat(DiffCmpBOMCntqty1,DiffBomCnt);
												tc_strcat(DiffCmpBOMCntqty1,",");
												wFileFlag = 1;
																												
											}
								
										}
									printf("\n wFileFlag : %d\n",wFileFlag);
									if (wFileFlag == 1)
									{

									if ((tc_strcmp(DiffCmpBOMCntqty1,NULL) != 0 && tc_strcmp(DiffCmpBOMCntqty1," ") != 0 ))
									{
										fprintf(output,"\n Below part List Getting Issue \n");
										fprintf(output,"'%s",DiffCmpBOMCntqty1);
										printf("\n Below part List Getting Issue :\n %s\n",DiffCmpBOMCntqty1);
										tc_strcat(DiffCmpBOMCnt,DiffCmpBOMCntqty1);
										tc_strcat(DiffCmpBOMCnt,",");
										tc_strcpy(DiffCmpBOMCntqty1," ");
										
										wFileFlag == 0;	
									}
										
									}															   
								}
								
							}

						}
								
					}


				}
								
			  return ITK_ok;
			}
		int  ClrSCM_BOMExpansion(tag_t	top_line ,tag_t ColSchmRevTag)
		{   
			tag_t  *children				= NULLTAG;
			tag_t  *children1				= NULLTAG;
			tag_t	bl_Child_dv				= NULLTAG;

			n_Cnt					=0;
			n_Cnt1					=0;
			int     jcnt					=0;

			char * ChColourInd				= NULL;
			char * LatChildName				 = NULL;
			char * PartType1				= NULL;
			char * PartCompcode				= NULL;

			tag_t SchmWithCmpcdRel_VC	= NULLTAG;
			tag_t *CmpCodeOfClrScheme	= NULLTAG;
			tag_t CmpCodeObj			= NULLTAG;
			int Cmpcount = 0;
			int g1		 = 0;
			char *t5itemid2				= NULL;
			char *sColourInd			= NULL;
			char *t5PrtCatCd			= NULL;
			char *ClrPrtCmpCodeCmp		= NULL;
			char *sPartType				= NULL;
			char *sColourID				= NULL;
			char *SCMColorID			= NULL;
			char *ColourIDSchm			= NULL;
			char *Suffix				= NULL;
			char *tmpAdvString			= NULL;
			char *sTempItemID			= NULL;
					
			ITK_CALL(BOM_line_ask_child_lines (top_line, &n_Cnt, &children)); //3 sept
			printf("\n\n\t\t ****1st level VC contains child objects are :: %d \n", n_Cnt);fflush(stdout);

			if (n_Cnt>0)
			{
				printf("\n\n\t\t Inside DVP-VC No of child objects are :: %d \n", n_Cnt);fflush(stdout);
				for (jcnt=0;jcnt<n_Cnt;jcnt++)
				{
					char *RevId	=NULL;
					char *RevId2=NULL;
					int Flag =0;
					int jj = 0;
					char *sColourInd = NULL;
					char *RevId3Clr = NULL;

					 bl_Child_dv=children[jcnt];

					
					ITK_CALL(AOM_ask_value_string(bl_Child_dv, "bl_item_item_id", &RevId));
					ITK_CALL(AOM_ask_value_string(bl_Child_dv, "bl_Design Revision_t5_ColourInd", &sColourInd));
					tc_strcat(wFileClrBOMArr,RevId);
					tc_strcat(wFileClrBOMArr,",");
					if(tc_strcmp(sColourInd,"N") == 0)
					{
					 
					for (jj=0;jj<ia ;jj++ )
					{
						tc_strcpy(RevId2,"");
						ITK_CALL(AOM_ask_value_string(tagSET[jj], "bl_item_item_id", &RevId2 ));
						if (tc_strcmp(RevId,RevId2)==0)
						{
							Flag=1;
						}
					}
					if (Flag==0)
					{
						 tagSET[ia]=bl_Child_dv;
						 ITK_CALL(AOM_ask_value_string(tagSET[ia], "bl_item_item_id", &RevId3Clr ));
						tc_strcat(ClrBOMArr," ");
						tc_strcat(ClrBOMArr,RevId3Clr);
						setAddStrInApplySVRonX4(&ia,&sFinalDataSet,RevId);
					}	
					}

					if(tc_strcmp(sColourInd,"C") == 0)
					{

					ITK_CALL(AOM_ask_value_string(bl_Child_dv,"bl_item_item_id",&LatChildName));
					//printf("\n VC LatChildName Parts Id : [%s] \n",LatChildName);
					ITK_CALL(AOM_ask_value_string(bl_Child_dv,"bl_Design Revision_t5_ColourInd",&ChColourInd));
					ITK_CALL(AOM_ask_value_string(bl_Child_dv,"bl_Design Revision_t5_PartType",&PartType1));
					ITK_CALL(AOM_ask_value_string(bl_Child_dv,"bl_T5_ClrPartRevision_t5_PrtCatCode",&PartCompcode));
					ITK_CALL(AOM_ask_value_string(bl_Child_dv,"bl_T5_ClrPartRevision_t5_ColourID",&sColourID));
					//printf("\nChildName Parts Type 11 : [%s] \n",PartType1);
					ITK_CALL(BOM_line_ask_child_lines (bl_Child_dv, &n_Cnt1, &children1));
					//printf("\n\n\t\t **** 2nd  level child Count are :: %d \n", n_Cnt1);fflush(stdout);

						if((tc_strcmp(ChColourInd,"C")==0))
						{
							if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel_VC)!=ITK_ok);
							if(GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel_VC, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok);
							//printf("\n Comp Code Cmpcount for Color Scheme : %d\n",Cmpcount); fflush(stdout);
							if(Cmpcount > 0)
							{
								
								for(g1=0;g1<Cmpcount;g1++ )
								{	
									 ClrPrtCmpCodeCmp		= NULL;
									 ColourIDSchm			= NULL;
									if(CmpCodeObj) CmpCodeObj=NULLTAG;
									CmpCodeObj=CmpCodeOfClrScheme[g1];
									if(AOM_ask_value_string(CmpCodeObj, "t5_PrtCatCode", &ClrPrtCmpCodeCmp)!=ITK_ok);
									if(AOM_ask_value_string(CmpCodeObj, "t5_ClSrl", &SCMColorID)!=ITK_ok);
										Suffix =  strtok(SCMColorID,";");
										ColourIDSchm  =  strtok(NULL,";");
									
									if(tc_strcmp(PartCompcode,ClrPrtCmpCodeCmp) ==0 && tc_strcmp(sColourID,ColourIDSchm) !=0)
									{
										printf("\n\t For Colour Ind C Matches with compcode and color of scheme  =>[%s=%s],[%s =%s],[%s] \n",PartCompcode,ClrPrtCmpCodeCmp,sColourID,ColourIDSchm,LatChildName);fflush(stdout);

											printf(  "\n For Colour Ind C Parent item =  [%s] \n",LatChildName); fflush(stdout);
										
											if (tc_strcmp(sTempItemID,NULL) == 0)
											{
												tc_strcpy(sTempItemID,"");
												tc_strcpy(sTempItemID,LatChildName);
												//printf("unique id %s",sTempItemID);
											   tmpAdvString = (char *) MEM_alloc(60000);
											   tc_strcat(tmpAdvString," ");
											   sprintf(tmpAdvString,"\nPartNo %s with Comp Code %s and  colour %s is already Released in different Colour Structure than this Colour Scheme",LatChildName,PartCompcode,sColourID);
											   tc_strcat(FullAdvString,tmpAdvString);
											}
											//printf("\n copy item  = [%s]",sTempItemID);

											if (tc_strstr(FullAdvString,LatChildName) == NULL)
											{	
																							
												
											   tmpAdvString = (char *) MEM_alloc(60000);
											   tc_strcat(tmpAdvString," ");
											   sprintf(tmpAdvString,"\nPartNo %s with Comp Code %s and  colour %s is already Released in different Colour Structure than this Colour Scheme",LatChildName,PartCompcode);
											   tc_strcat(FullAdvString,tmpAdvString);
											}
										
									}																											
								}
								fprintf(output,"\n Already Released in different Colour Structure than this Colour Scheme :");
								fprintf(output,"'%s",FullAdvString);
								printf("Already Released in different Colour Structure than this Colour Scheme : \n %s ..",FullAdvString);
								
							}

						}
					}
					
					
				}
			}

		  return n_Cnt;
		}

		int BOMExpantion(char* Platform,char* SVR,char* RevisionRule,tag_t ColSchmRevTag)
		{

			int			transfermode1Cnt		= 0;
			int			n_entriesV				= 1;
			int			resultCountVNCol		= 0;
			int			n_bom_views				= 0;
			int			rulefound				= 0;
			n_lines1				= 0;
			n_lines2				= 0;
			int			p1						= 0;
			int			p2						= 0;
			int			Level					= 0;
			char		*RevTyp					= NULL;
			char		**rulename				= NULL;
			char		**rulevalue				= NULL;
			char		*AppSVR					= NULL;
			
			tag_t  *children				= NULLTAG;
			tag_t  *children1				= NULLTAG;
			tag_t	bl_Child_dv				= NULLTAG;

			n_Cnt					=0;
			n_Cnt1					=0;
			int     jcnt					=0;

			char * ChColourInd				= NULL;
			char * LatChildName				 = NULL;
			char * PartType1				= NULL;
			char * PartCompcode				= NULL;

			tag_t SchmWithCmpcdRel_VC	= NULLTAG;
			tag_t *CmpCodeOfClrScheme	= NULLTAG;
			tag_t CmpCodeObj			= NULLTAG;
			int Cmpcount = 0;
			int g1		 = 0;
			char *t5itemid2				= NULL;
			char *sColourInd			= NULL;
			char *t5PrtCatCd			= NULL;
			char *ClrPrtCmpCodeCmp		= NULL;
			char *sPartType				= NULL;
			char *sColourID				= NULL;
			char *SCMColorID			= NULL;
			char *ColourIDSchm			= NULL;
			char *Suffix				= NULL;
			char *tmpAdvString			= NULL;
			char *sTempItemID			= NULL;		
			tag_t		plat					= NULLTAG;
			tag_t		rev						= NULLTAG;
			tag_t		RevTypTag				= NULLTAG;
			tag_t		VariqueryTag			= NULLTAG;
			tag_t		VarientRuletag			= NULLTAG;
			tag_t		item					= NULLTAG;
			tag_t		bom_view				= NULLTAG;
			tag_t		bom_window				= NULLTAG;
			tag_t		rule					= NULLTAG;
			tag_t		close_tag				= NULLTAG;
			tag_t		top_line				= NULLTAG;
			tag_t		bl_Child_dv1			= NULLTAG;
			tag_t		ModuleLine				= NULLTAG;

			tag_t		*outputVNCol_tags		=NULLTAG;
			tag_t		*bom_views				=NULLTAG;
			tag_t		*closurerule			=NULLTAG;
			tag_t		*lines1					=NULLTAG;
			tag_t		*lines2					=NULLTAG;
			tag_t		view_type				= NULLTAG;

			tag_t		ItemSVRTag					= NULLTAG;
			tag_t		ItemRevSVRTag						= NULLTAG;
			int n_entries11 =2;
			tag_t	Cntl_obj_Qtag11	=	NULLTAG;
			char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
			char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
			int resultCount11=0;
			tag_t *qry_cntrlobj11= NULLTAG;
			char *userinfo11=NULL;
			char *clrRevTag=NULL;
			char *myvarientname				=	NULL;
			char		*qry_entries3[1]		= {"Name"};

			char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));

			printf("\n\t ********************INSIDE BOMCorrect FUN*****************8 \n");fflush(stdout);
			printf("\n\t RevisionRule %s \n",RevisionRule);fflush(stdout);

			int n_entries =2;
			tag_t query = NULLTAG;
			char *qry_entries[2] = {"SYSCD","SUBSYSCD"};
			char **qry_values = (char **) MEM_alloc(50 * sizeof(char *));
			int count=0;
			tag_t *contrlObjs= NULLTAG;
			char* Info1Str = NULL;
			char* Info2Str = NULL;
			char* Info3Str = NULL;
			char* Info4Str = NULL;
			char* Info5Str = NULL;
			char* Info6Str = NULL;
			char* Info7Str = NULL;
			char* Info8Str = NULL;
			char* Info9Str = NULL;
			char* Info10Str = NULL;
			char *VCNo = NULL;

				if(QRY_find2("Control Objects...", &query));		 
				qry_values[0] = "Hornbill_Way_VC" ;
				qry_values[1] = "Hornbill_Way" ;
				QRY_execute(query, n_entries, qry_entries, qry_values, &count, &contrlObjs);
				if (count>0)
				{ 
					tag_t cntrlObj = NULLTAG;
					cntrlObj = contrlObjs[0];
					
				 if(cntrlObj!=NULLTAG)
				 {
					 
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo1",&Info1Str));        
					printf("\n Veh-Release--Info1Str: [%s]", Info1Str);fflush(stdout);    
																						
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo2",&Info2Str));        
					printf("\n Veh-Release--Info2Str: [%s]", Info2Str);fflush(stdout);  
																						
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo3",&Info3Str));        
					printf("\n Veh-Release--Info3Str: [%s]", Info3Str);fflush(stdout);  
																						
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo4",&Info4Str));        
					printf("\n Veh-Release--Info4Str: [%s]", Info4Str);fflush(stdout);  
																						
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo5",&Info5Str));        
					printf("\n Veh-Release--Info5Str: [%s]", Info5Str);fflush(stdout);  
																						
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo6",&Info6Str));        
					printf("\n Veh-Release--Info6Str: [%s]", Info6Str);fflush(stdout);  
																						
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo7",&Info7Str));        
					printf("\n Veh-Release--Info7Str: [%s]", Info7Str);fflush(stdout);  
																						
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo8",&Info8Str));        
					printf("\n Veh-Release--Info8Str: [%s]", Info8Str);fflush(stdout);  
																						
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo9",&Info9Str));        
					printf("\n Veh-Release--Info9Str: [%s]", Info9Str);fflush(stdout);  
																						
					if(AOM_ask_value_string(cntrlObj,"t5_Userinfo10",&Info10Str));      
					printf("\n Veh-Release--Info10Str: [%s]", Info10Str);fflush(stdout);
				}
			}
							  VCNo = subString(SVR,0,12);
							  printf(" --VCNo: [%s] ", VCNo);fflush(stdout);

				  if((tc_strstr(Info1Str,VCNo)!=NULL)||(tc_strstr(Info2Str,VCNo)!=NULL) ||(tc_strstr(Info3Str,VCNo)!=NULL)||(tc_strstr(Info4Str,VCNo)!=NULL) ||(tc_strstr(Info5Str,VCNo)!=NULL)||(tc_strstr(Info6Str,VCNo)!=NULL) ||(tc_strstr(Info7Str,VCNo)!=NULL)||(tc_strstr(Info8Str,VCNo)!=NULL) ||(tc_strstr(Info9Str,VCNo)!=NULL)||(tc_strstr(Info10Str,VCNo)!=NULL))
					{
							printf("\n **** For 5445 And live projects **** \n");fflush(stdout);
							ITK_CALL(ITEM_find_item(Platform, &plat));
							ITK_CALL(ITEM_ask_latest_rev(plat, &ItemRevSVRTag));
							ITK_CALL(AOM_ask_value_string(ItemRevSVRTag,"item_revision_id",&clrRevTag));
				
							printf("\n Non Clr Latest Revision = %s\n",clrRevTag);fflush(stdout);
				
							if(TCTYPE_ask_object_type(ItemRevSVRTag, &RevTypTag));
							if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
							printf("\n\t MT: RevTyp type: [%s]\n", RevTyp);fflush(stdout);
				
								if(QRY_find2("VariantRule", &VariqueryTag));
							printf("\n\t After IFERR_REPORT : QRY_find2 .... "); fflush(stdout);
							
							valuesNonColSvr[0] = SVR ;
							if(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));
							printf("   n_entriesV:%d   resultCount:%d \n\t",n_entriesV,resultCountVNCol); fflush(stdout);
							
							if (resultCountVNCol > 0)
							{
								VarientRuletag = outputVNCol_tags[0];
							}
							else
							{
								printf ("\n NonColour-SVR-VarientRule not present  [%s]\n", SVR); fflush(stdout);
								exit (0);
							}	
				
					}			
				  else
					{
						AppSVR=subString(SVR,0,12);fflush(stdout);
						printf("\n **** for 5442 And live projects **** \n");fflush(stdout);
						ITK_CALL(ITEM_find_item(AppSVR, &ItemSVRTag));
						ITK_CALL(ITEM_ask_latest_rev(ItemSVRTag, &ItemRevSVRTag));
						ITK_CALL(AOM_ask_value_string(ItemRevSVRTag,"item_revision_id",&clrRevTag));
						printf("\n Non Clr Latest Revision %s\n",clrRevTag);fflush(stdout);
				
				
					}
					
			//if (tc_strcmp(RevTyp,"T5_PlatformRevision")==0)
			//{
			

			if (ItemRevSVRTag !=NULLTAG )
			{
				CALLAPI ( PS_find_view_type( "view", &view_type ));
				printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

				if ( view_type != NULLTAG )
				{
					CALLAPI ( ITEM_ask_item_of_rev( ItemRevSVRTag, &item ));
					CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

					bom_view = bom_views[0];

				}
				else
					printf("\nView not found check.......\n"); fflush(stdout);

			}

			if ( bom_view != NULLTAG )
			{
				printf(" before BOM_create_window..\n");fflush(stdout);   
				CALLAPI ( BOM_create_window( &bom_window ));
				CALLAPI(CFM_find( RevisionRule, &rule ));
				CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
				
				
				CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
				
				printf ("rule count %d \n",rulefound);fflush(stdout);
				if (rulefound > 0)
				{
					close_tag = closurerule[0];
					printf ("closure rule found \n");fflush(stdout);
				}

				CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));
				CALLAPI ( BOM_set_window_top_line( bom_window, NULLTAG, ItemRevSVRTag, NULLTAG, &top_line ));
				printf( " After BOM_set_window_top_line..\n");fflush(stdout);		
			  
				
				if(top_line!=NULLTAG)
				{
					CALLAPI(BOM_window_hide_unconfigured(bom_window));
					CALLAPI(BOM_window_show_variants(bom_window));
				  if(strstr(userinfo11,myvarientname))
					{
					printf("\n After inside bom_window-----\n"); fflush(stdout);                                    
					CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
					printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
					}
					char * t5itemid4 = NULL;
					CALLAPI(BOM_window_hide_variants(bom_window));				
					CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines1));
					printf("\n  Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);
					ITK_CALL(AOM_ask_value_string(top_line, "bl_item_item_id", &t5itemid4));
					printf(  "\n Topline Item %s \n",t5itemid4); fflush(stdout); 
					if (n_lines1>0)
					{
						for (p1=0;p1<n_lines1;p1++ )
						{
							
							char *RevIdNClr	=NULL;
							char *RevId2NClr=NULL;
							char *RevId3NClr=NULL;
							int FlagNClr =0;
							int jj = 0;
							char *sColourInd = NULL;
							//printf("\n\n\t\t Inside for loop \n");fflush(stdout);

							bl_Child_dv1 = lines1[p1];

							ITK_CALL(AOM_ask_value_string(bl_Child_dv1, "bl_item_item_id", &RevIdNClr));
							ITK_CALL(AOM_ask_value_string(bl_Child_dv1, "bl_Design Revision_t5_ColourInd", &sColourInd));
							
							if(tc_strcmp(sColourInd,"N") == 0)
							{

							  tc_strcat(wFileNClrBOMArr,RevIdNClr);
							  tc_strcat(wFileNClrBOMArr,",");
								for (jj=0;jj<iaNClr ;jj++ )
								{
									tc_strcpy(RevId2NClr,"");
									ITK_CALL(AOM_ask_value_string(tagSETNClr[jj], "bl_item_item_id", &RevId2NClr ));
									if (tc_strcmp(RevIdNClr,RevId2NClr)==0)
									{
										FlagNClr=1;
									}
								}
								if (FlagNClr==0)
								{
									tagSETNClr[iaNClr]=bl_Child_dv1;
									ITK_CALL(AOM_ask_value_string(tagSETNClr[iaNClr], "bl_item_item_id", &RevId3NClr ));
									tc_strcat(NonClrBOMArr," ");
									tc_strcat(NonClrBOMArr,RevId3NClr);
									setAddStrInApplySVRonX4(&iaNClr,&sFinalDataSetNClr,RevIdNClr);
								}	

							}
							if(tc_strcmp(sColourInd,"Y") == 0)
							{
									tc_strcat(wFileNClrBOMArr,RevIdNClr);
									tc_strcat(wFileNClrBOMArr,",");
							}
						
								
				
					}
						
						 
				}

					//CALLAPI(BOM_save_window(bom_window));
					//CALLAPI(BOM_close_window(bom_window));
			}

			}
			else
			{
				printf(  "\n\t no bom window found here \n"); fflush(stdout); 
			}
				//}
				return n_lines1;
		}


		int CmpBomSVRAndClrBOMSVR(tag_t dmlRevTag)
		{

			 tag_t dmlRelType			= NULLTAG ;
			 tag_t *clrScmTag			= NULLTAG ;
			 tag_t ColSchmRevTag		= NULLTAG ;
			 tag_t SVRRelType			= NULLTAG ;
			 tag_t *AppliSvrsRelTags		= NULLTAG ;
			 tag_t CmpCodeObj			= NULLTAG ;
			 tag_t cmRefRelType			= NULLTAG ;
			 tag_t *cmRefSVRTag			= NULLTAG ;
			 tag_t  NonClrSVR				= NULLTAG ;
			 
			 char *AppSVR				= NULL;
			 char *clrSCM				= NULL;
			 char *Platform				= NULL;
			 char *SVR					= NULL;
			 char *RevisionRule1			= NULL;
			 char *RevisionRule3			= NULL;
			 int dmlCount				= 0;
			 int cmRefCount				= 0;
			 int svrCount				= 0;
			 int i						= 0;
		 
			 GRM_find_relation_type("IMAN_reference",&dmlRelType);
			 if(GRM_list_secondary_objects_only(dmlRevTag,dmlRelType,&dmlCount,&clrScmTag)!=ITK_ok);
			 if(dmlCount>0)
				{
				 // if(ColSchmRevTag) ColSchmRevTag = NULLTAG;
				  // ColSchmRevTag=clrScmTag[0];
					//AOM_UIF_ask_value(ColSchmRevTag,"item_id",&clrSCM);
					//printf("\n\t SVR ClrScheam  = %s \n", clrSCM);fflush(stdout);
					//AOM_UIF_ask_value(ColSchmRevTag,"t5_SchmPlant",&Platform);		
					//printf("\n\t SVR Platform = %s \n", Platform);fflush(stdout);
				   
					  GRM_find_relation_type("CMReferences",&cmRefRelType);
					  if(GRM_list_secondary_objects_only(dmlRevTag,cmRefRelType,&cmRefCount,&cmRefSVRTag)!=ITK_ok);
					  printf("\n CMReferences count %d = %s",cmRefCount);
					  if (cmRefCount>0)
					  {
						  for (i=0;i<cmRefCount ;i++ )
						  {  
							char *CorrBomCntSVR = NULL;
							char *DiffBomCntSVR = NULL;
							  char *SVRId	= NULL;
							  char *SVRRev	= NULL;
							  char *SubSVR	= NULL;
							  SVRNClr =  (char *) MEM_alloc(50);
							RevisionRule1 ="Color ERC Review and above";
							Platform ="X4";
							NonClrSVR				= NULLTAG ;
							NonClrSVR=cmRefSVRTag[i];
							ITK_CALL(AOM_ask_value_string(NonClrSVR,"object_name",&SVR));
							printf("\n\t IMAN_reference SVR  = %s ",SVR);fflush(stdout);
							int cntClrsvr = SVRCLRBOMExpantion(Platform,SVR,RevisionRule1,ColSchmRevTag);
							printf("\nTotal Clr SVR  Module  Single level count %d = %s",cntClrsvr,ClrBOMArrSVR);
							SVRId=strtok (SVR,"_");
							SVRRev=strtok (NULL,"_");
							printf(" SVR Rev %s",SVRRev);
							SubSVR=subString(SVR,0,8);
							//tc_strcat(SVRNClr," ");
							tc_strcat(SVRNClr,SubSVR);
							tc_strcat(SVRNClr,"000R");
							tc_strcat(SVRNClr,"_");
							tc_strcat(SVRNClr,SVRRev);
							printf("\nNon-Clr SVR = %s",SVRNClr);
							RevisionRule3 = "ERC release and above";
							int cntNClrsvr = SVRNONCLRBOMExpantion(Platform,SVRNClr,RevisionRule3,ColSchmRevTag);
							printf("\nTotal Non Clr SVR  Module  Single level count %d = %s",cntNClrsvr,NClrBOMArrSVR);

									int jkl =0;
									int jk =0;
									tag_t  NClrBOMTag = NULLTAG;
									tag_t  ClrBOMTag = NULLTAG;
									char *NClrItemId = NULL;
									char *NClrquantity = NULL; 
									char *ClrItemId = NULL;
									char *Clrquantity = NULL;
										
									if (cntClrsvr == cntNClrsvr )  // count  compare
									{      
									 printf("\n All Non-Clr SVR Part number bl_item_item_id===>%s \n",NClrBOMArrSVR);fflush(stdout);
									 printf("\n All Clr SVR Part number bl_item_item_id===>%s \n",ClrBOMArrSVR);fflush(stdout);

										for (jk=0;jk<iaClrSVR ;jk++ )
										{   
											ClrBOMTag = NULLTAG;
											ClrItemId = NULL;
											Clrquantity = NULL;
										
											  ClrBOMTag=tagSETClrSVR[jk];
											  ITK_CALL(AOM_ask_value_string(ClrBOMTag, "bl_item_item_id", &ClrItemId ));
											  printf("\n Clr PartSVR number bl_item_item_id===>%s \n",ClrItemId);fflush(stdout);
											if(tc_strstr(NClrBOMArrSVR,ClrItemId) != NULL)    // part compare
											{

												 for (jkl=0;jkl<iaNClrSVR ;jkl++ )
												{   
													NClrBOMTag = NULLTAG;
													NClrItemId = NULL;
													NClrquantity = NULL;
												
													NClrBOMTag=tagSETNClrSVR[jkl];
													ITK_CALL(AOM_ask_value_string(NClrBOMTag, "bl_item_item_id", &NClrItemId ));
													printf("\n Non-Clr SVR Part number bl_item_item_id===>%s \n",NClrItemId);fflush(stdout);
													if(tc_strstr(ClrBOMArrSVR,NClrItemId) != NULL)    // part compare
													{
															if (tc_strcmp(NClrItemId,ClrItemId) == 0)
															{
																 ITK_CALL(AOM_ask_value_string(ClrBOMTag, "bl_quantity", &Clrquantity ));
																ITK_CALL(AOM_ask_value_string(NClrBOMTag, "bl_quantity", &NClrquantity ));
																printf("\n Clr SVR Part and Non-Clr Part  bl_quantity  ===>[%s=%s] \n",Clrquantity,NClrquantity);fflush(stdout);
																if (tc_strcmp(Clrquantity,NClrquantity) != 0 )   // quntity compare
																{
																	DiffBomCntSVR = (char *) MEM_alloc(5000);                                                                       
																	tc_strcat(DiffBomCntSVR," ");                                                                                   
																	sprintf(DiffBomCntSVR,SVR);
																	tc_strcat(DiffCmpBOMCntSVR,DiffBomCntSVR); 
																	break;

																}
															}

														}
														else 
														{
															DiffBomCntSVR = (char *) MEM_alloc(5000);                                                                      
															tc_strcat(DiffBomCntSVR," ");                                                                                  
															sprintf(DiffBomCntSVR,SVR);	
															tc_strcat(DiffCmpBOMCntSVR,DiffBomCntSVR);  
															break;
														}
												}

											 }
											else
											{

												DiffBomCntSVR = (char *) MEM_alloc(5000);                                                                      
												tc_strcat(DiffBomCntSVR," ");                                                                                  
												sprintf(DiffBomCntSVR,SVR);	
												tc_strcat(DiffCmpBOMCntSVR,DiffBomCntSVR);
												break;
											}
														
									
										}
									}
									else
									{
										DiffBomCntSVR = (char *) MEM_alloc(5000);                                                                      
										tc_strcat(DiffBomCntSVR," ");                                                                                  
										sprintf(DiffBomCntSVR,SVR);	
										tc_strcat(DiffCmpBOMCntSVR,DiffBomCntSVR);  
										break;
									}


						  }
					  }
					  else
					  {
							printf("\n\t Change Reference is Empty ");fflush(stdout);
					  }


					}
					else
					{
						printf("\n\t Colour Scheme  Not Found ");fflush(stdout);
					}

							return ITK_ok;
		}


		int SVRCLRBOMExpantion(char* Platform,char* SVR,char* RevisionRule,tag_t ColSchmRevTag)
		{

					int			transfermode1Cnt		= 0;
					int			n_entriesV				= 1;
					int			resultCountVNCol		= 0;
					int			n_bom_views				= 0;
					int			rulefound				= 0;
					n_lines1SVR				= 0;
					n_lines2SVR				= 0;
					int			p1						= 0;
					int			p2						= 0;
					int			Level					= 0;
					int         CountItem				= 0;
					char		*RevTyp					= NULL;
					char		**rulename				= NULL;
					char		**rulevalue				= NULL;
					char		*AppSVR					= NULL;
					tag_t		plat					= NULLTAG;
					tag_t		rev						= NULLTAG;
					tag_t		RevTypTag				= NULLTAG;
					tag_t		VariqueryTag			= NULLTAG;
					tag_t		VarientRuletag			= NULLTAG;
					tag_t		item					= NULLTAG;
					tag_t		bom_view				= NULLTAG;
					tag_t		bom_window				= NULLTAG;
					tag_t		rule					= NULLTAG;
					tag_t		close_tag				= NULLTAG;
					tag_t		top_line				= NULLTAG;
					tag_t		bl_Child_dv1			= NULLTAG;
					tag_t		ModuleLine				= NULLTAG;

					tag_t		*outputVNCol_tags		=NULLTAG;
					tag_t		*bom_views				=NULLTAG;
					tag_t		*closurerule			=NULLTAG;
					tag_t		*lines1					=NULLTAG;
					tag_t		*lines2					=NULLTAG;
					tag_t		view_type				= NULLTAG;

					tag_t		ItemSVRTag					= NULLTAG;
					tag_t		ItemRevSVRTag						= NULLTAG;
					int n_entries11 =2;
					tag_t	Cntl_obj_Qtag11	=	NULLTAG;
					char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
					char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
					int resultCount11=0;
					tag_t *qry_cntrlobj11= NULLTAG;
					char *userinfo11=NULL;
					char *clrRevTag=NULL;
					char *myvarientname				=	NULL;
					char		*qry_entries3[1]		= {"Name"};

					char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));


					printf("\n\t ********************INSIDE BOMCorrect FUN*****************8 \n");fflush(stdout);
					printf("\n\t RevisionRule %s \n",RevisionRule);fflush(stdout);

						//if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));

							//qry_values11[0] = "CLRSCMPROJ" ;
							//qry_values11[1] = "CLRSCMPROJ" ;

						//QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11);
							//AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo11);
							//printf("\n **************** User Info 1 ===> %s **************** \n",userinfo11);fflush(stdout);
							 // myvarientname = subString(SVR,0,4);	
							 // printf("\n **************** MY Varient Name ===> %s **************** \n",myvarientname);fflush(stdout);
							 //if(strstr(userinfo11,myvarientname))
								//{
										printf("\n **** For 5445 And live projects **** \n");fflush(stdout);
										ITK_CALL(ITEM_find_item(Platform, &plat));
										ITK_CALL(ITEM_ask_latest_rev(plat, &ItemRevSVRTag));
										ITK_CALL(AOM_ask_value_string(ItemRevSVRTag,"item_revision_id",&clrRevTag));
							
										printf("\n Non Clr Latest Revision %s=%s\n",clrRevTag);fflush(stdout);
							
										if(TCTYPE_ask_object_type(ItemRevSVRTag, &RevTypTag));
										if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
										printf("\n\t MT: RevTyp type: [%s]\n", RevTyp);fflush(stdout);
							
											if(QRY_find2("VariantRule", &VariqueryTag));
										printf("\n\t After IFERR_REPORT : QRY_find2 .... "); fflush(stdout);
										
										valuesNonColSvr[0] = SVR ;
										if(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));
										printf("   n_entriesV:%d   resultCount:%d \n\t",n_entriesV,resultCountVNCol); fflush(stdout);
										
										if (resultCountVNCol > 0)
										{
											VarientRuletag = outputVNCol_tags[0];
										}
										else
										{
											printf ("\n NonColour-SVR-VarientRule not present  [%s]\n", SVR); fflush(stdout);
											exit (0);
										}	
							
							//	}
							//
							//  else
							//	{
							//		AppSVR=subString(SVR,0,12);fflush(stdout);
							//		printf("\n **** for 5442 And live projects **** \n");fflush(stdout);
							//		ITK_CALL(ITEM_find_item(AppSVR, &ItemSVRTag));
							//		ITK_CALL(ITEM_ask_latest_rev(ItemSVRTag, &ItemRevSVRTag));
							//		ITK_CALL(AOM_ask_value_string(ItemRevSVRTag,"item_revision_id",&clrRevTag));
							//		printf("\n Non Clr Latest Revision %s\n",clrRevTag);fflush(stdout);
							//
							//
							//	}
							

									

					if (tc_strcmp(RevTyp,"T5_PlatformRevision")==0)
					{
					

					if (ItemRevSVRTag !=NULLTAG )
					{
						CALLAPI ( PS_find_view_type( "view", &view_type ));
						printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

						if ( view_type != NULLTAG )
						{
							CALLAPI ( ITEM_ask_item_of_rev( ItemRevSVRTag, &item ));
							CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

							bom_view = bom_views[0];

						}
						else
							printf("\nView not found check.......\n"); fflush(stdout);

					}

					if ( bom_view != NULLTAG )
					{
						printf(" before BOM_create_window..\n");fflush(stdout);   
						CALLAPI ( BOM_create_window( &bom_window ));
						CALLAPI(CFM_find( RevisionRule, &rule ));
						CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
						
						
						CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
						
						printf ("rule count %d \n",rulefound);fflush(stdout);
						if (rulefound > 0)
						{
							close_tag = closurerule[0];
							printf ("closure rule found \n");fflush(stdout);
						}

						CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));
						CALLAPI ( BOM_set_window_top_line( bom_window, NULLTAG, ItemRevSVRTag, NULLTAG, &top_line ));
						printf( " After BOM_set_window_top_line..\n");fflush(stdout);		
					  
						
						if(top_line!=NULLTAG)
						{
							CALLAPI(BOM_window_hide_unconfigured(bom_window));
							CALLAPI(BOM_window_show_variants(bom_window));
						  //if(strstr(userinfo11,myvarientname))
							//{
							printf("\n After inside bom_window-----\n"); fflush(stdout);                                    
							CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
							printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
							//}
							char * t5itemid4 = NULL;
							CALLAPI(BOM_window_hide_variants(bom_window));				
							CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1SVR, &lines1));
							printf("\n  Before setting option n_lines1SVR: %d \n", n_lines1SVR); fflush(stdout);
							ITK_CALL(AOM_ask_value_string(top_line, "bl_item_item_id", &t5itemid4));
							printf(  "\n Topline Item %s \n",t5itemid4); fflush(stdout); 
							if (n_lines1SVR>0)
							{
								for (p1=0;p1<n_lines1SVR;p1++ )
								{
									
									char *RevIdClrSVR	=NULL;
									char *RevId2ClrSVR=NULL;
									char *RevId3ClrSVR=NULL;
									int FlagClrSVR =0;
									int jj = 0;
									char *sColourInd = NULL;
									//printf("\n\n\t\t Inside for loop \n");fflush(stdout);

									bl_Child_dv1 = lines1[p1];

									
								


								//ITK_CALL(AOM_ask_value_string(bl_Child_dv1, "bl_item_item_id", &t5itemid5));
								//printf(  "\n 2nd level child Item  %s \n",t5itemid5); fflush(stdout); 
								CALLAPI(BOM_line_ask_child_lines(bl_Child_dv1, &n_lines2SVR, &lines2));
								printf(  "\n 2nd level child count %d \n",n_lines2SVR); fflush(stdout); 
								if (n_lines2SVR >0)
								{
									for (p2=0;p2<n_lines2SVR;p2++ )
									{
										char *BLitemid	=NULL;
										char *t5itemid3	=NULL;
										char *t5PrtCatCd	=NULL;
										char *t5VariantFormula	=NULL;
										if(ModuleLine) ModuleLine=NULLTAG;
										ModuleLine=lines2[p2];
										

											ITK_CALL(AOM_ask_value_string(ModuleLine, "bl_item_item_id", &RevIdClrSVR));
											ITK_CALL(AOM_ask_value_string(ModuleLine, "bl_Design Revision_t5_ColourInd", &sColourInd));
											if(tc_strcmp(sColourInd,"C") != 0 && tc_strcmp(sColourInd,"Y") != 0)
											{

												for (jj=0;jj<iaNClr ;jj++ )
												{
													tc_strcpy(RevId2ClrSVR,"");
													ITK_CALL(AOM_ask_value_string(tagSETClrSVR[jj], "bl_item_item_id", &RevId2ClrSVR ));
													if (tc_strcmp(RevIdClrSVR,RevId2ClrSVR)==0)
													{
														FlagClrSVR=1;
													}
												}
												if (FlagClrSVR==0)
												{
													tagSETClrSVR[iaClrSVR]=ModuleLine;
													ITK_CALL(AOM_ask_value_string(tagSETClrSVR[iaClrSVR], "bl_item_item_id", &RevId3ClrSVR ));
													tc_strcat(ClrBOMArrSVR," ");
													tc_strcat(ClrBOMArrSVR,RevId3ClrSVR);
													setAddStrInApplySVRonX4(&iaClrSVR,&sFinalDataSetClrSVR,RevIdClrSVR);
													CountItem++;
												}	

											}
																			 
									 }
								}
							}
								
								 
						}

							//CALLAPI(BOM_save_window(bom_window));
							//CALLAPI(BOM_close_window(bom_window));
					}

					}
					else
					{
						printf(  "\n\t no bom window found here \n"); fflush(stdout); 
					}
				   }
						return CountItem;
				}

				int SVRNONCLRBOMExpantion(char* PlatformSVR,char* NCLRSVR,char* RevisionRuleClrSVR,tag_t ColSchmRevTag)
					{

					int			transfermode1Cnt		= 0;
					int			n_entriesV				= 1;
					int			resultCountVNCol		= 0;
					int			n_bom_views				= 0;
					int			rulefound				= 0;
					n_lines1SVR				= 0;
					n_lines2SVR				= 0;
					int			p1						= 0;
					int			p2						= 0;
					int			Level					= 0;
					int         CountItem				= 0;
					char		*RevTyp					= NULL;
					char		**rulename				= NULL;
					char		**rulevalue				= NULL;
					char		*AppSVR					= NULL;
					tag_t		plat					= NULLTAG;
					tag_t		rev						= NULLTAG;
					tag_t		RevTypTag				= NULLTAG;
					tag_t		VariqueryTag			= NULLTAG;
					tag_t		VarientRuletag			= NULLTAG;
					tag_t		item					= NULLTAG;
					tag_t		bom_view				= NULLTAG;
					tag_t		bom_window				= NULLTAG;
					tag_t		rule					= NULLTAG;
					tag_t		close_tag				= NULLTAG;
					tag_t		top_line				= NULLTAG;
					tag_t		bl_Child_dv1			= NULLTAG;
					tag_t		ModuleLine				= NULLTAG;

					tag_t		*outputVNCol_tags		=NULLTAG;
					tag_t		*bom_views				=NULLTAG;
					tag_t		*closurerule			=NULLTAG;
					tag_t		*lines1					=NULLTAG;
					tag_t		*lines2					=NULLTAG;
					tag_t		view_type				= NULLTAG;

					tag_t		ItemSVRTag					= NULLTAG;
					tag_t		ItemRevSVRTag						= NULLTAG;
					int n_entries11 =2;
					tag_t	Cntl_obj_Qtag11	=	NULLTAG;
					char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
					char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
					int resultCount11=0;
					tag_t *qry_cntrlobj11= NULLTAG;
					char *userinfo11=NULL;
					char *clrRevTag=NULL;
					char *myvarientname				=	NULL;
					char		*qry_entries3[1]		= {"Name"};

					char	**valuesNonColSvr = (char **) MEM_alloc(1 * sizeof(char *));


					printf("\n\t ********************INSIDE BOMCorrect FUN*****************8 \n");fflush(stdout);
					printf("\n\t RevisionRuleClrSVR %s \n",RevisionRuleClrSVR);fflush(stdout);

						//if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));

							//qry_values11[0] = "CLRSCMPROJ" ;
							//qry_values11[1] = "CLRSCMPROJ" ;

						//QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11);
						//	AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo11);
							//printf("\n **************** User Info 1 ===> %s **************** \n",userinfo11);fflush(stdout);
							 // myvarientname = subString(NCLRSVR,0,4);	
							 // printf("\n **************** MY Varient Name ===> %s **************** \n",myvarientname);fflush(stdout);
							 //if(strstr(userinfo11,myvarientname))
								//{
										printf("\n **** For 5445 And live projects **** \n");fflush(stdout);
										ITK_CALL(ITEM_find_item(PlatformSVR, &plat));
										ITK_CALL(ITEM_ask_latest_rev(plat, &ItemRevSVRTag));
										ITK_CALL(AOM_ask_value_string(ItemRevSVRTag,"item_revision_id",&clrRevTag));
							
										printf("\n Non Clr Latest Revision %s\n",clrRevTag);fflush(stdout);
							
										if(TCTYPE_ask_object_type(ItemRevSVRTag, &RevTypTag));
										if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
										printf("\n\t MT: RevTyp type: [%s]\n", RevTyp);fflush(stdout);
							
											if(QRY_find2("VariantRule", &VariqueryTag));
										printf("\n\t After IFERR_REPORT : QRY_find2 .... "); fflush(stdout);
										
										valuesNonColSvr[0] = NCLRSVR ;
										if(QRY_execute(VariqueryTag, n_entriesV, qry_entries3, valuesNonColSvr, &resultCountVNCol, &outputVNCol_tags));
										printf("   n_entriesV:%d   resultCount:%d \n\t",n_entriesV,resultCountVNCol); fflush(stdout);
										
										if (resultCountVNCol > 0)
										{
											VarientRuletag = outputVNCol_tags[0];
										}
										else
										{
											printf ("\n NonColour-NCLRSVR-VarientRule not present  [%s]\n",NCLRSVR); fflush(stdout);
											exit (0);
										}	
							
							//	}
							//
							//  else
							//	{
							//		AppSVR=subString(SVR,0,12);fflush(stdout);
							//		printf("\n **** for 5442 And live projects **** \n");fflush(stdout);
							//		ITK_CALL(ITEM_find_item(AppSVR, &ItemSVRTag));
							//		ITK_CALL(ITEM_ask_latest_rev(ItemSVRTag, &ItemRevSVRTag));
							//		ITK_CALL(AOM_ask_value_string(ItemRevSVRTag,"item_revision_id",&clrRevTag));
							//		printf("\n Non Clr Latest Revision %s\n",clrRevTag);fflush(stdout);
							//
							//
							//	}
							

									

					if (tc_strcmp(RevTyp,"T5_PlatformRevision")==0)
					{
					

					if (ItemRevSVRTag !=NULLTAG )
					{
						CALLAPI ( PS_find_view_type( "view", &view_type ));
						printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

						if ( view_type != NULLTAG )
						{
							CALLAPI ( ITEM_ask_item_of_rev( ItemRevSVRTag, &item ));
							CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

							bom_view = bom_views[0];

						}
						else
							printf("\nView not found check.......\n"); fflush(stdout);

					}

					if ( bom_view != NULLTAG )
					{
						printf(" before BOM_create_window..\n");fflush(stdout);   
						CALLAPI ( BOM_create_window( &bom_window ));
						CALLAPI(CFM_find( RevisionRuleClrSVR, &rule ));
						CALLAPI(BOM_set_window_config_rule( bom_window, rule ));
						
						
						CALLAPI(PIE_find_closure_rules2( "BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule ));
						
						printf ("rule count %d \n",rulefound);fflush(stdout);
						if (rulefound > 0)
						{
							close_tag = closurerule[0];
							printf ("closure rule found \n");fflush(stdout);
						}

						CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));
						CALLAPI ( BOM_set_window_top_line( bom_window, NULLTAG, ItemRevSVRTag, NULLTAG, &top_line ));
						printf( " After BOM_set_window_top_line..\n");fflush(stdout);		
					  
						
						if(top_line!=NULLTAG)
						{
							CALLAPI(BOM_window_hide_unconfigured(bom_window));
							CALLAPI(BOM_window_show_variants(bom_window));
						  //if(strstr(userinfo11,myvarientname))
							//{
							printf("\n After inside bom_window-----\n"); fflush(stdout);                                    
							CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&VarientRuletag))   ;
							printf("\n After BOM_window_apply_variant_configuration-----\n"); fflush(stdout);
							//}
							char * t5itemid4 = NULL;
							CALLAPI(BOM_window_hide_variants(bom_window));				
							CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1SVR, &lines1));
							printf("\n  Before setting option n_lines1SVR: %d \n", n_lines1SVR); fflush(stdout);
							ITK_CALL(AOM_ask_value_string(top_line, "bl_item_item_id", &t5itemid4));
							printf(  "\n Topline Item %s \n",t5itemid4); fflush(stdout); 
							if (n_lines1SVR>0)
							{
								for (p1=0;p1<n_lines1SVR;p1++ )
								{
									
									char *RevIdNClrSVR	=NULL;
									char *RevId2NClrSVR=NULL;
									char *RevId3NClrSVR=NULL;
									int FlagNClrSVR =0;
									int jj = 0;
									char *sColourInd = NULL;
									//printf("\n\n\t\t Inside for loop \n");fflush(stdout);

									bl_Child_dv1 = lines1[p1];

						
								//ITK_CALL(AOM_ask_value_string(bl_Child_dv1, "bl_item_item_id", &t5itemid5));
								//printf(  "\n 2nd level child Item  %s \n",t5itemid5); fflush(stdout); 
								CALLAPI(BOM_line_ask_child_lines(bl_Child_dv1, &n_lines2SVR, &lines2));
								printf(  "\n 2nd level child count %d \n",n_lines2SVR); fflush(stdout); 
								if (n_lines2SVR >0)
								{
									for (p2=0;p2<n_lines2SVR;p2++ )
									{
										char *BLitemid	=NULL;
										char *t5itemid3	=NULL;
										char *t5PrtCatCd	=NULL;
										char *t5VariantFormula	=NULL;
										if(ModuleLine) ModuleLine=NULLTAG;
										ModuleLine=lines2[p2];
										

											ITK_CALL(AOM_ask_value_string(ModuleLine, "bl_item_item_id", &RevIdNClrSVR));
											ITK_CALL(AOM_ask_value_string(ModuleLine, "bl_Design Revision_t5_ColourInd", &sColourInd));
											if(tc_strcmp(sColourInd,"C") != 0 && tc_strcmp(sColourInd,"Y") != 0)
											{

												for (jj=0;jj<iaNClr ;jj++ )
												{
													tc_strcpy(RevId2NClrSVR,"");
													ITK_CALL(AOM_ask_value_string(tagSETNClrSVR[jj], "bl_item_item_id", &RevId2NClrSVR ));
													if (tc_strcmp(RevIdNClrSVR,RevId2NClrSVR)==0)
													{
														FlagNClrSVR=1;
													}
												}
												if (FlagNClrSVR==0)
												{
													tagSETNClrSVR[iaNClrSVR]=ModuleLine;
													ITK_CALL(AOM_ask_value_string(tagSETNClrSVR[iaNClrSVR], "bl_item_item_id", &RevId3NClrSVR ));
													tc_strcat(NClrBOMArrSVR," ");
													tc_strcat(NClrBOMArrSVR,RevId3NClrSVR);
													setAddStrInApplySVRonX4(&iaNClrSVR,&sFinalDataSetNClrSVR,RevIdNClrSVR);
													CountItem++;
												}	

											}

																			 
									 }
								}
							}
								
								 
						}

							//CALLAPI(BOM_save_window(bom_window));
							//CALLAPI(BOM_close_window(bom_window));
					}

					}
					else
					{
						printf(  "\n\t no bom window found here \n"); fflush(stdout); 
					}
				}
						return CountItem;
		}

		extern EPM_decision_t DLLAPI multiple_module_status(EPM_rule_message_t msg)
		{
		  int			ifail				= 0;
		  int         stat                    = ITK_ok;
		  char        *ItemId                 = NULL;
		  
		  char        *RevId                  = NULL;
		  char        *VCItemId               = NULL;
		  char        *SVRType                = NULL;
		  tag_t        rev                    = NULLTAG;
		  tag_t        rev1                   = NULLTAG;
		  tag_t		 view_type				= NULLTAG;
		  int    n_bom_views=0;
		  int    j=0;
		  tag_t *bom_views=NULL;
		  tag_t  bom_view_type=NULLTAG;
		  int    bom_view_index=0;
		  int    noAttachment=0;
		  tag_t  item=NULLTAG;
		  tag_t        bom_view					=NULLTAG;
		  tag_t			*attachments			=NULLTAG;
		  tag_t			dataset					= NULLTAG;
		  tag_t   e_block=NULLTAG;
		  tag_t DMLTag = NULLTAG;
		  tag_t   bom_window=NULLTAG;
		  tag_t   window2=NULLTAG;
		  tag_t   top_line=NULLTAG;
		  tag_t   top_line1=NULLTAG;
		  tag_t   rule	=NULLTAG;
		  tag_t   Childobject33=NULLTAG;
		  int     n_saved_variant_rules=0;
		  tag_t  *saved_variant_rules=NULLTAG;
		  tag_t   bom_variant_rule=NULLTAG;
		  logical list_changed=FALSE;
		  int     n_options=0;
		  int     errorflag=0;
		  int     ErrZeroflag = 0;
		  int     n_option_data=0,p1=0;
		  tag_t topline = NULLTAG;
		  int n_lines,n_lines1,Item_ID = 0;
		  tag_t *lines = NULL;
		  tag_t			relation_type		= NULLTAG;
		  tag_t			Gmrelation_type		= NULLTAG;
		  char *child_item_id15=NULL;
		  char *objecttype=NULL;
		  char *objectname=NULL;
		  logical modB=FALSE;
		  char MulModule[1900] = { 0 };
		  char MulArchiNode[1900] = { 0 };
		  char MulChild[1900] = { 0 };
		  int i,cnt = 0;
		  tag_t  primary1=NULLTAG;
		  tag_t			rootTask	=NULLTAG;
		  EPM_decision_t decision = EPM_go;
		  
		  tag_t  objTypeTagDi=NULLTAG;
		  tag_t  objTypeTagDi1=NULLTAG;
		  tag_t  opt_tag=NULLTAG;
		  tag_t  master_tag=NULLTAG;
		  tag_t  Itemmaster_tag=NULLTAG;
		  tag_t  *opts=NULLTAG;
		  tag_t  *rootLine=NULL;
		  tag_t  bom_variant_config=NULLTAG;
		  tag_t  *opt_revs=NULLTAG;
		  tag_t  *secondaries=NULL;
		  tag_t  *occs=NULL;
		  tag_t  relation_dep	= NULLTAG;
		  tag_t *occsal;
		  tag_t  *secondary_objects	= NULLTAG;
		  tag_t  *secondary_objects1	= NULLTAG;
		  GRM_relation_t *primary_list_Dep	= NULLTAG;
		  tag_t   *status_list          = NULLTAG;
		  int p34=0;
		  tag_t	queryTag	= NULLTAG;
		  int n_entries = 1;
		  char *qry_entries[1] = {"ID"};
		  int resultCount=0;
		  int    n_ves,n_opts,k=0,k1=0,Opt1=0,n_values1=0,n_secondaries=0,countDep,countDep1=0;
		  tag_t			*attachments1							= NULLTAG;
		  char*			username				=NULL;
		  char **rulename = NULL;
		  char **rulevalue = NULL;
		  tag_t  	objTypeTag=NULLTAG;
		  tag_t  	objTypeTag1=NULLTAG;
		  tag_t *closurerule = NULL;
		  
		  tag_t *bvs, *bvrs;
		  int    bv_count, bvr_count;
		  tag_t        bv,bvr,parentBvr,bv1,bvr1       = NULLTAG;
		  tag_t        Childrev                = NULLTAG;
		  tag_t			user_tag				=NULLTAG;
		  int rulefound= 0;
		  
		  tag_t close_tag;
		  tag_t ** 	variant_rule_list= NULLTAG;
		  tag_t top_bomline;
		  tag_t clause_list = NULLTAG; 
		  
		  tag_t X4ItemTag = NULLTAG;		  
		  tag_t X4ItemRevTag = NULLTAG;	
		  char  *typeName=NULL;
		  char  *typeName1 =NULL;
		  int iChildItemTag;
		  tag_t t_ChildItemRev=NULLTAG;
		  char *Arcbl_Item_id = NULL;
		  char *dml_rlstype = NULL;
		  char *DMLItem_id = NULL;
		  char *ClrSvr_Name = NULL;
		  char *Svr_Project = NULL;
		  char *Svr_Project1 = NULL;
		  int no_bom_lines =0;
		  tag_t *child_bom_lines;
		  tag_t dml_tag1 = NULLTAG;
		  tag_t DMLRevTag1 = NULLTAG;
		  
		  int n_entries11 =2;
		  tag_t	Cntl_obj_Qtag11	=	NULLTAG;
		  char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
		  char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
		  int resultCount11=0;
		  tag_t *qry_cntrlobj11= NULLTAG;
		  
		  //VARIABLE DECLARATION FOR DML DR STATUS & COLOR PART DR STATUS CHECK
		  char    **CPgMQryEntryValue     =  (char **) MEM_alloc(100 * sizeof(char *));
		  tag_t   CP_gMCtrObjQryTag      = NULLTAG;
		  int     GMenry_Count  = 2;
		  char    *CPGMQryEntry[2]  = {"SUBSYSCD","SYSCD"};
		  int     CPGMQryC    = 0;
		  int     CP_Tsk_part_Count    = 0;
		  int     n_attchs1    = 0;
		  int     l    = 0;
		  tag_t   *CPGMCtrObj      = NULLTAG;
		  tag_t class_id2=NULLTAG;
		  char *class_name2;
		  tag_t  *secondary_GMobjects = NULLTAG;
		  char* Object_id		= NULL;
		  char* t5_DRstatus		= NULL;
		  char*	 Dml_DR = NULL;
		  char*	 dml_project = NULL;
		  char*	 t5_ClrPartStatus = NULL;
		  char*	 ClrPartNo = NULL;
		  tag_t *CP_Tsk_parts= NULLTAG;
		  char		*ClrPrtErr = NULL;
		  int flagDMLClrDR=0;
		  
		  char    **ArchrNodeyEntryValue     =  (char **) MEM_alloc(100 * sizeof(char *));
		  int      ArchNodeQryC = 0;
		  tag_t   *ArchNodeCtrObj      = NULLTAG;
		  char *strinfo1 =NULL;
		  char *strinfo2 =NULL;
		  char *strinfo3 =NULL;
		  char *strinfo4 =NULL;
		  char *strinfo5 =NULL;
		  char *strinfo6 =NULL;
		  
		  if (tc_strcmp(ClrPrtErr,"NULL") !=0) MEM_free(ClrPrtErr);
		  ClrPrtErr=(char *)MEM_alloc(3000);
		  
		  CALLAPI(POM_get_user(&username,&user_tag));
		  printf("\n Starting for taskbreskdownnn :%s....\n",username);fflush(stdout);	
		  
		  CALLAPI(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
		  qry_values11[0] = "ClrSvrOnX4" ;
		  qry_values11[1] = "ClrSvrOnX4" ;
		  CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
		  printf("\n Control Object count for ClrSvrOnX4---------->%d\n",resultCount11);fflush(stdout);
		  
		  tag_t  objTypTag		= NULLTAG;
		  char   *ObjTyp=NULL;
		  char *Dml_taskNo = NULL;
		  char *DMLNo = NULL;
		  int	  PartCnt		= 0;
		  tag_t*	PartTags	= NULLTAG;
		  int		iLength	=	0;
		  int icount_aplModCheck=0;
		  char	**SetChildRelAPLModErr = NULL;
		  SetChildRelAPLModErr = (char**)MEM_alloc( 1 * sizeof *SetChildRelAPLModErr);
		  char	*tempErr	=	0;
		  int icount_ebommbom_bom=0;
		  int status;
		  
		if(resultCount11>0)
		{		
			CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n erc_dml_assignnnnnnnnnn \n"); fflush(stdout);

			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
			printf("\n Target Attachment:%d\n",noAttachment);fflush(stdout);

			if(noAttachment >0)
			{
				for(i=0;i<noAttachment;i++)
				{
					printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);
					if(TCTYPE_ask_object_type(attachments[i],&objTypTag));
					if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
					printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);

					if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
					{
						if(AOM_ask_value_string(attachments[i],"item_id",&Dml_taskNo)!=ITK_ok)PrintErrorStack();
						printf("\n Dml_taskNo----------->%s\n",Dml_taskNo); fflush(stdout);

						DMLNo = subString(Dml_taskNo,0,10);
						printf("\n Dml_taskNo----------->%s\n",DMLNo); fflush(stdout);
						
						if(ITEM_find_item(DMLNo, &DMLTag)!=ITK_ok)PrintErrorStack();
						CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&DMLItem_id));
						printf("\n DML DMLItem_id is : %s\n",DMLItem_id);fflush(stdout);				
						
						if (DMLTag != NULLTAG)
						{
							if(ITEM_ask_latest_rev(DMLTag, &DMLRevTag1)!=ITK_ok)PrintErrorStack();
							CALLAPI(AOM_ask_value_string(DMLRevTag1,"t5_rlstype",&dml_rlstype));
							printf("\n dml_rlstype is : %s\n",dml_rlstype);fflush(stdout);

							CALLAPI(AOM_ask_value_string(DMLRevTag1,"t5_cDRstatus",&Dml_DR));
							printf("\n Dml_DR  is : %s\n",Dml_DR );fflush(stdout);

							CALLAPI(AOM_ask_value_string(DMLRevTag1,"t5_cprojectcode",&dml_project));
							printf("\n dml_project is : %s\n",dml_project);fflush(stdout);

								// to use altros way control and read userinfo1 

							int n_entries11 =2;
							tag_t	Cntl_obj_Qtag11	=	NULLTAG;
							char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
							char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
							int resultCount11=0;
							tag_t *qry_cntrlobj11= NULLTAG;
							char *userinfo2=NULL;

							if(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));

								qry_values11[0] = "Project" ;
								qry_values11[1] = "AltrozWay" ;

						QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11);
						AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&userinfo2);
			
						printf("\n **************** User Info 1 ===> %s **************** \n",userinfo2);fflush(stdout);

							if((tc_strcmp(dml_rlstype,"CP")==0) && (tc_strstr(dml_project,userinfo2)!= NULL))
							{
								CALLAPI(AOM_ask_value_tags(attachments[i],"CMHasSolutionItem",&PartCnt,&PartTags));
								printf("\n\n\t\t ERC DML Cre:Now PartCnt:%d",PartCnt);fflush(stdout);

								CALLAPI(Check_ERCModPresent(attachments[i],PartCnt,PartTags,&SetChildRelAPLModErr,&icount_aplModCheck));
								printf("\n Check_ERCModPresent icount_aplModCheck : %d",icount_aplModCheck);fflush(stdout);
								
								if(icount_aplModCheck>0)
								{
									iLength	=	0;
									if (!tempErr) MEM_free(tempErr);
									i=0;
									for (i=0; i < icount_aplModCheck; i++)
									{
										tempErr	=	SetChildRelAPLModErr[i];
										iLength	=	iLength	+	tc_strlen(tempErr);
									}
									printf("Check_APLModPresent EBOM-MBOM iLength : %d",iLength);fflush(stdout);
									if (!tempErr) MEM_free(tempErr);
									tempErr	=	(char *)MEM_alloc(iLength+20);
									i=0;
									printf("\nBefore For loop");fflush(stdout);
									for (i=0; i < icount_aplModCheck; i++)
									{
										if(i==0)
											tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
										else
											tc_strcat(tempErr,SetChildRelAPLModErr[i]);
									}
									printf("\n Check_APLModPresent EBOM-MBOM Printing Errors...!!!");fflush(stdout);
									printf("%s",tempErr);fflush(stdout);
									EMH_clear_errors();
									status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
									decision = EPM_nogo;
									return ITK_errStore;								
								}
								
								CALLAPI(Check_ERCModuleDuplicate(attachments[i],PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom));
								printf("\n Check_ERCModuleDuplicate icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);
								
								CALLAPI(Check_ERCModuleQTY(attachments[i],PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom));
								printf("\n Check_ERCModuleQTY icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);

								CALLAPI(Check_ERCModuleColourSuffix(attachments[i],PartCnt,PartTags,&SetChildRelAPLModErr,&icount_ebommbom_bom));
								printf("\n Check_ERCModuleColourSuffix icount_ebommbom : %d",icount_ebommbom_bom);fflush(stdout);

								if(icount_ebommbom_bom>0)
								{
									iLength	=	0;
									if (!tempErr) MEM_free(tempErr);
									i=0;
									for (i=0; i < icount_ebommbom_bom; i++)
									{
										tempErr	=	SetChildRelAPLModErr[i];
										iLength	=	iLength	+	tc_strlen(tempErr);
									}
									printf("EBOM-MBOM iLength : %d",iLength);fflush(stdout);
									if (!tempErr) MEM_free(tempErr);
									tempErr	=	(char *)MEM_alloc(iLength+20);
									i=0;
									printf("\nBefore For loop");fflush(stdout);
									for (i=0; i < icount_ebommbom_bom; i++)
									{
										if(i==0)
											tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
										else
											tc_strcat(tempErr,SetChildRelAPLModErr[i]);
									}
									printf("\n EBOM-MBOM Printing Errors...!!!");fflush(stdout);
									printf("%s",tempErr);fflush(stdout);
									EMH_clear_errors();
									status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
									decision = EPM_nogo;
									return ITK_errStore;							
								}

								int icount_ebommSupp=0;
								Check_ERCModSuppress1(attachments[i],PartCnt,"APL",PartTags,&SetChildRelAPLModErr,&icount_ebommSupp);
								printf("\n Check_ERCModSuppress icount_ebommSupp : %d",icount_ebommSupp);fflush(stdout);
								if(icount_ebommSupp>0)
								{
									iLength	=	0;
									if (!tempErr) MEM_free(tempErr);
									i=0;
									for (i=0; i < icount_ebommSupp; i++)
									{
										tempErr	=	SetChildRelAPLModErr[i];
										iLength	=	iLength	+	tc_strlen(tempErr);
									}
									printf("EBOM-MBOM iLength : %d",iLength);fflush(stdout);
									if (!tempErr) MEM_free(tempErr);
									tempErr	=	(char *)MEM_alloc(iLength+20);
									i=0;
									printf("\nBefore For loop");fflush(stdout);
									for (i=0; i < icount_ebommSupp; i++)
									{
										if(i==0)
											tc_strcpy(tempErr,SetChildRelAPLModErr[i]);
										else
											tc_strcat(tempErr,SetChildRelAPLModErr[i]);
									}
									printf("\n EBOM-MBOM Printing Errors...!!!");fflush(stdout);
									printf("%s",tempErr);fflush(stdout);
									EMH_clear_errors();
									status=EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,tempErr);
									decision = EPM_nogo;
									return ITK_errStore;							
								}
							}						


							if(tc_strcmp(dml_rlstype,"CP")==0)
							{	
								printf("\n ****** Inside CP DML Validation ****** \n");fflush(stdout);
								if(strcmp(Dml_DR,"")!=0)
								{								
									CALLAPI(QRY_find2("ControlObjQry", &CP_gMCtrObjQryTag));
									CPgMQryEntryValue[0] = "CPGM_DML";
									CPgMQryEntryValue[1] = "CP";
									CALLAPI(QRY_execute(CP_gMCtrObjQryTag, GMenry_Count, CPGMQryEntry, CPgMQryEntryValue, &CPGMQryC, &CPGMCtrObj));
									printf("\n CPGMQryC is : %d\n",CPGMQryC);fflush(stdout);	
									
									if(CPGMQryC>0)
									{
										CALLAPI(POM_class_of_instance(DMLRevTag1,&class_id2));
										CALLAPI(POM_name_of_class(class_id2,&class_name2));
										printf("\n\n\t\t class_name2 found1 :%s",class_name2);fflush(stdout);

										if(tc_strcmp(class_name2,"ChangeRequestRevision")==0)
										{
											CALLAPI(GRM_find_relation_type("T5_DMLTaskRelation", &Gmrelation_type));
											if (Gmrelation_type!=NULLTAG)
											{
												CALLAPI(GRM_list_secondary_objects_only(DMLRevTag1,Gmrelation_type,&n_attchs1,&secondary_GMobjects));
												printf("\n\n\t\t No of DI : %d",n_attchs1);fflush(stdout);

												if(n_attchs1>0)
												{
													for (l=0;l<n_attchs1 ;l++ )
													{					
														CALLAPI(AOM_ask_value_string(secondary_GMobjects[l],"item_id",&Object_id));
														printf("\n\n\t\t Object_id is :%s",Object_id);fflush(stdout);

														if(tc_strstr(Object_id,"_00")!=NULL)
														{	
															CALLAPI(AOM_ask_value_tags(secondary_GMobjects[l],"CMHasSolutionItem",&CP_Tsk_part_Count,&CP_Tsk_parts));
															printf("\n\n\t\t CP_Tsk_part_Count has : %d",CP_Tsk_part_Count);fflush(stdout);

															if(CP_Tsk_part_Count>0)
															{
																for (k=0;k<CP_Tsk_part_Count ;k++ )
																{
																	CALLAPI(AOM_ask_value_string(CP_Tsk_parts[k],"object_string",&ClrPartNo));
																	printf("\n\t Color Part is :%s",ClrPartNo);fflush(stdout);

																	ITKCALL(AOM_ask_value_string(CP_Tsk_parts[k],"t5_PartStatus",&t5_ClrPartStatus));
																	printf("\n t5_ClrPartStatus------>%s\n",t5_ClrPartStatus);fflush(stdout);

																	if (tc_strcmp(Dml_DR,t5_ClrPartStatus)!=0)
																	{
																		flagDMLClrDR=1;
																		tc_strcpy(ClrPrtErr,"");
																		tc_strcat(ClrPrtErr,"DR STATUS of DML [");
																		tc_strcat(ClrPrtErr,Dml_DR);
																		tc_strcat(ClrPrtErr,"] IS NOT MATCH WITH COLOR PART [");
																		tc_strcat(ClrPrtErr,ClrPartNo);
																		tc_strcat(ClrPrtErr,"] DR STATUS [");
																		tc_strcat(ClrPrtErr,t5_ClrPartStatus);
																		tc_strcat(ClrPrtErr,"]");
																		printf("\n ClrPrtErr: %s\n",ClrPrtErr);fflush(stdout);

																		printf("\n DML DR Status:[%s] & Color Part:[%s] Having DR Status:[%s]\n",Dml_DR,ClrPartNo,t5_ClrPartStatus);fflush(stdout);
																		EMH_clear_errors();
																		EMH_store_error_s1(EMH_severity_error,ITK_Prjerr,ClrPrtErr);																	
																		decision = EPM_nogo;
																		break;														
																	}else
																	printf("\n NO ISSUE WITH COLOR PARTS DR STATUS------>%s\n",ClrPartNo);fflush(stdout);
																}
															}
														}
													}
												}
											}
										}						
									}
								}
								
								//DUPLICATE Checked on X4 Platfrom using SVR/REVISON RULE & CLOSURE RULE
								printf("\n\n\n flagDMLClrDR-------->  : %d\n\n",flagDMLClrDR);fflush(stdout);
								if(flagDMLClrDR==0)
								{								
									printf("\n to find impacted items\n");fflush(stdout);
									CALLAPI(GRM_find_relation_type("CMReferences",&relation_type));
									if(relation_type != NULLTAG)
									{
									  CALLAPI(GRM_list_secondary_objects_only(DMLRevTag1,relation_type,&cnt,&attachments1));
									  printf("\n Checkin- impacted items:%d\n",cnt);fflush(stdout);
										
									  for(i=0;i<cnt;i++)
									  {
										  printf("\n to find impacted items\n");fflush(stdout);
										  rev1 = attachments1[i]; 

										  if(AOM_ask_value_string(rev1,"object_type",&objecttype));
										  printf("\n objecttype is---------->%s\n",objecttype ); fflush(stdout);

										  if(AOM_ask_value_string(rev1,"object_name",&objectname));
										  printf("\n objectname is---------->%s\n",objectname ); fflush(stdout);

										  Svr_Project1=subString(objectname, 0, 4);
										  printf("\n Svr_Project1 is : %s\n",Svr_Project1); fflush(stdout);
		 
										  if (strcmp(Svr_Project1,"5445")==0 || strcmp(Svr_Project1,"5477")==0)
										  {
											  if (strcmp(objecttype,"VariantRule")==0)
											  {
												if(rev1 != NULLTAG)
												{
													  CALLAPI(ITEM_find_item("X4",&X4ItemTag));
													  printf("\n ITEM_find_item------------>\n" ); fflush(stdout);
													  
													  CALLAPI(ITEM_ask_latest_rev(X4ItemTag,&X4ItemRevTag));
													  printf("\n ITEM_ask_latest_rev---------->\n" ); fflush(stdout);
												
													  if(TCTYPE_ask_object_type(X4ItemRevTag,&objTypeTag));
													  if(TCTYPE_ask_name2(objTypeTag,&typeName));
													  printf("\n\nT5_PlatformRevision is----->%s\n",typeName); fflush(stdout);			
														 
													  if (strcmp(typeName,"T5_PlatformRevision")==0)
													  {
															printf( "\n INside platform\n"); fflush(stdout);
															if ( X4ItemRevTag !=NULLTAG )
															{
																CALLAPI ( PS_find_view_type( "view", &view_type ));
																printf("\n PS_find_view_type is found......\n" ); fflush(stdout);

																if ( view_type != NULLTAG )
																{
																	CALLAPI ( ITEM_ask_item_of_rev( X4ItemRevTag, &item ));
																	CALLAPI ( ITEM_list_bom_views( item, &n_bom_views, &bom_views ));

																	bom_view = bom_views[0];
																}
																else
																printf("\nView not found check.......\n"); fflush(stdout);
															}

															if ( bom_view != NULLTAG )
															{
																printf(" before BOM_create_window..\n");	fflush(stdout);	
																CALLAPI(BOM_create_window( &bom_window ));
																CALLAPI(CFM_find("Color ERC Review and above", &rule ));
																CALLAPI(BOM_set_window_config_rule(bom_window, rule ));	
																CALLAPI(PIE_find_closure_rules2("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound, &closurerule));
																if (rulefound > 0)
																{
																	close_tag = closurerule[0];
																	printf ("closure rule found \n");fflush(stdout);
																}
																CALLAPI(BOM_window_set_closure_rule(bom_window,close_tag, 0, rulename,rulevalue));
																CALLAPI(BOM_set_window_pack_all(bom_window, TRUE));
																CALLAPI(BOM_set_window_top_line(bom_window , NULLTAG, X4ItemRevTag, NULLTAG, &top_line ));
																CALLAPI(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
																printf("\n before hiide LLlast Before setting option n_lines1 : %d \n", n_lines1);

																if(bom_window != NULLTAG)
																{
																	CALLAPI(BOM_window_hide_unconfigured(bom_window));
																	CALLAPI(BOM_window_show_variants(bom_window));
																	CALLAPI(BOM_create_window_variant_config(bom_window,1,&bom_variant_config));
																	CALLAPI(BOM_variant_config_apply(bom_variant_config));
																	CALLAPI(BOM_window_apply_variant_configuration(bom_window,1,&rev1));
																	CALLAPI(BOM_window_hide_variants(bom_window));
																	CALLAPI(BOM_window_ask_is_modified(bom_window,&modB));
																	if(modB) { printf( "\n modified bom window:..\n"); } else {
																	printf( "\n not modfiifed ..\n"); }
																	if(BOM_line_ask_child_lines(top_line, &n_lines1, &lines));
																	printf("\n 2nd time LLlast Before setting option n_lines1: %d \n", n_lines1); fflush(stdout);
																}					
																// Added by Gajanan for Module is not present under ArchiTechture Node 	 
																printf("\n Start control Object for HornbillArchNode ----->\n"); fflush(stdout);
																ArchrNodeyEntryValue[0] = "HornbillArchNode";
																ArchrNodeyEntryValue[1] = "HornbillArchNode";
																CALLAPI(QRY_execute(CP_gMCtrObjQryTag, GMenry_Count, CPGMQryEntry, ArchrNodeyEntryValue, &ArchNodeQryC, &ArchNodeCtrObj));
																printf("\n Control Object HornbillArchNode count is  ----->%d\n",ArchNodeQryC); fflush(stdout);
																 if(ArchNodeQryC>0)	
																{
																  AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo1",&strinfo1);
																  AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo2",&strinfo2);
																  AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo3",&strinfo3);
																  AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo4",&strinfo4);
																  AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo5",&strinfo5);
																  AOM_ask_value_string(ArchNodeCtrObj[0],"t5_Userinfo6",&strinfo6);
																  printf("\n in control object Module Class Name is----->%s,%s \n",strinfo1,strinfo2,strinfo5); fflush(stdout);
																}
																					
																if (n_lines1 >0)
																{
																 if (tc_strstr(strinfo5,dml_project) != NULL)       // GR For Project Code 5445,5477
																	{
																		tc_strcpy(MulArchiNode,"");
																	  for (p1=0;p1<n_lines1 ;p1++ )
																	   {
																		  Arcbl_Item_id		= NULL;	   
																		  tag_t ArchTag		= NULLTAG;   	
																		  tag_t ArchTagRev	= NULLTAG;
																		  char *sModuleAdrr = NULL;  

																		//  CALLAPI(BOM_line_look_up_attribute((char *) bomAttr_lineItemRevTag , &iChildItemTag)); //TCUA14.3
																		 // CALLAPI(BOM_line_ask_attribute_tag(lines[p1], iChildItemTag, &t_ChildItemRev));
																	
																		  CALLAPI(AOM_ask_value_string(lines[p1], "bl_item_item_id", &Arcbl_Item_id));
																		  printf("\n\n Arcbl_Item_id is---------------->%s\n",Arcbl_Item_id); fflush(stdout);
																			
																		  CALLAPI(ITEM_find_item(Arcbl_Item_id,&ArchTag));                               
																		  CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));                             
																		  CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));
																		  printf("\n Module t5_ArchModuleAddress is----->%s\n",sModuleAdrr); fflush(stdout);	

																		 if(TCTYPE_ask_object_type(ArchTagRev,&objTypeTag1));
																		 if(TCTYPE_ask_name2(objTypeTag1,&typeName1));
																		 printf("\n Module Class Name is----->%s\n",typeName1); fflush(stdout);	
																		
																		if(tc_strcmp(typeName1,"T5_ArchModuleRevision")==0)
																		{
																		  if(ArchNodeQryC>0)	
																		   {
																			
																			if((tc_strstr(strinfo1,sModuleAdrr) != NULL) || (tc_strstr(strinfo2,sModuleAdrr) != NULL) || (tc_strstr(strinfo3,sModuleAdrr) != NULL) || (tc_strstr(strinfo4,sModuleAdrr) != NULL))
																			{
																			   CALLAPI(BOM_line_ask_child_lines(lines[p1], &no_bom_lines, &child_bom_lines));
																			   printf("\n BOM_line_ask_child_lines for Module is: %d\n\n", no_bom_lines); fflush(stdout);										
																			   tc_strcpy(MulModule,"");
																			   tc_strcat(MulModule,Arcbl_Item_id);
																			   tc_strcat(MulModule,"==>");
																			   
																			  if (no_bom_lines>1)
																			  {
																				 for (p34=0;p34<no_bom_lines ;p34++ )
																				 {
																					if(Childobject33) Childobject33=NULLTAG;
																					Childobject33=child_bom_lines[p34];
																					
																					CALLAPI(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
																					printf("\n child_item_id15 is----->%s\n",child_item_id15); fflush(stdout);
																					
																					tc_strcat(MulModule,"[");
																					tc_strcat(MulModule,child_item_id15);
																					tc_strcat(MulModule,"]");
																					tc_strcat(MulModule,",");
																					errorflag=errorflag+1;
																					printf("\n.....mulmodule is after..%s\n",MulModule);fflush(stdout);
																				  }
																			   
																					printf("\n errorflag----->%d\n",errorflag); fflush(stdout);
																				  if (errorflag>1)
																				   {	
																						printf("\n MORE THAN ONE MODULES IS PRESENT UNDER ARCHITECHTURE NODE...........>\n"); fflush(stdout); //EMH_severity_error
																						EMH_clear_errors();
																						EMH_store_error_s3(EMH_severity_warning,ITK_Prjerr,"Duplicate module is getting created/solved under the same architecture node.",MulModule,"\n Please contact colour support group in BoM Process team for further help and resolution of the issue.");
																						decision = EPM_nogo;
																						break;
																					}
																					else
																					{
																						printf("\n THEIR ONE MODULES IS PRESENT UNDER ARCHITECHTURE NODE...........>\n"); fflush(stdout);
																						decision = EPM_go;
																					}
																			  }
																			  else if (no_bom_lines==0)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
																				{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
																					 printf("\n MODULES IS NOT PRESENT UNDER ARCHITECHTURE NODE...........>%s\n",Arcbl_Item_id); fflush(stdout); //EMH_severity_error                                                                                                                                                                                                                                                                                                                                                                                                                                                 
																					 tc_strcat(MulArchiNode,Arcbl_Item_id);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
																					 tc_strcat(MulArchiNode,",");                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
																					 ErrZeroflag=ErrZeroflag+1;                                                                                                                                                                                                                                                                                                                                                                                                                                                    
																				 }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    

																			else 
																			{
																				printf("\n Module count is not more than one...........>%d\n",no_bom_lines); fflush(stdout);
																			}
																		  }
																		  else
																			 {
																			   CALLAPI(BOM_line_ask_child_lines(lines[p1], &no_bom_lines, &child_bom_lines));
																			   printf("\n BOM_line_ask_child_lines for Module is: %d\n\n", no_bom_lines); fflush(stdout);										
																			   tc_strcpy(MulModule,"");
																			   tc_strcat(MulModule,Arcbl_Item_id);
																			   tc_strcat(MulModule,"==>");
																				
																				if (no_bom_lines>1)
																				  {
																					 for (p34=0;p34<no_bom_lines ;p34++ )
																					 {
																						if(Childobject33) Childobject33=NULLTAG;
																						Childobject33=child_bom_lines[p34];
																						
																						CALLAPI(AOM_ask_value_string(Childobject33, "bl_item_item_id", &child_item_id15 ));
																						printf("\n child_item_id15 is----->%s\n",child_item_id15); fflush(stdout);
																						
																						tc_strcat(MulModule,"[");
																						tc_strcat(MulModule,child_item_id15);
																						tc_strcat(MulModule,"]");
																						tc_strcat(MulModule,",");
																						errorflag=errorflag+1;
																						printf("\n.....mulmodule is after..%s\n",MulModule);fflush(stdout);
																					  }
																				   
																						printf("\n errorflag----->%d\n",errorflag); fflush(stdout);
																					  if (errorflag>1)
																					   {	
																							printf("\n MORE THAN ONE MODULES IS PRESENT UNDER ARCHITECHTURE NODE...........>\n"); fflush(stdout); //EMH_severity_error
																							EMH_clear_errors();
																							EMH_store_error_s3(EMH_severity_warning,ITK_Prjerr,"Duplicate module is getting created/solved under the same architecture node.",MulModule,"\n Please contact colour support group in BoM Process team for further help and resolution of the issue.");
																							decision = EPM_nogo;
																							break;
																						}
																						else
																						{
																							printf("\n THEIR ONE MODULES IS PRESENT UNDER ARCHITECHTURE NODE...........>\n"); fflush(stdout);
																							decision = EPM_go;
																						}
																				  }																	  
																			  }

																		 }
																		 else
																			{
																			  printf("\n HornbillArchNode CONTROL OBJECT COUNT IS ...........>%d\n",ArchNodeQryC); fflush(stdout);
																			}
																		}
																	}
																	if (ErrZeroflag > 0 && tc_strstr(strinfo6,Dml_DR) != NULL)
																	{
																	   printf("\n MODULES IS NOT PRESENT UNDER ARCHITECHTURE NODE.%s\n Please contact support group in BoM Process team for further help and resolution of the issue",MulArchiNode); fflush(stdout); //EMH_severity_error
																	   EMH_clear_errors();
																	   EMH_store_error_s3(EMH_severity_warning,ITK_Prjerr,"MODULES IS NOT PRESENT UNDER ARCHITECHTURE NODE.",MulArchiNode,"\n Please contact colour support group in BoM Process team for further help and resolution of the issue.");
																	   decision = EPM_nogo;
																	   break;
																	}
																 }
																 else
																	{
																	  printf("\n PROJECT CODE UNABLE TO MATCH, PLEASE CHECK AND TRY AGAIN...........>\n"); fflush(stdout);
																	  decision = EPM_go;
																	}
																}					 						 
																CALLAPI(BOM_save_window(bom_window));
																CALLAPI(BOM_close_window(bom_window));
															}
														}
												  }
											}
										}else
										printf("\n Project code of Color SVR is other than 5445--------------->\n"); fflush(stdout);
									  }
									}
								}
							}
						}
					 }
				 }
			 }
			}		
			return decision;
		}

		int tm_DMLPostColRlzProcess(char* dml_no)
		{
			int tskcnt,i=0;
			int partcnt,k=0;
			int NCAssyChildFlag=0;
			tag_t *Dml_tasks=NULLTAG;
			tag_t *PartsTag=NULLTAG;
			tag_t dml_tag = NULLTAG;
			tag_t DMLRevTag = NULLTAG;
			tag_t RevTypTag = NULLTAG;
			tag_t NonClrPartTag = NULLTAG;
			char *RevTyp = NULL;
			char *dmlNumber = NULL;
			char *DMLRevId = NULL;
			char *DML_rlstype = NULL;
			char *DMLProj = NULL;

			char command[512];

			//control logic:
			tag_t CLqryTag = NULLTAG;
			int CL_n_entry = 1;
			int CL_rsltCount = 0;
			char *CL_qry_entry[1] = {"SYSCD"};
			tag_t *CLCntrlObjectTag = NULLTAG;
			char **CL_qry_values2 =  (char **) MEM_alloc(10 * sizeof(char *));
			char *CLinfo3 = NULL;
			char *CLinfo1 = NULL;
			char *CLinfo4 = NULL;
			char *RelTypeCat			= NULL;

			if(ITEM_find_item(dml_no, &dml_tag)!=ITK_ok)PrintErrorStack();
			if (dml_tag != NULLTAG)
			{
				//Control object logic:
					if(QRY_find2("ControlObjects", &CLqryTag));
					if (CLqryTag)
					{
						printf("\n CLCHECK:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n CLCHECK:Not Found Query ControlObjects \n");fflush(stdout);
					}
					CL_qry_values2[0] = "CLCHECK";
					if(QRY_execute(CLqryTag, CL_n_entry, CL_qry_entry, CL_qry_values2, &CL_rsltCount, &CLCntrlObjectTag));
					printf(" \n CLCHECK:CL_rsltCount:%d:", CL_rsltCount); fflush(stdout);
					if (CL_rsltCount > 0)
					{
						if (AOM_ask_value_string(CLCntrlObjectTag[0],"t5_Userinfo1",&CLinfo1)!=ITK_ok)   PrintErrorStack();
						printf("\n t5_Userinfo1: [%s]\n", CLinfo1);fflush(stdout);

						if(ITEM_ask_latest_rev(dml_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();
						if(TCTYPE_ask_object_type(DMLRevTag, &RevTypTag));
						if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
						printf("\n RevTyp type: [%s] ", RevTyp);fflush(stdout);

						if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DML_rlstype)!=ITK_ok)PrintErrorStack();
						printf(" and DML_rlstype: [%s]", DML_rlstype);fflush(stdout);

						RelTypeCat = MEM_alloc(100);
						tc_strcpy(RelTypeCat,"");
						tc_strcpy(RelTypeCat,",");
						tc_strcat(RelTypeCat,DML_rlstype);
						tc_strcat(RelTypeCat,",");
						printf("\n tm_DMLPostColRlzProcess RelTypeCat.:%s \n",RelTypeCat);fflush(stdout);

					
						

						if(tc_strstr(CLinfo1,RelTypeCat)!=NULL)//  8/4/2026 Modified by Nilesh
						{
							
							
							//if(CL_rsltCount > 0) 8/4/2026 commented by nilesh 
							//{
								if (AOM_ask_value_string(CLCntrlObjectTag[0],"t5_Userinfo3",&CLinfo3)!=ITK_ok)   PrintErrorStack();
								if (AOM_ask_value_string(CLCntrlObjectTag[0],"t5_Userinfo4",&CLinfo4)!=ITK_ok)   PrintErrorStack();

								printf("\n CL-info3: [%s]  CLinfo4: [%s] \n", CLinfo3, CLinfo4);fflush(stdout);
								if(tc_strstr(CLinfo3,"CLCHECKOFF")==NULL)
								{
									if(tc_strstr(CLinfo3,"CLCHECKUAPROD")!=NULL)
									{
										printf("\n UAPROD:Task name: %s ", dml_no);fflush(stdout);
										sprintf(command,"%s %s ",CLinfo4,dml_no);///user/uaprod/TC_ROOT12/bin/tml_tools/CLtaskDML.sh
										TC_write_syslog("Command = %s\n",command);
										system(command);
									}
									else if (tc_strstr(CLinfo3,"CLCHECKCVPROD")!=NULL)
									{
										printf("\n CVPROD:Task name: %s ", dml_no);fflush(stdout);
										sprintf(command,"%s %s ",CLinfo4,dml_no);///user/uaprod/TC_ROOT12/bin/tml_tools/CLtaskDML.sh
										TC_write_syslog("Command = %s\n",command);
										system(command);
									}
									else if(tc_strstr(CLinfo3,"CLCHECKCMITEST")!=NULL)
									{
										printf("\n CMITEST: Task name: %s ", dml_no);fflush(stdout);
										sprintf(command,"%s %s ",CLinfo4,dml_no);///user/uaprod/TC_ROOT12/bin/tml_tools/CLtaskDML.sh
										TC_write_syslog("Command = %s\n",command);
										system(command);
									}
									else
									{
										printf("\n CL-TASK:Other client.. \n");fflush(stdout);
									}
								}
							//}
						/*
							char* inputfile =(char *) MEM_alloc(100);
							tc_strcpy(inputfile,"/tmp/");
							tc_strcat(inputfile,dml_no);
							tc_strcat(inputfile,"_CL.log");

							char* inputfile2 =(char *) MEM_alloc(100);
							tc_strcpy(inputfile2,"/tmp/");
							tc_strcat(inputfile2,dml_no);
							tc_strcat(inputfile2,"_CL_ErrorColPart.log");

							fpCLLog=fopen(inputfile,"a");
							fpCLErrLog=fopen(inputfile2,"a");

							fprintf(fpCLLog,"\n================START===DML_rlstype: [%s] ================================================================================================\n",DML_rlstype); fflush(fpCLLog);

							// START---define Query/Control objects/Relation type
							if(GRM_find_relation_type("CMHasSolutionItem", &tsk_HSI_rel_type)!=ITK_ok)PrintErrorStack();
							if(GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind)!=ITK_ok)PrintErrorStack();
							if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel)!=ITK_ok)PrintErrorStack();
							if(BOM_line_look_up_attribute("bl_quantity", &QuantityAttrId)!=ITK_ok)PrintErrorStack();
							if(QRY_find2("ClrPart", &ClrPartQryTag));
							if (ClrPartQryTag) {
								printf("\n CM=Found Query ClrPartQryTag \n"); fflush(stdout);
								fprintf(fpCLLog,"\n CM=Found Query ClrPartQryTag \n"); fflush(fpCLLog);
							}else {
								printf("\n\t CM=Not Found Query ClrPartQryTag, hence skipping ??? \n"); fflush(stdout);
								fprintf(fpCLLog,"\n\t CM=Not Found Query ClrPartQryTag, hence skipping ??? \n"); fflush(fpCLLog);
								return ifail;
							}

							if(QRY_find2("ControlObjects", &qryCTOTag));
							if (qryCTOTag)
							{
								printf("\n qryCTOTag:Found Query ControlObjects \n");fflush(stdout);
								fprintf(fpCLLog,"\n qryCTOTag:Found Query ControlObjects \n");fflush(fpCLLog);
							}else
							{
								printf("\n qryCTOTag:Not Found Query ControlObjects \n");fflush(stdout);
								fprintf(fpCLLog,"\n qryCTOTag:Not Found Query ControlObjects \n");fflush(fpCLLog);
							}

							if(QRY_find2("ClrScheme", &SchmqueryTag));
							if (SchmqueryTag)
							{
								printf("\n CM=Found Query SchmqueryTag"); fflush(stdout);
								fprintf(fpCLLog,"\n CM=Found Query SchmqueryTag"); fflush(fpCLLog);
							}else
							{
								printf("\n CM=Not Found Query SchmqueryTag \n"); fflush(stdout);
								fprintf(fpCLLog,"\n CM=Not Found Query SchmqueryTag \n"); fflush(fpCLLog);
								if(POM_logout(false)!=ITK_ok)PrintErrorStack();
								return ifail;
							}

							if(QRY_find2("General...", &GeneralQryTag));
							if (GeneralQryTag)
							{
								printf("\nGeneral... Found Query");	fflush(stdout);
								fprintf(fpCLLog,"\nGeneral... Found Query");	fflush(fpCLLog);
							}else
							{
								printf("\n General...:Not Found Query \n");fflush(stdout);
								fprintf(fpCLLog,"\n General...:Not Found Query \n");fflush(fpCLLog);
								if(POM_logout(false)!=ITK_ok)PrintErrorStack();
								return ifail;
							}
							// END---define Query/Control objects/Relation type

							//DML DETAILS.................
							if(AOM_ask_value_string(DMLRevTag,"item_id",&dmlNumber)!=ITK_ok)PrintErrorStack();
							printf("\n DML Number: [%s]", dmlNumber);fflush(stdout);
							fprintf(fpCLLog,"\n DML Number: [%s]", dmlNumber);fflush(fpCLLog);

							if(AOM_ask_value_string(DMLRevTag,"item_revision_id",&DMLRevId)!=ITK_ok)PrintErrorStack();
							printf("  DMLRevId: [%s]", DMLRevId);fflush(stdout);
							fprintf(fpCLLog,"  DMLRevId: [%s]", DMLRevId);fflush(fpCLLog);

							if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DML_rlstype)!=ITK_ok)PrintErrorStack();
							printf("  DML_rlstype: [%s]", DML_rlstype);fflush(stdout);
							fprintf(fpCLLog,"  DML_rlstype: [%s]", DML_rlstype);fflush(fpCLLog);

							if(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
							printf("  DMLProj: [%s]", DMLProj);fflush(stdout);
							fprintf(fpCLLog,"  DMLProj: [%s]", DMLProj);fflush(fpCLLog);

							if(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
							printf("\n No. of tskcnt: %d ",tskcnt);fflush(stdout);
							fprintf(fpCLLog,"\n No. of tskcnt: %d ",tskcnt);fflush(fpCLLog);

							if (tskcnt>0)
							{
								/////////////////////////////Color Scheme is Queryed/////////////////////////////////////////
								tag_t *ColSchme_tags = NULLTAG;
								tag_t *CmpCodeOfClrScheme = NULLTAG;
								tag_t *ClrPrtTags = NULLTAG;
								tag_t *Col_Rlz_St_list = NULLTAG;
								tag_t *sec_objects = NULLTAG;
								tag_t *CtrlObjTag = NULLTAG;
								tag_t *CntrolObjectTag = NULLTAG;
								tag_t *ProjSetObs = NULLTAG;

								tag_t ColorSchemetag = NULLTAG;
								tag_t ColSchmTypeTag=NULLTAG;
								tag_t ColSchmRevTag = NULLTAG;
								tag_t CmpCodeObjTag=NULLTAG;
								tag_t ColItemTag = NULLTAG;
								tag_t ColorRevTag = NULLTAG;
								tag_t NewColorRevTag = NULLTAG;
								tag_t ReltnExist = NULLTAG;
								tag_t reltask = NULLTAG;
								tag_t secObjTypeTag	= NULLTAG;
								tag_t PrjCdObj	= NULLTAG;

								int resultColSchm=0;
								int co , rs, RlzRevFlag=0;
								int status_count=0;
								int Cmpcount , g1=0;
								int n_ClrPrt_tags, ColRlzStatusCnt, ss2, ColRlzRevFlag=0;
								int n_attchs , st = 0;
								int resultCountObs = 0;
								int n_entriesObs = 2;
								char type_name2[TCTYPE_name_size_c+1];
								char* tsk_object_type = NULL;
								char* tsk_object_name = NULL;
								char* Part_no = NULL;
								char* sPartColInd = NULL;
								char *Clrscheme = NULL;
								char *CpyClrscheme = NULL;
								char *ClSrlName=NULL;
								char *ClSuffix=NULL;
								char *ColSchmRlzSt = NULL;
								char *SchmCmpCode = NULL;
								char *ColPrtLatestRlzSt=NULL;
								char *NewColPartRevSeq=NULL;
								char *NewColourPart=NULL;
								char *info1S=NULL;
								char *ProjectVehClass=NULL;
								char *NCPrtRevision=NULL;

								char *qry_entries4[1] = {"ID"};
								char *qry_entries[1] = {"ID"};
								char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
								char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));
								char ColSchm_name[TCTYPE_name_size_c+1];

								NewColourPart=(char *) MEM_alloc(50 * sizeof(char ));
								CpyClrscheme=(char *) MEM_alloc(50 * sizeof(char ));

								int n_entryCT = 1;
								int n_entryClrSchm = 2;
								int rsltCnt, rsltCount, ct, PrjPltfmSchmFlag = 0;

								char *qry_entriesObs[2] = {"Name","Type"};
								char **qry_valuesObs = (char **) MEM_alloc(10 * sizeof(char *));
								char *qry_entryCT[1]  = {"SYSCD"};
								char *qry_entrySchm[2]  = {"SYSCD","SUBSYSCD"};
								char **qryCT_values =  (char **) MEM_alloc(10 * sizeof(char *));
								char **qrySchm_values =  (char **) MEM_alloc(10 * sizeof(char *));
								
								///////////////////////////// For loop for DML task and Queryed CMReferences Item /////////////////////////////////////////
								for (i=0;i<tskcnt ;i++ )
								{
									if(AOM_ask_value_string(Dml_tasks[i],"object_type",&tsk_object_type)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(Dml_tasks[i],"object_name",&tsk_object_name)!=ITK_ok)PrintErrorStack();
									printf("\n CL=tsk_object_type: [%s]   tsk_object_name: [%s]",tsk_object_type,tsk_object_name);fflush(stdout);
									fprintf(fpCLLog,"\n CL=tsk_object_type: [%s]   tsk_object_name: [%s]",tsk_object_type,tsk_object_name);fflush(fpCLLog);
									if(tc_strcmp(tsk_object_type,"T5_ChangeTaskRevision")==0)
									{
										if(AOM_ask_value_tags(Dml_tasks[i],"CMHasSolutionItem", &partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
										printf("\n CL=No. of partcnt: %d",partcnt);fflush(stdout);
										fprintf(fpCLLog,"\n CL=No. of partcnt: %d",partcnt);fflush(fpCLLog);
										if (partcnt>0)
										{
											NCAssyChildFlag=0;
											NoColSchemeMatchPrts = (char *) MEM_alloc(10000 * sizeof(char));

											ifail = BOM_create_window (&windowClr);
											CHECK_FAIL;
											//ifail = CFM_find( "Latest Working", &ruleNC );
											ifail = CFM_find( "ERC release and above", &ruleNC );
											CHECK_FAIL;
											ifail = BOM_set_window_config_rule( windowClr, ruleNC );
											CHECK_FAIL;

											tc_strcpy(NewColourPart,"");

											for (k=0; k<partcnt ;k++ )
											{
												NCAssyChildFlag=1;
												NonClrPartTag=PartsTag[k];

												ifail = AOM_ask_value_string(NonClrPartTag,"item_id",&Part_no); CHECK_FAIL;
												printf("\nCL=k: %d----------------Assembly: %s --------------------------------------------------------",k,Part_no);fflush(stdout);
												fprintf(fpCLLog,"\nCL=k: %d----------------Assembly: %s --------------------------------------------------------",k,Part_no);fflush(fpCLLog);

												ifail = AOM_ask_value_string(NonClrPartTag,"item_revision_id",&NCPrtRevision);
												printf("\n Non-Color Part Revision : %s   ",NCPrtRevision); fflush(stdout);
												fprintf(fpCLLog,"\n Non-Color Part Revision : %s  ",NCPrtRevision); fflush(fpCLLog);

												//if(tc_strstr(NCPrtRevision,"NR")==NULL)
												//{
													//check latest ERC Released Non-Colour should be attached to DML
													ifail = AOM_UIF_ask_value(NonClrPartTag, "t5_ColourInd", &sPartColInd); CHECK_FAIL;
													printf("  ColInd: %s",sPartColInd);fflush(stdout);
													fprintf(fpCLLog,"  ColInd: %s",sPartColInd);fflush(fpCLLog);
													if(tc_strcmp(sPartColInd,"Y")==0)
													{
														tm_ProcessColourPartCL(tskcnt,Dml_tasks,Dml_tasks[i],NCAssyChildFlag,NonClrPartTag,NewColourPart,DMLProj);
													}
												//}
												//printf("\n\t CM=NewColourPart: [%s]",NewColourPart);fflush(stdout);
											} //for loop end for partcnt
										} //if end of partcnt
									} //if end of tsk_object_type
								} //for loop end for tskcnt
							} //if end of tskcnt

							fprintf(fpCLLog,"\n\n CL Task-Process is Finished..\n");fflush(fpCLLog);

							if (fpCLLog!=NULL)
							{
								fclose(fpCLLog);
								fpCLLog=NULL;
							}
							if (fpCLErrLog!=NULL)
							{
								fclose(fpCLErrLog);
								fpCLErrLog=NULL;
							}
						*/
						} //if end of RevTyp=ChangeRequestRevision
						else
						{
							printf("\nDML is not of Veh/MR/PR hence skipping from validatn tm_DMLPostColRlzProcess. \n");fflush(stdout);
						}
					}//control object not found
					else
					{
						printf("\nControl Object query not found tm_DMLPostColRlzProcess. \n");fflush(stdout);
					}
			} //if end of dml tag
			else
			{
				printf("\n Else--Input DML does not present...\n");fflush(stdout);
			}

			printf("\n\n CL Task-Process is Finished..\n");fflush(stdout);

			return ITK_ok;
		}
		int tm_DMLPostColSVRRlzProcess(char* dml_no)
		{
			int tskcnt,i=0;
			int partcnt,k=0;
			int NCAssyChildFlag=0;
			tag_t *Dml_tasks=NULLTAG;
			tag_t *PartsTag=NULLTAG;
			tag_t dml_tag = NULLTAG;
			tag_t DMLRevTag = NULLTAG;
			tag_t RevTypTag = NULLTAG;
			tag_t NonClrPartTag = NULLTAG;
			char *RevTyp = NULL;
			char *dmlNumber = NULL;
			char *DMLRevId = NULL;
			char *DML_rlstype = NULL;
			char *DMLProj = NULL;

			char command[512];

			//control logic:
			tag_t CLqryTag = NULLTAG;
			int CL_n_entry = 1;
			int CL_rsltCount = 0;
			char *CL_qry_entry[1] = {"SYSCD"};
			tag_t *CLCntrlObjectTag = NULLTAG;
			char **CL_qry_values2 =  (char **) MEM_alloc(10 * sizeof(char *));
			char *CLinfo3 = NULL;
			char *CLinfo4 = NULL;

			if(ITEM_find_item(dml_no, &dml_tag)!=ITK_ok)PrintErrorStack();
			if (dml_tag != NULLTAG)
			{
				if(ITEM_ask_latest_rev(dml_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();
				if(TCTYPE_ask_object_type(DMLRevTag, &RevTypTag));
				if(TCTYPE_ask_name2(RevTypTag,&RevTyp));

				if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DML_rlstype)!=ITK_ok)PrintErrorStack();
				printf(" and DML_rlstype tm_DMLPostColSVRRlzProcess: [%s]", DML_rlstype);fflush(stdout);

				if(TCTYPE_ask_object_type(DMLRevTag, &RevTypTag));
				if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
				printf("\n RevTyp type tm_DMLPostColSVRRlzProcess: [%s]\n", RevTyp);fflush(stdout);

				if((strcmp(DML_rlstype,"Veh")==0))
				{
					//Control object logic:
					if(QRY_find2("ControlObjects", &CLqryTag));
					if (CLqryTag)
					{
						printf("\n CLCHECK:Found Query ControlObjects tm_DMLPostColSVRRlzProcess \n");fflush(stdout);
					}
					else
					{
						printf("\n CLCHECK:Not Found Query ControlObjects tm_DMLPostColSVRRlzProcess \n");fflush(stdout);
					}

					CL_qry_values2[0] = "CLCHECKSVR";
					if(QRY_execute(CLqryTag, CL_n_entry, CL_qry_entry, CL_qry_values2, &CL_rsltCount, &CLCntrlObjectTag));
					printf(" \n CLCHECKS:CL_rsltCount tm_DMLPostColSVRRlzProcess:%d:", CL_rsltCount); fflush(stdout);
					if(CL_rsltCount > 0)
					{
						if (AOM_ask_value_string(CLCntrlObjectTag[0],"t5_Userinfo3",&CLinfo3)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(CLCntrlObjectTag[0],"t5_Userinfo4",&CLinfo4)!=ITK_ok)   PrintErrorStack();

						printf("\n CL-info3: [%s]  CLinfo4:tm_DMLPostColSVRRlzProcess [%s] \n", CLinfo3, CLinfo4);fflush(stdout);
						if(tc_strstr(CLinfo3,"CLCHECKOFFS")==NULL)
						{
							if(tc_strstr(CLinfo3,"CLCHECKUAPRODSVR")!=NULL)
							{
								printf("\n UAPROD:Task name: tm_DMLPostColSVRRlzProcess%s ", dml_no);fflush(stdout);
								sprintf(command,"%s %s ",CLinfo4,dml_no);///user/uaprod/TC_ROOT12/bin/tml_tools/CLSVRtaskDML.sh
								TC_write_syslog("Command tm_DMLPostColSVRRlzProcess= %s\n",command);
								system(command);
							}
							else if(tc_strstr(CLinfo3,"CLCHECKCMITESTSVR")!=NULL)
							{
								printf("\n CMITEST: Task name tm_DMLPostColSVRRlzProcess: %s ", dml_no);fflush(stdout);
								sprintf(command,"%s %s ",CLinfo4,dml_no);///home/cmitest/TC_ROOT_10/bin/tml_tools/CLSVRtaskDML.sh
								TC_write_syslog("Commandtm_DMLPostColSVRRlzProcess = %s\n",command);
								system(command);
							}
							else
							{
								printf("\n CL-TASK:Other client.tm_DMLPostColSVRRlzProcess. \n");fflush(stdout);
							}
						}
					}
				
				} //if end of RevTyp=ChangeRequestRevision
				if((strcmp(DML_rlstype,"UVF")==0))
				{
					if(QRY_find2("ControlObjects", &CLqryTag));
					if (CLqryTag)
					{
						printf("\n CLCHECK:Found Query ControlObjects tm_DMLPostColSVRRlzProcess \n");fflush(stdout);
					}
					else
					{
						printf("\n CLCHECK:Not Found Query ControlObjects tm_DMLPostColSVRRlzProcess \n");fflush(stdout);
					}

					CL_qry_values2[0] = "CLCHECKUVF";
					if(QRY_execute(CLqryTag, CL_n_entry, CL_qry_entry, CL_qry_values2, &CL_rsltCount, &CLCntrlObjectTag));
					printf(" \n CLCHECKUVF:CL_rsltCount tm_DMLPostColSVRRlzProcess:%d:", CL_rsltCount); fflush(stdout);
					if(CL_rsltCount > 0)
					{
						if (AOM_ask_value_string(CLCntrlObjectTag[0],"t5_Userinfo3",&CLinfo3)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(CLCntrlObjectTag[0],"t5_Userinfo4",&CLinfo4)!=ITK_ok)   PrintErrorStack();

						printf("\n CL-CLCHECKUVF: [%s]  CLinfo4:tm_DMLPostColSVRRlzProcess [%s] \n", CLinfo3, CLinfo4);fflush(stdout);
						if(tc_strstr(CLinfo3,"CLCHECKOFFV")==NULL)
						{
							if(tc_strstr(CLinfo3,"CLCHECKUAPRODUVF")!=NULL)
							{
								printf("\n UAPROD:Task name: tm_DMLPostColSVRRlzProcess UVF%s ", dml_no);fflush(stdout);
								sprintf(command,"%s %s ",CLinfo4,dml_no);///user/uaprod/TC_ROOT12/bin/tml_tools/CLUVFtaskDML.sh
								TC_write_syslog("Command tm_DMLPostColSVRRlzProcessUVF= %s\n",command);
								system(command);
							}
							else if(tc_strstr(CLinfo3,"CLCHECKCMITESTUVF")!=NULL)
							{
								printf("\n CMITEST: Task name tm_DMLPostColSVRRlzProcessUVF: %s ", dml_no);fflush(stdout);
								sprintf(command,"%s %s ",CLinfo4,dml_no);///home/cmitest/TC_ROOT_10/bin/tml_tools/CLUVFtaskDML.sh
								TC_write_syslog("Commandtm_DMLPostColSVRRlzProcessUVF = %s\n",command);
								system(command);
							}
							else
							{
								printf("\n CL-TASK:Other client.tm_DMLPostColSVRRlzProcessUVF. \n");fflush(stdout);
							}
						}
					}
					printf("\nDML is not of Veh/UVFhence skipping from validatn tm_DMLPostColSVRRlzProcess. \n");fflush(stdout);
				}
			} //if end of dml tag
			else
			{
				printf("\n Else--Input DML does not present.tm_DMLPostColSVRRlzProcess.UVF.\n");fflush(stdout);
			}

			printf("\n\n CL Task-Process is Finished.tm_DMLPostColSVRRlzProcessUVF.\n");fflush(stdout);

			return ITK_ok;
		}
		char* GetColourSrlFrmSchmCompCodes(tag_t *CmpCodesOfClrSchm, int CmpCnt, char *PartCompCode)
		{
			int g1=0;

			char *SchmCmpCode=NULL;
			char *t5ClSrl=NULL;
			char *Suffix5=NULL;
			char *ColourID5=NULL;

			tag_t CmpCodeObjTag = NULLTAG;

			t5ClSrl = (char*) malloc(50);
			//Suffix5 = (char*) malloc(20);

			printf("\n In GetColourSrlFrmSchmCompCodes function  CmpCnt: [%d]   PartCompCode: [%s] ",CmpCnt,PartCompCode); fflush(stdout);

			strcpy(t5ClSrl,"");

			for(g1=0;g1<CmpCnt;g1++ )
			{
				if(CmpCodeObjTag) CmpCodeObjTag=NULLTAG;
				CmpCodeObjTag = CmpCodesOfClrSchm[g1];
				if(AOM_ask_value_string(CmpCodeObjTag, "t5_PrtCatCode", &SchmCmpCode )!=ITK_ok)PrintErrorStack();
				//printf("\n SchmCmpCode & Comp_Code is --> : %s = %s\n",SchmCmpCode,Comp_Code); fflush(stdout);

				if(tc_strcmp(SchmCmpCode,PartCompCode)==0)
				{
					printf("\n    SchmCmpCode & PartCompCode-->:%s = %s: ---------->CompCode Match Found......",SchmCmpCode,PartCompCode); fflush(stdout);
					fprintf(fpCLLog,"\n    SchmCmpCode & PartCompCode-->:%s = %s: ---------->CompCode Match Found......",SchmCmpCode,PartCompCode); fflush(fpCLLog);

					if(AOM_ask_value_string(CmpCodeObjTag, "t5_ClSrl", &t5ClSrl )!=ITK_ok)PrintErrorStack();
					printf("\t CL=t5ClSrl--> %s \n",t5ClSrl); fflush(stdout);
					fprintf(fpCLLog,"\t CL=t5ClSrl--> %s",t5ClSrl); fflush(fpCLLog);

					//if(tc_strstr(t5ClSrl,";")!=NULL) {
					//	Suffix5 =  strtok(t5ClSrl,";");
					//	ColourID5  =  strtok(NULL,";");
					//}
					//else {
					//	Suffix5 =  strtok(t5ClSrl,",");
					//	ColourID5  =  strtok(NULL,",");
					//}
					//printf("\t Suffix5: %s    ColourID5: %s ",Suffix5,ColourID5); fflush(stdout);
					////fprintf(fpCLLog,"\t Suffix5: %s    ColourID5: %s ",Suffix5,ColourID5); fflush(fpCLLog);
				}
			}

			//return Suffix5;
			return t5ClSrl;
		}
		tag_t ColorPartCreate_CL(tag_t NonClrPartRevTag, char *NonClrPart, char *PartCompCode, tag_t SchmRefTag, tag_t *CmpCodesOfClrSchm, int CmpCnt, char *SchemeNm, char *SchemeRev, tag_t CLTaskDmlTag)
		{
			int n_ClrParts=0;
			
			char *t5ClSrl = NULL;
			char *Suffix=NULL;
			char *ColourID=NULL;
			char *PartType=NULL;
			char *ClrChildItem=NULL;

			//char *qry_entries[1] = {"Colour ID"},	//uadev
			char *qry_entries[1] = {"Comp Code"},	//UAPROD
				 *qry_values[1]	= {"*"};

			char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));

			tag_t *ClrPartTags=NULLTAG;

			tag_t ColPartRevTag=NULLTAG;
			tag_t ColChilditemMstr = NULLTAG;
			tag_t ReltnExist = NULLTAG;
			tag_t Rel_task = NULLTAG;
			tag_t reltask = NULLTAG;
			tag_t tRelationExist = NULLTAG;

			t5ClSrl = (char*) malloc(50);


			t5ClSrl = GetColourSrlFrmSchmCompCodes(CmpCodesOfClrSchm,CmpCnt,PartCompCode);
			printf("\n  CL-B=t5ClSrl from function: %s",t5ClSrl); fflush(stdout);
			fprintf(fpCLLog,"\n  CL=t5ClSrl from function: %s",t5ClSrl); fflush(fpCLLog);

			if(AOM_ask_value_string(NonClrPartRevTag, "t5_PartType", &PartType)!=ITK_ok)PrintErrorStack();

			if ((t5ClSrl!=NULL) && (strlen(t5ClSrl)>0))
			{
				if(tc_strstr(t5ClSrl,";")!=NULL) {
					Suffix =  strtok(t5ClSrl,";");
					ColourID  =  strtok(NULL,";");
				}
				else {
					Suffix =  strtok(t5ClSrl,",");
					ColourID  =  strtok(NULL,",");
				}
				printf("\n\t   CL=Suffix-->: %s  ColourID: %s ",Suffix,ColourID); fflush(stdout);
				fprintf(fpCLLog,"\n\t   CL=Suffix-->: %s  ColourID: 5s ",Suffix,ColourID); fflush(fpCLLog);

				ClrChildItem=(char *) MEM_alloc(25);
				strcpy(ClrChildItem,"");

				if(tc_strcmp(PartType,"G")==0)
				{
					printf("\n  In GroupID if condition===\n"); fflush(stdout);
					//ResponseStr = NewUniqGroupIDNum();
					//printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
					//
					//ClrChildItem = NULL;
					//ClrChildItem=(char *) MEM_alloc(25);
					//strcpy(ClrChildItem,"");
					//strcat(ClrChildItem,ResponseStr);
					//printf("\n\t   Colour Part for Group ID---->%s\n",ClrChildItem); fflush(stdout);
					fflush(stdout);
				}
				else
				{
					strcpy(ClrChildItem,NonClrPart);
					strcat(ClrChildItem,Suffix);
				}
				printf("\n\t   R--ColPartNo: %s ",ClrChildItem); fflush(stdout);

				if ( (strlen(ClrChildItem)>0) && (ClrPartQryTag!=NULLTAG) )
				{
					//printf("\n\t   CM=Found Query 'ClrPart' ClrPartQryTag \n"); fflush(stdout);
					valuesClrPrt[0] = ClrChildItem;
					if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &n_ClrParts, &ClrPartTags));
					printf("\t ClrPart_QryCount------> %d ",n_ClrParts);fflush(stdout);

					if (n_ClrParts>0)
					{
						ColPartRevTag=ClrPartTags[0];
					}
					else if ((n_ClrParts==0) && (NonClrPartRevTag!=NULLTAG))
					{
						if(ITEM_create_item(ClrChildItem,ClrChildItem,"T5_ClrPart","NR;1",&ColChilditemMstr,&ColPartRevTag)!=ITK_ok) PrintErrorStack();
						if(ColPartRevTag != NULLTAG)
						{
							printf("\n\t R--T5_ClrPart is created---------->\n");fflush(stdout);
							fprintf(fpCLLog,"\n\t R--T5_ClrPart is created---------->\n");fflush(fpCLLog);

							char *t5PrtCatCd = NULL;
							char *t5object_desc = NULL;
							char *clrdesc = NULL;
							char *t5PartStatus = NULL;
							char *t5DesignGrp = NULL;
							char *t5ProjectCode = NULL;
							char *t5DocRemarks = NULL;
							char *t5DrawingInd = NULL;
							char *t5PartCode = NULL;
							char *t5AhdMakeBuyIndicator = NULL;
							char *t5PunPCBUMakeBuyIndicator = NULL;
							char *t5PunMakeBuyIndicator = NULL;
							char *t5DwdMakeBuyIndicator = NULL;
							char *t5Coated = NULL;
							char *UnitOfMeasureS = NULL;

							if( AOM_ask_value_string(NonClrPartRevTag,"t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"object_desc", &t5object_desc)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_Coated", &t5Coated)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_PartStatus", &t5PartStatus)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_DesignGrp", &t5DesignGrp)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_ProjectCode", &t5ProjectCode)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_DocRemarks", &t5DocRemarks)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_DrawingInd", &t5DrawingInd)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_PartCode", &t5PartCode)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_AhdMakeBuyIndicator", &t5AhdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_PunPCBUMakeBuyIndicator", &t5PunPCBUMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_PunMakeBuyIndicator", &t5PunMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
							if( AOM_ask_value_string(NonClrPartRevTag,"t5_DwdMakeBuyIndicator", &t5DwdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();

							printf("\n\t   3.ClrChildItem ---->%s   t5PrtCatCd---->%s   ColourID---->%s",ClrChildItem,t5PrtCatCd,ColourID);fflush(stdout);
							//printf("\n\t   t5Coated---->%s",t5Coated);fflush(stdout);
							//printf("\n\t   t5PartStatus---->%s",t5PartStatus);fflush(stdout);
							//printf("\n\t   t5DesignGrp---->%s",t5DesignGrp);fflush(stdout);
							//printf("\n\t   t5ProjectCode---->%s",t5ProjectCode);fflush(stdout);
							//printf("\n\t   mod_desc---->%s",t5DocRemarks);fflush(stdout);
							//printf("\n\t   t5DrawingInd---->%s",t5DrawingInd);fflush(stdout);
							//printf("\n\t   PartType---->%s",PartType);fflush(stdout);
							//printf("\n\t   t5PartCode---->%s",t5PartCode);fflush(stdout);
							//printf("\n\t   t5AhdMakeBuyIndicator---->%s",t5AhdMakeBuyIndicator);fflush(stdout);
							//printf("\n\t   t5PunPCBUMakeBuyIndicator---->%s",t5PunPCBUMakeBuyIndicator);fflush(stdout);
							//printf("\n\t   t5PunMakeBuyIndicator---->%s",t5PunMakeBuyIndicator);fflush(stdout);
							//printf("\n\t   t5DwdMakeBuyIndicator---->%s",t5DwdMakeBuyIndicator);fflush(stdout);

							clrdesc=(char *) MEM_alloc(200);
							strcpy(clrdesc,"");
							strcpy(clrdesc,ColourID);
							strcat(clrdesc,"-");
							strcat(clrdesc,t5object_desc);

							printf("\n\t   Part Desc ---->%s \n",clrdesc);fflush(stdout);
							fprintf(fpCLLog,"\n\t   Part Desc ---->%s \n",clrdesc);fflush(fpCLLog);

							//if(setAttributesOnDesign(&ColChilditemMstr,clrdesc,UnitOfMeasureS)!=ITK_ok)PrintErrorStack();
							//printf("\n Set Attribute on Class T5_ClrPart------------>\n");fflush(stdout);

							if(tm_setAttributesOnDesignRev2(&ColPartRevTag,clrdesc,"C",t5PrtCatCd,ColourID,t5Coated,t5PartStatus,t5DesignGrp,t5ProjectCode,t5DocRemarks,t5DrawingInd,PartType,t5PartCode,t5AhdMakeBuyIndicator,t5PunPCBUMakeBuyIndicator,t5PunMakeBuyIndicator,t5DwdMakeBuyIndicator,NonClrPart)!=ITK_ok)PrintErrorStack();
							printf("\n\t   Set Attribute on Class T5_ClrPartRevision--------->\n");fflush(stdout);
							fprintf(fpCLLog,"\n\t   Set Attribute on Class T5_ClrPartRevision--------->\n");fflush(fpCLLog);

							if(tm_CreateReleasestatus(ColPartRevTag)!=ITK_ok)PrintErrorStack();
							printf("\n\t   CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(stdout);
							fprintf(fpCLLog,"\n\t   CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(fpCLLog);

							if(tm_AssignProject(ColPartRevTag,t5ProjectCode)!=ITK_ok)PrintErrorStack();
							printf("\n\t   Assign Project to T5_ClrPartsRevision--------->\n");fflush(stdout);
							fprintf(fpCLLog,"\n\t   Assign Project to T5_ClrPartsRevision--------->\n");fflush(fpCLLog);

							//Going to update UserOwner Name
							//if(AOM_set_ownership(ColPartRevTag,user_tag ,group)!=ITK_ok)PrintErrorStack();
							//printf("\n\t   property Value set...!!\n");fflush(stdout);

							if (ColPartRevTag!=NULLTAG)
							{
								if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
								{
									if(GRM_find_relation(CLTaskDmlTag,ColPartRevTag,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
									if (ReltnExist==NULLTAG)
									{
										if(GRM_create_relation(CLTaskDmlTag,ColPartRevTag,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
										if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
										if(AOM_refresh(reltask,FALSE)!=ITK_ok)PrintErrorStack();
										printf("\n\t   DML_Task and Revised New ColChild Part Relation is Created Successfully.....\n");fflush(stdout);
										fprintf(fpCLLog,"\n\t   DML_Task and Revised New ColChild Part Relation is Created Successfully.....\n");fflush(fpCLLog);
									}
								}

								if (tRelationFind!=NULLTAG)
								{
									if(GRM_find_relation(ColPartRevTag,NonClrPartRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
									if (tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
									{
										if(GRM_create_relation(ColPartRevTag,NonClrPartRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
										printf("\n\t   Child-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
										fprintf(fpCLLog,"\n\t   Child-Colour-Non_Colour child part Relation Created Successfully \n");fflush(fpCLLog);
										if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();
										if(AOM_refresh(Rel_task,FALSE)!=ITK_ok)PrintErrorStack();
									}
								}

								if(AOM_refresh(ColPartRevTag,TRUE)!=ITK_ok)PrintErrorStack();
								if(AOM_set_value_string(ColPartRevTag,"gov_classification",SchDataToGov)!=ITK_ok)PrintErrorStack();
								if(AOM_save_without_extensions(ColPartRevTag)!=ITK_ok)PrintErrorStack();
								if(AOM_refresh(ColPartRevTag,FALSE)!=ITK_ok)PrintErrorStack();
							}
						}
					}
				}
			}

			return ColPartRevTag;
		}
		int ValMultiLvlBomForScheme_CL(tag_t NonClrBomline, tag_t SchmRefTag, tag_t *CmpCodesOfClrSchm, int CmpCnt, char *SchemeNm, char *SchemeRev, tag_t CLTaskDmlTag)
		{
			int ifail;
			int no_bom_lines=0 , j=0;
			int n_tags_found= 0;
			int level0=0;
			int CompCodeClrSrlMatchFlag = 0;
			int n_ClrChild_tags = 0;

			char *name=NULL;
			char *word=NULL;
			char *NonClrChild=NULL;
			char *ItemRevSeq=NULL;
			char *ItemRevStr=NULL;
			char *ColourInd=NULL;
			char *CompCode=NULL;
			char *ChildItem=NULL;
			char *ChildColInd=NULL;
			char *ChildCompCode=NULL;
			char *ClrChildItem=NULL;

			char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
			char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));

			tag_t *child_bom_lines=NULLTAG;
			tag_t *ClrChildTags=NULLTAG;

			tag_t NonClrMstrTag=NULLTAG;
			tag_t NonClrRevTag=NULLTAG;
			tag_t childbomline=NULLTAG;


			//char *qry_entries[1] = {"Colour ID"},	//uadev
			char *qry_entries[1] = {"Comp Code"},	//UAPROD
				 *qry_values[1]	= {"*"};

			CompCode =(char *) MEM_alloc(100);

			printf("\n In ValMultiLvlBomForScheme_CL Function...........................................................................................\n"); fflush(stdout);
			fprintf(fpCLLog,"\n In ValMultiLvlBomForScheme_CL Function...........................................................................................\n"); fflush(fpCLLog);
			
			//initialise_attribute (bomAttr_lineName, &name_attribute);

			printf("\n 1111 --------\n "); fflush(stdout);
			fprintf(fpCLLog,"\n 1111 --------\n "); fflush(fpCLLog);

			//ifail = BOM_line_ask_attribute_string (NonClrBomline, name_attribute, &name);
			ifail = AOM_UIF_ask_value(NonClrBomline,"bl_line_name",&name);
			printf("\n name: [%s]",name); fflush(stdout);
			CHECK_FAIL;
			word = strtok(name, "/");

			printf("\n word: [%s]",word); fflush(stdout);
			if (tc_strcmp(word,"<<REMOTE OBJECT>>")!=0)
			{
				//if( AOM_ask_value_string(NonClrBomline,"bl_T5_ClrPartRevision_t5_ColourInd",&ColourInd)!=ITK_ok);  //uadev
				if( AOM_ask_value_string(NonClrBomline,"bl_Design Revision_t5_ColourInd",&ColourInd)!=ITK_ok);		//UAPROD

				tc_strcpy(CompCode,"");
				//if( AOM_ask_value_string(NonClrBomline,"bl_T5_ClrPartRevision_t5_PrtCatCode",&CompCode)!=ITK_ok);  //uadev
				if( AOM_ask_value_string(NonClrBomline,"bl_Design Revision_t5_PrtCatCode",&CompCode)!=ITK_ok);		//UAPROD

				//if ((tc_strcmp(ColourInd,"Y")==0)&&(strlen(CompCode)>0) && ((tc_strstr(CompCode,"CCA")==NULL)||(tc_strstr(CompCode,"VEHICLE")==NULL)||(tc_strstr(CompCode,"TPL")==NULL)) )
				if ((tc_strcmp(ColourInd,"Y")==0)&&(strlen(CompCode)>0) && ((tc_strstr(CompCode,"CCA")==NULL)&&(tc_strstr(CompCode,"VEHICLE")==NULL)&&(tc_strstr(CompCode,"TPL")==NULL)) )
				{
					if( AOM_ask_value_int(NonClrBomline,"bl_level_starting_0",&level0)!=ITK_ok);
					if( AOM_ask_value_string(NonClrBomline,"bl_item_item_id",&NonClrChild)!=ITK_ok);
					if( AOM_ask_value_string(NonClrBomline,"bl_rev_item_revision_id",&ItemRevSeq)!=ITK_ok);

					printf("\n NonClrChild::::::[%d]  [%s]    ItemRevSeq: [%s]    ColourInd:[%s]    CompCode:[%s]",level0,NonClrChild, ItemRevSeq, ColourInd, CompCode); fflush(stdout);

					if(ITEM_find_item(NonClrChild, &NonClrMstrTag)!=ITK_ok)PrintErrorStack();
					if(ITEM_ask_latest_rev(NonClrMstrTag,&NonClrRevTag)!=ITK_ok)PrintErrorStack();
					//if(ITEM_find_revision(NonClrMstrTag,ItemRevSeq,&NonClrRevTag)!=ITK_ok)PrintErrorStack();

					ifail = BOM_line_ask_child_lines (NonClrBomline, &no_bom_lines, &child_bom_lines);
					CHECK_FAIL;

					if (no_bom_lines > 0)
					{
						int ClrChPrtCount=0, colChPrtCnt=0, zp3=0, ColRlzRevFlag=0, PartAttachtoCLTaskFlag=0, ColChildMatch=0;
						int g1=0, n_childCnt=0, it=0;
						int bv_clrcount=0, bvr_count=0, n_occs_clr=0, ic=0;
						int NoClrChildinBom=0, CLTskHSICnt=0, ci=0;

						char *ClrChildSet=NULL;
						char *ColPrtRelSt = NULL;
						char *ColChild = NULL;
						char *ColChildRev = NULL;
						char *ChildComp = NULL;
						char *ChildColourID = NULL;
						char *SchmCmpCode=NULL;
						char *t5ClSrl = NULL;
						char *Suffix = NULL;
						char *ColourID = NULL;
						char *child_item_id = NULL;
						char *ChildColIndClr = NULL;
						char *NewColPartRevSeq = NULL;
						char *NPrtLatestRlzSt = NULL;
						char *tsk_name = NULL;
						char *TskSolutnItem = NULL;

						tag_t *ClrChPrts_tag=NULLTAG;
						tag_t *ColChPrtUniqTags = NULLTAG;
						tag_t *clr_bvs = NULLTAG;
						tag_t *clr_bvrs = NULLTAG;
						tag_t *occs_clr = NULLTAG;
						tag_t *childrenClr = NULLTAG;
						tag_t *CLTskHSItems = NULLTAG;

						tag_t CmpCodeObjTag=NULLTAG;
						tag_t ChildColRevTag = NULLTAG;
						tag_t ColItemMstrTag = NULLTAG;
						tag_t ColLatestRevTag = NULLTAG;
						tag_t ClritemTag = NULLTAG;
						tag_t clrbv = NULLTAG;
						tag_t clrbvrTag = NULLTAG;
						tag_t windowVal = NULLTAG;
						tag_t top_bomLineClr = NULLTAG;
						tag_t NewColorRevTag = NULLTAG;
						tag_t ReltnExist=NULLTAG, reltask=NULLTAG, Rel_task=NULLTAG, tRelationExist1 = NULLTAG, tRelationExist=NULLTAG;


						logical checkout;
						int ncItem_count=0, ik=0 ;
						tag_t *ncRev_list=NULLTAG;
						tag_t NonClrPrtPrevRevTag=NULLTAG;
						char *ncPartno=NULL;
						char *ncPartRev=NULL;
						char *ncRel_status=NULL;

						t5ClSrl = (char*) malloc(50);


						if((tRelationFind!=NULLTAG) && (NonClrRevTag!=NULLTAG))
						{
							if (tc_strstr(ItemRevSeq,"NR;")==NULL)	//Current Rev is NR hence not querying previous revision
							{
								if(ITEM_list_all_revs (NonClrRevTag, &ncItem_count, &ncRev_list)!=ITK_ok)PrintErrorStack();
								printf("\n\t CL=ncItem_count::%d:\n\t", ncItem_count);fflush(stdout);
								fprintf(fpCLLog,"\n\t CL=ncItem_count::%d:\n\t", ncItem_count);fflush(fpCLLog);

								if(ncItem_count > 0)
								{
									for(ik=ncItem_count-1;ik>=0;ik--)
									{
										if(AOM_UIF_ask_value(ncRev_list[ik], "item_id", &ncPartno)!=ITK_ok)PrintErrorStack();
										if(AOM_UIF_ask_value(ncRev_list[ik], "item_revision_id", &ncPartRev)!=ITK_ok)PrintErrorStack();
										if(AOM_UIF_ask_value (ncRev_list[ik], "release_status_list", &ncRel_status)!=ITK_ok)PrintErrorStack();
										if((tc_strstr(ncRel_status,"ERC Released")!=NULL)||(tc_strstr(ncRel_status,"T5_LcsErcRlzd")!=NULL))
										{
											printf("  ncPartno=%s:%s:--", ncPartno,ncPartRev);fflush(stdout);
											fprintf(fpCLLog,"  ncPartno=%s:%s:--", ncPartno,ncPartRev);fflush(fpCLLog);
											NonClrPrtPrevRevTag=ncRev_list[ik];
											break;
										}
									}
								}
							}

							if (NonClrPrtPrevRevTag!=NULLTAG)
							{
								//if(GRM_list_primary_objects_only(NonClrRevTag,tRelationFind,&ClrChPrtCount,&ClrChPrts_tag)!=ITK_ok)PrintErrorStack(); // Latest Non-colour do not have colour parts
								if(GRM_list_primary_objects_only(NonClrPrtPrevRevTag,tRelationFind,&ClrChPrtCount,&ClrChPrts_tag)!=ITK_ok)PrintErrorStack(); //checking colour parts to previous Non-col part
								printf("\n\t IF--ClrChPrtCount: %d",ClrChPrtCount);fflush(stdout);
							}
							else
							{
								if(GRM_list_primary_objects_only(NonClrRevTag,tRelationFind,&ClrChPrtCount,&ClrChPrts_tag)!=ITK_ok)PrintErrorStack(); // Latest Non-colour do not have colour parts
								printf("\n\t ELSE--ClrChPrtCount: %d",ClrChPrtCount);fflush(stdout);
							}

							if(ClrChPrtCount>0)
							{
								colChPrtCnt=0;
								ClrChildSet = (char *) MEM_alloc(10000 * sizeof(char));
								ColChPrtUniqTags = (tag_t *) MEM_alloc(10000 * sizeof(tag_t));
								tc_strcpy(ClrChildSet,"");

								for(zp3 = 0; zp3<ClrChPrtCount; zp3++)
								{
									if(AOM_ask_value_string(ClrChPrts_tag[zp3],"item_id",&ColChild)!=ITK_ok)PrintErrorStack();

									if(ITEM_find_item(ColChild, &ColItemMstrTag)!=ITK_ok)PrintErrorStack();
									if(ITEM_ask_latest_rev(ColItemMstrTag,&ColLatestRevTag)!=ITK_ok)PrintErrorStack();

									if (strlen(ClrChildSet)==0)
									{
										tc_strcpy(ClrChildSet,ColChild);
										tc_strcat(ClrChildSet,",");

										ColChPrtUniqTags[colChPrtCnt]=ColLatestRevTag;
										colChPrtCnt=colChPrtCnt+1;
									}
									else if (tc_strstr(ClrChildSet,ColChild)==NULL)
									{
										tc_strcat(ClrChildSet,ColChild);
										tc_strcat(ClrChildSet,",");

										ColChPrtUniqTags[colChPrtCnt]=ColLatestRevTag;
										colChPrtCnt=colChPrtCnt+1;
									}
								}
								printf("\n\t Distinct colChPrtCnt: %d",colChPrtCnt);fflush(stdout);
								fprintf(fpCLLog,"\n\t Distinct colChPrtCnt: %d",colChPrtCnt);fflush(fpCLLog);

								for(zp3 = 0; zp3<colChPrtCnt; zp3++)
								{
									ChildColRevTag=ColChPrtUniqTags[zp3];

									ColRlzRevFlag=0;
									PartAttachtoCLTaskFlag=0;

									if(AOM_ask_value_string(ChildColRevTag,"item_id",&ColChild)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(ChildColRevTag,"item_revision_id",&ColChildRev)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(ChildColRevTag,"t5_PrtCatCode",&ChildComp)!=ITK_ok)PrintErrorStack();
									if(AOM_ask_value_string(ChildColRevTag,"t5_ColourID",&ChildColourID)!=ITK_ok)PrintErrorStack();

									printf("\n\t %d--ColChild: %s,%s ",zp3,ColChild,ColChildRev);fflush(stdout);
									fprintf(fpCLLog,"\n\t %d--ColChild: %s/%s",zp3,ColChild,ColChildRev);fflush(fpCLLog);

									if(AOM_UIF_ask_value (ChildColRevTag, "release_status_list", &ColPrtRelSt)!=ITK_ok)PrintErrorStack();

									if(tc_strstr(ColPrtRelSt,"Obsolete")!=NULL)
									{
										printf(" --This colourPart is in 'Obsolete' hence skipping....");fflush(stdout);
										fprintf(fpCLLog," --This colourPart is in 'Obsolete' hence skipping....");fflush(fpCLLog);
										continue;
									}
									if((tc_strstr(ColPrtRelSt,"ERC Released")!=NULL)||(tc_strstr(ColPrtRelSt,"T5_LcsErcRlzd")!=NULL))
									{
										ColRlzRevFlag=1;
									}
									printf(" ColPrtRelSt: [%s]   ColRlzRevFlag: %d ",ColPrtRelSt,ColRlzRevFlag);fflush(stdout);
									fprintf(fpCLLog," ColPrtRelSt: [%s]   ColRlzRevFlag: %d ",ColPrtRelSt,ColRlzRevFlag);fflush(fpCLLog);

									if (ColRlzRevFlag==0)
									{
										////If ColPrtRelSt=ERC Review then check whether it is attach to any DML of not

										if(AOM_ask_value_string(CLTaskDmlTag,"object_name",&tsk_name)==ITK_ok)
										//printf("\n tsk_name is :%s\n",tsk_name);fflush(stdout);
										//fprintf(fpCLLog,"\n tsk_name is :%s\n",tsk_name);fflush(fpCLLog);

										if (tsk_HSI_rel_type!=NULLTAG)
										{
											if(GRM_list_secondary_objects_only(CLTaskDmlTag, tsk_HSI_rel_type, &CLTskHSICnt, &CLTskHSItems)!=ITK_ok)PrintErrorStack();
											printf("\n\t CLTask: %s --->> CLTskHSICnt partcnt:  %d ",tsk_name, CLTskHSICnt);fflush(stdout);
											fprintf(fpCLLog,"\n    Task: %s --->> CLTskHSICnt partcnt:  %d ",tsk_name, CLTskHSICnt);fflush(fpCLLog);

											if (CLTskHSICnt > 0)
											{
												for (ci = 0; ci < CLTskHSICnt ; ci ++)
												{
													if( AOM_ask_value_string(CLTskHSItems[ci],"item_id",&TskSolutnItem)==ITK_ok)
													//printf("\n\t\t TskSolutnItem-item_id: %s  ColChild: %s",TskSolutnItem,ColChild);fflush(stdout);

													if (tc_strcmp(ColChild,TskSolutnItem)==0)
													{
														printf("\n\t TskSolutnItem-item_id: %s  ColChild: %s",TskSolutnItem,ColChild);fflush(stdout);
														printf(" ---Match-Colour attached found to DML task"); fflush(stdout);
														fprintf(fpCLLog,"\n\t TskSolutnItem-item_id: %s  ColChild: %s",TskSolutnItem,ColChild);fflush(fpCLLog);
														fprintf(fpCLLog," ---Match-Colour attached found to DML task"); fflush(fpCLLog);

														PartAttachtoCLTaskFlag=1;

														break;
													}
												}
											}
										}
									}//if (ColRlzRevFlag==0)


									// Process if non-colour Review part is attached to same DML



									ColChildMatch=0;
									t5ClSrl = (char*) malloc(50);
									t5ClSrl = GetColourSrlFrmSchmCompCodes(CmpCodesOfClrSchm,CmpCnt,ChildComp);
									printf("\n\t CL-C=t5ClSrl from function: [%s]  ChildComp: [%s] ",t5ClSrl,ChildComp); fflush(stdout);
									fprintf(fpCLLog,"\n\t CL-C=t5ClSrl from function: [%s]  ChildComp: [%s] ",t5ClSrl,ChildComp); fflush(fpCLLog);

									if ((t5ClSrl!=NULL) && (strlen(t5ClSrl)>0))
									{
										if(tc_strstr(t5ClSrl,";")!=NULL) {
										Suffix =  strtok(t5ClSrl,";");
										ColourID  =  strtok(NULL,";");
										}
										else {
											Suffix =  strtok(t5ClSrl,",");
											ColourID  =  strtok(NULL,",");
										}

										if (tc_strcmp(ChildColourID,ColourID)==0)
										{
											ColChildMatch=1;

											break;
										}
									}
								} // for loop end
							} //if(ClrChPrtCount>0)

							if(ClrChPrtCount==0)  //New Colour Child will create if not found in above condition
							{
								ChildColRevTag = ColorPartCreate_CL(NonClrRevTag,NonClrChild,CompCode,SchmRefTag, CmpCodesOfClrSchm, CmpCnt, SchemeNm, SchemeRev,CLTaskDmlTag);
								ColChildMatch=1;
							}

							printf("\n\t ColChildMatch :%d ",ColChildMatch);fflush(stdout);

							if (ColChildMatch==1)
							{
								if(ChildColRevTag!=NULLTAG)
								{
									//Create Colour Assembly BVR
									if(ITEM_ask_item_of_rev(ChildColRevTag, &ClritemTag)!=ITK_ok)PrintErrorStack();
									if(ITEM_list_bom_views(ClritemTag,&bv_clrcount, &clr_bvs)!=ITK_ok)PrintErrorStack();
									printf("\n\t 3--bv_clrcnt :%d ",bv_clrcount);fflush(stdout);
									fprintf(fpCLLog,"\n\t 3--bv_clrcnt :%d ",bv_clrcount);fflush(fpCLLog);

									if ( (bv_clrcount>0) && (clr_bvs) )
									{
										clrbv = clr_bvs[0];
										MEM_free(clr_bvs);
									}
									else
									{
										if(PS_create_bom_view( NULLTAG, "", "", ClritemTag,&clrbv )!=ITK_ok)PrintErrorStack();
										if(AOM_save_without_extensions( clrbv )!=ITK_ok)PrintErrorStack();
										if(AOM_save_without_extensions( ClritemTag )!=ITK_ok)PrintErrorStack();
										if(AOM_refresh( ClritemTag,FALSE )!=ITK_ok)PrintErrorStack();
										printf("\n\t 3--inside PS_create_bom_view..\n");fflush(stdout);
										fprintf(fpCLLog,"\n\t 3--inside PS_create_bom_view..\n");fflush(fpCLLog);
									}

									if(clrbv !=NULLTAG)
									{
										//printf("\n Before clrbvrTag find...");fflush(stdout);
										if(ITEM_rev_list_bom_view_revs( ChildColRevTag, &bvr_count, &clr_bvrs)!=ITK_ok)PrintErrorStack();
										printf("\n\t 3--Colour bvr_count  --->[%d]  ",bvr_count); fflush(stdout);
										fprintf(fpCLLog,"\n\t 3--Colour bvr_count  --->[%d]  ",bvr_count); fflush(fpCLLog);
										if (bvr_count > 0)
										{
											clrbvrTag=clr_bvrs[0];
											MEM_free(clr_bvrs);

											if(AOM_refresh(clrbvrTag,TRUE)!=ITK_ok)PrintErrorStack();
											if(PS_list_occurrences_of_bvr( clrbvrTag, &n_occs_clr, &occs_clr )!=ITK_ok)PrintErrorStack();
											printf("\n\t 3-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(stdout);
											fprintf(fpCLLog,"\n\t 3-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(fpCLLog);


											if(BOM_create_window( &windowVal )!=ITK_ok)PrintErrorStack();
											if(BOM_set_window_top_line_bvr	(windowVal, clrbvrTag, &top_bomLineClr)!=ITK_ok)PrintErrorStack();
											if(BOM_set_window_pack_all (windowVal, true)!=ITK_ok)PrintErrorStack();
											if(BOM_line_ask_child_lines (top_bomLineClr, &n_childCnt, &childrenClr)!=ITK_ok)PrintErrorStack();

											printf ("\n  B--n_childCnt=> %d ", n_childCnt); fflush(stdout);

											NoClrChildinBom=0;
											if ( n_childCnt > 0)
											{
												for (it = 0; it < n_childCnt; it++)
												{
													if( AOM_ask_value_string(childrenClr[it], "bl_item_item_id",&child_item_id)!=ITK_ok)PrintErrorStack();
													if( AOM_ask_value_string( childrenClr[it] ,"bl_Design Revision_t5_ColourInd",&ChildColIndClr)!=ITK_ok)PrintErrorStack();

													if (strcmp(ChildColIndClr,"Y")==0)
													{
														NoClrChildinBom=NoClrChildinBom+1;
													}
												}
											}

										}
										else
										{
											if(PS_create_bvr( clrbv, "", "", false, ChildColRevTag,&clrbvrTag)!=ITK_ok)PrintErrorStack();
											if(clrbvrTag !=NULLTAG)
											{
												if(AOM_save_without_extensions( clrbvrTag)!=ITK_ok)PrintErrorStack();
												if(AOM_save_without_extensions( ChildColRevTag )!=ITK_ok)PrintErrorStack();
												if(AOM_refresh( ChildColRevTag,FALSE )!=ITK_ok)PrintErrorStack();
												printf( "\n\t 3--inside  PS_create_bvr..\n");fflush(stdout);
												fprintf(fpCLLog,"\n\t inside  PS_create_bvr..\n");fflush(fpCLLog);
											}
										}
									}
								}


								printf("\n D--ColRlzRevFlag:%d   PartAttachtoCLTaskFlag: %d ",ColRlzRevFlag,PartAttachtoCLTaskFlag);fflush(stdout);
								fprintf(fpCLLog,"\n\t D--ColRlzRevFlag:%d   PartAttachtoCLTaskFlag: %d ",ColRlzRevFlag,PartAttachtoCLTaskFlag);fflush(fpCLLog);

								if ((ColRlzRevFlag>0) || (PartAttachtoCLTaskFlag==1))  //ERC released ColPart
								{
									int ReviseStatus = ValColAndNonColBomForRevise_CL(NonClrRevTag,ChildColRevTag,ColRlzRevFlag,SchmRefTag);
									printf("   ReviseStatus: %d   ",ReviseStatus);fflush(stdout);

									if ((ReviseStatus==0) && (NoClrChildinBom==0) /*&&(strlen(NonClrChildSet)==0)*/)
									{
										printf(" ---D--No need to revive Colour: %s,%s [%s] --No BOM Difference ..",ColChild,ColChildRev,ColPrtRelSt);fflush(stdout);
										fprintf(fpCLLog,"\t ---D--No need to revive Colour: %s,%s [%s] --No BOM Difference ..",ColChild,ColChildRev,ColPrtRelSt);fflush(fpCLLog);
									}
									else
									{
										//Revise colour childAssy logic
										printf(" ---E--Revive Colour ChildAssy: %s,%s [%s]---",ColChild,ColChildRev,ColPrtRelSt);fflush(stdout);

										if(RES_is_checked_out(ChildColRevTag,&checkout)!=ITK_ok)PrintErrorStack();
										printf(" checkout: %d ",checkout);fflush(stdout);
										fprintf(fpCLLog," 333checkout: %d ",checkout);fflush(fpCLLog);
										if (checkout==0)
										{
											if (ColRlzRevFlag>0)
											{
												if(ITEM_copy_rev(ChildColRevTag,NULL,&NewColorRevTag)!=ITK_ok)PrintErrorStack();  //Revise
												if(AOM_ask_value_string(NewColorRevTag,"item_revision_id",&NewColPartRevSeq)!=ITK_ok)PrintErrorStack();
												printf("\n\t CL--ExpandFunctn=NewColPartRevSeq: %s ",NewColPartRevSeq);fflush(stdout);
												fprintf(fpCLLog,"\n\t CL--ExpandFunctn=NewColPartRevSeq: %s ",NewColPartRevSeq);fflush(fpCLLog);

												printf ( "\t SchDataToGov---> %s \n",SchDataToGov);fflush(stdout);
												fprintf (fpCLLog,"\t SchDataToGov---> %s \n",SchDataToGov);fflush(fpCLLog);

												if(AOM_refresh(NewColorRevTag,TRUE)!=ITK_ok)PrintErrorStack();
												if(AOM_set_value_string(NewColorRevTag,"gov_classification",SchDataToGov)!=ITK_ok)PrintErrorStack();
												if(AOM_save_without_extensions(NewColorRevTag)!=ITK_ok)PrintErrorStack();
												if(AOM_refresh(NewColorRevTag,FALSE)!=ITK_ok)PrintErrorStack();
												if (NewColorRevTag!=NULLTAG)
												{
													if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
													{
														if(GRM_find_relation(CLTaskDmlTag,NewColorRevTag,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
														if (ReltnExist==NULLTAG)
														{
															if(GRM_create_relation(CLTaskDmlTag,NewColorRevTag,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
															if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
															if(AOM_refresh(reltask,FALSE)!=ITK_ok)PrintErrorStack();
															printf("\n\t CL--ExpandFunctn=DML_Task and Revised New ColPart Relation is Created Successfully.....\n");fflush(stdout);
															fprintf(fpCLLog,"\n\t CL--ExpandFunctn=DML_Task and Revised New ColPart Relation is Created Successfully.....\n");fflush(fpCLLog);
														}
													}

													//below point is in Under discussion at TZ 1.56
													int n_attchs=0 ,l=0;
													tag_t*  secondary_objects = NULLTAG;

													if (tRelationFind!=NULLTAG)
													{
														if(GRM_find_relation(NewColorRevTag,NonClrRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
														if(tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
														{
															if(GRM_create_relation(NewColorRevTag,NonClrRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
															if(Rel_task!=NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
															{
																printf("\n CL--ExpandFunctn=Assy-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
																fprintf(fpCLLog,"\n CL--ExpandFunctn=Assy-Colour-Non_Colour child part Relation Created Successfully \n");fflush(fpCLLog);
																if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();
																if(AOM_refresh(Rel_task,FALSE)!=ITK_ok)PrintErrorStack();
															}
															else
															{
																printf("\n CL--ExpandFunctn=Assy-Colour-Non_Colour child part Relation is NOT Created Successfully \n");fflush(stdout);
																fprintf(fpCLLog,"\n CL--ExpandFunctn=Assy-Colour-Non_Colour child part Relation is NOT Created Successfully \n");fflush(fpCLLog);
															}
														}

														printf("\n\n\t CL--NewColPartRevSeq :: %s\n",NewColPartRevSeq);fflush(stdout);

														if (tc_strstr(NewColPartRevSeq,"NR")==NULL)
														{
															printf("\n\n\t CL--ExpandFunctn ");fflush(stdout);
															if(GRM_list_secondary_objects_only(NewColorRevTag,tRelationFind,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
															printf("\n  =No of DI : %d\n",n_attchs);fflush(stdout);
															fprintf(fpCLLog,"\n\n\t\t CL--ExpandFunctn=No of DI : %d",n_attchs);fflush(fpCLLog);
															if(n_attchs>0)
															{
																for (l=0;l<n_attchs ;l++ )
																{
																	if(AOM_UIF_ask_value (secondary_objects[l], "release_status_list", &NPrtLatestRlzSt)!=ITK_ok)PrintErrorStack();
																	if((tc_strstr(NPrtLatestRlzSt,"ERC Released")!=NULL) || (tc_strstr(NPrtLatestRlzSt,"T5_LcsErcRlzd")!=NULL))
																	{
																		printf("\t ColPrtLatestRlzSt: %s\n",NPrtLatestRlzSt);fflush(stdout);
																		fprintf(fpCLLog,"\t ColPrtLatestRlzSt: %s\n",NPrtLatestRlzSt);fflush(fpCLLog);
																		if(GRM_find_relation(NewColorRevTag,secondary_objects[l],tRelationFind,&tRelationExist1)!=ITK_ok)PrintErrorStack();
																		if(tRelationExist1!=NULLTAG)
																		{
																			if(GRM_delete_relation(tRelationExist1)!=ITK_ok)PrintErrorStack();
																			if(AOM_refresh(NewColorRevTag,TRUE)!=ITK_ok)PrintErrorStack();
																			if(AOM_save_without_extensions(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																			if(AOM_refresh(NewColorRevTag,FALSE)!=ITK_ok)PrintErrorStack();
																			printf("\n CL--ExpandFunctn=Relation Deleted Successfully\n"); fflush(stdout);
																			fprintf(fpCLLog,"\n CL--ExpandFunctn=Relation Deleted Successfully\n"); fflush(fpCLLog);
																		}
																	}
																}
															}
														}// end for if
													}
												}
											}
											else
											{
												NewColorRevTag=ChildColRevTag; //For ERC Review
											}
											
											if(NewColorRevTag!=NULLTAG)
											{
												//if(AOM_ask_value_string(NewColorRevTag,"item_revision_id",&ColChildRev)!=ITK_ok)PrintErrorStack();
												//printf("\n\t ColChildRev: %s  ",ColChildRev);fflush(stdout);

												//Create Colour Assembly BVR
												if(ITEM_ask_item_of_rev(NewColorRevTag, &ClritemTag)!=ITK_ok)PrintErrorStack();
												if(ITEM_list_bom_views(ClritemTag,&bv_clrcount, &clr_bvs)!=ITK_ok)PrintErrorStack();
												printf("  bv_clrcnt :%d ",bv_clrcount);fflush(stdout);
												fprintf(fpCLLog,"  bv_clrcnt :%d ",bv_clrcount);fflush(fpCLLog);

												if (bv_clrcount!=NULLTAG)
												{
													clrbv = clr_bvs[0];
													MEM_free(clr_bvs);
												}
												else
												{
													if(PS_create_bom_view( NULLTAG, "", "", ClritemTag,&clrbv )!=ITK_ok)PrintErrorStack();
													if(AOM_save_without_extensions( clrbv )!=ITK_ok)PrintErrorStack();
													if(AOM_save_without_extensions( ClritemTag )!=ITK_ok)PrintErrorStack();
													if(AOM_refresh( ClritemTag,FALSE )!=ITK_ok)PrintErrorStack();
													printf("\n\t inside PS_create_bom_view..\n");fflush(stdout);
													fprintf(fpCLLog,"\n\t inside PS_create_bom_view..\n");fflush(fpCLLog);
												}

												if(clrbv !=NULLTAG)
												{
													//printf("\n Before clrbvrTag find...");fflush(stdout);
													if(ITEM_rev_list_bom_view_revs( NewColorRevTag, &bvr_count, &clr_bvrs)!=ITK_ok)PrintErrorStack();
													printf("\n\t CL--Colour bvr_count  --->[%d]  ",bvr_count); fflush(stdout);
													fprintf(fpCLLog,"\n\t CL--Colour bvr_count  --->[%d]  ",bvr_count); fflush(fpCLLog);
													if (bvr_count > 0)
													{
														clrbvrTag=clr_bvrs[0];
														MEM_free(clr_bvrs);

														if(AOM_refresh(clrbvrTag,TRUE)!=ITK_ok)PrintErrorStack();
														if(PS_list_occurrences_of_bvr( clrbvrTag, &n_occs_clr, &occs_clr )!=ITK_ok)PrintErrorStack();\
														printf("\n\t CL-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(stdout);
														fprintf(fpCLLog,"\n\t CL-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(fpCLLog);

														if (n_occs_clr > 0)
														{
															for (ic = 0; ic<n_occs_clr; ic++)
															{
																if(PS_delete_occurrence( clrbvrTag, occs_clr[ic] )!=ITK_ok)PrintErrorStack();
															}
															if(AOM_save_without_extensions( clrbvrTag )!=ITK_ok)PrintErrorStack();
															if(AOM_refresh( clrbvrTag ,FALSE)!=ITK_ok)PrintErrorStack();
															MEM_free(occs_clr);
														}
													}
													else
													{
														if(PS_create_bvr( clrbv, "", "", false, NewColorRevTag,&clrbvrTag)!=ITK_ok)PrintErrorStack();
														if(clrbvrTag !=NULLTAG)
														{
															if(AOM_save_without_extensions( clrbvrTag)!=ITK_ok)PrintErrorStack();
															if(AOM_save_without_extensions( NewColorRevTag )!=ITK_ok)PrintErrorStack();
															if(AOM_refresh( NewColorRevTag,FALSE )!=ITK_ok)PrintErrorStack();
															printf( "\n\t inside  PS_create_bvr..\n");fflush(stdout);
															fprintf(fpCLLog,"\n\t inside  PS_create_bvr..\n");fflush(fpCLLog);
														}
													}

													//--START--Adding Childs under New Colour Assy bvr-----------

													//Previous Released Colour assy- Start
													tag_t   bom_winclr=NULLTAG;
													tag_t   top_line1=NULLTAG;
													tag_t   ruleClr	=NULLTAG;
													int rulefound1= 0;
													tag_t *closurerule1 = NULL;
													tag_t close_tag1;
													char **rulename1 = NULL;
													char **rulevalue1 = NULL;
													tag_t *lines1 = NULL;
													int n_lines1,k1,k2,CClrQty =0;
													tag_t  clrPartObject		= NULLTAG;
													tag_t  CCChildItemTag		= NULLTAG;
													char *CCChildQty = NULL;
													char *ColourIndC = NULL;
													char *ClrCompCode = NULL;
													char *t5_clr_item_id = NULL;

													int nc1,NClrQty1,p1 =0;
													tag_t Childobject1 = NULLTAG;
													tag_t NCChildItemTag1 = NULLTAG;
													tag_t *NonClrChilds1 = NULLTAG;
													char *NCChild1=NULL;
													char *NCChildColInd1=NULL;
													char *NCChildQt1y=NULL;

													if (ChildColRevTag!=NULLTAG)
													{
														if(BOM_create_window( &bom_winclr)!=ITK_ok)PrintErrorStack();
														//if(CFM_find("Color ERC Released and above", &ruleClr)!=ITK_ok)PrintErrorStack(); // To be discussed later if released rule requitred here
														if(CFM_find("Color ERC Review and above", &ruleClr)!=ITK_ok)PrintErrorStack();
														if(BOM_set_window_config_rule(bom_winclr, ruleClr)!=ITK_ok)PrintErrorStack();
														/*
														if(PIE_find_closure_rules2("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound1, &closurerule1)!=ITK_ok)PrintErrorStack();
														if (rulefound1 > 0)
														{
															close_tag1 = closurerule1[0];
															printf ("closure ruleClr found \n");fflush(stdout);
															fprintf (fpCLLog,"closure ruleClr found \n");fflush(fpCLLog);
														}
														if(BOM_window_set_closure_rule(bom_winclr,close_tag1, 0, rulename1,rulevalue1)!=ITK_ok)PrintErrorStack();
														*/
														if(BOM_set_window_pack_all(bom_winclr, TRUE)!=ITK_ok)PrintErrorStack();
														if(BOM_set_window_top_line(bom_winclr , NULLTAG, ChildColRevTag, NULLTAG, &top_line1)!=ITK_ok)PrintErrorStack();
														if(BOM_line_ask_child_lines(top_line1, &n_lines1, &lines1)!=ITK_ok)PrintErrorStack();
													}
													printf("\n\tPrevisous rev-Colour bvr n_lines1: %d \n",n_lines1); fflush(stdout);
													//Previous Released Colour assy- End

													if(AOM_refresh(clrbvrTag,TRUE)!=ITK_ok)PrintErrorStack();
													printf("\n\t NonClrChild,ItemRevSeq= %s,%s   no_bom_lines==> %d",NonClrChild, ItemRevSeq,no_bom_lines); fflush(stdout);
													fprintf(fpCLLog,"\n\t NonClrChild,ItemRevSeq= %s,%s   no_bom_lines==> %d",NonClrChild, ItemRevSeq,no_bom_lines); fflush(fpCLLog);
													int nc2 = 0, NClrQty=0, p2=0;
													char *NCChild=NULL;
													char *NCChildRevSeq=NULL;
													char *NCChildColInd=NULL;
													char *NCChildCompCode=NULL;
													char *NCChildPartType=NULL;
													char *NCChildQty = NULL;
													char *clr_item_id = NULL;
													tag_t Childobject = NULLTAG;
													tag_t NCChildItemTag2 = NULLTAG;
													//tag_t NClrItemMstrTag=NULLTAG;
													tag_t NClrItemRevTag=NULLTAG;
													tag_t *occs = NULLTAG;

													for (nc2 = 0; nc2 < no_bom_lines; nc2++)
													{
														if(Childobject) Childobject=NULLTAG;
														Childobject=child_bom_lines[nc2];

														if(AOM_ask_value_string(Childobject, "bl_item_item_id", &NCChild)!=ITK_ok)PrintErrorStack();
														if(AOM_ask_value_string(Childobject, "bl_rev_item_revision_id", &NCChildRevSeq)!=ITK_ok)PrintErrorStack();
														if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_ColourInd", &NCChildColInd)!=ITK_ok)PrintErrorStack();
														if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_PrtCatCode", &NCChildCompCode)!=ITK_ok)PrintErrorStack();
														if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_PartType", &NCChildPartType)!=ITK_ok)PrintErrorStack();

														//if(BOM_line_ask_attribute_string(Childobject,QuantityAttrId, &NCChildQty)!=ITK_ok)PrintErrorStack();
														ifail = AOM_UIF_ask_value(Childobject,"bl_quantity",&NCChildQty);

														NClrQty=atoi(NCChildQty);

														printf("\n\n  A--nc2: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  PartType: [%s]   Bomline_NClrQty: [%d]",nc2,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode,NCChildPartType,NClrQty); fflush(stdout);
														fprintf(fpCLLog,"\n\n  A--nc2: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  Bomline_NClrQty: [%d]",nc2,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode,NClrQty); fflush(fpCLLog);

														if(ITEM_find_item(NCChild,&NCChildItemTag2)!=ITK_ok)PrintErrorStack();

														if(NCChildItemTag2==NULLTAG)
														{
															printf("\n\n  ChildPart==> %s/%s  NCChildItemTag2 tag not found ?????",NCChild,NCChildRevSeq); fflush(stdout);
															fprintf(fpCLLog,"\n\n  ChildPart==> %s/%s  NCChildItemTag2 tag not found ?????",NCChild,NCChildRevSeq); fflush(fpCLLog);
														}
														else
														{
															if(tc_strcmp(NCChildColInd,"N")==0)
															{
																printf(" ---child ColInd==> N \n"); fflush(stdout);
																fprintf(fpCLLog," ---child ColInd==> N \n"); fflush(fpCLLog);

																if(NClrQty==0)
																{
																	if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																}
																else
																{
																	for (p2=0;p2<NClrQty ;p2++ )
																	{
																		if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																		printf("\n    0-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																		fprintf(fpCLLog,"\n    0-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																	}
																}
															}
															else if(tc_strcmp(NCChildColInd,"Y")==0)
															{
																int childExistFl=0;

																printf(" ---child ColInd==> Y  NCChildCompCode: %s ",NCChildCompCode); fflush(stdout);
																fprintf(fpCLLog," ---child ColInd==> Y  NCChildCompCode: %s ",NCChildCompCode); fflush(fpCLLog);

																if((tc_strstr(NCChildCompCode,"CCA")!=NULL)||(tc_strstr(NCChildCompCode,"VEHICLE")!=NULL)||(tc_strstr(NCChildCompCode,"TPL")!=NULL))
																{
																	childExistFl=0;
																	for (k1=0;k1<n_lines1 ;k1++ )
																	{
																		if(clrPartObject) clrPartObject=NULLTAG;
																		clrPartObject=lines1[k1];

																		if(AOM_ask_value_string(clrPartObject, "bl_item_item_id", &t5_clr_item_id)!=ITK_ok)PrintErrorStack();
																		printf("\n\t B--t5_clr_item_id: %s",t5_clr_item_id); fflush(stdout);
																		fprintf(fpCLLog,"\n\t B--t5_clr_item_id: %s",t5_clr_item_id); fflush(fpCLLog);

																		if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
																		printf(" ColourIndC: %s",ColourIndC); fflush(stdout);
																		fprintf(fpCLLog," ColourIndC: %s",ColourIndC); fflush(fpCLLog);

																		if((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0))
																		{
																			if (strstr(t5_clr_item_id,NCChild)!=NULL)
																			{
																				childExistFl=1;

																				//if(BOM_line_ask_attribute_string(clrPartObject,QuantityAttrId, &CCChildQty)!=ITK_ok)PrintErrorStack();
																				//NClrQty=atoi(CCChildQty);

																				break;
																			}
																		}
																	}

																	printf("\n\t childExistFl: %d",childExistFl); fflush(stdout);
																	if (childExistFl==0)
																	{
																		printf("\n ...---adding child from colour bom and not present in non-col bom.....[%s]=[%d]",NCChild,NClrQty); fflush(stdout);
																		fprintf(fpCLLog,"\n ...---adding child from colour bom and not present in non-col bom.....[%s]=[%d]",NCChild,NClrQty); fflush(fpCLLog);

																		if(NClrQty==0)
																		{
																			if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																			printf("\n    if==>1-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(stdout);
																			fprintf(fpCLLog,"\n    if==>1-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(fpCLLog);
																		}
																		else
																		{
																			for (k2=0;k2<NClrQty;k2++ )
																			{
																				if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																				printf("\n    else==>1-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(stdout);
																				fprintf(fpCLLog,"\n    else==>1-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(fpCLLog);
																			}
																		}
																	}
																}
																else ////Comp_code not like CCA% , VEHICLE, TPLS%
																{
																	char *ClrChildItem = NULL;
																	logical checkout2;
																	int CompCodeClrSrlMatchFlag = 0;
																	t5ClSrl = (char*) malloc(50);

																	t5ClSrl = GetColourSrlFrmSchmCompCodes(CmpCodesOfClrSchm,CmpCnt,NCChildCompCode);
																	printf("\n  CL-B=t5ClSrl from function: %s",t5ClSrl); fflush(stdout);
																	fprintf(fpCLLog,"\n  CL=t5ClSrl from function: %s",t5ClSrl); fflush(fpCLLog);

																	if ((t5ClSrl!=NULL) && (strlen(t5ClSrl)>0))
																	{
																		if(tc_strstr(t5ClSrl,";")!=NULL) {
																			Suffix =  strtok(t5ClSrl,";");
																			ColourID  =  strtok(NULL,";");
																		}
																		else {
																			Suffix =  strtok(t5ClSrl,",");
																			ColourID  =  strtok(NULL,",");
																		}
																		printf("\n\t   CL=Suffix-->: %s  ColourID: %s ",Suffix,ColourID); fflush(stdout);
																		fprintf(fpCLLog,"\n\t   CL=Suffix-->: %s  ColourID: %s ",Suffix,ColourID); fflush(fpCLLog);


																		if(tc_strcmp(NCChildPartType,"G")==0)
																		{
																			printf("\n  In GroupID if condition===\n"); fflush(stdout);
																			//ResponseStr = NewUniqGroupIDNum();
																			//printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
																			//
																			//ClrChildItem = NULL;
																			//ClrChildItem=(char *) MEM_alloc(25);
																			//strcpy(ClrChildItem,"");
																			//strcat(ClrChildItem,ResponseStr);
																			//printf("\n\t   Colour Part for Group ID---->%s\n",ClrChildItem); fflush(stdout);
																			fflush(stdout);
																		}
																		else
																		{
																			ClrChildItem=(char *) MEM_alloc(25);
																			strcpy(ClrChildItem,"");
																			strcpy(ClrChildItem,NCChild);
																			strcat(ClrChildItem,Suffix);
																		}
																		printf("\n\t   Child_ColPartNo: %s ",ClrChildItem); fflush(stdout);

																		if ( (strlen(ClrChildItem)>0) && (ClrPartQryTag!=NULLTAG) )
																		{
																			CompCodeClrSrlMatchFlag = 1;
																			//printf("\n\t   CM=Found Query 'ClrPart' ClrPartQryTag \n"); fflush(stdout);
																			valuesClrPrt[0] = ClrChildItem;
																			if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &n_ClrChild_tags, &ClrChildTags));
																			printf("\t ClrPart_QryCount------> %d ",n_ClrChild_tags);fflush(stdout);

																			if(ITEM_ask_latest_rev(NCChildItemTag2,&NClrItemRevTag)!=ITK_ok)PrintErrorStack();

																			if (n_ClrChild_tags==0)
																			{
																				tag_t ColChilditemMstr = NULLTAG;
																				tag_t ColChilditemRevTag = NULLTAG;

																				if(NClrItemRevTag!=NULLTAG)
																				{
																					ColChilditemRevTag = ColorPartCreate_CL(NClrItemRevTag,NCChild,NCChildCompCode,SchmRefTag, CmpCodesOfClrSchm, CmpCnt, SchemeNm, SchemeRev,CLTaskDmlTag);
																					
																					if(ColChilditemRevTag!=NULLTAG)
																					{
																						if(AOM_ask_value_string(ColChilditemRevTag, "item_id", &clr_item_id)!=ITK_ok)PrintErrorStack();
																						printf("\n\t B--clr_item_id: %s",clr_item_id); fflush(stdout);

																						if(ITEM_find_item(clr_item_id,&ColChilditemMstr)!=ITK_ok)PrintErrorStack();

																						//if(ITEM_ask_item_of_rev(ColChilditemRevTag, &ColChilditemMstr)!=ITK_ok)PrintErrorStack();
																					}
																				}

																				if(ColChilditemMstr != NULLTAG)
																				{
																					if(NClrQty==0)
																					{
																						if(PS_create_occurrences(clrbvrTag, ColChilditemMstr, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																						printf("\n\t if==3-->PS_create_occurrences successfully in PSE for Non-Colors-------> "); fflush(stdout);
																						fprintf(fpCLLog,"\n\t if==3-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(fpCLLog);
																					}
																					else
																					{
																						for (p2=0;p2<NClrQty ;p2++ )
																						{
																							if(PS_create_occurrences(clrbvrTag, ColChilditemMstr, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																							printf("\n\t else==3-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors-------> ",p2); fflush(stdout);
																							fprintf(fpCLLog,"\n\t else==3-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																						}
																					}
																					if(AOM_save_without_extensions(clrbvrTag)!=ITK_ok)PrintErrorStack();
																				}
																				else
																				{
																					printf("\n\t else==ColChilditemRevTag is not found created hence not added to BVR ?????? [%s]",ClrChildItem); fflush(stdout);
																					fprintf(fpCLLog,"\n\t else==ColChilditemRevTag is not found created hence not added to BVR ?????? [%s]",ClrChildItem); fflush(fpCLLog);
																				}
																			}
																			else
																			{
																				printf("\nCL=ClrChildItem: %s Already present in PLM-TCUA, hence no need to create....Adding under ClrAssy BVR..\n",ClrChildItem);fflush(stdout);
																				fprintf(fpCLLog,"\nCL=ClrChildItem: %s Already present in PLM-TCUA, hence no need to create....Adding under ClrAssy BVR..\n",ClrChildItem);fflush(fpCLLog);
																				if(NClrQty==0)
																				{
																					if(PS_create_occurrences(clrbvrTag, ClrChildTags[0], NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																					printf("\n\t if==4-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(stdout);
																					fprintf(fpCLLog,"\n\t if==4-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(fpCLLog);
																				}
																				else
																				{
																					for (p2=0;p2<NClrQty ;p2++ )
																					{
																						if(PS_create_occurrences(clrbvrTag, ClrChildTags[0], NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																						printf("\n\t else==4-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																						fprintf(fpCLLog,"\n\t else==4-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																					}
																				}
																				if(AOM_save_without_extensions(clrbvrTag)!=ITK_ok)PrintErrorStack();
																			}
																		}
																		else
																		{
																			printf("\t -->Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....??????\n"); fflush(stdout);
																			fprintf(fpCLLog,"\t -->Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....??????\n"); fflush(fpCLLog);
																		}
																	}

																	if (CompCodeClrSrlMatchFlag==0)
																	{
																		printf("\n\n\t ---Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(stdout);
																		fprintf(fpCLLog,"\n\n\t ---Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(fpCLLog);
																		fprintf(fpCLErrLog,"\n Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(fpCLErrLog);

																		if(ITEM_find_item(NCChild,&NCChildItemTag2)!=ITK_ok)PrintErrorStack();

																		if(NClrQty==0)
																		{
																			if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																			printf("\n\t if==5-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(stdout);
																			fprintf(fpCLLog,"\n\t if==5-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(fpCLLog);
																		}
																		else
																		{
																			for (p2=0;p2<NClrQty ;p2++ )
																			{
																				if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																				printf("\n\n\t   else==5-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																				fprintf(fpCLLog,"\n\n\t   else==5-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																			}
																		}
																		if(AOM_save_without_extensions(clrbvrTag)!=ITK_ok)PrintErrorStack();
																	}
																}
															}
															else if(tc_strcmp(ChildColInd,"")==0)
															{
																printf("\t ---child ColInd==> NULL \n"); fflush(stdout);
																fprintf(fpCLLog,"\t ---child ColInd==> NULL \n"); fflush(fpCLLog);
																if(ITEM_find_item(NCChild,&NCChildItemTag2)!=ITK_ok)PrintErrorStack();
																if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
															}
														} //end of ELSE condn (NCChildItemTag2!=NULLTAG)
														if(AOM_save_without_extensions(clrbvrTag)!=ITK_ok)PrintErrorStack();
													} // end of for loop NonClrChildCnt

													printf("\n\t ChildColRevTag--------------------> rev-Colour bvr [n_lines1]: %d \n",n_lines1); fflush(stdout);
													fprintf(fpCLLog,"\n\t ChildColRevTag-------------------->\n"); fflush(fpCLLog);
													if ((ChildColRevTag!=NULLTAG) && (n_lines1 >0))
													{
														int CLChildExistFl=0;
														int k5=0;
														for (k5=0; k5<n_lines1; k5++ )
														{
															CLChildExistFl=0;
															if(clrPartObject) clrPartObject=NULLTAG;
															clrPartObject=lines1[k5];

															if(AOM_ask_value_string(clrPartObject, "bl_item_item_id", &t5_clr_item_id)!=ITK_ok)PrintErrorStack();
															printf("\n\t k5: [%d]  t5_clr_item_id ===> :: %s",k5,t5_clr_item_id); fflush(stdout);

															if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
															if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_PrtCatCode", &ClrCompCode)!=ITK_ok)PrintErrorStack();
															printf("\n\t ColourIndC ===> :: %s  ClrCompCode:: %s ",ColourIndC,ClrCompCode); fflush(stdout);

															if(((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0)) && ((tc_strstr(ClrCompCode,"CCA")!=NULL)||(tc_strstr(ClrCompCode,"VEHICLE")!=NULL)||(tc_strstr(ClrCompCode,"TPL")!=NULL)))
															{
																int nk3=0;
																char *NCChild2=NULL;

																for (nk3=0;nk3<no_bom_lines ;nk3++ )
																{
																	if(Childobject) Childobject=NULLTAG;
																	Childobject=child_bom_lines[nk3];

																	if(AOM_ask_value_string(Childobject, "bl_item_item_id", &NCChild2)!=ITK_ok)PrintErrorStack();
																	printf("\n\t\t R--NCChild2: %s",NCChild2); fflush(stdout);
																	fprintf(fpCLLog,"\n\t B--NCChild2: %s",NCChild2); fflush(fpCLLog);

																	if(AOM_ask_value_string(Childobject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
																	printf(" ColourIndC: %s",ColourIndC); fflush(stdout);
																	fprintf(fpCLLog," ColourIndC: %s",ColourIndC); fflush(fpCLLog);

																	if((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0))
																	{
																		if (strstr(t5_clr_item_id,NCChild2)!=NULL)
																		{
																			CLChildExistFl=1;

																			break;
																		}
																	}
																}
																printf(" CLChildExistFl: %d ",CLChildExistFl); fflush(stdout);
																if (CLChildExistFl==1)
																{
																	//if(BOM_line_ask_attribute_string(Childobject,QuantityAttrId, &CCChildQty)!=ITK_ok)PrintErrorStack();
																			ifail = AOM_UIF_ask_value(Childobject,"bl_quantity",&CCChildQty);

																	CClrQty=atoi(CCChildQty);

																	if(ITEM_find_item(t5_clr_item_id, &CCChildItemTag)!=ITK_ok)PrintErrorStack();

																	if(CClrQty==0)
																	{
																		if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																		printf("\n\t if==6-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(stdout);
																		fprintf(fpCLLog,"\n\t if==6-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(fpCLLog);
																	}
																	else
																	{
																		for (k2=0;k2<CClrQty;k2++ )
																		{
																			if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																			printf("\n    6-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(stdout);
																			fprintf(fpCLLog,"\n    6-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(fpCLLog);
																		}
																	}
																} //End of condn if (CLChildExistFl==1)
															} //if condn end
														}
													}
													//--END--Adding Childs under New Colour Assy bvr-----------
												}
												printf("\n B==After clrbvrTag creation --- ");fflush(stdout);
												fprintf(fpCLLog,"\n B==After clrbvrTag creation --- ");fflush(fpCLLog);
												if(AOM_save_without_extensions(clrbvrTag)!=ITK_ok)PrintErrorStack();
												if(AOM_refresh(clrbvrTag,FALSE)!=ITK_ok)PrintErrorStack();
												printf("\t clrbvrTag is saved...");fflush(stdout);
												fprintf(fpCLLog,"\t clrbvrTag is saved...");fflush(fpCLLog);

											}//if(NewColorRevTag!=NULLTAG)


										} //if (checkout==0)



									}  //else end revise logic
								}
							} //if (ColChildMatch==1)

							for (j = 0; j < no_bom_lines; j++)
							{
								childbomline=child_bom_lines[j];

								if( AOM_ask_value_string(childbomline,"bl_item_item_id",&ChildItem)!=ITK_ok);

								//if( AOM_ask_value_string(childbomline,"bl_T5_ClrPartRevision_t5_ColourInd",&ColourInd)!=ITK_ok);  //uadev
								if( AOM_ask_value_string(childbomline,"bl_Design Revision_t5_ColourInd",&ChildColInd)!=ITK_ok);		//UAPROD

								//if( AOM_ask_value_string(childbomline,"bl_T5_ClrPartRevision_t5_PrtCatCode",&CompCode)!=ITK_ok);  //uadev
								if( AOM_ask_value_string(childbomline,"bl_Design Revision_t5_PrtCatCode",&ChildCompCode)!=ITK_ok);	//UAPROD

								printf("\n\n Child:::::[%s]    ColourInd:[%s]  CompCode:[%s]  ",ChildItem, ChildColInd, ChildCompCode); fflush(stdout);

								//if ((tc_strcmp(ChildColInd,"Y")==0) && (strlen(ChildCompCode)>0) && ((tc_strstr(ChildCompCode,"CCA")==NULL)||(tc_strstr(ChildCompCode,"VEHICLE")==NULL)||(tc_strstr(ChildCompCode,"TPL")==NULL)))
								if ((tc_strcmp(ChildColInd,"Y")==0) && (strlen(ChildCompCode)>0) && ((tc_strstr(ChildCompCode,"CCA")==NULL)&&(tc_strstr(ChildCompCode,"VEHICLE")==NULL)&&(tc_strstr(ChildCompCode,"TPL")==NULL)))
								{
									printf(" ---> Calling expansion funtion..."); fflush(stdout);
									ValMultiLvlBomForScheme_CL(childbomline, SchmRefTag, CmpCodesOfClrSchm, CmpCnt, SchemeNm, SchemeRev,CLTaskDmlTag);
								}
							}
						}
					}

					if (no_bom_lines > 0)
					{
						MEM_free (child_bom_lines);
					}
				}
			}

			MEM_free (name);
		}
		int ValColAndNonColBomForRevise_CL(tag_t NonClrRev,tag_t Clrrev,int ColRevRlzStatus, tag_t ColSchmRevTag)
		{
			int ifail = ITK_ok;
			int no_bom_linesN, jnc=0;
			int no_bom_linesC, jc=0;
			int FlagchildPresentInBom=0;
			int FlagBomDiff=0;
			int Cmpcount2, k2, CompCodeMatchFlag=0;

			tag_t windowNC=NULLTAG;
			tag_t windowClr=NULLTAG;
			tag_t rule = NULLTAG;
			tag_t ruleClr = NULLTAG;
			tag_t top_lineNC = NULLTAG;
			tag_t top_lineClr = NULLTAG;
			tag_t CmpCodeObj2 = NULLTAG;

			tag_t *child_bom_linesNC = NULLTAG;
			tag_t *child_bom_linesC = NULLTAG;
			tag_t *CmpCodeOfClrScheme2 = NULLTAG;

			char *child_item_idN = NULL;
			char *child_item_idN2 = NULL;
			char *ChildRevSeqN = NULL;
			char *ChildColIndN = NULL;
			char *child_item_idC = NULL;
			char *ChildRevSeqC = NULL;
			char *ChildColIndC = NULL;
			char *CmpCodeCmp2 = NULL;
			char *t5ClSrl = NULL;
			char *Suffix = NULL;
			char *ColourID = NULL;
			char *ChildNCCompCode = NULL;
			child_item_idN2=(char *) MEM_alloc(50);

			//t5ClSrl = (char*) malloc(50);
			
			ifail = BOM_create_window (&windowNC);
			ifail = BOM_create_window (&windowClr);
			ifail = CFM_find("ERC Review And Above", &rule);	//Non-colour
			ifail = BOM_set_window_config_rule(windowNC, rule);	//Non-colour
			ifail = BOM_set_window_top_line(windowNC, null_tag, NonClrRev, null_tag, &top_lineNC);
			ifail = BOM_window_show_suppressed(windowNC);
			ifail = BOM_line_ask_child_lines(top_lineNC, &no_bom_linesN, &child_bom_linesNC);
			//colour
			if (ColRevRlzStatus==1)
			{
				ifail = CFM_find( "Color ERC release and above", &ruleClr );//colour
			}
			else
			{
				ifail = CFM_find( "Color ERC Review and above", &ruleClr );//colour
			}
			ifail = BOM_set_window_config_rule( windowClr, ruleClr ); 
			ifail = BOM_set_window_top_line (windowClr, null_tag, Clrrev, null_tag, &top_lineClr);
			ifail = BOM_window_show_suppressed ( windowClr );
			ifail = BOM_line_ask_child_lines (top_lineClr, &no_bom_linesC, &child_bom_linesC);
			
			printf("\n\t no_bom_linesN: %d   no_bom_linesC: %d",no_bom_linesN,no_bom_linesC);fflush(stdout);
			FlagBomDiff=0;
			for (jnc = 0; jnc < no_bom_linesN; jnc++) //Non-Colour Bom loop
			{
				ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_item_item_id",&child_item_idN);
				if (strstr(child_item_idN,"_")!=NULL)
				{
					continue;
				}
				if (strcmp(subString(child_item_idN,0,1),"G")==0)
				{
					continue;
				}

				ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_rev_item_revision_id",&ChildRevSeqN);
				//ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndN);
				ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_Design Revision_t5_ColourInd",&ChildColIndN);

				printf("\n\t A--jnc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jnc,child_item_idN,ChildRevSeqN,ChildColIndN);fflush(stdout);

				strcpy(child_item_idN2,"");
				tc_strcpy(child_item_idN2,child_item_idN);
				CompCodeMatchFlag==0;
				/*if (strcmp(ChildColIndN,"Y")==0)
				{
					ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_PrtCatCode",&ChildNCCompCode);
					if (SchmWithCmpcdRel != NULLTAG)
					{
						ifail = GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel, &Cmpcount2, &CmpCodeOfClrScheme2);
						printf("\n\t\t MultilevelExpantion Comp Code count from Color Scheme is : %d",Cmpcount2); fflush(stdout);
						if(Cmpcount2 > 0)
						{
							for (k2=0;k2<Cmpcount2 ;k2++ )
							{
								if(CmpCodeObj2) CmpCodeObj2=NULLTAG;
								CmpCodeObj2=CmpCodeOfClrScheme2[k2];
								ifail = AOM_ask_value_string(CmpCodeObj2, "t5_PrtCatCode", &CmpCodeCmp2 );
								printf("\n\t\t CmpCodeCmp2 & ChildNCCompCode status--> : [%s]==[%s]",CmpCodeCmp2,ChildNCCompCode); fflush(stdout);
								if(tc_strcmp(ChildNCCompCode,CmpCodeCmp2)==0)
								{
									printf(" -- Match Foun compcode "); fflush(stdout);
									CompCodeMatchFlag=1;
									ifail = AOM_ask_value_string(CmpCodeObj2, "t5_ClSrl", &t5ClSrl );
									Suffix =  strtok(t5ClSrl,";");
									ColourID  =  strtok(NULL,";");
									
									tc_strcat(child_item_idN2,Suffix);

									break;
								}
							}
						}
					}
				}*/
					FlagchildPresentInBom=0;
					for (jc = 0; jc < no_bom_linesC; jc++)
					{
						//ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndC);
						ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_Design Revision_t5_ColourInd",&ChildColIndC);

						//if ((strcmp(ChildColIndC,"Y")==0)||(strcmp(ChildColIndC,"C")==0))
						//{
							ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_item_item_id",&child_item_idC);
							if (strstr(child_item_idC,"_")!=NULL)
							{
								continue;
							}
							if (strcmp(subString(child_item_idC,0,1),"G")==0)
							{
								continue;
							}

							ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_rev_item_revision_id",&ChildRevSeqC);

							printf("\n\t A--jc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jc,child_item_idC,ChildRevSeqC,ChildColIndC);fflush(stdout);
							
							//if ((strstr(child_item_idC,child_item_idN)!=NULL) && ((strcmp(ChildColIndC,"C")==0)||(strcmp(ChildColIndC,"N")==0)||(strcmp(ChildColIndC,"Y")==0)))
							//if (strstr(child_item_idC,child_item_idN)!=NULL)
							
							printf("\n\t\t child_item_idC: %s  child_item_idN: %s   child_item_idN2: %s  ",child_item_idC,child_item_idN,child_item_idN2);fflush(stdout);
							if (strstr(child_item_idC,child_item_idN)!=NULL)
							{
								//if (strcmp(child_item_idC,child_item_idN2)==0)
								if (strstr(child_item_idC,child_item_idN2)!=NULL)
								{
									FlagchildPresentInBom=1;
									break;
								}
							}
						//}
					}
					if (FlagchildPresentInBom==0)
					{
						FlagBomDiff++;
					}
					printf(" -- FlagchildPresentInBom: %d  FlagBomDiff: %d",FlagchildPresentInBom,FlagBomDiff); fflush(stdout);
				//}
			}
			printf("\n\t A--FlagBomDiff: %d",FlagBomDiff);fflush(stdout);
			if (FlagBomDiff==0)
			{
				for (jc = 0; jc < no_bom_linesC; jc++) //Colour Bom loop
				{
					ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndC);
					ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_item_item_id",&child_item_idC);
					if (strstr(child_item_idC,"_")!=NULL)
					{
						continue;
					}
					if (strcmp(subString(child_item_idC,0,1),"G")==0)
					{
						continue;
					}

					ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_rev_item_revision_id",&ChildRevSeqC);
					printf("\n\t B--jc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jc,child_item_idC,ChildRevSeqC,ChildColIndC);fflush(stdout);
					
					FlagchildPresentInBom=0;
					for (jnc = 0; jnc < no_bom_linesN; jnc++)
					{
						ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_item_item_id",&child_item_idN);
						if (strstr(child_item_idN,"_")!=NULL)
						{
							continue;
						}
						if (strcmp(subString(child_item_idN,0,1),"G")==0)
						{
							continue;
						}

						ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_rev_item_revision_id",&ChildRevSeqN);
						ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndN);

						printf("\n\t B--jnc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jnc,child_item_idN,ChildRevSeqN,ChildColIndN);fflush(stdout);

						if (strstr(child_item_idC,child_item_idN)!=NULL)
						{
							FlagchildPresentInBom=1;
							break;
						}

					}
					if (FlagchildPresentInBom==0)
					{
						FlagBomDiff++;
					}
				}
			}
			printf("\n\t In ValColAndNonColBomAttrForRevise function,  FlagBomDiff: %d",FlagBomDiff);fflush(stdout);

			/*if (FlagBomDiff==0)
			{
				if (SchmWithCmpcdRel != NULLTAG)
				{
					ifail = GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel, &Cmpcount2, &CmpCodeOfClrScheme2);
					printf("\n\t\t MultilevelExpantion Comp Code count from Color Scheme is : %d\n\n",Cmpcount2); fflush(stdout);
					if(Cmpcount2 > 0)
					{
						for (k2=0;k2<Cmpcount2 ;k2++ )
						{
							if(CmpCodeObj2) CmpCodeObj2=NULLTAG;
							CmpCodeObj2=CmpCodeOfClrScheme2[k2];
							ifail = AOM_ask_value_string(CmpCodeObj2, "t5_PrtCatCode", &CmpCodeCmp2 );
							printf("\n CmpCodeCmp2 & t5PrtCatCd status--> : %s-%s\n",CmpCodeCmp2,t5PrtCatCd); fflush(stdout);
							//if(tc_strcmp(t5PrtCatCd,CmpCodeCmp2)==0)
							//{
							//	ClrGrpPartPresentFlag=0;
							//	ifail = AOM_ask_value_string(CmpCodeObj, "t5_ClSrl", &t5ClSrl );
							//	Suffix =  strtok(t5ClSrl,";");
							//	ColourID  =  strtok(NULL,";");
							//}
						}
					}
				}
			}*/

			return FlagBomDiff;
		}

		int ProcessColourScheme2(char *ColPartNo, tag_t latestClrRev, char *ClrschemeStr, tag_t RefschmTag)
		{
			int resultColSchm, co = 0;
			int status_count, rs, RlzRevFlag = 0;
			int SchmRevsCnt, c2 = 0;
			int Cmpcount, g1 = 0;
			int SchmMatchFlag=0;

			char *qry_entries4[1] = {"ID"};
			char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));

			char *qry_entries5[1] = {"Colour ID"};
			char **valuesColID = (char **) MEM_alloc(1 * sizeof(char *));

			char *ColPrtSrl = NULL;
			char *CompCode = NULL;
			char *ColSchm_name = NULL;
			char *ColSchmRlzSt = NULL;
			char *t5objectStr = NULL;
			char *SchmCmpCode = NULL;
			char *t5ClSrl = NULL;
			char *Suffix = NULL;
			char *ColourID = NULL;
			//char *SchmDesc = NULL;
			//char *SchmClrSrl = NULL;
			//char *SchmSuffix = NULL;
			//char *SchmColourID = NULL;

			tag_t *ColSchme_tags = NULLTAG;
			tag_t *SchmRevisions = NULLTAG;
			tag_t *relStatus_list = NULLTAG;
			tag_t *CmpCodeOfClrScheme = NULLTAG;

			tag_t ColorSchemetag = NULLTAG;
			tag_t ColSchmRevTag = NULLTAG;
			tag_t ColSchmTypeTag = NULLTAG;
			tag_t CmpCodeObjTag = NULLTAG;

			ColPrtSrl = (char *) MEM_alloc(3 * sizeof(char));

			ColPrtSrl=subString(ColPartNo,strlen(ColPartNo)-2,strlen(ColPartNo));

			printf("\n ProcessColourScheme2==ColPartNo: %s   strlen(ColPartNo): %d   ColPrtSrl: [%s]",ColPartNo,strlen(ColPartNo),ColPrtSrl);fflush(stdout);
			fprintf(fpCLLog,"\n ProcessColourScheme2==ColPartNo: %s   strlen(ColPartNo): %d   ColPrtSrl: [%s]",ColPartNo,strlen(ColPartNo),ColPrtSrl);fflush(fpCLLog);

			if( AOM_ask_value_string(latestClrRev,"t5_PrtCatCode",&CompCode)!=ITK_ok);
			printf(" CompCode: [%s]",CompCode);fflush(stdout);
			fprintf(fpCLLog," CompCode: [%s]",CompCode);fflush(fpCLLog);

			/*if (RefschmTag==NULLTAG)
			{
				valuesColSchm[0] = ClrschemeStr ;
				if(QRY_execute(SchmqueryTag, 1, qry_entries4, valuesColSchm, &resultColSchm, &ColSchme_tags));
				printf("\n resultColSchm count is-------->  : %d",resultColSchm);fflush(stdout);
				if (resultColSchm > 0)
				{
					for(co = 0; co < resultColSchm; co++)
					{
						printf("\n co: %d ",co);fflush(stdout);

						ColorSchemetag = ColSchme_tags[co];

						//if(TCTYPE_ask_object_type(ColorSchemetag,&ColSchmTypeTag)!=ITK_ok);
						//if(TCTYPE_ask_name2(ColSchmTypeTag,ColSchm_name)!=ITK_ok);
						//printf("\t ColSchm_name name------> %s",ColSchm_name);fflush(stdout);

						if(ITEM_ask_latest_rev(ColorSchemetag , &ColSchmRevTag)!=ITK_ok);
						if(AOM_ask_value_string(ColSchmRevTag, "object_string", &t5objectStr)!=ITK_ok);
						printf("\t t5objectStr: %s",t5objectStr); fflush(stdout);
						
						//int vschmFlag=0;
						//if ((strstr(t5objectStr,"CLRSCM-X4/19/0001")!=NULL) || (strstr(t5objectStr,"CLRSCM-X4/19/0002")!=NULL))
						//{
						//	vschmFlag=1;
						//}
						//if (vschmFlag==0)
						//{
						//	continue;
						//}

						if(WSOM_ask_release_status_list(ColSchmRevTag, &status_count, &relStatus_list)!=ITK_ok);
						printf("\t status_count:: %d",status_count); fflush(stdout);
						if(status_count > 0)
						{
							printf("\t ColSchm Release status:");fflush(stdout);
							for(rs = 0; rs < status_count; rs++)
							{
								if(AOM_ask_name(relStatus_list[rs], &ColSchmRlzSt)==ITK_ok)
								printf("   %s ", ColSchmRlzSt);fflush(stdout);
								if ((tc_strcmp(ColSchmRlzSt,"T5_LcsErcRlzd")==0) || (tc_strcmp(ColSchmRlzSt,"ERC Released")==0) )
								{
									RlzRevFlag=1;
									break;
								}
								else
								{
									if(ITEM_list_all_revs (ColorSchemetag, &SchmRevsCnt, &SchmRevisions));
								}
							}
						}
						else
						{
							printf("\t ----No Release status on ColSchm, hence skipping ...");fflush(stdout);
							continue;
						}
					}
				}
			}
			else
			{*/
				ColSchmRevTag=RefschmTag;
			//}

			if ((SchmWithCmpcdRel!=NULLTAG) && (ColSchmRevTag!=NULLTAG))
			{
				if(GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok);
				printf("\n\n Comp Code Cmpcount for Color Scheme: %d \n",Cmpcount); fflush(stdout);
				fprintf(fpCLLog,"\n\n Comp Code Cmpcount for Color Scheme: %d \n",Cmpcount); fflush(fpCLLog);

				if(Cmpcount > 0)
				{
					//if(AOM_ask_value_string(ColSchmRevTag, "t5_ClSchmDesc", &SchmDesc)!=ITK_ok);
					//if(AOM_ask_value_string(ColSchmRevTag, "t5_ClSrl", &SchmClrSrl)!=ITK_ok);
					//
					//if(tc_strstr(SchmClrSrl,";")!=NULL)
					//{															
					//	SchmSuffix =  strtok(SchmClrSrl,";");
					//	SchmColourID  =  strtok(NULL,";");
					//}
					//else
					//{
					//	SchmSuffix =  strtok(SchmClrSrl,",");
					//	SchmColourID  =  strtok(NULL,",");
					//}
					//printf("\n\n Comp Code Cmpcount for Color Scheme: %d   SchmColourID: [%s]\n",Cmpcount,SchmColourID); fflush(stdout);
					//fprintf(fpCLLog,"\n\n Comp Code Cmpcount for Color Scheme: %d   SchmColourID: [%s]\n",Cmpcount,SchmColourID); fflush(fpCLLog);
					
					printf("\n\n Comp Code Cmpcount for Color Scheme: %d \n",Cmpcount); fflush(stdout);
					fprintf(fpCLLog,"\n\n Comp Code Cmpcount for Color Scheme: %d \n",Cmpcount); fflush(fpCLLog);

					//if (strlen(SchmColourID)>0)
					//{
						for(g1=0;g1<Cmpcount;g1++ )
						{
							if(CmpCodeObjTag) CmpCodeObjTag=NULLTAG;

							CmpCodeObjTag=CmpCodeOfClrScheme[g1];

							if(AOM_ask_value_string(CmpCodeObjTag, "t5_PrtCatCode", &SchmCmpCode )!=ITK_ok);
							if(AOM_ask_value_string(CmpCodeObjTag, "t5_ClSrl", &t5ClSrl )!=ITK_ok);
							
							if(tc_strstr(t5ClSrl,";")!=NULL)
							{															
								Suffix =  strtok(t5ClSrl,";");
								ColourID  =  strtok(NULL,";");
								//printf("\n\t\t CM=Suffix --> : %s",Suffix); fflush(stdout);
								//printf("\n\t\t CM=ColourID --> : %s",ColourID); fflush(stdout);
							}
							else
							{
								Suffix =  strtok(t5ClSrl,",");
								ColourID  =  strtok(NULL,",");
								//printf("\n\t\t CM=Suffix --> : %s",Suffix); fflush(stdout);
								//printf("\n\t\t CM=ColourID --> : %s",ColourID); fflush(stdout);
							}

							printf("\n%s, %s, %s,",SchmCmpCode,Suffix,ColourID); fflush(stdout);
							fprintf(fpCLLog,"\n%s, %s, %s,",SchmCmpCode,Suffix,ColourID); fflush(fpCLLog);
							if ((strcmp(CompCode,SchmCmpCode)==0) && (strcmp(ColPrtSrl,Suffix)==0))
							{
								SchmMatchFlag=1;
								break;
							}
						}
					//} //End of if (strlen(SchmColourID)>0)
				}
				else
				{
					printf("\n\t\t CL=Comp Code are not attached to Color Scheme : %s , hence skipping ??? \n\n",ClrschemeStr); fflush(stdout);
					fprintf(fpCLLog,"\n\t\t CL=Comp Code are not attached to Color Scheme : %s , hence skipping ??? \n\n",ClrschemeStr); fflush(fpCLLog);
				}
			}
			else
			{
				printf("\n\t\t CL=In Else, hence skipping ??? \n\n"); fflush(stdout);
				fprintf(fpCLLog,"\n\t\t CL=In Else, hence skipping ??? \n\n"); fflush(fpCLLog);
			}

			return SchmMatchFlag;
		}
					  
		int tm_ProcessColourPartCL(int taskCnt, tag_t *DmlTaskTags, tag_t Dml_task, int NCAssyChildFlag, tag_t NonClrPartTag, char *NewColourPart, char *DMLProject)
		{
			int co, rs, RlzRevFlag=0;
			int status_count=0;
			int RlzStatusCnt , ss =0;
			int n_ClrPrt_tags, ColRlzStatusCnt, ss2, n_ClrChild_tags=0;
			int n_attchs , st = 0;
			int no_bom_lines, j = 0;
			int ncItem_count=0 , ik=0 , relRev2Flag = 0;
			int NonClrChildCnt=0, nc=0, NonClrPrevChildCnt, ncp = 0;
			int childNotExitFlag=0;
			int SchmRevCnt=0, sc=0, SchmRevRlzFlag=0;
			int ClrCount=0, zp=0, ColRlzRevFlag, zp1 =0;
			int Cmpcount=0, g1=0, MatchColSchemeFlag = 0;
			int nc2=0, NClrQty=0, p2=0, nc3=0;
			int colPrtCnt=0;

			tag_t *ClrPrtTags = NULLTAG;
			tag_t *Col_Rlz_St_list = NULLTAG;
			tag_t *sec_objects = NULLTAG;
			tag_t *relStatus_list = NULLTAG;
			tag_t *child_bom_lines = NULLTAG;
			tag_t *ncRev_list = NULLTAG;
			tag_t *NonClrChilds = NULLTAG;
			tag_t *NonClrPrevChilds = NULLTAG;
			tag_t *SchmRev_list = NULLTAG;
			tag_t *ClrPart_tag = NULLTAG;
			tag_t *CmpCodeOfClrScheme = NULLTAG;
			tag_t *ClrChildTags = NULLTAG;
			tag_t *ColPrtUniqTags = NULLTAG;

			tag_t NonClrItemMstrTag = NULLTAG;
			tag_t NonClrItemRevTag = NULLTAG;
			tag_t ColorSchemetag = NULLTAG;
			tag_t ColSchmTypeTag = NULLTAG;
			tag_t ColSchmRevTag = NULLTAG;
			tag_t CmpCodeObjTag = NULLTAG;
			tag_t ColItemTag = NULLTAG;
			tag_t ColorRevTag = NULLTAG;
			tag_t NewColorRevTag = NULLTAG;
			tag_t ReltnExist = NULLTAG;
			tag_t reltask = NULLTAG;
			tag_t secObjTypeTag	= NULLTAG;
			tag_t top_line = NULLTAG;
			tag_t ColChilditemMstr = NULLTAG;
			tag_t ColChilditemRev = NULLTAG;
			tag_t Child_item_revTag = NULLTAG;
			tag_t tPrevRelationExist = NULLTAG;
			tag_t tRelationExist = NULLTAG;
			tag_t tRelationExist1 = NULLTAG;
			tag_t Rel_task = NULLTAG;
			tag_t NClrItemMstrTag = NULLTAG;
			tag_t NonClrPrtPrevRevTag = NULLTAG;
			tag_t windowNonClr = NULLTAG;
			tag_t top_lineNonClr = NULLTAG;
			tag_t windowNonClrPrev = NULLTAG;
			tag_t top_lineNonClrPrev = NULLTAG;
			tag_t latestClrRev = NULLTAG;
			tag_t Childobject = NULLTAG;
			tag_t NClrChildobject = NULLTAG;
			tag_t NCChildItemTag = NULLTAG;
			tag_t ClrItemMstrTag = NULLTAG;
			tag_t ClrItemRevTag = NULLTAG;

			char* Part_no = NULL;
			char* Col_Ind = NULL;
			char* Comp_Code = NULL;
			char* PartType = NULL;
			char* RevSeqTmp = NULL;
			char* RevStr = NULL;
			char* SeqStr = NULL;
			char* LatestRlzSt = NULL;
			char* ColPartNo = NULL;
			char* ColPartRev = NULL;
			char* ColPrtRelSt = NULL;

			char *type_name2=NULL;

			char *Clrscheme = NULL;
			char *CpyClrscheme = NULL;
			char *ClSrlName=NULL;
			char *ClSuffix=NULL;
			char* SchmName=NULL;
			char* SchmRev=NULL;
			char* SchmRel_status=NULL;
			char *ColSchmRlzSt = NULL;
			char *SchmCmpCode = NULL;
			char *t5ClSrl = NULL;
			char *Suffix=NULL;
			char *ColourID=NULL;
			char *ColPrtLatestRlzSt=NULL;
			char *NewColPartRevSeq=NULL;
			char *ChildRevSeq = NULL;
			char *ChildColInd = NULL;
			char *Part_noLatest = NULL;
			char *RevSeqTmpLatest = NULL;
			char *ncPartno=NULL;
			char *ncPartRev=NULL;
			char *ncRel_status=NULL;
			char *NPrtLatestRlzSt=NULL;
			char *NCRevChild=NULL;
			char *NCPrevRevChild=NULL;
			char *NCChild = NULL;
			char *NCChildRevSeq = NULL;
			char *NCChildColInd = NULL;
			char *NCChildCompCode = NULL;
			char *NCChildQty = NULL;
			tag_t ruleRev = NULLTAG;

			char *NonClrChildSet=NULL;
			char *ClrAssySet=NULL;
			char *DMLNo=NULL;
			char *sTaskName=NULL;
			char *SchTok=NULL;
			char *govClassification=NULL;

			tag_t queryds = NULLTAG;
			char *qry_entriesds[1] = {"ID"};
			char **qry_valuesds = (char **) MEM_alloc(50 * sizeof(char *));
			int n_entries = 1;
			int TaskClSet =0;
			tag_t	*TaskClTag	= NULLTAG;

			char *qry_entries4[1] = {"ID"};
			char *qry_entries[1] = {"ID"};
			char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
			char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));
			char *ColSchm_name=NULL;

			NonClrChildSet = (char *) MEM_alloc(10000 * sizeof(char));
			DMLNo = (char *) MEM_alloc(20 * sizeof(char));
			t5ClSrl = (char*) malloc(50);

			if(AOM_ask_value_string(NonClrPartTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
			if(AOM_ask_value_string(NonClrPartTag,"item_revision_id",&RevSeqTmp)!=ITK_ok)PrintErrorStack();
			printf("\n\t Part_no: [%s,%s]",Part_no,RevSeqTmp); fflush(stdout);
			fprintf(fpCLLog,"\n\t Part_no: [%s,%s]",Part_no,RevSeqTmp); fflush(fpCLLog);

			if(AOM_ask_value_string(NonClrPartTag,"t5_ColourInd",&Col_Ind)!=ITK_ok)PrintErrorStack();
			printf("  Col_Ind: [%s]",Col_Ind);	fflush(stdout);
			fprintf(fpCLLog,"  Col_Ind: [%s]",Col_Ind);	fflush(fpCLLog);

			if(AOM_ask_value_string(NonClrPartTag,"t5_PrtCatCode",&Comp_Code)!=ITK_ok)PrintErrorStack();
			printf("  Comp_Code: [%s]",Comp_Code);	fflush(stdout);
			fprintf(fpCLLog,"  Comp_Code: [%s]",Comp_Code);	fflush(fpCLLog);

			if(AOM_ask_value_string(NonClrPartTag, "t5_PartType", &PartType)!=ITK_ok)PrintErrorStack();
			printf("  PartType: [%s]",PartType);	fflush(stdout);
			fprintf(fpCLLog,"  PartType: [%s]",PartType);	fflush(fpCLLog);

			if(ITEM_find_item(Part_no, &NonClrItemMstrTag)!=ITK_ok)PrintErrorStack();
			if(ITEM_ask_latest_rev(NonClrItemMstrTag,&NonClrItemRevTag)!=ITK_ok)PrintErrorStack();
			if(AOM_ask_value_string(NonClrItemRevTag,"item_id",&Part_noLatest)!=ITK_ok)PrintErrorStack();
			if(AOM_ask_value_string(NonClrItemRevTag,"item_revision_id",&RevSeqTmpLatest)!=ITK_ok)PrintErrorStack();

			if(tc_strcmp(Col_Ind,"Y")==0)
			{
				int n_entries11 =2;
				tag_t CntlObj_Qtag11 = NULLTAG;
				char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
				char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
				int CntrlObjCntCL=0;
				tag_t *qry_cntrlobj11= NULLTAG;

				if(QRY_find2("Control Objects...", &CntlObj_Qtag11)!=ITK_ok)PrintErrorStack();
				qry_values11[0] = "CLClrT";
				qry_values11[1] = "MultiLvlExp";
				if(QRY_execute(CntlObj_Qtag11, n_entries11, qry_entries11, qry_values11, &CntrlObjCntCL, &qry_cntrlobj11)!=ITK_ok)PrintErrorStack();
				printf("\n Control Object count for CL Task [CntrlObjCntCL: %d] \n",CntrlObjCntCL);fflush(stdout);


				if(WSOM_ask_release_status_list(NonClrPartTag, &RlzStatusCnt, &relStatus_list)!=ITK_ok)PrintErrorStack();
				printf("  RlzStatusCnt: %d",RlzStatusCnt);	fflush(stdout);
				fprintf(fpCLLog,"  RlzStatusCnt: %d",RlzStatusCnt);	fflush(fpCLLog);

				if (RlzStatusCnt > 0)
				{
					RlzRevFlag=0;
					for(ss=0; ss<RlzStatusCnt ; ss++)
					{
						if(AOM_ask_value_string(relStatus_list[ss],"object_name",&LatestRlzSt)!=ITK_ok)PrintErrorStack();
						printf("  LatestRlzSt: %s",LatestRlzSt);fflush(stdout);
						fprintf(fpCLLog,"  LatestRlzSt: %s",LatestRlzSt);fflush(fpCLLog);

						//if((tc_strcmp(LatestRlzSt,"ERC Released")==0) || (tc_strcmp(LatestRlzSt,"T5_LcsErcRlzd")==0))
						if(tc_strcmp(LatestRlzSt,"T5_LcsReview")==0)
						{
							RlzRevFlag=1;

							//Get child from BOM of latest released and previous released revision---START------
							tc_strcpy(NonClrChildSet,"");
							NonClrChildCnt=0;
							NonClrPrevChildCnt=0;
							NonClrPrtPrevRevTag=NULLTAG;

							if (tc_strstr(RevSeqTmp,"NR;")==NULL)	//Current Rev is NR hence not querying previous revision
							{
								if(ITEM_list_all_revs (NonClrItemMstrTag, &ncItem_count, &ncRev_list)!=ITK_ok)PrintErrorStack();
								printf("\n\t CL=ncItem_count::%d:\n\t", ncItem_count);fflush(stdout);
								fprintf(fpCLLog,"\n\t CL=ncItem_count::%d:\n\t", ncItem_count);fflush(fpCLLog);

								if(ncItem_count > 0)
								{
									//relRev2Flag = 0;
									for(ik=ncItem_count-1;ik>=0;ik--)
									{
										if(AOM_UIF_ask_value(ncRev_list[ik], "item_id", &ncPartno)!=ITK_ok)PrintErrorStack();
										if(AOM_UIF_ask_value(ncRev_list[ik], "item_revision_id", &ncPartRev)!=ITK_ok)PrintErrorStack();
										if(AOM_UIF_ask_value (ncRev_list[ik], "release_status_list", &ncRel_status)!=ITK_ok)PrintErrorStack();
										if((tc_strstr(ncRel_status,"ERC Released")!=NULL)||(tc_strstr(ncRel_status,"T5_LcsErcRlzd")!=NULL))
										{
											printf("  ncPartno=%s:%s:--", ncPartno,ncPartRev);fflush(stdout);
											fprintf(fpCLLog,"  ncPartno=%s:%s:--", ncPartno,ncPartRev);fflush(fpCLLog);
											NonClrPrtPrevRevTag=ncRev_list[ik];
											break;
										}
									}
								}
							}

							if(BOM_create_window(&windowNonClr)!=ITK_ok)PrintErrorStack();
							if(CFM_find("ERC Review And Above", &ruleRev)!=ITK_ok)PrintErrorStack();
							if(BOM_set_window_top_line(windowNonClr, null_tag, NonClrPartTag, null_tag, &top_lineNonClr)!=ITK_ok)PrintErrorStack();
							if(BOM_window_show_suppressed(windowNonClr)!=ITK_ok)PrintErrorStack();
							if(BOM_set_window_pack_all(windowNonClr, true)!=ITK_ok)PrintErrorStack();
							if(BOM_set_window_config_rule(windowNonClr, ruleRev)!=ITK_ok)PrintErrorStack();
							if(BOM_line_ask_child_lines(top_lineNonClr, &NonClrChildCnt, &NonClrChilds)!=ITK_ok)PrintErrorStack();

							if (NonClrPrtPrevRevTag!=NULLTAG)
							{
								if(BOM_create_window(&windowNonClrPrev)!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_top_line(windowNonClrPrev, null_tag, NonClrPrtPrevRevTag, null_tag, &top_lineNonClrPrev)!=ITK_ok)PrintErrorStack();
								if(BOM_window_show_suppressed(windowNonClrPrev)!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_pack_all(windowNonClrPrev, true)!=ITK_ok)PrintErrorStack();
								if(BOM_set_window_config_rule(windowNonClrPrev, ruleNC)!=ITK_ok)PrintErrorStack();
								if(BOM_line_ask_child_lines(top_lineNonClrPrev, &NonClrPrevChildCnt, &NonClrPrevChilds)!=ITK_ok)PrintErrorStack();

								for (nc = 0; nc < NonClrChildCnt; nc++)
								{
									childNotExitFlag=0;
									if(AOM_ask_value_string( NonClrChilds[nc] ,"bl_item_item_id",&NCRevChild)!=ITK_ok)PrintErrorStack();
									for (ncp = 0; ncp < NonClrPrevChildCnt; ncp++)
									{
										if(AOM_ask_value_string( NonClrPrevChilds[ncp] ,"bl_item_item_id",&NCPrevRevChild)!=ITK_ok)PrintErrorStack();

										if (tc_strcmp(NCRevChild,NCPrevRevChild)==0)
										{
											childNotExitFlag=1;
											break;
										}
									}
									if (childNotExitFlag==0)
									{
										if (strlen(NonClrChildSet)==0)
										{
											tc_strcpy(NonClrChildSet,NCRevChild);
											tc_strcat(NonClrChildSet,",");
										}
										else if (tc_strstr(NonClrChildSet,NCRevChild)==NULL)
										{
											tc_strcat(NonClrChildSet,NCRevChild);
											tc_strcat(NonClrChildSet,",");
										}
									}
								} //End of loop NonClrChildCnt

								if (strlen(NonClrChildSet)==0)
								{
									for (ncp = 0; ncp < NonClrPrevChildCnt; ncp++)
									{
										childNotExitFlag=0;
										if(AOM_ask_value_string( NonClrPrevChilds[ncp] ,"bl_item_item_id",&NCPrevRevChild)!=ITK_ok)PrintErrorStack();
										for (nc = 0; nc < NonClrChildCnt; nc++)
										{
											if(AOM_ask_value_string( NonClrChilds[nc] ,"bl_item_item_id",&NCRevChild)!=ITK_ok)PrintErrorStack();
											if (tc_strcmp(NCRevChild,NCPrevRevChild)==0)
											{
												childNotExitFlag=1;
												break;
											}
										}
										if (childNotExitFlag==0)
										{
											if (strlen(NonClrChildSet)==0)
											{
												tc_strcpy(NonClrChildSet,NCRevChild);
												tc_strcat(NonClrChildSet,",");
											}
											else if (tc_strstr(NonClrChildSet,NCRevChild)==NULL)
											{
												tc_strcat(NonClrChildSet,NCRevChild);
												tc_strcat(NonClrChildSet,",");
											}
										}
									} //End of loop NonClrPrevChildCnt
								} //End of condn if (strlen(NonClrChildSet)==0)
							}
							printf("\t NonClrChildCnt= %d  NonClrPrevChildCnt= %d  strlen(NonClrChildSet)= %d ",NonClrChildCnt,NonClrPrevChildCnt,strlen(NonClrChildSet)); fflush(stdout);
							fprintf(fpCLLog,"\t NonClrChildCnt= %d  NonClrPrevChildCnt= %d  strlen(NonClrChildSet)= %d ",NonClrChildCnt,NonClrPrevChildCnt,strlen(NonClrChildSet)); fflush(fpCLLog);
							//Get child from BOM of latest released and previous released revision---END------

							// ----------------START-Get Colour Parts-------------------------------------------
							if(tRelationFind!=NULLTAG)
							{
								tag_t ColItemMstrTag = NULLTAG;
								tag_t ColLatestRevTag = NULLTAG;
								tag_t owningUserSchm = NULLTAG;
								int zp2 = 0;
								char useridSchm[SA_user_size_c+1];
								tag_t *ClrPrimObjstag = NULLTAG;
								tag_t ClrPrimObjtag = NULLTAG;
								tag_t class_id = NULLTAG;
								tag_t *TaskPrimObjstag = NULLTAG;
								tag_t TaskPrimObjtag = NULLTAG;
								tag_t Taskclass_id = NULLTAG;
								tag_t SchmRefTag = NULLTAG;
								int ClrPrimObjCnt=0, zk=0, TaskPrimObjCnt=0, zk2=0, ClrDmlFlag=0;
								char *class_name=NULL;
								char *class_name2=NULL;
								char *DMLTaskNo=NULL;
								char *DMLNumber2=NULL;
								char *DMLRlsType=NULL;
								tag_t *MatchColSchmsTags = NULLTAG;

								if(NonClrPrtPrevRevTag!=NULLTAG)
								{
									if(GRM_list_primary_objects_only(NonClrPrtPrevRevTag,tRelationFind,&ClrCount,&ClrPart_tag)!=ITK_ok)PrintErrorStack();
								}

								printf("\n\t ClrCount: %d",ClrCount);fflush(stdout);
								fprintf(fpCLLog,"\n\t ClrCount: %d",ClrCount);fflush(fpCLLog);

								/*if((tc_strstr(RevSeqTmp,"NR;")!=NULL)&&(ClrCount==0))
								{
								}
								else*/ if(ClrCount>0)
								{
									colPrtCnt=0;
									ClrAssySet = (char *) MEM_alloc(10000 * sizeof(char));
									ColPrtUniqTags = (tag_t *) MEM_alloc(10000 * sizeof(tag_t));
									tc_strcpy(ClrAssySet,"");

									for(zp1=0; zp1<ClrCount; zp1++)
									{
										latestClrRev=ClrPart_tag[zp1];
										if(AOM_ask_value_string(latestClrRev,"item_id",&ColPartNo)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(latestClrRev,"item_revision_id",&ColPartRev)!=ITK_ok)PrintErrorStack();

										printf("\n\t %d--ColPartNo: %s/%s",zp1,ColPartNo,ColPartRev);fflush(stdout);
										fprintf(fpCLLog,"\n\t %d--ColPartNo: %s/%s",zp1,ColPartNo,ColPartRev);fflush(fpCLLog);

										if(ITEM_find_item(ColPartNo, &ColItemMstrTag)!=ITK_ok)PrintErrorStack();
										if(ITEM_ask_latest_rev(ColItemMstrTag,&ColLatestRevTag)!=ITK_ok)PrintErrorStack();

										if (strlen(ClrAssySet)==0)
										{
											tc_strcpy(ClrAssySet,ColPartNo);
											tc_strcat(ClrAssySet,",");

											ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
											colPrtCnt=colPrtCnt+1;
										}
										else if (tc_strstr(ClrAssySet,ColPartNo)==NULL)
										{
											tc_strcat(ClrAssySet,ColPartNo);
											tc_strcat(ClrAssySet,",");

											ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
											colPrtCnt=colPrtCnt+1;
										}
									}

									printf("\n\t Distinct colPrtCnt: %d",colPrtCnt);fflush(stdout);
									fprintf(fpCLLog,"\n\t Distinct colPrtCnt: %d",colPrtCnt);fflush(fpCLLog);
									for(zp = 0; zp<colPrtCnt; zp++)
									{
										int colSchmCnt=0;
										ColRlzRevFlag=0;

										SchmRefTag = NULLTAG;
										MatchColSchmsTags = NULLTAG;
										MatchColSchmsTags = (tag_t *) MEM_alloc(100 * sizeof(tag_t));

										if(latestClrRev!=NULLTAG)
										{
											latestClrRev=NULLTAG;
										}

										latestClrRev=ColPrtUniqTags[zp];

										if(AOM_ask_value_string(latestClrRev,"item_id",&ColPartNo)!=ITK_ok)PrintErrorStack();

										//if (tc_strcmp(ColPartNo,"5442T3Z0168009ZZ")!=0)
										//{
										//	continue;
										//}

										if(AOM_UIF_ask_value (latestClrRev, "release_status_list", &ColPrtRelSt)!=ITK_ok)PrintErrorStack();
										if((tc_strstr(ColPrtRelSt,"ERC Released")!=NULL)||(tc_strstr(ColPrtRelSt,"T5_LcsErcRlzd")!=NULL))
										{
											ColRlzRevFlag=1;
										}
										printf("\n\t ColPrtRelSt: [%s]",ColPrtRelSt);fflush(stdout);
										printf("\n\n =======CL=ColAssy--zp: %d  ColourPart: %s  ColRlzRevFlag: %d  DMLProject:[%s]===============================================\n\n",zp,ColPartNo,ColRlzRevFlag,DMLProject);fflush(stdout);
										fprintf(fpCLLog,"\n\t ColPrtRelSt: [%s]",ColPrtRelSt);fflush(fpCLLog);
										fprintf(fpCLLog,"\n\n =======CL=ColAssy--zp: %d  ColourPart: %s  ColRlzRevFlag: %d  DMLProject:[%s]===============================================\n\n",zp,ColPartNo,ColRlzRevFlag,DMLProject);fflush(fpCLLog);

										if(tc_strstr(ColPrtRelSt,"Obsolete")!=NULL)
										{
											printf(" This colourPart is in 'Obsolete' hence skipping....");fflush(stdout);
											fprintf(fpCLLog," This colourPart is in 'Obsolete' hence skipping....");fflush(fpCLLog);
											continue;
										}

										printf("\n\t DMLProject11111: [%s]",DMLProject);fflush(stdout);
										fprintf(fpCLLog,"\n\t DMLProject11111: [%s]",DMLProject);fflush(fpCLLog);

										if(tc_strcmp(DMLProject,"5445")==0 || tc_strcmp(DMLProject,"5477")==0)   // no changes needed bcz function commented by Gajanan
										{
											if(GRM_list_primary_objects_only(latestClrRev,NULLTAG,&ClrPrimObjCnt,&ClrPrimObjstag));
											printf("\n\t ClrPrimObjCnt: %d ",ClrPrimObjCnt);fflush(stdout);
											fprintf(fpCLLog,"\n\t ClrPrimObjCnt: %d ",ClrPrimObjCnt);fflush(fpCLLog);

											ClrDmlFlag=0;
											MatchColSchemeFlag=0;

											for(zk = 0; zk<ClrPrimObjCnt; zk++)
											{
												ClrPrimObjtag = ClrPrimObjstag[zk];

												if(POM_class_of_instance(ClrPrimObjtag,&class_id));
												if(POM_name_of_class(class_id,&class_name));

												printf("\n\t class_name: %s",class_name);fflush(stdout);
												fprintf(fpCLLog,"\n\t class_name: %s",class_name); fflush(fpCLLog);

												if (tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
												{
													if(AOM_ask_value_string(ClrPrimObjtag,"item_id",&DMLTaskNo)); //object_string
													printf("\n\t CM=DMLTaskNo: %s",DMLTaskNo);fflush(stdout);
													fprintf(fpCLLog,"\n\t CM=DMLTaskNo: %s",DMLTaskNo);fflush(fpCLLog);

													if(GRM_list_primary_objects_only(ClrPrimObjtag,NULLTAG,&TaskPrimObjCnt,&TaskPrimObjstag));
													printf("  TaskPrimObjCnt: %d ",TaskPrimObjCnt);fflush(stdout);
													fprintf(fpCLLog,"  TaskPrimObjCnt: %d ",TaskPrimObjCnt);fflush(fpCLLog);

													for(zk2 = 0; zk2<TaskPrimObjCnt; zk2++)
													{
														TaskPrimObjtag = TaskPrimObjstag[zk2];

														if(POM_class_of_instance(TaskPrimObjtag,&Taskclass_id));
														if(POM_name_of_class(Taskclass_id,&class_name2));
														printf("  class_name2: %s",class_name2);fflush(stdout);
														fprintf(fpCLLog,"  class_name2: %s",class_name2);fflush(fpCLLog);

														if(AOM_ask_value_string(TaskPrimObjtag,"object_string",&DMLNumber2));
														printf("  DMLNo: %s",DMLNumber2);fflush(stdout);
														fprintf(fpCLLog,"  DMLNo: %s",DMLNumber2);fflush(fpCLLog);

														if(AOM_ask_value_string(TaskPrimObjtag,"t5_rlstype",&DMLRlsType));
														printf("  DMLRlsType: %s \n",DMLRlsType);fflush(stdout);
														fprintf(fpCLLog,"  DMLRlsType: %s \n",DMLRlsType);fflush(fpCLLog);

														if ((strcmp(DMLRlsType,"CP")==0)||(strcmp(DMLRlsType,"CM")==0)||(strstr(DMLTaskNo,"CL")!=NULL))
														{
															ClrDmlFlag=1;
															break;
														}
													}
													if (ClrDmlFlag==1)
													{
														break;
													}
												}
											}

											if((ClrDmlFlag==1) && (TaskPrimObjtag!=NULLTAG))
											{
												tag_t RefRel_tag = NULLTAG;
												tag_t RefTypeTag = NULLTAG;
												tag_t *RefDoc_tag = NULLTAG;
												int Refcount=0, jr=0;
												char *Reftype_name=NULL;
												char *ClrSchmNo=NULL;

												if(GRM_find_relation_type("IMAN_reference", &RefRel_tag));
												if(RefRel_tag!=NULLTAG)
												{
													if(GRM_list_secondary_objects_only(TaskPrimObjtag,RefRel_tag,&Refcount,&RefDoc_tag));
													printf("\n Refcount: %d ",Refcount);fflush(stdout);
													fprintf(fpCLLog,"\n Refcount: %d ",Refcount);fflush(fpCLLog);

													for (jr=0; jr<Refcount; jr++)
													{
														SchmRefTag=RefDoc_tag[jr];

														if(TCTYPE_ask_object_type(SchmRefTag,&RefTypeTag));
														if(TCTYPE_ask_name2(RefTypeTag,&Reftype_name));
														printf("\n Reftype_name: %s ",Reftype_name);fflush(stdout);
														fprintf(fpCLLog,"\n Reftype_name: %s ",Reftype_name);fflush(fpCLLog);

														if (tc_strcmp(Reftype_name,"T5_clschmRevision")==0)
														{
															CpyClrscheme=(char *) MEM_alloc(100);

															if(AOM_ask_value_string(SchmRefTag,"item_id",&ClrSchmNo));
															printf("\t ClrSchmNo: [%s] ",ClrSchmNo);fflush(stdout);
															fprintf(fpCLLog,"\t ClrSchmNo: [%s] ",ClrSchmNo);fflush(fpCLLog);

															tc_strcpy(CpyClrscheme,ClrSchmNo);

															MatchColSchemeFlag = ProcessColourScheme2(ColPartNo,latestClrRev,CpyClrscheme,SchmRefTag);

															printf("\t MatchColSchemeFlag: [%d] ",MatchColSchemeFlag);fflush(stdout);
															fprintf(fpCLLog,"\t MatchColSchemeFlag: [%d] ",MatchColSchemeFlag);fflush(fpCLLog);

															if (MatchColSchemeFlag==1)
															{
																printf("-------Match Scheme Found ");fflush(stdout);
																fprintf(fpCLLog,"-------Match Scheme Found ");fflush(fpCLLog);

																MatchColSchmsTags[colSchmCnt]=SchmRefTag;
																colSchmCnt=colSchmCnt+1;
																//break;
															}
														}
													}
												}
											}
										}else if(tc_strcmp(DMLProject,"5442")==0)   // no changes needed bcz function commented by Gajanan
										{
											printf("\n\t DMLProject2222222: [%s]",DMLProject);fflush(stdout);
											fprintf(fpCLLog,"\n\t DMLProject2222222: [%s]",DMLProject);fflush(fpCLLog);

											colSchmCnt=0;

											if(AOM_ask_value_string (latestClrRev, "gov_classification", &govClassification));
											printf("\n 2.govClassification----->: %s\n", govClassification); fflush(stdout);
											fprintf(fpCLLog,"\n 2.govClassification----->: %s\n", govClassification); fflush(fpCLLog);

											if ((govClassification!=NULL) && (strstr(govClassification,"#")!=NULL))
											{
												tag_t schemeMasterTag = NULLTAG;

												char* schemeNo=strtok(govClassification,"#");
												char* schemeRev=strtok(NULL,"#");

												char *SchRevSeq = NULL;
												SchRevSeq = NULL;
												SchRevSeq =(char *) MEM_alloc(32);
												strcpy(SchRevSeq ,schemeRev);
												strcat(SchRevSeq ,"*1");

												//strcat(SchRevSeq ,";");
												//strcat(SchRevSeq ,"1");

												printf("  schemeNo: %s  SchRevSeq: %s \n",schemeNo,SchRevSeq );fflush(stdout);
												fprintf(fpCLLog,"  schemeNo: %s  SchRevSeq: %s \n",schemeNo,SchRevSeq );fflush(fpCLLog);

												if(ITEM_find_item(schemeNo, &schemeMasterTag)!=ITK_ok)PrintErrorStack();
												ifail =ITEM_find_revision(schemeMasterTag,SchRevSeq ,&SchmRefTag);

												if (SchmRefTag!=NULLTAG)
												{
													MatchColSchemeFlag = ProcessColourScheme2(ColPartNo,latestClrRev,schemeNo,SchmRefTag);

													printf("\t 2.1122MatchColSchemeFlag: [%d] ",MatchColSchemeFlag);fflush(stdout);
													fprintf(fpCLLog,"\t 2.1122MatchColSchemeFlag: [%d] ",MatchColSchemeFlag);fflush(fpCLLog);
													if (MatchColSchemeFlag==1)
													{
														printf("-------Match Scheme Found ");fflush(stdout);
														fprintf(fpCLLog,"-------Match Scheme Found ");fflush(fpCLLog);

														MatchColSchmsTags[colSchmCnt]=SchmRefTag;
														colSchmCnt=colSchmCnt+1;
														//break;
													}
												}
												else
												{
													printf("\t -------- Scheme is not queried..??");fflush(stdout);
													fprintf(fpCLLog,"\t -------- Scheme is not queried..??");fflush(fpCLLog);
												}
											}
										}else
										{
											printf("\n\t ColourPart: %s -----No Scheme logic for project [%s] hence continued.....\n",ColPartNo,DMLProject); fflush(stdout);
											fprintf(fpCLLog,"\n\t ColourPart: %s -----No Scheme logic for project [%s] hence continued.....\n",ColPartNo,DMLProject); fflush(fpCLLog);
											fprintf(fpCLErrLog,"\nColourPart: %s -----No Scheme logic for project [%s] hence continued.....",ColPartNo,DMLProject); fflush(fpCLLog);
											continue;
										}

										if (MatchColSchemeFlag==0)
										{
											printf("-------Scheme NOT Found for Color Part = [%s] continuning.........\n",ColPartNo);fflush(stdout);
											fprintf(fpCLLog,"-------Scheme NOT Found for Color Part = [%s] continuning.........\n",ColPartNo);fflush(fpCLLog);
											fprintf(fpCLErrLog,"\nScheme NOT Found for Color Part = [%s] continuning.........",ColPartNo);fflush(fpCLErrLog);
											continue;
										}

										if (colSchmCnt>1)
										{
											printf("\n\t-------more than one match scheme found for Color Part [%s] so continue to next.....\n",ColPartNo);fflush(stdout);
											fprintf(fpCLLog,"\n\t-------more than one match scheme found for Color Part [%s] so continue to next.....\n",ColPartNo);fflush(fpCLLog);
											fprintf(fpCLErrLog,"\nmore than one match scheme found for Color Part [%s] so continue to next.....",ColPartNo);fflush(fpCLErrLog);

											//Add error message for more than one match scheme

											continue;
										}

										// ----------------Colour Scheme-START---------------------------------------------
										SchmRevRlzFlag=0;

										if (SchmRefTag==NULLTAG)
										{
											continue;
										}

										if(AOM_ask_value_string(SchmRefTag, "object_string", &SchmName)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(SchmRefTag, "item_revision_id", &SchmRev)!=ITK_ok)PrintErrorStack();

										SchTok=strtok(SchmName,";");
										printf ("\n Color Scheme is : %s\n", SchTok);fflush(stdout);
										fprintf (fpCLLog,"\n Color Scheme is : %s\n", SchTok);fflush(fpCLLog);

										if(STRNG_replace_str(SchTok,",","#",&SchDataToGov)!=ITK_ok)PrintErrorStack();
										printf ( "\n SchDataToGov is -------> %s\n",SchDataToGov);fflush(stdout);
										fprintf (fpCLLog,"\n SchDataToGov is -------> %s\n",SchDataToGov);fflush(fpCLLog);

										//if(WSOM_ask_release_status_list(SchmRefTag, &status_count, &relStatus_list)!=ITK_ok)PrintErrorStack();
										//if(status_count > 0)
										//{
										//	for(rs = 0; rs < status_count; rs++)
										//	{
										//		if(AOM_ask_name(relStatus_list[rs], &ColSchmRlzSt)==ITK_ok)
										//		printf("\t ColSchm Release status:%s ", ColSchmRlzSt);fflush(stdout);
										//		if ((tc_strcmp(ColSchmRlzSt,"T5_LcsErcRlzd")==0) || (tc_strcmp(ColSchmRlzSt,"ERC Released")==0) )
										//		{
										//			break;
										//		}
										//	}
										//}

										if(AOM_UIF_ask_value (SchmRefTag, "release_status_list", &SchmRel_status)!=ITK_ok)PrintErrorStack();
										if((tc_strstr(SchmRel_status,"ERC Released")!=NULL)||(tc_strstr(SchmRel_status,"T5_LcsErcRlzd")!=NULL))
										{
											//printf(" --A-SchmRel_status");
											fprintf(fpCLLog," --A-SchmRel_status");
											SchmRevRlzFlag=1;
											fflush(stdout);
										}
										else
										{
											printf(" --B-SchmRel_status"); fflush(stdout);
											fprintf(fpCLLog," --B-SchmRel_status"); fflush(fpCLLog);
											//if(ITEM_list_all_revs (ColorSchemetag, &SchmRevCnt, &SchmRev_list)!=ITK_ok)PrintErrorStack();
											//for(sc = 0; sc < status_count; sc++)
											//{
											//	SchmRefTag=SchmRev_list[sc];
											//	if(AOM_UIF_ask_value (SchmRefTag, "release_status_list", &SchmRel_status)!=ITK_ok)PrintErrorStack();
											//	if((tc_strstr(SchmRel_status,"ERC Released")!=NULL)||(tc_strstr(SchmRel_status,"T5_LcsErcRlzd")!=NULL))
											//	{
											//		SchmRevRlzFlag=1;
											//		break;
											//	}
											//}
										}
										if (SchmRevRlzFlag==0)
										{
											printf("\n  Scheme--co: %d ==>No Revision of scheme Released [%s], hence skipping ??",co,SchmName); fflush(stdout);
											fprintf(fpCLLog,"\n  Scheme--co: %d ==>No Revision of scheme Released [%s], hence skipping ??",co,SchmName); fflush(fpCLLog);
											//continue;
										}
										else if ( (SchmRevRlzFlag==1) && (SchmRefTag!=NULLTAG) )
										{
											//if(AOM_ask_value_string(SchmRefTag, "t5_ClSrl", &ClSrlName)!=ITK_ok)PrintErrorStack();
											//printf("\n\t CM=ClSrlName is --> : %s",ClSrlName); fflush(stdout);
											//
											//ClSuffix=tc_strtok(ClSrlName,";");
											//printf("\n\t CM=ClSuffix => %s ",ClSuffix );fflush(stdout);
											//
											//ClrSchmToVf = (char *) MEM_alloc( 50 * sizeof(char) );
											//strcpy(ClrSchmToVf,"");
											//tc_strcat(ClrSchmToVf,CpyClrscheme);
											//printf ("\n\t CM=ClrSchmToVf-------------------------------------> [%s]\n", ClrSchmToVf); fflush(stdout);

											if (SchmWithCmpcdRel!=NULLTAG)
											{
												if(GRM_list_secondary_objects_only(SchmRefTag, SchmWithCmpcdRel, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok)PrintErrorStack();
												printf("\n  CL=Comp Code Cmpcount for Color Scheme: %d",Cmpcount); fflush(stdout);
												fprintf(fpCLLog,"\n  CL=Comp Code Cmpcount for Color Scheme: %d",Cmpcount); fflush(fpCLLog);

												if(Cmpcount > 0)
												{
													int NonClrflag=0;
													t5ClSrl = (char*) malloc(50);
													t5ClSrl = GetColourSrlFrmSchmCompCodes(CmpCodeOfClrScheme,Cmpcount,Comp_Code);
													printf("\n  CL-A=t5ClSrl from function: %s",t5ClSrl); fflush(stdout);
													fprintf(fpCLLog,"\n  CL=t5ClSrl from function: %s",t5ClSrl); fflush(fpCLLog);

													if ((t5ClSrl!=NULL) && (strlen(t5ClSrl)>0))
													{
														if(tc_strstr(t5ClSrl,";")!=NULL)
														{
															Suffix =  strtok(t5ClSrl,";");
															printf("    Suffix --> : %s",Suffix); fflush(stdout);
															fprintf(fpCLLog,"    Suffix --> : %s",Suffix); fflush(fpCLLog);

															ColourID  =  strtok(NULL,";");
															printf("	ColourID --> : %s",ColourID); fflush(stdout);
															fprintf(fpCLLog,"	ColourID --> : %s",ColourID); fflush(fpCLLog);
														}
														else
														{
															Suffix =  strtok(t5ClSrl,",");
															printf("    Suffix --> : %s",Suffix); fflush(stdout);
															fprintf(fpCLLog,"    Suffix --> : %s",Suffix); fflush(fpCLLog);

															ColourID  =  strtok(NULL,",");
															printf("    ColourID --> : %s",ColourID); fflush(stdout);
															fprintf(fpCLLog,"    ColourID --> : %s",ColourID); fflush(fpCLLog);
														}


														n_ClrPrt_tags=0;
														NonClrflag=1;

														char *ColItem = NULL;
														logical checkout;

														ColItem=(char *) MEM_alloc(25);
														strcpy(ColItem,"");
														if(tc_strcmp(PartType,"G")==0)
														{
															//printf("\n  before NewUniqGroupIDNum\n"); fflush(stdout);
															//ResponseStr = NewUniqGroupIDNum();
															//printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
															//strcat(ColItem,ResponseStr);
															printf("\n    Colour Part for Group ID---->%s\n",ColItem);
															fprintf(fpCLLog,"\n    Colour Part for Group ID---->%s\n",ColItem); fflush(fpCLLog);
														}
														else
														{
															strcpy(ColItem,Part_no);
															strcat(ColItem,Suffix);
														}

														if (tc_strcmp(ColPartNo,ColItem)==0)
														{
															printf("\n\n    SchemeColourPart: %s == ColPartNo: %s --------------->ColPart Match Found......",ColItem,ColPartNo); fflush(stdout);
															fprintf(fpCLLog,"\n\n    SchemeColourPart: %s == ColPartNo: %s --------------->ColPart Match Found......",ColItem,ColPartNo); fflush(fpCLLog);
															MatchColSchemeFlag=1;
														}
														else
														{
															continue;
														}

														if (strlen(ColItem)>=1)
														{
															if (ClrPartQryTag!=NULLTAG)
															{
																//printf("\n    CM=Found Query 'ClrPart' ClrPartQryTag \n"); fflush(stdout);
																valuesClrPrt[0] = ColItem;
																if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &n_ClrPrt_tags, &ClrPrtTags));
																printf("\n    1.ClrPart count is--------> %d ",n_ClrPrt_tags);fflush(stdout);
																fprintf(fpCLLog,"\n    1.ClrPart count is--------> %d ",n_ClrPrt_tags);fflush(fpCLLog);
															}
															else
															{
																printf("\n    Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....\n"); fflush(stdout);
																fprintf(fpCLLog,"\n    Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....\n"); fflush(fpCLLog);
																break;
															}
														}
														else{
															printf("\n    2.ClrPart count = 0");fflush(stdout);
															fprintf(fpCLLog,"\n    2.ClrPart count = 0");fflush(fpCLLog);
															break;
														}

														tc_strcpy(NewColourPart,ColItem);

														printf("\t NCAssyChildFlag: %d   NewColourPart: [%s]",NCAssyChildFlag,NewColourPart);fflush(stdout);
														fprintf(fpCLLog,"\t NCAssyChildFlag: %d   NewColourPart: [%s]",NCAssyChildFlag,NewColourPart);fflush(fpCLLog);

														tag_t ClritemTag = NULLTAG;
														tag_t clrbv = NULLTAG;
														tag_t  clrbvrTag = NULLTAG;
														tag_t *clr_bvs = NULLTAG;
														tag_t *clr_bvrs = NULLTAG;
														int bv_clrcount =0;
														int i1, TskHSICnt, ci, PartAttachtoDmlFlag =0;
														char *ColPartRev = NULL;
														char *tsk_name = NULL;
														char *TskSolutnItem = NULL;
														tag_t *TskHSItems = NULLTAG;

														if(n_ClrPrt_tags > 0)
														{
															ColItemTag = ClrPrtTags[0];

															if(ITEM_ask_latest_rev(ColItemTag,&ColorRevTag)!=ITK_ok)PrintErrorStack();
															if(AOM_UIF_ask_value(ColorRevTag, "item_revision_id", &ColPartRev)!=ITK_ok)PrintErrorStack();
															printf("  ColPartRev: %s",ColPartRev);	fflush(stdout);
															fprintf(fpCLLog,"  ColPartRev: %s",ColPartRev);	fflush(fpCLLog);

															if(WSOM_ask_release_status_list(ColorRevTag, &ColRlzStatusCnt, &Col_Rlz_St_list)!=ITK_ok)PrintErrorStack();
															printf("\t ColRlzStatusCnt: %d",ColRlzStatusCnt);	fflush(stdout);
															fprintf(fpCLLog,"\t ColRlzStatusCnt: %d",ColRlzStatusCnt);	fflush(fpCLLog);

															ColRlzRevFlag=0;
															if (ColRlzStatusCnt > 0)
															{
																for(ss2=0; ss2<ColRlzStatusCnt ; ss2++)
																{
																	if(AOM_ask_value_string(Col_Rlz_St_list[ss2],"object_name",&ColPrtLatestRlzSt)!=ITK_ok)PrintErrorStack();
																	if((tc_strcmp(ColPrtLatestRlzSt,"ERC Released")==0) || (tc_strcmp(ColPrtLatestRlzSt,"T5_LcsErcRlzd")==0))
																	{
																		printf("\t ColPrtLatestRlzSt: %s ",ColPrtLatestRlzSt);fflush(stdout);
																		fprintf(fpCLLog,"\t ColPrtLatestRlzSt: %s ",ColPrtLatestRlzSt);fflush(fpCLLog);
																		ColRlzRevFlag=1;
																		break;
																	}
																}
															} //End of if (ColRlzStatusCnt > 0)

															if (ColRlzRevFlag==0)
															{
																printf("\t ColPrtLatestRlzSt: %s ",ColPrtLatestRlzSt);fflush(stdout);
																fprintf(fpCLLog,"\t ColPrtLatestRlzSt: %s ",ColPrtLatestRlzSt);fflush(fpCLLog);
																////printf(" ----Latest ColourPart revision is not in ERC Released Status, hence skipping its colour colour part revise ??? \n");fflush(stdout);

																//START--Check ERC Review colour if attached to same working DML then proceed for bom change
																PartAttachtoDmlFlag=0;
																if (taskCnt>0)
																{
																	for (i1=0;i1<taskCnt ;i1++ )
																	{
																		if(AOM_ask_value_string(DmlTaskTags[i1],"object_name",&tsk_name)==ITK_ok)
																		printf("\n tsk_name is :%s\n",tsk_name);fflush(stdout);
																		fprintf(fpCLLog,"\n tsk_name is :%s\n",tsk_name);fflush(fpCLLog);

																		if (tsk_HSI_rel_type!=NULLTAG)
																		{
																			if(GRM_list_secondary_objects_only(DmlTaskTags[i1], tsk_HSI_rel_type, &TskHSICnt, &TskHSItems)!=ITK_ok)PrintErrorStack();
																			printf("\n    i1: %d  Task: %s --->> TskHSICnt partcnt:  %d ",i1, tsk_name, TskHSICnt);fflush(stdout);
																			fprintf(fpCLLog,"\n    i1: %d  Task: %s --->> TskHSICnt partcnt:  %d ",i1, tsk_name, TskHSICnt);fflush(fpCLLog);

																			if (TskHSICnt > 0)
																			{
																				for (ci = 0; ci < TskHSICnt ; ci ++)
																				{
																					if( AOM_ask_value_string(TskHSItems[ci],"item_id",&TskSolutnItem)==ITK_ok)
																					//printf("\n\t\t TskSolutnItem-item_id: %s  ColItem: %s",TskSolutnItem,ColItem);fflush(stdout);

																					if (tc_strcmp(ColItem,TskSolutnItem)==0)
																					{
																						printf("\n\t TskSolutnItem-item_id: %s  ColItem: %s",TskSolutnItem,ColItem);fflush(stdout);
																						printf(" ---Match-Colour attached found to DML task"); fflush(stdout);

																						fprintf(fpCLLog,"\n\t TskSolutnItem-item_id: %s  ColItem: %s",TskSolutnItem,ColItem);fflush(fpCLLog);
																						fprintf(fpCLLog," ---Match-Colour attached found to DML task"); fflush(fpCLLog);

																						PartAttachtoDmlFlag=1;

																						break;
																					}
																				}
																			}
																		}
																		if (PartAttachtoDmlFlag==1)
																		{
																			break;
																		}
																	}
																}
																printf("\n\n\t PartAttachtoDmlFlag: %d  for ColItem: %s ",PartAttachtoDmlFlag, ColItem);fflush(stdout);
																fprintf(fpCLLog,"\n\n\t PartAttachtoDmlFlag: %d  for ColItem: %s ",PartAttachtoDmlFlag, ColItem);fflush(fpCLLog);
																if (PartAttachtoDmlFlag==0)
																{
																	printf(" ---ColourPart is not attached to same DML, hence skipping ????"); fflush(stdout);
																	fprintf(fpCLLog," ---ColourPart is not attached to same DML, hence skipping ????"); fflush(fpCLLog);
																	//If Colour attached to another DML if not then attach to current DML and preoceed bom--add code
																}
																//END--Check ERC Review colour if attached to same working DML then proceed for bom change
															}

															//if (ColRlzRevFlag>0)
															if ((ColRlzRevFlag>0) || (PartAttachtoDmlFlag==1))
															{
																int ReviseStatus = ValColAndNonColBomForRevise_CL(NonClrPartTag,ColorRevTag,ColRlzRevFlag,SchmRefTag);
																printf("\n\t ColRlzRevFlag:%d  ReviseStatus: %d  NonColPartBomDiff: %d",ColRlzRevFlag, ReviseStatus, strlen(NonClrChildSet));fflush(stdout);
																fprintf(fpCLLog,"\n\t ColRlzRevFlag:%d  ReviseStatus: %d  NonColPartBomDiff: %d",ColRlzRevFlag, ReviseStatus, strlen(NonClrChildSet));fflush(fpCLLog);

																if ((ReviseStatus==0)&&(strlen(NonClrChildSet)==0))
																{
																	printf("\t ---B--No need to revive Colour: %s/%s [%s] --No BOM Difference ..",ColItem,ColPartRev,ColPrtLatestRlzSt);fflush(stdout);
																	fprintf(fpCLLog,"\t ---B--No need to revive Colour: %s/%s [%s] --No BOM Difference ..",ColItem,ColPartRev,ColPrtLatestRlzSt);fflush(fpCLLog);
																}
																else
																{
																if(RES_is_checked_out(ColorRevTag,&checkout)!=ITK_ok)PrintErrorStack();
																//printf("\n\t CM=ColPart--Value of checkout: %d ",checkout);fflush(stdout);
																printf(" 333checkout: %d ",checkout);fflush(stdout);
																fprintf(fpCLLog," 333checkout: %d ",checkout);fflush(fpCLLog);
																if (checkout==0)
																{
																printf("---Latest and previous Rlz NC_Rev bom difference present1...\n"); fflush(stdout);
																fprintf(fpCLLog,"---Latest and previous Rlz NC_Rev bom difference present1...\n"); fflush(fpCLLog);
																int count2=0;
																int z=0;
																int bvr_count=0;
																int n_occs_clr=0;
																int ic = 0;
																tag_t *occs_clr = NULLTAG;
																tag_t *secondary_objects = NULLTAG;
																tag_t *occs=NULL;
																tag_t objTypeTag2 = NULLTAG;
																char *type_name1=NULL;
																char *object_type = NULL;
																char *chname= NULL;

																tag_t	NewTskObjOP		= NULLTAG;
																tag_t	item			= NULLTAG;
																tag_t	ERCDMLTag		= NULLTAG;
																char **valuesERCDML = (char **) MEM_alloc(1 * sizeof(char *));
																int n_entriesDML = 1;
																char *qry_entries5[1] = {"ID"};
																int resultDMLNo=0;
																tag_t *DMLNotags=NULLTAG;
																tag_t ERCDMLObjtag = NULLTAG;
																tag_t reln_type_tag = NULLTAG;
																tag_t relation = NULLTAG;
																char *Dml_taskNo = NULL;
																tag_t IMANReferences_type;
																tag_t Rel_References = NULLTAG;
																tag_t RelExist = NULLTAG;

																printf("---Latest and previous Rlz NC_Rev bom difference present...2\n"); fflush(stdout);
																fprintf(fpCLLog,"---Latest and previous Rlz NC_Rev bom difference present...2\n"); fflush(fpCLLog);

																if(GRM_find_relation_type("T5_DMLTaskRelation",&reln_type_tag)!=ITK_ok)PrintErrorStack();
																if(AOM_ask_value_string(Dml_task,"item_id",&Dml_taskNo)!=ITK_ok)PrintErrorStack();
																printf("\n Dml_taskNo----------->%s\n",Dml_taskNo); fflush(stdout);
																fprintf(fpCLLog,"\n Dml_taskNo----------->%s\n",Dml_taskNo); fflush(fpCLLog);

																DMLNo = subString(Dml_taskNo,0,10);
																printf("\n Dml_taskNo----------->%s\n",DMLNo); fflush(stdout);
																fprintf(fpCLLog,"\n Dml_taskNo----------->%s\n",DMLNo); fflush(fpCLLog);

																if(QRY_find2("ERC DML", &ERCDMLTag));
																valuesERCDML[0] = DMLNo ;
																if(QRY_execute(ERCDMLTag, n_entriesDML, qry_entries5, valuesERCDML, &resultDMLNo, &DMLNotags));
																printf("\n resultDMLNo count is-------->  : %d",resultDMLNo);fflush(stdout);
																fprintf(fpCLLog,"\n resultDMLNo count is-------->  : %d",resultDMLNo);fflush(fpCLLog);

																if (resultDMLNo > 0)
																{
																	ERCDMLObjtag = DMLNotags[0];
																	//Added by Hanuman at TZ 1.52
																	if(GRM_find_relation_type("IMAN_reference", &IMANReferences_type)!=ITK_ok)PrintErrorStack();
																	if(IMANReferences_type!=NULLTAG)
																	{
																		if(GRM_find_relation(ERCDMLObjtag,SchmRefTag,IMANReferences_type,&RelExist)!=ITK_ok)PrintErrorStack();
																		if (RelExist==NULLTAG)
																		{
																			if(GRM_create_relation(ERCDMLObjtag,SchmRefTag,IMANReferences_type, NULLTAG, &Rel_References)!=ITK_ok)PrintErrorStack();
																			if(AOM_load(Rel_References)!=ITK_ok)PrintErrorStack();
																			if(GRM_save_relation(Rel_References)!=ITK_ok)PrintErrorStack();
																			if(AOM_refresh(Rel_References,FALSE)!=ITK_ok)PrintErrorStack();
																		}
																	}
																}

																sTaskName = NULL;
																sTaskName=(char *) MEM_alloc(50);
																tc_strcpy(sTaskName,DMLNo);
																tc_strcat(sTaskName,"_CL");
																printf("\n TaskName is ===> [%s]\n",sTaskName);fflush(stdout);
																fprintf(fpCLLog,"\n TaskName is ===> [%s]\n",sTaskName);fflush(fpCLLog);

																if(QRY_find2("ERC DML Task", &queryds)!=ITK_ok)PrintErrorStack();
																qry_valuesds[0] = sTaskName;
																if(QRY_execute(queryds, n_entries, qry_entriesds, qry_valuesds, &TaskClSet, &TaskClTag)!=ITK_ok)PrintErrorStack();
																printf("\n TaskClSet is :: %d\n", TaskClSet);fflush(stdout);
																fprintf(fpCLLog,"\n TaskClSet is :: %d\n", TaskClSet);fflush(fpCLLog);

																if(TaskClSet>0)
																{
																	NewTskObjOP=TaskClTag[0];
																}else
																{
																	if(TaskClSet == 0)
																	{
																		if(ITEM_create_item(sTaskName,sTaskName,"T5_ChangeTask",sTaskName,&item,&NewTskObjOP)!=ITK_ok)PrintErrorStack();
																		printf("\n CL Task created first time------------>\n");fflush(stdout);
																		fprintf(fpCLLog,"\n CL Task created first time------------>\n");fflush(fpCLLog);
																		if(AOM_save_without_extensions(item)!=ITK_ok)PrintErrorStack();
																		if(AOM_save_without_extensions(NewTskObjOP)!=ITK_ok)PrintErrorStack();
																		if(GRM_create_relation(ERCDMLObjtag, NewTskObjOP, reln_type_tag,  NULLTAG, &relation)!=ITK_ok)PrintErrorStack();
																		if(GRM_save_relation(relation)!=ITK_ok)PrintErrorStack();
																		printf("\n CL Task relation created sucessfuly------------>\n");fflush(stdout);
																		fprintf(fpCLLog,"\n CL Task relation created sucessfuly------------>\n");fflush(fpCLLog);

																		//int retrnVal = SendMailToUser(sTaskName);
																		//printf("\n retrnVal is ===> [%d]\n",retrnVal);fflush(stdout);
																		//fprintf(fpCLLog,"\n retrnVal is ===> [%d]\n",retrnVal);fflush(fpCLLog);
																	}
																}

																if (ColRlzRevFlag>0)
																{
																	if(ITEM_copy_rev(ColorRevTag,NULL,&NewColorRevTag)!=ITK_ok)PrintErrorStack();  //Revise
																	//printf("\n....25....");fflush(stdout);
																	if (NewColorRevTag!=NULLTAG)
																	{
																	if(AOM_ask_value_string(NewColorRevTag,"item_revision_id",&NewColPartRevSeq)!=ITK_ok)PrintErrorStack();
																	printf("\n\t CL=NewColPartRevSeq: %s ",NewColPartRevSeq);fflush(stdout);
																	fprintf(fpCLLog,"\n\t CL=NewColPartRevSeq: %s ",NewColPartRevSeq);fflush(fpCLLog);
																	//printf("\n....26....");fflush(stdout);

																	//Scheme added in Revise Color Parts-Hanuman
																	printf ( "\n SchDataToGov1122222222 is -------> %s\n",SchDataToGov);fflush(stdout);
																	fprintf (fpCLLog,"\n SchDataToGov1122222222 is -------> %s\n",SchDataToGov);fflush(fpCLLog);

																	if(AOM_refresh(NewColorRevTag,TRUE)!=ITK_ok)PrintErrorStack();
																	if(AOM_set_value_string(NewColorRevTag,"gov_classification",SchDataToGov)!=ITK_ok)PrintErrorStack();
																	if(AOM_save_without_extensions(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																	if(AOM_refresh(NewColorRevTag,FALSE)!=ITK_ok)PrintErrorStack();
																		if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
																		{
																			if(GRM_find_relation(NewTskObjOP,NewColorRevTag,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
																			if (ReltnExist==NULLTAG)
																			{
																				if(GRM_create_relation(NewTskObjOP,NewColorRevTag,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
																				if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
																				if(AOM_refresh(reltask,FALSE)!=ITK_ok)PrintErrorStack();
																				printf("\n\t DML_Task and Revised New ColPart Relation is Created Successfully.....\n");fflush(stdout);
																				fprintf(fpCLLog,"\n\t DML_Task and Revised New ColPart Relation is Created Successfully.....\n");fflush(fpCLLog);
																			}
																		}

																		//below point is in Under discussion at TZ 1.56
																		int n_attchs,l =0;
																		tag_t*  secondary_objects	= NULLTAG;

																		if ((tRelationFind!=NULLTAG) && (NewColorRevTag!=NULLTAG) && (NonClrItemRevTag!=NULLTAG))
																		{
																			if(GRM_find_relation(NewColorRevTag,NonClrItemRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
																			if(tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
																			{
																				if(GRM_create_relation(NewColorRevTag,NonClrItemRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
																				if(Rel_task!=NULLTAG)
																				{
																					printf("\nAssy-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
																					//fprintf(fpCLLog,"\nAssy-Colour-Non_Colour child part Relation Created Successfully \n");fflush(fpCLLog);
																					if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();//
																					if(AOM_refresh(Rel_task,FALSE)!=ITK_ok)PrintErrorStack();//
																				}
																				else
																				{
																					printf("\nAssy-Colour-Non_Colour child part Relation is not Created ?????\n");fflush(stdout);
																					//fprintf(fpCLLog,"\nAssy-Colour-Non_Colour child part Relation is not Created ?????\n");fflush(fpCLLog);
																				}
																			}

																			if (tc_strstr(NewColPartRevSeq,"NR")==NULL)
																			{
																				if(GRM_list_secondary_objects_only(NewColorRevTag,tRelationFind,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
																				printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);
																				fprintf(fpCLLog,"\n\n\t\t No of DI : %d",n_attchs);fflush(fpCLLog);
																				if(n_attchs>0)
																				{
																					for (l=0;l<n_attchs ;l++ )
																					{
																						if(AOM_UIF_ask_value (secondary_objects[l], "release_status_list", &NPrtLatestRlzSt)!=ITK_ok)PrintErrorStack();
																						if((tc_strstr(NPrtLatestRlzSt,"ERC Released")!=NULL) || (tc_strstr(NPrtLatestRlzSt,"T5_LcsErcRlzd")!=NULL))
																						{
																							printf("\t ColPrtLatestRlzSt: %s\n",NPrtLatestRlzSt);fflush(stdout);
																							fprintf(fpCLLog,"\t ColPrtLatestRlzSt: %s\n",NPrtLatestRlzSt);fflush(fpCLLog);
																							if(GRM_find_relation(NewColorRevTag,secondary_objects[l],tRelationFind,&tRelationExist1)!=ITK_ok)PrintErrorStack();
																							if(tRelationExist1!=NULLTAG)
																							{
																								if(GRM_delete_relation(tRelationExist1)!=ITK_ok)PrintErrorStack();
																								if(AOM_refresh(NewColorRevTag,TRUE)!=ITK_ok)PrintErrorStack();
																								if(AOM_save_without_extensions(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																								if(AOM_refresh(NewColorRevTag,FALSE)!=ITK_ok)PrintErrorStack();
																								printf("\nRelation Deleted Successfully\n"); fflush(stdout);
																								fprintf(fpCLLog,"\nRelation Deleted Successfully\n"); fflush(fpCLLog);
																							}
																						}
																					}
																				}
																			}
																		}
																		else
																		{
																			printf("\n NULLTAG found for tRelationFind/NewColorRevTag/NonClrItemRevTag hence Relation is not Created ?? \n");fflush(stdout);
																			fprintf(fpCLLog,"\n NULLTAG found for tRelationFind/NewColorRevTag/NonClrItemRevTag hence Relation is not Created ?? \n");fflush(fpCLLog);
																		}
																	}
																}else
																{
																	NewColorRevTag=ColorRevTag; //For ERC Review
																}
																if(NewColorRevTag!=NULLTAG)
																{
																	//Create Colour Assembly BVR
																	if(ITEM_ask_item_of_rev(NewColorRevTag, &ClritemTag)!=ITK_ok)PrintErrorStack();
																	if(ITEM_list_bom_views(ClritemTag,&bv_clrcount, &clr_bvs)!=ITK_ok)PrintErrorStack();
																	printf("\n\t bv_clrcnt :%d ",bv_clrcount);fflush(stdout);
																	fprintf(fpCLLog,"\n\t bv_clrcnt :%d ",bv_clrcount);fflush(fpCLLog);

																	if (bv_clrcount!=NULLTAG)
																	{
																		clrbv = clr_bvs[0];
																		MEM_free(clr_bvs);
																	}
																	else
																	{
																		if(PS_create_bom_view( NULLTAG, "", "", ClritemTag,&clrbv )!=ITK_ok)PrintErrorStack();
																		if(AOM_save_without_extensions( clrbv )!=ITK_ok)PrintErrorStack();
																		if(AOM_save_without_extensions( ClritemTag )!=ITK_ok)PrintErrorStack();
																		if(AOM_refresh( ClritemTag,FALSE )!=ITK_ok)PrintErrorStack();
																		printf("\n\t inside PS_create_bom_view..\n");fflush(stdout);
																		fprintf(fpCLLog,"\n\t inside PS_create_bom_view..\n");fflush(fpCLLog);
																	}

																	if(clrbv !=NULLTAG)
																	{
																	//printf("\n Before clrbvrTag find...");fflush(stdout);
																	if(ITEM_rev_list_bom_view_revs( NewColorRevTag, &bvr_count, &clr_bvrs)!=ITK_ok)PrintErrorStack();
																	printf("\n\t CL--Colour bvr_count  --->[%d]  ",bvr_count); fflush(stdout);
																	fprintf(fpCLLog,"\n\t CL--Colour bvr_count  --->[%d]  ",bvr_count); fflush(fpCLLog);
																	if (bvr_count > 0)
																	{
																		clrbvrTag=clr_bvrs[0];
																		MEM_free(clr_bvrs);

																		if(AOM_refresh(clrbvrTag,TRUE)!=ITK_ok)PrintErrorStack();
																		if(PS_list_occurrences_of_bvr( clrbvrTag, &n_occs_clr, &occs_clr )!=ITK_ok)PrintErrorStack();\
																		printf("\n\t CL-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(stdout);
																		fprintf(fpCLLog,"\n\t CL-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(fpCLLog);

																		for (ic = 0; ic<n_occs_clr; ic++)
																		{
																			if(PS_delete_occurrence( clrbvrTag, occs_clr[ic] )!=ITK_ok)PrintErrorStack();
																		}
																		if(AOM_save_without_extensions( clrbvrTag )!=ITK_ok)PrintErrorStack();
																		if(AOM_refresh( clrbvrTag,FALSE )!=ITK_ok)PrintErrorStack();
																		MEM_free(occs_clr);
																	}
																	else{
																		if(PS_create_bvr( clrbv, "", "", false, NewColorRevTag,&clrbvrTag)!=ITK_ok)PrintErrorStack();
																		if(clrbvrTag !=NULLTAG)
																		{
																			if(AOM_save_without_extensions( clrbvrTag)!=ITK_ok)PrintErrorStack();
																			if(AOM_save_without_extensions( NewColorRevTag )!=ITK_ok)PrintErrorStack();
																			if(AOM_refresh( NewColorRevTag,FALSE )!=ITK_ok)PrintErrorStack();
																			printf( "\n\t inside  PS_create_bvr..\n");fflush(stdout);
																			fprintf(fpCLLog,"\n\t inside  PS_create_bvr..\n");fflush(fpCLLog);
																		}
																	}

																	//--START--Adding Childs under New Colour Assy bvr-----------

																	//Previous Released Colour assy- Start
																	tag_t   bom_winclr=NULLTAG;
																	tag_t   top_line1=NULLTAG;
																	tag_t   ruleClr	=NULLTAG;
																	int rulefound1= 0;
																	tag_t *closurerule1 = NULL;
																	tag_t close_tag1;
																	char **rulename1 = NULL;
																	char **rulevalue1 = NULL;
																	tag_t *lines1 = NULL;
																	int n_lines1,k1,k2,CClrQty =0;
																	tag_t  clrPartObject		= NULLTAG;
																	tag_t  CCChildItemTag		= NULLTAG;
																	char *CCChildQty = NULL;
																	char *ColourIndC = NULL;
																	char *ClrCompCode = NULL;
																	char *t5_clr_item_id = NULL;

																	int nc1,NClrQty1,p1 =0;
																	tag_t Childobject1 = NULLTAG;
																	tag_t NCChildItemTag1 = NULLTAG;
																	tag_t *NonClrChilds1 = NULLTAG;
																	char *NCChild1=NULL;
																	char *NCChildColInd1=NULL;
																	char *NCChildQt1y=NULL;

																	if (ColorRevTag!=NULLTAG)
																	{
																		if(BOM_create_window( &bom_winclr)!=ITK_ok)PrintErrorStack();
																		//if(CFM_find("Color ERC Released and above", &ruleClr)!=ITK_ok)PrintErrorStack(); // To be discussed later if released rule requitred here
																		if(CFM_find("Color ERC Review and above", &ruleClr)!=ITK_ok)PrintErrorStack();
																		if(BOM_set_window_config_rule(bom_winclr, ruleClr)!=ITK_ok)PrintErrorStack();
																		/*
																		if(PIE_find_closure_rules2("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound1, &closurerule1)!=ITK_ok)PrintErrorStack();
																		if (rulefound1 > 0)
																		{
																			close_tag1 = closurerule1[0];
																			printf ("closure ruleClr found \n");fflush(stdout);
																			fprintf (fpCLLog,"closure ruleClr found \n");fflush(fpCLLog);
																		}
																		if(BOM_window_set_closure_rule(bom_winclr,close_tag1, 0, rulename1,rulevalue1)!=ITK_ok)PrintErrorStack();
																		*/
																		if(BOM_set_window_pack_all(bom_winclr, TRUE)!=ITK_ok)PrintErrorStack();
																		if(BOM_set_window_top_line(bom_winclr , NULLTAG, ColorRevTag, NULLTAG, &top_line1)!=ITK_ok)PrintErrorStack();
																		if(BOM_line_ask_child_lines(top_line1, &n_lines1, &lines1)!=ITK_ok)PrintErrorStack();
																	}
																	printf("\n\tPrevisous rev-Colour bvr n_lines1: %d \n",n_lines1); fflush(stdout);
																	//Previous Released Colour assy- End

																	if(AOM_refresh(clrbvrTag,TRUE)!=ITK_ok)PrintErrorStack();
																	printf("\n\t Part_no/RevSeq= %s/%s   NonClrChildCnt==> %d",Part_no,RevSeqTmp,NonClrChildCnt); fflush(stdout);
																	fprintf(fpCLLog,"\n\t Part_no/RevSeq= %s/%s   NonClrChildCnt==> %d",Part_no,RevSeqTmp,NonClrChildCnt); fflush(fpCLLog);
																	for (nc2 = 0; nc2 < NonClrChildCnt; nc2++)
																	{
																		if(Childobject) Childobject=NULLTAG;
																		Childobject=NonClrChilds[nc2];

																		if(AOM_ask_value_string(Childobject, "bl_item_item_id", &NCChild)!=ITK_ok)PrintErrorStack();
																		if(AOM_ask_value_string(Childobject, "bl_rev_item_revision_id", &NCChildRevSeq)!=ITK_ok)PrintErrorStack();
																		if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_ColourInd", &NCChildColInd)!=ITK_ok)PrintErrorStack();
																		if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_PrtCatCode", &NCChildCompCode)!=ITK_ok)PrintErrorStack();
																		//if(BOM_line_ask_attribute_string(Childobject,QuantityAttrId, &NCChildQty)!=ITK_ok)PrintErrorStack();
																		ifail = AOM_UIF_ask_value(Childobject,"bl_quantity",&NCChildQty);

																		NClrQty=atoi(NCChildQty);

																		printf("\n\n  B--nc2: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  Bomline_NClrQty: [%d]",nc2,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode,NClrQty); fflush(stdout);
																		fprintf(fpCLLog,"\n\n  B--nc2: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  Bomline_NClrQty: [%d]",nc2,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode,NClrQty); fflush(fpCLLog);

																		if(tc_strcmp(NCChildColInd,"N")==0)
																		{
																			printf("\t ---child ColInd==> N \n"); fflush(stdout);
																			fprintf(fpCLLog,"\t ---child ColInd==> N \n"); fflush(fpCLLog);
																			if(ITEM_find_item(NCChild,&NCChildItemTag)!=ITK_ok)PrintErrorStack();

																			if(NClrQty==0)
																			{
																				if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																			}
																			else
																			{
																				for (p2=0;p2<NClrQty ;p2++ )
																				{
																					if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																					printf("\n    0-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																					fprintf(fpCLLog,"\n    0-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																				}
																			}
																		}
																		else if(tc_strcmp(NCChildColInd,"Y")==0)
																		{
																			int childExistFl=0;

																			printf("\t ---child ColInd==> Y  NCChildCompCode: %s ",NCChildCompCode); fflush(stdout);

																			if((tc_strstr(NCChildCompCode,"CCA")!=NULL)||(tc_strstr(NCChildCompCode,"VEHICLE")!=NULL)||(tc_strstr(NCChildCompCode,"TPL")!=NULL))
																			{
																				for (k1=0;k1<n_lines1 ;k1++ )
																				{
																					if(clrPartObject) clrPartObject=NULLTAG;
																					clrPartObject=lines1[k1];

																					if(AOM_ask_value_string(clrPartObject, "bl_item_item_id", &t5_clr_item_id)!=ITK_ok)PrintErrorStack();
																					printf("\n\t A--t5_clr_item_id: %s",t5_clr_item_id); fflush(stdout);
																					fprintf(fpCLLog,"\n\t A--t5_clr_item_id: %s",t5_clr_item_id); fflush(fpCLLog);

																					if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
																					printf(" ColourIndC: %s",ColourIndC); fflush(stdout);
																					fprintf(fpCLLog," ColourIndC: %s",ColourIndC); fflush(fpCLLog);

																					if((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0))
																					{
																						if (strstr(t5_clr_item_id,NCChild)!=NULL)
																						{
																							childExistFl=1;

																							//if(BOM_line_ask_attribute_string(clrPartObject,QuantityAttrId, &CCChildQty)!=ITK_ok)PrintErrorStack();
																							//NClrQty=atoi(CCChildQty);

																							break;
																						}
																					}
																				}

																				printf(" n_lines1: %d   childExistFl: %d ",n_lines1,childExistFl); fflush(stdout);

																				if (childExistFl==0)
																				{
																					printf("\n ...---adding child from colour bom and not present in non-col bom.....[%s]=[%d]",NCChild,NClrQty); fflush(stdout);
																					fprintf(fpCLLog,"\n ...---adding child from colour bom and not present in non-col bom.....[%s]=[%d]",NCChild,NClrQty); fflush(fpCLLog);
																					if(ITEM_find_item(NCChild, &CCChildItemTag)!=ITK_ok)PrintErrorStack();

																					if(NClrQty==0)
																					{
																						if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																					}
																					else
																					{
																						for (k2=0;k2<NClrQty;k2++ )
																						{
																							if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																							printf("\n    1-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(stdout);
																							fprintf(fpCLLog,"\n    1-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(fpCLLog);
																						}
																					}
																				}
																			}
																			else ////Comp_code not like CCA% , VEHICLE, TPLS%
																			{
																				char *ClrChildItem = NULL;
																				logical checkout2;
																				int CompCodeClrSrlMatchFlag = 0;
																				t5ClSrl = (char*) malloc(50);

																				t5ClSrl = GetColourSrlFrmSchmCompCodes(CmpCodeOfClrScheme,Cmpcount,NCChildCompCode);
																				printf("\n  CL-B=t5ClSrl from function: %s",t5ClSrl); fflush(stdout);
																				fprintf(fpCLLog,"\n  CL=t5ClSrl from function: %s",t5ClSrl); fflush(fpCLLog);

																				if ((t5ClSrl!=NULL) && (strlen(t5ClSrl)>0))
																				{
																					if(tc_strstr(t5ClSrl,";")!=NULL) {
																						Suffix =  strtok(t5ClSrl,";");
																						ColourID  =  strtok(NULL,";");
																					}
																					else {
																						Suffix =  strtok(t5ClSrl,",");
																						ColourID  =  strtok(NULL,",");
																					}
																					printf("\n\t   CL=Suffix-->: %s  ColourID: 5s ",Suffix,ColourID); fflush(stdout);
																					fprintf(fpCLLog,"\n\t   CL=Suffix-->: %s  ColourID: 5s ",Suffix,ColourID); fflush(fpCLLog);


																					if(tc_strcmp(PartType,"G")==0)
																					{
																						printf("\n  In GroupID if condition===\n"); fflush(stdout);
																						//ResponseStr = NewUniqGroupIDNum();
																						//printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
																						//
																						//ClrChildItem = NULL;
																						//ClrChildItem=(char *) MEM_alloc(25);
																						//strcpy(ClrChildItem,"");
																						//strcat(ClrChildItem,ResponseStr);
																						//printf("\n\t   Colour Part for Group ID---->%s\n",ClrChildItem); fflush(stdout);
																						fflush(stdout);
																					}
																					else
																					{
																						ClrChildItem=(char *) MEM_alloc(25);
																						strcpy(ClrChildItem,"");
																						strcpy(ClrChildItem,NCChild);
																						strcat(ClrChildItem,Suffix);
																					}
																					printf("\n\t   Child_ColPartNo: %s ",ClrChildItem); fflush(stdout);

																					if ( (strlen(ClrChildItem)>0) && (ClrPartQryTag!=NULLTAG) )
																					{
																						CompCodeClrSrlMatchFlag = 1;
																						//printf("\n\t   CM=Found Query 'ClrPart' ClrPartQryTag \n"); fflush(stdout);
																						valuesClrPrt[0] = ClrChildItem;
																						if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &n_ClrChild_tags, &ClrChildTags));
																						printf("\t ClrPart_QryCount------> %d ",n_ClrChild_tags);fflush(stdout);

																						if(ITEM_find_item(NCChild, &ClrItemMstrTag)!=ITK_ok)PrintErrorStack();
																						if(ITEM_ask_latest_rev(ClrItemMstrTag,&ClrItemRevTag)!=ITK_ok)PrintErrorStack();

																						if (n_ClrChild_tags==0)
																						{
																							if(ITEM_create_item(ClrChildItem,ClrChildItem,"T5_ClrPart","NR;1",&ColChilditemMstr,&ColChilditemRev)!=ITK_ok)PrintErrorStack();

																							if(ColChilditemRev != NULLTAG)
																							{
																								printf("\n\t A--T5_ClrPart is created---------->\n");fflush(stdout);
																								fprintf(fpCLLog,"\n\t A--T5_ClrPart is created---------->\n");fflush(fpCLLog);

																								char *t5PrtCatCd = NULL;
																								char *t5object_desc = NULL;
																								char *clrdesc = NULL;
																								char *t5PartStatus = NULL;
																								char *t5DesignGrp = NULL;
																								char *t5ProjectCode = NULL;
																								char *t5DocRemarks = NULL;
																								char *t5DrawingInd = NULL;
																								char *t5PartCode = NULL;
																								char *t5AhdMakeBuyIndicator = NULL;
																								char *t5PunPCBUMakeBuyIndicator = NULL;
																								char *t5PunMakeBuyIndicator = NULL;
																								char *t5DwdMakeBuyIndicator = NULL;
																								char *t5Coated = NULL;
																								char *UnitOfMeasureS = NULL;

																								if( AOM_ask_value_string(NonClrPartTag, "t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "object_desc", &t5object_desc)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_Coated", &t5Coated)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_PartStatus", &t5PartStatus)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_DesignGrp", &t5DesignGrp)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_ProjectCode", &t5ProjectCode)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_DocRemarks", &t5DocRemarks)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_DrawingInd", &t5DrawingInd)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_PartCode", &t5PartCode)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_AhdMakeBuyIndicator", &t5AhdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_PunPCBUMakeBuyIndicator", &t5PunPCBUMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_PunMakeBuyIndicator", &t5PunMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
																								if( AOM_ask_value_string(NonClrPartTag, "t5_DwdMakeBuyIndicator", &t5DwdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();


																								printf("\n\t   2.ClrChildItem ---->%s",ClrChildItem);fflush(stdout);
																								printf("\n\t   2.Col_Ind ---->%s",Col_Ind);fflush(stdout);
																								printf("\n\t   2.t5PrtCatCd---->%s",t5PrtCatCd);fflush(stdout);
																								//printf("\n\t   ColourID---->%s",ColourID);fflush(stdout);
																								//printf("\n\t   t5Coated---->%s",t5Coated);fflush(stdout);
																								//printf("\n\t   t5PartStatus---->%s",t5PartStatus);fflush(stdout);
																								//printf("\n\t   t5DesignGrp---->%s",t5DesignGrp);fflush(stdout);
																								//printf("\n\t   t5ProjectCode---->%s",t5ProjectCode);fflush(stdout);
																								//printf("\n\t   mod_desc---->%s",t5DocRemarks);fflush(stdout);
																								//printf("\n\t   t5DrawingInd---->%s",t5DrawingInd);fflush(stdout);
																								//printf("\n\t   PartType---->%s",PartType);fflush(stdout);
																								//printf("\n\t   t5PartCode---->%s",t5PartCode);fflush(stdout);
																								//printf("\n\t   t5AhdMakeBuyIndicator---->%s",t5AhdMakeBuyIndicator);fflush(stdout);
																								//printf("\n\t   t5PunPCBUMakeBuyIndicator---->%s",t5PunPCBUMakeBuyIndicator);fflush(stdout);
																								//printf("\n\t   t5PunMakeBuyIndicator---->%s",t5PunMakeBuyIndicator);fflush(stdout);
																								printf("\n\t   t5DwdMakeBuyIndicator---->%s",t5DwdMakeBuyIndicator);fflush(stdout);

																								clrdesc=(char *) MEM_alloc(200);
																								strcpy(clrdesc,"");
																								strcpy(clrdesc,ColourID);
																								strcat(clrdesc,"-");
																								strcat(clrdesc,t5object_desc);

																								printf("\n\t   Part Desc ---->%s \n",clrdesc);fflush(stdout);
																								fprintf(fpCLLog,"\n\t   Part Desc ---->%s \n",clrdesc);fflush(fpCLLog);

																								//if(setAttributesOnDesign(&ColChilditemMstr,clrdesc,UnitOfMeasureS)!=ITK_ok)PrintErrorStack();
																								//printf("\n Set Attribute on Class T5_ClrPart------------>\n");fflush(stdout);

																								if(tm_setAttributesOnDesignRev2(&ColChilditemRev,clrdesc,"C",t5PrtCatCd,ColourID,t5Coated,t5PartStatus,t5DesignGrp,t5ProjectCode,t5DocRemarks,t5DrawingInd,PartType,t5PartCode,t5AhdMakeBuyIndicator,t5PunPCBUMakeBuyIndicator,t5PunMakeBuyIndicator,t5DwdMakeBuyIndicator,Part_no)!=ITK_ok)PrintErrorStack();
																								printf("\n\t   Set Attribute on Class T5_ClrPartRevision--------->\n");fflush(stdout);
																								fprintf(fpCLLog,"\n\t   Set Attribute on Class T5_ClrPartRevision--------->\n");fflush(fpCLLog);

																								if(tm_CreateReleasestatus(ColChilditemRev)!=ITK_ok)PrintErrorStack();
																								printf("\n\t   CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(stdout);
																								fprintf(fpCLLog,"\n\t   CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(fpCLLog);

																								if(tm_AssignProject(ColChilditemRev,t5ProjectCode)!=ITK_ok)PrintErrorStack();
																								printf("\n\t   Assign Project to T5_ClrPartsRevision--------->\n");fflush(stdout);
																								fprintf(fpCLLog,"\n\t   Assign Project to T5_ClrPartsRevision--------->\n");fflush(fpCLLog);

																								//Going to update UserOwner Name
																								//if(AOM_set_ownership(ColChilditemRev,user_tag ,group)!=ITK_ok)PrintErrorStack();
																								//printf("\n\t   property Value set...!!\n");fflush(stdout);

																								if (ColChilditemRev!=NULLTAG)
																								{
																									if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
																									{
																										if(GRM_find_relation(NewTskObjOP,ColChilditemRev,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
																										if (ReltnExist==NULLTAG)
																										{
																											if(GRM_create_relation(NewTskObjOP,ColChilditemRev,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
																											if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
																											if(AOM_refresh(reltask,FALSE)!=ITK_ok)PrintErrorStack();
																											printf("\n\t   DML_Task and Revised New ColChild Part Relation is Created Successfully.....\n");fflush(stdout);
																											fprintf(fpCLLog,"\n\t   DML_Task and Revised New ColChild Part Relation is Created Successfully.....\n");fflush(fpCLLog);
																										}
																									}

																									if (tRelationFind!=NULLTAG)
																									{
																										if(GRM_find_relation(ColChilditemRev,ClrItemRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
																										if (tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
																										{
																											if(GRM_create_relation(ColChilditemRev,ClrItemRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
																											printf("\n\t   Child-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
																											fprintf(fpCLLog,"\n\t   Child-Colour-Non_Colour child part Relation Created Successfully \n");fflush(fpCLLog);
																											if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();
																											if(AOM_refresh(Rel_task,FALSE)!=ITK_ok)PrintErrorStack();
																										}
																									}

																									if(AOM_refresh(ColChilditemRev,TRUE)!=ITK_ok)PrintErrorStack();
																									if(AOM_set_value_string(ColChilditemRev,"gov_classification",SchDataToGov)!=ITK_ok)PrintErrorStack();
																									if(AOM_save_without_extensions(ColChilditemRev)!=ITK_ok)PrintErrorStack();
																									if(AOM_refresh(ColChilditemRev,FALSE)!=ITK_ok)PrintErrorStack();
																								}

																								if(NClrQty==0)
																								{
																									if(PS_create_occurrences(clrbvrTag, ColChilditemMstr, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																								}
																								else
																								{
																									for (p2=0;p2<NClrQty ;p2++ )
																									{
																										if(PS_create_occurrences(clrbvrTag, ColChilditemMstr, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																										printf("\n\t 3-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																										fprintf(fpCLLog,"\n\t 3-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																									}
																								}
																							}
																						}
																						else
																						{
																							printf("\nCL=ClrChildItem: %s Already present in PLM-TCUA, hence no need to create....Adding under ClrAssy BVR..\n",ClrChildItem);fflush(stdout);
																							fprintf(fpCLLog,"\nCL=ClrChildItem: %s Already present in PLM-TCUA, hence no need to create....Adding under ClrAssy BVR..\n",ClrChildItem);fflush(fpCLLog);
																							if(NClrQty==0)
																							{
																								if(PS_create_occurrences(clrbvrTag, ClrChildTags[0], NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																							}
																							else
																							{
																								for (p2=0;p2<NClrQty ;p2++ )
																								{
																									if(PS_create_occurrences(clrbvrTag, ClrChildTags[0], NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																									printf("\n\t 4-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																									fprintf(fpCLLog,"\n\t 4-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																								}
																							}
																						}
																					}
																					else
																					{
																						printf("\t -->Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....\n"); fflush(stdout);
																						fprintf(fpCLLog,"\t -->Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....\n"); fflush(fpCLLog);
																					}
																				}

																				if (CompCodeClrSrlMatchFlag==0)
																				{
																					printf("\n\n\t ---Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(stdout);
																					fprintf(fpCLLog,"\n\n\t ---Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(fpCLLog);
																					fprintf(fpCLErrLog,"\n Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(fpCLErrLog);

																					if(ITEM_find_item(NCChild,&NCChildItemTag)!=ITK_ok)PrintErrorStack();

																					if(NClrQty==0)
																					{
																						if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																					}
																					else
																					{
																						for (p2=0;p2<NClrQty ;p2++ )
																						{
																							if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																							printf("\n\n\t   5-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																							fprintf(fpCLLog,"\n\n\t   5-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																						}
																					}
																				}
																			}
																		}
																		else if(tc_strcmp(ChildColInd,"")==0)
																		{
																			printf("\t ---child ColInd==> NULL \n"); fflush(stdout);
																			fprintf(fpCLLog,"\t ---child ColInd==> NULL \n"); fflush(fpCLLog);
																			if(ITEM_find_item(NCChild,&NCChildItemTag)!=ITK_ok)PrintErrorStack();
																			if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																		}
																	} // end of for loop NonClrChildCnt

																	printf("\n\t ColorRevTag--------------------> n_lines1:%d \n",n_lines1); fflush(stdout);
																	fprintf(fpCLLog,"\n\t ColorRevTag-------------------->\n"); fflush(fpCLLog);
																	if ((ColorRevTag!=NULLTAG) && (n_lines1 >0))
																	{
																		for (k1=0;k1<n_lines1 ;k1++ )
																		{
																			int CLChildExistFl=0;

																			if(clrPartObject) clrPartObject=NULLTAG;
																			clrPartObject=lines1[k1];

																			if(AOM_ask_value_string(clrPartObject, "bl_item_item_id", &t5_clr_item_id)!=ITK_ok)PrintErrorStack();
																			if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
																			if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_PrtCatCode", &ClrCompCode)!=ITK_ok)PrintErrorStack();
																			printf("\n\t t5_clr_item_id ===> :: %s  ColourIndC ===> :: %s  ClrCompCode:: %s ",t5_clr_item_id,ColourIndC,ClrCompCode); fflush(stdout);

																			if(((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0)) && ((tc_strstr(ClrCompCode,"CCA")!=NULL)||(tc_strstr(ClrCompCode,"VEHICLE")!=NULL)||(tc_strstr(ClrCompCode,"TPL")!=NULL)))
																			{
																				int nk3=0;
																				char *NCChild2=NULL;

																				for (nk3=0;nk3<NonClrChildCnt ;nk3++ )
																				{
																					if(Childobject) Childobject=NULLTAG;
																					Childobject=NonClrChilds[nk3];

																					if(AOM_ask_value_string(Childobject, "bl_item_item_id", &NCChild2)!=ITK_ok)PrintErrorStack();
																					printf("\n\t\t H--NCChild2: %s",NCChild2); fflush(stdout);
																					fprintf(fpCLLog,"\n\t B--NCChild2: %s",NCChild2); fflush(fpCLLog);

																					if(AOM_ask_value_string(Childobject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
																					printf(" ColourIndC: %s",ColourIndC); fflush(stdout);
																					fprintf(fpCLLog," ColourIndC: %s",ColourIndC); fflush(fpCLLog);

																					if((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0))
																					{
																						if (strstr(t5_clr_item_id,NCChild2)!=NULL)
																						{
																							CLChildExistFl=1;
																							break;
																						}
																					}
																				}
																				printf(" CLChildExistFl: %d ",CLChildExistFl); fflush(stdout);
																				if (CLChildExistFl==1)
																				{
																					//if(BOM_line_ask_attribute_string(clrPartObject,QuantityAttrId, &CCChildQty)!=ITK_ok)PrintErrorStack();
																					ifail = AOM_UIF_ask_value(clrPartObject,"bl_quantity",&CCChildQty);
																					CClrQty=atoi(CCChildQty);

																					if(ITEM_find_item(t5_clr_item_id, &CCChildItemTag)!=ITK_ok)PrintErrorStack();

																					if(CClrQty==0)
																					{
																						if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																					}
																					else
																					{
																						for (k2=0;k2<CClrQty;k2++ )
																						{
																							if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																							printf("\n    6-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(stdout);
																							fprintf(fpCLLog,"\n    6-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(fpCLLog);
																						}
																					}
																				}
																			}
																		} //for loop end
																	}
																	//--END--Adding Childs under New Colour Assy bvr-----------
																	}
																	printf("\n After clrbvrTag creation ---");fflush(stdout);
																	//printf(fpCLLog,"\n After clrbvrTag creation ---");fflush(fpCLLog);
																	fprintf(fpCLLog,"\n After clrbvrTag creation...");fflush(fpCLLog);
																	if(AOM_save_without_extensions(clrbvrTag)!=ITK_ok)PrintErrorStack();
																	if(AOM_refresh(clrbvrTag,FALSE)!=ITK_ok)PrintErrorStack();
																	printf("\t clrbvrTag is saved...");fflush(stdout);
																	fprintf(fpCLLog,"\t clrbvrTag is saved...");fflush(fpCLLog);

																	printf("\n\n CntrlObjCntCL: [%d]",CntrlObjCntCL);fflush(stdout);
																	fprintf(fpCLLog,"\n\n CntrlObjCntCL: [%d]",CntrlObjCntCL);fflush(fpCLLog);

																	if (CntrlObjCntCL>0)
																	{
																		printf("\n\n ...................Checking for multi-level colourable childs........................CntrlObjCntCL: [%d]",CntrlObjCntCL);fflush(stdout);
																		fprintf(fpCLLog,"\n\n Checking for multi-level colourable childs....CntrlObjCntCL: [%d]",CntrlObjCntCL);fflush(fpCLLog);

																		for (nc3 = 0; nc3 < NonClrChildCnt; nc3++)
																		{
																			if(NClrChildobject) NClrChildobject=NULLTAG;
																			NClrChildobject=NonClrChilds[nc3];

																			if(AOM_ask_value_string(NClrChildobject, "bl_item_item_id", &NCChild)!=ITK_ok)PrintErrorStack();
																			if(AOM_ask_value_string(NClrChildobject, "bl_rev_item_revision_id", &NCChildRevSeq)!=ITK_ok)PrintErrorStack();
																			if(AOM_ask_value_string(NClrChildobject, "bl_Design Revision_t5_ColourInd", &NCChildColInd)!=ITK_ok)PrintErrorStack();
																			if(AOM_ask_value_string(NClrChildobject, "bl_Design Revision_t5_PrtCatCode", &NCChildCompCode)!=ITK_ok)PrintErrorStack();

																			printf("\n\n  nc3: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  ",nc3,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode); fflush(stdout);
																			fprintf(fpCLLog,"\n\n  nc3: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s] ",nc3,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode); fflush(fpCLLog);

																			if((tc_strcmp(NCChildColInd,"Y")==0) && ((tc_strstr(NCChildCompCode,"CCA")==NULL)&&(tc_strstr(NCChildCompCode,"VEHICLE")==NULL)&&(tc_strstr(NCChildCompCode,"TPL")==NULL)))
																			{
																				printf("\t Inside Condition---"); fflush(stdout);
																				fprintf(fpCLLog,"\t Inside Condition---"); fflush(fpCLLog);

																				int MultiLvlBomSt = ValMultiLvlBomForScheme_CL(NClrChildobject,SchmRefTag,CmpCodeOfClrScheme,Cmpcount,SchmName,SchmRev,NewTskObjOP);
																				printf("\n\n\t   ValMultiLvlBomForScheme_CL----MultiLvlBomSt: ",MultiLvlBomSt); fflush(stdout);
																				fprintf(fpCLLog,"\n\n\t   ValMultiLvlBomForScheme_CL----MultiLvlBomSt: ",MultiLvlBomSt); fflush(fpCLLog);
																			}
																		}
																	} //End for loop

																} //End for condn if(NewColorRevTag!=NULLTAG)
																} //End of condn checkout
																} // Else of (ReviseStatus==0)&&(strlen(NonClrChildSet)==0)
															}
															else
															{
																printf("\t ---A--No need to revive Colour: %s/%s [%s]",ColItem,ColPartRev,ColPrtLatestRlzSt);fflush(stdout);
																fprintf(fpCLLog,"\t ---A--No need to revive Colour: %s/%s [%s]",ColItem,ColPartRev,ColPrtLatestRlzSt);fflush(fpCLLog);
															}
														}
													} //End of if (t5ClSrl!=NULL)
													else
													{
														printf("\n\t\t No comp-code or colourSrl match found, hence skipping ??? \n\n"); fflush(stdout);
														fprintf(fpCLLog,"\n\t\t No comp-code or colourSrl match found, hence skipping ??? \n\n"); fflush(fpCLLog);
													}
												}
											}
											else
											{
												printf("\n\t\t Tag of SchmWithCmpcdRel is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(stdout);
												fprintf(fpCLLog,"\n\t\t Tag of SchmWithCmpcdRel is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(fpCLLog);
											}
										}
										else
										{
											printf("\n\t\t Tag of SchmRefTag is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(stdout);
											fprintf(fpCLLog,"\n\t\t Tag of SchmRefTag is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(fpCLLog);
										}

										if (MatchColSchemeFlag==0)
										{
											printf("\n\t  No matching Scheme found for ColPartNo: %s , hence skipping ???? ",ColPartNo); fflush(stdout);
											fprintf(fpCLLog,"\n\t  No matching Scheme found for ColPartNo: %s , hence skipping ???? ",ColPartNo); fflush(fpCLLog);
											fprintf(fpCLErrLog,"\nNo matching Scheme found for ColPartNo: %s , hence skipping ???? ",ColPartNo); fflush(fpCLErrLog);

											if (strlen(NoColSchemeMatchPrts)==0)
											{
												strcpy(NoColSchemeMatchPrts,ColPartNo);
												strcat(NoColSchemeMatchPrts,",");
											}
											else
											{
												strcat(NoColSchemeMatchPrts,ColPartNo);
												strcat(NoColSchemeMatchPrts,",");
											}
										}
										// ----------------Colour Scheme-END---------------------------------------------
									} //End of loop for(zp = 0; zp<ClrCount; zp++)
								} //End of condn if(ClrCount>0)
							} //End of condn if(tRelationFind!=NULLTAG)
							// ----------------END--Get Colour Parts---------------------------------------------
			//					} //End of condn if (strlen(NonClrChildSet)>2)
			//					else
			//					{
			//						printf("---No NC-Rev bom difference present...\n"); fflush(stdout);
			//					}
							break;
						} //if end of LatestRlzSt
					} //for loop end of RlzStatusCnt

					if (RlzRevFlag==0)
					{
						printf("\t----Attached Non-colour is not in ERC Review Status, hence skipping its colour colour part ??? \n");fflush(stdout);
						fprintf(fpCLLog,"\t----Attached Non-colour is not in ERC Review Status, hence skipping its colour colour part ??? \n");fflush(fpCLLog);
					}
					/*else
					{
						tc_strcpy(NewColourPart,"");
					}*/
				} //if end of RlzStatusCnt
				else
				{
					tc_strcpy(NewColourPart,"");
				}
			} //if end of Col_Ind=Y && (strlen(Comp_Code)>0)
			else
			{
				printf("\t ----Skipping Non-colour part of col ind=N ????\n"); fflush(stdout);
				fprintf(fpCLLog,"\t ----Skipping Non-colour part of col ind=N ????\n"); fflush(fpCLLog);
			}

			printf("\n===============================================================================================================================================================\n");fflush(stdout);
			fprintf(fpCLLog,"\n===============================================================================================================================================================\n");fflush(fpCLLog);
			
			return ITK_ok;
		}

		int setAttributesOnDesign(tag_t* item,char* desc,char* UnitOfMeasureS)
		{
			int status;
			char* ent_uom=NULL;
			tag_t unit_of_measure=NULLTAG;

			if(AOM_set_value_string(*item,"object_desc",desc)!=ITK_ok)PrintErrorStack();
			if(AOM_save_without_extensions(*item)!=ITK_ok)PrintErrorStack();

			//ent_uom=(char *) MEM_alloc(10 * sizeof(char *));
			//
			//if(strcmp(UnitOfMeasureS,"1")==0){strcpy(ent_uom,ONE);}
			//else if(strcmp(UnitOfMeasureS,"2")==0){strcpy(ent_uom,TWO);}
			//else if(strcmp(UnitOfMeasureS,"3")==0){strcpy(ent_uom,THREE);}
			//else if(strcmp(UnitOfMeasureS,"4")==0){strcpy(ent_uom,FOUR);}
			//else if(strcmp(UnitOfMeasureS,"5")==0){strcpy(ent_uom,FIVE);}
			//else if(strcmp(UnitOfMeasureS,"6")==0){strcpy(ent_uom,SIX);}
			//else if(strcmp(UnitOfMeasureS,"7")==0){strcpy(ent_uom,SEVEN);}
			//else if(strcmp(UnitOfMeasureS,"8")==0){strcpy(ent_uom,EIGHT);}
			//else {
			//	strcpy(ent_uom,FOUR);
			//}
			//
			//if((strcmp(ent_uom,"FOUR")!=0) && (strcmp(ent_uom,"4-Nos")!=0))
			//{
			//	if(UOM_find_by_symbol(ent_uom,&unit_of_measure)!=ITK_ok)PrintErrorStack();
			//	printf("\n ent_uom:%s  \n",ent_uom);fflush(stdout);
			//	if(ITEM_set_unit_of_measure(*item, unit_of_measure)!=ITK_ok)PrintErrorStack();
			//}
			//if(AOM_save_without_extensions(*item)!=ITK_ok)PrintErrorStack();
		}

		int tm_setAttributesOnDesignRev2(tag_t* rev,char* desc,char* ColourIndS,char* t5PrtCatCodeS,char* t5ColourIDS,char* t5CoatedS,char* t5PartStatusS,char* designgroup,char* projectcode,char* mod_desc,char* DrawingIndS,char * PartTypeS,char * t5PartCodeS,char * t5AhdMakeBuyIndS,char * t5PunPCBUMakeBuyIndS,char * t5PunMakeBuyIndS,char * t5DwdMakeBuyIndS,char * NonColorPart)
		{
			int status;
			double dweight=0;
			tag_t  projobj=NULLTAG;
			printf ( "\n SchDataToGov33333333333333333333 is -------> %s\n",SchDataToGov);fflush(stdout);
			fprintf (fpCLLog,"\n SchDataToGov33333333333333333333 is -------> %s\n",SchDataToGov);fflush(fpCLLog);

			if(AOM_refresh(*rev,TRUE)!=ITK_ok)PrintErrorStack();	
			if(AOM_set_value_string(*rev,"object_desc",desc)!=ITK_ok)PrintErrorStack();
			if(AOM_set_value_string(*rev,"t5_ColourInd",ColourIndS)!=ITK_ok)PrintErrorStack();
			if(AOM_set_value_string(*rev,"t5_PrtCatCode",t5PrtCatCodeS)!=ITK_ok)PrintErrorStack();
			if(AOM_set_value_string(*rev,"t5_ColourID",t5ColourIDS)!=ITK_ok)PrintErrorStack();
			if(AOM_set_value_string(*rev,"t5_Coated",t5CoatedS)!=ITK_ok)PrintErrorStack();
			if(AOM_set_value_string(*rev,"t5_NcPartNo",NonColorPart)!=ITK_ok)PrintErrorStack();
			if(AOM_set_value_string(*rev,"t5_PartStatus",t5PartStatusS)!=ITK_ok)PrintErrorStack();
			if(AOM_set_value_string(*rev,"t5_DesignGrp",designgroup)!=ITK_ok)PrintErrorStack();
			if(AOM_set_value_string(*rev,"t5_ProjectCode",projectcode)!=ITK_ok)PrintErrorStack();
			if(AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc)!=ITK_ok)PrintErrorStack();
			if(AOM_set_value_string(*rev,"gov_classification",SchDataToGov)!=ITK_ok)PrintErrorStack();

			if(AOM_set_value_string(*rev,"t5_DrawingInd",DrawingIndS)!=ITK_ok)PrintErrorStack();
			if (strstr(PartTypeS,"D")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","D")!=ITK_ok)PrintErrorStack(); }
			if (strstr(PartTypeS,"A")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","A")!=ITK_ok)PrintErrorStack(); }
			if (strstr(PartTypeS,"C")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","C")!=ITK_ok)PrintErrorStack(); }
			if (strstr(PartTypeS,"VC")!=NULL){ if( AOM_set_value_string(*rev,"t5_PartType","VC")!=ITK_ok)PrintErrorStack();}
			if (strstr(PartTypeS,"V")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","V")!=ITK_ok)PrintErrorStack(); }

			if(AOM_set_value_string(*rev,"t5_PartCode",t5PartCodeS)!=ITK_ok)PrintErrorStack();
			if(tc_strcmp(t5AhdMakeBuyIndS,"-")==0)	{
				if(AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
			}else
			{
				if(AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator",t5AhdMakeBuyIndS)!=ITK_ok)PrintErrorStack();
			}

			if(tc_strcmp(t5PunPCBUMakeBuyIndS,"-")==0) { 
				if(AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
			}else
			{
				if(AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator",t5PunPCBUMakeBuyIndS)!=ITK_ok)PrintErrorStack();
			}

			if(tc_strcmp(t5PunMakeBuyIndS,"-")==0) { 
				if(AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
			}else
			{
				if(AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",t5PunMakeBuyIndS)!=ITK_ok)PrintErrorStack();
			}
			
			if(tc_strcmp(t5DwdMakeBuyIndS,"-")==0) {
				if(AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
			}else
			{
				if(AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator",t5DwdMakeBuyIndS)!=ITK_ok)PrintErrorStack();
			}	
				
			if(AOM_save_without_extensions(*rev)!=ITK_ok)PrintErrorStack();
			if(AOM_refresh(*rev,FALSE)!=ITK_ok)PrintErrorStack();
		}
		int tm_CreateReleasestatus(tag_t ColourRev)
		{
			tag_t   release_status =NULLTAG;
			char   *ReleaseStatus=NULL;
			char* ReviewStatus=NULL;
			int status;
			int		ifail	=0;
			int	   status_count=0;
			tag_t* status_list = NULLTAG;
			logical  retain_released_date =false;

			ReviewStatus =(char *) MEM_alloc(20 * sizeof(char *));
			tc_strcpy(ReviewStatus,"T5_LcsReview");
			printf("\n\t ReviewStatus --> %s",ReviewStatus);fflush(stdout);
			fprintf(fpCLLog,"\n\t ReviewStatus --> %s",ReviewStatus);fflush(fpCLLog);

			if((strcmp(ReviewStatus,"T5_LcsReview")==0))
			{
				if(ITK_ok != (ifail = WSOM_ask_release_status_list(ColourRev,&status_count,&status_list)))
				{
				   return ifail;
				}
				printf("\n\t REV status_count: %d",status_count);fflush(stdout);
				fprintf(fpCLLog,"\n\t REV status_count: %d",status_count);fflush(fpCLLog);
				if (status_count == 0)
				{
					printf("---No Status, so the Item is not yet Released....");fflush(stdout);
					printf(" *****  Stamping Releasing item  *****");fflush(stdout);
					if(ITK_ok != (ifail = RELSTAT_create_release_status(ReviewStatus,&release_status)))	 return ifail;
					if(ITK_ok != (ifail = AOM_ask_name(release_status, &ReleaseStatus))) return ifail;
					printf("\t ReleaseStatus: %s \n",ReleaseStatus);fflush(stdout);
					fprintf(fpCLLog,"\t ReleaseStatus: %s \n",ReleaseStatus);fflush(fpCLLog);
					if( RELSTAT_add_release_status(release_status,1,&ColourRev,retain_released_date)!=ITK_ok)PrintErrorStack();
				}
			}
			return status;
		}
		int tm_AssignProject(tag_t  itemRev,char* projectcode)
		{
			int status;
			tag_t  projobj=NULLTAG;
			char* username=NULL;
			tag_t user_tag=NULLTAG;

			printf("\n projectcode [%s]\n",projectcode);fflush(stdout);
			fprintf(fpCLLog,"\n projectcode [%s]\n",projectcode);fflush(fpCLLog);
			if(PROJ_find(projectcode,&projobj)!=ITK_ok)PrintErrorStack();
			printf("\n Assigned to Project111\n");fflush(stdout);

			if(projobj !=NULLTAG)
			{
				if(PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev)!=ITK_ok)PrintErrorStack();
				printf("\n Assigned to Project\n");fflush(stdout);
				fprintf(fpCLLog,"\n Assigned to Project\n");fflush(fpCLLog);
			}
			else
			{
				printf("\n Project not found\n");fflush(stdout);
				fprintf(fpCLLog,"\n Project not found\n");fflush(fpCLLog);
			}
		  return status;
		}

		int tm_OccurSetTopLineClr(tag_t  clrbvrTag, char* UsesPartNo)
		{
			int stat = ITK_ok;
			int status;
			int ifail = ITK_ok;
			tag_t UseMaster = NULLTAG;
			tag_t Nrev = NULLTAG;
			char *ChildPartNo = NULL;
			char *ChildPartRevSeq = NULL;
			tag_t objNameType=NULLTAG;
			char *type_name=NULL;
			tag_t *occs=NULL;

			printf("\n Uses Part Number is ------> %s",UsesPartNo);fflush(stdout);
			if(ITEM_find_item(UsesPartNo,&UseMaster)!=ITK_ok)PrintErrorStack();
			printf("\n UseMaster found------>");fflush(stdout);
			
			if(ITEM_ask_latest_rev(UseMaster, &Nrev)!=ITK_ok)PrintErrorStack();
			printf("\n Childrev found------>");fflush(stdout);
			
			if(AOM_ask_value_string(Nrev,"item_id",&ChildPartNo)!=ITK_ok)PrintErrorStack();
			if(AOM_ask_value_string(Nrev,"item_revision_id",&ChildPartRevSeq)!=ITK_ok)PrintErrorStack();
			printf("\n ChildPartNo: %s--%s ..............",ChildPartNo,ChildPartRevSeq);fflush(stdout);

			if(TCTYPE_ask_object_type(Nrev,&objNameType)!=ITK_ok)PrintErrorStack();
			if(TCTYPE_ask_name2(objNameType,&type_name)!=ITK_ok)PrintErrorStack();
			printf("\t type_name:: [%s] \n",type_name);

			if(PS_create_occurrences(clrbvrTag, UseMaster, NULLTAG,1, &occs )!=ITK_ok)PrintErrorStack();
			printf("\n PS_create_occurrences successfully in PSE------->");fflush(stdout);

			if(AOM_save_without_extensions( clrbvrTag) !=ITK_ok)PrintErrorStack();
			printf("\n AOM_save_without_extensions successfully of clrbvrTag------->");fflush(stdout);

			if(AOM_refresh(clrbvrTag,FALSE)!=ITK_ok)PrintErrorStack();
			printf("\n AOM_refresh successfully of clrbvrTag------->\n"); fflush(stdout);

			return ITK_ok;
		}
		int cl_task_deletion( EPM_action_message_t msg )
		{
			int			ifail		= 0;
			int         stat        = ITK_ok;
			char*		username	= NULL;
			char*		CLinfo3	= NULL;
			char*		CLinfo1	= NULL;
			tag_t		user_tag	= NULLTAG;
			int n_entries11 =2;
			tag_t	Cntl_obj_Qtag11	=	NULLTAG;
			char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
			char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
			int resultCount11=0;
			tag_t *qry_cntrlobj11= NULLTAG;
			tag_t  rootTask			= NULLTAG;
			int    noAttachment=0;
			tag_t  *attachments		= NULLTAG;
			tag_t  DMLTag = NULLTAG;
			tag_t  dml_tagCL = NULLTAG;
			char   *Item_id = NULL;
			char   *DMLProjS = NULL;
			char   *Item_idCL = NULL;
			char   *dml_project = NULL;
			char   *DMLIDNo = NULL;
			tag_t DMLRevProjTag = NULLTAG;
			tag_t DMLRevTagCL = NULLTAG;
			tag_t  objTypTag		= NULLTAG;
			char   *ObjTyp=NULL;
			int i= 0;
			char command[512];

			CALLAPI(POM_get_user(&username,&user_tag));
			printf("\n CLD:Starting for taskbreskdownnn of CL Task deletion----------->%s\n",username);fflush(stdout);

			CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n CLD:EPM_ask_root_task----------> \n"); fflush(stdout);

			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
			printf("\n CLD:Target Attachment--------------->%d\n",noAttachment);fflush(stdout);

			if(noAttachment > 0) 
			{
				for(i=0;i<noAttachment;i++)
				{
					printf("\nCLD:******* cl_task_deletion INSIDE Attachments  ********\n");fflush(stdout);
					if(TCTYPE_ask_object_type(attachments[i],&objTypTag));
					if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
					printf("\n CLD:********** cl_task_deletion Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);
					if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0 || tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
					{
						
					   DMLTag = attachments[i];
					   
					   break;
					}
				}	

			}

			if ( DMLTag != NULLTAG )
			{		
				CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&Item_idCL));
				printf("\n CLD:DML Item_id for CL is : %s\n",Item_idCL);fflush(stdout);

				DMLIDNo = subString(Item_idCL,0,10);
				printf("\n CLD:DMLIDNo----------->%s\n",DMLIDNo); fflush(stdout);

				//CALLAPI(ITEM_find_item(DMLIDNo, &dml_tagCL));
				//if (dml_tagCL != NULLTAG)
				{			
					//CALLAPI(ITEM_ask_latest_rev(dml_tagCL, &DMLRevTagCL));
					//CALLAPI(AOM_ask_value_string(DMLRevTagCL,"t5_cprojectcode",&dml_project));
					//printf("\n dml_project is : %s\n",dml_project);fflush(stdout);
			
					CALLAPI(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
					qry_values11[0] = "CLdel";   //CLdel-CLdelCLTask
					//qry_values11[1] =  dml_project;
					qry_values11[1] =  "CLdelCLTask"; 
					CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
					printf("\n CLD:Control Object count for CL Task---------->%d\n",resultCount11);fflush(stdout);
					if(resultCount11 > 0)
					{
						if (AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo3",&CLinfo3)!=ITK_ok)   PrintErrorStack();
						if (AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&CLinfo1)!=ITK_ok)   PrintErrorStack();
					

						printf("\n CL-info3: [%s]   \n", CLinfo3);fflush(stdout);
						if(tc_strstr(CLinfo3,"CLCHECK")!=NULL)
						{
							printf("\n CLD:CL task deletion  is calling..................\n");fflush(stdout);
							printf("\n UAPROD:Task name: %s ", DMLIDNo);fflush(stdout);
							printf("\n UAPROD:t5_Userinfo1 %s ", CLinfo1);fflush(stdout);
							sprintf(command,"%s %s",CLinfo1,DMLIDNo);///user/uaprod/TC_ROOT12/bin/tml_tools/CLdeletion.sh
							TC_write_syslog("Command = %s\n",command);
							system(command);
						}
								
					}
					else
					{
						printf("\n CLD:Control object not available Hence DML not go for CL task deletion--------------->\n"); fflush(stdout);
					}
					
				}
			}

			return ITK_ok;
		}
				/***************************************************************************
		* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
		*
		* This software is the confidential and proprietary information of TTL.
		* You shall not disclose such confidential information and shall use it
		* only in accordance with the terms of the license agreement.
		*
		*  Author               :   Nilesh Patil
		*  Module               :   Workflow Rule Handler to Check the Workflow is aborted or not for DML
		*  Code                 :   tm_workflow_chck_clrschm
		*  Created on			:   Jul 17th, 2025
		*  Modification History :
		* S.No    Date                  CR No     Modified By            Modification Notes
		***************************************************************************/
		
		#define ITK_Prjerr (EMH_USER_error_base + 8)
		//#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}
		//#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
		
		
		/*
			Rule Handler		:		tm_workflow_chck_clrschm
			Description			:		This handler ensure the Workflow is aborted or not for DMl
		*/
		
		EPM_decision_t tm_workflow_chck_clrschm(EPM_rule_message_t msg)
		{
			int   i							= 0;
			int   attachmentCount			= 0;
			char*   obj_type=NULL;
			tag_t rootTask_t				= NULLTAG;
			tag_t *taskAttachments			= NULLTAG;
			tag_t  objTypTag				= NULLTAG;	
			char*	 ClrschmNumb			= NULL;
			char*	 DMLtp			= NULL;
			char*	 info1_value	= NULL;
			char*	 info2_value	= NULL;
			char*	 parent_name	= NULL;
			char*	 ClrschmStatus	= NULL;
			logical  	 DMLProcess =FALSE;	
			
			char*	 dmltype_name			= NULL;
			int		Chk_count		=0;
			int		CtrObjQryCount				=0;
			int		sdk				=0;
			int		wflcount				=0;
			int		tt				=0;
			int		t				=0;
			int		kk				=0;
			int		entry_c			=1;
			int		tskcount	=0;
			tag_t	DMLRevTag		= NULLTAG;
			
		
			tag_t	job_Tag3		=NULLTAG;
			tag_t	CtrObjQry		=NULLTAG;
			tag_t	jobtype_Tag3	=NULLTAG;
			tag_t	rootTask		=NULLTAG;
			tag_t	*CntObj_tag		=NULLTAG;
			tag_t	*wfltag		=NULLTAG;
			tag_t	*subtask		=NULLTAG;
		
			char		*Qry_entry[1]	= {"SYSCD"};
			char		**Qry_values    = (char **) MEM_alloc(10 * sizeof(char *));
		
			EPM_decision_t decision = EPM_go;
			printf("\n tm_workflow_chck_clrschm Function started...");fflush(stdout);
			TC_write_syslog("\n tm_workflow_chck_clrschm Function started...");
		
			ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
			ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));
			
			if(attachmentCount >0)
			{
				for(i=0;i<attachmentCount;i++)
				{
					if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
					if(TCTYPE_ask_name2(objTypTag,&obj_type));
					printf("\n ********** tm_workflow_chck_clrschm Workfow obj type: [%s]*************\n", obj_type);fflush(stdout);
		
					if(tc_strcasecmp(obj_type,"T5_clschmRevision")==0)
					{
						printf("\n\t Colour_Scheme_Found \n");fflush(stdout);
		
						DMLRevTag=taskAttachments[i];
		
						ITK_CALL(AOM_ask_value_string(DMLRevTag,"item_id",&ClrschmNumb));
						
						printf("\n\t MT: ClrschmNumb:%s  \n",ClrschmNumb);fflush(stdout);
						ITK_CALL(AOM_UIF_ask_value(DMLRevTag,"release_status_list",&ClrschmStatus));

						printf("\n\t MT: Colour Scheme Status:%s  \n",ClrschmStatus);fflush(stdout);
						if((tc_strstr(ClrschmStatus,"ERC Released")!=NULL) ||  (tc_strstr(ClrschmStatus,"T5_LcsErcRlzd")!=NULL))
						{
							EMH_clear_errors();
							EMH_store_error_s1(EMH_severity_error,ITK_err,"ERROR: The Colour Scheme is already in the released state. Please revise it and try again..");
							decision = EPM_nogo;
							return decision;

						}
						else
						{

		
		
							if(QRY_find2("ControlObjects", &CtrObjQry));
							if (CtrObjQry)
							{
								printf("\n\t ControlObjects Query_found \n");fflush(stdout);
							}
							else
							{
								printf("\n\t ControlObjects Query_Not_Found \n");fflush(stdout);
							}
							
							Qry_values[0] = "WRKFLOWCHKFORCLRSCHM" ;
							
							if(QRY_execute(CtrObjQry, entry_c, Qry_entry, Qry_values, &CtrObjQryCount, &CntObj_tag));
							printf("\n\t ControlObjects Count = %d \n",CtrObjQryCount);fflush(stdout);
							
							if(CtrObjQryCount>0)
							{
								for (sdk=0; sdk < CtrObjQryCount; sdk++)
								{
									//ON/OFF
									if(AOM_ask_value_string(CntObj_tag[sdk],"t5_Userinfo1",&info1_value));
									printf("\n ControlObjects Value1 = %s \n",info1_value);fflush(stdout);
									TC_write_syslog("\n ControlObjects Value1 = %s \n",info1_value);
									
									if(AOM_ask_value_string(CntObj_tag[sdk],"t5_Userinfo2",&info2_value));
									printf("\n ControlObjects Value2 = %s \n",info2_value);fflush(stdout);
									TC_write_syslog("\n ControlObjects Value2 = %s \n",info2_value);
							
									if(tc_strstr(info1_value,"WFLOW001")==NULL)
									{
										if(AOM_ask_value_string(DMLRevTag,"item_id",&ClrschmNumb));
										printf("\n MT: ClrschmNumb:%s \n",ClrschmNumb);fflush(stdout);
										TC_write_syslog("\n MT: ClrschmNumb:%s\n",ClrschmNumb);
										if(AOM_ask_value_tags(DMLRevTag,"fnd0AllWorkflows",&wflcount,&wfltag));
										printf("\n wflcount %d \n",wflcount);fflush(stdout);
										TC_write_syslog("\n MT: wflcount:%d\n",wflcount);
										if(wflcount>1)
										{
											EMH_clear_errors();
											EMH_store_error_s1(EMH_severity_error,ITK_err,"ERROR: Please get the current Workflow aborted and then try to resubmit the colour scheme into workflow.");
											decision = EPM_nogo;
											return decision;
										}
									}
								}
							}
						}
					}//scheme				
				}
			}
			printf("\n tm_workflow_check Function end...");fflush(stdout);
			TC_write_syslog("\n tm_workflow_check Function end...");
			return decision;
		}
		int ClrsuffixSelction( EPM_action_message_t msg )
		{
			int no_attach,i,SchComCnt,st,resultCount11			= 0;
			int n_entries11 = 2;
			tag_t  roottask			= NULLTAG;
			tag_t  objTypTag		= NULLTAG;
			tag_t  Cntl_obj_Qtag11		= NULLTAG;
			tag_t  *taskAttachments	= NULLTAG;
			tag_t  *qry_cntrlobj11	= NULLTAG;
			tag_t  *SchHcoldata	= NULLTAG;
			char   *ObjTyp=NULL;
			char   *ClrschmRevNumber=NULL;
			char   *ClrschmRevSeqNumber=NULL;
			char   *ClrschmNumber=NULL;
			char   *ClrSuffInp=NULL;
			char   *strinfo1=NULL;
			char   *strinfo2=NULL;
			char   *ClrschmRevNumberdup=NULL;
			char   *ClrschmRevSeqNumber1=NULL;
			ClrSuffInp = MEM_alloc(300);
			char command[512];


			char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
			char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
			

			if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
			if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
			printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);
			if(no_attach > 0)
			{
				CALLAPI(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
					qry_values11[0] = "Suffix";
					//qry_values11[1] =  dml_project;
					qry_values11[1] =  "SelectionClrWf"; // for ALTROZ way projects 5442,5485, etc
					CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
					printf("\n Control Object count for CL Task---------->%d\n",resultCount11);fflush(stdout);
					if(resultCount11 > 0)
					{
						ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo1",&strinfo1));
						ITKCALL(AOM_ask_value_string(qry_cntrlobj11[0],"t5_Userinfo2",&strinfo2));
						printf("\n strinfo1::==>>>> [%s]", strinfo1);fflush(stdout);
						if(tc_strcmp(strinfo1,"ClrWfSuffixON")==0)
						{
							for(i=0;i<no_attach;i++)
							{
								printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);
								if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
								if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
								printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);
								if(tc_strcmp(ObjTyp,"T5_clschmRevision")==0)
								{
									CALLAPI(AOM_ask_value_string(taskAttachments[i],"item_id",&ClrschmNumber));
									CALLAPI(AOM_ask_value_string(taskAttachments[i],"current_revision_id",&ClrschmRevNumber));
									printf("\n ClrschmNumber::==>>>> [%s] ClrschmRevNumber [%s]", ClrschmNumber,ClrschmRevNumber);fflush(stdout);
									//CALLAPI(AOM_ask_value_string(taskAttachments[i],"sequence_id",&ClrschmRevSeqNumber));
									ClrschmRevNumberdup = strdup(ClrschmRevNumber);
									ClrschmRevSeqNumber1= tc_strtok(ClrschmRevNumber,";");
									ClrschmRevSeqNumber = tc_strtok(NULL,";");
									printf("\n ClrschmNumber::==>>>> [%s] ClrschmRevNumber [%s] ClrschmRevSeqNumber[%s]", ClrschmNumber,ClrschmRevNumberdup,ClrschmRevSeqNumber);fflush(stdout);

									tc_strcpy(ClrSuffInp,"");
									    
									tc_strcat(ClrSuffInp,ClrschmNumber);   //./UpdateClrSchmData.sh "CLRSCM_X445EV_25_0050" "NR;1#1"
									tc_strcat(ClrSuffInp," "); 
									tc_strcat(ClrSuffInp,ClrschmRevNumberdup); 
									tc_strcat(ClrSuffInp,"#"); 
									tc_strcat(ClrSuffInp,ClrschmRevSeqNumber); 
									printf("\n ClrSuffInp::==>>>> [%s]", ClrSuffInp);fflush(stdout);
									printf("\n strinfo2::==>>>> [%s]", strinfo2);fflush(stdout);

									sprintf(command,"%s %s",strinfo2,ClrSuffInp);
									TC_write_syslog("Command = %s\n",command);
									system(command);
								}
							}
						}
						else
						{
							printf("\nControl  Object is OFF\n");fflush(stdout);
						}
					}

			}
			return ITK_ok;
		}

		int cl_task_status( EPM_action_message_t msg )
		{		
			int			ifail		= 0;
			int         stat        = ITK_ok;
			char*		username	= NULL;
			tag_t		user_tag	= NULLTAG;
			int n_entries11 =2;
			tag_t	Cntl_obj_Qtag11	=	NULLTAG;
			char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
			char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
			int resultCount11=0;
			tag_t *qry_cntrlobj11= NULLTAG;
			tag_t  rootTask			= NULLTAG;
			int    noAttachment=0;
			tag_t  *attachments		= NULLTAG;
			tag_t  DMLTag = NULLTAG;
			tag_t  dml_tagCL = NULLTAG;
			char   *Item_id = NULL;
			char   *DMLProjS = NULL;
			char   *Item_idCL = NULL;
			char   *dml_project = NULL;
			char   *DMLIDNo = NULL;
			tag_t DMLRevProjTag = NULLTAG;
			tag_t DMLRevTagCL = NULLTAG;
			tag_t  objTypTag		= NULLTAG;
			char   *ObjTyp=NULL;
			int i= 0;

			//12PP555556 - DML for CL Creation on uadev
			CALLAPI(POM_get_user(&username,&user_tag));
			printf("\n Starting for taskbreskdownnn of CL Task----------->%s\n",username);fflush(stdout);
			
			CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n EPM_ask_root_task----------> \n"); fflush(stdout);

			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
			printf("\n Target Attachment--------------->%d\n",noAttachment);fflush(stdout);

			if(noAttachment > 0) 
			{	
				 for(i=0;i<noAttachment;i++)
				  {
					printf("\n******* cl_task_status INSIDE Attachments  ********\n");fflush(stdout);
					if(TCTYPE_ask_object_type(attachments[i],&objTypTag));
					if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
					printf("\n ********** cl_task_status Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);
				if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0 || tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
					{
						
					   DMLTag = attachments[i];
					   
					   break;
					}
				 }		
		
			}

			if ( DMLTag != NULLTAG )
			{		
				CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&Item_idCL));
				printf("\n DML Item_id for CL is : %s\n",Item_idCL);fflush(stdout);

				DMLIDNo = subString(Item_idCL,0,10);
				printf("\n DMLIDNo----------->%s\n",DMLIDNo); fflush(stdout);

				//CALLAPI(ITEM_find_item(DMLIDNo, &dml_tagCL));
				//if (dml_tagCL != NULLTAG)
				{			
					//CALLAPI(ITEM_ask_latest_rev(dml_tagCL, &DMLRevTagCL));
					//CALLAPI(AOM_ask_value_string(DMLRevTagCL,"t5_cprojectcode",&dml_project));
					//printf("\n dml_project is : %s\n",dml_project);fflush(stdout);
			
					CALLAPI(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
					qry_values11[0] = "ClrRlz";
					//qry_values11[1] =  dml_project;
					qry_values11[1] =  "ClrRlzCLTask"; // for ALTROZ way projects 5442,5485, etc
					CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
					printf("\n Control Object count for CL Task---------->%d\n",resultCount11);fflush(stdout);
					if(resultCount11 > 0)
					{
						printf("\n tm_DMLPostColRlzProcess Method is calling..................\n");fflush(stdout);
						if(tm_DMLPostColRlzProcess(DMLIDNo)!=ITK_ok)PrintErrorStack();				
					}else
					printf("\n Control object not available Hence DML not go for CL task creation--------------->\n"); fflush(stdout);
				}
			}
			return ITK_ok;
		}
		int cl_task_creation_SVR( EPM_action_message_t msg )
		{		
			int			ifail		= 0;
			int         stat        = ITK_ok;
			char*		username	= NULL;
			tag_t		user_tag	= NULLTAG;
			int n_entries11 =2;
			tag_t	Cntl_obj_Qtag11	=	NULLTAG;
			char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
			char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
			int resultCount11=0;
			tag_t *qry_cntrlobj11= NULLTAG;
			tag_t  rootTask			= NULLTAG;
			int    noAttachment=0;
			tag_t  *attachments		= NULLTAG;
			tag_t  DMLTag = NULLTAG;
			tag_t  dml_tagCL = NULLTAG;
			char   *Item_id = NULL;
			char   *DMLProjS = NULL;
			char   *Item_idCL = NULL;
			char   *dml_project = NULL;
			char   *DMLIDNo = NULL;
			tag_t DMLRevProjTag = NULLTAG;
			tag_t DMLRevTagCL = NULLTAG;
			tag_t  objTypTag		= NULLTAG;
			char  *ObjTyp=NULL;
			 int i = 0;
			//12PP555556 - DML for CL Creation on uadev
			CALLAPI(POM_get_user(&username,&user_tag));
			printf("\n Starting for cl_task_creation_SVR of CL Task----------->%s\n",username);fflush(stdout);
			
			CALLAPI(EPM_ask_root_task(msg.task,&rootTask));
			printf("\n EPM_ask_root_task-cl_task_creation_SVR---------> \n"); fflush(stdout);

			CALLAPI(EPM_ask_attachments(rootTask,EPM_target_attachment,&noAttachment,&attachments));	    
			printf("\n Target Attachment cl_task_creation_SVR--------------->%d\n",noAttachment);fflush(stdout);

			if(noAttachment > 0) 
			{		
				 for(i=0;i<noAttachment;i++)
				  {
					printf("\n******* cl_task_creation_SVR INSIDE Attachments  ********\n");fflush(stdout);
					if(TCTYPE_ask_object_type(attachments[i],&objTypTag));
					if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
					printf("\n ********** cl_task_creation_SVR Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);
				if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0 || tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
					{
					   DMLTag = attachments[i];
					   
					   break;
					}
				 }			
			}

			if ( DMLTag != NULLTAG )
			{		
				CALLAPI(AOM_ask_value_string(DMLTag,"item_id",&Item_idCL));
				printf("\n DML Item_id for cl_task_creation_SVR is : %s\n",Item_idCL);fflush(stdout);

				DMLIDNo = subString(Item_idCL,0,10);
				printf("\n DMLIDNo----------->%s\n",DMLIDNo); fflush(stdout);

				CALLAPI(ITEM_find_item(DMLIDNo, &dml_tagCL));
				if (dml_tagCL != NULLTAG)
				{			
					CALLAPI(ITEM_ask_latest_rev(dml_tagCL, &DMLRevTagCL));
					CALLAPI(AOM_ask_value_string(DMLRevTagCL,"t5_cprojectcode",&dml_project));
					printf("\n dml_project is : %s\n",dml_project);fflush(stdout);
			
					CALLAPI(QRY_find2("Control Objects...", &Cntl_obj_Qtag11));
					qry_values11[0] = "ClrRlzSVR";
					qry_values11[1] =  dml_project;  // for Hornbill way project 5445/5477
					CALLAPI(QRY_execute(Cntl_obj_Qtag11, n_entries11, qry_entries11, qry_values11, &resultCount11, &qry_cntrlobj11));
					printf("\n Control Object count for CL Task-cl_task_creation_SVR--------->%d\n",resultCount11);fflush(stdout);
					if(resultCount11 > 0)
					{
						printf("\n tm_DMLPostColRlzProcess Method is calling..................\n");fflush(stdout);
						if(tm_DMLPostColSVRRlzProcess(DMLIDNo)!=ITK_ok)PrintErrorStack();				
					}else
					printf("\n Control object not available Hence DML not go for CL task creation tm_DMLPostColRlzProcess--------------->\n"); fflush(stdout);
				}
			}
			return ITK_ok;
		}
		int GetBLFormulaC(tag_t ConfigCtx,char* child_bl_formula,char* othermodule_bl_formula)
		{

		  tag_t	queryTag1	= NULLTAG;
			tag_t *options=NULLTAG;
			tag_t Optvalue_tag = NULLTAG;
			int resultCountoption=0;
			int n_entries1 = 1;//
			int jm=  0;
			char *qry_entries1[1] = {"Thread ID"};
			char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));
			char*	 objvalueName			= NULL;
			char*	 ContextobjId			= NULL;
			char*	 optionvaluetobjId			= NULL;
			char Mudlewithor[1500];
			char Mudlewithorother[1500];
			char *Strother_item_id=NULL;
			//char *othermodule_bl_formula=NULL;
			char *token;
			tag_t  ConfigCtxObjTypeTag=NULLTAG;
			char   *Config_CtxType=NULL;
			char*	 SmVCContext			= NULL;
			char*	 SmCrIDContext			= NULL;
			 tag_t	queryTag	= NULLTAG;
			int n_entries = 1;
			char *qry_entries[1] = {"ID"};
			int resultCount=0;
			tag_t *rev=NULLTAG;
			tag_t Optfmly_tag = NULLTAG;
			char*	 ContextobjName			= NULL;
			char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
			
			int countir = 0, ir=0,iut=0,j=0;
			char* tok; 
			char* tok2; 
			char* tok3; 
			int		flagtt = 0;
			int		flagttr = 0;
			int		flagii = 0;



				if(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
						  if(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType));
						  printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

						  if(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
						  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

						  if(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
						  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

						  if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag));
						  printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find2");fflush(stdout);
						  if (queryTag)
						  {
							printf("\n\tFound Query");fflush(stdout);
						  }else
						  {
							printf("\n\tNot Found Query");fflush(stdout);
						  }

						  qry_values[0] = SmCrIDContext;

						  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
						  printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);
						  tc_strcpy(Mudlewithor,"");
							tc_strcpy(Mudlewithorother,"");

						   for (j=0;j<resultCount;j++ )
							{
							 Optfmly_tag = rev[j];
							 if(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName));
							 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family

							  if(AOM_ask_value_string(Optfmly_tag,"cfg0ObjectId",&ContextobjId));
								  printf("\n\t ContextobjId Object String ID is :%s",ContextobjId); fflush(stdout); 

							


				 if(QRY_find2("__Cfg0OptionValuesFromOptionFamilyIDs", &queryTag1));
				  printf("\n\t After __Cfg0OptionValuesFromOptionFamilyIDs : QRY_find2");fflush(stdout);
				  if (queryTag1)
				  {
					printf("\n\t************Found Query");fflush(stdout);
				  }else
				  {
					printf("\n\t************Not Found Query");fflush(stdout);
				  }

				  qry_values1[0] = ContextobjName;
				 
				  if(QRY_execute(queryTag1, n_entries1, qry_entries1, qry_values1, &resultCountoption, &options));
				  printf("\n\t resultCountoption =>>>>>>>: %d\n", resultCountoption); fflush(stdout);
				  flagtt=0;
				  flagttr=0;
				  for (jm=0;jm<resultCountoption;jm++ )
					{		  
					  Optvalue_tag = options[jm];
					  if(AOM_ask_value_string(Optvalue_tag,"object_name",&objvalueName));
					  printf("\n\t objvalueName Objectvalue String Type is=>>>>>>> :%s",objvalueName); fflush(stdout);
					  if(AOM_ask_value_string(Optvalue_tag,"cfg0ObjectId",&optionvaluetobjId));
					  printf("\n\t optionvaluetobjId Object String ID is=>>>>>>>>> :%s",optionvaluetobjId); fflush(stdout); 

					  if(tc_strstr(child_bl_formula,ContextobjName)!=NULL)
					  {
						  if(tc_strstr(child_bl_formula,objvalueName)!=NULL)
						  {
								 if (flagttr==0)
							  {
								tc_strcat(Mudlewithor,",");
								tc_strcat(Mudlewithor,optionvaluetobjId);
								countir++;
							  }
							  else
							  {
								  tc_strcat(Mudlewithor,"^");
								tc_strcat(Mudlewithor,optionvaluetobjId);
							  }
							  flagttr++;


						  }
					  }
		 

						  if(tc_strstr(othermodule_bl_formula,ContextobjName)!=NULL)
						  {
							  if(tc_strstr(othermodule_bl_formula,objvalueName)!=NULL)
							  { 
								  if (flagtt==0)
								  {
									tc_strcat(Mudlewithorother,",");
									tc_strcat(Mudlewithorother,optionvaluetobjId);
								  }
								  else
								  {
									  tc_strcat(Mudlewithorother,"^");
									  tc_strcat(Mudlewithorother,optionvaluetobjId);
								  }

								   flagtt++;
							  }
						  }
					}
						
						printf("\n\n\t\t for other parttypes Mudlewithor 111111111111: %s \n",Mudlewithor);fflush(stdout);
					  printf("\n\n\t\t for other parttypes Mudlewithor other 1111111111: %s \n",Mudlewithorother);fflush(stdout);

					}

					 flagii=1;

					  if(tc_strlen(Mudlewithor)>1)
					{

					  printf("\n\n\t\t for other parttypes Mudlewithor : %s \n",Mudlewithor);fflush(stdout);
					  printf("\n\n\t\t for other parttypes Mudlewithor other : %s \n",Mudlewithorother);fflush(stdout);

					  // bhaskar start
					   char* rest = Mudlewithor; 
					   char* rest1 = Mudlewithorother; 

					//  for (ir = 0; Mudlewithor[ir] != '\0'; ir++) {
						//  if (Mudlewithor[ir] == '\,')
						//	 countir++;
					  // }
						printf("\nOccurence of character ',' : %d",  countir);fflush(stdout);
						flagii=0;
						 for(iut=1;iut<=countir;iut++)
							{
								tok = strtok_r(rest, ",", &rest);
								printf("\n tok %s\n", tok);fflush(stdout); 
											 tok2 = strtok_r(rest1, ",", &rest1);
											 printf("\n tok2 %s\n", tok2);fflush(stdout); 
											 if (tc_strstr(tok2,tok)!=NULL)
											 {
												 printf ("tokens are matching");fflush(stdout);
											 }
											 else
												{
													  printf ("tokens are not matching");fflush(stdout);
													  flagii++;
												}

												
							}
							printf("\n flagii valus ie  : %d",  flagii);fflush(stdout);
							//return flagii;
						}

						printf("\n flagii value ie  : %d",  flagii);fflush(stdout);

						  if (flagii==0)
						  {
							  printf("\n dmlIncnt greator than 1 :%d\n",flagii); fflush(stdout);
							  EMH_store_error_s1(EMH_severity_error,ITK_err, "Same Variant formula exist for other module with OR condition");
							  return ITK_err;
						  }
						
		}
		extern EPM_decision_t DLLAPI Chk_clr_schm_dummy(EPM_rule_message_t msg)
		{
			int no_attach,i,SchComCnt,st			= 0;
			tag_t  roottask			= NULLTAG;
			tag_t  objTypTag		= NULLTAG;
			tag_t  *taskAttachments	= NULLTAG;
			tag_t  *SchHcoldata	= NULLTAG;
			char   *ObjTyp=NULL;
			char   *SerNum=NULL;
			char   *CmpCd=NULL;
			char   *CrrntId=NULL;
			int   CCACntr = 0;
			int   NCCACntr = 0;
			//if (!ErrString) MEM_free(ErrString);
			char *ErrString = (char *) MEM_alloc(100 * sizeof(char *));
			
			EPM_decision_t decision = EPM_go;
			printf("\n *********** ::start here:: **********"); fflush(stdout);
			if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
			if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
			printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);
			if(no_attach > 0)
			{
				tc_strcpy(ErrString,"");
				for(i=0;i<no_attach;i++)
				{
					printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);
					if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
					if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
					printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);
					if(tc_strcmp(ObjTyp,"T5_clschmRevision")==0)
					{
						if(AOM_ask_value_tags (taskAttachments[i], "T5_ShmHasClrData",&SchComCnt, &SchHcoldata)!=ITK_ok) PrintErrorStack();
						printf(" \n SchComCnt Count: [%d] \n ",SchComCnt); fflush(stdout);
						for (st=0;st< SchComCnt;st++ )
						{
							//if(AOM_UIF_ask_value (SchHcoldata[st], "object_string", &Obj_str)!=ITK_ok) PrintErrorStack();
							if(AOM_UIF_ask_value (SchHcoldata[st], "t5_ClSrl", &SerNum)!=ITK_ok) PrintErrorStack();
							if(AOM_UIF_ask_value (SchHcoldata[st], "t5_PrtCatCode", &CmpCd)!=ITK_ok) PrintErrorStack();
							if(AOM_UIF_ask_value (SchHcoldata[st], "current_id", &CrrntId)!=ITK_ok) PrintErrorStack();

							if ((tc_strstr(SerNum,"DUMMY")!=NULL) && (tc_strstr(CmpCd,"CCA_")==NULL))
							{
								
								NCCACntr++;
								tc_strcat(ErrString,CrrntId);
								tc_strcat(ErrString,"\n");
								printf(" \nDUMMY serial found SerNum : [%s] [%s] [%s]\n ",SerNum,CmpCd,CrrntId); fflush(stdout);
								//EMH_clear_errors();
								//EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"\nDUMMY serial found SerNum and comp code: ",SerNum,CmpCd);
								//decision = EPM_nogo;
								//return decision;
							}
							else if ((tc_strstr(SerNum,"DUMMY")!=NULL) && (tc_strstr(CmpCd,"CCA_")!=NULL))
							{
								CCACntr++;
								tc_strcat(ErrString,CrrntId);
								//tc_strcat(ErrString,",");
								tc_strcat(ErrString,"\n");
								printf(" \nDUMMY serial found SerNum : [%s] [%s] [%s]\n ",SerNum,CmpCd,CrrntId); fflush(stdout);
								//printf(" \nDUMMY serial found SerNum : [%s] [%s] \n ",SerNum,CmpCd); fflush(stdout);
								//printf(" \nDUMMY serial found SerNum : [%s] \n ",SerNum); fflush(stdout);
								//EMH_clear_errors();
								//EMH_store_error_s4(EMH_severity_error,ITK_Prjerr,"\nDUMMY serial found SerNum and comp code: ",SerNum,CmpCd,"Kindly raise ticket in colour BOM category");
								//decision = EPM_nogo;
								//return decision;

							}
							else
							{
								printf(" \nDUMMY serial not found SerNum : [%s] [%s] \n ",SerNum,CmpCd); fflush(stdout);

							}
						}
						printf(" \nDUMMY serial  Count CCA & Non CCA respectively [%d] [%d]  \n ",CCACntr,NCCACntr); fflush(stdout);
						if (CCACntr > 0 && NCCACntr == 0)
						{
							//Found CCA comp codes as dummy
							printf(" \nDUMMY serial found SerNum : [%s] \n ",ErrString); fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"\nDUMMY serial found SerNum and comp code: ",ErrString,"Kindly raise ticket in TMS category TCUA Colour Module");
							decision = EPM_nogo;
							//if (ErrString) MEM_free(ErrString); //MEM free 
							return decision;
						}else if (NCCACntr > 0 && CCACntr == 0)
						{
							//Found Non CCA comp codes as dummy
							printf(" \nDUMMY serial found SerNum : [%s] \n ",ErrString); fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"\nDUMMY serial found SerNum and comp code: ",ErrString,"Enter colour Serial/Colour ID against displayed non-CCA comp codes and proceed to sign-off");
							decision = EPM_nogo;
							//if (ErrString) MEM_free(ErrString); //MEM free
							return decision;
						}
						else if (NCCACntr > 0 && CCACntr > 0)
						{
							//Found Non CCA & CCA comp codes as dummy
							printf(" \nDUMMY serial found SerNum : [%s] \n ",ErrString); fflush(stdout);
							EMH_clear_errors();
							EMH_store_error_s3(EMH_severity_error,ITK_Prjerr,"\nDUMMY serial found SerNum and comp code: ",ErrString,"Enter colour Serial/Colour ID against displayed non-CCA comp codes and Kindly raise ticket in TMS category TCUA Colour Module for CCA comp codes");
							decision = EPM_nogo;
							//if (ErrString) MEM_free(ErrString); //MEM free
							return decision;

						}else 
						{
							printf(" \nDUMMY serial not found SerNum "); fflush(stdout);
						}

					}

				}
			}
			//if (ErrString) MEM_free(ErrString); //MEM free
			return decision;

		}

		extern EPM_decision_t DLLAPI duplicate_vf_on_clrmodule(EPM_rule_message_t msg)
		{
			int no_attach,i			= 0;
			tag_t  roottask			= NULLTAG;
			EPM_decision_t decision = EPM_go;
			tag_t  *taskAttachments	= NULLTAG;
			tag_t  objTypTag		= NULLTAG;
			char   *ObjTyp=NULL;
			char   *Archtype_name=NULL;
			char   *Archtype_nameC=NULL;
			int partcnt,j,jd,jd1,k =0;
			char   *objectId		=NULL;
			char   *objectIdC		=NULL;
			char   *Dml_taskNo		=NULL;
			char   *DMLNo		=NULL;
			char   *Part_type		=NULL;
			char   *Part_typeC		=NULL;
			char   *DML_rlstype		=NULL;
			char   *Arch_obj		=NULL;
			char   *Arch_obj_str	=NULL;
			char   *ColourInd		=NULL;
			char   *ColourIndC		=NULL;
			char   *child_item_id		=NULL;
			tag_t dml_tag = NULLTAG;
			tag_t DMLRevTag = NULLTAG;
			tag_t *PartsTag=NULLTAG;
			tag_t	AssyTag		= NULLTAG;
			int n_parents			= 0;
			int *levels				= 0;
			tag_t  *parents			= NULL;
			tag_t	ArchAssyTag		= NULLTAG;
			tag_t  ArchobjTypeTag	= NULLTAG;
			tag_t  	master =	NULLTAG;
			tag_t relation_dep=	NULLTAG;
			int countConfigCtx = 0;
			tag_t  *ConfigCtxSecObject	= NULLTAG;
			tag_t ConfigCtx = NULLTAG;
			tag_t   window,rule,item_tag = null_tag,top_line;
			tag_t   window1,rule1,top_line1; 
			int n_BL,p1,n,l=0;
			tag_t  *children1		= NULLTAG;
			tag_t  *children2		= NULLTAG;
			tag_t  Childobject		= NULLTAG;
			tag_t  Childobject1		= NULLTAG;
			char* child_bl_formula_cmp = NULL;
			char* child_bl_formula = NULL;
			int			blobjType		= 0;
			int			revid		= 0;
			char *child_objType = NULL;
			char *child_rev_id = NULL;
			char *child_item_rev_id=NULL;
			tag_t  ConfigCtxObjTypeTag=NULLTAG;
			char   *Config_CtxType=NULL;
			char*	 SmVCContext			= NULL;
			char*	 SmCrIDContext			= NULL;
			char*	 ContextobjName			= NULL;
			char*	 CtxtrimobjName			= NULL;
			tag_t	queryTag	= NULLTAG;
			tag_t	queryChkTag	= NULLTAG;
			char **qry_values = (char **) MEM_alloc(100 * sizeof(char *));
			char **qry_valuesChk = (char **) MEM_alloc(100 * sizeof(char *));
			int n_entries = 1;
			char	*qry_entries[1] = {"ID"};
			int		resultCount = 0;
			tag_t *rev=NULLTAG;
			tag_t Optfmly_tag = NULLTAG;
			char*	 ContextobjId			= NULL;
			char*	 optionvaluetobjId			= NULL;
			char *Strother_item_id=NULL;
			char *othermodule_bl_formula=NULL;
			tag_t	qry_t1	= NULLTAG;
			char **qry_val3 = (char **) MEM_alloc(10 * sizeof(char *));
			int n_entr1 = 1;
			char    *qry_entr1[1]  = {"SYSCD"};
			int rsltCunt1=0;
			tag_t *CntrlObjTag1=NULLTAG;
			int NoDupClrFlag=0;
			int n_parents1=0;

			tag_t top_line2;
			tag_t   otherArchObj=NULLTAG;
			char *qry_entries1[1] = {"Thread ID"};
			char **qry_values1 = (char **) MEM_alloc(10 * sizeof(char *));

			printf("\n *********** ::start here:: **********"); fflush(stdout);
			if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
			if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &taskAttachments)!=ITK_ok)PrintErrorStack();
			printf("\n No of Attachements::==>>>> [%d]", no_attach);fflush(stdout);
			if(no_attach >0)
			{
				for(i=0;i<no_attach;i++)
				{
					printf("\n******* INSIDE Attachments  ********\n");fflush(stdout);
					if(TCTYPE_ask_object_type(taskAttachments[i],&objTypTag));
					if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
					printf("\n ********** Workfow obj type: [%s]*************\n", ObjTyp);fflush(stdout);
					if(tc_strcmp(ObjTyp,"T5_ChangeTaskRevision")==0)
					{
						if(AOM_ask_value_string(taskAttachments[i],"item_id",&Dml_taskNo)!=ITK_ok)PrintErrorStack();
						printf("\n Dml_taskNo----------->%s\n",Dml_taskNo); fflush(stdout);

						DMLNo = subString(Dml_taskNo,0,10);
						printf("\n Dml_taskNo----------->%s\n",DMLNo); fflush(stdout);
						
						if(ITEM_find_item(DMLNo, &dml_tag)!=ITK_ok)PrintErrorStack();
						if (dml_tag != NULLTAG)
						{
							if(ITEM_ask_latest_rev(dml_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();					
							if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DML_rlstype)!=ITK_ok)PrintErrorStack();
							printf(" and DML_rlstype: [%s]", DML_rlstype);fflush(stdout);
							
							NoDupClrFlag=0;
							if(tc_strcmp(DML_rlstype,"CP")==0)
							{
								if(AOM_ask_value_tags(taskAttachments[i],"CMHasSolutionItem", &partcnt, &PartsTag));
								printf("\n Color Parts attached to Task :%d\n",partcnt);fflush(stdout);
								if(partcnt >0)
								{
									for(j=0;j<partcnt;j++)
									{
										if(AOM_ask_value_string(PartsTag[j],"item_id",&objectId));
										printf("\n Color Parts attached to Task :%s\n",objectId);fflush(stdout);

										if(AOM_ask_value_string(PartsTag[j],"t5_PartType",&Part_type));
										printf("\n PartType Color Parts attached to Task :%s\n",Part_type);fflush(stdout);

										if(AOM_ask_value_string(PartsTag[j],"t5_ColourInd",&ColourInd));
										printf("\n ColourInd Color Parts attached to Task :%s\n",ColourInd);fflush(stdout);
										if((tc_strcmp(Part_type,"M")==0)&&(tc_strcmp(ColourInd,"C")==0))
										{
											AssyTag=PartsTag[j];
											if(PS_where_used_all(AssyTag,1,&n_parents,&levels,&parents));
											printf("\n\t CP where_used count of objects are : %d",n_parents); fflush(stdout);

											if(n_parents>0)
											{
											  for (jd=0;jd<n_parents;jd++ )
											  {
												ArchAssyTag=parents[jd];
												if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj))PrintErrorStack();
												printf("\n\t Architecture Object is :%s",Arch_obj);	fflush(stdout);

												if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag))PrintErrorStack();
												if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_name))PrintErrorStack();
												printf("\n\t Architecture Type Name is := %s", Archtype_name);fflush(stdout); 

												if (tc_strcmp(Archtype_name,"T5_ArchModuleRevision")==0)
												{
													if(ITEM_ask_item_of_rev(ArchAssyTag, &master));
													if(AOM_ask_value_string(master,"item_id",&Arch_obj_str))PrintErrorStack();
													printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);
													
													if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
													if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();

													if(top_line!=NULLTAG)
													{
														if(BOM_line_ask_child_lines(top_line, &n_BL, &children1))PrintErrorStack();
														printf("\n\t No of child objects are first : %d",n_BL);fflush(stdout);
														if (n_BL >0)
														{													
															for (p1=0;p1<n_BL ;p1++ )
															{
																if(Childobject) Childobject=NULLTAG;
																Childobject=children1[p1];
																if(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ))PrintErrorStack();
																printf("\n\t Color Part is ===> :: %s",child_item_id); fflush(stdout);

																if(tc_strcmp(objectId,child_item_id)==0)
																{
																	if(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula_cmp ))PrintErrorStack();
																	printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula_cmp); fflush(stdout);

																	if(BOM_create_window (&window1)!=ITK_ok)PrintErrorStack();
																	if(CFM_find( "Latest Working", &rule1)!=ITK_ok)PrintErrorStack();
																	if(BOM_set_window_config_rule( window1, rule1)!=ITK_ok)PrintErrorStack();
																	if(BOM_set_window_pack_all (window1, false)!=ITK_ok)PrintErrorStack();
																	if(BOM_set_window_top_line (window1, null_tag,ArchAssyTag, null_tag, &top_line1)!=ITK_ok)PrintErrorStack();

																	if(top_line1!=NULLTAG)
																	{
																		  if(BOM_line_ask_child_lines (top_line1, &n, &children2));
																		  printf("\n\t No of child objects are secound : %d",n);fflush(stdout);
																		  if (n >0)
																		  {
																			  for (l=0;l<n ;l++)
																			  {
																				 if(Childobject1) Childobject1=NULLTAG;
																				 Childobject1=children2[l];
																				 if(Childobject1!=NULLTAG)
																				 {
																					 //if(BOM_line_look_up_attribute ("bl_item_object_type",&blobjType))PrintErrorStack();
																					 //if(BOM_line_look_up_attribute("bl_item_item_id",&revid))PrintErrorStack();
																					// if(BOM_line_ask_attribute_string(Childobject1,revid,&child_rev_id))PrintErrorStack();
																					// if(BOM_line_ask_attribute_string(Childobject1, blobjType, &child_objType))PrintErrorStack();																			
																					 if( AOM_UIF_ask_value(Childobject1,"bl_item_object_type",&child_objType)!=ITK_ok)PrintErrorStack();
																					  if( AOM_UIF_ask_value(Childobject1,"bl_item_item_id",&child_rev_id)!=ITK_ok)PrintErrorStack();

																					 //if (tc_strcmp(child_objType,"Colour Part")==0)
																					 //{
																						 if(AOM_ask_value_string(Childobject1, "bl_formula", &child_bl_formula)!=ITK_ok)PrintErrorStack();
																						 printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);
																						 printf("\n\t strlen(child_bl_formula)--------------> %d\n",strlen(child_bl_formula)); fflush(stdout);

																						 if(strlen(child_bl_formula)>0)
																						 {
																							 if(tc_strcmp(objectId,child_rev_id)!=0)
																							 {
																								 if (tc_strcmp(child_bl_formula_cmp,child_bl_formula)==0)
																								 {																						 
																									 printf("\n\t Variant Formula Matched-------------->%s=%s\n",objectId,child_rev_id); fflush(stdout);
																									 EMH_clear_errors();
																									 EMH_store_error_s4(EMH_severity_warning,ITK_Prjerr,"\nDuplicate Variant formula found for Color Modules ",objectId," and ",child_rev_id);
																									 decision = EPM_nogo;
																									 return decision;
																								 }else
																								 {
																									 NoDupClrFlag=1;
																									 printf("\n\t Variant Formula NOT Matched-------------->\n"); fflush(stdout);
																								 }
																							 }
																						 }
																					 //}
																				 }
																			  }
																		  }
																	}
																}
															}
														}
													}
												}
											  }
											}
										}else
										{
											printf("\n\t Color Indicator for attached Color Parts is Other than M\n\n");fflush(stdout);
										}
									}
								}
								
								//OR Condiction logic in Variant formula
								printf("\n NoDupClrFlag--------------------->%d\n",NoDupClrFlag);fflush(stdout);
								if(NoDupClrFlag==1)
								{
								 printf("\n OR Condiction Going to check in Variant formula--------------------->\n");fflush(stdout);
								 if(partcnt >0)
								 {
									for(k=0;k<partcnt;k++)
									{
										if(AOM_ask_value_string(PartsTag[k],"item_id",&objectIdC));
										printf("\n Color Parts attached to Task :%s\n",objectIdC);fflush(stdout);

										if(AOM_ask_value_string(PartsTag[k],"t5_PartType",&Part_typeC));
										printf("\n PartType Color Parts attached to Task :%s\n",Part_typeC);fflush(stdout);

										if(AOM_ask_value_string(PartsTag[k],"t5_ColourInd",&ColourIndC));
										printf("\n ColourInd Color Parts attached to Task :%s\n",ColourIndC);fflush(stdout);
										if((tc_strcmp(Part_typeC,"M")==0)&&(tc_strcmp(ColourIndC,"C")==0))
										{
											AssyTag=PartsTag[k];
											if(PS_where_used_all(AssyTag,1,&n_parents1,&levels,&parents));
											printf("\n\t CP where_used count of objects are : %d",n_parents1); fflush(stdout);
											if(n_parents1>0)
											{
											  for (jd1=0;jd1<n_parents1;jd1++ )
											  {
												ArchAssyTag=parents[jd1];
												if(AOM_ask_value_string(ArchAssyTag,"item_id",&Arch_obj))PrintErrorStack();
												printf("\n\t Architecture Object is :%s",Arch_obj);	fflush(stdout);

												if(TCTYPE_ask_object_type(ArchAssyTag,&ArchobjTypeTag))PrintErrorStack();
												if(TCTYPE_ask_name2(ArchobjTypeTag,&Archtype_nameC))PrintErrorStack();
												printf("\n\t Architecture Type Name is := %s", Archtype_nameC);fflush(stdout); 
												if (tc_strcmp(Archtype_nameC,"T5_ArchModuleRevision")==0)
												{										
													if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
													if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
													if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line)!=ITK_ok)PrintErrorStack();
													if(top_line!=NULLTAG)
													 {
														if(BOM_line_ask_child_lines(top_line, &n, &children1));
														printf("\n\t No of child objects are n : %d",n);fflush(stdout);
														if (n >0)
														{
														  for (p1=0;p1<n ;p1++ )
														  {
															if(Childobject) Childobject=NULLTAG;
															Childobject=children1[p1];
															CALLAPI(AOM_ask_value_string(Childobject, "bl_item_item_id", &child_item_id ));
															printf("\n\t Design Object ===> :: %s",child_item_id); fflush(stdout);

															if(tc_strcmp(objectIdC,child_item_id)==0)
															{
															   CALLAPI(AOM_ask_value_string(Childobject, "bl_formula", &child_bl_formula ));
															   printf("\n\t child_bl_formula--------------> %s\n",child_bl_formula); fflush(stdout);

															   CALLAPI(AOM_ask_value_string(Childobject, "bl_rev_item_revision_id", &child_item_rev_id ));
															   printf("\n\t Design Object ===> :: %s",child_item_rev_id); fflush(stdout);

															   CALLAPI(ITEM_ask_item_of_rev(ArchAssyTag, &master));
																CALLAPI(AOM_ask_value_string(master,"item_id",&Arch_obj_str));
																printf("\n\t Architecture Object String Type is :%s",Arch_obj_str); fflush(stdout);

																CALLAPI(GRM_find_relation_type("Smc0HasVariantConfigContext",&relation_dep));
																if(relation_dep != NULLTAG)
																{
																	printf("\n\t Variant ConfigContext relation found......");	fflush(stdout);
																}

																CALLAPI(GRM_list_secondary_objects_only(master,relation_dep,&countConfigCtx,&ConfigCtxSecObject));
																printf("\n\t Configuration Context count is : %d",countConfigCtx);
																if(countConfigCtx>0)
																{
																	  ConfigCtx=ConfigCtxSecObject[0];
																	  CALLAPI(TCTYPE_ask_object_type(ConfigCtx,&ConfigCtxObjTypeTag));
																	  CALLAPI(TCTYPE_ask_name2(ConfigCtxObjTypeTag,&Config_CtxType));
																	  printf( "\n\t Config relation Config_CtxType :%s ..",Config_CtxType);

																	  CALLAPI(AOM_ask_value_string(ConfigCtx,"object_string",&SmVCContext));
																	  printf("\n\t SmVCContext Object String Type is :%s",SmVCContext);	fflush(stdout);

																	  CALLAPI(AOM_ask_value_string(ConfigCtx,"current_id",&SmCrIDContext));
																	  printf("\n\t SmCrIDContext Object String Type is :%s",SmCrIDContext);	fflush(stdout);

																	  if(QRY_find2("Cfg0OptionFamiliesFromIDs", &queryTag));
																	  printf("\n\t After Cfg0OptionFamiliesFromIDs : QRY_find2");fflush(stdout);
																	  if (queryTag)
																	  {
																		printf("\n\tFound Query");fflush(stdout);
																	  }else {
																		printf("\n\tNot Found Query");fflush(stdout);
																	  }

																	  qry_values[0] = SmCrIDContext;
																	  if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &rev));
																	  printf("\n\t resultCount : %d\n", resultCount); fflush(stdout);
																	  
																	  if(tc_strcmp(child_bl_formula,"")==0 && resultCount >0)
																	  {
																		printf("\n CC available Variant formula not available \n"); fflush(stdout);
																		EMH_store_error_s2(EMH_severity_error,ITK_err, "Module Release not allowed without variant formula for",child_item_id);
																		return ITK_err;
																	  }else
																	  {																													
																		  for (j=0;j<resultCount;j++ )
																		  {
																			 Optfmly_tag = rev[j];
																			 CALLAPI(AOM_ask_value_string(Optfmly_tag,"object_name",&ContextobjName));
																			 printf("\n\t ContextobjName Object String Type is :%s",ContextobjName); fflush(stdout);   //Drive, Fuel is a Name if Option family

																			  CALLAPI(AOM_ask_value_string(Optfmly_tag,"cfg0ObjectId",&ContextobjId));
																			  printf("\n\t ContextobjId Object String ID is :%s",ContextobjId); fflush(stdout); 

																			 if(tc_strlen(ContextobjName)>1)
																			 {		
																				 if(tc_strlen(ContextobjId)>1)
																				 {
																						printf("\n\t ContextobjId:::::>>> %s",ContextobjId); fflush(stdout); 
																						printf("\n\t **********Inside OR Condition **************\n"); fflush(stdout);
																						printf("\n\t **Main Part** =>>> %s with his Complete Variant formula=>>>>> = %s\n",objectIdC,child_bl_formula); fflush(stdout);
																						if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
																						if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
																						if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
																						if(BOM_set_window_pack_all (window, false)!=ITK_ok)PrintErrorStack();
																						if(BOM_set_window_top_line (window, null_tag,ArchAssyTag, null_tag, &top_line2)!=ITK_ok)PrintErrorStack();																			  
																						if(top_line2!=NULLTAG)
																						{
																							if(BOM_line_ask_child_lines (top_line2, &n, &children1));
																							printf("\n\t No of child objects are n=>>>>>>> : %d",n);fflush(stdout);
																							if (n >0)
																							{
																							  for (p1=0;p1<n ;p1++ )
																							  {
																								if(otherArchObj) otherArchObj=NULLTAG;
																								otherArchObj=children1[p1];
																								CALLAPI(AOM_ask_value_string(otherArchObj, "bl_item_item_id", &Strother_item_id ));
																								if(tc_strcmp(objectIdC,Strother_item_id)!=0)
																								{
																									printf("\n\t Strother_item_id Object ===> :: %s",Strother_item_id); fflush(stdout);
																									CALLAPI(AOM_ask_value_string(otherArchObj, "bl_formula", &othermodule_bl_formula ));
																									printf("\n\t othermodule_bl_formula ===>>>>>>>> %s\n",othermodule_bl_formula); fflush(stdout);
																									if(QRY_find2("ControlObjects", &qry_t1));
																									if (qry_t1)
																									{
																										printf("\n ControlObjects:.Found Query ControlObjects \n");fflush(stdout);
																									}else
																									{
																										printf("\n ControlObjects:.Not Found Query ControlObjects \n");fflush(stdout);
																									}
																									qry_val3[0] = "ModulewithOR";
																									if(QRY_execute(qry_t1, n_entr1, qry_entr1, qry_val3, &rsltCunt1, &CntrlObjTag1));
																									printf(" \n ModulewithOR:rsltCunt1::::>>> :%d:", rsltCunt1); fflush(stdout);
																									if(rsltCunt1>0)
																									{
																										int status = GetBLFormulaC(ConfigCtx,child_bl_formula,othermodule_bl_formula);
																										printf(" \n After Function call GetBLFormula::::>>>%d\n",status); fflush(stdout);
																										if(status!=0)
																										{
																											decision = EPM_nogo;
																										}else
																										{
																											decision = EPM_go;
																										}
																									}
																								}
																							  }																				 
																							}
																						}																
																					}
																				}
																			}
																	  }															  
																  }
															  }
														  }
														}
													 }
												 }
											  }
											}
										}
									}
								}						
								}
							}else
							{
								printf("\n\t DML Release Type Other Than CP DML : [%s]", DML_rlstype);fflush(stdout);
							}
						}
					}
				}
			}

			return decision;
		}

		int Check_ERCModPresent(tag_t TaskTag, int PartCnt, tag_t* PartTags,char	***SetChildRelAPLModErr,int *icount_aplModCheck)
		{
			EPM_decision_t decision;
			tag_t			AssyTag				= NULLTAG;
			char*			partType				= NULL;
			char*			partItemId				= NULL;
			char*			partItemId_rev				= NULL;
			char*			childPrtNo				= NULL;
			int k=0;
			tag_t  t_ChildItemRev = NULLTAG;
			tag_t   t_ChildItemRev_grp=NULLTAG;
			tag_t   t_itemTag=NULLTAG;
			tag_t   t_itemTag_grp=NULLTAG;
			
			int pbTbFnd=0;
			int childPrtC=0;
			int iChildItemTag=0;
			int iChildItemTag_grp=0;

			date_t Release_date;
			char*		ErrString	=	NULL;
			char*		b4Z01PBString	=	NULL;
			char*		b5Z01TBString	=	NULL;
			char*		p4Z01String	=	NULL;
			char*		aplModBomQtyString	=	NULL;
			char*		aplModViewMskString	=	NULL;
			char*		value_itemid	=	NULL;
			char*		value_itemRevID	=	NULL;
			char*		value_itemRevPartType	=	NULL;
			char*		value_flag	=	NULL;
			char*		aplBiwModule	=	NULL;
			char*		ercBiwModule1	=	NULL;
			char*		ercBiwModule2	=	NULL;
			char*		aplPTModule	=	NULL;
			char*		ercPTModule	=	NULL;
			char*		aplModule1	=	NULL;
			char*		aplModule2	=	NULL;
			char*		viewmask	=	NULL;
			char*		revisionRule	=	NULL;
			char*		Item_ID_Check	=	NULL;
			tag_t   window					=	NULLTAG;
			tag_t   window_grp					=	NULLTAG;
			tag_t	rule								= NULLTAG;
			tag_t	rule_grp								= NULLTAG;
			tag_t			bvr_tag= NULLTAG;
			tag_t			bvr_tag_grp= NULLTAG;
			tag_t	top_line							= NULLTAG;
			tag_t	top_line_grp							= NULLTAG;
			int		nClhd=0;
			int		nClhd_grp=0;
			tag_t  *children = NULLTAG;
			tag_t  *children_grp = NULLTAG;
			tag_t Bomline_tag = NULLTAG;
			tag_t Bomline_tag_grp = NULLTAG;
			int			attribute_flag					=0;
			int			attribute_flag_grp					=0;
			int			attribute_qty					=0;
			int			attribute_qty_grp					=0;
			int			value_qty					=0;
			
			char    *qry_entryCntrlBiw[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrlBiw= (char **) MEM_alloc(5 * sizeof(char *));

			int cntrlcnt=0;
			int  control_number_foundBiw=0;

			tag_t *list_of_WSO_cntrl_tagsBiw=NULLTAG;

			tag_t   qryTagCntrlBiw     = NULLTAG;
			int     n_entryCntrlBiw    = 3;

			char    *qry_entryCntrlPT[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrlPT= (char **) MEM_alloc(5 * sizeof(char *));

			int  control_number_foundPT=0;

			tag_t *list_of_WSO_cntrl_tagsPT=NULLTAG;

			int     n_entryCntrlPT    = 3;

			char	**SetChildRelB4PB	= NULL;
			char	**SetChildRelB5TB	= NULL;
			char	**SetChildRelPT	= NULL;
			char  *sItem_id_rev=NULL;
			char  *sItem_id=NULL;
			
			char	*value_itemid_grp	= NULL;
			char	*value_itemRevID_grp	= NULL;
			char	*value_itemRevPartType_grp	= NULL;
			char	*Item_ID_Check_grp_SA	= NULL;
			char	*value_flag_grp	= NULL;
			char	*value_qty1_grp	= NULL;
			char  *sItem_id_rev_grp=NULL;  
			char  *sItem_id_grp=NULL;      int icountQty =0; 
			int icountB4PB =0; 
			int icountPT =0; 
			int icountViewMsk =0; 
			int icountB5TB =0; 
			char	*tempErr				=	NULL;
			//char	*dmlType				=	NULL;

			SetChildRelB4PB=NULL;
			SetChildRelB4PB = (char**)MEM_alloc( 1 * sizeof *SetChildRelB4PB );

			SetChildRelB5TB=NULL;
			SetChildRelB5TB = (char**)MEM_alloc( 1 * sizeof *SetChildRelB5TB );

			SetChildRelPT=NULL;
			SetChildRelPT = (char**)MEM_alloc( 1 * sizeof *SetChildRelPT );


				for (k=0;k<PartCnt ;k++ )
				{
					printf("\n\n\t\t inside Check_APLModPresent APL DML Cre:for k_4 =:%d",k);fflush(stdout);			
					AssyTag=NULLTAG;			
					AssyTag=PartTags[k];			
					
					ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&partType));
					printf("\n partType:%s ..............",partType);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&partItemId));
					printf("\n partItemId:%s ..............",partItemId);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&partItemId_rev));
					printf("\n partItemId_rev:%s ..............",partItemId_rev);fflush(stdout);

					if((tc_strcmp(partType,"V")==0))	
					{
						printf("\n Inside PartType Check");fflush(stdout);
						
						ITKCALL(BOM_create_window (&window));
						printf("\n find occurence..window");fflush(stdout);
						ITKCALL(CFM_find("Color ERC Review and above", &rule)); //"Latest Working"
						printf("\n find occurence..rule");fflush(stdout);
						ITKCALL(BOM_set_window_config_rule( window, rule ));
						printf("\n configure occurence..rule");fflush(stdout);
						ITKCALL(BOM_set_window_top_line(window, null_tag,AssyTag , bvr_tag, &top_line));
						ITKCALL(BOM_line_ask_child_lines (top_line, &nClhd, &children));
						printf("\n nClhd %d,",nClhd);fflush(stdout);

						int b4pbFnd = 0;
						int b5tbFnd	= 0;
						int p4Fnd	= 0;
						int ck	= 0;
						int ptpFnd	= 0;
						int ptdFnd	= 0;

						if((children) && nClhd>0)
						{
							for (ck = 0; ck < nClhd; ck++)				//Vehicle BOM
							{
								//get the revision from bomline
								//ITKCALL(BOM_line_unpack (children[ck]));
								ITKCALL(BOM_line_pack (children[ck]));

								t_ChildItemRev=NULLTAG;
								sItem_id=NULL;
								sItem_id_rev=NULL;
                    
								//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
								//ITKCALL(BOM_line_ask_attribute_tag(children[ck], iChildItemTag, &t_ChildItemRev));
                                 CALLAPI(AOM_ask_value_string(children[ck], "bl_item_item_id", &sItem_id));
								 CALLAPI(AOM_ask_value_string(children[ck], "bl_rev_item_revision_id", &sItem_id_rev));
							     printf("\n\n TCUA 14.3 bl_item_item_id is---------------->%s ,%s\n",sItem_id,sItem_id_rev); fflush(stdout);

								 CALLAPI(ITEM_find_item(sItem_id,&t_itemTag));
								 CALLAPI(ITEM_find_revision(t_itemTag,sItem_id_rev,&t_ChildItemRev));
							     //CALLAPI(ITEM_ask_latest_rev(ArchTag,&ArchTagRev));                             
							     //CALLAPI(AOM_ask_value_string(ArchTagRev,"t5_ArchModuleAddress",&sModuleAdrr));

								
								if(t_ChildItemRev!=NULLTAG)
								{

									Bomline_tag=NULLTAG;
									Bomline_tag = children[ck];
									if(Bomline_tag!=NULLTAG)
									{
										value_itemid=NULL;
										value_itemRevID=NULL;
										value_itemRevPartType=NULL;
										value_flag=NULL;
										Item_ID_Check=NULL;
										

										ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&value_itemid))
										printf("\n Arc Node child value_itemid:%s ..............",value_itemid);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&value_itemRevID))
										printf("\n value_itemRevID:%s ..............",value_itemRevID);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartType",&value_itemRevPartType))
										printf("\n value_itemRevPartType:%s ..............",value_itemRevPartType);fflush(stdout);

										if((tc_strstr(value_itemid,"B4Z01")!=NULL)|| (tc_strstr(value_itemid,"PB")!=NULL))
										{
											b4pbFnd++;
											printf("\n b4pbFnd:%d..............",b4pbFnd);fflush(stdout);
										}
										else if((tc_strstr(value_itemid,"B5Z01")!=NULL)|| (tc_strstr(value_itemid,"TB")!=NULL))
										{
											b5tbFnd++;
											printf("\n b5tbFnd:%d..............",b5tbFnd);fflush(stdout);
										}
										else if(tc_strstr(value_itemid,"P4Z01")!=NULL)
										{
											p4Fnd++;
											printf("\n p4Fnd:%d..............",p4Fnd);fflush(stdout);
										}
										else if(tc_strstr(value_itemid,"PTP")!=NULL)
										{
											ptpFnd++;
											printf("\n ptpFnd:%d..............",ptpFnd);fflush(stdout);
										}
										else if(tc_strstr(value_itemid,"PTD")!=NULL)
										{
											ptdFnd++;
											printf("\n ptdFnd:%d..............",ptdFnd);fflush(stdout);
										}
										else if(tc_strstr(value_itemid,"G")!=NULL) 
										{
											ITKCALL(BOM_create_window (&window_grp));
											printf("\n find occurence..window_grp");fflush(stdout);
											ITKCALL(CFM_find("Color ERC Review and above", &rule_grp)); //"Latest Working"
											printf("\n find occurence..rule_grp");fflush(stdout);
											ITKCALL(BOM_set_window_config_rule( window_grp, rule_grp ));
											printf("\n configure occurence..rule_grp");fflush(stdout);
											ITKCALL(BOM_set_window_top_line(window_grp, null_tag,t_ChildItemRev , bvr_tag_grp, &top_line_grp));
											ITKCALL(BOM_line_ask_child_lines (top_line_grp, &nClhd_grp, &children_grp));
											printf("\n nClhd_grp %d,",nClhd_grp);fflush(stdout);

											int ck_grp	= 0;
											if((children_grp) && nClhd_grp>0 )
											{
											
												for (ck_grp = 0; ck_grp < nClhd_grp; ck_grp++)				//Grp Part BOM
												{
													//get the revision from bomline
													ITKCALL(BOM_line_pack (children_grp[ck_grp]));

													t_ChildItemRev_grp=NULLTAG;

													//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag_grp));
													//ITKCALL(BOM_line_ask_attribute_tag(children_grp[ck_grp], iChildItemTag_grp, &t_ChildItemRev_grp));
												    ITKCALL(AOM_ask_value_string(children_grp[ck_grp], "bl_item_item_id", &sItem_id_grp));
													ITKCALL(AOM_ask_value_string(children_grp[ck_grp], "bl_rev_item_revision_id", &sItem_id_rev_grp));
													printf("\n\n TCUA 14.3 sItem_id_rev_grp---------------->%s ,%s\n",sItem_id_grp,sItem_id_rev_grp); fflush(stdout);

													ITKCALL(ITEM_find_item(sItem_id_grp,&t_itemTag_grp));
													ITKCALL(ITEM_find_revision(t_itemTag_grp,sItem_id_rev_grp,&t_ChildItemRev_grp));
																	
													
													if(t_ChildItemRev_grp!=NULLTAG)
													{

														Bomline_tag_grp=NULLTAG;
														Bomline_tag_grp = children_grp[ck_grp];

														if(Bomline_tag_grp!=NULLTAG)
														{
															
															value_itemid_grp=NULL;
															value_itemRevID_grp=NULL;
															value_itemRevPartType_grp=NULL;
															

															ITKCALL(AOM_ask_value_string(t_ChildItemRev_grp,"item_id",&value_itemid_grp))
															printf("\n Arc Node child value_itemid_grp:%s ..............",value_itemid_grp);fflush(stdout);

															ITKCALL(AOM_ask_value_string(t_ChildItemRev_grp,"item_revision_id",&value_itemRevID_grp))
															printf("\n value_itemRevID_grp:%s ..............",value_itemRevID_grp);fflush(stdout);

															ITKCALL(AOM_ask_value_string(t_ChildItemRev_grp,"t5_PartType",&value_itemRevPartType_grp))
															printf("\n value_itemRevPartType_grp:%s ..............",value_itemRevPartType_grp);fflush(stdout);

															if(tc_strstr(value_itemid_grp,"PTP")!=NULL) 
															{
																ptpFnd++;
																printf("\n 11 ptpFnd:%d..............",ptpFnd);fflush(stdout);
															}
															else if(tc_strstr(value_itemid_grp,"PTD")!=NULL)
															{
																ptdFnd++;
																printf("\n 11 ptdFnd:%d..............",ptdFnd);fflush(stdout);
															}
														}
													}
												}
											}										
										
										}
										
									}
								}//end of if
								else
								{
								
								}

							}

							if(b4pbFnd<=0)
							{
								if (!ErrString) MEM_free(ErrString);
								ErrString	=(char *)MEM_alloc(tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
								tc_strcpy(ErrString,partItemId);
								tc_strcat(ErrString,";");
								tc_strcat(ErrString,partItemId_rev);
								tc_strcat(ErrString,".\n");
								printf("\n 11 ErrString:%d..............",ErrString);fflush(stdout);
								setAddStrInApplySVRonX4(&icountB4PB,&SetChildRelB4PB,ErrString);	
							}

							if(b5tbFnd<=0)
							{
								if (!ErrString) MEM_free(ErrString);
								ErrString	=	(char *)MEM_alloc(tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
								tc_strcpy(ErrString,"");
								tc_strcat(ErrString,partItemId);
								tc_strcat(ErrString,";");
								tc_strcat(ErrString,partItemId_rev);
								tc_strcat(ErrString,".\n");
								setAddStrInApplySVRonX4(&icountB5TB,&SetChildRelB5TB,ErrString);					
							}

							if((p4Fnd<=0) && (ptpFnd<=0) && (ptdFnd<=0))
							{
								if (!ErrString) MEM_free(ErrString);
								ErrString	=	(char *)MEM_alloc(tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
								tc_strcpy(ErrString,"");
								tc_strcat(ErrString,partItemId);
								tc_strcat(ErrString,";");
								tc_strcat(ErrString,partItemId_rev);
								tc_strcat(ErrString,".\n");
								setAddStrInApplySVRonX4(&icountPT,&SetChildRelPT,ErrString);	
							}
						}			
					}
				}

				int iLength	=	0;
				int i	=	0;
				if (!tempErr) MEM_free(tempErr);
				for (i=0; i < icountB4PB; i++)
				{
					tempErr	=	SetChildRelB4PB[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("11.iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+120);
				for (i=0; i < icountB4PB; i++)
				{
					if(i==0)
					{
						tc_strcpy(tempErr,"\n Painted Assembly (B4Z01 or PB) are not found in below Vehicle :\n ");
						tc_strcat(tempErr,SetChildRelB4PB[i]);
					}
					else
					{
						tc_strcpy(tempErr,SetChildRelB4PB[i]);
					}
					setAddStrInApplySVRonX4(icount_aplModCheck,SetChildRelAPLModErr,tempErr);
					
				}
				printf("\n111.Printing Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);

				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				for (i=0; i < icountB5TB; i++)
				{
					tempErr	=	SetChildRelB5TB[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("5.iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+120);
				for (i=0; i < icountB5TB; i++)
				{
					if(i==0)
					{
						tc_strcpy(tempErr,"\n Boltable Part (B5Z01 or TB) are not found in below Vehicle :\n ");
						tc_strcat(tempErr,SetChildRelB5TB[i]);
					}
					else
					{
						tc_strcpy(tempErr,SetChildRelB5TB[i]);
					}
					setAddStrInApplySVRonX4(icount_aplModCheck,SetChildRelAPLModErr,tempErr);
					
				}
				printf("\n5.Printing Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);

				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				for (i=0; i < icountPT; i++)
				{
					tempErr	=	SetChildRelPT[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("5.iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+120);
				for (i=0; i < icountPT; i++)
				{
					if(i==0)
					{
						tc_strcpy(tempErr,"\n PowerTrain Part (P4Z01 or PTP or PTD or Group ID) are not found in below Vehicle :\n ");
						tc_strcat(tempErr,SetChildRelPT[i]);
					}
					else
					{
						tc_strcpy(tempErr,SetChildRelPT[i]);
					}
					setAddStrInApplySVRonX4(icount_aplModCheck,SetChildRelAPLModErr,tempErr);
					
				}
				printf("\n5.Printing Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);

			return 0;
		}

		int Check_ERCModuleDuplicate(tag_t TaskTag, int PartCnt, tag_t* PartTags,char	***SetChildRelAPLModErr,int *icount_ebommbom_bom)
		{
			EPM_decision_t decision;
			tag_t			AssyTag				= NULLTAG;
			char*			partType				= NULL;
			char*			partItemId				= NULL;
			char*			partItemId_rev				= NULL;
			char*			taskowning_groupVal				= NULL;
			char*			childPrtNo				= NULL;
			int k=0;
			char RevRuleInfo1[40];
			char BVRInfo2[40];
			char Info3[40];
			struct			BomChldStrut	ChldStrutBdySh[5000];
			int	StructCntBdyShProdPlan	= 0,pbFnd=0,tbFnd=0;
			tag_t objChild_BVR		= NULLTAG;
			int iChildItemTag=0;
			tag_t   t_ChildItemRev= NULLTAG;
			tag_t   t_itemTag= NULLTAG;
			tag_t   t_itemTag_grp= NULLTAG;
			
			int VehicleCnt=0;
			int pbTbFnd=0;
			int childPrtC=0;
			char cCurrentAccessDate[20]={0};
			date_t Release_date;
			char*		ErrString	=	NULL;
			char*		b4Z01PBString	=	NULL;
			char*		b4Z01MultipleString	=	NULL;
			char*		PBMultipleString	=	NULL;
			char*		TBMultipleString	=	NULL;
			char*		p4Z01MultipleString	=	NULL;
			char*		b5Z01MultipleString	=	NULL;
			char*		ptpMultipleString	=	NULL;
			char*		ptdMultipleString	=	NULL;
			char*		b5Z01TBString	=	NULL;
			char*		p4Z01String	=	NULL;
			char*		aplModBomQtyString	=	NULL;
			char*		aplModViewMskString	=	NULL;
			char*		value_itemid	=	NULL;
			char*		value_itemRevID	=	NULL;
			char*		value_itemRevPartType	=	NULL;
			char*		value_flag	=	NULL;
			char*		aplBiwModule	=	NULL;
			char*		aplModule1	=	NULL;
			char*		aplModule2	=	NULL;
			char*		aplPTModule	=	NULL;
			char*		ercPTModule	=	NULL;
			char*		viewmask	=	NULL;
			char*		revisionRule	=	NULL;
			char*		Item_ID_Check	=	NULL;
			char*		sItem_id	 =	NULL;
			char*		sItem_id_rev =	NULL;
			char*		sItem_id_grp	 =	NULL;
			char*		sItem_id_rev_grp =	NULL;
			tag_t   window					=	NULLTAG;
			tag_t	rule								= NULLTAG;
			tag_t			bvr_tag= NULLTAG;
			tag_t	top_line							= NULLTAG;
			int		nClhd=0;
			tag_t  *children;
			tag_t Bomline_tag = NULLTAG;
			int			attribute_flag					=0;
			int			attribute_qty					=0;
			int			value_qty					=0;

			tag_t   window_grp					=	NULLTAG;
			tag_t	rule_grp								= NULLTAG;
			tag_t			bvr_tag_grp= NULLTAG;
			tag_t	top_line_grp							= NULLTAG;
			int		nClhd_grp=0;
			tag_t  *children_grp;
			tag_t Bomline_tag_grp = NULLTAG;
			tag_t t_ChildItemRev_grp = NULLTAG;
			char *value_itemid_grp = NULL;
			char *value_itemRevID_grp = NULL;
			char *value_itemRevPartType_grp = NULL;
			char *Item_ID_Check_grp_SA = NULL;
			int iChildItemTag_grp=0;

			
			char    *qry_entryCntrlBiw[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrlBiw= (char **) MEM_alloc(5 * sizeof(char *));

			int cntrlcnt=0;
			int  control_number_foundBiw=0;

			tag_t *list_of_WSO_cntrl_tagsBiw=NULLTAG;

			tag_t   qryTagCntrlBiw     = NULLTAG;
			int     n_entryCntrlBiw    = 3;

			char    *qry_entryCntrlPT[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrlPT= (char **) MEM_alloc(5 * sizeof(char *));

			int  control_number_foundPT=0;

			tag_t *list_of_WSO_cntrl_tagsPT=NULLTAG;

			int     n_entryCntrlPT    = 3;

			char	**SetChildRelB4PB	= NULL;
			char	**SetChildRelB5TB	= NULL;
			char	**SetChildRelPT	= NULL;
			char	**SetChildRelB4Multiple	= NULL;
			char	**SetChildRelPBMultiple	= NULL;
			char	**SetChildRelB5Multiple	= NULL;
			char	**SetChildRelPTDMultiple	= NULL;
			char	**SetChildRelPTPMultiple	= NULL;
			char	**SetChildRelP4Multiple	= NULL;
			char	**SetChildRelTBMultiple	= NULL;
			int icountQty =0; 
			int icountB4PB =0; 
			int icountPT =0; 
			int icountB4 =0; 
			int icountB5 =0; 
			int icountPB =0; 
			int icountTB =0; 
			int icountPTD =0; 
			int icountPTP =0; 
			int icountViewMsk =0; 
			int icountB5TB =0; 
			int icountP4 =0; 
			char	*tempErr				=	NULL;


			printf("\n\n\t\t inside Check_APLModuleDuplicate fucntion");fflush(stdout);



			if(QRY_find2("Control Objects...", &qryTagCntrlBiw));
			if (qryTagCntrlBiw)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrlBiw[0]="ERC_APL_BOM_Validation";
				qry_valuesCntrlBiw[1]="APLModuleDuplicate";
				qry_valuesCntrlBiw[2]="0";

				if(QRY_execute(qryTagCntrlBiw, n_entryCntrlBiw, qry_entryCntrlBiw, qry_valuesCntrlBiw, &control_number_foundBiw, &list_of_WSO_cntrl_tagsBiw));

				qry_valuesCntrlPT[0]="APL_Module_Mapping";
				qry_valuesCntrlPT[1]="SignOffValidation";
				qry_valuesCntrlPT[2]="0";

				if(QRY_execute(qryTagCntrlBiw, n_entryCntrlPT, qry_entryCntrlPT, qry_valuesCntrlPT, &control_number_foundPT, &list_of_WSO_cntrl_tagsPT));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	

			printf("\n control_number_found1 is : %d\n",control_number_foundBiw);fflush(stdout);

			if(control_number_foundBiw>0)
			{
				
				if(control_number_foundPT>0)
				{
				
					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo1", &aplModule1));
					printf("\n aplModule1: %s\n",aplModule1);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo2", &aplModule2));
					printf("\n aplModule2: %s\n",aplModule2);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo3", &viewmask));
					printf("\n viewmask: %s\n",viewmask);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo4", &revisionRule));
					printf("\n revisionRule: %s\n",revisionRule);fflush(stdout);

				
				}

				SetChildRelB4PB=NULL;
				SetChildRelB4PB = (char**)MEM_alloc( 1 * sizeof *SetChildRelB4PB );

				SetChildRelB5TB=NULL;
				SetChildRelB5TB = (char**)MEM_alloc( 1 * sizeof *SetChildRelB5TB );

				SetChildRelPT=NULL;
				SetChildRelPT = (char**)MEM_alloc( 1 * sizeof *SetChildRelPT );

				SetChildRelB4Multiple=NULL;
				SetChildRelB4Multiple = (char**)MEM_alloc( 1 * sizeof *SetChildRelB4Multiple );

				SetChildRelPBMultiple=NULL;
				SetChildRelPBMultiple = (char**)MEM_alloc( 1 * sizeof *SetChildRelPBMultiple );

				SetChildRelB5Multiple=NULL;
				SetChildRelB5Multiple = (char**)MEM_alloc( 1 * sizeof *SetChildRelB5Multiple );

				SetChildRelPTDMultiple=NULL;
				SetChildRelPTDMultiple = (char**)MEM_alloc( 1 * sizeof *SetChildRelPTDMultiple );

				SetChildRelPTPMultiple=NULL;
				SetChildRelPTPMultiple = (char**)MEM_alloc( 1 * sizeof *SetChildRelPTPMultiple );

				SetChildRelP4Multiple=NULL;
				SetChildRelP4Multiple = (char**)MEM_alloc( 1 * sizeof *SetChildRelP4Multiple );

				SetChildRelTBMultiple=NULL;
				SetChildRelTBMultiple = (char**)MEM_alloc( 1 * sizeof *SetChildRelTBMultiple );

				for (k=0;k<PartCnt ;k++ )
				{

					printf("\n\n\t\t inside Check_APLModuleDuplicate APL DML Cre:for k_4 =:%d",k);fflush(stdout);
					AssyTag=NULLTAG;
					AssyTag=PartTags[k];

					partType=NULL;
					partItemId=NULL;
					partItemId_rev=NULL;

					ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&partType));
					printf("\n partType:%s ..............",partType);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&partItemId));
					printf("\n partItemId:%s ..............",partItemId);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&partItemId_rev));
					printf("\n partItemId_rev:%s ..............",partItemId_rev);fflush(stdout);

					if((tc_strcmp(partType,"V")==0))	
					{
						printf("\n Inside PartType Check");fflush(stdout);
						ITKCALL(BOM_create_window (&window));
						printf("\n find occurence..window");fflush(stdout);
						ITKCALL(CFM_find("Color ERC Review and above", &rule));
						printf("\n find occurence..rule");fflush(stdout);
						ITKCALL(BOM_set_window_config_rule( window, rule ));
						printf("\n configure occurence..rule");fflush(stdout);
						ITKCALL(BOM_set_window_top_line(window, null_tag,AssyTag , bvr_tag, &top_line));
						ITKCALL(BOM_line_ask_child_lines (top_line, &nClhd, &children));
						printf("\n nClhd %d,",nClhd);fflush(stdout);

						int childPrtC = 0;
						int pbFnd	= 0;
						int tbFnd	= 0;
						int b4Fnd	= 0;
						int b5Fnd	= 0;
						int pbB4Fnd	= 0;
						int tbB5Fnd	= 0;
						int qtyErr	= 0;
						int viewMskErr	= 0;
						int ck	= 0;
						int p4Z01Fnd	= 0;
						int ptpFnd	= 0;
						int ptdFnd	= 0;
						int ptFnd	= 0;
						int value_qtyInt	= 0;

						for (ck = 0; ck < nClhd; ck++)				//Vehicle BOM
						{
							ITKCALL(BOM_line_pack (children[ck]));

							t_ChildItemRev=NULLTAG;
							t_itemTag = NULLTAG;
							sItem_id = NULL;
							sItem_id_rev = NULL;

							//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
							//ITKCALL(BOM_line_ask_attribute_tag(children[ck], iChildItemTag, &t_ChildItemRev));
							ITKCALL(AOM_ask_value_string(children[ck], "bl_item_item_id", &sItem_id));
							ITKCALL(AOM_ask_value_string(children[ck], "bl_rev_item_revision_id", &sItem_id_rev));
							printf("\n\n TCUA 14.3 bl_rev_item_revision_id---------------->%s ,%s\n",sItem_id,sItem_id_rev); fflush(stdout);
							ITKCALL(ITEM_find_item(sItem_id,&t_itemTag));
							ITKCALL(ITEM_find_revision(t_itemTag,sItem_id_rev,&t_ChildItemRev));
													
							
							if(t_ChildItemRev!=NULLTAG)
							{

								Bomline_tag=NULLTAG;
								Bomline_tag = children[ck];

								if(Bomline_tag!=NULLTAG)
								{
									value_itemid=NULL;
									value_itemRevID=NULL;
									value_itemRevPartType=NULL;
									value_flag=NULL;
									Item_ID_Check=NULL;
									value_qtyInt=0;
									char *value_qty1=NULL;

									ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&value_itemid))
									printf("\n 111 Arc Node child value_itemid:%s ..............",value_itemid);fflush(stdout);

									ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&value_itemRevID))
									printf("\n 111 value_itemRevID:%s ..............",value_itemRevID);fflush(stdout);

									ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartType",&value_itemRevPartType))
									printf("\n 111 value_itemRevPartType:%s ..............",value_itemRevPartType);fflush(stdout);

									if(tc_strcmp(value_itemRevPartType,"M")==0 )
									{
										Item_ID_Check=subString(value_itemid,4,5);
										printf("\n  M Item_ID_Check:%s ..............",Item_ID_Check);fflush(stdout);
									}
									else if((tc_strcmp(value_itemRevPartType,"SA")==0 ) && (tc_strstr(value_itemid,"PTP")!=NULL || tc_strstr(value_itemid,"PTD")!=NULL))
									{
										Item_ID_Check=subString(value_itemid,8,3);
										printf("\n  SA fro PT Item_ID_Check:%s ..............",Item_ID_Check);fflush(stdout);
									}
									else if((tc_strcmp(value_itemRevPartType,"SA")==0 ) && (tc_strstr(value_itemid,"PB")!=NULL || tc_strstr(value_itemid,"TB")!=NULL))
									{
										Item_ID_Check=subString(value_itemid,8,2);
										printf("\n  SA Item_ID_Check:%s ..............",Item_ID_Check);fflush(stdout);
									}
									
									if((tc_strcmp(Item_ID_Check,"")!=0) && ( (tc_strstr(aplModule1,Item_ID_Check)!=NULL) || (tc_strstr(aplModule2,Item_ID_Check)!=NULL)) )
									{
									
									
										//ITKCALL(BOM_line_look_up_attribute(viewmask, &attribute_flag));
										//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_flag, &value_flag));
                                            ITKCALL(AOM_UIF_ask_value(Bomline_tag,viewmask,&value_flag));
										printf("\n  TCUA 14.3 11  value_flag:%s ..............",value_flag);fflush(stdout);

										//ITKCALL(BOM_line_look_up_attribute("bl_quantity", &attribute_qty));
										//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_qty, &value_qty1));
										ITKCALL(AOM_UIF_ask_value(Bomline_tag,"bl_quantity",&value_qty1));
										printf("\n TCUA 14.3  value_qty1:%s ..............",value_qty1);fflush(stdout);

										value_qtyInt =atof(value_qty1);
										printf("\n  11 value_qtyInt:%f ..............",value_qtyInt);fflush(stdout);

										if(tc_strstr(value_itemid,"B4Z01")!=NULL)
										{
											
											if(pbFnd<=0)
											{
												//if (!b4Z01PBString) MEM_free(b4Z01PBString); //hemal
												b4Z01PBString=NULL;
												b4Z01PBString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*5)+(tc_strlen(value_flag)*5)+150);//hemal
												tc_strcpy(b4Z01PBString,"");//hemal
											}
											
											if(b4Fnd==0)
											{
												//if (!b4Z01MultipleString) MEM_free(b4Z01MultipleString); //
												b4Z01MultipleString=NULL;
												b4Z01MultipleString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*10)+150);//hemal
												tc_strcpy(b4Z01MultipleString,"");//hemal
											}

											tc_strcat(b4Z01PBString,value_itemid);
											tc_strcat(b4Z01PBString,";");

											tc_strcat(b4Z01MultipleString,value_itemid);
											tc_strcat(b4Z01MultipleString,";");

											b4Fnd++;

											printf("\n  b4Fnd:%d:%s:%s ..............",b4Fnd,b4Z01MultipleString,b4Z01PBString);fflush(stdout);

										}
										//hemal
										if(tc_strstr(value_itemid,"PB")!=NULL)
										{
											//b4Z01PBString	=	NULL;//hemal
											//b4Z01PBString	=	(char *)MEM_alloc(100);//hemal
											if (b4Fnd<=0)
											{
												//if (!b4Z01PBString) MEM_free(b4Z01PBString) ;//hemal
												b4Z01PBString=NULL;
												b4Z01PBString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*5)+(tc_strlen(value_flag)*5)+150);
												tc_strcpy(b4Z01PBString,"");
											}
											//

											if(pbFnd==0)
											{
												//if (!PBMultipleString) MEM_free(PBMultipleString); //hemal
												PBMultipleString=NULL;
												PBMultipleString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*10)+150);//hemal
												tc_strcpy(PBMultipleString,"");//hemal
											}

											tc_strcat(b4Z01PBString,value_itemid);
											tc_strcat(b4Z01PBString,";");

											tc_strcat(PBMultipleString,value_itemid);
											tc_strcat(PBMultipleString,";");

											pbFnd++;
											printf("\n  pbFnd:%d:%s:%s ..............",pbFnd,PBMultipleString,b4Z01PBString);fflush(stdout);

										}

										if(tc_strstr(value_itemid,"B5Z01")!=NULL)
										{
											if(tbFnd<=0)
											{
												//if (!b5Z01TBString) MEM_free(b5Z01TBString) ;//hemal
												b5Z01TBString=NULL;
												b5Z01TBString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*5)+(tc_strlen(value_flag)*5)+150);//hemal
												tc_strcpy(b5Z01TBString,"");//hemal
											}
											tc_strcat(b5Z01TBString,value_itemid);
											tc_strcat(b5Z01TBString,";");

											if(b5Fnd==0)
											{
												//if (!b5Z01MultipleString) MEM_free(b5Z01MultipleString); //hemal
												b5Z01MultipleString=NULL;
												b5Z01MultipleString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*10)+150);//hemal
												tc_strcpy(b5Z01MultipleString,"");//hemal
											}
											tc_strcat(b5Z01MultipleString,value_itemid);
											tc_strcat(b5Z01MultipleString,";");
											b5Fnd++;
											printf("\n  b5Fnd:%d:%s:%s ..............",b5Fnd,b5Z01MultipleString,b5Z01TBString);fflush(stdout);
											
										}

										if(tc_strstr(value_itemid,"TB")!=NULL)
										{
											if(b5Fnd<=0)
											{
												//if (!b5Z01TBString) MEM_free(b5Z01TBString);//hemal
												b5Z01TBString=NULL;
												b5Z01TBString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*5)+(tc_strlen(value_flag)*5)+150);//hemal
												tc_strcpy(b5Z01TBString,"");//hemal
											}
											tc_strcat(b5Z01TBString,value_itemid);
											tc_strcat(b5Z01TBString,";");

											if(tbFnd==0)
											{
												//if (!TBMultipleString) MEM_free(TBMultipleString); //hemal
												TBMultipleString=NULL;
												TBMultipleString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*10)+150);//hemal
												tc_strcpy(TBMultipleString,"");//hemal
											}
											tc_strcat(TBMultipleString,value_itemid);
											tc_strcat(TBMultipleString,";");
											tbFnd++;
											printf("\n  tbFnd:%d:%s:%s ..............",tbFnd,TBMultipleString,b5Z01TBString);fflush(stdout);

										}


										if(tc_strstr(value_itemid,"P4Z01")!=NULL)
										{
											if((ptpFnd<=0) && (ptdFnd<=0))
											{
												//if (!p4Z01String) MEM_free(p4Z01String) ;//hemal
												p4Z01String=NULL;
												p4Z01String	=	(char *)MEM_alloc((tc_strlen(value_itemid)*5)+(tc_strlen(value_flag)*5)+150);//hemal
												tc_strcpy(p4Z01String,"");//hemal
											}
											tc_strcat(p4Z01String,value_itemid);
											tc_strcat(p4Z01String,";");

											if(p4Z01Fnd==0)
											{
												//if (!p4Z01MultipleString) MEM_free(p4Z01MultipleString); //hemal
												p4Z01MultipleString=NULL;
												p4Z01MultipleString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*10)+150);//hemal
												tc_strcpy(p4Z01MultipleString,"");//hemal
											}
											tc_strcat(p4Z01MultipleString,value_itemid);
											tc_strcat(p4Z01MultipleString,";");
											p4Z01Fnd++;
											printf("\n  p4Z01Fnd:%d:%s:%s ..............",p4Z01Fnd,p4Z01MultipleString,p4Z01String);fflush(stdout);


										}

										if(tc_strstr(value_itemid,"PTP")!=NULL)
										{
											if((p4Z01Fnd<=0) && (ptdFnd<=0))
											{
												//if (!p4Z01String) MEM_free(p4Z01String) ;//hemal
												p4Z01String=NULL;
												p4Z01String	=	(char *)MEM_alloc((tc_strlen(value_itemid)*5)+(tc_strlen(value_flag)*5)+150);//hemal
												tc_strcpy(p4Z01String,"");//hemal
											}

											tc_strcat(p4Z01String,value_itemid);
											tc_strcat(p4Z01String,";");

											if(ptpFnd==0)
											{
												//if (!ptpMultipleString) MEM_free(ptpMultipleString); //hemal
												ptpMultipleString=NULL;
												ptpMultipleString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*10)+150);//hemal
												tc_strcpy(ptpMultipleString,"");//hemal
											}
											tc_strcat(ptpMultipleString,value_itemid);
											tc_strcat(ptpMultipleString,";");
											ptpFnd++;
											printf("\n  ptpFnd:%d:%s:%s ..............",ptpFnd,ptpMultipleString,p4Z01String);fflush(stdout);
											
										}

										if(tc_strstr(value_itemid,"PTD")!=NULL)
										{
											if((p4Z01Fnd<=0) && (ptpFnd<=0))
											{
												//if (!p4Z01String) MEM_free(p4Z01String) ;//hemal
												p4Z01String=NULL;
												p4Z01String	=	(char *)MEM_alloc((tc_strlen(value_itemid)*5)+(tc_strlen(value_flag)*5)+150);//hemal
												tc_strcpy(p4Z01String,"");//hemal
											}
											tc_strcat(p4Z01String,value_itemid);
											tc_strcat(p4Z01String,";");

											if(ptdFnd==0)
											{
												//if (!ptdMultipleString) MEM_free(ptdMultipleString); //hemal
												ptdMultipleString=NULL;
												ptdMultipleString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*10)+150);//hemal
												tc_strcpy(ptdMultipleString,"");//hemal
											}
											tc_strcat(ptdMultipleString,value_itemid);
											tc_strcat(ptdMultipleString,";");
											ptdFnd++;
											printf("\n  ptdFnd:%d:%s:%s ..............",ptdFnd,ptdMultipleString,p4Z01String);fflush(stdout);
											
										}
					
										if((pbFnd>0) && (b4Fnd>0) )
										{
											pbB4Fnd++;	
										}


										if((tbFnd>0) && (b5Fnd>0) )
										{
											tbB5Fnd++;	
										}

										//if(((ptdFnd>0) || (ptpFnd>0)) && (p4Z01Fnd>0))
										if(   (ptdFnd>0 && p4Z01Fnd>0)  || (ptpFnd>0 && p4Z01Fnd>0) || (ptdFnd>0 && ptpFnd>0) )
										{
											ptFnd++;	
										}


									}

									if(tc_strcmp(value_itemRevPartType,"G")==0 )				//Check for PTP/PTD in Grp Part
									{								
										ITKCALL(BOM_create_window (&window_grp));
										printf("\n 1.find occurence..window_grp");fflush(stdout);
										ITKCALL(CFM_find("Color ERC Review and above", &rule_grp)); //"Latest Working"
										printf("\n 1.find occurence..rule_grp");fflush(stdout);
										ITKCALL(BOM_set_window_config_rule( window_grp, rule_grp ));
										printf("\n 1.configure occurence..rule_grp");fflush(stdout);
										ITKCALL(BOM_set_window_top_line(window_grp, null_tag,t_ChildItemRev , bvr_tag_grp, &top_line_grp));
										ITKCALL(BOM_line_ask_child_lines (top_line_grp, &nClhd_grp, &children_grp));
										printf("\n 1.nClhd_grp %d,",nClhd_grp);fflush(stdout);

										int ck_grp	= 0;
										int value_qty1_grpInt	= 0;
										int grpPrtViewMskErr	= 0;
										int grpPrtQtyErr	= 0;

										for (ck_grp = 0; ck_grp < nClhd_grp; ck_grp++)				//Grp Part BOM
										{
											//get the revision from bomline
											ITKCALL(BOM_line_pack (children_grp[ck_grp]));

											t_ChildItemRev_grp=NULLTAG;
											t_itemTag_grp=NULLTAG;
											sItem_id_rev_grp=NULL;
											sItem_id_grp=NULL;

											//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag_grp));
											//ITKCALL(BOM_line_ask_attribute_tag(children_grp[ck_grp], iChildItemTag_grp, &t_ChildItemRev_grp));
											ITKCALL(AOM_ask_value_string(children[ck], "bl_item_item_id", &sItem_id_grp));
											ITKCALL(AOM_ask_value_string(children[ck], "bl_rev_item_revision_id", &sItem_id_rev_grp));
											printf("\n\n TCUA 14.3 bl_rev_item_revision_id---------------->%s ,%s\n",sItem_id_grp,sItem_id_rev_grp); fflush(stdout);
											ITKCALL(ITEM_find_item(sItem_id_grp,&t_itemTag_grp));
											ITKCALL(ITEM_find_revision(t_itemTag_grp,sItem_id_rev_grp,&t_ChildItemRev_grp));


											if(t_ChildItemRev_grp!=NULLTAG)
											{

												Bomline_tag_grp=NULLTAG;
												Bomline_tag_grp = children_grp[ck_grp];

												if(Bomline_tag_grp!=NULLTAG)
												{
													
													value_itemid_grp=NULL;
													value_itemRevID_grp=NULL;
													value_itemRevPartType_grp=NULL;
													Item_ID_Check_grp_SA=NULL;

													ITKCALL(AOM_ask_value_string(t_ChildItemRev_grp,"item_id",&value_itemid_grp))
													printf("\n Arc Node child value_itemid_grp:%s ..............",value_itemid_grp);fflush(stdout);

													ITKCALL(AOM_ask_value_string(t_ChildItemRev_grp,"item_revision_id",&value_itemRevID_grp))
													printf("\n value_itemRevID_grp:%s ..............",value_itemRevID_grp);fflush(stdout);

													ITKCALL(AOM_ask_value_string(t_ChildItemRev_grp,"t5_PartType",&value_itemRevPartType_grp))
													printf("\n value_itemRevPartType_grp:%s ..............",value_itemRevPartType_grp);fflush(stdout);

													if(tc_strcmp(value_itemRevPartType_grp,"SA")==0 )
													{
														Item_ID_Check_grp_SA=subString(value_itemid_grp,8,3);
														printf("\n  SA Item_ID_Check_grp_SA:%s ..............",Item_ID_Check_grp_SA);fflush(stdout);
													
														if(tc_strstr(aplModule1,Item_ID_Check_grp_SA)!=NULL || tc_strstr(aplModule2,Item_ID_Check_grp_SA)!=NULL)
														{
														
															if(tc_strstr(value_itemid_grp,"PTP")!=NULL)
															{
																if((p4Z01Fnd<=0) && (ptdFnd<=0))
																{
																	p4Z01String=NULL;
																	p4Z01String	=	(char *)MEM_alloc((tc_strlen(value_itemid)*5)+150);//hemal
																	tc_strcpy(p4Z01String,"");//hemal
																}

																tc_strcat(p4Z01String,value_itemid);
																tc_strcat(p4Z01String,";");

																if(ptpFnd==0)
																{
																	ptpMultipleString=NULL;
																	ptpMultipleString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*10)+150);//hemal
																	tc_strcpy(ptpMultipleString,"");//hemal
																}
																tc_strcat(ptpMultipleString,value_itemid);
																tc_strcat(ptpMultipleString,";");
																ptpFnd++;
																
															}

															if(tc_strstr(value_itemid_grp,"PTD")!=NULL)
															{
																if((p4Z01Fnd<=0) && (ptpFnd<=0))
																{
																	p4Z01String=NULL;
																	p4Z01String	=	(char *)MEM_alloc((tc_strlen(value_itemid)*5)+150);//hemal
																	tc_strcpy(p4Z01String,"");//hemal
																}
																tc_strcat(p4Z01String,value_itemid);
																tc_strcat(p4Z01String,";");

																if(ptdFnd==0)
																{
																	ptdMultipleString=NULL;
																	ptdMultipleString	=	(char *)MEM_alloc((tc_strlen(value_itemid)*10)+150);//hemal
																	tc_strcpy(ptdMultipleString,"");//hemal
																}
																tc_strcat(ptdMultipleString,value_itemid);
																tc_strcat(ptdMultipleString,";");
																ptdFnd++;														
																
															}
														
														}
													}

												}
											}
										}

										//if(((ptdFnd>0) || (ptpFnd>0)) && (p4Z01Fnd>0))
										if(   (ptdFnd>0 && p4Z01Fnd>0)  || (ptpFnd>0 && p4Z01Fnd>0))
										{
											ptFnd++;	
										}
									}

								}
							}//end of if
						}

						if(pbB4Fnd>0)
						{
							//if (!ErrString) MEM_free(ErrString) ;
							ErrString=NULL;
							ErrString	=	(char *)MEM_alloc(tc_strlen(b4Z01PBString)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);//Hemal
							tc_strcpy(ErrString,"");
							tc_strcpy(ErrString,"Painted Body ");
							tc_strcat(ErrString,b4Z01PBString);
							tc_strcat(ErrString," are present in Vehicle ");
							tc_strcat(ErrString,partItemId);
							tc_strcat(ErrString,";");
							tc_strcat(ErrString,partItemId_rev);
							tc_strcat(ErrString,".\n");
							setAddStrInApplySVRonX4(&icountB4PB,&SetChildRelB4PB,ErrString);
							
						}

						if(tbB5Fnd>0)
						{
							//if (!ErrString) MEM_free(ErrString) ;
							ErrString=NULL;
							ErrString	=	(char *)MEM_alloc(tc_strlen(b5Z01TBString)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
							tc_strcpy(ErrString,"");
							tc_strcpy(ErrString,"Bolted Part ");
							tc_strcat(ErrString,b5Z01TBString);
							tc_strcat(ErrString," are present in Vehicle ");
							tc_strcat(ErrString,partItemId);
							tc_strcat(ErrString,";");
							tc_strcat(ErrString,partItemId_rev);
							tc_strcat(ErrString,".\n");
							setAddStrInApplySVRonX4(&icountB5TB,&SetChildRelB5TB,ErrString);
							
						}

						if(ptFnd>0)
						{
							//if (!ErrString) MEM_free(ErrString) ;
							ErrString=NULL;
							ErrString	=	(char *)MEM_alloc(tc_strlen(p4Z01String)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
							tc_strcpy(ErrString,"");
							tc_strcpy(ErrString,"PowerTrain ");
							tc_strcat(ErrString,p4Z01String);
							tc_strcat(ErrString," are present in Vehicle ");
							tc_strcat(ErrString,partItemId);
							tc_strcat(ErrString,";");
							tc_strcat(ErrString,partItemId_rev);
							tc_strcat(ErrString,".\n");
							setAddStrInApplySVRonX4(&icountPT,&SetChildRelPT,ErrString);
							
						}

						if(b4Fnd>1)
						{
							ErrString=NULL;
							ErrString	=	(char *)MEM_alloc(tc_strlen(b4Z01MultipleString)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
							tc_strcpy(ErrString,"");
							tc_strcpy(ErrString,"Multiple Painted Assembly ");
							tc_strcat(ErrString,b4Z01MultipleString);
							tc_strcat(ErrString," are present in Vehicle ");
							tc_strcat(ErrString,partItemId);
							tc_strcat(ErrString,";");
							tc_strcat(ErrString,partItemId_rev);
							tc_strcat(ErrString,".\n");
							setAddStrInApplySVRonX4(&icountB4,&SetChildRelB4Multiple,ErrString);
							
						
						}

						if(pbFnd>1)
						{
							
							ErrString=NULL;
							ErrString	=	(char *)MEM_alloc(tc_strlen(PBMultipleString)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
							tc_strcpy(ErrString,"");
							tc_strcpy(ErrString,"Multiple Painted Assembly  ");
							tc_strcat(ErrString,PBMultipleString);
							tc_strcat(ErrString," are present in Vehicle ");
							tc_strcat(ErrString,partItemId);
							tc_strcat(ErrString,";");
							tc_strcat(ErrString,partItemId_rev);
							tc_strcat(ErrString,".\n");
							setAddStrInApplySVRonX4(&icountPB,&SetChildRelPBMultiple,ErrString);
							
						
						}

						if(b5Fnd>1)
						{
							ErrString=NULL;
							ErrString	=	(char *)MEM_alloc(tc_strlen(b5Z01MultipleString)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
							tc_strcpy(ErrString,"");
							tc_strcpy(ErrString,"Multiple Bolted Assembly  ");
							tc_strcat(ErrString,b5Z01MultipleString);
							tc_strcat(ErrString," are present in Vehicle ");
							tc_strcat(ErrString,partItemId);
							tc_strcat(ErrString,";");
							tc_strcat(ErrString,partItemId_rev);
							tc_strcat(ErrString,".\n");
							setAddStrInApplySVRonX4(&icountB5,&SetChildRelB5Multiple,ErrString);
							
						
						}

						if(tbFnd>1)
						{
							ErrString=NULL;
							ErrString	=	(char *)MEM_alloc(tc_strlen(TBMultipleString)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
							tc_strcpy(ErrString,"");
							tc_strcpy(ErrString,"Multiple Bolted Assembly  ");
							tc_strcat(ErrString,TBMultipleString);
							tc_strcat(ErrString," are present in Vehicle ");
							tc_strcat(ErrString,partItemId);
							tc_strcat(ErrString,";");
							tc_strcat(ErrString,partItemId_rev);
							tc_strcat(ErrString,".\n");
							setAddStrInApplySVRonX4(&icountTB,&SetChildRelTBMultiple,TBMultipleString);
							
						
						}

						if(ptdFnd>1)
						{
							ErrString=NULL;
							ErrString	=	(char *)MEM_alloc(tc_strlen(ptdMultipleString)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
							tc_strcpy(ErrString,"");
							tc_strcpy(ErrString,"Multiple Powertrain Assembly  ");
							tc_strcat(ErrString,ptdMultipleString);
							tc_strcat(ErrString," are present in Vehicle ");
							tc_strcat(ErrString,partItemId);
							tc_strcat(ErrString,";");
							tc_strcat(ErrString,partItemId_rev);
							tc_strcat(ErrString,".\n");
							setAddStrInApplySVRonX4(&icountPTD,&SetChildRelPTDMultiple,ErrString);
							
						
						}

						if(ptpFnd>1)
						{
							ErrString=NULL;
							ErrString	=	(char *)MEM_alloc(tc_strlen(ptpMultipleString)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
							tc_strcpy(ErrString,"");
							tc_strcpy(ErrString,"Multiple Powertrain Assembly  ");
							tc_strcat(ErrString,ptpMultipleString);
							tc_strcat(ErrString," are present in Vehicle ");
							tc_strcat(ErrString,partItemId);
							tc_strcat(ErrString,";");
							tc_strcat(ErrString,partItemId_rev);
							tc_strcat(ErrString,".\n");
							setAddStrInApplySVRonX4(&icountPTP,&SetChildRelPTPMultiple,ErrString);
							
						
						}

						if(p4Z01Fnd>1)
						{
							ErrString=NULL;
							ErrString	=	(char *)MEM_alloc(tc_strlen(p4Z01MultipleString)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
							tc_strcpy(ErrString,"");
							tc_strcpy(ErrString,"Multiple Powertrain Assembly  ");
							tc_strcat(ErrString,p4Z01MultipleString);
							tc_strcat(ErrString," are present in Vehicle ");
							tc_strcat(ErrString,partItemId);
							tc_strcat(ErrString,";");
							tc_strcat(ErrString,partItemId_rev);
							tc_strcat(ErrString,".\n");
							setAddStrInApplySVRonX4(&icountP4,&SetChildRelP4Multiple,p4Z01MultipleString);
							
						
						}



					}


				}
			}

			int iLength	=	0;
			int i	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountB4PB; i++)
			{
				tempErr	=	SetChildRelB4PB[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("1.iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			for (i=0; i < icountB4PB; i++)
			{
				
				tc_strcpy(tempErr,SetChildRelB4PB[i]);
				setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n 1. Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);

			iLength	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountB5TB; i++)
			{
				tempErr	=	SetChildRelB5TB[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("2. iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			for (i=0; i < icountB5TB; i++)
			{
				tc_strcpy(tempErr,SetChildRelB5TB[i]);
				setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n2. Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);

			iLength	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountPT; i++)
			{
				tempErr	=	SetChildRelPT[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("3.iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			for (i=0; i < icountPT; i++)
			{
				tc_strcpy(tempErr,SetChildRelPT[i]);
				setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n3.Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);

			iLength	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountB4; i++)
			{
				tempErr	=	SetChildRelB4Multiple[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("4.iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			for (i=0; i < icountB4; i++)
			{
				tc_strcpy(tempErr,SetChildRelB4Multiple[i]);
				setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n4.Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);

			iLength	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountPB; i++)
			{
				tempErr	=	SetChildRelPBMultiple[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("5.iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			for (i=0; i < icountPB; i++)
			{
				tc_strcpy(tempErr,SetChildRelPBMultiple[i]);
				setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n5.Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);

			iLength	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountB5; i++)
			{
				tempErr	=	SetChildRelB5Multiple[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("6.iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			for (i=0; i < icountB5; i++)
			{
				tc_strcpy(tempErr,SetChildRelB5Multiple[i]);
				setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n6.Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);

			iLength	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountTB; i++)
			{
				tempErr	=	SetChildRelTBMultiple[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("7.iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			for (i=0; i < icountTB; i++)
			{
				tc_strcpy(tempErr,SetChildRelTBMultiple[i]);
				setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n7.Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);


			iLength	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountPTD; i++)
			{
				tempErr	=	SetChildRelPTDMultiple[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("8.iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			for (i=0; i < icountPTD; i++)
			{
				tc_strcpy(tempErr,SetChildRelPTDMultiple[i]);
				setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n8.Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);

			iLength	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountPTP; i++)
			{
				tempErr	=	SetChildRelPTPMultiple[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("9.iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			for (i=0; i < icountPTP; i++)
			{
				tc_strcpy(tempErr,SetChildRelPTPMultiple[i]);
				setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n9.Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);

			iLength	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountP4; i++)
			{
				tempErr	=	SetChildRelP4Multiple[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("10.iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+20);
			for (i=0; i < icountP4; i++)
			{
				tc_strcpy(tempErr,SetChildRelP4Multiple[i]);
				setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n10.Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);


			printf("\n\n Exit from function of Check_APLModuleDuplicate.....\n");fflush(stdout);
			return 0;
		}

		int Check_ERCModuleQTY(tag_t TaskTag, int PartCnt,tag_t* PartTags,char	***SetChildRelAPLModErr,int *icount_ebommbom_bom)
		{
			EPM_decision_t decision;
			tag_t			AssyTag				= NULLTAG;
			char*			partType				= NULL;
			char*			partItemId				= NULL;
			char*			partItemId_rev				= NULL;
			char*			childPrtNo				= NULL;
			int k=0;
			tag_t   t_ChildItemRev = NULLTAG;
			tag_t   t_ChildItemRev_grp = NULLTAG;
			tag_t   t_itemTag=NULLTAG;
			tag_t   t_itemTag_grp=NULLTAG;
			int pbTbFnd=0;
			int childPrtC=0;
			int iChildItemTag=0;
			int iChildItemTag_grp=0;

			date_t Release_date;
			char*		ErrString	=	NULL;
			char*		b4Z01PBString	=	NULL;
			char*		b5Z01TBString	=	NULL;
			char*		p4Z01String	=	NULL;
			char*		aplModBomQtyString	=	NULL;
			char*		aplModViewMskString	=	NULL;
			char*		value_itemid	=	NULL;
			char*		value_itemRevID	=	NULL;
			char*		value_itemRevPartType	=	NULL;
			char*		value_flag	=	NULL;
			char*		aplBiwModule	=	NULL;
			char*		ercBiwModule1	=	NULL;
			char*		ercBiwModule2	=	NULL;
			char*		aplPTModule	=	NULL;
			char*		ercPTModule	=	NULL;
			char*		aplModule1	=	NULL;
			char*		aplModule2	=	NULL;
			char*		viewmask	=	NULL;
			char*		revisionRule	=	NULL;
			char*		Item_ID_Check	=	NULL;
			char*		sItem_id	=	NULL;
			char*		sItem_id_grp	=	NULL;
			char*		sItem_id_rev	=	NULL;
			char*		sItem_id_rev_grp	=	NULL;
			tag_t   window					=	NULLTAG;
			tag_t   window_grp					=	NULLTAG;
			tag_t	rule								= NULLTAG;
			tag_t	rule_grp								= NULLTAG;
			tag_t			bvr_tag= NULLTAG;
			tag_t			bvr_tag_grp= NULLTAG;
			tag_t	top_line							= NULLTAG;
			tag_t	top_line_grp							= NULLTAG;
			int		nClhd=0;
			int		nClhd_grp=0;
			tag_t  *children = NULLTAG;
			tag_t  *children_grp = NULLTAG;
			tag_t Bomline_tag = NULLTAG;
			tag_t Bomline_tag_grp = NULLTAG;
			int			attribute_flag					=0;
			int			attribute_flag_grp					=0;
			int			attribute_qty					=0;
			int			attribute_qty_grp					=0;
			int			value_qty					=0;
			
			char    *qry_entryCntrlBiw[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrlBiw= (char **) MEM_alloc(5 * sizeof(char *));

			int cntrlcnt=0;
			int  control_number_foundBiw=0;

			tag_t *list_of_WSO_cntrl_tagsBiw=NULLTAG;

			tag_t   qryTagCntrlBiw     = NULLTAG;
			int     n_entryCntrlBiw    = 3;

			char    *qry_entryCntrlPT[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrlPT= (char **) MEM_alloc(5 * sizeof(char *));

			int  control_number_foundPT=0;

			tag_t *list_of_WSO_cntrl_tagsPT=NULLTAG;

			int     n_entryCntrlPT    = 3;

			char	**SetChildRelB4PB	= NULL;
			char	**SetChildRelB5TB	= NULL;
			char	**SetChildRelPT	= NULL;
			char	**SetChildRelQty	= NULL;
			char	**SetChildRelViewMsk	= NULL;
			char	*value_itemid_grp	= NULL;
			char	*value_itemRevID_grp	= NULL;
			char	*value_itemRevPartType_grp	= NULL;
			char	*Item_ID_Check_grp_SA	= NULL;
			char	*value_flag_grp	= NULL;
			char	*value_qty1_grp	= NULL;
			int icountQty =0; 
			int icountB4PB =0; 
			int icountPT =0; 
			int icountViewMsk =0; 
			int icountB5TB =0; 
			char	*tempErr				=	NULL;


			printf("\n\n\t\t inside Check_APLModuleQTY fucntion");fflush(stdout);



			if(QRY_find2("Control Objects...", &qryTagCntrlBiw));
			if (qryTagCntrlBiw)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrlBiw[0]="ERC_APL_BOM_Validation";
				qry_valuesCntrlBiw[1]="SignoffValidation";
				qry_valuesCntrlBiw[2]="0";

				if(QRY_execute(qryTagCntrlBiw, n_entryCntrlBiw, qry_entryCntrlBiw, qry_valuesCntrlBiw, &control_number_foundBiw, &list_of_WSO_cntrl_tagsBiw));

				qry_valuesCntrlPT[0]="APL_Module_Mapping";
				qry_valuesCntrlPT[1]="SignOffValidation";
				qry_valuesCntrlPT[2]="0";

				if(QRY_execute(qryTagCntrlBiw, n_entryCntrlPT, qry_entryCntrlPT, qry_valuesCntrlPT, &control_number_foundPT, &list_of_WSO_cntrl_tagsPT));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	

			printf("\n control_number_found1 is : %d\n",control_number_foundBiw);fflush(stdout);

			if(control_number_foundBiw>0)
			{
			
				if(control_number_foundPT>0)
				{
				
					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo1", &aplModule1));
					printf("\n aplModule1: %s\n",aplModule1);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo2", &aplModule2));
					printf("\n aplModule2: %s\n",aplModule2);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo3", &viewmask));
					printf("\n viewmask: %s\n",viewmask);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo4", &revisionRule));
					printf("\n revisionRule: %s\n",revisionRule);fflush(stdout);

				
				}

				SetChildRelQty=NULL;
				SetChildRelQty = (char**)MEM_alloc( 1 * sizeof *SetChildRelQty );

				SetChildRelViewMsk=NULL;
				SetChildRelViewMsk = (char**)MEM_alloc( 1 * sizeof *SetChildRelViewMsk );


				for (k=0;k<PartCnt ;k++ )
				{

					printf("\n\n\t\t inside Check_APLModuleQTY APL DML Cre:for k_4 =:%d",k);fflush(stdout);
					
					AssyTag=NULLTAG;
					
					AssyTag=PartTags[k];

					
					ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&partType));
					printf("\n partType:%s ..............",partType);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&partItemId));
					printf("\n partItemId:%s ..............",partItemId);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&partItemId_rev));
					printf("\n partItemId_rev:%s ..............",partItemId_rev);fflush(stdout);

					if((tc_strcmp(partType,"V")==0))	
					{
						printf("\n Inside PartType Check");fflush(stdout);
						
						ITKCALL(BOM_create_window (&window));
						printf("\n find occurence..window");fflush(stdout);
						ITKCALL(CFM_find("Color ERC Review and above", &rule)); //"Latest Working"
						printf("\n find occurence..rule");fflush(stdout);
						ITKCALL(BOM_set_window_config_rule( window, rule ));
						printf("\n configure occurence..rule");fflush(stdout);
						ITKCALL(BOM_set_window_top_line(window, null_tag,AssyTag , bvr_tag, &top_line));
						ITKCALL(BOM_line_ask_child_lines (top_line, &nClhd, &children));
						printf("\n nClhd %d,",nClhd);fflush(stdout);

						int childPrtC = 0;
						int qtyErr	= 0;
						int viewMskErr	= 0;
						int ck	= 0;
						int value_qtyInt	= 0;

					
						for (ck = 0; ck < nClhd; ck++)				//Vehicle BOM
						{
							//get the revision from bomline
							//ITKCALL(BOM_line_unpack (children[ck]));
							ITKCALL(BOM_line_pack (children[ck]));

							t_ChildItemRev=NULLTAG;
							t_itemTag=NULLTAG;
							sItem_id=NULL;
							sItem_id_rev=NULL;

							//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
							//ITKCALL(BOM_line_ask_attribute_tag(children[ck], iChildItemTag, &t_ChildItemRev));
						    ITKCALL(AOM_ask_value_string(children[ck], "bl_item_item_id", &sItem_id));
							ITKCALL(AOM_ask_value_string(children[ck], "bl_rev_item_revision_id", &sItem_id_rev));
							printf("\n\n TCUA 14.3 bl_rev_item_revision_id---------------->%s ,%s\n",sItem_id,sItem_id_rev); fflush(stdout);
							ITKCALL(ITEM_find_item(sItem_id,&t_itemTag));
							ITKCALL(ITEM_find_revision(t_itemTag,sItem_id_rev,&t_ChildItemRev));
														
							if(t_ChildItemRev!=NULLTAG)
							{

								Bomline_tag=NULLTAG;
								Bomline_tag = children[ck];
								if(Bomline_tag!=NULLTAG)
								{
									value_itemid=NULL;
									value_itemRevID=NULL;
									value_itemRevPartType=NULL;
									value_flag=NULL;
									Item_ID_Check=NULL;
									value_qtyInt=0;
									char *value_qty1=NULL;

									ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&value_itemid))
									printf("\n Arc Node child value_itemid:%s ..............",value_itemid);fflush(stdout);

									ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&value_itemRevID))
									printf("\n value_itemRevID:%s ..............",value_itemRevID);fflush(stdout);

									ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartType",&value_itemRevPartType))
									printf("\n value_itemRevPartType:%s ..............",value_itemRevPartType);fflush(stdout);

									if(tc_strcmp(value_itemRevPartType,"M")==0 )
									{
										Item_ID_Check=subString(value_itemid,4,5);
										printf("\n  M Item_ID_Check:%s ..............",Item_ID_Check);fflush(stdout);
									}
									else if((tc_strcmp(value_itemRevPartType,"SA")==0 ) && (tc_strstr(value_itemid,"PTP")!=NULL || tc_strstr(value_itemid,"PTD")!=NULL))
									{
										Item_ID_Check=subString(value_itemid,8,3);
										printf("\n  SA fro PT Item_ID_Check:%s ..............",Item_ID_Check);fflush(stdout);
									}
									else if((tc_strcmp(value_itemRevPartType,"SA")==0 ) && (tc_strstr(value_itemid,"PB")!=NULL || tc_strstr(value_itemid,"TB")!=NULL))
									{
										Item_ID_Check=subString(value_itemid,8,2);
										printf("\n  SA Item_ID_Check:%s ..............",Item_ID_Check);fflush(stdout);
									}
									
									if(tc_strstr(aplModule1,Item_ID_Check)!=NULL || tc_strstr(aplModule2,Item_ID_Check)!=NULL)
									{

										//ITKCALL(BOM_line_look_up_attribute(viewmask, &attribute_flag));//bl_occ_t5_CurrentViewMaskC
										//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_flag, &value_flag));
										ITKCALL(AOM_UIF_ask_value(Bomline_tag,viewmask,&value_flag));
										printf("\n TCUA 14.3 value_flag:%s ..............",value_flag);fflush(stdout);

										//ITKCALL(BOM_line_look_up_attribute("bl_quantity", &attribute_qty));
										//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_qty, &value_qty1));
										ITKCALL(AOM_UIF_ask_value(Bomline_tag,"bl_quantity",&value_qty1));
										printf("\n  TCUA 14.3 value_qty1:%s ..............",value_qty1);fflush(stdout);

										value_qtyInt =atoi(value_qty1);
										printf("\n  value_qtyInt:%d ..............",value_qtyInt);fflush(stdout);

										if((tc_strstr(value_flag,"-12")==NULL) || (tc_strcmp(value_flag,"")==0))
										{
											
											//if (!ErrString) MEM_free(ErrString) ;
											ErrString=NULL;
											ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemid)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
											tc_strcpy(ErrString,"");
											tc_strcat(ErrString,value_itemid);
											tc_strcat(ErrString," for Vehicle ");
											tc_strcat(ErrString,partItemId);
											tc_strcat(ErrString,";");
											tc_strcat(ErrString,partItemId_rev);
											tc_strcat(ErrString,".\n");
											setAddStrInApplySVRonX4(&icountViewMsk,&SetChildRelViewMsk,ErrString);
											
										
										}

										
										if(value_qtyInt>1)
										{
												
											//if (!ErrString) MEM_free(ErrString) ;
											ErrString=NULL;
											ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemid)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
											tc_strcpy(ErrString,"");
											tc_strcpy(ErrString,value_itemid);
											tc_strcat(ErrString," for Vehicle ");
											tc_strcat(ErrString,partItemId);
											tc_strcat(ErrString,";");
											tc_strcat(ErrString,partItemId_rev);
											tc_strcat(ErrString,".\n");
											setAddStrInApplySVRonX4(&icountQty,&SetChildRelQty,ErrString);
											
										
										}
										
										

									}

									if(tc_strcmp(value_itemRevPartType,"G")==0 )				//Check for PTP/PTD in Grp Part
									{
										
										//ITKCALL(BOM_line_look_up_attribute(viewmask, &attribute_flag));//bl_occ_t5_CurrentViewMaskC
										//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_flag, &value_flag));
                                        ITKCALL(AOM_UIF_ask_value(Bomline_tag,viewmask,&value_flag));
										printf("\n  value_flag:%s ..............",value_flag);fflush(stdout);

										//ITKCALL(BOM_line_look_up_attribute("bl_quantity", &attribute_qty));
										//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_qty, &value_qty1));
										ITKCALL(AOM_UIF_ask_value(Bomline_tag,"bl_quantity",&value_qty1));
										printf("\n  value_qty1:%s ..............",value_qty1);fflush(stdout);

										value_qtyInt =atoi(value_qty1);
										printf("\n  value_qtyInt:%d ..............",value_qtyInt);fflush(stdout);
										
										ITKCALL(BOM_create_window (&window_grp));
										printf("\n find occurence..window_grp");fflush(stdout);
										ITKCALL(CFM_find("Color ERC Review and above", &rule_grp)); //"Latest Working"
										printf("\n find occurence..rule_grp");fflush(stdout);
										ITKCALL(BOM_set_window_config_rule( window_grp, rule_grp ));
										printf("\n configure occurence..rule_grp");fflush(stdout);
										ITKCALL(BOM_set_window_top_line(window_grp, null_tag,t_ChildItemRev , bvr_tag_grp, &top_line_grp));
										ITKCALL(BOM_line_ask_child_lines (top_line_grp, &nClhd_grp, &children_grp));
										printf("\n nClhd_grp %d,",nClhd_grp);fflush(stdout);

										int ck_grp	= 0;
										int value_qty1_grpInt	= 0;
										int grpPrtViewMskErr	= 0;
										int grpPrtQtyErr	= 0;

										for (ck_grp = 0; ck_grp < nClhd_grp; ck_grp++)				//Grp Part BOM
										{
											//get the revision from bomline
											ITKCALL(BOM_line_pack (children_grp[ck_grp]));

											t_ChildItemRev_grp=NULLTAG;
											t_itemTag_grp=NULLTAG;
											sItem_id_grp=NULL;
											sItem_id_rev_grp=NULL;

											//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag_grp));
											//ITKCALL(BOM_line_ask_attribute_tag(children_grp[ck_grp], iChildItemTag_grp, &t_ChildItemRev_grp));
										    ITKCALL(AOM_ask_value_string(children_grp[ck_grp], "bl_item_item_id", &sItem_id_grp));
											ITKCALL(AOM_ask_value_string(children_grp[ck_grp], "bl_rev_item_revision_id", &sItem_id_rev_grp));
											printf("\n\n TCUA 14.3 bl_item_item_id is---------------->%s ,%s\n",sItem_id_grp,sItem_id_rev_grp); fflush(stdout);

											ITKCALL(ITEM_find_item(sItem_id_grp,&t_itemTag_grp));
											ITKCALL(ITEM_find_revision(t_itemTag_grp,sItem_id_rev_grp,&t_ChildItemRev_grp));
											
											if(t_ChildItemRev_grp!=NULLTAG)
											{

												Bomline_tag_grp=NULLTAG;
												Bomline_tag_grp = children_grp[ck_grp];

												if(Bomline_tag_grp!=NULLTAG)
												{
													
													value_itemid_grp=NULL;
													value_itemRevID_grp=NULL;
													value_itemRevPartType_grp=NULL;
													Item_ID_Check_grp_SA=NULL;
													value_flag_grp=NULL;
													value_qty1_grp=NULL;
													value_qty1_grpInt=0;

													ITKCALL(AOM_ask_value_string(t_ChildItemRev_grp,"item_id",&value_itemid_grp))
													printf("\n Arc Node child value_itemid_grp:%s ..............",value_itemid_grp);fflush(stdout);

													ITKCALL(AOM_ask_value_string(t_ChildItemRev_grp,"item_revision_id",&value_itemRevID_grp))
													printf("\n value_itemRevID_grp:%s ..............",value_itemRevID_grp);fflush(stdout);

													ITKCALL(AOM_ask_value_string(t_ChildItemRev_grp,"t5_PartType",&value_itemRevPartType_grp))
													printf("\n value_itemRevPartType_grp:%s ..............",value_itemRevPartType_grp);fflush(stdout);

													if(tc_strcmp(value_itemRevPartType_grp,"SA")==0 )
													{
														Item_ID_Check_grp_SA=subString(value_itemid_grp,8,3);
														printf("\n  SA Item_ID_Check_grp_SA:%s ..............",Item_ID_Check_grp_SA);fflush(stdout);
													
														if(tc_strstr(aplModule1,Item_ID_Check_grp_SA)!=NULL || tc_strstr(aplModule2,Item_ID_Check_grp_SA)!=NULL)
														{
															
															//ITKCALL(BOM_line_look_up_attribute("bl_quantity", &attribute_qty_grp));
															//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag_grp, attribute_qty_grp, &value_qty1_grp));
															ITKCALL(AOM_UIF_ask_value(Bomline_tag_grp,"bl_quantity",&value_qty1_grp));
															printf("\n  value_qty1_grp:%s ..............",value_qty1_grp);fflush(stdout);

															value_qty1_grpInt =atoi(value_qty1_grp);
															printf("\n  value_qty1_grpInt:%d ..............",value_qty1_grpInt);fflush(stdout);

															//ITKCALL(BOM_line_look_up_attribute(viewmask, &attribute_flag_grp));//bl_occ_t5_CurrentViewMaskC
															//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag_grp, attribute_flag_grp, &value_flag_grp));
															ITKCALL(AOM_UIF_ask_value(Bomline_tag_grp,viewmask,&value_flag_grp));
															printf("\n  value_flag_grp:%s ..............",value_flag_grp);fflush(stdout);

															if((tc_strstr(value_flag,"-12")==NULL) || (tc_strcmp(value_flag,"")==0))
															{
																
																if(grpPrtViewMskErr==0)
																{
																	ErrString=NULL;
																	ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemid)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
																	tc_strcpy(ErrString,"");
																	tc_strcat(ErrString,value_itemid);
																	tc_strcat(ErrString," for Vehicle ");
																	tc_strcat(ErrString,partItemId);
																	tc_strcat(ErrString,";");
																	tc_strcat(ErrString,partItemId_rev);
																	tc_strcat(ErrString,".\n");
																	printf("\n 1. For Grp ErrString:%s ..............",ErrString);fflush(stdout);
																	setAddStrInApplySVRonX4(&icountViewMsk,&SetChildRelViewMsk,ErrString);
																	
																	grpPrtViewMskErr=1;
																}
															
															}
															
															if(value_qtyInt>1)
															{
																	
																if(grpPrtQtyErr==0)
																{
																	ErrString=NULL;
																	ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemid)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
																	tc_strcpy(ErrString,"");
																	tc_strcpy(ErrString,value_itemid);
																	tc_strcat(ErrString," for Vehicle ");
																	tc_strcat(ErrString,partItemId);
																	tc_strcat(ErrString,";");
																	tc_strcat(ErrString,partItemId_rev);
																	tc_strcat(ErrString,".\n");
																	printf("\n 3 For Grp ErrString:%s ..............",ErrString);fflush(stdout);
																	setAddStrInApplySVRonX4(&icountQty,&SetChildRelQty,ErrString);
																	
																	grpPrtQtyErr=1;
																}
															
															}
															
															if(value_qty1_grpInt>1)
															{
																	
																ErrString=NULL;
																ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemid_grp)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
																tc_strcpy(ErrString,"");
																tc_strcpy(ErrString,value_itemid_grp);
																tc_strcat(ErrString," for Vehicle ");
																tc_strcat(ErrString,partItemId);
																tc_strcat(ErrString,";");
																tc_strcat(ErrString,partItemId_rev);
																tc_strcat(ErrString,".\n");
																printf("\n 4.or Grp ErrString:%s ..............",ErrString);fflush(stdout);
																setAddStrInApplySVRonX4(&icountQty,&SetChildRelQty,ErrString);
																
															
															}

															if((tc_strstr(value_flag_grp,"-12")!=NULL) || (tc_strcmp(value_flag_grp,"")!=0))
															{
																
																ErrString=NULL;
																ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemid_grp)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+550);
																tc_strcpy(ErrString,"");
																tc_strcat(ErrString,value_itemid_grp);
																tc_strcat(ErrString," for Vehicle ");
																tc_strcat(ErrString,partItemId);
																tc_strcat(ErrString,";");
																tc_strcat(ErrString,partItemId_rev);
																tc_strcat(ErrString,".\n");
																printf("\n 4. For Grp ErrString:%s ..............",ErrString);fflush(stdout);
																setAddStrInApplySVRonX4(&icountViewMsk,&SetChildRelViewMsk,ErrString);
																
																	
															
															}
														
														
														}
																						
													}
												}
				
											}
										}
									
								
									}
								}
							}//end of if
						}

					}


				}

				int iLength	=	0;
				int i	=	0;
				if (!tempErr) MEM_free(tempErr);
				for (i=0; i < icountQty; i++)
				{
					tempErr	=	SetChildRelQty[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("4.iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+120);
				for (i=0; i < icountQty; i++)
				{
					if(i==0)
					{
						tc_strcpy(tempErr,"\n Below APL Modules are present in BOM with Quantity >1 :\n ");
						tc_strcat(tempErr,SetChildRelQty[i]);
					}
					else
					{
						tc_strcpy(tempErr,SetChildRelQty[i]);
					}
					setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
					
				}
				printf("\n4.Printing Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);

				iLength	=	0;
				if (!tempErr) MEM_free(tempErr);
				for (i=0; i < icountViewMsk; i++)
				{
					tempErr	=	SetChildRelViewMsk[i];
					iLength	=	iLength	+	tc_strlen(tempErr);
				}
				printf("5.iLength : %d",iLength);fflush(stdout);
				if (!tempErr) MEM_free(tempErr);
				tempErr	=	(char *)MEM_alloc(iLength+120);
				for (i=0; i < icountViewMsk; i++)
				{
					if(i==0)
					{
						tc_strcpy(tempErr,"\n Below APL Modules are present in BOM with incorrect ViewMask :\n ");
						tc_strcat(tempErr,SetChildRelViewMsk[i]);
					}
					else
					{
						tc_strcpy(tempErr,SetChildRelViewMsk[i]);
					}
					setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,tempErr);
					
				}
				printf("\n5.Printing Errors...!!!");fflush(stdout);
				printf("%s",tempErr);fflush(stdout);
			}

			printf("\n\n Exit from function of APl-ERC BOM.....\n");fflush(stdout);
			return 0;
		}

		int Check_ERCModuleColourSuffix(tag_t TaskTag,int PartCnt, tag_t* PartTags,char ***SetChildRelAPLModErr,int *icount_ebommbom_bom)
		{
			EPM_decision_t decision;
			tag_t			AssyTag				= NULLTAG;
			tag_t			parents_tag				= NULLTAG;
			char*			partType				= NULL;
			char*			partItemId				= NULL;
			char*			partItemId_rev				= NULL;
			char*			ParetnName				= NULL;
			char*			ParetnRevId				= NULL;
			char*			ParetnPrtType				= NULL;
			char*			colourVCSuffixVal				= NULL;
			tag_t   qryTagCntrlBiw     = NULLTAG;
			char    *qry_entryCntrlBiw[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrlBiw= (char **) MEM_alloc(5 * sizeof(char *));
			int		*levels					=	0;

			int cntrlcnt=0;
			int  control_number_foundBiw=0;
			int		n_parents					=	0;
			int		ck					=	0;
			int		*levels_prnt					=	0;



			tag_t *list_of_WSO_cntrl_tagsBiw=NULLTAG;

			int     n_entryCntrlBiw    = 3;

			char    *qry_entryCntrlPT[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrlPT= (char **) MEM_alloc(5 * sizeof(char *));

			int  control_number_foundPT=0;

			tag_t *list_of_WSO_cntrl_tagsPT=NULLTAG;

			int     n_entryCntrlPT    = 3;

			char*		aplModule1	=	NULL;
			char*		aplModule2	=	NULL;
			char*		aplPTModule	=	NULL;
			char*		ercPTModule	=	NULL;
			char*		viewmask	=	NULL;
			char*		revisionRule	=	NULL;
			char*		revisionRuleSTD	=	NULL;
			char		*value_itemid=NULL;
			char		*value_itemRevID=NULL;
			char		*value_itemRevPartType=NULL;
			char		*colourAPLModSuffixVal=NULL;
			char*		Item_ID_Check	=	NULL;
			tag_t   window					=	NULLTAG;
			tag_t	rule								= NULLTAG;
			tag_t			bvr_tag= NULLTAG;
			tag_t	top_line							= NULLTAG;
			int		nClhd=0;
			tag_t  *children;
			tag_t Bomline_tag = NULLTAG;
			int k =0; 
			int jp=0; 
			tag_t	*parents				=	NULLTAG;

			int icountErr =0; 
			int iChildItemTag=0;
			int errFlag=0;
			tag_t   t_ChildItemRev = NULLTAG;
			tag_t t_itemTag=NULLTAG;
			char* sItem_id=NULL;
			char* sItem_id_rev=NULL;
			char*		ErrString	=	NULL;
			char*		value_itemColInd	=	NULL;
			tag_t revRule 			= NULLTAG;


			if(QRY_find2("Control Objects...", &qryTagCntrlBiw));
			if (qryTagCntrlBiw)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				qry_valuesCntrlBiw[0]="ERC_APL_BOM_Validation";
				qry_valuesCntrlBiw[1]="APLModuleSuffix";
				qry_valuesCntrlBiw[2]="0";

				if(QRY_execute(qryTagCntrlBiw, n_entryCntrlBiw, qry_entryCntrlBiw, qry_valuesCntrlBiw, &control_number_foundBiw, &list_of_WSO_cntrl_tagsBiw));

				qry_valuesCntrlPT[0]="APL_Module_Mapping";
				qry_valuesCntrlPT[1]="SignOffValidation";
				qry_valuesCntrlPT[2]="0";

				if(QRY_execute(qryTagCntrlBiw, n_entryCntrlPT, qry_entryCntrlPT, qry_valuesCntrlPT, &control_number_foundPT, &list_of_WSO_cntrl_tagsPT));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	

			printf("\n control_number_found1 is : %d\n",control_number_foundBiw);fflush(stdout);

			if(control_number_foundBiw>0)
			{
				
				if(control_number_foundPT>0)
				{
				
					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo1", &aplModule1));
					printf("\n aplModule1: %s\n",aplModule1);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo2", &aplModule2));
					printf("\n aplModule2: %s\n",aplModule2);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo3", &viewmask));
					printf("\n viewmask: %s\n",viewmask);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo4", &revisionRule));
					printf("\n revisionRule: %s\n",revisionRule);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo5", &revisionRuleSTD));
					printf("\n revisionRuleSTD: %s\n",revisionRuleSTD);fflush(stdout);
					
					ITKCALL(CFM_find("Color ERC Review and above", &revRule));

					/*
					if(tc_strcmp(signOffDept,"APL")==0)
					{
						ITKCALL(CFM_find(revisionRule, &revRule));
						if (revRule != NULLTAG)
						{
							printf("\nFind revRule\n");fflush(stdout);
						}
					}
					else if(tc_strcmp(signOffDept,"STD")==0)
					{
						ITKCALL(CFM_find(revisionRuleSTD, &revRule));
						if (revRule != NULLTAG)
						{
							printf("\nFind revRule\n");fflush(stdout);
						}
					}
					*/

				}


				for (k=0;k<PartCnt ;k++ )
				{

					printf("\n\n\t\t inside Check_APLModuleDuplicate APL DML Cre:for k_4 =:%d",k);fflush(stdout);
					AssyTag=NULLTAG;
					AssyTag=PartTags[k];

					partType=NULL;
					partItemId=NULL;
					partItemId_rev=NULL;

					ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&partType));
					printf("\n partType:%s ..............",partType);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&partItemId));
					printf("\n partItemId:%s ..............",partItemId);fflush(stdout);

					ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&partItemId_rev));
					printf("\n partItemId_rev:%s ..............",partItemId_rev);fflush(stdout);

					if((tc_strcmp(partType,"V")==0))	
					{
						printf("\n Inside PartType Check");fflush(stdout);

						ITKCALL(PS_where_used_configured(AssyTag,revRule,1,&n_parents,&levels_prnt,&parents));

						printf("\n\n\t\t No of Assy objects are n_parents : %d\n",n_parents);fflush(stdout);
						if(n_parents>0)
						{
							for(jp=0;jp<n_parents;jp++)
							{
								parents_tag=NULLTAG;
								parents_tag=parents[jp];
								
								if(parents_tag!=NULLTAG)
								{
									ParetnName=NULL;
									ParetnPrtType=NULL;
									colourVCSuffixVal=NULL;
									ParetnRevId=NULL;

									ITKCALL(AOM_ask_value_string(parents_tag,"item_id",&ParetnName));
									printf("\n Fparents %s",ParetnName);fflush(stdout);
									
									ITKCALL(AOM_ask_value_string(parents_tag,"item_revision_id",&ParetnRevId));
									printf("\n ParetnRevId %s",ParetnRevId);fflush(stdout);

									ITKCALL(AOM_ask_value_string(parents_tag,"t5_PartType",&ParetnPrtType));
									printf("\n ParetnPrtType:%s ..............",ParetnPrtType);fflush(stdout);
									if((tc_strcmp(ParetnPrtType,"VC")==0))	
									{
										colourVCSuffixVal=subString(ParetnName,tc_strlen(ParetnName)-3,2);	
										printf("\n colourVCSuffixVal:%s ..............",colourVCSuffixVal);fflush(stdout);
										break;
									
									}

								
								}
							}
						

							ITKCALL(BOM_create_window (&window));
							printf("\n find occurence..window");fflush(stdout);
							ITKCALL(CFM_find("Color ERC Review and above", &rule));
							printf("\n find occurence..rule");fflush(stdout);
							ITKCALL(BOM_set_window_config_rule( window, rule ));
							printf("\n configure occurence..rule");fflush(stdout);
							ITKCALL(BOM_set_window_top_line(window, null_tag,AssyTag , bvr_tag, &top_line));
							ITKCALL(BOM_line_ask_child_lines (top_line, &nClhd, &children));
							printf("\n nClhd %d,",nClhd);fflush(stdout);

							for (ck = 0; ck < nClhd; ck++)				//Vehicle BOM
							{
								//get the revision from bomline
								ITKCALL(BOM_line_pack (children[ck]));

								t_ChildItemRev=NULLTAG;
								t_itemTag=NULLTAG;
								sItem_id=NULL;
								sItem_id_rev=NULL;

								//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
								//ITKCALL(BOM_line_ask_attribute_tag(children[ck], iChildItemTag, &t_ChildItemRev));
								CALLAPI(AOM_ask_value_string(children[ck], "bl_item_item_id", &sItem_id));
								 CALLAPI(AOM_ask_value_string(children[ck], "bl_rev_item_revision_id", &sItem_id_rev));
							     printf("\n\n TCUA 14.3 bl_item_item_id is---------------->%s ,%s\n",sItem_id,sItem_id_rev); fflush(stdout);

								 CALLAPI(ITEM_find_item(sItem_id,&t_itemTag));
								 CALLAPI(ITEM_find_revision(t_itemTag,sItem_id_rev,&t_ChildItemRev));
								
								if(t_ChildItemRev!=NULLTAG)
								{

									Bomline_tag=NULLTAG;
									Bomline_tag = children[ck];

									if(Bomline_tag!=NULLTAG)
									{
										value_itemid=NULL;
										value_itemRevID=NULL;
										value_itemRevPartType=NULL;
										value_itemColInd=NULL;
										Item_ID_Check=NULL;
										colourAPLModSuffixVal=NULL;

										ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&value_itemid))
										printf("\n 111 Arc Node child value_itemid:%s ..............",value_itemid);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&value_itemRevID))
										printf("\n 111 value_itemRevID:%s ..............",value_itemRevID);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartType",&value_itemRevPartType))
										printf("\n 111 value_itemRevPartType:%s ..............",value_itemRevPartType);fflush(stdout);

										ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_ColourInd",&value_itemColInd))
										printf("\n 111 value_itemColInd:%s ..............",value_itemColInd);fflush(stdout);

										if( (tc_strstr(value_itemid,"PB")!=NULL) || (tc_strstr(value_itemid,"B4Z01")!=NULL))
										{								
											colourAPLModSuffixVal=subString(value_itemid,tc_strlen(value_itemid)-2,2);	
											printf("\n colourAPLModSuffixVal:%s ..............%s:",colourAPLModSuffixVal,colourVCSuffixVal);fflush(stdout);

											if(tc_strcmp(colourAPLModSuffixVal,colourVCSuffixVal)!=0)
											{
												printf("\n In Side from tc_strcmp(colourAPLModSuffixVal,colourVCSuffixVal)..............");fflush(stdout);

												errFlag++;
												ErrString=NULL;
												ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemid)+tc_strlen(partItemId)+tc_strlen(partItemId_rev)+tc_strlen(ParetnName)+tc_strlen(ParetnRevId)+550);
												if(errFlag==1)
												{
													tc_strcpy(ErrString,"Colour suffix is Incorrect for Painted body colour module (B4Z01 or PB) :\n");
												}
												else
												{
													tc_strcpy(ErrString,"");	
												}
												
												tc_strcat(ErrString,value_itemid);
												tc_strcat(ErrString," in Vehicle ");
												tc_strcat(ErrString,partItemId);
												tc_strcat(ErrString,";");
												tc_strcat(ErrString,partItemId_rev);
												tc_strcat(ErrString,"-->VC-");
												tc_strcat(ErrString,ParetnName);
												tc_strcat(ErrString,";");
												tc_strcat(ErrString,ParetnRevId);
												tc_strcat(ErrString,".\n");

												printf("\n ErrString is..............>%s",ErrString);fflush(stdout);
												setAddStrInApplySVRonX4(icount_ebommbom_bom,SetChildRelAPLModErr,ErrString);									
											} 

											printf("\n Out Side from tc_strcmp(colourAPLModSuffixVal,colourVCSuffixVal)..............");fflush(stdout);									
										}
									}
								}
							}
						}


					}
				}
			}
			printf("\n\n Exit from function of APl-ERC BOM.....\n");fflush(stdout);
			return 0;
		}

		int Check_ERCModSuppress1(tag_t TaskTag, int PartCnt,char *signOffDept,tag_t* PartTags,char ***SetChildRelAPLModErr,int *icount_ebommSupp)
		{
			EPM_decision_t decision;
			tag_t			AssyTag				= NULLTAG;
			char*			partType				= NULL;
			char*			partItemId				= NULL;
			char*			taskowning_groupVal				= NULL;
			char*			childPrtNo				= NULL;
			int k=0;
			char RevRuleInfo1[40];
			char BVRInfo2[40];
			char Info3[40];
			struct			BomChldStrut	ChldStrutBdySh[5000];
			int	StructCntBdyShProdPlan	= 0,pbFnd=0,tbFnd=0;
			tag_t objChild_BVR		= NULLTAG;
			int iChildItemTag;
			tag_t   t_ChildItemRev;
			tag_t t_itemTag;
			char* sItem_id=NULL;
			char* sItem_id_rev=NULL;
			int VehicleCnt=0;
			int pbTbFnd=0;
			int childPrtC=0;
			char cCurrentAccessDate[20]={0};
			date_t Release_date;
			char*		ErrString	=	NULL;
			char*		b4Z01PBString	=	NULL;
			char*		b5Z01TBString	=	NULL;
			char*		p4Z01String	=	NULL;
			char*		aplModBomQtyString	=	NULL;
			char*		aplModViewMskString	=	NULL;
			char*		ercModViewMskString	=	NULL;
			char*		value_itemid	=	NULL;
			char*		value_itemRevID	=	NULL;
			char*		value_itemRevPartType	=	NULL;
			char*		value_flag	=	NULL;
			char*		aplBiwModule	=	NULL;
			char*		ercBiwModule1	=	NULL;
			char*		ercBiwModule2	=	NULL;
			char*		ercBiwModule3	=	NULL;
			char*		aplPTModule	=	NULL;
			char*		ercPTModule	=	NULL;
			char*		Item_ID_Check	=	NULL;
			tag_t   window					=	NULLTAG;
			tag_t	rule								= NULLTAG;
			tag_t			bvr_tag= NULLTAG;
			tag_t	top_line							= NULLTAG;
			int		nClhd=0;
			tag_t  *children;
			tag_t Bomline_tag = NULLTAG;
			int			attribute_flag					=0;
			int			attribute_qty					=0;
			int			value_qty					=0;
			
			char    *qry_entryCntrlBiw[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrlBiw= (char **) MEM_alloc(5 * sizeof(char *));

			int cntrlcnt=0;
			int  control_number_foundBiw=0;

			tag_t *list_of_WSO_cntrl_tagsBiw=NULLTAG;

			tag_t   qryTagCntrlBiw     = NULLTAG;
			int     n_entryCntrlBiw    = 3;

			char    *qry_entryCntrlPT[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
			char	**qry_valuesCntrlPT= (char **) MEM_alloc(5 * sizeof(char *));

			int  control_number_foundPT=0;

			tag_t *list_of_WSO_cntrl_tagsPT=NULLTAG;

			int     n_entryCntrlPT    = 3;

			char	**SetChildRelB4PB	= NULL;
			char	**SetChildRelB5TB	= NULL;
			char	**SetChildRelPT	= NULL;
			char	**SetChildRelQty	= NULL;
			char	**SetChildRelViewMsk	= NULL;
			int icountQty =0; 
			int icountB4PB =0; 
			int icountPT =0; 
			int icountViewMsk =0; 
			int icountB5TB =0; 
			char	*tempErr				=	NULL;
			char	*aplModule1				=	NULL;
			char	*aplModule2				=	NULL;
			char	*viewmask				=	NULL;
			char	*revisionRule				=	NULL;
			char	*partItemId_rev=NULL;
			char	*dmlType=NULL;


			if(QRY_find2("Control Objects...", &qryTagCntrlBiw));
			if (qryTagCntrlBiw)
			{
				printf("\n Control Object Query Found \n");fflush(stdout);
				
				if(tc_strcmp(signOffDept,"APL")==0)
				{
					qry_valuesCntrlBiw[0]="ERC_APL_BOM_Validation";
					qry_valuesCntrlBiw[1]="ModSuppress";
					qry_valuesCntrlBiw[2]="0";
				}
				if(tc_strcmp(signOffDept,"STD")==0)
				{
					qry_valuesCntrlBiw[0]="ERC_APL_BOM_Validation_STD";
					qry_valuesCntrlBiw[1]="APLModPresent";
					qry_valuesCntrlBiw[2]="0";
				}

				if(QRY_execute(qryTagCntrlBiw, n_entryCntrlBiw, qry_entryCntrlBiw, qry_valuesCntrlBiw, &control_number_foundBiw, &list_of_WSO_cntrl_tagsBiw));

				qry_valuesCntrlPT[0]="ERC_APL_BIW_Mapping";
				qry_valuesCntrlPT[1]="SignOffValidation";
				qry_valuesCntrlPT[2]="0";

				if(QRY_execute(qryTagCntrlBiw, n_entryCntrlPT, qry_entryCntrlPT, qry_valuesCntrlPT, &control_number_foundPT, &list_of_WSO_cntrl_tagsPT));
			}
			else
			{
				printf("\n Control Object Query not Found \n");fflush(stdout);
			}	

			printf("\n control_number_found1 is : %d\n",control_number_foundBiw);fflush(stdout);

			if(control_number_foundBiw>0)
			{
			
				ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsBiw[0], "t5_Userinfo1", &dmlType));
				printf("\n dmlType: %s\n",dmlType);fflush(stdout);

				if(control_number_foundPT>0)
				{
				
					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo1", &aplModule1));
					printf("\n aplModule1: %s\n",aplModule1);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo2", &ercBiwModule1));
					printf("\n ercBiwModule1: %s\n",ercBiwModule1);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo3", &ercBiwModule2));
					printf("\n ercBiwModule2: %s\n",ercBiwModule2);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo4", &ercBiwModule3));
					printf("\n ercBiwModule3: %s\n",ercBiwModule3);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo6", &viewmask));
					printf("\n viewmask: %s\n",viewmask);fflush(stdout);

					ITKCALL(AOM_ask_value_string( list_of_WSO_cntrl_tagsPT[0], "t5_Userinfo5", &revisionRule));
					printf("\n revisionRule: %s\n",revisionRule);fflush(stdout);

				
				}

				SetChildRelViewMsk=NULL;
				SetChildRelViewMsk = (char**)MEM_alloc( 1 * sizeof *SetChildRelViewMsk );


				for (k=0;k<PartCnt ;k++ )
				{

					printf("\n\n\t\t inside Check_APLModuleAgtERCMod APL DML Cre:for k_4 =:%d",k);fflush(stdout);
					AssyTag=NULLTAG;
					children=NULLTAG;

					AssyTag=PartTags[k];

					if(AssyTag!=NULLTAG)
					{

						
						partType=NULL;
						ITKCALL(AOM_ask_value_string(AssyTag,"t5_PartType",&partType));
						printf("\n partType:%s ..............",partType);fflush(stdout);

						partItemId=NULL;
						ITKCALL(AOM_ask_value_string(AssyTag,"item_id",&partItemId));
						printf("\n partItemId:%s ..............",partItemId);fflush(stdout);

						partItemId_rev=NULL;
						ITKCALL(AOM_ask_value_string(AssyTag,"item_revision_id",&partItemId_rev));
						printf("\n partItemId_rev:%s ..............",partItemId_rev);fflush(stdout);


						if((tc_strcmp(partType,"V")==0))	
						{
							printf("\n Inside PartType Check");fflush(stdout);
							
							ITKCALL(BOM_create_window (&window));
							printf("\n find occurence..window");fflush(stdout);
							ITKCALL(CFM_find("Color ERC Review and above", &rule));
							printf("\n find occurence..rule");fflush(stdout);
							ITKCALL(BOM_set_window_config_rule( window, rule ));
							printf("\n configure occurence..rule");fflush(stdout);
							ITKCALL(BOM_set_window_top_line(window, null_tag,AssyTag , bvr_tag, &top_line));
							ITKCALL(BOM_line_ask_child_lines (top_line, &nClhd, &children));
							printf("\n nClhd %d,",nClhd);fflush(stdout);

							int childPrtC = 0;
							int qtyErr	= 0;
							int viewMskErr	= 0;
							int ck	= 0;
							int value_qtyInt	= 0;

							if((children) && nClhd>0)
							{
								for (ck = 0; ck < nClhd; ck++)				//Vehicle BOM
								{
									//get the revision from bomline
									ITKCALL(BOM_line_pack (children[ck]));

									t_ChildItemRev=NULLTAG;
                                    t_itemTag=NULLTAG;
                                     sItem_id=NULL;
									 sItem_id_rev=NULL;
									//ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
									//ITKCALL(BOM_line_ask_attribute_tag(children[ck], iChildItemTag, &t_ChildItemRev));
									ITKCALL(AOM_ask_value_string(children[ck], "bl_item_item_id", &sItem_id));
									ITKCALL(AOM_ask_value_string(children[ck], "bl_rev_item_revision_id", &sItem_id_rev));
									printf("\n\n TCUA 14.3 bl_item_item_id is---------------->%s ,%s\n",sItem_id,sItem_id_rev); fflush(stdout);

									ITKCALL(ITEM_find_item(sItem_id,&t_itemTag));
									ITKCALL(ITEM_find_revision(t_itemTag,sItem_id_rev,&t_ChildItemRev));
									
									if(t_ChildItemRev!=NULLTAG)
									{

										Bomline_tag=NULLTAG;
										Bomline_tag = children[ck];
										
										if(Bomline_tag!=NULLTAG)
										{
											value_itemid=NULL;
											value_itemRevID=NULL;
											value_itemRevPartType=NULL;
											value_flag=NULL;
											Item_ID_Check=NULL;
											value_qtyInt=0;
											char *value_qty1=NULL;

											ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&value_itemid))
											printf("\n Arc Node child value_itemid:%s ..............",value_itemid);fflush(stdout);

											ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_revision_id",&value_itemRevID))
											printf("\n value_itemRevID:%s ..............",value_itemRevID);fflush(stdout);

											ITKCALL(AOM_ask_value_string(t_ChildItemRev,"t5_PartType",&value_itemRevPartType))
											printf("\n value_itemRevPartType:%s ..............",value_itemRevPartType);fflush(stdout);

											if(tc_strcmp(value_itemRevPartType,"M")==0 )
											{
												Item_ID_Check=subString(value_itemid,4,5);
												printf("\n  Item_ID_Check:%s ..............",Item_ID_Check);fflush(stdout);
											
											
												if((tc_strstr(ercBiwModule1,Item_ID_Check)!=NULL) || (tc_strstr(ercBiwModule2,Item_ID_Check)!=NULL) || (tc_strstr(ercBiwModule3,Item_ID_Check)!=NULL))
												{

													//ITKCALL(BOM_line_look_up_attribute("bl_occ_t5_CurrentViewMaskC", &attribute_flag));
													//ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, attribute_flag, &value_flag));
													ITKCALL(AOM_UIF_ask_value(Bomline_tag,"bl_occ_t5_CurrentViewMaskC",&value_flag));
													printf("\n  value_flag:%s ..............",value_flag);fflush(stdout);


													if((tc_strstr(value_flag,"0--")==NULL) || (tc_strcmp(value_flag,"")==0))
													{

														ErrString=NULL;
														ErrString	=	(char *)MEM_alloc(tc_strlen(value_itemid)+tc_strlen(partItemId)+500);
														tc_strcpy(ErrString,"");
														tc_strcat(ErrString,value_itemid);
														tc_strcat(ErrString," for Vehicle ");
														tc_strcat(ErrString,partItemId);
														tc_strcat(ErrString,".\n");
														setAddStrInApplySVRonX4(&icountViewMsk,&SetChildRelViewMsk,ErrString);
														//cntFlag	=	1;
													
													}

												}

											}
										}//end of if
									}
								}
							}

						}
					}
				}


			}

			int iLength	=	0;
			int i	=	0;
			if (!tempErr) MEM_free(tempErr);
			for (i=0; i < icountViewMsk; i++)
			{
				tempErr	=	SetChildRelViewMsk[i];
				iLength	=	iLength	+	tc_strlen(tempErr);
			}
			printf("5.iLength : %d",iLength);fflush(stdout);
			if (!tempErr) MEM_free(tempErr);
			tempErr	=	(char *)MEM_alloc(iLength+120);
			for (i=0; i < icountViewMsk; i++)
			{
				if(i==0)
				{
					tc_strcpy(tempErr,"\n Below ERC Modules are not suppressed :\n ");
					tc_strcat(tempErr,SetChildRelViewMsk[i]);
				}
				else
				{
					tc_strcpy(tempErr,SetChildRelViewMsk[i]);
				}
				setAddStrInApplySVRonX4(icount_ebommSupp,SetChildRelAPLModErr,tempErr);
				
			}
			printf("\n5.Printing Errors...!!!");fflush(stdout);
			printf("%s",tempErr);fflush(stdout);

			printf("\n\n Exit from function of APl-ERC BOM.....\n");fflush(stdout);
			return 0;
		}

		extern int ApplySVRonX4_register_method(int *decision, va_list args)
		{
		   int ifail=0;
		   *decision = ALL_CUSTOMIZATIONS;
		   tag_t objTag = va_arg(args, tag_t);	

		   if(ITK_ok ==  EPM_register_rule_handler ("multiple_module_status","Solved NonClr BOM", (EPM_rule_handler_t) multiple_module_status))
		   {
				printf("\t\n Registered rule  multiple_module_status.................\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register rule Handler multiple_module_status\n");fflush(stdout);
		   }

		   if(ITK_ok ==  EPM_register_rule_handler ("duplicate_vf_on_clrmodule","Solved Color BOM", (EPM_rule_handler_t) duplicate_vf_on_clrmodule))
		   {
				printf("\t\n Registered rule  duplicate_vf_on_clrmodule.................\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register rule Handler duplicate_vf_on_clrmodule\n");fflush(stdout);
		   }
		   if(ITK_ok ==  EPM_register_rule_handler ("Chk_clr_schm_dummy","Check Clr shm dummy availble or not", (EPM_rule_handler_t) Chk_clr_schm_dummy))
		   {
				printf("\t\n Registered rule  Chk_clr_schm_dummy.................\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register rule Handler Chk_clr_schm_dummy\n");fflush(stdout);
		   }
		   
		   if( ITK_ok == EPM_register_action_handler("ClrsuffixSelction", "Automation of colour suffix selection", ClrsuffixSelction))// Added by Nilesh Patil on 07/29/2025
		   {
				printf("\t\n Registered Action Handler ClrsuffixSelction\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register Action Handler ClrsuffixSelction\n");fflush(stdout);
		   }
		   if( ITK_ok == EPM_register_rule_handler("tm_workflow_chck_clrschm","Rule handler to Check Single Validation Report",tm_workflow_chck_clrschm))// Added by Nilesh Patil on 6/16/2026
		   {
				printf("\t\n Registered Action Handler tm_workflow_chck_clrschm\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register Action Handler tm_workflow_chck_clrschm\n");fflush(stdout);
		   }
		 
		   if( ITK_ok == EPM_register_action_handler("cl_task_creation", "", cl_task_status))
		   {
				printf("\t\n Registered Action Handler cl_task_creation\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register Action Handler cl_task_creation\n");fflush(stdout);
		   }
			if( ITK_ok == EPM_register_action_handler("cl_task_creation_SVR", "", cl_task_creation_SVR))
		   {
				printf("\t\n Registered Action Handler cl_task_creation_SVR\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register Action Handler cl_task_creation_SVR\n");fflush(stdout);
		   } if( ITK_ok == EPM_register_rule_handler("validateSVRCOl_vf_on_clrmodule","Solved SVRColor BOM", (EPM_rule_handler_t) validateSVRCOl_vf_on_clrmodule))
		   {
				printf("\t\n Registered Action Handler validateSVRCOl_vf_on_clrmodule\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register Action Handler validateSVRCOl_vf_on_clrmodule\n");fflush(stdout);
		   }

		   if( ITK_ok == EPM_register_action_handler("cl_task_deletion", "", cl_task_deletion))
		   {
				printf("\t\n Registered Action Handler cl_task_deletion\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register Action Handler cl_task_deletion\n");fflush(stdout);
		   }

		   if( ITK_ok == EPM_register_rule_handler("validation_CTRLBase_ArchNode","", (EPM_rule_handler_t) validation_CTRLBase_ArchNode))
		   {
				printf("\t\n Registered Action Handler Validation_CTRLBase_ArchNode\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register Rule Handler Validation_CTRLBase_ArchNode\n");fflush(stdout);
		   }

		  if( ITK_ok == EPM_register_rule_handler("CLTaskBOMMistmatchFun","", (EPM_rule_handler_t) CLTaskBOMMistmatchFun))
		   {
				printf("\t\n Registered Action Handler CLTaskBOMMistmatchFun\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register Rule Handler CLTaskBOMMistmatch\n");fflush(stdout);
		   }

		 if( ITK_ok == EPM_register_rule_handler("CLTASKCPBOMDML","", (EPM_rule_handler_t) CLTASKCPBOMDML))
		   {
				printf("\t\n Registered Action Handler CLTASKCPBOMDML\n");fflush(stdout);
		   }else
		   {
				printf("\t FAILED to register Rule Handler CLTASKCPBOMDML\n");fflush(stdout);
		   }


		   return ITK_ok;
		}

		extern DLLAPI int tm_ApplySVRonX4_register_callbacks()
		{     
			 printf("\n Before ApplySVRonX4_register_callbacks--------------->\n");fflush(stdout);
			 
			 CUSTOM_register_exit("tm_ApplySVRonX4", "USER_init_module", (CUSTOM_EXIT_ftn_t) ApplySVRonX4_register_method);

			 printf("\n After ApplySVRonX4_register_callbacks--------------->\n");fflush(stdout);

			 return ( ITK_ok );
		}
		
		
		
		
		#define Debug TRUE

#define ITK_CALL_API(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}	 								\


// #define ITK_CALL(x) {           \
	// int stat;                     \
	// char *err_string;             \
	// if( (stat = (x)) != ITK_ok)   \
	// {                             \
	// EMH_get_error_string (NULLTAG, stat, &err_string);                 \
	// printf ("ERROR: %d ERROR MSG: %s.\n", stat, err_string);           \
	// printf ("FUNCTION: %s\nFILE: %s LINE: %d\n",#x, __FILE__, __LINE__); \
	// if(err_string) MEM_free(err_string);                                \
	// exit (EXIT_FAILURE);                                                   \
	// }                                                                    \
// }

char*   ClosureRule = "BOMViewClosureRuleERC";      // tmvp_ClrNonClrMismatchRpt



int tmvp_ClrNonClrMismatchRpt(tag_t dmlTag, tag_t t_dml_Task)  
{
		int iFail = ITK_ok;
		tag_t tDML            = NULLTAG;
		tag_t tLatestDMLRev   = NULLTAG;
		tag_t tDMLTskReLation = NULLTAG;
		int sec_count = 0;
		tag_t* tDMLTasksec    = NULLTAG;
		
		FILE *fprpt            = NULL;					// tmvp_ClrNonClrMismatchRpt
		
		char* cRev_id          = NULL;
		tag_t tSolItemRelation = NULLTAG;
		tag_t* tColorItems     = NULLTAG;
		//tag_t t_dml_Task = NULLTAG;
		char* c_Tsk_id = NULL;
		
		char* cError   = NULL;
		
		int iSolItem_count     = 0;
		char* cRevID           = NULL;
		char* cClrPartID       = NULL;
		char* cDML_ID          = NULL;
		int s = 0;
		int p = 0;
		char* c_NonColorItem      = NULL;
		char* c_ReleaseStatus     = NULL;
		char* c_dml_rlstype       = NULL;
		char* C_RepresentedRevID1 = NULL;
		char* C_RepresentedRevID  = NULL;
		
		int k =0;
		char * filename = NULL;
		
		tag_t tRepresentedRel = NULLTAG ;
		int iReprItmCount   = 0;
		tag_t* tNonClrItems = NULLTAG;
		tag_t* ttColorItems = NULLTAG;
		tag_t ClrItemRev    = NULLTAG;
		char* cNonClrPartID = NULL;
		char* cDML_Tsk_ID   = NULL;
		char* c_PartTypNCLR = NULL;
		char* c_SeqID_NCLR  = NULL;
		
		char *ClrPrtNo      = NULL;
		char *ClrPrtRevId   = NULL;
		char *ClrPrtStat    = NULL;
		tag_t t_RevRule     = NULLTAG;
		tag_t t_RevRule_CLR = NULLTAG;
		
		char *c_RevRule     = NULL;
		char *c_RevRule_CLR = NULL;
		
		
		char* cClrItemRevID    = NULL;
		char* cClrItemRevID1   = NULL;
		char* cNonClrPartRevID = NULL;
		char *Matchingstatus   = NULL;
		char *cNONClrPrtStat   = NULL;
		tag_t t_RevRuleNclr    = NULLTAG;
		char *c_NonClr_RevRule = NULL;
		
		tag_t 	tCntrlObj		= NULLTAG;
		tag_t	*tQryResult		= NULLTAG;
		int		iEntryCount		= 1;
		int		iResultFound	= 0;
		
		
		//---------------------------Dataset Creation Variable Block----------------------------
		tag_t dml_Ref_Rel		= NULLTAG;
		tag_t msExcelType		= NULLTAG;
		tag_t ExcelDataset		= NULLTAG;
		tag_t dml_Ref_Rel_t		= NULLTAG;
		tag_t ExlLatestDat_t	= NULLTAG;
		
		char* DsetName = NULL;

		DsetName =(char *) MEM_alloc(100);
		filename =(char *) MEM_alloc(200);
		printf("\n\t  --tmvp_ClrNonClrMismatchRpt-- After MEM_Alloc to DsetName and filename ");fflush(stdout);
		//---------------------------Dataset Creation Variable Block END---------------------------
		
		// -------------Import Named ref Variable block------------------
		tag_t filetag =  NULLTAG;
		tag_t tool =  NULLTAG;
		int ref_count =0;
		char** ref_list;
		AE_reference_type_t tagRefType =  1;
		
		IMF_file_t fileDescriptor;
		
		// -------------Import Named ref Variable block------------------
		
						int i;
						int j;
						int jj=0;
						int ss=0;
						char ColourVCparts[50]; 
						char NonColourVCparts[50];
						char ErcQty[50]; 
						char AplQty[50]; 
						char DRsts[50]; 
						int partMatchFound;
						int partMatchFound1;
						int partqtymacth = 0;
		
		int APL;
		int ERC;
		
		Matchingstatus =(char *) MEM_alloc(100);
		
		char *FinalRemark = NULL;
		FinalRemark =(char *) MEM_alloc(100);
		
		char *parttoadd = NULL;
		parttoadd =(char *) MEM_alloc(2000); 
		
		char *parttoremove = NULL;
		parttoremove =(char *) MEM_alloc(2000);
		
		char *ColQty = NULL;
		ColQty =(char *) MEM_alloc(2000);
		
		
		char *Filepath = NULL;
		Filepath =(char *) MEM_alloc(150);
		
		time_t temptime;
		char GenDate[20]; 
		struct tm *timeptr; 
		int ch; 
		printf("\n Generating Curernt Time Stamp");fflush(stdout); 
		temptime = time(NULL); 
		tc_strcpy(GenDate,"");
		timeptr = (struct tm *)localtime(&temptime); 
		ch = strftime(GenDate,sizeof(GenDate)-1,"%d_%b_%Y_%H_%M",timeptr);
		printf("\n Current Time --------> %s", GenDate);fflush(stdout);
		
		// checking DML ID
		
		iFail = AOM_ask_value_string(dmlTag,"item_id",&cDML_ID);
		iFail = AOM_ask_value_string(t_dml_Task,"item_id",&cDML_Tsk_ID);
		
		printf("\n\t ===================Inside tmvp_ClrNonClrMismatchRpt =================== ");fflush(stdout);
		printf("\n\t --tmvp_ClrNonClrMismatchRpt-- DML ID ==  [ %s ] ", cDML_ID);fflush(stdout);
		printf("\n\t --tmvp_ClrNonClrMismatchRpt-- cDML_Tsk_ID == [ %s ] ", cDML_Tsk_ID);fflush(stdout);
		
		//----------- setting file name ----
	
		tc_strcpy(filename,cDML_ID);
		tc_strcat(filename,"_COLOUR_VS_BASE_VC_BOM_COMPARE_");
		tc_strcat(filename, GenDate);
		tc_strcat(filename, ".csv");
	
		
		
		char    *cQryEntry[1]		    = {"SYSCD"};
		char    **cEntryValue			= (char **) MEM_alloc(100 * sizeof(char *));
		char 	*c_userInfo1 			= NULL;
		
		ITK_CALL(QRY_find2("ControlObjQry", &tCntrlObj));
	    cEntryValue[0] = "Colour_Env";
	    ITK_CALL(QRY_execute(tCntrlObj, iEntryCount, cQryEntry, cEntryValue, &iResultFound, &tQryResult));
	    printf("\n ========== Checking control Object ==> Colour_Env ");fflush(stdout);
	  

	if (iResultFound > 0)   // If control object count of "Colour_Env" found more than one
	{
			printf("\n\t +++ CONTROL OBJECT ====> Colour_Env ============FOUND ");fflush(stdout);
			
			ITK_CALL(AOM_UIF_ask_value(tQryResult[0],"t5_Userinfo1",&c_userInfo1));
			printf("\n\t ####CONTROL OBJECT = Colour_Env \t and Information 1 = %s",c_userInfo1);fflush(stdout);
			
			if(tc_strcmp(c_userInfo1,"CMITEST")==0)
			{
				tc_strcpy(Filepath,"/tmp/");
			}
			else
			{
				tc_strcpy(Filepath,"/plmpv16/reports/CL_DMLTASK_LOG/");
			}
			printf ("\n\tFILE PATH AFTER t5checkEnvironment is ==>  %s ",Filepath);fflush(stdout);
		
			
			tc_strcat(Filepath,filename);
			
			
	
		printf("\n\n\t File Path ==> %s ",Filepath);fflush(stdout);
		
	
		
		fprpt	 =	fopen(Filepath,"w");
		
		if (fprpt == NULL)
		{
			printf("\n\t tmvp_ClrNonClrMismatchRpt WARNING VP --->  %s ----xxxxxxx--- (fprpt == NULL) -----xxxx------",filename);fflush(stdout);
			return ITK_ok;
		}
		else
		{
			printf("\n\t tmvp_ClrNonClrMismatchRpt -----> FILE NAME - %s",filename);fflush(stdout);
		
				// Setting Report details
				
				fprintf(fprpt,"===========,=============,============");fflush(fprpt);
				fprintf(fprpt,"\nREPORT NAME,===,BOM COMPARE BETWEEN COLOUR VC & NON COLOUR VC");fflush(fprpt);
				fprintf(fprpt,"\nDML ID,===,%s",cDML_ID);fflush(fprpt);
				fprintf(fprpt,"\nREPORT FIRE DATE,===,%s",GenDate);fflush(fprpt); 
				
				//Setting report headers
				fprintf(fprpt,"\n===========,=============,=============,=========================,=======================,==============\n");fflush(fprpt);
				fprintf(fprpt,"\nCOLOUR VC,BASE VC,PART TYPE-BASE,PART TO BE ADDED IN COLOUR VC,PART TO BE REMOVE FROM COLOUR VC,QTY MISMATCH DETAILS");fflush(fprpt);
				fprintf(fprpt,"\n===========,=============,=============,=========================,=======================,==============\n");fflush(fprpt);
		
			
				iFail  = GRM_find_relation_type("CMHasSolutionItem", &tSolItemRelation);
				iFail  = GRM_list_secondary_objects_only(t_dml_Task, tSolItemRelation, &iSolItem_count, &tColorItems);	// find all solution items(colour parts) of the tasks
				printf("\n\t tmvp_ClrNonClrMismatchRpt---> --------------Checking Solution Items (Colour Parts)----------------------------");fflush(fprpt); 
				
				// Colour Part COunt 
				printf ("\n\t tmvp_ClrNonClrMismatchRpt---> SOLUTION ITEMS count ==> %d ", iSolItem_count);fflush(stdout);   //colour
				
				// Traverse thru' all solution items
				
				for ( p = 0 ; p < iSolItem_count ; p++)
				{
					
					ClrItemRev = tColorItems[p];
					ITK_CALL(AOM_ask_value_string (tColorItems[p], "object_string", &cClrPartID));
					
					
					printf("\n\t tmvp_ClrNonClrMismatchRpt---> Colour part is %s",cClrPartID);fflush(stdout);
					
					
					ITK_CALL(AOM_ask_value_string (ClrItemRev, "object_string", &cClrPartID));
					ITK_CALL(AOM_ask_value_string(ClrItemRev,"item_id",&ClrPrtNo));    
					
	
					ITK_CALL(AOM_ask_value_string(ClrItemRev,"item_revision_id",&ClrPrtRevId)); 
				
					ITK_CALL(AOM_UIF_ask_value(ClrItemRev,"release_status_list",&ClrPrtStat));
					
					printf("\n\t tmvp_ClrNonClrMismatchRpt---> RELEASE STATUS of %s;%s   is =========> [ %s ]",ClrPrtNo,ClrPrtRevId,ClrPrtStat );fflush(stdout);
					
					if((tc_strstr(ClrPrtStat,"ERC Released")!=NULL) ||  (tc_strstr(ClrPrtStat,"T5_LcsErcRlzd")!=NULL))
					{
						//printf("\n\t\t ==== SOL ITEM --REV RULE = ERC release and above ---");fflush(stdout);
						ITK_CALL(CFM_find( "ERC release and above", &t_RevRule ));
								
					}
					else
					{
							//printf("\n\t\t ==== SOL ITEM --REV RULE = ERC Review And Above ---");fflush(stdout);
							ITK_CALL(CFM_find( "ERC Review And Above", &t_RevRule ));
					}
					
					ITK_CALL(AOM_ask_value_string(t_RevRule,"object_name",&c_RevRule_CLR)); 
					printf ("\n\t\t tmvp_ClrNonClrMismatchRpt---> REVISION RULE for solution item  ====>  %s ",c_RevRule_CLR );fflush(stdout);
					
					//colour Vc expansion starting 
					t5GetExpChildERC(tColorItems[p], t_RevRule);
					printf("\n\t\t -----------------------COLOUR VC EXPANSION END----------------------------\n");fflush(stdout);
					
					
					ITK_CALL(GRM_find_relation_type("TC_Is_Represented_By", &tRepresentedRel));
					ITK_CALL(GRM_list_secondary_objects_only(tColorItems[p], tRepresentedRel, &iReprItmCount, &tNonClrItems)); // find all Non-Colour parts (Represented by) of resp colour parts
					
					printf("\n\t tmvp_ClrNonClrMismatchRpt---> --------------Checking Represented by Items (Non-Colour Parts)----------------------------");fflush(stdout);
					
					// Non-Colour part Count
					
					printf ("\n\t tmvp_ClrNonClrMismatchRpt---> REPRESENTED BY Part's count ==> %d ", iReprItmCount);fflush(stdout);
					
					if (iReprItmCount > 0)
					{
						ITK_CALL(AOM_UIF_ask_value (tColorItems[p], "TC_Is_Represented_By", &cNonClrPartRevID));
						c_NonColorItem = tc_strtok(cNonClrPartRevID,";");				
						
						printf ("\n\t tmvp_ClrNonClrMismatchRpt---> ----TC_Is_Represented_By item_id of %s =  [ %s ] ", cClrPartID,c_NonColorItem);fflush(stdout);  //NON_colour
						
						ITK_CALL(AOM_UIF_ask_value(tNonClrItems[0],"release_status_list",&cNONClrPrtStat));
						
						ITK_CALL(AOM_UIF_ask_value(tNonClrItems[0],"t5_PartType",&c_PartTypNCLR));
						printf ("\n\t tmvp_ClrNonClrMismatchRpt---> PART TYPE OF TC_Is_Represented_By(NON-COLOUR) item_id  %s is --> %s",c_NonColorItem,c_PartTypNCLR );fflush(stdout);
						
						ITK_CALL(AOM_UIF_ask_value(tNonClrItems[0],"sequence_id",&c_SeqID_NCLR));
					
						C_RepresentedRevID1 = tc_strcat(c_NonColorItem,";");
						C_RepresentedRevID = tc_strcat(C_RepresentedRevID1,c_SeqID_NCLR);
					
						if ( (tc_strstr(cNONClrPrtStat,"ERC Released")!=NULL) ||  (tc_strstr(cNONClrPrtStat,"T5_LcsErcRlzd")!=NULL) )
						{
							//printf("\n\n\t\t ==== SOL ITEM --REV RULE = ERC release and above ---");fflush(stdout);
							ITK_CALL(CFM_find( "ERC release and above", &t_RevRuleNclr ));
							
						}
						else
						{
							//printf("\n\n\t\t ==== SOL ITEM --REV RULE = ERC Review And Above ---vp9999");
							ITK_CALL(CFM_find( "ERC Review And Above", &t_RevRuleNclr ));
						}
						
						ITK_CALL(AOM_ask_value_string(t_RevRuleNclr,"object_name",&c_NonClr_RevRule));
						printf ("\n\t\t tmvp_ClrNonClrMismatchRpt--->  REVISION RULE for represented by item  ---->  %s ",c_NonClr_RevRule );fflush(stdout);
								
						
						//NON_colour Vc expansion starting 
						
						t5GetExpChildAPLSingle(tNonClrItems[0], t_RevRuleNclr);
						
						printf("\n\t\t ------------------------NON VC EXPANSION END-----------------------");fflush(stdout);
					
					}
					else
					{
						printf("\n\t --XX-- RELATION (Represented by) NOT FOUND of %s;%s--xx--",cClrPartID,cClrItemRevID);
						fprintf(fprpt,"\n %s,Represented by relation is not present",cClrPartID);
						continue;
					}
							
						
						
						printf("\n\nTotal elegible COLOUR VC CHILD  Part count is [%d]",ERC_Index);fflush(stdout);
						
						printf("\nTotal elegible NON COLOUR VC  Parts detail count is [%d]",APLMulti_Index);fflush(stdout);
						
						
						strcpy(parttoadd,"");
						strcpy(parttoremove,"");
						strcpy(ColQty,"");
						
								
							for(i = 0; i < ERC_Index; i++)  //colour bom
							{
								partMatchFound=0;
								partqtymacth =0;
								printf("\n 96633");
								for(j = 0; j < APLMulti_Index; j++) //Non-colour bom
								{
									//printf("\n 966699633");
									
									strcpy(ColourVCparts,"");
									strcpy(NonColourVCparts,"");
									strcpy(ErcQty,"");
									strcpy(AplQty,"");
									//strcpy(DRsts,"");
									//strcpy(CSup,"");
									//strcpy(Parttyp,"");
									//printf("\n 96999999966699633");
									strcpy(ColourVCparts,PartDetailsArray[i]->partName);
									strcpy(NonColourVCparts,PartDetailsArrayAPLMul[j]->partName);
									strcpy(DRsts,PartDetailsArray[i]->DRstatus);
									//printf("\n 96999treyteyty99633");
									strcpy(ErcQty,PartDetailsArray[i]->Qty);
									strcpy(AplQty,PartDetailsArrayAPLMul[j]->Qty);
								
									printf("\nCOLOUR VC PART Number %s || NON COLOUR VC Part Number %s || COLOUR VC PART Qty %s || NON COLOUR VC PART QTY %s",ColourVCparts,NonColourVCparts,ErcQty,AplQty);fflush(stdout);
									
									
									
						
								if (tc_strstr(ColourVCparts,NonColourVCparts)!=NULL)/// and CLR indicator=N					
									{
										//printf("\n 966339996");
										partMatchFound =1;
										printf("\n\t\t ===========::Module Match found::===========\n");fflush(stdout);
										
										if (tc_strcmp(ErcQty,AplQty)!=0) 
										{
											//printf("\n 96634894rt3");
											partqtymacth =1;
											printf("\n\t\t ========::MODULE MATCH::========= BUT QUANTITY NOT MATCHED for both part");fflush(stdout);
											//break;
											
										}
										printf("\n\t ~~~~A--qtyMatchFlag=[%d]  partMatchFound:[%d]~~~~~~~~~~",partqtymacth,partMatchFound);fflush(stdout);
										break;								
									}
								} //for loop end non-colour bom
									
									
								printf("\n\t\t tmvp_ClrNonClrMismatchRpt---> non-colour bom part no [%s] partMatchFound is [%d]",ColourVCparts,partMatchFound);fflush(stdout);
								if (partqtymacth == 1)
								{
									strcat(ColQty,PartDetailsArray[i]->partName);
									strcat(ColQty,"|");
						
								}
								
								if (partMatchFound == 0)
								{
									printf("\n\t\t tmvp_ClrNonClrMismatchRpt---> parttoremove:[%s] --> PART TO BE REMOVED:[%s]\n",parttoremove,PartDetailsArray[i]->partName);fflush(stdout);
									strcat(parttoremove,PartDetailsArray[i]->partName);
									strcat(parttoremove,"|");
									
								}			
							}
						
						
							
							for(APL = 0; APL < APLMulti_Index; APL++)   //  APLMulti_Index ERC_Index_Multi ERC  PartDetailsArrayAPLMul PartDetailsArrayAPLMul
							{
								partqtymacth =0;
								partMatchFound1 =0;
													
								for(ERC = 0; ERC < ERC_Index; ERC++)							
								{
									//partMatchFound1 =0;
									strcpy(ColourVCparts,"");
									strcpy(NonColourVCparts,"");
									strcpy(ErcQty,"");
									strcpy(AplQty,"");
									strcpy(DRsts,"");
								
									strcpy(NonColourVCparts,PartDetailsArrayAPLMul[APL]->partName);
									strcpy(ColourVCparts,PartDetailsArray[ERC]->partName);
							
						
									strcpy(ErcQty,PartDetailsArray[ERC]->Qty);
									strcpy(AplQty,PartDetailsArrayAPLMul[APL]->Qty);
						
									printf("\n NON-COLOUR PART NUMBER %s ||COLOUR_VC_PARTS PART NUMBER %s || APL QTY %s || ERC Qty %s",NonColourVCparts,ColourVCparts,AplQty,ErcQty);fflush(stdout);
									//if (tc_strstr(ColourVCparts,NonColourVCparts)!=NULL)
									//if (tc_strstr(NonColourVCparts,ColourVCparts)!=NULL)	
									if (tc_strstr(ColourVCparts,NonColourVCparts)!=NULL)
									{
										partMatchFound1 =1;
										printf("\n\t\t ====111=======::Module Match found::=====111======\n");fflush(stdout);
							
										if (tc_strcmp(AplQty,ErcQty)!=0)
										{
											partqtymacth =1;
											printf("\n\t\t ====111====::MODULE MATCH::====111===== BUT QUANTITY NOT MATCHED for both part");fflush(stdout);
										//break;
											
										}
										printf("\n\t ~~~~B--qtyMatchFlag=[%d]  partMatchFound1:[%d]~~~~~~~~~~",partqtymacth,partMatchFound1);fflush(stdout);
										
										break;
									}
									
								}
								printf("\n tmvp_ClrNonClrMismatchRpt---> MP part no [%s] partMatchFound1 is [%d]",NonColourVCparts,partMatchFound1);fflush(stdout);
								if (partMatchFound1 == 0)
								{
									printf("\n\t\t tmvp_ClrNonClrMismatchRpt---> [%s] TO BE ADDED in BOM ---> No_Match found:[%s]\n",parttoadd,PartDetailsArrayAPLMul[APL]->partName);fflush(stdout);
									strcat(parttoadd,PartDetailsArrayAPLMul[APL]->partName);
									strcat(parttoadd,"|");
									
								}
						
							}
						
							
						// print report into file
						
						fprintf(fprpt,"\n%s,%s,%s,%s,%s",cClrPartID,C_RepresentedRevID,c_PartTypNCLR,parttoadd,parttoremove,ColQty);fflush(fprpt);
						
						
						
						FreeArrayOfStructureAPLMul();
						FreeArrayOfStructureAPLMul2();
	
				} // For LOOP ENDS OF Solution Items
			
	
			// ----Required mismatch data is already printed into csv now closing the file below
			
			fclose(fprpt);   
	
			// ---File is closed
			printf("\n\n\t ++++++++++++++++FILE [%s] CLOSED++++++++++++++ ",filename);

			//-------------------------starting to create dataset & import csv named ref
			
				strcpy(DsetName,c_Tsk_id);
				strcat(DsetName,"_CLR_Vs_NClr_BOM_Compare_Rpt");
				
				printf("\n\t\t tmvp_ClrNonClrMismatchRpt---> Creating Dataset with Name ===> %s ",DsetName );fflush(stdout);
				
				ITK_CALL(AE_find_datasettype2("MSExcel",&msExcelType));
				if(msExcelType == NULLTAG)
				{
					printf("\n --xx--tmvp_ClrNonClrMismatchRpt---xx-- FAILED TO FIND -> msExcelType at AE_find_datasettype2 \n\n");fflush(stdout);
				}
				else 
				printf("\n\t tmvp_ClrNonClrMismatchRpt---> --MSExcel Type Dataset found--");fflush(stdout);
				
				
				ITK_CALL(AE_create_dataset_with_id(msExcelType,DsetName,"BOM Compare Report BeTween colour VC & Base VC","","",&ExcelDataset));
				
				
				ITK_CALL(AE_save_myself(ExcelDataset));
				printf("\n\t tmvp_ClrNonClrMismatchRpt---> ---Dataset is Succesfully Created & saved in Database ");fflush(stdout);
				
				// ---------------------Create Relation with CL_task-------------------------------//
				
				printf("\n\t tmvp_ClrNonClrMismatchRpt---> ------Going to create relation Task and Excel file in References------\n");fflush(stdout);
				
				ITK_CALL(GRM_find_relation_type("IMAN_reference", &dml_Ref_Rel));
				printf("\n\t tmvp_ClrNonClrMismatchRpt---> --Found Reference rel tag--");fflush(stdout);fflush(stdout);
				
				ITK_CALL(GRM_create_relation(t_dml_Task,ExcelDataset,dml_Ref_Rel,NULLTAG,&dml_Ref_Rel_t));
				
				ITK_CALL(AOM_load(dml_Ref_Rel_t));
				printf("\n\t tmvp_ClrNonClrMismatchRpt---> dml_Ref_Rel_t loaded---");fflush(stdout);
				ITK_CALL(GRM_save_relation(dml_Ref_Rel_t));
				printf("\n\t tmvp_ClrNonClrMismatchRpt---> ---Relation created and saved successfully-- \n");fflush(stdout);
				
				// ---------------------Import Named ref-------------------------------//
				
				printf("\n\n\t tmvp_ClrNonClrMismatchRpt ---> -----------------------IMPORT OF Named reference started-------------------\n");fflush(stdout);
				printf("\n\n\t tmvp_ClrNonClrMismatchRpt ---> 2. Filepath --->>  %s \n\n", Filepath);fflush(stdout);
				
				ITK_CALL(IMF_import_file(Filepath,NULL, SS_BINARY, &filetag, &fileDescriptor));
				
				ITK_CALL(AOM_save_without_extensions(filetag)!=ITK_ok);
								
				ITK_CALL(AE_ask_datasettype_refs(msExcelType, &ref_count, &ref_list));
				ITK_CALL(AE_add_dataset_named_ref2(ExcelDataset,ref_list[0],tagRefType,filetag));
				ITK_CALL(AE_set_dataset_tool(ExcelDataset,tool));
				ITK_CALL(AOM_save_without_extensions(ExcelDataset));
				
				printf("\n\t tmvp_ClrNonClrMismatchRpt---> ---$$$$$$$$---Imported csv file into Excel Dataset----$$$$$$$$$----", filename);fflush(stdout);
				
			
				printf ("\n --xxxxxxxxxxxxxxx----END OF tmvp_ClrNonClrMismatchRpt---xxxxxxxx----------xxxxxxxxxxxxx----END OF tmvp_ClrNonClrMismatchRpt---xxxxxxxx-----");fflush(stdout);
		
		} // (fptr != NULL)
	
	}
	else
	{
		printf("\n\n\t tmvp_ClrNonClrMismatchRpt --> --xx--Control Object NO FOUND --xx-- Colour_Env \n");fflush(stdout);		
	}
	
		
		return ITK_ok;
}

int t5GetExpChildAPLSingle(tag_t itemRev, tag_t tNonClr_Rule)
{
	printf ("\n INSIDE t5GetExpChildAPLSingle non cOLOUR vc level ****\n");fflush(stdout);
    int ifail = ITK_ok;
    char *description=NULL;
    char *description1=NULL;

    tag_t window=NULLTAG;
    int rulefound = 0;
    int childIterator = 0;
    tag_t rule=NULLTAG;
    tag_t *tClosurerule = NULLTAG;
    tag_t close_tag = NULLTAG;
    tag_t dItem=NULLTAG;
    tag_t top_line=NULLTAG;
    int   count = 0;
    tag_t *child=NULLTAG;

	char *PartRev=NULL;
	char *PartSeq=NULL;

    char *level=NULL;
    
    tag_t *subChild=NULLTAG;
    int level2 = 99;
	char *Revision_ID=NULL;
	char *DRstatus=NULL;
    char *Qty=NULL;
    char *part_no=NULL;
	char* cTopline_itemId = 0;
	char* c_NonColourRule = NULL;


	AOM_ask_value_string(itemRev,"item_id",&cTopline_itemId);
	
	printf ("\n\t t5GetExpChildAPLSingle--> ITEM ID OF ItemRev = %s", cTopline_itemId);fflush(stdout);

	printf("\n t5GetExpChildAPLSingle--> CLOSURE RULE = %s",ClosureRule);fflush(stdout);
	
	ITK_CALL(BOM_create_window(&window));
	ITK_CALL(PIE_find_closure_rules2(ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	
	ITK_CALL(AOM_ask_value_string(tNonClr_Rule,"object_name",&c_NonColourRule));
	
	
	printf ("\n t5GetExpChildAPLSingle--> CLOSURE rule COUNT = %d ",rulefound);fflush(stdout);
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("\n t5GetExpChildAPLSingle--> CLOSURE RULE FOUND \n");fflush(stdout);
	}
	else
	{
		printf ("\n t5GetExpChildAPLSingle--> WARNING---xx-- closure rule not found --xx---WARNING \n");fflush(stdout);
		exit;
	}
	if (tNonClr_Rule != NULLTAG)
	{
		ITK_CALL(AOM_ask_value_string(tNonClr_Rule,"object_name",&c_NonColourRule));	
		printf ("\n\t t5GetExpChildAPLSingle--> REVISION RULE FOR SOLUTION ITEM  - [ %s ] " ,c_NonColourRule );fflush(stdout);   
		
		ITK_CALL(BOM_set_window_config_rule(window,tNonClr_Rule));
	}
	else
	{
		printf("\n t5GetExpChildAPLSingle--> WARNING --xx--REVISION RULE NOT FOUND for Reperesented Item,hence exit---xx-- WARNING --xx-\n");fflush(stdout);
		exit;
	}
	
	
	ITK_CALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITK_CALL(BOM_set_window_pack_all (window, true));
    ITK_CALL(BOM_set_window_top_line(window,dItem,itemRev,NULLTAG,&top_line));
	ITK_CALL(BOM_window_show_suppressed ( window ));
    ITK_CALL(BOM_line_ask_all_child_lines(top_line,&count,&child));
	printf("\n t5GetExpChildAPLSingle ------------------------ NON COLOUR VC LEVEL EXPANSION child count = %d -------------------",count);fflush(stdout);
	
	int i = 0;
    for( i = 0;i<count;i++)
    {
		char *childItemName = NULL;
        char* partName = NULL;
        int counter = 0;
		char *PartRev=NULL;  
		char *PartSeq=NULL;   
		char *c_PartTyp=NULL;   
		char *c_ClrIndtr=NULL;   
		
		
        ITK_CALL(AOM_UIF_ask_value(child[i],"bl_level_starting_0",&level));
        int level1 = atoi(level);
        printf("\n t5GetExpChildAPLSingle--> Level of Expension  = %d\n",level1);fflush(stdout);
        
        //******** STOP EXPLOSION IF PART HAVING PART TYPE AS DUMMY **************//
        char* PartType = NULL;
        PartType = (char *) MEM_alloc(32);
        ITK_CALL(AOM_UIF_ask_value(child[i],"bl_Design Revision_t5_PartType",&PartType));
		
		ITK_CALL(AOM_ask_value_string(child[i],"bl_item_item_id",&partName));
		printf("\n t5GetExpChildAPLSingle-->  Child Part No = %s",partName);fflush(stdout);
        
		ITK_CALL(AOM_ask_value_string(child[i],"bl_rev_item_revision_id",&Revision_ID));
		printf("\n t5GetExpChildAPLSingle-->  Child Part Revision ID = %s",Revision_ID);fflush(stdout);
		printf("\n t5GetExpChildAPLSingle-->  Child Part Part Type = %s",PartType);fflush(stdout);
		
		
		if(strlen(PartType)>0)
		{
			
			
				SetOfParts[PartIndex] = child[i];
				PartIndex = PartIndex + 1;
				
				
				printf("\n\n t5GetExpChildAPLSingle-->****************APL side Single Level startd **************** ");fflush(stdout);
				char* suppCs = NULL;
				suppCs = (char *) MEM_alloc(64);
				tc_strcpy(suppCs,"-");
				
				
				ITK_CALL(AOM_ask_value_string(child[i],"bl_quantity",&Qty)); 
				printf("\n t5GetExpChildAPLSingle--> Child Part quantity = %s\n",Qty);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(child[i],"bl_rev_object_desc",&description1));
				//printf("\n Child Part Description = %s",description1);
				

				ITK_CALL(AOM_ask_value_string(child[i],"bl_Design Revision_t5_PartStatus",&DRstatus)); 
				//printf("\n Child Part DRStatus = %s",DRstatus);fflush(stdout);
				
				
				STRNG_replace_str(description1,","," ",&description);
				//printf("\n Description: %s", description);fflush(stdout);
				
				// VP 27.03.24 GROUP PART LOGIC
		
				ITK_CALL(AOM_ask_value_string(child[i],"bl_T5_ClrPartRevision_t5_PartType",&c_PartTyp));    
				
		
				printf("\n t5GetExpChildAPLSingle--> 777 Non-Colour - Child Part Type = %s",c_PartTyp);fflush(stdout);
		
				ITK_CALL(AOM_ask_value_string(child[i],"bl_T5_ClrPartRevision_t5_ColourInd",&c_ClrIndtr)); 
				printf("\n t5GetExpChildAPLSingle--> 777 Non-Colour - Colour Indicator = %s",c_ClrIndtr);fflush(stdout);
		
			
				
				if (tc_strcmp(c_PartTyp,"G")==0) 
				{
					printf("\n t5GetExpChildAPLSingle--> ~~~~~Skipping Manindra Non-Colour Group Part = %s ~~~~~",childItemName);fflush(stdout);
					continue;
				}
//------------------------------------------------
				
				PartRev  = strtok(Revision_ID,";");
				PartSeq = strtok(NULL,";");
	
				PartDetails_APLMultiexpan* APLPartMulti = (PartDetails_APLMultiexpan*)malloc(sizeof(PartDetails_APLMultiexpan));
		
				strcpy(APLPartMulti->partName, partName);
				strcpy(APLPartMulti->Revision_ID, PartRev); 
				strcpy(APLPartMulti->Seq_ID, PartSeq);
		
				strcpy(APLPartMulti->description, description);
				strcpy(APLPartMulti->DRstatus, DRstatus);
		
				strcpy(APLPartMulti->Qty, Qty);
			
				PushIntoArrayOfStructureAPLMul(APLPartMulti);
			
				
		}
		else
		{
			printf("\n t5GetExpChildAPLSingle--> Length of the part type is less then zero,so skip");fflush(stdout);
		}
        
        printf("\n t5GetExpChildAPLSingle--> =======****APL side Single Level ENDED ****========");fflush(stdout);
        
        
    }
	printf ("\n\n t5GetExpChildAPLSingle--> OUTSIDE t5GetExpChildPALMulti\n");fflush(stdout);
	
    
    return ifail;
}


int t5GetExpChildERC(tag_t itemRev, tag_t tColourRule)
{
	printf ("\n\n t5GetExpChildERC ==> INSIDE t5GetExpChildERC for Colour VC expansion \n");fflush(stdout);
    int ifail = ITK_ok;
    char *description=NULL;
    char *description1=NULL;
    char *Revision_ID=NULL;
    char *Qty=NULL;
    char *part_no=NULL;
    tag_t window=NULLTAG;
    int rulefound = 0;
    int childIterator = 0;
    tag_t rule=NULLTAG;
    tag_t *tClosurerule = NULLTAG;
    tag_t close_tag = NULLTAG;
    tag_t dItem=NULLTAG;
    tag_t top_line=NULLTAG;
    int   count = 0;
    tag_t *child=NULLTAG;
	char *DRstatus=NULL;
	char *PartRev=NULL;
	char *PartSeq=NULL;
	char* c_ColourRule = NULL;
	char* c_ParentID = NULL;
	char* c_PartTyp = NULL;
	char* c_ClrIndtr = NULL;

		 
	ITK_CALL(BOM_create_window(&window));
	//ITK_CALL(CFM_find(RevisionRuleERC,&rule));
	ITK_CALL(PIE_find_closure_rules2(ClosureRule,PIE_TEAMCENTER, &rulefound, &tClosurerule ));
	printf ("t5GetExpChildERC ==> CLOSURE RULE count = %d \n",rulefound);fflush(stdout);
	
	if (rulefound > 0)
	{
		close_tag = tClosurerule[0];
		printf ("\n\t t5GetExpChildERC ==> CLOSURE RULE FOUND \n");fflush(stdout);
	}
	else
	{
		printf ("\n t5GetExpChildERC ==> WARNING---xx-- closure rule not found --xx---WARNING \n");fflush(stdout);
		exit;
	}
	if (tColourRule != NULLTAG)
	{
		ITK_CALL(AOM_ask_value_string(tColourRule,"object_name",&c_ColourRule));	
		printf ("\n\t Inside t5GetExpChildERC =>> REVISION RULE FOR SOLUTION ITEM  - [ %s ] vp000000 " ,c_ColourRule );fflush(stdout);   //VP123123
		
		ITK_CALL(BOM_set_window_config_rule(window,tColourRule));
	}
	else
	{
		printf("\n t5GetExpChildERC =>>  WARNING --xx--REVISION RULE FOR for Reperesented Item, Hence EXIT --xx-- WARNING --xx-");fflush(stdout);
		exit;
	}
	
	
	ITK_CALL(BOM_window_set_closure_rule(window,close_tag,0,NULL,NULL));
	ITK_CALL(BOM_set_window_pack_all (window, true));
    ITK_CALL(BOM_set_window_top_line(window,dItem,itemRev,NULLTAG,&top_line));
	ITK_CALL(BOM_window_show_suppressed (window));
    ITK_CALL(BOM_line_ask_all_child_lines(top_line,&count,&child));
	
	
	printf("\n t5GetExpChildERC =>> ------------------------ NON COLOUR VC LEVEL EXPANSION child count = %d -------------------",count);fflush(stdout);
	
	for(childIterator = 0 ; childIterator <count;childIterator++)
	{
		printf("\n t5GetExpChildERC =>> CHILD NO. %d",childIterator);fflush(stdout);
		char *childItemName = NULL;
		char *bl_item_id2 = NULL;
		char* seqNo = NULL;
		
		
		printf("\n t5GetExpChildERC =>> ===================COLOUR VC EXPANSION==============================");fflush(stdout);
		ITK_CALL(AOM_ask_value_string(itemRev,"item_id",&c_ParentID));
	    printf("\n t5GetExpChildERC =>> Parent ITEM ID = =%s",c_ParentID);fflush(stdout);
		
		ITK_CALL(AOM_ask_value_string(child[childIterator],"bl_item_item_id",&childItemName));
        printf("\n t5GetExpChildERC =>> Child Part = %s",childItemName);fflush(stdout);
		
		ITK_CALL(AOM_ask_value_string(child[childIterator],"bl_quantity",&Qty));
        printf("\n t5GetExpChildERC =>> Child Part quantity = %s",Qty);fflush(stdout);
		
		ITK_CALL(AOM_ask_value_string(child[childIterator],"bl_rev_object_desc",&description1));
        //printf("\n Child Part Description = %s\n",description1);fflush(stdout);
		
		ITK_CALL(AOM_ask_value_string(child[childIterator],"bl_rev_item_revision_id",&Revision_ID));
        printf("\n t5GetExpChildERC =>> Child Part Revision ID = %s",Revision_ID);fflush(stdout);
		
		ITK_CALL(AOM_ask_value_string(child[childIterator],"bl_Design Revision_t5_PartStatus",&DRstatus)); 
		//printf("\n Child Part DRStatus = %s",DRstatus);fflush(stdout);
		
		// VP Skip Group part in COlour expansion 04.04.24
		
		ITK_CALL(AOM_ask_value_string(child[childIterator],"bl_T5_ClrPartRevision_t5_PartType",&c_PartTyp)); 
		
		printf("\n t5GetExpChildERC =>> Child Part Type = %s",c_PartTyp);fflush(stdout);
		
		ITK_CALL(AOM_ask_value_string(child[childIterator],"bl_T5_ClrPartRevision_t5_ColourInd",&c_ClrIndtr)); 
		//printf("\n 777 Colour Indicator = %s",c_ClrIndtr);fflush(stdout);
		
		if (tc_strcmp(c_PartTyp,"G")==0) 
		{
			printf("\n t5GetExpChildERC =>> ~~~~~Skipping Colour Group Part = %s ~~~~~",childItemName);fflush(stdout);
			continue;
		}  					 // VP Skip Group part in COlour expansion 04.04.24 END
		
		
		STRNG_replace_str(description1,","," ",&description);
		
		//printf("\n child Part Description: %s\n", description);fflush(stdout);
		
		PartRev  = strtok(Revision_ID,";");
		PartSeq = strtok(NULL,";");
		
		printf("\n\n\t   1111111111111111111111111111111111111111");fflush(stdout);
		
		PartDetails_ERC* ERCPart = (PartDetails_ERC*)malloc(sizeof(PartDetails_ERC));
		strcpy(ERCPart->partName, childItemName);
		strcpy(ERCPart->Revision_ID, PartRev);
		strcpy(ERCPart->Seq_ID, PartSeq);
		strcpy(ERCPart->description, description);
		strcpy(ERCPart->DRstatus, DRstatus);
		strcpy(ERCPart->Qty, Qty);
		PushIntoArrayOfStructure(ERCPart);
		
	
	}
	printf("\n\n t5GetExpChildERC =>> =======****ERC SIDE SINGLE LEVEL ENDED ****========");fflush(stdout);
	
	printf ("\n OUTSIDE t5GetExpChildERC\n");fflush(stdout);
	
    
    return ifail;
}


