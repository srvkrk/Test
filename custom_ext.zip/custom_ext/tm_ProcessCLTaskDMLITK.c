/****************************************************************************************************************************
*  Author               :   Rupali Rane
*  Module               :   Workflow Action Handler. Check and create CL task and attach colour parts to DML.
*  Code                 :   tm_ProcessCLTaskDMLITK.c
*
*  Command				:	tm_ProcessCLTaskDMLITK.c -u=loader -pf=pwdfilepath  -g=dba -DML=DML_no
*						:	
*  Created on			:   23/03/2021
*  Modification History :
*  S.No    Date         CR No		Modified By			Modification Notes
*  1.		
*
*****************************************************************************************************************************/
#include <time.h>
#include <stdio.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <bom/bom.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <tc/tc_macros.h>
#include <bom/bom_attr.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_string.h>
#include <tccore/workspaceobject.h>
#include <user_exits/epm_toolkit_utils.h>
#include <pie/pie.h>
#include <sa/sa.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define PROP_UIF_ask_value_msg   "PROP_UIF_ask_value"
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}

int ifail = ITK_ok;
int QuantityAttrId=0;
char *ClrSchmToVf = NULL;
char *NoColSchemeMatchPrts = NULL;
tag_t tsk_HSI_rel_type = NULLTAG;
tag_t tRelationFind = NULLTAG;
tag_t windowClr = NULLTAG;
tag_t ruleNC = NULLTAG;
tag_t ClrPartQryTag = NULLTAG;
tag_t qryCTOTag = NULLTAG;
tag_t SchmqueryTag = NULLTAG;
tag_t GeneralQryTag = NULLTAG;
tag_t SchmWithCmpcdRel = NULLTAG;
char *info7ClrSchmMsg=NULL;
char *info2SchmCre=NULL;
char *SchDataToGov = NULL;
static int name_attribute;
FILE* fpCLLog=NULL;
FILE* fpCLErrLog=NULL;

int tm_ProcessColourPartCL(int taskCnt, tag_t *Dml_tasks, tag_t Dml_task, int NCAssyChildFlag, tag_t NonClrPartTag, char *NewColourPart, char *DMLProject);

static void initialise (void);

struct ChldStrut_Col
{
	char *clr_item_id; //Color Part
	int clr_qty;       //Colot Qty
}*get_ChldStrut_Col;

void print_requirement()
{
	printf(
        "\n all the following parameters are mandatory for procedure"
        " USAGE:\n"
        //" -u=<teamcenter dbUsr id> (required)\n"
        //" -p=<teamcenter password> (required)\n"
        //" -g=<teamcenter group> (required)\n"
        " -dml_no=<DML number> (required)\n"
        );
}
static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}

int ITK_user_main(int argc, char *argv[])
{
	char *dml_no = NULL;
	dml_no = ITK_ask_cli_argument("-dml=");
	printf("\n dml_no:    [%s]",dml_no); fflush(stdout);
	if(tc_strlen(stripBlanks(dml_no)) == 0)
	{
		print_requirement();
		return -1;
	}
	initialise();
	printf("\n Input dml_no:  %s \n",dml_no); fflush(stdout);

	if(tm_DMLPostColRlzProcess(dml_no)!=ITK_ok)PrintErrorStack();
	CHECK_FAIL;
	return ifail;
}

int tm_DMLPostColRlzProcess(char* dml_no)
{
	int tskcnt,i=0;
	int partcnt,k=0;
	int NCAssyChildFlag=0;
	tag_t *Dml_tasks=NULLTAG;
	tag_t *PartsTag=NULLTAG;
	tag_t dml_tag = NULLTAG;
	tag_t DMLRevTag = NULLTAG;
	tag_t RevTypTag = NULLTAG;
	tag_t NonClrPartTag = NULLTAG;
	char *RevTyp = NULL;
	char *dmlNumber = NULL;
	char *DMLRevId = NULL;
	char *DML_rlstype = NULL;
	char *DMLProj = NULL;

	if(ITEM_find_item(dml_no, &dml_tag)!=ITK_ok)PrintErrorStack();
	if (dml_tag != NULLTAG)
	{
		if(ITEM_ask_latest_rev(dml_tag, &DMLRevTag)!=ITK_ok)PrintErrorStack();
		if(TCTYPE_ask_object_type(DMLRevTag, &RevTypTag));
		if(TCTYPE_ask_name2(RevTypTag,&RevTyp));

		if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DML_rlstype)!=ITK_ok)PrintErrorStack();
		printf(" and DML_rlstype: [%s]", DML_rlstype);fflush(stdout);

		if(TCTYPE_ask_object_type(DMLRevTag, &RevTypTag));
		if(TCTYPE_ask_name2(RevTypTag,&RevTyp));
		printf("\n RevTyp type: [%s]\n", RevTyp);fflush(stdout);

		if((strcmp(DML_rlstype,"Veh")==0) || (strcmp(DML_rlstype,"MR")==0) || (strcmp(DML_rlstype,"PR")==0))
		{
			int n_entriesCL=1;
			tag_t CntlObj_QtagCL = NULLTAG;
			char *qry_entriesCL[1] = {"SYSCD"};
			char **qry_valuesCL = (char **) MEM_alloc(50 * sizeof(char *));
			int CntrlObjCntCL=0;
			tag_t *qry_cntrlobjCL= NULLTAG;
			char *info1CLlogPath=NULL;
			char* inputfile =(char *) MEM_alloc(100);
			char* inputfile2 =(char *) MEM_alloc(100);

			if(QRY_find("Control Objects...", &CntlObj_QtagCL)!=ITK_ok)PrintErrorStack();
			if (CntlObj_QtagCL!=NULLTAG)
			{
				printf("\n CL=Found Query CntlObj_QtagCL \n"); fflush(stdout);

				qry_valuesCL[0] = "CL_LOGPATH";
				if(QRY_execute(CntlObj_QtagCL, n_entriesCL, qry_entriesCL, qry_valuesCL, &CntrlObjCntCL, &qry_cntrlobjCL)!=ITK_ok)PrintErrorStack();
				printf("\n CL+Control Object count for CL Task [CntrlObjCntCL: %d] \n",CntrlObjCntCL);fflush(stdout);

			}
			else
			{
				printf("\n\t CL=Not Found Query CntlObj_QtagCL, hence skipping ??? \n"); fflush(stdout);
			}

			if(CntrlObjCntCL > 0)
			{
				if (AOM_ask_value_string(qry_cntrlobjCL[0],"t5_Userinfo1",&info1CLlogPath)!=ITK_ok)   PrintErrorStack();
				printf("\n CL=info1CLlogPath= [%s] \n", info1CLlogPath);fflush(stdout);

				tc_strcpy(inputfile,info1CLlogPath);
				tc_strcat(inputfile,dml_no);
				tc_strcat(inputfile,"_CL.log");

				tc_strcpy(inputfile2,info1CLlogPath);
				tc_strcat(inputfile2,dml_no);
				tc_strcat(inputfile2,"_CL_ErrorColPart.log");
			}
			else
			{
				tc_strcpy(inputfile,"/tmp/");
				tc_strcat(inputfile,dml_no);
				tc_strcat(inputfile,"_CL.log");

				tc_strcpy(inputfile2,"/tmp/");
				tc_strcat(inputfile2,dml_no);
				tc_strcat(inputfile2,"_CL_ErrorColPart.log");
			}

			printf("\n CL=inputfile= [%s] ", inputfile);fflush(stdout);
			printf("\n CL=inputfile2= [%s] \n", inputfile2);fflush(stdout);

			fpCLLog=fopen(inputfile,"a");
			fpCLErrLog=fopen(inputfile2,"a");

			fprintf(fpCLLog,"\n\n================START===DML_rlstype: [%s]  dml_no:[%s]================================================================================================\n",DML_rlstype,dml_no); fflush(fpCLLog);
			fprintf(fpCLLog,"\n CL=inputfile= [%s] ", inputfile);fflush(fpCLLog);
			fprintf(fpCLLog,"\n CL=inputfile2= [%s] \n", inputfile2);fflush(fpCLLog);

			// START---define Query/Control objects/Relation type
			if(GRM_find_relation_type("CMHasSolutionItem", &tsk_HSI_rel_type)!=ITK_ok)PrintErrorStack();
			if(GRM_find_relation_type("TC_Is_Represented_By",&tRelationFind)!=ITK_ok)PrintErrorStack();
			if(GRM_find_relation_type("T5_ShmHasClrData",&SchmWithCmpcdRel)!=ITK_ok)PrintErrorStack();
			if(BOM_line_look_up_attribute("bl_quantity", &QuantityAttrId)!=ITK_ok)PrintErrorStack();
			
			if(QRY_find("ClrPart", &ClrPartQryTag));
			if (ClrPartQryTag!=NULLTAG) {
				printf("\n CL=Found Query ClrPartQryTag \n"); fflush(stdout);
				fprintf(fpCLLog,"\n CL=Found Query ClrPartQryTag \n"); fflush(fpCLLog);
			}else {
				printf("\n\t CL=Not Found Query ClrPartQryTag, hence skipping ??? \n"); fflush(stdout);
				fprintf(fpCLLog,"\n\t CL=Not Found Query ClrPartQryTag, hence skipping ??? \n"); fflush(fpCLLog);
				return ifail;
			}

			if(QRY_find("ClrScheme", &SchmqueryTag));
			if (SchmqueryTag!=NULLTAG)
			{
				printf("\n CL=Found Query SchmqueryTag"); fflush(stdout);
				fprintf(fpCLLog,"\n CL=Found Query SchmqueryTag"); fflush(fpCLLog);
			}else
			{
				printf("\n CL=Not Found Query SchmqueryTag \n"); fflush(stdout);
				fprintf(fpCLLog,"\n CL=Not Found Query SchmqueryTag \n"); fflush(fpCLLog);
				if(POM_logout(false)!=ITK_ok)PrintErrorStack();
				return ifail;
			}

			if(QRY_find("General...", &GeneralQryTag));
			if (GeneralQryTag!=NULLTAG)
			{
				printf("\nGeneral... Found Query");	fflush(stdout);
				fprintf(fpCLLog,"\nGeneral... Found Query");	fflush(fpCLLog);
			}else
			{
				printf("\n General...:Not Found Query \n");fflush(stdout);
				fprintf(fpCLLog,"\n General...:Not Found Query \n");fflush(fpCLLog);
				if(POM_logout(false)!=ITK_ok)PrintErrorStack();
				return ifail;
			}
			// END---define Query/Control objects/Relation type

			//DML DETAILS.................
			if(AOM_ask_value_string(DMLRevTag,"item_id",&dmlNumber)!=ITK_ok)PrintErrorStack();
			printf("\n DML Number: [%s]", dmlNumber);fflush(stdout);
			fprintf(fpCLLog,"\n DML Number: [%s]", dmlNumber);fflush(fpCLLog);

			if(AOM_ask_value_string(DMLRevTag,"item_revision_id",&DMLRevId)!=ITK_ok)PrintErrorStack();
			printf("  DMLRevId: [%s]", DMLRevId);fflush(stdout);
			fprintf(fpCLLog,"  DMLRevId: [%s]", DMLRevId);fflush(fpCLLog);

			if(AOM_ask_value_string(DMLRevTag,"t5_rlstype",&DML_rlstype)!=ITK_ok)PrintErrorStack();
			printf("  DML_rlstype: [%s]", DML_rlstype);fflush(stdout);
			fprintf(fpCLLog,"  DML_rlstype: [%s]", DML_rlstype);fflush(fpCLLog);

			if(AOM_ask_value_string(DMLRevTag,"t5_cprojectcode",&DMLProj)!=ITK_ok)PrintErrorStack();
			printf("  DMLProj: [%s]", DMLProj);fflush(stdout);
			fprintf(fpCLLog,"  DMLProj: [%s]", DMLProj);fflush(fpCLLog);

			if(AOM_ask_value_tags(DMLRevTag,"T5_DMLTaskRelation",&tskcnt,&Dml_tasks)!=ITK_ok)PrintErrorStack();
			printf("\n No. of tskcnt: %d ",tskcnt);fflush(stdout);
			fprintf(fpCLLog,"\n No. of tskcnt: %d ",tskcnt);fflush(fpCLLog);

			if (tskcnt>0)
			{
				/////////////////////////////Color Scheme is Queryed/////////////////////////////////////////
				tag_t *ColSchme_tags = NULLTAG;
				tag_t *CmpCodeOfClrScheme = NULLTAG;
				tag_t *ClrPrtTags = NULLTAG;
				tag_t *Col_Rlz_St_list = NULLTAG;
				tag_t *sec_objects = NULLTAG;
				tag_t *CtrlObjTag = NULLTAG;
				tag_t *CntrolObjectTag = NULLTAG;
				tag_t *ProjSetObs = NULLTAG;

				tag_t ColorSchemetag = NULLTAG;
				tag_t ColSchmTypeTag=NULLTAG;
				tag_t ColSchmRevTag = NULLTAG;
				tag_t CmpCodeObjTag=NULLTAG;
				tag_t ColItemTag = NULLTAG;
				tag_t ColorRevTag = NULLTAG;
				tag_t NewColorRevTag = NULLTAG;
				tag_t ReltnExist = NULLTAG;
				tag_t reltask = NULLTAG;
				tag_t secObjTypeTag	= NULLTAG;
				tag_t PrjCdObj	= NULLTAG;

				int resultColSchm=0;
				int co , rs, RlzRevFlag=0;
				int status_count=0;
				int Cmpcount , g1=0;
				int n_ClrPrt_tags, ColRlzStatusCnt, ss2, ColRlzRevFlag=0;
				int n_attchs , st = 0;
				int resultCountObs = 0;
				int n_entriesObs = 2;
				char type_name2[TCTYPE_name_size_c+1];
				char* tsk_object_type = NULL;
				char* tsk_object_name = NULL;
				char* Part_no = NULL;
				char* sPartColInd = NULL;
				char *Clrscheme = NULL;
				char *CpyClrscheme = NULL;
				char *ClSrlName=NULL;
				char *ClSuffix=NULL;
				char *ColSchmRlzSt = NULL;
				char *SchmCmpCode = NULL;
				char *ColPrtLatestRlzSt=NULL;
				char *NewColPartRevSeq=NULL;
				char *NewColourPart=NULL;
				char *info1S=NULL;
				char *ProjectVehClass=NULL;
				char *NCPrtRevision=NULL;

				char *qry_entries4[1] = {"ID"};
				char *qry_entries[1] = {"ID"};
				char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
				char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));
				char ColSchm_name[TCTYPE_name_size_c+1];

				NewColourPart=(char *) MEM_alloc(50 * sizeof(char ));
				CpyClrscheme=(char *) MEM_alloc(50 * sizeof(char ));

				int n_entryCT = 1;
				int n_entryClrSchm = 2;
				int rsltCnt, rsltCount, ct, PrjPltfmSchmFlag = 0;

				char *qry_entriesObs[2] = {"Name","Type"};
				char **qry_valuesObs = (char **) MEM_alloc(10 * sizeof(char *));
				char *qry_entryCT[1]  = {"SYSCD"};
				char *qry_entrySchm[2]  = {"SYSCD","SUBSYSCD"};
				char **qryCT_values =  (char **) MEM_alloc(10 * sizeof(char *));
				char **qrySchm_values =  (char **) MEM_alloc(10 * sizeof(char *));


				///////////////////////////// For loop for DML task and Queryed CMReferences Item /////////////////////////////////////////
				for (i=0;i<tskcnt ;i++ )
				{
					if(AOM_ask_value_string(Dml_tasks[i],"object_type",&tsk_object_type)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(Dml_tasks[i],"object_name",&tsk_object_name)!=ITK_ok)PrintErrorStack();
					printf("\n CL=tsk_object_type: [%s]   tsk_object_name: [%s]",tsk_object_type,tsk_object_name);fflush(stdout);
					fprintf(fpCLLog,"\n CL=tsk_object_type: [%s]   tsk_object_name: [%s]",tsk_object_type,tsk_object_name);fflush(fpCLLog);
					if(tc_strcmp(tsk_object_type,"T5_ChangeTaskRevision")==0)
					{
						if(AOM_ask_value_tags(Dml_tasks[i],"CMHasSolutionItem", &partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
						printf("\n CL=No. of partcnt: %d",partcnt);fflush(stdout);
						fprintf(fpCLLog,"\n CL=No. of partcnt: %d",partcnt);fflush(fpCLLog);
						if (partcnt>0)
						{
							NCAssyChildFlag=0;
							NoColSchemeMatchPrts = (char *) MEM_alloc(10000 * sizeof(char));

							ifail = BOM_create_window (&windowClr);
							CHECK_FAIL;
							//ifail = CFM_find( "Latest Working", &ruleNC );
							ifail = CFM_find( "ERC release and above", &ruleNC );
							CHECK_FAIL;
							ifail = BOM_set_window_config_rule( windowClr, ruleNC );
							CHECK_FAIL;

							tc_strcpy(NewColourPart,"");

							for (k=0; k<partcnt ;k++ )
							{
								NCAssyChildFlag=1;
								NonClrPartTag=PartsTag[k];

								ifail = AOM_ask_value_string(NonClrPartTag,"item_id",&Part_no); CHECK_FAIL;
								printf("\nCL=k: %d----------------Assembly: %s --------------------------------------------------------",k,Part_no);fflush(stdout);
								fprintf(fpCLLog,"\nCL=k: %d----------------Assembly: %s --------------------------------------------------------",k,Part_no);fflush(fpCLLog);

								ifail = AOM_ask_value_string(NonClrPartTag,"item_revision_id",&NCPrtRevision);
								printf("\n Non-Color Part Revision : %s   ",NCPrtRevision); fflush(stdout);
								fprintf(fpCLLog,"\n Non-Color Part Revision : %s  ",NCPrtRevision); fflush(fpCLLog);

								//if(tc_strstr(NCPrtRevision,"NR")==NULL)
								//{
									//check latest ERC Released Non-Colour should be attached to DML
									ifail = AOM_UIF_ask_value(NonClrPartTag, "t5_ColourInd", &sPartColInd); CHECK_FAIL;
									printf("  ColInd: %s",sPartColInd);fflush(stdout);
									fprintf(fpCLLog,"  ColInd: %s",sPartColInd);fflush(fpCLLog);
									if(tc_strcmp(sPartColInd,"Y")==0)
									{
										tm_ProcessColourPartCL(tskcnt,Dml_tasks,Dml_tasks[i],NCAssyChildFlag,NonClrPartTag,NewColourPart,DMLProj);
									}
								//}
								//printf("\n\t CL=NewColourPart: [%s]",NewColourPart);fflush(stdout);
							} //for loop end for partcnt
							
							/*
							printf("\n info7ClrSchmMsg= [%s]  strlen(NoColSchemeMatchPrts): %d", info7ClrSchmMsg,strlen(NoColSchemeMatchPrts));fflush(stdout); //SchmMsgON
							if ((tc_strcmp(info7ClrSchmMsg,"SchmMsgON")==0)&&(strlen(NoColSchemeMatchPrts)>0))
							{
								tc_strcat(NoColSchemeMatchPrts,"\n Colour Scheme match not found for above list of colour Parts DML.\nPls contact PLM colour support team.\n");
								NoColSchemeMatchPrts[strlen(NoColSchemeMatchPrts)] = '\0';

								printf("\nList NoColSchemeMatchPrts: [%s]",NoColSchemeMatchPrts);fflush(stdout);
								EMH_store_error_s1(EMH_severity_error,ITK_errStore1,NoColSchemeMatchPrts);

								return ITK_errStore1;
							}
							*/
						} //if end of partcnt
					} //if end of tsk_object_type
				} //for loop end for tskcnt
			} //if end of tskcnt

			fprintf(fpCLLog,"\n\n CL Task-Process is Finished..\n");fflush(fpCLLog);

			if (fpCLLog!=NULL)
			{
				fclose(fpCLLog);
				fpCLLog=NULL;
			}
			if (fpCLErrLog!=NULL)
			{
				fclose(fpCLErrLog);
				fpCLErrLog=NULL;
			}
		} //if end of RevTyp=ChangeRequestRevision
		else
		{
			printf("\nDML is not of Veh/MR/PR hence skipping from validatn tm_DMLPostColRlzProcess. \n");fflush(stdout);
		}
	} //if end of dml tag
	else
	{
		printf("\n Else--Input DML does not present...\n");fflush(stdout);
	}

	printf("\n\n CL Task-Process is Finished..\n");fflush(stdout);

	return ITK_ok;
}
char* GetColourSrlFrmSchmCompCodes(tag_t *CmpCodesOfClrSchm, int CmpCnt, char *PartCompCode)
{
	int g1=0;

	char *SchmCmpCode=NULL;
	char *t5ClSrl=NULL;
	char *Suffix5=NULL;
	char *ColourID5=NULL;

	tag_t CmpCodeObjTag = NULLTAG;

	t5ClSrl = (char*) malloc(50);
	//Suffix5 = (char*) malloc(20);

	printf("\n In GetColourSrlFrmSchmCompCodes function  CmpCnt: [%d]   PartCompCode: [%s] ",CmpCnt,PartCompCode); fflush(stdout);

	strcpy(t5ClSrl,"");

	for(g1=0;g1<CmpCnt;g1++ )
	{
		if(CmpCodeObjTag) CmpCodeObjTag=NULLTAG;
		CmpCodeObjTag = CmpCodesOfClrSchm[g1];
		if(AOM_ask_value_string(CmpCodeObjTag, "t5_PrtCatCode", &SchmCmpCode )!=ITK_ok)PrintErrorStack();
		//printf("\n SchmCmpCode & Comp_Code is --> : %s = %s\n",SchmCmpCode,Comp_Code); fflush(stdout);

		if(tc_strcmp(SchmCmpCode,PartCompCode)==0)
		{
			printf("\n    SchmCmpCode & PartCompCode-->:%s = %s: ---------->CompCode Match Found......",SchmCmpCode,PartCompCode); fflush(stdout);
			fprintf(fpCLLog,"\n    SchmCmpCode & PartCompCode-->:%s = %s: ---------->CompCode Match Found......",SchmCmpCode,PartCompCode); fflush(fpCLLog);

			if(AOM_ask_value_string(CmpCodeObjTag, "t5_ClSrl", &t5ClSrl )!=ITK_ok)PrintErrorStack();
			printf("\t CL=t5ClSrl--> %s \n",t5ClSrl); fflush(stdout);
			fprintf(fpCLLog,"\t CL=t5ClSrl--> %s",t5ClSrl); fflush(fpCLLog);

			//if(tc_strstr(t5ClSrl,";")!=NULL) {
			//	Suffix5 =  strtok(t5ClSrl,";");
			//	ColourID5  =  strtok(NULL,";");
			//}
			//else {
			//	Suffix5 =  strtok(t5ClSrl,",");
			//	ColourID5  =  strtok(NULL,",");
			//}
			//printf("\t Suffix5: %s    ColourID5: %s ",Suffix5,ColourID5); fflush(stdout);
			//fprintf(fpCLLog,"\t Suffix5: %s    ColourID5: %s ",Suffix5,ColourID5); fflush(fpCLLog);
		}
	}

	//return Suffix5;
	return t5ClSrl;
}
tag_t ColorPartCreate_CL(tag_t NonClrPartRevTag, char *NonClrPart, char *PartCompCode, tag_t SchmRefTag, tag_t *CmpCodesOfClrSchm, int CmpCnt, char *SchemeNm, char *SchemeRev, tag_t CLTaskDmlTag)
{
	int n_ClrParts=0;
	
	char *t5ClSrl = NULL;
	char *Suffix=NULL;
	char *ColourID=NULL;
	char *PartType=NULL;
	char *ClrChildItem=NULL;

	//char *qry_entries[1] = {"Colour ID"},	//uadev
	char *qry_entries[1] = {"Comp Code"},	//UAPROD
		 *qry_values[1]	= {"*"};

	char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));

	tag_t *ClrPartTags=NULLTAG;

	tag_t ColPartRevTag=NULLTAG;
	tag_t ColChilditemMstr = NULLTAG;
	tag_t ReltnExist = NULLTAG;
	tag_t Rel_task = NULLTAG;
	tag_t reltask = NULLTAG;
	tag_t tRelationExist = NULLTAG;

	t5ClSrl = (char*) malloc(50);

	t5ClSrl = GetColourSrlFrmSchmCompCodes(CmpCodesOfClrSchm,CmpCnt,PartCompCode);
	printf("\n  CL-B=t5ClSrl from function: %s",t5ClSrl); fflush(stdout);
	fprintf(fpCLLog,"\n  CL=t5ClSrl from function: %s",t5ClSrl); fflush(fpCLLog);

	if(AOM_ask_value_string(NonClrPartRevTag, "t5_PartType", &PartType)!=ITK_ok)PrintErrorStack();

	if ((t5ClSrl!=NULL) && (strlen(t5ClSrl)>0))
	{
		if(tc_strstr(t5ClSrl,";")!=NULL) {
			Suffix =  strtok(t5ClSrl,";");
			ColourID  =  strtok(NULL,";");
		}
		else {
			Suffix =  strtok(t5ClSrl,",");
			ColourID  =  strtok(NULL,",");
		}
		printf("\n\t   CL=Suffix-->: %s  ColourID: %s ",Suffix,ColourID); fflush(stdout);
		fprintf(fpCLLog,"\n\t   CL=Suffix-->: %s  ColourID: 5s ",Suffix,ColourID); fflush(fpCLLog);

		ClrChildItem=(char *) MEM_alloc(25);
		strcpy(ClrChildItem,"");

		if(tc_strcmp(PartType,"G")==0)
		{
			printf("\n  In GroupID if condition===\n"); fflush(stdout);
			//ResponseStr = NewUniqGroupIDNum();
			//printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
			//
			//ClrChildItem = NULL;
			//ClrChildItem=(char *) MEM_alloc(25);
			//strcpy(ClrChildItem,"");
			//strcat(ClrChildItem,ResponseStr);
			//printf("\n\t   Colour Part for Group ID---->%s\n",ClrChildItem); fflush(stdout);
			fflush(stdout);
		}
		else
		{
			strcpy(ClrChildItem,NonClrPart);
			strcat(ClrChildItem,Suffix);
		}
		printf("\n\t   R--ColPartNo: %s ",ClrChildItem); fflush(stdout);

		if ( (strlen(ClrChildItem)>0) && (ClrPartQryTag!=NULLTAG) )
		{
			//printf("\n\t   CM=Found Query 'ClrPart' ClrPartQryTag \n"); fflush(stdout);
			valuesClrPrt[0] = ClrChildItem;
			if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &n_ClrParts, &ClrPartTags));
			printf("\t ClrPart_QryCount------> %d ",n_ClrParts);fflush(stdout);

			if (n_ClrParts>0)
			{
				ColPartRevTag=ClrPartTags[0];
			}
			else if ((n_ClrParts==0) && (NonClrPartRevTag!=NULLTAG))
			{
				if(ITEM_create_item(ClrChildItem,ClrChildItem,"T5_ClrPart","NR;1",&ColChilditemMstr,&ColPartRevTag)!=ITK_ok) PrintErrorStack();
				if(ColPartRevTag != NULLTAG)
				{
					printf("\n\t R--T5_ClrPart is created---------->\n");fflush(stdout);
					fprintf(fpCLLog,"\n\t R--T5_ClrPart is created---------->\n");fflush(fpCLLog);

					char *t5PrtCatCd = NULL;
					char *t5object_desc = NULL;
					char *clrdesc = NULL;
					char *t5PartStatus = NULL;
					char *t5DesignGrp = NULL;
					char *t5ProjectCode = NULL;
					char *t5DocRemarks = NULL;
					char *t5DrawingInd = NULL;
					char *t5PartCode = NULL;
					char *t5AhdMakeBuyIndicator = NULL;
					char *t5PunPCBUMakeBuyIndicator = NULL;
					char *t5PunMakeBuyIndicator = NULL;
					char *t5DwdMakeBuyIndicator = NULL;
					char *t5Coated = NULL;
					char *UnitOfMeasureS = NULL;

					if( AOM_ask_value_string(NonClrPartRevTag,"t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"object_desc", &t5object_desc)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_Coated", &t5Coated)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_PartStatus", &t5PartStatus)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_DesignGrp", &t5DesignGrp)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_ProjectCode", &t5ProjectCode)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_DocRemarks", &t5DocRemarks)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_DrawingInd", &t5DrawingInd)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_PartCode", &t5PartCode)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_AhdMakeBuyIndicator", &t5AhdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_PunPCBUMakeBuyIndicator", &t5PunPCBUMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_PunMakeBuyIndicator", &t5PunMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
					if( AOM_ask_value_string(NonClrPartRevTag,"t5_DwdMakeBuyIndicator", &t5DwdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();

					printf("\n\t   3.ClrChildItem ---->%s   t5PrtCatCd---->%s   ColourID---->%s",ClrChildItem,t5PrtCatCd,ColourID);fflush(stdout);
					//printf("\n\t   t5Coated---->%s",t5Coated);fflush(stdout);
					//printf("\n\t   t5PartStatus---->%s",t5PartStatus);fflush(stdout);
					//printf("\n\t   t5DesignGrp---->%s",t5DesignGrp);fflush(stdout);
					//printf("\n\t   t5ProjectCode---->%s",t5ProjectCode);fflush(stdout);
					//printf("\n\t   mod_desc---->%s",t5DocRemarks);fflush(stdout);
					//printf("\n\t   t5DrawingInd---->%s",t5DrawingInd);fflush(stdout);
					//printf("\n\t   PartType---->%s",PartType);fflush(stdout);
					//printf("\n\t   t5PartCode---->%s",t5PartCode);fflush(stdout);
					//printf("\n\t   t5AhdMakeBuyIndicator---->%s",t5AhdMakeBuyIndicator);fflush(stdout);
					//printf("\n\t   t5PunPCBUMakeBuyIndicator---->%s",t5PunPCBUMakeBuyIndicator);fflush(stdout);
					//printf("\n\t   t5PunMakeBuyIndicator---->%s",t5PunMakeBuyIndicator);fflush(stdout);
					//printf("\n\t   t5DwdMakeBuyIndicator---->%s",t5DwdMakeBuyIndicator);fflush(stdout);

					clrdesc=(char *) MEM_alloc(200);
					strcpy(clrdesc,"");
					strcpy(clrdesc,ColourID);
					strcat(clrdesc,"-");
					strcat(clrdesc,t5object_desc);

					printf("\n\t   Part Desc ---->%s \n",clrdesc);fflush(stdout);
					fprintf(fpCLLog,"\n\t   Part Desc ---->%s \n",clrdesc);fflush(fpCLLog);

					//if(setAttributesOnDesign(&ColChilditemMstr,clrdesc,UnitOfMeasureS)!=ITK_ok)PrintErrorStack();
					//printf("\n Set Attribute on Class T5_ClrPart------------>\n");fflush(stdout);

					if(tm_setAttributesOnDesignRev2(&ColPartRevTag,clrdesc,"C",t5PrtCatCd,ColourID,t5Coated,t5PartStatus,t5DesignGrp,t5ProjectCode,t5DocRemarks,t5DrawingInd,PartType,t5PartCode,t5AhdMakeBuyIndicator,t5PunPCBUMakeBuyIndicator,t5PunMakeBuyIndicator,t5DwdMakeBuyIndicator,NonClrPart)!=ITK_ok)PrintErrorStack();
					printf("\n\t   Set Attribute on Class T5_ClrPartRevision--------->\n");fflush(stdout);
					fprintf(fpCLLog,"\n\t   Set Attribute on Class T5_ClrPartRevision--------->\n");fflush(fpCLLog);

					if(tm_CreateReleasestatus(ColPartRevTag)!=ITK_ok)PrintErrorStack();
					printf("\n\t   CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(stdout);
					fprintf(fpCLLog,"\n\t   CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(fpCLLog);

					if(tm_AssignProject(ColPartRevTag,t5ProjectCode)!=ITK_ok)PrintErrorStack();
					printf("\n\t   Assign Project to T5_ClrPartsRevision--------->\n");fflush(stdout);
					fprintf(fpCLLog,"\n\t   Assign Project to T5_ClrPartsRevision--------->\n");fflush(fpCLLog);

					//Going to update UserOwner Name
					//if(AOM_set_ownership(ColPartRevTag,user_tag ,group)!=ITK_ok)PrintErrorStack();
					//printf("\n\t   property Value set...!!\n");fflush(stdout);

					if (ColPartRevTag!=NULLTAG)
					{
						if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
						{
							if(GRM_find_relation(CLTaskDmlTag,ColPartRevTag,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
							if (ReltnExist==NULLTAG)
							{
								if(GRM_create_relation(CLTaskDmlTag,ColPartRevTag,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
								if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
								if(AOM_refresh(reltask,0)!=ITK_ok)PrintErrorStack();
								printf("\n\t   DML_Task and Revised New ColChild Part Relation is Created Successfully.....\n");fflush(stdout);
								fprintf(fpCLLog,"\n\t   DML_Task and Revised New ColChild Part Relation is Created Successfully.....\n");fflush(fpCLLog);
							}
						}

						if (tRelationFind!=NULLTAG)
						{
							if(GRM_find_relation(ColPartRevTag,NonClrPartRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
							if (tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
							{
								if(GRM_create_relation(ColPartRevTag,NonClrPartRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
								printf("\n\t   Child-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
								fprintf(fpCLLog,"\n\t   Child-Colour-Non_Colour child part Relation Created Successfully \n");fflush(fpCLLog);
								if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();
								if(AOM_refresh(Rel_task,0)!=ITK_ok)PrintErrorStack();
							}
						}

						if(AOM_lock(ColPartRevTag)!=ITK_ok)PrintErrorStack();
						if(AOM_set_value_string(ColPartRevTag,"gov_classification",SchDataToGov)!=ITK_ok)PrintErrorStack();
						if(AOM_save(ColPartRevTag)!=ITK_ok)PrintErrorStack();
						if(AOM_unlock(ColPartRevTag)!=ITK_ok)PrintErrorStack();
					}
				}
			}
		}
	}

	return ColPartRevTag;
}
//int ValMultiLvlBomForScheme_CCAComp_CL(tag_t NonClrBomline, tag_t SchmRefTag, tag_t *CmpCodesOfClrSchm, int CmpCnt, char *SchemeNm, char *SchemeRev, tag_t CLTaskDmlTag)
int ValMultiLvlBomForScheme_CCAComp_CL(tag_t NonClrBomline, tag_t SchmRefTag, tag_t *CmpCodesOfClrSchm, int CmpCnt, char *SchemeNm, char *SchemeRev)
{
	int ifail;
	int CCAFlag=0;

	/*
	int no_bom_lines=0 , j=0;
	int n_tags_found= 0;
	int level0=0;
	int CompCodeClrSrlMatchFlag = 0;
	int n_ClrChild_tags = 0;

	char *name=NULL;
	char *word=NULL;
	char *NonClrChild=NULL;
	char *ItemRevSeq=NULL;
	char *ItemRevStr=NULL;
	char *ColourInd=NULL;
	char *CompCode=NULL;
	char *ChildItem=NULL;
	char *ChildColInd=NULL;
	char *ChildCompCode=NULL;
	char *ClrChildItem=NULL;

	char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
	char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));

	tag_t *child_bom_lines=NULLTAG;
	tag_t *ClrChildTags=NULLTAG;

	tag_t NonClrMstrTag=NULLTAG;
	tag_t NonClrRevTag=NULLTAG;
	tag_t childbomline=NULLTAG;


	//char *qry_entries[1] = {"Colour ID"},	//uadev
	char *qry_entries[1] = {"Comp Code"},	//UAPROD
		 *qry_values[1]	= {"*"};

	CompCode =(char *) MEM_alloc(100);

	printf("\n In ValMultiLvlBomForScheme_CCAComp_CL Function...........................................................................................\n"); fflush(stdout);
	fprintf(fpCLLog,"\n In ValMultiLvlBomForScheme_CCAComp_CL Function...........................................................................................\n"); fflush(fpCLLog);
	
	initialise_attribute (bomAttr_lineName, &name_attribute);

	printf("\n 1111 --------\n "); fflush(stdout);
	fprintf(fpCLLog,"\n 1111 --------\n "); fflush(fpCLLog);

	ifail = BOM_line_ask_attribute_string (NonClrBomline, name_attribute, &name);
	CHECK_FAIL;
	word = strtok(name, "/");

	printf("\n word: [%s]",word); fflush(stdout);
	if (tc_strcmp(word,"<<REMOTE OBJECT>>")!=0)
	{
		//if( AOM_ask_value_string(NonClrBomline,"bl_T5_ClrPartRevision_t5_ColourInd",&ColourInd)!=ITK_ok);  //uadev
		if( AOM_ask_value_string(NonClrBomline,"bl_Design Revision_t5_ColourInd",&ColourInd)!=ITK_ok);		//UAPROD

		tc_strcpy(CompCode,"");
		//if( AOM_ask_value_string(NonClrBomline,"bl_T5_ClrPartRevision_t5_PrtCatCode",&CompCode)!=ITK_ok);  //uadev
		if( AOM_ask_value_string(NonClrBomline,"bl_Design Revision_t5_PrtCatCode",&CompCode)!=ITK_ok);		//UAPROD

		//if ((tc_strcmp(ColourInd,"Y")==0)&&(strlen(CompCode)>0) && (tc_strstr(CompCode,"CCA")!=NULL))
		if ((tc_strcmp(ColourInd,"Y")==0)&&(strlen(CompCode)>0))
		{
			if( AOM_ask_value_int(NonClrBomline,"bl_level_starting_0",&level0)!=ITK_ok);
			if( AOM_ask_value_string(NonClrBomline,"bl_item_item_id",&NonClrChild)!=ITK_ok);
			if( AOM_ask_value_string(NonClrBomline,"bl_rev_item_revision_id",&ItemRevSeq)!=ITK_ok);

			printf("\n NonClrChild::::::[%d]  [%s]    ItemRevSeq: [%s]    ColourInd:[%s]    CompCode:[%s]",level0,NonClrChild, ItemRevSeq, ColourInd, CompCode); fflush(stdout);

			if(ITEM_find_item(NonClrChild, &NonClrMstrTag)!=ITK_ok)PrintErrorStack();
			if(ITEM_ask_latest_rev(NonClrMstrTag,&NonClrRevTag)!=ITK_ok)PrintErrorStack();
			//if(ITEM_find_revision(NonClrMstrTag,ItemRevSeq,&NonClrRevTag)!=ITK_ok)PrintErrorStack();

			ifail = BOM_line_ask_child_lines (NonClrBomline, &no_bom_lines, &child_bom_lines);
			CHECK_FAIL;

			if (no_bom_lines > 0)
			{
				for (j = 0; j < no_bom_lines; j++)
				{
					childbomline=child_bom_lines[j];

					if( AOM_ask_value_string(childbomline,"bl_item_item_id",&ChildItem)!=ITK_ok);

					//if( AOM_ask_value_string(childbomline,"bl_T5_ClrPartRevision_t5_ColourInd",&ColourInd)!=ITK_ok);  //uadev
					if( AOM_ask_value_string(childbomline,"bl_Design Revision_t5_ColourInd",&ChildColInd)!=ITK_ok);		//UAPROD

					//if( AOM_ask_value_string(childbomline,"bl_T5_ClrPartRevision_t5_PrtCatCode",&CompCode)!=ITK_ok);  //uadev
					if( AOM_ask_value_string(childbomline,"bl_Design Revision_t5_PrtCatCode",&ChildCompCode)!=ITK_ok);	//UAPROD

					printf("\n\n Child:::::[%s]    ColourInd:[%s]  CompCode:[%s]  ",ChildItem, ChildColInd, ChildCompCode); fflush(stdout);

					//if ((tc_strcmp(ChildColInd,"Y")==0) && (strlen(ChildCompCode)>0) && (tc_strstr(ChildCompCode,"CCA")!=NULL))
					if ((tc_strcmp(ChildColInd,"Y")==0) && (strlen(ChildCompCode)>0))
					{
						printf(" ---> CCA--Calling expansion funtion..."); fflush(stdout);
						//ValMultiLvlBomForScheme_CCAComp_CL(childbomline, SchmRefTag, CmpCodesOfClrSchm, CmpCnt, SchemeNm, SchemeRev,CLTaskDmlTag);
						ValMultiLvlBomForScheme_CCAComp_CL(childbomline, SchmRefTag, CmpCodesOfClrSchm, CmpCnt, SchemeNm, SchemeRev);
					}
				}
			}

			if (no_bom_lines > 0)
			{
				MEM_free (child_bom_lines);
			}
		}
	}

	MEM_free (name);
	*/

	return CCAFlag;
}
int ValMultiLvlBomForScheme_CL(tag_t NonClrBomline, tag_t SchmRefTag, tag_t *CmpCodesOfClrSchm, int CmpCnt, char *SchemeNm, char *SchemeRev, tag_t CLTaskDmlTag)
{
	int ifail;
	int no_bom_lines=0 , j=0;
	int n_tags_found= 0;
	int level0=0;
	int CompCodeClrSrlMatchFlag = 0;
	int n_ClrChild_tags = 0;

	char *name=NULL;
	char *word=NULL;
	char *NonClrChild=NULL;
	char *ItemRevSeq=NULL;
	char *ItemRevStr=NULL;
	char *ColourInd=NULL;
	char *CompCode=NULL;
	char *ChildItem=NULL;
	char *ChildColInd=NULL;
	char *ChildCompCode=NULL;
	char *ClrChildItem=NULL;

	char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
	char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));

	tag_t *child_bom_lines=NULLTAG;
	tag_t *ClrChildTags=NULLTAG;

	tag_t NonClrMstrTag=NULLTAG;
	tag_t NonClrRevTag=NULLTAG;
	tag_t childbomline=NULLTAG;


	//char *qry_entries[1] = {"Colour ID"},	//uadev
	char *qry_entries[1] = {"Comp Code"},	//UAPROD
		 *qry_values[1]	= {"*"};

	CompCode =(char *) MEM_alloc(100);

	printf("\n In ValMultiLvlBomForScheme_CL Function...........................................................................................\n"); fflush(stdout);
	fprintf(fpCLLog,"\n In ValMultiLvlBomForScheme_CL Function...........................................................................................\n"); fflush(fpCLLog);

	ifail = BOM_line_ask_attribute_string (NonClrBomline, name_attribute, &name);
	CHECK_FAIL;
	word = strtok(name, "/");

	printf("\n word: [%s]",word); fflush(stdout);
	if (tc_strcmp(word,"<<REMOTE OBJECT>>")!=0)
	{
		//if( AOM_ask_value_string(NonClrBomline,"bl_T5_ClrPartRevision_t5_ColourInd",&ColourInd)!=ITK_ok);  //uadev
		if( AOM_ask_value_string(NonClrBomline,"bl_Design Revision_t5_ColourInd",&ColourInd)!=ITK_ok);		//UAPROD

		tc_strcpy(CompCode,"");
		//if( AOM_ask_value_string(NonClrBomline,"bl_T5_ClrPartRevision_t5_PrtCatCode",&CompCode)!=ITK_ok);  //uadev
		if( AOM_ask_value_string(NonClrBomline,"bl_Design Revision_t5_PrtCatCode",&CompCode)!=ITK_ok);		//UAPROD

		//if ((tc_strcmp(ColourInd,"Y")==0)&&(strlen(CompCode)>0) && ((tc_strstr(CompCode,"CCA")==NULL)||(tc_strstr(CompCode,"VEHICLE")==NULL)||(tc_strstr(CompCode,"TPL")==NULL)) )
		if ((tc_strcmp(ColourInd,"Y")==0)&&(strlen(CompCode)>0) && ((tc_strstr(CompCode,"CCA")==NULL)&&(tc_strstr(CompCode,"VEHICLE")==NULL)&&(tc_strstr(CompCode,"TPL")==NULL)) )
		{
			if( AOM_ask_value_int(NonClrBomline,"bl_level_starting_0",&level0)!=ITK_ok);
			if( AOM_ask_value_string(NonClrBomline,"bl_item_item_id",&NonClrChild)!=ITK_ok);
			if( AOM_ask_value_string(NonClrBomline,"bl_rev_item_revision_id",&ItemRevSeq)!=ITK_ok);

			printf("\n NonClrChild::::::[%d]  [%s]    ItemRevSeq: [%s]    ColourInd:[%s]    CompCode:[%s]",level0,NonClrChild, ItemRevSeq, ColourInd, CompCode); fflush(stdout);

			if(ITEM_find_item(NonClrChild, &NonClrMstrTag)!=ITK_ok)PrintErrorStack();
			if(ITEM_ask_latest_rev(NonClrMstrTag,&NonClrRevTag)!=ITK_ok)PrintErrorStack();
			//if(ITEM_find_revision(NonClrMstrTag,ItemRevSeq,&NonClrRevTag)!=ITK_ok)PrintErrorStack();

			ifail = BOM_line_ask_child_lines (NonClrBomline, &no_bom_lines, &child_bom_lines);
			CHECK_FAIL;

			if (no_bom_lines > 0)
			{
				int ClrChPrtCount=0, colChPrtCnt=0, zp3=0, ColRlzRevFlag=0, PartAttachtoCLTaskFlag=0, ColChildMatch=0;
				int g1=0, n_childCnt=0, it=0;
				int bv_clrcount=0, bvr_count=0, n_occs_clr=0, ic=0;
				int NoClrChildinBom=0, CLTskHSICnt=0, ci=0;

				char *ClrChildSet=NULL;
				char *ColPrtRelSt = NULL;
				char *ColChild = NULL;
				char *ColChildRev = NULL;
				char *ChildComp = NULL;
				char *ChildColourID = NULL;
				char *SchmCmpCode=NULL;
				char *t5ClSrl = NULL;
				char *Suffix = NULL;
				char *ColourID = NULL;
				char *child_item_id = NULL;
				char *ChildColIndClr = NULL;
				char *NewColPartRevSeq = NULL;
				char *NPrtLatestRlzSt = NULL;
				char *tsk_name = NULL;
				char *TskSolutnItem = NULL;

				tag_t *ClrChPrts_tag=NULLTAG;
				tag_t *ColChPrtUniqTags = NULLTAG;
				tag_t *clr_bvs = NULLTAG;
				tag_t *clr_bvrs = NULLTAG;
				tag_t *occs_clr = NULLTAG;
				tag_t *childrenClr = NULLTAG;
				tag_t *CLTskHSItems = NULLTAG;

				tag_t CmpCodeObjTag=NULLTAG;
				tag_t ChildColRevTag = NULLTAG;
				tag_t ColItemMstrTag = NULLTAG;
				tag_t ColLatestRevTag = NULLTAG;
				tag_t ClritemTag = NULLTAG;
				tag_t clrbv = NULLTAG;
				tag_t clrbvrTag = NULLTAG;
				tag_t windowVal = NULLTAG;
				tag_t top_bomLineClr = NULLTAG;
				tag_t NewColorRevTag = NULLTAG;
				tag_t ReltnExist=NULLTAG, reltask=NULLTAG, Rel_task=NULLTAG, tRelationExist1 = NULLTAG, tRelationExist=NULLTAG;


				logical checkout;
				int ncItem_count=0, ik=0 ;
				tag_t *ncRev_list=NULLTAG;
				tag_t NonClrPrtPrevRevTag=NULLTAG;
				char *ncPartno=NULL;
				char *ncPartRev=NULL;
				char *ncRel_status=NULL;

				t5ClSrl = (char*) malloc(50);


				if((tRelationFind!=NULLTAG) && (NonClrRevTag!=NULLTAG))
				{
					if (tc_strstr(ItemRevSeq,"NR;")==NULL)	//Current Rev is NR hence not querying previous revision
					{
						if(ITEM_list_all_revs (NonClrRevTag, &ncItem_count, &ncRev_list)!=ITK_ok)PrintErrorStack();
						printf("\n\t CL=ncItem_count::%d:\n\t", ncItem_count);fflush(stdout);
						fprintf(fpCLLog,"\n\t CL=ncItem_count::%d:\n\t", ncItem_count);fflush(fpCLLog);

						if(ncItem_count > 0)
						{
							for(ik=ncItem_count-1;ik>=0;ik--)
							{
								if(AOM_UIF_ask_value(ncRev_list[ik], "item_id", &ncPartno)!=ITK_ok)PrintErrorStack();
								if(AOM_UIF_ask_value(ncRev_list[ik], "item_revision_id", &ncPartRev)!=ITK_ok)PrintErrorStack();
								if(AOM_UIF_ask_value (ncRev_list[ik], "release_status_list", &ncRel_status)!=ITK_ok)PrintErrorStack();
								if((tc_strstr(ncRel_status,"ERC Released")!=NULL)||(tc_strstr(ncRel_status,"T5_LcsErcRlzd")!=NULL))
								{
									printf("  ncPartno=%s:%s:--", ncPartno,ncPartRev);fflush(stdout);
									fprintf(fpCLLog,"  ncPartno=%s:%s:--", ncPartno,ncPartRev);fflush(fpCLLog);
									NonClrPrtPrevRevTag=ncRev_list[ik];
									break;
								}
							}
						}
					}

					if (NonClrPrtPrevRevTag!=NULLTAG)
					{
						//if(GRM_list_primary_objects_only(NonClrRevTag,tRelationFind,&ClrChPrtCount,&ClrChPrts_tag)!=ITK_ok)PrintErrorStack(); // Latest Non-colour do not have colour parts
						if(GRM_list_primary_objects_only(NonClrPrtPrevRevTag,tRelationFind,&ClrChPrtCount,&ClrChPrts_tag)!=ITK_ok)PrintErrorStack(); //checking colour parts to previous Non-col part
						printf("\n\t IF--ClrChPrtCount: %d",ClrChPrtCount);fflush(stdout);
					}
					else
					{
						if(GRM_list_primary_objects_only(NonClrRevTag,tRelationFind,&ClrChPrtCount,&ClrChPrts_tag)!=ITK_ok)PrintErrorStack(); // Latest Non-colour do not have colour parts
						printf("\n\t ELSE--ClrChPrtCount: %d",ClrChPrtCount);fflush(stdout);
					}

					if(ClrChPrtCount>0)
					{
						colChPrtCnt=0;
						ClrChildSet = (char *) MEM_alloc(10000 * sizeof(char));
						ColChPrtUniqTags = (tag_t *) MEM_alloc(10000 * sizeof(tag_t));
						tc_strcpy(ClrChildSet,"");

						for(zp3 = 0; zp3<ClrChPrtCount; zp3++)
						{
							if(AOM_ask_value_string(ClrChPrts_tag[zp3],"item_id",&ColChild)!=ITK_ok)PrintErrorStack();

							if(ITEM_find_item(ColChild, &ColItemMstrTag)!=ITK_ok)PrintErrorStack();
							if(ITEM_ask_latest_rev(ColItemMstrTag,&ColLatestRevTag)!=ITK_ok)PrintErrorStack();

							if (strlen(ClrChildSet)==0)
							{
								tc_strcpy(ClrChildSet,ColChild);
								tc_strcat(ClrChildSet,",");

								ColChPrtUniqTags[colChPrtCnt]=ColLatestRevTag;
								colChPrtCnt=colChPrtCnt+1;
							}
							else if (tc_strstr(ClrChildSet,ColChild)==NULL)
							{
								tc_strcat(ClrChildSet,ColChild);
								tc_strcat(ClrChildSet,",");

								ColChPrtUniqTags[colChPrtCnt]=ColLatestRevTag;
								colChPrtCnt=colChPrtCnt+1;
							}
						}
						printf("\n\t Distinct colChPrtCnt: %d",colChPrtCnt);fflush(stdout);
						fprintf(fpCLLog,"\n\t Distinct colChPrtCnt: %d",colChPrtCnt);fflush(fpCLLog);

						for(zp3 = 0; zp3<colChPrtCnt; zp3++)
						{
							ChildColRevTag=ColChPrtUniqTags[zp3];

							ColRlzRevFlag=0;
							PartAttachtoCLTaskFlag=0;

							if(AOM_ask_value_string(ChildColRevTag,"item_id",&ColChild)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(ChildColRevTag,"item_revision_id",&ColChildRev)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(ChildColRevTag,"t5_PrtCatCode",&ChildComp)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(ChildColRevTag,"t5_ColourID",&ChildColourID)!=ITK_ok)PrintErrorStack();

							printf("\n\t %d--ColChild: %s,%s ",zp3,ColChild,ColChildRev);fflush(stdout);
							fprintf(fpCLLog,"\n\t %d--ColChild: %s/%s",zp3,ColChild,ColChildRev);fflush(fpCLLog);

							if(AOM_UIF_ask_value (ChildColRevTag, "release_status_list", &ColPrtRelSt)!=ITK_ok)PrintErrorStack();

							if(tc_strstr(ColPrtRelSt,"Obsolete")!=NULL)
							{
								printf(" --This colourPart is in 'Obsolete' hence skipping....");fflush(stdout);
								fprintf(fpCLLog," --This colourPart is in 'Obsolete' hence skipping....");fflush(fpCLLog);
								continue;
							}
							if((tc_strstr(ColPrtRelSt,"ERC Released")!=NULL)||(tc_strstr(ColPrtRelSt,"T5_LcsErcRlzd")!=NULL))
							{
								ColRlzRevFlag=1;
							}
							printf(" ColPrtRelSt: [%s]   ColRlzRevFlag: %d ",ColPrtRelSt,ColRlzRevFlag);fflush(stdout);
							fprintf(fpCLLog," ColPrtRelSt: [%s]   ColRlzRevFlag: %d ",ColPrtRelSt,ColRlzRevFlag);fflush(fpCLLog);

							if (ColRlzRevFlag==0)
							{
								////If ColPrtRelSt=ERC Review then check whether it is attach to any DML of not

								if(AOM_ask_value_string(CLTaskDmlTag,"object_name",&tsk_name)==ITK_ok)
								////printf("\n tsk_name is :%s\n",tsk_name);fflush(stdout);
								////fprintf(fpCLLog,"\n tsk_name is :%s\n",tsk_name);fflush(fpCLLog);

								if (tsk_HSI_rel_type!=NULLTAG)
								{
									if(GRM_list_secondary_objects_only(CLTaskDmlTag, tsk_HSI_rel_type, &CLTskHSICnt, &CLTskHSItems)!=ITK_ok)PrintErrorStack();
									printf("\n\t CLTask: %s --->> CLTskHSICnt partcnt:  %d ",tsk_name, CLTskHSICnt);fflush(stdout);
									fprintf(fpCLLog,"\n    Task: %s --->> CLTskHSICnt partcnt:  %d ",tsk_name, CLTskHSICnt);fflush(fpCLLog);

									if (CLTskHSICnt > 0)
									{
										for (ci = 0; ci < CLTskHSICnt ; ci ++)
										{
											if( AOM_ask_value_string(CLTskHSItems[ci],"item_id",&TskSolutnItem)==ITK_ok)
											//printf("\n\t\t TskSolutnItem-item_id: %s  ColChild: %s",TskSolutnItem,ColChild);fflush(stdout);

											if (tc_strcmp(ColChild,TskSolutnItem)==0)
											{
												printf("\n\t TskSolutnItem-item_id: %s  ColChild: %s",TskSolutnItem,ColChild);fflush(stdout);
												printf(" ---Match-Colour attached found to DML task"); fflush(stdout);

												fprintf(fpCLLog,"\n\t TskSolutnItem-item_id: %s  ColChild: %s",TskSolutnItem,ColChild);fflush(fpCLLog);
												fprintf(fpCLLog," ---Match-Colour attached found to DML task"); fflush(fpCLLog);

												PartAttachtoCLTaskFlag=1;

												break;
											}
										}
									}
								}
							}//if (ColRlzRevFlag==0)


							// Process if non-colour Review part is attached to same DML



							ColChildMatch=0;
							t5ClSrl = (char*) malloc(50);
							t5ClSrl = GetColourSrlFrmSchmCompCodes(CmpCodesOfClrSchm,CmpCnt,ChildComp);
							printf("\n\t CL-C=t5ClSrl from function: [%s]  ChildComp: [%s] ",t5ClSrl,ChildComp); fflush(stdout);
							fprintf(fpCLLog,"\n\t CL-C=t5ClSrl from function: [%s]  ChildComp: [%s] ",t5ClSrl,ChildComp); fflush(fpCLLog);

							if ((t5ClSrl!=NULL) && (strlen(t5ClSrl)>0))
							{
								if(tc_strstr(t5ClSrl,";")!=NULL) {
								Suffix =  strtok(t5ClSrl,";");
								ColourID  =  strtok(NULL,";");
								}
								else {
									Suffix =  strtok(t5ClSrl,",");
									ColourID  =  strtok(NULL,",");
								}

								if (tc_strcmp(ChildColourID,ColourID)==0)
								{
									ColChildMatch=1;

									break;
								}
							}
						} // for loop end
					} //if(ClrChPrtCount>0)

					if(ClrChPrtCount==0)  //New Colour Child will create if not found in above condition
					{
						ChildColRevTag = ColorPartCreate_CL(NonClrRevTag,NonClrChild,CompCode,SchmRefTag, CmpCodesOfClrSchm, CmpCnt, SchemeNm, SchemeRev,CLTaskDmlTag);
						ColChildMatch=1;
					}

					printf("\n\t ColChildMatch :%d ",ColChildMatch);fflush(stdout);

					if (ColChildMatch==1)
					{
						if(ChildColRevTag!=NULLTAG)
						{
							//Create Colour Assembly BVR
							if(ITEM_ask_item_of_rev(ChildColRevTag, &ClritemTag)!=ITK_ok)PrintErrorStack();
							if(ITEM_list_bom_views(ClritemTag,&bv_clrcount, &clr_bvs)!=ITK_ok)PrintErrorStack();
							printf("\n\t 3--bv_clrcnt :%d ",bv_clrcount);fflush(stdout);
							fprintf(fpCLLog,"\n\t 3--bv_clrcnt :%d ",bv_clrcount);fflush(fpCLLog);

							if ( (bv_clrcount>0) && (clr_bvs!=NULLTAG) )
							{
								clrbv = clr_bvs[0];
								MEM_free(clr_bvs);
							}
							else
							{
								if(PS_create_bom_view( NULLTAG, "", "", ClritemTag,&clrbv )!=ITK_ok)PrintErrorStack();
								if(AOM_save( clrbv )!=ITK_ok)PrintErrorStack();
								if(AOM_save( ClritemTag )!=ITK_ok)PrintErrorStack();
								if(AOM_unlock( ClritemTag )!=ITK_ok)PrintErrorStack();
								printf("\n\t 3--inside PS_create_bom_view..\n");fflush(stdout);
								fprintf(fpCLLog,"\n\t 3--inside PS_create_bom_view..\n");fflush(fpCLLog);
							}

							if(clrbv !=NULLTAG)
							{
								//printf("\n Before clrbvrTag find...");fflush(stdout);
								if(ITEM_rev_list_bom_view_revs( ChildColRevTag, &bvr_count, &clr_bvrs)!=ITK_ok)PrintErrorStack();
								printf("\n\t 3--Colour bvr_count  --->[%d]  ",bvr_count); fflush(stdout);
								fprintf(fpCLLog,"\n\t 3--Colour bvr_count  --->[%d]  ",bvr_count); fflush(fpCLLog);
								if (bvr_count > 0)
								{
									clrbvrTag=clr_bvrs[0];
									MEM_free(clr_bvrs);

									if(AOM_lock(clrbvrTag)!=ITK_ok)PrintErrorStack();
									if(PS_list_occurrences_of_bvr( clrbvrTag, &n_occs_clr, &occs_clr )!=ITK_ok)PrintErrorStack();
									printf("\n\t 3-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(stdout);
									fprintf(fpCLLog,"\n\t 3-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(fpCLLog);


									if(BOM_create_window( &windowVal )!=ITK_ok)PrintErrorStack();
									if(BOM_set_window_top_line_bvr	(windowVal, clrbvrTag, &top_bomLineClr)!=ITK_ok)PrintErrorStack();
									if(BOM_set_window_pack_all (windowVal, true)!=ITK_ok)PrintErrorStack();
									if(BOM_line_ask_child_lines (top_bomLineClr, &n_childCnt, &childrenClr)!=ITK_ok)PrintErrorStack();

									printf ("\n  B--n_childCnt=> %d ", n_childCnt); fflush(stdout);

									NoClrChildinBom=0;
									if ( n_childCnt > 0)
									{
										for (it = 0; it < n_childCnt; it++)
										{
											if( AOM_ask_value_string(childrenClr[it], "bl_item_item_id",&child_item_id)!=ITK_ok)PrintErrorStack();
											if( AOM_ask_value_string( childrenClr[it] ,"bl_Design Revision_t5_ColourInd",&ChildColIndClr)!=ITK_ok)PrintErrorStack();

											if (strcmp(ChildColIndClr,"Y")==0)
											{
												NoClrChildinBom=NoClrChildinBom+1;
											}
										}
									}

								}
								else
								{
									if(PS_create_bvr( clrbv, "", "", false, ChildColRevTag,&clrbvrTag)!=ITK_ok)PrintErrorStack();
									if(clrbvrTag !=NULLTAG)
									{
										if(AOM_save( clrbvrTag)!=ITK_ok)PrintErrorStack();
										if(AOM_save( ChildColRevTag )!=ITK_ok)PrintErrorStack();
										if(AOM_unlock( ChildColRevTag )!=ITK_ok)PrintErrorStack();
										printf( "\n\t 3--inside  PS_create_bvr..\n");fflush(stdout);
										fprintf(fpCLLog,"\n\t inside  PS_create_bvr..\n");fflush(fpCLLog);
									}
								}
							}
						}


						printf("\n D--ColRlzRevFlag:%d   PartAttachtoCLTaskFlag: %d ",ColRlzRevFlag,PartAttachtoCLTaskFlag);fflush(stdout);
						fprintf(fpCLLog,"\n\t D--ColRlzRevFlag:%d   PartAttachtoCLTaskFlag: %d ",ColRlzRevFlag,PartAttachtoCLTaskFlag);fflush(fpCLLog);

						if ((ColRlzRevFlag>0) || (PartAttachtoCLTaskFlag==1))  //ERC released ColPart
						{
							int ReviseStatus = ValColAndNonColBomForRevise_CL(NonClrRevTag,ChildColRevTag,ColRlzRevFlag,SchmRefTag);
							printf("   ReviseStatus: %d   ",ReviseStatus);fflush(stdout);

							if ((ReviseStatus==0) && (NoClrChildinBom==0) /*&&(strlen(NonClrChildSet)==0)*/)
							{
								printf(" ---D--No need to revive Colour: %s,%s [%s] --No BOM Difference ..",ColChild,ColChildRev,ColPrtRelSt);fflush(stdout);
								fprintf(fpCLLog,"\t ---D--No need to revive Colour: %s,%s [%s] --No BOM Difference ..",ColChild,ColChildRev,ColPrtRelSt);fflush(fpCLLog);
							}
							else
							{
								//Revise colour childAssy logic
								printf(" ---E--Revive Colour ChildAssy: %s,%s [%s]---",ColChild,ColChildRev,ColPrtRelSt);fflush(stdout);

								if(RES_is_checked_out(ChildColRevTag,&checkout)!=ITK_ok)PrintErrorStack();
								printf(" checkout: %d ",checkout);fflush(stdout);
								fprintf(fpCLLog," 333checkout: %d ",checkout);fflush(fpCLLog);
								if (checkout==0)
								{
									if (ColRlzRevFlag>0)
									{
										if(ITEM_copy_rev(ChildColRevTag,NULL,&NewColorRevTag)!=ITK_ok)PrintErrorStack();  //Revise
										if(AOM_ask_value_string(NewColorRevTag,"item_revision_id",&NewColPartRevSeq)!=ITK_ok)PrintErrorStack();
										printf("\n\t CL--ExpandFunctn=NewColPartRevSeq: %s ",NewColPartRevSeq);fflush(stdout);
										fprintf(fpCLLog,"\n\t CL--ExpandFunctn=NewColPartRevSeq: %s ",NewColPartRevSeq);fflush(fpCLLog);

										printf ( "\t SchDataToGov---> %s \n",SchDataToGov);fflush(stdout);
										fprintf(fpCLLog,"\t SchDataToGov---> %s \n",SchDataToGov);fflush(fpCLLog);

										if(AOM_lock(NewColorRevTag)!=ITK_ok)PrintErrorStack();
										if(AOM_set_value_string(NewColorRevTag,"gov_classification",SchDataToGov)!=ITK_ok)PrintErrorStack();
										if(AOM_save(NewColorRevTag)!=ITK_ok)PrintErrorStack();
										if(AOM_unlock(NewColorRevTag)!=ITK_ok)PrintErrorStack();
										if (NewColorRevTag!=NULLTAG)
										{
											if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
											{
												if(GRM_find_relation(CLTaskDmlTag,NewColorRevTag,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
												if (ReltnExist==NULLTAG)
												{
													if(GRM_create_relation(CLTaskDmlTag,NewColorRevTag,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
													if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
													if(AOM_refresh(reltask,0)!=ITK_ok)PrintErrorStack();
													printf("\n\t CL--ExpandFunctn=DML_Task and Revised New ColPart Relation is Created Successfully.....\n");fflush(stdout);
													fprintf(fpCLLog,"\n\t CL--ExpandFunctn=DML_Task and Revised New ColPart Relation is Created Successfully.....\n");fflush(fpCLLog);
												}
											}

											//below point is in Under discussion at TZ 1.56
											int n_attchs=0 ,l=0;
											tag_t*  secondary_objects = NULLTAG;

											if (tRelationFind!=NULLTAG)
											{
												if(GRM_find_relation(NewColorRevTag,NonClrRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
												if(tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
												{
													if(GRM_create_relation(NewColorRevTag,NonClrRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
													if(Rel_task!=NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
													{
														printf("\n CL--ExpandFunctn=Assy-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
														fprintf(fpCLLog,"\n CL--ExpandFunctn=Assy-Colour-Non_Colour child part Relation Created Successfully \n");fflush(fpCLLog);
														if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();
														if(AOM_refresh(Rel_task,0)!=ITK_ok)PrintErrorStack();
													}
													else
													{
														printf("\n CL--ExpandFunctn=Assy-Colour-Non_Colour child part Relation is NOT Created Successfully \n");fflush(stdout);
														fprintf(fpCLLog,"\n CL--ExpandFunctn=Assy-Colour-Non_Colour child part Relation is NOT Created Successfully \n");fflush(fpCLLog);
													}
												}

												printf("\n\n\t CL--NewColPartRevSeq :: %s\n",NewColPartRevSeq);fflush(stdout);

												if (tc_strstr(NewColPartRevSeq,"NR")==NULL)
												{
													printf("\n\n\t CL--ExpandFunctn ");fflush(stdout);
													if(GRM_list_secondary_objects_only(NewColorRevTag,tRelationFind,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
													printf("\n  =No of DI : %d\n",n_attchs);fflush(stdout);
													fprintf(fpCLLog,"\n\n\t\t CL--ExpandFunctn=No of DI : %d",n_attchs);fflush(fpCLLog);
													if(n_attchs>0)
													{
														for (l=0;l<n_attchs ;l++ )
														{
															if(AOM_UIF_ask_value (secondary_objects[l], "release_status_list", &NPrtLatestRlzSt)!=ITK_ok)PrintErrorStack();
															if((tc_strstr(NPrtLatestRlzSt,"ERC Released")!=NULL) || (tc_strstr(NPrtLatestRlzSt,"T5_LcsErcRlzd")!=NULL))
															{
																printf("\t ColPrtLatestRlzSt: %s\n",NPrtLatestRlzSt);fflush(stdout);
																fprintf(fpCLLog,"\t ColPrtLatestRlzSt: %s\n",NPrtLatestRlzSt);fflush(fpCLLog);
																if(GRM_find_relation(NewColorRevTag,secondary_objects[l],tRelationFind,&tRelationExist1)!=ITK_ok)PrintErrorStack();
																if(tRelationExist1!=NULLTAG)
																{
																	if(GRM_delete_relation(tRelationExist1)!=ITK_ok)PrintErrorStack();
																	if(AOM_lock(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																	if(AOM_save(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																	if(AOM_unlock(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																	printf("\n CL--ExpandFunctn=Relation Deleted Successfully\n"); fflush(stdout);
																	fprintf(fpCLLog,"\n CL--ExpandFunctn=Relation Deleted Successfully\n"); fflush(fpCLLog);
																}
															}
														}
													}
												}// end for if
											}
										}
									}
									else
									{
										NewColorRevTag=ChildColRevTag; //For ERC Review
									}
									
									if(NewColorRevTag!=NULLTAG)
									{
										//if(AOM_ask_value_string(NewColorRevTag,"item_revision_id",&ColChildRev)!=ITK_ok)PrintErrorStack();
										//printf("\n\t ColChildRev: %s  ",ColChildRev);fflush(stdout);

										//Create Colour Assembly BVR
										if(ITEM_ask_item_of_rev(NewColorRevTag, &ClritemTag)!=ITK_ok)PrintErrorStack();
										if(ITEM_list_bom_views(ClritemTag,&bv_clrcount, &clr_bvs)!=ITK_ok)PrintErrorStack();
										printf("  bv_clrcnt :%d ",bv_clrcount);fflush(stdout);
										fprintf(fpCLLog,"  bv_clrcnt :%d ",bv_clrcount);fflush(fpCLLog);

										if (bv_clrcount!=NULLTAG)
										{
											clrbv = clr_bvs[0];
											MEM_free(clr_bvs);
										}
										else
										{
											if(PS_create_bom_view( NULLTAG, "", "", ClritemTag,&clrbv )!=ITK_ok)PrintErrorStack();
											if(AOM_save( clrbv )!=ITK_ok)PrintErrorStack();
											if(AOM_save( ClritemTag )!=ITK_ok)PrintErrorStack();
											if(AOM_unlock( ClritemTag )!=ITK_ok)PrintErrorStack();
											printf("\n\t inside PS_create_bom_view..\n");fflush(stdout);
											fprintf(fpCLLog,"\n\t inside PS_create_bom_view..\n");fflush(fpCLLog);
										}

										if(clrbv !=NULLTAG)
										{
											//printf("\n Before clrbvrTag find...");fflush(stdout);
											if(ITEM_rev_list_bom_view_revs( NewColorRevTag, &bvr_count, &clr_bvrs)!=ITK_ok)PrintErrorStack();
											printf("\n\t CL--Colour bvr_count  --->[%d]  ",bvr_count); fflush(stdout);
											fprintf(fpCLLog,"\n\t CL--Colour bvr_count  --->[%d]  ",bvr_count); fflush(fpCLLog);
											if (bvr_count > 0)
											{
												clrbvrTag=clr_bvrs[0];
												MEM_free(clr_bvrs);

												if(AOM_lock(clrbvrTag)!=ITK_ok)PrintErrorStack();
												if(PS_list_occurrences_of_bvr( clrbvrTag, &n_occs_clr, &occs_clr )!=ITK_ok)PrintErrorStack();\
												printf("\n\t CL-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(stdout);
												fprintf(fpCLLog,"\n\t CL-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(fpCLLog);

												if (n_occs_clr > 0)
												{
													for (ic = 0; ic<n_occs_clr; ic++)
													{
														if(PS_delete_occurrence( clrbvrTag, occs_clr[ic] )!=ITK_ok)PrintErrorStack();
													}
													if(AOM_save( clrbvrTag )!=ITK_ok)PrintErrorStack();
													if(AOM_unlock( clrbvrTag )!=ITK_ok)PrintErrorStack();
													MEM_free(occs_clr);
												}
											}
											else
											{
												if(PS_create_bvr( clrbv, "", "", false, NewColorRevTag,&clrbvrTag)!=ITK_ok)PrintErrorStack();
												if(clrbvrTag !=NULLTAG)
												{
													if(AOM_save( clrbvrTag)!=ITK_ok)PrintErrorStack();
													if(AOM_save( NewColorRevTag )!=ITK_ok)PrintErrorStack();
													if(AOM_unlock( NewColorRevTag )!=ITK_ok)PrintErrorStack();
													printf( "\n\t inside  PS_create_bvr..\n");fflush(stdout);
													fprintf(fpCLLog,"\n\t inside  PS_create_bvr..\n");fflush(fpCLLog);
												}
											}

											//--START--Adding Childs under New Colour Assy bvr-----------

											//Previous Released Colour assy- Start
											tag_t   bom_winclr=NULLTAG;
											tag_t   top_line1=NULLTAG;
											tag_t   ruleClr	=NULLTAG;
											int rulefound1= 0;
											tag_t *closurerule1 = NULL;
											tag_t close_tag1;
											char **rulename1 = NULL;
											char **rulevalue1 = NULL;
											tag_t *lines1 = NULL;
											int n_lines1,k1,k2,CClrQty =0;
											tag_t  clrPartObject		= NULLTAG;
											tag_t  CCChildItemTag		= NULLTAG;
											char *CCChildQty = NULL;
											char *ColourIndC = NULL;
											char *ClrCompCode = NULL;
											char *t5_clr_item_id = NULL;

											int nc1,NClrQty1,p1 =0;
											tag_t Childobject1 = NULLTAG;
											tag_t NCChildItemTag1 = NULLTAG;
											tag_t *NonClrChilds1 = NULLTAG;
											char *NCChild1=NULL;
											char *NCChildColInd1=NULL;
											char *NCChildQt1y=NULL;

											if (ChildColRevTag!=NULLTAG)
											{
												if(BOM_create_window( &bom_winclr)!=ITK_ok)PrintErrorStack();
												//if(CFM_find("Color ERC Released and above", &ruleClr)!=ITK_ok)PrintErrorStack(); // To be discussed later if released rule requitred here
												if(CFM_find("Color ERC Review and above", &ruleClr)!=ITK_ok)PrintErrorStack();
												if(BOM_set_window_config_rule(bom_winclr, ruleClr)!=ITK_ok)PrintErrorStack();
												/*
												if(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound1, &closurerule1)!=ITK_ok)PrintErrorStack();
												if (rulefound1 > 0)
												{
													close_tag1 = closurerule1[0];
													printf ("closure ruleClr found \n");fflush(stdout);
													fprintf(fpCLLog,"closure ruleClr found \n");fflush(fpCLLog);
												}
												if(BOM_window_set_closure_rule(bom_winclr,close_tag1, 0, rulename1,rulevalue1)!=ITK_ok)PrintErrorStack();
												*/
												if(BOM_set_window_pack_all(bom_winclr, TRUE)!=ITK_ok)PrintErrorStack();
												if(BOM_set_window_top_line(bom_winclr , NULLTAG, ChildColRevTag, NULLTAG, &top_line1)!=ITK_ok)PrintErrorStack();
												if(BOM_line_ask_child_lines(top_line1, &n_lines1, &lines1)!=ITK_ok)PrintErrorStack();
											}
											printf("\n\tPrevisous rev-Colour bvr n_lines1: %d \n",n_lines1); fflush(stdout);
											//Previous Released Colour assy- End

											if(AOM_lock(clrbvrTag)!=ITK_ok)PrintErrorStack();
											printf("\n\t NonClrChild,ItemRevSeq= %s,%s   no_bom_lines==> %d",NonClrChild, ItemRevSeq,no_bom_lines); fflush(stdout);
											fprintf(fpCLLog,"\n\t NonClrChild,ItemRevSeq= %s,%s   no_bom_lines==> %d",NonClrChild, ItemRevSeq,no_bom_lines); fflush(fpCLLog);
											int nc2 = 0, NClrQty=0, p2=0;
											char *NCChild=NULL;
											char *NCChildRevSeq=NULL;
											char *NCChildColInd=NULL;
											char *NCChildCompCode=NULL;
											char *NCChildPartType=NULL;
											char *NCChildQty = NULL;
											char *clr_item_id = NULL;
											tag_t Childobject = NULLTAG;
											tag_t NCChildItemTag2 = NULLTAG;
											//tag_t NClrItemMstrTag=NULLTAG;
											tag_t NClrItemRevTag=NULLTAG;
											tag_t *occs = NULLTAG;

											for (nc2 = 0; nc2 < no_bom_lines; nc2++)
											{
												if(Childobject) Childobject=NULLTAG;
												Childobject=child_bom_lines[nc2];

												if(AOM_ask_value_string(Childobject, "bl_item_item_id", &NCChild)!=ITK_ok)PrintErrorStack();
												if(AOM_ask_value_string(Childobject, "bl_rev_item_revision_id", &NCChildRevSeq)!=ITK_ok)PrintErrorStack();
												if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_ColourInd", &NCChildColInd)!=ITK_ok)PrintErrorStack();
												if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_PrtCatCode", &NCChildCompCode)!=ITK_ok)PrintErrorStack();
												if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_PartType", &NCChildPartType)!=ITK_ok)PrintErrorStack();

												if(BOM_line_ask_attribute_string(Childobject,QuantityAttrId, &NCChildQty)!=ITK_ok)PrintErrorStack();
												NClrQty=atoi(NCChildQty);

												printf("\n\n  A--nc2: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  PartType: [%s]   Bomline_NClrQty: [%d]",nc2,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode,NCChildPartType,NClrQty); fflush(stdout);
												fprintf(fpCLLog,"\n\n  A--nc2: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  Bomline_NClrQty: [%d]",nc2,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode,NClrQty); fflush(fpCLLog);

												if(ITEM_find_item(NCChild,&NCChildItemTag2)!=ITK_ok)PrintErrorStack();

												if(NCChildItemTag2==NULLTAG)
												{
													printf("\n\n  ChildPart==> %s/%s  NCChildItemTag2 tag not found ?????",NCChild,NCChildRevSeq); fflush(stdout);
													fprintf(fpCLLog,"\n\n  ChildPart==> %s/%s  NCChildItemTag2 tag not found ?????",NCChild,NCChildRevSeq); fflush(fpCLLog);
												}
												else
												{
													if(tc_strcmp(NCChildColInd,"N")==0)
													{
														printf(" ---child ColInd==> N \n"); fflush(stdout);
														fprintf(fpCLLog," ---child ColInd==> N \n"); fflush(fpCLLog);

														if(NClrQty==0)
														{
															if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
														}
														else
														{
															for (p2=0;p2<NClrQty ;p2++ )
															{
																if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																printf("\n    0-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																fprintf(fpCLLog,"\n    0-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
															}
														}
													}
													else if(tc_strcmp(NCChildColInd,"Y")==0)
													{
														int childExistFl=0;

														printf(" ---child ColInd==> Y  NCChildCompCode: %s ",NCChildCompCode); fflush(stdout);
														fprintf(fpCLLog," ---child ColInd==> Y  NCChildCompCode: %s ",NCChildCompCode); fflush(fpCLLog);

														if((tc_strstr(NCChildCompCode,"CCA")!=NULL)||(tc_strstr(NCChildCompCode,"VEHICLE")!=NULL)||(tc_strstr(NCChildCompCode,"TPL")!=NULL))
														{
															childExistFl=0;
															for (k1=0;k1<n_lines1 ;k1++ )
															{
																if(clrPartObject) clrPartObject=NULLTAG;
																clrPartObject=lines1[k1];

																if(AOM_ask_value_string(clrPartObject, "bl_item_item_id", &t5_clr_item_id)!=ITK_ok)PrintErrorStack();
																printf("\n\t B--t5_clr_item_id: %s",t5_clr_item_id); fflush(stdout);
																fprintf(fpCLLog,"\n\t B--t5_clr_item_id: %s",t5_clr_item_id); fflush(fpCLLog);

																if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
																printf(" ColourIndC: %s",ColourIndC); fflush(stdout);
																fprintf(fpCLLog," ColourIndC: %s",ColourIndC); fflush(fpCLLog);

																if((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0))
																{
																	if (strstr(t5_clr_item_id,NCChild)!=NULL)
																	{
																		childExistFl=1;

																		//if(BOM_line_ask_attribute_string(clrPartObject,QuantityAttrId, &CCChildQty)!=ITK_ok)PrintErrorStack();
																		//NClrQty=atoi(CCChildQty);

																		break;
																	}
																}
															}

															printf("\n\t childExistFl: %d",childExistFl); fflush(stdout);
															if (childExistFl==0)
															{
																printf("\n ...---adding child from colour bom and not present in non-col bom.....[%s]=[%d]",NCChild,NClrQty); fflush(stdout);
																fprintf(fpCLLog,"\n ...---adding child from colour bom and not present in non-col bom.....[%s]=[%d]",NCChild,NClrQty); fflush(fpCLLog);

																if(NClrQty==0)
																{
																	if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																	printf("\n    if==>1-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(stdout);
																	fprintf(fpCLLog,"\n    if==>1-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(fpCLLog);
																}
																else
																{
																	for (k2=0;k2<NClrQty;k2++ )
																	{
																		if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																		printf("\n    else==>1-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(stdout);
																		fprintf(fpCLLog,"\n    else==>1-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(fpCLLog);
																	}
																}
															}
														}
														else ////Comp_code not like CCA% , VEHICLE, TPLS%
														{
															char *ClrChildItem = NULL;
															logical checkout2;
															int CompCodeClrSrlMatchFlag = 0;
															t5ClSrl = (char*) malloc(50);

															t5ClSrl = GetColourSrlFrmSchmCompCodes(CmpCodesOfClrSchm,CmpCnt,NCChildCompCode);
															printf("\n  CL-E=t5ClSrl from function: %s",t5ClSrl); fflush(stdout);
															fprintf(fpCLLog,"\n  CL=t5ClSrl from function: %s",t5ClSrl); fflush(fpCLLog);

															if ((t5ClSrl!=NULL) && (strlen(t5ClSrl)>0))
															{
																if(tc_strstr(t5ClSrl,";")!=NULL) {
																	Suffix =  strtok(t5ClSrl,";");
																	ColourID  =  strtok(NULL,";");
																}
																else {
																	Suffix =  strtok(t5ClSrl,",");
																	ColourID  =  strtok(NULL,",");
																}
																printf("\n\t   CL=Suffix-->: %s  ColourID: %s ",Suffix,ColourID); fflush(stdout);
																fprintf(fpCLLog,"\n\t   CL=Suffix-->: %s  ColourID: %s ",Suffix,ColourID); fflush(fpCLLog);


																if(tc_strcmp(NCChildPartType,"G")==0)
																{
																	printf("\n  In GroupID if condition===\n"); fflush(stdout);
																	//ResponseStr = NewUniqGroupIDNum();
																	//printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
																	//
																	//ClrChildItem = NULL;
																	//ClrChildItem=(char *) MEM_alloc(25);
																	//strcpy(ClrChildItem,"");
																	//strcat(ClrChildItem,ResponseStr);
																	//printf("\n\t   Colour Part for Group ID---->%s\n",ClrChildItem); fflush(stdout);
																	fflush(stdout);
																}
																else
																{
																	ClrChildItem=(char *) MEM_alloc(25);
																	strcpy(ClrChildItem,"");
																	strcpy(ClrChildItem,NCChild);
																	strcat(ClrChildItem,Suffix);
																}
																printf("\n\t   Child_ColPartNo: %s ",ClrChildItem); fflush(stdout);

																if ( (strlen(ClrChildItem)>0) && (ClrPartQryTag!=NULLTAG) )
																{
																	CompCodeClrSrlMatchFlag = 1;
																	//printf("\n\t   CM=Found Query 'ClrPart' ClrPartQryTag \n"); fflush(stdout);
																	valuesClrPrt[0] = ClrChildItem;
																	if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &n_ClrChild_tags, &ClrChildTags));
																	printf("\t ClrPart_QryCount------> %d ",n_ClrChild_tags);fflush(stdout);

																	if(ITEM_ask_latest_rev(NCChildItemTag2,&NClrItemRevTag)!=ITK_ok)PrintErrorStack();

																	if (n_ClrChild_tags==0)
																	{
																		tag_t ColChilditemMstr = NULLTAG;
																		tag_t ColChilditemRevTag = NULLTAG;

																		if(NClrItemRevTag!=NULLTAG)
																		{
																			ColChilditemRevTag = ColorPartCreate_CL(NClrItemRevTag,NCChild,NCChildCompCode,SchmRefTag, CmpCodesOfClrSchm, CmpCnt, SchemeNm, SchemeRev,CLTaskDmlTag);
																			
																			if(ColChilditemRevTag!=NULLTAG)
																			{
																				if(AOM_ask_value_string(ColChilditemRevTag, "item_id", &clr_item_id)!=ITK_ok)PrintErrorStack();
																				printf("\n\t B--clr_item_id: %s",clr_item_id); fflush(stdout);

																				if(ITEM_find_item(clr_item_id,&ColChilditemMstr)!=ITK_ok)PrintErrorStack();

																				//if(ITEM_ask_item_of_rev(ColChilditemRevTag, &ColChilditemMstr)!=ITK_ok)PrintErrorStack();
																			}
																		}

																		if(ColChilditemMstr != NULLTAG)
																		{
																			if(NClrQty==0)
																			{
																				if(PS_create_occurrences(clrbvrTag, ColChilditemMstr, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																				printf("\n\t if==3-->PS_create_occurrences successfully in PSE for Non-Colors-------> "); fflush(stdout);
																				fprintf(fpCLLog,"\n\t if==3-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(fpCLLog);
																			}
																			else
																			{
																				for (p2=0;p2<NClrQty ;p2++ )
																				{
																					if(PS_create_occurrences(clrbvrTag, ColChilditemMstr, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																					printf("\n\t else==3-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors-------> ",p2); fflush(stdout);
																					fprintf(fpCLLog,"\n\t else==3-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																				}
																			}
																			if(AOM_save(clrbvrTag)!=ITK_ok)PrintErrorStack();
																		}
																		else
																		{
																			printf("\n\t else==ColChilditemRevTag is not found created hence not added to BVR ?????? [%s]",ClrChildItem); fflush(stdout);
																			fprintf(fpCLLog,"\n\t else==ColChilditemRevTag is not found created hence not added to BVR ?????? [%s]",ClrChildItem); fflush(fpCLLog);
																		}
																	}
																	else
																	{
																		printf("\nCL=ClrChildItem: %s Already present in PLM-TCUA, hence no need to create....Adding under ClrAssy BVR..\n",ClrChildItem);fflush(stdout);
																		fprintf(fpCLLog,"\nCL=ClrChildItem: %s Already present in PLM-TCUA, hence no need to create....Adding under ClrAssy BVR..\n",ClrChildItem);fflush(fpCLLog);
																		if(NClrQty==0)
																		{
																			if(PS_create_occurrences(clrbvrTag, ClrChildTags[0], NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																			printf("\n\t if==4-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(stdout);
																			fprintf(fpCLLog,"\n\t if==4-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(fpCLLog);
																		}
																		else
																		{
																			for (p2=0;p2<NClrQty ;p2++ )
																			{
																				if(PS_create_occurrences(clrbvrTag, ClrChildTags[0], NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																				printf("\n\t else==4-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																				fprintf(fpCLLog,"\n\t else==4-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																			}
																		}
																		if(AOM_save(clrbvrTag)!=ITK_ok)PrintErrorStack();
																	}
																}
																else
																{
																	printf("\t -->Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....??????\n"); fflush(stdout);
																	fprintf(fpCLLog,"\t -->Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....??????\n"); fflush(fpCLLog);
																}
															}

															if (CompCodeClrSrlMatchFlag==0)
															{
																printf("\n\n\t ---Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(stdout);
																fprintf(fpCLLog,"\n\n\t ---Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(fpCLLog);
																fprintf(fpCLErrLog,"\n Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(fpCLErrLog);

																if(ITEM_find_item(NCChild,&NCChildItemTag2)!=ITK_ok)PrintErrorStack();

																if(NClrQty==0)
																{
																	if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																	printf("\n\t if==5-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(stdout);
																	fprintf(fpCLLog,"\n\t if==5-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(fpCLLog);
																}
																else
																{
																	for (p2=0;p2<NClrQty ;p2++ )
																	{
																		if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																		printf("\n\n\t   else==5-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																		fprintf(fpCLLog,"\n\n\t   else==5-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																	}
																}
																if(AOM_save(clrbvrTag)!=ITK_ok)PrintErrorStack();
															}
														}
													}
													else if(tc_strcmp(ChildColInd,"")==0)
													{
														printf("\t ---child ColInd==> NULL \n"); fflush(stdout);
														fprintf(fpCLLog,"\t ---child ColInd==> NULL \n"); fflush(fpCLLog);
														if(ITEM_find_item(NCChild,&NCChildItemTag2)!=ITK_ok)PrintErrorStack();
														if(PS_create_occurrences(clrbvrTag, NCChildItemTag2, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
													}
												} //end of ELSE condn (NCChildItemTag2!=NULLTAG)
												if(AOM_save(clrbvrTag)!=ITK_ok)PrintErrorStack();
											} // end of for loop NonClrChildCnt

											printf("\n\t ChildColRevTag--------------------> rev-Colour bvr [n_lines1]: %d \n",n_lines1); fflush(stdout);
											fprintf(fpCLLog,"\n\t ChildColRevTag-------------------->\n"); fflush(fpCLLog);
											if ((ChildColRevTag!=NULLTAG) && (n_lines1 >0))
											{
												int CLChildExistFl=0;
												int k5=0;
												for (k5=0; k5<n_lines1; k5++ )
												{
													CLChildExistFl=0;
													if(clrPartObject) clrPartObject=NULLTAG;
													clrPartObject=lines1[k5];

													if(AOM_ask_value_string(clrPartObject, "bl_item_item_id", &t5_clr_item_id)!=ITK_ok)PrintErrorStack();
													printf("\n\t k5: [%d]  t5_clr_item_id ===> :: %s",k5,t5_clr_item_id); fflush(stdout);

													if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
													if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_PrtCatCode", &ClrCompCode)!=ITK_ok)PrintErrorStack();
													printf("\n\t ColourIndC ===> :: %s  ClrCompCode:: %s ",ColourIndC,ClrCompCode); fflush(stdout);

													if(((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0)) && ((tc_strstr(ClrCompCode,"CCA")!=NULL)||(tc_strstr(ClrCompCode,"VEHICLE")!=NULL)||(tc_strstr(ClrCompCode,"TPL")!=NULL)))
													{
														int nk3=0;
														char *NCChild2=NULL;

														for (nk3=0;nk3<no_bom_lines ;nk3++ )
														{
															if(Childobject) Childobject=NULLTAG;
															Childobject=child_bom_lines[nk3];

															if(AOM_ask_value_string(Childobject, "bl_item_item_id", &NCChild2)!=ITK_ok)PrintErrorStack();
															printf("\n\t\t R--NCChild2: %s",NCChild2); fflush(stdout);
															fprintf(fpCLLog,"\n\t B--NCChild2: %s",NCChild2); fflush(fpCLLog);

															if(AOM_ask_value_string(Childobject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
															printf(" ColourIndC: %s",ColourIndC); fflush(stdout);
															fprintf(fpCLLog," ColourIndC: %s",ColourIndC); fflush(fpCLLog);

															if((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0))
															{
																if (strstr(t5_clr_item_id,NCChild2)!=NULL)
																{
																	CLChildExistFl=1;

																	break;
																}
															}
														}
														printf(" CLChildExistFl: %d ",CLChildExistFl); fflush(stdout);
														if (CLChildExistFl==1)
														{
															if(BOM_line_ask_attribute_string(Childobject,QuantityAttrId, &CCChildQty)!=ITK_ok)PrintErrorStack();
															CClrQty=atoi(CCChildQty);

															if(ITEM_find_item(t5_clr_item_id, &CCChildItemTag)!=ITK_ok)PrintErrorStack();

															if(CClrQty==0)
															{
																if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																printf("\n\t if==6-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(stdout);
																fprintf(fpCLLog,"\n\t if==6-->PS_create_occurrences successfully in PSE for Non-Colors------->"); fflush(fpCLLog);
															}
															else
															{
																for (k2=0;k2<CClrQty;k2++ )
																{
																	if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																	printf("\n    6-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(stdout);
																	fprintf(fpCLLog,"\n    6-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(fpCLLog);
																}
															}
														} //End of condn if (CLChildExistFl==1)
													} //if condn end
												}
											}
											//--END--Adding Childs under New Colour Assy bvr-----------
										}
										printf("\n B==After clrbvrTag creation --- ");fflush(stdout);
										fprintf(fpCLLog,"\n B==After clrbvrTag creation --- ");fflush(fpCLLog);
										if(AOM_save(clrbvrTag)!=ITK_ok)PrintErrorStack();
										if(AOM_unlock(clrbvrTag)!=ITK_ok)PrintErrorStack();
										printf("\t clrbvrTag is saved...");fflush(stdout);
										fprintf(fpCLLog,"\t clrbvrTag is saved...");fflush(fpCLLog);

									}//if(NewColorRevTag!=NULLTAG)


								} //if (checkout==0)



							}  //else end revise logic
						}
					} //if (ColChildMatch==1)

					for (j = 0; j < no_bom_lines; j++)
					{
						childbomline=child_bom_lines[j];

						if( AOM_ask_value_string(childbomline,"bl_item_item_id",&ChildItem)!=ITK_ok);

						//if( AOM_ask_value_string(childbomline,"bl_T5_ClrPartRevision_t5_ColourInd",&ColourInd)!=ITK_ok);  //uadev
						if( AOM_ask_value_string(childbomline,"bl_Design Revision_t5_ColourInd",&ChildColInd)!=ITK_ok);		//UAPROD

						//if( AOM_ask_value_string(childbomline,"bl_T5_ClrPartRevision_t5_PrtCatCode",&CompCode)!=ITK_ok);  //uadev
						if( AOM_ask_value_string(childbomline,"bl_Design Revision_t5_PrtCatCode",&ChildCompCode)!=ITK_ok);	//UAPROD

						printf("\n\n Child:::::[%s]    ColourInd:[%s]  CompCode:[%s]  ",ChildItem, ChildColInd, ChildCompCode); fflush(stdout);

						//if ((tc_strcmp(ChildColInd,"Y")==0) && (strlen(ChildCompCode)>0) && ((tc_strstr(ChildCompCode,"CCA")==NULL)||(tc_strstr(ChildCompCode,"VEHICLE")==NULL)||(tc_strstr(ChildCompCode,"TPL")==NULL)))
						if ((tc_strcmp(ChildColInd,"Y")==0) && (strlen(ChildCompCode)>0) && ((tc_strstr(ChildCompCode,"CCA")==NULL)&&(tc_strstr(ChildCompCode,"VEHICLE")==NULL)&&(tc_strstr(ChildCompCode,"TPL")==NULL)))
						{
							printf(" ---> Calling expansion funtion..."); fflush(stdout);
							ValMultiLvlBomForScheme_CL(childbomline, SchmRefTag, CmpCodesOfClrSchm, CmpCnt, SchemeNm, SchemeRev,CLTaskDmlTag);
						}
					}
				}
			}

			if (no_bom_lines > 0)
			{
				MEM_free (child_bom_lines);
			}
		}
	}

	MEM_free (name);
}
int ValColAndNonColBomForRevise_CL(tag_t NonClrRev,tag_t Clrrev,int ColRevRlzStatus, tag_t ColSchmRevTag)
{
	int ifail = ITK_ok;
	int no_bom_linesN, jnc=0;
	int no_bom_linesC, jc=0;
	int FlagchildPresentInBom=0;
	int FlagBomDiff=0;
	int Cmpcount2, k2, CompCodeMatchFlag=0;

	tag_t windowNC=NULLTAG;
	tag_t windowClr=NULLTAG;
	tag_t rule = NULLTAG;
	tag_t ruleClr = NULLTAG;
	tag_t top_lineNC = NULLTAG;
	tag_t top_lineClr = NULLTAG;
	tag_t CmpCodeObj2 = NULLTAG;

	tag_t *child_bom_linesNC = NULLTAG;
	tag_t *child_bom_linesC = NULLTAG;
	tag_t *CmpCodeOfClrScheme2 = NULLTAG;

	char *child_item_idN = NULL;
	char *child_item_idN2 = NULL;
	char *ChildRevSeqN = NULL;
	char *ChildColIndN = NULL;
	char *child_item_idC = NULL;
	char *ChildRevSeqC = NULL;
	char *ChildColIndC = NULL;
	char *CmpCodeCmp2 = NULL;
	char *t5ClSrl = NULL;
	char *Suffix = NULL;
	char *ColourID = NULL;
	char *ChildNCCompCode = NULL;
	child_item_idN2=(char *) MEM_alloc(50);

	ifail = BOM_create_window (&windowNC);
	ifail = BOM_create_window (&windowClr);
	ifail = CFM_find("ERC Review And Above", &rule);	//Non-colour
	ifail = BOM_set_window_config_rule(windowNC, rule);	//Non-colour
	ifail = BOM_set_window_top_line(windowNC, null_tag, NonClrRev, null_tag, &top_lineNC);
	ifail = BOM_window_show_suppressed(windowNC);
	ifail = BOM_line_ask_child_lines(top_lineNC, &no_bom_linesN, &child_bom_linesNC);
	//colour
	if (ColRevRlzStatus==1)
	{
		ifail = CFM_find( "Color ERC release and above", &ruleClr );//colour
	}
	else
	{
		ifail = CFM_find( "Color ERC Review and above", &ruleClr );//colour
	}
	ifail = BOM_set_window_config_rule( windowClr, ruleClr );
	ifail = BOM_set_window_top_line (windowClr, null_tag, Clrrev, null_tag, &top_lineClr);
	ifail = BOM_window_show_suppressed ( windowClr );
	ifail = BOM_line_ask_child_lines (top_lineClr, &no_bom_linesC, &child_bom_linesC);

	printf("\n\t no_bom_linesN: %d   no_bom_linesC: %d",no_bom_linesN,no_bom_linesC);fflush(stdout);
	FlagBomDiff=0;
	for (jnc = 0; jnc < no_bom_linesN; jnc++) //Non-Colour Bom loop
	{
		ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_item_item_id",&child_item_idN);
		if (strstr(child_item_idN,"_")!=NULL)
		{
			continue;
		}
		if (strcmp(subString(child_item_idN,0,1),"G")==0)
		{
			continue;
		}

		ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_rev_item_revision_id",&ChildRevSeqN);
		//ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndN);
		ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_Design Revision_t5_ColourInd",&ChildColIndN);

		printf("\n\t A--jnc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jnc,child_item_idN,ChildRevSeqN,ChildColIndN);fflush(stdout);

		strcpy(child_item_idN2,"");
		tc_strcpy(child_item_idN2,child_item_idN);
		CompCodeMatchFlag==0;
		if (strcmp(ChildColIndN,"Y")==0)
		{
			ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_T5_ClrPartRevision_t5_PrtCatCode",&ChildNCCompCode);
			if (SchmWithCmpcdRel != NULLTAG)
			{
				ifail = GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel, &Cmpcount2, &CmpCodeOfClrScheme2);
				printf("\n\t\t MultilevelExpantion Comp Code count from Color Scheme is : %d",Cmpcount2); fflush(stdout);
				if(Cmpcount2 > 0)
				{
					for (k2=0;k2<Cmpcount2 ;k2++ )
					{
						if(CmpCodeObj2) CmpCodeObj2=NULLTAG;
						CmpCodeObj2=CmpCodeOfClrScheme2[k2];
						ifail = AOM_ask_value_string(CmpCodeObj2, "t5_PrtCatCode", &CmpCodeCmp2 );
						//printf("\n\t\t CmpCodeCmp2 & ChildNCCompCode status--> : [%s]==[%s]",CmpCodeCmp2,ChildNCCompCode); fflush(stdout);
						if(tc_strcmp(ChildNCCompCode,CmpCodeCmp2)==0)
						{
							printf(" -- Match Found compcode "); fflush(stdout);
							CompCodeMatchFlag=1;
							ifail = AOM_ask_value_string(CmpCodeObj2, "t5_ClSrl", &t5ClSrl );
							Suffix =  strtok(t5ClSrl,";");
							ColourID  =  strtok(NULL,";");

							tc_strcat(child_item_idN2,Suffix);

							break;
						}
					}
				}
			}
		}
			FlagchildPresentInBom=0;
			for (jc = 0; jc < no_bom_linesC; jc++)
			{
				//ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndC);
				ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_Design Revision_t5_ColourInd",&ChildColIndC);

				//if ((strcmp(ChildColIndC,"Y")==0)||(strcmp(ChildColIndC,"C")==0))
				//{
					ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_item_item_id",&child_item_idC);
					if (strstr(child_item_idC,"_")!=NULL)
					{
						continue;
					}
					if (strcmp(subString(child_item_idC,0,1),"G")==0)
					{
						continue;
					}

					ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_rev_item_revision_id",&ChildRevSeqC);

					printf("\n\t A--jc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jc,child_item_idC,ChildRevSeqC,ChildColIndC);fflush(stdout);

					//if ((strstr(child_item_idC,child_item_idN)!=NULL) && ((strcmp(ChildColIndC,"C")==0)||(strcmp(ChildColIndC,"N")==0)||(strcmp(ChildColIndC,"Y")==0)))
					//if (strstr(child_item_idC,child_item_idN)!=NULL)

					printf("\n\t\t child_item_idC: %s  child_item_idN: %s   child_item_idN2: %s  ",child_item_idC,child_item_idN,child_item_idN2);fflush(stdout);
					if (strstr(child_item_idC,child_item_idN)!=NULL)
					{
						if (strcmp(child_item_idC,child_item_idN2)==0)
						{
							FlagchildPresentInBom=1;
							break;
						}
					}
				//}
			}
			if (FlagchildPresentInBom==0)
			{
				FlagBomDiff++;
			}
			printf(" -- FlagchildPresentInBom: %d  FlagBomDiff: %d",FlagchildPresentInBom,FlagBomDiff); fflush(stdout);
		//}
	}
	printf("\n\t A--FlagBomDiff: %d",FlagBomDiff);fflush(stdout);
	if (FlagBomDiff==0)
	{
		for (jc = 0; jc < no_bom_linesC; jc++) //Colour Bom loop
		{
			ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_T5_ClrPartRevision_t5_ColourInd",&ChildColIndC);
			ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_item_item_id",&child_item_idC);
			if (strstr(child_item_idC,"_")!=NULL)
			{
				continue;
			}
			if (strcmp(subString(child_item_idC,0,1),"G")==0)
			{
				continue;
			}

			ifail = AOM_ask_value_string( child_bom_linesC[jc] ,"bl_rev_item_revision_id",&ChildRevSeqC);
			printf("\n\t B--jc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jc,child_item_idC,ChildRevSeqC,ChildColIndC);fflush(stdout);

			FlagchildPresentInBom=0;
			for (jnc = 0; jnc < no_bom_linesN; jnc++)
			{
				ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_item_item_id",&child_item_idN);
				if (strstr(child_item_idN,"_")!=NULL)
				{
					continue;
				}
				if (strcmp(subString(child_item_idN,0,1),"G")==0)
				{
					continue;
				}

				ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"bl_rev_item_revision_id",&ChildRevSeqN);
				ifail = AOM_ask_value_string( child_bom_linesNC[jnc] ,"10/20/2020_ColourInd",&ChildColIndN);

				printf("\n\t B--jnc: %d  \t ColItem_id: %s  ChildRevSeqC: %s   Colour_Indicator: %s  ",jnc,child_item_idN,ChildRevSeqN,ChildColIndN);fflush(stdout);

				if (strstr(child_item_idC,child_item_idN)!=NULL)
				{
					FlagchildPresentInBom=1;
					break;
				}

			}
			if (FlagchildPresentInBom==0)
			{
				FlagBomDiff++;
			}
		}
	}
	printf("\n\t In ValColAndNonColBomAttrForRevise function,  FlagBomDiff: %d",FlagBomDiff);fflush(stdout);

	/*if (FlagBomDiff==0)
	{
		if (SchmWithCmpcdRel != NULLTAG)
		{
			ifail = GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel, &Cmpcount2, &CmpCodeOfClrScheme2);
			printf("\n\t\t MultilevelExpantion Comp Code count from Color Scheme is : %d\n\n",Cmpcount2); fflush(stdout);
			if(Cmpcount2 > 0)
			{
				for (k2=0;k2<Cmpcount2 ;k2++ )
				{
					if(CmpCodeObj2) CmpCodeObj2=NULLTAG;
					CmpCodeObj2=CmpCodeOfClrScheme2[k2];
					ifail = AOM_ask_value_string(CmpCodeObj2, "t5_PrtCatCode", &CmpCodeCmp2 );
					printf("\n CmpCodeCmp2 & t5PrtCatCd status--> : %s-%s\n",CmpCodeCmp2,t5PrtCatCd); fflush(stdout);
					//if(tc_strcmp(t5PrtCatCd,CmpCodeCmp2)==0)
					//{
					//	ClrGrpPartPresentFlag=0;
					//	ifail = AOM_ask_value_string(CmpCodeObj, "t5_ClSrl", &t5ClSrl );
					//	Suffix =  strtok(t5ClSrl,";");
					//	ColourID  =  strtok(NULL,";");
					//}
				}
			}
		}
	}*/

	return FlagBomDiff;
}

int ProcessColourScheme2(char *ColPartNo, tag_t latestClrRev, char *ClrschemeStr, tag_t RefschmTag)
{
	int resultColSchm, co = 0;
	int status_count, rs, RlzRevFlag = 0;
	int SchmRevsCnt, c2 = 0;
	int Cmpcount, g1 = 0;
	int SchmMatchFlag=0;

	char *qry_entries4[1] = {"ID"};
	char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));

	char *qry_entries5[1] = {"Colour ID"};
	char **valuesColID = (char **) MEM_alloc(1 * sizeof(char *));

	char *ColPrtSrl = NULL;
	char *CompCode = NULL;
	char *ColSchm_name = NULL;
	char *ColSchmRlzSt = NULL;
	char *t5objectStr = NULL;
	char *SchmCmpCode = NULL;
	char *t5ClSrl = NULL;
	char *Suffix = NULL;
	char *ColourID = NULL;
	char *SchmDesc = NULL;
	char *SchmClrSrl = NULL;
	char *SchmSuffix = NULL;
	char *SchmColourID = NULL;

	tag_t *ColSchme_tags = NULLTAG;
	tag_t *SchmRevisions = NULLTAG;
	tag_t *relStatus_list = NULLTAG;
	tag_t *CmpCodeOfClrScheme = NULLTAG;

	tag_t ColorSchemetag = NULLTAG;
	tag_t ColSchmRevTag = NULLTAG;
	tag_t ColSchmTypeTag = NULLTAG;
	tag_t CmpCodeObjTag = NULLTAG;

	ColPrtSrl = (char *) MEM_alloc(3 * sizeof(char));

	ColPrtSrl=subString(ColPartNo,strlen(ColPartNo)-2,strlen(ColPartNo));

	printf("\n ProcessColourScheme2==ColPartNo: %s   strlen(ColPartNo): %d   ColPrtSrl: [%s]",ColPartNo,strlen(ColPartNo),ColPrtSrl);fflush(stdout);
	fprintf(fpCLLog,"\n ProcessColourScheme2==ColPartNo: %s   strlen(ColPartNo): %d   ColPrtSrl: [%s]",ColPartNo,strlen(ColPartNo),ColPrtSrl);fflush(fpCLLog);

	if( AOM_ask_value_string(latestClrRev,"t5_PrtCatCode",&CompCode)!=ITK_ok);
	printf(" CompCode: [%s]",CompCode);fflush(stdout);
	fprintf(fpCLLog," CompCode: [%s]",CompCode);fflush(fpCLLog);

	/*if (RefschmTag==NULLTAG)
	{
		valuesColSchm[0] = ClrschemeStr ;
		if(QRY_execute(SchmqueryTag, 1, qry_entries4, valuesColSchm, &resultColSchm, &ColSchme_tags));
		printf("\n resultColSchm count is-------->  : %d",resultColSchm);fflush(stdout);
		if (resultColSchm > 0)
		{
			for(co = 0; co < resultColSchm; co++)
			{
				printf("\n co: %d ",co);fflush(stdout);

				ColorSchemetag = ColSchme_tags[co];

				//if(TCTYPE_ask_object_type(ColorSchemetag,&ColSchmTypeTag)!=ITK_ok);
				//if(TCTYPE_ask_name(ColSchmTypeTag,ColSchm_name)!=ITK_ok);
				//printf("\t ColSchm_name name------> %s",ColSchm_name);fflush(stdout);

				if(ITEM_ask_latest_rev(ColorSchemetag , &ColSchmRevTag)!=ITK_ok);
				if(AOM_ask_value_string(ColSchmRevTag, "object_string", &t5objectStr)!=ITK_ok);
				printf("\t t5objectStr: %s",t5objectStr); fflush(stdout);

				//int vschmFlag=0;
				//if ((strstr(t5objectStr,"CLRSCM-X4/19/0001")!=NULL) || (strstr(t5objectStr,"CLRSCM-X4/19/0002")!=NULL))
				//{
				//	vschmFlag=1;
				//}
				//if (vschmFlag==0)
				//{
				//	continue;
				//}

				if(WSOM_ask_release_status_list(ColSchmRevTag, &status_count, &relStatus_list)!=ITK_ok);
				printf("\t status_count:: %d",status_count); fflush(stdout);
				if(status_count > 0)
				{
					printf("\t ColSchm Release status:");fflush(stdout);
					for(rs = 0; rs < status_count; rs++)
					{
						if(AOM_ask_name(relStatus_list[rs], &ColSchmRlzSt)==ITK_ok)
						printf("   %s ", ColSchmRlzSt);fflush(stdout);
						if ((tc_strcmp(ColSchmRlzSt,"T5_LcsErcRlzd")==0) || (tc_strcmp(ColSchmRlzSt,"ERC Released")==0) )
						{
							RlzRevFlag=1;
							break;
						}
						else
						{
							if(ITEM_list_all_revs (ColorSchemetag, &SchmRevsCnt, &SchmRevisions));
						}
					}
				}
				else
				{
					printf("\t ----No Release status on ColSchm, hence skipping ...");fflush(stdout);
					continue;
				}
			}
		}
	}
	else
	{*/
		ColSchmRevTag=RefschmTag;
	//}

	if ((SchmWithCmpcdRel!=NULLTAG) && (ColSchmRevTag!=NULLTAG))
	{
		if(GRM_list_secondary_objects_only(ColSchmRevTag, SchmWithCmpcdRel, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok);
		printf("\n\n Comp Code Cmpcount for Color Scheme: %d \n",Cmpcount); fflush(stdout);
		fprintf(fpCLLog,"\n\n Comp Code Cmpcount for Color Scheme: %d \n",Cmpcount); fflush(fpCLLog);

		if(Cmpcount > 0)
		{
			//if(AOM_ask_value_string(ColSchmRevTag, "t5_ClSchmDesc", &SchmDesc)!=ITK_ok);
			//if(AOM_ask_value_string(ColSchmRevTag, "t5_ClSrl", &SchmClrSrl)!=ITK_ok);

			//if(tc_strstr(SchmClrSrl,";")!=NULL)
			//{
			//	SchmSuffix =  strtok(SchmClrSrl,";");
			//	SchmColourID  =  strtok(NULL,";");
			//}
			//else
			//{
			//	SchmSuffix =  strtok(SchmClrSrl,",");
			//	SchmColourID  =  strtok(NULL,",");
			//}
			//printf("\n\n Comp Code Cmpcount for Color Scheme: %d   SchmColourID: [%s]\n",Cmpcount,SchmColourID); fflush(stdout);
			fprintf(fpCLLog,"\n\n Comp Code Cmpcount for Color Scheme: %d   SchmColourID: [%s]\n",Cmpcount,SchmColourID); fflush(fpCLLog);

			//if (strlen(SchmColourID)>0)
			//{
				for(g1=0;g1<Cmpcount;g1++)
				{
					if(CmpCodeObjTag) CmpCodeObjTag=NULLTAG;

					CmpCodeObjTag=CmpCodeOfClrScheme[g1];

					if(AOM_ask_value_string(CmpCodeObjTag, "t5_PrtCatCode", &SchmCmpCode )!=ITK_ok);
					if(AOM_ask_value_string(CmpCodeObjTag, "t5_ClSrl", &t5ClSrl )!=ITK_ok);

					if(tc_strstr(t5ClSrl,";")!=NULL)
					{
						Suffix =  strtok(t5ClSrl,";");
						ColourID  =  strtok(NULL,";");
						//printf("\n\t\t CM=Suffix --> : %s",Suffix); fflush(stdout);
						//printf("\n\t\t CM=ColourID --> : %s",ColourID); fflush(stdout);
					}
					else
					{
						Suffix =  strtok(t5ClSrl,",");
						ColourID  =  strtok(NULL,",");
						//printf("\n\t\t CM=Suffix --> : %s",Suffix); fflush(stdout);
						//printf("\n\t\t CM=ColourID --> : %s",ColourID); fflush(stdout);
					}

					printf("\n%s, %s, %s,",SchmCmpCode,Suffix,ColourID); fflush(stdout);
					fprintf(fpCLLog,"\n%s, %s, %s,",SchmCmpCode,Suffix,ColourID); fflush(fpCLLog);
					if ((strcmp(CompCode,SchmCmpCode)==0) && (strcmp(ColPrtSrl,Suffix)==0))
					{
						SchmMatchFlag=1;
						break;
					}
				}
			//} //End of if (strlen(SchmColourID)>0)
		}
		else
		{
			printf("\n\t\t CL=Comp Code are not attached to Color Scheme : %s , hence skipping ??? \n\n",ClrschemeStr); fflush(stdout);
			fprintf(fpCLLog,"\n\t\t CL=Comp Code are not attached to Color Scheme : %s , hence skipping ??? \n\n",ClrschemeStr); fflush(fpCLLog);
		}
	}
	else
	{
		printf("\n\t\t CL=In Else, hence skipping ??? \n\n"); fflush(stdout);
		fprintf(fpCLLog,"\n\t\t CL=In Else, hence skipping ??? \n\n"); fflush(fpCLLog);
	}

	return SchmMatchFlag;
}

int tm_ProcessColourPartCL(int taskCnt, tag_t *DmlTaskTags, tag_t Dml_task, int NCAssyChildFlag, tag_t NonClrPartTag, char *NewColourPart, char *DMLProject)
{
	int co, rs, RlzRevFlag=0;
	int status_count=0;
	int RlzStatusCnt , ss =0;
	int n_ClrPrt_tags, ColRlzStatusCnt, ss2, n_ClrChild_tags=0;
	int n_attchs , st = 0;
	int no_bom_lines, j = 0;
	int ncItem_count=0 , ik=0 , relRev2Flag = 0;
	int NonClrChildCnt=0, nc=0, NonClrPrevChildCnt, ncp = 0;
	int childNotExitFlag=0;
	int SchmRevCnt=0, sc=0, SchmRevRlzFlag=0;
	int ClrCount=0, zp=0, ColRlzRevFlag, zp1 =0;
	int Cmpcount=0, g1=0, MatchColSchemeFlag = 0;
	int nc2=0, NClrQty=0, p2=0, nc3=0;
	int colPrtCnt=0;

	tag_t *ClrPrtTags = NULLTAG;
	tag_t *Col_Rlz_St_list = NULLTAG;
	tag_t *sec_objects = NULLTAG;
	tag_t *relStatus_list = NULLTAG;
	tag_t *child_bom_lines = NULLTAG;
	tag_t *ncRev_list = NULLTAG;
	tag_t *NonClrChilds = NULLTAG;
	tag_t *NonClrPrevChilds = NULLTAG;
	tag_t *SchmRev_list = NULLTAG;
	tag_t *ClrPart_tag = NULLTAG;
	tag_t *CmpCodeOfClrScheme = NULLTAG;
	tag_t *ClrChildTags = NULLTAG;
	tag_t *ColPrtUniqTags = NULLTAG;

	tag_t NonClrItemMstrTag = NULLTAG;
	tag_t NonClrItemRevTag = NULLTAG;
	tag_t ColorSchemetag = NULLTAG;
	tag_t ColSchmTypeTag = NULLTAG;
	tag_t ColSchmRevTag = NULLTAG;
	tag_t CmpCodeObjTag = NULLTAG;
	tag_t ColItemTag = NULLTAG;
	tag_t ColorRevTag = NULLTAG;
	tag_t NewColorRevTag = NULLTAG;
	tag_t ReltnExist = NULLTAG;
	tag_t reltask = NULLTAG;
	tag_t secObjTypeTag	= NULLTAG;
	tag_t top_line = NULLTAG;
	tag_t ColChilditemMstr = NULLTAG;
	tag_t ColChilditemRev = NULLTAG;
	tag_t Child_item_revTag = NULLTAG;
	tag_t tPrevRelationExist = NULLTAG;
	tag_t tRelationExist = NULLTAG;
	tag_t tRelationExist1 = NULLTAG;
	tag_t Rel_task = NULLTAG;
	tag_t NClrItemMstrTag = NULLTAG;
	tag_t NonClrPrtPrevRevTag = NULLTAG;
	tag_t windowNonClr = NULLTAG;
	tag_t top_lineNonClr = NULLTAG;
	tag_t windowNonClrPrev = NULLTAG;
	tag_t top_lineNonClrPrev = NULLTAG;
	tag_t latestClrRev = NULLTAG;
	tag_t Childobject = NULLTAG;
	tag_t NClrChildobject = NULLTAG;
	tag_t NCChildItemTag = NULLTAG;
	tag_t ClrItemMstrTag = NULLTAG;
	tag_t ClrItemRevTag = NULLTAG;

	char* Part_no = NULL;
	char* Col_Ind = NULL;
	char* Comp_Code = NULL;
	char* PartType = NULL;
	char* RevSeqTmp = NULL;
	char* RevStr = NULL;
	char* SeqStr = NULL;
	char* LatestRlzSt = NULL;
	char* ColPartNo = NULL;
	char* ColPartRev = NULL;
	char* ColPrtRelSt = NULL;

	char type_name2[TCTYPE_name_size_c+1];

	char *Clrscheme = NULL;
	char *CpyClrscheme = NULL;
	char *ClSrlName=NULL;
	char *ClSuffix=NULL;
	char* SchmName=NULL;
	char* SchmRev=NULL;
	char* SchmRel_status=NULL;
	char *ColSchmRlzSt = NULL;
	char *SchmCmpCode = NULL;
	char *t5ClSrl = NULL;
	char *Suffix=NULL;
	char *ColourID=NULL;
	char *ColPrtLatestRlzSt=NULL;
	char *NewColPartRevSeq=NULL;
	char *ChildRevSeq = NULL;
	char *ChildColInd = NULL;
	char *Part_noLatest = NULL;
	char *RevSeqTmpLatest = NULL;
	char *ncPartno=NULL;
	char *ncPartRev=NULL;
	char *ncRel_status=NULL;
	char *NPrtLatestRlzSt=NULL;
	char *NCRevChild=NULL;
	char *NCPrevRevChild=NULL;
	char *NCChild = NULL;
	char *NCChildRevSeq = NULL;
	char *NCChildColInd = NULL;
	char *NCChildCompCode = NULL;
	char *NCChildQty = NULL;
	tag_t ruleRev = NULLTAG;

	char *NonClrChildSet=NULL;
	char *ClrAssySet=NULL;
	char *DMLNo=NULL;
	char *sTaskName=NULL;
	char *SchTok=NULL;
	char *govClassification=NULL;

	tag_t queryds = NULLTAG;
	char *qry_entriesds[1] = {"ID"};
	char **qry_valuesds = (char **) MEM_alloc(50 * sizeof(char *));
	int n_entries = 1;
	int TaskClSet =0;
	tag_t	*TaskClTag	= NULLTAG;

	char *qry_entries4[1] = {"ID"};
	char *qry_entries[1] = {"ID"};
	char **valuesColSchm = (char **) MEM_alloc(1 * sizeof(char *));
	char **valuesClrPrt = (char **) MEM_alloc(1 * sizeof(char *));
	char ColSchm_name[TCTYPE_name_size_c+1];

	NonClrChildSet = (char *) MEM_alloc(10000 * sizeof(char));
	DMLNo = (char *) MEM_alloc(20 * sizeof(char));
	t5ClSrl = (char*) malloc(50);

	if(AOM_ask_value_string(NonClrPartTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
	if(AOM_ask_value_string(NonClrPartTag,"item_revision_id",&RevSeqTmp)!=ITK_ok)PrintErrorStack();
	printf("\n\t Part_no: [%s,%s]",Part_no,RevSeqTmp); fflush(stdout);
	fprintf(fpCLLog,"\n\t Part_no: [%s,%s]",Part_no,RevSeqTmp); fflush(fpCLLog);

	if(AOM_ask_value_string(NonClrPartTag,"t5_ColourInd",&Col_Ind)!=ITK_ok)PrintErrorStack();
	printf("  Col_Ind: [%s]",Col_Ind);	fflush(stdout);
	fprintf(fpCLLog,"  Col_Ind: [%s]",Col_Ind);	fflush(fpCLLog);

	if(AOM_ask_value_string(NonClrPartTag,"t5_PrtCatCode",&Comp_Code)!=ITK_ok)PrintErrorStack();
	printf("  Comp_Code: [%s]",Comp_Code);	fflush(stdout);
	fprintf(fpCLLog,"  Comp_Code: [%s]",Comp_Code);	fflush(fpCLLog);

	if(AOM_ask_value_string(NonClrPartTag, "t5_PartType", &PartType)!=ITK_ok)PrintErrorStack();
	printf("  PartType: [%s]",PartType);	fflush(stdout);
	fprintf(fpCLLog,"  PartType: [%s]",PartType);	fflush(fpCLLog);

	if(ITEM_find_item(Part_no, &NonClrItemMstrTag)!=ITK_ok)PrintErrorStack();
	if(ITEM_ask_latest_rev(NonClrItemMstrTag,&NonClrItemRevTag)!=ITK_ok)PrintErrorStack();
	if(AOM_ask_value_string(NonClrItemRevTag,"item_id",&Part_noLatest)!=ITK_ok)PrintErrorStack();
	if(AOM_ask_value_string(NonClrItemRevTag,"item_revision_id",&RevSeqTmpLatest)!=ITK_ok)PrintErrorStack();

	if(tc_strcmp(Col_Ind,"Y")==0)
	{
		int n_entries11 =2;
		tag_t CntlObj_Qtag11 = NULLTAG;
		char *qry_entries11[2] = {"SYSCD","SUBSYSCD"};
		char **qry_values11 = (char **) MEM_alloc(50 * sizeof(char *));
		int CntrlObjCntCL=0;
		int CntrlObjCntCCA=0;
		tag_t *qry_cntrlobj11= NULLTAG;
		tag_t *qry_cntrlobjCCA= NULLTAG;

		if(QRY_find("Control Objects...", &CntlObj_Qtag11)!=ITK_ok)PrintErrorStack();
		if (CntlObj_Qtag11!=NULLTAG)
		{
			qry_values11[0] = "CLClrT";
			qry_values11[1] = "MultiLvlExp";
			if(QRY_execute(CntlObj_Qtag11, n_entries11, qry_entries11, qry_values11, &CntrlObjCntCL, &qry_cntrlobj11)!=ITK_ok)PrintErrorStack();

			qry_values11[0] = "CLClrT";
			qry_values11[1] = "MultiLvlExpCCA";
			if(QRY_execute(CntlObj_Qtag11, n_entries11, qry_entries11, qry_values11, &CntrlObjCntCCA, &qry_cntrlobjCCA)!=ITK_ok)PrintErrorStack();
		}
		printf("\n Control Object count for CL Task [CntrlObjCntCL: %d]   [CntrlObjCntCCA: %d]  \n",CntrlObjCntCL,CntrlObjCntCCA);fflush(stdout);


		if(WSOM_ask_release_status_list(NonClrPartTag, &RlzStatusCnt, &relStatus_list)!=ITK_ok)PrintErrorStack();
		printf("  RlzStatusCnt: %d",RlzStatusCnt);	fflush(stdout);
		fprintf(fpCLLog,"  RlzStatusCnt: %d",RlzStatusCnt);	fflush(fpCLLog);

		if (RlzStatusCnt > 0)
		{
			RlzRevFlag=0;
			for(ss=0; ss<RlzStatusCnt ; ss++)
			{
				if(AOM_ask_value_string(relStatus_list[ss],"object_name",&LatestRlzSt)!=ITK_ok)PrintErrorStack();
				printf("  LatestRlzSt: %s",LatestRlzSt);fflush(stdout);
				fprintf(fpCLLog,"  LatestRlzSt: %s",LatestRlzSt);fflush(fpCLLog);

				//if((tc_strcmp(LatestRlzSt,"ERC Released")==0) || (tc_strcmp(LatestRlzSt,"T5_LcsErcRlzd")==0))
				if(tc_strcmp(LatestRlzSt,"T5_LcsReview")==0)
				{
					RlzRevFlag=1;

					//Get child from BOM of latest released and previous released revision---START------
					tc_strcpy(NonClrChildSet,"");
					NonClrChildCnt=0;
					NonClrPrevChildCnt=0;
					NonClrPrtPrevRevTag=NULLTAG;

					if (tc_strstr(RevSeqTmp,"NR;")==NULL)	//Current Rev is NR hence not querying previous revision
					{
						if(ITEM_list_all_revs (NonClrItemMstrTag, &ncItem_count, &ncRev_list)!=ITK_ok)PrintErrorStack();
						printf("\n\t CL=ncItem_count::%d:\n\t", ncItem_count);fflush(stdout);
						fprintf(fpCLLog,"\n\t CL=ncItem_count::%d:\n\t", ncItem_count);fflush(fpCLLog);

						if(ncItem_count > 0)
						{
							//relRev2Flag = 0;
							for(ik=ncItem_count-1;ik>=0;ik--)
							{
								if(AOM_UIF_ask_value(ncRev_list[ik], "item_id", &ncPartno)!=ITK_ok)PrintErrorStack();
								if(AOM_UIF_ask_value(ncRev_list[ik], "item_revision_id", &ncPartRev)!=ITK_ok)PrintErrorStack();
								if(AOM_UIF_ask_value (ncRev_list[ik], "release_status_list", &ncRel_status)!=ITK_ok)PrintErrorStack();
								if((tc_strstr(ncRel_status,"ERC Released")!=NULL)||(tc_strstr(ncRel_status,"T5_LcsErcRlzd")!=NULL))
								{
									printf("  ncPartno=%s:%s:--", ncPartno,ncPartRev);fflush(stdout);
									fprintf(fpCLLog,"  ncPartno=%s:%s:--", ncPartno,ncPartRev);fflush(fpCLLog);
									NonClrPrtPrevRevTag=ncRev_list[ik];
									break;
								}
							}
						}
					}

					if(BOM_create_window(&windowNonClr)!=ITK_ok)PrintErrorStack();
					if(CFM_find("ERC Review And Above", &ruleRev)!=ITK_ok)PrintErrorStack();
					if(BOM_set_window_top_line(windowNonClr, null_tag, NonClrPartTag, null_tag, &top_lineNonClr)!=ITK_ok)PrintErrorStack();
					if(BOM_window_show_suppressed(windowNonClr)!=ITK_ok)PrintErrorStack();
					if(BOM_set_window_pack_all(windowNonClr, true)!=ITK_ok)PrintErrorStack();
					if(BOM_set_window_config_rule(windowNonClr, ruleRev)!=ITK_ok)PrintErrorStack();
					if(BOM_line_ask_child_lines(top_lineNonClr, &NonClrChildCnt, &NonClrChilds)!=ITK_ok)PrintErrorStack();

					if (NonClrPrtPrevRevTag!=NULLTAG)
					{
						if(BOM_create_window(&windowNonClrPrev)!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_top_line(windowNonClrPrev, null_tag, NonClrPrtPrevRevTag, null_tag, &top_lineNonClrPrev)!=ITK_ok)PrintErrorStack();
						if(BOM_window_show_suppressed(windowNonClrPrev)!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_pack_all(windowNonClrPrev, true)!=ITK_ok)PrintErrorStack();
						if(BOM_set_window_config_rule(windowNonClrPrev, ruleNC)!=ITK_ok)PrintErrorStack();
						if(BOM_line_ask_child_lines(top_lineNonClrPrev, &NonClrPrevChildCnt, &NonClrPrevChilds)!=ITK_ok)PrintErrorStack();

						for (nc = 0; nc < NonClrChildCnt; nc++)
						{
							childNotExitFlag=0;
							if(AOM_ask_value_string( NonClrChilds[nc] ,"bl_item_item_id",&NCRevChild)!=ITK_ok)PrintErrorStack();
							for (ncp = 0; ncp < NonClrPrevChildCnt; ncp++)
							{
								if(AOM_ask_value_string( NonClrPrevChilds[ncp] ,"bl_item_item_id",&NCPrevRevChild)!=ITK_ok)PrintErrorStack();

								if (tc_strcmp(NCRevChild,NCPrevRevChild)==0)
								{
									childNotExitFlag=1;
									break;
								}
							}
							if (childNotExitFlag==0)
							{
								if (strlen(NonClrChildSet)==0)
								{
									tc_strcpy(NonClrChildSet,NCRevChild);
									tc_strcat(NonClrChildSet,",");
								}
								else if (tc_strstr(NonClrChildSet,NCRevChild)==NULL)
								{
									tc_strcat(NonClrChildSet,NCRevChild);
									tc_strcat(NonClrChildSet,",");
								}
							}
						} //End of loop NonClrChildCnt

						if (strlen(NonClrChildSet)==0)
						{
							for (ncp = 0; ncp < NonClrPrevChildCnt; ncp++)
							{
								childNotExitFlag=0;
								if(AOM_ask_value_string( NonClrPrevChilds[ncp] ,"bl_item_item_id",&NCPrevRevChild)!=ITK_ok)PrintErrorStack();
								for (nc = 0; nc < NonClrChildCnt; nc++)
								{
									if(AOM_ask_value_string( NonClrChilds[nc] ,"bl_item_item_id",&NCRevChild)!=ITK_ok)PrintErrorStack();
									if (tc_strcmp(NCRevChild,NCPrevRevChild)==0)
									{
										childNotExitFlag=1;
										break;
									}
								}
								if (childNotExitFlag==0)
								{
									if (strlen(NonClrChildSet)==0)
									{
										tc_strcpy(NonClrChildSet,NCRevChild);
										tc_strcat(NonClrChildSet,",");
									}
									else if (tc_strstr(NonClrChildSet,NCRevChild)==NULL)
									{
										tc_strcat(NonClrChildSet,NCRevChild);
										tc_strcat(NonClrChildSet,",");
									}
								}
							} //End of loop NonClrPrevChildCnt
						} //End of condn if (strlen(NonClrChildSet)==0)
					}
					printf("\t NonClrChildCnt= %d  NonClrPrevChildCnt= %d  strlen(NonClrChildSet)= %d ",NonClrChildCnt,NonClrPrevChildCnt,strlen(NonClrChildSet)); fflush(stdout);
					fprintf(fpCLLog,"\t NonClrChildCnt= %d  NonClrPrevChildCnt= %d  strlen(NonClrChildSet)= %d ",NonClrChildCnt,NonClrPrevChildCnt,strlen(NonClrChildSet)); fflush(fpCLLog);
					//Get child from BOM of latest released and previous released revision---END------

					// ----------------START-Get Colour Parts-------------------------------------------
					if(tRelationFind!=NULLTAG)
					{
						tag_t ColItemMstrTag = NULLTAG;
						tag_t ColLatestRevTag = NULLTAG;
						tag_t owningUserSchm = NULLTAG;
						int zp2 = 0, ikk=0;
						char useridSchm[SA_user_size_c+1];
						tag_t *ClrPrimObjstag = NULLTAG;
						tag_t ClrPrimObjtag = NULLTAG;
						tag_t class_id = NULLTAG;
						tag_t *TaskPrimObjstag = NULLTAG;
						tag_t TaskPrimObjtag = NULLTAG;
						tag_t Taskclass_id = NULLTAG;
						tag_t SchmRefTag = NULLTAG;
						int ClrPrimObjCnt=0, zk=0, TaskPrimObjCnt=0, zk2=0, ClrDmlFlag=0;
						char *class_name=NULL;
						char *class_name2=NULL;
						char *DMLTaskNo=NULL;
						char *DMLNumber2=NULL;
						char *DMLRlsType=NULL;
						char *ncPartRevNew=NULL;
						char *ncRel_statusNew=NULL;
						tag_t *MatchColSchmsTags = NULLTAG;

						if(NonClrPrtPrevRevTag!=NULLTAG)
						{
							if(GRM_list_primary_objects_only(NonClrPrtPrevRevTag,tRelationFind,&ClrCount,&ClrPart_tag)!=ITK_ok)PrintErrorStack();

							printf("\n\t 1.ClrCount: [%d]  ncItem_count: [%d]",ClrCount,ncItem_count);fflush(stdout);
							fprintf(fpCLLog,"\n\t 1.ClrCount: [%d]  ncItem_count: [%d]",ClrCount,ncItem_count);fflush(fpCLLog);

							if((ClrCount<=0) && (ncItem_count > 0))
							{
								for(ikk=ncItem_count-1;ikk>=0;ikk--)
								{
									tag_t NonClrPrtPrevRevTagNew = NULLTAG;

									NonClrPrtPrevRevTagNew=ncRev_list[ikk];

									if(AOM_UIF_ask_value(NonClrPrtPrevRevTagNew, "item_revision_id", &ncPartRevNew)!=ITK_ok)PrintErrorStack();
									if(AOM_UIF_ask_value (NonClrPrtPrevRevTagNew, "release_status_list", &ncRel_statusNew)!=ITK_ok)PrintErrorStack();

									if((tc_strstr(ncRel_statusNew,"ERC Released")!=NULL)||(tc_strstr(ncRel_statusNew,"T5_LcsErcRlzd")!=NULL))
									{
										printf("\n CL=2.ncPartno=%s:%s:--", Part_no,ncPartRevNew);fflush(stdout);
										fprintf(fpCLLog,"\n CL=2.ncPartno=%s:%s:--", Part_no,ncPartRevNew);fflush(fpCLLog);

										if(NonClrPrtPrevRevTagNew!=NULLTAG)
										{
											if(GRM_list_primary_objects_only(NonClrPrtPrevRevTagNew,tRelationFind,&ClrCount,&ClrPart_tag)!=ITK_ok)PrintErrorStack();
											if(ClrCount>0)
											{
												break;
											}
										}
									}
								}

							}
						}

						printf("\n\t 2.ClrCount: %d",ClrCount);fflush(stdout);
						fprintf(fpCLLog,"\n\t 2.ClrCount: %d",ClrCount);fflush(fpCLLog);

						/*if((tc_strstr(RevSeqTmp,"NR;")!=NULL)&&(ClrCount==0))
						{
						}
						else*/ if(ClrCount>0)
						{
							colPrtCnt=0;
							ClrAssySet = (char *) MEM_alloc(10000 * sizeof(char));
							ColPrtUniqTags = (tag_t *) MEM_alloc(10000 * sizeof(tag_t));
							tc_strcpy(ClrAssySet,"");

							for(zp1=0; zp1<ClrCount; zp1++)
							{
								latestClrRev=ClrPart_tag[zp1];
								if(AOM_ask_value_string(latestClrRev,"item_id",&ColPartNo)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_string(latestClrRev,"item_revision_id",&ColPartRev)!=ITK_ok)PrintErrorStack();

								printf("\n\t %d--ColPartNo: %s/%s",zp1,ColPartNo,ColPartRev);fflush(stdout);
								fprintf(fpCLLog,"\n\t %d--ColPartNo: %s/%s",zp1,ColPartNo,ColPartRev);fflush(fpCLLog);

								if(ITEM_find_item(ColPartNo, &ColItemMstrTag)!=ITK_ok)PrintErrorStack();
								if(ITEM_ask_latest_rev(ColItemMstrTag,&ColLatestRevTag)!=ITK_ok)PrintErrorStack();

								if (strlen(ClrAssySet)==0)
								{
									tc_strcpy(ClrAssySet,ColPartNo);
									tc_strcat(ClrAssySet,",");

									ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
									colPrtCnt=colPrtCnt+1;
								}
								else if (tc_strstr(ClrAssySet,ColPartNo)==NULL)
								{
									tc_strcat(ClrAssySet,ColPartNo);
									tc_strcat(ClrAssySet,",");

									ColPrtUniqTags[colPrtCnt]=ColLatestRevTag;
									colPrtCnt=colPrtCnt+1;
								}
							}

							printf("\n\t Distinct colPrtCnt: %d",colPrtCnt);fflush(stdout);
							fprintf(fpCLLog,"\n\t Distinct colPrtCnt: %d",colPrtCnt);fflush(fpCLLog);
							for(zp = 0; zp<colPrtCnt; zp++)
							{
								int colSchmCnt=0;
								ColRlzRevFlag=0;

								SchmRefTag = NULLTAG;
								MatchColSchmsTags = NULLTAG;
								MatchColSchmsTags = (tag_t *) MEM_alloc(100 * sizeof(tag_t));

								if(latestClrRev!=NULLTAG)
								{
									latestClrRev=NULLTAG;
								}

								latestClrRev=ColPrtUniqTags[zp];

								if(AOM_ask_value_string(latestClrRev,"item_id",&ColPartNo)!=ITK_ok)PrintErrorStack();

								//if (tc_strcmp(ColPartNo,"5442T3Z0168009ZZ")!=0)
								//{
								//	continue;
								//}

								if(AOM_UIF_ask_value (latestClrRev, "release_status_list", &ColPrtRelSt)!=ITK_ok)PrintErrorStack();
								if((tc_strstr(ColPrtRelSt,"ERC Released")!=NULL)||(tc_strstr(ColPrtRelSt,"T5_LcsErcRlzd")!=NULL))
								{
									ColRlzRevFlag=1;
								}
								printf("\n\t ColPrtRelSt: [%s]",ColPrtRelSt);fflush(stdout);
								printf("\n\n =======CL=ColAssy--zp: %d  ColourPart: %s  ColRlzRevFlag: %d  DMLProject:[%s]===============================================\n\n",zp,ColPartNo,ColRlzRevFlag,DMLProject);fflush(stdout);
								fprintf(fpCLLog,"\n\t ColPrtRelSt: [%s]",ColPrtRelSt);fflush(fpCLLog);
								fprintf(fpCLLog,"\n\n =======CL=ColAssy--zp: %d  ColourPart: %s  ColRlzRevFlag: %d  DMLProject:[%s]===============================================\n\n",zp,ColPartNo,ColRlzRevFlag,DMLProject);fflush(fpCLLog);

								if(tc_strstr(ColPrtRelSt,"Obsolete")!=NULL)
								{
									printf(" This colourPart is in 'Obsolete' hence skipping....");fflush(stdout);
									fprintf(fpCLLog," This colourPart is in 'Obsolete' hence skipping....");fflush(fpCLLog);
									continue;
								}

								printf("\n\t DMLProject11111: [%s]",DMLProject);fflush(stdout);
								fprintf(fpCLLog,"\n\t DMLProject11111: [%s]",DMLProject);fflush(fpCLLog);

								//if(tc_strcmp(DMLProject,"5445")==0)
								//{
								//	if(GRM_list_primary_objects_only(latestClrRev,NULLTAG,&ClrPrimObjCnt,&ClrPrimObjstag));
								//	printf("\n\t ClrPrimObjCnt: %d ",ClrPrimObjCnt);fflush(stdout);
								//	fprintf(fpCLLog,"\n\t ClrPrimObjCnt: %d ",ClrPrimObjCnt);fflush(fpCLLog);
								//
								//	ClrDmlFlag=0;
								//	MatchColSchemeFlag=0;
								//
								//	for(zk = 0; zk<ClrPrimObjCnt; zk++)
								//	{
								//		ClrPrimObjtag = ClrPrimObjstag[zk];
								//
								//		if(POM_class_of_instance(ClrPrimObjtag,&class_id));
								//		if(POM_name_of_class(class_id,&class_name));
								//
								//		printf("\n\t class_name: %s",class_name);fflush(stdout);
								//		fprintf(fpCLLog,"\n\t class_name: %s",class_name); fflush(fpCLLog);
								//
								//		if (tc_strcmp(class_name,"T5_ChangeTaskRevision")==0)
								//		{
								//			if(AOM_ask_value_string(ClrPrimObjtag,"item_id",&DMLTaskNo)); //object_string
								//			printf("\n\t CL=DMLTaskNo: %s",DMLTaskNo);fflush(stdout);
								//			fprintf(fpCLLog,"\n\t CL=DMLTaskNo: %s",DMLTaskNo);fflush(fpCLLog);
								//
								//			if(GRM_list_primary_objects_only(ClrPrimObjtag,NULLTAG,&TaskPrimObjCnt,&TaskPrimObjstag));
								//			printf("  TaskPrimObjCnt: %d ",TaskPrimObjCnt);fflush(stdout);
								//			fprintf(fpCLLog,"  TaskPrimObjCnt: %d ",TaskPrimObjCnt);fflush(fpCLLog);
								//
								//			for(zk2 = 0; zk2<TaskPrimObjCnt; zk2++)
								//			{
								//				TaskPrimObjtag = TaskPrimObjstag[zk2];
								//
								//				if(POM_class_of_instance(TaskPrimObjtag,&Taskclass_id));
								//				if(POM_name_of_class(Taskclass_id,&class_name2));
								//				printf("  class_name2: %s",class_name2);fflush(stdout);
								//				fprintf(fpCLLog,"  class_name2: %s",class_name2);fflush(fpCLLog);
								//
								//				if(AOM_ask_value_string(TaskPrimObjtag,"object_string",&DMLNumber2));
								//				printf("  DMLNo: %s",DMLNumber2);fflush(stdout);
								//				fprintf(fpCLLog,"  DMLNo: %s",DMLNumber2);fflush(fpCLLog);
								//
								//				if(AOM_ask_value_string(TaskPrimObjtag,"t5_rlstype",&DMLRlsType));
								//				printf("  DMLRlsType: %s \n",DMLRlsType);fflush(stdout);
								//				fprintf(fpCLLog,"  DMLRlsType: %s \n",DMLRlsType);fflush(fpCLLog);
								//
								//				if ((strcmp(DMLRlsType,"CP")==0)||(strcmp(DMLRlsType,"CM")==0)||(strstr(DMLTaskNo,"CL")!=NULL))
								//				{
								//					ClrDmlFlag=1;
								//					break;
								//				}
								//			}
								//			if (ClrDmlFlag==1)
								//			{
								//				break;
								//			}
								//		}
								//	}
								//
								//	if((ClrDmlFlag==1) && (TaskPrimObjtag!=NULLTAG))
								//	{
								//		tag_t RefRel_tag = NULLTAG;
								//		tag_t RefTypeTag = NULLTAG;
								//		tag_t *RefDoc_tag = NULLTAG;
								//		int Refcount=0, jr=0;
								//		char Reftype_name[TCTYPE_name_size_c+1];
								//		char *ClrSchmNo=NULL;
								//
								//		if(GRM_find_relation_type("IMAN_reference", &RefRel_tag));
								//		if(RefRel_tag!=NULLTAG)
								//		{
								//			if(GRM_list_secondary_objects_only(TaskPrimObjtag,RefRel_tag,&Refcount,&RefDoc_tag));
								//			printf("\n Refcount: %d ",Refcount);fflush(stdout);
								//			fprintf(fpCLLog,"\n Refcount: %d ",Refcount);fflush(fpCLLog);
								//
								//			for (jr=0; jr<Refcount; jr++)
								//			{
								//				SchmRefTag=RefDoc_tag[jr];
								//
								//				if(TCTYPE_ask_object_type(SchmRefTag,&RefTypeTag));
								//				if(TCTYPE_ask_name(RefTypeTag,Reftype_name));
								//				printf("\n Reftype_name: %s ",Reftype_name);fflush(stdout);
								//				fprintf(fpCLLog,"\n Reftype_name: %s ",Reftype_name);fflush(fpCLLog);
								//
								//				if (tc_strcmp(Reftype_name,"T5_clschmRevision")==0)
								//				{
								//					CpyClrscheme=(char *) MEM_alloc(100);
								//
								//					if(AOM_ask_value_string(SchmRefTag,"item_id",&ClrSchmNo));
								//					printf("\t ClrSchmNo: [%s] ",ClrSchmNo);fflush(stdout);
								//					fprintf(fpCLLog,"\t ClrSchmNo: [%s] ",ClrSchmNo);fflush(fpCLLog);
								//
								//					tc_strcpy(CpyClrscheme,ClrSchmNo);
								//
								//					MatchColSchemeFlag = ProcessColourScheme2(ColPartNo,latestClrRev,CpyClrscheme,SchmRefTag);
								//
								//					printf("\t MatchColSchemeFlag: [%d] ",MatchColSchemeFlag);fflush(stdout);
								//					fprintf(fpCLLog,"\t MatchColSchemeFlag: [%d] ",MatchColSchemeFlag);fflush(fpCLLog);
								//
								//					if (MatchColSchemeFlag==1)
								//					{
								//						printf("-------Match Scheme Found ");fflush(stdout);
								//						fprintf(fpCLLog,"-------Match Scheme Found ");fflush(fpCLLog);
								//
								//						MatchColSchmsTags[colSchmCnt]=SchmRefTag;
								//						colSchmCnt=colSchmCnt+1;
								//						//break;
								//					}
								//				}
								//			}
								//		}
								//	}
								//}else if(tc_strcmp(DMLProject,"5442")==0)
								//{
									printf("\n\t DMLProject2222222: [%s]",DMLProject);fflush(stdout);
									fprintf(fpCLLog,"\n\t DMLProject2222222: [%s]",DMLProject);fflush(fpCLLog);

									colSchmCnt=0;
									//MatchColSchemeFlag=0;

									if(AOM_ask_value_string (latestClrRev, "gov_classification", &govClassification));
									printf("\n 2.govClassification----->: %s\n", govClassification); fflush(stdout);
									fprintf(fpCLLog,"\n 2.govClassification----->: %s\n", govClassification); fflush(fpCLLog);

									if ((govClassification!=NULL) && (strstr(govClassification,"#")!=NULL))
									{
										tag_t schemeMasterTag = NULLTAG;

										char* schemeNo=strtok(govClassification,"#");
										char* schemeRev=strtok(NULL,"#");

										char *SchRevSeq = NULL;
										SchRevSeq = NULL;
										SchRevSeq =(char *) MEM_alloc(32);
										strcpy(SchRevSeq ,schemeRev);
										strcat(SchRevSeq ,"*1");

										//strcat(SchRevSeq ,";");
										//strcat(SchRevSeq ,"1");

										printf("  schemeNo: %s  SchRevSeq: %s \n",schemeNo,SchRevSeq );fflush(stdout);
										fprintf(fpCLLog,"  schemeNo: %s  SchRevSeq: %s \n",schemeNo,SchRevSeq );fflush(fpCLLog);

										if(ITEM_find_item(schemeNo, &schemeMasterTag)!=ITK_ok)PrintErrorStack();
										ifail =ITEM_find_revision(schemeMasterTag,SchRevSeq ,&SchmRefTag);

										if (SchmRefTag!=NULLTAG)
										{
											MatchColSchemeFlag = ProcessColourScheme2(ColPartNo,latestClrRev,schemeNo,SchmRefTag);

											printf("\t 2.1122MatchColSchemeFlag: [%d] ",MatchColSchemeFlag);fflush(stdout);
											fprintf(fpCLLog,"\t 2.1122MatchColSchemeFlag: [%d] ",MatchColSchemeFlag);fflush(fpCLLog);
											if (MatchColSchemeFlag==1)
											{
												printf("-------Match Scheme Found ");fflush(stdout);
												fprintf(fpCLLog,"-------Match Scheme Found ");fflush(fpCLLog);

												MatchColSchmsTags[colSchmCnt]=SchmRefTag;
												colSchmCnt=colSchmCnt+1;
												//break;
											}
										}
										else
										{
											printf("\t -------- Scheme is not queried..??");fflush(stdout);
											fprintf(fpCLLog,"\t -------- Scheme is not queried..??");fflush(fpCLLog);
										}
									}
								//}else
								//{
								//	printf("\n\t ColourPart: %s -----No Scheme logic for project [%s] hence continued.....\n",ColPartNo,DMLProject); fflush(stdout);
								//	fprintf(fpCLLog,"\n\t ColourPart: %s -----No Scheme logic for project [%s] hence continued.....\n",ColPartNo,DMLProject); fflush(fpCLLog);
								//	fprintf(fpCLErrLog,"\nColourPart: %s -----No Scheme logic for project [%s] hence continued.....",ColPartNo,DMLProject); fflush(fpCLLog);
								//	continue;
								//}

								printf("\n\t CL=MatchColSchemeFlag: [%d]   colSchmCnt: [%d] ",MatchColSchemeFlag,colSchmCnt);fflush(stdout);
								fprintf(fpCLLog,"\n\t CL=MatchColSchemeFlag: [%d]   colSchmCnt: [%d] ",MatchColSchemeFlag,colSchmCnt);fflush(fpCLLog);

								//if (MatchColSchemeFlag==0)
								if (colSchmCnt==0)
								{
									printf("-------Scheme NOT Found for Color Part = [%s] continuning.........\n",ColPartNo);fflush(stdout);
									fprintf(fpCLLog,"-------Scheme NOT Found for Color Part = [%s] continuning.........\n",ColPartNo);fflush(fpCLLog);
									fprintf(fpCLErrLog,"\nScheme NOT Found for Color Part = [%s] continuning.........",ColPartNo);fflush(fpCLErrLog);
									continue;
								}

								if (colSchmCnt>1)
								{
									printf("\n\t-------more than one match scheme found for Color Part [%s] so continue to next.....\n",ColPartNo);fflush(stdout);
									fprintf(fpCLLog,"\n\t-------more than one match scheme found for Color Part [%s] so continue to next.....\n",ColPartNo);fflush(fpCLLog);
									fprintf(fpCLErrLog,"\nmore than one match scheme found for Color Part [%s] so continue to next.....",ColPartNo);fflush(fpCLErrLog);

									//Add error message for more than one match scheme

									continue;
								}

								// ----------------Colour Scheme-START---------------------------------------------
								SchmRevRlzFlag=0;

								if (SchmRefTag==NULLTAG)
								{
									continue;
								}

								if(AOM_ask_value_string(SchmRefTag, "object_string", &SchmName)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_string(SchmRefTag, "item_revision_id", &SchmRev)!=ITK_ok)PrintErrorStack();

								printf ("\n SchmName: [%s]  SchmRev: [%s] ", SchmName,SchmRev);fflush(stdout);
								fprintf(fpCLLog,"\n SchmName: [%s]  SchmRev: [%s] ", SchmName,SchmRev);fflush(fpCLLog);

								SchTok=strtok(SchmName,";");
								printf ("\n Color Scheme is : %s\n", SchTok);fflush(stdout);
								fprintf(fpCLLog,"\n Color Scheme is : %s\n", SchTok);fflush(fpCLLog);

								if(STRNG_replace_str(SchTok,",","#",&SchDataToGov)!=ITK_ok)PrintErrorStack();
								printf ( "\n SchDataToGov is -------> %s\n",SchDataToGov);fflush(stdout);
								fprintf(fpCLLog,"\n SchDataToGov is -------> %s\n",SchDataToGov);fflush(fpCLLog);

								//if(WSOM_ask_release_status_list(SchmRefTag, &status_count, &relStatus_list)!=ITK_ok)PrintErrorStack();
								//if(status_count > 0)
								//{
								//	for(rs = 0; rs < status_count; rs++)
								//	{
								//		if(AOM_ask_name(relStatus_list[rs], &ColSchmRlzSt)==ITK_ok)
								//		printf("\t ColSchm Release status:%s ", ColSchmRlzSt);fflush(stdout);
								//		if ((tc_strcmp(ColSchmRlzSt,"T5_LcsErcRlzd")==0) || (tc_strcmp(ColSchmRlzSt,"ERC Released")==0) )
								//		{
								//			break;
								//		}
								//	}
								//}

								if(AOM_UIF_ask_value (SchmRefTag, "release_status_list", &SchmRel_status)!=ITK_ok)PrintErrorStack();
								if((tc_strstr(SchmRel_status,"ERC Released")!=NULL)||(tc_strstr(SchmRel_status,"T5_LcsErcRlzd")!=NULL))
								{
									//printf(" --A-SchmRel_status");
									fprintf(fpCLLog," --A-SchmRel_status");
									SchmRevRlzFlag=1;
									fflush(stdout);
								}
								else
								{
									printf(" --B-SchmRel_status"); fflush(stdout);
									fprintf(fpCLLog," --B-SchmRel_status"); fflush(fpCLLog);
									//if(ITEM_list_all_revs (ColorSchemetag, &SchmRevCnt, &SchmRev_list)!=ITK_ok)PrintErrorStack();
									//for(sc = 0; sc < status_count; sc++)
									//{
									//	SchmRefTag=SchmRev_list[sc];
									//	if(AOM_UIF_ask_value (SchmRefTag, "release_status_list", &SchmRel_status)!=ITK_ok)PrintErrorStack();
									//	if((tc_strstr(SchmRel_status,"ERC Released")!=NULL)||(tc_strstr(SchmRel_status,"T5_LcsErcRlzd")!=NULL))
									//	{
									//		SchmRevRlzFlag=1;
									//		break;
									//	}
									//}
								}
								if (SchmRevRlzFlag==0)
								{
									printf("\n  Scheme--co: %d ==>No Revision of scheme Released [%s], hence skipping ??",co,SchmName); fflush(stdout);
									fprintf(fpCLLog,"\n  Scheme--co: %d ==>No Revision of scheme Released [%s], hence skipping ??",co,SchmName); fflush(fpCLLog);
									//continue;
								}
								else if ( (SchmRevRlzFlag==1) && (SchmRefTag!=NULLTAG) )
								{
									//if(AOM_ask_value_string(SchmRefTag, "t5_ClSrl", &ClSrlName)!=ITK_ok)PrintErrorStack();
									//printf("\n\t CL=ClSrlName is --> : %s",ClSrlName); fflush(stdout);
									//
									//ClSuffix=tc_strtok(ClSrlName,";");
									//printf("\n\t CL=ClSuffix => %s ",ClSuffix );fflush(stdout);
									//
									//ClrSchmToVf = (char *) MEM_alloc( 50 * sizeof(char) );
									//strcpy(ClrSchmToVf,"");
									//tc_strcat(ClrSchmToVf,CpyClrscheme);
									//printf ("\n\t CL=ClrSchmToVf-------------------------------------> [%s]\n", ClrSchmToVf); fflush(stdout);

									if (SchmWithCmpcdRel!=NULLTAG)
									{
										if(GRM_list_secondary_objects_only(SchmRefTag, SchmWithCmpcdRel, &Cmpcount, &CmpCodeOfClrScheme)!=ITK_ok)PrintErrorStack();
										printf("\n  CL=Comp Code Cmpcount for Color Scheme: %d",Cmpcount); fflush(stdout);
										fprintf(fpCLLog,"\n  CL=Comp Code Cmpcount for Color Scheme: %d",Cmpcount); fflush(fpCLLog);

										if(Cmpcount > 0)
										{
											int NonClrflag=0;
											t5ClSrl = (char*) malloc(50);
											t5ClSrl = GetColourSrlFrmSchmCompCodes(CmpCodeOfClrScheme,Cmpcount,Comp_Code);
											printf("\n  CL-A=t5ClSrl from function: %s",t5ClSrl); fflush(stdout);
											fprintf(fpCLLog,"\n  CL=t5ClSrl from function: %s",t5ClSrl); fflush(fpCLLog);

											if ((t5ClSrl!=NULL) && (strlen(t5ClSrl)>0))
											{
												if(tc_strstr(t5ClSrl,";")!=NULL)
												{
													Suffix =  strtok(t5ClSrl,";");
													printf("    Suffix --> : %s",Suffix); fflush(stdout);
													fprintf(fpCLLog,"    Suffix --> : %s",Suffix); fflush(fpCLLog);

													ColourID  =  strtok(NULL,";");
													printf("	ColourID --> : %s",ColourID); fflush(stdout);
													fprintf(fpCLLog,"	ColourID --> : %s",ColourID); fflush(fpCLLog);
												}
												else
												{
													Suffix =  strtok(t5ClSrl,",");
													printf("    Suffix --> : %s",Suffix); fflush(stdout);
													fprintf(fpCLLog,"    Suffix --> : %s",Suffix); fflush(fpCLLog);

													ColourID  =  strtok(NULL,",");
													printf("    ColourID --> : %s",ColourID); fflush(stdout);
													fprintf(fpCLLog,"    ColourID --> : %s",ColourID); fflush(fpCLLog);
												}


												n_ClrPrt_tags=0;
												NonClrflag=1;

												char *ColItem = NULL;
												logical checkout;

												ColItem=(char *) MEM_alloc(25);
												strcpy(ColItem,"");
												if(tc_strcmp(PartType,"G")==0)
												{
													//printf("\n  before NewUniqGroupIDNum\n"); fflush(stdout);
													//ResponseStr = NewUniqGroupIDNum();
													//printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
													//strcat(ColItem,ResponseStr);
													printf("\n    Colour Part for Group ID---->%s\n",ColItem);
													fprintf(fpCLLog,"\n    Colour Part for Group ID---->%s\n",ColItem); fflush(fpCLLog);
												}
												else
												{
													strcpy(ColItem,Part_no);
													strcat(ColItem,Suffix);
												}

												if (tc_strcmp(ColPartNo,ColItem)==0)
												{
													printf("\n\n    SchemeColourPart: %s == ColPartNo: %s --------------->ColPart Match Found......",ColItem,ColPartNo); fflush(stdout);
													fprintf(fpCLLog,"\n\n    SchemeColourPart: %s == ColPartNo: %s --------------->ColPart Match Found......",ColItem,ColPartNo); fflush(fpCLLog);
													MatchColSchemeFlag=1;
												}
												else
												{
													continue;
												}

												if (strlen(ColItem)>=1)
												{
													if (ClrPartQryTag!=NULLTAG)
													{
														//printf("\n    CL=Found Query 'ClrPart' ClrPartQryTag \n"); fflush(stdout);
														valuesClrPrt[0] = ColItem;
														if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &n_ClrPrt_tags, &ClrPrtTags));
														printf("\n    1.ClrPart count is--------> %d ",n_ClrPrt_tags);fflush(stdout);
														fprintf(fpCLLog,"\n    1.ClrPart count is--------> %d ",n_ClrPrt_tags);fflush(fpCLLog);
													}
													else
													{
														printf("\n    Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....\n"); fflush(stdout);
														fprintf(fpCLLog,"\n    Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....\n"); fflush(fpCLLog);
														break;
													}
												}
												else{
													printf("\n    2.ClrPart count = 0");fflush(stdout);
													fprintf(fpCLLog,"\n    2.ClrPart count = 0");fflush(fpCLLog);
													break;
												}

												tc_strcpy(NewColourPart,ColItem);

												printf("\t NCAssyChildFlag: %d   NewColourPart: [%s]",NCAssyChildFlag,NewColourPart);fflush(stdout);
												fprintf(fpCLLog,"\t NCAssyChildFlag: %d   NewColourPart: [%s]",NCAssyChildFlag,NewColourPart);fflush(fpCLLog);

												tag_t ClritemTag = NULLTAG;
												tag_t clrbv = NULLTAG;
												tag_t  clrbvrTag = NULLTAG;
												tag_t *clr_bvs = NULLTAG;
												tag_t *clr_bvrs = NULLTAG;
												int bv_clrcount =0;
												int i1, TskHSICnt, ci, PartAttachtoDmlFlag =0;
												char *ColPartRev = NULL;
												char *tsk_name = NULL;
												char *TskSolutnItem = NULL;
												tag_t *TskHSItems = NULLTAG;
												int MultiLvlCCABomSt = 0;
												int MultiLvlCCACompCodeMatch=0 , CCACompCFlag=0 , cca=0;

												if(n_ClrPrt_tags > 0)
												{
													ColItemTag = ClrPrtTags[0];

													if(ITEM_ask_latest_rev(ColItemTag,&ColorRevTag)!=ITK_ok)PrintErrorStack();
													if(AOM_UIF_ask_value(ColorRevTag, "item_revision_id", &ColPartRev)!=ITK_ok)PrintErrorStack();
													printf("  ColPartRev: %s",ColPartRev);	fflush(stdout);
													fprintf(fpCLLog,"  ColPartRev: %s",ColPartRev);	fflush(fpCLLog);

													if(WSOM_ask_release_status_list(ColorRevTag, &ColRlzStatusCnt, &Col_Rlz_St_list)!=ITK_ok)PrintErrorStack();
													printf("\t ColRlzStatusCnt: %d",ColRlzStatusCnt);	fflush(stdout);
													fprintf(fpCLLog,"\t ColRlzStatusCnt: %d",ColRlzStatusCnt);	fflush(fpCLLog);

													ColRlzRevFlag=0;
													if (ColRlzStatusCnt > 0)
													{
														for(ss2=0; ss2<ColRlzStatusCnt ; ss2++)
														{
															if(AOM_ask_value_string(Col_Rlz_St_list[ss2],"object_name",&ColPrtLatestRlzSt)!=ITK_ok)PrintErrorStack();
															if((tc_strcmp(ColPrtLatestRlzSt,"ERC Released")==0) || (tc_strcmp(ColPrtLatestRlzSt,"T5_LcsErcRlzd")==0))
															{
																printf("\t ColPrtLatestRlzSt: %s ",ColPrtLatestRlzSt);fflush(stdout);
																fprintf(fpCLLog,"\t ColPrtLatestRlzSt: %s ",ColPrtLatestRlzSt);fflush(fpCLLog);
																ColRlzRevFlag=1;
																break;
															}
														}
													} //End of if (ColRlzStatusCnt > 0)

													if (ColRlzRevFlag==0)
													{
														printf("\t ColPrtLatestRlzSt: %s ",ColPrtLatestRlzSt);fflush(stdout);
														fprintf(fpCLLog,"\t ColPrtLatestRlzSt: %s ",ColPrtLatestRlzSt);fflush(fpCLLog);
														////printf(" ----Latest ColourPart revision is not in ERC Released Status, hence skipping its colour colour part revise ??? \n");fflush(stdout);

														//START--Check ERC Review colour if attached to same working DML then proceed for bom change
														PartAttachtoDmlFlag=0;
														if (taskCnt>0)
														{
															for (i1=0;i1<taskCnt ;i1++ )
															{
																if(AOM_ask_value_string(DmlTaskTags[i1],"object_name",&tsk_name)==ITK_ok)
																printf("\n tsk_name is :%s\n",tsk_name);fflush(stdout);
																fprintf(fpCLLog,"\n tsk_name is :%s\n",tsk_name);fflush(fpCLLog);

																if (tsk_HSI_rel_type!=NULLTAG)
																{
																	if(GRM_list_secondary_objects_only(DmlTaskTags[i1], tsk_HSI_rel_type, &TskHSICnt, &TskHSItems)!=ITK_ok)PrintErrorStack();
																	printf("\n    i1: %d  Task: %s --->> TskHSICnt partcnt:  %d ",i1, tsk_name, TskHSICnt);fflush(stdout);
																	fprintf(fpCLLog,"\n    i1: %d  Task: %s --->> TskHSICnt partcnt:  %d ",i1, tsk_name, TskHSICnt);fflush(fpCLLog);

																	if (TskHSICnt > 0)
																	{
																		for (ci = 0; ci < TskHSICnt ; ci ++)
																		{
																			if( AOM_ask_value_string(TskHSItems[ci],"item_id",&TskSolutnItem)==ITK_ok)
																			//printf("\n\t\t TskSolutnItem-item_id: %s  ColItem: %s",TskSolutnItem,ColItem);fflush(stdout);

																			if (tc_strcmp(ColItem,TskSolutnItem)==0)
																			{
																				printf("\n\t TskSolutnItem-item_id: %s  ColItem: %s",TskSolutnItem,ColItem);fflush(stdout);
																				printf(" ---Match-Colour attached found to DML task"); fflush(stdout);

																				fprintf(fpCLLog,"\n\t TskSolutnItem-item_id: %s  ColItem: %s",TskSolutnItem,ColItem);fflush(fpCLLog);
																				fprintf(fpCLLog," ---Match-Colour attached found to DML task"); fflush(fpCLLog);

																				PartAttachtoDmlFlag=1;

																				break;
																			}
																		}
																	}
																}
																if (PartAttachtoDmlFlag==1)
																{
																	break;
																}
															}
														}
														printf("\n\n\t PartAttachtoDmlFlag: %d  for ColItem: %s ",PartAttachtoDmlFlag, ColItem);fflush(stdout);
														fprintf(fpCLLog,"\n\n\t PartAttachtoDmlFlag: %d  for ColItem: %s ",PartAttachtoDmlFlag, ColItem);fflush(fpCLLog);
														if (PartAttachtoDmlFlag==0)
														{
															printf(" ---ColourPart is not attached to same DML, hence skipping ????"); fflush(stdout);
															fprintf(fpCLLog," ---ColourPart is not attached to same DML, hence skipping ????"); fflush(fpCLLog);
															//If Colour attached to another DML if not then attach to current DML and preoceed bom--add code
														}
														//END--Check ERC Review colour if attached to same working DML then proceed for bom change
													}

													//if (ColRlzRevFlag>0)
													if ((ColRlzRevFlag>0) || (PartAttachtoDmlFlag==1))
													{
														int ReviseStatus = ValColAndNonColBomForRevise_CL(NonClrPartTag,ColorRevTag,ColRlzRevFlag,SchmRefTag);
														printf("\n\t ColRlzRevFlag:%d  ReviseStatus: %d  NonColPartBomDiff: %d",ColRlzRevFlag, ReviseStatus, strlen(NonClrChildSet));fflush(stdout);
														fprintf(fpCLLog,"\n\t ColRlzRevFlag:%d  ReviseStatus: %d  NonColPartBomDiff: %d",ColRlzRevFlag, ReviseStatus, strlen(NonClrChildSet));fflush(fpCLLog);

														if ((ReviseStatus==0)&&(strlen(NonClrChildSet)==0))
														{
															printf("\t ---B--No need to revive Colour: %s/%s [%s] --No BOM Difference ..",ColItem,ColPartRev,ColPrtLatestRlzSt);fflush(stdout);
															fprintf(fpCLLog,"\t ---B--No need to revive Colour: %s/%s [%s] --No BOM Difference ..",ColItem,ColPartRev,ColPrtLatestRlzSt);fflush(fpCLLog);
														}
														else
														{
															MultiLvlCCABomSt=0;
															MultiLvlCCACompCodeMatch=0;
															CCACompCFlag=0;

															printf("\n CL=Comp_Code: %s   NCPart_no: [%s,%s]   CntrlObjCntCCA: [%d] ",Comp_Code,Part_no,RevSeqTmp,CntrlObjCntCCA);fflush(stdout);
															fprintf(fpCLLog,"\n CL=Comp_Code: %s   NCPart_no: [%s,%s]   CntrlObjCntCCA: [%d] ",Comp_Code,Part_no,RevSeqTmp,CntrlObjCntCCA);fflush(fpCLLog);

															//START-For Comp_Code=CCA Assy, check mult-level child compcode match under scheme. Added on dated 15.03.2021 in UA 1.57
															if ((CntrlObjCntCCA>0) && (tc_strstr(Comp_Code,"CCA")!=NULL))
															{
																CCACompCFlag=1;
																printf("\n ------------Check Comp_Code=CCA Assy mult-level child compcode match -----------------");fflush(stdout);
																fprintf(fpCLLog," ------------Check Comp_Code=CCA Assy mult-level child compcode match -----------------");fflush(fpCLLog);

																//NonClrPartTag  -- ERC Review non-colour part rev tag
																for (cca = 0; cca < NonClrChildCnt; cca++)
																{
																	if(NClrChildobject) NClrChildobject=NULLTAG;
																	NClrChildobject=NonClrChilds[cca];

																	if(AOM_ask_value_string(NClrChildobject, "bl_item_item_id", &NCChild)!=ITK_ok)PrintErrorStack();
																	if(AOM_ask_value_string(NClrChildobject, "bl_rev_item_revision_id", &NCChildRevSeq)!=ITK_ok)PrintErrorStack();
																	if(AOM_ask_value_string(NClrChildobject, "bl_Design Revision_t5_ColourInd", &NCChildColInd)!=ITK_ok)PrintErrorStack();
																	if(AOM_ask_value_string(NClrChildobject, "bl_Design Revision_t5_PrtCatCode", &NCChildCompCode)!=ITK_ok)PrintErrorStack();

																	printf("\n\n  cca: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  ",cca,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode); fflush(stdout);
																	fprintf(fpCLLog,"\n\n  cca: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s] ",cca,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode); fflush(fpCLLog);

																	if((tc_strcmp(NCChildColInd,"Y")==0) && (tc_strstr(NCChildCompCode,"CCA")!=NULL))
																	{
																		printf("\t Inside Condition---"); fflush(stdout);
																		fprintf(fpCLLog,"\t Inside Condition---"); fflush(fpCLLog);

																		//MultiLvlCCABomSt = ValMultiLvlBomForScheme_CCAComp_CL(NClrChildobject,SchmRefTag,CmpCodeOfClrScheme,Cmpcount,SchmName,SchmRev,NewTskObjOP);
																		MultiLvlCCABomSt = ValMultiLvlBomForScheme_CCAComp_CL(NClrChildobject,SchmRefTag,CmpCodeOfClrScheme,Cmpcount,SchmName,SchmRev);
																		
																		printf("\n\n\t   ValMultiLvlBomForScheme_CCAComp_CL----MultiLvlCCABomSt: ",MultiLvlCCABomSt); fflush(stdout);
																		fprintf(fpCLLog,"\n\n\t   ValMultiLvlBomForScheme_CCAComp_CL----MultiLvlCCABomSt: ",MultiLvlCCABomSt); fflush(fpCLLog);

																		if (MultiLvlCCABomSt<=0)
																		{
																			MultiLvlCCACompCodeMatch=0;
																		}
																		else
																		{
																			MultiLvlCCACompCodeMatch=1;
																		}
																	}
																}
															} //end for condn--if ((CntrlObjCntCCA>0) && (tc_strstr(Comp_Code,"CCA")!=NULL))
															else if (((CntrlObjCntCCA>0) || (CntrlObjCntCCA==0)) && (tc_strstr(Comp_Code,"CCA")==NULL))
															{
																CCACompCFlag=0;
															}
															else if ((CntrlObjCntCCA==0) && (tc_strstr(Comp_Code,"CCA")!=NULL))
															{
																CCACompCFlag=-1;
															}
															//END-For Comp_Code=CCA Assy, check mult-level child compcode match under scheme. Added on dated 15.03.2021 in UA 1.57

															printf("\n\n\t CL==Comp_Code: [%s]  MultiLvlCCACompCodeMatch: [%d]  CCACompCFlag: [%d]  ",Comp_Code,MultiLvlCCACompCodeMatch,CCACompCFlag); fflush(stdout);
															fprintf(fpCLLog,"\n\n\t CL==Comp_Code: [%s]  MultiLvlCCACompCodeMatch: [%d]  CCACompCFlag: [%d]  ",Comp_Code,MultiLvlCCACompCodeMatch,CCACompCFlag); fflush(fpCLLog);

															if ((MultiLvlCCACompCodeMatch==0) && (tc_strstr(Comp_Code,"CCA")!=NULL) && (CCACompCFlag==1))
															{
																printf("----All CompCode are not matched under CCA Assy, hence skipping from revise...??? \n"); fflush(stdout);
																fprintf(fpCLLog,"----All CompCode are not matched under CCA Assy, hence skipping from revise...??? \n"); fflush(fpCLLog);

																fprintf(fpCLErrLog,"\n\n\t CL==Comp_Code: [%s]  MultiLvlCCACompCodeMatch: [%d]  CCACompCFlag: [%d]  ",Comp_Code,MultiLvlCCACompCodeMatch,CCACompCFlag); fflush(fpCLErrLog);
																fprintf(fpCLErrLog,"----All CompCode are not matched under CCA Assy, hence skipping from revise...??? \n"); fflush(fpCLErrLog);

															} //end for if condn--if ((MultiLvlCCABomSt<=0) && (tc_strstr(Comp_Code,"CCA")!=NULL))
															else
															{
																if(RES_is_checked_out(ColorRevTag,&checkout)!=ITK_ok)PrintErrorStack();
																//printf("\n\t CL=ColPart--Value of checkout: %d ",checkout);fflush(stdout);
																printf(" 333checkout: %d ",checkout);fflush(stdout);
																fprintf(fpCLLog," 333checkout: %d ",checkout);fflush(fpCLLog);
																if (checkout==0)
																{
																	printf("---Latest and previous Rlz NC_Rev bom difference present1...\n"); fflush(stdout);
																	fprintf(fpCLLog,"---Latest and previous Rlz NC_Rev bom difference present1...\n"); fflush(fpCLLog);
																	int count2=0;
																	int z=0;
																	int bvr_count=0;
																	int n_occs_clr=0;
																	int ic = 0;
																	tag_t *occs_clr = NULLTAG;
																	tag_t *secondary_objects = NULLTAG;
																	tag_t *occs=NULL;
																	tag_t objTypeTag2 = NULLTAG;
																	char type_name1[TCTYPE_name_size_c+1];
																	char *object_type = NULL;
																	char *chname= NULL;

																	tag_t	NewTskObjOP		= NULLTAG;
																	tag_t	item			= NULLTAG;
																	tag_t	ERCDMLTag		= NULLTAG;
																	char **valuesERCDML = (char **) MEM_alloc(1 * sizeof(char *));
																	int n_entriesDML = 1;
																	char *qry_entries5[1] = {"ID"};
																	int resultDMLNo=0;
																	tag_t *DMLNotags=NULLTAG;
																	tag_t ERCDMLObjtag = NULLTAG;
																	tag_t reln_type_tag = NULLTAG;
																	tag_t relation = NULLTAG;
																	char *Dml_taskNo = NULL;
																	tag_t IMANReferences_type;
																	tag_t Rel_References = NULLTAG;
																	tag_t RelExist = NULLTAG;

																	printf("---Latest and previous Rlz NC_Rev bom difference present...2\n"); fflush(stdout);
																	fprintf(fpCLLog,"---Latest and previous Rlz NC_Rev bom difference present...2\n"); fflush(fpCLLog);

																	if(GRM_find_relation_type("T5_DMLTaskRelation",&reln_type_tag)!=ITK_ok)PrintErrorStack();
																	if(AOM_ask_value_string(Dml_task,"item_id",&Dml_taskNo)!=ITK_ok)PrintErrorStack();
																	printf("\n Dml_taskNo----------->%s\n",Dml_taskNo); fflush(stdout);
																	fprintf(fpCLLog,"\n Dml_taskNo----------->%s\n",Dml_taskNo); fflush(fpCLLog);

																	DMLNo = subString(Dml_taskNo,0,10);
																	printf("\n Dml_taskNo----------->%s\n",DMLNo); fflush(stdout);
																	fprintf(fpCLLog,"\n Dml_taskNo----------->%s\n",DMLNo); fflush(fpCLLog);

																	if(QRY_find("ERC DML", &ERCDMLTag));
																	valuesERCDML[0] = DMLNo ;
																	if(QRY_execute(ERCDMLTag, n_entriesDML, qry_entries5, valuesERCDML, &resultDMLNo, &DMLNotags));
																	printf("\n resultDMLNo count is-------->  : %d",resultDMLNo);fflush(stdout);
																	fprintf(fpCLLog,"\n resultDMLNo count is-------->  : %d",resultDMLNo);fflush(fpCLLog);

																	if (resultDMLNo > 0)
																	{
																		ERCDMLObjtag = DMLNotags[0];
																		//Added by Hanuman at TZ 1.52
																		if(GRM_find_relation_type("IMAN_reference", &IMANReferences_type)!=ITK_ok)PrintErrorStack();
																		if(IMANReferences_type!=NULLTAG)
																		{
																			if(GRM_find_relation(ERCDMLObjtag,SchmRefTag,IMANReferences_type,&RelExist)!=ITK_ok)PrintErrorStack();
																			if (RelExist==NULLTAG)
																			{
																				if(GRM_create_relation(ERCDMLObjtag,SchmRefTag,IMANReferences_type, NULLTAG, &Rel_References)!=ITK_ok)PrintErrorStack();
																				if(AOM_load(Rel_References)!=ITK_ok)PrintErrorStack();
																				if(GRM_save_relation(Rel_References)!=ITK_ok)PrintErrorStack();
																				if(AOM_refresh(Rel_References,0)!=ITK_ok)PrintErrorStack();
																			}
																		}
																	}

																	sTaskName = NULL;
																	sTaskName=(char *) MEM_alloc(50);
																	tc_strcpy(sTaskName,DMLNo);
																	tc_strcat(sTaskName,"_CL");
																	printf("\n TaskName is ===> [%s]\n",sTaskName);fflush(stdout);
																	fprintf(fpCLLog,"\n TaskName is ===> [%s]\n",sTaskName);fflush(fpCLLog);

																	if(QRY_find("ERC DML Task", &queryds)!=ITK_ok)PrintErrorStack();
																	qry_valuesds[0] = sTaskName;
																	if(QRY_execute(queryds, n_entries, qry_entriesds, qry_valuesds, &TaskClSet, &TaskClTag)!=ITK_ok)PrintErrorStack();
																	printf("\n TaskClSet is :: %d\n", TaskClSet);fflush(stdout);
																	fprintf(fpCLLog,"\n TaskClSet is :: %d\n", TaskClSet);fflush(fpCLLog);

																	if(TaskClSet>0)
																	{
																		NewTskObjOP=TaskClTag[0];
																	}else
																	{
																		if(TaskClSet == 0)
																		{
																			if(ITEM_create_item(sTaskName,sTaskName,"T5_ChangeTask",sTaskName,&item,&NewTskObjOP)!=ITK_ok)PrintErrorStack();
																			printf("\n CL Task created first time------------>\n");fflush(stdout);
																			fprintf(fpCLLog,"\n CL Task created first time------------>\n");fflush(fpCLLog);
																			if(AOM_save(item)!=ITK_ok)PrintErrorStack();
																			if(AOM_save(NewTskObjOP)!=ITK_ok)PrintErrorStack();
																			if(GRM_create_relation(ERCDMLObjtag, NewTskObjOP, reln_type_tag,  NULLTAG, &relation)!=ITK_ok)PrintErrorStack();
																			if(GRM_save_relation(relation)!=ITK_ok)PrintErrorStack();
																			printf("\n CL Task relation created sucessfuly------------>\n");fflush(stdout);
																			fprintf(fpCLLog,"\n CL Task relation created sucessfuly------------>\n");fflush(fpCLLog);

																			//int retrnVal = SendMailToUser(sTaskName);
																			//printf("\n retrnVal is ===> [%d]\n",retrnVal);fflush(stdout);
																			//fprintf(fpCLLog,"\n retrnVal is ===> [%d]\n",retrnVal);fflush(fpCLLog);
																		}
																	}

																	if (NewTskObjOP!=NULLTAG)
																	{
																		if (ColRlzRevFlag>0)
																		{
																			if(ITEM_copy_rev(ColorRevTag,NULL,&NewColorRevTag)!=ITK_ok)PrintErrorStack();  //Revise
																			//printf("\n....25....");fflush(stdout);
																			if (NewColorRevTag!=NULLTAG)
																			{
																			if(AOM_ask_value_string(NewColorRevTag,"item_revision_id",&NewColPartRevSeq)!=ITK_ok)PrintErrorStack();
																			printf("\n\t CL=NewColPartRevSeq: %s ",NewColPartRevSeq);fflush(stdout);
																			fprintf(fpCLLog,"\n\t CL=NewColPartRevSeq: %s ",NewColPartRevSeq);fflush(fpCLLog);
																			//printf("\n....26....");fflush(stdout);

																			//Scheme added in Revise Color Parts-Hanuman
																			printf("\n SchDataToGov1122222222 is -------> %s\n",SchDataToGov);fflush(stdout);
																			fprintf(fpCLLog,"\n SchDataToGov1122222222 is -------> %s\n",SchDataToGov);fflush(fpCLLog);

																			if(AOM_lock(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																			if(AOM_set_value_string(NewColorRevTag,"gov_classification",SchDataToGov)!=ITK_ok)PrintErrorStack();
																			if(AOM_save(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																			if(AOM_unlock(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																				if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
																				{
																					if(GRM_find_relation(NewTskObjOP,NewColorRevTag,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
																					if (ReltnExist==NULLTAG)
																					{
																						if(GRM_create_relation(NewTskObjOP,NewColorRevTag,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
																						if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
																						if(AOM_refresh(reltask,0)!=ITK_ok)PrintErrorStack();
																						printf("\n\t DML_Task and Revised New ColPart Relation is Created Successfully.....\n");fflush(stdout);
																						fprintf(fpCLLog,"\n\t DML_Task and Revised New ColPart Relation is Created Successfully.....\n");fflush(fpCLLog);
																					}
																				}

																				//below point is in Under discussion at TZ 1.56
																				int n_attchs,l =0;
																				tag_t*  secondary_objects	= NULLTAG;

																				if ((tRelationFind!=NULLTAG) && (NewColorRevTag!=NULLTAG) && (NonClrItemRevTag!=NULLTAG))
																				{
																					if(GRM_find_relation(NewColorRevTag,NonClrItemRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
																					if(tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
																					{
																						if(GRM_create_relation(NewColorRevTag,NonClrItemRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
																						if(Rel_task!=NULLTAG)
																						{
																							printf("\nAssy-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
																							//fprintf(fpCLLog,"\nAssy-Colour-Non_Colour child part Relation Created Successfully \n");fflush(fpCLLog);
																							if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();//
																							if(AOM_refresh(Rel_task,0)!=ITK_ok)PrintErrorStack();//
																						}
																						else
																						{
																							printf("\nAssy-Colour-Non_Colour child part Relation is not Created ?????\n");fflush(stdout);
																							//fprintf(fpCLLog,"\nAssy-Colour-Non_Colour child part Relation is not Created ?????\n");fflush(fpCLLog);
																						}
																					}

																					if (tc_strstr(NewColPartRevSeq,"NR")==NULL)
																					{
																						if(GRM_list_secondary_objects_only(NewColorRevTag,tRelationFind,&n_attchs,&secondary_objects)!=ITK_ok)PrintErrorStack();
																						printf("\n\n\t\t No of DI : %d",n_attchs);fflush(stdout);
																						fprintf(fpCLLog,"\n\n\t\t No of DI : %d",n_attchs);fflush(fpCLLog);
																						if(n_attchs>0)
																						{
																							for (l=0;l<n_attchs ;l++ )
																							{
																								if(AOM_UIF_ask_value (secondary_objects[l], "release_status_list", &NPrtLatestRlzSt)!=ITK_ok)PrintErrorStack();
																								if((tc_strstr(NPrtLatestRlzSt,"ERC Released")!=NULL) || (tc_strstr(NPrtLatestRlzSt,"T5_LcsErcRlzd")!=NULL))
																								{
																									printf("\t ColPrtLatestRlzSt: %s\n",NPrtLatestRlzSt);fflush(stdout);
																									fprintf(fpCLLog,"\t ColPrtLatestRlzSt: %s\n",NPrtLatestRlzSt);fflush(fpCLLog);
																									if(GRM_find_relation(NewColorRevTag,secondary_objects[l],tRelationFind,&tRelationExist1)!=ITK_ok)PrintErrorStack();
																									if(tRelationExist1!=NULLTAG)
																									{
																										if(GRM_delete_relation(tRelationExist1)!=ITK_ok)PrintErrorStack();
																										if(AOM_lock(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																										if(AOM_save(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																										if(AOM_unlock(NewColorRevTag)!=ITK_ok)PrintErrorStack();
																										printf("\nRelation Deleted Successfully\n"); fflush(stdout);
																										fprintf(fpCLLog,"\nRelation Deleted Successfully\n"); fflush(fpCLLog);
																									}
																								}
																							}
																						}
																					}
																				}
																				else
																				{
																					printf("\n NULLTAG found for tRelationFind/NewColorRevTag/NonClrItemRevTag hence Relation is not Created ?? \n");fflush(stdout);
																					fprintf(fpCLLog,"\n NULLTAG found for tRelationFind/NewColorRevTag/NonClrItemRevTag hence Relation is not Created ?? \n");fflush(fpCLLog);
																				}
																			}
																		}else
																		{
																			NewColorRevTag=ColorRevTag; //For ERC Review
																		}
																		if(NewColorRevTag!=NULLTAG)
																		{
																			//Create Colour Assembly BVR
																			if(ITEM_ask_item_of_rev(NewColorRevTag, &ClritemTag)!=ITK_ok)PrintErrorStack();
																			if(ITEM_list_bom_views(ClritemTag,&bv_clrcount, &clr_bvs)!=ITK_ok)PrintErrorStack();
																			printf("\n\t bv_clrcnt :%d ",bv_clrcount);fflush(stdout);
																			fprintf(fpCLLog,"\n\t bv_clrcnt :%d ",bv_clrcount);fflush(fpCLLog);

																			if (bv_clrcount!=NULLTAG)
																			{
																				clrbv = clr_bvs[0];
																				MEM_free(clr_bvs);
																			}
																			else
																			{
																				if(PS_create_bom_view( NULLTAG, "", "", ClritemTag,&clrbv )!=ITK_ok)PrintErrorStack();
																				if(AOM_save( clrbv )!=ITK_ok)PrintErrorStack();
																				if(AOM_save( ClritemTag )!=ITK_ok)PrintErrorStack();
																				if(AOM_unlock( ClritemTag )!=ITK_ok)PrintErrorStack();
																				printf("\n\t inside PS_create_bom_view..\n");fflush(stdout);
																				fprintf(fpCLLog,"\n\t inside PS_create_bom_view..\n");fflush(fpCLLog);
																			}

																			if(clrbv !=NULLTAG)
																			{
																			//printf("\n Before clrbvrTag find...");fflush(stdout);
																			if(ITEM_rev_list_bom_view_revs( NewColorRevTag, &bvr_count, &clr_bvrs)!=ITK_ok)PrintErrorStack();
																			printf("\n\t CL--Colour bvr_count  --->[%d]  ",bvr_count); fflush(stdout);
																			fprintf(fpCLLog,"\n\t CL--Colour bvr_count  --->[%d]  ",bvr_count); fflush(fpCLLog);
																			if (bvr_count > 0)
																			{
																				clrbvrTag=clr_bvrs[0];
																				MEM_free(clr_bvrs);

																				if(AOM_lock(clrbvrTag)!=ITK_ok)PrintErrorStack();
																				if(PS_list_occurrences_of_bvr( clrbvrTag, &n_occs_clr, &occs_clr )!=ITK_ok)PrintErrorStack();\
																				printf("\n\t CL-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(stdout);
																				fprintf(fpCLLog,"\n\t CL-- n_occs_clr  --->[%d]  ",n_occs_clr); fflush(fpCLLog);

																				for (ic = 0; ic<n_occs_clr; ic++)
																				{
																					if(PS_delete_occurrence( clrbvrTag, occs_clr[ic] )!=ITK_ok)PrintErrorStack();
																				}
																				if(AOM_save( clrbvrTag )!=ITK_ok)PrintErrorStack();
																				if(AOM_unlock( clrbvrTag )!=ITK_ok)PrintErrorStack();
																				MEM_free(occs_clr);
																			}
																			else{
																				if(PS_create_bvr( clrbv, "", "", false, NewColorRevTag,&clrbvrTag)!=ITK_ok)PrintErrorStack();
																				if(clrbvrTag !=NULLTAG)
																				{
																					if(AOM_save( clrbvrTag)!=ITK_ok)PrintErrorStack();
																					if(AOM_save( NewColorRevTag )!=ITK_ok)PrintErrorStack();
																					if(AOM_unlock( NewColorRevTag )!=ITK_ok)PrintErrorStack();
																					printf( "\n\t inside  PS_create_bvr..\n");fflush(stdout);
																					fprintf(fpCLLog,"\n\t inside  PS_create_bvr..\n");fflush(fpCLLog);
																				}
																			}

																			//--START--Adding Childs under New Colour Assy bvr-----------

																			//Previous Released Colour assy- Start
																			tag_t   bom_winclr=NULLTAG;
																			tag_t   top_line1=NULLTAG;
																			tag_t   ruleClr	=NULLTAG;
																			int rulefound1= 0;
																			tag_t *closurerule1 = NULL;
																			tag_t close_tag1;
																			char **rulename1 = NULL;
																			char **rulevalue1 = NULL;
																			tag_t *lines1 = NULL;
																			int n_lines1,k1,k2,CClrQty =0;
																			tag_t  clrPartObject		= NULLTAG;
																			tag_t  CCChildItemTag		= NULLTAG;
																			char *CCChildQty = NULL;
																			char *ColourIndC = NULL;
																			char *ClrCompCode = NULL;
																			char *t5_clr_item_id = NULL;

																			int nc1,NClrQty1,p1 =0;
																			tag_t Childobject1 = NULLTAG;
																			tag_t NCChildItemTag1 = NULLTAG;
																			tag_t *NonClrChilds1 = NULLTAG;
																			char *NCChild1=NULL;
																			char *NCChildColInd1=NULL;
																			char *NCChildQt1y=NULL;

																			if (ColorRevTag!=NULLTAG)
																			{
																				if(BOM_create_window( &bom_winclr)!=ITK_ok)PrintErrorStack();
																				//if(CFM_find("Color ERC Released and above", &ruleClr)!=ITK_ok)PrintErrorStack(); // To be discussed later if released rule requitred here
																				if(CFM_find("Color ERC Review and above", &ruleClr)!=ITK_ok)PrintErrorStack();
																				if(BOM_set_window_config_rule(bom_winclr, ruleClr)!=ITK_ok)PrintErrorStack();
																				/*
																				if(PIE_find_closure_rules("BOMLineskipforunconfigured",PIE_TEAMCENTER, &rulefound1, &closurerule1)!=ITK_ok)PrintErrorStack();
																				if (rulefound1 > 0)
																				{
																					close_tag1 = closurerule1[0];
																					printf ("closure ruleClr found \n");fflush(stdout);
																					fprintf(fpCLLog,"closure ruleClr found \n");fflush(fpCLLog);
																				}
																				if(BOM_window_set_closure_rule(bom_winclr,close_tag1, 0, rulename1,rulevalue1)!=ITK_ok)PrintErrorStack();
																				*/
																				if(BOM_set_window_pack_all(bom_winclr, TRUE)!=ITK_ok)PrintErrorStack();
																				if(BOM_set_window_top_line(bom_winclr , NULLTAG, ColorRevTag, NULLTAG, &top_line1)!=ITK_ok)PrintErrorStack();
																				if(BOM_line_ask_child_lines(top_line1, &n_lines1, &lines1)!=ITK_ok)PrintErrorStack();
																			}
																			printf("\n\tPrevisous rev-Colour bvr n_lines1: %d \n",n_lines1); fflush(stdout);
																			//Previous Released Colour assy- End

																			if(AOM_lock(clrbvrTag)!=ITK_ok)PrintErrorStack();
																			printf("\n\t Part_no/RevSeq= %s/%s   NonClrChildCnt==> %d",Part_no,RevSeqTmp,NonClrChildCnt); fflush(stdout);
																			fprintf(fpCLLog,"\n\t Part_no/RevSeq= %s/%s   NonClrChildCnt==> %d",Part_no,RevSeqTmp,NonClrChildCnt); fflush(fpCLLog);
																			for (nc2 = 0; nc2 < NonClrChildCnt; nc2++)
																			{
																				if(Childobject) Childobject=NULLTAG;
																				Childobject=NonClrChilds[nc2];

																				if(AOM_ask_value_string(Childobject, "bl_item_item_id", &NCChild)!=ITK_ok)PrintErrorStack();
																				if(AOM_ask_value_string(Childobject, "bl_rev_item_revision_id", &NCChildRevSeq)!=ITK_ok)PrintErrorStack();
																				if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_ColourInd", &NCChildColInd)!=ITK_ok)PrintErrorStack();
																				if(AOM_ask_value_string(Childobject, "bl_Design Revision_t5_PrtCatCode", &NCChildCompCode)!=ITK_ok)PrintErrorStack();
																				if(BOM_line_ask_attribute_string(Childobject,QuantityAttrId, &NCChildQty)!=ITK_ok)PrintErrorStack();
																				NClrQty=atoi(NCChildQty);

																				printf("\n\n  B--nc2: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  Bomline_NClrQty: [%d]",nc2,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode,NClrQty); fflush(stdout);
																				fprintf(fpCLLog,"\n\n  B--nc2: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  Bomline_NClrQty: [%d]",nc2,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode,NClrQty); fflush(fpCLLog);

																				if(tc_strcmp(NCChildColInd,"N")==0)
																				{
																					printf("\t ---child ColInd==> N \n"); fflush(stdout);
																					fprintf(fpCLLog,"\t ---child ColInd==> N \n"); fflush(fpCLLog);
																					if(ITEM_find_item(NCChild,&NCChildItemTag)!=ITK_ok)PrintErrorStack();

																					if(NClrQty==0)
																					{
																						if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																					}
																					else
																					{
																						for (p2=0;p2<NClrQty ;p2++ )
																						{
																							if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																							printf("\n    0-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																							fprintf(fpCLLog,"\n    0-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																						}
																					}
																				}
																				else if(tc_strcmp(NCChildColInd,"Y")==0)
																				{
																					int childExistFl=0;

																					printf("\t ---child ColInd==> Y  NCChildCompCode: %s ",NCChildCompCode); fflush(stdout);

																					if((tc_strstr(NCChildCompCode,"CCA")!=NULL)||(tc_strstr(NCChildCompCode,"VEHICLE")!=NULL)||(tc_strstr(NCChildCompCode,"TPL")!=NULL))
																					{
																						for (k1=0;k1<n_lines1 ;k1++ )
																						{
																							if(clrPartObject) clrPartObject=NULLTAG;
																							clrPartObject=lines1[k1];

																							if(AOM_ask_value_string(clrPartObject, "bl_item_item_id", &t5_clr_item_id)!=ITK_ok)PrintErrorStack();
																							printf("\n\t A--t5_clr_item_id: %s",t5_clr_item_id); fflush(stdout);
																							fprintf(fpCLLog,"\n\t A--t5_clr_item_id: %s",t5_clr_item_id); fflush(fpCLLog);

																							if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
																							printf(" ColourIndC: %s",ColourIndC); fflush(stdout);
																							fprintf(fpCLLog," ColourIndC: %s",ColourIndC); fflush(fpCLLog);

																							if((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0))
																							{
																								if (strstr(t5_clr_item_id,NCChild)!=NULL)
																								{
																									childExistFl=1;

																									//if(BOM_line_ask_attribute_string(clrPartObject,QuantityAttrId, &CCChildQty)!=ITK_ok)PrintErrorStack();
																									//NClrQty=atoi(CCChildQty);

																									break;
																								}
																							}
																						}

																						printf(" n_lines1: %d   childExistFl: %d ",n_lines1,childExistFl); fflush(stdout);

																						if (childExistFl==0)
																						{
																							printf("\n ...---adding child from colour bom and not present in non-col bom.....[%s]=[%d]",NCChild,NClrQty); fflush(stdout);
																							fprintf(fpCLLog,"\n ...---adding child from colour bom and not present in non-col bom.....[%s]=[%d]",NCChild,NClrQty); fflush(fpCLLog);
																							if(ITEM_find_item(NCChild, &CCChildItemTag)!=ITK_ok)PrintErrorStack();

																							if(NClrQty==0)
																							{
																								if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																							}
																							else
																							{
																								for (k2=0;k2<NClrQty;k2++ )
																								{
																									if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																									printf("\n    1-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(stdout);
																									fprintf(fpCLLog,"\n    1-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(fpCLLog);
																								}
																							}
																						}
																					}
																					else ////Comp_code not like CCA% , VEHICLE, TPLS%
																					{
																						char *ClrChildItem = NULL;
																						logical checkout2;
																						int CompCodeClrSrlMatchFlag = 0;
																						t5ClSrl = (char*) malloc(50);

																						t5ClSrl = GetColourSrlFrmSchmCompCodes(CmpCodeOfClrScheme,Cmpcount,NCChildCompCode);
																						printf("\n  CL-B=t5ClSrl from function: %s",t5ClSrl); fflush(stdout);
																						fprintf(fpCLLog,"\n  CL=t5ClSrl from function: %s",t5ClSrl); fflush(fpCLLog);

																						if ((t5ClSrl!=NULL) && (strlen(t5ClSrl)>0))
																						{
																							if(tc_strstr(t5ClSrl,";")!=NULL) {
																								Suffix =  strtok(t5ClSrl,";");
																								ColourID  =  strtok(NULL,";");
																							}
																							else {
																								Suffix =  strtok(t5ClSrl,",");
																								ColourID  =  strtok(NULL,",");
																							}
																							printf("\n\t   CL=Suffix-->: %s  ColourID: %s ",Suffix,ColourID); fflush(stdout);
																							fprintf(fpCLLog,"\n\t   CL=Suffix-->: %s  ColourID: 5s ",Suffix,ColourID); fflush(fpCLLog);


																							if(tc_strcmp(PartType,"G")==0)
																							{
																								printf("\n  In GroupID if condition===\n"); fflush(stdout);
																								//ResponseStr = NewUniqGroupIDNum();
																								//printf("\n  after NewUniqGroupIDNum :: %s\n",ResponseStr); fflush(stdout);
																								//
																								//ClrChildItem = NULL;
																								//ClrChildItem=(char *) MEM_alloc(25);
																								//strcpy(ClrChildItem,"");
																								//strcat(ClrChildItem,ResponseStr);
																								//printf("\n\t   Colour Part for Group ID---->%s\n",ClrChildItem); fflush(stdout);
																								fflush(stdout);
																							}
																							else
																							{
																								ClrChildItem=(char *) MEM_alloc(25);
																								strcpy(ClrChildItem,"");
																								strcpy(ClrChildItem,NCChild);
																								strcat(ClrChildItem,Suffix);
																							}
																							printf("\n\t   Child_ColPartNo: %s ",ClrChildItem); fflush(stdout);

																							if ( (strlen(ClrChildItem)>0) && (ClrPartQryTag!=NULLTAG) )
																							{
																								CompCodeClrSrlMatchFlag = 1;
																								//printf("\n\t   CL=Found Query 'ClrPart' ClrPartQryTag \n"); fflush(stdout);
																								valuesClrPrt[0] = ClrChildItem;
																								if(QRY_execute(ClrPartQryTag, 1 , qry_entries, valuesClrPrt, &n_ClrChild_tags, &ClrChildTags));
																								printf("\t ClrPart_QryCount------> %d ",n_ClrChild_tags);fflush(stdout);

																								if(ITEM_find_item(NCChild, &ClrItemMstrTag)!=ITK_ok)PrintErrorStack();
																								if(ITEM_ask_latest_rev(ClrItemMstrTag,&ClrItemRevTag)!=ITK_ok)PrintErrorStack();

																								if (n_ClrChild_tags==0)
																								{
																									if(ITEM_create_item(ClrChildItem,ClrChildItem,"T5_ClrPart","NR;1",&ColChilditemMstr,&ColChilditemRev)!=ITK_ok)PrintErrorStack();

																									if(ColChilditemRev != NULLTAG)
																									{
																										printf("\n\t A--T5_ClrPart is created---------->\n");fflush(stdout);
																										fprintf(fpCLLog,"\n\t A--T5_ClrPart is created---------->\n");fflush(fpCLLog);

																										char *t5PrtCatCd = NULL;
																										char *t5object_desc = NULL;
																										char *clrdesc = NULL;
																										char *t5PartStatus = NULL;
																										char *t5DesignGrp = NULL;
																										char *t5ProjectCode = NULL;
																										char *t5DocRemarks = NULL;
																										char *t5DrawingInd = NULL;
																										char *t5PartCode = NULL;
																										char *t5AhdMakeBuyIndicator = NULL;
																										char *t5PunPCBUMakeBuyIndicator = NULL;
																										char *t5PunMakeBuyIndicator = NULL;
																										char *t5DwdMakeBuyIndicator = NULL;
																										char *t5Coated = NULL;
																										char *UnitOfMeasureS = NULL;

																										if( AOM_ask_value_string(NonClrPartTag, "t5_PrtCatCode", &t5PrtCatCd)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "object_desc", &t5object_desc)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_Coated", &t5Coated)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_PartStatus", &t5PartStatus)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_DesignGrp", &t5DesignGrp)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_ProjectCode", &t5ProjectCode)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_DocRemarks", &t5DocRemarks)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_DrawingInd", &t5DrawingInd)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_PartCode", &t5PartCode)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_AhdMakeBuyIndicator", &t5AhdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_PunPCBUMakeBuyIndicator", &t5PunPCBUMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_PunMakeBuyIndicator", &t5PunMakeBuyIndicator)!=ITK_ok)PrintErrorStack();
																										if( AOM_ask_value_string(NonClrPartTag, "t5_DwdMakeBuyIndicator", &t5DwdMakeBuyIndicator)!=ITK_ok)PrintErrorStack();


																										printf("\n\t   2.ClrChildItem ---->%s",ClrChildItem);fflush(stdout);
																										printf("\n\t   2.Col_Ind ---->%s",Col_Ind);fflush(stdout);
																										printf("\n\t   2.t5PrtCatCd---->%s",t5PrtCatCd);fflush(stdout);
																										//printf("\n\t   ColourID---->%s",ColourID);fflush(stdout);
																										//printf("\n\t   t5Coated---->%s",t5Coated);fflush(stdout);
																										//printf("\n\t   t5PartStatus---->%s",t5PartStatus);fflush(stdout);
																										//printf("\n\t   t5DesignGrp---->%s",t5DesignGrp);fflush(stdout);
																										//printf("\n\t   t5ProjectCode---->%s",t5ProjectCode);fflush(stdout);
																										//printf("\n\t   mod_desc---->%s",t5DocRemarks);fflush(stdout);
																										//printf("\n\t   t5DrawingInd---->%s",t5DrawingInd);fflush(stdout);
																										//printf("\n\t   PartType---->%s",PartType);fflush(stdout);
																										//printf("\n\t   t5PartCode---->%s",t5PartCode);fflush(stdout);
																										//printf("\n\t   t5AhdMakeBuyIndicator---->%s",t5AhdMakeBuyIndicator);fflush(stdout);
																										//printf("\n\t   t5PunPCBUMakeBuyIndicator---->%s",t5PunPCBUMakeBuyIndicator);fflush(stdout);
																										//printf("\n\t   t5PunMakeBuyIndicator---->%s",t5PunMakeBuyIndicator);fflush(stdout);
																										printf("\n\t   t5DwdMakeBuyIndicator---->%s",t5DwdMakeBuyIndicator);fflush(stdout);

																										clrdesc=(char *) MEM_alloc(200);
																										strcpy(clrdesc,"");
																										strcpy(clrdesc,ColourID);
																										strcat(clrdesc,"-");
																										strcat(clrdesc,t5object_desc);

																										printf("\n\t   Part Desc ---->%s \n",clrdesc);fflush(stdout);
																										fprintf(fpCLLog,"\n\t   Part Desc ---->%s \n",clrdesc);fflush(fpCLLog);

																										//if(setAttributesOnDesign(&ColChilditemMstr,clrdesc,UnitOfMeasureS)!=ITK_ok)PrintErrorStack();
																										//printf("\n Set Attribute on Class T5_ClrPart------------>\n");fflush(stdout);

																										if(tm_setAttributesOnDesignRev2(&ColChilditemRev,clrdesc,"C",t5PrtCatCd,ColourID,t5Coated,t5PartStatus,t5DesignGrp,t5ProjectCode,t5DocRemarks,t5DrawingInd,PartType,t5PartCode,t5AhdMakeBuyIndicator,t5PunPCBUMakeBuyIndicator,t5PunMakeBuyIndicator,t5DwdMakeBuyIndicator,Part_no)!=ITK_ok)PrintErrorStack();
																										printf("\n\t   Set Attribute on Class T5_ClrPartRevision--------->\n");fflush(stdout);
																										fprintf(fpCLLog,"\n\t   Set Attribute on Class T5_ClrPartRevision--------->\n");fflush(fpCLLog);

																										if(tm_CreateReleasestatus(ColChilditemRev)!=ITK_ok)PrintErrorStack();
																										printf("\n\t   CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(stdout);
																										fprintf(fpCLLog,"\n\t   CreateEffctivity for T5_ClrPartsRevision---------->\n");fflush(fpCLLog);

																										if(tm_AssignProject(ColChilditemRev,t5ProjectCode)!=ITK_ok)PrintErrorStack();
																										printf("\n\t   Assign Project to T5_ClrPartsRevision--------->\n");fflush(stdout);
																										fprintf(fpCLLog,"\n\t   Assign Project to T5_ClrPartsRevision--------->\n");fflush(fpCLLog);

																										//Going to update UserOwner Name
																										//if(AOM_set_ownership(ColChilditemRev,user_tag ,group)!=ITK_ok)PrintErrorStack();
																										//printf("\n\t   property Value set...!!\n");fflush(stdout);

																										if (ColChilditemRev!=NULLTAG)
																										{
																											if (tsk_HSI_rel_type!=NULLTAG)  //Attach new colour Assembly to DML Task
																											{
																												if(GRM_find_relation(NewTskObjOP,ColChilditemRev,tsk_HSI_rel_type,&ReltnExist)!=ITK_ok)PrintErrorStack();
																												if (ReltnExist==NULLTAG)
																												{
																													if(GRM_create_relation(NewTskObjOP,ColChilditemRev,tsk_HSI_rel_type,NULLTAG,&reltask)!=ITK_ok)PrintErrorStack();
																													if(GRM_save_relation(reltask)!=ITK_ok)PrintErrorStack();
																													if(AOM_refresh(reltask,0)!=ITK_ok)PrintErrorStack();
																													printf("\n\t   DML_Task and Revised New ColChild Part Relation is Created Successfully.....\n");fflush(stdout);
																													fprintf(fpCLLog,"\n\t   DML_Task and Revised New ColChild Part Relation is Created Successfully.....\n");fflush(fpCLLog);
																												}
																											}

																											if (tRelationFind!=NULLTAG)
																											{
																												if(GRM_find_relation(ColChilditemRev,ClrItemRevTag,tRelationFind,&tRelationExist)!=ITK_ok)PrintErrorStack();
																												if (tRelationExist==NULLTAG)   //Create latest/new colour child Rel to latest Non-Colour
																												{
																													if(GRM_create_relation(ColChilditemRev,ClrItemRevTag,tRelationFind,NULLTAG,&Rel_task)!=ITK_ok)PrintErrorStack();
																													printf("\n\t   Child-Colour-Non_Colour child part Relation Created Successfully \n");fflush(stdout);
																													fprintf(fpCLLog,"\n\t   Child-Colour-Non_Colour child part Relation Created Successfully \n");fflush(fpCLLog);
																													if(GRM_save_relation(Rel_task)!=ITK_ok)PrintErrorStack();
																													if(AOM_refresh(Rel_task,0)!=ITK_ok)PrintErrorStack();
																												}
																											}

																											if(AOM_lock(ColChilditemRev)!=ITK_ok)PrintErrorStack();
																											if(AOM_set_value_string(ColChilditemRev,"gov_classification",SchDataToGov)!=ITK_ok)PrintErrorStack();
																											if(AOM_save(ColChilditemRev)!=ITK_ok)PrintErrorStack();
																											if(AOM_unlock(ColChilditemRev)!=ITK_ok)PrintErrorStack();
																										}

																										if(NClrQty==0)
																										{
																											if(PS_create_occurrences(clrbvrTag, ColChilditemMstr, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																										}
																										else
																										{
																											for (p2=0;p2<NClrQty ;p2++ )
																											{
																												if(PS_create_occurrences(clrbvrTag, ColChilditemMstr, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																												printf("\n\t 3-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																												fprintf(fpCLLog,"\n\t 3-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																											}
																										}
																									}
																								}
																								else
																								{
																									printf("\nCL=ClrChildItem: %s Already present in PLM-TCUA, hence no need to create....Adding under ClrAssy BVR..\n",ClrChildItem);fflush(stdout);
																									fprintf(fpCLLog,"\nCL=ClrChildItem: %s Already present in PLM-TCUA, hence no need to create....Adding under ClrAssy BVR..\n",ClrChildItem);fflush(fpCLLog);
																									if(NClrQty==0)
																									{
																										if(PS_create_occurrences(clrbvrTag, ClrChildTags[0], NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																									}
																									else
																									{
																										for (p2=0;p2<NClrQty ;p2++ )
																										{
																											if(PS_create_occurrences(clrbvrTag, ClrChildTags[0], NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																											printf("\n\t 4-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																											fprintf(fpCLLog,"\n\t 4-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																										}
																									}
																								}
																							}
																							else
																							{
																								printf("\t -->Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....\n"); fflush(stdout);
																								fprintf(fpCLLog,"\t -->Not Found Query 'ClrPart' ClrPartQryTag , hence skipping....\n"); fflush(fpCLLog);
																							}
																						}

																						if (CompCodeClrSrlMatchFlag==0)
																						{
																							printf("\n\n\t ---Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(stdout);
																							fprintf(fpCLLog,"\n\n\t ---Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(fpCLLog);
																							fprintf(fpCLErrLog,"\n Non-colour child ColInd==> Y, but it's comp_code match not found in scheme, hence skipping ???  [%s,%s]\n",NCChild,NCChildCompCode); fflush(fpCLErrLog);

																							if(ITEM_find_item(NCChild,&NCChildItemTag)!=ITK_ok)PrintErrorStack();

																							if(NClrQty==0)
																							{
																								if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																							}
																							else
																							{
																								for (p2=0;p2<NClrQty ;p2++ )
																								{
																									if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																									printf("\n\n\t   5-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(stdout);
																									fprintf(fpCLLog,"\n\n\t   5-->p2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",p2); fflush(fpCLLog);
																								}
																							}
																						}
																					}
																				}
																				else if(tc_strcmp(ChildColInd,"")==0)
																				{
																					printf("\t ---child ColInd==> NULL \n"); fflush(stdout);
																					fprintf(fpCLLog,"\t ---child ColInd==> NULL \n"); fflush(fpCLLog);
																					if(ITEM_find_item(NCChild,&NCChildItemTag)!=ITK_ok)PrintErrorStack();
																					if(PS_create_occurrences(clrbvrTag, NCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																				}
																			} // end of for loop NonClrChildCnt

																			printf("\n\t ColorRevTag--------------------> n_lines1:%d \n",n_lines1); fflush(stdout);
																			fprintf(fpCLLog,"\n\t ColorRevTag-------------------->\n"); fflush(fpCLLog);
																			if ((ColorRevTag!=NULLTAG) && (n_lines1 >0))
																			{
																				for (k1=0;k1<n_lines1 ;k1++ )
																				{
																					int CLChildExistFl=0;

																					if(clrPartObject) clrPartObject=NULLTAG;
																					clrPartObject=lines1[k1];

																					if(AOM_ask_value_string(clrPartObject, "bl_item_item_id", &t5_clr_item_id)!=ITK_ok)PrintErrorStack();
																					if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
																					if(AOM_ask_value_string(clrPartObject, "bl_T5_ClrPartRevision_t5_PrtCatCode", &ClrCompCode)!=ITK_ok)PrintErrorStack();
																					printf("\n\t t5_clr_item_id ===> :: %s  ColourIndC ===> :: %s  ClrCompCode:: %s ",t5_clr_item_id,ColourIndC,ClrCompCode); fflush(stdout);

																					if(((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0)) && ((tc_strstr(ClrCompCode,"CCA")!=NULL)||(tc_strstr(ClrCompCode,"VEHICLE")!=NULL)||(tc_strstr(ClrCompCode,"TPL")!=NULL)))
																					{
																						int nk3=0;
																						char *NCChild2=NULL;

																						for (nk3=0;nk3<NonClrChildCnt ;nk3++ )
																						{
																							if(Childobject) Childobject=NULLTAG;
																							Childobject=NonClrChilds[nk3];

																							if(AOM_ask_value_string(Childobject, "bl_item_item_id", &NCChild2)!=ITK_ok)PrintErrorStack();
																							printf("\n\t\t H--NCChild2: %s",NCChild2); fflush(stdout);
																							fprintf(fpCLLog,"\n\t B--NCChild2: %s",NCChild2); fflush(fpCLLog);

																							if(AOM_ask_value_string(Childobject, "bl_T5_ClrPartRevision_t5_ColourInd", &ColourIndC)!=ITK_ok)PrintErrorStack();
																							printf(" ColourIndC: %s",ColourIndC); fflush(stdout);
																							fprintf(fpCLLog," ColourIndC: %s",ColourIndC); fflush(fpCLLog);

																							if((tc_strcmp(ColourIndC,"C")==0)||(tc_strcmp(ColourIndC,"Y")==0))
																							{
																								if (strstr(t5_clr_item_id,NCChild2)!=NULL)
																								{
																									CLChildExistFl=1;
																									break;
																								}
																							}
																						}
																						printf(" CLChildExistFl: %d ",CLChildExistFl); fflush(stdout);
																						if (CLChildExistFl==1)
																						{
																							if(BOM_line_ask_attribute_string(clrPartObject,QuantityAttrId, &CCChildQty)!=ITK_ok)PrintErrorStack();
																							CClrQty=atoi(CCChildQty);

																							if(ITEM_find_item(t5_clr_item_id, &CCChildItemTag)!=ITK_ok)PrintErrorStack();

																							if(CClrQty==0)
																							{
																								if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																							}
																							else
																							{
																								for (k2=0;k2<CClrQty;k2++ )
																								{
																									if(PS_create_occurrences(clrbvrTag, CCChildItemTag, NULLTAG, 1, &occs )!=ITK_ok)PrintErrorStack();
																									printf("\n    6-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(stdout);
																									fprintf(fpCLLog,"\n    6-->k2: %d ==> PS_create_occurrences successfully in PSE for Non-Colors------->",k2); fflush(fpCLLog);
																								}
																							}
																						}
																					}
																				} //for loop end
																			}
																			//--END--Adding Childs under New Colour Assy bvr-----------
																			}
																			printf("\n After clrbvrTag creation ---");fflush(stdout);
																			//printf(fpCLLog,"\n After clrbvrTag creation ---");fflush(fpCLLog);
																			fprintf(fpCLLog,"\n After clrbvrTag creation...");fflush(fpCLLog);
																			if(AOM_save(clrbvrTag)!=ITK_ok)PrintErrorStack();
																			if(AOM_unlock(clrbvrTag)!=ITK_ok)PrintErrorStack();
																			printf("\t clrbvrTag is saved...");fflush(stdout);
																			fprintf(fpCLLog,"\t clrbvrTag is saved...");fflush(fpCLLog);

																			printf("\n\n CntrlObjCntCL: [%d]",CntrlObjCntCL);fflush(stdout);
																			fprintf(fpCLLog,"\n\n CntrlObjCntCL: [%d]",CntrlObjCntCL);fflush(fpCLLog);

																			if (CntrlObjCntCL>0)
																			{
																				printf("\n\n ...................Checking for multi-level colourable childs........................CntrlObjCntCL: [%d]",CntrlObjCntCL);fflush(stdout);
																				fprintf(fpCLLog,"\n\n Checking for multi-level colourable childs....CntrlObjCntCL: [%d]",CntrlObjCntCL);fflush(fpCLLog);

																				for (nc3 = 0; nc3 < NonClrChildCnt; nc3++)
																				{
																					if(NClrChildobject) NClrChildobject=NULLTAG;
																					NClrChildobject=NonClrChilds[nc3];

																					if(AOM_ask_value_string(NClrChildobject, "bl_item_item_id", &NCChild)!=ITK_ok)PrintErrorStack();
																					if(AOM_ask_value_string(NClrChildobject, "bl_rev_item_revision_id", &NCChildRevSeq)!=ITK_ok)PrintErrorStack();
																					if(AOM_ask_value_string(NClrChildobject, "bl_Design Revision_t5_ColourInd", &NCChildColInd)!=ITK_ok)PrintErrorStack();
																					if(AOM_ask_value_string(NClrChildobject, "bl_Design Revision_t5_PrtCatCode", &NCChildCompCode)!=ITK_ok)PrintErrorStack();

																					printf("\n\n  nc3: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s]  ",nc3,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode); fflush(stdout);
																					fprintf(fpCLLog,"\n\n  nc3: %d  ChildPart==> %s/%s  ColourInd: [%s] [%s] ",nc3,NCChild,NCChildRevSeq,NCChildColInd,NCChildCompCode); fflush(fpCLLog);

																					if((tc_strcmp(NCChildColInd,"Y")==0) && ((tc_strstr(NCChildCompCode,"CCA")==NULL)&&(tc_strstr(NCChildCompCode,"VEHICLE")==NULL)&&(tc_strstr(NCChildCompCode,"TPL")==NULL)))
																					{
																						printf("\t Inside Condition---"); fflush(stdout);
																						fprintf(fpCLLog,"\t Inside Condition---"); fflush(fpCLLog);

																						int MultiLvlBomSt = ValMultiLvlBomForScheme_CL(NClrChildobject,SchmRefTag,CmpCodeOfClrScheme,Cmpcount,SchmName,SchmRev,NewTskObjOP);
																						printf("\n\n\t   ValMultiLvlBomForScheme_CL----MultiLvlBomSt: ",MultiLvlBomSt); fflush(stdout);
																						fprintf(fpCLLog,"\n\n\t   ValMultiLvlBomForScheme_CL----MultiLvlBomSt: ",MultiLvlBomSt); fflush(fpCLLog);
																					}
																				}
																			} //End for loop

																		} //End for condn if(NewColorRevTag!=NULLTAG)
																	} //End for condn NewTskObjOP!=NULLTAG
																	else
																	{
																		printf("\n\t\t CL Task is not created, hence skipping ???  [%s]\n\n",sTaskName); fflush(stdout);
																		fprintf(fpCLLog,"\n\t\t CL Task is not created, hence skipping ???  [%s]\n\n",sTaskName); fflush(fpCLLog);
																		fprintf(fpCLErrLog,"\n\t\t CL Task is not created, hence skipping ???  [%s]\n\n",sTaskName); fflush(fpCLErrLog);
																	}
																} //End of condn checkout
															} //end for else condn--if ((MultiLvlCCABomSt<=0) && (tc_strstr(Comp_Code,"CCA")!=NULL))
														} // Else of (ReviseStatus==0)&&(strlen(NonClrChildSet)==0)
													}
													else
													{
														printf("\t ---A--No need to revive Colour: %s/%s [%s]",ColItem,ColPartRev,ColPrtLatestRlzSt);fflush(stdout);
														fprintf(fpCLLog,"\t ---A--No need to revive Colour: %s/%s [%s]",ColItem,ColPartRev,ColPrtLatestRlzSt);fflush(fpCLLog);
													}
												}
											} //End of if (t5ClSrl!=NULL)
											else
											{
												printf("\n\t\t No comp-code or colourSrl match found, hence skipping ??? \n\n"); fflush(stdout);
												fprintf(fpCLLog,"\n\t\t No comp-code or colourSrl match found, hence skipping ??? \n\n"); fflush(fpCLLog);
												fprintf(fpCLErrLog,"\n\t\t No comp-code or colourSrl match found, hence skipping ??? \n\n"); fflush(fpCLErrLog);
											}
										}
									}
									else
									{
										printf("\n\t\t Tag of SchmWithCmpcdRel is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(stdout);
										fprintf(fpCLLog,"\n\t\t Tag of SchmWithCmpcdRel is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(fpCLLog);
										fprintf(fpCLErrLog,"\n\t\t Tag of SchmWithCmpcdRel is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(fpCLErrLog);
									}
								}
								else
								{
									printf("\n\t\t Tag of SchmRefTag is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(stdout);
									fprintf(fpCLLog,"\n\t\t Tag of SchmRefTag is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(fpCLLog);
									fprintf(fpCLErrLog,"\n\t\t Tag of SchmRefTag is NULL, hence skipping rev SchmName: %s??? \n\n",SchmName); fflush(fpCLErrLog);
								}

								if (MatchColSchemeFlag==0)
								{
									printf("\n\t  No matching Scheme found for ColPartNo: %s , hence skipping ???? ",ColPartNo); fflush(stdout);
									fprintf(fpCLLog,"\n\t  No matching Scheme found for ColPartNo: %s , hence skipping ???? ",ColPartNo); fflush(fpCLLog);
									fprintf(fpCLErrLog,"\nNo matching Scheme found for ColPartNo: %s , hence skipping ???? ",ColPartNo); fflush(fpCLErrLog);

									if (strlen(NoColSchemeMatchPrts)==0)
									{
										strcpy(NoColSchemeMatchPrts,ColPartNo);
										strcat(NoColSchemeMatchPrts,",");
									}
									else
									{
										strcat(NoColSchemeMatchPrts,ColPartNo);
										strcat(NoColSchemeMatchPrts,",");
									}
								}
								// ----------------Colour Scheme-END---------------------------------------------
							} //End of loop for(zp = 0; zp<ClrCount; zp++)
						} //End of condn if(ClrCount>0)
					} //End of condn if(tRelationFind!=NULLTAG)
					// ----------------END--Get Colour Parts---------------------------------------------
	//					} //End of condn if (strlen(NonClrChildSet)>2)
	//					else
	//					{
	//						printf("---No NC-Rev bom difference present...\n"); fflush(stdout);
	//					}
					break;
				} //if end of LatestRlzSt
			} //for loop end of RlzStatusCnt

			if (RlzRevFlag==0)
			{
				printf("\t----Attached Non-colour is not in ERC Review Status, hence skipping its colour colour part ??? \n");fflush(stdout);
				fprintf(fpCLLog,"\t----Attached Non-colour is not in ERC Review Status, hence skipping its colour colour part ??? \n");fflush(fpCLLog);
			}
			/*else
			{
				tc_strcpy(NewColourPart,"");
			}*/
		} //if end of RlzStatusCnt
		else
		{
			tc_strcpy(NewColourPart,"");
		}
	} //if end of Col_Ind=Y && (strlen(Comp_Code)>0)
	else
	{
		printf("\t ----Skipping Non-colour part of col ind=N ????\n"); fflush(stdout);
		fprintf(fpCLLog,"\t ----Skipping Non-colour part of col ind=N ????\n"); fflush(fpCLLog);
	}

	printf("\n===============================================================================================================================================================\n");fflush(stdout);
	fprintf(fpCLLog,"\n===============================================================================================================================================================\n");fflush(fpCLLog);
	
	return ITK_ok;
}

int setAttributesOnDesign(tag_t* item,char* desc,char* UnitOfMeasureS)
{
	int status;
	char* ent_uom=NULL;
	tag_t unit_of_measure=NULLTAG;

	if(AOM_set_value_string(*item,"object_desc",desc)!=ITK_ok)PrintErrorStack();
	if(AOM_save(*item)!=ITK_ok)PrintErrorStack();

	ent_uom=(char *) MEM_alloc(10 * sizeof(char *));

	if(strcmp(UnitOfMeasureS,"1")==0){strcpy(ent_uom,ONE);}
	else if(strcmp(UnitOfMeasureS,"2")==0){strcpy(ent_uom,TWO);}
	else if(strcmp(UnitOfMeasureS,"3")==0){strcpy(ent_uom,THREE);}
	else if(strcmp(UnitOfMeasureS,"4")==0){strcpy(ent_uom,FOUR);}
	else if(strcmp(UnitOfMeasureS,"5")==0){strcpy(ent_uom,FIVE);}
	else if(strcmp(UnitOfMeasureS,"6")==0){strcpy(ent_uom,SIX);}
	else if(strcmp(UnitOfMeasureS,"7")==0){strcpy(ent_uom,SEVEN);}
	else if(strcmp(UnitOfMeasureS,"8")==0){strcpy(ent_uom,EIGHT);}
	else {
		strcpy(ent_uom,FOUR);
	}

	if((strcmp(ent_uom,"FOUR")!=0) && (strcmp(ent_uom,"4-Nos")!=0))
	{
		if(UOM_find_by_symbol(ent_uom,&unit_of_measure)!=ITK_ok)PrintErrorStack();
		printf("\n ent_uom:%s  \n",ent_uom);fflush(stdout);
		if(ITEM_set_unit_of_measure(*item, unit_of_measure)!=ITK_ok)PrintErrorStack();
		if(AOM_save(*item)!=ITK_ok)PrintErrorStack();
	}
}
int tm_setAttributesOnDesignRev2(tag_t* rev,char* desc,char* ColourIndS,char* t5PrtCatCodeS,char* t5ColourIDS,char* t5CoatedS,char* t5PartStatusS,char* designgroup,char* projectcode,char* mod_desc,char* DrawingIndS,char * PartTypeS,char * t5PartCodeS,char * t5AhdMakeBuyIndS,char * t5PunPCBUMakeBuyIndS,char * t5PunMakeBuyIndS,char * t5DwdMakeBuyIndS,char * NonColorPart)
{
	int status;
	double dweight=0;
	tag_t  projobj=NULLTAG;

	printf("\n\t In tm_setAttributesOnDesignRev2-->t5PrtCatCodeS: %s",t5PrtCatCodeS);fflush(stdout);

	if(AOM_lock(*rev)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"object_desc",desc)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_ColourInd",ColourIndS)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_PrtCatCode",t5PrtCatCodeS)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_ColourID",t5ColourIDS)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_Coated",t5CoatedS)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_NcPartNo",NonColorPart)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_PartStatus",t5PartStatusS)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_DesignGrp",designgroup)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_ProjectCode",projectcode)!=ITK_ok)PrintErrorStack();
	if(AOM_set_value_string(*rev,"t5_DocRemarks",mod_desc)!=ITK_ok)PrintErrorStack();

	if(AOM_set_value_string(*rev,"t5_DrawingInd",DrawingIndS)!=ITK_ok)PrintErrorStack();
	if (strstr(PartTypeS,"D")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","D")!=ITK_ok)PrintErrorStack(); }
	if (strstr(PartTypeS,"A")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","A")!=ITK_ok)PrintErrorStack(); }
	if (strstr(PartTypeS,"C")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","C")!=ITK_ok)PrintErrorStack(); }
	if (strstr(PartTypeS,"VC")!=NULL){ if( AOM_set_value_string(*rev,"t5_PartType","VC")!=ITK_ok)PrintErrorStack();}
	if (strstr(PartTypeS,"V")!=NULL) { if( AOM_set_value_string(*rev,"t5_PartType","V")!=ITK_ok)PrintErrorStack(); }

	if(AOM_set_value_string(*rev,"t5_PartCode",t5PartCodeS)!=ITK_ok)PrintErrorStack();
	if(tc_strcmp(t5AhdMakeBuyIndS,"-")==0)	{
		if(AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
	}else
	{
		if(AOM_set_value_string(*rev,"t5_AhdMakeBuyIndicator",t5AhdMakeBuyIndS)!=ITK_ok)PrintErrorStack();
	}

	if(tc_strcmp(t5PunPCBUMakeBuyIndS,"-")==0) {
		if(AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
	}else
	{
		if(AOM_set_value_string(*rev,"t5_PunPCBUMakeBuyIndicator",t5PunPCBUMakeBuyIndS)!=ITK_ok)PrintErrorStack();
	}

	if(tc_strcmp(t5PunMakeBuyIndS,"-")==0) {
		if(AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
	}else
	{
		if(AOM_set_value_string(*rev,"t5_PunMakeBuyIndicator",t5PunMakeBuyIndS)!=ITK_ok)PrintErrorStack();
	}

	if(tc_strcmp(t5DwdMakeBuyIndS,"-")==0) {
		if(AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator","")!=ITK_ok)PrintErrorStack();
	}else
	{
		if(AOM_set_value_string(*rev,"t5_DwdMakeBuyIndicator",t5DwdMakeBuyIndS)!=ITK_ok)PrintErrorStack();
	}

	if(AOM_save(*rev)!=ITK_ok)PrintErrorStack();
	if(AOM_unlock(*rev)!=ITK_ok)PrintErrorStack();
}

int tm_CreateReleasestatus(tag_t ColourRev)
{
	tag_t   release_status =NULLTAG;
	char   *ReleaseStatus=NULL;
	char* ReviewStatus=NULL;
	int status;
	int		ifail	=0;
	int	   status_count=0;
	tag_t* status_list = NULLTAG;
	logical  retain_released_date =false;

	ReviewStatus =(char *) MEM_alloc(20 * sizeof(char *));
	tc_strcpy(ReviewStatus,"T5_LcsReview");
	printf("\n\t ReviewStatus --> %s",ReviewStatus);fflush(stdout);

	if((strcmp(ReviewStatus,"T5_LcsReview")==0))
	{
		if(ITK_ok != (ifail = WSOM_ask_release_status_list(ColourRev,&status_count,&status_list)))
		{
		   return ifail;
		}
		printf("\n\t REV status_count: %d",status_count);fflush(stdout);
		if (status_count == 0)
		{
			printf("---No Status, so the Item is not yet Released....");fflush(stdout);
			printf(" *****  Stamping Releasing item  *****");fflush(stdout);
			if(ITK_ok != (ifail = CR_create_release_status(ReviewStatus,&release_status)))	 return ifail;
			if(ITK_ok != (ifail = AOM_ask_name(release_status, &ReleaseStatus))) return ifail;
			printf("\t ReleaseStatus: %s \n",ReleaseStatus);fflush(stdout);
			if( EPM_add_release_status(release_status,1,&ColourRev,retain_released_date)!=ITK_ok)PrintErrorStack();
		}
	}
	return status;
}
int tm_AssignProject(tag_t  itemRev,char* projectcode)
{
	int status;
	tag_t  projobj=NULLTAG;
	char* username=NULL;
	tag_t user_tag=NULLTAG;

	//if(AOM_lock(itemRev)!=ITK_ok)PrintErrorStack();
	printf("\n projectcode [%s]\n",projectcode);fflush(stdout);
	if(PROJ_find(projectcode,&projobj)!=ITK_ok)PrintErrorStack();
	printf("\n Assigned to Project111\n");fflush(stdout);

	if(projobj !=NULLTAG)
	{
	//	POM_get_user(&username,&user_tag);
	//	if(PROJ_add_members(projobj,1,&user_tag)!=ITK_ok)PrintErrorStack();
		if(PROJ_assign_objects(1 ,&projobj ,1 ,&itemRev)!=ITK_ok)PrintErrorStack();
		printf("\n Assigned to Project\n");fflush(stdout);
	}
	else
	{
		printf("\n Project not found\n");fflush(stdout);
	}
	//  if(AOM_save(itemRev)!=ITK_ok)PrintErrorStack();
	//  if(AOM_unlock(itemRev)!=ITK_ok)PrintErrorStack();

  return status;
}

int tm_OccurSetTopLineClr(tag_t  clrbvrTag, char* UsesPartNo)
{
	int stat = ITK_ok;
	int status;
	int ifail = ITK_ok;
    tag_t UseMaster = NULLTAG;
	tag_t Nrev = NULLTAG;
	char *ChildPartNo = NULL;
	char *ChildPartRevSeq = NULL;
	tag_t objNameType=NULLTAG;
	char type_name[TCTYPE_name_size_c+1];
	tag_t *occs=NULL;

	printf("\n Uses Part Number is ------> %s",UsesPartNo);fflush(stdout);
    if(ITEM_find_item(UsesPartNo,&UseMaster)!=ITK_ok)PrintErrorStack();
	printf("\n UseMaster found------>");fflush(stdout);

	if(ITEM_ask_latest_rev(UseMaster, &Nrev)!=ITK_ok)PrintErrorStack();
	printf("\n Childrev found------>");fflush(stdout);

	if(AOM_ask_value_string(Nrev,"item_id",&ChildPartNo)!=ITK_ok)PrintErrorStack();
	if(AOM_ask_value_string(Nrev,"item_revision_id",&ChildPartRevSeq)!=ITK_ok)PrintErrorStack();
	printf("\n ChildPartNo: %s--%s ..............",ChildPartNo,ChildPartRevSeq);fflush(stdout);

	if(TCTYPE_ask_object_type(Nrev,&objNameType)!=ITK_ok)PrintErrorStack();
	if(TCTYPE_ask_name(objNameType,type_name)!=ITK_ok)PrintErrorStack();
	printf("\t type_name:: [%s] \n",type_name);

	//if(PS_create_occurrences(clrbvrTag, Nrev, NULLTAG,1, &occs )!=ITK_ok)PrintErrorStack();
	if(PS_create_occurrences(clrbvrTag, UseMaster, NULLTAG,1, &occs )!=ITK_ok)PrintErrorStack();
	printf("\n PS_create_occurrences successfully in PSE------->");fflush(stdout);

	if(AOM_save( clrbvrTag) !=ITK_ok)PrintErrorStack();
	printf("\n AOM_save successfully of clrbvrTag------->");fflush(stdout);

	if(AOM_refresh(clrbvrTag,0)!=ITK_ok)PrintErrorStack();
	printf("\n AOM_refresh successfully of clrbvrTag------->\n"); fflush(stdout);

	return ITK_ok;
}
static void initialise_attribute (char *name,  int *attribute)
{
    int ifail, mode;

    if(BOM_line_look_up_attribute (name, attribute)!=ITK_ok)PrintErrorStack();
    if(BOM_line_ask_attribute_mode (*attribute, &mode)!=ITK_ok)PrintErrorStack();

    if (mode != BOM_attribute_mode_string)
      { printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode);
        exit(0);
      }
}
static void initialise (void)
{
    int ifail;

	printf("\nAuto Login--\n\n",ifail); fflush(stdout);

    /* <kc> pr#397778 July2595 exit if autologin() fail */
    if ((ifail = ITK_auto_login()) != ITK_ok)
    fprintf(stderr,"Login fail !!: Error code = %d \n\n",ifail);fflush(stderr);

	/* these tokens come from bom_attr.h */
    initialise_attribute (bomAttr_lineName, &name_attribute);
}
