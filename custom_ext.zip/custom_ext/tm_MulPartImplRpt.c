/*******************
*  File            :   tm_MulPartImplRpt.c
*  Created By      :   Vijay Khandare
*  Created On      :   08-07-2024
*  Purpose         :   Multi Part Implosion Report...
*  TZ			   :   
*******************/
#include <stdlib.h>
#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>                  
#include <setjmp.h>
#include <ae/ae_errors.h>           
#include <ae/ae_types.h>           
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <tc/tc_startup.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <sa/groupmember.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <pie/pie.h>
#include <bom/bom_attr.h>
#include <bom/bom_tokens.h>
#include <tc/envelope.h>
#include <tccore/aom.h>
#include <res/res_itk.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <itk/mem.h>
#include <tccore/item.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <time.h>
#include <pie/pie.h> 
#include <tccore/uom.h>
#include <user_exits/user_exits.h>
#include <rdv/arch.h>
#include <stdlib.h>
#include <string.h>
#include <textsrv/textserver.h>
#include <tccore/item_errors.h>
#include <stdlib.h>
#include <ae/dataset.h>
#include <assert.h>
#include <stdbool.h>
#include <tccore/libtccore_exports.h>
#define ITK_err 950001

#define MAX_SIZE 1000
#define STRING_LENGTH 10000

#define CHECK_FAIL if (ifail != 0) { printf ("line %d (ifail %d)\n", __LINE__, ifail); exit (0);}
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { return ifail;}

#define ITK_CALL 	 \
status=X; 	 \
if (status != ITK_ok)  	 \
{	 \
int	 index = 0;	 \
int	 n_ifails = 0;	 \
const int*	 severities = 0;	 \
const int*	 ifails = 0;	 \
const char**	texts = NULL;	 \
\
EMH_ask_errors( &n_ifails, &severities, &ifails, &texts); \
printf("%3d error with #X\n", n_ifails);	 \
for( index=0; index<n_ifails; index++)	 \
{	 \
printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
}	 \
return status;	 \
}	 \
;			
int 				status						= 0; 
int 				X							= 0;		

void MulIMPLstrcat(char **src,char* dest)
{
	 char * desc = dest ? dest : "NA";

	const size_t a = strlen(*src);
	const size_t b = strlen(desc);
	const size_t size_ab = a + b + 2;
	
	*src = (char *)MEM_realloc(*src,size_ab * sizeof(char *));

	tc_strcat(*src , desc);

}

char* replacestr(char *str, const char *find, const char *replacestr) 
{
    // Allocate memory for the new string
    char *result;
    int i, count = 0;
    int find_len = strlen(find);
    int replacestr_len = strlen(replacestr);

    // Count the number of times the 'find' substring occurs in the original string
    for (i = 0; str[i] != '\0'; i++) 
	{
        if (strstr(&str[i], find) == &str[i])
		{
            count++;
           // Jump index to the next occurrence of the 'find' substring
            i += find_len - 1;
        }
    }
    // Allocate memory for the new string
    result = (char *)MEM_alloc(i + count * (replacestr_len - find_len) + 1);  
    i = 0;
    while (*str)
	{
        // Compare the substring with the result
        if (strstr(str, find) == str) 
		{
            strcpy(&result[i], replacestr);
            i += replacestr_len;
            str += find_len;
        } 
		else 
	    {
            result[i++] = *str++;
        }
    }
    result[i] = '\0';
    //printf("replacestrd string: %s\n", result);
    return result;
}

void MulsetFixedSize(char **str, size_t size) 
{
    // Dynamically allocate memory for the string
    *str = (char *)MEM_realloc(*str, size + 1); // +1 for null terminator
    
    // If realloc fails, handle the error
    if (*str == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
    
    // If the length of the string is less than the desired size, add spaces
    size_t len = strlen(*str);
    if (len < size) {
        memset(*str + len, ' ', size - len);
        (*str)[size] = '\0'; // Null-terminate the string
    }
    // If the length of the string is greater than the desired size, remove extra characters
    else if (len > size) {
        (*str)[size] = '\0'; // Null-terminate the string at the desired size
    }
}

bool isStringAlreadyCopiedMul(char *targetStrings[STRING_LENGTH], int targetCount, char *str) 
{
	int  i = 0;
    for(i = 0; i < targetCount; i++) 
    {
        if(strcmp(targetStrings[i], str) == 0) 
    	{
            return true;
        }
    }
    return false;
}

char     commonStringsUnq[1000][10000];
bool isStringAlreadyCopiedMulUnq(char targetStrings[][STRING_LENGTH], int targetCount, char *str)
{
        int  i = 0;
    for(i = 0; i < targetCount; i++)
    {
        if(strcmp(targetStrings[i], str) == 0)
        {
            return true;
        }
    }
    return false;
}

int tm_PartImplFnMul(tag_t ChildPrtItmRev,char* PlantName,char* FileFormat,int row_cnt,tag_t* AmdentableRowset,tag_t RevRuleObjTag,char** OutputCKD,char** OutputCargo,
char** OutputDefence,char** OutputEPA,char** OutputTipper,char** OutputWT,char** UniqueVC,int* CKDSum,
int* CargoSum,int* Defencesum,int* EPAsum,int* Tippersum,int* WTsum)
{
	
	char         *PartNo                   = NULL;
	char         *PartRevSeq               = NULL;
	char         *PartRevSeqV              = NULL;
	char         *PartDrStaus              = NULL;
	char         *PartDesc                 = NULL;
	char         *PartDescV                = NULL;
	char         *PartType                 = NULL;
	char         *MakeBy                   = NULL;
	int          ALLUnqVcSum               = 0;
	int          ALLUnqVcSumUnq            = 0;
	
	int          n_ParentFound             = 0;
	int          *n_Parent                 = 0;
	tag_t        *ParentSet                = NULLTAG;
	
	//int CKDSum=0,CargoSum=0,Defencesum=0,EPAsum=0,Tippersum=0, WTsum=0;
	
	if(tc_strcmp(PlantName,"DWD")==0)
    {
	    ITK_CALL(AOM_UIF_ask_value(ChildPrtItmRev,"t5_DwdMakeBuyIndicator",&MakeBy));
		printf("DWD make by is  = %s\n",MakeBy);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"JSR")==0)
    {
	    ITK_CALL(AOM_UIF_ask_value(ChildPrtItmRev,"t5_JsrMakeBuyIndicator",&MakeBy));
        printf("JSR make by is  = %s\n",MakeBy);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"LKO")==0)
    {
	    ITK_CALL(AOM_UIF_ask_value(ChildPrtItmRev,"t5_LkoMakeBuyIndicator",&MakeBy));
        printf("LKO make by is  = %s\n",MakeBy);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PNR")==0)
    {
	    ITK_CALL(AOM_UIF_ask_value(ChildPrtItmRev,"t5_PnrMakeBuyIndicator",&MakeBy));
        printf("PNR make by is  = %s\n",MakeBy);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PUNE")==0)
    {
	    ITK_CALL(AOM_UIF_ask_value(ChildPrtItmRev,"t5_PunMakeBuyIndicator",&MakeBy));
    	printf("Pune make by is  = %s\n",MakeBy);fflush(stdout);
	}
	
	//Parts details.............................................................
	
	ITK_CALL(AOM_ask_value_string(ChildPrtItmRev,"item_id",&PartNo));
	printf("Part no is = %s\n",PartNo);fflush(stdout);
	
	ITK_CALL(AOM_UIF_ask_value(ChildPrtItmRev,"item_revision_id",&PartRevSeq));
	printf("Part revision/sequence no is = %s\n",PartRevSeq);fflush(stdout);
	
	PartRevSeqV=replacestr(PartRevSeq, ",", ";");
	
	ITK_CALL(AOM_ask_value_string(ChildPrtItmRev,"t5_PartStatus",&PartDrStaus));
	printf("Part DR status is = %s\n",PartDrStaus);fflush(stdout);
	
	ITK_CALL(AOM_ask_value_string(ChildPrtItmRev,"current_desc",&PartDesc));
	printf("Part PartDesc is = %s\n",PartDesc);fflush(stdout);
    
	PartDescV = replacestr(PartDesc, ",", " ");
	
	ITK_CALL(AOM_ask_value_string(ChildPrtItmRev,"t5_PartType",&PartType));
	printf("Part PartType is = %s\n",PartType);fflush(stdout);
	
	//...........................................................................

	if(tc_strcmp(FileFormat,".txt") == 0)
    {
		//CKD
		MulIMPLstrcat(OutputCKD,"    Impl of Part : ");
        MulIMPLstrcat(OutputCKD,PartNo);
        MulIMPLstrcat(OutputCKD,"\n");
        MulIMPLstrcat(OutputCKD,"    Revision     : ");
        MulIMPLstrcat(OutputCKD,PartRevSeqV);
        MulIMPLstrcat(OutputCKD,"\n");
        MulIMPLstrcat(OutputCKD,"    Description  : ");
        MulIMPLstrcat(OutputCKD,PartDescV);
        MulIMPLstrcat(OutputCKD,"\n");
        MulIMPLstrcat(OutputCKD,"    DR Stat      : ");
        MulIMPLstrcat(OutputCKD,PartDrStaus);
        MulIMPLstrcat(OutputCKD,"\n");
        MulIMPLstrcat(OutputCKD,"    Part Type    : ");
        MulIMPLstrcat(OutputCKD,PartType);
        MulIMPLstrcat(OutputCKD,"\n");
        MulIMPLstrcat(OutputCKD,"    Make By      : ");
        MulIMPLstrcat(OutputCKD,MakeBy);
        MulIMPLstrcat(OutputCKD,"\n");
        MulIMPLstrcat(OutputCKD,"    ===========================================\n");
		MulIMPLstrcat(OutputCKD,"    ===============               ==================================            ==========    \n");
        MulIMPLstrcat(OutputCKD,"        VC LIST                              DESCRIPTION                          DR Stat   \n");
        MulIMPLstrcat(OutputCKD,"    ===============               ==================================            ==========    \n");
        
	    //Cargo
		MulIMPLstrcat(OutputCargo,"    Impl of Part : ");
        MulIMPLstrcat(OutputCargo,PartNo);
        MulIMPLstrcat(OutputCargo,"\n");
        MulIMPLstrcat(OutputCargo,"    Revision     : ");
        MulIMPLstrcat(OutputCargo,PartRevSeqV);
        MulIMPLstrcat(OutputCargo,"\n");
        MulIMPLstrcat(OutputCargo,"    Description  : ");
        MulIMPLstrcat(OutputCargo,PartDescV);
        MulIMPLstrcat(OutputCargo,"\n");
        MulIMPLstrcat(OutputCargo,"    DR Stat      : ");
        MulIMPLstrcat(OutputCargo,PartDrStaus);
        MulIMPLstrcat(OutputCargo,"\n");
        MulIMPLstrcat(OutputCargo,"    Part Type    : ");
        MulIMPLstrcat(OutputCargo,PartType);
        MulIMPLstrcat(OutputCargo,"\n");
        MulIMPLstrcat(OutputCargo,"    Make By      : ");
        MulIMPLstrcat(OutputCargo,MakeBy);
        MulIMPLstrcat(OutputCargo,"\n");
        MulIMPLstrcat(OutputCargo,"    ===========================================\n");
		MulIMPLstrcat(OutputCargo,"    ===============               ==================================            ==========    \n");
        MulIMPLstrcat(OutputCargo,"        VC LIST                              DESCRIPTION                          DR Stat   \n");
        MulIMPLstrcat(OutputCargo,"    ===============               ==================================            ==========    \n");
        
        //Defence
		MulIMPLstrcat(OutputDefence,"    Impl of Part : ");
        MulIMPLstrcat(OutputDefence,PartNo);
        MulIMPLstrcat(OutputDefence,"\n");
        MulIMPLstrcat(OutputDefence,"    Revision     : ");
        MulIMPLstrcat(OutputDefence,PartRevSeqV);
        MulIMPLstrcat(OutputDefence,"\n");
        MulIMPLstrcat(OutputDefence,"    Description  : ");
        MulIMPLstrcat(OutputDefence,PartDescV);
        MulIMPLstrcat(OutputDefence,"\n");
        MulIMPLstrcat(OutputDefence,"    DR Stat      : ");
        MulIMPLstrcat(OutputDefence,PartDrStaus);
        MulIMPLstrcat(OutputDefence,"\n");
        MulIMPLstrcat(OutputDefence,"    Part Type    : ");
        MulIMPLstrcat(OutputDefence,PartType);
        MulIMPLstrcat(OutputDefence,"\n");
        MulIMPLstrcat(OutputDefence,"    Make By      : ");
        MulIMPLstrcat(OutputDefence,MakeBy);
        MulIMPLstrcat(OutputDefence,"\n");
        MulIMPLstrcat(OutputDefence,"    ===========================================\n");
		MulIMPLstrcat(OutputDefence,"    ===============               ==================================            ==========    \n");
        MulIMPLstrcat(OutputDefence,"        VC LIST                              DESCRIPTION                          DR Stat   \n");
        MulIMPLstrcat(OutputDefence,"    ===============               ==================================            ==========    \n");
        
        //EPA
		MulIMPLstrcat(OutputEPA,"    Impl of Part : ");
        MulIMPLstrcat(OutputEPA,PartNo);
        MulIMPLstrcat(OutputEPA,"\n");
        MulIMPLstrcat(OutputEPA,"    Revision     : ");
        MulIMPLstrcat(OutputEPA,PartRevSeqV);
        MulIMPLstrcat(OutputEPA,"\n");
        MulIMPLstrcat(OutputEPA,"    Description  : ");
        MulIMPLstrcat(OutputEPA,PartDescV);
        MulIMPLstrcat(OutputEPA,"\n");
        MulIMPLstrcat(OutputEPA,"    DR Stat      : ");
        MulIMPLstrcat(OutputEPA,PartDrStaus);
        MulIMPLstrcat(OutputEPA,"\n");
        MulIMPLstrcat(OutputEPA,"    Part Type    : ");
        MulIMPLstrcat(OutputEPA,PartType);
        MulIMPLstrcat(OutputEPA,"\n");
        MulIMPLstrcat(OutputEPA,"    Make By      : ");
        MulIMPLstrcat(OutputEPA,MakeBy);
        MulIMPLstrcat(OutputEPA,"\n");
        MulIMPLstrcat(OutputEPA,"    ===========================================\n");
		MulIMPLstrcat(OutputEPA,"    ===============               ==================================            ==========    \n");
        MulIMPLstrcat(OutputEPA,"        VC LIST                              DESCRIPTION                          DR Stat   \n");
        MulIMPLstrcat(OutputEPA,"    ===============               ==================================            ==========    \n");
        
        //Tipper
		MulIMPLstrcat(OutputTipper,"    Impl of Part : ");
        MulIMPLstrcat(OutputTipper,PartNo);
        MulIMPLstrcat(OutputTipper,"\n");
        MulIMPLstrcat(OutputTipper,"    Revision     : ");
        MulIMPLstrcat(OutputTipper,PartRevSeqV);
        MulIMPLstrcat(OutputTipper,"\n");
        MulIMPLstrcat(OutputTipper,"    Description  : ");
        MulIMPLstrcat(OutputTipper,PartDescV);
        MulIMPLstrcat(OutputTipper,"\n");
        MulIMPLstrcat(OutputTipper,"    DR Stat      : ");
        MulIMPLstrcat(OutputTipper,PartDrStaus);
        MulIMPLstrcat(OutputTipper,"\n");
        MulIMPLstrcat(OutputTipper,"    Part Type    : ");
        MulIMPLstrcat(OutputTipper,PartType);
        MulIMPLstrcat(OutputTipper,"\n");
        MulIMPLstrcat(OutputTipper,"    Make By      : ");
        MulIMPLstrcat(OutputTipper,MakeBy);
        MulIMPLstrcat(OutputTipper,"\n");
        MulIMPLstrcat(OutputTipper,"    ===========================================\n");
		MulIMPLstrcat(OutputTipper,"    ===============               ==================================            ==========    \n");
        MulIMPLstrcat(OutputTipper,"        VC LIST                              DESCRIPTION                          DR Stat   \n");
        MulIMPLstrcat(OutputTipper,"    ===============               ==================================            ==========    \n");
       
        //WT
		MulIMPLstrcat(OutputWT,"    Impl of Part : ");
        MulIMPLstrcat(OutputWT,PartNo);
        MulIMPLstrcat(OutputWT,"\n");
        MulIMPLstrcat(OutputWT,"    Revision     : ");
        MulIMPLstrcat(OutputWT,PartRevSeqV);
        MulIMPLstrcat(OutputWT,"\n");
        MulIMPLstrcat(OutputWT,"    Description  : ");
        MulIMPLstrcat(OutputWT,PartDescV);
        MulIMPLstrcat(OutputWT,"\n");
        MulIMPLstrcat(OutputWT,"    DR Stat      : ");
        MulIMPLstrcat(OutputWT,PartDrStaus);
        MulIMPLstrcat(OutputWT,"\n");
        MulIMPLstrcat(OutputWT,"    Part Type    : ");
        MulIMPLstrcat(OutputWT,PartType);
        MulIMPLstrcat(OutputWT,"\n");
        MulIMPLstrcat(OutputWT,"    Make By      : ");
        MulIMPLstrcat(OutputWT,MakeBy);
        MulIMPLstrcat(OutputWT,"\n");
        MulIMPLstrcat(OutputWT,"    ===========================================\n");
		MulIMPLstrcat(OutputWT,"    ===============               ==================================            ==========    \n");
        MulIMPLstrcat(OutputWT,"        VC LIST                              DESCRIPTION                          DR Stat   \n");
        MulIMPLstrcat(OutputWT,"    ===============               ==================================            ==========    \n");
	}
	
	int          RevCount                  = 0;
	tag_t        ItemMaster                = NULLTAG;
	tag_t        PartLtstRev               = NULLTAG;
	tag_t        *PartLtstRevSet           = NULLTAG;
	char         *PartRlzStat              = NULL;
	
	//ITK_CALL(PS_where_used_all(PartItem,PS_where_used_all_levels,&n_ParentFound,&n_Parent,&ParentSet));
	
	//ITK_CALL(PS_where_used_all(PartItem,PS_where_used_all_levels,&n_ParentFound,&n_Parent,&ParentSet));
	
	ITK_CALL(PS_where_used_configured(ChildPrtItmRev,RevRuleObjTag,PS_where_used_all_levels,&n_ParentFound,&n_Parent,&ParentSet));
	
	if(n_ParentFound > 0)
    {
		
	}
	else
	{
		ITEM_ask_item_of_rev(ChildPrtItmRev, &ItemMaster);
	    //AOM_ask_value_string(ItemMaster, "item_id", &ItemMaster);
		
		ITK_CALL(ITEM_ask_latest_rev(ItemMaster,&PartLtstRev));
		
		ITK_CALL(AOM_UIF_ask_value(PartLtstRev,"release_status_list",&PartRlzStat));
		printf("Part PartRlzStat is ... = %s\n",PartRlzStat);fflush(stdout);
		if(tc_strstr(PartRlzStat,"ERC Released")!= NULL)
		{
		    ITK_CALL(PS_where_used_configured(PartLtstRev,RevRuleObjTag,PS_where_used_all_levels,&n_ParentFound,&n_Parent,&ParentSet));
		}
		else
		{
			ITK_CALL(ITEM_list_all_revs(ItemMaster,&RevCount,&PartLtstRevSet));
			
			if(RevCount > 0)
			{
				printf("No of rev is ... = %d\n",RevCount);fflush(stdout);
				int RevItr = 0;
				for(RevItr = 0; RevItr < RevCount; RevItr++)
				{
					tag_t     PrtRevObj         = NULLTAG;
					char      *PrtRlzVal        = NULL;
					char      *PrtRevSeq        = NULL;
					PrtRevObj = PartLtstRevSet[RevItr];
					
					ITK_CALL(AOM_UIF_ask_value(PrtRevObj,"release_status_list",&PrtRlzVal));
					//printf("Part PrtRlzVal is ... = %s\n",PrtRlzVal);fflush(stdout);	
					
					if(tc_strstr(PrtRlzVal,"ERC Released")!= NULL)
		            {
						ITK_CALL(AOM_UIF_ask_value(PrtRevObj,"item_revision_id",&PrtRevSeq));
	                    printf("PrtRevSeq value is ... = %s\n",PrtRevSeq);fflush(stdout);
						
		                ITK_CALL(PS_where_used_configured(PrtRevObj,RevRuleObjTag,PS_where_used_all_levels,&n_ParentFound,&n_Parent,&ParentSet));
		            }
					
				}
			}
			
		}
	}
	
	printf("Number of Parent found part is  = %d\n",n_ParentFound);fflush(stdout);
	
    if(n_ParentFound > 0)
    {
		char **commonStrings = (char **)MEM_alloc(MAX_SIZE * sizeof(char *));
	    
	    if (commonStrings == NULL) 
	    {
            printf("Memory allocation failed\n");
            return 1;
	    }
        int itr = 0;
	    for (itr = 0; itr < MAX_SIZE; itr++) 
	    {
            commonStrings[itr] = (char *)malloc(STRING_LENGTH * sizeof(char));
            if(commonStrings[itr] == NULL) 
	    	{
            printf("Memory allocation failed\n");
            return 1;
	    	}
	    }
	    
    	//Compare Amden vc .........................
        
    	int index;
        for( index = 0; index < n_ParentFound; index++ )
        {
            if ( index == n_ParentFound - 1 || n_Parent[index] >= n_Parent[index+1] )
            {
    	        tag_t     ParentItem        = NULLTAG;
    	        char      *ParentNo         = NULL;
    	        char      *ParentType       = NULL;
    	        char      *ParentDR         = NULL;
    	        char      *ParentDesc       = NULL;
    	        char      *ParentDescV      = NULL;
				char      *ParentRlzS       = NULL;
				char      *ParentRlzSV      = NULL;
				char      *ParentRlzSV1     = NULL;
				char      *ParentPrtType    = NULL;	    	    		    		    	
				char      *RevisionId       = NULL;	    	    		    		    	

    	        ParentItem = ParentSet[index];

    	        ITK_CALL(AOM_ask_value_string(ParentItem,"item_id",&ParentNo));
                //printf("Parent  is = %s\n",ParentNo);fflush(stdout);
    	        ITK_CALL(AOM_ask_value_string(ParentItem,"object_type",&ParentType));
                //printf("Parent type is = %s\n",ParentType);fflush(stdout);
				
				ITK_CALL(AOM_ask_value_string(ParentItem,"t5_PartType",&ParentPrtType));
				//printf("ParentPart Typeis..... = %s\n",ParentPrtType);fflush(stdout);current_revision_id
				
				ITK_CALL(AOM_ask_value_string(ParentItem,"item_revision_id",&RevisionId));
				//printf("Parent Revision Id  is..... = %s\n",RevisionId);fflush(stdout);

    	        ITK_CALL(AOM_ask_value_string(ParentItem,"t5_PartStatus",&ParentDR));
                //printf("Parent DR status is = %s\n",ParentDR);fflush(stdout);
    	        ITK_CALL(AOM_ask_value_string(ParentItem,"object_desc",&ParentDesc));
    	        ParentDescV=replacestr(ParentDesc, ",", " ");

                MulsetFixedSize(&ParentDescV, 30);
				MulsetFixedSize(&RevisionId, 5);
				
				ITK_CALL(AOM_UIF_ask_value(ParentItem,"release_status_list",&ParentRlzS));
				//printf("Parent Release status is... = %s\n",ParentRlzS);fflush(stdout);
				ParentRlzSV=replacestr(ParentRlzS, ",", " ");
				ParentRlzSV1=replacestr(ParentRlzSV, "ERC Review", " ");
    	        //printf("Parent Desc is = %s\n",ParentDescV);fflush(stdout);

				if((tc_strcmp(ParentPrtType,"VC") == 0 || tc_strcmp(ParentPrtType,"VCCR") == 0) && tc_strstr(ParentRlzS,"ERC Released")!= NULL)
                {
					if(!isStringAlreadyCopiedMul(commonStrings, ALLUnqVcSum, ParentNo))
                    {
					    strcpy(commonStrings[ALLUnqVcSum++],ParentNo);

					    int Amdenitr = 0;
    		            for(Amdenitr = 0 ; Amdenitr < row_cnt ; Amdenitr++)
    	                {
							tag_t       AmdentableRow             = NULLTAG;
    	                    char        *AmdenVC                  = NULL;
    	                    char        *AmdenAgency              = NULL;
							
    	                    AmdentableRow = AmdentableRowset[Amdenitr];
                            ITK_CALL(AOM_ask_value_string(AmdentableRow,"t5_AmdPartNumber",&AmdenVC));
    	                    //printf("\n Amden VC for Compare ... = %s\n",AmdenVC);fflush(stdout);    
    	                    ITK_CALL(AOM_ask_value_string(AmdentableRow,"t5_AmdAgency",&AmdenAgency));
    	                    //printf("\n Amden agency .... = %s\n",AmdenAgency);fflush(stdout);
    		            
    	                	if(tc_strcmp(FileFormat,".csv") == 0)
                            {
                                
							    if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"CKD") == 0))
    	                	    {
                                    //CKD..................................................
								    MulIMPLstrcat(OutputCKD,PartNo);
									MulIMPLstrcat(OutputCKD," ");
                                    MulIMPLstrcat(OutputCKD,PartRevSeqV);
                                    MulIMPLstrcat(OutputCKD,",");
                                    MulIMPLstrcat(OutputCKD,PartDescV);
                                    MulIMPLstrcat(OutputCKD,",");
                                    MulIMPLstrcat(OutputCKD,PartDrStaus);
                                    MulIMPLstrcat(OutputCKD,",");
                                    MulIMPLstrcat(OutputCKD,PartType);
                                    MulIMPLstrcat(OutputCKD,",");
    	                	    	MulIMPLstrcat(OutputCKD,ParentNo);
    	                	    	MulIMPLstrcat(OutputCKD,",");
    	                	    	MulIMPLstrcat(OutputCKD,ParentDescV);
    	                	    	MulIMPLstrcat(OutputCKD,",");
    	                	    	MulIMPLstrcat(OutputCKD,ParentDR);
    	                	    	MulIMPLstrcat(OutputCKD,"\n");
									
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *CKDSum, ParentNo)) 
                                    {

					                    strcpy(commonStringsUnq[*CKDSum],ParentNo);
										
										*CKDSum = *CKDSum+1;

    	                	    	    MulIMPLstrcat(UniqueVC,ParentNo);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,RevisionId);
										MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDescV);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDR);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,"CKD");
    	                	    	    MulIMPLstrcat(UniqueVC,"\n");
									}
							    
    	                	    	//.........................................................
    		            	    }
    	                	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Cargo") == 0))
    	                	    {
    	                	    	//*CargoSum = *CargoSum+1;
    	                	    
    	                	    	//Cargo
                                    MulIMPLstrcat(OutputCargo,PartNo);
                                    MulIMPLstrcat(OutputCargo," ");
                                    MulIMPLstrcat(OutputCargo,PartRevSeqV);
                                    MulIMPLstrcat(OutputCargo,",");
                                    MulIMPLstrcat(OutputCargo,PartDescV);
                                    MulIMPLstrcat(OutputCargo,",");
                                    MulIMPLstrcat(OutputCargo,PartDrStaus);
                                    MulIMPLstrcat(OutputCargo,",");
                                    MulIMPLstrcat(OutputCargo,PartType);
                                    MulIMPLstrcat(OutputCargo,",");
    	                	    	MulIMPLstrcat(OutputCargo,ParentNo);
    	                	    	MulIMPLstrcat(OutputCargo,",");
    	                	    	MulIMPLstrcat(OutputCargo,ParentDescV);
    	                	    	MulIMPLstrcat(OutputCargo,",");
    	                	    	MulIMPLstrcat(OutputCargo,ParentDR);
    	                	    	MulIMPLstrcat(OutputCargo,"\n");
							    
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *CargoSum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*CargoSum],ParentNo);
										*CargoSum = *CargoSum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,ParentNo);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,RevisionId);
										MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDescV);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDR);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,"Cargo");
    	                	    	    MulIMPLstrcat(UniqueVC,"\n");
									}
    	                	      
    	                	    }
    	                	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Defence") == 0))
    	                	    {
    	                	        //*Defencesum = *Defencesum+1;
							    
    	                	        //Defence
    	                	        MulIMPLstrcat(OutputDefence,PartNo);
                                    MulIMPLstrcat(OutputDefence," ");
                                    MulIMPLstrcat(OutputDefence,PartRevSeqV);
                                    MulIMPLstrcat(OutputDefence,",");
                                    MulIMPLstrcat(OutputDefence,PartDescV);
                                    MulIMPLstrcat(OutputDefence,",");
                                    MulIMPLstrcat(OutputDefence,PartDrStaus);
                                    MulIMPLstrcat(OutputDefence,",");
                                    MulIMPLstrcat(OutputDefence,PartType);
                                    MulIMPLstrcat(OutputDefence,",");
    	                	    	MulIMPLstrcat(OutputDefence,ParentNo);
    	                	    	MulIMPLstrcat(OutputDefence,",");
    	                	    	MulIMPLstrcat(OutputDefence,ParentDescV);
    	                	    	MulIMPLstrcat(OutputDefence,",");
    	                	    	MulIMPLstrcat(OutputDefence,ParentDR);
    	                	    	MulIMPLstrcat(OutputDefence,"\n");
    	                	        
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *Defencesum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*Defencesum],ParentNo);
										*Defencesum = *Defencesum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,ParentNo);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,RevisionId);
										MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDescV);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDR);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,"Defence");
    	                	    	    MulIMPLstrcat(UniqueVC,"\n");
									}
					    	    	
    	                	    }
    	                	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && ((tc_strcmp(AmdenAgency,"EPA") == 0) || 
								(tc_strcmp(AmdenAgency,"VEHICLE") == 0) || (tc_strcmp(AmdenAgency,"Vehicle") == 0) || 
							    (tc_strcmp(AmdenAgency,"Maxicab") == 0) || (tc_strcmp(AmdenAgency,"ACE GOLD RDE") == 0) ||
								(tc_strcmp(AmdenAgency,"EPA RDE") == 0)))
    	                	    {
    	                	        //*EPAsum = *EPAsum+1;
    	                	        //EPA
    	                	        MulIMPLstrcat(OutputEPA,PartNo);
                                    MulIMPLstrcat(OutputEPA," ");
                                    MulIMPLstrcat(OutputEPA,PartRevSeqV);
                                    MulIMPLstrcat(OutputEPA,",");
                                    MulIMPLstrcat(OutputEPA,PartDescV);
                                    MulIMPLstrcat(OutputEPA,",");
                                    MulIMPLstrcat(OutputEPA,PartDrStaus);
                                    MulIMPLstrcat(OutputEPA,",");
                                    MulIMPLstrcat(OutputEPA,PartType);
                                    MulIMPLstrcat(OutputEPA,",");
    	                	    	MulIMPLstrcat(OutputEPA,ParentNo);
    	                	    	MulIMPLstrcat(OutputEPA,",");
    	                	    	MulIMPLstrcat(OutputEPA,ParentDescV);
    	                	    	MulIMPLstrcat(OutputEPA,",");
    	                	    	MulIMPLstrcat(OutputEPA,ParentDR);
    	                	    	MulIMPLstrcat(OutputEPA,"\n");
    	                	        
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *EPAsum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*EPAsum],ParentNo);
										*EPAsum = *EPAsum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,ParentNo);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,RevisionId);
										MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDescV);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDR);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,"EPA");
    	                	    	    MulIMPLstrcat(UniqueVC,"\n");
									}

    	                	    }
    	                	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Tipper") == 0))
    	                	    {
    	                	        //*Tippersum = *Tippersum+1;
    	                	        
    	                	        //Tipper
    	                	        MulIMPLstrcat(OutputTipper,PartNo);
                                    MulIMPLstrcat(OutputTipper," ");
                                    MulIMPLstrcat(OutputTipper,PartRevSeqV);
                                    MulIMPLstrcat(OutputTipper,",");
                                    MulIMPLstrcat(OutputTipper,PartDescV);
                                    MulIMPLstrcat(OutputTipper,",");
                                    MulIMPLstrcat(OutputTipper,PartDrStaus);
                                    MulIMPLstrcat(OutputTipper,",");
                                    MulIMPLstrcat(OutputTipper,PartType);
                                    MulIMPLstrcat(OutputTipper,",");
    	                	    	MulIMPLstrcat(OutputTipper,ParentNo);
    	                	    	MulIMPLstrcat(OutputTipper,",");
    	                	    	MulIMPLstrcat(OutputTipper,ParentDescV);
    	                	    	MulIMPLstrcat(OutputTipper,",");
    	                	    	MulIMPLstrcat(OutputTipper,ParentDR);
    	                	    	MulIMPLstrcat(OutputTipper,"\n");
    	                	        
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *Tippersum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*Tippersum],ParentNo);
										*Tippersum = *Tippersum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,ParentNo);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,RevisionId);
										MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDescV);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDR);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,"Tipper");
    	                	    	    MulIMPLstrcat(UniqueVC,"\n");
									}
    	                	    
    	                	    }
    	                	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"WT") == 0))
    	                	    {
    	                	        //*WTsum = *WTsum+1;
    	                	        //WT
    	                	        MulIMPLstrcat(OutputWT,PartNo);
                                    MulIMPLstrcat(OutputWT," ");
                                    MulIMPLstrcat(OutputWT,PartRevSeqV);
                                    MulIMPLstrcat(OutputWT,",");
                                    MulIMPLstrcat(OutputWT,PartDescV);
                                    MulIMPLstrcat(OutputWT,",");
                                    MulIMPLstrcat(OutputWT,PartDrStaus);
                                    MulIMPLstrcat(OutputWT,",");
                                    MulIMPLstrcat(OutputWT,PartType);
                                    MulIMPLstrcat(OutputWT,",");
    	                	    	MulIMPLstrcat(OutputWT,ParentNo);
    	                	    	MulIMPLstrcat(OutputWT,",");
    	                	    	MulIMPLstrcat(OutputWT,ParentDescV);
    	                	    	MulIMPLstrcat(OutputWT,",");
    	                	    	MulIMPLstrcat(OutputWT,ParentDR);
    	                	    	MulIMPLstrcat(OutputWT,"\n");
    	                	        
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *WTsum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*WTsum],ParentNo);
										*WTsum = *WTsum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,ParentNo);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,RevisionId);
										MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDescV);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(UniqueVC,ParentDR);
    	                	    	    MulIMPLstrcat(UniqueVC,",");
    	                	    	    MulIMPLstrcat(OutputWT,"WT");
    	                	    	    MulIMPLstrcat(OutputWT,"\n");
									}
    	                	    
    	                	    }
					    	    else
					    	    {
							    
					    	    }
							}
							else if(tc_strcmp(FileFormat,".txt") == 0)
                            {
								if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"CKD") == 0))
    	                	    {
    	                	    	//*CKDSum = *CKDSum+1;
                                    //CKD..................................................
    	                	    	MulIMPLstrcat(OutputCKD,"    ");
    	                	    	MulIMPLstrcat(OutputCKD,ParentNo);
    	                	    	MulIMPLstrcat(OutputCKD,"                 ");
    	                	    	MulIMPLstrcat(OutputCKD,ParentDescV);
    	                	    	MulIMPLstrcat(OutputCKD,"                    ");
    	                	    	MulIMPLstrcat(OutputCKD,ParentDR);
    	                	    	MulIMPLstrcat(OutputCKD,"\n");
							    
							    
    		            	    	if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *CKDSum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*CKDSum],ParentNo);
										*CKDSum = *CKDSum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,"    ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentNo);
	    	    				    	MulIMPLstrcat(UniqueVC,"      ");
										MulIMPLstrcat(UniqueVC,RevisionId);
	    	    				    	MulIMPLstrcat(UniqueVC,"       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	MulIMPLstrcat(UniqueVC,"                       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDR);
	    	    				    	MulIMPLstrcat(UniqueVC,"                    ");
	    	    				    	MulIMPLstrcat(UniqueVC,"CKD");
	    	    				    	MulIMPLstrcat(UniqueVC,"\n");
									}
							    
    	                	    	//.........................................................
    		            	    }
    	                	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Cargo") == 0))
    	                	    {
    	                	    	//*CargoSum = *CargoSum+1;
    	                	    
    	                	    	//Cargo..................................................
    	                	    	MulIMPLstrcat(OutputCargo,"    ");
    	                	    	MulIMPLstrcat(OutputCargo,ParentNo);
    	                	    	MulIMPLstrcat(OutputCargo,"                 ");
    	                	    	MulIMPLstrcat(OutputCargo,ParentDescV);
    	                	    	MulIMPLstrcat(OutputCargo,"                    ");
    	                	    	MulIMPLstrcat(OutputCargo,ParentDR);
    	                	    	MulIMPLstrcat(OutputCargo,"\n");
							    
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *CargoSum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*CargoSum],ParentNo);
										*CargoSum = *CargoSum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,"    ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentNo);
	    	    				    	MulIMPLstrcat(UniqueVC,"      ");
										MulIMPLstrcat(UniqueVC,RevisionId);
	    	    				    	MulIMPLstrcat(UniqueVC,"       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	MulIMPLstrcat(UniqueVC,"                       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDR);
	    	    				    	MulIMPLstrcat(UniqueVC,"                    ");
	    	    				    	MulIMPLstrcat(UniqueVC,"Cargo");
	    	    				    	MulIMPLstrcat(UniqueVC,"\n");
									}
    	                	      
    	                	    }
    	                	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Defence") == 0))
    	                	    {
    	                	        //*Defencesum = *Defencesum+1;
    	                	        //Defence..................................................
    	                	        MulIMPLstrcat(OutputDefence,"    ");
    	                	        MulIMPLstrcat(OutputDefence,ParentNo);
    	                	        MulIMPLstrcat(OutputDefence,"                 ");
    	                	        MulIMPLstrcat(OutputDefence,ParentDescV);
    	                	        MulIMPLstrcat(OutputDefence,"                    ");
    	                	        MulIMPLstrcat(OutputDefence,ParentDR);
    	                	        MulIMPLstrcat(OutputDefence,"\n");
    	                	        
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *Defencesum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*Defencesum],ParentNo);
										*Defencesum = *Defencesum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,"    ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentNo);
	    	    				    	MulIMPLstrcat(UniqueVC,"      ");
										MulIMPLstrcat(UniqueVC,RevisionId);
	    	    				    	MulIMPLstrcat(UniqueVC,"       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	MulIMPLstrcat(UniqueVC,"                       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDR);
	    	    				    	MulIMPLstrcat(UniqueVC,"                    ");
	    	    				    	MulIMPLstrcat(UniqueVC,"Defence");
	    	    				    	MulIMPLstrcat(UniqueVC,"\n");
									}
					    	    	
    	                	    }
    	                	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && ((tc_strcmp(AmdenAgency,"EPA") == 0) || 
								(tc_strcmp(AmdenAgency,"VEHICLE") == 0) || (tc_strcmp(AmdenAgency,"Vehicle") == 0) || 
							    (tc_strcmp(AmdenAgency,"Maxicab") == 0) || (tc_strcmp(AmdenAgency,"ACE GOLD RDE") == 0) ||
								(tc_strcmp(AmdenAgency,"EPA RDE") == 0)))
								{
    	                	        //*EPAsum = *EPAsum+1;
    	                	        //EPA..................................................
    	                	        MulIMPLstrcat(OutputEPA,"    ");
    	                	        MulIMPLstrcat(OutputEPA,ParentNo);
    	                	        MulIMPLstrcat(OutputEPA,"                 ");
    	                	        MulIMPLstrcat(OutputEPA,ParentDescV);
    	                	        MulIMPLstrcat(OutputEPA,"                    ");
    	                	        MulIMPLstrcat(OutputEPA,ParentDR);
    	                	        MulIMPLstrcat(OutputEPA,"\n");
    	                	        
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *EPAsum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*EPAsum],ParentNo);
										*EPAsum = *EPAsum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,"    ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentNo);
	    	    				    	MulIMPLstrcat(UniqueVC,"      ");
										MulIMPLstrcat(UniqueVC,RevisionId);
	    	    				    	MulIMPLstrcat(UniqueVC,"       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	MulIMPLstrcat(UniqueVC,"                       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDR);
	    	    				    	MulIMPLstrcat(UniqueVC,"                    ");
	    	    				    	MulIMPLstrcat(UniqueVC,"EPA");
	    	    				    	MulIMPLstrcat(UniqueVC,"\n");
									}
					    	    	
    	                	    }
    	                	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"Tipper") == 0))
    	                	    {
    	                	        //*Tippersum = *Tippersum+1;
    	                	        //Tipper..................................................
    	                	        MulIMPLstrcat(OutputTipper,"    ");
    	                	        MulIMPLstrcat(OutputTipper,ParentNo);
    	                	        MulIMPLstrcat(OutputTipper,"                 ");
    	                	        MulIMPLstrcat(OutputTipper,ParentDescV);
    	                	        MulIMPLstrcat(OutputTipper,"                    ");
    	                	        MulIMPLstrcat(OutputTipper,ParentDR);
    	                	        MulIMPLstrcat(OutputTipper,"\n");
    	                	        
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *Tippersum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*Tippersum],ParentNo);
										*Tippersum = *Tippersum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,"    ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentNo);
	    	    				    	MulIMPLstrcat(UniqueVC,"      ");
										MulIMPLstrcat(UniqueVC,RevisionId);
	    	    				    	MulIMPLstrcat(UniqueVC,"       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	MulIMPLstrcat(UniqueVC,"                       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDR);
	    	    				    	MulIMPLstrcat(UniqueVC,"                    ");
	    	    				    	MulIMPLstrcat(UniqueVC,"Tipper");
	    	    				    	MulIMPLstrcat(UniqueVC,"\n");
									}
    	                	    
    	                	    }
    	                	    else if((tc_strcmp(AmdenVC,ParentNo) == 0) && (tc_strcmp(AmdenAgency,"WT") == 0))
    	                	    {
    	                	        //*WTsum = *WTsum+1;
    	                	        //WT..................................................
    	                	        MulIMPLstrcat(OutputWT,"    ");
    	                	        MulIMPLstrcat(OutputWT,ParentNo);
    	                	        MulIMPLstrcat(OutputWT,"                 ");
    	                	        MulIMPLstrcat(OutputWT,ParentDescV);
    	                	        MulIMPLstrcat(OutputWT,"                    ");
    	                	        MulIMPLstrcat(OutputWT,ParentDR);
    	                	        MulIMPLstrcat(OutputWT,"\n");
    	                	        
									if(!isStringAlreadyCopiedMulUnq(commonStringsUnq, *WTsum, ParentNo)) 
                                    {
					                    strcpy(commonStringsUnq[*WTsum],ParentNo);
										*WTsum = *WTsum+1;

    		            	    	    MulIMPLstrcat(UniqueVC,"    ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentNo);
	    	    				    	MulIMPLstrcat(UniqueVC,"      ");
										MulIMPLstrcat(UniqueVC,RevisionId);
	    	    				    	MulIMPLstrcat(UniqueVC,"       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDescV);
	    	    				    	MulIMPLstrcat(UniqueVC,"                       ");
	    	    				    	MulIMPLstrcat(UniqueVC,ParentDR);
	    	    				    	MulIMPLstrcat(UniqueVC,"                    ");
	    	    				    	MulIMPLstrcat(UniqueVC,"WT");
	    	    				    	MulIMPLstrcat(UniqueVC,"\n");
									}
    	                	    
    	                	    }
					    	    else
					    	    {
							    
					    	    }
							}
							else
							{
								
							}
					    	
    			        }
					    
					}
					
				}
				else
				{

				}
    		}					
        }
        //........................................................................................	
		MEM_free(commonStrings);
    }
	else
    {
    	printf("\n No Parents found under Part......\n");fflush(stdout);
    }	
	
	printf("CKD sum [%d] Cargo sum [%d] Defence sum [%d] EPA sum [%d] Tipper sum [%d] WT sum [%d]\n",*CKDSum,*CargoSum,*Defencesum,*EPAsum,*Tippersum,*WTsum);fflush(stdout);


    MulIMPLstrcat(OutputCKD,"    \n");
    MulIMPLstrcat(OutputCargo,"    \n");
    MulIMPLstrcat(OutputDefence,"    \n");
    MulIMPLstrcat(OutputEPA,"    \n");
    MulIMPLstrcat(OutputTipper,"    \n");
    MulIMPLstrcat(OutputWT,"    \n");

	
	return ITK_ok;
}

int tm_MulPartImplFn(char *Infiledata,char *PlantName,char **output,char * FileFormat)
{
	printf("Inside the function of tm_MulPartImplFnFn\n");fflush(stdout);
	tag_t	QryTag	               = NULLTAG;
	tag_t	*ERCDMLSet	           = NULLTAG;

	char     *OutputCKD			 = NULL;
    char     *OutputCargo	     = NULL;
    char     *OutputDefence	     = NULL;
    char     *OutputEPA			 = NULL;
    char     *OutputTipper		 = NULL;
    char     *OutputWT			 = NULL;
    char     *UniqueVC			 = NULL;
	char     *StringLine         = NULL;
	char*     StorPrtInfo[1000]      ;
	
	StringLine = (char *) MEM_alloc(1 * sizeof(Infiledata));
	StringLine = strtok(Infiledata,"\n");
	int StorIdx = 0;
	while(StringLine!=NULL)
	{
		StorPrtInfo[StorIdx] = (char*)malloc(300);
		strcpy(StorPrtInfo[StorIdx],StringLine);
		StringLine = strtok(NULL,"\n");
		StorIdx ++;
	}
    printf(" Total StorIdx.... = %d\n",StorIdx);fflush(stdout);
	
	int      SummaryFlag         = 0;
	
	int CKDSumS=0,CargoSumS=0,DefencesumS=0,EPAsumS=0,TippersumS=0, WTsumS=0;
	
	int CKDSumF=0,CargoSumF=0,DefencesumF=0,EPAsumF=0,TippersumF=0, WTsumF=0;
	
	char        *CKDSumV            = (char *) MEM_alloc(5 * sizeof(char *));
	char        *CargoSumV          = (char *) MEM_alloc(5 * sizeof(char *));
	char        *DefencesumV        = (char *) MEM_alloc(5 * sizeof(char *));
	char        *EPAsumV            = (char *) MEM_alloc(5 * sizeof(char *));
	char        *WTsumV             = (char *) MEM_alloc(5 * sizeof(char *));
	char        *TippersumV         = (char *) MEM_alloc(5 * sizeof(char *));
	
	//..................................................................
    
    OutputCKD = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    OutputCargo = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    OutputDefence = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    OutputEPA = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    OutputTipper = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    OutputWT = (char *) MEM_alloc( 10000000 * sizeof(char*) );
    UniqueVC = (char *) MEM_alloc( 10000000 * sizeof(char*) );
	//TZ Changes....................................................
	
	tc_strcpy(OutputCKD,"");
	tc_strcpy(OutputCargo,"");
	tc_strcpy(OutputDefence,"");
	tc_strcpy(OutputEPA,"");
	tc_strcpy(OutputTipper,"");
	tc_strcpy(OutputWT,"");
	tc_strcpy(UniqueVC,"");
	//TZ Changes....................................................

	int 	ERCDMLCount		       = 0;

	printf("Input Plant name is ... = %s\n",PlantName);fflush(stdout);
	printf("\nInput FileFormat  is ... = %s\n",FileFormat);fflush(stdout);
	
	//........................................................
	
	// Query Revision rule...................
    tag_t	     GnrQryTag	               = NULLTAG;
    tag_t	     CntrlQryTag               = NULLTAG;
    
	tag_t	     RevRuleObjTag             = NULLTAG;
	char*	     CntRisionRule             = NULL;

	if(QRY_find2("General...", &CntrlQryTag));
	if(CntrlQryTag != NULLTAG)
	{
		printf("query found\n");fflush(stdout);
	    int         Cntrlcnt              = 0;
	    tag_t       *CntrlObSet           = NULLTAG;


		char 		*CntrEntry[2] 	= 	{"Name","Type"};
	    char 		**Cntrvalues 	= 	(char **) MEM_alloc(10 * sizeof(char *));
	
	    Cntrvalues[0]				=	"RevisionRuleForDmlImpl";
	    Cntrvalues[1]				=	"Control Object";

		if(QRY_execute(CntrlQryTag,2,CntrEntry,Cntrvalues,&Cntrlcnt,&CntrlObSet));

		if(Cntrlcnt > 0)
	    {
	    	printf("\nControl Object found ......  :%d\n",Cntrlcnt);fflush(stdout);
            tag_t	     CntrlObjTag               = NULLTAG;
			CntrlObjTag = CntrlObSet[0];

			ITK_CALL(AOM_UIF_ask_value(CntrlObjTag,"t5_Userinfo1",&CntRisionRule));
	        printf("Control Object Revision Rule is = %s\n",CntRisionRule);fflush(stdout);
	    }
		else
		{
			printf("Control Object not found\n");fflush(stdout);
		}
	} 
	else
	{
        printf("Control object Query not found\n");fflush(stdout);
	}

	if(QRY_find2("General...", &GnrQryTag));
	if(GnrQryTag != NULLTAG)
	{
		printf("query found\n");fflush(stdout);
		int         RevRuleCnt              = 0;
		tag_t       *RevRuleSet            = NULLTAG;

		char 		*RevruleEntry[2] 	= 	{"Name","Type"};
	    char 		**Revrulevalues 	= 	(char **) MEM_alloc(10 * sizeof(char *));
	
	    Revrulevalues[0]				=	CntRisionRule;
	    Revrulevalues[1]				=	"Revision Rule";

		if(QRY_execute(GnrQryTag,2,RevruleEntry,Revrulevalues,&RevRuleCnt,&RevRuleSet));

		if(RevRuleCnt > 0)
	    {
	        char*	     GetRevRule             = NULL;

			RevRuleObjTag = RevRuleSet[0];
			ITK_CALL(AOM_UIF_ask_value(RevRuleObjTag,"object_name",&GetRevRule));
	        printf("Revision Rule from Rev rule object is = %s\n",GetRevRule);fflush(stdout);
		}
		else
		{
			printf("Revision Rule not found\n");fflush(stdout);

		}
	} 
	else
	{
        printf("Revision Rule Query not found\n");fflush(stdout);
	}
	//.......................................
	
	//Amden Query ........................................................
	
	char     *AmdenTname			 = NULL;
	AmdenTname = (char *) MEM_alloc( 5 * sizeof(char*) );

	if(tc_strcmp(PlantName,"JSR")==0)
	{
		tc_strcpy(AmdenTname,"AMDEN_JSR");
		printf("\n Amden table name is %s\n",AmdenTname);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"LKO")==0)
	{
		tc_strcpy(AmdenTname,"AMDEN_LKN");
		printf("\n Amden table name is %s\n",AmdenTname);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"DWD")==0)
	{
		tc_strcpy(AmdenTname,"AMDEN_DWD");
		printf("\n Amden table name is %s\n",AmdenTname);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PNR")==0)
	{
		tc_strcpy(AmdenTname,"AMDEN_PNR");
		printf("\n Amden table name is %s\n",AmdenTname);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PUNE")==0)
	{
		tc_strcpy(AmdenTname,"AMDEN_PUNE");
		printf("\n Amden table name is %s\n",AmdenTname);fflush(stdout);
	}
	else
	{
		printf("\n Inside else ...");fflush(stdout);
	}
	//......................................................................
	
	int         AmdenCnt              = 0;
	int         row_cnt               = 0;
	tag_t       *Amdentableset        = NULLTAG;
	tag_t       Amdentable            = NULLTAG;
	tag_t       *AmdentableRowset     = NULLTAG;
	tag_t       AMDENQryTag           = NULLTAG;

    //TZ Changes....................................................

	if(QRY_find2("General...", &AMDENQryTag));
	if(AMDENQryTag != NULLTAG)
	{
		printf("Amden query found\n");fflush(stdout);
		char 		*AMDqry_entries[2] 	= 	{"Name","Type"};
	    char 		**AMDqry_values 		= 	(char **) MEM_alloc(10 * sizeof(char *));
	    
	    AMDqry_values[0]					=	AmdenTname;
	    AMDqry_values[1]					=	"Amden Table";
    
	    if(QRY_execute(AMDENQryTag,2,AMDqry_entries,AMDqry_values,&AmdenCnt,&Amdentableset));
    
		if(AmdenCnt > 0)
	    {
	    	printf("\nTotal MADEN found ......  :%d\n",AmdenCnt);fflush(stdout);
			Amdentable = Amdentableset[0];
		    ITK_CALL(AOM_ask_table_rows(Amdentable,"t5_AmdTablerow",&row_cnt,&AmdentableRowset));
		    printf("\nTotal row found under AMden table is ... :%d\n",row_cnt);fflush(stdout);
		    if(row_cnt > 0)
		    {
		    	printf(" \nAmden table row found ..... !\n");fflush(stdout);
		    }
	    }
	    else 
	    {
            printf(" \n\n AMDEN Not found !\n");fflush(stdout);
			
	    }
	} 
	else
	{
		printf("Amden Query not found\n");fflush(stdout);
	}

	// Part IMPLOSION Summary............................
	//Write all data in one string  ............................................................................
	
	SummaryFlag = 1;
	MulIMPLstrcat(output,"\n");
	MulIMPLstrcat(output,"                          PART IMPLOSION REPORT                     \n");
	MulIMPLstrcat(output,"                          =====================                     \n");
	
	//Return to rac ............................................................................
	
    if(tc_strcmp(FileFormat,".csv") == 0)
	{
		//CKD........................................................................
	    tc_strcat(OutputCKD,"\n");
	    tc_strcat(OutputCKD,"    CKD START\n");
	    tc_strcat(OutputCKD,", CKD \n");
	    tc_strcat(OutputCKD,", --- \n");
	    tc_strcat(OutputCKD,", PART IMPLOSION \n");
	    tc_strcat(OutputCKD," , ===============\n");
	    //.............................................................................
        
	    //Cargo........................................................................
	    tc_strcat(OutputCargo,"\n");
	    tc_strcat(OutputCargo,"    CARGO START\n");
	    tc_strcat(OutputCargo,", Cargo \n");
	    tc_strcat(OutputCargo,", ----- \n");
	    tc_strcat(OutputCargo,", PART IMPLOSION \n");
	    tc_strcat(OutputCargo,", ===============\n");
	    //.............................................................................
        
	    //Defence........................................................................
	    tc_strcat(OutputDefence,"\n");
	    tc_strcat(OutputDefence,"    DEFENCE START\n");
	    tc_strcat(OutputDefence,", Defence \n");
	    tc_strcat(OutputDefence,", -------  \n");
	    tc_strcat(OutputDefence,", PART IMPLOSION \n");
	    tc_strcat(OutputDefence,", ===============\n");
	    //.............................................................................
        
	    //EPA........................................................................
	    tc_strcat(OutputEPA,"\n");
	    tc_strcat(OutputEPA,"    EPA START\n");
	    tc_strcat(OutputEPA,", EPA \n");
	    tc_strcat(OutputEPA,", ---  \n");
	    tc_strcat(OutputEPA,", PART IMPLOSION \n");
	    tc_strcat(OutputEPA,", ===============\n");
	    //.............................................................................
        
	    //Tipper........................................................................
	    tc_strcat(OutputTipper,"\n");
	    tc_strcat(OutputTipper,"    TIPPER START\n");
	    tc_strcat(OutputTipper,", Tipper \n");
	    tc_strcat(OutputTipper,", ------  \n");
	    tc_strcat(OutputTipper,", PART IMPLOSION \n");
	    tc_strcat(OutputTipper,", ===============\n");
	    //.............................................................................
        
	    //WT IMPLOSION REPORT............................................................................................
        
	    //WT........................................................................
	    tc_strcat(OutputWT,"\n");
	    tc_strcat(OutputWT,"    WT START\n");
	    tc_strcat(OutputWT,", WT \n");
	    tc_strcat(OutputWT,", -- \n");
	    tc_strcat(OutputWT,", PART IMPLOSION \n");
	    tc_strcat(OutputWT,", ===============\n");
	    //.............................................................................
		
		
        //Unique VC list..............................................................................
	    tc_strcat(UniqueVC,",====== Unique VC List Affected by DML =======\n");
	    tc_strcat(UniqueVC,"===============,=====,==================================,==========,=============\n");
	    tc_strcat(UniqueVC,"VC LIST,REV,VC DESC,DR Stat,AGENCY\n");
	    tc_strcat(UniqueVC,"===============,=====,==================================,==========,=============\n");
	    //.............................................................................................
		

		//CKD
		tc_strcat(OutputCKD," ===============,===========================,============,===========,=============,===========================,==============\n");
        tc_strcat(OutputCKD,"Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
        tc_strcat(OutputCKD," ===============,===========================,============,===========,=============,===========================,==============\n");
		
		//Cargo
		tc_strcat(OutputCargo," ===============,===========================,============,===========,=============,===========================,==============\n");
        tc_strcat(OutputCargo,"Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
        tc_strcat(OutputCargo," ===============,===========================,============,===========,=============,===========================,==============\n");
		
		//Defence
		tc_strcat(OutputDefence," ===============,===========================,============,===========,=============,===========================,==============\n");
        tc_strcat(OutputDefence,"Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
        tc_strcat(OutputDefence," ===============,===========================,============,===========,=============,===========================,==============\n");
        
		//EPA
		tc_strcat(OutputEPA," ===============,===========================,============,===========,=============,===========================,==============\n");
        tc_strcat(OutputEPA,"Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
        tc_strcat(OutputEPA," ===============,===========================,============,===========,=============,===========================,==============\n");

		//Tipper
		tc_strcat(OutputTipper," ===============,===========================,============,===========,=============,===========================,==============\n");
        tc_strcat(OutputTipper,"Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
        tc_strcat(OutputTipper," ===============,===========================,============,===========,=============,===========================,==============\n");
		
		//WT
		tc_strcat(OutputWT," ===============,===========================,============,===========,=============,===========================,==============\n");
        tc_strcat(OutputWT,"Part No,Part Desc,DR Stat,Part Type,VC No,VC Desc,VC DR Status\n");
        tc_strcat(OutputWT," ===============,===========================,============,===========,=============,===========================,==============\n");
	}
	else if(tc_strcmp(FileFormat,".txt") == 0)
	{	
		//CKD........................................................................
	    tc_strcat(OutputCKD,"\n");
	    tc_strcat(OutputCKD,"    CKD START\n");
	    tc_strcat(OutputCKD,"                   CKD \n");
	    tc_strcat(OutputCKD,"                   --- \n");
	    tc_strcat(OutputCKD,"              PART IMPLOSION \n");
	    tc_strcat(OutputCKD,"    ===================================\n");
	    //.............................................................................
        
	    //Cargo........................................................................
	    tc_strcat(OutputCargo,"\n");
	    tc_strcat(OutputCargo,"    CARGO START\n");
	    tc_strcat(OutputCargo,"                   Cargo \n");
	    tc_strcat(OutputCargo,"                   ----- \n");
	    tc_strcat(OutputCargo,"               PART IMPLOSION \n");
	    tc_strcat(OutputCargo,"    ===================================\n");
	    //.............................................................................
        
	    //Defence........................................................................
	    tc_strcat(OutputDefence,"\n");
	    tc_strcat(OutputDefence,"    DEFENCE START\n");
	    tc_strcat(OutputDefence,"                   Defence \n");
	    tc_strcat(OutputDefence,"                   -------  \n");
	    tc_strcat(OutputDefence,"                PART IMPLOSION \n");
	    tc_strcat(OutputDefence,"     ===================================\n");
	    //.............................................................................
        
	    //EPA........................................................................
	    tc_strcat(OutputEPA,"\n");
	    tc_strcat(OutputEPA,"    EPA START\n");
	    tc_strcat(OutputEPA,"                   EPA \n");
	    tc_strcat(OutputEPA,"                   ---  \n");
	    tc_strcat(OutputEPA,"              PART IMPLOSION \n");
	    tc_strcat(OutputEPA,"   ===================================\n");
	    //.............................................................................
        
	    //Tipper........................................................................
	    tc_strcat(OutputTipper,"\n");
	    tc_strcat(OutputTipper,"    TIPPER START\n");
	    tc_strcat(OutputTipper,"                   Tipper \n");
	    tc_strcat(OutputTipper,"                   ------  \n");
	    tc_strcat(OutputTipper,"               PART IMPLOSION \n");
	    tc_strcat(OutputTipper,"    ===================================\n");
	    //.............................................................................
        
	    //WT IMPLOSION REPORT............................................................................................
        
	    //WT........................................................................
	    tc_strcat(OutputWT,"\n");
	    tc_strcat(OutputWT,"    WT START\n");
	    tc_strcat(OutputWT,"                   WT \n");
	    tc_strcat(OutputWT,"                   -- \n");
	    tc_strcat(OutputWT,"              PART IMPLOSION \n");
	    tc_strcat(OutputWT,"   ===================================\n");
	    //.............................................................................
		
		//Unique VC list..............................................................................
	    tc_strcat(UniqueVC,"    ====== Unique VC List Affected by DML =======\n");
	    tc_strcat(UniqueVC,"    ===============   =====      ==================================                  ==========            =============\n");
	    tc_strcat(UniqueVC,"        VC LIST        REV                DESCRIPTION                                  DR Stat              AGENCY   \n");
	    tc_strcat(UniqueVC,"    ===============   =====      ==================================                  ==========            =============\n");
	    //.............................................................................................
	}
	else
	{
		printf("File format is not correct ...\n");fflush(stdout);
	}
    

	// Part find ..................................................................................
	tag_t 		ChildPrtItm 		= 	NULLTAG;
	tag_t 		ChildPrtItmRev 		= 	NULLTAG;
	
	int      ItrPrtInpt   = 0;
    for(ItrPrtInpt = 0 ; ItrPrtInpt < StorIdx ; ItrPrtInpt++)
    {
		char          *InputPrtNo            = NULL;
		InputPrtNo = (char *) MEM_alloc(50 * sizeof(char *));
		
	    tc_strcpy(InputPrtNo,StorPrtInfo[ItrPrtInpt]);
		
		printf("Input Part No is ..... =  %s\n",InputPrtNo);fflush(stdout);
		
        ITK_CALL(ITEM_find_item(InputPrtNo,&ChildPrtItm));
	    
	    ITK_CALL(ITEM_ask_latest_rev(ChildPrtItm,&ChildPrtItmRev));
	    
	    if(ChildPrtItm != NULLTAG && ChildPrtItmRev != NULLTAG)
	    {
	    	printf("Child Part and latest part revision found...\n");fflush(stdout);
	    	
	    	char      *ChildItem         = NULL;
	        char      *ChldItmRevid      = NULL;
	        char      *Prt_object_type   = NULL;
	        char      *PartRevSeq        = NULL; 
	        char      *Releasestate1     = NULL;
	        char      *PartDesc          = NULL;
	        char      *PartDescV         = NULL;
	        char      *PartType          = NULL;
	        char      **RlzStsList       = NULL;
	        int       NoofLC             = 0;
	    	int       PrtSerial = 0;
	        PrtSerial++;
	    	
	        int serial = 0;
	        serial++;

	    	ITK_CALL(AOM_ask_value_string(ChildPrtItm,"item_id",&ChildItem));
	        printf("Part Item name is = %s\n",ChildItem);fflush(stdout);
	    	
	    	ITK_CALL(AOM_ask_value_string(ChildPrtItmRev,"item_revision_id",&ChldItmRevid));
	        printf("Child revision id = %s\n",ChldItmRevid);fflush(stdout);
            
	        //printf("after replacestr Part PartDesc is = %s\n",PartDescV);fflush(stdout);
	    
	        ITK_CALL(AOM_ask_value_string(ChildPrtItmRev,"t5_PartType",&PartType));
	        printf("Part PartType is = %s\n",PartType);fflush(stdout);
            
	        //ITK_CALL(AOM_UIF_ask_value(ChildPrtItmRev,"release_status_list",&Releasestate1));
	    	
	        if((tc_strcmp(PartType,"D") == 0) || (tc_strcmp(PartType,"DC") == 0) || (tc_strcmp(PartType,"CM") == 0 ))
            {
	        	printf("Skiping becausePart Typeis D or DC or CM or Folder\n");fflush(stdout);
	        }
	        else
	    	{
	    		//Part Impl.......................................................................
	    		tm_PartImplFnMul(ChildPrtItmRev,PlantName,FileFormat,row_cnt,AmdentableRowset,RevRuleObjTag,&OutputCKD,&OutputCargo,
	    		&OutputDefence,&OutputEPA,&OutputTipper,&OutputWT,&UniqueVC,&CKDSumS,
	    		&CargoSumS,&DefencesumS,&EPAsumS,&TippersumS,&WTsumS);
	    		
	    		printf("CKD sumF.. [%d] Cargo sumF.. [%d] Defence sumF [%d] EPA sumF [%d] Tipper sumF [%d] WT sumF [%d]\n",CKDSumS,CargoSumS,DefencesumS,EPAsumS,TippersumS,WTsumS);fflush(stdout);	
	    	
	    		//................................................................................
	    	}

	    }
	    else
	    {
	    	printf("Child part item and item revision not found.... \n");fflush(stdout);
	    }
	}

	tc_strcat(OutputCKD,"    CKD END \n");
	tc_strcat(OutputCargo,"    CARGO END \n");
	tc_strcat(OutputDefence,"    DEFENCE END \n");
	tc_strcat(OutputEPA,"    EPA END \n");
	tc_strcat(OutputTipper,"    TIPPER END \n");
	tc_strcat(OutputWT,"    WT END \n");

    
	
	//.........................................................
	
	//printf("CKD sumF [%d] Cargo sumF [%d] Defence sumF [%d] EPA sumF [%d] Tipper sumF [%d] WT sumF [%d]\n",CKDSumF,CargoSumF,DefencesumF,EPAsumF,TippersumF,WTsumF);fflush(stdout);	

	//Write all data in one string  ............................................................................
    
	sprintf(CKDSumV,"%d",CKDSumS);
	sprintf(CargoSumV,"%d",CargoSumS);
	sprintf(DefencesumV,"%d",DefencesumS);
	sprintf(EPAsumV,"%d",EPAsumS);
	sprintf(TippersumV,"%d",TippersumS);
	sprintf(WTsumV,"%d",WTsumS);
	
	MulIMPLstrcat(output,"    ===============================================================\n");
	MulIMPLstrcat(output,"                               Change Occurances \n");
	MulIMPLstrcat(output,"                               ================= \n");
	MulIMPLstrcat(output,"                               CKD      :     ");
	MulIMPLstrcat(output,CKDSumV);
	MulIMPLstrcat(output,"\n");
	MulIMPLstrcat(output,"                               Cargo    :     ");
	MulIMPLstrcat(output,CargoSumV);
	MulIMPLstrcat(output,"\n");
	MulIMPLstrcat(output,"                               Defence  :     ");
	MulIMPLstrcat(output,DefencesumV);
	MulIMPLstrcat(output,"\n");
	MulIMPLstrcat(output,"                               EPA      :     ");
	MulIMPLstrcat(output,EPAsumV);
	MulIMPLstrcat(output,"\n");
	MulIMPLstrcat(output,"                               Tipper   :     ");
	MulIMPLstrcat(output,TippersumV);
	MulIMPLstrcat(output,"\n");
	MulIMPLstrcat(output,"                               WT       :     ");
	MulIMPLstrcat(output,WTsumV);
	MulIMPLstrcat(output,"\n");
	MulIMPLstrcat(output,"    ===============================================================\n");
    
	tc_strcat(UniqueVC,"    ========================== END OF THE REPORT ========================\n");
		
	MulIMPLstrcat(output,OutputCKD);
	MulIMPLstrcat(output,OutputCargo);
	MulIMPLstrcat(output,OutputDefence);
	MulIMPLstrcat(output,OutputEPA);
	MulIMPLstrcat(output,OutputTipper);
	MulIMPLstrcat(output,OutputWT);
	MulIMPLstrcat(output,UniqueVC);
	
	MEM_free(OutputCKD);
	MEM_free(OutputCargo);
	MEM_free(OutputDefence);
	MEM_free(OutputEPA);
	MEM_free(OutputTipper);
	MEM_free(OutputWT);
	MEM_free(UniqueVC);
	
	printf("End of the function tm_MulPartImplFn.... \n");fflush(stdout);
	return ITK_ok;
}

char * StringTrimMul(char** pointerToString)
{
    int start=0, length=0;

        // Trim.Start:
        length = strlen(*pointerToString);
        while ((*pointerToString)[start]==' ') start++;
        (*pointerToString) += start;

        if (start < length) // Required for empty (ex. "    ") input
        {
            // Trim.End:
            int end = strlen(*pointerToString)-1; // Get string length again (after Trim.Start)
            while ((*pointerToString)[end]==' ') end--;
            (*pointerToString)[end+1] = 0;
        }

    return *pointerToString;
}

int MulPrtImplRpt(void *return_data)
{
	//Variable Decleration
	int ifail = ITK_ok;
	char     *PlantName          = NULL;
	char     *FileFormat	     = NULL;
	char     *FileDataIn    	 = NULL;
	char     *output			 = NULL;
	
	output = (char *) MEM_alloc( 90000000 * sizeof(char*) );

	printf("\n inside the function DML_ImplosionRpt .....");fflush(stdout);

	//Get Agruments ...........................................

	USERARG_get_string_argument(&PlantName);
	USERARG_get_string_argument(&FileFormat);
	USERARG_get_string_argument(&FileDataIn);

	printf("Input Plant Name is ... = %s\n",PlantName);fflush(stdout);
	printf("Input FileFormat is ... = %s\n",FileFormat);fflush(stdout);
	printf("Input file Data is ... = %s\n",FileDataIn);fflush(stdout);

	//..........................................................
	
	tc_strcpy(output,"");

	tm_MulPartImplFn(FileDataIn,PlantName,&output,FileFormat);
	
	printf("\n before return data....!\n");fflush(stdout);

	*((char **) return_data) = (char *) MEM_alloc( (strlen(output) + 1) * sizeof(char));
    strcpy( *((char **) return_data),output);

	printf("\n Reports Generated successfully...........!\n");fflush(stdout);

    MEM_free(output);

	printf("\n After free...!\n");fflush(stdout);
    return ifail;
}

extern int AllUserServiceFnMulPrtImplFn(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;
    int nargs = 3;
    int retValueType;
    int inputArgTypes[3] = {0};

    inputArgTypes[0] = USERARG_STRING_TYPE; //Plant Name
    inputArgTypes[1] = USERARG_STRING_TYPE; //fileformat
	inputArgTypes[2] = USERARG_STRING_TYPE; //Input File Date  
    

    retValueType = USERARG_STRING_TYPE ;
    ifail=USERSERVICE_register_method("MulPrtImplRpt",(USER_function_t)MulPrtImplRpt,nargs,inputArgTypes,retValueType);

    return ifail;
}

extern DLLAPI int tm_MulPartImplRpt_register_callbacks ()
{

    int ifail    = ITK_ok;

    ifail = CUSTOM_register_exit("tm_MulPartImplRpt", "USERSERVICE_register_methods",(CUSTOM_EXIT_ftn_t)AllUserServiceFnMulPrtImplFn);
    return ifail;
}