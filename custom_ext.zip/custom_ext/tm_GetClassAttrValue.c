/***************************************************************************
*  Copyright (c) 2004 Tata Technologies Limited (TTL). All Rights
* Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
* File                         : tm_FinalizeEPA.c
* Created By                   : Sagar Baviskar
* Created On                   : 
* Project                      : TML
* Description                  : RAC TO ITK Function calling
* Specific Notes               :
*
* Modification History :
* S.No    Date                            CR No        Modified By                    Modification Notes
*
****************************************************************************************************************************************************/
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/epm.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>
#include <tccore/aom_prop.h>


#define NULLDATE   (POM_null_date()) 
#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#define ITK_errStore 91900002

#define Debug TRUE

//#ifndef RETURN
//#define RETURN(output, value) USERARG_add_string_return((void *)output, value)
//#endif

int GetClassAttValueFnc(void *retValue)
{
    int ifail = ITK_ok;
    char *part_rev_uid = NULL;
    char *fuel_type = NULL;
    char* Revitem_id=NULL;
    tag_t item_tag=NULLTAG;

    printf("\n[ERROR] 11111\n");

    // Get arguments from RAC
    USERARG_get_string_argument(&part_rev_uid);  // From Java: PartRev.getUid()
    USERARG_get_string_argument(&fuel_type);     // From Java: "[VC]FUEL(FUEL)"

    printf("\n[GetClassAttValueFnc] Received Item ID: %s", part_rev_uid);
    printf("\n[GetClassAttValueFnc] Received FuelType: %s", fuel_type);

    ifail = ITEM_find_item(part_rev_uid, &item_tag);
    if (ifail != ITK_ok || item_tag == NULLTAG) {
        printf("\n[ERROR] Failed to find item for ID: %s\n", Revitem_id); fflush(stdout);
       // USERARG_add_string_return(retValue, "ERROR: ITEM not found");
       
        return ifail;
    }
                                        
    tag_t			classificationObject = NULLTAG;
    int theAttributeCount,xc,ic,t5NoEcuDupint =0;
    int *theAttributeIds ;
    char 			**theAttributeNames;
    int *theAttributeValCounts=0;
    char***       theAttributeValues;
    char***       theAttributeOptimizedUnits;
    char* 	attrId 					= NULL;
    attrId = (char *) MEM_alloc( 50 * sizeof(char) );
    char 	*attributeNameDup 			= NULL;
    char 	*attributeValueDup 			= NULL;
    attributeNameDup = (char *) MEM_alloc( 5000 * sizeof(char) );
    attributeValueDup = (char *) MEM_alloc( 5000 * sizeof(char) );
    int i,x=0;
    int TotVCAttrCount=0;

    char*	 ModelrevPartRev = NULL;

    ITKCALL(ICS_ask_classification_object(item_tag,&classificationObject));

    if (classificationObject != NULLTAG)
    {
        ITKCALL( ICS_ico_ask_attributes_optimized(classificationObject,&theAttributeCount,&theAttributeIds,&theAttributeNames,&theAttributeValCounts,&theAttributeValues,&theAttributeOptimizedUnits));

        if(theAttributeCount>0)
        {
            for(ic=0;ic<theAttributeCount;ic++)
            {
                sprintf(attrId,"%d",theAttributeIds[ic]);

                tc_strcpy(attributeNameDup,"");
                tc_strcpy(attributeNameDup,theAttributeNames[ic]);

                if(tc_strcmp(attributeNameDup,"[VC]FUEL(FUEL)")==0)
                {
                    tc_strcpy(attributeValueDup,"");
                    for(xc=0;xc<theAttributeValCounts[ic];xc++)
                    {
                        tc_strcat(attributeValueDup,theAttributeValues[ic][xc]);
                    }

                    printf("\n theAttribute Name :[%s]",attributeNameDup,ic);fflush(stdout);
                    printf("\n theAttribute value:[%s] ",attributeValueDup);fflush(stdout);

                    t5NoEcuDupint=atoi(attributeValueDup);
                    
                    printf("\n Fuel_Type : %s\n",attributeValueDup);fflush(stdout);

                    char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};    
                    char     *qry_valuesCntrl1[3]= {"FUEL_TYPE","T4B04","0"};

                    tag_t qryTagCntrl1=NULLTAG;
                    int control_number_found1;
                    int n_entryCntrl1=3;
                    tag_t* list_of_WSO_cntrl_tags1=NULLTAG;


                    //ITK_CALL(QRY_find("Control Objects...", &qryTagCntrl1));
                    ITK_CALL(QRY_find2("Control Objects...", &qryTagCntrl1));
                    if (qryTagCntrl1)
                    {
                        // printf("\n Control Object Query Found \n");
                        fflush(stdout);
                    

                        ITK_CALL(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_WSO_cntrl_tags1));

                        printf("\n CO Count : %d\n",control_number_found1);fflush(stdout);
                            
                        if(control_number_found1>0)
                        {
                            char* t5_Userinfo1 = NULL;                           
                            tag_t obj = list_of_WSO_cntrl_tags1[0];
                            ITK_CALL(AOM_ask_value_string(obj,"t5_Userinfo1",&t5_Userinfo1));
                            printf("\n CO Info 1:[%s] ",t5_Userinfo1);fflush(stdout);
                            printf("\nControl Object Found ...\n");
                            ITKCALL(AOM_lock(obj));
                            ITK_CALL(AOM_set_value_string(obj,"t5_Userinfo1",attributeValueDup));
                            ITK_CALL(AOM_save_with_extensions(obj));
				            ITK_CALL(AOM_unlock(obj));
                            printf("\nValue Set on Control Object...\n");
                        }
                    }

                /*    if(tc_strcmp(attributeValueDup,"") != 0)
                    {
                        USERARG_add_string_return(retValue, attributeValueDup);
                       // USERARG_add_string_return(retValue,
                    }
                    else
                    {
                        USERARG_add_string_return(retValue, "NO VALUE FOUND");
                    }*/
                }
            }
        }
    }

	return ifail;
}


extern int GetClassAttValueFncRegisterServiceFnc()
{
	int ifail = ITK_ok;
	//*decision = ALL_CUSTOMIZATIONS; 
	//int nargs = 9;
	int nargs = 2;
	int retValueType;
	//int inputArgTypes[2] = {0};
   int *inputArgTypes = (int *) MEM_alloc ( nargs * nargs *sizeof (int) );
    printf("\n GetClassAttValueFnc 011...");fflush(stdout);  
    inputArgTypes[0] = USERARG_STRING_TYPE;
    inputArgTypes[1] = USERARG_STRING_TYPE;

    retValueType = USERARG_STRING_TYPE+ USERARG_ARRAY_TYPE;
    fflush(stdout);  

	printf("\n GetClassAttValueFnc before...");fflush(stdout);  
	ifail=USERSERVICE_register_method("GetClassAttValueFnc",(USER_function_t)GetClassAttValueFnc,nargs,inputArgTypes,retValueType);

	return ifail;
	
}
extern int tm_GetClassAttrValueServiceFnc(int *decision, va_list args)
{
	int ifail = ITK_ok;
	*decision = ALL_CUSTOMIZATIONS; 
	
	ITKCALL(GetClassAttValueFncRegisterServiceFnc());
	
	return ifail;
	
}

extern DLLAPI int tm_GetClassAttrValue_register_callbacks ()
{
	int ifail    = ITK_ok;
 //   fflush(stdout);
	printf("\n tm_ClassAttValueFuncs_register_callbacks....");fflush(stdout);
	printf("\n Before registoring userservice tm_GetClassAttrValue ....");fflush(stdout);
	ifail=CUSTOM_register_exit ( "tm_GetClassAttrValue", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)tm_GetClassAttrValueServiceFnc);
	printf("\n After registoring userservice tm_GetClassAttrValue....");fflush(stdout);
    
	return ( ITK_ok );
}