/***************************************************************************
* Copyright (c) 2007 Tata Technologies Limited (TTL). All Rights Reserved.
*
* This software is the confidential and proprietary information of TTL.
* You shall not disclose such confidential information and shall use it
* only in accordance with the terms of the license agreement.
*
*  Author		 :   Deepti Meshram
*  Module		 :   TCUA Desing Rev BOM Uploader
*  Code			 :   t5APLPartBOMCreation.c
*  Created on	 :   March 28, 2018
*
*
* Modification History :
* S.No    Date			CR No     Modified By            Modification Notes
***************************************************************************/

#define ITK_Prjerr (EMH_USER_error_base + 8)
#define ITK_err 919002
#define ITK_errStore1 (EMH_USER_error_base + 5)
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#define _CRT_SECURE_NO_DEPRECATE
#include <ae/dataset.h>
#include <ae/dataset_msg.h>
#include <ai/sample_err.h>
#include <bom/bom.h>
#include <ctype.h>
#include <epm/cr_effectivity.h>
#include <epm/epm.h>
#include <epm/releasestatus.h>
#include <fclasses/tc_string.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <pom/pom/pom.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <rdv/arch.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <sa/imanfile.h>
#include <sa/sa.h>
#include <sa/tcfile.h>
#include <sa/user.h>
#include <ss/ss_errors.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <tc/emh.h>
#include <tc/folder.h>
#include <tc/iman.h>
#include <tc/tc.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tccore/grm.h>
#include <tccore/grm_msg.h>
#include <tccore/grmtype.h>
#include <tccore/iman_msg.h>
#include <tccore/imantype.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <tccore/item_msg.h>
#include <tccore/tctype.h>
#include <tccore/uom.h>
#include <tccore/workspaceobject.h>
#include <tcinit/tcinit.h>
#include <textsrv/textserver.h>
#include <time.h>
#include <user_exits/user_exits.h>
#include <pie/pie.h>

#define ONE "1-Mtr"
#define TWO "2-Kg"
#define THREE "3-Ltr"
#define FOUR "4-Nos"
#define FIVE "5-Sq.Mtr"
#define SIX "6-Sets"
#define SEVEN "7-Tonne"
#define EIGHT "8-Cu.Mtr"
#define NINE "9-Thsnds"
#define EIGHT "8-Cu.Mtr"

#define ERCREVIEW	"T5_LcsReview"
#define ERCWORKING	"T5_LcsWorking"
#define ERCRELEASED "T5_LcsErcRlzd"
#define APLWORKING  "T5_LcsAPLWrkg"
#define APLRELEASED "T5_LcsAplRlzd"
#define STDWORKING  "T5_LcsSTDWrkg"
#define STDRELEASED "T5_LcsStdRlzd"
#define APLREVIEW	"T5_LcsAplReview"



#define Debug TRUE

#define ITK_CALL(X) 							\
		if(Debug)								\
		{										\
			printf(#X);							\
		}										\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			if(Debug)							\
			printf("\tSUCCESS\n");				\
		}										\

static char* default_empty_to_A(char *s)
{
    return (NULL == s ? s : ('\0' == s[0] ? "A" : s));
}

static int initialise_attribute (char *name,  int *attribute)
{

	int mode;
    int status;

	ITK_CALL(BOM_line_look_up_attribute (name, attribute));
	ITK_CALL(BOM_line_ask_attribute_mode (*attribute, &mode));
	if (mode != BOM_attribute_mode_string)
	{ 
		printf ("Help,  attribute %s has mode %d,  I want a string\n", name, mode);
		exit(0);
	}
	return status;
}

int validateBOMPart(char *inputfile,FILE *fperror1)
{
	int status;

	FILE *fp1=NULL;
	char *inputline1=NULL;
	//char *mod_Part1=NULL;
	//char *prent_Orgid1=NULL;
	char *parent_item_id1=NULL;
	char *parent_item_revision_id1=NULL;
	char *parent_item_sequence_id1=NULL;
	char *child_item_id1=NULL;
	//char *child_item_revision_id1=NULL;
	//char *child_item_sequence_id1=NULL;
	char *childitemRevSeq=NULL;
	char *childPartNoVal=NULL;
	const char *attrs1[1];
	const char *values1[1];
	int n_tags_found1= 0;
	tag_t *tags_found1 = NULL;
	tag_t child_item=NULLTAG;
	tag_t child_rev=NULLTAG;
	
	printf("\n INSIDE BOM VALIDATE FUNCTION.. %s \n",inputfile);
	
	fp1=fopen(inputfile,"r");
	if(fp1!=NULL)
	{
		inputline1=(char *) MEM_alloc(1000);
		while(fgets(inputline1,1000,fp1)!=NULL)
		{
			fputs(inputline1,stdout);


			//=NULL;
			//prent_Orgid1=NULL;
			parent_item_id1=NULL;
			parent_item_revision_id1=NULL;
			parent_item_sequence_id1=NULL;
			child_item_id1=NULL;
			//child_item_revision_id1=NULL;
			//child_item_sequence_id1=NULL;
			childPartNoVal=NULL;

			//mod_Part1=strtok(inputline1,"^");  //1
			//prent_Orgid1=strtok(NULL,"^");  //2
			parent_item_id1=strtok(inputline1,"^"); //3
			parent_item_revision_id1=strtok(NULL,"^"); //4
			parent_item_sequence_id1=strtok(NULL,"^"); //4
			child_item_id1=strtok(NULL,"^"); //2

			childPartNoVal=strtok(child_item_id1,".");

			printf("\n 11 mod_Part .......%s,%s,%s,%s,%s",parent_item_id1,parent_item_revision_id1,parent_item_sequence_id1,child_item_id1,childPartNoVal);fflush(stdout);

			attrs1[0] ="item_id";
			values1[0] = (char *)childPartNoVal;
			ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs1, values1, &n_tags_found1, &tags_found1));
			if(n_tags_found1==0)
			{
				fprintf(fperror1,"Child :[%s] of Parent Part not found  :[%s],[%s],[%s]\n",childPartNoVal,parent_item_id1,parent_item_revision_id1,parent_item_sequence_id1);
				
				printf("Child :[%s] of Parent Part not found  :[%s],[%s],[%s]\n",childPartNoVal,parent_item_id1,parent_item_revision_id1,parent_item_sequence_id1);fflush(stdout);

			}
			
		}
	}

	
	if(fp1)fclose(fp1);fp1=NULL;
	if(fperror1)fclose(fperror1);fperror1=NULL;


}

extern int ITK_user_main (int argc, char ** argv )
{

	char *assyPartNo=NULL;
	char *assyPartNoRev=NULL;
	char *assyPartNoSeq=NULL;
	char *childPartNo=NULL;
	char * optionalCS=NULL;
	char * assyPartNoOrgID=NULL;
	int status;
	char *inputfile=NULL;
	char *PlantName=NULL;
	char *inputline=NULL;
	char *childPartNoVal=NULL;
	const char *attrs[1];
	const char *values[1];
	tag_t parent_item=NULLTAG;
	tag_t parent_rev=NULLTAG;
	tag_t *tags_found = NULL;
	int n_tags_found= 0;
	char *assyitemRevSeq=NULL;
	tag_t revRule 			= NULLTAG;
	PIE_scope_t scope;
	int 	n_closure_tags=0;
	int 	childCnt=0;
	tag_t * 	closure_tags;
	tag_t  	closure_tag;
	int bvr_count_AssRev=0;
	tag_t	window 				= NULLTAG;
	tag_t			*bvrs_AssyRev= NULLTAG;
	int 	bvrCnt=0;
	char *view_name_assy=NULL;
	char *viewTok=NULL;
	tag_t			top_line							= NULLTAG;
	tag_t  *children1=NULLTAG;
	int kC=0;
	tag_t			Bomline_tag							= NULLTAG;
	int iChildItemTag=0;
	tag_t   t_ChildItemRev;
	char *ItemName = NULL;
	char *child_Item_opCS = NULL;
	char *GenOptionalCS = NULL;
	char *getPlantCR = NULL;
	char *getPlantView = NULL;
	char *partTok = NULL;
	int aplFlag_attribute= 0;
	int aplviewfound= 0;
	long int res;
	int childPartFound=0;



	FILE *fp=NULL;
	FILE *fperror=NULL;
	FILE *fpexception=NULL;
	FILE *fperror1=NULL;
	FILE *fperror_file=NULL;
	
	inputfile = ITK_ask_cli_argument("-i=");
	PlantName = ITK_ask_cli_argument("-plname=");

	ITK_CALL(ITK_auto_login( ));  
    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
    ITK_CALL(ITK_set_journalling( TRUE ));
	printf("\n Auto login .......");fflush(stdout);

	if((tc_strcmp(PlantName,"PlantName1")==0) || (tc_strcmp(PlantName,"PlantName4")==0))
	{
		GenOptionalCS=NULL;
		GenOptionalCS=(char *) MEM_alloc(100);
		tc_strcpy(GenOptionalCS,  "bl_occ_t5_CarOptionalCS");

		getPlantCR=NULL;
		getPlantCR=(char *) MEM_alloc(100);
		tc_strcpy(getPlantCR,"BOMViewClosureRuleAPLC");

		getPlantView=NULL;
		getPlantView=(char *) MEM_alloc(100);
		tc_strcpy(getPlantView,"APLC");

		printf("OPCS Name After Conversion ==> [%s]:[%s]:[%s]\n",GenOptionalCS,getPlantCR,getPlantView);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName13")==0)
	{
		GenOptionalCS=NULL;
		GenOptionalCS=(char *) MEM_alloc(100);
		tc_strcpy(GenOptionalCS,  "bl_occ_t5_PunUVOptionalCS");

		getPlantCR=NULL;
		getPlantCR=(char *) MEM_alloc(100);
		tc_strcpy(getPlantCR,"BOMViewClosureRuleAPLV");

		getPlantView=NULL;
		getPlantView=(char *) MEM_alloc(100);
		tc_strcpy(getPlantView,"APLV");
		printf("OPCS Name After Conversion ==> [%s]:[%s]:[%s]\n",GenOptionalCS,getPlantCR,getPlantView);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName2")==0)
	{
		GenOptionalCS=NULL;
		GenOptionalCS=(char *) MEM_alloc(100);
		tc_strcpy(GenOptionalCS,  "bl_occ_t5_PnrOptionalCS");

		getPlantCR=NULL;
		getPlantCR=(char *) MEM_alloc(100);
		tc_strcpy(getPlantCR,"BOMViewClosureRuleAPLU");

		getPlantView=NULL;
		getPlantView=(char *) MEM_alloc(100);
		tc_strcpy(getPlantView,"APLU");

		printf("OPCS Name After Conversion ==> [%s]:[%s]:[%s]\n",GenOptionalCS,getPlantCR,getPlantView);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName3")==0)
	{
		GenOptionalCS=NULL;
		GenOptionalCS=(char *) MEM_alloc(100);
		tc_strcpy(GenOptionalCS,  "bl_occ_t5_PunOptionalCS");

		getPlantCR=NULL;
		getPlantCR=(char *) MEM_alloc(100);
		tc_strcpy(getPlantCR,"BOMViewClosureRuleAPLP");

		getPlantView=NULL;
		getPlantView=(char *) MEM_alloc(100);
		tc_strcpy(getPlantView,"APLP");

		printf("OPCS Name After Conversion ==> [%s]:[%s]:[%s]\n",GenOptionalCS,getPlantCR,getPlantView);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName6")==0)
	{
		GenOptionalCS=NULL;
		GenOptionalCS=(char *) MEM_alloc(100);
		tc_strcpy(GenOptionalCS,  "bl_occ_t5_AhdOptionalCS");

		getPlantCR=NULL;
		getPlantCR=(char *) MEM_alloc(100);
		tc_strcpy(getPlantCR,"BOMViewClosureRuleAPLA");

		getPlantView=NULL;
		getPlantView=(char *) MEM_alloc(100);
		tc_strcpy(getPlantView,"APLA");

		printf("OPCS Name After Conversion ==> [%s]:[%s]:[%s]\n",GenOptionalCS,getPlantCR,getPlantView);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName8")==0)
	{
		GenOptionalCS=NULL;
		GenOptionalCS=(char *) MEM_alloc(100);
		tc_strcpy(GenOptionalCS,  "bl_occ_t5_JsrOptionalCS");

		getPlantCR=NULL;
		getPlantCR=(char *) MEM_alloc(100);
		tc_strcpy(getPlantCR,"BOMViewClosureRuleAPLJ");

		getPlantView=NULL;
		getPlantView=(char *) MEM_alloc(100);
		tc_strcpy(getPlantView,"APLJ");

		printf("OPCS Name After Conversion ==> [%s]:[%s]:[%s]\n",GenOptionalCS,getPlantCR,getPlantView);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName9")==0)
	{
		GenOptionalCS=NULL;
		GenOptionalCS=(char *) MEM_alloc(100);
		tc_strcpy(GenOptionalCS,  "bl_occ_t5_LkoOptionalCS");

		getPlantCR=NULL;
		getPlantCR=(char *) MEM_alloc(100);
		tc_strcpy(getPlantCR,"BOMViewClosureRuleAPLL");

		getPlantView=NULL;
		getPlantView=(char *) MEM_alloc(100);
		tc_strcpy(getPlantView,"APLL");

		printf("OPCS Name After Conversion ==> [%s]:[%s]:[%s]\n",GenOptionalCS,getPlantCR,getPlantView);fflush(stdout);
	}
	else if(tc_strcmp(PlantName,"PlantName11")==0)
	{
		GenOptionalCS=NULL;
		GenOptionalCS=(char *) MEM_alloc(100);
		tc_strcpy(GenOptionalCS,  "bl_occ_t5_DwdOptionalCS");

		getPlantCR=NULL;
		getPlantCR=(char *) MEM_alloc(100);

		tc_strcpy(getPlantCR,"BOMViewClosureRuleAPLD");

		getPlantView=NULL;
		getPlantView=(char *) MEM_alloc(100);
		tc_strcpy(getPlantView,"APLD");

		printf("OPCS Name After Conversion ==> [%s]:[%s]:[%s]\n",GenOptionalCS,getPlantCR,getPlantView);fflush(stdout);
	}
	else
	{
		printf("\nSYNTEX ERROR :: \n");
		printf("\n PLEASE ENTER CORRECT PLANTNAME(EX:PlantName1,PlantName13,PlantName2 etc..)\n");
		printf("\nTRY AGAIN !!!\n");
		return status;
	}
	
	
//	fperror1=fopen("error_OPTCSChild.log","w");
//	printf("\n CALLING BOM VALIDATE FUNCTION in OPCS UPD.. \n");fflush(stdout);
//	validateBOMPart(inputfile,fperror1);
//	fperror_file=fopen("error_OPTCSChild.log","r");
//
//	if(fperror_file==NULL)
//	{
//		printf("\n fperror_file is NULL \n");fflush(stdout);
//
//	}
//	else
//	{
//		printf("\n fperror_file is NOT NULL \n");fflush(stdout);
//		res = ftell(fperror_file);
//		printf("Size of the file is %ld bytes \n", res); 
//
//	}

//	if(res>0)
//	{
//		printf("Error log is not null...Hence not going for Optional CS upd..\n");fflush(stdout);
//	
//	}
//	else
//	{	
//		printf("Error log is null...going for Optional CS upd..\n");fflush(stdout);

		fp=fopen(inputfile,"r");
		fperror=fopen("error_OPTCSUPD.log","w");
		fpexception=fopen("Exception_OPTCSUPD.log","w");
		if(fp!=NULL)
		{
			inputline=(char *) MEM_alloc(1000);
			while(fgets(inputline,1000,fp)!=NULL)
			{
				printf("\n File rease.");fflush(stdout);
				fputs(inputline,stdout);
				
				//2790351009R^O^4^279009130134.2^F^

				assyPartNo=NULL;
				assyPartNoRev=NULL;
				assyPartNoSeq=NULL;
				childPartNo=NULL;
				optionalCS=NULL;
				assyPartNoOrgID=NULL;
				childPartFound=0;
				
				
				assyPartNo=strtok(inputline,"^");
				assyPartNoRev=strtok(NULL,"^");
				assyPartNoSeq=strtok(NULL,"^");
				assyPartNoOrgID=strtok(NULL,"^");
				childPartNo=strtok(NULL,"^");
				optionalCS=strtok(NULL,"^");
				childPartNoVal=strtok(childPartNo,".");
				printf("\n mod_Part .......%s,%s,%s,%s,%s,%s",assyPartNo,assyPartNoRev,assyPartNoSeq,childPartNo,optionalCS,childPartNoVal);fflush(stdout);

				attrs[0] ="item_id";
				values[0] = (char *)assyPartNo;
				ITK_CALL(ITEM_find_items_by_key_attributes(1,attrs, values, &n_tags_found, &tags_found));
				if(n_tags_found==0)
				{
					if((tc_strcmp(assyPartNoOrgID,"ERC")==0))
					{				
						fprintf(fperror,"ERC Parent Part not found  :[%s],[%s],[%s]\n",assyPartNo,assyPartNoRev,assyPartNoSeq);
						printf("ERC Parent Part not found  :[%s],[%s],[%s]\n",assyPartNo,assyPartNoRev,assyPartNoSeq);fflush(stdout);
						continue;
					}
					else
					{
						fprintf(fperror,"APL Parent Part not found  :[%s],[%s],[%s]\n",assyPartNo,assyPartNoRev,assyPartNoSeq);
						printf("APL Parent Part not found  :[%s],[%s],[%s]\n",assyPartNo,assyPartNoRev,assyPartNoSeq);fflush(stdout);
						continue;				
					
					}

				}
				else
				{
						
						
						parent_item = tags_found[0];
						printf("Item already exists\n");fflush(stdout);
						aplviewfound=0;

						assyitemRevSeq = NULL;
						assyitemRevSeq=(char *) MEM_alloc(32);
						strcpy(assyitemRevSeq,assyPartNoRev);
						strcat(assyitemRevSeq,";");
						strcat(assyitemRevSeq,assyPartNoSeq);
						printf(" assyitemRevSeq [%s]\n",assyitemRevSeq);fflush(stdout);	
						
						ITK_CALL(ITEM_find_revision(parent_item,assyitemRevSeq,&parent_rev));
						if(parent_rev != NULLTAG)
						{
							ITK_CALL(BOM_create_window (&window));
							ITK_CALL(CFM_find("ERC release and above", &revRule));
							if (revRule != NULLTAG)
							{
								printf("\nFind revRule\n");fflush(stdout);
								ITK_CALL(BOM_set_window_config_rule(window,revRule));
							}

							ITK_CALL(PIE_find_closure_rules2(getPlantCR,scope,&n_closure_tags,&closure_tags));
							printf("\n n_closure_tags:%d ..............",n_closure_tags);fflush(stdout);
							if(n_closure_tags==1)
							{
								closure_tag=closure_tags[0];
								ITK_CALL(BOM_window_set_closure_rule(window,closure_tag,0,NULL,NULL));
							}

							ITKCALL(ITEM_rev_list_bom_view_revs( parent_rev, &bvr_count_AssRev, &bvrs_AssyRev));
							printf("\n bvr_count_AssRev %d ",bvr_count_AssRev);fflush(stdout);
							for (bvrCnt=0;bvrCnt<bvr_count_AssRev;bvrCnt++)
							{
								
								printf("\n Inside for loop ..");fflush(stdout);
								ITKCALL(AOM_ask_value_string(bvrs_AssyRev[bvrCnt],"object_name",&view_name_assy));
								printf("\n view_name_assy %s",view_name_assy);fflush(stdout);
								
								if(tc_strstr(view_name_assy,getPlantView)!=NULL)
								{
									aplviewfound++;
									break;		
								
								}
							}

							if(aplviewfound==0)
							{
								for (bvrCnt=0;bvrCnt<bvr_count_AssRev;bvrCnt++)
								{
									
									printf("\n Inside for loop to check for erc view..");fflush(stdout);
									ITKCALL(AOM_ask_value_string(bvrs_AssyRev[bvrCnt],"object_name",&view_name_assy));
									printf("\n view_name_assy %s",view_name_assy);fflush(stdout);

									partTok = strtok (view_name_assy,"-");
									viewTok = strtok (NULL,"-");
									printf("\n viewTok %s",viewTok);fflush(stdout);


									if(tc_strcmp(viewTok,"View")==0)
									{
										aplviewfound++;
										break;		
									
									}
								}
							
							
							}

							if(aplviewfound>0)
							{
								ITKCALL(BOM_set_window_top_line(window,parent_item,parent_rev,bvrs_AssyRev[bvrCnt],&top_line));
								ITKCALL(BOM_save_window(window));
								ITKCALL(BOM_line_ask_child_lines(top_line, &childCnt, &children1));
								printf("\n\n\t\t No of child objects are n : %d\n",childCnt);fflush(stdout);
								for (kC = 0; kC < childCnt; kC++)
								{
									BOM_line_unpack (children1[kC]);
									Bomline_tag = children1[kC];

									ITKCALL(BOM_line_look_up_attribute (( char * ) bomAttr_lineItemRevTag , &iChildItemTag));
									ITKCALL(BOM_line_ask_attribute_tag(Bomline_tag, iChildItemTag, &t_ChildItemRev));
									if(t_ChildItemRev!=NULLTAG)
									{
										ITKCALL(AOM_ask_value_string(t_ChildItemRev,"item_id",&ItemName));
										printf("\n\n\t\t Part Compare : %s: %s\n",ItemName,childPartNoVal);fflush(stdout);

										if(tc_strcmp(ItemName,childPartNoVal)==0)
										{
											childPartFound++;
											ITKCALL(BOM_line_look_up_attribute (GenOptionalCS,&aplFlag_attribute));
											ITKCALL(BOM_line_ask_attribute_string(Bomline_tag, aplFlag_attribute, &child_Item_opCS));
											printf("\n\n\t\t child_Item_opCS : %s:\n",child_Item_opCS);fflush(stdout);

											if(tc_strcmp(child_Item_opCS,"")==0)
											{
												ITKCALL(BOM_line_set_attribute_string(Bomline_tag, aplFlag_attribute,optionalCS ));
												printf("\n Updating OP CS....");fflush(stdout);
											}
											else
											{
												fprintf(fpexception,"Assy Part :[%s],[%s],[%s] :Child Part:[%s] is not having optional cs blank.so not updating..\n",assyPartNo,assyPartNoRev,assyPartNoSeq,childPartNoVal);	
								
											}
											break;
										}
									}
									
								}

								if(childPartFound==0)
								{
									fprintf(fperror,"In Assy Part :[%s],[%s],[%s] :Child Part:[%s] ..not found\n",assyPartNo,assyPartNoRev,assyPartNoSeq,childPartNoVal);	
								
								}
								ITKCALL(BOM_close_window(window));
							}
							else
							{
								fprintf(fperror,"Assy Part :[%s],[%s],[%s] BVR NOT FOUND..so not creating the structure\n",assyPartNo,assyPartNoRev,assyPartNoSeq);	
							}
						
						
						}
				
				
				}


			}
		}
	//}
	
	
	
	
	
	//ITK_CALL(POM_logout(false));
	
//	if(fp)fclose(fp);fp=NULL;
//	if(fperror)fclose(fperror);fperror=NULL;
//	if(fpexception)fclose(fpexception);fpexception=NULL;
//	
	return status;

}