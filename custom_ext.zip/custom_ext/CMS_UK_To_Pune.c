/****************************************************************************************************
*  File                 :		data_transfer_process.c
*  Created By			:		Dhiraj
*  Created On			:		
*  Purpose				:		data_share utility to transfer the data from one site to other site 
*  Modification History :		
******************************************************************************************************/

#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128
#include <user_exits/user_exits.h>
#include <ss/ss_const.h>
#include <ae/ae.h>
#include <tccore/aom_prop.h>
#include <epm/epm_errors.h>
#include <sys/stat.h>
#include <bom/bom.h>
#include <cfm/cfm.h>
#include <tccore/custom.h>
#include <ae/dataset.h>
#include <tccore/grm.h>
#include <ict/ict_userservice.h>
#include <itk/mem.h>
#include <tccore/method.h>
#include <ps/ps_errors.h>
#include <tccore/aom.h>
#include <res/reservation.h>
#include <sa/sa.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <fclasses/tc_time.h>
#include <unidefs.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <tccore/tc_msg.h>
#include <tccore/iman_msg.h>
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/grmtype.h>
#include <pom/pom/pom.h>
#include <ai/sample_err.h>
#include <dispatcher/dispatcher_itk.h>

/*
	Action Handler		:		CMS_DataShare_UK_PUNE
	Description			:		Action Handler to trasnfer date thru share data utility
*/


int CMS_DataShare_UK_PUNE(EPM_action_message_t msg)
{
	int status=ITK_ok;

	int			attachmentCount		= 0;

	tag_t		rootTask_t				= NULLTAG;
	tag_t		objTag					= NULLTAG;
	tag_t		ObjTypeTag				= NULLTAG;
	tag_t		obj_class_id			= NULLTAG;
	tag_t*		taskAttachments			= NULLTAG;


	char*		type_name				= NULL;
	char*		TransferObject			= NULL;
	char*		item_id					= NULL;
	char*		obj_class_name			= NULL;


	ITK_CALL(EPM_ask_root_task(msg.task,&rootTask_t));
	ITK_CALL(EPM_ask_attachments(rootTask_t,EPM_target_attachment,&attachmentCount,&taskAttachments));

	TC_write_syslog("attachmentCount = %d\n",attachmentCount);
	
	if(attachmentCount > 0)
	{
		objTag = taskAttachments[0];
	}
	if(attachmentCount > 0)
	{

		AOM_ask_value_string(objTag,"object_type",&type_name);
		TC_write_syslog("type_name ::  %s\n", type_name);
		
		AOM_ask_value_string(objTag,"item_id",&item_id);
		TC_write_syslog("item_id ::  %s\n", item_id);

		POM_class_of_instance(objTag, &obj_class_id);

		if(obj_class_id != NULLTAG)
		{
			POM_name_of_class(obj_class_id, &obj_class_name);
			TC_write_syslog("obj_class_name ::  %s\n", obj_class_name);
		}

		if(tc_strcmp(type_name,"Design Revision") == 0)
		{
			TransferObject=malloc(2000);
			strcpy(TransferObject,"nohup data_share -u=infodba -p=INfoDBA -g=dba -f=send -site=Cmitest -item_id=");
			strcat(TransferObject,item_id);
			//strcat(TransferObject," -latest_revision ");
			strcat(TransferObject," -selected_revision ");
			strcat(TransferObject," -latest_ds_version ");
			strcat(TransferObject," > /tmp/");
			strcat(TransferObject,item_id);
			strcat(TransferObject,".log &");
			TC_write_syslog("TransferObject final string is  ::  %s\n", TransferObject);
			system(TransferObject);
		}
	}
	return status; 
}


extern int data_transfer_process_custom_exit(int *decision, va_list args)
{
    int ifail = ITK_ok;
    *decision = ALL_CUSTOMIZATIONS;  

	ifail=data_transfer_process_action_handlers();

    return ifail;
}


int data_transfer_process_action_handlers()
{
	int ifail = ITK_ok;
	
	EPM_register_action_handler("CMS_DataShare_UK_PUNE", "Action Handler to trasnfer data thru share data utility", CMS_DataShare_UK_PUNE);
	TC_write_syslog("Registered Action Handler CMS_DataShare_UK_PUNE..\n");

	return ifail;
}


extern DLLAPI int CMS_UK_To_Pune_register_callbacks ()
{     
	 TC_write_syslog("\n data_transfer_process.c:::Hello Teamcenter, via Custom Exit.. \n");
     CUSTOM_register_exit ( "CMS_UK_To_Pune", "USER_init_module", (CUSTOM_EXIT_ftn_t) data_transfer_process_custom_exit);

     return ( ITK_ok );
}
