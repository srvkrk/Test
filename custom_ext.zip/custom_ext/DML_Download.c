/*
# Basic Assumptions of this code :
#	1. If Item exists then; Item Revision also exists.
#	2. DML and Task are never Revised so, there exists only one version of DML and Task
#	3. Same Task Number with different design groups will be treated as different objects which will have object and object revision.
#	
# 
# 
*/

#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <ai/sample_err.h>
#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dir.h> 
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/grm.h>
#define ITK_err 910001
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}
#define CALLAPI2(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) { PrintErrorStack(); return ifail;}

static void Write_To_Log(char *format, ...)
{
    char msg[1000];
    va_list args;
    va_start(args, format);
    vsprintf(msg, format, args);
    va_end(args);
    printf(msg);
    printf(msg);
}

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    int *pSevLst = NULL;
    int *pErrCdeLst = NULL;
    char **pMsgLst = NULL;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
    fprintf( stderr, "Checkout Error(s): \n");
	Write_To_Log("Checkout Error(s): \n");
    for ( i = 0; i < iNumErrs; i++ )
    {
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
        fprintf( stderr, "\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
		Write_To_Log("\t %6d: %s\n", pErrCdeLst[i], pMsgLst[i]);
    }
//    	 919003: error_919003, "Modification Description"
//	 919003: error_919003, "Modification Description"
//	 919003: error_919003, "Part Type"
//	 919003: error_919003, "Part Type"
//	 919099: error_919099, "CAP_FOR_PISTON_ROD_PRT", "A", "2"
//	 919099: error_919099, "CAP_FOR_PISTON_ROD_PRT", "A", "2"

    return ITK_ok;
}


#define ITK_CALL(X) 							\
		printf(#X);								\
		fflush(NULL);							\
		status=X; 								\
		if (status != ITK_ok ) 					\
		{										\
			int				index = 0;			\
			int				n_ifails = 0;		\
			const int*		severities = 0;		\
			const int*		ifails = 0;			\
			const char**	texts = NULL;		\
												\
			EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);		\
			printf("\t%3d error(s)\n", n_ifails);							\
			for( index=0; index<n_ifails; index++)							\
			{																\
				printf("\tError #%d, %s\n", ifails[index], texts[index]);	\
			}																\
			return status;													\
		}																	\
		else									\
		{										\
			printf("\tSUCCESS\n");				\
		}										\


GetUserString( const char *pPrompt, char *pInput, int iInputSz )
/*
 * PURPOSE : Gather Generic Input from a user
 *
 * RETURN : Information input from the user on pIrompt and the length of
 *          the new stream in the return portion.
 *
 * NOTES : requires the size of the input array and uses fgets to read
 *         from the input stream stdin. Must call fflush to clear the buffer
 *         between calls. Any input of only a \n is overwritten with '\0'
 */
{
	register int i=0;
	fflush(stdout);
	fflush(stderr);
	printf("%s", pPrompt);
	fflush(stdout);
	fflush(stderr);
	fgets(pInput, iInputSz, stdin );
	fflush(stdin);

	for( i=0; i<iInputSz; i++)
	{
		if( pInput[i] == '\n' )
		{
			pInput[i] = '\0';
		}
	}

	return strlen( pInput );
}



void Complete_DML_Download(char* DmlIdS, char* filenameS)
{
	int		i,j					= 0;
	int		status				= 0;
	int		flag				= 0;
	int		n_tasks				= 0;
	int		n_parts				= 0;
	int		ifail				= ITK_ok;

	char*	item_type				= NULL;
	char	*AllDmlAttrS			= NULL;
	char	*AllTaskAttrS			= NULL;
	char	*AllTaskAttrDupS		= NULL;
	// DML Attributes
    char	*Dml_item_idS			= NULL;
    char	*t5_basicdmlS			= NULL;
    char	*object_nameS			= NULL;
    char	*project_idsS			= NULL;
    char	*t5designgroupS			= NULL;
    char	*object_descS			= NULL;
    char	*CMDispositionS			= NULL;
    char	*requestor_user_idS		= NULL;
    char	*analyst_user_idS		= NULL;
    char	*release_status_listS	= NULL;
    char	*owning_userS			= NULL;
    char	*CMClosureS				= NULL;
    char	*CMClosureDateS			= NULL;
	// Task Attributes
    char	*TaskItemIdS			= NULL;
    char	*TaskObjectDescS		= NULL;
    char	*DesignGroupS			= NULL;
    char	*TaskDespositionS		= NULL;
    char	*RequestorS				= NULL;
    char	*TaskAnalystUserIdS		= NULL;

    char	*PartNumberS			= NULL;
    char	*RevisionS				= NULL;
    char	*SequenceS				= NULL;

	tag_t *dml_tag					= NULLTAG;
	tag_t *dml_rev_tag				= NULLTAG;
	tag_t *task_obj_tag				= NULLTAG;
	tag_t *part_obj_tag				= NULLTAG;
	tag_t reln_type_tag				= NULLTAG;
	tag_t task_rev_tag				= NULLTAG;

	FILE	*DML_Download_fp		=	NULL;

	AllDmlAttrS = ( char * ) MEM_alloc(600);
	AllDmlAttrS=strcpy(AllDmlAttrS,"");

	DML_Download_fp=fopen(filenameS,"w");
	fflush(DML_Download_fp);

	// Query the DML in PLM. 
	ifail = ITEM_find_item( DmlIdS, &dml_tag );

	if (dml_tag != NULLTAG)
	{
		printf("\n\n Complete_DML_Download : DML found ! ! ! \n\n");  fflush(stdout);
		printf("\n\n Complete_DML_Download : [%s] \n\n",AllDmlAttrS);  fflush(stdout);


		// find the type of dml_tag
		ifail = ITEM_ask_type2 (dml_tag, &item_type);
		printf("\n Complete_DML_Download : item_typeS [%s] \n",item_type);  fflush(stdout);
		    

		// Find the DML-Revision tag.
		ITK_CALL(ITEM_find_revision(dml_tag,"A",&dml_rev_tag)) ;
		if (dml_rev_tag  != NULLTAG)
		{
			printf("\n Complete_DML_Download : item_typeS [%s] \n",item_type);  fflush(stdout);
			
			// Collecting DML-Revision Attributes for Download.

			//1
			if (AOM_ask_value_string(dml_rev_tag,"item_id",&Dml_item_idS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : item_id : %s \n",Dml_item_idS); fflush(stdout);
			if (Dml_item_idS)               
				strcat(AllDmlAttrS,Dml_item_idS);
			strcat(AllDmlAttrS,",");
			printf("\n\n Complete_DML_Download : [%s] \n\n",AllDmlAttrS);  fflush(stdout);
			//fprintf(DML_Download_fp,Dml_item_idS);  
			//fprintf(DML_Download_fp,","); 
			
			//2
			if (AOM_ask_value_string(dml_rev_tag,"t5_basicdml",&t5_basicdmlS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : t5_basicdml : %s \n",t5_basicdmlS); fflush(stdout);
			if (t5_basicdmlS)               
				strcat(AllDmlAttrS,t5_basicdmlS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,t5_basicdmlS);  
			//fprintf(DML_Download_fp,",");

			//3
			if (AOM_ask_value_string(dml_rev_tag,"object_name",&object_nameS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : object_nameS : %s \n",object_nameS); fflush(stdout);
			if (object_nameS)               
				strcat(AllDmlAttrS,object_nameS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,object_nameS);  
			//fprintf(DML_Download_fp,",");

			//4
			//if (AOM_ask_value_string(dml_rev_tag,"project_ids",&project_idsS)!=ITK_ok)   PrintErrorStack();
			if (AOM_ask_value_string(dml_rev_tag,"t5_ProjectCode",&project_idsS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : project_ids : %s \n",project_idsS); fflush(stdout);
			if (project_idsS)               
				strcat(AllDmlAttrS,project_idsS);
			strcat(AllDmlAttrS,",");			
			//fprintf(DML_Download_fp,project_idsS);  
			//fprintf(DML_Download_fp,",");

			//5
			if (AOM_ask_value_string(dml_rev_tag,"t5designgroup",&t5designgroupS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : t5designgroup : %s \n",t5designgroupS); fflush(stdout);
			if (t5designgroupS)               
				strcat(AllDmlAttrS,t5designgroupS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,t5designgroupS);  
			//fprintf(DML_Download_fp,",");

			//6
			if (AOM_ask_value_string(dml_rev_tag,"object_desc",&object_descS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : object_desc : %s \n",object_descS); fflush(stdout);
			if (object_descS)               
				strcat(AllDmlAttrS,object_descS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,object_descS);  
			//fprintf(DML_Download_fp,",");

			//7
			if (AOM_ask_value_string(dml_rev_tag,"CMDisposition",&CMDispositionS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : CMDisposition : %s \n",CMDispositionS); fflush(stdout);
			if (CMDispositionS)               
				strcat(AllDmlAttrS,CMDispositionS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,CMDispositionS);  
			//fprintf(DML_Download_fp,",");

			//8 Authorised By Not Present in TCUA
			//if (AOM_ask_value_string(dml_rev_tag,"???",&???)!=ITK_ok)   PrintErrorStack();
			//printf("\n Complete_DML_Download : ??? : %s \n",???); fflush(stdout);
			//if (t5_basicdmlS)               
				strcat(AllDmlAttrS,"");
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,"");  
			//fprintf(DML_Download_fp,",");

			//9 Creator Not Present in TCUA 
			//if (AOM_ask_value_string(dml_rev_tag,"???",&???)!=ITK_ok)   PrintErrorStack();
			//printf("\n Complete_DML_Download : ??? : %s \n",???); fflush(stdout);
			//if (t5_basicdmlS)               
				strcat(AllDmlAttrS,"");
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,"");  
			//fprintf(DML_Download_fp,",");


			//10
			if (AOM_ask_value_string(dml_rev_tag,"requestor_user_id",&requestor_user_idS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : requestor_user_id : %s \n",requestor_user_idS); fflush(stdout);
			if (requestor_user_idS)               
				strcat(AllDmlAttrS,requestor_user_idS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,requestor_user_idS);  
			//fprintf(DML_Download_fp,",");

			//11
			if (AOM_ask_value_string(dml_rev_tag,"analyst_user_id",&analyst_user_idS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : analyst_user_id : %s \n",analyst_user_idS); fflush(stdout);
			if (analyst_user_idS)               
				strcat(AllDmlAttrS,analyst_user_idS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,analyst_user_idS);  
			//fprintf(DML_Download_fp,",");

			//12 Administrator not present in TCUA
			//if (AOM_ask_value_string(dml_rev_tag,"???",&???)!=ITK_ok)   PrintErrorStack();
			//printf("\n Complete_DML_Download : ??? : %s \n",???); fflush(stdout);
			//if (t5_basicdmlS)               
				strcat(AllDmlAttrS,"");
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,"");  
			//fprintf(DML_Download_fp,",");

			//13 LCS not present in TCUA
			//if (AOM_ask_value_string(dml_rev_tag,"???",&???)!=ITK_ok)   PrintErrorStack();
			//printf("\n Complete_DML_Download : ??? : %s \n",???); fflush(stdout);
			//if (t5_basicdmlS)               
				strcat(AllDmlAttrS,"");
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,"");  
			//fprintf(DML_Download_fp,",");

			//14
			if (AOM_ask_value_string(dml_rev_tag,"release_status_list",&release_status_listS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : release_status_list : %s \n",release_status_listS); fflush(stdout);
			if (release_status_listS)               
				strcat(AllDmlAttrS,release_status_listS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,release_status_listS);  
			//fprintf(DML_Download_fp,",");

			//15
			if (AOM_ask_value_string(dml_rev_tag,"owning_user",&owning_userS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : owning_user : %s \n",owning_userS); fflush(stdout);
			if (owning_userS)               
				strcat(AllDmlAttrS,owning_userS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,owning_userS);  
			//fprintf(DML_Download_fp,",");
			
			//16 Planning Status not present in TCUA
			//if (AOM_ask_value_string(dml_rev_tag,"???",&???)!=ITK_ok)   PrintErrorStack();
			//printf("\n Complete_DML_Download : ??? : %s \n",???); fflush(stdout);
			//if (t5_basicdmlS)               
				strcat(AllDmlAttrS,"");
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,"");  
			//fprintf(DML_Download_fp,",");

			//17
			if (AOM_ask_value_string(dml_rev_tag,"CMClosure",&CMClosureS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : CMClosure : %s \n",CMClosureS); fflush(stdout);
			if (CMClosureS)               
				strcat(AllDmlAttrS,CMClosureS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,CMClosureS);  
			//fprintf(DML_Download_fp,",");

			//18
			if (AOM_ask_value_string(dml_rev_tag,"CMClosureDate",&CMClosureDateS)!=ITK_ok)   PrintErrorStack();
			printf("\n Complete_DML_Download : CMClosureDate : %s \n",CMClosureDateS); fflush(stdout);
			if (CMClosureDateS)               
				strcat(AllDmlAttrS,CMClosureDateS);
			strcat(AllDmlAttrS,",");
			//fprintf(DML_Download_fp,CMClosureDateS);  
			//fprintf(DML_Download_fp,",");


			printf("\n Complete_DML_Download : AllDmlAttrS : [%s] \n",AllDmlAttrS); fflush(stdout);


			// Expand the DML-Revision using relation "T5_DMLTaskRelation" to get Task tag.
			ITK_CALL(GRM_find_relation_type("T5_DMLTaskRelation",&reln_type_tag));
			if (reln_type_tag	!=	NULLTAG)
			{
				if ( (ifail = GRM_list_secondary_objects_only( dml_rev_tag, reln_type_tag, &n_tasks, &task_obj_tag )) != ITK_ok )
				{
					return ifail;
				}			
				printf("\n Complete_DML_Download : No of Tasks are : %d \n",n_tasks); fflush(stdout);

				for (i=0;i<n_tasks ;i++ )
				{
					// Find the Task-Revision Tag.
					task_rev_tag = NULLTAG;
					ITK_CALL(ITEM_find_revision(task_obj_tag[i],"A",&task_rev_tag)) ;
					if (task_rev_tag  != NULLTAG)
					{
						AllTaskAttrS = (  char * )MEM_alloc(600);

						AllTaskAttrS=strcpy(AllTaskAttrS,AllDmlAttrS);
						strcat(AllTaskAttrS,"#");

						//fprintf(DML_Download_fp,"#");
						// Collecting Task-Revision Attributes for Download.
						// 1
						if (AOM_ask_value_string(task_rev_tag,"item_id",&TaskItemIdS)!=ITK_ok)   PrintErrorStack();
						printf("\n Complete_DML_Download : Task-Rev item_id : %s \n",TaskItemIdS); fflush(stdout);
						if (TaskItemIdS)               
							strcat(AllTaskAttrS,TaskItemIdS);
						strcat(AllTaskAttrS,"#");
						//fprintf(DML_Download_fp,TaskItemIdS); 
						//fprintf(DML_Download_fp,"#");

						// 2
						if (AOM_ask_value_string(task_rev_tag,"object_desc",&TaskObjectDescS)!=ITK_ok)   PrintErrorStack();
						printf("\n Complete_DML_Download : Task-Rev TaskObjectDescS : %s \n",TaskObjectDescS); fflush(stdout);
						if (TaskObjectDescS)               
							strcat(AllTaskAttrS,TaskObjectDescS);
						strcat(AllTaskAttrS,"#");
						//fprintf(DML_Download_fp,TaskItemIdS);
						//fprintf(DML_Download_fp,"#");

						// 3
						if (AOM_ask_value_string(task_rev_tag,"t5designgroup",&DesignGroupS)!=ITK_ok)   PrintErrorStack();
						printf("\n Complete_DML_Download : Task-Rev DesignGroupS : %s \n",TaskObjectDescS); fflush(stdout);
						if (DesignGroupS)               
							strcat(AllTaskAttrS,DesignGroupS);
						strcat(AllTaskAttrS,"#");
						//fprintf(DML_Download_fp,TaskObjectDescS);
						//fprintf(DML_Download_fp,"#");

						// 4 LCS attribute not present in TCUA.
						//if (AOM_ask_value_string(task_rev_tag,"???",&???)!=ITK_ok)   PrintErrorStack();
						//printf("\n Complete_DML_Download : Task-Rev ???: %s \n",???); fflush(stdout);
						//if (CMClosureDateS)               
							strcat(AllTaskAttrS,"");
						strcat(AllTaskAttrS,",");
						//fprintf(DML_Download_fp,"");
						//fprintf(DML_Download_fp,"#");
						
						// 5 TaskStatus is not present in TCUA.
						//if (AOM_ask_value_string(task_rev_tag,"???",&???)!=ITK_ok)   PrintErrorStack();
						//printf("\n Complete_DML_Download : Task-Rev ???: %s \n",???); fflush(stdout);
						//if (CMClosureDateS)               
							strcat(AllTaskAttrS,"");
						strcat(AllTaskAttrS,",");
						//fprintf(DML_Download_fp,"");
						//fprintf(DML_Download_fp,"#");

						// 6 
						if (AOM_ask_value_string(task_rev_tag,"CMDisposition",&TaskDespositionS)!=ITK_ok)   PrintErrorStack();
						printf("\n Complete_DML_Download : Task-Rev TaskDespositionS : %s \n",TaskDespositionS); fflush(stdout);
						if (TaskDespositionS)               
							strcat(AllTaskAttrS,TaskDespositionS);
						strcat(AllTaskAttrS,"#");
						//fprintf(DML_Download_fp,TaskDespositionS);
						//fprintf(DML_Download_fp,"#");
												
						// 7 Creator is not present in TCUA.
						//if (AOM_ask_value_string(task_rev_tag,"???",&???)!=ITK_ok)   PrintErrorStack();
						//printf("\n Complete_DML_Download : Task-Rev ???: %s \n",???); fflush(stdout);
						//if (CMClosureDateS)               
							strcat(AllTaskAttrS,CMClosureDateS);
						strcat(AllTaskAttrS,"#");
						//fprintf(DML_Download_fp,"");
						//fprintf(DML_Download_fp,"#");

						// 8 
						if (AOM_ask_value_string(task_rev_tag,"requestor_user_id",&RequestorS)!=ITK_ok)   PrintErrorStack();
						printf("\n Complete_DML_Download : Task-Rev RequestorS : %s \n",RequestorS); fflush(stdout);
						if (RequestorS)               
							strcat(AllTaskAttrS,RequestorS);
						strcat(AllTaskAttrS,"#");
						//fprintf(DML_Download_fp,RequestorS);
						//fprintf(DML_Download_fp,"#");

						// 9
						if (AOM_ask_value_string(task_rev_tag,"analyst_user_id",&TaskAnalystUserIdS)!=ITK_ok)   PrintErrorStack();
						printf("\n Complete_DML_Download : Task-Rev TaskAnalystUserIdS : %s \n",TaskAnalystUserIdS); fflush(stdout);
						if (TaskAnalystUserIdS)               
							strcat(AllTaskAttrS,TaskAnalystUserIdS);
						strcat(AllTaskAttrS,"#");
						//fprintf(DML_Download_fp,TaskAnalystUserIdS);
						//fprintf(DML_Download_fp,"#");

						AllTaskAttrDupS = strdup(AllTaskAttrS);

						printf("\n Complete_DML_Download : AllTaskAttrS : %s \n",AllTaskAttrS); fflush(stdout);
						printf("\n Complete_DML_Download : AllTaskAttrDupS : %s \n",AllTaskAttrDupS); fflush(stdout);

						// Expand the Task-Revision using CMHasSolutionItem to get the TC Part.
						reln_type_tag = NULLTAG;
						ITK_CALL(GRM_find_relation_type("CMHasSolutionItem",&reln_type_tag));
						if (reln_type_tag	!=	NULLTAG)
						{
							if ( (ifail = GRM_list_secondary_objects_only( task_rev_tag, reln_type_tag, &n_parts, &part_obj_tag )) != ITK_ok )
							{
								return ifail;
							}
							printf("\n Complete_DML_Download : No of TC Parts attached to the Task are : %d \n",n_parts); fflush(stdout);
							for (j=0;j<n_parts ;j++ )
							{
								fflush(DML_Download_fp);
								fprintf(DML_Download_fp,AllTaskAttrDupS);
								
								fprintf(DML_Download_fp,"$");
								// Collecting Part Attributes for DML Download.
								// 1
								if (AOM_ask_value_string(part_obj_tag[j],"item_id",&PartNumberS)!=ITK_ok)   PrintErrorStack();
								printf("\n Complete_DML_Download : Task-Rev PartNumberS : %s \n",PartNumberS); fflush(stdout);
								fprintf(DML_Download_fp,PartNumberS);
								fprintf(DML_Download_fp,"$");

								// 2
								if (AOM_ask_value_string(part_obj_tag[j],"item_revision_id",&RevisionS)!=ITK_ok)   PrintErrorStack();
								printf("\n Complete_DML_Download : Task-Rev RevisionS : %s \n",RevisionS); fflush(stdout);
								fprintf(DML_Download_fp,RevisionS);
								fprintf(DML_Download_fp,"$");

								// 3
								if (AOM_ask_value_string(part_obj_tag[j],"sequence_id",&SequenceS)!=ITK_ok)   PrintErrorStack();
								printf("\n Complete_DML_Download : Task-Rev SequenceS : %s \n",SequenceS); fflush(stdout);
								fprintf(DML_Download_fp,SequenceS);
								fprintf(DML_Download_fp,"$");


								// 4 Effectivity Start Date is not present in TCUA
								//if (AOM_ask_value_string(part_obj_tag[j],"???",&???)!=ITK_ok)   PrintErrorStack();
								//printf("\n Complete_DML_Download : Task-Rev ??? : %s \n",???); fflush(stdout);
								fprintf(DML_Download_fp,"");
								fprintf(DML_Download_fp,"$");

								// 5 Effectivity End Date is not present in TCUA
								//if (AOM_ask_value_string(part_obj_tag[j],"???",&???)!=ITK_ok)   PrintErrorStack();
								//printf("\n Complete_DML_Download : Task-Rev ??? : %s \n",???); fflush(stdout);
								fprintf(DML_Download_fp,"");
								fprintf(DML_Download_fp,"$");
								fprintf(DML_Download_fp,"\n");
							}
						}
					}
				}
			}
			fflush(DML_Download_fp);
		}
		else
		{
			printf("\n XXXX \n");  fflush(stdout);
		}

	}
	if (flag == 0)
	{
		printf("\n Complete_DML_Download : DML Not Found \n ");  fflush(stdout);		
	}
	fclose(DML_Download_fp);


}
;



int ITK_user_main(int argc, char* argv[])
{
	int BUFFER_SIZE						=	500;
	int status = 0;
	int flag = 0;
	int ifail = ITK_ok;

	char *inputline				= NULL;
	char*	DmlNumberS			= NULL;
	//char*	DMLProjcode			= NULL;
	//char*	DMLDesc				= NULL;
	//char*	DMLGrp				= NULL;
	char*	DmlDownloadS;

	char**	stringArray			= NULL;
	char*	tempString			= NULL;
	char*	item_type			= NULL;
    char*	ObjectClassType4	= NULL;

	int n_tags_found = 0;

	tag_t	itemTypeTag		= NULLTAG;
	tag_t	newItemTag		= NULLTAG;
	tag_t	itemCreInTag	= NULLTAG;
	tag_t	itemRevCreInTag	= NULLTAG;
	tag_t	itemRevTypeTag	= NULLTAG;
	tag_t	newDmlTag		= NULLTAG;
	tag_t	newDmlRevTag	= NULLTAG;
	tag_t	newTaskTag		= NULLTAG;
	tag_t	newTaskRevTag	= NULLTAG;
	tag_t	Rel_task		= NULLTAG;
	tag_t	tRelationExist	= NULLTAG;
	tag_t	PartRel_task	= NULLTAG;
	tag_t	item_tag		= NULLTAG;
	tag_t	tPartRelationExist		= NULLTAG;
	
	ITK_initialize_text_services (0);

	tag_t *tags_left = NULLTAG;
	tag_t *tags_right = NULLTAG;


	//FILE *fp1;

	if( ITK_init_module("loader" ,"abc","dba")!=ITK_ok) ;


    ITK_CALL(ITK_initialize_text_services( ITK_BATCH_TEXT_MODE ));
	printf("\n Auto login ");fflush(stdout);
	ITK_CALL(ITK_auto_login( ));
    ITK_CALL(ITK_set_journalling( TRUE ));


	DmlNumberS = ITK_ask_cli_argument("-p=");
	printf("\n DmlNumberS = %s",DmlNumberS);  fflush(stdout);	

	DmlDownloadS = ITK_ask_cli_argument("-i=");
	printf("\n Output File = %s",DmlDownloadS);  fflush(stdout);

	

	//fp1 = fopen(DmlDownloadS,"a+");

	
	// Calling Function for Complete DML Downloading.
	Complete_DML_Download(DmlNumberS,DmlDownloadS);

	if (newDmlTag  != NULLTAG)
	{
		// Finding the Dml Revision for Creating its relation with the Task.

		ITK_CALL(ITEM_find_revision(newDmlTag,"A",&newDmlRevTag)) ;
		if (newDmlRevTag  != NULLTAG)
		{
			printf("\n YYYY \n");  fflush(stdout);
		}
		else
		{
			printf("\n XXXX \n");  fflush(stdout);
		}
	}

	ITK_exit_module (TRUE);
	return status;
}