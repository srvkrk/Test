/**********************************************************************************************************************************************************
**
** SOURCE FILE NAME: tm_Assign_Dynamic_party.c
**
**
**	Date				Author			Modification
**	01-01-2018			Mohan Tayade	Code creation
* 
* SrNo		Modified By		Date			Modification
*	1		Mohan Tayade	16 Aug 2022		Path for CV to call function for Assign dynamic participant.
*	2		Mohan Tayade	16 MAy 2023		for bypass for CVBU
***********************************************************************************************************************************************************/

#include <stdarg.h>
#include <tccore/custom.h>
#include <ict/ict_userservice.h>
#include <tc/iman.h>
#include <tccore/imantype.h>
#include <sa/imanfile.h>
#include <tc/preferences.h>
#include <lov/lov_msg.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <tccore/tc_msg.h>
#include <ae/dataset_msg.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <ecm/ecm.h>
#include <fclasses/tc_string.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <time.h>
#include <ae/ae.h>
#include <setjmp.h>
#include <ae/ae_errors.h>
#include <ae/ae_types.h> 
#include <unidefs.h>
#include <user_exits/user_exit_msg.h>
#include <pom/enq/enq.h>
#include <ug_va_copy.h>
#include <itk/mem.h>
#include <tie/tie_errors.h>
#include <tccore/grm.h>
#include <tccore/grmtype.h>
#include <user_exits/user_exits.h>
#include <tccore/method.h>
#include <property/prop.h>
#include <property/prop_msg.h>
#include <property/prop_errors.h>
#include <tccore/item.h>
#include <lov/lov.h>
#include <sa/sa.h>
#include <sa/site.h>
#include <res/res_itk.h>
#include <res/reservation.h>
#include <tccore/workspaceobject.h>
#include <tc/wsouif_errors.h>
#include <tccore/aom.h>
#include <publication/dist_user_exits.h>
#include <form/form.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <constants/constants.h>
#include <tc/emh_const.h>
#include <tccore/project.h>
#include <sa/groupmember.h>
#define PS_where_used_all_levels   -1 
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
static int PrintErrorStack( void )
/*
**
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
    int iNumErrs = 0;
    const int *pSevLst;
    const int *pErrCdeLst;
    const char **pMsgLst;
    register int i = 0;

    EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst ); 
	//fprintf( stderr, "in PrintErrorStack iNumErrs :%d \n",iNumErrs);
    for ( i = 0; i < iNumErrs; i++ )
    {
		fprintf( stderr, "Error(PrintErrorStack): \n");
        fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
    }
    return ITK_ok;
}

/****************************************************************************
*   Function name			: Assign_Dynamic_party_Func
*   Description				: To set dynamic participant for dml and task in workflow.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		22/01/2018			Mohan Tayade	1.30: Set dynamic participants for dml and task
*
****************************************************************************/
int Assign_Dynamic_party_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;
	char	*DMLNo			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=  NULL;
	char	*groupName		= NULL;
	char	*DsgGrp			= NULL;
	char	*Task_name		= NULL;
	
	//BOM Analyst
	int     DsgGrup = 0;
	int     i = 0;
	int     No_BomAna = 0;
	tag_t   BomAna_Rev			= NULLTAG;
	tag_t   BAGrp_tag			= NULLTAG;
	tag_t   BomAnalyst_tag		= NULLTAG;
	tag_t	BomAna_Patri_Type	= NULLTAG;
	tag_t*  BomAna				= NULLTAG;
	tag_t	BomAna_Party		= NULLTAG;
	const char*   BomAnalyst_role = "BomAnalyst";
	//VI Reviewer
	int     iii = 0;
	int     No_VIAna = 0;
	tag_t   VIAna_Rev			= NULLTAG;
	tag_t   VIGrp_tag			= NULLTAG;
	tag_t   VIAnalyst_tag		= NULLTAG;
	tag_t	VIAna_Patri_Type	= NULLTAG;
	tag_t*  VIAna				= NULLTAG;
	tag_t	VIAna_Party		= NULLTAG;
	const char*   VIAnalyst_role = "VI_Reviewer";

	//CE Reviewer
	int     ik = 0;
	int     No_CEAna = 0;
	tag_t   CEAna_Rev			= NULLTAG;
	tag_t   CEGrp_tag			= NULLTAG;
	tag_t   CEAnalyst_tag		= NULLTAG;
	tag_t	CEAna_Patri_Type	= NULLTAG;
	tag_t*  CEAna				= NULLTAG;
	tag_t	CEAna_Party		= NULLTAG;
	const char*   CEAnalyst_role = "CE_Reviewer";

	//Peer_reviewer
	int     ii = 0;
	int     No_Peer = 0;
	tag_t   Peer_Rev			= NULLTAG;
	tag_t   PeerGrp_tag			= NULLTAG;
	tag_t   Peer_tag		= NULLTAG;
	tag_t	Peer_Patri_Type	= NULLTAG;
	tag_t*  Peer_t			= NULLTAG;
	tag_t	Peer_Party			= NULLTAG;
	const char*   Brake_Peer_role = "CoC_Brakes_Controls_Peer_PVBU";
	const char*   BIW_Peer_role = "CoC_CAB_BIW_Peer_PVBU";
	const char*   Door_Peer_role = "CoC_CAB_Door_Peer_PVBU";
	const char*   ExtTrims_Peer_role = "CoC_CAB_Ext_Trims_Peer_PVBU";
	const char*   Fit_Peer_role = "CoC_CAB_Int_Fittings_Peer_PVBU";
	const char*   IntTrims_Peer_role = "CoC_CAB_Int_Trims_Peer_PVBU";
	const char*   Mascots_Peer_role = "CoC_CAB_Mascots_Peer_PVBU";
	const char*   Seat_Peer_role = "CoC_CAB_Seats_Peer_PVBU";
	const char*   EE_Peer_role = "CoC_E&E_Peer_PVBU";
	const char*   Exhaust_Peer_role = "CoC_Exhaust_Peer_PVBU";
	const char*   Frame_Peer_role = "CoC_Frames_Peer_PVBU";
	const char*   Fuel_Peer_role = "CoC_Fuel_System_Peer_PVBU";
	const char*   HVAC_Peer_role = "CoC_HVAC_Peer_PVBU";
	const char*   Mounts_Peer_role = "CoC_Mounts_Peer_PVBU";
	const char*   Restrn_Peer_role = "CoC_Restraints_Peer_PVBU";
	const char*   Steering_Peer_role = "CoC_Steering_Peer_PVBU";
	const char*   Suspension_Peer_role = "CoC_Suspension_Peer_PVBU";
	const char*   Tools_Peer_role = "CoC_Tools_Acessories_Peer_PVBU";

	//DMU_reviewer
	int     im = 0;
	int     No_DMU = 0;
	tag_t   DMUGrp_tag		= NULLTAG;
	tag_t   DMU_Rev			= NULLTAG;
	tag_t   DMU_tag		= NULLTAG;
	tag_t	DMU_Patri_Type	= NULLTAG;
	tag_t*  DMU_t			= NULLTAG;
	tag_t	DMU_Party		= NULLTAG;
	const char*   Brake_DMU_role = "CoC_Brakes_Controls_DMU_PVBU";
	const char*   BIW_DMU_role = "CoC_CAB_BIW_DMU_PVBU";
	const char*   Door_DMU_role = "CoC_CAB_Door_DMU_PVBU";
	const char*   ExtTrims_DMU_role = "CoC_CAB_Ext_Trims_DMU_PVBU";
	const char*   Fit_DMU_role = "CoC_CAB_Int_Fittings_DMU_PVBU";
	const char*   IntTrims_DMU_role = "CoC_CAB_Int_Trims_DMU_PVBU";
	const char*   Mascots_DMU_role = "CoC_CAB_Mascots_DMU_PVBU";
	const char*   Seat_DMU_role = "CoC_CAB_Seats_DMU_PVBU";
	const char*   EE_DMU_role = "CoC_E&E_DMU_PVBU";
	const char*   Exhaust_DMU_role = "CoC_Exhaust_DMU_PVBU";
	const char*   Frame_DMU_role = "CoC_Frames_DMU_PVBU";
	const char*   Fuel_DMU_role = "CoC_Fuel_System_DMU_PVBU";
	const char*   HVAC_DMU_role = "CoC_HVAC_DMU_PVBU";
	const char*   Mounts_DMU_role = "CoC_Mounts_DMU_PVBU";
	const char*   Restrn_DMU_role = "CoC_Restraints_DMU_PVBU";
	const char*   Steering_DMU_role = "CoC_Steering_DMU_PVBU";
	const char*   Suspension_DMU_role = "CoC_Suspension_DMU_PVBU";
	const char*   Tools_DMU_role = "CoC_Tools_Acessories_DMU_PVBU";


	//SVR COC Reviewer (Task)
	tag_t	*GmFound1 = NULLTAG;
	tag_t	*GmFound2 = NULLTAG;
	tag_t	*GmFound3 = NULLTAG;
	char*	 sUserId = NULL;
	char*	 GrpMembName = NULL;
	tag_t	GrpTag = NULLTAG;
	int	AccesFound=0;
	int	jkl=0;
	int	Gmcnt1=0;
	int	Gmcnt2=0;
	int	Gmcnt3=0;
	const char*   BIW_SVRCoC_role = "BIW_COC_Reviewer";
	const char*   Trim_SVRCoC_role = "Trim_COC_Reviewer";
	const char*   CH_SVRCoC_role = "Chassis_COC_Reviewer";
	const char*   EE_SVRCoC_role = "EE_COC_Reviewer";
	const char*   PT_SVRCoC_role = "Powertrain_COC_Reviewer";
	//BIW_COC_Reviewer
	int     b = 0;
	int     No_SVRcoc = 0;
	tag_t   SVRcocGrp_tag	= NULLTAG;
	tag_t   SVRcoc_tag		= NULLTAG;
	tag_t	SVRcoc_Patri_Type	= NULLTAG;
	tag_t*  SVRcoc_t			= NULLTAG;
	tag_t	SVRcoc_Party		= NULLTAG;
	//Trim_SVRCoC_role
	int     tr = 0;
	int     No_SVRt = 0;
	tag_t   SVRtGrp_tag	= NULLTAG;
	tag_t   SVRt_tag		= NULLTAG;
	tag_t	SVRt_Patri_Type	= NULLTAG;
	tag_t*  SVRt_t			= NULLTAG;
	tag_t	SVRt_Party		= NULLTAG;
	//CH_SVRCoC_role
	int     c = 0;
	int     No_SVRc = 0;
	tag_t   SVRcGrp_tag	= NULLTAG;
	tag_t   SVRc_tag		= NULLTAG;
	tag_t	SVRc_Patri_Type	= NULLTAG;
	tag_t*  SVRc_t			= NULLTAG;
	tag_t	SVRc_Party		= NULLTAG;
	//EE_SVRCoC_role
	int     e = 0;
	int     No_SVRe = 0;
	tag_t   SVReGrp_tag	= NULLTAG;
	tag_t   SVRe_tag		= NULLTAG;
	tag_t	SVRe_Patri_Type	= NULLTAG;
	tag_t*  SVRe_t			= NULLTAG;
	tag_t	SVRe_Party		= NULLTAG;
	//PT_SVRCoC_role
	int     p = 0;
	int     No_SVRp = 0;
	tag_t   SVRpGrp_tag	= NULLTAG;
	tag_t   SVRp_tag		= NULLTAG;
	tag_t	SVRp_Patri_Type	= NULLTAG;
	tag_t*  SVRp_t			= NULLTAG;
	tag_t	SVRp_Party			= NULLTAG;

	// Participants remove.
	int jk = 0;
	int jkk = 0;
	int kk = 0;
	int jtsk = 0;
	int CRBcount = 0;
	int CRBcunt = 0;
	char	*TskReviewr		= NULL;
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char 	*ProjectID		= NULL;
	char	*DMLReviewr		= NULL;
	char	*Part_prj		= NULL;
	tag_t Tsk_CRB_rel_type	= NULLTAG;
	tag_t dml_CRB_rel_type	= NULLTAG;
	tag_t* TskCRB = NULLTAG;
	tag_t* DmlCRB = NULLTAG;
	tag_t	TskCRBTag		= NULLTAG;
	tag_t	DmlCRBTag		= NULLTAG;
	tag_t	ObjTypProj		= NULLTAG;
	tag_t	ObjTypDmlCRB	= NULLTAG;
	tag_t	TskTypeTag	= NULLTAG;
	tag_t	ObjTypTskCRB	= NULLTAG;
	tag_t	TskRev_tg		= NULLTAG;
	char*   type_Proj=NULL;
	char*   type_name7=NULL;
	char*   type_name8=NULL;
	char*   Tsk_Typ=NULL;
	logical is_Tskletst;
	logical is_Tskltst;
	logical hasbypass =true;

	//Task variables
	int     PltFrmPartFlg	=  0;
	int     prt		=  0;
	int     t		=  0;
	int     PRDFlag	=  0;
	int     Taskcout	=  0;
	int     partcnt		=  0;
	int     Tskcout		=  0;
	char	*Proj_BU		= NULL;
	char	*Part_no		= NULL;
	char	*BomAna_Role		= NULL;
	//char	*BIW_SVRCoC_role	= NULL;
	//char	*Trim_SVRCoC_role	= NULL;
	//char	*CH_SVRCoC_role		= NULL;
	//char	*EE_SVRCoC_role		= NULL;
	//char	*PT_SVRCoC_role		= NULL;
	char	*Tsk_class		= NULL;
	tag_t   *TskRevn_tag    =  NULLTAG;
	tag_t   *TskRev_tag    =  NULLTAG;
	tag_t   *PartsTag    =  NULLTAG;
	tag_t	TskCls_t		= NULLTAG;
	tag_t	TskRev_t		= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	DmlTask_tag		= NULLTAG;
	tag_t	DmlTsk_tag		= NULLTAG;
	tag_t	tUserTag		= NULLTAG;
	tag_t	AssyTag		= NULLTAG;
	logical is_Tsklatst;
	int error_code = ITK_ok;
	//Qry Project
	char	*info1	= NULL;
	tag_t	queryTag   = NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	tag_t	Project_tag  = NULLTAG;
	char	*info2	= NULL;
	char	*info3	= NULL;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	int     n_entry    = 1;  
	int     rsltCount      =  0; 
	int		resultCount = 0;
	int		n_entries = 1;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	//Assign CE Reviewer On basis of Group Handle..
	char	*DMLReason		=  NULL;
	char	*sDMLBU		=  NULL;
	char	*DMLDrStat		=  NULL;
	char	*DMLDesignGrp		=  NULL;
	char	*DMLVertical		=  NULL;
	char	*DML_CE_Group		=  NULL;
	char	*DML_MGR_Group		=  NULL;
	char	*MgrAnalyst_role	= NULL;
	tag_t	dml_vertical_qryTag		= NULLTAG;
	tag_t	*dml_vertical_CntrlObjectTag		= NULLTAG;
	char command[512];
	char    *dml_vertical_qry_entry[1]  = {"SYSCD"};
	char    **dml_vertical_qry_values =  (char **) MEM_alloc(10 * sizeof(char *));
	int dml_vertical_rsltCount =0;
	int dml_vertical_n_entry =1;
	//int num =0;
	tag_t   MgrGrp_tag     = NULLTAG;
	tag_t   MgrAnalyst_tag     = NULLTAG;
	tag_t   *MGRAna     = NULLTAG;

	tag_t	MGRAna_Patri_Type	= NULLTAG;
	tag_t	MGRAna_Party		= NULLTAG;
	int No_MGRAna =0;
	char	*ErcGroupName	= NULL;
	tag_t	Erc_group_tag	= NULLTAG;

	printf("\n MT: Dynamic particiant assignment start.......");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n MT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
	printf("\n MT:DML/Task Number: [%s].", DMLNo);fflush(stdout);
	//t5_rlstype

	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

	groupName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"DML_Participants_Group");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

	if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
	{
		if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
		printf("\n MT:DML Number: [%s] DMLType: [%s]", DMLNo,DMLType);fflush(stdout);
		if(AOM_ask_value_string(attachment[0],"t5_ERCBusiUt",&sDMLBU)!=ITK_ok)PrintErrorStack();
		printf("\n CH:sDMLBU is :%s\n",sDMLBU);fflush(stdout);
		if(tc_strstr(sDMLBU,"CV") != NULL)
		{
			printf("\n MT:Assign dynamic Party handler bypassed for CVBU..");fflush(stdout);
		}
		else
		{
			if(tc_strcmp(DMLType,"Veh")!=0)
			{
				if(AOM_ask_value_string(attachment[0],"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
				printf("\n MT: ProjectID : %s",ProjectID);   fflush(stdout);

				//if(ITEM_find_item(ProjectID,&Project_t)!=ITK_ok)PrintErrorStack();
				if(ProjectID)
				{
					if(QRY_find2("Qury_Project", &queryTag));
					printf("\n MT:After Prd_Project: QRY_find");fflush(stdout);
					if (queryTag)
					{
						printf("\n MT:Found Query");fflush(stdout);
					}
					else
					{
						printf("\n MT:Not Found Query");fflush(stdout);
					}

					qry_values[0] = ProjectID;

					if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
					printf("\n MT: resultCount : %d\n", resultCount); fflush(stdout);

					if(resultCount > 0)
					{
						printf("\n MT:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
						Project_t = t5_Project[0];
						if (Project_t!=NULLTAG)
						{
							if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
							printf("\n MT: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
							//Query control table for PRDtoCVBU workflow project list.
							printf("\n MT:.Checking PRD  to CVBU WF project...\n"); fflush(stdout);
							if(QRY_find2("ControlObjects", &qryTag));
							if (qryTag)
							{
								printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
							}
							else
							{
								printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
							}

							qry_values2[0] = "PRDCVBU";
							if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
							printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
							if(rsltCount > 0)
							{
								if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
								printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
								if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
								printf("\n info2 is.:[%s]\n", info2);fflush(stdout);
								if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
								printf("\n info3 is.:[%s]\n", info3);fflush(stdout);
							}
							if(tc_strstr(info3,"DMLASGPV")==NULL)
							{
								printf("\n %s:Exe logic to set reviewer start...",DMLNo);fflush(stdout);
								if(tc_strcmp(ProjectClass,"PRD")==0)
								{
									if((tc_strstr(info1,ProjectID)!=NULL) || (tc_strstr(info2,ProjectID)!=NULL))
									{
										PRDFlag=1;
										printf("\n MT:.PRD project of CVBU found: %d",PRDFlag); fflush(stdout);
									}
									else
									{
										PRDFlag=0;
										printf("\n MT:.No project CVBU found: %d",PRDFlag); fflush(stdout);
									}
								}
								else
								{
									PRDFlag=1;
									printf("\n MT:.No PRD project: %d",PRDFlag); fflush(stdout);
								}
								if (PRDFlag >0)
								{
									//############################### REMOVE PARTICIPALNTS START################################/
									if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
									if (dml_CRB_rel_type!=NULLTAG)
									{
										printf("\n MT:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
										if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
										printf("\n MT: DmlCRB count: %d",CRBcount);fflush(stdout);	
										for (jk=0;jk<CRBcount ;jk++ )
										{	
											//printf("\n MT:jk: %d.\n",jk);fflush(stdout);
											DmlCRBTag = DmlCRB[jk];
											if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
											if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
											printf("\n MT:DML: Participants Name: %s", type_name7);fflush(stdout);
											if(tc_strcmp(DMLType,"SVR")!=0)
											{
												if ((tc_strcmp(type_name7,"T5_BOMAnalyst")==0)||(tc_strcmp(type_name7,"T5_PPReviewer")==0))
												{
													if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
													printf("\n MT: Removing BOM/PP reviewer: [%s] ",DMLReviewr);fflush(stdout);
													AOM_lock(objTag);
													if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
													AOM_save_without_extensions(objTag);
													AOM_unlock(objTag);
												}
											}
											else
											{
												if (tc_strcmp(type_name7,"T5_VIReviewer")==0)
												{
													if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
													printf("\n MT:Removing VI Reviewer: [%s] ",DMLReviewr);fflush(stdout);
													AOM_lock(objTag);
													if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
													AOM_save_without_extensions(objTag);
													AOM_unlock(objTag);
												}
											}
										}
									}
									printf("\n MT:START ASSIGNING REVIEWERS: DML: [%s] Type: [%s] PltFrm :[%s] Proj_BU:[%s]", DMLNo,DMLType,Proj_PltFrm,Proj_BU);fflush(stdout);
									if((tc_strcmp(Proj_BU,"PCBU")==0)||(tc_strcmp(Proj_BU,"PVBU")==0))
									{
										if(tc_strcmp(DMLType,"SVR")==0)
										{
											//VI Reviewer for SVR only.
											printf("\n MT:PCBU: Setting VI Analyst...");fflush(stdout);
											if(SA_find_group(groupName, &VIGrp_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_role2(VIAnalyst_role,&VIAnalyst_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_groupmember_by_role(VIAnalyst_tag,VIGrp_tag,&No_VIAna,&VIAna)!=ITK_ok)PrintErrorStack();
											printf("\n MT:PCBU:No_VIAna :[%d]",No_VIAna);  fflush(stdout);
											if(No_VIAna>0)
											{
												for(iii=0;iii<No_VIAna;iii++)
												{	
													printf("\n MT:PCBU: VI Reviewer no: [%d]",iii);fflush(stdout);
													if(EPM_get_participanttype ("T5_VIReviewer",&VIAna_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(VIAna[iii],VIAna_Patri_Type,&VIAna_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(objTag);			
													if(PARTICIPANT_add_participant(objTag,hasbypass,VIAna_Party)!=ITK_ok)PrintErrorStack();
													AOM_save_without_extensions(objTag);
													AOM_unlock(objTag);
												}
											}
											AOM_refresh ( objTag,TRUE);
											MEM_free(VIAna);
										}
										else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
										{
											if(tc_strcmp(Proj_PltFrm,"")!=0)
											{
												if(tc_strcmp(Proj_PltFrm,"TBD")==0)
												{
													printf("\n MT:PCBU:BOM ANalyst Set to NULL since platform is TBD...");fflush(stdout);
												}
												else
												{
													BomAna_Role = (char	*)MEM_alloc(100);
													tc_strcpy(BomAna_Role,"");
													tc_strcpy(BomAna_Role,Proj_PltFrm);
													tc_strcat(BomAna_Role,"_");
													tc_strcat(BomAna_Role,"BOM_Analyst");
													printf("\n MT:PCBU: after BomAna_Role: %s",BomAna_Role);   fflush(stdout);
													if(SA_find_group(groupName, &BAGrp_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_role2(BomAna_Role,&BomAnalyst_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(BomAnalyst_tag,BAGrp_tag,&No_BomAna,&BomAna)!=ITK_ok)PrintErrorStack();
													printf("\n MT:PCBU:No_BomAna :[%d]",No_BomAna);  fflush(stdout);
													if(No_BomAna>0)
													{
														for(i=0;i<No_BomAna;i++)
														{	
															printf("\n MT:PCBU:BOM Analyst no: [%d]",i);fflush(stdout);
															if(EPM_get_participanttype ("T5_BOMAnalyst",&BomAna_Patri_Type)!=ITK_ok)PrintErrorStack();
															if(EPM_create_participant(BomAna[i],BomAna_Patri_Type,&BomAna_Party)!=ITK_ok)PrintErrorStack();
															AOM_lock(objTag);			
															if(PARTICIPANT_add_participant(objTag,hasbypass,BomAna_Party)!=ITK_ok)PrintErrorStack();	
															AOM_save_without_extensions(objTag);
															AOM_unlock(objTag);
														}
													}
													AOM_refresh (objTag,TRUE);
													MEM_free(BomAna);
												}
											}
											else
											{
												printf("\n MT:Proj Platform is NULL...");fflush(stdout);
											}
										}
										else
										{
											printf("\n MT: NO Assignment for XO/TOO/PDR dmls...... \n"); fflush(stdout);
										}
										//################# REVIEWERS FOR TASK START #####################/
										printf("\n MT:PVBU:TASK:REMOVING REVIEWERS FOR TASK START......\n");fflush(stdout);
										if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTask_tag)!=ITK_ok)PrintErrorStack();
										if (DmlTask_tag!=NULLTAG)
										{		
											if(GRM_list_secondary_objects_only(objTag,DmlTask_tag,&Tskcout,&TskRev_tag)!=ITK_ok)PrintErrorStack();
											printf("\n MT:TASK:TskRev_tag Tskcout : %d",Tskcout);fflush(stdout);
											for (jkk=0;jkk<Tskcout ;jkk++ )
											{
												if(ITEM_rev_sequence_is_latest(TskRev_tag[jkk],&is_Tskletst)!=ITK_ok)PrintErrorStack();
												//printf("\n MT:.is_Tskletst. %d",is_Tskletst);fflush(stdout);
												if(is_Tskletst != true)
												{
													printf("\n MT:TASK:is_Tskletst is not true .....\n");fflush(stdout);
												}
												else
												{	
													TskRev_tg = TskRev_tag[jkk];
													if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
													if (Tsk_CRB_rel_type!=NULLTAG)
													{
														if(GRM_list_secondary_objects_only(TskRev_tg,Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
														printf("\n MT:TASK: count: %d",CRBcunt);fflush(stdout);	
														for (jtsk=0;jtsk<CRBcunt ;jtsk++ )
														{	
															TskCRBTag = TskCRB[jtsk];
															if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
															if(TCTYPE_ask_name2(ObjTypTskCRB,&type_name8));
															printf("\n MT:TASK: Participant Name: %s\n", type_name8);fflush(stdout);
															if(tc_strcmp(DMLType,"SVR")==0)
															{
																if ((tc_strcmp(type_name8,"T5_BIWReviewer")==0)||(tc_strcmp(type_name8,"T5_PTReviewer")==0)||(tc_strcmp(type_name8,"T5_EEReviewer")==0)||
																	(tc_strcmp(type_name8,"T5_CHReviewer")==0)||(tc_strcmp(type_name8,"T5_TRIMReviewer")==0))
																{
																	printf("\n MT:TASK:: Removing "); fflush(stdout);
																	if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
																	printf(" reviewer: [%s]\n",TskReviewr);fflush(stdout);
																	AOM_lock(TskRev_tg);
																	if(PARTICIPANT_remove_participant(TskRev_tg,TskCRBTag) !=ITK_ok)PrintErrorStack();
																	AOM_save_without_extensions(TskRev_tg);
																	AOM_unlock(TskRev_tg);
																}
															}
															else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
															{
																if ((tc_strcmp(type_name8,"T5_DMUReviewer")==0)|| (tc_strcmp(type_name8,"T5_PeerReviewer")==0))
																{
																	printf("\n MT:TASK: Removing "); fflush(stdout);
																	if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
																	printf(" reviewer: [%s]\n",TskReviewr);fflush(stdout);
																	AOM_lock(TskRev_tg);
																	if(PARTICIPANT_remove_participant(TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
																	AOM_save_without_extensions(TskRev_tg);
																	AOM_unlock(TskRev_tg);
																}
															}
															else
															{
																printf("\n MT: Other dml type... \n"); fflush(stdout);
															}
														}
													}
												}
											}

											printf("\n MT:PVBU:ADDING REVIEWERS FOR TASK START......\n");fflush(stdout);
											for (t=0;t<Tskcout ;t++ )
											{ 
												No_DMU=0;
												No_Peer=0;
												if(ITEM_rev_sequence_is_latest(TskRev_tag[t],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
												//printf("\n MT:is_Tsklatst %d",is_Tsklatst);fflush(stdout);

												if(is_Tsklatst != true)
												{
													printf("\n MT:is_Tsklatst is not true .....\n");fflush(stdout);
												}
												else
												{	
													TskRev_t = TskRev_tag[t];
													if(POM_class_of_instance(TskRev_t,&TskCls_t)!=ITK_ok)PrintErrorStack();
													if(POM_name_of_class(TskCls_t,&Tsk_class)!=ITK_ok)PrintErrorStack();
													printf("\n MT: Task class..:%s",Tsk_class); fflush(stdout);
													if(tc_strcmp(Tsk_class,"T5_ChangeTaskRevision")==0)
													{
														//Setting DMU Reviewers.
														if(AOM_UIF_ask_value(TskRev_t,"item_id",&Task_name)!=ITK_ok)PrintErrorStack();
														printf("\n MT: Task Name :[%s]",Task_name);fflush(stdout);
														DsgGrp=subString(Task_name,11,2);
														DsgGrup=(int) atoi(DsgGrp);
														printf(" and design group: [%s]\n",DsgGrp);fflush(stdout);
														if(tc_strcmp(DMLType,"SVR")==0)
														{
															//SVR COC REVIEWER...
															No_SVRcoc=0;
															No_SVRc=0;
															No_SVRe=0;
															No_SVRp=0;
															No_SVRt=0;
															//get Project access check:
															if(tc_strstr(info3,"SVRCOC")==NULL)
															{
																Gmcnt1=0;
																Gmcnt2=0;
																Gmcnt3=0;
																GmFound1 =NULLTAG;
																GmFound2 =NULLTAG;
																GmFound3 =NULLTAG;
																printf("\n DML:Getting Project Team...\n");fflush(stdout);
																if (PROJ_ask_team(Project_t,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();
																printf("\n DML:Gmcnt1 %d \n",Gmcnt1);fflush(stdout);
															}
															//BIW Reviewer.
															if(SA_find_group(groupName, &SVRcocGrp_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_role2(BIW_SVRCoC_role,&SVRcoc_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(SVRcoc_tag,SVRcocGrp_tag,&No_SVRcoc,&SVRcoc_t)!=ITK_ok)PrintErrorStack();
															if(No_SVRcoc>0)
															{
																for(b=0;b<No_SVRcoc;b++)
																{	
																	printf("\n MT: BIW_SVRCoC_role: %d",b);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(info3,"SVRCOC")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(SVRcoc_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n MT: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"BIW_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n DML:BIW_COC_Reviewer access avail...\n");fflush(stdout);
																					AccesFound=1;
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n MT: BIW_SVRCoC_role.");fflush(stdout);
																		if(EPM_get_participanttype ("T5_BIWReviewer",&SVRcoc_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(SVRcoc_t[b],SVRcoc_Patri_Type,&SVRcoc_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);			
																		if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRcoc_Party)!=ITK_ok)PrintErrorStack();	
																		AOM_save_without_extensions(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																	if(AccesFound >0)
																	{
																		printf("\n MT: BIW_SVRCoC_role assigned:%s",sUserId);fflush(stdout);
																		if(EPM_get_participanttype ("T5_BIWReviewer",&SVRcoc_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(SVRcoc_t[b],SVRcoc_Patri_Type,&SVRcoc_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);			
																		if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRcoc_Party)!=ITK_ok)PrintErrorStack();	
																		AOM_save_without_extensions(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(SVRcoc_t);
															}
															//TRIM Reviewer
															if(SA_find_group(groupName, &SVRtGrp_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_role2(Trim_SVRCoC_role,&SVRt_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(SVRt_tag,SVRtGrp_tag,&No_SVRt,&SVRt_t)!=ITK_ok)PrintErrorStack();
															if(No_SVRt>0)
															{
																for(tr=0;tr<No_SVRt;tr++)
																{	
																	printf("\n MT: TRIM reviewer no: %d",tr);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(info3,"SVRCOC")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(SVRt_t[tr],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n MT: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Trim_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n DML:Trim_COC_Reviewer access avail...\n");fflush(stdout);
																					AccesFound=1;
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n MT: TRIM reviewer.");fflush(stdout);
																		if(EPM_get_participanttype ("T5_TRIMReviewer",&SVRt_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(SVRt_t[tr],SVRt_Patri_Type,&SVRt_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);			
																		if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRt_Party)!=ITK_ok)PrintErrorStack();	
																		AOM_save_without_extensions(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																	if (AccesFound >0)
																	{
																		printf("\n MT: TRIM reviewer assigned:%s",sUserId);fflush(stdout);
																		if(EPM_get_participanttype ("T5_TRIMReviewer",&SVRt_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(SVRt_t[tr],SVRt_Patri_Type,&SVRt_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);			
																		if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRt_Party)!=ITK_ok)PrintErrorStack();	
																		AOM_save_without_extensions(TskRev_t);
																		AOM_unlock(TskRev_t);

																	}
																}
																AOM_refresh (TskRev_t,TRUE);
																MEM_free(SVRt_t);
															}
															//CHASSIS SVR ROLE
															if(SA_find_group(groupName, &SVRcGrp_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_role2(CH_SVRCoC_role,&SVRc_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(SVRc_tag,SVRcGrp_tag,&No_SVRc,&SVRc_t)!=ITK_ok)PrintErrorStack();
															if(No_SVRc>0)
															{
																for(c=0;c<No_SVRc;c++)
																{	
																	printf("\n MT: CH reviewer no: %d",c);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(info3,"SVRCOC")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(SVRc_t[c],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n MT: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Chassis_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n DML:Chassis_COC_Reviewer access avail...\n");fflush(stdout);
																					AccesFound=1;
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n MT: CHS reviewer assigned.");fflush(stdout);
																		if(EPM_get_participanttype ("T5_CHReviewer",&SVRc_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(SVRc_t[c],SVRc_Patri_Type,&SVRc_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);			
																		if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRc_Party)!=ITK_ok)PrintErrorStack();	
																		AOM_save_without_extensions(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																	if (AccesFound >0)
																	{
																		printf("\n MT: CHS reviewer assigned:%s",sUserId);fflush(stdout);
																		if(EPM_get_participanttype ("T5_CHReviewer",&SVRc_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(SVRc_t[c],SVRc_Patri_Type,&SVRc_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);			
																		if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRc_Party)!=ITK_ok)PrintErrorStack();	
																		AOM_save_without_extensions(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh (TskRev_t,TRUE);
																MEM_free(SVRc_t);
															}
															//EE COC reviewer
															if(SA_find_group(groupName, &SVReGrp_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_role2(EE_SVRCoC_role,&SVRe_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(SVRe_tag,SVReGrp_tag,&No_SVRe,&SVRe_t)!=ITK_ok)PrintErrorStack();
															if(No_SVRe>0)
															{
																for(e=0;e<No_SVRe;e++)
																{	
																	printf("\n MT: peer reviewer no: %d",e);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(info3,"SVRCOC")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(SVRe_t[e],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n MT: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"EE_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n DML:EE_COC_Reviewer access avail...\n");fflush(stdout);
																					AccesFound=1;
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		if(EPM_get_participanttype ("T5_EEReviewer",&SVRe_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(SVRe_t[e],SVRe_Patri_Type,&SVRe_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);			
																		if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRe_Party)!=ITK_ok)PrintErrorStack();	
																		AOM_save_without_extensions(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																	if (AccesFound >0)
																	{
																		printf("\n EE reviewer assigned: %s",sUserId);fflush(stdout);
																		if(EPM_get_participanttype ("T5_EEReviewer",&SVRe_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(SVRe_t[e],SVRe_Patri_Type,&SVRe_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);			
																		if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRe_Party)!=ITK_ok)PrintErrorStack();	
																		AOM_save_without_extensions(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh (TskRev_t,TRUE);
																MEM_free(SVRe_t);
															}
															//Powertrain reviewer
															if(SA_find_group(groupName, &SVRpGrp_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_role2(PT_SVRCoC_role,&SVRp_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(SVRp_tag,SVRpGrp_tag,&No_SVRp,&SVRp_t)!=ITK_ok)PrintErrorStack();
															if(No_SVRp>0)
															{
																for(p=0;p<No_SVRp;p++)
																{	
																	printf("\n MT: PT_SVRCoC reviewer no: %d",p);fflush(stdout);
																	AccesFound=0;
																	if(tc_strstr(info3,"SVRCOC")==NULL)
																	{
																		sUserId=NULL;
																		if(SA_ask_groupmember_user(SVRp_t[p],&tUserTag)!=ITK_ok)   PrintErrorStack();
																		if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
																		printf("\n MT: sUserId: %s",sUserId);fflush(stdout);
																		jkl=0;
																		for(jkl=0;jkl<Gmcnt1;jkl++)
																		{
																			AccesFound=0;
																			GrpMembName=NULL;
																			GrpTag = GmFound1[jkl];
																			if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
																			printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																			if(GrpMembName)
																			{
																				if((tc_strstr(GrpMembName,"Powertrain_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																				{
																					printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																					printf("\n DML:Powertrain_COC_Reviewer access avail...\n");fflush(stdout);
																					AccesFound=1;
																					break;
																				}
																			}
																		}
																	}
																	else
																	{
																		printf("\n POWRTRN reviewer assigned");fflush(stdout);
																		if(EPM_get_participanttype ("T5_PTReviewer",&SVRp_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(SVRp_t[p],SVRp_Patri_Type,&SVRp_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);			
																		if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRp_Party)!=ITK_ok)PrintErrorStack();	
																		AOM_save_without_extensions(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																	if (AccesFound >0)
																	{
																		printf("\n POWRTRN reviewer assigned: %s",sUserId);fflush(stdout);
																		if(EPM_get_participanttype ("T5_PTReviewer",&SVRp_Patri_Type)!=ITK_ok)PrintErrorStack();
																		if(EPM_create_participant(SVRp_t[p],SVRp_Patri_Type,&SVRp_Party)!=ITK_ok)PrintErrorStack();
																		AOM_lock(TskRev_t);			
																		if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRp_Party)!=ITK_ok)PrintErrorStack();	
																		AOM_save_without_extensions(TskRev_t);
																		AOM_unlock(TskRev_t);
																	}
																}
																AOM_refresh (TskRev_t,TRUE);
																MEM_free(SVRp_t);
															}
														}
														else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
														{
															//COC DMU Reviewer
															printf("\n MT:SETTING COC DMU Reviewer.....: ");fflush(stdout);
															if(SA_find_group(groupName, &DMUGrp_tag)!=ITK_ok)PrintErrorStack();
															if((DsgGrup ==29) ||(DsgGrup ==30)||(DsgGrup ==42) ||(DsgGrup ==43))
															{
																printf("Brake_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Brake_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if ((DsgGrup >=60) && (DsgGrup <=66))
															{
																printf("BIW_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(BIW_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if ((DsgGrup >=70) && (DsgGrup <=80))
															{
																printf("Door_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Door_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==88)
															{
																printf("ExtTrims_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(ExtTrims_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==81)
															{
																printf("Fit_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Fit_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if ((DsgGrup >=67) && (DsgGrup <=69))
															{
																printf("IntTrims_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(IntTrims_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==55)
															{
																printf("Mascots_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Mascots_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if ((DsgGrup >=91) && (DsgGrup <=96))
															{
																printf("Seat_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Seat_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if((DsgGrup ==54)||(DsgGrup ==15)||(DsgGrup ==16)||(DsgGrup ==04)||(DsgGrup ==82))
															{
																printf("EE_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(EE_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==49)
															{
																printf("Exhaust_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Exhaust_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==31)
															{
																printf("Frame_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Frame_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==47)
															{
																printf("Fuel_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Fuel_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==83)
															{
																printf("HVAC_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(HVAC_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==24)
															{
																printf("Mounts_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Mounts_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==97)
															{
																printf("Restrn_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Restrn_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==46)
															{
																printf("Steering_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Steering_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if((DsgGrup ==32)||(DsgGrup ==35)||(DsgGrup ==33)||(DsgGrup ==40)||(DsgGrup ==41))
															{
																printf("Suspension_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Suspension_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==58)
															{
																printf("Tools_DMU_role.. \n"); fflush(stdout);
																if(SA_find_role2(Tools_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
															}
															else
															{
																printf("\n MT: ELSE Other design group.. \n"); fflush(stdout);
															}
															
															printf("\n MT: Find  grp member for DMU count..%d \n",No_DMU); fflush(stdout);
															if(No_DMU>0)
															{
																im=0;
																for(im=0;im<No_DMU;im++)
																{	
																	printf("\n MT: DMU Reviewer no: %d",im);fflush(stdout);
																	if(EPM_get_participanttype ("T5_DMUReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
																	if(EPM_create_participant(DMU_t[im],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
																	AOM_lock(TskRev_t);			
																	if(PARTICIPANT_add_participant(TskRev_t,hasbypass,DMU_Party)!=ITK_ok)PrintErrorStack();	
																	AOM_save_without_extensions(TskRev_t);
																	AOM_unlock(TskRev_t);
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(DMU_t);
															}
															
															//COC PEER REVIEWER...
															printf("\n MT:SETTING COC Peer Reviewer.....: ");fflush(stdout);
															if(SA_find_group(groupName, &PeerGrp_tag)!=ITK_ok)PrintErrorStack();
															if((DsgGrup ==29) ||(DsgGrup ==30)||(DsgGrup ==42) ||(DsgGrup ==43))
															{
																printf("Brake_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Brake_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if ((DsgGrup >=60) && (DsgGrup <=66))
															{
																printf("BIW_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(BIW_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if ((DsgGrup >=70) && (DsgGrup <=80))
															{
																printf("Door_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Door_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==88)
															{
																printf("ExtTrims_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(ExtTrims_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==81)
															{
																printf("Fit_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Fit_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if ((DsgGrup >=67) && (DsgGrup <=69))
															{
																printf("IntTrims_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(IntTrims_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==55)
															{
																printf("Mascots_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Mascots_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if ((DsgGrup >=91) && (DsgGrup <=96))
															{
																printf("Seat_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Seat_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if((DsgGrup ==54)||(DsgGrup ==15)||(DsgGrup ==16)||(DsgGrup ==04)||(DsgGrup ==82))
															{
																printf("EE_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(EE_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==49)
															{
																printf("Exhaust_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Exhaust_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==31)
															{
																printf("Frame_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Frame_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==47)
															{
																printf("Fuel_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Fuel_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==83)
															{
																printf("HVAC_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(HVAC_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==24)
															{
																printf("Mounts_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Mounts_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==97)
															{
																printf("Restrn_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Restrn_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if(DsgGrup ==46)
															{
																printf("Steering_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Steering_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else if((DsgGrup ==32)||(DsgGrup ==35)||(DsgGrup ==33)||(DsgGrup ==40)||(DsgGrup ==41))
															{
																printf("Suspension_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Suspension_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else  if(DsgGrup ==58)
															{
																printf("Tools_Peer_role.. \n"); fflush(stdout);
																if(SA_find_role2(Tools_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
																if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
															}
															else
															{
																printf("\n MT: ELSE Other design group.. \n"); fflush(stdout);
															}
															printf("\n MT: Find  grp member for Peer count..%d \n",No_Peer); fflush(stdout);
															if(No_Peer>0)
															{
																ii=0;
																for(ii=0;ii<No_Peer;ii++)
																{	
																	printf("\n MT: peer reviewer no: %d",ii);fflush(stdout);
																	if(EPM_get_participanttype ("T5_PeerReviewer",&Peer_Patri_Type)!=ITK_ok)PrintErrorStack();
																	if(EPM_create_participant(Peer_t[ii],Peer_Patri_Type,&Peer_Party)!=ITK_ok)PrintErrorStack();
																	AOM_lock(TskRev_t);			
																	if(PARTICIPANT_add_participant(TskRev_t,hasbypass,Peer_Party)!=ITK_ok)PrintErrorStack();	
																	AOM_save_without_extensions(TskRev_t);
																	AOM_unlock(TskRev_t);
																}
																AOM_refresh ( TskRev_t,TRUE);
																MEM_free(Peer_t);
															}
														}
														else
														{
															printf("\n MT: Other DML Type...... \n"); fflush(stdout);
														}
													}
												}
											}
										}
									}
									else if(tc_strcmp(Proj_BU,"CVBU")==0)
									{
										printf("\n MT: Other Program will set for CVBU...... \n"); fflush(stdout);
									}
									else
									{
										printf("\n MT: PRD Dml..... \n"); fflush(stdout);
									}
								}
							}
							else
							{
								printf("\n %s:Exe logic to set reviewer start...",DMLNo);fflush(stdout);
								if(strstr(info3,"Uaprod")==NULL)
								{
									printf("\n UAPROD:DML no : %s ", DMLNo);fflush(stdout);
									sprintf(command,"/user/uaprod/shells/DMLWF/dmlpvrev.sh %s ",DMLNo);
									TC_write_syslog("Command = %s\n",command);
									system(command);
									printf("\n POCHCK:Reviewers set successfully.. \n");fflush(stdout);
								}
								else if(strstr(info3,"Cmitest")==NULL)
								{
									printf("\n CMITEST:DML no : %s ", DMLNo);fflush(stdout);
									sprintf(command,"/user/testcmi/devgroups/DMLWF/dmlpvrev.sh %s ",DMLNo);
									TC_write_syslog("Command = %s\n",command);
									system(command);
									printf("\n POCHCK:Reviewers set successfully.. \n");fflush(stdout);
								}
								else if(strstr(info3,"Uadev")==NULL)
								{
									printf("\n UADEV:DML no : %s ", DMLNo);fflush(stdout);
									sprintf(command,"/home/uadev/devgroups/DMLWF/dmlpvrev.sh %s ",DMLNo);
									TC_write_syslog("Command = %s\n",command);
									system(command);
									printf("\n POCHCK:Reviewers set successfully.. \n");fflush(stdout);
								}
								else
								{
									printf("\n POCHCK:other client \n");fflush(stdout);
								}
							}
						}
						else
						{
							printf("\n NO PROJECT AVAILABLE..\n");fflush(stdout);
						}
					}
					else
					{
						PRDFlag=0;
						printf("\n MT: No project found: %d",PRDFlag); fflush(stdout);
					}
				}
			}
		}
	}
	return error_code;
}

/****************************************************************************
*   Function name			: Assign_Dynamic_party_Func_CV
*   Description				: To set dynamic participant for dml and task in workflow.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		22/01/2018			Mohan Tayade	1.30: Set dynamic participants for dml and task
*
****************************************************************************/
int Assign_Dynamic_party_Func_CV(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;
	char	*DMLNo			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=NULL;
	char	*groupName		= NULL;
	char	*groupNameCV		= NULL;
	char	*DsgGrp			= NULL;
	char	*Task_name		= NULL;
	
	//BOM Analyst
	int     DsgGrup = 0;
	int     i = 0;
	int     No_BomAna = 0;
	tag_t   BomAna_Rev			= NULLTAG;
	tag_t   BAGrp_tag			= NULLTAG;
	tag_t   BomAnalyst_tag		= NULLTAG;
	tag_t	BomAna_Patri_Type	= NULLTAG;
	tag_t*  BomAna				= NULLTAG;
	tag_t	BomAna_Party		= NULLTAG;
	const char*   BomAnalyst_role = "BomAnalyst";
	//VI Reviewer
	int     iii = 0;
	int     No_VIAna = 0;
	tag_t   VIAna_Rev			= NULLTAG;
	tag_t   VIGrp_tag			= NULLTAG;
	tag_t   VIAnalyst_tag		= NULLTAG;
	tag_t	VIAna_Patri_Type	= NULLTAG;
	tag_t*  VIAna				= NULLTAG;
	tag_t	VIAna_Party		= NULLTAG;
	const char*   VIAnalyst_role = "VI_Reviewer";

	//CE Reviewer
	int     ik = 0;
	int     No_CEAna = 0;
	tag_t   CEAna_Rev			= NULLTAG;
	tag_t   CEGrp_tag			= NULLTAG;
	tag_t   CEAnalyst_tag		= NULLTAG;
	tag_t	CEAna_Patri_Type	= NULLTAG;
	tag_t*  CEAna				= NULLTAG;
	tag_t	CEAna_Party		= NULLTAG;
	const char*   CEAnalyst_role = "CE_Reviewer";

	//Peer_reviewer
	int     ii = 0;
	int     No_Peer = 0;
	tag_t   Peer_Rev			= NULLTAG;
	tag_t   PeerGrp_tag			= NULLTAG;
	tag_t   Peer_tag		= NULLTAG;
	tag_t	Peer_Patri_Type	= NULLTAG;
	tag_t*  Peer_t			= NULLTAG;
	tag_t	Peer_Party			= NULLTAG;
	const char*   Brake_Peer_role = "CoC_Brakes_Controls_Peer_PVBU";
	const char*   BIW_Peer_role = "CoC_CAB_BIW_Peer_PVBU";
	const char*   Door_Peer_role = "CoC_CAB_Door_Peer_PVBU";
	const char*   ExtTrims_Peer_role = "CoC_CAB_Ext_Trims_Peer_PVBU";
	const char*   Fit_Peer_role = "CoC_CAB_Int_Fittings_Peer_PVBU";
	const char*   IntTrims_Peer_role = "CoC_CAB_Int_Trims_Peer_PVBU";
	const char*   Mascots_Peer_role = "CoC_CAB_Mascots_Peer_PVBU";
	const char*   Seat_Peer_role = "CoC_CAB_Seats_Peer_PVBU";
	const char*   EE_Peer_role = "CoC_E&E_Peer_PVBU";
	const char*   Exhaust_Peer_role = "CoC_Exhaust_Peer_PVBU";
	const char*   Frame_Peer_role = "CoC_Frames_Peer_PVBU";
	const char*   Fuel_Peer_role = "CoC_Fuel_System_Peer_PVBU";
	const char*   HVAC_Peer_role = "CoC_HVAC_Peer_PVBU";
	const char*   Mounts_Peer_role = "CoC_Mounts_Peer_PVBU";
	const char*   Restrn_Peer_role = "CoC_Restraints_Peer_PVBU";
	const char*   Steering_Peer_role = "CoC_Steering_Peer_PVBU";
	const char*   Suspension_Peer_role = "CoC_Suspension_Peer_PVBU";
	const char*   Tools_Peer_role = "CoC_Tools_Acessories_Peer_PVBU";

	//DMU_reviewer
	int     im = 0;
	int     No_DMU = 0;
	tag_t   DMUGrp_tag		= NULLTAG;
	tag_t   DMU_Rev			= NULLTAG;
	tag_t   DMU_tag		= NULLTAG;
	tag_t	DMU_Patri_Type	= NULLTAG;
	tag_t*  DMU_t			= NULLTAG;
	tag_t	DMU_Party		= NULLTAG;
	const char*   Brake_DMU_role = "CoC_Brakes_Controls_DMU_PVBU";
	const char*   BIW_DMU_role = "CoC_CAB_BIW_DMU_PVBU";
	const char*   Door_DMU_role = "CoC_CAB_Door_DMU_PVBU";
	const char*   ExtTrims_DMU_role = "CoC_CAB_Ext_Trims_DMU_PVBU";
	const char*   Fit_DMU_role = "CoC_CAB_Int_Fittings_DMU_PVBU";
	const char*   IntTrims_DMU_role = "CoC_CAB_Int_Trims_DMU_PVBU";
	const char*   Mascots_DMU_role = "CoC_CAB_Mascots_DMU_PVBU";
	const char*   Seat_DMU_role = "CoC_CAB_Seats_DMU_PVBU";
	const char*   EE_DMU_role = "CoC_E&E_DMU_PVBU";
	const char*   Exhaust_DMU_role = "CoC_Exhaust_DMU_PVBU";
	const char*   Frame_DMU_role = "CoC_Frames_DMU_PVBU";
	const char*   Fuel_DMU_role = "CoC_Fuel_System_DMU_PVBU";
	const char*   HVAC_DMU_role = "CoC_HVAC_DMU_PVBU";
	const char*   Mounts_DMU_role = "CoC_Mounts_DMU_PVBU";
	const char*   Restrn_DMU_role = "CoC_Restraints_DMU_PVBU";
	const char*   Steering_DMU_role = "CoC_Steering_DMU_PVBU";
	const char*   Suspension_DMU_role = "CoC_Suspension_DMU_PVBU";
	const char*   Tools_DMU_role = "CoC_Tools_Acessories_DMU_PVBU";
	//CVBU PEER REVIEWER...
	const char*   Axle_Peer_role = "Peer_AXLE_W_T_Reviewers_CV";
	const char*   CAB_Peer_role = "Peer_CAB_Reviewers_CV";
	const char*   Chassis_Peer_role = "Peer_Chassis_Design_CV";
	const char*   E_and_E_Peer_role = "Peer_E_and_E_Reviewers_CV";
	const char*   Brakes_Peer_role = "Peer_Brake_Reviewers_CV";
	const char*   PTrain_Peer_role = "Peer_Power_TrainInt_Reviewers_CV";
	const char*   Steering_System_Peer_role = "Peer_Steering_System_Reviewers_CV";
	const char*   Suspenssion_Peer_role = "Peer_Suspension_Reviewers_CV";
	const char*   Gearbox_Peer_role = "Peer_Aux_GearBox_Reviewers_CV";

	//SVR COC Reviewer (Task)
	tag_t	*GmFound1 = NULLTAG;
	tag_t	*GmFound2 = NULLTAG;
	tag_t	*GmFound3 = NULLTAG;
	char*	 sUserId = NULL;
	char*	 GrpMembName = NULL;
	tag_t	GrpTag = NULLTAG;
	int	AccesFound=0;
	int	jkl=0;
	int	Gmcnt1=0;
	int	Gmcnt2=0;
	int	Gmcnt3=0;
	const char*   BIW_SVRCoC_role = "BIW_COC_Reviewer";
	const char*   Trim_SVRCoC_role = "Trim_COC_Reviewer";
	const char*   CH_SVRCoC_role = "Chassis_COC_Reviewer";
	const char*   EE_SVRCoC_role = "EE_COC_Reviewer";
	const char*   PT_SVRCoC_role = "Powertrain_COC_Reviewer";
	//BIW_COC_Reviewer
	int     b = 0;
	int     No_SVRcoc = 0;
	tag_t   SVRcocGrp_tag	= NULLTAG;
	tag_t   SVRcoc_tag		= NULLTAG;
	tag_t	SVRcoc_Patri_Type	= NULLTAG;
	tag_t*  SVRcoc_t			= NULLTAG;
	tag_t	SVRcoc_Party		= NULLTAG;
	//Trim_SVRCoC_role
	int     tr = 0;
	int     No_SVRt = 0;
	tag_t   SVRtGrp_tag	= NULLTAG;
	tag_t   SVRt_tag		= NULLTAG;
	tag_t	SVRt_Patri_Type	= NULLTAG;
	tag_t*  SVRt_t			= NULLTAG;
	tag_t	SVRt_Party		= NULLTAG;
	//CH_SVRCoC_role
	int     c = 0;
	int     No_SVRc = 0;
	tag_t   SVRcGrp_tag	= NULLTAG;
	tag_t   SVRc_tag		= NULLTAG;
	tag_t	SVRc_Patri_Type	= NULLTAG;
	tag_t*  SVRc_t			= NULLTAG;
	tag_t	SVRc_Party		= NULLTAG;
	//EE_SVRCoC_role
	int     e = 0;
	int     No_SVRe = 0;
	tag_t   SVReGrp_tag	= NULLTAG;
	tag_t   SVRe_tag		= NULLTAG;
	tag_t	SVRe_Patri_Type	= NULLTAG;
	tag_t*  SVRe_t			= NULLTAG;
	tag_t	SVRe_Party		= NULLTAG;
	//PT_SVRCoC_role
	int     p = 0;
	int     No_SVRp = 0;
	tag_t   SVRpGrp_tag	= NULLTAG;
	tag_t   SVRp_tag		= NULLTAG;
	tag_t	SVRp_Patri_Type	= NULLTAG;
	tag_t*  SVRp_t			= NULLTAG;
	tag_t	SVRp_Party			= NULLTAG;

	// Participants remove.
	int jk = 0;
	int jkk = 0;
	int kk = 0;
	int jtsk = 0;
	int CRBcount = 0;
	int CRBcunt = 0;
	char	*TskReviewr		= NULL;
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char 	*ProjectID		= NULL;
	char	*DMLReviewr		= NULL;
	char	*Part_prj		= NULL;
	tag_t Tsk_CRB_rel_type	= NULLTAG;
	tag_t dml_CRB_rel_type	= NULLTAG;
	tag_t* TskCRB = NULLTAG;
	tag_t* DmlCRB = NULLTAG;
	tag_t	TskCRBTag		= NULLTAG;
	tag_t	DmlCRBTag		= NULLTAG;
	tag_t	ObjTypProj		= NULLTAG;
	tag_t	ObjTypDmlCRB	= NULLTAG;
	tag_t	TskTypeTag	= NULLTAG;
	tag_t	ObjTypTskCRB	= NULLTAG;
	tag_t	TskRev_tg		= NULLTAG;
	char*   type_Proj=NULL;
	char*   type_name7=NULL;
	char*   type_name8=NULL;
	char*   Tsk_Typ=NULL;
	logical is_Tskletst;
	logical is_Tskltst;
	logical hasbypass =true;

	//Task variables
	int     PltFrmPartFlg	=  0;
	int     prt		=  0;
	int     t		=  0;
	int     PRDFlag	=  0;
	int     Taskcout	=  0;
	int     partcnt		=  0;
	int     Tskcout		=  0;
	char	*Proj_BU		= NULL;
	char	*Part_no		= NULL;
	char	*BomAna_Role		= NULL;
	char	*Tsk_class		= NULL;
	tag_t   *TskRevn_tag    =  NULLTAG;
	tag_t   *TskRev_tag    =  NULLTAG;
	tag_t   *PartsTag    =  NULLTAG;
	tag_t	TskCls_t		= NULLTAG;
	tag_t	TskRev_t		= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	DmlTask_tag		= NULLTAG;
	tag_t	DmlTsk_tag		= NULLTAG;
	tag_t	tUserTag		= NULLTAG;
	tag_t	AssyTag		= NULLTAG;
	logical is_Tsklatst;
	int error_code = ITK_ok;
	//Qry Project
	char	*DML_info1	= NULL;
	char	*DML_info2	= NULL;
	char	*DML_info3	= NULL;
	char	*DML_info4	= NULL;
	char	*DML_info6	= NULL;
	char	*DML_info7	= NULL;
	tag_t	queryTag   = NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	tag_t	Project_tag  = NULLTAG;

	tag_t   *DML_CntrlObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	tag_t   DMLqryTag     = NULLTAG; 
	int     n_entry    = 1;  
	int     DML_n_entry    = 1;  
	int     rsltCount      =  0; 
	int     DML_rsltCount      =  0; 
	int		resultCount = 0;
	int		n_entries = 1;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    *qry_entry[1]  = {"SYSCD"};
	char    *DML_qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **DML_qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	//Assign CE Reviewer On basis of Group Handle..
	char	*DMLReason		=  NULL;
	char	*DMLDrStat		=  NULL;
	char	*DMLDesignGrp		=  NULL;
	char	*DMLVertical		=  NULL;
	char	*DML_CE_Group		=  NULL;
	char	*sCVProdPath	=  NULL;
	char	*DML_MGR_Group		=  NULL;
	char	*MgrAnalyst_role	= NULL;
	tag_t	dml_vertical_qryTag		= NULLTAG;
	tag_t	*dml_vertical_CntrlObjectTag		= NULLTAG;

	char    *dml_vertical_qry_entry[1]  = {"SYSCD"};
	char    **dml_vertical_qry_values =  (char **) MEM_alloc(10 * sizeof(char *));
	int dml_vertical_rsltCount =0;
	int dml_vertical_n_entry =1;
	int num =0;
	tag_t   MgrGrp_tag     = NULLTAG;
	tag_t   MgrAnalyst_tag     = NULLTAG;
	tag_t   *MGRAna     = NULLTAG;
	char command[512];
	tag_t	MGRAna_Patri_Type	= NULLTAG;
	tag_t	MGRAna_Party		= NULLTAG;
	int No_MGRAna =0;
	char	*DML_info5	= NULL;
	char	*DML_BU	= NULL;
	char	*ErcGroupName	= NULL;
	tag_t	Erc_group_tag	= NULLTAG;
	char *sDMLrlstype = NULL;

	printf("\n ASSIGN: Dynamic particiant assignment start.......");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n ASSIGN:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
	printf("\n ASSIGN:DML/Task Number: [%s].", DMLNo);fflush(stdout);
	//t5_rlstype

	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\n ASSIGN: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

	groupName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"DML_Participants_Group");
	groupNameCV = (char	*)MEM_alloc(100);
	tc_strcpy(groupNameCV,"DML_Participants_Group_CV");

	printf("\n ASSIGN: groupName  --> %s\n",groupName);   fflush(stdout);
	//Control Table for Assign dynamic party
	printf("\n ASSIGN:.Control Table for Assign dynamic party....\n"); fflush(stdout);
	if(QRY_find2("ControlObjects", &DMLqryTag));
	if (DMLqryTag)
	{
		printf("\n ASSIGN:Found Query ControlObjects \n");fflush(stdout);
	}
	else
	{
		printf("\n ASSIGN:Not Found Query ControlObjects \n");fflush(stdout);
	}

	DML_qry_values2[0] = "DMLASSIG";
	if(QRY_execute(DMLqryTag, DML_n_entry, DML_qry_entry, DML_qry_values2, &DML_rsltCount, &DML_CntrlObjectTag));
	printf(" \n ASSIGN:DML_rsltCount :%d:", DML_rsltCount); fflush(stdout);
	if(DML_rsltCount > 0)
	{
		//PV/CV ONOFF
		if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo1",&DML_info1)!=ITK_ok)   PrintErrorStack();
		printf("\n ASSIGN:DML_info1 is.:[%s]\n", DML_info1);fflush(stdout);
		//PV DML Types
		if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo2",&DML_info2)!=ITK_ok)   PrintErrorStack();
		printf("\n ASSIGN:DML_info2 is.:[%s]\n", DML_info2);fflush(stdout);
		//PV DML BU
		if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo3",&DML_info3)!=ITK_ok)   PrintErrorStack();
		printf("\n ASSIGN:DML_info3 is.:[%s]\n", DML_info3);fflush(stdout);
		//CV DML Type
		if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo4",&DML_info4)!=ITK_ok)   PrintErrorStack();
		printf("\n ASSIGN:DML_info4 is.:[%s]\n", DML_info4);fflush(stdout);
		//CV DML BU
		if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo5",&DML_info5)!=ITK_ok)   PrintErrorStack();
		printf("\n ASSIGN:DML_info5 is.:[%s]\n", DML_info5);fflush(stdout);
		//CV: Prod path
		if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo6",&DML_info6)!=ITK_ok)   PrintErrorStack();
		printf("\n ASSIGN:DML_info6 is.:[%s]\n", DML_info6);fflush(stdout);
		//CV :not used yet
		if (AOM_ask_value_string(DML_CntrlObjectTag[0],"t5_Userinfo7",&DML_info7)!=ITK_ok)   PrintErrorStack();
		printf("\n ASSIGN:DML_info7 is.:[%s]\n", DML_info7);fflush(stdout);
	}

	if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
	{
		DMLType=(char *)MEM_alloc(20);
		DML_BU=(char *)MEM_alloc(30);
		ProjectID=(char *)MEM_alloc(20);
		if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
		if(AOM_ask_value_string(attachment[0],"t5_ERCBusiUt",&DML_BU)!=ITK_ok)PrintErrorStack();
		if(AOM_ask_value_string(attachment[0],"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
		printf("\n ASSIGN::DML Number: [%s] DMLType: [%s] DML_BU:[%s] ProjectID :[%s]", DMLNo,DMLType,DML_BU,ProjectID);fflush(stdout);
		if(tc_strstr(DML_info1,"DMLASGAON") == NULL)
		{
			printf("\n ASSIGN:%s:Exe logic to set reviewer start...",DMLNo);fflush(stdout);
			//need to update CV prod path.
			printf("\n ASSIGN:UAPROD:DML no : %s and Path: ", DMLNo,DML_info6);fflush(stdout);
			if(tc_strstr(DML_info1,"ProgPath1") == NULL)
			{
				printf("\n ASSIGN:A:Reviewers set start.. \n");fflush(stdout);
				tc_strcpy(command,"");
				tc_strcpy(command,DML_info6);
				tc_strcat(command," ");
				tc_strcat(command,DMLNo);
				printf("\n ASSIGN::command: %s",command);fflush(stdout);
				//sprintf(command,"/user/uaprod/shells/DMLWF/dmlcvrev.sh %s ",DMLNo);
				TC_write_syslog("Command = %s\n",command);
				system(command);
				printf("\n ASSIGN:A:Reviewers set successfully.. \n");fflush(stdout);
			}
			else if(tc_strstr(DML_info1,"ProgPath2") == NULL)
			{
				printf("\n ASSIGN:B:Reviewers set start.. \n");fflush(stdout);
				sCVProdPath = (char	*)MEM_alloc(500);
				tc_strcpy(sCVProdPath,"");
				tc_strcpy(sCVProdPath,DML_info6);
				tc_strcat(sCVProdPath," ");
				tc_strcat(sCVProdPath,DMLNo);
				printf("\n ASSIGN:B:command: %s",sCVProdPath);fflush(stdout);
				//sprintf(command,"/user/uaprod/shells/DMLWF/dmlcvrev.sh %s ",DMLNo);
				TC_write_syslog("sCVProdPath = %s\n",sCVProdPath);
				system(sCVProdPath);
				printf("\n ASSIGN:B:Reviewers set successfully.. \n");fflush(stdout);
			}
			else if(tc_strstr(DML_info1,"ProgPath3") == NULL)
			{
				printf("\n ASSIGN:B:Reviewers set start.. \n");fflush(stdout);
				sCVProdPath = (char	*)MEM_alloc(500);
				tc_strcpy(sCVProdPath,"");
				tc_strcpy(sCVProdPath,DML_info6);
				tc_strcat(sCVProdPath," ");
				tc_strcat(sCVProdPath,DMLNo);
				tc_strcat(sCVProdPath," ");
				printf("\n ASSIGN:B:command: %s",sCVProdPath);fflush(stdout);
				//sprintf(command,"/user/uaprod/shells/DMLWF/dmlcvrev.sh %s ",DMLNo);
				TC_write_syslog("sCVProdPath = %s\n",sCVProdPath);
				system(sCVProdPath);
				printf("\n ASSIGN:B:Reviewers set successfully.. \n");fflush(stdout);
			}
		}
		else
		{
			sDMLrlstype=(char *)MEM_alloc(20);
			tc_strcpy(sDMLrlstype,"");
			tc_strcpy(sDMLrlstype,",");
			tc_strcat(sDMLrlstype,DMLType);
			tc_strcat(sDMLrlstype,",");
			printf("\n ASSIGN::sDMLrlstype: %s",sDMLrlstype);fflush(stdout);
			if(tc_strstr(DML_info1,"DMLASGA01") == NULL)
			{
				if((tc_strcmp(DMLType,"")==0) ||(tc_strcmp(ProjectID,"")==0)||(tc_strcmp(DML_BU,"")==0))
				{
					printf("\n ASSIGN:%s:ERROR:DML type/DMLBU/DML Project is NULL..................",DMLNo);fflush(stdout);
				}
			}
			if(tc_strstr(DML_info1,"DMLASGA02") == NULL)
			{
				printf("\n ASSIGN:%s:Check for DML BU:[%s].",DMLNo,DML_BU);fflush(stdout);
				if(ProjectID)
				{
					if(QRY_find2("Qury_Project", &queryTag));
					printf("\n ASSIGN::After Prd_Project: QRY_find2");fflush(stdout);
					if (queryTag)
					{
						printf("\n ASSIGN::Found Query");fflush(stdout);
					}
					else
					{
						printf("\n ASSIGN::Not Found Query");fflush(stdout);
					}
					qry_values[0] = ProjectID;
					if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
					printf("\n ASSIGN:: resultCount : %d\n", resultCount); fflush(stdout);
					if(resultCount > 0)
					{
						printf("\n ASSIGN::t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
						Project_t = t5_Project[0];
						if (Project_t!=NULLTAG)
						{
							ProjectClass=(char *)MEM_alloc(20);
							ProjDesc=(char *)MEM_alloc(200);
							Proj_PltFrm=(char *)MEM_alloc(20);
							Proj_BU=(char *)MEM_alloc(20);
							if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
							if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
							printf("\n ASSIGN:: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
							if(tc_strstr(DML_info1,"DMLASGA03") == NULL)
							{
								if((tc_strcmp(Proj_PltFrm,"")==0) ||(tc_strcmp(Proj_BU,"")==0)||(tc_strcmp(ProjectClass,"")==0))
								{
									printf("\n %s:ERROR:Project platform/proj BU/Proj Class is NULL:%s..................",DMLNo,ProjectID);fflush(stdout);
								}
							}
						}
					}
				}
				//For PVBU DML BU
				if(tc_strstr(DML_info3,DML_BU) != NULL)
				{
					printf("\n ASSIGN: %s:It is for PV DML Type.",DMLNo);fflush(stdout);
					if(tc_strstr(DML_info2,sDMLrlstype) != NULL)
					{
						printf("\n ASSIGN::%s:PV:REMOVE PARTICIPALNTS START.. \n",DMLNo);fflush(stdout);
						if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
						if (dml_CRB_rel_type!=NULLTAG)
						{
							printf("\n ASSIGN::inside participant removal. \n");fflush(stdout);
							if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
							printf("\n ASSIGN:: DmlCRB count: %d",CRBcount);fflush(stdout);	
							for (jk=0;jk<CRBcount ;jk++ )
							{	
								//printf("\n ASSIGN::jk: %d.\n",jk);fflush(stdout);
								DmlCRBTag = DmlCRB[jk];
								if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
								if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
								printf("\n ASSIGN::DML: Participants Name: %s", type_name7);fflush(stdout);
								if(tc_strcmp(DMLType,"SVR")!=0)
								{
									if ((tc_strcmp(type_name7,"T5_BOMAnalyst")==0)||(tc_strcmp(type_name7,"T5_PPReviewer")==0))
									{
										if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
										printf("\n ASSIGN:: Removing BOM/PP reviewer: [%s] ",DMLReviewr);fflush(stdout);
										AOM_lock(objTag);
										if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
										AOM_save_without_extensions(objTag);
										AOM_unlock(objTag);
									}
								}
								else
								{
									if (tc_strcmp(type_name7,"T5_VIReviewer")==0)
									{
										if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
										printf("\n ASSIGN::Removing VI Reviewer: [%s] ",DMLReviewr);fflush(stdout);
										AOM_lock(objTag);
										if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
										AOM_save_without_extensions(objTag);
										AOM_unlock(objTag);
									}
								}
							}
						}
						printf("\n ASSIGN::%s:PV DML:ADD PARTICIPALNTS START.. \n",DMLNo);fflush(stdout);
						if(tc_strcmp(DMLType,"SVR")==0)
						{
							printf("\n ASSIGN::PCBU: VI Reviewer for SVR only:Setting VI Analyst...");fflush(stdout);
							if(SA_find_group(groupName, &VIGrp_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(VIAnalyst_role,&VIAnalyst_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_groupmember_by_role(VIAnalyst_tag,VIGrp_tag,&No_VIAna,&VIAna)!=ITK_ok)PrintErrorStack();
							printf("\n ASSIGN::PCBU:No_VIAna :[%d]",No_VIAna);  fflush(stdout);
							if(No_VIAna>0)
							{
								for(iii=0;iii<No_VIAna;iii++)
								{	
									printf("\n ASSIGN::PCBU: VI Reviewer no: [%d]",iii);fflush(stdout);
									if(EPM_get_participanttype ("T5_VIReviewer",&VIAna_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(VIAna[iii],VIAna_Patri_Type,&VIAna_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(objTag);			
									if(PARTICIPANT_add_participant(objTag,hasbypass,VIAna_Party)!=ITK_ok)PrintErrorStack();
									AOM_save_without_extensions(objTag);
									AOM_unlock(objTag);
								}
							}
							AOM_refresh (objTag,TRUE);
							MEM_free(VIAna);
						}
						else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
						{
							printf("\n ASSIGN::PCBU:For MR/Veh DML..");fflush(stdout);
							if(tc_strcmp(Proj_PltFrm,"")!=0)
							{
								if(tc_strcmp(Proj_PltFrm,"TBD")==0)
								{
									printf("\n ASSIGN::PCBU:BOM ANalyst Set to NULL since platform is TBD...");fflush(stdout);
								}
								else
								{
									BomAna_Role = (char	*)MEM_alloc(100);
									tc_strcpy(BomAna_Role,"");
									tc_strcpy(BomAna_Role,Proj_PltFrm);
									tc_strcat(BomAna_Role,"_");
									tc_strcat(BomAna_Role,"BOM_Analyst");
									printf("\n ASSIGN::PCBU: after BomAna_Role: %s",BomAna_Role);   fflush(stdout);
									if(SA_find_group(groupName, &BAGrp_tag)!=ITK_ok)PrintErrorStack();
									if(SA_find_role2(BomAna_Role,&BomAnalyst_tag)!=ITK_ok)PrintErrorStack();
									if(SA_find_groupmember_by_role(BomAnalyst_tag,BAGrp_tag,&No_BomAna,&BomAna)!=ITK_ok)PrintErrorStack();
									printf("\n ASSIGN::PCBU:No_BomAna :[%d]",No_BomAna);  fflush(stdout);
									if(No_BomAna>0)
									{
										for(i=0;i<No_BomAna;i++)
										{	
											printf("\n ASSIGN::PCBU:BOM Analyst no: [%d]",i);fflush(stdout);
											if(EPM_get_participanttype ("T5_BOMAnalyst",&BomAna_Patri_Type)!=ITK_ok)PrintErrorStack();
											if(EPM_create_participant(BomAna[i],BomAna_Patri_Type,&BomAna_Party)!=ITK_ok)PrintErrorStack();
											AOM_lock(objTag);			
											if(PARTICIPANT_add_participant(objTag,hasbypass,BomAna_Party)!=ITK_ok)PrintErrorStack();	
											AOM_save_without_extensions(objTag);
											AOM_unlock(objTag);
										}
									}
									AOM_refresh (objTag,TRUE);
									MEM_free(BomAna);
								}
							}
							else
							{
								printf("\n ASSIGN::Proj Platform is NULL...");fflush(stdout);
							}
						}
						else
						{
							printf("\n ASSIGN:: NO Assignment for XO/TOO/PDR dmls...... \n"); fflush(stdout);
						}
						printf("\n ASSIGN::PVBU:TASK:REMOVING REVIEWERS FOR TASK START......\n");fflush(stdout);
						if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTask_tag)!=ITK_ok)PrintErrorStack();
						if (DmlTask_tag!=NULLTAG)
						{		
							if(GRM_list_secondary_objects_only(objTag,DmlTask_tag,&Tskcout,&TskRev_tag)!=ITK_ok)PrintErrorStack();
							printf("\n ASSIGN::TASK:TskRev_tag Tskcout : %d",Tskcout);fflush(stdout);
							for (jkk=0;jkk<Tskcout ;jkk++ )
							{
								if(ITEM_rev_sequence_is_latest(TskRev_tag[jkk],&is_Tskletst)!=ITK_ok)PrintErrorStack();
								//printf("\n ASSIGN::.is_Tskletst. %d",is_Tskletst);fflush(stdout);
								if(is_Tskletst != true)
								{
									printf("\n ASSIGN::TASK:is_Tskletst is not true .....\n");fflush(stdout);
								}
								else
								{	
									TskRev_tg = TskRev_tag[jkk];
									if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
									if (Tsk_CRB_rel_type!=NULLTAG)
									{
										if(GRM_list_secondary_objects_only(TskRev_tg,Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
										printf("\n ASSIGN::TASK: count: %d",CRBcunt);fflush(stdout);	
										for (jtsk=0;jtsk<CRBcunt ;jtsk++ )
										{	
											TskCRBTag = TskCRB[jtsk];
											if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
											if(TCTYPE_ask_name2(ObjTypTskCRB,&type_name8));
											printf("\n ASSIGN::TASK: Participant Name: %s\n", type_name8);fflush(stdout);
											if(tc_strcmp(DMLType,"SVR")==0)
											{
												if ((tc_strcmp(type_name8,"T5_BIWReviewer")==0)||(tc_strcmp(type_name8,"T5_PTReviewer")==0)||(tc_strcmp(type_name8,"T5_EEReviewer")==0)|| (tc_strcmp(type_name8,"T5_CHReviewer")==0)||(tc_strcmp(type_name8,"T5_TRIMReviewer")==0))
												{
													printf("\n ASSIGN::SVR:TASK:: Removing "); fflush(stdout);
													if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
													printf(" reviewer: [%s]\n",TskReviewr);fflush(stdout);
													AOM_lock(TskRev_tg);
													if(PARTICIPANT_remove_participant(TskRev_tg,TskCRBTag) !=ITK_ok)PrintErrorStack();
													AOM_save_without_extensions(TskRev_tg);
													AOM_unlock(TskRev_tg);
												}
											}
											else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
											{
												if ((tc_strcmp(type_name8,"T5_DMUReviewer")==0)|| (tc_strcmp(type_name8,"T5_PeerReviewer")==0))
												{
													printf("\n ASSIGN::MR:TASK: Removing "); fflush(stdout);
													if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
													printf(" reviewer: [%s]\n",TskReviewr);fflush(stdout);
													AOM_lock(TskRev_tg);
													if(PARTICIPANT_remove_participant(TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
													AOM_save_without_extensions(TskRev_tg);
													AOM_unlock(TskRev_tg);
												}
											}
											else
											{
												printf("\n ASSIGN:: Other dml type... \n"); fflush(stdout);
											}
										}
									}
								}
							}

							printf("\n ASSIGN::PVBU:ADDING REVIEWERS FOR TASK START......\n");fflush(stdout);
							for (t=0;t<Tskcout ;t++ )
							{ 
								No_DMU=0;
								No_Peer=0;
								if(ITEM_rev_sequence_is_latest(TskRev_tag[t],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
								//printf("\n ASSIGN::is_Tsklatst %d",is_Tsklatst);fflush(stdout);

								if(is_Tsklatst != true)
								{
									printf("\n ASSIGN::is_Tsklatst is not true .....\n");fflush(stdout);
								}
								else
								{	
									TskRev_t = TskRev_tag[t];
									if(POM_class_of_instance(TskRev_t,&TskCls_t)!=ITK_ok)PrintErrorStack();
									if(POM_name_of_class(TskCls_t,&Tsk_class)!=ITK_ok)PrintErrorStack();
									printf("\n ASSIGN:: Task class..:%s",Tsk_class); fflush(stdout);
									if(tc_strcmp(Tsk_class,"T5_ChangeTaskRevision")==0)
									{
										//Setting DMU Reviewers.
										if(AOM_UIF_ask_value(TskRev_t,"item_id",&Task_name)!=ITK_ok)PrintErrorStack();
										printf("\n ASSIGN:: Task Name :[%s]",Task_name);fflush(stdout);
										DsgGrp=subString(Task_name,11,2);
										DsgGrup=(int) atoi(DsgGrp);
										printf(" and design group: [%s:%d]\n",DsgGrp,DsgGrup);fflush(stdout);
										if(tc_strcmp(DMLType,"SVR")==0)
										{
											//SVR COC REVIEWER...
											No_SVRcoc=0;
											No_SVRc=0;
											No_SVRe=0;
											No_SVRp=0;
											No_SVRt=0;
											//get Project access check:
											if(tc_strstr(DML_info1,"DMLASGA04")==NULL)
											{
												Gmcnt1=0;
												Gmcnt2=0;
												Gmcnt3=0;
												GmFound1 =NULLTAG;
												GmFound2 =NULLTAG;
												GmFound3 =NULLTAG;
												printf("\n ASSIGN::Getting Project Team...\n");fflush(stdout);
												if (PROJ_ask_team(Project_t,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();
												printf("\n ASSIGN::Gmcnt1 %d \n",Gmcnt1);fflush(stdout);
											}
											//BIW Reviewer.
											if(SA_find_group(groupName, &SVRcocGrp_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_role2(BIW_SVRCoC_role,&SVRcoc_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_groupmember_by_role(SVRcoc_tag,SVRcocGrp_tag,&No_SVRcoc,&SVRcoc_t)!=ITK_ok)PrintErrorStack();
											if(No_SVRcoc>0)
											{
												for(b=0;b<No_SVRcoc;b++)
												{	
													printf("\n ASSIGN:: BIW_SVRCoC_role: %d",b);fflush(stdout);
													AccesFound=0;
													if(tc_strstr(DML_info1,"DMLASGA05")==NULL)
													{
														sUserId=NULL;
														if(SA_ask_groupmember_user(SVRcoc_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
														if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
														printf("\n ASSIGN:: sUserId: %s",sUserId);fflush(stdout);
														jkl=0;
														for(jkl=0;jkl<Gmcnt1;jkl++)
														{
															AccesFound=0;
															GrpMembName=NULL;
															GrpTag = GmFound1[jkl];
															if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
															printf("\n ASSIGN:Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
															if(GrpMembName)
															{
																if((tc_strstr(GrpMembName,"BIW_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																{
																	printf("\n ASSIGN:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																	printf("\n ASSIGN::BIW_COC_Reviewer access avail...\n");fflush(stdout);
																	AccesFound=1;
																	break;
																}
															}
														}
													}
													else
													{
														printf("\n ASSIGN:: BIW_SVRCoC_role.");fflush(stdout);
														if(EPM_get_participanttype ("T5_BIWReviewer",&SVRcoc_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(SVRcoc_t[b],SVRcoc_Patri_Type,&SVRcoc_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRcoc_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);
													}
													if(AccesFound >0)
													{
														printf("\n ASSIGN:: BIW_SVRCoC_role assigned:%s",sUserId);fflush(stdout);
														if(EPM_get_participanttype ("T5_BIWReviewer",&SVRcoc_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(SVRcoc_t[b],SVRcoc_Patri_Type,&SVRcoc_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRcoc_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);
													}
												}
												AOM_refresh ( TskRev_t,TRUE);
												MEM_free(SVRcoc_t);
											}
											//TRIM Reviewer
											if(SA_find_group(groupName, &SVRtGrp_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_role2(Trim_SVRCoC_role,&SVRt_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_groupmember_by_role(SVRt_tag,SVRtGrp_tag,&No_SVRt,&SVRt_t)!=ITK_ok)PrintErrorStack();
											if(No_SVRt>0)
											{
												for(tr=0;tr<No_SVRt;tr++)
												{	
													printf("\n ASSIGN:: TRIM reviewer no: %d",tr);fflush(stdout);
													AccesFound=0;
													if(tc_strstr(DML_info1,"DMLASGA06")==NULL)
													{
														sUserId=NULL;
														if(SA_ask_groupmember_user(SVRt_t[tr],&tUserTag)!=ITK_ok)   PrintErrorStack();
														if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
														printf("\n ASSIGN:: sUserId: %s",sUserId);fflush(stdout);
														jkl=0;
														for(jkl=0;jkl<Gmcnt1;jkl++)
														{
															AccesFound=0;
															GrpMembName=NULL;
															GrpTag = GmFound1[jkl];
															if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
															printf("\n ASSIGN:Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
															if(GrpMembName)
															{
																if((tc_strstr(GrpMembName,"Trim_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																{
																	printf("\n ASSIGN:Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																	printf("\n ASSIGN::Trim_COC_Reviewer access avail...\n");fflush(stdout);
																	AccesFound=1;
																	break;
																}
															}
														}
													}
													else
													{
														printf("\n ASSIGN:: TRIM reviewer.");fflush(stdout);
														if(EPM_get_participanttype ("T5_TRIMReviewer",&SVRt_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(SVRt_t[tr],SVRt_Patri_Type,&SVRt_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRt_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);
													}
													if (AccesFound >0)
													{
														printf("\n ASSIGN:: TRIM reviewer assigned:%s",sUserId);fflush(stdout);
														if(EPM_get_participanttype ("T5_TRIMReviewer",&SVRt_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(SVRt_t[tr],SVRt_Patri_Type,&SVRt_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRt_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);

													}
												}
												AOM_refresh (TskRev_t,TRUE);
												MEM_free(SVRt_t);
											}
											//CHASSIS SVR ROLE
											if(SA_find_group(groupName, &SVRcGrp_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_role2(CH_SVRCoC_role,&SVRc_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_groupmember_by_role(SVRc_tag,SVRcGrp_tag,&No_SVRc,&SVRc_t)!=ITK_ok)PrintErrorStack();
											if(No_SVRc>0)
											{
												for(c=0;c<No_SVRc;c++)
												{	
													printf("\n ASSIGN:: CH reviewer no: %d",c);fflush(stdout);
													AccesFound=0;
													if(tc_strstr(DML_info1,"DMLASGA07")==NULL)
													{
														sUserId=NULL;
														if(SA_ask_groupmember_user(SVRc_t[c],&tUserTag)!=ITK_ok)   PrintErrorStack();
														if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
														printf("\n ASSIGN:: sUserId: %s",sUserId);fflush(stdout);
														jkl=0;
														for(jkl=0;jkl<Gmcnt1;jkl++)
														{
															AccesFound=0;
															GrpMembName=NULL;
															GrpTag = GmFound1[jkl];
															if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
															printf("\n ASSIGN:Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
															if(GrpMembName)
															{
																if((tc_strstr(GrpMembName,"Chassis_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																{
																	printf("\n ASSIGN:Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																	printf("\n ASSIGN::Chassis_COC_Reviewer access avail...\n");fflush(stdout);
																	AccesFound=1;
																	break;
																}
															}
														}
													}
													else
													{
														printf("\n ASSIGN:: CHS reviewer assigned.");fflush(stdout);
														if(EPM_get_participanttype ("T5_CHReviewer",&SVRc_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(SVRc_t[c],SVRc_Patri_Type,&SVRc_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRc_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);
													}
													if (AccesFound >0)
													{
														printf("\n ASSIGN:: CHS reviewer assigned:%s",sUserId);fflush(stdout);
														if(EPM_get_participanttype ("T5_CHReviewer",&SVRc_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(SVRc_t[c],SVRc_Patri_Type,&SVRc_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRc_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);
													}
												}
												AOM_refresh (TskRev_t,TRUE);
												MEM_free(SVRc_t);
											}
											//EE COC reviewer
											if(SA_find_group(groupName, &SVReGrp_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_role2(EE_SVRCoC_role,&SVRe_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_groupmember_by_role(SVRe_tag,SVReGrp_tag,&No_SVRe,&SVRe_t)!=ITK_ok)PrintErrorStack();
											if(No_SVRe>0)
											{
												for(e=0;e<No_SVRe;e++)
												{	
													printf("\n ASSIGN:: peer reviewer no: %d",e);fflush(stdout);
													AccesFound=0;
													if(tc_strstr(DML_info1,"DMLASGA08")==NULL)
													{
														sUserId=NULL;
														if(SA_ask_groupmember_user(SVRe_t[e],&tUserTag)!=ITK_ok)   PrintErrorStack();
														if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
														printf("\n ASSIGN:: sUserId: %s",sUserId);fflush(stdout);
														jkl=0;
														for(jkl=0;jkl<Gmcnt1;jkl++)
														{
															AccesFound=0;
															GrpMembName=NULL;
															GrpTag = GmFound1[jkl];
															if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
															printf("\n ASSIGN:Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
															if(GrpMembName)
															{
																if((tc_strstr(GrpMembName,"EE_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																{
																	printf("\n ASSIGN:Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																	printf("\n ASSIGN::EE_COC_Reviewer access avail...\n");fflush(stdout);
																	AccesFound=1;
																	break;
																}
															}
														}
													}
													else
													{
														if(EPM_get_participanttype ("T5_EEReviewer",&SVRe_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(SVRe_t[e],SVRe_Patri_Type,&SVRe_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRe_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);
													}
													if (AccesFound >0)
													{
														printf("\n ASSIGN:EE reviewer assigned: %s",sUserId);fflush(stdout);
														if(EPM_get_participanttype ("T5_EEReviewer",&SVRe_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(SVRe_t[e],SVRe_Patri_Type,&SVRe_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRe_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);
													}
												}
												AOM_refresh (TskRev_t,TRUE);
												MEM_free(SVRe_t);
											}
											//Powertrain reviewer
											if(SA_find_group(groupName, &SVRpGrp_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_role2(PT_SVRCoC_role,&SVRp_tag)!=ITK_ok)PrintErrorStack();
											if(SA_find_groupmember_by_role(SVRp_tag,SVRpGrp_tag,&No_SVRp,&SVRp_t)!=ITK_ok)PrintErrorStack();
											if(No_SVRp>0)
											{
												for(p=0;p<No_SVRp;p++)
												{	
													printf("\n ASSIGN:: PT_SVRCoC reviewer no: %d",p);fflush(stdout);
													AccesFound=0;
													if(tc_strstr(DML_info1,"DMLASGA09")==NULL)
													{
														sUserId=NULL;
														if(SA_ask_groupmember_user(SVRp_t[p],&tUserTag)!=ITK_ok)   PrintErrorStack();
														if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
														printf("\n ASSIGN:: sUserId: %s",sUserId);fflush(stdout);
														jkl=0;
														for(jkl=0;jkl<Gmcnt1;jkl++)
														{
															AccesFound=0;
															GrpMembName=NULL;
															GrpTag = GmFound1[jkl];
															if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
															printf("\n ASSIGN:Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
															if(GrpMembName)
															{
																if((tc_strstr(GrpMembName,"Powertrain_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
																{
																	printf("\n ASSIGN:Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																	printf("\n ASSIGN::Powertrain_COC_Reviewer access avail...\n");fflush(stdout);
																	AccesFound=1;
																	break;
																}
															}
														}
													}
													else
													{
														printf("\n ASSIGN:POWRTRN reviewer assigned");fflush(stdout);
														if(EPM_get_participanttype ("T5_PTReviewer",&SVRp_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(SVRp_t[p],SVRp_Patri_Type,&SVRp_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRp_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);
													}
													if (AccesFound >0)
													{
														printf("\n ASSIGN:POWRTRN reviewer assigned: %s",sUserId);fflush(stdout);
														if(EPM_get_participanttype ("T5_PTReviewer",&SVRp_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(SVRp_t[p],SVRp_Patri_Type,&SVRp_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRp_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);
													}
												}
												AOM_refresh (TskRev_t,TRUE);
												MEM_free(SVRp_t);
											}
										}
										else if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
										{
											//COC DMU Reviewer
											printf("\n ASSIGN::SETTING COC DMU Reviewer.....: ");fflush(stdout);
											if(SA_find_group(groupName, &DMUGrp_tag)!=ITK_ok)PrintErrorStack();
											if((DsgGrup ==29) ||(DsgGrup ==30)||(DsgGrup ==42) ||(DsgGrup ==43))
											{
												printf("Brake_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Brake_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if ((DsgGrup >=60) && (DsgGrup <=66))
											{
												printf("BIW_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(BIW_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if ((DsgGrup >=70) && (DsgGrup <=80))
											{
												printf("Door_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Door_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==88)
											{
												printf("ExtTrims_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(ExtTrims_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==81)
											{
												printf("Fit_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Fit_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if ((DsgGrup >=67) && (DsgGrup <=69))
											{
												printf("IntTrims_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(IntTrims_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==55)
											{
												printf("Mascots_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Mascots_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if ((DsgGrup >=91) && (DsgGrup <=96))
											{
												printf("Seat_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Seat_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if((DsgGrup ==54)||(DsgGrup ==15)||(DsgGrup ==16)||(DsgGrup ==04)||(DsgGrup ==82))
											{
												printf("EE_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(EE_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==49)
											{
												printf("Exhaust_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Exhaust_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==31)
											{
												printf("Frame_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Frame_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==47)
											{
												printf("Fuel_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Fuel_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==83)
											{
												printf("HVAC_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(HVAC_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==24)
											{
												printf("Mounts_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Mounts_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==97)
											{
												printf("Restrn_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Restrn_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==46)
											{
												printf("Steering_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Steering_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if((DsgGrup ==32)||(DsgGrup ==35)||(DsgGrup ==33)||(DsgGrup ==40)||(DsgGrup ==41))
											{
												printf("Suspension_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Suspension_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==58)
											{
												printf("Tools_DMU_role.. \n"); fflush(stdout);
												if(SA_find_role2(Tools_DMU_role,&DMU_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(DMU_tag,DMUGrp_tag,&No_DMU,&DMU_t)!=ITK_ok)PrintErrorStack();
											}
											else
											{
												printf("\n ASSIGN:: ELSE Other design group.. \n"); fflush(stdout);
											}
											
											printf("\n ASSIGN:: Find  grp member for DMU count..%d \n",No_DMU); fflush(stdout);
											if(No_DMU>0)
											{
												im=0;
												for(im=0;im<No_DMU;im++)
												{	
													printf("\n ASSIGN:: DMU Reviewer no: %d",im);fflush(stdout);
													if(EPM_get_participanttype ("T5_DMUReviewer",&DMU_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(DMU_t[im],DMU_Patri_Type,&DMU_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,DMU_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
												AOM_refresh ( TskRev_t,TRUE);
												MEM_free(DMU_t);
											}
											
											//COC PEER REVIEWER...
											printf("\n ASSIGN::SETTING COC Peer Reviewer.....: ");fflush(stdout);
											if(SA_find_group(groupName, &PeerGrp_tag)!=ITK_ok)PrintErrorStack();
											if((DsgGrup ==29) ||(DsgGrup ==30)||(DsgGrup ==42) ||(DsgGrup ==43))
											{
												printf("Brake_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Brake_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if ((DsgGrup >=60) && (DsgGrup <=66))
											{
												printf("BIW_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(BIW_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if ((DsgGrup >=70) && (DsgGrup <=80))
											{
												printf("Door_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Door_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==88)
											{
												printf("ExtTrims_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(ExtTrims_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==81)
											{
												printf("Fit_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Fit_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if ((DsgGrup >=67) && (DsgGrup <=69))
											{
												printf("IntTrims_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(IntTrims_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==55)
											{
												printf("Mascots_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Mascots_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if ((DsgGrup >=91) && (DsgGrup <=96))
											{
												printf("Seat_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Seat_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if((DsgGrup ==54)||(DsgGrup ==15)||(DsgGrup ==16)||(DsgGrup ==04)||(DsgGrup ==82))
											{
												printf("EE_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(EE_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==49)
											{
												printf("Exhaust_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Exhaust_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==31)
											{
												printf("Frame_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Frame_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==47)
											{
												printf("Fuel_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Fuel_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==83)
											{
												printf("HVAC_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(HVAC_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==24)
											{
												printf("Mounts_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Mounts_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==97)
											{
												printf("Restrn_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Restrn_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if(DsgGrup ==46)
											{
												printf("Steering_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Steering_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else if((DsgGrup ==32)||(DsgGrup ==35)||(DsgGrup ==33)||(DsgGrup ==40)||(DsgGrup ==41))
											{
												printf("Suspension_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Suspension_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else  if(DsgGrup ==58)
											{
												printf("Tools_Peer_role.. \n"); fflush(stdout);
												if(SA_find_role2(Tools_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
											}
											else
											{
												printf("\n ASSIGN:: ELSE Other design group.. \n"); fflush(stdout);
											}
											printf("\n ASSIGN:: Find  grp member for Peer count..%d \n",No_Peer); fflush(stdout);
											if(No_Peer>0)
											{
												ii=0;
												for(ii=0;ii<No_Peer;ii++)
												{	
													printf("\n ASSIGN:: peer reviewer no: %d",ii);fflush(stdout);
													if(EPM_get_participanttype ("T5_PeerReviewer",&Peer_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(Peer_t[ii],Peer_Patri_Type,&Peer_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,Peer_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
												AOM_refresh ( TskRev_t,TRUE);
												MEM_free(Peer_t);
											}
										}
										else
										{
											printf("\n ASSIGN:: Other DML Type...... \n"); fflush(stdout);
										}
									}
								}
							}
						}
					}
				}
				//For CVBU DML BU
				if(tc_strstr(DML_info5,DML_BU) != NULL)
				{
					printf("\n ASSIGN:CV:%s:It is for CV DML Type.",DMLNo);fflush(stdout);
					if(tc_strstr(DML_info4,sDMLrlstype) != NULL)
					{
						//CE Reviewer not for PCBU.
						printf("\n ASSIGN:CV:: Setting CE Reviewer...");fflush(stdout);
						if(AOM_ask_value_string(attachment[0],"t5_cDRstatus",&DMLDrStat)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(attachment[0],"t5_reason",&DMLReason)!=ITK_ok)PrintErrorStack();
						//if(AOM_ask_value_string(attachment[0],"t5_crdesigngroup",&DMLDesignGrp)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string_at(attachment[0],"t5_crdesigngroup",0,&DMLDesignGrp)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(attachment[0],"t5_ProductLine",&DMLVertical)!=ITK_ok)PrintErrorStack();

						printf("\n ASSIGN:CV::DML DR STATUS: [%s] DMLType: [%s] DMLReason: [%s] DMLGroup: [%s] DMLVertical: [%s]", DMLDrStat,DMLType,DMLReason,DMLDesignGrp,DMLVertical);fflush(stdout);
						if(tc_strstr(DML_info1,"DMLASGB01") == NULL)
						{
							if(tc_strlen(DMLVertical)>0)
							{
								DML_CE_Group = (char	*)MEM_alloc(100);
								if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0)
								{
									tc_strcpy(DML_CE_Group,DMLVertical);
									tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
								}
								else if(tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0 || tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0||tc_strcmp(DMLDrStat,"DR3P")==0 || tc_strcmp(DMLDrStat,"AR3P")==0)
								{
									tc_strcpy(DML_CE_Group,DMLVertical);
									tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
								}
								else if(tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
								{
									tc_strcpy(DML_CE_Group,DMLVertical);
									tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
								}
							}
							else
							{
								tc_strcpy(DML_CE_Group,"CE");
								tc_strcat(DML_CE_Group,"_Reviewer_Grp");
							}
							
							printf("\n ASSIGN:CV:DML_CE_Group  :[%s]",DML_CE_Group);  fflush(stdout);
							if(SA_find_group(groupNameCV, &CEGrp_tag)!=ITK_ok)PrintErrorStack();
							if(SA_find_role2(DML_CE_Group,&CEAnalyst_tag)!=ITK_ok)PrintErrorStack();
							if(CEGrp_tag!=NULLTAG && CEAnalyst_tag!=NULLTAG)
							{
								if(SA_find_groupmember_by_role(CEAnalyst_tag,CEGrp_tag,&No_CEAna,&CEAna)!=ITK_ok)PrintErrorStack();
								printf("\n ASSIGN:CV::No_CEAna  :[%d]",No_CEAna);  fflush(stdout);
							}
							if(No_CEAna>0)
							{
								for(ik=0;ik<No_CEAna;ik++)
								{	
									printf("\n ASSIGN:CV::CE Reviewer no: %d",ik);fflush(stdout);
									if(EPM_get_participanttype ("T5_CEReviewer",&CEAna_Patri_Type)!=ITK_ok)PrintErrorStack();
									if(EPM_create_participant(CEAna[ik],CEAna_Patri_Type,&CEAna_Party)!=ITK_ok)PrintErrorStack();
									AOM_lock(objTag);			
									if(PARTICIPANT_add_participant(objTag,hasbypass,CEAna_Party)!=ITK_ok)PrintErrorStack();	
									AOM_save_without_extensions(objTag);
									AOM_unlock(objTag);
								}
							}
							AOM_refresh ( objTag,TRUE);
							MEM_free(CEAna);
						}
						if(tc_strstr(DML_info1,"DMLASGB02") == NULL)
						{
							printf("\n ASSIGN:CV::TASK:REMOVING PEER REVIEWERS FOR TASK START......\n");fflush(stdout);
							if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTask_tag)!=ITK_ok)PrintErrorStack();
							if (DmlTask_tag!=NULLTAG)
							{		
								if(GRM_list_secondary_objects_only(objTag,DmlTask_tag,&Tskcout,&TskRev_tag)!=ITK_ok)PrintErrorStack();
								printf("\n ASSIGN:CV::TASK:TskRev_tag Tskcout : %d",Tskcout);fflush(stdout);
								for (jkk=0;jkk<Tskcout ;jkk++ )
								{
									if(ITEM_rev_sequence_is_latest(TskRev_tag[jkk],&is_Tskletst)!=ITK_ok)PrintErrorStack();
									//printf("\n MT:.is_Tskletst. %d",is_Tskletst);fflush(stdout);
									if(is_Tskletst != true)
									{
										printf("\n ASSIGN:CV::TASK:is_Tskletst is not true .....\n");fflush(stdout);
									}
									else
									{	
										TskRev_tg = TskRev_tag[jkk];
										if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
										if (Tsk_CRB_rel_type!=NULLTAG)
										{
											if(GRM_list_secondary_objects_only(TskRev_tg,Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
											printf("\n ASSIGN:CV::TASK: count: %d",CRBcunt);fflush(stdout);	
											for (jtsk=0;jtsk<CRBcunt ;jtsk++ )
											{
												TskCRBTag = TskCRB[jtsk];
												if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
												if(TCTYPE_ask_name2(ObjTypTskCRB,&type_name8));
												printf("\n ASSIGN:CV::TASK: Participant Name: %s\n", type_name8);fflush(stdout);
												if (tc_strcmp(type_name8,"T5_PeerReviewer")==0)
												{
													printf("\n ASSIGN:CV::TASK: Removing "); fflush(stdout);
													if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
													printf(" reviewer: [%s]\n",TskReviewr);fflush(stdout);
													if (TskReviewr)
													{
														AOM_lock(TskRev_tg);
														if(PARTICIPANT_remove_participant(TskRev_tg,TskCRBTag)!=ITK_ok)PrintErrorStack();
														printf("\n ASSIGN:CV::TASK: removed :%d",jtsk); fflush(stdout);
														AOM_save_without_extensions(TskRev_tg);
														AOM_unlock(TskRev_tg);
													}
												}
											}
										}
									}
								}

								printf("\n ASSIGN:CV::CVBU:ADDING PEER REVIEWERS FOR TASK START......\n");fflush(stdout);
								for (t=0;t<Tskcout ;t++ )
								{ 
									No_DMU=0;
									No_Peer=0;
									if(ITEM_rev_sequence_is_latest(TskRev_tag[t],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
									//printf("\n MT:is_Tsklatst %d",is_Tsklatst);fflush(stdout);

									if(is_Tsklatst != true)
									{
										printf("\n ASSIGN:CV::is_Tsklatst is not true .....\n");fflush(stdout);
									}
									else
									{	
										TskRev_t = TskRev_tag[t];
										if(POM_class_of_instance(TskRev_t,&TskCls_t)!=ITK_ok)PrintErrorStack();
										if(POM_name_of_class(TskCls_t,&Tsk_class)!=ITK_ok)PrintErrorStack();
										printf("\n ASSIGN:CV:: Task class..:%s",Tsk_class); fflush(stdout);
										if(tc_strcmp(Tsk_class,"T5_ChangeTaskRevision")==0)
										{
											//Setting DMU Reviewers.
											if(AOM_UIF_ask_value(TskRev_t,"item_id",&Task_name)!=ITK_ok)PrintErrorStack();
											printf("\n ASSIGN:CV:: Task Name :[%s]",Task_name);fflush(stdout);
											DsgGrp=subString(Task_name,11,2);
											DsgGrup=(int) atoi(DsgGrp);
											printf(" and design group: [%s]\n",DsgGrp);fflush(stdout);
											if((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0))
											{
												printf("\n ASSIGN:CV::SETTING CVBU Peer Reviewer.....: ");fflush(stdout);
												if(SA_find_group(groupNameCV, &PeerGrp_tag)!=ITK_ok)PrintErrorStack();
												if((DsgGrup ==33) ||(DsgGrup ==35)||(DsgGrup ==40))
												{
													printf("Axle_Peer_role.. \n"); fflush(stdout);
													if(SA_find_role2(Axle_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
												}
												else if ((DsgGrup >=60) && (DsgGrup <=99))
												{
													printf("CAB_Peer_role.. \n"); fflush(stdout);
													if(SA_find_role2(CAB_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
												}
												else if (DsgGrup ==31)
												{
													printf("Chassis_Peer_role.. \n"); fflush(stdout);
													if(SA_find_role2(Chassis_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
												}
												else if ((DsgGrup ==16)||(DsgGrup ==54))
												{
													printf("E_and_E_Peer_role.. \n"); fflush(stdout);
													if(SA_find_role2(E_and_E_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
												}
												else if ((DsgGrup ==42)||(DsgGrup ==43))
												{
													printf("Brakes_Peer_role.. \n"); fflush(stdout);
													if(SA_find_role2(Brakes_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
												}
												else if ((DsgGrup ==47)||(DsgGrup ==49)||(DsgGrup ==50))
												{
													printf("PTrain_Peer_role.. \n"); fflush(stdout);
													if(SA_find_role2(PTrain_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
												}
												else if ((DsgGrup ==29)||(DsgGrup ==30)||(DsgGrup ==46))
												{
													printf("Steering_System_Peer_role.. \n"); fflush(stdout);
													if(SA_find_role2(Steering_System_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
												}
												else if (DsgGrup ==32)
												{
													printf("Suspenssion_Peer_role.. \n"); fflush(stdout);
													if(SA_find_role2(Suspenssion_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
												}
												else if (DsgGrup ==28)
												{
													printf("Gearbox_Peer_role.. \n"); fflush(stdout);
													if(SA_find_role2(Gearbox_Peer_role,&Peer_tag)!=ITK_ok)PrintErrorStack();
													if(SA_find_groupmember_by_role(Peer_tag,PeerGrp_tag,&No_Peer,&Peer_t)!=ITK_ok)PrintErrorStack();
												}
												else
												{
													printf("\n ASSIGN:CV:: ELSE Other design group.. \n"); fflush(stdout);
												}
												printf("\n ASSIGN:CV:: Find  grp member for Peer count..%d \n",No_Peer); fflush(stdout);
												if(No_Peer>0)
												{
													ii=0;
													for(ii=0;ii<No_Peer;ii++)
													{	
														printf("\n ASSIGN:CV:: peer reviewer no: %d",ii);fflush(stdout);
														if(EPM_get_participanttype ("T5_PeerReviewer",&Peer_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(Peer_t[ii],Peer_Patri_Type,&Peer_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(TskRev_t);			
														if(PARTICIPANT_add_participant(TskRev_t,hasbypass,Peer_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(TskRev_t);
														AOM_unlock(TskRev_t);
													}
													AOM_refresh ( TskRev_t,TRUE);
													MEM_free(Peer_t);
												}
											}
											else
											{
												printf("\n MT: Other DML Type...... \n"); fflush(stdout);
											}
										}
									}
								}
							}
						}
					}
				}
			}			
		}
	}
	return error_code;
}
/****************************************************************************
*   Function name			: Assign_Platform_Review_Func
*   Description				: To set PP Reviewer as per platform of project and decide for DML to send for PP reviewer.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		04/07/2018			Mohan Tayade	1.37: Assign PP reviewer
*
****************************************************************************/

int Assign_Platform_Review_Func(EPM_action_message_t msg)
{
	tag_t	root_task        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;
	char	*DMLNo			=  NULL;
	char	*ObjTyp			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	//char   ObjTyp=NULL;
	char	*groupName		= NULL;

	//Platform Reviewer (DML)
	int     pp = 0;
	int     No_PPAna = 0;
	tag_t   PPAna_Rev			= NULLTAG;
	tag_t   PPGrp_tag			= NULLTAG;
	tag_t   PPAnalyst_tag		= NULLTAG;
	tag_t	PPAna_Patri_Type	= NULLTAG;
	tag_t*  PPAna				= NULLTAG;
	tag_t	PPAna_Party		= NULLTAG;
	const char*   Def_PPAna_role = "Def_PPAnalyst";
	const char*   UV_PPAna_role = "UV_PPAnalyst";
	const char*   X0_PPAna_role = "X0_PPAnalyst";
	const char*   X1_PPAna_role = "X1_PPAnalyst";
	const char*   X2_PPAna_role = "X2_PPAnalyst";
	const char*   X3_PPAna_role = "X3_PPAnalyst";
	const char*   X4_PPAna_role = "X4_PPAnalyst";

	// Participants remove.
	int jk = 0;
	int kk = 0;
	int CRBcount = 0;
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char 	*ProjectID		= NULL;
	char	*DMLReviewr		= NULL;
	char	*Part_prj		= NULL;
	tag_t dml_CRB_rel_type	= NULLTAG;
	tag_t* DmlCRB = NULLTAG;
	tag_t	DmlCRBTag		= NULLTAG;
	tag_t	ObjTypProj		= NULLTAG;
	tag_t	ObjTypDmlCRB	= NULLTAG;
	tag_t	TskTypeTag	= NULLTAG;
	tag_t	TskTypeTag1	= NULLTAG;
	char*   type_Proj=NULL;
	char*   type_name7=NULL;
	char*   Tsk_Typ=NULL;
	char*   Tsk_Type=NULL;
	logical is_Tskltst;
	logical is_Tsklatst;
logical hasbypass =true;
	//Task variables
	int     PltFrmPartFlg	=  0;
	int     prt		=  0;
	int     Taskcout	=  0;
	int     partcnt		=  0;
	int     pcnts		=  0;
	char	*Proj_BU		= NULL;
	char	*Part_no		= NULL;
	char	*Modltyp		= NULL;
	char	*BomAna_Role		= NULL;
	tag_t   *TskRevn_tag    =  NULLTAG;
	tag_t   *Parts_t    =  NULLTAG;
	tag_t   *PartsTag    =  NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	DmlTsk_tag		= NULLTAG;
	tag_t	Assy_t		= NULLTAG;
	tag_t	AssyTag		= NULLTAG;
	int ifail = ITK_ok;

	//Qry project
	char	*info1	= NULL;
	tag_t	queryTag   = NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	tag_t	user_tag  = NULLTAG;
	tag_t	Project_tag  = NULLTAG;
	char	*info2	= NULL;
	char	*info3	= NULL;
	char*	username	= NULL;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	tag_t   window     = NULLTAG; 
	tag_t   rule     = NULLTAG; 
	tag_t   top_line     = NULLTAG;
	tag_t *parents = NULLTAG;
	int     jd    = 1;  
	int     n_entry    = 1;  
	int     PRDFlag      =  0; 
	int     atch      =  0; 
	int     rsltCount      =  0; 
	int		resultCount = 0;
	int		n_entries = 1;
	int n_parents,n1_parents = 0;
	int *levels = 0;
	char*	prttyp				=NULL;
	char*	DesgTyp				=NULL;
	char*	Modltype				=NULL;
	char*	modlno				=NULL;
	char*	MObjTyp				=NULL;
	char*	CurrentTask				=NULL;
	char*	task_result				=NULL;
	char*	parent_name				=NULL;
	tag_t job = NULLTAG;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char*	current_release_level=NULL;


	printf("\n MT:PP: Dynamic Platform reviewer assignment start.......\n");fflush(stdout);
	// To get the Task Number from workflow..
	ifail = POM_get_user(&username,&user_tag);
	printf("\n MT:Starting for username:[%s]",username);fflush(stdout);

	ifail = EPM_ask_root_task(msg.task,&root_task);
	printf("\n MT:Root task found");fflush(stdout);

	ifail = AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	printf("\n MT:CurrentTask:%s.",CurrentTask);fflush(stdout);

	ifail = AOM_ask_value_string(msg.task,"task_result",&task_result);
	printf("\n MT:task_result:%s.",task_result);fflush(stdout);

	ifail = AOM_ask_value_string(root_task,"object_name",&parent_name);
	printf("\n MT:Parent Name:%s.",parent_name);fflush(stdout);

	//ifail = EPM_ask_job( msg.task, &job );
	//ifail = EPM_ask_review_task_name2( job,&current_release_level );
	//printf("\n MT:current_release_level :: %s\n",current_release_level); fflush(stdout);
	//if(tc_strcmp(parent_name,"Change Request Life Cycle")==0)
	//{
		//if(tc_strstr(CurrentTask,"Condition")!=NULL)
		//{
			if(EPM_ask_attachments(root_task, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
			printf("\n MT:PP:No of Attachements: [%d]", no_attach);fflush(stdout);
			if(no_attach> 0)
			{
				for(atch=0;atch<no_attach;atch++)
				{
					objTag = attachment[atch];
					if(AOM_ask_value_string(attachment[atch],"object_type",&ObjTyp)!=ITK_ok)PrintErrorStack();
					printf("\n ObjTyp is :%s\n",ObjTyp);fflush(stdout);

					if(AOM_ask_value_string(attachment[atch],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
					printf("\n DMLNo is :%s\n",DMLNo);fflush(stdout);

					if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
					{
						groupName = (char	*)MEM_alloc(100);
						tc_strcpy(groupName,"DML_Participants_Group");
						printf("\n MT:PP: groupName : %s",groupName);   fflush(stdout);

						if(AOM_ask_value_string(attachment[atch],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
						printf("\n MT:PP:DML Number: [%s] DMLType: [%s]", DMLNo,DMLType);fflush(stdout);

						if(tc_strcmp(DMLType,"Veh")!=0)
						{
							if(AOM_ask_value_string(attachment[atch],"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
							printf("\n MT:PP: ProjectID : %s",ProjectID);   fflush(stdout);
							if(ProjectID)
							{
								if(QRY_find2("Qury_Project", &queryTag));
								printf("\n MT:After Prd_Project: QRY_find2");fflush(stdout);
								if (queryTag)
								{
									printf("\n MT:Found Query");fflush(stdout);
								}
								else
								{
									printf("\n MT:Not Found Query");fflush(stdout);
								}
								qry_values[0] = ProjectID;

								if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
								printf("\n MT: resultCount : %d\n", resultCount); fflush(stdout);

								if(resultCount > 0)
								{
									printf("\n MT:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
									Project_t = t5_Project[0];
									if (Project_t!=NULLTAG)
									{
										if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
										printf("\n MT: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
										//Query control table for PRDtoCVBU workflow project list.
										printf("\n MT:Checking PRD  to CVBU WF project...\n"); fflush(stdout);
										if(QRY_find2("ControlObjects", &qryTag));
										if (qryTag)
										{
											printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
										}
										else
										{
											printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
										}

										qry_values2[0] = "PRDCVBU";
										if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
										printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
										if(rsltCount > 0)
										{
											if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
											printf("\n info1 is :[%s]\n", info1);fflush(stdout);
											if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
											printf("\n info2 is :[%s]\n", info2);fflush(stdout);
											if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
											printf("\n info3 is :[%s]\n", info3);fflush(stdout);
										}
										if(tc_strcmp(ProjectClass,"PRD")==0)
										{
											if((tc_strstr(info1,ProjectID)!=NULL) || (tc_strstr(info2,ProjectID)!=NULL))
											{
												PRDFlag=1;
												printf("\n MT: PRD project of CVBU found: %d",PRDFlag); fflush(stdout);
											}
											else
											{
												PRDFlag=0;
												printf("\n MT: No project CVBU found: %d",PRDFlag); fflush(stdout);
											}
										}
										else
										{
											PRDFlag=1;
											printf("\n MT: No PRD project: %d",PRDFlag); fflush(stdout);
										}
										if (PRDFlag >0)
										{
											printf("\n MT:PASS: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
											if (((tc_strcmp(Proj_BU,"PCBU")==0)||(tc_strcmp(Proj_BU,"PVBU")==0))&&((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"XO")!=0)&&(tc_strcmp(DMLType,"TOO")!=0)&&(tc_strcmp(DMLType,"SVR")!=0)))
											{
												//REMOVE PARTICIPALNTS START
												if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
												if (dml_CRB_rel_type!=NULLTAG)
												{
													printf("\n MT:PP: REMOVE PARTICIPALNTS START......... \n"); fflush(stdout);
													if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
													printf("\n MT:PP: DmlCRB count: %d",CRBcount);fflush(stdout);	
													for (jk=0;jk<CRBcount ;jk++ )
													{	
														DmlCRBTag = DmlCRB[jk];
														if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
														if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
														printf("\n MT:PP:DML: type_name7 :: %s", type_name7);fflush(stdout);
														if(tc_strcmp(DMLType,"SVR")!=0)
														{
															if (tc_strcmp(type_name7,"T5_PPReviewer")==0)
															{
																if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
																printf("\n MT:PP: Removing PP reviewer: [%s] ",DMLReviewr);fflush(stdout);
																AOM_lock(objTag);
																if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
																AOM_save_without_extensions(objTag);
																AOM_unlock(objTag);
															}
														}
													}
												}
												printf("\n MT:PP:START ASSIGNING PLATFORM REVIEWER: DML: [%s] Type: [%s] PltFrm :[%s] Proj_BU:[%s]\n", DMLNo,DMLType,Proj_PltFrm,Proj_BU);fflush(stdout);
												if(tc_strcmp(Proj_PltFrm,"")!=0)
												{
													//Check if part of 5447 project available in task.WORKINGgggg
													if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTsk_tag)!=ITK_ok)PrintErrorStack();
													if (DmlTsk_tag!=NULLTAG)
													{		
														if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
														printf("\n MT:PP: TskRevn_tag Taskcout : %d",Taskcout);fflush(stdout);
														for (kk=0;kk<Taskcout ;kk++ )
														{
															if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
															if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));
															printf("\n MT:PP: Tsk_Typ := %s", Tsk_Typ);fflush(stdout); 
															if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
															{
																if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
																if(is_Tskltst != true)
																{
																	printf("\n MT:PP:is_Tskltst is not true .....\n");fflush(stdout);
																}
																else
																{
																	if(AOM_ask_value_tags(TskRevn_tag[kk],"CMHasSolutionItem",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
																	printf("\n MT:PP: partcnt.:%d\n",partcnt);fflush(stdout);
																	if (partcnt>0)
																	{
																		prt=0;
																		PltFrmPartFlg=0;
																		for (prt=0;prt<partcnt ;prt++ )
																		{							
																			AssyTag=PartsTag[prt];
																			if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																			printf("\n MT:PP:.Part_no:%s ...",Part_no);	fflush(stdout);
																			if (AOM_ask_value_string(AssyTag,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																			printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																			if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																			printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);
																			
																			//If 14 digit part and part type is Module then get Module type...
																			if(tc_strcmp(Part_prj,"5447")==0)
																			{
																				PltFrmPartFlg++;
																				printf("\n PltFrmPartFlg...BREAKING1: [%d]\n", PltFrmPartFlg);fflush(stdout);
																				break;
																			}
																			else if ((tc_strcmp(DesgTyp,"M")==0)&&(strlen(Part_no) ==14))
																			{
																				//get the Module type t5_ModuleType	....																					
																				if(AOM_ask_value_string(AssyTag,"t5_ModuleType",&Modltyp)!=ITK_ok)PrintErrorStack();
																				printf("\n MT:PP:Modltyp:%s ...",Modltyp);	fflush(stdout);
																				if (tc_strcmp(Modltyp,"PLATFORM")==0)
																				{
																					PltFrmPartFlg++;
																					printf("\n PltFrmPartFlg...BREAKING2: [%d]\n", PltFrmPartFlg);fflush(stdout);
																					break;
																				}
																			}
																		}
																		if (PltFrmPartFlg >0)
																		{
																			break;
																		}
																	}
																}
															}
														}
														printf("\n After first for loop.... \n"); fflush(stdout);
														if(tc_strstr(info3,"PLATFORM")==NULL)
														{
															if (PltFrmPartFlg ==0)
															{
																kk=0;
																for (kk=0;kk<Taskcout ;kk++ )
																{
																	if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag1));
																	if(TCTYPE_ask_name2(TskTypeTag1,&Tsk_Type));
																	printf("\n MT:PP: Tsk_Type := %s", Tsk_Type);fflush(stdout); 
																	if(tc_strcmp(Tsk_Type,"T5_ChangeTaskRevision")==0)
																	{
																		if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
																		if(is_Tsklatst != true)
																		{
																			printf("\n MT:PP:is_Tsklatst is not true .....\n");fflush(stdout);
																		}
																		else
																		{
																			partcnt=0;
																			if(AOM_ask_value_tags(TskRevn_tag[kk],"CMHasSolutionItem",&partcnt,&Parts_t)!=ITK_ok)PrintErrorStack();
																			printf("\n MT:PP:Now partcnt:%d\n",partcnt);fflush(stdout);
																			if (partcnt>0)
																			{
																				prt=0;
																				PltFrmPartFlg=0;
																				for (prt=0;prt<partcnt ;prt++ )
																				{	
																					Part_no = NULL;
																					Part_prj = NULL;
																					DesgTyp = NULL;
																					Part_no = NULL;
																					Assy_t=Parts_t[prt];
																					if(AOM_ask_value_string(Assy_t,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
																					printf("\n MT:PP:Part_no:%s ...",Part_no);	fflush(stdout);
																					if (AOM_ask_value_string(Assy_t,"t5_ProjectCode",&Part_prj)!=ITK_ok)   PrintErrorStack();
																					printf(" Part_prj:[%s] ...",Part_prj);	fflush(stdout);
																					if (AOM_ask_value_string(Assy_t,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
																					printf(" DesgTyp: [%s]\n", DesgTyp);fflush(stdout);

																					if (((tc_strcmp(DesgTyp,"A")==0)||(tc_strcmp(DesgTyp,"C")==0)||(tc_strcmp(DesgTyp,"G")==0))&&(strlen(Part_no) ==12))
																					{
																						//Implossion: If 12 digit part.
																						if(BOM_create_window (&window)!=ITK_ok)PrintErrorStack();
																						if(CFM_find( "Latest Working", &rule )!=ITK_ok)PrintErrorStack();
																						if(BOM_set_window_config_rule( window, rule )!=ITK_ok)PrintErrorStack();
																						if(BOM_set_window_top_line (window, null_tag,Assy_t , null_tag, &top_line)!=ITK_ok)PrintErrorStack();

																						PS_where_used_all( Assy_t, PS_where_used_all_levels, &n_parents, &levels, &parents );
																						printf("\n CP where_used count of parents: %d",n_parents); fflush(stdout);
																						if(n_parents>0)
																						{
																							jd=0;
																							for (jd=0;jd<n_parents;jd++ )
																							{
																								prttyp	= NULL;
																								Modltype	= NULL;
																								MObjTyp	= NULL;
																								modlno	= NULL;
																								if(AOM_ask_value_string(parents[jd],"item_id",&modlno)!=ITK_ok)PrintErrorStack(); 
																								printf("\n\t part no:[%s]",modlno);	fflush(stdout);
																								if(AOM_ask_value_string(parents[jd],"object_type",&MObjTyp)!=ITK_ok)PrintErrorStack();
																								printf("\t Objtype :[%s]",MObjTyp);fflush(stdout);
																								if(tc_strcmp(MObjTyp,"Design Revision")==0 || tc_strcmp(MObjTyp,"ItemRevision")==0)
																								{
																									if (AOM_ask_value_string(parents[jd],"t5_PartType",&prttyp)!=ITK_ok)   PrintErrorStack();
																									printf("\t Parttype:[%s]",prttyp);	fflush(stdout);
																									if (tc_strcmp(prttyp,"M")==0)
																									{
																										//get the Module type t5_ModuleType	....																					
																										if(AOM_ask_value_string(parents[jd],"t5_ModuleType",&Modltype)!=ITK_ok)PrintErrorStack();
																										printf("\t Modltype:[%s]",Modltype);	fflush(stdout);
																										if (tc_strcmp(Modltype,"PLATFORM")==0)
																										{
																											PltFrmPartFlg++;
																											printf("\t CONFIRMED.....:[%s] ...",Modltype);	fflush(stdout);
																											break;
																										}
																									}
																								}
																							}
																							if (PltFrmPartFlg >0)
																							{
																								break;
																							}
																						}
																					}
																				}
																				if (PltFrmPartFlg >0)
																				{
																					break;
																				}
																			}
																		}
																	}
																}
															}
														}
													}
													printf("\n Setting PP reviewer.... \n"); fflush(stdout);
													if (PltFrmPartFlg >0)
													{
														if(SA_find_group(groupName, &PPGrp_tag)!=ITK_ok)PrintErrorStack();
														if(tc_strcmp(Proj_PltFrm,"Defence")==0)
														{
															printf("Def_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(Def_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"UV")==0)
														{
															printf("UV_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(UV_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"X0")==0)
														{
															printf("X0_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(X0_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"X1")==0)
														{
															printf("X1_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(X1_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"X2")==0)
														{
															printf("X2_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(X2_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"X3")==0)
														{
															printf("X3_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(X3_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else if(tc_strcmp(Proj_PltFrm,"X4")==0)
														{
															printf("X4_PPAna_role.. \n"); fflush(stdout);
															if(SA_find_role2(X4_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
														else
														{
															printf("OTHER PLATFORM... \n"); fflush(stdout);
															if(SA_find_role2(Def_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
															if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
														}
													
														printf("\n MT:No_PPAna :[%d]",No_PPAna);  fflush(stdout);
														if(No_PPAna>0)
														{
															for(pp=0;pp<No_PPAna;pp++)
															{	
																printf("\n MT:PP Analyst no: [%d]",pp);fflush(stdout);
																if(EPM_get_participanttype ("T5_PPReviewer",&PPAna_Patri_Type)!=ITK_ok)PrintErrorStack();
																if(EPM_create_participant(PPAna[pp],PPAna_Patri_Type,&PPAna_Party)!=ITK_ok)PrintErrorStack();
																AOM_lock(objTag);			
																if(PARTICIPANT_add_participant(objTag,hasbypass,PPAna_Party)!=ITK_ok)PrintErrorStack();	
																AOM_save_without_extensions(objTag);
																AOM_unlock(objTag);
															}
														}
														AOM_refresh ( objTag,TRUE);
														MEM_free(PPAna);
														//break;
													}
												}
											}
										}
										else
										{
											printf("\n PRD project or NO project available..\n");fflush(stdout);
										}
									}
								}
							}
						}
					}
				}
			}
		//}
	//}
	printf("\n MT:PP:Now PltFrmPartFlg:%d ",PltFrmPartFlg);fflush(stdout);
	if (PltFrmPartFlg >0)
	{
		ifail = EPM_set_task_result(msg.task,EPM_RESULT_True);
		printf("\n EPM_RESULT_True inside PP Reviewer: %d",ifail); fflush(stdout);	
	}
	else
	{
		ifail = EPM_set_task_result(msg.task,EPM_RESULT_False);
		printf("\n EPM_RESULT_False: %d",ifail); fflush(stdout);
	}

	return ifail;
}
/****************************************************************************
*   Function name			: Assign_Chassis_Review_Func
*   Description				: To set CH Reviewer as per platform of project and decide for DML to send for CH reviewer.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		17/12/2018			Mohan Tayade	1.37: Assign CH reviewer
*
****************************************************************************/

int Assign_Chassis_Review_Func(EPM_action_message_t msg)
{
	int no_attach =  0;
	int pp = 0;
	int No_CHAna = 0;
	int No_PPAna = 0;
	int jk = 0;
	int CRBcount = 0;
	int ifail = ITK_ok;
	int atch =  0; 
	int	resultCount = 0;
	int	n_entries = 1;
	char	*DMLType		= NULL;
	char	*DMLNo			= NULL;
	char	*ObjTyp			= NULL;
	char	*groupName		= NULL;
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char 	*ProjectID		= NULL;
	char	*DMLReviewr		= NULL;
	char	*Proj_BU		= NULL;
	char*	sDMLBU		= NULL;
	char*	username		= NULL;
	char*	CurrentTask		= NULL;
	char*	task_result		= NULL;
	char*	parent_name		= NULL;
	char	*qry_entries[1]	= {"Name"};
	char*	ProjectClass	= NULL;
	char*   type_name7=NULL;
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char*	current_release_level= NULL;
	tag_t	root_task			=  NULLTAG;
	tag_t   *attachment			=  NULLTAG;
	tag_t	objTag				=  NULLTAG;
	tag_t   CHGrp_tag			= NULLTAG;
	tag_t   PPGrp_tag			= NULLTAG;
	tag_t   CHAnalyst_tag		= NULLTAG;
	tag_t   PPAnalyst_tag		= NULLTAG;
	tag_t	CHAna_Patri_Type	= NULLTAG;
	tag_t	PPAna_Patri_Type	= NULLTAG;
	tag_t*  CHAna				= NULLTAG;
	tag_t*  PPAna				= NULLTAG;
	tag_t	CHAna_Party			= NULLTAG;
	tag_t	PPAna_Party			= NULLTAG;
	tag_t	objTypTag			= NULLTAG;
	tag_t	dml_CRB_rel_type	= NULLTAG;
	tag_t*	DmlCRB				= NULLTAG;
	tag_t	DmlCRBTag			= NULLTAG;
	tag_t	ObjTypDmlCRB		= NULLTAG;
	tag_t	Project_t			= NULLTAG;
	tag_t	queryTag			= NULLTAG;
	tag_t   *t5_Project			= NULLTAG;
	tag_t	user_tag			= NULLTAG;
	tag_t	Project_tag			= NULLTAG;
	tag_t	job					= NULLTAG;
	const char*   BUS_CHAna_role = "BUS_Chassis_Designer";
	const char*   CAR_CHAna_role = "CAR_Chassis_Designer";
	const char*   HCV_CHAna_role = "HCV_Chassis_Designer";
	const char*   LCV_CHAna_role = "LCV_Chassis_Designer";
	const char*   LMV_CHAna_role = "LMV_Chassis_Designer";
	const char*   MCV_CHAna_role = "MCV_Chassis_Designer";
	const char*   MUV_CHAna_role = "MUV_Chassis_Designer";
	const char*   PRD_CHAna_role = "PRD_Chassis_Designer";
	const char*   UV_VAN_CHAna_role = "UV_VAN_Chassis_Designer";
	const char*   Other_CHAna_role = "Chassis_Designer";
	const char*   BUS_PPAna_role = "BUS_Diagnostic_Designer";
	const char*   CAR_PPAna_role = "CAR_Diagnostic_Designer";
	const char*   HCV_PPAna_role = "HCV_Diagnostic_Designer";
	const char*   LCV_PPAna_role = "LCV_Diagnostic_Designer";
	const char*   LMV_PPAna_role = "LMV_Diagnostic_Designer";
	const char*   MCV_PPAna_role = "MCV_Diagnostic_Designer";
	const char*   MUV_PPAna_role = "MUV_Diagnostic_Designer";
	const char*   PRD_PPAna_role = "PRD_Diagnostic_Designer";
	const char*   UV_VAN_PPAna_role = "UV_VAN_Diagnostic_Designer";
	const char*   Other_PPAna_role = "Diagnostic_Designer";
	logical hasbypass =true;

	// Participants remove.BUS_Diagnostic_Designer
	printf("\n CH: Dynamic CHASSIS reviewer assignment start.......\n");fflush(stdout);
	// To get the Task Number from workflow..
	ifail = POM_get_user(&username,&user_tag);
	printf("\n CH:Starting for username:[%s]",username);fflush(stdout);

	ifail = EPM_ask_root_task(msg.task,&root_task);
	printf("\n CH:Root task found");fflush(stdout);

	ifail = AOM_ask_value_string(msg.task,"object_name",&CurrentTask);
	printf("\n CH:CurrentTask:%s.",CurrentTask);fflush(stdout);

	ifail = AOM_ask_value_string(msg.task,"task_result",&task_result);
	printf("\n CH:task_result:%s.",task_result);fflush(stdout);

	ifail = AOM_ask_value_string(root_task,"object_name",&parent_name);
	printf("\n CH:Parent Name:%s.",parent_name);fflush(stdout);

	//ifail = EPM_ask_job( msg.task, &job );
	//ifail = EPM_ask_review_task_name2( job,&current_release_level );
	//printf("\n CH:current_release_level :: %s\n",current_release_level); fflush(stdout);

	if(EPM_ask_attachments(root_task, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n CH:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach> 0)
	{
		for(atch=0;atch<no_attach;atch++)
		{
			objTag = attachment[atch];
			if(AOM_ask_value_string(attachment[atch],"object_type",&ObjTyp)!=ITK_ok)PrintErrorStack();
			printf("\n CH:ObjTyp is :%s\n",ObjTyp);fflush(stdout);

			if(AOM_ask_value_string(attachment[atch],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
			printf("\n CH:DMLNo is :%s\n",DMLNo);fflush(stdout);
			
			if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
			{
				groupName = (char	*)MEM_alloc(100);
				//DML BU
				if(AOM_ask_value_string(attachment[atch],"t5_ERCBusiUt",&sDMLBU)!=ITK_ok)PrintErrorStack();
				printf("\n CH:sDMLBU is :%s\n",sDMLBU);fflush(stdout);
				if(tc_strstr(sDMLBU,"CV") != NULL)
				{
					tc_strcpy(groupName,"DML_Participants_Group_CV");
				}
				else
				{
					tc_strcpy(groupName,"DML_Participants_Group");
				}
				printf("\n CH: groupName : %s",groupName);   fflush(stdout);

				if(AOM_ask_value_string(attachment[atch],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
				printf("\n CH:DML Number: [%s] DMLType: [%s]", DMLNo,DMLType);fflush(stdout);

				if(tc_strcmp(DMLType,"Veh")==0)
				{
					if(AOM_ask_value_string(attachment[atch],"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
					printf("\n CH: ProjectID : %s",ProjectID);   fflush(stdout);
					if(ProjectID)
					{
						if(QRY_find2("Qury_Project", &queryTag));
						printf("\n CH:After Prd_Project: QRY_find2");fflush(stdout);
						if (queryTag)
						{
							printf("\n CH:Found Query");fflush(stdout);
						}
						else
						{
							printf("\n CH:Not Found Query");fflush(stdout);
						}
						qry_values[0] = ProjectID;

						if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
						printf("\n CH: resultCount : %d\n", resultCount); fflush(stdout);

						if(resultCount > 0)
						{
							printf("\n CH:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
							Project_t = t5_Project[0];
							if (Project_t!=NULLTAG)
							{
								if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
								if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
								printf("\n CH: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);

								printf("\n CH:PASS: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
								if((tc_strstr(sDMLBU,"CV") != NULL)||(tc_strstr(sDMLBU,"PV") != NULL)||(tc_strstr(sDMLBU,"PC") != NULL))
								{
									if ((tc_strcmp(DMLType,"PDR")!=0)&&(tc_strcmp(DMLType,"TOO")!=0)&&(tc_strcmp(DMLType,"SVR")!=0))
									{
										printf("\n CH:START ASSIGNING CHASSIS REVIEWER: DML: [%s] Type: [%s] ProjectClass :[%s] Proj_BU:[%s]\n", DMLNo,DMLType,ProjectClass,Proj_BU);fflush(stdout);
										if(tc_strcmp(ProjectClass,"")!=0)
										{
											//REMOVE/Add PARTICIPALNTS START
											if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
											if (dml_CRB_rel_type!=NULLTAG)
											{
												printf("\n CH: Remove Chassis/Diag Reviewers......... \n"); fflush(stdout);
												if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
												printf("\n CH:DmlCRB count: %d",CRBcount);fflush(stdout);	
												for (jk=0;jk<CRBcount ;jk++ )
												{	
													DmlCRBTag = DmlCRB[jk];
													if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
													if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
													printf("\n CH:DML: type_name7 :: %s", type_name7);fflush(stdout);
													if (tc_strcmp(type_name7,"T5_ChassisReviewer")==0)
													{
														printf("\n CH: Remove Chassis Reviewers......... \n"); fflush(stdout);
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
														printf("\n CH: Removing chassis reviewer: [%s] [%d]",DMLReviewr,jk);fflush(stdout);
														AOM_lock(objTag);
														if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
														AOM_save_without_extensions(objTag);
														AOM_unlock(objTag);
													}
													if (tc_strcmp(type_name7,"T5_DiaPrtRev")==0)
													{
														printf("\n CH: Remove Diag Reviewers......... \n"); fflush(stdout);
														if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
														printf("\n CH: Removing Diag reviewer: [%s] [%d]",DMLReviewr,jk);fflush(stdout);
														AOM_lock(objTag);
														if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
														AOM_save_without_extensions(objTag);
														AOM_unlock(objTag);
													}
												}
											}
											printf("\n CH:Setting CH reviewer.... \n"); fflush(stdout);
											if(SA_find_group(groupName, &CHGrp_tag)!=ITK_ok)PrintErrorStack();
											if(tc_strcmp(ProjectClass,"BUS")==0)
											{
												printf("BUS_CHAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(BUS_CHAna_role,&CHAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CHAnalyst_tag,CHGrp_tag,&No_CHAna,&CHAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"CAR")==0)
											{
												printf("CAR_CHAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(CAR_CHAna_role,&CHAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CHAnalyst_tag,CHGrp_tag,&No_CHAna,&CHAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"HCV")==0)
											{
												printf("HCV_CHAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(HCV_CHAna_role,&CHAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CHAnalyst_tag,CHGrp_tag,&No_CHAna,&CHAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"LCV")==0)
											{
												printf("LCV_CHAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(LCV_CHAna_role,&CHAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CHAnalyst_tag,CHGrp_tag,&No_CHAna,&CHAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"LMV")==0)
											{
												printf("LMV_CHAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(LMV_CHAna_role,&CHAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CHAnalyst_tag,CHGrp_tag,&No_CHAna,&CHAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"MCV")==0)
											{
												printf("MCV_CHAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(MCV_CHAna_role,&CHAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CHAnalyst_tag,CHGrp_tag,&No_CHAna,&CHAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"MUV")==0)
											{
												printf("MUV_CHAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(MUV_CHAna_role,&CHAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CHAnalyst_tag,CHGrp_tag,&No_CHAna,&CHAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"PRD")==0)
											{
												printf("PRD_CHAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(PRD_CHAna_role,&CHAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CHAnalyst_tag,CHGrp_tag,&No_CHAna,&CHAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"UV_VAN")==0)
											{
												printf("UV_VAN_CHAna_role .. \n"); fflush(stdout);
												if(SA_find_role2(UV_VAN_CHAna_role,&CHAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CHAnalyst_tag,CHGrp_tag,&No_CHAna,&CHAna)!=ITK_ok)PrintErrorStack();
											}
											else
											{
												printf("OTHER ProjectClass... \n"); fflush(stdout);
												if(SA_find_role2(Other_CHAna_role,&CHAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CHAnalyst_tag,CHGrp_tag,&No_CHAna,&CHAna)!=ITK_ok)PrintErrorStack();
											}
										
											printf("\n CH:No_CHAna :[%d]",No_CHAna);  fflush(stdout);
											if(No_CHAna>0)
											{
												pp=0;
												for(pp=0;pp<No_CHAna;pp++)
												{	
													printf("\n MT:CH Analyst no: [%d]",pp);fflush(stdout);
													if(EPM_get_participanttype ("T5_ChassisReviewer",&CHAna_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(CHAna[pp],CHAna_Patri_Type,&CHAna_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(objTag);			
													if(PARTICIPANT_add_participant(objTag,hasbypass,CHAna_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(objTag);
													AOM_unlock(objTag);
												}
											}
											AOM_refresh ( objTag,TRUE);
											MEM_free(CHAna);
											printf("\n Assign chassis reviewer END. "); fflush(stdout);
											//Setting Diag reviewer.
											printf("\n CH:Setting Diag reviewer.... \n"); fflush(stdout);
											if(SA_find_group(groupName, &PPGrp_tag)!=ITK_ok)PrintErrorStack();
											if(tc_strcmp(ProjectClass,"BUS")==0)
											{
												printf("BUS_PPAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(BUS_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"CAR")==0)
											{
												printf("CAR_PPAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(CAR_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"HCV")==0)
											{
												printf("HCV_PPAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(HCV_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"LCV")==0)
											{
												printf("LCV_PPAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(LCV_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"LMV")==0)
											{
												printf("LMV_PPAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(LMV_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"MCV")==0)
											{
												printf("MCV_PPAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(MCV_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"MUV")==0)
											{
												printf("MUV_PPAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(MUV_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"PRD")==0)
											{
												printf("PRD_PPAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(PRD_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
											}
											else if(tc_strcmp(ProjectClass,"UV_VAN")==0)
											{
												printf("UV_VAN_PPAna_role.. \n"); fflush(stdout);
												if(SA_find_role2(UV_VAN_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
											}
											else
											{
												printf("OTHER ProjectClass... \n"); fflush(stdout);
												if(SA_find_role2(Other_PPAna_role,&PPAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(PPAnalyst_tag,PPGrp_tag,&No_PPAna,&PPAna)!=ITK_ok)PrintErrorStack();
											}
										
											printf("\n CH:No_PPAna :[%d]",No_PPAna);  fflush(stdout);
											if(No_PPAna>0)
											{
												pp=0;
												for(pp=0;pp<No_PPAna;pp++)
												{	
													printf("\n CH:CH Analyst no: [%d]",pp);fflush(stdout);
													if(EPM_get_participanttype ("T5_DiaPrtRev",&PPAna_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(PPAna[pp],PPAna_Patri_Type,&PPAna_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(objTag);			
													if(PARTICIPANT_add_participant(objTag,hasbypass,PPAna_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(objTag);
													AOM_unlock(objTag);
												}
											}
											AOM_refresh ( objTag,TRUE);
											printf("\n Assign diag reviewer done.refresh done111111 \n"); fflush(stdout);
											MEM_free(PPAna);
											printf("\n Assign diag reviewer done. \n"); fflush(stdout);
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	//	printf("\n MT:CH:Now PltFrmPartFlg:%d ",PltFrmPartFlg);fflush(stdout);
	//	if (PltFrmPartFlg >0)
	//	{
	//		ifail = EPM_set_task_result(msg.task,EPM_RESULT_True);
	//		printf("\n EPM_RESULT_True inside CH Reviewer: %d",ifail); fflush(stdout);	
	//	}
	//	else
	//	{
	//		ifail = EPM_set_task_result(msg.task,EPM_RESULT_False);
	//		printf("\n EPM_RESULT_False: %d",ifail); fflush(stdout);
	//	}
	printf("\n ....................Chassis Reviewer assignment done.\n");fflush(stdout);

	return ifail;
}

/****************************************************************************
*   Function name			: Assign_SVRCOC_party_Func
*   Description				: To set SVR COC Reviewer to DML tasks.
*	Modification History	:
*	S.No	Date		CR No   Modified By		Modification Notes
*	01		17/12/2018			Mohan Tayade	1.42: Assign CH reviewer
*
****************************************************************************/

int Assign_SVRCOC_party_Func(EPM_action_message_t msg)
{
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;
	char	*DMLNo			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=NULL;
	char	*groupName		= NULL;
	char	*DsgGrp			= NULL;
	char	*Task_name		= NULL;
	
	//VI Reviewer
	int     iii = 0;
	int     No_VIAna = 0;
	tag_t   VIAna_Rev			= NULLTAG;
	tag_t   VIGrp_tag			= NULLTAG;
	tag_t   VIAnalyst_tag		= NULLTAG;
	tag_t	VIAna_Patri_Type	= NULLTAG;
	tag_t*  VIAna				= NULLTAG;
	tag_t	VIAna_Party		= NULLTAG;
	const char*   VIAnalyst_role = "VI_Reviewer";

	//SVR COC Reviewer (Task)
	tag_t	*GmFound1 = NULLTAG;
	tag_t	*GmFound2 = NULLTAG;
	tag_t	*GmFound3 = NULLTAG;
	char*	 sUserId = NULL;
	char*	 GrpMembName = NULL;
	tag_t	GrpTag = NULLTAG;
	int	AccesFound=0;
	int	jkl=0;
	int	Gmcnt1=0;
	int	Gmcnt2=0;
	int	Gmcnt3=0;
	const char*   BIW_SVRCoC_role = "BIW_COC_Reviewer";
	const char*   Trim_SVRCoC_role = "Trim_COC_Reviewer";
	const char*   CH_SVRCoC_role = "Chassis_COC_Reviewer";
	const char*   EE_SVRCoC_role = "EE_COC_Reviewer";
	const char*   PT_SVRCoC_role = "Powertrain_COC_Reviewer";
	//BIW_COC_Reviewer
	int     b = 0;
	int     No_SVRcoc = 0;
	tag_t   SVRcocGrp_tag	= NULLTAG;
	tag_t   SVRcoc_tag		= NULLTAG;
	tag_t	SVRcoc_Patri_Type	= NULLTAG;
	tag_t*  SVRcoc_t			= NULLTAG;
	tag_t	SVRcoc_Party		= NULLTAG;
	//Trim_SVRCoC_role
	int     tr = 0;
	int     No_SVRt = 0;
	tag_t   SVRtGrp_tag	= NULLTAG;
	tag_t   SVRt_tag		= NULLTAG;
	tag_t	SVRt_Patri_Type	= NULLTAG;
	tag_t*  SVRt_t			= NULLTAG;
	tag_t	SVRt_Party		= NULLTAG;
	//CH_SVRCoC_role
	int     c = 0;
	int     No_SVRc = 0;
	tag_t   SVRcGrp_tag	= NULLTAG;
	tag_t   SVRc_tag		= NULLTAG;
	tag_t	SVRc_Patri_Type	= NULLTAG;
	tag_t*  SVRc_t			= NULLTAG;
	tag_t	SVRc_Party		= NULLTAG;
	//EE_SVRCoC_role
	int     e = 0;
	int     No_SVRe = 0;
	tag_t   SVReGrp_tag	= NULLTAG;
	tag_t   SVRe_tag		= NULLTAG;
	tag_t	SVRe_Patri_Type	= NULLTAG;
	tag_t*  SVRe_t			= NULLTAG;
	tag_t	SVRe_Party		= NULLTAG;
	//PT_SVRCoC_role
	int     p = 0;
	int     No_SVRp = 0;
	tag_t   SVRpGrp_tag	= NULLTAG;
	tag_t   SVRp_tag		= NULLTAG;
	tag_t	SVRp_Patri_Type	= NULLTAG;
	tag_t*  SVRp_t			= NULLTAG;
	tag_t	SVRp_Party			= NULLTAG;

	// Participants remove.
	int jk = 0;
	int jkk = 0;
	int kk = 0;
	int jtsk = 0;
	int CRBcount = 0;
	int CRBcunt = 0;
	char	*TskReviewr		= NULL;
	char	*ProjDesc		= NULL;
	char 	*Proj_PltFrm	= NULL;
	char 	*ProjectID		= NULL;
	char	*DMLReviewr		= NULL;
	char	*Part_prj		= NULL;
	tag_t Tsk_CRB_rel_type	= NULLTAG;
	tag_t dml_CRB_rel_type	= NULLTAG;
	tag_t* TskCRB = NULLTAG;
	tag_t* DmlCRB = NULLTAG;
	tag_t	TskCRBTag		= NULLTAG;
	tag_t	DmlCRBTag		= NULLTAG;
	tag_t	ObjTypProj		= NULLTAG;
	tag_t	ObjTypDmlCRB	= NULLTAG;
	tag_t	TskTypeTag	= NULLTAG;
	tag_t	ObjTypTskCRB	= NULLTAG;
	tag_t	TskRev_tg		= NULLTAG;
	char*   type_Proj=NULL;
	char*   type_name7=NULL;
	char*   type_name8=NULL;
	char*   Tsk_Typ=NULL;
	logical is_Tskletst;
	logical is_Tskltst;
	logical hasbypass =true;
	int     t		=  0;

	//Task variables	
	int     PRDFlag	=  0;
	int     Taskcout	=  0;
	int     partcnt		=  0;
	int     Tskcout		=  0;
	char	*Proj_BU		= NULL;
	char	*Part_no		= NULL;
	char	*BomAna_Role		= NULL;
	char	*Tsk_class		= NULL;
	tag_t   *TskRevn_tag    =  NULLTAG;
	tag_t   *TskRev_tag    =  NULLTAG;
	tag_t   *PartsTag    =  NULLTAG;
	tag_t	TskCls_t		= NULLTAG;
	tag_t	TskRev_t		= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	DmlTask_tag		= NULLTAG;
	tag_t	DmlTsk_tag		= NULLTAG;
	tag_t	tUserTag		= NULLTAG;
	tag_t	AssyTag		= NULLTAG;
	tag_t projTag = NULLTAG;
	logical is_Tsklatst;
	int error_code = ITK_ok;
	//Qry Project
	char	*info1	= NULL;
	tag_t	queryTag   = NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	tag_t	Project_tag  = NULLTAG;
	char	*info2	= NULL;
	char	*info3	= NULL;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   qryTag     = NULLTAG; 
	int     n_entry    = 1;  
	int     rsltCount      =  0; 
	int		resultCount = 0;
	int		n_entries = 1;
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char    *qry_entry[1]  = {"SYSCD"};
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));

	printf("\n MT: Dynamic SVR COC particiant assignment start.......");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\n MT:No of Attachements: [%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
	printf("\n MT:DML/Task Number: [%s].", DMLNo);fflush(stdout);

	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\n MT: Workfow obj type: [%s]\n", ObjTyp);fflush(stdout);

	groupName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"DML_Participants_Group");
	printf("\n MT: groupName  --> %s\n",groupName);   fflush(stdout);

	if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
	{
		if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
		printf("\n MT:DML Number: [%s] DMLType: [%s]", DMLNo,DMLType);fflush(stdout);

		if(AOM_ask_value_string(attachment[0],"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
		printf("\n MT: ProjectID : %s",ProjectID);   fflush(stdout);

		//if(ITEM_find_item(ProjectID,&Project_t)!=ITK_ok)PrintErrorStack();
		if(ProjectID)
		{
			if(QRY_find2("Qury_Project", &queryTag));
			printf("\n MT:After Prd_Project: QRY_find2");fflush(stdout);
			if (queryTag)
			{
				printf("\n MT:Found Query");fflush(stdout);
			}
			else
			{
				printf("\n MT:Not Found Query");fflush(stdout);
			}

			qry_values[0] = ProjectID;

			if(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &resultCount, &t5_Project));
			printf("\n MT: resultCount : %d\n", resultCount); fflush(stdout);

			if(resultCount > 0)
			{
				printf("\n MT:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
				Project_t = t5_Project[0];
				if (Project_t!=NULLTAG)
				{
					if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
					if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
					printf("\n MT: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
					//Query control table for PRDtoCVBU workflow project list.
					printf("\n MT:.Checking PRD  to CVBU WF project...\n"); fflush(stdout);
					if(QRY_find2("ControlObjects", &qryTag));
					if (qryTag)
					{
						printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
					}
					else
					{
						printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
					}

					qry_values2[0] = "PRDCVBU";
					if(QRY_execute(qryTag, n_entry, qry_entry, qry_values2, &rsltCount, &CntrlObjectTag));
					printf(" \n PRDCVBU:rsltCount :%d:", rsltCount); fflush(stdout);
					if(rsltCount > 0)
					{
						if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
						printf("\n info1 is.:[%s]\n", info1);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
						printf("\n info2 is.:[%s]\n", info2);fflush(stdout);
						if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
						printf("\n info3 is.:[%s]\n", info3);fflush(stdout);
					}

					if(tc_strcmp(ProjectClass,"PRD")==0)
					{
						if((tc_strstr(info1,ProjectID)!=NULL) || (tc_strstr(info2,ProjectID)!=NULL))
						{
							PRDFlag=1;
							printf("\n MT:.PRD project of CVBU found: %d",PRDFlag); fflush(stdout);
						}
						else
						{
							PRDFlag=0;
							printf("\n MT:.No project CVBU found: %d",PRDFlag); fflush(stdout);
						}
					}
					else
					{
						PRDFlag=1;
						printf("\n MT:.No PRD project: %d",PRDFlag); fflush(stdout);
					}
					if (PRDFlag >0)
					{
						//############################### REMOVE PARTICIPALNTS START################################/
						if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
						if (dml_CRB_rel_type!=NULLTAG)
						{
							printf("\n MT:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
							if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
							printf("\n MT: DmlCRB count: %d",CRBcount);fflush(stdout);	
							jk=0;
							for (jk=0;jk<CRBcount ;jk++ )
							{	
								//printf("\n MT:jk: %d.\n",jk);fflush(stdout);
								DmlCRBTag = DmlCRB[jk];
								if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
								if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
								printf("\n MT:DML: Participants Name: %s", type_name7);fflush(stdout);

								if (tc_strcmp(type_name7,"T5_VIReviewer")==0)
								{
									if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
									printf("\n MT:Removing VI Reviewer: [%s] ",DMLReviewr);fflush(stdout);
									AOM_lock(objTag);
									if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
									AOM_save_without_extensions(objTag);
									AOM_unlock(objTag);
								}
							}
						}
						printf("\n MT:START ASSIGNING REVIEWERS: DML: [%s] Type: [%s] PltFrm :[%s] Proj_BU:[%s]", DMLNo,DMLType,Proj_PltFrm,Proj_BU);fflush(stdout);

						//VI Reviewer for SVR only.
						printf("\n MT:PCBU: Setting VI Analyst...");fflush(stdout);
						if(SA_find_group(groupName, &VIGrp_tag)!=ITK_ok)PrintErrorStack();
						if(SA_find_role2(VIAnalyst_role,&VIAnalyst_tag)!=ITK_ok)PrintErrorStack();
						if(SA_find_groupmember_by_role(VIAnalyst_tag,VIGrp_tag,&No_VIAna,&VIAna)!=ITK_ok)PrintErrorStack();
						printf("\n MT:PCBU:No_VIAna :[%d]",No_VIAna);  fflush(stdout);
						if(No_VIAna>0)
						{
							iii=0;
							for(iii=0;iii<No_VIAna;iii++)
							{	
								printf("\n MT:PCBU: VI Reviewer no [%d]",iii);fflush(stdout);
								if(EPM_get_participanttype ("T5_VIReviewer",&VIAna_Patri_Type)!=ITK_ok)PrintErrorStack();
								if(EPM_create_participant(VIAna[iii],VIAna_Patri_Type,&VIAna_Party)!=ITK_ok)PrintErrorStack();
								AOM_lock(objTag);			
								if(PARTICIPANT_add_participant(objTag,hasbypass,VIAna_Party)!=ITK_ok)PrintErrorStack();
								AOM_save_without_extensions(objTag);
								AOM_unlock(objTag);
							}
						}
						AOM_refresh ( objTag,TRUE);
						MEM_free(VIAna);

						//################# REVIEWERS FOR TASK START #####################/
						printf("\n MT:PVBU:TASK:REMOVING REVIEWERS FOR TASK START......\n");fflush(stdout);
						if(GRM_find_relation_type("T5_DMLTaskRelation", &DmlTask_tag)!=ITK_ok)PrintErrorStack();
						if (DmlTask_tag!=NULLTAG)
						{		
							if(GRM_list_secondary_objects_only(objTag,DmlTask_tag,&Tskcout,&TskRev_tag)!=ITK_ok)PrintErrorStack();
							printf("\n MT:TASK:TskRev_tag Tskcout : %d",Tskcout);fflush(stdout);
							jkk=0;
							for (jkk=0;jkk<Tskcout ;jkk++ )
							{
								if(ITEM_rev_sequence_is_latest(TskRev_tag[jkk],&is_Tskletst)!=ITK_ok)PrintErrorStack();
								//printf("\n MT:.is_Tskletst. %d",is_Tskletst);fflush(stdout);
								if(is_Tskletst != true)
								{
									printf("\n MT:TASK:is_Tskletst is not true .....\n");fflush(stdout);
								}
								else
								{	
									TskRev_tg = TskRev_tag[jkk];
									if(GRM_find_relation_type("HasParticipant", &Tsk_CRB_rel_type)!=ITK_ok)PrintErrorStack();
									if (Tsk_CRB_rel_type!=NULLTAG)
									{
										if(GRM_list_secondary_objects_only(TskRev_tg,Tsk_CRB_rel_type,&CRBcunt,&TskCRB)!=ITK_ok)PrintErrorStack();
										printf("\n MT:TASK: count: %d",CRBcunt);fflush(stdout);	
										jtsk=0;
										for (jtsk=0;jtsk<CRBcunt ;jtsk++ )
										{	
											TskCRBTag = TskCRB[jtsk];
											if(TCTYPE_ask_object_type(TskCRBTag,&ObjTypTskCRB));
											if(TCTYPE_ask_name2(ObjTypTskCRB,&type_name8));
											printf("\n MT:TASK: Participant Name: %s\n", type_name8);fflush(stdout);
											if ((tc_strcmp(type_name8,"T5_BIWReviewer")==0)||(tc_strcmp(type_name8,"T5_PTReviewer")==0)||(tc_strcmp(type_name8,"T5_EEReviewer")==0)||
												(tc_strcmp(type_name8,"T5_CHReviewer")==0)||(tc_strcmp(type_name8,"T5_TRIMReviewer")==0))
											{
												printf("\n MT:TASK:: Removing "); fflush(stdout);
												if(AOM_UIF_ask_value(TskCRBTag,"fnd0AssigneeUser",&TskReviewr)!=ITK_ok)PrintErrorStack();
												printf(" reviewer: [%s]\n",TskReviewr);fflush(stdout);
												AOM_lock(TskRev_tg);
												if(PARTICIPANT_remove_participant(TskRev_tg,TskCRBTag) !=ITK_ok)PrintErrorStack();
												AOM_save_without_extensions(TskRev_tg);
												AOM_unlock(TskRev_tg);
											}
										}
									}
								}
							}

							printf("\n MT:PVBU:ADDING REVIEWERS FOR TASK START......\n");fflush(stdout);
							t=0;
							for (t=0;t<Tskcout ;t++ )
							{ 
								if(ITEM_rev_sequence_is_latest(TskRev_tag[t],&is_Tsklatst)!=ITK_ok)PrintErrorStack();
								if(is_Tsklatst != true)
								{
									printf("\n MT:is_Tsklatst is not true .....\n");fflush(stdout);
								}
								else
								{	
									TskRev_t = TskRev_tag[t];
									if(POM_class_of_instance(TskRev_t,&TskCls_t)!=ITK_ok)PrintErrorStack();
									if(POM_name_of_class(TskCls_t,&Tsk_class)!=ITK_ok)PrintErrorStack();
									printf("\n MT: Task class..:%s",Tsk_class); fflush(stdout);
									if(tc_strcmp(Tsk_class,"T5_ChangeTaskRevision")==0)
									{
										//Setting DMU Reviewers.
										if(AOM_UIF_ask_value(TskRev_t,"item_id",&Task_name)!=ITK_ok)PrintErrorStack();
										printf("\n MT: Task Name :[%s]",Task_name);fflush(stdout);
										//SVR COC REVIEWER...
										No_SVRcoc=0;
										No_SVRc=0;
										No_SVRe=0;
										No_SVRp=0;
										No_SVRt=0;
										//get Project access check:
										if(tc_strstr(info3,"SVRCOC")==NULL)
										{
											if (PROJ_find(ProjectID,&projTag) !=ITK_ok)PrintErrorStack();
											if(projTag !=NULLTAG)
											{
												Gmcnt1=0;
												Gmcnt2=0;
												Gmcnt3=0;
												GmFound1 =NULLTAG;
												GmFound2 =NULLTAG;
												GmFound3 =NULLTAG;
												printf("\n DML:Getting Project Team...\n");fflush(stdout);
												if (PROJ_ask_team(projTag,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();
												printf("\n DML:Gmcnt1 %d \n",Gmcnt1);fflush(stdout);
											}
										}
										//BIW Reviewer.
										if(SA_find_group(groupName, &SVRcocGrp_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_role2(BIW_SVRCoC_role,&SVRcoc_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_groupmember_by_role(SVRcoc_tag,SVRcocGrp_tag,&No_SVRcoc,&SVRcoc_t)!=ITK_ok)PrintErrorStack();
										if(No_SVRcoc>0)
										{
											for(b=0;b<No_SVRcoc;b++)
											{	
												printf("\n MT: BIW_SVRCoC_role: %d",b);fflush(stdout);
												AccesFound=0;
												if(tc_strstr(info3,"SVRCOC")==NULL)
												{
													sUserId=NULL;
													if(SA_ask_groupmember_user(SVRcoc_t[b],&tUserTag)!=ITK_ok)   PrintErrorStack();
													if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
													printf("\n MT: sUserId: %s",sUserId);fflush(stdout);
													jkl=0;
													for(jkl=0;jkl<Gmcnt1;jkl++)
													{
														AccesFound=0;
														GrpMembName=NULL;
														GrpTag = GmFound1[jkl];
														if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
														printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
														if(GrpMembName)
														{
															if((tc_strstr(GrpMembName,"BIW_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
															{
																printf("\n Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																printf("\n DML:BIW_COC_Reviewer access avail...\n");fflush(stdout);
																AccesFound=1;
																break;
															}
														}
													}
												}
												else
												{
													printf("\n MT: BIW_SVRCoC_role.");fflush(stdout);
													if(EPM_get_participanttype ("T5_BIWReviewer",&SVRcoc_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(SVRcoc_t[b],SVRcoc_Patri_Type,&SVRcoc_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRcoc_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
												if(AccesFound >0)
												{
													printf("\n MT: BIW_SVRCoC_role assigned:%s",sUserId);fflush(stdout);
													if(EPM_get_participanttype ("T5_BIWReviewer",&SVRcoc_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(SVRcoc_t[b],SVRcoc_Patri_Type,&SVRcoc_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRcoc_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
											}
											AOM_refresh ( TskRev_t,TRUE);
											MEM_free(SVRcoc_t);
										}
										//TRIM Reviewer
										if(SA_find_group(groupName, &SVRtGrp_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_role2(Trim_SVRCoC_role,&SVRt_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_groupmember_by_role(SVRt_tag,SVRtGrp_tag,&No_SVRt,&SVRt_t)!=ITK_ok)PrintErrorStack();
										if(No_SVRt>0)
										{
											for(tr=0;tr<No_SVRt;tr++)
											{	
												printf("\n MT: TRIM reviewer no: %d",tr);fflush(stdout);
												AccesFound=0;
												if(tc_strstr(info3,"SVRCOC")==NULL)
												{
													sUserId=NULL;
													if(SA_ask_groupmember_user(SVRt_t[tr],&tUserTag)!=ITK_ok)   PrintErrorStack();
													if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
													printf("\n MT: sUserId: %s",sUserId);fflush(stdout);
													jkl=0;
													for(jkl=0;jkl<Gmcnt1;jkl++)
													{
														AccesFound=0;
														GrpMembName=NULL;
														GrpTag = GmFound1[jkl];
														if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
														printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
														if(GrpMembName)
														{
															if((tc_strstr(GrpMembName,"Trim_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
															{
																printf("\n Actual Group Member:[%s]\n", GrpMembName);fflush(stdout);
																printf("\n DML:Trim_COC_Reviewer access avail...\n");fflush(stdout);
																AccesFound=1;
																break;
															}
														}
													}
												}
												else
												{
													printf("\n MT: TRIM reviewer.");fflush(stdout);
													if(EPM_get_participanttype ("T5_TRIMReviewer",&SVRt_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(SVRt_t[tr],SVRt_Patri_Type,&SVRt_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRt_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
												if (AccesFound >0)
												{
													printf("\n MT: TRIM reviewer assigned:%s",sUserId);fflush(stdout);
													if(EPM_get_participanttype ("T5_TRIMReviewer",&SVRt_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(SVRt_t[tr],SVRt_Patri_Type,&SVRt_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRt_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);

												}
											}
											AOM_refresh (TskRev_t,TRUE);
											MEM_free(SVRt_t);
										}
										//CHASSIS SVR ROLE
										if(SA_find_group(groupName, &SVRcGrp_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_role2(CH_SVRCoC_role,&SVRc_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_groupmember_by_role(SVRc_tag,SVRcGrp_tag,&No_SVRc,&SVRc_t)!=ITK_ok)PrintErrorStack();
										if(No_SVRc>0)
										{
											for(c=0;c<No_SVRc;c++)
											{	
												printf("\n MT: CH reviewer no: %d",c);fflush(stdout);
												AccesFound=0;
												if(tc_strstr(info3,"SVRCOC")==NULL)
												{
													sUserId=NULL;
													if(SA_ask_groupmember_user(SVRc_t[c],&tUserTag)!=ITK_ok)   PrintErrorStack();
													if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
													printf("\n MT: sUserId: %s",sUserId);fflush(stdout);
													jkl=0;
													for(jkl=0;jkl<Gmcnt1;jkl++)
													{
														AccesFound=0;
														GrpMembName=NULL;
														GrpTag = GmFound1[jkl];
														if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
														printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
														if(GrpMembName)
														{
															if((tc_strstr(GrpMembName,"Chassis_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
															{
																printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																printf("\n DML:Chassis_COC_Reviewer access avail...\n");fflush(stdout);
																AccesFound=1;
																break;
															}
														}
													}
												}
												else
												{
													printf("\n MT: CHS reviewer assigned.");fflush(stdout);
													if(EPM_get_participanttype ("T5_CHReviewer",&SVRc_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(SVRc_t[c],SVRc_Patri_Type,&SVRc_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRc_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
												if (AccesFound >0)
												{
													printf("\n MT: CHS reviewer assigned:%s",sUserId);fflush(stdout);
													if(EPM_get_participanttype ("T5_CHReviewer",&SVRc_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(SVRc_t[c],SVRc_Patri_Type,&SVRc_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRc_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
											}
											AOM_refresh (TskRev_t,TRUE);
											MEM_free(SVRc_t);
										}
										//EE COC reviewer
										if(SA_find_group(groupName, &SVReGrp_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_role2(EE_SVRCoC_role,&SVRe_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_groupmember_by_role(SVRe_tag,SVReGrp_tag,&No_SVRe,&SVRe_t)!=ITK_ok)PrintErrorStack();
										if(No_SVRe>0)
										{
											for(e=0;e<No_SVRe;e++)
											{	
												printf("\n MT: peer reviewer no: %d",e);fflush(stdout);
												AccesFound=0;
												if(tc_strstr(info3,"SVRCOC")==NULL)
												{
													sUserId=NULL;
													if(SA_ask_groupmember_user(SVRe_t[e],&tUserTag)!=ITK_ok)   PrintErrorStack();
													if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
													printf("\n MT: sUserId: %s",sUserId);fflush(stdout);
													jkl=0;
													for(jkl=0;jkl<Gmcnt1;jkl++)
													{
														AccesFound=0;
														GrpMembName=NULL;
														GrpTag = GmFound1[jkl];
														if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
														printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
														if(GrpMembName)
														{
															if((tc_strstr(GrpMembName,"EE_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
															{
																printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																printf("\n DML:EE_COC_Reviewer access avail...\n");fflush(stdout);
																AccesFound=1;
																break;
															}
														}
													}
												}
												else
												{
													if(EPM_get_participanttype ("T5_EEReviewer",&SVRe_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(SVRe_t[e],SVRe_Patri_Type,&SVRe_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRe_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
												if (AccesFound >0)
												{
													printf("\n EE reviewer assigned: %s",sUserId);fflush(stdout);
													if(EPM_get_participanttype ("T5_EEReviewer",&SVRe_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(SVRe_t[e],SVRe_Patri_Type,&SVRe_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRe_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
											}
											AOM_refresh (TskRev_t,TRUE);
											MEM_free(SVRe_t);
										}
										//Powertrain reviewer
										if(SA_find_group(groupName, &SVRpGrp_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_role2(PT_SVRCoC_role,&SVRp_tag)!=ITK_ok)PrintErrorStack();
										if(SA_find_groupmember_by_role(SVRp_tag,SVRpGrp_tag,&No_SVRp,&SVRp_t)!=ITK_ok)PrintErrorStack();
										if(No_SVRp>0)
										{
											for(p=0;p<No_SVRp;p++)
											{	
												printf("\n MT: PT_SVRCoC reviewer no: %d",p);fflush(stdout);
												AccesFound=0;
												if(tc_strstr(info3,"SVRCOC")==NULL)
												{
													sUserId=NULL;
													if(SA_ask_groupmember_user(SVRp_t[p],&tUserTag)!=ITK_ok)   PrintErrorStack();
													if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
													printf("\n MT: sUserId: %s",sUserId);fflush(stdout);
													jkl=0;
													for(jkl=0;jkl<Gmcnt1;jkl++)
													{
														AccesFound=0;
														GrpMembName=NULL;
														GrpTag = GmFound1[jkl];
														if (AOM_ask_value_string(GrpTag,"object_name",&GrpMembName)!=ITK_ok)   PrintErrorStack();
														printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
														if(GrpMembName)
														{
															if((tc_strstr(GrpMembName,"Powertrain_COC_Reviewer")!=NULL)&& (tc_strstr(GrpMembName,sUserId)!=NULL))
															{
																printf("\n Actual Group Member name:[%s]\n", GrpMembName);fflush(stdout);
																printf("\n DML:Powertrain_COC_Reviewer access avail...\n");fflush(stdout);
																AccesFound=1;
																break;
															}
														}
													}
												}
												else
												{
													printf("\n POWRTRN reviewer assigned");fflush(stdout);
													if(EPM_get_participanttype ("T5_PTReviewer",&SVRp_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(SVRp_t[p],SVRp_Patri_Type,&SVRp_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRp_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
												if (AccesFound >0)
												{
													printf("\n POWRTRN reviewer assigned: %s",sUserId);fflush(stdout);
													if(EPM_get_participanttype ("T5_PTReviewer",&SVRp_Patri_Type)!=ITK_ok)PrintErrorStack();
													if(EPM_create_participant(SVRp_t[p],SVRp_Patri_Type,&SVRp_Party)!=ITK_ok)PrintErrorStack();
													AOM_lock(TskRev_t);			
													if(PARTICIPANT_add_participant(TskRev_t,hasbypass,SVRp_Party)!=ITK_ok)PrintErrorStack();	
													AOM_save_without_extensions(TskRev_t);
													AOM_unlock(TskRev_t);
												}
											}
											AOM_refresh (TskRev_t,TRUE);
											MEM_free(SVRp_t);
										}
									}
								}
							}
						}	
					}
				}
				else
				{
					printf("\n NO PROJECT AVAILABLE..\n");fflush(stdout);
				}
			}
			else
			{
				PRDFlag=0;
				printf("\n MT: No project found: %d",PRDFlag); fflush(stdout);
			}
		}
		
	}
	printf("\n ....................SVR COC assignment done.\n");fflush(stdout);
	return error_code;
}

/******************************************************************************************
*   Function name			:	Assign_MDM_Review_Func
*   Action Handler Name		:	Assign_MDM_Review
*   Description				:	This function used to set MDM COC Reviewer to DML Revision
								according to project code access.
*
*	Date				Modified By				Modification Notes
*	05/04/2018			Kalpesh Gondhali		1.45: Assign MDM reviewer
******************************************************************************************/

int Assign_MDM_Review_Func(EPM_action_message_t msg)
{
	int						error_code							= ITK_ok;
	int						CE_VI								= 0;
	int						X4									= 0;
	int						MDM									= 0;
	int						resultCount							= 0;
	int						no_attach							= 0;
	int						rsltCount							= 0;
	int						CRBcount							= 0;
	int						AccesFound							= 0;
	int						count_CE_VI							= 0;
	int						count_X4							= 0;
	int						count_MDM							= 0;
	int						Gmcnt1								= 0;
	int						Gmcnt2								= 0;
	int						Gmcnt3								= 0;
	int						jk									= 0;
	int						jkl									= 0;
	int						MDM_APL								= 0;
	int						count_MDM_APL						= 0;

	tag_t					roottask							= NULLTAG;	
	tag_t					objTag								= NULLTAG;
	tag_t					objTypTag							= NULLTAG;
	tag_t					queryTag_project					= NULLTAG;
	tag_t					qryTag_cntrl_obj					= NULLTAG;
	tag_t					Project_t							= NULLTAG;
	tag_t					DmlCRBTag							= NULLTAG;
	tag_t					CE_VI_Parti_Type					= NULLTAG;
	tag_t					MDM_APL_Parti_Type					= NULLTAG;
	tag_t					X4_Parti_Type						= NULLTAG;
	tag_t					MDM_Parti_Type						= NULLTAG;
	tag_t					proj_member							= NULLTAG;
	tag_t					CE_VI_role_tag						= NULLTAG;
	tag_t					MDM_APL_role_tag					= NULLTAG;
	tag_t					MDM_X4_role_tag						= NULLTAG;
	tag_t					MDM_role_tag						= NULLTAG;
	tag_t					CE_VI_Party							= NULLTAG;
	tag_t					MDM_APL_Party						= NULLTAG;
	tag_t					X4_Party							= NULLTAG;
	tag_t					MDM_Party							= NULLTAG;
	tag_t					Group_tag							= NULLTAG;
	tag_t					projTag								= NULLTAG;
	tag_t					tUserTag							= NULLTAG;
	tag_t					dml_CRB_rel_type					= NULLTAG;
	tag_t					ObjTypDmlCRB						= NULLTAG;

	tag_t					*DmlCRB								= NULL;
	tag_t					*attachment							= NULL;
	tag_t					*t5_Project							= NULL;
	tag_t					*CntrlObjectTag						= NULL;
	tag_t					*CE_VI_members						= NULL;
	tag_t					*MDM_APL_members						= NULL;
	tag_t					*X4_members							= NULL;
	tag_t					*MDM_members						= NULL;
	tag_t					*GmFound1							= NULL;   
	tag_t					*GmFound2							= NULL;   
	tag_t					*GmFound3							= NULL;

	char					*DMLType							= NULL;
	char					*DMLNo								= NULL;
	char					*ProjectID							= NULL;
	char					*sUserId							= NULL;   
	char					*proj_MembName						= NULL;
	char					*DMLReviewr							= NULL;
	char					groupName[50];

	char*					ObjTyp=NULL;
	char*					type_name7=NULL;

	const char*				MDM_CE_VI_role						= "MDM_CE_VI_Reviewer";
	const char*				MDM_MDM_APL_role					= "MDM_APL_REVIEWER";
	const char*				MDM_X4_role							= "MDM_X4_Reviewer";
	const char*				MDM_MDM_role						= "MDM_MDM_Reviewer";
	logical hasbypass =true;

	printf("\nMDM COC Reviewer assignment started...!!");fflush(stdout);
	
	// To get the Task Number from workflow...!!
	if(EPM_ask_root_task(msg.task, &roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask, EPM_target_attachment,&no_attach, &attachment)!=ITK_ok)PrintErrorStack();
	printf("\nNo of Attachements:[%d]", no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0], "item_id", &DMLNo)!=ITK_ok)PrintErrorStack();
	printf("\nDML/Task Number: [%s]", DMLNo);fflush(stdout);

	if(TCTYPE_ask_object_type(objTag, &objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\nObject type: [%s]\n", ObjTyp);fflush(stdout);

	tc_strcpy(groupName,"DML_Participants_Group");
	printf("\nGroup Name:%s\n", groupName);   fflush(stdout);

	if(tc_strcmp(ObjTyp, "ChangeRequestRevision")==0)
	{
		if(AOM_ask_value_string(attachment[0], "t5_rlstype", &DMLType)!=ITK_ok)PrintErrorStack();
		printf("\nDML Number:[%s] and DMLType:[%s]", DMLNo, DMLType);fflush(stdout);

		if(AOM_ask_value_string(attachment[0], "t5_cprojectcode", &ProjectID)!=ITK_ok)PrintErrorStack();
		printf("\nProjectID:%s", ProjectID);fflush(stdout);


		//**************************REMOVE PARTICIPALNTS START****************************//
		if(GRM_find_relation_type("HasParticipant", &dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
		if (dml_CRB_rel_type != NULLTAG)
		{
			printf("\nREMOVE PARTICIPALNTS START...!!\n");fflush(stdout);
			if(GRM_list_secondary_objects_only(objTag, dml_CRB_rel_type, &CRBcount, &DmlCRB)!=ITK_ok)PrintErrorStack();
			printf("\nDmlCRB count: %d", CRBcount);fflush(stdout);	
			jk=0;
			for (jk=0; jk<CRBcount; jk++)
			{	
				//printf("\n jk: %d.\n",jk);fflush(stdout);
				DmlCRBTag = DmlCRB[jk];
				if(TCTYPE_ask_object_type(DmlCRBTag, &ObjTypDmlCRB));
				if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
				printf("\nDML:Participants Name:%s", type_name7);fflush(stdout);

				if (tc_strcmp(type_name7,"T5_MDM_CE_VI_Reviewer")==0)
				{
					if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
					printf("\nRemoving MDM CE VI Reviewer:[%s] ",DMLReviewr);fflush(stdout);
					AOM_lock(objTag);
					if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
					AOM_save_without_extensions(objTag);
					AOM_unlock(objTag);
				}
				if (tc_strcmp(type_name7,"T5_MDM_X4_Reviewer")==0)
				{
					if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
					printf("\n Removing MDM_X4 Reviewer:[%s] ",DMLReviewr);fflush(stdout);
					AOM_lock(objTag);
					if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
					AOM_save_without_extensions(objTag);
					AOM_unlock(objTag);
				}
				if (tc_strcmp(type_name7,"T5_MDM_MDM_Reviewer")==0)
				{
					if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
					printf("\n Removing MDM VI Reviewer:[%s] ",DMLReviewr);fflush(stdout);
					AOM_lock(objTag);
					if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
					AOM_save_without_extensions(objTag);
					AOM_unlock(objTag);
				}
				//PSS918119
				if (tc_strcmp(type_name7,"T5_MDM_APL_Reviewer")==0)
				{
					if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
					printf("\n Removing MDM VI Reviewer:[%s] ",DMLReviewr);fflush(stdout);
					AOM_lock(objTag);
					if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
					AOM_save_without_extensions(objTag);
					AOM_unlock(objTag);
				}
			}
		}//End of removing participants.
		
		if (PROJ_find(ProjectID,&projTag) !=ITK_ok)PrintErrorStack();
		if(projTag != NULLTAG)
		{
			printf("\nDML:Getting Project Team...\n");fflush(stdout);
			if (PROJ_ask_team(projTag,&Gmcnt1,&GmFound1,&Gmcnt2,&GmFound2,&Gmcnt3,&GmFound3)!=ITK_ok) PrintErrorStack();
			printf("\nDML:Gmcnt1 %d \n",Gmcnt1);fflush(stdout);
		}

		//T5_MDM_CE_VI_Reviewer for MDM only.
		printf("\nSetting CE_VI_Reviewer...!!");fflush(stdout);
		if(SA_find_group(groupName,&Group_tag) != ITK_ok)PrintErrorStack();
		if(SA_find_role2(MDM_CE_VI_role,&CE_VI_role_tag) != ITK_ok)PrintErrorStack();
		if(SA_find_groupmember_by_role(CE_VI_role_tag,Group_tag,&count_CE_VI,&CE_VI_members)!=ITK_ok)PrintErrorStack();
		printf("\nTotal [%d] CE_VI Members found...!!",count_CE_VI);  fflush(stdout);
		if(count_CE_VI > 0)
		{
			for(CE_VI=0; CE_VI < count_CE_VI; CE_VI++)
			{	
				if(SA_ask_groupmember_user(CE_VI_members[CE_VI],&tUserTag)!=ITK_ok)   PrintErrorStack();
				if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)PrintErrorStack();
				printf("\nsUserId: %s",sUserId);fflush(stdout);
				for(jkl=0;jkl<Gmcnt1;jkl++)
				{
					AccesFound = 0;
					proj_member = GmFound1[jkl];
					if(AOM_ask_value_string(proj_member,"object_name",&proj_MembName)!=ITK_ok)   PrintErrorStack();
					printf("\n Actual Group Member name:[%s]\n",proj_MembName);fflush(stdout);
					if(tc_strcmp(proj_MembName,"")!=0  || (tc_strlen(proj_MembName) > 0))
					{
						if((tc_strstr(proj_MembName,"MDM_CE_VI_Reviewer") != NULL) && (tc_strstr(proj_MembName,sUserId)!=NULL))
						{
							printf("\nActual Group Member:[%s]\n",proj_MembName);fflush(stdout);
							printf("\nMDM_CE_VI_Reviewer access Avail...!!\n");fflush(stdout);
							AccesFound=1;
							break;
						}
					}
				}
				if(AccesFound > 0)
				{
					printf("\nCE_VI Reviewer no.[%d]",CE_VI);fflush(stdout);
					if(EPM_get_participanttype("T5_MDM_CE_VI_Reviewer",&CE_VI_Parti_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(CE_VI_members[CE_VI],CE_VI_Parti_Type,&CE_VI_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(objTag);			
					if(PARTICIPANT_add_participant(objTag,hasbypass,CE_VI_Party)!=ITK_ok)PrintErrorStack();
					AOM_save_without_extensions(objTag);
					AOM_unlock(objTag);
				}
			}
			AOM_refresh (objTag,TRUE);
			MEM_free(CE_VI_members);
		}

		//T5_MDM_X4_Reviewer for MDM only.
		printf("\nSetting X4_Reviewer...!!");fflush(stdout);
		if(SA_find_group(groupName,&Group_tag) != ITK_ok)PrintErrorStack();
		if(SA_find_role2(MDM_X4_role,&MDM_X4_role_tag) != ITK_ok)PrintErrorStack();
		if(SA_find_groupmember_by_role(MDM_X4_role_tag,Group_tag,&count_X4,&X4_members)!=ITK_ok)PrintErrorStack();
		printf("\nTotal [%d] X4_Members found...!!",count_X4);  fflush(stdout);
		if(count_X4 > 0)
		{
			for(X4=0; X4 < count_X4; X4++)
			{	
				if(SA_ask_groupmember_user(X4_members[X4],&tUserTag)!=ITK_ok)   PrintErrorStack();
				if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
				printf("\nsUserId: %s",sUserId);fflush(stdout);
				for(jkl=0;jkl<Gmcnt1;jkl++)
				{
					AccesFound = 0;
					proj_member = GmFound1[jkl];
					if(AOM_ask_value_string(proj_member,"object_name",&proj_MembName)!=ITK_ok)   PrintErrorStack();
					printf("\n Actual Group Member name:[%s]\n",proj_MembName);fflush(stdout);
					if(tc_strcmp(proj_MembName,"")!=0  || (tc_strlen(proj_MembName) > 0))
					{
						if((tc_strstr(proj_MembName,"MDM_X4_Reviewer") != NULL) && (tc_strstr(proj_MembName,sUserId)!=NULL))
						{
							printf("\nActual Group Member:[%s]\n",proj_MembName);fflush(stdout);
							printf("\nMDM_X4_Reviewer access Avail...!!\n");fflush(stdout);
							AccesFound=1;
							break;
						}
					}
				}			
				if(AccesFound > 0)
				{
					printf("\nVI Reviewer no [%d]",X4);fflush(stdout);
					if(EPM_get_participanttype("T5_MDM_X4_Reviewer",&X4_Parti_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(X4_members[X4],X4_Parti_Type,&X4_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(objTag);			
					if(PARTICIPANT_add_participant(objTag,hasbypass,X4_Party)!=ITK_ok)PrintErrorStack();
					AOM_save_without_extensions(objTag);
					AOM_unlock(objTag);
				}
			}
			AOM_refresh (objTag,TRUE);
			MEM_free(X4_members);
		}

		//T5_MDM_MDM_Reviewer for MDM only.
		printf("\nSetting MDM_Reviewer...!!");fflush(stdout);
		if(SA_find_group(groupName,&Group_tag) != ITK_ok)PrintErrorStack();
		if(SA_find_role2(MDM_MDM_role,&MDM_role_tag) != ITK_ok)PrintErrorStack();
		if(SA_find_groupmember_by_role(MDM_role_tag,Group_tag,&count_MDM,&MDM_members)!=ITK_ok)PrintErrorStack();
		printf("\nTotal [%d] MDM Members found...!!",count_MDM);  fflush(stdout);
		if(count_MDM > 0)
		{
			for(MDM=0; MDM < count_MDM; MDM++)
			{	
				if(SA_ask_groupmember_user(MDM_members[MDM],&tUserTag)!=ITK_ok)   PrintErrorStack();
				if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)   PrintErrorStack();
				printf("\nsUserId: %s",sUserId);fflush(stdout);
				for(jkl=0;jkl<Gmcnt1;jkl++)
				{
					AccesFound = 0;
					proj_member = GmFound1[jkl];
					if(AOM_ask_value_string(proj_member,"object_name",&proj_MembName)!=ITK_ok)   PrintErrorStack();
					printf("\n Actual Group Member name:[%s]\n",proj_MembName);fflush(stdout);
					if(tc_strcmp(proj_MembName,"")!=0  || (tc_strlen(proj_MembName) > 0))
					{
						if((tc_strstr(proj_MembName,"MDM_MDM_Reviewer") != NULL) && (tc_strstr(proj_MembName,sUserId)!=NULL))
						{
							printf("\nActual Group Member:[%s]\n",proj_MembName);fflush(stdout);
							printf("\nMDM_MDM_Reviewer access Avail...!!\n");fflush(stdout);
							AccesFound=1;
							break;
						}
					}
				}			
				if(AccesFound > 0)
				{
					printf("\nVI Reviewer no [%d]",MDM);fflush(stdout);
					if(EPM_get_participanttype("T5_MDM_MDM_Reviewer",&MDM_Parti_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(MDM_members[MDM],MDM_Parti_Type,&MDM_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(objTag);			
					if(PARTICIPANT_add_participant(objTag,hasbypass,MDM_Party)!=ITK_ok)PrintErrorStack();
					AOM_save_without_extensions(objTag);
					AOM_unlock(objTag);
				}
			}
			AOM_refresh (objTag,TRUE);
			MEM_free(MDM_members);
		}
		//T5_MDM_APL_Reviewer for MDM only. PSS918119
		printf("\nSetting MDM_APL_Reviewer...!!");fflush(stdout);
		if(SA_find_group(groupName,&Group_tag) != ITK_ok)PrintErrorStack();
		if(SA_find_role2(MDM_MDM_APL_role,&MDM_APL_role_tag) != ITK_ok)PrintErrorStack();
		if(SA_find_groupmember_by_role(MDM_APL_role_tag,Group_tag,&count_MDM_APL,&MDM_APL_members)!=ITK_ok)PrintErrorStack();
		printf("\nTotal [%d] MDM_APL Members found...!!",count_MDM_APL);  fflush(stdout);
		if(count_MDM_APL > 0)
		{
			for(MDM_APL=0; MDM_APL < count_CE_VI; MDM_APL++)
			{	
				if(SA_ask_groupmember_user(MDM_APL_members[MDM_APL],&tUserTag)!=ITK_ok)   PrintErrorStack();
				if(SA_ask_user_identifier2(tUserTag,&sUserId)!=ITK_ok)PrintErrorStack();
				printf("\nsUserId: %s",sUserId);fflush(stdout);
				for(jkl=0;jkl<Gmcnt1;jkl++)
				{
					AccesFound = 0;
					proj_member = GmFound1[jkl];
					if(AOM_ask_value_string(proj_member,"object_name",&proj_MembName)!=ITK_ok)   PrintErrorStack();
					printf("\n Actual Group Member name:[%s]\n",proj_MembName);fflush(stdout);
					if(tc_strcmp(proj_MembName,"")!=0  || (tc_strlen(proj_MembName) > 0))
					{
						if((tc_strstr(proj_MembName,"MDM_APL_REVIEWER") != NULL) && (tc_strstr(proj_MembName,sUserId)!=NULL))
						{
							printf("\nActual Group Member:[%s]\n",proj_MembName);fflush(stdout);
							printf("\nMDM_MDM_APL_Reviewer access Avail...!!\n");fflush(stdout);
							AccesFound=1;
							break;
						}
					}
				}
				if(AccesFound > 0)
				{
					printf("\nMDM_APL Reviewer no.[%d]",MDM_APL);fflush(stdout);
					if(EPM_get_participanttype("T5_MDM_APL_Reviewer",&MDM_APL_Parti_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(MDM_APL_members[MDM_APL],MDM_APL_Parti_Type,&MDM_APL_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(objTag);			
					if(PARTICIPANT_add_participant(objTag,hasbypass,MDM_APL_Party)!=ITK_ok)PrintErrorStack();
					AOM_save_without_extensions(objTag);
					AOM_unlock(objTag);
				}
			}
			AOM_refresh (objTag,TRUE);
			MEM_free(MDM_APL_members);
		}
	}
	printf("\n ....................MDM auto assignment done.\n");fflush(stdout);
	return error_code;
}

/******************************************************************************************
*   Function name			:	Assign_CE_Manager_Review_Func
*   Action Handler Name		:	Assign_CE_Manager_Review
*   Description				:	This function used to set Assign CE & Manager Review to DML
								according to project code access.
*
*	Date				Modified By				Modification Notes
*	18/03/2020			Sudhir		1.52: Assign CE & Manager Review
******************************************************************************************/
int Assign_CE_Manager_Review_Func(EPM_action_message_t msg)
{
	int error_code = ITK_ok;
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;
	char	*DMLNo			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=NULL;
	
	
	
	//Assign CE Reviewer On basis of Group Handle..
	char	*ProjectID		= NULL;
	char    **qry_values2     =  (char **) MEM_alloc(10 * sizeof(char *));
	char    **qry_values = (char **) MEM_alloc(10 * sizeof(char *));
	char	*qry_entries[1] = {"Name"};
	char*	ProjectClass			= NULL;
	char*	ProjDesc			= NULL;
	char*	Proj_PltFrm			= NULL;
	char*	Proj_BU			= NULL;
	char	*DMLReason		=  NULL;
	char	*DMLDrStat		=  NULL;
	char	*DMLDesignGrp		=  NULL;
	char	*DMLVertical		=  NULL;
	char	*DML_CE_Group		=  NULL;
	char	*DML_MGR_Group		=  NULL;
	char	*MgrAnalyst_role	= NULL;
	char	*info1	= NULL;
	char	*info2	= NULL;
	char	*info3	= NULL;
	char	*groupName	= NULL;
	char*	type_name7=NULL;
	const char*   CEAnalyst_role = "CE_Reviewer";

	tag_t	queryTag   = NULLTAG;
	tag_t   *t5_Project= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t   qryTag     = NULLTAG;
	tag_t	dml_vertical_qryTag		= NULLTAG;
	tag_t	*dml_vertical_CntrlObjectTag		= NULLTAG;
	tag_t   *CntrlObjectTag      = NULLTAG;
	tag_t   CEGrp_tag			= NULLTAG;
	tag_t   CEAnalyst_tag		= NULLTAG;
	tag_t*  CEAna				= NULLTAG;
	tag_t	CEAna_Patri_Type	= NULLTAG;
	tag_t	CEAna_Party		= NULLTAG;
	tag_t	dml_CRB_rel_type		= NULLTAG;

	char    *dml_vertical_qry_entry[1]  = {"SYSCD"};
	char    **dml_vertical_qry_values =  (char **) MEM_alloc(10 * sizeof(char *));
	char    *qry_entry[1]  = {"SYSCD"};
	int		n_entries = 1;
	int		n_entry = 1;
	int		resultCount = 0;
	int dml_vertical_rsltCount =0;
	int dml_vertical_n_entry =1;
	int num =0;
	int     ik = 0;
	int     No_CEAna = 0;
	int     rsltCount      =  0;
	tag_t   MgrGrp_tag     = NULLTAG;
	tag_t   MgrAnalyst_tag     = NULLTAG;
	tag_t   *MGRAna     = NULLTAG;
	tag_t   *DmlCRB     = NULLTAG;
	tag_t   DmlCRBTag     = NULLTAG;
	tag_t   ObjTypDmlCRB     = NULLTAG;

	tag_t	MGRAna_Patri_Type	= NULLTAG;
	tag_t	MGRAna_Party		= NULLTAG;
	int No_MGRAna =0;
	int     CRBcount	=  0;
	int     PRDFlag	=  0;
	int     jk	=  0;
	char	*ErcGroupName	= NULL;
	char	*DMLReviewr							= NULL;
	tag_t	Erc_group_tag	= NULLTAG;
	logical hasbypass =true;

	printf("\n Assign_CE_Manager_Review_Func start.......");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task,&roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask,EPM_target_attachment,&no_attach,&attachment)!=ITK_ok)PrintErrorStack();
	printf("\n Assign_CE_Manager_Review_Func:No of Attachements: [%d]",no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
	//if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
	printf("\n Assign_CE_Manager_Review_Func:DML/Task Number: [%s].",DMLNo);fflush(stdout);
	//t5_rlstype

	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\n Assign_CE_Manager_Review_Func: Workfow obj type: [%s]\n",ObjTyp);fflush(stdout);
	groupName = (char	*)MEM_alloc(100);
	tc_strcpy(groupName,"DML_Participants_Group");
	printf("\nGroup Name:%s\n",groupName);   fflush(stdout);

	if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
	{
		if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
		printf("\n Assign_CE_Manager_Review_Func:DML Number: [%s] DMLType: [%s]",DMLNo,DMLType);fflush(stdout);

		if(tc_strcmp(DMLType,"Veh")==0)
		{
			if(AOM_ask_value_string(attachment[0],"t5_cprojectcode",&ProjectID)!=ITK_ok)PrintErrorStack();
			printf("\n Assign_CE_Manager_Review_Func: ProjectID : %s",ProjectID);   fflush(stdout);

			//if(ITEM_find_item(ProjectID,&Project_t)!=ITK_ok)PrintErrorStack();
			if(ProjectID)
			{
				if(QRY_find2("Qury_Project",&queryTag));
				printf("\n Assign_CE_Manager_Review_Func:After Prd_Project: QRY_find2");fflush(stdout);
				if (queryTag)
				{
					printf("\n Assign_CE_Manager_Review_Func:Found Query");fflush(stdout);
				}
				else
				{
					printf("\n Assign_CE_Manager_Review_Func:Not Found Query");fflush(stdout);
				}

				qry_values[0] = ProjectID;

				if(QRY_execute(queryTag,n_entries,qry_entries,qry_values,&resultCount,&t5_Project));
				printf("\n Assign_CE_Manager_Review_Func: resultCount : %d\n",resultCount); fflush(stdout);

				if(resultCount > 0)
				{
					printf("\n Assign_CE_Manager_Review_Func:t5_Project = [%s] found in DB\n",ProjectID);fflush(stdout);
					Project_t = t5_Project[0];
					if (Project_t!=NULLTAG)
					{
						if(AOM_ask_value_string(Project_t,"t5_VehicleClass",&ProjectClass)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(Project_t,"object_desc",&ProjDesc)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(Project_t,"t5_Program",&Proj_PltFrm)!=ITK_ok)PrintErrorStack();
						if(AOM_ask_value_string(Project_t,"t5_BussUnitType",&Proj_BU)!=ITK_ok)PrintErrorStack();
						printf("\n Assign_CE_Manager_Review_Func: ProjectClass:[%s] ProjDesc : %s Proj_PltFrm :[%s] Proj_BU:[%s]\n",ProjectClass,ProjDesc,Proj_PltFrm,Proj_BU);   fflush(stdout);
						//Query control table for PRDtoCVBU workflow project list.
						printf("\n Assign_CE_Manager_Review_Func:.Checking PRD  to CVBU WF project...\n"); fflush(stdout);
						if(QRY_find2("ControlObjects",&qryTag));
						if (qryTag)
						{
							printf("\n PRDCVBU:Found Query ControlObjects \n");fflush(stdout);
						}
						else
						{
							printf("\n PRDCVBU:Not Found Query ControlObjects \n");fflush(stdout);
						}

						qry_values2[0] = "PRDCVBU";
						if(QRY_execute(qryTag,n_entry,qry_entry,qry_values2,&rsltCount,&CntrlObjectTag));
						printf(" \n PRDCVBU:rsltCount :%d:",rsltCount); fflush(stdout);
						if(rsltCount > 0)
						{
							if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo1",&info1)!=ITK_ok)   PrintErrorStack();
							printf("\n info1 is.:[%s]\n",info1);fflush(stdout);
							if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo2",&info2)!=ITK_ok)   PrintErrorStack();
							printf("\n info2 is.:[%s]\n",info2);fflush(stdout);
							if (AOM_ask_value_string(CntrlObjectTag[0],"t5_Userinfo3",&info3)!=ITK_ok)   PrintErrorStack();
							printf("\n info3 is.:[%s]\n",info3);fflush(stdout);
						}

						if(tc_strcmp(ProjectClass,"PRD")==0)
						{
							if((tc_strstr(info1,ProjectID)!=NULL) || (tc_strstr(info2,ProjectID)!=NULL))
							{
								PRDFlag=1;
								printf("\n Assign_CE_Manager_Review_Func:.PRD project of CVBU found: %d",PRDFlag); fflush(stdout);
							}
							else
							{
								PRDFlag=0;
								printf("\n Assign_CE_Manager_Review_Func:.No project CVBU found: %d",PRDFlag); fflush(stdout);
							}
						}
						else
						{
							PRDFlag=1;
							printf("\n Assign_CE_Manager_Review_Func:.No PRD project: %d",PRDFlag); fflush(stdout);
						}
						if (PRDFlag >0)
						{
							//**************************REMOVE PARTICIPALNTS START****************************//
							if(GRM_find_relation_type("HasParticipant",&dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
							if (dml_CRB_rel_type!=NULLTAG)
							{
								printf("\n Assign_CE_Manager_Review_Func:REMOVE PARTICIPALNTS START.. \n");fflush(stdout);
								if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
								printf("\n Assign_CE_Manager_Review_Func: DmlCRB count: %d",CRBcount);fflush(stdout);	
								for (jk=0;jk<CRBcount ;jk++ )
								{	
									//printf("\n MT:jk: %d.\n",jk);fflush(stdout);
									DmlCRBTag = DmlCRB[jk];
									if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
									if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
									printf("\n Assign_CE_Manager_Review_Func:DML: Participants Name: %s",type_name7);fflush(stdout);
									if(tc_strcmp(DMLType,"Veh")==0)
									{
										if ((tc_strcmp(type_name7,"T5_CEReviewer")==0))
										{
											if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
											printf("\n Assign_CE_Manager_Review_Func: Removing BOM/PP reviewer: [%s] ",DMLReviewr);fflush(stdout);
											AOM_lock(objTag);
											if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
											AOM_save_without_extensions(objTag);
											AOM_unlock(objTag);
										}
										if ((tc_strcmp(type_name7,"ChangeReviewBoard")==0))
										{
											if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
											printf("\n Assign_CE_Manager_Review_Func:Removing ChangeReviewBoard Reviewer: [%s] ",DMLReviewr);fflush(stdout);
											AOM_lock(objTag);
											if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
											AOM_save_without_extensions(objTag);
											AOM_unlock(objTag);
										}
									}
								}
							}
							printf("\n Assign_CE_Manager_Review_Func:START ASSIGNING REVIEWERS: DML: [%s] Type: [%s] PltFrm :[%s] Proj_BU:[%s]",DMLNo,DMLType,Proj_PltFrm,Proj_BU);fflush(stdout);
							if(tc_strcmp(Proj_BU,"CVBU")==0)
							{
								if((tc_strcmp(DMLType,"Veh")==0))
								{

										//CE Reviewer not for PCBU.
										printf("\n Assign_CE_Manager_Review_Func: Setting CE Reviewer...");fflush(stdout);
										if(AOM_ask_value_string(attachment[0],"t5_cDRstatus",&DMLDrStat)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(attachment[0],"t5_reason",&DMLReason)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string_at(attachment[0],"t5_crdesigngroup",0,&DMLDesignGrp)!=ITK_ok)PrintErrorStack();
										if(AOM_ask_value_string(attachment[0],"t5_ProductLine",&DMLVertical)!=ITK_ok)PrintErrorStack();
										printf("\n Assign_CE_Manager_Review_Func:DML DR STATUS: [%s] DMLType: [%s] DMLReason: [%s] DMLGroup: [%s] DMLVertical: [%s]",DMLDrStat,DMLType,DMLReason,DMLDesignGrp,DMLVertical);fflush(stdout);
										// To Add control Object .. DML_Vertical as SYSCD ,DML_Vertical ad SUBSYSCD

										if(QRY_find2("ControlObjects",&dml_vertical_qryTag));
										if (dml_vertical_qryTag)
										{
											printf("\n dml_vertical_qryTag:Found Query ControlObjects \n");fflush(stdout);
										}
										else
										{
											printf("\n dml_vertical_qryTag:Not Found Query ControlObjects \n");fflush(stdout);
										}

										dml_vertical_qry_values[0] = "DML_Vertical";
										if(QRY_execute(dml_vertical_qryTag,dml_vertical_n_entry,dml_vertical_qry_entry,dml_vertical_qry_values,&dml_vertical_rsltCount,&dml_vertical_CntrlObjectTag));
										printf(" \n DML_Vertical:rsltCount :%d:",dml_vertical_rsltCount); fflush(stdout);
										if(dml_vertical_rsltCount>0)
										{
											ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );
											tc_strcpy(ErcGroupName,"ERC_Designers_Group");
											if((tc_strcmp(DMLType,"Veh")==0) && tc_strlen(DMLVertical)>0)
											{
												if(tc_strcmp(DMLReason,"NR")==0)
												{
													if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0)
													{
														DML_CE_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_CE_Group,DMLVertical);
														tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
													}
													if(tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0 || tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0)
													{
														DML_CE_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_CE_Group,DMLVertical);
														tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
													}
													if(tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
													{
														DML_CE_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_CE_Group,DMLVertical);
														tc_strcat(DML_CE_Group,"_HeadVIG_Chf_Grp");
													}
												}
												else if(tc_strcmp(DMLReason,"DR")==0)
												{
													if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0 || tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0 || tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0)
													{
														DML_CE_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_CE_Group,DMLVertical);
														tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
													}
													if(tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
													{
														DML_CE_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_CE_Group,DMLVertical);
														tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
													}
												}
												else
												{
													if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0 || tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0)
													{
														DML_CE_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_CE_Group,DMLVertical);
														tc_strcat(DML_CE_Group,"_ProjMgr_Chf_Grp");
													}
													if(tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0 || tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
													{
														DML_CE_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_CE_Group,DMLVertical);
														tc_strcat(DML_CE_Group,"_FamChf_Chf_Grp");
													}
												}

												printf("\n DML_CE_Group  :[%s]",DML_CE_Group);  fflush(stdout);
												//if(SA_find_group(DML_CE_Group,&CEGrp_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_group(ErcGroupName,&CEGrp_tag)!=ITK_ok)PrintErrorStack();
												//if(SA_find_role2(CEAnalyst_role,&CEAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_role2(DML_CE_Group,&CEAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(CEGrp_tag!=NULLTAG && CEAnalyst_tag!=NULLTAG)
												{
													if(SA_find_groupmember_by_role(CEAnalyst_tag,CEGrp_tag,&No_CEAna,&CEAna)!=ITK_ok)PrintErrorStack();
													printf("\n Assign_CE_Manager_Review_Func:No_CEAna  :[%d]",No_CEAna);  fflush(stdout);
												}
												if(No_CEAna>0)
												{
													for(ik=0;ik<No_CEAna;ik++)
													{	
														printf("\n Assign_CE_Manager_Review_Func:CE Reviewer no: %d",ik);fflush(stdout);
														if(EPM_get_participanttype ("T5_CEReviewer",&CEAna_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(CEAna[ik],CEAna_Patri_Type,&CEAna_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(objTag);			
														if(PARTICIPANT_add_participant(objTag,hasbypass,CEAna_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(objTag);
														AOM_unlock(objTag);
													}
												}

												/// To Assign Manager .. for DML-on basis of Vetical field..
												if(tc_strcmp(DMLReason,"NR")==0)
												{
													if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0)
													{
														DML_MGR_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_MGR_Group,DMLVertical);
														tc_strcat(DML_MGR_Group,"_");
														tc_strcat(DML_MGR_Group,DMLDesignGrp);
														tc_strcat(DML_MGR_Group,"_Lead_CoC");
													}
													if(tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0 || tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0)
													{
														DML_MGR_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_MGR_Group,DMLVertical);
														tc_strcat(DML_MGR_Group,"_");
														tc_strcat(DML_MGR_Group,DMLDesignGrp);
														tc_strcat(DML_MGR_Group,"_Head_CoC");
													}
													if(tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
													{
														DML_MGR_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_MGR_Group,DMLDesignGrp);
														tc_strcat(DML_MGR_Group,"_Group_Head");
													}
												}
												else if(tc_strcmp(DMLReason,"DR")==0)
												{
													if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0 || tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0)
													{
														DML_MGR_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_MGR_Group,DMLVertical);
														tc_strcat(DML_MGR_Group,"_");
														tc_strcat(DML_MGR_Group,DMLDesignGrp);
														tc_strcat(DML_MGR_Group,"_Lead_CoC");
													}
													if(tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0 || tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
													{
														DML_MGR_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_MGR_Group,DMLVertical);
														tc_strcat(DML_MGR_Group,"_");
														tc_strcat(DML_MGR_Group,DMLDesignGrp);
														tc_strcat(DML_MGR_Group,"_Head_CoC");
													}
												}
												else
												{
													if(tc_strcmp(DMLDrStat,"DR0")==0 || tc_strcmp(DMLDrStat,"AR0")==0 || tc_strcmp(DMLDrStat,"DR1")==0 || tc_strcmp(DMLDrStat,"AR1")==0 || tc_strcmp(DMLDrStat,"DR2")==0 || tc_strcmp(DMLDrStat,"AR2")==0 || tc_strcmp(DMLDrStat,"DR3")==0 || tc_strcmp(DMLDrStat,"AR3")==0)
													{
														DML_MGR_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_MGR_Group,DMLVertical);
														tc_strcat(DML_MGR_Group,"_");
														tc_strcat(DML_MGR_Group,DMLDesignGrp);
														tc_strcat(DML_MGR_Group,"_Lead_CoC");
													}
													if(tc_strcmp(DMLDrStat,"DR4")==0 || tc_strcmp(DMLDrStat,"AR4")==0 || tc_strcmp(DMLDrStat,"DR5")==0 || tc_strcmp(DMLDrStat,"AR5")==0)
													{
														DML_MGR_Group = (char	*)MEM_alloc(100);
														tc_strcpy(DML_MGR_Group,DMLVertical);
														tc_strcat(DML_MGR_Group,"_");
														tc_strcat(DML_MGR_Group,DMLDesignGrp);
														tc_strcat(DML_MGR_Group,"_Head_CoC");
													}
												}

												printf("\n DML_MGR_Group  :[%s]",DML_MGR_Group);  fflush(stdout);
												//if(SA_find_group(DML_MGR_Group,&MgrGrp_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_group(ErcGroupName,&MgrGrp_tag)!=ITK_ok)PrintErrorStack();
												MgrAnalyst_role = (char	*)MEM_alloc(100);
												tc_strcpy(MgrAnalyst_role,DMLDesignGrp);
												tc_strcat(MgrAnalyst_role,"_Managers");
												printf("\n MgrAnalyst_role  :[%s]",MgrAnalyst_role);  fflush(stdout);
												//if(SA_find_role2(MgrAnalyst_role,&MgrAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_role2(DML_MGR_Group,&MgrAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(MgrGrp_tag!=NULLTAG && MgrAnalyst_tag!=NULLTAG)
												{
													if(SA_find_groupmember_by_role(MgrAnalyst_tag,MgrGrp_tag,&No_MGRAna,&MGRAna)!=ITK_ok)PrintErrorStack();
													printf("\n Assign_CE_Manager_Review_Func:No_MGRAna  :[%d]",No_MGRAna);fflush(stdout);
												}
												if(No_MGRAna>0)
												{
													for(ik=0;ik<No_MGRAna;ik++)
													{	
														printf("\n Assign_CE_Manager_Review_Func:Reviewer no: %d",ik);fflush(stdout);
														if(EPM_get_participanttype ("ChangeReviewBoard",&MGRAna_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(MGRAna[ik],MGRAna_Patri_Type,&MGRAna_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(objTag);			
														if(PARTICIPANT_add_participant(objTag,hasbypass,MGRAna_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(objTag);
														AOM_unlock(objTag);
													}
												}
												/// To Assign Manager .. for DML-on basis of Vetical field..
											}
										}
										else
										{
											if(tc_strcmp(groupName,"DML_Participants_Group")==0)
											{
												if(SA_find_group(groupName,&CEGrp_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_role2(CEAnalyst_role,&CEAnalyst_tag)!=ITK_ok)PrintErrorStack();
												if(SA_find_groupmember_by_role(CEAnalyst_tag,CEGrp_tag,&No_CEAna,&CEAna)!=ITK_ok)PrintErrorStack();
												printf("\n Assign_CE_Manager_Review_Func:No_CEAna  :[%d]",No_CEAna);  fflush(stdout);

												if(No_CEAna>0)
												{
													for(ik=0;ik<No_CEAna;ik++)
													{	
														printf("\n Assign_CE_Manager_Review_Func:CE Reviewer no: %d",ik);fflush(stdout);
														if(EPM_get_participanttype ("T5_CEReviewer",&CEAna_Patri_Type)!=ITK_ok)PrintErrorStack();
														if(EPM_create_participant(CEAna[ik],CEAna_Patri_Type,&CEAna_Party)!=ITK_ok)PrintErrorStack();
														AOM_lock(objTag);			
														if(PARTICIPANT_add_participant(objTag,hasbypass,CEAna_Party)!=ITK_ok)PrintErrorStack();	
														AOM_save_without_extensions(objTag);
														AOM_unlock(objTag);
													}
												}
											}
										}
										AOM_refresh ( objTag,TRUE);
										MEM_free(CEAna);
								}
							}
							else
							{
								printf("\n Assign_CE_Manager_Review_Func:CVBU:Other DMl...");fflush(stdout);
							}
						}
					}
					else
					{
						printf("\n NO PROJECT AVAILABLE..\n");fflush(stdout);
					}
				}
				else
				{
					PRDFlag=0;
					printf("\n Assign_CE_Manager_Review_Func: No project found: %d",PRDFlag); fflush(stdout);
				}
			}
		}
	}
	return error_code;
}

/******************************************************************************************
*   Function name			:	Assign_Principle_Eng_Func
*   Action Handler Name		:	Assign_Principle_Eng
*   Description				:	This function use to set Assign PrincipleEng to ERC CAB DML
								according to project code access.
*
*	Date				Modified By				Modification Notes
*	18/07/2020			Sudhir		1.54: Assign PrincipleEng to ERC CAB DML
******************************************************************************************/
int Assign_Principle_Eng_Func(EPM_action_message_t msg)
{
	int error_code = ITK_ok;
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;
	char	*DMLNo			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=NULL;

	char	*ErcGroupName	=  NULL;
	char	*DML_PrincipleEngg_Role		=  NULL;

	tag_t   ErcGroup_tag     = NULLTAG;
	tag_t   DML_PrincipleEng_tag     = NULLTAG;
	tag_t   *PrincipleEngineering     = NULLTAG;
	tag_t	PrincipleEngineer_Type	= NULLTAG;
	tag_t	PrincipleEngineer_Party		= NULLTAG;

	int No_PrincipleEng =0;
	int ik =0;
	logical hasbypass =true;

	printf("\n Assign_Principle_Eng_Func start.......");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task,&roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask,EPM_target_attachment,&no_attach,&attachment)!=ITK_ok)PrintErrorStack();
	printf("\n Assign_Principle_Eng_Func:No of Attachements: [%d]",no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
	printf("\n Assign_Principle_Eng_Func:DML/Task Number: [%s].",DMLNo);fflush(stdout);
	
	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\n Assign_Principle_Eng_Func: Workfow obj type: [%s]\n",ObjTyp);fflush(stdout);
	if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
	{
		if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
		printf("\n Assign_Principle_Eng_Func:DML Number: [%s] DMLType: [%s]",DMLNo,DMLType);fflush(stdout);

		if(tc_strcmp(DMLType,"EIDL")==0)
		{
			ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );
			DML_PrincipleEngg_Role = (char *) MEM_alloc( 100 * sizeof(char) );
			tc_strcpy(ErcGroupName,"ERC_Designers_Group");
			tc_strcpy(DML_PrincipleEngg_Role,"PrincipleEngRole");

			if(SA_find_group(ErcGroupName,&ErcGroup_tag)!=ITK_ok)PrintErrorStack();

			if(SA_find_role2(DML_PrincipleEngg_Role,&DML_PrincipleEng_tag)!=ITK_ok)PrintErrorStack();

			if(ErcGroup_tag!=NULLTAG && DML_PrincipleEng_tag!=NULLTAG)
			{
				if(SA_find_groupmember_by_role(DML_PrincipleEng_tag,ErcGroup_tag,&No_PrincipleEng,&PrincipleEngineering)!=ITK_ok)PrintErrorStack();
				printf("\n Assign_Principle_Eng_Func:No_MGRAna  :[%d]",No_PrincipleEng);fflush(stdout);
			}
			if(No_PrincipleEng>0)
			{
				for(ik=0;ik<No_PrincipleEng;ik++)
				{	
					printf("\n Assign_Principle_Eng_Func:Reviewer no: %d",ik);fflush(stdout);
					if(EPM_get_participanttype ("T5_PrincipleEngineer",&PrincipleEngineer_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(PrincipleEngineering[ik],PrincipleEngineer_Type,&PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(objTag);			
					if(PARTICIPANT_add_participant(objTag,hasbypass,PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();	
					AOM_save_without_extensions(objTag);
					AOM_unlock(objTag);
				}
			}
		}
		MEM_free(PrincipleEngineering);
	}
	return error_code;
}


/******************************************************************************************
*   Function name			:	Assign_Crash_Review_Func1
*   Action Handler Name		:	Assign_Crash_Review1
*   Description				:	This function use to set Crash Reviewer

******************************************************************************************/
int Assign_Crash_Review_Func1(EPM_action_message_t msg)
{
	int error_code = ITK_ok;
	tag_t	roottask        =  NULLTAG;
	tag_t   *attachment     =  NULLTAG;
	tag_t	objTag			=  NULLTAG;
	int      no_attach      =  0;
	char	*DMLType		=  NULL;
	char	*DMLNo			=  NULL;
	tag_t	objTypTag		= NULLTAG;
	char*   ObjTyp=NULL;

	char	*ErcGroupName	=  NULL;
	char	*DML_PrincipleEngg_Role		=  NULL;

	tag_t   ErcGroup_tag     = NULLTAG;
	tag_t   DML_PrincipleEng_tag     = NULLTAG;
	tag_t   *PrincipleEngineering     = NULLTAG;
	tag_t	PrincipleEngineer_Type	= NULLTAG;
	tag_t	PrincipleEngineer_Party		= NULLTAG;

	int No_PrincipleEng =0;
	int ik =0;

	//Task variables	
	int     PRDFlag	=  0;
	int     Taskcout	=  0;
	int     partcnt		=  0;
	int     Tskcout		=  0;
	int     kk		=  0;
	int     PltFoundFlg	=  0;
	int     prt	=  0;

	char	*Part_no		= NULL;
	char	*BomAna_Role		= NULL;
	char	*Tsk_class		= NULL;
	char	*Part_prj		= NULL;
	char*	DesgTyp				=NULL;

	tag_t   *TskRevn_tag    =  NULLTAG;
	tag_t   *TskRev_tag    =  NULLTAG;
	tag_t   *PartsTag    =  NULLTAG;
	tag_t	TskCls_t		= NULLTAG;
	tag_t	TskRev_t		= NULLTAG;
	tag_t	Project_t		= NULLTAG;
	tag_t	DmlTask_tag		= NULLTAG;
	tag_t	DmlTsk_tag		= NULLTAG;
	tag_t	AssyTag		= NULLTAG;
	tag_t	TskTypeTag	= NULLTAG;
	logical is_Tsklatst;
	logical hasbypass =true;
	char*   Tsk_Typ=NULL;
	logical is_Tskltst;
	int ifail = ITK_ok;
	int jk =0;
	int     CRBcount	=  0;
	tag_t	dml_CRB_rel_type		= NULLTAG;
	tag_t   *DmlCRB     = NULLTAG;
	tag_t   DmlCRBTag     = NULLTAG;
	tag_t   ObjTypDmlCRB     = NULLTAG;
	char*	type_name7=NULL;
		char	*DMLReviewr	;
		tag_t	objTypTagT		= NULLTAG;
		char*   ObjTypT=NULL;
		char		*ee_ecutype				= NULL;

	///

	printf("\n 11Assign_Crash_Review_Func start now.......11\n");fflush(stdout);
	// To get the Task Number from workflow..
	if(EPM_ask_root_task(msg.task,&roottask)!=ITK_ok)PrintErrorStack();
	if(EPM_ask_attachments(roottask,EPM_target_attachment,&no_attach,&attachment)!=ITK_ok)PrintErrorStack();
	printf("\n Assign_Crash_Review_Func:No of Attachements: [%d]\n",no_attach);fflush(stdout);
	if(no_attach>0)
	{
		objTag = attachment[0];
	}

	if(AOM_ask_value_string(attachment[0],"item_id",&DMLNo)!=ITK_ok)PrintErrorStack();
	printf("\n Assign_Crash_Review_Func:DML/Task Number: [%s].\n",DMLNo);fflush(stdout);
	
	if(TCTYPE_ask_object_type(objTag,&objTypTag));
	if(TCTYPE_ask_name2(objTypTag,&ObjTyp));
	printf("\n Assign_Crash_Review_Func: Workfow obj type: [%s]\n",ObjTyp);fflush(stdout);
	if(tc_strcmp(ObjTyp,"ChangeRequestRevision")==0)
	{
		if(AOM_ask_value_string(attachment[0],"t5_rlstype",&DMLType)!=ITK_ok)PrintErrorStack();
		printf("\n Assign_Crash_Review_Func:DML Number: [%s] DMLType: [%s]\n",DMLNo,DMLType);fflush(stdout);

//		if(tc_strcmp(DMLType,"EP")==0)
//		{
			//added for condition check of SW type//

			if(GRM_find_relation_type("T5_DMLTaskRelation",&DmlTsk_tag)!=ITK_ok)PrintErrorStack();
			if (DmlTsk_tag!=NULLTAG)
			{		
				if(GRM_list_secondary_objects_only(objTag,DmlTsk_tag,&Taskcout,&TskRevn_tag)!=ITK_ok)PrintErrorStack();
				printf("\n Assign_Crash_Review_Func TskRevn_tag Taskcout : %d\n ",Taskcout);fflush(stdout);
				for (kk=0;kk<Taskcout ;kk++ )
				{
					if(TCTYPE_ask_object_type(TskRevn_tag[kk],&TskTypeTag));
					if(TCTYPE_ask_name2(TskTypeTag,&Tsk_Typ));
					printf("\n Assign_Crash_Review_Func Tsk_Typ := %s\n",Tsk_Typ);fflush(stdout); 
					if(tc_strcmp(Tsk_Typ,"T5_ChangeTaskRevision")==0)
					{
						if(ITEM_rev_sequence_is_latest(TskRevn_tag[kk],&is_Tskltst)!=ITK_ok)PrintErrorStack();
						if(is_Tskltst != true)
						{
							printf("\n Assign_Crash_Review_Funcis_Tskltst is not true .....\n");fflush(stdout);
						}
						else
						{
							if(AOM_ask_value_tags(TskRevn_tag[kk],"CMHasSolutionItem",&partcnt,&PartsTag)!=ITK_ok)PrintErrorStack();
							printf("\n Assign_Crash_Review_Func partcnt.:%d\n",partcnt);fflush(stdout);
							if (partcnt>0)
							{
								prt=0;
								PltFoundFlg=0;
								for (prt=0;prt<partcnt ;prt++ )
								{							
									AssyTag=PartsTag[prt];
									if(AOM_ask_value_string(AssyTag,"item_id",&Part_no)!=ITK_ok)PrintErrorStack();
									printf("\n Assign_Crash_Review_Func.Part_no:%s ... \n",Part_no);	fflush(stdout);
									
									if (AOM_ask_value_string(AssyTag,"t5_PartType",&DesgTyp)!=ITK_ok)   PrintErrorStack();
									printf("\n DesgTyp: [%s] \n",DesgTyp);fflush(stdout);

									if(TCTYPE_ask_object_type(AssyTag,&objTypTagT));
									if(TCTYPE_ask_name2(objTypTagT,&ObjTypT));
									printf("\n Class of part in solution item  for crash review -->[%s]\n",ObjTypT);fflush(stdout);

									if((tc_strcmp(ObjTypT,"T5_EE_PartRevision")==0)||(tc_strcmp(ObjTypT,"EE Part Revision")==0))
									{
										printf("\n Inside EE part found in crash review -- [%s] \n",ObjTypT);fflush(stdout);
										if(AOM_UIF_ask_value(AssyTag,"t5_EcuType",&ee_ecutype)!= ITK_ok)PrintErrorStack();
										printf("\n ECU type found -- [%s] \n",ee_ecutype);fflush(stdout);

										if(tc_strcmp(ee_ecutype,"Restraints Control Module (Airbag)")==0)
										{
										  printf("\n Set the flag for crash review as ECU Type is --[%s] \n",ee_ecutype);fflush(stdout);
										  PltFoundFlg=1;
										  break;
										}
										
									}
									
									
								}
								
							}
						}
					}
				}

			}
	
			//end//
			printf("\n PltFoundFlg---->>  [%d] \n",PltFoundFlg);fflush(stdout);
			if (PltFoundFlg==1)
		   {	printf("\n First code start to REMOVE PARTICIPALNTS START...!!\n");fflush(stdout);
				// add remove participant//
				if(GRM_find_relation_type("HasParticipant",&dml_CRB_rel_type)!=ITK_ok)PrintErrorStack();
				if (dml_CRB_rel_type != NULLTAG)
				{
					printf("\n 111 REMOVE PARTICIPALNTS START...!!\n");fflush(stdout);
					if(GRM_list_secondary_objects_only(objTag,dml_CRB_rel_type,&CRBcount,&DmlCRB)!=ITK_ok)PrintErrorStack();
					printf("\nDmlCRB count: %d \n",CRBcount);fflush(stdout);	
					jk=0;
					for (jk=0; jk<CRBcount; jk++)
					{	
						printf("\n jk: %d.\n",jk);fflush(stdout);
						DmlCRBTag = DmlCRB[jk];
						if(TCTYPE_ask_object_type(DmlCRBTag,&ObjTypDmlCRB));
						if(TCTYPE_ask_name2(ObjTypDmlCRB,&type_name7));
						printf("\nDML:Participants Name:%s\n ",type_name7);fflush(stdout);

						if (tc_strcmp(type_name7,"T5_CrashReviewerGrp")==0)
						{
								printf("\n Inside the Participants Name:%s\n ",type_name7);fflush(stdout);
							if(AOM_UIF_ask_value(DmlCRBTag,"fnd0AssigneeUser",&DMLReviewr)!=ITK_ok)PrintErrorStack();
							printf("\nRemoving crash review already assigned participant :[%s] ",DMLReviewr);fflush(stdout);
							AOM_lock(objTag);
							if(PARTICIPANT_remove_participant(objTag,DmlCRBTag)!=ITK_ok)PrintErrorStack();
							AOM_save_without_extensions(objTag);
							AOM_unlock(objTag);
						}
					}

				}
				printf("\n Outside for First code start to REMOVE PARTICIPALNTS START...!!\n");fflush(stdout);
				//end


			 printf("\n Set the Crash Reviewer as PltFoundFlg  [%d] \n",PltFoundFlg);fflush(stdout);
			ErcGroupName = (char *) MEM_alloc( 100 * sizeof(char) );
			DML_PrincipleEngg_Role = (char *) MEM_alloc( 100 * sizeof(char) );
			tc_strcpy(ErcGroupName,"DML_Participants_Group");
			tc_strcpy(DML_PrincipleEngg_Role,"CrashECUReviewer");

			if(SA_find_group(ErcGroupName,&ErcGroup_tag)!=ITK_ok)PrintErrorStack();

			if(SA_find_role2(DML_PrincipleEngg_Role,&DML_PrincipleEng_tag)!=ITK_ok)PrintErrorStack();

			if(ErcGroup_tag!=NULLTAG && DML_PrincipleEng_tag!=NULLTAG)
			{
					printf("\n  Now at 5555 !\n");fflush(stdout);
				if(SA_find_groupmember_by_role(DML_PrincipleEng_tag,ErcGroup_tag,&No_PrincipleEng,&PrincipleEngineering)!=ITK_ok)PrintErrorStack();
				printf("\n Assign_Crash_Review_Func:>>  :[%d]",No_PrincipleEng);fflush(stdout);
			}
			if(No_PrincipleEng>0)
			{

				for(ik=0;ik<No_PrincipleEng;ik++)
				{	
					printf("\n Inside for loop - Assign_Crash_Review_Func:Reviewer no: %d",ik);fflush(stdout);
					if(EPM_get_participanttype ("T5_CrashReviewerGrp",&PrincipleEngineer_Type)!=ITK_ok)PrintErrorStack();
					if(EPM_create_participant(PrincipleEngineering[ik],PrincipleEngineer_Type,&PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();
					AOM_lock(objTag);			
					if(PARTICIPANT_add_participant(objTag,hasbypass,PrincipleEngineer_Party)!=ITK_ok)PrintErrorStack();	
					AOM_save_without_extensions(objTag);
					AOM_unlock(objTag);
				}

					printf("\n In the end of for loop \n");fflush(stdout);
						AOM_refresh (objTag,TRUE);
						//MEM_free(PrincipleEngineering);
				
			}
			printf("\n Set task condition true \n");fflush(stdout);

		   }
    	
	  }

	  printf("\n 777777777777777777788   \n");fflush(stdout);

		  if (PltFoundFlg==1)
		  {
				printf("\n Now condition true now part started  \n");fflush(stdout);

				ifail = EPM_set_task_result(msg.task,EPM_RESULT_True);
				printf("\n EPM_RESULT_True inside : %d \n",ifail); fflush(stdout);

		   }
		   else
			{
				 printf("\n Else no need to  Set the Crash Reviewer as PltFoundFlg  [%d] \n",PltFoundFlg);fflush(stdout);

				 ifail = EPM_set_task_result(msg.task,EPM_RESULT_False);
				 printf("\n EPM_RESULT_False inside : %d",ifail); fflush(stdout);
			}

		printf("\n  MAIN FUNCTION END here ---%d \n",ifail );fflush(stdout);
		MEM_free(PrincipleEngineering);


	return ifail;
	
}

//end by ajinkya//

int Assign_Dynamic_party_register_action_handlers()
{
	int retcode = ITK_ok;

	if ( retcode == ITK_ok )
	{
		//Assign BOM/CE/Peer/DMU reviewer
		retcode = EPM_register_action_handler (
								"Assign_Dynamic_party",
								"Assign_Dynamic_party",
								(EPM_action_handler_t)Assign_Dynamic_party_Func
								);
		//Assign BOM/CE/Peer/DMU reviewer
		retcode = EPM_register_action_handler (
								"Assign_Dynamic_party_CV",
								"Assign_Dynamic_party_CV",
								(EPM_action_handler_t)Assign_Dynamic_party_Func_CV
								);
		//Platform Reviewer
		retcode = EPM_register_action_handler (
								"Assign_Platform_Review",
								"Assign_Platform_Review",
								(EPM_action_handler_t)Assign_Platform_Review_Func
								);
		//Platform Reviewer
		retcode = EPM_register_action_handler (
								"Assign_Chassis_Review",
								"Assign_Chassis_Review",
								(EPM_action_handler_t)Assign_Chassis_Review_Func
								);
		//SVR COC Reviewer
		retcode = EPM_register_action_handler (
								"Assign_SVRCOC_Review",
								"Assign_SVRCOC_Review",
								(EPM_action_handler_t)Assign_SVRCOC_party_Func
								);
		//MDM Reviewer
		retcode = EPM_register_action_handler (
								"Assign_MDM_Review",
								"Assign_MDM_Review",
								(EPM_action_handler_t)Assign_MDM_Review_Func
								);

		//CE_Manager Reviewer
		retcode = EPM_register_action_handler (
								"Assign_CE_Manager_Review",
								"Assign_CE_Manager_Review",
								(EPM_action_handler_t)Assign_CE_Manager_Review_Func
								);

		//Principle Eng
		retcode = EPM_register_action_handler (
								"Assign_Principle_Eng",
								"Assign_Principle_Eng",
								(EPM_action_handler_t)Assign_Principle_Eng_Func
								);

		//added by ajinkya for Crash Reviewer Grp on 18 may//

		retcode = EPM_register_action_handler (
								"Assign_Crash_Review1",
								"Assign_Crash_Review1",
								(EPM_action_handler_t)Assign_Crash_Review_Func1
								);
		

		//end

		printf("\n at the end.....\n");fflush(stdout);
	}
	return retcode;
}

extern int Assign_Dynamic_party_action(int *decision,va_list args)
{
	int status = ITK_ok;
	*decision=ALL_CUSTOMIZATIONS;	

	printf("\n before .... ");fflush(stdout);
	status = Assign_Dynamic_party_register_action_handlers();
	printf("\n after ..... ");fflush(stdout);
	return status;
}

extern DLLAPI int tm_Assign_Dynamic_party_register_callbacks ()
{
	int ifail    = ITK_ok;
	printf("\n\n before calling ..\n");
    ifail=CUSTOM_register_exit("tm_Assign_Dynamic_party","USER_init_module",(CUSTOM_EXIT_ftn_t)Assign_Dynamic_party_action);
	printf("\n\n after calling ...\n");
	
    return ( ITK_ok );
}
