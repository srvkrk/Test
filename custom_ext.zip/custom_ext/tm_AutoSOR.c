/*
preference	AutoSOR_CC_path		uadev path	/home/uadev/devgroups/dbk/PPPMProjectCodes_list
preference	AutoSOR_CC_path		cmitest path	
preference	AutoSOR_CC_path		uaprodtrl path	
preference	SOR_PPPMPrjCode		ON/OFF
*/
#define ITK_err 919002
#define TE_MAXLINELEN  128
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tccore/workspaceobject.h>
#include <tccore/item_msg.h>
#include <bom/bom.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
//#include <tccore/iman_msg.h>
#include <tccore/aom_prop.h>
#include <tccore/project.h>
#include <tccore/grm.h>
#include <ae/datasettype.h>
#include <tc/preferences.h>
#include <epm/epm.h>
#include <tccore/method.h>
#include <tc/tc_arguments.h>


#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
//#include <tc/iman.h>
//#include <tccore/imantype.h>
//#include <sa/imanfile.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
//#include <itk/mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>
#include <epm/epm.h>
#include <epm/epm_task_template_itk.h>
#include <tccore/grm_msg.h>
//#include <sys/time.h>
#include <time.h>
//#include "soapH.h"
//#include "pronextSOAP.nsmap"

#include <ae/dataset_msg.h>

#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PLM_error (EMH_USER_error_base + 325)


#define NO_OF_PPPM_PROJECT 100
#define PPPM_PROJECT_NAME_DESC 2

//struct PPPM_ProjectInfo
//{
//        char PPPM_PROJECT_CODE[80];
//        char PROJECT_DESCSCRIPTION[80];
//}
//sProjectInfo;
//
//struct ProjectVariant
//{
//        char TOTAL_VOLUME[80];
//        char VARIANT_ID[80];
//        char LOCATION[20];
//        char VARIANT_NAME[20];
//}
//sProjectVariant;
//
//struct ProjectBase
//{
//        char PPPM_PROJECT_CODE[80];
//        char PROJECT_DESCSCRIPTION[80];
//        char MANUF_LOC[20];
//        char PRONEXT_PROJ_SRL[20];
//        char BUSINESS_UNIT[20];
//        char PROJ_CODE[20];
//        struct ProjectVariant PrjVariant[50];
//}
//sProjectBase;


int removeAllReleaseStatus (tag_t objTag);
int tm_check_control_object ( char *syscd, char *subsyscd );
int AutoSorPPPMAskLOVValuesMethod( METHOD_message_t *msg, va_list  args );

#define ITK_CALL(X) (report_error( __FILE__, __LINE__, #X, (X)))

static int report_error( char *file, int line, char *function, int return_code)
{
	if (return_code != ITK_ok)
	{
		int				index = 0;
		int				n_ifails = 0;
		const int*		severities = 0;
		const int*		ifails = 0;
		const char**	texts = NULL;

		EMH_ask_errors( &n_ifails, &severities, &ifails, &texts);
		printf("%3d error(s)\n", n_ifails);
		for( index=0; index<n_ifails; index++)
		{
			printf("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			TC_write_syslog("ERROR: %d\tERROR MSG: %s\n", ifails[index], texts[index]);
			printf ("FUNCTION: %s\nFILE: %s LINE: %d\n\n", function, file, line);
			TC_write_syslog("FUNCTION: %s\nFILE: %s LINE: %d\n", function, file, line);
		}
		EMH_clear_errors();

	}
	return return_code;
}
static void TAG_free(void *what)
{
    if (what != NULL)
    {
        MEM_free(what);
        what = NULL;
    }
}

//check session project and sor project are matching then only allow to save object
char* time_stamp()
{

	char *timestamp = (char *)malloc(sizeof(char) * 30);
	time_t ltime;
	ltime=time(NULL);
	struct tm *tm_now;
	tm_now=localtime(&ltime);
	sprintf(timestamp,"%04d_%02d_%02d_%02d_%02d_%02d", tm_now->tm_year+1900, tm_now->tm_mon, tm_now->tm_mday, tm_now->tm_hour, tm_now->tm_min, tm_now->tm_sec);
	//sprintf(timestamp,"%04d_%02d_%02d_%02d_%02d_%02d", tm_now.tm_year+1900, tm_now.tm_mon, tm_now.tm_mday, tm_now.tm_hour, tm_now.tm_min, tm_now.tm_sec);
	return timestamp;
}

void checkHostName(int hostname)
{
    if (hostname == -1)
    {
        perror("gethostname");
        exit(1);
    }
}

// Returns host information corresponding to host name
void checkHostEntry(struct hostent * hostentry)
{
    if (hostentry == NULL)
    {
        perror("gethostbyname");
        exit(1);
    }
}


void checkIPbuffer(char *IPbuffer)
{
    if (NULL == IPbuffer)
    {
        perror("inet_ntoa");
        exit(1);
    }
}

// Driver code
int host_tcua(char hostbuffer1[256])
{
    char hostbuffer[256];
    char *IPbuffer;
    struct hostent *host_entry;
    int hostname;

    // To retrieve hostname
    hostname = gethostname(hostbuffer, sizeof(hostbuffer));
    checkHostName(hostname);

    // To retrieve host information
    host_entry = gethostbyname(hostbuffer);
    checkHostEntry(host_entry);

    // To convert an Internet network
    // address into ASCII string
    IPbuffer = inet_ntoa(*((struct in_addr*)
                           host_entry->h_addr_list[0]));

	tc_strcpy(hostbuffer1,hostbuffer);
    printf("Hostname: %s\n", hostbuffer);
    printf("Hostname: %s\n", hostbuffer1);
    printf("Host IP: %s", IPbuffer);

    return 0;
}
//check object in control table
int tm_check_info_control_object ( char *syscd, char *subsyscd, char *info1, char *info2 )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	char *l_info1 = NULL ;
	char *l_info2 = NULL ;

	ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	if ( n_found > 0 )
	{
		ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo1",&l_info1) );
		tc_strcpy( info1, l_info1 );
		ITK_CALL ( AOM_ask_value_string(cntr_objects[0],"t5_Userinfo2",&l_info2) );
		tc_strcpy( info2, l_info2 );

		TC_write_syslog ( "\ninfo1 : [%s] info2 : [%s]" ,info1 ,info2 ) ; fflush ( stdout) ;
	}

	return n_found ;
}

int AutoSor_PPPM_proj_LOV_Method( METHOD_message_t *msg, va_list  args )
{
	tag_t lov_tag = va_arg(args, const tag_t);
	int* n_values = va_arg(args, int*);
	char ***values = va_arg(args, char***);
	int error_code = ITK_ok;
	int n_found_SOR_LOV = 0 ;
	int n_found = 0;

	char *val1 = NULL ;
	char *AllProjectStr = NULL ;
	char *pppmcode3 = NULL ;
	int iPrjCounter = 0 ;
	int jc = 0 ;
	//struct PPPM_ProjectInfo mysProjectInfo [100] ;

	char **project_details = NULL;
	tag_t Currproj = NULLTAG;
	char *curr_proj_name = NULL;
	int  ii = 0;
	char *ProjectCode = NULL;
	char line[250] = { 0 };
	int count = 0 ;
	int ij = 0;
	char *username = NULL;
	tag_t user_tag = NULLTAG;
	char *userid = NULL;
	//char const *fileName = "/tmp/a.txt";
	char fileName[200] = { 0 };
	char *timestamp = NULL;
	char *pppm_cmd_to_execute = NULL;
	char *command = NULL;
	//char command[512];
	FILE* file = NULL ;
	char *sAutoSOR_CC_path = NULL;
	int n_found_SOR_PF_info = 0;
	int n_found_SOR_PF_info1 = 0;
	char *tcua_uname = NULL;
	char *tcua_pf_file = NULL;
	char *info2 = NULL;
	char *info22 = NULL;
	char *pppm_file_path = NULL;
	char *shell_path = NULL;
	char hostbuffer[256];

	host_tcua(hostbuffer);

	printf ( "\nhostbuffer : %s",hostbuffer );

	tcua_uname = ( char * ) MEM_alloc ( 50 * sizeof ( char ) );
	tcua_pf_file = ( char * ) MEM_alloc (200* sizeof ( char ) );
	pppm_file_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	shell_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info2 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info22 = ( char * ) MEM_alloc (200* sizeof ( char ) );

	
	
	n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PWFILE", "PATH", tcua_uname, tcua_pf_file );
	if ( n_found_SOR_PF_info < 0 )
	{
		TC_write_syslog ( "\nCreate hostname username and password file control object for host : %s",hostbuffer ) ;
		return 0;
	}


	n_found_SOR_LOV = tm_check_control_object ( "SORLOVBYPASS", "LOVBYPASSALLOW" );//webservice call handling
	if ( n_found_SOR_LOV > 0 )
	{
		n_found = 1;
		*n_values = 1;
		*values = (char **)MEM_alloc (*n_values * sizeof(char*));
		memset( *values, 0,  *n_values * sizeof(char*));
		for ( ii = 0; ii < n_found; ii++ )
		{
			(*values)[ii] = (char *) MEM_alloc ( 128 );
			strcpy((*values)[ii], "M-L95.3-CAD.698-SIGNA REFRESH");
		}
	}
	else//call client code
	{
		ITK_CALL ( PREF_ask_char_value ( "AutoSOR_CC_path", 0 , &sAutoSOR_CC_path ) ) ;//preference
		//printf ( "\nsAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ; fflush ( stdout) ;
		//TC_write_syslog ( "\nsAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ;

		ITK_CALL ( POM_get_user ( &username, &user_tag ) ) ;
		ITK_CALL ( SA_ask_user_identifier2 ( user_tag, &userid ) ) ;
        printf ("\nLogged in user: [%s] [%s]",userid,username);fflush(stdout);
        TC_write_syslog ("\nLogged in user: [%s] [%s]",userid,username);fflush(stdout);

		ITK_CALL ( SA_ask_current_project ( &Currproj ) );
		if ( Currproj != NULLTAG )
		{
			ITK_CALL ( AOM_ask_value_string(Currproj,"object_name",&curr_proj_name) );
		}
		printf ("\ncurr_proj_name: [%s]", curr_proj_name ) ; fflush ( stdout ) ;
		TC_write_syslog ("\ncurr_proj_name: [%s]", curr_proj_name ) ; fflush ( stdout ) ;

        n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PPPMFILE","PPPM_CODE", pppm_file_path, info22 );

		if ( n_found_SOR_PF_info < 0 )
	    {
	    	TC_write_syslog ( "\nCreating PPPM code file on common location" ) ;
	    	return 0;
	    }

        n_found_SOR_PF_info1 = tm_check_info_control_object ( "AUTOSOR_SHELL", "PPPM_CODE_VARIANT", shell_path, info2 );

		if ( n_found_SOR_PF_info1 < 0 )
	    {
	    	TC_write_syslog ( "\nexecuting shell for PPPM code info" ) ;
	    	return 0;
	    }
		
		timestamp = time_stamp ( ) ;
		sprintf( fileName, "/%s/pppm_%s_%s_%s.txt",pppm_file_path, userid,curr_proj_name,timestamp );
		printf ( "\nfileName : [%s]", fileName ); fflush ( stdout) ;
		TC_write_syslog ( "\nfileName : [%s]", fileName );
		command = ( char * ) MEM_alloc ( 1000 * sizeof ( char ) ) ;
		//sprintf ( pppm_cmd_to_execute, "/home/uadev/devgroups/dbk/PPPMProjectCodes_list/PPPMProjectCodes_list -d=%s -f=%s", curr_proj_name, fileName ) ;


		if (access(shell_path, F_OK) == 0) 
		{
		    // file exists
			printf ("\nshell_path : [%s]",shell_path);
			TC_write_syslog ("\nshell_path : [%s]",shell_path);
			sprintf ( command, "%s/PPPMProjectCodes_list.sh -d=%s -f=%s -u=%s -pf=\"%s\"",shell_path, curr_proj_name, fileName,tcua_uname, tcua_pf_file ) ;
			system( command );
		} 
		else 
		{
		    // file doesn't exist

			int tmp_n_found_SOR_PF_info1 = 0;
			char *shell_path_TMP_PATH = NULL;
			char *info2_TMP_PATH = NULL;

			shell_path_TMP_PATH = ( char * ) MEM_alloc (200* sizeof ( char ) );
			info2_TMP_PATH = ( char * ) MEM_alloc (200* sizeof ( char ) );

			tmp_n_found_SOR_PF_info1 = tm_check_info_control_object ( "AUTOSOR_SHELL_TMP_PATH", "PPPM_CODE_VARIANT_TMP_PATH", shell_path_TMP_PATH, info2_TMP_PATH );

			if ( tmp_n_found_SOR_PF_info1 < 0 )
			{
				TC_write_syslog ( "\nexecuting shell for PPPM code info" ) ;
				return 0;
			}
			printf ("\nshell_path_TMP_PATH : [%s]",shell_path_TMP_PATH);
			TC_write_syslog ("\nshell_path_TMP_PATH : [%s]",shell_path_TMP_PATH);
			//sprintf ( command, "%s/PPPMProjectCodes_list.sh -d=%s -f=%s -u=%s -pf=\"%s\"",shell_path, curr_proj_name, fileName,tcua_uname, tcua_pf_file ) ;
			sprintf ( command, "%s/PPPMProjectCodes_list.sh -d=%s -f=%s -u=%s -pf=\"%s\"", shell_path_TMP_PATH,curr_proj_name, fileName,tcua_uname, tcua_pf_file ) ;
			system( command );
		
		}


		printf ( "\ncmd_to_execute : [%s]", command ); fflush ( stdout) ;
		TC_write_syslog ( "\ncmd_to_execute : [%s]", command );

		file = fopen(fileName, "r");
	
		if ( !file )
		{
			printf("\nUnable to open 1 : [%s] ", fileName);fflush ( stdout ) ;
			TC_write_syslog("\nUnable to open 1 : [%s] ", fileName);fflush ( stdout ) ;
			return -1;
		}

		project_details = (char **)MEM_alloc (200 * sizeof(char*));//no of project
		while ( fgets ( line, sizeof ( line ), file ) )
		{
			line[tc_strlen(line)-2] = '\0';
			project_details[ij] = (char *) MEM_alloc ( 200 );	//project desc length
			tc_strcpy ( project_details[ij], line ) ;
			printf("\nproject_details[ij] : [%s] tc_strlen(project_details[ij]) : [%d]", project_details[ij],tc_strlen(project_details[ij])); fflush ( stdout ) ;
			TC_write_syslog("\nproject_details[ij] : [%s] tc_strlen(project_details[ij]) : [%d]", project_details[ij],tc_strlen(project_details[ij])); fflush ( stdout ) ;
			ij = ij + 1;
		}
		fclose ( file ) ;
		*n_values = ij;
		*values = (char **)MEM_alloc (ij * sizeof(char*));
		for ( ii = 0; ii < ij; ii++ )
		{
			(*values)[ii] = (char *) MEM_alloc ( 200 );
			tc_strcpy((*values)[ii], project_details[ii]);
			printf("\n*values)[%d] : [%s]",ii,(*values)[ii]);fflush ( stdout ) ;
			TC_write_syslog("\n*values)[%d] : [%s]",ii,(*values)[ii]);fflush ( stdout ) ;
		}
		printf("\nAutoSor_PPPM_proj_LOV_Method : Project Name Desc details END code\n\n\n" ) ; fflush ( stdout) ;
		TC_write_syslog("\nAutoSor_PPPM_proj_LOV_Method : Project Name Desc details END code\n\n\n" ) ;
	}

	return error_code;
}


int tm_get_pppm_variant ( tag_t objTag, char *dml_project_code, char *sor_t5_PPPMPrjCode)
{
	char *username = NULL;
	tag_t user_tag = NULLTAG;
	char *userid = NULL;
	char fileName[200] = { 0 };
	char *timestamp = NULL;
	char *var_cmd_to_execute = NULL;
	char *command = NULL;
	//char command[512];
	FILE* file = NULL ;
	tag_t Currproj = NULLTAG;
	char *curr_proj_name = NULL;
	char **variant_details = NULL;
	char **variant_details_read = NULL;
	int ij = 0;
	char line[250] = { 0 };
	//char *sor_t5_PPPMPrjCode = NULL;
	int iIndex = 0;

	char *s_srl_no = NULL;
	char *s_volume_inf = NULL;
	char *s_var_id = NULL;
	char *s_location = NULL;
	char *s_var_name = NULL;

	int n_table_rows = 0;
	tag_t *table_rowsTag = NULLTAG;
	tag_t *table_rows1Tag = NULLTAG;
	int NewLevel = 0;
	const char *table_property_name = "t5_SORVar";
	int num_rows_to_append = 0;
	char *sAutoSOR_CC_path = NULL;
	char hostbuffer[256];

	int n_found_SOR_PF_info = 0;
	int n_found_SOR_PF_info1 = 0;
	char *tcua_uname = NULL;
	char *tcua_pf_file = NULL;
	char *info2 = NULL;
	char *info22 = NULL;
	char *shell_path = NULL;
	char *pppm_file_path = NULL;

	host_tcua(hostbuffer);

	printf ( "\nhostbuffer : %s",hostbuffer );

	tcua_uname = ( char * ) MEM_alloc ( 50 * sizeof ( char ) );
	tcua_pf_file = ( char * ) MEM_alloc (200* sizeof ( char ) );
	pppm_file_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	shell_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info2 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info22 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	
	n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PWFILE", "PATH", tcua_uname, tcua_pf_file );
	if ( n_found_SOR_PF_info < 0 )
	{
		TC_write_syslog ( "\nCreate hostname username and password file control object for host : %s",hostbuffer ) ;
		return 0;
	}

	printf ( "\nhostbuffer : %s",hostbuffer );

	//TC_write_syslog ("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc before : [%s]",sor_t5_PPPMPrjCode_desc);
	TC_write_syslog ("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode before : [%s]",sor_t5_PPPMPrjCode);


	if ( tc_strcmp ( sor_t5_PPPMPrjCode, "" ) == 0 )
	{
		printf ( "\ntm_get_pppm_variant: sor_t5_PPPMPrjCode is null select from drop down" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\ntm_get_pppm_variant : sor_t5_PPPMPrjCode is null select from drop down" ) ;
		return -1;
	}

	ITK_CALL ( PREF_ask_char_value ( "AutoSOR_CC_path", 0 , &sAutoSOR_CC_path ) ) ;//preference
	//printf ( "\ntm_get_pppm_variant : sAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ; fflush ( stdout) ;
	//TC_write_syslog ( "\ntm_get_pppm_variant : sAutoSOR_CC_path : [%s]", sAutoSOR_CC_path ) ;
		

	//sor_t5_PPPMPrjCode = tc_strtok ( sor_t5_PPPMPrjCode_desc, "$" );

	printf("\ntm_get_pppm_variant : Project code after strtok : [%s]",sor_t5_PPPMPrjCode); fflush ( stdout) ;
	TC_write_syslog ("\ntm_get_pppm_variant: sor_t5_PPPMPrjCode after strtok : [%s]",sor_t5_PPPMPrjCode);
	//TC_write_syslog ("\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc after strtok : [%s]",sor_t5_PPPMPrjCode_desc);

	ITK_CALL ( POM_get_user ( &username, &user_tag ) ) ;
	ITK_CALL ( SA_ask_user_identifier2 ( user_tag, &userid ) ) ;
	printf ("\ntm_get_pppm_variant : Logged in user: [%s] [%s]",userid,username);fflush(stdout);
	TC_write_syslog ("\ntm_get_pppm_variant : Logged in user: [%s] [%s]",userid,username);fflush(stdout);

	n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PPPMFILE","PPPM_CODE", pppm_file_path, info22 );

	if ( n_found_SOR_PF_info < 0 )
	{
		TC_write_syslog ( "\nCreating PPPM code file on common location" ) ;
		return 0;
	}

    n_found_SOR_PF_info1 = tm_check_info_control_object ( "AUTOSOR_SHELL", "PPPM_CODE_VARIANT", shell_path, info2 );

	if ( n_found_SOR_PF_info1 < 0 )
	{
		TC_write_syslog ( "\nexecuting shell for PPPM code info" ) ;
		return 0;
	}

	timestamp = time_stamp ( ) ;
	sprintf( fileName, "/%s/pppm_var_%s_%s_%s.txt",pppm_file_path, userid,dml_project_code,timestamp );
	printf ( "\ntm_get_pppm_variant : fileName : [%s]", fileName ); fflush ( stdout) ;
	TC_write_syslog ( "\ntm_get_pppm_variant : fileName : [%s]", fileName );
	command = ( char * ) MEM_alloc ( 500 * sizeof ( char ) ) ;
	//PPPMVariantInfo -u=infodba -p=infodba -d="2228" -m="M-L155.5-MHCV_PD-MHCV PRODUCTIONISED VC_TIPPER" -f="/tmp/a.txt" 
	//sprintf ( var_cmd_to_execute, "/home/uadev/devgroups/dbk/PPPMProjectCodes_list/PPPMVariantInfo -d=\"%s\" -m=\"%s\" -f=\"%s\"", dml_project_code, sor_t5_PPPMPrjCode, fileName ) ;
	//sprintf ( command, "%s/PPPMVariantInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"",shell_path, dml_project_code, sor_t5_PPPMPrjCode, fileName, tcua_uname, tcua_pf_file ) ;
	//system( command );


	if (access(shell_path, F_OK) == 0) 
	{
	    // file exists


		printf ("\nshell_path : [%s]",shell_path);
		TC_write_syslog ("\nshell_path : [%s]",shell_path);
		sprintf ( command, "%s/PPPMVariantInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"",shell_path, dml_project_code, sor_t5_PPPMPrjCode, fileName, tcua_uname, tcua_pf_file ) ;
		system( command );
	} 
	else 
	{
	    // file doesn't exist
		int tmp_n_found_SOR_PF_info1 = 0;
		char *shell_path_TMP_PATH = NULL;
		char *info2_TMP_PATH = NULL;


		shell_path_TMP_PATH = ( char * ) MEM_alloc (200* sizeof ( char ) );
		info2_TMP_PATH = ( char * ) MEM_alloc (200* sizeof ( char ) );

		tmp_n_found_SOR_PF_info1 = tm_check_info_control_object ( "AUTOSOR_SHELL_TMP_PATH", "PPPM_CODE_VARIANT_TMP_PATH", shell_path_TMP_PATH, info2_TMP_PATH );

		if ( tmp_n_found_SOR_PF_info1 < 0 )
		{
			TC_write_syslog ( "\nexecuting shell for PPPM code info" ) ;
			return 0;
		}
		printf ("\nshell_path_TMP_PATH : [%s]",shell_path_TMP_PATH);
		TC_write_syslog ("\nshell_path_TMP_PATH : [%s]",shell_path_TMP_PATH);
		//sprintf ( command, "%s/PPPMProjectCodes_list.sh -d=%s -f=%s -u=%s -pf=\"%s\"",shell_path, curr_proj_name, fileName,tcua_uname, tcua_pf_file ) ;
		sprintf ( command, "%s/PPPMVariantInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"",shell_path_TMP_PATH,dml_project_code, sor_t5_PPPMPrjCode, fileName, tcua_uname, tcua_pf_file ) ;
		system( command );
	
	}

	printf ( "\ntm_get_pppm_variant : var_cmd_to_execute : [%s]", command ); fflush ( stdout) ;
	TC_write_syslog ( "\ntm_get_pppm_variant : var_cmd_to_execute : [%s]", command );

	file = fopen(fileName, "r");

	if ( !file )
	{
		printf("\ntm_get_pppm_variant : Unable to open1 : [%s] ", fileName);fflush ( stdout ) ;
		TC_write_syslog("\ntm_get_pppm_variant : Unable to open1 : [%s] ", fileName);fflush ( stdout ) ;
		return -1;
	}

	variant_details = (char **)MEM_alloc (200 * sizeof(char*));//no of project
	while ( fgets ( line, sizeof ( line ), file ) )
	{
		line[tc_strlen(line)-2] = '\0';
		variant_details[ij] = (char *) MEM_alloc ( 200 );	//project desc length
		tc_strcpy ( variant_details[ij], line ) ;
		printf("\nvariant_details[ij] : [%s] tc_strlen(variant_details[ij]) : [%d]", variant_details[ij],tc_strlen(variant_details[ij])); fflush ( stdout ) ;
		TC_write_syslog("\nvariant_details[ij] : [%s] tc_strlen(variant_details[ij]) : [%d]", variant_details[ij],tc_strlen(variant_details[ij])); fflush ( stdout ) ;
		ij = ij + 1;
	}
	fclose ( file ) ;

	printf("\ntm_get_pppm_variant : Number of variant found in file : [%d]", ij ); fflush ( stdout) ;
	TC_write_syslog("\ntm_get_pppm_variant : Number of variant found in file : [%d]", ij );

	//information same file read twice first for to count no of records

	file = fopen(fileName, "r");

	if ( !file )
	{
		printf("\ntm_get_pppm_variant : Unable to open2 : [%s] ", fileName);fflush ( stdout ) ;
		TC_write_syslog("\ntm_get_pppm_variant : Unable to open2 : [%s] ", fileName);fflush ( stdout ) ;
		return -1;
	}

	ITK_CALL ( AOM_ask_table_rows ( objTag, "t5_SORVar", &n_table_rows, &table_rowsTag ) ) ;
	printf ( "\ntm_get_pppm_variant : no of table rows are %d \n", n_table_rows ) ;//need to delete old rows
	fflush ( stdout) ;
	TC_write_syslog ( "\ntm_get_pppm_variant : no of table rows are %d \n", n_table_rows ) ;//need to delete old rows

	if ( n_table_rows > 0 )
	{

		TC_write_syslog ( "\ntm_get_pppm_variant : deleting old variant for PPPM project code selected \n" ) ;//need to delete old rows
		//ITK_CALL ( RES_checkout2(objTag, "", "", "", RES_EXCLUSIVE_RESERVE) );
		//ITK_CALL ( AOM_lock(objTag) ) ;//Rajan 20-12-2024 instance locked
		//ITK_CALL ( AOM_refresh ( objTag,TRUE ) ); //lock
		ITK_CALL ( AOM_delete_table_rows(objTag, "t5_SORVar", 0, n_table_rows) );
		//ITK_CALL ( AOM_save(objTag) );
		//ITK_CALL (  AOM_save_without_extensions(objTag) ); //Rajan 20-12-2024 instance locked
        //ITK_CALL ( AOM_unlock(objTag) ); //Rajan 20-12-2024 instance locked
		//ITK_CALL ( AOM_refresh ( objTag,FALSE ) );//unlock

		TC_write_syslog ( "\ntm_get_pppm_variant : deleting old variant for previous PPPM project code completed... \n" ) ;//need to delete old rows
        
	}


	//printf ( "\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc : [%s] \n", sor_t5_PPPMPrjCode_desc ) ;//need to delete old rows
	//fflush ( stdout) ;
	//TC_write_syslog ( "\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc : [%s] \n", sor_t5_PPPMPrjCode_desc ) ;//need to delete old rows

	//if ( ( n_table_rows <= 0 ) && ( tc_strcmp ( sor_t5_PPPMPrjCode, "" ) != 0 ) )//no of rows are zero then only append
	if ( tc_strcmp ( sor_t5_PPPMPrjCode, "" ) != 0 )//pppm project is not blank
	{
		num_rows_to_append = ij ;
		//ITK_CALL ( RES_checkout2(objTag, "", "", "", RES_EXCLUSIVE_RESERVE) );
		//ITK_CALL ( AOM_lock ( objTag ) ) ;//Rajan 20-12-2024 instance locked
		//ITK_CALL ( AOM_refresh ( objTag,TRUE ) );//lock
		ITK_CALL ( AOM_append_table_rows ( objTag, table_property_name,num_rows_to_append, &NewLevel, &table_rows1Tag ) ) ;
		
		//ITK_CALL (  AOM_save_without_extensions(objTag) ); //save	//Rajan 20-12-2024 instance locked
		//TC_write_syslog("\nautosorobjTag saved1");
		//ITK_CALL ( AOM_refresh ( quicksorobjTag,FALSE ) );//unlock
		//ITK_CALL ( AOM_unlock ( objTag ) );//unlock		//Rajan 20-12-2024 instance locked
		TC_write_syslog("\nautosorobjTag unlocked1");

		variant_details_read = (char **)MEM_alloc (200 * sizeof(char*));//no of project
		while ( fgets ( line, sizeof ( line ), file ) )
		{
			line[tc_strlen(line)-2] = '\0';
			variant_details_read[iIndex] = (char *) MEM_alloc ( 200 );	//project desc length
			tc_strcpy ( variant_details_read[iIndex], line ) ;
			//printf("\nvariant_details_read[iIndex] : [%s] tc_strlen(variant_details_read[iIndex]) : [%d]", variant_details_read[iIndex],tc_strlen(variant_details_read[iIndex])); fflush ( stdout ) ;
			//TC_write_syslog("\nvariant_details_read[iIndex] : [%s] tc_strlen(variant_details_read[iIndex]) : [%d]", variant_details_read[iIndex],tc_strlen(variant_details_read[iIndex])); fflush ( stdout ) ;
			
			
			s_srl_no = tc_strtok ( variant_details_read[iIndex], "^" );
			s_volume_inf = tc_strtok ( NULL, "^" );
			s_var_id = tc_strtok (  NULL, "^" );
			s_location = tc_strtok (  NULL, "^" );
			s_var_name = tc_strtok (  NULL, "^" );
			TC_write_syslog("\ntm_get_pppm_variant : s_srl_no : [%s]",s_srl_no);
			TC_write_syslog("\ntm_get_pppm_variant : s_volume_inf : [%s]",s_volume_inf);
			TC_write_syslog("\ntm_get_pppm_variant : s_var_id : [%s]",s_var_id);
			TC_write_syslog("\ntm_get_pppm_variant : s_location : [%s]",s_location);
			TC_write_syslog("\ntm_get_pppm_variant : s_var_name : [%s]\n",s_var_name);

			
			ITK_CALL ( AOM_lock ( table_rows1Tag[iIndex] ) );
			//ITK_CALL ( AOM_refresh ( table_rows1Tag[iIndex],TRUE ) );//lock
			TC_write_syslog("\nrefresh");
			ITK_CALL ( AOM_set_value_string ( table_rows1Tag[iIndex], "t5_VaraintId", s_var_id ) ) ;
			TC_write_syslog("\nAOM_set_value_string");
			ITK_CALL ( AOM_set_value_string ( table_rows1Tag[iIndex], "t5_VariantName", s_var_name ) ) ;
			TC_write_syslog("\nt5_VariantName");
			//ITK_CALL ( AOM_save ( table_rows1Tag[iIndex] ) );
			//ITK_CALL ( AOM_refresh ( table_rows1Tag[iIndex],1 ) );
			ITK_CALL (  AOM_save_without_extensions ( table_rows1Tag[iIndex] ) );
			TC_write_syslog("\nAOM_save_without_extensions");
			ITK_CALL ( AOM_unlock ( table_rows1Tag[iIndex] ) );
			//ITK_CALL ( AOM_refresh ( table_rows1Tag[iIndex],FALSE ) );//unlock
			TC_write_syslog("\ntable_rows1Tag[iIndex],FALSE");
			iIndex = iIndex + 1;

		}
		fclose ( file ) ;
		TC_write_syslog("\nfclose ( file )");
		
		MEM_free(table_rows1Tag);	//Rajan 20-12-2024 instance locked
		TC_write_syslog("\nTable row free");	//Rajan 20-12-2024 instance locked

		//ITK_CALL ( AOM_save(objTag) ); 
		//ITK_CALL ( AOM_refresh ( objTag,TRUE ) );//lock
		//TC_write_syslog("\nAOM_refresh ( objTag,TRUE )");
		//ITK_CALL (  AOM_save_without_extensions(objTag) ); 
		//TC_write_syslog("\nAOM_save_without_extensions(objTag)");
        //ITK_CALL ( AOM_unlock(objTag) ); 
		//ITK_CALL ( AOM_refresh ( objTag,FALSE ) );//unlock
		//TC_write_syslog("\nAOM_refresh ( objTag,FALSE )");
		TC_write_syslog("\ndone");

	}
	else
	{
		printf ( "\ntm_get_pppm_variant : sor_t5_PPPMPrjCode is blank and no of table rows are zero" ) ;//need to delete old rows
		fflush ( stdout) ;
		TC_write_syslog ( "\ntm_get_pppm_variant : sor_t5_PPPMPrjCode_desc is blank and no of table rows are zero " ) ;//need to delete old rows

	}
	return 0;
}
int tm_get_rfi_pppm_variant ( tag_t objTag, char *RfiVerticle, char *rfi_PPPMPrjCode)
{
	char *username = NULL;
	tag_t user_tag = NULLTAG;
	char *userid = NULL;
	char fileName[200] = { 0 };
	char *timestamp = NULL;
	char *var_cmd_to_execute = NULL;
	char *command = NULL;
	FILE* file = NULL ;
	tag_t Currproj = NULLTAG;
	char *curr_proj_name = NULL;
	char **variant_details = NULL;
	char **variant_details_read = NULL;
	int ij = 0;
	char line[250] = { 0 };
	int iIndex = 0;

	char *s_srl_no = NULL;
	char *s_volume_inf = NULL;
	char *s_var_id = NULL;
	char *s_location = NULL;
	char *s_var_name = NULL;

	int n_table_rows = 0;
	tag_t *table_rowsTag = NULLTAG;
	tag_t *table_rows1Tag = NULLTAG;
	int NewLevel = 0;
	const char *table_property_name = "t5_RFI_Var_table";
	int num_rows_to_append = 0;
	char *sAutoSOR_CC_path = NULL;
	char hostbuffer[256];

	int n_found_SOR_PF_info = 0;
	int n_found_SOR_PF_info1 = 0;
	char *tcua_uname = NULL;
	char *tcua_pf_file = NULL;
	char *info2 = NULL;
	char *info22 = NULL;
	char *shell_path = NULL;
	char *pppm_file_path = NULL;

	host_tcua(hostbuffer);

	printf ( "\nRFI variant chg hostbuffer : %s",hostbuffer );

	tcua_uname = ( char * ) MEM_alloc ( 50 * sizeof ( char ) );
	tcua_pf_file = ( char * ) MEM_alloc (200* sizeof ( char ) );
	pppm_file_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	shell_path = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info2 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info22 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	
	n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PWFILE", "PATH", tcua_uname, tcua_pf_file );
	if ( n_found_SOR_PF_info < 0 )
	{
		TC_write_syslog ( "\nRFI variant chg Create hostname username and password file control object for host : %s",hostbuffer ) ;
		return 0;
	}

	printf ( "\nhostbuffer : %s",hostbuffer );
	printf ("\nRFI variant chg : rfi_PPPMPrjCode before : [%s]",rfi_PPPMPrjCode);
	TC_write_syslog ("\nRFI variant chg : rfi_PPPMPrjCode before : [%s]",rfi_PPPMPrjCode);


	if ( tc_strcmp ( rfi_PPPMPrjCode, "" ) == 0 )
	{
		printf ( "\nRFI variant chg : rfi_PPPMPrjCode is null select from drop down" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nRFI variant chg  : rfi_PPPMPrjCode is null select from drop down" ) ;
		return -1;
	}

	ITK_CALL ( PREF_ask_char_value ( "AutoSOR_CC_path", 0 , &sAutoSOR_CC_path ) ) ;//preference
		
	printf("\nRFI variant chg  : Project code after strtok : [%s]",rfi_PPPMPrjCode); fflush ( stdout) ;
	TC_write_syslog ("\nRFI variant chg : rfi_PPPMPrjCode after strtok : [%s]",rfi_PPPMPrjCode);
	
	ITK_CALL ( POM_get_user ( &username, &user_tag ) ) ;
	ITK_CALL ( SA_ask_user_identifier2 ( user_tag, &userid ) ) ;
	printf ("\nRFI variant chg  : Logged in user: [%s] [%s]",userid,username);fflush(stdout);
	TC_write_syslog ("\nRFI variant chg  : Logged in user: [%s] [%s]",userid,username);fflush(stdout);

	n_found_SOR_PF_info = tm_check_info_control_object ( "AUTOSOR_PPPMFILE","PPPM_CODE", pppm_file_path, info22 );

	if ( n_found_SOR_PF_info < 0 )
	{
		TC_write_syslog ( "\nCreating PPPM code file on common location" ) ;
		return 0;
	}

	n_found_SOR_PF_info1 = tm_check_info_control_object ( "AUTOSOR_SHELL", "PPPM_CODE_VARIANT", shell_path, info2 );

	if ( n_found_SOR_PF_info1 < 0 )
	{
		TC_write_syslog ( "\nexecuting shell for PPPM code info" ) ;
		return 0;
	}

	timestamp = time_stamp ( ) ;
	sprintf( fileName, "/%s/pppm_var_%s_%s_%s.txt",pppm_file_path, userid,RfiVerticle,timestamp );
	//sprintf( fileName, "/%s/pppm_var_%s_%s.txt",pppm_file_path, userid,RfiVerticle );
	printf ( "\nRFI variant chg  : fileName : [%s]", fileName ); fflush ( stdout) ;
	TC_write_syslog ( "\nRFI variant chg  : fileName : [%s]", fileName );
	command = ( char * ) MEM_alloc ( 500 * sizeof ( char ) ) ;
	

	if (access(shell_path, F_OK) == 0) 
	{
		printf ("\nshell_path : [%s]",shell_path);
		TC_write_syslog ("\nshell_path : [%s]",shell_path);
		sprintf ( command, "%s/PPPMVariantProdLineInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"",shell_path, RfiVerticle, rfi_PPPMPrjCode, fileName, tcua_uname, tcua_pf_file ) ;
		system( command );
	} 
	else 
	{
	    // file doesn't exist
		int tmp_n_found_SOR_PF_info1 = 0;
		char *shell_path_TMP_PATH = NULL;
		char *info2_TMP_PATH = NULL;


		shell_path_TMP_PATH = ( char * ) MEM_alloc (200* sizeof ( char ) );
		info2_TMP_PATH = ( char * ) MEM_alloc (200* sizeof ( char ) );

		tmp_n_found_SOR_PF_info1 = tm_check_info_control_object ( "AUTOSOR_SHELL_TMP_PATH", "PPPM_CODE_VARIANT_TMP_PATH", shell_path_TMP_PATH, info2_TMP_PATH );

		if ( tmp_n_found_SOR_PF_info1 < 0 )
		{
			TC_write_syslog ( "\nexecuting shell for rfi PPPM code info" ) ;
			return 0;
		}
		printf ("\nshell_path_TMP_PATH : [%s]",shell_path_TMP_PATH);
		TC_write_syslog ("\nshell_path_TMP_PATH : [%s]",shell_path_TMP_PATH);
		sprintf ( command, "%s/PPPMVariantProdLineInfo.sh -d=\"%s\" -m=\"%s\" -f=\"%s\" -u=%s -pf=\"%s\"",shell_path_TMP_PATH,RfiVerticle, rfi_PPPMPrjCode, fileName, tcua_uname, tcua_pf_file ) ;
		system( command );
	
	}

	printf ( "\nRFI variant chg  : var_cmd_to_execute : [%s]", command ); fflush ( stdout) ;
	TC_write_syslog ( "\nRFI variant chg  : var_cmd_to_execute : [%s]", command );

	file = fopen(fileName, "r");

	if ( !file )
	{
		printf("\nRFI variant chg  : Unable to open1 : [%s] ", fileName);fflush ( stdout ) ;
		TC_write_syslog("\nRFI variant chg  : Unable to open1 : [%s] ", fileName);fflush ( stdout ) ;
		return -1;
	}

	variant_details = (char **)MEM_alloc (200 * sizeof(char*));//no of project
	while ( fgets ( line, sizeof ( line ), file ) )
	{
		line[tc_strlen(line)-2] = '\0';
		variant_details[ij] = (char *) MEM_alloc ( 200 );	//project desc length
		tc_strcpy ( variant_details[ij], line ) ;
		printf("\nvariant_details[ij] : [%s] tc_strlen(variant_details[ij]) : [%d]", variant_details[ij],tc_strlen(variant_details[ij])); fflush ( stdout ) ;
		TC_write_syslog("\nvariant_details[ij] : [%s] tc_strlen(variant_details[ij]) : [%d]", variant_details[ij],tc_strlen(variant_details[ij])); fflush ( stdout ) ;
		ij = ij + 1;
	}
	fclose ( file ) ;

	printf("\nRFI variant chg  : Number of variant found in file : [%d]", ij ); fflush ( stdout) ;
	TC_write_syslog("\nRFI variant chg  : Number of variant found in file : [%d]", ij );

	//information same file read twice first for to count no of records

	file = fopen(fileName, "r");

	if ( !file )
	{
		printf("\nRFI variant chg  : Unable to open2 : [%s] ", fileName);fflush ( stdout ) ;
		TC_write_syslog("\nRFI variant chg  : Unable to open2 : [%s] ", fileName);fflush ( stdout ) ;
		return -1;
	}

	ITK_CALL ( AOM_ask_table_rows ( objTag, "t5_RFI_Var_table", &n_table_rows, &table_rowsTag ) ) ;
	printf ( "\nRFI variant chg  : no of table rows are %d \n", n_table_rows ) ;//need to delete old rows
	fflush ( stdout) ;
	TC_write_syslog ( "\nRFI variant chg  : no of table rows are %d \n", n_table_rows ) ;//need to delete old rows

	if ( n_table_rows > 0 )
	{

		TC_write_syslog ( "\nRFI variant chg  : deleting old variant for PPPM project code selected \n" ) ;//need to delete old rows
		//ITK_CALL ( AOM_lock(objTag) ) ;	//Shubham commented on 23-jan-2025
		ITK_CALL ( AOM_delete_table_rows(objTag, "t5_RFI_Var_table", 0, n_table_rows) );
		//ITK_CALL ( AOM_save_without_extensions(objTag) );		//Shubham commented on 23-jan-2025
		//ITK_CALL ( AOM_unlock(objTag) );	//Shubham commented on 23-jan-2025
		
		TC_write_syslog ( "\nRFI variant chg  : deleting old variant for previous PPPM project code completed... \n" ) ;//need to delete old rows
        
	}


	if ( tc_strcmp ( rfi_PPPMPrjCode, "" ) != 0 )//pppm project is not blank
	{
		num_rows_to_append = ij ;
		//ITK_CALL ( AOM_lock ( objTag ) ) ;	//Shubham commented on 23-jan-2025
		ITK_CALL ( AOM_append_table_rows ( objTag, table_property_name,num_rows_to_append, &NewLevel, &table_rows1Tag ) ) ;
		
		//ITK_CALL (  AOM_save_without_extensions(objTag) ); //save	//Shubham commented on 23-jan-2025
		TC_write_syslog("\nRFIsorobjTag AOM_append_table_rows");
		//ITK_CALL ( AOM_unlock ( objTag ) );//unlock	//Shubham commented on 23-jan-2025
		
		variant_details_read = (char **)MEM_alloc (200 * sizeof(char*));//no of project
		while ( fgets ( line, sizeof ( line ), file ) )
		{
			line[tc_strlen(line)-2] = '\0';
			variant_details_read[iIndex] = (char *) MEM_alloc ( 200 );	//project desc length
			tc_strcpy ( variant_details_read[iIndex], line ) ;
			
			s_srl_no = tc_strtok ( variant_details_read[iIndex], "^" );
			s_volume_inf = tc_strtok ( NULL, "^" );
			s_var_id = tc_strtok (  NULL, "^" );
			s_location = tc_strtok (  NULL, "^" );
			s_var_name = tc_strtok (  NULL, "^" );
			
			TC_write_syslog("\nRFI variant chg  : s_srl_no     : [%s]",s_srl_no);
			TC_write_syslog("\nRFI variant chg  : s_volume_inf : [%s]",s_volume_inf);
			TC_write_syslog("\nRFI variant chg  : s_var_id     : [%s]",s_var_id);
			TC_write_syslog("\nRFI variant chg  : s_location   : [%s]",s_location);
			TC_write_syslog("\nRFI variant chg  : s_var_name   : [%s]\n",s_var_name);
			
			ITK_CALL ( AOM_lock ( table_rows1Tag[iIndex] ) );
			TC_write_syslog("\nrfi prop lock");
			ITK_CALL ( AOM_set_value_string ( table_rows1Tag[iIndex], "t5_VarID", s_var_id ) ) ;//t5_VarID
			TC_write_syslog("\nrfi AOM_set_value_string");
			ITK_CALL ( AOM_set_value_string ( table_rows1Tag[iIndex], "t5_VarName", s_var_name ) ) ;//t5_VarName
			TC_write_syslog("\nrfi t5_VariantName");
			ITK_CALL (  AOM_save_without_extensions ( table_rows1Tag[iIndex] ) );
			TC_write_syslog("\nrfi AOM_save_without_extensions");
			ITK_CALL ( AOM_unlock ( table_rows1Tag[iIndex] ) );
			TC_write_syslog("\nrfi table_rows1Tag[iIndex],FALSE");
			iIndex = iIndex + 1;

		}
		fclose ( file ) ;
		TC_write_syslog("\nfclose ( file )");
		TC_write_syslog("\ndone");
	}
	else
	{
		printf ( "\nRFI variant chg  : rfi_PPPMPrjCode is blank and no of table rows are zero" ) ;//need to delete old rows
		fflush ( stdout) ;
		TC_write_syslog ( "\nRFI variant chg  : rfi_PPPMPrjCode_desc is blank and no of table rows are zero " ) ;//need to delete old rows
	}
	return 0;
}
extern DLLAPI int SOR_save_method_post ( METHOD_message_t *m, va_list args )
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	//char type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	const char *reason = "";
	const char *change_id = "";
	const char *dir_name = "";
	char *sor_t5_PPPMPrjCode = NULL;
	char *SOR_validation = NULL;

	//variant code
	int n_table_rows = 0;
	tag_t *table_rowsTag = NULLTAG;
	tag_t *table_rows1Tag = NULLTAG;
	int NewLevel = 0;
	const char *table_property_name = "t5_SORVar";
	int num_rows_to_append = 5;
	int row_index = 0;
	int iCntr = 0 ;
	char var_id [30] = { 0 };
	char var_name [50] = { 0 };
	//char *sor_t5_PPPMPrjCode = NULL;
	char *dml_project_code = NULL;

	
	char *PPPMPrjCodeDetailval = NULL ;
	PPPMPrjCodeDetailval = ( char * ) MEM_alloc ( 25000 * sizeof ( char ) ) ;	//project details for input pppm project
	//variant code

	ITK_CALL ( TCTYPE_ask_object_type ( objTag, &objTypeTag ) ) ;
	//ITK_CALL ( TCTYPE_ask_name ( objTypeTag, type_name ) );
	ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag, &type_name ) );

	printf ( "\nSOR_save_method_post : type_name : [%s]", type_name ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSOR_save_method_post : type_name : [%s]", type_name ) ;
//	if ( tc_strcmp ( type_name, "T5_AutoSorRevision" ) == 0 )
//	{
//		
//		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_BarrelCode", &dml_project_code ) ) ;
//		printf ( "\nSOR_save_method_post : SOR_save_method_post : dml_project_code : [%s]", dml_project_code ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nSOR_save_method_post : SOR_save_method_post : dml_project_code : [%s]", dml_project_code ) ;
//
//		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_PPPMPrjCode", &sor_t5_PPPMPrjCode ) ) ;
//		printf ( "\nSOR_save_method_post : sor_t5_PPPMPrjCode : [%s]", sor_t5_PPPMPrjCode ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nSOR_save_method_post : sor_t5_PPPMPrjCode : [%s]", sor_t5_PPPMPrjCode ) ;
//
//		printf ( "\nSOR_save_method_post : calling get variant info and populate post action\n" ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nSOR_save_method_post : calling get variant info and populate\n" ) ;
//
//		//tm_get_pppm_variant ( objTag, dml_project_code, sor_t5_PPPMPrjCode);
//			
//	}
	return ITK_ok;
}

extern DLLAPI int SOR_save_method_pre ( METHOD_message_t *m, va_list args )
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	//char type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	char *sor_t5_PPPMPrjCode = NULL;
	char *dml_project_code = NULL;
	//---------------------------
	
	ITK_CALL ( TCTYPE_ask_object_type ( objTag, &objTypeTag ) ) ;
	//ITK_CALL ( TCTYPE_ask_name ( objTypeTag, type_name ) );
	ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag, &type_name ) );

	
	printf ( "\nSOR_save_method_pre : type_name : [%s]", type_name ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSOR_save_method_pre : type_name : [%s]", type_name ) ;
//	if ( tc_strcmp ( type_name, "T5_AutoSorRevision" ) == 0 )
//	{
//		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_BarrelCode", &dml_project_code ) ) ;
//		printf ( "\nSOR_save_method_pre : dml_project_code : [%s]", dml_project_code ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nSOR_save_method_pre : dml_project_code : [%s]", dml_project_code ) ;
//
//		ITK_CALL ( AOM_ask_value_string ( objTag, "t5_PPPMPrjCode", &sor_t5_PPPMPrjCode ) ) ;
//		printf ( "\nSOR_save_method_pre : sor_t5_PPPMPrjCode pre : [%s]", sor_t5_PPPMPrjCode ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nSOR_save_method_pre : sor_t5_PPPMPrjCode pre : [%s]", sor_t5_PPPMPrjCode ) ;
//
//		//tm_get_pppm_variant ( objTag, dml_project_code, sor_t5_PPPMPrjCode);
//	}
	return ITK_ok;
}

//venkat
char* subString (char* mainStringf ,int fromCharf,int toCharf)
{
	int i;
	char *retStringf;
	retStringf = (char*) malloc(200);
	for(i=0; i < toCharf; i++ )
              *(retStringf+i) = *(mainStringf+i+fromCharf);
	*(retStringf+i) = '\0';
	return retStringf;
}
;

void get_CtrlVal_MBOMAPLStateInf (char* Plantname,char* APLLifeCylcleWrkState ,char APLLifeCylcleRevwState[40] ) //check5
{
	char    *qry_entryCntrl[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl= (char **) MEM_alloc(5 * sizeof(char *));

	tag_t			qryTagCntrl				= NULLTAG;
	tag_t			*list_of_WSO_cntrl_tags	= NULLTAG;
	char*			MbomAPlwrk				= NULL;
	char*			MbomAPlrev				= NULL;
	int				n_entryCntrl			= 3;
	int				control_number_found	= 0;
	int				ifail	= 0;

	printf("\n plant name or Owner: %s\n",Plantname);fflush(stdout);

	if(QRY_find2("Control Objects...", &qryTagCntrl));
	if (qryTagCntrl)
	{
		printf("\n Control Object Query Found \n");fflush(stdout);
		qry_valuesCntrl[0]="APLStateInf";
		qry_valuesCntrl[1]=Plantname;
		qry_valuesCntrl[2]="0";
				
		if(QRY_execute(qryTagCntrl, n_entryCntrl, qry_entryCntrl, qry_valuesCntrl, &control_number_found, &list_of_WSO_cntrl_tags));
	}
	else
	{
		printf("\n Control Object Query not Found \n");fflush(stdout);
	}	
			
	printf("\n control_number_found is : %d\n",control_number_found);fflush(stdout);

	if(control_number_found>0)
	{
				
		ITK_CALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo1", &MbomAPlrev));
		ITK_CALL(AOM_ask_value_string( list_of_WSO_cntrl_tags[0], "t5_Userinfo2", &MbomAPlwrk));
		printf("\n APl Lifecycle working: %s\n",MbomAPlwrk);fflush(stdout);
		printf("\n APl Lifecycle Review: %s\n",MbomAPlrev);fflush(stdout);
	
		if(tc_strlen(MbomAPlwrk)>0) 
		{
			tc_strcpy(APLLifeCylcleWrkState,MbomAPlwrk);
		}

		if(tc_strlen(MbomAPlrev)>0) 
		{
			tc_strcpy(APLLifeCylcleRevwState,MbomAPlrev);
		}
		
	}
	else
	{
		tc_strcpy(APLLifeCylcleWrkState,"T5_LcsAPLWrkg");
		tc_strcpy(APLLifeCylcleRevwState,"T5_LcsAplReview");
				
	}


}

extern DLLAPI int sor_checkin_method(METHOD_message_t *m, va_list args)
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	//char type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	char *sor_t5_PPPMPrjCode = NULL;
	char *sor_t5_CtrlCommodity = NULL;
	char *sor_t5_CtrlSorCat = NULL;
	char *sor_t5_CtrlProcessType = NULL;
	char *Release_status_SOR = NULL;
	char *st5_OwningG = NULL;
	tag_t rel_status_SOR		   = NULLTAG;
	logical retain_released_date_SOR = TRUE;
	int tm_AutoSOR_checkin = 0;

	 char *PlantName		= NULL;
	 char	APLLifeCylcleWrkState[40];
	char	APLLifeCylcleRevwState[40];

	tag_t *table_rows = NULLTAG;
	int ntablerows = 0;
	int i = 0;
	char *st5_Quantity = NULL;
	char *st5_ApplicableVC = NULL;
	char *st5_Dom = NULL;
	char *st5_IB = NULL;
	char *num  = NULL;

	ITK_CALL ( TCTYPE_ask_object_type ( objTag, &objTypeTag ) ) ;
	//ITK_CALL ( TCTYPE_ask_name ( objTypeTag, type_name ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag, &type_name ) ) ;

	//t5_BarrelCode



	if ( tc_strcmp ( type_name,"T5_AutoSorRevision" ) == 0 )
	{


		tm_AutoSOR_checkin = tm_check_control_object ("AUTOSORCHECKIN","ON");
		
		printf("\ntm_AutoSOR_checkin : [%d]",tm_AutoSOR_checkin); fflush ( stdout) ;
		TC_write_syslog("\ntm_AutoSOR_checkin : [%d]",tm_AutoSOR_checkin); fflush ( stdout);

		if ( tm_AutoSOR_checkin > 0 )
		{


			ITK_CALL ( AOM_ask_value_string ( objTag, "t5_PPPMPrjCode", &sor_t5_PPPMPrjCode ) ) ;
			printf ( "\nsor_t5_PPPMPrjCode checkin : [%s]", sor_t5_PPPMPrjCode ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nsor_t5_PPPMPrjCode checkin : [%s]", sor_t5_PPPMPrjCode ) ;
			if ( ( sor_t5_PPPMPrjCode == NULL ) || ( tc_strcmp (sor_t5_PPPMPrjCode, "" ) == 0 ) ||  ( tc_strlen (sor_t5_PPPMPrjCode ) == 0 ) )
			{
				EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid PPPM project code from dropdown list");
				printf("\nselect valid PPPM project code from dropdown list\n"); fflush ( stdout) ;
				TC_write_syslog("\nselect valid PPPM project code from dropdown list\n");
				return PLM_error;
			}

			ITK_CALL ( AOM_ask_value_string ( objTag, "t5_CtrlCommodity", &sor_t5_CtrlCommodity  ) ) ;
			printf ( "\nsor_t5_CtrlCommodity checkin : [%s]", sor_t5_CtrlCommodity ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nsor_t5_CtrlCommodity checkin : [%s]", sor_t5_CtrlCommodity ) ;
			if ( ( sor_t5_CtrlCommodity == NULL ) || ( tc_strcmp (sor_t5_CtrlCommodity, "" ) == 0 ) ||  ( tc_strlen (sor_t5_CtrlCommodity ) == 0 ) )
			{
				EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid Commodity from dropdown list");
				printf("\nselect valid Commodity from dropdown list\n"); fflush ( stdout) ;
				TC_write_syslog("\nselect valid Commodity from dropdown list\n");
				return PLM_error;
			}

			ITK_CALL ( AOM_ask_value_string ( objTag, "t5_CtrlSorCat", &sor_t5_CtrlSorCat  ) ) ;
			printf ( "\nsor_t5_CtrlSorCat checkin : [%s]", sor_t5_CtrlSorCat ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nsor_t5_CtrlSorCat checkin : [%s]", sor_t5_CtrlSorCat ) ;
			if ( ( sor_t5_CtrlSorCat == NULL ) || ( tc_strcmp (sor_t5_CtrlSorCat, "" ) == 0 ) ||  ( tc_strlen (sor_t5_CtrlSorCat ) == 0 ) )
			{
				EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid SOR Category from dropdown list");
				printf("\nselect valid SOR Category from dropdown list\n"); fflush ( stdout) ;
				TC_write_syslog("\nselect valid SOR Category from dropdown list\n");
				return PLM_error;
			}

			ITK_CALL ( AOM_ask_value_string ( objTag, "t5_CtrlProcessType", &sor_t5_CtrlProcessType   ) ) ;
			printf ( "\nsor_t5_CtrlProcessType  checkin : [%s]", sor_t5_CtrlProcessType  ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nsor_t5_CtrlProcessType  checkin : [%s]", sor_t5_CtrlProcessType  ) ;
			if ( ( sor_t5_CtrlProcessType  == NULL ) || ( tc_strcmp (sor_t5_CtrlProcessType , "" ) == 0 ) ||  ( tc_strlen (sor_t5_CtrlProcessType  ) == 0 ) )
			{
				EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid Process Type from dropdown list");
				printf("\nselect valid Process Type from dropdown list\n"); fflush ( stdout) ;
				TC_write_syslog("\nselect valid Process Type from dropdown list\n");
				return PLM_error;
			}
            //add shrivardhan
			ITK_CALL ( AOM_ask_table_rows(objTag, "t5_SORVar", &ntablerows, &table_rows) );
            printf("\nsor_t5_variant  checkin : [%d]",ntablerows);fflush(stdout);
			TC_write_syslog("\nsor_t5_variant  checkin : [%d]",ntablerows);

			if (tc_strstr(sor_t5_CtrlSorCat,"Category")!=NULL)
			{
				int varflagPv = 0;
                for (i=0; i<ntablerows; i++)
			    {
					printf("\n********************************************************");fflush(stdout);
			    	ITK_CALL ( AOM_UIF_ask_value(table_rows[i],"t5_Quantity",&st5_Quantity));
					printf("\nt5_Quantity : [%s]",st5_Quantity);fflush(stdout);

					ITK_CALL ( AOM_UIF_ask_value(table_rows[i],"t5_ApplicableVC",&st5_ApplicableVC));
					printf("\nt5_ApplicableVC : [%s]",st5_ApplicableVC);fflush(stdout);
					//if (asprintf(&num, "%d", st5_Quantity) == -1) {
                    //perror("asprintf");
                    //} 
					//printf("\nnum : [%s]",num);fflush(stdout);
					//if (st5_Quantity >= 0 )
					if (tc_strcmp ( st5_Quantity, "" ) == 0 || tc_strcmp ( st5_Quantity, NULL) == 0 || tc_strcmp ( st5_ApplicableVC, "" ) == 0 || tc_strcmp ( st5_ApplicableVC, NULL) == 0)
					{
                        printf("\nst5_Quantity : [%s]",st5_Quantity);fflush(stdout);
			            TC_write_syslog("\nst5_Quantity : [%s]",st5_Quantity);
						varflagPv++;
					}
			    }
                printf("\n ntablerows : [%d]",ntablerows);fflush(stdout);
				printf("\n varflagPv : [%d]",varflagPv);fflush(stdout);
				TC_write_syslog("\n ntablerows : [%d]",ntablerows);
				TC_write_syslog("\n varflagPv : [%d]",varflagPv);
				if (varflagPv > 0)
				{
					EMH_store_error_s1(EMH_severity_error,PLM_error,"Fill the details of All Variant (Applicable and Quentity is mandatory)");
				    printf("\nFill the details of Variant 1\n"); fflush ( stdout) ;
				    TC_write_syslog("\nFill the details of Variant 1\n");
				    return PLM_error;

				}

			}
			if (tc_strstr(sor_t5_CtrlSorCat,"CAT")!=NULL)
			{
				int varflagCv = 0;
                for (i=0; i<ntablerows; i++)
			    {
				    ITK_CALL ( AOM_ask_value_string(table_rows[i],"t5_Dom",&st5_Dom));
				    ITK_CALL ( AOM_ask_value_string(table_rows[i],"t5_IB",&st5_IB));
				    //ITK_CALL ( AOM_ask_value_int(table_rows[i],"t5_IB",&st5_IB));
					printf("\nst5_Dom : [%s]",st5_Dom);fflush(stdout);
			            TC_write_syslog("\nst5_Dom : [%s]",st5_Dom);
						printf("\nst5_IB : [%s]",st5_IB);fflush(stdout);
			            TC_write_syslog("\nst5_IB : [%s]",st5_IB);

					if (tc_strcmp ( st5_Dom, "" ) == 0 || tc_strcmp ( st5_IB, "" ) == 0 || tc_strcmp ( st5_Dom, NULL ) == 0 ||  tc_strcmp ( st5_IB, NULL ) == 0)
					{
						printf("\nst5_Dom : [%s]",st5_Dom);fflush(stdout);
			            TC_write_syslog("\nst5_Dom : [%s]",st5_Dom);
						printf("\nst5_IB : [%s]",st5_IB);fflush(stdout);
			            TC_write_syslog("\nst5_IB : [%s]",st5_IB);
                         varflagCv++;
					}
				}
				printf("\n ntablerows : [%d]",ntablerows);fflush(stdout);
				printf("\n varflagCv : [%d]",varflagCv);fflush(stdout);
				TC_write_syslog("\n ntablerows : [%d]",ntablerows);
				TC_write_syslog("\n varflagCv : [%d]",varflagCv);
				if (varflagCv > 0)
				{
					EMH_store_error_s1(EMH_severity_error,PLM_error,"Fill the details of All Variant (Value of IB and DOM should be 1 or 0)");
				    printf("\nFill the details of Variant 2\n"); fflush ( stdout) ;
				    TC_write_syslog("\nFill the details of Variant 2\n");
				    return PLM_error;

				}

			}
			
			ITK_CALL ( AOM_UIF_ask_value	( objTag, "owning_group", &st5_OwningG ) ) ;//for MBOM sor creation 
			printf ( "\n owning_group : [%s]", st5_OwningG ) ; fflush ( stdout) ; ///APLJSR

		
			PlantName=subString(st5_OwningG,0,4);
			printf("\n Plant Name:%s",PlantName);fflush(stdout); 


			

			
			if (tc_strstr(st5_OwningG,"MBOM")!=NULL)//FOR mbom
			{
			removeAllReleaseStatus (objTag);
			ITK_CALL ( RELSTAT_create_release_status("T5_MBOMReview",&rel_status_SOR));
			ITK_CALL(RELSTAT_add_release_status(rel_status_SOR,1,&objTag ,retain_released_date_SOR));
				
			}
			else if (tc_strstr(st5_OwningG,"APL")!=NULL)//FOR APL Venkat
			{
				removeAllReleaseStatus (objTag);

						
				get_CtrlVal_MBOMAPLStateInf(PlantName,APLLifeCylcleWrkState,APLLifeCylcleRevwState);  //check6

				printf("\nLifecycle :%s",APLLifeCylcleRevwState);fflush(stdout);
				ITK_CALL ( RELSTAT_create_release_status(APLLifeCylcleRevwState,&rel_status_SOR));
				ITK_CALL(RELSTAT_add_release_status(rel_status_SOR,1,&objTag ,retain_released_date_SOR));
				printf("\nAPL Review stamping on SOR....");fflush(stdout);
				TC_write_syslog("\n Apl Review stamping on SOR....");fflush(stdout);
				
			}
			else
			{
			removeAllReleaseStatus (objTag);
			ITK_CALL ( RELSTAT_create_release_status("T5_LcsReview",&rel_status_SOR));
			ITK_CALL(RELSTAT_add_release_status(rel_status_SOR,1,&objTag ,retain_released_date_SOR));
			}

			
			Release_status_SOR = NULL;
			ITK_CALL(AOM_UIF_ask_value(objTag,"release_status_list",&Release_status_SOR));
			printf ( "\nRelease_status_SOR : [%s]", Release_status_SOR ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nRelease_status_SOR : [%s]", Release_status_SOR ) ; fflush ( stdout) ;
			printf("\nERC Review stamping on SOR....");fflush(stdout);
			TC_write_syslog("\nERC Review stamping on SOR....");fflush(stdout);

		}

		else
		{
			printf("\ntm_AutoSOR_checkin : [%d]",tm_AutoSOR_checkin); fflush ( stdout) ;
			TC_write_syslog("\ntm_AutoSOR_checkin : [%d]",tm_AutoSOR_checkin); fflush ( stdout);
			return 0;
		}
	}

	// RFI sor commodity validation Nikhil
	char *rfi_t5_RFI_Commodity = NULL;
    int tm_RFISOR_checkin = 0;

	if ( tc_strcmp ( type_name,"T5_RfiSorRevision" ) == 0 )
	{

		tm_RFISOR_checkin = tm_check_control_object ("RFISORCHECKIN","ON");
		
		printf("\ntm_RFISOR_checkin : [%d]",tm_RFISOR_checkin); fflush ( stdout) ;
		TC_write_syslog("\ntm_RFISOR_checkin : [%d]",tm_RFISOR_checkin); fflush ( stdout);

		if ( tm_RFISOR_checkin > 0 )
		{
			printf("\nInside PV RFI SOR control object for commodity check-in\n"); fflush ( stdout) ;
			TC_write_syslog("\nInside PV RFI SOR control object for commodity check-in\n"); fflush ( stdout) ;
			
			ITK_CALL ( AOM_ask_value_string ( objTag, "t5_RFI_Commodity", &rfi_t5_RFI_Commodity ) ) ;
			printf ( "\nrfi_t5_RFI_Commodity checkin : [%s]", rfi_t5_RFI_Commodity ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nrfi_t5_RFI_Commodity checkin : [%s]", rfi_t5_RFI_Commodity ) ;
			if ( ( rfi_t5_RFI_Commodity == NULL ) || ( tc_strcmp (rfi_t5_RFI_Commodity, "" ) == 0 ) ||  ( tc_strlen (rfi_t5_RFI_Commodity ) == 0 ) )
			{
				EMH_store_error_s1(EMH_severity_error,PLM_error,"Fill RFI SOR Commodity field before checkin");
				printf("\nFill RFI SOR Commodity field before checkin\n"); fflush ( stdout) ;
				TC_write_syslog("\nFill RFI SOR Commodity field before checkin\n");
				return PLM_error;
			}

		}

		else
		{
			printf("\ntm_RFISOR_checkin : [%d]",tm_RFISOR_checkin); fflush ( stdout) ;
			printf("\ntm_RFISOR_checkin COntrol object not found\n"); fflush ( stdout) ;
			TC_write_syslog("\ntm_RFISOR_checkin : [%d]",tm_RFISOR_checkin); fflush ( stdout);
			return 0;
		}


	}

	return ITK_ok;
}


//removeAllReleaseStatus (tag_t objTag)
int removeAllReleaseStatus (tag_t objTag)
{

	int status_count;
	tag_t* status_list;
	int			st_relList_count		= 0;
	int			Rel_cnt					= 0;
	tag_t*		relstatus_list			= NULLTAG;
	char		*WSO_Name_RelVal		= NULL ;
	tag_t		tReleaseStatusList		= NULLTAG;
	int			n_values				= 0;
	int			cunt1					= 0;
	tag_t*		attr_tags				= NULLTAG;
	logical		*is_it_null				= NULL;
	logical		*is_it_empty			= NULL;
	tag_t		class_id				= NULLTAG;
	char		*class_name				= NULL;
	logical		log1;
	int	ifail = 0;

	printf ( "\ninside t5removeAllReleaseStatus : Removing all the release status" ) ; fflush ( stdout) ;
	TC_write_syslog ( "\ninside t5removeAllReleaseStatus : Removing all the release status" ) ; fflush ( stdout) ;

	ITK_CALL (WSOM_ask_release_status_list(objTag,&status_count,&status_list));

	printf("\n no of Status==%d\n",status_count);;fflush(stdout);
	if(status_count>0)
	{
		//ERROR_CALL (CR_remove_status_from_targets	(status_list[0],rev));
		printf("\n For Status remove...");fflush(stdout);

		ITK_CALL(POM_class_of_instance(objTag,&class_id));
		ITK_CALL(POM_name_of_class(class_id,&class_name));
		printf("\n class_name is :%s\n",class_name);fflush(stdout);

		ITK_CALL(POM_attr_id_of_attr("release_status_list",class_name,&tReleaseStatusList));fflush(stdout);

		ITK_CALL(POM_unload_instances (1,&objTag));
		ITK_CALL(POM_load_instances(1,&objTag,class_id,1));
		ITK_CALL(POM_is_loaded(objTag,&log1));
		if(log1 == 1)
		{
			 printf(" Load Success\n " );
		}
		else
		printf("Load Failure\n"  );

		ITK_CALL( POM_length_of_attr(objTag, tReleaseStatusList, &n_values) );
		printf("\n n_values is :%d\n",n_values);fflush(stdout);
		if(n_values>0)
		{
			ITK_CALL( POM_ask_attr_tags(objTag, tReleaseStatusList, 0, n_values, &attr_tags, &is_it_null, &is_it_empty ));
			printf("\n n_values11 is :%d\n",n_values);fflush(stdout);

			for (cunt1 =  0; cunt1 <n_values; cunt1++)
			{
				printf("\n Inside POM_save_instances is :%d\n",cunt1);fflush(stdout);


				ITK_CALL(POM_remove_from_attr(1,&objTag,tReleaseStatusList,0,1));
				printf("\n cunt1 == 0 removedd is :%d\n",cunt1);fflush(stdout);


				ITK_CALL(POM_save_instances(1,&objTag,1));

				ITK_CALL(POM_refresh_instances(1,&objTag,class_id,2));

				//ITK_CALL(AOM_lock(objTag));

				//ITK_CALL(AOM_save(objTag));
				ITK_CALL(AOM_refresh(objTag,TRUE));
				ITK_CALL(AOM_save_without_extensions(objTag));
				ITK_CALL(AOM_refresh(objTag,FALSE));

			}

			 //ITK_CALL(AOM_unlock(objTag));
			 ITK_CALL(AOM_refresh(objTag,FALSE));
		}
		printf("\n Status removed");;fflush(stdout);
	}
}


//check object in control table
int tm_check_control_object ( char *syscd, char *subsyscd )
{
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_values[2] =  { syscd, subsyscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	//ITK_CALL ( QRY_find ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;

	return n_found ;
}

int tm_check_control_object_ERCLive ( char *syscd, char *DMLprjCode ) //Hrishikesh 12.02.2024
{


	int n_found = 0 ;
	//int n_entries = 2 ;
	int n_entries = 1 ;
	//char *qry_entries[2] = { "SYSCD", "SUBSYSCD" } ;
	char *qry_entries[1] = { "SYSCD" } ;
	//char *qry_values[2] =  { syscd, subsyscd } ;
	char *qry_values[1] =  { syscd } ;
	tag_t query = NULLTAG ;
	tag_t *cntr_objects = NULL ;

	char *ERCInf1   = NULL;
	char *ERCInf2   = NULL;
	char *ERCInf3   = NULL;
	char *ERCInf4   = NULL;
	char *ERCInf5   = NULL;
	char *ERCInf6   = NULL;
	char *ERCInf7   = NULL;
	char *ERCInf8   = NULL;
	char *ERCInf9   = NULL;
	char *ERCInf10  = NULL;
	char *DMLprjCode_str  = NULL;

	DMLprjCode_str = (char *)MEM_alloc(10*sizeof(char));

	tc_strcpy(	DMLprjCode_str, ",");
	tc_strcat(	DMLprjCode_str, DMLprjCode);
	tc_strcat(	DMLprjCode_str, ",");

	printf("\ntm_check_control_object_ERCLive DMLprjCode_str : [%s]",DMLprjCode_str);

	ITK_CALL ( QRY_find2 ( "ControlObjQry", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &cntr_objects ) ) ;
    //printf ( "\n[%s] [%s] n_found : [%d]" ,syscd ,subsyscd ,n_found ) ; fflush ( stdout) ;
    printf ( "\n[%s] n_found : [%d]" ,syscd , n_found ) ; fflush ( stdout) ;
    TC_write_syslog ( "\n[%s] n_found : [%d]" ,syscd , n_found ) ; fflush ( stdout) ;

	if (n_found > 0)
	{
	
		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo1",&ERCInf1));
		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo2",&ERCInf2));
		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo3",&ERCInf3));
		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo4",&ERCInf4));
		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo5",&ERCInf5));
		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo6",&ERCInf6));
		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo7",&ERCInf7));
		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo8",&ERCInf8));
		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_Userinfo9",&ERCInf9));
		ITK_CALL ( AOM_ask_value_string ( cntr_objects[0], "t5_userinfo10",&ERCInf10));


		printf("\nERCInf1  : [%s]",ERCInf1);
		TC_write_syslog("\nERCInf1  : [%s]",ERCInf1);
		printf("\nERCInf2  : [%s]",ERCInf2);
		TC_write_syslog("\nERCInf2  : [%s]",ERCInf2);
		printf("\nERCInf3  : [%s]",ERCInf3);
		TC_write_syslog("\nERCInf3  : [%s]",ERCInf3);
		printf("\nERCInf4  : [%s]",ERCInf4);
		TC_write_syslog("\nERCInf4  : [%s]",ERCInf4);
		printf("\nERCInf5  : [%s]",ERCInf5);
		TC_write_syslog("\nERCInf5  : [%s]",ERCInf5);
		printf("\nERCInf6  : [%s]",ERCInf6);
		TC_write_syslog("\nERCInf6  : [%s]",ERCInf6);
		printf("\nERCInf7  : [%s]",ERCInf7);
		TC_write_syslog("\nERCInf7  : [%s]",ERCInf7);
		printf("\nERCInf8  : [%s]",ERCInf8);
		TC_write_syslog("\nERCInf8  : [%s]",ERCInf8);
		printf("\nERCInf9  : [%s]",ERCInf9);
		TC_write_syslog("\nERCInf9  : [%s]",ERCInf9);
		printf("\nERCInf10 : [%s]",ERCInf10);
		TC_write_syslog("\nERCInf10 : [%s]",ERCInf10);


		if(	(tc_strstr(ERCInf1,DMLprjCode_str) != NULL)||
			(tc_strstr(ERCInf2,DMLprjCode_str) != NULL)||
			(tc_strstr(ERCInf3,DMLprjCode_str) != NULL)||
			(tc_strstr(ERCInf4,DMLprjCode_str) != NULL)||
			(tc_strstr(ERCInf5,DMLprjCode_str) != NULL)||
			(tc_strstr(ERCInf6,DMLprjCode_str) != NULL)||
			(tc_strstr(ERCInf7,DMLprjCode_str) != NULL)||
			(tc_strstr(ERCInf8,DMLprjCode_str) != NULL)||
			(tc_strstr(ERCInf9,DMLprjCode_str) != NULL)||
			(tc_strstr(ERCInf10,DMLprjCode_str) != NULL))
		{

			printf("\nDMLprjCode_str found in control Object");
			TC_write_syslog("\nDMLprjCode_str found in control Object");
			return 1;

		}

	}

	return 0 ;
}
//Venkat Added
void get_MBOM_APL_Dml_Details(tag_t APLDmlRevision,char* Apldml_no,char* Apldml_project_code,char* APLrlz_type,  char* Aplbusiness_unit, char* Aplproduct_line) //venkat check2
{
	
	//int ifail	= 0;
	char* st5_rlstype		= NULL;
	char* st5_cprojectcode	= NULL;
	char* st5_ERCBusiUt		= NULL;
	char* st5_cDRstatus		= NULL;
	char* st5_ProductLine	= NULL;
	char* sitem_id_dml_task_no	= NULL;
	char* DML_No	= NULL;
	//char APLDmltype_name[TCTYPE_name_size_c+1] ;
	tag_t	projobj			= NULLTAG;
	tag_t	APLDml			= NULLTAG;
	tag_t	APLDmlobjTypeTag	= NULLTAG;
	tag_t			classd_id	= NULLTAG;
	char		 *class_name	= NULL;


	 printf ( "\ninside MBOMAPL DML details\n") ;fflush ( stdout) ;

	 ITKCALL(POM_class_of_instance(APLDmlRevision,&classd_id));
	 ITKCALL(POM_name_of_class(classd_id,&class_name));

	 printf("\n class_name found :%s",class_name); fflush(stdout);

	
	if(tc_strcmp ( class_name, "T5_APLDMLRevision" ) == 0)
	{
		ITKCALL(AOM_ask_value_string(APLDmlRevision,"item_id",&DML_No));
		
		//ITK_CALL ( AOM_ask_value_string ( APLDmlRevision, "t5_rlstype", &st5_rlstype ) ) ;
		ITK_CALL ( AOM_ask_value_string ( APLDmlRevision, "t5_EcnType", &st5_rlstype ) ) ;
		ITK_CALL ( AOM_ask_value_string ( APLDmlRevision, "t5_cprojectcode", &st5_cprojectcode ) ) ;
		ITK_CALL ( AOM_ask_value_string ( APLDmlRevision, "t5_ERCBusiUt", &st5_ERCBusiUt ) ) ;
		ITK_CALL ( AOM_ask_value_string ( APLDmlRevision, "t5_cDRstatus", &st5_cDRstatus ) ) ;
		ITK_CALL ( AOM_ask_value_string ( APLDmlRevision, "t5_ProductLine", &st5_ProductLine ) ) ;
	}

	tc_strcpy ( Aplbusiness_unit, st5_ERCBusiUt ) ;
	tc_strcpy ( Aplproduct_line, st5_ProductLine ) ;
	tc_strcpy ( APLrlz_type, st5_rlstype ) ;
	tc_strcpy ( Apldml_no, DML_No ) ;
	tc_strcpy ( Apldml_project_code, st5_cprojectcode ) ;

	printf("\n APL DML_NO ...%s\n", DML_No);fflush(stdout);
	printf ( "\nst5_rlstype : [%s]", st5_rlstype ) ;//check valid release types
	fflush ( stdout) ;
	TC_write_syslog ( "\nst5_rlstype : [%s]", st5_rlstype ) ;
	printf ( "\nst5_cprojectcode : [%s]", st5_cprojectcode ) ;//can allow to skip project from sor creation
	fflush ( stdout) ;
	TC_write_syslog ( "\nst5_cprojectcode : [%s]", st5_cprojectcode ) ;
	printf ( "\nst5_ERCBusiUt : [%s]", st5_ERCBusiUt ) ;//valid business unit for SOR
	fflush ( stdout) ;
	TC_write_syslog ( "\nst5_ERCBusiUt : [%s]", st5_ERCBusiUt ) ;
	printf ( "\nst5_cDRstatus : [%s]", st5_cDRstatus ) ;
	fflush ( stdout) ;
	TC_write_syslog ( "\nst5_cDRstatus : [%s]", st5_cDRstatus ) ;
	printf ( "\nst5_ProductLine : [%s]", st5_ProductLine ) ;//vertical for PPPM project
	fflush ( stdout) ;
	TC_write_syslog ( "\nst5_ProductLine : [%s]", st5_ProductLine ) ;

	ITK_CALL(PROJ_find(st5_cprojectcode,&projobj));
	ITK_CALL(SA_set_current_project(projobj));
		
	printf ( "\nDefault Project on SOR object : [%s]", st5_cprojectcode ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nDefault Project on SOR object : [%s]", st5_cprojectcode ) ;

	
		
//	ITEM_ask_item_of_rev ( APLDmlRevision, &APLDml ) ;
//	printf ( "\ninside MBOMAPL DML details11\n" ) ;fflush ( stdout) ;
//	ITK_CALL(TCTYPE_ask_object_type(APLDml,&APLDmlobjTypeTag));
//	ITK_CALL(TCTYPE_ask_name(APLDmlobjTypeTag,APLDmltype_name));
//	printf ( "\nDmltype_name : [%s]", APLDmltype_name ) ; fflush ( stdout) ;
//	TC_write_syslog ( "\nDmltype_name : [%s]", APLDmltype_name ) ;
//
//	if ( tc_strcmp ( APLDmltype_name, "T5_APLDML" ) == 0 )
//	{
//		ITK_CALL(AOM_ask_value_string(APLDml,"item_id",&sitem_id_dml_task_no));
//		printf ( "\nsitem_id_dml_task_no : [%s]", sitem_id_dml_task_no ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nsitem_id_dml_task_no : [%s]", sitem_id_dml_task_no ) ;
//
//		tc_strcpy ( Apldml_no, sitem_id_dml_task_no ) ;
//		tc_strcpy ( Apldml_project_code, st5_cprojectcode ) ;
//
//		printf ( "\nsdml_no : [%s]", Apldml_no ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\nsdml_no : [%s]", Apldml_no ) ;
//		printf ( "\ns_dml_project_code : [%s]", Apldml_project_code ) ; fflush ( stdout) ;
//		TC_write_syslog ( "\ns_dml_project_code : [%s]", Apldml_project_code ) ;
//	}
	
}

//dbk added code for SOR
int Get_dml_details ( tag_t task_tag, char *sdml_no, char *s_dml_project_code, char *dml_rlz_type, char *business_unit, char *product_line )
{
	int Tskcount = 0 ;
	int	ifail = 0;
	tag_t *ERCDmlRevision = NULLTAG;
	tag_t ERCDml = NULLTAG;
	tag_t MBOMDml = NULLTAG;
	char *st5_rlstype = NULL;
	char *st5_cprojectcode = NULL;
	char *st5_ERCBusiUt = NULL;
	char *st5_cDRstatus = NULL;
	char *sitem_id_dml_task_no = NULL;
	char *st5_ProductLine = NULL;
	tag_t dml_tsk_rel_type = NULLTAG;
	tag_t objTypeTag = NULLTAG;
	tag_t ERCDmlobjTypeTag = NULLTAG;
	tag_t MBOMDmlobjTypeTag = NULLTAG;
	//char type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	//char ERCDmltype_name[TCTYPE_name_size_c+1] ;
	char *ERCDmltype_name = NULL;
	//char MBOMDmltype_name[TCTYPE_name_size_c+1] ;
	char *MBOMDmltype_name = NULL ;
	tag_t projobj = NULLTAG;

	//VENKAT 

	tag_t	APLDmlRevision	= NULLTAG;


	//tag_t * 	item
	ITK_CALL ( GRM_find_relation_type ( "T5_DMLTaskRelation", &dml_tsk_rel_type ) ) ;
	ITK_CALL ( GRM_list_primary_objects_only ( task_tag, dml_tsk_rel_type, &Tskcount, &ERCDmlRevision ) ) ;//task to dml traversal
	printf ( "\nTask count : [%d]", Tskcount ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nTask count : [%d]", Tskcount ) ;
	if ( Tskcount > 0 )
	{
		ITK_CALL ( TCTYPE_ask_object_type (ERCDmlRevision[0], &objTypeTag ) ) ;
		//ITK_CALL ( TCTYPE_ask_name ( objTypeTag, type_name ) ) ;
		ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag, &type_name ) ) ;
		printf ( "\ntask type_name : [%s]", type_name ) ; fflush ( stdout) ;
		TC_write_syslog ( "\ntask type_name : [%s]", type_name ) ;

		if ( tc_strcmp ( type_name, "ChangeRequestRevision" ) == 0 )
		{

			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_rlstype", &st5_rlstype ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_cprojectcode", &st5_cprojectcode ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_ERCBusiUt", &st5_ERCBusiUt ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_cDRstatus", &st5_cDRstatus ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_ProductLine", &st5_ProductLine ) ) ;

			tc_strcpy ( business_unit, st5_ERCBusiUt ) ;
			tc_strcpy ( product_line, st5_ProductLine ) ;
			tc_strcpy ( dml_rlz_type, st5_rlstype ) ;


			printf ( "\nst5_rlstype : [%s]", st5_rlstype ) ;//check valid release types
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_rlstype : [%s]", st5_rlstype ) ;//check valid release types
			printf ( "\nst5_cprojectcode : [%s]", st5_cprojectcode ) ;//can allow to skip project from sor creation
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_cprojectcode : [%s]", st5_cprojectcode ) ;//can allow to skip project from sor creation
			printf ( "\nst5_ERCBusiUt : [%s]", st5_ERCBusiUt ) ;//valid business unit for SOR
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_ERCBusiUt : [%s]", st5_ERCBusiUt ) ;//valid business unit for SOR
			printf ( "\nst5_cDRstatus : [%s]", st5_cDRstatus ) ;
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_cDRstatus : [%s]", st5_cDRstatus ) ;
			printf ( "\nst5_ProductLine : [%s]", st5_ProductLine ) ;//vertical for PPPM project
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_ProductLine : [%s]", st5_ProductLine ) ;//vertical for PPPM project

			ITK_CALL(PROJ_find(st5_cprojectcode,&projobj));
			ITK_CALL(SA_set_current_project(projobj));
		
			printf ( "\nDefault Project on SOR object : [%s]", st5_cprojectcode ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nDefault Project on SOR object : [%s]", st5_cprojectcode ) ;


			ITEM_ask_item_of_rev ( ERCDmlRevision[0], &ERCDml ) ;

			ITK_CALL(TCTYPE_ask_object_type(ERCDml,&ERCDmlobjTypeTag));
			//ITK_CALL(TCTYPE_ask_name(ERCDmlobjTypeTag,ERCDmltype_name));
			ITK_CALL(TCTYPE_ask_name2(ERCDmlobjTypeTag,&ERCDmltype_name));
			printf ( "\nERCDmltype_name : [%s]", ERCDmltype_name ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nERCDmltype_name : [%s]", ERCDmltype_name ) ;

			if ( tc_strcmp ( ERCDmltype_name, "ChangeRequest" ) == 0 )
			{

				ITK_CALL(AOM_ask_value_string(ERCDml,"item_id",&sitem_id_dml_task_no));
				printf ( "\nsitem_id_dml_task_no : [%s]", sitem_id_dml_task_no ) ; fflush ( stdout) ;
				TC_write_syslog ( "\nsitem_id_dml_task_no : [%s]", sitem_id_dml_task_no ) ;

				tc_strcpy ( sdml_no, sitem_id_dml_task_no ) ;
				tc_strcpy ( s_dml_project_code, st5_cprojectcode ) ;

				printf ( "\nsdml_no : [%s]", sdml_no ) ; fflush ( stdout) ;
				TC_write_syslog ( "\nsdml_no : [%s]", sdml_no ) ;
				printf ( "\ns_dml_project_code : [%s]", s_dml_project_code ) ; fflush ( stdout) ;
				TC_write_syslog ( "\ns_dml_project_code : [%s]", s_dml_project_code ) ;
			}
		}
		else if ( tc_strcmp ( type_name, "T5_MBOMDMLRevision" ) == 0 )
		{
			printf ( "\nInsyde T5_MBOMDMLRevision " ) ;fflush ( stdout) ;

			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_MBOMRlzType", &st5_rlstype ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_cprojectcode", &st5_cprojectcode ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_ERCBusiUt", &st5_ERCBusiUt ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_cDRstatus", &st5_cDRstatus ) ) ;
			ITK_CALL ( AOM_ask_value_string ( ERCDmlRevision[0], "t5_ProductLine", &st5_ProductLine ) ) ;

			tc_strcpy ( business_unit, st5_ERCBusiUt ) ;
			tc_strcpy ( product_line, st5_ProductLine ) ;
			tc_strcpy ( dml_rlz_type, st5_rlstype ) ;

			printf ( "\nst5_rlstype : [%s]", st5_rlstype ) ;//check valid release types
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_rlstype : [%s]", st5_rlstype ) ;//check valid release types
			printf ( "\nst5_cprojectcode : [%s]", st5_cprojectcode ) ;//can allow to skip project from sor creation
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_cprojectcode : [%s]", st5_cprojectcode ) ;//can allow to skip project from sor creation
			printf ( "\nst5_ERCBusiUt : [%s]", st5_ERCBusiUt ) ;//valid business unit for SOR
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_ERCBusiUt : [%s]", st5_ERCBusiUt ) ;//valid business unit for SOR
			printf ( "\nst5_cDRstatus : [%s]", st5_cDRstatus ) ;
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_cDRstatus : [%s]", st5_cDRstatus ) ;
			printf ( "\nst5_ProductLine : [%s]", st5_ProductLine ) ;//vertical for PPPM project
			fflush ( stdout) ;
			TC_write_syslog ( "\nst5_ProductLine : [%s]", st5_ProductLine ) ;//vertical for PPPM projec

			//ITK_CALL(PROJ_find(st5_cprojectcode,&projobj));
			//ITK_CALL(SA_set_current_project(projobj));

			ITEM_ask_item_of_rev ( ERCDmlRevision[0], &MBOMDml ) ;

			ITK_CALL(TCTYPE_ask_object_type(MBOMDml,&MBOMDmlobjTypeTag));
			//ITK_CALL(TCTYPE_ask_name(MBOMDmlobjTypeTag,MBOMDmltype_name));
			ITK_CALL(TCTYPE_ask_name2(MBOMDmlobjTypeTag,&MBOMDmltype_name));
			printf ( "\nMBOMDML Name [%s]", MBOMDmltype_name ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nMBOMDML Name : [%s]", MBOMDmltype_name ) ;

			if ( tc_strcmp ( MBOMDmltype_name, "T5_MBOMDML" ) == 0 )
			{

				ITK_CALL(AOM_ask_value_string(MBOMDml,"item_id",&sitem_id_dml_task_no));
				printf ( "\nsitem_id_dml_task_no : [%s]", sitem_id_dml_task_no ) ; fflush ( stdout) ;
				TC_write_syslog ( "\nsitem_id_dml_task_no : [%s]", sitem_id_dml_task_no ) ;

				tc_strcpy ( sdml_no, sitem_id_dml_task_no ) ;
				tc_strcpy ( s_dml_project_code, st5_cprojectcode ) ;

				printf ( "\nsdml_no : [%s]", sdml_no ) ; fflush ( stdout) ;
				TC_write_syslog ( "\nsdml_no : [%s]", sdml_no ) ;
				printf ( "\ns_dml_project_code : [%s]", s_dml_project_code ) ; fflush ( stdout) ;
				TC_write_syslog ( "\ns_dml_project_code : [%s]", s_dml_project_code ) ;
			}



		}
		else if ( tc_strcmp ( type_name, "T5_APLDMLRevision" ) == 0 ) // Venkat Check1
		{
			printf ( "\nInside T5_APLDMLRevision " ) ;fflush ( stdout) ;

			APLDmlRevision=ERCDmlRevision[0];
			
			get_MBOM_APL_Dml_Details(APLDmlRevision, sdml_no, s_dml_project_code, dml_rlz_type, business_unit, product_line); // Venkat 
			
			printf ( "\nDML no : [%s]", sdml_no ) ; fflush ( stdout) ;
			printf ( "\n APL DML rlz type : [%s]", dml_rlz_type ) ; fflush ( stdout) ;
			printf ( "\n APL DML project code : [%s]", s_dml_project_code ) ; fflush ( stdout) ;
			printf ( "\n APL DML buasiness unit : [%s]", business_unit ) ; fflush ( stdout) ;
			printf ( "\n APL productline : [%s]", product_line ) ; fflush ( stdout) ;

		}



	}
	return ifail;
}

//QDSGNGRPCOMMDITY control object
int check_and_set_commodity(tag_t objTag)
{
    int ifail = ITK_ok;
    int n_entries = 1;
    int n_found = 0;
    tag_t designGroupQTag = NULLTAG;
    tag_t *designGroup_objects = NULLTAG;
    char *qry_entries[1] = { "SYSCD" };
    char *qry_values[1] = { "QDSGNGRPCOMMDITY" };
    
    // Arrays for Userinfo fields and their commodity values
    char *userinfo_fields[9] = { 
        "t5_Userinfo1", "t5_Userinfo2", "t5_Userinfo3", 
        "t5_Userinfo4", "t5_Userinfo5", "t5_Userinfo6", 
        "t5_Userinfo7", "t5_Userinfo8", "t5_Userinfo9"
    };
    int commodity_values[9] = { 
        100000000, 200000000, 300000000, 
        400000000, 500000000, 600000000, 
        700000000, 800000000, 900000000
    };
    
    char *userinfo_value = NULL;
    char *designGrp = NULL;
    int commodity = 0;
    int i = 0;
    
    // Get Design Group from part
    ITK_CALL(AOM_ask_value_string(objTag, "t5_DesignGrp", &designGrp));
    
    if (designGrp == NULL || tc_strlen(designGrp) == 0)
    {
        printf("\n Design Group is empty, skipping commodity check");
        TC_write_syslog("\n Design Group is empty, skipping commodity check");
        return 0;
    }
    
    printf("\n Design Group: [%s]", designGrp);
    TC_write_syslog("\n Design Group: [%s]", designGrp);
    
    // Find control object
    ITK_CALL(QRY_find2("Control Objects...", &designGroupQTag));
    
    if (designGroupQTag != NULLTAG)
    {
        ITK_CALL(QRY_execute(designGroupQTag, n_entries, qry_entries, qry_values, &n_found, &designGroup_objects));
        
        if (n_found > 0)
        {
            // Loop through all 9 Userinfo fields
            for (i = 0; i < 9; i++)
            {
                ITK_CALL(AOM_ask_value_string(designGroup_objects[0], userinfo_fields[i], &userinfo_value));
                
                if (userinfo_value != NULL && tc_strlen(userinfo_value) > 0)
                {
                    printf("\n %s: [%s]", userinfo_fields[i], userinfo_value);
                    TC_write_syslog("\n %s: [%s]", userinfo_fields[i], userinfo_value);
                    
                    if (tc_strstr(userinfo_value, designGrp) != NULL)
                    {
                        printf("\n Design group FOUND in %s", userinfo_fields[i]);
                        TC_write_syslog("\n Design group FOUND in %s", userinfo_fields[i]);
                        commodity = commodity_values[i];  // Return the actual value
                        break;
                    }
                }
                
                if (userinfo_value) MEM_free(userinfo_value);
                userinfo_value = NULL;
            }
        }
    }
    
    // Clean up
    if (designGrp) MEM_free(designGrp);
    if (userinfo_value) MEM_free(userinfo_value);
    if (designGroup_objects) MEM_free(designGroup_objects);
    
    return commodity;  // Returns the actual commodity value (e.g., 200000000) or 0 if not found
}



int compare_revisions(const void *a, const void *b)
{
    tag_t rev_a = *(tag_t*)a;
    tag_t rev_b = *(tag_t*)b;
    
    char *id_a = NULL;
    char *id_b = NULL;
    int result = 0;
    
    ITK_CALL(ITEM_ask_rev_id2(rev_a, &id_a));
    ITK_CALL(ITEM_ask_rev_id2(rev_b, &id_b));
    
    // compare strings 
    result = tc_strcmp(id_a, id_b);
    
    if (id_a) MEM_free(id_a);
    if (id_b) MEM_free(id_b);
    
    return result;
}

// To  compare revision IDs in seq order 
int compare_revisions_sequence(const void *a, const void *b)
{
    tag_t rev_a = *(tag_t*)a;
    tag_t rev_b = *(tag_t*)b;
    
    char *id_a = NULL;
    char *id_b = NULL;
    int result = 0;
    
    ITK_CALL(ITEM_ask_rev_id2(rev_a, &id_a));
    ITK_CALL(ITEM_ask_rev_id2(rev_b, &id_b));
    
    
    int is_nr_a = (tc_strstr(id_a, "NR") != NULL) ? 1 : 0;
    int is_nr_b = (tc_strstr(id_b, "NR") != NULL) ? 1 : 0;
    
    if (is_nr_a && !is_nr_b) {
        result = -1;  // NR comes first
    } else if (!is_nr_a && is_nr_b) {
        result = 1;   // NR comes first
    } else {
        // Normal string comparison for others
        result = tc_strcmp(id_a, id_b);
    }
    
    if (id_a) MEM_free(id_a);
    if (id_b) MEM_free(id_b);
    
    return result;
}

int find_previous_erc_released_sor(tag_t current_rev, tag_t *prev_sor_rev, tag_t *prev_part_rev)
{
    int ifail = ITK_ok;
    tag_t item_tag = NULLTAG;
    char *current_rev_id = NULL;
    char *rev_id = NULL;
    int n_revs = 0;
    tag_t *revs = NULL;
    int i = 0;
    int found = 0;
    tag_t relation_type = NULLTAG;
    tag_t *secondary_objects = NULLTAG;
    int secondary_count = 0;
    char *release_status = NULL;
    char *sor_rev_id = NULL;
    int current_index = -1;
    
    *prev_sor_rev = NULLTAG;
    *prev_part_rev = NULLTAG;
    
    // Get the item (master)
    ITK_CALL(ITEM_ask_item_of_rev(current_rev, &item_tag));
    
    // Get current revision ID
    ITK_CALL(ITEM_ask_rev_id2(current_rev, &current_rev_id));
    
    printf("\n============================================================\n");
    printf(" FINDING PREVIOUS ERC RELEASED SOR \n");
    printf("============================================================\n");
    printf(" Current Revision  : [%s]\n", current_rev_id);
    printf("------------------------------------------------------------\n");
    
    // Get ALL revisions
    ITK_CALL(ITEM_find_revisions(item_tag, "*", &n_revs, &revs));
    
    qsort(revs, n_revs, sizeof(tag_t), compare_revisions_sequence);
    
    printf("\n Total Revisions Found: [%d]\n", n_revs);
    printf(" Revisions in SEQUENCE ORDER (NR, A, B, C, D...):\n");
    for (i = 0; i < n_revs; i++)
    {
        char *rev_id_temp = NULL;
        ITK_CALL(ITEM_ask_rev_id2(revs[i], &rev_id_temp));
        
        // Check if this is the current revision
        if (tc_strcmp(rev_id_temp, current_rev_id) == 0)
        {
            current_index = i;
            printf("  [%d] Revision: [%s] <<< CURRENT\n", i, rev_id_temp);
        }
        else
        {
            printf("  [%d] Revision: [%s]\n", i, rev_id_temp);
        }
        if (rev_id_temp) MEM_free(rev_id_temp);
    }
    
    if (current_index == -1)
    {
        printf("\n  Current revision [%s] not found\n", current_rev_id);
        if (current_rev_id) MEM_free(current_rev_id);
        if (revs) MEM_free(revs);
        return 0;
    }
    
    printf("\n Current Revision Index: [%d]\n", current_index);
    printf("------------------------------------------------------------\n");
    
    // Find relation type T5_PartSorRel
    ITK_CALL(GRM_find_relation_type("T5_PartSorRel", &relation_type));
    
    if (current_index == 0)
    {
        printf("\n No previous revisions this is the first revision in sequence\n");
        printf("------------------------------------------------------------\n");
        printf(" Previous ERC Released SOR Found: [NO]\n");
        printf("============================================================\n");
        
        if (current_rev_id) MEM_free(current_rev_id);
        if (revs) MEM_free(revs);
        return 0;
    }
    
    printf("\n Checking PREVIOUS revisions (sequence order):\n");
    printf(" From index [%d] to [0]\n", current_index - 1);
    printf("------------------------------------------------------------\n");
    
    //  checking from newset to oldest previous
    for (i = current_index - 1; i >= 0; i--)
    {
        rev_id = NULL;
        secondary_objects = NULLTAG;
        secondary_count = 0;
        release_status = NULL;
        sor_rev_id = NULL;
        
        ITK_CALL(ITEM_ask_rev_id2(revs[i], &rev_id));
        printf("\n [%d] Checking PREVIOUS Revision: [%s]\n", i, rev_id);
        
        // Check  revision has any SOR relation
        ITK_CALL(GRM_list_secondary_objects_only(revs[i], relation_type, &secondary_count, &secondary_objects));
        
        if (secondary_count > 0 && secondary_objects != NULLTAG)
        {
            tag_t sor_rev = secondary_objects[0];
            
            ITK_CALL(ITEM_ask_rev_id2(sor_rev, &sor_rev_id));
            printf("     SOR Revision: [%s]\n", sor_rev_id);
            
            ITK_CALL(AOM_UIF_ask_value(sor_rev, "release_status_list", &release_status));
            
            if (release_status != NULL && tc_strlen(release_status) > 0)
            {
                printf("     Release Status: [%s]\n", release_status);
                
                if (tc_strstr(release_status, "ERC Released") != NULL )
                {
                    printf("     Yessssss FOUND ERC RELEASED SOR on revision [%s]!\n", rev_id);
                    TC_write_syslog("Yessssss FOUND ERC RELEASED SOR on revision [%s]\n", rev_id);
                    
                    *prev_sor_rev = sor_rev;
                    *prev_part_rev = revs[i];
                    found = 1;
                    
                    if (release_status) { MEM_free(release_status); release_status = NULL; }
                    if (secondary_objects) { MEM_free(secondary_objects); secondary_objects = NULLTAG; }
                    if (rev_id) { MEM_free(rev_id); rev_id = NULL; }
                    if (sor_rev_id) { MEM_free(sor_rev_id); sor_rev_id = NULL; }
                    break;
                }
                else
                {
                    printf("    oh noooooooo SOR is NOT ERC Released\n");
                }
            }
            else
            {
                printf("     Release Status: NULL or EMPTY\n");
            }
        }
        else
        {
            printf("     No SOR found on this revision\n");
        }
        
        if (release_status) { MEM_free(release_status); release_status = NULL; }
        if (secondary_objects) { MEM_free(secondary_objects); secondary_objects = NULLTAG; }
        if (rev_id) { MEM_free(rev_id); rev_id = NULL; }
        if (sor_rev_id) { MEM_free(sor_rev_id); sor_rev_id = NULL; }
    }
    
    printf("\n------------------------------------------------------------\n");
    printf(" Previous ERC Released SOR Found: [%s]\n", found ? "YES" : "NO");
    if (found && prev_sor_rev != NULLTAG)
    {
        char *prev_sor_id = NULL;
        ITK_CALL(ITEM_ask_rev_id2(*prev_sor_rev, &prev_sor_id));
        printf(" Previous ERC Released SOR Revision: [%s]\n", prev_sor_id);
        if (prev_sor_id) MEM_free(prev_sor_id);
    }
    printf("============================================================\n");
    
    //  cleanup
    if (current_rev_id) { MEM_free(current_rev_id); current_rev_id = NULL; }
    if (revs) { MEM_free(revs); revs = NULL; }
    if (rev_id) { MEM_free(rev_id); rev_id = NULL; }
    if (release_status) { MEM_free(release_status); release_status = NULL; }
    if (secondary_objects) { MEM_free(secondary_objects); secondary_objects = NULLTAG; }
    if (sor_rev_id) { MEM_free(sor_rev_id); sor_rev_id = NULL; }
    
    return found;
}

// copy properties from previous SOR to new SOR
int copy_properties_from_prev_sor(tag_t prev_sor_rev, tag_t existing_sor_rev)
{
    int ifail = ITK_ok;
    char *prev_pppm = NULL;
    char *prev_pmxu = NULL;
    char *prev_cat = NULL;
    char *prev_commodity = NULL;
    char *prev_ref_part = NULL;
    char *prev_sor_id = NULL;
    char *new_sor_id = NULL;
    
    ITK_CALL(ITEM_ask_rev_id2(prev_sor_rev, &prev_sor_id));
    ITK_CALL(ITEM_ask_rev_id2(existing_sor_rev, &new_sor_id));
    
    printf("\n============================================================\n");
    printf(" COPYING PROPERTIES FROM PREVIOUS SOR\n");
    printf("============================================================\n");
    printf(" Previous SOR Revision: [%s]\n", prev_sor_id);
    printf(" New SOR Revision     : [%s]\n", new_sor_id);
    printf("------------------------------------------------------------\n");
    
    //  properties from previous SOR
    ITK_CALL(AOM_ask_value_string(prev_sor_rev, "t5_qPPPMPrjCode", &prev_pppm));
    ITK_CALL(AOM_ask_value_string(prev_sor_rev, "t5_qsorPMXU", &prev_pmxu));
    ITK_CALL(AOM_ask_value_string(prev_sor_rev, "t5_qCtrlSorCat", &prev_cat));
    ITK_CALL(AOM_ask_value_string(prev_sor_rev, "t5_qCtrlCommodity", &prev_commodity));
    ITK_CALL(AOM_ask_value_string(prev_sor_rev, "t5_qReferencePartnumber", &prev_ref_part));
    
    // Lock new SOR before setting properties
    ITK_CALL(AOM_lock(existing_sor_rev));
    
    // Set properties on new SOR 
    if (prev_pppm != NULL && tc_strlen(prev_pppm) > 0)
    {
        ITK_CALL(AOM_set_value_string(existing_sor_rev, "t5_qPPPMPrjCode", prev_pppm));
        printf(" Copied t5_qPPPMPrjCode: [%s]\n", prev_pppm);
        TC_write_syslog(" Copied t5_qPPPMPrjCode: [%s]\n", prev_pppm);
    }
    else
    {
        printf(" t5_qPPPMPrjCode not available or empty - skipped\n");
    }
    
    if (prev_pmxu != NULL && tc_strlen(prev_pmxu) > 0)
    {
        ITK_CALL(AOM_set_value_string(existing_sor_rev, "t5_qsorPMXU", prev_pmxu));
        printf(" Copied t5_qsorPMXU: [%s]\n", prev_pmxu);
        TC_write_syslog(" Copied t5_qsorPMXU: [%s]\n", prev_pmxu);
    }
    else
    {
        printf(" t5_qsorPMXU not available or empty - skipped\n");
    }
    
    if (prev_cat != NULL && tc_strlen(prev_cat) > 0)
    {
        ITK_CALL(AOM_set_value_string(existing_sor_rev, "t5_qCtrlSorCat", prev_cat));
        printf(" Copied t5_qCtrlSorCat: [%s]\n", prev_cat);
        TC_write_syslog(" Copied t5_qCtrlSorCat: [%s]\n", prev_cat);
    }
    else
    {
        printf(" t5_qCtrlSorCat not available or empty - skipped\n");
    }
    
    if (prev_commodity != NULL && tc_strlen(prev_commodity) > 0)
    {
        ITK_CALL(AOM_set_value_string(existing_sor_rev, "t5_qCtrlCommodity", prev_commodity));
        printf(" Copied t5_qCtrlCommodity: [%s]\n", prev_commodity);
        TC_write_syslog(" Copied t5_qCtrlCommodity: [%s]\n", prev_commodity);
    }
    else
    {
        printf(" t5_qCtrlCommodity not available or empty - skipped\n");
    }
    
    if (prev_ref_part != NULL && tc_strlen(prev_ref_part) > 0)
    {
        ITK_CALL(AOM_set_value_string(existing_sor_rev, "t5_qReferencePartnumber", prev_ref_part));
        printf(" Copied t5_qReferencePartnumber: [%s]\n", prev_ref_part);
        TC_write_syslog(" Copied t5_qReferencePartnumber: [%s]\n", prev_ref_part);
    }
    else
    {
        printf(" t5_qReferencePartnumber not available or empty - skipped\n");
    }
    
    // Save and unlock
    ITK_CALL(AOM_save_without_extensions(existing_sor_rev));
    ITK_CALL(AOM_unlock(existing_sor_rev));
    
    printf("============================================================\n");
    printf(" Yeahhh Properties copied successfully!\n");
    printf("============================================================\n");
    
    // Clean up
    if (prev_sor_id) MEM_free(prev_sor_id);
    if (new_sor_id) MEM_free(new_sor_id);
    if (prev_pppm) MEM_free(prev_pppm);
    if (prev_pmxu) MEM_free(prev_pmxu);
    if (prev_cat) MEM_free(prev_cat);
    if (prev_commodity) MEM_free(prev_commodity);
    if (prev_ref_part) MEM_free(prev_ref_part);
    
    return ifail;
}




int copy_variant_table_from_prev_sor(tag_t prev_sor_rev, tag_t new_sor_rev)
{
    int ifail = ITK_ok;
    int prev_table_rows = 0;
    tag_t *prev_table_rows_tag = NULLTAG;
    int new_table_rows = 0;
    tag_t *new_table_rows_tag = NULLTAG;
    int i = 0;
    int max_rows = 0;
    char *prev_var_name = NULL;
    char *prev_var_id = NULL;
    char *prev_qty_str = NULL;  // read as string
    int prev_qty_int = 0;        // set as integer
    char *prev_sor_id = NULL;
    char *new_sor_id = NULL;
    
    // NULL checks
    if (prev_sor_rev == NULLTAG || new_sor_rev == NULLTAG)
    {
        printf("\n ERROR: Invalid SOR tags\n");
        TC_write_syslog("\n ERROR: Invalid SOR tags\n");
        return -1;
    }
    
    ITK_CALL(ITEM_ask_rev_id2(prev_sor_rev, &prev_sor_id));
    ITK_CALL(ITEM_ask_rev_id2(new_sor_rev, &new_sor_id));
    
    printf("\n============================================================\n");
    printf(" COPYING VARIANT TABLE FROM PREVIOUS SOR\n");
    printf("============================================================\n");
    printf(" Previous SOR Revision: [%s]\n", prev_sor_id ? prev_sor_id : "NULL");
    printf(" New SOR Revision     : [%s]\n", new_sor_id ? new_sor_id : "NULL");
    printf("------------------------------------------------------------\n");
    
    //  variant table 
    ITK_CALL(AOM_ask_table_rows(prev_sor_rev, "t5_qSORVar", &prev_table_rows, &prev_table_rows_tag));
    ITK_CALL(AOM_ask_table_rows(new_sor_rev, "t5_qSORVar", &new_table_rows, &new_table_rows_tag));
    
    printf(" Previous SOR rows: [%d]\n", prev_table_rows);
    printf(" New SOR rows     : [%d]\n", new_table_rows);
    
    if (prev_table_rows == 0)
    {
        printf("\n No variant rows in previous SOR to copy.\n");
        TC_write_syslog("\n No variant rows in previous SOR to copy.\n");
        goto cleanup;
    }
    
    if (new_table_rows == 0)
    {
        printf("\n WARNING: New SOR has no variant table rows. Cannot copy.\n");
        TC_write_syslog("\n WARNING: New SOR has no variant table rows. Cannot copy.\n");
        goto cleanup;
    }
    
    max_rows = (prev_table_rows < new_table_rows) ? prev_table_rows : new_table_rows;
    printf("\n Copying [%d] variant rows...\n", max_rows);
    TC_write_syslog("\n Copying [%d] variant rows...\n", max_rows);
    
    // lock the new SOR
    ITK_CALL(AOM_lock(new_sor_rev));
    
    for (i = 0; i < max_rows; i++)
    {
        printf("\n [%d] Copying variant row...\n", i+1);
        
        // ask value
        ITK_CALL(AOM_UIF_ask_value(prev_table_rows_tag[i], "t5_qVariant_Name", &prev_var_name));
        ITK_CALL(AOM_UIF_ask_value(prev_table_rows_tag[i], "t5_qVariantId", &prev_var_id));
        ITK_CALL(AOM_UIF_ask_value(prev_table_rows_tag[i], "t5_qQuantity", &prev_qty_str));
        
        // convt quantity to integer
        prev_qty_int = 0;
        if (prev_qty_str != NULL && tc_strlen(prev_qty_str) > 0) {
            prev_qty_int = atoi(prev_qty_str);
        }
        
        printf("     Previous: Name=[%s], Id=[%s], Qty=[%s] (int: %d)\n", 
               prev_var_name ? prev_var_name : "NULL", 
               prev_var_id ? prev_var_id : "NULL", 
               prev_qty_str ? prev_qty_str : "NULL",
               prev_qty_int);
        
        // Lock the new row
        ITK_CALL(AOM_lock(new_table_rows_tag[i]));
        
        // Set  properties
        ITK_CALL(AOM_set_value_string(new_table_rows_tag[i], "t5_qVariant_Name", 
                                      prev_var_name ? prev_var_name : ""));
        ITK_CALL(AOM_set_value_string(new_table_rows_tag[i], "t5_qVariantId", 
                                      prev_var_id ? prev_var_id : ""));
        
        // integer property sets 
        ITK_CALL(AOM_set_value_int(new_table_rows_tag[i], "t5_qQuantity", prev_qty_int));
        
        // Save and unlock  row
        ITK_CALL(AOM_save_without_extensions(new_table_rows_tag[i]));
        ITK_CALL(AOM_unlock(new_table_rows_tag[i]));
        
        printf("     Copied: Name=[%s], Id=[%s], Qty=[%d]\n", 
               prev_var_name ? prev_var_name : "", 
               prev_var_id ? prev_var_id : "", 
               prev_qty_int);
        TC_write_syslog("     Copied row [%d]: Name=[%s], Id=[%s], Qty=[%d]\n", 
                        i+1, 
                        prev_var_name ? prev_var_name : "", 
                        prev_var_id ? prev_var_id : "", 
                        prev_qty_int);
        
        // Clean up
        if (prev_var_name) { MEM_free(prev_var_name); prev_var_name = NULL; }
        if (prev_var_id) { MEM_free(prev_var_id); prev_var_id = NULL; }
        if (prev_qty_str) { MEM_free(prev_qty_str); prev_qty_str = NULL; }
    }
    
    // Save and unlock the new SOR
    ITK_CALL(AOM_save_without_extensions(new_sor_rev));
    ITK_CALL(AOM_unlock(new_sor_rev));
    
    printf("\n============================================================\n");
    printf(" Yessssss Variant table copied successfully !\n");
    printf("============================================================\n");
    
cleanup:
    // Clean up
    if (prev_sor_id) { MEM_free(prev_sor_id); prev_sor_id = NULL; }
    if (new_sor_id) { MEM_free(new_sor_id); new_sor_id = NULL; }
    if (prev_table_rows_tag) { MEM_free(prev_table_rows_tag); prev_table_rows_tag = NULL; }
    if (new_table_rows_tag) { MEM_free(new_table_rows_tag); new_table_rows_tag = NULL; }
    if (prev_var_name) { MEM_free(prev_var_name); prev_var_name = NULL; }
    if (prev_var_id) { MEM_free(prev_var_id); prev_var_id = NULL; }
    if (prev_qty_str) { MEM_free(prev_qty_str); prev_qty_str = NULL; }
    
    return ifail;
}

// Check if Make/Buy is  F, F30, or F40
int is_makebuy_ff30f40(char *makebuy_value)
{
    if (makebuy_value == NULL || tc_strlen(makebuy_value) == 0)
        return 0;
    
    if (tc_strcmp(makebuy_value, "F") == 0 ||
        tc_strcmp(makebuy_value, "F30") == 0 ||
        tc_strcmp(makebuy_value, "F40") == 0)
    {
        return 1;
    }
    
    return 0;
}

int is_apl_released(tag_t rev_tag)
{
    int ifail = ITK_ok;
    char *release_status = NULL;
    int is_released = 0;
    
    ITK_CALL(AOM_UIF_ask_value(rev_tag, "release_status_list", &release_status));
    
    if (release_status != NULL && tc_strlen(release_status) > 0)
    {
        // Check if ANY APL 
        if (tc_strstr(release_status, "APLC Released") != NULL ||
            tc_strstr(release_status, "APLA Released") != NULL ||
            tc_strstr(release_status, "APLS Released") != NULL )
        {
            is_released = 1;
            printf("\n   >>> Revision IS APL Released\n");
            TC_write_syslog("\n   >>> Revision IS APL Released\n");
        }
        else
        {
            printf("\n   >>> Revision is NOT APL Released\n");
            TC_write_syslog("\n   >>> Revision is NOT APL Released\n");
        }
    }
    
    if (release_status) MEM_free(release_status);
    
    return is_released;
}



// get latest apl released with query Query_Latest_PartRev
int get_latest_apl_released_revision(tag_t item_tag, tag_t *apl_rev_tag)
{
    int ifail = ITK_ok;
    int n_found = 0;
    tag_t queryTag = NULLTAG;
    tag_t *revs = NULL;
    char *item_id = NULL;
    int i = 0;
    
    *apl_rev_tag = NULLTAG;
    
    ITK_CALL(AOM_ask_value_string(item_tag, "item_id", &item_id));
    
    ITK_CALL(QRY_find2("Query_Latest_PartRev", &queryTag));
    
    if (queryTag == NULLTAG)
    {
        printf("\n ERROR: Query 'Query_Latest_PartRev' not found!\n");
        TC_write_syslog("\n ERROR: Query 'Query_Latest_PartRev' not found!\n");
        if (item_id) MEM_free(item_id);
        return 0;
    }
    
    int n_entries = 1;
    char *qry_entries[1] = { "ID" };
    char *qry_values[1] = { item_id };
    
    ITK_CALL(QRY_execute(queryTag, n_entries, qry_entries, qry_values, &n_found, &revs));
    
    printf("\n Query 'Query_Latest_PartRev' found [%d] APL Released revisions for ID: [%s]\n", n_found, item_id);
    TC_write_syslog("\n Query 'Query_Latest_PartRev' found [%d] APL Released revisions for ID: [%s]\n", n_found, item_id);
    
    if (n_found > 0 && revs != NULL)
    {
        
        for (i = 0; i < n_found; i++)
        {
            char *rev_id = NULL;
            ITK_CALL(ITEM_ask_rev_id2(revs[i], &rev_id));
            
            printf("\n Checking Revision: [%s] for APL Release\n", rev_id);
            
            if (is_apl_released(revs[i]))
            {
                *apl_rev_tag = revs[i];
                printf("\n >>> Found Latest APL Released Revision: [%s]\n", rev_id);
                TC_write_syslog("\n >>> Found Latest APL Released Revision: [%s]\n", rev_id);
                
                if (rev_id) MEM_free(rev_id);
                break;
            }
            
            if (rev_id) MEM_free(rev_id);
        }
    }
    else
    {
        printf("\n No APL Released revisions found\n");
        TC_write_syslog("\n No APL Released revisions found\n");
    }
    
    if (item_id) MEM_free(item_id);
    if (revs) MEM_free(revs);
    
    return (*apl_rev_tag != NULLTAG) ? 1 : 0;
}

// check apl  rleased Revision for Make/Buy F/F30/F40
int check_latest_apl_released_makebuy(tag_t design_tag, int *apl_released_found)
{
    int ifail = ITK_ok;
    tag_t item_tag = NULLTAG;
    tag_t apl_rev_tag = NULLTAG;
    char *current_rev_id = NULL;
    char *apl_rev_id = NULL;
    char *makebuy_car = NULL;
    char *makebuy_ahd = NULL;
    char *makebuy_snd = NULL;
    int makebuy_found = 0;
    
    *apl_released_found = 0;
    
    ITK_CALL(ITEM_ask_item_of_rev(design_tag, &item_tag));
    ITK_CALL(ITEM_ask_rev_id2(design_tag, &current_rev_id));
    
    printf("\n============================================================\n");
    printf(" CHECKING LATEST APL RELEASED REVISION\n");
    printf("============================================================\n");
    printf(" Current Revision   : [%s]\n", current_rev_id);
    printf("------------------------------------------------------------\n");
    
    int found = get_latest_apl_released_revision(item_tag, &apl_rev_tag);
    
    if (found && apl_rev_tag != NULLTAG)
    {
        *apl_released_found = 1;
        
        ITK_CALL(ITEM_ask_rev_id2(apl_rev_tag, &apl_rev_id));
        
        printf("\n >>> Latest APL Released Revision: [%s]\n", apl_rev_id);
        printf("------------------------------------------------------------\n");
        
        ITK_CALL(AOM_ask_value_string(apl_rev_tag, "t5_CarMakeBuyIndicator", &makebuy_car));
        ITK_CALL(AOM_ask_value_string(apl_rev_tag, "t5_AhdMakeBuyIndicator", &makebuy_ahd));
        ITK_CALL(AOM_ask_value_string(apl_rev_tag, "t5_SndMakeBuyIndicator", &makebuy_snd));
        
        printf("\n Make/Buy Indicators on Latest APL Released Revision [%s]:\n", apl_rev_id);
        printf("   t5_CarMakeBuyIndicator: [%s]\n", makebuy_car ? makebuy_car : "NULL");
        printf("   t5_AhdMakeBuyIndicator: [%s]\n", makebuy_ahd ? makebuy_ahd : "NULL");
        printf("   t5_SndMakeBuyIndicator: [%s]\n", makebuy_snd ? makebuy_snd : "NULL");
        
        // check for  t5_CarMakeBuyIndicator
        if (is_makebuy_ff30f40(makebuy_car))
        {
            printf("\n  FOUND F/F30/F40 in t5_CarMakeBuyIndicator!\n");
            TC_write_syslog(" FOUND F/F30/F40 in t5_CarMakeBuyIndicator\n");
            makebuy_found = 1;
        }
        
        // Check t5_AhdMakeBuyIndicator
        if (!makebuy_found && is_makebuy_ff30f40(makebuy_ahd))
        {
            printf("\n  FOUND F/F30/F40 in t5_AhdMakeBuyIndicator!\n");
            TC_write_syslog(" FOUND F/F30/F40 in t5_AhdMakeBuyIndicator\n");
            makebuy_found = 1;
        }
        
        // Check t5_SndMakeBuyIndicator
        if (!makebuy_found && is_makebuy_ff30f40(makebuy_snd))
        {
            printf("\n  FOUND F/F30/F40 in t5_SndMakeBuyIndicator!\n");
            TC_write_syslog(" FOUND F/F30/F40 in t5_SndMakeBuyIndicator\n");
            makebuy_found = 1;
        }
        
        if (!makebuy_found)
        {
            printf("\n  NO F/F30/F40 found in ANY Make/Buy indicator\n");
            TC_write_syslog("\n  NO F/F30/F40 found in ANY Make/Buy indicator\n");
        }
        
        if (apl_rev_id) MEM_free(apl_rev_id);
        if (makebuy_car) MEM_free(makebuy_car);
        if (makebuy_ahd) MEM_free(makebuy_ahd);
        if (makebuy_snd) MEM_free(makebuy_snd);
    }
    else
    {
        printf("\n  NO APL Released revision found\n");
        TC_write_syslog("\n  NO APL Released revision found\n");
        *apl_released_found = 0;
    }
    
    printf("\n============================================================\n");
    printf(" SUMMARY\n");
    printf("============================================================\n");
    printf(" APL Released Revision Found: [%s]\n", *apl_released_found ? "YES" : "NO");
    printf(" F/F30/F40 Found in ANY Make/Buy: [%s]\n", makebuy_found ? "YES" : "NO");
    printf("============================================================\n");
    
    if (current_rev_id) MEM_free(current_rev_id);
    
    return makebuy_found;
}

// Create Q SOR based on APL Release & Make/Buy
int ShouldCreateQuickSOR_PV(tag_t design_tag)
{
    char *current_rev_id = NULL;
    int should_create = 0;
    int makebuy_found = 0;
    int apl_released_found = 0;
    
    ITK_CALL(ITEM_ask_rev_id2(design_tag, &current_rev_id));
    
    printf("\n============================================================\n");
    printf(" PV QUICK SOR DECISION LOGIC\n");
    printf("============================================================\n");
    printf(" Current Revision  : [%s]\n", current_rev_id);
    printf("------------------------------------------------------------\n");
    printf("\n Checking Latest APL Released Revision for ALL THREE Make/Buy\n");
    printf(" (t5_CarMakeBuyIndicator, t5_AhdMakeBuyIndicator, t5_SndMakeBuyIndicator)\n");
    printf("------------------------------------------------------------\n");
    
    makebuy_found = check_latest_apl_released_makebuy(design_tag, &apl_released_found);
    
    printf("\n============================================================\n");
    printf(" DECISION SUMMARY\n");
    printf("============================================================\n");
    
    if (apl_released_found)
    {
        if (makebuy_found)
        {
            printf("\n  DECISION: CREATE SOR");
            printf("\n Reason: Latest APL Released revision has F/F30/F40 in Make/Buy\n");
            should_create = 1;
        }
        else
        {
            printf("\n  DECISION: SKIP SOR");
            printf("\n Reason: Latest APL Released revision does NOT have F/F30/F40 in ANY Make/Buy\n");
            should_create = 0;
        }
    }
    else
    {
        printf("\n  DECISION: CREATE SOR");
        printf("\n Reason: No APL Released revision found\n");
        should_create = 1;
    }
    
    printf("\n============================================================\n");
    printf(" FINAL DECISION: [%s]\n", should_create ? "CREATE SOR " : "SKIP SOR ");
    printf("============================================================\n\n");
    
    if (current_rev_id) MEM_free(current_rev_id);
    
    return should_create;
}



int Create_SOR ( tag_t objTag, char *type_name,char *myItem_id, char *PartRevision,char *PartSequence, char *dml_no, char *dml_project_code, char *business_unit, char *product_line,tag_t task_tag, char *st5_ColourInd)
{
    int retcode = ITK_ok ;
    char *SOR_item_id = NULL ;
    tag_t tItemTag = NULLTAG ;
    tag_t tRevTypeTag = NULLTAG ;
    tag_t tRevCreateInputTag  = NULLTAG ;
    int nItems = 0 ;
    tag_t *items = NULLTAG ;
    tag_t latestSorrev = NULLTAG ;
    tag_t tRelationFind = NULLTAG ;
    tag_t tItemTypeTag = NULLTAG ;
    tag_t tItemCreateInputTag = NULLTAG ;
	tag_t tRelationExist = NULLTAG ;        
    tag_t PartSorRelTag = NULLTAG ; 
    char *myitem_revision_id = NULL ;
    char *Release_status_SOR = NULL ;
    char *PartCategory = NULL;
    const char *reason = "" ;
    const char *change_id = "" ;
    const char *dir_name = "" ;
    logical  retain_released_date_SOR  = TRUE;
    tag_t status_rel_SOR		   = NULLTAG;
    char APLLifeCylcleWrkState[40];
    char APLLifeCylcleRevwState[40];
    char* PlantName = NULL;
    char* DMLNO = NULL;
    char* my_part_desc = NULL;
    char* my_part_category = NULL;
    char *part_info_on = NULL;
    char *VendorName = NULL;
    int n_found_prt_info = 0 ;
    tag_t NonClr_Relation = NULLTAG;
    int NonClr_count = 0;
    tag_t *NonClrSet = NULLTAG;
    tag_t NonClrRev_t = NULLTAG;
    
	// Variables for skip dml project code
    char *t5_Userinfo1tag2 = NULL;
	tag_t skipDMLQTag = NULLTAG;
	tag_t *skipDML_objects = NULLTAG;



	// CHECK FOR PREVIOUS ERC RELEASED SOR (CONTROL OBJECT BASED)
    // ============================================================
    tag_t prev_sor_rev = NULLTAG;
    tag_t prev_part_rev = NULLTAG;
    int has_prev_erc_sor = 0;
    char *sor_part_number = NULL;
    
    ITK_CALL(AOM_ask_value_string(objTag, "item_id", &sor_part_number));
    
    // Check if SOR copy feature is enabled via control object
    int n_found_SOR_COPY = tm_check_control_object("SOR_COPY", "TRUE");
    
    if (n_found_SOR_COPY > 0)
    {
        has_prev_erc_sor = find_previous_erc_released_sor(objTag, &prev_sor_rev, &prev_part_rev);
        
        if (has_prev_erc_sor && prev_sor_rev != NULLTAG)
        {
            printf("\n Found previous ERC Released SOR. Will copy properties after creation.\n");
            TC_write_syslog("\n Found previous ERC Released SOR. Will copy properties after creation.\n");
        }
        else
        {
            printf("\n No previous ERC Released SOR found. Creating new SOR.\n");
            TC_write_syslog("\n No previous ERC Released SOR found. Creating new SOR.\n");
        }
    }
    else
    {
        printf("\n SOR_COPY control object NOT found - Skipping SOR copy logic.\n");
        TC_write_syslog("\n SOR_COPY control object NOT found - Skipping SOR copy logic.\n");
    }

    // check for PV_QUICK_SOR control object 
    
    int n_found_PV_QUICK_SOR = 0;
    n_found_PV_QUICK_SOR = tm_check_control_object("PV_QUICK_SOR", "TRUE");
    printf("\n[Create_SOR] PV_QUICK_SOR control object found: [%d]\n", n_found_PV_QUICK_SOR);
    TC_write_syslog("\n[Create_SOR] PV_QUICK_SOR control object found: [%d]\n", n_found_PV_QUICK_SOR);
    
    DMLNO = ( char * ) malloc ( 10 * sizeof (char) );
    part_info_on = ( char * ) malloc ( 10 * sizeof (char) );
                    
    printf("\nRSS 1.1- Checking Part_category SOR Creation \n");
    TC_write_syslog ( "\nRSS 1.1- Checking Part_categoryfor SOR Creation \n" ) ;
    {
        printf("RSS 1.2- Getting Part category and Vendor for SOR Creation \n");
        ITK_CALL(AOM_ask_value_string(objTag,"t5_SpareCriteria",&PartCategory));
        ITK_CALL(AOM_ask_value_string(objTag,"t5_VendorName",&VendorName));
        printf("\n*******Part category on design Revision ******** [%s]\n",PartCategory );
        printf("\n*******Vendor Name on design Revision ******** [%s]\n",VendorName );
        

        SOR_item_id = MEM_alloc ( 50*sizeof ( char ) );
        
        
        if (n_found_PV_QUICK_SOR > 0)
        {

			int n_entries = 1 ;
			int n1_found = 0 ; 
			
			tag_t designGroupQTag = NULLTAG;
			tag_t *designGroup_objects = NULLTAG ;
			//tag_t *partTagRev = NULLTAG ;

			char *qry_entries[1] = { "SYSCD"} ;
			char *qry_values[1] =   { "SORDESGNGRP" }  ;

			char *t5_Userinfo1tag = NULL;
			char *designGrp = NULL;
			 

			
			//ITK_CALL ( AOM_ask_value_tags(myItem_id,"t5_DesignGrp",&tagCount,&partTagRev ) ) ;
			//ITK_CALL ( AOM_UIF_ask_value(myItem_id,"t5_DesignGrp",&designGrp ) ) ;
			//ITK_CALL( ( AOM_ask_value_string(myItem_id, "t5_DesignGrp",&t5DesignGrp) ); // get design group
			
			ITK_CALL ( AOM_ask_value_string(objTag, "t5_DesignGrp", &designGrp) );
			printf("\n Design Group of Part [%s] is [%s] ",myItem_id, designGrp);
            TC_write_syslog ("\n Design Group of Part [%s] is [%s] ",myItem_id, designGrp);

			ITK_CALL( QRY_find2("Control Objects...", &designGroupQTag)) ;
			printf("\n Query Find   \n");

			ITK_CALL ( QRY_execute ( designGroupQTag, n_entries, qry_entries, qry_values, &n1_found, &designGroup_objects ) );

			printf("\n n1_found : [%d]", n1_found);
            TC_write_syslog("\n n1_found : [%d]", n1_found);
			
			if (n1_found > 0)
			{
				
				ITK_CALL ( AOM_ask_value_string(designGroup_objects[0],"t5_Userinfo1",&t5_Userinfo1tag) ) ;
				printf("\n t5_Userinfo1tag : [%s]", t5_Userinfo1tag);
                TC_write_syslog("\n t5_Userinfo1tag : [%s]", t5_Userinfo1tag);

				if(tc_strstr(t5_Userinfo1tag,designGrp)!=NULL)
				{
					printf("\n Inside Design group check block\n");
					TC_write_syslog("\n Inside Design group check block\n");

					printf("\n Design group is [%s]", t5_Userinfo1tag);
					TC_write_syslog("\n Design group is [%s] hence skipping", t5_Userinfo1tag);
				    TC_write_syslog("\n Design group is [%s] hence skipping", t5_Userinfo1tag);

					EMH_clear_errors();
					char error_msg[512];
					sprintf(error_msg, "SOR creation not allowed for Design Group [%s].", designGrp);
					EMH_store_error_s1(EMH_severity_error, PLM_error, error_msg);
					TC_write_syslog("\nERROR: %s", error_msg);
					
					
					if (designGrp) MEM_free(designGrp);
					if (t5_Userinfo1tag) MEM_free(t5_Userinfo1tag);
					
					return PLM_error;
				}
				else
				{
				    printf("\n Design group [%s] NOT found in control obj list [%s] - Continuing with SOR creation", designGrp, t5_Userinfo1tag);
				    TC_write_syslog("\n Design group [%s] NOT found in skip list [%s] - Continuing with SOR creation", designGrp, t5_Userinfo1tag);
				}
			}


			// start
			
			int n_entries2 = 1;
			int n2_found = 0;
			tag_t skipDMLQTag = NULLTAG;
			tag_t *skipDML_objects = NULLTAG;
			char *qry_entries2[1] = { "SYSCD" };
			char *qry_values2[1] = { "SKIPSORDMLPRJCODE" };
			char *t5_Userinfo1tag2 = NULL;

			printf("\n DML Project Code: [%s]", dml_project_code);
			TC_write_syslog("\n DML Project Code: [%s]", dml_project_code);

			ITK_CALL(QRY_find2("Control Objects...", &skipDMLQTag));
			printf("\n Query Find for SKIPSORDMLPRJCODE");

			ITK_CALL(QRY_execute(skipDMLQTag, n_entries2, qry_entries2, qry_values2, &n2_found, &skipDML_objects));
			printf("\n n2_found for SKIPSORDMLPRJCODE: [%d]", n2_found);
			TC_write_syslog("\n n2_found for SKIPSORDMLPRJCODE: [%d]", n2_found);

			if (n2_found > 0)
			{
			    ITK_CALL(AOM_ask_value_string(skipDML_objects[0], "t5_Userinfo1", &t5_Userinfo1tag2));
			    printf("\n DML Project codes to skip: [%s]", t5_Userinfo1tag2);
			    TC_write_syslog("\n DML Project codes to skip: [%s]", t5_Userinfo1tag2);

			      
			        if (tc_strstr(t5_Userinfo1tag2, dml_project_code) != NULL)
			        {
			            
			            printf("\n DML Project Code [%s] FOUND in SKIPSORDMLPRJCODE", dml_project_code);
			            printf("\n Skipping SOR creation for this DML Project");
			            TC_write_syslog("\n DML Project Code [%s] FOUND in SKIPSORDMLPRJCODE  SKIPPING SOR", dml_project_code);
			            
			            
			            if (designGrp) MEM_free(designGrp);
			            if (t5_Userinfo1tag) MEM_free(t5_Userinfo1tag);
			            if (designGroup_objects) MEM_free(designGroup_objects);
			            if (t5_Userinfo1tag2) MEM_free(t5_Userinfo1tag2);
			            if (skipDML_objects) MEM_free(skipDML_objects);

			            EMH_clear_errors();
			            char warn_msg[512];
			            sprintf(warn_msg, "SOR creation skipped for DML Project [%s].", dml_project_code);
			            EMH_store_error_s1(EMH_severity_warning, ITK_err, warn_msg);
			            TC_write_syslog("\nWARNING: %s", warn_msg);
			            return ITK_ok;
			        }
			        else
			        {
			            printf("\n DML Project Code [%s] NOT found in skip list - Continuing with SOR creation", dml_project_code);
			            TC_write_syslog("\n DML Project Code [%s] NOT found in skip list - Continuing with SOR creation", dml_project_code);
			        }
			    
			}

			
			if (t5_Userinfo1tag2) { MEM_free(t5_Userinfo1tag2); t5_Userinfo1tag2 = NULL; }
			if (skipDML_objects) { MEM_free(skipDML_objects); skipDML_objects = NULL; }


					//END

			
			// PV QUICK SOR - APL RELEASE & MAKE/BUY CHECK 
			


			// Check if APL logic control object is enabled
			int n_found_PV_APL_CHECK = 0;
            n_found_PV_APL_CHECK = tm_check_control_object("PV_SOR_APL_CS_CHECK", "TRUE");

		  if (n_found_PV_APL_CHECK > 0)
		{
				printf("\n PV_SOR_APL_CS_CHECK control object found - Applying APL CS logic\n");
				TC_write_syslog("\n PV_SOR_APL_CS_CHECK control object found - Applying APL  CS logic\n");
			    int should_create = ShouldCreateQuickSOR_PV(objTag);
			
			  if (!should_create)
			  {
			    printf("\n PV Quick SOR condition not met - Skipping creation\n");
			    TC_write_syslog("\n PV Quick SOR condition not met - Skipping creation");
			    
			    // Clean up and return
			    if (designGrp) MEM_free(designGrp);
			    if (t5_Userinfo1tag) MEM_free(t5_Userinfo1tag);
			    if (designGroup_objects) MEM_free(designGroup_objects);
			    //if (t5_Userinfo1tag2) MEM_free(t5_Userinfo1tag2);
			    //if (skipDML_objects) MEM_free(skipDML_objects);
			    

				// exit  function completely
                goto cleanup_and_return;
			   }
		}
		    else
			   {
				  printf("\n PV_SOR_APL_CS_CHECK control object NOT found - Skipping APL CS logic, creating SOR\n");
                  TC_write_syslog("\n PV_SOR_APL_CS_CHECK control object NOT found - Skipping APL CS logic, creating SOR\n");
			    }

			
            int n_found_qSORNAME = tm_check_control_object("qSORNAME", "ON");
            printf("\n[Create_SOR] qSORNAME found: [%d]\n", n_found_qSORNAME);
            TC_write_syslog("\n[Create_SOR] qSORNAME found: [%d]\n", n_found_qSORNAME);
            
            if (n_found_qSORNAME > 0)
            {
                tc_strcpy(SOR_item_id, "qSOR_");
            }
            else
            {
                tc_strcpy(SOR_item_id, "SOR_");
            }
            tc_strcat(SOR_item_id, myItem_id);
            tc_strcat(SOR_item_id, "_");
            tc_strcat(SOR_item_id, PartRevision);
            
            printf("\n[Create_SOR] PV QUICK SOR ID: [%s]\n", SOR_item_id);
            TC_write_syslog("\n[Create_SOR] PV QUICK SOR ID: [%s]\n", SOR_item_id);
            printf("\n******** CREATING PV QUICK SOR ********\n");
            TC_write_syslog("\n******** CREATING PV QUICK SOR ********\n");
        }
        else
        {
            
            if (((tc_strstr(PartCategory, "TSD-Black") != NULL) || (tc_strstr(PartCategory, "TSD-Gray") != NULL)) && (VendorName == NULL || *VendorName == '\0')) 
            {
                printf("Inside - Part Category is [%s] - Creating OFFER SOR\n", PartCategory);
                tc_strcpy(SOR_item_id, "OFFER_");
                tc_strcat(SOR_item_id, myItem_id);
                tc_strcat(SOR_item_id, "_");
                tc_strcat(SOR_item_id, PartRevision);
            }
            else
            {
                tc_strcpy(SOR_item_id, "SOR_");
                tc_strcat(SOR_item_id, myItem_id);
                tc_strcat(SOR_item_id, "_");
                tc_strcat(SOR_item_id, PartRevision);
            }
            
            printf("\n[Create_SOR] CV AUTO SOR ID: [%s]\n", SOR_item_id);
            TC_write_syslog("\n[Create_SOR] CV AUTO SOR ID: [%s]\n", SOR_item_id);
            printf("\n******** CREATING CV AUTO SOR ********\n");
            TC_write_syslog("\n******** CREATING CV AUTO SOR ********\n");
        }

        printf ( "\nmyItem_id : [%s] \n", myItem_id ) ; fflush ( stdout) ;
        TC_write_syslog ( "\nmyItem_id : [%s] \n", myItem_id ) ;
        printf ( "\nPartRevision : [%s] \n", PartRevision ) ; fflush ( stdout) ;
        TC_write_syslog ( "\nPartRevision : [%s] \n", PartRevision ) ;
        printf ( "\nSOR_item_id : [%s] \n", SOR_item_id ) ; fflush ( stdout) ;
        TC_write_syslog ( "\nSOR_item_id : [%s] \n", SOR_item_id ) ;

        
        // check if sor already exist
        
        const char *names [2] = { "object_type", "item_id" } ;
        const char *values [2] = { 
            (n_found_PV_QUICK_SOR > 0) ? "T5_quicksor" : "T5_AutoSor", 
            SOR_item_id 
        } ;

        ITK_CALL ( ITEM_find_items_by_key_attributes ( 2, names, values, &nItems, &items ) ) ;
        printf ( "\nno of items : [%d]\n", nItems ) ; fflush ( stdout) ;
        TC_write_syslog ( "\nno of items : [%d]\n", nItems ) ;

        if ( nItems == 0 )
        {
            
            // create sor
           
            const char* rev_type = (n_found_PV_QUICK_SOR > 0) ? "T5_quicksorRevision" : "T5_AutoSorRevision";
            const char* item_type = (n_found_PV_QUICK_SOR > 0) ? "T5_quicksor" : "T5_AutoSor";
            
            ITK_CALL ( TCTYPE_find_type ( rev_type, NULL, &tRevTypeTag ) ) ;
            ITK_CALL ( TCTYPE_construct_create_input ( tRevTypeTag, &tRevCreateInputTag ) ) ;
            printf ( "\nCreating %s", rev_type ) ; fflush ( stdout) ;
            TC_write_syslog ( "\nCreating %s", rev_type ) ;

            ITK_CALL ( TCTYPE_find_type ( item_type, NULL, &tItemTypeTag ) ) ;
            ITK_CALL ( TCTYPE_construct_create_input ( tItemTypeTag, &tItemCreateInputTag ) ) ;
            printf("\nfind the item type %s\n", item_type); fflush ( stdout) ;
            TC_write_syslog("\nfind the item type %s\n", item_type);

            ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "item_id", SOR_item_id ) ) ;
            ITK_CALL ( AOM_set_value_string ( tItemCreateInputTag, "object_name", SOR_item_id ) ) ;
            ITK_CALL ( AOM_set_value_tag ( tItemCreateInputTag, "revision", tRevCreateInputTag ) ) ;

            
            // set properties
           
            
            // Get part description and category (common for both)
            n_found_prt_info = 0 ;
            tc_strcpy ( part_info_on, "ON" ) ; 
            n_found_prt_info = tm_check_control_object ( "SORPRTINF", part_info_on );
            
            if ( n_found_prt_info > 0 )
            {
                ITK_CALL ( AOM_ask_value_string ( objTag, "object_desc", &my_part_desc ) );
                printf("\nmy_part_desc : [%s]", my_part_desc); fflush ( stdout) ;
                TC_write_syslog("\nmy_part_desc : [%s]", my_part_desc);
                
                if ( tc_strcmp ( type_name, "T5_ClrPartRevision" ) == 0 )
                {
                    ITK_CALL(GRM_find_relation_type("TC_Is_Represented_By", &NonClr_Relation));
                    ITK_CALL(GRM_list_secondary_objects_only(objTag, NonClr_Relation, &NonClr_count, &NonClrSet));
                    if ( NonClr_count > 0 )
                    {
                        NonClrRev_t = NonClrSet[0];
                        ITK_CALL ( AOM_ask_value_string ( NonClrRev_t, "t5_SpareCriteria", &my_part_category ) ) ;
                    }
                    else
                    {
                        my_part_category = ( char * ) malloc ( 50 * sizeof (char) );
                        tc_strcpy ( my_part_category, "Not attached to NonCLR" ) ;
                    }
                }
                else
                {
                    ITK_CALL ( AOM_ask_value_string ( objTag, "t5_SpareCriteria", &my_part_category ) ) ;
                }
            }

            if (n_found_PV_QUICK_SOR > 0)
            {
                
                // pv quick sor properties (T5_quicksorRevision)
                
               
                
                if ( n_found_prt_info > 0 )
                {
                    ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_qPrtCat", my_part_category ) ) ;
                    ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSORPartDesc", my_part_desc ) ) ;
                }
                
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartNumber", myItem_id ) ) ;
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartRevision", PartRevision ) ) ;
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPartSeq", PartSequence ) ) ;
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_qBarrelCode", dml_project_code ) ) ;
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_qPPPMPrjCode", "" ) ) ;  // user selects
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSorPrtClrInd", st5_ColourInd ) ) ;
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_qDmlNumber", dml_no ) ) ;
                //ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_qSORRequired", "Y" ) ) ;
                //printf("\n t5_qSORRequired set to: [%s]", commodity_str);
				//TC_write_syslog("\n t5_qSORRequired set to: [%s]", commodity_str);
				// set commodity
				
				   int commodity_value = check_and_set_commodity(objTag);
				   
				   // cnvert int to string
				   char commodity_str[50];
				   sprintf(commodity_str, "%d", commodity_value);
				   
				   if (commodity_value > 0)
				   {
				       
				       ITK_CALL(AOM_set_value_string(tRevCreateInputTag, "t5_qCtrlCommodity", commodity_str));
				       printf("\n Commodity set to: [%s]", commodity_str);
				       TC_write_syslog("\n Commodity set to: [%s]", commodity_str);
				   }
				   else
				   {
				       
				       ITK_CALL(AOM_set_value_string(tRevCreateInputTag, "t5_qCtrlCommodity", ""));
				       printf("\n No design group match, commodity set to empty");
				       TC_write_syslog("\n No design group match, commodity set to empty");
				   }


                printf("\nPV Quick SOR properties set successfully"); fflush(stdout);
                TC_write_syslog("\nPV Quick SOR properties set successfully");
            }
            else
            {
                
                if ( n_found_prt_info > 0 )
                {
                    ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_PrtCat", my_part_category ) ) ;
                    ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_SORPartDesc", my_part_desc ) ) ;
                    ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_SorPartNumber", myItem_id ) ) ;
                    ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_SorPartRevision", PartRevision ) ) ;
                    ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_SorPartSeq", PartSequence ) ) ;
                }
                
                // CV Auto SOR specific properties
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_DmlNumber", dml_no ) ) ;
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_BarrelCode", dml_project_code ) ) ;
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_DMLVertical", product_line ) ) ;
                ITK_CALL ( AOM_set_value_string ( tRevCreateInputTag, "t5_BusinessUnit", business_unit ) ) ;
                
                printf("\nCV Auto SOR properties set successfully"); fflush(stdout);
                TC_write_syslog("\nCV Auto SOR properties set successfully");
            }

            
            
            printf("\n Going to create %s....\n", item_type); fflush ( stdout) ;
            ITK_CALL ( TCTYPE_create_object ( tItemCreateInputTag, &tItemTag ) ) ;
            printf("\n Object created\n"); fflush ( stdout) ;
            
            if (tItemTag != NULLTAG)
            {
                printf("\n %s created successfully\n", item_type); fflush ( stdout) ;

                ITK_CALL ( AOM_refresh ( tItemTag, TRUE ) ) ;
                ITK_CALL ( AOM_save_without_extensions ( tItemTag ) ) ;
                ITK_CALL ( AOM_refresh ( tItemTag, FALSE ) ) ;
                ITK_CALL ( ITEM_ask_latest_rev ( tItemTag, &latestSorrev ) ) ;
				
                //START 14/8
				
				// COPY PROPERTIES AND VARIANT TABLE FROM PREVIOUS ERC RELEASED SOR

				if (n_found_SOR_COPY > 0 && has_prev_erc_sor && prev_sor_rev != NULLTAG && latestSorrev != NULLTAG)
				{
				    printf("\n Copying properties from previous ERC Released SOR...\n");
				    TC_write_syslog("\n Copying properties from previous ERC Released SOR...\n");
				    
				    // Copy properties
				    copy_properties_from_prev_sor(prev_sor_rev, latestSorrev);
				    
				    // Copy variant table 
				    copy_variant_table_from_prev_sor(prev_sor_rev, latestSorrev);
				    
				    // Save after copying
				    ITK_CALL(AOM_lock(latestSorrev));
                    ITK_CALL(AOM_save_without_extensions(latestSorrev));
                    ITK_CALL(AOM_unlock(latestSorrev));
                    ITK_CALL(AOM_refresh(latestSorrev, FALSE));
				}

				// END


                // set released status based on sor type
                
                if (n_found_PV_QUICK_SOR > 0)
                {
                    // pv sor erc working status
                    removeAllReleaseStatus(latestSorrev);
                    printf("\nGoing to ERC Working on PV Quick SOR...."); fflush(stdout);
                    ITK_CALL ( RELSTAT_create_release_status("T5_LcsWorking", &status_rel_SOR));
                    ITK_CALL ( RELSTAT_add_release_status(status_rel_SOR, 1, &latestSorrev, retain_released_date_SOR));
                    printf("\nERC Working stamping on PV Quick SOR...."); fflush(stdout);
                    TC_write_syslog("\nERC Working stamping on PV Quick SOR....");
                }
                else if (tc_strstr(dml_no,"MBOM")!=NULL)
                {
                    
                    ITK_CALL ( RELSTAT_create_release_status("T5_MBOMWorking",&status_rel_SOR));
                    ITK_CALL(RELSTAT_add_release_status(status_rel_SOR,1,&latestSorrev ,retain_released_date_SOR));
                    printf("\nMBOM Working stamping on CV Auto SOR...."); fflush(stdout);
                    TC_write_syslog("\nMBOM Working stamping on CV Auto SOR....");
                }
                else if (tc_strstr(dml_no,"APL")!=NULL)
                {
                    
                    printf("\nDML No : %s",dml_no); fflush(stdout);
                    DMLNO=tc_strtok(dml_no,"_"); 
                    PlantName=tc_strtok(NULL,"_");
                    printf("\nPlantName :%s",PlantName); fflush(stdout);
                    TC_write_syslog("\nPlantName :%s",PlantName);
                    printf("\nGoing to APL Working on CV Auto SOR...."); fflush(stdout);

                    get_CtrlVal_MBOMAPLStateInf(PlantName, APLLifeCylcleWrkState, APLLifeCylcleRevwState);

                    printf("\nLifecycleWorking :%s", APLLifeCylcleWrkState); fflush(stdout);
                    printf("\nLifecycleReview :%s", APLLifeCylcleRevwState); fflush(stdout);

                    ITK_CALL ( RELSTAT_create_release_status(APLLifeCylcleWrkState, &status_rel_SOR));
                    ITK_CALL ( RELSTAT_add_release_status(status_rel_SOR, 1, &latestSorrev, retain_released_date_SOR));
                    printf("\nAPL working stamping on CV Auto SOR...."); fflush(stdout);
                    TC_write_syslog("\nAPL Working stamping on CV Auto SOR....");
                }
                else
                {
                    
                    printf("\nGoing to ERC Working on CV Auto SOR...."); fflush(stdout);
                    ITK_CALL ( RELSTAT_create_release_status("T5_LcsWorking", &status_rel_SOR));
                    ITK_CALL ( RELSTAT_add_release_status(status_rel_SOR, 1, &latestSorrev, retain_released_date_SOR));
                    printf("\nERC Working stamping on CV Auto SOR...."); fflush(stdout);
                    TC_write_syslog("\nERC Working stamping on CV Auto SOR....");
                }

                // Checkout the SOR
                ITK_CALL ( RES_checkout2 ( latestSorrev, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;

                printf("\n%s [%s] revision created successfully\n", item_type, SOR_item_id); fflush ( stdout) ;
                TC_write_syslog("\n%s [%s] revision created successfully\n", item_type, SOR_item_id);

                
              
                
                ITK_CALL ( GRM_find_relation_type ( "T5_PartSorRel", &tRelationFind ) ) ;
                printf("\nfound relation T5_PartSorRel\n"); fflush(stdout);
                TC_write_syslog("\nfound relation T5_PartSorRel\n");
                
                ITK_CALL( GRM_find_relation(objTag, latestSorrev, tRelationFind, &tRelationExist));

                if(tRelationExist)
                {
                    printf("\nRelation already exists\n"); fflush(stdout);
                    TC_write_syslog("\nRelation already exists\n");
                }
                else
                {
                    printf("\nCreating relation between Part and SOR\n"); fflush(stdout);
                    TC_write_syslog("\nCreating relation between Part and SOR\n");
                    ITK_CALL ( GRM_create_relation ( objTag, latestSorrev, tRelationFind, NULLTAG, &PartSorRelTag ) ) ;
                    
                    if (PartSorRelTag != NULLTAG)
                    {
                        ITK_CALL ( GRM_save_relation ( PartSorRelTag ) ) ;
                        ITK_CALL ( AOM_refresh ( objTag, 0 ) );
                        printf("\nSOR [%s] and part [%s] relation created successfully\n", SOR_item_id, myItem_id); fflush ( stdout) ;
                        TC_write_syslog("\nSOR [%s] and part [%s] relation created successfully\n", SOR_item_id, myItem_id);
                    }
                }
            }
        }

					else
						{
						    printf("\nSOR already exists: [%s]", SOR_item_id);
						    TC_write_syslog("\nSOR already exists: [%s]", SOR_item_id);
						
						    if (n_found_PV_QUICK_SOR > 0)
						    {
						        if (n_found_SOR_COPY > 0)
						        {
						            printf("\n SOR_COPY enabled - SOR already exists, continuing...\n");
						            TC_write_syslog("\n SOR_COPY enabled - SOR already exists, continuing...\n");
						            
						            // In the "SOR already exists" block
									if (has_prev_erc_sor && prev_sor_rev != NULLTAG)
									{
									    printf("\n Copying properties from previous ERC Released SOR to existing SOR...\n");
									    TC_write_syslog("\n Copying properties from previous ERC Released SOR to existing SOR...\n");
									    
									    tag_t existing_sor_rev = NULLTAG;
									    ITK_CALL(ITEM_ask_latest_rev(items[0], &existing_sor_rev));
									    
									    if (existing_sor_rev != NULLTAG)
									    {
									        // Copy properties
									        copy_properties_from_prev_sor(prev_sor_rev, existing_sor_rev);
									        
									        // Copy variant table (copy as it is from previous SOR)
									        copy_variant_table_from_prev_sor(prev_sor_rev, existing_sor_rev);
									        
									       // ITK_CALL(AOM_save_without_extensions(existing_sor_rev));
									        ITK_CALL(AOM_refresh(existing_sor_rev, FALSE));
									    }
									}
						            
						            EMH_clear_errors();
						            EMH_store_error_s1(EMH_severity_warning, ITK_err, "Quick SOR already exists (Copy mode)");
						            TC_write_syslog ( "\nSOR already exists....: [%s] - Copy mode, continuing", SOR_item_id ) ;
						            
						            if (items) MEM_free(items);
						            return ITK_ok;
						        }
						        else
						        {
						            
						            EMH_clear_errors();
						            EMH_store_error_s1(EMH_severity_warning, ITK_err, "Quick SOR already exists ");
						            TC_write_syslog ( "\nSOR already exists....: [%s]", SOR_item_id ) ;
						            
						            if (items) MEM_free(items);
						            return ITK_err;
						        }
						    }
						}

		}
	cleanup_and_return:

    return ITK_ok;
}
        
    

int SorCrValidation ( tag_t task_tag, tag_t design_tag )
{
	int	ifail = 0;

	char *st5_OwningG = NULL;
	char *sitem_id_partno = NULL;
	char *sitem_revision_id = NULL;
	char *st5_PartType = NULL;
	char *st5_DrawingInd = NULL;
	char *st5_ColourInd = NULL;
	char *PartRevision = NULL;
	char *PartSequence = NULL;
	//char dsg_type_name[TCTYPE_name_size_c+1];
	char *dsg_type_name = NULL;
	tag_t desgobjTypeTag = NULLTAG ;
	char *dml_no = NULL;
	char *dml_project_code = NULL;
	char *dml_rlz_type = NULL;
	char *business_unit = NULL;
	char *product_line = NULL;
	char *info1 = NULL;
	char *info2 = NULL;
	int n_found_BU = 0 ;
	int n_found_PL = 0 ;
	int n_found_PRT_TYPE = 0 ;
	int n_found_DRW_IND = 0 ;
	int n_found_CLR_IND = 0 ;
	int n_found_DML_PRJ_CODE = 0 ;
	int n_found_DML_RLZ_TYPE = 0 ;
	int n_found_BO_CLASS_TYPE = 0 ;
	int n_found_NON_NR_SOR = 0;
	logical isSpareIndtr = FALSE;  // Declare logical variable
	char *st5_SpareIndtr = NULL;
	int n_found_SPR_IND = 0 ;
	//char *DrawingInd = NULL;

	dml_no = ( char * ) MEM_alloc ( 20 * sizeof ( char ) );
	dml_project_code = ( char * ) MEM_alloc ( 10 * sizeof ( char ) );
	dml_rlz_type = ( char * ) MEM_alloc ( 100 * sizeof ( char ) );
	business_unit = ( char * ) MEM_alloc ( 10 * sizeof ( char ) );
	product_line = ( char * ) MEM_alloc ( 10 * sizeof ( char ) );
	info1 = ( char * ) MEM_alloc ( 50 * sizeof ( char ) );
	info2 = ( char * ) MEM_alloc (50* sizeof ( char ) );

	Get_dml_details ( task_tag, dml_no, dml_project_code, dml_rlz_type, business_unit, product_line ) ;


	printf ( "\nSorCrValidation dml_rlz_type : [%s]", dml_rlz_type ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSorCrValidation dml_rlz_type : [%s]", dml_rlz_type ) ;
	printf ( "\nSorCrValidation business_unit : [%s]", business_unit ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSorCrValidation business_unit : [%s]", business_unit ) ;
	printf ( "\nSorCrValidation product_line : [%s]", product_line ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSorCrValidation product_line : [%s]", product_line ) ;
	printf ( "\nSorCrValidation dml_project_code : [%s]", dml_project_code ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSorCrValidation dml_project_code : [%s]", dml_project_code ) ;

	printf ( "\nSorCrValidation DML : [%s]", dml_no ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nSorCrValidation DML : [%s]", dml_no ) ;

	n_found_BU = tm_check_control_object ( "SORCOBU", business_unit );//busniness unit
	n_found_PL = tm_check_control_object ( "SORCOPL", product_line );//product line or vertical
	//n_found_DML_PRJ_CODE = tm_check_control_object ( "SORDMLPRCODE", dml_project_code );//product line or vertical
	n_found_DML_PRJ_CODE = tm_check_control_object_ERCLive ( "ERCLive", dml_project_code );//DML Project code Hrishikesh 12.02.2024
	n_found_DML_RLZ_TYPE = tm_check_control_object ( "SORDMLRLZTYPE", dml_rlz_type );//dml release type

	printf ( "\ndml release type count [%s] : [%d]", dml_rlz_type, n_found_DML_RLZ_TYPE ) ; fflush ( stdout) ;
	TC_write_syslog ( "\ndml release type count [%s] : [%d]", dml_rlz_type, n_found_DML_RLZ_TYPE ) ;

	if ( n_found_DML_RLZ_TYPE <= 0 ) //dml release type control object not found hence skipping
	{
		printf ( "\thence skipping SOR creation dml release type" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\thence skipping SOR creation dml release type" ) ;
		return 0 ;
	}


	printf ( "\nBusiness unit count [%s] : [%d]", business_unit, n_found_BU ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nBusiness unit count [%s] : [%d]", business_unit, n_found_BU ) ;

	if ( n_found_BU <= 0 ) //Business unit control object not found hence skipping
	{
		printf ( "\thence skipping SOR creation BU" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\thence skipping SOR creation BU" ) ;
		return 0 ;
	}

	printf ( "\nProduct Line vertical count [%s] : [%d]", product_line, n_found_PL ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nProduct Line vertical count [%s] : [%d]", product_line, n_found_PL ) ;

	if ( n_found_PL <= 0 ) //vertical control object "not found" hence skipping SOR creation
	{
		printf ( "\thence skipping SOR creation vertical" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\thence skipping SOR creation vertical" ) ;
		return 0 ;
	}

	printf ( "\nDML Product code count [%s] : [%d]", dml_project_code, n_found_DML_PRJ_CODE ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nDML Product code count [%s] : [%d]", dml_project_code, n_found_DML_PRJ_CODE ) ;

//	if ( n_found_DML_PRJ_CODE > 0 )//project code "found" hence skip sor creation for those project
//	{
//		printf ( "\thence skipping SOR creation projectcode" ) ;
//		TC_write_syslog ( "\thence skipping SOR creation projectcode" ) ;
//		return 0 ;
//	}

	if ( n_found_DML_PRJ_CODE <= 0 )//project code "found" hence skip sor creation for those project
	{
		printf ( "\thence skipping SOR creation projectcode" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\thence skipping SOR creation projectcode" ) ;
		return 0 ;
	}

	ITK_CALL ( TCTYPE_ask_object_type ( design_tag, &desgobjTypeTag ) );
	//ITK_CALL ( TCTYPE_ask_name ( desgobjTypeTag, dsg_type_name ) );
	ITK_CALL ( TCTYPE_ask_name2 ( desgobjTypeTag, &dsg_type_name ) );

	n_found_BO_CLASS_TYPE = tm_check_control_object ( "SORBOCLSTYPE", dsg_type_name );//Design Revision

	printf ( "\nBusiness object type or class count [%s] : [%d]", dsg_type_name, n_found_BO_CLASS_TYPE ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nBusiness object type or class count [%s] : [%d]", dsg_type_name, n_found_BO_CLASS_TYPE ) ;

	//if ( tc_strcmp ( dsg_type_name, "Design Revision" ) == 0 )//it was handling only design revision hence control object base to handle various classes
	if ( n_found_BO_CLASS_TYPE > 0 ) // if business object type or class found in control object then only create SOR = Design Revision
	{
		ITK_CALL ( AOM_ask_value_string ( design_tag, "item_id", &sitem_id_partno ) ) ;
		ITK_CALL ( AOM_ask_value_string ( design_tag, "item_revision_id", &sitem_revision_id ) ) ;
		ITK_CALL ( AOM_ask_value_string ( design_tag, "t5_PartType", &st5_PartType ) ) ;
		ITK_CALL ( AOM_ask_value_string ( design_tag, "t5_DrawingInd", &st5_DrawingInd ) ) ;
		ITK_CALL ( AOM_ask_value_string ( design_tag, "t5_ColourInd", &st5_ColourInd ) ) ;
		ITK_CALL ( AOM_UIF_ask_value	( design_tag, "owning_group", &st5_OwningG ) ) ;//for MBOM sor creation 

		printf ( "\nowning_group : [%s]", st5_OwningG ) ; fflush ( stdout) ;
		printf ( "\nsitem_id_partno : [%s]", sitem_id_partno ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nsitem_id_partno : [%s]", sitem_id_partno ) ;
		printf ( "\nsitem_revision_id : [%s]", sitem_revision_id ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nsitem_revision_id : [%s]", sitem_revision_id ) ;
		printf ( "\nst5_PartType : [%s]", st5_PartType ) ;//check valid part types
		fflush ( stdout) ;
		TC_write_syslog ( "\nst5_PartType : [%s]", st5_PartType ) ;//check valid part types
		printf ( "\nst5_DrawingInd : [%s]", st5_DrawingInd ) ;//check drawing ind D/A
		fflush ( stdout) ;
		TC_write_syslog ( "\nst5_DrawingInd : [%s]", st5_DrawingInd ) ;//check drawing ind D/A
		printf ( "\nsst5_ColourInd : [%s]", st5_ColourInd ) ;//check colour ind
		fflush ( stdout) ;
		TC_write_syslog ( "\nsst5_ColourInd : [%s]", st5_ColourInd ) ;//check colour ind

		n_found_PRT_TYPE = tm_check_control_object ( "SORCOPRTTYPE", st5_PartType );//valid part types
		n_found_DRW_IND = tm_check_control_object ( "SORCODRWIND", st5_DrawingInd );//valid drawing ind
		n_found_CLR_IND = tm_check_control_object ( "SORCOCLRIND", st5_ColourInd );//valid colour ind



		printf ( "\nPart type count [%s] : [%d]", st5_PartType, n_found_PRT_TYPE ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nPart type count [%s] : [%d]", st5_PartType, n_found_PRT_TYPE ) ;

		if ( n_found_PRT_TYPE <= 0 )//part type not found in control object
		{
			printf ( "\thence skipping SOR creation part type" ) ; fflush ( stdout) ;
			TC_write_syslog ( "\thence skipping SOR creation part type" ) ;
			return 0 ;
		}

		printf ( "\nDrawing indicator count [%s] : [%d]", st5_DrawingInd, n_found_DRW_IND ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nDrawing indicator count [%s] : [%d]", st5_DrawingInd, n_found_DRW_IND ) ;

	/* 	if ( n_found_DRW_IND <= 0 )//drawing indicator not found in control object
		{
			printf ( "\thence skipping SOR creation drawing indicator" ) ; fflush ( stdout) ;
			TC_write_syslog ( "\thence skipping SOR creation drawing indicator" ) ;
			return 0 ;
		} */

			if ( n_found_DRW_IND > 0 )//drawing indicator found in control object 
			{
				
				printf ( "\n DrawingInd D or A found SO Continue ");
			}
			else 		
			{
				//int n_found_SPR_IND = 0 ;
				// Get the logical value of "t5_SpareInd"
				ITK_CALL(AOM_ask_value_logical(design_tag, "t5_SpareInd", &isSpareIndtr));
				 
				if (isSpareIndtr) 
				{
					st5_SpareIndtr = "True";  // Assign string representation
				} 
				else 
				{
					st5_SpareIndtr = "False";
				}
				
				
				TC_write_syslog ( "\n st5_SpareIndtr : [%s]", st5_SpareIndtr ) ; //check Spare Indicator ind True or +
				n_found_SPR_IND = tm_check_control_object ( "SORCOSPRIND", st5_SpareIndtr );//valid Spare Inicator
				if ( n_found_SPR_IND > 0 )
				{
					printf ( "\n DrawingInd not found but Spare Indicator Found, SO Continue for SOR Creation");
					TC_write_syslog ( "\tDrawingInd not found but Spare Indicator Found, SO Continue for SOR Creation" ) ;
				}	
				else 				
				{
					printf ( "\thence skipping SOR creation - Please check drawing/Spare indicator " ) ; fflush ( stdout) ;
					TC_write_syslog ( "\thence skipping SOR creation - Please check drawing/Spare indicator" ) ;
					return 0;
				}				
			}
		
		
		
		printf ( "\nColour indicator count [%s] : [%d]", st5_ColourInd, n_found_CLR_IND ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nColour indicator count [%s] : [%d]", st5_ColourInd, n_found_CLR_IND ) ;

		if ( n_found_CLR_IND <= 0 )//colour indicator not found in control object
		{
			printf ( "\thence skipping SOR creation colour indicator" ) ;  fflush ( stdout) ;
			TC_write_syslog ( "\thence skipping SOR creation colour indicator" ) ;
			return 0 ;
		}


		if ( tc_strstr ( sitem_revision_id, ";" ) != NULL )
		{
			PartRevision = strtok(sitem_revision_id, ";");
			PartSequence = strtok(NULL, ";");
		}
		else
		{
			PartRevision = MEM_alloc ( 10 ) ;
			PartSequence = MEM_alloc ( 10 ) ;
			tc_strcpy ( PartRevision, sitem_revision_id ) ;
			tc_strcpy ( PartSequence, "" ) ;
		}
		
		if (tc_strstr(dml_no,"MBOM")!=NULL)
		{
			if (tc_strstr(st5_OwningG,"MBOM")!=NULL)
			{
				//if ( tc_strcmp ( PartRevision, "NR" ) == 0 )//AUTOSOR LIVE FOR ALL REV FOR MBOM
				//{
					printf ( "\n Going for SOR creation" ) ;  fflush ( stdout) ;
					Create_SOR ( design_tag, dsg_type_name, sitem_id_partno, PartRevision, PartSequence, dml_no, dml_project_code, business_unit, product_line,task_tag,st5_ColourInd) ;
				//}
				//else
				//{
					//printf ( "\n Part revision  is other than NR" ) ;  fflush ( stdout) ;
					//TC_write_syslog ( "\n Part revision  is other than NR" ) ;
				//}

			}
			else
			{
				printf ( "\n Part OWNER is not MBOM" ) ;  fflush ( stdout) ;
				TC_write_syslog ( "\n Part OWNER is not MBOM" ) ;

			}

		}
		else if (tc_strstr(dml_no,"APL")!=NULL) //Venkat check3
		{
			if (tc_strstr(st5_OwningG,"APL")!=NULL) 
			{
					printf ( "\n Going for SOR creation for APL" ) ;  fflush ( stdout) ;
					Create_SOR ( design_tag, dsg_type_name, sitem_id_partno, PartRevision, PartSequence, dml_no, dml_project_code, business_unit, product_line,task_tag,st5_ColourInd) ;
			}
			else
			{
				printf ( "\n Part OWNER is not APL" ) ;  fflush ( stdout) ;
				TC_write_syslog ( "\n Part OWNER is not APL" ) ;

			}

		}
		else if (tc_strstr(dml_no,"APL")==NULL)//If DML is ERC DML not contain APL string
		{
			//added shrivardhan
			//ERC SOR creation

             n_found_NON_NR_SOR = tm_check_info_control_object ( "NONNRSOR", "ON", info1, info2);
	         if ( n_found_NON_NR_SOR > 0 )
		     {
		        
		     	   TC_write_syslog ( "\n ERC DML Creating SOR for NON NR Revision" ) ;
		     	   Create_SOR ( design_tag, dsg_type_name, sitem_id_partno, PartRevision, PartSequence, dml_no, dml_project_code, business_unit, product_line,task_tag,st5_ColourInd) ;
		     }
		     else
		     {
		     	if ( tc_strcmp ( PartRevision, "NR" ) == 0 )
		         {
		     	    TC_write_syslog ( "\nERC DML Creating SOR for NR Revision" ) ;
		     	    Create_SOR ( design_tag, dsg_type_name, sitem_id_partno, PartRevision, PartSequence, dml_no, dml_project_code, business_unit, product_line,task_tag,st5_ColourInd) ;
		     	}
		     }
		}

	}
	else
	{
		printf ( "\thence skipping SOR creation business object type or class" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\thence skipping SOR creation business object type or class" ) ;
		return 0 ;
	}

	return ifail;
}
//dbk added code for SOR
int T5TaskToPart_SORCreateVal ( METHOD_message_t *msg, va_list  args )
{
	va_list largs;
	va_copy( largs, args );
	//char type_name[TCTYPE_name_size_c+1];
	char *type_name = NULL;
	//char secndry_obj_type_name[TCTYPE_name_size_c+1];
	char *secndry_obj_type_name = NULL;
	tag_t  primary_object = va_arg(largs, tag_t);
	tag_t  secondary_object = va_arg(largs, tag_t);
	tag_t  relation_type = va_arg(largs, tag_t);
	tag_t  user_data = va_arg(largs, tag_t);
	tag_t  *new_relation = va_arg(largs, tag_t *);
	tag_t objTypeTag1 = NULLTAG ;
	tag_t objTypeTag2 = NULLTAG ;
	//char   relation_name[TCTYPE_name_size_c+1];
	char   *relation_name = NULL;
	int n_found_BO_CLASS_TYPE = 0 ;
	int n_AUTOSOR_LIVE = 0;
	int n_AUTOSOR_TASK_BOTYPE = 0;
	int n_AUTOSOR_TASK_PART_REL_NAME = 0;

	n_AUTOSOR_LIVE = tm_check_control_object ( "AUTOSOR_LIVE", "TRUE" );//autosor functionality live

	if ( n_AUTOSOR_LIVE > 0 )
	{
		
		printf ( "\nAutoSOR is live : [%d]",n_AUTOSOR_LIVE ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nAutoSOR is live : [%d]",n_AUTOSOR_LIVE ) ;
		
		ITK_CALL ( TCTYPE_ask_object_type ( primary_object, &objTypeTag1 ) ) ;
		//ITK_CALL ( TCTYPE_ask_name ( objTypeTag1, type_name ) ) ;
		ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag1, &type_name ) ) ;

		ITK_CALL ( TCTYPE_ask_object_type ( secondary_object, &objTypeTag2 ) ) ;
		//ITK_CALL ( TCTYPE_ask_name ( objTypeTag2, secndry_obj_type_name ) ) ;
		ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag2, &secndry_obj_type_name ) ) ;
		//ITK_CALL ( TCTYPE_ask_name ( relation_type, relation_name ) ) ;
		ITK_CALL ( TCTYPE_ask_name2 ( relation_type, &relation_name ) ) ;

		//dbk added code for SOR
		printf ( "\nT5TaskToPart_SORCreateVal : dbk testing after SOR T5TaskToPart_SORCreateVal" ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nT5TaskToPart_SORCreateVal : dbk testing after SOR T5TaskToPart_SORCreateVal" ) ;
		printf ( "\nT5TaskToPart_SORCreateVal : secndry_obj_type_name : [%s]", secndry_obj_type_name ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nT5TaskToPart_SORCreateVal : secndry_obj_type_name : [%s]", secndry_obj_type_name ) ;
		printf ( "\nT5TaskToPart_SORCreateVal : type_name : [%s]", type_name ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nT5TaskToPart_SORCreateVal : type_name : [%s]", type_name ) ;
		printf ( "\nT5TaskToPart_SORCreateVal : relation_name : [%s]", relation_name ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nT5TaskToPart_SORCreateVal : relation_name : [%s]", relation_name ) ;
		
		if ( ( tc_strcmp(relation_name, "HasParticipant" ) == 0 ) && ( tc_strcmp(type_name, "T5_quicksorRevision" ) == 0 )   )//assign participant to quicksorrevision
		{
			char *Assignee = NULL;
			int n_qsor_reviwer = 0;
			n_qsor_reviwer = tm_check_control_object ( "QSORGRPACCESS", "ON" );
			printf ( "\nn_qsor_reviwer : [%d]", n_qsor_reviwer ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nn_qsor_reviwer : [%d]", n_qsor_reviwer ) ;
		
			if ( n_qsor_reviwer > 0 )
			{
				if ( tc_strcmp(secndry_obj_type_name, "T5_SORVIGReviewer" ) == 0 )
				{
					printf("\nCalling validation for Quick T5_SORVIGReviewer"); fflush ( stdout) ;
					TC_write_syslog("\nCalling validation for Quick T5_SORVIGReviewer");
					ITK_CALL(AOM_UIF_ask_value(secondary_object,"assignee",&Assignee));
					
					printf("\nT5_SORVIGReviewer Assignee : [%s]",Assignee); fflush ( stdout) ;
					TC_write_syslog("\nT5_SORVIGReviewer Assignee : [%s]",Assignee);
					
					if ( tc_strstr ( Assignee, "QSOR_VIG_Reviewer") == NULL )
					{
						printf("\nQSOR VIG Reviewer should be from QSOR_VIG_Reviewer role"); fflush ( stdout) ;
						TC_write_syslog("\nQSOR VIG Reviewer should be from QSOR_VIG_Reviewer role");
						
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nERROR: QSOR VIG Reviewer should be from QSOR_VIG_Reviewer role");
						return ITK_err;
					}
					
					
				}
				else if ( tc_strcmp(secndry_obj_type_name, "T5_SORReviewer" ) == 0 )
				{
					printf("\nCalling validation for Quick T5_SORVIGReviewer"); fflush ( stdout) ;
					TC_write_syslog("\nCalling validation for Quick T5_SORVIGReviewer");
					ITK_CALL(AOM_UIF_ask_value(secondary_object,"assignee",&Assignee));
					
					printf("\nT5_SORReviewer Assignee : [%s]",Assignee); fflush ( stdout) ;
					TC_write_syslog("\nT5_SORReviewer Assignee : [%s]",Assignee);
					if ( tc_strstr ( Assignee, "QSOR_Reviewer") == NULL )
					{
						printf("\nQSOR Reviewer should be from QSOR_Reviewer role"); fflush ( stdout) ;
						TC_write_syslog("\nQSOR Reviewer should be from QSOR_Reviewer role");
					
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nERROR: QSOR Reviewer should be from QSOR_Reviewer role");
						return ITK_err;
					}
				}
			}
			
		}
		else if ( ( tc_strcmp(relation_name, "HasParticipant" ) == 0 ) && ( tc_strcmp(type_name, "T5_RfiSorRevision" ) == 0 )   )//assign participant to rfisorrevision
		{
			//RFI_CEReviewer
			//RFI_CoCHOD
			char *Assignee = NULL;
			int n_rfisor_reviwer = 0;
			n_rfisor_reviwer = tm_check_control_object ( "RFISORGRPACCESS", "ON" );
			printf ( "\nn_rfisor_reviwer : [%d]", n_rfisor_reviwer ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nn_rfisor_reviwer : [%d]", n_rfisor_reviwer ) ;
			
			if ( n_rfisor_reviwer > 0 )
			{
				if ( tc_strcmp(secndry_obj_type_name, "T5_RFICEReviewer" ) == 0 )
				{
					printf("\nCalling validation for RFI T5_RFICEReviewer"); fflush ( stdout) ;
					TC_write_syslog("\nCalling validation for RFI T5_RFICEReviewer");
					ITK_CALL(AOM_UIF_ask_value(secondary_object,"assignee",&Assignee));
					
					printf("\nT5_RFICEReviewer Assignee : [%s]",Assignee); fflush ( stdout) ;
					TC_write_syslog("\nT5_RFICEReviewer Assignee : [%s]",Assignee);
					
					if ( tc_strstr ( Assignee, "RFI_CEReviewer") == NULL )
					{
						printf("\nRFISOR CE Reviewer should be from RFI_CEReviewer role"); fflush ( stdout) ;
						TC_write_syslog("\nRFISOR CE Reviewer should be from RFI_CEReviewer role");
						
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nERROR: RFISOR CE Reviewer should be from RFI_CEReviewer role");
						return ITK_err;
					}
					
					
				}
				else if ( tc_strcmp(secndry_obj_type_name, "T5_RFICoCHOD" ) == 0 )
				{
					printf("\nCalling validation for RFI T5_RFICoCHOD"); fflush ( stdout) ;
					TC_write_syslog("\nCalling validation for RFI T5_RFICoCHOD");
					ITK_CALL(AOM_UIF_ask_value(secondary_object,"assignee",&Assignee));
					
					printf("\nT5_RFICoCHOD Assignee : [%s]",Assignee); fflush ( stdout) ;
					TC_write_syslog("\nT5_RFICoCHOD Assignee : [%s]",Assignee);
					if ( tc_strstr ( Assignee, "RFI_CoCHOD") == NULL )
					{
						printf("\nRFISOR CoC HOD should be from RFI_CoCHOD role"); fflush ( stdout) ;
						TC_write_syslog("\nRFISOR CoC HOD should be from RFI_CoCHOD role");
					
						EMH_clear_errors();
						EMH_store_error_s1(EMH_severity_error,ITK_err,"\nERROR: RFISOR CoC HOD should be from RFI_CoCHOD role");
						return ITK_err;
					}
				}
			}
			
		}
		else	//attach part to task and create autosor
		{
			
			n_found_BO_CLASS_TYPE = tm_check_control_object ( "SORBOCLSTYPE", secndry_obj_type_name );//Design Revision is secondary object
			printf ( "\nT5TaskToPart_SORCreateVal : first check Business object type or class count [%s] : [%d]", secndry_obj_type_name, n_found_BO_CLASS_TYPE ) ; fflush ( stdout) ;
			TC_write_syslog ( "\nT5TaskToPart_SORCreateVal : first check Business object type or class count [%s] : [%d]", secndry_obj_type_name, n_found_BO_CLASS_TYPE ) ;
		
			printf("\ndml TASK Business object type name : [%s]",type_name); fflush ( stdout) ;
			TC_write_syslog("\ndml TASK Business object type name : [%s]",type_name);
			
			n_AUTOSOR_TASK_BOTYPE = tm_check_control_object ( "AUTOSOR_TASK_BOTYPE", type_name );//task business object type ERC TASK/APL task
			//if ( ( n_found_BO_CLASS_TYPE > 0 ) && ( tc_strcmp ( type_name, "T5_ChangeTaskRevision" ) == 0 ) )
			if ( ( n_found_BO_CLASS_TYPE > 0 ) && ( n_AUTOSOR_TASK_BOTYPE > 0 ) )
			{
				//printf("\ndbk testing 1");
				printf("\nRelation object check : [%s]",relation_name); fflush ( stdout) ;
				TC_write_syslog("\nRelation object check : [%s]",relation_name);
				//if ( tc_strcmp ( relation_name, "CMHasSolutionItem" ) == 0 )
				n_AUTOSOR_TASK_PART_REL_NAME = tm_check_control_object ( "AUTOSOR_TASK_PART_REL_NAME", relation_name );
				if ( n_AUTOSOR_TASK_PART_REL_NAME > 0 )
				{
					TC_write_syslog("\nbefore SorCrValidation");
					SorCrValidation ( primary_object, secondary_object );
					TC_write_syslog("\nafter SorCrValidation");
				}
			}
			//printf("\ndbk testing after SOR");
			TC_write_syslog("\nend T5TaskToPart_SORCreateVal");
		}
	}
	else
	{
		printf ( "\nAutoSOR is not live : [%d]",n_AUTOSOR_LIVE ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nAutoSOR is not live : [%d]",n_AUTOSOR_LIVE ) ;
		
	}
	return ITK_ok;
}

int SOR_Save_PreCond_Validation(METHOD_message_t *msg, va_list args)
{
	printf("\n***** INSIDE SOR_Save_PreCond_Validation ***** \n");fflush(stdout);
	int	ifail = 0;
	tag_t P_Obj_Type = NULLTAG;
	//char Ptype_name[WSO_name_size_c+1];
	char *Ptype_name = NULL;
	tag_t Currproj = NULLTAG;
	//char *st5_session_prj_code = NULL;
	char *sor_t5_BarrelCode = NULL;


	tag_t P_Obj = va_arg(args, tag_t);
	tag_t S_Obj =  va_arg(args, tag_t);

	ITK_CALL ( TCTYPE_ask_object_type(P_Obj,&P_Obj_Type ) );
	//ITK_CALL ( TCTYPE_ask_name(P_Obj_Type,Ptype_name ) );
	ITK_CALL ( TCTYPE_ask_name2(P_Obj_Type,&Ptype_name ) );
	printf("\nmethod_save_pre_cond_sor BO type:  %s\n",Ptype_name);fflush(stdout);
	TC_write_syslog ("\nmethod_save_pre_cond_sor BO type:  %s\n",Ptype_name);fflush(stdout);

	if ( tc_strcmp ( Ptype_name, "T5_AutoSorRevision" ) == 0)
	{
		
		
		/*ITK_CALL ( SA_ask_current_project ( &Currproj ) );
		ITK_CALL ( AOM_ask_value_string(Currproj,"object_name",&st5_session_prj_code) );
		printf ( "\nsession st5_session_prj_code : [%s]", st5_session_prj_code ) ; fflush ( stdout) ;
		TC_write_syslog ( "\nsession st5_session_prj_code : [%s]", st5_session_prj_code ) ;*/	//Rajan 20-12-2024 instance locked

		ITK_CALL ( AOM_ask_value_string ( P_Obj, "t5_BarrelCode", &sor_t5_BarrelCode ) ) ;
		TC_write_syslog ( "\nsor_t5_BarrelCode : [%s]", sor_t5_BarrelCode ) ;
		
		/*if ( tc_strcmp ( st5_session_prj_code, sor_t5_BarrelCode ) != 0 )
		{
			EMH_store_error_s1(EMH_severity_error,ITK_err,"Change session project value as per dml project!!!");
			return ITK_err;
		}*/
	}

	return ifail;
}

extern DLLAPI int prop_PPPProjValueChange_ChngVariant(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	char *sor_t5_PPPMPrjCode = NULL;
	char *dml_project_code = NULL;

	
	TC_write_syslog("\nINSIDE prop_PPPProjValueChange_ChngVariant*** \n");fflush(stdout);
	
	tag_t autosorRev = msg->object_tag;

	// 	ITK_CALL ( AOM_set_value_string ( autosorRev, "t5_RefSOR", "Used by Designer" ) ) ;		//testing
			
	ITK_CALL ( AOM_ask_value_string ( autosorRev, "t5_BarrelCode", &dml_project_code ) ) ;
	printf ( "\nprop_PPPProjValueChange_ChngVariant : dml_project_code : [%s]", dml_project_code ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nprop_PPPProjValueChange_ChngVariant : dml_project_code : [%s]", dml_project_code ) ;

	ITK_CALL ( AOM_ask_value_string ( autosorRev, "t5_PPPMPrjCode", &sor_t5_PPPMPrjCode ) ) ;
	printf ( "\nprop_PPPProjValueChange_ChngVariant : sor_t5_PPPMPrjCode pre : [%s]", sor_t5_PPPMPrjCode ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nprop_PPPProjValueChange_ChngVariant : sor_t5_PPPMPrjCode pre : [%s]", sor_t5_PPPMPrjCode ) ;

	if ( tc_strcmp ( sor_t5_PPPMPrjCode, "" ) != 0 )
	{
		tm_get_pppm_variant ( autosorRev, dml_project_code, sor_t5_PPPMPrjCode);
	}
	else
	{
		TC_write_syslog("\nprop_PPPProjValueChange_ChngVariant : Select valid PPPM Project code\n");fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,PLM_error,"select valid PPPM project code from dropdown list");
		return PLM_error;
	}

	return error_code;
}

extern DLLAPI int prop_rfi_PPPProjValChg_ChgVariant(METHOD_message_t *msg, va_list args)
{
	int error_code = ITK_ok;
	char *rfi_PPPMPrjCode = NULL;
	char *RfiVerticle = NULL;
	char *info1 = NULL;
	char *info2 = NULL;
	int n_found_rfi_var = 0;

	info1 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	info2 = ( char * ) MEM_alloc (200* sizeof ( char ) );
	tc_strcpy ( info1, "" ) ;
	tc_strcpy ( info2, "" ) ;
	
	n_found_rfi_var = tm_check_info_control_object ( "RFIVAR", "ON", info1, info2 );
	if ( n_found_rfi_var <= 0 )
	{
		TC_write_syslog ( "\nRFIVAR is not ON hence can not fetch RFI variant info" ) ;
		return error_code;
	}
	
	TC_write_syslog("\nINSIDE prop_rfi_PPPProjValChg_ChgVariant*** \n");fflush(stdout);
	
	tag_t rfi_sorRev = msg->object_tag;

			
	ITK_CALL ( AOM_ask_value_string ( rfi_sorRev, "t5_RfiVerticle", &RfiVerticle ) ) ;
	printf ( "\nprop_rfi_PPPProjValChg_ChgVariant : RfiVerticle : [%s]", RfiVerticle ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nprop_rfi_PPPProjValChg_ChgVariant : RfiVerticle : [%s]", RfiVerticle ) ;

	ITK_CALL ( AOM_ask_value_string ( rfi_sorRev, "t5_RfiPPPMPrjCode", &rfi_PPPMPrjCode ) ) ;
	printf ( "\nprop_rfi_PPPProjValChg_ChgVariant : rfi_PPPMPrjCode pre : [%s]", rfi_PPPMPrjCode ) ; fflush ( stdout) ;
	TC_write_syslog ( "\nprop_rfi_PPPProjValChg_ChgVariant : rfi_PPPMPrjCode pre : [%s]", rfi_PPPMPrjCode ) ;

	if ( tc_strcmp ( rfi_PPPMPrjCode, "" ) != 0 )
	{
		tm_get_rfi_pppm_variant ( rfi_sorRev, RfiVerticle, rfi_PPPMPrjCode);
	}
	else
	{
		TC_write_syslog("\nprop_rfi_PPPProjValChg_ChgVariant : Select valid PPPM Project code for RFI SOR\n");fflush(stdout);
		EMH_store_error_s1(EMH_severity_error,PLM_error,"Select valid PPPM project code from dropdown list");
		return PLM_error;
	}

	return error_code;
}

int chk_underscore_count(char* item_ids, char c)
{
	int res = 0;
	int i = 0;
	for (i = 0; i < tc_strlen(item_ids);i++)
		if (item_ids[i] == c)
			res++;
	return res;
}

extern DLLAPI int RFISOR_save_method_pre ( METHOD_message_t *m, va_list args )
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	char *type_name = NULL;
	char *sor_t5_PPPMPrjCode = NULL;
	tag_t item = NULLTAG;
	int und_scr_count = 0;
	char *rfi_item_id = NULL;

	ITK_CALL ( TCTYPE_ask_object_type ( objTag, &objTypeTag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag, &type_name ) );

	printf ( "\nT5_RfiSorRevision_save_method_pre type_name : [%s]", type_name ) ;
	TC_write_syslog ( "\nT5_RfiSorRevision_save_method_pre type_name : [%s]", type_name ) ;
	if ( tc_strcmp ( type_name, "T5_RfiSorRevision" ) == 0 )
	{
		ITEM_ask_item_of_rev (objTag,&item);
		ITK_CALL ( AOM_ask_value_string ( item, "item_id", &rfi_item_id ) ) ;
		printf ( "\nrfi_item_id : [%s]", rfi_item_id ) ;
		TC_write_syslog ( "\nrfi_item_id : [%s]", rfi_item_id ) ;

		und_scr_count = chk_underscore_count ( rfi_item_id, '_' );

		printf ( "\nPre no of underscore in item_id string : [%d]", und_scr_count ) ;
		TC_write_syslog ( "\nPre no of underscore in item_id string : [%d]", und_scr_count ) ;

//		if ( und_scr_count != 4 )
//		{
//			EMH_store_error_s1(EMH_severity_error,PLM_error,"select RFI, Business Unit, Design Group, Year, Underscrore from Drop downlist");
//			printf("\nselect RFI, Business Unit, Design Group, Year, Underscrore from Drop downlist");
//			TC_write_syslog ( "\nselect RFI, Business Unit, Design Group, Year, Underscrore from Drop downlist");
//			return PLM_error;
//		}
	}
	return ITK_ok;
}


extern DLLAPI int RFISOR_save_method_post ( METHOD_message_t *m, va_list args )
{
	tag_t objTag = va_arg(args, tag_t);
	tag_t objTypeTag = NULLTAG;
	tag_t item = NULLTAG;
	char *rfi_item_id = NULL;
	char *type_name = NULL;

	char *RFIstr = NULL;
	char *BUstr = NULL;
	char *Dsgstr = NULL;
	char *rfi_no_cpy = NULL;
		
	ITK_CALL ( TCTYPE_ask_object_type ( objTag, &objTypeTag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag, &type_name ) );

	printf ( "\nT5_RfiSorRevision_save_method_post type_name : [%s]", type_name ) ;
	TC_write_syslog ( "\nT5_RfiSorRevision_save_method_post type_name : [%s]", type_name ) ;
	if ( tc_strcmp ( type_name, "T5_RfiSorRevision" ) == 0 )
	{
		ITEM_ask_item_of_rev (objTag,&item);
		ITK_CALL ( AOM_ask_value_string ( item, "item_id", &rfi_item_id ) ) ;
		printf ( "\nrfi_item_id : [%s]", rfi_item_id ) ;
		TC_write_syslog ( "\nrfi_item_id : [%s]", rfi_item_id ) ;

		rfi_no_cpy = MEM_alloc(tc_strlen(rfi_item_id));
		tc_strcpy ( rfi_no_cpy, rfi_item_id );
		
		//RFI_CVBU_99_24_000001

		RFIstr = tc_strtok ( rfi_no_cpy, "_" ) ;
		BUstr = tc_strtok ( NULL, "_" ) ;
		Dsgstr = tc_strtok ( NULL, "_" ) ;

		printf ( "\nRFIstr : [%s]", RFIstr ) ;
		TC_write_syslog ( "\nRFIstr : [%s]", RFIstr ) ;

		printf ( "\nBUstr : [%s]", BUstr ) ;
		TC_write_syslog ( "\nBUstr : [%s]", BUstr ) ;

		printf ( "\nDsgstr : [%s]", Dsgstr ) ;
		TC_write_syslog ( "\nDsgstr : [%s]", Dsgstr ) ;

		
		ITK_CALL ( AOM_refresh ( objTag,true ) );
		ITK_CALL ( AOM_set_value_string ( objTag, "t5_RfiBusUnit", BUstr ) ) ;
		ITK_CALL ( AOM_set_value_string ( objTag, "t5_DesignGroup", Dsgstr ) ) ;
		ITK_CALL ( AOM_set_value_string ( objTag, "object_name", rfi_item_id ) ) ;
		ITK_CALL ( AOM_set_value_string ( objTag, "t5_RfiSORNum", rfi_item_id ) ) ;
		//ITK_CALL ( AOM_save ( objTag ) );
		ITK_CALL ( AOM_save_without_extensions ( objTag ) );//RS14.3
		ITK_CALL ( AOM_refresh ( objTag,false ) );
		
		ITK_CALL ( AOM_refresh ( item,true ) );
		ITK_CALL ( AOM_set_value_string ( item, "object_name", rfi_item_id ) ) ;//set on master also
		//ITK_CALL ( AOM_save ( item ) );
		ITK_CALL ( AOM_save_without_extensions ( item ) );//RS14.3
		ITK_CALL ( AOM_refresh ( item,false ) );
		printf("\nSaved rfi BU and Design Group");
		TC_write_syslog ( "\nSaved rfi BU and Design Group");
	}
	return ITK_ok;	
}
int check_if_dataset_exist( char *Dataset_ID , char *datasetType ) //"PDF"
{
	tag_t query = NULLTAG ;
	int n_found = 0 ;
	int n_entries = 2 ;
	char *qry_entries[2] = { "Name", "Dataset Type" } ;
	char *qry_values[2] =  { Dataset_ID, datasetType } ;
	tag_t *dataset_objects = NULL ;

	
	ITK_CALL ( QRY_find2 ( "Dataset...", &query ) ) ;
	ITK_CALL ( QRY_execute ( query, n_entries, qry_entries, qry_values, &n_found, &dataset_objects ) ) ;
	printf( "\nfound dataset [%s] of type [%s] n_found [%d]", Dataset_ID, datasetType, n_found ) ;
	TC_write_syslog ( "\nfound dataset [%s] of type [%s] n_found [%d]", Dataset_ID, datasetType, n_found ) ;
	if ( n_found > 0 )
	{
		return n_found;
	}
	return 0;
}
int create_dataset_with_rfisor_no ( tag_t tagItemRev, const char *item_id, const char *rev_id )
{
	tag_t datasettype = NULLTAG;
	int ref_count = 0;
	char **ref_list;
	tag_t tool = NULLTAG;
	char *DsetID = NULL;
	tag_t aNewDataset = NULLTAG;
	tag_t Relatn_type1;
	tag_t relation = NULLTAG;

	const char *reason = "" ;
	const char *change_id = "" ;
	const char *dir_name = "" ;

	int n_RFISOR_CR_DTSET = 0;
	int pdf_dataset_cr_flag = 0;

	n_RFISOR_CR_DTSET = tm_check_control_object ( "RFISOR_DATASET_CR", "TRUE" );
	if ( n_RFISOR_CR_DTSET > 0 )
	{

		//ITK_CALL ( AE_find_datasettype("PDF", &datasettype ) ) ;
		ITK_CALL ( AE_find_datasettype2("PDF", &datasettype ) ) ; //RS14.3
		ITK_CALL ( AE_ask_datasettype_refs(datasettype, &ref_count, &ref_list) ) ;
		printf("\n1ref_list[0] : %s",ref_list[0]);
		TC_write_syslog("\n1ref_list[0] : %s",ref_list[0]);
		
		DsetID = NULL;
		DsetID=(char *) MEM_alloc(32);
		tc_strcpy(DsetID,item_id);
		tc_strcat(DsetID,"_");
		tc_strcat(DsetID,rev_id);
		TC_write_syslog("\nDsetID : [%s]",DsetID);
		
		pdf_dataset_cr_flag = check_if_dataset_exist( DsetID , "PDF" );
		
		if ( pdf_dataset_cr_flag > 0 )
		{
			printf("\nDataset already exist hence skipping creation");
			TC_write_syslog("\nDataset already exist hence skipping creation");
			return ITK_ok;
		}


		ITK_CALL(AE_create_dataset_with_id(datasettype,DsetID,"PDF Dataset",DsetID,"",&aNewDataset));
		ITK_CALL(AOM_lock(aNewDataset));
		ITK_CALL(AE_set_dataset_tool( aNewDataset, tool));
		//ITK_CALL(AE_set_dataset_format(aNewDataset, "BINARY_REF"));
		ITK_CALL(AE_set_dataset_format2(aNewDataset, "BINARY_REF")); //RS14.3
		ITK_CALL(AOM_save_without_extensions(aNewDataset));
		ITK_CALL(AOM_unlock(aNewDataset));

		TC_write_syslog("\nfind IMAN_specification");

		ITK_CALL(GRM_find_relation_type("IMAN_specification",&Relatn_type1));
		ITK_CALL(AOM_refresh(tagItemRev,true));
		TC_write_syslog("\ncreate_dataset_with_rfisor_no : GRM_create_relation create");
		ITK_CALL(GRM_create_relation(tagItemRev,aNewDataset,Relatn_type1,NULLTAG,&relation));
		printf("\ncreate_dataset_with_rfisor_no : after creating relation between dataset"); fflush(stdout);
		TC_write_syslog("\ncreate_dataset_with_rfisor_no : after creating relation between dataset"); fflush(stdout);
		ITK_CALL(GRM_save_relation(relation));
		printf("\ncreate_dataset_with_rfisor_no : GRM_save_relation"); fflush(stdout);
		TC_write_syslog("\ncreate_dataset_with_rfisor_no : GRM_save_relation"); fflush(stdout);
		
		ITK_CALL(AOM_save_without_extensions(tagItemRev));
		ITK_CALL(AOM_refresh(tagItemRev,false));

		printf("\ncreate_dataset_with_rfisor_no : AOM_save for RFISOR tagItemRev"); fflush(stdout);
		TC_write_syslog("\ncreate_dataset_with_rfisor_no : AOM_save for RFISOR tagItemRev"); fflush(stdout);

		//ITK_CALL ( RES_checkout ( aNewDataset, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;//this code is added to check if object remains checkedout after create
		ITK_CALL ( RES_checkout2 ( aNewDataset, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;//this code is added to check if object remains checkedout after create //RS14.3

	}
	return ITK_ok;
}

//Shubham Added Zip file logic on 07_July_2025
int create_Zipdataset_with_rfisor_no ( tag_t tagItemRev, const char *item_id, const char *rev_id )
{
	//tag_t datasettype = NULLTAG;
	tag_t Zipdatasettype = NULLTAG;
	//int ref_count = 0;
	int Zipref_count = 0;
	//char **ref_list;
	char **Zipref_list;
	//tag_t tool = NULLTAG;
	tag_t Ziptool = NULLTAG;
	//char *DsetID = NULL;
	char *ZipDsetID = NULL;
	//tag_t aNewDataset = NULLTAG;
	tag_t ZipaNewDataset = NULLTAG;
	//tag_t Relatn_type1;
	tag_t ZipRelatn_type1;
	//tag_t relation = NULLTAG;
	tag_t Ziprelation = NULLTAG;

	const char *reason = "" ;
	const char *change_id = "" ;
	const char *dir_name = "" ;

	int n_RFISOR_CR_DTSET = 0;
	int zip_dataset_cr_flag = 0;

	n_RFISOR_CR_DTSET = tm_check_control_object ( "RFISOR_ZIPDATASET_CR", "TRUE" );
	if ( n_RFISOR_CR_DTSET > 0 )
	{

		//ITK_CALL ( AE_find_datasettype("PDF", &datasettype ) ) ;
		ITK_CALL ( AE_find_datasettype2("ZIP", &Zipdatasettype ) ) ; //RS14.3
		ITK_CALL ( AE_ask_datasettype_refs(Zipdatasettype, &Zipref_count, &Zipref_list) ) ;
		printf("\n2ref_list[0] : %s",Zipref_list[0]);
		TC_write_syslog("\n2ref_list[0] : %s",Zipref_list[0]);
		
		ZipDsetID = NULL;
		ZipDsetID=(char *) MEM_alloc(32);
		tc_strcpy(ZipDsetID,item_id);
		tc_strcat(ZipDsetID,"_");
		tc_strcat(ZipDsetID,rev_id);
		TC_write_syslog("\nDsetID : [%s]",ZipDsetID);

		zip_dataset_cr_flag = check_if_dataset_exist( ZipDsetID , "ZIP" );
		
		if ( zip_dataset_cr_flag > 0 )
		{
			printf("\nzipDataset already exist hence skipping creation");
			TC_write_syslog("\nzipDataset already exist hence skipping creation");
			return ITK_ok;
		}

		ITK_CALL(AE_create_dataset_with_id(Zipdatasettype,ZipDsetID,"RFI SOR ZIP",ZipDsetID,"",&ZipaNewDataset));
		ITK_CALL(AE_save_myself(ZipaNewDataset));
		ITK_CALL(AOM_lock(ZipaNewDataset));
		ITK_CALL(AE_set_dataset_tool( ZipaNewDataset, Ziptool));
		//ITK_CALL(AE_set_dataset_format(ZipaNewDataset, "BINARY_REF"));
		ITK_CALL(AE_set_dataset_format2(ZipaNewDataset, "BINARY_REF")); //RS14.3
		ITK_CALL(AOM_save_without_extensions(ZipaNewDataset));
		ITK_CALL(AOM_unlock(ZipaNewDataset));

		TC_write_syslog("\nfind RFI SOR HAS DOC");

		ITK_CALL(GRM_find_relation_type("T5_Rfi_sor_has_doc",&ZipRelatn_type1));
		ITK_CALL(AOM_refresh(tagItemRev,true));
		TC_write_syslog("\ncreate_Zipdataset_with_rfisor_no : GRM_create_relation create");
		ITK_CALL(GRM_create_relation(tagItemRev,ZipaNewDataset,ZipRelatn_type1,NULLTAG,&Ziprelation));
		printf("\ncreate_Zipdataset_with_rfisor_no : after creating Ziprelation between dataset"); fflush(stdout);
		TC_write_syslog("\ncreate_Zipdataset_with_rfisor_no : after creating Ziprelation between dataset"); fflush(stdout);
		ITK_CALL(AOM_load(Ziprelation));
		ITK_CALL(GRM_save_relation(Ziprelation));
		printf("\ncreate_Zipdataset_with_rfisor_no : GRM_save_relation"); fflush(stdout);
		TC_write_syslog("\ncreate_Zipdataset_with_rfisor_no : GRM_save_relation"); fflush(stdout);
		
		ITK_CALL(AOM_save_without_extensions(tagItemRev));
		ITK_CALL(AOM_refresh(tagItemRev,false));

		printf("\ncreate_Zipdataset_with_rfisor_no : AOM_save for RFISOR tagItemRev"); fflush(stdout);
		TC_write_syslog("\ncreate_Zipdataset_with_rfisor_no : AOM_save for RFISOR tagItemRev"); fflush(stdout);

		//ITK_CALL ( RES_checkout ( ZipaNewDataset, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;//this code is added to check if object remains checkedout after create
		ITK_CALL ( RES_checkout2 ( ZipaNewDataset, reason, change_id, dir_name, RES_EXCLUSIVE_RESERVE ) ) ;//this code is added to check if object remains checkedout after create //RS14.3

	}
	return ITK_ok;
}
//Ended

int Submit_rfisor_to_workflow ( tag_t rfi_sor_rev_tag )
{
	tag_t template_tag      = NULLTAG;
	tag_t test_job_a        = NULLTAG;
	int attachment_types    = 1;
	int n_RFISOR_wFLOW = 0;

	n_RFISOR_wFLOW = tm_check_control_object ( "RFISOR_WFL", "TRUE" );
	if ( n_RFISOR_wFLOW > 0 )
	{
		ITK_CALL ( EPM_find_template2("RFI_SOR_Workflow",0,&template_tag ) ) ;
		ITK_CALL ( EPM_create_process("RFI_SOR_Workflow","Submit RFI SOR",template_tag,1, &rfi_sor_rev_tag,&attachment_types,&test_job_a ) );
		printf("\nObject Submitted into workflow");
		TC_write_syslog ( "\nObject Submitted into workflow");
	}
	return ITK_ok;
}
extern DLLAPI int RFISOR_create_method ( METHOD_message_t *m, va_list args )
{

	const char* item_id;
	const char* item_name;
	const char* type_name;
	const char* rev_id;
	tag_t* new_item_tag;
	tag_t* new_rev_tag;
	tag_t item_master_form_tag;
	tag_t item_rev_master_form_tag;
	tag_t tagItem =NULLTAG;
	tag_t tagItemRev =NULLTAG;
	
	tag_t objTypeTag = NULLTAG;
	char *type_name2 = NULL;

	item_id = va_arg(args, const char*);
	item_name = va_arg(args, const char*);
	type_name = va_arg(args, const char*);
	rev_id = va_arg(args, const char*);

	new_item_tag = va_arg(args, tag_t*);
	new_rev_tag = va_arg(args, tag_t*);
	item_master_form_tag = va_arg(args, tag_t);
	item_rev_master_form_tag = va_arg(args, tag_t);

	tagItem = *new_item_tag;
	tagItemRev = *new_rev_tag;
	ITK_CALL ( TCTYPE_ask_object_type ( tagItemRev, &objTypeTag ) ) ;
	ITK_CALL ( TCTYPE_ask_name2 ( objTypeTag, &type_name2 ) );

	printf ( "\nT5_RfiSor_create_method_post item_id : [%s]", item_id ) ;
	TC_write_syslog ( "\nT5_RfiSor_create_method_post item_id : [%s]", item_id ) ;
	

	printf ( "\nT5_RfiSor_create_method_post type_name : [%s]", type_name2 ) ;
	TC_write_syslog ( "\nT5_RfiSor_create_method_post type_name : [%s]", type_name2 ) ;

	if (tc_strcmp (type_name2 , "T5_RfiSorRevision" ) == 0 )
	{
		printf ( "\nSubmitting [%s] in workflow", item_id ) ;
		TC_write_syslog ( "\nSubmitting [%s] in workflow", item_id );
	
		Submit_rfisor_to_workflow(tagItemRev);
		
		printf ( "\nCreating dataset : [%s]", item_id ) ;
		TC_write_syslog ( "\nCreating dataset : [%s]", item_id );
	
		create_dataset_with_rfisor_no (tagItemRev,item_id,rev_id) ;
		create_Zipdataset_with_rfisor_no (tagItemRev,item_id,rev_id) ;
		
	}

	return ITK_ok;	
}
int tm_rfi_sor_dataset_import( METHOD_message_t *msg, va_list args )
{
	int ifail = ITK_ok;
	/**
	    @param tag_t               datasetTag     (I)
	    @param char*               referenceName  (I)
	    @param AE_reference_type_t referenceType  (I)
	    @param char*               osFullPathName (I)
	    @param char*               fileName       (I)
	    @param int                 fileTypeFlag   (I)
	*/
	tag_t  datasetTag = va_arg(args, tag_t);
	char*  referenceName = va_arg(args, char*);
	AE_reference_type_t  referenceType = va_arg(args, AE_reference_type_t);
	char*  osFullPathName = va_arg(args, char*);
	char*  fileName = va_arg(args, char*);
	char *dataset_obj_name = NULL;
	char* type = NULL;
	int priObjCount = 0;
	tag_t* priObj;
	int count = 0;
	char* priObjtype = NULL;
	int namedRefCount = 0;
	tag_t* namedReference;
	char* pdfname = NULL;
	char *pdf_no_ext = NULL;
	tag_t rfi_item_tag = NULLTAG;
	char *rfi_item_id = NULL;
	int n_RFISOR_IMP_PDF = 0;

	TC_write_syslog("\n*******************welcome rfiSOR dataset import**********************");

	n_RFISOR_IMP_PDF = tm_check_control_object ( "RFISOR_PDF_NAME_VLDTN", "TRUE" );
	if ( n_RFISOR_IMP_PDF > 0 )
	{
		if(datasetTag != NULLTAG)
		{
			ITK_CALL ( AOM_ask_value_string ( datasetTag, "object_name", &dataset_obj_name ) ) ;
			TC_write_syslog("\ninside tm_rfi_sor_dataset_import : [%s]", dataset_obj_name);fflush(stdout);
			ITK_CALL ( WSOM_ask_object_type2(datasetTag,&type) );
			TC_write_syslog("\ntm_rfi_sor_dataset_import : DatasetType : [%s]",type);fflush(stdout);
			TC_write_syslog("\ntm_rfi_sor_dataset_import : referenceName : [%s]",referenceName);fflush(stdout);
			if(tc_strcmp(type,"PDF")==0)
			{
				ITK_CALL ( GRM_list_primary_objects_only(datasetTag,NULLTAG,&priObjCount,&priObj) );
				TC_write_syslog("\ntm_rfi_sor_dataset_import : Primary object count : [%d]", priObjCount);fflush(stdout);
				if(priObjCount>0)
				{
					for ( count = 0 ; count < priObjCount; count++ )
					{
						ITK_CALL ( WSOM_ask_object_type2(priObj[count],&priObjtype ) ) ;
						TC_write_syslog("\ntm_rfi_sor_dataset_import : Primary object type : [%s]", priObjtype);fflush(stdout);

						if(tc_strcmp(priObjtype,"T5_RfiSorRevision")==0)//RFI SOR revision
						{
							ITK_CALL ( ITEM_ask_item_of_rev ( priObj[count], &rfi_item_tag) );
							ITK_CALL ( AOM_ask_value_string ( rfi_item_tag, "item_id", &rfi_item_id ) ) ;
					
							ITK_CALL ( AE_ask_dataset_named_refs(datasetTag,&namedRefCount,&namedReference) );
							TC_write_syslog("\ntm_rfi_sor_dataset_import : inside if of tm_rfi_sor_dataset_import");fflush(stdout);
							TC_write_syslog("\ntm_rfi_sor_dataset_import : AE_ask_dataset_named_refs count : [%d]",namedRefCount);fflush(stdout);
							if ( namedRefCount > 0 )
							{
								if ( tc_strstr ( dataset_obj_name, rfi_item_id ) != NULL ) // check if item id and dataset name matching
								{
									ITK_CALL ( IMF_ask_original_file_name2 ( namedReference[0], &pdfname) );
									TC_write_syslog("\ntm_rfi_sor_dataset_import : pdfname : [%s]",pdfname);fflush(stdout);
									TC_write_syslog("\ntm_rfi_sor_dataset_import : dataset_obj_name : [%s]",dataset_obj_name);fflush(stdout);
									pdf_no_ext = tc_strtok ( pdfname, "." ) ;
									if ( tc_strcmp ( dataset_obj_name,pdf_no_ext ) != 0 )//Is dataset name and pdf name matching check
									{
										char *PDFNameErr = NULL;
										PDFNameErr = MEM_alloc ( 200 ) ;
										sprintf ( PDFNameErr, "PDF filename : [%s] not matching with Dataset name : [%s] ", pdf_no_ext, dataset_obj_name ) ;
										EMH_store_error_s1 ( EMH_severity_error, PLM_error,PDFNameErr ) ;
										TC_write_syslog ( "\ntm_rfi_sor_dataset_import : Error Msg : [%s]",PDFNameErr ) ;
										return PLM_error;
									}
								}
								else
								{
									TC_write_syslog ( "\ntm_rfi_sor_dataset_import : RFI item_no and dataset name not maching allowing to import other pdf" ) ;
								}
							}
						}
					}
				}
			}
		}
	}
	return 0;
}
int Assign_RFISOR_Review_Func(EPM_action_message_t msg)
{
	char *s_DesignGrp = NULL;
	char* CurrentTask = NULL;
	char* ObjTyp = NULL;
	char* current_release_level = NULL;
	char* parent_name = NULL;
	char* task_result = NULL;
	char* rfi_COC_Hd_roles = NULL ;
	char* rfi_ce_review_roles = NULL ;
	char* rfi_sor_no = NULL;
	char* username = NULL;
	
	int atch = 0 ;
	int no_attach = 0 ;
	tag_t *attachment = NULLTAG;

	tag_t job = NULLTAG;
	tag_t objTag = NULLTAG;
	tag_t root_task = NULLTAG;
	tag_t user_tag = NULLTAG;
	//tag_t objMasterTag = NULLTAG;
	char *sor_releasestatus = NULL;
	char* command = NULL;
	command = (char*)MEM_alloc(1000 * sizeof(char));

	ITK_CALL ( POM_get_user(&username,&user_tag) ) ;
	TC_write_syslog("\nStarting for username:[%s]",username);fflush(stdout);
	printf("\nStarting for username:[%s]",username);fflush(stdout);

	ITK_CALL ( EPM_ask_root_task(msg.task,&root_task ) ) ;
	TC_write_syslog("\nRoot task found");fflush(stdout);
	printf("\nRoot task found");fflush(stdout);

	ITK_CALL ( AOM_ask_value_string(msg.task,"object_name",&CurrentTask) ) ;
	TC_write_syslog("\nCurrentTask:%s.",CurrentTask);fflush(stdout);//RFI_SOR_Workflow
	printf("\nCurrentTask:%s.",CurrentTask);fflush(stdout);//RFI_SOR_Workflow

	ITK_CALL ( AOM_ask_value_string(msg.task,"task_result",&task_result) ) ;
	TC_write_syslog("\ntask_result:%s.",task_result);fflush(stdout);
	printf("\ntask_result:%s.",task_result);fflush(stdout);

	ITK_CALL ( AOM_ask_value_string(root_task,"object_name",&parent_name ) ) ;
	TC_write_syslog("\nParent Name:%s.",parent_name);fflush(stdout);//RFI_SOR_Workflow
	printf("\nParent Name:%s.",parent_name);fflush(stdout);//RFI_SOR_Workflow
	
	if (tc_strcmp (parent_name, "RFI_SOR_Workflow" ) == 0 )
	{
		if (tc_strcmp (CurrentTask, "RFI_Add_Release_Status" ) == 0 )
		{
			ITK_CALL ( EPM_ask_attachments(root_task, EPM_target_attachment,&no_attach, &attachment) ) ;
			TC_write_syslog("\nNo of Attachements: [%d]", no_attach);fflush(stdout);
			if( no_attach > 0 )
			{
				for(atch=0;atch<no_attach;atch++)
				{
					objTag = attachment[atch];
					ITK_CALL ( AOM_ask_value_string(objTag,"object_type",&ObjTyp) ) ;
					printf("\nObjTyp is :%s\n",ObjTyp);fflush(stdout);//T5_RfiSorRevision
					TC_write_syslog("\nObjTyp is :%s\n",ObjTyp);fflush(stdout);//T5_RfiSorRevision

					if( tc_strcmp ( ObjTyp, "T5_RfiSorRevision" ) == 0 )
					{
						ITK_CALL ( AOM_ask_value_string(objTag,"item_id",&rfi_sor_no) ) ;
						TC_write_syslog("\nTRFISOR item_id :%s\n",rfi_sor_no);fflush(stdout);

						ITK_CALL(AOM_UIF_ask_value(objTag, "release_status_list", &sor_releasestatus));
						printf("\nRFI_action_handler sor_releasestatus : [%s]", sor_releasestatus);
						TC_write_syslog("\nRFI_action_handler sor_releasestatus : [%s]", sor_releasestatus);

						if (tc_strstr(sor_releasestatus, "ERC Released") != NULL || tc_strstr(sor_releasestatus, "T5_LcsErcRlzd") != NULL)
						{
							int n_found_SOR_ProNext_info1 = 0;
							int n_found_SOR_PF_info = 0;
							char* shell_path = NULL;
							char* info2 = NULL;
							char* tcua_uname = NULL;
							char* tcua_pf_file = NULL;

							shell_path = (char*)MEM_alloc(200 * sizeof(char));
							info2 = (char*)MEM_alloc(200 * sizeof(char));
							tcua_uname = (char*)MEM_alloc(50 * sizeof(char));
							tcua_pf_file = (char*)MEM_alloc(200 * sizeof(char));

							n_found_SOR_PF_info = tm_check_info_control_object("AUTOSOR_PWFILE", "PATH", tcua_uname, tcua_pf_file);
							if (n_found_SOR_PF_info < 0)
							{
								printf ( "\nCreate control object for username password file" ) ;
								TC_write_syslog ( "\nCreate control object for username password file" ) ;
								return 0;
							}

							n_found_SOR_ProNext_info1 = tm_check_info_control_object("RFISOR_PNXT_SHELL", "PRONEXT_TRNS", shell_path, info2);

							if (n_found_SOR_ProNext_info1 < 0)
							{
								printf("\nexecuting shell for PRONEXT_TRNS");
								TC_write_syslog("\nexecuting shell for PRONEXT_TRNS");
								return 0;
							}



							if (access(shell_path, F_OK) == 0)
							{
								// file exists
								printf("\nshell_path : [%s]", shell_path);
								TC_write_syslog("\nshell_path : [%s]", shell_path);
								sprintf(command, "%s/CCPLMToProNext_RFI_TRANS.sh -u=%s -pf=\"%s\" -i=%s", shell_path, tcua_uname, tcua_pf_file, rfi_sor_no);
								system(command);
								printf("\ncommand1 : [%s]", command);
								TC_write_syslog("\ncommand1 : [%s]", command);
							}
							else
							{
								// file doesn't exist

								int tmp_n_found_SOR_PF_info1 = 0;
								char* shell_path_TMP_PATH = NULL;
								char* info2_TMP_PATH = NULL;

								shell_path_TMP_PATH = (char*)MEM_alloc(200 * sizeof(char));
								info2_TMP_PATH = (char*)MEM_alloc(200 * sizeof(char));

								tmp_n_found_SOR_PF_info1 = tm_check_info_control_object("RFISOR_SHELL_TMP_PATH", "PRONEXT_TRNS_TMP_PATH", shell_path_TMP_PATH, info2_TMP_PATH);

								if (tmp_n_found_SOR_PF_info1 < 0)
								{
									printf("\nexecuting shell for PRONEXT_TRNS");
									TC_write_syslog("\nexecuting shell for PRONEXT_TRNS");
									return 0;
								}

								printf("\nshell_path_TMP_PATH : [%s]", shell_path_TMP_PATH);
								TC_write_syslog("\nshell_path_TMP_PATH : [%s]", shell_path_TMP_PATH);
								sprintf(command, "%s/CCPLMToProNext_RFI_TRANS.sh -u=%s -pf=\"%s\" -i=%s -r=%s -s=%s", shell_path_TMP_PATH, tcua_uname, tcua_pf_file, rfi_sor_no);
								system(command);
								printf("\ncommand2 : [%s]", command);
								TC_write_syslog("\ncommand2 : [%s]", command);
							}
						}
					}
				}
			}
		}
	}
	return ITK_ok;
}

extern  DLLAPI int Revise_rfi_sor_postAct(METHOD_message_t *m, va_list args)
{
	tag_t objTypeTag = NULLTAG;
	char *type_name = NULL;
	tag_t master = NULLTAG;
	tag_t source_rev =va_arg (args, tag_t);
	char* new_rev_id = va_arg(args, char*);
	tag_t* new_rev = va_arg(args, tag_t*);
	tag_t item_rev_master_form = va_arg(args, tag_t);
	tag_t dataset_relation_type = NULLTAG;
	tag_t* DatasetList = NULLTAG;
	int dataset_cnt = 0 ;
	int iRelCntr = 0;
	int n_rfisor_pdf_rel_del = 0;
	tag_t relation_tag = NULLTAG;
	char *old_rev_id = NULL;
	char *rfi_item_id = NULL;
	char *old_data_set_name = NULL;
	char *New_rev_data_set_name = NULL;

	tag_t dataset_objTypeTag = NULLTAG;
	char *dataset_typename = NULL;
	char *info1 = NULL;
	char *info2 = NULL;

	info1 = ( char * ) MEM_alloc ( 100 * sizeof ( char ) ) ;
	info2 = ( char * ) MEM_alloc ( 100 * sizeof ( char ) ) ;
	

	ITK_CALL ( TCTYPE_ask_object_type ( *new_rev,&objTypeTag ) );
	ITK_CALL ( TCTYPE_ask_name2( objTypeTag, &type_name ) );
	ITK_CALL ( ITEM_ask_item_of_rev  ( *new_rev, &master ) );

	printf("\nRevise_rfi_sor_postAct : type_name : [%s]",type_name); fflush(stdout);
	TC_write_syslog("\nRevise_rfi_sor_postAct : type_name : [%s]",type_name);
	
	printf("\nRevise_rfi_sor_postAct : new_rev_id : [%s]",new_rev_id); fflush(stdout);
	TC_write_syslog("\nRevise_rfi_sor_postAct : new_rev_id : [%s]",new_rev_id);

	if (tc_strcmp(type_name,"T5_RfiSorRevision") == 0)
	{
		n_rfisor_pdf_rel_del = tm_check_info_control_object("RFI_PDF_REL", "TRUE", info1, info2);
		printf ( "\nn_rfisor_pdf_rel_del : [%d]", n_rfisor_pdf_rel_del ) ;
		TC_write_syslog ( "\nn_rfisor_pdf_rel_del : [%d]", n_rfisor_pdf_rel_del ) ;
			
		if (n_rfisor_pdf_rel_del > 0)
		{
			ITK_CALL ( AOM_ask_value_string ( source_rev,"item_revision_id", &old_rev_id ) ) ;
			ITK_CALL ( AOM_ask_value_string ( source_rev, "item_id", &rfi_item_id ) ) ;

			printf ( "\nrfi_item_id : [%s]", rfi_item_id ) ;
			TC_write_syslog ( "\nrfi_item_id : [%s]", rfi_item_id ) ;

			printf ( "\nold_rev_id : [%s]", old_rev_id ) ;
			TC_write_syslog ( "\nold_rev_id : [%s]", old_rev_id ) ;
			
			old_data_set_name =  ( char * ) MEM_alloc ( 200 * sizeof ( char )  ) ;
			sprintf ( old_data_set_name, "%s_%s",  rfi_item_id, old_rev_id ) ;

			printf ( "\nold_data_set_name : [%s]", old_data_set_name ) ;
			TC_write_syslog ( "\nold_data_set_name : [%s]", old_data_set_name ) ;
		
			ITK_CALL ( GRM_find_relation_type ( "IMAN_specification", &dataset_relation_type ) );

			ITK_CALL ( GRM_list_secondary_objects_only ( *new_rev, dataset_relation_type, &dataset_cnt, &DatasetList ) ) ;
			printf("\nRevise_rfi_sor_postAct : dataset_cnt : [%d]", dataset_cnt); fflush(stdout);
			TC_write_syslog("\nRevise_rfi_sor_postAct : dataset_cnt : [%d]", dataset_cnt);

			for ( iRelCntr = 0 ; iRelCntr < dataset_cnt; iRelCntr++ )
			{
				printf("\nRevise_rfi_sor_postAct : RelCounter : [%d]", iRelCntr); fflush(stdout);
				TC_write_syslog("\nRevise_rfi_sor_postAct : RelCounter : [%d]", iRelCntr);

				ITK_CALL ( GRM_find_relation ( *new_rev, DatasetList[iRelCntr], dataset_relation_type, &relation_tag ) );

				ITK_CALL ( TCTYPE_ask_object_type ( DatasetList[iRelCntr],&dataset_objTypeTag ) );
				ITK_CALL ( TCTYPE_ask_name2( dataset_objTypeTag, &dataset_typename ) );

				printf("\nRevise_rfi_sor_postAct : dataset_typename : [%s]", dataset_typename); fflush(stdout);
				TC_write_syslog("\nRevise_rfi_sor_postAct : dataset_typename : [%s]", dataset_typename);

				if ( tc_strcmp ( dataset_typename, "PDF" ) == 0 )//delete only PDF dataset type
				{
					if ( relation_tag )//	Breaking relation between RFI SOR and New revision
					{
						ITK_CALL ( AOM_ask_value_string ( DatasetList[iRelCntr], "object_name", &New_rev_data_set_name ) ) ;
						printf ( "\nNew_rev_data_set_name : [%s]", New_rev_data_set_name ) ;
						TC_write_syslog ( "\nNew_rev_data_set_name : [%s]", New_rev_data_set_name ) ;
		
						if ( tc_strcmp ( New_rev_data_set_name, old_data_set_name ) == 0 )
						{
							ITK_CALL ( GRM_delete_relation ( relation_tag ) ) ;
							printf("\nRevise_rfi_sor_postAct : after delete RFI document relation delete" ) ; fflush(stdout);
							TC_write_syslog("\nRevise_rfi_sor_postAct : after delete RFI document relation delete" ) ;
						}
					}
				}
			}
		}
	}
	
	return ITK_ok;
}
//RFISORCoCHeadReview	$obj.t5RfiCoCHod	TCE
//RFISOR_CE_Review	$obj.t5RfiCERevr	TCE
int check_participant_count ( tag_t objTag) 
{
	tag_t has_participant_type = NULLTAG ;
	int nScndry_Obj_Prticipnt_cnt = 0 ;
	tag_t *existing_Prticipnts = NULLTAG ;
	tag_t exst_prtcpnt_Tag = NULLTAG ;
	int index_Prticipnt_remove = 0 ;
	tag_t ObjTypPrtcpant = NULLTAG ;
	char *PrtcpantTypeName;
	char *AssignedUsr_1 = NULL ;
	char *AssignedUsr_2 = NULL ;
	char *ParticiapntObjType = NULL;
	ITK_CALL(GRM_find_relation_type("HasParticipant", &has_participant_type));
	if ( has_participant_type != NULLTAG )
	{
		TC_write_syslog("\nHasParticipant START........."); fflush(stdout);
		printf("\nHasParticipant START........."); fflush(stdout);
		ITK_CALL(GRM_list_secondary_objects_only(objTag,has_participant_type,&nScndry_Obj_Prticipnt_cnt,&existing_Prticipnts));
		TC_write_syslog("\nexisting_Prticipnts count 1 : %d",nScndry_Obj_Prticipnt_cnt);fflush(stdout);	
		printf("\nexisting_Prticipnts count 1 : %d",nScndry_Obj_Prticipnt_cnt);fflush(stdout);	
		for ( index_Prticipnt_remove = 0; index_Prticipnt_remove < nScndry_Obj_Prticipnt_cnt ; index_Prticipnt_remove++ )
		{	
			exst_prtcpnt_Tag = existing_Prticipnts[index_Prticipnt_remove];
			ITK_CALL(TCTYPE_ask_object_type(exst_prtcpnt_Tag,&ObjTypPrtcpant));
			ITK_CALL(TCTYPE_ask_name2(ObjTypPrtcpant,&PrtcpantTypeName));
			TC_write_syslog("\nPrtcpantTypeName 1 : %s", PrtcpantTypeName);fflush(stdout);
			printf("\nPrtcpantTypeName 1 : %s", PrtcpantTypeName);fflush(stdout);
			if (tc_strcmp(PrtcpantTypeName,"T5_RFICoCHOD")==0)//Partipant type
			{
				ITK_CALL(AOM_UIF_ask_value(exst_prtcpnt_Tag,"fnd0AssigneeUser",&AssignedUsr_1));
				TC_write_syslog("\nreviewer 1 : [%s] ",AssignedUsr_1);fflush(stdout);
				printf("\nreviewer 1 : [%s] ",AssignedUsr_1);fflush(stdout);
			}
			if (tc_strcmp(PrtcpantTypeName,"T5_RFICEReviewer")==0)//Partipant type
			{
				ITK_CALL(AOM_UIF_ask_value(exst_prtcpnt_Tag,"fnd0AssigneeUser",&AssignedUsr_2));
				TC_write_syslog("\nreviewer 2 : [%s] ",AssignedUsr_2);fflush(stdout);
				printf("\nreviewer 2 : [%s] ",AssignedUsr_2);fflush(stdout);
			}
		}
		if ( (AssignedUsr_1 != NULL) && (AssignedUsr_2 != NULL) )
		{
			TC_write_syslog("\nBoth Reviewer assigned hence proceed");
			printf("\nBoth Reviewer assigned hence proceed");
			return 2;//Both Available
		}
		else if ( (AssignedUsr_1 == NULL) && (AssignedUsr_2 == NULL) )
		{
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Assign 'RFI CoC HOD' and 'RFI CE Reviewer' to RFI SOR");
			
			TC_write_syslog("\nAssign 'RFI CoC HOD' and 'RFI CE Reviewer' to RFI SOR");
			printf("\nAssign 'RFI CoC HOD' and 'RFI CE Reviewer' to RFI SOR");
			return -2;//both are not available
		}
		else if (AssignedUsr_1 == NULL)
		{
			//T5_RFICoCHOD
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Assign 'RFI CoC HOD' to RFI SOR");
			TC_write_syslog("\nAssign 'RFI CoC HOD' to RFI SOR");
			printf("\nAssign 'RFI CoC HOD' to RFI SOR");
			return -1;//CoC HOD not available
		}
		else if (AssignedUsr_2 == NULL)
		{
			//T5_RFICEReviewer
			EMH_store_error_s1(EMH_severity_error,PLM_error,"Assign 'RFI CE Reviewer' to RFI SOR");
			TC_write_syslog("\nAssign 'RFI CE Reviewer' to RFI SOR");
			printf("\nAssign 'RFI CE Reviewer' to RFI SOR");
			return -1;//CE Reviewer not available
		}
	}
	return 0;
}

EPM_decision_t Check_RFISOR_Review_Count_Func(EPM_rule_message_t msg)
{
	char *s_DesignGrp = NULL;
	char* CurrentTask = NULL;
	char* ObjTyp = NULL;
	char* current_release_level = NULL;
	char* parent_name = NULL;
	char* task_result = NULL;
	char* rfi_COC_Hd_roles = NULL ;
	char* rfi_ce_review_roles = NULL ;
	char* tct_item_id = NULL;
	char* username = NULL;
	
	int atch = 0 ;
	int no_attach = 0 ;
	tag_t *attachment = NULLTAG;

	tag_t job = NULLTAG;
	tag_t objTag = NULLTAG;
	tag_t root_task = NULLTAG;
	tag_t user_tag = NULLTAG;
	//tag_t objMasterTag = NULLTAG;
	EPM_decision_t decision = EPM_go;


	ITK_CALL ( POM_get_user(&username,&user_tag) ) ;
	TC_write_syslog("\nStarting for username:[%s]",username);fflush(stdout);
	printf("\nStarting for username:[%s]",username);fflush(stdout);

	ITK_CALL ( EPM_ask_root_task(msg.task,&root_task ) ) ;
	TC_write_syslog("\nRoot task found");fflush(stdout);
	printf("\nRoot task found");fflush(stdout);

	ITK_CALL ( AOM_ask_value_string(msg.task,"object_name",&CurrentTask) ) ;
	TC_write_syslog("\nCurrentTask:%s.",CurrentTask);fflush(stdout);//RFI_SOR_Workflow
	printf("\nCurrentTask:%s.",CurrentTask);fflush(stdout);//RFI_SOR_Workflow

	ITK_CALL ( AOM_ask_value_string(msg.task,"task_result",&task_result) ) ;
	TC_write_syslog("\ntask_result:%s.",task_result);fflush(stdout);
	printf("\ntask_result:%s.",task_result);fflush(stdout);

	ITK_CALL ( AOM_ask_value_string(root_task,"object_name",&parent_name ) ) ;
	TC_write_syslog("\nParent Name:%s.",parent_name);fflush(stdout);//RFI_SOR_Workflow
	printf("\nParent Name:%s.",parent_name);fflush(stdout);//RFI_SOR_Workflow
	
	
	ITK_CALL ( EPM_ask_attachments(root_task, EPM_target_attachment,&no_attach, &attachment) ) ;
	TC_write_syslog("\nNo of Attachements: [%d]", no_attach);fflush(stdout);
	printf("\nNo of Attachements: [%d]", no_attach);fflush(stdout);

	//CurrentTask:Assign CoC_CE reviewer and attach document
	//Parent Name:RFI_SOR_Workflow
	if( no_attach > 0 )
	{
		if ( tc_strcmp ( parent_name, "RFI_SOR_Workflow" ) == 0 )
		{
			if ( tc_strcmp ( CurrentTask, "Assign CoC_CE reviewer and attach document" ) == 0 )
			{
				
				for(atch=0;atch<no_attach;atch++)
				{
					objTag = attachment[atch];
					ITK_CALL ( AOM_ask_value_string(objTag,"object_type",&ObjTyp) ) ;
					TC_write_syslog("\nObjTyp is :%s\n",ObjTyp);fflush(stdout);//T5_RfiSorRevision
					printf("\nObjTyp is :%s\n",ObjTyp);fflush(stdout);//T5_RfiSorRevision

					
					if( tc_strcmp ( ObjTyp, "T5_RfiSorRevision" ) == 0 )
					{
						int Participant_Count = check_participant_count( objTag);
						TC_write_syslog("\nParticipant_Count : [%d]",Participant_Count);fflush(stdout);
						printf("\nParticipant_Count : [%d]",Participant_Count);fflush(stdout);

						if ( Participant_Count < 2)
						{
							decision = EPM_nogo;
							return decision;
						}
						else//total more than 2 partipant of both type
						{
							decision = EPM_go;
							return decision;
						}

					}
				}
			}
		}
	}
	return decision;
}
extern int tm_AutoSOR_CUST_register_method(int *decision, va_list args)
{

	METHOD_id_t  method;
	METHOD_id_t  method_sor_checkin;
	//METHOD_id_t  method_save_post_act;
	METHOD_id_t  method_save_post_act_sor;
	METHOD_id_t  method_save_pre_act_sor;
	METHOD_id_t  method_save_pre_cond_sor;
	METHOD_id_t  methodPPPProjValueChange;
	METHOD_id_t  method_rfi_PPPProjValChange;
	METHOD_id_t  method_grm_pre_act_sor;
	int	ifail = 0;
	METHOD_id_t  method_save_post_act_rfisor;
	METHOD_id_t  method_save_pre_act_rfisor;
	METHOD_id_t  method_create_item_act_rfisor;
	METHOD_id_t  rfi_sor_dataset_import;
	METHOD_id_t  method_rfi_revise;



	*decision = ALL_CUSTOMIZATIONS;

	ITK_CALL ( METHOD_find_method ( "T5_AutoSorRevision", "IMAN_save", &method_save_pre_act_sor  ) );
	//if ( method_save_pre_act_sor.id != NULLTAG )
	if ( method_save_pre_act_sor.id != 0 )//RSS 14.3 Changes
	{
		ITK_CALL ( METHOD_add_action ( method_save_pre_act_sor, METHOD_pre_action_type, (METHOD_function_t) SOR_save_method_pre, NULL ) ) ;
	}
	else
	{
		TC_write_syslog("\nSOR SOR_save_method_pre not found\n");fflush(stdout);
	}

	ITK_CALL ( METHOD_find_method ( "T5_AutoSorRevision", "IMAN_save", &method_save_post_act_sor  ) );
	//if ( method_save_post_act_sor.id != NULLTAG )
	if ( method_save_post_act_sor.id != 0 )//RSS 14.3 Changes
	{
		ITK_CALL ( METHOD_add_action ( method_save_post_act_sor, METHOD_post_action_type, (METHOD_function_t) SOR_save_method_post, NULL ) ) ;
	}
	else
	{
		TC_write_syslog("\nSOR SOR_save_method_post not found\n");fflush(stdout);
	}

	ITK_CALL ( METHOD_find_method("T5_AutoSorRevision", "IMAN_save", &method_save_pre_cond_sor) );
	//if (method_save_pre_cond_sor.id != NULLTAG)
	if (method_save_pre_cond_sor.id != 0)//RSS 14.3 Changes
	{
		ITK_CALL(METHOD_add_pre_condition(method_save_pre_cond_sor,(METHOD_function_t) SOR_Save_PreCond_Validation,NULL) ) ;
	}
	else
	{
		TC_write_syslog("\nSOR SOR_Save_PreCond_Validation not found\n");fflush(stdout);
	}

	ITK_CALL ( METHOD_find_prop_method("T5_AutoSorRevision", "t5_PPPMPrjCode", PROP_set_value_string_msg, &methodPPPProjValueChange) );
	//if (methodPPPProjValueChange.id != NULLTAG)
	if (methodPPPProjValueChange.id != 0)//RSS 14.3 Changes
	{
		ITK_CALL ( METHOD_add_action(methodPPPProjValueChange, METHOD_post_action_type, (METHOD_function_t) prop_PPPProjValueChange_ChngVariant, NULL) ) ;
	}
	else
	{
		TC_write_syslog("\nSOR SOR_Save_PreCond_Validation not found\n");fflush(stdout);
	}
	
	ITK_CALL ( METHOD_find_method(RES_Type, RES_checkin_msg, &method_sor_checkin) );
	//if (method_sor_checkin.id != NULLTAG)
	if (method_sor_checkin.id != 0)//RSS 14.3 Changes
    {
        ITK_CALL( METHOD_add_action(method_sor_checkin, METHOD_pre_action_type, (METHOD_function_t) sor_checkin_method, NULL));

		printf("\nSOR Pre-Action for check-in\n");fflush(stdout);
		TC_write_syslog("\nSOR Pre-Action for check-in\n");fflush(stdout);
    }
	else
	{
		TC_write_syslog("\nSOR sor_checkin_method not found\n");fflush(stdout);
	}
	

	ITK_CALL ( METHOD_find_method("ImanRelation", GRM_create_msg, &method_grm_pre_act_sor) );
	//if (method_grm_pre_act_sor.id != NULLTAG)
	if (method_grm_pre_act_sor.id != 0)//RSS 14.3 Changes
	{
		ITK_CALL( METHOD_add_action(method_grm_pre_act_sor, METHOD_pre_action_type, (METHOD_function_t) T5TaskToPart_SORCreateVal, NULL));
		printf("\nSOR Registered as METHOD_pre_action_type for T5TaskToPartCreateVal\n");fflush(stdout);
		TC_write_syslog("\nSOR Registered as METHOD_pre_action_type for T5TaskToPartCreateVal\n");fflush(stdout);
	}
	else
	{
		TC_write_syslog("\nSOR T5TaskToPart_SORCreateVal not found\n");fflush(stdout);
	}

//	ITK_CALL ( METHOD_find_method("ImanRelation", TC_delete_msg, &method3) );
//	if (method3.id != NULLTAG)
//	{
//		ITK_CALL( METHOD_add_action(method3, METHOD_pre_action_type, (METHOD_function_t) T5TaskToPart_SORDeleteVal, NULL));
//		printf("\nRegistered as METHOD_pre_action_type for T5TaskToPart_SORDeleteVal \n");fflush(stdout);
//	}

	ITK_CALL ( METHOD_register_method ( "T5_PPPMPrjCodeLOVType", LOV_ask_values_msg, &AutoSor_PPPM_proj_LOV_Method,  0, &method ) ) ;
//	TC_write_syslog("\nafter PPPMProject Code\n");fflush(stdout);

	ITK_CALL ( METHOD_find_method ( "T5_RfiSorRevision", "IMAN_save", &method_save_pre_act_rfisor  ) );
	//if ( method_save_pre_act_rfisor.id != NULLTAG )
	if ( method_save_pre_act_rfisor.id != 0 )//RSS 14.3 Changes
	{
		ITK_CALL ( METHOD_add_action ( method_save_pre_act_rfisor, METHOD_pre_action_type, (METHOD_function_t) RFISOR_save_method_pre, NULL ) ) ;
		TC_write_syslog("\nmethod_save_pre_act_rfisor\n");fflush(stdout);
    }
	

	ITK_CALL ( METHOD_find_method ( "T5_RfiSorRevision", "IMAN_save", &method_save_post_act_rfisor  ) );
	//if ( method_save_post_act_rfisor.id != NULLTAG )
	if ( method_save_post_act_rfisor.id != 0 )//RSS 14.3 Changes
	{
		ITK_CALL ( METHOD_add_action ( method_save_post_act_rfisor, METHOD_post_action_type, (METHOD_function_t) RFISOR_save_method_post, NULL ) ) ;
		TC_write_syslog("\nmethod_save_post_act_rfisor\n");fflush(stdout);
    }

	ITK_CALL ( METHOD_find_method ( "T5_RfiSor", "ITEM_create", &method_create_item_act_rfisor  ) );
	//if ( method_create_item_act_rfisor.id != NULLTAG )
	if ( method_create_item_act_rfisor.id != 0 )//RSS 14.3 Changes
	{
		ITK_CALL ( METHOD_add_action ( method_create_item_act_rfisor, METHOD_post_action_type, (METHOD_function_t) RFISOR_create_method, NULL ) ) ;
		
	}

	ITK_CALL(METHOD_find_method("PDF", AE_import_file_msg, &rfi_sor_dataset_import));
	//if (rfi_sor_dataset_import.id != NULLTAG)
	if (rfi_sor_dataset_import.id != 0)//RSS 14.3 Changes
	{
			ITK_CALL(METHOD_add_action(rfi_sor_dataset_import, METHOD_post_action_type,(METHOD_function_t)tm_rfi_sor_dataset_import ,NULL));
	}

	ITK_CALL(METHOD_find_method("T5_RfiSorRevision", "ITEM_copy_rev", &method_rfi_revise));
    //if (method_rfi_revise.id != NULLTAG)
    if (method_rfi_revise.id != 0)//RSS 14.3 Changes
    {
        ITK_CALL(METHOD_add_action(method_rfi_revise, METHOD_post_action_type,(METHOD_function_t)Revise_rfi_sor_postAct,NULL));
		
    }

	ITK_CALL ( EPM_register_action_handler ( "RFISOR-action-handler", "Placement: Assign Task Action of select-signoff-team task", (EPM_action_handler_t)Assign_RFISOR_Review_Func ) ) ;
	ITK_CALL( EPM_register_rule_handler ("RFISOR-rule-handler","Placement: Assign Task Action of select-signoff-team task", (EPM_rule_handler_t) Check_RFISOR_Review_Count_Func));
	
	
	ITK_CALL ( METHOD_find_prop_method("T5_RfiSorRevision", "t5_RfiPPPMPrjCode", PROP_set_value_string_msg, &method_rfi_PPPProjValChange) );
	//if (method_rfi_PPPProjValChange.id != NULLTAG)
	if (method_rfi_PPPProjValChange.id != 0)//RSS 14.3 Changes
	{
		ITK_CALL ( METHOD_add_action(method_rfi_PPPProjValChange, METHOD_post_action_type, (METHOD_function_t) prop_rfi_PPPProjValChg_ChgVariant, NULL) ) ;
	}
	else
	{
		TC_write_syslog("\nRFISOR RFISOR_Save_PreCond_Validation not found\n");fflush(stdout);
	}
  
    return ifail;
}

DLLAPI int tm_AutoSOR_register_callbacks ()
{
	int ifail=0;
	printf("\nregister_callback for tm_AutoSOR\n");fflush(stdout);
	TC_write_syslog("\nregister_callback for tm_AutoSOR\n");fflush(stdout);
	ITK_CALL ( CUSTOM_register_exit ( "tm_AutoSOR", "USER_init_module", (CUSTOM_EXIT_ftn_t)  tm_AutoSOR_CUST_register_method ) ) ;
	TC_write_syslog("\nafter register_callback for tm_AutoSOR\n");fflush(stdout);

	return ( ITK_ok );
}
