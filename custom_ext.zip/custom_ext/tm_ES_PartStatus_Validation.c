#define _CRT_SECURE_NO_DEPRECATE
#define NUM_ENTRIES 1
#define TE_MAXLINELEN  128 
#include <epm/epm.h>
#include <ae/dataset_msg.h>
#include <tccore/tc_msg.h>
#include <ps/ps.h>
#include <ps/ps_errors.h>
#include <time.h>
#include <ai/sample_err.h>
//#include <tc/tc.h>
#include <tc/tc_startup.h>
#include <tcinit/tcinit.h>
#include <ae/datasettype.h>
#include <tccore/grm_msg.h>
#include <tccore/workspaceobject.h>
#include <ae/dataset.h>
#include <ps/ps_errors.h>
#include <sa/sa.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <fclasses/tc_string.h>
#include <tccore/item.h>
#include <tccore/item_errors.h>
#include <sa/tcfile.h>
#include <pom/pom/pom.h>
#include <tccore/aom_prop.h>
//#include <epm/releasestatus.h>
#include <tccore/releasestatus.h>
#include <tcinit/tcinit.h>
#include <tccore/tctype.h>
#include <res/reservation.h>
#include <tccore/aom.h>
#include <tccore/custom.h>
#include <tc/emh.h>
#include <ict/ict_userservice.h>
#include <lov/lov.h>
#include <lov/lov_msg.h>
#include <base_utils/Mem.h>
#include <ss/ss_errors.h>
#include <sa/user.h>	
#include <tccore/grm.h>
#include <string.h>
#include <tc/folder.h>
#include <pie/pie.h>
#include <tccore/item_msg.h>
#include <fclasses/tc_stdarg.h>
#include <fclasses/tc_stdio.h>
#include <fclasses/tc_stdlib.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_time.h>
#include <dispatcher/dispatcher_itk.h>
#include <Fnd0Participant/participant.h>
#include <unistd.h>

#define TC_MAJOR_VERSION 14000

#if TC_MAJOR_VERSION <= 10
#define TC_master_form_rtype IMAN_master_form_rtype
#endif

#define HANDLE_IFAIL   handle_ifail( __FILE__, __LINE__ )
#define CHECK_IFAIL    if ( ifail != ITK_ok ) HANDLE_IFAIL;
#define ITK_err 919002
#define ITK_SVR_err (EMH_USER_error_base + 8)
#define CALLAPI(expr)ITKCALL(ifail = expr); if(ifail != ITK_ok) {  return ifail;}
#define CHECK_FAIL if (ifail != 0) { printf("line %d (ifail %d)\n", __LINE__, ifail); return 0;}


char* getMailIDs(int,tag_t*);
char* getCCMailIDs(char*,char*,char*,char*,char*);
char* getCCMailIDsForMailApproval(char *mail1, char *mail2, char *mail3, char *mail4, char *mail5,char *mail6,char *mail7,char *mail8,char *mail9);

static int PrintErrorStack( void )
/*
*
* PURPOSE : Function to dump the ITK error stack
*
* RETURN : causes program termination. If you made it here
*          you're not coming back modified for cust.c to not call exit()
*          but to just print the error stack
*
* NOTES : This version will always return ITK_ok, which is quite strange
*           actually. But if the error reporting was "OK" then that makes
*           sense
*
*/
{
	int iNumErrs = 0;
	const int *pSevLst = NULL;
	const int *pErrCdeLst = NULL;
	const char **pMsgLst = NULL;
	int i = 0;

	EMH_ask_errors( &iNumErrs, &pSevLst, &pErrCdeLst, &pMsgLst );
	fprintf( stderr, "Error(PrintErrorStack): \n");
	for ( i = 0; i < iNumErrs; i++ )
	{
		fprintf( stderr, "\t%6d: %s\n", pErrCdeLst[i], pMsgLst[i] );
	}
	return ITK_ok;
} 

static void handle_ifail( char * file, int line )
/*  Prints out the full error stack.*/
{
	int  i, n_errors;
	const int *severities;
	const int *ifails;
	const char **messages;
	EMH_ask_errors( &n_errors, &severities, &ifails, &messages );
	printf( "ERROR: (%s:%d)\n", file, line);
	for (i = 0; i < n_errors; i++)
	{
		printf( "    %6d: %s\n", ifails[i], messages[i] );
	}
	exit( EXIT_FAILURE );
}
;

//char* subString (char* mainStringf ,int fromCharf,int toCharf)
//{
	//int i;
	//char *retStringf;
	//retStringf = (char*) malloc(200);
	//for(i=0; i < toCharf; i++ )
			 // *(retStringf+i) = *(mainStringf+i+fromCharf);
	//*(retStringf+i) = '\0';
	//return retStringf;
//}
//;

extern EPM_decision_t DLLAPI EstimateSheet_Status_Validation(EPM_rule_message_t msg)
{
    int ifail = ITK_ok;
    int count = 0;
	int i = 0,j=0;
	
	int n_entryCntrl1    = 3;
	int control_number_found1 = 0;
	int ceflag = 0;
	int controlObjectExists = 0;

	EPM_decision_t decision = EPM_go;
	
    tag_t root_task = NULLTAG;
    tag_t *attachments = NULL;
	
	tag_t   qryTagCntrl1     = NULLTAG;
	tag_t *list_of_cntrl_tags1 = NULLTAG;

    char *currentTask = NULL;
    char *parent_name = NULL;
	
	char * objName = NULL;
	char * itemrevd = NULL;
	char *status_name = NULL;
	char *contrlobject = NULL;
	char *plantName = NULL;
    char *expectedReleaseStatus = NULL;
	
	char    *qry_entryCntrl1[3]  = {"SYSCD","SUBSYSCD","Delete Indicator"};	
	char	**qry_valuesCntrl1= (char **) MEM_alloc(50 * sizeof(char *));

    CALLAPI(EPM_ask_root_task(msg.task, &root_task));

    CALLAPI(AOM_ask_value_string(msg.task, "object_name", &currentTask));
    CALLAPI(AOM_ask_value_string(root_task, "object_name", &parent_name));

    printf("\nCurrent Task: %s", currentTask);
    printf("\nParent Task: %s\n", parent_name);

    CALLAPI(EPM_ask_attachments(root_task, EPM_target_attachment, &count, &attachments));

    for (i = 0; i < count && ceflag == 0; i++)
    {
        tag_t objTypeTag = NULLTAG;
        char *type_name = NULL;

        CALLAPI(TCTYPE_ask_object_type(attachments[i], &objTypeTag));
        CALLAPI(TCTYPE_ask_name2(objTypeTag, &type_name));
		printf("\n Primary Object type name is: %s\n", type_name);

      //  if (tc_strcmp(type_name, "Estimate Sheet Revision") == 0)
		if ((tc_strcmp(type_name, "T5_EstimateSheetRevision") == 0) ||(tc_strcmp(type_name, "Estimate Sheet Revision") == 0))
        {
			printf("\n Estimate Sheet Revision found");
			plantName = NULL;

            CALLAPI(AOM_ask_value_string(attachments[i],"t5_PEPlantName",&plantName));
            printf("\nEstimate Plant Name: %s\n",plantName);    
            TC_write_syslog( "\nEstimate Plant Name: %s",plantName );        

			expectedReleaseStatus = NULL;

            if (tc_strcmp(plantName,"CVBU LKO") == 0 )
            {
                expectedReleaseStatus = "T5_LcsStdlRlzd";                   
            }    
            else if (tc_strcmp( plantName,"CVBU PUNE" ) == 0 )     
            {
                expectedReleaseStatus = "T5_LcsStdpRlzd";                   
            }        
            else if (tc_strcmp( plantName,"CVBU JSR" ) == 0 )     
            {
                expectedReleaseStatus = "T5_LcsStdjRlzd";                   
            }     
            else if (tc_strcmp( plantName,"CVBU DWD" ) == 0 )     
            {
                expectedReleaseStatus = "T5_LcsStddRlzd";                  
            } 
            else if (tc_strcmp( plantName,"CVBU PNR" ) == 0 )     
            {
                expectedReleaseStatus = "T5_LcsStduRlzd";                  
            } 
            printf("\nExpected Release Status for Plant [%s] = [%s]\n",plantName,expectedReleaseStatus );
            TC_write_syslog("\nExpected Release Status for Plant [%s] = [%s]",plantName,expectedReleaseStatus );  
			
            tag_t rel_type = NULLTAG;

            if (GRM_find_relation_type("T5_Estimate_Design_Relation", &rel_type) == ITK_ok && rel_type != NULLTAG)
            {
				printf("\n Zuber check_2");
                tag_t *secondaryObjs = NULL;
                int secCount = 0;

                CALLAPI(GRM_list_secondary_objects_only(attachments[i], rel_type, &secCount, &secondaryObjs));
				
                for (int d = 0; d < secCount && ceflag == 0; d++)
                {
					printf("\n Zuber check_3 %d",d);
                    tag_t secTypeTag = NULLTAG;
                    char *sec_type_name = NULL;

                    CALLAPI(TCTYPE_ask_object_type(secondaryObjs[d], &secTypeTag));
                    CALLAPI(TCTYPE_ask_name2(secTypeTag, &sec_type_name));
					printf("\n Secondary object_type name is: %s", sec_type_name);

                    if (strcmp(sec_type_name, "Design") == 0)
                    {
                        tag_t *revList = NULL;
                        int revCount = 0;
						
						tag_t Designitem = secondaryObjs[d]; 

						printf("\n Design Item Tag: %u\n", Designitem);
						TC_write_syslog("\nDesign Item Tag: %u",Designitem);

                        if (ITEM_list_all_revs(Designitem, &revCount, &revList) == ITK_ok)
                        {
                          for (j = 0; j < revCount; j++)
                            {
                                tag_t *statusList = NULL;
                                int statusCount = 0;
								
								AOM_ask_value_string(revList[j], "object_name", &objName);
								printf("\n Parts with revisions is: %s", objName);
								TC_write_syslog("\nParts with revisions is: %s",objName);
								
								AOM_ask_value_string(revList[j], "item_revision_id", &itemrevd);
								printf("\n Parts with Item revision is: %s", itemrevd);
								TC_write_syslog("\nParts with Item revision is: %s",itemrevd);

                                CALLAPI(WSOM_ask_release_status_list(revList[j], &statusCount, &statusList));
									
								if(QRY_find2("Control Objects...", &qryTagCntrl1)== ITK_ok)
									if (qryTagCntrl1!=NULLTAG)
									{
										printf("\n Control Object Query Found \n");fflush(stdout);
										
										qry_valuesCntrl1[0]="EstimateSheet_Cntrl";
										qry_valuesCntrl1[1]="Active";
										qry_valuesCntrl1[2]= "0";
										
										 CALLAPI(QRY_execute(qryTagCntrl1, n_entryCntrl1, qry_entryCntrl1, qry_valuesCntrl1, &control_number_found1, &list_of_cntrl_tags1));
										
										printf("\n control_number_found1 ===> %d \n", control_number_found1);fflush(stdout);
									}	
							
									if(control_number_found1 > 0)
									{

									 controlObjectExists = 1;
									 
									for (int kh = 0; kh < statusCount; kh++)
									{

										CALLAPI(AOM_ask_value_string(statusList[kh], "object_name", &status_name));
									//	printf("\n Release Status Name Found is: %s", status_name);
										TC_write_syslog("\nRelease Status Name Found is: %s", status_name);

										//if (tc_strcmp(status_name, "T5_LcsStdlRlzd") == 0)
										//{
											//TC_write_syslog("\n STD Released status found %s", status_name);
											//printf("\nSTD Released found\n");
											
											//ceflag = 1;
										//}
										if (expectedReleaseStatus != NULL && tc_strcmp(status_name,expectedReleaseStatus ) == 0)
                                         {   
                                           printf("\nPlant-wise Standard Release Found\n" ); 
                                           printf("\nPlant: %s\n", plantName);
										   printf("\nExpected Status: %s\n",expectedReleaseStatus);
                                           printf("\nActual Status: %s\n",status_name);     
                                           TC_write_syslog("\nPlant-wise Standard Release Found");     
                                           TC_write_syslog("\nPlant: %s", plantName);
                                           TC_write_syslog("\nExpected Status: %s",expectedReleaseStatus );
                                           TC_write_syslog("\nActual Status: %s",status_name); 

                                            ceflag = 1;
                                        }

										MEM_free(status_name);
										if (ceflag) break;
										
									}
									}
                                MEM_free(statusList);
                            }
                        }

                        MEM_free(revList);
                    }

                    MEM_free(sec_type_name);
                }

                MEM_free(secondaryObjs);
            }
        }

        MEM_free(type_name);
    }

    MEM_free(attachments);
    MEM_free(currentTask);
    MEM_free(parent_name);
	
	
			/* No control object found -> Skipping validation */
		if (controlObjectExists == 0)
		{
			printf("\nNo active EstimateSheet control object found.");
			printf("\nSkipping STD Released validation.");

			TC_write_syslog("\nNo active EstimateSheet control object found. Validation skipped.");

			return EPM_go;
		}

		/* Control object exists and STD Released found */
		if (ceflag == 1)
		{
			printf("\nValidation Passed: STD Released found\n");

			TC_write_syslog("\nEPM_go command returned successfully");

			return EPM_go;
		}

		/* Control object exists but STD Released not found */
		EMH_store_error_s1(EMH_severity_error,ITK_err,"No Revision of Assembly is release from STDS");

		TC_write_syslog("\nValidation Failed : STD Released Design Revision Not Found");

		return EPM_nogo;
	
	
}

extern int ZR_register_method(int *decision, va_list args)
{
   
   int ifail=0;
 
   METHOD_id_t  method_DesRevRel ;
   METHOD_id_t  method_Fir ;
   *decision = ALL_CUSTOMIZATIONS;
   tag_t objTag = va_arg(args, tag_t); 


   if(ITK_ok ==  EPM_register_rule_handler ("ES_PartStatus_check","Validate the Assignment of Estimate Sheet", (EPM_rule_handler_t) EstimateSheet_Status_Validation))
   {
		printf("\t\n ZR Registered Rule Handler ES_Partstatus_check\n");fflush(stdout);
   }
   else
   {
		printf("\t ZR FAILED to register Rule Handler ES_Partstatus_check\n");fflush(stdout);
   }

   return ITK_ok;
}

extern DLLAPI int tm_ES_PartStatus_Validation_register_callbacks()
{     
	 CUSTOM_register_exit("tm_ES_PartStatus_Validation", "USER_init_module", (CUSTOM_EXIT_ftn_t) ZR_register_method);
	// CUSTOM_register_exit ("tm_tdm", "USERSERVICE_register_methods", (CUSTOM_EXIT_ftn_t)TDM_ReportModule);

	 printf("\n ZR registered function tm_ES_PartStatus_Validation\n");fflush(stdout);

	 return ( ITK_ok );
}


