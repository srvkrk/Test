/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_TMSHELLEXECUTION_2019_06_T5LINUXSHELLMANAGEMENT_IMPL_HXX 
#define TEAMCENTER_SERVICES_TMSHELLEXECUTION_2019_06_T5LINUXSHELLMANAGEMENT_IMPL_HXX


#include <t5linuxshellmanagement1906.hxx>

#include <tmShellExecution_exports.h>

namespace T5
{
    namespace Soa
    {
        namespace tmShellExecution
        {
            namespace _2019_06
            {
                class T5LinuxShellManagementImpl;
            }
        }
    }
}


class SOATMSHELLEXECUTION_API T5::Soa::tmShellExecution::_2019_06::T5LinuxShellManagementImpl : public T5::Soa::tmShellExecution::_2019_06::T5LinuxShellManagement

{
public:

    virtual std::string tmShellBatchCall ( const std::string shellpath, const std::string shellName, const std::string shellArg1, const std::string shellArg2 );


};

#include <tmShellExecution_undef.h>
#endif
